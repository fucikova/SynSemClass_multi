<G-vec00418-001-s019><boast.angeben><de> Wenn es allein durch meine gute Beziehung zum Heiligen Geist Gottes möglich wäre, bis zum Ende treu zu bleiben, dann kann ich darüber angeben, wie ich es geschafft habe auf Kurs zu bleiben und am Glauben festzuhalten.
<G-vec00418-001-s019><boast.angeben><en> If by my cooperation with the Spirit of God I remain faithful to the end, I can boast (a little) about how I was able to stay the course and finish the race.
<G-vec00418-001-s020><boast.angeben><de> Wir wollen ja nicht angeben, aber wenn es um Orte zum Besuchen geht, hat Schottland einiges zu bieten.
<G-vec00418-001-s020><boast.angeben><en> We don't like to boast, but when it comes to places to visit, Scotland has some mighty fine options indeed.
<G-vec00418-001-s021><boast.angeben><de> Wir sollen nicht angeben; wenn wir angeben wollen, denn über die Herrlichkeit von Gott.
<G-vec00418-001-s021><boast.angeben><en> We are not to boast about ourselves; if we want to boast, then we are to proclaim the glories of God.
<G-vec00418-001-s022><boast.angeben><de> Wir sollen nicht angeben; wenn wir angeben wollen, denn über die Herrlichkeit von Gott.
<G-vec00418-001-s022><boast.angeben><en> We are not to boast about ourselves; if we want to boast, then we are to proclaim the glories of God.
<G-vec00418-001-s023><boast.angeben><de> """Also, kein Mensch kann vor Mir angeben."
<G-vec00418-001-s023><boast.angeben><en> """So, no man may boast before Me."
<G-vec00418-001-s004><brag.angeben><de> Nicht weil sie angeben wollen, sondern weil sie eine tiefe Verbindung herstellen wollen, indem sie ihren Prozess und ihren Weg offen mit Ihnen teilen.
<G-vec00418-001-s004><brag.angeben><en> It's not because they want to brag. It's because they want to connect deeply with you, by sharing their process and journey openly.
<G-vec00418-001-s005><brag.angeben><de> Sie können angeben, bluffen und den Kunden bloßstellen.
<G-vec00418-001-s005><brag.angeben><en> They can brag, bluff and embarrass.
<G-vec00060-001-s062><declare.angeben><de> Der folgende Code zeigt, wie wir die Beziehung für die User - und Post -Klasse angeben.
<G-vec00060-001-s062><declare.angeben><en> The following code shows how we declare the relationships for the User and Post classes.
<G-vec00060-001-s063><declare.angeben><de> Beim Abonnieren musst du nur einmal angeben, wo auf deinem Computer die Folgen gespeichert werden sollen.
<G-vec00060-001-s063><declare.angeben><en> This way you have to declare where you want to save the episodes on your computer just once.
<G-vec00060-001-s064><declare.angeben><de> Wenn sie öffentlich tätig werden wollen, dann werden sie angeben müssen, von wem sie Geld erhalten, wie viel sie erhalten und warum sie es bekommen.
<G-vec00060-001-s064><declare.angeben><en> If they want to continue their public activities, then they must declare who they receive funding from, how much they have received, and why they have received it.
<G-vec00060-001-s065><declare.angeben><de> Mit dem System ABAX 2 müssen Sie nicht alle Funktionen sofort angeben.
<G-vec00060-001-s065><declare.angeben><en> With the ABAX 2 system you donot have to declare all the functions at once.
<G-vec00060-001-s066><declare.angeben><de> Kommission untersucht die EBA, ob Finanzunterneh­ men, die angeben, dass sie ihre Tätigkeiten im Einklang mit den Grundsätzen des islamischen Bankwesens aus­ üben, hinreichend von den Bestimmungen dieser Richtlinie und der Verordnung [vom Amt für Ver­ öffentlichungen einzufügen] erfasst werden.
<G-vec00060-001-s066><declare.angeben><en> Upon receiving a mandate from the Commission, EBA shall explore whether financial sector entities which declare that they carry out their activities in accordance with Islamic banking principles are adequately covered by the provisions of this Directive and Regulation [inserted by OP].
<G-vec00060-001-s067><declare.angeben><de> Wegen der Euroeinführung werden die Gesellschaften auch ihre Satzungen ändern müssen und in diesen den Nennwert der Aktien sowie das Stammkapital in Euro angeben müssen.
<G-vec00060-001-s067><declare.angeben><en> Because of euro adoption, companies must also change their statues and declare their share capital and the nominal value of their shares in euro.
<G-vec00060-001-s068><declare.angeben><de> Anmerkung: Leider kann ich hierzu keine Quelle angeben, da ich mir vor vielen Jahren nur den Text notiert hatte.
<G-vec00060-001-s068><declare.angeben><en> Comment: Unfortunately I can declare no source to this since I had written down only the text many years ago.
<G-vec00060-001-s069><declare.angeben><de> Hier müssen Sie die Feldnamen angeben, wie sie vom Identity Provider gesandt wurden.
<G-vec00060-001-s069><declare.angeben><en> Here, you need to declare the fields names as they are sent by the identity provider.
<G-vec00078-001-s062><declare.angeben><de> Der folgende Code zeigt, wie wir die Beziehung für die User - und Post -Klasse angeben.
<G-vec00078-001-s062><declare.angeben><en> The following code shows how we declare the relationships for the User and Post classes.
<G-vec00078-001-s063><declare.angeben><de> Beim Abonnieren musst du nur einmal angeben, wo auf deinem Computer die Folgen gespeichert werden sollen.
<G-vec00078-001-s063><declare.angeben><en> This way you have to declare where you want to save the episodes on your computer just once.
<G-vec00078-001-s064><declare.angeben><de> Wenn sie öffentlich tätig werden wollen, dann werden sie angeben müssen, von wem sie Geld erhalten, wie viel sie erhalten und warum sie es bekommen.
<G-vec00078-001-s064><declare.angeben><en> If they want to continue their public activities, then they must declare who they receive funding from, how much they have received, and why they have received it.
<G-vec00078-001-s065><declare.angeben><de> Mit dem System ABAX 2 müssen Sie nicht alle Funktionen sofort angeben.
<G-vec00078-001-s065><declare.angeben><en> With the ABAX 2 system you donot have to declare all the functions at once.
<G-vec00078-001-s066><declare.angeben><de> Kommission untersucht die EBA, ob Finanzunterneh­ men, die angeben, dass sie ihre Tätigkeiten im Einklang mit den Grundsätzen des islamischen Bankwesens aus­ üben, hinreichend von den Bestimmungen dieser Richtlinie und der Verordnung [vom Amt für Ver­ öffentlichungen einzufügen] erfasst werden.
<G-vec00078-001-s066><declare.angeben><en> Upon receiving a mandate from the Commission, EBA shall explore whether financial sector entities which declare that they carry out their activities in accordance with Islamic banking principles are adequately covered by the provisions of this Directive and Regulation [inserted by OP].
<G-vec00078-001-s067><declare.angeben><de> Wegen der Euroeinführung werden die Gesellschaften auch ihre Satzungen ändern müssen und in diesen den Nennwert der Aktien sowie das Stammkapital in Euro angeben müssen.
<G-vec00078-001-s067><declare.angeben><en> Because of euro adoption, companies must also change their statues and declare their share capital and the nominal value of their shares in euro.
<G-vec00078-001-s068><declare.angeben><de> Anmerkung: Leider kann ich hierzu keine Quelle angeben, da ich mir vor vielen Jahren nur den Text notiert hatte.
<G-vec00078-001-s068><declare.angeben><en> Comment: Unfortunately I can declare no source to this since I had written down only the text many years ago.
<G-vec00078-001-s069><declare.angeben><de> Hier müssen Sie die Feldnamen angeben, wie sie vom Identity Provider gesandt wurden.
<G-vec00078-001-s069><declare.angeben><en> Here, you need to declare the fields names as they are sent by the identity provider.
<G-vec00060-001-s089><indicate.angeben><de> Mit einem Template und einem Profil kann die IT-Abteilung exakt angeben, wie ein Konto angelegt oder geändert werden soll.
<G-vec00060-001-s089><indicate.angeben><en> Using the template and profile, the systems administration department can indicate exactly how an account must be created.
<G-vec00060-001-s090><indicate.angeben><de> Jede Benennung durch einen Vertragsstaat oder der Vorsitzende führt den Namen angeben, Anschrift und Nationalität des designee, und enthält eine Erklärung seiner Qualifikationen, insbesondere in Bezug auf seine Kompetenz in den Bereichen Recht, Handel, Industrie und Finanzen.
<G-vec00060-001-s090><indicate.angeben><en> Each designation made by a Contracting State or by the Chairman shall indicate the name, address and nationality of the designee, and include a statement of his qualifications, with particular reference to his competence in the fields of law, commerce, industry and finance.
<G-vec00060-001-s091><indicate.angeben><de> wenn die Option für rekursive Durchsuchung von E-Mail-Dateien in Unterordner anzumerken, dass aktiviert ist, es ist genug, um einfach den Pfad zum Stammordner der E-Mail-Datenbank angeben.
<G-vec00060-001-s091><indicate.angeben><en> Note that if the option for recursive searching of e-mail files in subfolders is enabled, it is enough to simply indicate the path to the root folder of the e-mail database.
<G-vec00060-001-s092><indicate.angeben><de> Die Quellen angeben, die Aristonoa, als aristokratischer Abstammung und loyal im mazedonischen Zoll.
<G-vec00060-001-s092><indicate.angeben><en> The sources indicate the Aristonoa, as aristocratic descent and loyal in Macedonian customs.
<G-vec00060-001-s093><indicate.angeben><de> Dann bitte Folgendes angeben “KUKU 2013.......
<G-vec00060-001-s093><indicate.angeben><en> Please indicate the following: “KUKU 2013.......
<G-vec00060-001-s094><indicate.angeben><de> Die Genauigkeit des Datums ist wichtig, weil die Prologe Antimarcioni historischen Aufzeichnungen sind, die angeben, wie die frühe Kirche, hatte gerade einen Hauch von Ketzerei und Verwirrung sein inspiriert, sofort bereitgestellten Texte.
<G-vec00060-001-s094><indicate.angeben><en> The accuracy of the data is very important because the Prologues are antimarcioni historical records that indicate how the early Church, just had hints of heresy and confusion on the texts considered inspired provided immediately.
<G-vec00060-001-s095><indicate.angeben><de> "Schließlich kannst du etwas ""Wackelgeschwindigkeit"" angeben."
<G-vec00060-001-s095><indicate.angeben><en> Finally you can indicate some amount of wiggling of the speed.
<G-vec00060-001-s096><indicate.angeben><de> Niemand kann einen vernünftigen Grund angeben, weshalb in ähnlicher Weise eine Maschine – dieses Gerät mit selbständiger Bewegung, mit einem gewissen Eigenleben – nicht schön sein könnte.
<G-vec00060-001-s096><indicate.angeben><en> Nobody can indicate a good reason why in a similar way a machine - this device with an independent movement, with a certain independent existence - could be not beautiful as well.
<G-vec00060-001-s097><indicate.angeben><de> Du kannst tatsächlich angeben, wie dies passieren muss.
<G-vec00060-001-s097><indicate.angeben><en> You can actually indicate how this must happen.
<G-vec00060-001-s098><indicate.angeben><de> Auf dem Anmeldeformular können Sie die bevorzugten Tage und Uhrzeiten angeben, die zur Festlegung der späteren Unterrichtszeiten während der Probestunde benötigt werden.
<G-vec00060-001-s098><indicate.angeben><en> On the registration form, you can indicate your preferred day and time of the session to coincide with the teacher's availability.
<G-vec00060-001-s099><indicate.angeben><de> Eine Fehlermeldung kann ebenfalls angeben, dass ein Fehler aufgetreten ist.
<G-vec00060-001-s099><indicate.angeben><en> An error message may also indicate that an error has been encountered.
<G-vec00060-001-s100><indicate.angeben><de> Der Kunde muss die gewünschte Zahlungsart angeben.
<G-vec00060-001-s100><indicate.angeben><en> • Lastly, the Customer must also indicate the selected method of payment.
<G-vec00060-001-s101><indicate.angeben><de> Weil die Zunge nur angeben kann Textur und unterscheiden zwischen süß, sauer, bitter, salzig und umami das meiste, was als den Geschmackssinn wahrgenommen wird tatsächlich von Geruch abgeleitet.
<G-vec00060-001-s101><indicate.angeben><en> Because the tongue can only indicate texture and differentiate between sweet, sour, bitter, salty, and umami most of what is perceived as the sense of taste is actually derived from smell.
<G-vec00060-001-s102><indicate.angeben><de> Ein Affe muss eine klassische Gedächtnisaufgabe lösen: dem Tier werden kurz hintereinander zwei Bilder gezeigt und es muss angeben, ob das zweite Bild dem ersten entspricht oder nicht.
<G-vec00060-001-s102><indicate.angeben><en> A monkey has to carry out a classic memory task: the animal is shown two consecutive images and then has to indicate whether the second image was the same as the first one.
<G-vec00060-001-s103><indicate.angeben><de> Diese Fotos und Illustrationen sollen dem Benutzer die Kategorie der Unterkunft oder das Maß des Komforts angeben und begründen keine darüber hinausgehende Verpflichtung.
<G-vec00060-001-s103><indicate.angeben><en> The purpose of these photos and illustrations is to indicate the category of accommodation or the degree of comfort to the User and may not be the source of any commitment beyond this purpose.
<G-vec00060-001-s104><indicate.angeben><de> Des Weiteren kann der Anmelder auf eine Aufforderung nach Regel 62a hin Argumente gegen die Feststellungen in der Aufforderung einreichen und als Hauptantrag eine vollständige Recherche der eingereichten Ansprüche beantragen sowie in einem Hilfsantrag für den Fall, dass der Prüfer nicht überzeugt sein sollte, die zu recherchierenden unabhängigen Ansprüche angeben (siehe auch H‑III, 3.2).
<G-vec00060-001-s104><indicate.angeben><en> Furthermore, the applicant may, in reply to an invitation under Rule 62a, file arguments against the findings in the invitation requesting as a main request that the claims as filed be completely searched and as an auxiliary request, in case the examiner is not convinced, indicate the independent claims to be searched (see also H‑III, 3.2).
<G-vec00060-001-s105><indicate.angeben><de> Möchtest Du Dein Testgerät zurücksenden, musst Du dies im Abschlussfragebogen, welcher Dir zum Kampagnen-Ende zur Verfügung gestellt wird, zwingend angeben.
<G-vec00060-001-s105><indicate.angeben><en> Return your device. Should you wish to do so, you must indicate it in the end survey communicated at the end of the campaign.
<G-vec00060-001-s106><indicate.angeben><de> Sie sollten angeben, ob generell Placebos eingesetzt würden.
<G-vec00060-001-s106><indicate.angeben><en> They were to indicate whether placebos are generally used.
<G-vec00060-001-s107><indicate.angeben><de> Die Protokoll müssen angeben, welche Sender(laufen einen Multiplikator) machte jedes QSO.
<G-vec00060-001-s107><indicate.angeben><en> The log must indicate which transmitter(run a multiplier) made each QSO.
<G-vec00060-001-s057><specify.angeben><de> In diesem Fall können Sie beim Erstellen eines Maschinenkatalogs die auf den Maschinen installierte VDA-Version angeben.
<G-vec00060-001-s057><specify.angeben><en> In this scenario, when you create a machine catalog, you can specify the VDA version installed on the machines.
<G-vec00060-001-s058><specify.angeben><de> Zudem können Sie angeben, ob die MIF-Dokumente, die Sie in Across bearbeiten, mit einer FrameMaker-Version erstellt wurden, bei der das Problem mit der Darstellung von Zacute und tcaron behoben ist (ab Version 7.2).
<G-vec00060-001-s058><specify.angeben><en> Furthermore, you can specify whether the MIF documents you edit in Across were created with a FrameMaker version in which the Zacute/tcaron display problem has been resolved (from version 7.2).
<G-vec00060-001-s059><specify.angeben><de> Wenn Sie die NDR-Überprüfung aktivieren, müssen Sie einen NDR-Überprüfung aktivieren angeben (eine Zeichenfolge mit mindestens 8 Zeichen, ähnlich einer Passphrase).
<G-vec00060-001-s059><specify.angeben><en> When you Enable NDR check, you must specify Signature seed (a string of at least 8 characters, something like a passphrase).
<G-vec00060-001-s060><specify.angeben><de> Das Schlimmste ist, dass man den Prozess nicht verlassen kann nur laufen - Sie kann es immer noch kontrollieren müssen und manuell die nächste Mailbox für die Konvertierung auswählen und das Ziel angeben PST Datei als auch.
<G-vec00060-001-s060><specify.angeben><en> The worst thing is that you can’t leave the process just running – you still have to control it and manually pick the next mailbox for conversion and specify the target PST file as well.
<G-vec00060-001-s061><specify.angeben><de> Du musst möglicherweise den Videotextsprachcode für dein Land angeben.
<G-vec00060-001-s061><specify.angeben><en> You might need to specify the teletext language code for your country.
<G-vec00060-001-s062><specify.angeben><de> In einem Fragebogen sollten diese unter anderem ihre politischen Positionen bezüglich Fracking und ihre Kontakte zu anderen Akteuren angeben sowie deren Einfluss beurteilen.
<G-vec00060-001-s062><specify.angeben><en> In a survey, these actors were asked to indicate their policy positions with regard to fracking and to specify their relations with and assess the influence of other actors.
<G-vec00060-001-s063><specify.angeben><de> 3° und 4° Bett -10%; Preise für Kinder auf Anfrage per Email, je nach Anzahl der Familienmitglieder (Angeben: Anzahl derErwachsene, anzahl der kinder, Geburtsdatum und Skifahrer Detail).
<G-vec00060-001-s063><specify.angeben><en> Prices for children upon request by email according to families (specify number of adults, number of children, date of birth and detail skiers).
<G-vec00060-001-s064><specify.angeben><de> "Außerdem wurde das Disk-Tools-Menü erweitert: * ""Freien Speicher extrahieren"" durchläuft das gegenwärtig geöffnete Laufwerk und sammelt alle unbenutzte Cluster in einer Zieldatei, die Sie angeben."
<G-vec00060-001-s064><specify.angeben><en> Besides, the Disk Tools menu has been extended: * Gather Free Space traverses the currently open logical drive and gathers all unused clusters into a destination file you specify.
<G-vec00060-001-s065><specify.angeben><de> Durch das Abonnieren von Ereignissen können Sie jedoch die Ereignisse weiterleiten, eine Aktion angeben, mit der auf die Ereignisse reagiert wird, und das Abonnement abbrechen.
<G-vec00060-001-s065><specify.angeben><en> However, subscribing lets you forward the events, specify an action to respond to the events, and cancel the subscription.
<G-vec00060-001-s066><specify.angeben><de> Wenn Sie eine Datenbank auf einem Remoteserver erstellen, sollten Sie die Spezifikation des Remoteservers angeben.
<G-vec00060-001-s066><specify.angeben><en> If you create a database on a remote server, you should specify the remote server specification.
<G-vec00060-001-s067><specify.angeben><de> Zeilenhöhe Wenn Sie eine feste Zeilenhöhe angeben, muss diese größer als die Schriftgröße sein, andernfalls laufen die Zeilen ineinander.
<G-vec00060-001-s067><specify.angeben><en> Line height If you specify a fixed line height, enter a line height larger than the font size or lines of text will overlap.
<G-vec00060-001-s068><specify.angeben><de> Wenn Sie die cephx-Authentifizierung nutzen, müssen Sie außerdem ein Geheimnis angeben.
<G-vec00060-001-s068><specify.angeben><en> If you use cephx authentication, you also need to specify a secret.
<G-vec00060-001-s069><specify.angeben><de> Wenn Sie beispielsweise angeben, dass die Regel nur auf RAS-Verbindungen angewendet werden soll, stimmen nur diese Verbindungen mit der Regel überein.
<G-vec00060-001-s069><specify.angeben><en> For example, if you specify that a rule to be applied only to remote access connections, then only these connections will match the rule.
<G-vec00060-001-s070><specify.angeben><de> Mitglieder Ihres Skype Manager können ebenfalls die Währung angeben, die sie...
<G-vec00060-001-s070><specify.angeben><en> Members of your Skype Manager can also specify the currency they want to use.If...
<G-vec00060-001-s071><specify.angeben><de> Sie können auch Befehlszeilenparameter mit EXE-Dateien angeben.
<G-vec00060-001-s071><specify.angeben><en> You can also specify command-line parameters with .exe files.
<G-vec00060-001-s072><specify.angeben><de> Hotel pick-up und drop-off zur Verfügung gestellt, bitte angeben.
<G-vec00060-001-s072><specify.angeben><en> Hotel pick up and drop off provided, please specify.
<G-vec00060-001-s073><specify.angeben><de> Vor dem Kauf eines Staubsaugers Bosch BSGL 32 383 angeben, alle Optionen, Ausstattung, Aussehen und Garantie vom Verkäufer.
<G-vec00060-001-s073><specify.angeben><en> Before buying a vacuum cleaner Bosch BSGL 32 383 specify all your options, equipment, appearance and warranty from the seller.
<G-vec00060-001-s074><specify.angeben><de> Wenn Sie eine von dieser Rechnungsadresse abweichende Lieferanschrift angeben wollen, können Sie dies im nächsten Schritt des Bestellvorgangs tun, wenn die angegebene Rechnungsadresse der Versandadresse entspricht, wird dieser Schritt übersprungen.
<G-vec00060-001-s074><specify.angeben><en> Fields marked with * must be filled in. If you want to specify a shipping address that is different from the billing address, you can do so in the next step of the ordering process. If the specified shipping address matches the billing address, this step is skipped.
<G-vec00060-001-s075><specify.angeben><de> Wenn Sie diesen Parameter angeben, kann sich der Benutzer mehrfach mit seinem Benutzer-Account anmelden.
<G-vec00060-001-s075><specify.angeben><en> If you specify this parameter, the user can login multiple times with his/her user account.
<G-vec00060-001-s076><specify.angeben><de> Wenn Sie eine Fehlerklasse und eine von deren abgeleiteten Klassen angeben, platzieren Sie den Catch-Block für die abgeleitete Klasse vor dem Catch-Block für die allgemeine Klasse.
<G-vec00060-001-s076><specify.angeben><en> If you specify an error class and one of its derived classes, place the Catch block for the derived class before the Catch block for the general class.
<G-vec00060-001-s077><specify.angeben><de> Die Java-Datei müssen wir auch im Makefile mit MURL_ANDROID_JAVA_FILES angeben, damit sie beim Build-Vorgang berücksichtigt wird.
<G-vec00060-001-s077><specify.angeben><en> To add the Java file to the build process we need to specify it in the Makefile with MURL_ANDROID_JAVA_FILES.
<G-vec00060-001-s078><specify.angeben><de> In dem Geteilte Zellen Dialog, überprüfen Sie die Aufteilung Art Sie brauchen, und klicken Sie dann auf Breite angeben Option, und geben Sie die Länge, die Sie teilen möchten, in das nächste Textfeld ein.
<G-vec00060-001-s078><specify.angeben><en> In the Split Cells dialog, check the split Type you need, and then click Specify width option, and type the length you want to split based on into the next textbox.
<G-vec00060-001-s079><specify.angeben><de> Sie können eine Zeichenkette angeben, mit dem Sie den Benutzer zur Eingabe auffordern.
<G-vec00060-001-s079><specify.angeben><en> You may specify a string with which to prompt the user.
<G-vec00060-001-s080><specify.angeben><de> Wenn Sie ein vielfältiges Inventar, Sie können weitere Kosten angeben, indem Sie pro Produkt Versand Fracht Einrichtung und eine Kosten für jeden Posten einrichten.
<G-vec00060-001-s080><specify.angeben><en> If you have a diverse inventory, you can further specify costs by setting up shipping freight per product and set up a cost for each item.
<G-vec00060-001-s081><specify.angeben><de> "Wenn Sie möchten, um importierten E-Mails zu einem neuen eigenständigen sparen PST Datei, verwenden die "" Save .PST "", Um seine Position angeben und starten Sie den Vorgang."
<G-vec00060-001-s081><specify.angeben><en> If you would like to save imported emails to a new standalone PST file, use the “ Save .PST ” button to specify its location and start the process.
<G-vec00060-001-s082><specify.angeben><de> Somit muss der Mitarbeiter keinen Benutzernamen oder ein Passwort angeben, dennoch erreichen Sie eine hohe Sicherheit.
<G-vec00060-001-s082><specify.angeben><en> In this way, the employee does not have to specify a user name or a password but a high level of security is achieved.
<G-vec00060-001-s083><specify.angeben><de> In den Einstellungen können Sie die Anzahl der FPS angeben geradlinig Abhängigkeit Entladen Sie den Akku.
<G-vec00060-001-s083><specify.angeben><en> In the settings you can specify the number of FPS is rectilinear dependence discharge the battery.
<G-vec00060-001-s084><specify.angeben><de> Spinn verbindet, um einen Begleiter iOS – / Android-app über Wi-Fi, so können die Benutzer angeben, wie Sie wollen Ihren Kaffee getan, oder planen Sie eine Tasse vor der Zeit, obwohl dies kann auch direkt aus der Maschine oder durch Alexa Sprachbefehle.
<G-vec00060-001-s084><specify.angeben><en> Spinn connects to a companion iOS / Android app over Wi-Fi so users can specify how they want their coffee done, or schedule a cup ahead of time, although this can also be done directly from the machine or through Alexa voice commands.
<G-vec00060-001-s085><specify.angeben><de> Falls Sie die Anzeigenserver-URL auf Playerebene angeben möchten, finden Sie Informationen hierzu unter Zuweisen der Anzeigenserver-URL auf Playerebene über das Werbemodul.
<G-vec00060-001-s085><specify.angeben><en> However, if you want to specify the Ad Server URL at the player level, see Assigning the Ad Server URL at the Player Level from Advertising Module.
<G-vec00060-001-s086><specify.angeben><de> mVPN-Tunnelausschlussliste: Wenn Sie den Micro-VPN-Zugriff aktivieren, können Sie die Domänen angeben, die Sie aus den Micro-VPN-Richtlinien ausschließen möchten.
<G-vec00060-001-s086><specify.angeben><en> mVPN tunnel exclusion list: If you enable micro VPN access, you can specify the domains to exclude from the micro VPN policies.
<G-vec00060-001-s087><specify.angeben><de> Falls Sie eine bestimmte Spielkennung angeben möchten, finden Sie diese in ~/.minetest/games/ .
<G-vec00060-001-s087><specify.angeben><en> If you want to specify a specific game ID, the game ID choices are located in /Minetest/games/ .
<G-vec00060-001-s088><specify.angeben><de> Wenn Sie keinen Wert angeben, verbleiben Faxe so lange im Archiv, bis sie manuell gelöscht werden.
<G-vec00060-001-s088><specify.angeben><en> If you do not specify a value, faxes will remain in the archive until deleted manually.
<G-vec00060-001-s089><specify.angeben><de> Wenn Sie ein alternatives Verzeichnis angeben möchten, kopieren Sie bitte alle Daten aus dem Verzeichnis wwwroot im estos MetaDirectory Installationsverzeichnis.
<G-vec00060-001-s089><specify.angeben><en> If you want to specify an alternative directory, copy all data from the wwwroot directory to the estos MetaDirectory installation directory.
<G-vec00060-001-s090><specify.angeben><de> Auf dieser Seite des Assistenten können Sie weitere Optionen angeben, bevor Sie das Zusammenführen starten.
<G-vec00060-001-s090><specify.angeben><en> This page of the wizard lets you specify advanced options, before starting the merge process.
<G-vec00060-001-s108><indicate.angeben><de> Tagout-Apparate sind so anzubringen, dass deutlich angegeben ist, dass das Bedienen oder Umschalten der energieisolierenden Vorrichtung von der „sicheren“ oder „Aus“-Stellung in eine andere Stellung untersagt ist.
<G-vec00060-001-s108><indicate.angeben><en> "Tagout devices, where used, shall be affixed in such a manner as will clearly indicate that the operation or movement of energy isolating devices from the ""safe"" or ""off"" position is prohibited."
<G-vec00060-001-s109><indicate.angeben><de> Allerdings können auch bei nichtökologischen Erzeugnissen Zutaten ökologischen Ursprungs angegeben werden, dies jedoch ausschließlich auf der Zutatenliste.
<G-vec00060-001-s109><indicate.angeben><en> But non-organic products will be entitled to indicate organic ingredients on the ingredients list only.
<G-vec00060-001-s110><indicate.angeben><de> Dort können auch Momente angegeben werden, die nach Ansicht der Person selbst zu hohen Tonometerzahlen führen können.
<G-vec00060-001-s110><indicate.angeben><en> It is also possible to indicate moments there, which, in the opinion of the person himself, could contribute to high numbers on the tonometer.
<G-vec00060-001-s111><indicate.angeben><de> Ihr habt angegeben, dass das etwas damit zu tun hatte, dass Ark und ich nun letztendlich zusammen sind, und die ersten Phasen einer gewissen großen Bestimmung an ihren Platz fallen würden.
<G-vec00060-001-s111><indicate.angeben><en> You did indicate that this had something to do with the fact that Ark and I were together, finally, and the beginning stages of some grand destiny were falling into place.
<G-vec00060-001-s112><indicate.angeben><de> Auf der Website werden die Verkaufspreise jeden Produkts und die Art der Berechnung des Gesamtpreises des Kaufs klar und deutlich angegeben.
<G-vec00060-001-s112><indicate.angeben><en> The Site shall clearly indicate the Selling Prices for each product and the way to calculate the total price of the purchase.
<G-vec00060-001-s113><indicate.angeben><de> - Falls Geräte auch von anderen Richtlinien erfasst werden, die andere Aspekte behandeln und in denen die CE-Konformitätskennzeichnung vorgesehen ist, wird mit dieser Kennzeichnung angegeben, daß auch von der Konformität dieser Geräte mit den Bestimmungen dieser anderen Richtlinien auszugehen ist.
<G-vec00060-001-s113><indicate.angeben><en> - Where apparatus is the subject of other Directives covering other aspects and which also provide for the CE conformity marking, the latter shall indicate that the appliances are also presumed to conform to those other Directives.
<G-vec00060-001-s114><indicate.angeben><de> Entwertung: Die Karte muss in den öffentlichen Verkehrsmitteln bei jeder Fahrt entwertet werden (der Bestimmungsort muss nicht angegeben werden).
<G-vec00060-001-s114><indicate.angeben><en> How to use the card: Use your card like a ticket every time you use public transport (you need not indicate your destination).
<G-vec00060-001-s115><indicate.angeben><de> Darin ist ein Richtwert für Uran von 15 Mikrogramm pro Liter angegeben.
<G-vec00060-001-s115><indicate.angeben><en> They indicate a guideline value for uranium of 15 microgram per litre.
<G-vec00060-001-s116><indicate.angeben><de> In der Zusammenfassung D1a von D1 sei nicht angegeben, wie die erste Cursorposition zustandekomme, d. h., ob sie durch die Berührung des Tastfelds mit dem Finger oder als Ergebnis eines bereits auf dem Bildschirm vorhandenen Cursors erzeugt werde, der vom Finger zu einer neuen Position verschoben werden müsse.
<G-vec00060-001-s116><indicate.angeben><en> The abstract D1a, which related to D1, did not indicate how the cursor position was initially generated, whether it was generated when the finger touched the touch panel or as a result of a cursor already on a screen which had to be dragged to a new position by the finger.
<G-vec00060-001-s117><indicate.angeben><de> Um den Wert einer noch austehenden Zahlungsfolge bestimmen zu können muss eine Vergleichsrendite angegeben werden, die alternativ mit dem Kapital erzielt werden könnte.
<G-vec00060-001-s117><indicate.angeben><en> To determine the value of a sequence of pending payments you need to indicate a comparison net yield, which could be obtained alternatively with the capital.
<G-vec00060-001-s118><indicate.angeben><de> In Fällen, in denen die Reproduktion einer vorhergehenden Genehmigung bedarf, trifft die zuvor angegebene allgemeine Erlaubnis nicht zu und klare Angaben bezüglich der Einschränkungen müssen angegeben werden.
<G-vec00060-001-s118><indicate.angeben><en> Where prior permission is required to reproduce information, such permission excludes the aforementioned general permission and must clearly indicate any restrictions on its use.
<G-vec00060-001-s119><indicate.angeben><de> Unsere hier angegeben Preise verstehen sich als Endpreise inkl.
<G-vec00060-001-s119><indicate.angeben><en> The prices we indicate are the final prices including value added tax.
<G-vec00060-001-s120><indicate.angeben><de> Online-Anmeldung: Bei der Anmeldung muss die genaue Teilnehmerzahl angegeben werden (Studenten, Dozenten und eventuelle Begleitpersonen) .
<G-vec00060-001-s120><indicate.angeben><en> Online booking: upon booking it is necessary to indicate the precise number of members in the group (students, teachers and any other accompanying visitors).
<G-vec00060-001-s121><indicate.angeben><de> "Im Befehl wird mit dem Dollarzeichen ($) eine Variable angegeben, und mit dem Zuweisungsoperator (=) wird das Ergebnis des Befehls ""Get-Service"" der neu erstellten Variablen zugewiesen."
<G-vec00060-001-s121><indicate.angeben><en> The command uses a dollar sign ($) to indicate a variable and the assignment operator (=) to assign the result of the Get-Service command to the newly created variable.
<G-vec00060-001-s122><indicate.angeben><de> "Wenn die Alarmzentrale in CID kommuniziert es kommuniziert bei 2300Hz und eine schnellere Kommunikation (höhere Baudrate) ""[was führen kann die Alarmzentrale mehrmals die Wahlwiederholung und gegebenenfalls eine fehlgeschlagene Verbindung angegeben]."
<G-vec00060-001-s122><indicate.angeben><en> "When the alarm panel communicates in CID it is communicating at 2300Hz and is a faster communication (higher baud rate)"" [which can cause the alarm panel to redial several times and possibly indicate a failed connection]."
<G-vec00060-001-s123><indicate.angeben><de> Daher muss angegeben werden, was genau es bestätigen soll.
<G-vec00060-001-s123><indicate.angeben><en> Therefore, it is necessary to indicate what exactly it should confirm.
<G-vec00060-001-s124><indicate.angeben><de> In der Datenschutzerklärung wird immer das späteste Datum der Änderung angegeben.
<G-vec00060-001-s124><indicate.angeben><en> The privacy policy will always indicate the latest date of the change.
<G-vec00060-001-s125><indicate.angeben><de> "Im Fall von ""polling"" eines akkreditierten Journalisten, der ein Telefax senden will, ist dieser gebeten, bei der Telefax-Nummer des Presseamtes des Heiligen Stuhls anrufen zu lassen, die ihm vom beauftragten Personal angegeben wird und dabei die Uhrzeit für den Anruf vom Faxgerät des Empfängers anzugeben."
<G-vec00060-001-s125><indicate.angeben><en> In the case of “polling”, the accredited journalist who intends to send a telefax is asked to have the destined receiver call the telefax number of the Holy See Press Office (the reception personnel will indicate the telephone number and the hour in which the receiving end should place the call).
<G-vec00060-001-s126><indicate.angeben><de> Wenn dies nach billigem Ermessen nicht möglich ist, wird der Unternehmer – bevor der Fernabsatzvertrag zustande kommt – angegeben, auf welche Weise die AGB bei dem Unternehmer einzusehen sind und diese auf Anfrage des Verbrauchers schnellstmöglich kostenlos zugeschickt werden.
<G-vec00060-001-s126><indicate.angeben><en> made available to the consumer. If this is not reasonably possible, the trader will indicate, before the distance contract is concluded, in what way the general terms and conditions are available for inspection at the trader’s premises and that they will be sent free of charge to the consumer, as
<G-vec00060-001-s091><specify.angeben><de> Wenn die chinesische Website nicht angegeben wird, welcher die Hersteller Ihre Tablette nicht Kauf sollte.
<G-vec00060-001-s091><specify.angeben><en> If the Chinese site does not specify what the manufacturer of your tablet you should not buy it.
<G-vec00060-001-s092><specify.angeben><de> Sie braucht drei Werte, die auf #t (wahr) oder #f (falsch) gestellt werden können, womit angegeben wird, ob die Taktnummer an der entsprechenden Stelle sichtbar ist.
<G-vec00060-001-s092><specify.angeben><en> This takes three values which may be set to #t or #f to specify whether the corresponding bar number is visible or not.
<G-vec00060-001-s093><specify.angeben><de> Dabei wird der Port mit dem Port-Parameter angeben, und das Konto eines Benutzers mit der Berechtigung zum Herstellen einer Verbindung mit dem Remotecomputer wird mit dem Credential-Parameter angegeben.
<G-vec00060-001-s093><specify.angeben><en> It uses the Port parameter to specify the port and the Credential parameter to specify the account of a user with permission to connect to the remote computer.
<G-vec00060-001-s094><specify.angeben><de> Ihre Registrierung und/oder Verwendung des Benutzerkontos setzt Ihr Verständnis dessen voraus, dass wir auf natürliche Weise die vorhandenen Daten über Ihre Firma (die wir von Ihnen, sowie aus anderen legitimen Quellen erhalten haben) mit den Daten, die von Ihnen im Benutzerkonto angegeben worden sind, vergleichen können.
<G-vec00060-001-s094><specify.angeben><en> When you register and/or use an account it implies your understanding that we can naturally compare the data about your firm that we have (received from you as well as from other legal sources) with the data that you specify in your account.
<G-vec00060-001-s095><specify.angeben><de> Ein Sprecher hat nicht angegeben, welche Art von Portal ist, verklagt zu werden.
<G-vec00060-001-s095><specify.angeben><en> A spokesman did not specify what kind of portal is being sued.
<G-vec00060-001-s096><specify.angeben><de> Sehr viele Kunden von HelloFresh haben dafür einen sicheren Abstellort angegeben (zum Beispiel die hauseigene Garage).
<G-vec00060-001-s096><specify.angeben><en> For this purpose many HelloFresh customers specify a secure place to deposit their food box (for example in the garage).
<G-vec00060-001-s097><specify.angeben><de> Außerdem kann der spezielle Wert default angegeben werden, um die schlichte, hartkodierte Nachricht des Apache zu verwenden.
<G-vec00060-001-s097><specify.angeben><en> Additionally, the special value default can be used to specify Apache's simple hardcoded message.
<G-vec00060-001-s098><specify.angeben><de> Aus diesem Grund muss in einem Broschürenlayout auch die Anzahl der Bogen mit angegeben werden, da diese den zu berücksichtigenden Bundzuwachs beeinflusst.
<G-vec00060-001-s098><specify.angeben><en> Consequently, a book layout must also specify the number of sheets in each saddle because the number of sheets in each saddle affects the amount of creep that needs to be accounted for.
<G-vec00060-001-s099><specify.angeben><de> Wenn ein höherer Verschlüsselungsgrad auf dem Server oder Benutzergerät eingestellt ist, können Einstellungen überschrieben werden, die Sie für veröffentlichte Ressourcen angegeben haben.
<G-vec00060-001-s099><specify.angeben><en> If a higher priority encryption level is set on either a server or user device, settings you specify for published resources can be overridden.
<G-vec00060-001-s100><specify.angeben><de> Durch Hinzufügen eines Index ist der Benutzer in der Lage, durch Auswählen aus einer Liste von Schlüsselwörtern, die Sie angegeben haben, nach Hilfe zu suchen.
<G-vec00060-001-s100><specify.angeben><en> By adding a Index, the user will be able to search for help by selecting from a list of keywords that you specify.
<G-vec00060-001-s101><specify.angeben><de> Das Laufwerk wird mit dem PSDrive-Parameter angegeben.
<G-vec00060-001-s101><specify.angeben><en> It uses the PSDrive parameter to specify the drive.
<G-vec00060-001-s102><specify.angeben><de> Im Falle, dass Sie ein ausländischer Kunde sind, muss das Zielland angegeben werden, da zum Preis die Versandkosten und eventuelle Zollgebühren hinzugefügt werden.
<G-vec00060-001-s102><specify.angeben><en> If you are a foreign customer, you should specify the destination country because the price will be raised by the cost of transportation and any customs charges.
<G-vec00060-001-s103><specify.angeben><de> Achten Sie darauf, dass Sie sowohl beim Einlesen als auch beim Erstellen eines Dumps immer einen einzigen Zeichensatz per SET NAMES angegeben haben.
<G-vec00060-001-s103><specify.angeben><en> Make sure that you always use SET NAMES to specify a single character set both when reading and generating dumps.
<G-vec00060-001-s104><specify.angeben><de> Sie hat nicht angegeben was die genaue fließt der Malware-Entwickler gemacht hatte aber gezeigt, dass die Opfer entschlüsseln über können 70% ihrer gesperrten Dateien selbst.
<G-vec00060-001-s104><specify.angeben><en> They did not specify the exact flows the malware developers had made but revealed that victims can decrypt over 70% of their locked files themselves.
<G-vec00060-001-s105><specify.angeben><de> Falls der Quelllizenzserver im Netzwerk nicht verfügbar ist, muss neben dem Betriebssystem, unter dem der Lizenzserver ausgeführt wird, auch die Lizenzserver-ID für den Quelllizenzserver angegeben werden.
<G-vec00060-001-s105><specify.angeben><en> If the source license server is not available on the network, you need to specify the operating system that the source license server is running and provide the license server ID for the source license server.
<G-vec00060-001-s106><specify.angeben><de> Bei mount_msdosfs (8) können jetzt mit -D die MS-DOS Codepage und mit -L der lokale Zeichensatz angegeben werden, um die Dateinamen umzuwandeln.
<G-vec00060-001-s106><specify.angeben><en> The mount_msdosfs (8) utility now supports a -D option to specify MS-DOS codepages and a -L option to specify local character sets. They are used to convert character sets of filenames.
<G-vec00060-001-s107><specify.angeben><de> Die Skriptinstallation kann IP-, TCP/IP-, LPR- und UNC-Netzwerkanschlüsse erstellen, je nachdem, welchen Protokollwert Sie angegeben haben.
<G-vec00060-001-s107><specify.angeben><en> Script Install can create IP, TCP/IP, LPR, and UNC network ports according to the protocol value you specify.
<G-vec00060-001-s108><specify.angeben><de> Mit dem Name-Parameter wird die Ablaufverfolgungsquelle angegeben, mit dem Option-Parameter werden die ExecutionFlow-Ablaufverfolgungsereignisse ausgewählt, und mit dem PSHost-Parameter wird der Listener des Windows PowerShell-Hosts ausgewählt, der die Ausgabe an die Konsole sendet.
<G-vec00060-001-s108><specify.angeben><en> It uses the Name parameter to specify the trace source, the Option parameter to select the ExecutionFlow trace events, and the PSHost parameter to select the Windows PowerShell host listener, which sends the output to the console.
<G-vec00060-001-s109><specify.angeben><de> Falls für einige Eingabekanäle nichts angegeben ist, wird 0 angenommen.
<G-vec00060-001-s109><specify.angeben><en> If you do not specify any numbers for some input channels, 0 is assumed.
<G-vec00060-001-s110><specify.angeben><de> Bei mountd (8) kann mit der neuen Option -p ein fester Port angegeben werden, der dann im Regelsatz einer Firewall genutzt werden kann.
<G-vec00060-001-s110><specify.angeben><en> mountd (8) now supports the -p option, which allows users to specify a known port for use in firewall rulesets.
<G-vec00060-001-s111><specify.angeben><de> Dies öffnet den Dialog in dem die vollständige Adresse angegeben werden kann.
<G-vec00060-001-s111><specify.angeben><en> This will open the Location Dialog where you can specify the full address.
<G-vec00060-001-s112><specify.angeben><de> Für alle Abschätzung können feste Modellparameter oder Grenzwerte für freie Parameter angegeben werden.
<G-vec00060-001-s112><specify.angeben><en> For all estimations, you can designate fixed model parameters and specify bounds for free parameters.
<G-vec00060-001-s113><specify.angeben><de> Über diese Option unter 'Optionen > Verzeichnisse' kann ein Verzeichnis für Album-Cover angegeben werden, das beim Hinzufügen von Album-Covern angezeigt wird.
<G-vec00060-001-s113><specify.angeben><en> With this option located at 'Options > Directories' you can specify a default directory that is displayed when adding cover art.
<G-vec00060-001-s114><specify.angeben><de> Bei einer Verbindung zwischen zwei NT Rechnern muss diese Nummer nicht einmal angegeben werden.
<G-vec00060-001-s114><specify.angeben><en> If you connect two NT machines you don't even have to specify this number.
<G-vec00060-001-s115><specify.angeben><de> Optional kann angegeben werden, nach welchem Kapitel mit dem Abspielen aufgehört werden soll (Standard: 1).
<G-vec00060-001-s115><specify.angeben><en> Specify which chapter to start playing at. Optionally specify which chapter to end playing at (default: 1).
<G-vec00060-001-s116><specify.angeben><de> Hinzufügen: Öffnet das Dialogfeld Hinzufügen eines Skripts, in dem zusätzlich zu verwendende Skripts angegeben werden können.
<G-vec00060-001-s116><specify.angeben><en> Add: Opens the Add a Script dialog box, where you can specify any additional scripts to use.
<G-vec00060-001-s117><specify.angeben><de> Relative Pfadnamen können mit Sonderzeichen angegeben werden.
<G-vec00060-001-s117><specify.angeben><en> You can specify relative path names by using special characters.
<G-vec00060-001-s118><specify.angeben><de> Für den Index oder Primärschlüssel können nicht mehr als %1 Spaltennamen angegeben werden (%2 Spalten wurden angegeben).
<G-vec00060-001-s118><specify.angeben><en> Cannot specify more than %1 column names for index or primary key (%2 columns specified)
<G-vec00060-001-s119><specify.angeben><de> Darüber hinaus können Adressen angegeben werden, die nicht geprüft werden sollen.
<G-vec00060-001-s119><specify.angeben><en> Furthermore, it allows user to specify addresses, which should be excluded from checking.
<G-vec00060-001-s120><specify.angeben><de> Standardmäßig muss kein Benutzername und Passwort angegeben werden, da der integrierte HTTP-Server keine Authentifizierung erfordert.
<G-vec00060-001-s120><specify.angeben><en> By default, there is no need to specify a username or password, because the integrated HTTP server requires no authentication.
<G-vec00060-001-s121><specify.angeben><de> Bei ftpd (8) kann jetzt mit der neuen Option -P angegeben werden, auf welchem Port eingehende Verbindungen erwartet werden sollen.
<G-vec00060-001-s121><specify.angeben><en> ftpd (8) now supports a -P option to specify a port on which to listen in daemon mode.
<G-vec00060-001-s122><specify.angeben><de> Die Verzeichnisse können relativ oder absolut angegeben werden.
<G-vec00060-001-s122><specify.angeben><en> You can specify the directories in a relative or absolute way.
<G-vec00060-001-s123><specify.angeben><de> Hier kann nur eine Gruppe angegeben werden.
<G-vec00060-001-s123><specify.angeben><en> You may only specify a single group here.
<G-vec00060-001-s124><specify.angeben><de> Als Benutzername muss SYSDBA oder der Eigner angegeben werden.
<G-vec00060-001-s124><specify.angeben><en> Only the SYSDBA or the database owner may specify the sweep interval.
<G-vec00060-001-s125><specify.angeben><de> Wenn das LCD-Modul nicht in ein Unterverzeichnis von /lib/modules (siehe oben) kopiert wurde, muss der gesamte Pfad zum Modul angegeben werden.
<G-vec00060-001-s125><specify.angeben><en> If you did not copy the LCD module into a subdirectory of /lib/modules (see above) you would have to specify the full path instead.
<G-vec00060-001-s126><specify.angeben><de> Bei watch (8) kann das verwendete snp (4) Gerät jetzt mit der Option -f angegeben werden.
<G-vec00060-001-s126><specify.angeben><en> watch (8) now takes a -f option to specify a snp (4) device to use.
<G-vec00060-001-s127><specify.angeben><de> Beim Erstellen einer Shell auf einem Computer können die zu verwendenden Anmeldeinformationen vom Clientcomputer angegeben werden.
<G-vec00060-001-s127><specify.angeben><en> The client computer can specify the credentials to use when creating a shell on a computer.
<G-vec00060-001-s128><specify.angeben><de> Lösungsmethoden Evolver arbeitet mit sechs verschiedenen Lösungsmethoden, die angegeben werden können, um die optimale Kombination von anpassbaren Zellen zu finden.
<G-vec00060-001-s128><specify.angeben><en> Solving Methods Evolver uses six different solving methods that you can specify to find the optimal combination of adjustable cells.
<G-vec00060-001-s129><specify.angeben><de> So werden beispielsweise die von Ihnen in einem Kontakt-Formular getätigten Eingaben an einen internen Ansprechpartner weitergeleitet, bei der „Weiterempfehlen“-Funktion eine E-Mail unter Mitteilung Ihrer E-Mail-Adresse an den von Ihnen benannten Empfänger geschickt, beim Bestellen von Dokumenten das Dokument an die von Ihnen angegebene Adresse versandt.
<G-vec00060-001-s129><specify.angeben><en> For example, the entries you make in a contact form are forwarded to an internal contact person; when you use the “Recommend” function, an email including your email address is sent to the recipient nominated by you; when ordering documents (e.g. manuals), the document is sent to the address you specify.
<G-vec00060-001-s130><specify.angeben><de> Es zeigt Dir die Organic Keywords, für die Deine Konkurrenz rankt, und verrät Dir auch das Ads-Keyword für jede angegebene Seite.
<G-vec00060-001-s130><specify.angeben><en> It shows you the organic keywords that your competitors are ranking for and also reveals the ads keyword for any site that you specify.
<G-vec00060-001-s131><specify.angeben><de> PowerShell: Ändert die Systemzeit auf dem Computer in die von Ihnen angegebene Zeit.
<G-vec00060-001-s131><specify.angeben><en> PowerShell: Changes the system time on the computer to a time that you specify.
<G-vec00060-001-s132><specify.angeben><de> Dies entspricht der folgenden Option auf der Windows-Benutzeroberfläche: Nur von Benutzern angegebene Dateien und Programme sind offline verfügbar.
<G-vec00060-001-s132><specify.angeben><en> Corresponds to the following option in the Windows interface: Only the files and programs that users specify are available offline.
<G-vec00060-001-s133><specify.angeben><de> Notieren Sie sich das angegebene Attribut.
<G-vec00060-001-s133><specify.angeben><en> Make a note of the attribute that you specify.
<G-vec00060-001-s134><specify.angeben><de> "Also, ""Alle Stufen"" muss nur dann gewählt werden, wenn Sie zusätzliche Begrenzungen haben, in den URL-Filtern, zum Beispiel, begrenzen Sie das Herunterladen auf ""Starthost"", in diesem Fall wird die ganze angegebene Website heruntergeladen."
<G-vec00060-001-s134><specify.angeben><en> "Thus, ""All levels"" should be selected only when you have specified restrictions in the URL filters, for example, limit downloading to the ""Start host"", in this case the entire website you specify will be downloaded"
<G-vec00060-001-s135><specify.angeben><de> Die von Ihnen angegebene Position wird auf alle Register im Auftrag angewendet.
<G-vec00060-001-s135><specify.angeben><en> The position you specify applies to all the tabs in the job.
<G-vec00060-001-s136><specify.angeben><de> npm install module_name Es ist egal, welches Betriebssystem Sie haben; Der obige Befehl installiert das von Ihnen angegebene Modul anstelle von module_name .
<G-vec00060-001-s136><specify.angeben><en> npm install module_name It doesn't matter what OS you have; the above command will install the module you specify in place of module_name .
<G-vec00060-001-s137><specify.angeben><de> Professional Rezeption leitet die eingehenden Anruf oder Mail an die von Ihnen angegebene Adresse, ohne Einmischung oder charakteristische komutatornyh Signale lesen und präzise Antwort auf eine Anfrage oder Nachfrage, die zuvor von Ihrem Anweisungen empfangen werden, machen einen Bericht über die Termine und die Art der eingehenden Nachrichten an Sie gerichtet.
<G-vec00060-001-s137><specify.angeben><en> Professional receptionist forwards the incoming call or mail to the address you specify, without any interference or characteristic komutatornyh signals will be literate and accurate response to a request or demand, previously received from your instructions, make a report on the dates and nature of incoming messages addressed to you.
<G-vec00060-001-s138><specify.angeben><de> Hinweis: Die von Ihnen angegebene Konto für die Rückzahlung muss gleich das Konto, dessen Zahlung an Lucky Buddha tat.
<G-vec00060-001-s138><specify.angeben><en> Note: the account you specify for the repayment must be equal to the account whose payment to Lucky Buddha did.
<G-vec00060-001-s139><specify.angeben><de> Dem SOLID L, kann man immer vertrauen, dass die genaue angegebene Menge an Material über den genauen Teil der Straße verteilt werden.
<G-vec00060-001-s139><specify.angeben><en> With SOLID L, you can always rely that the exact amount of material will be spread on the exact part of the road you specify.
<G-vec00060-001-s140><specify.angeben><de> Für die angegebene Uhrzeit wird die Ortszeit auf dem Webserver verwendet.
<G-vec00060-001-s140><specify.angeben><en> The time that you specify uses the local time on the Web server.
<G-vec00060-001-s141><specify.angeben><de> Die Software enthält eine verschlüsselte Datei, die – je nach gewählter Lizenz – entweder an eine von Ihnen angegebene Domain oder IP Adresse gebunden wird.
<G-vec00060-001-s141><specify.angeben><en> The Software holds an encrypted file which will be locked to a Domain name respectively an IP address you specify.
<G-vec00060-001-s142><specify.angeben><de> Hinweis: Die angegebene Größe muss exakt mit der tatsächlichen Größe des eingelegten Mediums/Papiers übereinstimmen.
<G-vec00060-001-s142><specify.angeben><en> Note: The size you specify must match the actual paper size.
<G-vec00060-001-s143><specify.angeben><de> Von Ihnen angegebene Programme oder Skripts sollten ohne Benutzereingabe auskommen.
<G-vec00060-001-s143><specify.angeben><en> Programs or scripts that you specify should not require user input.
<G-vec00060-001-s144><specify.angeben><de> Wenn für einen Upload die Standardeinstellung von 12 Stunden oder der für die Einstellung Überprüfung auf nicht abgeschlossene Aufträge alle angegebene Wert überschritten ist, wird der Upload vom BITS-Server automatisch abgebrochen, und unvollständige Dateiinhalte werden gelöscht.
<G-vec00060-001-s144><specify.angeben><en> BITS Server checks for and deletes incomplete upload jobs that have timed out. If an upload exceeds the default setting of 12 hours, or the value you specify in the Scan for incomplete jobs every setting, BITS Server automatically cancels the upload and deletes any partial file contents.
<G-vec00060-001-s145><specify.angeben><de> Wenn Sie nicht auf die sekundäre Administrator-E-Mail-Adresse zugreifen können, können Sie Ihre Domain-Inhaberschaft bestätigen und die Anweisungen zum Zurücksetzen an eine andere von Ihnen angegebene E-Mail-Adresse senden lassen.
<G-vec00060-001-s145><specify.angeben><en> If you don't have access to the secondary administrator email address, you can verify your domain ownership and have the reset instructions sent to another email address that you specify.
<G-vec00060-001-s146><specify.angeben><de> SUBSTRING Dieser Operator wählt Dokumente, indem die angegebene Abfragezeichenfolge mit einem beliebigen Teil der Zeichenfolge in einem bestimmten Dokumentfeld verglichen wird.
<G-vec00060-001-s146><specify.angeben><en> Selects documents by matching the query string that you specify with any portion of the strings in a specific document field.
<G-vec00060-001-s147><specify.angeben><de> Sendet alle Fehler, die vom Prozess generiert werden, in eine von Ihnen angegebene Datei.
<G-vec00060-001-s147><specify.angeben><en> Sends any errors generated by the process to a file that you specify.
<G-vec00060-001-s148><specify.angeben><de> Anders als der format-Filter erlaubt dieser jeden Farbraum auÃÂer dem von dir angegebenen.
<G-vec00060-001-s148><specify.angeben><en> Unlike the format filter, this will allow any colorspace except the one you specify.
<G-vec00060-001-s149><specify.angeben><de> Die von Ihnen angegebenen Daten werden nur für diesen Zweck verwendet.
<G-vec00060-001-s149><specify.angeben><en> The data you specify is used only for this purpose.
<G-vec00060-001-s150><specify.angeben><de> Beim Workflow „ Endgröße = Auf Basis des Maskenrahmens “ bewirken Sie durch das Aktivieren der Option „ Randanschnitt “, dass die Schnittmarken um einen von Ihnen angegebenen Wert in den Bereich des gedruckten Seiteninhalts hinein verschoben werden, sodass der gedruckte Inhalt nach dem Schneiden bis unmittelbar an die Blattkante heranreicht.
<G-vec00060-001-s150><specify.angeben><en> For the Crop Box finish size workflow, the Bleeds option moves the trim marks into the image by the amount you specify to ensure that the printed area extends beyond the edge of the trimmed sheet.
<G-vec00060-001-s151><specify.angeben><de> ACCRUE Dieser Operator wählt Dokumente, die mindestens eines der angegebenen Suchelemente enthalten.
<G-vec00060-001-s151><specify.angeben><en> Selects documents that include at least one of the search elements that you specify.
<G-vec00060-001-s152><specify.angeben><de> Der SiteRemote 3 Client (oder höher) richtet mit Hilfe der hier angegebenen Verbindungsdaten eine permanente Verbindung ein, die erst wieder beim Herunterfahren des Rechners abgebaut wird.
<G-vec00060-001-s152><specify.angeben><en> SiteRemote 3 Client (or higher) uses the connection data you specify here to set up a permanent connection which will not be disconnected until the computer is shut down.
<G-vec00060-001-s153><specify.angeben><de> Während des Discoveryvorgangs kontaktieren die Cloud Connectors den Citrix XenApp Remoting Service auf dem von Ihnen angegebenen XenApp-Server.
<G-vec00060-001-s153><specify.angeben><en> During the discovery process, the Cloud Connectors contact the Citrix XenApp Remoting Service on the XenApp server you specify.
<G-vec00060-001-s154><specify.angeben><de> Die RAR-Dateien werden jetzt in dem von Ihnen angegebenen Ordner gespeichert.
<G-vec00060-001-s154><specify.angeben><en> The RAR files will now save to the folder that you specify.
<G-vec00060-001-s155><specify.angeben><de> Jede gespeicherte Abfrage besteht aus den ausgewählten Abfragekriterien sowie den angegebenen angepassten Sortier- und Spalteninformationen.
<G-vec00060-001-s155><specify.angeben><en> Each saved query consists of the query criteria that you select, as well as the customized sorting and column information that you specify.
<G-vec00060-001-s156><specify.angeben><de> Dieser Operator wählt Dokumente, die alle angegebenen Suchelemente enthalten.
<G-vec00060-001-s156><specify.angeben><en> Selects documents that contain all the search elements that you specify.
<G-vec00060-001-s157><specify.angeben><de> 4 Klicken OK um es zu schließen und zu dem von Ihnen angegebenen Verzeichnis zu gehen, um die exportierten Bilder anzuzeigen.
<G-vec00060-001-s157><specify.angeben><en> 4. Click OK to close it, and go to the directory you specify to view the exported pictures.
<G-vec00060-001-s158><specify.angeben><de> Auf einem Netzwerkrichtlinienserver mit mehreren installierten Netzwerkadaptern können Sie den Netzwerkrichtlinienserver so konfigurieren, dass RADIUS-Datenverkehr nur auf von Ihnen angegebenen Netzwerkadaptern gesendet und empfangen wird.
<G-vec00060-001-s158><specify.angeben><en> On an NPS server that has multiple network adapters installed, you might want to configure NPS to send and receive RADIUS traffic only on the adapters you specify.
<G-vec00060-001-s159><specify.angeben><de> Bei Verwendung des Format-Parameters ruft Windows PowerShell nur die Eigenschaften des DateTime-Objekts ab, die zum Anzeigen des Datums in dem von Ihnen angegebenen Format erforderlich sind.
<G-vec00060-001-s159><specify.angeben><en> When you use the Format parameter, Windows PowerShell retrieves only the properties of the DateTime object that it needs to display the date in the format that you specify.
<G-vec00060-001-s160><specify.angeben><de> 3.2 Die Einhaltung der von uns angegebenen Lieferzeit setzt die Abklärung aller technischer Fragen sowie die rechtzeitige und ordnungsgemäße Erfüllung der Verpflichtungen des Bestellers voraus.
<G-vec00060-001-s160><specify.angeben><en> 3.2 Compliance with the delivery time we specify shall require clarification of all technical issues and the Customer‘s due and proper satisfaction of obligations.
<G-vec00060-001-s161><specify.angeben><de> Konfigurieren Sie beispielsweise bei Verwendung von AWS Regeln für die VPC-Sicherheitsgruppe, sodass Maschinen in der VPC nur den von Ihnen angegebenen IP-Adressen zugänglich sind.
<G-vec00060-001-s161><specify.angeben><en> For example, when using AWS, ensure the VPC's security group has the appropriate rules configured so that machines in the VPC are accessible only to the IP addresses you specify
<G-vec00060-001-s162><specify.angeben><de> Die neue Medien-API-Methode find_modified_videos gibt Videos zurück, die während eines angegebenen Zeitraums geändert wurden.
<G-vec00060-001-s162><specify.angeben><en> A new Media API method, find_modified_videos, returns videos that have been modified during the time span you specify.
<G-vec00060-001-s163><specify.angeben><de> Bei Verwendung des UFormat-Parameters ruft Windows PowerShell nur die Eigenschaften des DateTime-Objekts ab, die zum Anzeigen des Datums in dem von Ihnen angegebenen Format erforderlich sind.
<G-vec00060-001-s163><specify.angeben><en> When you use the UFormat parameter, Windows PowerShell retrieves only the properties of the DateTime object that it needs to display the date in the format that you specify.
<G-vec00060-001-s164><specify.angeben><de> Teillieferungen sind innerhalb der von uns angegebenen Lieferfristen zulässig, soweit sich Nachteile für den Gebrauch daraus nicht ergeben.
<G-vec00060-001-s164><specify.angeben><en> Partial deliveries are permissible within the delivery periods we specify providing these do not result in disadvantages for use.
<G-vec00060-001-s165><specify.angeben><de> Mit dem Dialogfeld Zertifikate suchen können Sie basierend auf von Ihnen angegebenen Kriterien nach Zertifikaten suchen.
<G-vec00060-001-s165><specify.angeben><en> The Find Certificates dialog box allows you to locate certificates based on criteria that you specify.
<G-vec00060-001-s166><specify.angeben><de> Wenn Sie diese Einstellung aktivieren, werden die in dieser Einstellung angegebenen Befehle von Windows blockiert und nicht an das TPM im Computer geleitet.
<G-vec00060-001-s166><specify.angeben><en> If you enable this policy setting, Windows will block the commands you specify in this setting from being sent to the TPM on the computer.
<G-vec00060-001-s084><declare.angeben><de> Dynamische Variablen: Sie können dieses Menü verwenden, um den Typ der dynamischen Variablen anzugeben (siehe Dynamische Variablen).
<G-vec00060-001-s084><declare.angeben><en> Dynamic variables: you can use this menu to declare the type of dynamic variables (see Dynamic variables).
<G-vec00060-001-s085><declare.angeben><de> Es ist somit nicht mehr obligatorisch anzugeben, welches Pferd in welcher Prüfung geht.
<G-vec00060-001-s085><declare.angeben><en> It is no longer compulsory to declare which horse starts in which phase of the competition.
<G-vec00060-001-s086><declare.angeben><de> Sie sind jedoch verpflichtet, diese Mieteinnahme bei Ihrer Steuererklärung anzugeben.
<G-vec00060-001-s086><declare.angeben><en> You are however, obligated to declare the revenue from renting the home on your tax return.
<G-vec00060-001-s087><declare.angeben><de> Aber der stellvertretende Vorsitzende versäumte diesen Interessenkonflikt in der obligatorischen jährlichen Offenlegungserklärung anzugeben.
<G-vec00060-001-s087><declare.angeben><en> But the vice-chair also does not declare this interest in the mandatory annual disclosure statement.
<G-vec00060-001-s088><declare.angeben><de> Unter bestimmten Umständen ist es durchaus sinnvoll, den Vertragsnamen direkt anzugeben.
<G-vec00060-001-s088><declare.angeben><en> It makes sense to declare contract name directly under certain circumstances.
<G-vec00060-001-s089><declare.angeben><de> ME Wenn solche Werke, ob in privatem oder in öffentlichem Besitz, öffentlich in Museen ausgestellt werden, sollte die jeweilige Institution unmittelbar verpflichtet sein, die Herkunft der Werke anzugeben.
<G-vec00060-001-s089><declare.angeben><en> ME Whether privately or publicly owned, when such works go on public display in museums, the respective institution should be immediately obliged to declare the work's origins.
<G-vec00078-001-s084><declare.angeben><de> Dynamische Variablen: Sie können dieses Menü verwenden, um den Typ der dynamischen Variablen anzugeben (siehe Dynamische Variablen).
<G-vec00078-001-s084><declare.angeben><en> Dynamic variables: you can use this menu to declare the type of dynamic variables (see Dynamic variables).
<G-vec00078-001-s085><declare.angeben><de> Es ist somit nicht mehr obligatorisch anzugeben, welches Pferd in welcher Prüfung geht.
<G-vec00078-001-s085><declare.angeben><en> It is no longer compulsory to declare which horse starts in which phase of the competition.
<G-vec00078-001-s086><declare.angeben><de> Sie sind jedoch verpflichtet, diese Mieteinnahme bei Ihrer Steuererklärung anzugeben.
<G-vec00078-001-s086><declare.angeben><en> You are however, obligated to declare the revenue from renting the home on your tax return.
<G-vec00078-001-s087><declare.angeben><de> Aber der stellvertretende Vorsitzende versäumte diesen Interessenkonflikt in der obligatorischen jährlichen Offenlegungserklärung anzugeben.
<G-vec00078-001-s087><declare.angeben><en> But the vice-chair also does not declare this interest in the mandatory annual disclosure statement.
<G-vec00078-001-s088><declare.angeben><de> Unter bestimmten Umständen ist es durchaus sinnvoll, den Vertragsnamen direkt anzugeben.
<G-vec00078-001-s088><declare.angeben><en> It makes sense to declare contract name directly under certain circumstances.
<G-vec00078-001-s089><declare.angeben><de> ME Wenn solche Werke, ob in privatem oder in öffentlichem Besitz, öffentlich in Museen ausgestellt werden, sollte die jeweilige Institution unmittelbar verpflichtet sein, die Herkunft der Werke anzugeben.
<G-vec00078-001-s089><declare.angeben><en> ME Whether privately or publicly owned, when such works go on public display in museums, the respective institution should be immediately obliged to declare the work's origins.
<G-vec00060-001-s219><indicate.angeben><de> In diesem Fall hat er zusätzlich Namen und Anschrift des Vertretenen anzugeben.
<G-vec00060-001-s219><indicate.angeben><en> In this case, he must also indicate the name and address of the party he is representing.
<G-vec00060-001-s220><indicate.angeben><de> Artikel 8- Personen und Organisationen haben bei der Antragstellung im Gouvernement zur Einholung einer Erlaubnis für private Sicherheitsdienstleistung anzugeben, wie dieser Dienst ausgeführt wird, wie viel Personal eingestellt wird, welche Waffen in welcher Anzahl benötigt werden.
<G-vec00060-001-s220><indicate.angeben><en> Article 8- At their application to be made to the governorship for private security permit, the persons and institutions shall indicate the subject of the private security service, the method of performance of the private security, with maximum how many personnel will be used to perform the service, the amount and nature of the required weapons and equipment if any.
<G-vec00060-001-s221><indicate.angeben><de> Wann immer Sie gefragt werden ein Formular auf dieser Webseite auszufüllen, halten Sie ausschau nach einem Kästchen, das Sie anklicken können, um anzugeben, dass Sie nicht möchten, dass die Daten von jemanden zu Werbezwecken genutzt werden sollen.
<G-vec00060-001-s221><indicate.angeben><en> whenever you are asked to fill in a form on the website, look for the box that you can click to indicate that you do not want the information to be used by anybody for direct marketing purposes
<G-vec00060-001-s222><indicate.angeben><de> Um von diesem Angebot zu profitieren, vergessen Sie nicht, den folgenden Verweis, bei der Bestellung, anzugeben: Dept M.
<G-vec00060-001-s222><indicate.angeben><en> To take advantage of this offer please indicate the following reference: Dept M.
<G-vec00060-001-s223><indicate.angeben><de> In dem vom Bittsteller zu unterfertigenden Dispensgesuch sind außer Namen und allgemeinen Lebensdaten auch zumindest in Umrissen die Tatsachen und Argumente anzugeben, auf die der Bittsteller sein Ansuchen stützt.
<G-vec00060-001-s223><indicate.angeben><en> The signed petition must indicate the petitioner’s name, general information about him and at least in general the facts and arguments on which his petition is based.
<G-vec00060-001-s224><indicate.angeben><de> Der Hersteller hat die Betriebsbedingungen der Maschine während des Meßvorgangs sowie die angewendeten Meßverfahren anzugeben.
<G-vec00060-001-s224><indicate.angeben><en> The manufacturer must indicate the operating conditions of the machinery during measurement and which methods were used for taking the measurements;
<G-vec00060-001-s225><indicate.angeben><de> Beides gleichzeitig anzugeben macht ja keinen Sinn.
<G-vec00060-001-s225><indicate.angeben><en> Both to indicate at the same time makes no sense.
<G-vec00060-001-s226><indicate.angeben><de> Liegen die Voraussetzungen für die Inanspruchnahme einer Priorität vor und will der Anmelder die Priorität beanspru-chen, so ist in dem vorgesehenen Feld anzugeben, aus welcher Voranmeldung oder Schaustellung des Gegenstandes die beanspruchte Priorität hergeleitet wird.
<G-vec00060-001-s226><indicate.angeben><en> If the requirements for claiming priority are met, and if the applicant wishes to claim priority, he shall indicate in the appropriate box on which earlier application or exhibition the priority is based.
<G-vec00060-001-s227><indicate.angeben><de> Es ist Möglich anzugeben, dass das Lade-Bild transparent sein soll.
<G-vec00060-001-s227><indicate.angeben><en> It is possible to indicate that the loading image must be transparent.
<G-vec00060-001-s228><indicate.angeben><de> Dafür hat sie eine eigene Lehre, ein Lehrgebäude aufgestellt, das es ihr ermöglicht, die soziale Wirklichkeit zu analysieren, sie zu beurteilen und Richtlinien für eine gerechte Lösung der daraus entstehenden Probleme anzugeben.
<G-vec00060-001-s228><indicate.angeben><en> She formulates a genuine doctrine for these situations, a corpus which enables her to analyze social realities, to make judgments about them and to indicate directions to be taken for the just resolution of the problems involved.
<G-vec00060-001-s229><indicate.angeben><de> Geschützte Trennstriche werden in Wortzusammensetzungen verwendet, um anzugeben, dass beide Wörter zusammen mit dem Trennstrich als ein einziges Wort behandelt werden sollen, wenn der Text-Editor eine Trennung vornehmen möchte.
<G-vec00060-001-s229><indicate.angeben><en> Non-breaking hyphens are used in compound words to indicate that both words and the hyphen should be treated as a single word when the text editor is forming lines.
<G-vec00060-001-s230><indicate.angeben><de> Auf einigen IKRK-Formularen, zum Beispiel beim Formular für Online-Spenden, werden Sie aufgefordert anzugeben, ob Sie Informationen über das IKRK per E-Mail erhalten möchten.
<G-vec00060-001-s230><indicate.angeben><en> On some ICRC forms, such as that for online donations, you are invited to indicate whether you are interested in receiving information via e-mail about the ICRC.
<G-vec00060-001-s231><indicate.angeben><de> Manche Leute vergessen beim Kreditantrag beispielsweise die Einnahmen ihres Nebenjobs anzugeben.
<G-vec00060-001-s231><indicate.angeben><en> Some people forget to indicate at the loan application, e.g. the income of their part-time job .
<G-vec00060-001-s232><indicate.angeben><de> DE 0031: Dieses Datenelement wird benutzt, um anzugeben, ob eine Bestätigung gefordert wird.
<G-vec00060-001-s232><indicate.angeben><en> DE 0031: This data element is used to indicate whether an acknowledgement to the interchange is required or not.
<G-vec00060-001-s233><indicate.angeben><de> Bei Verwendung anderer Maßeinheiten in Abbildungen und Tabellen sind die Umrechnungsfaktoren in der Legende anzugeben.
<G-vec00060-001-s233><indicate.angeben><en> If other units of measure are used in figures and tables, please indicate the conversion factors in the legend.
<G-vec00060-001-s234><indicate.angeben><de> """Wir haben zudem in neue Schallpegelmessgeräte investiert, welche es uns ermöglichen, den Geräuschpegel unserer Ventilatoren anzugeben, was hinsichtlich der Umweltverträglichkeit immer öfter erforderlich ist."
<G-vec00060-001-s234><indicate.angeben><en> """We have also invested in new sound level measuring equipment that now allows us to indicate the noise level of our fans, which is an increasing requirement in relation to environmental compatibility."
<G-vec00060-001-s235><indicate.angeben><de> Obwohl wir unsere Kunden normalerweise nicht anrufen, bitten wir Sie, Ihre korrekte Telefonnummer anzugeben, damit Ihre Bestellung von Address Verification System nicht abgelehnt wird.
<G-vec00060-001-s235><indicate.angeben><en> Though we do not call to our clients generally, we ask you to indicate your correct telephone number for the Address Verification System not to cancel your order.
<G-vec00060-001-s236><indicate.angeben><de> Die Eingabeaufforderung wird auch geändert, um anzugeben, dass die Steuerung beim Debugger liegt.
<G-vec00060-001-s236><indicate.angeben><en> The command prompt also changes to indicate that the debugger has control.
<G-vec00060-001-s237><indicate.angeben><de> Um ein Ziel anzugeben.
<G-vec00060-001-s237><indicate.angeben><en> to indicate destination
<G-vec00060-001-s167><specify.angeben><de> Auswählen einer Anzeigenquelle, um anzugeben, wohin der Player die Anzeigenanforderungen senden soll.
<G-vec00060-001-s167><specify.angeben><en> Set the Ad Source to specify where the player should send its ad requests.
<G-vec00060-001-s168><specify.angeben><de> Dann in der Fügen Sie Arbeitsmappeninformationen ein Dialog, überprüfen Sie die Informationen, die Sie einfügen möchten aus Abschnitt Informationen, dann gehen Sie, um den Ort anzugeben, die Sie einfügen möchten, können Sie Zellen, Fußzeile (linke Fußzeile, mittlere Fußzeile, rechte Fußzeile) oder Kopfzeile (linke Kopfzeile, zentrale Kopfzeile, rechte Überschrift).
<G-vec00060-001-s168><specify.angeben><en> Then in the Insert Workbook Information dialog, check the information you want to insert from Information section, then go to specify the location you want to insert to, you can choose cells, footer (left footer, centre footer, right footer) or header (left header, centre header, right header).
<G-vec00060-001-s169><specify.angeben><de> Abhängig vom gewählten Zahlungssystem werden Sie möglicherweise aufgefordert, auf der nächsten Seite einige zusätzliche Informationen anzugeben, um einen Auszahlungsantrag stellen zu können.
<G-vec00060-001-s169><specify.angeben><en> After that, there will be the second step of the depositing procedure, where you may be asked to specify some additional information according to the requirements of the chosen payment system.
<G-vec00060-001-s170><specify.angeben><de> Wenn E-Mail-Adresse und externe ID nicht in der Logout-URL übergeben werden sollen, bitten Sie Ihren Zendesk-Administrator, in der Admin-Oberfläche im Feld Remote-Logout-URL leere Parameter anzugeben.
<G-vec00060-001-s170><specify.angeben><en> If you prefer not to receive email and external id information in the sign-out URL, ask your Zendesk admin to specify blank parameters in the Remote logout URL field in the admin interface.
<G-vec00060-001-s171><specify.angeben><de> Klicken Sie hier, um den vollständigen Pfad und den Dateinamen für die Fußzeilendatei zu suchen und anzugeben.
<G-vec00060-001-s171><specify.angeben><en> Click to locate and specify the full path and file name for your footer file.
<G-vec00060-001-s172><specify.angeben><de> 1, 2, 3... geeignete Stelle für medizinische Notfallversorgung vom Hersteller /Lieferanten anzugeben.
<G-vec00060-001-s172><specify.angeben><en> 1, 2, 3 …Manufacturer/supplier to specify the appropriate source of emergency medical advice.
<G-vec00060-001-s173><specify.angeben><de> Das Ziel des Kurses ist es, Ingenieure mit Fähigkeiten, Fertigkeiten und Einstellungen, die an der Lösung der Probleme mit den Produkten, Verfahren und Dienstleistungen verbunden sind, wie zu trainieren: Design, Entwicklung und integrierte Systeme von Menschen, Material, Ausrüstung und Informationen zu verwalten; Verwendung aus erworbenen Kenntnisse Ressourcen und Fähigkeiten in der Grundlagenforschung zusammen mit den Prinzipien und Methoden der technischen Analyse und Design, um anzugeben, vorherzusagen und zu bewerten, um die Ergebnisse aus diesen Systemen erhalten werden.
<G-vec00060-001-s173><specify.angeben><en> The aim of the course is to train engineers with abilities, skills and attitudes appropriate to the solution of problems associated with the products, processes and services, such as: design, develop and manage integrated systems of people, materials, equipment and information; Using up resources acquired from knowledge and skills in basic sciences together with the principles and methods of engineering analysis and design to specify, predict and evaluate the results to be obtained from these systems.
<G-vec00060-001-s174><specify.angeben><de> Verwenden Sie die Option Alle Programme, und wählen Sie dann die Registerkarte Programme und Dienste im Dialogfeld Eigenschaften von Firewallregel aus, um einen Dienst in einer Firewallregel anzugeben.
<G-vec00060-001-s174><specify.angeben><en> To specify a service in a firewall rule, use the All programs option, and then select the Programs and Services tab on the Firewall Rule Properties dialog box.
<G-vec00060-001-s175><specify.angeben><de> Ein findiger Flash Profi hat jedoch Abhilfe geschaffen und das kostenlose Tool „UniLauncher“ programmiert, welches ermöglicht, den absoluten oder relativen Pfad zu einem Dokument innerhalb einer INI-Datei anzugeben und somit die Dokumente in einer eigene Ordnerstruktur unterhalb des CD-Root Ordners abzulegen.
<G-vec00060-001-s175><specify.angeben><en> "Fortunately, an Adobe Flash Professional developer has created a tool called ""UniLauncher"", which allows to specify an absolute or relative path to a document within an INI file and so store the document in an own separate folder structure below the CD root folder."
<G-vec00060-001-s176><specify.angeben><de> Ja Ich begegnete einigen Wesen die mich kannten, und umgekehrt, und ich hatte ein Gefühl dass wie einander seit tausenden von Jahren gekannt hatten, aber ich bin nicht fähig ihre Namen anzugeben.
<G-vec00060-001-s176><specify.angeben><en> Yes I encountered some beings who knew me, and the other way around, and I had a feeling that we had known each other for thousands of years, but I am not able to specify their names.
<G-vec00060-001-s177><specify.angeben><de> Unsere Kunden sind nicht verpflichtet anzugeben, wo die Texte veröffentlicht werden.
<G-vec00060-001-s177><specify.angeben><en> Customers are in no way obliged to specify where texts will be published.
<G-vec00060-001-s178><specify.angeben><de> Anzugeben sind die Arbeitgeber-und Arbeitnehmerbeiträge Namen, das Startdatum des Vertrags, der zu verrichtenden Arbeit und die Vergütung im Gegenzug bezahlt werden.
<G-vec00060-001-s178><specify.angeben><en> It should specify the employer's and employee's names, the start date of the contract, the work to be performed and the remuneration to be paid in return.
<G-vec00060-001-s179><specify.angeben><de> Wählen Sie Netzwerk verwendet ein anderes VLAN zur Authentifizierung mit Computer- und Benutzeranmeldeinformationen aus, um anzugeben, dass Drahtloscomputer beim Start in einem virtuellen LAN (VLAN) platziert werden und dann nach der Anmeldung des Benutzers beim Computer in ein anderes Netzwerk übertragen werden.
<G-vec00060-001-s179><specify.angeben><en> To specify that wireless computers are placed on one virtual local area network (VLAN) at startup, and then transitioned to a different network after the user logs on to the computer, select This network uses different VLAN for authentication with machine and user credentials.
<G-vec00060-001-s180><specify.angeben><de> In der IPv6-Welt ist es aber durchaus üblich, die vollständige IP-Adresse anzugeben und mit /nn anzugeben, wieviele Bits davon zum Präfix des Subnetzes gehören.
<G-vec00060-001-s180><specify.angeben><en> In the IPv6 world, it is but common, to specify the full IP address and / nn to specify, How many bits of them belong to the prefix of the subnet.
<G-vec00060-001-s181><specify.angeben><de> In der IPv6-Welt ist es aber durchaus üblich, die vollständige IP-Adresse anzugeben und mit /nn anzugeben, wieviele Bits davon zum Präfix des Subnetzes gehören.
<G-vec00060-001-s181><specify.angeben><en> In the IPv6 world, it is but common, to specify the full IP address and / nn to specify, How many bits of them belong to the prefix of the subnet.
<G-vec00060-001-s182><specify.angeben><de> Sie können die Schnittstelle Application Cache (AppCache) verwenden, um Ressourcen anzugeben, die der Browser zwischenspeichern und fÃ1⁄4r Offline-Benutzer verfÃ1⁄4gbar machen soll.
<G-vec00060-001-s182><specify.angeben><en> You can use the Application Cache (AppCache) interface to specify resources that the browser should cache and make available to offline users.
<G-vec00060-001-s183><specify.angeben><de> Sie können eine Wochenendnummer auswählen, um anzugeben, welche Wochentage als Wochenenden betrachtet werden, oder dieses Argument ignorieren, um Samstag und Sonntag standardmäßig als Wochenenden zu verwenden.
<G-vec00060-001-s183><specify.angeben><en> You can choose a weekend number to specify which days of the week are considered as weekends, or ignore this argument to take Saturday and Sunday as weekends by default.
<G-vec00060-001-s184><specify.angeben><de> Wenn Sie in einem Hotel außerhalb des angegebenen Bereichs untergebracht sind, senden Sie uns bitte eine E-Mail mit Ihrer Hotel- und Zimmernummer, um sich mit Ihnen in Verbindung zu setzen und den Abholort oder den geeigneten Treffpunkt anzugeben.
<G-vec00060-001-s184><specify.angeben><en> If you are accommodated in a hotel beyond the designated area, please send us an e-mail, with your hotel and room number, to contact you and specify the pick-up place or convenient meeting point.
<G-vec00060-001-s185><specify.angeben><de> Der Grund, warum dieses Anforderung für Latex akzeptabel ist, ist, dass TeX eine Fazilität enthält, die ermöglicht Dateinamen wie Datei ‚Bar‘ verwenden, wenn die Datei ‚Fu‘ angefordert wird anzugeben.
<G-vec00060-001-s185><specify.angeben><en> The reason this requirement is acceptable for LaTeX is that TeX has a facility to allow you to map file names, to specify “use file bar when file foo is requested”.
<G-vec00418-001-s012><brag.angeben><de> Nur wenige Hotels in Dubai können damit angeben, das Burj Al Arab im Hinterhof zu haben.
<G-vec00418-001-s012><brag.angeben><en> Few hotels in Dubai can brag they have the Burj Al Arab in their backyard.
<G-vec00418-001-s013><brag.angeben><de> Er sagte, dass es absurd sei, damit anzugeben, ein großer Yogi-Praktizierender einer bestimmten Buddha-Gestalt zu sein, wenn alles, was man tut oder getan hat, lediglich ein kurzes Retreat dazu mit ein paar hunderttausend Rezitationen der relevanten Mantras ist.
<G-vec00418-001-s013><brag.angeben><en> He said it was absurd to brag about being a great yogi practitioner of a certain Buddha-figure when all one is doing or has done is its short retreat by reciting the relevant mantras a couple hundred thousand times.
<G-vec00060-001-s667><indicate.angeben><de> Bitte geben Sie zudem an, an welchem Tag Sie in den Carolus Thermen waren und in welchem Bereich Sie Ihren Gegenstand vergessen haben.
<G-vec00060-001-s667><indicate.angeben><en> Please also indicate, on which day you visited the Carolus Thermen and in which area you forgot your things.
<G-vec00060-001-s668><indicate.angeben><de> B. in Formularen), geben wir immer an, ob die betreffenden Angaben verpflichtend sind (z.
<G-vec00060-001-s668><indicate.angeben><en> in forms), we will indicate whether the provision of such data is mandatory (e.g.
<G-vec00060-001-s669><indicate.angeben><de> Bitte geben Sie an, ob sie 2 Einzelbetten oder 1 Doppelbett bevorzugen.
<G-vec00060-001-s669><indicate.angeben><en> Guests are kindly asked to indicate whether they prefer 2 single beds or 1 double bed.
<G-vec00060-001-s670><indicate.angeben><de> grau Pflegehinweise: Die angeführten Pflegesymbole geben nicht die empfohlene sondern die maximal zulässige Behandlungsstufe für die jeweiligen Textilien an.
<G-vec00060-001-s670><indicate.angeben><en> Â grey Care Instructions: The care symbols do not indicate the recommended treatment but the maximum permissible level for the respective fabrics.
<G-vec00060-001-s671><indicate.angeben><de> "Die Informationsgesuche geben an, die in den letzten monaten bekommen wir haben, dass das Know-how viel erfordert ist"", das erworben wir haben."
<G-vec00060-001-s671><indicate.angeben><en> "The demands for information that we have received in recent months indicate that the know-how-how that we have acquired is a lot demanded""."
<G-vec00060-001-s672><indicate.angeben><de> marineblau Pflegehinweise: Die angeführten Pflegesymbole geben nicht die empfohlene sondern die maximal zulässige Behandlungsstufe für die jeweiligen Textilien an.
<G-vec00060-001-s672><indicate.angeben><en> Care Instructions: The care symbols do not indicate the recommended treatment but the maximum permissible level for the respective fabrics.
<G-vec00060-001-s673><indicate.angeben><de> Geben Sie im Dialogfeld Controller hinzufügen oder Controller bearbeiten einen Namen ein, über den Sie die Bereitstellung identifizieren können, und geben Sie an, ob die Ressourcen, die Sie im Store verfügbar machen möchten, von XenDesktop, XenApp oder AppController bereitgestellt werden.
<G-vec00060-001-s673><indicate.angeben><en> In the Add Controller or Edit Controller dialog box, specify a name that will help you to identify the deployment and indicate whether the resources that you want to make available in the store are provided by XenDesktop, XenApp, or AppController.
<G-vec00060-001-s674><indicate.angeben><de> Positive Werte geben an, dass die Anfrage erfolgreich war, aber weitere Informationen in res/return_code/@message enthalten sind.
<G-vec00060-001-s674><indicate.angeben><en> Positive values indicate that the request succeeded with additional information, contained in res/return_code/@message as well.
<G-vec00060-001-s675><indicate.angeben><de> Eckige Klammern geben ein impliziertes OR an.
<G-vec00060-001-s675><indicate.angeben><en> Square brackets indicate an implied OR.
<G-vec00060-001-s676><indicate.angeben><de> In der Elektronischen Zeitschriftenbibliothek (EZB) geben gelb/rote Ampeln an, dass nur ein Teil der erschienenen Jahrgänge im Volltext zugänglich sind.
<G-vec00060-001-s676><indicate.angeben><en> In the Electronic Journals Library (EZB), yellow/red lights indicate that only some of the published volumes are accessible as full texts.
<G-vec00060-001-s677><indicate.angeben><de> Wenn Sie lokalen Speicher auf dem Hypervisor wählen, geben Sie an, ob Sie persönliche Daten (persönliche vDisks) im freigegebenen Speicher verwalten möchten.
<G-vec00060-001-s677><indicate.angeben><en> If you choose storage local to the hypervisor, indicate if you want to manage personal data (personal vDisks) on shared storage.
<G-vec00060-001-s678><indicate.angeben><de> Die neuen Akzente in der Außenpolitik, namentlich das Embargo gegen Gaza zu lockern und wieder diplomatische Beziehungen zum Iran aufzunehmen, geben die Bewegungsrichtung an.
<G-vec00060-001-s678><indicate.angeben><en> The first new accents in foreign policy, namely to soften the embargo on Gaza and to resume ties with Tehran, indicate a clear direction.
<G-vec00060-001-s679><indicate.angeben><de> Bitte geben Sie an, ob Sie sich als Teilnehmer*in oder Beobachter*in anmelden möchten.
<G-vec00060-001-s679><indicate.angeben><en> Please indicate whether you would like to register as a participant or observer.
<G-vec00060-001-s680><indicate.angeben><de> Wählen Sie die Farbe aus und geben Sie es in der Observierung des Warenkorbs an.
<G-vec00060-001-s680><indicate.angeben><en> Choose the color and indicate it in the comments of the shopping cart.
<G-vec00060-001-s681><indicate.angeben><de> Weiße Balken geben an, dass der Oregon noch Daten sammelt.
<G-vec00060-001-s681><indicate.angeben><en> White bars indicate that the Oregon is still collecting data.
<G-vec00060-001-s682><indicate.angeben><de> Geben Sie hierzu unter dem Menüpunkt Sources | Add Directory den Namen der Dateien ein und geben Sie an, in welchem Verzeichnis sie sich befinden.
<G-vec00060-001-s682><indicate.angeben><en> Select the menu item: Sources | Add Directory, enter the name of the group of files, and indicate the directory in which the dbx files are located.
<G-vec00060-001-s683><indicate.angeben><de> Kontaktieren Sie uns bitte über den Kundenservice und geben Sie an, was Sie suchen.
<G-vec00060-001-s683><indicate.angeben><en> please contact us via customer service and indicate what you are looking for.
<G-vec00060-001-s684><indicate.angeben><de> Geben Sie diese in dieser Form vor Ihrer Ankunft an.
<G-vec00060-001-s684><indicate.angeben><en> Indicate this in this form before your arrival.
<G-vec00060-001-s685><indicate.angeben><de> Daher geben die Produkte bereits die Größen an, die sie nach dem Waschen erhalten.
<G-vec00060-001-s685><indicate.angeben><en> Therefore, the products already indicate the sizes that they will acquire after washing.
<G-vec00060-001-s481><specify.angeben><de> Hersteller kerzenzentrierter Artikel geben oft den Typ und / oder die Größe der Kerze an, die empfohlen wird.
<G-vec00060-001-s481><specify.angeben><en> Manufacturers of candle-centric items often specify the type and/or size of candle that is recommended.
<G-vec00060-001-s482><specify.angeben><de> Die Dienstleister geben bei der Buchung an, wie viele Paletten sie anliefern.
<G-vec00060-001-s482><specify.angeben><en> When booking, the service providers specify how many pallets they deliver.
<G-vec00060-001-s483><specify.angeben><de> displayWidth Breite_in_Pixeln displayHeight Höhe_in_Pixeln displayGeometry Breite xHöhe geben den rechteckigen Bereich an, in dem die Wiedergabe dargestellt werden soll.
<G-vec00060-001-s483><specify.angeben><en> displayWidth width_in_pixels displayHeight height_in_pixels displayGeometry width xheight specify the rectangular area, in which the playback is displayed.
<G-vec00060-001-s484><specify.angeben><de> Dazu rufen Sie get_comment_meta auf und geben die Kommentar-ID und den MetaschlÃ1⁄4ssel an.
<G-vec00060-001-s484><specify.angeben><en> To do this, you would make a call to get_comment_meta and you'd specify the comment ID and the meta key.
<G-vec00060-001-s485><specify.angeben><de> Über diesen Eintrag geben Sie den Konnektivitäts-Status Ihres Gerätes mit dem Internet an.
<G-vec00060-001-s485><specify.angeben><en> Using this entry, you specify the connectivity status of your device to the Internet.
<G-vec00060-001-s486><specify.angeben><de> Bitte geben Sie Packstück-Nummer an.
<G-vec00060-001-s486><specify.angeben><en> Please specify the serial no.
<G-vec00060-001-s487><specify.angeben><de> VORSICHT: Wenn Sie einen Kreuzschlitzschraubendreher benötigen, geben Sie dies bitte an.
<G-vec00060-001-s487><specify.angeben><en> CAUTION: If you require a Phillips screwdriver, please specify.
<G-vec00060-001-s488><specify.angeben><de> Geben Sie im Dialogfeld Arbeitsblätter kombinieren - Schritt 3 von 3 die Kombinationsregel nach Bedarf an und klicken Sie auf Fertigstellung klicken.
<G-vec00060-001-s488><specify.angeben><en> In the Combine Worksheets - Step 3 of 3 dialog box, please specify the combination rule as you need, and click the Finish button.
<G-vec00060-001-s489><specify.angeben><de> Bitte geben Sie einen Drucker an und klicken Sie auf Drucken Taste.
<G-vec00060-001-s489><specify.angeben><en> Please specify a printer, and click the Print button.
<G-vec00060-001-s490><specify.angeben><de> In diesem Schritt geben Sie an, ob Sie nur externen Benutzerzugriff oder nur internen Benutzerzugriff auf Ihre Site über Citrix Workspace erlauben.
<G-vec00060-001-s490><specify.angeben><en> In this step, you specify whether you want to allow only external user access or internal-only access to your Site through Citrix Workspace.
<G-vec00060-001-s491><specify.angeben><de> Geben Sie beim Drucken einer Kalibrierungsseite für die Nachkalibrierung die Messmethode, das Messfeldlayout und die Papierquelle an.
<G-vec00060-001-s491><specify.angeben><en> When you print a calibration page for recalibration, specify the measurement method, patch set, and paper source.
<G-vec00060-001-s492><specify.angeben><de> Bitte geben Sie in ihrer Bestellung ihre gültige email Adresse an.
<G-vec00060-001-s492><specify.angeben><en> Please specify a valid email address in your order.
<G-vec00060-001-s493><specify.angeben><de> Bitte geben Sie bei Ihrer Buchung Ihre bevorzugte Bettenart an.
<G-vec00060-001-s493><specify.angeben><en> Please specify bed preference when booking.
<G-vec00060-001-s494><specify.angeben><de> Name Bitte geben Sie Ihren vollständigen Namen an.
<G-vec00060-001-s494><specify.angeben><en> Mr. Name Please specify your full name.
<G-vec00060-001-s495><specify.angeben><de> Auf der Editiermaske geben Sie ein oder zwei Ausgangsprodukte und ein oder zwei Endprodukte an.
<G-vec00060-001-s495><specify.angeben><en> On the edit mask you specify one or two source products and one or two end products.
<G-vec00060-001-s496><specify.angeben><de> "%%vskip 12pt %%text Im Gegensatz zu Quelle a), geben die Quellen b) und c) auch unzweideutig die Akzidentien %%text (""musica ficta"") an."
<G-vec00060-001-s496><specify.angeben><en> "%%vskip 12pt %%text In contrast to source a), the sources b) and c) also specify uniquely the accidentals (""musica ficta"")."
<G-vec00060-001-s497><specify.angeben><de> Als digitale Signatur verwenden: Geben Sie an, ob das Zertifikat als digitale Signatur verwendet werden soll.
<G-vec00060-001-s497><specify.angeben><en> Use as digital signature: Specify whether you want the certificate to be used as a digital signature.
<G-vec00060-001-s498><specify.angeben><de> Routing-Tag: Geben Sie hier das Routing-Tag des Netzes an, zu dem die Loopback-Adresse gehört.
<G-vec00060-001-s498><specify.angeben><en> Routing tag: Here you specify the routing tag of the network that the loopback address belongs to.
<G-vec00060-001-s499><specify.angeben><de> Diese Werte geben an, ob CredSSP als Client oder als Server deaktiviert werden soll.
<G-vec00060-001-s499><specify.angeben><en> These values specify whether CredSSP should be disabled as a client or as a server.
<G-vec00060-001-s703><indicate.angeben><de> Gut zu wissen: Der Hersteller gibt auf der Verpackung eventuell noch die gerundeten Maße an.
<G-vec00060-001-s703><indicate.angeben><en> Good to know: The manufacturer may also indicate the rounded dimensions on the packaging.
<G-vec00060-001-s704><indicate.angeben><de> Die Kommission setzt eine angemessene Frist, bis zu deren Ablauf der/die Zulassungsinhaber weitere Informationen vorlegen kann/können, die für eine Überprüfung erforderlich sind, und sie gibt an, bis wann sie eine Entscheidung nach Artikel 64 treffen wird.
<G-vec00060-001-s704><indicate.angeben><en> The Commission shall set a reasonable deadline by which the holder(s) of the authorisation may submit further information necessary for the review and indicate by when it will take a decision in accordance with Article 64.
<G-vec00060-001-s705><indicate.angeben><de> "Nicht genug,- hat das Professor Senn erklärt,- weil die Achtung auf dem Übergang von den Waren von der Straße zu der Eisenbahn gibt die sehr wichtige soziale und umwelt- Ersparnis an: die minori Kosten von den Zwischenfällen und dem Stau von dem Verkehr assommano zu 600 Millionen Euro, jen für die Luftverschmutzung und die Emissionen von CO2 von ungefähr 300 Millionen Euro,""."
<G-vec00060-001-s705><indicate.angeben><en> "Not enough - it has explained professor Senn - because the esteem on the passage of the goods from the road to the railroad indicate important social and environmental savings a lot: the smaller costs from incidents and congestion of the traffic emerge to 600 million euros, those for the air pollution and the emissions of co2 of approximately 300 million euros""."
<G-vec00060-001-s706><indicate.angeben><de> Der Wert 'Kurve' gibt an, wie sehr der Himmel gekrümmt sein soll (kann entweder positiv oder negativ sein).
<G-vec00060-001-s706><indicate.angeben><en> The curve value indicate how much the sky should be curved (can be either negative or positive).
<G-vec00060-001-s707><indicate.angeben><de> Wenn aktiviert, gibt der Chronographen -12-Stunden-Zähler 1/10 Sekunden bis zu 30 Minuten an, bei 6 Stunden ist der 30-Minuten-Zähler und das 9-Stunden-Zifferblatt bis zu 10 Stunden.
<G-vec00060-001-s707><indicate.angeben><en> When activated, the chronograph 12-hour counter indicate 1/10 seconds up to 30 minutes, at 6-hour is the 30 minute counter, and 9-hour sub dial indicate up to 10 hours.
<G-vec00060-001-s708><indicate.angeben><de> Reichen die Informationen nicht aus, um zu entscheiden, ob ein Stoff für einen bestimmten Endpunkt eingestuft werden sollte, so gibt der Registrant die von ihm daraufhin getroffene Maßnahme oder Entscheidung an und begründet sie.
<G-vec00060-001-s708><indicate.angeben><en> If the information is inadequate to decide whether a substance should be classified for a particular end-point, the registrant shall indicate and justify the action or decision he has taken as a result.
<G-vec00060-001-s709><indicate.angeben><de> Bei der Einholung des Einverständnisses gibt das zuständige Gericht oder die zuständige Behörde die ungefähre Höhe der Kosten an, die durch dieses Verfahren entstehen.
<G-vec00060-001-s709><indicate.angeben><en> When seeking such consent, the competent court or authority shall indicate the approximate costs which would result from this procedure.
<G-vec00060-001-s710><indicate.angeben><de> Dabei gibt es die Stelle der Auslassung und die Zahl der ausgelassenen Wörter an und stellt auf Antrag eine Abschrift der ausgelassenen Stellen zur Verfügung.
<G-vec00060-001-s710><indicate.angeben><en> It shall indicate the place and number of words omitted, and shall furnish, upon request, a copy of the passages omitted.
<G-vec00060-001-s711><indicate.angeben><de> Im Vorwort gibt er sehr präzise seine Quellen an, was im Mittelalter absolut nicht üblich war.
<G-vec00060-001-s711><indicate.angeben><en> In the premise he is careful to indicate his sources, something that was not usual in the Middle Ages.
<G-vec00060-001-s712><indicate.angeben><de> Die Gebrauchsanweisung gibt deutlich an, bei welchem Druck Enap angewendet wird.
<G-vec00060-001-s712><indicate.angeben><en> The instructions for use clearly indicate at which pressure Enap is applied.
<G-vec00060-001-s713><indicate.angeben><de> Die Anzahl der Verbindungen gibt an, wie viele Geräte Sie gleichzeitig in Ihrem VPN-Abonnement schützen können.
<G-vec00060-001-s713><indicate.angeben><en> The number of connections indicate how many devices you can simultaneously protect on your VPN subscription.
<G-vec00060-001-s714><indicate.angeben><de> In einer anderen Aufstellung gibt die offizielle Statistik für 1933 mehr als 860.000 Administratoren und Spezialisten an für die Sowjetwirtschaft insgesamt, davon in der Industrie über 480.000, im Transportwesen über 100.000, in der Landwirtschaft 93.000, im Handel 25.000.
<G-vec00060-001-s714><indicate.angeben><en> In another cross-section the official statistics indicate for 1933 more than 860,000 administrators and specialists in the whole Soviet economy – in industry over 480,000, in transport over 100,000, in agriculture 93,000, in commerce 25,000.
<G-vec00060-001-s715><indicate.angeben><de> (5) Unterliegen die Maschinen anderen Gemeinschaftsrichtlinien über andere Aspekte, so gibt das EG-Zeichen des Artikels 10 in diesen Fällen an, daß die Maschinen auch den Anforderungen dieser anderen Richtlinien entsprechen.
<G-vec00060-001-s715><indicate.angeben><en> Where the machinery is subject to other Community Directives concerning other aspects, the EC mark referred to in Article 10 shall indicate in these cases that the machinery also fulfils the requirements of the other Directives.
<G-vec00060-001-s716><indicate.angeben><de> Bei der Einholung des Einverständnisses des Europäischen Patentamts gibt das zuständige Gericht oder die zuständige Behörde die ungefähre Höhe der Kosten an, die durch dieses Verfahren entstehen.
<G-vec00060-001-s716><indicate.angeben><en> When seeking the consent of the European Patent Office, the competent authority shall indicate the approximate costs which would result from this procedure.
<G-vec00060-001-s717><indicate.angeben><de> Er gibt an, welche für ihn jeweils die höchste und welche die niedrigste Präferenz hat.
<G-vec00060-001-s717><indicate.angeben><en> They indicate in each case which level has the highest and which one has the lowest preference.
<G-vec00060-001-s718><indicate.angeben><de> Anders die Alumni und Studenten selbst, die ein heterogenes Bild skizzieren: Ein Drittel gibt zwar Mobilität als wichtig an, ein anderes Drittel sucht durchaus Ortsbindung.
<G-vec00060-001-s718><indicate.angeben><en> The alumni and students, by contrast, paint a heterogeneous picture: while one third indicate that mobility is important, another third are keen to stay in one place.
<G-vec00060-001-s620><specify.angeben><de> Dieser Abschnitt beschreibt, wie Sie Vorschub-Daten und nicht graphisch darstellbare Zeichen in DNC-Max angeben können.
<G-vec00060-001-s620><specify.angeben><en> This section describes how to specify feed data and non-printable characters in DNC-Max.
<G-vec00060-001-s621><specify.angeben><de> HTML-Interpretation: Wenn Sie einen zufälligen String angeben wollen, mÃ1⁄4ssen Sie ihn in die doppelte AnfÃ1⁄4hrungszeichen einschließen und htmlspecialchars() auf den gesamten Wert anwenden.
<G-vec00060-001-s621><specify.angeben><en> In order to specify a random string, you must include it in double quotes, and htmlspecialchars() the whole value.
<G-vec00060-001-s622><specify.angeben><de> Daher können Sie in der Bedeutung die Kostenrechnungsaufteilung erfassen, wobei Sie die Höhe der Beträge als Prozentwerte für die Aufteilung angeben.
<G-vec00060-001-s622><specify.angeben><en> You can therefore enter the cost allocation in the explanation and specify the amounts as percentage values for the allocation.
<G-vec00060-001-s623><specify.angeben><de> Schritt-für-Schritt-Anleitungen zur Verwendung der Ordnerumleitung finden Sie unter Angeben des Speicherorts der Ordner in einem Benutzerprofil.
<G-vec00060-001-s623><specify.angeben><en> For step-by-step information about how to use folder redirection, see Specify the Location of Folders in a User Profile.
<G-vec00060-001-s624><specify.angeben><de> HTML-Interpretation: Wenn Sie einen zufälligen String angeben wollen, müssen Sie ihn in die doppelte Anführungszeichen einschließen und htmlspecialchars() auf den gesamten Wert anwenden.
<G-vec00060-001-s624><specify.angeben><en> In order to specify a random string, you must include it in double quotes, and htmlspecialchars() the whole value.
<G-vec00060-001-s625><specify.angeben><de> Nachdem Sie Ihre Subdomäne als Alias Ihrer Standard-Zendesk-Adresse eingerichtet haben, müssen Sie die neue Adresse in Ihrer Instanz von Zendesk Support angeben.
<G-vec00060-001-s625><specify.angeben><en> After making your subdomain an alias of your default Zendesk address, you need to specify the new address in your instance of Zendesk Support.
<G-vec00060-001-s626><specify.angeben><de> So stellen Sie sicher, um herauszufinden, was Sie und Ihr Mann Blut (vergessen Sie nicht die Art und Rh angeben).
<G-vec00060-001-s626><specify.angeben><en> So make sure to find out what you and your husband's blood (do not forget to specify the type and Rh).
<G-vec00060-001-s627><specify.angeben><de> Lassen Sie die angeben.
<G-vec00060-001-s627><specify.angeben><en> Allow’s specify.
<G-vec00060-001-s628><specify.angeben><de> Achten Sie darauf, dass Sie diese Option nach dem „ --- “ angeben, so dass diese Option auch in die Bootloader-Konfiguration des installierten Systems kopiert wird (falls vom Bootloader-Installer unterstützt).
<G-vec00060-001-s628><specify.angeben><en> Be sure to specify this option after “ --- ”, so that it is copied into the bootloader configuration for the installed system (if supported by the installer for the bootloader).
<G-vec00060-001-s629><specify.angeben><de> Im unteren Teil des Rücksendeformulars, das dem Paket beiliegt, können Sie angeben, warum Sie den Artikel umtauschen möchten und welchen Artikel Sie stattdessen erhalten möchten.
<G-vec00060-001-s629><specify.angeben><en> In the lower part of the return form that is included with your package, you can specify why and to what you want the product exchanged.
<G-vec00060-001-s630><specify.angeben><de> Hier können Sie die für Sie ihre gewünschten Themengebiete angeben.
<G-vec00060-001-s630><specify.angeben><en> Mobile phone Here you can specify your desired topics.
<G-vec00060-001-s631><specify.angeben><de> Notieren Sie das SQL Server-Kontokennwort, das Sie bei der XenMobile Server-Installation angeben.
<G-vec00060-001-s631><specify.angeben><en> Record the SQL server account password that you specify during XenMobile Server installation.
<G-vec00060-001-s632><specify.angeben><de> Die Nutzer Award Tasten-Rekorder für Mac können Sie angeben, eine Liste der computer-Nutzer, will er überwachen.
<G-vec00060-001-s632><specify.angeben><en> The user of Award Keylogger for Mac can specify a list of computer users he wants to monitor.
<G-vec00060-001-s633><specify.angeben><de> Füllen Sie das Formular aus, wobei Sie die Art der Anfrage angeben (Handel, Einkauf, Verwaltung, Marketing), und unsere entsprechende Abteilung wird Ihnen so schnell wie möglich antworten.
<G-vec00060-001-s633><specify.angeben><en> Fill the form below and specify your type of request (commercial, purchase, administration, marketing), we will come reply you soon.
<G-vec00060-001-s634><specify.angeben><de> Nachdem Sie diese Option ausgewählt haben, können Sie angeben, ob die Seitenquelle über HTTP/FTP, REST oder SOAP abgerufen wird (siehe Abbildung unten).
<G-vec00060-001-s634><specify.angeben><en> After you select this option you can specify whether the page source will be obtained using HTTP/FTP, REST, or SOAP (see screenshot below).
<G-vec00060-001-s635><specify.angeben><de> Mit den optionalen Klauseln FIRSTNAME, MIDDLENAME und LASTNAME können Sie weitere Benutzereigenschaften wie den Vornamen der Person, den Vornamen und den Nachnamen angeben.
<G-vec00060-001-s635><specify.angeben><en> The optional FIRSTNAME, MIDDLENAME and LASTNAME clauses can be used to specify additional user properties, such as the person's first name, middle name and last name, respectively.
<G-vec00060-001-s636><specify.angeben><de> Soundtrack beschlossen, ubernehmen die kostenlose Lizenz, mussen Sie nur den Namen des Kunstlers angeben mussen.
<G-vec00060-001-s636><specify.angeben><en> It was decided to take free license soundtrack, where was required to specify only the name of the artist.
<G-vec00060-001-s637><specify.angeben><de> Wenn es bei einem Fahrzeugmodell verschiedene Dachvarianten gibt, müssen Sie auch den Dachtyp Ihres Autos angeben.
<G-vec00060-001-s637><specify.angeben><en> Where a car model has several roof variations you will need to specify the roof type of your specific car as well.
<G-vec00060-001-s638><specify.angeben><de> Wählen Sie auf der Seite Zieltyp angeben die Option Sicherung auf einem freigegebenen Netzwerkorder erstellen aus.
<G-vec00060-001-s638><specify.angeben><en> On the Specify Destination Type page, select Back up to a shared network folder.
<G-vec00060-001-s639><specify.angeben><de> Wenn Sie die Option –field verwenden, brauchen Sie keine OPF-Datei anzugeben.
<G-vec00060-001-s639><specify.angeben><en> If you use the –field option, there is no need to specify an OPF file.
<G-vec00060-001-s640><specify.angeben><de> Verwenden Sie Menüs und Schaltflächen unterhalb des Felds „Text“, um Textattribute wie Schriftart, Größe, Ausrichtung und Textrotation anzugeben.
<G-vec00060-001-s640><specify.angeben><en> Use menus and buttons below the Text field to specify text attributes such as font, size, alignment, and text rotation.
<G-vec00060-001-s641><specify.angeben><de> Bitte Vergessen Sie nicht, die Größe Ihres Logos in Pixel anzugeben, und für einen Ausdruck guter Qualität nehmen Sie bitte ein Bild von wenigstens 150 DPI.
<G-vec00060-001-s641><specify.angeben><en> Do not forget to specify the size of your logo in pixel and for a good printing quality, please take an image of at least 150 DPI.
<G-vec00060-001-s642><specify.angeben><de> Verwenden Sie dieses Feld, um die Anfrage für das Verzeichnis der FTP-Übertragungen anzugeben.
<G-vec00060-001-s642><specify.angeben><en> Use this field to specify the request directory for FTP transfers.
<G-vec00060-001-s643><specify.angeben><de> In dieser Erklärung hat sie die Artikel oder Absätze des Teils II der Charta anzugeben, die sie für die in der Erklärung bezeichneten Hoheitsgebiete als bindend anerkennt.
<G-vec00060-001-s643><specify.angeben><en> It shall specify in the declaration the articles or paragraphs of Part II of the Charter which it accepts as binding in respect of the territories named in the declaration.
<G-vec00060-001-s644><specify.angeben><de> Verwenden Sie diese Seite, um eine IP-Adresse, ein Subnetz oder einen IP-Adressbereich anzugeben.
<G-vec00060-001-s644><specify.angeben><en> Use this page to specify an IP address, a subnet, or a range of IP addresses.
<G-vec00060-001-s645><specify.angeben><de> Verwenden Sie das href -Attribut, um die Ziel-URL anzugeben.
<G-vec00060-001-s645><specify.angeben><en> Use the href attribute to specify the target URL.
<G-vec00060-001-s646><specify.angeben><de> Verwenden Sie die Registerkarte Bereich, um eine IP-Adresse, ein Subnetz oder einen IP-Adressbereich anzugeben.
<G-vec00060-001-s646><specify.angeben><en> Use the Scope tab to specify an IP address, a subnet, or a range of IP addresses.
<G-vec00060-001-s647><specify.angeben><de> Verwenden Sie diese Liste, um die GPO-Ausschlussverzeichnisse anzugeben, ohne sie manuell ausfüllen zu müssen.
<G-vec00060-001-s647><specify.angeben><en> Use this policy to specify GPO exclusion directories without having to fill them in manually.
<G-vec00060-001-s648><specify.angeben><de> Verwenden Sie das folgende Verfahren, um den Remotedesktop-Lizenzierungsmodus für den Server mit dem Host für Remotedesktopsitzungen mithilfe der Konfiguration des Hosts für Remotedesktopsitzungen anzugeben.
<G-vec00060-001-s648><specify.angeben><en> Use the following procedure to specify the Remote Desktop licensing mode for the RD Session Host server by using Remote Desktop Session Host Configuration.
<G-vec00060-001-s649><specify.angeben><de> Sie können jedoch auch das cfmodule-Tag mit dem Attribut template verwenden, um den absoluten Pfad des benutzerdefinierten Tags anzugeben.
<G-vec00060-001-s649><specify.angeben><en> Or, use the cfmodule tag with the template attribute to specify the absolute path to the custom tag.
<G-vec00060-001-s650><specify.angeben><de> Geben Sie einen definierten Namen ein, um den Ausgangspunkt für die Suche anzugeben.
<G-vec00060-001-s650><specify.angeben><en> Type a distinguished name to specify where the search starts.
<G-vec00060-001-s651><specify.angeben><de> Verwenden Sie das folgende Verfahren, um einen Lizenzserver anzugeben, der vom Server mit dem Host für Remotedesktopsitzungen verwendet wird.
<G-vec00060-001-s651><specify.angeben><en> Use the following procedure to specify a license server for the RD Session Host server to use by using the Remote Desktop Session Host Configuration tool.
<G-vec00060-001-s652><specify.angeben><de> Sollte das Projekt mehr als einen Datensatz enthalten, dann werden Sie gebeten anzugeben, welcher davon benutzt werden soll.
<G-vec00060-001-s652><specify.angeben><en> If the project contains more than one Data Set, you are asked to specify which one is to be used.
<G-vec00060-001-s653><specify.angeben><de> Verwenden Sie den Path-Parameter, um die Datei anzugeben.
<G-vec00060-001-s653><specify.angeben><en> Use the Path parameter to specify the file.
<G-vec00418-001-s078><brag.angeben><de> Wenn sich in Ihren Gebinde eine Lösung, Säure, Lauge oder ähnliches befindet, so können Sie in diesen Feldern angeben welche Konzentration die Lösung hat und was das Lösungsmittel ist.
<G-vec00418-001-s078><brag.angeben><en> If in your bundle is a solution, acid, lye or the similar, you can brag in these fields which concentration the solution has and what is the solvent.
