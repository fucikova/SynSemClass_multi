<G-vec00060-001-s057><note.beachten><de> Und beachte den Widerspruch zu den modernen Kirchen.
<G-vec00060-001-s057><note.beachten><en> Note the discrepancy in the modern Churches.
<G-vec00060-001-s058><note.beachten><de> Bitte beachte, dass wenn Unternehmen Dienste Dritter nutzen, deren eigene Bedingungen und Datenschutzrichtlinien in Bezug auf deine Nutzung solcher Dienste sowie hinsichtlich der Verwendung deiner Informationen durch sie auf solchen Diensten gelten.
<G-vec00060-001-s058><note.beachten><en> Please note that when businesses use third-party services, their own terms and privacy policies will govern your use of those services and their use of your information on those services. Third-Party Service Providers.
<G-vec00060-001-s059><note.beachten><de> Bitte beachte, dass unsere Partner und Download Stores allesamt professionelle Online Shops sind und auch dementsprechend nur hochwertige „Ware“ akzeptieren.
<G-vec00060-001-s059><note.beachten><en> "Please note that all our partners and download stores are professional online stores and therefore they only accept high-quality ""goods. So please release your reworked audio material again."
<G-vec00060-001-s060><note.beachten><de> Beachte, dass bei diesem Vorgang wahrscheinlich ein wenig Farbe auf dein Tuch oder deinen Stoff abfärben wird.
<G-vec00060-001-s060><note.beachten><en> Note that this process will probably get a little ink onto your towel or rag.
<G-vec00060-001-s061><note.beachten><de> Beachte, dass der hoch-Pfeil immer oberhalb des Punkts ist und der runter-Pfeil immer unterhalb des Punkts ist, unabhängig von der Himmelsrichtung der Linie.
<G-vec00060-001-s061><note.beachten><en> Note that the up arrow is always above the node and the down arrow always below the node, independent from the cardinal direction of the way.
<G-vec00060-001-s062><note.beachten><de> Bitte beachte, dass du die Zeitzone nur wechseln kannst, wenn du ein registriertes Mitglied bist.
<G-vec00060-001-s062><note.beachten><en> Please note that changing the timezone, like most settings can only be done by registered users.
<G-vec00060-001-s063><note.beachten><de> Bitte beachte: Je näher wir dem Festival kommen, desto mehr ändern sich diese Informationen und werden detaillierter.
<G-vec00060-001-s063><note.beachten><en> Please note: As we get closer to the festival the following informationwill change and become more detailed
<G-vec00060-001-s064><note.beachten><de> Beachte: Mit einem Klick auf den Ausloggen-Eintrag verlässt man zwar den Chat, das Chat-Fenster muss aber noch manuell geschlossen werden.
<G-vec00060-001-s064><note.beachten><en> Note: Although you leave the chat after a click at the [Logout]-button, you still need to close the chat window manually.
<G-vec00060-001-s065><note.beachten><de> Beachte, dass cannot ein Wort ist, während could not aus zwei Wörtern besteht.
<G-vec00060-001-s065><note.beachten><en> Note that cannot is one word and could not consists of two separate words.
<G-vec00060-001-s066><note.beachten><de> Bitte beachte, dass dieses Spiel deine Sprache nicht unterstützt.
<G-vec00060-001-s066><note.beachten><en> Please note that this game is not supported in your language.
<G-vec00060-001-s067><note.beachten><de> BEACHTE: Die Software benötigt ein PEAK CAN Interface und mindestens ein angeschlossenes CiA447 Geräte um korrekt funktionieren zu können.
<G-vec00060-001-s067><note.beachten><en> NOTE: This software requires any PEAK CAN interface and at least one connected CiA447 device to function properly.
<G-vec00060-001-s068><note.beachten><de> Bitte beachte: Die oben genannten Risiken treffen auch auf das Editieren von Spielständen und das Verändern einzelner Spieldateien zu.
<G-vec00060-001-s068><note.beachten><en> Please note: The above mentioned risks do also apply to savegame edits and modifying game files yourself.
<G-vec00060-001-s069><note.beachten><de> Beachte bitte, dass die erstattung ausschließlich durch bacs erfolgt.
<G-vec00060-001-s069><note.beachten><en> Please note that the refund will be made by BACS only
<G-vec00060-001-s070><note.beachten><de> Bitte beachte: Langebaan ist nur während der ersten 3 Tage Deines Kitesurfing Kurses ein guter Ort um Kitesurfen zu lernen (dieses ist Dein Kurs A, und wir gehen auch oft dann dorthin).
<G-vec00060-001-s070><note.beachten><en> Please note: Langebaan is only a good place during your first 3 days of your kitesurfing course (which is your course A, and we also often go there).
<G-vec00060-001-s071><note.beachten><de> Beachte den Gebrauch der Zeilennummern.
<G-vec00060-001-s071><note.beachten><en> Note the use of line numbers.
<G-vec00060-001-s072><note.beachten><de> Beachte bitte, dass die Darstellung unserer Produkte möglicherweise Links zu Produkten und Anwendungen von Drittparteien enthalten, deren Datenschutzrichtlinien von den Standards von göldo abweichen.
<G-vec00060-001-s072><note.beachten><en> Please note that the presentation of our products may contain links to products and applications of third parties whose privacy policies differ from göldo's standards.
<G-vec00060-001-s073><note.beachten><de> Beachte, dass dies eine keine Gebühr kosten kann (irgendjemand muss diese alten Archive gelegentlich abstauben), dies lohnt sich aber für die Informationen in diesen Dokumenten - sie sind von unschätzbarem Wert.
<G-vec00060-001-s073><note.beachten><en> Note that while there may be a small fee for their services (somebody has to dust off those old archives occasionally), it is well worth the price for the invaluable information contained in those documents.
<G-vec00060-001-s074><note.beachten><de> Beachte: Project64 hat einen Bug, es gibt kein Bild während der letzten Stunde eines Tages, 5 - 6 Uhr morgens, das kann in späteren Kapiteln zum Problem werden, für jetzt, einfach warten bis das Bild zur Dämmerung am nächsten Tag wiederkommt.
<G-vec00060-001-s074><note.beachten><en> Note: Project64 has a bug, it doesn´t display a picture during the last hour of a day, 5am - 6am, that might become a problem in later chapters, for now, simply wait until the picture comes back at dawn of next day.
<G-vec00060-001-s075><note.beachten><de> Beispiele: Beachte: Beim deutschen t und d steht die Zunge genau am Übergang von Zähnen und Zahnfleisch am Oberkiefer (Alveolar).
<G-vec00060-001-s075><note.beachten><en> Please note: For a German t or d, the tongue is positioned right at the bridge between teeth and gums at the upper jaw (alveolar).
<G-vec00078-001-s164><acknowledge.beachten><de> Wir beachten und fördern die kulturellen Eigenheiten und Traditionen der Länder, in denen wir tätig sind.
<G-vec00078-001-s164><acknowledge.beachten><en> We acknowledge and promote the cultural distinctiveness and traditions of the countries in which we operate in.
<G-vec00078-001-s165><acknowledge.beachten><de> Wenn Du einen Split-Test durchführst, solltest Du einige Dinge beachten.
<G-vec00078-001-s165><acknowledge.beachten><en> When you’re split testing, there are a few things to acknowledge.
<G-vec00078-001-s166><acknowledge.beachten><de> Wenn Sie auf einen solchen Link klicken, der zu Websites von Dritten führt, ist zu beachten, dass diese Webseiten eigene Datenschutzbestimmungen haben.
<G-vec00078-001-s166><acknowledge.beachten><en> By clicking on a link that leads to third-party websites you acknowledge that these websites have their own privacy policies.
<G-vec00078-001-s167><acknowledge.beachten><de> Der Autor ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Grafiken, Videos, Sounds und Texte zu beachten, von ihm selbst erstellte Grafiken, Videos, Sounds und Texte zu nutzen oder auf lizenzfreie Grafiken, Sounds und Texte zurückzugreifen.
<G-vec00078-001-s167><acknowledge.beachten><en> The author aims to acknowledge the copyrights of the used graphics, videos, sound and texts in all publications, to use graphics, videos, sounds and texts, created by himself or to use public domain graphics, videos, sound and texts. Should there be a not marked graphic, video, sound or text, which is protected by a copyright of third party on the specific pages, it means that the author could not ascertain the copyright.
<G-vec00078-001-s168><acknowledge.beachten><de> Bitte beachten Sie, dass sich die Taxify Gebühr von Zeit zu Zeit ändern kann.
<G-vec00078-001-s168><acknowledge.beachten><en> Please acknowledge that the Taxify Fee may change from time to time.
<G-vec00301-001-s217><attend.beachten><de> In unserem Hotel lassen wir alles Wissen und Annehmlichkeiten benötigen, um Geschäft oder Freizeitreisende zu beachten entweder.
<G-vec00301-001-s217><attend.beachten><en> In our hotel we have all the knowledge and amenities needed to attend to either business or leisure travellers.
<G-vec00301-001-s218><attend.beachten><de> Der Grund kann gewesen sein, dass die Wasserversorgung in Fatehpur Sikri oder von der geringen Qualität unzulänglich war, oder, wie einige Historiker glauben, dass Akbar die Nordwestbereiche seines Reiches beachten musste und folglich, seinen Hauptnordwesten verschob.
<G-vec00301-001-s218><attend.beachten><en> The reason may have been that the water supply in Fatehpur Sikri was insufficient or of poor quality, or, as some historians believe, that Akbar had to attend to the northwest areas of his empire and therefore moved his capital northwest.
<G-vec00301-001-s219><attend.beachten><de> Montag ist Fußball-üblich, Dienstag ist Klavierlektion, Mittwoch ist Kirche-Tätigkeiten, Donnerstag ist ein Fußball-Spiel, Freitag eine GeburtstagPartei zu beachten.
<G-vec00301-001-s219><attend.beachten><en> Monday is Soccer Practice, Tuesday is Piano lesson, Wednesday is Church Activities, Thursday is a Soccer Game, Friday a birthday party to attend.
<G-vec00301-001-s220><attend.beachten><de> Beachten Sie in diesem Fall bitte unseren Eintrag in den FAQs dazu und installieren Sie anschließend folgenden Treiber.
<G-vec00301-001-s220><attend.beachten><en> Please attend to our FAQs entry in this case and install the following driver afterwards.
<G-vec00301-001-s221><attend.beachten><de> In der Zwischenzeit versuchen wir, unsere spirituellen Lektionen zu beachten und bleiben geerdet.
<G-vec00301-001-s221><attend.beachten><en> In-between we attempt to attend to our own spiritual lessons and stay grounded.
<G-vec00301-001-s222><attend.beachten><de> Aber die Wahrscheinlichkeit einen solchen Weg zu finden ist größer, wenn wir zumindest den körperlichen Felt Sense von dem haben, was gebraucht wird und wir diesen beachten.
<G-vec00301-001-s222><attend.beachten><en> But we are more likely to find such a new way if we first have a bodily felt sense of what is needed, and if we attend to it.
<G-vec00301-001-s223><attend.beachten><de> Aber ich war zu neugierig nicht zu beachten.
<G-vec00301-001-s223><attend.beachten><en> But I was too curious not to attend.
<G-vec00301-001-s224><attend.beachten><de> Das Versäumnis des Gebets führt dazu, dass der Geist von den Pflichten abgelenkt wird, die uns obliegen; lasst uns dann also unsere Gebete beachten und alle unsere Pflichten, und ihr werdet wissen, dass Bruder Brigham und seine Brüder zu euch von diesen Dingen sprach....
<G-vec00301-001-s224><attend.beachten><en> Omitting prayer is calculated to lead the mind away from those duties which are incumbent upon us; then let us attend to our prayers and all our duties, and you will know that brother Brigham and his brethren have told you of these things...
<G-vec00301-001-s225><attend.beachten><de> Meine Ahnung war korrekt gewesen, die der Lernabschnitt auf russischer Pädagogik das ein I war, das benötigt wurde, um zu beachten.
<G-vec00301-001-s225><attend.beachten><en> My hunch had been correct that the session on Russian Pedagogy was the one I needed to attend.
<G-vec00301-001-s226><attend.beachten><de> Eine Ansage der Roadrunners würde zu dieser Zeit gebildet, wenn ich nicht imstande war, persönlich zu beachten.
<G-vec00301-001-s226><attend.beachten><en> An announcement of the Roadrunners would be made at that time if I was unable to attend in person.
<G-vec00301-001-s227><attend.beachten><de> Trotz der Schwierigkeiten des Kriegtransportes, beharrte ` Munny ' nach dem Lassen ihrer jährlichen Sommerexkursion zu Milford, Pennsylvania, die Eigenschaft beachten, die von ihren Eltern übernommen wurde.
<G-vec00301-001-s227><attend.beachten><en> Despite the difficulties of wartime transportation, 'Munny' insisted upon making her annual summer excursion to Milford, Pennsylvania, to attend to property inherited from her parents.
<G-vec00301-001-s228><attend.beachten><de> Meine Familie würde lieben zu beachten und möglicherweise einen Spaziergang vorbei zu Anissa' macht; s-Haus, während wir im Bereich sind.
<G-vec00301-001-s228><attend.beachten><en> My family would love to attend, and maybe take a walk over to Anissa's house while we are in the area.
<G-vec00301-001-s230><attend.beachten><de> Wenn solch eine Lagebestimmung vorhanden ist, ist es eine gute Idee, als Weise zu beachten, über alle Wahlen an deinen Fingerspitzen zu erlernen und zu entscheiden, welche Tätigkeiten zum zu wählen, die deine Luxuxerfahrung erhöhen.
<G-vec00301-001-s230><attend.beachten><en> If such an orientation is available, it is a good idea to attend as a way to learn about all of the options at your fingertips and decide what activities to choose that will enhance your luxury experience.
<G-vec00301-001-s231><attend.beachten><de> Das Hochschulgremium schätzt die durchschnittlichen vierjährlichen allgemeine Hochschulkosten fast $5.000 pro Jahr, um zu beachten und eine zweijährige allgemeine Hochschule ist fast $2000.
<G-vec00301-001-s231><attend.beachten><en> The College Board estimates the average four-year public college costs almost $5,000 per year to attend and a two-year public college is almost $2000.
<G-vec00547-001-s057><mind.beachten><de> Allerdings ist beim Winterurlaub im Gebirge zu beachten, dass die UV -Strahlung hier aufgrund der Höhe und der Reflexion am Schnee erheblich höher sein kann, so dass ein UV -Schutz erforderlich sein könnte.
<G-vec00547-001-s057><mind.beachten><en> It has to be kept in mind that during winter vacation in the mountains the UV exposure can be significantly higher, due to altitude and reflection of UV radiation at snow.
<G-vec00547-001-s058><mind.beachten><de> Es ist wichtig zu beachten, dass die Dachbalken 15 dienen müssen - 30 cm von der Außenkante des Racks, so dass das Design richtig und schön.
<G-vec00547-001-s058><mind.beachten><en> It is important to bear in mind that the roof joists must serve 15 - 30 cm from the outer edge of the rack, making the design right and beautiful.
<G-vec00547-001-s059><mind.beachten><de> Bei der Prüfung der Frage, unter welchen Umständen die Prüfungsabteilung guten Grund hat, in Ausübung ihres Ermessens spät eingereichte Änderungen noch zuzulassen, gilt es zu beachten, dass ein Änderungsantrag in diesem Stadium möglicherweise gestellt wird, weil dem Anmelder die Notwendigkeit einer Änderung klar geworden ist, weil die Prüfungsabteilung einen kritischen Punkt angesprochen hat oder weil damit Einwendungen Dritter gemäß Art.
<G-vec00547-001-s059><mind.beachten><en> When considering the possible circumstances in which an examining division may have good reason to exercise its discretion to allow belated amendments, it should be borne in mind that a request for amendment at that stage may arise as a result of a realisation by the applicant of the need for an amendment, as a result of a point raised by the examining division or as a result of consideration of observations made by a third party pursuant to Art.
<G-vec00547-001-s060><mind.beachten><de> Hier finden Sie Informationen zu allem, was Sie vor und während Ihrer Reise beachten sollten.
<G-vec00547-001-s060><mind.beachten><en> Here you will find information on everything you need to bear in mind before and during your trip.
<G-vec00547-001-s061><mind.beachten><de> Wenn Sie einen Hund mitführen, beachten Sie bitte, dass der Hund in einer Hundebox untergebracht sein muss, ansonsten können wir die gewünschte Beförderung nicht durchführen.
<G-vec00547-001-s061><mind.beachten><en> If you intend to travel with a dog please keep in mind that the dog must travel in a cage, otherwise we may not be able to accommodate your transportation.
<G-vec00547-001-s062><mind.beachten><de> Dabei sollte beachten, dass abhängig von der Windrichtung einige Ferienwohnungen Lärmprobleme haben können.
<G-vec00547-001-s062><mind.beachten><en> Keep in mind that depending on wind, accommodations around may have problems with noise.
<G-vec00547-001-s063><mind.beachten><de> Beachten Sie allerdings, dass Schläuche schnell verschleißen können und ersetzt werden müssen.
<G-vec00547-001-s063><mind.beachten><en> Keep in mind, however, that hoses can wear quickly and will need to be replaced over time.
<G-vec00547-001-s064><mind.beachten><de> Bei der Wahl der Schwellenwerte High High High High high und Low Low Low Low low ist zu beachten, dass die zweite Richtungsableitung von der Amplitude und Breite der Linie, sowie von der Größe des Glättungsparameters Sigma Sigma Sigma Sigma sigma abhängt.
<G-vec00547-001-s064><mind.beachten><en> For the choice of the thresholds High High High High high and Low Low Low Low low one has to keep in mind that the second directional derivative depends on the amplitude and width of the line as well as the choice of Sigma Sigma Sigma Sigma sigma .
<G-vec00547-001-s065><mind.beachten><de> Asthmamedikationen mÃ1⁄4ssen sogar während der Schwangerschaft fortgesetzt werden und beachten die Gesundheit der Mutter sowie des Babys.
<G-vec00547-001-s065><mind.beachten><en> Asthma medications need to be continued even during pregnancy, keeping in mind the health of the mother as well as the baby.
<G-vec00547-001-s066><mind.beachten><de> Es gibt einige typographische Feinheiten zu beachten.
<G-vec00547-001-s066><mind.beachten><en> There are a couple of typographic subtleties to keep in mind.
<G-vec00547-001-s067><mind.beachten><de> Ich setzte alles auf diesen einen Punkt, nur dieses eine zu tun: Lernen des Fa – die Lehren des Falun Gong – und das Problem Krankheit überhaupt nicht mehr zu beachten.
<G-vec00547-001-s067><mind.beachten><en> I set everything down at that point, to do one thing only: study the Falun Gong teachings (the Fa) and not mind the problem of sickness any more.
<G-vec00547-001-s068><mind.beachten><de> Blaue Augen findet man bei weißen Katzen, bei Bicolour und bei Colourpoint (beachten Sie bitte, dass blaue Augen bei Colourpoint genetisch verschieden sind von den blauen Augen bei weißen Katzen).
<G-vec00547-001-s068><mind.beachten><en> Blue eyes are found in white, bicolour and colourpoint (but bare in mind that the blue of a colourpoint is genetically different from the blue in a white cat!).
<G-vec00547-001-s069><mind.beachten><de> Beachten Sie, dass Nasenbluten mit den oben genannten Symptomen häufig auftritt, wenn der Bluthochdruck einen kritischen Pegel erreicht.
<G-vec00547-001-s069><mind.beachten><en> Keep in mind that nose bleeds with the above listed symptoms will often strike only when high blood pressurereaches a critical stage.
<G-vec00547-001-s070><mind.beachten><de> Es ist notwendig, die spezifische Zusammensetzung von HGH Ergänzungen zu beachten, wenn Sie eine künstliche Art zu kaufen werden.
<G-vec00547-001-s070><mind.beachten><en> It is essential to keep in mind the specific make-up of HGH drugs if you are going to buy an artificial form.
<G-vec00547-001-s071><mind.beachten><de> Was ist noch zu beachten, dass Sie sicherlich benötigen Post-Cycle-Therapie, bis Ihr all-natürlichen Testosteronspiegel Feature zurück zu typischen gegangen.
<G-vec00547-001-s071><mind.beachten><en> What's even more, keep in mind that you will certainly require post-cycle treatment up until your organic testosterone degrees feature returned to typical.
<G-vec00547-001-s072><mind.beachten><de> Es ist jedoch zu beachten, dass die Trennung von thermoregulatorischem und emotional bedingtem Schwitzen nicht absolut ist (e19); eine gegenseitige Beeinflussung ist nachgewiesen (e2).
<G-vec00547-001-s072><mind.beachten><en> It needs to be borne in mind, however, that the distinction between thermoregulatory and emotional sweating is not an absolute distinction (e19); they have been shown to mutually influence one another (e2).
<G-vec00547-001-s073><mind.beachten><de> Was ist noch zu beachten, dass haben Sie sicher schon post-Zyklus-Therapie bis Ihr all-natürlichen Testosteronspiegel tatsächlich zu typischen zurückgegangen.
<G-vec00547-001-s073><mind.beachten><en> Exactly what's more, keep in mind that you will certainly require post-cycle treatment until your natural testosterone levels have actually returned to typical.
<G-vec00547-001-s074><mind.beachten><de> Wir beteiligen uns jedoch nicht an anfallenden Bankgebühren und bitten, dies zu beachten.
<G-vec00547-001-s074><mind.beachten><en> However, we do not participate in any bank charges and ask you to keep that in mind.
<G-vec00547-001-s075><mind.beachten><de> "Bitte beachten Sie, gibt es einen zusätzlichen Gebühr für diesen Service und alle Gewebe Gangläufer, die rutschfest sind die Sicherung hinzugefügt wird verlieren bis zu 4 ""in der Breite von der ursprünglichen 36"" oder 45 ""Größe."
<G-vec00547-001-s075><mind.beachten><en> Please bear in mind there is an added charge for this service and all fabric aisle runners that have nonslip backing added will lose up to 4″ in width from the original 36″ or 45″ size.
<G-vec00060-001-s076><note.beachten><de> Sie sollten beachten, dass Angel Eyes Songtext auf Deutsch durchgeführt von Ace Of Base ist nur für didaktische Zwecke, und wenn Sie den Song mögen, sollten Sie die CD kaufen.
<G-vec00060-001-s076><note.beachten><en> You should note that Angel Eyes Lyrics performed by Ace Of Base is only provided for educational purposes only and if you like the song you should buy the CD
<G-vec00060-001-s077><note.beachten><de> Bitte beachten Sie, dass das Namensschild auf Wangs linker Brust ein Namensschild für NGO Mitglieder ist.
<G-vec00060-001-s077><note.beachten><en> Please note that the badge on Wang's left lapel was an NGO's name tag.
<G-vec00060-001-s078><note.beachten><de> Hinweis: Bitte beachten Sie, dass die Farbe nicht frei gewählt werden können.
<G-vec00060-001-s078><note.beachten><en> Note: Please note that the color can not be chosen.
<G-vec00060-001-s079><note.beachten><de> Sie sollten beachten, dass If / Then Songtext auf Deutsch durchgeführt von Aberfeldy ist nur für didaktische Zwecke, und wenn Sie den Song mögen, sollten Sie die CD kaufen.
<G-vec00060-001-s079><note.beachten><en> You should note that If / Then Lyrics performed by Aberfeldy is only provided for educational purposes only and if you like the song you should buy the CD
<G-vec00060-001-s080><note.beachten><de> Bitte beachten Sie, dass wir leider die Tierbeförderung verweigern müssen, wenn die Tasche den Anforderungen nicht entspricht.
<G-vec00060-001-s080><note.beachten><en> Please note that we will not be able to transport your animal if the carrier does not meet the above requirements.
<G-vec00060-001-s081><note.beachten><de> Sie sollten beachten, dass Be My Witness Songtext auf Deutsch durchgeführt von Bahamas ist nur für didaktische Zwecke, und wenn Sie den Song mögen, sollten Sie die CD kaufen.
<G-vec00060-001-s081><note.beachten><en> You should note that Be My Witness Lyrics performed by Bahamas is only provided for educational purposes only and if you like the song you should buy the CD
<G-vec00060-001-s082><note.beachten><de> Beachten Sie bitte, dass für Dienste die MobileTogether Server Advanced Edition benötigt wird.
<G-vec00060-001-s082><note.beachten><en> Please note that services require use of the MobileTogether Server Advanced Edition.
<G-vec00060-001-s083><note.beachten><de> Bitte beachten Sie, dass ein Zustellbett gegen einen Aufpreis von € 25 pro Person inklusive Frühstück hinzugefügt werden kann.
<G-vec00060-001-s083><note.beachten><en> Informaţii importante Please note that an extra bed can be added for € 25 per person including breakfast.
<G-vec00060-001-s084><note.beachten><de> Bitte beachten Sie, dass dieses Zimmer keine Fenster hat und es nur für 1 Person geeignet ist.
<G-vec00060-001-s084><note.beachten><en> Please note that this room has no windows and room is strictly for 1 person only.
<G-vec00060-001-s085><note.beachten><de> Sie sollten beachten, dass Festa Songtext auf Deutsch durchgeführt von Maria Bethânia ist nur für didaktische Zwecke, und wenn Sie den Song mögen, sollten Sie die CD kaufen.
<G-vec00060-001-s085><note.beachten><en> You should note that Festa Lyrics performed by Maria Bethânia is only provided for educational purposes only and if you like the song you should buy the CD
<G-vec00060-001-s086><note.beachten><de> Wichtige Informationen Bitte beachten Sie, dass diese Unterkunft keine Ankünfte nach Mitternacht akzeptiert.
<G-vec00060-001-s086><note.beachten><en> Important information Please note, this property does not accept arrivals after midnight.
<G-vec00060-001-s087><note.beachten><de> Bitte beachten Sie, dass es nur unter außergewöhnlichen Umständen möglich ist, das zugewiesene Apartment während Ihres Aufenthalts zu ändern.
<G-vec00060-001-s087><note.beachten><en> Please note that under exceptional circumstances it may be necessary to change the allocated apartment during your stay.
<G-vec00060-001-s088><note.beachten><de> Wir wollen die Worte des Paulus beachten, „wenn wir mit ihm leiden”.
<G-vec00060-001-s088><note.beachten><en> We note Paul’s words—“if so be that we suffer with him.”
<G-vec00060-001-s089><note.beachten><de> Bitte beachten Sie, dass für die Nutzung von TV Air free Datenkosten anfallen.
<G-vec00060-001-s089><note.beachten><en> Please note that data usage costs are incurred when you use TV Air free.
<G-vec00060-001-s090><note.beachten><de> Falls Sie die Option zur Übersetzung der Beschreibung nutzen, beachten Sie bitte, dass es sich hierbei um eine maschinelle Übersetzung der Originalbeschreibung handelt.
<G-vec00060-001-s090><note.beachten><en> I z pewnością bezlitośnie je wykorzysta, by tym razem zabić Jane. If you use the option to translate the description, please note that this is a machine translation of original description.
<G-vec00060-001-s091><note.beachten><de> Bitte beachten Sie, dass, wann immer es möglich ist, das Hotel die Zahlung auf Ihrer Kreditkarte in der Währung des Landes verarbeitet, in dem die Kreditkarte ausgestellt wurde.
<G-vec00060-001-s091><note.beachten><en> Please note that whenever possible the hotel will process payment on the guest's credit card in the currency of the country where the credit card was issued.
<G-vec00060-001-s092><note.beachten><de> Bitte beachten Sie, dass in dieser Zimmerkategorie kein Zustellbett untergebracht werden kann.
<G-vec00060-001-s092><note.beachten><en> Please note that an extra bed cannot be accommodated in this category.
<G-vec00060-001-s093><note.beachten><de> Dieser geschmiedete beachten Detektor für den täglichen Gebrauch konzipiert (Bank, Geschäft, etc).
<G-vec00060-001-s093><note.beachten><en> This forged note detector has been designed for everyday use (bank, shop, etc.).
<G-vec00060-001-s094><note.beachten><de> Bitte beachten Sie, dass Zahlungen mit Kreditkarte gebührenpflichtig sind.
<G-vec00060-001-s094><note.beachten><en> Please note that credit card payments can only be accepted at a surcharge.
<G-vec00060-001-s095><note.beachten><de> Wichtige Informationen Bitte beachten Sie, dass für Handtücher GBP 2 pro Stück berechnet werden.
<G-vec00060-001-s095><note.beachten><en> Important information Please note hand towels are charged at GBP 2 per towel.
<G-vec00060-001-s096><note.beachten><de> Beachten Sie bitte, dass der Pool, das Fitnesscenter, das Spa, die Sauna und der Billardtisch der Verfügbarkeit unterliegen und sich nicht für alle Zimmer garantieren lassen.
<G-vec00060-001-s096><note.beachten><en> Please note: The swimming pool, fitness centre, spa, sauna and billiards table are subject to availability and are not guaranteed for all of the rooms.
<G-vec00060-001-s097><note.beachten><de> Bitte beachten Sie, dass sich dieses Zimmer unter der Erde befindet und keine Fenster besitzt.
<G-vec00060-001-s097><note.beachten><en> Please note, this room is located below ground and does not have windows.
<G-vec00060-001-s098><note.beachten><de> Bitte beachten Sie, dass einige Zimmer nur über Treppen erreichbar sind.
<G-vec00060-001-s098><note.beachten><en> Please note some of the rooms require guests to climb a number of stairs.
<G-vec00060-001-s099><note.beachten><de> Bitte beachten Sie, dass ein später Check-out nicht möglich ist.
<G-vec00060-001-s099><note.beachten><en> Please note: Late checkouts are not allowed.
<G-vec00060-001-s100><note.beachten><de> Wichtige Informationen Bitte beachten Sie, dass eine Gebühr für die Anreise außerhalb der Check-in-Zeiten berechnet wird.
<G-vec00060-001-s100><note.beachten><en> Important information Please note a surcharge applies for arrivals outside check-in hours.
<G-vec00060-001-s101><note.beachten><de> Bitte beachten Sie, dass sich diese Wohneinheit 80 m vom Hauptgebäude des Hotels entfernt befindet.
<G-vec00060-001-s101><note.beachten><en> Please note this unit is located 80 metres of the main hotel building.
<G-vec00060-001-s102><note.beachten><de> Wichtige Informationen Beachten Sie bitte, dass nur Personen ab 21 Jahren einchecken dürfen.
<G-vec00060-001-s102><note.beachten><en> Important information Please note, guests must be 21 years of age or older to check in.
<G-vec00060-001-s103><note.beachten><de> Wichtige Informationen Bitte beachten Sie, dass Barzahlungen in Höhe von über € 1.000 gemäß der aktuellen italienischen Gesetzgebung nicht gestattet sind.
<G-vec00060-001-s103><note.beachten><en> Important information Please note, cash payments over € 1,000.00 are not permitted under current Italian law.
<G-vec00060-001-s104><note.beachten><de> Bitte beachten Sie, dass diese Unterkunft keine Parkplätze bietet.
<G-vec00060-001-s104><note.beachten><en> Please note, parking facilities are not offered at this property.
<G-vec00060-001-s105><note.beachten><de> Bitte beachten Sie, dass die Disney Vacation Homes sich das Recht vorbehalten, Ihre Kreditkarten im Falle von Schäden an der Unterkunft zu belasten.
<G-vec00060-001-s105><note.beachten><en> Please note Disney Vacation Homes reserves the right to charge guest credit cards in the event of damages to the property.
<G-vec00060-001-s106><note.beachten><de> Bitte beachten Sie, dass bei Aufenthalten von mehr als 14 Tagen eine zusätzliche Reinigungsgebühr anfällt.
<G-vec00060-001-s106><note.beachten><en> Please note stays of more than 14 days will incur an additional cleaning fee.
<G-vec00060-001-s107><note.beachten><de> Bitte beachten Sie, dass das Restaurant La Maquinista in der Sommersaison geschlossen ist.
<G-vec00060-001-s107><note.beachten><en> Please note Restaurant La Maquinista is closed during the summer season.
<G-vec00060-001-s108><note.beachten><de> Bitte beachten Sie, dass die Zimmer nicht klimatisiert sind.
<G-vec00060-001-s108><note.beachten><en> Please note there is no air-conditioning in the rooms.
<G-vec00060-001-s109><note.beachten><de> Bitte beachten Sie, dass die Aktualisierung bis zu drei Wochen dauern kann.
<G-vec00060-001-s109><note.beachten><en> Please note, this process can take up to three weeks.
<G-vec00060-001-s110><note.beachten><de> Bitte beachten Sie, dass für die Nutzung der Sauna ein Aufpreis berechnet wird.
<G-vec00060-001-s110><note.beachten><en> Please note there is an extra charge for using the sauna.
<G-vec00060-001-s111><note.beachten><de> Wichtige Informationen Beachten Sie bitte, dass das Mindestalter für den Check-in 25 Jahre beträgt.
<G-vec00060-001-s111><note.beachten><en> Important information Please note, guests must be 25 years or older to check-in.
<G-vec00060-001-s112><note.beachten><de> Bitte beachten Sie, dass die saisonalen Pools im Sommer geöffnet sind.
<G-vec00060-001-s112><note.beachten><en> Please note, seasonal pools open in summer.
<G-vec00060-001-s113><note.beachten><de> Bitte beachten Sie, dass die Klimaanlage gegen einen täglichen Aufpreis in Höhe von EUR 10 zur Verfügung gestellt wird.
<G-vec00060-001-s113><note.beachten><en> Please note use of air conditioning has an extra daily cost of EUR 10.
<G-vec00060-001-s114><note.beachten><de> (Beachten Sie: Da es in verschiedenen Ländern unterschiedliche Gesetze gibt, achten Sie bitte darauf, dass Sie nicht gegen die Gesetze verstoßen, wenn Sie solch ein Programm verwenden wollen.
<G-vec00060-001-s114><note.beachten><en> (Note: Since there are different laws in different countries, please pay attention to not violate the laws before using such program.
<G-vec00060-001-s115><note.beachten><de> Bitte beachten Sie, dass die Revisionsberichte der folgenden Jahre im Jahresbericht integriert sind.
<G-vec00060-001-s115><note.beachten><en> Audit Reports Kindly note that following audit reports areÂ integrated in the annual report
<G-vec00060-001-s116><note.beachten><de> Beachten Sie, dass dies nur dann der Fall ist, wenn die LDAP-Passwortrichtlinie verwendet wird (normalerweise vom LDAP-Server gehandhabt), d.h., wenn die erweiterte LDAP-Operation zur Änderung des Passworts verwendet wird.
<G-vec00060-001-s116><note.beachten><en> Note that this is only related to a case when the LDAP password policy is used (usually taken care of by LDAP server), that is, the LDAP extended operation is used to change the password.
<G-vec00060-001-s117><note.beachten><de> Beachten Sie, dass Dänemark, Frankreich, Spanien, Vereinigtes Königreich und die Vereinigten Staaten Spieler sind beschränkt auf Betchan casino.
<G-vec00060-001-s117><note.beachten><en> Note that Denmark, France, Spain, United Kingdom and United States players are restricted at Betchan casino.
<G-vec00060-001-s118><note.beachten><de> Beachten Sie, dass American Samoa, Andorra, Anguilla, Aruba, Barbados, Belgien, Bermuda, British Virgin Inseln, Cayman Inseln, Chile, Cook-Inseln, Finnland, Griechenland, Island, Luxemburg, Marshall Inseln, Martinique, Mayotte, Monaco, Montserrat, Neukaledonien, Niue, Norfolk Island, Northern Mariana Islands, Portugal, Puerto Rico, San Marino, Spain, Tokelau, Uruguay und Venezuela Spieler beschränkt sind, die bei Prism Casino .
<G-vec00060-001-s118><note.beachten><en> Note that American Samoa, Andorra, Anguilla, Aruba, Barbados, Belgium, Bermuda, British Virgin Islands, Cayman Islands, Chile, Cook Islands, Finland, Greece, Iceland, Luxembourg, Marshall Islands, Martinique, Mayotte, Monaco, Montserrat, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Portugal, Puerto Rico, San Marino, Spain, Tokelau, Uruguay and Venezuela players are restricted at Prism Casino .
<G-vec00060-001-s119><note.beachten><de> Bitte beachten Sie, dass in solchen Fällen die Rücksendekosten vom Kunden zu tragen sind und nicht zurückerstattet werden können.
<G-vec00060-001-s119><note.beachten><en> Kindly note that in such cases the return shipping fee is the customers responsibility and is non-refundable.
<G-vec00060-001-s120><note.beachten><de> Beachten Sie, dass es kostenlos ist und pro Person berechnet.
<G-vec00060-001-s120><note.beachten><en> Note that it is complimentary and is charged per person.
<G-vec00060-001-s121><note.beachten><de> Diese können sinnvoll Aufführungen, aber beachten Sie, dass diese vielleicht nicht die authentische Erlebnisse werden.
<G-vec00060-001-s121><note.beachten><en> These may be worthwhile performances, but note that these may not be the most authentic experiences.
<G-vec00060-001-s122><note.beachten><de> Ruhezeit funktioniert nach 11 Uhr.Wir bieten kostenlose Job Agency Dienste an (sparen $ 100), wenn Sie kein Geld haben oder können einige tolle Ermäßigungen für lokale Attraktionen arrangieren, um diesen Dollar auf das Maximum zu strecken.Bitte beachten Sie, dass alle Gäste aus Sicherheitsgründen beim Check-in einen Lichtbildausweis vorlegen müssen.
<G-vec00060-001-s122><note.beachten><en> We offer free Job Agency services (saving $100) if you're short of cash or can arrange some great discounts to local attractions to stretch that dollar to the max.Please note that in the interests of security, all guests are required to produce government photo ID on check-in.
<G-vec00060-001-s123><note.beachten><de> "Beachten Sie, dass dieser Einfluss die Lautstärke erhöhen kann, also sollte der ""Dry Gain"" in der Regel niedriger als 0 dB eingestellt werden, um ein Clipping zu vermeiden."
<G-vec00060-001-s123><note.beachten><en> "Note: that this influence may upsurge the volume, so the ""Dry Gain"" should typically be set lower than 0 dB in order to avoid clipping."
<G-vec00060-001-s124><note.beachten><de> Beachten Sie, dass der 30-Tage-Zeitraum genau 30 Tage ab dem Tag endet auf dem Konto war ursprünglich aktiviert (nicht der Tag, den die Bestellung aufgegeben wurde).
<G-vec00060-001-s124><note.beachten><en> Note that the 30 day period ends exactly 30 days from the day on which account was originally activated (not the day the order was placed).
<G-vec00060-001-s125><note.beachten><de> "Beachten Sie außerdem: Wenn ein Binding-Kästchen oder ein Eintrag in einem Binding-Kästchen ausgewählt ist, werden die Definitionen in der Eingabehilfe ""Details"" angezeigt und können dort bearbeitet werden."
<G-vec00060-001-s125><note.beachten><en> Note also that when a binding box or an item in a binding box is selected, the definitions are displayed in the Details entry helper and can be edited there.
<G-vec00060-001-s126><note.beachten><de> Wichtige Informationen Beachten Sie, dass Sie 3 Tage vor der Ankunft eine E-Mail vom ApartDirect Gamla Stan II mit Informationen zum Check-in erhalten.
<G-vec00060-001-s126><note.beachten><en> Important information Note that 3 days before arrival, you will receive an email from ApartDirect Gamla Stan II with check-in instructions.
<G-vec00060-001-s127><note.beachten><de> "Beachten Sie, dass es sich bei den ""SOLIDWORKS Apps for Kids"" Produkten und Diensten um Konsumgüter handelt, die einer separaten Datenschutzrichtlinie unterliegen."
<G-vec00060-001-s127><note.beachten><en> Note that the SOLIDWORKS Apps for Kids products and services are consumer products and subject to a separate privacy policy.
<G-vec00060-001-s128><note.beachten><de> Beachten Sie, dass wenn Sie diesen Prozess beenden, die Anwendung nicht neben entfernt werden.
<G-vec00060-001-s128><note.beachten><en> Note that if you terminate this process, the application will not be removed alongside.
<G-vec00060-001-s129><note.beachten><de> Beachten Sie, daß eine oder mehrere der gelben Punkte hin und wieder verschwinden, obwohl die drei gelben Punkte kontinuierlich vorhanden sind.
<G-vec00060-001-s129><note.beachten><en> Note that one or more of the yellow spots disappear once in a while, although the 3 yellow spots are continuously present.
<G-vec00060-001-s130><note.beachten><de> Beachten Sie auch, solange Sie das Medikament verwenden, bekommen Sie Ergebnis.
<G-vec00060-001-s130><note.beachten><en> Also note that as long as you take the drug you will get result.
<G-vec00060-001-s131><note.beachten><de> Wichtige Informationen Bitte beachten Sie, dass Kaffee- und Teezubehör an der Rezeption erhältlich ist.
<G-vec00060-001-s131><note.beachten><en> Please note that a tea/coffee maker and ironing facilities are available at the reception.
<G-vec00060-001-s132><note.beachten><de> Ja, Beachten Sie, dass alle auf Ihre Persönlichkeit abhängt, denn normalerweise egozentrischen Menschen Sie neigen dazu, mehr zu reden als hören.
<G-vec00060-001-s132><note.beachten><en> That Yes, Note that all depends on your personality, because normally egocentric people They tend to talk more than listen.
<G-vec00303-002-s076><follow.beachten><de> Bitte beachten Sie unsere Hinweise zu den Bildrechten.
<G-vec00303-002-s076><follow.beachten><en> Please follow our instructions to the copyrights.
<G-vec00303-002-s077><follow.beachten><de> Beachten Sie die dem Wagen beiliegenden Pflegeanleitungen oder kontaktieren Sie Ihre Emmaljunga Fachhändler.
<G-vec00303-002-s077><follow.beachten><en> Follow the care instructions supplied with the pram or contact your authorised retailer for care advice.
<G-vec00303-002-s078><follow.beachten><de> Bitte beachten Sie das auf dem RMA-Formular beschriebene Vorgehen.
<G-vec00303-002-s078><follow.beachten><en> Please follow the instructions on the RMA form.
<G-vec00303-002-s079><follow.beachten><de> Beachten Sie alle Installationsanweisungen stets genau.
<G-vec00303-002-s079><follow.beachten><en> Always follow installation instructions closely.
<G-vec00303-002-s080><follow.beachten><de> Beachten Sie unbedingt immer die nachfolgend aufgelisteten Vorsichtsmaßregeln, um mögliche körperliche Verletzungen bei Ihnen oder Dritten, oder Beschädigungen am Instrument oder an anderem Eigentum zu vermeiden.
<G-vec00303-002-s080><follow.beachten><en> Always follow the basic precautions listed below to avoid the possibility of physical injury to you or others, or damage to the
<G-vec00303-002-s081><follow.beachten><de> Grundlegende Sicherheitshinweise Beachten Sie für einen sicheren Umgang mit dem Gerät die folgenden Sicherheitshinweise: ■ Kontrollieren Sie das Gerät vor der Verwendung auf äußere sichtbare Schäden.
<G-vec00303-002-s081><follow.beachten><en> Basic safety guidelines To ensure safe handling of the appliance, follow the safety guidelines set out below ■ Prior to use, check the appliance for visible, external damage.
<G-vec00303-002-s082><follow.beachten><de> Beachten Sie die Verkehrsregeln: beachten Sie alle Ampeln und Schilder; fahren Sie nicht auf Fußwegen, Bürgersteigen, Autobahnen und in Fußgängerzonen.
<G-vec00303-002-s082><follow.beachten><en> Follow the rules of the road: adhere to all traffic lights and signs; don’t cycle on footpaths, shopping streets, pavements and motorways.
<G-vec00303-002-s083><follow.beachten><de> Bitte beachten Sie in diesem Fall die Hinweise der Stadt Braunschweig.
<G-vec00303-002-s083><follow.beachten><en> In this case please follow the instructions of the city of Braunschweig.
<G-vec00303-002-s084><follow.beachten><de> Wir empfehlen Ihnen, folgende goldene Regel zu beachten: Verwenden Sie immer ein Verhältnis mit mehr Wasser als Reinigungsmittel.
<G-vec00303-002-s084><follow.beachten><en> Follow this golden rule: Always use a solution with a far higher ratio of water to your cleaning product.
<G-vec00303-002-s085><follow.beachten><de> Bitte beachten Sie oben geschilderte Vorgehensweise.
<G-vec00303-002-s085><follow.beachten><en> Please follow the procedure detailed above.
<G-vec00303-002-s086><follow.beachten><de> Beachten Sie die Hinweise.
<G-vec00303-002-s086><follow.beachten><en> Follow the instructions.
<G-vec00303-002-s087><follow.beachten><de> Beachten Sie die in der Gebrauchsanleitung Ihrer Feuerstätte angegebene maximale Holzmenge und Anheizzeit.
<G-vec00303-002-s087><follow.beachten><en> Follow the maximum amounts of wood and heating times stated in the fireplace-specific instructions for use.
<G-vec00303-002-s088><follow.beachten><de> Bitte beachten Sie insoweit die aktuellen Datenschutzhinweise, die Sie hier abrufen können.
<G-vec00303-002-s088><follow.beachten><en> Please, follow in this respect thetopical data protection tips which youcan call away here.
<G-vec00303-002-s089><follow.beachten><de> Beachten Sie die Gebrauchsanweisung Ihres ASAP B71 (Modelle bis zur Seriennummer 13316LJ0087).
<G-vec00303-002-s089><follow.beachten><en> Follow the Instructions for Use for your ASAP B71 (models up to serial number 13316LJ0087).
<G-vec00303-002-s090><follow.beachten><de> Bitte beachten Sie die Gebrauchsanweisung um Ihren Baum optimal aufzubauen.
<G-vec00303-002-s090><follow.beachten><en> Please follow the instructions to set up your tree in the best possible way.
<G-vec00303-002-s091><follow.beachten><de> Beachten Sie, dass Sie in der Gratisversion von Airy die ersten 2 Videos umsonst herunterladen können.
<G-vec00303-002-s091><follow.beachten><en> Follow the steps: Download free Airy for Mac that offers 2 first downloads for free.
<G-vec00303-002-s092><follow.beachten><de> Wenn Sie zwischen 100 und 140 kg wiegen, lesen und beachten Sie bitte die Empfehlungen im Online Tool.
<G-vec00303-002-s092><follow.beachten><en> Solution for workers over 100kg If you weigh 100 to 140 kg, read and follow the
<G-vec00303-002-s093><follow.beachten><de> (1) Beachten Sie alle Warnungen und Anweisungen auf dem Gerät.
<G-vec00303-002-s093><follow.beachten><en> (1) Follow all warnings and instructions marked on the product.
<G-vec00303-002-s094><follow.beachten><de> Beachten Sie die Pflegeanleitung des Schuhherstellers.
<G-vec00303-002-s094><follow.beachten><en> Textile Gloves: Follow the manufacturer's instructions.
<G-vec00303-002-s253><heed.beachten><de> Wenn Sie die folgenden Tipps beachten, steht der Schnäppchenjagd nichts mehr im Weg.
<G-vec00303-002-s253><heed.beachten><en> Heed the following tips and nothing will stand in the way of the hunt for a good bargain.
<G-vec00303-002-s025><obey.beachten><de> Bitte beachten Sie die Nutzungsbedingungen und das Urheberrecht.
<G-vec00303-002-s025><obey.beachten><en> Please obey the terms of use and the copyright.
<G-vec00303-002-s026><obey.beachten><de> Fahren Sie bitte vorsichtig auf dem Parkplatz und in Schrittgeschwindigkeit (10km/h) und beachten Sie die Beschilderung.
<G-vec00303-002-s026><obey.beachten><en> Please drive carefully in the Car Park at not more than 5 mph and obey any directional signs.
<G-vec00303-002-s027><obey.beachten><de> •Beachten Sie die Sicherheitsanweisungen des Reinigungsmittelherstellers, um Verätzungen an Augen, Mund oder im Hals zu vermeiden.
<G-vec00303-002-s027><obey.beachten><en> •Obey the safety instructions from the detergent manufacturer to prevent burns to eyes, mouth and throat.
<G-vec00303-002-s028><obey.beachten><de> Kunden sind verpflichtet, in der Gruppe zu bleiben und die Anweisungen des Fremdenführers zu beachten.
<G-vec00303-002-s028><obey.beachten><en> The client is obliged to stay with the group and obey the instructions of the guide.
<G-vec00303-002-s029><obey.beachten><de> Alle Benutzer sollten die Regeln der U-Bahn beachten.
<G-vec00303-002-s029><obey.beachten><en> All users should obey the rules of the metro.
<G-vec00303-002-s030><obey.beachten><de> Prüfen und beachten Sie die Gesetze und Bestimmungen zur Nutzung von Mobilgeräten in den Regionen, in denen Sie mit dem Auto oder Fahrrad unterwegs sind.
<G-vec00303-002-s030><obey.beachten><en> Check and obey the laws and regulations on the use of mobile devices in the areas where you drive or ride.
<G-vec00303-002-s031><obey.beachten><de> Achte darauf alle Gesetze und Vorschriften bezüglich der Verwendung von Alkohol zu beachten.
<G-vec00303-002-s031><obey.beachten><en> Be sure to obey all laws and regulations regarding the use of alcohol.
<G-vec00303-002-s032><obey.beachten><de> Wir weisen darauf hin, dass Ihr Recht auf Löschung von personenbezogenen Daten durch gesetzliche Aufbewahrungspflichten, die wir beachten müssen, eingeschränkt sein kann.
<G-vec00303-002-s032><obey.beachten><en> Please note, that your right to data deletion may be limited by legal retention periods which we are required to obey. Emails
<G-vec00303-002-s033><obey.beachten><de> Beachtung der Zeichen:Jeder Skifahrer und Snowboarder muss die Markierung und Zeichengebungen beachten.
<G-vec00303-002-s033><obey.beachten><en> Paying attention to signs: Every skier and snowboarder must obey all signs, markings and signals.
<G-vec00303-002-s034><obey.beachten><de> Beachten Sie zu Ihrer eigenen Sicherheit die Schilder auf den Pisten.
<G-vec00303-002-s034><obey.beachten><en> For your safety, obey warning signs on trails.
<G-vec00303-002-s035><obey.beachten><de> Beachten Sie bitte alle Verordnungen und Empfehlungen über Geschwindigkeit für Fahrradfahrer.
<G-vec00303-002-s035><obey.beachten><en> Obey all bicycle speed regulations and recommendations. Always yield trail
<G-vec00303-002-s095><respect.beachten><de> Die Europäische Union erwartet, dass die betroffenen Parteien in der Region (sowohl in Bosnien und Herzegowina als auch in Serbien und in Montenegro) das Urteil des Internationalen Gerichtshofs akzeptieren und uneingeschränkt beachten.
<G-vec00303-002-s095><respect.beachten><en> The European Union expects the concerned parties in the region (both in Bosnia and Herzegovina as well as in Serbia and Montenegro) to accept and fully respect the verdict of the International Criminal Court.
<G-vec00303-002-s096><respect.beachten><de> Bitte Dresscode beachten, bitte Local Rules beachten.
<G-vec00303-002-s096><respect.beachten><en> Please respect dress code, please respect local rules.
<G-vec00303-002-s097><respect.beachten><de> Um ein Ereignis zu identifizieren, solltest Du bestimmte Auswahlkriterien beachten.
<G-vec00303-002-s097><respect.beachten><en> To identify an event you should respect certain selection criteria.
<G-vec00303-002-s098><respect.beachten><de> Geboren aus der anatomischen Studie und den jahrelangen Erfahrungen von Bassano Selle und dank eines speziellen elastischen Viskosematerials, ist die Sitzfläche des Bikers in 5 Zonen mit unterschiedlichen Tragfähigkeiten unterteilt, die die Kurven des Körpers beachten und eine individuelle Entlastung des Gewichts ermöglichen.
<G-vec00303-002-s098><respect.beachten><en> Born from the anatomical study and the experience of Bassano Selle, thanks to a special multi-density material and special ergonomics, we have divided the biker seating area into 5 anatomical zones with different lift for design and compliance, which respect and follow the curves of the body and allow the weight to be unloaded in a personalized way.
<G-vec00303-002-s099><respect.beachten><de> Bei der Beschaffung unserer Rohstoffe beachten wir die Vorschriften der REACH-Verordnung zur „Registrierung, Bewertung, Zulassung und Beschränkung chemischer Stoffe“.
<G-vec00303-002-s099><respect.beachten><en> As to the sourcing of our raw materials, we respect the regulations of “REACH” (Registration, Evaluation, Authorisation and Restriction of Chemicals).
<G-vec00303-002-s100><respect.beachten><de> Beim Treffen wurde ein Handlungsplan entwickelt, ein überregionales Team zur Vorbereitung des nächsten Treffens ernannt und ein Aufruf an die Bevölkerung verabschiedet: "Beachten wir alle Personen, Gruppen und Gemeinden genauso wie ihre Sitten und Gebräuche.
<G-vec00303-002-s100><respect.beachten><en> The Meeting determined a plan of action, designated an interregional team to plan the next meeting, and produced a call to all villages: "We take into account and respect all individuals, groups, and communities, as well as customs.
<G-vec00303-002-s101><respect.beachten><de> Alle Personen, die diese Vorrechte und Immunitäten genießen, haben, ohne Beeinträchtigung derselben, die Pflicht, die schweizerischen Gesetze und Reglemente zu beachten.
<G-vec00303-002-s101><respect.beachten><en> The vast majority of these internationals respect Swiss laws and regulations and comply with them the same as the local population.
<G-vec00303-002-s102><respect.beachten><de> Allerdings ist es wichtig, einige Hygienevorschriften zu beachten.
<G-vec00303-002-s102><respect.beachten><en> That said, it is important to respect certain hygiene rules.
<G-vec00303-002-s103><respect.beachten><de> Soweit handels- und steuerrechtliche Aufbewahrungsfristen zu beachten sind, kann die Dauer der Speicherung bestimmter Daten bis zu 10 Jahre betragen.
<G-vec00303-002-s103><respect.beachten><en> As far as we have to respect storage periods required by commercial and fiscal law, the duration of storage of certain data can be up to 10 years.
<G-vec00303-002-s104><respect.beachten><de> 3.2 Sämtliche relevanten behördlichen und gesetzlichen Auflagen des Staats, von dem aus abgeflogen wird, der angeflogen wird oder zum Umsteigen genutzt wird, zu beachten und einzuhalten.
<G-vec00303-002-s104><respect.beachten><en> 3.2 To respect and comply with all relevant official and legal requirements of the country from which the flight departs, the country to which the flight is headed, and/or the country in which transfers between flights take place.
<G-vec00303-002-s105><respect.beachten><de> Alle Clients und Werkzeuge, die auf FileMaker-Lösungen zugreifen, beachten die Berechtigungen der Benutzer.
<G-vec00303-002-s105><respect.beachten><en> All clients and tools that access FileMaker solutions respect users' privilege sets.
<G-vec00303-002-s106><respect.beachten><de> 4.3) Der Benutzer verpflichtet sich, das Urheberrecht derjenigen zu beachten, die ihre Beiträge auf den Websites "Parajumpers.it" veröffentlichen oder in irgendeiner Weise an den Websites "Parajumpers.it" mitarbeiten zur Schaffung von Texten und künstlerischen Beiträgen, die zur Veröffentlichung bestimmt sind, auch wenn diese nicht ausschließlich über die Website veröffentlicht werden oder wenn diese die Website ergänzen.
<G-vec00303-002-s106><respect.beachten><en> 4.3) The user undertakes to respect the copyright of those who publish their works on "Parajumpers.it" or who collaborate in any way with "Parajumpers.it" in the creation of any expressive or artistic form destined for publication, even those not exclusively for the website or that do not form an integral part of it.
<G-vec00303-002-s107><respect.beachten><de> (22) Bei der Regelung der Kontrolle von Unternehmenszusammenschlüssen ist unbeschadet des Artikels 86 Absatz 2 des Vertrags der Grundsatz der Nichtdiskriminierung zwischen dem öffentlichen und dem privaten Sektor zu beachten.
<G-vec00303-002-s107><respect.beachten><en> (22) The arrangements to be introduced for the control of concentrations should, without prejudice to Article 86(2) of the Treaty, respect the principle of non-discrimination between the public and the private sectors.
<G-vec00303-002-s108><respect.beachten><de> Jeder Ski- oder Snowboardfahrer muss die Markierung und die Signalisation beachten.
<G-vec00303-002-s108><respect.beachten><en> A skier or snowboarder must respect all signs and markings.
<G-vec00303-002-s109><respect.beachten><de> Bei alledem gilt es die Erfordernisse einer nachhaltigen Raumentwicklung zu beachten und Chancen für die Stadtentwicklungen der jeweiligen Länder zu nutzen.
<G-vec00303-002-s109><respect.beachten><en> In all of these possibilities, it will be important to respect the requirements of a sustainable spatial development and to use the opportunities for the urban development of the respective countries.
<G-vec00303-002-s110><respect.beachten><de> Bitte beachten Sie diese und befolgen Sie diese hinweise.
<G-vec00303-002-s110><respect.beachten><en> Please respect and follow these.
<G-vec00303-002-s111><respect.beachten><de> Alle Fahrzeuge, insbesondere Motorfahrzeuge, dürfen nur zum Ein- und Ausfahren und nur während der erlaubten Zeiten benützt werden.Es ist innerhalb des Campinggeländes sehr langsam zu fahren (max.10 km/h) und die errichteten Hinweisschilder sind zu beachten.
<G-vec00303-002-s111><respect.beachten><en> All kinds of vehicles, particularly motorized ones, can be used only for moving to and from the campsite during the permitted Drivers must keep a very moderate speed (10 km/h) and respect the various signs within the campsite.
<G-vec00303-002-s112><respect.beachten><de> Bitte beachten Sie, dass medizinische Fragen nicht per Mail beantwortet werden können.
<G-vec00303-002-s112><respect.beachten><en> Please respect that I cannot answer medical questions via e-mail.
<G-vec00303-002-s113><respect.beachten><de> In den verbindlichen Unternehmensrichtlinien von Schneider Electric beachten und berücksichtigen wir die wichtigsten Grundsätze der EU-Datenschutzregelungen, da sich unser Firmenhauptsitz in der Europäischen Union befindet.
<G-vec00303-002-s113><respect.beachten><en> In Telemecanique Sensors’s Binding Corporate Rules, we respect and take into account the major principles of EU data protection rules as our Head Office is located in the European Union.
<G-vec00316-002-s036><comply.beachten><de> Wir beachten alle gesetzlichen Vorgaben zum Datenschutz.
<G-vec00316-002-s036><comply.beachten><en> We comply with all current legislation on data protection.
<G-vec00316-002-s037><comply.beachten><de> Der Veranstalter verpflichtet sich, die Angaben des Kunden im Rahmen des Angebots zu beachten.
<G-vec00316-002-s037><comply.beachten><en> The Organizer undertakes to comply with the indications of the Client as part of the Offer.
<G-vec00316-002-s038><comply.beachten><de> Bei PUBLISHERN im europäischen Raum ist dabei die Cookie-Richtlinie zu beachten, welche im Unterschied zum schweizerischen Recht eine ausdrückliche Zustimmung des Nutzers verlangt (Opt-In).
<G-vec00316-002-s038><comply.beachten><en> PUBLISHERS in Europe must comply with the Cookie Directive, which in contrast to Swiss law requires the explicit consent of the user (opt-in). 4.
<G-vec00316-002-s039><comply.beachten><de> Unterbleibt eine solche Mitteilung, so enthebt dies keine der Parteien der Verpflichtung, die Bestimmungen des Absatzes 1 zu beachten.
<G-vec00316-002-s039><comply.beachten><en> The absence of such notification shall not exempt any of the Parties from the obligation to comply with the provisions of paragraph 1.
<G-vec00316-002-s040><comply.beachten><de> Wer als Importeur, Hersteller oder Händler Spielzeug in Verkehr bringt, muss eine Vielzahl gesetzlicher und untergesetzlicher Vorgaben beachten.
<G-vec00316-002-s040><comply.beachten><en> Whoever places cosmetics on the market as importer, manufacturer or dealer must comply with a variety of statutory and administrative requirements.
<G-vec00316-002-s041><comply.beachten><de> Wir beachten dabei das für Deutschland geltende Datenschutzrecht.
<G-vec00316-002-s041><comply.beachten><en> In this connection we comply with the data protection legislation applicable to Germany.
<G-vec00316-002-s042><comply.beachten><de> 13.1 Die Parteien verpflichten sich gegenseitig, die gesetzlichen Bestimmungen über den Datenschutz, insbesondere die EU-Datenschutzgrundverordnung („DSGVO“) in Ausführung des Vertrages zu beachten und die Einhaltung dieser Bestimmungen ihren Mitarbeitern aufzuerlegen.
<G-vec00316-002-s042><comply.beachten><en> 13.1 The parties mutually undertake to comply with the statutory provisions on data protection, in particular the EU General Data Protection Regulation ("GDPR") in the execution of the contract and to impose compliance with these provisions on their employees.
<G-vec00316-002-s043><comply.beachten><de> Diese Regelung dürfte jedoch keine Auswirkungen auf Fische aus Kulturen haben, da bei den Futtermitteln für diese Fische ein strikter Hoechstgehalt zu beachten ist, der dazu führt, dass bei der Produktion von Fischen in Kulturen der betreffende Hoechstgehalt für Dioxine nicht erreicht wird.
<G-vec00316-002-s043><comply.beachten><en> It is unlikely to have an impact on farmed fish, since feed for fish has to comply with a strict maximum level resulting in the production of farmed fish respecting the maximum level for dioxins set for fish.
<G-vec00316-002-s044><comply.beachten><de> Der Lieferant verpflichtet sich die geltenden Gesetze und Normen zu beachten.
<G-vec00316-002-s044><comply.beachten><en> The supplier undertakes to comply with all applicable laws and standards.
<G-vec00316-002-s045><comply.beachten><de> Wir beachten bei den Adressdaten die Bestimmungen der schweizerischen und der europäischen Datenschutzgesetzgebungen.
<G-vec00316-002-s045><comply.beachten><en> We comply with Swiss and European data protection regulations governing address data.
<G-vec00316-002-s046><comply.beachten><de> Urheberrecht Die Bayerische Medien Technik (GmbH) ist bestrebt geltende Urheberrechte zu beachten.
<G-vec00316-002-s046><comply.beachten><en> Copyright Bayerische Medien Technik (GmbH) tries to comply with existing copyrights at all times.
<G-vec00316-002-s047><comply.beachten><de> Einflussreiche Politikdidaktiker - zunächst für den schulischen Bereich – schlugen darin drei Grundprinzipien vor, was Politische Bildung beachten muss.
<G-vec00316-002-s047><comply.beachten><en> Influential political education - first for schools - was to propose three principles, which must comply with political education.
<G-vec00316-002-s048><comply.beachten><de> Die HKI-Hersteller richten sich hier nach dem aktuellen Stand der Technik und beachten bei der Produktion die strengen Regeln der Hygiene und Arbeitssicherheit.
<G-vec00316-002-s048><comply.beachten><en> The HKI manufacturers operate according to standards to the current status of technology and comply during the production with the strict rules of hygiene and occupational safety.
<G-vec00316-002-s049><comply.beachten><de> Das Weblinkbuch ist bestrebt, auf allen Seiten geltende Urheberrechte zu beachten.
<G-vec00316-002-s049><comply.beachten><en> In all publications, Weblinkbuch endeavours to comply with applicable copyrights.
<G-vec00316-002-s050><comply.beachten><de> Wenn Sie die registrierte Marke AOE zitieren möchten, so bitten wir Sie, die folgenden Regeln für den Umgang mit Marken zu beachten.
<G-vec00316-002-s050><comply.beachten><en> If you would like to use the registered trademark “AOE” we would ask you to comply with the following guidelines regarding trademark use.
<G-vec00316-002-s051><comply.beachten><de> In dieser Entschließung heißt es aber, dass die fraglichen Fristen ausschließlich zur Beschleunigung des Verfahrens dienten, und der Rat wird lediglich „aufgefordert“ (und damit nicht förmlich verpflichtet), sie zu beachten (14) .
<G-vec00316-002-s051><comply.beachten><en> However, the resolution itself clearly states that the deadlines in question are intended solely to speed up the procedure and merely ‘urges’ (rather than formally obliges) the Council to comply with them. (14)
<G-vec00316-002-s052><comply.beachten><de> Darüber hinaus hat Fresenius weitere allgemein anwendbare Rechtsvorschriften zu beachten, die sich von Land zu Land unterscheiden.
<G-vec00316-002-s052><comply.beachten><en> In addition, Fresenius has to comply with general rules of law, which differ from country to country.
<G-vec00316-002-s053><comply.beachten><de> Sie dürfen diese nicht zu anderen Zwecken verwenden und sind verpflichtet, diese Datenschutzerklärung und die Datenschutzgesetze und Vorschriften zu beachten.
<G-vec00316-002-s053><comply.beachten><en> They are not permitted to use the data for other purposes and are required to comply with this privacy statement, the data protection laws and regulations.
<G-vec00316-002-s054><comply.beachten><de> Bei der Erhebung, Verarbeitung und Nutzung Ihrer personenbezogenen Daten beachten wir die einschlägigen datenschutzrechtlichen Bestimmungen, insbesondere die Bestimmungen des Bundesdatenschutzgesetzes (BDSG) und des Telemediengesetzes (TMG).
<G-vec00316-002-s054><comply.beachten><en> In the collection, processing and use of your personal data, we comply with the relevant data protection provisions, in particular the provisions of the German Federal Data Protection Act (BDSG) and Telemedia Act (TMG).
<G-vec00364-002-s076><remember.beachten><de> Beachte, dass alle Daten im Computer eine feste Gro¨ße (in der Anzahl Bits) haben.
<G-vec00364-002-s076><remember.beachten><en> Remember that all data on the computer is of some fixed size (in terms of number of bits).
<G-vec00364-002-s077><remember.beachten><de> Beachte jedoch – auch ein neues Bike musst du nutzen, wenn du fitter werden willst.
<G-vec00364-002-s077><remember.beachten><en> But remember – you aren’t going to get any fitter if you don’t use your new bike.
<G-vec00364-002-s078><remember.beachten><de> Bitte beachte, dass Informationen mit ihrer Offenlegung auf diesen Plattformen öffentliche Informationen werden, zu deren Nutzung und Weitergabe wir ebenso wie andere Nutzer berechtigt sind.
<G-vec00364-002-s078><remember.beachten><en> Please remember that any information that is disclosed in these areas becomes public information for both us and other users to use and share.
<G-vec00364-002-s079><remember.beachten><de> Aber beachte: Du kannst nur ein Licht-Modi und eine Farbe zur gleichen Zeit auswählen.
<G-vec00364-002-s079><remember.beachten><en> But remember, you can only choose one lighting mode and one colour at a time.
<G-vec00364-002-s080><remember.beachten><de> Beachte, dass nicht alle die gleichen Spiele zeigen.
<G-vec00364-002-s080><remember.beachten><en> Remember that not all of them stream the same games.
<G-vec00364-002-s081><remember.beachten><de> Beachte, dass die Daten Zahlen, eine Geschichte, Text oder Bilder sein können, die die Ergebnisse eines Experiments erklären.
<G-vec00364-002-s081><remember.beachten><en> Remember that the data can be in the form of numbers, a story, text, web page, or images that explain the outcome of an experiment.
<G-vec00364-002-s082><remember.beachten><de> Beachte, dass der Nutzer kein Anfänger ist.
<G-vec00364-002-s082><remember.beachten><en> Remember that the user isn’t a novice.
<G-vec00364-002-s083><remember.beachten><de> Verwende dein "WAK Geld" bei deinem nächsten Einkauf Beachte, dass du den Einkauf mit deinem Konto tätigst, auf dem du das virtuelle 'WAK Geld' angesammelt hast.
<G-vec00364-002-s083><remember.beachten><en> Next time you make a purchase! But remember, you must make the purchase using your personal account with which you have accumulated that virtual money.
<G-vec00364-002-s084><remember.beachten><de> Beachte, dass Sprites von anderen nur mit deren Erlaubnis verwendet werden dürfen oder wenn sie Freeware sind.
<G-vec00364-002-s084><remember.beachten><en> Please remember that you are only allowed to use images created by others when you have their permission or when they are freeware.
<G-vec00364-002-s085><remember.beachten><de> Beachte auch, dass du nicht länger als 12 Monate an einem der The Student Hotel Standorte wohnen kannst.
<G-vec00364-002-s085><remember.beachten><en> Also remember that you cannot stay longer than 12 months in one TSH location.
<G-vec00364-002-s086><remember.beachten><de> Bitte beachte, dass an Sonn- und Feiertagen keine Zustellung erfolgt.
<G-vec00364-002-s086><remember.beachten><en> Please remember that there can be no delivery on Sundays or holidays.
<G-vec00364-002-s087><remember.beachten><de> Bitte beachte: Diese Anwendung ist kein Ersatz für einen ausgebildeten Arzt.
<G-vec00364-002-s087><remember.beachten><en> Please remember: This application should not replace the care of a trained physician.
<G-vec00364-002-s088><remember.beachten><de> Beachte: Es ist besser, ein relativ leeres Haus zu zeigen, als eins, das bis unters Dach mit Krempel gefüllt ist.
<G-vec00364-002-s088><remember.beachten><en> Remember that it's better to show a somewhat barren house than one that's filled to the brim with clutter.
<G-vec00364-002-s089><remember.beachten><de> Beachte, dass du als Autor dafür verantwortlich bist, dass die Tags richtig geschlossen werden.
<G-vec00364-002-s089><remember.beachten><en> Remember that it is up to you to ensure that tags are closed correctly.
<G-vec00364-002-s090><remember.beachten><de> Beachte, dass das Ergebnis heller wird, wenn du ein Blondiermittel mit 30 oder 40 Volumen verwendest, aber dementsprechend aggressiver wirkt es dann auch auf deiner Kopfhaut.
<G-vec00364-002-s090><remember.beachten><en> Remember that you will get a higher lift if you use 30 or 40 volume. They also have a higher risk of burning your scalp. 3
<G-vec00316-003-s041><abide_by.beachten><de> Für Streitigkeiten mit einem Gesamtstreitwert von bis zu $10.000 müssen die AAA, Sie und 99designs folgende Regeln beachten: (a) das Schiedsverfahren darf nur auf der Grundlage schriftlicher Eingaben durchgeführt werden; und (b) das Schiedsverfahren beinhaltet kein persönliches Erscheinen der Parteien oder von Zeugen, es sei denn, dies wird von den Parteien einvernehmlich vereinbart.
<G-vec00316-003-s041><abide_by.beachten><en> For any claim where the total amount of the award sought is $10,000 or less, the AAA, you and Covoco must abide by the following rules: (a) the arbitration shall be conducted solely based on written submissions; and (b) the arbitration shall not involve any personal appearance by the parties or witnesses unless otherwise mutually agreed by the parties.
<G-vec00316-003-s042><abide_by.beachten><de> Der Kunde hat diese Vorschriften vollumfänglich zu beachten und zu keinem Zeitpunkt beim Verkäufer gekaufte Produkte an die iranische Gas- und Ölindustrie weder direkt noch indirekt zu liefern, noch diese Vorschriften auf irgendeine Weise zu umgehen.
<G-vec00316-003-s042><abide_by.beachten><en> The client shall comprehensively abide by these regulations, save their direct or indirect applicability and shall never supply products purchased from the vendor to the Iranian oil and gas industry nor directly or indirectly get round these Regulations in any manner whatsoever.
<G-vec00316-003-s043><abide_by.beachten><de> Der Kunde verpflichtet sich, die eventuellen besonderen Zugangsbedingungen in Bezug auf Haustiere zu beachten.
<G-vec00316-003-s043><abide_by.beachten><en> The Client undertakes to abide by any special conditions of access to the accommodation concerning pets.
<G-vec00316-003-s044><abide_by.beachten><de> Die in der VIP Lounge geltenden Bestimmungen sind von Mitgliedern und Gästen gleichermaßen zu beachten.
<G-vec00316-003-s044><abide_by.beachten><en> Both members and guests are expected to abide by all relevant VIP lounge regulations.
<G-vec00316-003-s045><abide_by.beachten><de> Selbstverständlich beachten wir die gesetzlichen Bestimmungen des Datenschutzgesetzes (BDSG) des Telemediengesetzes (TMG) und anderer datenschutzrechtlicher Bestimmungen.
<G-vec00316-003-s045><abide_by.beachten><en> Naturally, we abide by the legal provisions of the German Federal Data Protection Act (BDSG), the German Telemedia Act (TMG) and any other applicable data protection regulations.
<G-vec00316-003-s046><abide_by.beachten><de> Ich erkläre hiermit, von den allgemeinen Geschäftsbedingungen Kenntnis genommen zu haben und sie zu beachten.
<G-vec00316-003-s046><abide_by.beachten><en> I have familiarised myself with the general conditions and agree to abide by them. See conditions Miscellaneous
<G-vec00316-003-s047><abide_by.beachten><de> Sie verpflichten sich, alle zusätzlichen urheberrechtlichen Vermerke, Informationen oder Beschränkungen zu beachten, die in irgendeinem Teil von TechTarget’s Netzwerk von deutschen Webseiten enthalten sind.
<G-vec00316-003-s047><abide_by.beachten><en> You agree to abide by any and all additional copyright notices, information, or restrictions contained in any part of TechTarget’s German Network of Sites.
<G-vec00316-003-s048><abide_by.beachten><de> Sie dürfen die Dateien, die das Werk oder zulässige abgeleitete Werke enthalten, an Mitarbeiter oder Vertragsnehmer unter der Voraussetzung übermitteln, dass die betreffenden Mitarbeiter und Vertragsnehmer die Einschränkungen dieses Vertrags beachten und das Werk nur in Ihrem Auftrag verwenden.
<G-vec00316-003-s048><abide_by.beachten><en> You may transfer files containing the Work or permitted derivative works to employees or subcontractors, provided that such employees and subcontractors agree to abide by the restrictions of this Agreement and only use the Work on your behalf.
<G-vec00316-003-s049><abide_by.beachten><de> Bitte beachten Sie die Allgemeinen Geschäftsbedingungen von Facebook, Twitter, Instagram und Youtube.
<G-vec00316-003-s049><abide_by.beachten><en> Always abide by the terms and conditions of use of Facebook, Twitter, Instagram and YouTube.
<G-vec00316-003-s050><abide_by.beachten><de> Während des Ramadans müssen alle Besucher Dubais unabhängig von ihrer Region das Fastengebot in der Öffentlichkeit beachten.
<G-vec00316-003-s050><abide_by.beachten><en> During Ramadan everyone who visits Dubai, regardless of their religion, should abide by the fast in public throughout their visit.
<G-vec00316-003-s051><abide_by.beachten><de> Sie stimmen zu, diese Lizenz bei Ihrer Installation und Nutzung der App zu beachten.
<G-vec00316-003-s051><abide_by.beachten><en> You agree to abide by this License in Your installation and use of the App.
