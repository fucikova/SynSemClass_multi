<G-vec00555-002-s030><eject.ausstoßen><de> Wenn du iPod als Festplatte benutzt, mußt du sie ausstoßen, bevor Sie sie von deinem Computer trennen.
<G-vec00555-002-s030><eject.ausstoßen><en> If you are using iPod as a hard disk, you must eject it before disconnecting it from your computer.
<G-vec00555-002-s023><expel.ausstoßen><de> Die geometrische Form dieser Klauenkolben ist so gestaltet, dass sie bei jeder Drehbewegung Luft ansaugen, verdichten und wieder ausstoßen.
<G-vec00555-002-s023><expel.ausstoßen><en> The geometric shape of these claws is designed so that with each rotation movement they draw in air, compress it and expel it again.
