<G-vec00092-001-s209><need.braucht><de> JUKI Automation Systems GmbH in Nürnberg (Deutschland) stellt auf einer Fläche von über 3000 m2 alles zur Verfügung, was es braucht, um den Kunden einen erstklassigen Service zu garantieren.
<G-vec00092-001-s209><need.braucht><en> With a space of approximately 3’000 m2, JUKI Automation Systems GmbH in Nuremberg (Germany) provides all you need to ensure a first-class customer service.
<G-vec00092-001-s210><need.braucht><de> Benutzung von ausgefallenen Bildergalerien und JavaScript-Effekten – Man braucht keine automatischen Bildergalerien oder rotierende Banner.
<G-vec00092-001-s210><need.braucht><en> Using fancy slider and Javascript effects – You don't need to use those automatic image sliders or rotating banners.
<G-vec00092-001-s211><need.braucht><de> Zu jeder Kunst gehören zwei: einer, der sie macht, und einer, der sie braucht.
<G-vec00092-001-s211><need.braucht><en> Art needs two: one to make it and one to need it. Ernst Barlach, 1917
<G-vec00092-001-s212><need.braucht><de> """Es braucht mehr Häuser in verschiedenen Landesteilen"", sagt das Gründungsmitglied, während er über künftige Pläne spricht."
<G-vec00092-001-s212><need.braucht><en> """We realise that we need more houses in different parts of the country,"" Hunziker explains, while talking about their plans for the future."
<G-vec00092-001-s213><need.braucht><de> (Wem die deutsche Version genügt, braucht keinen neuen Download durchzuführen, da sonst keine weiteren funktionalen Änderungen enthalten sind.
<G-vec00092-001-s213><need.braucht><en> (If you only need a German user interface you do not need to download the new version as no additional functional changes are included.
<G-vec00092-001-s214><need.braucht><de> Hier braucht man nicht weiter zu schauen als nach der Vergangenheit dieser Person, um ihre Absicht zu erkennen.
<G-vec00092-001-s214><need.braucht><en> Here one need look no further than the individual’s past history to discern their intent.
<G-vec00092-001-s215><need.braucht><de> Aber, um ehrlich zu sein, Israel braucht die Mauer nicht; es hat das Land bereits eingenommen.
<G-vec00092-001-s215><need.braucht><en> But to be honest, Israel does not need the Wall. They have already conquered the land.
<G-vec00092-001-s216><need.braucht><de> Wer Deutschland nicht kennt, kann nur schwer schätzen, wie viel Geld man hier wirklich braucht.
<G-vec00092-001-s216><need.braucht><en> If you do not know Germany very well, it is difficult to guess how much money you will really need here.
<G-vec00092-001-s217><need.braucht><de> Vivek Ramaswamy: In der Biotech-Branche braucht man drei wesentliche Elemente, um ein grossartiges Unternehmen aufzubauen: wirksame Arzneimittel, gute Mitarbeitende und ausreichend Kapital.
<G-vec00092-001-s217><need.braucht><en> Vivek Ramaswamy: In biotech you need three main ingredients to build a great company: good drugs, good people, and sufficient capital.
<G-vec00092-001-s218><need.braucht><de> Um Diversity voranzutreiben, braucht es sowohl Männer als auch Frauen.
<G-vec00092-001-s218><need.braucht><en> To promote diversity, you need both men and women.
<G-vec00092-001-s219><need.braucht><de> Der beste Weg, nichts wegwerfen zu müssen, ist daher nur genau so viel zu kaufen, wie man wirklich braucht.
<G-vec00092-001-s219><need.braucht><en> The best way to avoid spoilage in this case is to only buy what you need.
<G-vec00092-001-s220><need.braucht><de> Oft braucht man vor Allem bei der Verarbeitung größerer Schmuckperlen eine solche Perle als eine Art Gelenk, damit die Halskette am Ende besser fällt.
<G-vec00092-001-s220><need.braucht><en> Often you will need in the processing of larger jewelry beads such a pearl as a kind of joint, so that the necklace falls at the end better.
<G-vec00092-001-s221><need.braucht><de> Die Tochter braucht also dringend Verbündete, die zu ihr eine Verbindung herstellen können.
<G-vec00092-001-s221><need.braucht><en> The daughter is in urgent need of allies, capable of establishing a contact with her.
<G-vec00092-001-s222><need.braucht><de> Mittlerweile braucht man einen Helikopter, der einen ab Pokhara ins Basecamp fliegt.
<G-vec00092-001-s222><need.braucht><en> By now you need a helicopter to fly you from Pokhara into basecamp.
<G-vec00092-001-s223><need.braucht><de> Wer anderen auf Augenhöhe begegnen und eingreifende Veränderungen begleiten möchte, braucht Persönlichkeit und fundierte Kenntnisse in den unterschiedlichsten Fachgebieten und Branchen.
<G-vec00092-001-s223><need.braucht><en> Those who want to meet others at eye level and accompany interfering changes need personality and a good knowledge in the most diverse subject areas and sectors.
<G-vec00092-001-s224><need.braucht><de> Entgegen einer weit verbreiteten Idee braucht die schwangere Frau Salz in ihrer Ernährung, um den Anstieg ihrer Blutmenge auszugleichen, die sich um ungefähr 50% erhöht.
<G-vec00092-001-s224><need.braucht><en> Contrary to a once popular belief, pregnant women need salt in their diet to compensate for the increased blood volume, which increases by nearly 50%.
<G-vec00092-001-s225><need.braucht><de> Die Stadt hat alles zu bieten, was man für einen romantischen Kurzurlaub braucht: beeindruckende Architektur, elegante Parks und Gärten sowie Aktivitäten, bei denen man sich näherkommen kann.
<G-vec00092-001-s225><need.braucht><en> It’s got everything you need for a couples’ escape – gorgeous architecture, elegant parks and gardens, and activities to bring you closer together.
<G-vec00092-001-s226><need.braucht><de> Um diese herzustellen, braucht man zunächst ein 3D-Modell des Kopfes des zu behandelnden Säuglings.
<G-vec00092-001-s226><need.braucht><en> To produce these you first need to create a 3D model of the infant's head.
<G-vec00092-001-s227><need.braucht><de> Er braucht kein erschaffenes Wesen, aber wir brauchen ihn.
<G-vec00092-001-s227><need.braucht><en> He does not need any created being, but we do need Him.
