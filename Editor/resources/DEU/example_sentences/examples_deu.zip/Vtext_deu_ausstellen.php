<G-vec00169-001-s085><reclaim.ausstellen><de> Nach dem Fest werden gefundene Gegenstände hier auf der Homepage ausgestellt.
<G-vec00169-001-s085><reclaim.ausstellen><en> After the event you may contact us to reclaim lost items.
<G-vec00351-002-s076><issue.ausstellen><de> Als eingetragene und anerkannte Non-Profit- Organisation dürfen wir Spendenquittungen ausstellen die steuerlich geltend gemacht werden können.
<G-vec00351-002-s076><issue.ausstellen><en> As a registered and recognized non-profit organization, we may issue donation receipts that can be claimed for tax purposes.
<G-vec00351-002-s077><issue.ausstellen><de> Wenn wir einen Flugschein ohne Sitzplatzreservierung ausstellen kann später vorbehaltlich Platzverfügbarkeit auf dem fraglichen Flug gemäß unseren Tarifbestimmungen ein Platz reserviert werden.
<G-vec00351-002-s077><issue.ausstellen><en> If we issue you with a Ticket which doesn’t have a confirmed Booking for a seat on a Flight, it may be possible to make a reservation at a later time providing you pay the Tariff and if there is space on the Flight requested.
<G-vec00351-002-s078><issue.ausstellen><de> Der Administrator muss das Zertifikat ausdrücklich ausstellen.
<G-vec00351-002-s078><issue.ausstellen><en> The administrator must explicitly issue the certificate.
<G-vec00351-002-s079><issue.ausstellen><de> Dieses Zertifikat ist die Voraussetzung dafür, dass die Behörden einen Fahrzeugbrief ausstellen, mit dem der Besitzer das Fahrzeug später zulassen kann.
<G-vec00351-002-s079><issue.ausstellen><en> This certificate is the prerequisite for the authorities to issue a vehicle registration document with which the owner can later register the vehicle.
<G-vec00351-002-s080><issue.ausstellen><de> Bevor Sie ein Haus kaufen, wird Ihnen der Hypothekaranbieter eine Offerte ausstellen.
<G-vec00351-002-s080><issue.ausstellen><en> Before you buy a house, a mortgage lender will issue you a quote.
<G-vec00351-002-s081><issue.ausstellen><de> Das heißt, Sie können später für alle genannten SSL Domänen ein beliebiges SSL Zertifikat, das Sie bestellt haben, ausstellen.
<G-vec00351-002-s081><issue.ausstellen><en> It is possible to issue any ordered SSL certificate for any specified domain.
<G-vec00351-002-s082><issue.ausstellen><de> Aktionäre können per Internet eine Eintrittskarte zur Hauptversammlung bestellen oder eine Vollmacht ausstellen.
<G-vec00351-002-s082><issue.ausstellen><en> Using the internet, shareholders can order an admission ticket for the shareholders’ meeting and issue a proxy.
<G-vec00351-002-s083><issue.ausstellen><de> Der Anbieter wird Ihnen ein Einladungsschreiben für Ihr Visum ausstellen.
<G-vec00351-002-s083><issue.ausstellen><en> The supplier will issue you with an invitation letter for your visa.
<G-vec00351-002-s084><issue.ausstellen><de> Die Kirche solle ein Dokument, ein schriftlicher Nachweis ausstellen, dass die Person jetzt biblische Taufe empfangen hat.
<G-vec00351-002-s084><issue.ausstellen><en> The church should issue a document, a written evidence, that the candidate now has received biblical baptism.
<G-vec00351-002-s085><issue.ausstellen><de> Jetzt können Sie alle Ihre SSL-Zertifikate an einer zentralen Stelle verwalten, erwerben, ausstellen, verlängern und nachverfolgen.
<G-vec00351-002-s085><issue.ausstellen><en> Manage, purchase, issue, renew, and track all your SSL certificates in one place.
<G-vec00351-002-s086><issue.ausstellen><de> Das Problem entsteht, wenn Sie mehrere Zertifikate für neue Mitarbeiter ausstellen müssen und diese schnell installiert werden müssen.
<G-vec00351-002-s086><issue.ausstellen><en> The problem comes when you need to issue multiple certificates for new employees and have them installed quickly.
<G-vec00351-002-s087><issue.ausstellen><de> Allerdings sollte die Mitnahme der Medikamente vorher mit dem Hausarzt durchgesprochen werden, der ein Attest ausstellen kann – denn eine uneingeschränkte Medikamenteneinfuhr ist nicht weltweit gestattet.
<G-vec00351-002-s087><issue.ausstellen><en> The medications to be taken along should however first be discussed with a general practitioner, who can issue a doctor’s certificate – because some countries have import restrictions for drugs.
<G-vec00351-002-s088><issue.ausstellen><de> Die Mitgliedstaaten können diese Führerscheine auch mit einer Gültigkeitsdauer von bis zu 15 Jahren ausstellen.
<G-vec00351-002-s088><issue.ausstellen><en> A Member State may choose to issue such licences with an administrative validity of up to 15 years;
<G-vec00351-002-s089><issue.ausstellen><de> Für Online-Bestellungen, die in Shops retourniert werden, können wir dir eine Gutschrift ausstellen oder den Betrag zurück überweisen.
<G-vec00351-002-s089><issue.ausstellen><en> For online orders that are returned to a shop, we can either issue a credit note or refund the amount.
<G-vec00351-002-s090><issue.ausstellen><de> So können Sie EMDs anzeigen, aktualisieren, prüfen, ausstellen, ausdrucken, löschen und neu ausstellen.
<G-vec00351-002-s090><issue.ausstellen><en> This allows you to display, update, review, issue, print, void or reissue EMDs.
<G-vec00351-002-s091><issue.ausstellen><de> Khartum (Fides) – Das Ministeriums für religiöse Angelgenheiten im Sudan verkündete, dass die Regierung keine Genehmigungen zum Bau neuer Kirchengebäude im Land mehr ausstellen werde.
<G-vec00351-002-s091><issue.ausstellen><en> Khartoum (Agenzia Fides) - The Sudanese Minister of Guidance and religious Endowments announced that the government will not issue permits anymore for the construction of new churches in the country.
<G-vec00351-002-s092><issue.ausstellen><de> Billdu ist ein Cloud-basiertes Rechnungssystem für Freiberufler und kleine Unternehmen, die das Erstellen und Ausstellen von Rechnungen, Verwalten von Online-Shops, Nachverfolgen von Kosten, Erfassen von Kundenfeedback und vieles mehr ermöglicht.
<G-vec00351-002-s092><issue.ausstellen><en> Billdu is a cloud-based invoicing system designed for freelancers and small businesses which can be used to create and issue invoices, manage online stores, track expenses, capture customer feedback, and more.
<G-vec00351-002-s093><issue.ausstellen><de> Außerdem haben Anwälte einen besseren Ruf als Inkasso-/Factoring-Unternehmen: Dadurch, dass sie professioneller und individueller auftreten, werden sie allgemein eher respektiert als Unternehmen, die zumeist etliche Forderungen pro Tag ausstellen, ohne sich dabei auf den spezifischen Fall konzentrieren zu können.
<G-vec00351-002-s093><issue.ausstellen><en> In addition, lawyers have a better reputation than debt collection agencies/factoring companies. Since they are more professional and focus on the individual more, they are generally more respected than companies that issue countless claims per day without being able to focus on a specific case.
<G-vec00351-002-s094><issue.ausstellen><de> Wenn Sie mithilfe von CAA einschränken möchten, welche Zertifizierungsstellen Zertifikate für Ihre Domain ausstellen dürfen, müssen Sie einen DNS-Anbieter verwenden, der die Einstellung von CAA-Einträgen unterstützt.
<G-vec00351-002-s094><issue.ausstellen><en> If you would like to use CAA to restrict which Certificate Authorities are allowed to issue certificates for your domain, you will need to use a DNS provider that supports setting CAA records.
<G-vec00380-002-s081><dispense.ausstellen><de> Eine Ausgabeeinheit für Karten im ISO-Format ist in der Lage, berührungslose Karten zu codieren und auszustellen.
<G-vec00380-002-s081><dispense.ausstellen><en> An ISO format card dispenser is able to encode and dispense contactless cards.
