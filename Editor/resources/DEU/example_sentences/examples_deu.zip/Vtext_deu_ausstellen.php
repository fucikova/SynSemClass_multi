<G-vec00169-001-s085><reclaim.ausstellen><de> Nach dem Fest werden gefundene Gegenstände hier auf der Homepage ausgestellt.
<G-vec00169-001-s085><reclaim.ausstellen><en> After the event you may contact us to reclaim lost items.
<G-vec00351-002-s076><issue.ausstellen><de> Als eingetragene und anerkannte Non-Profit- Organisation dürfen wir Spendenquittungen ausstellen die steuerlich geltend gemacht werden können.
<G-vec00351-002-s076><issue.ausstellen><en> As a registered and recognized non-profit organization, we may issue donation receipts that can be claimed for tax purposes.
<G-vec00351-002-s077><issue.ausstellen><de> Wenn wir einen Flugschein ohne Sitzplatzreservierung ausstellen kann später vorbehaltlich Platzverfügbarkeit auf dem fraglichen Flug gemäß unseren Tarifbestimmungen ein Platz reserviert werden.
<G-vec00351-002-s077><issue.ausstellen><en> If we issue you with a Ticket which doesn’t have a confirmed Booking for a seat on a Flight, it may be possible to make a reservation at a later time providing you pay the Tariff and if there is space on the Flight requested.
<G-vec00351-002-s078><issue.ausstellen><de> Der Administrator muss das Zertifikat ausdrücklich ausstellen.
<G-vec00351-002-s078><issue.ausstellen><en> The administrator must explicitly issue the certificate.
<G-vec00351-002-s079><issue.ausstellen><de> Dieses Zertifikat ist die Voraussetzung dafür, dass die Behörden einen Fahrzeugbrief ausstellen, mit dem der Besitzer das Fahrzeug später zulassen kann.
<G-vec00351-002-s079><issue.ausstellen><en> This certificate is the prerequisite for the authorities to issue a vehicle registration document with which the owner can later register the vehicle.
<G-vec00351-002-s080><issue.ausstellen><de> Bevor Sie ein Haus kaufen, wird Ihnen der Hypothekaranbieter eine Offerte ausstellen.
<G-vec00351-002-s080><issue.ausstellen><en> Before you buy a house, a mortgage lender will issue you a quote.
<G-vec00351-002-s081><issue.ausstellen><de> Das heißt, Sie können später für alle genannten SSL Domänen ein beliebiges SSL Zertifikat, das Sie bestellt haben, ausstellen.
<G-vec00351-002-s081><issue.ausstellen><en> It is possible to issue any ordered SSL certificate for any specified domain.
<G-vec00351-002-s082><issue.ausstellen><de> Aktionäre können per Internet eine Eintrittskarte zur Hauptversammlung bestellen oder eine Vollmacht ausstellen.
<G-vec00351-002-s082><issue.ausstellen><en> Using the internet, shareholders can order an admission ticket for the shareholders’ meeting and issue a proxy.
<G-vec00351-002-s083><issue.ausstellen><de> Der Anbieter wird Ihnen ein Einladungsschreiben für Ihr Visum ausstellen.
<G-vec00351-002-s083><issue.ausstellen><en> The supplier will issue you with an invitation letter for your visa.
<G-vec00351-002-s084><issue.ausstellen><de> Die Kirche solle ein Dokument, ein schriftlicher Nachweis ausstellen, dass die Person jetzt biblische Taufe empfangen hat.
<G-vec00351-002-s084><issue.ausstellen><en> The church should issue a document, a written evidence, that the candidate now has received biblical baptism.
<G-vec00351-002-s085><issue.ausstellen><de> Jetzt können Sie alle Ihre SSL-Zertifikate an einer zentralen Stelle verwalten, erwerben, ausstellen, verlängern und nachverfolgen.
<G-vec00351-002-s085><issue.ausstellen><en> Manage, purchase, issue, renew, and track all your SSL certificates in one place.
<G-vec00351-002-s086><issue.ausstellen><de> Das Problem entsteht, wenn Sie mehrere Zertifikate für neue Mitarbeiter ausstellen müssen und diese schnell installiert werden müssen.
<G-vec00351-002-s086><issue.ausstellen><en> The problem comes when you need to issue multiple certificates for new employees and have them installed quickly.
<G-vec00351-002-s087><issue.ausstellen><de> Allerdings sollte die Mitnahme der Medikamente vorher mit dem Hausarzt durchgesprochen werden, der ein Attest ausstellen kann – denn eine uneingeschränkte Medikamenteneinfuhr ist nicht weltweit gestattet.
<G-vec00351-002-s087><issue.ausstellen><en> The medications to be taken along should however first be discussed with a general practitioner, who can issue a doctor’s certificate – because some countries have import restrictions for drugs.
<G-vec00351-002-s088><issue.ausstellen><de> Die Mitgliedstaaten können diese Führerscheine auch mit einer Gültigkeitsdauer von bis zu 15 Jahren ausstellen.
<G-vec00351-002-s088><issue.ausstellen><en> A Member State may choose to issue such licences with an administrative validity of up to 15 years;
<G-vec00351-002-s089><issue.ausstellen><de> Für Online-Bestellungen, die in Shops retourniert werden, können wir dir eine Gutschrift ausstellen oder den Betrag zurück überweisen.
<G-vec00351-002-s089><issue.ausstellen><en> For online orders that are returned to a shop, we can either issue a credit note or refund the amount.
<G-vec00351-002-s090><issue.ausstellen><de> So können Sie EMDs anzeigen, aktualisieren, prüfen, ausstellen, ausdrucken, löschen und neu ausstellen.
<G-vec00351-002-s090><issue.ausstellen><en> This allows you to display, update, review, issue, print, void or reissue EMDs.
<G-vec00351-002-s091><issue.ausstellen><de> Khartum (Fides) – Das Ministeriums für religiöse Angelgenheiten im Sudan verkündete, dass die Regierung keine Genehmigungen zum Bau neuer Kirchengebäude im Land mehr ausstellen werde.
<G-vec00351-002-s091><issue.ausstellen><en> Khartoum (Agenzia Fides) - The Sudanese Minister of Guidance and religious Endowments announced that the government will not issue permits anymore for the construction of new churches in the country.
<G-vec00351-002-s092><issue.ausstellen><de> Billdu ist ein Cloud-basiertes Rechnungssystem für Freiberufler und kleine Unternehmen, die das Erstellen und Ausstellen von Rechnungen, Verwalten von Online-Shops, Nachverfolgen von Kosten, Erfassen von Kundenfeedback und vieles mehr ermöglicht.
<G-vec00351-002-s092><issue.ausstellen><en> Billdu is a cloud-based invoicing system designed for freelancers and small businesses which can be used to create and issue invoices, manage online stores, track expenses, capture customer feedback, and more.
<G-vec00351-002-s093><issue.ausstellen><de> Außerdem haben Anwälte einen besseren Ruf als Inkasso-/Factoring-Unternehmen: Dadurch, dass sie professioneller und individueller auftreten, werden sie allgemein eher respektiert als Unternehmen, die zumeist etliche Forderungen pro Tag ausstellen, ohne sich dabei auf den spezifischen Fall konzentrieren zu können.
<G-vec00351-002-s093><issue.ausstellen><en> In addition, lawyers have a better reputation than debt collection agencies/factoring companies. Since they are more professional and focus on the individual more, they are generally more respected than companies that issue countless claims per day without being able to focus on a specific case.
<G-vec00351-002-s094><issue.ausstellen><de> Wenn Sie mithilfe von CAA einschränken möchten, welche Zertifizierungsstellen Zertifikate für Ihre Domain ausstellen dürfen, müssen Sie einen DNS-Anbieter verwenden, der die Einstellung von CAA-Einträgen unterstützt.
<G-vec00351-002-s094><issue.ausstellen><en> If you would like to use CAA to restrict which Certificate Authorities are allowed to issue certificates for your domain, you will need to use a DNS provider that supports setting CAA records.
<G-vec00380-002-s081><dispense.ausstellen><de> Eine Ausgabeeinheit für Karten im ISO-Format ist in der Lage, berührungslose Karten zu codieren und auszustellen.
<G-vec00380-002-s081><dispense.ausstellen><en> An ISO format card dispenser is able to encode and dispense contactless cards.
<G-vec00509-002-s133><issue.ausstellen><de> Datenschutzerklädem Gestz über die Erlöseevidenz ist der Verkäufer dazu verpflichtet, dem Käufer eine Rechnung auszustellen.
<G-vec00509-002-s133><issue.ausstellen><en> The seller is obliged to issue a receipt to the buyer under the Act on Sales Records.
<G-vec00509-002-s134><issue.ausstellen><de> Er forderte Peking auf, sofort einen neuen Pass für Wang auszustellen sowie ihm zu erlauben, ohne eine weitere Einmischung China zu verlassen und zu seiner Familie in die USA zu reisen.
<G-vec00509-002-s134><issue.ausstellen><en> He demanded Beijing to immediately issue Mr. Wang his passport and allow him to leave China to reunite with his family in the U.S. without any interference.
<G-vec00509-002-s135><issue.ausstellen><de> „Gemäß dem Gesetz über die Umsatzerfassung ist der Verkäufer verpflichtet dem Käufer eine Rechnung auszustellen.
<G-vec00509-002-s135><issue.ausstellen><en> “Pursuant to the Act on Registration of Sales, the salesperson is obliged to issue a receipt to the buyer.
<G-vec00509-002-s136><issue.ausstellen><de> In den folgenden Teilen dieser Artikelreihe beleuchten wir vier verschiedene Use Cases, wie der FAS-Server in die Infrastruktur eingefügt und autorisiert wird um bei Bedarf SmartCard-Zertifikate auszustellen, mit denen die User an ihrer Citrix HDX-Session angemeldet werden, als würden sie über eine SmartCard verfügen.
<G-vec00509-002-s136><issue.ausstellen><en> In the following articles of this series, we examine four different use cases, how the FAS server is inserted into the infrastructure and authorized to issue smart card certificates if required, with which the user logs on to his Citrix HDX session as if he had a smart card.
<G-vec00509-002-s137><issue.ausstellen><de> Gemäß dem Gesetz über Umsatzevidenz ist der Verkäufer verpflichtet, dem Käufer eine Quittung auszustellen.
<G-vec00509-002-s137><issue.ausstellen><en> As provided in the Sales Records Act, the seller is required to issue a receipt to the buyer.
<G-vec00509-002-s138><issue.ausstellen><de> Die Waschanlage wurde auf SQAS Cleaning, geprüft und ist berechtigt das ECD (European Cleaning Document) auszustellen.
<G-vec00509-002-s138><issue.ausstellen><en> Tank cleaning has been SQAS Cleaning tested and is authorised to issue ECD (European Cleaning Document)
<G-vec00509-002-s139><issue.ausstellen><de> Aber machen Sie sich keine Sorgen, Sie werden den Sicherungsschein nicht benötigen!Seit 1994 sind Reiseveranstalter in Deutschland gesetzlich dazu verpflichtet, eine Insolvenzversicherung abzuschließen und Ihren Kunden einen Reisesicherungsschein für Pauschalreisen auszustellen.
<G-vec00509-002-s139><issue.ausstellen><en> But do not worry, you will not need the security certificate! Since 1994 tour operators in Germany are required by law to take out a bankruptcy insurance and issue a travel insurance for package tours to their customers.
<G-vec00509-002-s140><issue.ausstellen><de> Nach Auskunft palästinensischer Menschenrechtsverteidiger und -anwälte ist ein palästinensischer Gouverneur oder hochrangiger Beamter ermächtigt, jederzeit aus beliebigen Gründen einen Haftbefehl gegen jeden Palästinenser auszustellen.
<G-vec00509-002-s140><issue.ausstellen><en> According to Palestinian human rights advocates and lawyers, a Palestinian governor or senior official is authorized to issue arrest warrants against any Palestinian for any reason.
<G-vec00509-002-s141><issue.ausstellen><de> Sie dürfen sich auch nicht aufgrund der Behinderung oder der eingeschränkten Mobilität von Personen weigern, eine Buchung vorzunehmen, einen Fahrschein auszustellen oder die Personen an Bord des Fahrzeugs zu nehmen.
<G-vec00509-002-s141><issue.ausstellen><en> They also are not allowed to refuse making bookings or issue tickets or remove the person from board of a vehicle due to a passenger's disability or due to his reduced mobility.
<G-vec00509-002-s142><issue.ausstellen><de> Stammzertifizierungsstellen und untergeordnete Zertifizierungsstellen werden verwendet, um Zertifikate für Benutzer, Computer und Dienste auszustellen und um die Gültigkeit von Zertifikaten zu verwalten.
<G-vec00509-002-s142><issue.ausstellen><en> Root and subordinate CAs are used to issue certificates to users, computers, and services, and to manage certificate validity. Web Enrollment
<G-vec00509-002-s143><issue.ausstellen><de> Da Sie bei Spenden unter 200, 00 € den Kontoauszug als Spendenbeleg verwenden können, sind wir hier verpflichtet, auch die Spendenbescheinigung auf den Namen des Kontoinhabers auszustellen.
<G-vec00509-002-s143><issue.ausstellen><en> Because donations of less than 200 euros can use a bank account statement to document the donation, we are obligated to issue the donation receipt in the account holder's name.
<G-vec00509-002-s144><issue.ausstellen><de> Ich beabsichtigte, sie dort zu besuchen, doch die Regierung weigerte sich, mir einen Pass auszustellen.
<G-vec00509-002-s144><issue.ausstellen><en> I planned to visit her there, but the government refused to issue me a passport.
<G-vec00509-002-s145><issue.ausstellen><de> GlobalSigns ePKI-Lösung bietet Organisationen aller Größen die Plattform und Prozesse, um Digitale IDs auszustellen, mit denen sie im schnellen elektronischen Handel sowohl in internen als auch den oft unsicheren externen Netzwerken wettbewerbsfähig bleiben können, während sie immer noch die Anforderungen an die in SOX dargelegte Rechenschaftspflicht der Führungskräfte erfüllen.
<G-vec00509-002-s145><issue.ausstellen><en> GlobalSign’s ePKI solution provides organisations of all sizes with the platform and processes to issue Digital IDs to allow them to stay competitive with fast electronic commerce within both internal and often unsecure external networks, while still meeting the executive accountability requirements set forth by SOX.
<G-vec00509-002-s146><issue.ausstellen><de> Der bekannteste von ihnen war Raoul Wallenberg, der 1944 nach Budapest gesandt wurde, um Pässe und Visa für Juden mit Verbindung nach Schweden auszustellen.
<G-vec00509-002-s146><issue.ausstellen><en> The most famous of them was Raoul Wallenberg, who was seconded to Budapest in 1944 to issue passports and visas for Jews with links to Sweden.
<G-vec00509-002-s147><issue.ausstellen><de> Interline-Partnerschaften ermöglichen es zwei oder mehr Fluggesellschaften, im Namen der anderen Fluggesellschaften Tickets auszustellen, wobei der Airline-Code der anderen Fluggesellschaft beibehalten wird.
<G-vec00509-002-s147><issue.ausstellen><en> An interline partnership allows two or more airlines to issue tickets on behalf of each other, while retaining the designator code of the other airline.
<G-vec00509-002-s148><issue.ausstellen><de> Joseph M. Schenck musste sich ebenfalls an den Zahlungen beteiligen und machte den Fehler, eine der Zahlungen mit seinem persönlichen Check auszustellen.
<G-vec00509-002-s148><issue.ausstellen><en> Joseph M. Schenck also had to take part at the payments but made the mistake to issue a personal check for one of these payments.
<G-vec00509-002-s149><issue.ausstellen><de> Die Kommission gelangte zu dem Schluss, dass die Behörden des Vereinigten Königreichs in der Tat die EU-Vorschrift, Aufenthaltsgenehmigungen innerhalb von sechs Monaten nach Antragstellung auszustellen, nicht einhielten.
<G-vec00509-002-s149><issue.ausstellen><en> The Commission concluded that the United Kingdom authorities were indeed not complying with the EU rule to issue residence cards within six months of application.
<G-vec00509-002-s150><issue.ausstellen><de> Wir behalten uns vor pro Familienname nur einen Gutschein auszustellen (auch bei mehreren reservierten Zimmer), sofern die reservierten Zimmer am selben Tag anreisen.
<G-vec00509-002-s150><issue.ausstellen><en> We reserve the right to issue only one voucher per family name (even if more than oneroom is reserved) if the reserved rooms arrive on the same day.
<G-vec00509-002-s151><issue.ausstellen><de> Experteer ist berechtigt nach eigenem Ermessen die Rechnungen in elektronischer Form auszustellen und per E-Mail zu versenden.
<G-vec00509-002-s151><issue.ausstellen><en> Experteer is entitled to issue invoices in electronic form at its discretion, and to send them via e-mail.
<G-vec00555-002-s061><dismiss.ausstellen><de> Unser Wecker bietet folgende Optionen zum Ausstellen: Bildschirmtaste, Lautstärketasten, Ein-/Aus-Taste oder Schütteln des Telefons.
<G-vec00555-002-s061><dismiss.ausstellen><en> Our alarm clock offers the following dismiss options: screen button, volume buttons, power button, or shaking your phone.
<G-vec00564-002-s140><expose.ausstellen><de> Das Bild ist ein Medium gleich dem Licht, das beispielsweise genutzt wird, um auszustellen was gezeigt wird.
<G-vec00564-002-s140><expose.ausstellen><en> The image is used as a medium and the use of light, for example, is used to expose what is being shown.
<G-vec00564-002-s141><expose.ausstellen><de> Mit der nicht einfachen Entscheidung, diese Fotos öffentlich auszustellen, versucht Lider – einer der erfolgreichsten israelischen Musiker –, die Wunden von Zeit und Geschichte zu heilen und seinem Vater, wie er wirklich war, ein Denkmal zu errichten.
<G-vec00564-002-s141><expose.ausstellen><en> With the complex decision to expose these photographs to the public, Lider—one of Israel’s most renowned musicians—mends history and time, celebrating who his father really was, with all that entails.
<G-vec00564-002-s142><expose.ausstellen><de> Empfiehlt sich um Fisch, Meeresfrüchte, Obst, usw... auszustellen.
<G-vec00564-002-s142><expose.ausstellen><en> It is best to expose fish, seafood, fruit, etc...
