<G-vec00347-001-s040><accuse.anschuldigen><de> Hierbei sollten wir nicht nur die primitiven Leute anschuldigen.
<G-vec00347-001-s040><accuse.anschuldigen><en> In this matter let us not accuse only the primitive peoples.
