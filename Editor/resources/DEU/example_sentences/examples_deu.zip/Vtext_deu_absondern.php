<G-vec00595-002-s089><detach.absondern><de> Indem Sie auf den Chart klicken, können sie ihn auch absondern.
<G-vec00595-002-s089><detach.absondern><en> By clicking on the chart you can also detach each chart.
