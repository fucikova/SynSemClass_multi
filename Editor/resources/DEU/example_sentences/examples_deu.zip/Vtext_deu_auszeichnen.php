<G-vec00169-001-s038><award.auszeichnen><de> Als Krönung sind wir für unseren Stand mit einem Silberpreis ausgezeichnet worden.
<G-vec00169-001-s038><award.auszeichnen><en> The cherry on the top was getting a Silver Award for our stand.
<G-vec00169-001-s039><award.auszeichnen><de> Marco Netzbandt wurde für seine Arbeit als Pianist, Komponist, Arrangeur und Hochschuldozent mit dem Kulturförderpreis der Stadt Würzburg ausgezeichnet, wo er auch lebt.
<G-vec00169-001-s039><award.auszeichnen><en> Marco Netzband received the Cultural Award of the city of Würzburg to honour his attainments as a pianist, composer, arranger and college teacher.
<G-vec00169-001-s040><award.auszeichnen><de> "Im Februar 2012 wurde Franz Fehrenbach vom Wirtschaftsmagazin Capital als ""Greentech-Manager des Jahres 2011"" ausgezeichnet."
<G-vec00169-001-s040><award.auszeichnen><en> "The business magazine ""Capital"" presented Franz Fehrenbach with its ""Greentech Manager of the Year 2011"" award in February 2012."
<G-vec00169-001-s041><award.auszeichnen><de> Mannone hat letztes Jahr an einer Diskussionsrunde auf der Createasphere Digital Asset Management Conference der teilgenommen, der gleichen Veranstaltung, auf der Canto mit dem „DAMMY of the Year“ ausgezeichnet worden ist.
<G-vec00169-001-s041><award.auszeichnen><en> Mannone sat on a discussion panel at last year’s Createasphere digital asset management conference, where Canto won its “DAMMY of the Year” award. In addition, he has been featured on the popular “Another DAM Podcast” website.
<G-vec00169-001-s042><award.auszeichnen><de> BARMER GEK und T-Systems werden für Online-Portal ausgezeichnet.
<G-vec00169-001-s042><award.auszeichnen><en> BARMER GEK and T-Systems receive award for online portal.
<G-vec00169-001-s043><award.auszeichnen><de> Ausgezeichnet wird das neue Leitwerk des Hubschraubers AugustaWestland AW169 vor allem für seine energiesparende Leichtigkeit: Mit 15 Prozent Gewichtsreduzierung gegenüber Vorgängermodellen aus herkömmlichen Verbundstoffen trägt das innovative Bauteil erheblich zu einer treibstoff-sparenden Konstruktion und damit zu besserer Wirtschaftlichkeit und geringerem Schadstoffausstoß bei.
<G-vec00169-001-s043><award.auszeichnen><en> The award goes to the new tailplane of the AgustaWestland AW169 helicopter primarily due to its energy-saving lightness: With a 15 percent weight reduction compared with predecessor models made from conventional composites, this innovative composite makes a considerable contribution to a fuel-saving construction and thus to greater profitability and lower emissions.
<G-vec00169-001-s044><award.auszeichnen><de> An jedem beliebigen Tag Pokerspieler auf der ganzen Welt verstreut, repping ihre Sponsoren Turniere oder jagen einige Reiseveranstalter Spieler des Jahres ausgezeichnet.
<G-vec00169-001-s044><award.auszeichnen><en> On any given day poker players are scattered across the globe, repping their sponsors tournaments or chasing some tour's Player of the Year award.
<G-vec00169-001-s045><award.auszeichnen><de> Zusätzliche wildnis, die halt auf den Walzen, wird gesperrt und eine zusätzliche re-spin, werden ausgezeichnet.
<G-vec00169-001-s045><award.auszeichnen><en> Any additional wilds that stop on the reels will become locked and an additional re-spin will be award.
<G-vec00169-001-s046><award.auszeichnen><de> "Gemeinsam mit Judith Rakers wurden sie fÃ1⁄4r Ihre Moderation des ""Eurovision Song Contest 2011"" ausgezeichnet."
<G-vec00169-001-s046><award.auszeichnen><en> Together with Judith Rakers, they received an award for presenting the 2011 Eurovision Song Contest.
<G-vec00169-001-s047><award.auszeichnen><de> „Mit Leo Kandl wird einer der spannendsten Fotokünstler Österreichs ausgezeichnet.
<G-vec00169-001-s047><award.auszeichnen><en> “The award pays tribute to Leo Kandl, one of Austria’s most exciting photographic artists.
<G-vec00169-001-s048><award.auszeichnen><de> Bereits 2006 wurde unsere Simulationssoftware SimulationX im Bereich Antriebstechnik von der SAE (Society of Automotive Engineers) ausgezeichnet.
<G-vec00169-001-s048><award.auszeichnen><en> Our simulation software SimulationX received an award for drive systems by the Society of Automotive Engineers (SAE) already in 2006.
<G-vec00169-001-s049><award.auszeichnen><de> Heppe Medical Chitosan wird mit dem IQ-Innovationspreis Halle (Saale) ausgezeichnet.
<G-vec00169-001-s049><award.auszeichnen><en> Heppe Medical Chitosan GmbH awarded the IQ Innovation Award Halle (Saale).
<G-vec00169-001-s050><award.auszeichnen><de> Die Kampagne wurde auch mit dem Bronze Effie für Markteffizienz und MIXX Award für digitales Marketing ausgezeichnet.
<G-vec00169-001-s050><award.auszeichnen><en> The Time Vault also won Bronze Effie award for market effectiveness and MIXX award for digital marketing.
<G-vec00169-001-s051><award.auszeichnen><de> "Dem Trend zum höheren Klavier trägt das Modell 122/124 Rechnung, das 1985 in Paris mit der ""Goldenen Stimmgabel"" ausgezeichnet wird."
<G-vec00169-001-s051><award.auszeichnen><en> The trend towards the high piano leads to the model 122/124, which wins the “Golden Tuning Fork” award in Paris in 1985.
<G-vec00169-001-s052><award.auszeichnen><de> "Guntamatic wurde für sein Industrieanlagenkonzept PRO bei der Eröffnung der Energiesparmesse mit dem Innovationspreis ""EnergieGenie"" des Bundesministeriums und des Landes OÖ ausgezeichnet."
<G-vec00169-001-s052><award.auszeichnen><en> "The ""EnergieGenie"" award by the Federal Ministry of Agriculture, Forestry, Environment and Water Management and the region of Upper Austria was presented at the opening of the Energiesparmesse in Wels."
<G-vec00169-001-s053><award.auszeichnen><de> "Nach dessen Fertigstellung war er Österreichs erstes Plus-Energie-Bürohaus, ausgezeichnet mit dem EU Green Building Award und ""Top Quality Building"" von ÖGNB."
<G-vec00169-001-s053><award.auszeichnen><en> "Upon completion this was Austria's first Plus-Energy office building and it received the EU Green Building Award and ""Top Quality Building"" award of the ÖGNB."
<G-vec00169-001-s054><award.auszeichnen><de> Erst wenn die visuelle Ebene hinzukomme – der Auftritt des Dichters, sein Aussehen und Habitus wie auch seine Stimme bei der Lesung –, könne man einen Bezug zum Verfasser herstellen: »Lyrik ist unmittelbarer, man muss Verantwortung für seinen Text übernehmen.« Polozkovas Blog, der im März 2010 über 16.000 registrierte Leser hatte, wurde 2009 mit dem Neformat-Preis, einem russischen Literaturpreis, ausgezeichnet.
<G-vec00169-001-s054><award.auszeichnen><en> Only when complemented by a visual layer – enshrined in the performance of the poet, his appearance and habit, as well as his voice when reading – we can understand the author: »Poetry is more immediate, one has to take responsibility for one's own words.« Vera Polozkova's blog, which in March, 2010 had 16,000 registered readers, received the Neformat Prize, a Russian literature award, in 2009.
<G-vec00169-001-s055><award.auszeichnen><de> Ausgezeichnet wurde bisher u. a. das Umweltbundesamt in Dessau, für das KREBS+KIEFER die Tragwerksplanung durchgeführt hat.
<G-vec00169-001-s055><award.auszeichnen><en> So far the award has been given (among others) to the Federal Environment Agency building in Dessau, the structural design of which was produced by KREBS+KIEFER.
<G-vec00169-001-s056><award.auszeichnen><de> "Heute ist Maslinica ein attraktives, touristisches Mekka und wurde national ausgezeichnet als ""bester touristischer Ort mit weniger als 1000 Einwohnern"" an der Adria."
<G-vec00169-001-s056><award.auszeichnen><en> Nowadays Maslinica is an attractive tourist mecca, and it has received a national award as the best tourist place up to 1,000 inhabitants on the Adriatic.
<G-vec00169-001-s114><award.auszeichnen><de> Brokula & Ž wurde mit dem Greenovation Award als bestes Start-Up der kroatischen grünen Wirtschaft ausgezeichnet.
<G-vec00169-001-s114><award.auszeichnen><en> Brokula&Ž is the winner of Greenovation award as the best start-up of Croatian green economy.
<G-vec00169-001-s115><award.auszeichnen><de> Im Januar 2012 wurde ROBINSON beim „Hotelier des Jahres“ – dem wichtigsten Event der deutschen Hotelbranche – mit dem begehrten Special Award ausgezeichnet.
<G-vec00169-001-s115><award.auszeichnen><en> In January 2012, ROBINSON received the prestigious Special Award at the “Hotel Operator of the Year” celebration – the most important event in the German hospitality industry.
<G-vec00169-001-s116><award.auszeichnen><de> Die Ocean Clinic wurde hierbei mit dem Medical Charity Award ausgezeichnet, nachdem sie in den vergangenen Jahren zwei karitative Missionen in Lamu (Kenia) durchgeführt hatte.
<G-vec00169-001-s116><award.auszeichnen><en> Ocean Clinic was named winner of the Medical Charity Award, following two charitable missions to Lamu, Kenya, where Head Surgeon Doctor Kai Kaye and his team carried out reconstructive surgery.
<G-vec00169-001-s117><award.auszeichnen><de> In Südafrika wurden unsere Produkte mit dem Mama Magic Innovation Award ausgezeichnet.
<G-vec00169-001-s117><award.auszeichnen><en> In South Africa, our products have been awarded to the Mama Magic Innovation Award.
<G-vec00169-001-s118><award.auszeichnen><de> Die ökologische Textil-Innovation wurde von Pontetorto im Herbst 2017 erstmals im Rahmen der Fachmesse Performance Days in München der Öffentlichkeit präsentiert und dort gleich mit dem Eco Performance Award der Messe ausgezeichnet.
<G-vec00169-001-s118><award.auszeichnen><en> This ecological textile innovation was premiered by Pontetorto in the fall of 2017 at the Performance Days Trade Fair in Munich, where it was recognized with the trade fair's Eco Performance Award.
<G-vec00169-001-s119><award.auszeichnen><de> "HRS konnte als Global Hotel Solutions Provider auf dem chinesischen B2B Markt punkten und wurde beim ""Leader of Business Travel Award"" als ""Best Business Travel Management Platform"" ausgezeichnet."
<G-vec00169-001-s119><award.auszeichnen><en> "HRS scored as Global Hotel Solutions Provider on the Chinese B2B market and was named as the ""Best Business Travel Management Platform"" on the 2nd Leader of Business Travel Award."
<G-vec00169-001-s120><award.auszeichnen><de> "Die Besten werden mit dem von Agilent Technologies gesponserten ""Best Innovation Award 2007"" ausgezeichnet."
<G-vec00169-001-s120><award.auszeichnen><en> "The best ones will receive the ""Best Innovation Award 2007"" sponsored by Agilent Technologies."
<G-vec00169-001-s121><award.auszeichnen><de> Als einziges Geländersystem wurden sie mit dem Red Dot Design Award ausgezeichnet.
<G-vec00169-001-s121><award.auszeichnen><en> They even won a red dot – the only railing systems ever to receive this design award.
<G-vec00169-001-s122><award.auszeichnen><de> "Die Veeam Management SuiteTM wurde mit dem 2010 TechColumbus Innovation Award als ""Outstanding Product"" ausgezeichnet."
<G-vec00169-001-s122><award.auszeichnen><en> The Veeam Management Suite received a 2010 TechColumbus Innovation Award for Outstanding Product.
<G-vec00169-001-s123><award.auszeichnen><de> Gerade wurde er in Hamburg mit dem Lucky Strike Designer Award ausgezeichnet.
<G-vec00169-001-s123><award.auszeichnen><en> And he has just won the Lucky Strike Designer Award in Hamburg.
<G-vec00169-001-s124><award.auszeichnen><de> Im November 2010 wurde er dafür mit dem AmCham Transatlantic Partnership Award ausgezeichnet.
<G-vec00169-001-s124><award.auszeichnen><en> In November 2010 he was honored with the AmCham Transatlantic Partnership Award.
<G-vec00169-001-s125><award.auszeichnen><de> Der LEGOLAND® Feriendorf Campingplatz wurde mit dem Camping.Info Award 2014 als einer der besten 100 Campingplätze Europas ausgezeichnet.
<G-vec00169-001-s125><award.auszeichnen><en> The LEGOLAND® Holiday Village campsite was rewarded the „Camping.Info Award 2014” being one of the top 100 campsites in Europe!
<G-vec00169-001-s126><award.auszeichnen><de> Die Disability Employee Resource Group von EMC wurde mit dem 2013 Employer of Choice Award von Disability Matters ausgezeichnet.
<G-vec00169-001-s126><award.auszeichnen><en> EMC Disability Employee Resource Group received the 2013 Employer of Choice Award from Disability Matters.
<G-vec00169-001-s127><award.auszeichnen><de> SMA gehört 2009 aber nicht nur erneut zu den besten Arbeitgebern Europas, sondern wurde auch mit dem Great Place to Work® Fairness Award für faire Vergütung ausgezeichnet.
<G-vec00169-001-s127><award.auszeichnen><en> In 2009 SMA is not only once again amongst Europe's best employers, however, but has also been distinguished with the Great Place to Work® Fairness Award for fair salaries.
<G-vec00169-001-s128><award.auszeichnen><de> "Beide Projekte, Tampines Grande und Lonza, wurden mit dem ""Solar Pioneer Award"" des Economic Development Board (EDB), Singapur, ausgezeichnet."
<G-vec00169-001-s128><award.auszeichnen><en> "Both the Tampines Grande and Lonza projects won the ""Solar Pioneer Award"" of Singapore’s Economic Development Board (EDB)."
<G-vec00169-001-s129><award.auszeichnen><de> iTernity wurde im Juni 2014 mit dem HPE AllianceONE Partner of the Year Award in der Kategorie Storage ausgezeichnet.
<G-vec00169-001-s129><award.auszeichnen><en> iTernityhas been selected for the 2014 HPE AllianceONE Partner of the Year Award in the Storage category.
<G-vec00169-001-s130><award.auszeichnen><de> Im vergangenen Jahr wurde die Schule vom Ausschuss für gesunde Ernährungs- und Lebensplanung mit dem vom Bildungs- und Arbeitsministerium ausgelobten Healthy Lifestyle Award ausgezeichnet.
<G-vec00169-001-s130><award.auszeichnen><en> Last year the school received the Ministry of Education and Employment’s Healthy Lifestyle Award from the Committee on Healthy Nutrition and Life Planning.
<G-vec00169-001-s131><award.auszeichnen><de> In Großbritannien wurden in sechs Kategorien Einzelhändler mit dem Natural Beauty Retail Award ausgezeichnet.
<G-vec00169-001-s131><award.auszeichnen><en> In the UK retailers received the Natural Beauty Retail Award in six categories.
<G-vec00169-001-s132><award.auszeichnen><de> Im Rahmen der Textil-Fachmesse Performance Days in München wurde der Stoff im November 2017 der Öffentlichkeit präsentiert und mit dem Eco Performance Award der Messe ausgezeichnet.
<G-vec00169-001-s132><award.auszeichnen><en> The fabric was presented to the public at the Performance Days textile trade fair in Munich in November 2017 where it was honored with the Eco Performance Award.
<G-vec00169-001-s209><award.auszeichnen><de> Ab dem 5. erfolgreichen Teilnahmejahr wird der Betrieb mit dem „Preis für langjährige Produktqualität“ ausgezeichnet.
<G-vec00169-001-s209><award.auszeichnen><en> After the 5th year of successful participation, the company is given the “Award for longstanding product quality”.
<G-vec00169-001-s210><award.auszeichnen><de> Award 2019 der Siemens Stiftung.Mit dem Preis werden innovative Technologien ausgezeichnet, die wichtige Bereiche der Grundversorgung in Entwicklungsregionen abdecken.
<G-vec00169-001-s210><award.auszeichnen><en> Award 2019 of Siemens Stiftung.The award identifies and supports low-tech solutions that address crucial basic needs sectors in developing regions.
<G-vec00169-001-s211><award.auszeichnen><de> Zur Begründung erklärte das Komitee, mit dem zum dritten Mal vergebenen Preis werde Viviens Einsatz zum Schutz der Opfer von Scientology und ähnlichen Organisationen ausgezeichnet.
<G-vec00169-001-s211><award.auszeichnen><en> For the basis of its third annual award, the committee named Vivien's work in protecting victims of Scientology and of similar organizations.
<G-vec00169-001-s212><award.auszeichnen><de> Nach seinem langjährigen Mentor, Prof. Markus Schwaiger / TU München, der diese Auszeichnung 2006 erhielt, ist Prof. Bengel der zweite Europäer und erst der dritte nicht in den USA ansässige Wissenschaftler, der mit diesem Preis ausgezeichnet wird.
<G-vec00169-001-s212><award.auszeichnen><en> After his longstanding mentor, Prof. Markus Schwaiger / TU München, who received the award in 2006, Prof. Bengel is only the second European and the third non-US-based researcher to receive this award.
<G-vec00169-001-s213><award.auszeichnen><de> Über 4,600 Arbeiten aus 54 Ländern wurden zur Bewertung eingereicht, aber nur die besten Produkte wurden mit dem begehrten Preis für ästhetische Formen und nachhaltige Trends ausgezeichnet.
<G-vec00169-001-s213><award.auszeichnen><en> Over 4,600 works from 54 countries were submitted for consideration and only the best products were bestowed with this coveted award for aesthetic forms and lasting trends.
<G-vec00169-001-s214><award.auszeichnen><de> Das Werk wurde vom Fachmagazin Produktion mit dem Preis 'Fabrik des Jahres' 2017 in der Kategorie 'Standortsicherung durch Digitalisierung' ausgezeichnet.
<G-vec00169-001-s214><award.auszeichnen><en> In 2017 the trade magazine Produktion presented the plant with its Factory of the Year award in the category Safeguarding Locations through Digitalization.
<G-vec00169-001-s215><award.auszeichnen><de> Seit 2015 verfügt der Campingplatz Baldarin über ein ECOCAMPING-Zertifikat und er wurde auch mit dem gleichnamigen Preis ausgezeichnet.
<G-vec00169-001-s215><award.auszeichnen><en> Since 2015 the campsite Baldarin owns an ECOCAMPING certificate and is also the proud winner of the ECOCAMPING award.
<G-vec00169-001-s216><award.auszeichnen><de> Die Bpogen® Spirulina Kapsel wird von der Health Food Society aus Taiwan mit einem innovativen Preis ausgezeichnet.
<G-vec00169-001-s216><award.auszeichnen><en> A00241). 2012 Bpogen® spirulina capsule receives innovative award from Health Food Society of Taiwan.
<G-vec00169-001-s217><award.auszeichnen><de> Das besondere, durchdachte und innovative Produktdesign des Cavalons wurde nun mit dem weltweit rennomiertesten Preis ausgezeichnet: dem red dot award: product design 2012.
<G-vec00169-001-s217><award.auszeichnen><en> The very special, sophisticated and innovative product design of the Cavalon was now decorated with the worldwide most renowned award: the red dot award: product design.
<G-vec00169-001-s218><award.auszeichnen><de> Mit dem Preis wird ein Werk ausgezeichnet, das stellvertretend für das Gesamtschaffen des Künstlers steht.
<G-vec00169-001-s218><award.auszeichnen><en> The award recognizes a work that is representative of the artist’s total work.
<G-vec00169-001-s219><award.auszeichnen><de> Bundespräsident Frank-Walter Steinmeier hatte die drei Entwickler am Mittwochabend mit dem Deutschen Zukunftspreis, dem Preis des Bundespräsidenten für Technik und Innovation 2017 ausgezeichnet.
<G-vec00169-001-s219><award.auszeichnen><en> em>On Wednesday evening, Federal President Frank-Walter Steinmeier awarded the Deutscher Zukunftspreis, the Federal President’s Award for Technology and Innovation 2017, to the three scientists.
<G-vec00169-001-s220><award.auszeichnen><de> "Animal Flex wurde acht Jahre hintereinander mit dem angesehenen Preis ""Joint Supplement of the Year"" ausgezeichnet."
<G-vec00169-001-s220><award.auszeichnen><en> Animal Flex has won the prestigious 'Joint Supplement of the Year' award eight years in a row.
<G-vec00169-001-s221><award.auszeichnen><de> "Für die Publikation ""A Network Analysis Approach to Understand the Human Way-finding Problem"" wurde das Team um Katharina Zweig während der diesjährigen Konferenz für Kognitionswissenschaften ""CogSci 2011"" Ende Juli von der Cognitive Science Society mit einem Preis ausgezeichnet."
<G-vec00169-001-s221><award.auszeichnen><en> "For its publication entitled ""A Network Analysis Approach to Understand the Human Way-finding Problem"" the Cognitive Science Society recognised Dr. Zweig's team with an award at this year's ""CogSci 2011"" conference for the cognitive sciences at the end of July."
<G-vec00169-001-s222><award.auszeichnen><de> 1977 wurde er mit dem Internationalen Senefelder Preis für Lithographie ausgezeichnet.
<G-vec00169-001-s222><award.auszeichnen><en> In 1977 he received the International Senefelder Award for Lithography.
<G-vec00169-001-s223><award.auszeichnen><de> "Jury würdigt das umfangreich zusammengestellte Vermächtnis der ""virtuos zupackenden wie poetisch sensiblen Pianistin"" Die im November 2015 bei GENUIN classics veröffentlichte »Dinorah Varsi-Legacy« Box wird mit dem Preis der deutschen Schallplattenkritik der Bestenliste 1/2016 in der Kategorie Tasteninstrumente ausgezeichnet."
<G-vec00169-001-s223><award.auszeichnen><en> "Jury awards the extensive compiled legacy of the ""virtuostically gripping and poetically sensitive pianist"" Released in November 2015, GENUIN classics' ""Dinorah Varsi Legacy "" box has been awarded the Quarterly Critics' Choice 1/2016 in the category ""Keyboard Instruments"" of the German Record Critics' Award ."
<G-vec00169-001-s224><award.auszeichnen><de> "Bereits 2005 wurde der ebenfalls in der Nähe gelegene ""Felsenweg"" mit demselben Preis ausgezeichnet."
<G-vec00169-001-s224><award.auszeichnen><en> "In 2005, the ""Felsenweg"" (rocky trail), which is also close by, was given the same award."
<G-vec00169-001-s225><award.auszeichnen><de> """Gödel wurde schließlich hoch angesehen und 1951 mit dem ersten Albert Einstein Preis für Beiträge zu den Naturwissenschaften ausgezeichnet, der höchsten Auszeichnung dieser Art in den Vereinigten Staaten."
<G-vec00169-001-s225><award.auszeichnen><en> """Gödel was at last recognized by his peers and presented with the first Albert Einstein Award in 1951 for achievement in the natural sciences – the highest honor of its kind in the United States."
<G-vec00169-001-s226><award.auszeichnen><de> Stefanie Eyerich, München, wurde mit dem Preis für Immunologie für ihre Untersuchungen zur Regulation der epithelialen T-Zell-Immunantwort ausgezeichnet.
<G-vec00169-001-s226><award.auszeichnen><en> Stefanie Eyerich from Munich received the Immunology Award for her research into the regulation of epithelial T-cell immune response.
<G-vec00169-001-s227><award.auszeichnen><de> "Während des ""15th National Cement & Ceramic Conference and Exhibition"" in Beijing wurde UWT China mit dem BAT (Best Application Technology) Preis für Anwendungen in der Zement- und Keramikindustrie für das Jahr 2013 ausgezeichnet."
<G-vec00169-001-s227><award.auszeichnen><en> "During the ""15th National Cement & Ceramic Conference and Exhibition"" in Beijing UWT China received the BAT (Best Application Technology) award in the Cement & Ceramic Industry for the year 2013."
<G-vec00228-002-s027><nominate.auszeichnen><de> Die Kommission wird die Kulturstätten im Januar 2014 offiziell auszeichnen.
<G-vec00228-002-s027><nominate.auszeichnen><en> The Commission will formally nominate the sites in January 2014.
<G-vec00417-002-s033><characterize.auszeichnen><de> Statt vordergründiger Werbung, setzt Blocher Blocher Partners auf die besonderen Blickwinkel und spannenden Themen, die die Unternehmensgruppe auszeichnen.
<G-vec00417-002-s033><characterize.auszeichnen><en> Instead of taking a superficial advertising tack, Blocher Blocher Partners highlights the unique perspective and exciting themes that characterize the firm's work.
<G-vec00417-002-s034><characterize.auszeichnen><de> Beschaulichkeit, Ruhe, Natur und die Weite des Meeres – dies alles sind Attribute, die das Nordseeheilbad Helgoland auszeichnen.
<G-vec00417-002-s034><characterize.auszeichnen><en> Tranquility, peace, nature and the vastness of the sea – all these are attributes that characterize the North Sea health resort island of Helgoland.
<G-vec00417-002-s035><characterize.auszeichnen><de> Bücherregale mit alten Büchern, Gemälden, Schrotflinten, Hirschgeweih und Massivholz sind einige der Besonderheiten, die die Einrichtung dieser Villa auszeichnen.
<G-vec00417-002-s035><characterize.auszeichnen><en> Bookcases with old books, paintings, shotguns, deer antlers and solid wood are some of the peculiarities that characterize the furnishings of this villa.
<G-vec00417-002-s036><characterize.auszeichnen><de> Überzeugen Sie sich neben der Flexibilität und Effizienz, welche das System auszeichnen, auch von der Bedienerfreundlichkeit und der patentierten Doppelhubtechnik.
<G-vec00417-002-s036><characterize.auszeichnen><en> Convince yourself. Not only of the flexibility and efficiency that characterize the system, but also of its user-friendliness and patented double stroke technology.
<G-vec00417-002-s037><characterize.auszeichnen><de> Dabei sollen Haltbarkeit und Frische die neue Verpackung auszeichnen.
<G-vec00417-002-s037><characterize.auszeichnen><en> On top the shelf-life and freshness should characterize the new pack.
<G-vec00417-002-s038><characterize.auszeichnen><de> Der Stil und die Thematik dieser Abbildungen sind meilenweit entfernt von der heiteren Gelassenheit und Farbigkeit, die seine anderen Bilder auszeichnen.
<G-vec00417-002-s038><characterize.auszeichnen><en> The style and theme of these illustrations are a world away from the cheerful serenity and colorfulness that characterize his other paintings.
<G-vec00417-002-s039><characterize.auszeichnen><de> Langeweile, Büro-Muff und schlechte Atmosphäre – Greenfort lässt all das vermissen, wodurch sich viele andere Kanzleien auszeichnen und verschafft sich mit kompromissloser Gute-Laune-Stimmung, freundschaftlicher Atmosphäre und authentischer Menschlichkeit ein außergewöhnliches Gesicht.
<G-vec00417-002-s039><characterize.auszeichnen><en> Boredom and an unpleasant work atmosphere – Greenfort lacks such features that characterize many other law firms and instead distinguishes itself by its uncompromising good-mood-vibe, amicable atmosphere and authentic humanity.
<G-vec00417-002-s040><characterize.auszeichnen><de> Dieser Jamón wird von Schinken-Experten hergestellt, die sehr gut wissen, wie man alle Geschmacksnuancen hervorhebt, die diesen besonderen Schinken auszeichnen.
<G-vec00417-002-s040><characterize.auszeichnen><en> This Jamón is made by ham experts who know very the way to bring out all the flavour nuances that characterize this particular ham.
<G-vec00417-002-s041><characterize.auszeichnen><de> Starke Qualität und vor allem Belastbarkeit sind Faktoren, die diese Stoffe auszeichnen.
<G-vec00417-002-s041><characterize.auszeichnen><en> Good quality and, above all, resilience are factors which characterize these substances.
<G-vec00417-002-s042><characterize.auszeichnen><de> Hohe chemische Beständigkeit, gegen Öl und Fette, sind nur einige Atribute, die diese Rolle auszeichnen.
<G-vec00417-002-s042><characterize.auszeichnen><en> High chemical resistance, against oil and fats, are only a few of the attributes that characterize this castor.
