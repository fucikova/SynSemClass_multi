<G-vec00555-002-s051><squeeze_out.auspressen><de> Das ist eine freundliche Konkurrenz, um etwas interessante Musik und Töne von einer der einschränkendsten Sound Hardware auszupressen.
<G-vec00555-002-s051><squeeze_out.auspressen><en> This is a friendly competition to squeeze out some interesting music and sounds from one of the most restrictive sound hardware produced.
<G-vec00555-002-s052><squeeze_out.auspressen><de> Wie der Name bereits vermuten lässt, kann eine automatische Saftmaschine den Saft des Obstes direkt auspressen, während eine elektrische Saftmaschine mehr Einsatz des Anwenders benötigt, um den Saft auszupressen.
<G-vec00555-002-s052><squeeze_out.auspressen><en> As the name suggests, an automatic citrus press is able to press the juice from fruits independently, while an electrical citrus press requires more human involvement in order to squeeze juice from fruits.
<G-vec00648-002-s032><squeeze.auspressen><de> Den Saft der Limette auspressen.
<G-vec00648-002-s032><squeeze.auspressen><en> Squeeze the juice of the lime.
<G-vec00648-002-s033><squeeze.auspressen><de> Zitronensaft separat auspressen.
<G-vec00648-002-s033><squeeze.auspressen><en> Separately squeeze lemon juice.
<G-vec00648-002-s034><squeeze.auspressen><de> Die Gurke auspressen und unter den Quark rühren.
<G-vec00648-002-s034><squeeze.auspressen><en> Squeeze the excess water from the cucumber and stir in the curd.
<G-vec00648-002-s035><squeeze.auspressen><de> Orange halbieren und den Saft aus einer Hälfte auspressen.
<G-vec00648-002-s035><squeeze.auspressen><en> Cut orange in half and squeeze the juice from one half.
<G-vec00648-002-s036><squeeze.auspressen><de> Orange auspressen und zusammen mit restlichen Zutaten in den Mixer geben und mixen bis es cremig ist.
<G-vec00648-002-s036><squeeze.auspressen><en> Squeeze orange and mix with remaining ingredients in the blender and mix until creamy.
<G-vec00648-002-s037><squeeze.auspressen><de> Das Frühstück wird von natürlichen Säften begleitet, die wir im Ort auspressen, von hochwertigem Kaffee, der im Boden gemahlen wird, und von Kräutertee-Aufgüssen.
<G-vec00648-002-s037><squeeze.auspressen><en> Breakfast is accompanied by natural juices we squeeze in the place, high-quality coffee that is ground in the ground and herbal tea infusions.
<G-vec00648-002-s038><squeeze.auspressen><de> Orangen, Zitronen und Limetten mit der Zitruspresse auspressen.
<G-vec00648-002-s038><squeeze.auspressen><en> Squeeze the oranges, lemons and limes in the citrus press.
<G-vec00648-002-s039><squeeze.auspressen><de> Die Schale abreiben und den Saft auspressen.
<G-vec00648-002-s039><squeeze.auspressen><en> Rinse the lemon well, grate some peel and squeeze the lemon..
<G-vec00648-002-s040><squeeze.auspressen><de> Zubereitung: Die Orangen auspressen, die Möhren pürieren und beide Zutaten in den Mixer geben, so dass der Saft schön cremig wird.
<G-vec00648-002-s040><squeeze.auspressen><en> Method: Simply squeeze the oranges, purée the carrots and add both ingredients to the blender to make a nice creamy juice.
<G-vec00648-002-s041><squeeze.auspressen><de> Intuitive Bedienung dank variabler Geschwindigkeit und Turbofunktion in einer Taste, die Ihnen mehr Leistung beim Auspressen bietet.
<G-vec00648-002-s041><squeeze.auspressen><en> Intuitive variable speed setting and turbo boost in one button that gives you more power as you squeeze.
<G-vec00648-002-s042><squeeze.auspressen><de> Um es zu bekommen, sollten Sie die frischen Blätter in einem Mixer zerkleinern und den Saft mit Gaze auspressen.
<G-vec00648-002-s042><squeeze.auspressen><en> To get it, you should chop the fresh leaves in a blender, and squeeze the juice using gauze.
<G-vec00648-002-s043><squeeze.auspressen><de> Die Orangenschale fein abreiben und den Saft auspressen.
<G-vec00648-002-s043><squeeze.auspressen><en> Grate the zest of the orange and squeeze out the juice.
<G-vec00648-002-s044><squeeze.auspressen><de> 3 Wenn der Fisch aus der Pfanne ist, die Butter erneuern und eine Zitrone in der Pfanne auspressen und die Petersilie hinzufügen.
<G-vec00648-002-s044><squeeze.auspressen><en> 3 When the fish is out of the pan, refresh the butter and squeeze a lemon in the pan and add the parsley.
<G-vec00648-002-s045><squeeze.auspressen><de> Die Sauce über die Nudeln gießen, mit Petersilie bestreuen und eine Zitronenscheibe darüber auspressen.
<G-vec00648-002-s045><squeeze.auspressen><en> Pour over hot pasta, sprinkle with parsley and squeeze lemon wedge over all.
<G-vec00648-002-s046><squeeze.auspressen><de> 500g Blattspinat in kochendem Salzwasser 5 Sekunden blanchieren, in gesalzenem Eiswasser abschrecken und auspressen.
<G-vec00648-002-s046><squeeze.auspressen><en> Blanch 500 gm (17.6 oz) of spinach leaves in boiling salt water for 5 seconds, rinse it in salted ice water and squeeze.
<G-vec00648-002-s047><squeeze.auspressen><de> Gelatine auspressen und in die Soße rühren.
<G-vec00648-002-s047><squeeze.auspressen><en> Squeeze out gelatine and stir into the gravy.
<G-vec00648-002-s048><squeeze.auspressen><de> Zitrone halbieren, auspressen und einen Teelöffel Zitronensaft dazugeben.
<G-vec00648-002-s048><squeeze.auspressen><en> Halve your lemon, squeeze it and add a teaspoon of lemon juice.
<G-vec00648-002-s049><squeeze.auspressen><de> Eine Mullmasse auftragen, den Saft auspressen.
<G-vec00648-002-s049><squeeze.auspressen><en> Put on a gauze mass, squeeze the juice.
<G-vec00648-002-s050><squeeze.auspressen><de> Zitrone halbieren und den Saft auspressen.
<G-vec00648-002-s050><squeeze.auspressen><en> Cut lemon in half and squeeze out the juice.
<G-vec00648-002-s051><squeeze.auspressen><de> Das ist eine freundliche Konkurrenz, um etwas interessante Musik und Töne von einer der einschränkendsten Sound Hardware auszupressen.
<G-vec00648-002-s051><squeeze.auspressen><en> This is a friendly competition to squeeze out some interesting music and sounds from one of the most restrictive sound hardware produced.
<G-vec00648-002-s052><squeeze.auspressen><de> Wie der Name bereits vermuten lässt, kann eine automatische Saftmaschine den Saft des Obstes direkt auspressen, während eine elektrische Saftmaschine mehr Einsatz des Anwenders benötigt, um den Saft auszupressen.
<G-vec00648-002-s052><squeeze.auspressen><en> As the name suggests, an automatic citrus press is able to press the juice from fruits independently, while an electrical citrus press requires more human involvement in order to squeeze juice from fruits.
