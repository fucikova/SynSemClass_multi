<G-vec00060-001-s127><indicate.anzeigen><de> Hat jedoch der Hersteller oder sein Bevollmächtigter nach einer oder mehrerer dieser Richtlinien während einer Übergangszeit die Wahl der anzuwendenden Regelung, so wird durch die CE-Kennzeichnung lediglich die Konformität mit den Bestimmungen der von ihm angewandten Richtlinien angezeigt.
<G-vec00060-001-s127><indicate.anzeigen><en> However, where one or more of those Directives allow the manufacturer or his authorised representative to choose, during a transitional period, the system to be applied, the CE marking shall indicate conformity only to the provisions of those Directives applied by the manufacturer or his authorised representative.
<G-vec00060-001-s128><indicate.anzeigen><de> Das Anliegen der Spannungsversorgung und der Betriebszustand des Moduls werden durch Leuchtdioden angezeigt.
<G-vec00060-001-s128><indicate.anzeigen><en> LEDs are used to indicate applied voltage supply and the module operating status.
<G-vec00060-001-s129><indicate.anzeigen><de> Die EtherCAT Box enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s129><indicate.anzeigen><en> The EtherCAT Box has two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s130><indicate.anzeigen><de> Nach der Anmeldung wird durch Flächenlichter angezeigt, welchen jeweiligen Ladepunkt der Kunde gerade benutzen kann.
<G-vec00060-001-s130><indicate.anzeigen><en> After logging on, large lights indicate which charging point the customer can use.
<G-vec00060-001-s131><indicate.anzeigen><de> Die EtherCAT-Klemmen enthalten je zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s131><indicate.anzeigen><en> The EtherCAT Terminals have two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s132><indicate.anzeigen><de> Unabhängig vom gewählten Menü wird Ihnen der Fortschritt des Downloads auch durch das Symbol -3- Abb.2 in der Statuszeile angezeigt.
<G-vec00060-001-s132><indicate.anzeigen><en> Irrespective of the selected menu, a symbol -3- Fig.2 in the status line will indicate the status of the download progress.
<G-vec00060-001-s133><indicate.anzeigen><de> Wenn die entsprechenden Optionsfelder aktiviert sind, werden technische Stromrichtung (rote Pfeile), magnetische Feldlinien (blau) und Lorentzkraft (schwarzer Pfeil) angezeigt.
<G-vec00060-001-s133><indicate.anzeigen><en> If the corresponding checkboxes are selected, the app will indicate the conventional direction of current (red arrows), the magnetic field lines (blue) and the Lorentz force (black arrow).
<G-vec00060-001-s134><indicate.anzeigen><de> Dann wird Ihnen die Version und das Build der Plattform die Sie installiert haben angezeigt.
<G-vec00060-001-s134><indicate.anzeigen><en> This will indicate the version and build of the platform you have installed.
<G-vec00060-001-s135><indicate.anzeigen><de> Dabei werden die Planeten in der Radix in grün dargestellt; so wird angezeigt, dass es sich hier nicht mehr um ein Geburtshoroskop mit Transiten, sondern um Progressionen handelt.
<G-vec00060-001-s135><indicate.anzeigen><en> When you right click on a progression to look at it in more detail in a wheel, you'll remark that the planets are shown in green to indicate that it's not a birth chart with transits, but a progression.
<G-vec00060-001-s136><indicate.anzeigen><de> Wenn im Anhängerbetrieb am Anhänger oder am Fahrzeug eine Blinkleuchte ausfällt, wird dies durch doppelt so schnelles Blinken der Kontrollleuchte angezeigt.
<G-vec00060-001-s136><indicate.anzeigen><en> If a turn signal bulb on the trailer or vehicle fails in towing mode, the indicator lamp flashes twice as fast to indicate the bulb failure.
<G-vec00060-001-s137><indicate.anzeigen><de> Fehlmontage ausgeschlossen Als erster Hersteller von Schlaucharmaturen hat Voswinkel dieses Problem gelöst: Bei den neuen ECOVOS-Armaturen mit Blocksicherung wird das Montageende eindeutig angezeigt.
<G-vec00060-001-s137><indicate.anzeigen><en> Voswinkel is the first manufacturer of hose fittings to solve this problem: The new ECOVOS fittings with block stop feature clearly indicate when mounting is completed.
<G-vec00060-001-s138><indicate.anzeigen><de> Zudem wird durch farbliche LEDs angezeigt, dass das Gerät eine stehende Verbindung hat und auch, ob der Akku langsam leer läuft.
<G-vec00060-001-s138><indicate.anzeigen><en> In addition, colour LEDs indicate that the module has an established connection and also whether the battery is gradually going flat.
<G-vec00060-001-s139><indicate.anzeigen><de> Während die Einstellung U gilt, wird dies durch ein,,U`` in der Statuszeile von exaEdit angezeigt.
<G-vec00060-001-s139><indicate.anzeigen><en> As long as U is in effect, a U in the status line will indicate this.
<G-vec00060-001-s140><indicate.anzeigen><de> "Wenn sehr viele Figurenwechsel vorkommen, kann es auch einfacher sein, ""Instrument""-Definitionen für jeden Namen auf oberster Dateiebene zu definieren, sodass \instrumentSwitch der Wechsel der Figur angezeigt werden kann."
<G-vec00060-001-s140><indicate.anzeigen><en> "Alternatively, if there are many character changes, it may be easier to set up ""instrument"" definitions for each character at the top level so that \instrumentSwitch can be used to indicate each change."
<G-vec00060-001-s141><indicate.anzeigen><de> Zusätzlich wird der Schaltzustand der Eingänge mit je einer LED angezeigt.
<G-vec00060-001-s141><indicate.anzeigen><en> In addition, each input has an LED used to indicate its status.
<G-vec00060-001-s142><indicate.anzeigen><de> Es sollte indessen Folgendes klargemacht werden: Wenn in der Göttlichkeit irgendeiner Situation, unter extremen Umständen, und immer dann, wenn in Befolgung höchster Weisheit eine andere Vorgehensweise angezeigt erschiene – wenn die Ansprüche der Vollkommenheit aus irgendeinem Grunde eine andere und bessere Reaktionsweise gebieten sollten – dann würde der allweise Gott auf der Stelle in dieser besseren und passenderen Art handeln.
<G-vec00060-001-s142><indicate.anzeigen><en> It should be made clear, however, that, if, in the divinity of any situation, in the extremity of any circumstance, in any case where the course of supreme wisdom might indicate the demand for different conduct—if the demands of perfection might for any reason dictate another method of reaction, a better one, then and there would the all-wise God function in that better and more suitable way.
<G-vec00060-001-s143><indicate.anzeigen><de> Halten Sie die Taste Shift gedrückt und ziehen Sie die Auswahl genau zwischen die anderen beiden Spalten, bis die orangefarbenen Umrisse, die während des Ziehens angezeigt werden, sich bewegen.
<G-vec00060-001-s143><indicate.anzeigen><en> Hold down the Shift key and drag the selection exactly between the other two columns until the orange boundaries shown during the drag operation indicate a move.
<G-vec00060-001-s144><indicate.anzeigen><de> Die EtherCAT-P-Box enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s144><indicate.anzeigen><en> The EtherCATP Box has two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s145><indicate.anzeigen><de> D: Es wird angezeigt, wie viele Arbeitsmappen oder Dateien gedruckt werden.
<G-vec00060-001-s145><indicate.anzeigen><en> D: It will indicate how many workbooks or files will be printed.
<G-vec00332-001-s019><show.anzeigen><de> In der Tat, jede Art von Suchergebnissen, die angezeigt werden sind häufig tot Web-Links oder Web-Link zurück auf die genau gleiche Seite unter verschiedenen Namen.
<G-vec00332-001-s019><show.anzeigen><en> Definitely, any kind of search engine results page that do show up are typically dead links or web link back to the very same web page under various names.
<G-vec00332-001-s020><show.anzeigen><de> Mac iPhone 4 Ringtone Maker wird automatisch angezeigt iTunes Wiedergabeliste auf der linken Seite des Programms können Sie Ihre iTunes-Video auf dem Programm wählen, oder ziehen Sie Videos in das Programm direkt.
<G-vec00332-001-s020><show.anzeigen><en> Mac iPhone 4 Ringtone Maker will automatically show up iTunes playlist on the left of the program, you can choose your iTunes video to the program, or drag video to the program directly.
<G-vec00332-001-s021><show.anzeigen><de> Auch hier wird beim jeweiligen Namen die Position in der Etage angezeigt und beim Klick auf die Raumdetailseite verlinkt.
<G-vec00332-001-s021><show.anzeigen><en> Here again, move the cursor to the name to show the position, and click on the name to show the detail page.
<G-vec00332-001-s022><show.anzeigen><de> Wenn eine solche Bestätigung nicht angezeigt wird, muss die Korrektur komplex sein.
<G-vec00332-001-s022><show.anzeigen><en> If such a confirmation does not show, then the correction must be a complex one.
<G-vec00332-001-s023><show.anzeigen><de> "Wähle ""Suchen"", wenn deine Promoted Pins in den Suchergebnissen angezeigt werden sollen."
<G-vec00332-001-s023><show.anzeigen><en> "Choose ""Search"" to show your Promoted Pins in search results."
<G-vec00332-001-s024><show.anzeigen><de> In der 5-stelligen Preis Zitat kann jede Fraktion von 0 bis 9 angezeigt.
<G-vec00332-001-s024><show.anzeigen><en> In the 5-digit pricing quote, any fraction from 0 to 9 may show up.
<G-vec00332-001-s025><show.anzeigen><de> Strassenname und Strassennummer werden nun in der korrekten Reihenfolge angezeigt, entsprechend den Daten auf der zugehörigen Karte.
<G-vec00332-001-s025><show.anzeigen><en> Always show street number and street name in correct order based on map data.
<G-vec00332-001-s026><show.anzeigen><de> "Hinweis: Sie erhalten die Benennen Sie ""Ihren Ordnernamen"" um in das Kontextmenü in Outlook 2007 und ""Ihr Ordnername""Wird als der aktuelle Name des ausgewählten Ordners angezeigt."
<G-vec00332-001-s026><show.anzeigen><en> Note: You will get the Rename “your folder name” in the right-clicking menu in Outlook 2007, and “Your folder name” will show as the current name of selected folder.
<G-vec00332-001-s027><show.anzeigen><de> Wie bei jedem Produkt könnte es regelmäßig auf eBay oder Amazon, dennoch angezeigt dies ist nicht sehr wahrscheinlich so zuverlässig ab die CrazyBulk amtliche Web Site sowie es empfiehlt sich in der Regel nicht zu kaufen bei eBay oder Amazon als die Qualität oder Erstattungen können nicht garantiert werden.
<G-vec00332-001-s027><show.anzeigen><en> African Mango Extract can be bought from the BauerNutrition main web site from Algeria and also this seems like the only method to get it. Just like any product, it could periodically show up on ebay.com or Amazon, however this is not most likely to be as dependable as from the BauerNutrition main site and also it is normally recommended not to purchase from eBay or Amazon.com as the top quality or refunds could not be ensured.
<G-vec00332-001-s028><show.anzeigen><de> "• Wenn die Disc (Playlist) gewechselt wird, kann es dazu kommen, dass ""EJECT"" im Display angezeigt wird."
<G-vec00332-001-s028><show.anzeigen><en> "• When the disc is changed, ""EJECT"" will show up instantly."
<G-vec00332-001-s029><show.anzeigen><de> "Nachdem Sie die Formel eingegeben und anschließend die Eingabetaste gedrückt haben, wird die Zeilennummer der Zelle angezeigt, die ""Tinte""."
<G-vec00332-001-s029><show.anzeigen><en> "After entering the formula, and then press the Enter key, it will show the row number of the cell which contains ""ink""."
<G-vec00332-001-s030><show.anzeigen><de> Klicken Sie auf diesen Link und durch Google maps komplettes Bildschirmgroße wird Ihnen angezeigt, wo wir uns befinden.
<G-vec00332-001-s030><show.anzeigen><en> Please click in this link and the Google maps screen will show you where we are located.
<G-vec00332-001-s031><show.anzeigen><de> Klicken Sie auf die horizontale Linie neben der Beziehung UND, und es werden einige Bedingungsfelder angezeigt, klicken Sie auf die Bedingungsfelder und geben Sie das Kriterium einzeln nach Bedarf an.
<G-vec00332-001-s031><show.anzeigen><en> Click the horizontal line beside the relationship AND, and it will show some condition boxes, click the condition boxes and specify the criterion one after one as you need.
<G-vec00332-001-s032><show.anzeigen><de> Wenn sie dann noch immer auf dem Bildschirm „Bericht“ sind, wird der gewünschte Bericht angezeigt.
<G-vec00332-001-s032><show.anzeigen><en> If still on the report screen, the desired report will show.
<G-vec00332-001-s033><show.anzeigen><de> Ohne Zweifel, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel tot Web-Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00332-001-s033><show.anzeigen><en> Indeed, any type of search results page that do show up are usually dead web links or web link back to the very same page under different names.
<G-vec00332-001-s034><show.anzeigen><de> Wird dieser Punkt neben einer TV-Staffel oder Podcast-Serie angezeigt, wurde mindestens eine Folge der Staffel oder Serie noch nicht abgespielt.
<G-vec00332-001-s034><show.anzeigen><en> If this appears next to a TV show season or podcast series, there is at least one episode in the season or series that hasn't been played.
<G-vec00332-001-s035><show.anzeigen><de> • Session-Cookies:Das sind zeitlich begrenzte Cookies und diese werden durch das Schließen des Browsers ge-löscht.o adaptive_image: Speichert die aktuelle Auflösung, um die geeignete Bildgröße auszuspieleno has_js: Speichert, ob der Browser des Users JavaScript hat oder nicht, um bestimmte Funktionen oder Darstellungen wiederzugebeno cookie_agreed: Ob der User Cookie- Popup akzeptiert hat oder nicht, um zu entscheiden, ob dem User der Hinweis nochmal angezeigt werden muss oder nicht.
<G-vec00332-001-s035><show.anzeigen><en> • Session cookies:These are temporary cookies and they are deleted by closing the browser.o adaptive image: Saves the current resolution to play the appropriate image sizeo has_js: saves information on whether the user's browser has JavaScript as to provide specific functions or display formatso cookie_agreed: checks if the user has accepted the cookie popup to decide whether to show the notice again or not.
<G-vec00332-001-s036><show.anzeigen><de> Im Display können neben den Informationen des Bordcomputers (Bordcomputer 1 oder 2) auch Informationen weiterer Systeme angezeigt werden.
<G-vec00332-001-s036><show.anzeigen><en> As well as the figures from the on-board computer (computer 1 or 2), the display can also show information from other systems.
<G-vec00332-001-s037><show.anzeigen><de> Auf jeden Fall, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel Tote Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00332-001-s037><show.anzeigen><en> Indeed, any type of search engine results page that do show up are typically dead links or link back to the very same page under different names.
<G-vec00276-001-s056><advertise.anzeigen><de> Die Verwendung der DoubleClick-Cookies ermöglicht Google und seinen Partner-Webseiten lediglich die Schaltung von Anzeigen auf Basis vorheriger Besuche auf unserer oder anderen Webseiten im Internet.
<G-vec00276-001-s056><advertise.anzeigen><en> The use of DoubleClick cookies allows Google and its affiliate sites to advertise on the basis of prior visits to our or other websites on the internet.
<G-vec00276-001-s057><advertise.anzeigen><de> Händler können auf EMR Anzeigen schalten, um potentielle Kunden anzusprechen.
<G-vec00276-001-s057><advertise.anzeigen><en> As a vendor, you may be interested in advertise on EMR to find prospective buyers.
<G-vec00276-001-s058><advertise.anzeigen><de> My Catholic Standard Nachrichten, Kleinanzeige, Anzeigen und mehr.
<G-vec00276-001-s058><advertise.anzeigen><en> My Catholic Standard News, Classifieds, Advertise and more.
<G-vec00276-001-s059><advertise.anzeigen><de> Gelegentlich gibt es auch Anzeigen in der Zeitung (normalerweise in der Unterhaltung/Kunst Spalte) oder in dem Gemeinde Magazin.
<G-vec00276-001-s059><advertise.anzeigen><en> On occasion they may advertise in the local paper (usually in the entertainment/arts section) or community magazine.
<G-vec00276-001-s060><advertise.anzeigen><de> Somit können die Mitglieder in Echtzeit die Daten zu Arbeitssuchenden, Arbeitgebern sowie - allgemeiner betrachtet - zu Beschäftigungsangeboten angeben, anzeigen und modifizieren.
<G-vec00276-001-s060><advertise.anzeigen><en> In this way, the members can, in real-time, modify, specify and advertise data concerning jobseekers, employers, as well as – more generally –Â job offers.
<G-vec00276-001-s061><advertise.anzeigen><de> Nachrichten, Anzeigen und Read the Paper.
<G-vec00276-001-s061><advertise.anzeigen><en> News, Advertise and Read the Paper.
<G-vec00276-001-s062><advertise.anzeigen><de> Santa Ynez Valley Journal Geschichte, Writers, Archiv, Anzeigen und Search Artikel .
<G-vec00276-001-s062><advertise.anzeigen><en> Santa Ynez Valley Journal History, Writers, Archive, Advertise and Search articles.
<G-vec00276-001-s063><advertise.anzeigen><de> Weiser Signal American Submit News/Briefe, Anzeigen und Subscribe.
<G-vec00276-001-s063><advertise.anzeigen><en> Weiser Signal American Submit News/Letters, Advertise and Subscribe.
<G-vec00060-001-s162><indicate.anzeigen><de> atariModePossible muss anzeigen, daß der MMU-Switch erlaubt ist.
<G-vec00060-001-s162><indicate.anzeigen><en> atariModePossible must indicate that MMU switching is permitted.
<G-vec00060-001-s163><indicate.anzeigen><de> Ein solches Muster kann die Ähnlichkeit seines Trägers mit einem bestimmten Vertreter der Fauna anzeigen.
<G-vec00060-001-s163><indicate.anzeigen><en> Such a pattern may indicate the similarity of its carrier with a certain representative of the fauna.
<G-vec00060-001-s164><indicate.anzeigen><de> Alle drei Männer trugen Luftwaffen-Uniformen ohne Aufkleber, die anzeigen, wer sie waren.
<G-vec00060-001-s164><indicate.anzeigen><en> All three of the men were wearing Air Force uniforms without any patches to indicate who they were.
<G-vec00060-001-s165><indicate.anzeigen><de> Sie kann den Grad der magnetischen Aufladung von Gegenständen oder Wasser anzeigen.
<G-vec00060-001-s165><indicate.anzeigen><en> It can indicate the degree of magnetization of objects or water.
<G-vec00060-001-s166><indicate.anzeigen><de> Es gibt eine andere Rangordnung von Bedeutungen, in der sie die Aura oder Tätigkeit göttlicher Wesen anzeigen, wie Krishna, Mahakali, Radha, oder auch anderer übermenschlicher Wesen; es gibt eine weitere Kategorie, in der sie die Aura um Objekte oder lebende Personen anzeigen – und hiermit ist die Reihe der Möglichkeiten noch nicht erschöpft.
<G-vec00060-001-s166><indicate.anzeigen><en> There is another order of significances in which they indicate the aura or the activity of divine beings, Krishna, Mahakali, Radha or else of other superhuman beings; there is another in which they indicate the aura around objects or living persons – and that does not exhaust the list of possibilities.
<G-vec00060-001-s168><indicate.anzeigen><de> Ein komplettes Blutbild durchgeführt werden wird, einschließlich einer chemischen Blutbild, ein komplettes Blutbild, und eine Urinanalyse — die Ergebnisse von denen das Vorhandensein von Stoffen, die möglicherweise die Ursache eine verlangsamte Herzfrequenz anzeigen kann.
<G-vec00060-001-s168><indicate.anzeigen><en> A complete blood profile will be conducted, including a chemical blood profile, a complete blood count, and a urinalysis — the results of which may indicate the presence of substances that might be causing a slowed heart rate.
<G-vec00060-001-s169><indicate.anzeigen><de> "Dieser Punkt ist erkennbar weil links Schilder sind, die die Wege beim Namen anzeigen, die Strecke in die man rechts abbiegt ist als ""Ameno"" benannt."
<G-vec00060-001-s169><indicate.anzeigen><en> This point is recognizable because on the left side of the path there are some signs that indicate the names of the trails.
<G-vec00060-001-s170><indicate.anzeigen><de> Die LEDs, die den Zustand des ganzen Systems anzeigen, befinden sich über dem Display.
<G-vec00060-001-s170><indicate.anzeigen><en> LEDs which indicate the status of the entire system have been provided above the keypad display.
<G-vec00060-001-s171><indicate.anzeigen><de> Wenn diesen Daten das Resultat, unten gezeigt geplottet, ein Verhältnis zwischen dem Preisniveau und der Menge des Geldumlaufs anzeigen Sie werden, welches hier durch die kumulativen Importe des Schatzes approximiert wird.
<G-vec00060-001-s171><indicate.anzeigen><en> When these data are plotted the result, shown below, indicate a relationship between the price level and the amount of money in circulation which is here approximated by the cumulative imports of treasure.
<G-vec00060-001-s172><indicate.anzeigen><de> "Wenn der Anwender Daten diesen Formats über das Fenster zieht, wird der Mauscursor anzeigen, dass die Daten hier abgelegt (""fallen gelassen"") werden können."
<G-vec00060-001-s172><indicate.anzeigen><en> When the user drags data of this format over the window, the cursor will indicate that the data can be dropped there.
<G-vec00060-001-s173><indicate.anzeigen><de> Schüler präsentieren stolz ihre ESA Nachweise welche die exakte Position der ISS anzeigen während die Programmierung im Weltall lief.
<G-vec00060-001-s173><indicate.anzeigen><en> Students proudly display their ESA certificates, which indicate the position of the ISS when their code was running in space.
<G-vec00060-001-s174><indicate.anzeigen><de> Verschiedene Stoffwechselprodukte von NMP und NEP können im Urin bestimmt werden und somit eine Belastung anzeigen.
<G-vec00060-001-s174><indicate.anzeigen><en> Various NMP and NEP metabolites can be tracked in urine and indicate exposure.
<G-vec00060-001-s175><indicate.anzeigen><de> 1 Schalt- und Überwachungseinheit mit Sicherungen, Motorschutzschalter, Vorwahl-Zählwerk zum Anzeigen der Fallzahl und zum Stillsetzen der Anlage.
<G-vec00060-001-s175><indicate.anzeigen><en> 1 switching and monitoring unit with fuses, protecting switch for the motor, preset able counter to indicate the number of falls and to switch off the unit.
<G-vec00060-001-s176><indicate.anzeigen><de> Diese Störung kennzeichnet die Personen wie die Gegenstände: Zum einen sind es dysfunktionale Versatzstücke der Mode (Schuhe ohne Absätze oder als sich um den Fuß zu schnallender Absatz), die die potenziellen TrägerInnen zu geradezu unmöglichen Haltungen und Bewegungen zwingen, zum anderen sind es die autistischen Rituale der filmischen Protagonisten angesichts eines Anderen, das Unerreichbar scheint, die diese Störung anzeigen.
<G-vec00060-001-s176><indicate.anzeigen><en> This disorder is characteristic of the individuals and of the objects: in one case it is the dysfunctional set pieces of fashion (shoes with no heels or a heel strapped around the ankle), that compel the potential wearers to perform practically impossible postures and movements; on the other hand, the autistic rituals of the film protagonist vis-Ã -vis the other, that appears unattainable, that indicate this disorder.
<G-vec00060-001-s177><indicate.anzeigen><de> Views sind temporäre Tabellen, die den gesamten oder teilweisen Inhalt einer oder mehrerer Tabellen anzeigen.
<G-vec00060-001-s177><indicate.anzeigen><en> Views are temporary tables which indicate the whole or partial contents of one or several tables.
<G-vec00060-001-s178><indicate.anzeigen><de> Der aktuelle Prototyp nutzt zwei Magnetfeldsensoren, welche die Position zuverlässig anzeigen, sobald sich die beiden Spulen auf einen Abstand von 1,5 Metern genähert haben.
<G-vec00060-001-s178><indicate.anzeigen><en> The current prototype uses two magnetic field sensors which indicate the position reliably as soon as the two coils approach each other to a distance of 1.5 meters.
<G-vec00060-001-s179><indicate.anzeigen><de> Aufklärung lieferte unser Guide, der uns durch Soweto führte: Jeder Stadtteil hat sein eigenes Handzeichen, mit dem die Fahrgäste anzeigen, in welche Richtung sie wollen.
<G-vec00060-001-s179><indicate.anzeigen><en> Our guide through Soweto explained it to us: Each suburb has its own hand signal, by which the passengers indicate which direction they want to go.
<G-vec00060-001-s180><indicate.anzeigen><de> Ich sollte auch erwähnen, dass bestimmte Handgesten Buchstaben des Alphabets und Zahlen anzeigen und zur Zeit Poussins verstanden worden wären.
<G-vec00060-001-s180><indicate.anzeigen><en> I should also mention that certain hand gestures indicate letters of the alphabet and numbers, and would have been understood at the time Poussin painted them.
<G-vec00060-001-s038><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s038><reveal.anzeigen><en> The benefits stacked up beside various other kinds of weight loss devices reveal this kind of ketone to be secure, organic and efficient with absolutely no side effects.
<G-vec00060-001-s040><reveal.anzeigen><de> Kontrollkästchen, die in romanischen Sprachen lange Textbeschreibungen haben, die aufgrund des beschränkten Platzes abgeschnitten werden, kommen jetzt automatisch mit Tool-Tips daher, die den vollständigen Text anzeigen, wenn man mit dem Mauszeiger darüber verharrt.
<G-vec00060-001-s040><reveal.anzeigen><en> Check boxes with long text labels in Romance languages that get truncated because of the limited space available now automatically come with tooltips that reveal the complete text when hovering the mouse cursor over the control.
<G-vec00060-001-s041><reveal.anzeigen><de> Und er kann Allergie und Panik anzeigen.
<G-vec00060-001-s041><reveal.anzeigen><en> And it can reveal allergies and panic.
<G-vec00060-001-s042><reveal.anzeigen><de> Sie verraten außerdem eine Retouren-Adresse für Kunden weltweit und auch die von St. Lucia auf ihrer Webseite empfehlen, dass sie auf Saint Lucia oft Schiff sollten, wenn sie wirklich das Bedürfnis, eine separate Adresse für Saint Lucia anzeigen gibt.
<G-vec00060-001-s042><reveal.anzeigen><en> They additionally reveal a returns address for global consumers and those from Saint Lucia on their returns page, suggesting they must ship to Saint Lucia quite often if they really feel the need to reveal a separate address for Saint Lucia. They provide an explanation of just how much delivery prices linked with overseas delivery, so customers should not be fear of any type of extra hidden expenses.
<G-vec00060-001-s051><reveal.anzeigen><de> Fingerabdruck vom Tatort soll bald auch Drogenmissbrauch anzeigen.
<G-vec00060-001-s051><reveal.anzeigen><en> Fingerprints from the scene of the crime will soon reveal drug abuse.
<G-vec00060-001-s056><reveal.anzeigen><de> Bevor Panel-Daten anzeigen, ob der Launch oder Relaunch erfolgreich oder nicht erfolgreich verläuft, liefert dieses Testverfahren Klarheit über die Attraktivität des Produktes und mögliche Vorbehalte.
<G-vec00060-001-s056><reveal.anzeigen><en> Before panel data can reveal whether or not a launch or relaunch is going successfully, this quickly established and conducted procedure gives you clarity about the attractiveness of the product and potential reservations.
<G-vec00332-001-s038><show.anzeigen><de> Schritt 3: Jetzt gelangen Sie in das Dialogfeld Mail Setup und klicken auf Profile anzeigen klicken.
<G-vec00332-001-s038><show.anzeigen><en> Step 3: Now you get into the Mail Setup dialog box, and click the Show Profiles button.
<G-vec00332-001-s039><show.anzeigen><de> Du kannst die Informationen, die wir zum Anzeigen von Promoted Pins und anderen Empfehlungen verwenden, wie folgt in deinen Einstellungen anpassen.
<G-vec00332-001-s039><show.anzeigen><en> You can adjust the info we use to show you Promoted Pins and other recommendations in your settings by following the instructions below.
<G-vec00332-001-s040><show.anzeigen><de> "Wenn die Signalspannung über 36V befindet, wird der LCD-Bildschirm-Symbol anzeigen "">>""."
<G-vec00332-001-s040><show.anzeigen><en> "When the signal voltage is over 36V, the LCD screen will show icon "">>'."
<G-vec00332-001-s041><show.anzeigen><de> Wenn alle Schichten sichtbar sind, sollte das Bildfenster nun unseren Text mit gelblicher Färbung in der Mitte und einem weich abgedunkeltem Rand anzeigen.
<G-vec00332-001-s041><show.anzeigen><en> If all of the layers are visible, the image box should now show our text with yellowish coloring to the center with a softly darkened border.
<G-vec00332-001-s042><show.anzeigen><de> Scrollen Sie ganz nach unten und klicken Sie auf Erweiterte Einstellungen anzeigen.
<G-vec00332-001-s042><show.anzeigen><en> Scroll down to the bottom and click Show advanced settings.
<G-vec00332-001-s043><show.anzeigen><de> Wenn Sie also alle Wechselbüros für die Richtung Bank Card USD sehen wollen -> Bitcoin Cashsehen möchten, klicken Sie auf „Alle anzeigen”.
<G-vec00332-001-s043><show.anzeigen><en> "So if you want to see all the exchangers for the direction Bank Card USD -> Bitcoin Cash, click the ""Show all""."
<G-vec00332-001-s044><show.anzeigen><de> "Konten mit dem Abonnementmodus ""Auf Anfrage"" ohne aktivierter Option ""In der Bewertung anzeigen""."
<G-vec00332-001-s044><show.anzeigen><en> Accounts with “By request” subscription mode without “Show in the Rating” option enabled.
<G-vec00332-001-s045><show.anzeigen><de> Wenn die Option 'Gruppen in Formatliste anzeigen' aktiviert ist, werden die Gruppennamen in den Formatlisten angezeigt (1).
<G-vec00332-001-s045><show.anzeigen><en> When the 'Show Groups in Format List' option is enabled, the group names will be displayed in the format lists (1) .
<G-vec00332-001-s046><show.anzeigen><de> Wenn in der Struktur der Elementtabelle Felddefinitionen angezeigt werden (Definition anzeigen), können Sie die Definitionen bearbeiten, indem Sie die Definition auswählen und eine Option aus der Auswahlliste der Definition auswählen (siehe Abbildung oben).
<G-vec00332-001-s046><show.anzeigen><en> When the element's table structure shows field definitions (Show Definition), the definitions can be edited by selecting the definition and selecting an option from the definition's combo box (see screenshot above).
<G-vec00332-001-s047><show.anzeigen><de> Dieser Controller verfügt über zwei Steuerknöpfe und zwei LEDs, die anzeigen, wenn jede Funktion aktiv ist.
<G-vec00332-001-s047><show.anzeigen><en> This controller features two control knobs and two Lights that show when each function is active.
<G-vec00332-001-s048><show.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00332-001-s048><show.anzeigen><en> The benefits stacked up alongside various other types of weight loss devices show this type of ketone to be secure, organic and effective with absolutely no side effects.
<G-vec00332-001-s049><show.anzeigen><de> Schaltfläche Begriffsebene des aktuellen Begriffs anzeigen: Zeigt zum ausgewählten Term eine Begriffsinformation (z.
<G-vec00332-001-s049><show.anzeigen><en> Show concept information button: Click to show the concept information for the selected term (e.g.
<G-vec00332-001-s050><show.anzeigen><de> LED-Fernseher (Bild anzeigen) Hier zeigen wir nur Produktbilder von Sponsor-Marken, die an Open Icecat teilnehmen, da Produktbilder dem Urheberrecht unterliegen können.
<G-vec00332-001-s050><show.anzeigen><en> (show image) Here, we only show product images of sponsoring brands that joined Open Icecat as product images can be subject to copyrights.
<G-vec00332-001-s051><show.anzeigen><de> Sie zeigen außerdem eine Retouren-Adresse für internationale Verbraucher wie auch die von Jan Mayen auf ihrer Webseite empfehlen, sie müssen sehr oft auf Jan Mayen Schiff, wenn sie wirklich das Gefühl gibt das sollte eine andere Adresse für Jan Mayen anzeigen.
<G-vec00332-001-s051><show.anzeigen><en> They additionally show a returns address for global consumers and those from Jan Mayen on their returns page, proposing they must ship to Jan Mayen quite often if they really feel the have to show a separate address for Jan Mayen.
<G-vec00332-001-s052><show.anzeigen><de> "Beispielsweise können wir deinen Freunden anzeigen, dass du an einer beworbenen Veranstaltung interessiert bist oder eine Seite mit ""Gefällt mir"" markiert hast, die von einer Marke erstellt worden ist, die uns dafür bezahlt hat, dass wir ihre Anzeigen auf Facebook zeigen."
<G-vec00332-001-s052><show.anzeigen><en> For example, we may show your friends that you are interested in an advertised event or have liked a Page created by a brand that has paid us to display its ads on Facebook.
<G-vec00332-001-s053><show.anzeigen><de> Ihr Bike Fähigkeiten auf die Spur anzeigen .
<G-vec00332-001-s053><show.anzeigen><en> Show your bike skills on the track.
<G-vec00332-001-s055><show.anzeigen><de> Ohne jede Tutorials zu sprechen, dieser Ebene des Problems möglicherweise für einige lästige anzeigen..
<G-vec00332-001-s055><show.anzeigen><en> Without any tutorials to speak of, this level of problem might show annoying for some.
<G-vec00332-001-s056><show.anzeigen><de> Das Band ist in Tabulatoren eingeteilt, die aufeinander bezogene Funktionen gruppieren und sie zusammen anzeigen.
<G-vec00332-001-s056><show.anzeigen><en> The Ribbon is divided into tabs that group related functions and show them together.
<G-vec00060-001-s181><indicate.anzeigen><de> Bei diesen Prozessen, und wie die bisher diskutierte Kunst anzeigt, geht es dabei immer wieder um die Frage, was diese Umwandlungsprozesse für die Menschen bedeuten und was für Subjekte sie hervorbringen.
<G-vec00060-001-s181><indicate.anzeigen><en> As the works of art discussed above indicate, these processes are repeatedly concerned with the question of what these processes of transformation mean for humans and what kinds of subjects they produce.
<G-vec00060-001-s182><indicate.anzeigen><de> Wenn wir zur Sonne hinsehen, dann können wir nichts bemerken, was eine solche Rotation anzeigt, genau weil es keine leicht sichtbare Merkmale auf der Oberfläche der Sonne gibt.
<G-vec00060-001-s182><indicate.anzeigen><en> When we look at the sun, then we cannot notice something, which would indicate such a rotation, exactly because there are no easily visible features on the surface of the sun.
<G-vec00060-001-s183><indicate.anzeigen><de> Das Firmware Update könnte noch etwas optimiert werden, da die Software keinen durchgehenden Status anzeigt.
<G-vec00060-001-s183><indicate.anzeigen><en> The Firmware update software could be optimized some more, since the software does not indicate a continuously status.
<G-vec00060-001-s184><indicate.anzeigen><de> Leber-Enzym worths wird sicherlich mit der Nutzung zu verbessern, die während dies Schäden anzeigt es Angst macht vorschlagen, die zu Schäden führen könnte.
<G-vec00060-001-s184><indicate.anzeigen><en> Liver enzyme worths will certainly enhance with use, which while this does not indicate damage it does show tension that could lead to damages.
<G-vec00060-001-s185><indicate.anzeigen><de> 1983 präsentiert Blancpain mit dem kleinsten Automatikuhrwerk, das Mondphasen, Tag, Monat und Datum anzeigt, eine Weltneuheit und rückt damit eine bis dahin weitgehend in Vergessenheit geratene Komplikation in den Mittelpunkt.
<G-vec00060-001-s185><indicate.anzeigen><en> In 1983, Blancpain brought out a world first with the smallest self-winding movement to indicate moon phase, day, month and date, thereby bringing back a complication which had all but disappeared at the time.
<G-vec00060-001-s186><indicate.anzeigen><de> Obwohl Oxandrolone als mildeste anabole Steroide daran gedacht, anzeigt es nicht, dass es keine Nebenwirkungen hat.
<G-vec00060-001-s186><indicate.anzeigen><en> Although Oxandrolone is thought about as the mildest steroid stacks, it does not indicate that it has no side-effects.
<G-vec00060-001-s187><indicate.anzeigen><de> In einer idealen Situation ist es notwendig, das Arzneimittel nur nach Erhalt der Ergebnisse der Analysen zu verschreiben, was anzeigt, für welche speziellen Mittel die nachgewiesenen Mikroorganismen empfindlich sind.
<G-vec00060-001-s187><indicate.anzeigen><en> In an ideal situation, it is necessary to prescribe the drug only after receiving the results of the analyzes, which will indicate what particular agents the detected microorganisms are sensitive to.
<G-vec00060-001-s188><indicate.anzeigen><de> Wie man auf dem unteren Bild erkennen kann, sind die Hauptfarben Orange und Violett, was Negativität anzeigt.
<G-vec00060-001-s188><indicate.anzeigen><en> As one can see from the picture below, the main colours seen are orange and violet, which indicate negativity.
<G-vec00060-001-s189><indicate.anzeigen><de> Die Verwendung des Namens der Firma Aquapol ist hier lediglich ein Mittel, das anzeigt, dass eine andere Person als der Namensträger unabhängige Informationen über die Produkte der Firma gibt.
<G-vec00060-001-s189><indicate.anzeigen><en> The use of the name of the firm Aquapol is only a means to indicate that a person different from it gives independent information about it.
<G-vec00060-001-s190><indicate.anzeigen><de> Ich denke, dass es ziemlich offensichtlich war, dass die Seite für dein Telefon oder andere ähnliche Geräte gedacht ist, da der Name der Seite das verdammt nochmal anzeigt.
<G-vec00060-001-s190><indicate.anzeigen><en> I think that it was quite obvious that the site is meant for your phone, or other similar devices, since the name of the site does fucking indicate that.
<G-vec00060-001-s191><indicate.anzeigen><de> Die meisten Browser sind Cookies akzeptieren, aber Sie können Ihren Browser so einstellen, dass alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00060-001-s191><indicate.anzeigen><en> Most browsers are initially set up to accept cookies, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00060-001-s192><indicate.anzeigen><de> Einzig der leuchtend rote Aktivator-Knopf, der präzise anzeigt, an welchem Tisch man sitzt und welches Spiel man spielt, ist ein Pluspunkt.
<G-vec00060-001-s192><indicate.anzeigen><en> The one saving grace for them are the bright red activator buttons that indicate precisely which table you're at, and what game you're playing.
<G-vec00060-001-s193><indicate.anzeigen><de> Dabei muss sich die Frau einem Bluttest-Profil zu unterziehen, das die immunologische Umwelt ihres reproduktiven Systems anzeigt.
<G-vec00060-001-s193><indicate.anzeigen><en> It requires the woman to undergo a profile of blood tests that indicate the immunological environment within her reproductive system.
<G-vec00060-001-s194><indicate.anzeigen><de> Stellen Sie Ihren Browser alle Cookies, einschließlich Cookies mit unseren Dienstleistungen verbunden zu blockieren, oder anzeigt, wenn ein Cookie von uns gesetzten.
<G-vec00060-001-s194><indicate.anzeigen><en> Set your browser to block all cookies, including cookies associated with our services, or to indicate when a cookie is being set by us.
<G-vec00060-001-s195><indicate.anzeigen><de> Der Verband der Automobilingenieure hat eine Kategorisierung von Motorölen vorgenommen, die Viskosität (Zähflüssigkeit) und die Temperatur anzeigt, bei der Motoröl verwendet werden kann.
<G-vec00060-001-s195><indicate.anzeigen><en> The Society of Automotive Engineers has developed a categorization of motor oils which will indicate the viscosity (thickness) and temperature in which engine oil can be used.
<G-vec00060-001-s196><indicate.anzeigen><de> Der Indikator wird wahrscheinlich spätestens zum Launch implementiert und einem Wifi Symbol (wie auf eurem Mobiltelefon) ähneln, welches euch Stufenweise anzeigt ob eure Gruppenmitglieder in Reichweite sind oder nicht.
<G-vec00060-001-s196><indicate.anzeigen><en> The indicator will be probably implemented latest by launch and it will look similar to the Wifi Symbol (on your cell-phone) that will gradually indicate whether or not your party members are in range.
<G-vec00060-001-s197><indicate.anzeigen><de> Deaktivieren von Cookies Die meisten Browser sind standardmäßig so eingestellt, dass sie Cookies akzeptieren, aber Sie können Ihren Browser so einstellen, dass er alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00060-001-s197><indicate.anzeigen><en> Disabling cookies Most browsers are set to accept cookies by default, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00060-001-s198><indicate.anzeigen><de> Die App übermittelt diesen Mitschnitt an den Server, der einen Abgleich der Ist-Werte mit den Soll-Werten vornimmt und auf diese Weise Fehlfunktionen frühzeitig anzeigt.
<G-vec00060-001-s198><indicate.anzeigen><en> The app sends this recording to a server, which compares current values with target values and thus can indicate malfunctions early on.
<G-vec00060-001-s199><indicate.anzeigen><de> Parallel zur Strömungsrichtung dient ein Zeiger des Trägers, der die Position auf der Skala der Versuchsrinne anzeigt.
<G-vec00060-001-s199><indicate.anzeigen><en> Parallel to the flow, a pointer of the carrier is used to indicate the position on the scale of the experimental flume.
<G-vec00060-001-s238><indicate.anzeigen><de> * Die 2 Bilder der Chromversion sind verfügbar, um die Abmessungen anzuzeigen.
<G-vec00060-001-s238><indicate.anzeigen><en> * The 2 pictures of the chrome version are available to indicate the dimensions.
<G-vec00060-001-s239><indicate.anzeigen><de> Passagen in der Nähe vom Ende des Leviathan erschien, um anzuzeigen, dass Hobbes wollte seinen Frieden mit der englischen Regierung, die verärgert die Royalisten.
<G-vec00060-001-s239><indicate.anzeigen><en> Passages near the end of the Leviathan appeared to indicate that Hobbes was trying to make his peace with the English government, which angered the Royalists.
<G-vec00060-001-s240><indicate.anzeigen><de> Diese Methode hat einen booleschen Wert als Parameter, um anzuzeigen, ob Schaltflächen gezeichnet werden sollen oder nicht.
<G-vec00060-001-s240><indicate.anzeigen><en> This method takes a boolean as a parameter to indicate whether push buttons should be painted or not.
<G-vec00060-001-s241><indicate.anzeigen><de> Sie können Flair wählen Sie Ihre Nationalität, um anzuzeigen, durch Bearbeiten oben klicken.
<G-vec00060-001-s241><indicate.anzeigen><en> You can select flair to indicate your nationality by clicking edit above.
<G-vec00060-001-s242><indicate.anzeigen><de> Liste der Geräte: Mit nur verschiedenen Videorecorder Fügen Sie die IP-Adresse des Recorders und Bearbeiten von Videorecordern bereits hinzugefügt anzuzeigen.
<G-vec00060-001-s242><indicate.anzeigen><en> List of Devices: Add different video recorders with only indicate the IP address of the recorder and edit video recorders already added.
<G-vec00060-001-s243><indicate.anzeigen><de> "Halten Sie gleichzeitig Ihre Hand, um die universelle Geste ""Stopp / Stopp / Nein"" anzuzeigen."
<G-vec00060-001-s243><indicate.anzeigen><en> "At the same time, hold your hand to indicate the universal gesture of ""stop / halt / no""."
<G-vec00060-001-s244><indicate.anzeigen><de> Dieses Foto scheint eine Art 'Blockade' durch Frank anzuzeigen, aber sie war minimal.
<G-vec00060-001-s244><indicate.anzeigen><en> This photo seems to indicate some level of blockage on Frank's side, but it was minimal.
<G-vec00060-001-s245><indicate.anzeigen><de> Das Muster auf ihm scheint, anzuzeigen, daя es von der westlichen Periode Zhou (1100 BC bis 770 BC) entstehen kann.
<G-vec00060-001-s245><indicate.anzeigen><en> The pattern on this replica seems to indicate that it may originate from the Western Zhou period (1100 BC to 770 BC).
<G-vec00060-001-s246><indicate.anzeigen><de> Das Team-Namen sind auf dem Board, um schriftliche und eine 0 platziert neben jedem Namen auf den aktuellen Spielstand anzuzeigen.
<G-vec00060-001-s246><indicate.anzeigen><en> The team names are written on the board in order and a 0 placed next to each name to indicate the current score.
<G-vec00060-001-s247><indicate.anzeigen><de> Da ein höheres Hoch und ein höheres Tief gebildet wurden, wurde Block 1 blau gekennzeichnet, um seine stark bullische Tendenz anzuzeigen.
<G-vec00060-001-s247><indicate.anzeigen><en> Since a higher high and a higher low were created, Block 1 has been labeled in blue to indicate its strong bullish bias.
<G-vec00060-001-s248><indicate.anzeigen><de> Erhöhte Konkurrenz, Produktdiversifizierung Linien scheinen, anzuzeigen, dass diese Abbildungen fortfahren, sich aufwärts zu bewegen.
<G-vec00060-001-s248><indicate.anzeigen><en> Increased competition, diversification of product lines seem to indicate that these figures will continue to move upward.
<G-vec00060-001-s249><indicate.anzeigen><de> Bei VMware®- oder Hyper-V®-Instanzen färben sich nur numerische Werte rot, um die Überlastung anzuzeigen.
<G-vec00060-001-s249><indicate.anzeigen><en> For VMware® or Hyper-V® instances, only the numerical values turn red to indicate over allocation.
<G-vec00060-001-s250><indicate.anzeigen><de> "Der Backslash ""\"" läßt sich als letztes Zeichen in einer Zeile dazu verwenden, die Fortsetzung der Direktive in der nächsten Zeile anzuzeigen."
<G-vec00060-001-s250><indicate.anzeigen><en> "The backslash ""\"" may be used as the last character on a line to indicate that the directive continues onto the next line."
<G-vec00060-001-s251><indicate.anzeigen><de> Diese Informationen können kooperieren in ihren künstlerischen Schöpfungen zu durchdringen und versuchen, die Geheimnisse zu entwirren, dass sie vererben, und auch, um anzuzeigen, dass Blake große Aufmerksamkeit für die menschliche Intuition hatte, anzeigen, einschließlich, sofort aus dem Grunde, dass während der historischen Zeit herrschte in der er lebte.
<G-vec00060-001-s251><indicate.anzeigen><en> This information can cooperate to penetrate in their artistic creations and try to unravel the mysteries that they bequeath, and also to indicate that Blake had great attention to human intuition, showing, including, right away from the reason that prevailed during the historical period in which he lived.
<G-vec00060-001-s252><indicate.anzeigen><de> Dieses Produkt wurde gemäß den Anforderungen von CE hergestellt, um die Konformität mit der grundlegenden Gesundheit und Sicherheit anzuzeigen.
<G-vec00060-001-s252><indicate.anzeigen><en> This product was produced under the requirements of CE to indicate conformity with the essential health and safety.
<G-vec00060-001-s253><indicate.anzeigen><de> Wenn Sie eingeben '2013 / 03 / 21 In eine Zelle wird dieser Apostroph vor dem Datum verwendet, um Excel anzuzeigen, dass der Wert in der Zelle ein Textwert ist (siehe folgenden Screenshot).
<G-vec00060-001-s253><indicate.anzeigen><en> When you input '2013/03/21 into a cell, that apostrophe before the date is used to indicate to Excel that the value in the cell is text value (see following screenshot).
<G-vec00060-001-s254><indicate.anzeigen><de> Das Kreuz steht für den Pakt mit den Menschen in den vier Gestalten ansehen, Personifikationen der Theologie, Literatur, Wissenschaft, und Kunst, zu dem greifen sie die Kinder der neuen Dämonen war, während eine Schar von Kritzeleien unerklärlich, lebendige Farben, Es erinnert an die geheimnisvolle Warten auf Rettung, als Embryonen bei der jungen Generation, um anzuzeigen, dass nichts verloren geht.
<G-vec00060-001-s254><indicate.anzeigen><en> The cross represents the pact with men in the four figures contemplating, personifications of Theology, literature, science, and art, to which they attack the children of the new demons was, while a bevy of doodles inexplicable, vibrant color, It evokes the mysterious waiting for salvation, as embryos related to new generations, to indicate that nothing is lost.
<G-vec00060-001-s255><indicate.anzeigen><de> Nirgendwo im Heiligen Evangelium und zu jeder Zeit seiner Verkündigung, das fleischgewordene Wort Gott hat gesagt, dass viele einladender und barmherzig zu sein, die moralische Unordnung zu empfangen und zu legitimieren, oder dass Sie Angst zu haben, zu nennen und die moralische Störung als solche, um anzuzeigen,, Bewegen auf falschen Vorwänden der Barmherzigkeit und die Falschakzeptanz.
<G-vec00060-001-s255><indicate.anzeigen><en> Nowhere in the Holy Gospel and at any time of His preaching, the Incarnate Word of God has ever said that to be welcoming and merciful to accommodate and legitimize the moral disorder, or that you have to be afraid to call and to indicate the moral disorder as such, moving on false pretexts of mercy and false acceptance.
<G-vec00060-001-s256><indicate.anzeigen><de> Wird verwendet, um das Ende irgendwelcher Medien, zum Beispiel das Ende eines Bandlaufwerks, anzuzeigen.
<G-vec00060-001-s256><indicate.anzeigen><en> Used to indicate the end of some media, for example the end of a tape drive
<G-vec00358-001-s057><show.anzeigen><de> Sie wurde herausgebracht, um Werbeanzeigen anzuzeigen, weil Super Web LLC, der Herausgeber von Cyti Web, Geld für Pay-per-Click-Websites erhält.
<G-vec00358-001-s057><show.anzeigen><en> It has been released in order to show advertisements because Super Web LLC, which is the publisher of Cyti Web, receives money from pay-per-click websites.
<G-vec00358-001-s058><show.anzeigen><de> Die Karte verzweigt dann in separate Zellen, um Details oder Beispiele für das Thema anzuzeigen.
<G-vec00358-001-s058><show.anzeigen><en> The map then branches out into separate cells to show details or examples of the topic.
<G-vec00358-001-s059><show.anzeigen><de> Man kann jetzt bei Desktop-Browsern das Bild anklicken um die obere und untere Leiste anzuzeigen und auch auszublenden.
<G-vec00358-001-s059><show.anzeigen><en> You can now click the image in desktop browsers to show and also hide the top and bottom bars.
<G-vec00358-001-s060><show.anzeigen><de> Verwende deine Highlights zum einfachen Bearbeiten oder um die Sensorendaten in deinem finalen Clip anzuzeigen.
<G-vec00358-001-s060><show.anzeigen><en> Use your highlights for easy editing or to show sensor stats in your final video.
<G-vec00358-001-s061><show.anzeigen><de> Klicken Sie auf das Diagramm, um es anzuzeigen Diagrammwerkzeuge schwimmen Band, dann klick Layout > Achsen.
<G-vec00358-001-s061><show.anzeigen><en> Click the chart to show Chart Tools in the Ribbon, then click Layout > Axes.
<G-vec00358-001-s062><show.anzeigen><de> Ebenso verwenden wir die Geo-Lokalisierung, um Ihnen in unserem Online Shop die richtigen Produkte, Preise und Steuern Ihres jeweiligen Landes anzuzeigen.
<G-vec00358-001-s062><show.anzeigen><en> Further, we use geo localisation to show you the right products, prices and taxes of the respective country in our online shop.
<G-vec00358-001-s063><show.anzeigen><de> Sie können diese ausblenden, es kann jedoch sinnvoll sein, sie wieder anzuzeigen.
<G-vec00358-001-s063><show.anzeigen><en> You can switch them off, but it may be useful to show them again.
<G-vec00358-001-s064><show.anzeigen><de> Ziel ist es, die Seite, die Google als die Relevanteste für den Nutzer erachtet, ganz oben auf der Liste anzuzeigen.
<G-vec00358-001-s064><show.anzeigen><en> The aim is to show the page that Google perceives as most relevant to users at the top of the list.
<G-vec00358-001-s065><show.anzeigen><de> Sie können Total zu Ihrem Formular hinzufÃ1⁄4gen, um die Zusammenfassung der Zahlung anzuzeigen, bevor Benutzer auf Senden klicken.
<G-vec00358-001-s065><show.anzeigen><en> You can add Total to your form to show the summary of the payment before users press Submit.
<G-vec00358-001-s066><show.anzeigen><de> Hier zeige ich Ihnen eine Möglichkeit, das Thema über oder unter den Absendern in der E-Mail-Liste in Microsoft Outlook anzuzeigen.
<G-vec00358-001-s066><show.anzeigen><en> Here I will show you a way to show the subject above or below the senders in mails list in Microsoft Outlook.
<G-vec00358-001-s067><show.anzeigen><de> Wenn Sie Ergebnisse zuvor in absteigender Reihenfolge sortiert haben, müssen Sie erneut auf die Spaltenbezeichnung klicken, um die Sortierreihenfolge wieder umzukehren und den höchsten Ressourcenverbrauch oben in der Liste anzuzeigen.
<G-vec00358-001-s067><show.anzeigen><en> If you have previously sorted results in descending order, you must click the column label again to reverse the sort order and show the highest resource consumers at the top of the list.
<G-vec00358-001-s068><show.anzeigen><de> Ein Fenster wird geöffnet, um den Erstellungsprozess anzuzeigen.
<G-vec00358-001-s068><show.anzeigen><en> A window is opened to show the build progress.
<G-vec00358-001-s069><show.anzeigen><de> Dann erscheint die zweite Select Specific Cells, um anzuzeigen, wie viele Zellen ausgewählt sind.
<G-vec00358-001-s069><show.anzeigen><en> Then the second Select Specific Cells comes out to show how many cells are selected.
<G-vec00358-001-s070><show.anzeigen><de> Um die Anrufliste anzuzeigen, drehen Sie den Steuerungsknopf.
<G-vec00358-001-s070><show.anzeigen><en> Turn the rotary pushbutton to show the call list.
<G-vec00358-001-s071><show.anzeigen><de> Zu einer bestimmten Stelle im Musiktitel wechseln: Drücken Sie, wenn der Bildschirm „Sie hören“ angezeigt wird, auf die Touch-Oberfläche und streichen Sie dann nach unten, um die abgelaufene und verbleibende Zeit anzuzeigen.
<G-vec00358-001-s071><show.anzeigen><en> Move to a specific point in the song. On the Now Playing screen, press the Touch surface, then swipe down to show the elapsed and remaining time.
<G-vec00358-001-s072><show.anzeigen><de> Beispielsweise arbeitet unser Team intensiv daran, die Suchalgorithmen für Entdeckungen zu aktualisieren, um unsere Gastgeber zu unterstützen und Gästen die relevantesten Entdeckungen anzuzeigen.
<G-vec00358-001-s072><show.anzeigen><en> For example, our team is working hard to update experience search algorithms to support our hosts and show the most relevant experiences to guests.
<G-vec00358-001-s073><show.anzeigen><de> Du kannst die Seite filtern, um nur dann Sprechblasen anzuzeigen, wenn sich die Anzahl der Klicks in einem bestimmten Grenzbereich befindet.
<G-vec00358-001-s073><show.anzeigen><en> And you can filter the page, to show only bubbles above your set click threshold.
<G-vec00358-001-s074><show.anzeigen><de> Sie können folgendermaßen vorgehen, um die neue Artikelzeile in Outlook anzuzeigen.
<G-vec00358-001-s074><show.anzeigen><en> You can do as follows to show the new item row in Outlook.
<G-vec00358-001-s075><show.anzeigen><de> Füge den folgenden Link in einem Kommentar, eine Beschreibung oder eine Nachricht ein, um dieses Bild darin anzuzeigen.
<G-vec00358-001-s075><show.anzeigen><en> Hertha Götz Include in a comment, a description or a message to show this image.
<G-vec00060-001-s926><indicate.anzeigen><de> Alle unsere bisherigen Ergebnisse zeigen an, dass sich die Mine Bama für Ressourcenuntersuchungen und eine Bewertung ihres wirtschaftlichen Potenzials eignet.
<G-vec00060-001-s926><indicate.anzeigen><en> All of our results to date indicate that the Bama Mine is a candidate for resource testing and an evaluation of its economic potential.
<G-vec00060-001-s927><indicate.anzeigen><de> Relevante Entdeckungen zeigen auch an, dass es im Bereich die Marinestation von Knossos gab.
<G-vec00060-001-s927><indicate.anzeigen><en> Relevant findings also indicate that in the area there was the naval station of Knossos. Caves & Gorges
<G-vec00060-001-s928><indicate.anzeigen><de> Die Werte Nitrat (NO3) und Nitrit (NO2) zeigen an, ob die biologischen Reinigungsprozesse funktionieren.
<G-vec00060-001-s928><indicate.anzeigen><en> The nitrate (NO3) and nitrite (NO2) values indicate whether the biological cleaning processes are functioning efficiently.
<G-vec00060-001-s929><indicate.anzeigen><de> Gleichzeitig messen die Strohschüttlersensoren (Plattensensoren) den Verlust an den Schüttlern (dem Engpaß des Mähdrescherdurchsatzes) und zeigen an, dass die Strohschüttler überlastet sind – deshalb die Fahrt VERLANGSAMEN.
<G-vec00060-001-s929><indicate.anzeigen><en> For example, the straw walker sensors measure the loss from the straw walkers (the bottleneck of combine throughput) and indicate that the straw walkers canot keep up. In this instance, the operator should slow down.
<G-vec00060-001-s930><indicate.anzeigen><de> Die Farben in diesem Bild der Galaxie J090543.56+043347.3 zeigen an, ob und wie schnell sich das Gas in dem betreffenden Bereich der Galaxie auf uns zu oder von uns weg bewegt.
<G-vec00060-001-s930><indicate.anzeigen><en> Colours in this image of the galaxy J090543.56+043347.3 indicate whether there is gas moving towards us or away from us, and at what speed.
<G-vec00060-001-s931><indicate.anzeigen><de> Beobachtungen zeigen an, dass die Temperaturschwingung etwa 0,05 ° C beträgt und schwer zu erkennen ist.
<G-vec00060-001-s931><indicate.anzeigen><en> Observations indicate that the temperature oscillation is about 0.05 C and it is difficult to detect.
<G-vec00060-001-s932><indicate.anzeigen><de> Studien zeigen an, dass diese Chemikalie möglichen Gebrauch hat, wenn sie verbessert das Lipidprofil bei der Erhöhung von Muskelmass.
<G-vec00060-001-s932><indicate.anzeigen><en> Studies indicate that this chemical has potential use in improving the lipid profile while increasing muscle mass.
<G-vec00060-001-s933><indicate.anzeigen><de> Zählungen die während der letzten zwanzig Jahre gemacht wurden zeigen an, dass die Anzahl sich verringert.
<G-vec00060-001-s933><indicate.anzeigen><en> Counts made over the last twenty years indicate that their number is decreasing .
<G-vec00060-001-s934><indicate.anzeigen><de> Werte Ã1⁄4ber 50 zeigen Wachstum an.
<G-vec00060-001-s934><indicate.anzeigen><en> Any values above 50 indicate growth.
<G-vec00060-001-s935><indicate.anzeigen><de> Drei schwarze konzentrische Scheiben mit drei Indizes in Komplementärfarben zeigen klar die Stunden, Minuten und Sekunden an.
<G-vec00060-001-s935><indicate.anzeigen><en> Three concentric black discs marked with three index in contrasting colors indicate clearly the hours, minutes and seconds.
<G-vec00060-001-s936><indicate.anzeigen><de> Gemeinsam zeigen diese Planeten an, daß diese Beziehung vermutlich einen starken Einfluß auf die Denkweise der beiden Partner ausüben wird.
<G-vec00060-001-s936><indicate.anzeigen><en> These planets together indicate that this relationship is likely to have a strong effect on the way you both think.
<G-vec00060-001-s937><indicate.anzeigen><de> Versand-Benachrichtigungen zeigen an, dass das Paket versandt wurde.
<G-vec00060-001-s937><indicate.anzeigen><en> Ship notifications indicate that the shipment information has been sent to FedEx.
<G-vec00060-001-s938><indicate.anzeigen><de> Kontroll-LEDs zeigen unmittelbar die elektrische Funktionsfähigkeit aller Leiter an.
<G-vec00060-001-s938><indicate.anzeigen><en> Control LEDs immediately indicate the electrical operability of all conductors.
<G-vec00060-001-s939><indicate.anzeigen><de> Frühere Berichte, die von Besuchern der Insel aufgezeichnet wurden, zeigen an, dass den Statuen vom mythischen König Tuu Ku Ihu und dem Gott Make Make befohlen wurde, zu wandern.
<G-vec00060-001-s939><indicate.anzeigen><en> Earlier accounts recorded by visitors to the island indicate that statues were ordered to walk by the mythical King Tuu Ku Ihu and the god Make Make.
<G-vec00060-001-s940><indicate.anzeigen><de> Stoppschilder zeigen an, dass Sie vollständig anhalten müssen, bevor Sie weiterfahren.
<G-vec00060-001-s940><indicate.anzeigen><en> Stop signs indicate that you must come to a complete stop before giving way.
<G-vec00060-001-s941><indicate.anzeigen><de> Buchstaben und Zahlen auf der Außenseite zeigen an, in welcher Position Sie diesem Buchstaben bei der Betrachtung von dieser Seite aus begegnen (z.
<G-vec00060-001-s941><indicate.anzeigen><en> Letters and numbers on the outside indicate at what position you come across this letter when looking from that side (e.g.
<G-vec00060-001-s942><indicate.anzeigen><de> Das Vorhandensein von Anzeichen von Übelkeit, das Erbrechen, die Verdauungsstörung und die Diarrhöe zeigen die erhöhten Effekte auf den Magen an.
<G-vec00060-001-s942><indicate.anzeigen><en> The presence of symptoms of nausea, vomiting, indigestion, and diarrhea indicate the increased effects on the stomach. 12 units and above
<G-vec00060-001-s943><indicate.anzeigen><de> Mit Ihrer Nutzung der Websites zeigen Sie an, dass Sie diese Nutzungsbedingungen akzeptieren und damit einverstanden sind, sich an diese zu halten.
<G-vec00060-001-s943><indicate.anzeigen><en> By using the Websites, you indicate that you accept these terms of use and that you agree to abide by them.
<G-vec00060-001-s944><indicate.anzeigen><de> Verschiedene Größen der Freibeuter-Münzen zeigen den unterschiedlichen Wert des Piraten-Spielgeldes an.
<G-vec00060-001-s944><indicate.anzeigen><en> Different sizes of buccaneer coins indicate the different value of pirate play money.
<G-vec00060-001-s976><indicate.anzeigen><de> Rechts unten zeigt das Programm den maximalen Wert der Stromstärke an.
<G-vec00060-001-s976><indicate.anzeigen><en> The program will indicate the new value of the maximal amperage.
<G-vec00060-001-s977><indicate.anzeigen><de> Viele Fragen werden in jedem Abschnitt gefragt, und der Spieler muss das Jahr ein, diese Ereignisse - wenn der Spieler zeigt an, das genaue Jahr bekommen dann die maximale Punktzahl.
<G-vec00060-001-s977><indicate.anzeigen><en> Many questions will be asked in each section and the player must set the year, these events - if the player will indicate the exact year then get maximum points.
<G-vec00060-001-s978><indicate.anzeigen><de> Der Test zeigt bereits eine hCG (humanes Choriongonadotropin) Konzentration von 12 IU/L an und eignet sich daher für eine Anwendung bereits vor dem Ausbleiben der Periode (etwa zehn Tage nach dem Geschlechtsverkehr).
<G-vec00060-001-s978><indicate.anzeigen><en> The test can already indicate an hCG (human choriongonadotropine) concentration of 12 IU/L and is therefore suitable for use even before the period has stopped (about ten days after sexual intercourse).
<G-vec00060-001-s979><indicate.anzeigen><de> 17.4 Ein Linienrichter zeigt an, ob ein Federball „in“ oder „aus“ ist, bezogen auf die ihm zugewiesene(n) Linie(n).
<G-vec00060-001-s979><indicate.anzeigen><en> 17.4 A line judge shall indicate whether a shuttle landed `in' or `out' on the line(s) assigned.
<G-vec00060-001-s980><indicate.anzeigen><de> Sie zeigt jedoch an, von Wilber selbst, die umkämpfte - im Gegensatz zur einvernehmlichen - Situation der Entwicklungsforschung.
<G-vec00060-001-s980><indicate.anzeigen><en> But it does indicate, from Wilber himself, the embattled – as opposed to the consensual – situation of developmentalism.
<G-vec00060-001-s981><indicate.anzeigen><de> 7 Zeichenfeld 8 TOTAL/REMAIN – Zeigt die momentan angezeigte Disc/Trackinformation an (Seite 14).
<G-vec00060-001-s981><indicate.anzeigen><en> 7 Character display 8 TOTAL/REMAIN – Indicate the disc/track information currently displayed (page 14).
<G-vec00060-001-s982><indicate.anzeigen><de> Die CE Markierung besagt nicht, dass ein Produkt in einem EWR Land hergestellt wurde, sie zeigt lediglich an, dass ein Produkt bewertet wurde, bevor es auf den Markt gebracht wird und somit die Rechtlichen Anforderungen innerhalb d er EU erfüllt.
<G-vec00060-001-s982><indicate.anzeigen><en> CE marking does not indicate that a product was made in the EEA, but merely states that the product is assessed before being placed on the market and thus meets the EU legislative requirements .
<G-vec00060-001-s983><indicate.anzeigen><de> Sollte dies der Fall sein, zeigt Ihnen der Server an, dass nur eine Teilmenge des Ergebnisses zurückgeliefert wurde.
<G-vec00060-001-s983><indicate.anzeigen><en> If this occurs, the server will indicate that it has only returned a partial results set.
<G-vec00060-001-s984><indicate.anzeigen><de> Während es in der Forschung weit verbreitet ist, zeigt dieses Kriterium nicht Empfindlichkeit oder Schwere, wenn es in den ersten drei Tagen nach Anfang verwendet wird an und ist deshalb häufig nicht klinisch nÃ1⁄4tzlich.
<G-vec00060-001-s984><indicate.anzeigen><en> While it is widely used in research, this criterion does not indicate survivability or severity when used in the first three days after onset and is therefore often not clinically useful.
<G-vec00060-001-s985><indicate.anzeigen><de> Halten Sie Ihren GyroTwister einfach an´s Mikrofon und unsere Software zeigt Ihnen die aktuelle Umdrehungszahl, den Kraftindex und natürlich auch den Highscore an.
<G-vec00060-001-s985><indicate.anzeigen><en> Once active, just hold your GyroTwister close to the microphone and our software will indicate the current number of rotations, the strength index and the high score.
<G-vec00060-001-s986><indicate.anzeigen><de> Der Druck auf den ganzen Körper würde einem Druck auf das ganze innere Bewusstsein gleich kommen, vielleicht mit dem Ziel einer Modifikation oder Wandlung, die es für Wissen oder Erfahrung empfänglicher machen würde; die dritte oder vierte Rippe zeigt einen Bereich an, welcher zur vitalen Natur gehört, den Bereich der Lebenskraft – einen Druck zu einer Wandlung dort.
<G-vec00060-001-s986><indicate.anzeigen><en> The pressure on the whole body would mean a pressure on the whole inner consciousness, perhaps for some modification or change which would make it more ready for knowledge or experience; the third or fourth rib would indicate a region which belongs to the vital nature, the domain of the life-force, some pressure for a change there.
<G-vec00060-001-s987><indicate.anzeigen><de> Der Mond als Symbol in der Vision zeigt meist Spiritualität im Mental an oder ganz einfach das spirituelle Bewusstsein.
<G-vec00060-001-s987><indicate.anzeigen><en> It can also indicate the flow of spiritual Ananda (nectar is in the moon according to the old tradition).
<G-vec00060-001-s988><indicate.anzeigen><de> Dieser Test zeigt nur das Vorhandensein von Strep A Antigenen von sowohl lebensfähigen als auch nicht-lebensfähigen Gruppe A Streptococcus-Bakterien in Proben an.
<G-vec00060-001-s988><indicate.anzeigen><en> This test will only indicate the presence of Strep A antigen in the specimen from both viable and non-viable Group A Streptococcus bacteria.
<G-vec00060-001-s989><indicate.anzeigen><de> Der Anzugsmechanismus des Schuhs gibt also zwei Töne aus und ein dritter zeigt an, dass die Batterie schwach ist.
<G-vec00060-001-s989><indicate.anzeigen><en> So the shoe's tightening mechanism emits two tones, and a third to indicate that the battery is low.
<G-vec00060-001-s990><indicate.anzeigen><de> Die Produkte von MSR-Electronic sichern die Kältemittel-Überwachung in geschlossenen Räumen, bei denen Leckagen vorkommen können und zeigt die mögliche erhöhte Gaskonzentration in Echtzeit an.
<G-vec00060-001-s990><indicate.anzeigen><en> The products of MSR-Electronic ensure refrigerant monitoring in closed rooms where leaks can occur and indicate the possible increased gas concentration in real time.
<G-vec00060-001-s991><indicate.anzeigen><de> Die klar ablesbare Digitalanzeige der Kamera zeigt an, ob die Kamera gerade ausgerichtet ist und ermöglicht die Feinanpassung der horizontalen Ausrichtung während der Aufnahme.
<G-vec00060-001-s991><indicate.anzeigen><en> The camera's digital level gauge uses easy-to-read graphics to indicate clearly whether the camera is level and enables fine adjustment of horizontal alignment during shooting.
<G-vec00060-001-s992><indicate.anzeigen><de> Zeigt bei stromführenden Kabeln die tatsächliche Spannung an.
<G-vec00060-001-s992><indicate.anzeigen><en> On energized wires, the meter will indicate the real voltage.
<G-vec00060-001-s993><indicate.anzeigen><de> Gebrauch von dieser Web site zeigt an, dass Sie damit einverstanden sind, durch die Ausdrücke gesprungen zu werden.
<G-vec00060-001-s993><indicate.anzeigen><en> Use of this Website will indicate that you agree to be bound by the Terms.
<G-vec00060-001-s994><indicate.anzeigen><de> Daher zeigt der anfängliche Temperaturanstieg nicht an, dass das Antibiotikum nicht geeignet ist.
<G-vec00060-001-s994><indicate.anzeigen><en> Therefore, the initial increase in temperature does not indicate that the antibiotic is not suitable.
<G-vec00230-002-s031><denounce.anzeigen><de> Ein Unternehmen, das ein Kartell, an dem es beteiligt ist, anzeigen möchte, kann den vollständigen Erlass der Geldbuße beantragen, wenn es als erstes Unternehmen Beweise für ein der Europäischen Kommission bis dahin unbekanntes Kartell vorlegt oder - falls die Kommission bereits von dem Kartell wusste - ihr als erstes Unternehmen entscheidende Beweise vorlegt, die die Feststellung des Kartells ermöglichen.
<G-vec00230-002-s031><denounce.anzeigen><en> A firm participating in a cartel which it wishes to denounce may request total immunity from fines if it is the first firm to provide evidence of a cartel hitherto unknown to the European Commission or, if the Commission is aware of the cartel, if the firm is the first to provide it with crucial information enabling it to establish its existence.
<G-vec00230-002-s032><denounce.anzeigen><de> Der springenden Punkt ist, dass selbst im Anzeigen des Falschen, im Bekämpfen des Bösen und in der Trauer über die Tragödien, wir gleichzeitig die negative Seite dieser Welt auf eine andere, wesentlichere Ebene erheben, indem wir ihren positiven Kern zurückgewinnen.
<G-vec00230-002-s032><denounce.anzeigen><en> The point is that even as we denounce falsehood, fight evil and mourn tragedy, we simultaneously engage the negativity in our world on another, more inner plane: by reclaiming its positive core. When we are faced with a lie we renounce it.
<G-vec00245-002-s076><appear.anzeigen><de> * Apps wie iTunes und das Festplattendienstprogramm können auch dann weiterhin auf den Datenträger zugreifen, wenn dieser nicht auf dem Schreibtisch oder im Finder angezeigt wird.
<G-vec00245-002-s076><appear.anzeigen><en> * Apps such as iTunes and Disk Utility can still access the disc, even if it doesn't appear on the desktop or in the Finder.
<G-vec00245-002-s077><appear.anzeigen><de> Warte, bis der Name deines Geräts angezeigt wird.
<G-vec00245-002-s077><appear.anzeigen><en> Wait for your device's name to appear.
<G-vec00245-002-s078><appear.anzeigen><de> Wenn das Symbol nicht in der Menüleiste angezeigt wird, öffnen Sie die Systemeinstellungen im Menü Apple.
<G-vec00245-002-s078><appear.anzeigen><en> If the icon does not appear in the menu bar at all, then choose System Preferences from the Apple menu.
<G-vec00245-002-s079><appear.anzeigen><de> Da in PSE die Miniatur der Filtermaske im Ebenen-Bedienfeld nicht angezeigt wird, ist es nicht einfach zu erkennen, welche Bereiche maskiert sind und welche nicht.
<G-vec00245-002-s079><appear.anzeigen><en> Since, in PSE, filter mask thumbnails don't appear in the Layers palette, we may not know which exactly parts are already masked and which are not.
<G-vec00245-002-s080><appear.anzeigen><de> Wenn es sich bei diesem Reiseziel um Ihre Stadt oder Region handelt, ist es wichtig, dass Ihre Unterkunft in den Suchergebnissen angezeigt wird.
<G-vec00245-002-s080><appear.anzeigen><en> When that destination is your city or region, you’re going to want to make sure you appear in their search results.
<G-vec00245-002-s081><appear.anzeigen><de> Hinweis: Wenn Autorun deaktiviert ist und das Roxio Retrieve-Fenster nicht angezeigt wird, können Sie Roxio Retrieve manuell starten, indem Sie auf die Datei Launch_Retrieve.exe auf der Disc doppelklicken.
<G-vec00245-002-s081><appear.anzeigen><en> Note: If Auto-run is disabled and the Roxio Retrieve window does not appear, you can manually start Roxio Retrieve by double-clicking the Launch_Retrieve.exe file included on the disc.
<G-vec00245-002-s082><appear.anzeigen><de> Das könnte dazu führen, dass die Datei als allgemeines Icon angezeigt wird, wenn sie innerhalb eines Ordners über WebDAV-Freigabe betrachtet wird, und nicht mit einer bestimmten Anwendung verknüpft wird.
<G-vec00245-002-s082><appear.anzeigen><en> This might cause the file to appear as a generic icon when viewed within a WebDAV shared folder, not having an association with any application.
<G-vec00245-002-s083><appear.anzeigen><de> Wir können Cookies ablegen, wenn Sie unsere Website oder die eines anderen Unternehmens besuchen, auf der unsere Werbung angezeigt wird, oder wenn Sie Einkäufe tätigen, Informationen anfordern oder personalisieren oder sich für bestimmte Dienstleistungen anmelden.
<G-vec00245-002-s083><appear.anzeigen><en> We may send cookies when you visit our website or websites where our ads appear or when you make purchases, request or personalize information, or register for certain services.
<G-vec00245-002-s084><appear.anzeigen><de> Sie müssen Windows PowerShell jedoch einmal starten, damit die Aufgabe Alle Module importieren angezeigt wird.
<G-vec00245-002-s084><appear.anzeigen><en> However, you must start Windows PowerShell one time to make the Import all modules task appear.
<G-vec00245-002-s085><appear.anzeigen><de> Als nächstes werden Sie die Möglichkeit haben, eine Startzeit für das Wasserzeichen zu wählen, so dass es erst am Ende des Videos angezeigt wird, oder Sie es für die gesamte Länge des Videos anzeigen wollen.
<G-vec00245-002-s085><appear.anzeigen><en> Next, you will have the option of choosing a start time for your watermark, making it appear only at the end of your video, or having it there for the entire length of your video.
<G-vec00245-002-s086><appear.anzeigen><de> Für ein vollständiges Dell Cinema Erlebnis: Aktualisieren Sie Ihren Bildschirm und erleben Sie Bilder, bei denen jedes Bit so lebendig angezeigt wird wie die Welt um uns herum.
<G-vec00245-002-s086><appear.anzeigen><en> Get the full Dell Cinema experience: Upgrade your screen to experience visuals that appear every bit as vibrant as the world around you.
<G-vec00245-002-s087><appear.anzeigen><de> Wenn das Programm nicht angezeigt wird, verwenden Sie die unter Bei erstmaliger Verwendung aufgeführten Links in der E-Mail-Einladung, um den Live Meeting-Client zu installieren.
<G-vec00245-002-s087><appear.anzeigen><en> If the program does not appear, use the links listed under First-Time Users in the e-mail invitation to install the meeting client.
<G-vec00245-002-s088><appear.anzeigen><de> Wenn das folgende Pop-up angezeigt wird, wählen Sie die Sicherung aus und klicken Sie auf die Schaltfläche "Wiederherstellen", um Kontakte auf Ihr Gerät abzurufen.
<G-vec00245-002-s088><appear.anzeigen><en> As the following pop-up would appear, select the backup and click on the “Restore” button to retrieve contacts to your device.
<G-vec00245-002-s089><appear.anzeigen><de> Mit dem Rollover-Bereich legen Sie die Position des Mauszeigers fest, bei der die Beschriftung oder das Bild angezeigt wird.
<G-vec00245-002-s089><appear.anzeigen><en> The rollover area defines where the mouse must be for the caption or image to appear.
<G-vec00245-002-s090><appear.anzeigen><de> Versuchen Sie, falls Ihr Drucker noch immer nicht angezeigt wird, ihn unter Verwendung seiner IP-Adresse hinzuzufügen (siehe unten).
<G-vec00245-002-s090><appear.anzeigen><en> If your printer still doesn’t appear in the list, try adding the printer by its IP address (see below).
<G-vec00245-002-s091><appear.anzeigen><de> Damit das Menü angezeigt wird, müssen Sie unter Umständen einmal irgendwo auf den Bildschirm tippen.
<G-vec00245-002-s091><appear.anzeigen><en> You might need to tap once anywhere on the screen for the menu to appear.
<G-vec00245-002-s092><appear.anzeigen><de> Wenn das Symbol Dialog nicht angezeigt wird, drücken Sie während der Wiedergabe Ihres Titels auf den Pfeil nach unten, um das Audio- und Untertitel-Menü zu öffnen.
<G-vec00245-002-s092><appear.anzeigen><en> If the Dialog icon does not appear, press the Down arrow while your TV show or movie is playing to open the audio and subtitle menu.
<G-vec00245-002-s093><appear.anzeigen><de> Wenn die NETGEAR-Website nicht innerhalb einer Minute angezeigt wird, lesen Sie Kapitel 2, Fehlerbehebung.
<G-vec00245-002-s093><appear.anzeigen><en> If the NETGEAR Web site does not appear within one minute, refer to Chapter 2, Troubleshooting.
<G-vec00245-002-s094><appear.anzeigen><de> Wenn der gewünschte Name nicht in der Liste Aktuellste Empfänger angezeigt wird, geben Sie den Namen oder den E-Mail-Alias in das Feld An, Optional oder Ressourcen ein.
<G-vec00245-002-s094><appear.anzeigen><en> If the name you want doesn't appear in the Most Recent Recipients list, type the name or email alias in the To, Optional, or Resources box.
<G-vec00276-002-s283><advertise.anzeigen><de> Pipol A/S nutzt Retargeting-Dienste, um Ihnen auf Webseiten Dritter Werbung anzuzeigen, nachdem Sie unseren Service besucht haben.
<G-vec00276-002-s283><advertise.anzeigen><en> Hallmark Properties uses remarketing services to advertise on third party websites to you after you visited our Service.
<G-vec00276-002-s284><advertise.anzeigen><de> Wir verwenden Adroll, um auf unserer Website und den Seiten Dritter, die von Nutzern besucht werden, die sich zuvor auf unserer Website aufgehalten haben, Werbung anzuzeigen.
<G-vec00276-002-s284><advertise.anzeigen><en> We use Adroll to advertise on our site and third party websites to previous visitors of our site.
<G-vec00276-002-s285><advertise.anzeigen><de> Zuhause Design, LLC setzt Wiedervermarktungsdienste ein, um Ihnen auf Websites Dritter Werbung anzuzeigen, nachdem Sie unseren Dienst besucht haben.
<G-vec00276-002-s285><advertise.anzeigen><en> Behavioral Remarketing PostNet-Champions TX121 uses remarketing services to advertise on third party websites to you after you visited our Service.
<G-vec00310-002-s095><view.anzeigen><de> Drücken Sie den Namen einer der Kategorien um Hintergrundbilder anzuzeigen.
<G-vec00310-002-s095><view.anzeigen><en> Press one of the categories to view wallpapers.
<G-vec00310-002-s096><view.anzeigen><de> Das Glossar ermöglicht es Ihnen, Glossareinträge zu suchen, anzuzeigen, zu erzeugen, zu editieren, zu löschen und zu veröffentlichen.
<G-vec00310-002-s096><view.anzeigen><en> The Dictionary allows you to search, view, create, edit, delete, and publish dictionary entries.
<G-vec00310-002-s097><view.anzeigen><de> Zu Wiederherstellen verlorener Dateien auf dem iPhone nach iOS 11 Update, dann können Sie zum linken Panel gehen und auf jede Kategorie klicken, um die Elemente einzeln anzuzeigen.
<G-vec00310-002-s097><view.anzeigen><en> To recover lost files on iPhone after iOS 11 update, then you can go to the left panel and click on each category to view the items one by one.
<G-vec00310-002-s098><view.anzeigen><de> Von hier, öffne deine Konsole und scroll über das Bild-Style-Tag, um die Pixel-Abmessungen deines Bildes anzuzeigen.
<G-vec00310-002-s098><view.anzeigen><en> From there, open up your console, and scroll over the img style tag to view the pixel dimensions of your artwork.
<G-vec00310-002-s099><view.anzeigen><de> Hinweis: Wenn sich eine Hülle aus gruppierten Pfaden zusammensetzt, klicken Sie im Ebenenbedienfeld links neben dem Eintrag „<Hülle>“ auf das Dreieck, um den zu bearbeitenden Pfad anzuzeigen und als Ziel auszuwählen.
<G-vec00310-002-s099><view.anzeigen><en> note: If your envelope consists of grouped paths, click the triangle to the left of the <Envelope> entry in the Layers panel to view and target the path you want to edit. Edit it as desired. Märkus.
<G-vec00310-002-s100><view.anzeigen><de> iMyFone iTransor Lite kann Ihnen helfen, Daten aus allen Backups in Ihrem iCloud-Konto ohne Probleme herunterzuladen und anzuzeigen.
<G-vec00310-002-s100><view.anzeigen><en> iMyFone iTransor Lite can help you download and view data from all backups in your iCloud account without any hassle.
<G-vec00310-002-s101><view.anzeigen><de> Wählen Sie Ihr Modelljahr aus den Optionen unten aus, um Ersatzteile und Anleitungen anzuzeigen.
<G-vec00310-002-s101><view.anzeigen><en> Select your model year from the options below to view parts & manuals.
<G-vec00310-002-s102><view.anzeigen><de> Sie können auf den Briefumschlag klicken, um eine Vorschau der neuesten Nachricht anzuzeigen, oder auf den Kalender, um Kalender- und Aufgabenerinnerungen anzuzeigen und zu verwalten.
<G-vec00310-002-s102><view.anzeigen><en> You can click the envelope to see a preview of the latest new message, or the calendar to view and manage calendar and task reminders.
<G-vec00310-002-s103><view.anzeigen><de> Wählen Sie dann den BIC-Code, es ist voller Details anzuzeigen.
<G-vec00310-002-s103><view.anzeigen><en> Then select the BIC code to view it's full details.
<G-vec00310-002-s104><view.anzeigen><de> Um die Karte anzuzeigen aktivieren Sie bitte JavaScript in Ihren Browser-Einstellungen.
<G-vec00310-002-s104><view.anzeigen><en> To use standard view, enable JavaScript by changing your browser options.
<G-vec00310-002-s105><view.anzeigen><de> Um Google Maps anzuzeigen, aktivieren Sie JavaScript in den Einstellungen Ihres Webbrowsers und versuchen Sie es erneut.
<G-vec00310-002-s105><view.anzeigen><en> To view Google Maps, enable JavaScript by changing your browser options, and then try Sipenmaru
<G-vec00310-002-s106><view.anzeigen><de> Um diese Seite anzuzeigen, benötigen Sie einen Browser, der Frames anzeigen kann.
<G-vec00310-002-s106><view.anzeigen><en> Oops! This document requires a browser that can view frames.
<G-vec00310-002-s107><view.anzeigen><de> Klicken Sie auf ein Bild, um es größer anzuzeigen.
<G-vec00310-002-s107><view.anzeigen><en> Click on any picture to view it larger.
<G-vec00310-002-s108><view.anzeigen><de> Es gibt drei Möglichkeiten, mit diesem Tool Ihre iMessages auf Ihrem Windows-PC anzuzeigen.
<G-vec00310-002-s108><view.anzeigen><en> There are three ways to use this tool to view your iMessages on your Windows PC.
<G-vec00310-002-s109><view.anzeigen><de> Klicken Sie unten, um unseren neuesten Katalog anzuzeigen.
<G-vec00310-002-s109><view.anzeigen><en> Click below to view our latest catalog.
<G-vec00310-002-s110><view.anzeigen><de> Klicken Sie auf die Hotspot-Einstellungen, um das Passwort anzuzeigen, das für den Zugriff auf den Wi-Fi-Hotspot im Fahrzeug erforderlich ist.
<G-vec00310-002-s110><view.anzeigen><en> Click on Hotspot settings to view the password required for accessing the in-car Wi-Fi Hotspot. Find out more
<G-vec00310-002-s111><view.anzeigen><de> Dies ist die extra-lite Version von Facebook, die Sie über den mobilen Browser laden können, und obwohl sie im Allgemeinen für leistungsschwache Telefone und Personen mit schlechten Mobilfunkverbindungen gedacht ist, ist sie auch der einzige Ort, an dem Sie nicht gezwungen werden, Facebook Messenger herunterzuladen, um Ihren Posteingang anzuzeigen oder auf Nachrichten zu antworten.
<G-vec00310-002-s111><view.anzeigen><en> This is the extra-lite version of Facebook that you can load through the mobile browser, and while generally intended for low-powered phones and people running on bad cell connections, it’s also the one place left that you won’t be forced into downloading Facebook Messenger in order to view your inbox or respond to any messages.
<G-vec00310-002-s112><view.anzeigen><de> Klicken Sie auf ein Druckermodell, um die Funktionen anzuzeigen, die von diesem Modell unterstützt werden.
<G-vec00310-002-s112><view.anzeigen><en> Click on a printer model to view the features that are supported by that model
<G-vec00310-002-s113><view.anzeigen><de> Bitte Javascript aktivieren, um die Händler deiner Region anzuzeigen, die Vorbestellungen anbieten.
<G-vec00310-002-s113><view.anzeigen><en> Please enable JavaScript to view the retailers accepting pre-orders in your region.
<G-vec00330-002-s032><reveal.anzeigen><de> Tippen Sie einfach auf die Schaltfläche "Gang" in der unteren rechten Ecke, um die Einstellungen anzuzeigen, und gehen Sie dann zu den Bildeinstellungen> Bild & Video> Wasserzeichen.
<G-vec00330-002-s032><reveal.anzeigen><en> Just tap the "gear” button in the lower right corner to reveal settings, and then go to Image Preferences > Image & Video > Watermarks.
<G-vec00330-002-s033><reveal.anzeigen><de> Klicken Sie auf die Dreiecke links neben den mitgelieferten Programmen, um die Wahlmöglichkeiten anzuzeigen.
<G-vec00330-002-s033><reveal.anzeigen><en> Click the disclosure triangle to the left of Bundled Applications to reveal the choices.
<G-vec00330-002-s034><reveal.anzeigen><de> Das Dashboard seiner Business-Intelligence-Lösung Power BI erweitert Microsoft um die Möglichkeiten, Trends und Angriffsmuster anzuzeigen sowie Empfehlungen und Sicherheitsalarme von überall zu filtern und zu visualisieren, Mobilgeräte eingeschlossen.
<G-vec00330-002-s034><reveal.anzeigen><en> Microsoft is adding the ability to use Power BI dashboard to reveal trends and attack patterns, as well as visualize and filter recommendations and security alerts from anywhere, including a mobile device.
<G-vec00330-002-s035><reveal.anzeigen><de> Der Spieler wählt eine Karte, um einen Topf in Bronze, Silber oder Gold anzuzeigen.
<G-vec00330-002-s035><reveal.anzeigen><en> The player selects a card to reveal a bronze, silver or gold pot.
<G-vec00330-002-s036><reveal.anzeigen><de> Um die in einer schmalen Bedienfeldgruppe ausgeblendeten Bedienfelder anzuzeigen, ziehen Sie die Bildlaufleiste über der Bedienfeldgruppe.
<G-vec00330-002-s036><reveal.anzeigen><en> To reveal panels hidden in a narrow panel group, drag the scroll bar above the panel group.
<G-vec00330-002-s037><reveal.anzeigen><de> Sie können einen Ordner öffnen, um seinen Inhalt anzuzeigen, und einen Ordner in einen anderen Ordner verschieben.
<G-vec00330-002-s037><reveal.anzeigen><en> You can expand a folder to reveal its contents, and put folders inside other folders.
<G-vec00330-002-s038><reveal.anzeigen><de> Sie können auch den Befehl Im Browser zeigen des [Rechts-Klick](PC) / [CTRL-Klick](Mac) Kontextmen√ľs verwenden, um die Sample-Datei im Browser anzuzeigen.
<G-vec00330-002-s038><reveal.anzeigen><en> You can also use the Show in Browser command in the right-click(PC) / CTRL-click(Mac) context menu to reveal the file in the browser.
<G-vec00330-002-s039><reveal.anzeigen><de> Achte auf: 3 + Scatters für den Freispiel-Modus, drehe das Rad um deine Spins anzuzeigen, erhalte zufällige Multiplikatoren bei jedem Spin und 2 weitere Scatters für Pyramid-Spins.
<G-vec00330-002-s039><reveal.anzeigen><en> In this game: 3+ scatters for the free spin mode, spin a wheel to reveal how many spins, during these a random multiplier is added on each spin & land 2 more scatters for Pyramid Spins.
<G-vec00330-002-s040><reveal.anzeigen><de> Wenn eine Marionette als Ebene hinzugefügt wird, können Sie die Ebene öffnen, um die Ebenen der hinzugefügten Marionette anzuzeigen, und die Ebenen der Marionette im Kontext der aktuellen Marionette ändern.
<G-vec00330-002-s040><reveal.anzeigen><en> When a puppet is added as a layer, you can twirl the layer open to reveal the layers inside that added puppet, and modify that puppet’s layers within the context of the current puppet.
<G-vec00330-002-s041><reveal.anzeigen><de> Klicken Sie auf den Pfeil neben dem Skalierungs-Steuerelement im Bewegungseffekt, um den Skalierungsregler anzuzeigen.
<G-vec00330-002-s041><reveal.anzeigen><en> Click the arrow next to the Scale control within the Motion effect to reveal the Scale slider.
<G-vec00330-002-s042><reveal.anzeigen><de> Dann alle übrigen Spieler beginnen, sich die Hände anzuzeigen.
<G-vec00330-002-s042><reveal.anzeigen><en> Then, all the remaining players begin to reveal their hands.
<G-vec00332-002-s019><notify.anzeigen><de> Hinweis: Sie können auch über das Preflight-Bedienfeld Meldungen zu veralteten und ungelösten Querverweisen anzeigen.
<G-vec00332-002-s019><notify.anzeigen><en> Poznámka: You can also use the Preflight panel to notify you when cross-references are out of date or unresolved.
<G-vec00332-002-s020><notify.anzeigen><de> Den deutschen Bestimmungen zufolge müssen Hersteller und Importeure pyrotechnische Gegenstände, die mit der CE-Kennzeichnung versehen sind, zusammen mit den dazugehörigen Gebrauchsanweisungen der Bundesanstalt für Materialprüfung (BAM) anzeigen, bevor sie diese in Deutschland in Verkehr bringen dürfen.
<G-vec00332-002-s020><notify.anzeigen><en> German legislation requires that manufacturers and importers notify CE marked pyrotechnic articles, together with their instructions for use, to the Federal Institute for Material Research and Testing (BAM), before their placing on the German market.
<G-vec00332-002-s021><notify.anzeigen><de> Wir können dem Schuldner die Abtretung anzeigen und/oder vom Käufer den Vermerk der Abtretung in seinen Büchern verlangen.
<G-vec00332-002-s021><notify.anzeigen><en> We have the right to notify the debtor of the assignment and/or to ask the buyer to record the assignment on his books.
<G-vec00332-002-s022><notify.anzeigen><de> (7) Falls die Ware aus einem der in Absatz 6 genannten Gründe nicht oder nicht rechtzeitig lieferbar ist, werden wir dies dem Kunden unverzüglich anzeigen.
<G-vec00332-002-s022><notify.anzeigen><en> (3) Should the goods not be deliverable or not be deliverable on time, we will immediately notify the Customer of such.
<G-vec00332-002-s023><notify.anzeigen><de> (5) Unternehmer müssen dem Verkäufer offensichtliche Mängel der gelieferten Ware innerhalb einer Frist von 2 Wochen ab Empfang der Ware anzeigen; andernfalls ist die Geltendmachung des Gewährleistungsanspruchs ausgeschlossen.
<G-vec00332-002-s023><notify.anzeigen><en> (5) Entrepreneurs must notify the seller of obvious defects concerning the delivered goods within a period of 2 weeks following receipt of the goods, otherwise the assertion of warranty claims is excluded.
<G-vec00332-002-s024><notify.anzeigen><de> Damit sie die Schutzrechte nach dem Mutterschutzgesetz in Anspruch nehmen können und die Universität entsprechende Schutzmaßnahmen ergreifen kann, sollen Studentinnen eine Schwangerschaft so früh wie möglich gegenüber der Universität anzeigen.
<G-vec00332-002-s024><notify.anzeigen><en> Students should notify the University of a pregnancy as soon as possible to ensure they enjoy their full protection rights pursuant to MuSchG and that the University can implement the necessary protection measures.
<G-vec00332-002-s025><notify.anzeigen><de> 12.2 Entdeckt der AG bei den vorgenannten Prüfungen einen Mangel, wird er diesen dem AN anzeigen.
<G-vec00332-002-s025><notify.anzeigen><en> 12.2 If the Customer detects any defect when carrying out the above inspections, it shall notify the Contractor of such.
<G-vec00332-002-s026><notify.anzeigen><de> (4) Der Besteller muss offensichtliche Mängel – soweit er kein Verbraucher ist – sofort, spätestens jedoch innerhalb einer Frist von 7 Tagen nach Empfang der Lieferware, schriftlich anzeigen.
<G-vec00332-002-s026><notify.anzeigen><en> (4) The customer shall notify us in writing of any apparent defect – if he is not a consumer – immediately, at the latest within 7 days after receipt of the delivery.
<G-vec00332-002-s027><notify.anzeigen><de> 19.2 Sie unterliegen den gültigen und auf unserer Webseite zum Zeitpunkt Ihrer Bestellung bei uns eingestellten Richtlinien und Allgemeinen Geschäftsbedingungen, soweit eine Änderung dieser Richtlinien oder Allgemeinen Geschäftsbedingungen nicht gesetzlich oder behördlich vorgeschrieben wird (in welchem Falle diese auch auf vorher von Ihnen getätigte Bestellungen angewandt werden wird), oder soweit wir Ihnen die Änderung der entsprechenden Richtlinen oder dieser Allgemeinen Geschäftsbedingungen anzeigen, bevor wir Ihnen die Lieferbestätigung schicken (in welchem Fall wir berechtigt sind, davon auszugehen, dass Sie der Änderung der Allgemeinen Geschäftsbedingungen zugestimmt haben, wenn Sie diesen nicht innerhalb von sieben Werktagen nach Erhalt des Waren von uns ausdrücklich widersprechen).
<G-vec00332-002-s027><notify.anzeigen><en> 21.2 You will be subject to the policies and terms and conditions in force at the time that you order products from us, unless any change to those policies or these terms and conditions is required to be made by law or governmental authority (in which case it will apply to orders previously placed by you), or if we notify you of the change to those policies or these terms and conditions before we send you the Acceptance Confirmation (in which case we have the right to assume that you have accepted the change to the terms and conditions, unless you notify us to the contrary within seven working days of receipt by you of the Products).
<G-vec00332-002-s028><notify.anzeigen><de> Derartige Verzögerungen wird die SOLO Lighting GmbH dem Käufer unverzüglich anzeigen.
<G-vec00332-002-s028><notify.anzeigen><en> SOLO Lighting GmbH will notify the buyer immediately of any such delays.
<G-vec00332-002-s029><notify.anzeigen><de> ORdigiNAL wird dem Auftraggeber die Fertigstellung der Leistungen anzeigen (“Fertigstellungsanzeige”).
<G-vec00332-002-s029><notify.anzeigen><en> ORdigiNAL shall notify Company upon completion of the Services (“Notification of Completion”).
<G-vec00332-002-s031><notify.anzeigen><de> Offene Mängel werden wir dem Lieferanten unverzüglich schriftlich, spätestens jedoch innerhalb von 10 Werktagen nach Eingang der Lieferung bei uns anzeigen.
<G-vec00332-002-s031><notify.anzeigen><en> We shall notify the supplier of obvious defects immediately in writing, but no later than within 10 working days of receipt of the delivery by us.
<G-vec00332-002-s032><notify.anzeigen><de> Sollte ein Ticketkäufer mit der Bezahlung des/der gekauften Tickets in Rückstand geraten oder eine für den Kauf getätigte Überweisung zurückrufen, so wird Silverdust uns die Zahlungsforderung gegen den jeweiligen Ticketkäufer abtreten und die Abtretung gegenüber dem Ticketkäufer anzeigen.
<G-vec00332-002-s032><notify.anzeigen><en> If a ticket buyer falls into arrears regarding the payment of the ticket(s) concerned, or cancels a bank transfer for payment of the ticket(s), Silverdust shall assign to us the payment claim against the ticket buyer and notify that ticket buyer that such assignment has taken place.
<G-vec00337-002-s026><prompt.anzeigen><de> Es wird ein neues Fenster angezeigt, in dem Sie einen Namen und ein Passwort eingeben müssen.
<G-vec00337-002-s026><prompt.anzeigen><en> A new window will prompt for a Name and Password.
<G-vec00337-002-s027><prompt.anzeigen><de> Falls sich der Preis eines Fahrzeuges während des Parkens ändert, wird dies direkt angezeigt.
<G-vec00337-002-s027><prompt.anzeigen><en> The system will instantly prompt whenever the price of the 'earmarked' machine changes.
<G-vec00337-002-s028><prompt.anzeigen><de> Hier sollte eine Beschreibung angezeigt werden, diese Seite lässt dies jedoch nicht zu.
<G-vec00337-002-s028><prompt.anzeigen><en> Page Prompt message Page Prompt message: 404: This page does not exist!
<G-vec00337-002-s029><prompt.anzeigen><de> Wenn Sie darauf klicken, wird ein Menü mit den optionalen Nodes angezeigt.
<G-vec00337-002-s029><prompt.anzeigen><en> Clicking the prompt displays a menu of the optional nodes.
<G-vec00337-002-s030><prompt.anzeigen><de> Es wird dann der folgende Anmeldebildschirm angezeigt: Bild 6: Anmeldebildschirm der iRMC S2/S3-Web-Oberfläche I Falls der Anmeldebildschirm nicht angezeigt wird, überprüfen Sie die LAN-Verbindung (siehe Abschnitt "LAN-Schnittstelle testen" auf Seite 49).
<G-vec00337-002-s030><prompt.anzeigen><en> The following login prompt appears: Figure 6: Login prompt for the iRMC S2/S3 web interface I If the login prompt does not appear, check the LAN connection (see section "Testing the LAN interface" on page 47).
<G-vec00337-002-s031><prompt.anzeigen><de> Wenn du eine neue Liste erstellst oder eine bestehende lädst, dann wird ein Bestätigungsdialog angezeigt, um die aktuelle Liste zu speichern.
<G-vec00337-002-s031><prompt.anzeigen><en> If you create a new list or load an existing one, you will see a confirmation prompt to save your current list.
<G-vec00347-002-s019><sue.anzeigen><de> Ihre Familie wies darauf hin, dass sie die Polizeibehörde und die Staatsanwaltschaft anzeigen würde.
<G-vec00347-002-s019><sue.anzeigen><en> Ms. Wang's family members indicated that they would sue the police station and the prosecutor's office.
<G-vec00347-002-s020><sue.anzeigen><de> Sollte ich ihn nicht anzeigen?“ Er erklärte den Polizisten und dem Sicherheitschef die wahren Umstände der Verfolgung und dass sie rechtswidrig sei.
<G-vec00347-002-s020><sue.anzeigen><en> Shouldn't I sue him?” He went on to tell the police and the security chief the facts behind the persecution and how it was illegal.
<G-vec00354-002-s058><show.anzeigen><de> Klicke in der Buchungsbestätigungs-E-Mail auf den Link "Reservierung stornieren", um deine Online-Reservierung anzuzeigen.
<G-vec00354-002-s058><show.anzeigen><en> In the booking confirmation email, click on the "Cancel reservation" link that will show you your online reservation.
<G-vec00354-002-s059><show.anzeigen><de> Dank dieser Anwendung ist es auch möglich, Bilder oder Videos auf dem Tablet anzuzeigen, Sounds auf dem Roboter abzuspielen oder eine Vorschau dessen zu sehen, was der Roboter durch seine Kamera sieht.
<G-vec00354-002-s059><show.anzeigen><en> It is also possible, thanks to this application, to show images or videos on the tablet, to play sounds on the robot, or to have a glimpse of what the robot perceives through its camera.
<G-vec00354-002-s060><show.anzeigen><de> Drücke den Knopf am Anfang des Korridors (einmal) um die richtige Richtung anzuzeigen (>).
<G-vec00354-002-s060><show.anzeigen><en> Push the button in the beginning of the corridor once to make it show the right direction (>).
<G-vec00354-002-s061><show.anzeigen><de> Als nächstes werde ich dann versuchen, solch eine Landschaft auf dem iPod touch anzuzeigen.
<G-vec00354-002-s061><show.anzeigen><en> Next, I’ll try to get such a landscape to show up on my iPod touch.
<G-vec00354-002-s062><show.anzeigen><de> Um unseren Standort anzuzeigen und eine Anfahrtsbeschreibung zu erstellen, werden Ihre Nutzereinstellungen und -daten verarbeitet.
<G-vec00354-002-s062><show.anzeigen><en> To show our location and enable directions to be calculated, your user settings and data are processed.
<G-vec00354-002-s063><show.anzeigen><de> Der AM Part Identifier analysiert dann die Metadaten jedes Bauteils, um Ihnen automatisch die Top-Business Cases für die additive Fertigung anzuzeigen.
<G-vec00354-002-s063><show.anzeigen><en> The AM Part Identifier will then analyze every part’s metadata to show you the top business cases for additive manufacturing automatically.
<G-vec00354-002-s064><show.anzeigen><de> Es aktiviert nicht das Theme, sondern ermöglicht, es im Menü der Website unter Design anzuzeigen.
<G-vec00354-002-s064><show.anzeigen><en> It does not activate the theme, but allows it to show in the site’s Appearance menu.
<G-vec00354-002-s065><show.anzeigen><de> Um nur die für ein bestimmtes Produkt gewählten Farben anzuzeigen, sollte auf dieses Produkt gefiltert werden oder "Produkte" als Dimension hinzugefügt werden.
<G-vec00354-002-s065><show.anzeigen><en> To only show colors for a specific product, you should filter on this product or alternatively add the dimension "products".
<G-vec00354-002-s066><show.anzeigen><de> Nicht autorisierte Kanäle anzeigen: Wählen Sie diese Option, um die Kanäle anzuzeigen, für die der Benutzer keine Überwachungsrechte besitzt.
<G-vec00354-002-s066><show.anzeigen><en> Display unauthorized channels: Select this option to show the channels that the user does not have the right to monitor.
<G-vec00354-002-s067><show.anzeigen><de> Setzen Sie diese Eigenschaft auf true, um importierte Elemente in der XBRL-Dokumentation anzuzeigen.
<G-vec00354-002-s067><show.anzeigen><en> Set this property to true, to show imported elements in the XBRL documentation.
<G-vec00354-002-s068><show.anzeigen><de> Die Layouts können geändert werden, um Tag, Woche oder Monat anzuzeigen.
<G-vec00354-002-s068><show.anzeigen><en> Views can also be changed to show the day, week, or month.
<G-vec00354-002-s069><show.anzeigen><de> Das Tracking zur Optimierung der Anzeige von Werbung hat den Zweck, den Nutzern auf ihre Interessen zugeschnittene Werbung anzuzeigen, den Erfolg der Werbung und dadurch auch die Werbeerlöse zu erhöhen.
<G-vec00354-002-s069><show.anzeigen><en> The purpose of tracking to optimize the display of advertising is to show users advertising tailored to their interests, to increase the success of advertising and thus also advertising revenues.
<G-vec00354-002-s070><show.anzeigen><de> Hinweis: Das Layout „Reduzierbare Spalten“ ist zwar für Mobilgeräte optimiert, funktioniert aber auch auf Desktops, wenn nicht genug Platz verfügbar ist, um alle Spalten in einer Tabelle anzuzeigen.
<G-vec00354-002-s070><show.anzeigen><en> Note: While Collapsible column layout is optimized for mobile devices, it will work on desktop as well, if the width available is not enough to show all the columns in a table.
<G-vec00354-002-s071><show.anzeigen><de> Kategorien und Statusmeldungen erscheinen in einer Liste zusammen mit der Möglichkeit, den Status anzuzeigen und zu versenden.
<G-vec00354-002-s071><show.anzeigen><en> Categories and statutes are shown in a list with two options Show and Send the status.
<G-vec00354-002-s072><show.anzeigen><de> NetSpot ist ein vielseitiges Tool für WLAN-Standortgutachten, WLAN-Analyse und Fehlerbehebung für macOS und Windows, das auch zur WLAN-Kanalanalyse verwendet werden kann, um die Überlappung von WLAN-Kanälen anzuzeigen.
<G-vec00354-002-s072><show.anzeigen><en> NetSpot is a versatile WiFi site survey, WiFi analysis, and troubleshooting tool for macOS and Windows that can also be used as a WiFi channel analyzer to show WiFi channel overlap.
<G-vec00354-002-s073><show.anzeigen><de> Indem Sie die Option Berichtszeit wählen, können Sie die Serie einschränken oder auswählen, nur Ergebnisse einer spezifischen Zeitperiode im Bericht anzuzeigen.
<G-vec00354-002-s073><show.anzeigen><en> can be set in the report and used to show only specific results/answers of your survey (based on a certain group, time/date of answer or similar).
<G-vec00354-002-s074><show.anzeigen><de> Um detaillierte Angaben passend zu Ihrem Fahrzeug anzuzeigen, wählen Sie bitte noch das Modell und die Modellvariante aus.
<G-vec00354-002-s074><show.anzeigen><en> In order to show detail specifications for your vehicle, please select the model and the version of Detailed Article Group
<G-vec00354-002-s075><show.anzeigen><de> Dies kann bedeuten, dass deren Services auf unserer Webseite / unseren Apps integriert werden; dass sie die Möglichkeit haben, Ihnen auf unserer Seite ein individuelles Angebot anzuzeigen; oder dass der Online-Buchungsservice von Booking.com auf deren Webseite und/oder deren Apps integriert wird.
<G-vec00354-002-s075><show.anzeigen><en> This may mean that their services are integrated into our website or they have been enabled to show a customised advertisement on our website – or we are advertising on theirs.
<G-vec00381-002-s076><appear.anzeigen><de> * Apps wie iTunes und das Festplattendienstprogramm können auch dann weiterhin auf den Datenträger zugreifen, wenn dieser nicht auf dem Schreibtisch oder im Finder angezeigt wird.
<G-vec00381-002-s076><appear.anzeigen><en> * Apps such as iTunes and Disk Utility can still access the disc, even if it doesn't appear on the desktop or in the Finder.
