<G-vec00060-001-s127><indicate.anzeigen><de> Hat jedoch der Hersteller oder sein Bevollmächtigter nach einer oder mehrerer dieser Richtlinien während einer Übergangszeit die Wahl der anzuwendenden Regelung, so wird durch die CE-Kennzeichnung lediglich die Konformität mit den Bestimmungen der von ihm angewandten Richtlinien angezeigt.
<G-vec00060-001-s127><indicate.anzeigen><en> However, where one or more of those Directives allow the manufacturer or his authorised representative to choose, during a transitional period, the system to be applied, the CE marking shall indicate conformity only to the provisions of those Directives applied by the manufacturer or his authorised representative.
<G-vec00060-001-s128><indicate.anzeigen><de> Das Anliegen der Spannungsversorgung und der Betriebszustand des Moduls werden durch Leuchtdioden angezeigt.
<G-vec00060-001-s128><indicate.anzeigen><en> LEDs are used to indicate applied voltage supply and the module operating status.
<G-vec00060-001-s129><indicate.anzeigen><de> Die EtherCAT Box enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s129><indicate.anzeigen><en> The EtherCAT Box has two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s130><indicate.anzeigen><de> Nach der Anmeldung wird durch Flächenlichter angezeigt, welchen jeweiligen Ladepunkt der Kunde gerade benutzen kann.
<G-vec00060-001-s130><indicate.anzeigen><en> After logging on, large lights indicate which charging point the customer can use.
<G-vec00060-001-s131><indicate.anzeigen><de> Die EtherCAT-Klemmen enthalten je zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s131><indicate.anzeigen><en> The EtherCAT Terminals have two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s132><indicate.anzeigen><de> Unabhängig vom gewählten Menü wird Ihnen der Fortschritt des Downloads auch durch das Symbol -3- Abb.2 in der Statuszeile angezeigt.
<G-vec00060-001-s132><indicate.anzeigen><en> Irrespective of the selected menu, a symbol -3- Fig.2 in the status line will indicate the status of the download progress.
<G-vec00060-001-s133><indicate.anzeigen><de> Wenn die entsprechenden Optionsfelder aktiviert sind, werden technische Stromrichtung (rote Pfeile), magnetische Feldlinien (blau) und Lorentzkraft (schwarzer Pfeil) angezeigt.
<G-vec00060-001-s133><indicate.anzeigen><en> If the corresponding checkboxes are selected, the app will indicate the conventional direction of current (red arrows), the magnetic field lines (blue) and the Lorentz force (black arrow).
<G-vec00060-001-s134><indicate.anzeigen><de> Dann wird Ihnen die Version und das Build der Plattform die Sie installiert haben angezeigt.
<G-vec00060-001-s134><indicate.anzeigen><en> This will indicate the version and build of the platform you have installed.
<G-vec00060-001-s135><indicate.anzeigen><de> Dabei werden die Planeten in der Radix in grün dargestellt; so wird angezeigt, dass es sich hier nicht mehr um ein Geburtshoroskop mit Transiten, sondern um Progressionen handelt.
<G-vec00060-001-s135><indicate.anzeigen><en> When you right click on a progression to look at it in more detail in a wheel, you'll remark that the planets are shown in green to indicate that it's not a birth chart with transits, but a progression.
<G-vec00060-001-s136><indicate.anzeigen><de> Wenn im Anhängerbetrieb am Anhänger oder am Fahrzeug eine Blinkleuchte ausfällt, wird dies durch doppelt so schnelles Blinken der Kontrollleuchte angezeigt.
<G-vec00060-001-s136><indicate.anzeigen><en> If a turn signal bulb on the trailer or vehicle fails in towing mode, the indicator lamp flashes twice as fast to indicate the bulb failure.
<G-vec00060-001-s137><indicate.anzeigen><de> Fehlmontage ausgeschlossen Als erster Hersteller von Schlaucharmaturen hat Voswinkel dieses Problem gelöst: Bei den neuen ECOVOS-Armaturen mit Blocksicherung wird das Montageende eindeutig angezeigt.
<G-vec00060-001-s137><indicate.anzeigen><en> Voswinkel is the first manufacturer of hose fittings to solve this problem: The new ECOVOS fittings with block stop feature clearly indicate when mounting is completed.
<G-vec00060-001-s138><indicate.anzeigen><de> Zudem wird durch farbliche LEDs angezeigt, dass das Gerät eine stehende Verbindung hat und auch, ob der Akku langsam leer läuft.
<G-vec00060-001-s138><indicate.anzeigen><en> In addition, colour LEDs indicate that the module has an established connection and also whether the battery is gradually going flat.
<G-vec00060-001-s139><indicate.anzeigen><de> Während die Einstellung U gilt, wird dies durch ein,,U`` in der Statuszeile von exaEdit angezeigt.
<G-vec00060-001-s139><indicate.anzeigen><en> As long as U is in effect, a U in the status line will indicate this.
<G-vec00060-001-s140><indicate.anzeigen><de> "Wenn sehr viele Figurenwechsel vorkommen, kann es auch einfacher sein, ""Instrument""-Definitionen für jeden Namen auf oberster Dateiebene zu definieren, sodass \instrumentSwitch der Wechsel der Figur angezeigt werden kann."
<G-vec00060-001-s140><indicate.anzeigen><en> "Alternatively, if there are many character changes, it may be easier to set up ""instrument"" definitions for each character at the top level so that \instrumentSwitch can be used to indicate each change."
<G-vec00060-001-s141><indicate.anzeigen><de> Zusätzlich wird der Schaltzustand der Eingänge mit je einer LED angezeigt.
<G-vec00060-001-s141><indicate.anzeigen><en> In addition, each input has an LED used to indicate its status.
<G-vec00060-001-s142><indicate.anzeigen><de> Es sollte indessen Folgendes klargemacht werden: Wenn in der Göttlichkeit irgendeiner Situation, unter extremen Umständen, und immer dann, wenn in Befolgung höchster Weisheit eine andere Vorgehensweise angezeigt erschiene – wenn die Ansprüche der Vollkommenheit aus irgendeinem Grunde eine andere und bessere Reaktionsweise gebieten sollten – dann würde der allweise Gott auf der Stelle in dieser besseren und passenderen Art handeln.
<G-vec00060-001-s142><indicate.anzeigen><en> It should be made clear, however, that, if, in the divinity of any situation, in the extremity of any circumstance, in any case where the course of supreme wisdom might indicate the demand for different conduct—if the demands of perfection might for any reason dictate another method of reaction, a better one, then and there would the all-wise God function in that better and more suitable way.
<G-vec00060-001-s143><indicate.anzeigen><de> Halten Sie die Taste Shift gedrückt und ziehen Sie die Auswahl genau zwischen die anderen beiden Spalten, bis die orangefarbenen Umrisse, die während des Ziehens angezeigt werden, sich bewegen.
<G-vec00060-001-s143><indicate.anzeigen><en> Hold down the Shift key and drag the selection exactly between the other two columns until the orange boundaries shown during the drag operation indicate a move.
<G-vec00060-001-s144><indicate.anzeigen><de> Die EtherCAT-P-Box enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s144><indicate.anzeigen><en> The EtherCATP Box has two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s145><indicate.anzeigen><de> D: Es wird angezeigt, wie viele Arbeitsmappen oder Dateien gedruckt werden.
<G-vec00060-001-s145><indicate.anzeigen><en> D: It will indicate how many workbooks or files will be printed.
<G-vec00332-001-s019><show.anzeigen><de> In der Tat, jede Art von Suchergebnissen, die angezeigt werden sind häufig tot Web-Links oder Web-Link zurück auf die genau gleiche Seite unter verschiedenen Namen.
<G-vec00332-001-s019><show.anzeigen><en> Definitely, any kind of search engine results page that do show up are typically dead links or web link back to the very same web page under various names.
<G-vec00332-001-s020><show.anzeigen><de> Mac iPhone 4 Ringtone Maker wird automatisch angezeigt iTunes Wiedergabeliste auf der linken Seite des Programms können Sie Ihre iTunes-Video auf dem Programm wählen, oder ziehen Sie Videos in das Programm direkt.
<G-vec00332-001-s020><show.anzeigen><en> Mac iPhone 4 Ringtone Maker will automatically show up iTunes playlist on the left of the program, you can choose your iTunes video to the program, or drag video to the program directly.
<G-vec00332-001-s021><show.anzeigen><de> Auch hier wird beim jeweiligen Namen die Position in der Etage angezeigt und beim Klick auf die Raumdetailseite verlinkt.
<G-vec00332-001-s021><show.anzeigen><en> Here again, move the cursor to the name to show the position, and click on the name to show the detail page.
<G-vec00332-001-s022><show.anzeigen><de> Wenn eine solche Bestätigung nicht angezeigt wird, muss die Korrektur komplex sein.
<G-vec00332-001-s022><show.anzeigen><en> If such a confirmation does not show, then the correction must be a complex one.
<G-vec00332-001-s023><show.anzeigen><de> "Wähle ""Suchen"", wenn deine Promoted Pins in den Suchergebnissen angezeigt werden sollen."
<G-vec00332-001-s023><show.anzeigen><en> "Choose ""Search"" to show your Promoted Pins in search results."
<G-vec00332-001-s024><show.anzeigen><de> In der 5-stelligen Preis Zitat kann jede Fraktion von 0 bis 9 angezeigt.
<G-vec00332-001-s024><show.anzeigen><en> In the 5-digit pricing quote, any fraction from 0 to 9 may show up.
<G-vec00332-001-s025><show.anzeigen><de> Strassenname und Strassennummer werden nun in der korrekten Reihenfolge angezeigt, entsprechend den Daten auf der zugehörigen Karte.
<G-vec00332-001-s025><show.anzeigen><en> Always show street number and street name in correct order based on map data.
<G-vec00332-001-s026><show.anzeigen><de> "Hinweis: Sie erhalten die Benennen Sie ""Ihren Ordnernamen"" um in das Kontextmenü in Outlook 2007 und ""Ihr Ordnername""Wird als der aktuelle Name des ausgewählten Ordners angezeigt."
<G-vec00332-001-s026><show.anzeigen><en> Note: You will get the Rename “your folder name” in the right-clicking menu in Outlook 2007, and “Your folder name” will show as the current name of selected folder.
<G-vec00332-001-s027><show.anzeigen><de> Wie bei jedem Produkt könnte es regelmäßig auf eBay oder Amazon, dennoch angezeigt dies ist nicht sehr wahrscheinlich so zuverlässig ab die CrazyBulk amtliche Web Site sowie es empfiehlt sich in der Regel nicht zu kaufen bei eBay oder Amazon als die Qualität oder Erstattungen können nicht garantiert werden.
<G-vec00332-001-s027><show.anzeigen><en> African Mango Extract can be bought from the BauerNutrition main web site from Algeria and also this seems like the only method to get it. Just like any product, it could periodically show up on ebay.com or Amazon, however this is not most likely to be as dependable as from the BauerNutrition main site and also it is normally recommended not to purchase from eBay or Amazon.com as the top quality or refunds could not be ensured.
<G-vec00332-001-s028><show.anzeigen><de> "• Wenn die Disc (Playlist) gewechselt wird, kann es dazu kommen, dass ""EJECT"" im Display angezeigt wird."
<G-vec00332-001-s028><show.anzeigen><en> "• When the disc is changed, ""EJECT"" will show up instantly."
<G-vec00332-001-s029><show.anzeigen><de> "Nachdem Sie die Formel eingegeben und anschließend die Eingabetaste gedrückt haben, wird die Zeilennummer der Zelle angezeigt, die ""Tinte""."
<G-vec00332-001-s029><show.anzeigen><en> "After entering the formula, and then press the Enter key, it will show the row number of the cell which contains ""ink""."
<G-vec00332-001-s030><show.anzeigen><de> Klicken Sie auf diesen Link und durch Google maps komplettes Bildschirmgroße wird Ihnen angezeigt, wo wir uns befinden.
<G-vec00332-001-s030><show.anzeigen><en> Please click in this link and the Google maps screen will show you where we are located.
<G-vec00332-001-s031><show.anzeigen><de> Klicken Sie auf die horizontale Linie neben der Beziehung UND, und es werden einige Bedingungsfelder angezeigt, klicken Sie auf die Bedingungsfelder und geben Sie das Kriterium einzeln nach Bedarf an.
<G-vec00332-001-s031><show.anzeigen><en> Click the horizontal line beside the relationship AND, and it will show some condition boxes, click the condition boxes and specify the criterion one after one as you need.
<G-vec00332-001-s032><show.anzeigen><de> Wenn sie dann noch immer auf dem Bildschirm „Bericht“ sind, wird der gewünschte Bericht angezeigt.
<G-vec00332-001-s032><show.anzeigen><en> If still on the report screen, the desired report will show.
<G-vec00332-001-s033><show.anzeigen><de> Ohne Zweifel, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel tot Web-Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00332-001-s033><show.anzeigen><en> Indeed, any type of search results page that do show up are usually dead web links or web link back to the very same page under different names.
<G-vec00332-001-s034><show.anzeigen><de> Wird dieser Punkt neben einer TV-Staffel oder Podcast-Serie angezeigt, wurde mindestens eine Folge der Staffel oder Serie noch nicht abgespielt.
<G-vec00332-001-s034><show.anzeigen><en> If this appears next to a TV show season or podcast series, there is at least one episode in the season or series that hasn't been played.
<G-vec00332-001-s035><show.anzeigen><de> • Session-Cookies:Das sind zeitlich begrenzte Cookies und diese werden durch das Schließen des Browsers ge-löscht.o adaptive_image: Speichert die aktuelle Auflösung, um die geeignete Bildgröße auszuspieleno has_js: Speichert, ob der Browser des Users JavaScript hat oder nicht, um bestimmte Funktionen oder Darstellungen wiederzugebeno cookie_agreed: Ob der User Cookie- Popup akzeptiert hat oder nicht, um zu entscheiden, ob dem User der Hinweis nochmal angezeigt werden muss oder nicht.
<G-vec00332-001-s035><show.anzeigen><en> • Session cookies:These are temporary cookies and they are deleted by closing the browser.o adaptive image: Saves the current resolution to play the appropriate image sizeo has_js: saves information on whether the user's browser has JavaScript as to provide specific functions or display formatso cookie_agreed: checks if the user has accepted the cookie popup to decide whether to show the notice again or not.
<G-vec00332-001-s036><show.anzeigen><de> Im Display können neben den Informationen des Bordcomputers (Bordcomputer 1 oder 2) auch Informationen weiterer Systeme angezeigt werden.
<G-vec00332-001-s036><show.anzeigen><en> As well as the figures from the on-board computer (computer 1 or 2), the display can also show information from other systems.
<G-vec00332-001-s037><show.anzeigen><de> Auf jeden Fall, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel Tote Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00332-001-s037><show.anzeigen><en> Indeed, any type of search engine results page that do show up are typically dead links or link back to the very same page under different names.
<G-vec00276-001-s056><advertise.anzeigen><de> Die Verwendung der DoubleClick-Cookies ermöglicht Google und seinen Partner-Webseiten lediglich die Schaltung von Anzeigen auf Basis vorheriger Besuche auf unserer oder anderen Webseiten im Internet.
<G-vec00276-001-s056><advertise.anzeigen><en> The use of DoubleClick cookies allows Google and its affiliate sites to advertise on the basis of prior visits to our or other websites on the internet.
<G-vec00276-001-s057><advertise.anzeigen><de> Händler können auf EMR Anzeigen schalten, um potentielle Kunden anzusprechen.
<G-vec00276-001-s057><advertise.anzeigen><en> As a vendor, you may be interested in advertise on EMR to find prospective buyers.
<G-vec00276-001-s058><advertise.anzeigen><de> My Catholic Standard Nachrichten, Kleinanzeige, Anzeigen und mehr.
<G-vec00276-001-s058><advertise.anzeigen><en> My Catholic Standard News, Classifieds, Advertise and more.
<G-vec00276-001-s059><advertise.anzeigen><de> Gelegentlich gibt es auch Anzeigen in der Zeitung (normalerweise in der Unterhaltung/Kunst Spalte) oder in dem Gemeinde Magazin.
<G-vec00276-001-s059><advertise.anzeigen><en> On occasion they may advertise in the local paper (usually in the entertainment/arts section) or community magazine.
<G-vec00276-001-s060><advertise.anzeigen><de> Somit können die Mitglieder in Echtzeit die Daten zu Arbeitssuchenden, Arbeitgebern sowie - allgemeiner betrachtet - zu Beschäftigungsangeboten angeben, anzeigen und modifizieren.
<G-vec00276-001-s060><advertise.anzeigen><en> In this way, the members can, in real-time, modify, specify and advertise data concerning jobseekers, employers, as well as – more generally –Â job offers.
<G-vec00276-001-s061><advertise.anzeigen><de> Nachrichten, Anzeigen und Read the Paper.
<G-vec00276-001-s061><advertise.anzeigen><en> News, Advertise and Read the Paper.
<G-vec00276-001-s062><advertise.anzeigen><de> Santa Ynez Valley Journal Geschichte, Writers, Archiv, Anzeigen und Search Artikel .
<G-vec00276-001-s062><advertise.anzeigen><en> Santa Ynez Valley Journal History, Writers, Archive, Advertise and Search articles.
<G-vec00276-001-s063><advertise.anzeigen><de> Weiser Signal American Submit News/Briefe, Anzeigen und Subscribe.
<G-vec00276-001-s063><advertise.anzeigen><en> Weiser Signal American Submit News/Letters, Advertise and Subscribe.
<G-vec00060-001-s162><indicate.anzeigen><de> atariModePossible muss anzeigen, daß der MMU-Switch erlaubt ist.
<G-vec00060-001-s162><indicate.anzeigen><en> atariModePossible must indicate that MMU switching is permitted.
<G-vec00060-001-s163><indicate.anzeigen><de> Ein solches Muster kann die Ähnlichkeit seines Trägers mit einem bestimmten Vertreter der Fauna anzeigen.
<G-vec00060-001-s163><indicate.anzeigen><en> Such a pattern may indicate the similarity of its carrier with a certain representative of the fauna.
<G-vec00060-001-s164><indicate.anzeigen><de> Alle drei Männer trugen Luftwaffen-Uniformen ohne Aufkleber, die anzeigen, wer sie waren.
<G-vec00060-001-s164><indicate.anzeigen><en> All three of the men were wearing Air Force uniforms without any patches to indicate who they were.
<G-vec00060-001-s165><indicate.anzeigen><de> Sie kann den Grad der magnetischen Aufladung von Gegenständen oder Wasser anzeigen.
<G-vec00060-001-s165><indicate.anzeigen><en> It can indicate the degree of magnetization of objects or water.
<G-vec00060-001-s166><indicate.anzeigen><de> Es gibt eine andere Rangordnung von Bedeutungen, in der sie die Aura oder Tätigkeit göttlicher Wesen anzeigen, wie Krishna, Mahakali, Radha, oder auch anderer übermenschlicher Wesen; es gibt eine weitere Kategorie, in der sie die Aura um Objekte oder lebende Personen anzeigen – und hiermit ist die Reihe der Möglichkeiten noch nicht erschöpft.
<G-vec00060-001-s166><indicate.anzeigen><en> There is another order of significances in which they indicate the aura or the activity of divine beings, Krishna, Mahakali, Radha or else of other superhuman beings; there is another in which they indicate the aura around objects or living persons – and that does not exhaust the list of possibilities.
<G-vec00060-001-s168><indicate.anzeigen><de> Ein komplettes Blutbild durchgeführt werden wird, einschließlich einer chemischen Blutbild, ein komplettes Blutbild, und eine Urinanalyse — die Ergebnisse von denen das Vorhandensein von Stoffen, die möglicherweise die Ursache eine verlangsamte Herzfrequenz anzeigen kann.
<G-vec00060-001-s168><indicate.anzeigen><en> A complete blood profile will be conducted, including a chemical blood profile, a complete blood count, and a urinalysis — the results of which may indicate the presence of substances that might be causing a slowed heart rate.
<G-vec00060-001-s169><indicate.anzeigen><de> "Dieser Punkt ist erkennbar weil links Schilder sind, die die Wege beim Namen anzeigen, die Strecke in die man rechts abbiegt ist als ""Ameno"" benannt."
<G-vec00060-001-s169><indicate.anzeigen><en> This point is recognizable because on the left side of the path there are some signs that indicate the names of the trails.
<G-vec00060-001-s170><indicate.anzeigen><de> Die LEDs, die den Zustand des ganzen Systems anzeigen, befinden sich über dem Display.
<G-vec00060-001-s170><indicate.anzeigen><en> LEDs which indicate the status of the entire system have been provided above the keypad display.
<G-vec00060-001-s171><indicate.anzeigen><de> Wenn diesen Daten das Resultat, unten gezeigt geplottet, ein Verhältnis zwischen dem Preisniveau und der Menge des Geldumlaufs anzeigen Sie werden, welches hier durch die kumulativen Importe des Schatzes approximiert wird.
<G-vec00060-001-s171><indicate.anzeigen><en> When these data are plotted the result, shown below, indicate a relationship between the price level and the amount of money in circulation which is here approximated by the cumulative imports of treasure.
<G-vec00060-001-s172><indicate.anzeigen><de> "Wenn der Anwender Daten diesen Formats über das Fenster zieht, wird der Mauscursor anzeigen, dass die Daten hier abgelegt (""fallen gelassen"") werden können."
<G-vec00060-001-s172><indicate.anzeigen><en> When the user drags data of this format over the window, the cursor will indicate that the data can be dropped there.
<G-vec00060-001-s173><indicate.anzeigen><de> Schüler präsentieren stolz ihre ESA Nachweise welche die exakte Position der ISS anzeigen während die Programmierung im Weltall lief.
<G-vec00060-001-s173><indicate.anzeigen><en> Students proudly display their ESA certificates, which indicate the position of the ISS when their code was running in space.
<G-vec00060-001-s174><indicate.anzeigen><de> Verschiedene Stoffwechselprodukte von NMP und NEP können im Urin bestimmt werden und somit eine Belastung anzeigen.
<G-vec00060-001-s174><indicate.anzeigen><en> Various NMP and NEP metabolites can be tracked in urine and indicate exposure.
<G-vec00060-001-s175><indicate.anzeigen><de> 1 Schalt- und Überwachungseinheit mit Sicherungen, Motorschutzschalter, Vorwahl-Zählwerk zum Anzeigen der Fallzahl und zum Stillsetzen der Anlage.
<G-vec00060-001-s175><indicate.anzeigen><en> 1 switching and monitoring unit with fuses, protecting switch for the motor, preset able counter to indicate the number of falls and to switch off the unit.
<G-vec00060-001-s176><indicate.anzeigen><de> Diese Störung kennzeichnet die Personen wie die Gegenstände: Zum einen sind es dysfunktionale Versatzstücke der Mode (Schuhe ohne Absätze oder als sich um den Fuß zu schnallender Absatz), die die potenziellen TrägerInnen zu geradezu unmöglichen Haltungen und Bewegungen zwingen, zum anderen sind es die autistischen Rituale der filmischen Protagonisten angesichts eines Anderen, das Unerreichbar scheint, die diese Störung anzeigen.
<G-vec00060-001-s176><indicate.anzeigen><en> This disorder is characteristic of the individuals and of the objects: in one case it is the dysfunctional set pieces of fashion (shoes with no heels or a heel strapped around the ankle), that compel the potential wearers to perform practically impossible postures and movements; on the other hand, the autistic rituals of the film protagonist vis-Ã -vis the other, that appears unattainable, that indicate this disorder.
<G-vec00060-001-s177><indicate.anzeigen><de> Views sind temporäre Tabellen, die den gesamten oder teilweisen Inhalt einer oder mehrerer Tabellen anzeigen.
<G-vec00060-001-s177><indicate.anzeigen><en> Views are temporary tables which indicate the whole or partial contents of one or several tables.
<G-vec00060-001-s178><indicate.anzeigen><de> Der aktuelle Prototyp nutzt zwei Magnetfeldsensoren, welche die Position zuverlässig anzeigen, sobald sich die beiden Spulen auf einen Abstand von 1,5 Metern genähert haben.
<G-vec00060-001-s178><indicate.anzeigen><en> The current prototype uses two magnetic field sensors which indicate the position reliably as soon as the two coils approach each other to a distance of 1.5 meters.
<G-vec00060-001-s179><indicate.anzeigen><de> Aufklärung lieferte unser Guide, der uns durch Soweto führte: Jeder Stadtteil hat sein eigenes Handzeichen, mit dem die Fahrgäste anzeigen, in welche Richtung sie wollen.
<G-vec00060-001-s179><indicate.anzeigen><en> Our guide through Soweto explained it to us: Each suburb has its own hand signal, by which the passengers indicate which direction they want to go.
<G-vec00060-001-s180><indicate.anzeigen><de> Ich sollte auch erwähnen, dass bestimmte Handgesten Buchstaben des Alphabets und Zahlen anzeigen und zur Zeit Poussins verstanden worden wären.
<G-vec00060-001-s180><indicate.anzeigen><en> I should also mention that certain hand gestures indicate letters of the alphabet and numbers, and would have been understood at the time Poussin painted them.
<G-vec00060-001-s038><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s038><reveal.anzeigen><en> The benefits stacked up beside various other kinds of weight loss devices reveal this kind of ketone to be secure, organic and efficient with absolutely no side effects.
<G-vec00060-001-s040><reveal.anzeigen><de> Kontrollkästchen, die in romanischen Sprachen lange Textbeschreibungen haben, die aufgrund des beschränkten Platzes abgeschnitten werden, kommen jetzt automatisch mit Tool-Tips daher, die den vollständigen Text anzeigen, wenn man mit dem Mauszeiger darüber verharrt.
<G-vec00060-001-s040><reveal.anzeigen><en> Check boxes with long text labels in Romance languages that get truncated because of the limited space available now automatically come with tooltips that reveal the complete text when hovering the mouse cursor over the control.
<G-vec00060-001-s041><reveal.anzeigen><de> Und er kann Allergie und Panik anzeigen.
<G-vec00060-001-s041><reveal.anzeigen><en> And it can reveal allergies and panic.
<G-vec00060-001-s042><reveal.anzeigen><de> Sie verraten außerdem eine Retouren-Adresse für Kunden weltweit und auch die von St. Lucia auf ihrer Webseite empfehlen, dass sie auf Saint Lucia oft Schiff sollten, wenn sie wirklich das Bedürfnis, eine separate Adresse für Saint Lucia anzeigen gibt.
<G-vec00060-001-s042><reveal.anzeigen><en> They additionally reveal a returns address for global consumers and those from Saint Lucia on their returns page, suggesting they must ship to Saint Lucia quite often if they really feel the need to reveal a separate address for Saint Lucia. They provide an explanation of just how much delivery prices linked with overseas delivery, so customers should not be fear of any type of extra hidden expenses.
<G-vec00060-001-s051><reveal.anzeigen><de> Fingerabdruck vom Tatort soll bald auch Drogenmissbrauch anzeigen.
<G-vec00060-001-s051><reveal.anzeigen><en> Fingerprints from the scene of the crime will soon reveal drug abuse.
<G-vec00060-001-s056><reveal.anzeigen><de> Bevor Panel-Daten anzeigen, ob der Launch oder Relaunch erfolgreich oder nicht erfolgreich verläuft, liefert dieses Testverfahren Klarheit über die Attraktivität des Produktes und mögliche Vorbehalte.
<G-vec00060-001-s056><reveal.anzeigen><en> Before panel data can reveal whether or not a launch or relaunch is going successfully, this quickly established and conducted procedure gives you clarity about the attractiveness of the product and potential reservations.
<G-vec00332-001-s038><show.anzeigen><de> Schritt 3: Jetzt gelangen Sie in das Dialogfeld Mail Setup und klicken auf Profile anzeigen klicken.
<G-vec00332-001-s038><show.anzeigen><en> Step 3: Now you get into the Mail Setup dialog box, and click the Show Profiles button.
<G-vec00332-001-s039><show.anzeigen><de> Du kannst die Informationen, die wir zum Anzeigen von Promoted Pins und anderen Empfehlungen verwenden, wie folgt in deinen Einstellungen anpassen.
<G-vec00332-001-s039><show.anzeigen><en> You can adjust the info we use to show you Promoted Pins and other recommendations in your settings by following the instructions below.
<G-vec00332-001-s040><show.anzeigen><de> "Wenn die Signalspannung über 36V befindet, wird der LCD-Bildschirm-Symbol anzeigen "">>""."
<G-vec00332-001-s040><show.anzeigen><en> "When the signal voltage is over 36V, the LCD screen will show icon "">>'."
<G-vec00332-001-s041><show.anzeigen><de> Wenn alle Schichten sichtbar sind, sollte das Bildfenster nun unseren Text mit gelblicher Färbung in der Mitte und einem weich abgedunkeltem Rand anzeigen.
<G-vec00332-001-s041><show.anzeigen><en> If all of the layers are visible, the image box should now show our text with yellowish coloring to the center with a softly darkened border.
<G-vec00332-001-s042><show.anzeigen><de> Scrollen Sie ganz nach unten und klicken Sie auf Erweiterte Einstellungen anzeigen.
<G-vec00332-001-s042><show.anzeigen><en> Scroll down to the bottom and click Show advanced settings.
<G-vec00332-001-s043><show.anzeigen><de> Wenn Sie also alle Wechselbüros für die Richtung Bank Card USD sehen wollen -> Bitcoin Cashsehen möchten, klicken Sie auf „Alle anzeigen”.
<G-vec00332-001-s043><show.anzeigen><en> "So if you want to see all the exchangers for the direction Bank Card USD -> Bitcoin Cash, click the ""Show all""."
<G-vec00332-001-s044><show.anzeigen><de> "Konten mit dem Abonnementmodus ""Auf Anfrage"" ohne aktivierter Option ""In der Bewertung anzeigen""."
<G-vec00332-001-s044><show.anzeigen><en> Accounts with “By request” subscription mode without “Show in the Rating” option enabled.
<G-vec00332-001-s045><show.anzeigen><de> Wenn die Option 'Gruppen in Formatliste anzeigen' aktiviert ist, werden die Gruppennamen in den Formatlisten angezeigt (1).
<G-vec00332-001-s045><show.anzeigen><en> When the 'Show Groups in Format List' option is enabled, the group names will be displayed in the format lists (1) .
<G-vec00332-001-s046><show.anzeigen><de> Wenn in der Struktur der Elementtabelle Felddefinitionen angezeigt werden (Definition anzeigen), können Sie die Definitionen bearbeiten, indem Sie die Definition auswählen und eine Option aus der Auswahlliste der Definition auswählen (siehe Abbildung oben).
<G-vec00332-001-s046><show.anzeigen><en> When the element's table structure shows field definitions (Show Definition), the definitions can be edited by selecting the definition and selecting an option from the definition's combo box (see screenshot above).
<G-vec00332-001-s047><show.anzeigen><de> Dieser Controller verfügt über zwei Steuerknöpfe und zwei LEDs, die anzeigen, wenn jede Funktion aktiv ist.
<G-vec00332-001-s047><show.anzeigen><en> This controller features two control knobs and two Lights that show when each function is active.
<G-vec00332-001-s048><show.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00332-001-s048><show.anzeigen><en> The benefits stacked up alongside various other types of weight loss devices show this type of ketone to be secure, organic and effective with absolutely no side effects.
<G-vec00332-001-s049><show.anzeigen><de> Schaltfläche Begriffsebene des aktuellen Begriffs anzeigen: Zeigt zum ausgewählten Term eine Begriffsinformation (z.
<G-vec00332-001-s049><show.anzeigen><en> Show concept information button: Click to show the concept information for the selected term (e.g.
<G-vec00332-001-s050><show.anzeigen><de> LED-Fernseher (Bild anzeigen) Hier zeigen wir nur Produktbilder von Sponsor-Marken, die an Open Icecat teilnehmen, da Produktbilder dem Urheberrecht unterliegen können.
<G-vec00332-001-s050><show.anzeigen><en> (show image) Here, we only show product images of sponsoring brands that joined Open Icecat as product images can be subject to copyrights.
<G-vec00332-001-s051><show.anzeigen><de> Sie zeigen außerdem eine Retouren-Adresse für internationale Verbraucher wie auch die von Jan Mayen auf ihrer Webseite empfehlen, sie müssen sehr oft auf Jan Mayen Schiff, wenn sie wirklich das Gefühl gibt das sollte eine andere Adresse für Jan Mayen anzeigen.
<G-vec00332-001-s051><show.anzeigen><en> They additionally show a returns address for global consumers and those from Jan Mayen on their returns page, proposing they must ship to Jan Mayen quite often if they really feel the have to show a separate address for Jan Mayen.
<G-vec00332-001-s052><show.anzeigen><de> "Beispielsweise können wir deinen Freunden anzeigen, dass du an einer beworbenen Veranstaltung interessiert bist oder eine Seite mit ""Gefällt mir"" markiert hast, die von einer Marke erstellt worden ist, die uns dafür bezahlt hat, dass wir ihre Anzeigen auf Facebook zeigen."
<G-vec00332-001-s052><show.anzeigen><en> For example, we may show your friends that you are interested in an advertised event or have liked a Page created by a brand that has paid us to display its ads on Facebook.
<G-vec00332-001-s053><show.anzeigen><de> Ihr Bike Fähigkeiten auf die Spur anzeigen .
<G-vec00332-001-s053><show.anzeigen><en> Show your bike skills on the track.
<G-vec00332-001-s055><show.anzeigen><de> Ohne jede Tutorials zu sprechen, dieser Ebene des Problems möglicherweise für einige lästige anzeigen..
<G-vec00332-001-s055><show.anzeigen><en> Without any tutorials to speak of, this level of problem might show annoying for some.
<G-vec00332-001-s056><show.anzeigen><de> Das Band ist in Tabulatoren eingeteilt, die aufeinander bezogene Funktionen gruppieren und sie zusammen anzeigen.
<G-vec00332-001-s056><show.anzeigen><en> The Ribbon is divided into tabs that group related functions and show them together.
<G-vec00060-001-s181><indicate.anzeigen><de> Bei diesen Prozessen, und wie die bisher diskutierte Kunst anzeigt, geht es dabei immer wieder um die Frage, was diese Umwandlungsprozesse für die Menschen bedeuten und was für Subjekte sie hervorbringen.
<G-vec00060-001-s181><indicate.anzeigen><en> As the works of art discussed above indicate, these processes are repeatedly concerned with the question of what these processes of transformation mean for humans and what kinds of subjects they produce.
<G-vec00060-001-s182><indicate.anzeigen><de> Wenn wir zur Sonne hinsehen, dann können wir nichts bemerken, was eine solche Rotation anzeigt, genau weil es keine leicht sichtbare Merkmale auf der Oberfläche der Sonne gibt.
<G-vec00060-001-s182><indicate.anzeigen><en> When we look at the sun, then we cannot notice something, which would indicate such a rotation, exactly because there are no easily visible features on the surface of the sun.
<G-vec00060-001-s183><indicate.anzeigen><de> Das Firmware Update könnte noch etwas optimiert werden, da die Software keinen durchgehenden Status anzeigt.
<G-vec00060-001-s183><indicate.anzeigen><en> The Firmware update software could be optimized some more, since the software does not indicate a continuously status.
<G-vec00060-001-s184><indicate.anzeigen><de> Leber-Enzym worths wird sicherlich mit der Nutzung zu verbessern, die während dies Schäden anzeigt es Angst macht vorschlagen, die zu Schäden führen könnte.
<G-vec00060-001-s184><indicate.anzeigen><en> Liver enzyme worths will certainly enhance with use, which while this does not indicate damage it does show tension that could lead to damages.
<G-vec00060-001-s185><indicate.anzeigen><de> 1983 präsentiert Blancpain mit dem kleinsten Automatikuhrwerk, das Mondphasen, Tag, Monat und Datum anzeigt, eine Weltneuheit und rückt damit eine bis dahin weitgehend in Vergessenheit geratene Komplikation in den Mittelpunkt.
<G-vec00060-001-s185><indicate.anzeigen><en> In 1983, Blancpain brought out a world first with the smallest self-winding movement to indicate moon phase, day, month and date, thereby bringing back a complication which had all but disappeared at the time.
<G-vec00060-001-s186><indicate.anzeigen><de> Obwohl Oxandrolone als mildeste anabole Steroide daran gedacht, anzeigt es nicht, dass es keine Nebenwirkungen hat.
<G-vec00060-001-s186><indicate.anzeigen><en> Although Oxandrolone is thought about as the mildest steroid stacks, it does not indicate that it has no side-effects.
<G-vec00060-001-s187><indicate.anzeigen><de> In einer idealen Situation ist es notwendig, das Arzneimittel nur nach Erhalt der Ergebnisse der Analysen zu verschreiben, was anzeigt, für welche speziellen Mittel die nachgewiesenen Mikroorganismen empfindlich sind.
<G-vec00060-001-s187><indicate.anzeigen><en> In an ideal situation, it is necessary to prescribe the drug only after receiving the results of the analyzes, which will indicate what particular agents the detected microorganisms are sensitive to.
<G-vec00060-001-s188><indicate.anzeigen><de> Wie man auf dem unteren Bild erkennen kann, sind die Hauptfarben Orange und Violett, was Negativität anzeigt.
<G-vec00060-001-s188><indicate.anzeigen><en> As one can see from the picture below, the main colours seen are orange and violet, which indicate negativity.
<G-vec00060-001-s189><indicate.anzeigen><de> Die Verwendung des Namens der Firma Aquapol ist hier lediglich ein Mittel, das anzeigt, dass eine andere Person als der Namensträger unabhängige Informationen über die Produkte der Firma gibt.
<G-vec00060-001-s189><indicate.anzeigen><en> The use of the name of the firm Aquapol is only a means to indicate that a person different from it gives independent information about it.
<G-vec00060-001-s190><indicate.anzeigen><de> Ich denke, dass es ziemlich offensichtlich war, dass die Seite für dein Telefon oder andere ähnliche Geräte gedacht ist, da der Name der Seite das verdammt nochmal anzeigt.
<G-vec00060-001-s190><indicate.anzeigen><en> I think that it was quite obvious that the site is meant for your phone, or other similar devices, since the name of the site does fucking indicate that.
<G-vec00060-001-s191><indicate.anzeigen><de> Die meisten Browser sind Cookies akzeptieren, aber Sie können Ihren Browser so einstellen, dass alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00060-001-s191><indicate.anzeigen><en> Most browsers are initially set up to accept cookies, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00060-001-s192><indicate.anzeigen><de> Einzig der leuchtend rote Aktivator-Knopf, der präzise anzeigt, an welchem Tisch man sitzt und welches Spiel man spielt, ist ein Pluspunkt.
<G-vec00060-001-s192><indicate.anzeigen><en> The one saving grace for them are the bright red activator buttons that indicate precisely which table you're at, and what game you're playing.
<G-vec00060-001-s193><indicate.anzeigen><de> Dabei muss sich die Frau einem Bluttest-Profil zu unterziehen, das die immunologische Umwelt ihres reproduktiven Systems anzeigt.
<G-vec00060-001-s193><indicate.anzeigen><en> It requires the woman to undergo a profile of blood tests that indicate the immunological environment within her reproductive system.
<G-vec00060-001-s194><indicate.anzeigen><de> Stellen Sie Ihren Browser alle Cookies, einschließlich Cookies mit unseren Dienstleistungen verbunden zu blockieren, oder anzeigt, wenn ein Cookie von uns gesetzten.
<G-vec00060-001-s194><indicate.anzeigen><en> Set your browser to block all cookies, including cookies associated with our services, or to indicate when a cookie is being set by us.
<G-vec00060-001-s195><indicate.anzeigen><de> Der Verband der Automobilingenieure hat eine Kategorisierung von Motorölen vorgenommen, die Viskosität (Zähflüssigkeit) und die Temperatur anzeigt, bei der Motoröl verwendet werden kann.
<G-vec00060-001-s195><indicate.anzeigen><en> The Society of Automotive Engineers has developed a categorization of motor oils which will indicate the viscosity (thickness) and temperature in which engine oil can be used.
<G-vec00060-001-s196><indicate.anzeigen><de> Der Indikator wird wahrscheinlich spätestens zum Launch implementiert und einem Wifi Symbol (wie auf eurem Mobiltelefon) ähneln, welches euch Stufenweise anzeigt ob eure Gruppenmitglieder in Reichweite sind oder nicht.
<G-vec00060-001-s196><indicate.anzeigen><en> The indicator will be probably implemented latest by launch and it will look similar to the Wifi Symbol (on your cell-phone) that will gradually indicate whether or not your party members are in range.
<G-vec00060-001-s197><indicate.anzeigen><de> Deaktivieren von Cookies Die meisten Browser sind standardmäßig so eingestellt, dass sie Cookies akzeptieren, aber Sie können Ihren Browser so einstellen, dass er alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00060-001-s197><indicate.anzeigen><en> Disabling cookies Most browsers are set to accept cookies by default, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00060-001-s198><indicate.anzeigen><de> Die App übermittelt diesen Mitschnitt an den Server, der einen Abgleich der Ist-Werte mit den Soll-Werten vornimmt und auf diese Weise Fehlfunktionen frühzeitig anzeigt.
<G-vec00060-001-s198><indicate.anzeigen><en> The app sends this recording to a server, which compares current values with target values and thus can indicate malfunctions early on.
<G-vec00060-001-s199><indicate.anzeigen><de> Parallel zur Strömungsrichtung dient ein Zeiger des Trägers, der die Position auf der Skala der Versuchsrinne anzeigt.
<G-vec00060-001-s199><indicate.anzeigen><en> Parallel to the flow, a pointer of the carrier is used to indicate the position on the scale of the experimental flume.
<G-vec00060-001-s238><indicate.anzeigen><de> * Die 2 Bilder der Chromversion sind verfügbar, um die Abmessungen anzuzeigen.
<G-vec00060-001-s238><indicate.anzeigen><en> * The 2 pictures of the chrome version are available to indicate the dimensions.
<G-vec00060-001-s239><indicate.anzeigen><de> Passagen in der Nähe vom Ende des Leviathan erschien, um anzuzeigen, dass Hobbes wollte seinen Frieden mit der englischen Regierung, die verärgert die Royalisten.
<G-vec00060-001-s239><indicate.anzeigen><en> Passages near the end of the Leviathan appeared to indicate that Hobbes was trying to make his peace with the English government, which angered the Royalists.
<G-vec00060-001-s240><indicate.anzeigen><de> Diese Methode hat einen booleschen Wert als Parameter, um anzuzeigen, ob Schaltflächen gezeichnet werden sollen oder nicht.
<G-vec00060-001-s240><indicate.anzeigen><en> This method takes a boolean as a parameter to indicate whether push buttons should be painted or not.
<G-vec00060-001-s241><indicate.anzeigen><de> Sie können Flair wählen Sie Ihre Nationalität, um anzuzeigen, durch Bearbeiten oben klicken.
<G-vec00060-001-s241><indicate.anzeigen><en> You can select flair to indicate your nationality by clicking edit above.
<G-vec00060-001-s242><indicate.anzeigen><de> Liste der Geräte: Mit nur verschiedenen Videorecorder Fügen Sie die IP-Adresse des Recorders und Bearbeiten von Videorecordern bereits hinzugefügt anzuzeigen.
<G-vec00060-001-s242><indicate.anzeigen><en> List of Devices: Add different video recorders with only indicate the IP address of the recorder and edit video recorders already added.
<G-vec00060-001-s243><indicate.anzeigen><de> "Halten Sie gleichzeitig Ihre Hand, um die universelle Geste ""Stopp / Stopp / Nein"" anzuzeigen."
<G-vec00060-001-s243><indicate.anzeigen><en> "At the same time, hold your hand to indicate the universal gesture of ""stop / halt / no""."
<G-vec00060-001-s244><indicate.anzeigen><de> Dieses Foto scheint eine Art 'Blockade' durch Frank anzuzeigen, aber sie war minimal.
<G-vec00060-001-s244><indicate.anzeigen><en> This photo seems to indicate some level of blockage on Frank's side, but it was minimal.
<G-vec00060-001-s245><indicate.anzeigen><de> Das Muster auf ihm scheint, anzuzeigen, daя es von der westlichen Periode Zhou (1100 BC bis 770 BC) entstehen kann.
<G-vec00060-001-s245><indicate.anzeigen><en> The pattern on this replica seems to indicate that it may originate from the Western Zhou period (1100 BC to 770 BC).
<G-vec00060-001-s246><indicate.anzeigen><de> Das Team-Namen sind auf dem Board, um schriftliche und eine 0 platziert neben jedem Namen auf den aktuellen Spielstand anzuzeigen.
<G-vec00060-001-s246><indicate.anzeigen><en> The team names are written on the board in order and a 0 placed next to each name to indicate the current score.
<G-vec00060-001-s247><indicate.anzeigen><de> Da ein höheres Hoch und ein höheres Tief gebildet wurden, wurde Block 1 blau gekennzeichnet, um seine stark bullische Tendenz anzuzeigen.
<G-vec00060-001-s247><indicate.anzeigen><en> Since a higher high and a higher low were created, Block 1 has been labeled in blue to indicate its strong bullish bias.
<G-vec00060-001-s248><indicate.anzeigen><de> Erhöhte Konkurrenz, Produktdiversifizierung Linien scheinen, anzuzeigen, dass diese Abbildungen fortfahren, sich aufwärts zu bewegen.
<G-vec00060-001-s248><indicate.anzeigen><en> Increased competition, diversification of product lines seem to indicate that these figures will continue to move upward.
<G-vec00060-001-s249><indicate.anzeigen><de> Bei VMware®- oder Hyper-V®-Instanzen färben sich nur numerische Werte rot, um die Überlastung anzuzeigen.
<G-vec00060-001-s249><indicate.anzeigen><en> For VMware® or Hyper-V® instances, only the numerical values turn red to indicate over allocation.
<G-vec00060-001-s250><indicate.anzeigen><de> "Der Backslash ""\"" läßt sich als letztes Zeichen in einer Zeile dazu verwenden, die Fortsetzung der Direktive in der nächsten Zeile anzuzeigen."
<G-vec00060-001-s250><indicate.anzeigen><en> "The backslash ""\"" may be used as the last character on a line to indicate that the directive continues onto the next line."
<G-vec00060-001-s251><indicate.anzeigen><de> Diese Informationen können kooperieren in ihren künstlerischen Schöpfungen zu durchdringen und versuchen, die Geheimnisse zu entwirren, dass sie vererben, und auch, um anzuzeigen, dass Blake große Aufmerksamkeit für die menschliche Intuition hatte, anzeigen, einschließlich, sofort aus dem Grunde, dass während der historischen Zeit herrschte in der er lebte.
<G-vec00060-001-s251><indicate.anzeigen><en> This information can cooperate to penetrate in their artistic creations and try to unravel the mysteries that they bequeath, and also to indicate that Blake had great attention to human intuition, showing, including, right away from the reason that prevailed during the historical period in which he lived.
<G-vec00060-001-s252><indicate.anzeigen><de> Dieses Produkt wurde gemäß den Anforderungen von CE hergestellt, um die Konformität mit der grundlegenden Gesundheit und Sicherheit anzuzeigen.
<G-vec00060-001-s252><indicate.anzeigen><en> This product was produced under the requirements of CE to indicate conformity with the essential health and safety.
<G-vec00060-001-s253><indicate.anzeigen><de> Wenn Sie eingeben '2013 / 03 / 21 In eine Zelle wird dieser Apostroph vor dem Datum verwendet, um Excel anzuzeigen, dass der Wert in der Zelle ein Textwert ist (siehe folgenden Screenshot).
<G-vec00060-001-s253><indicate.anzeigen><en> When you input '2013/03/21 into a cell, that apostrophe before the date is used to indicate to Excel that the value in the cell is text value (see following screenshot).
<G-vec00060-001-s254><indicate.anzeigen><de> Das Kreuz steht für den Pakt mit den Menschen in den vier Gestalten ansehen, Personifikationen der Theologie, Literatur, Wissenschaft, und Kunst, zu dem greifen sie die Kinder der neuen Dämonen war, während eine Schar von Kritzeleien unerklärlich, lebendige Farben, Es erinnert an die geheimnisvolle Warten auf Rettung, als Embryonen bei der jungen Generation, um anzuzeigen, dass nichts verloren geht.
<G-vec00060-001-s254><indicate.anzeigen><en> The cross represents the pact with men in the four figures contemplating, personifications of Theology, literature, science, and art, to which they attack the children of the new demons was, while a bevy of doodles inexplicable, vibrant color, It evokes the mysterious waiting for salvation, as embryos related to new generations, to indicate that nothing is lost.
<G-vec00060-001-s255><indicate.anzeigen><de> Nirgendwo im Heiligen Evangelium und zu jeder Zeit seiner Verkündigung, das fleischgewordene Wort Gott hat gesagt, dass viele einladender und barmherzig zu sein, die moralische Unordnung zu empfangen und zu legitimieren, oder dass Sie Angst zu haben, zu nennen und die moralische Störung als solche, um anzuzeigen,, Bewegen auf falschen Vorwänden der Barmherzigkeit und die Falschakzeptanz.
<G-vec00060-001-s255><indicate.anzeigen><en> Nowhere in the Holy Gospel and at any time of His preaching, the Incarnate Word of God has ever said that to be welcoming and merciful to accommodate and legitimize the moral disorder, or that you have to be afraid to call and to indicate the moral disorder as such, moving on false pretexts of mercy and false acceptance.
<G-vec00060-001-s256><indicate.anzeigen><de> Wird verwendet, um das Ende irgendwelcher Medien, zum Beispiel das Ende eines Bandlaufwerks, anzuzeigen.
<G-vec00060-001-s256><indicate.anzeigen><en> Used to indicate the end of some media, for example the end of a tape drive
<G-vec00358-001-s057><show.anzeigen><de> Sie wurde herausgebracht, um Werbeanzeigen anzuzeigen, weil Super Web LLC, der Herausgeber von Cyti Web, Geld für Pay-per-Click-Websites erhält.
<G-vec00358-001-s057><show.anzeigen><en> It has been released in order to show advertisements because Super Web LLC, which is the publisher of Cyti Web, receives money from pay-per-click websites.
<G-vec00358-001-s058><show.anzeigen><de> Die Karte verzweigt dann in separate Zellen, um Details oder Beispiele für das Thema anzuzeigen.
<G-vec00358-001-s058><show.anzeigen><en> The map then branches out into separate cells to show details or examples of the topic.
<G-vec00358-001-s059><show.anzeigen><de> Man kann jetzt bei Desktop-Browsern das Bild anklicken um die obere und untere Leiste anzuzeigen und auch auszublenden.
<G-vec00358-001-s059><show.anzeigen><en> You can now click the image in desktop browsers to show and also hide the top and bottom bars.
<G-vec00358-001-s060><show.anzeigen><de> Verwende deine Highlights zum einfachen Bearbeiten oder um die Sensorendaten in deinem finalen Clip anzuzeigen.
<G-vec00358-001-s060><show.anzeigen><en> Use your highlights for easy editing or to show sensor stats in your final video.
<G-vec00358-001-s061><show.anzeigen><de> Klicken Sie auf das Diagramm, um es anzuzeigen Diagrammwerkzeuge schwimmen Band, dann klick Layout > Achsen.
<G-vec00358-001-s061><show.anzeigen><en> Click the chart to show Chart Tools in the Ribbon, then click Layout > Axes.
<G-vec00358-001-s062><show.anzeigen><de> Ebenso verwenden wir die Geo-Lokalisierung, um Ihnen in unserem Online Shop die richtigen Produkte, Preise und Steuern Ihres jeweiligen Landes anzuzeigen.
<G-vec00358-001-s062><show.anzeigen><en> Further, we use geo localisation to show you the right products, prices and taxes of the respective country in our online shop.
<G-vec00358-001-s063><show.anzeigen><de> Sie können diese ausblenden, es kann jedoch sinnvoll sein, sie wieder anzuzeigen.
<G-vec00358-001-s063><show.anzeigen><en> You can switch them off, but it may be useful to show them again.
<G-vec00358-001-s064><show.anzeigen><de> Ziel ist es, die Seite, die Google als die Relevanteste für den Nutzer erachtet, ganz oben auf der Liste anzuzeigen.
<G-vec00358-001-s064><show.anzeigen><en> The aim is to show the page that Google perceives as most relevant to users at the top of the list.
<G-vec00358-001-s065><show.anzeigen><de> Sie können Total zu Ihrem Formular hinzufÃ1⁄4gen, um die Zusammenfassung der Zahlung anzuzeigen, bevor Benutzer auf Senden klicken.
<G-vec00358-001-s065><show.anzeigen><en> You can add Total to your form to show the summary of the payment before users press Submit.
<G-vec00358-001-s066><show.anzeigen><de> Hier zeige ich Ihnen eine Möglichkeit, das Thema über oder unter den Absendern in der E-Mail-Liste in Microsoft Outlook anzuzeigen.
<G-vec00358-001-s066><show.anzeigen><en> Here I will show you a way to show the subject above or below the senders in mails list in Microsoft Outlook.
<G-vec00358-001-s067><show.anzeigen><de> Wenn Sie Ergebnisse zuvor in absteigender Reihenfolge sortiert haben, müssen Sie erneut auf die Spaltenbezeichnung klicken, um die Sortierreihenfolge wieder umzukehren und den höchsten Ressourcenverbrauch oben in der Liste anzuzeigen.
<G-vec00358-001-s067><show.anzeigen><en> If you have previously sorted results in descending order, you must click the column label again to reverse the sort order and show the highest resource consumers at the top of the list.
<G-vec00358-001-s068><show.anzeigen><de> Ein Fenster wird geöffnet, um den Erstellungsprozess anzuzeigen.
<G-vec00358-001-s068><show.anzeigen><en> A window is opened to show the build progress.
<G-vec00358-001-s069><show.anzeigen><de> Dann erscheint die zweite Select Specific Cells, um anzuzeigen, wie viele Zellen ausgewählt sind.
<G-vec00358-001-s069><show.anzeigen><en> Then the second Select Specific Cells comes out to show how many cells are selected.
<G-vec00358-001-s070><show.anzeigen><de> Um die Anrufliste anzuzeigen, drehen Sie den Steuerungsknopf.
<G-vec00358-001-s070><show.anzeigen><en> Turn the rotary pushbutton to show the call list.
<G-vec00358-001-s071><show.anzeigen><de> Zu einer bestimmten Stelle im Musiktitel wechseln: Drücken Sie, wenn der Bildschirm „Sie hören“ angezeigt wird, auf die Touch-Oberfläche und streichen Sie dann nach unten, um die abgelaufene und verbleibende Zeit anzuzeigen.
<G-vec00358-001-s071><show.anzeigen><en> Move to a specific point in the song. On the Now Playing screen, press the Touch surface, then swipe down to show the elapsed and remaining time.
<G-vec00358-001-s072><show.anzeigen><de> Beispielsweise arbeitet unser Team intensiv daran, die Suchalgorithmen für Entdeckungen zu aktualisieren, um unsere Gastgeber zu unterstützen und Gästen die relevantesten Entdeckungen anzuzeigen.
<G-vec00358-001-s072><show.anzeigen><en> For example, our team is working hard to update experience search algorithms to support our hosts and show the most relevant experiences to guests.
<G-vec00358-001-s073><show.anzeigen><de> Du kannst die Seite filtern, um nur dann Sprechblasen anzuzeigen, wenn sich die Anzahl der Klicks in einem bestimmten Grenzbereich befindet.
<G-vec00358-001-s073><show.anzeigen><en> And you can filter the page, to show only bubbles above your set click threshold.
<G-vec00358-001-s074><show.anzeigen><de> Sie können folgendermaßen vorgehen, um die neue Artikelzeile in Outlook anzuzeigen.
<G-vec00358-001-s074><show.anzeigen><en> You can do as follows to show the new item row in Outlook.
<G-vec00358-001-s075><show.anzeigen><de> Füge den folgenden Link in einem Kommentar, eine Beschreibung oder eine Nachricht ein, um dieses Bild darin anzuzeigen.
<G-vec00358-001-s075><show.anzeigen><en> Hertha Götz Include in a comment, a description or a message to show this image.
<G-vec00060-001-s926><indicate.anzeigen><de> Alle unsere bisherigen Ergebnisse zeigen an, dass sich die Mine Bama für Ressourcenuntersuchungen und eine Bewertung ihres wirtschaftlichen Potenzials eignet.
<G-vec00060-001-s926><indicate.anzeigen><en> All of our results to date indicate that the Bama Mine is a candidate for resource testing and an evaluation of its economic potential.
<G-vec00060-001-s927><indicate.anzeigen><de> Relevante Entdeckungen zeigen auch an, dass es im Bereich die Marinestation von Knossos gab.
<G-vec00060-001-s927><indicate.anzeigen><en> Relevant findings also indicate that in the area there was the naval station of Knossos. Caves & Gorges
<G-vec00060-001-s928><indicate.anzeigen><de> Die Werte Nitrat (NO3) und Nitrit (NO2) zeigen an, ob die biologischen Reinigungsprozesse funktionieren.
<G-vec00060-001-s928><indicate.anzeigen><en> The nitrate (NO3) and nitrite (NO2) values indicate whether the biological cleaning processes are functioning efficiently.
<G-vec00060-001-s929><indicate.anzeigen><de> Gleichzeitig messen die Strohschüttlersensoren (Plattensensoren) den Verlust an den Schüttlern (dem Engpaß des Mähdrescherdurchsatzes) und zeigen an, dass die Strohschüttler überlastet sind – deshalb die Fahrt VERLANGSAMEN.
<G-vec00060-001-s929><indicate.anzeigen><en> For example, the straw walker sensors measure the loss from the straw walkers (the bottleneck of combine throughput) and indicate that the straw walkers canot keep up. In this instance, the operator should slow down.
<G-vec00060-001-s930><indicate.anzeigen><de> Die Farben in diesem Bild der Galaxie J090543.56+043347.3 zeigen an, ob und wie schnell sich das Gas in dem betreffenden Bereich der Galaxie auf uns zu oder von uns weg bewegt.
<G-vec00060-001-s930><indicate.anzeigen><en> Colours in this image of the galaxy J090543.56+043347.3 indicate whether there is gas moving towards us or away from us, and at what speed.
<G-vec00060-001-s931><indicate.anzeigen><de> Beobachtungen zeigen an, dass die Temperaturschwingung etwa 0,05 ° C beträgt und schwer zu erkennen ist.
<G-vec00060-001-s931><indicate.anzeigen><en> Observations indicate that the temperature oscillation is about 0.05 C and it is difficult to detect.
<G-vec00060-001-s932><indicate.anzeigen><de> Studien zeigen an, dass diese Chemikalie möglichen Gebrauch hat, wenn sie verbessert das Lipidprofil bei der Erhöhung von Muskelmass.
<G-vec00060-001-s932><indicate.anzeigen><en> Studies indicate that this chemical has potential use in improving the lipid profile while increasing muscle mass.
<G-vec00060-001-s933><indicate.anzeigen><de> Zählungen die während der letzten zwanzig Jahre gemacht wurden zeigen an, dass die Anzahl sich verringert.
<G-vec00060-001-s933><indicate.anzeigen><en> Counts made over the last twenty years indicate that their number is decreasing .
<G-vec00060-001-s934><indicate.anzeigen><de> Werte Ã1⁄4ber 50 zeigen Wachstum an.
<G-vec00060-001-s934><indicate.anzeigen><en> Any values above 50 indicate growth.
<G-vec00060-001-s935><indicate.anzeigen><de> Drei schwarze konzentrische Scheiben mit drei Indizes in Komplementärfarben zeigen klar die Stunden, Minuten und Sekunden an.
<G-vec00060-001-s935><indicate.anzeigen><en> Three concentric black discs marked with three index in contrasting colors indicate clearly the hours, minutes and seconds.
<G-vec00060-001-s936><indicate.anzeigen><de> Gemeinsam zeigen diese Planeten an, daß diese Beziehung vermutlich einen starken Einfluß auf die Denkweise der beiden Partner ausüben wird.
<G-vec00060-001-s936><indicate.anzeigen><en> These planets together indicate that this relationship is likely to have a strong effect on the way you both think.
<G-vec00060-001-s937><indicate.anzeigen><de> Versand-Benachrichtigungen zeigen an, dass das Paket versandt wurde.
<G-vec00060-001-s937><indicate.anzeigen><en> Ship notifications indicate that the shipment information has been sent to FedEx.
<G-vec00060-001-s938><indicate.anzeigen><de> Kontroll-LEDs zeigen unmittelbar die elektrische Funktionsfähigkeit aller Leiter an.
<G-vec00060-001-s938><indicate.anzeigen><en> Control LEDs immediately indicate the electrical operability of all conductors.
<G-vec00060-001-s939><indicate.anzeigen><de> Frühere Berichte, die von Besuchern der Insel aufgezeichnet wurden, zeigen an, dass den Statuen vom mythischen König Tuu Ku Ihu und dem Gott Make Make befohlen wurde, zu wandern.
<G-vec00060-001-s939><indicate.anzeigen><en> Earlier accounts recorded by visitors to the island indicate that statues were ordered to walk by the mythical King Tuu Ku Ihu and the god Make Make.
<G-vec00060-001-s940><indicate.anzeigen><de> Stoppschilder zeigen an, dass Sie vollständig anhalten müssen, bevor Sie weiterfahren.
<G-vec00060-001-s940><indicate.anzeigen><en> Stop signs indicate that you must come to a complete stop before giving way.
<G-vec00060-001-s941><indicate.anzeigen><de> Buchstaben und Zahlen auf der Außenseite zeigen an, in welcher Position Sie diesem Buchstaben bei der Betrachtung von dieser Seite aus begegnen (z.
<G-vec00060-001-s941><indicate.anzeigen><en> Letters and numbers on the outside indicate at what position you come across this letter when looking from that side (e.g.
<G-vec00060-001-s942><indicate.anzeigen><de> Das Vorhandensein von Anzeichen von Übelkeit, das Erbrechen, die Verdauungsstörung und die Diarrhöe zeigen die erhöhten Effekte auf den Magen an.
<G-vec00060-001-s942><indicate.anzeigen><en> The presence of symptoms of nausea, vomiting, indigestion, and diarrhea indicate the increased effects on the stomach. 12 units and above
<G-vec00060-001-s943><indicate.anzeigen><de> Mit Ihrer Nutzung der Websites zeigen Sie an, dass Sie diese Nutzungsbedingungen akzeptieren und damit einverstanden sind, sich an diese zu halten.
<G-vec00060-001-s943><indicate.anzeigen><en> By using the Websites, you indicate that you accept these terms of use and that you agree to abide by them.
<G-vec00060-001-s944><indicate.anzeigen><de> Verschiedene Größen der Freibeuter-Münzen zeigen den unterschiedlichen Wert des Piraten-Spielgeldes an.
<G-vec00060-001-s944><indicate.anzeigen><en> Different sizes of buccaneer coins indicate the different value of pirate play money.
<G-vec00060-001-s976><indicate.anzeigen><de> Rechts unten zeigt das Programm den maximalen Wert der Stromstärke an.
<G-vec00060-001-s976><indicate.anzeigen><en> The program will indicate the new value of the maximal amperage.
<G-vec00060-001-s977><indicate.anzeigen><de> Viele Fragen werden in jedem Abschnitt gefragt, und der Spieler muss das Jahr ein, diese Ereignisse - wenn der Spieler zeigt an, das genaue Jahr bekommen dann die maximale Punktzahl.
<G-vec00060-001-s977><indicate.anzeigen><en> Many questions will be asked in each section and the player must set the year, these events - if the player will indicate the exact year then get maximum points.
<G-vec00060-001-s978><indicate.anzeigen><de> Der Test zeigt bereits eine hCG (humanes Choriongonadotropin) Konzentration von 12 IU/L an und eignet sich daher für eine Anwendung bereits vor dem Ausbleiben der Periode (etwa zehn Tage nach dem Geschlechtsverkehr).
<G-vec00060-001-s978><indicate.anzeigen><en> The test can already indicate an hCG (human choriongonadotropine) concentration of 12 IU/L and is therefore suitable for use even before the period has stopped (about ten days after sexual intercourse).
<G-vec00060-001-s979><indicate.anzeigen><de> 17.4 Ein Linienrichter zeigt an, ob ein Federball „in“ oder „aus“ ist, bezogen auf die ihm zugewiesene(n) Linie(n).
<G-vec00060-001-s979><indicate.anzeigen><en> 17.4 A line judge shall indicate whether a shuttle landed `in' or `out' on the line(s) assigned.
<G-vec00060-001-s980><indicate.anzeigen><de> Sie zeigt jedoch an, von Wilber selbst, die umkämpfte - im Gegensatz zur einvernehmlichen - Situation der Entwicklungsforschung.
<G-vec00060-001-s980><indicate.anzeigen><en> But it does indicate, from Wilber himself, the embattled – as opposed to the consensual – situation of developmentalism.
<G-vec00060-001-s981><indicate.anzeigen><de> 7 Zeichenfeld 8 TOTAL/REMAIN – Zeigt die momentan angezeigte Disc/Trackinformation an (Seite 14).
<G-vec00060-001-s981><indicate.anzeigen><en> 7 Character display 8 TOTAL/REMAIN – Indicate the disc/track information currently displayed (page 14).
<G-vec00060-001-s982><indicate.anzeigen><de> Die CE Markierung besagt nicht, dass ein Produkt in einem EWR Land hergestellt wurde, sie zeigt lediglich an, dass ein Produkt bewertet wurde, bevor es auf den Markt gebracht wird und somit die Rechtlichen Anforderungen innerhalb d er EU erfüllt.
<G-vec00060-001-s982><indicate.anzeigen><en> CE marking does not indicate that a product was made in the EEA, but merely states that the product is assessed before being placed on the market and thus meets the EU legislative requirements .
<G-vec00060-001-s983><indicate.anzeigen><de> Sollte dies der Fall sein, zeigt Ihnen der Server an, dass nur eine Teilmenge des Ergebnisses zurückgeliefert wurde.
<G-vec00060-001-s983><indicate.anzeigen><en> If this occurs, the server will indicate that it has only returned a partial results set.
<G-vec00060-001-s984><indicate.anzeigen><de> Während es in der Forschung weit verbreitet ist, zeigt dieses Kriterium nicht Empfindlichkeit oder Schwere, wenn es in den ersten drei Tagen nach Anfang verwendet wird an und ist deshalb häufig nicht klinisch nÃ1⁄4tzlich.
<G-vec00060-001-s984><indicate.anzeigen><en> While it is widely used in research, this criterion does not indicate survivability or severity when used in the first three days after onset and is therefore often not clinically useful.
<G-vec00060-001-s985><indicate.anzeigen><de> Halten Sie Ihren GyroTwister einfach an´s Mikrofon und unsere Software zeigt Ihnen die aktuelle Umdrehungszahl, den Kraftindex und natürlich auch den Highscore an.
<G-vec00060-001-s985><indicate.anzeigen><en> Once active, just hold your GyroTwister close to the microphone and our software will indicate the current number of rotations, the strength index and the high score.
<G-vec00060-001-s986><indicate.anzeigen><de> Der Druck auf den ganzen Körper würde einem Druck auf das ganze innere Bewusstsein gleich kommen, vielleicht mit dem Ziel einer Modifikation oder Wandlung, die es für Wissen oder Erfahrung empfänglicher machen würde; die dritte oder vierte Rippe zeigt einen Bereich an, welcher zur vitalen Natur gehört, den Bereich der Lebenskraft – einen Druck zu einer Wandlung dort.
<G-vec00060-001-s986><indicate.anzeigen><en> The pressure on the whole body would mean a pressure on the whole inner consciousness, perhaps for some modification or change which would make it more ready for knowledge or experience; the third or fourth rib would indicate a region which belongs to the vital nature, the domain of the life-force, some pressure for a change there.
<G-vec00060-001-s987><indicate.anzeigen><de> Der Mond als Symbol in der Vision zeigt meist Spiritualität im Mental an oder ganz einfach das spirituelle Bewusstsein.
<G-vec00060-001-s987><indicate.anzeigen><en> It can also indicate the flow of spiritual Ananda (nectar is in the moon according to the old tradition).
<G-vec00060-001-s988><indicate.anzeigen><de> Dieser Test zeigt nur das Vorhandensein von Strep A Antigenen von sowohl lebensfähigen als auch nicht-lebensfähigen Gruppe A Streptococcus-Bakterien in Proben an.
<G-vec00060-001-s988><indicate.anzeigen><en> This test will only indicate the presence of Strep A antigen in the specimen from both viable and non-viable Group A Streptococcus bacteria.
<G-vec00060-001-s989><indicate.anzeigen><de> Der Anzugsmechanismus des Schuhs gibt also zwei Töne aus und ein dritter zeigt an, dass die Batterie schwach ist.
<G-vec00060-001-s989><indicate.anzeigen><en> So the shoe's tightening mechanism emits two tones, and a third to indicate that the battery is low.
<G-vec00060-001-s990><indicate.anzeigen><de> Die Produkte von MSR-Electronic sichern die Kältemittel-Überwachung in geschlossenen Räumen, bei denen Leckagen vorkommen können und zeigt die mögliche erhöhte Gaskonzentration in Echtzeit an.
<G-vec00060-001-s990><indicate.anzeigen><en> The products of MSR-Electronic ensure refrigerant monitoring in closed rooms where leaks can occur and indicate the possible increased gas concentration in real time.
<G-vec00060-001-s991><indicate.anzeigen><de> Die klar ablesbare Digitalanzeige der Kamera zeigt an, ob die Kamera gerade ausgerichtet ist und ermöglicht die Feinanpassung der horizontalen Ausrichtung während der Aufnahme.
<G-vec00060-001-s991><indicate.anzeigen><en> The camera's digital level gauge uses easy-to-read graphics to indicate clearly whether the camera is level and enables fine adjustment of horizontal alignment during shooting.
<G-vec00060-001-s992><indicate.anzeigen><de> Zeigt bei stromführenden Kabeln die tatsächliche Spannung an.
<G-vec00060-001-s992><indicate.anzeigen><en> On energized wires, the meter will indicate the real voltage.
<G-vec00060-001-s993><indicate.anzeigen><de> Gebrauch von dieser Web site zeigt an, dass Sie damit einverstanden sind, durch die Ausdrücke gesprungen zu werden.
<G-vec00060-001-s993><indicate.anzeigen><en> Use of this Website will indicate that you agree to be bound by the Terms.
<G-vec00060-001-s994><indicate.anzeigen><de> Daher zeigt der anfängliche Temperaturanstieg nicht an, dass das Antibiotikum nicht geeignet ist.
<G-vec00060-001-s994><indicate.anzeigen><en> Therefore, the initial increase in temperature does not indicate that the antibiotic is not suitable.
<G-vec00230-002-s031><denounce.anzeigen><de> Ein Unternehmen, das ein Kartell, an dem es beteiligt ist, anzeigen möchte, kann den vollständigen Erlass der Geldbuße beantragen, wenn es als erstes Unternehmen Beweise für ein der Europäischen Kommission bis dahin unbekanntes Kartell vorlegt oder - falls die Kommission bereits von dem Kartell wusste - ihr als erstes Unternehmen entscheidende Beweise vorlegt, die die Feststellung des Kartells ermöglichen.
<G-vec00230-002-s031><denounce.anzeigen><en> A firm participating in a cartel which it wishes to denounce may request total immunity from fines if it is the first firm to provide evidence of a cartel hitherto unknown to the European Commission or, if the Commission is aware of the cartel, if the firm is the first to provide it with crucial information enabling it to establish its existence.
<G-vec00230-002-s032><denounce.anzeigen><de> Der springenden Punkt ist, dass selbst im Anzeigen des Falschen, im Bekämpfen des Bösen und in der Trauer über die Tragödien, wir gleichzeitig die negative Seite dieser Welt auf eine andere, wesentlichere Ebene erheben, indem wir ihren positiven Kern zurückgewinnen.
<G-vec00230-002-s032><denounce.anzeigen><en> The point is that even as we denounce falsehood, fight evil and mourn tragedy, we simultaneously engage the negativity in our world on another, more inner plane: by reclaiming its positive core. When we are faced with a lie we renounce it.
<G-vec00245-002-s076><appear.anzeigen><de> * Apps wie iTunes und das Festplattendienstprogramm können auch dann weiterhin auf den Datenträger zugreifen, wenn dieser nicht auf dem Schreibtisch oder im Finder angezeigt wird.
<G-vec00245-002-s076><appear.anzeigen><en> * Apps such as iTunes and Disk Utility can still access the disc, even if it doesn't appear on the desktop or in the Finder.
<G-vec00245-002-s077><appear.anzeigen><de> Warte, bis der Name deines Geräts angezeigt wird.
<G-vec00245-002-s077><appear.anzeigen><en> Wait for your device's name to appear.
<G-vec00245-002-s078><appear.anzeigen><de> Wenn das Symbol nicht in der Menüleiste angezeigt wird, öffnen Sie die Systemeinstellungen im Menü Apple.
<G-vec00245-002-s078><appear.anzeigen><en> If the icon does not appear in the menu bar at all, then choose System Preferences from the Apple menu.
<G-vec00245-002-s079><appear.anzeigen><de> Da in PSE die Miniatur der Filtermaske im Ebenen-Bedienfeld nicht angezeigt wird, ist es nicht einfach zu erkennen, welche Bereiche maskiert sind und welche nicht.
<G-vec00245-002-s079><appear.anzeigen><en> Since, in PSE, filter mask thumbnails don't appear in the Layers palette, we may not know which exactly parts are already masked and which are not.
<G-vec00245-002-s080><appear.anzeigen><de> Wenn es sich bei diesem Reiseziel um Ihre Stadt oder Region handelt, ist es wichtig, dass Ihre Unterkunft in den Suchergebnissen angezeigt wird.
<G-vec00245-002-s080><appear.anzeigen><en> When that destination is your city or region, you’re going to want to make sure you appear in their search results.
<G-vec00245-002-s081><appear.anzeigen><de> Hinweis: Wenn Autorun deaktiviert ist und das Roxio Retrieve-Fenster nicht angezeigt wird, können Sie Roxio Retrieve manuell starten, indem Sie auf die Datei Launch_Retrieve.exe auf der Disc doppelklicken.
<G-vec00245-002-s081><appear.anzeigen><en> Note: If Auto-run is disabled and the Roxio Retrieve window does not appear, you can manually start Roxio Retrieve by double-clicking the Launch_Retrieve.exe file included on the disc.
<G-vec00245-002-s082><appear.anzeigen><de> Das könnte dazu führen, dass die Datei als allgemeines Icon angezeigt wird, wenn sie innerhalb eines Ordners über WebDAV-Freigabe betrachtet wird, und nicht mit einer bestimmten Anwendung verknüpft wird.
<G-vec00245-002-s082><appear.anzeigen><en> This might cause the file to appear as a generic icon when viewed within a WebDAV shared folder, not having an association with any application.
<G-vec00245-002-s083><appear.anzeigen><de> Wir können Cookies ablegen, wenn Sie unsere Website oder die eines anderen Unternehmens besuchen, auf der unsere Werbung angezeigt wird, oder wenn Sie Einkäufe tätigen, Informationen anfordern oder personalisieren oder sich für bestimmte Dienstleistungen anmelden.
<G-vec00245-002-s083><appear.anzeigen><en> We may send cookies when you visit our website or websites where our ads appear or when you make purchases, request or personalize information, or register for certain services.
<G-vec00245-002-s084><appear.anzeigen><de> Sie müssen Windows PowerShell jedoch einmal starten, damit die Aufgabe Alle Module importieren angezeigt wird.
<G-vec00245-002-s084><appear.anzeigen><en> However, you must start Windows PowerShell one time to make the Import all modules task appear.
<G-vec00245-002-s085><appear.anzeigen><de> Als nächstes werden Sie die Möglichkeit haben, eine Startzeit für das Wasserzeichen zu wählen, so dass es erst am Ende des Videos angezeigt wird, oder Sie es für die gesamte Länge des Videos anzeigen wollen.
<G-vec00245-002-s085><appear.anzeigen><en> Next, you will have the option of choosing a start time for your watermark, making it appear only at the end of your video, or having it there for the entire length of your video.
<G-vec00245-002-s086><appear.anzeigen><de> Für ein vollständiges Dell Cinema Erlebnis: Aktualisieren Sie Ihren Bildschirm und erleben Sie Bilder, bei denen jedes Bit so lebendig angezeigt wird wie die Welt um uns herum.
<G-vec00245-002-s086><appear.anzeigen><en> Get the full Dell Cinema experience: Upgrade your screen to experience visuals that appear every bit as vibrant as the world around you.
<G-vec00245-002-s087><appear.anzeigen><de> Wenn das Programm nicht angezeigt wird, verwenden Sie die unter Bei erstmaliger Verwendung aufgeführten Links in der E-Mail-Einladung, um den Live Meeting-Client zu installieren.
<G-vec00245-002-s087><appear.anzeigen><en> If the program does not appear, use the links listed under First-Time Users in the e-mail invitation to install the meeting client.
<G-vec00245-002-s088><appear.anzeigen><de> Wenn das folgende Pop-up angezeigt wird, wählen Sie die Sicherung aus und klicken Sie auf die Schaltfläche "Wiederherstellen", um Kontakte auf Ihr Gerät abzurufen.
<G-vec00245-002-s088><appear.anzeigen><en> As the following pop-up would appear, select the backup and click on the “Restore” button to retrieve contacts to your device.
<G-vec00245-002-s089><appear.anzeigen><de> Mit dem Rollover-Bereich legen Sie die Position des Mauszeigers fest, bei der die Beschriftung oder das Bild angezeigt wird.
<G-vec00245-002-s089><appear.anzeigen><en> The rollover area defines where the mouse must be for the caption or image to appear.
<G-vec00245-002-s090><appear.anzeigen><de> Versuchen Sie, falls Ihr Drucker noch immer nicht angezeigt wird, ihn unter Verwendung seiner IP-Adresse hinzuzufügen (siehe unten).
<G-vec00245-002-s090><appear.anzeigen><en> If your printer still doesn’t appear in the list, try adding the printer by its IP address (see below).
<G-vec00245-002-s091><appear.anzeigen><de> Damit das Menü angezeigt wird, müssen Sie unter Umständen einmal irgendwo auf den Bildschirm tippen.
<G-vec00245-002-s091><appear.anzeigen><en> You might need to tap once anywhere on the screen for the menu to appear.
<G-vec00245-002-s092><appear.anzeigen><de> Wenn das Symbol Dialog nicht angezeigt wird, drücken Sie während der Wiedergabe Ihres Titels auf den Pfeil nach unten, um das Audio- und Untertitel-Menü zu öffnen.
<G-vec00245-002-s092><appear.anzeigen><en> If the Dialog icon does not appear, press the Down arrow while your TV show or movie is playing to open the audio and subtitle menu.
<G-vec00245-002-s093><appear.anzeigen><de> Wenn die NETGEAR-Website nicht innerhalb einer Minute angezeigt wird, lesen Sie Kapitel 2, Fehlerbehebung.
<G-vec00245-002-s093><appear.anzeigen><en> If the NETGEAR Web site does not appear within one minute, refer to Chapter 2, Troubleshooting.
<G-vec00245-002-s094><appear.anzeigen><de> Wenn der gewünschte Name nicht in der Liste Aktuellste Empfänger angezeigt wird, geben Sie den Namen oder den E-Mail-Alias in das Feld An, Optional oder Ressourcen ein.
<G-vec00245-002-s094><appear.anzeigen><en> If the name you want doesn't appear in the Most Recent Recipients list, type the name or email alias in the To, Optional, or Resources box.
<G-vec00276-002-s283><advertise.anzeigen><de> Pipol A/S nutzt Retargeting-Dienste, um Ihnen auf Webseiten Dritter Werbung anzuzeigen, nachdem Sie unseren Service besucht haben.
<G-vec00276-002-s283><advertise.anzeigen><en> Hallmark Properties uses remarketing services to advertise on third party websites to you after you visited our Service.
<G-vec00276-002-s284><advertise.anzeigen><de> Wir verwenden Adroll, um auf unserer Website und den Seiten Dritter, die von Nutzern besucht werden, die sich zuvor auf unserer Website aufgehalten haben, Werbung anzuzeigen.
<G-vec00276-002-s284><advertise.anzeigen><en> We use Adroll to advertise on our site and third party websites to previous visitors of our site.
<G-vec00276-002-s285><advertise.anzeigen><de> Zuhause Design, LLC setzt Wiedervermarktungsdienste ein, um Ihnen auf Websites Dritter Werbung anzuzeigen, nachdem Sie unseren Dienst besucht haben.
<G-vec00276-002-s285><advertise.anzeigen><en> Behavioral Remarketing PostNet-Champions TX121 uses remarketing services to advertise on third party websites to you after you visited our Service.
<G-vec00310-002-s095><view.anzeigen><de> Drücken Sie den Namen einer der Kategorien um Hintergrundbilder anzuzeigen.
<G-vec00310-002-s095><view.anzeigen><en> Press one of the categories to view wallpapers.
<G-vec00310-002-s096><view.anzeigen><de> Das Glossar ermöglicht es Ihnen, Glossareinträge zu suchen, anzuzeigen, zu erzeugen, zu editieren, zu löschen und zu veröffentlichen.
<G-vec00310-002-s096><view.anzeigen><en> The Dictionary allows you to search, view, create, edit, delete, and publish dictionary entries.
<G-vec00310-002-s097><view.anzeigen><de> Zu Wiederherstellen verlorener Dateien auf dem iPhone nach iOS 11 Update, dann können Sie zum linken Panel gehen und auf jede Kategorie klicken, um die Elemente einzeln anzuzeigen.
<G-vec00310-002-s097><view.anzeigen><en> To recover lost files on iPhone after iOS 11 update, then you can go to the left panel and click on each category to view the items one by one.
<G-vec00310-002-s098><view.anzeigen><de> Von hier, öffne deine Konsole und scroll über das Bild-Style-Tag, um die Pixel-Abmessungen deines Bildes anzuzeigen.
<G-vec00310-002-s098><view.anzeigen><en> From there, open up your console, and scroll over the img style tag to view the pixel dimensions of your artwork.
<G-vec00310-002-s099><view.anzeigen><de> Hinweis: Wenn sich eine Hülle aus gruppierten Pfaden zusammensetzt, klicken Sie im Ebenenbedienfeld links neben dem Eintrag „<Hülle>“ auf das Dreieck, um den zu bearbeitenden Pfad anzuzeigen und als Ziel auszuwählen.
<G-vec00310-002-s099><view.anzeigen><en> note: If your envelope consists of grouped paths, click the triangle to the left of the <Envelope> entry in the Layers panel to view and target the path you want to edit. Edit it as desired. Märkus.
<G-vec00310-002-s100><view.anzeigen><de> iMyFone iTransor Lite kann Ihnen helfen, Daten aus allen Backups in Ihrem iCloud-Konto ohne Probleme herunterzuladen und anzuzeigen.
<G-vec00310-002-s100><view.anzeigen><en> iMyFone iTransor Lite can help you download and view data from all backups in your iCloud account without any hassle.
<G-vec00310-002-s101><view.anzeigen><de> Wählen Sie Ihr Modelljahr aus den Optionen unten aus, um Ersatzteile und Anleitungen anzuzeigen.
<G-vec00310-002-s101><view.anzeigen><en> Select your model year from the options below to view parts & manuals.
<G-vec00310-002-s102><view.anzeigen><de> Sie können auf den Briefumschlag klicken, um eine Vorschau der neuesten Nachricht anzuzeigen, oder auf den Kalender, um Kalender- und Aufgabenerinnerungen anzuzeigen und zu verwalten.
<G-vec00310-002-s102><view.anzeigen><en> You can click the envelope to see a preview of the latest new message, or the calendar to view and manage calendar and task reminders.
<G-vec00310-002-s103><view.anzeigen><de> Wählen Sie dann den BIC-Code, es ist voller Details anzuzeigen.
<G-vec00310-002-s103><view.anzeigen><en> Then select the BIC code to view it's full details.
<G-vec00310-002-s104><view.anzeigen><de> Um die Karte anzuzeigen aktivieren Sie bitte JavaScript in Ihren Browser-Einstellungen.
<G-vec00310-002-s104><view.anzeigen><en> To use standard view, enable JavaScript by changing your browser options.
<G-vec00310-002-s105><view.anzeigen><de> Um Google Maps anzuzeigen, aktivieren Sie JavaScript in den Einstellungen Ihres Webbrowsers und versuchen Sie es erneut.
<G-vec00310-002-s105><view.anzeigen><en> To view Google Maps, enable JavaScript by changing your browser options, and then try Sipenmaru
<G-vec00310-002-s106><view.anzeigen><de> Um diese Seite anzuzeigen, benötigen Sie einen Browser, der Frames anzeigen kann.
<G-vec00310-002-s106><view.anzeigen><en> Oops! This document requires a browser that can view frames.
<G-vec00310-002-s107><view.anzeigen><de> Klicken Sie auf ein Bild, um es größer anzuzeigen.
<G-vec00310-002-s107><view.anzeigen><en> Click on any picture to view it larger.
<G-vec00310-002-s108><view.anzeigen><de> Es gibt drei Möglichkeiten, mit diesem Tool Ihre iMessages auf Ihrem Windows-PC anzuzeigen.
<G-vec00310-002-s108><view.anzeigen><en> There are three ways to use this tool to view your iMessages on your Windows PC.
<G-vec00310-002-s109><view.anzeigen><de> Klicken Sie unten, um unseren neuesten Katalog anzuzeigen.
<G-vec00310-002-s109><view.anzeigen><en> Click below to view our latest catalog.
<G-vec00310-002-s110><view.anzeigen><de> Klicken Sie auf die Hotspot-Einstellungen, um das Passwort anzuzeigen, das für den Zugriff auf den Wi-Fi-Hotspot im Fahrzeug erforderlich ist.
<G-vec00310-002-s110><view.anzeigen><en> Click on Hotspot settings to view the password required for accessing the in-car Wi-Fi Hotspot. Find out more
<G-vec00310-002-s111><view.anzeigen><de> Dies ist die extra-lite Version von Facebook, die Sie über den mobilen Browser laden können, und obwohl sie im Allgemeinen für leistungsschwache Telefone und Personen mit schlechten Mobilfunkverbindungen gedacht ist, ist sie auch der einzige Ort, an dem Sie nicht gezwungen werden, Facebook Messenger herunterzuladen, um Ihren Posteingang anzuzeigen oder auf Nachrichten zu antworten.
<G-vec00310-002-s111><view.anzeigen><en> This is the extra-lite version of Facebook that you can load through the mobile browser, and while generally intended for low-powered phones and people running on bad cell connections, it’s also the one place left that you won’t be forced into downloading Facebook Messenger in order to view your inbox or respond to any messages.
<G-vec00310-002-s112><view.anzeigen><de> Klicken Sie auf ein Druckermodell, um die Funktionen anzuzeigen, die von diesem Modell unterstützt werden.
<G-vec00310-002-s112><view.anzeigen><en> Click on a printer model to view the features that are supported by that model
<G-vec00310-002-s113><view.anzeigen><de> Bitte Javascript aktivieren, um die Händler deiner Region anzuzeigen, die Vorbestellungen anbieten.
<G-vec00310-002-s113><view.anzeigen><en> Please enable JavaScript to view the retailers accepting pre-orders in your region.
<G-vec00330-002-s032><reveal.anzeigen><de> Tippen Sie einfach auf die Schaltfläche "Gang" in der unteren rechten Ecke, um die Einstellungen anzuzeigen, und gehen Sie dann zu den Bildeinstellungen> Bild & Video> Wasserzeichen.
<G-vec00330-002-s032><reveal.anzeigen><en> Just tap the "gear” button in the lower right corner to reveal settings, and then go to Image Preferences > Image & Video > Watermarks.
<G-vec00330-002-s033><reveal.anzeigen><de> Klicken Sie auf die Dreiecke links neben den mitgelieferten Programmen, um die Wahlmöglichkeiten anzuzeigen.
<G-vec00330-002-s033><reveal.anzeigen><en> Click the disclosure triangle to the left of Bundled Applications to reveal the choices.
<G-vec00330-002-s034><reveal.anzeigen><de> Das Dashboard seiner Business-Intelligence-Lösung Power BI erweitert Microsoft um die Möglichkeiten, Trends und Angriffsmuster anzuzeigen sowie Empfehlungen und Sicherheitsalarme von überall zu filtern und zu visualisieren, Mobilgeräte eingeschlossen.
<G-vec00330-002-s034><reveal.anzeigen><en> Microsoft is adding the ability to use Power BI dashboard to reveal trends and attack patterns, as well as visualize and filter recommendations and security alerts from anywhere, including a mobile device.
<G-vec00330-002-s035><reveal.anzeigen><de> Der Spieler wählt eine Karte, um einen Topf in Bronze, Silber oder Gold anzuzeigen.
<G-vec00330-002-s035><reveal.anzeigen><en> The player selects a card to reveal a bronze, silver or gold pot.
<G-vec00330-002-s036><reveal.anzeigen><de> Um die in einer schmalen Bedienfeldgruppe ausgeblendeten Bedienfelder anzuzeigen, ziehen Sie die Bildlaufleiste über der Bedienfeldgruppe.
<G-vec00330-002-s036><reveal.anzeigen><en> To reveal panels hidden in a narrow panel group, drag the scroll bar above the panel group.
<G-vec00330-002-s037><reveal.anzeigen><de> Sie können einen Ordner öffnen, um seinen Inhalt anzuzeigen, und einen Ordner in einen anderen Ordner verschieben.
<G-vec00330-002-s037><reveal.anzeigen><en> You can expand a folder to reveal its contents, and put folders inside other folders.
<G-vec00330-002-s038><reveal.anzeigen><de> Sie können auch den Befehl Im Browser zeigen des [Rechts-Klick](PC) / [CTRL-Klick](Mac) Kontextmen√ľs verwenden, um die Sample-Datei im Browser anzuzeigen.
<G-vec00330-002-s038><reveal.anzeigen><en> You can also use the Show in Browser command in the right-click(PC) / CTRL-click(Mac) context menu to reveal the file in the browser.
<G-vec00330-002-s039><reveal.anzeigen><de> Achte auf: 3 + Scatters für den Freispiel-Modus, drehe das Rad um deine Spins anzuzeigen, erhalte zufällige Multiplikatoren bei jedem Spin und 2 weitere Scatters für Pyramid-Spins.
<G-vec00330-002-s039><reveal.anzeigen><en> In this game: 3+ scatters for the free spin mode, spin a wheel to reveal how many spins, during these a random multiplier is added on each spin & land 2 more scatters for Pyramid Spins.
<G-vec00330-002-s040><reveal.anzeigen><de> Wenn eine Marionette als Ebene hinzugefügt wird, können Sie die Ebene öffnen, um die Ebenen der hinzugefügten Marionette anzuzeigen, und die Ebenen der Marionette im Kontext der aktuellen Marionette ändern.
<G-vec00330-002-s040><reveal.anzeigen><en> When a puppet is added as a layer, you can twirl the layer open to reveal the layers inside that added puppet, and modify that puppet’s layers within the context of the current puppet.
<G-vec00330-002-s041><reveal.anzeigen><de> Klicken Sie auf den Pfeil neben dem Skalierungs-Steuerelement im Bewegungseffekt, um den Skalierungsregler anzuzeigen.
<G-vec00330-002-s041><reveal.anzeigen><en> Click the arrow next to the Scale control within the Motion effect to reveal the Scale slider.
<G-vec00330-002-s042><reveal.anzeigen><de> Dann alle übrigen Spieler beginnen, sich die Hände anzuzeigen.
<G-vec00330-002-s042><reveal.anzeigen><en> Then, all the remaining players begin to reveal their hands.
<G-vec00332-002-s019><notify.anzeigen><de> Hinweis: Sie können auch über das Preflight-Bedienfeld Meldungen zu veralteten und ungelösten Querverweisen anzeigen.
<G-vec00332-002-s019><notify.anzeigen><en> Poznámka: You can also use the Preflight panel to notify you when cross-references are out of date or unresolved.
<G-vec00332-002-s020><notify.anzeigen><de> Den deutschen Bestimmungen zufolge müssen Hersteller und Importeure pyrotechnische Gegenstände, die mit der CE-Kennzeichnung versehen sind, zusammen mit den dazugehörigen Gebrauchsanweisungen der Bundesanstalt für Materialprüfung (BAM) anzeigen, bevor sie diese in Deutschland in Verkehr bringen dürfen.
<G-vec00332-002-s020><notify.anzeigen><en> German legislation requires that manufacturers and importers notify CE marked pyrotechnic articles, together with their instructions for use, to the Federal Institute for Material Research and Testing (BAM), before their placing on the German market.
<G-vec00332-002-s021><notify.anzeigen><de> Wir können dem Schuldner die Abtretung anzeigen und/oder vom Käufer den Vermerk der Abtretung in seinen Büchern verlangen.
<G-vec00332-002-s021><notify.anzeigen><en> We have the right to notify the debtor of the assignment and/or to ask the buyer to record the assignment on his books.
<G-vec00332-002-s022><notify.anzeigen><de> (7) Falls die Ware aus einem der in Absatz 6 genannten Gründe nicht oder nicht rechtzeitig lieferbar ist, werden wir dies dem Kunden unverzüglich anzeigen.
<G-vec00332-002-s022><notify.anzeigen><en> (3) Should the goods not be deliverable or not be deliverable on time, we will immediately notify the Customer of such.
<G-vec00332-002-s023><notify.anzeigen><de> (5) Unternehmer müssen dem Verkäufer offensichtliche Mängel der gelieferten Ware innerhalb einer Frist von 2 Wochen ab Empfang der Ware anzeigen; andernfalls ist die Geltendmachung des Gewährleistungsanspruchs ausgeschlossen.
<G-vec00332-002-s023><notify.anzeigen><en> (5) Entrepreneurs must notify the seller of obvious defects concerning the delivered goods within a period of 2 weeks following receipt of the goods, otherwise the assertion of warranty claims is excluded.
<G-vec00332-002-s024><notify.anzeigen><de> Damit sie die Schutzrechte nach dem Mutterschutzgesetz in Anspruch nehmen können und die Universität entsprechende Schutzmaßnahmen ergreifen kann, sollen Studentinnen eine Schwangerschaft so früh wie möglich gegenüber der Universität anzeigen.
<G-vec00332-002-s024><notify.anzeigen><en> Students should notify the University of a pregnancy as soon as possible to ensure they enjoy their full protection rights pursuant to MuSchG and that the University can implement the necessary protection measures.
<G-vec00332-002-s025><notify.anzeigen><de> 12.2 Entdeckt der AG bei den vorgenannten Prüfungen einen Mangel, wird er diesen dem AN anzeigen.
<G-vec00332-002-s025><notify.anzeigen><en> 12.2 If the Customer detects any defect when carrying out the above inspections, it shall notify the Contractor of such.
<G-vec00332-002-s026><notify.anzeigen><de> (4) Der Besteller muss offensichtliche Mängel – soweit er kein Verbraucher ist – sofort, spätestens jedoch innerhalb einer Frist von 7 Tagen nach Empfang der Lieferware, schriftlich anzeigen.
<G-vec00332-002-s026><notify.anzeigen><en> (4) The customer shall notify us in writing of any apparent defect – if he is not a consumer – immediately, at the latest within 7 days after receipt of the delivery.
<G-vec00332-002-s027><notify.anzeigen><de> 19.2 Sie unterliegen den gültigen und auf unserer Webseite zum Zeitpunkt Ihrer Bestellung bei uns eingestellten Richtlinien und Allgemeinen Geschäftsbedingungen, soweit eine Änderung dieser Richtlinien oder Allgemeinen Geschäftsbedingungen nicht gesetzlich oder behördlich vorgeschrieben wird (in welchem Falle diese auch auf vorher von Ihnen getätigte Bestellungen angewandt werden wird), oder soweit wir Ihnen die Änderung der entsprechenden Richtlinen oder dieser Allgemeinen Geschäftsbedingungen anzeigen, bevor wir Ihnen die Lieferbestätigung schicken (in welchem Fall wir berechtigt sind, davon auszugehen, dass Sie der Änderung der Allgemeinen Geschäftsbedingungen zugestimmt haben, wenn Sie diesen nicht innerhalb von sieben Werktagen nach Erhalt des Waren von uns ausdrücklich widersprechen).
<G-vec00332-002-s027><notify.anzeigen><en> 21.2 You will be subject to the policies and terms and conditions in force at the time that you order products from us, unless any change to those policies or these terms and conditions is required to be made by law or governmental authority (in which case it will apply to orders previously placed by you), or if we notify you of the change to those policies or these terms and conditions before we send you the Acceptance Confirmation (in which case we have the right to assume that you have accepted the change to the terms and conditions, unless you notify us to the contrary within seven working days of receipt by you of the Products).
<G-vec00332-002-s028><notify.anzeigen><de> Derartige Verzögerungen wird die SOLO Lighting GmbH dem Käufer unverzüglich anzeigen.
<G-vec00332-002-s028><notify.anzeigen><en> SOLO Lighting GmbH will notify the buyer immediately of any such delays.
<G-vec00332-002-s029><notify.anzeigen><de> ORdigiNAL wird dem Auftraggeber die Fertigstellung der Leistungen anzeigen (“Fertigstellungsanzeige”).
<G-vec00332-002-s029><notify.anzeigen><en> ORdigiNAL shall notify Company upon completion of the Services (“Notification of Completion”).
<G-vec00332-002-s031><notify.anzeigen><de> Offene Mängel werden wir dem Lieferanten unverzüglich schriftlich, spätestens jedoch innerhalb von 10 Werktagen nach Eingang der Lieferung bei uns anzeigen.
<G-vec00332-002-s031><notify.anzeigen><en> We shall notify the supplier of obvious defects immediately in writing, but no later than within 10 working days of receipt of the delivery by us.
<G-vec00332-002-s032><notify.anzeigen><de> Sollte ein Ticketkäufer mit der Bezahlung des/der gekauften Tickets in Rückstand geraten oder eine für den Kauf getätigte Überweisung zurückrufen, so wird Silverdust uns die Zahlungsforderung gegen den jeweiligen Ticketkäufer abtreten und die Abtretung gegenüber dem Ticketkäufer anzeigen.
<G-vec00332-002-s032><notify.anzeigen><en> If a ticket buyer falls into arrears regarding the payment of the ticket(s) concerned, or cancels a bank transfer for payment of the ticket(s), Silverdust shall assign to us the payment claim against the ticket buyer and notify that ticket buyer that such assignment has taken place.
<G-vec00337-002-s026><prompt.anzeigen><de> Es wird ein neues Fenster angezeigt, in dem Sie einen Namen und ein Passwort eingeben müssen.
<G-vec00337-002-s026><prompt.anzeigen><en> A new window will prompt for a Name and Password.
<G-vec00337-002-s027><prompt.anzeigen><de> Falls sich der Preis eines Fahrzeuges während des Parkens ändert, wird dies direkt angezeigt.
<G-vec00337-002-s027><prompt.anzeigen><en> The system will instantly prompt whenever the price of the 'earmarked' machine changes.
<G-vec00337-002-s028><prompt.anzeigen><de> Hier sollte eine Beschreibung angezeigt werden, diese Seite lässt dies jedoch nicht zu.
<G-vec00337-002-s028><prompt.anzeigen><en> Page Prompt message Page Prompt message: 404: This page does not exist!
<G-vec00337-002-s029><prompt.anzeigen><de> Wenn Sie darauf klicken, wird ein Menü mit den optionalen Nodes angezeigt.
<G-vec00337-002-s029><prompt.anzeigen><en> Clicking the prompt displays a menu of the optional nodes.
<G-vec00337-002-s030><prompt.anzeigen><de> Es wird dann der folgende Anmeldebildschirm angezeigt: Bild 6: Anmeldebildschirm der iRMC S2/S3-Web-Oberfläche I Falls der Anmeldebildschirm nicht angezeigt wird, überprüfen Sie die LAN-Verbindung (siehe Abschnitt "LAN-Schnittstelle testen" auf Seite 49).
<G-vec00337-002-s030><prompt.anzeigen><en> The following login prompt appears: Figure 6: Login prompt for the iRMC S2/S3 web interface I If the login prompt does not appear, check the LAN connection (see section "Testing the LAN interface" on page 47).
<G-vec00337-002-s031><prompt.anzeigen><de> Wenn du eine neue Liste erstellst oder eine bestehende lädst, dann wird ein Bestätigungsdialog angezeigt, um die aktuelle Liste zu speichern.
<G-vec00337-002-s031><prompt.anzeigen><en> If you create a new list or load an existing one, you will see a confirmation prompt to save your current list.
<G-vec00347-002-s019><sue.anzeigen><de> Ihre Familie wies darauf hin, dass sie die Polizeibehörde und die Staatsanwaltschaft anzeigen würde.
<G-vec00347-002-s019><sue.anzeigen><en> Ms. Wang's family members indicated that they would sue the police station and the prosecutor's office.
<G-vec00347-002-s020><sue.anzeigen><de> Sollte ich ihn nicht anzeigen?“ Er erklärte den Polizisten und dem Sicherheitschef die wahren Umstände der Verfolgung und dass sie rechtswidrig sei.
<G-vec00347-002-s020><sue.anzeigen><en> Shouldn't I sue him?” He went on to tell the police and the security chief the facts behind the persecution and how it was illegal.
<G-vec00354-002-s058><show.anzeigen><de> Klicke in der Buchungsbestätigungs-E-Mail auf den Link "Reservierung stornieren", um deine Online-Reservierung anzuzeigen.
<G-vec00354-002-s058><show.anzeigen><en> In the booking confirmation email, click on the "Cancel reservation" link that will show you your online reservation.
<G-vec00354-002-s059><show.anzeigen><de> Dank dieser Anwendung ist es auch möglich, Bilder oder Videos auf dem Tablet anzuzeigen, Sounds auf dem Roboter abzuspielen oder eine Vorschau dessen zu sehen, was der Roboter durch seine Kamera sieht.
<G-vec00354-002-s059><show.anzeigen><en> It is also possible, thanks to this application, to show images or videos on the tablet, to play sounds on the robot, or to have a glimpse of what the robot perceives through its camera.
<G-vec00354-002-s060><show.anzeigen><de> Drücke den Knopf am Anfang des Korridors (einmal) um die richtige Richtung anzuzeigen (>).
<G-vec00354-002-s060><show.anzeigen><en> Push the button in the beginning of the corridor once to make it show the right direction (>).
<G-vec00354-002-s061><show.anzeigen><de> Als nächstes werde ich dann versuchen, solch eine Landschaft auf dem iPod touch anzuzeigen.
<G-vec00354-002-s061><show.anzeigen><en> Next, I’ll try to get such a landscape to show up on my iPod touch.
<G-vec00354-002-s062><show.anzeigen><de> Um unseren Standort anzuzeigen und eine Anfahrtsbeschreibung zu erstellen, werden Ihre Nutzereinstellungen und -daten verarbeitet.
<G-vec00354-002-s062><show.anzeigen><en> To show our location and enable directions to be calculated, your user settings and data are processed.
<G-vec00354-002-s063><show.anzeigen><de> Der AM Part Identifier analysiert dann die Metadaten jedes Bauteils, um Ihnen automatisch die Top-Business Cases für die additive Fertigung anzuzeigen.
<G-vec00354-002-s063><show.anzeigen><en> The AM Part Identifier will then analyze every part’s metadata to show you the top business cases for additive manufacturing automatically.
<G-vec00354-002-s064><show.anzeigen><de> Es aktiviert nicht das Theme, sondern ermöglicht, es im Menü der Website unter Design anzuzeigen.
<G-vec00354-002-s064><show.anzeigen><en> It does not activate the theme, but allows it to show in the site’s Appearance menu.
<G-vec00354-002-s065><show.anzeigen><de> Um nur die für ein bestimmtes Produkt gewählten Farben anzuzeigen, sollte auf dieses Produkt gefiltert werden oder "Produkte" als Dimension hinzugefügt werden.
<G-vec00354-002-s065><show.anzeigen><en> To only show colors for a specific product, you should filter on this product or alternatively add the dimension "products".
<G-vec00354-002-s066><show.anzeigen><de> Nicht autorisierte Kanäle anzeigen: Wählen Sie diese Option, um die Kanäle anzuzeigen, für die der Benutzer keine Überwachungsrechte besitzt.
<G-vec00354-002-s066><show.anzeigen><en> Display unauthorized channels: Select this option to show the channels that the user does not have the right to monitor.
<G-vec00354-002-s067><show.anzeigen><de> Setzen Sie diese Eigenschaft auf true, um importierte Elemente in der XBRL-Dokumentation anzuzeigen.
<G-vec00354-002-s067><show.anzeigen><en> Set this property to true, to show imported elements in the XBRL documentation.
<G-vec00354-002-s068><show.anzeigen><de> Die Layouts können geändert werden, um Tag, Woche oder Monat anzuzeigen.
<G-vec00354-002-s068><show.anzeigen><en> Views can also be changed to show the day, week, or month.
<G-vec00354-002-s069><show.anzeigen><de> Das Tracking zur Optimierung der Anzeige von Werbung hat den Zweck, den Nutzern auf ihre Interessen zugeschnittene Werbung anzuzeigen, den Erfolg der Werbung und dadurch auch die Werbeerlöse zu erhöhen.
<G-vec00354-002-s069><show.anzeigen><en> The purpose of tracking to optimize the display of advertising is to show users advertising tailored to their interests, to increase the success of advertising and thus also advertising revenues.
<G-vec00354-002-s070><show.anzeigen><de> Hinweis: Das Layout „Reduzierbare Spalten“ ist zwar für Mobilgeräte optimiert, funktioniert aber auch auf Desktops, wenn nicht genug Platz verfügbar ist, um alle Spalten in einer Tabelle anzuzeigen.
<G-vec00354-002-s070><show.anzeigen><en> Note: While Collapsible column layout is optimized for mobile devices, it will work on desktop as well, if the width available is not enough to show all the columns in a table.
<G-vec00354-002-s071><show.anzeigen><de> Kategorien und Statusmeldungen erscheinen in einer Liste zusammen mit der Möglichkeit, den Status anzuzeigen und zu versenden.
<G-vec00354-002-s071><show.anzeigen><en> Categories and statutes are shown in a list with two options Show and Send the status.
<G-vec00354-002-s072><show.anzeigen><de> NetSpot ist ein vielseitiges Tool für WLAN-Standortgutachten, WLAN-Analyse und Fehlerbehebung für macOS und Windows, das auch zur WLAN-Kanalanalyse verwendet werden kann, um die Überlappung von WLAN-Kanälen anzuzeigen.
<G-vec00354-002-s072><show.anzeigen><en> NetSpot is a versatile WiFi site survey, WiFi analysis, and troubleshooting tool for macOS and Windows that can also be used as a WiFi channel analyzer to show WiFi channel overlap.
<G-vec00354-002-s073><show.anzeigen><de> Indem Sie die Option Berichtszeit wählen, können Sie die Serie einschränken oder auswählen, nur Ergebnisse einer spezifischen Zeitperiode im Bericht anzuzeigen.
<G-vec00354-002-s073><show.anzeigen><en> can be set in the report and used to show only specific results/answers of your survey (based on a certain group, time/date of answer or similar).
<G-vec00354-002-s074><show.anzeigen><de> Um detaillierte Angaben passend zu Ihrem Fahrzeug anzuzeigen, wählen Sie bitte noch das Modell und die Modellvariante aus.
<G-vec00354-002-s074><show.anzeigen><en> In order to show detail specifications for your vehicle, please select the model and the version of Detailed Article Group
<G-vec00354-002-s075><show.anzeigen><de> Dies kann bedeuten, dass deren Services auf unserer Webseite / unseren Apps integriert werden; dass sie die Möglichkeit haben, Ihnen auf unserer Seite ein individuelles Angebot anzuzeigen; oder dass der Online-Buchungsservice von Booking.com auf deren Webseite und/oder deren Apps integriert wird.
<G-vec00354-002-s075><show.anzeigen><en> This may mean that their services are integrated into our website or they have been enabled to show a customised advertisement on our website – or we are advertising on theirs.
<G-vec00381-002-s076><appear.anzeigen><de> * Apps wie iTunes und das Festplattendienstprogramm können auch dann weiterhin auf den Datenträger zugreifen, wenn dieser nicht auf dem Schreibtisch oder im Finder angezeigt wird.
<G-vec00381-002-s076><appear.anzeigen><en> * Apps such as iTunes and Disk Utility can still access the disc, even if it doesn't appear on the desktop or in the Finder.
<G-vec00211-003-s057><see_to.anzeigen><de> Um den Fülltext anzuzeigen, wählen Sie die Option „Fülltext“ im Hilfslinienbedienfeld aus.
<G-vec00211-003-s057><see_to.anzeigen><en> To see filler text, select the Filler Text option in the Guides panel.
<G-vec00211-003-s058><see_to.anzeigen><de> Sie können auf die Registerkarte Veröffentlichen klicken, um die neu gestalteten Seiten anzuzeigen, die in Ihrer Sandbox-Domain veröffentlicht wurden.
<G-vec00211-003-s058><see_to.anzeigen><en> You can click the Publish tab to see redesigned pages that have been published on your sandbox domain.
<G-vec00211-003-s059><see_to.anzeigen><de> Geben Sie die Anzahl der Million Gallonen pro Tag (US-Flüssigkeit) ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec00211-003-s059><see_to.anzeigen><en> Type the number of Bushels per year (U.S.) you want to convert in the text box, to see the results in the table.
<G-vec00211-003-s060><see_to.anzeigen><de> Um anzuzeigen, welche Widgets für Ihr eingetragenes Unternehmen oder Reiseziel verfügbar sind, besuchen Sie Ihre Widget-Zentrale.
<G-vec00211-003-s060><see_to.anzeigen><en> To see what widgets are available to your listed business or destination, please visit your Widget Center.
<G-vec00211-003-s061><see_to.anzeigen><de> Geben Sie die Anzahl der Rotation ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec00211-003-s061><see_to.anzeigen><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec00211-003-s062><see_to.anzeigen><de> Sie können auf den Briefumschlag klicken, um eine Vorschau der neuesten Nachricht anzuzeigen, oder auf den Kalender, um Kalender- und Aufgabenerinnerungen anzuzeigen und zu verwalten.
<G-vec00211-003-s062><see_to.anzeigen><en> You can click the envelope to see a preview of the latest new message, or the calendar to view and manage calendar and task reminders.
<G-vec00211-003-s063><see_to.anzeigen><de> Geben Sie die Anzahl der kcal ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec00211-003-s063><see_to.anzeigen><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec00211-003-s064><see_to.anzeigen><de> Verwenden Sie die Widgets Nicht richtlinientreue Geräte und Installierte Apps, um die Geräte anzuzeigen, auf denen keine mobilen Citrix Produktivitätsapps installiert sind.
<G-vec00211-003-s064><see_to.anzeigen><en> Use the Out of Compliance Devices and Installed Apps widgets to see the devices that do not have Citrix mobile productivity apps installed.
<G-vec00211-003-s065><see_to.anzeigen><de> Führen Sie einen Bildlauf nach unten durch, um die Option Land/Region für Ihr Konto anzuzeigen.
<G-vec00211-003-s065><see_to.anzeigen><en> Scroll down to see the Country/Region for your account.
<G-vec00211-003-s066><see_to.anzeigen><de> Wählen Sie Planner-Hub aus, um in Planner alle Pläne anzuzeigen, an denen Sie gerade arbeiten.
<G-vec00211-003-s066><see_to.anzeigen><en> Select Planner hub to see all of the plans you're working on in Planner.
<G-vec00211-003-s067><see_to.anzeigen><de> Anmeldung oder Registrieren um den Standort dieses Hauses auf einer Karte anzuzeigen.
<G-vec00211-003-s067><see_to.anzeigen><en> Taxi. Login or Register to see this home's location on a map.
<G-vec00211-003-s068><see_to.anzeigen><de> Tippen Sie auf das Menü-Symbol, um die verfügbaren Optionen anzuzeigen.
<G-vec00211-003-s068><see_to.anzeigen><en> Press the Menu button to see available options.
<G-vec00211-003-s069><see_to.anzeigen><de> Zeigen Sie in der Nachrichtenliste auf die Nachricht, oder wählen Sie die Nachricht aus, um die Option zum Kennzeichnen anzuzeigen.
<G-vec00211-003-s069><see_to.anzeigen><en> In the message list, hover over the message or select it to see the flag option.
<G-vec00211-003-s070><see_to.anzeigen><de> Wir empfehlen Ihnen, Ihren Browser zu aktualisieren (Internet Explorer 9 oder höher), um die Seite korrekt anzuzeigen.
<G-vec00211-003-s070><see_to.anzeigen><en> You must update your browser (Internet Explorer 9 or higher) to see this site properly.
<G-vec00211-003-s071><see_to.anzeigen><de> Klicken Sie auf das Dock-Symbol für Ihren Drucker, um die Druckermeldung anzuzeigen.
<G-vec00211-003-s071><see_to.anzeigen><en> Click your printer's Dock icon to see the printer message.
<G-vec00211-003-s072><see_to.anzeigen><de> Klicken Sie auf einen Ansatz, um eine Liste der Titel anzuzeigen, in denen dieser Therapieansatz demonstriert wird.
<G-vec00211-003-s072><see_to.anzeigen><en> Click any approach to see a list of the titles that demonstrate that therapeutic approach.
<G-vec00211-003-s073><see_to.anzeigen><de> Um alle Eigenschaften anzuzeigen, klicken Sie auf den Erweiterungspfeil in der unteren rechten Ecke des Eigenschafteninspektors.
<G-vec00211-003-s073><see_to.anzeigen><en> To see all properties, click the expander arrow in the lower-right corner of the Property inspector.
<G-vec00211-003-s074><see_to.anzeigen><de> Klicken Sie hier um den Code anzuzeigen, der die Pfade ändert.
<G-vec00211-003-s074><see_to.anzeigen><en> Click here to see the code that changes the paths.
<G-vec00211-003-s075><see_to.anzeigen><de> Gehen Sie auf "Cash", um zunächst unser Angebot an Ring Games anzuzeigen.
<G-vec00211-003-s075><see_to.anzeigen><en> Go to 'Cash' to see our Ring Game offer first.
<G-vec00402-002-s057><see.anzeigen><de> Um den Fülltext anzuzeigen, wählen Sie die Option „Fülltext“ im Hilfslinienbedienfeld aus.
<G-vec00402-002-s057><see.anzeigen><en> To see filler text, select the Filler Text option in the Guides panel.
<G-vec00402-002-s058><see.anzeigen><de> Sie können auf die Registerkarte Veröffentlichen klicken, um die neu gestalteten Seiten anzuzeigen, die in Ihrer Sandbox-Domain veröffentlicht wurden.
<G-vec00402-002-s058><see.anzeigen><en> You can click the Publish tab to see redesigned pages that have been published on your sandbox domain.
<G-vec00402-002-s059><see.anzeigen><de> Geben Sie die Anzahl der Million Gallonen pro Tag (US-Flüssigkeit) ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec00402-002-s059><see.anzeigen><en> Type the number of Bushels per year (U.S.) you want to convert in the text box, to see the results in the table.
<G-vec00402-002-s060><see.anzeigen><de> Um anzuzeigen, welche Widgets für Ihr eingetragenes Unternehmen oder Reiseziel verfügbar sind, besuchen Sie Ihre Widget-Zentrale.
<G-vec00402-002-s060><see.anzeigen><en> To see what widgets are available to your listed business or destination, please visit your Widget Center.
<G-vec00402-002-s061><see.anzeigen><de> Geben Sie die Anzahl der Rotation ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec00402-002-s061><see.anzeigen><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec00402-002-s062><see.anzeigen><de> Sie können auf den Briefumschlag klicken, um eine Vorschau der neuesten Nachricht anzuzeigen, oder auf den Kalender, um Kalender- und Aufgabenerinnerungen anzuzeigen und zu verwalten.
<G-vec00402-002-s062><see.anzeigen><en> You can click the envelope to see a preview of the latest new message, or the calendar to view and manage calendar and task reminders.
<G-vec00402-002-s063><see.anzeigen><de> Geben Sie die Anzahl der kcal ein, die Sie in das Textfeld umwandeln möchten, um die Ergebnisse in der Tabelle anzuzeigen.
<G-vec00402-002-s063><see.anzeigen><en> Type the number of Rotation you want to convert in the text box, to see the results in the table.
<G-vec00402-002-s064><see.anzeigen><de> Verwenden Sie die Widgets Nicht richtlinientreue Geräte und Installierte Apps, um die Geräte anzuzeigen, auf denen keine mobilen Citrix Produktivitätsapps installiert sind.
<G-vec00402-002-s064><see.anzeigen><en> Use the Out of Compliance Devices and Installed Apps widgets to see the devices that do not have Citrix mobile productivity apps installed.
<G-vec00402-002-s065><see.anzeigen><de> Führen Sie einen Bildlauf nach unten durch, um die Option Land/Region für Ihr Konto anzuzeigen.
<G-vec00402-002-s065><see.anzeigen><en> Scroll down to see the Country/Region for your account.
<G-vec00402-002-s066><see.anzeigen><de> Wählen Sie Planner-Hub aus, um in Planner alle Pläne anzuzeigen, an denen Sie gerade arbeiten.
<G-vec00402-002-s066><see.anzeigen><en> Select Planner hub to see all of the plans you're working on in Planner.
<G-vec00402-002-s067><see.anzeigen><de> Anmeldung oder Registrieren um den Standort dieses Hauses auf einer Karte anzuzeigen.
<G-vec00402-002-s067><see.anzeigen><en> Taxi. Login or Register to see this home's location on a map.
<G-vec00402-002-s068><see.anzeigen><de> Tippen Sie auf das Menü-Symbol, um die verfügbaren Optionen anzuzeigen.
<G-vec00402-002-s068><see.anzeigen><en> Press the Menu button to see available options.
<G-vec00402-002-s069><see.anzeigen><de> Zeigen Sie in der Nachrichtenliste auf die Nachricht, oder wählen Sie die Nachricht aus, um die Option zum Kennzeichnen anzuzeigen.
<G-vec00402-002-s069><see.anzeigen><en> In the message list, hover over the message or select it to see the flag option.
<G-vec00402-002-s070><see.anzeigen><de> Wir empfehlen Ihnen, Ihren Browser zu aktualisieren (Internet Explorer 9 oder höher), um die Seite korrekt anzuzeigen.
<G-vec00402-002-s070><see.anzeigen><en> You must update your browser (Internet Explorer 9 or higher) to see this site properly.
<G-vec00402-002-s071><see.anzeigen><de> Klicken Sie auf das Dock-Symbol für Ihren Drucker, um die Druckermeldung anzuzeigen.
<G-vec00402-002-s071><see.anzeigen><en> Click your printer's Dock icon to see the printer message.
<G-vec00402-002-s072><see.anzeigen><de> Klicken Sie auf einen Ansatz, um eine Liste der Titel anzuzeigen, in denen dieser Therapieansatz demonstriert wird.
<G-vec00402-002-s072><see.anzeigen><en> Click any approach to see a list of the titles that demonstrate that therapeutic approach.
<G-vec00402-002-s073><see.anzeigen><de> Um alle Eigenschaften anzuzeigen, klicken Sie auf den Erweiterungspfeil in der unteren rechten Ecke des Eigenschafteninspektors.
<G-vec00402-002-s073><see.anzeigen><en> To see all properties, click the expander arrow in the lower-right corner of the Property inspector.
<G-vec00402-002-s074><see.anzeigen><de> Klicken Sie hier um den Code anzuzeigen, der die Pfade ändert.
<G-vec00402-002-s074><see.anzeigen><en> Click here to see the code that changes the paths.
<G-vec00402-002-s075><see.anzeigen><de> Gehen Sie auf "Cash", um zunächst unser Angebot an Ring Games anzuzeigen.
<G-vec00402-002-s075><see.anzeigen><en> Go to 'Cash' to see our Ring Game offer first.
<G-vec00488-002-s032><designate.anzeigen><de> Standardmäßig wird Ihre Teilnahme an eine der Lotterien durch die Abonnement-Service auf dem Formular Zahlen beruhen, die Sie anzeigen wenn Sie die Teilnahme an dem Abo Service ("Abonnement-Form-Zahlen") beginnen .
<G-vec00488-002-s032><designate.anzeigen><en> By default, your participation in any of the Lotteries through the Subscription Service will be based on the Form numbers that you designate when you commence participating in the Subscription Service ("Subscription Form Numbers").
<G-vec00507-002-s057><list.anzeigen><de> Wenn Sie Plaza de la Aduana mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s057><list.anzeigen><en> If you're visiting Aduana Square, Cartagena with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s058><list.anzeigen><de> Wenn Sie Queenscliff Beach mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s058><list.anzeigen><en> If you're visiting Queenscliff Beach, Manly with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s059><list.anzeigen><de> Wenn Sie Pairc Ui Chaoimh mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s059><list.anzeigen><en> If you're visiting Pairc Ui Chaoimh, Cork with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s060><list.anzeigen><de> Wenn Sie Head's Beach mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s060><list.anzeigen><en> If you're visiting Head's Beach with the family or in a large group, don't forget to check out the room options and facilities we list for each hotel to ensure you get the right type of accommodation for your needs.
<G-vec00507-002-s061><list.anzeigen><de> Wenn Sie ORF-Funkhaus Wien mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s061><list.anzeigen><en> If you're visiting ORF Broadcasting House Vienna with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s062><list.anzeigen><de> Wenn Sie Weingut La Vinyeta mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s062><list.anzeigen><en> If you're visiting Puerta del Sol with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s063><list.anzeigen><de> Wenn Sie Plage des Sables-Blancs mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s063><list.anzeigen><en> If you're visiting Plage des Quatre Vaux with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s064><list.anzeigen><de> Wenn Sie Kewarra Beach mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s064><list.anzeigen><en> If you're visiting Kewarra Beach, Kewarra Beach with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s065><list.anzeigen><de> Wenn Sie Hafen von Palma de Mallorca mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s065><list.anzeigen><en> If you're visiting Port of Palma de Mallorca with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s066><list.anzeigen><de> Wenn Sie Palazzo Giordano mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s066><list.anzeigen><en> If you're visiting Palazzo Olginati with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s067><list.anzeigen><de> Wenn Sie Glicorisa Strand mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s067><list.anzeigen><en> If you're visiting Glicorisa Beach with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s068><list.anzeigen><de> Wenn Sie See Tota mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s068><list.anzeigen><en> If you're visiting Lake Tohopekaliga with the family or in a large group, don't forget to check out the room options and facilities we list for each hotel to ensure you get the right type of accommodation for your needs.
<G-vec00507-002-s069><list.anzeigen><de> Wenn Sie Chicago Water Tower mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s069><list.anzeigen><en> If you're visiting Chicago Water Tower with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s070><list.anzeigen><de> Wenn Sie Hole-in-the-Wall mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s070><list.anzeigen><en> If you're visiting Hole-in-the-Wall, Mgxotyeni with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s071><list.anzeigen><de> Wenn Sie Strand Eskibag mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s071><list.anzeigen><en> If you're visiting Yorukali Plaji with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s072><list.anzeigen><de> Wenn Sie Manchester Arena mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s072><list.anzeigen><en> If you're visiting Manchester Arena, Manchester with the family or in a group, be sure to check out the room options and facilities we list for each hotel to ensure we help find the perfect hotel for you.
<G-vec00507-002-s073><list.anzeigen><de> Wenn Sie Shaw Ocean Discovery Centre mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s073><list.anzeigen><en> If you're visiting Shaw Ocean Discovery Centre with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s074><list.anzeigen><de> Wenn Sie Massachusetts State House mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s074><list.anzeigen><en> If you're visiting Massachusetts State House with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00507-002-s075><list.anzeigen><de> Wenn Sie Wilhelmina Park mit der Familie oder in einer Gruppe besuchen, sollten Sie die Zimmeroptionen und Ausstattungsmerkmale überprüfen, die wir für jedes Hotel anzeigen, um Ihnen die Wahl des richtigen Hotels zu erleichtern.
<G-vec00507-002-s075><list.anzeigen><en> If you're visiting Wilhelmina Park with the family or in a large group, be sure to check out the room options and facilities we list for each hotel to ensure we help find you the perfect hotel.
<G-vec00141-002-s019><display.anzeigen><de> Mithilfe der Standorte der einzelnen Hotels, die deutlich um Rotes Rathaus herum angezeigt werden, können Sie Ihre Suche innerhalb von Śródmieście oder West Pomeranian Voivodeship einschränken, basierend auf anderen Sehenswürdigkeiten in der Nähe und Stadtvierteln sowie Transportoptionen.
<G-vec00141-002-s019><display.anzeigen><en> Our maps are based on hotel search and display areas and neighborhoods of each hotel so you can see how close you are from Red Town Hall and refine your search within Srodmiescie or West Pomeranian Voivodeship based on closest public transportation, restaurants and entertainment so you can easily get around the city.
<G-vec00141-002-s020><display.anzeigen><de> Es könnte sein, dass die BullionVault-Webseite nicht vollständig angezeigt ist, sie wird aber trotzdem funktionieren.
<G-vec00141-002-s020><display.anzeigen><en> The BullionVault website may not display properly, but the site will still be functional.
<G-vec00141-002-s021><display.anzeigen><de> Wird die Datei report.csv für einen Aktivitätsbericht in Microsoft Excel geöffnet, so werden chinesische Zeichen nicht korrekt angezeigt, obwohl die Datei report.csv korrekt konfiguriert wurde.
<G-vec00141-002-s021><display.anzeigen><en> When a report.csv file for an activity report is opened in Excel, Chinese characters do not display correctly, even though the report.csv file has been created correctly by default because Excel always reads the file using the ISO Latin character set.
<G-vec00141-002-s022><display.anzeigen><de> Webseiten, die PPC-Anzeigen nutzen, werden angezeigt, wenn eine Keyword-Suchanfrage, mit der Keyword-Liste eines Inserenten übereinstimmt; oder wenn eine Content-Webseite relevante Inhalte anzeigt.
<G-vec00141-002-s022><display.anzeigen><en> Websites that utilize PPC ads will display an advertisement when a keyword query matches an advertiser's keyword list, or when a content site displays relevant content.
<G-vec00141-002-s023><display.anzeigen><de> Die eingehende Rufnummer wird unter Umständen nicht richtig angezeigt.
<G-vec00141-002-s023><display.anzeigen><en> It may not be available to display the incoming call number correctly.
<G-vec00141-002-s024><display.anzeigen><de> Nur dein Vorname, dein Benutzername, dein Alter und dein Geschlecht werden später öffentlich angezeigt.
<G-vec00141-002-s024><display.anzeigen><en> We will only display your firstname, username, age and your gender publicly.
<G-vec00141-002-s025><display.anzeigen><de> Schaltet man seinen Hauptbildschirm beispielsweise aus, können im Second Screen über einen bestimmten Modus das Wetter, die Batterielaufzeit, das Datum und die Uhrzeit angezeigt werden.
<G-vec00141-002-s025><display.anzeigen><en> Dubbed Second Screen, the smaller display can be set to “always on” to display the time, weather, date and battery icon when the primary display is off.
<G-vec00141-002-s026><display.anzeigen><de> Alle Tastaturkurzbefehle, die diesem Befehl oder Element zugewiesen sind, werden im Feld Aktuelle Schlüssel angezeigt.
<G-vec00141-002-s026><display.anzeigen><en> Any keyboard shortcuts that are assigned currently to that command or item will display in the Current keys box.
<G-vec00141-002-s027><display.anzeigen><de> Der Browser unterstuetzt keine Inlineframes oder ist aktuell so konfiguriert, dass Inlineframes nicht angezeigt werden.
<G-vec00141-002-s027><display.anzeigen><en> Kaart Your browser does not support inline frames or is currently configured not to display inline frames.
<G-vec00141-002-s028><display.anzeigen><de> Ein Fehler wurde behoben, der dazu führte, dass für verschiedene Zauber, unter anderem Tornado, Arkaner Schild und am häufigsten Strudel, manchmal keine Grafik angezeigt wurde.
<G-vec00141-002-s028><display.anzeigen><en> Fixed a bug that caused several spells, including Tornado, Arcane Shield, and most frequently Whirlpool, to sometimes fail to display any graphics.
<G-vec00141-002-s029><display.anzeigen><de> Wenn die Windows-Anzeigesprache noch auf Englisch festgelegt ist, wird die Titelleiste weiterhin in Englisch angezeigt, und die Schaltflächen Schließen, Minimieren und Maximieren werden weiterhin in der rechten oberen Ecke angezeigt, genau wie bei einer Links-nach-rechts-Oberfläche.
<G-vec00141-002-s029><display.anzeigen><en> If the Windows display language is still set to English, the title bar remains in English and the Close, Minimize, and Maximize buttons remain in the upper-right corner as they do in a left-to-right interface.
<G-vec00141-002-s030><display.anzeigen><de> Der Browser unterstützt keine Inlineframes oder ist aktuell so konfiguriert, dass Inlineframes nicht angezeigt werden.
<G-vec00141-002-s030><display.anzeigen><en> frames or is currently configured not to display inline frames. Weight
<G-vec00141-002-s031><display.anzeigen><de> Gestapelte japanische Datumsangaben werden in konvertierten Dateien nicht richtig angezeigt.
<G-vec00141-002-s031><display.anzeigen><en> Stacked Japanese dates do not display correctly in converted files.
<G-vec00141-002-s032><display.anzeigen><de> Ihnen wird dann der zuständige einheitliche Ansprechpartner, an den Sie sich mit Ihrem Anliegen wenden können, angezeigt.
<G-vec00141-002-s032><display.anzeigen><en> The system will then display the responsible single point of contact, who you can contact with your request.
<G-vec00141-002-s033><display.anzeigen><de> Dieser Befehl funktioniert ähnlich wie der Befehl "Abrufen", doch wird das Dialogfeld "Versionskontrolle - Abrufen" nicht angezeigt.
<G-vec00141-002-s033><display.anzeigen><en> This command works in a similar fashion to the Get command, but does not display the "Source control - Get" dialog box.
<G-vec00141-002-s034><display.anzeigen><de> Diese Zeichen werden digital auf dem Display des Kombiinstruments angezeigt.
<G-vec00141-002-s034><display.anzeigen><en> It then displays the signs digitally in the instrument panel’s cluster display.
<G-vec00141-002-s035><display.anzeigen><de> Außerdem wird möglicherweise die Uhrzeit nicht angezeigt.
<G-vec00141-002-s035><display.anzeigen><en> And it may not display the timer, either.
<G-vec00141-002-s036><display.anzeigen><de> Bitte beachten Sie, dass diese Seite in anderen Browsern möglicherweise nicht korrekt angezeigt wird.
<G-vec00141-002-s036><display.anzeigen><en> Remarque: This page might not display properly in other browsers.
<G-vec00141-002-s037><display.anzeigen><de> Man kann aber auch eine der markierten Zeilen des User Style entfernen, wenn man es hinzufügt — dann wird die Liste auf der rechten Seite beziehungsweise oben angezeigt.
<G-vec00141-002-s037><display.anzeigen><en> You can also remove one of the marked lines when prompted to add the style — then the list of blockable items will display on the right side or on the top.
<G-vec00141-002-s038><display.anzeigen><de> Dynamic Green View gibt Ihnen Entfernungen zur Vorderseite, Mitte und Rückseite des Grüns, die auf einem 1,26 Zoll großen LCD-Display angezeigt werden.
<G-vec00141-002-s038><display.anzeigen><en> Dynamic Green view offers distances from the front, centre and back of the green are made viewable on the 1.26" LCD display.
<G-vec00141-002-s039><display.anzeigen><de> Es kann von Vorteil sein, eine Spalte nicht zu exportieren, wenn Sie nur im Dashboard angezeigt werden soll.
<G-vec00141-002-s039><display.anzeigen><en> Not exporting a column can be of interest if the intent is only to display the column in the dashboard.
<G-vec00141-002-s040><display.anzeigen><de> Auf einer zweiten Webseite kann ein anderes Formular angezeigt werden, wenn diese ein anderes Objekt enthält.
<G-vec00141-002-s040><display.anzeigen><en> A second Web page can display a different form if it contains a different object.
<G-vec00141-002-s041><display.anzeigen><de> Ohne den Cache müssen Sie möglicherweise mehrere Minuten warten, bis einige Oberflächen angezeigt werden.
<G-vec00141-002-s041><display.anzeigen><en> Without the cache, you may have to wait several minutes for some surfaces to display.
<G-vec00141-002-s042><display.anzeigen><de> Wenn Sie mit sehr umfangreichen Tabellen arbeiten, kommen Sie vielleicht mit einem großen Monitor, auf dem mehr Zeilen und Spalten gleichzeitig angezeigt werden können, besser zurecht.
<G-vec00141-002-s042><display.anzeigen><en> If you work with giant spreadsheets, you might prefer one large monitor that can display more rows and columns at once.
<G-vec00141-002-s043><display.anzeigen><de> Wechseln Sie zu einem beliebigen anderen Layout und fügen Sie dann Ihren gewünschten Text hinzu, der als Beschriftung angezeigt werden soll.
<G-vec00141-002-s043><display.anzeigen><en> Switch to any other layout, and add any text you want to display as the caption.
<G-vec00141-002-s044><display.anzeigen><de> Es erscheinen weitere Optionen, aus denen man wählen kann, wie der Menüeintrag angezeigt werden soll.
<G-vec00141-002-s044><display.anzeigen><en> Here are more options you can choose for the display of your menu item.
<G-vec00141-002-s045><display.anzeigen><de> Je nach Datenverkehrsaufkommen in einer bestimmten Umgebung kann es einige Stunden dauern, bis die Updates angezeigt werden.
<G-vec00141-002-s045><display.anzeigen><en> Depending on the level of traffic on a specific environment, it may take a few more hours to display the updates.
<G-vec00141-002-s046><display.anzeigen><de> Es macht sich erst bemerkbar, wenn sehr viele Anwender auf ein und dasselbe zugreifen, d.h. wenn sehr viele Anwender eine PHP-Seite/-Script gleichzeitig aufrufen, kann es je nach Server-Hardware hier und da etwas länger dauern, bis diese angezeigt werden.
<G-vec00141-002-s046><display.anzeigen><en> A delay only becomes noticeable if several users are accessing the same thing, e.g. if several users call up a PHP page or script at the same time, it can take longer to display the page or script, depending on the hardware.
<G-vec00141-002-s047><display.anzeigen><de> Wählen Sie im Abschnitt Kreuztabelle neben Spalte den Zeitraum aus, der angezeigt werden soll, und geben Sie dann die Anzahl der Zeiträume für jede Spalte ein.
<G-vec00141-002-s047><display.anzeigen><en> In the Crosstab section, next to Column, select the time period that you want to display, and then enter the number of time periods for each column.
<G-vec00141-002-s048><display.anzeigen><de> Bücher sind QuarkXPress Dateien, die als Fenster angezeigt werden mit Links zu einzelnen Dokumenten, den Kapiteln.
<G-vec00141-002-s048><display.anzeigen><en> Books are QuarkXPress files that display as windows containing links to individual documents, called chapters.
<G-vec00141-002-s049><display.anzeigen><de> Der Zahlungsstatus kann bis zu 24 Stunden lang als ausstehend angezeigt werden, auch wenn kein Kulanzzeitraum festgelegt wurde.
<G-vec00141-002-s049><display.anzeigen><en> The payment status may display as pending for up to 24 hours, even if no grace period is set.
<G-vec00141-002-s050><display.anzeigen><de> Ihr Browser unterstützt keine inline frames oder ist so konfiguriert, das inline frames nicht angezeigt werden.
<G-vec00141-002-s050><display.anzeigen><en> support inline frames or is currently configured not to display inline All right reserved.
<G-vec00141-002-s051><display.anzeigen><de> Sie können auch schön in Ihrem Zuhause oder im Büro angezeigt werden.
<G-vec00141-002-s051><display.anzeigen><en> They also can nicely display in your home or office.
<G-vec00141-002-s052><display.anzeigen><de> Es sollen jedoch nur die Fahrzeugmodelle des vom Benutzer in der Auswahlliste ausgewählten Herstellers geladen und angezeigt werden.
<G-vec00141-002-s052><display.anzeigen><en> However, the goal is to load and display only the car models of the manufacturer that the user selects in the combo box.
<G-vec00141-002-s053><display.anzeigen><de> Dieses Webpart kann nicht angezeigt werden.
<G-vec00141-002-s053><display.anzeigen><en> Unable to display this Web Part.
<G-vec00141-002-s054><display.anzeigen><de> Hinweis: Wenn der gewünschte Aufgabenbereich nicht durch Drücken von F6 angezeigt werden kann, drücken Sie ALT, um den Fokus in das Menüband zu setzen, und drücken Sie dann F6, um zum Aufgabenbereich zu wechseln.
<G-vec00141-002-s054><display.anzeigen><en> If pressing F6 doesn't display the task pane you want, try pressing ALT to place the focus on the menu bar and then pressing CTRL+TAB to move to the task pane.
<G-vec00141-002-s055><display.anzeigen><de> Ich habe diesem Artikel ein Bild meiner Bürowand beigefügt, auf der Kopien vieler Schlüsselmodelle angezeigt werden.
<G-vec00141-002-s055><display.anzeigen><en> I’ve included with this article a picture of my office wall, where I display copies of many of the key models.
<G-vec00141-002-s056><display.anzeigen><de> Damit im Listenwebpart und im verbundenen Webpart die gewünschten Daten angezeigt werden, müssen Sie die Listenansicht möglicherweise bearbeiten.
<G-vec00141-002-s056><display.anzeigen><en> To display the data that you want in the List Web Part as well as the other connected Web Part, you may need to edit the view of the list.
<G-vec00141-002-s057><display.anzeigen><de> Eine WetterSymboländerung in der Anzeige kann zum Teil länger als erwünscht dauern.
<G-vec00141-002-s057><display.anzeigen><en> A change in the weather symbol on the display may at times take longer than desired.
<G-vec00141-002-s058><display.anzeigen><de> VIVE WLAN Adapter > Manchmal erscheint das Funksignal schwach oder die Anzeige des Headsets wird gestört.
<G-vec00141-002-s058><display.anzeigen><en> VIVE Wireless Adapter > Sometimes the wireless signal seems weak or the headset display gets disrupted.
<G-vec00141-002-s059><display.anzeigen><de> System Symptom Kein Betrieb Keine Funktion oder Anzeige Kein oder unnatürlicher Ton.
<G-vec00141-002-s059><display.anzeigen><en> System Symptom No operation No function or display No sound or unnatural sound.
<G-vec00141-002-s060><display.anzeigen><de> Die Anzeige des Digital Thermostat kommt mit einer Hintergrundbeleuchtung und lässt so auch in der Dämmerung einen Blick auf die Funktionalität, sowie die aktuelle Raumtemperatur werfen.
<G-vec00141-002-s060><display.anzeigen><en> The display of the Digital thermostat comes with a backlit and can be so also in the twilight take a look at the functionality, as well as the current room temperature.
<G-vec00141-002-s061><display.anzeigen><de> Empfänger mit großer, farbiger Anzeige, elektronischem Kompass, barometrischem Höhenmeter, integrierter Welt- und Europa/Afrika-Karte, automatischer Routenberechnung, USB- und serieller Schnittstelle.
<G-vec00141-002-s061><display.anzeigen><en> held GPS receiver with large color display, electronic compass, barometrical altimeter, integrated world and Europe/Africa map, auto-routing, USB and serial interface.
<G-vec00141-002-s062><display.anzeigen><de> Dies ist die kombinierte Anzeige aller in E-Assessment-Wiki geführten Logbücher.
<G-vec00141-002-s062><display.anzeigen><en> Combined display of all available logs of IRC Improv Wiki.
<G-vec00141-002-s063><display.anzeigen><de> (SMART SCANNING) Anzeige der ECHTZEIT-Motorsensordaten, einschließlich Motordrehzahl, berechneter Lastwert, Kühlmitteltemperatur, Kraftstoffsystemstatus, Fahrzeuggeschwindigkeit, kurzzeitige Kraftstofftrimmung, langfristige Kraftstofftrimmung, Ansaugkrümmerdruck, Zeitvorlauf, Ansauglufttemperatur, Luftdurchflussrate, absolute Drosselklappenstellung, Sauerstoffsensorspannungen / zugehörige Kurzzeit-Kraftstoffverkleidungen, Kraftstoffsystemstatus, Kraftstoffdruck.
<G-vec00141-002-s063><display.anzeigen><en> Display current sensor data, including: engine rpm, calculated load value, coolant temperature, fuel system status, vehicle speed, short term fuel trim, long term fuel trim, intake manifold pressure, timing advance, intake air temperature, air flow rate, absolute throttle position, oxygen sensor voltages/associated short term fuel trims, fuel system status, fuel pressure.
<G-vec00141-002-s064><display.anzeigen><de> Mit dem Einreichen von Informationen gewähren Sie BioClin ein nicht exklusives, gebührenfreies, ständiges, unwiderrufliches und vollständig unterlizenzierbares Recht zur Vervielfältigung, Nutzung, Veränderung, Veröffentlichung, Anpassung, Übersetzung, Erzeugung abgeleiteter Werke, Verteilung und Anzeige solcher Inhalte auf der ganzen Welt.
<G-vec00141-002-s064><display.anzeigen><en> By submitting information, you grant BioClin a nonexclusive, royalty-free, perpetual, irrevocable and fully sub licensable right to reproduce, use, modify, publish, adapt, translate, create derivative works from, distribute and display such content throughout the world in any media.
<G-vec00141-002-s065><display.anzeigen><de> Diese Version enthält mehrere wichtige neue Funktionen, darunter die Anzeige des in IE8-Prozessen gehosteten Webs im Prozess-Tooltip, die Anzeige der Service-Host-Kategorie eines svchosts im Tooltip, die Zuordnung von Dienstnamen zu Threads auf der Registerkarte Threads und TCP/IP-Registerkarten des Prozesseigenschaften-Dialogfelds unter Windows Vista und höher, eine neue Registerkarte mit Informationen zur.NET-Assembly im Prozesseigenschaften-Dialogfeld sowie weitere Verbesserungen und Fehlerbehebungen.
<G-vec00141-002-s065><display.anzeigen><en> This release includes several significant new features, including the showing the web hosted in IE8 processes in the process tooltip, display of a svchost’s service host category in its tooltip, mapping of service names to threads on the threads tab and TCP/IP tabs of the process properties dialog on Windows Vista and higher, a new.NET assembly information tab in the process properties dialog, as well as other improvements and bug fixes.
<G-vec00141-002-s066><display.anzeigen><de> Der Anti-Aufstiegszaun ist ein einzigartiges Umkreissicherheitsprodukt, das eine vorsichtige ofvisual Siebung der Anzeige beibehält, die den Bedarf balanciert, einen Angriff zu verzögern und abzuhalten.
<G-vec00141-002-s066><display.anzeigen><en> The Anti-Climb fence is a unique perimeter security product that maintains a guarded display ofvisual screening balancing the need to delay and deter an attack.
<G-vec00141-002-s067><display.anzeigen><de> Die voreingestellte Funktion dieser Taste besteht in der Anzeige der Lichtempfindlichkeit (ISO-Wert).
<G-vec00141-002-s067><display.anzeigen><en> The default for this button is to display the current ISO setting.
<G-vec00141-002-s068><display.anzeigen><de> Die Anzeige der reduzierten Kochzone wechselt zwischen den beiden Kochstufen.
<G-vec00141-002-s068><display.anzeigen><en> The heat setting display for the reduced zone changes between two levels.
<G-vec00141-002-s069><display.anzeigen><de> Der HL760U verfügt über eine digitale Anzeige der Sollhöhenabweichung, die eine numerische Anzeige von 5 cm bietet.
<G-vec00141-002-s069><display.anzeigen><en> The HL760U features a digital readout of elevation that provides a numeric display of ± 5 cm (± 2 inches).
<G-vec00141-002-s070><display.anzeigen><de> Tachometer Geräte für die Grenzüberwachung, Umformung und Anzeige von Drehzahl, Geschwindigkeit und Durchfluss, mit Analogausgang und/oder Dateninterface.
<G-vec00141-002-s070><display.anzeigen><en> Devices for set point monitoring, conversion and display of rotational speed, speed and flow rate, with analog output and/or data interface.
<G-vec00141-002-s071><display.anzeigen><de> Damit ist das SENTINEL - Zeigerwerk in den bekannten Versionen (mit mechanischer, mit elektrischer Anzeige und mit Leitungsüberwachung) auch in einer korrosionsfreien Bauform verfügbar.
<G-vec00141-002-s071><display.anzeigen><en> Therefor, the SENTINEL - position indicator is in the known versions (with mechanical, with electrical display and with circuit monitoring) available in a corrosion-free design.
<G-vec00141-002-s072><display.anzeigen><de> Forscher im Wearable-Computing und die “Maker”-Community haben sich diese Abspielgeräte zunutze gemacht und passten sie für ihre besonderen mobilen Bedürfnisse an, etwa durch das Entfernen der Anzeige für ein Auge.
<G-vec00141-002-s072><display.anzeigen><en> Wearable computing academics and makers adopted these viewers and often adapted them for their mobile needs by removing the display for one eye.
<G-vec00141-002-s073><display.anzeigen><de> Benachrichtigungen + Musik: Anzeige von Anruf- und SMS-Benachrichtigungen über das Touchscreen-Display.
<G-vec00141-002-s073><display.anzeigen><en> Messages + Music: display call and SMS messages via the touch screen display
<G-vec00141-002-s074><display.anzeigen><de> Drittanbieter-Cookie IDE Verwendet von Google DoubleClick, um die Handlungen des Benutzers auf der Website nach der Anzeige oder dem Klicken auf eine der Anzeigen des Anbieters zu registrieren und zu melden, mit dem Zweck der Messung der Wirksamkeit einer Werbung und der Anzeige zielgerichteter Werbung für den Benutzer.
<G-vec00141-002-s074><display.anzeigen><en> Third-party cookie IDE Used by Google Double Click to register the user’s actions on the website after showing or even clicking on an advert to measure the effectiveness of an advert and the display of target-oriented advertising for the user.
<G-vec00141-002-s075><display.anzeigen><de> Sie beinhaltet Geräte für die Bedienung, Steuerung und Regelung sowie für die grafische Anzeige von Maschinendaten.
<G-vec00141-002-s075><display.anzeigen><en> It contains devices for operating, controlling and regulating as well as for the graphical display of machine data.
<G-vec00141-002-s076><display.anzeigen><de> 1 = Nur die erste Spalte im Footer anzeigen.
<G-vec00141-002-s076><display.anzeigen><en> 1 = Only display the first column in the footer.
<G-vec00141-002-s077><display.anzeigen><de> Zusammen mit den Anzeigen für die kleine Sekunde bei «6 Uhr» und dem Datum bei «3 Uhr» entsteht so ein ausgewogenes Zifferblattbild.
<G-vec00141-002-s077><display.anzeigen><en> Together with the small seconds display at “6 o’clock” and the date display at “3”, this gives the dial a pleasing equilibrium.
<G-vec00141-002-s078><display.anzeigen><de> Wir können Ihre personenbezogenen Daten und sonstige Informationen, die wir gemäß diesen Datenschutzgrundsätzen erfasst haben, nutzen, um Ihnen personalisierte Anzeigen, Funktionen oder Angebote auf Websites von Drittanbietern bereitzustellen.
<G-vec00141-002-s078><display.anzeigen><en> We may use your Personal Data and other information collected in accordance with this Privacy Statement to provide a targeted display, feature, Services or offer to you on third-party websites.
<G-vec00141-002-s079><display.anzeigen><de> Wenn Sie Zellen beim Drucken eines Arbeitsblatts mit einer Hervorhebung anzeigen möchten, können Sie mithilfe von Formatierungsfeatures eine Zellenschattierung anwenden.
<G-vec00141-002-s079><display.anzeigen><en> If you want to display cells with a highlight when you print a worksheet, you can use formatting features to apply cell shading.
<G-vec00141-002-s080><display.anzeigen><de> Dadurch kann die Website Ihren Computer wiedererkennen, wenn Sie sie erneut besuchen, und benutzerspezifische Einstellungen anzeigen.
<G-vec00141-002-s080><display.anzeigen><en> It allows that web site to recognize your computer when you return, enabling it to display personalized settings and other user preferences.
<G-vec00141-002-s081><display.anzeigen><de> Welches Inhaltsmodul Sie verwenden, hängt von der Art der Inhalte ab, die Sie erstellen, speichern und anzeigen möchten.
<G-vec00141-002-s081><display.anzeigen><en> The type of content modules you use will vary depending on what kinds of content you want to create, store, and display.
<G-vec00141-002-s082><display.anzeigen><de> Mit dieser Art von Diensten kann diese Website Werbung für die Produkte oder Dienstleistungen Dritter anzeigen.
<G-vec00141-002-s082><display.anzeigen><en> Commercial affiliation These services allow this website to display advertisements for third party products or services.
<G-vec00141-002-s083><display.anzeigen><de> WebView Webview Fügt Webseiten Ihrer Kontaktliste hinzu, und kann Text anzeigen und/oder bei Änderungen auf diesen Seiten einen Alarm auslösen.
<G-vec00141-002-s083><display.anzeigen><en> WebView Webview Adds web pages as contacts to your contact list and can display text and/or issue change alerts from those pages in a window.
<G-vec00141-002-s084><display.anzeigen><de> Sie können eine Vorschau des Renderings Ihres Formulars auf einem Mobilgerät anzeigen, indem Sie die Ansicht oben im Formulareditor von "Desktop" auf "Mobilgerät" umschalten.
<G-vec00141-002-s084><display.anzeigen><en> You can display your Update Profile form in mobile mode to preview how it will look on your subscribers’ devices. Simply toggle the view from desktop to mobile on the top of the form editor.
<G-vec00141-002-s085><display.anzeigen><de> Slack wird die Top Drei deiner Einträge anzeigen – klicke einfach auf Details anzeigen, um mehr zu sehen oder sie in Salesforce zu öffnen.
<G-vec00141-002-s085><display.anzeigen><en> Slack will display the top three records – simply click Show details to see more or to view it in Salesforce.
<G-vec00141-002-s086><display.anzeigen><de> Schritt 3: Dann werden iTunes Ihnen die Informationen zu den neuesten Updates anzeigen, befolgen Sie den Assistenten und iTunes werden die neueste Firmware automatisch herunterladen, die schon beim Update auf iOS 10/9 verwendet wird.
<G-vec00141-002-s086><display.anzeigen><en> Step 3: Then iTunes would display the latest update information for you, just follow the wizard and iTunes will automatically download the latest firmware used to update iPhone to latest iOS version.
<G-vec00141-002-s087><display.anzeigen><de> Wir werden dann mehrere Download-Buttons anzeigen, mit denen du konvertierte Videos als MP3 herunterladen kannst.
<G-vec00141-002-s087><display.anzeigen><en> We will then display several download buttons that will allow you download converted video as mp3.
<G-vec00141-002-s088><display.anzeigen><de> Man kann auch ein kleines Bild mit einem Tooltip vergrößert anzeigen.
<G-vec00141-002-s088><display.anzeigen><en> You may use a thumbnail and display it full sized with a Tooltip.
<G-vec00141-002-s089><display.anzeigen><de> Die Zentralsekunde ermöglicht das genaue Ablesen der Achtelsekunde, während die beiden Totalisatoren auf dem Zifferblatt die abgelaufene Zeit in Stunden- und Minutenschritten anzeigen.
<G-vec00141-002-s089><display.anzeigen><en> The central sweep seconds hand allows an accurate reading of 1/8 second, while the two counters on the dial display the lapsed time in hours and minutes.
<G-vec00141-002-s090><display.anzeigen><de> Zur Optimierung des Profilaufbaus und zur besseren Erfassung des Informations- und Leseverhaltens von Abonnenten bietet Evalanche verschiedene Arten des Profilings – angefangen vom Content Profiling über Profile (Interessen)-Tagging bis hin zum Progressive Profiling (automatisches Anzeigen von Datenfeldern) für Landingpages.
<G-vec00141-002-s090><display.anzeigen><en> Evalanche offers different types of profiling to optimise the profile structure and to improve the capture information and reading behaviors of subscribers - from content profiling to profiling (interest) tagging and progressive profiling (automatic display of data fields) for landing pages.
<G-vec00141-002-s091><display.anzeigen><de> Benutzername für Abschnitt zum Anzeigen des Abschnittsnamens in Menüs oder in der Dokumentansicht (Nur-Lesen mit Unterabschnitten).
<G-vec00141-002-s091><display.anzeigen><en> Section user name, used to display section name in menus or in the document view (Read-only with subsections).
<G-vec00141-002-s092><display.anzeigen><de> Diese Datenschutzerklärung gilt für pb.com und Pitney Bowes-Websites, -Dienstleistungen und -Produkte, die Daten erfassen und diese Bedingungen anzeigen, und die Pitney Bowes und Tochtergesellschaften von Pitney Bowes gehören und von diesen betrieben werden, gemeinsam als „Pitney Bowes“ bezeichnet.
<G-vec00141-002-s092><display.anzeigen><en> This Privacy Statement applies to pb.com and Pitney Bowes websites, services and products that collect data and display these terms, and that are owned and operated by Pitney Bowes and Pitney Bowes subsidiaries, collectively, "Pitney Bowes".
<G-vec00141-002-s093><display.anzeigen><de> CoPilot Truck kann die derzeit gültige Geschwindigkeitsbegrenzung anzeigen und Sie warnen, falls Sie diese versehentlich überschreiten.
<G-vec00141-002-s093><display.anzeigen><en> CoPilot Truck can display the speed limit of the current road and warn you if you accidentally exceed it.
<G-vec00141-002-s094><display.anzeigen><de> Wenn Sie festgelegt haben, in welchem Bereich Sie den Kontostand eines Nutzers anzeigen möchten, nutzen Sie loadRewards() zur Anzeige der aktuellen Anzahl Credits.
<G-vec00141-002-s094><display.anzeigen><en> Once you’ve figured out where you want to display a user’s credit balance, use loadRewards() to display how many credits a user has.
<G-vec00141-002-s095><display.anzeigen><de> In Writer können Sie die Navigationssymbolleiste auch anzeigen lassen, indem Sie auf das kleine Icon klicken, das sich in der unteren rechten Ecke des Fensters unterhalb der vertikalen Bildlaufleiste befindet (siehe Abbildung XYZ).
<G-vec00141-002-s095><display.anzeigen><en> In Writer, you can also display the Navigation toolbar by clicking on the small Navigation icon near the lower right-hand corner of the window below the vertical scroll bar, as shown in Figure 6.
<G-vec00141-002-s096><display.anzeigen><de> Ändert ihr eure Online-ID, habt ihr die Möglichkeit, eure vorherige ID mit eurer neuen ID anzeigen zu lassen, damit eure Freunde euch erkennen können.
<G-vec00141-002-s096><display.anzeigen><en> When you change your online ID, you will have the option to display your previous ID with your new ID.
<G-vec00141-002-s097><display.anzeigen><de> a. Tippe die Home-Taste doppelt an, um kürzlich verwendete Apps anzeigen zu lassen.
<G-vec00141-002-s097><display.anzeigen><en> Tap the Home button twice on your iPhone to display recently used apps
<G-vec00141-002-s098><display.anzeigen><de> Sie können jedoch einzelne Transaktionen rausfiltern, indem Sie in der Transaktionsliste unter Berichte > Transaktionen bei Transaktionstyp die Transaktionen anklicken, die Sie sich anzeigen lassen wollen.
<G-vec00141-002-s098><display.anzeigen><en> However, you can filter out individual transactions. To do this, go to the transaction list under Reports > Transactions and for Transaction type click on the transactions you want to display.
<G-vec00141-002-s099><display.anzeigen><de> Die meisten Browser bieten die Möglichkeit, vor Speicherung eines Cookies eine Warnung anzeigen zu lassen, die Annahme von Cookies ganz zu verweigern und/oder bestehende Cookies wieder zu löschen.
<G-vec00141-002-s099><display.anzeigen><en> Most browsers offer the possibility to display a warning before storing a cookie, to completely refuse the acceptance of cookies and/or to delete existing cookies again.
<G-vec00141-002-s100><display.anzeigen><de> Sie können auch Abfahrts- und Ankunftstafeln für die Stationen anzeigen lassen.
<G-vec00141-002-s100><display.anzeigen><en> You can also display departure and arrival information for the stations.
<G-vec00141-002-s101><display.anzeigen><de> 3) Du kannst das Video in drei verschiedenen Größen anzeigen lassen.
<G-vec00141-002-s101><display.anzeigen><en> 3) You can display the video in three different sizes.
<G-vec00141-002-s102><display.anzeigen><de> Der Softwareanwender kann unter anderem zwischen Stufen innerhalb eines Trend-Projektes hin- und herschalten oder sich relevante Stufenbereiche exklusiv anzeigen lassen.
<G-vec00141-002-s102><display.anzeigen><en> The software user can switch back and forth between stages within a trend project or display relevant/defined stage areas exclusively.
<G-vec00141-002-s103><display.anzeigen><de> Um das Formular anzeigen zu lassen, müssen Sie den Schutz für diese Seite temporär deaktivieren.
<G-vec00141-002-s103><display.anzeigen><en> To display the form you have to deactivate the protection for this website temporarily.
<G-vec00141-002-s104><display.anzeigen><de> Zum Beispiel können Sie wichtige Eigenschaften am oberen Rand der Seite anzeigen lassen.
<G-vec00141-002-s104><display.anzeigen><en> For example, you can display important properties at the top of the page.
<G-vec00141-002-s105><display.anzeigen><de> Du kannst das PlayStation Vita-System als zweiten Bildschirm verwenden, um darauf Inhalte von Spielen anzeigen zu lassen, welche die Funktion "Zweitbildschirm" unterstützen.
<G-vec00141-002-s105><display.anzeigen><en> You can use the PS Vita as a secondary screen to display unique content when playing games that support the Second Screen feature.
<G-vec00141-002-s106><display.anzeigen><de> Die maximale Verformung jedes Stabes können Sie sich anzeigen lassen, indem Sie im "Zeigen"-Navigator unter "Ergebnisse" -> "Verformung" -> "Stäbe" die Option "Extremwerte anzeigen" aktivieren.
<G-vec00141-002-s106><display.anzeigen><en> Yes, you can display the maximum deformation of each member. Go to the "Display" navigator, open the items "Results", "Deformation" and "Members", and activate the option "Show extremes".
<G-vec00141-002-s107><display.anzeigen><de> Sie können nicht gleichzeitig eine Datei aus der ersten Datei-Upload-Runde und eine PowerPoint-Datei aus der letzten Runde für einen Beitrag anzeigen lassen.
<G-vec00141-002-s107><display.anzeigen><en> You cannot display a Word file from the first round of uploads and a PowerPoint file from the final round for one submission at the same time.
<G-vec00141-002-s108><display.anzeigen><de> In diesem Zeitraum wurden keine Events gefunden, die du anzeigen lassen kannst.
<G-vec00141-002-s108><display.anzeigen><en> During this period, no events have been found that you can display.
<G-vec00141-002-s109><display.anzeigen><de> Das neue, in die Experimentierumgebung von INCA V7.1 integrierte Oszilloskop ermöglicht es, die Anzeige in mehrere horizontale Streifen zu unterteilen, so dass sich die Messkurven verschiedener Signalgruppen separat voneinander anzeigen lassen.
<G-vec00141-002-s109><display.anzeigen><en> Integrated into the experiment environment of INCA V7.1, the new oscilloscope makes it possible to dissect the display of analog measurement values into several horizontal strips, enabling vertical stacking of the display with a variety of signal groups.
<G-vec00141-002-s110><display.anzeigen><de> Die Fleet Tracking API bietet verschiedene Tracking-Modi: Sie können sich einzelne GPS-Punkte oder die gesamte Streckenhistorie der Fahrzeuge anzeigen lassen.
<G-vec00141-002-s110><display.anzeigen><en> The Fleet Tracking API offers different tracking modes: You can choose to display single GPS points or the vehicles’ whole track history.
<G-vec00141-002-s111><display.anzeigen><de> Mit dem Widget von Google AdSense können Sie Google Werbeanzeigen auf Ihrer Webseite anzeigen lassen.
<G-vec00141-002-s111><display.anzeigen><en> With this Google AdSense widget, you can display Google ads on your website.
<G-vec00141-002-s112><display.anzeigen><de> • Über das integrierte Journal können Sie sich jederzeit die Details aller historischen Ladevorgänge anzeigen lassen.
<G-vec00141-002-s112><display.anzeigen><en> • Using the integrated journal, you can display the details of all historical loads at any time.
<G-vec00141-002-s113><display.anzeigen><de> Dieser ermöglicht es uns, bestimmten Gruppen von pseudonymisierten Besuchern unserer Website, die auch Facebook nutzen, individuell abgestimmte und interessenbezogene Werbung auf Facebook anzeigen zu lassen.
<G-vec00141-002-s113><display.anzeigen><en> It allows us to display personalized and interest-based advertising on Facebook to certain groups of pseudonymous visitors to our site who also use Facebook.
<G-vec00141-002-s114><display.anzeigen><de> Wird verwendet, um numerische Daten in einer Zusammenfassung anzuzeigen.
<G-vec00141-002-s114><display.anzeigen><en> Row Labels Use to display summary numeric data.
<G-vec00141-002-s115><display.anzeigen><de> Klicken Sie in der Toolbox-Liste links im Fenster auf die Kategorie „Basic Actions“ (Einfache Aktionen), um die einfachen Aktionen anzuzeigen.
<G-vec00141-002-s115><display.anzeigen><en> In the Toolbox list on the left side of the panel, click the Basic Actions category to display the basic actions.
<G-vec00141-002-s116><display.anzeigen><de> Um SwissPass Mobile auf dem digitalen Endgerät anzuzeigen ist es wichtig, die Funktion ordnungsgemäss aktiviert zu haben sowie über genügend Akku und ein nicht beschädigtes Display zu verfügen.
<G-vec00141-002-s116><display.anzeigen><en> To display SwissPass Mobile on the digital device, it is important to have activated the feature properly, and you must also have sufficiently battery power and a display that is undamaged.
<G-vec00141-002-s117><display.anzeigen><de> Wir verwenden Google-Inc. („Google“) Remarketing-Funktionen, um Anzeigen im Google Display Network (GDN) anzuzeigen.
<G-vec00141-002-s117><display.anzeigen><en> (“Google”) remarketing features to display ads on the Google Display Network (GDN).
<G-vec00141-002-s118><display.anzeigen><de> Bei diesem Abschnitt wird geprüft, ob Ihr Fernsehgerät in der Lage ist, HDR für Spiele anzuzeigen.
<G-vec00141-002-s118><display.anzeigen><en> Your TV must also support the HDR10 media profile to display HDR.
<G-vec00141-002-s119><display.anzeigen><de> Im Bereich der Personalabrechnung und des Vergütungsmanagements gibt es die Option, Mitarbeitern Ihren Gehaltsnachweis direkt online anzuzeigen und die Mitarbeiter selbstständig aus den verfügbaren Vergütungsplänen wählen zu lassen, um ihre individuelle Vergütungskombination zu erstellen.
<G-vec00141-002-s119><display.anzeigen><en> In Payroll and Compensation Management, there is an option to display employees’ salary statements directly online and let your employees select their individual compensation plan from those available.
<G-vec00141-002-s120><display.anzeigen><de> Verwenden Sie an einer Eingabeaufforderung showmount –e Server, um die Namen der freigegebenen Verzeichnisse auf dem Server anzuzeigen.
<G-vec00141-002-s120><display.anzeigen><en> From a command prompt, use showmount –e server to display the names of shared directories on the server.
<G-vec00141-002-s121><display.anzeigen><de> Wählen Sie die Farbe, die Monate anzuzeigen.
<G-vec00141-002-s121><display.anzeigen><en> Choose the color to display the months.
<G-vec00141-002-s122><display.anzeigen><de> Wenn Sie unsere Website betrachten möchten, erheben wir die folgenden Daten, die für uns technisch erforderlich sind, um Ihnen unsere Website anzuzeigen und die Stabilität und Sicherheit zu gewährleisten.
<G-vec00141-002-s122><display.anzeigen><en> When you request to view our website, we collect the following data which are technically required for us to display our website to you and to ensure stability and security.
<G-vec00141-002-s123><display.anzeigen><de> 2... Klicke auf [Übernehmen], um den ausgewählten modifizierten Wind in der Vorhersage anzuzeigen.
<G-vec00141-002-s123><display.anzeigen><en> 2... click [apply] to display the selected modified wind in the forecast
<G-vec00141-002-s124><display.anzeigen><de> Hier haben Sie die Möglichkeit, alle gewünschten Informationen anzuzeigen.
<G-vec00141-002-s124><display.anzeigen><en> Here you have the option to display all of the required information.
<G-vec00141-002-s125><display.anzeigen><de> Erweitern Sie den Ordner, den Sie filtern, um die darin enthaltenen Objekte anzuzeigen.
<G-vec00141-002-s125><display.anzeigen><en> Expand the folder you are filtering to display the objects it contains.
<G-vec00141-002-s126><display.anzeigen><de> Öffnen Sie die Datei SHA1SUM mit einem Texteditor, beispielsweise Notepad, um ihren Inhalt anzuzeigen.
<G-vec00141-002-s126><display.anzeigen><en> Open the file SHA1SUM with a text editor, such as WordPad, to display its contents.
<G-vec00141-002-s127><display.anzeigen><de> Y Zwischensummentaste s Verwenden Sie diese Taste, um die gegenwärtige Zwischensumme (einschließlich Umsatzsteuer) anzuzeigen und auszudrucken.
<G-vec00141-002-s127><display.anzeigen><en> Y Subtotal key s Use this key to display and print the current subtotal (includes add-on tax) amount.
<G-vec00141-002-s128><display.anzeigen><de> Beim Aufruf einer Seite lädt Ihr Browser die benötigten Web Fonts in ihren Browsercache, um Texte und Schriftarten korrekt anzuzeigen.
<G-vec00141-002-s128><display.anzeigen><en> By accessing this website, the browser loads web fonts in the browser cache to correctly display the required typefaces.
<G-vec00141-002-s129><display.anzeigen><de> Wird verwendet, um Dateien und Ordner auf der grafischen Benutzeroberfläche (GUI) der Betriebssysteme anzuzeigen.
<G-vec00141-002-s129><display.anzeigen><en> Used to display files and folders in the graphical user interface (GUI) operating systems.
<G-vec00141-002-s130><display.anzeigen><de> Erwägen Sie, das size-Attribut zu verwenden, um die ersten Optionen einer Auswahlliste anzuzeigen.
<G-vec00141-002-s130><display.anzeigen><en> Consider using the size attribute to display the first set of options in a select control.
<G-vec00141-002-s131><display.anzeigen><de> Nachdem die Gilde Stufe 100 erreicht hat wird die Prestige Zeile mit Bekanntheit ersetzt (um die Anzahl an Bekanntheitspunkten, die von jedem Spieler im aktuellen Monat erhalten wurde anzuzeigen).
<G-vec00141-002-s131><display.anzeigen><en> After the guild reaches level 100, the Prestige column will be replaced with Nobility (to display the number of Nobility points gained by each member during the current month).
<G-vec00141-002-s132><display.anzeigen><de> Es wurde ein Problem behoben, bei dem das Programm hängen konnte, wenn es begonnen hat, Live-Ausgaben externer Dienstprogramme anzuzeigen, die ohne privilegierte Rechte gestartet wurden.
<G-vec00141-002-s132><display.anzeigen><en> Fixed a problem where the application could hang while beginning to display live output from external utility tools that have been started without privileged permissions.
<G-vec00141-002-s112><indicate.anzeigen><de> Das Gerät hat manchmal fälschlicherweise angezeigt, es sei eine Aktualisierung vorhanden.
<G-vec00141-002-s112><indicate.anzeigen><en> Fixed issue where the device could incorrectly indicate that there is a software update available.
<G-vec00141-002-s113><indicate.anzeigen><de> Die Dem Tode geweiht-Effekte werden angezeigt, wenn der Spieler dem Tode geweiht ist.
<G-vec00141-002-s113><indicate.anzeigen><en> The Marked For Death effects are used to indicate that the player is marked for death.
<G-vec00141-002-s114><indicate.anzeigen><de> Die Busklemme enthält zwei Kanäle, deren Signalzustand oder Fehler durch LEDs angezeigt werden.
<G-vec00141-002-s114><indicate.anzeigen><en> The Bus Terminal contains two channels that indicate their signal state and errors by means of LEDs.
<G-vec00141-002-s116><indicate.anzeigen><de> Mehrere Personen können ihre Telefone zu einem Umleitungsziel weiterleiten lassen, und wenn das Telefon über ein Display verfügt, wird angezeigt, für wen der Anruf ist AVAYA Alle Rechte vorbehalten.
<G-vec00141-002-s116><indicate.anzeigen><en> Several people can have their phones forwarded to a follow-me destination and if the phone has a display it will indicate who the call is for AVAYA All rights reserved.
<G-vec00141-002-s117><indicate.anzeigen><de> Eine volle Ladung wird auch dann angezeigt, wenn die Batterien abgetrennt und dann wieder angeschlossen werden.
<G-vec00141-002-s117><indicate.anzeigen><en> It will also indicate a full charge if the batteries are disconnected, then reconnected.
<G-vec00141-002-s118><indicate.anzeigen><de> b) Steht jedoch laut einer oder mehrerer dieser Richtlinien dem Hersteller während einer Übergangszeit die Wahl der anzuwendenden Regelung frei, wird durch die CE-Kennzeichnung lediglich die Konformität mit den Bestimmungen der vom Hersteller angewandten Richtlinien angezeigt.
<G-vec00141-002-s118><indicate.anzeigen><en> (b) However, where one or more of those Directives allow the manufacturer, during a transitional period, to choose which arrangements to apply, the CE marking shall indicate conformity only with the Directives applied by the manufacturer.
<G-vec00141-002-s119><indicate.anzeigen><de> Die Baugruppe enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00141-002-s119><indicate.anzeigen><en> The module contains two channels that indicate their state by means of light emitting diodes.
<G-vec00141-002-s120><indicate.anzeigen><de> Wenn bei Anhängerbetrieb am Anhänger oder am Fahrzeug eine Blinkleuchte ausfällt, wird dies nicht durch doppelt so schnelles Blinken der Kontrollleuchte angezeigt.
<G-vec00141-002-s120><indicate.anzeigen><en> If a turn signal bulb on the trailer or vehicle fails in towing mode, the indicator lamp does not flash twice as fast to indicate the bulb failure.
<G-vec00141-002-s121><indicate.anzeigen><de> Bei Transport durch internationale Kurierdienstunternehmen muss auf dem Frachtbrief eindeutig angezeigt werden, dass die Kosten für Verzollung und Steuern vom Absender getragen werden.
<G-vec00141-002-s121><indicate.anzeigen><en> Shipments sent through international courier services must clearly indicate on their waybill that all costs for duties and taxes are to be billed to the sender.
<G-vec00141-002-s122><indicate.anzeigen><de> IHRE LIZENZ Wenn Sie uns Materialien einsenden, räumen Sie – soweit nicht von uns anders angezeigt – Amazon ein nicht ausschließliches, gebührenfreies, unwiderrufliches und vollständig unterlizenzierbares Recht ein, diese weltweit in beliebigen Medien zu verwenden, zu reproduzieren, zu verändern, zu modifizieren, zu veröffentlichen, zu übersetzen und abgeleitete Werke daraus zu erstellen, sie zu verteilen und darzustellen, solange Sie nach dem geltenden Recht zur Erteilung einer entsprechenden Lizenz berechtigt sind.
<G-vec00141-002-s122><indicate.anzeigen><en> Your License If you submit material, and unless we indicate otherwise, you grant Amazon Seller Services Private Limited and its affiliates a nonexclusive, royalty-free, irrevocable, perpetual and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such content throughout the world in any media for as long as you are permitted to grant the said licence under applicable law.
<G-vec00141-002-s123><indicate.anzeigen><de> Es kann auch eine benutzerdefinierte Markierung mit bis zu 45 Zeichen angezeigt werden.
<G-vec00141-002-s123><indicate.anzeigen><en> It can also indicate a custom marking up to 45 characters.
<G-vec00141-002-s124><indicate.anzeigen><de> Sobald das Ladekabel angeschlossen ist, wird der Ladezustand farblich angezeigt.
<G-vec00141-002-s124><indicate.anzeigen><en> Once the plug is connected, colours will indicate the progress of the battery charge.
<G-vec00141-002-s125><indicate.anzeigen><de> In den Windowsversionen der BAE-Software wird die Markierung für die aktuell eingestellte Option nur noch in Menüs angezeigt, in denen eine dauerhaft einstellbare Option selektiert werden kann.
<G-vec00141-002-s125><indicate.anzeigen><en> Option Menus The BAE Windows menus have been changed to indicate currently pre-selected options only in menus which allow for the selection of permanently active options.
<G-vec00141-002-s126><indicate.anzeigen><de> Auch wenn unter "Zugriffsfehler" der Zähler ungleich null ist, wird das gesamte Backup als nicht fehlerfrei angezeigt.
<G-vec00141-002-s126><indicate.anzeigen><en> If the counter for access errors is not zero, the overall backup result will also indicate the failure.
<G-vec00141-002-s127><indicate.anzeigen><de> Soweit aufgrund der Eingaben des Kunden auf der Buchungsplattform die Versandkonditionen eines Vertragsunternehmens des Kunden angezeigt werden, liegt diesen Konditionen die jeweilige Rahmenvereinbarung des Kunden mit dem Vertragsunternehmen zugrunde.
<G-vec00141-002-s127><indicate.anzeigen><en> Insofar as the customer’s entries on the booking platform indicate the shipping conditions of a customer’s contractual company, these conditions are based on the respective general agreement between the customer and the contractual company.
<G-vec00141-002-s128><indicate.anzeigen><de> Beispielsweise wird anhand von Symbolen angezeigt, ob der Zieltext auf der Montagefläche, einer Musterseite, einer ausgeblendeten Ebene, in einem Übersatztext oder in verborgenem Text angezeigt wird.
<G-vec00141-002-s128><indicate.anzeigen><en> For example, icons indicate if the destination text appears on the pasteboard, a master page, a hidden layer, in overset text, or in hidden text .
<G-vec00141-002-s129><indicate.anzeigen><de> Die gespeicherte Geschwindigkeit und die grüne Kontrollleuchte werden im Display angezeigt Abb.2.
<G-vec00141-002-s129><indicate.anzeigen><en> The display will indicate the stored speed, and the green indicator lamp will light up Fig. 2.
<G-vec00141-002-s130><indicate.anzeigen><de> Sie können jedoch so eingestellt werden, dass Cookies nicht akzeptiert werden oder ihre Übertragung angezeigt wird.
<G-vec00141-002-s130><indicate.anzeigen><en> Yet, they can also be configured so as not to accept them or so as to indicate the cookies sent.
<G-vec00141-002-s159><indicate.anzeigen><de> Wenn der Hals deines Pferds ausgestreckt ist und sich die Muskeln unter dem Hals locker anfühlen, kann dies anzeigen, dass es entspannt und glücklich ist.
<G-vec00141-002-s159><indicate.anzeigen><en> If your horse's neck is stretched out and the muscles under his neck feel loose, this can indicate that he is relaxed and happy.
<G-vec00141-002-s160><indicate.anzeigen><de> Gleichwohl sind durchaus nicht alle Phänomene, die Folgen der Migration für Bildung und Erziehung anzeigen, inzwischen verstanden und erklärt.
<G-vec00141-002-s160><indicate.anzeigen><en> Nevertheless, not all phenomena that indicate the consequences of migration for education are understood and explained to this day.
<G-vec00141-002-s161><indicate.anzeigen><de> Er sagt uns, dass die resultierende Ausgabe statistisch signifikante Spitzen sind, die zyklische Wendepunkte präzise anzeigen.
<G-vec00141-002-s161><indicate.anzeigen><en> He tells us that the resultant output is statistically significant spikes that indicate cyclic turning points with precision.
<G-vec00141-002-s162><indicate.anzeigen><de> [RB 1.29.6] "Die Gottheit aber, die auch solch einem Wesen darum dennoch die Freiheit nicht nehmen kann und will, kann da ja doch nichts anderes tun, als solche verirrte Wesen bei ihrer Beschaffenheit anrufen und aus ihrem weisesten Liebernste ihnen den Weg anzeigen, aus dem für sie die Rettung möglich ist und sie wieder in den Verband der Liebe und Weisheit Gottes treten können.
<G-vec00141-002-s162><indicate.anzeigen><en> [RB 1.29.6] “The Deity however, Who does not want to deprive such being of freedom either, can do no more than call out to the nature of such wayward beings and with earnest love indicate to them the way by which they can again establish ties with God’s love and wisdom.
<G-vec00141-002-s163><indicate.anzeigen><de> Das Gerät erfordert Netzunterstützung, um anzeigen zu können, dass eine gesendete Mitteilung empfangen oder gelesen wurde.
<G-vec00141-002-s163><indicate.anzeigen><en> The device requires network support to indicate that a sent message has been received or read.
<G-vec00141-002-s165><indicate.anzeigen><de> Das Essen von Verdauungsabfällen kann sowohl Verhaltensabweichungen als auch gesundheitliche Probleme anzeigen.
<G-vec00141-002-s165><indicate.anzeigen><en> Eating digestive waste can indicate both behavioral deviations and health problems.
<G-vec00141-002-s166><indicate.anzeigen><de> Die Meldungen verwebt der Bot zu einer wilden Live-TV-Sendung, in der Bilder, Tweets und Videos in Echtzeit über den Bildschirm flimmern, und Icons in den Farben der Kombattanten deren aktuellen Online-Marktwert anzeigen.
<G-vec00141-002-s166><indicate.anzeigen><en> The bot weaves the posts into a frantic live TV broadcast in which images, tweets, and videos flicker across the screen in real time, and icons in the colours of the combatants indicate their current online market value.
<G-vec00141-002-s167><indicate.anzeigen><de> Die Zufahrt von der Hauptstraße erfolgt über ein privates Tor, das von einer majestätischen Zypresse markiert ist, die nach einer Reihe blühender Oleander, die auf natürliche Weise den einzuschlagenden Weg anzeigen, das gesamte Grundstück zu bewachen scheint.
<G-vec00141-002-s167><indicate.anzeigen><en> Access from the main road is via a private gate marked by a majestic cypress, as if to guard the entire property, after a row of blooming oleanders that naturally indicate the route to be taken.
<G-vec00141-002-s168><indicate.anzeigen><de> Ein dünner oder blutiger Stuhlgang kann das Gleiche anzeigen.
<G-vec00141-002-s168><indicate.anzeigen><en> Loose or bloody stools can indicate the same thing.
<G-vec00141-002-s169><indicate.anzeigen><de> Indikatoren sind Zustände oder Umstände, die während eines Beistandes auftauchen, die anzeigen, ob es gut oder schlecht geht.
<G-vec00141-002-s169><indicate.anzeigen><en> Indicators are conditions or circumstances arising during an assist which indicate whether it is running well or badly.
<G-vec00141-002-s170><indicate.anzeigen><de> Jedes dieser Medien kann die Design- oder Software-Informationen „tragen" oder „anzeigen".
<G-vec00141-002-s170><indicate.anzeigen><en> Any of these mediums may “carry” or “indicate” the design or software information.
<G-vec00141-002-s171><indicate.anzeigen><de> Lassen Sie einfach die Bilder auf sich wirken und beachten Sie auch die Riffelungen der Wolken, die klar anzeigen, daß hier schon wieder die HAARP-Technik eingesetzt wurde.
<G-vec00141-002-s171><indicate.anzeigen><en> Just take the pictures in and note the corrugations of clouds that clearly indicate that the HAARP technology had been applied again.
<G-vec00141-002-s172><indicate.anzeigen><de> Ein weiteres Unterscheidungsmerkmal ist sodann der Einsatz von Adjektiven, die Farben anzeigen: in den Texten der Mädchen tauchen golden, silbern, hell, grün, braun, kastanienbraun, pink, bonbonrosa und rot auf; in jenen der Jungen erscheint dagegen nur das Adjektiv weiß.
<G-vec00141-002-s172><indicate.anzeigen><en> Another a distinctive trait was the use of adjectives to indicate colours: in the girls’ texts were found golden, silver, white, clear, green, brown, chestnut, fuchsia, sugar-pink, red; in the male texts only the adjective white appeared.
<G-vec00141-002-s173><indicate.anzeigen><de> Obwohl manchmal die Symptome keinen Ausnahmezustand anzeigen, kann der Körper im Laufe der Zeit ineffizient werden.
<G-vec00141-002-s173><indicate.anzeigen><en> Although sometimes the symptoms do not indicate a state of emergency, over time, the body may become inefficient.
<G-vec00141-002-s174><indicate.anzeigen><de> Bitte beachten Sie, dass die Bilder auf dieser Seite nur zur Veranschaulichung dienen und nicht unbedingt den verkauften Artikel anzeigen.
<G-vec00141-002-s174><indicate.anzeigen><en> Please note that the pictures on this site are for illustrative purposes only and do not necessarily indicate the item being sold.
<G-vec00141-002-s175><indicate.anzeigen><de> Tatsächlich, die Tafeln die jedes Stockwerk des Gebäudes anzeigen sind bis heute erhalten geblieben und sind in ungarischer Sprache.
<G-vec00141-002-s175><indicate.anzeigen><en> It’s true that there are plaques which indicate every level on the Neptun Apartment Block and that have been kept intact to this day, being written in Hungarian.
<G-vec00141-002-s176><indicate.anzeigen><de> Somit können Sie die Anlage nicht nur ausleuchten, sondern auch Maschinenzustände mit unterschiedlichen Farben anzeigen.
<G-vec00141-002-s176><indicate.anzeigen><en> Thus you cannot just illuminate your machine, but also indicate machine statuses with different colours.
<G-vec00141-002-s177><indicate.anzeigen><de> Es gibt bestimmte Elliott-Wellen-Muster, die anzeigen, das sich ein neuer Trend in die entgegengesetzte Richtung bildet.
<G-vec00141-002-s177><indicate.anzeigen><en> There are certain Elliott Wave patterns that indicate a new trend in the opposite direction is forming.
<G-vec00141-002-s179><indicate.anzeigen><de> Wenn das Ergebnis anzeigt, dass es ein Problem gibt, können Sie in die Details gehen.
<G-vec00141-002-s179><indicate.anzeigen><en> If the results indicate that there is a problem, you can drill into the details.
<G-vec00141-002-s180><indicate.anzeigen><de> Die IAPP Presseausweise sind registriert und mit der aktuellen Jahreszahl versehen, die die Gültigkeit anzeigt.
<G-vec00141-002-s180><indicate.anzeigen><en> IAPP press passes are registered and marked with the current year to indicate their validity. 10.
<G-vec00141-002-s181><indicate.anzeigen><de> Wenn Sie auf diese Elemente in der Live-Ansicht klicken, werden sie mit einem grauen Rahmen dargestellt, der anzeigt, dass die Elemente nicht bearbeitet werden können.
<G-vec00141-002-s181><indicate.anzeigen><en> When you click such elements in Live View, a grey border appears around them to indicate that the elements cannot be edited.
<G-vec00141-002-s182><indicate.anzeigen><de> Füllstandanzeige Alle Maschinen der variablen Pressenserie von McHale sind mit Ultraschallsensoren für die Füllstandanzeige ausgestattet, die dem Bediener über den Monitor anzeigt, welche Seite der Kammer befüllt werden muss.
<G-vec00141-002-s182><indicate.anzeigen><en> All machines in the McHale variable chamber baler range are fitted with ultra sonic bale shape indicators, which indicate to the operator via the control console, which side of the chamber needs to be filled.
<G-vec00141-002-s183><indicate.anzeigen><de> Bitte beachte, dass sich das NordVPN-Symbol in der Symbolleiste deines Browsers grün färbt und das Land anzeigt, mit dem du verbunden bist, sobald die Verbindung erfolgreich hergestellt wurde.
<G-vec00141-002-s183><indicate.anzeigen><en> Please note that when you are connected using the extension, NordVPN icon on your browser's toolbar will turn green and indicate the country you are connected to.
<G-vec00141-002-s185><indicate.anzeigen><de> Die Software zoneCONTROL stellt ein funkbasiertes Assistenzsystem für die Fahrer von Flurförderzeugen dar, das sowohl mit stationären Funkankern lokale Hindernisse oder Gefahrenstellen kennzeichnet als auch mittels mobil von Personen mitgeführten Sendern ihre Anwesenheit in ihrem unmittelbaren Umfeld anzeigt.
<G-vec00141-002-s185><indicate.anzeigen><en> The zoneCONTROL software is a radio-beacon based assistance system for the drivers of industrial trucks, which uses stationary radio beacons to identify local obstacles or danger points and transmitters carried by persons to indicate their presence in their immediate vicinity.
<G-vec00141-002-s186><indicate.anzeigen><de> Je niedriger die Falschalarmrate eines Systems ist, desto höher ist die Effizienz, da das System die Tablette nicht zurückweist und keinen Fehler in der Verpackung anzeigt.
<G-vec00141-002-s186><indicate.anzeigen><en> The lower the false alarm rate of a system, the higher the efficiency because the system will not reject the pill or indicate an error in the package.
<G-vec00141-002-s187><indicate.anzeigen><de> Der Mitverfasser Jim Arbogast, Vizepräsident von Hygiene-Wissenschaften und von Öffentliches Gesundheitswesen-Förderungen für GOJO, sagte, dass mehr Arbeit ausgeführt werden muss, um die Menge genau zu verstehen und das Baumuster der Seife, die erforderlich ist, schädliche Mikroben zu löschen, zwar die Studie keine Unterschiede zwischen der Menge der Seife verwendet anzeigt.
<G-vec00141-002-s187><indicate.anzeigen><en> The coauthor Jim Arbogast, Vice President of Hygiene Sciences and Public Health Advancements for GOJO, said more work needs to be carried out to understand exactly the amount and the type of soap that is needed to remove harmful microbes, though the study does not indicate any differences between the amount of soap used.
<G-vec00141-002-s188><indicate.anzeigen><de> Wenn Sie eine Saite anschlagen, greift ein Piezo-Tonabnehmer das betreffende Signal ab, woraufhin zwei Anzeigetypen leuchten: Die Diode der Saitebei der zugehörigen Stimm-Mechanik und ein LED-Meter, das die erkannte Tonhöhe anzeigt.
<G-vec00141-002-s188><indicate.anzeigen><en> When you play a single note, the built-in piezo pickup will instantly detect the pitch of the vibrating string. Two types of LEDs will light up: a string indicator LED, to indicate the peg location, and an LED meter to indicate the pitch.
<G-vec00141-002-s189><indicate.anzeigen><de> Die Originalversion des Textes erscheint vor einem grauen Hintergrund, der anzeigt, dass das Dokument bisher noch nicht übersetzt worden ist.
<G-vec00141-002-s189><indicate.anzeigen><en> In this case, the original version of the text is displayed against a grey background to indicate that it is in its original language and has not yet been translated.
<G-vec00141-002-s190><indicate.anzeigen><de> Bitte löschen Sie dieses Cookie nicht, da es uns Ihren Widerspruch anzeigt.
<G-vec00141-002-s190><indicate.anzeigen><en> Please do not delete this cookie as it will indicate your objection to data collection.
<G-vec00141-002-s191><indicate.anzeigen><de> * Dieses Netzteil verfügt über eine LED, die einen möglichen Fehler anzeigt, wenn die LED nicht leuchtet, das Netzteil jedoch angeschlossen ist.
<G-vec00141-002-s191><indicate.anzeigen><en> This power supply has an LED to indicate a possible failure condition when the LED is off and power is connected.
<G-vec00141-002-s193><indicate.anzeigen><de> Es erscheint ein „Nicht berühren“-Symbol, das den Update-Modus anzeigt.
<G-vec00141-002-s193><indicate.anzeigen><en> A “do not touch” icon appears on the display to indicate Update Mode.
<G-vec00141-002-s194><indicate.anzeigen><de> Sie können Ihren Browser so einstellen, dass er keine Cookies akzeptiert oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00141-002-s194><indicate.anzeigen><en> You can reset your web browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00141-002-s226><indicate.anzeigen><de> Cheryl war ein guter Gastgeber und war da, um uns den Weg zur Lodge per Telefon, um anzuzeigen, wenn wir sie brauchten.
<G-vec00141-002-s226><indicate.anzeigen><en> Beautiful walks start right outside your door and you can roam acreoss hillsides there to indicate us the way to the lodge via phone when we needed her.
<G-vec00141-002-s227><indicate.anzeigen><de> Auf dem Display werden Hinweise angezeigt, um dem Benutzer beim Koppeln der Geräte zu helfen, einen niedrigen Batteriestand anzuzeigen und die Kindersicherung zu entsperren.
<G-vec00141-002-s227><indicate.anzeigen><en> Guiding notifications The display helps the user pair if unpaired, indicate low battery level, and unlock the child lock.
<G-vec00141-002-s228><indicate.anzeigen><de> Der eingetragene Registrar ist der "Sponsoring Registrar" gemäß der Liste im WHOIS-Datensatz für Ihre Domäne, um anzuzeigen, bei welchem Registrar Ihre Domäne registriert ist.
<G-vec00141-002-s228><indicate.anzeigen><en> The registrar of record is the “Sponsoring Registrar” listed in the WHOIS record for your domain to indicate which registrar your domain is registered with.
<G-vec00141-002-s229><indicate.anzeigen><de> Diese Kammer des Pure Hit ändert ihre Farbe von braun nach rot, um anzuzeigen, dass sie erhitzt ist.
<G-vec00141-002-s229><indicate.anzeigen><en> This chamber of the Pure Hit changes from brown to red to indicate that the chamber is heated.
<G-vec00141-002-s230><indicate.anzeigen><de> Nach Ablauf eines Programmschrittes erscheint dahinter ein Icon, um seinen Status anzuzeigen.
<G-vec00141-002-s230><indicate.anzeigen><en> After running a program step an icon appears behind it to indicate its status.
<G-vec00141-002-s231><indicate.anzeigen><de> Wir werden Rot, Gelb und Grün als Füllfarben verwenden, um niedrige, mittlere und hohe Lebenserwartung anzuzeigen.
<G-vec00141-002-s231><indicate.anzeigen><en> We will choose Red, Yellow and Green fill colors to indicate low, medium and high life expectancy.
<G-vec00141-002-s232><indicate.anzeigen><de> Es wird auch als Pronomen verwandt, um einen Plural anzuzeigen, wie in me fella = „we“ (wir) oder „us“ (uns), you fella = „you“ (Du oder Ihr).
<G-vec00141-002-s232><indicate.anzeigen><en> It is also used with pronouns to indicate the plural, e.g. me fella = "we" or "us", you fella = "you". Lexicon[edit]
<G-vec00141-002-s233><indicate.anzeigen><de> Wenn du deine Lexar-Karte formatierst, wird die FAT-Datei der Karte, wie die Dateizuordnungstabelle, nur aktualisiert, um anzuzeigen, dass der Speicherplatz, in dem gelöschte Dateien nach dem Format gespeichert wurden, nun verfügbar ist, um neue Daten zu akzeptieren.
<G-vec00141-002-s233><indicate.anzeigen><en> When you format your Lexar card, the card’s FAT file i.e. File Allocation Table is just updated to indicate that the memory space where deleted files after format were resided is now available to accept new data.
<G-vec00141-002-s234><indicate.anzeigen><de> -Hinzugefügt wurde die Möglichkeit um die Zeit anzuzeigen, aus der die Reservierung verfügbar sein wird.
<G-vec00141-002-s234><indicate.anzeigen><en> -Added the possibility to indicate the time from which the reservation will be available.
<G-vec00141-002-s235><indicate.anzeigen><de> Zusätzlich oder alternativ dazu kann auch vorgesehen sein, den geschätzten zukünftigen Verkehrsfluss anzuzeigen.
<G-vec00141-002-s235><indicate.anzeigen><en> Additionally or alternatively, may also be provided to indicate the estimated future traffic flow.
<G-vec00141-002-s236><indicate.anzeigen><de> • Wenn du den Bamboo Sketch einschaltest, blinkt zwei Sekunden lang eine blaue LED, um anzuzeigen, dass der Stift eingeschaltet ist.
<G-vec00141-002-s236><indicate.anzeigen><en> • When you turn the Bamboo Sketch on, a blue LED blinks for two seconds to indicate that the stylus is on.
<G-vec00141-002-s237><indicate.anzeigen><de> Tatsächlich können einige Pfeile oder andere Verbindungen verwendet werden, um nur den logischen Fluss der gezeigten Ausführungsform anzuzeigen.
<G-vec00141-002-s237><indicate.anzeigen><en> Indeed, some arrows or other connectors may be used to indicate only the logical flow of the depicted embodiment.
<G-vec00141-002-s238><indicate.anzeigen><de> Das Produkt ist jetzt im Kopplungsmodus (das Unterbettlicht blinkt, um dies anzuzeigen).
<G-vec00141-002-s238><indicate.anzeigen><en> The product is now in pairing mode; The Under Bed Light will blink to indicate this
<G-vec00141-002-s239><indicate.anzeigen><de> Das neue Bedienelement „EASY Slider“ bietet darüber hinaus die Möglichkeit, Bewegungen beim Einrichten präzise zu steuern und über LEDs anzuzeigen.
<G-vec00141-002-s239><indicate.anzeigen><en> The new "EASY Slide" operating element also makes it possible to control movements precisely during setup and to indicate these via LEDs.
<G-vec00141-002-s240><indicate.anzeigen><de> Diese beiden Farben werden ebenso benutzt, um den Yachten Strafen oder Rückrufe anzuzeigen und um diese beim Zieldurchgang zu identifizieren.
<G-vec00141-002-s240><indicate.anzeigen><en> These respectively coloured flags shall also be used to indicate penalties or recalls, as well as identification when crossing the finish-line.
<G-vec00141-002-s241><indicate.anzeigen><de> Um eine Last anzuzeigen, die die Länge von 20 m überschreitet, wird ein anderes Zeichen verwendet.
<G-vec00141-002-s241><indicate.anzeigen><en> To indicate a load exceeding the length of 20 m, another sign is used.
<G-vec00141-002-s242><indicate.anzeigen><de> 25:27 Denn es scheint mir ungereimt, einen Gefangenen zu senden und nicht auch die gegen ihn vorliegenden Beschuldigungen anzuzeigen.
<G-vec00141-002-s242><indicate.anzeigen><en> 27“For it seems absurd to me in sending a prisoner, not to indicate also the charges against him.”
<G-vec00141-002-s243><indicate.anzeigen><de> Um einen Platzhalter für ein fehlendes Laufwerk hinzuzufügen (nur für RAID 5 oder RAID 6), klicken Sie auf die Schaltfläche "Platzhalter hinzufügen", um ein fehlendes Laufwerk anzuzeigen.
<G-vec00141-002-s243><indicate.anzeigen><en> To add a placeholder for a missing drive (only for degraded RAID 5 or RAID 6), press the "Add placeholder to indicate missing disk" button.
<G-vec00141-002-s244><indicate.anzeigen><de> Wenn ihr die Wendung „de“ verwendet um einen Genetiv anzuzeigen, dann meint das stets, dass etwas zu jemandem gehört.
<G-vec00141-002-s244><indicate.anzeigen><en> When you employ the locution "de" to indicate a genitive, this always means that something belongs to someone.
<G-vec00141-002-s780><indicate.anzeigen><de> Dies zeigt ihre Stimmung an; Kunden mit mehr Herz zeigen an, dass sie glücklicher sind.
<G-vec00141-002-s780><indicate.anzeigen><en> This indicates their mood; customers with more hearts indicate that they are happier.
<G-vec00141-002-s782><indicate.anzeigen><de> Die Ziffern in jedem Bereichsabschnitt zeigen ein Vielfaches von alpha an.
<G-vec00141-002-s782><indicate.anzeigen><en> 6 shows the state of this middle The numbers in each area portion indicate a multiple of alpha.
<G-vec00141-002-s783><indicate.anzeigen><de> Sie zeigen an, in welcher semantischen Beziehung verbundene Aussagen stehen (Noordman & Vonk, 1997) und können somit die Integration der Information in eine kohärente mentale Repräsentation unterstützen.
<G-vec00141-002-s783><indicate.anzeigen><en> They indicate the semantic relationship between connected statements (Noordman & Vonk, 1997). So they can support the integration of information in a coherent representation.
<G-vec00141-002-s784><indicate.anzeigen><de> Die Lichter auf den Hörgeräten zeigen den Ladezustand an, wenn das Ladegerät eingesteckt ist.
<G-vec00141-002-s784><indicate.anzeigen><en> The lights on the hearing aids will indicate charging status when the charger is plugged in.
<G-vec00141-002-s785><indicate.anzeigen><de> Diese zwei Punkte zeigen an, dass die Kaffeebohnen am besten versiegelt sind.
<G-vec00141-002-s785><indicate.anzeigen><en> These two points indicate that the coffee beans are best sealed.
<G-vec00141-002-s786><indicate.anzeigen><de> Die Eigenschaften zeigen an, zu welchen Sets das ausgewählte Asset gehört (unter Mitglied von Sets).
<G-vec00141-002-s786><indicate.anzeigen><en> Properties indicate what sets the selected asset is a member of (under Member of Sets).
<G-vec00141-002-s787><indicate.anzeigen><de> Differenzdruckmessgeräte können als Indikator für eine Verstopfung des Filterelements genutzt werden, zeigen aber nicht an, wann ein Filterelement gewechselt werden muss.
<G-vec00141-002-s787><indicate.anzeigen><en> Differential pressure gauges can be used as an indicator of filter element clogging, but do not indicate when a filter element needs to be replaced.
<G-vec00141-002-s788><indicate.anzeigen><de> Das Projektsymbol und die Textfarbe zeigen die Zugriffsrechte für ein Projekt an.
<G-vec00141-002-s788><indicate.anzeigen><en> The project icon and text color indicate the permissions you have for the project.
<G-vec00141-002-s789><indicate.anzeigen><de> “Paulus Ansicht wurde nicht von allen akzeptiert oder, so könnte jemand argumentieren, sogar weit anerkannt … Noch treffender, Paulus eigenen Briefe zeigen an, das es ausgesprochene, ernsthafte und aktive christliche Führer gab, die ihm deshalb vehement widersprachen und die Paulus Ansichten für eine Verdrehung der wahren Botschaft des Christus hielten...
<G-vec00141-002-s789><indicate.anzeigen><en> “Paul’s view was not universally accepted or, one might argue, even widely accepted …. Even more striking, Paul’s own letters indicate that there were outspoken, sincere, and active Christian leaders who vehemently disagreed with him on this score and considered Paul’s views to be a corruption of the true message of Christ ….
<G-vec00141-002-s790><indicate.anzeigen><de> Diese HTTP-Statuscodes zeigen an, dass der Server die Anforderung wegen eines Fehlers nicht ausführen kann.
<G-vec00141-002-s790><indicate.anzeigen><en> These HTTP status codes indicate that the server cannot complete the request because the server encounters an error.
<G-vec00141-002-s791><indicate.anzeigen><de> Diese zeigen unter anderem durch Blinken die verschiedenen Arbeitsprozesse und den Lichtstatus an, aber auch durch das Dauerlicht.
<G-vec00141-002-s791><indicate.anzeigen><en> These indicate the different work processes and lighting status by flashing, among other things, but also by the continuous light.
<G-vec00141-002-s792><indicate.anzeigen><de> Separate LEDs zeigen Kurzschlüsse für jeden 9V-Anschluss separat an.
<G-vec00141-002-s792><indicate.anzeigen><en> Individual LEDs indicate short circuits for each of the 9V outputs.
<G-vec00141-002-s793><indicate.anzeigen><de> Positiv: Eindeutige Farbbänder erscheint auf den Steuer- und Testregionen, Testlinie und Steuerleitung zeigen an, dass Sie schwanger sind.
<G-vec00141-002-s793><indicate.anzeigen><en> Positive:Distinct color bands appears on the control and test regions,Both test line and control line indicate that you are pregnant.
<G-vec00141-002-s794><indicate.anzeigen><de> Im Gegensatz zu anderen Monitoren zeigen Omron-Monitore die zwei Druckwerte und die Pulsfrequenzzahl mit der Zeit und dem Aufzeichnungsstrom an.
<G-vec00141-002-s794><indicate.anzeigen><en> Unlike other monitors, Omron Monitors indicate the two pressure values and the pulse rate figure with time and recording stream.
<G-vec00141-002-s795><indicate.anzeigen><de> - Renko Charts zeigen klar Unterstützung und Widerstand an.
<G-vec00141-002-s795><indicate.anzeigen><en> - Renko charts clearly indicate support and resistance.
<G-vec00141-002-s796><indicate.anzeigen><de> Die Abmessungen der Anhänger zeigen an, dass entweder die ballistischen Raketensysteme SS-3 oder SS-4 beteiligt sind.
<G-vec00141-002-s796><indicate.anzeigen><en> The dimensions of the trailers indicate that either the SS-3 or SS-4 ballistic missile systems are involved.
<G-vec00141-002-s797><indicate.anzeigen><de> Die roten gestrichelten Linien zeigen dabei die Ränder der Fahrspur an, man muss die Breiten seiner Arbeitsgeräte also nicht auswendig wissen.
<G-vec00141-002-s797><indicate.anzeigen><en> The red dashed lines indicate for the edges of the lane, you have the width of its attachments do not know by heart so.
<G-vec00141-002-s798><indicate.anzeigen><de> Gefrorene Pfützen und runny Farbe auf der Haut zeigen an, dass der Fisch aufgetaut und wieder eingefroren war.
<G-vec00141-002-s798><indicate.anzeigen><en> Frozen puddles and runny color on the skin indicate that the fish has thawed and was refrozen.
<G-vec00141-002-s839><indicate.anzeigen><de> Sobald alle abgestimmt haben oder die Zeit abgelaufen ist, dreht sich der Pfeil und zeigt an, wer die meisten Stimmen erhalten hat.
<G-vec00141-002-s839><indicate.anzeigen><en> Once everyone has voted or the time has elapsed, the arrow spins to indicate who received the most votes.
<G-vec00141-002-s840><indicate.anzeigen><de> Ein Sentinel X100 Schnelltest zeigt an, ob ein System ausreichend mit Sentinel X100 Inhibitor behandelt wurde, um es vor Korrosion und Kalkbildung zu schützen.
<G-vec00141-002-s840><indicate.anzeigen><en> A Sentinel X100 Test Kit will indicate whether a system has been sufficiently treated with Sentinel X100 Inhibitor to protect it against corrosion and limescale.
<G-vec00141-002-s841><indicate.anzeigen><de> Die Maschine stoppt automatisch, wenn es Probleme gibt und zeigt die Ursache der Störungen über den Touchscreen an.
<G-vec00141-002-s841><indicate.anzeigen><en> Machine will be stop automatically if there is some troubles with it and indicate the cause of the troubles via the touch screen.
<G-vec00141-002-s842><indicate.anzeigen><de> Das Vorhandensein einer dicken Linie über einem Table-Scan zeigt an, dass die Erstellung eines Index möglicherweise erforderlich ist.
<G-vec00141-002-s842><indicate.anzeigen><en> The presence of a thick line over a table scan may indicate that the creation of an index might be required.
<G-vec00141-002-s843><indicate.anzeigen><de> Möglicherweise zeigt man anderen Nutzern nicht mehr nur seinen eigenen Standort an, sondern überträgt auch gleich Bilder in Echtzeit.
<G-vec00141-002-s843><indicate.anzeigen><en> Possibly one does not indicate other users any more only his own location, but transfers also immediately pictures on a real-time basis.
<G-vec00141-002-s844><indicate.anzeigen><de> Ein Kreis von Punkten zeigt an, dass es mit dem existierende Node verschmolzen wird.
<G-vec00141-002-s844><indicate.anzeigen><en> A circle of dots will indicate that it is joining to the existing node.
<G-vec00141-002-s845><indicate.anzeigen><de> Das „Scoreboard“ zeigt also keine Trends der privatwirtschaftlichen FuE-Intensität an, d. h. des Forschungsaufwands der Unternehmen in einem bestimmten Land oder einer bestimmten Region als Anteil des Bruttoinlandsprodukts und unabhängig davon, ob die Forschungsausgaben durch einheimische Firmen oder in Form ausländischer Direktinvestitionen getätigt werden.
<G-vec00141-002-s845><indicate.anzeigen><en> It does not therefore indicate trends in private sector R&D intensity – business R&D expenditure in a particular country or region as a proportion of GDP, whether that expenditure is by home-grown companies or through inward investment.
<G-vec00141-002-s846><indicate.anzeigen><de> Zeigt den neuen Freund eurer Ex als terrorverdächtig bei der Polizei an.
<G-vec00141-002-s846><indicate.anzeigen><en> Indicate the new boyfriend of your ex as a terror suspect.
<G-vec00141-002-s847><indicate.anzeigen><de> Verbesserte Aufnahmebenachrichtigung: Das Symbol My Screen Recorder Pro in der Taskleiste und im Infobereich blinkt kontinuierlich und zeigt den aktuellen Status der Bildschirmaufnahme an.
<G-vec00141-002-s847><indicate.anzeigen><en> Enhanced recording notification: My Screen Recorder Pro icon on the taskbar and notification area will continuously flash and will indicate the current state of screen recording.
<G-vec00141-002-s848><indicate.anzeigen><de> Außerdem zeigt das Dokument den Preis an, den Sie zusammen mit dem Makler definieren.
<G-vec00141-002-s848><indicate.anzeigen><en> Also, the document will indicate the price that you define together with the realtor.
<G-vec00141-002-s850><indicate.anzeigen><de> Der grüne Knopf mit weissen Pfeil zeigt eine erfolgreiche Verbindung an.
<G-vec00141-002-s850><indicate.anzeigen><en> A green arrow will indicate that a successful connection has been established.
<G-vec00141-002-s851><indicate.anzeigen><de> Der Schnittpunkt der Diagonalen der Schnüre zeigt die Position des Druckflansches an.
<G-vec00141-002-s851><indicate.anzeigen><en> The point of intersection of the diagonals of the cords will indicate the location of the thrust flange.
<G-vec00141-002-s852><indicate.anzeigen><de> Die Spalte "Integer Data" des Exception-Ereignisses zeigt alle Fehler an, die an den Client zurückgegeben wurden.
<G-vec00141-002-s852><indicate.anzeigen><en> The integer data column of the exception event will indicate any errors that were returned back to the client.
<G-vec00141-002-s853><indicate.anzeigen><de> Ja, aber die Analyse zeigt die Treffer in Ihren vorherigen Versionen an.
<G-vec00141-002-s853><indicate.anzeigen><en> Yes, but the Analysis will indicate hits in your previous versions.
<G-vec00141-002-s854><indicate.anzeigen><de> Die leuchtende grüne LED zeigt an, dass eine Funktion aktiviert ist.
<G-vec00141-002-s854><indicate.anzeigen><en> The green LED glows to indicate that a feature is enabled.
<G-vec00141-002-s855><indicate.anzeigen><de> Das Gerät informiert den Bediener sofort über die Größe der Leckage und zeigt an, ob die Leckage über oder unter dem voreingestellten Grenzleckagerate liegt.
<G-vec00141-002-s855><indicate.anzeigen><en> The detector will immediately tell the operator the size of the leak and also indicate if the leak was below or above the preset leak limit (accept/reject).
<G-vec00141-002-s857><indicate.anzeigen><de> Dunkelgrün zeigt einen Count an.
<G-vec00141-002-s857><indicate.anzeigen><en> Dark green lines indicate a count.
<G-vec00141-002-s019><show.anzeigen><de> Bitte beachtet, dass einige dieser Änderungen noch nicht vollständig übersetzt sind und somit auch dann auf Englisch angezeigt werden, wenn ihr eine andere Sprache eingestellt habt.
<G-vec00141-002-s019><show.anzeigen><en> Note that some of the changes still need to be properly translated and will show up in English even if you’ve selected another language.
<G-vec00141-002-s020><show.anzeigen><de> In Zwei-Weg-Dateien werden nur Unterschiede, keine Konflikte angezeigt.
<G-vec00141-002-s020><show.anzeigen><en> Two-way comparisons show only differences, no conflicts.
<G-vec00141-002-s021><show.anzeigen><de> Zusätzlich werden einige Informationen zu den Ländern angezeigt: Bevölkerung, Hauptstadt, Landessprache, etc.
<G-vec00141-002-s021><show.anzeigen><en> Also, we show you some informations of this country: population, capital, its language, etc.
<G-vec00141-002-s022><show.anzeigen><de> Vor dem Schritt zur Eingabe Ihrer Kundendaten werden die enthaltenen Apps angezeigt.
<G-vec00141-002-s022><show.anzeigen><en> Before entering your customer info, the process will show you the apps included.
<G-vec00141-002-s023><show.anzeigen><de> Neben Ihrer Bestellung finden Sie den Link zur Sendungsverfolgung; wenn Sie diesen anklicken, wird Ihnen der aktuelle Status Ihrer Bestellung angezeigt.
<G-vec00141-002-s023><show.anzeigen><en> Your order will be updated with the courier tracking link which, once clicked, will show you the status of your delivery.
<G-vec00141-002-s024><show.anzeigen><de> Im eingeblendeten Fenster wird Ihnen die gesamte Kapazität, der verfügbare und der verwendete Speicherplatz angezeigt.
<G-vec00141-002-s024><show.anzeigen><en> The window that opens will show you the Total Capacity, Available Space, and Used Space.
<G-vec00141-002-s025><show.anzeigen><de> Jedoch wird die Zeit nicht angezeigt, wann genau das Geschenk erhalten wurde.
<G-vec00141-002-s025><show.anzeigen><en> However, it will not show the time when the gift was received.
<G-vec00141-002-s026><show.anzeigen><de> Beachte aber, dass in der Nest App nur die Geräte angezeigt werden, die in der Nest App eingerichtet wurden.
<G-vec00141-002-s026><show.anzeigen><en> The Nest app will only show devices that were set up in the Nest app.
<G-vec00141-002-s027><show.anzeigen><de> Das Startvolume des alten Computers sollte nun im Finder angezeigt werden, wenn Sie auf dem neuen Computer angemeldet sind.
<G-vec00141-002-s027><show.anzeigen><en> The startup drive of the old computer should now show up in the Finder when you are logged in on the new computer.
<G-vec00141-002-s028><show.anzeigen><de> In diesem Feld werden die Suchabfragen angezeigt, die Sie als Favoriten speichern.
<G-vec00141-002-s028><show.anzeigen><en> This panel will show the searches you save as sale in Cala Millor
<G-vec00141-002-s029><show.anzeigen><de> So werden u. a. die gebuchten Gemeinkosten und die zugrunde liegenden Einzelkosten angezeigt.
<G-vec00141-002-s029><show.anzeigen><en> This will show, for example, the posted overheads and underlying direct costs.
<G-vec00141-002-s030><show.anzeigen><de> Sie werden vor allen anderen in unserer Datenbasis angezeigt (Wenn die Firmen Berwerbe suchen, werden Sie als erster angezeigt wenn Sie einen Premium Account haben).
<G-vec00141-002-s030><show.anzeigen><en> You will show up among the first candidates in our Database (when employers search for candidates, you will appear on the search results before the rest of the job seekers)..
<G-vec00141-002-s031><show.anzeigen><de> Der Veranstaltungsort kann auf einer Landkarte angezeigt werden.
<G-vec00141-002-s031><show.anzeigen><en> You can show the event place on the map.
<G-vec00141-002-s032><show.anzeigen><de> Benannte Personengruppen werden immer oberhalb der unbenannten Gruppen angezeigt.
<G-vec00141-002-s032><show.anzeigen><en> Named people clusters always show up above the unnamed clusters.
<G-vec00141-002-s033><show.anzeigen><de> Da die NBA den Exklusivrechten für diese Stationen zustimmt, werden in NBA League Pass keine Live-Spiele angezeigt, wenn die Aktionen ausgeführt werden.
<G-vec00141-002-s033><show.anzeigen><en> Because the NBA agrees to exclusive rights for those stations, even streaming services won’t show live games as the action happens.
<G-vec00141-002-s034><show.anzeigen><de> Alle eingereichten Seiten: Es werden nur die Seiten angezeigt, die mithilfe dieses Berichts in einer Sitemap oder über einen Sitemap-Ping eingereicht wurden.
<G-vec00141-002-s034><show.anzeigen><en> All submitted pages - Show only pages submitted in a sitemap to this report or by sitemap ping.
<G-vec00141-002-s035><show.anzeigen><de> Bitte beachte, dass keine Social Media Icons angezeigt werden, wenn keine URLs eingegeben wurden.
<G-vec00141-002-s035><show.anzeigen><en> Please note that the icons will not show up when no URLs are entered.
<G-vec00141-002-s036><show.anzeigen><de> Diese Richtlinieneinstellung steuert, ob benutzerdefinierte Vorlagen (falls welche vorhanden sind) in PowerPoint auf dem Office-Startbildschirm und im Bereich "Datei"| "Neu" als Standardregisterkarte angezeigt werden.
<G-vec00141-002-s036><show.anzeigen><en> This policy setting controls whether custom templates (when they exist) show as the default tab in PowerPoint on the Office Start screen and in File | New.
<G-vec00141-002-s037><show.anzeigen><de> Wählen Sie Ihr Wunschdatum aus und Ihnen werden alle Verbindungen angezeigt, die an dem Tag im Juli ab Oslo (OSL) angeboten werden.
<G-vec00141-002-s037><show.anzeigen><en> Select your desired date and we'll show you all the flights for that day in August 2017 from Oslo (OSL).
<G-vec00141-002-s038><show.anzeigen><de> (Optional) Filterkriterien anzeigen.
<G-vec00141-002-s038><show.anzeigen><en> (Optional) Show filter criteria.
<G-vec00141-002-s039><show.anzeigen><de> Klicken Sie bitte auf den Link "Kontaktdaten anzeigen" und schreiben an ADL Anti Dekubitus Lagerungssysteme GmbH eine Mail.
<G-vec00141-002-s039><show.anzeigen><en> Please click on the green button "Show contact details" and send a message regarding Wound supply systems to ADL Anti Dekubitus Lagerungssysteme GmbH.
<G-vec00141-002-s040><show.anzeigen><de> 0.8 km zu Griechisches Parlament (Karte anzeigen) Die Villa The White House Plaka liegt im Stadtteil Psyrri direkt neben einem Museum und einem Tempel.
<G-vec00141-002-s040><show.anzeigen><en> 0.8 km to Greek Parliament (Show map) The White House Plaka hosts up to 11 guests in vicinity of Acropolis Museum.
<G-vec00141-002-s041><show.anzeigen><de> Town Home In A Quiet Neighborhood 411 Teague Drive, Lewisville, United States (Karte anzeigen) Die Villa ist 60 Autominuten von Six Flags Over Texas.
<G-vec00141-002-s041><show.anzeigen><en> 512 South Jefferson Street, Irving, United States (Show map) The property is 10 minutes' walk from center of Irving. Such Irving sights as Six Flags Over Texas and Six…
<G-vec00141-002-s042><show.anzeigen><de> Tipp Wenn Mehr Kacheln anzeigen aktiviert ist, können Kacheln immer noch verschoben und die Größe angepasst werden – nur, dass Sie jetzt noch mehr Kacheln auf Ihrer Startseite anordnen können.
<G-vec00141-002-s042><show.anzeigen><en> Tip When Show more Tiles is on, Tiles can still be resized and moved as before, except now you can fit more Tiles on your Start screen.
<G-vec00141-002-s043><show.anzeigen><de> 0.7 km zu San Francisco Railway Museum (Karte anzeigen) Das 5-Sterne Mandarin Oriental San Francisco befindet sich ungefähr 8 km entfernt von Golden Gate Bridge.
<G-vec00141-002-s043><show.anzeigen><en> 0.7 km to San Francisco Railway Museum (Show map) The 5-star Mandarin Oriental San Francisco provides guests with a luxury accommodation in San Francisco.
<G-vec00141-002-s044><show.anzeigen><de> 1.8 km zu Riga Congress Centre (Karte anzeigen) Dieses zentrale Hostel bietet allergenfreie Zimmer und einen Safe.
<G-vec00141-002-s044><show.anzeigen><en> 1.8 km to Riga Congress Centre (Show map) The central Gogol Park Hostel offers bright guestrooms.
<G-vec00141-002-s045><show.anzeigen><de> Wie immer bei Werbung mit Google Ads konkurrieren Ihre Anzeigen auch hier mit den Anzeigen anderer Werbetreibender.
<G-vec00141-002-s045><show.anzeigen><en> As with all Google Ads, you'll compete with other advertisers to show your ads on placements you select.
<G-vec00141-002-s046><show.anzeigen><de> 0.3 km zu Koltso Shopping Centre (Karte anzeigen) Bilyar Palace ist ein 10-stöckiges Hotel im Zentrum von Kazan, das 126 klassische Zimmer umfasst und in der Nähe zu Hermitage, Millennium Bridge und Saint Peter and Saint Paul Cathedral liegt.
<G-vec00141-002-s046><show.anzeigen><en> 0.3 km to Koltso Shopping Centre (Show map) Located in the center of Kazan within a 20-minute walk of Hermitage, Bilyar Palace is a 10-story hotel offering 126 comfortable rooms.
<G-vec00141-002-s047><show.anzeigen><de> 0.1 km zu Rathaus Tallinn (Karte anzeigen) Während eines Besuchs von Reval können Gäste im Apartment Town Hall Square Apartments - Old Town übernachten.
<G-vec00141-002-s047><show.anzeigen><en> 0.1 km to Tallinn Townhall (Show map) Town Hall Square Apartments - Old Town apartment provides a comfortable stay in Tallinn.
<G-vec00141-002-s048><show.anzeigen><de> 2.2 km zu Wadi Bandar (Karte anzeigen) Das komfortable Sea Green Hotel ist eine 3-Sterne Unterkunft in der Nähe von Gateway of India und Marine Drive.
<G-vec00141-002-s048><show.anzeigen><en> 2.2 km to Wadi Bandar (Show map) The 2-star Sea Green Hotel offers modern rooms in Churchgate district of Mumbai.
<G-vec00141-002-s049><show.anzeigen><de> Im Katalog anzeigen Abgestimmte hellgraue Bindungssysteme ermöglichen den ELASTIC Schleifstiften sowohl einen universellen als auch einen anwendungsspezifischen Einsatz.
<G-vec00141-002-s049><show.anzeigen><en> Show in catalog Coordinated light grey bond systems enable the ELASTIC mounted points to be put to both universal use and use tailored to the application.
<G-vec00141-002-s050><show.anzeigen><de> 2.4 km zu Monumento a la Revolución (Karte anzeigen) Ferienwohnung Jalapa ist ein Apartment 1.6 km von Torre Mayor, El Ángel de la Independencia und Schloss Chapultepec.
<G-vec00141-002-s050><show.anzeigen><en> 2.4 km to Revolution Monument (Show map) Jalapa is an apartment only 1.5 km from The Angel of Independence.
<G-vec00141-002-s051><show.anzeigen><de> Doppelklicken Sie im Dialogfeld Tabelle anzeigen auf jede Tabelle oder Abfrage, die Sie als Datensatzquelle verwenden möchten.
<G-vec00141-002-s051><show.anzeigen><en> In the Show Table dialog box, double-click each table or query that you want to use as a record source.
<G-vec00141-002-s052><show.anzeigen><de> Dadurch können wir Ihnen interaktive Karten direkt in der Website anzeigen und ermöglichen Ihnen die komfortable Nutzung der Karten-Funktion.
<G-vec00141-002-s052><show.anzeigen><en> This allows us to show you interactive maps directly on our website, allowing you to conveniently use the map function to find our location and get easy directions to us.
<G-vec00141-002-s053><show.anzeigen><de> 0.8 km zu Zeustempel (Karte anzeigen) Im Stadtteil Neos Kosmos von Athen gelegen, ist das Apartment Ermou Budget Studios By Livin Urbban 20 km vom Flughafen Athen-Eleftherios Venizelos.
<G-vec00141-002-s053><show.anzeigen><en> 0.8 km to Olympeion (Show map) Set in Neos Kosmos district of Athens, Ermou Budget Studios By Livin Urbban apartment has WiFi and offers a quick access to B/2.
<G-vec00141-002-s054><show.anzeigen><de> Durch einen Mausklick auf den Link 'Relevante Produkte anzeigen' (6) sehen Sie die Produkte/Dienstleistungen, für die Sie den Gutschein einlösen können.
<G-vec00141-002-s054><show.anzeigen><en> By clicking the 'Show possible products' link (6) you can see the products/services for which you can use the voucher.
<G-vec00141-002-s055><show.anzeigen><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00141-002-s055><show.anzeigen><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00141-002-s056><show.anzeigen><de> 2.4 km zu Hadrianstor (Karte anzeigen) Während eines Besuchs von Athen können Gäste im Apartment Feel Home By Mc Queen übernachten.
<G-vec00141-002-s056><show.anzeigen><en> 2.4 km to Hadrian's Arch (Show map) Feel Home By Mc Queen apartment hosts guests of Athens.
