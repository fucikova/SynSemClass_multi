<G-vec00231-001-s060><favor.bevorzugen><de> Als Teil dieser Aufgabe verfügt er über ein Prioritätenkonzept, das es ihm erlaubt, je nach Bedarf bestimmte Prozesse gegenüber anderen zu bevorzugen.
<G-vec00231-001-s060><favor.bevorzugen><en> As a part of this task, it has a concept of priority, which allows it to favor certain processes over others, as needed.
<G-vec00231-001-s061><favor.bevorzugen><de> hotels online booking best price guarantieed - - ihr Glaube an ihn, wie und ihre häufigen Versuche, ihn vorzubereiten, um zu bevorzugen durch Geschenke der großen Großartigkeit anges sport t. Nicht jeder könnte solche Spielraum wie Crcesus geben, um sicher zu sein.
<G-vec00231-001-s061><favor.bevorzugen><en> hotels online booking best price guarantieed - -their belief in it as inspired, and their frequent attempts to predispose it to favor by gifts of great magnificence. Not everybody could give such offerings as Crcesus, to be sure.
<G-vec00231-001-s062><favor.bevorzugen><de> Wir könnten auch einen gewissen Prozentsatz von Personen nennen, die nicht in allen jede Art von Anti-Viren-Software-Anwendung zu haben, bevorzugen.
<G-vec00231-001-s062><favor.bevorzugen><en> We could also mention some percentage of individuals who favor not to have any type of anti-virus software application in all.
<G-vec00231-001-s063><favor.bevorzugen><de> Die Wahl, welches Spiel zu spielen, ist offensichtlich (das Euro-Spiel spielen), es sei denn, Sie herausfinden, dass das Casino bestimmte Regeln hat, die die USA Spiel bevorzugen.
<G-vec00231-001-s063><favor.bevorzugen><en> The choice of which game to play is obvious (play the Euro game), unless you find out that the casino has specific rules which favor the USA game.
<G-vec00231-001-s064><favor.bevorzugen><de> Für alle Hauttypen empfohlen, insbesondere für Kundinnen, die eine leichte Struktur bevorzugen.
<G-vec00231-001-s064><favor.bevorzugen><en> Recommended for all skin types, in particular those we favor lightweight textures.
<G-vec00231-001-s065><favor.bevorzugen><de> Große Unternehmen bevorzugen Absolventen, die auf ihren Füßen und Ansatz Geschäftsprobleme aus einer Vielzahl von verschiedenen Perspektiven zu denken.
<G-vec00231-001-s065><favor.bevorzugen><en> Large companies favor graduates who can think on their feet and approach business problems from a variety of different perspectives.
<G-vec00231-001-s066><favor.bevorzugen><de> Der Abgeordnete kündigte Widerstand der AfD im Bundestag an, sollte der Bund den Verkehrsträger Elektro aus „ideologischen Gründen“ bevorzugen.
<G-vec00231-001-s066><favor.bevorzugen><en> "The deputy announced resistance of the AFD in the Bundestag, the federal government should favor the transport of electric ""ideological reasons""."
<G-vec00231-001-s067><favor.bevorzugen><de> Sogar mischende und zusammenpassende Systeme, um irgendjemandes eigene Position zu bevorzugen können viel Bestürzung verursachen.
<G-vec00231-001-s067><favor.bevorzugen><en> Even mixing and matching systems to favor one's own position can cause a great deal of consternation.
<G-vec00231-001-s068><favor.bevorzugen><de> Um in ihre Anliegen sind, eine wachsende Zahl von Frauen bevorzugen derzeit Jungs, die einen größeren Penis haben.
<G-vec00231-001-s068><favor.bevorzugen><en> To contribute to their worries, increasingly more females currently favor males that have a larger penis.
<G-vec00231-001-s069><favor.bevorzugen><de> Wenn Sie als Taucher viel reisen, Gewicht reduzieren oder einfach eine leichte Flosse bevorzugen, suchen Sie nicht weiter.
<G-vec00231-001-s069><favor.bevorzugen><en> If you are a traveling diver, looking to reduce weight or just favor a lightweight fin, look no further.
<G-vec00231-001-s070><favor.bevorzugen><de> Mit Ausnahme von Julian der Apostat, Constantine Neffe nachfolgenden römischen Kaiser weiterhin die christliche Religion zu bevorzugen.
<G-vec00231-001-s070><favor.bevorzugen><en> Except for Julian the Apostate, Constantine’s nephew, subsequent Roman emperors continued to favor the Christian religion.
<G-vec00231-001-s071><favor.bevorzugen><de> Die Idee war, dass Regierung nicht, braucht einen ausgeglichenen Etat zu haben in allen Jahren - da engstirnige Republikaner schienen zu bevorzugen - aber Ausgabe regulieren sollte, um Überflüsse der Konjunktur abzuschwächen.
<G-vec00231-001-s071><favor.bevorzugen><en> The idea was that government need not have a balanced budget in all years - as narrow-minded Republicans seemed to favor - but should regulate spending to mitigate excesses of the business cycle.
<G-vec00231-001-s072><favor.bevorzugen><de> Die gewählte Ausstattung ist schlicht, einfach und gleichzeitig elegant, die ideale Wahl für all jene, die den Komfort bei einem Aufenthalt im Hotel bevorzugen.
<G-vec00231-001-s072><favor.bevorzugen><en> The furnishings chosen are sober and simple yet elegant, the ideal choice for those who favor comfort when staying in a hotel.
<G-vec00231-001-s073><favor.bevorzugen><de> (Genese 12: 3) Wurden Christen folglich geraten, die Juden zu bevorzugen und zu helfen.
<G-vec00231-001-s073><favor.bevorzugen><en> (Genesis 12: 3) Christians were thus advised to favor and help the Jews.
<G-vec00231-001-s074><favor.bevorzugen><de> Der einzige Weg zu den Suchmaschinen, Ihre Website zu bevorzugen ist, Inhalte zu verwenden, das einzigartig und sehr gezielte.
<G-vec00231-001-s074><favor.bevorzugen><en> The only way to get the search engines to favor your site is to use content that’s unique and highly targeted.
<G-vec00231-001-s075><favor.bevorzugen><de> Das Gehirn beginnt deshalb, das andere Auge zu bevorzugen, das nicht schlechte Vision hat.
<G-vec00231-001-s075><favor.bevorzugen><en> The brain therefore starts to favor the other eye that does not have poor vision.
<G-vec00231-001-s076><favor.bevorzugen><de> Einige bevorzugen mehr Frauen mit großen Titten plus eine schlaffe Bauch.
<G-vec00231-001-s076><favor.bevorzugen><en> Some favor more women with large tits plus a flabby stomach.
<G-vec00231-001-s077><favor.bevorzugen><de> 2007-11-13 22:16:19 - Fliegen GEGEN Das Fahren Wenn Kraftstoffkosten so hoch sind, bevorzugen Leute Fliegen zum Fahren.
<G-vec00231-001-s077><favor.bevorzugen><en> 2007-11-13 22:16:19 - Flying vs driving When fuel costs are so high, people favor flying to driving.
<G-vec00231-001-s078><favor.bevorzugen><de> Bei unserer Anlage in malaysischen Aktien sind wir wählerisch und bevorzugen Konsumwerte, für die wir im Zuge dieser Trends langfristig Wachstum absehen.
<G-vec00231-001-s078><favor.bevorzugen><en> As investors in Malaysian equities, we are selective, and we favor consumer stocks because that is where we see growth in the long term in line with these trends.
<G-vec00231-001-s079><favor.bevorzugen><de> Zahlungsschutz funktioniert oft zum Nachteil von Unternehmen – Jeder, der mit PayPal oder seiner Schwesterfirma eBay eine Rückbuchung vorgenommen hat, weiß, dass der PayPal-Zahlungsschutz den Kunden gegenüber dem Unternehmen bevorzugt.
<G-vec00231-001-s079><favor.bevorzugen><en> Payment protection often works against businesses – Anyone who has faced a chargeback or returns with PayPal or their sister company eBay knows that PayPal payment protection tends to favor the customer over the business.
<G-vec00231-001-s080><favor.bevorzugen><de> Dann, wenn sich öffentliche Meinung ändert, erkennt die Person, dass die Meinung weniger bevorzugt ist.
<G-vec00231-001-s080><favor.bevorzugen><en> Then, if public sentiment changes, the person will recognize that the opinion is less in favor.
<G-vec00231-001-s081><favor.bevorzugen><de> Schon in der Planung und Entwicklung unserer Produkte werden umweltfreundliche Produktionsverfahren und Produkte bevorzugt, um Abfälle, Abwässer und Emissionen zu vermeiden oder zu reduzieren.
<G-vec00231-001-s081><favor.bevorzugen><en> We favor eco-friendly manufacturing methods and products that either avoid or reduce waste, waste water and emissions.
<G-vec00231-001-s082><favor.bevorzugen><de> Parallel dazu wird das Ministerium für öffentliche Arbeiten bei einer transparenten Ausschreibungspolitik unterstützt und angeregt, dass nationale Baufirmen bei der Auftragsvergabe bevorzugt werden.
<G-vec00231-001-s082><favor.bevorzugen><en> In a parallel process, the project is supporting the Ministry of Public Works in introducing transparent tendering policies which favor national construction companies.
<G-vec00231-001-s083><favor.bevorzugen><de> Heute werden Soft-Dog-Trainingsmethoden bevorzugt, mit denen Service- und Haushunde in verschiedenen Teams trainiert werden können.
<G-vec00231-001-s083><favor.bevorzugen><en> Today, soft dog training methods are in favor, which can be used to train service and domestic dogs to various teams
<G-vec00231-001-s084><favor.bevorzugen><de> Angreifer nutzen bevorzugt Standards, weil sie automatisierte Werkzeuge für ihre Angriffe nutzen.
<G-vec00231-001-s084><favor.bevorzugen><en> Attackers favor using defaults because they use automated tools for their attacks.
<G-vec00231-001-s085><favor.bevorzugen><de> Dabei wird man auch oft entscheiden müssen welches Ausstattungsdetail man einem anderen bevorzugt, da nicht alles miteinander erhältlich oder kombinierbar ist.
<G-vec00231-001-s085><favor.bevorzugen><en> In doing so you often have to decide which equipment detail you favor since not every one is available together or combinable.
<G-vec00231-001-s086><favor.bevorzugen><de> Wenn der voraussichtliche Geschworene sagt, daß er die Todesstrafe bevorzugt, wird der Staatsanwalt diesen Geschworenen befragen.
<G-vec00231-001-s086><favor.bevorzugen><en> But if the prospective juror says that they favor the death penalty, the prosecutor will question this juror.
<G-vec00297-002-s105><opt.bevorzugen><de> WordPress-User bevorzugen meistens den Schnell-Export und speichern die Datei im SQL-Format.
<G-vec00297-002-s105><opt.bevorzugen><en> In the majority of cases, WordPress users opt for ‘Quick’ export and save the file in the ‘SQL’ format.
<G-vec00297-002-s106><opt.bevorzugen><de> Sie können auch bevorzugen die Tablette nach dem Training mit dem Essen zu konsumieren.
<G-vec00297-002-s106><opt.bevorzugen><en> You can also opt to take the capsule after exercise with your meal.
<G-vec00297-002-s107><opt.bevorzugen><de> Sie bevorzugen zu bummeln entlang der Dender oder die Schelde.
<G-vec00297-002-s107><opt.bevorzugen><en> You can also opt to stroll along the banks of the Dender or the Schelde.
<G-vec00297-002-s108><opt.bevorzugen><de> Bei uns genießen Sie nicht nur in einem gemütlichen Ambiente, sondern bekommen auch die gesamte Bandbreite der indischen Küche geboten – ganz gleich, ob Sie dabei Gerichte mit Fisch oder Fleisch, Curry oder Gegrilltes, vegetarische oder vegane Spezialitäten bevorzugen.
<G-vec00297-002-s108><opt.bevorzugen><en> At our restaurant you’ll enjoy a cosy ambience as well as a wide range of Indian offerings – all equally flavourful no matter whether you opt for fish, curries, grilled meats or one of our vegetarian or vegan specialities.
<G-vec00297-002-s109><opt.bevorzugen><de> Während Ihres Fitnessurlaubs in Italien raten wir Ihnen, pflanzliche Nahrung zu bevorzugen, da tierische Lebensmittel und Kohlenhydrate unsere Leber mit gesättigten Fettsäuren „überfluten“.
<G-vec00297-002-s109><opt.bevorzugen><en> During a fitness holiday in Italy, it’s good to opt for plant-based foods. This is because foods of animal origin and carbohydrates "flood" our liver with saturated fatty acids.
<G-vec00297-002-s110><opt.bevorzugen><de> Vier Hotels für Naturliebhaber, für alle, die eine einfache und familiäre Atmosphäre suchen oder den Service eines Luxushotels bevorzugen.
<G-vec00297-002-s110><opt.bevorzugen><en> Four hotels, to satisfy the nature lover, those who seek a simple, family atmosphere and for those who opt for the services of a luxury hotel.
<G-vec00297-002-s111><opt.bevorzugen><de> Liegen von Lieferanten vergleichbare Angebote vor, bevorzugen wir jene, welche nach ökologischen Prinzipien handeln.
<G-vec00297-002-s111><opt.bevorzugen><en> If our suppliers present us with comparable offers, we will opt for those that best meet our ecological principles.
<G-vec00334-002-s079><favor.bevorzugen><de> Auf französischem Gebiet wird der Name dieser Traube traditionell nicht auf dem Etikett angegeben, sondern bevorzugt der Keller- oder Ortsname, der des einzelnen Weinbergs, wo der Wein herstammt, wiedergegeben.
<G-vec00334-002-s079><favor.bevorzugen><en> In French territory, the name of this grape isn’t usually shown on the label, in favor instead of the cellar’s name, the village where the wine is produced or the single vineyard.
<G-vec00334-002-s080><favor.bevorzugen><de> Wir werden von verschiedenen Kunden aus dem In- und Ausland gelobt und bevorzugt.
<G-vec00334-002-s080><favor.bevorzugen><en> We get the praise and favor among different customers from at home and abroad.
<G-vec00334-002-s081><favor.bevorzugen><de> Einige Spieler haben das Gefühl, dass Spiele mit einem RNG manipuliert werden, in der Hinsicht, dass das Casino bevorzugt wird und keine wahren Chancen auf Gewinne bestehen.
<G-vec00334-002-s081><favor.bevorzugen><en> Some players feel that games controlled with an RNG are geared to favor the casino and not offer true chances at winning or game results.
<G-vec00334-002-s082><favor.bevorzugen><de> Es ist daher nicht verwunderlich, dass amerikanische Athleten diesen Testosteronester besonders bevorzugt.
<G-vec00334-002-s082><favor.bevorzugen><en> It is therefore not surprising that American athletes particularly favor this testosterone ester.
<G-vec00334-002-s083><favor.bevorzugen><de> Für Langstrecken-Lkw wird bevorzugt LNG (Liquefied Natural Gas oder Flüssigerdgas) eingesetzt, weil es eine höhere Energiedichte als CNG besitzt und beim Transport schwerer Lasten mit nur einer Tankfüllung Reichweiten von bis zu 1200 Kilometern ermöglicht.
<G-vec00334-002-s083><favor.bevorzugen><en> Long-haul trucks may favor liquefied natural gas (LNG) because of its higher energy density than CNG and the ability to travel up to 1200 kilometers between fill-ups while pulling heavy loads.
<G-vec00334-002-s235><prefer.bevorzugen><de> Die meisten Webbrowser akzeptieren Cookies automatisch, aber Sie können üblicherweise Ihre Browsereinstellungen verändern, um Cookies zurückzuweisen, wenn Sie dies bevorzugen.
<G-vec00334-002-s235><prefer.bevorzugen><en> Most Web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer.
<G-vec00334-002-s236><prefer.bevorzugen><de> Oder, falls Sie dies bevorzugen, eine Wohnmobil Frage an alle verifizierten Wohnmobilmechaniker auf unserer Seite richten, in dem Sie Ihre Frage in die Fragebox auf dieser Seite tippen.
<G-vec00334-002-s236><prefer.bevorzugen><en> Or, if you’d prefer, you can even ask a Volkswagen question to all of the verified Volkswagen Mechanics on our site by typing your question into the question box on this page.
<G-vec00334-002-s237><prefer.bevorzugen><de> Wir bieten Ihnen eine Vielzahl von Stilvarianten: gerade oder mit einer Viertelwendelung oder, sollten Sie dies bevorzugen, Spindel- oder Wendeltreppen.
<G-vec00334-002-s237><prefer.bevorzugen><en> We can offer a vast array of styles: straight, or with a quarter turn or you might prefer a spiral or helical staircase.
<G-vec00334-002-s238><prefer.bevorzugen><de> Falls Sie dies bevorzugen, können Sie auch unser Kundenservice-Team für das entsprechende Unternehmen unserer Gruppe anrufen und Ihren Wunsch mitteilen, keine Marketingkommunikation mehr zu erhalten.
<G-vec00334-002-s238><prefer.bevorzugen><en> If you prefer, you can also call our Customer Service team for the relevant entity of the Group and express your preference to not receive marketing communications.
<G-vec00334-002-s239><prefer.bevorzugen><de> Im unglücklichen Fall, dass Ihr Flug annulliert wird, können Sie kostenlos auf einen anderen easyJet-Flug wechseln oder wir leisten eine vollständige Rückerstattung, wenn Sie dies bevorzugen.
<G-vec00334-002-s239><prefer.bevorzugen><en> In the unfortunate event that your flight is cancelled you can transfer to another easyJet flight for free or if you’d prefer you can get a full refund.
<G-vec00334-002-s240><prefer.bevorzugen><de> Wenn Sie dies bevorzugen, können Sie ihn auch direkt in Ihren Proteinshake geben.
<G-vec00334-002-s240><prefer.bevorzugen><en> If you prefer, you can also add Pure Fine Oats directly to your protein shake.
<G-vec00334-002-s241><prefer.bevorzugen><de> Die meisten Webbrowser akzeptieren Cookies automatisch, aber Sie können Ihre Browsereinstellungen ändern, um Cookies abzulehnen, wenn Sie dies bevorzugen.
<G-vec00334-002-s241><prefer.bevorzugen><en> Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline if you prefer.
<G-vec00334-002-s242><prefer.bevorzugen><de> Wenn wir Ihnen keine Alternative anbieten können oder wenn Sie dies bevorzugen, werden wir Ihnen alle für die Hotelpaket-Buchung geleisteten Zahlungen erstatten.
<G-vec00334-002-s242><prefer.bevorzugen><en> If we cannot offer you an alternative, or even if you just prefer, we will provide you with a full refund of any payments made for the booking.
<G-vec00334-002-s243><prefer.bevorzugen><de> Wir bieten ein freiwilliges Abonnement für alle Spieler, die dies bevorzugen.
<G-vec00334-002-s243><prefer.bevorzugen><en> We offer an entirely optional subscription for players who prefer it.
<G-vec00334-002-s244><prefer.bevorzugen><de> Zahlungsmethoden Falls Ihr Unternehmen nicht am GUINNESS STOREHOUSE® Gutscheinprogramm teilnimmt, kann die Zahlung entweder in bar bei der Ankunft oder, falls Sie dies bevorzugen, per Überweisung oder Kreditkarte erfolgen.
<G-vec00334-002-s244><prefer.bevorzugen><en> If your company is not part of the GUINNESS STOREHOUSE® voucher scheme, payment can be made either by cash on arrival or if you prefer you can also pay by cheque or by credit card.
<G-vec00334-002-s245><prefer.bevorzugen><de> ⮱ Die meisten Webbrowser akzeptieren automatisch Cookies, aber Sie können in der Regel die Einstellung Ihres Browsers ändern, um Cookies abzulehnen, sollten Sie dies bevorzugen.
<G-vec00334-002-s245><prefer.bevorzugen><en> ⮱Most web browsers automatically accept cookies, but you can usually modify your browser’s setting to decline cookies if you prefer.
<G-vec00334-002-s246><prefer.bevorzugen><de> Die meisten Web-Browser akzeptieren Cookies automatisch, aber Sie können Ihre Browser-Einstellungen in der Regel so ändern, dass Cookies abgelehnt werden, wenn Sie dies bevorzugen.
<G-vec00334-002-s246><prefer.bevorzugen><en> Most Web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer.
<G-vec00334-002-s247><prefer.bevorzugen><de> Das Zimmer verfügt über ein Queensize-Bett und ein Einzelbett (oder 2 Einzelbetten, wenn Sie dies bevorzugen), viel Tageslicht und ausreichend Stauraum.
<G-vec00334-002-s247><prefer.bevorzugen><en> The room features a queen bed and a single bed (or two single beds if you prefer), plenty of natural light and ample storage.
<G-vec00334-002-s248><prefer.bevorzugen><de> Es gibt Einzeltische oder – falls Sie dies bevorzugen – können die Tische auch anders arrangiert werden.
<G-vec00334-002-s248><prefer.bevorzugen><en> Tables can be individual or, if you prefer, joined together.
