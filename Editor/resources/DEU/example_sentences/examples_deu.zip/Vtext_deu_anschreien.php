<G-vec00426-002-s027><scream.anschreien><de> Warum nimmst du es nicht mit in dein Zimmer?“ Wende dich dann an deinen Ex (der nur darauf wartet, dass du ihn anschreist) und sage „es war nett von dir, dass du es ihm gegeben hast.
<G-vec00426-002-s027><scream.anschreien><en> Why don't you take it up to your room." Then turn to your ex (who is just itching for you to scream at him) and say, "It was nice of you to give those to him.
<G-vec00426-002-s020><shout.anschreien><de> Und oft scheint es mir, die Hunde würden nur gehalten, damit man sie anschreien kann.
<G-vec00426-002-s020><shout.anschreien><en> And quite often it seems as if these dogs are only kept to have an opportunity to shout at something.
<G-vec00426-002-s020><shout_out.anschreien><de> Und oft scheint es mir, die Hunde würden nur gehalten, damit man sie anschreien kann.
<G-vec00426-002-s020><shout_out.anschreien><en> And quite often it seems as if these dogs are only kept to have an opportunity to shout at something.
<G-vec00426-002-s047><yell.anschreien><de> Streite nicht mit einer Person, die unter dem Messie-Syndrom leidet, und schrei sie nicht an.
<G-vec00426-002-s047><yell.anschreien><en> Do not argue or yell at a person who is hoarding.
<G-vec00426-002-s047><yell_out.anschreien><de> Streite nicht mit einer Person, die unter dem Messie-Syndrom leidet, und schrei sie nicht an.
<G-vec00426-002-s047><yell_out.anschreien><en> Do not argue or yell at a person who is hoarding.
