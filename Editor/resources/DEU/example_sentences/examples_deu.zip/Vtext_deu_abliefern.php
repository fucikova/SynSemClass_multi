<G-vec00011-002-s019><deliver.abliefern><de> Jene vertrauenswürdigen Dienstleister werden Lösungen abliefern, auf die Sie sich verlassen können, sodass Sie mehr Zeit mit dem Wesentlichsten verbringen können - dem Wachstum Ihres Unternehmens.
<G-vec00011-002-s019><deliver.abliefern><en> Those trusted service manufacturers like Ocean Freight Service factory will deliver solutions you can count on, so you can spend more time on what matters most - growing your business.
<G-vec00011-002-s020><deliver.abliefern><de> Wenn Sie ein Siebdrucker sind, der darum kämpft, die Kundennachfrage nach geringeren Auflagen oder maßgeschneiderten Aufträgen zu befriedigen, dann bietet die Roland-Digitaldruck-Technologie die Flexibilität und Effizienz bei der Produktion, um diese Aufträge profitabel abliefern zu können.
<G-vec00011-002-s020><deliver.abliefern><en> If you’re a screen printer looking to meet customer demands for lower volume or custom jobs, Roland DG wide-format digital printers offer the ease-of-use, flexibility and efficiency you need to deliver these jobs profitably.
<G-vec00011-002-s021><deliver.abliefern><de> Die Deutschnofner saßen im Wirtshaus und konnten das Gold nicht mehr rechtzeitig abliefern.
<G-vec00011-002-s021><deliver.abliefern><en> The Nova Ponente contingent were left sitting in the inn, unable to deliver the gold on time.
<G-vec00011-002-s022><deliver.abliefern><de> Ich kann mich noch erinnern, meinen Geburtstag habe ich schon in Breitensee – das weiß ich – feiern müssen, und ich habe aus Bayern, weil wir dann beten gelernt haben, und in die Kirche gehen haben müssen, dass uns der Pfarrer gegen die Bauern ein bisschen unterstützt hat, dass sie uns die Milch nicht verwässern, die sie abliefern haben müssen fürs Lager...
<G-vec00011-002-s022><deliver.abliefern><en> And from Bavaria I had…, because we had to learn to pray and go to the church, so that the priest might help us against the farmers a bit, so that they would not water down the milk which they had to deliver to the camp.
<G-vec00011-002-s030><deliver.abliefern><de> Aber was die Softwareeigentümer üblicherweise abliefern, ist eine Blackbox, die wir nicht untersuchen oder ändern können.
<G-vec00011-002-s030><deliver.abliefern><en> But what software owners typically deliver is a black box that we can't study or change.
<G-vec00011-002-s031><deliver.abliefern><de> Wir haben bereits eine Liste mit anstehenden Destiny 2-Verbesserungen veröffentlicht, die wir abliefern wollen.
<G-vec00011-002-s031><deliver.abliefern><en> We previously published a list of upcoming Destiny 2 improvements we want to deliver.
<G-vec00011-002-s033><deliver.abliefern><de> Monsanto fordert von Bauern nicht nur Lizenzgebühren ein, wenn diese Saatgut kaufen, sondern auch, wenn sie ihre Ernte am Silo abliefern.
<G-vec00011-002-s033><deliver.abliefern><en> Monsanto makes farmers pay royalties not only when they buy the seed but also when they deliver their harvest to the silo.
<G-vec00011-002-s034><deliver.abliefern><de> Handel- und Gewerbetreibende erhielten in der Edo-Zeit vom bakufu oder den feudalen Clans die Erlaubnis Gilden zu bilden, mussten jedoch für die Lizenz zur Handelskontrolle Steuern abliefern.
<G-vec00011-002-s034><deliver.abliefern><en> In the Edo-period the commercial and industrial men received the permission of the bakufu or the feudal clans to establish guilds, but had to deliver taxes for the commercial regulation.
<G-vec00011-002-s035><deliver.abliefern><de> Die Abstände sind dort immer sehr gering, entsprechend darf man sich keine Fehler erlauben und muss ein perfektes Rennen abliefern.
<G-vec00011-002-s035><deliver.abliefern><en> The gaps there are always very close, so you can’t afford to make any mistakes and you need to deliver a perfect race.
<G-vec00011-002-s036><deliver.abliefern><de> "Wir freuen uns, dass die Fans vom Spiel begeistert sind und nehmen uns die nötige Zeit, um sicherzustellen, dass wir ein Spiel abliefern, das ihre Erwartungen hoffentlich erfüllt und übertrifft.
<G-vec00011-002-s036><deliver.abliefern><en> "We're happy that fans are excited about the game, and we are taking the time to make sure we deliver a game that lives up to and hopefully exceeds their expectations.
<G-vec00011-002-s037><deliver.abliefern><de> Es wird erwartet, dass diese Betriebssituationen im Laufe des aktuellen Geschäftsjahres positive Ergebnisbeiträge abliefern werden.
<G-vec00011-002-s037><deliver.abliefern><en> These operating situations are expected to deliver positive earnings contributions in the course of the current fiscal year.
<G-vec00011-002-s038><deliver.abliefern><de> Da diese jedoch bisher keinen Anreiz hatten, den Müll abzuliefern, warfen sie diesen einfach wieder ins Meer.
<G-vec00011-002-s038><deliver.abliefern><en> However, since they have had no incentive to deliver the garbage, they just threw it back into the sea.
<G-vec00011-002-s039><deliver.abliefern><de> Er bat Euch, sie diskret bei ihrem Empfänger abzuliefern.
<G-vec00011-002-s039><deliver.abliefern><en> He has asked you to deliver them discreetly.
<G-vec00011-002-s040><deliver.abliefern><de> Baut euer Streckennetz aus, um noch mehr Waren aufzunehmen und abzuliefern.
<G-vec00011-002-s040><deliver.abliefern><en> Expand your rail network as you connect cities in order to pick up and deliver more goods.
<G-vec00011-002-s041><deliver.abliefern><de> Das Polyphony Team sprach auf der Bühne über die Vorteile, die PS4 bietet und ihnen erlauben, die Grafik, Physik und den Sound noch weiter zu verbessern und so den bisher realistischsten Rennsimulator abzuliefern.
<G-vec00011-002-s041><deliver.abliefern><en> On stage, the Polyphony team talked about the advances that the PS4 offers to allow them to continue to improve the graphics, physics and sound to deliver the most realistic driving simulator to date.
<G-vec00011-002-s042><deliver.abliefern><de> Bei Aufträgen ist es wichtig, die erwartete Arbeitsleistung in der gegebenen Zeit und in der gewünschten Qualität abzuliefern.
<G-vec00011-002-s042><deliver.abliefern><en> Considering constructional orders, it is important to deliver the expected efficiency in the given time and the desired quality.
<G-vec00011-002-s043><deliver.abliefern><de> • Low-Fi-Charakter: Als Konzepterin komme ich nicht in Versuchung, detailgetreue Screens abzuliefern; die Kundin kommt nicht auf die Idee, Schriftart oder Abstände zu kritisieren und kann sich voll auf den User Flow konzentrieren.
<G-vec00011-002-s043><deliver.abliefern><en> Low-fi character: As a concept designer, I’m not tempted to deliver detailed screens; the customer sees no need in criticizing font or spacing and can fully concentrate on the user flow.
<G-vec00011-002-s044><deliver.abliefern><de> Doch vorher galt es noch, in Assen eine saubere Leistung abzuliefern.
<G-vec00011-002-s044><deliver.abliefern><en> “But before that, it was still necessary to deliver a good performance in Assen.
<G-vec00011-002-s045><deliver.abliefern><de> Wir suchen Mitarbeiter/innen, die über mehr verfügen als nur Wissen und fachliche Kompetenzen: den Antrieb, Ergebnisse abzuliefern, und die Fähigkeit, zielgerichtet in einem multikulturellen Team zu arbeiten.
<G-vec00011-002-s045><deliver.abliefern><en> We want our staff to have more than just knowledge and professional skills: the drive to deliver results and the ability to work effectively as part of a multi-cultural team.
<G-vec00011-002-s046><deliver.abliefern><de> Sie koordinieren, unterstützen und lenken die notwendigen Prozesse, um letzten Endes ein fertiges Produkt beim Kunden abzuliefern.
<G-vec00011-002-s046><deliver.abliefern><en> They coordinate, support and drive the processes that are needed to deliver a finished product to our customers.
<G-vec00011-002-s047><deliver.abliefern><de> Der Striker von ANON hat mit seiner robusten Endura Hartschale und dem niedrig geschnittenen Old-School Profil nur ein Ziel: beste Performance abzuliefern.
<G-vec00011-002-s047><deliver.abliefern><en> The Striker by ANON with its robust Endura shell and the low-profile design has only one goal: to deliver the best performance.
<G-vec00011-002-s048><deliver.abliefern><de> Weil ich aber nunmal Bloggerin dieses Blogs bin, habe ich doch das Bedürfnis meinen Lesern einen kleinen Statusbericht abzuliefern.
<G-vec00011-002-s048><deliver.abliefern><en> But because I am the blogger of this blog, I feel the need to deliver my readers a little status report.
<G-vec00011-002-s049><deliver.abliefern><de> Du musst nicht jedes kleine Detail eines Gebietes kennen, um eine tolle Rede darüber abzuliefern.
<G-vec00011-002-s049><deliver.abliefern><en> You don't have to know every single thing about a topic to deliver a great speech.
<G-vec00011-002-s050><deliver.abliefern><de> Er wurde von Gott gesandt, um ein Neues Testament abzuliefern.
<G-vec00011-002-s050><deliver.abliefern><en> He was sent by God to deliver a New Testament.
<G-vec00011-002-s051><deliver.abliefern><de> Und was The Entropy Cage anbelangt, so denke ich, dass der Autor es hier geschafft hat ein Spiel abzuliefern, dass mich als Parser-Fan überzeugt hat, dass es so etwas wie ein gutes Hypertext-Spiel geben kann.
<G-vec00011-002-s051><deliver.abliefern><en> And as far as The Entropy Cage is concerned, I think the author knew the crafts well enough to deliver a game that finally convinced a parser fan like me, that there is such a thing as a good hypertext game.
<G-vec00011-002-s052><deliver.abliefern><de> Natürlich nicht ohne bei Christos mit Dank, Schnaps und Kletterer-Handcreme bewaffnet die Ausrüstung abzuliefern.
<G-vec00011-002-s052><deliver.abliefern><en> Of course not without a stop at Christos with thanks, liquor and climber hand cream to deliver the climbing gear.
<G-vec00011-002-s053><deliver.abliefern><de> Daher ist es immer unser vorherrschendes Ziel, am Ende des Arbeitsprozesses optimale Ergebnisse abzuliefern.
<G-vec00011-002-s053><deliver.abliefern><en> Therefore, our overriding objective is that we deliver optimal results at the end of the working process.
<G-vec00011-002-s054><deliver.abliefern><de> Ein guter Sprachdienstleister kann Engpässe überbrücken und hat entsprechende Krisenpläne, aber auch der Klient kann dem Projektmanager helfen, gegen die tickende Uhr zu kämpfen: eine plötzlich dringend gewordene Deadline bringt unnötige Hektik in den Lokalisationsprozess und geht zu Lasten der Fähigkeit, ein gutes Ergebnis pünktlich abzuliefern.
<G-vec00011-002-s054><deliver.abliefern><en> A good LSP will have its strategies for coping with bottle-necks as well as contingency plans, but there are also ways a client can help the project manager work against the ticking clock: suddenly notifying your provider of an urgent deadline rushes the localisation process and strains the ability to deliver quality on time.
<G-vec00011-002-s055><deliver.abliefern><de> Pfennige und ein Krampfund Wachs abzuliefern.
<G-vec00011-002-s055><deliver.abliefern><en> To deliver pennies and a spasm and wax.
<G-vec00011-002-s056><deliver.abliefern><de> Wenn du schon mal da bist, kannst du beim Tauschen auch gleich die Inseln abräumen, aber nicht vergessen die Fotos abzuliefern.
<G-vec00011-002-s056><deliver.abliefern><en> On the way you can also clear the islands, and don´t forget to deliver photos.
