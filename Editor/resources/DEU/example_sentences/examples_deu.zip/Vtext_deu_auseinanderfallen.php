<G-vec00599-002-s024><disintegrate.auseinanderfallen><de> Falls Putin jedoch scheitern sollte, werde Russland auseinanderfallen.
<G-vec00599-002-s024><disintegrate.auseinanderfallen><en> If Putin fails, however, Russia will disintegrate.
<G-vec00786-002-s021><deteriorate.auseinanderfallen><de> Es ist besonders unvorstellbar, dass das Wirtschaftssystem so schnell auseinander fallen kann.
<G-vec00786-002-s021><deteriorate.auseinanderfallen><en> Specifically, it is unimaginable that the economic system can deteriorate so rapidly!
