<G-vec00092-001-s114><take.dauern><de> Umschreiben Module ist nicht einfach, und es wird einige Zeit dauern...
<G-vec00092-001-s114><take.dauern><en> Re-writing modules is not simple, and it will take some time...
<G-vec00092-001-s115><take.dauern><de> Nach dem Bearbeiten herauf das Problem, im Fall des Elektrikers sollten Änderungen in der normalen Arbeit Periode geringe Wirkung auf seiner Fähigkeit haben, die notwendige Reparatur durchzuführen, da sie ihm nur fünf oder 10 Minuten dauern sollte, um diese Arbeit durchzuführen.
<G-vec00092-001-s115><take.dauern><en> In the electrician's case, changes in the normal work period should have little effect on his ability to make the necessary repair since it should take him only five or ten minutes to complete this work after sizing up the problem.
<G-vec00092-001-s116><take.dauern><de> Ja, das ist genau das, was ich meinte, als ich gesagt habe, dass es eine ganze Weile dauern kann, bis man einen Text vorbereitet hat, weil man alles doppelt und dreifach überprüfen und seine Übersetzung mit der von Wörterbüchern oder von Übersetzungssoftware vergleichen muss.
<G-vec00092-001-s116><take.dauern><en> Yes, that's exactly what I meant when I said that preparing a text can take quite some time because you have to double-check all of your translated words in several dictionaries and dictionary programs.
<G-vec00092-001-s117><take.dauern><de> Wenn Sie es verwenden eine vergrößerte Prostata zu behandeln, kann es 3 bis 6 Monate dauern, bis Sie den vollen Nutzen dieses Medikaments bemerken.
<G-vec00092-001-s117><take.dauern><en> If you are using it to treat an enlarged prostate, it may take 3 to 6 months for you to notice the full benefits of this drug.
<G-vec00092-001-s118><take.dauern><de> Aus- und Einbau sowie Reinigung der Siebe dauern zwei, die Prüfung selbst drei Stunden.
<G-vec00092-001-s118><take.dauern><en> The removal, refitting and cleaning of the screens take two hours, the inspection itself another three.
<G-vec00092-001-s119><take.dauern><de> Ihre Verbindung verloren, Google Website-Suche finden Sie unter verwenden, wenn es indiziert ist (kann bis zu 2 Wochen dauern).
<G-vec00092-001-s119><take.dauern><en> Lost your link, use google site search see if it has been indexed (can take up to 2 weeks).
<G-vec00092-001-s120><take.dauern><de> Die Lieferung des Schecks, per Kurier, nach der anfänglichen Bearbeitungszeit, bis zu 7 (sieben) Arbeitstagen dauern könnte.
<G-vec00092-001-s120><take.dauern><en> Delivery of the Cheque/Check, by courier, after initial processing may take up to 7 (seven) working days.
<G-vec00092-001-s121><take.dauern><de> ACHTUNG: Wenn es keine direkte Zahlung betrifft - wie eine Zahlung über AfterPay, PayPal oder Kreditkarte - kann es einige Tage dauern, bis die zurückerstattete Summe auf Ihren Kontoauszug erscheint.
<G-vec00092-001-s121><take.dauern><en> PLEASE NOTE: If this isn't a direct payment - such as via AfterPay, PayPal or credit card - it may take several days for the refunded amount to appear in your bank statement. Â
<G-vec00092-001-s122><take.dauern><de> Es kann einige Zeit dauern, um Fotos hinzuzufügen, um alle oder die wichtigsten Kontakte aus dem Thunderbird-Adressbuch.
<G-vec00092-001-s122><take.dauern><en> It may take some time to add photos to all or the most important contacts of the Thunderbird address book.
<G-vec00092-001-s123><take.dauern><de> Die Suche kann je nach Anzahl der zu durchsuchenden Empfängerlisten einige Minuten dauern.
<G-vec00092-001-s123><take.dauern><en> The search may take several minutes depending on the number of recipient lists being searched.
<G-vec00092-001-s124><take.dauern><de> Prag hat die größte Auswahl für Tschechen und für Expats, sondern in dünner besiedelten Gebieten kann es Monate dauern, bis Sie einen geeigneten Ort.
<G-vec00092-001-s124><take.dauern><en> Prague has the largest selection for Czechs and for expats, but in more sparsely populated areas it may take months to find a suitable place.
<G-vec00092-001-s125><take.dauern><de> Es kann 10 bis 12 Jahre dauern, bis diese Pflanze ihre volle Reife erreicht.
<G-vec00092-001-s125><take.dauern><en> It may take 10 to 12 years for this plant to reach full maturity.
<G-vec00092-001-s126><take.dauern><de> Es könnte dauern Geduld und Sorgfalt, aber Ihren Penis vergrößern sollte nicht verletzen oder sein ärgerlich unbequem.
<G-vec00092-001-s126><take.dauern><en> It might take patience and diligence, but enlarging your penis shouldn’t hurt or be annoyingly uncomfortable.
<G-vec00092-001-s127><take.dauern><de> Der Download sollte nicht zu lange dauern, und Sie werden keine zusätzlichen Komponenten müssen, wie beispielsweise ein Rahmen, Bibliothek oder Gebrauchs.
<G-vec00092-001-s127><take.dauern><en> The download shouldn’t take too long and you won’t need any additional components, such as a framework, library or utility.
<G-vec00092-001-s128><take.dauern><de> Es sollte etwa 20 Minuten dauern, bis die erste Schicht trocken ist.
<G-vec00092-001-s128><take.dauern><en> It should take about 20 minutes for the first coat to dry.
<G-vec00092-001-s129><take.dauern><de> Diese Überfahrten dauern etwa 45 bis 90 Minuten.
<G-vec00092-001-s129><take.dauern><en> These passages take about 45 to 90 minutes.
<G-vec00092-001-s130><take.dauern><de> Die meisten BBA-Studiengänge dauern etwa drei oder vier Jahre bis zum erfolgreichen Abschluss.
<G-vec00092-001-s130><take.dauern><en> Most BBA programs take about three or four years to successfully complete.
<G-vec00092-001-s131><take.dauern><de> Der Start kann einige Sekunden dauern.
<G-vec00092-001-s131><take.dauern><en> The startup can take several seconds.
<G-vec00092-001-s132><take.dauern><de> Nach der Verhaftung der Führungsriege des Leuchtenden Pfads (1992) sollte es noch acht Jahre dauern, bis diese politische Gewalt beendet werden konnte.
<G-vec00092-001-s132><take.dauern><en> After the arrest of the leaders of the Shining Path (1992) it was still to take eight years until this political violence could be ended.
<G-vec00092-001-s133><take.dauern><de> Ein Saunagang dauert zwischen 8 und 15 Minuten, nachdem man sich bei einer kalten Dusche oder mit Eis oder Schnee erfrischen sollte, um die Wirkung der Sauna zu verstärken.
<G-vec00092-001-s133><take.dauern><en> Each sauna session can take from 8 to 15 minutes. At the end of the session you take a cold shower or bath to cool your body and to maximize the beneficial effects of the sauna.
<G-vec00092-001-s134><take.dauern><de> Jedoch, sah, dass genau, Es dauert nicht Vorteil des Bodens, Es hat es viel schwieriger, eine macht, zu starten und eine richtige Kurve haben.
<G-vec00092-001-s134><take.dauern><en> However, for the exact same reason, he does not take advantage of the alley subtleties, it is a lot more harder for him to have an adequate throwing power and to have a proper curve.
<G-vec00092-001-s135><take.dauern><de> "Viel länger dauert es nämlich nicht, die Geschichte zu lesen, wenn man nicht gestört wird, da das Buch leider nur 83 Seiten ""dick"" ist."
<G-vec00092-001-s135><take.dauern><en> Because it doesn't take much longer to read this story when one isn't interrupted: the book only has 83 pages.
<G-vec00092-001-s136><take.dauern><de> Das Ausfüllen des Online-Bogens dauert dann höchstens 5 Minuten.
<G-vec00092-001-s136><take.dauern><en> Completing the online form will take no longer than 5 minutes.
<G-vec00092-001-s137><take.dauern><de> Es dauert ungefähr 1,5 Stunden, um die Stadt zu erreichen.
<G-vec00092-001-s137><take.dauern><en> It will take us about 1.5 hours to reach the city.
<G-vec00092-001-s138><take.dauern><de> In jedem Fall Ã1⁄4bernehmen wir nicht empfehlen, selbstblÃ1⁄4henden Sorten (Dr. Green Seeds) MIT Photoperioden von Ã1⁄4ber 16 Stunden, wie die Pflanzen dauert eine lange Zeit, um den Prozess zu beenden und neigen dazu, zu einer riesigen Größe wachsen und die Gefahr birgt WÄCHST jenseits des Erzeugers KONTROLLE.
<G-vec00092-001-s138><take.dauern><en> In any case, WE DO NOT RECOMMEND USING OUR AUTO-FLOWERING VARIETIES (Dr. Green Seeds) WITH PHOTOPERIODS OF OVER 16 HOURS, AS THE PLANTS WILL TAKE A LONG TIME TO END THE PROCESS, TENDING TO GROW TO A HUGE SIZE AND RISKING GROWING BEYOND THE GROWER'S CONTROL. • Use high-pressure sodium lamps.
<G-vec00092-001-s139><take.dauern><de> Wenn Sie Geld per Banküberweisung schicken, dauert es 2-3 Werktage.
<G-vec00092-001-s139><take.dauern><en> If you send money via bank transfer, it will take 2-3 business days.
<G-vec00092-001-s140><take.dauern><de> "Drücken Sie die Schaltfläche ""Download"", und das dauert ein paar Minuten die Firmware herunterladen."
<G-vec00092-001-s140><take.dauern><en> Hit the Download button, and this might take a few minutes to download the firmware.
<G-vec00092-001-s141><take.dauern><de> Anmerkung: Bitte fragen Sie bei Ihrer Bank nach, wielange es dauert, bis die Überweisung in unserem Bankkonto ankommt.
<G-vec00092-001-s141><take.dauern><en> Note: Please confirm with your bank how long the Wire Transfer will take to get into our bank account.
<G-vec00092-001-s142><take.dauern><de> Es dauert nur wenige Minuten, ein professionell aussehendes, attraktives Menü zu entwerfen.
<G-vec00092-001-s142><take.dauern><en> It will only take you a few minutes to finish designing a professional looking, attractive menu.
<G-vec00092-001-s143><take.dauern><de> Es dauert in der Regel 3-5 Werktage bis die Lieferung eintrifft.
<G-vec00092-001-s143><take.dauern><en> Typically, this will take 3-5 working days for delivery.
<G-vec00092-001-s144><take.dauern><de> Wenn Sie einige grundlegende Grafik-Design-Software verwenden können, dauert es nur ein paar Stunden, um den Vorgang zu meistern.
<G-vec00092-001-s144><take.dauern><en> If you are able to use some basic graphic design software, it will only take a few hours to master the operation.
<G-vec00092-001-s145><take.dauern><de> Dieser Prozess dauert je nach Größe Ihrer Datenbank zwischen einigen Sekunden und mehreren Stunden.
<G-vec00092-001-s145><take.dauern><en> This process can take from a few seconds to a few hours depending on the size of your database.
<G-vec00092-001-s146><take.dauern><de> Kostenloser Versand erfordert keine Transport Steuern, aber es dauert länger, um anzukommen und den Wert der Bestellung übersteigt $50 und die standard-Versand dauert wesentlich weniger, um anzukommen, sondern erfordern zusätzliche Gebühren.
<G-vec00092-001-s146><take.dauern><en> Free shipping requires no transportation taxes but takes longer to arrive and the value of the order has to exceed $50 and the standard shipping can take significantly less to arrive but will require additional fees.
<G-vec00092-001-s147><take.dauern><de> Und es dauert nicht lange und...
<G-vec00092-001-s147><take.dauern><en> And it didn't take long and …
<G-vec00092-001-s148><take.dauern><de> Zeithorizont: Basierend auf statistischen Daten der Jahre 1996-2004 und den Volatilitätsmerkmalen der Aktie wird der Zeithorizont als die Anzahl Tage berechnet, die es im Schnitt dauert, bis eine Kursbewegung erreicht wird, die der Bewegung von Kaufkurs bis Kursziel entspricht.
<G-vec00092-001-s148><take.dauern><en> Time horizon: Based on statistics from 1996-2004 and the stock's volatility characteristics, a time horizon is calculated for how many days it will take on average to complete a price movement equal to the movement from buying price to price target.
<G-vec00092-001-s149><take.dauern><de> Keine Sorge, dieser Artikel bietet ein sehr effizientes Werkzeug, d.h. Outlook Backup & migrieren, das dauert eine Sicherungskopie der PST-Datei & auch hilft Ihnen, diese PST-Datei auf eine höhere Version von MS Outlook oder das Betriebssystem zu migrieren.
<G-vec00092-001-s149><take.dauern><en> Don't worry, this article offers a very efficient tool i.e. Outlook Backup & Migrate, that will take a backup of the PST file & also helps you to migrate that PST file to a higher version of MS Outlook or the OS.
<G-vec00092-001-s150><take.dauern><de> Der Aufstieg zum Aussichtspunkt dauert ungefähr 1 ½ Stunden und von dort aus haben Sie einen spektakulären Blick auf das Kloster, das an der Seite der Klippe hängt.
<G-vec00092-001-s150><take.dauern><en> The climb up to the viewpoint will take around 1 ½ hours and from there you will enjoy a spectacular view of the monastery clinging to the side of the cliff.
<G-vec00092-001-s151><take.dauern><de> Vous über die Geschichte und Grundlagen der Entwicklung der Reben und Wein mit Ihrem Guide, der euch durch kleine dauert lernen steinige Pfade und Panorama-Balkon.
<G-vec00092-001-s151><take.dauern><en> You learn about the history and fundamentals of the development of the vine and wine with your guide who will take you by small stony paths and panoramic balconies.
<G-vec00169-001-s016><recoup.dauern><de> Die Geschichte zeigt uns, dass die Tech Seifenblase irgendwann platzen musste und die Aktien, die den Crash überlebt haben, mit 80-95% abgefallen sind und es einige Jahre gedauert hat, bis sie sich zu den alten Hochpreisen erholt hatten.
<G-vec00169-001-s016><recoup.dauern><en> History shows us that the tech bubble couldn't last forever and the stocks that survived the crash usually fell down with 80-95% and it took several years to recoup to old Price Highs.
<G-vec00261-002-s175><persist.dauern><de> Die klinischen Symptome dauern oft Wochen bis Monate, Komplikationen können bei Säuglingen mit lebensgefährlichen Apnoen auftreten.
<G-vec00261-002-s175><persist.dauern><en> The clinical symptoms often persist for weeks to months and complications can develop in infants with life-threatening apnoea.
<G-vec00261-002-s176><persist.dauern><de> Die Agenturen sagten: “Geplante Stromabschaltungen dauern bis zu 18 Stunden pro Tag.
<G-vec00261-002-s176><persist.dauern><en> The agencies said: “Scheduled power cuts persist for up to 18 hours a day.
<G-vec00261-002-s177><persist.dauern><de> Setzen Sie die Eigenschaft Duration auf die Anzahl der Sekunden, die die Animation dauern soll.
<G-vec00261-002-s177><persist.dauern><en> Set the Duration property to the number of seconds the animation should persist.
<G-vec00340-002-s133><take.dauern><de> Der Aufstieg dauert 45 Minuten / 1 Stunde.
<G-vec00340-002-s133><take.dauern><en> The ascent will take 45 minutes / 1 hour.
<G-vec00340-002-s134><take.dauern><de> Kleinere Gefriergutteile können unter Umständen sogar direkt aus dem Gefrierschrank entnommen und anschließend sofort gekocht oder gegart werden: in diesem Fall dauert der Garvorgang allerdings etwas länger.
<G-vec00340-002-s134><take.dauern><en> Small pieces may even be cooked still frozen, directly from the freezer: in this case, cooking will take longer. HELPFUL HINTS AND TIPS Normal Operating Sounds
<G-vec00340-002-s135><take.dauern><de> Der gesamte Prozess dauert etwa 45 Minuten.
<G-vec00340-002-s135><take.dauern><en> The entire experience should take about 60 to 90 minutes.
<G-vec00340-002-s136><take.dauern><de> Bei einer Häufigkeit mit einer Umfrage pro Quartal brauchen Sie nahezu ein Jahr, um Trends zu erkennen (obwohl das immer noch deutlich besser ist als die Jahre, die es bei veralteten jährlichen Umfragen dauert).
<G-vec00340-002-s136><take.dauern><en> On a quarterly frequency it will take nearly a year to create trend lines (although this is still a big improvement on the years it will take with old annual surveys).
<G-vec00340-002-s137><take.dauern><de> Das dauert je nach Größe der Speise nur etwa 20 Minuten, ganz egal, was die ursprüngliche Garzeit oder -temperatur war.
<G-vec00340-002-s137><take.dauern><en> This could take as little as 20 minutes irrespective of the original cooking time or temperature, depending of course on the size of the item.
<G-vec00340-002-s138><take.dauern><de> Die Herstellung dauert vielleicht ein paar Tage, aber wenn Sie es richtig machen, ist es einer der effektivsten Hintergründe die ich bisher gesehen habe.
<G-vec00340-002-s138><take.dauern><en> It may take a few days to create, but when done well, it is one of the most effective backgrounds I have come across.
<G-vec00340-002-s139><take.dauern><de> Die Einrichtung ist ganz einfach und dauert nur wenige Minuten.
<G-vec00340-002-s139><take.dauern><en> Setting this up is easy and will take just a few minutes.
<G-vec00340-002-s140><take.dauern><de> Wie lange das Verfahren voraussichtlich dauert, konnte die Sprecherin nicht sagen.
<G-vec00340-002-s140><take.dauern><en> The spokeswoman could not say how long the proceedings are likely to take.
<G-vec00340-002-s141><take.dauern><de> c. Wenn der Standby-Modus einen geringen Stromverbrauch aufweist, dauert es 3 Sekunden vom Druckknopf, um die Datei abzuspielen.
<G-vec00340-002-s141><take.dauern><en> c. When the standby mode is low power consumption, it will take 3 sec from push button to play file.
<G-vec00340-002-s142><take.dauern><de> Wenn man das wirklich so entwickeln sollte, dauert das sicherlich Jahre.
<G-vec00340-002-s142><take.dauern><en> If it really is to be developed, it will certainly take years.
<G-vec00340-002-s143><take.dauern><de> Wie oben erwähnt, dauert ein normales kabelloses Ladegerät sogar viel länger als ein kabelgebundenes Ladegerät.
<G-vec00340-002-s143><take.dauern><en> As it is mentioned above, normal wireless charger take even much time than a wired charger.
<G-vec00340-002-s145><take.dauern><de> Mit dem Zug dauert die Fahrt etwa 15 Stunden, wird aber erheblich zur Kostensenkung beitragen (im Vergleich zum Flugverkehr).
<G-vec00340-002-s145><take.dauern><en> By train, the journey will take about 15 hours, but will significantly help reduce costs (in comparison with air travel).
<G-vec00340-002-s146><take.dauern><de> Deine emotionale Genesung dauert Monate oder Jahre - das ist OK.
<G-vec00340-002-s146><take.dauern><en> Your emotional recovery may take months or years - this is OK.
<G-vec00340-002-s147><take.dauern><de> Dies kann Auswirkungen darauf haben, wie viel lange es dauert eine Datei herunterzuladen, auf die Qualität des gestreamten Filmes und auf das Laden einer Webseite.
<G-vec00340-002-s147><take.dauern><en> This can impact how much time it will take you to download a file, the quality of the media you’re streaming, and how long web pages take to load.
<G-vec00340-002-s148><take.dauern><de> Angesichts der aggressiven Scans und Datensammelmethoden von Mirai und der Vielzahl an Botnets, über die in den letzten neun Monaten berichtet wurde, dauert es niemals lange, bis ein ungeschütztes und unsicheres Gerät ausgebeutet wird, sobald es einmal mit dem Internet verbunden ist.
<G-vec00340-002-s148><take.dauern><en> Because of the aggressive scanning and harvesting method used by Mirai, and the sheer number of botnets reported in past nine months, it should not take long for an unprotected, insecure device to be exploited and victimized once it is connected to the internet.
<G-vec00340-002-s149><take.dauern><de> Die Auszahlung über Optionen wie Kreditkarten und Banküberweisungen dauert viel länger, oft zwischen 1-5 Werktagen, je nach gewählter Methode.
<G-vec00340-002-s149><take.dauern><en> Withdrawing via options such as credit cards and bank transfers take a lot longer. Often between 1-5 business days depending on the method chose.
<G-vec00340-002-s150><take.dauern><de> Jedoch so nützlich, wie das Hormon ist, dauert es eine lange Zeit, solchen Nutzen zu sehen; einige Wochen von HGH-Therapie ist eine Geldverschwendung und ein kompletter Abfall guten HGH.
<G-vec00340-002-s150><take.dauern><en> However, as beneficial as the hormone is it will take a long time to see such benefits; a few weeks of HGH therapy is a waste of money and a complete waste of good HGH.
<G-vec00340-002-s151><take.dauern><de> Eine Überlandfahrt zwischen den Flughäfen Punta Cana im Südosten und Puerto Plata im Norden beispielsweise, dauert bis zu sieben Stunden.
<G-vec00340-002-s151><take.dauern><en> For example, traveling overland between the Punta Cana and Puerto Plata airports can take up to seven hours.
<G-vec00340-003-s144><take.dauern><de> Es dauert nur wenige Minuten.
<G-vec00340-003-s144><take.dauern><en> It’ll only take you a few minutes.
