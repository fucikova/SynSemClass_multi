<G-vec00367-001-s108><ban.bannen><de> Anmerkung Gewisse Fedora Kanäle bannen Benutzer, welche an ihrem System als root eingeloggt sind.
<G-vec00367-001-s108><ban.bannen><en> WARNING Some of the Fedora channels ban users that are logged into their system as root .
<G-vec00367-001-s109><ban.bannen><de> Kannst du solches, so will ich dich nicht aus meinem Herzen bannen, sondern dich behalten gleich wie ehedem.
<G-vec00367-001-s109><ban.bannen><en> If you can do this, I will not ban you from my heart but will keep you as I used to.
<G-vec00367-001-s110><ban.bannen><de> In Moment scheint Control Warrior deutlich besser für Turniere geeignet zu sein, wo es möglich ist ein schlechtes Matchup zu bannen und sich stattdessen darauf zu konzentrieren, aggressive Decks wie Pirate Warrior oder Aggro Shaman auszukontern.
<G-vec00367-001-s110><ban.bannen><en> At the moment, Control Warrior seems to be more suited for tournaments, where one is able to ban out a bad matchup and focus on countering aggressive decks such as Pirate Warrior and Aggro Shaman.
<G-vec00367-001-s111><ban.bannen><de> 4. zum Schluss das Wichtigste: einen möglichst kleinen Ausschnitt des Kopfes auf das Foto bannen.
<G-vec00367-001-s111><ban.bannen><en> 4. Finally the most important thing: a possible fraction of the head on the photo ban.
<G-vec00367-001-s112><ban.bannen><de> Bei Verstoß gegen die genannten Regeln verwarnen, kicken und/oder bannen wir.
<G-vec00367-001-s112><ban.bannen><en> Violating the rules above will result in a kick or ban.
<G-vec00367-001-s113><ban.bannen><de> Du kannst außerdem zeitlich begrenzt bannen, das heißt Dein Ban wird nach einer von Dir bestimmten Anzahl Sekunden wieder automatisch entfernt.
<G-vec00367-001-s113><ban.bannen><en> You can also add a timed ban where the ban you placed will be removed automatically after a number of seconds specified.
<G-vec00169-001-s127><capture.bannen><de> Wenn ich mich recht erinnere waren es sieben Kameras, mit denen an diesem Abend versucht wurde, die Magie, die ein Poets of the Fall Konzert ausmacht auf Film zu bannen.
<G-vec00169-001-s127><capture.bannen><en> If I recall correctly there were seven cameras in the house that night, trying to capture the magic of Poets of the Fall on film.
<G-vec00169-001-s128><capture.bannen><de> Der Tiroler Künstler Josef Anton Koch versuchte dagegen, die göttliche Schöpfung in seinen Naturdarstellungen zu bannen, wie das Gemälde Berner Oberland (1815) zeigt.
<G-vec00169-001-s128><capture.bannen><en> By contrast, the Tyrolean artist Josef Anton Koch aimed to capture divine creation in his images of nature, as shown in his painting Bernese Oberland (1815).
<G-vec00169-001-s129><capture.bannen><de> »Wölfl hingegen, in Mozarts Schule gebildet blieb immerdar sich gleich; nie flach, aber stets klar, und eben deswegen der Mehrzahl zugänglicher … stets wußte er Antheil zu erregen, und diesen unwandelbar an den Reihengang seiner wohlgeordneten Ideen zu bannen.
<G-vec00169-001-s129><capture.bannen><en> “Wölfl, on the other hand, bred in Mozart’s school was always the same; never shallow, but always clear, and just by this more accessible for the majority … always he knew to exite interest, and to capture this unwaveringly to the flow of his well-ordered ideas.
<G-vec00169-001-s130><capture.bannen><de> Dennoch hat er es geschafft, Musiker aufzutun, um mit ihnen und seinen bewährten Begleitmusikern ein für den Österreicher durchaus überraschendes Album auf Tonträger zu bannen.
<G-vec00169-001-s130><capture.bannen><en> Nonetheless, he managed to find musicians to work with him and his tried and tested accompanying musicians to capture an album that is thoroughly surprising for the Austrian.
<G-vec00169-001-s131><capture.bannen><de> Ein Lehrer für Fotografie vergreift sich während der Schulstunde an einer Studentin, während die Kommilitonen die Szenerie fachgerecht auf Film bannen.
<G-vec00169-001-s131><capture.bannen><en> A photography teacher assaults a student during a lesson while the fellow students capture the event on film.
<G-vec00169-001-s132><capture.bannen><de> Wo kann man sonst schon Meer, schwarzen Strand, einen Leuchtturm sowie einen Gletscher gleichzeitig auf ein Foto bannen.
<G-vec00169-001-s132><capture.bannen><en> Where else can you capture simultaneously sea, a black beach, a lighthouse and a glacier in one photograph?
<G-vec00169-001-s133><capture.bannen><de> Das hat er versucht, auf die Leinwand zu bannen.
<G-vec00169-001-s133><capture.bannen><en> He tried to capture this on canvas.
<G-vec00169-001-s134><capture.bannen><de> Übersetzung: Meike Beier Das Konzert im Irving Plaza am Montagabend wies alle Kennzeichen eines typischen a-ha-Konzertes in Norwegen auf: Journalisten von VG, Dagbladet und anderen Medien waren in Stellung, um über das Ereignis zu berichten; eine Schlange von Fans wartete seit 8 Uhr morgens vor dem Club; Lauren Savoy und eine Filmcrew war vor Ort, um das Konzert auf Film zu bannen; und Fanpartys wurden zur Feier des Tages organisiert.
<G-vec00169-001-s134><capture.bannen><en> Monday night’s concert at Irving Plaza had all the earmarks of a typical a-ha concert in Norway: journalists from VG, Dagbladet and other media on hand to cover the event; a line of fans waiting outside the venue from 8:00am; Lauren Savoy and a film crew on site to capture the concert on film; and fan parties organized to celebrate the occasion.
<G-vec00169-001-s135><capture.bannen><de> Barthes' Weise dem Kino zu widerstehen, ist es nun nicht, sich der Faszination des Spiels/Illusionsspiels zu entziehen, sie durch Ideologiekritik oder Gegenlektüren zu bannen, sondern sich sowohl dem Film als auch dem Kinoraum hinzugeben.
<G-vec00169-001-s135><capture.bannen><en> Barthes' way of resisting cinema is not to remove himself from the fascination of the performance/ the performed illusion, or to capture it in shades of ideological criticism or counter discourses; instead, he resists cinema by surrendering himself to the movie as well as to the movie theater.
<G-vec00169-001-s136><capture.bannen><de> Sascha Weidner (1976–2015) hatte den Blick für magische Momente, er wusste das Poetisch-Flüchtige auf Papier zu bannen.
<G-vec00169-001-s136><capture.bannen><en> Sascha Weidner (1976–2015) had an eye for magic moments; he knew how to capture the poetic, the fleeting on paper.
<G-vec00169-001-s137><capture.bannen><de> Obgleich Hollywood vielfach versucht hat, diese Naturwunder für den Zuschauer auf Film zu bannen, ist das nichts im Vergleich dazu, diesen Nationalpark in all seiner Pracht aus nächster Nähe zu erleben und vollkommen in diese Welt einzutauchen.
<G-vec00169-001-s137><capture.bannen><en> Though Hollywood has attempted to capture these natural wonders, nothing compares to physically standing in the national park to immerse its grandeur.
<G-vec00169-001-s138><capture.bannen><de> auf ein wunderbares Foto bannen.
<G-vec00169-001-s138><capture.bannen><en> capture on a wonderful photo.
<G-vec00555-002-s024><banish.bannen><de> Sie kennen die Naturgesetze und ihre Auswirkungen nicht, um ein solches Gebiet erforschen zu können, und sie bringen sonach Kräfte zur Auslösung, die sie selbst nicht mehr zu bannen vermögen.
<G-vec00555-002-s024><banish.bannen><en> They do not know the laws of nature and their effects in order to be able to do research on such a field and therefore trigger off forces that they are not anymore able to banish themselves.
