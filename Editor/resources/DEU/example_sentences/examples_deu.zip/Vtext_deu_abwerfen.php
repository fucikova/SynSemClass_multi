<G-vec00019-001-s020><buck.abwerfen><de> Es wird dich wahrscheinlich abwerfen.
<G-vec00019-001-s020><buck.abwerfen><en> It will probably buck you off.
<G-vec00380-002-s247><discard.abwerfen><de> Wirf eine Karte aus deiner Hand ab und ziehe eine Karte aus deinem Extradeck.
<G-vec00380-002-s247><discard.abwerfen><en> Discard a card from your hand and draw a card from your extra deck.
<G-vec00380-002-s248><discard.abwerfen><de> Wirf alle Karten in deiner Hand auf den Friedhof ab.
<G-vec00380-002-s248><discard.abwerfen><en> Discard all the cards in your hand to the Graveyard.
<G-vec00380-002-s249><discard.abwerfen><de> FLIPP: Du kannst 2 Karten ziehen, dann wirf 1 Karte ab.
<G-vec00380-002-s249><discard.abwerfen><en> FLIP: You can draw 2 cards, then discard 1 card.
<G-vec00380-002-s250><discard.abwerfen><de> Bevor ein Monstereffekt deines Gegners aufgelöst wird, sieh dir die Hand deines Gegners an und wirf 1 Karte von seiner Hand ab.
<G-vec00380-002-s250><discard.abwerfen><en> When this face-up card you control is targeted by an opponent's Effect Monster's effect, look at your opponent's hand and discard 1 card from their hand.
<G-vec00380-002-s251><discard.abwerfen><de> Wirf 1 Karte aus deiner Hand ab, um den Effekt einer Fallenkarte, die 1 offenes Monster vom Typ Drache als Ziel bestimmt, zu annullieren und die Fallenkarte zu zerstören.
<G-vec00380-002-s251><discard.abwerfen><en> Discard 1 card from your hand. Negate the effect of a Trap Card that targets 1 face-up Dragon-Type monster and destroy the Trap Card.
<G-vec00380-002-s252><discard.abwerfen><de> Wirf die übrigen Karten auf deinen Friedhof ab.
<G-vec00380-002-s252><discard.abwerfen><en> Discard the remaining cards to the Graveyard.
<G-vec00380-002-s253><discard.abwerfen><de> Wenn diese Karte deinem Gegner Kampfschaden durch einen direkten Angriff zufügt, wirf 1 zufällige Karte von der Hand deines Gegners ab.
<G-vec00380-002-s253><discard.abwerfen><en> When this card inflicts Battle Damage to your opponent by a direct attack, your opponent must discard 1 random card from their hand.
<G-vec00380-002-s254><discard.abwerfen><de> Wirf diese Karte aus deiner Hand ab, um Kampfschaden, den alle Monster, deren Name "Grabwächter" enthält, bis zur End Phase dieses Spielzugs erhalten, 0 werden zu lassen.
<G-vec00380-002-s254><discard.abwerfen><en> Discard this card from your hand. Until the End Phase, make the Battle Damage to monsters that include "Gravekeeper's" in their card name 0.
<G-vec00380-002-s255><discard.abwerfen><de> Am Ende deiner Battle Phase, falls diese Karte angegriffen hat oder angegriffen wurde: Mische diese Karte ins Deck oder wirf 1 Karte ab.
<G-vec00380-002-s255><discard.abwerfen><en> At the end of your Battle Phase, if this card attacked or was attacked: Shuffle this card into the Deck or discard 1 card.
