<G-vec00169-001-s036><fetch.abrufen><de> Ist der Wert niedriger, werden zum Abrufen der Geräte mehr Threads verwendet.
<G-vec00169-001-s036><fetch.abrufen><en> If the value is lower, more threads fetch the devices.
<G-vec00169-001-s037><fetch.abrufen><de> Microsoft Windows Small Business Server (SBS)-Versionen enthalten einen nativen, integrierten POP3-Connector, mit dem der Server E-Mail-Nachrichten von externen POP3-Servern abrufen kann.
<G-vec00169-001-s037><fetch.abrufen><en> Microsoft Windows Small Business Server (SBS) versions contain a native built-in POP3 Connector that enables the server to fetch email messages from external POP3 servers.
<G-vec00169-001-s038><fetch.abrufen><de> Wenn diese Methoden jedoch keine Ergebnisse abrufen und der Fehler weiterhin bei der WinRAR-Datei auftritt, sollten Sie Reparaturwerkzeuge für RAR-Dateien von Drittanbietern verwenden.
<G-vec00169-001-s038><fetch.abrufen><en> But, if these methods doesn’t fetch any results and the error still persists with WinRAR file, then make use of third party RAR file repair tools.
<G-vec00169-001-s039><fetch.abrufen><de> Klicken Sie auf Aktualisierten PGP-Schlüssel abrufen.
<G-vec00169-001-s039><fetch.abrufen><en> Click Fetch Updated PGP Key.
<G-vec00169-001-s040><fetch.abrufen><de> Ihre Änderungen werden bei der nächsten Synchronisierung (standardmäßig alle fünf Minuten) oder beim Abrufen (standardmäßig alle 24 Stunden) in der XenMobile-Konsole angezeigt.
<G-vec00169-001-s040><fetch.abrufen><en> Your updates appear in the XenMobile console during the next sync (every five minutes by default) or fetch (every 24 hours by default).
<G-vec00169-001-s041><fetch.abrufen><de> Der Begriff Abrufen ist spezifischer und bezieht sich darauf, wie das Feature für gestreamte Benutzerprofile zu einem beliebigen Zeitpunkt nach der Anmeldung eine Untergruppe von Dateien vom Benutzerspeicher herunterlädt, wenn der Benutzer sie benötigt.
<G-vec00169-001-s041><fetch.abrufen><en> The term fetch is more specific and refers to how the streamed user profiles feature downloads, any time after logon when the user needs them, a subset of files from the user store.
<G-vec00169-001-s042><fetch.abrufen><de> Mit Zypper können Sie Änderungen in Paketen aus konfigurierten Repositorys abrufen.
<G-vec00169-001-s042><fetch.abrufen><en> zypper enables you to fetch changes in packages from configured repositories.
<G-vec00169-001-s043><fetch.abrufen><de> Nachdem Sie eine Sammlung geöffnet haben, können Sie mit der folgenden API alle Dokumente der Sammlung abrufen.
<G-vec00169-001-s043><fetch.abrufen><en> Fetching data from a Collection: After you have opened a collection, you can fetch all the documents using the following API.
<G-vec00169-001-s044><fetch.abrufen><de> Sie können einfach einen anonymen FTP-Abruf auf das Debian-Archiv starten, dann die Verzeichnisse durchgehen, bis die gewünschte Datei gefunden wird, diese dann abrufen, und diese schließlich mit dpkg installieren.
<G-vec00169-001-s044><fetch.abrufen><en> One could simply execute an anonymous ftp call to a Debian archive, then peruse the directories until one finds the desired file, and then fetch it, and finally install it using dpkg.
<G-vec00169-001-s045><fetch.abrufen><de> das Schlüsselwort SUSPEND verwendet, damit der Aufrufer die Ausgabezeilen nacheinander abrufen kann, genau so wie bei der Auswahl aus einer Tabelle oder Ansicht.
<G-vec00169-001-s045><fetch.abrufen><en> utilizes the SUSPEND keyword so the caller can fetch the output rows one by one, just as when selecting from a table or view.
<G-vec00169-001-s046><fetch.abrufen><de> Sie können sie auch aus dem Verzeichnis DB2-Installationsverzeichnis/java von DB2 Server abrufen und in das Verzeichnis $TOMCAT_HOME/lib stellen.
<G-vec00169-001-s046><fetch.abrufen><en> Or fetch it from the directory db2_install_dir/java on the DB2 server) to $TOMCAT_HOME/lib.
<G-vec00169-001-s047><fetch.abrufen><de> Optional kann der CRL-Veröffentlichungspunkt als Erweiterung im Zertifikat benannt werden, sodass ein Prüfer die aktuelle CRL zur Validierung abrufen kann.
<G-vec00169-001-s047><fetch.abrufen><en> The CDP can optionally be named as an extension in the certificate, so a checker can fetch a current CRL for validation purposes.
<G-vec00169-001-s048><fetch.abrufen><de> YOUTUBE_FILE_EX Wir konnten die hochzuladende Videodatei nicht abrufen.
<G-vec00169-001-s048><fetch.abrufen><en> YOUTUBE_FILE_EX We were unable to fetch your video file to upload
<G-vec00169-001-s049><fetch.abrufen><de> Wenn das System den Private Key nicht abrufen kann, finden Sie diesen im Abschnitt Private Keys (KEY) des SSL/TLS-Managers.
<G-vec00169-001-s049><fetch.abrufen><en> If the system fails to fetch the private key, you can locate it in the Private Keys (KEY) section of the SSL/TLS Manager.
<G-vec00169-001-s050><fetch.abrufen><de> Siehe Abrufen von Inhalten auf der Seite in der Episerver CMS unter Verknüpfung in In der Bearbeitungsansicht Alle Eigenschaften arbeiten.
<G-vec00169-001-s050><fetch.abrufen><en> See Fetch content from page in Episerver CMS under Shortcut in Working in All properties editing view.
<G-vec00169-001-s051><fetch.abrufen><de> Inhalt aus einem anderen Inhaltselement abrufen.
<G-vec00169-001-s051><fetch.abrufen><en> Fetch content from another content item.
<G-vec00169-001-s057><fetch.abrufen><de> Wenn das Benutzergerät versucht, Inhalte von einer Webseite abzurufen, die dem ersten Schema (dem URL-Übereinstimmungsschema) entspricht, werden sie an eine Webseite weitergeleitet, die mit dem zweiten Schema festgelegt wurde (dem Ersetzungsschema).
<G-vec00169-001-s057><fetch.abrufen><en> When the user device attempts to fetch content from a website matching the first pattern (the URL match pattern), it is redirected to the website specified by the second pattern (the rewritten URL format).
<G-vec00169-001-s058><fetch.abrufen><de> Wenn bei der Mail App die Nachricht «Hintergrundaktivität» angezeigt wird, kannst du auswählen, die Daten manuell abzurufen, oder den Zeitabstand fürs Abrufen verlängern.
<G-vec00169-001-s058><fetch.abrufen><en> If the Mail app lists Background Activity, you can choose to fetch data manually or increase the fetch interval.
<G-vec00169-001-s059><fetch.abrufen><de> Jeder kommuniziert mit dem Schlüsselserver, um einen Schlüssel oder ein Zertifikat zum automatischen Entsperren der Volumes abzurufen, sodass Daten sicher bleiben und die Wiederherstellungsdauer nach einem Systemneustart reduziert werden kann.
<G-vec00169-001-s059><fetch.abrufen><en> Each one communicates with the key server to fetch a key or certificate to unlock the volumes automatically, keeping data secure and reducing recovery time after a system restart.
<G-vec00035-001-s019><redeem.abrufen><de> Phen375 ist eine sichere und 100% alle natürlichen äußerst effizienten Ersatz der nun verbotenen chemischen Medikamente, die Sie vielleicht in den Tag abzurufen, wenn sie immer noch zugelassen waren.
<G-vec00035-001-s019><redeem.abrufen><en> Phen375 is a secure and 100 % all-natural strongly efficient substitute of the now restricted chemical medications you can redeem in the day when they were still authorized.
<G-vec00035-001-s020><redeem.abrufen><de> Alle bereits registrierten PSN-Mitglieder haben nach dem Start des Welcome Back (Willkommen zurück)-Programms 30 Tage Zeit, um ihre Inhalte abzurufen.
<G-vec00035-001-s020><redeem.abrufen><en> All existing PSN registrants have 30 days from when the welcome back programme goes live to redeem their content.
<G-vec00169-001-s169><fetch.abrufen><de> Sie können festlegen, wann diese Daten zwischengespeichert werden sollen, indem Sie den geplanten Auftrag Daten von Marketing-Konnektoren abrufen konfigurieren.
<G-vec00169-001-s169><fetch.abrufen><en> You can determine when to cache this data by configuring the Fetch data from Marketing Connectors scheduled job.
<G-vec00169-001-s170><fetch.abrufen><de> Sie können festlegen, wann diese Daten zwischengespeichert werden sollen, indem Sie den geplanten Auftrag Daten von MAI-Konnektor abrufen.
<G-vec00169-001-s170><fetch.abrufen><en> You can determine when to cache this data by configuring the Fetch data from MAI Connector scheduled job.
<G-vec00246-002-s052><reactivate.abrufen><de> Im Custom-Modus kann der Fahrer die Fahreigenschaften anhand der drei grundlegenden Werte Stabilisierung, Balance und Agilität frei konfigurieren, abspeichern und jederzeit abrufen.
<G-vec00246-002-s052><reactivate.abrufen><en> In Custom Mode, the driver can freely configure the vehicle's handling characteristics via three basic variables – stability, balance and agility – and can save and reactivate the configuration at any time.
<G-vec00321-002-s019><pull.abrufen><de> Preise und Zeitpläne für diesen Service können abhängig von der Plattform und den Daten, die Sie abrufen möchten, variieren, sodass Sie sich für weitere Informationen zu diesem Dienst am besten an Ihren Account Manager wenden können.
<G-vec00321-002-s019><pull.abrufen><en> Pricing and timelines for this service can vary depending on the platform, and data you are looking to pull so it is best to reach out to your Account Manager for additional information on this service.
<G-vec00321-002-s020><pull.abrufen><de> Wählen Sie zwischen Abrufen und Senden von Berichten.
<G-vec00321-002-s020><pull.abrufen><en> Choose between push or pull reports.
<G-vec00321-002-s021><pull.abrufen><de> Geräteverwaltung, die die Installation, Konfiguration, Verwaltung, Überwachung und das Abrufen von Berichten von vernetzten Druckern und Multifunktionsdruckern im gesamten Unternehmen vereinfachen – unabhängig vom Gerätehersteller.
<G-vec00321-002-s021><pull.abrufen><en> Xerox® Device Manager and Xerox CentreWare Web are device management software tools make it easy to install, configure, manage, monitor and pull reports from networked and multifunction printers throughout the enterprise, regardless of the manufacturer.
<G-vec00321-002-s022><pull.abrufen><de> Ein SIEM kann Daten aus unterschiedlichen Systemen abrufen oder eine separate Log-Management-Plattform verwenden, um eine einstufige Transparenz zu schaffen.
<G-vec00321-002-s022><pull.abrufen><en> A SIEM can pull data from disparate systems or use a separate log management platform to create single pane of glass visibility.
<G-vec00321-002-s023><pull.abrufen><de> Ausführen einer Reihe von PowerShell-Befehlen zum Abrufen der Eigenschaften des Gastbenutzerkontos.
<G-vec00321-002-s023><pull.abrufen><en> Run a series of PowerShell commands to pull up the guest user account properties.
<G-vec00321-002-s024><pull.abrufen><de> Dadurch kann eine andere Object Gateway-Instanz die Konfiguration mit dem Zugriffsschlüssel und geheimen Schlüssel entfernt abrufen.
<G-vec00321-002-s024><pull.abrufen><en> This allows another Object Gateway instance to pull the configuration remotely with the access and secret keys.
<G-vec00321-002-s025><pull.abrufen><de> Sie können Lattice Microbes herunterladen und im Bare-Metal-Verfahren installieren oder den Container aus NVIDIA GPU Cloud abrufen und ausführen.
<G-vec00321-002-s025><pull.abrufen><en> You have the option to download and install Lattice Microbes on bare-metal or pull and run the container from NVIDIA GPU Cloud.
<G-vec00321-002-s026><pull.abrufen><de> Eine Abfrage kann die Informationen aus verschiedenen Tabellen abrufen und zusammensetzen, damit sie im Formular oder Bericht angezeigt werden können.
<G-vec00321-002-s026><pull.abrufen><en> A query can pull the information from various tables and assemble it for display in the form or report.
<G-vec00321-002-s027><pull.abrufen><de> Weil der Google-Crawler (Googlebot) Ihren Content so „lesen“ muss, dass er die Informationen abrufen kann, um sie effektiv zu nutzen und ihre Relevanz für Nutzer sicherzustellen.
<G-vec00321-002-s027><pull.abrufen><en> Because Google’s crawler (Googlebot) needs to “read” your content in a way that can allow it to pull the information to use it effectively and ensure its relevance to users.
<G-vec00321-002-s028><pull.abrufen><de> Bei der Arbeit in einem Team ermöglichen Ihnen Remote-Repositorys das Übertragen und Abrufen von Daten zwischen Repositorys.
<G-vec00321-002-s028><pull.abrufen><en> When you work in a team, remote repositories help you push and pull data to and from other repositories.
<G-vec00321-002-s029><pull.abrufen><de> Microgaming möchte Ihnen außerdem Casino War so einfach wie möglich machen - Sie können jederzeit Ihre Spielstatistiken abrufen und verschiedene Optionen und Spielmodi einstellen, um das Spiel an Ihre Vorlieben und Fähigkeiten anzupassen.
<G-vec00321-002-s029><pull.abrufen><en> Microgaming also aim to make Casino War as easy as possible for you - at any time you can pull up your games' statistics, different options and play modes to tailor the game to your preferences and skill level.
<G-vec00321-002-s030><pull.abrufen><de> Sie können den Quellcode herunterladen und GAMESS im Bare-Metal-Verfahren installieren oder den GAMESS-Container aus der NVIDIA GPU Cloud abrufen und ausführen.
<G-vec00321-002-s030><pull.abrufen><en> You have the option to download the source code and install GAMESS on bare-metal or pull and run the GAMESS container from NVIDIA GPU Cloud.
<G-vec00321-002-s031><pull.abrufen><de> Sie können Informationen direkt aus Anfragen abrufen und schnell Antworten senden.
<G-vec00321-002-s031><pull.abrufen><en> You can pull information directly from inquiries and send responses quickly.
<G-vec00321-002-s032><pull.abrufen><de> Obwohl viele Tools Benutzer- und Gruppenberechtigungen aus Active Directory abrufen können, bieten sie nicht die notwendige Skalierung oder Schnelligkeit.
<G-vec00321-002-s032><pull.abrufen><en> Although PowerShell can pull user and group permissions from Active Directory, it’s not scalable or fast enough to meet IT needs.
<G-vec00355-002-s209><fetch.abrufen><de> Hierdurch wird die Gesamtzahl der Roundtrips reduziert, die zum Abrufen der Daten erforderlich sind, und so die Bereitstellung von Webinhalten beschleunigt.
<G-vec00355-002-s209><fetch.abrufen><en> This reduces the total number of round trips needed to fetch data and leads to accelerated delivery of web content.
<G-vec00361-002-s021><solicit.abrufen><de> Personenbezogene Informationen von Minderjährigen (Personen unter 18 Jahren) abrufen oder sammeln, einschließlich, aber nicht beschränkt auf: Name, E-Mail-Adresse, Privatadresse, Telefonnummer oder den Namen ihrer Schule.
<G-vec00361-002-s021><solicit.abrufen><en> is designed to solicit, or collect personally identifiable information of any minor (anyone under 18 years old), including, but not limited to: name, email address, home address, phone number, or the name of their school.
<G-vec00364-002-s019><recall.abrufen><de> Der Bundesrat besteht aus Mitgliedern der Regierungen der Länder, die sie bestellen und abberufen.
<G-vec00364-002-s019><recall.abrufen><en> The Bundesrat shall consist of members of the Land governments, which appoint and recall them.
<G-vec00364-002-s020><recall.abrufen><de> Die Gesellschafter können ihn nicht abberufen, jedoch können sie bei Gericht den entsprechenden Antrag stellen.
<G-vec00364-002-s020><recall.abrufen><en> The shareholders can not recall him, but they can make a request to the court.
<G-vec00364-002-s021><recall.abrufen><de> Den Projektleiter ernennen oder abberufen.
<G-vec00364-002-s021><recall.abrufen><en> Appoint or recall the Project Leader.
