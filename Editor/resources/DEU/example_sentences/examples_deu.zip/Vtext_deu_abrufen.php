<G-vec00169-001-s036><fetch.abrufen><de> Ist der Wert niedriger, werden zum Abrufen der Geräte mehr Threads verwendet.
<G-vec00169-001-s036><fetch.abrufen><en> If the value is lower, more threads fetch the devices.
<G-vec00169-001-s037><fetch.abrufen><de> Microsoft Windows Small Business Server (SBS)-Versionen enthalten einen nativen, integrierten POP3-Connector, mit dem der Server E-Mail-Nachrichten von externen POP3-Servern abrufen kann.
<G-vec00169-001-s037><fetch.abrufen><en> Microsoft Windows Small Business Server (SBS) versions contain a native built-in POP3 Connector that enables the server to fetch email messages from external POP3 servers.
<G-vec00169-001-s038><fetch.abrufen><de> Wenn diese Methoden jedoch keine Ergebnisse abrufen und der Fehler weiterhin bei der WinRAR-Datei auftritt, sollten Sie Reparaturwerkzeuge für RAR-Dateien von Drittanbietern verwenden.
<G-vec00169-001-s038><fetch.abrufen><en> But, if these methods doesn’t fetch any results and the error still persists with WinRAR file, then make use of third party RAR file repair tools.
<G-vec00169-001-s039><fetch.abrufen><de> Klicken Sie auf Aktualisierten PGP-Schlüssel abrufen.
<G-vec00169-001-s039><fetch.abrufen><en> Click Fetch Updated PGP Key.
<G-vec00169-001-s040><fetch.abrufen><de> Ihre Änderungen werden bei der nächsten Synchronisierung (standardmäßig alle fünf Minuten) oder beim Abrufen (standardmäßig alle 24 Stunden) in der XenMobile-Konsole angezeigt.
<G-vec00169-001-s040><fetch.abrufen><en> Your updates appear in the XenMobile console during the next sync (every five minutes by default) or fetch (every 24 hours by default).
<G-vec00169-001-s041><fetch.abrufen><de> Der Begriff Abrufen ist spezifischer und bezieht sich darauf, wie das Feature für gestreamte Benutzerprofile zu einem beliebigen Zeitpunkt nach der Anmeldung eine Untergruppe von Dateien vom Benutzerspeicher herunterlädt, wenn der Benutzer sie benötigt.
<G-vec00169-001-s041><fetch.abrufen><en> The term fetch is more specific and refers to how the streamed user profiles feature downloads, any time after logon when the user needs them, a subset of files from the user store.
<G-vec00169-001-s042><fetch.abrufen><de> Mit Zypper können Sie Änderungen in Paketen aus konfigurierten Repositorys abrufen.
<G-vec00169-001-s042><fetch.abrufen><en> zypper enables you to fetch changes in packages from configured repositories.
<G-vec00169-001-s043><fetch.abrufen><de> Nachdem Sie eine Sammlung geöffnet haben, können Sie mit der folgenden API alle Dokumente der Sammlung abrufen.
<G-vec00169-001-s043><fetch.abrufen><en> Fetching data from a Collection: After you have opened a collection, you can fetch all the documents using the following API.
<G-vec00169-001-s044><fetch.abrufen><de> Sie können einfach einen anonymen FTP-Abruf auf das Debian-Archiv starten, dann die Verzeichnisse durchgehen, bis die gewünschte Datei gefunden wird, diese dann abrufen, und diese schließlich mit dpkg installieren.
<G-vec00169-001-s044><fetch.abrufen><en> One could simply execute an anonymous ftp call to a Debian archive, then peruse the directories until one finds the desired file, and then fetch it, and finally install it using dpkg.
<G-vec00169-001-s045><fetch.abrufen><de> das Schlüsselwort SUSPEND verwendet, damit der Aufrufer die Ausgabezeilen nacheinander abrufen kann, genau so wie bei der Auswahl aus einer Tabelle oder Ansicht.
<G-vec00169-001-s045><fetch.abrufen><en> utilizes the SUSPEND keyword so the caller can fetch the output rows one by one, just as when selecting from a table or view.
<G-vec00169-001-s046><fetch.abrufen><de> Sie können sie auch aus dem Verzeichnis DB2-Installationsverzeichnis/java von DB2 Server abrufen und in das Verzeichnis $TOMCAT_HOME/lib stellen.
<G-vec00169-001-s046><fetch.abrufen><en> Or fetch it from the directory db2_install_dir/java on the DB2 server) to $TOMCAT_HOME/lib.
<G-vec00169-001-s047><fetch.abrufen><de> Optional kann der CRL-Veröffentlichungspunkt als Erweiterung im Zertifikat benannt werden, sodass ein Prüfer die aktuelle CRL zur Validierung abrufen kann.
<G-vec00169-001-s047><fetch.abrufen><en> The CDP can optionally be named as an extension in the certificate, so a checker can fetch a current CRL for validation purposes.
<G-vec00169-001-s048><fetch.abrufen><de> YOUTUBE_FILE_EX Wir konnten die hochzuladende Videodatei nicht abrufen.
<G-vec00169-001-s048><fetch.abrufen><en> YOUTUBE_FILE_EX We were unable to fetch your video file to upload
<G-vec00169-001-s049><fetch.abrufen><de> Wenn das System den Private Key nicht abrufen kann, finden Sie diesen im Abschnitt Private Keys (KEY) des SSL/TLS-Managers.
<G-vec00169-001-s049><fetch.abrufen><en> If the system fails to fetch the private key, you can locate it in the Private Keys (KEY) section of the SSL/TLS Manager.
<G-vec00169-001-s050><fetch.abrufen><de> Siehe Abrufen von Inhalten auf der Seite in der Episerver CMS unter Verknüpfung in In der Bearbeitungsansicht Alle Eigenschaften arbeiten.
<G-vec00169-001-s050><fetch.abrufen><en> See Fetch content from page in Episerver CMS under Shortcut in Working in All properties editing view.
<G-vec00169-001-s051><fetch.abrufen><de> Inhalt aus einem anderen Inhaltselement abrufen.
<G-vec00169-001-s051><fetch.abrufen><en> Fetch content from another content item.
<G-vec00169-001-s057><fetch.abrufen><de> Wenn das Benutzergerät versucht, Inhalte von einer Webseite abzurufen, die dem ersten Schema (dem URL-Übereinstimmungsschema) entspricht, werden sie an eine Webseite weitergeleitet, die mit dem zweiten Schema festgelegt wurde (dem Ersetzungsschema).
<G-vec00169-001-s057><fetch.abrufen><en> When the user device attempts to fetch content from a website matching the first pattern (the URL match pattern), it is redirected to the website specified by the second pattern (the rewritten URL format).
<G-vec00169-001-s058><fetch.abrufen><de> Wenn bei der Mail App die Nachricht «Hintergrundaktivität» angezeigt wird, kannst du auswählen, die Daten manuell abzurufen, oder den Zeitabstand fürs Abrufen verlängern.
<G-vec00169-001-s058><fetch.abrufen><en> If the Mail app lists Background Activity, you can choose to fetch data manually or increase the fetch interval.
<G-vec00169-001-s059><fetch.abrufen><de> Jeder kommuniziert mit dem Schlüsselserver, um einen Schlüssel oder ein Zertifikat zum automatischen Entsperren der Volumes abzurufen, sodass Daten sicher bleiben und die Wiederherstellungsdauer nach einem Systemneustart reduziert werden kann.
<G-vec00169-001-s059><fetch.abrufen><en> Each one communicates with the key server to fetch a key or certificate to unlock the volumes automatically, keeping data secure and reducing recovery time after a system restart.
<G-vec00035-001-s019><redeem.abrufen><de> Phen375 ist eine sichere und 100% alle natürlichen äußerst effizienten Ersatz der nun verbotenen chemischen Medikamente, die Sie vielleicht in den Tag abzurufen, wenn sie immer noch zugelassen waren.
<G-vec00035-001-s019><redeem.abrufen><en> Phen375 is a secure and 100 % all-natural strongly efficient substitute of the now restricted chemical medications you can redeem in the day when they were still authorized.
<G-vec00035-001-s020><redeem.abrufen><de> Alle bereits registrierten PSN-Mitglieder haben nach dem Start des Welcome Back (Willkommen zurück)-Programms 30 Tage Zeit, um ihre Inhalte abzurufen.
<G-vec00035-001-s020><redeem.abrufen><en> All existing PSN registrants have 30 days from when the welcome back programme goes live to redeem their content.
<G-vec00169-001-s169><fetch.abrufen><de> Sie können festlegen, wann diese Daten zwischengespeichert werden sollen, indem Sie den geplanten Auftrag Daten von Marketing-Konnektoren abrufen konfigurieren.
<G-vec00169-001-s169><fetch.abrufen><en> You can determine when to cache this data by configuring the Fetch data from Marketing Connectors scheduled job.
<G-vec00169-001-s170><fetch.abrufen><de> Sie können festlegen, wann diese Daten zwischengespeichert werden sollen, indem Sie den geplanten Auftrag Daten von MAI-Konnektor abrufen.
<G-vec00169-001-s170><fetch.abrufen><en> You can determine when to cache this data by configuring the Fetch data from MAI Connector scheduled job.
<G-vec00169-001-s171><fetch.abrufen><de> Sie können festlegen, wann diese Daten zwischengespeichert werden sollen, indem Sie den geplanten Auftrag Daten von MAI-Konnektor abrufen.
<G-vec00169-001-s171><fetch.abrufen><en> You can determine when to cache this data by configuring the Fetch data from Marketing Connectors scheduled job.
