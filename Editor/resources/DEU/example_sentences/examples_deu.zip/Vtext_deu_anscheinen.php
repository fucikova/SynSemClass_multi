<G-vec00381-002-s057><seem.anscheinen><de> Es macht den Anschein als würde man dort kein Geld mehr investieren.
<G-vec00381-002-s057><seem.anscheinen><en> It makes it seem as if you were there to invest any more money.
<G-vec00381-002-s058><seem.anscheinen><de> Die SATA Bridge IC's harmonisieren allen Anschein nach perfekt mit den anderen, sehr proffessionell an der Wasabi Platine befestigten Komponenten.
<G-vec00381-002-s058><seem.anscheinen><en> The SATA bridge IC's all seem to harmonize perfectly with all other very professional attached motherboard components.
<G-vec00381-002-s059><seem.anscheinen><de> Nein sind sie nicht, obwohl es manchmal den Anschein hat.
<G-vec00381-002-s059><seem.anscheinen><en> No, they aren’t although it may seem like they are.
<G-vec00381-002-s060><seem.anscheinen><de> Allerdings gibt es einige Problempunkte, die mit dem geänderten Vorschlag der Kommission allem Anschein nach nicht gelöst werden konnten.
<G-vec00381-002-s060><seem.anscheinen><en> However, there are still certain problematic points which the amended Commission proposal does not seem to have succeeded in resolving.
<G-vec00381-002-s061><seem.anscheinen><de> Sehr positive Kommentare sind oft über ihre Backhendl gehört und der Preis macht es den Anschein, dass es fast billiger ist Essengehen als sein Kauf von Lebensmitteln.
<G-vec00381-002-s061><seem.anscheinen><en> Very positive comments are often heard about their fried chicken and the price makes it seem that it is almost cheaper eating out than to be buying groceries.
<G-vec00381-002-s062><seem.anscheinen><de> 8 Denn wenn ich mich auch etwas mehr über unsere Vollmacht rühme, die uns der Herr zu eurer Erbauung und nicht zu eurer Zerstörung gegeben hat, so werde ich nicht zuschanden werden, 9 damit ich nicht den Anschein erwecke, als wolle ich euch durch die Briefe schrecken.
<G-vec00381-002-s062><seem.anscheinen><en> 8 For though I should boast somewhat abundantly concerning our authority, (which the Lord gave for building you up, and not for casting you down) I will not be put to shame, 9 that I may not seem as if I desire to terrify you by my letters.
<G-vec00381-002-s063><seem.anscheinen><de> Es hat nicht den Anschein, daß diese Person, wer immer es war, zu ihnen gehört hat oder auch nur ein Engländer war; aber es wird von ihm auch nicht ausdrücklich als von einem der Gegner gesprochen.
<G-vec00381-002-s063><seem.anscheinen><en> It does not seem as if this person, whoever he was, was one of themselves, nor even an Englishman; neither is he exactly spoken of as one of the enemy.
<G-vec00381-002-s064><seem.anscheinen><de> Generell machte es nicht den Anschein, als wäre das Zimmer frisch gereinigt worden.
<G-vec00381-002-s064><seem.anscheinen><en> Generally it did not seem as if the room had been recently cleaned.
<G-vec00381-002-s065><seem.anscheinen><de> Es erweckt den Anschein, dass ICOs generell im Sterben liegen, aber wie dieser Artikel zeigt, sind die Menschen bereit, viel zu investieren, wenn sie das richtige Projekt finden.
<G-vec00381-002-s065><seem.anscheinen><en> It might seem like ICOs are dying but as this report shows, people are willing to invest more given the right project and set of regulations.
<G-vec00381-002-s066><seem.anscheinen><de> Die virtuelle Welt der digitalen Kommunikation und die Straße stehen einander näher, als es den Anschein hat.
<G-vec00381-002-s066><seem.anscheinen><en> The virtual world of digital communication and the streets are closer to each other than it may seem.
<G-vec00381-002-s067><seem.anscheinen><de> Wenn du einfach hineinkommst und nach einer Gehaltserhöhung fragst, wirkst du unvorbereitet und erweckst den Anschein, als ob du keine verdient hast.
<G-vec00381-002-s067><seem.anscheinen><en> If you just walk up and ask for a raise, you'll seem unprepared -- and come across like you don't deserve one.
<G-vec00381-002-s068><seem.anscheinen><de> Unter Gegnerdruck nach einem Sprint von zwanzig Metern knapp hinter der Mittellinie voller Wucht abzuschließen und ein Tor zu machen, ist gar nicht so einfach, wie es das wegen des leerstehenden Tores den Anschein macht.
<G-vec00381-002-s068><seem.anscheinen><en> Finishing under pressure and after a sprint from twenty meters behind the halfway line and scoring a goal with full force isn’t as easy as the empty goal makes it seem to be.
<G-vec00381-002-s069><seem.anscheinen><de> Es hat den Anschein, dass Maria durch ihre Unbefleckte Empfängnis abermals die Antwort auf diese Suche ist.
<G-vec00381-002-s069><seem.anscheinen><en> It would seem that Mary in her Immaculate Conception again is the right answer to this quest.
<G-vec00381-002-s070><seem.anscheinen><de> Du gibst den Anschein, daß es profitabler wäre, ein Sünder zu sein als ein Christ.
<G-vec00381-002-s070><seem.anscheinen><en> You make it seem as if it's more profitable to be sinner than a Christian.
<G-vec00381-002-s071><seem.anscheinen><de> Während es für manche den Anschein von einem brandneuen Nahrungsmittel erweckt, benutzen die Menschen in Zentralamerika Chiasamen schon seit Jahrhunderten und fügen sie zu Speisen oder Medizin hinzu.
<G-vec00381-002-s071><seem.anscheinen><en> While they might seem like a brand new food to many of us, people living in Central America have been using chia seeds since ancient times, adding them to the food and using them in medicine too.
<G-vec00381-002-s072><seem.anscheinen><de> Zu große Kleidung erweckt vielleicht den Anschein, dass sie dir einen Gefallen tut, indem sie deinen Körper versteckt, aber sie vermittelt tatsächlich einen Mangel an Selbstvertrauen.
<G-vec00381-002-s072><seem.anscheinen><en> Clothes that are too big might seem like they're doing you a favor by hiding your body, but they're actually communicating a lack of confidence.
<G-vec00381-002-s073><seem.anscheinen><de> Heute ist es genauso, auch wenn es den Anschein hat, dass der Böse siegt.
<G-vec00381-002-s073><seem.anscheinen><en> Today it is exactly the same case, even though it may seem that evil has the upper hand.
<G-vec00381-002-s074><seem.anscheinen><de> Doch jetzt wird es ganz verrückt: bei Erlebnissen, die unsere Wissenschaftler als nicht real oder illusorisch definieren – wir nennen sie Halluzinationen – bei diesen Erlebnissen berichten Menschen überall auf der Welt alle von denselben Erfahrungen, und zwar, dass sie den Eindruck haben, in ein anderes Reich einzutreten, das sich absolut real anfühlt, überzeugend nahtlos real und das von intelligenten Wesen bewohnt wird, die allem Anschein nach mit dir kommunizieren wollen.
<G-vec00381-002-s074><seem.anscheinen><en> But here is the bizarre thing: in experiences that our scientists define as non-real or illusory, the experiences that we call hallucinations, in those experiences people all over the world universally report the same experiences, and that is the experience of passing through into another realm which is absolutely real, convincingly, seamlessly real, which is inhabited by intelligent beings who seem to want to communicate with you.
<G-vec00381-002-s075><seem.anscheinen><de> Noch steht aus, dass alle Kräfte in Aufruhr geraten, und die Atome in einem Chaos herumwirbeln, damit nach alledem eine Lethargie, eine Erschöpfung, eine Traurigkeit und ein Ekel eintritt, die den Anschein des Todes erwecken.
<G-vec00381-002-s075><seem.anscheinen><en> It is necessary yet for all the forces to agitate, and the atoms to spin in chaos so that afterward, there can come the lethargy, the fatigue, the sadness, and the weariness that seem like death. 97.
