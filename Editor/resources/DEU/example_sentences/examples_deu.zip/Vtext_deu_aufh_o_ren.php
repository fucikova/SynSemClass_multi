<G-vec00081-001-s043><cease.aufhören><de> 17 Dort haben die Gottlosen aufgehört mit Toben; dort ruhen, die viel Mühe gehabt haben.
<G-vec00081-001-s043><cease.aufhören><en> 17 There the wicked cease from tumult, and there the wearied in strength are at rest.
<G-vec00081-001-s044><cease.aufhören><de> Mit dem Eintritt der Arbeiter in den kombinierten Arbeitsprozeß haben die Arbeiter schon aufgehört, sich selbst zu gehören, sie sind dem Kapital einverleibt.
<G-vec00081-001-s044><cease.aufhören><en> When the labourers enter the combined labour process, they already cease to belong to themselves; they are incorporated in capital.
<G-vec00081-001-s045><cease.aufhören><de> "Denn ""obwohl die Kirche in der Kraft des Heiligen Geistes die treue Braut des Herrn geblieben ist und niemals aufgehört hat, das Zeichen des Heils in der Welt zu sein, so weiß sie doch klar, dass unter ihren Gliedern, ob Klerikern oder Laien, im Lauf so vieler Jahrhunderte immer auch Untreue gegen den Geist Gottes sich fand..."
<G-vec00081-001-s045><cease.aufhören><en> "In fact, ""Although by the power of the Holy Spirit the Church will remain the faithful spouse of her Lord and will never cease to be the sign of salvation on earth, still she is very well aware that among her members, both clerical and lay, some have been unfaithful to the Spirit of God during the course of many centuries..."
<G-vec00081-001-s046><cease.aufhören><de> Sie erlösche in dem Geld als indifferentes Resultat, das, insofern es nicht mehr in Bezug auf Waren, Preise, Zirkulation stünde, aufgehört hätte Geld, ein Produktionsverhältnis auszudrücken; von dem nur noch sein metallisches Dasein übriggeblieben, aber sein ökonomisches vernichtet wäre.
<G-vec00081-001-s046><cease.aufhören><en> It would flicker out in money as an indifferent result, in so far as money, would no longer have any connection with commodities, prices, circulation, cease to be money and express a production relationship; leaving no more than its metallic being, with its economic being annihilated.
<G-vec00081-001-s047><cease.aufhören><de> Und tatsächlich hat Israel über fast zwei Jahrtausende in der Zerstreuung – im Gegensatz zu manchen anderen Völkern der damaligen Zeit - nicht aufgehört als Geschlecht zu existieren.
<G-vec00081-001-s047><cease.aufhören><en> And indeed, Israel did not cease to exist as a strain although it had been dispersed for almost two thousand years – in contrast to a good many other peoples of that time.
<G-vec00081-001-s048><cease.aufhören><de> Darum wacht und denkt daran, daß ich drei Jahre lang Nacht und Tag nicht aufgehört habe, einen jeden unter Tränen zu ermahnen.
<G-vec00081-001-s048><cease.aufhören><en> Therefore watch and remember that for three years, night and day, I did not cease to teach every one of you with tears.
<G-vec00081-001-s049><cease.aufhören><de> Deshalb schloss er diese ihm unbekannten Gläubigen besonders in seine Fürbittegewohnheit ein und rang mit dem Herrn anhaltend darum, dass ihr Glaube nicht aufhöre und ihre Versucher abgewimmelt werden können.
<G-vec00081-001-s049><cease.aufhören><en> He continually wrestled with the Lord in prayer, asking that their faith might not cease and that they be enabled to shake off their tempter.
<G-vec00081-001-s050><cease.aufhören><de> Aber sie bedient sich der,ökonomischen' Agitation, um an die Regierung nicht nur die Forderung nach allen möglichen Maßnahmen zu stellen, sondern auch (und vor allem) die Forderung, dass sie aufhöre, eine autokratische Regierung zu sein.
<G-vec00081-001-s050><cease.aufhören><en> But it utilises 'economic' agitation for the purpose of presenting to the government, not only demands for all sorts of measures, but also (and primarily) the demand that it cease to be an autocratic government.
<G-vec00081-001-s051><cease.aufhören><de> Molotow beantwortete diese Frage etwas ausweichend mit der Erklärung, daß alles glatt gehen würde, wenn die finnische Regierung die zweideutige Haltung gegenüber der UdSSR aufgebe und wenn in der Bevölkerung die Hetze gegen Rußland (Ausgabe von Losungen, wie der vorher erwähnten) aufhöre.
<G-vec00081-001-s051><cease.aufhören><en> Molotov answered this question somewhat evasively with the statement that everything would be all right if the Finnish Government would give up its ambiguous attitude toward the U.S.S.R., and if the agitation against Russia among the population (bringing out of slogans such as the ones previously mentioned) would cease.
<G-vec00081-001-s052><cease.aufhören><de> Erneut erhebe ich die Stimme, um – im Namen Gottes – zu flehen, daß die Gewalttätigkeit des Menschen gegen den Menschen aufhöre, die Werkzeuge der Zerstörung und des Todes zum Stillstand kommen und jeder mögliche Verbindungsweg zugänglich gemacht werde, um denen, die inmitten von unbeschreibbaren Grausamkeiten zum Verlassen des eigenen Landes gezwungen sind, Hilfe zu leisten.
<G-vec00081-001-s052><cease.aufhören><en> Once again I raise my voice to beg — in the name of God — that that oppression of man by man may cease, that the tools of destruction and death be stopped and that every possible channel be opened for aiding those who have been forced to leave their lands amid unspeakable atrocities.
<G-vec00081-001-s053><cease.aufhören><de> Und wenn alle Völker, alle Religionen, alle Staaten damit aufhören zu denken, sie hätten die Kraft die Welt in Ordnung zu bringen, dann wird der Menschensohn mit Seinem Wissen auf der Erde erscheinen.
<G-vec00081-001-s053><cease.aufhören><en> So, when all nations, religions and states cease to think that they are empowered to arrange the world, then the Son of Humanity will appear on Earth with His knowledge.
<G-vec00081-001-s054><cease.aufhören><de> Das Donnern wird aufhören, und der Hagel nicht mehr sein, daß du erkennest: Dem Herrn gehört die Erde.
<G-vec00081-001-s054><cease.aufhören><en> The thunders shall cease, and there will not be any more hail; that you may know that the earth is Yahweh's.
<G-vec00081-001-s055><cease.aufhören><de> "Die endgültige Regelung im Fall Microsoft gezwungen werden aufhören ""Verdrängungspraktiken"" mit anderen Unternehmen und die Windows-Application Programming Interface bis zu andere Entwickler öffnen."
<G-vec00081-001-s055><cease.aufhören><en> The final settlement in the case forced Microsoft to cease “predatory behavior” against other companies and to open the Windows Application Programming Interface up to other developers.
<G-vec00081-001-s056><cease.aufhören><de> "In der Tat machen einige der Einschränkungen die Sache noch schlimmer: nur ""wenn Garantien dafür vorhanden sind, daß die Arbeiterregierung wirklich einen Kampf gegen das Bürgertum im oben angegebenen Sinne führen wird"" [36] – wenn aber die Sozialdemokraten und Zentristen das tun könnten (""die Arbeiter bewaffnen... den Widerstand der konterrevolutionären Bourgeoisie brechen""), dann würden sie aufhören, Reformisten zu sein."
<G-vec00081-001-s056><cease.aufhören><en> Indeed, some of the qualifications make it worse; 'only if there are guarantees that the workers' government will really struggle against the bourgeoisie in the sense mentioned' – if social democrats and centrists could do that ('arm the workers... break the resistance of the counter-revolutionary bourgeoisie'), they would cease to be reformists.
<G-vec00081-001-s057><cease.aufhören><de> Obwohl das Glas und ist recht traditionellMaterial für Lampen machen, Glasbläser nicht aufhören, uns mehr und mehr jedes Jahr zu überraschen.
<G-vec00081-001-s057><cease.aufhören><en> Although the glass is quite traditionalMaterial for the manufacture of lamps, the master glass blowers do not cease to amaze us every year more and more.
<G-vec00081-001-s058><cease.aufhören><de> Wenn Meine Leute dies von Anfang an erkennen könnten, würden Kriege aufhören zu existieren.
<G-vec00081-001-s058><cease.aufhören><en> If My people could recognize this from the onset, wars would cease to exist.
<G-vec00081-001-s059><cease.aufhören><de> Wie Sie in Ihren Begrüßungsworten erwähnten, haben sich der Glaube und die Geschichte vereint, um eine besondere Verbundenheit zwischen dem portugiesischen Volk und dem Nachfolger Petri zu schmieden, eine Verbundenheit, die der Verantwortung jeder der nachfolgenden Generationen anvertraut ist und für die wir niemals aufhören dürfen, Christus, dem Guten Hirten seiner Kirche und Herrn der Geschichte, der einzelnen Menschen und der Nationen, zu danken.
<G-vec00081-001-s059><cease.aufhören><en> As you recalled in your greeting, faith and history have united to forge a special bond between the Portuguese People and the Successor of Peter, a bond that is entrusted to the responsibility of each successive generation and for which we must never cease to thank Christ, the Good Shepherd of his Church and the Lord of history, of individual people and of nations.
<G-vec00081-001-s060><cease.aufhören><de> Seine vornehmste Pflicht vergessend, wollte er aufhören zu kämpfen, da er glaubte, glücklicher zu sein, wenn er seine Familienangehörigen und Verwandten nicht tötete, als wenn er sich des Königreiches erfreute, indem er seine Vettern und Brüder - die Söhne Dhtarāras - tötete.
<G-vec00081-001-s060><cease.aufhören><en> "Forgetting his prime duty, he wanted to cease fighting because he thought that by not killing his relatives and kinsmen he would be happier than by enjoying the kingdom by conquering his cousins and brothers, the sons of Dh""tar•£àra."
<G-vec00081-001-s061><cease.aufhören><de> "Sobald diese ""Liebe Muskeln"" gestärkt, sind Sie in der Lage, ein sich näherndes Ejakulation entweder durch Kontraktion dieser Muskeln oder einfach nur halten sie entspannt aufhören."
<G-vec00081-001-s061><cease.aufhören><en> As soon as these „love muscles“ are strengthened, you are able to cease an approaching ejaculation either by contracting these muscles or just keeping them relaxed.
<G-vec00081-001-s062><cease.aufhören><de> Aus diesem Grunde wird im Laufe der Zeit auch alle kriminelle Aktivität aufhören, und Leute mit kriminellen Veranlagungen werden von solchen Neigungen befreit werden.
<G-vec00081-001-s062><cease.aufhören><en> In the course of time all criminal activity will cease, and those with a predisposition to crime will be released from those tendencies.
<G-vec00081-001-s063><cease.aufhören><de> Hersteller davon werden jedoch nicht aufhören, ihre Waren herzustellen.
<G-vec00081-001-s063><cease.aufhören><en> However, manufacturers from this will not cease to produce their goods.
<G-vec00081-001-s064><cease.aufhören><de> Angesichts grenzenloser Barmherzigkeit, wird die Verfolgung aufhören, zu existieren.
<G-vec00081-001-s064><cease.aufhören><en> In the face of boundless compassion, the persecution will cease to exist.
<G-vec00081-001-s065><cease.aufhören><de> Die Religion ist das gleiche wie ein Glücksspiel: der Narr beginnt, aufhören zu betrügen.
<G-vec00081-001-s065><cease.aufhören><en> The religion is the same as a gambling game: the Fool begins to cease to cheat.
<G-vec00081-001-s066><cease.aufhören><de> Zwar stimmt es, dass begriffliche Gedanken und alle anderen Ebenen begrenzten Gewahrseins aufhören, indem man die Geschehnisse in unserem kognitiven Erleben einfach erkennt und der Geist unsere reine Erscheinung mitsamt den vollständigen Fähigkeiten eines Buddha entstehen lassen kann, aber nichts davon kann gelingen, wenn wir nicht in diesem und früheren Leben enorme Anstrengungen darauf verwendet haben, all die Voraussetzungen dafür im Sinne des Sutra und Tantra zu schaffen.
<G-vec00081-001-s066><cease.aufhören><en> Although it is true that just by recognizing what is happening in our cognitive experience, conceptual thoughts and all other levels of limited awareness cease and our minds give rise to our pure appearance with all the complete faculties of a Buddha, none of that can possibly happen unless we have put in a tremendous amount of effort in this and previous lives on all the sutra and tantra preliminaries.
<G-vec00081-001-s067><cease.aufhören><de> Wenn Sie derartige Konten nicht unterhalten, ist es möglich, dass bestimmte Features der Software nicht ordnungsgemäß funktionieren oder aufhören zu funktionieren.
<G-vec00081-001-s067><cease.aufhören><en> If you do not maintain such accounts, then certain features of the Software may not operate or may cease to function properly, either in whole or in part.
<G-vec00081-001-s068><cease.aufhören><de> Die Studios verfügen über einen zusätzlichen Monster iSoniTalk Kopfhörerkabel mit integriertem Telefon Antwort-Taste und Mikrofon, um mühelos aufhören den Felsen und starten die sprechen .
<G-vec00081-001-s068><cease.aufhören><en> Studios feature an additional Monster iSoniTalk headphone cable with built-in phone answer button and microphone in order to effortlessly cease the rock and start the speak.
<G-vec00081-001-s069><cease.aufhören><de> Wie ein Glück, daß Du mich ständig bewußtmachst von der Tatsache, daß nur ein Leben von Hingabe an Dich, worin ich niemals aufhören werde Dich zu loben, ehren und zu danken für alle außergewöhnliche Segnungen, die einzige und letztendliche Erfüllung ist.
<G-vec00081-001-s069><cease.aufhören><en> "What a luck that You make me continuously aware of the fact that only a life of surrender to You, in which I will never cease to praise, to honor and to thank You for all the exceptional Blessings, bestowed by You upon me, is the only and ultimate fulfillment""."
<G-vec00081-001-s070><cease.aufhören><de> Die Schattenseiten sind, dass Penny Stocks von sich aus riskant und eher als andere an Wert verlieren oder für das Unternehmen zum Handel ganz aufhören.
<G-vec00081-001-s070><cease.aufhören><en> The downsides to this are that penny stocks are inherently risky and more likely than others to lose value or for the company to cease trading altogether.
<G-vec00081-001-s071><cease.aufhören><de> "Das Gefühl der Schuld ist eine ""Nahrung"" für den Stress, deshalb ihm muss man entgehen, wenn Sie aufhören wollen, nervös zu sein."
<G-vec00081-001-s071><cease.aufhören><en> "Sense of guilt — is ""food"" for a stress therefore it is necessary to get rid of it if you want to cease to be nervous."
<G-vec00081-001-s045><discontinue.aufhören><de> Dies ermöglicht Ihnen einen Atemzug zu nehmen noch einfacher, wenn Sie schlafen, und aufhören, Ihr Schnarchen.
<G-vec00081-001-s045><discontinue.aufhören><en> This allows you to take a breath even more simple when you sleep, and discontinue your snore.
<G-vec00081-001-s046><discontinue.aufhören><de> Wenn Irritationen, Röte oder Beschwerden auftreten, mit dem Gebrauch aufhören und einen Arzt konsultieren.
<G-vec00081-001-s046><discontinue.aufhören><en> If irritation, redness or discomfort occurs, discontinue use and consult with a health care practitioner.
<G-vec00081-001-s047><discontinue.aufhören><de> Ich telegraphierte Pustet, daß ich mitten in der Arbeit aufhören müsse und kein Wort weiter für ihn schreiben werde.
<G-vec00081-001-s047><discontinue.aufhören><en> I telegraphed Pustet that I had to discontinue the work in progress and that I would write no further word for him.
<G-vec00081-001-s048><discontinue.aufhören><de> Dies ermöglicht es Ihnen, ein Hauch einfacher zu nehmen, wenn Sie sich ausruhen, und aufhören, Ihr Schnarchen.
<G-vec00081-001-s048><discontinue.aufhören><en> This allows you to take a breath more easy when you sleep, as well as discontinue your snore.
<G-vec00081-001-s049><discontinue.aufhören><de> Wenn Oxandrolone nimmt, im Gegensatz zu, wenn die meisten anderen anabolen Steroiden, einen Indikator an den Hypothalamus senden die Hoden nicht zu minimieren oder die Einführung des Gonadotropin aufhören Releasing-Hormon (GnRH) und auch das Luteinisierendes Hormon Releasing Hormonelle Mittel (LHRH).
<G-vec00081-001-s049><discontinue.aufhören><en> When taking Oxandrolone, unlike when using most other anabolic steroids, the testes write a signal to the hypothalamus to not lower or discontinue the launch of the Gonadotropin Releasing Hormone (GnRH) and the Luteinizing Hormone Releasing Hormone (LHRH).
<G-vec00081-001-s114><stop.aufhören><de> Wenn wir aufhören, an uns selbst zu denken und uns stattdessen auf das Glück eines anderen konzentrieren, erwärmt sich automatisch unser Herz.
<G-vec00081-001-s114><stop.aufhören><en> When we stop thinking about ourselves and focus instead on someone's happiness, our heart naturally warms.
<G-vec00081-001-s115><stop.aufhören><de> Du solltest damit aufhören, Anzeigen zu Zeiten und an Standorten zu schalten, die, aus welchen Gründen auch immer, keine guten Conversion-Rates erzielen.
<G-vec00081-001-s115><stop.aufhören><en> It also works the other way around, in the sense that you can stop running ads during times and in locations where your conversions, for whatever reason, nosedive.
<G-vec00081-001-s116><stop.aufhören><de> Somit musste ich aufhören zu arbeiten und die meiste Zeit ruhen, um den Blut- und Flüssigkeitsverlust auf ein Minimum zu reduzieren.
<G-vec00081-001-s116><stop.aufhören><en> I had to stop working and rest most of the time to keep the loss of blood and fluid to a minimum.
<G-vec00081-001-s117><stop.aufhören><de> Es handelt sich einfach nur um einen schlecht getarnten protektionistischen Schritt seitens des US-Imperialismus und bedeutet, dass die USA darauf bestehen, dass China aufhören muss, den Weltmarkt mit billigen Waren zu überfluten, welche die US-amerikanischen Kapitalisten vom Markt drängen.
<G-vec00081-001-s117><stop.aufhören><en> It is in fact merely a very flimsily veiled protectionist step on the part of US imperialism. It means that the US is insisting that China must stop flooding the world market with cheap goods that put American capitalists out of business.
<G-vec00081-001-s118><stop.aufhören><de> Myriam bezeichnet sich selbst als logophil, und kann nicht aufhören, mit Worten zu experimentieren.
<G-vec00081-001-s118><stop.aufhören><en> Myriam calls herself a logophile and cannot stop experimenting with words.
<G-vec00081-001-s119><stop.aufhören><de> Eigentlich lohnt es nicht Adware-Programme installiert, denn sie nicht aufhören werden, kommerzielle Werbung anzeigen und Sie sehr schnell auf Bedrohungen ausgesetzt sein können.
<G-vec00081-001-s119><stop.aufhören><en> Actually, it is not worth keeping adware programs installed because they will not stop showing commercial advertisements and you might be exposed to threats very quickly.
<G-vec00081-001-s120><stop.aufhören><de> Fragen Sie Ihre Ärztin oder Ihren Arzt, wie Sie Rauchen oder Trinken aufhören könne.
<G-vec00081-001-s120><stop.aufhören><en> Ask your doctor or health care professional for help to stop smoking or drinking.
<G-vec00081-001-s121><stop.aufhören><de> Diese Freifahrt für große Konzerne muss jetzt aufhören.
<G-vec00081-001-s121><stop.aufhören><en> This free ride for big corporations must now stop.
<G-vec00081-001-s122><stop.aufhören><de> Wenn die Menschen aber aufhören, der Polizei zu vertrauen, werden sie weitaus seltener mit den Sicherheitsdiensten zusammenarbeiten, zum Beispiel indem sie verdächtiges Verhalten melden oder als Zeuge auftreten.
<G-vec00081-001-s122><stop.aufhören><en> And once people stop trusting the police, they become far less likely to cooperate with security services, for example by reporting suspicious behaviour or coming forward as a witness.
<G-vec00081-001-s123><stop.aufhören><de> ·Dass die Regel Sktha Regimen und Regierungen und ägyptischen Herrscher seit 1974, das Verbot von Wissen, Informationen und Fakten, Meinungen und Position auf dem ägyptischen Volk in jeder Hinsicht auf die ägyptisch-israelischen Beziehungen, sowie der Geist der Sakramente von der Behörde, monopolisiert, sind korrupt und gefährlich Basis und muss aufhören.
<G-vec00081-001-s123><stop.aufhören><en> ·That the rule Sktha regimes and governments and Egyptian rulers since 1974, the prohibition of knowledge, information and facts, opinion and position on the Egyptian people in all regards to the Egyptian-Israeli relations, and the mind of the sacraments monopolized by the authority, are corrupt and dangerous base and must stop.
<G-vec00081-001-s124><stop.aufhören><de> Aufhören den Widerstand in Palästina, im Libanon und in Irak zu unterstützen.
<G-vec00081-001-s124><stop.aufhören><en> stop supporting the resistance in Palestine, Lebanon, and Iraq.
<G-vec00081-001-s125><stop.aufhören><de> Sie fangen an, sich zu küssen, doch müssen aufhören, als ein Auto in der Nähe parkt.
<G-vec00081-001-s125><stop.aufhören><en> They start to kiss but a car parks nearby and they must stop.
<G-vec00081-001-s126><stop.aufhören><de> Wenn solche schmerzhaften Empfindungen nicht innerhalb eines Tages aufhören, dann ist es notwendig, sofort einen Arzt zu konsultieren.
<G-vec00081-001-s126><stop.aufhören><en> If such painful sensations do not stop within a day, then it is necessary to immediately consult a doctor.
<G-vec00081-001-s127><stop.aufhören><de> Zwischen den Bandsets und während der After Hours Partys sorgen unsere DJs dafür, dass die gute Musik und der Spaß nicht aufhören.
<G-vec00081-001-s127><stop.aufhören><en> Between the band sets and during the After Hour Parties our DJs will asure that the great music and fun won’t stop.
<G-vec00081-001-s128><stop.aufhören><de> Die Musik darf nie aufhören: Während Blackened American Whiskey by Metallica bei der Reifung mit dem zuvor erwähnten Song beschallt wurde, wird beim letztendlichen Verkosten dazu ermutigt, ebenfalls ganz bestimmte Metallica-Songs zu hören.
<G-vec00081-001-s128><stop.aufhören><en> Please don't stop the music: While Blackened American Whiskey by Metallica was sonicated with the aforementioned song as it matured, the final tasting encourages you to listen to certain Metallica songs as well.
<G-vec00081-001-s129><stop.aufhören><de> Es ist kein abnormaler Zustand, und Sie sollte nicht aufhören.
<G-vec00081-001-s129><stop.aufhören><en> It is not an abnormal state, and you shouldn't stop.
<G-vec00081-001-s130><stop.aufhören><de> Solche Gräuel müssen aufhören.
<G-vec00081-001-s130><stop.aufhören><en> Such atrocities must stop.
<G-vec00081-001-s131><stop.aufhören><de> Es gibt ein altes Sprichwort sagt, wenn ein Graben Sie in Loch dann aufhören sollte.
<G-vec00081-001-s131><stop.aufhören><en> There is an old saying that says if you're in a hole then you should stop digging.
<G-vec00081-001-s132><stop.aufhören><de> Die Katzen haben eine interessante Besonderheit: nach der Geburt einiger Kätzchen kann die Geburt für die Zeit aufhören, und dann, wieder anfangen.
<G-vec00081-001-s132><stop.aufhören><en> Cats have an interesting feature: after the birth of several kittens childbirth can stop for a while, and then again begin.
<G-vec00081-001-s072><cease.aufhören><de> Das zweite von eurer Kongregation im Dezember 2007 veröffentlichte Dokument »Lehrmäßige Note zu einigen Aspekten der Evangelisierung« bekräftigt angesichts der Gefahr eines anhaltenden religiösen und kulturellen Relativismus, daß sich in der Zeit des Dialogs zwischen den Religionen und Kulturen der Welt die Kirche der Notwendigkeit der Evangelisierung und Missionstätigkeit bei den Völkern nicht entziehen und nicht aufhören darf, die Menschen zu bitten, das allen Völkern angebotene Heil anzunehmen.
<G-vec00081-001-s072><cease.aufhören><en> The Doctrinal Note on Some Aspects of Evangelization - the other Document, published by your Congregation in December 2007 -, confronted by the risk of persistent religious and cultural relativism, reaffirms that in the age of interreligious and intercultural dialogue the Church does not dispense with the need for evangelization and missionary activity for peoples, nor does she cease to ask men and women to accept the salvation offered to them all.
<G-vec00081-001-s073><cease.aufhören><de> Wenn es Ihre Hilfe nicht gäbe, dann würde der Himmel aufhören rein zu sein, die Erde würde über-all brechen, die Natur würde aufhören allen Leben- den ihre Schönheit zu geben; die Täler würden auf- hören zu blühen und sich in Wüste verwandeln; die lebenden Wesen würden aufhören sich zu vermeh- ren und sie würden verschwinden; die Helden des spirituellen Pfades wären kein Muster an Tugend- haftigkeit und würden lächerlich gemacht und ver- bannt werden.
<G-vec00081-001-s073><cease.aufhören><en> If They did not help, then the sky would cease to be pure and the earth would crack all over, nature would cease giving its beauty to all the living, val- leys would stop blooming and turn into deserts, all living beings would stop multiplying and disap- pear, and the heroes of the spiritual Path would not be paragons of virtue and would be ridiculed and banished...
<G-vec00081-001-s074><cease.aufhören><de> 3:17 Daselbst müssen doch aufhören die Gottlosen mit Toben; daselbst ruhen doch, die viel Mühe gehabt haben.
<G-vec00081-001-s074><cease.aufhören><en> 3:17 There the wicked cease from troubling; and there the weary be at rest.
<G-vec00081-001-s075><cease.aufhören><de> Wenn Sie aufhören, über die Dinge zu staunen, die ungewöhnlich sind in Ihrer Alltagswelt, wenn Sie den Willen verlieren, neue Wörter zu schmecken und sie ohne Scheu zu imitieren, wenn Sie sich den Nervenkitzel vorenthalten, der beim Erwerb neuer Fähigkeiten, wie klein sie auch sein mögen, zu spüren ist, dann verpassen sie den großen Reichtum dieses Hauses.
<G-vec00081-001-s075><cease.aufhören><en> When you cease to wonder about what's strange in your day-to-day world, when you lose your willingness to taste new words and imitate without self-consciousness, when you forego the thrill of acquiring new masteries, however small, you will lose the vast richness of this house.
<G-vec00081-001-s133><stop.aufhören><de> In dem Moment, wenn Sie am Ende Formatierung Festplatte, sofort aufhören zu speichern neue Daten über sie und nutzen alle professionellen wiederherstellung JPEG dateien von formatierter festplatte app, um das vollständige Abrufen von JPEG-Dateien sicherzustellen.
<G-vec00081-001-s133><stop.aufhören><en> The moment you end up formatting hard drive, instantly stop saving new data over it and utilize any professional photo recovery app to ensure complete retrieval of JPEG files. Formatted hard drive recovery software!
<G-vec00081-001-s134><stop.aufhören><de> Adressiert Problem, bei dem die Universal-CRT verursacht den linker – (link.exe), um aufhören zu arbeiten, für große Projekte.
<G-vec00081-001-s134><stop.aufhören><en> Addressed issue where the Universal CRT caused the linker (link.exe) to stop working for large projects.
<G-vec00081-001-s135><stop.aufhören><de> Denn eine Ansprache vorzulesen ist auch ein wenig langweilig… Und wenn jemand eine Ansprache vorliest, dann gibt es einen Moment, wo man mit einer gewissen Verstohlenheit beginnt, auf die Uhr zu schauen, wie um zu sagen: »Aber wann wird er aufhören zu sprechen?« Daher werdet ihr die Ansprache selbst lesen.
<G-vec00081-001-s135><stop.aufhören><en> Because reading a speech is also a little boring.... There is a moment, when one reads a speech, in which, with a certain shrewdness, one starts looking at the clock, as if to say: “When will this man stop talking?”. Therefore, you will read the speech to yourself.
<G-vec00081-001-s136><stop.aufhören><de> Zweitens jemand oft doesn 't aufhören zu essen, bis das Ende der Show, und zwar unabhängig davon, ob sie ' re voll ist oder nicht.
<G-vec00081-001-s136><stop.aufhören><en> Secondly, someone often does not stop there until the end of the show, regardless of whether they are fully or not.
<G-vec00081-001-s137><stop.aufhören><de> Besser aufhören zu schauen und zuzuhören.
<G-vec00081-001-s137><stop.aufhören><en> Better Stop Look And Listen
<G-vec00081-001-s138><stop.aufhören><de> Sitzungscookies verbleiben nur bis zu dem Moment auf Ihrem Gerät, an dem Sie aufhören zu surfen.
<G-vec00081-001-s138><stop.aufhören><en> Session cookies will only remain on your computer or mobile device until you stop browsing.
<G-vec00081-001-s139><stop.aufhören><de> Wenn Anstrengung und Belohnung nicht zuverlässig korrelieren, werden die meisten Menschen das Vertrauen verlieren und aufhören, Mühe zu investieren.
<G-vec00081-001-s139><stop.aufhören><en> When effort and reward do not correlate reliably, most people will lose faith and stop investing effort.
<G-vec00081-001-s140><stop.aufhören><de> Es wäre besser, wenn Sie hohe Absätze während der Schwangerschaft aufhören zu tragen.
<G-vec00081-001-s140><stop.aufhören><en> It would be better if you stop wearing high heels during pregnancy.
<G-vec00081-001-s141><stop.aufhören><de> Verzweifeln Sie nicht und nicht aufhören zu kämpfen.
<G-vec00081-001-s141><stop.aufhören><en> Do not despair and do not stop fighting.
<G-vec00081-001-s142><stop.aufhören><de> Ich kenne einige Menschen, die nicht aufhören, über andere schlecht zu reden.
<G-vec00081-001-s142><stop.aufhören><en> I know people who don’t stop speaking badly about others.
<G-vec00081-001-s143><stop.aufhören><de> Wie Sie aufhören zu arbeiten, Ihre Muskeln zu wachsen beginnen.
<G-vec00081-001-s143><stop.aufhören><en> As you stop working out, your muscles start to grow.
<G-vec00081-001-s144><stop.aufhören><de> "Bitte beachten Sie, dass Ihr Skimmer kann aufhören zu arbeiten für zwischen 2 und 7 Tagen (abhängig vom Skimmer), während die Marine Bio Perlen / Pellets ""eingefahren""."
<G-vec00081-001-s144><stop.aufhören><en> "Please note that your skimmer may stop working for between 2 and 7 days (depending on the skimmer) while the Marine Bio Pearls / Pellets ""run in""."
<G-vec00081-001-s145><stop.aufhören><de> Das Tribunal sagte, ein Anwalt müsse aufhören zu handeln oder sich aus dem Erbe entfernen, wo ein Interessenkonflikt bestand, wie es in diesen Fällen der Fall war.
<G-vec00081-001-s145><stop.aufhören><en> The tribunal said a solicitor must stop acting or remove himself from the legacy where there was a conflict of interest, as there was in these cases.
<G-vec00081-001-s146><stop.aufhören><de> Mit der Steroid entsprechend, mit den entsprechenden Dosierungen, erlaubt Training und Diät-Plan sicherlich Bodybuilder aus, Gewicht halten, selbst nachdem sie aufhören zu arbeiten seit einiger Zeit.
<G-vec00081-001-s146><stop.aufhören><en> Using the steroid effectively, with the right doses, training and diet will enable body builders to keep weight off, also after they stop working out for some time.
<G-vec00081-001-s147><stop.aufhören><de> Sie müssen sofort aufhören, Outlook zu benutzen und die herunterzuladen PST Reparatur Tool Um Kalendereinträge aus der beschädigten PST-Datei wiederherzustellen.
<G-vec00081-001-s147><stop.aufhören><en> You must immediately stop using Outlook and download the Outlook Repair Tool to recover Calendar items from the corrupted PST file.
<G-vec00081-001-s148><stop.aufhören><de> Sie liebt es so sehr, dass sie nicht aufhören zu tanzen.
<G-vec00081-001-s148><stop.aufhören><en> She loves it so much that she can't stop dancing.
<G-vec00081-001-s149><stop.aufhören><de> kurzes Drücken des Hauptmenüs im Standby Schnittstelle zu gelangen, drücken Sie, um in das Hauptmenü zu bestätigen.Im Menü kurz drücken, um die bei der Funktion zu wählen.Und während es einen eingehenden Anruf, drücken Sie diese Taste ist es, aufhören zu zittern.
<G-vec00081-001-s149><stop.aufhören><en> short press to enter the main menu in the standby interface, press to confirm in the main menu. In the menu, short press to select the upon function. And while there have a incoming call, press this key is to stop shaking.
<G-vec00081-001-s150><stop.aufhören><de> Eines der Kinder wurde vor strahlend, und jetzt weiß ich nicht aufhören zu weinen für seine Eltern, den ganzen Tag.
<G-vec00081-001-s150><stop.aufhören><en> One of the children was beaming before, and now I do not stop crying for his parents, all day long.
<G-vec00081-001-s151><stop.aufhören><de> Es muss darauf hingewiesen werden, dass Mozilla vielleicht stecken Sie in dieses Loch zu jeder Zeit, und dass die Skripte können aufhören zu arbeiten, denn, schließlich.
<G-vec00081-001-s151><stop.aufhören><en> It needs to be noted that Mozilla may plug this hole at any time, and that scripts may stop working because of that eventually.
<G-vec00081-001-s076><cease.aufhören><de> Wir erkannten, dass die Lehre des Marxismus niemals aufhört, sich kritisch weiter zu entwickeln, dass der Marxismus weder bei Lenin und Stalin, noch bei Enver Hoxha einen absoluten Endpunkt erreicht hat.
<G-vec00081-001-s076><cease.aufhören><en> We realized that the teachings of Marxism never cease to further develop self-critically, that Marxism has reached an absolute end neither by Lenin and Stalin, nor by Enver Hoxha.
<G-vec00081-001-s077><cease.aufhören><de> Sie erklärt eine Wahrheit, welche verkündigt werden muss, ehe des Heilandes Vermittlung aufhört und er zur Erde zurückkehrt, um sein Volk zu sich zu nehmen.
<G-vec00081-001-s077><cease.aufhören><en> It heralds a truth which must be proclaimed until the Saviour's intercession shall cease and He shall return to the earth to take His people to Himself.
<G-vec00081-001-s078><cease.aufhören><de> Ob in Literatur, Comic, TV, Theater oder Performance, kann ich mit der Serie die Erfahrung einer Zeit machen, die tatsächlich nichts tut als weiterzugehen und irgendwann aufhört.
<G-vec00081-001-s078><cease.aufhören><en> Whether in literature, comics, TV, theatre or performance, with the series I can experience a time that actually does nothing else but continue on and then cease.
<G-vec00081-001-s079><cease.aufhören><de> Euch bleibt keine lange Zeit mehr.... Immer wieder muss Ich euch das sagen, denn ihr nehmt Meine Worte nicht ernst, ihr steht mitten in der Welt und könnet es nicht glauben, daß alles, was um euch ist, einmal aufhört zu sein und daß nur das bleibt, was unvergänglich ist.... eure Seele.
<G-vec00081-001-s079><cease.aufhören><en> You don't have much time left.... Time and again I have to say this to you for you don't take My Words seriously, you are living in the midst of the world and cannot believe that everything around you will cease to exist one day and that only that will remain which is everlasting.... your soul.
<G-vec00081-001-s080><cease.aufhören><de> Sie können Tropical Paradise jederzeit informieren, wenn Sie möchten, dass Tropical Paradise aufhört, Ihre personenbezogenen Daten zu verwenden.
<G-vec00081-001-s080><cease.aufhören><en> You may inform Tropical Paradise at any time if you wish Tropical Paradise to cease using your personal information.
<G-vec00081-001-s081><cease.aufhören><de> Diese Bestätigung kann gesucht werden, unter anderem, um seine Angst zu bestehen aufhört, oder der Schmerz, der Tod geliebter Menschen bestimmt hat, beruhigen zu zerstreuen.
<G-vec00081-001-s081><cease.aufhören><en> Such confirmation can be sought, inter alia, to dispel their fear to cease to exist, or to alleviate the pain that people love death resulted.
<G-vec00081-001-s082><cease.aufhören><de> """Wir sind Jüdinnen, und wir wollen, daß Israel aufhört, gegen die Palästinenser Krieg zu führen."
<G-vec00081-001-s082><cease.aufhören><en> """We are Jews and we want Israel to cease war against the Palestinians."
<G-vec00081-001-s083><cease.aufhören><de> Wenn Männer dieses erlernen, pflanzt es Vergesslichkeit in ihren Seelen, sie aufhört, Gedächtnis auszuüben ein, weil sie auf den bauen, der geschrieben wird und nicht mehr Sachen zur Erinnerung von innerhalb selbst, aber mittels der externen Markierungen benennen.
<G-vec00081-001-s083><cease.aufhören><en> If men learn this, it will implant forgetfulness in their souls, they will cease to exercise memory because they rely on that which is written, calling things to remembrance no longer from within themselves, but by means of external marks.
<G-vec00081-001-s084><cease.aufhören><de> Selbst wenn sie möglicherweise aufhört, Verfahrensbeteiligte zu sein, wenn entschieden wird, dass sie zur Teilnahme am Verfahren nicht berechtigt ist, bedeutet dies nicht, dass sie nie eine Verfahrensbeteiligte war.
<G-vec00081-001-s084><cease.aufhören><en> Although he may cease to be a party if he is held not entitled to take part in the proceedings, this does not mean he was never a party.
<G-vec00081-001-s085><cease.aufhören><de> Jedesmal zum Beispiel, wenn eine Krankheit geheilt wird, jedesmal, wenn ein Unfall verhindert wird, jedesmal, wenn eine Katastrophe, sogar eine globale, verhindert wird, ist es immer das Eingreifen der Schwingung der Harmonie in die Schwingung der Unordnung, was dazu führt, daß die Unordnung aufhört.
<G-vec00081-001-s085><cease.aufhören><en> For example every time an illness is cured, every time an accident is avoided, every time a catastrophe, even a global one, is avoided, all that is always the intervention of the Vibration of Harmony into the vibration of Disorder, allowing Disorder to cease.
<G-vec00081-001-s086><cease.aufhören><de> Offenbarung 4:1-11 Der Apostel Petrus hat uns gesagt, dass das Universum vernichtet wird und aufhört, zu existieren.
<G-vec00081-001-s086><cease.aufhören><en> Revelation 4:1-11 The apostle Peter told us how the universe is going to be destroyed and cease to exist.
<G-vec00081-001-s087><cease.aufhören><de> Die Hauptsache ist, dass das Engagement war wie auf dem Bild, dann gibt es eine Chance, dass zu schlagen aufhört.
<G-vec00081-001-s087><cease.aufhören><en> The main thing that the engagement was as on the picture, then there is a chance that cease to beat.
<G-vec00081-001-s088><cease.aufhören><de> Wenn ihr mit der Selbstverurteilung aufhört, hört ihr ebenso damit auf diesen anderen, inneren Pol der Eitelkeit auszudrücken.
<G-vec00081-001-s088><cease.aufhören><en> When you cease self-judgment you also cease to express the other, inner pole of vanity.
<G-vec00081-001-s089><cease.aufhören><de> Lokalität betont, dass – auch in Zeiten der Globalisierung von Medienkommunikation – die lokale Welt nicht aufhört zu existieren.
<G-vec00081-001-s089><cease.aufhören><en> Locality emphasizes that—also in the time of media globalization—the local world does not cease to exist.
<G-vec00081-001-s090><cease.aufhören><de> Es ist wichtig, dass diese Sphäre aufhört ein Land von Nebel und Düsternis zu sein.
<G-vec00081-001-s090><cease.aufhören><en> It is important that this sphere should cease to be a land of mist and gloom.
<G-vec00081-001-s091><cease.aufhören><de> Die Jungfrau Maria, die das hohe Vorrecht hatte, dem Vater seinen eingeborenen Sohn Jesus Christus als reine und heilige Opfergabe darzubringen, möge dafür sorgen, daß wir immer offen und aufnahmebereit für die großen Werke sind, die Er nicht aufhört, zum Wohl seiner Kirche und der ganzen Menschheit zu vollbringen.
<G-vec00081-001-s091><cease.aufhören><en> May the Virgin Mary, who had the sublime privilege of presenting to the Father his only begotten Son, Jesus Christ, as a pure and holy oblation, obtain for us that we may constantly be open and welcoming in face of the great works which He does not cease to accomplish for the good of the Church and of all of humanity.
<G-vec00081-001-s092><cease.aufhören><de> Euer Erdendasein als Mensch ist eine der unendlich vielen Phasen eurer Aufwärtsentwicklung, denn auch, wenn ihr auf Erden ausgereift seid, um nun in das Lichtreich eingehen zu können, schreitet doch eure Entwicklung immer noch weiter, weil niemals die Seele, die erkannt hat, aufhört zu streben.... weil sie immer und ewig Gott anstreben wird und weil sie daher Ihm immer näherzukommen trachtet, um in gänzlicher Vereinigung mit Ihm unaussprechlich selig zu sein.
<G-vec00081-001-s092><cease.aufhören><en> Your earthly existence as a human being is one of infinitely many phases of your higher development, for even if you fully mature on earth so that you can enter the kingdom of light your development will nevertheless continue, because once a soul has attained realisation it will never cease going forward.... because it will always and forever strive towards God and thereby try to come closer to Him in order to become blissfully happy in complete union with Him. Consequently, the time on earth as a human being is just like a brief moment compared to eternity, compared to the infinitely long process of development through the material creation, and yet, this brief moment is crucial for the soul’s fate, it is crucial for the further process of development in the spiritual kingdom.
<G-vec00081-001-s093><cease.aufhören><de> Wie ihr informiert worden seid, wurde weder von Michael noch von mir gefordert zu verursachen, dass irgendeines unserer Kinder aufhört zu existieren, obwohl alles, was sie waren und machten, alles, was sie direkt verursacht haben, immer ein Teil des Supremen Wesens sein wird, der universalen Geschichte von Zeit- und Raumgeschehen – Gottes Seele, wenn ihr so wollt.
<G-vec00081-001-s093><cease.aufhören><en> As you’ve been informed, neither Michael nor I were required to cause any of our own children to cease to exist, although everything they were and did, everything they directly caused, will always be a part of the Supreme Being, the universal history of time and space events--God’s soul, if you will.
<G-vec00081-001-s094><cease.aufhören><de> Dieser Ort ist ein provisorischer Wartesaal, der aufhört zu bestehen, sobald er seinen Zweck erfüllt hat (weitere Einzelheiten in Kapitel 6).
<G-vec00081-001-s094><cease.aufhören><en> This place is a temporary waiting room that will cease to exist once it has served its purpose. (More details are provided in Chapter 6.)
<G-vec00081-001-s152><stop.aufhören><de> Wenn man sich dazu entschließt das Kochen zur Profession zu machen, dann sollte man immer neugierig bleiben, süchtig nach Essen sein, bescheiden und vor allem aufmerksam, dass man niemals aufhört dazuzulernen.
<G-vec00081-001-s152><stop.aufhören><en> When you decide to do cooking for a living you have to stay curious, be addicted, be humble and be aware that you will never stop learning.
<G-vec00081-001-s153><stop.aufhören><de> Wenn wir älter sind und aus dem Leben gehen, wurde mir gezeigt dass ein neues Leben weiter geht, und weiter zu lernen nicht aufhört.
<G-vec00081-001-s153><stop.aufhören><en> When we are older and pass from this life, I was shown that a new life to go on learning doesn't stop.
<G-vec00081-001-s154><stop.aufhören><de> "(Schweigen) Für die Zellen des Körpers bedeutet das einen schwierigen Übergang von der Ruhe, die ""tamasischen"" Ursprungs ist (einer Ruhe, die in ferner Vergangenheit das Produkt der Trägheit war, ein Überbleibsel dieser Tendenz zur Trägheit), zu einem Stadium, wo diese Ruhe aufhört, träge zu sein, und der Ruhe der Allmacht angehört."
<G-vec00081-001-s154><stop.aufhören><en> "And for the cells of the body, the transition from the tranquillity of ""tamasic"" origin (the calm that was, in the distant past, the outcome of Inertia, and what still remains of that tendency for inertia), for this calm to stop being inert and, on the contrary, to belong to the calm of All-Powerfulness, there is a difficult transition."
<G-vec00081-001-s155><stop.aufhören><de> Die gefährlichste Art von Allergien ist die Schwellung, da sie die Atemwege beeinträchtigen kann und es schwierig macht, dass der Atmungsprozess vollständig aufhört.
<G-vec00081-001-s155><stop.aufhören><en> The most dangerous of these types of allergies is edema, as it can affect the respiratory tract, making it difficult for the breathing process to stop completely.
<G-vec00081-001-s156><stop.aufhören><de> Ich wollte nicht dass es aufhört.
<G-vec00081-001-s156><stop.aufhören><en> I did not want it to stop.
<G-vec00081-001-s157><stop.aufhören><de> Im Laufe der Zeit kann es sein, dass das Kind auf der Straße mit Menschen, im Kindergarten oder in der Schule aufhört, aus Angst, dass andere Kinder ihn ärgern.
<G-vec00081-001-s157><stop.aufhören><en> Over time, the child may stop doing it on the street with people, in kindergarten, school, for fear that other children will tease him.
<G-vec00081-001-s158><stop.aufhören><de> Darum lasst uns beten, dass das Töten aufgrund von Familienfehden und Rache endlich aufhört und dass man lernt, dass Vergebung der ehrenwerteste Weg ist, um Konflikte zu lösen.
<G-vec00081-001-s158><stop.aufhören><en> Ask that those who kill because of family feuds and revenge, will stop. Ask that they will learn that forgiveness is the most honorable way to solve conflicts.
<G-vec00081-001-s159><stop.aufhören><de> Im Inneren des Webs finden Sie den allseits beliebten Spheroid von Hammer, einen symmetrischen Kern, der starke Midlane startet und nicht aufhört, bis er die Nadeln verheddert hinterlässt.
<G-vec00081-001-s159><stop.aufhören><en> Inside the Web, you will find the ever-popular Spheroid from Hammer, a symmetric core that starts strong midlane and will not stop until it leaves the pins tangled.
<G-vec00081-001-s160><stop.aufhören><de> Wie wir gesagt haben und White Cloud zugestimmt hat... wird es auch so sein,... dass manche Seelen ihre Körperlichkeit verlassen... ihre menschliche Gestalt... in dieser Zeit,... da die Offenbarung dazu führen wird, dass ihr Herz zu schlagen aufhört... und andere... buchstäblich zu atmen vergessen.
<G-vec00081-001-s160><stop.aufhören><en> As we have said and White Cloud has concurred... that it shall be too... that some souls shall leave their physicality... their human form... in that time... for the revelation shall cause their heart to stop beating... and some.... shall literally forget to breath .
<G-vec00081-001-s161><stop.aufhören><de> Föderation des Lichts: Alles ist möglich... das LEBEN ist so konzipiert, dass es niemals aufhört.
<G-vec00081-001-s161><stop.aufhören><en> Everything is possible... LIFE is designed never to stop.
<G-vec00081-001-s162><stop.aufhören><de> Es gibt viele verschiedene Möglichkeiten, warum das Mittelohr aufhört, richtig zu funktionieren.
<G-vec00081-001-s162><stop.aufhören><en> There are many different ways that the middle ear can stop working properly.
<G-vec00081-001-s163><stop.aufhören><de> Wer aufhört, besser zu werden, wird schnell überholt.
<G-vec00081-001-s163><stop.aufhören><en> Those who stop improving are soon overtaken.
<G-vec00081-001-s164><stop.aufhören><de> Der Pater steht am Rednerpult und wartet, bis die Jugend ihn sprechen lässt, wenn sie aufhört, ihm zuzujubeln.
<G-vec00081-001-s164><stop.aufhören><en> The Father stands at the rostrum and is waiting, until the young men let speak him, when they stop to cheer him.
<G-vec00081-001-s165><stop.aufhören><de> Man sollte vielleicht wissen, dass die Kaffeemaschine plötzlich aufhört zu funktionieren, um nur wenige Minuten später wieder anzuspringen.
<G-vec00081-001-s165><stop.aufhören><en> One thing you should know, the coffee maker tends to stop brewing, then starts up again minutes later.
<G-vec00081-001-s166><stop.aufhören><de> """Innerhalb der Fraktion haben wir unsere Arbeitsweise bereits geändert, um sicherzustellen, dass das Silodenken aufhört."
<G-vec00081-001-s166><stop.aufhören><en> """In the Group we already changed the way we work internally to make sure that we stop thinking in silos."
<G-vec00081-001-s167><stop.aufhören><de> Die Wahrscheinlichkeit ist gross, das die betreffende Person dann aufhört ihn streicheln zu wollen.
<G-vec00081-001-s167><stop.aufhören><en> The chances are that this person will then stop approaching.
<G-vec00081-001-s168><stop.aufhören><de> Alles, was einen veredelnden Einfluß auf die Seele hat, wird weder pflichtgemäß gefordert noch ausgeführt werden, sondern immer in vollster Willensfreiheit getan werden müssen, und darum kann erst dann von einem Fortschritt der Seele gesprochen werden, so sich der Mensch über seine Pflicht hinaus tätig erweist und in solcher Liebetätigkeit nicht aufhört.
<G-vec00081-001-s168><stop.aufhören><en> Anything that has a refining influence on the soul will neither be demanded nor carried out as a duty but it always has to be done in absolute freedom of will, and this is why a soul’s progress can only be spoken of when the person works above and beyond his duty and will not stop such kind-hearted activity.
<G-vec00081-001-s169><stop.aufhören><de> Wir schauen in diesem Modul alles an, was deine kleine innere Stimme dir täglich sagt und machen energetische Arbeit, damit es aufhört.
<G-vec00081-001-s169><stop.aufhören><en> In this module we look at everything your little inner voice tells you every day and do energetic work to make it stop.
<G-vec00081-001-s170><stop.aufhören><de> Das Betätigen des Auslösers verursacht etwas geringe Vibration der Kamera, jedoch ein paar wenige Sekunden Verzögerung sind genug, bis die Vibration aufhört.
<G-vec00081-001-s170><stop.aufhören><en> Pressing the shutter causes some minor vibrations to the camera, but few seconds of delay is enough for them to stop.
<G-vec00081-001-s095><cease.aufhören><de> Um aufzuhören, nervös zu sein, muss man auch in sich die Abhängigkeit von der Meinung anderer Menschen ausrotten.
<G-vec00081-001-s095><cease.aufhören><en> To cease to be nervous, it is also necessary to eradicate in itself dependence on opinion of other people.
<G-vec00081-001-s096><cease.aufhören><de> Das Universum ist nicht aufgezogen wie eine Uhr, um eine Zeit lang zu laufen und dann aufzuhören zu funktionieren; alle Dinge werden ständig erneuert.
<G-vec00081-001-s096><cease.aufhören><en> The universe is not wound up like a clock to run just so long and then cease to function; all things are constantly being renewed.
<G-vec00081-001-s097><cease.aufhören><de> Die beste Vorgehensweise ist alle, Hautprodukte zu verwenden aufzuhören, bis die Reaktion verbessert, die normalerweise eine ungefähr Woche nimmt.
<G-vec00081-001-s097><cease.aufhören><en> The best course of action is to cease using all skin products until the reaction improves, which usually takes about a week.
<G-vec00081-001-s098><cease.aufhören><de> Sie ersuchten das Außenministerium, sich an die chinesische Regierung zu wenden, damit diese aufhöre, ihre Mitbürger zu verfolgen, Charles Lee sofort freizulassen und aufzuhören, die Menschenrechte von Falun Gong-Praktizierenden zu verletzen.
<G-vec00081-001-s098><cease.aufhören><en> They appealed to the State Department for the Chinese government to stop persecuting their fellow citizens, immediately release Charles Lee and cease violating Falun Gong practitioners' human rights.
<G-vec00081-001-s099><cease.aufhören><de> Oft ist die Versuchung groß, den Mut zu verlieren und aufzuhören, an ein gemeinsames Ideal im gesamten Orden zu glauben.
<G-vec00081-001-s099><cease.aufhören><en> Often the temptation is great to lose courage, to cease to believe in a common ideal of the whole Order.
<G-vec00081-001-s100><cease.aufhören><de> Aufzuhören, sich selbst mit dem Körper zu identifizieren und sich selbst von dem Körperbewusstsein zu trennen, ist ein anerkannter und notwendiger Schritt hin zu spiritueller Befreiung sowie hin zu spiritueller Vollendung und Herrschaft über die Natur.
<G-vec00081-001-s100><cease.aufhören><en> o cease to be identified with the body, to separate oneself from the body-consciousness, is a recognized and necessary step whether toward spiritual liberation or toward spiritual perfection and mastery over Nature....
<G-vec00081-001-s101><cease.aufhören><de> Darum habt ihr noch nicht das Einssein eurer Persönlichkeit und ihrer Erfahrung und ihres Potenzials, um diese Art von Entscheidung zu treffen: zu wählen, aufzuhören zu existieren.
<G-vec00081-001-s101><cease.aufhören><en> So you do not as yet have the oneness of your personality and its experience and potential to make that kind of decision: to choose to cease to exist.
<G-vec00081-001-s102><cease.aufhören><de> Wenn ihr also wählt, aufzuhören zu existieren, dann wird dieser Teil des Gedankenjustierers – diese Story eurer Leben für immer in Gottes Besitz bleiben.
<G-vec00081-001-s102><cease.aufhören><en> If you so choose to cease to exist, then this part of the Thought Adjuster--this story of your life will remain forever in God’s possession.
<G-vec00081-001-s103><cease.aufhören><de> Wie aufzuhören sich zu quälen und, auf sdor überzugehen...
<G-vec00081-001-s103><cease.aufhören><en> How to cease to suffer and pass to a zdor...
<G-vec00081-001-s104><cease.aufhören><de> Nachdem Mohammed ablehnt, Feindschaften aufzuhören, zerstört travel Flotte von den vermittelnden Kräften (Frankreich, Britannien und Russland) travel TurkishEgyptian Flotte.
<G-vec00081-001-s104><cease.aufhören><en> After Mohammed refuses to cease hostilities, the fleet of the mediating powers (France, Britain and Russia) destroys the TurkishEgyptian fleet.
<G-vec00081-001-s105><cease.aufhören><de> In Scientology jedoch wurden brauchbare Lösungen entwickelt, die eine Person befähigen, nicht nur mit dem Drogenkonsum aufzuhören, sondern auch die grundlegenden Ursachen, die sie diesen finsteren Weg einschlagen ließen, zu finden und zu eliminieren.
<G-vec00081-001-s105><cease.aufhören><en> However, workable solutions have been developed in Scientology which enable a person not only to cease drug use, but to reach and eradicate the root causes which started him or her down that dark road.
<G-vec00081-001-s106><cease.aufhören><de> Ob es so auch uns höchste Zeit ist, den Weißrussen, aufzuhören, dieser zwei großen Menschen herunterzustoßen, ihre ewige Ruhe beunruhigend, und, zu beginnen, sich zu ihm wie zu den Symbolen unserer komplizierten und widersprüchlichen Geschichte zu verhalten.
<G-vec00081-001-s106><cease.aufhören><en> Is it time also for us, to Belarusians to cease to push together these two great people, disturbing them eternal rest, and to begin to treat them as to symbols of our difficult and inconsistent history.
<G-vec00081-001-s107><cease.aufhören><de> Sie kamen aus allen Gesellschaftsschichten und allen Regionen des Landes und baten die KPCh (Kommunistische Partei China), mit den eskalierenden Schikanen aufzuhören und für den Schutz der Menschenrechte zu sorgen.
<G-vec00081-001-s107><cease.aufhören><en> They came from all walks of life and regions of the country to ask the Chinese Communist regime to cease its escalating harassment, and ensure protection for basic human rights.
<G-vec00081-001-s108><cease.aufhören><de> 13:11 und ich bestrafen die Welt für ihr Übel und das böse für ihre Ungerechtigkeit; und ich verursache das arrogancy vom stolzen aufzuhören und lege Tief die Arroganz vom schrecklichen.
<G-vec00081-001-s108><cease.aufhören><en> 13:11 And I will punish the world for their evil, and the wicked for their iniquity; and I will cause the arrogancy of the proud to cease, and will lay low the haughtiness of the terrible.
<G-vec00081-001-s109><cease.aufhören><de> Es ist der Druck der Milch im udder vom Ende von Milch Enthebung, die Milch Produktion verursachen wird, aufzuhören, deshalb verlangsamt Melken der Stute, den Druck zu entlasten, nur das Verfahren.
<G-vec00081-001-s109><cease.aufhören><en> It is the pressure of the milk in the udder from the cessation of milk removal that will cause milk production to cease, so milking the mare to relieve the pressure only slows the process.
<G-vec00081-001-s110><cease.aufhören><de> Inhalte die insgesamt nicht mit den Überzeugungen die Sie zum Zeitpunkt Ihrer Erfahrung hatten übereinstimmten Ich erwartete entweder zu einem anderen Bereich weiter zu gehen oder aufzuhören zu existieren, ich sah diesen Zustand von Bewusstheit in der Leere nicht voraus.
<G-vec00081-001-s110><cease.aufhören><en> Content that was entirely not consistent with the beliefs you had at the time of your experience I was expecting to either go on to a different plane or cease to exist, I did not foresee this state of awareness in the void
<G-vec00081-001-s111><cease.aufhören><de> Doch kommt die Meinung vor, dass wenn aufzuhören, sich zu beschäftigen, so werden sich mit der Zeit die Muskeln ins Fett verwandeln.
<G-vec00081-001-s111><cease.aufhören><en> After all there is an opinion that if to cease to be engaged, over time muscles will turn into fat.
<G-vec00081-001-s112><cease.aufhören><de> Ihr Partner ist, wie auch Sie selbst nicht ideal, deshalb ist gekommen es ist höchste Zeit, zu lernen, miteinander zu genießen, und, aufzuhören, aus dem geringsten Anlass abgeärgert zu werden.
<G-vec00081-001-s112><cease.aufhören><en> Your partner is not ideal, as well as you, and therefore came it is time to learn to enjoy with each other, and to cease to be irritated for the least thing.
<G-vec00081-001-s113><cease.aufhören><de> "In den Versuchen, den Kreis des Verkehrs auszudehnen, um aufzuhören, sich zu genieren, braucht man, weit außerhalb der Zone des Komforts sofort nicht ""herauszuspringen"": es kann ein viel zu großer Schock werden, nach dem Sie noch mehr schüchtern sein werden."
<G-vec00081-001-s113><cease.aufhören><en> "In attempts to expand a circle of contacts to cease to hesitate, the descent should not ""jump out"" far beyond the zone of comfort: it can become too big shock after which you will become even more timid."
<G-vec00081-001-s190><stop.aufhören><de> """Als der Freund einige Zeit später aus dem Gefängnis kam, flehte er uns an, sofort aufzuhören."
<G-vec00081-001-s190><stop.aufhören><en> """When the friend was released from prison some time later, he begged us to stop right away."
<G-vec00081-001-s191><stop.aufhören><de> Datum festlegen, mit Trinken aufzuhören Witz.
<G-vec00081-001-s191><stop.aufhören><en> Set a date to stop drinking joke.
<G-vec00081-001-s192><stop.aufhören><de> Ein gutes Sutta ist eines, daß Sie dazu anregt aufzuhören, es zu lesen.
<G-vec00081-001-s192><stop.aufhören><en> A good sutta is one that inspires you to stop reading it.
<G-vec00081-001-s193><stop.aufhören><de> Der Trick besteht darin zu Essen aufzuhören, wenn das Essen aufhört, so delikat zu sein.
<G-vec00081-001-s193><stop.aufhören><en> The trick is to stop eating when the food stops being that delicious.
<G-vec00081-001-s194><stop.aufhören><de> Das erklärte mein unglaubliches Benehmen bei dem verzweifelten Versuch, mit dem Trinken aufzuhören.
<G-vec00081-001-s194><stop.aufhören><en> My incredible behavior in the face of a desperate desire to stop was explained.
<G-vec00081-001-s195><stop.aufhören><de> Nachdem wir neue Ideen implementiert hatten, entschieden wir uns, nicht damit aufzuhören und entwickelten mehrere einzigartige Tools, die bereits auf zwei Betriebssystemen verfügbar sind: Android und iOS.
<G-vec00081-001-s195><stop.aufhören><en> After implementing new ideas, we decided not to stop there and developed several more unique tools already available on two operating systems: Android and iOS.
<G-vec00081-001-s196><stop.aufhören><de> Derzeit gibt es keine verstanden oder berichteten negative Auswirkungen dieses Systems unter Verwendung Rauchen aufzuhören.
<G-vec00081-001-s196><stop.aufhören><en> Presently, there are no understood or reported negative effects of utilizing this system to stop smoking.
<G-vec00081-001-s197><stop.aufhören><de> Mit dem Eintritt der Erde in die letzte Stufe vor dem Austritt aus der dritten Dimension, wird es Zeit für euch damit aufzuhören, von euch selbst nur als Individuen mit bestimmten unterschiedlichen Persönlichkeiten, Charakteren, Talenten, Hoffnungen, Träumen und Erreichtem zu denken.
<G-vec00081-001-s197><stop.aufhören><en> With Earth entering the last stage of exiting third density, it is time that you stop thinking of yourselves only as individuals with distinctive personalities, characteristics, talents, hopes, dreams and accomplishments.
<G-vec00081-001-s198><stop.aufhören><de> Sie bat mich noch einmal, endlich aufzuhören, doch ich wollte weitermachen.
<G-vec00081-001-s198><stop.aufhören><en> She once again begged me to stop the feeding, but I still wanted to continue.
<G-vec00081-001-s199><stop.aufhören><de> Entscheidet euch heute, aufzuhören den Göttern und Geistern eurer Väter und Vorfahren zu dienen; und für Jesus, euren Herrn und Erlöser zu leben, und Ihm allein zu dienen.
<G-vec00081-001-s199><stop.aufhören><en> Decide today to stop to serve the gods and spirits your fathers and ancestors served; and to live for Jesus, your Lord and Saviour and to serve Him alone.
<G-vec00081-001-s200><stop.aufhören><de> Manipulieren heißt, den Menschen helfen aufzuhören, unabhängig und ethisch zu denken.
<G-vec00081-001-s200><stop.aufhören><en> To spin is to help people stop thinking independently and ethically.
<G-vec00081-001-s201><stop.aufhören><de> Die Kur besteht darin mit Vergleichen aufzuhören.
<G-vec00081-001-s201><stop.aufhören><en> The cure is to stop making comparisons.
<G-vec00081-001-s202><stop.aufhören><de> In dieser ernsten Lage forderte sie mutig die Polizisten auf, mit ihrem verbrecherischen Vorgehen aufzuhören und Dafa- Praktizierende freundlich zu behandeln.
<G-vec00081-001-s202><stop.aufhören><en> Even in this serious situation she warned the wicked police to stop doing wicked deeds; treat Dafa and Dafa practitioners kindly.
<G-vec00081-001-s203><stop.aufhören><de> Kläre die Situation, bevor die Lügen zur Gewohnheit werden, und lasse solche Menschen wissen, wann es Zeit ist aufzuhören oder sich zurückzunehmen, weil du ihr unzuverlässiges Verhalten nicht länger tolerierst.
<G-vec00081-001-s203><stop.aufhören><en> Clear the air before their lying becomes a habit and let such people know when to stop or back off, and that you won't tolerate untrustworthy behavior.
<G-vec00081-001-s204><stop.aufhören><de> Damit aufzuhören, Entwickler zu sein, ist viel schwieriger, als wieder anzufangen.
<G-vec00081-001-s204><stop.aufhören><en> To stop being a creator is much harder than starting again.
<G-vec00081-001-s205><stop.aufhören><de> mit Freunden sprechen über Plan - mit Trinken aufzuhören Ratgeber kostenlos.
<G-vec00081-001-s205><stop.aufhören><en> "Talk with trusted friends about your plan - to stop drinking free ""how to""."
<G-vec00081-001-s206><stop.aufhören><de> mit Freunden sprechen über Plan - mit Trinken aufzuhören Humor.
<G-vec00081-001-s206><stop.aufhören><en> Talk with trusted friends about your plan - to stop drinking humor.
<G-vec00081-001-s207><stop.aufhören><de> Wenn du bemerkst, dass du etwas tust oder dass es etwas an dir gibt, das andere nervös macht, dann ist es am besten damit aufzuhören.
<G-vec00081-001-s207><stop.aufhören><en> Â 34 If you notice there is something you do, or something about you that makes others nervous, it is probably best to stop.
<G-vec00081-001-s208><stop.aufhören><de> Es ist Zeit aufzuhören herumsitzen und fühlen sich schlecht über dich, oder sich Gedanken darüber, wie Sie Ihren Partner die Art und Weise zu befriedigen, die sie verdienen.
<G-vec00081-001-s208><stop.aufhören><en> It is time to stop sitting around and feeling bad about yourself, or worrying about how you are going to satisfy your partner the way they deserve.
<G-vec00081-001-s179><cease.aufhören><de> Jedoch nicht glücklich sein und die Verwendung von aufhören, SizeGenetics Nach diesem Ergebnis gewinnen, aufgrund der Tatsache, dass, wenn Sie fortfahren zu halten, es zu benutzen Sie das erstaunliche Ergebnis zusätzlich als Ihre Erwartung werden erhalten.
<G-vec00081-001-s179><cease.aufhören><en> However, do not be proud and cease making use of SizeGenetics after getting this outcome, because if you keep proceeding to use it you will get the incredible result extra than your expectation.
<G-vec00081-001-s180><cease.aufhören><de> Verkauf von Angel digital über iFiske bedeutet nicht, dass wir die Fanglizenzen durch unsere lokalen Händler zu verkaufen aufhören.
<G-vec00081-001-s180><cease.aufhören><en> The sale of fishing licenses digitally via iFiske does not mean that we cease to sell fishing licenses through our local retailers.
<G-vec00081-001-s181><cease.aufhören><de> – Um aber die Menschen in ihrer Umgestaltung vom Tier zum Menschen weiterzuführen, mussten diese Ahnungsfähigkeit und der hieraus folgende Glaube oder die Selbstsuggestion geschwächt werden oder ganz aufhören.
<G-vec00081-001-s181><cease.aufhören><en> So in order to advance the people further in their transformation from animal to human being this faculty for vague sensing and the ensuing belief or autosuggestion are weakened or cease totally.
<G-vec00081-001-s182><cease.aufhören><de> Die Länder werden aufhören zu existieren, wie wir sie heute kennen.
<G-vec00081-001-s182><cease.aufhören><en> Countries will cease to exist as we know them now.
<G-vec00081-001-s183><cease.aufhören><de> Diese Dinge werden sich aufgrund zunehmender Erkenntnisse der Menschen ändern, die dann aufhören werden, sich auf die organisierte Religion zu berufen.
<G-vec00081-001-s183><cease.aufhören><en> Things will change as peoples understanding grows and they cease to be so reliant on organised religion.
<G-vec00081-001-s184><cease.aufhören><de> In der Folge eines solchen umwandlungsrechtlichen Squeeze-Out würde die Diebold Nixdorf AG aufhören zu bestehen und die Notierung der Aktien der Diebold Nixdorf AG an der Frankfurter Wertpapierbörse eingestellt.
<G-vec00081-001-s184><cease.aufhören><en> As a result of such merger squeeze-out, Diebold Nixdorf AG would cease to exist and the listing of Diebold Nixdorf AG shares on the Frankfurt Stock Exchange would be terminated.
<G-vec00081-001-s185><cease.aufhören><de> Andernfalls müssten sie zugeben, dass es wirklich einen Schöpfer gibt, den Herrn von allem, was existiert, Gott der Allmächtige – und dann würden die Ungläubigen aufhören ungläubig zu sein.
<G-vec00081-001-s185><cease.aufhören><en> Otherwise, they would have to admit that there really is a Creator, the Lord of all that exists, God Almighty – and nonbelievers would cease to be nonbelievers.
<G-vec00081-001-s367><cease.aufhören><de> Jedes Jahr, Tausenden Sorten hören auf zu bestehen und Tausenden der neuen Sorten werden verursacht.
<G-vec00081-001-s367><cease.aufhören><en> Every year, thousands of species cease to exist and thousands of new species are created.
<G-vec00081-001-s368><cease.aufhören><de> "Falls wir vergessen, dass diese Teile des Bildes hinzu gemalt sind, hören wir auf in der Realität zu leben und wir treten in die Welt des ""Comics"" ein."
<G-vec00081-001-s368><cease.aufhören><en> If we forget that those parts of the picture have been projected, we cease to live in the physical reality and we enter the world of comics.
<G-vec00081-001-s369><cease.aufhören><de> Die autonome Organisierung der Gemeinden, ihre unverzichtbaren Kämpfe für die heiligen Orte und überlieferten Ländereien hören nicht auf.
<G-vec00081-001-s369><cease.aufhören><en> The autonomous organization of the communities and their unwavering struggles for sacred sites and ancestral lands do not cease.
<G-vec00081-001-s370><cease.aufhören><de> Wir hören auf, Beobachter unserer Emotionen zu sein.
<G-vec00081-001-s370><cease.aufhören><en> We cease to be observers of our emotions.
<G-vec00081-001-s371><cease.aufhören><de> Wenn du dem wahren Dhamma gemäß übst, wirst du für dich selbst wissen und sehen:,Dieses sind Krankheiten, Geschwüre und Stacheln; aber diese Krankheiten, Geschwüre und Stacheln hören ohne Überbleibsel auf.
<G-vec00081-001-s371><cease.aufhören><en> When you practise in accordance with the true Dhamma, you will know and see for yourself thus: 'These are diseases, tumours, and darts; but here these diseases, tumours, and darts cease without remainder.
<G-vec00081-001-s372><cease.aufhören><de> 10 Treibe den Spötter hinaus, so geht der Zank weg, und Hader und Schmähung hören auf.
<G-vec00081-001-s372><cease.aufhören><en> 10 Cast out the scorner, and contention shall go out; yea, strife and reproach shall cease.
<G-vec00081-001-s373><cease.aufhören><de> Erst dann, wenn das Unterbewusste gereinigt ist, hören sie auf; sie haben jedoch keine große Bedeutung (vorausgesetzt man versteht, was sie darstellen, und ist davon nicht betroffen), solange den alten Bewegungen nicht erlaubt wird, in den Wachzustand zurückzukehren oder dort zu verbleiben.
<G-vec00081-001-s373><cease.aufhören><en> It is only when the subconscient is cleared that they cease; meanwhile they are of not much importance (provided one understands what they are and is not affected) so long as the old movements are not allowed to recur or remain in the waking state.
<G-vec00081-001-s374><cease.aufhören><de> """ich bin Insulin, ließ mich in"" (Art II Diabetes).Wenn diese glyconutrients abwesend oder beschädigt sind, hören die Zellen auf, die Fähigkeit zu haben zu erkennen und miteinander und verschiedene Krankheiten wie Diabetes zu verständigen kann in einer Einzelperson erscheinen.Neue Forschung und Studien konzentrieren auf den Gebrauch von glyconutrients, zuckerkranken Patienten zu helfen."
<G-vec00081-001-s374><cease.aufhören><en> """I'm insulin, let me in"" (Type II diabetes).If these glyconutrients are absent or damaged, the cells cease to have the ability to recognize and communicate with one another and various diseases such as diabetes may appear in an individual.New research and studies are focusing on the use of glyconutrients to help diabetic patients."
<G-vec00081-001-s375><cease.aufhören><de> Die Ströme hören auf zu fließen.
<G-vec00081-001-s375><cease.aufhören><en> The streams cease to flow.
<G-vec00081-001-s376><cease.aufhören><de> 14:17 Und du sollst zu ihnen sagen dies Wort: Meine Augen fließen von Tränen Tag und Nacht und hören nicht auf; denn die Jungfrau, die Tochter meines Volks, ist greulich zerplagt und jämmerlich geschlagen.
<G-vec00081-001-s376><cease.aufhören><en> 14:17 And thou shalt say this word unto them: Let mine eyes run down with tears, night and day, and not cease; for the virgin daughter of my people is broken with a great breach, with a very grievous blow.
<G-vec00081-001-s377><cease.aufhören><de> """Glaube und Hoffnung sind die Tugenden eines unvollkommenen Zustandes und hören mit ihm auf; die Liebe aber ist größer, weil sie Vollendung ist."
<G-vec00081-001-s377><cease.aufhören><en> """Faith and hope are graces of an imperfect state, and they cease with that state; but love is greater, because it is perfection."
<G-vec00081-001-s378><cease.aufhören><de> Sie hören nicht auf andere zu verblüffen und sich daran zu erfreuen.
<G-vec00081-001-s378><cease.aufhören><en> They do not cease to amaze others and get pleasure from it.
<G-vec00081-001-s379><cease.aufhören><de> Alle Bewegungen hören nun auf.
<G-vec00081-001-s379><cease.aufhören><en> All movements now cease.
<G-vec00081-001-s380><cease.aufhören><de> „Glaube und Hoffnung sind die Tugenden eines unvollkommenen Zustandes und hören mit ihm auf; die Liebe aber ist größer, weil sie Vollendung ist.
<G-vec00081-001-s380><cease.aufhören><en> “Faith and hope are graces of an imperfect state, and they cease with that state; but love is greater, because it is perfection.
<G-vec00081-001-s381><cease.aufhören><de> Sie verspricht, Volksvertreter einzuberufen, aber in Wirklichkeit bleibt alles beim Alten, die Verfolgungen hören nicht auf, die Beamtenwillkür bleibt dieselbe, es gibt keine freien Versammlungen, keine freien Volkszeitungen, die Gefängnisse, in denen die Kämpfer für die Sache der Arbeiter schmachten, werden nicht geöffnet.
<G-vec00081-001-s381><cease.aufhören><en> It promises to convene representatives of the people, but actually everything remains unchanged; the persecutions do not cease, the lawlessness of the officials proceeds as before; there are no free public meetings, no freely circulated people's newspapers; the prisons in which fighters for the working-class cause are languishing have not been thrown open.
<G-vec00081-001-s382><cease.aufhören><de> 10 Treibe den Spötter fort, so geht der Zank hinaus, und Streit und Schande hören auf.
<G-vec00081-001-s382><cease.aufhören><en> 10 Drive out a scoffer, and strife will go out, and quarreling and abuse will cease.
<G-vec00081-001-s383><cease.aufhören><de> 7 Ein Baum hat Hoffnung, wenn er schon abgehauen ist, daß er sich wieder erneue, und seine Schößlinge hören nicht auf.
<G-vec00081-001-s383><cease.aufhören><en> 7 For there is hope of a tree, if it be cut down, that it will sprout again, and that the tender branch thereof will not cease.
<G-vec00081-001-s384><cease.aufhören><de> Wenn der Teil dieses Systems aus Synchronisierung mit dem Rest heraus ist, hören wir auf, leistungsfähig und effektiv zu arbeiten.
<G-vec00081-001-s384><cease.aufhören><en> When part of that system is out of sync with the rest, we cease to function efficiently and effectively.
<G-vec00081-001-s385><cease.aufhören><de> Er sagt: „Derhalben... hören wir nicht auf, für euch zu beten und zu bitten, daß ihr erfüllet werdet mit Erkenntnis seines Willens in allerlei geistlicher Weisheit und Verständnis, daß ihr wandelt würdig dem Herrn zu allem Gefallen und fruchtbar seid in allen guten Werken und wachset in der Erkenntnis Gottes, und gestärkt werdet mit aller Kraft nach seiner herrlichen Macht, in aller Geduld und Langmütigkeit mit Freuden.“ (Kol.
<G-vec00081-001-s385><cease.aufhören><en> "He says: We ""do not cease to pray for you, and to desire that ye might be filled with the knowledge of His will in all wisdom and spiritual understanding; that ye might walk worthy of the Lord unto all pleasing, being fruitful in every good work, and increasing in the knowledge of God; strengthened with all might, according to His glorious power, unto all patience and long-suffering with joyfulness."""
<G-vec00081-001-s392><cease.aufhören><de> Sein Inhalt hört auf sich zu bewegen, stagniert, was zu Verstopfung und einer starken Verdichtung der Stuhlmassen führt.
<G-vec00081-001-s392><cease.aufhören><en> Its contents cease to move, stagnate, which leads to constipation and a powerful compaction of fecal masses.
<G-vec00081-001-s393><cease.aufhören><de> Sie werden nichts sehen, das auslaufen wird, aber anscheinend wird dieser Speichel herausgedrückt und der Juckreiz hört auf.
<G-vec00081-001-s393><cease.aufhören><en> You will not see anything that will leak out, but apparently, it is this saliva that is squeezed out and itches cease.
<G-vec00081-001-s394><cease.aufhören><de> Hört auf, von Feinden zu reden, wenn eine Errungenschaft ein großes Licht entzünden kann.
<G-vec00081-001-s394><cease.aufhören><en> Cease speaking of enemies when an achievement can kindle a great light.
<G-vec00081-001-s395><cease.aufhören><de> Ein göttliches Beispiel hört niemals auf, Belohnungen zu ernten.
<G-vec00081-001-s395><cease.aufhören><en> A Godly example will never cease reaping rewards.
<G-vec00081-001-s396><cease.aufhören><de> Fundamentalanalyse Aktien hört nie auf sich zu wundern, warum Unterschiede zwischen Preis und Wert bestehen.
<G-vec00081-001-s396><cease.aufhören><en> Fundamental Investment Research shall never cease to wonder why differences between price and value exist.
<G-vec00081-001-s397><cease.aufhören><de> Allein ohne Freunde in Leben, ohne die für Sie kümmert, oder liebt dich, Sie hört auf zu existieren.
<G-vec00081-001-s397><cease.aufhören><en> With no friends in life, with no one that cares for you, or loves you, you cease to exist.
<G-vec00081-001-s398><cease.aufhören><de> """Werdet Moslems, und hört auf, Euch nach der Mode [Weise] der Fremden zu bekleiden"", sagte sein Dichter Hassan ibn Thabit einer Delegation von Stammesangehörigen, die gekommen waren, um mit der neuen Macht zu verhandeln."
<G-vec00081-001-s398><cease.aufhören><en> 'Become Muslims,/ And cease to dress after the fashion of strangers', his poet Hassan ibn Thabit told a delegation of tribesmen come to parley with the new power.
<G-vec00081-001-s399><cease.aufhören><de> Auf diese Art hört die Exklusivitätvereinbarung mit Dreamstime auf, zu existieren.
<G-vec00081-001-s399><cease.aufhören><en> In this way, the exclusivity agreement with Dreamstime will cease to exist.
<G-vec00081-001-s400><cease.aufhören><de> Ihr hört in Selbstvergessenheit auf, euch mit dem zu identifizieren, was für ein winziger Fleck ihr seid, und verliert euch selbst im Erfahren von irgendetwas Besonderem.
<G-vec00081-001-s400><cease.aufhören><en> You cease to identify, in self-forgetfulness, what a tiny speck you are, and lose yourself in experiencing something enormous.
<G-vec00081-001-s401><cease.aufhören><de> Oder – die Sozialdemokratie hört auf, zu sein.
<G-vec00081-001-s401><cease.aufhören><en> Or – the Social Democracy will cease to exist.
<G-vec00213-002-s345><cease.aufhören><de> ◊ Hört auf seine / ihre Partnerin zu Bett und schlafen in Ihrer Nähe zu stören.
<G-vec00213-002-s345><cease.aufhören><en> ◊ Cease to disturb his / her partner to bed and sleeping near you.
<G-vec00213-002-s346><cease.aufhören><de> Es ist der innere Friede, der angestrebt wird, sowie eine freudige Zuversicht, ein freudiges Glücklichsein nach außen – dann hört diese Art von nervösem Druck und diese Störung auf.
<G-vec00213-002-s346><cease.aufhören><en> Peace within and a cheerful confidence and gladness without is what is wanted – then this kind of nervous pressure and disorder would cease.
<G-vec00213-002-s348><cease.aufhören><de> 22:10 Vertreibe den Spötter, so nimmt der Streit ein Ende, und das Zanken und Schmähen hört auf.
<G-vec00213-002-s348><cease.aufhören><en> 22:10 Cast out the scoffer, and contention will go out; Yea, strife and ignominy will cease.
<G-vec00213-002-s349><cease.aufhören><de> Extreme Schmerzen während der Periode, fließt reichlich und hört nicht auf bis zum nächsten Periode, die meiste Zeit ans Bett gefesselt.
<G-vec00213-002-s349><cease.aufhören><en> Extreme pain during the period, flow profuse and do not cease until next period, most of the time confined to bed.
<G-vec00213-002-s133><stop.aufhören><de> Wir haben bereits fünf von ihnen gefangen genommen… Wenn Sie nicht aufhören, Mörder zu schicken, schicke ich einen nach Moskau - und ich muss keinen zweiten schicken.
<G-vec00213-002-s133><stop.aufhören><en> We’ve already captured five of them… If you don’t stop sending killers, I’ll send one to Moscow – and I won’t have to send a second”.
<G-vec00213-002-s134><stop.aufhören><de> Bei mir zu Hause geht es dann weiter, sie kann gar nicht aufhören meinen Schwanz zu blasen in ihren verschwitzten Sportklamotten.
<G-vec00213-002-s134><stop.aufhören><en> At my house it goes on, she can not stop blowing my cock in her sweaty sports clothes.
<G-vec00213-002-s135><stop.aufhören><de> Das Risiko, das Nutzer aufhören, das Produkt zu nutzen (Worst Case).
<G-vec00213-002-s135><stop.aufhören><en> The risk that users will stop using the product (worst case).
<G-vec00213-002-s136><stop.aufhören><de> US-Verteidigungsminister James Mattis bestätigte danach, dass Washington aufhören würde, die kurdischen Milizen zu bewaffnen, bemerkte jedoch, dass "Polizeikräfte", die aus der lokalen Bevölkerung bestehen, immer noch gebraucht würden, um "sicherzustellen, dass ISIS nicht zurückkommt".
<G-vec00213-002-s136><stop.aufhören><en> US Defense Secretary James Mattis later confirmed Washington would stop arming the Kurdish militias, noting that “police forces” comprised of the local population would still be needed to “make certain that ISIS doesn’t come back.”
<G-vec00213-002-s137><stop.aufhören><de> Wenn Sie im Sport aufhören zu trainieren, verlieren Sie schnell die Form.
<G-vec00213-002-s137><stop.aufhören><en> If in sports you stop training, then quickly lose shape.
<G-vec00213-002-s138><stop.aufhören><de> Sogar meine Großmutter konnte nicht aufhören, mich zu loben, wie schön sein Gesicht wurde.
<G-vec00213-002-s138><stop.aufhören><en> Even my grandmother couldn't stop praising me how beautiful his face turned out.
<G-vec00213-002-s139><stop.aufhören><de> Wo wir von der Macht dieser Versöhnung berührt sind, können wir darauf verzichten, unsere Leiden aufzurechnen und zu vergleichen, so wie wir auch aufhören können, unsere Schuld zu leugnen und zu verdrängen.
<G-vec00213-002-s139><stop.aufhören><en> When we are touched by the power of this reconciliation, we no longer need to count and compare our sufferings, and also can stop denying and repressing our guilt.
<G-vec00213-002-s140><stop.aufhören><de> Wenn Sie aufhören zu arbeiten, und dann nehmen Sie eine neue Beschäftigung an anderer Stelle, wird die Rente sofort aufgehängt werden.
<G-vec00213-002-s140><stop.aufhören><en> If you stop working, and then take up new employment elsewhere, the pension will be immediately suspended.
<G-vec00213-002-s141><stop.aufhören><de> Ich konnte einfach nicht aufhören an meine Thesis zu denken.
<G-vec00213-002-s141><stop.aufhören><en> I just couldn’t stop thinking about my thesis.
<G-vec00213-002-s143><stop.aufhören><de> Ich werde nicht aufhören zu kämpfen.
<G-vec00213-002-s143><stop.aufhören><en> I will not stop fighting.
<G-vec00213-002-s144><stop.aufhören><de> Der Wille beschließt, etwas soll geschehen, zum Beispiel soll der Körper aufhören, zu rauchen.
<G-vec00213-002-s144><stop.aufhören><en> The will decides that something should be done, for example the body should stop smoking.
<G-vec00213-002-s145><stop.aufhören><de> Wenn die Welpen aufhören, Milch zu trinken sinkt der pH-Wert (Säuregehalt) des Magens.
<G-vec00213-002-s145><stop.aufhören><en> When the puppies stop drinking milk the pH (acidity) of the stomach reduces.
<G-vec00213-002-s146><stop.aufhören><de> Außerdem sollten Sie aufhören, Alkohol und alkoholfreie Getränke zu trinken, da diese mit Kalorien überladen sind.
<G-vec00213-002-s146><stop.aufhören><en> In addition, you should stop drinking alcohol and soft drinks because they are overloaded with calories.
<G-vec00213-002-s147><stop.aufhören><de> Jeder im Quartier kennt sie und liebt sie!” – der Mann begleitet uns während eines Stück Weges und kann nicht aufhören, Naomi zu preisen.
<G-vec00213-002-s147><stop.aufhören><en> Everyone in this area knows Naomi and loves her!” The man who spoke those words followed us down the road one day and didn’t stop praising Noemi.
<G-vec00213-002-s148><stop.aufhören><de> Zuerst aufhören zu denken, viel von PST mit beschädigten Header.
<G-vec00213-002-s148><stop.aufhören><en> Firstly stop thinking much of PST with corrupted header.
<G-vec00213-002-s149><stop.aufhören><de> Die Anzeige wird aufhören zu blinken.
<G-vec00213-002-s149><stop.aufhören><en> The digit will stop flashing.
<G-vec00213-002-s150><stop.aufhören><de> Ehegatten können aufhören zu fragen, wenn ihr Mann oder Frau...
<G-vec00213-002-s150><stop.aufhören><en> Spouses can stop wondering if their husband or wife is visiting pornographic...
<G-vec00213-002-s151><stop.aufhören><de> Mädchen mit kleinen Titten sind immer supergeil, also bist du auf der Suche nach einem Leckerbissen, denn diese Schlampen können einfach nicht aufhören, mit ihren Liebeslöchern zu spielen.
<G-vec00213-002-s151><stop.aufhören><en> Girls with small tits are always super horny, so you’re in for a treat because these sluts just can’t stop toying with their love holes.
<G-vec00303-002-s198><heed.aufhören><de> 45Und ihr kehrtet zurück und weintet vor Jehova; aber Jehova hörte nicht auf eure Stimme und neigte sein Ohr nicht zu euch.
<G-vec00303-002-s198><heed.aufhören><en> 45 And you returned and wept before the Lord, but the Lord would not heed your voice or listen to you.
<G-vec00113-002-s068><quit.aufhören><de> Ich habe aufgehört zu schwören, zu rauchen und andere in meinem täglichen Leben zu betrügen.
<G-vec00113-002-s068><quit.aufhören><en> I quit swearing, smoking, and cheating in my everyday life.
<G-vec00113-002-s069><quit.aufhören><de> Als ich mich wirklich selbst zu lieben begann, habe ich aufgehört mich meiner freien Zeit zu berauben und ich habe aufgehört weiter grandiose Projekte für die Zukunft zu entwickeln.
<G-vec00113-002-s069><quit.aufhören><en> As I began to love myself I quit stealing my own time, and I stopped designing huge projects for the future.
<G-vec00113-002-s070><quit.aufhören><de> OaT: Musikalischen Hintergrund gibt es; ich habe sechs Jahre Klavier gespielt aber leider mit vierzehn aufgehört weil es mich nervte von anderen komponierte Stücke nachzuspielen und sich meine musikalischen Interessen zu der Zeit stark gewandelt haben.
<G-vec00113-002-s070><quit.aufhören><en> OaT: There is a bit of a musical background; I played piano for six years but sadly quit at fourteen because it annoyed me to play pieces composed by others and my musical interests changed a lot at that time.
<G-vec00113-002-s071><quit.aufhören><de> Vor den Sommerferien hat Maria aufgehört zu sprechen.
<G-vec00113-002-s071><quit.aufhören><en> Before the summer break, Maria quit talking.
<G-vec00113-002-s074><quit.aufhören><de> Wenn Ihr Klettern lernen wollt, könnt Ihr aufhören, Eure Kleiderschränke zu erklimmen.
<G-vec00113-002-s074><quit.aufhören><en> If free-climbing is your thing, you can quit scrambling up the side of your wardrobe.
<G-vec00113-002-s075><quit.aufhören><de> Wenn Sie immer noch nicht aufhören zu trinken, daher wissen Sie nicht, und es fehlen wesentliche Informationen.
<G-vec00113-002-s075><quit.aufhören><en> If you still can't quit drinking, therefore you do not know and missing essential information.
<G-vec00113-002-s076><quit.aufhören><de> Es gibt mehrere Gründe, warum Sie nicht mit dem Rauchen beginnen oder damit aufhören sollten.
<G-vec00113-002-s076><quit.aufhören><en> There are multiple reasons you should not start smoking, or you should quit.
<G-vec00113-002-s077><quit.aufhören><de> Jean-Michel: Wir sind die Rolling Stones der Straßenkünstler genannt worden, weil wir mehrere Male gesagt haben, das wir aufhören, aber immer wenn wir auf diese Fragestellung zurückkamen, begannen wir wieder gemeinsam zu touren.
<G-vec00113-002-s077><quit.aufhören><en> Jean-Michel: We have been called The Rolling Stones of street performers, because we have said several times that we would quit, but always came back on that decision and started touring together again.
<G-vec00113-002-s078><quit.aufhören><de> Wenn du das Gefühl hast, ohne Hilfe nicht aufhören zu können, frage deinen Arzt nach Methoden oder Medikamenten, die dir bei der Entwöhnung helfen können.
<G-vec00113-002-s078><quit.aufhören><en> If you feel that you cannot quit on your own, talk to your physician about strategies or medications that can help you quit.
<G-vec00113-002-s079><quit.aufhören><de> Das musste ich aber aufhören, weil das zu viel Praxis war und ich durfte mein Praktikum nicht in Deutschland machen.
<G-vec00113-002-s079><quit.aufhören><en> But I had to quit because it was too much training on the job and I wasn't allowed to do an internship in Germany.
<G-vec00113-002-s080><quit.aufhören><de> Ich werde eine Frau 18-55 Jahre schneiden, ich werde aufhören, weil ich steril bin.
<G-vec00113-002-s080><quit.aufhören><en> I will cut a woman 18-55 years, I will quit because I am sterile.
<G-vec00113-002-s081><quit.aufhören><de> Eventuell musst du nur etwas mehr Wasser trinken und aufhören, dir ständig über deine Lippen zu lecken.
<G-vec00113-002-s081><quit.aufhören><en> Sometimes, all you have to do is drink more water and quit licking your lips.
<G-vec00113-002-s082><quit.aufhören><de> Eigentlich verdammt schade, dass wir jetzt nie wieder was von Biohazard hören werden aber man soll halt auch immer aufhören, wenns gerade am schönsten ist.
<G-vec00113-002-s082><quit.aufhören><en> Actually, it´s too fucking bad that we won´t ever hear anything again from Biohazard but you should always quit while you´re ahead.
<G-vec00113-002-s083><quit.aufhören><de> Vor dem Eingriff müssen Sie aufhören zu rauchen.
<G-vec00113-002-s083><quit.aufhören><en> Prior to the procedure you must quit smoking.
<G-vec00113-002-s084><quit.aufhören><de> Ich hebe es wieder auf, wenn es aufhören will.
<G-vec00113-002-s084><quit.aufhören><en> I pick them up again when they want to quit.
<G-vec00113-002-s085><quit.aufhören><de> Um die Wirksamkeit der Wirkstoffe zu verbessern, wird empfohlen, die Verwendung von Alkohol zu begrenzen und aufhören zu rauchen.
<G-vec00113-002-s085><quit.aufhören><en> To increase the effectiveness of the active components, it is recommended to limit the use of alcohol and quit smoking.
<G-vec00113-002-s086><quit.aufhören><de> So lange da diese Liebe ist, werden wir niemals aufhören.
<G-vec00113-002-s086><quit.aufhören><en> As long as the love is there, we will never quit.
<G-vec00113-002-s087><quit.aufhören><de> Wenn machbar, sollte Rauchern, die nur mit Selbsthilfematerialien aufhören wollen, der Zugang zu einer telefonischen Beratungsmöglichkeit (Rauchertelefon) ermöglicht werden.
<G-vec00113-002-s087><quit.aufhören><en> Where feasible, smokers attempting to quit with self-help material alone should be provided with access to support through a telephone hotline/helpline.
<G-vec00113-002-s088><quit.aufhören><de> Photoshop wird jetzt aufhören.
<G-vec00113-002-s088><quit.aufhören><en> Photoshop will quit now.”
<G-vec00113-002-s089><quit.aufhören><de> Er weiß wie man Spannungen aufbaut, so dass man, wie bei einem guten Thriller, nicht aufhören kann zuzuhören, weil man wissen möchte wie’s weitergeht.
<G-vec00113-002-s089><quit.aufhören><en> He knows how to arrange tensions, so you can’t quit listening because you want to know how it ends, like in a good thriller.
<G-vec00113-002-s090><quit.aufhören><de> Rauchen ist eine sehr ungesunde Gewohnheit und viele Menschen würden gerne aufhören.
<G-vec00113-002-s090><quit.aufhören><en> Smoking is a very unhealthy habit and many people would like to quit it.
<G-vec00113-002-s091><quit.aufhören><de> Das wäre zu einfach gewesen und schließlich kann jeder aufhören.
<G-vec00113-002-s091><quit.aufhören><en> It would have been too easy to quit, anyone can do that, but not everyone could carry on.
<G-vec00113-002-s092><quit.aufhören><de> Einige statistische Studien deuten darauf hin, dass mehr als drei Drittel der aktiven Raucher aufhören möchten, wobei die Hälfte mindestens einmal im Jahr einen Versuch unternimmt.
<G-vec00113-002-s092><quit.aufhören><en> Some statistical studies seem to indicate that more than three thirds of active smokers wish to quit, with half of them actually trying at least once each year.
<G-vec00113-002-s093><quit.aufhören><de> Die drei Spots zeigen einen Teenager unter dem Druck seiner Altersgenossen, mit dem Rauchen anzufangen, einen erwachsenen Raucher, der aufhören möchte, und einen Nichtraucher, der auf einer Party den Rauch anderer ertragen muss.
<G-vec00113-002-s093><quit.aufhören><en> The three adverts depict a teenager under pressure from his peers to start smoking, an adult smoker longing to quit and a non-smoker enduring other people’s smoke at a party.
<G-vec00113-002-s094><quit.aufhören><de> Erst danach kann die Entscheidung gefallen werden, das man damit aufhören möchte.
<G-vec00113-002-s094><quit.aufhören><en> Only after you can sense this, you are able to make the decision to quit.
<G-vec00113-002-s095><quit.aufhören><de> Wenn ihr aufhört, nachdem ein Lungenschaden diagnostiziert wurde, ist es zu spät.
<G-vec00113-002-s095><quit.aufhören><en> If you quit after you're diagnosed with lung damage, it's too late," he also tweeted Thursday.
<G-vec00113-002-s096><quit.aufhören><de> "Um eine Sekte zu verlassen, muss eine Person einen Punkt erreichen, an dem sie es nicht mehr ertragen kann, zu bleiben, egal was passiert, wenn sie aufhört.
<G-vec00113-002-s096><quit.aufhören><en> “To leave a group a person must reach a point where they can't bear to be there anymore no matter what happens if they quit.
<G-vec00113-002-s112><quit.aufhören><de> Unglück ist kein Grund, um aufzuhören.
<G-vec00113-002-s112><quit.aufhören><en> Adversity is no reason to quit.
<G-vec00113-002-s113><quit.aufhören><de> In einer solchen Situation empfehle ich Ihnen, für den Rest des Tages aufzuhören und am nächsten Tag mit einem frischen Geist fortzufahren.
<G-vec00113-002-s113><quit.aufhören><en> In a situation like this, I suggest you quit for the rest of the day and start on the next day with a fresh mind.
<G-vec00113-002-s114><quit.aufhören><de> Zwei weitere Studien untersuchten Versuche aufzuhören und beobachteten einen Anstieg derselben in Australien, nachdem standardisierte Verpackungen eingeführt worden waren.
<G-vec00113-002-s114><quit.aufhören><en> Two further studies looked at quit attempts and observed increases in these in Australia after standardised packaging was introduced.
<G-vec00113-002-s115><quit.aufhören><de> Im Wesentlichen sind sie dazu gedacht, Raucherinnen und Rauchern dabei zu helfen, mit dem Rauchen aufzuhören oder erst gar nicht anzufangen.
<G-vec00113-002-s115><quit.aufhören><en> Crucially, they aim to help smokers to quit or not to start in the first place.
<G-vec00113-002-s116><quit.aufhören><de> Stellen Sie sich diese Situation vor – Sie versuchen aufzuhören und Ihr Kollege hat gerade eine Zigarette angemacht.
<G-vec00113-002-s116><quit.aufhören><en> Imagine this situation – you are trying to quit and your co-worker just went out for a smoke.
<G-vec00113-002-s117><quit.aufhören><de> Als ihnen die Gefahren bewusst wurden, haben sie vielleicht versucht aufzuhören, aber für einige ist es nicht leicht.
<G-vec00113-002-s117><quit.aufhören><en> When they realized the dangers, they may have attempted to quit, but for some it is not easy.
<G-vec00113-002-s118><quit.aufhören><de> Andre hat beschlossen aufzuhören zu boxen.
<G-vec00113-002-s118><quit.aufhören><en> Andre has decided to quit boxing.
<G-vec00113-002-s119><quit.aufhören><de> Ich dachte dann: „Ich habe schon so viel geopfert!“ Wenn ich mir diese schlichten Gedanken ansehe, merke ich jetzt, dass sie das Werk der alten Mächte waren, die meine Eigensinne manipulierten, um entweder Zeit zu verschwenden oder aufzuhören.
<G-vec00113-002-s119><quit.aufhören><en> I would think: “I have already sacrificed so much!” Looking at these subtle thoughts, I see now that they were the work of the old forces, manipulating my attachments to either waste time or quit.
<G-vec00113-002-s120><quit.aufhören><de> Er schlägt vor, dass eine der wichtigsten Sache, die Sie tun können, um Lungenkrebszellen zu vermeiden ist Rauchen aufzuhören und einfach das Rauchen von Zigaretten in allen möglichen Kosten zu vermeiden.
<G-vec00113-002-s120><quit.aufhören><en> It suggests that one of the most vital thing you can do to avoid lung cancer cells is to Quit Cigarette smoking and avoid easy cigarette smoking in all potential cost.
<G-vec00113-002-s121><quit.aufhören><de> Sie sagte, dass die Entscheidung eines Rauchers zu versuchen und aufzuhören ein entscheidender erster Schritt ist.
<G-vec00113-002-s121><quit.aufhören><en> Dr. Patricia Folan directs the Center for Tobacco Control at Northwell Health in Great Neck, N.Y. She said that a smoker's decision to try and quit is a crucial first step.
<G-vec00113-002-s122><quit.aufhören><de> Habe damals sogar kurz daran gedacht, mit dem Klavierspielen aufzuhören.
<G-vec00113-002-s122><quit.aufhören><en> For a short time I even thought to quit playing piano.
<G-vec00113-002-s123><quit.aufhören><de> Wenn Sie süchtig nach Gay Pornos sind, dann ist es an der Zeit aufzuhören und den xxx Live-Sex-Chat mit Sportsfreunden zu genießen.
<G-vec00113-002-s123><quit.aufhören><en> If you are addicted to watching gay porn recordings, then it's time to quit and start enjoying xxx live sex chat with Athletic men.
<G-vec00113-002-s124><quit.aufhören><de> Eltern können dabei helfen, ihre Jugendlichen vom Rauchen und von rauchlosen Tabakprodukten abzuhalten, indem sie positive Vorbilder sind (d. h., indem sie nicht rauchen oder kauen), offen über die Gefahren des Tabaks sprechen und Jugendliche, die bereits rauchen oder kauen, dazu ermutigen, damit aufzuhören, einschließlich sie dabei zu unterstützen, nach medizinischer Hilfe zu suchen, wenn nötig (Raucherentwöhnung: Rauchentwöhnung bei Kindern).
<G-vec00113-002-s124><quit.aufhören><en> Parents can help prevent their adolescent from smoking and using smokeless tobacco products by being positive role models (that is, by not smoking or chewing), openly discussing the hazards of tobacco, and encouraging adolescents who already smoke or chew to quit, including supporting them in seeking medical assistance if necessary (see Smoking Cessation).
<G-vec00113-002-s125><quit.aufhören><de> Zusammen mit der unnachgiebigen Leidenschaft nie aufzuhören, kam er auf die anderen Seite als Gewinner heraus.
<G-vec00113-002-s125><quit.aufhören><en> Together with a relentless passion to never quit, he has come out the other side a winner
<G-vec00113-002-s259><quit.aufhören><de> Frühere Studien haben gezeigt, dass Patientinnen eher mit dem Rauchen aufhören, wenn der Gesundheitsanbieter einen Fünfstufen-Plan anbietet, die sogenannten ‚Fünf As‘.
<G-vec00113-002-s259><quit.aufhören><en> Previous studies have shown that patients are more likely to quit smoking when healthcare providers follow a five-step process – the so-called ‘Five As’.
<G-vec00113-002-s260><quit.aufhören><de> Vier von fünf Rauchern möchten mit dem Rauchen aufhören.
<G-vec00113-002-s260><quit.aufhören><en> Since then, Hon Lik decided to quit smoking.
<G-vec00113-002-s261><quit.aufhören><de> Wenn du mit dem Rauchen aufhören möchtest, nimm dir fest vor, aufzuhören und lege ein Datum fest, an dem du mit dem Aufhören beginnen möchtest.
<G-vec00113-002-s261><quit.aufhören><en> Article SummaryX To successfully quit smoking, start by making a firm decision to quit and choosing a start date.
<G-vec00113-002-s262><quit.aufhören><de> Ich musste auch mit dem Rauchen aufhören, was ich einige Monate später tat.
<G-vec00113-002-s262><quit.aufhören><en> I also had to quit smoking, which I did several months later.
<G-vec00113-002-s263><quit.aufhören><de> Es gibt keine Altersbegrenzung, noch ist es JEMALS zu spät, mit dem Trinken aufzuhören.
<G-vec00113-002-s263><quit.aufhören><en> There is no age limit nor is it ever too late to try to quit drinking.
<G-vec00113-002-s264><quit.aufhören><de> In den letzten fünf Jahren habe ich immer wieder versucht, mit dem Trinken aufzuhören.
<G-vec00113-002-s264><quit.aufhören><en> In the last 5 years I had tried to quit drinking several times.
<G-vec00113-002-s265><quit.aufhören><de> Die 15ml E-Liquid Flaschen sind verbreitet bei denjenigen, die mit dem Dampfen anfangen und/oder versuchen mit dem Rauchen traditioneller Zigaretten aufzuhören.
<G-vec00113-002-s265><quit.aufhören><en> 15ml e-liquids bottles are largely used for those introducing themselves to vaping and/or trying to quit smoking traditional cigarettes.
<G-vec00113-002-s285><quit.aufhören><de> Nachdem sie aber Falun Gong zu praktizieren begonnen hatten, hörte mein Cousin auf zu spielen und seine familiären Beziehungen wurden harmonisch.
<G-vec00113-002-s285><quit.aufhören><en> After they began to practice Falun Gong, however, my cousin quit gambling and his family relationships became harmonious.
<G-vec00113-002-s286><quit.aufhören><de> Die Kreide blieb ihm im Hals stecken, und er hörte auf zu atmen.
<G-vec00113-002-s286><quit.aufhören><en> The chalk lodged in Tyson’s throat, and he quit breathing.
<G-vec00113-002-s287><quit.aufhören><de> Nachdem ich einige Medikamente einnahm, hörte ich für eine Weile auf, doch wurde ich immer wieder in Stresssituationen rückfällig.
<G-vec00113-002-s287><quit.aufhören><en> After I took some medications, I quit for some time, but went back whenever I was stressed.
<G-vec00113-002-s288><quit.aufhören><de> Ich hörte auf zu hören, zu sehen, zu atmen und legte mich hin, weil ich wusste dass ich ohnmächtig werden würde und ich wollte nicht fallen und mir den Hals brechen.
<G-vec00113-002-s288><quit.aufhören><en> I quit hearing/seeing/breathing and lay down because I knew I was passing out and didn't want to fall and break my neck.
<G-vec00113-002-s114><stop.aufhören><de> Ich muss aufhören mir diesen unnötigen Druck zu machen (leichter gesagt als getan).
<G-vec00113-002-s114><stop.aufhören><en> I need to stop putting so much useless pressure on myself (easier said than done).
<G-vec00113-002-s115><stop.aufhören><de> Mit dem viergelenkigen Arm werden Sie niemals aufhören zu kreieren.
<G-vec00113-002-s115><stop.aufhören><en> With the four-jointed arm you will never stop creating.
<G-vec00113-002-s116><stop.aufhören><de> Wir müssen aufhören im Meer der Ablenkung zu schwimmen und uns auf unsere wirklichen Prioritäten fokussieren.
<G-vec00113-002-s116><stop.aufhören><en> We have to stop swimming in the Sea of Distraction and focus on our real priorities.
<G-vec00113-002-s117><stop.aufhören><de> 77 Sekunden nach dem Beginn des Kampfes konnten sie nicht aufhören, über seine schnellen Hände und seine kampfentscheidende Schlagkraft zu sprechen.
<G-vec00113-002-s117><stop.aufhören><en> 77 seconds after the opening bell though, people couldn’t stop talking about his fast hands and fight-altering power.
<G-vec00113-002-s118><stop.aufhören><de> Sie können es nicht aufhören zu spielen.
<G-vec00113-002-s118><stop.aufhören><en> You can't stop playing it.
<G-vec00113-002-s119><stop.aufhören><de> Lasst ihn im Inneren herumkreisen, und lasst ihn damit nicht aufhören, bis er müde wird.
<G-vec00113-002-s119><stop.aufhören><en> Keep it circling around inside and don't let it stop until it gets tired.
<G-vec00113-002-s120><stop.aufhören><de> Wir werden alt, weil wir aufhören zu spielen.
<G-vec00113-002-s120><stop.aufhören><en> we grow old because we stop playing.
<G-vec00113-002-s121><stop.aufhören><de> Wir hoffen, dass andere Bürgermeister mit der grausamen und ineffektiven Behandlung von Streunerhunden aufhören und zu dem Beispiel übergehen, das der Stadtrat von Ploiesti für eine humane und wirksame Verwaltung von Streunerhunden eingeführt hat.
<G-vec00113-002-s121><stop.aufhören><en> We hope that other mayors will stop the cruel and ineffective management of stray dogs and will transition to the example of Ploiesti’s City Council for adopting a humane and efficient dog management.
<G-vec00113-002-s122><stop.aufhören><de> Selbst hinter der Schutzmaske werden wir nie aufhören, Sie anzulächeln und Sie mit unserer üblichen Spontanität begrüßen.
<G-vec00113-002-s122><stop.aufhören><en> Even behind the safetymask we will never stop smiling at you and will welcome you with our usual spontaneity ❤❤❤❤
<G-vec00113-002-s123><stop.aufhören><de> Jesus streckte seinen Arm aus, damit sie aufhören und Er lehnte sich sanft über den Rand des Bootes, platzierte sanft Seine Hand ins Wasser unter die Fische und brachte sie langsam und vorsichtig heraus.
<G-vec00113-002-s123><stop.aufhören><en> Jesus put His arm out for them to stop, and He gently leaned over the edge of the boat, tenderly placed His hand in the water under the fish and carefully and slowly brought them out.
<G-vec00113-002-s124><stop.aufhören><de> Mir gefällt wie die Hügel am nördlichen Ufer einfach aufhören.
<G-vec00113-002-s124><stop.aufhören><en> I like how the hills just stop at the northern bank of the river.
<G-vec00113-002-s125><stop.aufhören><de> Wenn Sie grüne feste Bananen mögen, können Sie sie so kaufen und an die Kälte senden: der Reifeprozess wird aufhören.
<G-vec00113-002-s125><stop.aufhören><en> If you like green solid bananas, you can buy them in such a way and send them to the cold: the ripening process will stop.
<G-vec00113-002-s126><stop.aufhören><de> Auf die gleiche Weise, wenn wir uns über die tierische Stufe der Natur zur Stufe des Schöpfers erheben, werden wir auch aufhören, den Verlust unseres körperlichen Lebens als wichtig und bedeutsam zu empfinden.
<G-vec00113-002-s126><stop.aufhören><en> In the same way, when we rise above the animate level of Nature to the level of the Creator, we will stop perceiving the loss of our material life as an important and meaningful event.
<G-vec00113-002-s127><stop.aufhören><de> Bevor uns Adtimize kontaktierte, hatten wir schon überlegt ob wir nicht besser mit AdWords aufhören sollten, da der generierte Umsatz nie zufriedenstellend war.
<G-vec00113-002-s127><stop.aufhören><en> Before we got contacted by Adtimize we considered to stop using Google AdWords as the generated revenue didn't correspond satisfying compared to the costs.
<G-vec00113-002-s128><stop.aufhören><de> Wir werden nicht aufhören mit unseren Appellen, bis der Tag kommt, an dem die Verfolgung geendet hat.“ Er wies darauf hin, dass die zehn Jahre andauernde brutale Verfolgung von Falun Gong-Praktizierenden durch die KPCh (Kommunistische Partei Chinas, Falun Gong nicht nur nicht auslöschte, sondern dass auch immer mehr Menschen die Wahrheit kennen und begonnen haben, Falun Gong zu praktizieren.
<G-vec00113-002-s128><stop.aufhören><en> We won't stop our appeals until the day the persecution has stopped."He pointed out that the CCP's ten-year brutal persecution of Falun Gong practitioners not only did not eradicate Falun Gong, but also, now more people understand the truth, and have started to practise Falun Gong.
<G-vec00113-002-s129><stop.aufhören><de> Wir werden nicht aufhören, Seinen Verheißungen zu glauben und werden weiterhin gemeinsam vorgehen.
<G-vec00113-002-s129><stop.aufhören><en> We will not stop believing in His promises, but will keep pressing in together.
<G-vec00113-002-s130><stop.aufhören><de> Schützt Schwulen-Dieses Blog wird vielleicht zum Aufhören gedrängt.
<G-vec00113-002-s130><stop.aufhören><en> This Blog May be Forced to Stop. 4.
<G-vec00113-002-s131><stop.aufhören><de> Vor 18 Jahren wurde ein herrliches kleines Mädchen geboren, das nicht aufhören wollte, ihre Eltern glücklich zu machen.Alles Gute zum Geburtstag.
<G-vec00113-002-s131><stop.aufhören><en> 18 years ago was born a magnificent little girl who did not stop making the happiness of her parents, happy birthday.
<G-vec00113-002-s132><stop.aufhören><de> Wenn während des Trainings hast du einen SchmerzKopf oder Brustbereich, aufhören.
<G-vec00113-002-s132><stop.aufhören><en> If during the training you are sickhead or chest area, stop.
<G-vec00113-002-s171><stop.aufhören><de> Du erkennst, dass es an der Zeit ist aufzuhören zu hoffen und darauf zu warten, dass sich etwas ändert, oder dass Glück, Sicherheit und Geborgenheit am nächsten Horizont auf magische Weise auftauchen.
<G-vec00113-002-s171><stop.aufhören><en> You realize that it’s time to stop hoping and waiting for something to change or for happiness, safety, and security to come galloping over the next horizon.
<G-vec00113-002-s172><stop.aufhören><de> Beim Eintritt in das Haus überprüfte sie ihr Mobiltelefon zum letzten Mal, hoffend, sie würde von Gott eine SMS erhalten, die sie anwies, aufzuhören, und dass er gesehen hatte, dass sie bereit war, gerade so wie er mit Abraham verfuhr.
<G-vec00113-002-s172><stop.aufhören><en> Upon entering the house, she checked her mobile phone one last time, hoping to receive a sms from God telling her to stop, and that he had seen that she was willing, just like he did with Abraham.
<G-vec00113-002-s173><stop.aufhören><de> Ich versuchte wegzuschauen, aber jedes Mal wenn ich den Versuch machte aufzuhören, stoppten sie meinen Atem, um eine verblüffende, transformierende Magie anzuwenden, die ich einfach nicht beschreiben kann und die so erstaunlich war, dass ich gehindert wurde wegzusehen.
<G-vec00113-002-s173><stop.aufhören><en> I would try to look away but each time I tried, they would stop my breath and do some amazing transformational magic which I simply can't describe and [which] was so amazing that I was prevented by awe from looking away.
<G-vec00113-002-s174><stop.aufhören><de> Bald war es Zeit mit der Arbeit für heute aufzuhören und sich auf den Heimweg zu machen.
<G-vec00113-002-s174><stop.aufhören><en> Soon it was time to stop working for today and go home.
<G-vec00113-002-s175><stop.aufhören><de> Dann wurde sie angewiesen, aufzuhören.
<G-vec00113-002-s175><stop.aufhören><en> She was then forced to stop.
<G-vec00113-002-s176><stop.aufhören><de> In der Gruppe hat man das Ziel, mit dem Trinken aufzuhören und ein Leben ohne Alkohol zu beginnen.
<G-vec00113-002-s176><stop.aufhören><en> The goal of the group is to stop drinking and start a life without alcohol.
<G-vec00113-002-s177><stop.aufhören><de> Freunde, die vor ein paar Wochen nur einmal gefragt hatten, ob sie sich ein Falun Gong-Buch ausleihen könnten, drängten nun die Praktizierenden mit der Praktik aufzuhören, um keinen Ärger zu bekommen.
<G-vec00113-002-s177><stop.aufhören><en> Friends who had only weeks earlier asked to borrow a Falun Gong book now urged practitioners to stop practising Falun Gong in order to stay out of trouble.
<G-vec00113-002-s178><stop.aufhören><de> Also um wirklich den Weg zu realisieren und aufzuhören, ihn durch unser Verhalten zu verraten, muss man diese zwei Annäherungen kombinieren: die Unbeständigkeit beobachten, die letztendliche Unhaltbarkeit des Egos und sein Nicht-Getrenntsein vom ganzen Universum, also seine Natur ohne Geburt und ohne Tod.
<G-vec00113-002-s178><stop.aufhören><en> So to truly realize the Way and stop betraying it through our behaviour, we need to combine these two approaches. Observe impermanence, observe the ultimate inconsistency of the ego, its non-separation from the whole universe – thus its nature which is without birth, without death.
<G-vec00113-002-s179><stop.aufhören><de> Wenn du eine nervöse Katze streichelst, sei darauf vorbereitet, schnell damit aufzuhören, und sei dir darüber bewusst, dass du gebissen oder gekratzt werden kannst.
<G-vec00113-002-s179><stop.aufhören><en> When petting a high strung cat, be prepared to stop petting him or her quickly, and be aware that you may get bitten or scratched.
<G-vec00113-002-s180><stop.aufhören><de> Und weil Ihr niemals an einen Schlusspunkt kommt, ist es nun an der Zeit aufzuhören, unglücklich zu sein, weil noch nicht alles erreicht ist - denn das meiste ist nicht vollendet.
<G-vec00113-002-s180><stop.aufhören><en> And since you never get it done, it's time to stop being unhappy about what's undone, because most of it is undone!
<G-vec00113-002-s181><stop.aufhören><de> Er hielt Karl oben am Arm fest, aber nicht etwa mit ruhigem Griff, der schließlich auszuhalten gewesen wäre, sondern er lokkerte hie und da den Griff und machte ihn dann mit Steigerung fester und fester, was bei seinen großen Körperkräften gar nicht aufzuhören schien und ein Dunkel vor Karls Augen verursachte.
<G-vec00113-002-s181><stop.aufhören><en> He held Karl tightly by the arm, not with a steady grip, which would have been bearable, but instead he loosened his grip here and there and gradually made it tighter and tighter, so that, with his great strength, it never seemed to stop and Karl’s vision went dark.
<G-vec00113-002-s182><stop.aufhören><de> Natürlich hat er mich ein paar Mal angebettelt aufzuhören - aber natürlich hält mich das nicht und sie verdienen eine entsprechende Pflege.
<G-vec00113-002-s182><stop.aufhören><en> Of course he begs me to stop several times - but nothing's going to stop me from having fun!
<G-vec00113-002-s183><stop.aufhören><de> Diese Schwierigkeit wäre über die ganze Kirche gekommen, und dann wären wir gezwungen worden, mit der Ausübung aufzuhören.
<G-vec00113-002-s183><stop.aufhören><en> This trouble would have come upon the whole Church, and we should have been compelled to stop the practice.
<G-vec00113-002-s184><stop.aufhören><de> Die können jetzt wieder gesprochen werden.“ Genau genommen ist der Verlust einer gemeinsamen Verständigungsbasis nicht viel mehr als der Verlust des Traums von ihr, denn es hat sie nie anders denn als Traum gegeben, weshalb von ihr zu träumen aufzuhören nicht zwingend bedeutet, mit dem Träumen aufzuhören.
<G-vec00113-002-s184><stop.aufhören><en> They can be spoken now.” The loss of a common basis for understanding and communication is, strictly speaking, not much more than the loss of the dream of it, because it never existed elsewhere than in a dream, that’s why to stop dreaming of it does not necessarily mean to stop dreaming.
<G-vec00113-002-s186><stop.aufhören><de> Als sprang ich oft auf dem Bett auf und nieder, hoch in die Luft fliegend, um es besser sehen zu können, obwohl sie mich oft ermahnte aufzuhören auf dem Bett zu springen, aus Angst dass ich herunter fallen könnte.
<G-vec00113-002-s186><stop.aufhören><en> So I often jumped up and down on the bed flying high in the air to see it better though she often admonished me to stop jumping on the bed for fear I'd fall off.
<G-vec00113-002-s187><stop.aufhören><de> Mit dem Ablauf der Testphase sind Sie verpflichtet, sämtliche Exemplare des Bitdefender-Produkts und der zugehörigen Dokumentation zu löschen oder zu vernichten und aufzuhören, die Dienstleistungen in Anspruch zu nehmen.
<G-vec00113-002-s187><stop.aufhören><en> Upon termination of the Evaluation Period, You must delete or destroy all copies of Bitdefender Product and documentation and stop using the Service.
<G-vec00113-002-s188><stop.aufhören><de> Irgendwann im Leben musst du erwachsen werden, aber du brauchst nicht aufzuhören, Spaß zu haben.
<G-vec00113-002-s188><stop.aufhören><en> At some point in your life you have to grow up but you don't have to stop having fun.
<G-vec00113-002-s189><stop.aufhören><de> Nachdem sie von der Verfolgung erfahren hatten, unterschrieben viele Zuschauer sogleich die Petition, die von der Kommunistischen Partei Chinas (KPCh) fordert, sofort mit ihren Verbrechen gegen die Menschlichkeit aufzuhören.
<G-vec00113-002-s189><stop.aufhören><en> Many spectators, after learning about the persecution, enthusiastically signed the petition demanding that the Chinese communist regime immediately stop its crimes against humanity.
<G-vec00113-002-s551><stop.aufhören><de> Wenn nur ein geringes Drehmoment benötigt wird, hört das Werkzeug auf zu schlagen und wird stattdessen die Spindel sanft antreiben.
<G-vec00113-002-s551><stop.aufhören><en> If only low torque is needed, then the tool will stop hammering and will instead smoothly drive the fastener, rapidly installing or removing it.
<G-vec00113-002-s552><stop.aufhören><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00113-002-s552><stop.aufhören><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00113-002-s553><stop.aufhören><de> Wenn man die ersten Medaillen in den Händen hält, hört man nicht auf.
<G-vec00113-002-s553><stop.aufhören><en> When you hold that first medal, you don’t stop.
<G-vec00113-002-s554><stop.aufhören><de> Das Kind sollte die Vorhersehbarkeit der Welt um sich herum fühlen, sonst wird er verwirrt und hört auf zu verstehen, was von ihm erwartet wird.
<G-vec00113-002-s554><stop.aufhören><en> The child should feel the predictability of the world around him, otherwise he will get confused and stop understanding what is expected of him.
<G-vec00113-002-s555><stop.aufhören><de> Dadurch wird die automatische Abschaltfunktion deaktiviert und die rote Anzeige hört auf zu blinken.
<G-vec00113-002-s555><stop.aufhören><en> This will deactivate the automatic shut-off function and then the red light will stop blinking.
<G-vec00113-002-s556><stop.aufhören><de> 22 Dann sprach er zu seinen Jüngern: „Deswegen sage ich euch: Hört auf, euch Sorgen zu machen um eure Seele, über das, was ihr essen werdet, oder um euren Leib, über das, was ihr anziehen werdet.+ 23 Denn die Seele ist mehr wert als die Speise und der Leib [mehr] als die Kleidung.
<G-vec00113-002-s556><stop.aufhören><en> 22 Then he said to his disciples: “That is why I say to you, stop being anxious about your lives as to what you will eat or about your bodies as to what you will wear.+ 23 For the life is worth more than food and the body more than clothing.
<G-vec00113-002-s557><stop.aufhören><de> Wenn sie für sich selbst plastische Chirurgie wollen, hört auf, euch für sie zu schämen.
<G-vec00113-002-s557><stop.aufhören><en> If they are doing plastic surgery for themselves stop shaming them for it.
<G-vec00113-002-s558><stop.aufhören><de> Es hört nie auf, wenn die Bestätigungstaste nicht gedrückt wird.
<G-vec00113-002-s558><stop.aufhören><en> It never stop unless the confirm button is depressed.
<G-vec00113-002-s559><stop.aufhören><de> Das hört nicht auf, weil er weg ist.
<G-vec00113-002-s559><stop.aufhören><en> It did not stop because he left.
<G-vec00113-002-s560><stop.aufhören><de> Empfangt von Mir!… Ja, hört auf zu sprechen, beruhigt euch selbst und bleibt in Mir.
<G-vec00113-002-s560><stop.aufhören><en> Receive of Me!… Yea, stop speaking, quiet yourselves, and abide in Me.
<G-vec00113-002-s561><stop.aufhören><de> Der Luftkompressor hört auf zu arbeiten, sobald der Druck im Reifen diese Daten erreicht.
<G-vec00113-002-s561><stop.aufhören><en> The air compressor will stop working, once the pressure in tire reaches this data.
<G-vec00113-002-s562><stop.aufhören><de> Hört auf, den Mann zu bekämpfen, der nicht wie ihr aussieht, oder die Frau, die nicht wie ihr aussieht.
<G-vec00113-002-s562><stop.aufhören><en> Stop fighting the man who doesn’t look like you, or the woman who doesn’t look like you.
<G-vec00113-002-s563><stop.aufhören><de> Hört auf, diesen Menschen entgegenzukommen.
<G-vec00113-002-s563><stop.aufhören><en> Stop accommodating those people.
<G-vec00113-002-s564><stop.aufhören><de> “Hört auf mit den Vertuschungen, zieht den toten und leblosen Programmen, die sich nur darum drehen, von den Menschen gesehen zu werden, die aber keine Substanz oder Heiligkeit vor Mir beinhalten, den Stöpsel.
<G-vec00113-002-s564><stop.aufhören><en> “Stop the cover-ups in the ranks, pull the plug on dead and lifeless programs that are all about being seen by men and have no substance or holiness before Me.
<G-vec00113-002-s565><stop.aufhören><de> Meine lieben Kinder, hört auf, die unschuldigen Babys in euren Leibern zu töten.
<G-vec00113-002-s565><stop.aufhören><en> My dear children, stop killing the innocent babies in your wombs.
<G-vec00113-002-s566><stop.aufhören><de> Im Winter hört es auf, im Sommer setzt es fort zu wachsen.
<G-vec00113-002-s566><stop.aufhören><en> They stop growing during winter and continue in summer.
<G-vec00113-002-s567><stop.aufhören><de> Ein Jedi der zum Sith wird — so was hat die Welt ja so was von noch nie gesehen… Die Politik hört auf, auch nur so zu tun als ob sie Sinn machen würde und keine der Probleme sind auf eine echt glaubwürdige Art und Weise gelöst.
<G-vec00113-002-s567><stop.aufhören><en> A Jedi turning to the dark side - Wow, the world so hasn’t seen that before… The politics stop even pretending to make any sense at all in the last third, and none of the problems are actually solved in a believable way.
<G-vec00113-002-s568><stop.aufhören><de> Mit dem Start der Produktion hört für uns der Turnkey-Gedanke nicht auf.
<G-vec00113-002-s568><stop.aufhören><en> For us, the turnkey concept does not stop with the beginning of production.
<G-vec00113-002-s569><stop.aufhören><de> Wenn der Uterus einen erhöhten Tonus hat, dann ballt er eine Faust, und der Blutverlust hört auf.
<G-vec00113-002-s569><stop.aufhören><en> If the uterus has an increased tone, then it will clench a fist, and blood loss will stop.
<G-vec00198-002-s147><abolish.aufhören><de> Weil es in der Zwischenzeit in Europa Wahlen geben wird und ich sehe, dass all jene, die für eine Vermischung des europäischen Volkes mit aus der Fremde angekommenen Menschen argumentieren, das heißt die ein Europa mit gemischter Bevölkerung wollen, die behaupten, der Weg des Fortschritts und der Entwicklung sei, dass wir jetzt aufhören Gesellschaften zu sein, die auf nationaler und christlicher Grundlage stehen, und wir stattdessen in einer vermischten multikulturellen Gesellschaften leben müssen, nun, jene, die diesen Standpunkt vertreten, werden bei den nationalen Wahlen kontinuierlich schwächer.
<G-vec00198-002-s147><abolish.aufhören><en> Because in the meantime elections are being held in Europe. I look at all those who argue for the mixing of the European people with people who have come from foreign continents: those who want Europe to have a mixed population and who claim that the path of progress and development is for us to abolish societies based on national and Christian foundations, and that we must instead live our lives in such a mixed multicultural society.
<G-vec00198-002-s018><desist.aufhören><de> Wenn sie aber aufhören, so soll es keine Gewalttätigkeit geben außer gegen diejenigen, die Unrecht tun.
<G-vec00198-002-s018><desist.aufhören><en> But if they desist, there will be no aggression except against the evildoers.
<G-vec00198-002-s019><desist.aufhören><de> 192 Wenn sie aufhören, so ist Gott voller Vergebung und barmherzig.
<G-vec00198-002-s019><desist.aufhören><en> 2:192 But if they desist, God is gracious and merciful.
<G-vec00198-002-s020><desist.aufhören><de> Dieser Angriff und dieser Spott führten nicht dazu, dass die Christen der ersten Jahrhunderte aufhörten, den Glauben an die Auferstehung zu bekennen, oder dass die frühen Theologen aufhörten, diesen Glauben auszulegen.
<G-vec00198-002-s020><desist.aufhören><en> This opposition and such ridicule did not succeed in making Christians of the first centuries desist from professing faith in the resurrection, nor did it succeed in making the earliest theologians desist from expounding it.
<G-vec00198-002-s022><desist.aufhören><de> Die Regierungsprüfer werden gezwungen aufzuhören.
<G-vec00198-002-s022><desist.aufhören><en> The government inspectors are forced to desist.
