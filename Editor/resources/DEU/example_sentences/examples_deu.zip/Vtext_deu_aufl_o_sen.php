<G-vec00301-001-s019><resolve.auflösen><de> Bis zu 2160 x 1080 Bildpunkte können mit dem Bildschirm aufgelöst werden.
<G-vec00301-001-s019><resolve.auflösen><en> The screen can resolve up to 2160 x 1080 pixels.
<G-vec00301-001-s020><resolve.auflösen><de> In vielen Fällen, der domain-name aufgelöst wird, auf eine bestehende website.
<G-vec00301-001-s020><resolve.auflösen><en> In many cases, the domain name will resolve to an existing website.
<G-vec00301-001-s021><resolve.auflösen><de> Laclau formuliert die Differenz zwischen Universalismus und Partikularismus als eine Spannung, die zu keiner der beiden Seiten hin aufgelöst werden kann.
<G-vec00301-001-s021><resolve.auflösen><en> Laclau articulates the difference between universalism and particularism as a tension that neither of the two sides can resolve.
<G-vec00301-001-s022><resolve.auflösen><de> Das liegt meistens daran, dass Ihr Rechnername nicht aufgelöst werden kann.
<G-vec00301-001-s022><resolve.auflösen><en> This is usually because your hostname will not resolve.
<G-vec00301-001-s023><resolve.auflösen><de> Die zentrale Registrierungsstelle für .XXX verlangt, dass Registrierende Mitglieder der gesponserten Community sind, damit ihre .XXX-Domains aufgelöst werden.
<G-vec00301-001-s023><resolve.auflösen><en> The central registry for .XXX requires registrants to be members of the Sponsored Community in order for their .XXX domains to resolve.
<G-vec00301-001-s024><resolve.auflösen><de> Wenn die Agentur des Auftraggebers Beschwerde nicht aufgelöst werden kann und eine alternative Unterkunft nicht innerhalb der angegebenen Frist bietet (6 Stunden), der Kunde erhält das Recht, gebuchte Unterkunft verlassen.
<G-vec00301-001-s024><resolve.auflösen><en> If the Agency does not resolve the client’s complaint and does not provide any alternative accommodation within the given period (6 hours), the client gains the right to leave the booked accommodation unit.
<G-vec00301-001-s025><resolve.auflösen><de> Wenn Sie einen <base> -Link in Ihr Dokument einfügen, werden relative URLs entsprechend der Basis-URL aufgelöst.
<G-vec00301-001-s025><resolve.auflösen><en> And, if you include a <base> link in your document, relative paths will resolve according to the base URL.
<G-vec00301-001-s026><resolve.auflösen><de> Wenn eine aktive Bedrohung nicht innerhalb von 24 Stunden nach der Erkennung aufgelöst wird, verliert sie den Status Aktiv, ist jedoch weiterhin nicht aufgelöst.
<G-vec00301-001-s026><resolve.auflösen><en> If a user does not resolve an active threat within 24 hours of its detection, it loses the Active status, but stays unresolved.
<G-vec00301-001-s027><resolve.auflösen><de> Diese Patt-Situation kann durch einen manuellen Transferflug aufgelöst werden.
<G-vec00301-001-s027><resolve.auflösen><en> You can resolve this situation by scheduling a transfer flight manually.
<G-vec00301-001-s028><resolve.auflösen><de> Sehr professionelle Agentur, schnell verfügbar und loyal (wir hatten ein Problem mit dem Kinderbett für das Baby, kam persönlich zu sehen, wenn diese aufgelöst werden konnte und wir haben extra Geld für arbeitsfreie Ursache der Fehlfunktion von der Liege).
<G-vec00301-001-s028><resolve.auflösen><en> Very professional agency, fast, available and loyal (we had a problem with the cot for the baby, came in person to see if they could resolve and we have given extra money for non-working cause the malfunction of the cot).
<G-vec00301-001-s029><resolve.auflösen><de> Citrix empfiehlt, DNS auf Ihrem Netzwerk zu konfigurieren, damit die Namen der Server, zu denen Sie eine Verbindung herstellen möchten, aufgelöst werden können.
<G-vec00301-001-s029><resolve.auflösen><en> Citrix recommends that you configure DNS (Domain Name Server) on your network to enable you to resolve the names of servers to which you want to connect.
<G-vec00301-001-s030><resolve.auflösen><de> Der XPath-Ausdruck der Einstellung muss zu einem String, der der Pfad zum Workflow der Lösung auf dem Server ist, aufgelöst werden.
<G-vec00301-001-s030><resolve.auflösen><en> The setting's XPath expression must resolve to a string that is the path to the solution's workflow on the server.
<G-vec00301-001-s031><resolve.auflösen><de> Um die Bedeutung von Raum und Zeit bei diesen Signalprozessen zu verstehen, entwickeln wir Methoden, mit denen wir die sekundären Botenstoffe in intakten Zellen bildlich darstellen undräumlich wie zeitlich aufgelöst analysierenkönnen.
<G-vec00301-001-s031><resolve.auflösen><en> To gain an insight into these dimensions, we develop methods to create images of these second messengers in intact cells, and to resolve these intracellular signals in space and in time.
<G-vec00301-001-s032><resolve.auflösen><de> In der Datei /etc/resolv.conf wird festgelegt, wo alle Namen, die nicht in /etc/hosts gefunden werden können, aufgelöst werden.
<G-vec00301-001-s032><resolve.auflösen><en> The file /etc/resolv.conf says where to resolve anything that can not be found in /etc/hosts.
<G-vec00301-001-s033><resolve.auflösen><de> Die Blase selbst kann jedoch nicht aufgelöst werden.
<G-vec00301-001-s033><resolve.auflösen><en> However, the blister itself can not resolve.
<G-vec00301-001-s034><resolve.auflösen><de> Solche Vorlage können niemals zu normalen Vorlagen aufgelöst werden (sondern bleiben benutzerdefinierte Vorlagen), da das for Konstrukt es nicht zulässt, dass StyleVision das Ziel anhand der derzeit verfügbaren Schemainformationen eindeutig aufgelöst wird.
<G-vec00301-001-s034><resolve.auflösen><en> Such templates can never resolve to normal templates (but will remain User-Defined Templates) because the for construct does not allow StyleVision to unambiguously resolve the target from only the schema information it currently has at its disposal.
<G-vec00301-001-s036><resolve.auflösen><de> Wenn IPv6-Adressen nur langsam aufgelöst werden, greift die App auf IPv4 zurück.
<G-vec00301-001-s036><resolve.auflösen><en> If IPv6 addresses are slow to resolve, the app defaults to IPv4.
<G-vec00301-001-s037><resolve.auflösen><de> Dieser Widerspruch kann durch einen neuen innovativen Weg, der innerhalb des KRAIBURG TPE Baukasten-Systems neben dem klassischen Ansatz entwickelt wurde, weitestgehend aufgelöst werden.
<G-vec00301-001-s037><resolve.auflösen><en> But the modular system has now enabled KRAIBURG TPE to resolve this contradiction almost completely by following a new, innovative approach beside the classical one.
<G-vec00301-001-s038><resolve.auflösen><de> Sie müssen den Konflikt auflösen, bevor Sie Ihre Änderungen in das Projektarchiv übergeben können.
<G-vec00301-001-s038><resolve.auflösen><en> You must resolve this conflict before committing your changes to the repository.
<G-vec00301-001-s039><resolve.auflösen><de> "Sie sind nahezu verzeichnungsfrei über den gesamten Bereich der Sensoren bis zu 4/3"" und können Pixelgrößen bis zu 2 μm auflösen."
<G-vec00301-001-s039><resolve.auflösen><en> "They are virtually distortion-free across the entire area of sensors up to 4/3"" and can resolve pixel sizes down to 2 Î1⁄4m."
<G-vec00301-001-s040><resolve.auflösen><de> Etwas von diesen wird auflösen, wenn das Pferd Zugriff auf Weide, mehr Heu, Übung, und Gesellschaft gegeben ist, aber andere werden sogar dann fortsetzen, haben eine Gewohnheit wird.
<G-vec00301-001-s040><resolve.auflösen><en> Some of these will resolve if the horse is given access to pasture, more hay, exercise, and companionship, but others will continue even then, having become a habit.
<G-vec00301-001-s041><resolve.auflösen><de> Rechts nach Links Auflösen zu Rechts nach Links Verbreitung.
<G-vec00301-001-s041><resolve.auflösen><en> Right to Left Resolve to Right to Left propagation.
<G-vec00301-001-s042><resolve.auflösen><de> 3) Dass der Zusammenhang des Reproduktionsprocesses nicht begriffen wird, wie er sich darstellt, nicht vom Standpunkt des einzelnen Kapitals, sondern von dem des Gesammtkapitals aus be- trachtet; die Schwierigkeit, wie das Produkt, worin Arbeitslohn und Mehrwerth, worin also der ganze Werth, den alle während des Jahres neu zugesetzte Arbeit geschaffen hat, sich realisirt, seinen konstanten Werththeil ersetzen, und sich noch gleichzeitig in, bloß durch die Revenuen begrenzten, Werth auflösen kann; wie ferner das in der Produktion aufgezehrte konstante Kapital stofflich und dem Werth nach durch neues ersetzt werden kann, obgleich die Gesammtsumme der neu zugesetzten Arbeit sich nur in Arbeitslohn und Mehrwerth realisirt, und in der Summe des Werths beider sich erschöpfend darstellt.
<G-vec00301-001-s042><resolve.auflösen><en> The difficulty is to explain how it Edition: current; Page: [983] is that the product, in which wages and surplus-value, in short the entire value produced by all the labor newly added during the current year, can be converted into money, can reproduce the constant part of its value and yet at the same time resolve itself into a value confined within the limits of the revenues; and how it is that the constant capital consumed in production can be replaced by the substance and value of new capital, although the total sum of the newly added labor is realized only in wages and surplus-value, and is fully represented by the sum of the values of both.
<G-vec00301-001-s043><resolve.auflösen><de> Ich hoffe auch, dass meine Stücke den Außenraum „auflösen“.
<G-vec00301-001-s043><resolve.auflösen><en> Also I try to make my pieces “resolve“ external space.
<G-vec00301-001-s044><resolve.auflösen><de> Jeder Dateiname muss seinen vollen Pfad beinhalten, da die Ziel-Applikation nicht weiß, wie sie relative Namen auflösen soll.
<G-vec00301-001-s044><resolve.auflösen><en> Each filename must include its full path, as the target application will not know how to resolve relative names.
<G-vec00301-001-s045><resolve.auflösen><de> Das Unternehmen kann den Dienst unterbrechen oder die Beziehung mit dem Nutzer sofort auflösen, wenn es eine Nutzung seines Portals oder eines der darin angebotenen Dienste als gegen diese Nutzungsbedingungen verstoßend erkennt.
<G-vec00301-001-s045><resolve.auflösen><en> The company may interrupt the service or immediately resolve the relationship with the User if it detects a use of its Portal or any of the services offered in it are contrary to these Legal Terms.
<G-vec00301-001-s046><resolve.auflösen><de> Allfreechips hat beschlossen, dass Sizzling Slots Casino nicht mehr eine sichere Casino als ist zu spielen oder konnte nicht zum Auflösen von Kunden oder Partner Fragen.
<G-vec00301-001-s046><resolve.auflösen><en> Allfreechips has decided that Sizzling Slots Casino is no longer considered a safe casino to play at or has not been able to resolve customer or affiliate issues.
<G-vec00301-001-s047><resolve.auflösen><de> Sie behauptet, diese Agenturen müssten mehr sparen und angebliche Interessenskonflikte auflösen.
<G-vec00301-001-s047><resolve.auflösen><en> She argues that they need to make more savings and resolve alleged conflicts of interest.
<G-vec00301-001-s048><resolve.auflösen><de> "Wenn der Wert yes ist (entspricht dem Standardwert), fordert Subversion den Benutzer auf, anzugeben, wie die Konflikte zu behandeln sind, wie in ""Konflikte auflösen (Änderungen anderer einarbeiten)"" beschrieben."
<G-vec00301-001-s048><resolve.auflösen><en> "If its value is yes (which is the default value), Subversion will prompt the user for how to handle conflicts in the manner demonstrated in the section called ""Resolve Conflicts (Merging Others' Changes)"" ."
<G-vec00301-001-s049><resolve.auflösen><de> Zum anderen ist das Gitter herkömmlicher Ozeanzirkulationsmodelle zu grob um interne Gezeiten auflösen zu können.
<G-vec00301-001-s049><resolve.auflösen><en> On the other hand, the grid of conventional ocean circulation models is too coarse to be able to resolve internal tides.
<G-vec00301-001-s050><resolve.auflösen><de> – Weller nennt für 1757 lediglich die Verteidigungsschrift Byngs als aus dem Englischen übersetzt, ohne indes deren fingierten Druckort London auflösen zu können.
<G-vec00301-001-s050><resolve.auflösen><en> – For 1757 Weller just mentions Byng’s written defense as being translated from English though without being able to resolve the faked place of printing London.
<G-vec00301-001-s051><resolve.auflösen><de> svn resolve — Konflikte in Dateien und Verzeichnissen der Arbeitskopie auflösen.
<G-vec00301-001-s051><resolve.auflösen><en> svn resolve — Resolve conflicts on working copy files or directories.
<G-vec00301-001-s052><resolve.auflösen><de> Hier ist das bahnbrechende Know-how, das absolut jede Verwirrung auflösen kann – aber von einer neuen Perspektive.
<G-vec00301-001-s052><resolve.auflösen><en> Here is the breakthrough technology that can resolve any and all confusions—but from a new perspective.
<G-vec00301-001-s053><resolve.auflösen><de> Die Idee zu einem solchen Mikroskop hatte Werner Heisenberg formuliert, wobei er annahm, Teilchen durch einen energieabhängigen Stoßprozess über seine Unschärfe-Relation zu lokalisieren, und damit örtlich auflösen zu können.
<G-vec00301-001-s053><resolve.auflösen><en> Werner Heisenberg came up with the idea of such a microscope which he assumed able to localize particles through an energy-dependent impact process via a blurred relationship and thereby resolve them locally.
<G-vec00301-001-s054><resolve.auflösen><de> Laravel wird es dann aus dem IoC-Container auflösen.
<G-vec00301-001-s054><resolve.auflösen><en> Laravel will then resolve it out of the IoC container.
<G-vec00301-001-s055><resolve.auflösen><de> Ein Doppelklick auf diese roten Einträge öffnet einen Konflikteditor, mit dem Sie solche Konflikte ganz einfach von Hand auflösen können.
<G-vec00301-001-s055><resolve.auflösen><en> You can double click on these lines to start the external merge tool to resolve the conflicts.
<G-vec00301-001-s056><resolve.auflösen><de> Das Auflösen von Aliassen zu deren übergeordneten Kanälen schlägt beim Importieren in ein Concert nicht mehr fehl.
<G-vec00301-001-s056><resolve.auflösen><en> Aliases no longer sometimes fail to resolve to their parent channels when imported into a Concert.
<G-vec00301-001-s072><resolve.auflösen><de> Jedoch gibt es verschiedene andere Wege, um Konflikte interaktiv aufzulösen – von denen Ihnen zwei erlauben, Änderungen selektiv zusammenzuführen und zu editieren und die restlichen, die es Ihnen erlauben, einfach eine Version der Datei auszuwählen und weiterzumachen.
<G-vec00301-001-s072><resolve.auflösen><en> However, there are several other different ways to resolve conflicts interactively—two of them allow you to selectively merge and edit changes using external editors, the rest of which allow you to simply pick a version of the file and move along.
<G-vec00301-001-s073><resolve.auflösen><de> So ist es umgekehrt wichtig, zunächst die energetische Ebene zu behandeln, um ein Symptom dauerhaft aufzulösen.
<G-vec00301-001-s073><resolve.auflösen><en> So, if you take it the other way round, it is important to treat the energetic level first in order to resolve a symptom permanently.
<G-vec00301-001-s074><resolve.auflösen><de> Um einen Pfad aufzulösen, benutzt diese Funktion virtuelle Mappings, die in ColdFusion Administrator definiert sind.
<G-vec00301-001-s074><resolve.auflösen><en> To resolve a path, this function uses virtual mappings that are defined in the ColdFusion Administrator.
<G-vec00301-001-s075><resolve.auflösen><de> Außer Ihre Arbeitskopie zu aktualisieren, so dass Sie Harrys Änderungen sehen können, markiert es auch einen Baumkonflikt, so dass Sie die Gelegenheit bekommen, die Situation abzuschätzen und entsprechend aufzulösen.
<G-vec00301-001-s075><resolve.auflösen><en> At this point, you need to run svn update . Besides bringing our working copy up to date so that you can see Harry's changes, this also flags a tree conflict so you have the opportunity to evaluate and properly resolve it.
<G-vec00301-001-s076><resolve.auflösen><de> Rekursive Abfragen werden von DNS-Servern häufig verwendet, um Remotenamen aufzulösen, die an andere DNS-Zonen und -Server delegiert werden.
<G-vec00301-001-s076><resolve.auflösen><en> Recursive queries are used frequently by DNS servers to resolve remote names that are delegated to other DNS zones and servers.
<G-vec00301-001-s077><resolve.auflösen><de> "Ich selbst habe keine ""Bauchschmerzen"" gehabt, wenn nötig, mit dem StarTravel 120/600 und meinem 7 mm- und 4 mm-Okular auf bis zu 150-fach vergrößern, um zum Beispiel Sternhaufen aufzulösen oder feine Sterne bei offenen Sternhaufen wie M 11 zu sehen."
<G-vec00301-001-s077><resolve.auflösen><en> "I myself did not have any ""headaches"" magnifying with the StarTravel 120/600 and my 7 mm and 4 mm eyepieces up to 150 times if needed, for example in order to resolve star clusters or to see fine stars in open star clusters such as M 11."
<G-vec00301-001-s078><resolve.auflösen><de> Sie sind gehalten, auch in Fällen, für welche die nachstehenden Regelungen keine konkreten Anweisungen enthalten, im Geiste der Integritätsgrundsätze der DIS zu handeln und mögliche Interessenkonflikte unter Zugrundelegung höchster Integritätsstandards aufzulösen.
<G-vec00301-001-s078><resolve.auflösen><en> They are also required to act in the spirit of the Integrity Principles even in cases for which the following provisions do not contain specific instructions, and to resolve possible conflicts of interest on the basis of the highest standards of integrity.
<G-vec00301-001-s079><resolve.auflösen><de> Deshalb ist der einzige Weg für die Praktizierenden, um all den irrationalen Hass aufzulösen, die Wahrheit zu erklären.
<G-vec00301-001-s079><resolve.auflösen><en> Thus, the only way for the practitioners to resolve all the irrational hatred is to tell people the truth.
<G-vec00301-001-s080><resolve.auflösen><de> Mit der Europäischen Union haben wir einen Weg gefunden, unsere Interessenunterschiede friedlich aufzulösen.
<G-vec00301-001-s080><resolve.auflösen><en> Through the European Union, we have found a way to resolve our differences of interest peacefully.
<G-vec00301-001-s081><resolve.auflösen><de> Falls ein Streitfall ZWISCHEN IHNEN UND UNS ergeben sich aufgrund dieser Haftungsausschlüsse und Ausschlüsse der Gewährleistung und Haftung, ODER FÜR irgendeinem anderen Grund, und weder unsere Kundenservice-Abteilung NOR GUTEN GLAUBEN Mediation ist KÖNNEN Ansprüche, Streitigkeiten oder Unklarheiten aufzulösen, wir beide STIMMEN ZU, DASS DANN solche Streitigkeit ist ausschließlich durch ein Schiedsgericht ausschließlich zwischen Ihnen und USA, deren Ergebnis die verbindlich auf irgendwelche beteiligten Vertragsparteien einander, UND JEDE ENTSCHEIDUNG AUS EINEM ZUSCHLAG Die Schiedsrichter können von jedem Gericht, zuständige Gericht hereingekommen werden beigelegt.
<G-vec00301-001-s081><resolve.auflösen><en> IF ANY DISPUTES ARISE BETWEEN YOU AND US AS A RESULT OF THESE DISCLAIMERS AND EXCLUSIONS OF WARRANTY AND LIABILITY, OR FOR ANY OTHER REASON, AND NEITHER OUR CUSTOMER SERVICE DEPARTMENT NOR GOOD FAITH MEDIATION IS ABLE TO RESOLVE ANY CLAIM, DISPUTE OR CONTROVERSY, WE BOTH AGREE THAT SUCH DISPUTE SHALL THEN BE SETTLED SOLELY BY ARBITRATION STRICTLY BETWEEN YOU AND US, THE RESULT OF WHICH SHALL BE BINDING UPON ANY PARTIES INVOLVED, AND ANY JUDGMENT UPON ANY AWARD OF THE ARBITRATORS MAY BE ENTERED BY ANY COURT HAVING COMPETENT JURISDICTION.
<G-vec00301-001-s082><resolve.auflösen><de> Um diesen Konflikt aufzulösen, muss Entwickler B zunächst herausfinden wie die konfliktbehaftete Datei Foo.c im Projektarchiv umbenannt wurde.
<G-vec00301-001-s082><resolve.auflösen><en> To resolve this conflict, Developer B has to find out to what filename the conflicted file Foo.c was renamed/moved in the repository.
<G-vec00301-001-s083><resolve.auflösen><de> Beginnend mit Subversion 1.8 erlaubt Ihnen ein internes Werkzeug zur Zusammenführung, die Auflösung bestimmter Konflikte auf einen späteren Zeitpunkt zu verlegen, andere Konflikte jedoch aufzulösen.
<G-vec00301-001-s083><resolve.auflösen><en> Beginning with Subversion 1.8, an internal file merge tool allows you to postpone conflict resolution for certain conflicts, but resolve other conflicts.
<G-vec00301-001-s084><resolve.auflösen><de> Zu versuchen die Angst aufzulösen, indem wir in der externen Welt umher laufen, und ausgedehnte Schutzsysteme erschaffen, nährt gerade die Kräfte, die die Angst erzeugen.
<G-vec00301-001-s084><resolve.auflösen><en> Trying to resolve fear by running around in the external world and creating vast systems of protection feeds the very forces that are creating the fear.
<G-vec00301-001-s085><resolve.auflösen><de> Die Rekursion wird in den meisten DNS-Konfigurationen verwendet, um Namen aufzulösen, die sich nicht innerhalb des konfigurierten DNS-Domänennamens befinden, der von den DNS-Servern und -Clients verwendet wird.
<G-vec00301-001-s085><resolve.auflösen><en> Recursion is used in most DNS configurations to resolve names that are not located within the configured DNS domain name that is used by the DNS servers and clients.
<G-vec00301-001-s086><resolve.auflösen><de> Um Onion-Adressen aufzulösen, müssen Sie noch die DNS-Einstellungen im Browser ändern.
<G-vec00301-001-s086><resolve.auflösen><en> To resolve onion addresses you will need to change the DNS settings in your browser.
<G-vec00301-001-s087><resolve.auflösen><de> DNS-Auflösungszeit: benötigte Zeit, um den Hostnamen der überwachten Website aufzulösen.
<G-vec00301-001-s087><resolve.auflösen><en> DNS resolve time - time needed to resolve the hostname of the monitored website.
<G-vec00301-001-s088><resolve.auflösen><de> Klicken Sie auf Namen überprüfen, um den Namen in seine registrierten Adressen aufzulösen.
<G-vec00301-001-s088><resolve.auflösen><en> Click Check Name to resolve the name to its registered addresses.
<G-vec00301-001-s089><resolve.auflösen><de> Die Rechner, woraus der Endpoint Client der Computer Browser Dienst abruft, müssen fähig sein, NetBIOS Namen aufzulösen.
<G-vec00301-001-s089><resolve.auflösen><en> Computers from which Endpoint Security queries the Computer Browser service must be able to resolve NetBIOS names.
<G-vec00301-001-s090><resolve.auflösen><de> Laqueur hat in beiden Punkten recht, aber natürlich war er angesichts seiner Voreingenommenheit unfähig, den Widerspruch aufzulösen, und er wandte sich von dem Thema ab.
<G-vec00301-001-s090><resolve.auflösen><en> Laqueur is right on both counts, but of course given his preconceptions he was unable to resolve the contradiction and left the subject.
<G-vec00297-002-s513><resolve.auflösen><de> Sie erkennen den Ursprung innerer Spannungen – und wissen, wo Sie ansetzen müssen, um diese aufzulösen.
<G-vec00297-002-s513><resolve.auflösen><en> You recognize the origin of inner tensions - and know where to start in order to resolve them.
<G-vec00297-002-s514><resolve.auflösen><de> Debug::pkgDepCache::AutoInstall generiert Fehlersuchmeldungen, die beschreiben, welche Pakete automatisch installiert werden, um Abhängigkeiten aufzulösen.
<G-vec00297-002-s514><resolve.auflösen><en> Debug::pkgDepCache::AutoInstall Generate debug messages describing which packages are being automatically installed to resolve dependencies.
<G-vec00297-002-s515><resolve.auflösen><de> Diese Karte muss offen auf dem Spielfeld bleiben, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00297-002-s515><resolve.auflösen><en> This card must be face-up on the field to activate and to resolve this effect.
<G-vec00297-002-s516><resolve.auflösen><de> Bei Anwendungen wird in der Regel das DNS verwendet, um einen Domainnamen in eine IP-Adresse aufzulösen.
<G-vec00297-002-s516><resolve.auflösen><en> Applications that want to resolve a domain name to an IP address typically use DNS.
<G-vec00297-002-s517><resolve.auflösen><de> Im Vergleich zu herkömmlichen Methoden sind wesentlich weniger Netzelemente erforderlich, um jede sich ausbreitende Welle aufzulösen.
<G-vec00297-002-s517><resolve.auflösen><en> It requires much fewer mesh elements to resolve each propagating wave when compared to traditional methods.
<G-vec00297-002-s518><resolve.auflösen><de> Um den Modernisierungsstau im Wärmemarkt aufzulösen, benötigen wir das gesamte zur Verfügung stehende technologische Spektrum.
<G-vec00297-002-s518><resolve.auflösen><en> To resolve the modernisation backlog in the heating market, we need the entire range of technology available.
<G-vec00297-002-s521><resolve.auflösen><de> Robo Advisory, Prozessautomatisierung und Services, die der Kunde möglichst ohne komplizierte Kontaktpunkte selbst nutzen kann, sind beispielsweise erfolgversprechende Strategien, um den Widerspruch zwischen mehr Service bei weniger Kosten aufzulösen.
<G-vec00297-002-s521><resolve.auflösen><en> Robo Advisory, process automation and services that the customer can use without complicated contact points are promising strategies to resolve the contradiction between more service at lower costs.
<G-vec00297-002-s522><resolve.auflösen><de> Um Baumkonflikte nach dem Zusammenführen aufzulösen, wird ein Dialog mit verschiedenen Optionen zum lösen des Konflikts angezeigt.
<G-vec00297-002-s522><resolve.auflösen><en> To resolve tree conflicts after a merge, a dialog is shown with various options on how to resolve the conflict:
<G-vec00297-002-s523><resolve.auflösen><de> Hinweis: Wenn Sie in Workbench einen User-Dienst für die Verwendung von Geschäftskalendern konfiguriert haben und der Dienst einer Gruppe zugewiesen ist, verwendet AEM Forms die hier angegebenen Gruppenzuordnungen, um den Kalender für die Gruppe aufzulösen.
<G-vec00297-002-s523><resolve.auflösen><en> In Workbench, if you have configured a User service to use business calendars and the service is assigned to a group, AEM forms uses the group mappings specified here to resolve the calendar for the group.
<G-vec00297-002-s524><resolve.auflösen><de> Du musst diese offene Karte kontrollieren, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00297-002-s524><resolve.auflösen><en> This card must be in the Graveyard to activate and to resolve this effect.
<G-vec00301-002-s019><resolve.auflösen><de> Oder wenn der Absender eine SMTP-Adresse mit einer Domäne eingibt, für die Exchange autoritativ ist, und die Adresse nicht in einen vorhandenen Absender aufgelöst wird.
<G-vec00301-002-s019><resolve.auflösen><en> It can also happen if the sender types an SMTP address with a domain for which Exchange is authoritative and the address doesn't resolve to an existing recipient.
<G-vec00301-002-s020><resolve.auflösen><de> Bei Datentypen ohne zusätzlich gesendeten Text wurden die Variablen nicht korrekt durch die Kamera aufgelöst.
<G-vec00301-002-s020><resolve.auflösen><en> When using one of the types without additional text, the camera did not correctly resolve the variables.
<G-vec00301-002-s021><resolve.auflösen><de> Es kann als Regel betrachtet werden, daß der Schritt von einer Molltonart zur parallelen Durtonart eine Bewegung in die ”negative”, unnatürliche Richtung darstellt, da der Leitton SI nicht aufwärts aufgelöst wird, sondern in unnatürlicher Weise abwärts nach SO.
<G-vec00301-002-s021><resolve.auflösen><en> It can be regarded as a rule that moving from a minor to a relative major means progressing in the ’negative’, unnatural direction, because the leading note (SI) does not resolve upwards, but unnaturally downwards (towards SO).
<G-vec00301-002-s022><resolve.auflösen><de> Wenn eine Regierung versucht, bestimmte Seiten zu sperren, wird eine Liste mit Domain-Namen angelegt und wenn man versucht eine der Seiten auf dieser Liste aufzurufen wird die IP zu dieser Seite nicht aufgelöst, so dass der Browser nicht auf die Seite gelangt.
<G-vec00301-002-s022><resolve.auflösen><en> If a government tries to keep you away from a site they just keep a list of domain names and if you enter one of the domains on the list in you browser the local DNS server doesn’t resolve the name so you can’t get to the site.
<G-vec00301-002-s023><resolve.auflösen><de> Ursache Die Beziehung zum verstorbenen Sims wird bei dessen Tod nicht korrekt aufgelöst.
<G-vec00301-002-s023><resolve.auflösen><en> Cause The game doesn’t resolve the relationship to the dead Sim correctly.
<G-vec00301-002-s024><resolve.auflösen><de> Benutzer können ihre Distinguished Names als Acrolinx Benutzerkennung eingeben oder Sie können Acrolinx Server so einrichten, dass der DN für jeden Benutzer auf Basis eines anderen Kennzeichners aufgelöst wird, den der jeweilige Benutzer als Acrolinx Benutzerkennung eingibt.
<G-vec00301-002-s024><resolve.auflösen><en> Users can enter their distinguished name as their Acrolinx user ID, or you can configure the Acrolinx Server to resolve the DN for each user based on another identifier that a user enters as their Acrolinx user ID.
<G-vec00301-002-s025><resolve.auflösen><de> Sie können "IP-Tools" so einstellen, dass symbolische Portnamen anstatt Portzahlen angezeigt werden, dass die IP-Adressen in Hostnamen aufgelöst werden, und dass alle Ereignisse in einer Datei gespeichert werden.
<G-vec00301-002-s025><resolve.auflösen><en> You can set up IP-Tools to display symbolic port names rather than port numbers, resolve IP addresses to host names, and record all events to a log file.
<G-vec00301-002-s026><resolve.auflösen><de> Ermitteln Sie mit der Registerkarte „Eigenschaften“, welches Sicherheitsrisiko gefunden wurde und informieren Sie sich anhand des Links zum Sicherheitsstatusbewertungs-Bericht über das Sicherheitsrisiko und wie es aufgelöst werden kann.
<G-vec00301-002-s026><resolve.auflösen><en> Use the Properties tab to determine what vulnerability was found and use the links to the Security State Assessment report to learn more about the vulnerability and how to resolve it.
<G-vec00301-002-s027><resolve.auflösen><de> Epilogue-Dateien können so bearbeitet werden, dass eine Folge von Prozeduren in einer PostScript-Datei aufgelöst wird.
<G-vec00301-002-s027><resolve.auflösen><en> Epilogue files can be edited to resolve a series of procedures in a PostScript file.
<G-vec00301-002-s028><resolve.auflösen><de> Dies ist zwar eine effektive kurzfristige Lösung, da die größte Überlastung in den Kanälen zwischen der Vermittlung und dem ISP POP auftritt, es wird jedoch nicht die Überlastung in der Vermittlung selbst aufgelöst, und deshalb kann es weiterhin erforderlich sein, daß der Ortsanschlußnetzanbieter weitere Vermittlungen und Kommunikationskanäle verwendet.
<G-vec00301-002-s028><resolve.auflösen><en> While this is an effective short term solution because the greatest congestion will occur at the channels between the Switch and the ISP POP, it does not resolve the congestion in the Switch itself and therefore may still require that the local access network provider deploy more switches and communication channels.
<G-vec00301-002-s029><resolve.auflösen><de> Also beispielsweise dessen IP-Adresse, den Hostnamen, das Land, in dem der Server steht sowie die Adresse des DNS-Servers, der den Domainnamen aufgelöst hat.
<G-vec00301-002-s029><resolve.auflösen><en> So, for example, its IP address, the host name, the country in which the Server is located and the address of the DNS server that resolve the domain name.
<G-vec00389-002-s031><destroy.auflösen><de> Ihr sollt nicht meinen, das ich gekommen sei, um das Gesetz oder die Propheten aufzulösen.
<G-vec00389-002-s031><destroy.auflösen><en> “Do not think that I came to destroy the law or the prophets.
<G-vec00389-002-s032><destroy.auflösen><de> In der Bergpredigt sagt er: „Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s032><destroy.auflösen><en> In his sermon on the mount he declared: "Think not that I am come to destroy the law or the prophets; I am not come to destroy, but to fulfill.
<G-vec00389-002-s034><destroy.auflösen><de> Ihr sollt nicht meinen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s034><destroy.auflösen><en> Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil.
<G-vec00389-002-s036><destroy.auflösen><de> 17 Meint nicht, daß ich gekommen sei, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s036><destroy.auflösen><en> 17 Don't think that I came to destroy the law or the prophets. I didn't come to destroy, but to fulfill.
<G-vec00389-002-s038><destroy.auflösen><de> Ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s038><destroy.auflösen><en> I am not come to destroy, but to fulfil.
<G-vec00389-002-s039><destroy.auflösen><de> Diese Karte muss offen auf dem Spielfeld liegen, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00389-002-s039><destroy.auflösen><en> ●WATER: Select 1 Spell/Trap Card on the field, and destroy it.
<G-vec00389-002-s040><destroy.auflösen><de> Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s040><destroy.auflösen><en> Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfill.
<G-vec00389-002-s042><destroy.auflösen><de> „17 Ihr sollt nicht meinen, dass ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s042><destroy.auflösen><en> ”17 Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil.
<G-vec00389-002-s044><destroy.auflösen><de> Bis Himmel und Erde vergehen... Dann wies mich der Mann auf einen Text hin: "Ihr sollt nicht meinen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s044><destroy.auflösen><en> I am not come to destroy, but to fulfill. For verily I say unto you, till heaven and earth pass, one jot or one tittle shall in no wise pass from the law, till all be fulfilled.”
<G-vec00389-002-s045><destroy.auflösen><de> 5:16 Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s045><destroy.auflösen><en> 5.17 Ne Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfill.
<G-vec00389-002-s008><liquidate.auflösen><de> Trotz des finanziellen Risikos beginne ich daher nun den Fonds aufzulösen und hoffe, den möglichen Fehlbetrag über eine freiwillige solidarische Lösung ausgleichen zu können.
<G-vec00389-002-s008><liquidate.auflösen><en> Despite the financial risk, therefore, I am now beginning to liquidate the fund and hope to be able to make up the possible shortfall by means of a voluntary solution based on solidarity.
