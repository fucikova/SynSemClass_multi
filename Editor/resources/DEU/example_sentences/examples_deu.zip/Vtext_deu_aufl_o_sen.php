<G-vec00301-001-s019><resolve.auflösen><de> Bis zu 2160 x 1080 Bildpunkte können mit dem Bildschirm aufgelöst werden.
<G-vec00301-001-s019><resolve.auflösen><en> The screen can resolve up to 2160 x 1080 pixels.
<G-vec00301-001-s020><resolve.auflösen><de> In vielen Fällen, der domain-name aufgelöst wird, auf eine bestehende website.
<G-vec00301-001-s020><resolve.auflösen><en> In many cases, the domain name will resolve to an existing website.
<G-vec00301-001-s021><resolve.auflösen><de> Laclau formuliert die Differenz zwischen Universalismus und Partikularismus als eine Spannung, die zu keiner der beiden Seiten hin aufgelöst werden kann.
<G-vec00301-001-s021><resolve.auflösen><en> Laclau articulates the difference between universalism and particularism as a tension that neither of the two sides can resolve.
<G-vec00301-001-s022><resolve.auflösen><de> Das liegt meistens daran, dass Ihr Rechnername nicht aufgelöst werden kann.
<G-vec00301-001-s022><resolve.auflösen><en> This is usually because your hostname will not resolve.
<G-vec00301-001-s023><resolve.auflösen><de> Die zentrale Registrierungsstelle für .XXX verlangt, dass Registrierende Mitglieder der gesponserten Community sind, damit ihre .XXX-Domains aufgelöst werden.
<G-vec00301-001-s023><resolve.auflösen><en> The central registry for .XXX requires registrants to be members of the Sponsored Community in order for their .XXX domains to resolve.
<G-vec00301-001-s024><resolve.auflösen><de> Wenn die Agentur des Auftraggebers Beschwerde nicht aufgelöst werden kann und eine alternative Unterkunft nicht innerhalb der angegebenen Frist bietet (6 Stunden), der Kunde erhält das Recht, gebuchte Unterkunft verlassen.
<G-vec00301-001-s024><resolve.auflösen><en> If the Agency does not resolve the client’s complaint and does not provide any alternative accommodation within the given period (6 hours), the client gains the right to leave the booked accommodation unit.
<G-vec00301-001-s025><resolve.auflösen><de> Wenn Sie einen <base> -Link in Ihr Dokument einfügen, werden relative URLs entsprechend der Basis-URL aufgelöst.
<G-vec00301-001-s025><resolve.auflösen><en> And, if you include a <base> link in your document, relative paths will resolve according to the base URL.
<G-vec00301-001-s026><resolve.auflösen><de> Wenn eine aktive Bedrohung nicht innerhalb von 24 Stunden nach der Erkennung aufgelöst wird, verliert sie den Status Aktiv, ist jedoch weiterhin nicht aufgelöst.
<G-vec00301-001-s026><resolve.auflösen><en> If a user does not resolve an active threat within 24 hours of its detection, it loses the Active status, but stays unresolved.
<G-vec00301-001-s027><resolve.auflösen><de> Diese Patt-Situation kann durch einen manuellen Transferflug aufgelöst werden.
<G-vec00301-001-s027><resolve.auflösen><en> You can resolve this situation by scheduling a transfer flight manually.
<G-vec00301-001-s028><resolve.auflösen><de> Sehr professionelle Agentur, schnell verfügbar und loyal (wir hatten ein Problem mit dem Kinderbett für das Baby, kam persönlich zu sehen, wenn diese aufgelöst werden konnte und wir haben extra Geld für arbeitsfreie Ursache der Fehlfunktion von der Liege).
<G-vec00301-001-s028><resolve.auflösen><en> Very professional agency, fast, available and loyal (we had a problem with the cot for the baby, came in person to see if they could resolve and we have given extra money for non-working cause the malfunction of the cot).
<G-vec00301-001-s029><resolve.auflösen><de> Citrix empfiehlt, DNS auf Ihrem Netzwerk zu konfigurieren, damit die Namen der Server, zu denen Sie eine Verbindung herstellen möchten, aufgelöst werden können.
<G-vec00301-001-s029><resolve.auflösen><en> Citrix recommends that you configure DNS (Domain Name Server) on your network to enable you to resolve the names of servers to which you want to connect.
<G-vec00301-001-s030><resolve.auflösen><de> Der XPath-Ausdruck der Einstellung muss zu einem String, der der Pfad zum Workflow der Lösung auf dem Server ist, aufgelöst werden.
<G-vec00301-001-s030><resolve.auflösen><en> The setting's XPath expression must resolve to a string that is the path to the solution's workflow on the server.
<G-vec00301-001-s031><resolve.auflösen><de> Um die Bedeutung von Raum und Zeit bei diesen Signalprozessen zu verstehen, entwickeln wir Methoden, mit denen wir die sekundären Botenstoffe in intakten Zellen bildlich darstellen undräumlich wie zeitlich aufgelöst analysierenkönnen.
<G-vec00301-001-s031><resolve.auflösen><en> To gain an insight into these dimensions, we develop methods to create images of these second messengers in intact cells, and to resolve these intracellular signals in space and in time.
<G-vec00301-001-s032><resolve.auflösen><de> In der Datei /etc/resolv.conf wird festgelegt, wo alle Namen, die nicht in /etc/hosts gefunden werden können, aufgelöst werden.
<G-vec00301-001-s032><resolve.auflösen><en> The file /etc/resolv.conf says where to resolve anything that can not be found in /etc/hosts.
<G-vec00301-001-s033><resolve.auflösen><de> Die Blase selbst kann jedoch nicht aufgelöst werden.
<G-vec00301-001-s033><resolve.auflösen><en> However, the blister itself can not resolve.
<G-vec00301-001-s034><resolve.auflösen><de> Solche Vorlage können niemals zu normalen Vorlagen aufgelöst werden (sondern bleiben benutzerdefinierte Vorlagen), da das for Konstrukt es nicht zulässt, dass StyleVision das Ziel anhand der derzeit verfügbaren Schemainformationen eindeutig aufgelöst wird.
<G-vec00301-001-s034><resolve.auflösen><en> Such templates can never resolve to normal templates (but will remain User-Defined Templates) because the for construct does not allow StyleVision to unambiguously resolve the target from only the schema information it currently has at its disposal.
<G-vec00301-001-s036><resolve.auflösen><de> Wenn IPv6-Adressen nur langsam aufgelöst werden, greift die App auf IPv4 zurück.
<G-vec00301-001-s036><resolve.auflösen><en> If IPv6 addresses are slow to resolve, the app defaults to IPv4.
<G-vec00301-001-s037><resolve.auflösen><de> Dieser Widerspruch kann durch einen neuen innovativen Weg, der innerhalb des KRAIBURG TPE Baukasten-Systems neben dem klassischen Ansatz entwickelt wurde, weitestgehend aufgelöst werden.
<G-vec00301-001-s037><resolve.auflösen><en> But the modular system has now enabled KRAIBURG TPE to resolve this contradiction almost completely by following a new, innovative approach beside the classical one.
<G-vec00301-001-s038><resolve.auflösen><de> Sie müssen den Konflikt auflösen, bevor Sie Ihre Änderungen in das Projektarchiv übergeben können.
<G-vec00301-001-s038><resolve.auflösen><en> You must resolve this conflict before committing your changes to the repository.
<G-vec00301-001-s039><resolve.auflösen><de> "Sie sind nahezu verzeichnungsfrei über den gesamten Bereich der Sensoren bis zu 4/3"" und können Pixelgrößen bis zu 2 μm auflösen."
<G-vec00301-001-s039><resolve.auflösen><en> "They are virtually distortion-free across the entire area of sensors up to 4/3"" and can resolve pixel sizes down to 2 Î1⁄4m."
<G-vec00301-001-s040><resolve.auflösen><de> Etwas von diesen wird auflösen, wenn das Pferd Zugriff auf Weide, mehr Heu, Übung, und Gesellschaft gegeben ist, aber andere werden sogar dann fortsetzen, haben eine Gewohnheit wird.
<G-vec00301-001-s040><resolve.auflösen><en> Some of these will resolve if the horse is given access to pasture, more hay, exercise, and companionship, but others will continue even then, having become a habit.
<G-vec00301-001-s041><resolve.auflösen><de> Rechts nach Links Auflösen zu Rechts nach Links Verbreitung.
<G-vec00301-001-s041><resolve.auflösen><en> Right to Left Resolve to Right to Left propagation.
<G-vec00301-001-s042><resolve.auflösen><de> 3) Dass der Zusammenhang des Reproduktionsprocesses nicht begriffen wird, wie er sich darstellt, nicht vom Standpunkt des einzelnen Kapitals, sondern von dem des Gesammtkapitals aus be- trachtet; die Schwierigkeit, wie das Produkt, worin Arbeitslohn und Mehrwerth, worin also der ganze Werth, den alle während des Jahres neu zugesetzte Arbeit geschaffen hat, sich realisirt, seinen konstanten Werththeil ersetzen, und sich noch gleichzeitig in, bloß durch die Revenuen begrenzten, Werth auflösen kann; wie ferner das in der Produktion aufgezehrte konstante Kapital stofflich und dem Werth nach durch neues ersetzt werden kann, obgleich die Gesammtsumme der neu zugesetzten Arbeit sich nur in Arbeitslohn und Mehrwerth realisirt, und in der Summe des Werths beider sich erschöpfend darstellt.
<G-vec00301-001-s042><resolve.auflösen><en> The difficulty is to explain how it Edition: current; Page: [983] is that the product, in which wages and surplus-value, in short the entire value produced by all the labor newly added during the current year, can be converted into money, can reproduce the constant part of its value and yet at the same time resolve itself into a value confined within the limits of the revenues; and how it is that the constant capital consumed in production can be replaced by the substance and value of new capital, although the total sum of the newly added labor is realized only in wages and surplus-value, and is fully represented by the sum of the values of both.
<G-vec00301-001-s043><resolve.auflösen><de> Ich hoffe auch, dass meine Stücke den Außenraum „auflösen“.
<G-vec00301-001-s043><resolve.auflösen><en> Also I try to make my pieces “resolve“ external space.
<G-vec00301-001-s044><resolve.auflösen><de> Jeder Dateiname muss seinen vollen Pfad beinhalten, da die Ziel-Applikation nicht weiß, wie sie relative Namen auflösen soll.
<G-vec00301-001-s044><resolve.auflösen><en> Each filename must include its full path, as the target application will not know how to resolve relative names.
<G-vec00301-001-s045><resolve.auflösen><de> Das Unternehmen kann den Dienst unterbrechen oder die Beziehung mit dem Nutzer sofort auflösen, wenn es eine Nutzung seines Portals oder eines der darin angebotenen Dienste als gegen diese Nutzungsbedingungen verstoßend erkennt.
<G-vec00301-001-s045><resolve.auflösen><en> The company may interrupt the service or immediately resolve the relationship with the User if it detects a use of its Portal or any of the services offered in it are contrary to these Legal Terms.
<G-vec00301-001-s046><resolve.auflösen><de> Allfreechips hat beschlossen, dass Sizzling Slots Casino nicht mehr eine sichere Casino als ist zu spielen oder konnte nicht zum Auflösen von Kunden oder Partner Fragen.
<G-vec00301-001-s046><resolve.auflösen><en> Allfreechips has decided that Sizzling Slots Casino is no longer considered a safe casino to play at or has not been able to resolve customer or affiliate issues.
<G-vec00301-001-s047><resolve.auflösen><de> Sie behauptet, diese Agenturen müssten mehr sparen und angebliche Interessenskonflikte auflösen.
<G-vec00301-001-s047><resolve.auflösen><en> She argues that they need to make more savings and resolve alleged conflicts of interest.
<G-vec00301-001-s048><resolve.auflösen><de> "Wenn der Wert yes ist (entspricht dem Standardwert), fordert Subversion den Benutzer auf, anzugeben, wie die Konflikte zu behandeln sind, wie in ""Konflikte auflösen (Änderungen anderer einarbeiten)"" beschrieben."
<G-vec00301-001-s048><resolve.auflösen><en> "If its value is yes (which is the default value), Subversion will prompt the user for how to handle conflicts in the manner demonstrated in the section called ""Resolve Conflicts (Merging Others' Changes)"" ."
<G-vec00301-001-s049><resolve.auflösen><de> Zum anderen ist das Gitter herkömmlicher Ozeanzirkulationsmodelle zu grob um interne Gezeiten auflösen zu können.
<G-vec00301-001-s049><resolve.auflösen><en> On the other hand, the grid of conventional ocean circulation models is too coarse to be able to resolve internal tides.
<G-vec00301-001-s050><resolve.auflösen><de> – Weller nennt für 1757 lediglich die Verteidigungsschrift Byngs als aus dem Englischen übersetzt, ohne indes deren fingierten Druckort London auflösen zu können.
<G-vec00301-001-s050><resolve.auflösen><en> – For 1757 Weller just mentions Byng’s written defense as being translated from English though without being able to resolve the faked place of printing London.
<G-vec00301-001-s051><resolve.auflösen><de> svn resolve — Konflikte in Dateien und Verzeichnissen der Arbeitskopie auflösen.
<G-vec00301-001-s051><resolve.auflösen><en> svn resolve — Resolve conflicts on working copy files or directories.
<G-vec00301-001-s052><resolve.auflösen><de> Hier ist das bahnbrechende Know-how, das absolut jede Verwirrung auflösen kann – aber von einer neuen Perspektive.
<G-vec00301-001-s052><resolve.auflösen><en> Here is the breakthrough technology that can resolve any and all confusions—but from a new perspective.
<G-vec00301-001-s053><resolve.auflösen><de> Die Idee zu einem solchen Mikroskop hatte Werner Heisenberg formuliert, wobei er annahm, Teilchen durch einen energieabhängigen Stoßprozess über seine Unschärfe-Relation zu lokalisieren, und damit örtlich auflösen zu können.
<G-vec00301-001-s053><resolve.auflösen><en> Werner Heisenberg came up with the idea of such a microscope which he assumed able to localize particles through an energy-dependent impact process via a blurred relationship and thereby resolve them locally.
<G-vec00301-001-s054><resolve.auflösen><de> Laravel wird es dann aus dem IoC-Container auflösen.
<G-vec00301-001-s054><resolve.auflösen><en> Laravel will then resolve it out of the IoC container.
<G-vec00301-001-s055><resolve.auflösen><de> Ein Doppelklick auf diese roten Einträge öffnet einen Konflikteditor, mit dem Sie solche Konflikte ganz einfach von Hand auflösen können.
<G-vec00301-001-s055><resolve.auflösen><en> You can double click on these lines to start the external merge tool to resolve the conflicts.
<G-vec00301-001-s056><resolve.auflösen><de> Das Auflösen von Aliassen zu deren übergeordneten Kanälen schlägt beim Importieren in ein Concert nicht mehr fehl.
<G-vec00301-001-s056><resolve.auflösen><en> Aliases no longer sometimes fail to resolve to their parent channels when imported into a Concert.
<G-vec00301-001-s072><resolve.auflösen><de> Jedoch gibt es verschiedene andere Wege, um Konflikte interaktiv aufzulösen – von denen Ihnen zwei erlauben, Änderungen selektiv zusammenzuführen und zu editieren und die restlichen, die es Ihnen erlauben, einfach eine Version der Datei auszuwählen und weiterzumachen.
<G-vec00301-001-s072><resolve.auflösen><en> However, there are several other different ways to resolve conflicts interactively—two of them allow you to selectively merge and edit changes using external editors, the rest of which allow you to simply pick a version of the file and move along.
<G-vec00301-001-s073><resolve.auflösen><de> So ist es umgekehrt wichtig, zunächst die energetische Ebene zu behandeln, um ein Symptom dauerhaft aufzulösen.
<G-vec00301-001-s073><resolve.auflösen><en> So, if you take it the other way round, it is important to treat the energetic level first in order to resolve a symptom permanently.
<G-vec00301-001-s074><resolve.auflösen><de> Um einen Pfad aufzulösen, benutzt diese Funktion virtuelle Mappings, die in ColdFusion Administrator definiert sind.
<G-vec00301-001-s074><resolve.auflösen><en> To resolve a path, this function uses virtual mappings that are defined in the ColdFusion Administrator.
<G-vec00301-001-s075><resolve.auflösen><de> Außer Ihre Arbeitskopie zu aktualisieren, so dass Sie Harrys Änderungen sehen können, markiert es auch einen Baumkonflikt, so dass Sie die Gelegenheit bekommen, die Situation abzuschätzen und entsprechend aufzulösen.
<G-vec00301-001-s075><resolve.auflösen><en> At this point, you need to run svn update . Besides bringing our working copy up to date so that you can see Harry's changes, this also flags a tree conflict so you have the opportunity to evaluate and properly resolve it.
<G-vec00301-001-s076><resolve.auflösen><de> Rekursive Abfragen werden von DNS-Servern häufig verwendet, um Remotenamen aufzulösen, die an andere DNS-Zonen und -Server delegiert werden.
<G-vec00301-001-s076><resolve.auflösen><en> Recursive queries are used frequently by DNS servers to resolve remote names that are delegated to other DNS zones and servers.
<G-vec00301-001-s077><resolve.auflösen><de> "Ich selbst habe keine ""Bauchschmerzen"" gehabt, wenn nötig, mit dem StarTravel 120/600 und meinem 7 mm- und 4 mm-Okular auf bis zu 150-fach vergrößern, um zum Beispiel Sternhaufen aufzulösen oder feine Sterne bei offenen Sternhaufen wie M 11 zu sehen."
<G-vec00301-001-s077><resolve.auflösen><en> "I myself did not have any ""headaches"" magnifying with the StarTravel 120/600 and my 7 mm and 4 mm eyepieces up to 150 times if needed, for example in order to resolve star clusters or to see fine stars in open star clusters such as M 11."
<G-vec00301-001-s078><resolve.auflösen><de> Sie sind gehalten, auch in Fällen, für welche die nachstehenden Regelungen keine konkreten Anweisungen enthalten, im Geiste der Integritätsgrundsätze der DIS zu handeln und mögliche Interessenkonflikte unter Zugrundelegung höchster Integritätsstandards aufzulösen.
<G-vec00301-001-s078><resolve.auflösen><en> They are also required to act in the spirit of the Integrity Principles even in cases for which the following provisions do not contain specific instructions, and to resolve possible conflicts of interest on the basis of the highest standards of integrity.
<G-vec00301-001-s079><resolve.auflösen><de> Deshalb ist der einzige Weg für die Praktizierenden, um all den irrationalen Hass aufzulösen, die Wahrheit zu erklären.
<G-vec00301-001-s079><resolve.auflösen><en> Thus, the only way for the practitioners to resolve all the irrational hatred is to tell people the truth.
<G-vec00301-001-s080><resolve.auflösen><de> Mit der Europäischen Union haben wir einen Weg gefunden, unsere Interessenunterschiede friedlich aufzulösen.
<G-vec00301-001-s080><resolve.auflösen><en> Through the European Union, we have found a way to resolve our differences of interest peacefully.
<G-vec00301-001-s081><resolve.auflösen><de> Falls ein Streitfall ZWISCHEN IHNEN UND UNS ergeben sich aufgrund dieser Haftungsausschlüsse und Ausschlüsse der Gewährleistung und Haftung, ODER FÜR irgendeinem anderen Grund, und weder unsere Kundenservice-Abteilung NOR GUTEN GLAUBEN Mediation ist KÖNNEN Ansprüche, Streitigkeiten oder Unklarheiten aufzulösen, wir beide STIMMEN ZU, DASS DANN solche Streitigkeit ist ausschließlich durch ein Schiedsgericht ausschließlich zwischen Ihnen und USA, deren Ergebnis die verbindlich auf irgendwelche beteiligten Vertragsparteien einander, UND JEDE ENTSCHEIDUNG AUS EINEM ZUSCHLAG Die Schiedsrichter können von jedem Gericht, zuständige Gericht hereingekommen werden beigelegt.
<G-vec00301-001-s081><resolve.auflösen><en> IF ANY DISPUTES ARISE BETWEEN YOU AND US AS A RESULT OF THESE DISCLAIMERS AND EXCLUSIONS OF WARRANTY AND LIABILITY, OR FOR ANY OTHER REASON, AND NEITHER OUR CUSTOMER SERVICE DEPARTMENT NOR GOOD FAITH MEDIATION IS ABLE TO RESOLVE ANY CLAIM, DISPUTE OR CONTROVERSY, WE BOTH AGREE THAT SUCH DISPUTE SHALL THEN BE SETTLED SOLELY BY ARBITRATION STRICTLY BETWEEN YOU AND US, THE RESULT OF WHICH SHALL BE BINDING UPON ANY PARTIES INVOLVED, AND ANY JUDGMENT UPON ANY AWARD OF THE ARBITRATORS MAY BE ENTERED BY ANY COURT HAVING COMPETENT JURISDICTION.
<G-vec00301-001-s082><resolve.auflösen><de> Um diesen Konflikt aufzulösen, muss Entwickler B zunächst herausfinden wie die konfliktbehaftete Datei Foo.c im Projektarchiv umbenannt wurde.
<G-vec00301-001-s082><resolve.auflösen><en> To resolve this conflict, Developer B has to find out to what filename the conflicted file Foo.c was renamed/moved in the repository.
<G-vec00301-001-s083><resolve.auflösen><de> Beginnend mit Subversion 1.8 erlaubt Ihnen ein internes Werkzeug zur Zusammenführung, die Auflösung bestimmter Konflikte auf einen späteren Zeitpunkt zu verlegen, andere Konflikte jedoch aufzulösen.
<G-vec00301-001-s083><resolve.auflösen><en> Beginning with Subversion 1.8, an internal file merge tool allows you to postpone conflict resolution for certain conflicts, but resolve other conflicts.
<G-vec00301-001-s084><resolve.auflösen><de> Zu versuchen die Angst aufzulösen, indem wir in der externen Welt umher laufen, und ausgedehnte Schutzsysteme erschaffen, nährt gerade die Kräfte, die die Angst erzeugen.
<G-vec00301-001-s084><resolve.auflösen><en> Trying to resolve fear by running around in the external world and creating vast systems of protection feeds the very forces that are creating the fear.
<G-vec00301-001-s085><resolve.auflösen><de> Die Rekursion wird in den meisten DNS-Konfigurationen verwendet, um Namen aufzulösen, die sich nicht innerhalb des konfigurierten DNS-Domänennamens befinden, der von den DNS-Servern und -Clients verwendet wird.
<G-vec00301-001-s085><resolve.auflösen><en> Recursion is used in most DNS configurations to resolve names that are not located within the configured DNS domain name that is used by the DNS servers and clients.
<G-vec00301-001-s086><resolve.auflösen><de> Um Onion-Adressen aufzulösen, müssen Sie noch die DNS-Einstellungen im Browser ändern.
<G-vec00301-001-s086><resolve.auflösen><en> To resolve onion addresses you will need to change the DNS settings in your browser.
<G-vec00301-001-s087><resolve.auflösen><de> DNS-Auflösungszeit: benötigte Zeit, um den Hostnamen der überwachten Website aufzulösen.
<G-vec00301-001-s087><resolve.auflösen><en> DNS resolve time - time needed to resolve the hostname of the monitored website.
<G-vec00301-001-s088><resolve.auflösen><de> Klicken Sie auf Namen überprüfen, um den Namen in seine registrierten Adressen aufzulösen.
<G-vec00301-001-s088><resolve.auflösen><en> Click Check Name to resolve the name to its registered addresses.
<G-vec00301-001-s089><resolve.auflösen><de> Die Rechner, woraus der Endpoint Client der Computer Browser Dienst abruft, müssen fähig sein, NetBIOS Namen aufzulösen.
<G-vec00301-001-s089><resolve.auflösen><en> Computers from which Endpoint Security queries the Computer Browser service must be able to resolve NetBIOS names.
<G-vec00301-001-s090><resolve.auflösen><de> Laqueur hat in beiden Punkten recht, aber natürlich war er angesichts seiner Voreingenommenheit unfähig, den Widerspruch aufzulösen, und er wandte sich von dem Thema ab.
<G-vec00301-001-s090><resolve.auflösen><en> Laqueur is right on both counts, but of course given his preconceptions he was unable to resolve the contradiction and left the subject.
<G-vec00297-002-s513><resolve.auflösen><de> Sie erkennen den Ursprung innerer Spannungen – und wissen, wo Sie ansetzen müssen, um diese aufzulösen.
<G-vec00297-002-s513><resolve.auflösen><en> You recognize the origin of inner tensions - and know where to start in order to resolve them.
<G-vec00297-002-s514><resolve.auflösen><de> Debug::pkgDepCache::AutoInstall generiert Fehlersuchmeldungen, die beschreiben, welche Pakete automatisch installiert werden, um Abhängigkeiten aufzulösen.
<G-vec00297-002-s514><resolve.auflösen><en> Debug::pkgDepCache::AutoInstall Generate debug messages describing which packages are being automatically installed to resolve dependencies.
<G-vec00297-002-s515><resolve.auflösen><de> Diese Karte muss offen auf dem Spielfeld bleiben, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00297-002-s515><resolve.auflösen><en> This card must be face-up on the field to activate and to resolve this effect.
<G-vec00297-002-s516><resolve.auflösen><de> Bei Anwendungen wird in der Regel das DNS verwendet, um einen Domainnamen in eine IP-Adresse aufzulösen.
<G-vec00297-002-s516><resolve.auflösen><en> Applications that want to resolve a domain name to an IP address typically use DNS.
<G-vec00297-002-s517><resolve.auflösen><de> Im Vergleich zu herkömmlichen Methoden sind wesentlich weniger Netzelemente erforderlich, um jede sich ausbreitende Welle aufzulösen.
<G-vec00297-002-s517><resolve.auflösen><en> It requires much fewer mesh elements to resolve each propagating wave when compared to traditional methods.
<G-vec00297-002-s518><resolve.auflösen><de> Um den Modernisierungsstau im Wärmemarkt aufzulösen, benötigen wir das gesamte zur Verfügung stehende technologische Spektrum.
<G-vec00297-002-s518><resolve.auflösen><en> To resolve the modernisation backlog in the heating market, we need the entire range of technology available.
<G-vec00297-002-s521><resolve.auflösen><de> Robo Advisory, Prozessautomatisierung und Services, die der Kunde möglichst ohne komplizierte Kontaktpunkte selbst nutzen kann, sind beispielsweise erfolgversprechende Strategien, um den Widerspruch zwischen mehr Service bei weniger Kosten aufzulösen.
<G-vec00297-002-s521><resolve.auflösen><en> Robo Advisory, process automation and services that the customer can use without complicated contact points are promising strategies to resolve the contradiction between more service at lower costs.
<G-vec00297-002-s522><resolve.auflösen><de> Um Baumkonflikte nach dem Zusammenführen aufzulösen, wird ein Dialog mit verschiedenen Optionen zum lösen des Konflikts angezeigt.
<G-vec00297-002-s522><resolve.auflösen><en> To resolve tree conflicts after a merge, a dialog is shown with various options on how to resolve the conflict:
<G-vec00297-002-s523><resolve.auflösen><de> Hinweis: Wenn Sie in Workbench einen User-Dienst für die Verwendung von Geschäftskalendern konfiguriert haben und der Dienst einer Gruppe zugewiesen ist, verwendet AEM Forms die hier angegebenen Gruppenzuordnungen, um den Kalender für die Gruppe aufzulösen.
<G-vec00297-002-s523><resolve.auflösen><en> In Workbench, if you have configured a User service to use business calendars and the service is assigned to a group, AEM forms uses the group mappings specified here to resolve the calendar for the group.
<G-vec00297-002-s524><resolve.auflösen><de> Du musst diese offene Karte kontrollieren, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00297-002-s524><resolve.auflösen><en> This card must be in the Graveyard to activate and to resolve this effect.
<G-vec00301-002-s019><resolve.auflösen><de> Oder wenn der Absender eine SMTP-Adresse mit einer Domäne eingibt, für die Exchange autoritativ ist, und die Adresse nicht in einen vorhandenen Absender aufgelöst wird.
<G-vec00301-002-s019><resolve.auflösen><en> It can also happen if the sender types an SMTP address with a domain for which Exchange is authoritative and the address doesn't resolve to an existing recipient.
<G-vec00301-002-s020><resolve.auflösen><de> Bei Datentypen ohne zusätzlich gesendeten Text wurden die Variablen nicht korrekt durch die Kamera aufgelöst.
<G-vec00301-002-s020><resolve.auflösen><en> When using one of the types without additional text, the camera did not correctly resolve the variables.
<G-vec00301-002-s021><resolve.auflösen><de> Es kann als Regel betrachtet werden, daß der Schritt von einer Molltonart zur parallelen Durtonart eine Bewegung in die ”negative”, unnatürliche Richtung darstellt, da der Leitton SI nicht aufwärts aufgelöst wird, sondern in unnatürlicher Weise abwärts nach SO.
<G-vec00301-002-s021><resolve.auflösen><en> It can be regarded as a rule that moving from a minor to a relative major means progressing in the ’negative’, unnatural direction, because the leading note (SI) does not resolve upwards, but unnaturally downwards (towards SO).
<G-vec00301-002-s022><resolve.auflösen><de> Wenn eine Regierung versucht, bestimmte Seiten zu sperren, wird eine Liste mit Domain-Namen angelegt und wenn man versucht eine der Seiten auf dieser Liste aufzurufen wird die IP zu dieser Seite nicht aufgelöst, so dass der Browser nicht auf die Seite gelangt.
<G-vec00301-002-s022><resolve.auflösen><en> If a government tries to keep you away from a site they just keep a list of domain names and if you enter one of the domains on the list in you browser the local DNS server doesn’t resolve the name so you can’t get to the site.
<G-vec00301-002-s023><resolve.auflösen><de> Ursache Die Beziehung zum verstorbenen Sims wird bei dessen Tod nicht korrekt aufgelöst.
<G-vec00301-002-s023><resolve.auflösen><en> Cause The game doesn’t resolve the relationship to the dead Sim correctly.
<G-vec00301-002-s024><resolve.auflösen><de> Benutzer können ihre Distinguished Names als Acrolinx Benutzerkennung eingeben oder Sie können Acrolinx Server so einrichten, dass der DN für jeden Benutzer auf Basis eines anderen Kennzeichners aufgelöst wird, den der jeweilige Benutzer als Acrolinx Benutzerkennung eingibt.
<G-vec00301-002-s024><resolve.auflösen><en> Users can enter their distinguished name as their Acrolinx user ID, or you can configure the Acrolinx Server to resolve the DN for each user based on another identifier that a user enters as their Acrolinx user ID.
<G-vec00301-002-s025><resolve.auflösen><de> Sie können "IP-Tools" so einstellen, dass symbolische Portnamen anstatt Portzahlen angezeigt werden, dass die IP-Adressen in Hostnamen aufgelöst werden, und dass alle Ereignisse in einer Datei gespeichert werden.
<G-vec00301-002-s025><resolve.auflösen><en> You can set up IP-Tools to display symbolic port names rather than port numbers, resolve IP addresses to host names, and record all events to a log file.
<G-vec00301-002-s026><resolve.auflösen><de> Ermitteln Sie mit der Registerkarte „Eigenschaften“, welches Sicherheitsrisiko gefunden wurde und informieren Sie sich anhand des Links zum Sicherheitsstatusbewertungs-Bericht über das Sicherheitsrisiko und wie es aufgelöst werden kann.
<G-vec00301-002-s026><resolve.auflösen><en> Use the Properties tab to determine what vulnerability was found and use the links to the Security State Assessment report to learn more about the vulnerability and how to resolve it.
<G-vec00301-002-s027><resolve.auflösen><de> Epilogue-Dateien können so bearbeitet werden, dass eine Folge von Prozeduren in einer PostScript-Datei aufgelöst wird.
<G-vec00301-002-s027><resolve.auflösen><en> Epilogue files can be edited to resolve a series of procedures in a PostScript file.
<G-vec00301-002-s028><resolve.auflösen><de> Dies ist zwar eine effektive kurzfristige Lösung, da die größte Überlastung in den Kanälen zwischen der Vermittlung und dem ISP POP auftritt, es wird jedoch nicht die Überlastung in der Vermittlung selbst aufgelöst, und deshalb kann es weiterhin erforderlich sein, daß der Ortsanschlußnetzanbieter weitere Vermittlungen und Kommunikationskanäle verwendet.
<G-vec00301-002-s028><resolve.auflösen><en> While this is an effective short term solution because the greatest congestion will occur at the channels between the Switch and the ISP POP, it does not resolve the congestion in the Switch itself and therefore may still require that the local access network provider deploy more switches and communication channels.
<G-vec00301-002-s029><resolve.auflösen><de> Also beispielsweise dessen IP-Adresse, den Hostnamen, das Land, in dem der Server steht sowie die Adresse des DNS-Servers, der den Domainnamen aufgelöst hat.
<G-vec00301-002-s029><resolve.auflösen><en> So, for example, its IP address, the host name, the country in which the Server is located and the address of the DNS server that resolve the domain name.
<G-vec00389-002-s031><destroy.auflösen><de> Ihr sollt nicht meinen, das ich gekommen sei, um das Gesetz oder die Propheten aufzulösen.
<G-vec00389-002-s031><destroy.auflösen><en> “Do not think that I came to destroy the law or the prophets.
<G-vec00389-002-s032><destroy.auflösen><de> In der Bergpredigt sagt er: „Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s032><destroy.auflösen><en> In his sermon on the mount he declared: "Think not that I am come to destroy the law or the prophets; I am not come to destroy, but to fulfill.
<G-vec00389-002-s034><destroy.auflösen><de> Ihr sollt nicht meinen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s034><destroy.auflösen><en> Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil.
<G-vec00389-002-s036><destroy.auflösen><de> 17 Meint nicht, daß ich gekommen sei, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s036><destroy.auflösen><en> 17 Don't think that I came to destroy the law or the prophets. I didn't come to destroy, but to fulfill.
<G-vec00389-002-s038><destroy.auflösen><de> Ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s038><destroy.auflösen><en> I am not come to destroy, but to fulfil.
<G-vec00389-002-s039><destroy.auflösen><de> Diese Karte muss offen auf dem Spielfeld liegen, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00389-002-s039><destroy.auflösen><en> ●WATER: Select 1 Spell/Trap Card on the field, and destroy it.
<G-vec00389-002-s040><destroy.auflösen><de> Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s040><destroy.auflösen><en> Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfill.
<G-vec00389-002-s042><destroy.auflösen><de> „17 Ihr sollt nicht meinen, dass ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s042><destroy.auflösen><en> ”17 Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil.
<G-vec00389-002-s044><destroy.auflösen><de> Bis Himmel und Erde vergehen... Dann wies mich der Mann auf einen Text hin: "Ihr sollt nicht meinen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s044><destroy.auflösen><en> I am not come to destroy, but to fulfill. For verily I say unto you, till heaven and earth pass, one jot or one tittle shall in no wise pass from the law, till all be fulfilled.”
<G-vec00389-002-s045><destroy.auflösen><de> 5:16 Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s045><destroy.auflösen><en> 5.17 Ne Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfill.
<G-vec00389-002-s008><liquidate.auflösen><de> Trotz des finanziellen Risikos beginne ich daher nun den Fonds aufzulösen und hoffe, den möglichen Fehlbetrag über eine freiwillige solidarische Lösung ausgleichen zu können.
<G-vec00389-002-s008><liquidate.auflösen><en> Despite the financial risk, therefore, I am now beginning to liquidate the fund and hope to be able to make up the possible shortfall by means of a voluntary solution based on solidarity.
<G-vec00599-002-s023><disintegrate.auflösen><de> Diese wunderbare, kraftvolle Technik erlaubt uns, auf ganz natürliche Weise, mittels unserer eigenen Selbstheilungskräfte, alte Gewohnheiten und unangepasste Verhaltensmuster aufzulösen und sie mit neuen, angepassteren zu ersetzen, die besser geeignet sind, uns auf einem glücklichen und harmonischen Lebensweg zu begleiten.
<G-vec00599-002-s023><disintegrate.auflösen><en> This marvellous and powerful method enables us in a very natural way, using our self-healing capacities, to disintegrate old habits and inadequate behaviour patterns and to replace them by new and adequate ones, capable of accompanying us in a happy and harmonious life.
<G-vec00599-002-s030><unravel.auflösen><de> Beginnt ein Teil dieses Prozesses unannehmbar schmerzhafte Ausmaße anzunehmen, steigt die Notwendigkeit politischer Intervention und das gesamte System läuft Gefahr, sich aufzulösen.
<G-vec00599-002-s030><unravel.auflösen><en> As one part of that process begins to appear unacceptably painful, demand for political intervention rises, and the entire system risks beginning to unravel.
<G-vec00198-002-s096><abolish.auflösen><de> In diesem Zusammenhang wird „auflösen“ dem Wort „erfüllen“ gegenüber gestellt.
<G-vec00198-002-s096><abolish.auflösen><en> In this context, “abolish” is set in opposition to “fulfill.”
<G-vec00198-002-s105><abolish.auflösen><de> 17 Wähnet nicht, daß ich gekommen sei, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00198-002-s105><abolish.auflösen><en> Jesus said to his disciples: "Do not think that I have come to abolish the law or the prophets. I have come not to abolish but to fulfill.
<G-vec00198-002-s106><abolish.auflösen><de> Ich bin nicht gekommen das Gesetz oder die Propheten aufzulösen, sondern zu erfüllen.
<G-vec00198-002-s106><abolish.auflösen><en> Do not think that I came to abolish the Law or the Prophets; I did not come to abolish but to fulfill.
<G-vec00198-002-s304><break_up.auflösen><de> An der Universität St. Gallen bringen wir den Studenten seit jeher bei, sich von der reinen Modelloptik zu lösen, die zugrundeliegenden Annahmen einzubeziehen – und auch zu hinterfragen.
<G-vec00198-002-s304><break_up.auflösen><en> At the University of St. Gallen, we have always taught students to break away from a pure model perspective, to factor in the underlying assumptions and to even question those assumptions.
<G-vec00198-002-s305><break_up.auflösen><de> Wir ermöglichen Ihnen auf systematische Weise, sich von konventionellen Denkmustern zu lösen und eine völlig neue Perspektive auf Ihr Geschäft einzunehmen.
<G-vec00198-002-s305><break_up.auflösen><en> We systematically enable you to break free of conventional patterns of thinking and expand your perspective on your business
<G-vec00198-002-s306><break_up.auflösen><de> (4) Der Anbieter behält sich vor, sich von der Verpflichtung zur Erfüllung des Vertrages zu lösen, wenn die Ware durch einen Lieferanten zum Tag der Auslieferung anzuliefern ist und die Anlieferung ganz oder teilweise unterbleibt.
<G-vec00198-002-s306><break_up.auflösen><en> (4) The provider reserves the right to break away from the obligation to fulfill the contract, if the goods are to be delivered by his supplier to the date of delivery and the delivery remains undone entirely or partially.
<G-vec00198-002-s307><break_up.auflösen><de> Drücke die Karte weiter rein, um den ganzen Kleber zu lösen.
<G-vec00198-002-s307><break_up.auflösen><en> Press the card in at several points if necessary to break up the adhesive behind the battery.
<G-vec00198-002-s308><break_up.auflösen><de> Wenn Gott uns in seiner Hand hält, gibt es keine Kraft, die diesen Griff lösen kann... keine.
<G-vec00198-002-s308><break_up.auflösen><en> If God holds us, there's no power that can break His hold...none.
<G-vec00198-002-s309><break_up.auflösen><de> Die Öle in Erdnussbutter, ob du es glaubst oder nicht, lösen viele Klebstoffe.
<G-vec00198-002-s309><break_up.auflösen><en> The oils in peanut butter will break down many adhesives.
<G-vec00198-002-s310><break_up.auflösen><de> Zudem lösen sich Verkrustungen am Inneren der Manschette während des Schließvorgangs durch die Verformung.
<G-vec00198-002-s310><break_up.auflösen><en> In addition, deformation of the sleeve during the closing process causes any incrustations inside the sleeve to break away.
<G-vec00198-002-s311><break_up.auflösen><de> Das kommt so – aus dem Wissen heraus, dass ihr eure Ziele erreicht habt und fähig gewesen seid, eure Bindung an irdische Verknüpfungen zu lösen, die euch nicht länger dienlich sind.
<G-vec00198-002-s311><break_up.auflösen><en> It comes from knowing that you have achieved your goals, and have been able to break your bonds with the earthly links that no longer serve you.
<G-vec00198-002-s312><break_up.auflösen><de> Das Licht ist der Startschuss für den Prozess: Die Elektronen werden angeregt, lösen sich von ihren Atomen und werden frei beweglich.
<G-vec00198-002-s312><break_up.auflösen><en> The light is the go-ahead for the process: The electrons are stimulated, break away from their atoms and become free movable.
<G-vec00198-002-s313><break_up.auflösen><de> Suchet euch zu lösen von ihr, machet euch frei von dem, was euer Verderben ist, Ihr habt die harte Materie schon vor langer Zeit überwunden - lasset euch nicht von ihr aufs neue gefangennehmen, sondern suchet frei zu werden von jeglicher Form.
<G-vec00198-002-s313><break_up.auflösen><en> Seek to break away from it; make yourselves free of that, what is your ruin; you have overcome hard matter already a long time ago – do not let yourselves be anew captured by it, but seek to become free of all form.
<G-vec00198-002-s314><break_up.auflösen><de> - Bitte lösen Sie paramilitärische Gruppen auf und lösen Sie deren Verbindungen zu den Sicherheitskräften, wie es die Vereinten Nationen in ihren Empfehlungen zum Schutz der Menschenrechte mehrfach ausgesprochen haben.
<G-vec00198-002-s314><break_up.auflösen><en> - Urging them to dismantle paramilitary groups and break their links with the security forces in line with repeated United Nations human rights recommendations.
<G-vec00198-002-s315><break_up.auflösen><de> In ähnlicher Weise können sich Plaquefragmente lösen und auf ihrem Weg durch den Blutstrom eine Arterie an einer anderen Stelle blockieren.
<G-vec00198-002-s315><break_up.auflösen><en> Similarly, pieces of the plaque can break off and travel through the bloodstream and block an artery elsewhere.
<G-vec00198-002-s316><break_up.auflösen><de> In Götter und Monster lösen Caroline und Alaric ihre Verlobung auf, weil Caroline immer noch Gefühle für Stefan hat.
<G-vec00198-002-s316><break_up.auflösen><en> As of Gods and Monsters, Caroline and Alaric break off their engagement being Caroline still wants to be with Stefan.
<G-vec00198-002-s317><break_up.auflösen><de> Sie waren so in der Lust des Augenblicks gefangen, sich davon zu lösen war schmerzlich und lästig.
<G-vec00198-002-s317><break_up.auflösen><en> They were so caught up in the lust of the moment, to break from it is painfully annoying.
<G-vec00198-002-s318><break_up.auflösen><de> Lösen Sie sich von statischen Mustern und starrem Layout-Denken.
<G-vec00198-002-s318><break_up.auflösen><en> Break away from static patterns and rigid layout thinking.
<G-vec00198-002-s319><break_up.auflösen><de> Dann erst gestaltet sich der Mensch selbst so, daß er tauglich ist, für Mich und Mein Reich zu arbeiten, daß er also rechte Weinbergsarbeit verrichten kann, ohne Ansehen der Person und des Standes den Mitmenschen das gleiche Ziel vor Augen zu stellen und sie durch Aufklärungen über Mich Selbst so weit zu bringen, daß sie an sich selbst das gleiche vollziehen - wieder sich zu lösen von der irdischen Welt und den Kampf gegen die Materie aufzunehmen.
<G-vec00198-002-s319><break_up.auflösen><en> Only then man fashions himself so that he is suitable to work for me and my kingdom that he therefore can accomplish real vineyard work, without respect for persons and for class to put the same aim before the eyes of fellowmen and to bring them so far through enlightenment about me myself that they carry out at themselves the same – to again break away from the earthly world and to take up the fight against matter.
<G-vec00198-002-s320><break_up.auflösen><de> Die Scorpions lösen sich demnächst auf, doch Band-Gründer Rudolf Schenker hat schon eine gute Nebenbeschäftigung gefunden.
<G-vec00198-002-s320><break_up.auflösen><en> The Scorpions break up shortly, but founder and guitarist Rudolf Schenker has already found a good sideline.
<G-vec00198-002-s321><break_up.auflösen><de> Hat man AVECs Klängen einmal gelauscht, kann man sich nur mehr schwer davon lösen.
<G-vec00198-002-s321><break_up.auflösen><en> Once you've listened to AVEC's sounds, it's hard to break away from them.
<G-vec00198-002-s322><break_up.auflösen><de> URSACHE Beim normalen Bremsvorgang lösen sich Metallpartikel von der Bremsscheibe.
<G-vec00198-002-s322><break_up.auflösen><en> CAUSE During normal braking small particles of the rotor surface break off.
<G-vec00198-002-s271><cancel.auflösen><de> Sollte ARMAS Gebühren für Teile des Service verlangen, die heute frei zugaenglich sind, erhalten Sie eine Nachricht von ARMAS und die Möglichkeit, Ihren Account aufzulösen, bevor diese Gebühren zum Tragen kommen.
<G-vec00198-002-s271><cancel.auflösen><en> Thus, if at any time “Armas” requires a fee for portions of the “Service” that are now free, “Armas” will give you advance notice of such fees and the opportunity to cancel your account before such charges are imposed.
<G-vec00198-002-s272><cancel.auflösen><de> Bei nicht rechtzeitiger Zahlung ist DASSY unbeschadet aller anderen Rechte berechtigt, die (weitere) Erfüllung jedes mit dem Kunden geschlossenen Vertrages auszusetzen (auch wenn die Nichtzahlung sich auf ein anderes Vertragsverhältnis bezieht) und den/die Vertrag/Verträge aufzulösen.
<G-vec00198-002-s272><cancel.auflösen><en> Without prejudice to all other rights, DASSY is entitled, in case of arrears in payment, to suspend the (further) performance of any agreement with the customer (even if the failure to pay relates to another contractual relationship) and to cancel the agreement(s).
<G-vec00198-002-s273><cancel.auflösen><de> Der Verbraucher hat in diesem Fall das Recht, den Vertrag ohne Kosten zu aufzulösen und hat gegebenenfalls Anspruch auf Schadenersatz.
<G-vec00198-002-s273><cancel.auflösen><en> The customer then has the right to cancel the order free of charge and has right to a potential damage claim.
<G-vec00198-002-s274><cancel.auflösen><de> Als Nutzer haben sie jederzeit die Möglichkeit, die Registrierung aufzulösen.
<G-vec00198-002-s274><cancel.auflösen><en> As a user you have the ability to cancel your registration at any time.
<G-vec00198-002-s275><cancel.auflösen><de> Sollte die Zahlung nicht fristgemäss eingegangen sein, behält sich der Anbieter das Recht vor, den Vertrag aufzulösen und die unter Punkt 3 aufgelisteten Annulationskosten in Rechnung zu stellen.
<G-vec00198-002-s275><cancel.auflösen><en> If the payment is not made on time the organizer has the right to cancel the contract and charge the annulment costs according to point 3.
<G-vec00198-002-s276><cancel.auflösen><de> Beim Kauf von Produkten hat der Verbraucher die Möglichkeit, den Vertrag für 14 Tage ohne Angabe von Gründen aufzulösen.
<G-vec00198-002-s276><cancel.auflösen><en> 1. When purchasing products the consumer has the possibility to cancel the agreement without reasons during 14 days.
<G-vec00198-002-s277><cancel.auflösen><de> Dauert einer der in Punkt 6.2. genannten Gründe länger als zwei Monate, so sind sowohl der Lieferant als auch der Kunde berechtigt, durch einseitige schriftliche Erklärung den Vertrag aufzulösen.
<G-vec00198-002-s277><cancel.auflösen><en> Should one of the reasons stated in clause 6.2. have existed for more than two months, the Supplier, as well as the Customer, shall be entitled to cancel the Contract by unilaterally announcing such cancellation in writing.
<G-vec00198-002-s278><cancel.auflösen><de> Zudem haben Sie jederzeit die Möglichkeit, Ihre Registrierung aufzulösen, indem Sie den registrieren Nutzer-Account in Ihren Account-Einstellungen eigenhändig löschen oder uns mitteilen, dass Sie eine Löschung Ihres registrierten Nutzer-Accounts wünschen.
<G-vec00198-002-s278><cancel.auflösen><en> Furthermore, you have the option to cancel your registration at any time by deleting the registered user account yourself through the account settings or letting us know that you want your registered user account deleted.
<G-vec00198-002-s280><cancel.auflösen><de> Pixmac hat das Recht, das Partnerprogramm zu ändern oder aufzulösen, sowie auch die gegenwärtigen Vertragsbedingungen zu ändern, und das ohne vorherige Bekanntgabe.
<G-vec00198-002-s280><cancel.auflösen><en> Pixmac has the right to modify or cancel the affiliate program as well as to change its current terms and conditions without any prior notice.
<G-vec00198-002-s281><cancel.auflösen><de> Artikel 1: Der Vermieter hat das Recht, den Vertrag bei Nichterfüllung einer seiner Pflichten durch den Käufer aufzulösen.
<G-vec00198-002-s281><cancel.auflösen><en> 13 Cancellation clause The vendor has the right to cancel the order if the customer doesn't execute his obligations.
<G-vec00198-002-s282><cancel.auflösen><de> Sie erkennen an und stimmen zu dass, sofern Sie während der besagten Zeit nichts an DISRUPTOR BEAM gezahlt haben, Ihr einziges Rechtsmittel (und der einzige Fall von Haftbarkeit für DISRUPTOR BEAM) für einen beliebigen Streit mit DISRUPTOR BEAM darin besteht, die Nutzung der LEISTUNG zu beenden und IHR KONTO aufzulösen.
<G-vec00198-002-s282><cancel.auflösen><en> YOU ACKNOWLEDGE AND AGREE THAT IF YOU HAVE NOT PAID ANYTHING TO DISRUPTOR BEAM DURING SUCH TIME PERIOD, YOUR SOLE REMEDY (AND DISRUPTOR BEAM’S EXCLUSIVE LIABILITY) FOR ANY DISPUTE WITH DISRUPTOR BEAM IS TO STOP USING THE SERVICE AND TO CANCEL YOUR ACCOUNT.
<G-vec00198-002-s002><disband.auflösen><de> Tatsächlich besteht das Problem darin, dass sich Euromaidan nach seinem Ende und der Zeit, sich mit politischen Aspekten zu befassen, alle diese Formationen leider nicht aufgelöst hat, sondern ganz im Gegenteil — er gewann an Fahrt und gewann in der Nazi-Ideologie populär.
<G-vec00198-002-s002><disband.auflösen><en> Actually, the problem is that when Euromaidan came to an end, and it was time to deal with political aspects, all these formations, alas, did not disband, but quite the opposite – began to gain momentum, popularizing in fact Nazi ideology.
<G-vec00198-002-s003><disband.auflösen><de> Außerdem kannst du Truppen oder andere Einheiten auflösen, wenn du schnell an Bauern kommen möchtest, damit dir rasch Arbeiter zur Verfügung stehen.
<G-vec00198-002-s003><disband.auflösen><en> You can also disband troops or other units if you wish to quickly get peasants into your village, and therefore have immediately-available workers.
<G-vec00198-002-s004><disband.auflösen><de> Wenn ihr eine Einheit nicht für nützlich befindet, sie nicht eurem Spielstil entspricht oder ihr einfach nur einen leeren Platz benötigt, könnt ihr die Einheit über das Fenster Kaserne auflösen.
<G-vec00198-002-s004><disband.auflösen><en> If you didn't find the unit useful, or if it fails to match your playstyle, or you simply need an empty slot, you can disband the unit via the barracks screen.
<G-vec00198-002-s005><disband.auflösen><de> Die „patriotische Version“ dagegen sagt, dass Ramanauskas’s Truppe zum Schutz gegen die Plünderei durch die Deutschen diente, was auch der Grund war, weshalb die Deutschen sie entwaffnen und auflösen wollten.
<G-vec00198-002-s005><disband.auflösen><en> The “patriotic version” has it that Ramanauskas’s squad served as an impediment to German plundering, and that was the reason why the Germans wanted to disarm and disband them.
<G-vec00198-002-s006><disband.auflösen><de> Die traurige Wirklichkeit des Liebens der Musik der achtziger Jahre ist, daß Anordnungen ändern, Bänder auflösen, oder die traditionelle Presse ignoriert ihren neuen Ausgang.
<G-vec00198-002-s006><disband.auflösen><en> The sad reality of loving the music of the 1980's is that line-ups change, bands disband or the traditional press ignores their new output.
<G-vec00198-002-s010><disband.auflösen><de> Seit zwei Jahren habe ich darüber nachgedacht, langsam, gründlich, geduldig, und ich habe mich nun entschlossen, den Orden, dessen Haupt ich nun einmal bin, aufzulösen.
<G-vec00198-002-s010><disband.auflösen><en> For two years I have been thinking about this, slowly, carefully, patiently, and I have now decided to disband the Order, as I happen to be its Head.
<G-vec00198-002-s011><disband.auflösen><de> Als sein Versöhnungsversuch zusammenbrach, weil – wie er selbst erklärte – die Menschewiki es ablehnten, ihre Fraktion aufzulösen und die Liquidatoren zu entfernen, verurteilte Trotzki sie nicht, sondern „enthielt sich des Urteils“.
<G-vec00198-002-s011><disband.auflösen><en> When his attempt at reconciliation broke down because – as he himself stated – the Mensheviks refused to disband their faction and get rid of the Liquidators, Trotsky did not condemn them but “suspended judgement”.
<G-vec00198-002-s012><disband.auflösen><de> Ja, er erklärte sogar, seine illegalen Sturmtruppen aufzulösen, sobald andere Parteien desgleichen getan hätten.
<G-vec00198-002-s012><disband.auflösen><en> They have even declared that they will disband their illegal assault troops as soon as the other parties have done the same.
<G-vec00198-002-s013><disband.auflösen><de> Was immer aufkommt, wir verstehen es korrekt - und die Dinge lösen sich auf.
<G-vec00198-002-s013><disband.auflösen><en> Whatever arises, we know it correctly — and things disband.
<G-vec00198-002-s014><disband.auflösen><de> Nach zahlreichen Liveauftritten trennten sich Chris Maico Schmidt, aka Mike S., Milan Zemanec und Daniel Varga 1994 und lösten die Gruppe auf.
<G-vec00198-002-s014><disband.auflösen><en> After numerous live performances Chris Maico Schmidt, aka Mike S., Milan Zemanec and Daniel Varga separated in 1994 and disband the group.
<G-vec00198-002-s017><disband.auflösen><de> Die Post erklärte, dass die Gruppe sich auflösen werde, so dass die Mitglieder ihre individuellen Ziele und Träume verfolgen können und so ihre individuellen Wege gehen können.
<G-vec00198-002-s017><disband.auflösen><en> The post stated the group will disband so that the members can each pursue their individual goals and dreams and so they can walk their individual paths.
<G-vec00198-002-s018><disband.auflösen><de> Doch die Gruppe begann sich aufzulösen.
<G-vec00198-002-s018><disband.auflösen><en> Nevertheless, the group began to disband.
<G-vec00198-002-s019><disband.auflösen><de> Beim Kauf von Produkten hat der Verbaucher die Möglichkeit die Vereinbarung, ohne Angabe von Gründen, innerhalb von 30 Werktagen aufzulösen.
<G-vec00198-002-s019><disband.auflösen><en> After purchasing products the consumer has the possibility to disband the agreement without giving reasons during 14 days.
<G-vec00198-002-s031><dissolve.auflösen><de> Tabletten müssen so hart gepresst sein, dass sie nicht zerbröckeln, aber nicht härter, als dass sie im Magen aufgelöst werden.
<G-vec00198-002-s031><dissolve.auflösen><en> Tablets should be pressed so that they do not crumble, but not hard enough not to let them dissolve quickly in the stomach.
<G-vec00198-002-s032><dissolve.auflösen><de> 5 ± 0,1 g Saccharose (handelsübliche Qualität) werden in 95 ± 1 g Wasser aufgelöst.
<G-vec00198-002-s032><dissolve.auflösen><en> Dissolve 5 ± 0,1 g sucrose (commercial grade) in 95 ± 1 g of water.
<G-vec00198-002-s033><dissolve.auflösen><de> Den fertigen Druck einfach ins warme Wasser einlegen, und das Copolymer aus Vinylalkohol und Butandiol (BVOH) wird vollständig aufgelöst, sodass nur das 3D-Modell übrig bleibt.
<G-vec00198-002-s033><dissolve.auflösen><en> It is enough to place the finished print in warm water and the butane-diol vinyl alcohol copolymer (BVOH) will completely dissolve, leaving only the 3D model.
<G-vec00198-002-s034><dissolve.auflösen><de> Aber der Mensch in diesem Raum ist verschwunden, weil der Körper eingeäschert oder unter der Erde begraben werden muss und der Körper verwest und aufgelöst wird.
<G-vec00198-002-s034><dissolve.auflösen><en> Yet the person in this dimension has vanished, since the body needs to be cremated or buried and it will eventually decompose and dissolve.
<G-vec00198-002-s035><dissolve.auflösen><de> Die starren Dogmen sind aufgelöst und werden mit einem neuen Rhythmus reanimiert.
<G-vec00198-002-s035><dissolve.auflösen><en> Rigid dogmas dissolve and are reanimated with a new rhythm.
<G-vec00198-002-s036><dissolve.auflösen><de> So gibt es Bereiche, in denen die Oberfläche fast opak erscheint, während sie an anderer Stelle durch den veränderten Lichteinfall aufgelöst wird und Farben freisetzt.
<G-vec00198-002-s036><dissolve.auflösen><en> Thus there are areas where the surface almost appears opaque, although in other places it seems to dissolve in the changing rays of light as it emits colours.
<G-vec00198-002-s037><dissolve.auflösen><de> Die beiden Ärzte hätten das Opfer darauf autopsiert, die Leiche anschließend aufgelöst und die Knochen an ein namhaftes anthropologisches Institut in Berlin-Dahlem gesandt.
<G-vec00198-002-s037><dissolve.auflösen><en> The two doctors would then autopsy the victims, after which they would dissolve the bodies and ship the bones to a renowned anthropological institute in Berlin-Dahlem.
<G-vec00198-002-s038><dissolve.auflösen><de> Tito, der spätere Führer Jugoslawiens, bezeugte lange später: „Eine ähnliche Erfahrung hatte ich 1938 in Moskau gemacht, als wir darüber sprachen, ob unsere Kommunistische Partei aufgelöst werden sollte oder nicht.
<G-vec00198-002-s038><dissolve.auflösen><en> Tito, later to be ruler of Yugoslavia, testified long afterwards: ‘In 1938 when I was in Moscow... we were discussing whether to dissolve the Yugoslav Communist Party or not.
<G-vec00198-002-s039><dissolve.auflösen><de> 1142 — Die nicht vollzogene Ehe zwischen Getauften oder zwischen einem getauften und einem ungetauften Partner kann aus einem gerechten Grund auf Bitten beider Partner oder eines Partners, selbst wenn der andere dem widerstrebt, vom Papst aufgelöst werden.
<G-vec00198-002-s039><dissolve.auflösen><en> 1142 For a just cause, the Roman Pontiff can dissolve a non-consummated marriage between baptized persons or between a baptized party and a non-baptized party at the request of both parties or of one of them, even if the other party is unwilling.
<G-vec00198-002-s040><dissolve.auflösen><de> Als temporäre Anwendung, nachdem sich die Pigmente aufgelöst und verblasst haben, können die Patienten ihr früheres Erscheinungsbild wieder aufnehmen.
<G-vec00198-002-s040><dissolve.auflösen><en> Being a temporary application, after the pigments dissolve and fade out, patients can resume their former appearances.
<G-vec00198-002-s041><dissolve.auflösen><de> Durch die regelmäßige Praxis von Yoga Nidra werden diese Spannungen auf allen Ebenen angegangen und aufgelöst.
<G-vec00198-002-s041><dissolve.auflösen><en> With a regular Yoga Nidra practice these tensions are tackled on all levels and slowly dissolve.
<G-vec00198-002-s042><dissolve.auflösen><de> Instantgetränke - In Wasser aufgelöst entsteht ein leckeres Getränk, das die Einnahme großer Wirkstoffmengen oder mehrerer Wirkstoffe ermöglicht.
<G-vec00198-002-s042><dissolve.auflösen><en> Instant drinks - Dissolve in water for a pleasant tasting drink that can deliver large quantities or multiple APIs in a single dose. Lozenges
<G-vec00198-002-s043><dissolve.auflösen><de> Sollten noch Reste von Echthaar-Stylingprodukten im Haar sein, werden diese im folgenden Waschgang vom Perücken-Shampoo automatisch aufgelöst.
<G-vec00198-002-s043><dissolve.auflösen><en> If there are any human hair styling products left in the hair, the wig shampoo will by itself dissolve them in the following wash.
<G-vec00198-002-s044><dissolve.auflösen><de> Sacrificial-Tooling-Material ST-130 für Opferkerne, die den hohen Temperaturen und dem Druck bei Verbundschichtformen widerstehen und bei Bauteilen mit inneren Hohlräumen leicht aufgelöst werden können.
<G-vec00198-002-s044><dissolve.auflösen><en> Sacrificial tooling material (not available for Fortus 380mc) ST-130 for sacrificial mandrels that withstand the heat and pressure of composite lay-up and dissolve easily from hollow part interiors
<G-vec00198-002-s045><dissolve.auflösen><de> Dabei verschwimmen die Kanten der Formen, werden in Fell aufgelöst oder vermischen sich zu einem einzigen Gesamtkunstwerk.
<G-vec00198-002-s045><dissolve.auflösen><en> In doing so, the edges of the shapes become blurred, dissolve in the fur or merge into one as a unique work of art.
<G-vec00198-002-s046><dissolve.auflösen><de> In einer Studie mit insgesamt 325 Patienten nach einem ischämischen Gehirnschlag zeigte sich, dass die übliche thrombolytische Therapie, mit der die Blutgerinnsel aufgelöst werden, Frauen deutlich weniger half als Männern: Drei Monate nach dem Ereignis waren nur noch 28,8 Prozent der betroffenen Männer von mehr als nur mäßigen Funktionsbeeinträchtigungen betroffen - aber 44,2 Prozent der Frauen.
<G-vec00198-002-s046><dissolve.auflösen><en> A study of 325 patients who had suffered an ischemic stroke showed that the standard thrombolytic therapy to dissolve clots helped women significantly less than men: three months after the event, only around 28.8% of men continued to suffer more than moderate functional impairment - compared to 44.2% of women.
<G-vec00198-002-s047><dissolve.auflösen><de> Aus diesem Grund sollen die bestehenden Verträge aufgelöst werden.
<G-vec00198-002-s047><dissolve.auflösen><en> Therefore it was decided to dissolve the existing contracts.
<G-vec00198-002-s048><dissolve.auflösen><de> So wie Nebel nur von der Sonne aufgelöst werden kann, kann auch Blindheit in einer Seele nur durch die wahre Liebe geheilt werden.
<G-vec00198-002-s048><dissolve.auflösen><en> Just like the fog can only dissolve under the sun's influence, a soul's blindness can only be cured by true Love.
<G-vec00198-002-s049><dissolve.auflösen><de> Generationskonflikt auflösen und neue Arbeitsweisen zulassen: Entscheider etablierter Unternehmen sind weitestgehend Vertreter der sogenannten Generation X, die gegenüber der Folgegenerationen Y und Z nicht in einer (zunehmend) vernetzten, digitalen Welt aufgewachsen und sozialisiert sind.
<G-vec00198-002-s049><dissolve.auflösen><en> Dissolve generational conflict and allow new ways of working: The decision makers of most established companies belong to the so-called Generation X, who in contrast to the subsequent generations Y and Z did not grow up and were not socialized in an (increasingly) connected, digital world.
<G-vec00198-002-s050><dissolve.auflösen><de> Das Rauschgift sollte sich innerhalb von 1 Minute völlig auflösen.
<G-vec00198-002-s050><dissolve.auflösen><en> The drug should completely dissolve within 1 min.
<G-vec00198-002-s051><dissolve.auflösen><de> Jede Sprache und Kultur aus jedem Winkel dieser Erde hat uns geprägt, und weil wir Bürgerkrieg und Rassentrennung bitter auf unserer Zunge geschmeckt haben, und gestärkter und geeinter aus diesem dunklen Kapitel hervorgegangen sind, können wir nicht anders als zu glauben, dass der alte Hass eines Tages überwunden sein wird, dass sich die Trennlinien zwischen Volksgruppen bald auflösen werden, dass in einer kleiner werdenden Welt unsere gemeinsame Menschlichkeit zum Vorschein kommen wird, und dass die Vereinigten Staaten ihre Rolle darin spielen müssen, eine neue Zeit des Friedens einzuläuten.
<G-vec00198-002-s051><dissolve.auflösen><en> We are shaped by every language and culture, drawn from every end of this Earth. And because we have tasted the bitter swill of civil war and segregation and emerged from that dark chapter stronger and more united, we cannot help but believe that the old hatreds shall someday pass; that the lines of tribe shall soon dissolve; that as the world grows smaller, our common humanity shall reveal itself; and that America must play its role in ushering in a new era of peace.
<G-vec00198-002-s052><dissolve.auflösen><de> Und auch nach der neuen EU-Verordnung werde sich dieses Problem nicht in Luft auflösen: “Die Finanzierung medizinischer Innovation wird von den Stakeholdern des deutschen Gesundheitssystems nicht ausreichend unterstützt”, kritisiert Eggert.
<G-vec00198-002-s052><dissolve.auflösen><en> Even after the new EU regulation, she said this problem will not dissolve into thin air: “Financing of medical innovation does not receive sufficient support from stakeholders of the German healthcare system”, Eggert said.
<G-vec00198-002-s053><dissolve.auflösen><de> Erfindungsgemäß werden insbesondere Wirkstoffe eingesetzt, deren Hauptangriffspunkt die Gefäßwand ist, im Gegensatz zu Arzneistoffen, die primär die Blutgerinnung hemmen oder fördern oder Blutgerinnsel auflösen oder sonst wie auf Blutkomponenten einwirken.
<G-vec00198-002-s053><dissolve.auflösen><en> According to the invention active ingredients are used in particular, whose main target is the vascular wall, as opposed to drugs that primarily inhibit blood clotting or promoting or dissolve blood clots or otherwise act as on blood components.
<G-vec00198-002-s054><dissolve.auflösen><de> Die Peelingpartikel werden sich nicht vollständig auflösen, was auch gewünscht ist.
<G-vec00198-002-s054><dissolve.auflösen><en> The exfoliant will not completely dissolve, which is what you want.
<G-vec00198-002-s055><dissolve.auflösen><de> Das Espressopulver in einem Esslöffel kochendem Wasser auflösen, anschließend etwas abkühlen lassen.
<G-vec00198-002-s055><dissolve.auflösen><en> Dissolve the espresso powder in a tablespoon of boiling water, then allow to cool slightly.
<G-vec00198-002-s056><dissolve.auflösen><de> Damit verbundene andere Zugänge könnten Fronten auflösen helfen und sie uneindeutig machen.
<G-vec00198-002-s056><dissolve.auflösen><en> Associated alternative approaches could help to dissolve battle lines and render them ambiguous.
<G-vec00198-002-s057><dissolve.auflösen><de> Unter Rühren auflösen.
<G-vec00198-002-s057><dissolve.auflösen><en> Dissolve with stirring.
<G-vec00198-002-s058><dissolve.auflösen><de> Gelatine ausdrücken und bei niedriger Hitze auflösen und unter der Quarkcreme verrühren.
<G-vec00198-002-s058><dissolve.auflösen><en> Press gelatine and dissolve under low heat. Stir liquid gelatine in curdmix and let it cool.
<G-vec00198-002-s059><dissolve.auflösen><de> Er kann mit Leichtigkeit unsere nicht wünschenswerten Wunschmuster auflösen, wenn wir Seine Gegenwart anrufen und um Seine Hilfe bitten.
<G-vec00198-002-s059><dissolve.auflösen><en> He can easily dissolve our undesirable desire patterns, if we invoke his presence and seek his help.
<G-vec00198-002-s060><dissolve.auflösen><de> Auflösen jede Portion in Wasser für den täglichen Konsum.
<G-vec00198-002-s060><dissolve.auflösen><en> Dissolve each serving in water for daily consumption.
<G-vec00198-002-s061><dissolve.auflösen><de> ... oder in Wasser auflösen.
<G-vec00198-002-s061><dissolve.auflösen><en> ...or dissolve in water.
<G-vec00198-002-s062><dissolve.auflösen><de> Um diese finanziell zu stabilisieren, musste Sasha Waltz 2014 ihr festes Ensemble sowie etwa ein Drittel der festen Mitarbeiterstellen auflösen.
<G-vec00198-002-s062><dissolve.auflösen><en> Thus, to stabilize its finances, Sasha Waltz had to dissolve her permanent ensemble and let go of approximately one third of the permanent employees in 2014.
<G-vec00198-002-s063><dissolve.auflösen><de> Gelatine ausdrücken, bei schwacher Hitze auflösen.
<G-vec00198-002-s063><dissolve.auflösen><en> Squeeze out gelatine, dissolve on a low heat.
<G-vec00198-002-s064><dissolve.auflösen><de> Die SALMIX® Echte Lakritz Stange bei kleiner Hitze im Hühnerfond und Weißwein auflösen.
<G-vec00198-002-s064><dissolve.auflösen><en> Dissolve the SALMIX® genuine liquorice stick over low heat in the chicken stock and white wine.
<G-vec00198-002-s065><dissolve.auflösen><de> Wasserstoff, das hellste Element, kann sich innerhalb der Metalle leicht auflösen und migrieren, um diese andernfalls duktile Materialien spröde und im Wesentlichen anfälliger zu machen für Versagen.
<G-vec00198-002-s065><dissolve.auflösen><en> Hydrogen, the lightest element, can easily dissolve and migrate within metals to make these otherwise ductile materials brittle and substantially more prone to failures.
<G-vec00198-002-s066><dissolve.auflösen><de> Hinzu kommt, dass der Aufenthalt in der freien Natur die Kreativität stimuliert und dass der Geist damit offen wird für neue Lösungsansätze und für das Auflösen von eingefahrenen und verhärteten Strukturen.
<G-vec00198-002-s066><dissolve.auflösen><en> In additional the stay in the free nature is stimulating the creativity so that the spirit gets open for new solutions and for the dissolve of well-worn and hardenend structures.
<G-vec00198-002-s067><dissolve.auflösen><de> Die kombinierten Niedervakuum-/Schwerkraft-Flaschen des ASEPT® Drainage Kit L können durch einen initialen Sog des Niedervakuums solche Okklusionen aktiv auflösen.
<G-vec00198-002-s067><dissolve.auflösen><en> The combined low-vacuum/gravitational bottles in the ASEPT® Drainage Kit L can actively dissolve such occlusions by means of initial suction through the low vacuum.
<G-vec00198-002-s068><dissolve.auflösen><de> Einen halben Liter HG Fliesen Kraftreiniger in einem halben Eimer (5 Liter) lauwarmem Wasser auflösen und mit einem Aufnehmer oder Mopp großzügig auf den Boden auftragen.
<G-vec00198-002-s068><dissolve.auflösen><en> Dissolve 50ml (half a cup) of HG polished tile cleaner in half a bucket (5L) of lukewarm water.
<G-vec00198-002-s069><dissolve.auflösen><de> Als Mediator hat er allein und zusammen mit Frau Rechtsanwältin Nicole-Denise Fassbender verschiedene Wirtschaftsmediatonen geleitet und konnte auf diesem Wege teilweise langjährige Meinungsverschiedenheiten zwischen vertraglich verbundenen und hierdurch in Streit geratenen Unternehmungen auflösen, ohne hierbei auf den Gerichtsweg zurückgreifen zu müssen.
<G-vec00198-002-s069><dissolve.auflösen><en> As a mediator, he alone and together with Attorney at Law Nicole-Denise Fassbender, led different mediations, and by that was able to find solutions to dissolve long-standing differences of opinion between contractually connected and thereby disputed enterprises, avoiding public court trials.
<G-vec00198-002-s070><dissolve.auflösen><de> Einfach ein kleines Stück ins fließende, warme Badewasser geben und auflösen lassen.
<G-vec00198-002-s070><dissolve.auflösen><en> Just a small piece into flowing, warm bath water and allow to dissolve.
<G-vec00198-002-s071><dissolve.auflösen><de> Einfach ein Tabs in eine Wasserflasche fallen lassen und sich auflösen lassen.
<G-vec00198-002-s071><dissolve.auflösen><en> Simply drop a tab into your re-usable water bottle and watch it rapidly dissolve.
<G-vec00198-002-s072><dissolve.auflösen><de> Wenn du schwimmst, dann versuche den Sonnenschutz mindestens eine halbe Stunde vorher aufzutragen, damit er bevor du schwimmst Zeit hat in deine Haut einzuziehen und sich nicht einfach im Wasser auflöst.
<G-vec00198-002-s072><dissolve.auflösen><en> If you go swimming, try applying sunscreen at least half an hour before you get in, so it has time to soak into your skin before you swim and doesn't just dissolve into the water.
<G-vec00198-002-s073><dissolve.auflösen><de> Eine solche Textpassage ist wichtig, weil die LLC sich ohne sie durch Tod oder eine andere Art des Ausscheiden eines Gesellschafters aus dem Unternehmen automatisch auflöst.
<G-vec00198-002-s073><dissolve.auflösen><en> Such text passages are important because the LLC automatically will automatically dissolve without them as a result of the death or another type of departure by a partner.
<G-vec00198-002-s074><dissolve.auflösen><de> So ist allerdings die transformative Energie dieser Worte, wie sie in diesem Artikel geschenkt werden, dass sie Schritt für Schritt die Kraft der Überzeugungen und Ideen auflöst und dem menschlichen Potenzial erlauben nach Außen zu strahlen – ein menschliches Wesen, das mit dauerhaften Werten ausgestattet ist.
<G-vec00198-002-s074><dissolve.auflösen><en> Such is the transformative energy of these words, however, as gifted in this article, that they gradually dissolve the power of the beliefs and ideas and allow man’s potential to shine out - a human being endowed with enduring values.
<G-vec00198-002-s075><dissolve.auflösen><de> Ein Wachs hat die Eigenschaft, dass es sich nicht so lange hält und auflöst (höchstens 2 bis 3 Monate).
<G-vec00198-002-s075><dissolve.auflösen><en> A wax or wax has the property that it will wear out and dissolve after not too long (at most 2 to 3 months).
<G-vec00198-002-s076><dissolve.auflösen><de> Neben Teilen auf Französisch vertont Vivier das Unaussprechliche in einer Fantasiesprache, in der sich jegliche Semantik in pure Lautlichkeit auflöst.
<G-vec00198-002-s076><dissolve.auflösen><en> Along with passages in French, Vivier also sets the inexpressible to music in a fantasy language in which all semantics dissolve into pure sound.
<G-vec00198-002-s077><dissolve.auflösen><de> Muskelentspannende Massage Tiefenmassage, die durch Strecken, Ziehen und Bewegen der verschiedenen Muskelpartien eventuelle Verhärtungen auflöst und die Muskulatur geschmeidig macht.
<G-vec00198-002-s077><dissolve.auflösen><en> Decontracting Massage Deep massage that together with techiques of stretching, mobilization and traction is proposed to dissolve any contractions and to soften the muscles.
<G-vec00198-002-s078><dissolve.auflösen><de> Nur in seltenen Fällen, wenn etwa der geschlossene Mund müde wird durch den ständigen Widerstand, locker wird, leicht, zuerst in den Winkeln, dann zunehmend überall aufbricht, sodass eine fremde Zunge beginnt, in mich zu finden, mich überrumpelt mit einer Liebe, die mich nicht auflöst, die vielmehr einen ganzen Körper macht, da es Lippen sind, an denen meine eigenen fühlbar werden, oder wenn etwa die Augen müde werden, der Neugierde nicht mehr widerstehen und sich mit dem Mund beginnen zu öffnen, und einen Blick finden, da jemand meine halb geschlossenen Lider sieht, und somit etwas geschieht – nur in diesen seltenen Fällen, diesem Fallen des Körpers also entstehen Liebesmomente.
<G-vec00198-002-s078><dissolve.auflösen><en> Only in very rare cases, when, for example, the closed mouth becomes tired because of its constant resistance, goes slack, light, first at the corners, then increasingly breaks open everywhere, so that another’s tongue begins to find in me, overpowers me with a love, which does not dissolve me, but, rather, makes a body whole, because these are lips, by which I can feel my own, or, for example, when the eyes grow tired, can no longer resist satisfying curiosity and begin to open with my mouth, and find a gaze, since someone sees my half shut lids, and so something happens – only in these rare cases, this falling of the body, therefore, do moments of love arise.
<G-vec00198-002-s098><dissolve.auflösen><de> Aber im Westen ist es einfach, das Ego aufzulösen, im Osten ist es sehr schwierig.
<G-vec00198-002-s098><dissolve.auflösen><en> But in the West it is easy to dissolve the ego, in the East it is very difficult.
<G-vec00198-002-s099><dissolve.auflösen><de> Struvitstein-Auflösung: Urinary S/O Moderate Calorie hilft, Struvitsteine wirksam aufzulösen.
<G-vec00198-002-s099><dissolve.auflösen><en> Struvite dissolution: URINARY S/O helps to dissolve all types of struvite stones.
<G-vec00198-002-s100><dissolve.auflösen><de> Der Organismus ist nicht in der Lage, die Bestandteile von B12 aufzulösen.
<G-vec00198-002-s100><dissolve.auflösen><en> The organism is not able to dissolve the components of B12.
<G-vec00198-002-s101><dissolve.auflösen><de> Als Klang- und Farbtherapeutin helfe ich Menschen und Tieren, Blockaden auf körperlicher, emotionaler und seelischer Ebene aufzulösen und die innere Harmonie zu finden.
<G-vec00198-002-s101><dissolve.auflösen><en> As a sound and colour therapist I help people and animals to dissolve blockages on a physical, emotional and mental level and to find inner harmony.
<G-vec00198-002-s102><dissolve.auflösen><de> Minde-Pouet nahm die Kündigung zum Anlass, die Kriegssammlung aufzulösen und die Zugangsverzeichnisse abzubrechen, die für den Zeitraum Januar bis März noch rund 1.400 Dokumente verzeichneten.
<G-vec00198-002-s102><dissolve.auflösen><en> Minde-Pouet took the occasion of the departure to dissolve the collection and to cancel the entry register, which still listed around 1,400 documents for the period from January to March.
<G-vec00198-002-s103><dissolve.auflösen><de> Es besitzt gute reinigende Eigenschaften und eine gute Fähigkeit, Blut und organische Reste aufzulösen.
<G-vec00198-002-s103><dissolve.auflösen><en> It has good cleansing properties and good ability to dissolve blood and organic residues.
<G-vec00198-002-s104><dissolve.auflösen><de> Sie können die Phiole zwischen Ihren Fingern oder Händen leicht rollen aber rütteln sie nicht, um dich aufzulösen.
<G-vec00198-002-s104><dissolve.auflösen><en> You can roll the vial gently between your fingers or hands but don't shake it to dissolve.
<G-vec00198-002-s105><dissolve.auflösen><de> 5.3 Wenn die Preiserhöhung 10% übersteigt, hat die andere Partei das Recht, den Vertrag für 7 Arbeitstage nach Bekanntgabe der Preiserhöhung aufzulösen.
<G-vec00198-002-s105><dissolve.auflösen><en> 5.3 If the price increase exceeds 10%, the other party has the right to dissolve the agreement for 7 working days after notification of the price increase.
<G-vec00198-002-s106><dissolve.auflösen><de> 10.2 Der Beschluss, diese Satzung zu ändern oder den Verein aufzulösen und das Vereinsvermögen in seiner Gesamtheit zu verwenden, ist nur wirksam, wenn ihm 80 % aller anwesenden oder vertretenen Stimmberechtigten der Mitglieder zustimmen; maßgebend sind gewichtete Stimmen gemäß Ziffer 6.4.
<G-vec00198-002-s106><dissolve.auflösen><en> 10.2 The resolution to amend these Articles of Association or to dissolve the Association and to utilise the assets of the Association completely shall only be legally valid if 80 % of all members entitled to vote present or represented vote in favour hereof; decisive are weighted votes pursuant to Clause 6.4.
<G-vec00198-002-s107><dissolve.auflösen><de> Pillen zur Erhöhung der Immunität sollten nach den Anweisungen des Herstellers dosiert werden, das heißt, nicht mehr als zwei Tabletten pro Tag, mit der Notwendigkeit, mindestens ein Glas Wasser zu trinken, um leichter aufzulösen.
<G-vec00198-002-s107><dissolve.auflösen><en> Pills to increase immunity should be dosed according to the manufacturer’s instructions, that is, no more than two tablets a day, with the need to drink at least one glass of water to dissolve more easily.
<G-vec00198-002-s108><dissolve.auflösen><de> Wir schauen, wo Du immer in das gleiche Muster fällst, um diese Muster aufzulösen.
<G-vec00198-002-s108><dissolve.auflösen><en> We look where you always fall into the same pattern to dissolve these patterns.
<G-vec00198-002-s109><dissolve.auflösen><de> Zudem gibt der Gesetzentwurf den Behörden die Befugnis, NGOs auf der Grundlage vager Anschuldigungen aufzulösen und Angestellte strafrechtlich zu verfolgen.
<G-vec00198-002-s109><dissolve.auflösen><en> It also gives the authorities the power to dissolve NGOs and prosecute staff based on vague allegations. Topics Middle East and North Africa
<G-vec00198-002-s110><dissolve.auflösen><de> Er ist auf einer Reise durch eine urbane Landschaft, in der sich die Natur langsam aufzulösen scheint, aber die Sehnsucht nach einer Vereinigung bleibt und lässt ihn in Nostalgie und Realität schweben.
<G-vec00198-002-s110><dissolve.auflösen><en> He is on a journey through an urban landscape where nature seems to slowly dissolve, but the longing for a union remains, leaving him in a limbo of nostalgia and reality.
<G-vec00198-002-s111><dissolve.auflösen><de> Nach der Gelug-Tradition lehrte der Buddha im 'Höchsten Yoga-Tantra' die tiefgreifendsten Instruktionen zur Umwandlung von sinnlichem Vergnügen in den schnellen Pfad zur Erleuchtung, die andererseits von der Fähigkeit abhängt, die inneren Winde (tibetisch: rlung; Sanskrit: prana) im zentralen Kanal zu sammeln und durch die Macht der Meditation aufzulösen.
<G-vec00198-002-s111><dissolve.auflösen><en> According to the Gelugpa tradition, in Highest Yoga Tantra, the Buddha taught the most profound instructions for transforming sensual pleasure into the quick path to enlightenment, which in turn depends upon the ability to gather and dissolve the inner winds (Sanskrit: prana) into the central channel through the power of meditation.
<G-vec00198-002-s112><dissolve.auflösen><de> Bellezi ist befugt, den Vertrag aufzulösen, wenn der Kunde die Verpflichtungen aus dem Vertrag nicht oder nicht vollständig erfüllt und diese Erfüllung auch, nachdem er schriftlich in Verzug gesetzt worden ist, nicht nachholt.
<G-vec00198-002-s112><dissolve.auflösen><en> Bellezi shall be authorised to dissolve the agreement if the customer does not or not fully comply with the obligations under the agreement and the customer has failed to comply with a notice of default sent.
<G-vec00198-002-s113><dissolve.auflösen><de> Wenn nach vernünftigen Maßstäben Channel Distribution B.V. aufgrund eines der in Artikel 10.2 genannten Umstände nicht verpflichtet ist, eine oder mehrere ihrer Verpflichtungen zu erfüllen, hat sie das Recht, die Erfüllung des Vertrags auszusetzen oder den Vertrag ganz oder teilweise ohne Inanspruchnahme von Gerichten aufzulösen und ohne in irgendeiner Weise für Schadenersatz haftbar zu sein.
<G-vec00198-002-s113><dissolve.auflösen><en> If by reasonable standards Channel Distribution B.V. cannot be required to fulfil one or more of its obligations due to any of the circumstances mentioned in article 10.2. it shall have the right to suspend performance of the agreement or to dissolve the agreement fully or partially, without recourse to the courts, without being liable to provide any form of compensation.
<G-vec00198-002-s114><dissolve.auflösen><de> Wir beginnen, diese Muster aufzulösen, um uns davon zu befreien, dasselbe Verhalten von Leben zu Leben zu wiederholen.
<G-vec00198-002-s114><dissolve.auflösen><en> We begin to dissolve these patterns, to free ourselves from repeating the same behavior from lifetime to lifetime.
<G-vec00198-002-s115><dissolve.auflösen><de> Es wird empfohlen, 70 g Superphosphat nicht als Pulver zuzugeben, sondern die mineralische Substanz in Wasser aufzulösen und das Substrat darauf zu gießen (dies macht den Phosphor für jungen Kohl „verdaulicher“).
<G-vec00198-002-s115><dissolve.auflösen><en> 70 grams of superphosphate is recommended not to be added as a powder, but rather to dissolve the mineral substance in water and pour the substrate onto it (this will make the phosphorus more “digestible” for young cabbage).
<G-vec00198-002-s116><dissolve.auflösen><de> Beim Kochen in heißem Wasser ist es notwendig, die Soda aufzulösen, und dann Wasserstoffperoxid in die resultierende Mischung gießen und alles gründlich schütteln, dann in eine Flasche mit einem Spray gießen.
<G-vec00198-002-s116><dissolve.auflösen><en> When cooking in hot water, it is necessary to dissolve the soda, and then pour hydrogen peroxide into the resulting mixture and shake everything thoroughly, then pour into a bottle with a spray.
<G-vec00198-002-s117><dissolve.auflösen><de> Die Hefe zerbröseln und darin auflösen.
<G-vec00198-002-s117><dissolve.auflösen><en> Crumble the yeast and dissolve it in the milk.
<G-vec00198-002-s118><dissolve.auflösen><de> Gelatine ausdrücken und darin auflösen.
<G-vec00198-002-s118><dissolve.auflösen><en> Squeeze out gelatine and dissolve in wine mixture.
<G-vec00198-002-s119><dissolve.auflösen><de> Milch hinzufügen und Misopaste darin bei mittlerer Hitze auflösen.
<G-vec00198-002-s119><dissolve.auflösen><en> Pour in milk and dissolve miso paste on a medium heat.
<G-vec00198-002-s131><dissolve.auflösen><de> Hier wird Ihr Rücken geschmeidig durchgeknetet und kleine Verspannungen in kurzer Zeit gelöst.
<G-vec00198-002-s131><dissolve.auflösen><en> Your back is kneaded to ensure implausible smoothness and within no time small tensions dissolve into nothing.
<G-vec00198-002-s132><dissolve.auflösen><de> In diesen Mischanlagen können Flüssigkeiten wie Säuren, Laugen und Lösungsmittel miteinander verrührt, Feststoffe in flüssigen Medien gelöst oder auch mehrere Feststoffe miteinander vermischt werden.
<G-vec00198-002-s132><dissolve.auflösen><en> This mixing and blending equipment can be used to mix liquids such as acids, alkalis and solvents with each other, dissolve solids in liquids, or blend several solids with each other.
<G-vec00198-002-s133><dissolve.auflösen><de> Sie kommen in Pulver und in Wasser gelöst, erhalten Sie einen Energydrink mit einer hohen Konzentration von Kohlenhydraten.
<G-vec00198-002-s133><dissolve.auflösen><en> They come in powder and dissolve in water, you get an energy drink with a high concentration of carbohydrates.
<G-vec00198-002-s134><dissolve.auflösen><de> Zur Vorbeugung: Wöchentlich 10 g auf 100 l Aquarienwasser in etwas Wasser gelöst und im Becken verteilt.
<G-vec00198-002-s134><dissolve.auflösen><en> As a preventative measure: Dissolve 10 g per 100 l aquarium water in a little water and disperse in the tank once a week.
<G-vec00198-002-s140><dissolve.auflösen><de> Löse diese Substanz in Wasser und lagere es im Kühlschrank.
<G-vec00198-002-s140><dissolve.auflösen><en> Dissolve this substance into water and keep it in the fridge.
<G-vec00198-002-s141><dissolve.auflösen><de> Löse einen Teelöffel Meersalz im Tee.
<G-vec00198-002-s141><dissolve.auflösen><en> Dissolve 1 teaspoon of sea salt in the tea.
<G-vec00198-002-s142><dissolve.auflösen><de> Sagte Ich erst, Ich liebe die Welt, so setze Ich jetzt ebenso hinzu: Ich liebe sie nicht, denn Ich vernichte sie, wie Ich Mich vernichte: Ich löse sie auf.
<G-vec00198-002-s142><dissolve.auflösen><en> If I first said, I love the world, I now add likewise: I do not love it, for I annihilate it as I annihilate myself; I dissolve it.
<G-vec00198-002-s143><dissolve.auflösen><de> Löse Tropfen in einem halben Glas Wasser oder Saft.
<G-vec00198-002-s143><dissolve.auflösen><en> Dissolve drops in half a glass of water or juice.
<G-vec00198-002-s144><dissolve.auflösen><de> Löse oder mische eine kleine Menge der Substanz in einem Glas mit sauberen Wasser auf und teste sie dann mit einem Lackmustreifen.
<G-vec00198-002-s144><dissolve.auflösen><en> Dissolve or mix a small amount of one substance at a time into a glass of clean water, and then test with a litmus strip.
<G-vec00198-002-s145><dissolve.auflösen><de> Löse die Hefe mit dem Zucker in einer Tasse warmen Wasser auf und stelle sie beiseite.
<G-vec00198-002-s145><dissolve.auflösen><en> Place aside. Mix the active dried yeast with 1 cup warm water and stir well to dissolve.
<G-vec00198-002-s146><dissolve.auflösen><de> Nur in einem guten Zustand haben sie Chancen, gut über die Wintermonate zu kommen: „Schwache Völker löse ich auf und mache aus zwei schwachen Völkern ein starkes Volk“, erklärt Trodtfeld.
<G-vec00198-002-s146><dissolve.auflösen><en> Only if they are in good condition do they have the chance to survive the winter months. “I dissolve weak colonies and put two weak colonies together to build a strong colony,” explains Trodtfeld.
<G-vec00198-002-s147><dissolve.auflösen><de> Löse eine kleine Menge Meersalz in einer Tasse warmen Wassers auf.
<G-vec00198-002-s147><dissolve.auflösen><en> Dissolve a small amount of sea salt in a cup of warm water.
<G-vec00198-002-s148><dissolve.auflösen><de> Löse 10 ml Konzentrat in 200 ml Wasser auf.
<G-vec00198-002-s148><dissolve.auflösen><en> Directions: Dissolve 10 ml concentrate in 200 ml water.
<G-vec00198-002-s149><dissolve.auflösen><de> Löse den Zucker auf.
<G-vec00198-002-s149><dissolve.auflösen><en> Dissolve the sugar.
<G-vec00198-002-s150><dissolve.auflösen><de> Anweisung: Löse 100g (4 Maßeinheiten) Pulver in 200 ml Wasser oder Milch auf.
<G-vec00198-002-s150><dissolve.auflösen><en> Directions: Dissolve 100g (4 measures) of powder in 200 ml of water or milk.
<G-vec00198-002-s151><dissolve.auflösen><de> Also bring mehr Liebe in die materielle Welt und löse das Ego in der Liebe auf.
<G-vec00198-002-s151><dissolve.auflösen><en> So bring more love in this material world and dissolve your ego in love.
<G-vec00198-002-s152><dissolve.auflösen><de> Löse etwas Xylit im Mund auf und behalte den Speichel fünf Minuten im Mund, dies könnte Abhilfe bringen.
<G-vec00198-002-s152><dissolve.auflösen><en> Dissolve some xylitol in your mouth and hold the saliva for 5 minutes, this might help.
<G-vec00198-002-s153><dissolve.auflösen><de> Löse die Tinktur in Wasser auf oder gib sie dir direkt auf die Zunge.
<G-vec00198-002-s153><dissolve.auflösen><en> Dissolve the tincture in water, or place directly on your tongue.
<G-vec00198-002-s154><dissolve.auflösen><de> Löse 10 ml des Getränke-Konzentrats Multi Hypotonic in 650 ml Wasser auf.
<G-vec00198-002-s154><dissolve.auflösen><en> Supplement Facts Directions Dissolve 10 ml Multi Hypotonic concentrate in 650 ml water.
<G-vec00198-002-s155><dissolve.auflösen><de> Löse das Pulver einfach in Wasser auf, verrühre es und Du hast ein köstliches Getränk mit Orangengeschmack.
<G-vec00198-002-s155><dissolve.auflösen><en> Simply dissolve the powder in water, stir and you’ve created a delicious orange-flavoured drink.
<G-vec00198-002-s156><dissolve.auflösen><de> Um eine Salzwasserlösung herzustellen, löse einen Teelöffel Salz in einer Tasse mit warmem Wasser auf.
<G-vec00198-002-s156><dissolve.auflösen><en> To prepare a salt water rinse, dissolve 1 teaspoon of salt in a cup of warm water.
<G-vec00198-002-s157><dissolve.auflösen><de> Solange der Erhalt nicht bestätigt ist, kann der Verbraucher den Vertrag lösen.
<G-vec00198-002-s157><dissolve.auflösen><en> The consumer can dissolve the contract as long as this acceptance has not been confirmed.
<G-vec00198-002-s158><dissolve.auflösen><de> Eine Knochenverstopfung ist schwer zu lösen und kann eine mehrtägige Intensivbehandlung in der Tierklinik erforderlich machen.
<G-vec00198-002-s158><dissolve.auflösen><en> A constipation caused by a bone can be difficult for the body to dissolve and can lead to several days of intensive care at an animal hospital.
<G-vec00198-002-s159><dissolve.auflösen><de> Chromhaltige Typen erfordern höhere Wärmebehandlungstemperaturen, da Chromkarbide schwerer in Lösung zu lösen sind.
<G-vec00198-002-s159><dissolve.auflösen><en> Chromium-bearing grades require higher heat treatment temperatures as chromium carbides are more difficult to dissolve into solution.
<G-vec00198-002-s160><dissolve.auflösen><de> Wärmeanwendungen aller Art werden als wohltuend empfunden, weil sie diesen reflektorischen Hypertonus der Rumpfmuskeln, insbesondere der paravertebralen Rückenstrecker, lösen und die Durchblutung fördern.
<G-vec00198-002-s160><dissolve.auflösen><en> All types of heat application are perceived as comforting, since they dissolve the reflectory hypertonia of the upper body muscles, in particular of the paravertebral dorsal extensor muscles, and encourage better blood circulation.
<G-vec00198-002-s161><dissolve.auflösen><de> Schematische Darstellung der gleichzeitig stattfindenden Absorption und Kompression in einem Kolbenkompressor zum Lösen von Gasen in Flüssigkeiten am Beispiel von Kohlenstoffdioxid.
<G-vec00198-002-s161><dissolve.auflösen><en> Schematic diagram of absorption and compression taking place simultaneously in a reciprocating compressor to dissolve gases in liquids using the example of carbon dioxide.
<G-vec00198-002-s162><dissolve.auflösen><de> Es ist in der Lage, bereits im festen Zustand mit steigender Temperatur in zunehmendem Maße Wolframkarbid zu lösen.
<G-vec00198-002-s162><dissolve.auflösen><en> It has the capability to increasingly dissolve tungsten carbide even in its solid state at increasing temperatures.
<G-vec00198-002-s163><dissolve.auflösen><de> Eine andere Möglichkeit besteht darin, den Stabilisator in einem geeigneten Lösemittel zu lösen und auf die Partikel des Polyalkenamers aufzubringen.
<G-vec00198-002-s163><dissolve.auflösen><en> Another possibility is to dissolve the stabilizer in a suitable solvent and applied to the particles of the polyalkenamer.
<G-vec00198-002-s164><dissolve.auflösen><de> Chemische Reiniger lösen die Farbe, so dass diese noch tiefer in die Poren eindringen können.
<G-vec00198-002-s164><dissolve.auflösen><en> Chemical cleaners dissolve the paint that way it penetrates deeper into the pores.
<G-vec00198-002-s165><dissolve.auflösen><de> Die Enthaarungscremes von Veet lösen die Haare an der Wurzel, sodass das Haar einfach abbricht und Sie bis zu vier Tage stoppelfrei sind.
<G-vec00198-002-s165><dissolve.auflösen><en> Depilatory creams dissolve the hair, leaving a rounded tip at the end of the hair instead of the prickly edge resulting from razors.
<G-vec00198-002-s166><dissolve.auflösen><de> Anwendungshinweis: Als Nahrungsergänzungsmittel, lösen Sie im Mund oder kauen Sie eine Tablette pro Tag.
<G-vec00198-002-s166><dissolve.auflösen><en> Suggested method of administration: As a food additive, dissolve in your mouth or chew one tablet daily.
<G-vec00198-002-s167><dissolve.auflösen><de> Milch lauwarm erwärmen und die Hefe darin lösen.
<G-vec00198-002-s167><dissolve.auflösen><en> Warm lukewarm milk and dissolve the yeast in it.
<G-vec00198-002-s168><dissolve.auflösen><de> Ich spüre emotionale Blockaden anderer Personen wenn sie in meiner Gegenwart sind und kann mit meinen Händen spüren wo sie sich im Körper befinden und diese Energien lösen.
<G-vec00198-002-s168><dissolve.auflösen><en> I feel emotional blockages of other people when they are in my presence and can feel with my hands where they are in the body and dissolve these energies.
<G-vec00198-002-s169><dissolve.auflösen><de> Zum Lösen von Fett und Schmutz verwende einen alkalischen Reiniger auf Wasserbasis; Seifen, Waschmittel oder etwas in Wasser aufgelöstes Backsoda sind gut geeignet, jedoch solltest du wissen, dass alkalische Lösungen die Versiegelung im Laufe der Zeit matt aussehen lassen.
<G-vec00198-002-s169><dissolve.auflösen><en> To dissolve grease and dirt, choose an alkaline, water-based cleaner: soaps, detergents, or a bit of baking soda dissolved in water will do, though should be used sparingly.
<G-vec00198-002-s170><dissolve.auflösen><de> Die Classic Tabs von Ecover lösen kraftvoll mit der Hilfe von Zellstoff-Tensiden hartnäckige Speiserückstände, angebranntes Essen und Fettreste.
<G-vec00198-002-s170><dissolve.auflösen><en> The Ecover Classic Dishwasher Tabs powerfully dissolve stubborn food and grease residues with the help of pulp surfactants.
<G-vec00198-002-s172><dissolve.auflösen><de> Den Inhalt eines Beutels unter Rühren in 500 ml Wasser lösen und alsbald trinken.
<G-vec00198-002-s172><dissolve.auflösen><en> Dissolve the contents of one bag in 500 ml water while stirring and drink immediately.
<G-vec00198-002-s173><dissolve.auflösen><de> Alkohol hat die Fähigkeit, sowohl öl- als auch wasserlösliche Aromen zu lösen.
<G-vec00198-002-s173><dissolve.auflösen><en> Alcohol has the capability to dissolve both oil-soluble and water-soluble flavors.
<G-vec00198-002-s174><dissolve.auflösen><de> Die hydrothermalen Wasser des Upper Geyser Basins sind neutral bis schwach basisch, lösen diverse Mineralien aus dem Vulkangestein und bilden einen idealen Lebensraum für thermophile Mikro-organismen im bis zu 55°C heißen Wasser.
<G-vec00198-002-s174><dissolve.auflösen><en> The hydrothermal waters of the Upper Geyser Basins are neutral to weak alkaline and dissolve several minerals from the volcanic bedrock underground. It is an ideal biotope for thermophile microorganisms living in 131°F (55°C) hot water.
<G-vec00198-002-s175><dissolve.auflösen><de> Ein einfacher Tipp, um hartnäckiges Augen-Make-up besser zu lösen, ist, die Augenlider und Wimpern länger einzuweichen.
<G-vec00198-002-s175><dissolve.auflösen><en> A simple tip to dissolve stubborn eye make-up is to soak lids and lashes for longer.
<G-vec00198-002-s176><dissolve.auflösen><de> Dazu entnehmen Sie den Tank, füllen diesen vor dem Einsetzen des neuen Filters mit Wasser, lösen drei Entkalkungstabletten von JURA im Wasser auf und lassen das Ganze einwirken.
<G-vec00198-002-s176><dissolve.auflösen><en> To do this, remove the tank, fill it with water before fitting the new filter, dissolve three JURA descaling tablets in the water and leave to take effect.
<G-vec00198-002-s177><dissolve.auflösen><de> Einnahme Lösen Sie einen gestrichenen Teelöffel in 200ml Wasser oder Tee auf.
<G-vec00198-002-s177><dissolve.auflösen><en> Dissolve one level teaspoon (1.5g) in 6oz water or tea.
<G-vec00198-002-s178><dissolve.auflösen><de> Lösen Sie die Hefe in 550 ml Wasser und das Salz in die restliche 50 ml auf.
<G-vec00198-002-s178><dissolve.auflösen><en> Dissolve the yeast in 550 ml of water, stir salt in the remaining water.
<G-vec00198-002-s179><dissolve.auflösen><de> Gleiche Architektur, gleiches Engineering sowie die Verwendung der gleichen Applikationssoftware lösen die Grenzen zwischen Drive-based und Controller-based Automation auf.
<G-vec00198-002-s179><dissolve.auflösen><en> The same architecture, the same engineering and use of the same application software dissolve the boundaries between drive-based and controller-based automation.
<G-vec00198-002-s180><dissolve.auflösen><de> Durch intergenerationales energetisches Arbeiten lösen wir sie auf und schaffen so einen neuen Handlungsspielraum.
<G-vec00198-002-s180><dissolve.auflösen><en> Through intergenerational energetic work we dissolve them and create a new room for manoeuvre.
<G-vec00198-002-s181><dissolve.auflösen><de> Die gezeigten Arbeiten lösen den Körper in Rauch auf, teilen ihn in Stücke, legen die Grenzen seiner Kontrollierbarkeit offen und untersuchen die Spuren, die er produziert und zurücklässt.
<G-vec00198-002-s181><dissolve.auflösen><en> The featured works dissolve the body into smoke, partition it into pieces, reveal the limits of its control, and examine the traces it builds and leaves behind.
<G-vec00198-002-s182><dissolve.auflösen><de> Mit der Uniserv Data Quality Cloud lösen Sie Dubletten auf und verhindern neue Dopplungen.
<G-vec00198-002-s182><dissolve.auflösen><en> With the Uniserv Data Quality Cloud you dissolve duplicates and prevent new duplications.
<G-vec00198-002-s183><dissolve.auflösen><de> 3 l des siedenden Wassers lösen die in Form von den feinen Spänen verflachte Seife auf.
<G-vec00198-002-s183><dissolve.auflösen><en> 3 l of boiling water dissolve the soap crushed in the form of thin shavings.
<G-vec00198-002-s184><dissolve.auflösen><de> Wir lösen die Barrieren auf, die für ein schlagendes Herz, das keiner Abwehr bedarf, keine Berechtigung haben.
<G-vec00198-002-s184><dissolve.auflösen><en> We dissolve the barriers that were unwarranted for a beating heart that needs no protection.
<G-vec00198-002-s185><dissolve.auflösen><de> Die dort auftretenden Hochdruckgebiete lösen die Wolken auf und es kommt deshalb zu keinem Niederschlag.
<G-vec00198-002-s185><dissolve.auflösen><en> The high-pressure areas there let the clouds dissolve and there is therefore no precipitate.
<G-vec00198-002-s186><dissolve.auflösen><de> Wenn die Sauce nicht die Konsistenz erereicht, die Sie wünschen, lösen Sie einfach einen Esslöffel Maismehl in etwas kaltem Wein, Wasser oder Brühe auf und geben Sie die Mischung nach und nach in die Sauce, bis diese eindickt.
<G-vec00198-002-s186><dissolve.auflösen><en> If your sauce doesn't reach the consistency you require, simply dissolve 1 tbsp of corn flour in either some cold wine, stock or water and add gradually to the simmering sauce until it thickens.
<G-vec00198-002-s187><dissolve.auflösen><de> So lösen Türken in ihrem Kaffee (siehe auch Cardamom) gerne etwas locoum auf, ein sehr süßes, gummiartiges Konfekt mit starkem Rosenaroma.
<G-vec00198-002-s187><dissolve.auflösen><en> So, Turks dissolve some locoum, a very sweet confectionery of rubbery texture with strong rose fragrance, in their coffee (see also cardamom).
<G-vec00198-002-s188><dissolve.auflösen><de> Am besten lösen Sie die Jodtabletten in einem Glas mit lauwarmem Wasser auf.
<G-vec00198-002-s188><dissolve.auflösen><en> It is best to dissolve the iodine tablets in a glass with lukewarm water.
<G-vec00198-002-s189><dissolve.auflösen><de> Die Eiweißenzyme in diesen Früchten lösen die Gelatine auf und verhindern, dass diese geliert.
<G-vec00198-002-s189><dissolve.auflösen><en> The proteic enzymes in these fruits dissolve the gelatine and prevent it from gelling.
<G-vec00198-002-s190><dissolve.auflösen><de> Lösen Sie die Trockenhefe und den Zucker in lauwarmem Wasser auf.
<G-vec00198-002-s190><dissolve.auflösen><en> Dissolve the yeast and sugar in some water.
<G-vec00198-002-s191><dissolve.auflösen><de> Seine Arbeiten lösen die Grenzen zwischen Kunst und Alltag, passivem Betrachten und aktiver Beteiligung auf.
<G-vec00198-002-s191><dissolve.auflösen><en> His works dissolve the boundaries between art and everyday life, between passive viewing and active participation.
<G-vec00198-002-s192><dissolve.auflösen><de> Indem wir das Licht-Gitternetz über dem Planeten stärken, lösen wir den Plasma-Oktopus auf und ermöglichen es so, dass das Event geschehen kann.
<G-vec00198-002-s192><dissolve.auflösen><en> By strengthening the light grid on the planet we dissolve the plasma octopus and allow the EVENT to become reality.
<G-vec00198-002-s193><dissolve.auflösen><de> Spezielle Dehnübungen sprechen die Meridiane an und lösen Blockaden auf.
<G-vec00198-002-s193><dissolve.auflösen><en> Special stretching exercises address the meridians and dissolve blockages.
<G-vec00198-002-s194><dissolve.auflösen><de> Lösen Sie die abgemessene Menge Professional Sea Salt unter gleichmäßiger Wasserbewegung in einem sauberen Behälter auf.
<G-vec00198-002-s194><dissolve.auflösen><en> Dissolve the measured quantity of Professional Sea Salt in a clean container, stirring evenly all the time.
<G-vec00198-002-s195><dissolve.auflösen><de> Softgel-Kapseln lösen sich schneller auf und führen so innerhalb von wenigen Minuten zu einer harten Erektion.
<G-vec00198-002-s195><dissolve.auflösen><en> Gelatine softgel capsules dissolve faster and allow to achieve hard erection within several minutes.
<G-vec00198-002-s196><dissolve.auflösen><de> Farben und Wörter fließen über die Fassade werden zu abstrakten Bildkompositionen und lösen sich wieder auf, verschiedene Details der Herstellung von Bier werden in die Installation schemenhaft integriert.
<G-vec00198-002-s196><dissolve.auflösen><en> Colors and words flow over the facade and become abstract compositions and dissolve again, various details of the production of beer are schematically integrated into the installation.
<G-vec00198-002-s197><dissolve.auflösen><de> Die Transportfunktion wird von gesunden Venen übernommen, die geklebten lösen sich innerhalb von anderthalb Jahren auf.
<G-vec00198-002-s197><dissolve.auflösen><en> The transport function is performed by healthy veins, and the glued ones dissolve within a year and a half.
<G-vec00198-002-s198><dissolve.auflösen><de> Körperliche und seelische Verspannungen lösen sich, ein verbesserter Zellstoffwechsel fördert physische Genesungsprozesse.
<G-vec00198-002-s198><dissolve.auflösen><en> Physical and mental tensions dissolve, an improved cell metabolism promotes physical recovery processes.
<G-vec00198-002-s199><dissolve.auflösen><de> Energieblockierungen lösen sich.
<G-vec00198-002-s199><dissolve.auflösen><en> Energy blockages dissolve.
<G-vec00198-002-s200><dissolve.auflösen><de> Zur Rechten lösen sich die Bodhisattvas in Avalokiteśvara auf.
<G-vec00198-002-s200><dissolve.auflösen><en> To the right, the bodhisattvas all dissolve into Avalokiteśvara.
<G-vec00198-002-s201><dissolve.auflösen><de> Außerdem lösen sich Alkalien gut in Ethanol.
<G-vec00198-002-s201><dissolve.auflösen><en> In addition, alkalis also dissolve well in ethanol.
<G-vec00198-002-s202><dissolve.auflösen><de> Cialis Super Softgel-Kapseln lösen sich schneller auf und führen so innerhalb von wenigen Minuten zu einer harten Erektion.
<G-vec00198-002-s202><dissolve.auflösen><en> Gelatine softgel capsules dissolve faster and allow to achieve hard erection within several minutes.
<G-vec00198-002-s203><dissolve.auflösen><de> In 4-6 Monaten lösen die Drähte sich vollständig.
<G-vec00198-002-s203><dissolve.auflösen><en> In 4-6 months the threads dissolve completely.
<G-vec00198-002-s204><dissolve.auflösen><de> Während des Kupferraffinationsprozess lösen sich die metallischen Verunreinigungen der Anode im Kupferelektrolyt oder formen einen sogennanten Anodenschlamm.
<G-vec00198-002-s204><dissolve.auflösen><en> During the copper refining process, impurities in the anode dissolve into the electrolyte or form anode slimes.
<G-vec00198-002-s205><dissolve.auflösen><de> Die meisten Pseudoknoten lösen sich während der Verarbeitung wieder.
<G-vec00198-002-s205><dissolve.auflösen><en> Most pseudo-knots dissolve again during processing.
<G-vec00198-002-s206><dissolve.auflösen><de> Die vermeintlich kompakten, natürlichen Dinge lösen sich unter ihren Oberflächen in kontingente Bedeutungen auf, und die scheinbare Einheit des Objekts verdeckt nur noch die Vielheit des Sinns.
<G-vec00198-002-s206><dissolve.auflösen><en> The allegedly compact, natural things dissolve beneath the surface into contingent significances and the visual coherence of objects merely shrouds the plurality of meanings.
<G-vec00198-002-s207><dissolve.auflösen><de> Ballaststoffe lösen sich nicht in Wasser und werden im Magen und Darm fast nicht verdaut.
<G-vec00198-002-s207><dissolve.auflösen><en> Fiber does not dissolve in water and is almost not digested in the stomach and intestines.
<G-vec00198-002-s208><dissolve.auflösen><de> Alle flüssigen Aromen lösen sich gut in Wasser und ergänzen den Köder erfolgreich.
<G-vec00198-002-s208><dissolve.auflösen><en> All liquid flavors dissolve well in water and successfully supplement the bait.
<G-vec00198-002-s209><dissolve.auflösen><de> Kapseln lösen sich einfach in einem Glas Wasser auf und auf diese Weise erhalten wir ein leckeres Getränk, das reich an Mineralien und Vitaminen ist.
<G-vec00198-002-s209><dissolve.auflösen><en> Capsules just dissolve in a glass of water and in this way we obtain a tasty drink that is rich in minerals and vitamins.
<G-vec00198-002-s210><dissolve.auflösen><de> Ätherische Öle lösen sich im Wasser auf, werden mit der warmen Luft eingeatmet und unterstützen so das Immunsystem.
<G-vec00198-002-s210><dissolve.auflösen><en> Essential oils dissolve in water, are breathed in with the warm air ad provide support for the immune system.
<G-vec00198-002-s211><dissolve.auflösen><de> Molybdän und Wolfram lösen sich in Aluminiumschmelze nicht.
<G-vec00198-002-s211><dissolve.auflösen><en> Molybdenum and tungsten do not dissolve in an aluminum melt.
<G-vec00198-002-s212><dissolve.auflösen><de> Die DEFROST-Produkte lösen sich aufgrund des hohen Siedesalzgehalts sehr gut auf und garantieren dadurch ein schnelles Auftauen von Schnee und Glätte.
<G-vec00198-002-s212><dissolve.auflösen><en> Due to their high content of evaporated salt, DEFROST products dissolve very well, which in turn guarantees that snow and ice melt quickly.
<G-vec00198-002-s213><dissolve.auflösen><de> Ohne Trennung lösen sich Zeit und Raum auf, denn sie sind einfach Trennungsmaßnahmen, die wir dem Universum strukturiert und auferlegt haben.
<G-vec00198-002-s213><dissolve.auflösen><en> Without separation, time and space dissolve, because they are simply measures of separation that we have structured and imposed on the universe.
<G-vec00198-002-s214><dissolve.auflösen><de> Kinder über 3 Jahre alt - lösen Sie 1 Päckchen in ½ Glas warmem Wasser einmal am Tag abends auf.
<G-vec00198-002-s214><dissolve.auflösen><en> Children above 3 years of age – dissolve 1 sachet in ½ glass of warm water, once a day in the evening.
<G-vec00198-002-s215><dissolve.auflösen><de> 2 Gramm pro Tag: Lösen Sie 1 Mal pro Tag 1,5 gestrichene Teelöffel* in Wasser, Tee oder Bio-Saft auf, oder rühren Sie in Wasser, Tee oder Bio-Saft auf, oder rühren Sie Fauna Mana in Suppe oder Müsli.
<G-vec00198-002-s215><dissolve.auflösen><en> 2 grams per day: Dissolve 1 times daily 1.5 teaspoons* in a glass of chlorine-free water, tea or organic juice, or stir in the soup of muesli
<G-vec00198-002-s216><dissolve.auflösen><de> Lösen Sie pro Shake 50 bis 100 Gramm (2 bis 4 Messlöffel) Perfect Oats in mindestens 350 ml Milch oder Wasser auf.
<G-vec00198-002-s216><dissolve.auflösen><en> Dissolve per shake 40 to 80 grams (1 to 2 scoops) of Perfect Rice Powder in 350 ml of milk or water.
<G-vec00198-002-s217><dissolve.auflösen><de> Für das beste Ergebnis lösen Sie zuerst eine Komponente in Wasser und dann die andere.
<G-vec00198-002-s217><dissolve.auflösen><en> For the best result, first dissolve one component in water and then the other.
<G-vec00198-002-s218><dissolve.auflösen><de> Lösen Sie 25g (vollen Meter) in 200ml (ein Glas) Wasser oder Magermilch.
<G-vec00198-002-s218><dissolve.auflösen><en> Dissolve 25g (full meter) in 200ml (one glass) of water or skimmed milk.
<G-vec00198-002-s219><dissolve.auflösen><de> Lösen Sie zwei oder mehr Tassen in ein warmes Bad.
<G-vec00198-002-s219><dissolve.auflösen><en> Dissolve two or more cups to into a warm bath.
<G-vec00198-002-s220><dissolve.auflösen><de> Zum Baden und für Hand- und Fussbäder: Lösen Sie 8-10 Tropfen Jasmineöl in Honig oder Milch auf und giessen Sie es ins Badewasser.
<G-vec00198-002-s220><dissolve.auflösen><en> For bath: Dissolve 8-10 drops of spearmint essential oil in a tablespoon of honey or STENDERS bath milk that has been mixed with a little water.
<G-vec00198-002-s221><dissolve.auflösen><de> Diese Extraktion löst die gebundenen Formen der Metallionen nicht, Deshalb sind die Metallionen der MMI-Lösungen die chemisch aktive oder "mobile" Komponente der Probe.
<G-vec00198-002-s221><dissolve.auflösen><en> This extraction does not dissolve the bound forms of the metal ions. Thus, the metal ions in the MMI solutions are the chemically active or ‘mobile’ component of the sample.
<G-vec00198-002-s222><dissolve.auflösen><de> Es ist wasserlöslich und löst leicht Chlorophyll auf, wodurch der Geschmack des Produkts grasig und bitter ist.
<G-vec00198-002-s222><dissolve.auflösen><en> It is water soluble and will easily dissolve chlorophyll, due to which the flavor of the product is grassy and bitter.
<G-vec00198-002-s223><dissolve.auflösen><de> Löst die Wolken durch das Beobachten eines ausgewogenen Leben mit gesunder Gewohnheiten.
<G-vec00198-002-s223><dissolve.auflösen><en> Dissolve the clouds by observing a balanced life with healthy habits.
<G-vec00198-002-s224><dissolve.auflösen><de> Bei der Anwendung verwandelt sich der seifenfreie Reiniger in einen erfrischenden Schaum, der Make-Up löst und verstopfte Poren reinigt, um dir einen sauberen und klaren Teint zu schenken.
<G-vec00198-002-s224><dissolve.auflösen><en> The soap-free cleanser transforms into a refreshing foam upon application, working to dissolve makeup and unclog pores for a cleansed and purified complexion.
<G-vec00198-002-s225><dissolve.auflösen><de> PreLavan Extra bietet eine außergewöhnlich gute Schaumleistung und löst damit viele verschiedene Verschmutzungen von der Fahrzeugoberfläche.
<G-vec00198-002-s225><dissolve.auflösen><en> PreLavan Extra delivers exceptionally good foaming action, helping it to dissolve many different kinds of dirt from vehicle surfaces.
<G-vec00198-002-s226><dissolve.auflösen><de> Zwischen den Anoden und der Hülle (Masse) wird ein konstanter Strom angelegt, welcher dafür sorgt, dass sich Kupfer im Seewasser löst.
<G-vec00198-002-s226><dissolve.auflösen><en> A constant current is applied between the anodes and the hull (mass), which causes copper to dissolve in the seawater.
<G-vec00198-002-s227><dissolve.auflösen><de> Während sich die meisten AHA (Alpha-Hydroxysäuren)-Seren nur auf den Peeling-Aspekt konzentrieren, der manchmal zu Irritationen führen kann, ist dieser Multitasking-Booster so formuliert, dass er nicht nur abgestorbene Hautzellen sanft löst, sondern auch Feuchtigkeit spendet und die Hautschutzbarriere dank enthaltener Hyaluronsäure, Niacinamid und essentiellen Fettsäuren aus organischem Hagebutten- und Tamanuöl stärkt.
<G-vec00198-002-s227><dissolve.auflösen><en> While most AHA (alpha-hydroxy acids) serums focus only on the exfoliation aspect that can sometimes lead to tightness and irritation, this multitasking booster is formulated to not only gently dissolve dead skin cells but also replenish moisture and strengthen the skin’s delicate barrier, with its hydrating blend of Hyaluronic Acid, Niacinamide and essential fatty acids from Organic Rosehip + Tamanu Oil.
<G-vec00198-002-s228><dissolve.auflösen><de> Der Fall inspirierte Alex Anwandter zu seinem beeindruckend vielschichtigen Debüt: Mit großem Feingefühl spürt er in der Zurückgezogenheit des Vaters dem gewaltsamen Druck eingeschworener Männlichkeitsnormen nach – und löst sie im bunten queeren Lebenstraum Pablos auf.
<G-vec00198-002-s228><dissolve.auflösen><en> This incident inspired Alex Anwandter to make his impressively multi-layered debut. Demonstrating great sensitivity, he traces in the figure of the reclusive father the enormous pressure that exists to adhere to the fixed norms of masculinity – only to dissolve these norms in Pablo’s dream of living a life that is vibrantly queer.
<G-vec00198-002-s229><dissolve.auflösen><de> Der CO2 Nano Diffusor aus Glas löst bis zu 98% des durchströmenden CO2.
<G-vec00198-002-s229><dissolve.auflösen><en> These CO2 diffusers in bowl style dissolve up to 98% of the CO2 running through them.
<G-vec00198-002-s230><dissolve.auflösen><de> Ethanol ist ein sehr beliebtes Lösungsmittel, da es sowohl polare (hydrophile) als auch unpolare (hydrophobe / lipophile) Substanzen löst.
<G-vec00198-002-s230><dissolve.auflösen><en> Ethanol is a very popular solvent since it ethanol dissolve both polar (hydrophilic) and nonpolar (hydrophobic/lipophilic) substances.
<G-vec00198-002-s231><dissolve.auflösen><de> Das Kristallsalz in Verbindung mit Wasser löst im Körper überflüssige oder giftige Abfallprodukte und fördert die Entschlackung.
<G-vec00198-002-s231><dissolve.auflösen><en> Crystal salt combined with water will dissolve all the superfluous and poisonous waste products of our body so as to improve detoxification.
<G-vec00198-002-s232><dissolve.auflösen><de> Löst in Milchschokolade.
<G-vec00198-002-s232><dissolve.auflösen><en> Dissolve in milk chocolate.
<G-vec00198-002-s233><dissolve.auflösen><de> Wahre Barmherzigkeit, die selbstlos ist, löst menschliche Anschauungen auf.
<G-vec00198-002-s233><dissolve.auflösen><en> True compassion, which is selfless, will dissolve human notions.
<G-vec00198-002-s234><dissolve.auflösen><de> Wenn die Ehegatten jedoch seit mindestens drei Jahren nicht mehr zusammenleben, löst das Gericht die Ehe auf, wenn sie gescheitert ist.
<G-vec00198-002-s234><dissolve.auflösen><en> However, if the spouses have not been living together for at least three years, the court will dissolve the marriage if it has broken down.
<G-vec00198-002-s235><dissolve.auflösen><de> Löst euer Ego in eurer Liebe auf.
<G-vec00198-002-s235><dissolve.auflösen><en> Let your ego dissolve in love.
<G-vec00198-002-s236><dissolve.auflösen><de> Also bietet der Buddha eine dritte, tauglichere Alternative an: Man atmet durch das Unbehagen hindurch und löst es so auf.
<G-vec00198-002-s236><dissolve.auflösen><en> So the Buddha provides a third, more skillful alternative: Breathe through your discomfort and dissolve it away.
<G-vec00198-002-s237><dissolve.auflösen><de> Ein organischer Fleck löst sich leicht mit einem weichen Bürstenkopf, während ein metallischer Fleck davon unbeeindruckt bleibt.
<G-vec00198-002-s237><dissolve.auflösen><en> An organic stain will dissolve easily with a soft head brush, whereas a metal stain will stay put.
<G-vec00198-002-s238><dissolve.auflösen><de> Die Verbindung zwischen den einzelnen Bildelementen löst sich nicht in einem spontanen Erkenntnisprozess auf, soll den Betrachter dagegen irritieren und konfrontieren.
<G-vec00198-002-s238><dissolve.auflösen><en> The link between the various pictorial elements does not dissolve within a spontaneous cognitive process; rather it is meant to unsettle and confront the viewer.
<G-vec00198-002-s239><dissolve.auflösen><de> Ohne die regelmäßige Zugabe von Phosphaten löst sich der Kesselstein in den Bleirohren auf und das durchfließende Wasser kommt mit den Rohrwänden in direkten Kontakt.
<G-vec00198-002-s239><dissolve.auflösen><en> Without the regular addition of phosphates to the water, the scale inside the lead pipes will dissolve, exposing the inside of the pipe itself to the water passing through it.
<G-vec00198-002-s240><dissolve.auflösen><de> Das Granulat löst sich vollständig in der Zunge auf und hat einen angenehmen Geschmack, was vor allem bei der Einnahme von Medikamenten bei kleinen Kindern wichtig ist.
<G-vec00198-002-s240><dissolve.auflösen><en> The granules completely dissolve in the tongue and have a pleasant taste, which is especially important when taking medication by young children.
<G-vec00198-002-s241><dissolve.auflösen><de> Während des Tages wird empfohlen, alkalisches Mineralwasser ohne Gas zu trinken, Azidose (saure Reaktion des Mediums) zu beseitigen, die sich nach einem reichlichen festlichen Fest entwickelt, und Getränke zu trinken, um die Leberarbeit zu erleichtern: Kräutertee aus Kamille, Preiselbeeren, Honigwasser (ein Esslöffel Honig löst sich auf ein Glas warmes Wasser), warme natürliche Traube und süßer Apfelsaft.
<G-vec00198-002-s241><dissolve.auflösen><en> During the day, it is recommended to drink alkaline mineral water without gas, eliminating acidosis (acid reaction of the medium), which develops after a plentiful festive feast, and drink drinks to facilitate the work of the liver: herbal tea from chamomile, cowberries, honey water (a tablespoon of honey dissolve in a glass of warm water), warm natural grape and sweet apple juice.
<G-vec00198-002-s242><dissolve.auflösen><de> Während der Eröffnung beginnt der massive Eisblock zu schmelzen und die Figur des Schweizer Künstlers löst sich allmählich vor den Augen der Besucher auf.
<G-vec00198-002-s242><dissolve.auflösen><en> During the opening of the exhibition, the massive block of ice will begin to melt, and the figure of the Swiss artist will gradually dissolve right before the eyes of the visitors.
<G-vec00198-002-s243><dissolve.auflösen><de> Der Duft löst sich allmählich im Wasser, das den Fisch anlockt.
<G-vec00198-002-s243><dissolve.auflösen><en> The fragrance will gradually dissolve in the water luring the fish.
<G-vec00198-002-s247><dissolve.auflösen><de> Anfahrt: Man löst 40 g Iso Whey in 250 ml kaltem Wasser und trinken Sie nach dem Training.
<G-vec00198-002-s247><dissolve.auflösen><en> Flavor: Strawberry Directions: Dissolve 40 g of Iso Whey in 250 ml of cold water and take it after exercise.
<G-vec00198-002-s248><dissolve.auflösen><de> Präsentation: Flasche mit 1000 g Geschmack: Schokolade Anfahrt: Man löst 40 g Iso Whey in 250 ml kaltem Wasser und trinken Sie nach dem Training.
<G-vec00198-002-s248><dissolve.auflösen><en> Presentation: Pack with 1000 g Flavor: Chocolate Directions: Dissolve 40 g of Iso Whey in 250 ml of cold water and take it after exercise.
<G-vec00198-002-s268><dissolve.auflösen><de> Da das Wasser immer stärker mit Zucker gesättigt sein wird, wird es mit der Zeit immer länger dauern, bis sich der Zucker aufgelöst hat.
<G-vec00198-002-s268><dissolve.auflösen><en> As the water becomes more saturated with sugar, it will take longer for it to dissolve in the water.
<G-vec00198-002-s269><dissolve.auflösen><de> Fügen Sie das Bienenwachs hinzu und warten Sie, bis es sich vollständig aufgelöst hat.
<G-vec00198-002-s269><dissolve.auflösen><en> Add the beeswax and wait for it to dissolve completely.
<G-vec00198-002-s270><dissolve.auflösen><de> Tauchen Sie in das Bad und lassen Sie die Salze sich auflösen, um die luxuriösen Inhaltsstoffe freizusetzen.
<G-vec00198-002-s270><dissolve.auflösen><en> Dip into the bath and let the salts dissolve to release the luxurious ingredients.
<G-vec00198-002-s271><dissolve.auflösen><de> Unerwartet deshalb, weil diese scheinbaren Unterschiede, die häufig Vorurteile hinsichtlich der erzieherischen und sozialen Leistung von Schulen wie der Pietro Mancini wecken, sich auflösen, sobald man die Schwelle überschreitet.
<G-vec00198-002-s271><dissolve.auflösen><en> Unexpected, because these apparent differences, often leading to prejudices regarding the academic and social performance of schools such as the Pietro Mancini school, dissolve as soon as you step inside.
<G-vec00198-002-s272><dissolve.auflösen><de> Ich verstehen auch, wie Mantras dazu führen können, dass subtile Energiewinde in den Zentralkanal eintreten und sich dort auflösen, um Zugang zum subtilsten Energiewind und dem Geist des klaren Lichts zu herhalten.
<G-vec00198-002-s272><dissolve.auflösen><en> And how mantra can also cause the subtle energy-winds to enter and dissolve in the central channel, gaining access to the subtlest energy-wind and clear light mind.
<G-vec00198-002-s273><dissolve.auflösen><de> Albert Schweitzer hat die Fantasie so gedeutet, daß die drei Teile die menschlichen Alterstufen darstellen: Im ersten Teil (très vitement) haben wir den jungen Springinsfeld vor uns, im zweiten Teil (lentement), wo sich die Akkorde nun in arpeggiohaften Figuren über einen langsam herabsteigenden Bass auflösen, das hohe Alter.
<G-vec00198-002-s273><dissolve.auflösen><en> During the first part (trés vitement), we accompany an adolescent romping around; the second part (gravement) which its rich and plentiful chords represents the abundance of life lived at its fullest, whereas the third part (lentement), in which the chords dissolve into Arpeggios-like ornaments in harmony with a slowly descending bass, reminds us of old age.
<G-vec00198-002-s274><dissolve.auflösen><de> Da diese Membranen aus Fett bestehen und diese Lösungsmittel sich in Fett auflösen, versteht man warum die PCBs und das Benzol sich dort akkumulieren, und warum die weißen Blutkörperchen dann ihre besonderen Fähigkeiten verlieren.
<G-vec00198-002-s274><dissolve.auflösen><en> Since the membranes are made of fat, and these solvents dissolve in fat, it is understandable why PCBs and benzene accumulate there and why the white cells then lose their special powers.
<G-vec00198-002-s275><dissolve.auflösen><de> Bei genauerem Hinsehen folgt er der Logik gründerzeitlicher Zimmerfluchten, deren Raumgrenzen sich in moderner Offenheit auflösen.
<G-vec00198-002-s275><dissolve.auflösen><en> When you take a closer look, you can see that is based on the logic of the Gründerzeit’s suite of rooms, whose spatial borders dissolve in modern openness.
<G-vec00198-002-s276><dissolve.auflösen><de> Bekannte Formen, Produkte, Wörter und Symbole werden in unbekannten, scheinbar falschen Kontexten arrangiert, wodurch sich die Grenzen zwischen Kultobjekt und Massenprodukt sowie Gläubiger und Konsument auflösen.
<G-vec00198-002-s276><dissolve.auflösen><en> Gonné’s works originate to an experimental field between religion and mass consumption, which tickles in the double standards of the believer or the consumer and dissolve the borders between cult object and mass product.
<G-vec00198-002-s277><dissolve.auflösen><de> Du kannst natürlich weiße Beißerchen erzielen mit Mr Blanc Express Zahnweißstreifen, einem Vorrat von peroxidfreien Zahnweißstreifen, die sich auf den Zähnen auflösen, um dein Lächeln unterwegs sicher weiß zu machen und aufzuhellen.
<G-vec00198-002-s277><dissolve.auflösen><en> Description Achieve natural pearly whites with Mr Blanc's Express Teeth Whitening Strips, a supply of peroxide-free whitening strips that dissolve on the teeth to safely whiten and brighten your smile, on-the-go.
<G-vec00198-002-s278><dissolve.auflösen><de> Das kleine Element ist die Familie, sie wird sich schneller auflösen als die große Platte.
<G-vec00198-002-s278><dissolve.auflösen><en> The small element is the family, it will dissolve faster than the big plate.
<G-vec00198-002-s279><dissolve.auflösen><de> Diese sollen unter die Zunge gelegt werden, so dass sie sich auflösen kann.
<G-vec00198-002-s279><dissolve.auflösen><en> These are meant to be put under the tongue so that they can dissolve.
<G-vec00198-002-s280><dissolve.auflösen><de> Unsere TIPS sind recycelbar und dürfen über die Toilette entsorgt werden, da sie sich im Wasser auflösen (wie Toilettenpapier) und die Toilette nicht verstopfen.
<G-vec00198-002-s280><dissolve.auflösen><en> Our TIPS are recyclable and may be disposed of via the toilet as they dissolve in the water (like toilet paper) and will not clog the toilet..
<G-vec00198-002-s281><dissolve.auflösen><de> Ist es einmal aktiviert, benutzt man auf der zweiten Stufe der Anuttarayoga-Praxis, der Vollständigkeitsstufe, verschiedenste Methoden, um die Blockaden der Kanalknoten zu beseitigen und die Energiewinde in den Zentralkanal eintreten, dort verbleiben und sich auflösen zu lassen.
<G-vec00198-002-s281><dissolve.auflösen><en> Once activated, then on the second stage of anuttarayoga practice, the complete stage, you employ various methods to unblock the channel-knots and to cause the energy-winds to enter, abide, and dissolve in the central energy-channel.
<G-vec00198-002-s282><dissolve.auflösen><de> Nichts leichter als das: er brauchte bloß Detergentien in die Behälter zu träufeln, und ihre Zellmembranen würden sich auflösen.
<G-vec00198-002-s282><dissolve.auflösen><en> That would be simple enough. He could add detergent to the containers and their cell membranes would dissolve.
<G-vec00198-002-s283><dissolve.auflösen><de> Im Video wischen und zoomen sie sich auf einem iPad durch das Material, identifizieren Verwandte und rekonstruieren Familienlinien, die sich in den Rhythmen des Soundtracks auflösen.
<G-vec00198-002-s283><dissolve.auflösen><en> The video shows them swiping and zooming through the images on an iPad, identifying relatives and reconstructing lineages that dissolve in the soundtrack’s rhythms.
<G-vec00198-002-s284><dissolve.auflösen><de> Granulate, die zu Tabletten gepresst werden, sollten möglichst hydrophil sein, damit sie gut benetzt werden und sich schnell auflösen.
<G-vec00198-002-s284><dissolve.auflösen><en> Granulates, which are compressed to form tablets, should be as hydrophilic as possible to ensure that they are easily wetted and dissolve quickly.
<G-vec00198-002-s285><dissolve.auflösen><de> Danach wird dieser Wafer mit gerichteten Strahlen aus Galliumatomen und Arsenmolekülen bedampft, die sich in den Galliumtröpfchen auflösen.
<G-vec00198-002-s285><dissolve.auflösen><en> Then, this wafer is subjected to directed beams of gallium atoms and arsenic molecules that dissolve in the gallium droplets.
<G-vec00198-002-s286><dissolve.auflösen><de> BioSilicon kann sich dank seiner Halbleitereigenschaften im Körper mit kontrollierter Geschwindigkeit auflösen und dabei über Stunden, Tage, Monate oder sogar Jahre hinweg langsam Medikamente freisetzen.
<G-vec00198-002-s286><dissolve.auflösen><en> BioSilicon's semiconductor properties enable it to dissolve in the body at a controlled rate while slowly releasing drugs over hours, days, months, or even years.
<G-vec00198-002-s287><dissolve.auflösen><de> Im Gegenteil, nach dem stressigen Arbeitstag sehnt mein Körper sich nach Entspannung und meine Gedanken wollen sich in Nebel auflösen.
<G-vec00198-002-s287><dissolve.auflösen><en> On the contrary, after the stressful day at work my body longs for relaxation and my thoughts want to dissolve into mist.
<G-vec00198-002-s288><dissolve.auflösen><de> Lasse das Salz sich vor Gebrauch in dem Wasser auflösen.
<G-vec00198-002-s288><dissolve.auflösen><en> Allow the salt to dissolve in the water before use.
<G-vec00198-002-s289><dissolve.auflösen><de> Den Zucker und das Wasser in einen Topf geben und bei mittlerer Hitze aufkochen lassen, damit sich der Zucker auflöst.
<G-vec00198-002-s289><dissolve.auflösen><en> Combine the sugar and water in a small saucepan and bring to a boil over medium-high heat, stirring often to dissolve the sugar.
<G-vec00198-002-s290><dissolve.auflösen><de> Die nächsten 12 Monate könnten ausschlaggebend für die Feststellung sein, ob dieser Vertrag gestärkt wird oder sich langsam auflöst.
<G-vec00198-002-s290><dissolve.auflösen><en> The next 12 months could be pivotal in determining whether this compact will be strengthened or will slowly dissolve.
<G-vec00198-002-s291><dissolve.auflösen><de> Benutze bei der Herstellung dieser Lösung heißes Wasser, damit sich das Natron leichter auflöst.
<G-vec00198-002-s291><dissolve.auflösen><en> When making this solution, use hot water to help the baking soda dissolve more easily.
<G-vec00198-002-s292><dissolve.auflösen><de> Indem du die Mischung umrührst, während sie sich erhitzt, stellst du sicher, dass die Hitze gleichmäßig verteilt wird und der Zucker sich schneller auflöst.
<G-vec00198-002-s292><dissolve.auflösen><en> Stirring the mixture as it heats up promotes even heat distribution and will encourage the sugar to dissolve more swiftly.
<G-vec00198-002-s293><dissolve.auflösen><de> Gib weiteren Zucker hinein, bis er sich nicht mehr auflöst.
<G-vec00198-002-s293><dissolve.auflösen><en> Keep adding sugar until no more will dissolve.
<G-vec00198-002-s294><dissolve.auflösen><de> Wave So wie eine einzige Welle sich im unendlichen Ozean auflöst, verschmilzt die Wandleuchte Wave perfekt mit sowohl traditionellen als auch modernen Inneneinrichtungen.
<G-vec00198-002-s294><dissolve.auflösen><en> Wave Just like a single wave will dissolve in the endless ocean, the Wave wall light fixture will blend effortlessly with both traditional and contemporary interior designs.
<G-vec00198-002-s295><dissolve.auflösen><de> Talk Fusion behält sich das Recht vor, alle Geschäftspartnerverträge mit einer Frist von 30 Tagen zu kündigen, wenn das Unternehmen: (1) den Geschäftsbetrieb einstellt; (2) sich als Geschäftseinheit auflöst oder (3) den Vertrieb seiner Produkte und/oder Services über Direktvertriebskanäle einstellt.
<G-vec00198-002-s295><dissolve.auflösen><en> Paparazzi reserves the right to terminate all Consultant Agreements upon 30 days notice if the Company elects to: (1) cease business operations; (2) dissolve as a business entity; or (3) terminate distribution of its products and/or services via direct selling channels.
<G-vec00198-002-s296><dissolve.auflösen><de> Bei unserer neuen proprietären Wirkstoffkombination machen wir uns die Quick-Melt-Technologie zunutze, um Ihnen eine großartig schmeckende Sublingual-Tablette anzubieten, die sich in weniger als 1 Minute auflöst.
<G-vec00198-002-s296><dissolve.auflösen><en> Formula - Our proprietary formula utilizes a quick-melt technology to provide you with a great tasting tablet that will dissolve in less than 1 minute.
<G-vec00198-002-s297><dissolve.auflösen><de> Nachdem Christian den Tank vor 2 Jahren in der Werft aufgeschnitten hatte (um den Dreck von 25 Jahren raus zu putzen), versiegelte er den Tank mit rotem Silikon, das jetzt begann sich aufzulösen.
<G-vec00198-002-s297><dissolve.auflösen><en> After Christian had cut open the diesel tank 2 years ago in the boatyard (in order to clean out the goo that had accumulated over 25 years) he resealed the tank with red silicone which now started to dissolve.
<G-vec00198-002-s298><dissolve.auflösen><de> „Moksha“ kann sowohl als tatsächlicher spiritueller „Durchbruch“ verstanden werden, nach dem sich die Mysterien des Seins aufzulösen scheinen als auch als bewusst beibehaltenes Stadium, in dem du die Bedeutung von Mitgefühl, Selbstlosigkeit und Akzeptanz erkennst.
<G-vec00198-002-s298><dissolve.auflösen><en> Moksha can simultaneously be understood as a literal spiritual “breakthrough” after which the mysteries of existence seem to dissolve, or as a purposefully maintained state that recognizes the need for compassion, selflessness and acceptance.
<G-vec00198-002-s299><dissolve.auflösen><de> In allen diesen Verfahren kann das Ausflockungsmittel-Pulver für eine beträchtliche Zeitspanne mit der Aufschlämmung in Kontakt sein, bevor es seinen Ausflockungs- Effekt vervollständigen muss, und somit hat das Pulver Zeit, sich aufzulösen.
<G-vec00198-002-s299><dissolve.auflösen><en> In all these processes, the flocculant powder can be in contact with the slurry for a considerable time before it needs to complete its flocculation effect, and so there is time for the powder to dissolve.
<G-vec00198-002-s300><dissolve.auflösen><de> Da Bilirubin, das in Wasser indirekt ist, nicht die Eigenschaft hat, sich aufzulösen, wird es selbst bei einer signifikanten Zunahme der Analyse keine Abweichungen von der Norm geben.
<G-vec00198-002-s300><dissolve.auflösen><en> But, since bilirubin indirect in water does not have the property to dissolve, even with its significant increase in the analysis there will be no deviations from the norm.
<G-vec00198-002-s301><dissolve.auflösen><de> Zahnverfall ist eine Infektion im Zahn, bei der der Zahnschmelz aufgrund von Bakterienverfall beginnt, sich aufzulösen .
<G-vec00198-002-s301><dissolve.auflösen><en> Dental decay is an infection in your tooth where the enamel begins to dissolve in response to acid produced by bacteria.
<G-vec00198-002-s302><dissolve.auflösen><de> Das Problem ist, dass alles sich aufzulösen droht.
<G-vec00198-002-s302><dissolve.auflösen><en> The problem is that everything threatens to dissolve.
<G-vec00198-002-s303><dissolve.auflösen><de> Wie sich diese von der Oberfläche abheben, hängt von der jeweiligen Farbkombination ab: Einige verfügen über einen deutlich grafischen Look, andere scheinen sich im Hintergrund aufzulösen und bilden einen Mélange-Effekt.
<G-vec00198-002-s303><dissolve.auflösen><en> The way these emerge from the surface depends on the colourway in question: some have a pronounced graphic look, others seem to dissolve into the background and have a melange expression.
<G-vec00198-002-s304><dissolve.auflösen><de> Die Methode der Verwendung ist ziemlich einfach, genug der richtigen Menge des Medikaments, um sich in Wasser aufzulösen und ein paar Schlucke zu trinken.
<G-vec00198-002-s304><dissolve.auflösen><en> The method of use is quite simple, enough of the right amount of the drug to dissolve in water and drink a few sips.
<G-vec00198-002-s305><dissolve.auflösen><de> Ab einem bestimmten pH-Wert fehlt jedoch nicht nur der Baustoff und die Kalkbildung wird immer schwieriger, sondern die Kalkschalen beginnen sogar sich aufzulösen.
<G-vec00198-002-s305><dissolve.auflösen><en> However, as from a certain pH value not only the building material is absent, the calcification process itself becomes increasingly more difficult and the lime shells even start to dissolve.
<G-vec00198-002-s306><dissolve.auflösen><de> Der granitbedeckte Sitzplatz scheint sich im Wasser aufzulösen.
<G-vec00198-002-s306><dissolve.auflösen><en> The granite-covered rest area appears to dissolve in the water.
<G-vec00198-002-s307><dissolve.auflösen><de> In dieser Praxis kreieren wir Form, um ihr zu erlauben, sich aufzulösen, indem wir sie weggeben.
<G-vec00198-002-s307><dissolve.auflösen><en> In this practice we create form in order to allow it to dissolve in giving it away.
<G-vec00198-002-s308><dissolve.auflösen><de> Das Zentralkomitee bat die sozialdemokratischen Mitglieder des Sowjets darum: (1) den Sowjet einzuladen, das Programm der SDAPR anzunehmen und, wenn das einmal gemacht worden sei, die Führung der Partei anzuerkennen und „sich schließlich in sie aufzulösen“; (2) falls der Sowjet es ablehne, das Programm anzunehmen, den Sowjet zu verlassen und das antiproletarische Wesen solcher Organisationen zu entlarven; (3) wenn der Sowjet, während er es ablehne, das Programm anzunehmen, sich das Recht vorbehalte, seine politischen Standpunkt in jedem Fall zu entscheiden, als er auftauche, im Sowjet zu bleiben aber sich das Recht vorzubehalten, über „die Absurdität einer solchen politischen Führung“ auszusagen.
<G-vec00198-002-s308><dissolve.auflösen><en> The central committee asked the Social Democratic members of the Soviet: (1) to invite the soviet to accept the RSDLP’s program and, when this was done, to recognise the leadership of the party and “ultimately dissolve in it”; (2) if the soviet refused to accept the program, to leave the soviet and expose the anti-proletarian nature of such organisations; (3) if the soviet, while refusing to accept the program, reserved to itself the right to decide its political stand in every case as it came up, to stay in the soviet but reserve the right to speak out on “the absurdity of such political leadership.”
<G-vec00198-002-s309><dissolve.auflösen><de> Unter der Belagerung des Volkes hatte die Versammlung keine andere Wahl, als den König zu suspendieren und sich aufzulösen.
<G-vec00198-002-s309><dissolve.auflösen><en> Under siege from the people, the Assembly had no alternative but to suspend the king and dissolve itself.
<G-vec00198-002-s310><dissolve.auflösen><de> Alles war in Bewegung, so als wären die Bäume nur Ideen von Bäumen, so vergänglich wie ein Gemälde, das drohte, sich aufzulösen, wenn Christy es berührte.
<G-vec00198-002-s310><dissolve.auflösen><en> Everything wavered, like the trees were only the ideas of trees, as ephemeral as a painting, threatening to dissolve if Christy merely reached out and touched them.
<G-vec00198-002-s311><dissolve.auflösen><de> In der Chemie: Mischung von zwei Substanzen, die sich gegenseitig nicht komplett lösen oder nicht vollständig miteinander chemisch reagieren können.
<G-vec00198-002-s311><dissolve.auflösen><en> In chemistry: mixing of two substances that cannot dissolve each other completely or react with each other completely.
<G-vec00198-002-s312><dissolve.auflösen><de> Im Übrigen ist in diesem Fall auch der Anbieter berechtigt, sich vom Vertrag zu lösen.
<G-vec00198-002-s312><dissolve.auflösen><en> Furthermore, in such event Quantum Courage is also entitled to dissolve the contract.
<G-vec00198-002-s313><dissolve.auflösen><de> Denn wie Wissenschaftler bereits lange wissen, lädt sich eine mineralische Oberfläche auch auf, wenn sie von unbewegtem Wasser benetzt wird, weil sich dabei manche Ionen besser lösen als andere.
<G-vec00198-002-s313><dissolve.auflösen><en> After all, as scientists have already known for a long time, a mineral surface acquires a charge if it is dampened with static water because some ions dissolve better than others.
<G-vec00198-002-s314><dissolve.auflösen><de> ACHTUNG: Bei zu viel Laserleistung oder einer zu hohen Auflösung kann der Stoff sofort oder spätestens nach dem ersten Waschgang reißen bzw können sich Fasern lösen.
<G-vec00198-002-s314><dissolve.auflösen><en> CAUTION: Using too much laser power or resolution which is too high can tear the fabric or dissolve the fibers, immediately or after the first wash at the latest.
<G-vec00198-002-s315><dissolve.auflösen><de> Ein auf diese Art befestigter Kickstarter wird sich im Betrieb nicht mehr lösen und die Verzahnung hält ewig.
<G-vec00198-002-s315><dissolve.auflösen><en> A fortified in this way Kickstarter will no longer dissolve in the operation and the toothing lasts forever.
<G-vec00198-002-s316><dissolve.auflösen><de> Im Anschluss habe ich alles in einem Mörser vermengt, damit die Pigmente noch feiner werden und sich besser lösen.
<G-vec00198-002-s316><dissolve.auflösen><en> After this I used a mortar for mixing, to finen the pigments in order to allow it to dissolve better.
<G-vec00198-002-s317><dissolve.auflösen><de> Der Begriff "hinreichend wasserlöslich" bedeutet, dass sich die Mittel leicht in den anderen Bestandteilen der Zusammensetzung lösen (und Abtrennung davon vermeiden).
<G-vec00198-002-s317><dissolve.auflösen><en> The term "sufficiently water-soluble" means that the agents readily dissolve in the other ingredients of the composition (and separation avoid thereof).
<G-vec00198-002-s318><dissolve.auflösen><de> Als Staubsammler verwenden sie einen Behälter mit Wasser, durch den Staubpartikel sich lösen und darin absetzen.
<G-vec00198-002-s318><dissolve.auflösen><en> As a dust collector, a container of water is used in them, passing through which dust particles dissolve and settle in it.
<G-vec00198-002-s319><dissolve.auflösen><de> Es ist unklar, ob freigesetzte Partikel in der Umwelt stabil sind oder sich in einer bestimmten Zeit oder unter bestimmten Bedingungen komplett lösen.
<G-vec00198-002-s319><dissolve.auflösen><en> It is unclear whether the particles released are stable in the environment or dissolve completely in a certain time or under certain conditions.
<G-vec00198-002-s323><dissolve.auflösen><de> Zucker um Wasser auflösen.
<G-vec00198-002-s323><dissolve.auflösen><en> Stirring to dissolve sugar.
<G-vec00198-002-s324><dissolve.auflösen><de> Denn obwohl der Filmbildner zunächst in Wasser löslich oder dispergierbar sein soll, darf sich die Beschichtung später nicht mehr in Wasser auflösen.
<G-vec00198-002-s324><dissolve.auflösen><en> This is not yet sufficient, however; while the film former should initially be soluble or dispersible in water, the coating must not dissolve.
<G-vec00198-002-s329><dissolve.auflösen><de> Zitronensäure hat durch ihren sehr niedrigen pH-Wert die Eigenschaft, entstandene Beläge wieder aufzulösen.
<G-vec00198-002-s329><dissolve.auflösen><en> Citric acid has a very low pH value which means it is able to dissolve deposits.
<G-vec00198-002-s330><dissolve.auflösen><de> Zitronensäure hat durch ihren sehr niedrigen pH-Wert die Eigenschaft, entstandene Kalkbeläge wieder aufzulösen.
<G-vec00198-002-s330><dissolve.auflösen><en> As citric acid has a very low pH-value it is able to dissolve limescale deposits.
<G-vec00198-002-s331><dissolve.auflösen><de> Ich schreib das deswegen so, damit die Knalltüten, die sich anstrengen müssen um meine Webseite zu verhexen, verstehen, dass es für uns ein genüssliches Tun ist, es wieder aufzulösen.
<G-vec00198-002-s331><dissolve.auflösen><en> I am writing this down, because I want those goofballs, who are cursing my website to understand that for us, it is a pleasurable activity to dissolve their curses.
<G-vec00198-002-s026><rescind.auflösen><de> Solange der Eingang der Annahme nicht vom Unternehmer bestätigt worden ist, kann der Konsument den Vertrag noch auflösen.
<G-vec00198-002-s026><rescind.auflösen><en> Until receipt of this acceptance has not been confirmed by the operator, the consumer may rescind the contract.
<G-vec00198-002-s035><rescind.auflösen><de> Sachtes Abstreifen genügt völlig, da die Krusten sich nach und nach von selber lösen.
<G-vec00198-002-s035><rescind.auflösen><en> A gentle touch is enough, for these crusts rescind by itself little by little.
<G-vec00198-002-s036><rescind.auflösen><de> Solange der Erhalt nicht bestätigt ist, kann der Verbraucher den Vertrag lösen.
<G-vec00198-002-s036><rescind.auflösen><en> Until receipt of this acceptance has not been confirmed, the consumer may rescind the contract.
<G-vec00198-002-s066><rescind.auflösen><de> Geringe Abweichungen vom Farbdruck sowie von der Farbe, der Dicke, dem Gewicht und sonstigen Maßen und Größen, der Qualität und der Verarbeitung des gelieferten Materials gewähren dem Vertragspartner nicht das Recht, die Produkte abzulehnen, den Vertrag aufzulösen (auflösen zu lassen) und/oder Schadenersatz von Berdal zu fordern.
<G-vec00198-002-s066><rescind.auflösen><en> Minor deviations in colour print as well as in colour, thickness, weight and other dimensions and measurements, quality and finishing of the delivered material shall not entitle the other party to reject the products, to rescind (have rescinded) the agreement and/or to claim compensation from Berdal.
<G-vec00198-002-s036><terminate.auflösen><de> Solange der Erhalt dieser Annahme nicht durch den Unternehmer bestätigt wurde, kann der Verbraucher den Vertrag auflösen.
<G-vec00198-002-s036><terminate.auflösen><en> The consumer can terminate the contract as long as this acceptance has not been confirmed by the entrepreneur.
<G-vec00198-002-s037><terminate.auflösen><de> Der Abnehmer kann den Vertrag ausschließlich schriftlich auflösen, wenn die Lieferung, nachdem der VVV hierfür eine vernünftige Frist erhalten hat, nicht innerhalb dieser Frist stattgefunden hat und dies die Folge von Umständen ist, die dem VVV nicht zugeschrieben werden können.
<G-vec00198-002-s037><terminate.auflösen><en> The Customer will only be entitled to terminate the agreement in writing if the product, after the VVV has been allowed a reasonable period of time, has not been delivered within that period of time and if this is due to circumstances attributable to VVV.
<G-vec00198-002-s038><terminate.auflösen><de> 15.1 Wenn der Käufer einem Konkursverfahren untersteht oder es bekannt wird, dass er sich in finanziellen Schwierigkeiten befindet oder einer seiner in den AVB angegebenen vertraglichen Verpflichtungen nicht nachkommt, kann Hammond Power Solutions S.p.A. den Vertrag mit einer schriftlichen Mitteilung an den Käufer auflösen.
<G-vec00198-002-s038><terminate.auflösen><en> 15.1– In case the Buyer is in a difficult financial condition or doesn’t fulfil its obligations deriving from the Contract and contained in this General Sales Conditions, Hammond Power Solutions S.p.A. shall terminate the contract trough a written notice to the Buyer.
<G-vec00198-002-s039><terminate.auflösen><de> Falls Sie gegen diesen Vertrag verstoßen, kann Yanone unbeschadet ihrer sonstigen Rechte diesen Vertrag und die zugehörige Lizenz umgehend auflösen.
<G-vec00198-002-s039><terminate.auflösen><en> Yanone has the right to terminate your license immediately if you fail to comply with any term of this Agreement.
<G-vec00198-002-s040><terminate.auflösen><de> Jeden Morgen beginnt sich das Konto neu zu füllen, aber die Bank kann das Konto jederzeit auflösen, ohne Vorwarnung.
<G-vec00198-002-s040><terminate.auflösen><en> Each morning, the account starts anew, filled up from scratch. But the bank can terminate the account at any time, without warning.
<G-vec00198-002-s041><terminate.auflösen><de> Zielgruppe Sowohl der Arbeitgeber als auch der Arbeitnehmer können den Arbeitsvertrag während der Probezeit einseitig auflösen.
<G-vec00198-002-s041><terminate.auflösen><en> The employer and the salaried worker (employee) may unilaterally terminate the contract during the trial period.
<G-vec00198-002-s042><terminate.auflösen><de> Die Partei, die den Ausbildungsvertrag auflösen möchte, sendet dem zuständigen Ausbildungsberater einen schriftlichen Auflösungsantrag, es sei denn, die Auflösung findet während der Probezeit statt.
<G-vec00198-002-s042><terminate.auflösen><en> The party who wishes to terminate the apprenticeship contract must send a written termination request to the competent apprenticeship adviser, except in cases where the termination takes place during the trial period.
<G-vec00198-002-s043><terminate.auflösen><de> Dort findest du auf der rechten Seiten den Link "Profil auflösen".
<G-vec00198-002-s043><terminate.auflösen><en> There, you will find a Terminate profile link on the right-hand side of the page.
<G-vec00198-002-s044><terminate.auflösen><de> 13.5 Will eine Vertragspartei aus sonstigen Gründen den Vertrag vorzeitig auflösen, so gilt dieser mit der schriftlicher Annahme der Erklärung durch die andere Partei unter den im folgenden Absatz genannten Bedingungen als aufgelöst.
<G-vec00198-002-s044><terminate.auflösen><en> 13.5 In case that one of the parties wants to prematurely terminate the contract from miscellaneous reasons, the contract shall be deemed as terminated if the other party declares its written acceptance and if the termination is in accordance with the following regulations.
<G-vec00198-002-s045><terminate.auflösen><de> Wir unterstützen Sie gerne beim Verhandeln, Erstellen und Auflösen von (internationalen) IT-Verträgen; etwa ASP-/SaaS-Verträgen, Cloudverträgen, Softwareentwicklungsverträgen, Outsourcingsverträgen, Softwarelizenzverträgen, Service Leval Verträgen (SLA), Wartungsverträgen, Escrowverträgen, Cloudescrowverträgen, Softwarewartungsverträgen, Gewährleistungsverträgen, allgemeine Geschäftsbedingungen (AGB), Hostingverträgen, Webvertisingverträgen und Verträgen bezüglich der Erstellung von Internetseiten.
<G-vec00198-002-s045><terminate.auflösen><en> We can help you negotiate, draw up, review or terminate Dutch or international ICT contracts, such as ASP/SaaS agreements, cloud agreements, software development agreements, customised agreements, software distribution agreements, outsourcing agreements, software licensing agreements, service level agreements (SLAs), maintenance agreements, escrow agreements, cloud escrow agreements, warranty agreements, general conditions, hosting agreements, webvertising agreements and agreements on the construction of websites.
<G-vec00198-002-s046><terminate.auflösen><de> Falls es irgendwelche Mängel gibt, kann der Auftraggeber, der den Bauunternehmer davon rechtzeitig benachrichtigt hat, Folgendes tun: vom Bauunternehmer Mängelbeseitigung verlangen oder die Mängel selbst auf Rechnung des Bauunternehmers beseitigen oder den Preis herabsetzen oder den Vertrag auflösen.
<G-vec00198-002-s046><terminate.auflösen><en> In case of existence of some defects, the client who has properly and in due time informed the contractor that delivered works have a certain defect, has the following at the disposal: ask the contractor to remedy the defect or to remedy the defects by himself for the account of the contractor or to reduce the price or to terminate the contract.
<G-vec00198-002-s047><terminate.auflösen><de> 15.4 Wurde der Beherbergungsvertrag auf unbestimmte Zeit abgeschlossen, so können die Vertragsparteien den Vertrag, bis 10.00 Uhr des dritten Tages vor dem beabsichtigten Vertragsende, auflösen.
<G-vec00198-002-s047><terminate.auflösen><en> 15.4 If the accommodation contract was concluded indefinitely, the parties can terminate the contract by 10.00 am on the third day before the intended end of the contract.
<G-vec00198-002-s048><terminate.auflösen><de> In jedem Fall eines Verdachts auf Eindringen in die Unternehmen-Dienstleistungen werden wir Ihr Spielerkonto unmittelbar auflösen, alle durch das Konto verfügbaren Gelder einziehen und die zuständigen Behörden benachrichtigen.
<G-vec00198-002-s048><terminate.auflösen><en> In any case of suspected break-in to The Company Services we shall immediately terminate Your Player Account, seize all funds available through that account pending our investigation, and notify the relevant authorities.
<G-vec00198-002-s049><terminate.auflösen><de> 15.6 Wenn die Vertragserfüllung durch ein als höhere Gewalt zu wertendes Ereignis (zB Elementarereignisse, Streik, Aussperrung, behördliche Verfügungen etc) unmöglich wird, kann der Beherberger den Beherbergungsvertrag jederzeit ohne Einhaltung einer Kündigungsfrist auflösen, sofern der Vertrag nicht bereits nach dem Gesetz als aufgelöst gilt, oder der Beherberger von seiner Beherbergungspflicht befreit ist.
<G-vec00198-002-s049><terminate.auflösen><en> 8.5 If the fulfillment of the contract becomes impossible due to an event to be regarded as force majeure (eg elementary event, strike, lock-out, official orders etc.), the lessor can terminate the contract at any time without observance of a notice period Or the landlord is exempted from his / her accommodation obligation.
<G-vec00198-002-s050><terminate.auflösen><de> Sollten Sie, in irgendeiner Phase des Projekts, nicht glücklich mit der Richtung sein, in die unsere Arbeit geht, werden Sie uns für die gesamten bis zu diesem Zeitpunkt erbrachten Leistungen bezahlen und diesen Vertrag auflösen.
<G-vec00198-002-s050><terminate.auflösen><en> If, at any stage, you change your mind about what you want to be delivered and are not happy with the direction our work is taking you’ll pay us in full for the time we’ve spent working with you until that point and terminate this contract.
<G-vec00198-002-s051><terminate.auflösen><de> Falls Sie Sich als beOne-Member registriert haben, können Sie diese Registrierung jederzeit auflösen.
<G-vec00198-002-s051><terminate.auflösen><en> If you have registered as a beOne member, you can terminate this registration at any time.
<G-vec00198-002-s052><terminate.auflösen><de> Sollte der Verkäufer die sonstigen Kaufverträge nicht auflösen, so sind alle Beträge, die der Kunde für diese anderen Bestellungen oder aus einem anderen Grund schuldet, unverzüglich einforderbar.
<G-vec00198-002-s052><terminate.auflösen><en> In the event that the Seller opts not to terminate the remaining sales, all amounts owing by the Customer in respect of such other orders or for any other cause shall be payable immediately.
<G-vec00198-002-s058><terminate.auflösen><de> Im Falle des Zahlungsverzuges ist sycube berechtigt, das Vertragsverhältnis, sei es auf bestimmte oder unbestimmte Dauer, unter Setzung einer Nachfrist von 2 Wochen mit sofortiger Wirkung vorzeitig aufzulösen.
<G-vec00198-002-s058><terminate.auflösen><en> In event of payment default, SYCUBE shall be entitled to prematurely terminate the contractual relationship, whether for a fixed or indefinite period of time, after a grace period of 2 weeks, with immediate effect.
<G-vec00198-002-s059><terminate.auflösen><de> - Casino 8118 behält sich das Recht vor, jederzeit und aus jedem Grund, ohne vorherige Anweisung Konten aufzulösen, Gewinne einzuziehen und sämtliche Angebote einzustellen oder zu widerrufen.
<G-vec00198-002-s059><terminate.auflösen><en> - The Casinos Management retains the right to terminate accounts, confiscate winnings and to discontinue or cancel all promotions at any time, for any reason whatsoever and without prior notice.
<G-vec00198-002-s060><terminate.auflösen><de> Der Käufer ist dann berechtigt, den Teil des Vertrages, für den dies absolut notwendig ist, aufzulösen oder zu kündigen, vorausgesetzt, dass er uns dies schriftlich mitteilt und unbeschadet unseres Anspruchs, die betreffenden Produkte innerhalb von drei Wochen nach Erhalt der Mitteilung noch an den Kunden zu liefern.
<G-vec00198-002-s060><terminate.auflösen><en> In that event the purchaser will be entitled to terminate or cancel the agreement for the part for which this is strictly necessary, provided that the purchaser has informed us of this in writing, and without prejudice to our right to still deliver the products concerned to the purchaser within three weeks after receipt of the notification.
<G-vec00198-002-s061><terminate.auflösen><de> Sofern keine weiteren Verbindlichkeiten gegenüber SEGA bestehen, haben Sie das Recht, Ihr Konto durch eine E-Mail an [email_accountdisabling] jederzeit zu deaktivieren oder zu aufzulösen.
<G-vec00198-002-s061><terminate.auflösen><en> Subject to there being no outstanding liabilities owing to SEGA, you have the right to disable or terminate your Account at any time by sending an email to customer services.
<G-vec00198-002-s062><terminate.auflösen><de> Beträgt die Preiserhöhung mehr als 10%, dann ist der Auftraggeber berechtigt, den Vertrag aufzulösen, es sei denn, die Preissteigerung ist die Folge einer Vertragsänderung oder ergibt sich aus einer diesbezüglichen gesetzlichen Befugnis.
<G-vec00198-002-s062><terminate.auflösen><en> If the price increase is more than 10%, the client is entitled to terminate the contract, unless this price increase is the result of an amendment to the contract or ensues from an entitlement to do so by virtue of the law.
<G-vec00198-002-s063><terminate.auflösen><de> Der Käufer/Auftraggeber hat in dem Fall das Recht, den Vertrag innerhalb einer Woche aufzulösen, wobei er den Händler/ Servicetechniker für die von ihm bereits durchgeführten Tätigkeiten entschädigt.
<G-vec00198-002-s063><terminate.auflösen><en> In that case, the buyer/customer is entitled, within a period of one week, to terminate the contract and shall compensate the dealer/repairer for any work already carried out by the dealer/repairer.
<G-vec00198-002-s064><terminate.auflösen><de> Wenn wir Kenntnis davon erlangen, dass wir Personenbezogene Daten von Kindern unter 13 Jahren erhoben haben, werden wir umgehend Schritte einleiten, um diese Informationen zu löschen und das Konto des Kindes aufzulösen.
<G-vec00198-002-s064><terminate.auflösen><en> If we learn that we have collected any Personal Data from children under 16, we will promptly take steps to delete such information and terminate the child’s account. 5.
<G-vec00198-002-s065><terminate.auflösen><de> PIPA hat das Recht, den Kaufvertrag einseitig zu Lasten des Käufers ohne vorherige Einschaltung eines Gerichts aufzulösen, sofern ein ernsthafter Verstoß des Käufers gegen eine oder mehrere seiner vertraglichen Pflichten vorliegt und die entsprechende Mahnung innerhalb von 30 Kalendertagen ohne Erfolg geblieben ist (wurde mehr als eine Mahnung verschickt, gilt als Beginn dieser Frist das Datum der ersten Mahnung).
<G-vec00198-002-s065><terminate.auflösen><en> PIPA has the right to unilaterally terminate the purchase agreement without prior recourse to court action against the Purchaser, in the event of a serious shortcoming of the Purchaser against one or more of its contractual obligations, insofar as the notice of default has not resulted in any remedy for a period of thirty calendar days (in the event in which more than one notice of default is sent, then this term is to be determined on the basis of the first notice of default).
<G-vec00198-002-s066><terminate.auflösen><de> Im Falle von überfälligen Rechnungen hat der Lieferant das Recht, die vorliegende Vereinbarung, den jeweiligen Kaufvertrag oder einen Teil desselben aufzulösen oder dessen Ausführung auszusetzen oder zu verschieben.
<G-vec00198-002-s066><terminate.auflösen><en> In case of unpaid invoices, the supplier has the right to terminate this agreement, the single purchase agreement or any part thereof, or to suspend its execution or to delay it.
<G-vec00198-002-s067><terminate.auflösen><de> Der Verbraucher hat in diesem Fall das Recht, den Vertrag kostenlos aufzulösen und einen eventuellen Schadenersatz zu erhalten.
<G-vec00198-002-s067><terminate.auflösen><en> In that case the consumer has the right to terminate the agreement without any further cost and he is entitled to compensation.
<G-vec00198-002-s068><terminate.auflösen><de> 6.1 Bei Erwerb von Produkte, die nicht auf elektronischem Wege, sondern physisch geliefert werden, hat der Kunde während 14 Arbeitstage die Möglichkeit den Kaufvertrag ohne Angabe von Gründen aufzulösen.
<G-vec00198-002-s068><terminate.auflösen><en> 6.1 In the event that Products are not electronically but physically delivered, the Client shall be entitled to terminate the Purchase Agreement within 14 workdays without giving reasons.
<G-vec00198-002-s069><terminate.auflösen><de> Als Nutzer haben sie jederzeit die Möglichkeit, die Registrierung aufzulösen.
<G-vec00198-002-s069><terminate.auflösen><en> As a user you have the right to terminate your registration at any time.
<G-vec00198-002-s070><terminate.auflösen><de> Ferner willigen Sie ein, sich am Ende jeder Sitzung von ihrem Benutzerkonto abzumelden Wir sind befugt ihr Benutzerkonto und Ihren Zugang zu der PocketPixies® Webseite oder zu Teilen der selbigen zu sperren oder aufzulösen, wenn Sie gegen diese Nutzungsbedingungen oder Sonderregelungen eines bestimmten Serviceangebots verstoßen, das Urheberrecht verletzen, oder aus sonstigen Gründen, die nicht angegeben werden müssen.
<G-vec00198-002-s070><terminate.auflösen><en> In addition, you agree to log off from your account at the end of each session. We may suspend or terminate your account and your ability to use the PocketPixies® website or portion thereof for failure to comply with these Terms of Use or any special terms related to a particular service, for infringing copyright, or for any other reason whatsoever or for no reason.
<G-vec00198-002-s071><terminate.auflösen><de> 3.6 Wenn die Preise der Produkte und Dienstleistungen in der Zeit zwischen der Bestellung und deren Ausführung steigen, sind Sie berechtigt, die Bestellung oder den Vertrag aufzulösen innerhalb von zehn (10) Tage nach Ankündigung der Erhöhung von Werkzeug Mania abzubrechen.
<G-vec00198-002-s071><terminate.auflösen><en> 3.6 If the prices for the products and services offered increase during the period between the order and its execution, you are entitled to cancel the order or to terminate the agreement within ten (10) days after notification of the price increase by ToolMania.
<G-vec00198-002-s072><terminate.auflösen><de> Beim Kauf von Produkten hat der Verbraucher die Möglichkeit, den Vertrag für 14 Tage ohne Angabe von Gründen aufzulösen.
<G-vec00198-002-s072><terminate.auflösen><en> When purchasing products, the consumer has the option to terminate the contract without giving any reason within 14 days.
<G-vec00198-002-s073><terminate.auflösen><de> Im Falle der Nichteinhaltung der Verpflichtungen durch den Auftraggeber oder bei Insolvenz, (vorläufigem) Zahlungsaufschub, Stilllegung, Liquidation oder vollständiger oder teilweiser Übertragung oder Verpfändung von Vermögensbestandteilen des Auftraggebers hat die Aboma bv das Recht, die Durchführung des Vertrags auszusetzen oder den Vertrag ohne vorherige Inverzugsetzung ganz oder teilweise aufzulösen.
<G-vec00198-002-s073><terminate.auflösen><en> In the case of non-compliance by the client or of bankruptcy, (provisional) moratorium of payments, stoppage, liquidation or full or partial transfer or pledging of assets of the client, Aboma BV is authorised to suspend the performance of the contract or fully or partially terminate the contract without prior notice.
<G-vec00198-002-s074><terminate.auflösen><de> Werden die oben aufgeführten Konditionen verletzt oder wird das Forschungsprojekt vorzeitig abgebrochen, behält sich die VERBI Software GmbH das Recht vor, den Vertrag aufzulösen und die bereits geleistete finanzielle Unterstützung zurückzufordern.
<G-vec00198-002-s074><terminate.auflösen><en> If the above conditions are violated or the research project is prematurely terminated, VERBI Software GmbH reserves the right to terminate the contract and reclaim the financial support already provided.
<G-vec00198-002-s075><terminate.auflösen><de> Der Beherberger ist berechtigt, den Beherbergungsvertrag mit sofortiger Wirkung aufzulösen, wenn wichtige Gründe, insbesondere jene des § 1118 ABGB vorliegen.
<G-vec00198-002-s075><terminate.auflösen><en> 15.5 The Proprietor shall be entitled to terminate the Accommodation Agreement with immediate effect for important reasons, particularly if the Party and/or the Guest
<G-vec00755-002-s072><dissipate.auflösen><de> Außerdem fungieren die Kanadischen Rockies als eine Art Barriere für die von Westen heranziehenden Wolken, sodass sich viele Unwetter auflösen, ehe sie die Prärie erreichen.
<G-vec00755-002-s072><dissipate.auflösen><en> And Canadian Rockies slow weather systems that arrive from the west, giving storms time to dissipate before hitting the prairies.
<G-vec00755-002-s073><dissipate.auflösen><de> In seltenen Fällen können sich kleine Blutergüsse, Verhärtungen oder Beulen in den behandelten Bereichen bilden, die sich aber nach einigen Tagen auflösen.
<G-vec00755-002-s073><dissipate.auflösen><en> In rare cases, small haematomas, indurations and lumps can form in the treated areas, which will dissipate within a few days.
<G-vec00755-002-s104><dissipate.auflösen><de> Dieser Geruch wird sich von selbst auflösen und ist kein Grund zur Sorge.
<G-vec00755-002-s104><dissipate.auflösen><en> This smell will dissipate and is nothing to worry about.
<G-vec00755-002-s108><dissipate.auflösen><de> Sie wollte sich völlig auflösen, und das konnte sie natürlich nicht.
<G-vec00755-002-s108><dissipate.auflösen><en> She wanted to dissipate altogether and of course she couldn’t.
<G-vec00755-002-s109><dissipate.auflösen><de> Der Freitag Morgen wird über dem Norden zunehmend sonnig, dann bilden sich Quellwolken und Temperaturen erreichen 22°C im Baselbiet, 20°C im Mittelland und im Wallis, 12°C im Engadin und 22°C im Tessin, wo die Wolken sich gegen Nachmittag meist auflösen.
<G-vec00755-002-s109><dissipate.auflösen><en> Friday morning will be increasingly sunny over the North, then clouds develop and temperatures reach 22°C in the Basel region, 20°C in the Plateau and the Valais, 12°C in the Engadine and 22°C in the Ticino, where clouds dissipate towards the afternoon.
<G-vec00755-002-s028><vanish.auflösen><de> Auf dem Kooperationsstand 239 des Mechatronik-Clusters können die Besucher in der Zone der Ruhe dem Trubel entfliehen und erfahren, wie man mit speziellen mechatronischen Systemen den Lärm in Luft auflöst.
<G-vec00755-002-s028><vanish.auflösen><en> Visitors to cooperative stand 239 in the mechatronic cluster can escape from the bustle into the Quiet Zone and experience how special mechatronic systems cause noise to vanish into thin air.
<G-vec00755-002-s030><vanish.auflösen><de> Und nun ist das stählerne, zweiteilige Eckensemble ein eigenständiges Wesen, dessen Bestandteile – ein dreieckiges Blech und ein Handlauf – sich im inneren Dialog aufzulösen scheinen.
<G-vec00755-002-s030><vanish.auflösen><en> And now the iron ensemble of two parts becomes an autonom entity, whose components – a triangular metal plate and a handrail – seem to vanish in their inner dialog.
<G-vec00755-002-s037><vanish.auflösen><de> Fragen, die sich im Laufe dieses Clips in Luft auflösen, um das Publikum dann schließlich doch wieder einzuholen.
<G-vec00755-002-s037><vanish.auflösen><en> Questions that seem to vanish into thin air during the course of this video, only to catch up with the audience again in the end.
<G-vec00755-002-s058><vanish.auflösen><de> Überzeugen Sie sich selbst: bei einem Flug mit dem Helikopter eröffnen sich Ihnen fantastische Ausblicke, während sich die Gedanken quasi in Luft auflösen und so Platz für das unbeschreiblich schöne Gefühl der Leichtigkeit schaffen.
<G-vec00755-002-s058><vanish.auflösen><en> See for yourself: enjoy fantastic views on a helicopter flight while your thoughts literally vanish into thin air, making room for a an incredibly beautiful feeling of lightness.
<G-vec00755-002-s076><vanish.auflösen><de> Ein Fluch, durch den sich das Königreich in Luft auflöste.
<G-vec00755-002-s076><vanish.auflösen><en> A curse that caused it to vanish into thin air.
<G-vec00755-002-s088><vanish.auflösen><de> „Mögen sich all unsere Schwierigkeiten so leicht in Nichts auflösen!“ sagte Sherlock Holmes.
<G-vec00755-002-s088><vanish.auflösen><en> Nos "May all our difficulties vanish as easily!" said Sherlock Holmes.
