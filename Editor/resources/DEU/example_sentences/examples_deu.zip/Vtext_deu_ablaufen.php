<G-vec00245-002-s019><occur.ablaufen><de> Das Besondere ist hierbei, dass diese Vorgänge viel langsamer ablaufen als bei "normalen" Stoffen und die Positionsänderung jedes einzelnen Staubpartikels mit der Kamera verfolgt werden kann.
<G-vec00245-002-s019><occur.ablaufen><en> The advantage of this is that the phase changes occur much more slowly than with ordinary materials and the changes in position of each particle can be followed with cameras.
<G-vec00245-002-s020><occur.ablaufen><de> Es zeigt alle Tests, die während dem Ablaufen von DISPLAY SELECTION zur kompletten Steuerung der Ereignisse notwendig sind.
<G-vec00245-002-s020><occur.ablaufen><en> This example shows all the tests you may need to check in order to fully monitor the events that occur during a DISPLAY SELECTION.
<G-vec00245-002-s021><occur.ablaufen><de> Zudem verlaufen Hydrierungen im Allgemeinen nur unter Zugabe von Katalysatoren, während die Halogenierungen mit Chlor und Brom oft spontan ablaufen.
<G-vec00245-002-s021><occur.ablaufen><en> Additionally, catalysts are required for hydrogenations, while halogenations with chlorine or bromine, for example, occur spontaneously.
<G-vec00245-002-s022><occur.ablaufen><de> Dafür können wir kleine zusätzliche Gleichungen konstruieren, welche die Mechanismen widerspiegeln, die für die optimale Energieverteilung verantwortlich sind (sogenannte “State Transitions“), unsere Parameter erweitern (wir müssen auch wissen, wie schnell manche Reaktionen ablaufen) und die Anzahl der Variablen ändern.
<G-vec00245-002-s022><occur.ablaufen><en> Therefore we can construct a small additional script that will include mechanisms responsible for optimal energy distribution (called state transitions, but only for those really interested in the topic) and increase our parameters space (we need to know how fast certain processes occur) and number of variables.
<G-vec00245-002-s023><occur.ablaufen><de> Ribonukleinsäure (RNA) spielt eine Schlüsselrolle für biochemische Prozesse, die auf zellulärer Ebene in einer wässrigen Umgebung ablaufen.
<G-vec00245-002-s023><occur.ablaufen><en> Ribonucleic acid (RNA) plays a key role in biochemical processes which occur at the cellular level in a water environment.
<G-vec00245-002-s024><occur.ablaufen><de> Bekanntermaßen spielen diese Säuren eine wichtige Rolle bei den biochemischen Prozessen, die im menschlichen Körper ablaufen.
<G-vec00245-002-s024><occur.ablaufen><en> As is known, these acids play quite an important role in the biochemical processes that occur in the human body.
<G-vec00245-002-s025><occur.ablaufen><de> Durch Kombination von Röntgenstreuung mit mikromechanischen in-situ Charakterisierungsmethoden werden Prozesse untersucht, die während der mechanischen Deformation im Knochen ablaufen.
<G-vec00245-002-s025><occur.ablaufen><en> Through use of in situ micro-mechanical characterization coupled with X-ray scattering and diffraction techniques, processes that occur during mechanical deformation, from the molecular scale to the tissue level, are investigated in bone.
<G-vec00245-002-s026><occur.ablaufen><de> Für die Geheimhaltung des Kennworts und des Nutzerkontos sowie für alle Aktivitäten, die unter Ihrem Kennwort oder Nutzerkonto ablaufen, sind Sie allein verantwortlich.
<G-vec00245-002-s026><occur.ablaufen><en> You are responsible for maintaining the confidentiality of the password and account, and are fully responsible for all activities that occur under your password or account.
<G-vec00245-002-s027><occur.ablaufen><de> Die Forscher erklären dieses Phänomen damit, dass die Kernfusionsprozesse, die bei Supernovae, Novae und Roten Riesen ablaufen, jeweils unter anderen Bedingungen stattfinden.
<G-vec00245-002-s027><occur.ablaufen><en> Researchers explain this phenomenon by the fact that the nuclear fusion processes that occur with supernovae, novae and red giants, take place under different conditions.
<G-vec00245-002-s028><occur.ablaufen><de> Jedes Aquarium ist so einzigartig, dass alle Prozesse mit unterschiedlichen Geschwindigkeiten ablaufen.
<G-vec00245-002-s028><occur.ablaufen><en> Each aquarium is so unique that all processes will occur at different speeds.
<G-vec00245-002-s029><occur.ablaufen><de> Verschiedene biochemische Prozesse, die im Fettgewebe ablaufen, beeinflussen den Hormonhaushalt und führen zur verstärkten Bildung männlicher Hormone.
<G-vec00245-002-s029><occur.ablaufen><en> Various biochemical processes that occur in the fatty tissue influence the hormonal balance and result in the increased formation of male hormones.
<G-vec00245-002-s030><occur.ablaufen><de> Wegen seiner niedrigen maximalen Phononenfrequenz (~180 cm-1) sind Multiphononrelaxationen selten, was zur Folge hat, dass diese Relaxationsprozesse über größere Energielücken hauptsächlich über elektronische Anregungszustände des Gitters ablaufen.
<G-vec00245-002-s030><occur.ablaufen><en> Due to the low maximum phonon frequency of the crystal lattice (~180 cm-1), multiphonon relaxation rates are low. Relaxation processes over larger energy gaps occur mostly via electronic excited states of the host lattice.
<G-vec00245-002-s031><occur.ablaufen><de> Weinenzyme werden benutzt, um natürliche Prozesse zu beschleunigen, die sonst nur langsam in Weinen ablaufen würden.
<G-vec00245-002-s031><occur.ablaufen><en> Wine enzymes are used to accelerate natural reactions that would otherwise occur slowly in wines.
<G-vec00245-002-s032><occur.ablaufen><de> Die Arbeiten in der Abteilung „Schwingfestigkeit“ beschäftigen sich mit der Verbesserung des Verständnisses der Schädigungsprozesse, die unter thermischer und mechanischer Ermüdungsbeanspruchung ablaufen.
<G-vec00245-002-s032><occur.ablaufen><en> The works in the section “fatigue” deal with the improvement of the understanding of the damage mechanism which occur under thermal and mechanical fatigue loading.
<G-vec00245-002-s033><occur.ablaufen><de> Es geht um all jene Denkprozesse, die unbewusst in kürzester Zeit ablaufen, ohne dass sie hinreichend hinterfragt werden.
<G-vec00245-002-s033><occur.ablaufen><en> Unconscious bias thus denotes thought processes that occur unconsciously and very quickly, without being sufficiently questioned.
<G-vec00245-002-s034><occur.ablaufen><de> Bei Biofeedback werden Körperfunktionen, die normalerweise unbewusst ablaufen, wie Muskelspannung, Herzfrequenz, Augenbewegungen und Durchblutung mit geeigneten Geräten gemessen und rückgemeldet.
<G-vec00245-002-s034><occur.ablaufen><en> During biofeedback, body functions, which usually occur unconsciously, such as muscle tension, heart rate, eye movements and circulation, are measured and fed back with suitable instruments.
<G-vec00245-002-s035><occur.ablaufen><de> Sie haben ihren Vorrat an Wasserstoff, der die Kernreaktionen befeuert, die die meiste Zeit ihres Lebens im Inneren des Sterns ablaufen, fast verbraucht.
<G-vec00245-002-s035><occur.ablaufen><en> They have almost depleted their reserves of hydrogen, which fuels the reactions that occur during most of the life of a star.
<G-vec00245-002-s036><occur.ablaufen><de> Bereits der erste Teil der Kampagne im Jahr 2012 hat neue Erkenntnisse zur OH-Radikal- und Aerosolbildung geliefert – insbesondere zu welcher Tageszeit und in welchen Höhen bestimmte Prozesse ablaufen.
<G-vec00245-002-s036><occur.ablaufen><en> The first part of the campaign in 2012 already provided new insights into OH radicals and aerosol formation – especially concerning the time of day and altitude at which certain processes occur.
<G-vec00245-002-s037><occur.ablaufen><de> Viele andere Faktoren spielen hierbei ebenfalls eine entscheidende Rolle: So sind Ärzte und Patienten - insbesondere bei operativen Behandlungen - eingebunden in eine hochkomplexe, vielschichtige Struktur, in der komplizierte Prozesse ablaufen.
<G-vec00245-002-s037><occur.ablaufen><en> Many other factors also play a decisive role here. For example, physicians and patients are involved in a highly complex, multi-layered structure in which complicated processes occur, especially in operative treatments.
<G-vec00261-002-s019><proceed.ablaufen><de> Ohne Vitamin B12 kann die Myelinsynthese nicht richtig ablaufen.
<G-vec00261-002-s019><proceed.ablaufen><en> Without vitamin B12, myelin synthesis cannot proceed properly.
<G-vec00261-002-s020><proceed.ablaufen><de> Ihre geistigen Fähigkeiten sowie Fokus werden viel mehr nach 30 bis 45 Minuten und auch wird es auch für 8 bis 10 Stunden ablaufen.
<G-vec00261-002-s020><proceed.ablaufen><en> Your mental ability and also focus will be much more after thirty to forty-five mins and it will certainly also proceed for eight to ten hrs.
<G-vec00261-002-s021><proceed.ablaufen><de> Verfahren nach Anspruch 1, bei dem die Reaktion bei einer Temperatur von 120°C oder weniger ablaufen gelassen wird, bis die Menge des restlichen fluorierten Alkylhalogenids 10 % oder weniger beträgt, und die Reaktion dann bei einer Temperatur von 120°C oder mehr durchgeführt wird.
<G-vec00261-002-s021><proceed.ablaufen><en> The method according to claim 1, wherein the reaction is allowed to proceed at a temperature of 120°C or below until the amount of the remaining fluorinated alkyl halide becomes 10% or less and is subsequently carried out at a temperature of 120°C or above.
<G-vec00261-002-s022><proceed.ablaufen><de> Damit diese Mechanismen der Entwicklung und Homöostase korrekt ablaufen sind präzise kontrollierte Signale und Signalvermittlung fundamental.
<G-vec00261-002-s022><proceed.ablaufen><en> Precisely controlled signaling and signal transduction are fundamental to ensure that these mechanisms of development and homeostasis proceed correctly.
<G-vec00261-002-s023><proceed.ablaufen><de> Positionierungen und Absteckungen Damit Produktions- und Montagezyklen reibungslos und teilweise vollautomatisiert ablaufen können, müssen alle daran beteiligten Maschinen und Anlagen exakt zueinander ausgerichtet und positioniert werden.
<G-vec00261-002-s023><proceed.ablaufen><en> So that production and installation cycles can proceed smoothly and sometimes fully automatically, all the machines and plants involved have to be exactly aligned and positioned with respect to each other.
<G-vec00261-002-s024><proceed.ablaufen><de> Aufgrund der Systemeigenschaften von Kolloiden – nämlich gleichmäßige Partikelverteilung und Widerständigkeit gegen Diffusion – und dem Umstand, dass der menschliche Körper zu etwa 75 Prozent aus Wasser besteht, kommt der Annahme eine hohe Plausibilität zu, daß die Stoffwechselprozesse lebendiger Organismen auf der Grundlage kolloidaler Lösungen ablaufen.
<G-vec00261-002-s024><proceed.ablaufen><en> Due to the system properties of colloids - namely uniform particle distribution and resistiveness against diffusion - and the fact that the human body is about 75 percent water, the assumption is of great plausibility, that the metabolic processes of living organisms proceed on the basis of colloidal solutions.
<G-vec00261-002-s025><proceed.ablaufen><de> Mit einer Thermokamera analysierten die Ingenieure, wie Erwärmung und Abkühlung exakt ablaufen.
<G-vec00261-002-s025><proceed.ablaufen><en> ‘We use a thermal imaging camera to analyse precisely how the heating and cooling stages proceed.’
<G-vec00261-002-s026><proceed.ablaufen><de> Piment gehört zu den Produkten mit unterbrochenen Respirationsprozessen, bei denen jedoch weiterhin mikrobielle, biochemische und andere Zersetzungsprozesse ablaufen.
<G-vec00261-002-s026><proceed.ablaufen><en> Capsicums belong to the class of products in which respiration processes are suspended, but in which biochemical, microbial and other decomposition processes still proceed.
<G-vec00261-002-s027><proceed.ablaufen><de> Dass auf öffentlichen Veranstaltungen, die ordnungsgemäß bei den Behörden gemeldet werden, immer ausreichender und neutraler Polizeischutz gewährleistet wird, um sicherzustellen, dass die Veranstaltungen nach Plan ablaufen können, ohne dass die Organisatoren oder Teilnehmer Gewaltakte vor, während oder nach der Veranstaltung befürchten müssen.
<G-vec00261-002-s027><proceed.ablaufen><en> That public events properly registered with the authorities are always granted sufficient and neutral police protection to ensure that the events can proceed according to plan, without the organizers or participants having to fear violence prior, during or after the event.
<G-vec00261-002-s028><proceed.ablaufen><de> Sie gehören zu den Waren mit unterbrochenen Respirationsprozessen, bei denen jedoch weiterhin biochemische, mikrobielle u. a. Zersetzungsprozesse ablaufen.
<G-vec00261-002-s028><proceed.ablaufen><en> It belongs to the class of products in which respiration processes are suspended, but in which biochemical, microbial and other decomposition processes still proceed.
<G-vec00261-002-s029><proceed.ablaufen><de> Es gehört zu den Produkten mit unterbrochenen Respirationsprozessen, bei denen jedoch weiterhin mikrobielle, biochemische und andere Zersetzungsprozesse ablaufen.
<G-vec00261-002-s029><proceed.ablaufen><en> It belongs to the class of products in which respiration processes are suspended, but in which biochemical, microbial and other decomposition processes still proceed.
<G-vec00261-002-s030><proceed.ablaufen><de> Je nach Datenmenge können die Datenverarbeitungsprozesse parallel ablaufen.
<G-vec00261-002-s030><proceed.ablaufen><en> Depending on data volume, data processing functions can proceed in parallel workers.
<G-vec00261-002-s031><proceed.ablaufen><de> Studie 8 zeigte, dass lediglich monokulare Komponenten der Gesichtsform-Adaptation unbewusst ablaufen können, während komplexere Komponenten auf visuelles Bewusstsein angewiesen sind.
<G-vec00261-002-s031><proceed.ablaufen><en> In Study 8, we measured face shape aftereffects and found that only low-level monocular components of face shape adaptation can proceed unconsciously, whereas higher-level components depend on visual awareness.
<G-vec00113-002-s034><expire.ablaufen><de> Achten Sie bei einer Vorbestellung darauf, dass Ihre Zahlungsoption zum Liefertermin eine ausreichende Deckung aufweist und bis dahin nicht abgelaufen ist.
<G-vec00113-002-s034><expire.ablaufen><en> For pre-orders, be sure that the payment option has enough funds for the purchase and won't expire before the expected release date.
<G-vec00113-002-s035><expire.ablaufen><de> Diese Cookies verbleiben selbst nach dem Schließen des Browsers auf dem Gerät, bis sie abgelaufen sind.
<G-vec00113-002-s035><expire.ablaufen><en> These cookies remain on the device and operate even after closing the browser, until they expire.
<G-vec00113-002-s036><expire.ablaufen><de> Oder Sie haben einen Selbstausschluss beantragt, der noch nicht abgelaufen ist.
<G-vec00113-002-s036><expire.ablaufen><en> or You may have requested a self-exclusion period which has yet to expire.
<G-vec00113-002-s037><expire.ablaufen><de> Danach werden die Daten für die weitere Verwendung gesperrt und nach Ablauf aller handels- und steuerrechtlichen Aufbewahrungsfristen endgültig gelöscht.
<G-vec00113-002-s037><expire.ablaufen><en> After that, the data will be blocked from further use and finally erased once all retention periods under commercial and tax law expire.
<G-vec00113-002-s038><expire.ablaufen><de> Wir bitten Sie höflich, die Nummer und Ablauf Ihrer Kreditkarte uns mitzuteilen.
<G-vec00113-002-s038><expire.ablaufen><en> Please add the number and expire date of your credit card.
<G-vec00113-002-s039><expire.ablaufen><de> Die Lieferfrist ist eingehalten, wenn bis zu ihrem Ablauf die Versandbereitschaft mitgeteilt ist oder der Liefergegenstand das Werk verlassen hat.
<G-vec00113-002-s039><expire.ablaufen><en> The delivery periods will have been satisfied if, by the time they expire, the goods have left the works or the Customer has been notified that they are ready for dispatch.
<G-vec00113-002-s040><expire.ablaufen><de> Bei Kündigung des Vertrages werden Ihre Daten selbstverständlich gesperrt und bis zum Ablauf der gesetzlichen Aufbewahrungsfristen zu keinerlei weiteren Zwecken verwendet.
<G-vec00113-002-s040><expire.ablaufen><en> When the contract is terminated, your data is blocked as a matter of course and is not used for any other purpose until the statutory retention periods expire.
<G-vec00113-002-s041><expire.ablaufen><de> Beantragen Sie die Lizenz online.Kostenlose Lizenzen besitzen eine Gültigkeit von einem Jahr, können aber nach Ablauf kostenlos erneuert werden.
<G-vec00113-002-s041><expire.ablaufen><en> Free Apply for a free license online.Free licenses expire after 1 year, but can be renewed every year for free.
<G-vec00113-002-s042><expire.ablaufen><de> - Durch Aktivieren von "Benutzerdefinierte Einstellungen verwenden" können Sie Cookies von Drittanbietern (immer, von den meistbesuchten Seiten oder überhaupt) akzeptieren und für einen bestimmten Zeitraum (bis zu deren Ablauf, Schließen von Firefox oder bei jeder Abfrage) speichern.
<G-vec00113-002-s042><expire.ablaufen><en> From the “History” section you can: - By enabling “Use custom settings”, accept third-party cookies (always, from the most visited websites or never) and store them for a specified period (until they expire, when Firefox closes or ask every time
<G-vec00113-002-s043><expire.ablaufen><de> E-mail E-mail Falls Sie dieses Feld besetzen, erhalten Sie grundsätzlich eine Erinnerungsmail vor Ablauf der Leihfrist.
<G-vec00113-002-s043><expire.ablaufen><en> Library users who fill in an email-adress will get a reminder a few days before the expire date of the loan period.
<G-vec00113-002-s044><expire.ablaufen><de> Globale Administratoren erhalten alle Nachrichten sowie die Berichte über Inhalte der Warteschlangen, Statistiken, Versionsinformationen, Meldungen, dass Benutzer nicht gefunden wurden (für alle Domänen), Meldungen über Datenträgerfehler, Meldungen über eingefrorene und gesperrte Benutzerkonten für alle Domänen (sie und die Domänen-Administratoren können die Benutzerkonten wieder freigeben), Warnmeldungen über Lizenzen und den bevorstehenden Ablauf der Funktionsdauer von Betaversionen, Übersichten über Spam und weitere Nachrichten.
<G-vec00113-002-s044><expire.ablaufen><en> Global administrators receive everything including the Queue Summary report, Statistics report, Release Notes, 'No Such User' found (for all domains), Disk Error notifications, Account Freeze and Disable notifications for all domains (which, like Domain admins, they can unfreeze and re-enable), warnings about licenses and beta test versions about to expire, Spam Summary reports, and perhaps others as well.
<G-vec00113-002-s045><expire.ablaufen><de> Kontenbezogene Informationen werden in Verbindung mit Ihrer Nutzung unserer Dienste gesammelt, wie Kontonummer, Käufe, Erneuerung oder Ablauf von Produkten, Informationsanfragen und Kundendienstanfragen sowie Notizen oder Details, die erklären, wonach Sie gefragt haben und wie wir geantwortet.
<G-vec00113-002-s045><expire.ablaufen><en> Account related information is collected in association with your use of our Services, such as account number, purchases, when products renew or expire, information requests, and customer service requests and notes or details explaining what you asked for and how we responded.
<G-vec00113-002-s046><expire.ablaufen><de> Sie werden über den Ablauf Ihrer Lizenzen informiert und müssen sich nicht merken, über wie viele Access Points Sie verfügen und wann diese verbunden wurden.
<G-vec00113-002-s046><expire.ablaufen><en> Know when all of your licenses will expire, without having to remember the number of access points or when they were connected.
<G-vec00113-002-s047><expire.ablaufen><de> Tarifverträge gelten weiter bis zum Ablauf, zur Kündigung oder Ersetzung des Vertrags.
<G-vec00113-002-s047><expire.ablaufen><en> Collective agreements continue to apply until they expire or are terminated or replaced.
<G-vec00113-002-s048><expire.ablaufen><de> (2) Qualifizierte Zertifikate, die gemäß der Richtlinie 1999/93/EG für natürliche Personen ausgestellt worden sind, gelten bis zu ihrem Ablauf als qualifizierte Zertifikate für elektronische Signaturen gemäß dieser Verordnung.
<G-vec00113-002-s048><expire.ablaufen><en> 2. Qualified certificates issued to natural persons under Directive 1999/93/EC shall be considered as qualified certificates for electronic signatures under this Regulation until they expire.
<G-vec00113-002-s049><expire.ablaufen><de> Im Falle einer Einzugsermächtigung wird Pidoco das Nutzungsentgelt für den jeweiligen folgenden Zeitraum mit Ablauf des letzten Tages des jeweiligen aktuellen Abrechnungszeitraums einziehen.
<G-vec00113-002-s049><expire.ablaufen><en> In case of a direct debit mandate, the fee for the next billing period is collected by Pidoco at the close of the last day of the billing period about to expire.
<G-vec00113-002-s050><expire.ablaufen><de> Vier Wochen vor Ablauf des Versicherungsjahres erinnert Sie eine E-Mail daran, dass Sie den Schutz für Ihr Bike online verlängern können.
<G-vec00113-002-s050><expire.ablaufen><en> Four weeks before the insurance is due to expire, you will receive an e-mail reminding you that you can extend your bike cover online.
<G-vec00113-002-s051><expire.ablaufen><de> Überprüfen und stimmen Sie dem Handel schließlich zu und warten Sie auf den Ablauf Ihrer Option.
<G-vec00113-002-s051><expire.ablaufen><en> Finally, review and approve the trade and wait for your option to expire.
<G-vec00113-002-s052><expire.ablaufen><de> (3) Fehlt bei einer nach Monaten bestimmten Frist in dem letzten Monat der für ihren Ablauf maßgebende Tag, so endigt die Frist mit dem Ablauf des letzten Tages dieses Monats.
<G-vec00113-002-s052><expire.ablaufen><en> (3)If, in the case of a period of time determined by months, the day on which it is due to expire does not occur in the last month, the period ends on the expiry of the last day of this month.
<G-vec00113-002-s053><expire.ablaufen><de> Andere Faktoren können auch schon früher zum Ablauf führen.
<G-vec00113-002-s053><expire.ablaufen><en> Other factors mat cause it to expire before this.
<G-vec00113-002-s062><expire.ablaufen><de> Zu den möglichen Aktionen für eine Dateiverwaltungsaufgabe gehören die Fähigkeit zum Ablaufen von Dateien, zum Verschlüsseln von Dateien oder zum Ausführen eines benutzerdefinierten Befehls.
<G-vec00113-002-s062><expire.ablaufen><en> The actions that a file management task can take include the ability to expire files, encrypt files, or run a custom command.
<G-vec00113-002-s063><expire.ablaufen><de> Push Nachrichten informieren Dich über Coupons die bald ablaufen, oder neue Coupons in deiner Umgebung.
<G-vec00113-002-s063><expire.ablaufen><en> Push messages inform you about coupons that will soon expire, or new coupons in your area.
<G-vec00113-002-s064><expire.ablaufen><de> Es darf nicht innerhalb von 6 Monaten nach Ihrer Ankunft ablaufen.
<G-vec00113-002-s064><expire.ablaufen><en> It must not expire within 6 months of your arrival.
<G-vec00113-002-s065><expire.ablaufen><de> Die meisten Gerichte werden aus Produkten hergestellt, die ablaufen (am besten - wenn nicht schon abgelaufen).
<G-vec00113-002-s065><expire.ablaufen><en> Most dishes are prepared from products that expire (at best - if not already expired) expiration date.
<G-vec00113-002-s066><expire.ablaufen><de> Um zu vergleichen, um erfolgreich und effizient diese beiden Medikamente, Modalert und Modafinil (Modvigil), die Kindererziehung und die Vermarktung dieser Medikamente, und was passiert, wenn Patente ablaufen muss verstanden werden.
<G-vec00113-002-s066><expire.ablaufen><en> In order to successfully and efficiently compare these two medications, Modalert and Modafinil (Modvigil), the patenting & marketing of these medications, and what happens when patents expire must be understood.
<G-vec00113-002-s067><expire.ablaufen><de> Die Polizei fügte außerdem hinzu, dass mein Pass bald ablaufen würde.
<G-vec00113-002-s067><expire.ablaufen><en> The police also mentioned that my passport was going to expire soon.
<G-vec00113-002-s068><expire.ablaufen><de> Prüfen Sie Ihr Meilenkonto, prüfen Sie, wann Ihre Meilen ablaufen werden, und finden Sie heraus, wie viele Statusmeilen Sie noch für das nächste Niveau Ihrer Mitgliedschaft brauchen.
<G-vec00113-002-s068><expire.ablaufen><en> Check your Miles balance, see when your Miles will expire, and find out how many Tier Miles you need to reach the next membership level.
<G-vec00113-002-s069><expire.ablaufen><de> Wenn es Ihnen nicht gelingt, alle Videos und Fragen kostenlos während der Zeit von Service Package zu benutzen, werden sie ablaufen.
<G-vec00113-002-s069><expire.ablaufen><en> If you do not manage to use all QUERIES and watch all video free during the time of your Service Package they will expire.
<G-vec00113-002-s070><expire.ablaufen><de> Bitte notieren Sie sich das Ablaufdatum Ihrer Domain(s) und sorgen Sie dafür, dass diese nicht ablaufen.
<G-vec00113-002-s070><expire.ablaufen><en> Please make note of the expiry date of your domain(s) and ensure that they do not expire.
<G-vec00113-002-s071><expire.ablaufen><de> Beachten Sie jedoch, dass die Sessions nach einer bestimmten Anzahl von Minuten ablaufen, so wie es in der Datei web.config konfiguriert ist.
<G-vec00113-002-s071><expire.ablaufen><en> Keep in mind though, that sessions will expire after a certain amount of minutes, as configured in the web.config file.
<G-vec00113-002-s072><expire.ablaufen><de> Beachten Sie außerdem, dass Stammzertifikate, wie alle Zertifikate, irgendwann ablaufen.
<G-vec00113-002-s072><expire.ablaufen><en> Also note that root certificates eventually expire, as do all certificates.
<G-vec00113-002-s073><expire.ablaufen><de> Nein, Ihr Konto wird nicht ablaufen.
<G-vec00113-002-s073><expire.ablaufen><en> No, your account will never expire.
<G-vec00113-002-s074><expire.ablaufen><de> Ablaufen am Wählen Sie diese Option aus, um ein bestimmtes Datum oder eine bestimmte Uhrzeit festzulegen, nach dem/der der Browser dazu gezwungen wird, den Inhalt bei nachfolgenden Anforderungen immer erneut vom Server abzurufen.
<G-vec00113-002-s074><expire.ablaufen><en> Expire on Select to set a specific date and time after which the browser is forced to retrieve the content again from the server on the subsequent requests.
<G-vec00113-002-s075><expire.ablaufen><de> Diese Anforderung gilt für von Dritten ausgestellte Cookies, die als "persistent" bezeichnet werden, solange sie auf Ihrem Gerät verbleiben, bis sie gelöscht werden oder ablaufen.
<G-vec00113-002-s075><expire.ablaufen><en> This requirement applies to cookies issued by third parties that are described as "persistent" for as long as they remain on your device or until they are deleted or expire.
<G-vec00113-002-s076><expire.ablaufen><de> Außerdem erneuert Lightsail die Zertifikate automatisch im Namen des Kunden, bevor sie ablaufen.
<G-vec00113-002-s076><expire.ablaufen><en> In addition, Lightsail will automatically renew certificates on customer's behalf before they expire.
<G-vec00113-002-s077><expire.ablaufen><de> Die Geschäfte welche 2016/2017 ablaufen sollten die Kunden unbedingt schnellst möglich die Verjährung hemmen.
<G-vec00113-002-s077><expire.ablaufen><en> The shops which should expire 2016/2017 customers absolutely as soon as possible inhibit the limitation period.
<G-vec00113-002-s078><expire.ablaufen><de> Um die genaue Liste der von BSEU verwendeten Cookies aufzurufen mit Angaben dazu, wie lange diese Cookies aktiv sind, wann sie ablaufen sowie mit der dazugehörigen Domain und/oder Namen, können Sie die entsprechenden Einstellungen in Ihrem Webbrowser aufrufen.
<G-vec00113-002-s078><expire.ablaufen><en> To be able to see the exact list of what cookies FSEU uses, for how long these are active, when they expire, their domain and/or name, you can consult the settings in your web browser.
<G-vec00113-002-s079><expire.ablaufen><de> Wenn Zugriffstoken ablaufen, verwenden Office-Clients ein gültiges Aktualisierungstoken, um ein neues Zugriffstoken abzurufen.
<G-vec00113-002-s079><expire.ablaufen><en> When access tokens expire, Office clients use a valid refresh token to obtain a new access token.
<G-vec00113-002-s080><expire.ablaufen><de> Sie können Ihrer Suche einen Namen geben, die Häufigkeit der E-Mail-Alerts festlegen und bestimmen, wann der Alert ablaufen wird.
<G-vec00113-002-s080><expire.ablaufen><en> You can name your search, determine the frequency of the email alert, and determine when the alert will expire.
<G-vec00113-002-s083><expire.ablaufen><de> Wenn das Zertifikat in Kürze abläuft, fragt der OCSP-Client rechtzeitig vor dem Ablaufdatum automatisch die Gültigkeit erneut ab.
<G-vec00113-002-s083><expire.ablaufen><en> If the certificate is about to expire, the OCSP client automatically repeats the query about the validity before the certificate expires.
<G-vec00113-002-s084><expire.ablaufen><de> Ihm wird nur dann stattgegeben, wenn die verlängerte Frist nicht später als 25 Monate nach dem Prioritätsdatum abläuft.
<G-vec00113-002-s084><expire.ablaufen><en> An extension will only be granted if the extended time limit does not expire later than 25 months from the priority date.
<G-vec00113-002-s085><expire.ablaufen><de> Wenn die aktive Lizenz abläuft, können Sie die Lizenz verlängern und dem Programm einen als Reserve-Aktivierungscode gekauften Code hinzufügen.
<G-vec00113-002-s085><expire.ablaufen><en> For example, if your active license is about to expire, you can renew the license for Kaspersky Anti-Virus 2015 and add the new code as a reserve.
<G-vec00113-002-s086><expire.ablaufen><de> Wenn Ihre Garantiezeit abläuft, gibt es für Sie verschiedene Optionen, mit denen Sie die Nutzungsdauer der Hardware in Ihrem Rechenzentrum verlängern können.
<G-vec00113-002-s086><expire.ablaufen><en> When your warranty is set to expire, you do have options to extend the useful life of your data center hardware.
<G-vec00113-002-s087><expire.ablaufen><de> Schritt 3: Auf der folgenden Seite wird unter „Ablaufdatum für Abonnement“ das Datum angezeigt, an dem Ihr Abonnement abläuft.
<G-vec00113-002-s087><expire.ablaufen><en> Step 3: On this page, you will see a section entitled ‘Subscription expiry date’ detailing the date your subscription is due to expire
<G-vec00113-002-s088><expire.ablaufen><de> Alle ausgegebenen Wertpapiere unterliegen einer viermonatigen Haltefrist, die an dem Tag abläuft, der vier Monate und einen Tag nach dem Abschlussdatum der Privatplatzierung liegt.
<G-vec00113-002-s088><expire.ablaufen><en> All securities issued will be subject to a four month hold period which will expire on the date that is four months and one day from the date of issue.
<G-vec00113-002-s089><expire.ablaufen><de> Für den Fall, dass Sie Ihre Passphrase vergessen oder dass Ihr privater Schlüssel kompromittiert oder verloren wurde, besteht die einzige Hoffnung darin, zu warten, bis der Schlüssel abläuft (dies ist allerdings keine gute Lösung).
<G-vec00113-002-s089><expire.ablaufen><en> In case you forget your passphrase or if your private key is compromised or lost, the only hope you have is to wait for the key to expire (this is not a good solution).
<G-vec00113-002-s090><expire.ablaufen><de> Du bekommst per E-Mail einen sicheren Link zugesandt, der nach 24 Stunden abläuft.
<G-vec00113-002-s090><expire.ablaufen><en> You will be emailed a secure link which will expire after 24 hours.
<G-vec00113-002-s091><expire.ablaufen><de> Warnhinweise bei abgelaufenen Zertifikaten: Es wird eine Benachrichtigung gesendet, wenn ein SSL-Zertifikat abläuft.
<G-vec00113-002-s091><expire.ablaufen><en> Certificate expiration warnings: Sends an when an SSL certificate is about to expire.
<G-vec00113-002-s092><expire.ablaufen><de> 10.7 Für die Nacherfüllung (10.4) beträgt die Verjährungsfrist 6 Monate, beginnend ab der Beendigung der Nacherfüllung, falls die Verjährungsfrist gemäß 10.6 früher abläuft.
<G-vec00113-002-s092><expire.ablaufen><en> 10.7 The limitation period for rectification (10.4) shall be 6 months commencing from the ending of the rectification, should the limitation period in accordance with 10.6 expire earlier.
<G-vec00113-002-s093><expire.ablaufen><de> Diese Aufzeichnungen geben Aufschluss über die Registrierung einer Domain, zum Beispiel: wenn die Domain übernommen wurde, wenn die Registrierung abläuft, Kontaktdaten des Registranten usw.
<G-vec00113-002-s093><expire.ablaufen><en> These records provide information about the registration of a domain, for example: when the domain was acquired, when the registration will expire, contact details of the registrant etc. Email:
<G-vec00113-002-s094><expire.ablaufen><de> Das neue stellvertretende Mitglied des Verwaltungsrats wird für die verbleibende Amtszeit ihrer Vorgängerin ernannt, die 2013 am Ende des Tages der Jahressitzung des Rates der Gouverneure, in der der Jahresbericht und der Jahresabschluss für das Jahr 2012 geprüft werden, abläuft.
<G-vec00113-002-s094><expire.ablaufen><en> The new alternate member of the Board of Directors has been appointed for the remainder of her predecessor’s term of office, which will expire in 2013 at the end of the day of the Annual Meeting in which the annual report, balance sheet and profit and loss account for the 2012 financial year are examined.
<G-vec00113-002-s095><expire.ablaufen><de> Eine Sperrung oder Löschung der Daten erfolgt auch dann, wenn eine durch die genannten Normen vorgeschriebene Speicherfrist abläuft, es sei denn, dass eine Erforderlichkeit zur weiteren Speicherung der Daten für einen Vertragsabschluss oder eine Vertragserfüllung besteht.
<G-vec00113-002-s095><expire.ablaufen><en> Data will also be blocked or erased if recordkeeping obligations under the aforementioned norms expire, unless continued storage of such data is necessary to enter into or perform a contract.
<G-vec00113-002-s096><expire.ablaufen><de> - Trial-Version, die nicht abläuft, so können Sie sie immer nach Wunsch verwenden.
<G-vec00113-002-s096><expire.ablaufen><en> - Trial version that doesn't expire, so you can use it whenever you want.
<G-vec00113-002-s097><expire.ablaufen><de> Bitte geben Sie sich ausreichend Zeit (2-3 Wochen), wenn Sie Ihren Auftrag für einen Domaintransfer abschicken, damit Ihre Domain nicht abläuft, während wir versuchen, den Transfer zu autorisieren.
<G-vec00113-002-s097><expire.ablaufen><en> Please give yourself ample time (2-3 weeks) when you submit your domain transfer order so that your domain does not expire while we are attempting to authorize the transfer.
<G-vec00113-002-s098><expire.ablaufen><de> Es ist neben meinem "Erwachen" zu neuen Leben, welches nicht tagtäglich an Veränderungen von großer Tragweite erscheinend, sichtbar abläuft, höre ich in mich hinein und stelle fest, das sich wie bei einem Jahreszeitenwechsel die Natur in unscheinbar, kleinen Wundern zu einem großen, allumfassenden Ganzen zusammenfügt.
<G-vec00113-002-s098><expire.ablaufen><en> It is next to my "awakening" to new life, which does not expire every day appearing to changes of great consequence, visible, I listen to myself and realize, which is insignificant as a change of seasons, the nature of small miracles into one great assembles all-encompassing whole.
<G-vec00113-002-s099><expire.ablaufen><de> Claim Duration/Anspruchsdauer – Die Anzahl der Tage die ein Spieler offline sein kann, bevor der Anspruch abläuft.
<G-vec00113-002-s099><expire.ablaufen><en> Claim Duration – The number of days a player can be offline before their land claims expire.
<G-vec00113-002-s136><expire.ablaufen><de> Monica lebt in Belgien und besitzt einen italienischen Führerschein, der bald abläuft.
<G-vec00113-002-s136><expire.ablaufen><en> Monica lives in Belgium and has an Italian licence which is about to expire.
<G-vec00113-002-s137><expire.ablaufen><de> Sobald der Eigentümer sichergestellt hat, dass die Domain nicht bald abläuft und wenn die Domain entsperrt ist, können Sie folgende Schritte durchführen, um Ihren Auftrag zum Eigentümerwechsel per Domain Pull abzuschicken: Gehen Sie auf unsere Seite Domain-Eigentum ändern.
<G-vec00113-002-s137><expire.ablaufen><en> Once the owner has made sure the domain is not about to expire and unlocked the domain, you can follow these steps to submit your change ownership domain pull order: Go to our Change Domain Ownership page.
<G-vec00113-002-s138><expire.ablaufen><de> Falls diese Kreditkarte bald abläuft und der andere Administrator sie nicht aktualisieren kann, können Sie eine Dienstunterbrechung verhindern, indem Sie eine andere Kreditkarte für das Abonnement hinzufügen.
<G-vec00113-002-s138><expire.ablaufen><en> If that card is about to expire and the other administrator isn’t able to update it, you can prevent service interruption by adding a different credit card for the subscription.
<G-vec00113-002-s234><expire.ablaufen><de> Alle ungenutzten Downloads laufen am monatlichen Verlängerungsdatum des Mitgliedschaftspakets ab.
<G-vec00113-002-s234><expire.ablaufen><en> Any unused downloads will expire on the plan's monthly renewal date.
<G-vec00113-002-s235><expire.ablaufen><de> Die Millenniumsentwicklungsziele, die seit fünfzehn Jahren die internationale Agenda für Verbesserung der Lebensverhältnisse bilden, laufen 2015 aus.
<G-vec00113-002-s235><expire.ablaufen><en> The Millennium Development Goals (MDGs) are due to expire in 2015. They have formed the international agenda for improving people’s living conditions for fifteen years.
<G-vec00113-002-s236><expire.ablaufen><de> ** Diese Angebote für kostenlose Kontingente für AWS laufen am Ende der 12monatigen Laufzeit nicht ab, sondern stehen sowohl bestehenden als auch neuen AWS-Kunden unbegrenzt lange zur Verfügung.
<G-vec00113-002-s236><expire.ablaufen><en> ** These free tier offers do not automatically expire at the end of your 12 month AWS Free Tier term, but are available to both existing and new AWS customers indefinitely.
<G-vec00113-002-s237><expire.ablaufen><de> Einträge laufen am Ende jedes Monats aus, somit müsst Ihr, um Euch für den nächsten Monat zu qualifizieren, mindestens 1 Ticket in dem Monat besitzen.
<G-vec00113-002-s237><expire.ablaufen><en> Entries expire at the end of each month so to qualify for the following month, you must have earned at least 1 ticket during said month.
<G-vec00113-002-s238><expire.ablaufen><de> (5) Die Frist zur Annahme des Angebots beginnt am Tag nach der Absendung des Angebots durch den Kunden zu laufen und endet mit dem Ablauf des fünften Tages, welcher auf die Absendung des Angebots folgt.
<G-vec00113-002-s238><expire.ablaufen><en> (5) The deadline for accepting the offer begins to expire the day after the customer submitting the offer and ends at the end of the fifth day, which follows the sending of the offer.
<G-vec00113-002-s239><expire.ablaufen><de> Sie laufen drei Jahre nach Verkaufsdatum ab und dürfen nur während der Wintersaison benützt werden.
<G-vec00113-002-s239><expire.ablaufen><en> These expire three years after the date of sale and may only be used during the winter season.
<G-vec00113-002-s240><expire.ablaufen><de> Alle Cookies laufen nach 90 Tagen ab.
<G-vec00113-002-s240><expire.ablaufen><en> All cookies will expire after 90 days.
<G-vec00113-002-s241><expire.ablaufen><de> Diese Cookies laufen innerhalb eines Jahres ab.
<G-vec00113-002-s241><expire.ablaufen><en> These cookies expire after one year.
<G-vec00113-002-s242><expire.ablaufen><de> Aktive Booster laufen nicht ab, werden jedoch zurückgesetzt, wenn Sie drei vollständige Kalendermonate lang inaktiv sind.
<G-vec00113-002-s242><expire.ablaufen><en> Active boosts do not expire but will reset if you are inactive for three full calendar months.
<G-vec00113-002-s243><expire.ablaufen><de> Sie laufen automatisch ab, wenn Sie Ihren Browser schließen.
<G-vec00113-002-s243><expire.ablaufen><en> These automatically expire when you close down your browser.
<G-vec00113-002-s244><expire.ablaufen><de> Antwort: Gutscheine laufen am Ende des Kalenderjahres ab.
<G-vec00113-002-s244><expire.ablaufen><en> A: Coupons expire at the end of the calendar year.
<G-vec00113-002-s245><expire.ablaufen><de> DynaDollar können für Einkäufe bei Dynadot verwendet werden und laufen niemals ab.
<G-vec00113-002-s245><expire.ablaufen><en> DynaDollars can be used toward any Dynadot purchase and will never expire.
<G-vec00113-002-s246><expire.ablaufen><de> Diese werden auch „dauerhafte Cookies" genannt und laufen nach einer gewissen Zeit ab.
<G-vec00113-002-s246><expire.ablaufen><en> These are known as ‘persistent cookies’, which expire after a period of time.
<G-vec00113-002-s247><expire.ablaufen><de> Wenn Sie "Unbegrenzt" angeben, laufen die PINs der Benutzer nie ab.
<G-vec00113-002-s247><expire.ablaufen><en> If you specify Unlimited, the users' PINs won't expire.
<G-vec00113-002-s248><expire.ablaufen><de> Solange Sie alle sechs Monate mindestens 0,01 VPP sammeln, laufen Ihre StarsCoin nicht ab.
<G-vec00113-002-s248><expire.ablaufen><en> As long as you earn at least 0.01 VPP every six months then your StarsCoin will not expire.
<G-vec00113-002-s249><expire.ablaufen><de> HINWEIS: Wenn Sie die Anzahl der Tage auf null setzen, laufen Ihre Meetings niemals ab.
<G-vec00113-002-s249><expire.ablaufen><en> NOTE: If you set the number of days to zero, your meetings will never expire.
<G-vec00113-002-s250><expire.ablaufen><de> Diese Cookies laufen im Allgemeinen nach 180 Tagen ab und können einen Benutzer nicht persönlich identifizieren.
<G-vec00113-002-s250><expire.ablaufen><en> These cookies generally expire after 180 days and cannot identify a user personally.
<G-vec00113-002-s251><expire.ablaufen><de> Von Exchange erstellte selbstsignierte Zertifikate laufen innerhalb eines Jahres ab.
<G-vec00113-002-s251><expire.ablaufen><en> Self-signed certificates that are created by Exchange expire in one year.
<G-vec00113-002-s252><expire.ablaufen><de> Derartige Cookies werden für die Verfolgung von Konvertierungen und Empfehlungen verwendet und laufen in der Regel nach 30 Tagen ab, obwohl einige länger aktiv sein können.
<G-vec00113-002-s252><expire.ablaufen><en> Such cookies are used for conversion and referral tracking and typically expire after 30 days, though some may take longer.
<G-vec00113-002-s253><expire.ablaufen><de> Wenn Sie ursprünglich einen Wert zwischen 1 und 99 Tagen für den PIN-Ablauf festgelegt haben und dann in diesem Zeitraum den Wert in die hohe Zahl ändern, laufen PINs am Ende des ursprünglichen Zeitraums ab und danach nie wieder.
<G-vec00113-002-s253><expire.ablaufen><en> If you originally set the expiry period to between 1 and 99 days and then change to the large number during that period: PINs still expire at the end of the initial period, but never again afterward.
<G-vec00113-002-s254><expire.ablaufen><de> Diese Cookies laufen nach kurzer Zeit oder wenn Sie Ihren Webbrowser nach der Nutzung unserer Dienste schließen ab.
<G-vec00113-002-s254><expire.ablaufen><en> These cookies expire after a short time, or when you close your web browser after using our Services.
<G-vec00113-002-s255><expire.ablaufen><de> Wenn Sie während dieses Zeitraums nicht genutzt werden, laufen sie ab.
<G-vec00113-002-s255><expire.ablaufen><en> If they are unused within that time, they will expire.
<G-vec00113-002-s256><expire.ablaufen><de> Im Gegensatz zu dauerhaften Cookies laufen Sitzungs-Cookies ab, wenn Sie sich bei den Services ausloggen und Ihren Browser schließen.
<G-vec00113-002-s256><expire.ablaufen><en> Unlike persistent Cookies, session Cookies expire when you log off from the Services and close your browser.
<G-vec00113-002-s257><expire.ablaufen><de> Diese Cookies laufen automatisch innerhalb von 30 Tagen ab.
<G-vec00113-002-s257><expire.ablaufen><en> These cookies expire automatically within 30 days.
<G-vec00113-002-s258><expire.ablaufen><de> - Nach kurzem „Blinker ein - Blinker aus“ laufen fünf Blinkzyklen ab.
<G-vec00113-002-s258><expire.ablaufen><en> - After a brief "flashers - Flasher from" expire five flashing cycles.
<G-vec00113-002-s264><expire.ablaufen><de> Solange Sie die Software nicht aktivieren, können Sie diese nur über einen bestimmten Zeitraum verwenden (die Testversion läuft nach 14 Tagen ab).
<G-vec00113-002-s264><expire.ablaufen><en> Before you activate the product, you may run it for a limited amount of time (trial version will expire in 14 days).
<G-vec00113-002-s265><expire.ablaufen><de> Unser Visum für die USA läuft am 17.11.2004 ab; wir haben also noch 1 Woche für die letzten 900km in den Staaten, bevor es auf die Baja California in Mexiko geht.
<G-vec00113-002-s265><expire.ablaufen><en> Our Visa for the USA will expire on the 17th of November, so we have about one week left for the last 900km before we go down the Baja California in Mexico.
<G-vec00113-002-s266><expire.ablaufen><de> Sobald Sie die automatische Verlängerung abschalten, läuft Ihr Abonnement zum Ende der laufenden Bezugsfrist ab.
<G-vec00113-002-s266><expire.ablaufen><en> Once you turn off auto-renewal, your subscription will expire at the end of the current subscription period.
<G-vec00113-002-s267><expire.ablaufen><de> Das Widerrufsrecht läuft nach 14 Tagen ab dem Tag [im Falle eines Vertrages über mehrere vom Verbraucher bestellte Waren in einer einheitlichen Bestellung und Lieferung in mehreren Teilsendungen], an dem Sie oder ein von Ihnen angegebener Dritter, der nicht Beförderer ist, physisch in den Besitz der zuletzt gelieferten Ware kommt.
<G-vec00113-002-s267><expire.ablaufen><en> The withdrawal period will expire after 14 days from the day [in the case of a contract relating to multiple goods ordered by the consumer in one order and delivered separately: ‘on which you acquire, or a third party other than the carrier and indicated by you acquires, physical possession of the last good.’.
<G-vec00113-002-s268><expire.ablaufen><de> Die Konzession des Kraftwerks läuft zwar erst im Jahre 2036 aus, doch nach dem Gewässerschutzgesetz der Schweiz müssen die Mindestwasserstrecken an Ausleitungskraftwerken saniert werden.
<G-vec00113-002-s268><expire.ablaufen><en> The concession of the hydropower plant will expire in 2036, but according to the Swiss Water Protection Act diverted reaches of hydropower plants have to be reconstructed.
<G-vec00113-002-s269><expire.ablaufen><de> Die Roamingverordnung läuft drei Jahre nach ihrem Inkrafttreten aus.
<G-vec00113-002-s269><expire.ablaufen><en> The Roaming Regulation will expire three years after it comes into force.
<G-vec00113-002-s270><expire.ablaufen><de> Damit läuft der bis Mitte 2018 gültige Vertrag bis Ende der Saison 2020/2021 weiter.
<G-vec00113-002-s270><expire.ablaufen><en> According to the extension, it would expire at the close of the 2020/2021 season.
<G-vec00113-002-s271><expire.ablaufen><de> Dieses Angebot ist für jedermann gültig, der diese Informationen erhält, und läuft drei Jahre nach dem Datum ab, an dem diese Produktversion durch das Unternehmen Hewlett Packard Enterprise letztmalig vertrieben wird.
<G-vec00113-002-s271><expire.ablaufen><en> This offer is valid to anyone in receipt of this information and shall expire three years following the date of the final distribution of this product version by Hewlett Packard Enterprise Company.
<G-vec00113-002-s272><expire.ablaufen><de> Läuft die Frist an einem Samstag, Sonntag oder an einem gesetzlichen Feiertag aus, so verlängert sich die Frist bis zum jeweils folgenden Werktag.
<G-vec00113-002-s272><expire.ablaufen><en> Should the period expire on a Saturday, Sunday or a public holiday, then it is extended to the first subsequent working day.
<G-vec00113-002-s273><expire.ablaufen><de> Die Bestellung von Herrn Somers erfolgt für die verbleibende Amtszeit seines Vorgängers und läuft 2008 am Ende des Tages der Jahressitzung des Rates der Gouverneure ab, in der der Jahresbericht und der Jahresabschluss für das Jahr 2007 geprüft werden.
<G-vec00113-002-s273><expire.ablaufen><en> Mr Michael Somers has been appointed for the remainder of his predecessor's term of office, which will expire in 2008 at the end of the Annual Meeting of the Board of Governors in which the annual report, balance sheet and profit and loss account for the 2007 financial year are examined.
<G-vec00113-002-s274><expire.ablaufen><de> Der sechsjährige Vertrag von Herrn Peksaglam läuft im August 2017 aus.
<G-vec00113-002-s274><expire.ablaufen><en> Mr. Peksaglam's six-year contract will expire in August 2017.
<G-vec00113-002-s275><expire.ablaufen><de> Teilen Facebook Twitter Die aktuelle Liste der Sektoren, die vor unfairem Wettbewerb im EU-Emissionshandelssystem (EHS) geschützt werden sollen, läuft am Ende des Jahres aus.
<G-vec00113-002-s275><expire.ablaufen><en> The current list of sectors to be protected from unfair competition in the EU Emissions Trading System (ETS) will expire by the end of the year and a new list must be in place for the period 2015-2020.
<G-vec00113-002-s276><expire.ablaufen><de> Das Abkommen von Cotonou, das mehr als einhundert Länder mit einer Gesamtbevölkerung von mehr als 1,5 Milliarden Menschen umfasst, läuft im Februar 2020 aus.
<G-vec00113-002-s276><expire.ablaufen><en> Uniting more than one hundred countries and over 1.5 billion people, the Cotonou Agreement is set to expire in February 2020.
<G-vec00113-002-s277><expire.ablaufen><de> Das 1997 geschlossene Abkommen, das erst 2005 in Kraft getreten ist, läuft 2012 aus.
<G-vec00113-002-s277><expire.ablaufen><en> The agreement, which was signed in 1997, did not come into force until 2005, and is due to expire in 2012.
<G-vec00113-002-s278><expire.ablaufen><de> Das Partnerschaftsabkommen von Cotonou (CPA), das die Beziehungen zwischen der AKP-Gruppe (Afrika, Karibik und Pazifik) und der Europäischen Union (EU) regelt, läuft im Jahr 2020 aus.
<G-vec00113-002-s278><expire.ablaufen><en> The Cotonou Partnership Agreement (CPA), which governs relations between the African, Caribbean and Pacific (ACP) group and the European Union (EU), will expire in the year 2020.
<G-vec00113-002-s279><expire.ablaufen><de> Wenn Sie vor Ende der Vertragslaufzeit keine Verlängerung Ihres Supports erwerben oder wenn Sie die automatische Verlängerung kündigen, läuft dieser Support-Vertrag und Ihre Berechtigung, Support-Leistungen zu erhalten automatisch ab, sofern nichts Anderes mit Autodesk vereinbart wurde.
<G-vec00113-002-s279><expire.ablaufen><en> Unless otherwise agreed by Autodesk, if You do not purchase a renewal for Your Support prior to expiration of the Term or if You cancel Your automatic renewal, this Support Agreement and Your entitlement to receive Support Benefits will automatically expire.
<G-vec00113-002-s280><expire.ablaufen><de> Aufgrund von Inaktivität läuft Ihre Sitzung mit Bazaarvoice in 60 Sekunden ab.
<G-vec00113-002-s280><expire.ablaufen><en> Due to inactivity, your online session with Bazaarvoice Inc. will expire in 60 seconds.
<G-vec00113-002-s281><expire.ablaufen><de> Um deine Website zu schützen, läuft dieser Link in 1 Tag ab.
<G-vec00113-002-s281><expire.ablaufen><en> To keep your site safe, this link will expire in 1 day.
<G-vec00113-002-s282><expire.ablaufen><de> Jedes Mal, wenn Sie eine andere Seite von der Webseite anfordern, wird das Cookie aktualisiert und läuft nach 30 Minuten ab.
<G-vec00113-002-s282><expire.ablaufen><en> Each time you request another page from the website the cookie is updated to expire after 30 minutes.
<G-vec00113-002-s283><expire.ablaufen><de> Die Widerrufsfrist läuft 14 Tage nach dem Tag ab, an dem Sie oder ein von Ihnen genannter Dritter außer dem Transportunternehmen in den physischen Besitz der letzten Ware gelangen.
<G-vec00113-002-s283><expire.ablaufen><en> The cancellation period will expire after 14 days from the day on which you acquire, or a third party other than the carrier and indicated by you acquires, physical possession of the last good.
<G-vec00113-002-s284><expire.ablaufen><de> 9.2 Cookies können entweder "dauerhafte" Cookies oder "flüchtige" -Cookies sein: ein dauerhaftes Cookie wird von einem Webbrowser gespeichert und bleibt bis zu seinem festgelegten Ablaufdatum gültig, es sei denn, es wird vom Benutzer vor dem Ablaufdatum gelöscht; ein flüchtiges Cookie hingegen läuft am Ende der Benutzersitzung ab, wenn der Webbrowser geschlossen wird.
<G-vec00113-002-s284><expire.ablaufen><en> Cookies may be either "persistent" cookies or "session" cookies: a persistent cookie will be stored by a web browser and will remain valid until its set expiry date, unless deleted by the user before the expiry date; a session cookie, on the other hand, will expire at the end of the user session, when the web browser is closed.
<G-vec00113-002-s285><expire.ablaufen><de> Wenn der Benutzer die Shop-Sprache ändert, nachdem Produkte in den Warenkorb gelegt hat, läuft Ihre Sitzung ab und die hinzugefügten Produkte im Warenkorb werden gelöscht.
<G-vec00113-002-s285><expire.ablaufen><en> If user changes the shop language after adding products to the shopping cart then the default Shopware makes your session expire and the added products in the shopping cart are deleted.
<G-vec00113-002-s286><expire.ablaufen><de> Die Widerrufsfrist läuft 14 Tage nach dem Tag ab, an dem die Waren in Ihren physischen Besitz gelangen.
<G-vec00113-002-s286><expire.ablaufen><en> The right of cancellation will expire 14 days from the day when you receive the item(s) in your physical possession.
<G-vec00113-002-s287><expire.ablaufen><de> Der Link kann einmal verwendet werden und läuft nach 24 Stunden ab.
<G-vec00113-002-s287><expire.ablaufen><en> The link can be used once and will expire after 24 hours.
<G-vec00113-002-s288><expire.ablaufen><de> Das Cookie läuft nach 80 Wochen ab und wird bei jedem Besuch der Website verlängert.
<G-vec00113-002-s288><expire.ablaufen><en> The cookie is set to expire after 80 weeks, which is extended each time the shopper visits the site.
<G-vec00113-002-s289><expire.ablaufen><de> Die Wartung (kostenlose Updates, Upgrades und neue Versionen) läuft nach Ablauf der gewählten Wartungsdauer von einem, drei oder fünf Jahren ab, aber Sie können Ihre bestehende Installation ohne Ablaufdatum weiter nutzen.
<G-vec00113-002-s289><expire.ablaufen><en> Only maintenance (free updates, upgrades and new versions) expire after the end of the selected maintenance term of either one, three or five years, but you can continue to use your existing installation without expiration.
<G-vec00113-002-s290><expire.ablaufen><de> Im Fall des Kaufs von verschiedenen Produkten läuft das Kündigungsrecht 14 Tage nach dem Erhalt des letzten Produkts ab.
<G-vec00113-002-s290><expire.ablaufen><en> In case of a contract comprising multiple Product(s), your cancellation right will expire within 14 days after the date on which you receive the last Product.
<G-vec00113-002-s291><expire.ablaufen><de> Dieser Cookie vom Drittanbieter „Google“ wird im Regelfall nicht durch das Schließen des Browsers gelöscht, sondern läuft nach einer bestimmten Zeit ab, soweit er nicht von Ihnen zuvor manuell gelöscht wird.
<G-vec00113-002-s291><expire.ablaufen><en> This cookie of third party Google will, as a general rule, not be deleted after the browser window is closed but will rather expire after a set amount of time, provided that you do not delete it manually beforehand.
<G-vec00113-002-s292><expire.ablaufen><de> Ein Session-ID-Cookie läuft nicht ab, wenn Sie Ihren Browser schließen.
<G-vec00113-002-s292><expire.ablaufen><en> A session ID cookie does not expire when you close your browser.
<G-vec00113-002-s293><expire.ablaufen><de> Die Lizenz ist nicht begrenzt und läuft auch nicht ab.
<G-vec00113-002-s293><expire.ablaufen><en> The license is not limited and does not expire.
<G-vec00113-002-s294><expire.ablaufen><de> Dieses Cookie wird im Regelfall nicht durch das Schließen des Browsers gelöscht, sondern läuft nach einer bestimmten Zeit ab, soweit es nicht von Ihnen zuvor manuell gelöscht wird.
<G-vec00113-002-s294><expire.ablaufen><en> This cookie will not be deleted automatically when the browser is closed, but will expire after a certain amount of time, provided, that it is not deleted manually.
<G-vec00113-002-s295><expire.ablaufen><de> Der API-Token läuft erst ab, wenn der Dynamic Tag Management-Benutzer dies explizit anfordert.
<G-vec00113-002-s295><expire.ablaufen><en> The API token does not expire until the Dynamic Tag Management user explicitly requests it.
<G-vec00113-002-s296><expire.ablaufen><de> Die Amtszeit von Herrn van den Wall Bake läuft 2013 am Ende des Tages der Jahresitzung des Rates der Gouverneure ab, in der der Jahresbericht und der Jahresabschluss für das Jahr 2012 geprüft werden.
<G-vec00113-002-s296><expire.ablaufen><en> The term of office of Mr van den Wall Bake will expire in 2013, at the end of the day of the Annual Meeting of the Board of Governors during which the annual report, balance sheet and profit and loss account for the 2012 financial year are examined.
<G-vec00113-002-s297><expire.ablaufen><de> 8.2 Cookies können entweder „persistente“ Cookies oder „Session“ -Cookies sein: ein persistenter Cookie wird von einem Webbrowser gespeichert und bleibt bis zu seinem festgelegten Ablaufdatum gültig, es sei denn, er wird vom Benutzer vor dem Ablaufdatum gelöscht; Ein Sitzungscookie hingegen läuft am Ende der Benutzersitzung ab, wenn der Webbrowser geschlossen wird.
<G-vec00113-002-s297><expire.ablaufen><en> Cookies may be either "persistent" cookies or "session" cookies: a persistent cookie will be stored by a web browser and will remain valid until its set expiry date, unless deleted by the user before the expiry date; a session cookie, on the other hand, will expire at the end of the user session, when the web browser is closed.
<G-vec00113-002-s123><lapse.ablaufen><de> 3.2 Unsere Angebote gelten für den im Angebot angegebenen Zeitraum und laufen, falls keine Frist angegeben ist, nach 30 Tagen ab.
<G-vec00113-002-s123><lapse.ablaufen><en> 3.2 Our quotations are valid for the period set out in them and, where no period is provided, the quotation shall lapse after 30 days.
<G-vec00113-002-s475><run_out.ablaufen><de> 32 Ich laufe den Weg deiner Gebote; denn du machst meinem Herzen Raum.
<G-vec00113-002-s475><run_out.ablaufen><en> 32 I run in the path of your commands, for you have set my heart free.
<G-vec00113-002-s476><run_out.ablaufen><de> Die langjährige Partnerschaft mit eggs unimedia – so Winfried Wirth – habe sich entsprechend der neuen Anforderungen positiv weiterentwickelt und das gesamte Projekt laufe weiter sehr zufriedenstellend.
<G-vec00113-002-s476><run_out.ablaufen><en> The long-standing partnership with eggs unimedia - according to Winfried Wirth - has developed positively in line with their new requirements and the entire project continues to run very satisfactorily.
<G-vec00113-002-s477><run_out.ablaufen><de> Unterwegs laufe ich auf einen Pickup-Truck mit ausgebrannten Fenstern am Straßenrand.
<G-vec00113-002-s477><run_out.ablaufen><en> On the way, I run into a pickup truck with blacked-out windows on the side of the road.
<G-vec00113-002-s478><run_out.ablaufen><de> Donnerstag (Halbe Geschwindigkeit): Laufe fünfmal 200 Meter, dreimal 100 Meter und zweimal 50 Meter.
<G-vec00113-002-s478><run_out.ablaufen><en> Thursday (Semi-Speed Day): Run five 200-meter stretches, three 100-meter stretches, and two 50-meter stretches.
<G-vec00113-002-s479><run_out.ablaufen><de> Zweitens laufe ich Gefahr, durch die Hingabe an solches Übersinnliche ein unpraktischer, für das Leben unbrauchbarer Mensch zu werden.
<G-vec00113-002-s479><run_out.ablaufen><en> In the second place, by devoting myself to these transcendental matters, I run the risk of becoming an impractical person of no use in life.
<G-vec00113-002-s480><run_out.ablaufen><de> Entdecke neue Routen, teste deine Grenzen aus und laufe nie dieselbe Route zweimal.
<G-vec00113-002-s480><run_out.ablaufen><en> Discover new routes, push your boundaries and never run the same route twice.
<G-vec00113-002-s481><run_out.ablaufen><de> In die Innenstadt sowie zu den Schiffsanlegestellen laufe ich in 10-12 Minuten.
<G-vec00113-002-s481><run_out.ablaufen><en> In the inner city and to the boat docks I run 10-12 minutes.
<G-vec00113-002-s482><run_out.ablaufen><de> Starte am Louvre, laufe durch den Jardin des Tuileries und die historische Champs-Élysées entlang.
<G-vec00113-002-s482><run_out.ablaufen><en> You'll start at the Louvre, run through the Jardin des Tuileries and up the historic Champs-Élysées.
<G-vec00113-002-s483><run_out.ablaufen><de> Laufe mehr, wechsle Deine Schuhe weniger.
<G-vec00113-002-s483><run_out.ablaufen><en> Run more, swap shoes less.
<G-vec00113-002-s484><run_out.ablaufen><de> Folgte man dem Ansatz des Gerichts, müsste der gesamte NZP neu beurteilt werden und man laufe Gefahr, ein völlig unterschiedliches Ergebnis zu erzielen.
<G-vec00113-002-s484><run_out.ablaufen><en> It argues that, if the General Court’s approach were to be followed, it would be necessary to assess the entirety of the NAP afresh, which would be to run the risk of obtaining a totally different result.
<G-vec00113-002-s485><run_out.ablaufen><de> Ich ziehe es entlang dem Pirschpfad und zur Forststrasse und lege es dort am Wegesrand ab und laufe dann schnell, mit Kopflampe an – ein weißer Strahl vor mir auf dem Weg – durch den mittlerweile dunklen Wald zu meinem Auto, der fast volle Mond blitzt ab und zu über den Bäumen auf.
<G-vec00113-002-s485><run_out.ablaufen><en> I pull it along the path and to the forest road and put it down there at the edge of the path and then run quickly, with a headlamp – a white beam in front of me on the way – through the now dark forest to my car, the full moon flashes up from time to time over the trees.
<G-vec00113-002-s486><run_out.ablaufen><de> Wenn du mein Herz troestest, so laufe ich den Weg deiner Gebote.
<G-vec00113-002-s486><run_out.ablaufen><en> I will run the way of thy commandments, when thou shalt enlarge my heart.
<G-vec00113-002-s487><run_out.ablaufen><de> 2:4 Und er sprach zu ihm: Laufe, rede zu diesem Jüngling und sprich: Als offene Stadt wird Jerusalem bewohnt werden wegen der Menge Menschen und Vieh in seiner Mitte.
<G-vec00113-002-s487><run_out.ablaufen><en> 2:4 and said to him, “Run, speak to this young man, saying, ‘Jerusalem will be inhabited as villages without walls, because of the multitude of men and livestock in it.
<G-vec00113-002-s488><run_out.ablaufen><de> 119:32 Wenn du mein Herz tröstest, so laufe ich den Weg deiner Gebote.
<G-vec00113-002-s488><run_out.ablaufen><en> 119:30 will run the way of your commandments, when you shall enlarge my heart.
<G-vec00113-002-s489><run_out.ablaufen><de> 4Und er sprach zu ihm: Laufe, rede zu diesem Jüngling und sprich: Als offene Stadt wird Jerusalem bewohnt werden wegen der Menge Menschen und Vieh in seiner Mitte.
<G-vec00113-002-s489><run_out.ablaufen><en> 4And he said to him, “Run, say to that young man, ‘Jerusalem shall be inhabited like villages without walls#Literally “like open regions” because of the multitude of people and animals in its midst.
<G-vec00113-002-s490><run_out.ablaufen><de> Die wichtigsten Eckdaten sind ganz einfach: Laufe deine beste Meile, teile deinen Erfolg auf Strava mit dem Hashtag #MyMile im Aktivitätstitel und du nimmst automatisch an der Verlosung teil.
<G-vec00113-002-s490><run_out.ablaufen><en> Read the rules for the details, but here’s the gist: Go run your best mile, share it on Strava with #MyMile in the activity title, and your name’s in the hat.
<G-vec00113-002-s491><run_out.ablaufen><de> Ich laufe bergauf und spüre wie sich die Schweissperlen auf meiner Stirn bilden und plötzlich sehe ich ihn.
<G-vec00113-002-s491><run_out.ablaufen><en> I run downhill and feel the sweat drops forming on my forehead and suddenly I see it.
<G-vec00113-002-s492><run_out.ablaufen><de> /way Sturmheim 47.3, 61.2 Falle: laufe den Berg hinauf (Reiten leicht gemacht).
<G-vec00113-002-s492><run_out.ablaufen><en> /way Stormheim 47.3, 61.2 Trap, run up the mountain (Mounting Made Easy).
<G-vec00113-002-s493><run_out.ablaufen><de> Ich laufe den Weg Deiner Gebote, denn Du machst meinem Herzen Raum.
<G-vec00113-002-s493><run_out.ablaufen><en> I will run the way of thy commandments, when thou shalt enlarge my heart.
<G-vec00113-002-s494><run_out.ablaufen><de> Nenndurchfluss: 50L / MIN-Kopf Entlastung: 6,0 m Saughöhe: 7.5m Solid Größe: 35mm Motor Größe: 0,75 kW Ungefähre Verdrängung pro Hub: 1,5 l Gewicht: 42 kg Maximale Außenabmessungen: 400mm x 335mm x 410mm (LxBxH) Saughöhen bis 7,5 m Schnelle selbstansaugende Wird ohne Schaden trocken laufen Wird auf schnarchen arbeitet abrasiven Flüssigkeiten handhaben werden Feststoffe bis zu 80% der Anschlussgröße Schwerlast-, kompakte Bauweise TEFC Elektromotoren passieren als Standard für spezielle Elektromotor-Remko .
<G-vec00113-002-s494><run_out.ablaufen><en> Aluminium/Buna construction Pump Specifications: Nominal Flow Rate: 50L/MIN Discharge Head: 6.0m Suction Lift: 7.5m Solid Size: 35mm Motor Size: 0.75kw Approximate Displacement Per Stroke: 1.5L Weight: 42kg Maximum outside dimensions: 400mm x 335mm x 410mm (LxWxH) Suction lifts to 7.5m Rapid self priming Will run dry without damage Will operate on snore Will handle abrasive liquids Will pass solids up to 80% of port size Heavy duty, compact construction TEFC electric motors fitted as standard Special electric motor enclosures as an option
<G-vec00113-002-s495><run_out.ablaufen><de> Oder laufen Sie ganzjährig Ski in Mitteleuropas größtem und technisch sehr interessant erbauten Skitunnel (Skihalle), dort können Sie als Gruppe auch Laserschießen.
<G-vec00113-002-s495><run_out.ablaufen><en> Or do you run year-round skiing in Central Europe's largest and technically very interesting built ski tunnel (indoor skiing), where you can as a group and laser shooting.
<G-vec00113-002-s496><run_out.ablaufen><de> T: Allein durch die Größe sind wir extrem auf Praktikanten angewiesen, die von Beginn an stark eingebunden werden und ohne die der Laden überhaupt nicht laufen würde.
<G-vec00113-002-s496><run_out.ablaufen><en> Thomas: Due to our size alone, we are extremely dependent on interns who are very much involved from the very beginning and without whom the business wouldn’t run at all.
<G-vec00113-002-s497><run_out.ablaufen><de> Der Garten ist sehr groß - wir hatten zwei Hunde mit uns, die wir in der Lage zu laufen und dort zu spielen waren.
<G-vec00113-002-s497><run_out.ablaufen><en> The garden is very big - we had two dogs with us who were able to run and play there.
<G-vec00113-002-s498><run_out.ablaufen><de> Mehr als 15.000 Vertriebs- und Kundendienstmitarbeiter sowie Händlerverkäufer und Servicetechniker bringen unsere Traktoren an den Mann oder die Frau und sorgen dafür, dass sie zuverlässig laufen.
<G-vec00113-002-s498><run_out.ablaufen><en> Over 15,000 sales and customer service staff, members of dealer sales teams and service technicians bring our tractors to the customers, old, new and prospective, and ensure that they run reliably.
<G-vec00113-002-s499><run_out.ablaufen><de> Wenn sie sofort an einen Platz geliefert werden, der einer Toilette zugeordnet ist (sie können noch nicht stehen), werden bald die Kätzchen dort laufen, und die Welpen laufen zur Tür.
<G-vec00113-002-s499><run_out.ablaufen><en> If they are immediately delivered to a place assigned to a toilet (they can not stand yet), soon the kittens themselves will run there, and the pups will run up to the door.
<G-vec00113-002-s501><run_out.ablaufen><de> Wenn du vorhast, auf technischen Trails so schnell wie der Wind zu laufen, dann darfst du ihn bei einer kleinen Verschnaufpause nicht die Oberhand gewinnen lassen.
<G-vec00113-002-s501><run_out.ablaufen><en> Products info When you aim to run fast as the wind on technical trails, don't let it get the better of you on that short break.
<G-vec00113-002-s502><run_out.ablaufen><de> Es kann eingestellt werden, und kann laufen stabil.
<G-vec00113-002-s502><run_out.ablaufen><en> It can be adjusted and can run stably.
<G-vec00113-002-s503><run_out.ablaufen><de> Die Motoren laufen übrigens in ihrem optimalen Drehzahlbereich sehr leise, bei niedrigeren Drehzahlen und zunehmender Last werden sie deutlich, aber nicht dramatisch hörbar.
<G-vec00113-002-s503><run_out.ablaufen><en> The motors run very quietly in their optimal rotation speed, with lower speeds and increasing load, they are clearly, but not dramatically audible.
<G-vec00113-002-s504><run_out.ablaufen><de> Beim Laufen schwitzen Sie viel und verlieren deshalb viel Flüssigkeit.
<G-vec00113-002-s504><run_out.ablaufen><en> When you run you lose a lot of fluid through sweating, and it’s easy to get dehydrated.
<G-vec00113-002-s505><run_out.ablaufen><de> HINWEIS: Bitdefender 2018 benötigt mindestens 2GB RAM, um ordnungsgemäß zu laufen.
<G-vec00113-002-s505><run_out.ablaufen><en> NOTE: Bitdefender 2018 requires at least 2GB RAM to run properly.
<G-vec00113-002-s506><run_out.ablaufen><de> Zentrales Motiv ist der Öl-Tropfen, der aus dem Tiegel zu laufen scheint.
<G-vec00113-002-s506><run_out.ablaufen><en> The central motif is the oil drop that seems to run out of the crucible.
<G-vec00113-002-s507><run_out.ablaufen><de> Sie können sich über öffentliche europäische oder nationale Programme oder durch private Ressourcen finanzieren und müssen mindestens für die Dauer der Residency laufen (zwischen März 2019 und März 2020).
<G-vec00113-002-s507><run_out.ablaufen><en> They can be funded through public European or national programs or through private resources and must run for at least the duration of the residency (between March 2019 and March 2020).
<G-vec00113-002-s508><run_out.ablaufen><de> Im Gegensatz zu handelsüblichen Softwareanwendungen hat Individualsoftware die bemerkenswerte Fähigkeit, genau so zu laufen, wie wir es uns wünschen.
<G-vec00113-002-s508><run_out.ablaufen><en> Unlike off-the-shelf software applications, custom software has the remarkable ability to run exactly the way we want it to.
<G-vec00113-002-s509><run_out.ablaufen><de> Zum einen sollte das System schon bei niedrigen Drehzahlen in der Lage sein in der Hydrodynamik zu laufen.
<G-vec00113-002-s509><run_out.ablaufen><en> On the one hand, the system should be able to run in hydrodynamics even at low speeds.
<G-vec00113-002-s510><run_out.ablaufen><de> So laufen Sie weder Gefahr, die Böden kostenintensiv austauschen zu müssen, noch bei Ihren Besuchern und Kunden einen negativen Eindruck zu hinterlassen.
<G-vec00113-002-s510><run_out.ablaufen><en> You will not run the risk of having to exchange the floors at a high cost or leaving a negative impression on your visitors and customers.
<G-vec00113-002-s511><run_out.ablaufen><de> Bevölkerung und HelferInnen werden offenbar von Polizeikräften im Dienste des staatlichen Notstandapparates schikaniert: “Sie laufen uns hinterher, sie verbieten uns, sie befehlen uns, sie schimpfen uns aus, wenn wir uns unsere Häuser zurück nehmen wollen”.
<G-vec00113-002-s511><run_out.ablaufen><en> The population and helpers obviously get harassed by police forces at the service of the emergency apparatus of state: “They run after us, they forbid us, they command us, they tell us off when we try to take back our houses“.
<G-vec00113-002-s512><run_out.ablaufen><de> Die Prozesse laufen über eine komplexe SPS-Steuerung.
<G-vec00113-002-s512><run_out.ablaufen><en> The processes run via complex programmable logic controllers (PLC).
<G-vec00113-002-s532><run_out.ablaufen><de> Lauft dort in die rechte Ecke und klettert in die Öffnung hinauf.
<G-vec00113-002-s532><run_out.ablaufen><en> There run into the right corner and climb through the opening.
<G-vec00113-002-s533><run_out.ablaufen><de> Ihr lauft Treppen aufwärts, und ihr lauft Treppen abwärts.
<G-vec00113-002-s533><run_out.ablaufen><en> You run upstairs, and you run downstairs.
<G-vec00113-002-s535><run_out.ablaufen><de> Wenn man Sie nicht zuallererst in sein Leben bringt, lauft man Gefahr, das Leben zum Scheitern zu bringen.
<G-vec00113-002-s535><run_out.ablaufen><en> If you don’t take the time to bring in the big stones in your life first, you run a risk, to fail in life.
<G-vec00113-002-s536><run_out.ablaufen><de> Lauft in die Ecke, zu der Leiter.
<G-vec00113-002-s536><run_out.ablaufen><en> Run into the corner towards the ladder.
<G-vec00113-002-s537><run_out.ablaufen><de> Lauft hier auf die Brücke hinaus.
<G-vec00113-002-s537><run_out.ablaufen><en> Run out onto the bridge.
<G-vec00113-002-s538><run_out.ablaufen><de> Lauft in die Kammer hinaus.
<G-vec00113-002-s538><run_out.ablaufen><en> Run out into the chamber.
<G-vec00113-002-s539><run_out.ablaufen><de> Lauft in die nächste Kammer.
<G-vec00113-002-s539><run_out.ablaufen><en> Run into the next chamber.
<G-vec00113-002-s540><run_out.ablaufen><de> Lauft das Rennen bis zur Ziellinie.
<G-vec00113-002-s540><run_out.ablaufen><en> Run the race to the finish line.
<G-vec00113-002-s541><run_out.ablaufen><de> Lauft in einer geraden Linie zu den Fackeln und sammelt diese ein.
<G-vec00113-002-s541><run_out.ablaufen><en> Run in a straight line towards the flares and pick them up.
<G-vec00113-002-s542><run_out.ablaufen><de> Lauft in den linken Teil der Höhle.
<G-vec00113-002-s542><run_out.ablaufen><en> Run into the left part of the cave.
<G-vec00113-002-s543><run_out.ablaufen><de> Lauft dann mehrmals an der Wand entlang, um genug Schwung zu bekommen.
<G-vec00113-002-s543><run_out.ablaufen><en> Then run along the wall a couple of times to gain enough momentum.
<G-vec00113-002-s544><run_out.ablaufen><de> Lauft nun in die andere Richtung.
<G-vec00113-002-s544><run_out.ablaufen><en> Now run into the other direction.
<G-vec00113-002-s545><run_out.ablaufen><de> Zwei Sprungschalter Lauft nach oben hoch.
<G-vec00113-002-s545><run_out.ablaufen><en> Two Jump Switches Run up to the top.
<G-vec00113-002-s546><run_out.ablaufen><de> Lauft in den neu geöffneten Gang und dahinter die Stufen hoch.
<G-vec00113-002-s546><run_out.ablaufen><en> Run into the newly opened passage and inside up the stairs.
<G-vec00113-002-s547><run_out.ablaufen><de> Lauft um den Pfeiler herum.
<G-vec00113-002-s547><run_out.ablaufen><en> Run around the pillar.
<G-vec00113-002-s548><run_out.ablaufen><de> Lauft zum Ende.
<G-vec00113-002-s548><run_out.ablaufen><en> Run tow the end.
<G-vec00113-002-s549><run_out.ablaufen><de> Lauft stattdessen nach links.
<G-vec00113-002-s549><run_out.ablaufen><en> Run over to the left instead.
<G-vec00113-002-s550><run_out.ablaufen><de> Lauft zu Ende und zieht euch auf die Schräge rechts hinauf.
<G-vec00113-002-s550><run_out.ablaufen><en> Run to the end and pull yourself onto the sloped block on the right.
<G-vec00113-002-s570><run_out.ablaufen><de> Auf allen unseren Server-/Client-Maschinen in der Abteilung läuft Debian.
<G-vec00113-002-s570><run_out.ablaufen><en> All our server/client machines in the Department run on Debian.
<G-vec00113-002-s571><run_out.ablaufen><de> Läuft ein Backup 5x in Folge nicht, wird es automatisch deaktiviert.
<G-vec00113-002-s571><run_out.ablaufen><en> A backup will be automatically deactivated if it does not run 5x in a row.
<G-vec00113-002-s572><run_out.ablaufen><de> Wow Bingo verwendet die Cosy Games-Software, damit Sie wissen, dass es gut läuft.
<G-vec00113-002-s572><run_out.ablaufen><en> Wow Bingo uses the Cozy Games software so you know it is going to run well.
<G-vec00113-002-s573><run_out.ablaufen><de> Betriebszyklus Ein typischer Betriebszyklus des Generators ist 1 Start pro Tag und läuft dann 8 Stunden pro Tag, was 2000 Betriebsstunden pro Jahr entspricht.
<G-vec00113-002-s573><run_out.ablaufen><en> A typical operating cycle for the Generator is 1 start per day and then run for 8 hours per day, which is equivalent to 2000 hours of operation per year.
<G-vec00113-002-s574><run_out.ablaufen><de> Die erste Phase des Projekts wurde 2017 auf den Weg gebracht und läuft bis zur ersten Jahreshälfte 2018.
<G-vec00113-002-s574><run_out.ablaufen><en> The first phase of the project started in 2017 and will run until the first half of 2018.
<G-vec00113-002-s575><run_out.ablaufen><de> Eine queere Ausdrucksform über Körper zu affirmieren, läuft Gefahr, neue Ausschlüsse zu produzieren.
<G-vec00113-002-s575><run_out.ablaufen><en> When you affirm a queer form of expression via bodies, you run the risk of creating new modes of exclusion.
<G-vec00113-002-s576><run_out.ablaufen><de> Fred muss eine Wartung der Datenbank "mydatabase" durchführen, die erfordert, dass die Datenbank während des gesamten Prozesses läuft.
<G-vec00113-002-s576><run_out.ablaufen><en> Fred must perform maintenance on the mydatabase database that requires the database to run throughout the process.
<G-vec00113-002-s577><run_out.ablaufen><de> Der Betrieb läuft rund um die Uhr, 7 Tage die Woche und beschäftigt 120 Vollzeitmitarbeiter.
<G-vec00113-002-s577><run_out.ablaufen><en> They run their operation 24 hours a day, 7 days a week with the help of 120 full-time employees.
<G-vec00113-002-s578><run_out.ablaufen><de> Die Zeichnung erklärt sehr gut das System, Werkzeug läuft schnell nach unten und berührt das Messingblech und empfängt ein Signal (Überlauf ist möglich wegen der Feder), bewegt sich dann frei von Signal zurück und bewegt sich dann langsam wieder zu Messingplatte für genaues Ablesen.
<G-vec00113-002-s578><run_out.ablaufen><en> The drawing explain very well the system, toolbit run quickly down and touch the brassplate and receive a signal (overrun is possible because of the spring) it then moves back free of signal and then move slowly down to brassplate again for accurate reading.
<G-vec00113-002-s579><run_out.ablaufen><de> „Man muss auch mal den Mut zu haben, von Produkten abzuraten, die der Kunde nicht braucht oder die nicht ausgereift sind“, findet Urs Weber und erklärt: „Wer viel läuft und schon eine Laufuhr hat, braucht nicht noch einen weiteren Fitnesstracker.
<G-vec00113-002-s579><run_out.ablaufen><en> “You sometimes have to have the courage to advise against products that the customer doesn’t need, or that aren’t well-engineered,” Weber believes, and explains: “People who run a lot and already have a running watch don’t need another fitness tracker.
<G-vec00113-002-s580><run_out.ablaufen><de> Der Bediener muss lediglich die gewünschte Menge eingeben und der Befüllvorgang läuft so lange bis die Bodenwaage ein Signal an die elektrische Steuerung übergibt, dass die Füllmenge erreicht wurde.
<G-vec00113-002-s580><run_out.ablaufen><en> The operator only needs to enter the desired quantity, then the filling procedure will run until the floor scale emits a signal to the electrical control indicating that the filling quantity has been reached.
<G-vec00113-002-s581><run_out.ablaufen><de> Wenn sich keine überflüssigen Daten auf Deiner Website ansammeln, läuft Dein Blog schneller und sorgt so für ein besseres Nutzererlebnis.
<G-vec00113-002-s581><run_out.ablaufen><en> By not letting extra data build up on your site, your blog will run faster and perform much better for your audience.
<G-vec00113-002-s582><run_out.ablaufen><de> Dies kann darin resultieren, dass das Spiel nicht startet, nicht ordentlich läuft oder der gespeicherte Fortschritt nicht beibehalten werden kann.
<G-vec00113-002-s582><run_out.ablaufen><en> This may cause the game to not start, run properly or may cause 'saving' issues.
<G-vec00113-002-s583><run_out.ablaufen><de> Wenn es nicht läuft, müssen Sie es mit Ihrer Windows XP CD installieren.
<G-vec00113-002-s583><run_out.ablaufen><en> If it doesn’t run, you’ll need to install it from your Windows XP disc.
<G-vec00113-002-s584><run_out.ablaufen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00113-002-s584><run_out.ablaufen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00113-002-s585><run_out.ablaufen><de> Um einen Shop zu installieren, wählen Sie ihn in der Liste aus und drücken Sie darauf: Das Herunterladen startet und die Installation läuft automatisch.
<G-vec00113-002-s585><run_out.ablaufen><en> To install a store, select it in the list and press it: the download will start and the installation will run automatically.
<G-vec00113-002-s586><run_out.ablaufen><de> Die Konecranes Servicetechniker reagieren schnell, sodass unsere Produktion ohne Unterbrechung läuft.
<G-vec00113-002-s586><run_out.ablaufen><en> Konecranes service technicians respond quickly, which means that we can run production without interruptions.
<G-vec00113-002-s587><run_out.ablaufen><de> Bei Ausschalten des Signals MRS läuft der Motor bei eingeschaltetem Startsignal STF oder STR im externen Betrieb.
<G-vec00113-002-s587><run_out.ablaufen><en> Therefore, the motor is run in the external operation mode when the MRS signal is switched off with either of STF and STR on.
<G-vec00113-002-s588><run_out.ablaufen><de> Dazu läuft der Motor am Prüfstand entweder im Normalbetrieb (befeuerterKolben) oder im Schleppbetrieb.
<G-vec00113-002-s588><run_out.ablaufen><en> To do this, the engine is run on the bench either in test mode or normal operating mode.
