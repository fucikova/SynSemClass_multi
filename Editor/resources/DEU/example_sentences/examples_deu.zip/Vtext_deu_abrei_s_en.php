<G-vec00321-002-s000><yank.abreißen><de> Widerstehe dem natürlichen Drang, deine Haut von dem abzureißen, womit sie verbunden ist.
<G-vec00321-002-s000><yank.abreißen><en> Resist the natural urge to pull or yank the skin away from what it’s connected to.
<G-vec00372-002-s113><disrupt.abreißen><de> Um überzuleben, muss man sich darüber, was in der Gegenwart des Kinos geschah, damit erinnern, das Drehbuch abzureißen.
<G-vec00372-002-s113><disrupt.abreißen><en> In order to survive, we have to remember what happened in this movie, in order to disrupt the script.
<G-vec00389-002-s021><demolish.abreißen><de> Mai 1985 Innerhalb von 24 Tagen haben die US-Pioniere mit über 100 Soldaten und 60 Fahrzeugen die weiteren 21 Bauten abgerissen (Offizielle Bezeichnung: Aktion Geisterjagd) und das Gelände eingeebnet.
<G-vec00389-002-s021><demolish.abreißen><en> May 1985 Within 24 days, U.S. pioneer units with more than 100 troops and 60 vehicles demolish the remaining 21 buildings and level the area (official codename "Ghostbusters").
<G-vec00389-003-s065><tear_up.abreißen><de> Um die Gewalt auf den Straßen und grassierende Gang-Delikte einzudämmen, beschloss die Stadtverwaltung im Dezember 2004, einen kompletten Wohnblock in South Central Los Angeles zu räumen und abzureißen.
<G-vec00389-003-s065><tear_up.abreißen><en> In order to contain violence on the streets and rampant gang crime, city authorities decided in December 2004 to clear out and tear down one complete apartment block in South Central Los Angeles.
<G-vec00389-003-s066><tear_up.abreißen><de> Und viele Kinder schaffen es, das Päckchen abzureißen, das sie verhindert.
<G-vec00389-003-s066><tear_up.abreißen><en> And many children contrive to tear off the packet that prevents them.
<G-vec00389-003-s067><tear_up.abreißen><de> Als ich gerade dabei war, es abzureißen, kam ein Mann auf mich zu, der ein Fahrrad schob.
<G-vec00389-003-s067><tear_up.abreißen><en> Just as I was about to tear it down, a man walked toward me pushing a bicycle.
<G-vec00389-003-s068><tear_up.abreißen><de> Leicht abzureißen, mit Mikroperforation zwischen den Tickets.
<G-vec00389-003-s068><tear_up.abreißen><en> Easy to tear off, with micro perforation between each ticket.
<G-vec00389-003-s069><tear_up.abreißen><de> Jede Rolle ist 19mmx50m und einfach abzureißen.
<G-vec00389-003-s069><tear_up.abreißen><en> Each roll is 19mm x 50m and is easy to tear.
<G-vec00389-003-s070><tear_up.abreißen><de> Gaffer Tapes sind sehr robust und typischerweise leicht von Hand abzureißen.
<G-vec00389-003-s070><tear_up.abreißen><en> Gaffer tapes are very robust and characteristically easy to tear off by hand.
<G-vec00389-003-s071><tear_up.abreißen><de> Es gab Diskussionen über verschiedene Pläne entweder das Gebäude zu restaurieren oder es alternativ abzureißen.
<G-vec00389-003-s071><tear_up.abreißen><en> Various plans have been discussed to restore the building or, alternatively, to tear it down.
<G-vec00389-003-s072><tear_up.abreißen><de> Auch der SPD-Außenpolitiker Günter Gloser äußerte sein Unverständnis über das israelische Vorhaben, die Solar- und Windkraftanlagen abzureißen.
<G-vec00389-003-s072><tear_up.abreißen><en> Günter Gloser, Middle East expert of the Social Democrats, has also expressed his incomprehension of Israeli plans to tear down the solar plants and wind turbines.
<G-vec00595-002-s147><detach.abreißen><de> Wahrscheinlich reißt das Wasser diese Krystalle vom anstehenden Gestein ab, wie zu Frascati bei Rom.
<G-vec00595-002-s147><detach.abreißen><en> The waters most probably detach these crystals from the neighbouring rocks, as at Frascati, near Rome.
<G-vec00681-002-s025><rupture.abreißen><de> Werden diese Schäden zu groß, kann es schon bei geringen Belastungen, oder unbedeutenden Bewegungen zum vollständigen Abreißen der Sehnen kommen.
<G-vec00681-002-s025><rupture.abreißen><en> If these tendons are damaged too massively, minor loads or insignificant movements may lead to their entire rupture.
