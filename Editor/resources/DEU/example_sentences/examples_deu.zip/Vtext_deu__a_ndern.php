<G-vec00407-001-s085><amend.ändern><de> Sie können die Ergebnisse bei Bedarf ändern.
<G-vec00407-001-s085><amend.ändern><en> You can amend the results if you like.
<G-vec00407-001-s086><amend.ändern><de> Sie haben das Recht, Ihre personenbezogenen Informationen abzurufen und bei Bedarf zu ändern.
<G-vec00407-001-s086><amend.ändern><en> You have the right to access and, where relevant, to amend your personal information.
<G-vec00407-001-s103><amend.ändern><de> Der Stab empfahl dem Board, die Textziffern 117-124 von IAS 1 dahingehend zu ändern, dass Unternehmen ihre wesentlichen und nicht ihre maßgeblichen Bilanzierungs- und Bewertungsmethoden anzugeben haben.
<G-vec00407-001-s103><amend.ändern><en> Staff recommended that the Board amend paragraphs 117–124 of IAS 1 to require entities to disclose their material accounting policies rather than their significant accounting policies.
<G-vec00407-001-s104><amend.ändern><de> Sofern der Kunde von Dritten wegen Verletzung von Urheber- und/oder gewerblichen Schutzrechten hinsichtlich von uns gelieferten und vertragsgemäß genutzten Gegenständen berechtigt in Anspruch genommen wird, werden wir wie folgt hierfür einstehen: Entweder werden wir nach unserer Wahl und auf unsere Kosten den betroffenen Gegenstand dahingehend ändern, dass ein Schutzrecht des Dritten nicht mehr verletzt wird oder einen nicht von dem Schutzrecht umfassten adäquaten Ersatzgegenstand liefern.
<G-vec00407-001-s104><amend.ändern><en> Insofar as Client is justifiably sued by third parties on account of copyrights and/or industrial protection rights with regard to the commodities supplied by us and used contractually, we shall take responsibility for this as follows: either we shall amend the object affected at our discretion and at our expense in such a way that a protective right of the third party is no longer breached or we shall supply an adequate replacement object not affected by the protective right.
<G-vec00407-001-s107><amend.ändern><de> Die H&M Gruppe behält sich das Recht vor ohne Vorankündigung diese Vorteile einseitig zu ändern oder zu widerrufen.
<G-vec00407-001-s107><amend.ändern><en> The H&M group reserves the right to amend or discontinue any of these benefits without notice.
<G-vec00407-001-s108><amend.ändern><de> *Die H&M Gruppe behält sich das Recht vor die genannten Vorteile ohne Vorankündigung einseitig zu ändern oder zu beenden.
<G-vec00407-001-s108><amend.ändern><en> *The H&M group reserves the right to amend or discontinue any of these benefits without notice.
<G-vec00407-001-s109><amend.ändern><de> behält sich das Recht vor in jedem Moment und ohne vorherige Ankündigung den Datenschutz einseitig zu ändern, um diesen an die derzeitigen Rechtsvorschriften anzupassen.
<G-vec00407-001-s109><amend.ändern><en> reserves the right to amend, at any time and without previous notice, its Personal Data Protection Policy in order to adjust it to the legislation in force at any particular time.
<G-vec00407-001-s142><amend.ändern><de> Somit hätten die Beschwerdeführer mit ihrem ersten, in der mündlichen Verhandlung vorgetragenen Argument ihr in der Beschwerdebegründung enthaltenes Vorbringen nicht wesentlich geändert.
<G-vec00407-001-s142><amend.ändern><en> Thus, by submitting the first line of argument at the oral proceedings the appellants did not amend their case, as set out in the grounds of appeal, in a substantial manner.
<G-vec00407-001-s143><amend.ändern><de> Ryanair ist nicht verantwortlich für die Passagiere, die ihre Reiseversicherungsdetails falsch geändert haben.
<G-vec00407-001-s143><amend.ändern><en> Ryanair is not responsible for any passengers who fail to amend their travel insurance policy details.
<G-vec00407-001-s144><amend.ändern><de> Für die Begründung der Europäischen Union sowie für Änderungen ihrer vertraglichen Grundlagen und vergleichbare Regelungen, durch die dieses Grundgesetz seinem Inhalt nach geändert oder ergänzt wird oder solche Änderungen oder Ergänzungen ermöglicht werden, gilt Artikel 79 Absatz 2 und 3.
<G-vec00407-001-s144><amend.ändern><en> The establishment of the European Union, as well as changes in its treaty foundations and comparable regulations that amend or supplement this Basic Law, or make such amendments or supplements possible, shall be subject to paragraphs (2) and (3) of Article 79.
<G-vec00407-001-s199><amend.ändern><de> Wir behalten uns vor, die vorliegenden Nutzungsbedingungen von Zeit zu Zeit zu ändern.
<G-vec00407-001-s199><amend.ändern><en> We may amend these Terms of Use from time to time.
<G-vec00407-001-s200><amend.ändern><de> Schlug ich, vor die angemessenen Richtlinien für angemessene Arbeitsbedingungen zu ändern verfahre nach der Verringerung des Standardworkweek auf 32 Stunden, die Halbzeitüberstundenzulage im Allgemeinen weg besteuernd, anstatt, sie zu zahlen zur Überstundenarbeitskraft, unter Verwendung dieses Geldes, um irgendwelche verlorenen Löhne und das Festziehen der Befreiung für die Verwaltungs- und Berufsangestellten zu entschädigen.
<G-vec00407-001-s200><amend.ändern><en> Basically, I proposed to amend the Fair Labor Standards Act by reducing the standard workweek to 32 hours, taxing away the half-time overtime premium instead of paying it to the overtime worker, using this money to compensate for any lost wages, and tightening the exemption for managerial and professional employees.
<G-vec00407-001-s204><amend.ändern><de> Doch nun ändere ich das in: Frag nicht danach, was die Welt für dich tun kann, sondern was du für die Welt tun kannst.
<G-vec00407-001-s204><amend.ändern><en> But now I amend those: Ask not what your world can do for you. Ask what you can do for your world.
<G-vec00407-001-s205><amend.ändern><de> Nachprüfen: Frage andere Personen deinen Text zu lesen und kommentieren, ändere es dann ab.
<G-vec00407-001-s205><amend.ändern><en> Revising: ask other people to read and comment on your text, then amend it.
<G-vec00407-001-s206><amend.ändern><de> So warum müssen Sie den Boden ändern und wie Sie tun ihn?Die Antwort zu beiden Fragen hängt von ab, was Sie beabsichtigen, zu pflanzen und...
<G-vec00407-001-s206><amend.ändern><en> So why do you need to amend the soil and how do you do it?The answer to both of these questions depends on what you intend to plant and the soil in your garden.
<G-vec00407-001-s207><amend.ändern><de> Caterpillar Financial behält sich das Recht vor, diesen Datenschutzhinweis zu ändern.
<G-vec00407-001-s207><amend.ändern><en> Caterpillar Financial reserves the right to amend this privacy notice at any time.
<G-vec00407-001-s208><amend.ändern><de> Videoslots behält sich das Recht vor, die Weekend Madness Battle jederzeit ohne vorherige Ankündigung zu stornieren oder zu ändern.
<G-vec00407-001-s208><amend.ändern><en> Videoslots reserves the right to cancel or amend this Battle Weekend at any given time without prior notice.
<G-vec00407-001-s209><amend.ändern><de> 1.2 Wir können die AGB jederzeit nach eigenem Ermessen ergänzen oder ändern.
<G-vec00407-001-s209><amend.ändern><en> 1.2 We shall be entitled to supplement or amend the GTC at any time at our own discretion.
<G-vec00407-001-s210><amend.ändern><de> Ist ein Mitarbeitender nach einem Unfall arbeitsunfähig, dürfen Sie ihm während einer gesetzlich geregelten Zeitspanne weder kündigen noch den Vertrag ändern.
<G-vec00407-001-s210><amend.ändern><en> For employees who are incapable of working following an accident, you may not terminate their position or amend their employment contract for a period of time specified by law.
<G-vec00407-001-s211><amend.ändern><de> Die STAHL CraneSystems GmbH behält sich vor, die Daten­schutz­erklärung jederzeit mit Wirkung für die Zukunft zu ändern.
<G-vec00407-001-s211><amend.ändern><en> STAHL CraneSystems GmbH reserves the right to amend the privacy statement at any time with future effect.
<G-vec00407-001-s212><amend.ändern><de> 3 Beabsichtigt die Beschwerdeinstanz, die angefochtene Verfügung zuungunsten einer Partei zu ändern, so bringt sie der Partei diese Absicht zur Kenntnis und räumt ihr Gelegenheit zur Gegenäusserung ein.
<G-vec00407-001-s212><amend.ändern><en> 3 Â If the appellate authority intends to amend the contested ruling to the prejudice of a party, it shall notify the party of this intention and allow him the opportunity to respond.
<G-vec00407-001-s213><amend.ändern><de> Einzelpersonen können verlangen, auf Informationen, die wir über sie haben, zuzugreifen, sie zu korrigieren, zu ändern oder zu löschen, indem sie auf unserer Kontaktseite Kontakt aufnehmen.
<G-vec00407-001-s213><amend.ändern><en> Individuals may request to access, correct, amend or delete information we hold about them by contacting on our contact page.
<G-vec00407-001-s214><amend.ändern><de> Wir behalten uns das Recht vor, die Datenschutzrichtlinien zu ändern, zu ergänzen oder Teile davon jederzeit zu entfernen.
<G-vec00407-001-s214><amend.ändern><en> We reserve the right to amend, augment or delete parts of this Privacy Policy at any time. Any changes will be displayed on the website
<G-vec00407-001-s215><amend.ändern><de> MATESO behält sich vor, die allgemeinen Bedingungen jederzeit ändern zu können.
<G-vec00407-001-s215><amend.ändern><en> MATESO reserves the right to amend its general terms and conditions at any time.
<G-vec00407-001-s216><amend.ändern><de> Wir können diese Nutzungsbedingungen jederzeit ändern, indem wir Sie per E-Mail über die neuen Bedingungen benachrichtigen und/oder die geänderten Nutzungsbedingungen auf einer unserer Websites veröffentlichen.
<G-vec00407-001-s216><amend.ändern><en> We may amend these Terms and Conditions at any time either by emailing You notification of the new terms and/or by publishing the modified Terms and Conditions on any of the Sites for your information and acceptance.
<G-vec00407-001-s217><amend.ändern><de> Die Europäische Kommission hat Belgien offiziell aufgefordert, seine Vorschriften bezüglich der jährlichen Steuer für ausländische Organismen für gemeinsame Anlagen (OGA) zu ändern.
<G-vec00407-001-s217><amend.ändern><en> The European Commission has officially asked Belgium to amend the rules which it applies for the annual taxation of foreign collective investment undertakings (CIUs).
<G-vec00407-001-s218><amend.ändern><de> Star's Edge International ist bemüht, angemessene Schritte zu unternehmen, um dir zu ermöglichen, die Nutzung deiner persönlichen Daten zu korrigieren, zu ändern, zu löschen oder zu begrenzen.
<G-vec00407-001-s218><amend.ändern><en> Star's Edge International aims to take reasonable steps to allow you to correct, amend, delete, or limit the use of your Personal Data.
<G-vec00407-001-s219><amend.ändern><de> Es ist nicht ratsam, ein Papierticket an einer Ticketverkaufsstelle zu kaufen, da Sie einen höheren Preis für Papiertickets bezahlen, die außerdem schwierig zu stornieren oder zu ändern sind.
<G-vec00407-001-s219><amend.ändern><en> It is not recommended to buy a paper ticket via any ticket selling agency as you will pay a premium price for paper tickets, which are difficult to cancel or amend.
<G-vec00407-001-s220><amend.ändern><de> Unbeschadet Ihrer Rechte gemäß einschlägiger Gesetzgebung, behält ONTEX sich das Recht vor, diese Datenschutzerklärung von Zeit zu Zeit zu ändern, um technologischen Fortschritten, behördlichen und gesetzlichen Änderungen und guten Geschäftspraktiken Rechnung zu tragen.
<G-vec00407-001-s220><amend.ändern><en> Without prejudice to your rights under applicable law, ONTEX reserves the right to amend this Privacy Statement from time to time to reflect technological advancements, legal and regulatory changes and good business practices.
<G-vec00407-001-s221><amend.ändern><de> Sie können Ihre persönlichen Daten jederzeit durch Anmeldung in Ihrem Konto online sehen und ändern.
<G-vec00407-001-s221><amend.ändern><en> You can view and amend your personal information at any time by logging in to your account online.
<G-vec00407-001-s222><amend.ändern><de> Wir behalten uns das Recht vor, diese Erklärung jederzeit zu ändern.
<G-vec00407-001-s222><amend.ändern><en> We reserve the right to amend this statement at any time.
<G-vec00407-001-s223><amend.ändern><de> Wir behalten uns vor, diese Datenschutzerklärung gemäß sich ändernder gesetzlicher oder behördlicher Bestimmungen, aufgrund der Weiterentwicklung unseres Internetauftritts oder aufgrund unserer Bemühungen, diese Erklärung fortlaufend zu verbessern, zu ändern.
<G-vec00407-001-s223><amend.ändern><en> We reserve the right to amend this Privacy Policy to reflect changing statutory or regulatory requirements, to take into account changes to our website or in the context of our ongoing efforts to constantly improve this Privacy Policy.
<G-vec00407-001-s224><amend.ändern><de> Wir fordern die griechische Regierung auf, ihre Versprechen zu erfüllen, die entsprechenden Gesetze unverzüglich zu ändern und allen Kriegsdienstverweigerern, die dies wünschen, die Ableistung eines alternativen zivilen Dienstes zu ermöglichen.
<G-vec00407-001-s224><amend.ändern><en> We urge the Greek government to fulfill its promises, to immediately amend the relevant legislation and allow all conscientious objectors who wish so, to perform the alternative civilian service.
<G-vec00407-001-s229><amend.ändern><de> Ändert eure Wege, und tragt zur Wiedergutmachung eurer Sünden bei, durch Gebet, Buße und Wohltätigkeit, so dass die Flüche von euren Sünden nicht auf eure Kinder und auf die folgenden Generationen kommen mögen; andernfalls werden eure Kinder und ihre Kinder euch verantwortlich machen für ihr Unglück und ihre Leiden.
<G-vec00407-001-s229><amend.ändern><en> Amend your ways and atone your sins by prayer, penance and charity so that the curses of your sins may not fall on your children and the following generations; otherwise your children and their children will hold you responsible for their misfortune and sufferings.
<G-vec00407-001-s230><amend.ändern><de> Die bundesstaatlichen Behörden haben Crowflight darauf hingewiesen, dass das Empfehlungsschreiben der bundesstaatlichen Behörden an den Governor in Council (Kabinett), in dem empfohlen wird, dass das Kabinett das Schedule 2 der Metal Mining Effluent Regulations ändert und Bucko Lake zur Tailings Impoundment Area erklärt, Anfang Januar 2008 abgeschickt wird, nachdem die öffentliche Überprüfung abgeschlossen ist, Kommentare über die Überprüfung abgegeben wurden und keine weiteren Überprüfungen erforderlich sind.
<G-vec00407-001-s230><amend.ändern><en> Federal authorities have indicated to Crowflight that upon completion of the public review, inclusion of comments from the review, and assuming that no revisions are required, then the letter of recommendation from federal authorities to the Governor in Council (Cabinet) recommending that Cabinet amend Schedule 2 of the Metal Mining Effluent Regulations to add Bucko Lake as a Tailings Impoundment Area will be sent by early January 2008.
<G-vec00407-001-s231><amend.ändern><de> Nach dem Tag ist die aufrechte Platte im Allgemeinen, zwischen Himmel installiert und Gesetzgebung, Gesetzgebungsbündiges mit den Boden und die Blockierung alles Klinkenhakens ändert.
<G-vec00407-001-s231><amend.ändern><en> After the day, the upright plate is generally installed, between heaven and amend legislation, legislation flush with the floor and locking all latch hook each other.
<G-vec00407-001-s232><amend.ändern><de> Sofern gesetzlich vorgeschrieben, gewährt EFI Einzelpersonen Zugriff auf ihre Personendaten und/oder ändert, löscht, korrigiert ihre Personendaten oder ermöglicht den Zugriff auf sie, wenn sie unzutreffend sind oder gesetzeswidrig verarbeitet werden.
<G-vec00407-001-s232><amend.ändern><en> Where required by law, EFI will grant individuals access to their Personal Information and/or amend, delete, correct or provide access their Personal Information if it is inaccurate or being processed in violation of law.
<G-vec00407-001-s233><amend.ändern><de> (14) Diese Richtlinie ändert die Verordnung über die Zusammenarbeit im Verbraucherschutz: In den Anhang der genannten Verordnung wird ein Verweis auf diese Richtlinie eingefügt, um eine abgestimmte Rechtsdurchsetzung durch die Verbraucherschutzbehörden im Geltungsbereich dieser Richtlinie zu ermöglichen.
<G-vec00407-001-s233><amend.ändern><en> (14) This Directive will amend the Regulation on consumer protection cooperation to add a reference of this Directive in the Annex of that Regulation enabling coordinated enforcement actions by the Consumer Protection authorities in the field covered by this Directive.
<G-vec00254-002-s211><manipulate.ändern><de> Es sollte vermerkt werden, daß der 2352-Byte-Sektor die kleinste Einheit ist, die ein CD-ROM-Laufwerk Software erlauben wird, zu ändern.
<G-vec00254-002-s211><manipulate.ändern><en> It should be pointed out that the 2352-byte sector is the smallest unit most CD-ROM drives will allow software to manipulate.
<G-vec00254-002-s212><manipulate.ändern><de> Du kannst das Bild vergrößern und seine Position innerhalb des Rahmens ändern.
<G-vec00254-002-s212><manipulate.ändern><en> You have the option to magnify the image and manipulate its position within the square.
<G-vec00254-002-s213><manipulate.ändern><de> JAWS aktiviert den Formularmodus, wenn es glaubt, dass Sie Text eingeben, Text überprüfen oder ein Steuerelement ändern müssen.
<G-vec00254-002-s213><manipulate.ändern><en> JAWS activates Forms Mode when it believes that you'll need to enter text, review text, or manipulate a control.
<G-vec00254-002-s214><manipulate.ändern><de> Wenn Sie Animationen in Adobe Edge Animate erstellen, ziehen Sie Elemente auf die Bühne und ändern Sie deren Bewegungen mittels einer Zeitleiste.
<G-vec00254-002-s214><manipulate.ändern><en> When you construct animations in Adobe Edge Animate, you drag elements onto the stage and manipulate their movements using a timeline.
<G-vec00254-002-s215><manipulate.ändern><de> Mit dieser Funktion können Sie das Erscheinungsbild und Verhalten des Objekts direkt im Eigenschafteninspektor schnell und einfach ändern.
<G-vec00254-002-s215><manipulate.ändern><en> This feature gives you the freedom to manipulate object behavior and appearance quickly and easily directly from the Property Inspector.
<G-vec00301-002-s293><rectify.ändern><de> Ein Umstand, den das Institut für Softwaretechnologie der TU Graz gemeinsam mit Partnerinstitutionen aus Österreich und Ungarn ändern will.
<G-vec00301-002-s293><rectify.ändern><en> This is something that the Institute of Software Technology at TU Graz together with partner institutions in Austria and Hungary wants to rectify.
<G-vec00360-002-s295><evolve.ändern><de> Stellen Sie sicher, dass Sie Drucker hinzufügen oder ein Upgrade auf eine höhere Edition durchführen können, wenn sich Ihre Geschäftsanforderungen ändern.
<G-vec00360-002-s295><evolve.ändern><en> Ensure you can add printers or upgrade to a higher edition as your business needs evolve.
<G-vec00360-002-s296><evolve.ändern><de> Wir bei Cisco wissen, dass sich die Bedürfnisse des Marktes schnell ändern, wenn Technologien weiterentwickelt werden und neue entstehen.
<G-vec00360-002-s296><evolve.ändern><en> Yes Cisco understands that the needs of the market evolve rapidly as technologies evolve and new technologies emerge.
<G-vec00360-002-s297><evolve.ändern><de> Sollten sich die Nutzerbedürfnisse ändern, können die Paneele für andere Räume neu konfiguriert oder bestehende Arrangements mit neuen Paneelfarben aufgefrischt werden.
<G-vec00360-002-s297><evolve.ändern><en> As needs evolve, panels can be reconfigured for another space or existing compositions can be refreshed with new panel colors.
<G-vec00360-002-s298><evolve.ändern><de> Nutzen Sie hochwertige Lösungen und erweitern Sie diese, wenn sich Ihre Anforderungen ändern.
<G-vec00360-002-s298><evolve.ändern><en> Deploy quality solutions and easily expand them as your needs evolve.
<G-vec00360-002-s299><evolve.ändern><de> Die Produkteigenschaften der auf der Webseite präsentierten Produkte können sich ändern.
<G-vec00360-002-s299><evolve.ändern><en> The characteristics of the products presented on the site can evolve.
<G-vec00360-002-s300><evolve.ändern><de> Unsere Tätigkeiten können sich im Laufe der Zeit ändern und wir können diese Datenschutzerklärung entsprechend aktualisieren.
<G-vec00360-002-s300><evolve.ändern><en> Our activities may evolve over time and we may update this privacy policy accordingly.
<G-vec00360-002-s301><evolve.ändern><de> Diese Studie, die in diesem Jahr in die fünfte Runde geht, untersucht die Erwartungshaltungen von Chief Communications Officers (kurz: CCOs) in Nordamerika, Europa, Lateinamerika und im asiatisch-pazifischen Raum, wie sich ihre Aufgaben und Arbeitsbereiche durch die immer weitere digitalisierte und von Medien zunehmend fragmentierte Welt ändern.
<G-vec00360-002-s301><evolve.ändern><en> This survey, now in its fifth year, explores how chief communications officers (CCOs) from North America, Europe, Asia Pacific and Latin America expect their responsibilities to evolve over time in an increasingly digitalised and media-fragmented world.
<G-vec00360-002-s302><evolve.ändern><de> „Da sich die Geschäftsanforderungen von Nationwide ändern, passen wir unsere Marketingressourcen an, um sicherzustellen, dass wir uns an diesen neuen Geschäftsprioritäten ausrichten.
<G-vec00360-002-s302><evolve.ändern><en> “As Nationwide’s business needs evolve, we are adjusting our marketing resources to ensure that we are aligning to those new business priorities.
<G-vec00407-002-s132><amend.ändern><de> Sofern zwischen Ihnen und uns ein Vertragsverhältnis begründet, inhaltlich ausgestaltet oder geändert werden soll, erheben und verwenden wir personenbezogene Daten von Ihnen, soweit dies zu diesen Zwecken erforderlich ist.
<G-vec00407-002-s132><amend.ändern><en> Personal details Where we are to enter into, set up or amend a contractual relationship with you, we collect and use your personal data where required for these purposes.
<G-vec00407-002-s133><amend.ändern><de> Wir empfehlen Ihnen, diese Datenschutzhinweise von Zeit zu Zeit zu überprüfen, so dass Sie wissen, ob die Privatsphäre und Datenschutz geändert oder aktualisiert wurde.
<G-vec00407-002-s133><amend.ändern><en> From time to time we may update or amend this policy, we would like to encourage you to review this Privacy Policy from time to time so you are aware of any updates.
<G-vec00407-002-s134><amend.ändern><de> Weiterhin kann der Fahrplan jeglicher Tour geändert und/oder stornieren werden.
<G-vec00407-002-s134><amend.ändern><en> Furthermore, they reserve the right to amend and/or cancel the schedule for any tour
<G-vec00407-002-s135><amend.ändern><de> RUNTIME Designer: Erzeugte RUNTIME Definitionen konnten zwar beim Kunden mit der Freeware Version geändert und ausgeführt werden, das anschließende Speichern der Definition wurde aber dann mit der Fehlermeldung „Die Freeware Version unterstützt das Speichern von Definitionen nicht!“ abgebrochen.
<G-vec00407-002-s135><amend.ändern><en> RUNTIME Designer: Users were able to amend and run RUNTIME Definitions with the Freeware Version, but it terminated when finally saving the Definition with the error message “The Freeware Version does not support the saving of Definitions.”
<G-vec00407-002-s136><amend.ändern><de> Diese Teilnahmebedingungen können jederzeit von der ElringKlinger AG ohne gesonderte Benachrichtigung geändert werden.
<G-vec00407-002-s136><amend.ändern><en> ElringKlinger AG is entitled to amend the conditions of entry at any time without specific notification.
<G-vec00407-002-s137><amend.ändern><de> Erwägung 3 (3) Die Richtlinie 2011/92/EU muss geändert werden, um die Qualität des UVP-Verfahrens zu erhöhen, die einzelnen Verfahrensschritte zu rationalisieren und die Kohärenz und die Synergien mit anderen EU-Rechtsvorschriften und –Politiken sowie mit den Strategien und Politiken, die die Mitgliedstaaten in bestimmten in die nationale Zuständigkeit fallenden Bereichen erarbeitet haben, zu verstärken.
<G-vec00407-002-s137><amend.ändern><en> (3) It is necessary to amend Directive 2011/92/EU in order to strengthen the quality of the environmental impact assessment procedure, align that procedure with the principles of smart regulation and enhance coherence and synergies with other Union legislation and policies, as well as strategies and policies developed by Member States in areas of national competence.
<G-vec00407-002-s138><amend.ändern><de> Diese Bedingungen können von Zeit zu Zeit geändert werden.
<G-vec00407-002-s138><amend.ändern><en> We may amend these Terms from time to time.
<G-vec00407-002-s139><amend.ändern><de> Das Blasphemiegesetz muss dringend geändert werden, um Missbrauch zu verhindern.
<G-vec00407-002-s139><amend.ändern><en> It is urgent to amend the blasphemy law to prevent abuses.
<G-vec00407-002-s141><amend.ändern><de> (3) Die Anlage der Richtlinie 96/49/EG muss daher geändert werden.
<G-vec00407-002-s141><amend.ändern><en> (3) It is therefore necessary to amend the Annex to Directive 96/49/EC.
<G-vec00407-002-s142><amend.ändern><de> Beachten Sie, dass die Elemente, die geändert werden können, von der jeweiligen Route abhängen.
<G-vec00407-002-s142><amend.ändern><en> Please note that the elements that you can amend might vary from route to route.
<G-vec00407-002-s143><amend.ändern><de> (7) Der Kommission wird die Befugnis übertragen, gemäß Artikel 87 delegierte Rechtsakte zu erlassen, mit denen Anhang I geändert wird, um die Liste der öffentlichen Auftraggeber entsprechend den von den Mitgliedstaaten übermittelten Mitteilungen zu aktualisieren, soweit die betreffenden Änderungen erforderlich sind, um öffentliche Auftraggeber korrekt zu ermitteln.
<G-vec00407-002-s143><amend.ändern><en> 7. The Commission shall be empowered to adopt delegated acts in accordance with Article 87 to amend Annex I, in order to update the list of contracting authorities following notifications from Member States, where such amendments prove necessary to correctly identify contracting authorities.
<G-vec00407-002-s144><amend.ändern><de> 3.2 Preise und Gebühren für Angebote von Apps und In-App Käufen können durch Mack Media jederzeit mit Wirkung für künftige Vertragsschlüsse geändert werden.
<G-vec00407-002-s144><amend.ändern><en> 3.2 Mack Media may amend prices and fees for offers of apps and in-app purchases at any time with effect for contracts concluded in the future.
<G-vec00430-002-s513><change.ändern><de> Wenn Sie möchten, dass Paylobby Ihre personenbezogenen Daten ändert oder Ihre Daten nicht mehr nutzt, können Sie Paylobby unter info@paylobby.com kontaktieren.
<G-vec00430-002-s513><change.ändern><en> If you would like Paylobby to change your personal data or no longer use your data, you can contact Paylobby at info@paylobby.com.
<G-vec00430-002-s514><change.ändern><de> Durch einen formfreien Preis wird der Preis nur angepasst (auch wenn sich der Umrechnungskurs ändert), wenn Sie ein Update mit einem neuen Preis übermitteln.Grundpreise für mehrere Märkte zu überschreiben, erstellen Sie eine Marktgruppe.To override the base price for multiple markets, you’ll create a market group.
<G-vec00430-002-s514><change.ändern><en> This price will be used only for customers on Windows 10 (including Xbox) in the selected market. If you enter a free-form price, that price will not be adjusted (even if conversion rates change) unless you submit an update with a new price.
<G-vec00430-002-s515><change.ändern><de> Sie können leicht später addiert werden, wenn Bedarf ändert.
<G-vec00430-002-s515><change.ändern><en> They can be easily added later if needs change.
<G-vec00430-002-s516><change.ändern><de> Auf Bestellung innerhalb von 4 Arbeitstagen Schutzfolie - 100% Garantie gegen Kratzer, lebenslange Garantie, extreme Widerstandsfähigkeit und volle Transparenz, die Folie ändert nicht die Farben des Displays, das Display...
<G-vec00430-002-s516><change.ändern><en> Ordered on request within 4 days Screen protector - 100% protection against scratches, lifetime warranty, extreme durability and full transparency, does not change the colours of the display, makes your...
<G-vec00430-002-s517><change.ändern><de> Dies ist ein absolut sicherer Vorgang, denn Start Menu 7 ändert keine Systemeinstellungen.
<G-vec00430-002-s517><change.ändern><en> It is safe because Start Menu 7 does not change your system!
<G-vec00430-002-s518><change.ändern><de> Wenn diese Option aktiviert ist, werden Änderungen in ACL auch dann erkannt, wenn sich der Dateikörper nicht ändert.
<G-vec00430-002-s518><change.ändern><en> If checked, changes in ACL are detected even when the file body does not change.
<G-vec00430-002-s519><change.ändern><de> FIXED (FEST): Wenn diese Einstellung gewählt wird, ändert sich der Ton des Fernsehers über die AUDIO OUT-Buchsen nicht, wenn die Lautstärkentasten der Fernbedienung des Fernsehers gedrückt werden.
<G-vec00430-002-s519><change.ändern><en> FIXED: When this setting is selected, the television audio through the AUDIO OUT jacks does not change How do I watch subscribed services using a smart card module?Table of contents: 1.
<G-vec00430-002-s520><change.ändern><de> An all dem ändert auch Tomboy nichts.
<G-vec00430-002-s520><change.ändern><en> Not even Tomboy could change anything about that.
<G-vec00430-002-s521><change.ändern><de> Manchmal ändert ein Paket seinen Bereich.
<G-vec00430-002-s521><change.ändern><en> Sometimes a package will change its section.
<G-vec00430-002-s522><change.ändern><de> Überprüfe, ob jemand seine Stimme ändert, oder ob sich plötzlich die Körpersprache ändert.
<G-vec00430-002-s522><change.ändern><en> Check to see if someone's voice changes, or if they suddenly change their body language.
<G-vec00430-002-s523><change.ändern><de> Bei einer öffentlichen Seite ändert die Berechtigung Seite durchsuchen nichts an der Zugriffssicherheit dieser Seite, da sie bereits für jeden zugänglich ist, der Zugriff auf die Domain hat.
<G-vec00430-002-s523><change.ändern><en> For a public page, the Browse page permission doesn't change anything to the access security of that page because it is already accessible by anybody who has access to the domain.
<G-vec00430-002-s524><change.ändern><de> Was immer an Versperrung er manifestiert, er ändert die Natur des Lebens nicht.
<G-vec00430-002-s524><change.ändern><en> Whatever obstruction he manifests, he does not change the nature of life.
<G-vec00430-002-s525><change.ändern><de> Es ändert Ihre IP-Adresse nicht und verschlüsselt Ihre Verbindung nicht wie VPN, bietet jedoch eine höhere Internetgeschwindigkeit beim Anschauen von Videoinhalten.
<G-vec00430-002-s525><change.ändern><en> It doesn’t change your IP and doesn’t encrypt your connection like VPN but offers better speed when watching video content.
<G-vec00430-002-s526><change.ändern><de> Beschreibung Aktionssteuerungen lösen Aktionen aus, wenn sich der Status von Rocrail-Objekten ändert.
<G-vec00430-002-s526><change.ändern><en> Description Action controls trigger actions when the states of Rocrail objects change.
<G-vec00430-002-s527><change.ändern><de> Falls nach einer vorbestimmten Anzahl von CK4-Taktzyklen ein Rahmensignal nicht detektiert wird, dann bewirkt der Zähler 850, dass die MUX-Steuerlogik 848 die Phase des CK4 unter Verwendung des MUX 828 ändert (8).
<G-vec00430-002-s527><change.ändern><en> If after a predetermined number of CK4 clock cycles a framing signal is not detected. then counter 850 will cause mux control logic 848 to change the phase of CK4 using mux 828 (FIG.
<G-vec00430-002-s528><change.ändern><de> Das elektromagnetische Feld ändert seine möglichen Wirkungen mit höher werdender Frequenz.
<G-vec00430-002-s528><change.ändern><en> The possible effects of an electromagnetic field change with increasing frequency.
<G-vec00430-002-s529><change.ändern><de> Die Online-Glücksspielindustrie hat darauf gewartet, dass die Technologie das Zahlungsverfahren in den Online-Casinos ändert.
<G-vec00430-002-s529><change.ändern><en> The online gambling industry has been waiting for the technology to change the payment procedure at online casinos.
<G-vec00430-002-s530><change.ändern><de> Er ändert ebenfalls die Stimme der Musik, fügt neuen Dateien Effekte für Hören oder Aufnehmen zu.
<G-vec00430-002-s530><change.ändern><en> You can also change music by adding effects for listening or recording to a new file.
<G-vec00430-002-s531><change.ändern><de> Battle Bears Royale, ein teambasierter Third-Person-Shooter Actionspiel für Android, ändert wie Sie über Teddybären denken.
<G-vec00430-002-s531><change.ändern><en> Battle Bears Royale, a team based third-person shooter action game for Android, will change the way you think about teddy bears.
<G-vec00496-002-s711><shift.ändern><de> Eine neue Regierung, die imstande ist, die Richtung der Politik radikal zu ändern, kann der Grund sein, in einen Markt einzutreten oder ihn zu verlassen.
<G-vec00496-002-s711><shift.ändern><en> A new administration that has the ability to radically shift policy direction can be reason to enter or exit a market.
<G-vec00496-002-s712><shift.ändern><de> Da mehr Suchanfragen durchgeführt, aber weniger Ergebnisse angezeigt werden, müssen viele Webseiten ihre Strategie ändern.
<G-vec00496-002-s712><shift.ändern><en> With more searches being performed and fewer results being shown, a lot of websites are going to need to shift strategies.
<G-vec00496-002-s713><shift.ändern><de> Ein Kunde möchte vielleicht den Kursschwerpunkt oder die Lernziele mitten im Projekt noch ändern.
<G-vec00496-002-s713><shift.ändern><en> The client might shift the scope of the elearning project or the learning objectives halfway through the project.
<G-vec00496-002-s714><shift.ändern><de> Wenn sich ökonomische Rahmenbedingungen ändern, kann eine Anlagenverlegung die wirtschaftlich attraktivste Lösung für eine solche Investition sein.
<G-vec00496-002-s714><shift.ändern><en> But when the economic goalposts shift, relocating the entire plant may be the most cost-efficient option to safeguard the investment.
<G-vec00496-002-s715><shift.ändern><de> Wir müssen nur unser Verhalten ändern, insbesondere unseren Konsum, wir müssen den Anteil an Kunststoffen, die wir nutzen, minimieren.
<G-vec00496-002-s715><shift.ändern><en> All we need to do is shift our behavior, particularly our consumption, minimize the amount of plastic that we use.
<G-vec00496-002-s716><shift.ändern><de> Die Effekte Tempo ändern, Rate ändern, Tonhöhe ändern und Umkehren sowie Stimme verwandeln werden auf alle Kanäle angewandt, unabhängig davon, ob Sie einen oder mehrere Kanäle deaktiviert oder nicht deaktiviert haben.
<G-vec00496-002-s716><shift.ändern><en> The Tempo Change, Rate Change, Pitch Shift and Reverse effects, as well as the Voice Morpher effect, will be applied to all channels whether you disabled them or not.
<G-vec00496-002-s717><shift.ändern><de> Mit Hilfe des Rad können Sie Seiten umdrehen, die Zuordnung der Tasten ändern, oder viele andere Funktionen nutzen.
<G-vec00496-002-s717><shift.ändern><en> Use the wheel to turn pages, reassign the buttons, or use many other features. Horizontal shift
<G-vec00496-002-s718><shift.ändern><de> In unserem Inneren haben wir alle Ressourcen, um unser Schicksal zu ändern.
<G-vec00496-002-s718><shift.ändern><en> Within us we have all the resources to make a shift in our destiny.
<G-vec00496-002-s719><shift.ändern><de> Wenn Sie die Größe der Grafik ändern möchten, markieren Sie die Form, positionieren den Mauszeiger über einem Punkt, klicken und ziehen den Ziehpunkt dann mit der Maus.
<G-vec00496-002-s719><shift.ändern><en> Select the object. Hold down SHIFT. Move the mouse pointer over one of the corner handles and then click and drag the mouse.
<G-vec00496-002-s720><shift.ändern><de> Doch in jüngster Zeit verweigerten Länder mit großen Produktionen die Zusammenarbeit mit diesem Kanalsystem und zwangen De Beers, seine Strategie zu ändern.
<G-vec00496-002-s720><shift.ändern><en> But recently, countries with large productions refused to cooperate with this channel system, forcing De Beers to shift strategy.
<G-vec00496-002-s721><shift.ändern><de> Der Preis kann sich deutlich und plötzlich ändern - und da der Bitcoin-Markt rund um die Uhr operiert, kann dies zu jeder Tageszeit passieren.
<G-vec00496-002-s721><shift.ändern><en> Its price can shift significantly and suddenly – and since the bitcoin market operates around the clock, this is liable to happen any time of day.
<G-vec00590-002-s532><change.ändern><de> Nur mit Zustimmung ändert sich so der Nutzungszweck dieser Daten.
<G-vec00590-002-s532><change.ändern><en> The purpose for which your data shall be used will only change upon provision of your consent.
<G-vec00590-002-s533><change.ändern><de> Wie bei jedem Index ändert sich auch die Zusammensetzung des Dow Jones ständig, um die Wirtschaftsrealität abzubilden – deswegen sind heute Microsoft und Intel als „Industrie“ gelistet, nicht mehr The American Cotton Oil Company und National Lead (aus dem Jahr 1896).
<G-vec00590-002-s533><change.ändern><en> As with any average, the components of the Dow Jones averages change to meet economic realities – which is why they currently list Microsoft and Intel as “industrial” instead of The American Cotton Oil Company and National Lead (from 1896).
<G-vec00590-002-s534><change.ändern><de> Der Preis der Futures-Kontrakte ändert sich während der Handelszeiten ständig und sie gelten als höchst attraktive Trading-Instrumente.
<G-vec00590-002-s534><change.ändern><en> The price of the Futures Contracts continuously change during market trading hours and are considered to be attractive trading instruments.
<G-vec00590-002-s535><change.ändern><de> Die Scharfstellung erfolgt dabei ausschließlich über eine Verlängerung des Auszugs, d. h. das gesamte Paket der Einzellinsen wird von der Filmebene wegbewegt, und der Abstand der Linsen zueinander ändert sich nicht.
<G-vec00590-002-s535><change.ändern><en> Focusing is purely by extension, i. e. the entire lens element package is moved forward. The spacing of the individual elements does not change.
<G-vec00590-002-s536><change.ändern><de> Dabei ändert sich die Kontostruktur innerhalb des Eurosystems: Liquidität wird zukünftig über ein zentrales Konto gesteuert.
<G-vec00590-002-s536><change.ändern><en> The account structure within the Eurosystem will change: liquidity will be controlled via a central account in the future.
<G-vec00590-002-s537><change.ändern><de> Auf jeder Seite ändert sich die Titelfarbe H1, H2 und H3 zu der Farbe, die Sie hier definieren.
<G-vec00590-002-s537><change.ändern><en> On every page the H1, H2 and H3 title color will change to the color you define here.
<G-vec00590-002-s538><change.ändern><de> Wenn Ihr Kunde beispielsweise das Dokument öffnet, das Sie ihm per E-Mail geschickt haben, ändert sich der Status unter dem Rechnungsbetrag von Verschickt zu Geöffnet.
<G-vec00590-002-s538><change.ändern><en> For example, when your customer opens the document you’ve emailed them, the status under the invoice total will change from Sent to Opened.
<G-vec00590-002-s539><change.ändern><de> Die Skulptur& rsquo; s Farbe und Form ändert sich entsprechend.
<G-vec00590-002-s539><change.ändern><en> The sculpture’s color and shape will change accordingly.
<G-vec00590-002-s540><change.ändern><de> Bei der Außenüberwachung ändert sich die Farbtemperatur im Laufe des Tages, sodass zum Aufrechterhalten der Farbtreue ein automatischer Weißabgleich erforderlich ist.
<G-vec00590-002-s540><change.ändern><en> In outdoor surveillance, the color temperature will change throughout the day, requiring automatic white balancing to keep color fidelity.
<G-vec00590-002-s541><change.ändern><de> Im Laufe ihres Lebens ändert sich der Stand der Wissenschaft und Technik, sowie diverser Anforderungen.
<G-vec00590-002-s541><change.ändern><en> During their lifetime, the state of technical and scientific knowledge and the nature of requirements will change.
<G-vec00590-002-s542><change.ändern><de> Unter voller Last ändert sich die Laufzeit nicht großartig, im Idle-Betrieb ermöglicht die neue Prozessorengeneration circa 1:40 Stunden längere Laufzeiten.
<G-vec00590-002-s542><change.ändern><en> The battery life does not change greatly under full load, but the new processor generation allows using the laptop about 1:40 hours longer while idle.
<G-vec00590-002-s543><change.ändern><de> Das ändert sich auch nicht, wenn zum Beispiel Kokosmilch in der Süß-Sauer Sauce verwendet wird.
<G-vec00590-002-s543><change.ändern><en> This does not change if, for example, coconut milk is used in the sweet and sour sauce.
<G-vec00590-002-s544><change.ändern><de> Der Bestellprozess selbst ändert sich für Sie nicht.
<G-vec00590-002-s544><change.ändern><en> The ordering process itself does not change and no system modifications are required.
<G-vec00590-002-s545><change.ändern><de> Wenn du deinen Accountnamen änderst, wird eine email an die email-Adresse, welche du beim Registrieren angegeben hast, geschickt, und es ändert sich dein Anmelde-Name.
<G-vec00590-002-s545><change.ändern><en> When your name is changed, an email will be sent to your registered email address, and your login name will change to the new name.
<G-vec00590-002-s546><change.ändern><de> In den letzten Jahren ist es als Zentrum für Sommer- und Zweitwohnungen wichtig geworden, aber nach und nach ändert sich dieses Verhalten und die Anzahl der Menschen, die sich entscheiden, zu bleiben und von der Ruhe motiviert zu leben lebt in der Gemeinde, seine Nähe zum Meer und seiner natürlichen Umgebung.
<G-vec00590-002-s546><change.ändern><en> In recent years, it has become important as a center for summer and second homes, but little by little there is a change in this behavior and the number of people who decide to stay and live motivated by the tranquility lives in the municipality, its proximity to the sea and its natural environment.
<G-vec00590-002-s547><change.ändern><de> Wenn dies geschieht, ändert sich der Status von Ausstehend zu Abgelaufen.
<G-vec00590-002-s547><change.ändern><en> If this happens, the status will change from Pending to Expired.
<G-vec00590-002-s548><change.ändern><de> Haben sie indes ein neues Amt, ändert sich ihre Rhetorik.
<G-vec00590-002-s548><change.ändern><en> However, when they change office, they also change their rhetoric.
<G-vec00590-002-s549><change.ändern><de> Das Symbol ändert sich in ein geöffnetes Vorhängeschloss.
<G-vec00590-002-s549><change.ändern><en> the symbol will change to an open padlock.
<G-vec00590-002-s550><change.ändern><de> Jedes Schuljahr ändert sich die Bücherliste der Schule (und auch wenn die Titel gleich bleiben kann die Ausgabe sich ändern).
<G-vec00590-002-s550><change.ändern><en> The school book lists change slightly from one year to another (and even if the titles remain the same, the edition can change).
