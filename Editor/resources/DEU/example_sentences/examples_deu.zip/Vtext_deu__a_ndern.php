<G-vec00407-001-s085><amend.ändern><de> Sie können die Ergebnisse bei Bedarf ändern.
<G-vec00407-001-s085><amend.ändern><en> You can amend the results if you like.
<G-vec00407-001-s086><amend.ändern><de> Sie haben das Recht, Ihre personenbezogenen Informationen abzurufen und bei Bedarf zu ändern.
<G-vec00407-001-s086><amend.ändern><en> You have the right to access and, where relevant, to amend your personal information.
<G-vec00407-001-s103><amend.ändern><de> Der Stab empfahl dem Board, die Textziffern 117-124 von IAS 1 dahingehend zu ändern, dass Unternehmen ihre wesentlichen und nicht ihre maßgeblichen Bilanzierungs- und Bewertungsmethoden anzugeben haben.
<G-vec00407-001-s103><amend.ändern><en> Staff recommended that the Board amend paragraphs 117–124 of IAS 1 to require entities to disclose their material accounting policies rather than their significant accounting policies.
<G-vec00407-001-s104><amend.ändern><de> Sofern der Kunde von Dritten wegen Verletzung von Urheber- und/oder gewerblichen Schutzrechten hinsichtlich von uns gelieferten und vertragsgemäß genutzten Gegenständen berechtigt in Anspruch genommen wird, werden wir wie folgt hierfür einstehen: Entweder werden wir nach unserer Wahl und auf unsere Kosten den betroffenen Gegenstand dahingehend ändern, dass ein Schutzrecht des Dritten nicht mehr verletzt wird oder einen nicht von dem Schutzrecht umfassten adäquaten Ersatzgegenstand liefern.
<G-vec00407-001-s104><amend.ändern><en> Insofar as Client is justifiably sued by third parties on account of copyrights and/or industrial protection rights with regard to the commodities supplied by us and used contractually, we shall take responsibility for this as follows: either we shall amend the object affected at our discretion and at our expense in such a way that a protective right of the third party is no longer breached or we shall supply an adequate replacement object not affected by the protective right.
<G-vec00407-001-s107><amend.ändern><de> Die H&M Gruppe behält sich das Recht vor ohne Vorankündigung diese Vorteile einseitig zu ändern oder zu widerrufen.
<G-vec00407-001-s107><amend.ändern><en> The H&M group reserves the right to amend or discontinue any of these benefits without notice.
<G-vec00407-001-s108><amend.ändern><de> *Die H&M Gruppe behält sich das Recht vor die genannten Vorteile ohne Vorankündigung einseitig zu ändern oder zu beenden.
<G-vec00407-001-s108><amend.ändern><en> *The H&M group reserves the right to amend or discontinue any of these benefits without notice.
<G-vec00407-001-s109><amend.ändern><de> behält sich das Recht vor in jedem Moment und ohne vorherige Ankündigung den Datenschutz einseitig zu ändern, um diesen an die derzeitigen Rechtsvorschriften anzupassen.
<G-vec00407-001-s109><amend.ändern><en> reserves the right to amend, at any time and without previous notice, its Personal Data Protection Policy in order to adjust it to the legislation in force at any particular time.
<G-vec00407-001-s142><amend.ändern><de> Somit hätten die Beschwerdeführer mit ihrem ersten, in der mündlichen Verhandlung vorgetragenen Argument ihr in der Beschwerdebegründung enthaltenes Vorbringen nicht wesentlich geändert.
<G-vec00407-001-s142><amend.ändern><en> Thus, by submitting the first line of argument at the oral proceedings the appellants did not amend their case, as set out in the grounds of appeal, in a substantial manner.
<G-vec00407-001-s143><amend.ändern><de> Ryanair ist nicht verantwortlich für die Passagiere, die ihre Reiseversicherungsdetails falsch geändert haben.
<G-vec00407-001-s143><amend.ändern><en> Ryanair is not responsible for any passengers who fail to amend their travel insurance policy details.
<G-vec00407-001-s144><amend.ändern><de> Für die Begründung der Europäischen Union sowie für Änderungen ihrer vertraglichen Grundlagen und vergleichbare Regelungen, durch die dieses Grundgesetz seinem Inhalt nach geändert oder ergänzt wird oder solche Änderungen oder Ergänzungen ermöglicht werden, gilt Artikel 79 Absatz 2 und 3.
<G-vec00407-001-s144><amend.ändern><en> The establishment of the European Union, as well as changes in its treaty foundations and comparable regulations that amend or supplement this Basic Law, or make such amendments or supplements possible, shall be subject to paragraphs (2) and (3) of Article 79.
<G-vec00407-001-s199><amend.ändern><de> Wir behalten uns vor, die vorliegenden Nutzungsbedingungen von Zeit zu Zeit zu ändern.
<G-vec00407-001-s199><amend.ändern><en> We may amend these Terms of Use from time to time.
<G-vec00407-001-s200><amend.ändern><de> Schlug ich, vor die angemessenen Richtlinien für angemessene Arbeitsbedingungen zu ändern verfahre nach der Verringerung des Standardworkweek auf 32 Stunden, die Halbzeitüberstundenzulage im Allgemeinen weg besteuernd, anstatt, sie zu zahlen zur Überstundenarbeitskraft, unter Verwendung dieses Geldes, um irgendwelche verlorenen Löhne und das Festziehen der Befreiung für die Verwaltungs- und Berufsangestellten zu entschädigen.
<G-vec00407-001-s200><amend.ändern><en> Basically, I proposed to amend the Fair Labor Standards Act by reducing the standard workweek to 32 hours, taxing away the half-time overtime premium instead of paying it to the overtime worker, using this money to compensate for any lost wages, and tightening the exemption for managerial and professional employees.
<G-vec00407-001-s204><amend.ändern><de> Doch nun ändere ich das in: Frag nicht danach, was die Welt für dich tun kann, sondern was du für die Welt tun kannst.
<G-vec00407-001-s204><amend.ändern><en> But now I amend those: Ask not what your world can do for you. Ask what you can do for your world.
<G-vec00407-001-s205><amend.ändern><de> Nachprüfen: Frage andere Personen deinen Text zu lesen und kommentieren, ändere es dann ab.
<G-vec00407-001-s205><amend.ändern><en> Revising: ask other people to read and comment on your text, then amend it.
<G-vec00407-001-s206><amend.ändern><de> So warum müssen Sie den Boden ändern und wie Sie tun ihn?Die Antwort zu beiden Fragen hängt von ab, was Sie beabsichtigen, zu pflanzen und...
<G-vec00407-001-s206><amend.ändern><en> So why do you need to amend the soil and how do you do it?The answer to both of these questions depends on what you intend to plant and the soil in your garden.
<G-vec00407-001-s207><amend.ändern><de> Caterpillar Financial behält sich das Recht vor, diesen Datenschutzhinweis zu ändern.
<G-vec00407-001-s207><amend.ändern><en> Caterpillar Financial reserves the right to amend this privacy notice at any time.
<G-vec00407-001-s208><amend.ändern><de> Videoslots behält sich das Recht vor, die Weekend Madness Battle jederzeit ohne vorherige Ankündigung zu stornieren oder zu ändern.
<G-vec00407-001-s208><amend.ändern><en> Videoslots reserves the right to cancel or amend this Battle Weekend at any given time without prior notice.
<G-vec00407-001-s209><amend.ändern><de> 1.2 Wir können die AGB jederzeit nach eigenem Ermessen ergänzen oder ändern.
<G-vec00407-001-s209><amend.ändern><en> 1.2 We shall be entitled to supplement or amend the GTC at any time at our own discretion.
<G-vec00407-001-s210><amend.ändern><de> Ist ein Mitarbeitender nach einem Unfall arbeitsunfähig, dürfen Sie ihm während einer gesetzlich geregelten Zeitspanne weder kündigen noch den Vertrag ändern.
<G-vec00407-001-s210><amend.ändern><en> For employees who are incapable of working following an accident, you may not terminate their position or amend their employment contract for a period of time specified by law.
<G-vec00407-001-s211><amend.ändern><de> Die STAHL CraneSystems GmbH behält sich vor, die Daten­schutz­erklärung jederzeit mit Wirkung für die Zukunft zu ändern.
<G-vec00407-001-s211><amend.ändern><en> STAHL CraneSystems GmbH reserves the right to amend the privacy statement at any time with future effect.
<G-vec00407-001-s212><amend.ändern><de> 3 Beabsichtigt die Beschwerdeinstanz, die angefochtene Verfügung zuungunsten einer Partei zu ändern, so bringt sie der Partei diese Absicht zur Kenntnis und räumt ihr Gelegenheit zur Gegenäusserung ein.
<G-vec00407-001-s212><amend.ändern><en> 3 Â If the appellate authority intends to amend the contested ruling to the prejudice of a party, it shall notify the party of this intention and allow him the opportunity to respond.
<G-vec00407-001-s213><amend.ändern><de> Einzelpersonen können verlangen, auf Informationen, die wir über sie haben, zuzugreifen, sie zu korrigieren, zu ändern oder zu löschen, indem sie auf unserer Kontaktseite Kontakt aufnehmen.
<G-vec00407-001-s213><amend.ändern><en> Individuals may request to access, correct, amend or delete information we hold about them by contacting on our contact page.
<G-vec00407-001-s214><amend.ändern><de> Wir behalten uns das Recht vor, die Datenschutzrichtlinien zu ändern, zu ergänzen oder Teile davon jederzeit zu entfernen.
<G-vec00407-001-s214><amend.ändern><en> We reserve the right to amend, augment or delete parts of this Privacy Policy at any time. Any changes will be displayed on the website
<G-vec00407-001-s215><amend.ändern><de> MATESO behält sich vor, die allgemeinen Bedingungen jederzeit ändern zu können.
<G-vec00407-001-s215><amend.ändern><en> MATESO reserves the right to amend its general terms and conditions at any time.
<G-vec00407-001-s216><amend.ändern><de> Wir können diese Nutzungsbedingungen jederzeit ändern, indem wir Sie per E-Mail über die neuen Bedingungen benachrichtigen und/oder die geänderten Nutzungsbedingungen auf einer unserer Websites veröffentlichen.
<G-vec00407-001-s216><amend.ändern><en> We may amend these Terms and Conditions at any time either by emailing You notification of the new terms and/or by publishing the modified Terms and Conditions on any of the Sites for your information and acceptance.
<G-vec00407-001-s217><amend.ändern><de> Die Europäische Kommission hat Belgien offiziell aufgefordert, seine Vorschriften bezüglich der jährlichen Steuer für ausländische Organismen für gemeinsame Anlagen (OGA) zu ändern.
<G-vec00407-001-s217><amend.ändern><en> The European Commission has officially asked Belgium to amend the rules which it applies for the annual taxation of foreign collective investment undertakings (CIUs).
<G-vec00407-001-s218><amend.ändern><de> Star's Edge International ist bemüht, angemessene Schritte zu unternehmen, um dir zu ermöglichen, die Nutzung deiner persönlichen Daten zu korrigieren, zu ändern, zu löschen oder zu begrenzen.
<G-vec00407-001-s218><amend.ändern><en> Star's Edge International aims to take reasonable steps to allow you to correct, amend, delete, or limit the use of your Personal Data.
<G-vec00407-001-s219><amend.ändern><de> Es ist nicht ratsam, ein Papierticket an einer Ticketverkaufsstelle zu kaufen, da Sie einen höheren Preis für Papiertickets bezahlen, die außerdem schwierig zu stornieren oder zu ändern sind.
<G-vec00407-001-s219><amend.ändern><en> It is not recommended to buy a paper ticket via any ticket selling agency as you will pay a premium price for paper tickets, which are difficult to cancel or amend.
<G-vec00407-001-s220><amend.ändern><de> Unbeschadet Ihrer Rechte gemäß einschlägiger Gesetzgebung, behält ONTEX sich das Recht vor, diese Datenschutzerklärung von Zeit zu Zeit zu ändern, um technologischen Fortschritten, behördlichen und gesetzlichen Änderungen und guten Geschäftspraktiken Rechnung zu tragen.
<G-vec00407-001-s220><amend.ändern><en> Without prejudice to your rights under applicable law, ONTEX reserves the right to amend this Privacy Statement from time to time to reflect technological advancements, legal and regulatory changes and good business practices.
<G-vec00407-001-s221><amend.ändern><de> Sie können Ihre persönlichen Daten jederzeit durch Anmeldung in Ihrem Konto online sehen und ändern.
<G-vec00407-001-s221><amend.ändern><en> You can view and amend your personal information at any time by logging in to your account online.
<G-vec00407-001-s222><amend.ändern><de> Wir behalten uns das Recht vor, diese Erklärung jederzeit zu ändern.
<G-vec00407-001-s222><amend.ändern><en> We reserve the right to amend this statement at any time.
<G-vec00407-001-s223><amend.ändern><de> Wir behalten uns vor, diese Datenschutzerklärung gemäß sich ändernder gesetzlicher oder behördlicher Bestimmungen, aufgrund der Weiterentwicklung unseres Internetauftritts oder aufgrund unserer Bemühungen, diese Erklärung fortlaufend zu verbessern, zu ändern.
<G-vec00407-001-s223><amend.ändern><en> We reserve the right to amend this Privacy Policy to reflect changing statutory or regulatory requirements, to take into account changes to our website or in the context of our ongoing efforts to constantly improve this Privacy Policy.
<G-vec00407-001-s224><amend.ändern><de> Wir fordern die griechische Regierung auf, ihre Versprechen zu erfüllen, die entsprechenden Gesetze unverzüglich zu ändern und allen Kriegsdienstverweigerern, die dies wünschen, die Ableistung eines alternativen zivilen Dienstes zu ermöglichen.
<G-vec00407-001-s224><amend.ändern><en> We urge the Greek government to fulfill its promises, to immediately amend the relevant legislation and allow all conscientious objectors who wish so, to perform the alternative civilian service.
<G-vec00407-001-s229><amend.ändern><de> Ändert eure Wege, und tragt zur Wiedergutmachung eurer Sünden bei, durch Gebet, Buße und Wohltätigkeit, so dass die Flüche von euren Sünden nicht auf eure Kinder und auf die folgenden Generationen kommen mögen; andernfalls werden eure Kinder und ihre Kinder euch verantwortlich machen für ihr Unglück und ihre Leiden.
<G-vec00407-001-s229><amend.ändern><en> Amend your ways and atone your sins by prayer, penance and charity so that the curses of your sins may not fall on your children and the following generations; otherwise your children and their children will hold you responsible for their misfortune and sufferings.
<G-vec00407-001-s230><amend.ändern><de> Die bundesstaatlichen Behörden haben Crowflight darauf hingewiesen, dass das Empfehlungsschreiben der bundesstaatlichen Behörden an den Governor in Council (Kabinett), in dem empfohlen wird, dass das Kabinett das Schedule 2 der Metal Mining Effluent Regulations ändert und Bucko Lake zur Tailings Impoundment Area erklärt, Anfang Januar 2008 abgeschickt wird, nachdem die öffentliche Überprüfung abgeschlossen ist, Kommentare über die Überprüfung abgegeben wurden und keine weiteren Überprüfungen erforderlich sind.
<G-vec00407-001-s230><amend.ändern><en> Federal authorities have indicated to Crowflight that upon completion of the public review, inclusion of comments from the review, and assuming that no revisions are required, then the letter of recommendation from federal authorities to the Governor in Council (Cabinet) recommending that Cabinet amend Schedule 2 of the Metal Mining Effluent Regulations to add Bucko Lake as a Tailings Impoundment Area will be sent by early January 2008.
<G-vec00407-001-s231><amend.ändern><de> Nach dem Tag ist die aufrechte Platte im Allgemeinen, zwischen Himmel installiert und Gesetzgebung, Gesetzgebungsbündiges mit den Boden und die Blockierung alles Klinkenhakens ändert.
<G-vec00407-001-s231><amend.ändern><en> After the day, the upright plate is generally installed, between heaven and amend legislation, legislation flush with the floor and locking all latch hook each other.
<G-vec00407-001-s232><amend.ändern><de> Sofern gesetzlich vorgeschrieben, gewährt EFI Einzelpersonen Zugriff auf ihre Personendaten und/oder ändert, löscht, korrigiert ihre Personendaten oder ermöglicht den Zugriff auf sie, wenn sie unzutreffend sind oder gesetzeswidrig verarbeitet werden.
<G-vec00407-001-s232><amend.ändern><en> Where required by law, EFI will grant individuals access to their Personal Information and/or amend, delete, correct or provide access their Personal Information if it is inaccurate or being processed in violation of law.
<G-vec00407-001-s233><amend.ändern><de> (14) Diese Richtlinie ändert die Verordnung über die Zusammenarbeit im Verbraucherschutz: In den Anhang der genannten Verordnung wird ein Verweis auf diese Richtlinie eingefügt, um eine abgestimmte Rechtsdurchsetzung durch die Verbraucherschutzbehörden im Geltungsbereich dieser Richtlinie zu ermöglichen.
<G-vec00407-001-s233><amend.ändern><en> (14) This Directive will amend the Regulation on consumer protection cooperation to add a reference of this Directive in the Annex of that Regulation enabling coordinated enforcement actions by the Consumer Protection authorities in the field covered by this Directive.
<G-vec00254-002-s211><manipulate.ändern><de> Es sollte vermerkt werden, daß der 2352-Byte-Sektor die kleinste Einheit ist, die ein CD-ROM-Laufwerk Software erlauben wird, zu ändern.
<G-vec00254-002-s211><manipulate.ändern><en> It should be pointed out that the 2352-byte sector is the smallest unit most CD-ROM drives will allow software to manipulate.
<G-vec00254-002-s212><manipulate.ändern><de> Du kannst das Bild vergrößern und seine Position innerhalb des Rahmens ändern.
<G-vec00254-002-s212><manipulate.ändern><en> You have the option to magnify the image and manipulate its position within the square.
<G-vec00254-002-s213><manipulate.ändern><de> JAWS aktiviert den Formularmodus, wenn es glaubt, dass Sie Text eingeben, Text überprüfen oder ein Steuerelement ändern müssen.
<G-vec00254-002-s213><manipulate.ändern><en> JAWS activates Forms Mode when it believes that you'll need to enter text, review text, or manipulate a control.
<G-vec00254-002-s214><manipulate.ändern><de> Wenn Sie Animationen in Adobe Edge Animate erstellen, ziehen Sie Elemente auf die Bühne und ändern Sie deren Bewegungen mittels einer Zeitleiste.
<G-vec00254-002-s214><manipulate.ändern><en> When you construct animations in Adobe Edge Animate, you drag elements onto the stage and manipulate their movements using a timeline.
<G-vec00254-002-s215><manipulate.ändern><de> Mit dieser Funktion können Sie das Erscheinungsbild und Verhalten des Objekts direkt im Eigenschafteninspektor schnell und einfach ändern.
<G-vec00254-002-s215><manipulate.ändern><en> This feature gives you the freedom to manipulate object behavior and appearance quickly and easily directly from the Property Inspector.
<G-vec00301-002-s293><rectify.ändern><de> Ein Umstand, den das Institut für Softwaretechnologie der TU Graz gemeinsam mit Partnerinstitutionen aus Österreich und Ungarn ändern will.
<G-vec00301-002-s293><rectify.ändern><en> This is something that the Institute of Software Technology at TU Graz together with partner institutions in Austria and Hungary wants to rectify.
<G-vec00360-002-s295><evolve.ändern><de> Stellen Sie sicher, dass Sie Drucker hinzufügen oder ein Upgrade auf eine höhere Edition durchführen können, wenn sich Ihre Geschäftsanforderungen ändern.
<G-vec00360-002-s295><evolve.ändern><en> Ensure you can add printers or upgrade to a higher edition as your business needs evolve.
<G-vec00360-002-s296><evolve.ändern><de> Wir bei Cisco wissen, dass sich die Bedürfnisse des Marktes schnell ändern, wenn Technologien weiterentwickelt werden und neue entstehen.
<G-vec00360-002-s296><evolve.ändern><en> Yes Cisco understands that the needs of the market evolve rapidly as technologies evolve and new technologies emerge.
<G-vec00360-002-s297><evolve.ändern><de> Sollten sich die Nutzerbedürfnisse ändern, können die Paneele für andere Räume neu konfiguriert oder bestehende Arrangements mit neuen Paneelfarben aufgefrischt werden.
<G-vec00360-002-s297><evolve.ändern><en> As needs evolve, panels can be reconfigured for another space or existing compositions can be refreshed with new panel colors.
<G-vec00360-002-s298><evolve.ändern><de> Nutzen Sie hochwertige Lösungen und erweitern Sie diese, wenn sich Ihre Anforderungen ändern.
<G-vec00360-002-s298><evolve.ändern><en> Deploy quality solutions and easily expand them as your needs evolve.
<G-vec00360-002-s299><evolve.ändern><de> Die Produkteigenschaften der auf der Webseite präsentierten Produkte können sich ändern.
<G-vec00360-002-s299><evolve.ändern><en> The characteristics of the products presented on the site can evolve.
<G-vec00360-002-s300><evolve.ändern><de> Unsere Tätigkeiten können sich im Laufe der Zeit ändern und wir können diese Datenschutzerklärung entsprechend aktualisieren.
<G-vec00360-002-s300><evolve.ändern><en> Our activities may evolve over time and we may update this privacy policy accordingly.
<G-vec00360-002-s301><evolve.ändern><de> Diese Studie, die in diesem Jahr in die fünfte Runde geht, untersucht die Erwartungshaltungen von Chief Communications Officers (kurz: CCOs) in Nordamerika, Europa, Lateinamerika und im asiatisch-pazifischen Raum, wie sich ihre Aufgaben und Arbeitsbereiche durch die immer weitere digitalisierte und von Medien zunehmend fragmentierte Welt ändern.
<G-vec00360-002-s301><evolve.ändern><en> This survey, now in its fifth year, explores how chief communications officers (CCOs) from North America, Europe, Asia Pacific and Latin America expect their responsibilities to evolve over time in an increasingly digitalised and media-fragmented world.
<G-vec00360-002-s302><evolve.ändern><de> „Da sich die Geschäftsanforderungen von Nationwide ändern, passen wir unsere Marketingressourcen an, um sicherzustellen, dass wir uns an diesen neuen Geschäftsprioritäten ausrichten.
<G-vec00360-002-s302><evolve.ändern><en> “As Nationwide’s business needs evolve, we are adjusting our marketing resources to ensure that we are aligning to those new business priorities.
<G-vec00407-002-s132><amend.ändern><de> Sofern zwischen Ihnen und uns ein Vertragsverhältnis begründet, inhaltlich ausgestaltet oder geändert werden soll, erheben und verwenden wir personenbezogene Daten von Ihnen, soweit dies zu diesen Zwecken erforderlich ist.
<G-vec00407-002-s132><amend.ändern><en> Personal details Where we are to enter into, set up or amend a contractual relationship with you, we collect and use your personal data where required for these purposes.
<G-vec00407-002-s133><amend.ändern><de> Wir empfehlen Ihnen, diese Datenschutzhinweise von Zeit zu Zeit zu überprüfen, so dass Sie wissen, ob die Privatsphäre und Datenschutz geändert oder aktualisiert wurde.
<G-vec00407-002-s133><amend.ändern><en> From time to time we may update or amend this policy, we would like to encourage you to review this Privacy Policy from time to time so you are aware of any updates.
<G-vec00407-002-s134><amend.ändern><de> Weiterhin kann der Fahrplan jeglicher Tour geändert und/oder stornieren werden.
<G-vec00407-002-s134><amend.ändern><en> Furthermore, they reserve the right to amend and/or cancel the schedule for any tour
<G-vec00407-002-s135><amend.ändern><de> RUNTIME Designer: Erzeugte RUNTIME Definitionen konnten zwar beim Kunden mit der Freeware Version geändert und ausgeführt werden, das anschließende Speichern der Definition wurde aber dann mit der Fehlermeldung „Die Freeware Version unterstützt das Speichern von Definitionen nicht!“ abgebrochen.
<G-vec00407-002-s135><amend.ändern><en> RUNTIME Designer: Users were able to amend and run RUNTIME Definitions with the Freeware Version, but it terminated when finally saving the Definition with the error message “The Freeware Version does not support the saving of Definitions.”
<G-vec00407-002-s136><amend.ändern><de> Diese Teilnahmebedingungen können jederzeit von der ElringKlinger AG ohne gesonderte Benachrichtigung geändert werden.
<G-vec00407-002-s136><amend.ändern><en> ElringKlinger AG is entitled to amend the conditions of entry at any time without specific notification.
<G-vec00407-002-s137><amend.ändern><de> Erwägung 3 (3) Die Richtlinie 2011/92/EU muss geändert werden, um die Qualität des UVP-Verfahrens zu erhöhen, die einzelnen Verfahrensschritte zu rationalisieren und die Kohärenz und die Synergien mit anderen EU-Rechtsvorschriften und –Politiken sowie mit den Strategien und Politiken, die die Mitgliedstaaten in bestimmten in die nationale Zuständigkeit fallenden Bereichen erarbeitet haben, zu verstärken.
<G-vec00407-002-s137><amend.ändern><en> (3) It is necessary to amend Directive 2011/92/EU in order to strengthen the quality of the environmental impact assessment procedure, align that procedure with the principles of smart regulation and enhance coherence and synergies with other Union legislation and policies, as well as strategies and policies developed by Member States in areas of national competence.
<G-vec00407-002-s138><amend.ändern><de> Diese Bedingungen können von Zeit zu Zeit geändert werden.
<G-vec00407-002-s138><amend.ändern><en> We may amend these Terms from time to time.
<G-vec00407-002-s139><amend.ändern><de> Das Blasphemiegesetz muss dringend geändert werden, um Missbrauch zu verhindern.
<G-vec00407-002-s139><amend.ändern><en> It is urgent to amend the blasphemy law to prevent abuses.
<G-vec00407-002-s141><amend.ändern><de> (3) Die Anlage der Richtlinie 96/49/EG muss daher geändert werden.
<G-vec00407-002-s141><amend.ändern><en> (3) It is therefore necessary to amend the Annex to Directive 96/49/EC.
<G-vec00407-002-s142><amend.ändern><de> Beachten Sie, dass die Elemente, die geändert werden können, von der jeweiligen Route abhängen.
<G-vec00407-002-s142><amend.ändern><en> Please note that the elements that you can amend might vary from route to route.
<G-vec00407-002-s143><amend.ändern><de> (7) Der Kommission wird die Befugnis übertragen, gemäß Artikel 87 delegierte Rechtsakte zu erlassen, mit denen Anhang I geändert wird, um die Liste der öffentlichen Auftraggeber entsprechend den von den Mitgliedstaaten übermittelten Mitteilungen zu aktualisieren, soweit die betreffenden Änderungen erforderlich sind, um öffentliche Auftraggeber korrekt zu ermitteln.
<G-vec00407-002-s143><amend.ändern><en> 7. The Commission shall be empowered to adopt delegated acts in accordance with Article 87 to amend Annex I, in order to update the list of contracting authorities following notifications from Member States, where such amendments prove necessary to correctly identify contracting authorities.
<G-vec00407-002-s144><amend.ändern><de> 3.2 Preise und Gebühren für Angebote von Apps und In-App Käufen können durch Mack Media jederzeit mit Wirkung für künftige Vertragsschlüsse geändert werden.
<G-vec00407-002-s144><amend.ändern><en> 3.2 Mack Media may amend prices and fees for offers of apps and in-app purchases at any time with effect for contracts concluded in the future.
<G-vec00430-002-s513><change.ändern><de> Wenn Sie möchten, dass Paylobby Ihre personenbezogenen Daten ändert oder Ihre Daten nicht mehr nutzt, können Sie Paylobby unter info@paylobby.com kontaktieren.
<G-vec00430-002-s513><change.ändern><en> If you would like Paylobby to change your personal data or no longer use your data, you can contact Paylobby at info@paylobby.com.
<G-vec00430-002-s514><change.ändern><de> Durch einen formfreien Preis wird der Preis nur angepasst (auch wenn sich der Umrechnungskurs ändert), wenn Sie ein Update mit einem neuen Preis übermitteln.Grundpreise für mehrere Märkte zu überschreiben, erstellen Sie eine Marktgruppe.To override the base price for multiple markets, you’ll create a market group.
<G-vec00430-002-s514><change.ändern><en> This price will be used only for customers on Windows 10 (including Xbox) in the selected market. If you enter a free-form price, that price will not be adjusted (even if conversion rates change) unless you submit an update with a new price.
<G-vec00430-002-s515><change.ändern><de> Sie können leicht später addiert werden, wenn Bedarf ändert.
<G-vec00430-002-s515><change.ändern><en> They can be easily added later if needs change.
<G-vec00430-002-s516><change.ändern><de> Auf Bestellung innerhalb von 4 Arbeitstagen Schutzfolie - 100% Garantie gegen Kratzer, lebenslange Garantie, extreme Widerstandsfähigkeit und volle Transparenz, die Folie ändert nicht die Farben des Displays, das Display...
<G-vec00430-002-s516><change.ändern><en> Ordered on request within 4 days Screen protector - 100% protection against scratches, lifetime warranty, extreme durability and full transparency, does not change the colours of the display, makes your...
<G-vec00430-002-s517><change.ändern><de> Dies ist ein absolut sicherer Vorgang, denn Start Menu 7 ändert keine Systemeinstellungen.
<G-vec00430-002-s517><change.ändern><en> It is safe because Start Menu 7 does not change your system!
<G-vec00430-002-s518><change.ändern><de> Wenn diese Option aktiviert ist, werden Änderungen in ACL auch dann erkannt, wenn sich der Dateikörper nicht ändert.
<G-vec00430-002-s518><change.ändern><en> If checked, changes in ACL are detected even when the file body does not change.
<G-vec00430-002-s519><change.ändern><de> FIXED (FEST): Wenn diese Einstellung gewählt wird, ändert sich der Ton des Fernsehers über die AUDIO OUT-Buchsen nicht, wenn die Lautstärkentasten der Fernbedienung des Fernsehers gedrückt werden.
<G-vec00430-002-s519><change.ändern><en> FIXED: When this setting is selected, the television audio through the AUDIO OUT jacks does not change How do I watch subscribed services using a smart card module?Table of contents: 1.
<G-vec00430-002-s520><change.ändern><de> An all dem ändert auch Tomboy nichts.
<G-vec00430-002-s520><change.ändern><en> Not even Tomboy could change anything about that.
<G-vec00430-002-s521><change.ändern><de> Manchmal ändert ein Paket seinen Bereich.
<G-vec00430-002-s521><change.ändern><en> Sometimes a package will change its section.
<G-vec00430-002-s522><change.ändern><de> Überprüfe, ob jemand seine Stimme ändert, oder ob sich plötzlich die Körpersprache ändert.
<G-vec00430-002-s522><change.ändern><en> Check to see if someone's voice changes, or if they suddenly change their body language.
<G-vec00430-002-s523><change.ändern><de> Bei einer öffentlichen Seite ändert die Berechtigung Seite durchsuchen nichts an der Zugriffssicherheit dieser Seite, da sie bereits für jeden zugänglich ist, der Zugriff auf die Domain hat.
<G-vec00430-002-s523><change.ändern><en> For a public page, the Browse page permission doesn't change anything to the access security of that page because it is already accessible by anybody who has access to the domain.
<G-vec00430-002-s524><change.ändern><de> Was immer an Versperrung er manifestiert, er ändert die Natur des Lebens nicht.
<G-vec00430-002-s524><change.ändern><en> Whatever obstruction he manifests, he does not change the nature of life.
<G-vec00430-002-s525><change.ändern><de> Es ändert Ihre IP-Adresse nicht und verschlüsselt Ihre Verbindung nicht wie VPN, bietet jedoch eine höhere Internetgeschwindigkeit beim Anschauen von Videoinhalten.
<G-vec00430-002-s525><change.ändern><en> It doesn’t change your IP and doesn’t encrypt your connection like VPN but offers better speed when watching video content.
<G-vec00430-002-s526><change.ändern><de> Beschreibung Aktionssteuerungen lösen Aktionen aus, wenn sich der Status von Rocrail-Objekten ändert.
<G-vec00430-002-s526><change.ändern><en> Description Action controls trigger actions when the states of Rocrail objects change.
<G-vec00430-002-s527><change.ändern><de> Falls nach einer vorbestimmten Anzahl von CK4-Taktzyklen ein Rahmensignal nicht detektiert wird, dann bewirkt der Zähler 850, dass die MUX-Steuerlogik 848 die Phase des CK4 unter Verwendung des MUX 828 ändert (8).
<G-vec00430-002-s527><change.ändern><en> If after a predetermined number of CK4 clock cycles a framing signal is not detected. then counter 850 will cause mux control logic 848 to change the phase of CK4 using mux 828 (FIG.
<G-vec00430-002-s528><change.ändern><de> Das elektromagnetische Feld ändert seine möglichen Wirkungen mit höher werdender Frequenz.
<G-vec00430-002-s528><change.ändern><en> The possible effects of an electromagnetic field change with increasing frequency.
<G-vec00430-002-s529><change.ändern><de> Die Online-Glücksspielindustrie hat darauf gewartet, dass die Technologie das Zahlungsverfahren in den Online-Casinos ändert.
<G-vec00430-002-s529><change.ändern><en> The online gambling industry has been waiting for the technology to change the payment procedure at online casinos.
<G-vec00430-002-s530><change.ändern><de> Er ändert ebenfalls die Stimme der Musik, fügt neuen Dateien Effekte für Hören oder Aufnehmen zu.
<G-vec00430-002-s530><change.ändern><en> You can also change music by adding effects for listening or recording to a new file.
<G-vec00430-002-s531><change.ändern><de> Battle Bears Royale, ein teambasierter Third-Person-Shooter Actionspiel für Android, ändert wie Sie über Teddybären denken.
<G-vec00430-002-s531><change.ändern><en> Battle Bears Royale, a team based third-person shooter action game for Android, will change the way you think about teddy bears.
<G-vec00496-002-s711><shift.ändern><de> Eine neue Regierung, die imstande ist, die Richtung der Politik radikal zu ändern, kann der Grund sein, in einen Markt einzutreten oder ihn zu verlassen.
<G-vec00496-002-s711><shift.ändern><en> A new administration that has the ability to radically shift policy direction can be reason to enter or exit a market.
<G-vec00496-002-s712><shift.ändern><de> Da mehr Suchanfragen durchgeführt, aber weniger Ergebnisse angezeigt werden, müssen viele Webseiten ihre Strategie ändern.
<G-vec00496-002-s712><shift.ändern><en> With more searches being performed and fewer results being shown, a lot of websites are going to need to shift strategies.
<G-vec00496-002-s713><shift.ändern><de> Ein Kunde möchte vielleicht den Kursschwerpunkt oder die Lernziele mitten im Projekt noch ändern.
<G-vec00496-002-s713><shift.ändern><en> The client might shift the scope of the elearning project or the learning objectives halfway through the project.
<G-vec00496-002-s714><shift.ändern><de> Wenn sich ökonomische Rahmenbedingungen ändern, kann eine Anlagenverlegung die wirtschaftlich attraktivste Lösung für eine solche Investition sein.
<G-vec00496-002-s714><shift.ändern><en> But when the economic goalposts shift, relocating the entire plant may be the most cost-efficient option to safeguard the investment.
<G-vec00496-002-s715><shift.ändern><de> Wir müssen nur unser Verhalten ändern, insbesondere unseren Konsum, wir müssen den Anteil an Kunststoffen, die wir nutzen, minimieren.
<G-vec00496-002-s715><shift.ändern><en> All we need to do is shift our behavior, particularly our consumption, minimize the amount of plastic that we use.
<G-vec00496-002-s716><shift.ändern><de> Die Effekte Tempo ändern, Rate ändern, Tonhöhe ändern und Umkehren sowie Stimme verwandeln werden auf alle Kanäle angewandt, unabhängig davon, ob Sie einen oder mehrere Kanäle deaktiviert oder nicht deaktiviert haben.
<G-vec00496-002-s716><shift.ändern><en> The Tempo Change, Rate Change, Pitch Shift and Reverse effects, as well as the Voice Morpher effect, will be applied to all channels whether you disabled them or not.
<G-vec00496-002-s717><shift.ändern><de> Mit Hilfe des Rad können Sie Seiten umdrehen, die Zuordnung der Tasten ändern, oder viele andere Funktionen nutzen.
<G-vec00496-002-s717><shift.ändern><en> Use the wheel to turn pages, reassign the buttons, or use many other features. Horizontal shift
<G-vec00496-002-s718><shift.ändern><de> In unserem Inneren haben wir alle Ressourcen, um unser Schicksal zu ändern.
<G-vec00496-002-s718><shift.ändern><en> Within us we have all the resources to make a shift in our destiny.
<G-vec00496-002-s719><shift.ändern><de> Wenn Sie die Größe der Grafik ändern möchten, markieren Sie die Form, positionieren den Mauszeiger über einem Punkt, klicken und ziehen den Ziehpunkt dann mit der Maus.
<G-vec00496-002-s719><shift.ändern><en> Select the object. Hold down SHIFT. Move the mouse pointer over one of the corner handles and then click and drag the mouse.
<G-vec00496-002-s720><shift.ändern><de> Doch in jüngster Zeit verweigerten Länder mit großen Produktionen die Zusammenarbeit mit diesem Kanalsystem und zwangen De Beers, seine Strategie zu ändern.
<G-vec00496-002-s720><shift.ändern><en> But recently, countries with large productions refused to cooperate with this channel system, forcing De Beers to shift strategy.
<G-vec00496-002-s721><shift.ändern><de> Der Preis kann sich deutlich und plötzlich ändern - und da der Bitcoin-Markt rund um die Uhr operiert, kann dies zu jeder Tageszeit passieren.
<G-vec00496-002-s721><shift.ändern><en> Its price can shift significantly and suddenly – and since the bitcoin market operates around the clock, this is liable to happen any time of day.
<G-vec00590-002-s532><change.ändern><de> Nur mit Zustimmung ändert sich so der Nutzungszweck dieser Daten.
<G-vec00590-002-s532><change.ändern><en> The purpose for which your data shall be used will only change upon provision of your consent.
<G-vec00590-002-s533><change.ändern><de> Wie bei jedem Index ändert sich auch die Zusammensetzung des Dow Jones ständig, um die Wirtschaftsrealität abzubilden – deswegen sind heute Microsoft und Intel als „Industrie“ gelistet, nicht mehr The American Cotton Oil Company und National Lead (aus dem Jahr 1896).
<G-vec00590-002-s533><change.ändern><en> As with any average, the components of the Dow Jones averages change to meet economic realities – which is why they currently list Microsoft and Intel as “industrial” instead of The American Cotton Oil Company and National Lead (from 1896).
<G-vec00590-002-s534><change.ändern><de> Der Preis der Futures-Kontrakte ändert sich während der Handelszeiten ständig und sie gelten als höchst attraktive Trading-Instrumente.
<G-vec00590-002-s534><change.ändern><en> The price of the Futures Contracts continuously change during market trading hours and are considered to be attractive trading instruments.
<G-vec00590-002-s535><change.ändern><de> Die Scharfstellung erfolgt dabei ausschließlich über eine Verlängerung des Auszugs, d. h. das gesamte Paket der Einzellinsen wird von der Filmebene wegbewegt, und der Abstand der Linsen zueinander ändert sich nicht.
<G-vec00590-002-s535><change.ändern><en> Focusing is purely by extension, i. e. the entire lens element package is moved forward. The spacing of the individual elements does not change.
<G-vec00590-002-s536><change.ändern><de> Dabei ändert sich die Kontostruktur innerhalb des Eurosystems: Liquidität wird zukünftig über ein zentrales Konto gesteuert.
<G-vec00590-002-s536><change.ändern><en> The account structure within the Eurosystem will change: liquidity will be controlled via a central account in the future.
<G-vec00590-002-s537><change.ändern><de> Auf jeder Seite ändert sich die Titelfarbe H1, H2 und H3 zu der Farbe, die Sie hier definieren.
<G-vec00590-002-s537><change.ändern><en> On every page the H1, H2 and H3 title color will change to the color you define here.
<G-vec00590-002-s538><change.ändern><de> Wenn Ihr Kunde beispielsweise das Dokument öffnet, das Sie ihm per E-Mail geschickt haben, ändert sich der Status unter dem Rechnungsbetrag von Verschickt zu Geöffnet.
<G-vec00590-002-s538><change.ändern><en> For example, when your customer opens the document you’ve emailed them, the status under the invoice total will change from Sent to Opened.
<G-vec00590-002-s539><change.ändern><de> Die Skulptur& rsquo; s Farbe und Form ändert sich entsprechend.
<G-vec00590-002-s539><change.ändern><en> The sculpture’s color and shape will change accordingly.
<G-vec00590-002-s540><change.ändern><de> Bei der Außenüberwachung ändert sich die Farbtemperatur im Laufe des Tages, sodass zum Aufrechterhalten der Farbtreue ein automatischer Weißabgleich erforderlich ist.
<G-vec00590-002-s540><change.ändern><en> In outdoor surveillance, the color temperature will change throughout the day, requiring automatic white balancing to keep color fidelity.
<G-vec00590-002-s541><change.ändern><de> Im Laufe ihres Lebens ändert sich der Stand der Wissenschaft und Technik, sowie diverser Anforderungen.
<G-vec00590-002-s541><change.ändern><en> During their lifetime, the state of technical and scientific knowledge and the nature of requirements will change.
<G-vec00590-002-s542><change.ändern><de> Unter voller Last ändert sich die Laufzeit nicht großartig, im Idle-Betrieb ermöglicht die neue Prozessorengeneration circa 1:40 Stunden längere Laufzeiten.
<G-vec00590-002-s542><change.ändern><en> The battery life does not change greatly under full load, but the new processor generation allows using the laptop about 1:40 hours longer while idle.
<G-vec00590-002-s543><change.ändern><de> Das ändert sich auch nicht, wenn zum Beispiel Kokosmilch in der Süß-Sauer Sauce verwendet wird.
<G-vec00590-002-s543><change.ändern><en> This does not change if, for example, coconut milk is used in the sweet and sour sauce.
<G-vec00590-002-s544><change.ändern><de> Der Bestellprozess selbst ändert sich für Sie nicht.
<G-vec00590-002-s544><change.ändern><en> The ordering process itself does not change and no system modifications are required.
<G-vec00590-002-s545><change.ändern><de> Wenn du deinen Accountnamen änderst, wird eine email an die email-Adresse, welche du beim Registrieren angegeben hast, geschickt, und es ändert sich dein Anmelde-Name.
<G-vec00590-002-s545><change.ändern><en> When your name is changed, an email will be sent to your registered email address, and your login name will change to the new name.
<G-vec00590-002-s546><change.ändern><de> In den letzten Jahren ist es als Zentrum für Sommer- und Zweitwohnungen wichtig geworden, aber nach und nach ändert sich dieses Verhalten und die Anzahl der Menschen, die sich entscheiden, zu bleiben und von der Ruhe motiviert zu leben lebt in der Gemeinde, seine Nähe zum Meer und seiner natürlichen Umgebung.
<G-vec00590-002-s546><change.ändern><en> In recent years, it has become important as a center for summer and second homes, but little by little there is a change in this behavior and the number of people who decide to stay and live motivated by the tranquility lives in the municipality, its proximity to the sea and its natural environment.
<G-vec00590-002-s547><change.ändern><de> Wenn dies geschieht, ändert sich der Status von Ausstehend zu Abgelaufen.
<G-vec00590-002-s547><change.ändern><en> If this happens, the status will change from Pending to Expired.
<G-vec00590-002-s548><change.ändern><de> Haben sie indes ein neues Amt, ändert sich ihre Rhetorik.
<G-vec00590-002-s548><change.ändern><en> However, when they change office, they also change their rhetoric.
<G-vec00590-002-s549><change.ändern><de> Das Symbol ändert sich in ein geöffnetes Vorhängeschloss.
<G-vec00590-002-s549><change.ändern><en> the symbol will change to an open padlock.
<G-vec00590-002-s550><change.ändern><de> Jedes Schuljahr ändert sich die Bücherliste der Schule (und auch wenn die Titel gleich bleiben kann die Ausgabe sich ändern).
<G-vec00590-002-s550><change.ändern><en> The school book lists change slightly from one year to another (and even if the titles remain the same, the edition can change).
<G-vec00095-002-s601><adapt.ändern><de> Die wesentliche Aufgabe des Systems besteht darin, aktiv und ununterbrochen die Reaktion der Stoßdämpfer zu steuern, welche das eigene Verhalten auf Grundlage der Bewegungen des Fahrzeugaufbaus und der Straßenbedingungen ändern, wobei selbstverständlich die Anforderungen des Fahrers und sein Fahrstil berücksichtigt werden.
<G-vec00095-002-s601><adapt.ändern><en> Its main feature is to actively and continuously control the response of the shock absorbers, which adapt depending on the movement of the car and the road conditions, as well as the driving style.
<G-vec00095-002-s602><adapt.ändern><de> HÔTEL DE CHARME NEIGE ET ROC behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s602><adapt.ändern><en> HÔTEL DE CHARME NEIGE ET ROC reserves the right to adapt the data protection policy.
<G-vec00095-002-s603><adapt.ändern><de> In diesem Zusammenhang wird darauf hingewiesen, dass der Prüfer die Beschreibung nicht von Amts wegen ändern kann.
<G-vec00095-002-s603><adapt.ändern><en> In this context it is pointed out that the examining division may not adapt the description of its own motion.
<G-vec00095-002-s604><adapt.ändern><de> SAS HOSTELLERIE DE LEVERNOIS behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s604><adapt.ändern><en> SAS HOSTELLERIE DE LEVERNOIS reserves the right to adapt the data protection policy.
<G-vec00095-002-s605><adapt.ändern><de> Durch die Weiterentwicklung unserer Website und Angebote darüber oder aufgrund geänderter gesetzlicher beziehungsweise behördlicher Vorgaben kann es notwendig werden, diese Datenschutzerklärung zu ändern.
<G-vec00095-002-s605><adapt.ändern><en> We reserve the right to adapt our data protection declaration to ensure that it always complies with the applicable legal requirements, especially in the event of changes to our services.
<G-vec00095-002-s606><adapt.ändern><de> SARL CARON behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s606><adapt.ändern><en> SARL CARON reserves the right to adapt the data protection policy.
<G-vec00095-002-s607><adapt.ändern><de> La Villa Florentine behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s607><adapt.ändern><en> HÔTEL D reserves the right to adapt the data protection policy.
<G-vec00095-002-s608><adapt.ändern><de> Hôtel Lyon Métropole behält sich das Recht vor, seine Richtlinie zum Schutz personenbezogener Daten zu ändern.
<G-vec00095-002-s608><adapt.ändern><en> Hôtel Lyon Métropole reserves the right to adapt the data protection policy.
<G-vec00095-002-s609><adapt.ändern><de> Gehen Sie ganz einfach zu Einstellungen > Deals, und klicken Sie unter ‚Templates für Angebotinhalt‘ auf den Stift neben der Vorlage, die Sie ändern wollen.
<G-vec00095-002-s609><adapt.ändern><en> Just go to Settings> Deals, and click the pencil next to the template you want to adapt under 'Templates for quotation content'.
<G-vec00095-002-s610><adapt.ändern><de> Da das Unternehmen regelmäßig Events und Kundenveranstaltungen durchführt, ist die Möglichkeit, Zutrittszeiten flexibel zu ändern, besonders hilfreich.
<G-vec00095-002-s610><adapt.ändern><en> As the company regularly organises customer events, it is particularly useful to adapt the access times in such a flexible way.
<G-vec00095-002-s611><adapt.ändern><de> Wir sind berechtigt, eingesandte Formeinrichtungen und Werkzeuge zu ändern, soweit dies aus technischen Gründen oder zwecks Verminderung des Risikos notwendig erscheint, unbeschadet der Haftung des Käufers für die richtige Konstruktion und die den Verwendungszweck sichernde Ausführung.
<G-vec00095-002-s611><adapt.ändern><en> We are entitled to adapt moulds and tools which have been submitted to us to the extent that this seems necessary for technical reasons or in order to minimize risks, without prejudice to Buyer’s liability to submit only tools which are properly designed and manufactured for their intended use.
<G-vec00095-002-s612><adapt.ändern><de> In einem solchen Fall ändern Sie bitte Ihre Internetoptionen oder schreiben Sie kurz Ihren Aufnahmewunsch als E-Mail.
<G-vec00095-002-s612><adapt.ändern><en> In such a case please adapt your internet options or write your registration as a normal email to us.
<G-vec00095-002-s936><adjust.ändern><de> Sie können Ihre Cookie-Einstellung jederzeit hier ändern: Datenschutz.
<G-vec00095-002-s936><adjust.ändern><en> Username Email You may adjust your notification preferences at any time
<G-vec00095-002-s937><adjust.ändern><de> So kannst du beispielsweise die Lautstärke nachjustieren, ohne gleich das ganze Video ändern zu müssen.
<G-vec00095-002-s937><adjust.ändern><en> This will allow you to adjust things like volume without affecting the video.
<G-vec00095-002-s938><adjust.ändern><de> Intuitive Bedienung: Durch den großen, gut ablesbaren LCD-Monitor und die praktisch angeordneten Bedienelemente können Sie die Einstellungen ganz leicht ändern.
<G-vec00095-002-s938><adjust.ändern><en> Intuitive operation: the large, easy-to-read LCD screen and conveniently placed controls make it easy to adjust settings.
<G-vec00095-002-s939><adjust.ändern><de> Auf einigen Rechnern können Sie den Eigentümer eines freigegebenen Ordners über die Desktop-App von Dropbox ändern.
<G-vec00095-002-s939><adjust.ändern><en> You can adjust the editing permissions granted to members of the shared folder of the file you're working on using the Dropbox badge.
<G-vec00095-002-s940><adjust.ändern><de> Kopfschutz geeignet zum Arbeiten in der Höhe und am Boden bei Tag und Nacht: - Das DUAL-Kinnband bietet dem Benutzer die Möglichkeit, die Haltekraft des Kinnbands zu ändern, um den Helm unterschiedlichen Arbeitssituationen anzupassen: Arbeiten in der Höhe (EN 12492) und Arbeiten am Boden (EN 397).
<G-vec00095-002-s940><adjust.ändern><en> • Protection designed for work at height and on the ground: - DUAL chinstrap allows the worker to adjust chinstrap strength in order to adapt the helmet to different environments: work at height (EN 12492) or on the ground (EN 397).
<G-vec00095-002-s941><adjust.ändern><de> Wichtig: Nur Team-Administratoren können Standard-Freigabeberechtigungen ändern.
<G-vec00095-002-s941><adjust.ändern><en> Key Points: Only team admins can adjust default sharing rules.
<G-vec00095-002-s942><adjust.ändern><de> Jedes Quartal wird geschaut wo der LIBOR-Satz steht, demzufolge kann sich der Kundenzins jedes Quartal ändern (Kundenmarge + LIBOR-Satz = Kundenzins).
<G-vec00095-002-s942><adjust.ändern><en> Each quarter, the banks check the LIBOR rate and may adjust the customer rate accordingly (customer margin + LIBOR rate = customer rate).
<G-vec00095-002-s943><adjust.ändern><de> Du kannst deine Ziel-Vorgabe entweder für alle zukünftigen Tage/Wochen ändern oder nur für den gerade aktuellen Zeitraum.
<G-vec00095-002-s943><adjust.ändern><en> You can adjust your targets for all future days/weeks or only for the current period.
<G-vec00095-002-s944><adjust.ändern><de> Sie können die Intensität der Schraffierung ändern, die Linien feiner machen, der Winkel der Striche festlegen, Ausgangsfarben hinzufügen/entfernen.
<G-vec00095-002-s944><adjust.ändern><en> You can adjust all the settings: make the hatching denser or finer, change the pitch angle of strokes, choose the pencil color, etc.
<G-vec00095-002-s945><adjust.ändern><de> 2.2 Der Verkäufer behält sich das Recht vor, die Preise periodisch zu ändern.
<G-vec00095-002-s945><adjust.ändern><en> The seller reserves the right to adjust its prices periodically.
<G-vec00095-002-s946><adjust.ändern><de> Wenn ein Meeting länger dauert als erwartet, kann ich die Zeitbuchung im Kalender einfach mit Drag & Drop ändern.
<G-vec00095-002-s946><adjust.ändern><en> If it happens that a meeting takes longer than expected, I can easily adjust the auto-generated booking in time cockpit’s calendar using drag and drop.
<G-vec00095-002-s947><adjust.ändern><de> Wir behalten uns das Recht vor, Preise, Angebote, Produkte und Produktbeschreibungen auf unserer Website nach unserem Ermessen zu jeder Zeit zu ändern.
<G-vec00095-002-s947><adjust.ändern><en> We reserve the right to adjust prices, offers, goods and specifications of goods on the Website at our discretion at any time before (but not after) we accept your order.
<G-vec00095-002-s948><adjust.ändern><de> Aber an manche dieser Aufträge kommt man erst, wenn man vorher andere Aufträge abgeschlossen hat, und wir würden das gerne ändern, sobald wir die Möglichkeit dazu haben.
<G-vec00095-002-s948><adjust.ändern><en> However, some of these quests were tied behind other quests, so we would like to adjust these when we have the opportunity.
<G-vec00095-002-s949><adjust.ändern><de> Bitte beachten Sie, dass Sie nach der Angabe Ihrer Kreditkartendaten beim Upgrade-Angebot diese Informationen nicht erneut angeben müssen, wenn Sie die Angebotssumme zu einem späteren Zeitpunkt ändern wollen.
<G-vec00095-002-s949><adjust.ändern><en> Please note that once you have submitted your credit card details to bid for an upgrade, you will not be required to re-enter those credit card details if you wish to adjust the bid amount at a later stage.
<G-vec00095-002-s950><adjust.ändern><de> Wenn du die Privatsphäreeinstellungen deines Mobilgeräts ändern möchtest, lies bitte unter Abruf, Aktualisierung und Verwaltung deiner Daten nach.
<G-vec00095-002-s950><adjust.ändern><en> If you want to adjust your privacy preferences on your mobile device, please see How to Access, Update and Manage Your Information.
<G-vec00095-002-s951><adjust.ändern><de> Damit konnten sie Reservierungen vornehmen, aber online nichts ändern.
<G-vec00095-002-s951><adjust.ändern><en> They could make a reservation, but were not able to adjust it online.
<G-vec00095-002-s952><adjust.ändern><de> Sie haben vielleicht das Gefühl, dass Sie unnatürlich langsam sprechen, Sie können die Geschwindigkeit mit Ihrer Audio-Aufzeichnungssoftware später jedoch noch ändern.
<G-vec00095-002-s952><adjust.ändern><en> You may feel that you are speaking artificially slowly, but you should be able to adjust the speed later by using your audio recording software.
<G-vec00095-002-s953><adjust.ändern><de> Der Versicherer kann dieses Pensionsalter im Laufe eines Vertrags aufgrund der allgemeinen Regeln über das gesetzliche Pensionsalter einseitig ändern.
<G-vec00095-002-s953><adjust.ändern><en> The employer can unilaterally adjust this retirement age during the course of the agreement based on the general rules governing the statutory retirement age.
<G-vec00095-002-s954><adjust.ändern><de> Sie können diese Zusammensetzung natürlich nach Ihren Vorstellungen ändern.
<G-vec00095-002-s954><adjust.ändern><en> Of course you can adjust this composition according to your preferences.
<G-vec00095-002-s154><alter.ändern><de> TRIA ist ein laufend weiterentwickeltes modulfähiges System, das nach den Wünschen des Kunden wachsen und geändert werden kann.
<G-vec00095-002-s154><alter.ändern><en> TRIA is a module system that has evolved continuously and can grow and alter depending on the client's needs.
<G-vec00095-002-s155><alter.ändern><de> Da TuneCore sich fortlaufend entwickelt, ändert und expandiert, um deine Anforderungen zu erfüllen, kann es sein, dass die Datenschutzerklärung geändert oder aktualisiert werden muss.
<G-vec00095-002-s155><alter.ändern><en> As TuneCore grows, changes, and expands to suit your needs, we may need to modify, alter or otherwise update this privacy policy.
<G-vec00095-002-s156><alter.ändern><de> Wenn Sie die Option Anzeigeformat ändern, wird die Framerate von Clips oder Sequenzen nicht geändert.
<G-vec00095-002-s156><alter.ändern><en> Changing the Display Format option does not alter the frame rate of clips or sequences.
<G-vec00095-002-s157><alter.ändern><de> Allerdings kann durch die Verwendung des SSL-Zertifikats die Funktionsweise Ihrer Webseite geändert werden.
<G-vec00095-002-s157><alter.ändern><en> However, using your SSL certificate may alter the way your website works.
<G-vec00095-002-s158><alter.ändern><de> Bei Textindizes mit sofortiger Aktualisierung müssen Sie den Textindex löschen und ihn wieder erstellen, nachdem Sie das Textkonfigurationsobjekt geändert haben.
<G-vec00095-002-s158><alter.ändern><en> For immediate refresh text indexes, you must drop the text index and recreate it after you alter the text configuration object.
<G-vec00095-002-s159><alter.ändern><de> (6) Eine Kopie eines Beschlusses des Gerichts nach diesem Abschnitt, mit dem das Memorandum oder die Satzung einer Gesellschaft geändert wird oder geändert werden kann, wird von der Gesellschaft innerhalb von 14 Tagen nach Erlass des Beschlusses oder einer längeren Frist, die das Gericht zulassen kann, dem Registerführer zur Eintragung zugestellt.
<G-vec00095-002-s159><alter.ändern><en> (6) A copy of an order of the Court under this section altering, or giving leave to alter, a company‘s memorandum or articles shall, within 14 days from the making of the order or such longer period as the Court may allow, be delivered by the company to the Registrar for registration.
<G-vec00095-002-s160><alter.ändern><de> Die Einstellung der Option chained kann nicht innerhalb einer Transaktion geändert werden.
<G-vec00095-002-s160><alter.ändern><en> You cannot alter the setting of the chained option within a transaction.
<G-vec00095-002-s161><alter.ändern><de> Nutzerbeiträge Bei einigen Spielen können Objekte oder sonstige Spielelemente erstellt, geändert, entworfen, verschönert oder sonst irgendwie geändert werden.
<G-vec00095-002-s161><alter.ändern><en> Some games may contain the ability to create, modify, design, embellish, or otherwise alter objects or other elements in the game.
<G-vec00095-002-s162><alter.ändern><de> Mit diesem Werkzeug werden die Geometrien aus Eingabe-Datasets weder geteilt noch geändert.
<G-vec00095-002-s162><alter.ändern><en> This tool will not split or alter the geometries from the input datasets.
<G-vec00095-002-s163><alter.ändern><de> Eine Partitionsfunktion kann nicht so erstellt oder geändert werden, dass sie keine Partitionen enthält.
<G-vec00095-002-s163><alter.ändern><en> Can not create or alter a partition function to have zero partitions.
<G-vec00095-002-s239><alter.ändern><de> Warnung: Die 'is_ms_shipped'-Eigenschaft ist für das %1-Objekt '%2' deaktiviert, da Sie nicht über die Berechtigung zum Erstellen oder Ändern eines Objekts mit dieser Eigenschaft verfügen.
<G-vec00095-002-s239><alter.ändern><en> Warning: 'is_ms_shipped' property is turned off for %1 '%2' because you do not have permission to create or alter an object with this property.
<G-vec00095-002-s240><alter.ändern><de> Ändern Sie die Netzwerkzeit, lassen Sie die Uhren driften oder versagen Sie, alles richtig zu synchronisieren und eine ganze Reihe von Problemen kann entstehen.
<G-vec00095-002-s240><alter.ändern><en> Alter the network time, allow the clocks to drift or fail to synchronise everything properly and a whole host of problems can arise.
<G-vec00095-002-s241><alter.ändern><de> Ändern Sie nicht die von Ihrem Arzt vorgeschriebene Dosis, da dies schwerwiegende Folgen haben kann und sogar Ihren Zustand verschlechtern kann.
<G-vec00095-002-s241><alter.ändern><en> Do not alter the dose prescribed by your physician as this may have serious implications and may even worsen your condition.
<G-vec00095-002-s242><alter.ändern><de> Da der ursprüngliche Wert jedoch bereits zum Ändern der Pixeldaten in der Datei verwendet wurde, verfügt Camera Raw nicht über eine genaue Kelvin-Temperaturskala.
<G-vec00095-002-s242><alter.ändern><en> Because the original value was already used to alter the pixel data in the file, Camera Raw does not provide the true Kelvin temperature scale.
<G-vec00095-002-s243><alter.ändern><de> Ändern Sie alle Tabellen der Benutzeranwendung auf VOLATILE, damit das Optimierungsprogramm weiß, dass die Kardinalität der Tabelle deutlich abweichen kann.
<G-vec00095-002-s243><alter.ändern><en> Alter all the User Application tables to be VOLATILE to indicate to the optimizer that cardinality of the table will vary significantly.
<G-vec00095-002-s244><alter.ändern><de> Ändern wird sich aller Voraussicht nach auch die Werbung mit dem Fokus auf Kinder.
<G-vec00095-002-s244><alter.ändern><en> In all probability advertising focused on children will also alter.
<G-vec00095-002-s245><alter.ändern><de> Verwenden Sie zum Ändern der Bildposition das Symbol, das angezeigt wird, wenn Sie den Mauszeiger über das Bild bewegen.
<G-vec00095-002-s245><alter.ändern><en> To alter the image position, use the icon that appears after hovering your mouse cursor over the image.
<G-vec00095-002-s246><alter.ändern><de> Ändern Sie Fenstertitel, Seitenüberschriften, Bildgrößen und -qualitäten.
<G-vec00095-002-s246><alter.ändern><en> Alter the window title, page titles, image sizes and qualities.
<G-vec00095-002-s247><alter.ändern><de> Ändern Sie die Konfiguration, bis sie funktioniert.
<G-vec00095-002-s247><alter.ändern><en> Alter the configuration until it works.
<G-vec00095-002-s248><alter.ändern><de> Ändern Sie die Werte bei den Server-Einstellungen nach Ihren Wünschen.
<G-vec00095-002-s248><alter.ändern><en> Alter the values in the Server Settings section of the page according to your preferences.
<G-vec00095-002-s249><alter.ändern><de> Der Vertriebspartner stimmt zu, umgehend jede Anfrage von mSpy zum Entfernen, Ändern oder Modifizieren jeglichen Links, jeglicher Grafik oder Bannerwerbung, die vom Vertriebspartner im Rahmen des Vertriebspartnerprogramms verwendet wird, umzusetzen.
<G-vec00095-002-s249><alter.ändern><en> Affiliate agrees to promptly implement any request from mSpy to remove, alter or modify any Link, graphic or banner ad that is being used by Affiliate as part of the Affiliate Program.
<G-vec00095-002-s250><alter.ändern><de> Ändern Sie die Monitor-Startzeilenzeichenfolge so, dass die Zertifikate verwendet werden.
<G-vec00095-002-s250><alter.ändern><en> Alter the Monitor start line string to use the certificates.
<G-vec00095-002-s289><alter.ändern><de> Die Tatsache, daß der Berichtigungsantrag sich auf einen Erteilungsbeschluß bezieht, ändere nichts an der Zuständigkeit, denn angefochten werde ja die Entscheidung, einen Berichtigungsantrag zurückzuweisen, nicht aber der Erteilungsbeschluß.
<G-vec00095-002-s289><alter.ändern><en> The fact that the request for correction relates to a decision to grant a patent does not, according to that decision, alter the competence because what is under appeal is the decision to refuse a request for correction and not the decision to grant the patent.
<G-vec00095-002-s290><alter.ändern><de> Ich ändere meinen Entschluß:—mich zieht es nach dem Kapitol:—ich gehe mit euch nach Rom.
<G-vec00095-002-s290><alter.ändern><en> I alter my resolution; I long to get to the Capitol; I will go with you to Rome.
<G-vec00095-002-s291><alter.ändern><de> Du kannst eine Nachricht oder eine Frage hinzufügen, aber ändere bitte weder die Betreffzeile noch den Text der E-Mail.
<G-vec00095-002-s291><alter.ändern><en> You can add a note or a question, but don’t alter the subject or content of the email.
<G-vec00095-002-s292><alter.ändern><de> Auch die Hervorhebung dieses Elements in Form und Farbe ändere nichts daran, dass dieser Teil des angemeldeten Zeichens vom Publikum als Buchstabe „v“ wahrgenommen werden werde.
<G-vec00095-002-s292><alter.ändern><en> Nor does the emphasis on the shape and colour of that element alter the fact that that part of the sign applied for will be perceived by the public as a letter ‘v’.
<G-vec00095-002-s293><alter.ändern><de> SO Connect kann seine Preise regelmäßig einseitig ändern, um inflationären, allgemeinen wirtschaftlichen, politischen oder organisatorischen Entwicklungen Rechnung zu tragen.
<G-vec00095-002-s293><alter.ändern><en> SO Connect may periodically alter its prices unilaterally to reflect inflationary, general economic, political or organizational developments.
<G-vec00095-002-s294><alter.ändern><de> Dieses Fenster wird angezeigt, wenn Sie auf die Schaltfläche PMFs ändern klicken.
<G-vec00095-002-s294><alter.ändern><en> This window appears after you click the Alter PMFs button.
<G-vec00095-002-s295><alter.ändern><de> Speichern und ändern Sie Dateien, ohne Zeit oder Effizienz zu opfern.
<G-vec00095-002-s295><alter.ändern><en> Store and alter files without sacrificing time or efficiency.
<G-vec00095-002-s296><alter.ändern><de> Fix: In 2.0 war es nicht möglich, die Seiten-Etiketten in der Seitenliste zu ändern.
<G-vec00095-002-s296><alter.ändern><en> Fixed: In 2.0 it was not possible to alter the page labels in the page list.
<G-vec00095-002-s297><alter.ändern><de> Recht auf Abbruch: PokerStars Live, gemeinsam mit dem veranstaltenden Casino, in dem das Event stattfindet, behält sich das Recht vor, jegliches Event oder Turnier nach unserem alleinigen und uneingeschränkten Ermessen abzubrechen oder zu ändern.
<G-vec00095-002-s297><alter.ändern><en> Right to Cancel: PokerStars Live, together with the organising casino in which the Event will be held, reserve the right to cancel or alter any Event or Tournament at our sole and absolute discretion.
<G-vec00095-002-s298><alter.ändern><de> Um diese zu ändern, gehe in den „Persönlichen Bereich“; der Link dazu wird meist oben auf der Seite angezeigt.
<G-vec00095-002-s298><alter.ändern><en> To alter them, visit your User Control Panel; a link can be found at the top of the forum pages or via the User panel on any of our portal home pages.
<G-vec00095-002-s299><alter.ändern><de> Allbirds behält sich das Recht vor, die Bedingungen oder die Dauer von Sonderangeboten oder Werbeaktionen zu ändern.
<G-vec00095-002-s299><alter.ändern><en> Allbirds reserves the right to alter the terms or duration of any special offers or sale promotion.
<G-vec00095-002-s300><alter.ändern><de> Keine nationale Regierung könnte die Wechselkurse ändern, d.h. keinem Land wäre es mehr gestattet, durch Abwertung einen Weg aus der Krise zu suchen.
<G-vec00095-002-s300><alter.ändern><en> No national government would be allowed to alter the agreed exchange rate. This means that no country would be allowed to get out of a crisis by resorting to devaluation.
<G-vec00095-002-s301><alter.ändern><de> Sie stimmen zu, kein von mir auf dieser Website angezeigtes Material ganz oder teilweise hinzuzufügen, zu ändern, zu ersetzen oder zu ergänzen.
<G-vec00095-002-s301><alter.ändern><en> You agree not to add, alter, substitute or amend, partially or in whole, any Material displayed by me on this Web Site.
<G-vec00095-002-s302><alter.ändern><de> Um Cookies zu begrenzen, blockieren oder löschen, genügt es die Einstellungen Ihres Browsers zu ändern.
<G-vec00095-002-s302><alter.ändern><en> Link Disabling cookies Alter your web browser settings to limit, block or cancel cookies.
<G-vec00095-002-s303><alter.ändern><de> Die Wärmeeinflusszone kann die Blecheigenschaften, welche durch die Walzbearbeitung erklärt werden, wesentlich ändern.
<G-vec00095-002-s303><alter.ändern><en> The heat-affected zone can alter the sheet metal figures as declared by the rolling mill to a great extent.
<G-vec00095-002-s304><alter.ändern><de> Schmerz beispielsweise kann einen Wissenschaftler dazu zwingen, den Pipettierrhythmus zu variieren oder den Druck auf den Pipettierknopf zu ändern.
<G-vec00095-002-s304><alter.ändern><en> Pain, for example, can compel a research scientist to vary the pipetting rhythm or alter the pressure on the plunger.
<G-vec00095-002-s305><alter.ändern><de> Darum, wenn man das tun möchte, muss man zuerst den gesamten Verfassungsvertrag zwischen den Regierten und den Regierenden, zwischen der Krone und dem Volk und zwischen der Königin und den Untergebenen ändern.
<G-vec00095-002-s305><alter.ändern><en> Therefore, if you are going to do that, you have first of all to alter the whole constitutional contract between the governed and the governors; between the Crown and the people; and between the Queen and her subjects.
<G-vec00095-002-s306><alter.ändern><de> Bei der Aktualisierung könnte der debconf-Mechanismus die Datei in einer Weise ändern, dass viewcvs diese nicht mehr interpretieren kann.
<G-vec00095-002-s306><alter.ändern><en> Upon upgrade the debconf mechanism may alter it in a way so that viewcvs doesn't understand it anymore.
<G-vec00095-002-s307><alter.ändern><de> Wenn Menschen der Ansicht sind, dass ihre Ernährung bereits gesund ist, kann man nicht von ihnen erwarten, dass sie ihre Ernährung ändern, oder dass sie Nährstoffe/gesundes Essen als wesentlichen Faktor bei der Auswahl ihrer Nahrungsmittel berücksichtigen.
<G-vec00095-002-s307><alter.ändern><en> If people believe that their diets are already healthy it may be unreasonable to expect them to alter their diets, or to consider nutrition/healthy eating as a highly important factor when choosing their food.
<G-vec00095-002-s308><alter.ändern><de> 15.4 Der Plattformbetreiber kann diese Nutzungs- und Teilnahmebedingungen jederzeit und ohne Angabe von Gründen ändern.
<G-vec00095-002-s308><alter.ändern><en> 15.4 The Platform Operator may alter these Special Terms & Conditions of Use and Participation at any time without giving reasons.
<G-vec00095-002-s309><alter.ändern><de> Akzeptieren oder ändern Sie den vorgegebenen Standardnamen UNQ_TABLENAME und klicken Sie auf die Drop-Down-Liste in der Spalte Auf Feld, um die gewünschten Felder als unique zu definieren.
<G-vec00095-002-s309><alter.ändern><en> Either accept or alter the default name UNQ_TABLENAME, and then click the drop-down list in the On Field column to select the field(s) you wish to specify as unique.
<G-vec00095-002-s310><alter.ändern><de> Sie haben versucht, einen systemdefinierten Wartungsplan zu ändern.
<G-vec00095-002-s310><alter.ändern><en> You attempted to alter a system-defined maintenance plan.
<G-vec00095-002-s311><alter.ändern><de> Centro Vacanze Pra' delle Torri behält sich das Recht vor, die Inhalte der Webseite und Rechtlichen Hinweise jederzeit und ohne vorherige Ankündigung zu ändern.
<G-vec00095-002-s311><alter.ändern><en> Centro Vacanze Pra' delle Torri reserves the right to alter the contents of the site and the legal notes at any time without prior notice.
<G-vec00095-002-s125><modify.ändern><de> Kopien (Papier oder digital) von Materialien, die Sie ausgedruckt oder heruntergeladen haben, dürfen nicht geändert werden und Illustrationen, Fotografien, Video- oder Audio-Sequenzen oder Grafiken dürfen nicht losgelöst vom dazugehörigen Text verwendet werden.
<G-vec00095-002-s125><modify.ändern><en> You must not modify the paper or digital copies of any materials you have printed off or downloaded in any way, and you must not use any illustrations, photographs, video or audio sequences or any graphics separately from any accompanying text.
<G-vec00095-002-s126><modify.ändern><de> In den Diözesen von Quebec zum Beispiel haben sich die Reformen des Konzils auf schon bestehende Neuerungen aufgesetzt, deren Orientierung sie kaum geändert haben.
<G-vec00095-002-s126><modify.ändern><en> In the dioceses of Quebec, for example, the reforms instituted by the Council became grafted on to institutional changes which were already being made but did not modify their orientation.
<G-vec00095-002-s127><modify.ändern><de> Dateien mit eingehenden Änderungen müssen zuerst lokal geändert werden (um Konflikte zu erzeugen), bevor Sie sie mit der Option "Einchecken erzwingen" einchecken.
<G-vec00095-002-s127><modify.ändern><en> For files with incoming changes only, you must first modify the files locally (to make them conflicting) before performing a force check-in.
<G-vec00095-002-s128><modify.ändern><de> Die Einstellungen einer vorhandenen Kalibrierungseinstellung können nicht geändert werden.
<G-vec00095-002-s128><modify.ändern><en> You cannot modify the settings of an existing calibration setting.
<G-vec00095-002-s129><modify.ändern><de> Das Tool "Nach verlorenen Daten suchen" aktiviert die Registerkarte "Wiederherstellung", in der die Parameter für die Dateisystemprüfung angegeben oder geändert werden.
<G-vec00095-002-s129><modify.ändern><en> The "Scan for lost data" tool activates the "Recovery" tab used to specify or modify the parameters for the file system scan.
<G-vec00095-002-s130><modify.ändern><de> Es können Synonyme für die Sprache eingefügt, geändert oder gelöscht werden.
<G-vec00095-002-s130><modify.ändern><en> Insert, modify or remove synonyms for this language.
<G-vec00095-002-s131><modify.ändern><de> 6.3 Da, wie oben dargelegt, die Entscheidung T 215/88 rechtskräftig ist, kann deren Inhalt nicht mehr geändert werden; daher läßt sich auch nicht behaupten, daß die drei ursprünglich bestimmten Mitglieder (einschließlich des Vorsitzenden) insofern ein persönliches Interesse an der Sache hätten, als sie bestrebt wären, ihre eigene Entscheidung unter allen Umständen aufrechtzuerhalten.
<G-vec00095-002-s131><modify.ändern><en> 6.3 Since, as pointed out above, decision T 215/88 is final, it is now impossible to modify its contents and, thus, it cannot be said that the first three nominated members (including the Chairman) have a personal interest insofar as they would be partial in order to try to maintain their own decision.
<G-vec00095-002-s132><modify.ändern><de> Ändern von Objekten Wählen Sie das Objekt aus, das geändert werden soll.
<G-vec00095-002-s132><modify.ändern><en> Modifying objects Select the object first, to modify it.
<G-vec00095-002-s133><modify.ändern><de> Dabei muss Euer Code nicht einmal geändert werden, und die Erfassung der Daten beginnt nahezu umgehend.
<G-vec00095-002-s133><modify.ändern><en> You won't need to modify your code in any way, and your URL channels will begin tracking data almost immediately.
<G-vec00095-002-s134><modify.ändern><de> Mit dem ECL Tool kann auf einen ECL Comfort 210/310 Regler zugegriffen werden und die Parametereinstellungen geladen, geändert und gespeichert werden.
<G-vec00095-002-s134><modify.ändern><en> ECL Tool lets service personnel connect to an ECL Comfort 210/310 controller and load, modify and save settings of all its parameters.
<G-vec00095-002-s135><modify.ändern><de> Auch Datumsangaben werden bei einer Kostenressourcenzuordnung nicht neu berechnet, da Arbeit oder Einheiten nicht geändert werden können.
<G-vec00095-002-s135><modify.ändern><en> Dates are also never recalculated for a cost resource assignment, because you can’t modify the work or units.
<G-vec00095-002-s136><modify.ändern><de> Die Ordnung der Bilder kann ganz einfach geändert werden.
<G-vec00095-002-s136><modify.ändern><en> Allows you to modify the order of the images by just dragging and dropping.
<G-vec00095-002-s137><modify.ändern><de> Das SACommand-Objekt ermöglicht Ihnen, SQL-Anweisungen durchzuführen, mit denen Daten direkt aus der Datenbank abgerufen oder dort geändert werden.
<G-vec00095-002-s137><modify.ändern><en> The SACommand object allows you to execute SQL statements that retrieve or modify data directly from the database.
<G-vec00095-002-s138><modify.ändern><de> Die meisten Browser akzeptieren Cookies automatisch, dies kann jedoch in den Einstellungen des Browsers geändert werden.
<G-vec00095-002-s138><modify.ändern><en> Most web browsers automatically accept cookies, but you can modify your browser settings to decline cookies if you prefer.
<G-vec00095-002-s139><modify.ändern><de> Wenn auf den globalen Katalogservern Windows® 2000 Server ausgeführt wird, kann ein Registrierungsschlüssel auf den Exchange 2000 SP3-Servern geändert werden, um die Zuverlässigkeit zu erhöhen.
<G-vec00095-002-s139><modify.ändern><en> If your global catalog servers are running Windows® 2000 Server, you can modify a registry key on your Exchange 2000 SP3 servers to achieve greater reliability.
<G-vec00095-002-s140><modify.ändern><de> Wie in der Richtlinie 2014/24/EU vorgesehen, ist es erforderlich, die Bedingungen, unter denen ein Vertrag während des Ausführungszeitraums ohne neues Vergabeverfahren geändert werden kann, zu präzisieren.
<G-vec00095-002-s140><modify.ändern><en> As is the case in Directive 2014/24/EU, it is necessary to clarify the conditions under which it is possible to modify a contract during its performance without a new procurement procedure.
<G-vec00095-002-s141><modify.ändern><de> Unter Umständen wird die vorliegende Datenschutzrichtlinie von Zeit zu Zeit geändert oder aktualisiert.
<G-vec00095-002-s141><modify.ändern><en> We may modify or update this Privacy Policy from time to time.
<G-vec00095-002-s142><modify.ändern><de> Die Ikone für Ordner und Diskette im Explorer Fenster wird geändert; beim Dekompilieren von AS 3.0 wird das Unterordner ergestellt, um ActionScript anzusehen.
<G-vec00095-002-s142><modify.ändern><en> Modify the icon for folder and disk in explorer window; when decompiling AS 3.0, the sub-folder is created to view ActionScript.
<G-vec00095-002-s143><modify.ändern><de> 1.1 Sie dürfen unsere Website für Ihre eigenen Zwecke nutzen und ausdrucken und Material von dieser Website herunterladen, vorausgesetzt, dass Inhalte nicht ohne unsere Zustimmung geändert werden.
<G-vec00095-002-s143><modify.ändern><en> You are permitted to use our web site for your own purposes and to print and download material from this Web site provided that you do not modify any content without our consent.
<G-vec00095-002-s406><modify.ändern><de> 3M behält sich das Recht vor, diese Richtlinie jederzeit und ohne vorherige Ankündigung zu aktualisieren oder zu ändern, indem sie die geänderte Version dieser Richtlinie auf den 3M Websites bekannt gibt.
<G-vec00095-002-s406><modify.ändern><en> 3M reserves the right to update or modify this Policy, at any time and without prior notice, by posting the revised version of this Policy on our 3M Internet Sites.
<G-vec00095-002-s407><modify.ändern><de> Außerdem ist es dem Nutzer nicht gestattet, Bezeichnungen bezüglich des Copyrights und sonstiger geistiger Eigentumsrechte des Fastcounters oder sonstiger Leistungen von DEVROCK zu entfernen, zu ändern oder unleserlich zu machen.
<G-vec00095-002-s407><modify.ändern><en> In addition, the user is not permitted to remove, modify or make illegible any copyright or other intellectual property rights of the Fastcounters or other services of DEVROCK.
<G-vec00095-002-s408><modify.ändern><de> Deutsch-20 BN68-00926A-00Ger.qxd 5/24/05 5:31 PM Page 21 Gespeicherte Kanäle sortieren Sie können die Nummern von zwei Kanälen austauschen, um: Die numerische Reihenfolge zu ändern, in der die Kanäle automatisch gespeichert wurden.
<G-vec00095-002-s408><modify.ändern><en> English-18 BN68-00801C-02Eng.qxd 2/25/05 9:53 AM Page 19 Sorting the Stored Channels You can exchange the numbers of two channels, in order to: Modify the numeric order in which the channels have been automatically stored.
<G-vec00095-002-s409><modify.ändern><de> Ohne die vorherige schriftliche Erlaubnis von Graupner ist es nicht gestattet, den Inhalt dieser Webseite zu veröffentlichen oder zu verbreiten, zu ändern, zu übertragen, wiederzuverwenden, öffentlich wiederzugeben oder zu öffentlichen oder für kommerzielle Zwecke zu verwenden.
<G-vec00095-002-s409><modify.ändern><en> It is prohibited to publish, distribute, modify, transmit, re-use, reproduce or otherwise make use of the content of this website, or use it for commercial purposes, without the prior written permission of the Graupner company.
<G-vec00095-002-s410><modify.ändern><de> Unsere Webseite gewährt Ihnen eine beschränkte Lizenz für den Zugriff und zur persönlichen Nutzung dieser Website und nicht zum Download (außer Page-Caching) oder zu ändern, oder eines Teils davon, außer mit ausdrücklicher schriftlicher Zustimmung von unserer Website diese Lizenz beinhaltet nicht den Weiterverkauf oder die kommerzielle Nutzung dieser Website oder ihrer Inhalte; einschließlich der Sammlung und Verwendung von Produktlisten, Beschreibungen oder Preisen; jede derivative Nutzung dieser Website oder ihrer Inhalte; Herunterladen oder Kopieren von Kontoinformationen zugunsten eines anderen Händlers: oder jeder Einsatz von Data-Mining, Robotern oder ähnlichen Datenerfassungs-und Extraktionstools.
<G-vec00095-002-s410><modify.ändern><en> Tonerandinkjetstore.com grants you a limited license to access and make personal use of this site and not to download (other than page caching) or modify it, or any portion of it, except with express written consent of Tonerandinkjetstore. This license does not include any resale or commercial use of this site or its contents; any collection and use of any product listings, descriptions, or prices; any derivative use of this site or its contents; any downloading or copying of account information for the benefit of another merchant; or any use of data mining, robots, or similar data gathering and extraction tools.
<G-vec00095-002-s411><modify.ändern><de> Toluna behält sich das Recht vor, die Verlosungen abzubrechen, zeitweise auszusetzen und/oder zu ändern, wenn Betrug, technische Fehler oder andere Faktoren, die jenseits der Kontrolle von Toluna liegen, die Integrität der Verlosungen beeinträchtigen könnten.
<G-vec00095-002-s411><modify.ändern><en> Toluna reserves the right to cancel, suspend and/or modify the sweepstakes if fraud, technical failures or any other factors beyond the reasonable control of Toluna may impair the integrity of the sweepstakes.
<G-vec00095-002-s412><modify.ändern><de> Der Code in diesem Beispiel soll Ihnen helfen, eigene Anwendungen zum Hochladen von Videos zu erstellen oder die Beispielanwendung nach Bedarf zu ändern.
<G-vec00095-002-s412><modify.ändern><en> By following the code described in this topic, you will be able to build your own applications for uploading video or modify the example application as needed.
<G-vec00095-002-s413><modify.ändern><de> Das Unternehmen gewährt Ihnen eine beschränkte Lizenz für den Zugriff und zur persönlichen Nutzung dieser Webseite und nicht zum Download (ausgenommen Seite Caching) oder zu ändern, oder eines Teils davon, außer mit ausdrücklicher schriftlicher Zustimmung des Unternehmens.
<G-vec00095-002-s413><modify.ändern><en> D-NEXUS grants you a limited license to access and make personal use of this site and not to download (other than page caching) or modify it, or any portion of it, except with express written consent of D-NEXUS, .
<G-vec00095-002-s414><modify.ändern><de> Wir behalten uns das Recht vor, unsere Website oder unsere über die Website angebotenen Dienste, Inhalte, Funktionen oder Produkte jederzeit nach eigenem Ermessen mit oder ohne Ankündigung zu ändern, auszusetzen oder einzustellen, Gebühren im Zusammenhang mit der Nutzung einer Website zu erheben und im Zusammenhang mit der Website erhobene Gebühren zu ändern und/oder zu erlassen und/oder einigen oder allen Nutzern der Website Möglichkeiten anzubieten.
<G-vec00095-002-s414><modify.ändern><en> We reserve the right, at any time in our sole discretion, to: modify, suspend or discontinue any of Our Websites or any service, content, feature or product offered through any Website, with or without notice; charge fees in connection with the use of any Website; modify and/or waive any fees charged in connection with any Website; and/or offer opportunities to some or all users of any Website.
<G-vec00095-002-s415><modify.ändern><de> Der Verwahrer behält sich das Recht vor, den Zugang zu der Website und / oder zu den angebotenen Dienstleistungen zu verhindern, ein Account auszusetzen oder zu schließen, den Inhalt der Website im Ermessen des Verwahrers zu entfernen oder zu ändern, im Falle einer Verletzung der gesetzlichen Bestimmungen und dieser Allgemeine Bedingungen für die Lagerung.
<G-vec00095-002-s415><modify.ändern><en> The Depositary reserves the right to prevent the access to the site and / or to the service offered, to suspend or close an account, to remove or modify the contents of the site at the discretion of the Depositary himself, in case of a violation of applicable law and of these General Conditions of Deposit.
<G-vec00095-002-s416><modify.ändern><de> Falls Sie den Einsatz von Cookies ablehnen, bitten wir Sie, die entsprechenden Einstellungen Ihres Browsers zu ändern.
<G-vec00095-002-s416><modify.ändern><en> If you do not permit the use of cookies, we request that you modify the relevant settings on your browser.
<G-vec00095-002-s417><modify.ändern><de> Gemäß der Bestimmungen unserer Datenschutzrichtlinie gewähren Sie uns durch die Übermittlung oder Veröffentlichung einer Einreichung ein nicht exklusives, gebührenfreies, unbefristetes, übertragbares, unwiderrufliches und voll unterlizenzierbares Recht, jede Einreichung zu nutzen, zu reproduzieren, zu ändern, anzupassen, zu veröffentlichen, zu verkaufen, zuzuteilen, zu übersetzen, abgeleitete Werke davon zu erstellen, zu verteilen und in jeder Form oder jedem Medium, das heute bekannt ist oder in Zukunft noch entwickelt wird, allein oder als Teil anderer Arbeiten anzuzeigen.
<G-vec00095-002-s417><modify.ändern><en> Subject to the terms of our Privacy Policy, by transmitting or posting any Submission, you hereby grant us a nonexclusive, royalty-free, perpetual, transferable, irrevocable, and fully sub licensable right to use, reproduce, modify, adapt, publish, sell, assign, translate, create derivative works from, distribute and display any Submission in any form, media, or technology, whether now known or hereafter developed, alone or as part of other works.
<G-vec00095-002-s418><modify.ändern><de> Kindle Post erteilt Ihnen eine beschränkte Lizenz zum Zugriff auf diese Website und zu deren privater Nutzung, nicht aber dazu, die Website oder Teile davon herunterzuladen (abgesehen von der Zwischenspeicherung von Seiten) oder zu ändern, es sei denn mit der ausdrücklichen schriftlichen Zustimmung von Kindle Post.
<G-vec00095-002-s418><modify.ändern><en> Pet Heaven Memorial Park, Inc. grants you a limited license to access and make personal use of this site and not to download (other than page caching) or modify it, or any portion of it, except with express written consent of Pet Heaven Memorial Park, Inc.
<G-vec00095-002-s419><modify.ändern><de> Wir können nicht-persönliche Daten für jeden Zweck, einschließlich unserer eigenen internen Zwecken verwenden; um den Besucherstrom zu messen; Bevölkerungsstatistik, Kundeninteresse und andere Trends unserer Benutzern zu verstehen; um unsere Apps und Websites bereitzustellen, zu verbessern und zu ändern; und für Werbe- und Marketingzwecke.
<G-vec00095-002-s419><modify.ändern><en> We may use Non-Personal Information for any purpose, including for our own internal purposes; to measure traffic patterns; to understand demographics, customer interest, and other trends among our Users; to provide, improve and modify Apps and Sites; and for promotion and marketing purposes.
<G-vec00095-002-s420><modify.ändern><de> Citrix empfiehlt, Makros in Vorlagen nicht zu ändern.
<G-vec00095-002-s420><modify.ändern><en> Citrix recommends that you do not modify macros in templates.
<G-vec00095-002-s421><modify.ändern><de> Die Mitarbeiter haben das Recht, jede Inhaltsnachricht, die sie für unangemessen hält, zu bearbeiten, zu zensieren, zu löschen oder anderweitig zu ändern, ohne dass dem Urheber eine Warnung gegeben wird.
<G-vec00095-002-s421><modify.ändern><en> Staff have the right to edit, censor, delete or otherwise modify any content message they feel is inappropriate, without any warning given to the poster.
<G-vec00095-002-s423><modify.ändern><de> rn Der Anbieter behält sich das Recht vor, die Informationen seiner Internetseite sowie deren Erscheinung und Konfiguration jederzeit ohne Mitteilung an die Nutzer zu aktualisieren, zu ändern oder zu löschen, wobei er keinerlei Verantwortung für derartige Handlungen übernimmt.
<G-vec00095-002-s423><modify.ändern><en> The provider reserves the right to update, modify or eliminate the information contained in his website, as well as its configuration or presentation, at any given moment, without previous warning and without assuming any type of responsibility for doing so.
<G-vec00095-002-s424><modify.ändern><de> Sie sind jederzeit berechtigt, Ihre von FRISS gespeicherten personenbezogenen Daten kostenlos einzusehen und falls gewünscht zu ändern oder löschen zu lassen.
<G-vec00095-002-s424><modify.ändern><en> You can view your data that is processed by FRISS at any time and free of charge and, if you so wish, modify this data or have it deleted.
<G-vec00095-002-s425><modify.ändern><de> Puppet kann verschiedene Admin Aufgaben, wie beispielsweise das Anlegen eines Users, das Ändern von Konfigurationsdateien oder Softwareinstallationen auf ganz unterschiedlichen Servern durchführen, sogar wenn diese Server unterschiedliche Betriebssysteme ausführen.
<G-vec00095-002-s425><modify.ändern><en> Puppet is capable of various administrative tasks (eg. create users, modify configuration files or install software) on different servers even if these servers run on different operating systems.
<G-vec00095-002-s426><modify.ändern><de> Markieren Sie einen Titeleffekt auf der Titelspur und klicken Sie anschließend auf Ändern.
<G-vec00095-002-s426><modify.ändern><en> select a title effect in the Title Track and then click Modify.
<G-vec00095-002-s427><modify.ändern><de> Um den Filter in der aktuellen Ansicht anzuwenden, klicken Sie auf Ändern.
<G-vec00095-002-s427><modify.ändern><en> To apply the filter to the current view, click Modify.
<G-vec00095-002-s428><modify.ändern><de> Weitere Informationen zum Erstellen und Ändern von Ansichten finden Sie unter Erstellen, Ändern oder Löschen einer Ansicht.
<G-vec00095-002-s428><modify.ändern><en> For information about creating and modifying views, see Create, modify, or delete a view.
<G-vec00095-002-s429><modify.ändern><de> Der nächste Schritt beim Anlegen einer neuen E-Komponente besteht im Bearbeiten der Eigenschaften der E-Komponente, wofür über die Schaltfläche <Eigenschaften bearbeiten…> der Ändern–Dialog der Komponente aufgerufen wird.
<G-vec00095-002-s429><modify.ändern><en> The next step for creating a new E-component consists of editing its properties; for this purpose call the Modify dialog of the component via the button <Edit Properties...>.
<G-vec00095-002-s430><modify.ändern><de> Ändern Sie Ihre Rechnungs-, Versand- oder E-Mail-Adresse und ändern Sie Ihr Passwort.
<G-vec00095-002-s430><modify.ändern><en> Modify your billing, shipping or e-mail address and change your password
<G-vec00095-002-s431><modify.ändern><de> Weitere Informationen findest du unter Ändern der Einstellungen eines Projekts.
<G-vec00095-002-s431><modify.ändern><en> For more information, see Modify a project’s settings.
<G-vec00095-002-s432><modify.ändern><de> Klicken Sie auf Ändern, um weitere Änderungen an den Abschnitteigenschaften vorzunehmen.
<G-vec00095-002-s432><modify.ändern><en> Click Modify to further modify the section properties.
<G-vec00095-002-s433><modify.ändern><de> Klicken Sie im rechten Bereich mit der rechten Maustaste auf AnnounceFlags, und klicken Sie dann auf Ändern.
<G-vec00095-002-s433><modify.ändern><en> In the right pane, right-click AnnounceFlags, then click modify.
<G-vec00095-002-s434><modify.ändern><de> Ändern Sie die bestehende Büroumgebung, indem Sie WorkFit-S einfach an einer bereits vorhandenen Ablagefläche anbringen, und sparen Sie sich die Kosten für teure Montagearbeiten durch den Profi.
<G-vec00095-002-s434><modify.ändern><en> Modify existing office spaces or cubes by simply removing a section of worksurface and rolling in the sit-to-stand WorkFit, without the cost of expensive professional installers
<G-vec00095-002-s435><modify.ändern><de> PowerApps kann nicht zum Erstellen einer verbundenen Datenquelle oder zum Ändern deren Struktur verwendet werden; die Datenquelle muss bereits in einem Dienst vorhanden sein.
<G-vec00095-002-s435><modify.ändern><en> PowerApps can't be used to create a connected data source, or modify its structure; the data source must already exist in a service somewhere.
<G-vec00095-002-s436><modify.ändern><de> Zum Ändern eines benutzerdefinierten Buttons drücken Sie diesen länger als 1 Sekunde.
<G-vec00095-002-s436><modify.ändern><en> To modify a user-defined button, tap on it for more than 1 second.
<G-vec00095-002-s437><modify.ändern><de> Zum Einrichten oder Ändern der Einstellungen Ihrer Linksys Wireless-N Ethernet-Bridge, wird dieser Artikel die zwei (2) Methoden beim Zugriff auf deren Setup-Webseite diskutieren.
<G-vec00095-002-s437><modify.ändern><en> This article will discuss the two methods in accessing the Linksys Wireless-N Ethernet bridge's web-based setup page to set up or modify its settings.
<G-vec00095-002-s438><modify.ändern><de> Klicken Sie mit der rechten Maustaste auf ds-Server, und klicken Sie dann auf Ändern .
<G-vec00095-002-s438><modify.ändern><en> Right-click ds server, and then click Modify.
<G-vec00095-002-s439><modify.ändern><de> Wählen Sie Kopieren im Menü Ändern.
<G-vec00095-002-s439><modify.ändern><en> Choose Copy in the Modify menu.
<G-vec00095-002-s440><modify.ändern><de> Klicken Sie zum Ändern der Audio- und Untertiteleinstellungen beim Ansehen von Videos oben rechts auf „Einstellungen“.
<G-vec00095-002-s440><modify.ändern><en> Click "Settings" in the top-right corner to modify Audio and Subtitle settings when watching videos.
<G-vec00095-002-s441><modify.ändern><de> Ändern Sie einfach einige Ihrer Meldungseinstellungen oder deaktivieren Sie sie.
<G-vec00095-002-s441><modify.ändern><en> Just modify or disable some of your alerts set up in the Settings section.
<G-vec00095-002-s442><modify.ändern><de> Schritt 04 - Ändern Sie einfach alle Meine Dateien Standardeinstellungen zu anderen Orten, die spezifischer sind.
<G-vec00095-002-s442><modify.ändern><en> Step 04 - Simply modify All My Files default settings to other locations that are more specific.
<G-vec00095-002-s443><modify.ändern><de> Informationen zum Erstellen eines oder mehrerer benutzerdefinierter Layouts oder zum Ändern vorhandener Layouts finden Sie unter Erstellen eines neuen benutzerdefinierten Layouts.
<G-vec00095-002-s443><modify.ändern><en> To create one or more custom layouts or to modify existing layouts, see Create a new custom layout.
<G-vec00095-002-s444><modify.ändern><de> Ändern Sie die Gruppenmitgliedschaft des Benutzers in Active Directory.
<G-vec00095-002-s444><modify.ändern><en> Modify the user’s containing group membership in Active Directory.
<G-vec00095-002-s445><modify.ändern><de> Ändern Sie die Ansicht wie gewünscht.
<G-vec00095-002-s445><modify.ändern><en> Modify the view as required.
<G-vec00095-002-s446><modify.ändern><de> Ändern Sie 3D-Volumenkörper ganz einfach mithilfe Boolescher Operationen wie Union oder Substract und formen Sie die Kanten von 3D-Geometrien neu, indem Sie Verrundungskanten oder Fasenkanten mit unterschiedlichen Optionen verwenden.
<G-vec00095-002-s446><modify.ändern><en> Easily modify 3D solids using Boolean operations such as Union and Subtract, and reshape the edges of 3D geometries using Fillet Edges or Chamfer Edges with different options.
<G-vec00095-002-s447><modify.ändern><de> 4 Ändern Sie die Informationen entsprechend.
<G-vec00095-002-s447><modify.ändern><en> 4 Modify the information as appropriate.
<G-vec00095-002-s448><modify.ändern><de> Farbbearbeitung: Ändern Sie die Farben bestimmter Bereiche des Bildes.
<G-vec00095-002-s448><modify.ändern><en> Edit colors: modify the colors of certain areas of the image.
<G-vec00095-002-s449><modify.ändern><de> Ändern Sie Ressourcen in Echtzeit auf einem oder mehreren Geräten.
<G-vec00095-002-s449><modify.ändern><en> Modify resources in real-time on one device or more.
<G-vec00095-002-s450><modify.ändern><de> Ändern Sie auf der Seite XenMobile server Service Properties die URL-Zeichenfolge so, dass sie auf den XenMobile-Server verweist.
<G-vec00095-002-s450><modify.ändern><en> On the XenMobile server Service Properties page, modify the URL string to point to the XenMobile server.
<G-vec00095-002-s451><modify.ändern><de> Ändern Sie den HOSTNAME-Eintrag auf den neuen hostname des Gasts.
<G-vec00095-002-s451><modify.ändern><en> Modify the HOSTNAME entry to the guest's new hostname.
<G-vec00095-002-s452><modify.ändern><de> Ändern Sie den neuen Path-Eintrag so, dass er den Wert aufweist, den Sie im ersten Schritt notiert oder kopiert haben.
<G-vec00095-002-s452><modify.ändern><en> Modify the new Path entry so that it has the same value that you wrote down or copied in the first step.
<G-vec00095-002-s453><modify.ändern><de> Ändern Sie das Flex-Polygon Sie können eine benutzerdefinierte Form mit dem Flex-Polygon erstellen, das Sie unter "Formen" in Ihrer Toolbox finden.
<G-vec00095-002-s453><modify.ändern><en> Modify the Flex Polygon You can create a custom shape using the Flex Polygon, which you can find under "Shapes" in your toolbox.
<G-vec00095-002-s454><modify.ändern><de> Ändern Sie die Nummern für Zellenauffüllung und Zellenabstand wie nötig.
<G-vec00095-002-s454><modify.ändern><en> Modify the numbers for both cellPadding and cellSpacing as needed.
<G-vec00095-002-s455><modify.ändern><de> Ändern Sie die IP-Adresse und, sofern anwendbar, den Hostnamen in der /etc/inet/hosts-Datei oder der entsprechenden hosts-Datenbank.
<G-vec00095-002-s455><modify.ändern><en> Modify the IP address and, if applicable, the host name in the /etc/inet/hosts file or equivalent hosts database.
<G-vec00095-002-s456><modify.ändern><de> Ändern Sie zur Vermeidung dieses Problems die Outlook Web App-Datei "Web.config", nachdem Sie das Upgrade auf Exchange 2010 SP2 durchgeführt haben.
<G-vec00095-002-s456><modify.ändern><en> To avoid this problem, after you’ve completed the upgrade to Exchange 2010 SP2, modify the Outlook Web App web.config file.
<G-vec00095-002-s457><modify.ändern><de> Ändern Sie Bildhelligkeit und Kontrast, stellen Sie Schatten und hellste Bildteile mit dem 'Belichtung' Tool ein.
<G-vec00095-002-s457><modify.ändern><en> Modify image brightness and contrast, adjust shadows and highlights with the ‘Exposure’ tool.
<G-vec00095-002-s458><modify.ändern><de> Ändern Sie die Namen und die Reihenfolge der Spalten.
<G-vec00095-002-s458><modify.ändern><en> Modify the names and the order of the columns.
<G-vec00095-002-s459><modify.ändern><de> Ändern Sie alle Stäbe (Position, Farbe, Breite, Höhe, Deckkraft, Anker, Display) und die Möglichkeit, einen Stil unter 4 zu wählen (klassisch, verbessert (klassisch mit einem gewölbten Effekt), Vergessen (Schreiben) und schließlich gespenstisch).
<G-vec00095-002-s459><modify.ändern><en> Modify all bars (position, color, width, height, opacity, anchor, display) and possibility of choosing a style among 4 (classic, enhanced (classic with a domed effect), oblivion (writing), and finally ghostly).
<G-vec00095-002-s460><modify.ändern><de> Ändern Sie die Informationen zur Standortgrenze nach Bedarf im Eigenschaftendialogfeld der Grenze auf den Registerkarten Allgemein und Geschützt.
<G-vec00095-002-s460><modify.ändern><en> Modify the site boundary information as required on the boundary properties General and Protected tabs.
<G-vec00095-002-s461><modify.ändern><de> (Optional) Ändern Sie die Sicherheitseinstellungen auf dem lokalen Computer.
<G-vec00095-002-s461><modify.ändern><en> (Optional) Modify security settings on your local computer
<G-vec00095-002-s462><modify.ändern><de> 1.8 Ändern Sie den Text im Editor.
<G-vec00095-002-s462><modify.ändern><en> 1.8 Modify the text from the editor.
<G-vec00095-002-s501><modify.ändern><de> Sie können Ihre Daten auch in Eigeninitiative ändern, indem Sie die Seite „Profil bearbeiten“ aufrufen, die Sie im Hauptmenü unseres Mitgliederbereichs finden.
<G-vec00095-002-s501><modify.ändern><en> You may also choose to modify your data on your own initiative by using the ‘Edit Your Profile’ page which you will find in the main menu of our members’ area.
<G-vec00095-002-s502><modify.ändern><de> Klicken Sie in der rechten oberen Ecke der Seite auf Ihren Namen und wählen Sie Profil, um die Informationen einzusehen und zu ändern.
<G-vec00095-002-s502><modify.ändern><en> Click your name in the upper-right corner of the page, and then select Profile to access and modify the information.
<G-vec00095-002-s503><modify.ändern><de> Durch Klicken auf das Bundle können Sie die Bundle-Details anzeigen und ändern.
<G-vec00095-002-s503><modify.ändern><en> You can click the bundle to view and modify the bundle’s details.
<G-vec00095-002-s504><modify.ändern><de> Wir behalten uns außerdem das Recht vor, nicht bestätigte Konten oder Konten, die schon seit langer Zeit inaktiv waren zu storniern und LearnApe Websites, Dienstleistungen oder Werkzeuge einzustellen oder zu ändern.
<G-vec00095-002-s504><modify.ändern><en> We also reserve the right to cancel unconfirmed accounts or accounts that have been inactive for a long time, or to modify or discontinue LearnApe sites, services or tools.
<G-vec00095-002-s505><modify.ändern><de> Anwender, die über Hosted Security verfügen, können diese Regel bis auf die Systemgrenzwerte von maximal 100 Empfängern ändern.
<G-vec00095-002-s505><modify.ändern><en> Hosted Security (full version) customers may modify this rule up to the system limit of 100 recipients.
<G-vec00095-002-s506><modify.ändern><de> Die Firma Giochi Preziosi Germany GmbH behält sich das Recht vor diese Datenschutzerklärung unter Beachtung der geltenden gesetzlichen Datenschutzbestimmungen jederzeit zu ändern.
<G-vec00095-002-s506><modify.ändern><en> The company Fidlock GmbH reserves the right to modify this data protection statement at any time, taking into account the legally applicable regulations on data protection.
<G-vec00095-002-s507><modify.ändern><de> Sie hält sich das Recht vor, den Inhalt dieser Webseiten zu jeder Zeit und auf beliebige Art zu ändern, unabhängig vom Grund und ohne vorangehende Benachrichtigung.
<G-vec00095-002-s507><modify.ändern><en> It shall reserve the right to modify the contents of this website at any time and in any way, regardless of its reasons for doing so and without any prior notice.
<G-vec00095-002-s508><modify.ändern><de> Die Entführer wird auch Ihre Browser-Einstellungen ändern, indem Sie Ihre Homepage und Ihre Suchanbieter zu 30tab.com wechseln.
<G-vec00095-002-s508><modify.ändern><en> The hijacker will also modify your browser preferences by switching your home page and your search provider to 30tab.com.
<G-vec00095-002-s509><modify.ändern><de> Sie können unsere Software Contenta Converter PREMIUM verwenden, um die Beschreibung von tausenden von Fujifilm X100T Foto zu ändern.
<G-vec00095-002-s509><modify.ändern><en> You can use our software Contenta Converter PREMIUM to modify the workflow from thousands of Fujifilm X100T photo.
<G-vec00095-002-s510><modify.ändern><de> Sie können Ihre Bestellung ändern oder stornieren, solange diese noch nicht verschickt wurde.
<G-vec00095-002-s510><modify.ändern><en> Piaget allows you to modify or cancel your order until the order is sent.
<G-vec00095-002-s511><modify.ändern><de> Im Webshop können Sie Ihre persönlichen Daten jederzeit unter „Mein Benutzerkonto" überprüfen und ändern.
<G-vec00095-002-s511><modify.ändern><en> You can always check and modify your personal information at any time, in the “My account” section of the webshop.
<G-vec00095-002-s512><modify.ändern><de> Um Einträge zum Menü hinzuzufügen, können Sie entweder eine Datei namens /boot/grub/custom.cfg erstellen oder die Datei /etc/grub.d/50_custom ändern.
<G-vec00095-002-s512><modify.ändern><en> To add entries to the menu, you can either create a /boot/grub/custom.cfg file or modify the /etc/grub.d/50_custom file.
<G-vec00095-002-s513><modify.ändern><de> Wenn Sie die Dauer des Aufenthalts entgegen Ihrer ursprünglichen Buchung ändern möchten, müssen Sie die Unterkunft mindestens 48 Stunden im Voraus informieren.
<G-vec00095-002-s513><modify.ändern><en> Guests who wish to modify the length of stay on their original booking must notify the property at least 48 hours in advance.
<G-vec00095-002-s514><modify.ändern><de> Wir behalten uns vor, diese Datenschutzbestimmungen im Rahmen der geltenden Gesetze jederzeit zu ändern.
<G-vec00095-002-s514><modify.ändern><en> We reserve the right to modify these data privacy rules at any time within the limits set by applicable laws.
<G-vec00095-002-s515><modify.ändern><de> Der Anwender darf die Dienste von conworld nicht zweckentfremden oder ändern.
<G-vec00095-002-s515><modify.ändern><en> The user many not alter or modify conworld's services beyond their designated usage.
<G-vec00095-002-s516><modify.ändern><de> Motorsport.com kann diese Vereinbarung und die Richtlinien jederzeit und wie erforderlich ändern oder das Motorsport.com Mitgliedsprogramm (oder Teile davon) ganz oder zeitweilig ändern, aussetzen oder nicht weiterführen.
<G-vec00095-002-s516><modify.ändern><en> Motorsport.com, at any time and from time to time, may modify this Agreement and the Policies, or may modify, suspend or discontinue, temporarily or permanently, the Motorsport.com Membership Program (or any parts thereof).
<G-vec00095-002-s518><modify.ändern><de> Sofern sich Jesus.de oder die betreffenden Werbeinserenten nicht schriftlich damit einverstanden erklärt haben, dürfen Sie Werke, die auf den Dienste oder der Software beruhen, weder ganz noch teilweise ändern, vermieten, verleasen, verleihen, verkaufen, vertreiben oder umgestalten.
<G-vec00095-002-s518><modify.ändern><en> Except as expressly authorized by the Owners or advertisers, you agree not to modify, rent, lease, loan, sell, distribute or create derivative works based on the Service or the Software, in whole or in part.
<G-vec00095-002-s519><modify.ändern><de> Sie können Aufgaben aus der Bibliothek heraus ausführen, deaktivieren, ändern und löschen.
<G-vec00095-002-s519><modify.ändern><en> From within the library, you can run, disable, modify, and delete tasks.
<G-vec00095-002-s520><modify.ändern><de> Da der Browser ein wenig anders ist, schauen Sie im Hilfemenü Ihres Browsers nach, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s520><modify.ändern><en> Since browser is a little different, look at your browser’s Help Menu to learn the correct way to modify your cookies.
<G-vec00095-002-s521><modify.ändern><de> Da der Browser etwas anders ist, lesen Sie im Hilfe-Menü Ihres Browsers nach, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s521><modify.ändern><en> Since browser is a little different, look at your browser’s Help Menu to learn the correct way to modify your cookies.
<G-vec00095-002-s522><modify.ändern><de> Jeder Browser ist ein wenig anders, also schauen Sie sich das Hilfe-Menü Ihres Browsers an, um zu erfahren, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s522><modify.ändern><en> Each browser is a little different, so look at your browser's Help menu to learn the correct way to modify your cookies.
<G-vec00095-002-s523><modify.ändern><de> Da jeder Browser ein wenig anders ist, sehen Sie sich das Hilfemenü Ihres Browsers an, um zu erfahren, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s523><modify.ändern><en> Each browser is a little different, so look at your browser’s Help menu to learn the correct way to modify your cookies.
<G-vec00095-002-s524><modify.ändern><de> In der folgenden Anleitung wird in den ersten Schritten beschrieben, wie Sie ein vorhandenes Ausbringungsprojekt mithilfe der Benutzeroberfläche auswählen und überwachen können, während in den letzten Schritten erläutert wird, wie Sie dieses Ausbringungsprojekt durch Auswahl von Aktionen ändern können.
<G-vec00095-002-s524><modify.ändern><en> In the task below, the first few steps describe using the interface to select and monitor an existing deployment project, while the last steps describe selecting Actions to modify that deployment project.
<G-vec00095-002-s525><modify.ändern><de> Symbol „Eigenschaft“: Öffnet das Dialogfeld Neuer Active Directory-Container, in dem Sie einen Active Directory-Container in der Ermittlungsabfrageliste anzeigen oder ändern können.
<G-vec00095-002-s525><modify.ändern><en> Property icon: Opens the New Active Directory Container dialog box to view or modify a container in the discovery polling list.
<G-vec00095-002-s526><modify.ändern><de> Da der Browser ein wenig anders ist, sehen Sie im Hilfemenü Ihres Browsers nach, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s526><modify.ändern><en> Since each browser is a little different, look at your browser's Help Menu to learn the correct way to modify your cookies.
<G-vec00095-002-s527><modify.ändern><de> Auf der anderen Seite hat es ein geschichtetes Bearbeitungssystem, mit dem Sie jeden Abschnitt der Abbildung unabhängig voneinander ändern können.
<G-vec00095-002-s527><modify.ändern><en> On the other hand, it has a layered editing system with which you’ll modify each of the illustration’s sections independently.
<G-vec00095-002-s528><modify.ändern><de> Jeder Browser ist anders; sehen Sie sich deshalb das Hilfe-Menü Ihres Browsers an, um zu erfahren, wie Sie Ihre Cookies ändern können.
<G-vec00095-002-s528><modify.ändern><en> Each browser is a little different, so look at your browser Help menu to learn the correct way to modify your cookies.
<G-vec00095-002-s529><modify.ändern><de> Da jeder Browser ein wenig unterschiedlich funktioniert, lesen Sie im Hilfemenü Ihres Browsers nach, wie Sie Cookie-Einstellungen korrekt ändern können.
<G-vec00095-002-s529><modify.ändern><en> Since browser is a little different, look at your browser's Help Menu to learn the correct way to modify your cookies.
<G-vec00095-002-s530><modify.ändern><de> TweakIE9 ist ein einfaches Werkzeug, mit dem Sie einige der Optionen von IE9 mit nur wenigen Mausklicks ändern können.
<G-vec00095-002-s530><modify.ändern><en> TweakIE9 is a simple tool that will allow you to modify some of the options of IE9 with just a few clicks of the mouse.
<G-vec00095-002-s532><modify.ändern><de> Da der Browser ein wenig anders ist, schauen Sie im Hilfe Menü Ihres Browsers nach, um zu erfahren, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s532><modify.ändern><en> Since the browser is a little different, look at your browser’s Help Menu to learn the correct way to modify your cookies.
<G-vec00095-002-s533><modify.ändern><de> Beschreibung Zeigt das Dialogfeld „Außerbetriebnahme“ an, in dem Sie außer Betrieb zu nehmende Ereignisquellen hinzufügen oder ändern können.
<G-vec00095-002-s533><modify.ändern><en> Feature Description Displays the Decommission dialog in which you add or modify event sources to decommission.
<G-vec00095-002-s534><modify.ändern><de> Da jeder Browser anders ist, sollten Sie das Hilfsmenü des Browsers anklicken, um zu erfahren, wie Sie die Cookie-Einstellungen richtig ändern können.
<G-vec00095-002-s534><modify.ändern><en> Each browser is a little different, so look at your browser's Help menu to learn the correct way to modify your cookies.
<G-vec00095-002-s535><modify.ändern><de> Da der Browser etwas anders ist, sehen Sie im Hilfemenü Ihres Browsers nach, wie Sie Ihre Cookies richtig ändern können.
<G-vec00095-002-s535><modify.ändern><en> Since each browser is a little different, look at your browser's Help Menu to learn the correct way to modify your cookies.
<G-vec00095-002-s537><modify.ändern><de> Damit Benutzer ihre Antworten auf Fragen ändern können, können Sie die Schaltfläche „Alles senden“ verwenden.
<G-vec00095-002-s537><modify.ändern><en> To enable users to modify their choice for an answered question, you can use the Submit All button.
<G-vec00095-002-s538><modify.ändern><de> Unter Einstellen eines Seitenverhältnisses für einen Videoclip erfahren Sie, wie Sie das Seitenverhältnis für Ihr Medium ändern können.
<G-vec00095-002-s538><modify.ändern><en> To modify the aspect ratio for your media, see Adjusting Video Clip Aspect Ratio.
<G-vec00095-002-s539><modify.ändern><de> Klicken Sie auf oder ändern Sie seinen Namen mit Rechtsklick auf das Wert-Feld und bearbeiten Sie den Text.
<G-vec00095-002-s539><modify.ändern><en> Click on the or modify its name by right-clicking on the value field and editing the text.
<G-vec00095-002-s540><modify.ändern><de> Um die Farbe zu ändern, ändern Sie den Stil, der mit .task-Auswahl im Stylesheet verknüpft ist.
<G-vec00095-002-s540><modify.ändern><en> To change its color, modify the style associated with .task selector in the Asia - Pacific
<G-vec00095-002-s541><modify.ändern><de> Platzieren und ändern Sie Orders direkt aus dem Chart heraus.
<G-vec00095-002-s541><modify.ändern><en> Place and modify orders directly from a chart window.
<G-vec00095-002-s542><modify.ändern><de> Klicken Sie dann auf den Button E-mail, um den übersetzten Text via E-mail zu senden, oder ändern Sie den zu übersetzenden Text, bevor Sie ihn senden.
<G-vec00095-002-s542><modify.ändern><en> Then click the E-mail button to send the translated text by e-mail, or modify the text directly before sending.
<G-vec00095-002-s543><modify.ändern><de> Mit folgenden Schritten erstellen oder ändern Sie die Konfiguration eines Administrations-Image von Autodesk Inventor 2010 mit Autodesk Inventor 2010 Subscription Advantage Pack Service Pack 3.
<G-vec00095-002-s543><modify.ändern><en> The following are steps to create/modify an administrative image configuration of Autodesk Inventor 2010 with Autodesk Inventor 2010 Subscription Advantage Pack Service Pack 3.
<G-vec00095-002-s544><modify.ändern><de> Zum Ändern der RD CAP klicken Sie im Ergebnisbereich in der Liste der RD CAPs mit der rechten Maustaste auf die RD CAP, klicken Sie auf Eigenschaften, ändern Sie die Einstellungen nach Bedarf, und klicken Sie dann auf OK.
<G-vec00095-002-s544><modify.ändern><en> To modify the RD CAP, in the results pane, in the list of RD CAPs, right-click the RD CAP, click Properties, modify settings as needed, and then click OK.
<G-vec00095-002-s545><modify.ändern><de> – Verwalten von Warenrücksendungen: Genehmigen oder schließen Sie Warenrücksendungen, nehmen Sie Erstattungen vor und ändern Sie die Rücksendungseinstellungen.
<G-vec00095-002-s545><modify.ändern><en> - Manage your returns. Authorize or close returns, issue refunds, and modify returns settings.
<G-vec00095-002-s546><modify.ändern><de> (Optional) Geben Sie im Dialogfeld „Musteroptionen“ einen neuen Namen für das Muster ein oder ändern Sie den vorhandenen Namen.
<G-vec00095-002-s546><modify.ändern><en> (Optional) In the Pattern Options dialog, provide a new name for the pattern, or modify the existing name.
<G-vec00095-002-s547><modify.ändern><de> Wenn Sie jedoch noch weitere Daten ausschließen möchten, die Sie bereits in den Speicher migriert haben, ändern Sie die Datei Config.xml und geben die aktualisierte Datei beim Befehl LoadState an.
<G-vec00095-002-s547><modify.ändern><en> However, if you want to exclude additional data that you migrated to the store, modify the Config.xml file and specify the updated file with the LoadState command.
<G-vec00095-002-s548><modify.ändern><de> Um dieses Problem zu beheben, ändern Sie die Berechtigungen des Benutzerobjekts ab, sodass das Objekt die Berechtigungen vom übergeordneten Objekt erbt.
<G-vec00095-002-s548><modify.ändern><en> To resolve this issue, modify the user object permissions to inherit permissions from the object’s parent.
<G-vec00095-002-s549><modify.ändern><de> Sobald Sie die Lichteinstellungen an die Lichtverhältnisse angepasst haben, unter denen Sie das reale Material betrachten, ändern Sie die Materialeinstellungen, bis das digitale Material aussieht und sich verhält wie das reale Material.
<G-vec00095-002-s549><modify.ändern><en> Once you set the light settings to the lighting conditions under which you are looking at the real material, modify the material settings until the digital material looks and behaves like the real material.
<G-vec00095-002-s550><modify.ändern><de> Überprüfen und ändern Sie die Tage oder Stunden, die für die Zertifizierungsstellenzertifikate, Zertifikatsperrlisten und Deltazertifikatsperrlisten aufgeführt sind.
<G-vec00095-002-s550><modify.ändern><en> Review and modify the days or hours listed for the CA certificate, CRLs, and delta CRLs.
<G-vec00095-002-s551><modify.ändern><de> Sigil - Erstellen, Bearbeiten und ändern Sie ebooks in ePub-Format.
<G-vec00095-002-s551><modify.ändern><en> Sigil - Create, edit, and modify ebooks in ePub format.
<G-vec00095-002-s552><modify.ändern><de> Kopieren, übertragen und ändern Sie Daten auf und zwischen NTFS- und HFS+-Laufwerken.
<G-vec00095-002-s552><modify.ändern><en> Easily copy, transfer and modify data on NTFS volumes alongside with HFS+ ones.
<G-vec00095-002-s553><modify.ändern><de> Wenn Sie möchten, dass ein E-Commerce-Workflow unterschiedliche Registrierungsauslöser hat, kopieren Sie den Workflow und ändern Sie die Registrierungsauslöser im geklonten Workflow.
<G-vec00095-002-s553><modify.ändern><en> If you want an ecommerce workflow to have different enrollment triggers, clone the workflow and modify the enrollment triggers in the cloned workflow.
<G-vec00095-002-s554><modify.ändern><de> Um eine Kampagne zu protokollieren, ändern Sie die Registrierungs-URL der Veranstaltung.
<G-vec00095-002-s554><modify.ändern><en> To track a campaign, modify the registration URL for the event.
<G-vec00095-002-s555><modify.ändern><de> Klicken Sie auf Einstellungen → Nebenstelle hinzufügen/ändern und ändern Sie den Eintrag „Gleichzeitige Registrierungen“.
<G-vec00095-002-s555><modify.ändern><en> Click Settings → Add/Edit Extension, and modify Concurrent Registrations.
<G-vec00095-002-s556><modify.ändern><de> Steigern Sie die Leistung, Beschleunigung, Höchstgeschwindigkeit und ändern Sie das Aussehen des Autos.
<G-vec00095-002-s556><modify.ändern><en> Increases the power, acceleration, top speed and modify the appearance of the car.
<G-vec00095-002-s557><modify.ändern><de> Das Plugin ändert die Miniaturbilder und lädt die Seite neu.
<G-vec00095-002-s557><modify.ändern><en> The plugin will modify the image thumbnails and reload the page.
<G-vec00095-002-s558><modify.ändern><de> Es funktioniert im Nur-Lese-Modus und ändert oder beschädigt dein ursprüngliches Word-Dokument nicht.
<G-vec00095-002-s558><modify.ändern><en> It works in read only mode and doesn’t modify or harm your original Word document.
<G-vec00095-002-s559><modify.ändern><de> Es ist völlig zerstörungsfrei in der Natur und ändert oder beschädigt nicht das ursprüngliche Worddokument und erzeugt eine neue gesunde Word Datei, indem alle seine Attribute wiederhergestellt werden.
<G-vec00095-002-s559><modify.ändern><en> It is completely non-destructive in nature and does not modify or damage the original Word document and creates a fresh healthy Word file by recovering all its attributes.
<G-vec00095-002-s560><modify.ändern><de> CCC kopiert nur ein Volume zur Zeit, und CCC ändert nicht die Partitionierung auf dem Zielvolume.
<G-vec00095-002-s560><modify.ändern><en> No, CCC will copy only one volume at a time, and CCC will not modify the partitioning of the destination disk.
<G-vec00095-002-s561><modify.ändern><de> Die Wahl des ehelichen Güterstandes hat keine Auswirkungen auf die Erbfolge, da sie die gesetzliche Erbfolge nicht ändert.
<G-vec00095-002-s561><modify.ändern><en> The choice of matrimonial arrangement has no bearing on estates, in the sense that it does not modify the legal order of successions.
<G-vec00095-002-s562><modify.ändern><de> Der Routing Daemon ändert automatisch die Routing Table, um sie an Änderungen im Netzwerk anzupassen.
<G-vec00095-002-s562><modify.ändern><en> The dynamic routing daemon will automatically modify your routing table to adjust to changes in your network.
<G-vec00095-002-s563><modify.ändern><de> Anmerkung: Das Bearbeiten des Bezugssystems im Roboter Panel ändert die Position des ausgewählten/aktiven Bezugssystem.
<G-vec00095-002-s563><modify.ändern><en> Note: Modifying the Reference Frame in the robot panel will modify the position of the selected/active Reference Frame.
<G-vec00095-002-s564><modify.ändern><de> Es kann passieren, dass VisaHQ.de von Zeit zu Zeit seine Nutzungsbedingungen ändert.
<G-vec00095-002-s564><modify.ändern><en> From time to time, VisaHQ.ca may modify these Terms & Conditions.
<G-vec00095-002-s565><modify.ändern><de> 5.6 Der Nutzer nimmt zur Kenntnis und berechtigt den Anbieter dazu, dass der Anbieter möglicherweise die vom Nutzer zur Verfügung gestellten Inhalte in dem für die Bereitstellung des ARRI Webgates erforderlichen Umfang verwendet, ändert, kopiert, vertreibt und veröffentlicht, jedoch nur, um diesen Nutzungsvertrag oder sonstige zwischen dem Nutzer und dem Anbieter bestehende Verträge zu erfüllen.
<G-vec00095-002-s565><modify.ändern><en> 5.6 The User acknowledges the fact, and authorises the Provider to use, modify, copy, distribute and render public any contents made available by the User to the extent necessary for the preparation of the ARRI Webgate, but only in order to comply with this User Agreement or other agreements in existence between the User and the Provider.
<G-vec00095-002-s566><modify.ändern><de> Der Befehl LISTBOX SET ROW HEIGHT ändert die Höhe der angegebenen Zeile in der Listbox, definiert durch die Parameter Objekt und *.
<G-vec00095-002-s566><modify.ändern><en> The LISTBOX SET ROW HEIGHT command allows you to modify the height of the specified row in the list box object designated using the object and * parameters.
<G-vec00095-002-s567><modify.ändern><de> Mit anderen Worten, die Suchmaschine betrachtet es als eine vorübergehende Änderung Ihrer Website und ändert ihren Index nicht entsprechend.
<G-vec00095-002-s567><modify.ändern><en> In other words, the search engine considers it to be a temporary modification of your site and does not modify its index accordingly.
<G-vec00095-002-s568><modify.ändern><de> Ein SEM-Manager weiß in der Regel, dass ein bestimmtes Produkt ausverkauft ist und ändert seine Keywords und Kampagnen im Voraus.
<G-vec00095-002-s568><modify.ändern><en> An SEM manager usually knows that a product is sold out and can modify its keywords and campaigns in advance.
<G-vec00095-002-s569><modify.ändern><de> Die allgemeinste knackende Methode ist, das Steuersignal auf der geteilten LadegerätLeiterplatte zu ändern und ändert die Stifte, um den Effekt des Beginnens des Aufladungsservices zu erzielen, ohne den Server durchzulaufen.
<G-vec00095-002-s569><modify.ändern><en> The most common cracking method is to modify the control signal on the shared charger circuit board, and modify the pins to achieve the effect of starting the charging service without going through the server.
<G-vec00095-002-s570><modify.ändern><de> Wenn der Rat innerhalb von 24 Stunden ab der Übermittlung des Abwicklungskonzepts durch den Ausschuss den Vorschlag der Kommission zur Änderung des Abwicklungskonzepts aus den in Unterabsatz 3 Buchstabe b genannten Gründen gebilligt hat oder wenn die Kommission gemäß Unterabsatz 2 Einwände erhoben hat, ändert der Ausschuss das Abwicklungskonzept innerhalb von acht Stunden nach Maßgabe der angegebenen Gründe.
<G-vec00095-002-s570><modify.ändern><en> Where, within 24 hours from the transmission of the resolution scheme by the Board, the Council has approved the proposal of the Commission for modification of the resolution scheme on the ground referred to in point (b) of the third subparagraph or the Commission has objected in accordance with the second subparagraph, the Board shall, within eight hours modify the resolution scheme in accordance with the reasons expressed.
<G-vec00095-002-s571><modify.ändern><de> Es ändert nicht Ihre Sucherakten auf der Scheibe.
<G-vec00095-002-s571><modify.ändern><en> It does not modify your Finder files on the disk.
<G-vec00095-002-s572><modify.ändern><de> Ungeachtet des Vorstehenden ersetzt oder ändert nichts von dem, was in dieser Lizenz enthalten ist, die Bedingungen einer separaten Lizenzvereinbarung, die Sie möglicherweise mit dem Lizenzgeber für solche Beiträge abgeschlossen haben.
<G-vec00095-002-s572><modify.ändern><en> Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions. 6. Trademarks.
<G-vec00095-002-s573><modify.ändern><de> Diese Garantie beeinträchtigt oder ändert keinerlei Garantie, die von Lowepro-Vertriebspartnern eingeräumt wird und gilt zusätzlich zu Ihren gesetzlich verankerten Rechten und Rechtsmitteln, die sie ebenfalls nicht berührt.
<G-vec00095-002-s573><modify.ändern><en> This warranty does not affect or modify any warranty provided by the Lowepro retailer nor does it affect any additional rights you may have under the laws of your jurisdiction.
<G-vec00095-002-s574><modify.ändern><de> Es ändert oder ändert nicht die ursprüngliche PowerPoint-Datei, während sie es repariert, da es nur die Elemente aus der beschädigten PowerPoint-Datei extrahiert und eine gesunde Datei erstellt.
<G-vec00095-002-s574><modify.ändern><en> It does not modify or alter original PowerPoint file while repairing it as it just extracts the elements from corrupted PowerPoint file and creates a healthy file.
<G-vec00095-002-s575><modify.ändern><de> Beispielsweise kann CHKDSK melden, dass ein Datenträger beschädigt ist, wenn NTFS zufällig aufgrund von Programmvorgängen Bereiche des Datenträgers ändert, den CHKDSK gerade untersucht.
<G-vec00095-002-s575><modify.ändern><en> For example, CHKDSK may report disk corruption if NTFS happens to modify areas of a disk while CHKDSK is examining the disk.
<G-vec00095-002-s055><revise.ändern><de> Diese Nutzungsbedingungen können nach unserem alleinigen Ermessen gelegentlich geändert und aktualisiert werden.
<G-vec00095-002-s055><revise.ändern><en> We may revise and update these Terms of Use from time to time at our sole discretion.
<G-vec00095-002-s137><revise.ändern><de> Die in dieser Pressemitteilung enthaltenen zukunftsgerichteten Aussagen beziehen sich auf das Datum dieser Pressemitteilung, und Yield Growth lehnt ausdrücklich jede Verpflichtung ab, Aussagen, die zukunftsgerichtete Informationen enthalten, oder die ihnen zugrunde liegenden Faktoren oder Annahmen zu aktualisieren oder zu ändern, sei es als Ergebnis neuer Informationen, zukünftiger Ereignisse oder anderweitig, es sei denn, dies ist gesetzlich vorgeschrieben.
<G-vec00095-002-s137><revise.ändern><en> Except as required by law, the Corporation disclaims any intention and assumes no obligation to update or revise any forward-looking statements to reflect actual results, whether as a result of new information, future events, changes in assumptions, changes in factors affecting such forward-looking statements or otherwise. Share
<G-vec00095-002-s138><revise.ändern><de> iWebCustom behält sich vor, diese Bestimmungen jederzeit und ohne Ankündigung zu ändern.
<G-vec00095-002-s138><revise.ändern><en> Fastreliablewebhosting.com may revise these terms of use for its web site at any time without notice.
<G-vec00095-002-s191><revise.ändern><de> Architecture Center Ltd kann diese Nutzungsbedingungen für seine Website jederzeit ohne vorherige Ankündigung ändern.
<G-vec00095-002-s191><revise.ändern><en> ChatBox.net may revise these terms of use for its web site at any time without notice.
<G-vec00095-002-s192><revise.ändern><de> Die Jocyco AB kann diese Allgemeinen Geschäftsbedingungen für ihre Website jederzeit und ohne Vorankündigung ändern.
<G-vec00095-002-s192><revise.ändern><en> Modifications BaoGuide Ltd. may revise these terms of service for its website at any time without notice.
<G-vec00095-002-s193><revise.ändern><de> Benchmark darf die Bedingungen, sowie jegliche Geschäftspolitik, die auf der Webseite oder den Unter-Webseiten bekanntgemacht wird, ändern.
<G-vec00095-002-s193><revise.ändern><en> Benchmark may revise these Terms as well as any operating policies that we may post on this website or sub-sites.
<G-vec00095-002-s194><revise.ändern><de> Wenn wir diese Mitteilung aktualisieren, werden wir das Datum der "letzten Aktualisierung" oben in der Mitteilung ändern.
<G-vec00095-002-s194><revise.ändern><en> When we update this Notice, we will revise the 'Last Update' date at the top of the Notice.
<G-vec00095-002-s195><revise.ändern><de> Royal FloraHolland behält sich das Recht vor, diese Cookie-Erklärung zu ändern.
<G-vec00095-002-s195><revise.ändern><en> Royal FloraHolland retains the right to revise this Cookie Statement.
<G-vec00095-002-s196><revise.ändern><de> Wir können die Preise für das Spiel oder damit verbundene Gegenstände jederzeit ändern.
<G-vec00095-002-s196><revise.ändern><en> We may revise the pricing for the Game or any item associated therewith at any time.
<G-vec00095-002-s197><revise.ändern><de> BlackStone kann diese Nutzungsbedingungen für seine Website jederzeit ohne vorherige Ankündigung ändern.
<G-vec00095-002-s197><revise.ändern><en> Washington Retail Association may revise these terms of service for its website at any time without notice.
<G-vec00095-002-s198><revise.ändern><de> Cardinal Health kann diese Bedingungen jederzeit durch Aktualisierung dieser Webseite ändern.
<G-vec00095-002-s198><revise.ändern><en> Cardinal Health may revise these Terms at any time by updating this posting.
<G-vec00095-002-s199><revise.ändern><de> Delta behält sich das Recht vor, die Allgemeinen Geschäftsbedingungen ohne vorherige Ankündigung zu ändern.
<G-vec00095-002-s199><revise.ändern><en> Delta reserves the right to revise terms and conditions at any time without notice.
<G-vec00095-002-s200><revise.ändern><de> DELTA ist berechtigt, diese Nutzungsbedingungen nach eigenem Ermessen jederzeit zu ändern und/oder zu aktualisieren.
<G-vec00095-002-s200><revise.ändern><en> Studycouch may revise these terms of use for its web site at any time without notice.
<G-vec00095-002-s201><revise.ändern><de> DENTSPLY DETREY kann jederzeit Inhalte der Site, einschließlich der Nutzungsbedingungen, durch eine Aktualisierung dieser Bekanntmachung ändern.
<G-vec00095-002-s201><revise.ändern><en> DENTSPLY International may at any time revise or delete the contents of the site, including these Terms and Conditions by updating this posting.
<G-vec00095-002-s202><revise.ändern><de> Bei Änderungen dieser Datenschutzerklärung oder wesentlichen Änderungen der Verwendung Ihrer personenbezogenen Daten überarbeiten wir diese Datenschutzerklärung jeweils entsprechend und ändern auch das Datum des Inkrafttretens, das Sie am Ende dieses Abschnitts finden.
<G-vec00095-002-s202><revise.ändern><en> If we make changes to this Privacy Statement or make any material changes to how we use your Personal Information, we will revise this Privacy Statement to reflect such changes and revise the statement's effective date, included at the end of this Privacy Statement.
<G-vec00095-002-s203><revise.ändern><de> Die Vorgangsart, die sich darauf auswirkt, wie ein Terminplan geändert wird, falls Sie die vorhandene Zuordnung ändern.
<G-vec00095-002-s203><revise.ändern><en> The task type, which affects how a schedule changes if you revise the existing assignment.
<G-vec00095-002-s204><revise.ändern><de> Sneaky Cards kann die Nutzungsbedingungen seiner Website jederzeit und ohne Vorankündigung ändern.
<G-vec00095-002-s204><revise.ändern><en> Yogitantra may revise these terms of use for its web site at any time without notice.
<G-vec00095-002-s205><revise.ändern><de> Wir behalten uns das Recht vor, diese Datenschutzrichtlinie jederzeit und ohne Mitteilung zu ändern.
<G-vec00095-002-s205><revise.ändern><en> We reserve the right to revise this Privacy Policy at any time without notice.
<G-vec00095-002-s206><revise.ändern><de> Allgeier Productivity Solutions kann diese Bedingungen durch Aktualisierung des vorliegenden Textes jederzeit ändern.
<G-vec00095-002-s206><revise.ändern><en> ISEQUALTO may at any time revise these terms by updating this posting.
<G-vec00095-002-s207><revise.ändern><de> Wir können diese Allgemeinen Geschäftsbedingungen von Zeit zu Zeit ändern.
<G-vec00095-002-s207><revise.ändern><en> We may revise these general conditions from time to time.
<G-vec00095-002-s208><revise.ändern><de> Die Sigmapharm GesmbH kann diese Bestimmungen und Bedingungen durch Aktualisierung dieser Bekanntmachung jederzeit ändern.
<G-vec00095-002-s208><revise.ändern><en> The Villages Lifelong Learning College may at any time revise these Terms and Conditions by updating this posting.
<G-vec00095-002-s209><revise.ändern><de> Mental Home behält sich das Recht vor, jederzeit nach eigenem Ermessen Teile dieser Nutzungsbedingungen zu ändern, zu modifizieren, zu ergänzen oder zu entfernen, indem wir eine neue Version online stellen.
<G-vec00095-002-s209><revise.ändern><en> Madrabbit reserves the right, in its sole discretion, to modify or revise these Terms at any time, and you agree to be bound by such modifications or revisions.
<G-vec00095-002-s210><revise.ändern><de> Der Rat prüft auf Vorschlag der Kommission fünf Jahre nach dem in Artikel 70 Absatz 2 bezeichneten Zeitpunkt unter Berücksichtigung der bei der Anwendung dieser Richtlinie gesammelten Erfahrungen und insbesondere der Ziele einer größeren Transparenz und Harmonisierung alle Bestimmungen dieser Richtlinie, die den Mitgliedstaaten eine Wahlfreiheit einräumen, und ändert sie erforderlichenfalls.
<G-vec00095-002-s210><revise.ändern><en> Five years after the date referred to in Article 70 (2) the Council, acting on a proposal from the Commission, shall examine and if need be revise all those provisions of this Directive which provide for Member State options in the light of the experience acquired in applying this Directive and in particular of the aims of greater transparency and harmonization of the provisions referred to by this Directive.
<G-vec00095-002-s211><revise.ändern><de> (2) Der Rat prüft auf Vorschlag der Kommission alle fünf Jahre die in Europäischen Rechnungseinheiten ausgedrückten Beträge dieser Richtlinie unter Berücksichtigung der wirtschaftlichen und monetären Entwicklung in der Gemeinschaft und ändert diese Beträge gegebenenfalls.
<G-vec00095-002-s211><revise.ändern><en> 2. Every five years the Council, acting on a proposal from the Commission, shall examine and, if need be, revise the amounts expressed in European units of account in this Directive, in the light of economic and monetary trends in the Community.
<G-vec00095-002-s746><transform.ändern><de> Color-Grading ermöglicht es Ihnen, die Stimmung Ihrer Aufnahmen zu ändern, die Aufmerksamkeit auf einzelne Szenen oder Objekte zu lenken, Korrekturen am Farbton und der Helligkeit vorzunehmen und vieles mehr.
<G-vec00095-002-s746><transform.ändern><en> Color Grading empowers you to transform the feel of your footage, draw focus to scenes or subjects, make corrections to the hue and brightness of your clips, and more.
<G-vec00095-002-s747><transform.ändern><de> Sicherlich wirst du deinen Körper nicht über Nacht ändern.
<G-vec00095-002-s747><transform.ändern><en> Naturally, you’re not going to transform your body overnight.
<G-vec00095-002-s748><transform.ändern><de> Mir wurde klar: Wenn ich mich ändern will, darf ich mich nicht mehr mit Leuten abgeben, die einen schlechten Einfluss auf mich haben.
<G-vec00095-002-s748><transform.ändern><en> I realized that if I wanted to transform my personality, I needed to stop associating with people who had a negative influence on me.
<G-vec00095-002-s749><transform.ändern><de> Clips, die Sie auf die Zeitachse legen, sind unter dem Ansichtsfenster sichtbar, von wo aus Sie ihre Position, Skalierung oder Rotationseigenschaften schnell ändern können.
<G-vec00095-002-s749><transform.ändern><en> Clips that you put on the timeline are visible under the Viewer Panel, from where you can quickly transform their position, scale, or rotation properties.
<G-vec00095-002-s750><transform.ändern><de> Das Festival Visualia 2015 stellt sich den Besuchern von 07. bis 09.05.2015 in Pula an verschiedenen Standorten im engeren Stadtzentrum dar, und begleitende Welttrends im Gebiet audiovisuelle Kunst bringen nach Pula neue Lichtinstallationen, interaktive Performance, Ausstellungen und 3D Video Mappings, und werden mit ihrem neuen Konzept visuelle Identität der Stadt, die die in- und ausländische Besucher während der Festivaldauer 3 Tage genießen können, komplett ändern.
<G-vec00095-002-s750><transform.ändern><en> Visualia Festival 2015 presents itself to visitors from May 7 – 9, 2015 at various locations in the very heart of Pula. Keeping up with the latest trends in audiovisual art, the Festival brings to Pula new lighting installations, interactive performances and 3D video mapping; with its new concept it will completely transform the city’s visual identity, a sight that all visitors will surely appreciate and enjoy during the 3 festival days.
<G-vec00095-002-s751><transform.ändern><de> Ein Promoter räumt AGORA eine beschränkte Lizenz ein, veröffentliche Inhalte zu reproduzieren und zu übertragen und erteilt die Erlaubnis, Inhalte hinzuzufügen oder zu ändern, damit diese den technischen Anforderungen der AGORA-Website entsprechen.
<G-vec00095-002-s751><transform.ändern><en> The promoter gives AGORA limited license to reproduce and transmit the published content through the AGORA website, and to add information and transform in order to comply with technical requirements of AGORA’s website.
<G-vec00095-002-s752><transform.ändern><de> Beschreibung Transparente Socken mit schwarzen gestreiften Socken, die deinen Alltagslook ändern will.
<G-vec00095-002-s752><transform.ändern><en> Description Transparent socks with black striped patterns, which will transform your daily look.
<G-vec00095-002-s753><transform.ändern><de> Das richtige Licht kann ganze Räume ändern.
<G-vec00095-002-s753><transform.ändern><en> The right light can transform entire rooms.
<G-vec00095-002-s754><transform.ändern><de> Um die riesige Nachfrage nach dem neuen MINI zu bewältigen, hat die BMW Gruppe Fachleute für die Auftragsfertigung angestellt, um die Kultur ihrer Produktionsstätte in Oxford zu ändern.
<G-vec00095-002-s754><transform.ändern><en> To cope with the huge demand for the new MINI, BMW Group employed contract manufacturing professionals to transform the culture of its production plant in Oxford.
<G-vec00095-002-s755><transform.ändern><de> Metabolische Rate ist die Behandlung, die Ihren Körper absorbiert das Essen zu ändern, die Sie direkt in Energie essen.
<G-vec00095-002-s755><transform.ändern><en> Metabolic rate is the procedure that absorbs your body to transform the food that you consume right into energy.
<G-vec00095-002-s756><transform.ändern><de> Ohne soziale Medien befänden wir uns immer noch im Millennium-Hype, als jeder geglaubt hat, das Internet sei eine riesengroße Sache und würde unser Leben vollständig ändern, was es aber nicht tat.
<G-vec00095-002-s756><transform.ändern><en> Without social media we would still be in the millennium hype, where everyone thought that the Internet was a huge thing and would completely transform our lives, which it did not.
<G-vec00095-002-s757><transform.ändern><de> Die italienische Landwirtschaft muss ihre Verfahrensweisen radikal ändern, um die kriegsbedingte Krise zu überwinden.
<G-vec00095-002-s757><transform.ändern><en> Italian agriculture must radically transform its operations to exit from the crisis caused by the war.
<G-vec00095-002-s758><transform.ändern><de> Um unter diesen neuen Marktbedingungen wettbewerbsfähig zu sein, müssen Unternehmen ihre Geschäftspraktiken ändern und neue Technologien einführen.
<G-vec00095-002-s758><transform.ändern><en> To compete in these new market conditions, organizations need to transform their business practices and adopt new technologies.
<G-vec00095-002-s759><transform.ändern><de> Wenn Sie zuversichtlich sind, wie Sie aussehen, Sie fühle mich großartig, Ihr Selbstvertrauen wird gestärkt und Sie können wirklich Ihre gesamte Wahrnehmung von sich selbst ändern.
<G-vec00095-002-s759><transform.ändern><en> When you are certain regarding just how you look, you really feel excellent, your self confidence is boosted and you can really transform your general understanding of yourself.
<G-vec00095-002-s760><transform.ändern><de> Und gerade Chatbots zählen zu den neuen Technologien, die im Stande sind, Kundenerfahrungen komplett zu ändern.
<G-vec00095-002-s760><transform.ändern><en> And it is precisely the chatbot that is one of the new technologies that could completely transform the customer experience.
<G-vec00095-002-s437><vary.ändern><de> Es ist wichtig, zu betonen, dass die gegebene Beschreibung Allgemeines ist und kann sich je nach dem konkreten Geschäft ändern.
<G-vec00095-002-s437><vary.ändern><en> It is important to emphasize that this description is general and can vary depending on the particular transaction.
<G-vec00095-002-s438><vary.ändern><de> Das Layout mag sich dann ändern, aber die Bedienung erfolgt immer über die gleichen grauen Buttons, und es genügt, wenn Sie sich bei irgendeiner dieser Homepages anmelden.
<G-vec00095-002-s438><vary.ändern><en> The layout may vary, but operation is throughout done with the same grey buttons. Moreover it will do to register on any of these sites, to use them all.
<G-vec00095-002-s439><vary.ändern><de> In Folgejahren wird sich die Differenz mit dem Anstieg der Höhe des an den offenen Pensionsfonds überwiesenen Beitrags ändern.
<G-vec00095-002-s439><vary.ändern><en> In subsequent years, the difference will vary with the increase in the amount of contributions transferred to Open Pension Funds.
<G-vec00095-002-s440><vary.ändern><de> Im Preis sind alle Gebühren des Hotels enthalten, allerdings können sich die Gebühren zum Beispiel je nach Länge des Aufenthalts oder des gebuchten Zimmers ändern.
<G-vec00095-002-s440><vary.ändern><en> We have included all charges provided to us by this hotel. However, charges can vary, for example, based on length of stay or feedback
<G-vec00095-002-s441><vary.ändern><de> Unsere Preise sowie der Ihnen verrechnete Versandkostenanteil können sich von Zeit zu Zeit ändern.
<G-vec00095-002-s441><vary.ändern><en> Our prices and the share of mailing costs we invoice you with may vary from time to time.
<G-vec00095-002-s442><vary.ändern><de> Die Stornierung- und Vorauszahlungsbedingungen können sich je nach Zimmerkategorie ändern.
<G-vec00095-002-s442><vary.ändern><en> Cancellation and prepayment conditions may vary depending on the type of room.
<G-vec00095-002-s443><vary.ändern><de> Geschäftsgebiet Unsere Geschäftsgebiete sind abhängig der Reichweite unserer Partner und können sich unter Umständen ändern.
<G-vec00095-002-s443><vary.ändern><en> Our service regions are subject to the range of our partners and may vary under circumstances.
<G-vec00095-002-s444><vary.ändern><de> Die Reihenfolge der Übungen kann sich in Abhängigkeit der Gegebenheiten ändern.
<G-vec00095-002-s444><vary.ändern><en> The order of the exercises can vary due to the conditions.
<G-vec00095-002-s445><vary.ändern><de> Die Funktionen können sich auch im Verlauf eines Investments ändern.
<G-vec00095-002-s445><vary.ändern><en> The roles can vary over the course of an investment.
<G-vec00095-002-s446><vary.ändern><de> Die Wetter- und Seeverhältnisse können sich mitunter schlagartig ändern, sind häufig strapaziös und immer für eine Überraschung gut.
<G-vec00095-002-s446><vary.ändern><en> Weather and the sea conditions can vary dramatically, are often punishing, and should never be taken for granted.
<G-vec00095-002-s448><vary.ändern><de> Diese Reichweite kann sich je nach Umgebung ändern, beispielsweise je nach Anzahl, Dicke und Material der Wände, die das Signal durchqueren muss.
<G-vec00095-002-s448><vary.ändern><en> This range can vary depending on the environment: number of walls to cross through, thickness of the walls, materials, etc.
<G-vec00095-002-s449><vary.ändern><de> Diese können sich im Laufe der Zeit ändern.
<G-vec00095-002-s449><vary.ändern><en> These may vary over the course of time.
<G-vec00095-002-s450><vary.ändern><de> Jede Rolle des ReTwisst XXLace hat ein Gewicht von 250gr und eine Länge von 90 m. Die Länge und das Gewicht können sich nach dem Inhalt eines Materials ändern.
<G-vec00095-002-s450><vary.ändern><en> Each bobin of ReTwisst has a weight of approx. 650 - 1000 gr and a length of 130 m. The length and the weight can vary according to the content of a material.
<G-vec00095-002-s451><vary.ändern><de> Die Liste der nicht-berechtigten Länder kann sich jährlich ändern.
<G-vec00095-002-s451><vary.ändern><en> The list of excluded countries may vary from year to year.
<G-vec00095-002-s452><vary.ändern><de> Das Angebot kann sich ändern und hängt von der Anzahl der interessierten Schüler ab.
<G-vec00095-002-s452><vary.ändern><en> The offer may vary, depending on the number of interested students.
<G-vec00095-002-s453><vary.ändern><de> Der Betrag kann sich von Zeit zu Zeit ändern.
<G-vec00095-002-s453><vary.ändern><en> The amount may vary from time to time.
<G-vec00095-002-s454><vary.ändern><de> Die Überprüfungen haben nach der Antwort gesucht, wie sich die Gene infolge der Umwelteffekten ändern, und diese genetische Änderung erblich ist.
<G-vec00095-002-s454><vary.ändern><en> Studies sought answers to how do genes vary due to the environmental effects and if the genetic change is inherited or not.
<G-vec00095-002-s455><vary.ändern><de> Das Elektrodenschweißverfahren basiert auf dem Gleichstromprinzip, d. h. der vom Generator bereitgestellte Strom darf sich nicht ändern, wenn der Schweißer die Elektrode im Verhältnis zum Werkstück bewegt.
<G-vec00095-002-s455><vary.ändern><en> Electrode welding is based on the constant current principle i.e. the current delivered by the power source should not vary when the operator moves the electrode towards the piece.
<G-vec00095-002-s823><vary.ändern><de> Einheitsgröße:106, Größen Tabelle ID: 285588Hinweis: Die angegebenen Größen können sich durch die unterschiedlichen Seriennummern der Größentabellen ändern.
<G-vec00095-002-s823><vary.ändern><en> S:98;M:102;L:106, Size Chart ID: 249915Please Note: Listed size charts may vary according to different Size Chart IDs.
<G-vec00095-002-s824><vary.ändern><de> Emirates behält sich vor, nach freiem Ermessen dieses Programm oder diese Geschäftsbedingungen jederzeit teilweise oder vollkommen zu ergänzen, zu ändern, zu aktualisieren oder zu beenden.
<G-vec00095-002-s824><vary.ändern><en> Emirates reserves the right to amend, vary, update, or terminate the Program or these Terms at any time, in whole or in part, at its sole discretion.
<G-vec00095-002-s825><vary.ändern><de> *Die Direktion bewahrt sich die Preisliste im Fall auf neue Gebühren zu ändern, fiskalische Abgaben und Erhöhung des Iva.
<G-vec00095-002-s825><vary.ändern><en> *The management reserves the right to vary the present price list in case of new fees, fiscal taxes and rise of VAT.
<G-vec00095-002-s826><vary.ändern><de> Wenn ein Festkörper große Verformungen erfährt, werden sich die Spannungskomponenten im allgemeinen als Folge der Materialrotation ändern.
<G-vec00095-002-s826><vary.ändern><en> When a solid element experience large deformations, the components of stress will, in general, vary as a result of material rotation.
<G-vec00095-002-s827><vary.ändern><de> Außer wenn sie ausdrücklich und in schriftlicher Form von einem Bevollmächtigten von ILH Ltd geändert wurden, hat kein Mitarbeiter, Vertreter oder Dritter, der im Namen von ILH Ltd handelt oder behauptet zu handeln, die Berechtigung, diese Bedingungen zu ändern und Sie sind nicht berechtigt anzunehmen, dass diese geändert wurden.
<G-vec00095-002-s827><vary.ändern><en> Save where expressly varied in writing by an authorised representative of ILH Ltd, no employee, agent or third party acting or purporting to act on behalf of ILH Ltd has the authority to vary these terms and you shall not be entitled to assume that any variation has occurred.
<G-vec00095-002-s829><vary.ändern><de> Wenn Sie die Bedingungen dieser Vereinbarung ändern möchten, muss dies schriftlich erfolgen und unsere Annahme einer Abweichung muss schriftlich nachgewiesen werden.
<G-vec00095-002-s829><vary.ändern><en> If you wish to vary the terms of this agreement, this must be in writing and our acceptance of any variation must be evidenced in writing.
<G-vec00095-002-s830><vary.ändern><de> Wir versuchen in so viele Städte wie möglich zu kommen und ändern unsere Tour-Route häufig.
<G-vec00095-002-s830><vary.ändern><en> We try our best to perform in as many cities as possible over the course of any given year, and we vary our tour routes from time to time.
<G-vec00095-002-s831><vary.ändern><de> Wir behalten uns das Recht vor, diese allgemeinen Geschäftsbedingungen und alle unsere Richtlinien von Zeit zu Zeit zu ändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Website in Kraft; durch Ihre weitere Nutzung der Website akzeptieren Sie diese Änderungen.
<G-vec00095-002-s831><vary.ändern><en> We reserve the right to vary these Terms & Conditions and any of Our policies from time to time, such variations becoming effective immediately upon posting to the Site; and by continuing to use the Site, You will be deemed to accept any such variations.
<G-vec00095-002-s832><vary.ändern><de> Sibanye-Stillwater behält sich das Recht vor, die Platzierung nicht fortzusetzen oder die Bedingungen der Platzierung in irgendeiner Weise zu ändern.
<G-vec00095-002-s832><vary.ändern><en> Sibanye-Stillwater reserves the right not to proceed with the Placing or to vary any terms of the Placing in any way.
<G-vec00095-002-s833><vary.ändern><de> Kategorien:Flache Schuhe; Styles:Runde Zehe,Comfort; Oberstoff:Veloursleder; Futterstoff:Kunstleder; Accents:Zuschnüren; Absatz Typ:Flascher Absatz; Größe:EU39,EU38,EU37,EU36; Verfügbare Breite:Durchschnitt; Farbe:Rot,Schwarz; Anlass:Informell,Büro; Saison:Winter,Herbst,Sommer,Frühling; Tips:Die Darstellung der Farbe & Stil kann von dem Birdschirm ändern.
<G-vec00095-002-s833><vary.ändern><en> Category:Fashion Sneakers; Styles:Round Toe,Comfort; Upper Materials:Canvas; Heel Type:Flat Heel; Size:EU28,EU27,EU26; Available Width:Average; Color:Black,White; Occasion:Casual; Season:Fall,Spring; Net weight:0.80 kg; Shipping Weight:0.90 kg; Tips:The color of embellishments are shown as picture.,Color Style representation may vary by monitor.
<G-vec00095-002-s834><vary.ändern><de> Das Management behält sich das Recht vor, die Zuteilung für seine internen organisatorischen oder funktionellen Bedürfnisse nach eigenem Ermessen durchzuführen und / oder zu ändern.
<G-vec00095-002-s834><vary.ändern><en> The Management, at its own discretion, reserves the right to assign accommodation and /or vary said accommodation according to organisational or functional needs within the village/campsite.
<G-vec00095-002-s835><vary.ändern><de> Es ist jederzeit möglich, den Abstand zum Fahrzeug vor Ihnen zu ändern, indem Sie mehrmals hintereinander auf den Schalter 6 drücken.
<G-vec00095-002-s835><vary.ändern><en> You can vary the following distance from the vehicle in front at any time by pressing switch 6 repeatedly.
<G-vec00095-002-s836><vary.ändern><de> Die Emittentin behält sich das Recht vor, jederzeit die Bestellung der Emissionsstelle oder einer Zahlstelle oder der Berechnungsstelle zu ändern oder zu beenden und eine andere Emissionsstelle oder zusätzliche oder andere Zahlstellen oder eine andere Berechnungsstelle zu bestellen.
<G-vec00095-002-s836><vary.ändern><en> The Issuer reserves the right at any time to vary or terminate the appointment of the Fiscal Agent or any Paying Agent or the Calculation Agent and to appoint another Fiscal Agent or additional or other Paying Agents or another Calculation Agent.
<G-vec00095-002-s837><vary.ändern><de> REGEL 43: ÄNDERUNG ODER ERNEUERUNG VON KLAUSELN 1 Wenn die Manager die Eintragungsbestimmungen eines versicherten Schiffs ändern oder erneuern möchten, können sie dem betreffenden Mitglied eine schriftliche Ankündigung der vorgesehenen Änderung oder Erneuerung höchstens 30 Tage vor dem nächsten Erneuerungsdatum zustellen.
<G-vec00095-002-s837><vary.ändern><en> RULE 43: VARIATION OR RENEWAL OF TERMS 1 If the Managers desire to vary or renew the terms of entry for any insured vessel they may give notice in writing to the Member concerned of the proposed variation or renewal of the terms of entry not later than 30 days prior to the renewal date next ensuing.
<G-vec00095-002-s838><vary.ändern><de> Sie können Ihre Bestellung nicht ändern oder stornieren, nachdem diese akzeptiert wurde, außer im Einklang mit dem unten aufgeführten Paragrafen 7.
<G-vec00095-002-s838><vary.ändern><en> You may not cancel or vary your order once it has been accepted, except in accordance with paragraph 7 below.
<G-vec00095-002-s839><vary.ändern><de> Der Rat der Westeuropäischen Union kann das Verzeichnis der Anlage IV durch einstimmige Entscheidung ändern.
<G-vec00095-002-s839><vary.ändern><en> The Council of Western European Union may vary the list in Annex IV by unanimous decision.
<G-vec00095-002-s840><vary.ändern><de> Kategorien:Typ:Stiletto; Größe:EU39,EU38,EU37,EU36; Farbe:Blau,Schwarz; Anlass:Party & Festabend,Kleid,Büro,Hochzeit; Saison:Frühling,Herbst,Sommer; Tips:Die Darstellung der Farbe & Stil kann von dem Birdschirm ändern.
<G-vec00095-002-s840><vary.ändern><en> Category:Color:Blue,Red; Occasion:Casual; Season:Fall,Spring; Net weight:0.80 kg; Shipping Weight:0.90 kg; Tips:The color of embellishments are shown as picture.,Color Style representation may vary by monitor.
