<G-vec00042-001-s038><go.begeben><de> Du hast Angst, dich außer Kontrolle zu begeben.
<G-vec00042-001-s038><go.begeben><en> You are afraid to let go of control.
<G-vec00042-001-s039><go.begeben><de> Wer sich sonnen will, kann sich auf die Terrasse des Hotels begeben und diejenigen, die sich lieber entspannen wollen, können einen schönen Spaziergang im Garten machen.
<G-vec00042-001-s039><go.begeben><en> Who wants to sunbathe, can go on the terrace of the hotel and those who prefer to relax can enjoy a walk in the garden.
<G-vec00042-001-s040><go.begeben><de> In Lysekil kann man das Haus des Meeres (Havets hus) besuchen, einen herrlichen Spaziergang am Gullmarsfjorden unternehmen oder begeben sich auf Meeresangeltour oder geguidete Robbensafarie.
<G-vec00042-001-s040><go.begeben><en> In Lysekil you can visit the Havets hus (The House of the Sea), enjoy a walk along the Gullmarsfjorden, go sea fishing with a guided tour boat or go by boat on a guided seal safari.
<G-vec00042-001-s041><go.begeben><de> Aber andererseits, Sie hätten sich auf die Arbeit nicht begeben, es wäre die Verletzung nicht.
<G-vec00042-001-s041><go.begeben><en> But on the other hand, you would not go for work, there would be no trauma.
<G-vec00042-001-s042><go.begeben><de> Das Besondere an diesen Gins ist, dass sie sich gar nicht erst in die Nähe der altbekannten Schiene des London Dry Gins begeben.
<G-vec00042-001-s042><go.begeben><en> These drinks are special because they do not even attempt to go down the London Dry Gin route.
<G-vec00042-001-s043><go.begeben><de> Reitunterricht auf dem Gelände von AdventureRide und Gelände-Ausritte Auf dem Gelände von AdventureRide kannst du Reitunterricht bei einem professionellem Trainer nehmen sowie dich auf einen ein paar Stunden dauernden Ausritt durch die Waldpfade begeben.
<G-vec00042-001-s043><go.begeben><en> Training in AdventureRide stable and horseback riding You can attend training led by a professional trainer and go on a couple-hour-long horseback ride through the trails in the woods.
<G-vec00042-001-s044><go.begeben><de> Sich noch in die Kreuzfahrt zu begeben...
<G-vec00042-001-s044><go.begeben><en> Still to go to cruise...
<G-vec00042-001-s045><go.begeben><de> Die Juden hatten vor der Schlucht ihre Wertsachen abzugeben, sich völlig zu entkleiden und sich in Gruppen von 10 Personen zur Oberkante der Schlucht zu begeben.
<G-vec00042-001-s045><go.begeben><en> Outside the ravine the Jews had to hand over their valuables, to undress entirely, and then to go to the upper edge of the ravine in groups of 10.
<G-vec00042-001-s046><go.begeben><de> Und da sich dann die Kleinbürger durch nichts von den Männern unterschieden und trugen vorzugsweise domotkanuju die Kleidung, einschließlich die Kaftane aus dem groben weißen Tuch, dem Schnitt ähnlich mit gewöhnlich polesskimi von den Rollen, so hat jemand die Meinung ausgesprochen, dass den negosche-halt Kleinbürgern, sich in die Hauptstadt in der Art von den Männern zu begeben.
<G-vec00042-001-s046><go.begeben><en> And as then petty bourgeoises differed in nothing from men and wore mainly homespun clothes, including caftans from rough white cloth, we will cover similar to usual Polesia rolls, someone expressed opinion that is more useless to petty bourgeoises to go to the capital like men.
<G-vec00042-001-s047><go.begeben><de> In Dezember 1936 war er erzwungen, Warschau zu verlassen und, sich in den schweizerischen Kurort Grass zu begeben.
<G-vec00042-001-s047><go.begeben><en> In December, 1936 he has been compelled to leave Warsaw and to go to the Swiss resort Grass.
<G-vec00042-001-s048><go.begeben><de> Für vier Tage haben sich viele Kiter, Windsurfer und Partybegeisterte aus der ganzen Republik nach Fehmarn begeben, die dem Ruf nach Surfen, Wind, Sonne und Party gefolgt sind.
<G-vec00042-001-s048><go.begeben><en> For four days, many riders, Surfers and party-seekers from all over the Republic of Fehmarn to go, to the call for surfing, Wind, The sun and the party followed.
<G-vec00042-001-s049><go.begeben><de> Nun begeben wir uns in mein Haus, das nun Gott dem Herrn sicher wohlgefälliger ist als der Salomonische Tempel zu Jerusalem.
<G-vec00042-001-s049><go.begeben><en> Now let us go to my house which is certainly more pleasing to the Lord God than Solomon's temple in Jerusalem.
<G-vec00042-001-s050><go.begeben><de> Um ältere Kunstwerke und Gebäude bewundern zu können, muss man sich in das Herz der Stadt begeben und zum Beispiel corso Matteotti entlang spazieren.
<G-vec00042-001-s050><go.begeben><en> If you want to find other interesting buildings and works of art, then you need to go into the heart of the town and, for example, walk along Corso Matteotti.
<G-vec00042-001-s051><go.begeben><de> Wenn jedoch die EDM Verwendung ist nicht auf das Messobjekt zu begeben und damit auf große Entfernungen spart eine Menge Zeit.
<G-vec00042-001-s051><go.begeben><en> However, when using the EDM is not required to go to the measured object, and hence at great distances saves a lot of time.
<G-vec00042-001-s052><go.begeben><de> Verlassen wir den Schutzanzug der Moral, so müssen wir uns auf die Suche nach persönlichem Sinn und Wirken begeben.
<G-vec00042-001-s052><go.begeben><en> As soon as we leave the protective gear of morals, we must go and look for a meaning in our personal lives and behaviour.
<G-vec00042-001-s053><go.begeben><de> Während der 90-minütigen Verkostung begeben Sie sich auf eine Reise durch das ganze Land und entdecken dabei die Geschichte und die Geheimnisse jedes Weingutes.
<G-vec00042-001-s053><go.begeben><en> During the 90 minutes tasting, you will go on a journey all over the country through it wines, discovering the history and secrets of each winery in the process.
<G-vec00042-001-s054><go.begeben><de> Es hindert auch keineswegs, daß Vertreter der Weltkirche sich nach Afrika begeben und dort ihre Sicht aus anderer Perspektive einbringen.
<G-vec00042-001-s054><go.begeben><en> And it does by no means prevent that representatives of the world church go to Africa and bring in there their view from a different perspective.
<G-vec00042-001-s055><go.begeben><de> Jeden Morgen begeben sich die Ortsansässigen zu „Dankesübungen“, die Sakura leitet, an den Strand.
<G-vec00042-001-s055><go.begeben><en> Every morning the locals go down to the beach for a round of ‘merci exercises’, led by Sakura.
<G-vec00042-001-s056><go.begeben><de> Bitte begeben Sie sich auf der Abflugebene zum Mobilitätsserviceschalter im Terminal 3, oder zum Check-in Schalter Ihrer Fluglinie.
<G-vec00042-001-s056><go.begeben><en> Please go to the Mobility Service counter in Terminal 3 or ask at your airline’s check-in counter.
<G-vec00524-001-s038><go.begeben><de> Du hast Angst, dich außer Kontrolle zu begeben.
<G-vec00524-001-s038><go.begeben><en> You are afraid to let go of control.
<G-vec00524-001-s039><go.begeben><de> Wer sich sonnen will, kann sich auf die Terrasse des Hotels begeben und diejenigen, die sich lieber entspannen wollen, können einen schönen Spaziergang im Garten machen.
<G-vec00524-001-s039><go.begeben><en> Who wants to sunbathe, can go on the terrace of the hotel and those who prefer to relax can enjoy a walk in the garden.
<G-vec00524-001-s040><go.begeben><de> In Lysekil kann man das Haus des Meeres (Havets hus) besuchen, einen herrlichen Spaziergang am Gullmarsfjorden unternehmen oder begeben sich auf Meeresangeltour oder geguidete Robbensafarie.
<G-vec00524-001-s040><go.begeben><en> In Lysekil you can visit the Havets hus (The House of the Sea), enjoy a walk along the Gullmarsfjorden, go sea fishing with a guided tour boat or go by boat on a guided seal safari.
<G-vec00524-001-s041><go.begeben><de> Aber andererseits, Sie hätten sich auf die Arbeit nicht begeben, es wäre die Verletzung nicht.
<G-vec00524-001-s041><go.begeben><en> But on the other hand, you would not go for work, there would be no trauma.
<G-vec00524-001-s042><go.begeben><de> Das Besondere an diesen Gins ist, dass sie sich gar nicht erst in die Nähe der altbekannten Schiene des London Dry Gins begeben.
<G-vec00524-001-s042><go.begeben><en> These drinks are special because they do not even attempt to go down the London Dry Gin route.
<G-vec00524-001-s043><go.begeben><de> Reitunterricht auf dem Gelände von AdventureRide und Gelände-Ausritte Auf dem Gelände von AdventureRide kannst du Reitunterricht bei einem professionellem Trainer nehmen sowie dich auf einen ein paar Stunden dauernden Ausritt durch die Waldpfade begeben.
<G-vec00524-001-s043><go.begeben><en> Training in AdventureRide stable and horseback riding You can attend training led by a professional trainer and go on a couple-hour-long horseback ride through the trails in the woods.
<G-vec00524-001-s044><go.begeben><de> Sich noch in die Kreuzfahrt zu begeben...
<G-vec00524-001-s044><go.begeben><en> Still to go to cruise...
<G-vec00524-001-s045><go.begeben><de> Die Juden hatten vor der Schlucht ihre Wertsachen abzugeben, sich völlig zu entkleiden und sich in Gruppen von 10 Personen zur Oberkante der Schlucht zu begeben.
<G-vec00524-001-s045><go.begeben><en> Outside the ravine the Jews had to hand over their valuables, to undress entirely, and then to go to the upper edge of the ravine in groups of 10.
<G-vec00524-001-s046><go.begeben><de> Und da sich dann die Kleinbürger durch nichts von den Männern unterschieden und trugen vorzugsweise domotkanuju die Kleidung, einschließlich die Kaftane aus dem groben weißen Tuch, dem Schnitt ähnlich mit gewöhnlich polesskimi von den Rollen, so hat jemand die Meinung ausgesprochen, dass den negosche-halt Kleinbürgern, sich in die Hauptstadt in der Art von den Männern zu begeben.
<G-vec00524-001-s046><go.begeben><en> And as then petty bourgeoises differed in nothing from men and wore mainly homespun clothes, including caftans from rough white cloth, we will cover similar to usual Polesia rolls, someone expressed opinion that is more useless to petty bourgeoises to go to the capital like men.
<G-vec00524-001-s047><go.begeben><de> In Dezember 1936 war er erzwungen, Warschau zu verlassen und, sich in den schweizerischen Kurort Grass zu begeben.
<G-vec00524-001-s047><go.begeben><en> In December, 1936 he has been compelled to leave Warsaw and to go to the Swiss resort Grass.
<G-vec00524-001-s048><go.begeben><de> Für vier Tage haben sich viele Kiter, Windsurfer und Partybegeisterte aus der ganzen Republik nach Fehmarn begeben, die dem Ruf nach Surfen, Wind, Sonne und Party gefolgt sind.
<G-vec00524-001-s048><go.begeben><en> For four days, many riders, Surfers and party-seekers from all over the Republic of Fehmarn to go, to the call for surfing, Wind, The sun and the party followed.
<G-vec00524-001-s049><go.begeben><de> Nun begeben wir uns in mein Haus, das nun Gott dem Herrn sicher wohlgefälliger ist als der Salomonische Tempel zu Jerusalem.
<G-vec00524-001-s049><go.begeben><en> Now let us go to my house which is certainly more pleasing to the Lord God than Solomon's temple in Jerusalem.
<G-vec00524-001-s050><go.begeben><de> Um ältere Kunstwerke und Gebäude bewundern zu können, muss man sich in das Herz der Stadt begeben und zum Beispiel corso Matteotti entlang spazieren.
<G-vec00524-001-s050><go.begeben><en> If you want to find other interesting buildings and works of art, then you need to go into the heart of the town and, for example, walk along Corso Matteotti.
<G-vec00524-001-s051><go.begeben><de> Wenn jedoch die EDM Verwendung ist nicht auf das Messobjekt zu begeben und damit auf große Entfernungen spart eine Menge Zeit.
<G-vec00524-001-s051><go.begeben><en> However, when using the EDM is not required to go to the measured object, and hence at great distances saves a lot of time.
<G-vec00524-001-s052><go.begeben><de> Verlassen wir den Schutzanzug der Moral, so müssen wir uns auf die Suche nach persönlichem Sinn und Wirken begeben.
<G-vec00524-001-s052><go.begeben><en> As soon as we leave the protective gear of morals, we must go and look for a meaning in our personal lives and behaviour.
<G-vec00524-001-s053><go.begeben><de> Während der 90-minütigen Verkostung begeben Sie sich auf eine Reise durch das ganze Land und entdecken dabei die Geschichte und die Geheimnisse jedes Weingutes.
<G-vec00524-001-s053><go.begeben><en> During the 90 minutes tasting, you will go on a journey all over the country through it wines, discovering the history and secrets of each winery in the process.
<G-vec00524-001-s054><go.begeben><de> Es hindert auch keineswegs, daß Vertreter der Weltkirche sich nach Afrika begeben und dort ihre Sicht aus anderer Perspektive einbringen.
<G-vec00524-001-s054><go.begeben><en> And it does by no means prevent that representatives of the world church go to Africa and bring in there their view from a different perspective.
<G-vec00524-001-s055><go.begeben><de> Jeden Morgen begeben sich die Ortsansässigen zu „Dankesübungen“, die Sakura leitet, an den Strand.
<G-vec00524-001-s055><go.begeben><en> Every morning the locals go down to the beach for a round of ‘merci exercises’, led by Sakura.
<G-vec00524-001-s056><go.begeben><de> Bitte begeben Sie sich auf der Abflugebene zum Mobilitätsserviceschalter im Terminal 3, oder zum Check-in Schalter Ihrer Fluglinie.
<G-vec00524-001-s056><go.begeben><en> Please go to the Mobility Service counter in Terminal 3 or ask at your airline’s check-in counter.
