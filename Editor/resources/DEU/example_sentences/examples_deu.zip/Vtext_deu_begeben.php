<G-vec00042-001-s038><go.begeben><de> Du hast Angst, dich außer Kontrolle zu begeben.
<G-vec00042-001-s038><go.begeben><en> You are afraid to let go of control.
<G-vec00042-001-s039><go.begeben><de> Wer sich sonnen will, kann sich auf die Terrasse des Hotels begeben und diejenigen, die sich lieber entspannen wollen, können einen schönen Spaziergang im Garten machen.
<G-vec00042-001-s039><go.begeben><en> Who wants to sunbathe, can go on the terrace of the hotel and those who prefer to relax can enjoy a walk in the garden.
<G-vec00042-001-s040><go.begeben><de> In Lysekil kann man das Haus des Meeres (Havets hus) besuchen, einen herrlichen Spaziergang am Gullmarsfjorden unternehmen oder begeben sich auf Meeresangeltour oder geguidete Robbensafarie.
<G-vec00042-001-s040><go.begeben><en> In Lysekil you can visit the Havets hus (The House of the Sea), enjoy a walk along the Gullmarsfjorden, go sea fishing with a guided tour boat or go by boat on a guided seal safari.
<G-vec00042-001-s041><go.begeben><de> Aber andererseits, Sie hätten sich auf die Arbeit nicht begeben, es wäre die Verletzung nicht.
<G-vec00042-001-s041><go.begeben><en> But on the other hand, you would not go for work, there would be no trauma.
<G-vec00042-001-s042><go.begeben><de> Das Besondere an diesen Gins ist, dass sie sich gar nicht erst in die Nähe der altbekannten Schiene des London Dry Gins begeben.
<G-vec00042-001-s042><go.begeben><en> These drinks are special because they do not even attempt to go down the London Dry Gin route.
<G-vec00042-001-s043><go.begeben><de> Reitunterricht auf dem Gelände von AdventureRide und Gelände-Ausritte Auf dem Gelände von AdventureRide kannst du Reitunterricht bei einem professionellem Trainer nehmen sowie dich auf einen ein paar Stunden dauernden Ausritt durch die Waldpfade begeben.
<G-vec00042-001-s043><go.begeben><en> Training in AdventureRide stable and horseback riding You can attend training led by a professional trainer and go on a couple-hour-long horseback ride through the trails in the woods.
<G-vec00042-001-s044><go.begeben><de> Sich noch in die Kreuzfahrt zu begeben...
<G-vec00042-001-s044><go.begeben><en> Still to go to cruise...
<G-vec00042-001-s045><go.begeben><de> Die Juden hatten vor der Schlucht ihre Wertsachen abzugeben, sich völlig zu entkleiden und sich in Gruppen von 10 Personen zur Oberkante der Schlucht zu begeben.
<G-vec00042-001-s045><go.begeben><en> Outside the ravine the Jews had to hand over their valuables, to undress entirely, and then to go to the upper edge of the ravine in groups of 10.
<G-vec00042-001-s046><go.begeben><de> Und da sich dann die Kleinbürger durch nichts von den Männern unterschieden und trugen vorzugsweise domotkanuju die Kleidung, einschließlich die Kaftane aus dem groben weißen Tuch, dem Schnitt ähnlich mit gewöhnlich polesskimi von den Rollen, so hat jemand die Meinung ausgesprochen, dass den negosche-halt Kleinbürgern, sich in die Hauptstadt in der Art von den Männern zu begeben.
<G-vec00042-001-s046><go.begeben><en> And as then petty bourgeoises differed in nothing from men and wore mainly homespun clothes, including caftans from rough white cloth, we will cover similar to usual Polesia rolls, someone expressed opinion that is more useless to petty bourgeoises to go to the capital like men.
<G-vec00042-001-s047><go.begeben><de> In Dezember 1936 war er erzwungen, Warschau zu verlassen und, sich in den schweizerischen Kurort Grass zu begeben.
<G-vec00042-001-s047><go.begeben><en> In December, 1936 he has been compelled to leave Warsaw and to go to the Swiss resort Grass.
<G-vec00042-001-s048><go.begeben><de> Für vier Tage haben sich viele Kiter, Windsurfer und Partybegeisterte aus der ganzen Republik nach Fehmarn begeben, die dem Ruf nach Surfen, Wind, Sonne und Party gefolgt sind.
<G-vec00042-001-s048><go.begeben><en> For four days, many riders, Surfers and party-seekers from all over the Republic of Fehmarn to go, to the call for surfing, Wind, The sun and the party followed.
<G-vec00042-001-s049><go.begeben><de> Nun begeben wir uns in mein Haus, das nun Gott dem Herrn sicher wohlgefälliger ist als der Salomonische Tempel zu Jerusalem.
<G-vec00042-001-s049><go.begeben><en> Now let us go to my house which is certainly more pleasing to the Lord God than Solomon's temple in Jerusalem.
<G-vec00042-001-s050><go.begeben><de> Um ältere Kunstwerke und Gebäude bewundern zu können, muss man sich in das Herz der Stadt begeben und zum Beispiel corso Matteotti entlang spazieren.
<G-vec00042-001-s050><go.begeben><en> If you want to find other interesting buildings and works of art, then you need to go into the heart of the town and, for example, walk along Corso Matteotti.
<G-vec00042-001-s051><go.begeben><de> Wenn jedoch die EDM Verwendung ist nicht auf das Messobjekt zu begeben und damit auf große Entfernungen spart eine Menge Zeit.
<G-vec00042-001-s051><go.begeben><en> However, when using the EDM is not required to go to the measured object, and hence at great distances saves a lot of time.
<G-vec00042-001-s052><go.begeben><de> Verlassen wir den Schutzanzug der Moral, so müssen wir uns auf die Suche nach persönlichem Sinn und Wirken begeben.
<G-vec00042-001-s052><go.begeben><en> As soon as we leave the protective gear of morals, we must go and look for a meaning in our personal lives and behaviour.
<G-vec00042-001-s053><go.begeben><de> Während der 90-minütigen Verkostung begeben Sie sich auf eine Reise durch das ganze Land und entdecken dabei die Geschichte und die Geheimnisse jedes Weingutes.
<G-vec00042-001-s053><go.begeben><en> During the 90 minutes tasting, you will go on a journey all over the country through it wines, discovering the history and secrets of each winery in the process.
<G-vec00042-001-s054><go.begeben><de> Es hindert auch keineswegs, daß Vertreter der Weltkirche sich nach Afrika begeben und dort ihre Sicht aus anderer Perspektive einbringen.
<G-vec00042-001-s054><go.begeben><en> And it does by no means prevent that representatives of the world church go to Africa and bring in there their view from a different perspective.
<G-vec00042-001-s055><go.begeben><de> Jeden Morgen begeben sich die Ortsansässigen zu „Dankesübungen“, die Sakura leitet, an den Strand.
<G-vec00042-001-s055><go.begeben><en> Every morning the locals go down to the beach for a round of ‘merci exercises’, led by Sakura.
<G-vec00042-001-s056><go.begeben><de> Bitte begeben Sie sich auf der Abflugebene zum Mobilitätsserviceschalter im Terminal 3, oder zum Check-in Schalter Ihrer Fluglinie.
<G-vec00042-001-s056><go.begeben><en> Please go to the Mobility Service counter in Terminal 3 or ask at your airline’s check-in counter.
<G-vec00261-002-s052><proceed.begeben><de> Nehmen Sie die MRT-Bahn bis zur Station Joo Koon und begeben Sie sich zum Busbahnhof, um die Linie 182/182M zu nutzen.
<G-vec00261-002-s052><proceed.begeben><en> Getting there MRT to Joo Koon MRT and proceed to the bus interchange to board bus service 182/182M.
<G-vec00261-002-s053><proceed.begeben><de> Begeben Sie sich am Flughafen direkt zur Sicherheits- und Passkontrolle, wenn Sie keine Taschen zum Aufgeben haben und keine Reisedokumente oder Ihre Kreditkarte am Check-in-Schalter überprüft werden müssen.
<G-vec00261-002-s053><proceed.begeben><en> At the airport, proceed directly to the Immigration counter if you don’t have bags to check in and if you don’t require travel document/visa/credit card verification at the check-in counter.
<G-vec00261-002-s054><proceed.begeben><de> Bitte begeben Sie sich zum Sixt-Schalter in der Ankunftshalle oder rufen Sie unsere Station unter +44 (0) 203 463 6791, damit wir unseren kostenlosen Shuttle-Service für Sie arrangieren und Sie vom Terminal abholen können.
<G-vec00261-002-s054><proceed.begeben><en> Please proceed to the Sixt desk in the arrivals hall or call our branch at +44 (0) 203 463 6791 to arrange for our free courtesy bus to pick you up.
<G-vec00261-002-s055><proceed.begeben><de> Bitte begeben Sie sich zum Bereich der Autovermietungen gegenüber von Terminal A und halten dabei Ausschau nach Sixt-Schildern.
<G-vec00261-002-s055><proceed.begeben><en> Please proceed to the car rental parkade situated opposite Teminal A arrivals. Look for our First Car Rental Signs.
<G-vec00261-002-s056><proceed.begeben><de> Bitte begeben Sie sich zum Avis Depot im South Terminal, um Ihren Wagen abzuholen.
<G-vec00261-002-s056><proceed.begeben><en> Please proceed to the Avis depot at the South Terminal to collect your car.
<G-vec00261-002-s057><proceed.begeben><de> Begeben Sie sich von der Gepäckausgabe zum Ankunftsbereich für nationale und internationale Flüge.
<G-vec00261-002-s057><proceed.begeben><en> baggage, proceed to the landing area for the domestic and international flight.
<G-vec00261-002-s058><proceed.begeben><de> Gehen Sie an den langen, überfüllten Einstiegslinien vorbei und begeben Sie sich in Begleitung Ihres Reiseführers und einer kleinen Gruppe von 10 Personen oder weniger direkt in die Galerie.
<G-vec00261-002-s058><proceed.begeben><en> Walk past the long, crowded entry lines and proceed directly inside the gallery in the company of your guide and small group of 10 people or fewer.
<G-vec00261-002-s059><proceed.begeben><de> Wenn Sie Ihre Einkäufe im Handgepäck befördern möchten, begeben Sie sich damit in die Transit Lounge im Abflugbereich (nach der Ausreisekontrolle) des Flughafens oder Kreuzfahrtterminals, und beantragen Sie die Erstattung an dem dortigen eTRS-Kiosk.
<G-vec00261-002-s059><proceed.begeben><en> If you plan to hand-carry your purchases, proceed to the Departure Transit area (after departure immigration) at the airport with your purchases and apply for your refund at the eTRS self-help kiosk found there. 2.
<G-vec00261-002-s060><proceed.begeben><de> Folgen Sie der Beschilderung zu den Gates "D" und begeben Sie sich zu Ihrem Abfluggate.
<G-vec00261-002-s060><proceed.begeben><en> Follow signage for E Gates and proceed to your departure gate
<G-vec00302-002-s019><head.begeben><de> Begeben Sie sich im Anschluss zum Máximo-Gómez-Park und mischen Sie sich bei einer Runde Domino unter die Einheimischen.
<G-vec00302-002-s019><head.begeben><en> Head to the Máximo Gómez park afterwards to mingle with the locals and join in the competitive dominoes games that take place there.
<G-vec00302-002-s020><head.begeben><de> Ganztägige Käfertour nach Sintra: Begeben Sie sich in die Berge von Sintra auf eine Tour in einem altem VW-Käfer.
<G-vec00302-002-s020><head.begeben><en> Full Day Tour to Sintra by Beetle: Head out into the Sintra Mountains with a retro VW Beetle tour.
<G-vec00302-002-s021><head.begeben><de> Wenn die Pferde und wir wieder trocken sind begeben wir uns auf den Weg zurück zur Ranch.
<G-vec00302-002-s021><head.begeben><en> When the horses and we are dried up, we will head back to the ranch.
<G-vec00302-002-s022><head.begeben><de> Umgehen Sie Warteschlangen und begeben Sie sich für ermäßigte Cocktails und vier kostenlose Shots in die Lokalitäten - ideal für ein Prost mit Ihren neuen Freunden.
<G-vec00302-002-s022><head.begeben><en> Skip the lines and head inside for discounted cocktails and four complimentary shots, perfect for toasting with your new friends.
<G-vec00302-002-s023><head.begeben><de> Merken Nach kurzer Unterweisung begeben wir uns auf einen Bogen-Parcours auf die Jagd nach Bisons, Wölfen und Bären und testen unser Geschick mit Pfeil und Bogen.
<G-vec00302-002-s023><head.begeben><en> After a brief instruction, we head out on to the archery course and test our skills with a bow and arrow as we hunt bison, wolves and bears.
<G-vec00302-002-s024><head.begeben><de> Spazieren Sie durch Tsarkoye Selo Parks und begeben Sie sich in Catherine Palace, wo Sie aufwendige Rokoko und den Nachbau des unglaublichen Bernsteinzimmers sehen - ein Zimmer, das geplündert wurde von den Nazis am Ende des Zweiten Weltkriegs.
<G-vec00302-002-s024><head.begeben><en> Stroll around Tsarkoye Selo Parks and head inside Catherine Palace to swoon at its lavish Rococo interiors like the replica of the incredible Amber Room – a room that was looted by the Nazis at the end of the Second World War.
<G-vec00302-002-s025><head.begeben><de> Testen Sie Hermosa Beach und Manhattan Beach, oder begeben Sie sich ins Del Amo Shopping Center, um nach Souvenirs zu suchen.
<G-vec00302-002-s025><head.begeben><en> Compare Hermosa Beach and Manhattan Beach, or head to the Del Amo Shopping Center for keepsakes.
<G-vec00302-002-s026><head.begeben><de> Wir nehmen Abschied von Swakopmund und begeben uns auf den Weg nordwärts entlang der Küste nach Henties Bay.
<G-vec00302-002-s026><head.begeben><en> We say goodbye to Swakopmund and head north along the coast to Henties Bay.
<G-vec00302-002-s027><head.begeben><de> Begeben Sie sich auf die Outdoor-Ausstellung in Amerika, auf der ein Regenbogen von Tieren zu sehen ist, darunter der scharlachrote Ara, der amerikanische Flamingo, der schwarzhändige Klammeraffe und natürlich Südamerikas größte Katze, der Jaguar.
<G-vec00302-002-s027><head.begeben><en> Head on over to the Americas Outdoor Exhibit, which has a rainbow of animals including the scarlet macaw, American flamingo, black-handed spider monkey, and, of course, South America’s largest cat, the jaguar.
<G-vec00302-002-s028><head.begeben><de> Begeben Sie sich zum Hafen und erkunden Sie das berühmte Sydney Opera House, oder versuchen Sie die Bridge Climb, eine Brückenbesteigung mit wahrhaft spektakulären Blicken auf die City.
<G-vec00302-002-s028><head.begeben><en> Head to the harbour area and explore the world famous Sydney Opera House or try the bridge climb for truly spectacular city views.
<G-vec00302-002-s029><head.begeben><de> Wenn Sie ein bisschen Geld verprassen möchten, können Sie sich bei Einbruch der Dunkelheit ins Casino Monte Carlo begeben.
<G-vec00302-002-s029><head.begeben><en> As night falls, if you wish to play for high stakes, head for the Monte Carlo Casino.
<G-vec00302-002-s030><head.begeben><de> Nach einer kurzen Einweisung und Sicherheitsunterweisung begeben Sie sich in die Bucht, erkunden kleinere Inseln, Tauchplätze und eine kleines Höhlensystem auf dem Weg.
<G-vec00302-002-s030><head.begeben><en> After a short instruction and safety lesson, head out into the bay, exploring smaller islets, diving spots, and a small cave system along the way.
<G-vec00302-002-s031><head.begeben><de> Begeben Sie sich zum Buffet Silja, um Ihren Teller mit Rogen, Schrimps, traditionellen Inselgerichten oder Tapas zu füllen.
<G-vec00302-002-s031><head.begeben><en> For a bit of everything head to the Grande Buffet to fill your plate with roe, shrimps, traditional island dishes or tapas.
<G-vec00302-002-s032><head.begeben><de> Nach 14 Stunden voller toller Eindrücke bin ich dann müde ins Bett gefallen um mich am nächsten Morgen in die lange Reihe der Abreisenden auf dem Syltshuttle zu begeben.
<G-vec00302-002-s032><head.begeben><en> 14 hours later full of great impressions I fell totally exhausted on my bed for a short night to head out to the Syltshuttle, lining up with tons of other people that were about to depart in the morning.
<G-vec00302-002-s033><head.begeben><de> Und wenn Sie sich gerne in einer gemütlichen Ecke zu einem Kaffee oder einem seltenen Brandy niederlassen möchten, begeben Sie sich am besten zur holzgetäfelten Vault Bar in einem der ältesten Cognac-Keller Europas – einem ehemaligen Banktresor.
<G-vec00302-002-s033><head.begeben><en> And if settling in an atmospheric corner for coffee or a rare brandy appeals, head for the wood-panelled Vault Bar set in one of the oldest cognac cellars – formerly a bank vault – in Europe.
<G-vec00302-002-s034><head.begeben><de> Begeben Sie sich in die Ausstellung, die im ehemaligen Königspalast untergebracht ist, und sehen Sie mehr als 150 mathematisch inspirierte Meisterwerke von Escher auf eigene Faust.
<G-vec00302-002-s034><head.begeben><en> Head inside the exhibition, housed in the former Royal Palace, and view over 150 of Escher’s mathematically inspired masterpieces independently.
<G-vec00302-002-s035><head.begeben><de> Umgehen Sie die Warteschlangen mit bevorzugtem Eintritt und begeben Sie sich in dieses architektonische Juwel, entworfen von Antoni Gaudí als das Zuhause einer Familie und gut erhalten als Museum, um Gaudis einzigartigen, skurrilen Stil zu präsentieren.
<G-vec00302-002-s035><head.begeben><en> Skip the lines with priority entrance and head inside this architectural gem designed by Antoni Gaudi, built as a family home and preserved as a museum to showcase Gaudi’s unique, whimsical style.
<G-vec00302-002-s036><head.begeben><de> Begeben Sie sich in die Memphis Music Hall of Fame, um die vielen Musiker zu feiern, die ihre Karriere in der Stadt starteten, einschließlich Elvis Presley, Al Green, Otis Redding und Jerry Lee Lewis, und sehen Sie sich Ausstellungen an, die den Sound ergründen, der die amerikanische Musik verändert hat.
<G-vec00302-002-s036><head.begeben><en> Head to the Memphis Music Hall of Fame to celebrate the many musicians who emerged from the city, including Elvis Presley, Al Green, Otis Redding, and Jerry Lee Lewis, and see exhibits that explore the sounds that changed American music. mobile_o
<G-vec00302-002-s037><head.begeben><de> Wenn Sie eine Verschnaufpause einlegen wollen, dann begeben Sie sich am besten zum Accessoires-Gang, dort können Sie Würfel unter den Verkaufsregalen herausziehen und diese als Sitzgelegenheit benutzen, um sich beim Anprobieren der Schuhe ein wenig auszuruhen.
<G-vec00302-002-s037><head.begeben><en> If you need to catch a breather, just head to their accessories corridor, where you can pull out cubes under the display shelves to use as seats while you try on shoes.
<G-vec00309-002-s038><go.begeben><de> Während ich hier noch die letzten Tage in Buenos Aires genieße, hat sich unser Jens am Freitag in meinem Auftrag auf die Blitz XIV Party begeben um dort ein paar fabelhafte Fotos für uns zu machen.
<G-vec00309-002-s038><go.begeben><en> While I am enjoying my last days in Buenos Aires our Jens was so kind to go to the Blitz party for me and take some photos.
<G-vec00309-002-s039><go.begeben><de> Hier begeben wir uns bei mehreren Pirschfahrten auf die Suche nach den Big 5.
<G-vec00309-002-s039><go.begeben><en> Here we go on several game drives in search of the Big 5.
<G-vec00309-002-s040><go.begeben><de> Zum Schlafen begeben sie sich in die Bäume.
<G-vec00309-002-s040><go.begeben><en> For sleeping they go into the trees.
<G-vec00309-002-s041><go.begeben><de> Zum Dîner begeben wir uns in eines der besten Restaurants der Stadt.
<G-vec00309-002-s041><go.begeben><en> For dinner, we go to one of the best restaurants in the city.
<G-vec00309-002-s042><go.begeben><de> Morgens stärken Sie sich bei einem herzhaften Frühstück und begeben sich anschließend zum Trekking in die Berglandschaft des Naturparks Ordesa.
<G-vec00309-002-s042><go.begeben><en> After a hearty breakfast in the morning, you can venture into the Ordesa's mountainous landscape, and go trekking.
<G-vec00309-002-s043><go.begeben><de> Gemeinsam begeben sie sich auf die Suche nach Travis' verschollener Frau Jane.
<G-vec00309-002-s043><go.begeben><en> Together, they go in search of Travis’ lost wife, Jane.
<G-vec00309-002-s044><go.begeben><de> Für Ihre Momente der Entspannung können Sie sich eine Sitzung im Schönheitssalon gönnen oder sich in den Billardraum begeben.
<G-vec00309-002-s044><go.begeben><en> To enjoy moments of relaxation, you can treat yourself to a beauty treatment, or go to the billiard room.
<G-vec00309-002-s045><go.begeben><de> Er gehörte einer Familie aus einfachen Verhältnissen an, wie wir dem Empfehlungsschreiben entnehmen können, das Bernhard von Clairvaux an Hilduin schrieb, den Oberen der Abtei von Saint Victor in Paris, um ihn zu bitten, Petrus, der sich aus Gründen des Studiums in jene Stadt begeben wollte, unentgeltlich aufzunehmen.
<G-vec00309-002-s045><go.begeben><en> He belonged to a modest family, as we may deduce from the letter of introduction that Bernard of Clairvaux wrote to Gilduin, Superior of the Abbey of Saint-Victor in Paris, asking him to give free accommodation to Peter who wanted to go to that city in order to study.
<G-vec00309-002-s046><go.begeben><de> Journalist Stefan Kreutzberger und Filmemacher Valentin Thurn begeben sich auf eine weltweite Suche nach zukunftsfähigen Lösungen für die Nahrungsmittelproduktion, die Mensch und Tier respektiert und die knappen Ressourcen schonen.
<G-vec00309-002-s046><go.begeben><en> Journalist Stefan Kreutzberger and filmmaker Valentin Thurn go on a worldwide search for a sustainable solution, which treats our nature with care and preserves its resources.
<G-vec00309-002-s047><go.begeben><de> Das Signal besteht aus 7 kurzen und 1 langem Signal, was bedeutet, dass sich jeder Passagier unverzüglich zur nächsten Rettungsstation begeben muss.
<G-vec00309-002-s047><go.begeben><en> In case of an emergency situation 7 short and 1 long signals will be used. It notifies people of the need to go to the nearest assembly station.
<G-vec00309-002-s048><go.begeben><de> Das bietet erheblich mehr Sicherheit, denn Sie müssen sich nicht in Gefahr begeben, um den Brandherd zu suchen.
<G-vec00309-002-s048><go.begeben><en> This offers considerably more security, because you do not have to go into danger to seek out the source of the fire.
<G-vec00309-002-s049><go.begeben><de> Dabei treffen sich die Kursteilnehmer 15 Minuten vor Beginn des Kurses an der Rezeption der Therme Meran, begeben sich gemeinsam in den Poolbereich und verlassen diesen 15 Minuten nach Kursende wieder gemeinsam.
<G-vec00309-002-s049><go.begeben><en> Course participants meet at the Terme Merano/Therme Meran reception 15 minutes before the course starts, they then go to the pool area together and leave again together 15 minutes after the course ends.
<G-vec00309-002-s050><go.begeben><de> Diese Fragen beschäftigen seit ein paar Jahren immer mehr Führungskräfte, und auch wenn es noch nicht in allen Bereichen den optimalen Weg gibt, so steht doch fest, dass es keine Option ist, sich nicht auf den Weg zu begeben.
<G-vec00309-002-s050><go.begeben><en> These questions have been the focus of an increasing number of managers since a few years, and although there is not yet the best way to go in all areas, it is clear that there is no option not to go.
<G-vec00309-002-s051><go.begeben><de> Heute, wie durch alle Jahrhunderte hindurch, lädt uns die Eucharistie leise aber hartnäckig ein, uns in das Obergemach zu begeben, wo die Eucharistie eingesetzt wurde und wo die Kirche als Gottes Familie geboren wurde, die ein Herz und eine Seele in der Communio mit Christus und untereinander ist.
<G-vec00309-002-s051><go.begeben><en> Today, just as it has been through the centuries, the Eucharist silently but tenaciously invites us to go back to the Upper Room where, by the institution of the Eucharist, the Church was born as ‘God’s family’, ‘one heart and one soul’ in communion with Christ and with one another.
<G-vec00309-002-s052><go.begeben><de> Nach dem Flug begeben wir uns zu den Buggies und fahren über die Sanddünen zu den Cahuchi Pyramiden, einem antiken zeremoniellen Zentrum und zu den Aquädukten, an denen Sie herausfinden werden, wie die Nazca Wasser durch die Stadt beförderten.
<G-vec00309-002-s052><go.begeben><en> Later after the flight we will go to the buggie cars and go through the sand dunes to the Cahuachi pyramids, an ancient ceremonial center, and then to the aqueducts where you will find out how the ancient Nazcans carried water across the city.
<G-vec00309-002-s053><go.begeben><de> Wenn Ihr Anschlussflug am Flughafen Gimpo abfliegt, begeben Sie sich zum Flughafen Gimpo und checken dort ein.
<G-vec00309-002-s053><go.begeben><en> If your connecting flight is departing from Gimpo Airport, you should go to Gimpo Airport and proceed to check in.
<G-vec00309-002-s054><go.begeben><de> Dabei müssen die arabischen Völker aus ihren eigenen Erfahrungen die richtigen Lehren ziehen, nämlich dass sie sich niemals unter den Schutz einer Großmacht begeben, um sich dadurch vermeintlich vor einer anderen Großmacht zu "schützen".
<G-vec00309-002-s054><go.begeben><en> The Arab peoples must draw the important lessons from their own negative historical experiences, namely that they never go under the protection of a great power in order to "protect" themselves from another great power.
<G-vec00309-002-s055><go.begeben><de> Um sich einzutragen müssen Sie sich mit Ihrem Personalausweis vor Ort am Schalter begeben und den Betrag von 50,- € vorzahlen.
<G-vec00309-002-s055><go.begeben><en> To register please go to the centre, taking your identity card with you and 50 €.
<G-vec00309-002-s056><go.begeben><de> Wenn Ich also zu Meinen Jüngern gesagt habe: Taufet sie im Namen des Vaters und des Sohnes und des heiligen Geistes.... so ist darunter nichts anderes zu verstehen, als daß sie in Meinem Namen den Menschen Mein Wort bringen sollten, das lebendige Wasser, das in Mir seinen Ursprung hat.... daß sie also zum Quell sich begeben müssen.
<G-vec00309-002-s056><go.begeben><en> Thus when I said to My disciples 'Baptise them in the name of the Father, the Son and the Holy Ghost'.... it is meant that they were to bring My Word to people in My name, the living water which originates from Me.... that people have to go to the source.
<G-vec00221-003-s038><go_along.begeben><de> Während ich hier noch die letzten Tage in Buenos Aires genieße, hat sich unser Jens am Freitag in meinem Auftrag auf die Blitz XIV Party begeben um dort ein paar fabelhafte Fotos für uns zu machen.
<G-vec00221-003-s038><go_along.begeben><en> While I am enjoying my last days in Buenos Aires our Jens was so kind to go to the Blitz party for me and take some photos.
<G-vec00221-003-s039><go_along.begeben><de> Hier begeben wir uns bei mehreren Pirschfahrten auf die Suche nach den Big 5.
<G-vec00221-003-s039><go_along.begeben><en> Here we go on several game drives in search of the Big 5.
<G-vec00221-003-s040><go_along.begeben><de> Zum Schlafen begeben sie sich in die Bäume.
<G-vec00221-003-s040><go_along.begeben><en> For sleeping they go into the trees.
<G-vec00221-003-s041><go_along.begeben><de> Zum Dîner begeben wir uns in eines der besten Restaurants der Stadt.
<G-vec00221-003-s041><go_along.begeben><en> For dinner, we go to one of the best restaurants in the city.
<G-vec00221-003-s042><go_along.begeben><de> Morgens stärken Sie sich bei einem herzhaften Frühstück und begeben sich anschließend zum Trekking in die Berglandschaft des Naturparks Ordesa.
<G-vec00221-003-s042><go_along.begeben><en> After a hearty breakfast in the morning, you can venture into the Ordesa's mountainous landscape, and go trekking.
<G-vec00221-003-s043><go_along.begeben><de> Gemeinsam begeben sie sich auf die Suche nach Travis' verschollener Frau Jane.
<G-vec00221-003-s043><go_along.begeben><en> Together, they go in search of Travis’ lost wife, Jane.
<G-vec00221-003-s044><go_along.begeben><de> Für Ihre Momente der Entspannung können Sie sich eine Sitzung im Schönheitssalon gönnen oder sich in den Billardraum begeben.
<G-vec00221-003-s044><go_along.begeben><en> To enjoy moments of relaxation, you can treat yourself to a beauty treatment, or go to the billiard room.
<G-vec00221-003-s045><go_along.begeben><de> Er gehörte einer Familie aus einfachen Verhältnissen an, wie wir dem Empfehlungsschreiben entnehmen können, das Bernhard von Clairvaux an Hilduin schrieb, den Oberen der Abtei von Saint Victor in Paris, um ihn zu bitten, Petrus, der sich aus Gründen des Studiums in jene Stadt begeben wollte, unentgeltlich aufzunehmen.
<G-vec00221-003-s045><go_along.begeben><en> He belonged to a modest family, as we may deduce from the letter of introduction that Bernard of Clairvaux wrote to Gilduin, Superior of the Abbey of Saint-Victor in Paris, asking him to give free accommodation to Peter who wanted to go to that city in order to study.
<G-vec00221-003-s046><go_along.begeben><de> Journalist Stefan Kreutzberger und Filmemacher Valentin Thurn begeben sich auf eine weltweite Suche nach zukunftsfähigen Lösungen für die Nahrungsmittelproduktion, die Mensch und Tier respektiert und die knappen Ressourcen schonen.
<G-vec00221-003-s046><go_along.begeben><en> Journalist Stefan Kreutzberger and filmmaker Valentin Thurn go on a worldwide search for a sustainable solution, which treats our nature with care and preserves its resources.
<G-vec00221-003-s047><go_along.begeben><de> Das Signal besteht aus 7 kurzen und 1 langem Signal, was bedeutet, dass sich jeder Passagier unverzüglich zur nächsten Rettungsstation begeben muss.
<G-vec00221-003-s047><go_along.begeben><en> In case of an emergency situation 7 short and 1 long signals will be used. It notifies people of the need to go to the nearest assembly station.
<G-vec00221-003-s048><go_along.begeben><de> Das bietet erheblich mehr Sicherheit, denn Sie müssen sich nicht in Gefahr begeben, um den Brandherd zu suchen.
<G-vec00221-003-s048><go_along.begeben><en> This offers considerably more security, because you do not have to go into danger to seek out the source of the fire.
<G-vec00221-003-s049><go_along.begeben><de> Dabei treffen sich die Kursteilnehmer 15 Minuten vor Beginn des Kurses an der Rezeption der Therme Meran, begeben sich gemeinsam in den Poolbereich und verlassen diesen 15 Minuten nach Kursende wieder gemeinsam.
<G-vec00221-003-s049><go_along.begeben><en> Course participants meet at the Terme Merano/Therme Meran reception 15 minutes before the course starts, they then go to the pool area together and leave again together 15 minutes after the course ends.
<G-vec00221-003-s050><go_along.begeben><de> Diese Fragen beschäftigen seit ein paar Jahren immer mehr Führungskräfte, und auch wenn es noch nicht in allen Bereichen den optimalen Weg gibt, so steht doch fest, dass es keine Option ist, sich nicht auf den Weg zu begeben.
<G-vec00221-003-s050><go_along.begeben><en> These questions have been the focus of an increasing number of managers since a few years, and although there is not yet the best way to go in all areas, it is clear that there is no option not to go.
<G-vec00221-003-s051><go_along.begeben><de> Heute, wie durch alle Jahrhunderte hindurch, lädt uns die Eucharistie leise aber hartnäckig ein, uns in das Obergemach zu begeben, wo die Eucharistie eingesetzt wurde und wo die Kirche als Gottes Familie geboren wurde, die ein Herz und eine Seele in der Communio mit Christus und untereinander ist.
<G-vec00221-003-s051><go_along.begeben><en> Today, just as it has been through the centuries, the Eucharist silently but tenaciously invites us to go back to the Upper Room where, by the institution of the Eucharist, the Church was born as ‘God’s family’, ‘one heart and one soul’ in communion with Christ and with one another.
<G-vec00221-003-s052><go_along.begeben><de> Nach dem Flug begeben wir uns zu den Buggies und fahren über die Sanddünen zu den Cahuchi Pyramiden, einem antiken zeremoniellen Zentrum und zu den Aquädukten, an denen Sie herausfinden werden, wie die Nazca Wasser durch die Stadt beförderten.
<G-vec00221-003-s052><go_along.begeben><en> Later after the flight we will go to the buggie cars and go through the sand dunes to the Cahuachi pyramids, an ancient ceremonial center, and then to the aqueducts where you will find out how the ancient Nazcans carried water across the city.
<G-vec00221-003-s053><go_along.begeben><de> Wenn Ihr Anschlussflug am Flughafen Gimpo abfliegt, begeben Sie sich zum Flughafen Gimpo und checken dort ein.
<G-vec00221-003-s053><go_along.begeben><en> If your connecting flight is departing from Gimpo Airport, you should go to Gimpo Airport and proceed to check in.
<G-vec00221-003-s054><go_along.begeben><de> Dabei müssen die arabischen Völker aus ihren eigenen Erfahrungen die richtigen Lehren ziehen, nämlich dass sie sich niemals unter den Schutz einer Großmacht begeben, um sich dadurch vermeintlich vor einer anderen Großmacht zu "schützen".
<G-vec00221-003-s054><go_along.begeben><en> The Arab peoples must draw the important lessons from their own negative historical experiences, namely that they never go under the protection of a great power in order to "protect" themselves from another great power.
<G-vec00221-003-s055><go_along.begeben><de> Um sich einzutragen müssen Sie sich mit Ihrem Personalausweis vor Ort am Schalter begeben und den Betrag von 50,- € vorzahlen.
<G-vec00221-003-s055><go_along.begeben><en> To register please go to the centre, taking your identity card with you and 50 €.
<G-vec00221-003-s056><go_along.begeben><de> Wenn Ich also zu Meinen Jüngern gesagt habe: Taufet sie im Namen des Vaters und des Sohnes und des heiligen Geistes.... so ist darunter nichts anderes zu verstehen, als daß sie in Meinem Namen den Menschen Mein Wort bringen sollten, das lebendige Wasser, das in Mir seinen Ursprung hat.... daß sie also zum Quell sich begeben müssen.
<G-vec00221-003-s056><go_along.begeben><en> Thus when I said to My disciples 'Baptise them in the name of the Father, the Son and the Holy Ghost'.... it is meant that they were to bring My Word to people in My name, the living water which originates from Me.... that people have to go to the source.
<G-vec00261-003-s038><go_on.begeben><de> Während ich hier noch die letzten Tage in Buenos Aires genieße, hat sich unser Jens am Freitag in meinem Auftrag auf die Blitz XIV Party begeben um dort ein paar fabelhafte Fotos für uns zu machen.
<G-vec00261-003-s038><go_on.begeben><en> While I am enjoying my last days in Buenos Aires our Jens was so kind to go to the Blitz party for me and take some photos.
<G-vec00261-003-s039><go_on.begeben><de> Hier begeben wir uns bei mehreren Pirschfahrten auf die Suche nach den Big 5.
<G-vec00261-003-s039><go_on.begeben><en> Here we go on several game drives in search of the Big 5.
<G-vec00261-003-s040><go_on.begeben><de> Zum Schlafen begeben sie sich in die Bäume.
<G-vec00261-003-s040><go_on.begeben><en> For sleeping they go into the trees.
<G-vec00261-003-s041><go_on.begeben><de> Zum Dîner begeben wir uns in eines der besten Restaurants der Stadt.
<G-vec00261-003-s041><go_on.begeben><en> For dinner, we go to one of the best restaurants in the city.
<G-vec00261-003-s042><go_on.begeben><de> Morgens stärken Sie sich bei einem herzhaften Frühstück und begeben sich anschließend zum Trekking in die Berglandschaft des Naturparks Ordesa.
<G-vec00261-003-s042><go_on.begeben><en> After a hearty breakfast in the morning, you can venture into the Ordesa's mountainous landscape, and go trekking.
<G-vec00261-003-s043><go_on.begeben><de> Gemeinsam begeben sie sich auf die Suche nach Travis' verschollener Frau Jane.
<G-vec00261-003-s043><go_on.begeben><en> Together, they go in search of Travis’ lost wife, Jane.
<G-vec00261-003-s044><go_on.begeben><de> Für Ihre Momente der Entspannung können Sie sich eine Sitzung im Schönheitssalon gönnen oder sich in den Billardraum begeben.
<G-vec00261-003-s044><go_on.begeben><en> To enjoy moments of relaxation, you can treat yourself to a beauty treatment, or go to the billiard room.
<G-vec00261-003-s045><go_on.begeben><de> Er gehörte einer Familie aus einfachen Verhältnissen an, wie wir dem Empfehlungsschreiben entnehmen können, das Bernhard von Clairvaux an Hilduin schrieb, den Oberen der Abtei von Saint Victor in Paris, um ihn zu bitten, Petrus, der sich aus Gründen des Studiums in jene Stadt begeben wollte, unentgeltlich aufzunehmen.
<G-vec00261-003-s045><go_on.begeben><en> He belonged to a modest family, as we may deduce from the letter of introduction that Bernard of Clairvaux wrote to Gilduin, Superior of the Abbey of Saint-Victor in Paris, asking him to give free accommodation to Peter who wanted to go to that city in order to study.
<G-vec00261-003-s046><go_on.begeben><de> Journalist Stefan Kreutzberger und Filmemacher Valentin Thurn begeben sich auf eine weltweite Suche nach zukunftsfähigen Lösungen für die Nahrungsmittelproduktion, die Mensch und Tier respektiert und die knappen Ressourcen schonen.
<G-vec00261-003-s046><go_on.begeben><en> Journalist Stefan Kreutzberger and filmmaker Valentin Thurn go on a worldwide search for a sustainable solution, which treats our nature with care and preserves its resources.
<G-vec00261-003-s047><go_on.begeben><de> Das Signal besteht aus 7 kurzen und 1 langem Signal, was bedeutet, dass sich jeder Passagier unverzüglich zur nächsten Rettungsstation begeben muss.
<G-vec00261-003-s047><go_on.begeben><en> In case of an emergency situation 7 short and 1 long signals will be used. It notifies people of the need to go to the nearest assembly station.
<G-vec00261-003-s048><go_on.begeben><de> Das bietet erheblich mehr Sicherheit, denn Sie müssen sich nicht in Gefahr begeben, um den Brandherd zu suchen.
<G-vec00261-003-s048><go_on.begeben><en> This offers considerably more security, because you do not have to go into danger to seek out the source of the fire.
<G-vec00261-003-s049><go_on.begeben><de> Dabei treffen sich die Kursteilnehmer 15 Minuten vor Beginn des Kurses an der Rezeption der Therme Meran, begeben sich gemeinsam in den Poolbereich und verlassen diesen 15 Minuten nach Kursende wieder gemeinsam.
<G-vec00261-003-s049><go_on.begeben><en> Course participants meet at the Terme Merano/Therme Meran reception 15 minutes before the course starts, they then go to the pool area together and leave again together 15 minutes after the course ends.
<G-vec00261-003-s050><go_on.begeben><de> Diese Fragen beschäftigen seit ein paar Jahren immer mehr Führungskräfte, und auch wenn es noch nicht in allen Bereichen den optimalen Weg gibt, so steht doch fest, dass es keine Option ist, sich nicht auf den Weg zu begeben.
<G-vec00261-003-s050><go_on.begeben><en> These questions have been the focus of an increasing number of managers since a few years, and although there is not yet the best way to go in all areas, it is clear that there is no option not to go.
<G-vec00261-003-s051><go_on.begeben><de> Heute, wie durch alle Jahrhunderte hindurch, lädt uns die Eucharistie leise aber hartnäckig ein, uns in das Obergemach zu begeben, wo die Eucharistie eingesetzt wurde und wo die Kirche als Gottes Familie geboren wurde, die ein Herz und eine Seele in der Communio mit Christus und untereinander ist.
<G-vec00261-003-s051><go_on.begeben><en> Today, just as it has been through the centuries, the Eucharist silently but tenaciously invites us to go back to the Upper Room where, by the institution of the Eucharist, the Church was born as ‘God’s family’, ‘one heart and one soul’ in communion with Christ and with one another.
<G-vec00261-003-s052><go_on.begeben><de> Nach dem Flug begeben wir uns zu den Buggies und fahren über die Sanddünen zu den Cahuchi Pyramiden, einem antiken zeremoniellen Zentrum und zu den Aquädukten, an denen Sie herausfinden werden, wie die Nazca Wasser durch die Stadt beförderten.
<G-vec00261-003-s052><go_on.begeben><en> Later after the flight we will go to the buggie cars and go through the sand dunes to the Cahuachi pyramids, an ancient ceremonial center, and then to the aqueducts where you will find out how the ancient Nazcans carried water across the city.
<G-vec00261-003-s053><go_on.begeben><de> Wenn Ihr Anschlussflug am Flughafen Gimpo abfliegt, begeben Sie sich zum Flughafen Gimpo und checken dort ein.
<G-vec00261-003-s053><go_on.begeben><en> If your connecting flight is departing from Gimpo Airport, you should go to Gimpo Airport and proceed to check in.
<G-vec00261-003-s054><go_on.begeben><de> Dabei müssen die arabischen Völker aus ihren eigenen Erfahrungen die richtigen Lehren ziehen, nämlich dass sie sich niemals unter den Schutz einer Großmacht begeben, um sich dadurch vermeintlich vor einer anderen Großmacht zu "schützen".
<G-vec00261-003-s054><go_on.begeben><en> The Arab peoples must draw the important lessons from their own negative historical experiences, namely that they never go under the protection of a great power in order to "protect" themselves from another great power.
<G-vec00261-003-s055><go_on.begeben><de> Um sich einzutragen müssen Sie sich mit Ihrem Personalausweis vor Ort am Schalter begeben und den Betrag von 50,- € vorzahlen.
<G-vec00261-003-s055><go_on.begeben><en> To register please go to the centre, taking your identity card with you and 50 €.
<G-vec00261-003-s056><go_on.begeben><de> Wenn Ich also zu Meinen Jüngern gesagt habe: Taufet sie im Namen des Vaters und des Sohnes und des heiligen Geistes.... so ist darunter nichts anderes zu verstehen, als daß sie in Meinem Namen den Menschen Mein Wort bringen sollten, das lebendige Wasser, das in Mir seinen Ursprung hat.... daß sie also zum Quell sich begeben müssen.
<G-vec00261-003-s056><go_on.begeben><en> Thus when I said to My disciples 'Baptise them in the name of the Father, the Son and the Holy Ghost'.... it is meant that they were to bring My Word to people in My name, the living water which originates from Me.... that people have to go to the source.
<G-vec00316-003-s038><go_through.begeben><de> Während ich hier noch die letzten Tage in Buenos Aires genieße, hat sich unser Jens am Freitag in meinem Auftrag auf die Blitz XIV Party begeben um dort ein paar fabelhafte Fotos für uns zu machen.
<G-vec00316-003-s038><go_through.begeben><en> While I am enjoying my last days in Buenos Aires our Jens was so kind to go to the Blitz party for me and take some photos.
<G-vec00316-003-s039><go_through.begeben><de> Hier begeben wir uns bei mehreren Pirschfahrten auf die Suche nach den Big 5.
<G-vec00316-003-s039><go_through.begeben><en> Here we go on several game drives in search of the Big 5.
<G-vec00316-003-s040><go_through.begeben><de> Zum Schlafen begeben sie sich in die Bäume.
<G-vec00316-003-s040><go_through.begeben><en> For sleeping they go into the trees.
<G-vec00316-003-s041><go_through.begeben><de> Zum Dîner begeben wir uns in eines der besten Restaurants der Stadt.
<G-vec00316-003-s041><go_through.begeben><en> For dinner, we go to one of the best restaurants in the city.
<G-vec00316-003-s042><go_through.begeben><de> Morgens stärken Sie sich bei einem herzhaften Frühstück und begeben sich anschließend zum Trekking in die Berglandschaft des Naturparks Ordesa.
<G-vec00316-003-s042><go_through.begeben><en> After a hearty breakfast in the morning, you can venture into the Ordesa's mountainous landscape, and go trekking.
<G-vec00316-003-s043><go_through.begeben><de> Gemeinsam begeben sie sich auf die Suche nach Travis' verschollener Frau Jane.
<G-vec00316-003-s043><go_through.begeben><en> Together, they go in search of Travis’ lost wife, Jane.
<G-vec00316-003-s044><go_through.begeben><de> Für Ihre Momente der Entspannung können Sie sich eine Sitzung im Schönheitssalon gönnen oder sich in den Billardraum begeben.
<G-vec00316-003-s044><go_through.begeben><en> To enjoy moments of relaxation, you can treat yourself to a beauty treatment, or go to the billiard room.
<G-vec00316-003-s045><go_through.begeben><de> Er gehörte einer Familie aus einfachen Verhältnissen an, wie wir dem Empfehlungsschreiben entnehmen können, das Bernhard von Clairvaux an Hilduin schrieb, den Oberen der Abtei von Saint Victor in Paris, um ihn zu bitten, Petrus, der sich aus Gründen des Studiums in jene Stadt begeben wollte, unentgeltlich aufzunehmen.
<G-vec00316-003-s045><go_through.begeben><en> He belonged to a modest family, as we may deduce from the letter of introduction that Bernard of Clairvaux wrote to Gilduin, Superior of the Abbey of Saint-Victor in Paris, asking him to give free accommodation to Peter who wanted to go to that city in order to study.
<G-vec00316-003-s046><go_through.begeben><de> Journalist Stefan Kreutzberger und Filmemacher Valentin Thurn begeben sich auf eine weltweite Suche nach zukunftsfähigen Lösungen für die Nahrungsmittelproduktion, die Mensch und Tier respektiert und die knappen Ressourcen schonen.
<G-vec00316-003-s046><go_through.begeben><en> Journalist Stefan Kreutzberger and filmmaker Valentin Thurn go on a worldwide search for a sustainable solution, which treats our nature with care and preserves its resources.
<G-vec00316-003-s047><go_through.begeben><de> Das Signal besteht aus 7 kurzen und 1 langem Signal, was bedeutet, dass sich jeder Passagier unverzüglich zur nächsten Rettungsstation begeben muss.
<G-vec00316-003-s047><go_through.begeben><en> In case of an emergency situation 7 short and 1 long signals will be used. It notifies people of the need to go to the nearest assembly station.
<G-vec00316-003-s048><go_through.begeben><de> Das bietet erheblich mehr Sicherheit, denn Sie müssen sich nicht in Gefahr begeben, um den Brandherd zu suchen.
<G-vec00316-003-s048><go_through.begeben><en> This offers considerably more security, because you do not have to go into danger to seek out the source of the fire.
<G-vec00316-003-s049><go_through.begeben><de> Dabei treffen sich die Kursteilnehmer 15 Minuten vor Beginn des Kurses an der Rezeption der Therme Meran, begeben sich gemeinsam in den Poolbereich und verlassen diesen 15 Minuten nach Kursende wieder gemeinsam.
<G-vec00316-003-s049><go_through.begeben><en> Course participants meet at the Terme Merano/Therme Meran reception 15 minutes before the course starts, they then go to the pool area together and leave again together 15 minutes after the course ends.
<G-vec00316-003-s050><go_through.begeben><de> Diese Fragen beschäftigen seit ein paar Jahren immer mehr Führungskräfte, und auch wenn es noch nicht in allen Bereichen den optimalen Weg gibt, so steht doch fest, dass es keine Option ist, sich nicht auf den Weg zu begeben.
<G-vec00316-003-s050><go_through.begeben><en> These questions have been the focus of an increasing number of managers since a few years, and although there is not yet the best way to go in all areas, it is clear that there is no option not to go.
<G-vec00316-003-s051><go_through.begeben><de> Heute, wie durch alle Jahrhunderte hindurch, lädt uns die Eucharistie leise aber hartnäckig ein, uns in das Obergemach zu begeben, wo die Eucharistie eingesetzt wurde und wo die Kirche als Gottes Familie geboren wurde, die ein Herz und eine Seele in der Communio mit Christus und untereinander ist.
<G-vec00316-003-s051><go_through.begeben><en> Today, just as it has been through the centuries, the Eucharist silently but tenaciously invites us to go back to the Upper Room where, by the institution of the Eucharist, the Church was born as ‘God’s family’, ‘one heart and one soul’ in communion with Christ and with one another.
<G-vec00316-003-s052><go_through.begeben><de> Nach dem Flug begeben wir uns zu den Buggies und fahren über die Sanddünen zu den Cahuchi Pyramiden, einem antiken zeremoniellen Zentrum und zu den Aquädukten, an denen Sie herausfinden werden, wie die Nazca Wasser durch die Stadt beförderten.
<G-vec00316-003-s052><go_through.begeben><en> Later after the flight we will go to the buggie cars and go through the sand dunes to the Cahuachi pyramids, an ancient ceremonial center, and then to the aqueducts where you will find out how the ancient Nazcans carried water across the city.
<G-vec00316-003-s053><go_through.begeben><de> Wenn Ihr Anschlussflug am Flughafen Gimpo abfliegt, begeben Sie sich zum Flughafen Gimpo und checken dort ein.
<G-vec00316-003-s053><go_through.begeben><en> If your connecting flight is departing from Gimpo Airport, you should go to Gimpo Airport and proceed to check in.
<G-vec00316-003-s054><go_through.begeben><de> Dabei müssen die arabischen Völker aus ihren eigenen Erfahrungen die richtigen Lehren ziehen, nämlich dass sie sich niemals unter den Schutz einer Großmacht begeben, um sich dadurch vermeintlich vor einer anderen Großmacht zu "schützen".
<G-vec00316-003-s054><go_through.begeben><en> The Arab peoples must draw the important lessons from their own negative historical experiences, namely that they never go under the protection of a great power in order to "protect" themselves from another great power.
<G-vec00316-003-s055><go_through.begeben><de> Um sich einzutragen müssen Sie sich mit Ihrem Personalausweis vor Ort am Schalter begeben und den Betrag von 50,- € vorzahlen.
<G-vec00316-003-s055><go_through.begeben><en> To register please go to the centre, taking your identity card with you and 50 €.
<G-vec00316-003-s056><go_through.begeben><de> Wenn Ich also zu Meinen Jüngern gesagt habe: Taufet sie im Namen des Vaters und des Sohnes und des heiligen Geistes.... so ist darunter nichts anderes zu verstehen, als daß sie in Meinem Namen den Menschen Mein Wort bringen sollten, das lebendige Wasser, das in Mir seinen Ursprung hat.... daß sie also zum Quell sich begeben müssen.
<G-vec00316-003-s056><go_through.begeben><en> Thus when I said to My disciples 'Baptise them in the name of the Father, the Son and the Holy Ghost'.... it is meant that they were to bring My Word to people in My name, the living water which originates from Me.... that people have to go to the source.
