<G-vec00272-001-s023><beg.anbetteln><de> Ich hasse es, dass sie Katherine wegen mir anbetteln muss.
<G-vec00272-001-s023><beg.anbetteln><en> I hate it that she has to beg Katherine for me.
