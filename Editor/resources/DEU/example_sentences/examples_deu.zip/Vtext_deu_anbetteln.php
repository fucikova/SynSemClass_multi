<G-vec00272-001-s023><beg.anbetteln><de> Ich hasse es, dass sie Katherine wegen mir anbetteln muss.
<G-vec00272-001-s023><beg.anbetteln><en> I hate it that she has to beg Katherine for me.
<G-vec00272-002-s025><beg.anbetteln><de> Dann würde sie ihn anbetteln, anflehen, dass er ihr Beachtung schenkte.
<G-vec00272-002-s025><beg.anbetteln><en> Then she would beg him, imploring him to pay attention.
