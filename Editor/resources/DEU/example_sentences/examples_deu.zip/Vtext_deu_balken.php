<G-vec00367-002-s076><bar.balken><de> Jeder Balken für den Interaktionstyp öffnet dieselben Daten, unabhängig von der Kategorie.
<G-vec00367-002-s076><bar.balken><en> Each bar for the interaction type opens the same data, regardless of the category.
<G-vec00367-002-s077><bar.balken><de> Auf der linken Seite finden Sie im grünen Balken unser Schnellmenü.
<G-vec00367-002-s077><bar.balken><en> On the left side, you can find the quick menu inside the green bar.
<G-vec00367-002-s078><bar.balken><de> Registerkartenansicht zeigt die Grafiken in Werte mit einer Linie, Balken zeigt einen Balken für jeden Wert.
<G-vec00367-002-s078><bar.balken><en> Chart type. Line connects values with a line, Bar displays a bar for each value.
<G-vec00367-002-s080><bar.balken><de> Wenn der Balken voll ist, erreicht das Pantheon das nächste Level und sowohl seine Reichweite als auch seine Produktion wird gesteigert.
<G-vec00367-002-s080><bar.balken><en> Once the progress bar is full, the Beacon will upgrade to the next level and its range and power will increase.
<G-vec00367-002-s081><bar.balken><de> Um den Content Optimizer komplett zu schließen, können Sie ganz einfach oben rechts im Balken auf den Pfeil klicken.
<G-vec00367-002-s081><bar.balken><en> To completely close the Content Optimizer, you can simply click the arrow in the upper right corner of the bar.
<G-vec00367-002-s082><bar.balken><de> Der rote Balken zeigt dabei die aktuelle Position der 3D Ansicht.
<G-vec00367-002-s082><bar.balken><en> The red bar shows the current position of
<G-vec00367-002-s083><bar.balken><de> Logik in BrightScript implementiert, um die Anzahl der Spins des Fidget Spinner zu berechnen, bevor der rote Balken das Ende erreicht oder die Kraft beendet.
<G-vec00367-002-s083><bar.balken><en> Implemented logic in BrightScript for calculating the number of spins of the Fidget Spinner before the red bar reaches the end or finish the power.
<G-vec00367-002-s084><bar.balken><de> Bewegen Sie den Cursor über den blauen Balken am Bildschirmrand, um OneClick anzuzeigen.
<G-vec00367-002-s084><bar.balken><en> Hover your cursor over the blue bar on the edge of your screen to expand the OneClick options.
<G-vec00367-002-s085><bar.balken><de> Das Zeitlimit für die Beantwortung der Frage wird von dem Balken über der Figur angezeigt.
<G-vec00367-002-s085><bar.balken><en> The time limit of answering the question will be displayed by the bar above the figure.
<G-vec00367-002-s086><bar.balken><de> Rechts daneben ein Balken, der die Ausdauer des Rangers darstellt.
<G-vec00367-002-s086><bar.balken><en> At the right next to it is the bar, which shows the ranger's endurance.
<G-vec00367-002-s087><bar.balken><de> Du gehst auf die nächste Stufe, wenn du den Balken oben füllen kannst.
<G-vec00367-002-s087><bar.balken><en> You go to the next level, if you can fill up the bar.
<G-vec00367-002-s088><bar.balken><de> Wir haben den Balken markiert, wo es ganz oben nur 22 Marketkaufaufträge gibt – vergleichen Sie ihn mit der Menge zum Zeitpunkt des Preisanstiegs – 614, 932, 786, mit der Nummer 3.
<G-vec00367-002-s088><bar.balken><en> We marked the bar, where there are only 22 market buy orders on the very top – compare it with the quantity at the moment of the price growth – 614,932,786, with number 3.
<G-vec00367-002-s089><bar.balken><de> 1: Der blaue Balken zeigt die Besuche vom ersten gewählten Zeitraum.
<G-vec00367-002-s089><bar.balken><en> 1: The blue bar shows you the page views per visits for the first selected period.
<G-vec00367-002-s090><bar.balken><de> Ist der grüne Balken höher, hat der Spieler/das Team mehr Spiele gewonnen als verloren.
<G-vec00367-002-s090><bar.balken><en> If the green bar is higher, the player/team has won more games than lost.
<G-vec00367-002-s091><bar.balken><de> Ein Balken wird angezeigt und du solltest auf "Einstellungen" klicken.
<G-vec00367-002-s091><bar.balken><en> A bar will appear, you should click on "Settings."
<G-vec00367-002-s092><bar.balken><de> Bei voll aufgezogenem Uhrwerk wird ein komplett weißer und bei abnehmender Gangreserve ein zunehmend blauer Balken angezeigt.
<G-vec00367-002-s092><bar.balken><en> When the movement is fully wound, a completely white bar is displayed and when the power reserve decreases, an increasingly blue bar is displayed.
<G-vec00367-002-s093><bar.balken><de> Wenn Sie alle für Sie relevanten Veranstaltungen ausgewählt haben, klicken Sie oben im schwarzen Balken auf „Sammlung/Stundenplan“.
<G-vec00367-002-s093><bar.balken><en> When you have chosen all relevant courses, click ‘collection/class schedule’ in the black bar at the top left.
<G-vec00367-002-s094><bar.balken><de> Sie können den Konvertierungsfortschritt am violetten Balken ablesen.
<G-vec00367-002-s094><bar.balken><en> Instantly, you can see a purple bar showing you the conversion progress.
