<G-vec00518-002-s019><sleep.ausschlafen><de> Nur sonntags konnten wir ausschlafen, wenn keine Badegäste kamen.
<G-vec00518-002-s019><sleep.ausschlafen><en> Only on Sundays we could sleep if no bathing guests would arrive.
<G-vec00518-002-s020><sleep.ausschlafen><de> Auch heute morgen konnten wir wieder ausschlafen.
<G-vec00518-002-s020><sleep.ausschlafen><en> Also today we could have a long sleep.
<G-vec00518-002-s021><sleep.ausschlafen><de> Heute will ich mich erstmal ausschlafen und mein Großer fühlt sich nun endlich, nachdem er Antibiotika bekommen hat, besser.
<G-vec00518-002-s021><sleep.ausschlafen><en> I want to sleep since my elder son is finally feeling better. He got antibiotics.
<G-vec00518-002-s022><sleep.ausschlafen><de> Und sollte sich der eine oder andere Regentag einschleichen, wird ein ansehnliches Angebot an Intressantem und Wissenswertem aus unserer Umgebung und Kultur, Sie davon abhalten, den Tag zum Ausschlafen zu nützen.
<G-vec00518-002-s022><sleep.ausschlafen><en> And should one or another rainy day creep, a considerable range of intresting and valuable information from our environment and culture, you stop them to use the day to sleep late.
<G-vec00518-002-s023><sleep.ausschlafen><de> Eine Möglichkeit: lange ausschlafen.
<G-vec00518-002-s023><sleep.ausschlafen><en> One possibility: to sleep late.
<G-vec00518-002-s024><sleep.ausschlafen><de> Nach dem langen Flug waren wir alle froh ausschlafen zu können.
<G-vec00518-002-s024><sleep.ausschlafen><en> After the long flight, we are all glad to be able to sleep long and deeply.
<G-vec00518-002-s025><sleep.ausschlafen><de> Das Schöne in Lo Stagnone Kitespot ist, dass man morgens ausschlafen kann; Der Wind beginnt in der Regel um die Mittagszeit und flaut erst spät abends ab.
<G-vec00518-002-s025><sleep.ausschlafen><en> The nice thing about Lo Stagnone Kitespot is that you can sleep in the morning; the wind usually starts at noon and calms down late in the evening.
<G-vec00518-002-s026><sleep.ausschlafen><de> Ebenso ist ausschlafen bis in den Nachmittag nicht empfehlenswert, dann kann die nächste Nacht noch schlimmer werden.
<G-vec00518-002-s026><sleep.ausschlafen><en> Don’t sleep in until the afternoon or the next night will be all the worse.
<G-vec00518-002-s027><sleep.ausschlafen><de> Oder Sie könnten einfach ausschlafen.
<G-vec00518-002-s027><sleep.ausschlafen><en> Or you could just sleep in.
<G-vec00518-002-s028><sleep.ausschlafen><de> An der alten Poststraße lagen die Gasthäuser, in denen müde Reisende zu Pferd oder zu Schiff sich ausschlafen und mit einer Mahlzeit stärken konnten.
<G-vec00518-002-s028><sleep.ausschlafen><en> Along the old postal route there were inns where tired travelers on horseback and by boat could get a good night’s sleep and a square meal.
<G-vec00518-002-s029><sleep.ausschlafen><de> Wenn Sie ein Westin Weekend buchen, bieten wir Ihnen deswegen Check-out um 15.00 Uhr an, sodass Sie noch etwas länger ausschlafen oder Ihr Reiseziel weiter erkunden können.
<G-vec00518-002-s029><sleep.ausschlafen><en> That’s why when you book a Westin Weekend, we offer 3pm checkout so you can sleep later or explore the destination longer.
<G-vec00518-002-s030><sleep.ausschlafen><de> Dann sorgen wir für das Ausmisten des Stalls und führen wir Ihr Pferd morgens aus, sodass Sie in aller Ruhe ausschlafen können.
<G-vec00518-002-s030><sleep.ausschlafen><en> We will muck out the box and groom and feed your horse in the morning while you can relax and sleep late.
<G-vec00518-002-s031><sleep.ausschlafen><de> Und sollte sich der Business Traveller nach seinen Geschäftsterminen zu lange auf der Reeperbahn amüsiert haben, kann er bei MEININGER jederzeit einchecken und mit dem Late Checkout am nächsten Morgen gemütlich ausschlafen.
<G-vec00518-002-s031><sleep.ausschlafen><en> And just in case the business traveller spent too long amusing himself at the Reeperbahn then he can check into MEININGER at any time and have a leisurely sleep in the next morning with late check-out. FAMILIES
<G-vec00518-002-s032><sleep.ausschlafen><de> Heute ist mal Ausschlafen und Frühstücken auf dem Campground angesagt.
<G-vec00518-002-s032><sleep.ausschlafen><en> Today it is time to sleep out and have breakfast on the campground.
<G-vec00518-002-s033><sleep.ausschlafen><de> Eigentlich können wir ausschlafen, aber gegen 5 Uhr war die Nacht - dank den "Bremer Stadtmusikanten" zu Ende.
<G-vec00518-002-s033><sleep.ausschlafen><en> Actually, we could sleep in, but around 5 am the night has been finished - thanks to the "Bremen Town Musicians".
<G-vec00518-002-s034><sleep.ausschlafen><de> Ich hoffe doch, dass dann alle abgereist sind, damit wir richtig ausschlafen können.
<G-vec00518-002-s034><sleep.ausschlafen><en> I’m hoping everyone will have left so that we can catch up on some sleep.”
<G-vec00518-002-s035><sleep.ausschlafen><de> So kann also ein Bewohner Frühstück machen und der Andere darf ausschlafen, abends kann einer schon schlafen gehen, während der Andere noch in Ruhe sitzenbleiben kann.
<G-vec00518-002-s035><sleep.ausschlafen><en> So one inhabitant can make breakfast and the other can sleep late, in the evening one can go to sleep while the other can still sit quietly.
<G-vec00518-002-s036><sleep.ausschlafen><de> Zum Beispiel: schlafen ü ausschlafen, fee – kostenlos.
<G-vec00518-002-s036><sleep.ausschlafen><en> For example: sleep – to sleep, fee – free.
<G-vec00518-002-s037><sleep.ausschlafen><de> Dementsprechend konnte ich wieder ausschlafen.
<G-vec00518-002-s037><sleep.ausschlafen><en> So I can sleep long again.
