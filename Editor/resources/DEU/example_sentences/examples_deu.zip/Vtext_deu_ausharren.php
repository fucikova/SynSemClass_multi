<G-vec00261-002-s058><persist.ausharren><de> Ja, das ist die Zeit, in der du ausharren musst, bis du in deinem inneren Bewusstsein ganz gefestigt bist, und die Nachhaltigkeit des Schweigens und Friedens ist ein Zeichen, dass es jetzt möglich ist.
<G-vec00261-002-s058><persist.ausharren><en> Yes, this is the time when you have to persist till you are quite settled in the inner consciousness and the persistence of the silence and peace is a sign that it is now possible.
<G-vec00261-002-s059><persist.ausharren><de> Es ist die alte Gewohnheit des Vitals, die dich immer wieder in den äußeren Teil [der Natur] hinaustreten lässt; du musst ausharren und die entgegensetzte Gewohnheit festigen, in deinem inneren Wesen, deinem wahren Wesen zu leben und alles von dorther zu betrachten.
<G-vec00261-002-s059><persist.ausharren><en> It is the past habit of the vital that makes you repeatedly go out into the external part; you must persist and establish the opposite habit of living in your inner being which is your true being and of looking at everything from there.
<G-vec00491-002-s059><endure.ausharren><de> 13 Wer aber ausharrt bis ans Ende, wird gerettet werden.
<G-vec00491-002-s059><endure.ausharren><en> 13 But he that shall endure unto the end, the same shall be saved.
<G-vec00491-002-s060><endure.ausharren><de> 24:13 wer aber ausharrt bis ans Ende, der wird errettet werden.
<G-vec00491-002-s060><endure.ausharren><en> 24:13 But he that shall endure unto the end, the same shall be saved.
<G-vec00491-002-s061><endure.ausharren><de> 13 (ELB) Und ihr werdet von allen gehaßt werden um meines Namens willen; wer aber ausharrt bis ans Ende, dieser wird errettet werden.
<G-vec00491-002-s061><endure.ausharren><en> 13 (UKJV) And all of you shall be hated of all men for my name's sake: but he that shall endure unto the end, the same shall be saved.
<G-vec00491-002-s062><endure.ausharren><de> Mk 13:13 - Und ihr werdet von allen gehaßt werden um meines Namens willen; wer aber ausharrt bis ans Ende, dieser wird errettet werden.
<G-vec00491-002-s062><endure.ausharren><en> Mk 13:13 - And ye shall be hated of all men for my name's sake: but he that shall endure unto the end, the same shall be saved.
<G-vec00491-002-s063><endure.ausharren><de> Matthäus 24/13 wer aber ausharrt bis ans Ende, dieser wird errettet werden.
<G-vec00491-002-s063><endure.ausharren><en> Matthew 24/13 But he that shall endure unto the end, the same shall be saved.
