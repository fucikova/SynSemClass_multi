<G-vec00001-001-s097><erect.aufstellen><de> Theater, die eine Bildwand aufstellen können, deren Breite mindestens die Hälfte der Saallänge beträgt, besser noch drei Fünftel davon, eignen sich besonders für den 70mm-Film.
<G-vec00001-001-s097><erect.aufstellen><en> Venues that can erect a screen that is at least half as wide as the auditorium is long, or even better three fifths as wide, are particularly well suited to screening 70mm movies.
<G-vec00001-001-s098><erect.aufstellen><de> Aufstellen, anschließen, befüllen und los gehts - einfach genial.
<G-vec00001-001-s098><erect.aufstellen><en> Erect, connect, fill, and there you go - simply brilliant.
<G-vec00001-001-s099><erect.aufstellen><de> Wir dürfen immer wieder neue Geräte aufstellen, um sie Kunden und Partnern in Aktion zeigen zu können.
<G-vec00001-001-s099><erect.aufstellen><en> We're allowed to erect new equipment repeatedly in order to show it in action to customers and partners.
<G-vec00001-001-s100><erect.aufstellen><de> Wenn das Fahrzeug auf dem Außenparkplatz abgestellt wird, können wir den Wischer aufstellen, um den Kontakt zwischen der Wischleiste und dem heißen Glas zu reduzieren, um die Lebensdauer des Wischers zu verlängern.
<G-vec00001-001-s100><erect.aufstellen><en> Therefore, when the vehicle is parked in the outdoor parking lot, we can erect the wiper to reduce the contact between the wiper strip and the hot glass to extend the life of the wiper.
<G-vec00001-001-s076><establish.aufstellen><de> Im allgemeinen Rahmen der Gesetze, Dekrete und Verordnungen über den Berufsverband, die professionellen Familien, Berufe oder Berufsgruppen, werden die besonderen Verordnungen aufstellen, die ihre eigene Organisation definieren werden.
<G-vec00001-001-s076><establish.aufstellen><en> Within the general framework of the laws, decrees and payments relative with the professional organization, the professional families, professions or groups of professions, will establish the particular payments which will define their own organization.
<G-vec00001-001-s077><establish.aufstellen><de> Durch den Tod Christi wollte Gott ein Kriterium des Glaubens aufstellen, um die wahren Gläubigen von den Zionisten zu trennen.
<G-vec00001-001-s077><establish.aufstellen><en> By the Messiah's death, God intended to establish a faith criterion to separate the true believers from the Zionist.
<G-vec00001-001-s078><establish.aufstellen><de> Bulpros kann ein engagiertes Team von Entwicklern aufstellen, das zur Verfügung steht, um unter der Projektleitung des Kunden zu arbeiten, wenn dies erforderlich ist.
<G-vec00001-001-s078><establish.aufstellen><en> BULPROS can establish a dedicated team of professionals fully capable to work under internal or external project management.
<G-vec00001-001-s079><establish.aufstellen><de> Ob sich nun Adidas, Nike und Co. mit ihren Apps oder ihren Beteiligungen an digitalen Unternehmen für die Zukunft neu erfinden oder Vereine ihre Vermarktung über Influencer optimaler aufstellen müssen.
<G-vec00001-001-s079><establish.aufstellen><en> Whether it's Adidas, Nike and others reinventing themselves for the future with apps or investments in digital companies, or clubs having to better establish their marketing through influencers.
<G-vec00001-001-s080><establish.aufstellen><de> Was sie kann, ist ein Doppeltes: Sie kann erstens eigene Kriterien fÃ1⁄4r ihr Handeln aufstellen – Kampf gegen jede Form von totalitärer Herrschaft und Barbarei, Kampf gegen Marktradikalismus, Autoritarismus und Militarisierung sowie Kampf fÃ1⁄4r die ZurÃ1⁄4ckdrängung von Profitdominanz und Vorherrschaft der Kapitalverwertung, fÃ1⁄4r den Ausbau der öffentlichen Daseinsvorsorge, der öffentlichen demokratischen Steuerung eines sozialen, ökologischen und zivilen Umbaus der Gesellschaft.
<G-vec00001-001-s080><establish.aufstellen><en> There are two things which it can do: First of all, it can establish criteria for its own action – struggle against any form of totalitarian rule and barbarism, struggle against market radicalism, authoritarianism and militarisation as well as struggle for the roll-back of profit dominance and the rule of capital, for the extension of public services, of public, democratic control, and for a social ecological and civil reconstruction of society.
<G-vec00001-001-s081><establish.aufstellen><de> Das funktioniert nur, wenn sie sich als Service-Broker für interne und externe IT-Services aufstellen und sich als partnerschaftlicher Dienstleister verstehen.
<G-vec00001-001-s081><establish.aufstellen><en> This only works if they establish themselves as a service broker for internal and external IT services and see themselves as a cooperative partner (service provider).
<G-vec00001-001-s082><establish.aufstellen><de> Ich will sagen, daß die Menschen (bis jetzt und immer mehr) entsprechend ihren Konzeptionen und ihrem Ideal gewohnheitsmäßig mentale Regeln aufstellen und sie dann anwenden (Mutter senkt ihre Faust, um die Welt unter der Fuchtel des Mentals zu zeigen).
<G-vec00001-001-s082><establish.aufstellen><en> What I mean is that usually (always so far, and more and more so), men establish mental rules according to their conceptions and their ideal, then they apply them (Mother lowers her fist, as if to show the world under the mental grip).
<G-vec00001-001-s083><establish.aufstellen><de> Freier Wille heißt nicht, dass du den Lehrplan aufstellen kannst.
<G-vec00001-001-s083><establish.aufstellen><en> Free will does not mean that you can establish the curriculum.
<G-vec00001-001-s084><establish.aufstellen><de> Das Übereinkommen solle klare Ziele aufstellen und Wege zu ihrer Überwachung festlegen.
<G-vec00001-001-s084><establish.aufstellen><en> The agreement should set clear targets and establish ways to monitor them.
<G-vec00001-001-s085><establish.aufstellen><de> Da kann ich auch eine persoenliche Bestleistung aufstellen: 2 Lachse mit 5 Wuerfen.
<G-vec00001-001-s085><establish.aufstellen><en> Where I can establish a personal record: 2 salmon with 5 casts.
<G-vec00001-001-s086><establish.aufstellen><de> Ich will keine Regeln aufstellen.
<G-vec00001-001-s086><establish.aufstellen><en> I'm not going to establish any rules.
<G-vec00001-001-s087><establish.aufstellen><de> Die Worte, die du von ihm zitierst, könnten sowohl Ausdruck eines einfachen Glaubens als auch einer pantheistischen Erfahrung sein; es ist ersichtlich, dass sie, falls sie besagen oder die These aufstellen wollen, das Göttliche sei überall und alles und dass daher alles gut, da göttlich sei, für diesen Zweck sehr unzulänglich sind.
<G-vec00001-001-s087><establish.aufstellen><en> The words you quote from him could be expressions either of a simple faith or of a pantheistic experience; evidently, if they are used or intended to establish the thesis that the Divine is everywhere and is all and therefore all is good, being Divine, they are very insufficient for that purpose.
<G-vec00001-001-s088><establish.aufstellen><de> Dieselben Verse, die die Eingebung der Schriften aufstellen, weisen auch auf, dass sie fehlerfrei und maßgebend sind.
<G-vec00001-001-s088><establish.aufstellen><en> The same verses that establish the inspiration of the Scriptures also establish that it is both inerrant and authoritative.
<G-vec00001-001-s089><establish.aufstellen><de> Wir kontrollieren weder diese Social Media noch Ihre jeweiligen Profile und wir können weder Ihre Datenschutzeinstellungen bei diesen Diensten ändern noch Regeln dazu aufstellen, wie Ihre persönlichen Informationen bei diesen Diensten verwendet werden.
<G-vec00001-001-s089><establish.aufstellen><en> We do not control those social media services and your profiles on those services, and we cannot change your privacy settings on those services or establish rules about how your personal information on those services will be treated.
<G-vec00001-001-s090><establish.aufstellen><de> Verbände können Regeln für branchenspezifische Datenverarbeitungen aufstellen und von den Aufsichtsbehörden freigeben lassen.
<G-vec00001-001-s090><establish.aufstellen><en> Associations may establish rules for industry-specific processing and have them approved by the supervisory authorities.
<G-vec00001-001-s091><establish.aufstellen><de> Um eine aufeinander abgestimmte Entwicklung der Forschungen zu erleichtern, wird die Europäische Kommission hinweisende Projektionsziele für die Kernenergie aufstellen, die die Erfordernisse im Rahmen des gegebenen Bedarfs umreißen.
<G-vec00001-001-s091><establish.aufstellen><en> In order to facilitate the coordinated development of research, the European Commission would have to establish indicative production targets for nuclear energy, which would define the scale of the effort to be made within the context of actual requirements.
<G-vec00001-001-s092><establish.aufstellen><de> Wenn du für eine dieser Optionen gehst, musst du dich selbst aufstellen, aber das ist in beiden Fällen wirklich einfach.
<G-vec00001-001-s092><establish.aufstellen><en> If you go for one of these options, you need to establish yourself even, but that's really simple in both cases.
<G-vec00001-001-s093><establish.aufstellen><de> Im bürokratischen Modell wird die Autorität das möglichste in unpersönlicher Regel konvertiert, und die selben Strukturen der Organisation scheinen so angeordnet, daß eine ausreichende Distanz zwischen den Leuten aufstellen kann, die haben, Entscheidungen zu treffen und jene, die durch diese Entscheidungen betroffen sind.
<G-vec00001-001-s093><establish.aufstellen><en> In the bureaucratic model, the authority is converted as much as possible into impersonal rule and the same structures of the organization seem arranged so that a sufficient distance can establish between people who have to make decisions and those which are affected by these decisions.
<G-vec00001-001-s094><establish.aufstellen><de> Eine völlige Abkehr von Biotreibstoffen lehnt Dimas ab, vielmehr müsse die EU Kriterien für Nachhaltigkeit, einschließlich der Sozial- und Umweltverträglichkeit aufstellen.
<G-vec00001-001-s094><establish.aufstellen><en> Dimas declined a complete renunciation from biofuels, but stressed that the EU had to establish criteria for sustainability, including the social and environmental compatibility.
<G-vec00001-001-s112><erect.aufstellen><de> Während die Politik versucht, allgemein gültige Regeln aufzustellen, Ordnung für eine Gemeinschaft zu schaffen, widmet sich die Kunst der subjektiven Wahrheit, den individuellen Lebensentwürfen.
<G-vec00001-001-s112><erect.aufstellen><en> While politics attempts to erect universally valid rules, to create order in a community, art is dedicated to subjective truth, to individual life projects.
<G-vec00001-001-s113><erect.aufstellen><de> Plötzlich habe er sich der wunderbaren Erzählungenvom Kreuzberg erinnert und gelobt, dort ein Kreuz aufzustellen, wenn er überleben sollte.
<G-vec00001-001-s113><erect.aufstellen><en> Suddenly he had recalled some remarkable tales about the Hill of Crosses, and he had resolved that, if he survived, he would erect a cross there.
<G-vec00001-001-s114><erect.aufstellen><de> Grund genug für die Bewohner, im Rahmen der 950-Jahr-Feier eine Bronzestatue aufzustellen und seit 2010 alljährlich eine „Käsfraa“ zu bestimmen.
<G-vec00001-001-s114><erect.aufstellen><en> Reason enough for the inhabitants, as part of the 950th anniversary celebrations, to erect a bronze statue and, since 2010, elect a female „Käsfraa“.
<G-vec00001-001-s115><erect.aufstellen><de> Zugegeben, die Erbauer der Hünengräber hatten keine Elektrizität, keine Flugzeuge, kein Plastik, aber man versuche nur, sich vorzustellen, über welche technischen Kenntnisse man verfügen muss, um diese riesigen Steine mehrere Kilometer zu transportieren – und das ohne LKW -, sie genau an einer bestimmten Stelle in einer bestimmten Position aufzustellen und sie sogar, wo das notwendig war, in der Form anzupassen.
<G-vec00001-001-s115><erect.aufstellen><en> Admittedly, whoever built these graves had no electricity, no airplanes, and no plastic, but just think about the technical knowledge required to move these stones several kilometers – without a truck – and to erect them in a specific spot and a specific position and, where necessary, to even shape their form.
<G-vec00001-001-s116><erect.aufstellen><de> Penomet macht die Kapillare größer im männlichen Bereich, der häufig den Blutfluss sorgt, dass der Penis zu machen sowie gerade aufzustellen.
<G-vec00001-001-s116><erect.aufstellen><en> Penomet makes the blood vessels bigger in the pennis area which makes the blood circulation frequently that making the pennis erect and also directly.
<G-vec00228-002-s026><nominate.aufstellen><de> Auch in Zukunft werden wir Kandidaten zu Wahlen aufstellen, um den Menschen eine echte Alternative zu den bürgerlichen Parteien zu bieten.
<G-vec00228-002-s026><nominate.aufstellen><en> Also in the future we will nominate our candidates for elections in order to give the people a real alternative to the bourgeois parties.
<G-vec00322-002-s111><establish.aufstellen><de> Leider ist die Ausstattung noch eher auf niedrigem Niveau, man sollte überall vernünftige Betten aufstellen, das untere Zimmer besser abtrennen und es innen etwas freundlicher gestalten.
<G-vec00322-002-s111><establish.aufstellen><en> Unfortunately, the equipment is still rather low level, you should all establish reasonable beds, separate the lower rooms better and make it inside a little more friendly.
<G-vec00322-002-s112><establish.aufstellen><de> Wir müssen außerdem ein Gespür dafür entwickeln, wo wir mit der Umsetzung anfangen und wie wir eine sinnvolle Roadmap aufstellen.
<G-vec00322-002-s112><establish.aufstellen><en> We additionally need to develop an understanding of where we're going to start with the implementation and how we're going to establish a meaningful roadmap.
<G-vec00322-002-s113><establish.aufstellen><de> In unserem Roman wird die von den Persönlichkeiten entstandene Bewegung Lebens- und Liebeshäuser in Stadt und am Land aufstellen.
<G-vec00322-002-s113><establish.aufstellen><en> In our novel, the movement created by the characters will establish houses of life and love downtown and with the countryside.
<G-vec00322-002-s116><establish.aufstellen><de> Wir wollen hier Grundsätze aufstellen und aus diesen Grundsätzen dann ein rechtes Resultat folgern.
<G-vec00322-002-s116><establish.aufstellen><en> We will establish foundational rules here and from these rules, we will come to the right conclusion.
<G-vec00322-002-s119><establish.aufstellen><de> Lieferanten müssen Verfahren und Systeme aufstellen, mit denen Arbeitsverletzungen und Krankheiten verfolgt und gemeldet werden können.
<G-vec00322-002-s119><establish.aufstellen><en> Suppliers shall establish procedures and systems to manage, track, and report occupational injury and illness.
<G-vec00322-002-s120><establish.aufstellen><de> Solche Eltern können keine Regeln aufstellen - sie drohen, sprechen über die Konsequenzen der Handlungen des Kindes, aber am Ende tun sie nichts.
<G-vec00322-002-s120><establish.aufstellen><en> Such parents can not establish rules - they threaten, talk about the consequences of the child's actions, but in the end do nothing.
<G-vec00322-002-s121><establish.aufstellen><de> Für die Zukunft setzt Geschäftsführer Grau auf weitere Shops: „Wir wollen uns vor allem in den Bestandsmärkten noch breiter aufstellen als bisher.
<G-vec00322-002-s121><establish.aufstellen><en> CEO Grau is focusing on new shops for the future: “Above all we want to establish ourselves more widely than before in our operating markets.
<G-vec00322-002-s124><establish.aufstellen><de> Ein Clan kann nur während dieses Zeitraumes den Grad des Unfriedens steigern und sein Hauptquartier aufstellen oder verlegen.
<G-vec00322-002-s124><establish.aufstellen><en> A clan can only decrease the unrest level of its provinces and establish or relocate its Headquarters during this period.
<G-vec00322-002-s125><establish.aufstellen><de> Die Konzerne müssen dringend klare Regeln aufstellen und auch ihren kommerziellen Nutzern endlich Rechtssicherheit für ihre Arbeit bieten.
<G-vec00322-002-s125><establish.aufstellen><en> Companies urgently need to establish clear rules and finally offer their commercial users legal certainty for their work.
<G-vec00322-002-s126><establish.aufstellen><de> (2) Im Hinblick auf die Anwendung von Absatz 1 können die Mitgliedstaaten für andere Erzeugnisse als Lebensmittel ein Verzeichnis der Erzeugnisse oder Erzeugniskategorien aufstellen, für die die Verpflichtung zur Angabe des Preises je Maßeinheit weiterhin gilt.
<G-vec00322-002-s126><establish.aufstellen><en> 2. With a view to implementing paragraph 1, Member States may, in the case of non-food products, establish a list of the products or product categories to which the obligation to indicate the unit price shall remain applicable.
<G-vec00290-003-s038><set_up.aufstellen><de> Auch im Backend hat sich Infraserv zukunftssicher aufgestellt: Durch die Ablösung des Altsystems und die Einführung von FirstSpirit verfügt Infraserv jetzt über ein leistungsstarkes CMS, das flexibel erweiterbar ist und auch in Zukunft die Handlungsfähigkeit des Unternehmens im Web sicherstellt.
<G-vec00290-003-s038><set_up.aufstellen><en> Infraserv has also set up a future-proof backend: By replacing the old system and introducing FirstSpirit, Infraserv now has a powerful CMS, which can be flexibly extended and also assures the company's future ability to act decisively on the web.
<G-vec00290-003-s039><set_up.aufstellen><de> 22 Und dieser Stein, den ich als Gedenkstein aufgestellt habe, soll ein Haus Gottes werden; und alles, was du mir geben wirst, werde ich dir treu verzehnten.
<G-vec00290-003-s039><set_up.aufstellen><en> 22)And the place of this stone, which I have set for a pillar, shall be the place of God's house:; and of all that thou shalt give me I will surely give the tenth unto thee.
<G-vec00290-003-s040><set_up.aufstellen><de> Die Zelle muss in einem abschliessbaren Raum aufgestellt und während Besuchszeiten betreut sein.
<G-vec00290-003-s040><set_up.aufstellen><en> The Cell must be set up in a lockable room and be overseen during visiting hours.
<G-vec00290-003-s041><set_up.aufstellen><de> Mit unseren Kundendiensttechnikern überprüfen Sie alle wichtigen Details und Sie erfahren, wie Ihre Maschine richtig aufgestellt, ausgerichtet und angeschlossen wird.
<G-vec00290-003-s041><set_up.aufstellen><en> With our service technicians you examine all important details and you will learn how to set up correctly, aligned and attached your machine.
<G-vec00290-003-s042><set_up.aufstellen><de> Dadurch wirkt das Stoffdach nicht mehr so aufgestellt, sondern kann die Proportionen des Coupes gut nachbilden.
<G-vec00290-003-s042><set_up.aufstellen><en> Thus the cloth top looks no longer set up so, but can reproduce well the proportions of the coupe.
<G-vec00290-003-s043><set_up.aufstellen><de> Komplexe Zusammenhangstrukturen können so aufgestellt werden, wobei Merkmale gleichzeitig unabhängig (also beeinflussend) und durch andere beeinflusst sein können.
<G-vec00290-003-s043><set_up.aufstellen><en> In this manner, complex covariance structures can be set up, whereby attributes can simultaneously be independent (influencing) and dependent (influenced by others).
<G-vec00290-003-s044><set_up.aufstellen><de> Zum Beispiel haben wir Richtlinien aufgestellt, was hinsichtlich der Kennzeichnung auf den Verpackungen alles zu beachten ist.
<G-vec00290-003-s044><set_up.aufstellen><en> For example, we have set guidelines on what has to be observed with regard to the labelling on the packaging.
<G-vec00290-003-s045><set_up.aufstellen><de> „Ich [der Prophet Daniel] schaute weiter, bis Throne aufgestellt wurden und der Alte an Tagen [Jehova] sich setzte.
<G-vec00290-003-s045><set_up.aufstellen><en> “I [the prophet Daniel] kept watching until thrones were set in place and the Ancient of Days [Jehovah] sat down.
<G-vec00290-003-s046><set_up.aufstellen><de> Im Park der Botschaft wurden Zelte und sanitäre Anlagen aufgestellt und ein Schulbetrieb für Kinder wurde eingerichtet.
<G-vec00290-003-s046><set_up.aufstellen><en> In the park of the embassy, tents and sanitary facilities were set up and a school enterprise for children was established.
<G-vec00290-003-s047><set_up.aufstellen><de> 19 Also kam Gideon und hundert Mann mit ihm vor das Lager, zu Anfang der mittelsten Nachtwache, da sie eben die Wächter aufgestellt hatten, und bliesen mit Posaunen und zerschlugen die Krüge in ihren Händen.
<G-vec00290-003-s047><set_up.aufstellen><en> "So Gideon and the hundred men who were with him came to the outskirts of the camp at the beginning of the middle watch, when they had just set the watch; and they blew the trumpets and smashed the jars that were in their hands.
<G-vec00290-003-s048><set_up.aufstellen><de> Das Tor muss so aufgestellt werden, dass der Spalt gleichmäßig verteilt ist (Abb.
<G-vec00290-003-s048><set_up.aufstellen><en> The door must be set up in such a way that the divide is evenly distributed.
<G-vec00290-003-s049><set_up.aufstellen><de> Ein weiteres Bett von 95 cm x 195 cm kann schnell durch Umbau der Sitzbank in der Wohnkabine aufgestellt werden.
<G-vec00290-003-s049><set_up.aufstellen><en> Another bed of 95 cm x 195 cm can be set up quickly by alteration of the bench in the living room.
<G-vec00290-003-s050><set_up.aufstellen><de> Das Deutsche Zentrum für Luft- und Raumfahrt (DLR) hat Platten entwickelt, die entlang von Landebahnen aufgestellt werden und so von den Flugzeugen verursachte Luftwirbel abschwächen.
<G-vec00290-003-s050><set_up.aufstellen><en> können. Fewer Airport Vortices The German Aerospace Center has developed panels to be set up alongside runways for minimising the air vortices caused by aircraft.
<G-vec00290-003-s051><set_up.aufstellen><de> Im Jahr 1956 wurde im Hintergrund eine Unterwasser-Krippe aus Keramik-Statuen aufgestellt.
<G-vec00290-003-s051><set_up.aufstellen><en> In 1956, on its backdrop, an underwater crib made of ceramic statues was set up.
<G-vec00290-003-s052><set_up.aufstellen><de> Es macht allerdings viel aus, wie die Netze aufgestellt werden.
<G-vec00290-003-s052><set_up.aufstellen><en> However, it also matters how the nets are set up.
<G-vec00290-003-s053><set_up.aufstellen><de> Eine große Auswahl an Firmen und Organisationen aus den verschiedensten Sektoren waren vertreten und hatten Infostände in der Hauptuniversität aufgestellt.
<G-vec00290-003-s053><set_up.aufstellen><en> Representatives from a wide range of companies and organizations from different sectors set up information stands in the main campus of the university.
<G-vec00290-003-s054><set_up.aufstellen><de> Da Kondensationstrockner keinen Abluftschlauch benötigen, können sie praktisch überall dort aufgestellt werden, wo es eine Steckdose gibt.
<G-vec00290-003-s054><set_up.aufstellen><en> Condensation dryers can be set up nearly anywhere a power outlet is available as they do not require an exhaust air hose.
<G-vec00290-003-s055><set_up.aufstellen><de> Diese Beobachtung kann jedoch durch ein Modell erklärt werden, das in dieser zweiten Untersuchung aufgestellt wird.
<G-vec00290-003-s055><set_up.aufstellen><en> It can be rationalized by a model, though, which is set up in this second study.
<G-vec00290-003-s056><set_up.aufstellen><de> Es gab keinen Zweifel daran, dass sie diese Falle aufgestellt hatte.
<G-vec00290-003-s056><set_up.aufstellen><en> There was no doubt that it was her, who had set this trap.
<G-vec00486-002-s038><set_back.aufstellen><de> Auch im Backend hat sich Infraserv zukunftssicher aufgestellt: Durch die Ablösung des Altsystems und die Einführung von FirstSpirit verfügt Infraserv jetzt über ein leistungsstarkes CMS, das flexibel erweiterbar ist und auch in Zukunft die Handlungsfähigkeit des Unternehmens im Web sicherstellt.
<G-vec00486-002-s038><set_back.aufstellen><en> Infraserv has also set up a future-proof backend: By replacing the old system and introducing FirstSpirit, Infraserv now has a powerful CMS, which can be flexibly extended and also assures the company's future ability to act decisively on the web.
<G-vec00486-002-s039><set_back.aufstellen><de> 22 Und dieser Stein, den ich als Gedenkstein aufgestellt habe, soll ein Haus Gottes werden; und alles, was du mir geben wirst, werde ich dir treu verzehnten.
<G-vec00486-002-s039><set_back.aufstellen><en> 22)And the place of this stone, which I have set for a pillar, shall be the place of God's house:; and of all that thou shalt give me I will surely give the tenth unto thee.
<G-vec00486-002-s040><set_back.aufstellen><de> Die Zelle muss in einem abschliessbaren Raum aufgestellt und während Besuchszeiten betreut sein.
<G-vec00486-002-s040><set_back.aufstellen><en> The Cell must be set up in a lockable room and be overseen during visiting hours.
<G-vec00486-002-s041><set_back.aufstellen><de> Mit unseren Kundendiensttechnikern überprüfen Sie alle wichtigen Details und Sie erfahren, wie Ihre Maschine richtig aufgestellt, ausgerichtet und angeschlossen wird.
<G-vec00486-002-s041><set_back.aufstellen><en> With our service technicians you examine all important details and you will learn how to set up correctly, aligned and attached your machine.
<G-vec00486-002-s042><set_back.aufstellen><de> Dadurch wirkt das Stoffdach nicht mehr so aufgestellt, sondern kann die Proportionen des Coupes gut nachbilden.
<G-vec00486-002-s042><set_back.aufstellen><en> Thus the cloth top looks no longer set up so, but can reproduce well the proportions of the coupe.
<G-vec00486-002-s043><set_back.aufstellen><de> Komplexe Zusammenhangstrukturen können so aufgestellt werden, wobei Merkmale gleichzeitig unabhängig (also beeinflussend) und durch andere beeinflusst sein können.
<G-vec00486-002-s043><set_back.aufstellen><en> In this manner, complex covariance structures can be set up, whereby attributes can simultaneously be independent (influencing) and dependent (influenced by others).
<G-vec00486-002-s044><set_back.aufstellen><de> Zum Beispiel haben wir Richtlinien aufgestellt, was hinsichtlich der Kennzeichnung auf den Verpackungen alles zu beachten ist.
<G-vec00486-002-s044><set_back.aufstellen><en> For example, we have set guidelines on what has to be observed with regard to the labelling on the packaging.
<G-vec00486-002-s045><set_back.aufstellen><de> „Ich [der Prophet Daniel] schaute weiter, bis Throne aufgestellt wurden und der Alte an Tagen [Jehova] sich setzte.
<G-vec00486-002-s045><set_back.aufstellen><en> “I [the prophet Daniel] kept watching until thrones were set in place and the Ancient of Days [Jehovah] sat down.
<G-vec00486-002-s046><set_back.aufstellen><de> Im Park der Botschaft wurden Zelte und sanitäre Anlagen aufgestellt und ein Schulbetrieb für Kinder wurde eingerichtet.
<G-vec00486-002-s046><set_back.aufstellen><en> In the park of the embassy, tents and sanitary facilities were set up and a school enterprise for children was established.
<G-vec00486-002-s047><set_back.aufstellen><de> 19 Also kam Gideon und hundert Mann mit ihm vor das Lager, zu Anfang der mittelsten Nachtwache, da sie eben die Wächter aufgestellt hatten, und bliesen mit Posaunen und zerschlugen die Krüge in ihren Händen.
<G-vec00486-002-s047><set_back.aufstellen><en> "So Gideon and the hundred men who were with him came to the outskirts of the camp at the beginning of the middle watch, when they had just set the watch; and they blew the trumpets and smashed the jars that were in their hands.
<G-vec00486-002-s048><set_back.aufstellen><de> Das Tor muss so aufgestellt werden, dass der Spalt gleichmäßig verteilt ist (Abb.
<G-vec00486-002-s048><set_back.aufstellen><en> The door must be set up in such a way that the divide is evenly distributed.
<G-vec00486-002-s049><set_back.aufstellen><de> Ein weiteres Bett von 95 cm x 195 cm kann schnell durch Umbau der Sitzbank in der Wohnkabine aufgestellt werden.
<G-vec00486-002-s049><set_back.aufstellen><en> Another bed of 95 cm x 195 cm can be set up quickly by alteration of the bench in the living room.
<G-vec00486-002-s050><set_back.aufstellen><de> Das Deutsche Zentrum für Luft- und Raumfahrt (DLR) hat Platten entwickelt, die entlang von Landebahnen aufgestellt werden und so von den Flugzeugen verursachte Luftwirbel abschwächen.
<G-vec00486-002-s050><set_back.aufstellen><en> können. Fewer Airport Vortices The German Aerospace Center has developed panels to be set up alongside runways for minimising the air vortices caused by aircraft.
<G-vec00486-002-s051><set_back.aufstellen><de> Im Jahr 1956 wurde im Hintergrund eine Unterwasser-Krippe aus Keramik-Statuen aufgestellt.
<G-vec00486-002-s051><set_back.aufstellen><en> In 1956, on its backdrop, an underwater crib made of ceramic statues was set up.
<G-vec00486-002-s052><set_back.aufstellen><de> Es macht allerdings viel aus, wie die Netze aufgestellt werden.
<G-vec00486-002-s052><set_back.aufstellen><en> However, it also matters how the nets are set up.
<G-vec00486-002-s053><set_back.aufstellen><de> Eine große Auswahl an Firmen und Organisationen aus den verschiedensten Sektoren waren vertreten und hatten Infostände in der Hauptuniversität aufgestellt.
<G-vec00486-002-s053><set_back.aufstellen><en> Representatives from a wide range of companies and organizations from different sectors set up information stands in the main campus of the university.
<G-vec00486-002-s054><set_back.aufstellen><de> Da Kondensationstrockner keinen Abluftschlauch benötigen, können sie praktisch überall dort aufgestellt werden, wo es eine Steckdose gibt.
<G-vec00486-002-s054><set_back.aufstellen><en> Condensation dryers can be set up nearly anywhere a power outlet is available as they do not require an exhaust air hose.
<G-vec00486-002-s055><set_back.aufstellen><de> Diese Beobachtung kann jedoch durch ein Modell erklärt werden, das in dieser zweiten Untersuchung aufgestellt wird.
<G-vec00486-002-s055><set_back.aufstellen><en> It can be rationalized by a model, though, which is set up in this second study.
<G-vec00486-002-s056><set_back.aufstellen><de> Es gab keinen Zweifel daran, dass sie diese Falle aufgestellt hatte.
<G-vec00486-002-s056><set_back.aufstellen><en> There was no doubt that it was her, who had set this trap.
<G-vec00556-002-s038><set_apart.aufstellen><de> Auch im Backend hat sich Infraserv zukunftssicher aufgestellt: Durch die Ablösung des Altsystems und die Einführung von FirstSpirit verfügt Infraserv jetzt über ein leistungsstarkes CMS, das flexibel erweiterbar ist und auch in Zukunft die Handlungsfähigkeit des Unternehmens im Web sicherstellt.
<G-vec00556-002-s038><set_apart.aufstellen><en> Infraserv has also set up a future-proof backend: By replacing the old system and introducing FirstSpirit, Infraserv now has a powerful CMS, which can be flexibly extended and also assures the company's future ability to act decisively on the web.
<G-vec00556-002-s039><set_apart.aufstellen><de> 22 Und dieser Stein, den ich als Gedenkstein aufgestellt habe, soll ein Haus Gottes werden; und alles, was du mir geben wirst, werde ich dir treu verzehnten.
<G-vec00556-002-s039><set_apart.aufstellen><en> 22)And the place of this stone, which I have set for a pillar, shall be the place of God's house:; and of all that thou shalt give me I will surely give the tenth unto thee.
<G-vec00556-002-s040><set_apart.aufstellen><de> Die Zelle muss in einem abschliessbaren Raum aufgestellt und während Besuchszeiten betreut sein.
<G-vec00556-002-s040><set_apart.aufstellen><en> The Cell must be set up in a lockable room and be overseen during visiting hours.
<G-vec00556-002-s041><set_apart.aufstellen><de> Mit unseren Kundendiensttechnikern überprüfen Sie alle wichtigen Details und Sie erfahren, wie Ihre Maschine richtig aufgestellt, ausgerichtet und angeschlossen wird.
<G-vec00556-002-s041><set_apart.aufstellen><en> With our service technicians you examine all important details and you will learn how to set up correctly, aligned and attached your machine.
<G-vec00556-002-s042><set_apart.aufstellen><de> Dadurch wirkt das Stoffdach nicht mehr so aufgestellt, sondern kann die Proportionen des Coupes gut nachbilden.
<G-vec00556-002-s042><set_apart.aufstellen><en> Thus the cloth top looks no longer set up so, but can reproduce well the proportions of the coupe.
<G-vec00556-002-s043><set_apart.aufstellen><de> Komplexe Zusammenhangstrukturen können so aufgestellt werden, wobei Merkmale gleichzeitig unabhängig (also beeinflussend) und durch andere beeinflusst sein können.
<G-vec00556-002-s043><set_apart.aufstellen><en> In this manner, complex covariance structures can be set up, whereby attributes can simultaneously be independent (influencing) and dependent (influenced by others).
<G-vec00556-002-s044><set_apart.aufstellen><de> Zum Beispiel haben wir Richtlinien aufgestellt, was hinsichtlich der Kennzeichnung auf den Verpackungen alles zu beachten ist.
<G-vec00556-002-s044><set_apart.aufstellen><en> For example, we have set guidelines on what has to be observed with regard to the labelling on the packaging.
<G-vec00556-002-s045><set_apart.aufstellen><de> „Ich [der Prophet Daniel] schaute weiter, bis Throne aufgestellt wurden und der Alte an Tagen [Jehova] sich setzte.
<G-vec00556-002-s045><set_apart.aufstellen><en> “I [the prophet Daniel] kept watching until thrones were set in place and the Ancient of Days [Jehovah] sat down.
<G-vec00556-002-s046><set_apart.aufstellen><de> Im Park der Botschaft wurden Zelte und sanitäre Anlagen aufgestellt und ein Schulbetrieb für Kinder wurde eingerichtet.
<G-vec00556-002-s046><set_apart.aufstellen><en> In the park of the embassy, tents and sanitary facilities were set up and a school enterprise for children was established.
<G-vec00556-002-s047><set_apart.aufstellen><de> 19 Also kam Gideon und hundert Mann mit ihm vor das Lager, zu Anfang der mittelsten Nachtwache, da sie eben die Wächter aufgestellt hatten, und bliesen mit Posaunen und zerschlugen die Krüge in ihren Händen.
<G-vec00556-002-s047><set_apart.aufstellen><en> "So Gideon and the hundred men who were with him came to the outskirts of the camp at the beginning of the middle watch, when they had just set the watch; and they blew the trumpets and smashed the jars that were in their hands.
<G-vec00556-002-s048><set_apart.aufstellen><de> Das Tor muss so aufgestellt werden, dass der Spalt gleichmäßig verteilt ist (Abb.
<G-vec00556-002-s048><set_apart.aufstellen><en> The door must be set up in such a way that the divide is evenly distributed.
<G-vec00556-002-s049><set_apart.aufstellen><de> Ein weiteres Bett von 95 cm x 195 cm kann schnell durch Umbau der Sitzbank in der Wohnkabine aufgestellt werden.
<G-vec00556-002-s049><set_apart.aufstellen><en> Another bed of 95 cm x 195 cm can be set up quickly by alteration of the bench in the living room.
<G-vec00556-002-s050><set_apart.aufstellen><de> Das Deutsche Zentrum für Luft- und Raumfahrt (DLR) hat Platten entwickelt, die entlang von Landebahnen aufgestellt werden und so von den Flugzeugen verursachte Luftwirbel abschwächen.
<G-vec00556-002-s050><set_apart.aufstellen><en> können. Fewer Airport Vortices The German Aerospace Center has developed panels to be set up alongside runways for minimising the air vortices caused by aircraft.
<G-vec00556-002-s051><set_apart.aufstellen><de> Im Jahr 1956 wurde im Hintergrund eine Unterwasser-Krippe aus Keramik-Statuen aufgestellt.
<G-vec00556-002-s051><set_apart.aufstellen><en> In 1956, on its backdrop, an underwater crib made of ceramic statues was set up.
<G-vec00556-002-s052><set_apart.aufstellen><de> Es macht allerdings viel aus, wie die Netze aufgestellt werden.
<G-vec00556-002-s052><set_apart.aufstellen><en> However, it also matters how the nets are set up.
<G-vec00556-002-s053><set_apart.aufstellen><de> Eine große Auswahl an Firmen und Organisationen aus den verschiedensten Sektoren waren vertreten und hatten Infostände in der Hauptuniversität aufgestellt.
<G-vec00556-002-s053><set_apart.aufstellen><en> Representatives from a wide range of companies and organizations from different sectors set up information stands in the main campus of the university.
<G-vec00556-002-s054><set_apart.aufstellen><de> Da Kondensationstrockner keinen Abluftschlauch benötigen, können sie praktisch überall dort aufgestellt werden, wo es eine Steckdose gibt.
<G-vec00556-002-s054><set_apart.aufstellen><en> Condensation dryers can be set up nearly anywhere a power outlet is available as they do not require an exhaust air hose.
<G-vec00556-002-s055><set_apart.aufstellen><de> Diese Beobachtung kann jedoch durch ein Modell erklärt werden, das in dieser zweiten Untersuchung aufgestellt wird.
<G-vec00556-002-s055><set_apart.aufstellen><en> It can be rationalized by a model, though, which is set up in this second study.
<G-vec00556-002-s056><set_apart.aufstellen><de> Es gab keinen Zweifel daran, dass sie diese Falle aufgestellt hatte.
<G-vec00556-002-s056><set_apart.aufstellen><en> There was no doubt that it was her, who had set this trap.
<G-vec00556-002-s038><set_aside.aufstellen><de> Auch im Backend hat sich Infraserv zukunftssicher aufgestellt: Durch die Ablösung des Altsystems und die Einführung von FirstSpirit verfügt Infraserv jetzt über ein leistungsstarkes CMS, das flexibel erweiterbar ist und auch in Zukunft die Handlungsfähigkeit des Unternehmens im Web sicherstellt.
<G-vec00556-002-s038><set_aside.aufstellen><en> Infraserv has also set up a future-proof backend: By replacing the old system and introducing FirstSpirit, Infraserv now has a powerful CMS, which can be flexibly extended and also assures the company's future ability to act decisively on the web.
<G-vec00556-002-s039><set_aside.aufstellen><de> 22 Und dieser Stein, den ich als Gedenkstein aufgestellt habe, soll ein Haus Gottes werden; und alles, was du mir geben wirst, werde ich dir treu verzehnten.
<G-vec00556-002-s039><set_aside.aufstellen><en> 22)And the place of this stone, which I have set for a pillar, shall be the place of God's house:; and of all that thou shalt give me I will surely give the tenth unto thee.
<G-vec00556-002-s040><set_aside.aufstellen><de> Die Zelle muss in einem abschliessbaren Raum aufgestellt und während Besuchszeiten betreut sein.
<G-vec00556-002-s040><set_aside.aufstellen><en> The Cell must be set up in a lockable room and be overseen during visiting hours.
<G-vec00556-002-s041><set_aside.aufstellen><de> Mit unseren Kundendiensttechnikern überprüfen Sie alle wichtigen Details und Sie erfahren, wie Ihre Maschine richtig aufgestellt, ausgerichtet und angeschlossen wird.
<G-vec00556-002-s041><set_aside.aufstellen><en> With our service technicians you examine all important details and you will learn how to set up correctly, aligned and attached your machine.
<G-vec00556-002-s042><set_aside.aufstellen><de> Dadurch wirkt das Stoffdach nicht mehr so aufgestellt, sondern kann die Proportionen des Coupes gut nachbilden.
<G-vec00556-002-s042><set_aside.aufstellen><en> Thus the cloth top looks no longer set up so, but can reproduce well the proportions of the coupe.
<G-vec00556-002-s043><set_aside.aufstellen><de> Komplexe Zusammenhangstrukturen können so aufgestellt werden, wobei Merkmale gleichzeitig unabhängig (also beeinflussend) und durch andere beeinflusst sein können.
<G-vec00556-002-s043><set_aside.aufstellen><en> In this manner, complex covariance structures can be set up, whereby attributes can simultaneously be independent (influencing) and dependent (influenced by others).
<G-vec00556-002-s044><set_aside.aufstellen><de> Zum Beispiel haben wir Richtlinien aufgestellt, was hinsichtlich der Kennzeichnung auf den Verpackungen alles zu beachten ist.
<G-vec00556-002-s044><set_aside.aufstellen><en> For example, we have set guidelines on what has to be observed with regard to the labelling on the packaging.
<G-vec00556-002-s045><set_aside.aufstellen><de> „Ich [der Prophet Daniel] schaute weiter, bis Throne aufgestellt wurden und der Alte an Tagen [Jehova] sich setzte.
<G-vec00556-002-s045><set_aside.aufstellen><en> “I [the prophet Daniel] kept watching until thrones were set in place and the Ancient of Days [Jehovah] sat down.
<G-vec00556-002-s046><set_aside.aufstellen><de> Im Park der Botschaft wurden Zelte und sanitäre Anlagen aufgestellt und ein Schulbetrieb für Kinder wurde eingerichtet.
<G-vec00556-002-s046><set_aside.aufstellen><en> In the park of the embassy, tents and sanitary facilities were set up and a school enterprise for children was established.
<G-vec00556-002-s047><set_aside.aufstellen><de> 19 Also kam Gideon und hundert Mann mit ihm vor das Lager, zu Anfang der mittelsten Nachtwache, da sie eben die Wächter aufgestellt hatten, und bliesen mit Posaunen und zerschlugen die Krüge in ihren Händen.
<G-vec00556-002-s047><set_aside.aufstellen><en> "So Gideon and the hundred men who were with him came to the outskirts of the camp at the beginning of the middle watch, when they had just set the watch; and they blew the trumpets and smashed the jars that were in their hands.
<G-vec00556-002-s048><set_aside.aufstellen><de> Das Tor muss so aufgestellt werden, dass der Spalt gleichmäßig verteilt ist (Abb.
<G-vec00556-002-s048><set_aside.aufstellen><en> The door must be set up in such a way that the divide is evenly distributed.
<G-vec00556-002-s049><set_aside.aufstellen><de> Ein weiteres Bett von 95 cm x 195 cm kann schnell durch Umbau der Sitzbank in der Wohnkabine aufgestellt werden.
<G-vec00556-002-s049><set_aside.aufstellen><en> Another bed of 95 cm x 195 cm can be set up quickly by alteration of the bench in the living room.
<G-vec00556-002-s050><set_aside.aufstellen><de> Das Deutsche Zentrum für Luft- und Raumfahrt (DLR) hat Platten entwickelt, die entlang von Landebahnen aufgestellt werden und so von den Flugzeugen verursachte Luftwirbel abschwächen.
<G-vec00556-002-s050><set_aside.aufstellen><en> können. Fewer Airport Vortices The German Aerospace Center has developed panels to be set up alongside runways for minimising the air vortices caused by aircraft.
<G-vec00556-002-s051><set_aside.aufstellen><de> Im Jahr 1956 wurde im Hintergrund eine Unterwasser-Krippe aus Keramik-Statuen aufgestellt.
<G-vec00556-002-s051><set_aside.aufstellen><en> In 1956, on its backdrop, an underwater crib made of ceramic statues was set up.
<G-vec00556-002-s052><set_aside.aufstellen><de> Es macht allerdings viel aus, wie die Netze aufgestellt werden.
<G-vec00556-002-s052><set_aside.aufstellen><en> However, it also matters how the nets are set up.
<G-vec00556-002-s053><set_aside.aufstellen><de> Eine große Auswahl an Firmen und Organisationen aus den verschiedensten Sektoren waren vertreten und hatten Infostände in der Hauptuniversität aufgestellt.
<G-vec00556-002-s053><set_aside.aufstellen><en> Representatives from a wide range of companies and organizations from different sectors set up information stands in the main campus of the university.
<G-vec00556-002-s054><set_aside.aufstellen><de> Da Kondensationstrockner keinen Abluftschlauch benötigen, können sie praktisch überall dort aufgestellt werden, wo es eine Steckdose gibt.
<G-vec00556-002-s054><set_aside.aufstellen><en> Condensation dryers can be set up nearly anywhere a power outlet is available as they do not require an exhaust air hose.
<G-vec00556-002-s055><set_aside.aufstellen><de> Diese Beobachtung kann jedoch durch ein Modell erklärt werden, das in dieser zweiten Untersuchung aufgestellt wird.
<G-vec00556-002-s055><set_aside.aufstellen><en> It can be rationalized by a model, though, which is set up in this second study.
<G-vec00556-002-s056><set_aside.aufstellen><de> Es gab keinen Zweifel daran, dass sie diese Falle aufgestellt hatte.
<G-vec00556-002-s056><set_aside.aufstellen><en> There was no doubt that it was her, who had set this trap.
<G-vec00075-002-s023><erect.aufstellen><de> Das bedeutet, es werden Fundamente gegossen sowie Fertigteil-Betonwände und -Stützen, für die anschließende Montage der Stahldachträger, aufgestellt.
<G-vec00075-002-s023><erect.aufstellen><en> Construction teams continue to pour foundations, prefab concrete walls, and erect columns that will enable installation of the steel roof beams.
<G-vec00075-002-s024><erect.aufstellen><de> Deckensegel ermöglichen zudem auch eine Abgrenzung von Bereichen im selben Raum, ohne dass Trennwände oder Raumteiler aufgestellt werden müssen.
<G-vec00075-002-s024><erect.aufstellen><en> Furthermore, ceiling rafts enable segmentation of areas in the same room without having to erect dividing walls or partitions.
<G-vec00075-002-s065><erect.aufstellen><de> Highlight des Produkt-Portfolios ist die neue Pro Print/EBS-HS-2 – eine Maschine, die alle Branchenvorgaben und Kundenwünsche abdeckt und Versandkartons bedrucken, aufstellen und verschließen kann.
<G-vec00075-002-s065><erect.aufstellen><en> To meet customer requirements and industry demand, Pro Pack developed their latest packaging machine, the Pro Print/EBS-HS-2, that will print, erect and seal a corrugated shipping case.
<G-vec00075-002-s078><erect.aufstellen><de> Das Bett ist schnell, mit nur wenigen Handgriffen aufzustellen und bequem zum Schlafen.
<G-vec00075-002-s078><erect.aufstellen><en> A strong aluminium frame with 600 denier nylon bed, easy to erect and comfortable to sleep.
<G-vec00075-002-s190><erect.aufstellen><de> Stelle dein Zelt nicht unter einem großen, allein stehenden Baum auf, um die Gefahr eines Blitzschlags zu vermeiden.
<G-vec00075-002-s190><erect.aufstellen><en> Do not erect your tent under a large solitary tree because of the risk of a lightning strike.
<G-vec00075-002-s191><erect.aufstellen><de> Stellen Sie Zelt und Sonnenschirm an einen der schönsten Strände des Languedoc auf.
<G-vec00075-002-s191><erect.aufstellen><en> Erect your tent and your parasol on one of the finest beaches in Languedoc.
<G-vec00075-002-s192><erect.aufstellen><de> Ralf Hoch, eno´s Country Manager für Schweden verhandelt längst über die Erweiterungen der Windparks: „ An beiden Standorten in Småland können wir voraussichtlich jeweils zwei weitere Windenergieanlagen stellen.
<G-vec00075-002-s192><erect.aufstellen><en> Ralf Hoch, eno's Country Manager for Sweden, is already negotiating expansions to the wind farms: “We can probably erect two more wind turbines at each of the two sites in Småland.
<G-vec00075-002-s193><erect.aufstellen><de> Parallel dazu stellen wir eine Reihe von Türmen auf, ebenso hoch wie die Halle und gleichermaßen weiß eingekleidet.
<G-vec00075-002-s193><erect.aufstellen><en> In addition, we will erect a number of towers, just as high as the hall and also covered in white.
