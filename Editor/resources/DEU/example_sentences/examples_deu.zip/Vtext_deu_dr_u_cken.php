<G-vec00272-001-s168><push.drücken><de> Beispiel: Möchtest Du etwas um 30° drehen, dann tippe ein <30 und drücke Enter, dann greife den Drehen-Griff und das Objekt kann nun in 30° Schritten gedreht werden.
<G-vec00272-001-s168><push.drücken><en> So for example if you want to rotate something by 30 degrees, type in <30 and push enter, then grab that rotation grip and it will rotate in 30 degree increments.
<G-vec00272-001-s169><push.drücken><de> Sitze zurückgelehnt und drücke die Brust gegen das Kissen.
<G-vec00272-001-s169><push.drücken><en> Sit back straight, push your chest against the cushion.
<G-vec00272-001-s170><push.drücken><de> Drücke zu Beginn und zum Ende des Urinierens hin stark, damit es nicht so sehr tröpfelt.
<G-vec00272-001-s170><push.drücken><en> Push hard at the beginning of your flow and then again to end the stream.
<G-vec00272-001-s171><push.drücken><de> Drücke vorwärts und halte die Sprint-Taste gedrückt.
<G-vec00272-001-s171><push.drücken><en> Push forward and hold down the sprint button.
<G-vec00272-001-s172><push.drücken><de> Drücke - oder Backspace, um eine Seite zurückzublättern (blättert zur letzten Seite, falls Du auf der ersten Seite bist).
<G-vec00272-001-s172><push.drücken><en> Push - or Backspace to flip to previous page (last page if on first page).
<G-vec00272-001-s173><push.drücken><de> Drücke d oder D, um tiefer zu fliegen (down).
<G-vec00272-001-s173><push.drücken><en> Push d or D to fly down (lower).
<G-vec00272-001-s174><push.drücken><de> Wähle Beschleunigen aus, drücke dann den Rechten Analogstick nach vorne.
<G-vec00272-001-s174><push.drücken><en> Select Accelerate, then push the Right analog stick forward.
<G-vec00272-001-s175><push.drücken><de> Ziehe jeden nach oben und drücke keinen runter.
<G-vec00272-001-s175><push.drücken><en> Pull everyone up, and push no one down.
<G-vec00272-001-s176><push.drücken><de> Nimm einen Schritt mit deinem rechten Fuß und drücke mit deinem linken Stock.
<G-vec00272-001-s176><push.drücken><en> Take a step with your right foot, and push with your left stick.
<G-vec00272-001-s177><push.drücken><de> Drücke es mit dem Finger in der Mitte nach unten, so dass es es sich am gerade gebohrten Loch etwas einwölbt.
<G-vec00272-001-s177><push.drücken><en> Push it down in the middle with your finger so that it forms an indentation in the hole that you just made.
<G-vec00272-001-s178><push.drücken><de> Um die Spacer zu verwenden, lege sie einfach auf das Gewinde deines Ytrucks Achsstifts und drücke sie langsam mit deinem Wheel fest.
<G-vec00272-001-s178><push.drücken><en> To mount the Spacers just place them on your Ytrucks axle and push them in gently with your wheel.
<G-vec00272-001-s179><push.drücken><de> Drücke leicht auf den Knopf und sorge dafür, dass das Licht an und aus flackern kann.
<G-vec00272-001-s179><push.drücken><en> Gently push on the power button and make sure that the light can flicker on and off.
<G-vec00272-001-s180><push.drücken><de> Lege deinen Zeigefinger waagerecht unter deine Wimpern und drücke sie an dein Augenlid.
<G-vec00272-001-s180><push.drücken><en> Place your forefinger horizontally under your eyelashes and push them up against your lid.
<G-vec00272-001-s181><push.drücken><de> Drücke fest auf die Schrauben und drehe sie langsam.
<G-vec00272-001-s181><push.drücken><en> Push hard and start to turn the screws slowly.
<G-vec00272-001-s182><push.drücken><de> Drücke die Nase unter die Oberfläche indem du deinen Rücken beugst und die Nase mit deinen Händen nach unten drückst.
<G-vec00272-001-s182><push.drücken><en> Push the nose of the board under the surface by arching your back and pushing down on the nose with your hands.
<G-vec00272-001-s183><push.drücken><de> Kratze an der Oberfläche und drücke die richtigen Knöpfe, und sie werden ebenso zornig sein wie jeder andere, ja sogar noch mehr, weil sie sich darüber Illusionen machen.
<G-vec00272-001-s183><push.drücken><en> Scratch the surface and push the right buttons and they're just as angry as the next person, indeed more so, because they're delusional about it.
<G-vec00272-001-s184><push.drücken><de> Außer Atem und gegen einen sich mühenden Bastille, hebe ich mein linkes Knie über seinen rechten Oberschenkel und drücke ihn mit meiner linken Hand auf den Boden, sodass er sich nicht mehr bewegen kann.
<G-vec00272-001-s184><push.drücken><en> Out of breath, and fighting against a struggling Bastille, I slide my left knee over his right thigh and push down on his chest with my left hand so he wouldn’t get up.
<G-vec00272-001-s185><push.drücken><de> Drücke sanft das Papier wieder nach innen, um die Knalltüte nochmal zu verwenden.
<G-vec00272-001-s185><push.drücken><en> To re-use the banger, just gently push the paper back in.
<G-vec00272-001-s186><push.drücken><de> Drücke ihn dann wieder ein wenig vor, um Deinen Cones etwas zusätzliche Füllung zu geben (je mehr Du bei diesem letzten Schritt drückst, desto fester kannst Du Deine Cones stopfen).
<G-vec00272-001-s186><push.drücken><en> Slide the top part forward and then back. Now, push just a little bit forward again to give your cones that extra pack (the more you push on this last step, the harder you can pack your cones).
<G-vec00272-001-s187><push.drücken><de> Wenn Sie drücken die “ermöglichen” Taste, dann werden Sie beginnen von Gogoputlocker.com auf Ihrem Desktop unerwünschte Pop-up-Anzeigen zu sehen, auch wenn Ihr Internet-Browser geschlossen ist.
<G-vec00272-001-s187><push.drücken><en> If you push the “Allow” button, then you will begin seeing unwanted pop-up ads from Gogoputlocker.com on your desktop even when your internet browser is closed.
<G-vec00272-001-s188><push.drücken><de> So viel zu fleischlichen Sünden Drücken Sie nicht, aber für die geistige: die Superbia, die empietÃ, die Vermutung, Blinde, l'odio, die ipocrisia, die Lüge, Duplizität.
<G-vec00272-001-s188><push.drücken><en> The main aim of Satan is not even so much the corruption of passions but the corruption of the spirit. Do not push so much to carnal sins, but for the spiritual: the Superbia, the empietà, the presumption, the blind, hatred, the ipocrisia, the lie, duplicity.
<G-vec00272-001-s189><push.drücken><de> Wenn der Fahrer den Fuß vom Pedal, die Federn drücken Sie die Druckplatte gegen die Kupplungsscheibe, die wiederum drückt gegen das Schwungrad.
<G-vec00272-001-s189><push.drücken><en> When the driver’s foot is off the pedal, the springs push the pressure plate against the clutch disc, which in turn presses against the flywheel.
<G-vec00272-001-s190><push.drücken><de> Ich denke viele von Ihnen würden die Schaltfläche jeden Tag drücken um Künstlern, deren Arbeit Sie mögen, einen Euro zu senden.
<G-vec00272-001-s190><push.drücken><en> I think a lot of you might push that button every day, to give one euro to some artist who had made a work that you liked.
<G-vec00272-001-s191><push.drücken><de> Ich konnte die Schwester sehen, die versuchte das Kind aus mir heraus zu drücken, und dann hörte ich auf darauf zu achten.
<G-vec00272-001-s191><push.drücken><en> I could see the nurse trying to push the baby out of me, and then I quit paying attention.
<G-vec00272-001-s192><push.drücken><de> Beschreibung Durch das Drücken des Druckknopfes am Griff des Bolzens, werden am anderen Ende die Sperrkugeln gelöst.
<G-vec00272-001-s192><push.drücken><en> Description By depressing the push button on the bolt grip, the balls at the other end are released.
<G-vec00272-001-s193><push.drücken><de> SYNCHRESIS FLUGDECK TECHNOLOGY arbeiten, Klang-ausgestattet, 3d-modelliert VC Layouts, Veranstaltungen, Knöpfe, Tasten drücken Flip-Cover, gleitenden Animationen, ausblenden Joche Sitze (für große Anschaltung Benutzer) Funktionen je fortschrittlichste 737 gebaut Simulation... (siehe unsere technische Seiten).
<G-vec00272-001-s193><push.drücken><en> SYNCHRESIS TECHNOLOGY working, sound-equipped, 3d-modeled VC layouts, switches, events, knobs, buttons push flip covers, sliding animations, HIDE yokes seats (for large montior users) ever before most 737 built simulation... (see our spec pages).
<G-vec00272-001-s194><push.drücken><de> Dieses Feature funktioniert sofort und ohne spezielle Konfiguration: Sie wählen dann einfach einen VM-Backup, einen Wiederherstellungspunkt und einen Wiederherstellungsspeicherort (einen Host, eine Ressourcenquelle oder einen Cluster, wo eine wiederhergestellte VM laufen soll), dann drücken Sie eine Taste – die VM wird in kürzester Zeit gebootet.
<G-vec00272-001-s194><push.drücken><en> This feature works right out of the box without any special setup. Just choose a VM backup, a recovery point, and a recovery location (a host, a resource pool, or a cluster where you want to run the recovered VM), then push a button – the VM is booted in no time.
<G-vec00272-001-s195><push.drücken><de> In den schlimmsten Tagen aufgrund der Zittern der Hand konnte ich den Löffel in den Mund nicht drücken.
<G-vec00272-001-s195><push.drücken><en> In the worst days due to the hand tremor I could not push the spoon in mouth.
<G-vec00272-001-s196><push.drücken><de> In weniger dringenden Fällen drücken Sie bitte an den Notruf- und Info-Säulen die grüne Infotaste - etwa wenn Sie sehen, dass in einer Station ein Automat nicht funktioniert oder das Licht ausgefallen ist.
<G-vec00272-001-s196><push.drücken><en> If it is not particularly urgent, please push the green information button of the emergency call and information pillar - for example if you notice that a vending machine is out of order or the light doesn't work.
<G-vec00272-001-s197><push.drücken><de> Sie drücken eine Taste runter und heraus kommt dieser Ton.
<G-vec00272-001-s197><push.drücken><en> They push a key down and out comes this sound.
<G-vec00272-001-s198><push.drücken><de> Einfach den Knopf drücken und davor arbeiten.
<G-vec00272-001-s198><push.drücken><en> Simply push the button and work in front of it.
<G-vec00272-001-s199><push.drücken><de> "Die Republikaner versuchen zu drücken ein ein ""Negativ"" von dies bouncy, progressiv Buchstabe mit einer ein viel wiederholen Fernsehapparat Anzeige vier Jahr vor zeigen eine ein Reihe von videoClip mit einem ein beleben Wellstone spitz gestikulieren und schreien, als ob er sein auf einem ein sozialistisch soapbox nach dem d gross Schlag 1934."
<G-vec00272-001-s199><push.drücken><en> "The Republicans tried to push a ""negative"" of this bouncy, progressive character with a much repeated TV ad of four years ago showing a series of video clips with an animated Wellstone pointedly gesturing and shouting, as if he were on a socialist soapbox after the big strike in 1934."
<G-vec00272-001-s200><push.drücken><de> Es ist nicht notwendig, den Kolben nach unten zu drücken.
<G-vec00272-001-s200><push.drücken><en> It is not necessary to push the plunger down.
<G-vec00272-001-s201><push.drücken><de> Drücken Sie dann den Download Button und speichern Sie die Datei citroen-myway.zip in einem Ordner auf Ihrer Festplatte.
<G-vec00272-001-s201><push.drücken><en> Push Download button and save the file citroen-myway.zip to your hard disk.
<G-vec00272-001-s202><push.drücken><de> Jeder Kanal verfügt über unabhängige Gain-Level Regler für maximale Gewinn-Niveau control, während eine dual Boost-Schaltung ermöglicht, drücken Sie entweder die reinigen oder Crunch/Lead Kanäle in die erhöhte Sättigung für geschoben-reinigen und Solo-Töne.
<G-vec00272-001-s202><push.drücken><en> Each channel has independent gain/level controls for maximum gain-level control, while a dual boost circuit enables you to push either the clean or crunch/lead channels into increased saturation for pushed-clean and solo tones.
<G-vec00272-001-s203><push.drücken><de> "Um der „Website Builder“ nach Ihrem einzigartigen Geschmack zu gestalten, drücken Sie einfach den orangen Button „Download""und fügen Sie danach die heruntergeladene Datei in den Ordner Ihrer Joomla 1.5 Installation hinzu."
<G-vec00272-001-s203><push.drücken><en> To make Mini Website-Builder your own Joomla website theme, simply push the orange Download button to download it and afterwards add it to your Joomla 1.5.x installation folder.
<G-vec00272-001-s204><push.drücken><de> Dies bedeutet, dass es eine konstante Tendenz für Flüssigkeit, nach innen - in die Blutkörperchen zu drücken.
<G-vec00272-001-s204><push.drücken><en> This means there is a constant tendency for liquid to push inward - into the blood cell.
<G-vec00272-001-s205><push.drücken><de> Sie müssen nur einen Knopf drücken “verbinden” WLAN USB-Adapter, wenn Sie als Maus verwenden möchten..
<G-vec00272-001-s205><push.drücken><en> You just have to push a button “connect” the wireless USB adapter when you want to use as mouse.
<G-vec00169-001-s105><tap.drücken><de> Produktbeschreibung Mehr Bedienkomfort beim schreiben, zeichnen, drücken und ziehen für dein IPad, Iphone oder jedem anderem touchscreen.
<G-vec00169-001-s105><tap.drücken><en> More control as you write, sketch, tap and drag on your iPad, iPhone or any touchscreen.
<G-vec00169-001-s106><tap.drücken><de> Wenn Sie glauben die Antwort zu wissen, oder wenn Ihnen zu der Frage nichts einfällt, ist es an der Zeit, den Knopf Antwort zeigen zu drücken.
<G-vec00169-001-s106><tap.drücken><en> When you think you know the answer or when you cannot recall any answer at all, it is time to tap the Show Answer button.
<G-vec00169-001-s107><tap.drücken><de> Überprüfen Sie die Anzahl der Schichten, die Sie herunterladen möchten - zum Beispiel 13, 14, 15, geben Sie einen Namen für die Karte und drücken Sie die Taste Download.
<G-vec00169-001-s107><tap.drücken><en> Check the number of layers you want to download - for example 13, 14, 15, fill in some name of the map and tap Download. The map will start downloading.
<G-vec00169-001-s108><tap.drücken><de> Den Teilen-Button drücken, um so das Menü der Erweiterungen zu öffnen, anschließend auf “Mehr“ klicken.
<G-vec00169-001-s108><tap.drücken><en> Tap the Share icon to open the extensions menu, and tap the lower “More” button.
<G-vec00169-001-s109><tap.drücken><de> Befinden Sie sich auf dem Home-Bildschirm, können Sie durch doppeltes Drücken der Home-Taste den App-Umschalter öffnen und MBraille auswählen, um wieder in MBraille zurückzukehren.
<G-vec00169-001-s109><tap.drücken><en> When in home screen, you can double tap the home button to open the app switcher and select MBraille to get back.
<G-vec00169-001-s110><tap.drücken><de> Wenn die zeile C:\Windows erscheint, geben Sie zur Vervollständigung \explorer.exe ein und drücken Sie Enter.
<G-vec00169-001-s110><tap.drücken><en> Tap Enter for the C:\Windows line to show up. Right after this line type \explorer.exe and tap Enter once again.
<G-vec00169-001-s111><tap.drücken><de> Wenn die zeile C:\Windows erscheint, geben Sie zur Vervollständigung \explorer.exe ein und drücken Sie Enter.
<G-vec00169-001-s111><tap.drücken><en> Place the cursor right after C:\Windows type \explorer.exe and then tap Enter.
<G-vec00169-001-s112><tap.drücken><de> Es ist sehr einfach zu spielen; Sie müssen nur einen Knopf drücken.
<G-vec00169-001-s112><tap.drücken><en> It's very easy to play; you just need to tap one button.
<G-vec00169-001-s113><tap.drücken><de> Stellen Sie die erforderlichen Eigenschaften des Indikators, dann drücken Sie bitte “ Erledigt”.
<G-vec00169-001-s113><tap.drücken><en> Adjust the indicator properties as required, then please tap “Done”.
<G-vec00272-001-s206><push.drücken><de> Saugpumpen oft - 8 m, und drücken Sie die Wasser, das sie auf einem recht hohen Höhe sind.
<G-vec00272-001-s206><push.drücken><en> Suction pumps often - 8 m, and push the water they are at a fairly high altitude.
<G-vec00272-001-s207><push.drücken><de> Drücken sie einen Knopf in Zimmer 5, um ein Loch verschwinden zu lassen.
<G-vec00272-001-s207><push.drücken><en> In the room at location 5, push a button to make a pit disappear.
<G-vec00272-001-s208><push.drücken><de> Zwei weitere an Bord steigert ermöglichen es Ihnen, drücken Sie den clean-Kanal oder der Crunch/Lead Kanal in die erhöhte Sättigung; perfekt für vintage geschoben-clean Sounds oder solo Töne mit glatten Sättigung und verbesserte Kompression.
<G-vec00272-001-s208><push.drücken><en> A further two onboard boosts allow you to push the clean channel or the crunch/lead channel into increased saturation; perfect for vintage pushed-clean sounds or solo tones with smooth saturation and enhanced compression.
<G-vec00272-001-s209><push.drücken><de> Tag 3: Bereiten Erreger Verdünnung auf OD 600nm = 0.001 und drücken Sie die Bakterien in der gesamten Blattoberfläche mit einer Spritze Infiltration (Schritt 3.3).
<G-vec00272-001-s209><push.drücken><en> Day 3: Prepare pathogen dilution to OD600nm=0.001 and push the bacteria into the entire leaf surface by syringe infiltration (Step 3.3).
<G-vec00272-001-s210><push.drücken><de> Drücken sie den Knopf bei Position 1, damit eine kleine Nische mit einigen Gegenständen erscheint.
<G-vec00272-001-s210><push.drücken><en> ROLAND'S MANOR Push the button at position 1 to make a niche with some items appear.
<G-vec00272-001-s211><push.drücken><de> Sie können verschiedene Stücke in dieser Sound App zusammenführen - einfach drücken Sie die Taste .
<G-vec00272-001-s211><push.drücken><en> You can merge different samples in the sound app - just push the button.
<G-vec00272-001-s212><push.drücken><de> Nutzen Sie unter Ihren Fingerspitzen ein wenig drücken Sie den kleineren der beiden Magnete in den oberen Teil Ihres Ohrläppchen.
<G-vec00272-001-s212><push.drücken><en> Make use of among your fingertips to a little push the smaller of the two magnets inside the upper part of your earlobe.
<G-vec00272-001-s213><push.drücken><de> Drücken Sie den Messinghalter in den Antrieb und sichern diesen mit der gedruckten Zunge.
<G-vec00272-001-s213><push.drücken><en> Push the brass retainer into the drive, and secure it with the printed tongue.
<G-vec00272-001-s214><push.drücken><de> 3 Drücken Sie das Netzkabel in die Vertiefung am Rand der Unterseite des Lautsprechers.
<G-vec00272-001-s214><push.drücken><en> 3 Push the power cord into the notch at the edge of the speaker bottom.
<G-vec00272-001-s215><push.drücken><de> Drücken Sie die Taste um zurückzukehren.
<G-vec00272-001-s215><push.drücken><en> Push the button to came back.
<G-vec00272-001-s216><push.drücken><de> Drücken sie den Knopf bei Position 42, um die westliche Wand verschwinden zu lassen.
<G-vec00272-001-s216><push.drücken><en> Push the button at position 42 to make the western wall disappear.
<G-vec00272-001-s217><push.drücken><de> Drücken Sie den Korken zur Hälfte in eine der Flaschen.
<G-vec00272-001-s217><push.drücken><en> Push the cork halfway into one of the bottles.
<G-vec00272-001-s218><push.drücken><de> Drücken Sie die Zunge nach vorne und dann nach unten - halten Sie sie 2 Sekunden lang in dieser Position.
<G-vec00272-001-s218><push.drücken><en> Push the tongue forward, then down - hold it in that position for 2 seconds.
<G-vec00272-001-s219><push.drücken><de> Drücken Sie einfach die Tastatur auf dem Bildschirm Richtung, können wir die Tastatur Clips lösen.
<G-vec00272-001-s219><push.drücken><en> Just push the keyboard towards the screen direction, we can loosen the keyboard clips.
<G-vec00272-001-s220><push.drücken><de> Und drücken Sie.
<G-vec00272-001-s220><push.drücken><en> And push.
<G-vec00272-001-s221><push.drücken><de> "Setzen Sie in Ihrem ""Geld"", drücken Sie die Taste, und betet für die beste."
<G-vec00272-001-s221><push.drücken><en> "Deposit your ""cash,"" push the button, and wish for the best."
<G-vec00272-001-s222><push.drücken><de> Drücken Sie die Leistung Ihres VPS über die Hardware-Fähigkeiten der traditionellen Spinn Laufwerke.
<G-vec00272-001-s222><push.drücken><en> Push the performance of your VPS beyond the hardware capabilities of traditional spinning drives.
<G-vec00272-001-s223><push.drücken><de> Wenn Sie sich dem Lkw im Dunkeln nähern, drücken Sie einfach die Fernbedienungstaste auf dem Schlüsselanhänger.
<G-vec00272-001-s223><push.drücken><en> When approaching the truck at night, just push the button on the remote key fob.
<G-vec00272-001-s224><push.drücken><de> "Abschließend drücken Sie auf den Button ""Quittung drucken"", um eine Quittung zu erhalten und sich vom Gerät abzumelden."
<G-vec00272-001-s224><push.drücken><en> Afterwards, push the button labelled “Print Receipt” to receive a receipt and log out from the device.
<G-vec00169-001-s114><tap.drücken><de> Drücken Sie Alt+F und gehen Sie zu Tools --> Erweiterungen.
<G-vec00169-001-s114><tap.drücken><en> Simultaneously tap Alt+F, select Tools and click Extensions.
<G-vec00169-001-s115><tap.drücken><de> "Jetzt geben Sie bitte die Stop-Loss(S/L)- oder Take-Profit(T/P)-Kurse ein oder ändern Sie sie, danach drücken Sie den Button ""Modifizieren""."
<G-vec00169-001-s115><tap.drücken><en> Now please enter or change the S/L or T/P levels and then tap the “Modify” button.
<G-vec00169-001-s116><tap.drücken><de> Wählen Sie im Windows-Menü Erweiterte Startoptionen die Option Abgesicherter Modus mit Netzwerktreibern und drücken Sie die Eingabetaste (Enter).
<G-vec00169-001-s116><tap.drücken><en> In the Windows Advanced Options Menu select Safe Mode with Networking and tap Enter.
<G-vec00169-001-s117><tap.drücken><de> Drücken Sie gleichzeitig Strg+Shift+A (Ctrl+Shift+A), um den Add-ons-Manager zu öffnen.
<G-vec00169-001-s117><tap.drücken><en> Simultaneously tap Ctrl+Shift+A for the Add-ons Manager.
<G-vec00169-001-s118><tap.drücken><de> Android: Drücken Sie die Übersichts-Taste oder bleiben Sie lang auf der Home-Taste (geräteabhängig), bis eine Übersicht über die geöffneten Apps erscheint.
<G-vec00169-001-s118><tap.drücken><en> Android: Tap the Overview button or hold the Home button for a few seconds (dependent on your device) until you see an overview of all the apps that are open.
<G-vec00169-001-s119><tap.drücken><de> Drücken Sie den Trimmerkopf, während er sich dreht, kurz auf den Boden, und der Faden wird automatisch nachgeführt.
<G-vec00169-001-s119><tap.drücken><en> Tap the trimmer head against the ground while it's spinning, and it will automatically feed the line. Adjustable Handle
<G-vec00169-001-s120><tap.drücken><de> Drücken Sie während eines Anrufs Besetzt, wenn Sie wiederholt Signaltöne hören.
<G-vec00169-001-s120><tap.drücken><en> When you hear repeated beeps during a call, tap Busy .
<G-vec00169-001-s121><tap.drücken><de> Drücken Sie die Windows-Taste auf dem Hintergrund der Startbildschirm der Metro Benutzeroberfläche zugreifen.
<G-vec00169-001-s121><tap.drücken><en> Tap the Windows key on the background to access the start screen of the Metro UI.
<G-vec00169-001-s122><tap.drücken><de> Drücken Sie Alt+F und gehen Sie zu Tools --> Erweiterungen.
<G-vec00169-001-s122><tap.drücken><en> Simultaneously tap Alt+F and select Settings.
<G-vec00169-001-s123><tap.drücken><de> So bald Sie diese festgelegt haben drücken Sie “Modifizieren”.
<G-vec00169-001-s123><tap.drücken><en> Once you’ve specified these, tap “Modify”.
<G-vec00169-001-s124><tap.drücken><de> Drücken Sie unter Verwendung Ihrer Tastatur die Windows-Taste + R.
<G-vec00169-001-s124><tap.drücken><en> Tap the Windows key + R using your keyboard.
<G-vec00169-001-s125><tap.drücken><de> Jetzt drücken Sie auf das Symbol, dass Sie in ihre Angebotsliste hinzufügen möchten.
<G-vec00169-001-s125><tap.drücken><en> Now please tap on the symbol you’d like to add to your quotes list.
<G-vec00169-001-s126><tap.drücken><de> Klicken Sie auf Schließen und drücken Sie gleichzeitig Alt+X, um erneut das Extras-Menü zu öffnen.
<G-vec00169-001-s126><tap.drücken><en> Click Close and simultaneously tap Alt+T to open the Tools menu again.
<G-vec00169-001-s127><tap.drücken><de> Android: gehen Sie zu den „Google Einstellungen“ (oder „ Einstellungen“ und dann „Google“) und drücken Sie auf „Anzeigen“.
<G-vec00169-001-s127><tap.drücken><en> For Android: go into “Google Settings” (or “Settings” then “Google”), then tap on “Adverts”.
<G-vec00169-001-s128><tap.drücken><de> Drücken Sie gleichzeitig Alt+X, um erneut das Extras-Menü zu öffnen, und wählen Sie Internetoptionen.
<G-vec00169-001-s128><tap.drücken><en> Simultaneously tap Alt+T to open the Tools menu again and select Internet Options.
<G-vec00169-001-s129><tap.drücken><de> Drücken Sie gleichzeitig Strg+Shift+Esc, um den Task-Manager zu öffnen.
<G-vec00169-001-s129><tap.drücken><en> Tap Ctrl+Shift+Esc simultaneously to run the Task Manager.
<G-vec00272-001-s225><push.drücken><de> Wenn er gegen seinen Willen hier ist, dann verhält er sich wie ein Ballon, den man unter Wasser drückt.
<G-vec00272-001-s225><push.drücken><en> If it's here against its will, it's going to be like a balloon you push under the water.
<G-vec00272-001-s226><push.drücken><de> Durch eine versteckte Öffnung an der Rückseite drückt man mit dem Finger oder einem Stift die Transparentabdeckung nach vorne, um das Plakat zu tauschen.
<G-vec00272-001-s226><push.drücken><en> A hidden release hole at the back of each panel is accessed using a finger or pen to push the transparent cover forward in order to change the poster.
<G-vec00272-001-s227><push.drücken><de> – das Ich drückt dann einen Knopf und daraufhin bewegt sich die Hand und tut etwas oder der Mund sagt etwas usw.
<G-vec00272-001-s227><push.drücken><en> and then you push the button, and the hand moves and does this, or the mouth says that, and so on.
<G-vec00272-001-s228><push.drücken><de> Drückt man die Kappe ein, löst sie sich vom äußeren Ring und kann abgezogen werden.
<G-vec00272-001-s228><push.drücken><en> When you push in the cap it detaches itself from the outer ring and can be removed.
<G-vec00272-001-s229><push.drücken><de> Entsprechend drückt man die Erde nur ein verschwindend kleines Stück nach unten, während man den Kleinwagen anhebt.
<G-vec00272-001-s229><push.drücken><en> Accordingly you push the earth just a little distance away while lifting the car.
<G-vec00272-001-s230><push.drücken><de> Jetzt drückt man das zweite, dünnere PVC-Röhrchen von der hinteren Seite in den Lauf hinein und stößt so die Murmel und den Magnetzylinder Richtung Ringmagneten (siehe nochmals Zeichnung oben).
<G-vec00272-001-s230><push.drücken><en> Now, you push the thinner PVC tube into the backside of the barrel, and thereby push the marble and the magnetic cylinder towards the ring magnet (see drawing above).
<G-vec00272-001-s231><push.drücken><de> Dann hebt man ein Knie auf das Ende des Brettes und drückt so den Rest des Brettes auch unter Wasser.
<G-vec00272-001-s231><push.drücken><en> Then one has to use one knee to push the tail of the board under the water.
<G-vec00272-001-s232><push.drücken><de> Drückt diesen, um die daneben liegende Wand zu öffnen.
<G-vec00272-001-s232><push.drücken><en> Push it to open the adjoining wall.
<G-vec00272-001-s233><push.drücken><de> Ein einfaches Drehen des Griffs drückt den Kompressor auf die Membran hinunter, wobei diese wiederum gegen den Steg des Ventilkörpers gedrückt wird und sich dadurch das Ventil letztendlich schließt.
<G-vec00272-001-s233><push.drücken><en> A simple turn of the handle will push the compressor downwards on the diaphragm, pressing the diaphragm against the weir of the valve body thereby closing the valve.
<G-vec00272-001-s234><push.drücken><de> Füllen Sie den Spalt mit etwas, das einigermaßen hitzebeständig ist und im Laufe der Zeit nicht zusammengedrückt werden kann, anderenfalls kann es passieren, daß der Federkontakt des Newton die obere rechte Zelle im Laufe der Zeit nach links drückt, was das Pack ziemlich schnell unbrauchbar machen würde.
<G-vec00272-001-s234><push.drücken><en> Fill it with something moderately heat-resistant that can't be compressed over time, otherwise the spring contact in your Newton might eventually push cell 1 to the left which would effectively make the pack useless.
<G-vec00272-001-s235><push.drücken><de> Das ist die Kraft des Stoßes gegen den magnetischen Nordpol, jedes Mal wenn er Planet X mit dem Gesicht gegenübersteht.Bewegt euch weiter,drückt zurück, ist der Stoß von Planet X, der die Ursache für das Figur 8-Wackeln ist, das viele dokumentieren.
<G-vec00272-001-s235><push.drücken><en> This is the force of the push against the magnetic N. Pole whenever it presents a face to Planet X. Move on, push back, is the shove from Planet X, which is the cause of the Figure 8 wobble many are documenting.
<G-vec00272-001-s236><push.drücken><de> Lernt von ihnen, aber drückt sie nicht herunter, indem ihr euch selbst über sie setzt.
<G-vec00272-001-s236><push.drücken><en> Learn from them, but do not push them down by declaring yourself over them.
<G-vec00272-001-s237><push.drücken><de> Besser man drückt die Wirbelsäule im Vierfüßlerstand nach oben.
<G-vec00272-001-s237><push.drücken><en> It is better to push the vertebral column upwards while being in a quadruped position.
<G-vec00272-001-s238><push.drücken><de> Drückt man den Knopf auf der rechten Seite des Filmadapters so wird das eingelegte Dia mechanisch wieder herausgeschoben, so dass man es bequem entnehmen kann.
<G-vec00272-001-s238><push.drücken><en> If you push the button on the right hand side of the film adaptor the inserted slide is pushed out mechanically, so that it can be easily removed.
<G-vec00272-001-s239><push.drücken><de> Der Deckel drückt das Baustein-Gehäuse mithilfe eines vorgespannten Federsystems auf die Kontakte, sodass sich das System für unterschiedliche Gehäusehöhen eignet.
<G-vec00272-001-s239><push.drücken><en> The lid is designed to push the package onto the contacts due to a spring-loaded system fitting different package thicknesses.
<G-vec00272-001-s240><push.drücken><de> Drückt die linke Seite nach oben und rechte Seite hinunter, damit Ego und Superego in Balanze kommen.
<G-vec00272-001-s240><push.drücken><en> Push the left side higher and right side lower so the ego and super-ego get the balance.
<G-vec00272-001-s241><push.drücken><de> Drückt man den Lenkerstummel nach vorn fällt das Motorrad entsprechend in Schräglage.
<G-vec00272-001-s241><push.drücken><en> If you push the steering wheel forward the motorcycle falls accordingly in an oblique position.
<G-vec00272-001-s242><push.drücken><de> Er drückt sie so, aber die Planeten widerstehen durch ihre Größe und die Trümmer im Asteroidengürtel haben nicht die Empfindlichkeit, die Kometen haben.
<G-vec00272-001-s242><push.drücken><en> It does so push, but the planets by their size resist and the debris in the Asteroid Belt does not have the sensitivity that comets do.
<G-vec00272-001-s243><push.drücken><de> Die Wildbearads.bid Website drückt ein “bestätigen Benachrichtigungen” Botschaft, fragen Sie Benachrichtigungen von dieser Website abonnieren.
<G-vec00272-001-s243><push.drücken><en> The Wildbearads.bid website will push a “Confirm notifications” message, asking you to subscribe to alerts from this website.
