<G-vec00272-001-s168><push.drücken><de> Beispiel: Möchtest Du etwas um 30° drehen, dann tippe ein <30 und drücke Enter, dann greife den Drehen-Griff und das Objekt kann nun in 30° Schritten gedreht werden.
<G-vec00272-001-s168><push.drücken><en> So for example if you want to rotate something by 30 degrees, type in <30 and push enter, then grab that rotation grip and it will rotate in 30 degree increments.
<G-vec00272-001-s169><push.drücken><de> Sitze zurückgelehnt und drücke die Brust gegen das Kissen.
<G-vec00272-001-s169><push.drücken><en> Sit back straight, push your chest against the cushion.
<G-vec00272-001-s170><push.drücken><de> Drücke zu Beginn und zum Ende des Urinierens hin stark, damit es nicht so sehr tröpfelt.
<G-vec00272-001-s170><push.drücken><en> Push hard at the beginning of your flow and then again to end the stream.
<G-vec00272-001-s171><push.drücken><de> Drücke vorwärts und halte die Sprint-Taste gedrückt.
<G-vec00272-001-s171><push.drücken><en> Push forward and hold down the sprint button.
<G-vec00272-001-s172><push.drücken><de> Drücke - oder Backspace, um eine Seite zurückzublättern (blättert zur letzten Seite, falls Du auf der ersten Seite bist).
<G-vec00272-001-s172><push.drücken><en> Push - or Backspace to flip to previous page (last page if on first page).
<G-vec00272-001-s173><push.drücken><de> Drücke d oder D, um tiefer zu fliegen (down).
<G-vec00272-001-s173><push.drücken><en> Push d or D to fly down (lower).
<G-vec00272-001-s174><push.drücken><de> Wähle Beschleunigen aus, drücke dann den Rechten Analogstick nach vorne.
<G-vec00272-001-s174><push.drücken><en> Select Accelerate, then push the Right analog stick forward.
<G-vec00272-001-s175><push.drücken><de> Ziehe jeden nach oben und drücke keinen runter.
<G-vec00272-001-s175><push.drücken><en> Pull everyone up, and push no one down.
<G-vec00272-001-s176><push.drücken><de> Nimm einen Schritt mit deinem rechten Fuß und drücke mit deinem linken Stock.
<G-vec00272-001-s176><push.drücken><en> Take a step with your right foot, and push with your left stick.
<G-vec00272-001-s177><push.drücken><de> Drücke es mit dem Finger in der Mitte nach unten, so dass es es sich am gerade gebohrten Loch etwas einwölbt.
<G-vec00272-001-s177><push.drücken><en> Push it down in the middle with your finger so that it forms an indentation in the hole that you just made.
<G-vec00272-001-s178><push.drücken><de> Um die Spacer zu verwenden, lege sie einfach auf das Gewinde deines Ytrucks Achsstifts und drücke sie langsam mit deinem Wheel fest.
<G-vec00272-001-s178><push.drücken><en> To mount the Spacers just place them on your Ytrucks axle and push them in gently with your wheel.
<G-vec00272-001-s179><push.drücken><de> Drücke leicht auf den Knopf und sorge dafür, dass das Licht an und aus flackern kann.
<G-vec00272-001-s179><push.drücken><en> Gently push on the power button and make sure that the light can flicker on and off.
<G-vec00272-001-s180><push.drücken><de> Lege deinen Zeigefinger waagerecht unter deine Wimpern und drücke sie an dein Augenlid.
<G-vec00272-001-s180><push.drücken><en> Place your forefinger horizontally under your eyelashes and push them up against your lid.
<G-vec00272-001-s181><push.drücken><de> Drücke fest auf die Schrauben und drehe sie langsam.
<G-vec00272-001-s181><push.drücken><en> Push hard and start to turn the screws slowly.
<G-vec00272-001-s182><push.drücken><de> Drücke die Nase unter die Oberfläche indem du deinen Rücken beugst und die Nase mit deinen Händen nach unten drückst.
<G-vec00272-001-s182><push.drücken><en> Push the nose of the board under the surface by arching your back and pushing down on the nose with your hands.
<G-vec00272-001-s183><push.drücken><de> Kratze an der Oberfläche und drücke die richtigen Knöpfe, und sie werden ebenso zornig sein wie jeder andere, ja sogar noch mehr, weil sie sich darüber Illusionen machen.
<G-vec00272-001-s183><push.drücken><en> Scratch the surface and push the right buttons and they're just as angry as the next person, indeed more so, because they're delusional about it.
<G-vec00272-001-s184><push.drücken><de> Außer Atem und gegen einen sich mühenden Bastille, hebe ich mein linkes Knie über seinen rechten Oberschenkel und drücke ihn mit meiner linken Hand auf den Boden, sodass er sich nicht mehr bewegen kann.
<G-vec00272-001-s184><push.drücken><en> Out of breath, and fighting against a struggling Bastille, I slide my left knee over his right thigh and push down on his chest with my left hand so he wouldn’t get up.
<G-vec00272-001-s185><push.drücken><de> Drücke sanft das Papier wieder nach innen, um die Knalltüte nochmal zu verwenden.
<G-vec00272-001-s185><push.drücken><en> To re-use the banger, just gently push the paper back in.
<G-vec00272-001-s186><push.drücken><de> Drücke ihn dann wieder ein wenig vor, um Deinen Cones etwas zusätzliche Füllung zu geben (je mehr Du bei diesem letzten Schritt drückst, desto fester kannst Du Deine Cones stopfen).
<G-vec00272-001-s186><push.drücken><en> Slide the top part forward and then back. Now, push just a little bit forward again to give your cones that extra pack (the more you push on this last step, the harder you can pack your cones).
<G-vec00272-001-s187><push.drücken><de> Wenn Sie drücken die “ermöglichen” Taste, dann werden Sie beginnen von Gogoputlocker.com auf Ihrem Desktop unerwünschte Pop-up-Anzeigen zu sehen, auch wenn Ihr Internet-Browser geschlossen ist.
<G-vec00272-001-s187><push.drücken><en> If you push the “Allow” button, then you will begin seeing unwanted pop-up ads from Gogoputlocker.com on your desktop even when your internet browser is closed.
<G-vec00272-001-s188><push.drücken><de> So viel zu fleischlichen Sünden Drücken Sie nicht, aber für die geistige: die Superbia, die empietÃ, die Vermutung, Blinde, l'odio, die ipocrisia, die Lüge, Duplizität.
<G-vec00272-001-s188><push.drücken><en> The main aim of Satan is not even so much the corruption of passions but the corruption of the spirit. Do not push so much to carnal sins, but for the spiritual: the Superbia, the empietà, the presumption, the blind, hatred, the ipocrisia, the lie, duplicity.
<G-vec00272-001-s189><push.drücken><de> Wenn der Fahrer den Fuß vom Pedal, die Federn drücken Sie die Druckplatte gegen die Kupplungsscheibe, die wiederum drückt gegen das Schwungrad.
<G-vec00272-001-s189><push.drücken><en> When the driver’s foot is off the pedal, the springs push the pressure plate against the clutch disc, which in turn presses against the flywheel.
<G-vec00272-001-s190><push.drücken><de> Ich denke viele von Ihnen würden die Schaltfläche jeden Tag drücken um Künstlern, deren Arbeit Sie mögen, einen Euro zu senden.
<G-vec00272-001-s190><push.drücken><en> I think a lot of you might push that button every day, to give one euro to some artist who had made a work that you liked.
<G-vec00272-001-s191><push.drücken><de> Ich konnte die Schwester sehen, die versuchte das Kind aus mir heraus zu drücken, und dann hörte ich auf darauf zu achten.
<G-vec00272-001-s191><push.drücken><en> I could see the nurse trying to push the baby out of me, and then I quit paying attention.
<G-vec00272-001-s192><push.drücken><de> Beschreibung Durch das Drücken des Druckknopfes am Griff des Bolzens, werden am anderen Ende die Sperrkugeln gelöst.
<G-vec00272-001-s192><push.drücken><en> Description By depressing the push button on the bolt grip, the balls at the other end are released.
<G-vec00272-001-s193><push.drücken><de> SYNCHRESIS FLUGDECK TECHNOLOGY arbeiten, Klang-ausgestattet, 3d-modelliert VC Layouts, Veranstaltungen, Knöpfe, Tasten drücken Flip-Cover, gleitenden Animationen, ausblenden Joche Sitze (für große Anschaltung Benutzer) Funktionen je fortschrittlichste 737 gebaut Simulation... (siehe unsere technische Seiten).
<G-vec00272-001-s193><push.drücken><en> SYNCHRESIS TECHNOLOGY working, sound-equipped, 3d-modeled VC layouts, switches, events, knobs, buttons push flip covers, sliding animations, HIDE yokes seats (for large montior users) ever before most 737 built simulation... (see our spec pages).
<G-vec00272-001-s194><push.drücken><de> Dieses Feature funktioniert sofort und ohne spezielle Konfiguration: Sie wählen dann einfach einen VM-Backup, einen Wiederherstellungspunkt und einen Wiederherstellungsspeicherort (einen Host, eine Ressourcenquelle oder einen Cluster, wo eine wiederhergestellte VM laufen soll), dann drücken Sie eine Taste – die VM wird in kürzester Zeit gebootet.
<G-vec00272-001-s194><push.drücken><en> This feature works right out of the box without any special setup. Just choose a VM backup, a recovery point, and a recovery location (a host, a resource pool, or a cluster where you want to run the recovered VM), then push a button – the VM is booted in no time.
<G-vec00272-001-s195><push.drücken><de> In den schlimmsten Tagen aufgrund der Zittern der Hand konnte ich den Löffel in den Mund nicht drücken.
<G-vec00272-001-s195><push.drücken><en> In the worst days due to the hand tremor I could not push the spoon in mouth.
<G-vec00272-001-s196><push.drücken><de> In weniger dringenden Fällen drücken Sie bitte an den Notruf- und Info-Säulen die grüne Infotaste - etwa wenn Sie sehen, dass in einer Station ein Automat nicht funktioniert oder das Licht ausgefallen ist.
<G-vec00272-001-s196><push.drücken><en> If it is not particularly urgent, please push the green information button of the emergency call and information pillar - for example if you notice that a vending machine is out of order or the light doesn't work.
<G-vec00272-001-s197><push.drücken><de> Sie drücken eine Taste runter und heraus kommt dieser Ton.
<G-vec00272-001-s197><push.drücken><en> They push a key down and out comes this sound.
<G-vec00272-001-s198><push.drücken><de> Einfach den Knopf drücken und davor arbeiten.
<G-vec00272-001-s198><push.drücken><en> Simply push the button and work in front of it.
<G-vec00272-001-s199><push.drücken><de> "Die Republikaner versuchen zu drücken ein ein ""Negativ"" von dies bouncy, progressiv Buchstabe mit einer ein viel wiederholen Fernsehapparat Anzeige vier Jahr vor zeigen eine ein Reihe von videoClip mit einem ein beleben Wellstone spitz gestikulieren und schreien, als ob er sein auf einem ein sozialistisch soapbox nach dem d gross Schlag 1934."
<G-vec00272-001-s199><push.drücken><en> "The Republicans tried to push a ""negative"" of this bouncy, progressive character with a much repeated TV ad of four years ago showing a series of video clips with an animated Wellstone pointedly gesturing and shouting, as if he were on a socialist soapbox after the big strike in 1934."
<G-vec00272-001-s200><push.drücken><de> Es ist nicht notwendig, den Kolben nach unten zu drücken.
<G-vec00272-001-s200><push.drücken><en> It is not necessary to push the plunger down.
<G-vec00272-001-s201><push.drücken><de> Drücken Sie dann den Download Button und speichern Sie die Datei citroen-myway.zip in einem Ordner auf Ihrer Festplatte.
<G-vec00272-001-s201><push.drücken><en> Push Download button and save the file citroen-myway.zip to your hard disk.
<G-vec00272-001-s202><push.drücken><de> Jeder Kanal verfügt über unabhängige Gain-Level Regler für maximale Gewinn-Niveau control, während eine dual Boost-Schaltung ermöglicht, drücken Sie entweder die reinigen oder Crunch/Lead Kanäle in die erhöhte Sättigung für geschoben-reinigen und Solo-Töne.
<G-vec00272-001-s202><push.drücken><en> Each channel has independent gain/level controls for maximum gain-level control, while a dual boost circuit enables you to push either the clean or crunch/lead channels into increased saturation for pushed-clean and solo tones.
<G-vec00272-001-s203><push.drücken><de> "Um der „Website Builder“ nach Ihrem einzigartigen Geschmack zu gestalten, drücken Sie einfach den orangen Button „Download""und fügen Sie danach die heruntergeladene Datei in den Ordner Ihrer Joomla 1.5 Installation hinzu."
<G-vec00272-001-s203><push.drücken><en> To make Mini Website-Builder your own Joomla website theme, simply push the orange Download button to download it and afterwards add it to your Joomla 1.5.x installation folder.
<G-vec00272-001-s204><push.drücken><de> Dies bedeutet, dass es eine konstante Tendenz für Flüssigkeit, nach innen - in die Blutkörperchen zu drücken.
<G-vec00272-001-s204><push.drücken><en> This means there is a constant tendency for liquid to push inward - into the blood cell.
<G-vec00272-001-s205><push.drücken><de> Sie müssen nur einen Knopf drücken “verbinden” WLAN USB-Adapter, wenn Sie als Maus verwenden möchten..
<G-vec00272-001-s205><push.drücken><en> You just have to push a button “connect” the wireless USB adapter when you want to use as mouse.
<G-vec00169-001-s105><tap.drücken><de> Produktbeschreibung Mehr Bedienkomfort beim schreiben, zeichnen, drücken und ziehen für dein IPad, Iphone oder jedem anderem touchscreen.
<G-vec00169-001-s105><tap.drücken><en> More control as you write, sketch, tap and drag on your iPad, iPhone or any touchscreen.
<G-vec00169-001-s106><tap.drücken><de> Wenn Sie glauben die Antwort zu wissen, oder wenn Ihnen zu der Frage nichts einfällt, ist es an der Zeit, den Knopf Antwort zeigen zu drücken.
<G-vec00169-001-s106><tap.drücken><en> When you think you know the answer or when you cannot recall any answer at all, it is time to tap the Show Answer button.
<G-vec00169-001-s107><tap.drücken><de> Überprüfen Sie die Anzahl der Schichten, die Sie herunterladen möchten - zum Beispiel 13, 14, 15, geben Sie einen Namen für die Karte und drücken Sie die Taste Download.
<G-vec00169-001-s107><tap.drücken><en> Check the number of layers you want to download - for example 13, 14, 15, fill in some name of the map and tap Download. The map will start downloading.
<G-vec00169-001-s108><tap.drücken><de> Den Teilen-Button drücken, um so das Menü der Erweiterungen zu öffnen, anschließend auf “Mehr“ klicken.
<G-vec00169-001-s108><tap.drücken><en> Tap the Share icon to open the extensions menu, and tap the lower “More” button.
<G-vec00169-001-s109><tap.drücken><de> Befinden Sie sich auf dem Home-Bildschirm, können Sie durch doppeltes Drücken der Home-Taste den App-Umschalter öffnen und MBraille auswählen, um wieder in MBraille zurückzukehren.
<G-vec00169-001-s109><tap.drücken><en> When in home screen, you can double tap the home button to open the app switcher and select MBraille to get back.
<G-vec00169-001-s110><tap.drücken><de> Wenn die zeile C:\Windows erscheint, geben Sie zur Vervollständigung \explorer.exe ein und drücken Sie Enter.
<G-vec00169-001-s110><tap.drücken><en> Tap Enter for the C:\Windows line to show up. Right after this line type \explorer.exe and tap Enter once again.
<G-vec00169-001-s112><tap.drücken><de> Es ist sehr einfach zu spielen; Sie müssen nur einen Knopf drücken.
<G-vec00169-001-s112><tap.drücken><en> It's very easy to play; you just need to tap one button.
<G-vec00169-001-s113><tap.drücken><de> Stellen Sie die erforderlichen Eigenschaften des Indikators, dann drücken Sie bitte “ Erledigt”.
<G-vec00169-001-s113><tap.drücken><en> Adjust the indicator properties as required, then please tap “Done”.
<G-vec00272-001-s206><push.drücken><de> Saugpumpen oft - 8 m, und drücken Sie die Wasser, das sie auf einem recht hohen Höhe sind.
<G-vec00272-001-s206><push.drücken><en> Suction pumps often - 8 m, and push the water they are at a fairly high altitude.
<G-vec00272-001-s207><push.drücken><de> Drücken sie einen Knopf in Zimmer 5, um ein Loch verschwinden zu lassen.
<G-vec00272-001-s207><push.drücken><en> In the room at location 5, push a button to make a pit disappear.
<G-vec00272-001-s208><push.drücken><de> Zwei weitere an Bord steigert ermöglichen es Ihnen, drücken Sie den clean-Kanal oder der Crunch/Lead Kanal in die erhöhte Sättigung; perfekt für vintage geschoben-clean Sounds oder solo Töne mit glatten Sättigung und verbesserte Kompression.
<G-vec00272-001-s208><push.drücken><en> A further two onboard boosts allow you to push the clean channel or the crunch/lead channel into increased saturation; perfect for vintage pushed-clean sounds or solo tones with smooth saturation and enhanced compression.
<G-vec00272-001-s209><push.drücken><de> Tag 3: Bereiten Erreger Verdünnung auf OD 600nm = 0.001 und drücken Sie die Bakterien in der gesamten Blattoberfläche mit einer Spritze Infiltration (Schritt 3.3).
<G-vec00272-001-s209><push.drücken><en> Day 3: Prepare pathogen dilution to OD600nm=0.001 and push the bacteria into the entire leaf surface by syringe infiltration (Step 3.3).
<G-vec00272-001-s210><push.drücken><de> Drücken sie den Knopf bei Position 1, damit eine kleine Nische mit einigen Gegenständen erscheint.
<G-vec00272-001-s210><push.drücken><en> ROLAND'S MANOR Push the button at position 1 to make a niche with some items appear.
<G-vec00272-001-s211><push.drücken><de> Sie können verschiedene Stücke in dieser Sound App zusammenführen - einfach drücken Sie die Taste .
<G-vec00272-001-s211><push.drücken><en> You can merge different samples in the sound app - just push the button.
<G-vec00272-001-s212><push.drücken><de> Nutzen Sie unter Ihren Fingerspitzen ein wenig drücken Sie den kleineren der beiden Magnete in den oberen Teil Ihres Ohrläppchen.
<G-vec00272-001-s212><push.drücken><en> Make use of among your fingertips to a little push the smaller of the two magnets inside the upper part of your earlobe.
<G-vec00272-001-s213><push.drücken><de> Drücken Sie den Messinghalter in den Antrieb und sichern diesen mit der gedruckten Zunge.
<G-vec00272-001-s213><push.drücken><en> Push the brass retainer into the drive, and secure it with the printed tongue.
<G-vec00272-001-s214><push.drücken><de> 3 Drücken Sie das Netzkabel in die Vertiefung am Rand der Unterseite des Lautsprechers.
<G-vec00272-001-s214><push.drücken><en> 3 Push the power cord into the notch at the edge of the speaker bottom.
<G-vec00272-001-s215><push.drücken><de> Drücken Sie die Taste um zurückzukehren.
<G-vec00272-001-s215><push.drücken><en> Push the button to came back.
<G-vec00272-001-s216><push.drücken><de> Drücken sie den Knopf bei Position 42, um die westliche Wand verschwinden zu lassen.
<G-vec00272-001-s216><push.drücken><en> Push the button at position 42 to make the western wall disappear.
<G-vec00272-001-s217><push.drücken><de> Drücken Sie den Korken zur Hälfte in eine der Flaschen.
<G-vec00272-001-s217><push.drücken><en> Push the cork halfway into one of the bottles.
<G-vec00272-001-s218><push.drücken><de> Drücken Sie die Zunge nach vorne und dann nach unten - halten Sie sie 2 Sekunden lang in dieser Position.
<G-vec00272-001-s218><push.drücken><en> Push the tongue forward, then down - hold it in that position for 2 seconds.
<G-vec00272-001-s219><push.drücken><de> Drücken Sie einfach die Tastatur auf dem Bildschirm Richtung, können wir die Tastatur Clips lösen.
<G-vec00272-001-s219><push.drücken><en> Just push the keyboard towards the screen direction, we can loosen the keyboard clips.
<G-vec00272-001-s220><push.drücken><de> Und drücken Sie.
<G-vec00272-001-s220><push.drücken><en> And push.
<G-vec00272-001-s221><push.drücken><de> "Setzen Sie in Ihrem ""Geld"", drücken Sie die Taste, und betet für die beste."
<G-vec00272-001-s221><push.drücken><en> "Deposit your ""cash,"" push the button, and wish for the best."
<G-vec00272-001-s222><push.drücken><de> Drücken Sie die Leistung Ihres VPS über die Hardware-Fähigkeiten der traditionellen Spinn Laufwerke.
<G-vec00272-001-s222><push.drücken><en> Push the performance of your VPS beyond the hardware capabilities of traditional spinning drives.
<G-vec00272-001-s223><push.drücken><de> Wenn Sie sich dem Lkw im Dunkeln nähern, drücken Sie einfach die Fernbedienungstaste auf dem Schlüsselanhänger.
<G-vec00272-001-s223><push.drücken><en> When approaching the truck at night, just push the button on the remote key fob.
<G-vec00272-001-s224><push.drücken><de> "Abschließend drücken Sie auf den Button ""Quittung drucken"", um eine Quittung zu erhalten und sich vom Gerät abzumelden."
<G-vec00272-001-s224><push.drücken><en> Afterwards, push the button labelled “Print Receipt” to receive a receipt and log out from the device.
<G-vec00169-001-s114><tap.drücken><de> Drücken Sie Alt+F und gehen Sie zu Tools --> Erweiterungen.
<G-vec00169-001-s114><tap.drücken><en> Simultaneously tap Alt+F, select Tools and click Extensions.
<G-vec00169-001-s115><tap.drücken><de> "Jetzt geben Sie bitte die Stop-Loss(S/L)- oder Take-Profit(T/P)-Kurse ein oder ändern Sie sie, danach drücken Sie den Button ""Modifizieren""."
<G-vec00169-001-s115><tap.drücken><en> Now please enter or change the S/L or T/P levels and then tap the “Modify” button.
<G-vec00169-001-s116><tap.drücken><de> Wählen Sie im Windows-Menü Erweiterte Startoptionen die Option Abgesicherter Modus mit Netzwerktreibern und drücken Sie die Eingabetaste (Enter).
<G-vec00169-001-s116><tap.drücken><en> In the Windows Advanced Options Menu select Safe Mode with Networking and tap Enter.
<G-vec00169-001-s117><tap.drücken><de> Drücken Sie gleichzeitig Strg+Shift+A (Ctrl+Shift+A), um den Add-ons-Manager zu öffnen.
<G-vec00169-001-s117><tap.drücken><en> Simultaneously tap Ctrl+Shift+A for the Add-ons Manager.
<G-vec00169-001-s118><tap.drücken><de> Android: Drücken Sie die Übersichts-Taste oder bleiben Sie lang auf der Home-Taste (geräteabhängig), bis eine Übersicht über die geöffneten Apps erscheint.
<G-vec00169-001-s118><tap.drücken><en> Android: Tap the Overview button or hold the Home button for a few seconds (dependent on your device) until you see an overview of all the apps that are open.
<G-vec00169-001-s119><tap.drücken><de> Drücken Sie den Trimmerkopf, während er sich dreht, kurz auf den Boden, und der Faden wird automatisch nachgeführt.
<G-vec00169-001-s119><tap.drücken><en> Tap the trimmer head against the ground while it's spinning, and it will automatically feed the line. Adjustable Handle
<G-vec00169-001-s120><tap.drücken><de> Drücken Sie während eines Anrufs Besetzt, wenn Sie wiederholt Signaltöne hören.
<G-vec00169-001-s120><tap.drücken><en> When you hear repeated beeps during a call, tap Busy .
<G-vec00169-001-s121><tap.drücken><de> Drücken Sie die Windows-Taste auf dem Hintergrund der Startbildschirm der Metro Benutzeroberfläche zugreifen.
<G-vec00169-001-s121><tap.drücken><en> Tap the Windows key on the background to access the start screen of the Metro UI.
<G-vec00169-001-s123><tap.drücken><de> So bald Sie diese festgelegt haben drücken Sie “Modifizieren”.
<G-vec00169-001-s123><tap.drücken><en> Once you’ve specified these, tap “Modify”.
<G-vec00169-001-s124><tap.drücken><de> Drücken Sie unter Verwendung Ihrer Tastatur die Windows-Taste + R.
<G-vec00169-001-s124><tap.drücken><en> Tap the Windows key + R using your keyboard.
<G-vec00169-001-s125><tap.drücken><de> Jetzt drücken Sie auf das Symbol, dass Sie in ihre Angebotsliste hinzufügen möchten.
<G-vec00169-001-s125><tap.drücken><en> Now please tap on the symbol you’d like to add to your quotes list.
<G-vec00169-001-s126><tap.drücken><de> Klicken Sie auf Schließen und drücken Sie gleichzeitig Alt+X, um erneut das Extras-Menü zu öffnen.
<G-vec00169-001-s126><tap.drücken><en> Click Close and simultaneously tap Alt+T to open the Tools menu again.
<G-vec00169-001-s127><tap.drücken><de> Android: gehen Sie zu den „Google Einstellungen“ (oder „ Einstellungen“ und dann „Google“) und drücken Sie auf „Anzeigen“.
<G-vec00169-001-s127><tap.drücken><en> For Android: go into “Google Settings” (or “Settings” then “Google”), then tap on “Adverts”.
<G-vec00169-001-s128><tap.drücken><de> Drücken Sie gleichzeitig Alt+X, um erneut das Extras-Menü zu öffnen, und wählen Sie Internetoptionen.
<G-vec00169-001-s128><tap.drücken><en> Simultaneously tap Alt+T to open the Tools menu again and select Internet Options.
<G-vec00169-001-s129><tap.drücken><de> Drücken Sie gleichzeitig Strg+Shift+Esc, um den Task-Manager zu öffnen.
<G-vec00169-001-s129><tap.drücken><en> Tap Ctrl+Shift+Esc simultaneously to run the Task Manager.
<G-vec00272-001-s225><push.drücken><de> Wenn er gegen seinen Willen hier ist, dann verhält er sich wie ein Ballon, den man unter Wasser drückt.
<G-vec00272-001-s225><push.drücken><en> If it's here against its will, it's going to be like a balloon you push under the water.
<G-vec00272-001-s226><push.drücken><de> Durch eine versteckte Öffnung an der Rückseite drückt man mit dem Finger oder einem Stift die Transparentabdeckung nach vorne, um das Plakat zu tauschen.
<G-vec00272-001-s226><push.drücken><en> A hidden release hole at the back of each panel is accessed using a finger or pen to push the transparent cover forward in order to change the poster.
<G-vec00272-001-s227><push.drücken><de> – das Ich drückt dann einen Knopf und daraufhin bewegt sich die Hand und tut etwas oder der Mund sagt etwas usw.
<G-vec00272-001-s227><push.drücken><en> and then you push the button, and the hand moves and does this, or the mouth says that, and so on.
<G-vec00272-001-s228><push.drücken><de> Drückt man die Kappe ein, löst sie sich vom äußeren Ring und kann abgezogen werden.
<G-vec00272-001-s228><push.drücken><en> When you push in the cap it detaches itself from the outer ring and can be removed.
<G-vec00272-001-s229><push.drücken><de> Entsprechend drückt man die Erde nur ein verschwindend kleines Stück nach unten, während man den Kleinwagen anhebt.
<G-vec00272-001-s229><push.drücken><en> Accordingly you push the earth just a little distance away while lifting the car.
<G-vec00272-001-s230><push.drücken><de> Jetzt drückt man das zweite, dünnere PVC-Röhrchen von der hinteren Seite in den Lauf hinein und stößt so die Murmel und den Magnetzylinder Richtung Ringmagneten (siehe nochmals Zeichnung oben).
<G-vec00272-001-s230><push.drücken><en> Now, you push the thinner PVC tube into the backside of the barrel, and thereby push the marble and the magnetic cylinder towards the ring magnet (see drawing above).
<G-vec00272-001-s231><push.drücken><de> Dann hebt man ein Knie auf das Ende des Brettes und drückt so den Rest des Brettes auch unter Wasser.
<G-vec00272-001-s231><push.drücken><en> Then one has to use one knee to push the tail of the board under the water.
<G-vec00272-001-s232><push.drücken><de> Drückt diesen, um die daneben liegende Wand zu öffnen.
<G-vec00272-001-s232><push.drücken><en> Push it to open the adjoining wall.
<G-vec00272-001-s233><push.drücken><de> Ein einfaches Drehen des Griffs drückt den Kompressor auf die Membran hinunter, wobei diese wiederum gegen den Steg des Ventilkörpers gedrückt wird und sich dadurch das Ventil letztendlich schließt.
<G-vec00272-001-s233><push.drücken><en> A simple turn of the handle will push the compressor downwards on the diaphragm, pressing the diaphragm against the weir of the valve body thereby closing the valve.
<G-vec00272-001-s234><push.drücken><de> Füllen Sie den Spalt mit etwas, das einigermaßen hitzebeständig ist und im Laufe der Zeit nicht zusammengedrückt werden kann, anderenfalls kann es passieren, daß der Federkontakt des Newton die obere rechte Zelle im Laufe der Zeit nach links drückt, was das Pack ziemlich schnell unbrauchbar machen würde.
<G-vec00272-001-s234><push.drücken><en> Fill it with something moderately heat-resistant that can't be compressed over time, otherwise the spring contact in your Newton might eventually push cell 1 to the left which would effectively make the pack useless.
<G-vec00272-001-s235><push.drücken><de> Das ist die Kraft des Stoßes gegen den magnetischen Nordpol, jedes Mal wenn er Planet X mit dem Gesicht gegenübersteht.Bewegt euch weiter,drückt zurück, ist der Stoß von Planet X, der die Ursache für das Figur 8-Wackeln ist, das viele dokumentieren.
<G-vec00272-001-s235><push.drücken><en> This is the force of the push against the magnetic N. Pole whenever it presents a face to Planet X. Move on, push back, is the shove from Planet X, which is the cause of the Figure 8 wobble many are documenting.
<G-vec00272-001-s236><push.drücken><de> Lernt von ihnen, aber drückt sie nicht herunter, indem ihr euch selbst über sie setzt.
<G-vec00272-001-s236><push.drücken><en> Learn from them, but do not push them down by declaring yourself over them.
<G-vec00272-001-s237><push.drücken><de> Besser man drückt die Wirbelsäule im Vierfüßlerstand nach oben.
<G-vec00272-001-s237><push.drücken><en> It is better to push the vertebral column upwards while being in a quadruped position.
<G-vec00272-001-s238><push.drücken><de> Drückt man den Knopf auf der rechten Seite des Filmadapters so wird das eingelegte Dia mechanisch wieder herausgeschoben, so dass man es bequem entnehmen kann.
<G-vec00272-001-s238><push.drücken><en> If you push the button on the right hand side of the film adaptor the inserted slide is pushed out mechanically, so that it can be easily removed.
<G-vec00272-001-s239><push.drücken><de> Der Deckel drückt das Baustein-Gehäuse mithilfe eines vorgespannten Federsystems auf die Kontakte, sodass sich das System für unterschiedliche Gehäusehöhen eignet.
<G-vec00272-001-s239><push.drücken><en> The lid is designed to push the package onto the contacts due to a spring-loaded system fitting different package thicknesses.
<G-vec00272-001-s240><push.drücken><de> Drückt die linke Seite nach oben und rechte Seite hinunter, damit Ego und Superego in Balanze kommen.
<G-vec00272-001-s240><push.drücken><en> Push the left side higher and right side lower so the ego and super-ego get the balance.
<G-vec00272-001-s241><push.drücken><de> Drückt man den Lenkerstummel nach vorn fällt das Motorrad entsprechend in Schräglage.
<G-vec00272-001-s241><push.drücken><en> If you push the steering wheel forward the motorcycle falls accordingly in an oblique position.
<G-vec00272-001-s242><push.drücken><de> Er drückt sie so, aber die Planeten widerstehen durch ihre Größe und die Trümmer im Asteroidengürtel haben nicht die Empfindlichkeit, die Kometen haben.
<G-vec00272-001-s242><push.drücken><en> It does so push, but the planets by their size resist and the debris in the Asteroid Belt does not have the sensitivity that comets do.
<G-vec00272-001-s243><push.drücken><de> Die Wildbearads.bid Website drückt ein “bestätigen Benachrichtigungen” Botschaft, fragen Sie Benachrichtigungen von dieser Website abonnieren.
<G-vec00272-001-s243><push.drücken><en> The Wildbearads.bid website will push a “Confirm notifications” message, asking you to subscribe to alerts from this website.
<G-vec00354-002-s266><express.drücken><de> Unsere regionale Verbundenheit drücken wir durch gezieltes finanzielles Engagement in Initiativen für die Menschen vor Ort aus.
<G-vec00354-002-s266><express.drücken><en> We express our regional connection by the targeted financial involvement in initiatives for local people.
<G-vec00354-002-s267><express.drücken><de> Die Keltis Weine sind das Ergebnis eines persönlichen Ansatzes im Weinberg und im Weinkeller, sie drücken ihren Terroir aus und enthalten geringere Mengen von Sulfiten.
<G-vec00354-002-s267><express.drücken><en> wines attest to the artisan’s approach in the vineyard and the cellar, they express their terroir, and contain minimum quantities of sulfites.
<G-vec00354-002-s268><express.drücken><de> Die Wiener Blätter drücken in herzlichen Worten den aufrichtigen Schmerz und das innigste Mitgefühl ganz Österreichs zu dem Unglück aus, welches das Deutsche Reich durch die Katastrophe des Marineluftschiffes "L 2" und durch den Verlust so vieler tapferer Menschenleben neuerlich betroffen habe.
<G-vec00354-002-s268><express.drücken><en> The Vienna newspapers express in heartfelt words the sincere sorrow and heartfelt condolences of all Austria to the misfortune which has affected the German Reich by the catastrophe of the Naval Airship "L2" and by the loss of so many brave lives.
<G-vec00354-002-s269><express.drücken><de> In einer von Solidarität geprägten Gesellschaft kann jemand, der etwas gut kann, einem anderen, dem diese Aufgabe schwerfällt, helfen, und so drücken sie ihre Solidarität aus.
<G-vec00354-002-s269><express.drücken><en> In a society defined by solidarity, a person who has the ability to do something can help someone who has difficulties fulfilling a task and thus they express their solidarity.
<G-vec00354-002-s270><express.drücken><de> Touristen drücken ihre Bewunderung für die einzigartige Landschaft aus, wie es bei den spanischen Sabas und Juan Carlos der Fall ist, aber sie werfen auch vor, dass der Service verbessert werden muss, da der Bahnhof stark unorganisiert ist und das Reisen unangenehm ist.
<G-vec00354-002-s270><express.drücken><en> Tourists express their admiration for the unique landscape, as is the case of the Spanish Sabas and Juan Carlos, but they also reproach that the service needs to be improved, since there is much disorganization in the station and discomfort for traveling.
<G-vec00354-002-s271><express.drücken><de> Die Zeichnungen drücken auf verschiedenste Weise aus, wie sehr sich unsere Kinder um die Gesundheit Ihrer Eltern sorgen und wie wichtig es ist, dass wir auf uns selbst und unsere Kollegen achtgeben.
<G-vec00354-002-s271><express.drücken><en> The drawings express in many different ways how much our children care about the well-being of their parents and how important it is to take care of yourselves and your colleagues.
<G-vec00354-002-s272><express.drücken><de> Alle Arbeiten dieser Ausgabe drücken auf ihre Weise eine unglaubliche Lebenslust aus, sei es im ausgelassenen Überschwang oder stillen Vergnügen.
<G-vec00354-002-s272><express.drücken><en> All works of this edition express an incredible lust of life in their own way, either in an exuberant ardour or in still enjoyment.
<G-vec00354-002-s273><express.drücken><de> Die zivilen Organisationen drücken ihren Unmut gegenüber der Nominierung eines Soldaten im Kabinett aus und erinnern daran, dass die Organisation der Vereinten Nationen sowie die Organisation der Amerikanischen Staaten Mexiko empfahlen, keine ehemaligen Militärangehörige in zivile öffentliche Ämter einzustellen.
<G-vec00354-002-s273><express.drücken><en> Civil organizations express their disagreement with the appointment of a soldier to the cabinet. They also mention that the United Nations and the Organization of American States (OAS) recommend that Mexico not involve members of the Army in public posts.
<G-vec00354-002-s274><express.drücken><de> Die Planeten im Schütze-Zeichen und Mars in Widder drücken etwas völlig anderes aus als die Planeten im Steinbock.
<G-vec00354-002-s274><express.drücken><en> The planets in the sign of Sagittarius and Mars in Aries express something completely different than the planets in Capricorn.
<G-vec00354-002-s275><express.drücken><de> Obwohl die Figuren in diesem Triptychon kaum als menschlich erkennbar sind, drücken sie dennoch einen nüchternen und rohen Ausdruck negativer Körperenergie aus.
<G-vec00354-002-s275><express.drücken><en> Though the figures in this triptych are barely recognizable as human, they nevertheless express a stark and raw expression of negative bodily energy.
<G-vec00354-002-s276><express.drücken><de> Drücken Sie durch DHL, Fedex, UPS oder TNT, Luft-Versand oder Seeversand aus.
<G-vec00354-002-s276><express.drücken><en> Express by DHL, Fedex, UPS or TNT, Air Shipment or Sea Shipment.
<G-vec00354-002-s277><express.drücken><de> Ungehorsame Aktionsformen ermöglichen dabei nicht nur einer Vielzahl von Menschen reale, kollektive Widerstandserfahrungen und öffnen öffentliche Wahrnehmungsräume für globalisierungskritische Inhalte, vor allem drücken sie auch eine klar ablehnende, antagonistische Haltung der Bewegungen gegenüber der herrschenden Politik aus.
<G-vec00354-002-s277><express.drücken><en> Disobidient forms of action not only enable a lot of people to make real collective experiences of resistance and open up public spaces of perception for issues critical of globalization, above all they express a definitelly rejecting, antagonistic mindset of the movement towards the politics in power.
<G-vec00354-002-s278><express.drücken><de> Mit der Lilie drücken Sie Ihre Trauer, Ehrung und Verbundenheit aus, sodass Sie sich sehr gut als Trauerblume eignet.
<G-vec00354-002-s278><express.drücken><en> With the lily you express your grief, honour and closeness; it is very suitable as a mourning flower.
<G-vec00354-002-s279><express.drücken><de> Durch die Qualität dieser Fahne drücken Sie im besonderen Maße Ihre Verbundenheit zu Deutschland aus.
<G-vec00354-002-s279><express.drücken><en> Due to the quality of this flag, you express your special attachment to Mato Grosso do Sul.
<G-vec00354-002-s280><express.drücken><de> Alle Nachrichten drücken die Ansichten der Autoren aus und die Eigentümer der Website:"Das Tattoo Spirit-Forum"oder die WoltLab GmbH (Entwickler der hier verwendeten Software) können nicht für den Inhalt einzelner Nachrichten verantwortlich gemacht werden.
<G-vec00354-002-s280><express.drücken><en> All messages express the views of the author, and neither the owners of JogloSemar, nor vBulletin Solutions, Inc. (developers of vBulletin) will be held responsible for the content of any message.
<G-vec00354-002-s281><express.drücken><de> Drücken Sie Ihre Anerkennung für unsere Leistungen aus.
<G-vec00354-002-s281><express.drücken><en> Express your appreciation on our services.
<G-vec00354-002-s282><express.drücken><de> Auch die Bilder, die nicht eine Gottheit darstellen, drücken eine starke persönliche Frömmigkeit aus: Mit ihren Siegeln weihten die Menschen ihrem Gott ein Objekt, das eng mit der eigenen Identität verbunden war, so Blömer.
<G-vec00354-002-s282><express.drücken><en> Even those images that do not depict a deity express strong personal piety: with their seals, people consecrated an object to their god which was closely associated with their own identity, said Blömer.
<G-vec00354-002-s283><express.drücken><de> Sie versuchen nicht mal, sich als „normal“ auszugeben und drücken sich auf eine bahnbrechende Art und Weise mit ihrer Kleidung aus.
<G-vec00354-002-s283><express.drücken><en> They shun the label of ’normal‘ and express themselves through their clothes in ways that push boundaries.
<G-vec00354-002-s284><express.drücken><de> Alle Nachrichten drücken die Ansichten der Autoren aus und die Eigentümer der Website: INVESTOX-Forum oder die WoltLab GmbH (Entwickler der hier verwendeten Software) können nicht für den Inhalt einzelner Nachrichten verantwortlich gemacht werden.
<G-vec00354-002-s284><express.drücken><en> All the posts express the opinion of the author, the owners of ContentLion Forum and WoltLab GmbH (the developers of Burning Board) cannot be held responsible for the content of those posts.
<G-vec00361-002-s171><push.drücken><de> Drücke dich von deiner rechten Ferse hoch und stehe auf.
<G-vec00361-002-s171><push.drücken><en> Use your right foot to push yourself upwards.
<G-vec00361-002-s172><push.drücken><de> Drücke den Knopf am Anfang des Korridors (einmal) um die richtige Richtung anzuzeigen (>).
<G-vec00361-002-s172><push.drücken><en> Push the button in the beginning of the corridor once to make it show the right direction (>).
<G-vec00361-002-s173><push.drücken><de> Wenn die Stange knapp über die Stirn ist, drücke sie wieder nach oben.
<G-vec00361-002-s173><push.drücken><en> Just before it touches your forehead, push it up.
<G-vec00361-002-s174><push.drücken><de> Drücke deinen Oberkörper zur Decke und vermeide es, die Schultergegend fallen zu lassen.
<G-vec00361-002-s174><push.drücken><en> Push your upper back towards the ceiling to avoid "drooping" your shoulder region.
<G-vec00361-002-s175><push.drücken><de> Drücke dich vom vorderen Fuß zurück in die Ausgangsposition und wechsle die Beine.
<G-vec00361-002-s175><push.drücken><en> Push off the front leg to return and switch sides.
<G-vec00361-002-s176><push.drücken><de> Drücke die microSD Karte mit dem Fingernagel ein bisschen tiefer in den Slot, bis du ein Klicken hörst.
<G-vec00361-002-s176><push.drücken><en> Using your fingernail, push the microSD card slightly deeper into its slot, until you hear a click.
<G-vec00361-002-s177><push.drücken><de> Werde dir deines Körpers bewusst, konzentriere dich auf deine Atmung und drücke dein Bewusstsein langsam an die äußersten Grenzen deines Körpers, sodass dein Kopf vollkommen frei von Gedanken ist.
<G-vec00361-002-s177><push.drücken><en> Become aware of your body, focus in on your breathing, and slowly push your awareness to the outer limits of your body, obliterating thought altogether.
<G-vec00361-002-s178><push.drücken><de> Drücke gleichzeitig den anderen Arm (der auf dem Boden) gegen das Knie, um die Drehung der Wirbelsäule zu erleichtern.
<G-vec00361-002-s178><push.drücken><en> At the same push the opposite arm (the one on the floor) into the knee to assist spinal rotation.
<G-vec00361-002-s179><push.drücken><de> Schritt 2 Hebe die Unterseite vorsichtig an und drücke sie Richtung Rückseite des Laptops, um die Halterungsclips zu lösen.
<G-vec00361-002-s179><push.drücken><en> Mike - 2017Slightly lift the lower case and push it toward the rear of the computer to free the mounting tabs.
<G-vec00361-002-s180><push.drücken><de> Drücke deine Beine nach außen und führe sie langsam wieder zusammen.
<G-vec00361-002-s180><push.drücken><en> Push your legs outwards and slowly take them back together again.
<G-vec00361-002-s182><push.drücken><de> Drücke die microSD Karte mit dem Fingernagel etwas tiefer in ihren Slot, bis du ein Klick hörst.
<G-vec00361-002-s182><push.drücken><en> Using your fingernail, push the microSD card slightly deeper into its slot, until you hear a click.
<G-vec00361-002-s183><push.drücken><de> Halte diese Position einige Sekunden und drücke dich anschließend zurück in die Ausgangsposition.
<G-vec00361-002-s183><push.drücken><en> Hold this pose for a couple of seconds and push yourself back up afterwards to starting position.
<G-vec00361-002-s184><push.drücken><de> Wenn die Knie und Beine anfangen, über deinen Kopf zu gehen, drücke mit deinen Armen und Schultern.
<G-vec00361-002-s184><push.drücken><en> As the knees and legs start to go over your head, push with your arms and shoulders.
<G-vec00361-002-s185><push.drücken><de> Drücke beim Wiederzusammenbau das untere Gehäuse in der Mitte leicht an, damit die beiden Plastikklammern wieder einrasten.
<G-vec00361-002-s185><push.drücken><en> During reassembly, gently push down the center of the lower case to reattach the two plastic clips. Battery Connector
<G-vec00361-002-s186><push.drücken><de> Drücke dich mit dem einen Fuß ab und gleite mit dem anderen, wie du es vorher schon getan hast, aber diesmal versuche es mit ein wenig mehr Kraft, damit du mehr Schwung bekommst und weiter über das Eis gleitest.
<G-vec00361-002-s186><push.drücken><en> Push off with one foot and glide on the other as before, but this time, do it a little harder to give yourself more momentum and glide much farther across the ice.
<G-vec00361-002-s187><push.drücken><de> Drücke die Nadel wieder hindurch.
<G-vec00361-002-s187><push.drücken><en> Push the needle through again.
<G-vec00361-002-s188><push.drücken><de> Drücke den Verschluss mit deinem Finger oder einem Schraubenzieher hinein und hebe die Batterieabdeckung aus dem Rauchmelder heraus.
<G-vec00361-002-s188><push.drücken><en> Use your finger or a screwdriver to push the latch in and lift the battery cover up from the alarm.
<G-vec00361-002-s189><push.drücken><de> So drücke und versuche deinen Urin hinauszuspritzen.
<G-vec00361-002-s189><push.drücken><en> So push and try to squirt liquid from your bladder.
<G-vec00372-002-s205><hit.drücken><de> Später tritt Rückmeldung aufgrund einer anderen Frequenz, drücken Sie einfach die Fußschalter wieder, wie die ANTI-FEEDBACK Funktion gleichzeitig bis zu drei problematische Frequenzbereiche verarbeiten kann.
<G-vec00372-002-s205><hit.drücken><en> Later, if feedback occurs due to another frequency, just hit the footswitch again, as the ANTI FEEDBACK function can handle up to three problematic frequency ranges at once.
<G-vec00372-002-s206><hit.drücken><de> Hinweis: Das Wondershare Videokonvertierungsprogramm ermöglicht es Ihnen, den Effekt in Echtzeit zu betrachten, drücken Sie dafür die Play-Schaltfläche im linken Fensterbereich des Videoelement-Menüs.
<G-vec00372-002-s206><hit.drücken><en> Note: Wondershare Video Converter also allows you to view the effect in real time, just hit Play button in the left pane of the video item bar.
<G-vec00372-002-s207><hit.drücken><de> Brain Spielen Think Think World - Hit'em Schützen Sie die Bäume, drücken Sie die Monster.
<G-vec00372-002-s207><hit.drücken><en> Brain Play Think Think World - Hit'em Protect the trees, hit the monsters.
<G-vec00372-002-s208><hit.drücken><de> Haken und drücken Sie das Pedal!.
<G-vec00372-002-s208><hit.drücken><en> Hook and hit the pedal!.
<G-vec00372-002-s209><hit.drücken><de> Wenn Sie mit Ihrer Auswahl zufrieden sind, drücken Sie die Schaltfläche „Draw“, um Ihr endgültiges Pokerblatt zu erhalten.
<G-vec00372-002-s209><hit.drücken><en> When you're satisfied with your selection, hit the 'draw' button to receive your final poker hand.
<G-vec00372-002-s210><hit.drücken><de> Um mit dem Update fortzufahren, drücken Sie Jetzt installieren.
<G-vec00372-002-s210><hit.drücken><en> To proceed with the update, hit Install Now.
<G-vec00372-002-s211><hit.drücken><de> Wählen Sie einfach das Textfeld aus oder führen Sie eine Mehrfachauswahl der Zeilen oder Spalten durch, die Sie entfernen möchten und drücken Sie die Taste Entfernen.
<G-vec00372-002-s211><hit.drücken><en> Just select the text box or multi-select the row or column you want to delete, and hit the Delete key.
<G-vec00372-002-s212><hit.drücken><de> Um die Liste auf die Ligen einzugrenzen, an denen Sie interessiert sind, drücken Sie die Filtereinstellung.
<G-vec00372-002-s212><hit.drücken><en> To narrow the list down to the leagues that you're interested in hit the Filter setting.
<G-vec00372-002-s213><hit.drücken><de> Spielen Sie haben nur einen Schlüssel zu steuern und Ihre Aufgabe ist es, drücken Sie nicht am Rand.
<G-vec00372-002-s213><hit.drücken><en> Play You have only one key to steer and your job is to do not hit the edge.
<G-vec00372-002-s214><hit.drücken><de> Schritt 5: Markieren Sie alle erkannten Partitionen des ausgewählten Laufwerks und drücken Sie die Next Taste.
<G-vec00372-002-s214><hit.drücken><en> Step 5: Mark all detected partitions of the selected drive and hit the Next button.
<G-vec00372-002-s215><hit.drücken><de> Drücken Sie einfach die Taste F1 oben rechts auf der Tastatur, um sie aufzurufen.
<G-vec00372-002-s215><hit.drücken><en> Simply hit the F1 key at top right of the keyboard to bring them up.
<G-vec00372-002-s216><hit.drücken><de> Drücken Sie auf der Tastatur die Taste Entf, oder klicken Sie mit der rechten Maustaste, und wählen Sie die Option "Löschen".
<G-vec00372-002-s216><hit.drücken><en> Hit the Delete key on your keyboard or right-click and select delete.
<G-vec00372-002-s217><hit.drücken><de> Die vollständige Kalibrierung erfordert lediglich drei einfache Schritte: Ermitteln Sie Farbabweichungen mit einem Messgerät und drücken Sie die Kalibrierungstaste, um ein einheitliches Farbprofil zur Verteilung an die Displays zu generieren.
<G-vec00372-002-s217><hit.drücken><en> Complete calibration takes just three easy steps: detect color irregularities with a measurement meter, then hit the calibration key to generate a uniform color profile for distribution to the array of displays.
<G-vec00372-002-s218><hit.drücken><de> Sobald Sie fertig sind, drücken Sie wiederherstellen und drücken Sie OK zu bestätigen.
<G-vec00372-002-s218><hit.drücken><en> Once done, hit Restore and press OK to confirm.
<G-vec00372-002-s219><hit.drücken><de> In seltenen Fällen sind die Ursache für die Überlastung der Blitz oder drücken Sie auf den anderen Leiterströme.
<G-vec00372-002-s219><hit.drücken><en> In rare cases, the cause of the overload are the lightning or hit on the other conductor currents.
<G-vec00372-002-s220><hit.drücken><de> Es war kein großes Ereignis für mich zu hüpfen in mein Auto am Freitag und drücken Sie die Streifen für ein wenig.
<G-vec00372-002-s220><hit.drücken><en> It was no huge event for me to hop in my car on Fridays and hit the Strip for a little bit.
<G-vec00372-002-s221><hit.drücken><de> Schließlich, drücken Sie die Schaltfläche "Erstellen", um es zu speichern.
<G-vec00372-002-s221><hit.drücken><en> Finally, hit the "Create" button to save it.
<G-vec00372-002-s222><hit.drücken><de> Geben Sie "cmd" ein und drücken Sie OK.
<G-vec00372-002-s222><hit.drücken><en> Input “cmd” and hit OK. b.
<G-vec00372-002-s223><hit.drücken><de> Drücken Sie die Looser Klicken Sie auf die weiße Kugel zu versuchen,...
<G-vec00372-002-s223><hit.drücken><en> Hit The Looser Click on the white ball to attempt to hit the...
<G-vec00372-002-s132><weigh.drücken><de> Gestiegene Materialkosten, vor allem für Karton und Verpackung, aber auch Transportkosten drücken das Ergebnisniveau der Packagingdivision.
<G-vec00372-002-s132><weigh.drücken><en> Higher material costs, especially for cartonboard and packaging, but also transport costs weigh on the margin of the packaging division.
<G-vec00372-002-s133><weigh.drücken><de> Bindungen drücken euch nieder, also schaut ihr laufend hinter euch, um sicher zu stellen, dass jene Dinge sicher sind.
<G-vec00372-002-s133><weigh.drücken><en> Attachments weigh you down, so you are constantly looking behind yourself to make sure those things are secure and maintained.
<G-vec00372-002-s134><weigh.drücken><de> Die Konflikte und Sanktionen um die Ukraine und Russland ebenso wie die kriegerischen Auseinandersetzungen im Gaza-Streifen und nicht zuletzt auch die erneute militärische Intervention der USA im Irak drücken auf die Stimmung der Investoren und Unternehmer.
<G-vec00372-002-s134><weigh.drücken><en> The sanctions on Russia resulting from the conflicts in the Ukraine, the attacks on the Gaza Strip, and last but not least, the renewed military intervention of the USA in Iraq, all weigh heavily on the spirits of investors and business.
