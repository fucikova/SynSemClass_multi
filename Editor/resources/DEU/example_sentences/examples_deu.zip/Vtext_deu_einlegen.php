<G-vec00407-001-s146><insert.einlegen><de> Muss also nicht mehr zurück zum Fahrzeug und Zettel einlegen, oder so.
<G-vec00407-001-s146><insert.einlegen><en> So do not have to go back to the vehicle and insert the paper or something.
<G-vec00407-001-s147><insert.einlegen><de> Im weiteren Verlauf des Spiels müssen wir nur noch zwei mal eine andere CD einlegen.
<G-vec00407-001-s147><insert.einlegen><en> In the further process of the game only two times we must insert another CD.
<G-vec00407-001-s148><insert.einlegen><de> Einfach den Teststreifen in Ihren Pool oder Spa tauchen, in das Lesegerät einlegen und in Sekundenschnelle genaue Ergebnisse erhalten.
<G-vec00407-001-s148><insert.einlegen><en> Just dip the test strip in your pool or spa, insert the reader, and get fast, accurate results in seconds.
<G-vec00407-001-s149><insert.einlegen><de> Bibliothek Bild: Klicken Sie auf dem Bild aus der Bibliothek einlegen.
<G-vec00407-001-s149><insert.einlegen><en> Library Image: Click to Insert Image from library.
<G-vec00407-001-s150><insert.einlegen><de> Sie müssen das Telefon ausschalten und das Ladegerät abziehen, bevor Sie die SIM-Karte einlegen oder entnehmen.
<G-vec00407-001-s150><insert.einlegen><en> Always turn off your phone and detach the charger before you insert or remove the SIM card.
<G-vec00407-001-s151><insert.einlegen><de> Die Website wurde mit dem neuen Management-Interface von Red Sky gebaut wurden aktualisiert: einfache Einlegen / Ändern / Löschen von Inhalten, Suchmaschinen-Optimierung, Integration mit Youtube Videos,...
<G-vec00407-001-s151><insert.einlegen><en> The site has been updated with the new management interface built by Red Sky: easy to insert / modify / delete content, search engine optimization, integration with Youtube for videos, shipping newsletter.......
<G-vec00407-001-s152><insert.einlegen><de> Das Messsystem besteht aus einer Linearachse, auf der ein Lasersensor montiert ist, sowie aus einem angetriebenen Rollen Prisma zum Einlegen des Spannstahls.
<G-vec00407-001-s152><insert.einlegen><en> The measurement system consits of a linear axis, on which a laser sensor is mounted. Additionaly there is a powered prism to insert the steel.
<G-vec00407-001-s153><insert.einlegen><de> "In der Systemeinstellung ""CDs & DVDs"" kann nessViewer bei der Aktion ""Beim Einlegen einer Video-DVD"" angegeben werden."
<G-vec00407-001-s153><insert.einlegen><en> "In the system preferences ""CDs & DVDs"" nessViewer can be set for the action ""Video DVD insert""."
<G-vec00407-001-s154><insert.einlegen><de> Wählen Sie eine Prämie Halterung einlegen, um mehr Tiefe zu Ihren Kunstdruck hinzufügen.
<G-vec00407-001-s154><insert.einlegen><en> Select a premium mount insert to add more depth to your art print.
<G-vec00407-001-s155><insert.einlegen><de> Sie müssen die Disc in das CD/DVD-Laufwerk Ihres Computers einlegen, bevor Sie den Code einlösen können.
<G-vec00407-001-s155><insert.einlegen><en> You'll need to insert the disc into your computer's CD/DVD drive before you can redeem your code.
<G-vec00407-001-s156><insert.einlegen><de> Das Programm wird automatisch mit dem Einlegen einer Netzwerkkarte aktiviert.
<G-vec00407-001-s156><insert.einlegen><en> The program will start automatically if you insert the network adaptor.
<G-vec00407-001-s157><insert.einlegen><de> Sie können den Draht auch in eine dafür vorgesehene Nut einlegen.
<G-vec00407-001-s157><insert.einlegen><en> You can also insert the rod into a designated slot.
<G-vec00407-001-s158><insert.einlegen><de> Sollte man die Dias jedoch anders ausgerichtet in den Halter einlegen, ist das auch kein Problem, da man das Bild in der Scansoftware nach dem Vorschauscan jederzeit beliebig drehen und spiegeln kann.
<G-vec00407-001-s158><insert.einlegen><en> If you insert your slides differently into the holder, it is not a problem at all, since you can rotate and reflect any picture within the scan software after the prescan.
<G-vec00407-001-s159><insert.einlegen><de> Wenn ein Titel aus dem Xbox Game Pass-Katalog entfernt wird, müssen Sie eine Disk einlegen, eine digitale Kopie im Microsoft Store erwerben oder sich eine andere Form von Berechtigung (beispielsweise eine Testversion) sichern, um weiterzuspielen.
<G-vec00407-001-s159><insert.einlegen><en> Once a title leaves the Xbox Game Pass catalog, you will need to insert a disc, purchase a digital copy from the Microsoft Store, or obtain another form of entitlement (like a trial) to continue playing.
<G-vec00407-001-s160><insert.einlegen><de> 2| Küvette aus dem Brennofen holen und in die Maschine einlegen.
<G-vec00407-001-s160><insert.einlegen><en> 2| Take the flask from oven and insert into the machine.
<G-vec00407-001-s161><insert.einlegen><de> Einfach Batterien einlegen und schon geht es mit bis zu 20 km/h ab durch's Gelände.
<G-vec00407-001-s161><insert.einlegen><en> Simply insert the batteries and off you go with up to 20 km/h through the terrain.
<G-vec00407-001-s162><insert.einlegen><de> Wenn das dvr / nvr nicht mit dem Internet verbunden ist, können Sie das Netzwerkkabel in Ihren Computer einlegen.
<G-vec00407-001-s162><insert.einlegen><en> If the dvr/nvr is failed to connect internet, you can insert the network cable into your computer.
<G-vec00407-001-s163><insert.einlegen><de> Dort werden wir dann eine Pause einlegen, danach geht es weiter in Richtung Agadir.
<G-vec00407-001-s163><insert.einlegen><en> Then there we will insert a break, then it is farther in direction of Agadir.
<G-vec00407-001-s164><insert.einlegen><de> Sie können eine Pause einlegen und nach Wechsel des Kartenausschnittes oder Maßstabes die Streckenberechnung wieder fortsetzen.
<G-vec00407-001-s164><insert.einlegen><en> They can a break insert and after change of the map cutout or yardstick the distance computation again continue.
<G-vec00407-001-s287><insert.einlegen><de> Wir nutzten die Gelegenheit um im hiesigen Warehouse eine Shoppingtour einzulegen.
<G-vec00407-001-s287><insert.einlegen><en> We took the opportunity at the local warehouse, a shopping insert.
<G-vec00407-001-s288><insert.einlegen><de> Informationen zu den Phasen der Entwicklung und spezifische Hilfe für den Eigentümer Zeit ein geladenes Wort einzulegen und Verletzungen zu verhindern.
<G-vec00407-001-s288><insert.einlegen><en> Information about the stages of development and specific help to the property owner time to insert a loaded word and prevent violations.
<G-vec00407-001-s289><insert.einlegen><de> Automatische Druckpause: Wenn das Filament während eines 3D-Druckauftrags ausgeht, stoppt der 3D-Drucker eigenständig und warnt dich, neues Filament einzulegen, um den Fertigungsprozess fortzusetzen.
<G-vec00407-001-s289><insert.einlegen><en> Automatic 3D printing pause: If the filament runs out during a manufacturing job, the 3D printer automatically stops and warns you to insert new filament to continue the manufacturing process.
<G-vec00407-001-s290><insert.einlegen><de> Wenn man ohnehin schon am Pult steht, liegt es in der Sicht des Tänzers nahe, gleich ein paar Tanzschritte einzulegen, die die ohnehin schon suspekte Sprache über Tanz und Finanz begleiten.
<G-vec00407-001-s290><insert.einlegen><en> If one is 'on stage' anyway, then it seems obvious from the dancer's viewpoint to insert a few dance steps, accompanying the already suspect language about dance and finance.
<G-vec00407-001-s291><insert.einlegen><de> Um einen Filmstreifen in den Halter einzulegen, muss man diesen zunächst öffnen, indem man die Verriegelung an der Vorderseite nach außen zieht und dann die obere Hälfte des Filmhalters nach oben klappt.
<G-vec00407-001-s291><insert.einlegen><en> In order to insert a film strip into the film strip holder you first have to open it by unlocking the lock at the front side and then swing open the upper half of the film holder.
<G-vec00407-001-s292><insert.einlegen><de> Wenn die MSSRCH.DLL-Datei nicht im DLL Cache vorhanden ist, oder der DLL Cache beschädigt ist werden Sie aufgefordert, den Windows-Installationsdatenträger einzulegen, um die ursprünglichen Dateien wiederherzustellen.
<G-vec00407-001-s292><insert.einlegen><en> If the MSSRCH.DLL file is not in the DLL Cache, or the DLL Cache is corrupted, you will be prompted to insert the Windows installation disc to recover the original files.
<G-vec00407-001-s293><insert.einlegen><de> Hier reicht es oft einen schmalen 9 cm breiten Streifen einzulegen.
<G-vec00407-001-s293><insert.einlegen><en> Here it is often sufficient to insert a narrow 9 cm wide strip.
<G-vec00407-001-s294><insert.einlegen><de> Wenn die prflbmsg.dll-Datei nicht im DLL Cache vorhanden ist, oder der DLL Cache beschädigt ist werden Sie aufgefordert, den Windows-Installationsdatenträger einzulegen, um die ursprünglichen Dateien wiederherzustellen.
<G-vec00407-001-s294><insert.einlegen><en> If the prflbmsg.dll file is not in the DLL Cache, or the DLL Cache is corrupted, you will be prompted to insert the Windows installation disc to recover the original files.
<G-vec00407-001-s295><insert.einlegen><de> ACHTUNG: Wenn sich bereits eine CD im CD-Schlitz befindet, nicht versuchen, eine weitere CD einzulegen.
<G-vec00407-001-s295><insert.einlegen><en> CAUTION: if there is already a cd in the cd slit, do not try to insert a second cd.
<G-vec00407-001-s296><insert.einlegen><de> Wenn die jsproxy.dll-Datei nicht im DLL Cache vorhanden ist, oder der DLL Cache beschädigt ist werden Sie aufgefordert, den Windows-Installationsdatenträger einzulegen, um die ursprünglichen Dateien wiederherzustellen.
<G-vec00407-001-s296><insert.einlegen><en> If the jsproxy.dll file is not in the DLL Cache, or the DLL Cache is corrupted, you will be prompted to insert the Windows installation disc to recover the original files.
<G-vec00407-001-s297><insert.einlegen><de> Wenn sich die Projektsicherung über mehrere ZIP- oder MO-Datenträger erstreckt, werden Sie nach dem Lesen der Daten vom ersten Datenträger in einer Meldung aufgefordert, den nächsten Datenträger einzulegen.
<G-vec00407-001-s297><insert.einlegen><en> When the project backup spans several ZIP or MO disks, a message prompting the user to insert the next disk appears after data from the first disk have been read.
<G-vec00407-001-s298><insert.einlegen><de> Da die meisten Rechner DVD / Blu-ray Laufwerke haben, ist es möglich, Discs mit Filmen in solches Laufwerk einzulegen, und das Programm wird technische Parameter erkennen.
<G-vec00407-001-s298><insert.einlegen><en> As most computers have DVD / Blu-ray devices, it is possible to insert discs with movies into such device and let the program detect technical details.
<G-vec00407-001-s299><insert.einlegen><de> Der Empfänger der Diskette einzulegen wurde empfohlen, das Paket zu installieren.
<G-vec00407-001-s299><insert.einlegen><en> The recipient was encouraged to insert the disk to install the package.
<G-vec00407-001-s300><insert.einlegen><de> Die Rollenetiketten sind einfach in die Spenderbox einzulegen und können händisch einzeln entnommen werden.
<G-vec00407-001-s300><insert.einlegen><en> The roll labels are easy to insert into the dispenser box and can be removed individually by hand.
<G-vec00407-001-s301><insert.einlegen><de> Im oberen Bereich kann der Kessel geöffnet werden um das mitgelieferte kupferne Aromasieb zur Dampfdestillation einzulegen.
<G-vec00407-001-s301><insert.einlegen><en> The top of the boiler can be opened to insert a sieve for aroma distillation.
<G-vec00407-001-s302><insert.einlegen><de> "Wagner bedauerte in seiner Ansprache auch, dass das im Berliner Tiergarten geplante Mahnmal für die als ""Zigeuner""ermordeten des Dritten Reiches bisher nicht realisiert sei, er schloss aber ein einseitig den Sinti & Roma gewidmetes Mahnmal kategorisch aus und bestärkte die Absicht des JENISCHEN Bundesverbandes notfalls Verfasssungsbeschwerde gegen ein solches einzulegen."
<G-vec00407-001-s302><insert.einlegen><en> "Wagner regretted in his speech also the fact that the memorial for the memorial, dedicated planned in the citizen of Berlin zoo, as “gypsies "" did not murder the third realm so far was realized, it excluded however on one side the Sinti & Roma categorically and encouraged the intention of the JENI Federal association if necessary Verfasssungsbeschwerde against such to insert."
<G-vec00407-001-s303><insert.einlegen><de> Wenn sich das Backup des Projekts über mehrere Disks er-streckt, vergewissern Sie sich, die erste Disk einzulegen, die Daten des gewünschten Projekts enthält.
<G-vec00407-001-s303><insert.einlegen><en> NOTE If the backup of the project spans multiple discs, be sure to insert the first disc that contains data of the desired project first.
<G-vec00407-001-s304><insert.einlegen><de> Es dauert nur Sekunden, um das Gehäuse in das Car Cradle einzulegen oder es heraus zu nehmen.
<G-vec00407-001-s304><insert.einlegen><en> It only takes seconds to insert or remove the case from the Car Cradle.
<G-vec00407-001-s305><insert.einlegen><de> Wenn die ext-ms-win-biometrics-winbio-l1-1-0.dll-Datei nicht im DLL Cache vorhanden ist, oder der DLL Cache beschädigt ist werden Sie aufgefordert, den Windows-Installationsdatenträger einzulegen, um die ursprünglichen Dateien wiederherzustellen.
<G-vec00407-001-s305><insert.einlegen><en> If the ext-ms-win-biometrics-winbio-l1-1-0.dll file is not in the DLL Cache, or the DLL Cache is corrupted, you will be prompted to insert the Windows installation disc to recover the original files.
<G-vec00081-001-s183><pause.einlegen><de> Die Aufgabe dieses Zentrums liegt darin, den Männern und Frauen, die in ihrem christlichen Leben eine Pause einlegen möchten, um ihr Dasein als Getaufte und ihre Berufung in der Kirche in größerer Fülle zu leben, die paulinische Spiritualität näherzubringen.
<G-vec00081-001-s183><pause.einlegen><en> The centre's vocation is to present the Pauline spirituality to the men and women who want to pause a moment in their Christian life, in order to live more fully their baptismal life and vocation in the Church.
<G-vec00081-001-s184><pause.einlegen><de> Heute Abend werden wir keine Pause einlegen und direkt in die Fragen einsteigen.
<G-vec00081-001-s184><pause.einlegen><en> Tonight we will not pause and go right into the questions.
<G-vec00081-001-s185><pause.einlegen><de> Anschließend 2-4 Wochen Pause einlegen.
<G-vec00081-001-s185><pause.einlegen><en> Pause for 2-4 weeks afterwards.
<G-vec00296-003-s361><break_down.einlegen><de> Du kannst mit Projects Abroad nach Belize reisen, wenn du gerade ein Sabbatjahr machst, eine Pause von deinem Job einlegen möchtest oder nach einer sinnvollen Aufgabe während eines Urlaubs suchst.
<G-vec00296-003-s361><break_down.einlegen><en> Whether you are on a gap year, career break, or looking for a meaningful experience during a vacation, volunteering with Projects Abroad gives you the chance to live and work alongside a diverse and friendly people.
<G-vec00296-003-s362><break_down.einlegen><de> Nach einer begrenzten Anzahl von Stufen musst du jedoch eine Pause einlegen.
<G-vec00296-003-s362><break_down.einlegen><en> There is a limit to how many stages you can play through without taking a break.
<G-vec00296-003-s363><break_down.einlegen><de> Die Tatsache, dass die Devisenmärkte an Wochenenden geschlossen sind, könnte einer der Vorteile in dieser Hinsicht sein, denn selbst die Hardcore-Workaholics müssen eine Pause einlegen.
<G-vec00296-003-s363><break_down.einlegen><en> The fact that Forex markets are closed over weekends might be one of the advantages in this respect, for even the hard-core workaholics have to take a break.
<G-vec00296-003-s364><break_down.einlegen><de> Wenn Du eine Pause einlegen möchtest, ist eine Auszeit-Funktion verfügbar, die Du nach dem Login hier online oder auch über unseren Kundenservice erreichen kannst.
<G-vec00296-003-s364><break_down.einlegen><en> Time-out period If you wish to take a break, a time-out period facility is available online here when logged in or by contacting our Customer Service team.
<G-vec00296-003-s365><break_down.einlegen><de> Wir steigen weiter ab, bis wir einen versteckten natürlichen Teich erreichen, wo wir unsere zweite Pause einlegen.
<G-vec00296-003-s365><break_down.einlegen><en> We keep on descending until we reach a hidden natural pond, where we take our second break.
<G-vec00296-003-s366><break_down.einlegen><de> Es tut uns einfach gut, nach wenigen Stunden eine (Raucher) Pause einlegen zu können.
<G-vec00296-003-s366><break_down.einlegen><en> We just enjoy having a short break after a few hours and saving on the ticket costs.
<G-vec00296-003-s367><break_down.einlegen><de> Wer eine Pause einlegen wollte, konnte bei Snacks und Getränken den Interviews mit aktuellen Azubis lauschen.
<G-vec00296-003-s367><break_down.einlegen><en> Snacks and drinks were on hand for those wishing to take a break and listen to the interviews held with the company’s current apprentices.
<G-vec00296-003-s368><break_down.einlegen><de> Die Devise heißt heiß und kalt: intensiv arbeiten und dann wieder eine Pause einlegen.
<G-vec00296-003-s368><break_down.einlegen><en> The motto is hot and cold: work hard, then take a break again.
<G-vec00296-003-s369><break_down.einlegen><de> Kurzfristig können Sie nur wenige Minuten nach dem schlechten Training eine Pause einlegen.
<G-vec00296-003-s369><break_down.einlegen><en> In the short term you can just take a break a few minutes after the poor exercise.
<G-vec00296-003-s370><break_down.einlegen><de> Laut Marktanalysen belegen dabei Fernsehen (18 %), zu Hause beim Musikhören oder Lesen entspannen (15 %), Frühstücken (15 %) oder eine Pause einlegen (14 %) die oberen Stellen im Index.
<G-vec00296-003-s370><break_down.einlegen><en> Watching TV (18%), relaxing at home, listening to music or reading (15%), having breakfast (15%) and taking a break (14%) are the occasions which index higher in the research.
<G-vec00296-003-s371><break_down.einlegen><de> Sie können eine Pause einlegen, indem Sie eine Auszeit von 24 Stunden für Ihr Kundenkonto anfordern.
<G-vec00296-003-s371><break_down.einlegen><en> You can take a break by requesting a 24 hr Time-Out period be applied to your Customer account.
<G-vec00296-003-s372><break_down.einlegen><de> Wir passieren nochmal den Stella Point und erreichen das Barafu Camp, wo wir eine kurze wohlverdiente Pause einlegen.
<G-vec00296-003-s372><break_down.einlegen><en> We pass Stella Point again and reach Barafu Camp, where we have a short well deserved break.
<G-vec00296-003-s373><break_down.einlegen><de> Sicher, das wird vergehen, aber wir müssen unsere Gewohnheiten überdenken und diese Pause einlegen, um unsere Einstellung gegenüber dem Ort zu ändern, den wir zu Hause anrufen.
<G-vec00296-003-s373><break_down.einlegen><en> Sure, this will pass but we have to re-think our habits and take this break to change our attitudes towards the place we call Home.
<G-vec00296-003-s374><break_down.einlegen><de> Ganz gleich, ob du gerade die Schule abgeschlossen hast, dich mitten im Studium befindest, oder im Berufsalltag eine Pause einlegen möchtest, unsere Working Holiday Programme in Südamerika oder Mittelamerika sind für Teilnehmer aller Altersstufen und beruflicher Backgrounds geeignet.
<G-vec00296-003-s374><break_down.einlegen><en> Whether you have just finished school, are in the middle of your university studies, or just want a break from your work routine, our Working Holiday programs are ideal for people of all ages and professional backgrounds.
<G-vec00296-003-s375><break_down.einlegen><de> Wenn Sie die "Pause einlegen" -Funktion von Mr Green nutzen, schließen Sie Ihr Konto vorübergehend für einen ausgewählten Zeitraum Ihrer Wahl.
<G-vec00296-003-s375><break_down.einlegen><en> Using our ‘Take a break’ feature on site will ensure the temporary closure of your Mr Green account for a selected time period of your choosing.
<G-vec00296-003-s376><break_down.einlegen><de> Außerdem gibt es normalerweise einen „Autogrill“, an dem Sie eine Pause einlegen können.
<G-vec00296-003-s376><break_down.einlegen><en> Here you can take a break and toilets are free for use.
<G-vec00296-003-s377><break_down.einlegen><de> Wir stellen Ihnen Gartenmöbel zur Verfügung, damit Sie eine entspannende Pause einlegen können.
<G-vec00296-003-s377><break_down.einlegen><en> We provide garden furniture so that you can take a relaxing break.
<G-vec00296-003-s378><break_down.einlegen><de> Willst Du nur eine Pause in Sachen Facebook einlegen, Dich aber noch nicht komplett verabschieden (oder Du willst den Messenger weiterhin nutzen), dann ist ein Deaktivieren Deines Kontos eine gute Lösung.
<G-vec00296-003-s378><break_down.einlegen><en> If you’d like to take a break for Facebook, but aren’t quite ready to say a final farewell just yet (or you still want access to Messenger), deactivating your account is a decent alternative to permanent deletion.
<G-vec00296-003-s379><break_down.einlegen><de> Trotzdem sollten Sie auch mal eine Pause einlegen und das herrliche Wetter genießen.
<G-vec00296-003-s379><break_down.einlegen><en> Nevertheless, you should also take a break and enjoy the wonderful weather.
