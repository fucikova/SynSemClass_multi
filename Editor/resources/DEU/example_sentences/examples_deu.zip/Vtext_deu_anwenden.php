<G-vec00272-001-s019><apply.anwenden><de> Sie erklären sich damit einverstanden, dass die belgischen Gesetze ohne Rücksicht auf Konflikte mit darin enthaltenen Gesetzesprinzipien auf sämtliche Belange der Nutzung dieser 'Website' angewendet werden.
<G-vec00272-001-s019><apply.anwenden><en> You agree that the laws of Switzerland without regard to conflicts of law principles thereof, shall apply to all matters relating to the use of the Website and these Terms of Use.
<G-vec00272-001-s020><apply.anwenden><de> Das selbe Prinzip, hier auf der meditativen Ebene angewendet, paßt in Buddhas Bemerkungen, zu Rahulas Handlungen, im Generellen.
<G-vec00272-001-s020><apply.anwenden><en> And the same principles apply here, on the meditative level, as apply in the Buddha's comments to Rahula on action in general.
<G-vec00272-001-s021><apply.anwenden><de> Für Sensoren mit geringerer Präzision werden vereinfachte Methoden angewendet.
<G-vec00272-001-s021><apply.anwenden><en> We also apply simplified technique for sensor with lower precision.
<G-vec00272-001-s022><apply.anwenden><de> Jedes Vielfliegerprogramm hat seine eigenen Regeln, Vorschriften und Geschäftsbedingungen des Programms, welche alle auf Ihren Gebrauch von Meilen angewendet werden, unabhängig davon, ob Sie Meilen sammeln, oder Punkte sammeln und diese später in Meilen umwandeln.
<G-vec00272-001-s022><apply.anwenden><en> Whether you elect to earn Miles as your earning preference or decide instead to earn Points and later convert them into Miles, each Airline Program maintains its own rules, regulations, and program terms and conditions, all of which will apply to your use of any Miles.
<G-vec00272-001-s023><apply.anwenden><de> Mit dem Onlinetool (USM: Urban Sprawl Metrics tool) kann die Methode der gewichteten Zersiedelung intuitiv angewendet werden.
<G-vec00272-001-s023><apply.anwenden><en> The Urban Sprawl Metrics (USM) Toolset allows to intuitively apply intuitvely possible to apply the method of Weighted Urban Proliferation.
<G-vec00272-001-s024><apply.anwenden><de> Unsere erfahrenen Schulungsleiter stützen sich auf jahrelange Fachkompetenz im Bereich Services, um Ihren Mitarbeitern beizubringen, wie die Geräte korrekt bedient und korrigierende sowie vorbeugende Wartungsmaßnahmen auf Ihre Messgeräte angewendet werden.
<G-vec00272-001-s024><apply.anwenden><en> Our experienced instructors apply years of service expertise to help your staff learn how to operate instruments properly and apply corrective and preventive maintenance of your measurement devices.
<G-vec00272-001-s025><apply.anwenden><de> Hinweis: Haben Sie im selben Array Attribut mehrere Kriterien definiert, wird das passende Kriterium nicht zwingend auf dasselbe Array Element angewendet.
<G-vec00272-001-s025><apply.anwenden><en> Note: If you defined several criteria on the same array attribute, the matched criteria will not necessarily apply to the same array element.
<G-vec00272-001-s026><apply.anwenden><de> Da jedes dieser Ereignisse auf das gesamte Projekt angewendet wird, könnte jedes Ereignis vom Audio auf einem beliebigen Kanal ausgelöst werden.
<G-vec00272-001-s026><apply.anwenden><en> Since each of these events apply across the entire project, each event could be triggered by the audio on any channel.
<G-vec00272-001-s027><apply.anwenden><de> In diesem Fall ist es zweckmäßig, dass nicht zum vollen Maskenaustrocknen kommt und nach dem Entfernen die Creme angewendet wird.
<G-vec00272-001-s027><apply.anwenden><en> In these cases it is recommended to apply a cream layer, preventing the mask from drying, or using it after removing the mask.
<G-vec00272-001-s028><apply.anwenden><de> Wenn eine Auslegung dieser Regeln nach den Gesetzen, Regeln oder Vorschriften eines bestimmten Landes ungültig ist, wird sie nur im zulässigen Umfang angewendet.
<G-vec00272-001-s028><apply.anwenden><en> If any provision of these rules is invalid under the law, rules or regulations of a particular country, it will only apply to the extent permitted.
<G-vec00272-001-s029><apply.anwenden><de> Die Artikel 163-171 werden auf die parlamentarischen Untersuchungskommissionen angewendet, die nach Inkrafttreten des Gesetzes eingesetzt werden.
<G-vec00272-001-s029><apply.anwenden><en> Articles 163-171 apply to parliamentary investigation committees that are appointed after the date on which this Act comes into force.
<G-vec00272-001-s030><apply.anwenden><de> Multiplikatoren von x1, x2, x3, x5 oder bis x7 werden auf jeden Gewinn angewendet und treten nach jedem Symbolabwurf auf.
<G-vec00272-001-s030><apply.anwenden><en> Multipliers of x1, x2, x3, x5 or up to x7 apply to every win occurring after every symbol dropping action.
<G-vec00272-001-s031><apply.anwenden><de> "Im ""Gesetzgebungszweck"" des Zuwanderungsgesetzes wird die Bestrafung von ""Hilfe"" oder ""Beförderung"" gegen illegale Arbeit,Artikel 73-2 des Immigration Control Act ""Sin zur Förderung illegaler Arbeit"" muss angewendet werden."
<G-vec00272-001-s031><apply.anwenden><en> "Under the Immigration Act's ""Purpose of Legislation"", punishment of ""assistance"" or ""promotion"" against illegal work must apply Article 73-2 of the Immigration Act ""Crime that promotes illegal labor""."
<G-vec00272-001-s032><apply.anwenden><de> (4) Bestehen zwischen dem Schuldner und dem Nutzungsberechtigten oder zwischen jedem von ihnen und einem Dritten besondere Beziehungen und übersteigen deshalb die Lizenzgebühren, gemessen an der zugrundeliegenden Leistung, den Betrag, den Schuldner und Nutzungsberechtigter ohne diese Beziehungen vereinbart hätten, so wird dieser Artikel nur auf den letzteren Betrag angewendet.
<G-vec00272-001-s032><apply.anwenden><en> 4. Where, by reason or a special relationship between the payor and the beneficial owner or between both of them and some other person, the amount of the royalties, having regard to the use, right, or information for which they are paid, exceeds the amount that would have been agreed upon by the payor and the beneficial owner in the absence of such relationship, the provisions or this Article shall apply only to the last-mentioned amount.
<G-vec00272-001-s033><apply.anwenden><de> Öffnet das Dialogfeld Anwendungsstandardwerte, in dem Sie Standardwerte konfigurieren können, die auf alle Anwendungen angewendet werden.
<G-vec00272-001-s033><apply.anwenden><en> Opens the Application Defaults dialog box in which you can configure default settings that apply to all applications.
<G-vec00272-001-s034><apply.anwenden><de> Schwarzkopf Dandruff Control Fluid, nach dem Waschen angewendet auf die Kopfhaut.
<G-vec00272-001-s034><apply.anwenden><en> Schwarzkopf Dandruff Control Fluid, after washing, apply to the scalp.
<G-vec00272-001-s035><apply.anwenden><de> 3 Soweit Daten von Mitgliedern der Bundesversammlung oder des Personals der Parlamentsdienste betroffen sind, werden diese Ausführungsbestimmungen angewendet, sofern nicht eine Verordnung der Bundesversammlung etwas anderes bestimmt.
<G-vec00272-001-s035><apply.anwenden><en> 3 Â Unless otherwise determined by an Ordinance issued by the Federal Assembly, these implementing provisions where appropriate apply to data relating to members of the Federal Assembly and the staff of the Parliamentary Services.
<G-vec00272-001-s036><apply.anwenden><de> Diese Prinzipien sollten auf alle Projekte angewendet werden, die den Ländern helfen, sich an die Folgen des Klimawandels anzupassen oder diese abzumildern.
<G-vec00272-001-s036><apply.anwenden><en> These principles should apply to all projects intended to help countries adapt to or mitigate the impact of climate change.
<G-vec00272-001-s037><apply.anwenden><de> Precision 7530 Mobile Workstation anzeigen Weitere Informationen über diese Produktreihe Andere PC-Lösungen können angewendet werden.
<G-vec00272-001-s037><apply.anwenden><en> View the Precision 7530 Mobile Workstation Learn more about this family Other PC solutions can apply.
<G-vec00272-001-s057><apply.anwenden><de> Sie können diese künstlichen Rasen zu Ihrem Hinterhof, Golfplatz, Tennisplatz und sogar ein großer Fußballplatz und gibt es richtige Methoden anwenden.
<G-vec00272-001-s057><apply.anwenden><en> You may apply this artificial lawn to your backyard, golf area, tennis court and even a huge football field and there are proper methods to apply.
<G-vec00272-001-s058><apply.anwenden><de> Lösung Mit JMP können die Produktionsteams von Cree Probleme innerhalb des Prozesses visualisieren und kommunizieren, Daten zu diesen Problemen sammeln, Modelle anwenden, die Auswirkungen von Interaktionen untersuchen und Verbesserungen nachweisen.
<G-vec00272-001-s058><apply.anwenden><en> JMP allows Cree's production teams to visualize and communicate issues in the process, collect data on those issues, apply models, study the effects of interactions and demonstrate improvement.
<G-vec00272-001-s059><apply.anwenden><de> Es funktioniert auf jeden Zeitraum von M15 bis D1… Vertrauen Sie mir Händler, wenn Sie dieses einzigartige Tool Ihre Handelsplattform anwenden, Sie werden nie wieder etwas anderes verwenden.
<G-vec00272-001-s059><apply.anwenden><en> It works on ANY timeframe from M15 to D1… Trust me traders, once you apply this unique tool to your trading platform, you will never use anything else ever again.
<G-vec00272-001-s060><apply.anwenden><de> Wenn Sie Kutools für Outlook installiert haben, können Sie dessen anwenden Sichere Anhangserweiterungen Option, um bestimmte Typen gesperrter Anhänge schnell zu entsperren und sie dann einfach zu löschen.
<G-vec00272-001-s060><apply.anwenden><en> If you have Kutools for Outlook installed, you can apply its Safe Attachment Extensions option to unblock specified types of blocked attachments quickly, and then delete them easily.
<G-vec00272-001-s061><apply.anwenden><de> Text: Wenn Sie überprüfen Zeig es mir beim nächsten Mal nicht schwimmen Arbeitsblätter synchronisieren Wenn Sie dieses Feature das nächste Mal anwenden, wird dieses Feld nicht angezeigt.
<G-vec00272-001-s061><apply.anwenden><en> Note: If you check Don’t show me next time in the Synchronize Worksheets prompt box, this box will not appear when you apply this feature next time.
<G-vec00272-001-s062><apply.anwenden><de> Landwirte mit landwirtschaftlichem Zustand erhalten und für alle Arten von Staat anwenden können.
<G-vec00272-001-s062><apply.anwenden><en> Farmers, who have the status of agricultural producers, can receive and apply for all types of state support.
<G-vec00272-001-s063><apply.anwenden><de> Wenn Sie Kutools für Outlook installiert haben, können Sie dessen anwenden Erweiterter Druck Funktion zum schnellen Drucken einer gesendeten E-Mail mit allen Bcc-Empfängern.
<G-vec00272-001-s063><apply.anwenden><en> If you have Kutools for Outlook installed, you can apply its Advanced Print feature to quickly print a sent email with all Bcc recipients at ease.
<G-vec00272-001-s064><apply.anwenden><de> Dieses Online-Programm wird die intellektuellen, praktischen und kritischen Denkfähigkeiten der Schüler entwickeln, damit sie fachbezogenes Wissen anwenden und Probleme lösen können, die von einem Buchhalter in einer internationalen Praxis erwartet werden.
<G-vec00272-001-s064><apply.anwenden><en> This online programme will develop students' intellectual, practical and critical-thinking skills to enable them to apply subject-related knowledge and solve problems, which would be expected of an entry-level accountant in an international practice.
<G-vec00272-001-s065><apply.anwenden><de> Am Ende des Workshops konnten die Teilnehmer die Wirkungen der Storz Stoßwellentherapie am eigenen Leib erfahren, diese auch selbst anwenden und natürlich begleitend in den Genuss eines K-Active Tapes kommen.
<G-vec00272-001-s065><apply.anwenden><en> At the end of the workshop participants were able to learn the effects of shock wave therapy Storz in his own body, and of course this also apply self-service benefit of a K-Active Tape.
<G-vec00272-001-s066><apply.anwenden><de> Sobald wir die Funktionen im Rahmen des jeweiligen Elementtyps definiert haben, können wir sie im Anschluß unmittelbar anwenden.
<G-vec00272-001-s066><apply.anwenden><en> Once we have defined the Roles in the Tag Type, we are ready to apply them.
<G-vec00272-001-s067><apply.anwenden><de> Die gleichen Regeln wie davon BK Powertool Dragracing anwenden.
<G-vec00272-001-s067><apply.anwenden><en> The same rules as of it BK Powertool Dragracing apply.
<G-vec00272-001-s068><apply.anwenden><de> Wenn du als erster an der Reihe bist musst du nur die Stacks der anderen Spieler in Betracht ziehen um zu entscheiden, ob du das Konzept anwenden kannst.
<G-vec00272-001-s068><apply.anwenden><en> If you are first to act, you only need to look at the stack sizes of the players remaining to determine if you can apply the concept.
<G-vec00272-001-s069><apply.anwenden><de> Falls das Objekt nicht mit dem Hotspot funktioniert, kann man das ausgewählte Objekt auf einen anderen Hotspot anwenden oder es mit Rechtsklick wieder ins Inventar legen.
<G-vec00272-001-s069><apply.anwenden><en> If the object does not function with the hotspot, one can apply the selected object to another hotspot or put it back again with right-click.
<G-vec00272-001-s070><apply.anwenden><de> Diese Formulierung ist hervorragend, da Sie etwas oder um den Anus nicht anwenden müssen.
<G-vec00272-001-s070><apply.anwenden><en> This formulation is superb since you do not have to apply anything to or around the anus.
<G-vec00272-001-s071><apply.anwenden><de> Wenn die Schrift sagt, wir sollten «alles prüfen», sollten wir dies besonders auf die Dinge anwenden, die den bösen Mächten in ihrer Propaganda und ihrem Misstrauen helfen könnten, Trennungen zu verursachen.
<G-vec00272-001-s071><apply.anwenden><en> When the Scripture says that we are to 'prove all things', we should apply that especially to the things which could serve the evil powers in their propaganda of suspicions, leading to divisions.
<G-vec00272-001-s072><apply.anwenden><de> Seit dem Beginn der Fortgeschrittenen Wissenschaftlichen Kurse hatte L. Ron Hubbard Prozesse entwickelt, die gelehrt werden konnten und die Auditoren anwenden konnten.
<G-vec00272-001-s072><apply.anwenden><en> Since the start of the Advanced Clinical Courses, L.RonHubbard had been developing processes that could be taught, that auditors could apply.
<G-vec00272-001-s073><apply.anwenden><de> Wir können Ihre IP-Adresse in Zusammenarbeit mit Ihrem Internetanbieter für Ihre Identifizierung nutzen, für den Fall, dass wir die Nutzungsbedingungen zum Schutz unserer Dienste, Kunden oder für die Einhaltung der geltenden Gesetze anwenden müssen.
<G-vec00272-001-s073><apply.anwenden><en> We may use your IP address in cooperation with your Internet access provider in order to identify you in the case of having to apply conditions of use to protect our services and clients, or in order to comply with laws in force.
<G-vec00272-001-s074><apply.anwenden><de> Und wenn es fertig ausgearbeitet ist, wird es eine Dienstleistung werden, die Ihr nehmen könnt, ein sichtbares Produkt und eine Technologie, die wir anwenden können.
<G-vec00272-001-s074><apply.anwenden><en> And if worked out well, it will become a service that you can take, a product that is visible and a technology that we can apply.
<G-vec00272-001-s075><apply.anwenden><de> Auf diese Weise können Sie durch die Ebenen bearbeiten, unterschiedliche Farbpaletten anwenden, RGB und Graustufen-Werte ändern, neben anderen Aufgaben.
<G-vec00272-001-s075><apply.anwenden><en> This lets you do editing by layer, apply different color palettes, modify RGB and grayscale values, among other tasks.
<G-vec00272-001-s114><apply.anwenden><de> Daher wird lackierten Bodenplatte empfohlen, regelmäßig eine Schutzbeschichtung anzuwenden.
<G-vec00272-001-s114><apply.anwenden><en> Therefore, varnished floorboard is recommended to periodically apply a protective coating.
<G-vec00272-001-s115><apply.anwenden><de> Die NKS weist das Unternehmen auf seine Verantwortung für die Zulieferkette hin und forderte es auf, eine sorgfältige Prüfung („due diligence“) durchzuführen und die OECD-Leitsätze auch im Verhältnis zu ihren Handelspartnern anzuwenden.
<G-vec00272-001-s115><apply.anwenden><en> The NCP also reminded the company of its responsibility for its supply chain and invited Devcot to carry out due diligence and to apply the recommendations of the OECD towards its trade partners.
<G-vec00272-001-s116><apply.anwenden><de> Aufgrund eines kürzlich vom Bundesministerium der Finanzen im Bundessteuerblatt II 2011, Seite 367, veröffentlichten Urteils des Bundesfinanzhofes (BFH) besteht das Risiko, dass die o. g. steuerliche Handhabung für die Deutsche EuroShop AG zukünftig nicht mehr anzuwenden ist.
<G-vec00272-001-s116><apply.anwenden><en> As a result of a ruling by the German Federal Fiscal Court (BFH) published recently by the German Federal Ministry of Finance on page 367 of Part II of the Federal Tax Gazette 2011, there is a risk that Deutsche EuroShop AG may no longer be able to apply the above-mentioned tax treatment in future.
<G-vec00272-001-s117><apply.anwenden><de> In der englischen Liga Regel anzuwenden Erbe und Förderung .
<G-vec00272-001-s117><apply.anwenden><en> In the English league rule apply inheritance and promotion.
<G-vec00272-001-s118><apply.anwenden><de> bestehende Assistive Technologies Frameworks, Sensoren und Aktoren anzuwenden und in weiterer Folge selbst Software-Komponenten zur einfachen Integration von spezifischen Hardware-Bedienelementen praktisch umzusetzen.
<G-vec00272-001-s118><apply.anwenden><en> To apply existing assistive technologies frameworks, sensors, and actuators, and furthermore to independently realize software components for the practical, simple integration of specific hardware control elements
<G-vec00272-001-s119><apply.anwenden><de> Der Bachelorstudiengang zielt darauf, einen Überblick über die grundlegenden Zusammenhänge des Sektors der Erneuerbaren Energien zu bieten, die erworbenen Kenntnisse im Berufsfeld anzuwenden und in der Lage zu sein, sich selbstständig in neue Aufgabenstellungen einarbeiten zu können.
<G-vec00272-001-s119><apply.anwenden><en> The Bachelor's programme aims to provide an overview of the fundamental interrelationships in the renewable energy sector, to apply the acquired knowledge in the professional field and to be able to independently familiarise oneself with new tasks.
<G-vec00272-001-s120><apply.anwenden><de> Das Produkt ist anaerob, thixotrop und sehr einfach anzuwenden.
<G-vec00272-001-s120><apply.anwenden><en> The compound is anaerobic, sensor safe and very easy to apply.
<G-vec00272-001-s121><apply.anwenden><de> • Olan Micalessin denunziert im Il Giornale den Willen von Hillary Clinton, ihren libyschen Plan auf Syrien anzuwenden.
<G-vec00272-001-s121><apply.anwenden><en> • In the columns of Il Giornale (Italy), Olan Micalessin denounces Hillary Clinton for wanting to apply the Libyan plan to Syria.
<G-vec00272-001-s122><apply.anwenden><de> Die Fähigkeit, grundlegende Techniken und Werkzeuge in den Computerdisziplinen anzuwenden.
<G-vec00272-001-s122><apply.anwenden><en> The ability to apply fundamental techniques and tools in the computing disciplines.
<G-vec00272-001-s123><apply.anwenden><de> Darüber hinaus unterstützen wir unser Auftraggeber, Methoden der Virtual Human Simulation auch selbstständig anzuwenden.
<G-vec00272-001-s123><apply.anwenden><en> What's more, we provide support to our customers who want to apply virtual human simulation methods themselves.
<G-vec00272-001-s124><apply.anwenden><de> HEIMESS hilft den allerkleinsten Kindern durch einfache Formen und Farben, die Welt zu entdecken und die neuerworbenen Fähigkeiten anzuwenden.
<G-vec00272-001-s124><apply.anwenden><en> HEIMESS helps the very youngest children to discover the world through simple shapes and colours and to apply their newly acquired skills.
<G-vec00272-001-s125><apply.anwenden><de> Da alle diese Einstellungen separat in Word gefunden werden, ist es für uns nicht einfach, sie zu speichern und sie bei Bedarf anzuwenden.
<G-vec00272-001-s125><apply.anwenden><en> Since all these settings are locating in separately in Word, it's not easy for us to remember and apply them when we need to.
<G-vec00272-001-s126><apply.anwenden><de> Weiterhin gegen Herrn Nada, einen Mann mit ausgezeichneten Empfehlungen, gegen den kein belastendes Material vorliegt, Sanktionen anzuwenden, bedeutet ganz einfach sich dem Diktat der Vereinigten Staaten zu beugen und die Herrschaft der Willkür und der Rechtlosigkeit zu akzeptieren.
<G-vec00272-001-s126><apply.anwenden><en> In Mr. Nada's case, a man with perfect references, against whom no charge was found, to continue to apply the sanctions against him is simply to obey the diktat of the United States and to accept the reign of arbitrariness and lawlessness.
<G-vec00272-001-s127><apply.anwenden><de> Es wurde versucht, eine Matrix-Operation auf zwei Matrizen unterschiedlichen Datentyps anzuwenden.
<G-vec00272-001-s127><apply.anwenden><en> An attempt was made to apply a matrix operation to two matrices of different data types.
<G-vec00272-001-s128><apply.anwenden><de> Wenn Sie Position heraus nach einer langweiligen Tag, matte Pulver schnell auf öligen Bereichen anzuwenden.
<G-vec00272-001-s128><apply.anwenden><en> If you are heading out after a tedious day, speedily apply matte powder to oily areas.
<G-vec00272-001-s129><apply.anwenden><de> Dieser Grundsatz gilt aber per definitionem nicht für Dritte, so daß daraus nicht abgeleitet werden kann, daß das EPA verpflichtet ist, das TRIPS-Übereinkommen anzuwenden, so wünschenswert dies im Interesse der internationalen Harmonisierung des materiellen Patentrechts wäre.
<G-vec00272-001-s129><apply.anwenden><en> This principle, however, by definition does not apply to third parties so that it cannot be deduced from it that the EPO is under an obligation to apply the TRIPS Agreement, even if this might be desirable in the interest of international harmonisation of substantive patent law.
<G-vec00272-001-s130><apply.anwenden><de> Wir haben unsere AI Style Engine für PowerDirector trainiert, um Ihr Filmmaterial Bild für Bild zu analysieren und Pinselstriche intelligent anzuwenden, damit Ihr Video wie bewegte chinesische Gemälde aussieht.
<G-vec00272-001-s130><apply.anwenden><en> We've trained our AI Style Engine for PowerDirector to analyze your footage frame by frame and intelligently apply brushstrokes so your video looks like moving Chinese traditional paintings.
<G-vec00272-001-s131><apply.anwenden><de> Antwort von einem solchen Zweck dass die menschliche Erfahrung des Priesters muss nicht ihren eigenen Horizont der säkularen anzuwenden - Wirtschaft, Finanzen, Miliz, Politik, Familie, Technologie, Industrie und Handel -, weil es konzentriert sich auf menschliche Werte, die an der Wurzel und den Zweck der Existenz, mehr relevant für den Sinn des Lebens und der Geschichte, auf das Problem des Leidens, von Sünde und Erlösung, das Bedürfnis nach Wahrheit, der Gerechtigkeit, Frieden, von Freiheit und Glück, die moralischen Werte, Religiöse und spirituelle, die Beziehung zu Gott.
<G-vec00272-001-s131><apply.anwenden><en> Answer from such purpose that human experience of the priest does not need to apply their own horizon of the secular - economy, finance, militia, politics, family, technology, industry and commerce -, because it focuses on human values â â that are at the root and the purpose of existence, more relevant to the meaning of life and history, to the problem of suffering, of sin and salvation, the need for truth, of Justice, of peace, of freedom and happiness, the moral values, Religious and Spiritual, the relationship with God.
<G-vec00272-001-s132><apply.anwenden><de> „Die TAKT Akademie hat uns, den jungen Diplomanden, ermöglicht, unsere erlangten theoretischen Kenntnisse jetzt auch in der Praxis anzuwenden.
<G-vec00272-001-s132><apply.anwenden><en> “TAKT Academy enabled us, the young undergraduates, to practically apply our acquired theoretical knowledge.
<G-vec00035-001-s024><repurchase.anwenden><de> Dieser 1. unternommene Schritt erlaubt dir innen das zweite mal, eine Akte für das Erhalten einer Finanzierung festzusetzen, um dir zu ermöglichen, dein Recht zum RÜCKKAUF anzuwenden (das verkaufte gute zurückkaufen).
<G-vec00035-001-s024><repurchase.anwenden><en> This 1st taken step allows you in the second time to constitute a file for obtaining a financing in order to enable you to exert your right to the REPURCHASE (To repurchase the sold good).
<G-vec00272-002-s057><apply.anwenden><de> Die Rollenposition wird durch Einstellung des Abstandhalters und des Motors eingestellt, um einen Satz der Rolle zu realisieren, der auf unterschiedliche Rohrgrößen angewendet werden kann.
<G-vec00272-002-s057><apply.anwenden><en> The roller position will be adjusted by spacer and motor adjustment to realize one set of the roller to apply for different size of pipe.
<G-vec00272-002-s058><apply.anwenden><de> C13420B – HINWEIS: Diese Einstellung wird nur auf den Browser und das Gerät angewendet, das Sie derzeit benutzen.
<G-vec00272-002-s058><apply.anwenden><en> Fires NOTE: These settings will only apply to the browser and device you are currently using.
<G-vec00272-002-s059><apply.anwenden><de> Die Befreiungsvorschrift sieht vor, dass auf Unternehmenszusammenschlüsse, die vor dem Übergangszeitpunkt nach anderen Rechnungslegungsvorschriften abgebildet wurden, IFRS 3 „Unternehmenszusammenschlüsse“ nicht angewendet werden muss.
<G-vec00272-002-s059><apply.anwenden><en> The exemption option specifies that a first-time adopter may elect not to apply IFRS 3 “Business Combinations” to business combinations that occurred before the date of transition to IFRSs.
<G-vec00272-002-s060><apply.anwenden><de> Im Rahmen der Entwicklungsarbeiten wird dabei das Konzept des „Design for all“ angewendet.
<G-vec00272-002-s060><apply.anwenden><en> The project partners apply the "Design for all" concept as part of the development efforts.
<G-vec00272-002-s061><apply.anwenden><de> Jeder Preis und die Verfügbarkeits-Informationen bei AMAZON, die zum Zeitpunkt des Kaufs angezeigt werden, werden auf das Produkt angewendet.
<G-vec00272-002-s061><apply.anwenden><en> Any price and availability information displayed on Amazon at the time of purchase will apply to the purchase of this
<G-vec00272-002-s062><apply.anwenden><de> Beispielsweise können Sie angeben, welches Metadatenprofil und welches Videokodierungsprofil auf Video-Assets angewendet wird, die Sie hochladen.
<G-vec00272-002-s062><apply.anwenden><en> For example, you can specify what metadata profile and video encoding profile to apply to video assets that you upload.
<G-vec00272-002-s063><apply.anwenden><de> Die Regel (Standardwert oder Node-Funktion) wird nur auf Datenelemente dieses Datentyps (oder eines davon abgeleiteten Datentyps) angewendet.
<G-vec00272-002-s063><apply.anwenden><en> The rule (default or node function) will apply only to items that have this data type (or a derived data type).
<G-vec00272-002-s064><apply.anwenden><de> Dabei werden automatisch bestimmte Teile eines beweglichen Objekts verfolgt und ein Effekt wird angewendet.
<G-vec00272-002-s064><apply.anwenden><en> It automatically tracks specific parts of a subject in motion and apply an effect.
<G-vec00272-002-s065><apply.anwenden><de> Availability: Vorrätig HINWEIS: Diese Einstellung wird nur auf den Browser und das Gerät angewendet, das Sie derzeit benutzen.
<G-vec00272-002-s065><apply.anwenden><en> Flag fabric fuses Ta NOTE: These settings will only apply to the browser and device you are currently using.
<G-vec00272-002-s066><apply.anwenden><de> Eine Lösung aus Rizinusöl kann nur in der Zeit der aktiven Blüte oder des Wachstums angewendet werden.
<G-vec00272-002-s066><apply.anwenden><en> Apply a solution of castor oil can only be in the period of active flowering or growth.
<G-vec00272-002-s067><apply.anwenden><de> PXB2218 – HINWEIS: Diese Einstellung wird nur auf den Browser und das Gerät angewendet, das Sie derzeit benutzen.
<G-vec00272-002-s067><apply.anwenden><en> € NOTE: These settings will only apply to the browser and device you are currently using.
<G-vec00272-002-s068><apply.anwenden><de> Wenn eine Musterseite auf eine Layoutseite angewendet wird, wirken sich die Objekte der Musterseite nur auf die Ebene Standard der Layoutseite aus.
<G-vec00272-002-s068><apply.anwenden><en> If you apply a master page to a layout page, the items on the master page will affect only the Default layer of that layout page.
<G-vec00272-002-s069><apply.anwenden><de> In Berlin wird entwickelt, gegründet, getestet und angewendet.
<G-vec00272-002-s069><apply.anwenden><en> In Berlin, we develop, found, test and apply.
<G-vec00272-002-s070><apply.anwenden><de> Hinweis: Der Stecker ist verpolungsgeschützt, es darf beim Einstecken keine Gewalt angewendet werden.
<G-vec00272-002-s070><apply.anwenden><en> Note: The connector is reverse polarity protected; please do not apply force when plugging it in.
<G-vec00272-002-s071><apply.anwenden><de> Im Modus „Automatisierte Updates “ werden alle kumulativen Updates angewendet, die für einen Host verfügbar sind.
<G-vec00272-002-s071><apply.anwenden><en> Automated Updates mode does apply any Cumulative Updates that are available for a host.
<G-vec00272-002-s072><apply.anwenden><de> Das Problem, bei dem die Richtlinien-Einstellung „Geplante Aufgaben im Akkubetrieb nicht starten“ inkorrekt auf die Client-Computer angewendet wurde, wurde behoben.
<G-vec00272-002-s072><apply.anwenden><en> The issue causing the Skip scheduled tasks when running on battery power policy setting to apply to client computers incorrectly has been fixed.
<G-vec00272-002-s073><apply.anwenden><de> Bei vielen Fotoeffekten werden Filter mit geänderten Werten angewendet.
<G-vec00272-002-s073><apply.anwenden><en> Pastaba: Many photo effects apply filters with modified values.
<G-vec00272-002-s074><apply.anwenden><de> Studierende haben anhand eines umfangreichen Projektes für einen - meist FH-externen - Auftraggeber die Projektmanagement-Werkzeuge angewendet und reflektiert.
<G-vec00272-002-s074><apply.anwenden><en> By carrying out a comprehensive project for a ¿mostly external ¿project owner, students apply and reflect project management tools.
<G-vec00272-002-s075><apply.anwenden><de> Sie können somit Regeln definieren, die nur auf Terzen oder Quinten des aktuellen Akkords angewendet werden (siehe unten).
<G-vec00272-002-s075><apply.anwenden><en> In this way you can define rules that apply only to thirds or fifths of the current chord (see below).
<G-vec00369-002-s042><employ.anwenden><de> Probieren Sie es aus auf gratis Spiele zu starten, und dann wirst du auf jeden Fall ganz eingestellt, um sie anzuwenden, wenn es wirklich zählt.
<G-vec00369-002-s042><employ.anwenden><en> Try them out to start on no charge games, and then you will be all set to employ them when it truly counts.
<G-vec00369-002-s043><employ.anwenden><de> Die Wachen entschieden sich neue Methoden anzuwenden – die „separate Verwaltung“ – und teilten die über 600 inhaftierten Praktizierenden in drei große Gruppen auf.
<G-vec00369-002-s043><employ.anwenden><en> The guards decided to employ new methods - "Separate Management" - and divided the more than 600 practitioners in the detention centre into three large teams.
<G-vec00369-002-s044><employ.anwenden><de> Für fleischliche Menschen geistige Methoden anzuwenden, wird nur Verwirrung und Scheitern zur Folge haben.
<G-vec00369-002-s044><employ.anwenden><en> For carnal men to employ spiritual methods will only result in confusion and failure.
<G-vec00369-002-s045><employ.anwenden><de> Aufgrund der erforderlichen speziellen Etikettier- und Biegetechniken sowie der strengen Prüfnormen ist es wichtig, einen effizienten und zuverlässigen Herstellungsprozess anzuwenden.
<G-vec00369-002-s045><employ.anwenden><en> With the specialized labeling and bending techniques that are needed as well as rigorous testing standards, it`s important to employ an efficient and reliable manufacturing process.
<G-vec00369-002-s046><employ.anwenden><de> Umgekehrt aber wächst meine Macht, produktive Arbeiter anzuwenden, durchaus nicht in dem Verhältnis, wie ich unproduktive Arbeiter anwende, sondern nimmt umgekehrt in demselben Verhältnis ab.
<G-vec00369-002-s046><employ.anwenden><en> On the other hand, however, my power to employ productive labourers by no means grows in the same proportion as I employ unproductive labourers, but on the contrary diminishes in the same proportion, although [one has] most to pay for the compulsory services (State, taxes).
<G-vec00369-002-s047><employ.anwenden><de> Aber dennoch hatte er in vielen Fällen Methoden anzuwenden, die dem Mikroskop näher sind als dem photographischen Apparat.
<G-vec00369-002-s047><employ.anwenden><en> But nevertheless in many cases he was obliged to employ methods closer to the microscope than the camera.
<G-vec00369-002-s048><employ.anwenden><de> Damit dies geschieht, ist es unerläßlich, neue Methoden anzuwenden, die uns heute zur Verfügung stehen.
<G-vec00369-002-s048><employ.anwenden><en> For this to happen, it is essential to employ new methods available to us today.
