<G-vec00365-002-s019><shoot.abschießen><de> Ashe kann das Dynamit auch abschießen, um es frühzeitig explodieren zu lassen und so nichts ahnende Gegner überrumpeln.
<G-vec00365-002-s019><shoot.abschießen><en> She can also shoot the dynamite to detonate it early, allowing her to damage unsuspecting enemies.
<G-vec00365-002-s020><shoot.abschießen><de> Mit der Grapple Gun und Laser den Ring an der Decke über dem Kronleuchter abschießen, so daß ein Seil erscheint.
<G-vec00365-002-s020><shoot.abschießen><en> With the Grapple Gun and laser shoot the ring in the ceiling over the chandelier, so that a rope appears.
<G-vec00365-002-s021><shoot.abschießen><de> Es gab zu dieser Zeit keinen Hinweis darauf, dass die mutmaßlich schlecht ausgebildeten prorussischen Separatisten Zugang zu hochentwickelten Waffen hätten, die ein Flugzeug in dieser Höhe abschießen könnten.
<G-vec00365-002-s021><shoot.abschießen><en> There was nothing to suggest at the time that the presumed ill-equipped pro-Russian separatists would have access to sophisticated weapons that would be able to shoot down an airplane at that height.
<G-vec00365-002-s022><shoot.abschießen><de> Die Teilnehmer dürfen sich nicht gegenseitig innerhalb einer Distanz von unter 5 Metern abschießen.
<G-vec00365-002-s022><shoot.abschießen><en> It is not allowed to shoot at each other within a radius of 5 meters.
<G-vec00365-002-s023><shoot.abschießen><de> Du musst sie so schnell wie möglich abschießen, um das Spiel zu gewinnen und dich in den Highscores einzutragen.
<G-vec00365-002-s023><shoot.abschießen><en> You must shoot them down as fast as possible to win the game and enter the highscores.
<G-vec00365-002-s024><shoot.abschießen><de> Anleitung: Ihr müsst 7 Räuchergefäße abschießen.
<G-vec00365-002-s024><shoot.abschießen><en> Guide: You need to shoot down 7 incense burners.
<G-vec00365-002-s025><shoot.abschießen><de> Das Ganze und all die kleinen Wege, die davon abschießen, führen zu einem atemberaubenden Meerblick.
<G-vec00365-002-s025><shoot.abschießen><en> The entire thing and all the little trails that shoot off of it lead to amazing ocean views.
<G-vec00365-002-s026><shoot.abschießen><de> Zu Beginn soweit wie möglich unten halten und die drei am Boden laufenden Maschinen abschießen.
<G-vec00365-002-s026><shoot.abschießen><en> At the start stay low as far as possible and shoot the three machines walking on the ground.
<G-vec00365-002-s027><shoot.abschießen><de> - Schöne Henne und Hühner zum abschießen.
<G-vec00365-002-s027><shoot.abschießen><en> - Beautiful hen and chickens to shoot down.
<G-vec00365-002-s028><shoot.abschießen><de> 15 In Jerusalem ließ er kunstvolle Wurfmaschinen bauen und auf den Türmen und Mauerecken aufstellen, um Pfeile und große Steine abschießen zu können.
<G-vec00365-002-s028><shoot.abschießen><en> 15 He also built machines in Jerusalem, devices contrived to stand on the towers and at the angles of the walls to shoot arrows and cast large stones.
<G-vec00365-002-s029><shoot.abschießen><de> Die Pistolen und die Shotgun holen, die Kiste abschießen, und die Battery nehmen.
<G-vec00365-002-s029><shoot.abschießen><en> The guns and the Shotgun get and shoot box, and take Battery.
<G-vec00365-002-s030><shoot.abschießen><de> Außerdem kannst du von deiner Burg aus Pfeile abschießen.
<G-vec00365-002-s030><shoot.abschießen><en> You can also shoot crossbow from your castle.
<G-vec00365-002-s031><shoot.abschießen><de> Ich meine auch mich erinnern zu können, dass man beim Automaten die kleinen Minen abschießen konnte.
<G-vec00365-002-s031><shoot.abschießen><en> If I remember right, one could shoot the small mines on the arcade machine.
<G-vec00365-002-s032><shoot.abschießen><de> Das Fenster abschießen, und das Laservisier nehmen.
<G-vec00365-002-s032><shoot.abschießen><en> Shoot the window, and take the laser sight.
<G-vec00365-002-s033><shoot.abschießen><de> Du musst Bälle abschießen, um verschiedene Rätsel zu lösen.
<G-vec00365-002-s033><shoot.abschießen><en> You must shoot balls to solve different puzzles.
<G-vec00365-002-s034><shoot.abschießen><de> Die Canon de 155 C modèle 1917 Schneider war ein französisches Geschütz, dass aus der Canon de 155 C Modell 1915 Schneider entstand nur um eine andere Munition abschießen zu können.
<G-vec00365-002-s034><shoot.abschießen><en> Artillery and cannons No French cannon, that from the Canon de 155 C model 1915 Schneider developed only to be able to shoot another ammunition.
<G-vec00365-002-s035><shoot.abschießen><de> Nordkorea kann auch etwas Ballistisches abschießen.
<G-vec00365-002-s035><shoot.abschießen><en> North Korea may also shoot off something ballistic.
<G-vec00365-002-s036><shoot.abschießen><de> Nicht dass unsere Flak in Verlegenheit kommt, Sie abschießen zu müssen.
<G-vec00365-002-s036><shoot.abschießen><en> Not that our flak gets into the situation of having to shoot you.
<G-vec00365-002-s037><shoot.abschießen><de> In diesem explosiven Multiplayer-Spiel musst du andere Flugzeuge abschießen.
<G-vec00365-002-s037><shoot.abschießen><en> In this explosive multiplayer game, you must shoot down other planes.
<G-vec00687-002-s038><shoot.abschießen><de> Ausweichen fliegenden Projektilen und den Gegner abzuschießen, den Himmel des Angreifers zu löschen.
<G-vec00687-002-s038><shoot.abschießen><en> Dodge flying projectiles and shoot down the enemy, clearing the sky of the aggressor.
<G-vec00687-002-s039><shoot.abschießen><de> Mit Ihrem leistungsstarken Maschinengewehr abzuschießen so viele Kämpfer wie posible.
<G-vec00687-002-s039><shoot.abschießen><en> Using your powerful machine gun to shoot down as many fighters as posible.
<G-vec00687-002-s040><shoot.abschießen><de> Um kleine Kugelmagnete abzuschießen, habe ich eine sogenannte "Gauß-Pistole" gebaut.
<G-vec00687-002-s040><shoot.abschießen><en> For shooting In order to shoot off small sphere magnets, I built a so-called "Gauss pistol".
<G-vec00687-002-s041><shoot.abschießen><de> Son-Gohan fordert Mai heraus, alle Kugeln ihrer Pistole auf ihn abzuschießen, woraufhin er sämtliche Kugeln mit einem Finger ablenkt, doch je eine trifft Videls Bein und Beerus Stirn.
<G-vec00687-002-s041><shoot.abschießen><en> A drunk Gohan dares Mai to shoot him; he deflects the bullets with one finger, but one of them hits Videl's leg and another one hits Beerus' forehead.
<G-vec00687-002-s042><shoot.abschießen><de> Bringe einen Stelzenschnipsel dazu, einen anderen Schnipsel abzuschießen.
<G-vec00687-002-s042><shoot.abschießen><en> Force a stilt scrap to shoot another scrap.
<G-vec00687-002-s043><shoot.abschießen><de> Da die Zeit überstanden werden muss bis der Zähler auf Null ist, hilft es nichts alle Gegner vorher abzuschießen, das bringt zwar Punkte, aber auch eine neue vollständige Gegnerformation.
<G-vec00687-002-s043><shoot.abschießen><en> As the time until the counter has run to zero has to be prevailed, it is no use to shoot all enemies before that. This may get you points, but also a complete new enemy formation.
<G-vec00687-002-s044><shoot.abschießen><de> Klicken und Taste gedrückt halten, um das Seil abzuschießen und irgendwo hoch zu klettern.
<G-vec00687-002-s044><shoot.abschießen><en> Click and hold to shoot out a rope in order to climb higher places.
<G-vec00687-002-s045><shoot.abschießen><de> Ihr vorsichtiger Helikopter ist mit Waffen und Rüstungen ausgestattet, um feindliche Fahrzeuge im Schlachtschiffsimulator abzuschießen.
<G-vec00687-002-s045><shoot.abschießen><en> Your cautious helicopter is equipped with weapons and armory to shoot down enemy vehicles in battleship simulator.
<G-vec00687-002-s046><shoot.abschießen><de> Sie können auch Katapulte verwenden, um feindliche Burgen der Könige abzuschießen, berechnet den Winkel und die Kraft des Starts gut und zerstören alles, was Sie können.
<G-vec00687-002-s046><shoot.abschießen><en> You can also use catapults to shoot down enemy castles of kings, calculates the angle and force of the launch well and destroy everything you can.
<G-vec00687-002-s047><shoot.abschießen><de> Seit zweieinhalb Monaten mit diesen Angriffen wurde das israelische Militär angewiesen, die Drachen- und Ballonbesatzungen nicht abzuschießen oder die Fahrzeuge zu treffen, die sie den “Demonstranten” lieferten, die am israelischen Grenzzaun tobten.
<G-vec00687-002-s047><shoot.abschießen><en> For two-and-a-half months of these attacks, the IDF was under orders not to shoot the kite and balloon crews or hit the vehicles delivering them to the “protesters” rampaging on the Israeli border fence.
<G-vec00687-002-s048><shoot.abschießen><de> Pjöngjang sagte, dass die USA dem Land den Krieg erklärt hätten und Nordkorea "jedes Recht hat, Gegenmaßnahmen zu ergreifen, einschließlich des Rechts, strategische Bomber abzuschießen, auch wenn diese sich nicht im Luftraum unseres Landes befinden".
<G-vec00687-002-s048><shoot.abschießen><en> This week, Pyongyang said the US has declared war on the North, and that Pyongyang “will have every right to make countermeasures, including the right to shoot down United States strategic bombers even when they are not inside the airspace border of our country.”
<G-vec00687-002-s049><shoot.abschießen><de> Hilf Ran zu rennen, springen und rutschen, um Hindernisse zu überwinden und Feinde abzuschießen, um...
<G-vec00687-002-s049><shoot.abschießen><en> Help Ran to run, jump and slide to overcome obstacles and shoot enemies to earn the gold she needs t...
<G-vec00687-002-s050><shoot.abschießen><de> Aus dem gleichen Grund niemand in der Lage war, sie abzuschießen, und es ist versucht worden.
<G-vec00687-002-s050><shoot.abschießen><en> For the same reason nobody has been able to shoot them down, and it's been tried.
<G-vec00687-002-s051><shoot.abschießen><de> Verboten ist ferner: die Veranstaltung zu stören, politische Propaganda und Handlungen, rassistisch diskriminierende oder verfassungsfeindliche Parolen/ Embleme zu verwenden oder zu verbreiten; mit Gegenständen jeder Art zu werfen, oder Flüssigkeiten jeder Art zu verschütten; Feuer zu entzünden, Feuerwerkskörper, Leuchtkörper, Rauchpulver, Rauchbomben, bengalische Feuer, Raketen, Wunderkerzen oder andere pyrotechnische Gegenstände abzubrennen oder abzuschießen; bauliche Anlagen, Einrichtungen, oder Wege zu beschriften, zu bemalen oder zu bekleben oder sonstige Sachen in der Anlage aufzustellen; Außerhalb der Toiletten die Notdurft zu verrichten oder das Gebäude durch das Wegwerfen von Gegenständen, Abfällen, Verpackungen, leeren Behältnissen o.Ä.
<G-vec00687-002-s051><shoot.abschießen><en> It is also forbidden: to disturb the event, to use or spread political propaganda and actions, racist discriminatory or anti-constitutional slogans / emblems; to throw objects of any kind, or to spill liquids of any kind; To ignite fires, fireworks, lighting fixtures, smoke powder, smoke bombs, Bengali fires, rockets, sparklers or other pyrotechnic items to burn or shoot down; to mark, paint or cover structural installations, facilities or ways or to set up other things in the facility; to carry out the emergency may outside the toilets or to throw away the building by objects, wastes, packaging, empty containers o.Ä.
<G-vec00687-002-s052><shoot.abschießen><de> In wilden Dogfights versucht man, die Vorzüge der eigenen Maschine ins Spiel zu bringen, um den Gegner abzuschießen.
<G-vec00687-002-s052><shoot.abschießen><en> In wild dogfights you try to bring your plane's advantages into play to shoot down the enemy.
<G-vec00687-002-s053><shoot.abschießen><de> Normalerweise würde man denken, das ist sehr schwierig - aber der Raum ist groß genug, um den Feinden stets auszuweichen und sie nacheinander abzuschießen.
<G-vec00687-002-s053><shoot.abschießen><en> Normally you would think this is very difficult - but the room is large enough to always get out of the way of the enemies and shoot them one by one.
<G-vec00687-002-s054><shoot.abschießen><de> Ein Projektil reichte aus, um jeden einmotorigen Jäger dieser Zeit abzuschießen.
<G-vec00687-002-s054><shoot.abschießen><en> One projectile was enough to shoot down any single-engine fighter of the period.
<G-vec00687-002-s055><shoot.abschießen><de> Versuche, alle Feinde abzuschießen, während du allen ankommenden Lasern ausweicht.
<G-vec00687-002-s055><shoot.abschießen><en> Try to shoot down all enemies while dodging all incomming lasers..
<G-vec00687-002-s056><shoot.abschießen><de> Fremde Platzschiffe schießen über den Himmel und es ist bis zu Ihnen, sie abzuschießen.
<G-vec00687-002-s056><shoot.abschießen><en> Alien Flying Saucers shoot across the sky and it is up to you to shoot them down.
