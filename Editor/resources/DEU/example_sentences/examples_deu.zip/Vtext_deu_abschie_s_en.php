<G-vec00365-002-s019><shoot.abschießen><de> Ashe kann das Dynamit auch abschießen, um es frühzeitig explodieren zu lassen und so nichts ahnende Gegner überrumpeln.
<G-vec00365-002-s019><shoot.abschießen><en> She can also shoot the dynamite to detonate it early, allowing her to damage unsuspecting enemies.
<G-vec00365-002-s020><shoot.abschießen><de> Mit der Grapple Gun und Laser den Ring an der Decke über dem Kronleuchter abschießen, so daß ein Seil erscheint.
<G-vec00365-002-s020><shoot.abschießen><en> With the Grapple Gun and laser shoot the ring in the ceiling over the chandelier, so that a rope appears.
<G-vec00365-002-s021><shoot.abschießen><de> Es gab zu dieser Zeit keinen Hinweis darauf, dass die mutmaßlich schlecht ausgebildeten prorussischen Separatisten Zugang zu hochentwickelten Waffen hätten, die ein Flugzeug in dieser Höhe abschießen könnten.
<G-vec00365-002-s021><shoot.abschießen><en> There was nothing to suggest at the time that the presumed ill-equipped pro-Russian separatists would have access to sophisticated weapons that would be able to shoot down an airplane at that height.
<G-vec00365-002-s022><shoot.abschießen><de> Die Teilnehmer dürfen sich nicht gegenseitig innerhalb einer Distanz von unter 5 Metern abschießen.
<G-vec00365-002-s022><shoot.abschießen><en> It is not allowed to shoot at each other within a radius of 5 meters.
<G-vec00365-002-s023><shoot.abschießen><de> Du musst sie so schnell wie möglich abschießen, um das Spiel zu gewinnen und dich in den Highscores einzutragen.
<G-vec00365-002-s023><shoot.abschießen><en> You must shoot them down as fast as possible to win the game and enter the highscores.
<G-vec00365-002-s024><shoot.abschießen><de> Anleitung: Ihr müsst 7 Räuchergefäße abschießen.
<G-vec00365-002-s024><shoot.abschießen><en> Guide: You need to shoot down 7 incense burners.
<G-vec00365-002-s025><shoot.abschießen><de> Das Ganze und all die kleinen Wege, die davon abschießen, führen zu einem atemberaubenden Meerblick.
<G-vec00365-002-s025><shoot.abschießen><en> The entire thing and all the little trails that shoot off of it lead to amazing ocean views.
<G-vec00365-002-s026><shoot.abschießen><de> Zu Beginn soweit wie möglich unten halten und die drei am Boden laufenden Maschinen abschießen.
<G-vec00365-002-s026><shoot.abschießen><en> At the start stay low as far as possible and shoot the three machines walking on the ground.
<G-vec00365-002-s027><shoot.abschießen><de> - Schöne Henne und Hühner zum abschießen.
<G-vec00365-002-s027><shoot.abschießen><en> - Beautiful hen and chickens to shoot down.
<G-vec00365-002-s028><shoot.abschießen><de> 15 In Jerusalem ließ er kunstvolle Wurfmaschinen bauen und auf den Türmen und Mauerecken aufstellen, um Pfeile und große Steine abschießen zu können.
<G-vec00365-002-s028><shoot.abschießen><en> 15 He also built machines in Jerusalem, devices contrived to stand on the towers and at the angles of the walls to shoot arrows and cast large stones.
<G-vec00365-002-s029><shoot.abschießen><de> Die Pistolen und die Shotgun holen, die Kiste abschießen, und die Battery nehmen.
<G-vec00365-002-s029><shoot.abschießen><en> The guns and the Shotgun get and shoot box, and take Battery.
<G-vec00365-002-s030><shoot.abschießen><de> Außerdem kannst du von deiner Burg aus Pfeile abschießen.
<G-vec00365-002-s030><shoot.abschießen><en> You can also shoot crossbow from your castle.
<G-vec00365-002-s031><shoot.abschießen><de> Ich meine auch mich erinnern zu können, dass man beim Automaten die kleinen Minen abschießen konnte.
<G-vec00365-002-s031><shoot.abschießen><en> If I remember right, one could shoot the small mines on the arcade machine.
<G-vec00365-002-s032><shoot.abschießen><de> Das Fenster abschießen, und das Laservisier nehmen.
<G-vec00365-002-s032><shoot.abschießen><en> Shoot the window, and take the laser sight.
<G-vec00365-002-s033><shoot.abschießen><de> Du musst Bälle abschießen, um verschiedene Rätsel zu lösen.
<G-vec00365-002-s033><shoot.abschießen><en> You must shoot balls to solve different puzzles.
<G-vec00365-002-s034><shoot.abschießen><de> Die Canon de 155 C modèle 1917 Schneider war ein französisches Geschütz, dass aus der Canon de 155 C Modell 1915 Schneider entstand nur um eine andere Munition abschießen zu können.
<G-vec00365-002-s034><shoot.abschießen><en> Artillery and cannons No French cannon, that from the Canon de 155 C model 1915 Schneider developed only to be able to shoot another ammunition.
<G-vec00365-002-s035><shoot.abschießen><de> Nordkorea kann auch etwas Ballistisches abschießen.
<G-vec00365-002-s035><shoot.abschießen><en> North Korea may also shoot off something ballistic.
<G-vec00365-002-s036><shoot.abschießen><de> Nicht dass unsere Flak in Verlegenheit kommt, Sie abschießen zu müssen.
<G-vec00365-002-s036><shoot.abschießen><en> Not that our flak gets into the situation of having to shoot you.
<G-vec00365-002-s037><shoot.abschießen><de> In diesem explosiven Multiplayer-Spiel musst du andere Flugzeuge abschießen.
<G-vec00365-002-s037><shoot.abschießen><en> In this explosive multiplayer game, you must shoot down other planes.
