<G-vec00418-001-s057><drop.ablegen><de> Von ihren Desktops aus können Mitarbeiter die Informationen, die auf der gemeinsamen Videowand angezeigt werden sollen, einfach ziehen und ablegen, um sie mit anderen Bedienern zu teilen.
<G-vec00418-001-s057><drop.ablegen><en> From their desktops, employees just drag and drop the information to be displayed on the collaborative video wall to share simultaneously with other operators.
<G-vec00418-001-s058><drop.ablegen><de> Ersetzen Sie es durch ein neues Bild, indem Sie eine Bilddatei in den Bereich auf der linken Seite laden oder ziehen und ablegen.
<G-vec00418-001-s058><drop.ablegen><en> To replace it with a new image, load or drag and drop a picture file onto the area on the left side.
<G-vec00418-001-s059><drop.ablegen><de> Definition [top] Der Eingangsordner ist ein spezieller Ordner in Ihren persönlichen Dokumenten, in dem die Mitglieder von Gruppen, denen Sie angehören, Dokumente ablegen können.
<G-vec00418-001-s059><drop.ablegen><en> Definition [top] The drop folder is a special folder in your private Documents, where the members of the groups you belong to may drop Documents.
<G-vec00418-001-s060><drop.ablegen><de> Beim Ablegen der Dateien werden Events erstellt (und die Mediendateien im Fenster Projektmedien hinzugefügt, wenn Sie den Explorer verwenden).
<G-vec00418-001-s060><drop.ablegen><en> Events are created where you drop the files (and the media files are added to the Project Media window if you're using the Explorer).
<G-vec00418-001-s061><drop.ablegen><de> Es ist nicht nur klug, um das Smartphone nur für den Fall in die Toilette zu halten unterstützt Sie es ablegen, sondern zusätzlich, ob es gestohlen und Sie haben aus der Ferne abwischen.
<G-vec00418-001-s061><drop.ablegen><en> It isn't only smart to keep the smartphone supported just in case you drop it within the toilet, but additionally whether it will get stolen and you've got to remotely wipe it clean.
<G-vec00418-001-s062><drop.ablegen><de> ie auf der Nuxeo Platform basierte CNG-Anwendung ermöglicht Journalisten die Zusammenstellung von Artikeln mit Texten, Fotos und Videos durch einfaches Ziehen und Ablegen.
<G-vec00418-001-s062><drop.ablegen><en> The Nuxeo Platform-based CNG application enables journalists to compile news stories using text, photos and/or videos by simply using drag and drop.
<G-vec00418-001-s063><drop.ablegen><de> Speichern Sie diese innerhalb SendBlaster, indem Sie das Programmsymbol auf den Abschnitt Verknüpfungen ziehen und ablegen.
<G-vec00418-001-s063><drop.ablegen><en> To save them within SendBlaster, simply drag and drop the program icon to the Shortcuts section.
<G-vec00418-001-s064><drop.ablegen><de> So ist es besser, zurück bringen und ablegen.
<G-vec00418-001-s064><drop.ablegen><en> That ́s better, bring it back and drop it.
<G-vec00418-001-s065><drop.ablegen><de> Wenn Sie es einmal etwas beschaulicher mögen, fahren Sie nach Gargnano und gönnen Sie sich an der Promenade neben dem Hafen einen Espresso oder Capucino und beobachten dabei, wie die Rundfahrtschiffe an- und ablegen.
<G-vec00418-001-s065><drop.ablegen><en> If you like it a bit more contemplative, head to Gargnano and treat yourself to an espresso or capucino on the promenade next to the harbor, watching the cruise ships take off and drop off.
<G-vec00418-001-s066><drop.ablegen><de> Du kannst auch die Pfeiltasten „Rechts“ und „Links“ zum Bewegen und die Leertaste oder die Pfeiltaste „Runter“ zum Ablegen eines Spielsteines benutzen.
<G-vec00418-001-s066><drop.ablegen><en> You can also use the arrow keys to move the token left or right, and the down or space key to drop a token.
<G-vec00418-001-s067><drop.ablegen><de> Hinweis: Werden Inhalte in nur einer Sprache angezeigt, können Sie Seiten an einen anderen Ort in der Seitenbaumstruktur verschieben, indem Sie sie ziehen und ablegen oder kopieren und einfügen, aber diese Seiten können nicht sortiert werden.
<G-vec00418-001-s067><drop.ablegen><en> When you show content in one language only, you can move pages to another location in the page tree structure by drag and drop or copy and paste, but it is not possible to sort pages.
<G-vec00418-001-s068><drop.ablegen><de> Selbst dann wirken die Qualitäten weiter und leiten die Körperfunktionen, bis wir unseren Träger ablegen.
<G-vec00418-001-s068><drop.ablegen><en> Even then the qualities continue to work and conduct the body functions until we drop off our vehicle.
<G-vec00418-001-s069><drop.ablegen><de> Ist die Brainstormingphase abgeschlossen, ordnen Sie die Zweige Ihrer Mind Map einfach per Ziehen und Ablegen, um die gewünschte Projektstruktur zu erhalten.
<G-vec00418-001-s069><drop.ablegen><en> Once your brainstorming phase is complete, simply drag and drop the branches of your Mind Map to transform it into the necessary Work Breakdown Structure.
<G-vec00418-001-s070><drop.ablegen><de> Zum Hochladen Datei hier ablegen oder auf den Button klicken.
<G-vec00418-001-s070><drop.ablegen><en> Drop a file here or click to upload Choose File
<G-vec00418-001-s071><drop.ablegen><de> Diese Besonderheit solltet ihr ablegen und die wirkliche Schönheit eurer Persönlichkeit erreichen.
<G-vec00418-001-s071><drop.ablegen><en> This speciality you should drop and the real beauty of your personality reached.
<G-vec00418-001-s072><drop.ablegen><de> Syntex beendet in den USA im Jahr 1993, die etwa zur gleichen Zeit entschlossen sie sich war, dieses Element in einer Reihe von ausländischen Ländern sowie ablegen.
<G-vec00418-001-s072><drop.ablegen><en> Syntex stopped in the U.S. in 1993, which was around the same time they decided to drop this item in a number of foreign countries as well.
<G-vec00418-001-s073><drop.ablegen><de> Darüber hinaus die Infektion ist relativ neu und da gibt es nicht genügend Informationen, wie es funktioniert, es könnte sogar schädliche Daten in anderen Verzeichnissen ablegen.
<G-vec00418-001-s073><drop.ablegen><en> In addition, the infection is fairly new and because there is not enough information, how it works, it could drop even malicious data in other directories.
<G-vec00418-001-s074><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Security for Microsoft SharePoint-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s074><drop.ablegen><en> You can also drag and drop files into the ESET File Security scan window. These files will be virus scanned immediately.
<G-vec00418-001-s075><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Mail Security-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s075><drop.ablegen><en> You can also drag and drop files into the ESET Mail Security scan window. These files will be virus scanned immediately.
<G-vec00345-001-s110><reckon.ablegen><de> Speziell bei den Jugendlichen entsteht so das Bild eines Gottes, der ohnehin niemandem etwas abschlagen kann und dem man daher gar keine Rechenschaft ablegen muss.
<G-vec00345-001-s110><reckon.ablegen><en> Among the youth especially, an image of God has arisen who cannot deny anyone anything and with whom one therefore does not need to reckon.
<G-vec00060-001-s095><unveil.ablegen><de> Auf Großveranstaltungen wurden Frauen aufgefordert, den Schleier abzulegen: Kleine Gruppen einheimischer Frauen sollten zur Bühne gehen und ihre Schleier in die Freudenfeuer werfen.
<G-vec00060-001-s095><unveil.ablegen><en> At mass meetings women were called upon to unveil: small groups of native women were expected to come to the podium and throw their veils on bonfires.
<G-vec00311-002-s141><vow.ablegen><de> Und indem Sie UniqueHoodia™ bestellen werden Sie einen Schwur ablegen (genau wie viele andere vor Ihnen), dass Sie Ihr Gewichtsmanagement ernst nehmen.
<G-vec00311-002-s141><vow.ablegen><en> And by ordering UniqueHoodia™ you will be making a vow (just like many others before you) that you will take your weight management seriously.
<G-vec00321-002-s056><drop.ablegen><de> Wenn sich die Shapes bereits auf dem Zeichenblatt befinden, können Sie einen Verbinder von einem blauen AutoVerbinden-Pfeil eines Shapes ziehen und auf einem anderen Shape ablegen.
<G-vec00321-002-s056><drop.ablegen><en> If your shapes are already on the page, you can drag a connector from a blue AutoConnect arrow of one shape and drop it on another shape.
<G-vec00321-002-s058><drop.ablegen><de> Wenn Sie eine Dimension in der mittleren Dropzone ablegen, wird automatisch ein Bericht ausgeführt, der die obersten Elemente für diese Dimension einfügt.
<G-vec00321-002-s058><drop.ablegen><en> If you drop a dimension into the middle zone, a report is automatically run that inserts the top items for that dimension.
<G-vec00321-002-s060><drop.ablegen><de> Einfach Audiodateien per Ziehen und Ablegen auf dem iPhone speichern und schon sind sie als Klingelton verfügbar.
<G-vec00321-002-s060><drop.ablegen><en> Simply drag & drop an audio file to your phone to make it available as a ringtone.
<G-vec00321-002-s061><drop.ablegen><de> Datei auswählen Ein Video von Ihrem Computer oder Handy öffnen oder ziehen und ablegen.
<G-vec00321-002-s061><drop.ablegen><en> Choose file Open or drag&drop a video from your Mac, Windows computer or other device.
<G-vec00321-002-s062><drop.ablegen><de> Sie haben also die Möglichkeit entweder die zu kopierenden Dateien auf Ihren Schreibtisch / Desktop ihres Macs zu ziehen (siehe Methode 1), oder Sie öffnen den Finder, wenn Sie die Dateien an einen anderen Speicherplatz ablegen möchten.
<G-vec00321-002-s062><drop.ablegen><en> You can drag the files to be copied onto the desktop of your Mac (see Method 1) or open the Finder if you want to drop the files at another storage location.
<G-vec00321-002-s063><drop.ablegen><de> Das Ziehen und Ablegen einer Datei von Mac auf Windows funktioniert nicht.
<G-vec00321-002-s063><drop.ablegen><en> Drag and Drop a file from Mac to Windows doesn’t work.
<G-vec00321-002-s064><drop.ablegen><de> In der Regel beginnt Ihr Arbeitstag mit der morgendlichen Hilfe: Frühstück, Anziehen und Ablegen im Kindergarten (3 Minuten zu Fuß).
<G-vec00321-002-s064><drop.ablegen><en> Tipically, your work day will start with helping in the morning: breakfast, dress-up and drop in the kindergarten (3 min walking distance).
<G-vec00321-002-s065><drop.ablegen><de> Ziehen und Ablegen von Plänen und Aktionen unterstützt Kopieren, Verschieben und Löschen von Operationen.
<G-vec00321-002-s065><drop.ablegen><en> Drag and drop of plans and actions supports copy, move and delete operations.
<G-vec00321-002-s066><drop.ablegen><de> Sie können Fotos, Audio- und Videomaterial aus der Medienbibliothek in der gewünschten Reihenfolge auf die Zeitachse ziehen und ablegen.
<G-vec00321-002-s066><drop.ablegen><en> You can drag and drop photos, audio and video from the media library to the timeline in the order you want them to appear.
<G-vec00321-002-s067><drop.ablegen><de> Sie können sie einfach ziehen, ablegen und bearbeiten, um verschiedenen Situationen gerecht zu werden, oder spezielle Formen erstellen, um spezielle Anforderungen mit vorbereiteten Zeichenwerkzeugen zu erfüllen.
<G-vec00321-002-s067><drop.ablegen><en> Just feel free to drag, drop and edit them to meet different situations or create special shapes to meet special requirements with prepared drawing tools.
<G-vec00321-002-s068><drop.ablegen><de> Sie können die Elemente dann im Ordner oder in einem beliebigen Unterordner ablegen.
<G-vec00321-002-s068><drop.ablegen><en> You can then drop the items into the folder or any subfolders under it.
<G-vec00321-002-s069><drop.ablegen><de> Sie können aber auch weitere Verantwortlichkeitsbereich-Shapes aus dem Fenster Shapes ziehen und ablegen, wenn der orangefarbene Verbindungsanzeiger eingeblendet wird.
<G-vec00321-002-s069><drop.ablegen><en> Or you can drag more swimlane shapes from the Shapes window and drop them when you see the orange connection indicator.
<G-vec00321-002-s070><drop.ablegen><de> In der Bibliothek wird eine Tafel mit einem Korb aufgehängt, in dem Sie das Buch, das Sie lesen, ablegen und Ihre Meinung dazu schreiben können, um es anderen Gästen zu empfehlen.
<G-vec00321-002-s070><drop.ablegen><en> A table is hung in the library with a basket where you can drop off the book you read and write your opinion on it in order to recommend it to other guests.
<G-vec00321-002-s071><drop.ablegen><de> Wenn ich diese Verteilung übernehmen musste, kamen mir beim Ablegen auf die Beistelltischchen ganz besondere Gedanken.
<G-vec00321-002-s071><drop.ablegen><en> If I had to take this distribution, came to me when you drop it on the side table special thoughts.
<G-vec00321-002-s072><drop.ablegen><de> Sie können auch bestehende Seiten mit der Maus in den Index ziehen und ablegen.
<G-vec00321-002-s072><drop.ablegen><en> You can also drag and drop existing pages into the Index.
<G-vec00321-002-s073><drop.ablegen><de> Fügen Sie per Ziehen und Ablegen Filter, Übergänge und wirkungsstarke Titel ein.
<G-vec00321-002-s073><drop.ablegen><en> Create Drag and drop filters, transitions and high-impact titles.
<G-vec00321-002-s074><drop.ablegen><de> Ein Benutzer kann hinzufügen oderersetzen ein Projekt Logo auf verschiedene Arten - durch Ziehen und Ablegen oder durch Drücken auf einen Logo-Bereich.
<G-vec00321-002-s074><drop.ablegen><en> A user can add or replace a project logo in several ways – with drag and drop or by pressing on a logo area.
<G-vec00380-002-s162><discard.ablegen><de> Wenn aufgedeckt: Lege 1 zufällige Karte von deiner Hand ab.
<G-vec00380-002-s162><discard.ablegen><en> When Revealed: Discard 1 random card from your hand.
<G-vec00380-002-s163><discard.ablegen><de> Falls die Probe gelingt, lege die Stimme des Dschungels ab.
<G-vec00380-002-s163><discard.ablegen><en> If you succeed, discard Voice of the Jungle.
<G-vec00380-002-s164><discard.ablegen><de> Reaktion: Nachdem du Frischgebackener Lord aufmarschieren lassen hast, wähle einen nicht-limitierten Ort mit aufgedruckten Kosten von 3oder weniger und lege ihn aus dem Spiel ab.
<G-vec00380-002-s164><discard.ablegen><en> Reaction: After you marshal Newly-Made Lord, choose a non-limited location with printed cost 3 or lower, and discard it from play.
<G-vec00380-002-s165><discard.ablegen><de> Behalte die Wild Card und den 3 karten Straight Flush und lege die andere Karte ab.
<G-vec00380-002-s165><discard.ablegen><en> Keep the wild card and the three-card straight flush and discard the other card.
<G-vec00380-002-s166><discard.ablegen><de> Behalte den Vier Karten Royal Flush und lege die andere Karte ab.
<G-vec00380-002-s166><discard.ablegen><en> Keep the four-card royal flush and discard the other card.
<G-vec00380-002-s167><discard.ablegen><de> Falls die Probe misslingt, musst du entweder (wähle eins): Lege die obersten 5 Karten deines Decks ab oder nimm 1 direkten Schaden und füge jedem deiner Verbündeter-Vorteilskarten 1 Schaden zu.
<G-vec00380-002-s167><discard.ablegen><en> If you fail you must either (choose one): discard the top 5 cards of your deck, or take 1 direct damage and deal 1 damage to each of your allies.
<G-vec00380-002-s168><discard.ablegen><de> - 3a Erzwungen - Falls sich am Ende der Runde Das Tor zur Hölle im Spiel befindet: Lege den Ort ab, der am weitesten vom Tor zur Hölle entfernt ist.
<G-vec00380-002-s168><discard.ablegen><en> 1x 244 in Forced - At the end of the round, if The Gate to Hell is in play: Discard the location that is farthest from The Gate to Hell.
<G-vec00380-002-s169><discard.ablegen><de> Falls du Arya Stark kontrollierst, lege Cat von den Kanälen aus dem Spiel ab.
<G-vec00380-002-s169><discard.ablegen><en> If you control Arya Stark, discard Cat o' the Canals from play.
<G-vec00380-002-s170><discard.ablegen><de> Lege Karten vom Begegnungsdeck ab, bis ein Unhold-Gegner abgelegt wird.
<G-vec00380-002-s170><discard.ablegen><en> Discard cards from the encounter deck until a Wight enemy is discarded.
<G-vec00380-002-s171><discard.ablegen><de> Wenn aufgedeckt: Lege 1 Dorfbewohner-Marker für jeden Spieler im Spiel vom aktiven Ort ab.
<G-vec00380-002-s171><discard.ablegen><en> When Revealed: Discard 1 villager token from the active location for each player in the game.
<G-vec00380-002-s172><discard.ablegen><de> - Falls sich Agenda 2c im Spiel befindet, nimm 2 Horror und lege 2 Karten von deiner Hand ab.
<G-vec00380-002-s172><discard.ablegen><en> - If agenda 2c is in play, take 2 horror and discard 2 cards from your hand.
<G-vec00380-002-s173><discard.ablegen><de> Reaktion: Nachdem eine Gleiter- oder Raumjäger-Einheit, die du kommandierst, auf einen Angriffsschlag fokussiert worden ist, lege eine Ereignis karte von deiner Hand ab, damit die Einheit bis zum Ende des Angriffsschlags () erhält.
<G-vec00380-002-s173><discard.ablegen><en> 2x Set 259 Technologisches Reaction: After a Speeder or Fighter unit you control is focused to strike, discard an event card from your hand to have that unit gain () until the end of the strike.
<G-vec00380-002-s174><discard.ablegen><de> Reaktion: Nachdem der Held mit dieser Verstärkung erschöpft worden ist, um gegen einen Angriff zu verteidigen, lege die oberste Karte des Begegnungsdecks ab.
<G-vec00380-002-s174><discard.ablegen><en> Response: After attached hero exhausts to defend an attack, discard the top card of the encounter deck.
<G-vec00380-002-s175><discard.ablegen><de> Aufmarsch: Lege Narrow Sea aus dem Spiel ab, um die Kosten des nächsten - oder -Charakters, den du in dieser Phase spielst, um 2 zu reduzieren.
<G-vec00380-002-s175><discard.ablegen><en> 3x 028 in Marshalling: Discard Narrow Sea from play to reduce the cost of the next or character you play this phase by 2.
<G-vec00380-002-s036><shed.ablegen><de> Darüber hinaus umweht sogar die zugänglichsten LLC-Mitglieder ein Hauch von Adel, Erhabenheit und Einfluss, den sie nie vollständig ablegen können – ob es nun der Glaube ist, dass täglich jemand kommt, um die Kleidung zu reinigen, oder die in die Firmware verbaute Annahme, dass alle Wesen der unteren Klassen eliminiert werden müssen, damit der Wert des übrigen Universums steigt.
<G-vec00380-002-s036><shed.ablegen><en> On top of that, even the kindest of the LLC members have an air of aristocracy, entitlement, and affluence that cannot completely be shed; whether that means a daily assumption that someone is there to clean your dress, or firmware-held beliefs that all beings of lesser classes must be eliminated to raise the value of the remaining universe. Can you tell us about LLC’s abilities?
<G-vec00380-002-s037><shed.ablegen><de> Zuerst muss man seine jetzige Identität ablegen, um eine neue anzunehmen.
<G-vec00380-002-s037><shed.ablegen><en> You must firstly shed your current identity before adopting a new one,” he says.
<G-vec00380-002-s038><shed.ablegen><de> Wenn die Triebe der Petunien weiter wachsen, aber ihre Samenhülle nicht ablegen, müssen sie helfen.
<G-vec00380-002-s038><shed.ablegen><en> If the shoots of petunias continue to grow, but they do not shed their seed coat, they will have to help.
<G-vec00380-002-s039><shed.ablegen><de> Wann immer sie ihren physischen Körper ablegen und einen neuen bekommen, erinnern sie sich an die Beständigkeit ihres Ziels und an die Identität ihres Bewusstseinsfadens durch die Wiedergeburt hindurch.
<G-vec00380-002-s039><shed.ablegen><en> Whenever they shed their physical bodies and get new ones, they remember the continuity of their goal and the identity of their thread of consciousness throughout the reincarnations.
