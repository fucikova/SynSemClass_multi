<G-vec00418-001-s057><drop.ablegen><de> Von ihren Desktops aus können Mitarbeiter die Informationen, die auf der gemeinsamen Videowand angezeigt werden sollen, einfach ziehen und ablegen, um sie mit anderen Bedienern zu teilen.
<G-vec00418-001-s057><drop.ablegen><en> From their desktops, employees just drag and drop the information to be displayed on the collaborative video wall to share simultaneously with other operators.
<G-vec00418-001-s058><drop.ablegen><de> Ersetzen Sie es durch ein neues Bild, indem Sie eine Bilddatei in den Bereich auf der linken Seite laden oder ziehen und ablegen.
<G-vec00418-001-s058><drop.ablegen><en> To replace it with a new image, load or drag and drop a picture file onto the area on the left side.
<G-vec00418-001-s059><drop.ablegen><de> Definition [top] Der Eingangsordner ist ein spezieller Ordner in Ihren persönlichen Dokumenten, in dem die Mitglieder von Gruppen, denen Sie angehören, Dokumente ablegen können.
<G-vec00418-001-s059><drop.ablegen><en> Definition [top] The drop folder is a special folder in your private Documents, where the members of the groups you belong to may drop Documents.
<G-vec00418-001-s060><drop.ablegen><de> Beim Ablegen der Dateien werden Events erstellt (und die Mediendateien im Fenster Projektmedien hinzugefügt, wenn Sie den Explorer verwenden).
<G-vec00418-001-s060><drop.ablegen><en> Events are created where you drop the files (and the media files are added to the Project Media window if you're using the Explorer).
<G-vec00418-001-s061><drop.ablegen><de> Es ist nicht nur klug, um das Smartphone nur für den Fall in die Toilette zu halten unterstützt Sie es ablegen, sondern zusätzlich, ob es gestohlen und Sie haben aus der Ferne abwischen.
<G-vec00418-001-s061><drop.ablegen><en> It isn't only smart to keep the smartphone supported just in case you drop it within the toilet, but additionally whether it will get stolen and you've got to remotely wipe it clean.
<G-vec00418-001-s062><drop.ablegen><de> ie auf der Nuxeo Platform basierte CNG-Anwendung ermöglicht Journalisten die Zusammenstellung von Artikeln mit Texten, Fotos und Videos durch einfaches Ziehen und Ablegen.
<G-vec00418-001-s062><drop.ablegen><en> The Nuxeo Platform-based CNG application enables journalists to compile news stories using text, photos and/or videos by simply using drag and drop.
<G-vec00418-001-s063><drop.ablegen><de> Speichern Sie diese innerhalb SendBlaster, indem Sie das Programmsymbol auf den Abschnitt Verknüpfungen ziehen und ablegen.
<G-vec00418-001-s063><drop.ablegen><en> To save them within SendBlaster, simply drag and drop the program icon to the Shortcuts section.
<G-vec00418-001-s064><drop.ablegen><de> So ist es besser, zurück bringen und ablegen.
<G-vec00418-001-s064><drop.ablegen><en> That ́s better, bring it back and drop it.
<G-vec00418-001-s065><drop.ablegen><de> Wenn Sie es einmal etwas beschaulicher mögen, fahren Sie nach Gargnano und gönnen Sie sich an der Promenade neben dem Hafen einen Espresso oder Capucino und beobachten dabei, wie die Rundfahrtschiffe an- und ablegen.
<G-vec00418-001-s065><drop.ablegen><en> If you like it a bit more contemplative, head to Gargnano and treat yourself to an espresso or capucino on the promenade next to the harbor, watching the cruise ships take off and drop off.
<G-vec00418-001-s066><drop.ablegen><de> Du kannst auch die Pfeiltasten „Rechts“ und „Links“ zum Bewegen und die Leertaste oder die Pfeiltaste „Runter“ zum Ablegen eines Spielsteines benutzen.
<G-vec00418-001-s066><drop.ablegen><en> You can also use the arrow keys to move the token left or right, and the down or space key to drop a token.
<G-vec00418-001-s067><drop.ablegen><de> Hinweis: Werden Inhalte in nur einer Sprache angezeigt, können Sie Seiten an einen anderen Ort in der Seitenbaumstruktur verschieben, indem Sie sie ziehen und ablegen oder kopieren und einfügen, aber diese Seiten können nicht sortiert werden.
<G-vec00418-001-s067><drop.ablegen><en> When you show content in one language only, you can move pages to another location in the page tree structure by drag and drop or copy and paste, but it is not possible to sort pages.
<G-vec00418-001-s068><drop.ablegen><de> Selbst dann wirken die Qualitäten weiter und leiten die Körperfunktionen, bis wir unseren Träger ablegen.
<G-vec00418-001-s068><drop.ablegen><en> Even then the qualities continue to work and conduct the body functions until we drop off our vehicle.
<G-vec00418-001-s069><drop.ablegen><de> Ist die Brainstormingphase abgeschlossen, ordnen Sie die Zweige Ihrer Mind Map einfach per Ziehen und Ablegen, um die gewünschte Projektstruktur zu erhalten.
<G-vec00418-001-s069><drop.ablegen><en> Once your brainstorming phase is complete, simply drag and drop the branches of your Mind Map to transform it into the necessary Work Breakdown Structure.
<G-vec00418-001-s070><drop.ablegen><de> Zum Hochladen Datei hier ablegen oder auf den Button klicken.
<G-vec00418-001-s070><drop.ablegen><en> Drop a file here or click to upload Choose File
<G-vec00418-001-s071><drop.ablegen><de> Diese Besonderheit solltet ihr ablegen und die wirkliche Schönheit eurer Persönlichkeit erreichen.
<G-vec00418-001-s071><drop.ablegen><en> This speciality you should drop and the real beauty of your personality reached.
<G-vec00418-001-s072><drop.ablegen><de> Syntex beendet in den USA im Jahr 1993, die etwa zur gleichen Zeit entschlossen sie sich war, dieses Element in einer Reihe von ausländischen Ländern sowie ablegen.
<G-vec00418-001-s072><drop.ablegen><en> Syntex stopped in the U.S. in 1993, which was around the same time they decided to drop this item in a number of foreign countries as well.
<G-vec00418-001-s073><drop.ablegen><de> Darüber hinaus die Infektion ist relativ neu und da gibt es nicht genügend Informationen, wie es funktioniert, es könnte sogar schädliche Daten in anderen Verzeichnissen ablegen.
<G-vec00418-001-s073><drop.ablegen><en> In addition, the infection is fairly new and because there is not enough information, how it works, it could drop even malicious data in other directories.
<G-vec00418-001-s074><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Security for Microsoft SharePoint-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s074><drop.ablegen><en> You can also drag and drop files into the ESET File Security scan window. These files will be virus scanned immediately.
<G-vec00418-001-s075><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Mail Security-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s075><drop.ablegen><en> You can also drag and drop files into the ESET Mail Security scan window. These files will be virus scanned immediately.
<G-vec00345-001-s110><reckon.ablegen><de> Speziell bei den Jugendlichen entsteht so das Bild eines Gottes, der ohnehin niemandem etwas abschlagen kann und dem man daher gar keine Rechenschaft ablegen muss.
<G-vec00345-001-s110><reckon.ablegen><en> Among the youth especially, an image of God has arisen who cannot deny anyone anything and with whom one therefore does not need to reckon.
<G-vec00060-001-s095><unveil.ablegen><de> Auf Großveranstaltungen wurden Frauen aufgefordert, den Schleier abzulegen: Kleine Gruppen einheimischer Frauen sollten zur Bühne gehen und ihre Schleier in die Freudenfeuer werfen.
<G-vec00060-001-s095><unveil.ablegen><en> At mass meetings women were called upon to unveil: small groups of native women were expected to come to the podium and throw their veils on bonfires.
<G-vec00311-002-s141><vow.ablegen><de> Und indem Sie UniqueHoodia™ bestellen werden Sie einen Schwur ablegen (genau wie viele andere vor Ihnen), dass Sie Ihr Gewichtsmanagement ernst nehmen.
<G-vec00311-002-s141><vow.ablegen><en> And by ordering UniqueHoodia™ you will be making a vow (just like many others before you) that you will take your weight management seriously.
<G-vec00321-002-s056><drop.ablegen><de> Wenn sich die Shapes bereits auf dem Zeichenblatt befinden, können Sie einen Verbinder von einem blauen AutoVerbinden-Pfeil eines Shapes ziehen und auf einem anderen Shape ablegen.
<G-vec00321-002-s056><drop.ablegen><en> If your shapes are already on the page, you can drag a connector from a blue AutoConnect arrow of one shape and drop it on another shape.
<G-vec00321-002-s058><drop.ablegen><de> Wenn Sie eine Dimension in der mittleren Dropzone ablegen, wird automatisch ein Bericht ausgeführt, der die obersten Elemente für diese Dimension einfügt.
<G-vec00321-002-s058><drop.ablegen><en> If you drop a dimension into the middle zone, a report is automatically run that inserts the top items for that dimension.
<G-vec00321-002-s060><drop.ablegen><de> Einfach Audiodateien per Ziehen und Ablegen auf dem iPhone speichern und schon sind sie als Klingelton verfügbar.
<G-vec00321-002-s060><drop.ablegen><en> Simply drag & drop an audio file to your phone to make it available as a ringtone.
<G-vec00321-002-s061><drop.ablegen><de> Datei auswählen Ein Video von Ihrem Computer oder Handy öffnen oder ziehen und ablegen.
<G-vec00321-002-s061><drop.ablegen><en> Choose file Open or drag&drop a video from your Mac, Windows computer or other device.
<G-vec00321-002-s062><drop.ablegen><de> Sie haben also die Möglichkeit entweder die zu kopierenden Dateien auf Ihren Schreibtisch / Desktop ihres Macs zu ziehen (siehe Methode 1), oder Sie öffnen den Finder, wenn Sie die Dateien an einen anderen Speicherplatz ablegen möchten.
<G-vec00321-002-s062><drop.ablegen><en> You can drag the files to be copied onto the desktop of your Mac (see Method 1) or open the Finder if you want to drop the files at another storage location.
<G-vec00321-002-s063><drop.ablegen><de> Das Ziehen und Ablegen einer Datei von Mac auf Windows funktioniert nicht.
<G-vec00321-002-s063><drop.ablegen><en> Drag and Drop a file from Mac to Windows doesn’t work.
<G-vec00321-002-s064><drop.ablegen><de> In der Regel beginnt Ihr Arbeitstag mit der morgendlichen Hilfe: Frühstück, Anziehen und Ablegen im Kindergarten (3 Minuten zu Fuß).
<G-vec00321-002-s064><drop.ablegen><en> Tipically, your work day will start with helping in the morning: breakfast, dress-up and drop in the kindergarten (3 min walking distance).
<G-vec00321-002-s065><drop.ablegen><de> Ziehen und Ablegen von Plänen und Aktionen unterstützt Kopieren, Verschieben und Löschen von Operationen.
<G-vec00321-002-s065><drop.ablegen><en> Drag and drop of plans and actions supports copy, move and delete operations.
<G-vec00321-002-s066><drop.ablegen><de> Sie können Fotos, Audio- und Videomaterial aus der Medienbibliothek in der gewünschten Reihenfolge auf die Zeitachse ziehen und ablegen.
<G-vec00321-002-s066><drop.ablegen><en> You can drag and drop photos, audio and video from the media library to the timeline in the order you want them to appear.
<G-vec00321-002-s067><drop.ablegen><de> Sie können sie einfach ziehen, ablegen und bearbeiten, um verschiedenen Situationen gerecht zu werden, oder spezielle Formen erstellen, um spezielle Anforderungen mit vorbereiteten Zeichenwerkzeugen zu erfüllen.
<G-vec00321-002-s067><drop.ablegen><en> Just feel free to drag, drop and edit them to meet different situations or create special shapes to meet special requirements with prepared drawing tools.
<G-vec00321-002-s068><drop.ablegen><de> Sie können die Elemente dann im Ordner oder in einem beliebigen Unterordner ablegen.
<G-vec00321-002-s068><drop.ablegen><en> You can then drop the items into the folder or any subfolders under it.
<G-vec00321-002-s069><drop.ablegen><de> Sie können aber auch weitere Verantwortlichkeitsbereich-Shapes aus dem Fenster Shapes ziehen und ablegen, wenn der orangefarbene Verbindungsanzeiger eingeblendet wird.
<G-vec00321-002-s069><drop.ablegen><en> Or you can drag more swimlane shapes from the Shapes window and drop them when you see the orange connection indicator.
<G-vec00321-002-s070><drop.ablegen><de> In der Bibliothek wird eine Tafel mit einem Korb aufgehängt, in dem Sie das Buch, das Sie lesen, ablegen und Ihre Meinung dazu schreiben können, um es anderen Gästen zu empfehlen.
<G-vec00321-002-s070><drop.ablegen><en> A table is hung in the library with a basket where you can drop off the book you read and write your opinion on it in order to recommend it to other guests.
<G-vec00321-002-s071><drop.ablegen><de> Wenn ich diese Verteilung übernehmen musste, kamen mir beim Ablegen auf die Beistelltischchen ganz besondere Gedanken.
<G-vec00321-002-s071><drop.ablegen><en> If I had to take this distribution, came to me when you drop it on the side table special thoughts.
<G-vec00321-002-s072><drop.ablegen><de> Sie können auch bestehende Seiten mit der Maus in den Index ziehen und ablegen.
<G-vec00321-002-s072><drop.ablegen><en> You can also drag and drop existing pages into the Index.
<G-vec00321-002-s073><drop.ablegen><de> Fügen Sie per Ziehen und Ablegen Filter, Übergänge und wirkungsstarke Titel ein.
<G-vec00321-002-s073><drop.ablegen><en> Create Drag and drop filters, transitions and high-impact titles.
<G-vec00321-002-s074><drop.ablegen><de> Ein Benutzer kann hinzufügen oderersetzen ein Projekt Logo auf verschiedene Arten - durch Ziehen und Ablegen oder durch Drücken auf einen Logo-Bereich.
<G-vec00321-002-s074><drop.ablegen><en> A user can add or replace a project logo in several ways – with drag and drop or by pressing on a logo area.
<G-vec00380-002-s162><discard.ablegen><de> Wenn aufgedeckt: Lege 1 zufällige Karte von deiner Hand ab.
<G-vec00380-002-s162><discard.ablegen><en> When Revealed: Discard 1 random card from your hand.
<G-vec00380-002-s163><discard.ablegen><de> Falls die Probe gelingt, lege die Stimme des Dschungels ab.
<G-vec00380-002-s163><discard.ablegen><en> If you succeed, discard Voice of the Jungle.
<G-vec00380-002-s164><discard.ablegen><de> Reaktion: Nachdem du Frischgebackener Lord aufmarschieren lassen hast, wähle einen nicht-limitierten Ort mit aufgedruckten Kosten von 3oder weniger und lege ihn aus dem Spiel ab.
<G-vec00380-002-s164><discard.ablegen><en> Reaction: After you marshal Newly-Made Lord, choose a non-limited location with printed cost 3 or lower, and discard it from play.
<G-vec00380-002-s165><discard.ablegen><de> Behalte die Wild Card und den 3 karten Straight Flush und lege die andere Karte ab.
<G-vec00380-002-s165><discard.ablegen><en> Keep the wild card and the three-card straight flush and discard the other card.
<G-vec00380-002-s166><discard.ablegen><de> Behalte den Vier Karten Royal Flush und lege die andere Karte ab.
<G-vec00380-002-s166><discard.ablegen><en> Keep the four-card royal flush and discard the other card.
<G-vec00380-002-s167><discard.ablegen><de> Falls die Probe misslingt, musst du entweder (wähle eins): Lege die obersten 5 Karten deines Decks ab oder nimm 1 direkten Schaden und füge jedem deiner Verbündeter-Vorteilskarten 1 Schaden zu.
<G-vec00380-002-s167><discard.ablegen><en> If you fail you must either (choose one): discard the top 5 cards of your deck, or take 1 direct damage and deal 1 damage to each of your allies.
<G-vec00380-002-s168><discard.ablegen><de> - 3a Erzwungen - Falls sich am Ende der Runde Das Tor zur Hölle im Spiel befindet: Lege den Ort ab, der am weitesten vom Tor zur Hölle entfernt ist.
<G-vec00380-002-s168><discard.ablegen><en> 1x 244 in Forced - At the end of the round, if The Gate to Hell is in play: Discard the location that is farthest from The Gate to Hell.
<G-vec00380-002-s169><discard.ablegen><de> Falls du Arya Stark kontrollierst, lege Cat von den Kanälen aus dem Spiel ab.
<G-vec00380-002-s169><discard.ablegen><en> If you control Arya Stark, discard Cat o' the Canals from play.
<G-vec00380-002-s170><discard.ablegen><de> Lege Karten vom Begegnungsdeck ab, bis ein Unhold-Gegner abgelegt wird.
<G-vec00380-002-s170><discard.ablegen><en> Discard cards from the encounter deck until a Wight enemy is discarded.
<G-vec00380-002-s171><discard.ablegen><de> Wenn aufgedeckt: Lege 1 Dorfbewohner-Marker für jeden Spieler im Spiel vom aktiven Ort ab.
<G-vec00380-002-s171><discard.ablegen><en> When Revealed: Discard 1 villager token from the active location for each player in the game.
<G-vec00380-002-s172><discard.ablegen><de> - Falls sich Agenda 2c im Spiel befindet, nimm 2 Horror und lege 2 Karten von deiner Hand ab.
<G-vec00380-002-s172><discard.ablegen><en> - If agenda 2c is in play, take 2 horror and discard 2 cards from your hand.
<G-vec00380-002-s173><discard.ablegen><de> Reaktion: Nachdem eine Gleiter- oder Raumjäger-Einheit, die du kommandierst, auf einen Angriffsschlag fokussiert worden ist, lege eine Ereignis karte von deiner Hand ab, damit die Einheit bis zum Ende des Angriffsschlags () erhält.
<G-vec00380-002-s173><discard.ablegen><en> 2x Set 259 Technologisches Reaction: After a Speeder or Fighter unit you control is focused to strike, discard an event card from your hand to have that unit gain () until the end of the strike.
<G-vec00380-002-s174><discard.ablegen><de> Reaktion: Nachdem der Held mit dieser Verstärkung erschöpft worden ist, um gegen einen Angriff zu verteidigen, lege die oberste Karte des Begegnungsdecks ab.
<G-vec00380-002-s174><discard.ablegen><en> Response: After attached hero exhausts to defend an attack, discard the top card of the encounter deck.
<G-vec00380-002-s175><discard.ablegen><de> Aufmarsch: Lege Narrow Sea aus dem Spiel ab, um die Kosten des nächsten - oder -Charakters, den du in dieser Phase spielst, um 2 zu reduzieren.
<G-vec00380-002-s175><discard.ablegen><en> 3x 028 in Marshalling: Discard Narrow Sea from play to reduce the cost of the next or character you play this phase by 2.
<G-vec00380-002-s036><shed.ablegen><de> Darüber hinaus umweht sogar die zugänglichsten LLC-Mitglieder ein Hauch von Adel, Erhabenheit und Einfluss, den sie nie vollständig ablegen können – ob es nun der Glaube ist, dass täglich jemand kommt, um die Kleidung zu reinigen, oder die in die Firmware verbaute Annahme, dass alle Wesen der unteren Klassen eliminiert werden müssen, damit der Wert des übrigen Universums steigt.
<G-vec00380-002-s036><shed.ablegen><en> On top of that, even the kindest of the LLC members have an air of aristocracy, entitlement, and affluence that cannot completely be shed; whether that means a daily assumption that someone is there to clean your dress, or firmware-held beliefs that all beings of lesser classes must be eliminated to raise the value of the remaining universe. Can you tell us about LLC’s abilities?
<G-vec00380-002-s037><shed.ablegen><de> Zuerst muss man seine jetzige Identität ablegen, um eine neue anzunehmen.
<G-vec00380-002-s037><shed.ablegen><en> You must firstly shed your current identity before adopting a new one,” he says.
<G-vec00380-002-s038><shed.ablegen><de> Wenn die Triebe der Petunien weiter wachsen, aber ihre Samenhülle nicht ablegen, müssen sie helfen.
<G-vec00380-002-s038><shed.ablegen><en> If the shoots of petunias continue to grow, but they do not shed their seed coat, they will have to help.
<G-vec00380-002-s039><shed.ablegen><de> Wann immer sie ihren physischen Körper ablegen und einen neuen bekommen, erinnern sie sich an die Beständigkeit ihres Ziels und an die Identität ihres Bewusstseinsfadens durch die Wiedergeburt hindurch.
<G-vec00380-002-s039><shed.ablegen><en> Whenever they shed their physical bodies and get new ones, they remember the continuity of their goal and the identity of their thread of consciousness throughout the reincarnations.
<G-vec00502-002-s019><lay.ablegen><de> Leider gibt es hier bei uns in Köln keine Bowie-Gedenkstätte, sonst würde ich die Karte dort ablegen.
<G-vec00502-002-s019><lay.ablegen><en> Unfortunately we do not have a Bowie memorial here in Cologne where I could lay down my card.
<G-vec00502-002-s020><lay.ablegen><de> "Deshalb nun, da wir eine so große Wolke von Zeugen um uns haben, lasst auch uns, indem wir jede Bürde und die leicht umstrickende Sünde ablegen, mit Ausharren laufen den vor uns liegenden Wettlauf, hinschauend auf Jesus, den Anfänger und Vollender des Glaubens, welcher, der Schande nicht achtend, für die vor Ihm liegende Freude das Kreuz erduldet und sich gesetzt hat zur Rechten des Thrones Gottes" (Verse 1–2).
<G-vec00502-002-s020><lay.ablegen><en> "Wherefore, seeing we also are compassed about with so great a cloud of witnesses, let us lay aside every weight, and the sin which doth so easily beset us, and let us run with patience the race that is set before us, looking unto Jesus, the Author and Finisher of faith; Who for the joy that was set before Him endured the cross, despising the shame, and is set down at the right hand of the throne of God."
<G-vec00502-002-s021><lay.ablegen><de> Sie können jedoch jedes Kartenblatt nur einmal ablegen.
<G-vec00502-002-s021><lay.ablegen><en> However, you can only lay each hand once.
<G-vec00502-002-s022><lay.ablegen><de> Wenn man die Summe auf genau 31 bringt, erhält man 2, wenn aber die Summe 30 oder weniger beträgt und kein Spieler eine Karte ablegen kann, ohne 31 zu überschreiten, erhält der letzte Spieler, der eine Karte gelegt hat, Einen fürs Passen oder Einen für die Letzte.
<G-vec00502-002-s022><lay.ablegen><en> Bringing the total to exactly 31 pegs 2, but if the total is 30 or less and neither player can lay a card without going over 31, then the last player to lay a card pegs one for the go or one for last.
<G-vec00502-002-s023><lay.ablegen><de> Wie Jesus mußt du die Oberbekleidung ablegen und dich mit Liebe gürten.
<G-vec00502-002-s023><lay.ablegen><en> Like Jesus, you must lay aside your outer garment and gird yourself with love.
<G-vec00502-002-s024><lay.ablegen><de> Am Strand schlüpfen Meeresschildkröten und gehen ins Meer, wo sie ein oder zwei Jahrzehnte lang Tausende von Kilometern zurücklegen, bevor sie wieder an denselben Strandabschnitt zurückschwimmen und ihre Eier ablegen.
<G-vec00502-002-s024><lay.ablegen><en> Green turtles hatch on the beach and go down to the sea where they travel thousands of miles for a decade or two before they retrace the path to that patch of beach and lay their eggs.
<G-vec00502-002-s025><lay.ablegen><de> Wer keine Karte ablegen kann oder will, muss stattdessen eine Karte vom Talon nehmen.
<G-vec00502-002-s025><lay.ablegen><en> If a player cannot or does not wish to lay a card, he/she must take one from the deck.
<G-vec00502-002-s026><lay.ablegen><de> Dem Strand vorgelagert ist die gleichnamige Insel, die jedoch nicht besucht werden darf und rund um die Uhr überwacht wird, um die Schildkröten zu schützen, die an ihrem Strand die Eier ablegen.
<G-vec00502-002-s026><lay.ablegen><en> In front of the beach there is the homonymous island, which unfortunately cannot be visited: its access is monitored 24/7 in order to protect the turtles that lay their eggs on the beach.
<G-vec00502-002-s027><lay.ablegen><de> Mit der Zeit ermüden die Muskeln, der Schüler darf das Buch wieder ablegen.
<G-vec00502-002-s027><lay.ablegen><en> Minute by minute the muscles tire, the pupil is allowed to lay down the book.
<G-vec00502-002-s028><lay.ablegen><de> Sprühe auf Leisten und Böden, wo Grillen normalerweise Eier ablegen.
<G-vec00502-002-s028><lay.ablegen><en> Spray along trim and baseboards, where crickets usually lay eggs.
<G-vec00502-002-s029><lay.ablegen><de> Mit diesem wunderbaren Häuschen finden Bienen ein Zuhause und in den hohlen Bambusröhren können weibliche Bienen mehrere Zeilen anlegen und ihre Eier ablegen.
<G-vec00502-002-s029><lay.ablegen><en> Unfortunately, bees are increasingly endangered. This wonderful little house offers hollow bamboo tubes to keep bees safe and offer a place to lay eggs for females.
<G-vec00502-002-s030><lay.ablegen><de> Grillen können im Haus Eier ablegen, wodurch der Befall schnell außer Kontrolle gerät.
<G-vec00502-002-s030><lay.ablegen><en> Crickets may lay eggs inside the home, which could cause the infestation to rapidly get out of control.
<G-vec00502-002-s031><lay.ablegen><de> 42:14 Wenn die Priester hineingegangen sind, sollen sie nicht aus dem Heiligtum in den äußern Vorhof hinaustreten, sondern sollen daselbst ihre Kleider, in denen sie gedient haben, ablegen, weil sie heilig sind, und sie sollen andere Kleider anziehen, um sich mit dem zu befassen, was das Volk angeht.
<G-vec00502-002-s031><lay.ablegen><en> 42:14 When the priests enter therein, then shall they not go out of the holy place into the utter court, but there they shall lay their garments wherein they minister; for they are holy; and shall put on other garments, and shall approach to those things which are for the people.
<G-vec00502-002-s032><lay.ablegen><de> Die Unterdruckleitung weiter rausziehen und auf dem Thermostat und Kühlwasserschlauch ablegen.
<G-vec00502-002-s032><lay.ablegen><en> Pull vacuum pipe further out and lay down on thermostat and radiator lower hose.
<G-vec00502-002-s033><lay.ablegen><de> Im Frühjahr treffen wir häufig auf Tintenfische, welche hier ihren Platz zum Eier ablegen suchen.
<G-vec00502-002-s033><lay.ablegen><en> In the springtime, you can often see octopuses that come here looking for a place to lay their eggs.
<G-vec00502-002-s034><lay.ablegen><de> Die Auswertung ergab, dass Fruchtfliegenweibchen ihre Eier bevorzugt auf Orangen ablegen.
<G-vec00502-002-s034><lay.ablegen><en> An analysis of the behavioural assays showed that female flies preferred to lay their eggs on oranges.
<G-vec00502-002-s035><lay.ablegen><de> So kann es in seinem Leben mehrere Eipakete ablegen und für immer mehr Nachkommen sorgen.
<G-vec00502-002-s035><lay.ablegen><en> In this way, she is able to lay a number of egg rafts, thereby ensuring more and more offspring.
<G-vec00503-002-s086><profess.ablegen><de> Ich bedanke mich auch bei euren Repräsentanten, die uns mit ihrem Zeugnis und mit einer sehr schönen kleinen Vorführung beschenkt haben, wie auch all denen, die daran mitgewirkt haben, dieses Treffen vorzubereiten, das im Jahr des Glaubens stattfindet, einem wichtigen Anlaß, um offen Zeugnis für den Glauben an Jesus, den Herrn, abzulegen.
<G-vec00503-002-s086><profess.ablegen><en> I am also grateful to your representatives, who have offered us their testimonies and a beautiful short performance, as well as those who helped prepare this meeting, set during the Year of Faith, an important occasion to openly profess our faith in the Lord Jesus.
<G-vec00555-002-s028><dismiss.ablegen><de> Du musst die Furcht vor der Konzentration ablegen.
<G-vec00555-002-s028><dismiss.ablegen><en> You must dismiss the fear of the concentration.
<G-vec00555-002-s019><lay_off.ablegen><de> Leider gibt es hier bei uns in Köln keine Bowie-Gedenkstätte, sonst würde ich die Karte dort ablegen.
<G-vec00555-002-s019><lay_off.ablegen><en> Unfortunately we do not have a Bowie memorial here in Cologne where I could lay down my card.
<G-vec00555-002-s020><lay_off.ablegen><de> "Deshalb nun, da wir eine so große Wolke von Zeugen um uns haben, lasst auch uns, indem wir jede Bürde und die leicht umstrickende Sünde ablegen, mit Ausharren laufen den vor uns liegenden Wettlauf, hinschauend auf Jesus, den Anfänger und Vollender des Glaubens, welcher, der Schande nicht achtend, für die vor Ihm liegende Freude das Kreuz erduldet und sich gesetzt hat zur Rechten des Thrones Gottes" (Verse 1–2).
<G-vec00555-002-s020><lay_off.ablegen><en> "Wherefore, seeing we also are compassed about with so great a cloud of witnesses, let us lay aside every weight, and the sin which doth so easily beset us, and let us run with patience the race that is set before us, looking unto Jesus, the Author and Finisher of faith; Who for the joy that was set before Him endured the cross, despising the shame, and is set down at the right hand of the throne of God."
<G-vec00555-002-s021><lay_off.ablegen><de> Sie können jedoch jedes Kartenblatt nur einmal ablegen.
<G-vec00555-002-s021><lay_off.ablegen><en> However, you can only lay each hand once.
<G-vec00555-002-s022><lay_off.ablegen><de> Wenn man die Summe auf genau 31 bringt, erhält man 2, wenn aber die Summe 30 oder weniger beträgt und kein Spieler eine Karte ablegen kann, ohne 31 zu überschreiten, erhält der letzte Spieler, der eine Karte gelegt hat, Einen fürs Passen oder Einen für die Letzte.
<G-vec00555-002-s022><lay_off.ablegen><en> Bringing the total to exactly 31 pegs 2, but if the total is 30 or less and neither player can lay a card without going over 31, then the last player to lay a card pegs one for the go or one for last.
<G-vec00555-002-s023><lay_off.ablegen><de> Wie Jesus mußt du die Oberbekleidung ablegen und dich mit Liebe gürten.
<G-vec00555-002-s023><lay_off.ablegen><en> Like Jesus, you must lay aside your outer garment and gird yourself with love.
<G-vec00555-002-s024><lay_off.ablegen><de> Am Strand schlüpfen Meeresschildkröten und gehen ins Meer, wo sie ein oder zwei Jahrzehnte lang Tausende von Kilometern zurücklegen, bevor sie wieder an denselben Strandabschnitt zurückschwimmen und ihre Eier ablegen.
<G-vec00555-002-s024><lay_off.ablegen><en> Green turtles hatch on the beach and go down to the sea where they travel thousands of miles for a decade or two before they retrace the path to that patch of beach and lay their eggs.
<G-vec00555-002-s025><lay_off.ablegen><de> Wer keine Karte ablegen kann oder will, muss stattdessen eine Karte vom Talon nehmen.
<G-vec00555-002-s025><lay_off.ablegen><en> If a player cannot or does not wish to lay a card, he/she must take one from the deck.
<G-vec00555-002-s026><lay_off.ablegen><de> Dem Strand vorgelagert ist die gleichnamige Insel, die jedoch nicht besucht werden darf und rund um die Uhr überwacht wird, um die Schildkröten zu schützen, die an ihrem Strand die Eier ablegen.
<G-vec00555-002-s026><lay_off.ablegen><en> In front of the beach there is the homonymous island, which unfortunately cannot be visited: its access is monitored 24/7 in order to protect the turtles that lay their eggs on the beach.
<G-vec00555-002-s027><lay_off.ablegen><de> Mit der Zeit ermüden die Muskeln, der Schüler darf das Buch wieder ablegen.
<G-vec00555-002-s027><lay_off.ablegen><en> Minute by minute the muscles tire, the pupil is allowed to lay down the book.
<G-vec00555-002-s028><lay_off.ablegen><de> Sprühe auf Leisten und Böden, wo Grillen normalerweise Eier ablegen.
<G-vec00555-002-s028><lay_off.ablegen><en> Spray along trim and baseboards, where crickets usually lay eggs.
<G-vec00555-002-s029><lay_off.ablegen><de> Mit diesem wunderbaren Häuschen finden Bienen ein Zuhause und in den hohlen Bambusröhren können weibliche Bienen mehrere Zeilen anlegen und ihre Eier ablegen.
<G-vec00555-002-s029><lay_off.ablegen><en> Unfortunately, bees are increasingly endangered. This wonderful little house offers hollow bamboo tubes to keep bees safe and offer a place to lay eggs for females.
<G-vec00555-002-s030><lay_off.ablegen><de> Grillen können im Haus Eier ablegen, wodurch der Befall schnell außer Kontrolle gerät.
<G-vec00555-002-s030><lay_off.ablegen><en> Crickets may lay eggs inside the home, which could cause the infestation to rapidly get out of control.
<G-vec00555-002-s031><lay_off.ablegen><de> 42:14 Wenn die Priester hineingegangen sind, sollen sie nicht aus dem Heiligtum in den äußern Vorhof hinaustreten, sondern sollen daselbst ihre Kleider, in denen sie gedient haben, ablegen, weil sie heilig sind, und sie sollen andere Kleider anziehen, um sich mit dem zu befassen, was das Volk angeht.
<G-vec00555-002-s031><lay_off.ablegen><en> 42:14 When the priests enter therein, then shall they not go out of the holy place into the utter court, but there they shall lay their garments wherein they minister; for they are holy; and shall put on other garments, and shall approach to those things which are for the people.
<G-vec00555-002-s032><lay_off.ablegen><de> Die Unterdruckleitung weiter rausziehen und auf dem Thermostat und Kühlwasserschlauch ablegen.
<G-vec00555-002-s032><lay_off.ablegen><en> Pull vacuum pipe further out and lay down on thermostat and radiator lower hose.
<G-vec00555-002-s033><lay_off.ablegen><de> Im Frühjahr treffen wir häufig auf Tintenfische, welche hier ihren Platz zum Eier ablegen suchen.
<G-vec00555-002-s033><lay_off.ablegen><en> In the springtime, you can often see octopuses that come here looking for a place to lay their eggs.
<G-vec00555-002-s034><lay_off.ablegen><de> Die Auswertung ergab, dass Fruchtfliegenweibchen ihre Eier bevorzugt auf Orangen ablegen.
<G-vec00555-002-s034><lay_off.ablegen><en> An analysis of the behavioural assays showed that female flies preferred to lay their eggs on oranges.
<G-vec00555-002-s035><lay_off.ablegen><de> So kann es in seinem Leben mehrere Eipakete ablegen und für immer mehr Nachkommen sorgen.
<G-vec00555-002-s035><lay_off.ablegen><en> In this way, she is able to lay a number of egg rafts, thereby ensuring more and more offspring.
<G-vec00561-002-s290><testify.ablegen><de> Da er sich Insider-Kenntnisse der internen Schriften von Scientology angeeignet hat, ist er bereit zu informieren und Zeugnis abzulegen.
<G-vec00561-002-s290><testify.ablegen><en> Having acquired an inside knowledge of the internal texts of the Scientology, he is ready to inform and to testify.
<G-vec00561-002-s291><testify.ablegen><de> Bei einer anderen Gelegenheit begannen Menschen für Christi Größe Zeugnis abzulegen, weil Jesus eine Reihe von großen Wundern vollbracht hatte.
<G-vec00561-002-s291><testify.ablegen><en> On another occasion, men started to testify of Christ’s greatness due to a series of outstanding miracles which he had performed.
<G-vec00595-002-s052><rid.ablegen><de> Er hat den Weg meiner Kultivierung beschattet und war schwer abzulegen.
<G-vec00595-002-s052><rid.ablegen><en> It shadowed the path of my cultivation practice and was hard to get rid of.
<G-vec00595-002-s053><rid.ablegen><de> Weil alles, was uns geschieht, nicht zufällig ist, sondern mit unseren Anschauungen zusammen hängt, werden uns Hinweise gegeben unsere Eigensinne abzulegen.
<G-vec00595-002-s053><rid.ablegen><en> Because whatever happens to us is not coincidental, it is related to our minds and warns us to get rid of our attachments.
<G-vec00595-002-s054><rid.ablegen><de> Um diesen Eigensinn abzulegen, entschied ich mich dieses „Angebot“ abzulehnen, auch wenn sie mich deswegen feuern würden.
<G-vec00595-002-s054><rid.ablegen><en> In order to get rid of my attachment, I decided not to accept the "buy out," even if I was fired.
<G-vec00595-002-s055><rid.ablegen><de> Es ist an der Zeit, seine eigenen Vorstellungen und Enttäuschungen aus der Vergangenheit abzulegen und sich dem Heiligen Geist in seiner souveränen Führung völlig hinzugeben, um Jesus Christus und den Vater, der ihn aus Liebe sandte, zu verherrlichen mit dem, was einem jeden zugeteilt ist.
<G-vec00595-002-s055><rid.ablegen><en> It is time to get rid of our own ideas and disappointments from the past and give ourselves fully to the Holy Spirit in His sovereign guidance in order to glorify Jesus Christ and the Father who sent Him out of love with what is assigned to each one of us.
<G-vec00595-002-s056><rid.ablegen><de> Einigen fällt es einfacher, diese Ängste schnell abzulegen und offen auf Andere zuzugehen.
<G-vec00595-002-s056><rid.ablegen><en> For some it is easy to rid themselves of their fear and approach others.
