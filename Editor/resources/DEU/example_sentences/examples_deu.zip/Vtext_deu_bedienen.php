<G-vec00301-001-s114><handle.bedienen><de> Koaxial-Rührwerke bedienen alle wichtigen Arbeitsvorgänge der Verfahrenstechnik.
<G-vec00301-001-s114><handle.bedienen><en> Co-axial mixers handle all main operations of process technology.
<G-vec00301-001-s115><handle.bedienen><de> Die Software ist flexibel, einfach zu bedienen und bietet uns 100%ige Datensicherheit.
<G-vec00301-001-s115><handle.bedienen><en> The software is flexible, easy to handle and offers us 100% data reliability.
<G-vec00301-001-s116><handle.bedienen><de> Der SlimPublisher ist eine Anwendung, die entwickelt wurde, um leicht zu bedienen zu sein, und damit sowohl erfahrenen als auch unerfahrenen Nutzern die Möglichkeit bietet, sie zu bedienen.
<G-vec00301-001-s116><handle.bedienen><en> SlimPublisher is an application that has been designed to be very easy-to-use, offering both experienced and inexperienced users the possibility to handle it.
<G-vec00301-001-s117><handle.bedienen><de> Bedienen Sie das Gerät nicht mit feuchten Händen.
<G-vec00301-001-s117><handle.bedienen><en> Do not handle unit with wet hands.
<G-vec00301-001-s118><handle.bedienen><de> Die Abstimmung ist sehr einfach zu bedienen, da nur zwei Kompoenten (C, L) zu verstellen sind.
<G-vec00301-001-s118><handle.bedienen><en> The tuning is very easy to handle because only two controls (C,L) have to be tuned.
<G-vec00301-001-s119><handle.bedienen><de> Und nicht zuletzt: Da mehr als 90 % unserer Kunden online kaufen (in unserer E-Boutique, die wir in 8 Sprachen bereitstellen, können unsere Kunden aus 7 Währungen und unterschiedlichen Zahlungsmethoden wählen), können wir sehr kosteneffizient einen schnell wachsenden Kundenstamm in der ganzen Welt bedienen (BAUNAT verkauft heute in mehr als 50 Ländern), ohne dass in viele Einzelhandelsgeschäfte und dementsprechende Fixkosten investiert werden muss.
<G-vec00301-001-s119><handle.bedienen><en> And last but not least: as more than 90% of our clients buy online (via our 8-lingual E-boutique, where clients can pay in 7 currencies and via a large variety of payment methods), we are able to handle very cost efficiently a fast growing customer base across the world (today BAUNAT sells to more than 50 countries), without having to invest in a large contingent of luxurious retail outlets and corresponding overheads.
<G-vec00301-001-s120><handle.bedienen><de> "Gutes User Interface Design kann beeindruckende Dinge erreichen, wenn es darum geht, Funktionalitäten auf einer Art und Weise zu ""verpacken"", die einfach zu bedienen ist, jedoch sollte man nicht erwarten, dass sich jedes User Interface auf drei Buttons reduzieren lässt."
<G-vec00301-001-s120><handle.bedienen><en> "A good user interface design can do impressive things in terms of ""packaging"" functionality in the way that is really easy to handle, but one should not expect that any interface can be reduced to three buttons."
<G-vec00301-001-s121><handle.bedienen><de> NIAB ist einfach zu bedienen, zuverlässig und pflegeleicht.
<G-vec00301-001-s121><handle.bedienen><en> FARMA tractor processor is simple to handle, is reliable and easy to service.
<G-vec00301-001-s122><handle.bedienen><de> Meine Boote dienen zur einfachen Vermietung ohne Skipper, da viele Gäste schon Ihren Führerschein besitzen und die Boote sehr einfach zu bedienen sind.
<G-vec00301-001-s122><handle.bedienen><en> The service that I offer is simple charters without skipper, because many people own a boat license, and our vessels are easy to handle.
<G-vec00301-001-s123><handle.bedienen><de> Leicht zu bedienen: Die DEUTZ Originalteile sind in Baugruppen logisch und übersichtlich zusammengefasst.
<G-vec00301-001-s123><handle.bedienen><en> Easy to handle: All parts and assemblies are presented in a clearly structured manner.
<G-vec00301-001-s124><handle.bedienen><de> Wir sind nicht nur Teil davon, wir können uns dessen auch bedienen.
<G-vec00301-001-s124><handle.bedienen><en> We are not only in it, but we can handle it.
<G-vec00301-001-s125><handle.bedienen><de> Wir zeigen Ihnen dabei nicht nur wie Sie die KE-Medical® Hair & Skin richtig bedienen und auf die jeweilige Behandlungsart einstellen, sondern wir geben auch unsere langjährige Erfahrung in Theorie- und Praxiskursen an Sie weiter.
<G-vec00301-001-s125><handle.bedienen><en> We will not only show you how to correctly handle your new KE-Medical Hair & Skin in any treatment situation, we as well will pass on our long-term experience in theoretical and practical sessions.
<G-vec00301-001-s126><handle.bedienen><de> The Tube lässt sich kinderleicht in nur einem einzigen Programmfenster bedienen und sollte zusammen mit dem stylischen TubeStick TV-Empfänger auf keinem Mac fehlen.
<G-vec00301-001-s126><handle.bedienen><en> In just one window, The Tube is very easy to handle and together with the stylish TV receiver TubeStick, it's a must-have for every Mac.
<G-vec00301-001-s127><handle.bedienen><de> Das Wichtigste ist, dass MaxClients gross genug ist, so viele gleichzeitige Anfragen zu bedienen, wie Sie erwarten, aber klein genug, um sicherzustellen, dass genug physischer Arbeitsspeicher für alle Prozesse vorhanden ist.
<G-vec00301-001-s127><handle.bedienen><en> Most important is that MaxClients be big enough to handle as many simultaneous requests as you expect to receive, but small enough to assure that there is enough physical RAM for all processes.
<G-vec00301-001-s128><handle.bedienen><de> "Wurde noch um 1980 ein Panasonic DR 28 oder Grundig Satellit 1400 als Reiseempfänger beworben, ""der am Handgriff leicht getragen werden kann und unter einem Flugzeugsitz verstaut werden kann"", so braucht der Benutzer der modernsten kaum mehr als streichholzschachtel-grossen Reiseradios spitze Finger, um die kleinen Tasten bedienen zu können."
<G-vec00301-001-s128><handle.bedienen><en> "Even in 1980 a Panasonic DR 28 or Grundig satellite 1400 have been advertised as travel radios, "" can be easily carried by the big handle and can be safely stored under Your airplane seat... "" Nowadays, the user of the miniature worldband radios, hardly bigger than a matchbox, needs pointed fingers, to press the miniature buttons and switches."
<G-vec00301-001-s129><handle.bedienen><de> Großes Display, leicht zu bedienen.
<G-vec00301-001-s129><handle.bedienen><en> Big screen that's easy to handle.
<G-vec00301-001-s130><handle.bedienen><de> Dafür ist das Gerät sehr einfach zu bedienen: Selbst unerfahrene Anwender können beim Scannen mit dem MemoScan nichts falsch machen.
<G-vec00301-001-s130><handle.bedienen><en> But therefore, the device is very easy to handle: even unexperienced users cannot be wrong during the scanning with MemoScan.
<G-vec00301-001-s131><handle.bedienen><de> Angenehm zu tragen, leicht zu bedienen und schnell wiederaufladbar: Die Kopflampe HL250SU ist die zuverlässige mobile Lichtquelle mit vielfältigen Einsatzmöglichkeiten.
<G-vec00301-001-s131><handle.bedienen><en> Comfortable to wear, easy to handle and quickly recharged: The headlamp HL250SU is the reliable mobile light source with versatile application possibilities.
<G-vec00301-001-s132><handle.bedienen><de> Das QTranslate-X-Plugin ist kostenlos und einfach zu bedienen.
<G-vec00301-001-s132><handle.bedienen><en> QTranslate-X-Plugin ist for free and easy to handle.
<G-vec00591-001-s027><use.bedienen><de> Es ist verboten, virtuelle Kamera Geräte vor Ort zu bedienen und es ist schwieriger, von Chat als anderen Websites nicht autorisiert zu bekommen.
<G-vec00591-001-s027><use.bedienen><en> It is prohibited to use virtual camera devices on site and it is more difficult to get unauthorized from Chatroulette than other sites.
<G-vec00591-001-s028><use.bedienen><de> Im Anwendertraining lernt der Kunde, das System zu bedienen und seine Prozesse bestmöglich zu automatisieren.
<G-vec00591-001-s028><use.bedienen><en> During user training, the client learns how to use the system and how to automate processes in the best possible way.
<G-vec00591-001-s029><use.bedienen><de> Das Gerät ist sehr einfach zu bedienen.
<G-vec00591-001-s029><use.bedienen><en> The device is extremely easy to use.
<G-vec00591-001-s030><use.bedienen><de> Holen Sie sich den Betrag, den Sie wollen Crystals – Gold – Essen, Sie müssen nur unsere Hack Dragons Welt verwenden, Wir überlassen es eine Taste nach oben, nur drücken müssen, um sie und folgen Sie den Anweisungen, Es ist sehr einfach zu bedienen und ist gültig für iOS und Android.
<G-vec00591-001-s030><use.bedienen><en> Get the amount you want Crystals – Gold – Food, you just have to use our hack Dragons World, We leave it up to a button, only have to press it and follow the instructions, It is very easy to use and is valid for iOS and Android.
<G-vec00591-001-s031><use.bedienen><de> Das Gerät ist zu bedienen, wie ein kleines Profi-Studio-Setup, klingt gut und ist durchaus bezahlbar.
<G-vec00591-001-s031><use.bedienen><en> You can use the unit as a small professional studio setup, it sounds great and is quite affordable.
<G-vec00591-001-s032><use.bedienen><de> Frauen-Winter Hüte werden von vielen geschätztGründe, sie schützt nicht nur den Kopf vor Kälte und Wind, sondern auch gut aussehen, einfach zu bedienen und zu betreiben.
<G-vec00591-001-s032><use.bedienen><en> Women winter hats are appreciated by manyreasons, they are not only protect your head from the cold and wind, but also look good, easy to use and to operate.
<G-vec00591-001-s033><use.bedienen><de> Aus diesem Grund, Neulinge oft diese Software einfach zu bedienen und problemlos.
<G-vec00591-001-s033><use.bedienen><en> For this reason, newbies often find this software easy to use and hassle-free.
<G-vec00591-001-s034><use.bedienen><de> Teilweise bedienen wir uns zur Verarbeitung Ihrer Daten externer Dienstleister.
<G-vec00591-001-s034><use.bedienen><en> We also use external service providers for processing some of your data.
<G-vec00591-001-s035><use.bedienen><de> Der seca 878 ist leicht, extrem robust und einfach zu bedienen.
<G-vec00591-001-s035><use.bedienen><en> The seca 878 has a lightweight, extremely robust construction and is easy to use.
<G-vec00221-002-s133><operate.bedienen><de> Die Kamera Niceboy VEGA 6 star wird mittels Applikation im Mobiltelefon dank dem eingebauten Wi-Fi Modul leicht bedient.
<G-vec00221-002-s133><operate.bedienen><en> You can easily operate the Niceboy VEGA 6 star camcorder using an app on your mobile phone thanks to the built-in Wi-Fi module.
<G-vec00221-002-s134><operate.bedienen><de> “Ryanair freut sich, die neue Strecke von Memmingen nach Tel Aviv zu verkünden, die im Rahmen des Winterflugplans ab Oktober 2018 zwei Mal wöchentlich bedient wird.
<G-vec00221-002-s134><operate.bedienen><en> “Ryanair is pleased to announce a new Cardiff route to Malta, commencing in April 2019, which will operate twice weekly as part of our Summer 2019 schedule.
<G-vec00221-002-s135><operate.bedienen><de> Alles war rund, sympathisch, man hat die Geräte haptisch gerne bedient, am Sendersuchlauf des Radios gedreht, den es in dieser Zeit noch gab.
<G-vec00221-002-s135><operate.bedienen><en> Everything was round, pleasant and people liked to touch and operate the devices like turning the station scan of the radio, which still existed then.
<G-vec00221-002-s136><operate.bedienen><de> Die Klimageräte werden mit dem Standard-Webbrowser Microsoft Internet Explorer (ab Version 5) bequem vom PC, der an das lokale Netzwerk angeschlossen ist, aus bedient.
<G-vec00221-002-s136><operate.bedienen><en> Conveniently operate the air conditioning units from your PC, connected to the local network, using the standard Microsoft Internet Explorer web browser (version 5).
<G-vec00221-002-s137><operate.bedienen><de> Ob Massivholz- oder Holzwerkstoffbearbeitung - um die Leistungskraft Ihrer neuen Maschine voll auszuschöpfen, muss sie perfekt bedient werden.
<G-vec00221-002-s137><operate.bedienen><en> Whether solid wood or panel processing, to fully exploit your new machine's performance power, you must be able to operate it to perfection.
<G-vec00221-002-s138><operate.bedienen><de> Die beiden kalifornischen Destinationen San Francisco und Los Angeles werden ab Mai von Berlin-Tegel aus mit drei beziehungsweise vier Nonstopflügen pro Woche bedient.
<G-vec00221-002-s138><operate.bedienen><en> The two Californian destinations of San Francisco and Los Angeles will operate from Berlin Tegel with three or four non-stop flights a week from May.
<G-vec00221-002-s139><operate.bedienen><de> Bedient zahlreiche neue Maschinen aus dem Sortiment von HORSCH, inklusive unverkäuflicher Einzelstücke und Prototypen, die ihr so noch nie zuvor auf einem Feld gesehen habt.
<G-vec00221-002-s139><operate.bedienen><en> Operate numerous new machines from HORSCH's range, including one-off productions and prototypes that you have never seen before.
<G-vec00221-002-s140><operate.bedienen><de> PureBallast 3 ist auf Benutzerfreundlichkeit ausgelegt, so dass die Besatzungen schnell lernen können, wie man das System bedient und wartet.
<G-vec00221-002-s140><operate.bedienen><en> designed for ease of use so crews can quickly learn how to operate and maintain the system.
<G-vec00221-002-s142><operate.bedienen><de> Unsere Vollluftfederungssysteme werden mit einem funktionsstarken Bediengerät ausgeliefert, mit dem alle Funktionen des Fahrwerksystems einfach bedient werden können.
<G-vec00221-002-s142><operate.bedienen><en> Our full air suspension systems are supplied with a sophisticated remote control that can be used to easily operate all functions of the suspension system.
<G-vec00221-002-s143><operate.bedienen><de> Bedient wird die Videowand über 20″ Widescreen- Touchpanel von Crestron.
<G-vec00221-002-s143><operate.bedienen><en> A 20” Crestron widescreen touch panel is used to operate the video wall.
<G-vec00221-002-s144><operate.bedienen><de> Bedient den Argonendetektor, der beim Feldlager des Irrsinns aufgestellt wurde.
<G-vec00221-002-s144><operate.bedienen><en> Operate the argon detector placed near Field Base Lunacy.
<G-vec00221-002-s145><operate.bedienen><de> Battenberg Messrobotic bedient Schalter, Drehsteller oder misst den Komfort von Flugzeugsitzen und Flugzeugtüren.
<G-vec00221-002-s145><operate.bedienen><en> Battenberg robotic measuring operate switches, turn keys or measures aircraft seats comfort and aircraft doors handling.
<G-vec00221-002-s146><operate.bedienen><de> Darüber hinaus wird das iPhone mit vier Tasten und einem Schiebeschalter bedient.
<G-vec00221-002-s146><operate.bedienen><en> In addition, the iPhone will operate with four buttons and a slider switch.
<G-vec00221-002-s147><operate.bedienen><de> Man kann also nicht plötzlich entscheiden 'oh, ich möchte jetzt etwas Waterhash herstellen', sondern man muss immer einen geeigneten Mixer finden, der in diesem Kontext sicher bedient werden kann.
<G-vec00221-002-s147><operate.bedienen><en> So you can't just suddenly decide 'oh, I think I want to make some water hash', but must always first find yourself a suitable mixer that will operate safely in this context.
<G-vec00221-002-s148><operate.bedienen><de> Die telefonische Rechtsauskunft wird durch Rechtsanwalt Daniel Bohren persönlich erteilt und ist daher nicht immer bedient.
<G-vec00221-002-s148><operate.bedienen><en> The telephone-based legal information service is provided by the lawyer Daniel Bohren personally and does not therefore operate at all times.
<G-vec00221-002-s149><operate.bedienen><de> Ab 2022 sollen drei Randgebiete der Stadt außerhalb der Stosszeiten mit ersten selbstfahrenden Bussen bedient werden.
<G-vec00221-002-s149><operate.bedienen><en> And plans are already in place to operate the first self- driving buses outside rush hours in three of the city’s suburbs starting in 2022.
<G-vec00221-002-s150><operate.bedienen><de> Unser weltgrößtes Publisher Netzwerk bedient mehr als viermal so viele Advertiser wie unser nächstgrößter Konkurrent.
<G-vec00221-002-s150><operate.bedienen><en> We operate the world’s largest publisher network with more than four times as many advertisers as our closest competitor.
<G-vec00221-002-s151><operate.bedienen><de> Per Infrarot-Sensor werden sie kinderleicht bedient.
<G-vec00221-002-s151><operate.bedienen><en> And – they are easy to operate via infrared sensor.
<G-vec00221-002-s057><serve.bedienen><de> Die Herausforderung liegt darin, alle Kunden möglichst schnell und effizient zu bedienen, damit sie Deinen Laden nicht unzufrieden verlassen.
<G-vec00221-002-s057><serve.bedienen><en> The challenge is to serve food to all your customers quickly and efficiently to keep them from walking out dissatisfied.
<G-vec00221-002-s058><serve.bedienen><de> Wir streben danach, unser Produkt- und Partnerschafts-Ökosystem zu erweitern, um Unternehmen jeder Größe zu bedienen.
<G-vec00221-002-s058><serve.bedienen><en> We aspire to extend our product and partnership ecosystem to serve companies of all sizes.
<G-vec00221-002-s059><serve.bedienen><de> 2013 entschied sich Carrefour, seine Geschäftstätigkeit auszuweiten und die vorhandenen Märkte zu modernisieren, um die Kunden besser bedienen zu können.
<G-vec00221-002-s059><serve.bedienen><en> In 2013, to better serve its customers, Carrefour Group decided to modernize its facilities and expand operations.
<G-vec00221-002-s060><serve.bedienen><de> Um Sie besser bedienen zu können, verwendet diese Website cookies.
<G-vec00221-002-s060><serve.bedienen><en> In order to serve you better, this website makes use of cookies.
<G-vec00221-002-s061><serve.bedienen><de> Zunächst soll Pier G 4-5 Millionen Passagiere bedienen, und nach Fertigstellung des gesamten Terminals 3 kann die Anzahl der Passagiere auf 6-7 Millionen steigen.
<G-vec00221-002-s061><serve.bedienen><en> According to plans, Pier G will initially serve 4 to 5 million passengers, and, following the completion of the entire Terminal 3, the number of passengers is expected to increase up to 6-7 million.
<G-vec00221-002-s062><serve.bedienen><de> Nachdem der Vorgänger getrennt für AMD und Intel erschien, kann der Freezer 33 nun beide Hersteller bedienen.
<G-vec00221-002-s062><serve.bedienen><en> After the predecessor appeared separately for AMD and Intel, the Freezer 33 now can serve both manufacturers.
<G-vec00221-002-s063><serve.bedienen><de> Mit dem weltweiten Vertriebsnetz, wie auch mit dem schon seit 2001 erfolgreich eingeführten E-Commerce, ist der Konzern bestens aufgestellt, um die Kunden, wo auch immer sie sich auf der Welt befinden, jederzeit bedienen zu können.
<G-vec00221-002-s063><serve.bedienen><en> With its global distribution network and the successful introduction of E-Commerce already in 2001, the Group is in an excellent position to serve its customers, wherever they are in the world, at any time.
<G-vec00221-002-s064><serve.bedienen><de> Darüber hinaus intensivieren Audi und FAW die Zusammenarbeit bei Finanzdienstleistungen, um die stark steigende Nachfrage der Audi-Kunden in diesem Bereich umfassend bedienen zu können.
<G-vec00221-002-s064><serve.bedienen><en> Furthermore Audi and FAW will intensify their collaboration in financial services aiming to serve the rapidly growing demand from Audi customers in this field.
<G-vec00221-002-s065><serve.bedienen><de> Wir wünschen Ihnen einen schwungvollen Start und freuen uns, Sie auch im neuen Jahr wieder königlich zu bedienen.
<G-vec00221-002-s065><serve.bedienen><en> We wish you a happy new year and we are looking forward to still serve you kinglike in 2017.
<G-vec00221-002-s066><serve.bedienen><de> Im heutigen, schnellebigen wirtschaftlichen Umfeld kommt es Ihnen mehr denn je auf eine schnelle, unkomplizierte und zuverlässige Lieferung der benötigten Sortimente an; eben um genauso kurzfristig Ihre Abnehmer zu bedienen und Ihr Umlaufvermögen so gering wie möglich zu halten.
<G-vec00221-002-s066><serve.bedienen><en> In today’s fast-moving economic environment a fast, uncomplicated and reliable delivery of the required product ranges is more than ever important to you; just to serve your customers in the same short way, and to maintain your current assets as low as possible.
<G-vec00221-002-s067><serve.bedienen><de> Um Ihre Support-Anfragen zu optimieren und im Dialog bedienen zu können, nutzen wir dieses Support-Ticket-System über das Internet (hotline.dicvrs.de).
<G-vec00221-002-s067><serve.bedienen><en> Dear customer, in order to streamline support requests and better serve you, we utilize a support ticket system.
<G-vec00221-002-s068><serve.bedienen><de> Kontakt Impressum Das Ziel unserer Nachhaltigkeitskommunikation ist es, die Interessen verschiedener Anspruchsgruppen zu bedienen und dabei eine transparente und vergleichbare Berichterstattung zu gewährleisten.
<G-vec00221-002-s068><serve.bedienen><en> Our sustainability-related communication aims to serve the interests of different target groups, all the while ensuring transparent reporting that can be used as a basis of comparison.
<G-vec00221-002-s069><serve.bedienen><de> Um die schnell wachsenden Märkte in Asien besser bedienen zu können, wird in Singapur ein neues Vertriebsbüro eröffnet.
<G-vec00221-002-s069><serve.bedienen><en> A new office was established in Singapore to better serve the growing markets in Asia.
<G-vec00221-002-s070><serve.bedienen><de> Wir bedienen den wachsenden Markt für große Gaskraftwerke mit einer Kapazität bis zu 250 Megawatt ebenso wie Industrieunternehmen mit Interesse an Eigenstromerzeugung, und natürlich bieten wir auch Lösungen für den Combined-Cycle-Betrieb in Verbindung mit einer Dampfturbine an.
<G-vec00221-002-s070><serve.bedienen><en> No matter which challenge faced in energy generation, we have the engine and power solution to tackle it. We are ideally placed to serve the growing market for gas engine-operated power plants, for power outputs of up to 250 Megawatts for grid connected power or captive power applications.
<G-vec00221-002-s071><serve.bedienen><de> Lebensmittelproduzenten stehen vor der Herausforderung, diese Interessen zu bedienen und zu garantieren, dass die Produkte auch tatsächlich den Anforderungen entsprechen.
<G-vec00221-002-s071><serve.bedienen><en> Food producers are facing the challenge to serve these interests and to guarantee that the products actually meet the requirements.
<G-vec00221-002-s072><serve.bedienen><de> Um diesen Volumenmarkt zu bedienen, befinden sich bei allen OEMs neue Hybrid- und Elektromodelle in der Entwicklung.
<G-vec00221-002-s072><serve.bedienen><en> To serve this high-volume market, all OEMs are developing new hybrid and electric models.
<G-vec00221-002-s073><serve.bedienen><de> Die Nischen- und feministischen Produktionen bedienen eher ein kleineres Publikum und bezahlen auch geringere Honorare.
<G-vec00221-002-s073><serve.bedienen><en> Niche queer and feminist productions tend to serve smaller audiences and pay less, too.
<G-vec00221-002-s074><serve.bedienen><de> Mit unserem breiten Portfolio bedienen wir regionale und überregionale Kunden.
<G-vec00221-002-s074><serve.bedienen><en> Our wide portfolio of products helps us to serve both regional and international customers.
<G-vec00221-002-s075><serve.bedienen><de> In der kleinen BAR können Sie sich selbst bedienen.
<G-vec00221-002-s075><serve.bedienen><en> In the small bar you can serve yourself.
<G-vec00245-002-s171><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit FACTORYPATH-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s171><appear.bedienen><en> In order to do it, you should double-click a MININCSF file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s172><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit UFF-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s172><appear.bedienen><en> In order to do it, you should double-click a KNF file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s173><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit PTG-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s173><appear.bedienen><en> In order to do it, you should double-click a PTG file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s174><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit CBL-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s174><appear.bedienen><en> In order to do it, you should double-click a COS file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s175><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit BPS-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s175><appear.bedienen><en> In order to do it, you should double-click a DIC file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s176><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit FOUNTAIN-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s176><appear.bedienen><en> In order to do it, you should double-click a DLL_RESP file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s177><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit CXX-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s177><appear.bedienen><en> In order to do it, you should double-click a CXX file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s178><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit AC4-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s178><appear.bedienen><en> In order to do it, you should double-click a AC4 file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s179><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit BSR-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s179><appear.bedienen><en> In order to do it, you should double-click a BKO file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s180><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit SPPACK-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s180><appear.bedienen><en> In order to do it, you should double-click a MXMF file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s181><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit RGSS2A-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s181><appear.bedienen><en> In order to do it, you should double-click a LSW file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s182><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit PBXSCRIPT-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s182><appear.bedienen><en> In order to do it, you should double-click a PBXSCRIPT file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s183><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit FLX-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s183><appear.bedienen><en> In order to do it, you should double-click a MIFF file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s184><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit HPG-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s184><appear.bedienen><en> In order to do it, you should double-click a HPG file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s185><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit CHV-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s185><appear.bedienen><en> In order to do it, you should double-click a SUI file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s186><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit BWZ-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s186><appear.bedienen><en> In order to do it, you should double-click a DSK file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s187><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit FIT-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s187><appear.bedienen><en> In order to do it, you should double-click a FIT file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s188><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit RTU-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s188><appear.bedienen><en> In order to do it, you should double-click a RTU file icon. A list of programs that probably support such a file will appear.
<G-vec00245-002-s189><appear.bedienen><de> Dazu soll man zweimal das Piktogramm mit WMLC-Datei klicken, es erscheint die Liste der Programme, die diese Datei bedienen.
<G-vec00245-002-s189><appear.bedienen><en> In order to do it, you should double-click a FAG file icon. A list of programs that probably support such a file will appear.
<G-vec00254-002-s047><manipulate.bedienen><de> Wie wir die Funktionsweisen der technischen Apparate, die wir bedienen und die uns bedienen, übernehmen, so übernehmen die Apparate unsere Skills, unsere Technik, unser Wissen.
<G-vec00254-002-s047><manipulate.bedienen><en> The way that we assume the functionality of technological devices that we manipulate and that manipulate us, so do the devices take over our skills, our technique, our knowledge.
<G-vec00254-002-s049><manipulate.bedienen><de> Sean McNally, Filmvorführer und Video Systems-Techniker des Kennedy Centers, erklärt, „Wir konnten viel Zeit und Mühe dadurch sparen, dass die Projektoren dank ihres leichten Gewichts einfach zu bedienen sind.
<G-vec00254-002-s049><manipulate.bedienen><en> Said Sean McNally, Projectionist & Video Systems Technician at The Kennedy Center: "It saved a lot of time and hassle to be able to manipulate the projectors easily due to their light weight."
<G-vec00254-002-s050><manipulate.bedienen><de> Der Lenker imitiert den Rennsport, der für jedes Alter leicht zu bedienen ist.
<G-vec00254-002-s050><manipulate.bedienen><en> The handlebar imitates the racing type which is easy to manipulate for any ages.
<G-vec00298-002-s019><widen.bedienen><de> Seit der Einführung der 4-Zoll-Rindergüllepumpen in den 1990er Jahren können wir auch den Markt der Milchbetriebe bedienen.
<G-vec00298-002-s019><widen.bedienen><en> In the 90’s, the introduction of the 4" Dairy Liquid Manure pumps allowed to widen the market by including dairy producers.
<G-vec00301-002-s114><handle.bedienen><de> ITE-Modelle sind für Personen mit eingeschränkter Fingerfertigkeit leichter zu bedienen, denn sie bieten größere Steuerelemente wie etwa ein Rad für die Lautstärkeregelung.
<G-vec00301-002-s114><handle.bedienen><en> ITE styles are easier to handle for people who face dexterity challenges, offering larger controls such as a wheel to adjust the volume.
<G-vec00301-002-s115><handle.bedienen><de> QF-Test unterstützt bei Web-Tests zusätzliche Browser (Internet Explorer, Edge, Safari, Chrome… auch 64bit) und ist für Tester einfacher zu bedienen.
<G-vec00301-002-s115><handle.bedienen><en> QF-Test further more supports additional browsers for web tests (Internet Explorer, Edge, Safari, Chrome... also 64bit) and is easier to handle for testers.
<G-vec00301-002-s116><handle.bedienen><de> Das Konzept von Funny-World sind Attraktionen, die Sie selbst bedienen.
<G-vec00301-002-s116><handle.bedienen><en> The concept of Funny World is based on attractions you handle yourself.
<G-vec00301-002-s117><handle.bedienen><de> Die Leyard TWS-Reihe ist federleicht und einfach zu bedienen, was sie besonders attraktiv für facettierte, gewölbte Videowände, hängende Videowände und traditionelle Videowände macht, für die eine kompakte Fine-Pitch-Lösung erforderlich ist.
<G-vec00301-002-s117><handle.bedienen><en> The display’s light weight makes it easy to handle, offering an attractive solution for faceted curved video walls, hanging video walls or standard video wall environments that require a compact, fine pixel pitch solution.
<G-vec00301-002-s118><handle.bedienen><de> Nicht ohne Bedeutung ist die Anlagepolitik des Seehäfenvorstand Stettin und Swinemünde SA, die unter Berücksichtigung die Notwendigkeit sieht, dass die Hafenanlagen angepasst sein müssen, um größere Schiffe im Hafen zu bedienen.
<G-vec00301-002-s118><handle.bedienen><en> Not without significance is the investment policy of the Szczecin and Swinoujscie Seaports Authority that takes into account the need of adapting port infrastructure to handle larger vessels by the port of Szczecin.
<G-vec00301-002-s119><handle.bedienen><de> Das Modell Lumia 730 Dual SIM bedient 3G-Netz und wird nur in einer Dual-SIM-Version zugänglich, dagegen wird das Lumia 735 das schnellste 4G/LTE-Mobilenetz bedienen.
<G-vec00301-002-s119><handle.bedienen><en> The model Lumia 730 Dual SIM supports 3G network and will be available only in Dual SIM, while the Lumia 735 will handle the fastest cellular network 4G / LTE.
<G-vec00301-002-s120><handle.bedienen><de> Die Maschine ist einfach zu bedienen, verfügt über moderne Technik mit elektronischer Steuerung und passert automatisch.
<G-vec00301-002-s120><handle.bedienen><en> The machine is easy to handle; it is laid out with state-of-the-art technique and with automatic registration.
<G-vec00301-002-s121><handle.bedienen><de> Es ist sehr einfach zu bedienen, aber manche seiner Funktionen erfordert erweiterte Computerkenntnisse, um sie richtig ausnutzen zu können.
<G-vec00301-002-s121><handle.bedienen><en> It isn't specially difficult to handle, but some of its functions require advanced computing knowledge to be able to make the most of them.
<G-vec00301-002-s122><handle.bedienen><de> Der Touchscreen der Kamera ist sogar im Liegen ganz einfach zu bedienen, sagt er.
<G-vec00301-002-s122><handle.bedienen><en> The camera's touchscreen made it easy to handle even when lying down, he says.
<G-vec00301-002-s123><handle.bedienen><de> SOBACO PAS ist flexibel, schnell zu erlernen und einfach zu bedienen und wird laufend den aktuellen technischen und funktionalen Anforderungen angepasst.
<G-vec00301-002-s123><handle.bedienen><en> SOBACO PAS is flexible, easy to learn and easy to handle. It is continuously updated to keep up with the steadily changing technical and functional requirements.
<G-vec00301-002-s124><handle.bedienen><de> Diese sind in beiden Maschinen fest einprogrammiert, sodass jeder Mitarbeiter in der Lage ist, die Maschinen zu bedienen.
<G-vec00301-002-s124><handle.bedienen><en> These are programed into the machines so that every employee of BHS can easily handle them.
<G-vec00301-002-s125><handle.bedienen><de> WSP-2A ist eine automatische Kaffeemaschine, die sehr einfach zu bedienen ist, damit jeder den perfekten Kaffee brühen kann.
<G-vec00301-002-s125><handle.bedienen><en> The WSP-2A is an automatic coffee maker that is very easy to handle so that anyone can brew the perfect coffee.
<G-vec00301-002-s126><handle.bedienen><de> Kalmars ASCs können mithilfe unseres automatisierten Systems zur Staplerbedienung angebracht werden, das es Ihnen erlaubt, Stapler und Kassetten von einer Länge bis zu 4 TEU zu bedienen.
<G-vec00301-002-s126><handle.bedienen><en> Automated truck handling Kalmar ASCs can be fitted with our automated truck handling system, which allows you to handle trucks and cassettes up to 4 TEU long.
<G-vec00301-002-s127><handle.bedienen><de> Und nach dem Vergleich der detaillierten Schritte ist es offensichtlich, dass der Filmora Video Editor einfacher zu bedienen ist.
<G-vec00301-002-s127><handle.bedienen><en> And after comparing the detailed steps, it is not hard to find the Filmora Video Editor is more easier to handle.
<G-vec00301-002-s129><handle.bedienen><de> Als der Markt wuchs und sich vergrößerte und die technologische Entwicklung fortschritt, brauchten die Fluggesellschaften eine Lösung, um die wachsende Anzahl von Kunden bedienen zu können.
<G-vec00301-002-s129><handle.bedienen><en> As the market grew and scaled up and technological development kicked in the airlines were in need for a technological solution to handle the growing amount of customers.
<G-vec00301-002-s130><handle.bedienen><de> Danach können Sie auch Dateien umbenennen in einem Tastendruck.Der integrierte Player ermöglicht Ihnen, Ihre Musik-Sammlung bedienen und Wiedergabelisten zu erstellen, ohne dabei die Aufmerksamkeit auf andere Anwendungen.
<G-vec00301-002-s130><handle.bedienen><en> Afterwards, you can even rename files in one keystroke. The built-in player enables you to handle your music collection and create playlists without moving your attention to other applications.
<G-vec00301-002-s131><handle.bedienen><de> Fahrradverleih Das Tourinform Büro verleiht Fahrräder für Stunden oder einen ganzen Tag, die bequem und leicht zu bedienen sind.
<G-vec00301-002-s131><handle.bedienen><en> The Tourinform office rents out its comfortable, easy to handle bikes for a couple of hours or for an entire day.
<G-vec00301-002-s132><handle.bedienen><de> Es benötigt 1-2 Personen, um die Maschine zu bedienen.
<G-vec00301-002-s132><handle.bedienen><en> It needs 1-2 persons to handle the machine.
<G-vec00369-002-s100><employ.bedienen><de> Letztlich kann man sagen, dass Hedgefonds in traditionelle Asset Klassen (wie Aktien und Anleihen) investieren, sie bedienen sich jedoch alternativer Strategien.
<G-vec00369-002-s100><employ.bedienen><en> Summarizing Hedge Funds invest into traditional asset classes (like shares and bonds) but employ alternative strategies. Leverage Leverage
<G-vec00369-002-s101><employ.bedienen><de> Sie bieten OpenVPN- und L2TP-Protokolle, die sich eines 256-Bit-Verschlüsselungsstandards bedienen.
<G-vec00369-002-s101><employ.bedienen><en> They have OpenVPN and L2TP protocols that employ 256-bit encryption standards.
<G-vec00369-002-s102><employ.bedienen><de> Teilweise bedienen wir uns der Verarbeitung Ihrer Daten externer Dienstleister.
<G-vec00369-002-s102><employ.bedienen><en> In some cases we employ external service providers for the processing of your data.
<G-vec00369-002-s103><employ.bedienen><de> Zur Optimierung des Übersetzungsprozesses bedienen wir uns modernster Techniken.
<G-vec00369-002-s103><employ.bedienen><en> We employ state-of-the-art techniques to optimise the translation process.
<G-vec00369-002-s104><employ.bedienen><de> Dabei bedienen sie sich schweizerischer Mittelsmänner, mit Vorliebe bekannter und einflussreicher Politiker wie Altbundesräte und kantonaler Bildungsdirektoren, die in der Öffentlichkeit nicht nur ein gewisses Ansehen, sondern auch Insiderwissen über die speziellen politischen Mechanismen in der Schweiz sowie ein hochrangiges Netzwerk haben.
<G-vec00369-002-s104><employ.bedienen><en> They employ Swiss middlemen to do so, preferably well-known and influential politicians such as former Federal Councillors or cantonal Heads of the Departement of Education, who not only have a certain reputation but also have insider knowledge of the specific policy mechanisms in Switzerland as well as a high-level network.
<G-vec00369-002-s105><employ.bedienen><de> Die Künstler, die in der Ausstellung präsentiert werden, setzen sich mit der inhärenten Schwierigkeit auseinander, etwas zu visualisieren, das sowohl allgegenwärtig als auch verborgen, scheinbar überall und nirgends zugleich ist, und bedienen sich dabei einer Fülle unterschiedlicher Ansätze.
<G-vec00369-002-s105><employ.bedienen><en> In tackling the inherent difficulty of visualizing something that is meant to be both omnipresent and covert - seemingly everywhere and nowhere at the same time - the artists in this exhibition employ a dynamic range of approaches.
<G-vec00369-002-s106><employ.bedienen><de> Um einen unbefugten Zugriff sowie die unbefugte Nutzung, Manipulation, Modifikation und/oder Offenlegung Ihrer persönlichen Informationen zu verhindern, bedienen wir uns physischer, elektronischer und administrativer Maßnahmen.
<G-vec00369-002-s106><employ.bedienen><en> 5.9 We may employ certain physical, electronic and managerial procedures designed to help safeguard and prevent unauthorised access, use, alteration, modification and/or disclosure of your personal information.
<G-vec00369-002-s107><employ.bedienen><de> Allerdings würde ich anstelle von “Lebenswelt” die Bezeichnung “Alltagswelt” verwenden, deren sich die “Alltagsgeschichte” und die “Historische Anthropologie” bereits bedienen, weil “Lebenswelt” philosophisch besetzt ist.
<G-vec00369-002-s107><employ.bedienen><en> However, I would use the term “everyday world” instead of “lifeworld,” because “everyday history” and “historical anthropology” already employ the former, seeing as how “lifeworld” is used in philosophical circles.
<G-vec00369-002-s108><employ.bedienen><de> Vorstehende Haftungsausschlüsse und –beschränkungen gelten auch zugunsten unserer Mitarbeiter, Erfüllungsgehilfen und sonstiger Dritter, denen wir uns zur Vertragserfüllung bedienen.
<G-vec00369-002-s108><employ.bedienen><en> The previous exclusions and limitations of liability also apply in favour of our staff members, vicarious agents and other third parties we employ for the fulfilment of the contract.
<G-vec00369-002-s109><employ.bedienen><de> Sie soll bedeuten, daß „der Wertbegriff ein Hilfsmittel unseres Denkens ist, dessen wir uns bedienen, um die Phänomene des Wirtschaftslebens uns verständlich zu machen“.
<G-vec00369-002-s109><employ.bedienen><en> It means that the "idea of value is an aid to our thought which we employ in order to make the phenomena of economic life comprehensible."
<G-vec00369-002-s110><employ.bedienen><de> Wir bedienen uns im Übrigen geeigneter technischer und organisatorischer Sicherheitsmaßnahmen, um Ihre Daten gegen zufällige oder vorsätzliche Manipulationen, teilweisen oder vollständigen Verlust, Zerstörung oder gegen den unbefugten Zugriff Dritter zu schützen.
<G-vec00369-002-s110><employ.bedienen><en> We also employ suitable technical and organisational security measures in order to protect your data against accidental or intentional manipulation, partial or complete loss, destruction or access by unauthorised third parties.
<G-vec00369-002-s112><employ.bedienen><de> Für den Newsletter-Versand bedienen wir uns eines Auftragsverarbeiters.
<G-vec00369-002-s112><employ.bedienen><en> We employ the services of a processor to distribute the newsletter.
<G-vec00369-002-s113><employ.bedienen><de> Der Unternehmer ist berechtigt, in Übereinstimmung mit dem Auftraggeber sich zur Erfüllung seiner Verpflichtungen gemäß § 34a GewO zugelassener und zuverlässiger Unternehmer zu bedienen.
<G-vec00369-002-s113><employ.bedienen><en> The security company is entitled with the consent of the contractor to employ the services of other approved and reliable companies in the fulfilment of its duties accordance with § 34 a GewO.
<G-vec00369-002-s114><employ.bedienen><de> Wir bedienen uns geeigneter technischer und organisatorischer Sicherheitsmassnahmen, um Ihre bei uns gespeicherten persönlichen Daten gegen Manipulation, teilweisen oder vollständigen Verlust und gegen unbefugten Zugriff Dritter zu schützen.
<G-vec00369-002-s114><employ.bedienen><en> We employ suitable technical and organisational security measures to protect the personal data we store from manipulation, partial or total loss and unauthorised access by third parties.
<G-vec00369-002-s115><employ.bedienen><de> Um dies zu erreichen, bedienen sich Rohrhersteller verschiedener Methoden.
<G-vec00369-002-s115><employ.bedienen><en> To achieve this, pipe manufacturers employ a variety of techniques.
<G-vec00369-002-s116><employ.bedienen><de> info@bautenschutz-waden.de Webhosting Wir bedienen uns zum Vorhalten unserer Onlinepräsenz eines Internet-Service-Providers, auf dessen Server die Webseite gespeichert wird (Hosting) und der unsere Seite im Internet verfügbar macht.
<G-vec00369-002-s116><employ.bedienen><en> Hosting We employ an internet service provider to hold our online-presence available. The website is saved on the server of this provider (hosting) who makes our website available in the internet.
