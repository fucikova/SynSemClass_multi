<G-vec00510-002-s025><sprout_up.aussäen><de> Im März können die Bohnen im Folientunnel direkt in den Grund ausgesät werden.
<G-vec00510-002-s025><sprout_up.aussäen><en> In March we can sow beans in the tunnel directly into the ground to sprout under the foil.
