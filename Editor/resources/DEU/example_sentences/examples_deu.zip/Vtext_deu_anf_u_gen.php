<G-vec00407-001-s028><append.anfügen><de> Hinzufügen der Möglichkeit zum Anfügen von Datum/Zeit zum exportierten Dateinamen.
<G-vec00407-001-s028><append.anfügen><en> Added the possibility to append date/time to the exported file name.
<G-vec00407-001-s029><append.anfügen><de> Markieren Sie An Vorhandene anfügen (Standard), um die Trennausnahmen einer existierenden Liste hinzuzufügen.
<G-vec00407-001-s029><append.anfügen><en> Check Append to Existing (default) to append the hyphenation exceptions to an existing list.
<G-vec00407-001-s030><append.anfügen><de> New Ransomware wurde von Sicherheitsexperten vor kurzem entdeckt, die anfügen .xcry7684 Dateierweiterung auf den Computern der Opfer.
<G-vec00407-001-s030><append.anfügen><en> New ransomware has been recently discovered by security researchers to append the .xcry7684 file extension on the computers of victims.
<G-vec00407-001-s031><append.anfügen><de> • Anfügen: Wenn Sie dieselbe Einstellung in mehr als einer Policy anwenden, können Sie die Einstellungen mit dieser Regel anfügen.
<G-vec00407-001-s031><append.anfügen><en> • Append: When applying the same setting in more than one policy, you can append the settings with this rule.
<G-vec00407-001-s033><append.anfügen><de> Nebenbei bemerkt: Sie können den anfügen .rss-nahezu alle Veröffentlichungen der Gruppe auf Reddit, nicht nur domain-Veröffentlichungen, um sich einen RSS-Feed-url sofort, dass Sie können, abonnieren Sie in einem feed-reader Ihrer Wahl.
<G-vec00407-001-s033><append.anfügen><en> Sidenote: You can append .rss to virtually any submission group on Reddit, not only domain submissions, to get a RSS Feed url right away that you can subscribe to in a feed reader of your choosing.
<G-vec00407-001-s034><append.anfügen><de> Eine Liste der DNS-Suffixe, die zur Vervollständigung von nicht qualifizierten DNS-Namen angefügt werden, die für die Suche und die Übermittlung von DNS-Abfragen auf dem Client für die Auflösung verwendet werden Für DHCP-Clients kann diese auf dem DHCP-Server durch Zuweisung der DNS-Domänennamenoption (Option 15) und Bereitstellung eines einzelnen DNS-Suffixes, das der Client anfügen und für Suchen verwenden kann, festgelegt werden.
<G-vec00407-001-s034><append.anfügen><en> A list of DNS suffixes to be appended for use in completing unqualified DNS names that are used for searching and submitting DNS queries at the client for resolution. For DHCP clients, this can be set on the DHCP server by assigning the DNS domain name option (option 15) and providing a single DNS suffix for the client to append and use in searches.
<G-vec00407-001-s035><append.anfügen><de> "Zum Anfügen des aktuellen Speicherorts wird der Befehl ""Get-Location"" verwendet, der beim Aufrufen der prompt-Funktion ausgeführt wird."
<G-vec00407-001-s035><append.anfügen><en> To append the current location, it uses a Get-Location command, which runs when the prompt function is called.
<G-vec00407-001-s036><append.anfügen><de> Der folgende Artikel nur anfügen, danke für die vielen guten Wünsche, viel Lob und aufmunternde Worte, die in den letzten Monaten hatte ich.
<G-vec00407-001-s036><append.anfügen><en> The following article just append to, give thanks for the many good wishes, a lot of praise and encouraging words, which in recent months, I had.
<G-vec00407-001-s037><append.anfügen><de> Verwaiste PST-Datei – dieser Möglichkeit Gebrauch machen es möglich, die vorhandenen PST-Datei auszuwählen anfügen.
<G-vec00407-001-s037><append.anfügen><en> Orphaned PST File – this option make it possible to select the existing PST file to append.
<G-vec00407-001-s038><append.anfügen><de> Genau wie beim „site:“ – Operator, kannst Du einfach einen Suchbegriff nach dem Doppelpunkt anfügen.
<G-vec00407-001-s038><append.anfügen><en> Just like the “site:” operator, you can append a search after the colon.
<G-vec00407-001-s102><attach.anfügen><de> Der Airwheel X3 kommt mit Stützrädern, die Sie anfügen können über Schrauben an den unteren Rand der Fuß-Plattformen und einem Sicherheitsriemen während Sie die Dinge hängen.
<G-vec00407-001-s102><attach.anfügen><en> The Airwheel X3 comes with training wheels that you can attach via screws to the bottom of the foot platforms and a safety strap whilst you get the hang of things.
<G-vec00407-001-s103><attach.anfügen><de> Weitere Informationen finden Sie unter Anfügen eines verwalteten Datenträgers an einen virtuellen Windows-Computer im Azure-Portal .
<G-vec00407-001-s103><attach.anfügen><en> For more information, see How to attach a data disk to a Windows virtual machine in the Azure portal .
<G-vec00407-001-s104><attach.anfügen><de> "Klicken Sie auf ""Datei anfügen"" (oder die entsprechende Option)."
<G-vec00407-001-s104><attach.anfügen><en> Click on ‘Attach File’ (or similar option).
<G-vec00407-001-s105><attach.anfügen><de> Dieser Artikel enthält ein Lernprogramm zum Anfügen von Aufgaben an E-Mails in Microsoft Outlook.
<G-vec00407-001-s105><attach.anfügen><en> This article is a tutorial about how to attach tasks to email in Microsoft Outlook.
<G-vec00407-001-s106><attach.anfügen><de> 6 Wäscheklammern Holz mit schwarzen und weißen Muster Stift, Fragezeichen, Erbsen Bälle, Schneeflocken, ein Geschenk-Box zu dekorieren oder eine Notiz anfügen.
<G-vec00407-001-s106><attach.anfügen><en> 6 clothespins wood with black and white patterns pen, question mark, pea balls, snowflakes, to decorate a gift box or attach a note.
<G-vec00407-001-s107><attach.anfügen><de> Datei anfügen Fügt eine in MeXX gespeicherte Datei als Anlage an die aktuelle E-Mail an.
<G-vec00407-001-s107><attach.anfügen><en> Attach file Adds a file saved in MeXX as an attachment to the current e-mail.
<G-vec00407-001-s108><attach.anfügen><de> Benutzer von Secure Mail können Dateien aus ihrem Citrix Files-Repository anfügen, ohne die Datei auf das Gerät herunterzuladen.
<G-vec00407-001-s108><attach.anfügen><en> Secure Mail users can attach files from their Citrix Files repository without needing to download the file to the device.
<G-vec00407-001-s109><attach.anfügen><de> Sie können auch Kontakte aus Ihrem E-Mail-Adressbuch mit ein paar Klicks importieren und eine Nachricht anfügen.
<G-vec00407-001-s109><attach.anfügen><en> You can even import contacts from your e-mail address book in a few clicks and attach a message.
<G-vec00407-001-s110><attach.anfügen><de> Ein schneller Erfahrung — Outlook.com Beta kommt mit einem “mehr responsive web development framework”, einer optimierten Optik mit einem “modernen Konversation Stil”, und ein neues “design, damit Sie sehen, Lesen und anfügen von Dateien und Fotos schneller”.
<G-vec00407-001-s110><attach.anfügen><en> A faster experience — Outlook.com Beta comes with a “more responsive web development framework”, an optimized look with a “modern conversation style”, and a new “design to let you see, read and attach files and photos faster”.
<G-vec00407-001-s111><attach.anfügen><de> Sie können andere Dateien anfügen, um uns die Reproduktion ihres Problems zu erleichtern.
<G-vec00407-001-s111><attach.anfügen><en> You can also attach one or several files to help us to reproduce your problem.
<G-vec00407-001-s112><attach.anfügen><de> Man muss jedoch anfügen, dass seit Beginn der Bordelaiser Klassifizierung noch nie eine Änderung vorgenommen wurde und dies nach Meinung aller Weinkenner auch weiterhin nicht möglich sein würde.
<G-vec00407-001-s112><attach.anfügen><en> One must attach, however, that an amendment was never carried out since the beginning of the Bordelaise classification and furthermore either this would not be possible in opinion of all connoisseurs of win.
<G-vec00407-001-s113><attach.anfügen><de> Überstehende Streifen abschneiden und als seitliche Ränder anfügen.
<G-vec00407-001-s113><attach.anfügen><en> Cut off the excess around the edges and attach as a crust.
<G-vec00407-001-s114><attach.anfügen><de> Du kannst auch standardmäßig eine Signatur an alle Beiträge anhängen, indem Du im Profil die entsprechende Option auswählst (Du kannst das Anfügen einer Signatur immer noch verhindern, indem Du die Signaturoption beim Beitragsschreiben abschaltest).
<G-vec00407-001-s114><attach.anfügen><en> Once created, you can check the Attach a signature box on the posting form to add your signature. You can also add a signature by default to all your posts by checking the appropriate radio button in the User Control Panel.
<G-vec00407-001-s115><attach.anfügen><de> Microsoft Outlook 2016 unterstützt, um die neuesten Elemente in der Liste aufzulisten Neue Artikel Dropdown-Liste, und Sie können dann die letzten Dokumente / Elemente schnell anfügen.
<G-vec00407-001-s115><attach.anfügen><en> Microsoft Outlook 2016 supports to list the most recent items in the Recent Items drop down list, and then you can attach recent documents/items from it quickly.
<G-vec00407-001-s116><attach.anfügen><de> – Zusammenarbeit – Mit Planner, einem für Office 365 konzipierten Werkzeug, können Sie gemeinsam an den gleichen Aufgaben arbeiten, erfasste Fotos direkt an sie anfügen und sogar Gespräche rund um Ihre Aufgaben führen, ohne die Anwendung zu wechseln.
<G-vec00407-001-s116><attach.anfügen><en> -- Collaborate -- Built for Office 365, Planner lets you work together on the same tasks, attach captured photos directly to them, and even have conversations around tasks without switching between apps.
<G-vec00407-001-s117><attach.anfügen><de> Kommt mit Anleitung und mit einem Klebstoff an die Tabelle anfügen.
<G-vec00407-001-s117><attach.anfügen><en> Comes with manual and with an adhesive to attach to the table.
<G-vec00407-001-s118><attach.anfügen><de> "Wahrscheinlich, dies ist der Grund für dieses Ding namens ""Chemie"", aber anfügen was Etikett die Menschen zu dieser Art von Anziehung, eine Sache ist sicher: die Wirkung, die Pheromone zu bringen ist nicht bloße Spekulation aber eine erwiesene Tatsache."
<G-vec00407-001-s118><attach.anfügen><en> "Probably, this is the reason for that thing called ""chemistry,"" but whatever label people attach to this kind of attraction, one thing is for sure: the effect that pheromones bring is not mere speculation but a proven fact."
<G-vec00407-001-s119><attach.anfügen><de> "Wenn Sie dann Ihr Etikett im FedEx Ship Manager erstellen, können Sie die Option ""Vom Center Dokumentenvorbereitung anfügen"" auswählen, um Ihr zuvor erstelltes Dokument hochzuladen."
<G-vec00407-001-s119><attach.anfügen><en> "Then, when creating your label on FedEx Ship Manager, you can select ""Attach from Document Preparation Center"" to upload the document you previously created."
<G-vec00407-001-s120><attach.anfügen><de> Wenn das Feld Datenbank-Dateinamen anfügen den Namen einer primären Datei enthält, wird die durch die primäre Datei beschriebene Datenbank als Datenbank mithilfe des im Feld Die Standarddatenbank ändern auf angegebenen Datenbanknamens angefügt.
<G-vec00407-001-s120><attach.anfügen><en> If the Attach database filename box contains the name of a primary file, the database described by the primary file is attached as a database using the database name specified in the Change the default database to box.
<G-vec00407-001-s039><append.anfügen><de> append_domain <Domaene> Mit append_domain können Sie angeben, welche Domäne automatisch angefügt wird, wenn keine angegeben wurde.
<G-vec00407-001-s039><append.anfügen><en> append_domain <domain> With append_domain, specify which domain to append automatically when none is given.
<G-vec00407-001-s040><append.anfügen><de> append_domain DOMÄNE Verwenden Sie append_domain, um anzugeben, welche Domäne automatisch angefügt wird, wenn keine angegeben wurde.
<G-vec00407-001-s040><append.anfügen><en> append_domain DOMAIN Use append_domain to specify which domain to append automatically when none is given.
<G-vec00407-001-s041><append.anfügen><de> Verwenden Sie append_domain, um anzugeben, welche Domäne automatisch angefügt wird, wenn keine angegeben wurde.
<G-vec00407-001-s041><append.anfügen><en> Use append_domain to specify which domain to append automatically when none is given.
<G-vec00407-001-s152><append.anfügen><de> Zu diesem Zeitpunkt können Sie die Ergebnisse in eine Datei schreiben und die später empfangenen Ergebnisse dann jeweils anfügen.
<G-vec00407-001-s152><append.anfügen><en> At this point, you can write the results to a file and then append the newly received results as they arrive.
<G-vec00407-001-s167><append.anfügen><de> Wenn Sie die Warnungen an den Variableninhalt anfügen möchten, anstatt bereits dort gespeicherte Warnungen zu ersetzen, geben Sie vor dem Variablennamen ein Pluszeichen (+) ein.
<G-vec00407-001-s167><append.anfügen><en> To append the warnings to the variable content, instead of replacing any warnings that might already be stored there, type a plus sign (+) before the variable name.
<G-vec00407-001-s174><append.anfügen><de> "Es stehen folgende Optionen zur Verfügung.Daten anfügen (Insert): Ist diese Option aktiv werden die Daten an die ""temporäre"" InMemory Tabelle angefügt."
<G-vec00407-001-s174><append.anfügen><en> "The following options are available. Append data (insert): When this option is checked the data is added with an ""insert"" into the temporary InMemory table."
<G-vec00407-001-s175><append.anfügen><de> "Damit der Bumper automatisch in neue Projekte eingefügt wird, aktivieren Sie die Option ""Video-Bumper anfügen""."
<G-vec00407-001-s175><append.anfügen><en> "To have the bumper automatically included in new projects, turn on the option ""Append Video Bumper."""
