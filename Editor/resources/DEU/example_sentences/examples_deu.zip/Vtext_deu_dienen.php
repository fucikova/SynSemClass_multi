<G-vec00225-001-s247><act.dienen><de> Sie dienen als Leitfaden für die Fitness und motivieren uns, unsere Ziele zu erreichen.
<G-vec00225-001-s247><act.dienen><en> They act as proper guides to fitness and keep us motivated to reach our goals.
<G-vec00225-001-s248><act.dienen><de> Dieses Spiel verfügt zu dem über Multiplikatoren und Scattersymbolen, die als Auslöser für das Gratis-Spins Bonusspiel und das Gamble Bonusspiel dienen, in denen du deine Gewinne vervielfachen kannst.
<G-vec00225-001-s248><act.dienen><en> It is also a game with a multiplier and scatter, which act as triggers to bring you into the Free Spins Bonus Game and the Gamble Bonus Game, where you can increase and multiply your wins.
<G-vec00225-001-s249><act.dienen><de> "Der Surrey County Council hat den Preis für seine Fehler bezahlt, und dieser Fall sollte als Warnung für andere dienen, dass laxe Datenschutzpraxis nicht toleriert werden soll""."
<G-vec00225-001-s249><act.dienen><en> "Surrey County Council has paid the price for their failings, and this case should act as a warning to others that lax data protection practices will not be tolerated."""
<G-vec00225-001-s250><act.dienen><de> Nach den Vorschriften des ungarischen Umsatzsteuergesetzes gilt ein Verkauf von Produkten, die einer – für den oder vom Lieferanten ausgeführten – Montage oder Installation zur Grundlage dienen, als Lieferung von Gegenständen.
<G-vec00225-001-s250><act.dienen><en> According to the Hungarian VAT Act, the sale of a product which underlies an installation or assembly carried out by the vendor or by another party is considered a product supply.
<G-vec00225-001-s251><act.dienen><de> Dies könnte dazu führen, erhöhte Grad an körperlicher Energie sowie als Kickstarter für Gewichtsmanagement dienen.
<G-vec00225-001-s251><act.dienen><en> This might lead to raised degrees of physical energy or even act as a kick starter for fat burning.
<G-vec00225-001-s252><act.dienen><de> Unsere Schülerpraktika dienen als Berufsorientierung während der Schulzeit.
<G-vec00225-001-s252><act.dienen><en> Our pupil placements act as careers guidance during your time at school.
<G-vec00225-001-s253><act.dienen><de> Die Seminare dienen der Sensibilisierung, die Muster von Gefahrensituationen rechtzeitig zu erkennen.
<G-vec00225-001-s253><act.dienen><en> Our seminars act as sensitisation to recognise dangerous situations early enough.
<G-vec00225-001-s254><act.dienen><de> Der Kurs Kommunikation, Groß in Werbung, zielt darauf ab, Fachkräfte und Forscher, die sich in einem transformative Weise in mehreren modernen Kommunikationsszenarien dienen, bereit, zu entwerfen, zu produzieren und auszuführen Werbekampagnen und Kommunikationsprojekte für die Entwicklung und Imageförderung trainieren Produkte und Dienstleistungen.
<G-vec00225-001-s254><act.dienen><en> The course Communication, major in Advertising, aims to train professionals and researchers who act in a transformative way in several contemporary communication scenarios, prepared to design, produce and execute advertising campaigns and communication projects for the development and image promotion products and services.
<G-vec00225-001-s255><act.dienen><de> die Größe/Ausdehnung der Küstenfeuchtgebiete, die als Überflutungspuffer dienen können.
<G-vec00225-001-s255><act.dienen><en> the area/extent of coastal wetlands which could act as a flood buffer.
<G-vec00225-001-s256><act.dienen><de> Die Europäische Investitionsbank (EIB) wird als zentrale Einrichtung für die Umsetzung von ELENA Unterstützung und Beratung bereitstellen und als Ansprechpartner dienen.
<G-vec00225-001-s256><act.dienen><en> The European Investment Bank (EIB), which stands at the core of the implementation of ELENA, will provide assistance and expertise and act as the point of contact.
<G-vec00225-001-s257><act.dienen><de> Diese Erfahrungen können nun als Modell für zukünftige Eingriffe dienen und je nach äußeren Gegebenheiten angepasst werden.
<G-vec00225-001-s257><act.dienen><en> These experiences can act as a model for future intervention and be adapted as the external environment changes.
<G-vec00225-001-s258><act.dienen><de> - Durch die Kommunikation mit anderen Ländern als Referenzentrum für die Beratung und Informationen für und über die lokale Kunst und Kultur zu dienen.
<G-vec00225-001-s258><act.dienen><en> - Through communication with other countries, to act as a centre of reference providing advices for and about local art and culture.
<G-vec00225-001-s259><act.dienen><de> "Ein elegant gekleideter ""Interlocutor"", der in der Mitte steht, würde als gerader Mann zu zwei gaudily gekleideten Schauspielern, zu Herrn Tambo und zu Herrn Bones dienen."
<G-vec00225-001-s259><act.dienen><en> An elegantly clothed “interlocutor” standing in the middle would act as straight man to two gaudily dressed comedians, Mr. Tambo and Mr. Bones.
<G-vec00225-001-s260><act.dienen><de> Das TS-963X kann virtuelle Maschinen und Container direkt hosten und als Speicher für Hypervisoren wie VMware®, Citrix® und Microsoft® Hyper-V® dienen.
<G-vec00225-001-s260><act.dienen><en> The TS-963X can directly host virtual machines and containers, and act as storage for hypervisors such as VMware®, Citrix® and Microsoft® Hyper-V®.
<G-vec00225-001-s261><act.dienen><de> Beim Trennschleifen beschichteter Proben muss die Trennscheibe zuerst durch die Schicht(en) schneiden, so dass der Hauptwerkstoff als Unterstützung dienen kann.
<G-vec00225-001-s261><act.dienen><en> When cutting coated samples, the wheel should pass through the layer(s) first, so that the base material can act as support.
<G-vec00225-001-s262><act.dienen><de> Heute fiel das GBP/USD weit zurück in den Widerstandsbereich, der nun als Unterstützung dienen könnte.
<G-vec00225-001-s262><act.dienen><en> Today, GBPUSD fell heavily back towards the resistance area which now could act as support.
<G-vec00225-001-s263><act.dienen><de> Die Qualifikationspunkte dienen als Regulator für die Zahl der Anmeldungen.
<G-vec00225-001-s263><act.dienen><en> Qualifying points act as a regulator for the number of registration requests.
<G-vec00225-001-s264><act.dienen><de> Sie dienen als Platzhalter für Abhängigkeiten.
<G-vec00225-001-s264><act.dienen><en> They will then act as dependency placeholders.
<G-vec00225-001-s265><act.dienen><de> Die Band Clubs dienen auch als Jugendzentren, in denen junge Leute kostenlos Musikunterricht bekommen.
<G-vec00225-001-s265><act.dienen><en> The band clubs also act as a youth centre as well as a source for young people to learn music for free.
