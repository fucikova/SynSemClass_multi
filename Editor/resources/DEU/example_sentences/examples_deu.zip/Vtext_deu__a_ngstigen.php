<G-vec00251-003-s220><scare_away.ängstigen><de> Es ist sehr wichtig, die Rennmaus richtig zu halten, damit du sie nicht ängstigst oder verletzt.
<G-vec00251-003-s220><scare_away.ängstigen><en> It’s very important to handle your gerbil properly so that you don’t scare or injure him.
<G-vec00251-003-s220><scare_off.ängstigen><de> Es ist sehr wichtig, die Rennmaus richtig zu halten, damit du sie nicht ängstigst oder verletzt.
<G-vec00251-003-s220><scare_off.ängstigen><en> It’s very important to handle your gerbil properly so that you don’t scare or injure him.
