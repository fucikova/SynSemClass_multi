<G-vec00297-002-s475><choose.auswählen><de> Bahne dir deinen Weg, wähle zwischen Held oder Schurke und erlebe die Kämpfe aus der Reihe hautnah.
<G-vec00297-002-s475><choose.auswählen><en> arena fighter. Pave your path and choose between hero or villain
<G-vec00297-002-s476><choose.auswählen><de> Wähle dann aus der unten stehenden Liste aus, was Peter mag und was er nicht mag.
<G-vec00297-002-s476><choose.auswählen><en> Then choose from the list below what Peter likes and what he doesn't like.
<G-vec00297-002-s477><choose.auswählen><de> Wähle aus einer Liste deiner gespeicherten Kreditkarten aus.
<G-vec00297-002-s477><choose.auswählen><en> Choose from a list of your stored credit cards.
<G-vec00297-002-s478><choose.auswählen><de> Dann wähle die richtige Antwort aus.
<G-vec00297-002-s478><choose.auswählen><en> Then choose the correct reply.
<G-vec00297-002-s479><choose.auswählen><de> Probiere ein paar komplett unterschiedliche Überschriften aus und wähle die beste aus.
<G-vec00297-002-s479><choose.auswählen><en> Try a few drastically different extended headlines and choose the best one to continue with.
<G-vec00297-002-s480><choose.auswählen><de> Objekte nach einem Tags gruppieren: Klicke auf die Taste „Gruppe“ und wähle „Tags“ aus.
<G-vec00297-002-s480><choose.auswählen><en> Group items by a tag: Click the Group button, then choose Tags.
<G-vec00297-002-s481><choose.auswählen><de> Passe Zifferblätter und App-Mitteilungen an, wähle die Apps im Dock aus und ordne sie, wie es dir gefällt, und wähle Fotos und Musik, die du synchronisieren willst.
<G-vec00297-002-s481><choose.auswählen><en> Customize your watch faces and app notifications, choose and arrange the apps in your Dock, select photos and music to sync, and more.
<G-vec00297-002-s482><choose.auswählen><de> Auschecken Für Preise und VerfügbarkeFreunden Grund- /Hauptschule Haupt-/Oberschule Universität Geschäftsreise Polterabend Sportsgruppen Kulturgruppen Bitte wähle eine Gruppenart aus.
<G-vec00297-002-s482><choose.auswählen><en> Check Out To view prices and availability, please enter a Friends Junior/Primary School High/Secondary School College/University Business Trip Stag / Hen / Bachelor Party Sports Group Cultural Group You must choose a group type.
<G-vec00297-002-s483><choose.auswählen><de> Wähle aus, ob die E-Mails in deinem Posteingang erscheinen sollen.
<G-vec00297-002-s483><choose.auswählen><en> Choose whether or not the messages should appear in your inbox.
<G-vec00297-002-s484><choose.auswählen><de> Wähle oben rechts mit einem Klick das Teammitglied aus, das du entfernen möchtest.
<G-vec00297-002-s484><choose.auswählen><en> In the upper right corner, choose the team member you want to remove.
<G-vec00297-002-s485><choose.auswählen><de> Long Road To HellRock Rebel by EMPWinterjacke Bitte wähle eine Größe aus.
<G-vec00297-002-s485><choose.auswählen><en> Skull Jacket IIRock Rebel by EMPWinter Jacket Please choose a size Jacket
<G-vec00297-002-s486><choose.auswählen><de> Cat Bitte wähle eine Größe aus.
<G-vec00297-002-s486><choose.auswählen><en> Please choose a size XXL
<G-vec00297-002-s487><choose.auswählen><de> Um Elixiere zu mischen, gehe zu deinem Heiligtum des Asklepios, öffne den Tab "Amphorenkammer" und wähle die Elixiere aus, die du miteinander mischen möchtest.
<G-vec00297-002-s487><choose.auswählen><en> To combine Potions, go to your Alchemist's Shop, open the "Laboratory" tab and choose the Potions you wish to mix.
<G-vec00297-002-s488><choose.auswählen><de> Wähle einfach deinen Lieblingsstream aus und gib dir die volle Dröhnung.
<G-vec00297-002-s488><choose.auswählen><en> Just choose your favorite stream and give you the full roar.
<G-vec00297-002-s489><choose.auswählen><de> Wähle in Choices: Stories you Play eine Geschichte nach deinen Wünschen aus und begib dich zu neuen Abenteuern, triff neue Bekannte und vielleicht auch deine Liebe.
<G-vec00297-002-s489><choose.auswählen><en> Votes: 299 Choices: Stories you play - choose a story to your liking and go to find adventures, new meetings and maybe love.
<G-vec00297-002-s490><choose.auswählen><de> Wähle etwas aus, was zu deiner Gesichtsform passt.
<G-vec00297-002-s490><choose.auswählen><en> Choose something that will flatter your face shape.
<G-vec00297-002-s491><choose.auswählen><de> Wähle aus, wohin du die Channels transferieren möchtest, indem du auf einen Workspace klickst.
<G-vec00297-002-s491><choose.auswählen><en> Choose where you'd like to move the channelsÂ by clicking on a workspace.
<G-vec00297-002-s492><choose.auswählen><de> Wähle Nahrungsmittel aus, die den Speichelfluss anregen, um über den Tag die Plaque fernzuhalten.
<G-vec00297-002-s492><choose.auswählen><en> Choose foods that make you salivate as a way to keep plaque away during the day.
<G-vec00297-002-s493><choose.auswählen><de> Art der Gruppe Urlaub mit Freunden Grund- /Hauptschule Haupt-/Oberschule Universität Geschäftsreise Polterabend Sportsgruppen Kulturgruppen Bitte wähle eine Gruppenart aus.
<G-vec00297-002-s493><choose.auswählen><en> Group Type Holiday with Friends Junior/Primary School High/Secondary School College/University Business Trip Stag / Hen / Bachelor Party Sports Group Cultural Group You must choose a group type.
<G-vec00297-002-s097><opt.auswählen><de> Um die Anmeldeinformationen für die Authentifizierung vollständig zu schützen, müssen bestimmte Anwendungen auf diesen Plattformen immer noch den Mechanismus auswählen.
<G-vec00297-002-s097><opt.auswählen><en> In order to fully protect authentication credentials, specific applications on these operating systems still need to opt in to the mechanism.
<G-vec00297-002-s098><opt.auswählen><de> Das Angebot richtet sich an Kundinnen, die auf die Pflege ihrer Haut achten und gleichzeitig umweltbewusst Produkte auswählen.
<G-vec00297-002-s098><opt.auswählen><en> The product range is aimed at customers who pay attention to their skin care and also opt for environmentally conscious products.
<G-vec00297-002-s099><opt.auswählen><de> Unser Gold ist immer 18 Karat, egal ob Sie Weiß-, Gelb- oder Rotgold auswählen.
<G-vec00297-002-s099><opt.auswählen><en> Our gold is always 18 carat, regardless of whether you opt for white, yellow or red gold.
<G-vec00297-002-s100><opt.auswählen><de> Auswählen und verlinken Sie Ihren Gnatta service HelpDesk mit HDM.
<G-vec00297-002-s100><opt.auswählen><en> Opt and connect your Activate support desk with HDM.
<G-vec00297-002-s101><opt.auswählen><de> Dann können Sie auf Ihrem iPhone "Wiederherstellen von iTunes Backup" auswählen.
<G-vec00297-002-s101><opt.auswählen><en> Then on your iPhone, you can now opt to "Restore from iTunes Backup".
<G-vec00297-002-s102><opt.auswählen><de> Ihr könnt die Unterkunft an Bord im Rahmen eures Budgets auswählen: entscheidet euch für eine der kostengünstigen Schlafkojen oder gönnt euch einer Doppelbett-Kabine mit eigenem Bad.
<G-vec00297-002-s102><opt.auswählen><en> Choose your onboard accommodation to suit your budget: opt for one of our best value 6-berth bunks or splash out on a double ensuite private cabin.
<G-vec00297-002-s103><opt.auswählen><de> Wenn Sie dies auswählen, kreuzen Sie einfach das Kästchen auf der Download-Seite an und klicken anschließend auf Download.
<G-vec00297-002-s103><opt.auswählen><en> If you’d like to opt for this, just check the box on the download page, then click Download.
<G-vec00297-002-s104><opt.auswählen><de> Sie können auch auswählen, diese Zahlen für 2, 4 oder 8 aufeinanderfolgende Ziehungen zu verwenden und/oder die selbe Wette bei 2,4 oder 8 aufeinanderfolgenden Wettbewerben (“Teimosinha”) zu machen.
<G-vec00297-002-s104><opt.auswählen><en> They can also opt to enter these numbers for 2, 4 or 8 consecutive draws in advance and / or compete with the same bet by 2, 4 or 8 consecutive contests (“Teimosinha”).
<G-vec00322-002-s182><specify.auswählen><de> Legen Sie fest, ob Sie eine ganze Gruppe von Dokumenten bearbeiten möchten, nur die derzeit angezeigte Kopie oder einen Teil der Gruppe, den Sie nach Datensatznummern auswählen.
<G-vec00322-002-s182><specify.auswählen><en> Choose whether you want to edit the whole set of labels, only the label that is currently visible, or a subset of the set, which you specify by record number.
<G-vec00322-002-s183><specify.auswählen><de> Die Stärke des Wasserdrucks, Position des Duscharms, Wunschtemperatur, Strahlart und Reinigungsverfahren lassen sich ganz nach persönlichen Vorlieben auswählen.
<G-vec00322-002-s183><specify.auswählen><en> Extensive personalization options allow the user to specify the water pressure, the position of the shower arm and the preferred water temperature, as well as the spray pattern and the cleansing procedure.
<G-vec00322-002-s184><specify.auswählen><de> Hier kannst du auswählen, wieviele Prozessor-Threads Gsdx mit dem Software Renderer verwenden soll, um alle Kerne deines Prozessors auszunützen.
<G-vec00322-002-s184><specify.auswählen><en> Here you can specify how many threads GSdx will use while software rendering, to take advantage of all cores your processor might have, e.g.
<G-vec00322-002-s185><specify.auswählen><de> In den MIME-Einstellungen können Sie auswählen, welche Formate QuickTime in Firefox abspielen soll.
<G-vec00322-002-s185><specify.auswählen><en> In the MIME Types window, you can specify the media formats you want QuickTime to play in Firefox.
<G-vec00322-002-s186><specify.auswählen><de> Abbildung 6: Zeitfenster auswählen.
<G-vec00322-002-s186><specify.auswählen><en> Figure 6: Specify a time frame
<G-vec00322-002-s187><specify.auswählen><de> Als Spieler kann man auswählen, auf wie viele Gewinnlinien man wetten möchte.
<G-vec00322-002-s187><specify.auswählen><en> As a player, you can specify the number of active pay lines you want to wager on.
<G-vec00322-002-s188><specify.auswählen><de> Die exklusiven GLK-Modelle werden in der Basisausführung in Calcitweiß angeboten, allerdings kann der Kunde auch jede andere Lackierung auswählen.
<G-vec00322-002-s188><specify.auswählen><en> The exclusive GLK models are available in calcite white in the basic version, although customers may specify any other paint finish.
<G-vec00322-002-s189><specify.auswählen><de> Neben den angegebenen Farbkombinationen können Sie daher die Farbe der lackierten Oberflächen dieses Möbelstücks selbst aus der Palette der RAL-Töne auswählen (ein- oder zweifarbige Lackierung möglich).
<G-vec00322-002-s189><specify.auswählen><en> Colour on request: Müller produces the furniture order-related. In addition to the colours selected by us, you may specify the furniture colours (monochrome or two-tone) from the palette of RAL colours.
<G-vec00322-002-s190><specify.auswählen><de> Sie müssen auf der Seite, auf die wir verlinken, lediglich Ihr Scanner-Modell auswählen.
<G-vec00322-002-s190><specify.auswählen><en> You will just have to specify your scanner model on the page we link to.
<G-vec00322-002-s191><specify.auswählen><de> Hier kannst du auch die Rechnungsadresse auswählen.
<G-vec00322-002-s191><specify.auswählen><en> It is also during this step that you can specify a billing address.
<G-vec00322-002-s192><specify.auswählen><de> Du kannst ein bestimmtes Genre auswählen, dir Songs und Alben eines Interpreten wünschen oder die Wunschlisten von Communitymitgliedern zum Mitschneiden auswählen.
<G-vec00322-002-s192><specify.auswählen><en> You can specify the genre, request specific songs and albums or choose to have your personal wishlist available for community members to record.
<G-vec00322-002-s193><specify.auswählen><de> Neben diesen Systemkomponenten können Sie nach Bedarf weitere Komponenten und Technologien (beispielsweise ZigBee, EnOcean oder andere) auswählen.
<G-vec00322-002-s193><specify.auswählen><en> In addition to these system components you can also specify other components and technologies (e.g. ZigBee, EnOcean etc.) according to your needs.
<G-vec00488-002-s033><designate.auswählen><de> Sind mehrere Gruppen mit der gleichen Berechtigung auf einem Ordner angelegt, so kann man die Gruppe auswählen, die man in tenfold registrieren möchte.
<G-vec00488-002-s033><designate.auswählen><en> If several groups have the same access right to a folder, it is possible to designate one of these groups for registration in tenfold.
<G-vec00106-002-s076><choose.auswählen><de> Sie können ein für Sie passendes Fahrzeug auswählen, eine Gruppe buchen oder einen individuellen Transfer buchen, um die genauen Kosten der Reise zu erfahren.
<G-vec00106-002-s076><choose.auswählen><en> You will be able to choose a suitable car for you, book group or individual transfer, to know the exact cost of the trip.
<G-vec00106-002-s077><choose.auswählen><de> Als Zusatz zeigen wir Ihnen auch den Ort der Hotels auf der Karte an, so dass Sie ein Hotel in Bonn Zentrum oder im Stadtviertel auswählen können, das Ihnen am meisten zusagt.
<G-vec00106-002-s077><choose.auswählen><en> In addition, we also provide you with the location of all the accommodation on a map, so that you can choose a hotel in the centre of Antrim or near the place that interests you the most.
<G-vec00106-002-s078><choose.auswählen><de> Zuvor mussten die Benutzer Links zu den Website-Besuchern manuell über die internationale Website von Amazon bereitstellen oder eine Liste von Links bereitstellen und den Benutzer auswählen lassen, auf welchen er klicken sollte.
<G-vec00106-002-s078><choose.auswählen><en> Before, users had to manually provide links per Amazon international site to the website visitors, or provide a list of links and let the user choose which one to click on.
<G-vec00106-002-s079><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Basconcillos del Tozo, Spanien, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s079><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Buttrio, Italy, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s080><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Cambados, Spanien, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s080><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Merza, Spain, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s081><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Vieux Boucau les Bains, Frankreich, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s081><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Luxeuil les Bains, France, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s082><choose.auswählen><de> Eine Option auswählen...
<G-vec00106-002-s082><choose.auswählen><en> Baby Choose an Option...
<G-vec00106-002-s083><choose.auswählen><de> Mini Suiten sind nicht die gleiche Kategorie wie Suiten; hier können die Gäste nur eines der oben aufgeführten Angebote auswählen.
<G-vec00106-002-s083><choose.auswählen><en> Our Mini-Suite categories are actually different than our Suite categories, and their guests are only eligible to choose one of the above offers.
<G-vec00106-002-s084><choose.auswählen><de> Der Markt Jeden Freitag findet in Moraira ein spezieller Obst- und Gemüsemarkt statt, auf dem Sie die frischesten lokalen Produkte auswählen und Geschenke für Familie und Freunde zu Hause kaufen können.
<G-vec00106-002-s084><choose.auswählen><en> The Market Every friday there is a special fruit and vegetable market in Moraira, where you can choose the freshest local produce, and buy gifts for family and friends back home.
<G-vec00106-002-s085><choose.auswählen><de> Man kann den Scanner nicht an den Ordner "XY" schicken oder einfach einen Netzwerkordner zuweisen, man muss immer einen Computer auswählen, damit er scannt.
<G-vec00106-002-s085><choose.auswählen><en> One can not tell the scanner send to folder "XY" or simply assign a network folder, you always have to choose a computer so that he scans.
<G-vec00106-002-s086><choose.auswählen><de> A - Domäne Wenn Sie für Ihre Organisation mehrere Domänen haben, können Sie aus einer Dropdown-Liste der Domänen auswählen, die verfügbar sind.
<G-vec00106-002-s086><choose.auswählen><en> A - Domain If you have multiple domains for your organization, you can choose from a drop-down list of domains that are available.
<G-vec00106-002-s087><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Siesta Key, Vereinigte Staaten, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s087><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Siesta Key, United States, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s088><choose.auswählen><de> Als Zusatz zeigen wir Ihnen auch den Ort der Hotels auf der Karte an, so dass Sie ein Hotel in Chemnitz Zentrum oder im Stadtviertel auswählen können, das Ihnen am meisten zusagt.
<G-vec00106-002-s088><choose.auswählen><en> In addition, we also provide you with the location of all the accommodation on a map, so that you can choose a hotel in the centre of Forfar or near the place that interests you the most.
<G-vec00106-002-s089><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Mai Khao Beach, Thailand, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s089><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Natai Beach, Thailand, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s090><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Skagen, Dänemark, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s090><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Skagen, Denmark, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s091><choose.auswählen><de> Es gibt keine zeitliche Begrenzung und Sie können ein beliebiges Bild auswählen.
<G-vec00106-002-s091><choose.auswählen><en> There is no time limit and you can choose any image that you like.
<G-vec00106-002-s092><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Villagonzalo-Pedernales, Spanien, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s092><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Isar, Spain, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s093><choose.auswählen><de> Bei Destinia bieten wir Ihnen ein breites Angebot an Hotels in Breda, Niederlande, damit Sie das auswählen können, welches am besten Ihren Ansprüchen und Ihrem Gelbeutel entspricht.
<G-vec00106-002-s093><choose.auswählen><en> At Destinia we offer you a wide variety of hotels in Breda, Netherlands, so you can choose the one that´s right for you, depending on your expectations and your budget.
<G-vec00106-002-s094><choose.auswählen><de> Auf der Seite für MSN, Bing & Windows Live – Kommunikationspräferenzen können Sie auswählen, ob Sie Marketingmaterialien von MSN oder Windows Live erhalten möchten.
<G-vec00106-002-s094><choose.auswählen><en> The MSN and Windows Live Communications Preferences page allows you to choose whether you wish to receive marketing material from MSN or Windows Live.
<G-vec00106-002-s095><choose.auswählen><de> Sie verpflichten sich, alle von uns vorgeschlagenen Sicherheitskontrollen zu prüfen und diejenigen auszuwählen, die für Ihr Geschäft zum Schutz vor nicht autorisierten Transaktionen geeignet sind, sowie unabhängig davon andere, nicht von uns bereitgestellte Sicherheitsverfahren und Kontrollen einzurichten, wenn dies für Ihr Geschäft angemessen ist.
<G-vec00106-002-s095><choose.auswählen><en> You agree to review all the Security Controls we suggest and choose those that are appropriate for your business to protect against unauthorised Transactions and, if appropriate for your business, independently implement other security procedures and controls not provided by us.
<G-vec00106-002-s096><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die FAT-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s096><choose.auswählen><en> Simply right-click on the IBAK file, then from the available list select "Choose default program".
<G-vec00106-002-s097><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die CVM-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s097><choose.auswählen><en> Simply right-click on the CVM file, then from the available list select "Choose default program".
<G-vec00106-002-s098><choose.auswählen><de> Jetradar schlägt den Kauf von Flügen nach Málaga im Voraus vor, um die Bedingungen für Ihren Flug nach Ihren Präferenzen und finanziellen Ressourcen auszuwählen.
<G-vec00106-002-s098><choose.auswählen><en> Jetradar suggests buying flights to Lisbon in advance in order to choose the conditions for your flight based on your preferences and financial resources.
<G-vec00106-002-s099><choose.auswählen><de> Jetradar schlägt den Kauf von Flügen nach Forrest City im Voraus vor, um die Bedingungen für Ihren Flug nach Ihren Präferenzen und finanziellen Ressourcen auszuwählen.
<G-vec00106-002-s099><choose.auswählen><en> Jetradar suggest buying flights to Chichen Itza in advance in order to choose the conditions for your flight based on your preferences and financial resources.
<G-vec00106-002-s100><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die WHTT-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s100><choose.auswählen><en> Simply right-click on the WHTT file, then from the available list select "Choose default program".
<G-vec00106-002-s101><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die S-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s101><choose.auswählen><en> Simply right-click on the CVSRC file, then from the available list select "Choose default program".
<G-vec00106-002-s102><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die QWQ-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s102><choose.auswählen><en> It is application manually. Simply right-click on the C3Z file, then from the available list select "Choose default program".
<G-vec00106-002-s103><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die PDI-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s103><choose.auswählen><en> Simply right-click on the PDI file, then from the available list select "Choose default program".
<G-vec00106-002-s104><choose.auswählen><de> Um das für Sie geeignete System von Schiebetüren auszuwählen, müssen Sie sich entscheiden, welche Modelle derzeit auf dem Markt für Bauprodukte angeboten werden.
<G-vec00106-002-s104><choose.auswählen><en> In order to choose the suitable system of sliding doors for you, you have to decide what models are currently offered in the building products market.
<G-vec00106-002-s105><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die NKD-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s105><choose.auswählen><en> Simply right-click on the NKD file, then from the available list select "Choose default program".
<G-vec00106-002-s106><choose.auswählen><de> So scheint es schier unmöglich, aus unzähligen Konzerten, Clubs, Lesungen, Film-und Theatervorstellungen auszuwählen.
<G-vec00106-002-s106><choose.auswählen><en> It seems nearly impossible to choose from countless concerts, clubs,… Read more › Share
<G-vec00106-002-s107><choose.auswählen><de> Bitte beachten Sie, dass es am Ankunftstag aus organisatorischen Gründen nicht möglich ist, bei Halbpension das Hauptgericht des Abendessens auszuwählen.
<G-vec00106-002-s107><choose.auswählen><en> Please note that it is not possible to choose the main course of the half-board dinner on the day of arrival due to organisational reasons.
<G-vec00106-002-s108><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die MMAP-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s108><choose.auswählen><en> Simply right-click on the MMAP file, then from the available list select "Choose default program".
<G-vec00106-002-s109><choose.auswählen><de> Jetradar schlägt den Kauf von Flügen nach Syracuse im Voraus vor, um die Bedingungen für Ihren Flug nach Ihren Präferenzen und finanziellen Ressourcen auszuwählen.
<G-vec00106-002-s109><choose.auswählen><en> Jetradar suggests buying flights to Camaguey in advance in order to choose the conditions for your flight based on your preferences and financial resources.
<G-vec00106-002-s110><choose.auswählen><de> Dank der Möglichkeit, für jede Situation den richtigen Filter auszuwählen, können die Benutzer mit dem Gehörschutz „besser“ hören als ohne.
<G-vec00106-002-s110><choose.auswählen><en> The ability to choose the right filter for the right kind of circumstances enables the wearer to hear ‘better’ when wearing the protective equipment compared to when they are not wearing this safety precaution.
<G-vec00106-002-s111><choose.auswählen><de> Es gibt Situationen, in denen es aufgrund der großen Vielfalt schwierig ist, das gewünschte Modell auszuwählen.
<G-vec00106-002-s111><choose.auswählen><en> There are situations when it is difficult to choose the desired model due to the large variety.
<G-vec00106-002-s112><choose.auswählen><de> Es reicht aus, mit der rechten Maustaste die BWP-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00106-002-s112><choose.auswählen><en> Simply right-click on the BUR file, then from the available list select "Choose default program".
<G-vec00106-002-s113><choose.auswählen><de> Jetradar schlägt den Kauf von Flügen nach Düsseldorf im Voraus vor, um die Bedingungen für Ihren Flug nach Ihren Präferenzen und finanziellen Ressourcen auszuwählen.
<G-vec00106-002-s113><choose.auswählen><en> Jetradar suggests buying flights to Thargomindah in advance in order to choose the conditions for your flight based on your preferences and financial resources.
<G-vec00106-002-s513><choose.auswählen><de> Vergleichen Sie Tarife für Volgograd — Rio De Janeiro von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s513><choose.auswählen><en> Compare prices from different carriers that offer flights Paris – Brazil and choose the air fare you like most.
<G-vec00106-002-s514><choose.auswählen><de> Zum Anpassen der Abschrägung klicken Sie auf 3D-Optionen und wählen dann die gewünschten Optionen aus.
<G-vec00106-002-s514><choose.auswählen><en> To customize the bevel, click 3-D Options, and then choose the options that you want.
<G-vec00106-002-s515><choose.auswählen><de> Nach Ihrer Suche bekommen Sie eine Liste der günstigen Billigflüge nach Korfu Sie wählen einen Billigflug aus der Liste, indem Sie auf "Weiter" klicken.
<G-vec00106-002-s515><choose.auswählen><en> After you search, you get a list of cheap flights to Corfu. Here you just choose a cheap flight, by clicking on the "Continue" button.
<G-vec00106-002-s516><choose.auswählen><de> Vergleichen Sie Tarife für Bergamo — Pisa von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s516><choose.auswählen><en> Compare prices from different carriers that offer flights Amsterdam – Italy and choose the air fare you like most.
<G-vec00106-002-s517><choose.auswählen><de> Vergleichen Sie Tarife für Mexiko-Stadt — San Salvador von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s517><choose.auswählen><en> Compare prices from different carriers that offer flights Mexico City – El Salvador and choose the air fare you like most.
<G-vec00106-002-s518><choose.auswählen><de> Vergleichen Sie Tarife für Oslo — Sankt Petersburg von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s518><choose.auswählen><en> Compare prices from different carriers that offer flights Oslo – Russian Federation and choose the air fare you like most.
<G-vec00106-002-s519><choose.auswählen><de> Vergleichen Sie Tarife für Ho-Chi-Minh-Stadt — Moskau von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s519><choose.auswählen><en> Compare prices from different carriers that offer flights Ho Chi Minh City – Russian Federation and choose the air fare you like most.
<G-vec00106-002-s520><choose.auswählen><de> Wählen Sie außerdem aus, ob Erinnerungen von Terminen des Kalenders angezeigt werden sollen und zu welcher E-Mail-Adresse der Kalender gehört.
<G-vec00106-002-s520><choose.auswählen><en> You can also choose whether reminders of appointments in your calendar should be shown, and which email address the calendar belongs to.
<G-vec00106-002-s521><choose.auswählen><de> Im nächsten Schritt wählen Sie die Dateitypen aus, die Sie wiederherstellen müssen.
<G-vec00106-002-s521><choose.auswählen><en> The next step is for you to choose the file types you need to recover.
<G-vec00106-002-s522><choose.auswählen><de> Vergleichen Sie Tarife für Istanbul — Laibach von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s522><choose.auswählen><en> Compare prices from different carriers that offer flights Istanbul – Slovenia and choose the air fare you like most.
<G-vec00106-002-s523><choose.auswählen><de> Vergleichen Sie Tarife für Chita — Prag von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s523><choose.auswählen><en> Compare prices from different carriers that offer flights Chita – Indonesia and choose the air fare you like most.
<G-vec00106-002-s524><choose.auswählen><de> Vergleichen Sie Tarife für Lyon — Mailand von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s524><choose.auswählen><en> Compare prices from different carriers that offer flights Lyon – Italy and choose the air fare you like most.
<G-vec00106-002-s525><choose.auswählen><de> Vergleichen Sie Tarife für Alicante — Provinz Barcelona von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s525><choose.auswählen><en> Compare prices from different carriers that offer flights Alicante – Spain and choose the air fare you like most.
<G-vec00106-002-s526><choose.auswählen><de> Vergleichen Sie Tarife für Abu Dhabi — London von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s526><choose.auswählen><en> Compare prices from different carriers that offer flights Abu Dhabi – United Kingdom and choose the air fare you like most.
<G-vec00106-002-s527><choose.auswählen><de> Vergleichen Sie Tarife für Dunedin — Auckland von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s527><choose.auswählen><en> Compare prices from different carriers that offer flights Dunedin – New Zealand and choose the air fare you like most.
<G-vec00106-002-s528><choose.auswählen><de> Wählen Sie die gewünschte Kampagne oder Anzeigengruppe aus.
<G-vec00106-002-s528><choose.auswählen><en> Choose the campaign or ad group you want to work with.
<G-vec00106-002-s529><choose.auswählen><de> Vergleichen Sie Tarife für Surgut — Antalya von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s529><choose.auswählen><en> Compare prices from different carriers that offer flights Surgut – Russian Federation and choose the air fare you like most.
<G-vec00106-002-s530><choose.auswählen><de> Vergleichen Sie Tarife für Rio De Janeiro — Panama-Stadt von verschiedenen Fluggesellschaften und wählen den besten aus.
<G-vec00106-002-s530><choose.auswählen><en> Compare prices from different carriers that offer flights Rio De Janeiro – United States and choose the air fare you like most.
<G-vec00106-002-s531><choose.auswählen><de> Individuelle Anfragen nehmen wir gern entgegen und wählen das für Sie passende Fjordpferd in unserem Bestand aus.
<G-vec00106-002-s531><choose.auswählen><en> Furthermore, we are glad to receive the non standart and individual inquiries and choose the most suitable Fjord horse in our stock for you.
<G-vec00106-002-s304><pick.auswählen><de> Einige Lösungen ermöglichen Ihnen sogar die Erstellung von benutzerverantwortlichen Webportalen, in denen Standardbenutzer die zu installierende Software selbst auswählen können.
<G-vec00106-002-s304><pick.auswählen><en> Some solutions even allow you to create self-service Web portals where standard users can pick and choose the software they want to install.
<G-vec00106-002-s305><pick.auswählen><de> Auf der rechten Seite können Sie je nach Ihren Vorlieben Mädchen auswählen.
<G-vec00106-002-s305><pick.auswählen><en> The right side of the page gives you an option to pick girls depending on your preferences.
<G-vec00106-002-s306><pick.auswählen><de> Sie konnten ein Thema auswählen, das zu beiden von Ihnen wi...
<G-vec00106-002-s306><pick.auswählen><en> You could pick a theme that's important to both of you.
<G-vec00106-002-s307><pick.auswählen><de> Danach kannst du auswählen, welches Video oder welcher Song heruntergeladen werden soll und in welcher Qualität du ihn speichern möchtest.
<G-vec00106-002-s307><pick.auswählen><en> This is when you get to pick the video or song that you want to download and the quality you want.
<G-vec00106-002-s308><pick.auswählen><de> Nun da Sie eine Idee aller Unkosten und Überlegungen haben, die mit einer Golfreise kommen, können Sie Ihren Kurs auswählen.
<G-vec00106-002-s308><pick.auswählen><en> Now that you have an idea of all of the expenses and considerations that come with a golf trip, you can pick your course.
<G-vec00106-002-s309><pick.auswählen><de> Ich kann keinen auswählen.
<G-vec00106-002-s309><pick.auswählen><en> I can't pick one.
<G-vec00106-002-s310><pick.auswählen><de> Doch sollte ich ein schwedisches Lieblingsgebäck auswählen, würde ich mich in diesem Jahr für die Zimtschnecke entscheiden.
<G-vec00106-002-s310><pick.auswählen><en> But if I have to pick my own favourite typically Swedish bakery product, it will have to be the cinnamon swirl.
<G-vec00106-002-s311><pick.auswählen><de> Und sonst können Sie einfach den jeweiligen Bonus aus mehreren auf der Website verfügbaren Angeboten auswählen.
<G-vec00106-002-s311><pick.auswählen><en> At other times, you’ll get to simply pick the particular bonus from several offers available on the site.
<G-vec00106-002-s312><pick.auswählen><de> Wenn Sie nach Abfrage bereinigen, müssen Sie eine Abfrage auswählen, deren Ergebnis eine Tabelle mit Ereignissen ist.
<G-vec00106-002-s312><pick.auswählen><en> If you purge by query, you must pick a query that results in a table of events.
<G-vec00106-002-s313><pick.auswählen><de> Um dir beim Auswählen einer starken Gruppe zum Kämpfen zu helfen, werden automatisch basierend auf den Stärken und Schwächen deines Gegners sechs Pokémon für den Kampf vorgeschlagen.
<G-vec00106-002-s313><pick.auswählen><en> To help you pick a strong group to bring to battle, six Pokémon will automatically be recommended to use in the battle based your opponents’ strengths and weaknesses.
<G-vec00106-002-s314><pick.auswählen><de> Die Einzelteile sind in vielen Varianten ohne weiteres verfügbar, so dass Sie bequem auswählen.
<G-vec00106-002-s314><pick.auswählen><en> The items are available in several variations, so you will effortlessly pick it.
<G-vec00106-002-s315><pick.auswählen><de> Mit der Auswahl von Streaming-Diensten wie Spotify Connect, Amazon Prime Music, Deezer und TIDAL können Sie aus Millionen von Songs auswählen und verschiedene Genres und Tracks entdecken, die Sie zu Ihren Playlists hinzufügen können.
<G-vec00106-002-s315><pick.auswählen><en> With the choice of streaming services including Spotify Connect, Amazon Prime Music, Deezer, and TIDAL, you can pick from millions of songs and discover different genres and tracks to add to your playlists.
<G-vec00106-002-s316><pick.auswählen><de> Sie können nur den gewünschten Teil auswählen und wiederherstellen, keine vollständige Wiederherstellung ist erfordlich.
<G-vec00106-002-s316><pick.auswählen><en> You can pick up and recover anything you want only, no need of a blind full restore.
<G-vec00106-002-s317><pick.auswählen><de> Mein Meteorologe Justin schlägt (für iPhone) Weather Underground vor, wo Sie eine Station auf der Karte auswählen und die Bedingungen anzeigen können, über die sie berichtet.
<G-vec00106-002-s317><pick.auswählen><en> My meteorologist friend Justin suggests (for iPhone) Weather Underground, where you can pick a station on the map and see the conditions it’s reporting.
<G-vec00106-002-s318><pick.auswählen><de> Dieses Wissen hilft Ihnen, vollständige Informationen über die besten HGH-Auslöser in Brüssel Belgien zu erhalten, aus denen Sie auswählen können.
<G-vec00106-002-s318><pick.auswählen><en> This knowledge will assist you to get comprehensive details concerning the very best HGH releasers in Brussels Belgium that you could pick from.
<G-vec00106-002-s319><pick.auswählen><de> Unten sehen Sie die Starttermine für Anfängerkurse, damit Sie den Tag auswählen können, der am besten für Ihr Studium geeignet ist.
<G-vec00106-002-s319><pick.auswählen><en> Below you can see the start dates for beginners courses so you can pick the day that suits you best to start your studies.
<G-vec00106-002-s320><pick.auswählen><de> Beim Planen, wann ein Video im Medienmodul verfügbar ist, können Sie jetzt zusätzlich zur vorhandenen Funktion, mit der Sie Daten aus einem Kalender auswählen können, Daten als Text eingeben.
<G-vec00106-002-s320><pick.auswählen><en> When you schedule when a video is available in the Media module, you can now enter dates as text, in addition to the existing feature that lets you pick dates from a calendar.
<G-vec00106-002-s321><pick.auswählen><de> Es gibt viele Einzelhändler für die Ferienzeit, wo Sie ein Geschäft auf der Wii-Konsole auswählen können.
<G-vec00106-002-s321><pick.auswählen><en> There many retailers for the holiday season where you can pick a deal on the wii console.
<G-vec00106-002-s322><pick.auswählen><de> Um dies in der Software widerzuspiegeln, können wir ein anderes Datum im internen Kalender auswählen und den Wert für den Parameter „Vertrauen“ aktualisieren.
<G-vec00106-002-s322><pick.auswählen><en> To reflect this in the software, we can pick another date in the internal calendar and update the value for the “Confidence” parameter.
<G-vec00106-002-s323><pick.auswählen><de> Drei Jahre zuvor hilft Claire ihrem Vater eine Brille auszuwählen.
<G-vec00106-002-s323><pick.auswählen><en> Three years ago, Claire helps her father pick out a pair of glasses.
<G-vec00106-002-s324><pick.auswählen><de> Wir sind immer zur Hand, um freundlichen Rat zu geben und Ihnen zu helfen, die richtige Palettenlagergröße auszuwählen und wie Sie das Beste aus Ihrem Platz machen können.
<G-vec00106-002-s324><pick.auswählen><en> We are always on hand to give friendly advice and help you pick the right pallet storage size and how to make the most of your space.
<G-vec00106-002-s325><pick.auswählen><de> Diese Methode setzt darauf, eine Aufgabe auszuwählen und an ihr zu arbeiten, bis sie abgeschlossen ist, um so die Flow-Kurve so lange wie möglich aufrechtzuerhalten.
<G-vec00106-002-s325><pick.auswählen><en> They argue that the best strategy is to pick a task and then hammer away at it until it’s finished, extending that flow curve as long as possible.
<G-vec00106-002-s326><pick.auswählen><de> Bei 421 Zimmern fällt es schwer einen Favoriten auszuwählen.
<G-vec00106-002-s326><pick.auswählen><en> With 421 rooms it’d be tough to pick a favorite.
<G-vec00106-002-s327><pick.auswählen><de> Wenn dir ein zufälliges GIF nicht gefällt, klicke einfach auf Shuffle (Wechseln), um ein neues auszuwählen.
<G-vec00106-002-s327><pick.auswählen><en> If you don't like a random GIF, click Shuffle to pick a new one.
<G-vec00106-002-s328><pick.auswählen><de> Ziehen Sie die schwarzen Linien entweder nach links oder rechts, um den Teil des Videos auszuwählen, der in Slo-Mo abgespielt werden soll.
<G-vec00106-002-s328><pick.auswählen><en> Drag the black lines either left or right to pick out the part of the video that should play in Slo-Mo.
<G-vec00106-002-s329><pick.auswählen><de> Sie haben auch die Möglichkeit, Ihre Montags-Lottozahlen selbst auszuwählen oder unsere Schnellauswahloption zu nutzen, um die Zahlen für Sie auszuwählen.
<G-vec00106-002-s329><pick.auswählen><en> You can choose your El Gordo de la primitiva numbers yourself or select them randomly using our quick pick option.
<G-vec00106-002-s330><pick.auswählen><de> Eine ausführliche Beratung vor Studienbeginn hilft den zukünftigen Studierenden, das passende Fach auszuwählen und ihren persönlichen Studienweg zu planen: Auch die Finanzierung des Studiums, die Unterbringung während der Studienzeit und weitere Rahmenfaktoren spielen dabei eine wichtige Rolle.
<G-vec00106-002-s330><pick.auswählen><en> Individual consultation is offered in advance to help the students pick the best suitable study program and plan their personal study path: Questions regarding financing, accommodation, and additional framework conditions are covered in detail as well.
<G-vec00106-002-s331><pick.auswählen><de> Dies ist deswegen so, da Docker jeden Container als seinen eigenen virtuellen Host aussortiert, sodass nicht die Notwendigkeit für jeden Container besteht, einen anderen Port auszuwählen.
<G-vec00106-002-s331><pick.auswählen><en> This is because Docker separates out each container as it’s own virtual host so there is no need to pick a different port for each container.
<G-vec00106-002-s332><pick.auswählen><de> Bei den Olympischen Spielen in Rio habe ich geholfen, die Farben für verschiedene Veranstaltungsorte auszuwählen.
<G-vec00106-002-s332><pick.auswählen><en> At the Rio Olympics I helped pick the colours for various venues.
<G-vec00106-002-s333><pick.auswählen><de> Wenn Ihre DNS-Einträge von Office 365 verwaltet werden, verwenden Sie die Option Adresse ändern, um eine andere Domäne auszuwählen.
<G-vec00106-002-s333><pick.auswählen><en> If Office 365 manages your DNS records, use the Change address option to pick a different domain.
<G-vec00106-002-s334><pick.auswählen><de> Klicke eine Prinzessin an, um sie auszuwählen, und klicke dann den leuchtenden rechten Pfeil an, um weiterzumachen.
<G-vec00106-002-s334><pick.auswählen><en> Click to pick a princess, then click the glowing right arrow to continue.
<G-vec00106-002-s335><pick.auswählen><de> Jetcost findet Tausende von Flugangeboten nach Mannheim - Neuostheim und hilft Ihnen, den richtigen für Sie auszuwählen.
<G-vec00106-002-s335><pick.auswählen><en> Jetcost finds thousands of flight deals to Poitiers - Biard and helps you pick the right one for you.
<G-vec00106-002-s336><pick.auswählen><de> Auf einer Karte Orte, Länder oder Regionen auszuwählen wäre auch nützlich, genauso die Möglichkeit, Einstellungen und Orte für später zu speichern.
<G-vec00106-002-s336><pick.auswählen><en> Being able to pick locations from a map would be helpful, too, as would be ways to save configurations and places.
<G-vec00106-002-s337><pick.auswählen><de> Der Brustumfang gilt als Hauptreferenz, um die Größe auszuwählen, die am besten zu Ihnen passt.
<G-vec00106-002-s337><pick.auswählen><en> Mainly the chest size is for reference to pick the size that will fit you the best.
<G-vec00106-002-s338><pick.auswählen><de> Unsere technische Mannschaft wird auch fähig, Ihnen zu helfen, das rechte Material zusammen mit dem Gramm fällig (Basisgewicht) oder Behandlung auszuwählen, wenn solche Notwendigkeit entsteht.
<G-vec00106-002-s338><pick.auswählen><en> Our technical team will also able to help you pick the right material along with the gram mature (basis weight) or treatment if such necessity arises.
<G-vec00106-002-s339><pick.auswählen><de> Letztendlich liegt es an ihnen, auszuwählen, wen sie in ihrem Team haben möchten.
<G-vec00106-002-s339><pick.auswählen><en> Ultimately, it is up to them to pick who they want to add to their team.
<G-vec00106-002-s340><pick.auswählen><de> Eine weitere Option ist, ein Buch auszuwählen, das Sie schon in Ihrer Muttersprache gelesen haben und das Ihnen gefallen hat.
<G-vec00106-002-s340><pick.auswählen><en> Another good option is to pick a book that you have already read and enjoyed in your native language.
<G-vec00106-002-s341><pick.auswählen><de> Mittags können die Gäste leichte Speisen bestellen, während die Küche zum Abendessen ein 4-Gänge-Schlemmermenü bietet, das sich täglich ändert (die Gäste habe die Möglichkeit, nur einige der Gerichte auszuwählen oder vorab mit dem Personal kleinere Änderungen zu vereinbaren).
<G-vec00106-002-s341><pick.auswählen><en> For lunch guests can order a light lunch, while dinner is based on a menu of 4 courses, which varies from day to day (guests may opt to pick just some dishes and ask for small variations, with prior notification to the staff).
<G-vec00106-002-s076><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Espinho Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Espinho auszuwählen.
<G-vec00106-002-s076><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Ovar, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Ovar.
<G-vec00106-002-s077><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Küste Beiras Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Küste Beiras auszuwählen.
<G-vec00106-002-s077><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Coast of Estoril, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Coast of Estoril.
<G-vec00106-002-s078><select.auswählen><de> Gartner spricht keine Empfehlungen für in seinen Publikationen dargestellte Anbieter, Produkte oder Dienstleistungen aus und rät Technologiebenutzern nicht, nur die Anbieter mit den besten Platzierungen oder Bewertungen auszuwählen.
<G-vec00106-002-s078><select.auswählen><en> Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation.
<G-vec00106-002-s079><select.auswählen><de> Wählen Sie in Ihrem Design den Tag h3 aus und wählen Sie in der Seitenleiste "Stil" 1 Absatz aus (um das vordefinierte Format auszuwählen) sowie die Eigenschaftsgruppe Allgemein.
<G-vec00106-002-s079><select.auswählen><en> In your design, select the h3 tag, and, in the Styles sidebar, select 1 paragraph (to select the predefined format), and the common group of properties.
<G-vec00106-002-s080><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Oviedo Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Oviedo auszuwählen.
<G-vec00106-002-s080><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Oviedo, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Oviedo.
<G-vec00106-002-s081><select.auswählen><de> In dieser Atmosphäre nehmen wir uns das Recht, aus den zahlreichen Angeboten auszuwählen, was uns für unser persönliches Leben wichtig und wertvoll scheint.
<G-vec00106-002-s081><select.auswählen><en> In the superabundance of proposals, we take for ourselves the right to select what appears important and useful for our personal life.
<G-vec00106-002-s082><select.auswählen><de> In der herkömmlichen Pflanzen- und Tierzüchtung nutzt der Mensch Verfahren, um die natürliche Mutationsrate zu erhöhen und aus den Mutanten neue Sorten oder Rassen mit nützlichen Eigenschaften auszuwählen.
<G-vec00106-002-s082><select.auswählen><en> In conventional plant cultivation and animal breeding, humans use methods to increase the natural mutation rate so that they can select new varieties or strains with useful properties from among the mutants.
<G-vec00106-002-s083><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Colindres Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Colindres auszuwählen.
<G-vec00106-002-s083><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Mundaka, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Mundaka.
<G-vec00106-002-s084><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Noja Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Noja auszuwählen.
<G-vec00106-002-s084><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Noja, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Noja.
<G-vec00106-002-s085><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Algeciras Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Algeciras auszuwählen.
<G-vec00106-002-s085><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Andorra la Vella, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Andorra la Vella.
<G-vec00106-002-s086><select.auswählen><de> Buchen Sie frühzeitig, um die besten Preise und Verfügbarkeiten zu bekommen; die Silver Privilege-Preise sind so gestaltet, dass Gäste, die früh buchen, von den bestmöglichen Preisen profitieren und außerdem das Privileg haben, sich Ihre gewünschte Suite aus dem vollen Angebot auszuwählen.
<G-vec00106-002-s086><select.auswählen><en> Book early for the best fares and availability; Silver Privilege Fares are structured to reward guests who book early with the best possible fare and the privilege of being able to select their desired suite when the best inventory is available.
<G-vec00106-002-s087><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Canyamel Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Canyamel auszuwählen.
<G-vec00106-002-s087><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Sagunto, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Sagunto.
<G-vec00106-002-s088><select.auswählen><de> Vergessen Sie nicht, das Land, aus dem Sie anrufen, in dem Dropdownmenü auszuwählen, oder geben Sie „+‟ und die Landesvorwahl ein.
<G-vec00106-002-s088><select.auswählen><en> Remember to select the country you're calling from the drop-down, or enter a “+” and then the country code.
<G-vec00106-002-s089><select.auswählen><de> Es reicht nicht aus, ein Land nur nach wirtschaftlichen Gründen auszuwählen, oder weil dort zufällig schon Verwandte wohnen.
<G-vec00106-002-s089><select.auswählen><en> It will not be sufficient to select a country only by economical reasons or because there are already been living relatives by chance.
<G-vec00106-002-s091><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Santander Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Santander auszuwählen.
<G-vec00106-002-s091><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Maidstone, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Maidstone.
<G-vec00106-002-s092><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Lauenburg Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Lauenburg auszuwählen.
<G-vec00106-002-s092><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Glasgow Airport, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Glasgow Airport.
<G-vec00106-002-s093><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Ibiza Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Ibiza auszuwählen.
<G-vec00106-002-s093><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Puerto san Miguel, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Puerto san Miguel.
<G-vec00106-002-s094><select.auswählen><de> Mit Hilfe der Suchmaschine haben Sie die Möglichkeit die verschiedenen Hotelkategorien in Garafia Stadt zu finden und aus den besten Angeboten zu Luxushotels oder den vielseitigen Hotels sowie Hostals in Garafia auszuwählen.
<G-vec00106-002-s094><select.auswählen><en> Our search engine enables you to book any type of hotel in the city of Bahia Feliz, allowing you to select the best offers for either luxury hotels or a wide range of budget hotels and hostels in Bahia Feliz.
<G-vec00106-002-s095><select.auswählen><de> Der Bemessungsfall kann in der Liste Vorhandene Fälle ausgewählt werden.
<G-vec00106-002-s095><select.auswählen><en> You can select the design case in the list of Available Cases.
<G-vec00106-002-s096><select.auswählen><de> Dafür werden 20 Techniker aus aller Welt ausgewählt.
<G-vec00106-002-s096><select.auswählen><en> To do this, they will select 20 technicians from around the world.
<G-vec00106-002-s097><select.auswählen><de> Netzauswahl: Unter Netzauswahl können die verfügbaren Netze des gegenwärtigen Standorts ausgewählt werden.
<G-vec00106-002-s097><select.auswählen><en> Network selection: You can use this function to select the available networks for the current position of the vehicle.
<G-vec00106-002-s098><select.auswählen><de> Wenn eine Nachricht keine Postfachempfänger enthält, wird ein zufälliger Postfachserver am lokalen Active Directory-Standort ausgewählt.
<G-vec00106-002-s098><select.auswählen><en> If the message has no mailbox recipients, select a random Mailbox server in the local Active Directory site.
<G-vec00106-002-s099><select.auswählen><de> Zusätzlich kann ausgewählt werden, ob eine PDF-Datei oder ein XML-Datensatz bei der Weiterverarbeitung genutzt werden soll.
<G-vec00106-002-s099><select.auswählen><en> In addition, you can select whether a PDF file or an XML data record is to be used for further processing.
<G-vec00106-002-s100><select.auswählen><de> Speziell für J1939-Anwendungen steht eine Vielzahl von Testfällen zur Verfügung, die mit Hilfe des Managers ausgewählt und konfiguriert werden.
<G-vec00106-002-s100><select.auswählen><en> Many test cases are available specifically for J1939 applications, and the manager can be used to select and configure them.
<G-vec00106-002-s101><select.auswählen><de> Dieses Whitepaper erläutert anhand von Beispielen aus der Praxis, wie die RF-Komponenten Ihrer Standorte ausgewählt und genutzt werden sollten, um Mobilnetzwerkkapazitäten zu optimieren.
<G-vec00106-002-s101><select.auswählen><en> This paper aims to explain how to select and utilize your sites’ RF components to optimize cellular networks capacities using real-life product examples.
<G-vec00106-002-s102><select.auswählen><de> Hier kann aus vorgegebenen Positionen / Größen ausgewählt werden oder aber es kann eine genaue Position sowie Größe der Box in mm angegeben werden.
<G-vec00106-002-s102><select.auswählen><en> Here you can select from predefined positions / sizes or you can specify an exact position and size of the box (in mm).
<G-vec00106-002-s103><select.auswählen><de> Vergewissern Sie sich bitte, dass Sie alle Optionen ausgewählt haben, wenn Sie buchen.
<G-vec00106-002-s103><select.auswählen><en> Please ensure you select all the options that you require when making your booking.
<G-vec00106-002-s104><select.auswählen><de> Die Schaltflächen „Anwenden und Abbrechen“ für Filter wurden weiterhin angezeigt, auch wenn im Filter keine Elemente ausgewählt waren.
<G-vec00106-002-s104><select.auswählen><en> Apply and Cancel buttons for filters were still displayed even when there were no items to select in the filter.
<G-vec00106-002-s105><select.auswählen><de> Beim Child-Datenband werden die Beziehung und das Parent-Datenband als Hauptkomponente ausgewählt.
<G-vec00106-002-s105><select.auswählen><en> For a child data band, you need to select the relation and the parent data band as the master component.
<G-vec00106-002-s106><select.auswählen><de> Die abgebildeten Bikes auf den Fotos sind Beispiele und zeigen nicht alle Farboptionen und Konfigurationsmöglichkeiten, die ausgewählt und bestellt werden können.
<G-vec00106-002-s106><select.auswählen><en> All pictured products are examples and do not reflect all colours and options that you can select and order. ZEPHYR | PURE COMFORT TECHNOLOGY
<G-vec00106-002-s107><select.auswählen><de> Bei Auswahl eines Programms werden automatisch alle zugehörigen Projekte ausgewählt.
<G-vec00106-002-s107><select.auswählen><en> Selecting a program will also select all associated projects.
<G-vec00106-002-s108><select.auswählen><de> Der Modus NEO:6 kann nicht ausgewählt werden.
<G-vec00106-002-s108><select.auswählen><en> Can't select NEO:6 mode.
<G-vec00106-002-s109><select.auswählen><de> In diesem Drop-down-Menü ist standardmäßig "Kein Datenfeed" ausgewählt.
<G-vec00106-002-s109><select.auswählen><en> This drop-down will select “No data feed” by default
<G-vec00106-002-s110><select.auswählen><de> In der folgenden Abbildung haben wir einen Rechtsklick auf Deluxe ausgeführt und Drilldown ausgewählt.
<G-vec00106-002-s110><select.auswählen><en> In the following image, we right-click on Deluxe and select Drill Down.
<G-vec00106-002-s111><select.auswählen><de> Sobald Sie das Video, das Sie bearbeiten möchten, ausgewählt haben, gehen Sie zum automatisch generierten Miniaturansichtsbereich und klicken Sie auf die Option “Benutzerdefinierte Miniaturansicht”.
<G-vec00106-002-s111><select.auswählen><en> Once you select the video you want to edit, go to the auto-generated thumbnails portion and click on the “Custom thumbnail” option.
<G-vec00106-002-s112><select.auswählen><de> Wenn Sie keinen Algorithmus ausgewählt haben, dient der Suunto EON Steel in diesem Modus als Bottom-Timer.
<G-vec00106-002-s112><select.auswählen><en> If you select no algorithm, Suunto EON Core functions as a gauge (bottom timer) in that mode.
<G-vec00106-002-s113><select.auswählen><de> Sie können Ihre Glückszahlen manuell auswählen oder die Quick Pick-Funktion verwenden, mit der für Sie zufällige Zahlen ausgewählt werden.
<G-vec00106-002-s113><select.auswählen><en> You can choose your lucky numbers manually or use the Quick Pick feature which will select a random set of numbers on your behalf.
<G-vec00106-002-s114><select.auswählen><de> Wenn die Vorlage des Holocaust Assistance Act, der im US Repräsentantenhaus und im Senat derzeit überprüft wird, Zulassung bekäme, würde er landesweit ausgewählte Organisationen mit wettbewerbsfähigen Hilfen versehen, um Holocaustlehrkräfte heranzuziehen, die auch zur Ausbildung von weiteren Lehrern geeignet sind.
<G-vec00106-002-s114><select.auswählen><en> Currently being reviewed by committees in the U.S. House of Representatives and Senate, the Simon Wiesenthal Holocaust Education Assistance Act - if passed - would provide select organizations nationwide with competitive grants to be used to develop Holocaust curriculum guides as well as training for teachers.
<G-vec00106-002-s115><select.auswählen><de> Erleben Sie immersiven Klang mit Dolby Atmos für ausgewählte Prime Video-Titel.
<G-vec00106-002-s115><select.auswählen><en> Experience immersive sound with Dolby Atmos on select Prime Video titles.
<G-vec00106-002-s116><select.auswählen><de> Zu diesen Zwecken können die Daten an die Daimler AG, deren jeweilige nationale Vertriebsgesellschaft, ausgewählte Händler/Servicepartner innerhalb der Daimler Vertriebs- und Serviceorganisation, die Mercedes-Benz Museum GmbH und Marktforschungsinstitute übermittelt werden.
<G-vec00106-002-s116><select.auswählen><en> For these purposes, the data may also be transferred to Daimler AG, the respective national sales company, select dealers/service partners within the Daimler Sales and Service Organization, Mercedes-Benz Museum GmbH and market research institutes.
<G-vec00106-002-s117><select.auswählen><de> Sie beinhalten für die jeweiligen Anwendungsfälle ausgewählte und bereits vorkonfektionierte Komponenten.
<G-vec00106-002-s117><select.auswählen><en> They include select and ready-prepared components for the respective application cases (Figure 3).
<G-vec00106-002-s118><select.auswählen><de> Auf den dritten Innovation Days in München stellen die führenden deutschen Forschungsorganisationen – Max-Planck-Gesellschaft, Fraunhofer-Gesellschaft, Helmholtz-Gemeinschaft und Leibniz-Gemeinschaft – ausgewählte Technologien und Spin-off-Projekte aus den Bereichen Life Sciences und Chemical & Physical Sciences vor.
<G-vec00106-002-s118><select.auswählen><en> At the third Innovation Days in Munich, the leading German research organizations Max Planck Society, the Fraunhofer-Gesellschaft, Helmholtz Association and Leibniz Association will be presenting select technologies and spin-off projects from the fields of life sciences and chemical & physical sciences. continue
<G-vec00106-002-s119><select.auswählen><de> Ausgewählte Hotels in der Innenstadt von Vancouver und in Richmond (Flughafen).
<G-vec00106-002-s119><select.auswählen><en> Select hotels in the Downtown Vancouver and Richmond (Airport) areas.
<G-vec00106-002-s120><select.auswählen><de> Jedes ausgewählte Produkt unseres Gebäudes muss Ausdruck unserer Verpflichtung sein, nur das Beste zu liefern.
<G-vec00106-002-s120><select.auswählen><en> Every product we select for our building needs to be an expression of our commitment to delivering only the very best.
<G-vec00106-002-s121><select.auswählen><de> Ausgewählte Standorte, unverwechselbare Architektur, fortschrittlichste Bauweise und modernste Technologien zeichnen die Objekte von Concept Bau aus.
<G-vec00106-002-s121><select.auswählen><en> Select locations, distinctive architecture, advanced building methods and modern technology characterize Concept Bau’s properties.
<G-vec00106-002-s122><select.auswählen><de> Wenn es nur ein Bild gibt oder wenn Sie ausgewählte Bilder auswählen möchten, müssen Sie darauf tippen und es wird automatisch als "ausgewählt" markiert.
<G-vec00106-002-s122><select.auswählen><en> If there is only one picture or if you want to choose select pictures you have to tap and it will be marked automatically as "selected".
<G-vec00106-002-s123><select.auswählen><de> Während dieser Führung können Sie drei ausgewählte Weine, darunter einen Wein am Fass, probieren.
<G-vec00106-002-s123><select.auswählen><en> During this guided tour, you can taste three select wines, including one at the cask.
<G-vec00106-002-s124><select.auswählen><de> Auf über 200 Quadratmetern, verteilt auf zwei Etagen, erwarten unsere handgefertigten Herren- und Damenschuhe sowie ausgewählte Accessoires und Pflegeprodukte Schuhliebhaber aus Münster und Umgebung.
<G-vec00106-002-s124><select.auswählen><en> Spread out over 200 square meters and two floors, our handcrafted men’s and women’s shoes, as well as select accessories and care products, await shoe lovers from Münster and the surrounding area.
<G-vec00106-002-s125><select.auswählen><de> Die MGH Constitutiones et acta publica veröffentlichen ausgewählte Texte, das sind Privilegien, Mandate und Briefe des Herrschers sowie Schriftstücke kurfürstlicher, fürstlicher und städtischer Urheber, die ohne thematische Einschränkung offen sind für alle möglichen Fragen der Forschung.
<G-vec00106-002-s125><select.auswählen><en> The MGH Constitutiones et acta publica publish select texts, namely privileges, mandates and letters of the ruler and documents produced by electors, princes and cities, which, without thematic limitation, are open for all possible research questions.
<G-vec00106-002-s126><select.auswählen><de> Zwischen 1991 und 1994 stellten die beiden etwa 150 Indoorcycling-Bikes für ausgewählte Fitnessstudios in Los Angeles und New York her.
<G-vec00106-002-s126><select.auswählen><en> Between 1991 and 1994, the two manufactured approximately 150 indoor cycling bikes that went to select studios and gyms in Los Angeles and New York.
<G-vec00106-002-s127><select.auswählen><de> Ausgewählte Suiten bieten ein Queensize-Schlafsofa.
<G-vec00106-002-s127><select.auswählen><en> Select suites offer queen sofabed.
<G-vec00106-002-s128><select.auswählen><de> LTE und VoLTE sind in ausgewählten Ländern und über ausgewählte Anbieter verfügbar.
<G-vec00106-002-s128><select.auswählen><en> LTE is available in select markets and through select carriers.
<G-vec00106-002-s129><select.auswählen><de> Für ausgewählte Länder ist bei Lieferung keine weitere Zahlung nötig.
<G-vec00106-002-s129><select.auswählen><en> Select countries will have no additional payment required upon delivery.
<G-vec00106-002-s130><select.auswählen><de> Kit 4059 Flush Railing - Passgenaues Adapter-Kit zur Montage eines Thule Dachträgersystems für ausgewählte Fahrzeuge.
<G-vec00106-002-s130><select.auswählen><en> Kit 1109 - Custom adapter kit for mounting a Thule roof rack system to select vehicles.
<G-vec00106-002-s131><select.auswählen><de> Dies stellt die höchste zu vergebende Auszeichnung im Bereich des thermischen Spritzens dar und wird nur an besonders verdiente, ausgewählte Personen vergeben.
<G-vec00106-002-s131><select.auswählen><en> This is the highest honour awarded in the field of thermal spraying and is only conferred on a select few who have made significant contributions in the area.
<G-vec00106-002-s132><select.auswählen><de> Sie können sich auch Trailer für ausgewählte Videos anschauen.
<G-vec00106-002-s132><select.auswählen><en> You can also view trailers for select videos.
<G-vec00106-002-s133><select.auswählen><de> Die Kalender sind im Moleskine Store bei Moleskine US und in ausgewählten Geschäften weltweit erhältlich.
<G-vec00106-002-s133><select.auswählen><en> The diaries are available at the Moleskine Store, Moleskine US and in select stores around the world.
<G-vec00106-002-s134><select.auswählen><de> Abgeholt werden Sie von einem der ausgewählten Hotels und Sie genießen ein Papsttums-Gespräch mit Ihrem Reiseleiter als Teil der Erfahrung.
<G-vec00106-002-s134><select.auswählen><en> Get picked up from one of a select group of hotels and enjoy a papacy discussion with your tour escort as part of the experience.
<G-vec00106-002-s135><select.auswählen><de> Er wird sich auf Schlüsselbeziehungen zu sehr vermögenden Kunden in der Schweiz und in ausgewählten internationalen Märkten konzentrieren und den weiteren Ausbau dieses Geschäfts unterstützen.
<G-vec00106-002-s135><select.auswählen><en> He will concentrate on key relationships with ultra high net worth individuals in Switzerland and select international markets, and support the ongoing expansion of that business.
<G-vec00106-002-s136><select.auswählen><de> Diese sehen sich als Teil der wenigen Ausgewählten verpflichtet, sich umfassend zu informieren und Gutes für die Gesellschaft zu tun.
<G-vec00106-002-s136><select.auswählen><en> As part of the select few, they feel obliged to inform themselves comprehensively and do good for society.
<G-vec00106-002-s137><select.auswählen><de> Für einen Preis von 100 US-Dollar erhalten Sie den Nike Air Force 1 Low Particle Pink für Damen in ausgewählten Nike Stores und online.
<G-vec00106-002-s137><select.auswählen><en> Retailing for $130, look for this women’s Nike Air Max 90 Premium at select Nike stores and online today.
<G-vec00106-002-s138><select.auswählen><de> Die meisten Pflanzer die Jacks sukulente, supergrossen Blütenkelche schwellen und reifen gesehen haben, werden zögern, diese Buds zu verkaufen, und darum wird das Beste von Jack Herer meistens nur innerhalb eines ausgewählten Freundeskreises - eines der Dinge eben, die man mit Geld nicht kaufen kann.
<G-vec00106-002-s138><select.auswählen><en> Most growers who have watched their succulent, super-sized calyxes swell and mature will be hesitant to sell such buds, and the best Jack Herer is often passed around a select circle of friends - an example of one of those things that money just can’t buy.
<G-vec00106-002-s139><select.auswählen><de> *Der Concierge Club steht exklusiv unseren Diamond Plus und Pinnacle Crown & Anchor Society Mitgliedern und ausgewählten Suite-Gästen offen.
<G-vec00106-002-s139><select.auswählen><en> **Concierge Club reserved for Diamond Plus and Pinnacle Crown & Anchor Society members, and select suite guests.
<G-vec00106-002-s140><select.auswählen><de> Hinweis: Der Lebenslauf-Assistent steht derzeit in Word 2016 für Windows in ausgewählten Ländern/Regionen zur Verfügung; wir beabsichtigen aber, ihn zukünftig auf weiteren Märkten und Plattformen zu veröffentlichen.
<G-vec00106-002-s140><select.auswählen><en> Note: Resume Assistant is currently available in Word 2016 for Windows in select countries/regions, but we're planning to release it to more markets and platforms in the future.
<G-vec00106-002-s141><select.auswählen><de> Das Angebot gilt nur auf ausgewählten Abfahrten.
<G-vec00106-002-s141><select.auswählen><en> Offer only valid on select sailings.
<G-vec00106-002-s142><select.auswählen><de> Die bibliophile Publikation versammelt Dantos Essays zu Scullys Œuvre erstmals in einem Band und begleitet die Texte mit ausgewählten Illustrationen – Gemälden, Fotografien und Zeichnungen des Malers.
<G-vec00106-002-s142><select.auswählen><en> The bibliophile publication assembles Danto’s essays on Scully’s body of work for the time in one volume, and combines them with select illustrations—paintings, photographs, and drawings by the painter.
<G-vec00106-002-s143><select.auswählen><de> Air Transat bietet Flüge nach Vancouver von ausgewählten kanadischen Flughäfen.
<G-vec00106-002-s143><select.auswählen><en> Air Transat offers flights to Madrid from select Canadian airports.
<G-vec00106-002-s144><select.auswählen><de> Jegliche Liquidationsbeträge, die am Fälligkeitstag nicht bezahlt werden, werden als unbezahlte Liquidationsbeträge betrachtet und mit dem durchschnittlich von den wichtigsten Banken im Londoner Interbanken-Markt um 11 Uhr morgens (Londoner Zeit) angebotenen Zinssatz für Tagesgelder in der jeweiligen Währung (oder, falls ein solcher Zinssatz nicht verfügbar ist, mit einem von uns nach billigem Ermessen ausgewählten Zinssatz) plus 1% pro Jahr für jeden Tag, an dem ein solcher Betrag unbezahlt bleibt, verzinst.
<G-vec00106-002-s144><select.auswählen><en> Any Liquidation Amount not paid on the due date shall be treated as an unpaid such amount and bear interest, at the average rate at which overnight deposits in the currency of such payment are offered by major banks in the London interbank market as of 11.00 am (London time) (or, if no such rate is available, at such reasonable rate as we may select) plus one 1% per annum for each day for which such amount remains unpaid.
<G-vec00106-002-s145><select.auswählen><de> Das all inklusive Hotel bietet ausgewählten gastronomischen Service und ein aufregendes Tag- und Nachtprogramm.
<G-vec00106-002-s145><select.auswählen><en> The hotel The all-inclusive hotel offers select gastronomic services and an exciting daytime and night-time programme.
<G-vec00106-002-s146><select.auswählen><de> Schon heute nutzen Mobilfunkbetreiber auf der ganzen Welt die Hotspot-2.0-Technologie, um automatisch Endgeräte zu konfigurieren, die sich mit den erforderlichen Verschlüsselungsprotokollen und ohne jegliche Benutzerinteraktion mit ausgewählten WLAN-Netzwerken an Flughäfen, Hotels und anderen Orten verbinden.
<G-vec00106-002-s146><select.auswählen><en> Today, mobile network operators all over the world use Hotspot 2.0 technology to automatically configure consumer devices to connect to select Wi-Fi networks at airports, hotels and other venues using the necessary encryption protocols and without any user interaction.
<G-vec00106-002-s147><select.auswählen><de> Wer digital vorbestellt oder seine Vorbestellung bei ausgewählten Händlern mit einer Anzahlung aufgibt, erhält außerdem Zugang zum laufenden Betatest von Legacy of the Void.
<G-vec00106-002-s147><select.auswählen><en> Those who pre-purchase digitally or lock in their pre-order at select retailers will also gain entry to the ongoing Legacy of the Void beta test.
<G-vec00106-002-s148><select.auswählen><de> Für das anspruchvollste Publikum ausgelegt, befindet sich ein Luzushotel in Baños dank der besten ausgewählten Preise nun in unmitelbarer Reichweite für jedermann.
<G-vec00106-002-s148><select.auswählen><en> In all cases, targeted at a more demanding public, a luxury hotel in Pesaro is now accessible to anyone, since we select the best prices.
<G-vec00106-002-s149><select.auswählen><de> HomePod wird in Apple Stores, über apple.com, die Apple Store-App und bei ausgewählten autorisierten Apple-Vertriebspartnern erhältlich sein.
<G-vec00106-002-s149><select.auswählen><en> HomePod will be available in Apple Stores, apple.com, the Apple Store app and at select Apple Authorised Resellers.
<G-vec00106-002-s150><select.auswählen><de> Veröffentlichungen Die Capa Stiftung zählt zu ihren Projekten die Erstellung einer ausgewählten Bibliografie als Teil der Verbreitungsdynamik der zeitgenössischen Bildhauerei, für welche sie an der Koordinierung verschiedenen fachlicher Veröffentlichungen teilgenommen hat.
<G-vec00106-002-s150><select.auswählen><en> Publications The Capa Foundation's projects include the creation of a select library collection as a dynamic means of spreading awareness about contemporary sculpture; to which end it has taken part in coordinating a wide variety of specific publications.
<G-vec00106-002-s151><select.auswählen><de> Im Gegensatz zu anderen Programmen, wo Prämien nur auf ausgewählten Flügen zu bestimmten Zeiten eingesetzt werden können, erlaubt „Beyond Business by Qatar Airways“ Geschäftsreisenden Qrewards auf jedem Flug, mit verfügbaren Plätzen, einzulösen.
<G-vec00106-002-s151><select.auswählen><en> Unlike other programmes where redemptions are permitted only on select flights at select times, 'Beyond Business by Qatar Airways' enables businesses to redeem Qrewards on any flight with available seats.
<G-vec00106-002-s171><select.auswählen><de> (3) Der Kunde kann nach einer erfolgreichen Registrierung und Anmeldung entsprechend Absatz 2 aus dem Sortiment des Onlineshops Waren auswählen und diese über den Button,,Ausgewählte in den Warenkorb'' in dem so genannten,,Warenkorb'' sammeln.
<G-vec00106-002-s171><select.auswählen><en> (3) The customer can, after the registration outlined in paragraph 2, select goods from the Onlineshop and place them with the button „Move selected products to the basket“ and collect them in the so called „basket“.
<G-vec00106-002-s172><select.auswählen><de> Die wichtigsten Informationen sollten erhalten bleiben, wenn es für Sie jedoch wichtig ist, dass die Datei nach der Konvertierung von DOTX in WPS identisch bleibt, müssen Sie überlegt vorgehen und eine entsprechende Applikation aus der Liste unten auswählen.
<G-vec00106-002-s172><select.auswählen><en> The most important information should be stored but if you want that this file after conversion from DOTX to DOTM was the same, you need to do it carefully and select the proper application from the list below.
<G-vec00106-002-s173><select.auswählen><de> Die wichtigsten Informationen sollten erhalten bleiben, wenn es für Sie jedoch wichtig ist, dass die Datei nach der Konvertierung von JPG in JP2 identisch bleibt, müssen Sie überlegt vorgehen und eine entsprechende Applikation aus der Liste unten auswählen.
<G-vec00106-002-s173><select.auswählen><en> The most important information should be stored but if you want that this file after conversion from RAW to JP2 was the same, you need to do it carefully and select the proper application from the list below.
<G-vec00106-002-s174><select.auswählen><de> Die wichtigsten Informationen sollten erhalten bleiben, wenn es für Sie jedoch wichtig ist, dass die Datei nach der Konvertierung von CMX in EPS identisch bleibt, müssen Sie überlegt vorgehen und eine entsprechende Applikation aus der Liste unten auswählen.
<G-vec00106-002-s174><select.auswählen><en> The most important information should be stored but if you want that this file after conversion from CMX to PDF was the same, you need to do it carefully and select the proper application from the list below.
<G-vec00106-002-s175><select.auswählen><de> Sie können mehrere Bilder auswählen, wenn Sie es wünschen.
<G-vec00106-002-s175><select.auswählen><en> You can select multiple images if you wish.
<G-vec00106-002-s176><select.auswählen><de> Spalten, die das Auswählen von Informationen vereinfachen, die bereits auf der Website gespeichert sind.
<G-vec00106-002-s176><select.auswählen><en> Columns that make it easy for you to select information that's already stored on a site.
<G-vec00106-002-s177><select.auswählen><de> Die wichtigsten Informationen sollten erhalten bleiben, wenn es für Sie jedoch wichtig ist, dass die Datei nach der Konvertierung von FB2 in RB identisch bleibt, müssen Sie überlegt vorgehen und eine entsprechende Applikation aus der Liste unten auswählen.
<G-vec00106-002-s177><select.auswählen><en> The most important information should be stored but if you want that this file after conversion from FB2 to HTMLZ was the same, you need to do it carefully and select the proper application from the list below.
<G-vec00106-002-s178><select.auswählen><de> Nach Fertigstellung des Inhalts kann der Kunde die Verbreitungskanäle (Papier, E-Mail, Textnachricht, Fax) auswählen und den Auftrag weitergeben.
<G-vec00106-002-s178><select.auswählen><en> Upon completion of the content, the customer is able to select the distribution channel (paper, e-mail, text message, fax) and submit the request for further internal processing.
<G-vec00106-002-s179><select.auswählen><de> Zunächst müssen Sie das gesamte Agenda-Element auswählen.
<G-vec00106-002-s179><select.auswählen><en> First, you need to select the whole agenda element.
<G-vec00106-002-s180><select.auswählen><de> Die wichtigsten Informationen sollten erhalten bleiben, wenn es für Sie jedoch wichtig ist, dass die Datei nach der Konvertierung von BONK in WAV identisch bleibt, müssen Sie überlegt vorgehen und eine entsprechende Applikation aus der Liste unten auswählen.
<G-vec00106-002-s180><select.auswählen><en> The most important information should be stored but if you want that this file after conversion from BONK to FLAC was the same, you need to do it carefully and select the proper application from the list below.
<G-vec00106-002-s181><select.auswählen><de> Pro-Tipp: Wenn Sie die Ergebnisse für einen bestimmten Zeitraum anzeigen möchten, können Sie zunächst ein Rechnungssegment für diesen Zeitraum erstellen und es hier auswählen.
<G-vec00106-002-s181><select.auswählen><en> Pro-tip: if you want to see the results for a certain period of time then you can create a segment of invoices from this period first and select it here.
<G-vec00106-002-s182><select.auswählen><de> Die Vorgesetzten können einen PC oder ein Smartphone oder beides für die Aufzeichnung der Zeiten der Mitarbeiter auswählen.
<G-vec00106-002-s182><select.auswählen><en> Setting punching restriction Managers can select a PC or smartphone or both to record the time of employees.
<G-vec00106-002-s183><select.auswählen><de> Die wichtigsten Informationen sollten erhalten bleiben, wenn es für Sie jedoch wichtig ist, dass die Datei nach der Konvertierung von ISZ in MDF identisch bleibt, müssen Sie überlegt vorgehen und eine entsprechende Applikation aus der Liste unten auswählen.
<G-vec00106-002-s183><select.auswählen><en> The most important information should be stored but if you want that this file after conversion from MDF to ISO was the same, you need to do it carefully and select the proper application from the list below.
<G-vec00106-002-s184><select.auswählen><de> Nach Ihrer Reservierung erhalten Sie eine E-Mail, in der Sie Ihre Zeitfenster für die Sagrada Familia und den Park Güell auswählen können.
<G-vec00106-002-s184><select.auswählen><en> After your reservation you will receive an email where you can select your timeslots for the Sagrada Familia and Park Güell.
<G-vec00106-002-s185><select.auswählen><de> Um einen neuen Term hinzuzufügen, für den es bereits einen Eintrag und somit mindestens auch schon einen Term in einer anderen oder derselben Sprache gibt, müssen Sie zunächst den entsprechenden Eintrag oder Term auswählen.
<G-vec00106-002-s185><select.auswählen><en> To add a new term for which an entry and therefore at least one term already exists in the same or another language, you must first select the respective entry or term.
<G-vec00106-002-s186><select.auswählen><de> Zu diesem Zweck werden wir den jeweiligen Dienstleister sorgfältig auswählen, mit diesem einen Vertrag zur Auftragsverarbeitung gemäß Art.
<G-vec00106-002-s186><select.auswählen><en> For this purpose, we will carefully select the respective service provider, agree with this contract processing contract according to Art.
<G-vec00106-002-s187><select.auswählen><de> Für diese Startadressen können Sie eine Crawlregel erstellen und ein Konto mit Zugriff auswählen.
<G-vec00106-002-s187><select.auswählen><en> For those start addresses, you can create a crawl rule and select an account that does have access.
<G-vec00106-002-s188><select.auswählen><de> In der linken Spalte kannst du die entsprechenden Buchungen auswählen (egal ob storniert oder bereits ausgecheckt).
<G-vec00106-002-s188><select.auswählen><en> In the left column, select the checked-out or cancelled bookings you would like to take action on.
<G-vec00106-002-s189><select.auswählen><de> In diesem Fall müssen Sie die Buchung auswählen, für die Sie einchecken möchten.
<G-vec00106-002-s189><select.auswählen><en> In this case, you have to select the booking you want to check-in for.
<G-vec00106-002-s190><select.auswählen><de> Um Ihre Flüge Mirny auszuwählen, schreiben Sie oben in das Feld "Abflugsort" den Namen der Stadt, von der aus Sie abfliegen möchten und in "Flugziel" Mirny.
<G-vec00106-002-s190><select.auswählen><en> To select your flights Kazan, type the name of the city you wish to depart from in the Departure box and write Kazan in the Arrival field.
<G-vec00106-002-s191><select.auswählen><de> Um das Spiel The Fury kostenlos herunterzuladen, empfehlen wir Ihnen, das Modell des Geräts auszuwählen und das System wird für Sie die am besten geeigneten Spiel-Dateien für Die Wut aussuchen.
<G-vec00106-002-s191><select.auswählen><en> Shooter To download Playman. Extreme Running free java game, we recommend you to select your phone model, and then our system will choose the most suitable game files.
<G-vec00106-002-s192><select.auswählen><de> Um Ihre Flüge Sachsen Anhalt auszuwählen, schreiben Sie oben in das Feld "Abflugsort" den Namen der Stadt, von der aus Sie abfliegen möchten und in "Flugziel" Sachsen Anhalt.
<G-vec00106-002-s192><select.auswählen><en> To select your flights Saxony Anhalt, type the name of the city you wish to depart from in the Departure box and write Saxony Anhalt in the Arrival field.
<G-vec00106-002-s193><select.auswählen><de> Um das Spiel Petz kostenlos herunterzuladen, empfehlen wir Ihnen, das Modell des Geräts auszuwählen und das System wird für Sie die am besten geeigneten Spiel-Dateien für Haustiere aussuchen.
<G-vec00106-002-s193><select.auswählen><en> Online Shooter To download Woody Woodpecker in Waterfools free java game, we recommend you to select your phone model, and then our system will choose the most suitable game files.
<G-vec00106-002-s194><select.auswählen><de> CAPTURE Atlas bietet eine neue Produktstruktur deren Features übersichtlicher gestaltet sind und die es dem Anwender noch einfacher machen die richtige Edition auszuwählen.
<G-vec00106-002-s194><select.auswählen><en> CAPTURE Atlas offers a new product structure whose features are clearer and make it easier for the user to select the right edition.
<G-vec00106-002-s195><select.auswählen><de> Besonders hervorgehoben wurde eine der wichtigsten Eigenschaften von Axxon Intellect – die Fähigkeit zur Unterstützung von Ausrüstungen verschiedener Hersteller und somit die Möglichkeit, die für jedes konkrete Objekt optimalen Geräte auszuwählen.
<G-vec00106-002-s195><select.auswählen><en> One of Axxon Intellect's important features was especially noted: its ability to support equipment from various manufacturers, which allows one to select the optimal devices for each specific site.
<G-vec00106-002-s196><select.auswählen><de> Hinweis: Wenn Sie versuchen, Text in einer gescannten PDF-Datei auszuwählen, bei der keine Texterkennung mit OCR durchgeführt wurde, oder sich eine Bilddatei laut vorlesen zu lassen, werden Sie von Acrobat gefragt, ob die Texterkennung an dieser Stelle durchgeführt werden soll.
<G-vec00106-002-s196><select.auswählen><en> Note: If you try to select text in a scanned PDF that does not have OCR applied, or try to perform a Read Out Loud operation on an image file, Acrobat asks if you want to run OCR.
<G-vec00106-002-s197><select.auswählen><de> Aktivieren oder Deaktivieren des Kamerablitzes Tippen Sie auf das Blitz-Symbol, um eine Blitzeinstellung auszuwählen.
<G-vec00106-002-s197><select.auswählen><en> On the Viewfinder screen, touch the flash icon to select a camera flash mode depending on your lighting conditions.
<G-vec00106-002-s198><select.auswählen><de> Um das Spiel Alloy Storm kostenlos herunterzuladen, empfehlen wir Ihnen, das Modell des Geräts auszuwählen und das System wird für Sie die am besten geeigneten Spiel-Dateien für Alloy Storm aussuchen.
<G-vec00106-002-s198><select.auswählen><en> Shooter To download Alloy Storm free java game, we recommend you to select your phone model, and then our system will choose the most suitable game files.
<G-vec00106-002-s199><select.auswählen><de> Ziehen Sie die Markierungslinien zurecht, um den Bereich des Bildes auszuwählen, den Sie behalten möchten, und lassen Sie die Teile, die Sie entfernen möchten, weg.
<G-vec00106-002-s199><select.auswählen><en> Drag the marquee lines to select the area of the image you want to keep and leave out the parts you want to take off.
<G-vec00106-002-s200><select.auswählen><de> Um alle Blasen auszuwählen, wählen Sie den Befehl Alle auswählen.
<G-vec00106-002-s200><select.auswählen><en> Choose the Select All command to select all bubbles.
<G-vec00106-002-s201><select.auswählen><de> Sie können per Drag & Drop eine oder mehrere ausgewählte PDF-Dateien an die Schnittstelle des Programms bringen oder gehen Sie zu "Datei" & “PDF-Dateien hinzufügen ", um PDF-Datei(en) im Popup-Dialog auszuwählen.
<G-vec00106-002-s201><select.auswählen><en> You may drag and drop one or multiple selected PDF files to the interface of the program, or go to "File”> Add PDF Files" to select PDF file(s) in the popup dialog.
<G-vec00106-002-s202><select.auswählen><de> Wir können Ihnen helfen, die richtige Technologie auszuwählen und ein System zu entwickeln, das mit den Vorschriften konform ist und Ihrem Budget und Zeitplan entspricht.
<G-vec00106-002-s202><select.auswählen><en> We can help you select the right technology and build a system which is compliant and stays within your budget and timeline.
<G-vec00106-002-s203><select.auswählen><de> Wenn Sie Ihre Zahlen registrieren, erscheint das Sofortgewinnspiel, in dem Sie aufgefordert werden, eines von vier Bullaugen auszuwählen.
<G-vec00106-002-s203><select.auswählen><en> When you submit your entry, the instant win game appears asking you to select one of four portholes.
<G-vec00106-002-s204><select.auswählen><de> Diese Information hilft uns, die Embryonen auszuwählen, die zu gesunden Babys führen.
<G-vec00106-002-s204><select.auswählen><en> This information helps us to select the embryos that will lead to the birth of a healthy child.
<G-vec00106-002-s205><select.auswählen><de> Das TMS-Netzwerk bietet seinen Benutzern die Möglichkeit, Inbound- / Outbound-Aufträge zu verwalten und zu kontrollieren, Ladungen zu optimieren, die besten Carrier auszuwählen, Sendungen auszuschreiben, Paket-,LTL- und TL-Ladeverzeichnisse zu erstellen, Fortschritte zu verfolgen und Forderungen zu verwalten.
<G-vec00106-002-s205><select.auswählen><en> The TMS system gives users the ability to manage and control inbound / outbound orders, optimise loads, select the best carriers, tender the shipments, manifest parcel, FTL, groupage, track the progress and manage claims.
<G-vec00106-002-s206><select.auswählen><de> Gehen Sie zum unteren Teil der Hauptoberfläche und klicken auf den „Ordner“, um ein Verzeichnis zum Speichern der Ausgabe Audiodatei auszuwählen.
<G-vec00106-002-s206><select.auswählen><en> Move to the bottom of the main interface and click the “folder” to select an output directory to save the audio file.
<G-vec00106-002-s207><select.auswählen><de> Die positiven Erfahrungen aus früheren gemeinsamen Projekten sowie auch die modernen Technologien von ANDRITZ, die für sicheren Betrieb und hohe Verfügbarkeit des Zellstoffwerks sorgen, waren die Hauptgründe für Sun Paper, ANDRITZ als Lieferanten wichtiger Technologien für das neue Zellstoffwerk auszuwählen.
<G-vec00106-002-s207><select.auswählen><en> The main reasons for Sun Paper to select ANDRITZ as supplier of main technologies for its new pulp mill were both the positive experience from previous joint projects and the state-of-the-art technologies supplied by ANDRITZ to ensure reliable operation and high availability of the pulp mill.
<G-vec00106-002-s208><select.auswählen><de> Verwenden Sie die Pfeiltasten, um in WordArt das gewünschte Format auszuwählen, und drücken Sie dann die EINGABETASTE.
<G-vec00106-002-s208><select.auswählen><en> Use the arrow keys to select the WordArt style that you want, and then press ENTER.
<G-vec00106-002-s342><select.auswählen><de> Zum einen können Sie ein vordefiniertes Messfenster für die Belichtungssteuerung auswählen.
<G-vec00106-002-s342><select.auswählen><en> Exposure Window Select one of the predefined exposure windows to adjust the exposure control.
<G-vec00106-002-s343><select.auswählen><de> Ja, abhängig von der Verwendung können Sie eine geeignete Stahlsorte auswählen.
<G-vec00106-002-s343><select.auswählen><en> Yes, depending on the intended use, you can select a suitable type of steel.
<G-vec00106-002-s344><select.auswählen><de> Unter „Wiederholen “ können Sie auswählen, ob der Termin mehrmals wiederholt werden soll.
<G-vec00106-002-s344><select.auswählen><en> Under "Repeat" you can select whether the appointment should be repeated multiple times.
<G-vec00106-002-s345><select.auswählen><de> In der erscheinenden Liste der installierten Programme können Sie Browser-Security.site finden und auswählen und auf die Schaltfläche Deinstallieren klicken.
<G-vec00106-002-s345><select.auswählen><en> Then after, you can select Browser-Updater.co pop-up and its associated annoying programs and click on Uninstall button.
<G-vec00106-002-s346><select.auswählen><de> Dort können Sie einen Satelliten nach ihrem Geschmack auswählen.
<G-vec00106-002-s346><select.auswählen><en> You’ll be able to select a satellite to your liking there.
<G-vec00106-002-s347><select.auswählen><de> Verwenden Sie die Maus, um Kleidung und Farben auswählen.
<G-vec00106-002-s347><select.auswählen><en> Use the mouse to select clothes and colors.
<G-vec00106-002-s348><select.auswählen><de> Wenn Sie bei früheren Bestellungen bereits eine Adresse gespeichert haben, dann können Sie diese auswählen.
<G-vec00106-002-s348><select.auswählen><en> If you have saved different addresses on previous orders, you are able to select one of them.
<G-vec00106-002-s349><select.auswählen><de> Klicken Sie mit der rechten Maustaste auf das Menü, das zuerst das Suchsystem (die Zeile "Suchen") auswählen soll, und geben Sie dann den abgekürzten Namen des Dienstes ein - perfmon.
<G-vec00106-002-s349><select.auswählen><en> Right click the menu, which should first select the search system (the "Find" line), then enter the abbreviated name of the service - perfmon.
<G-vec00106-002-s350><select.auswählen><de> Wenn Sie sie auswählen, ist die Hauptsache, den Stil anzupassen.
<G-vec00106-002-s350><select.auswählen><en> When you select them, the main thing is to match the style.
<G-vec00106-002-s351><select.auswählen><de> A: Hier können Sie verschiedene Umgebungen für die Echoeffekte auswählen.
<G-vec00106-002-s351><select.auswählen><en> 9 Effects Open the effects page A: Select different environments for echo effects.
<G-vec00106-002-s352><select.auswählen><de> Während Sie Ihr Blog erstellen, müssen Sie eine URL für Ihr Blog auswählen.
<G-vec00106-002-s352><select.auswählen><en> During the blog creation process, you'll have to select a URL for your blog.
<G-vec00106-002-s353><select.auswählen><de> Dann können Sie einen Durchflussbegrenzer auswählen, der den richtigen Druckabfallbereich für Ihre Anlage aufweist.
<G-vec00106-002-s353><select.auswählen><en> You will then be able to select a valve with the appropriate pressure differential range for your application.
<G-vec00106-002-s354><select.auswählen><de> Falls Sie den gesamten Text konvertieren möchten, gehen Sie einfach auf „Alles auswählen“ in der Registerkarte „Bearbeiten“.
<G-vec00106-002-s354><select.auswählen><en> If you want to convert the whole text, simply "Select All" from the "Edit" tab.
<G-vec00106-002-s355><select.auswählen><de> HINWEIS: Wenn Sie für Channel Width (Kanalbreite) die Einstellung Wide - 40MHz Channel (40-MHz- Zusatzkanal) auswählen, so können für Wireless-N ein primärer (Zusatzkanal) und ein sekundärer Kanal (Standardkanal) genutzt werden.
<G-vec00106-002-s355><select.auswählen><en> NOTE: If you select 40MHz only for the Channel Width setting, then Wireless-N can use two channels: a primary one (Wide Channel) and a secondary one (Standard Channel).
<G-vec00106-002-s356><select.auswählen><de> Mit Ausschnitt Zoomen können Sie einen Bereich vergrößern, den Sie auswählen, in dem Sie auf eine Ecke des Bereichs klicken, das Rechteck auf die gewünschte Größe ziehen und dann auf die gegenüberliegende Ecke klicken.
<G-vec00106-002-s356><select.auswählen><en> Zoom Window Zoom Window lets you zoom in on an area, which you select by first clicking at one corner, then dragging the rectangle and clicking at the opposite corner.
<G-vec00106-002-s357><select.auswählen><de> Öffnen Sie eine AVI-Datei, indem Sie auf die "Datei zum Bearbeitung auswählen"-Schaltfläche im geöffneten Fenster klicken (Abbildung 1).
<G-vec00106-002-s357><select.auswählen><en> Open a AVI file by clicking the "Select file for editing" button in the opened window.
<G-vec00106-002-s358><select.auswählen><de> Sie kopiert die Datei in die Impulsantwortbibliothek, so daß Sie sie auswählen können, wenn Sie im Klang-Reiter der Einstellungen-Sicht auf Faltungshall schalten.
<G-vec00106-002-s358><select.auswählen><en> It copies the file to the impulse responses library, so you can select it when you switch to convolution reverb in the Sound tab of the Settings view.
<G-vec00106-002-s359><select.auswählen><de> Dies können Sie in der Systemsteuerung unter Netzwerk auswählen.
<G-vec00106-002-s359><select.auswählen><en> You can select the DHCP under Network in the control panel.
<G-vec00106-002-s360><select.auswählen><de> Optional können Sie im Abschnitt Filter Folgendes tun: a. Stores-Speicherort zum Auswählen von vDisks ändern.
<G-vec00106-002-s360><select.auswählen><en> In the Filter section, optionally: a. Change the Store location from which to select vDisks from.
<G-vec00106-002-s361><select.auswählen><de> Verwenden Sie das Drop-down-Menü, um auszuwählen, welchen Standort Sie aktualisieren möchten.
<G-vec00106-002-s361><select.auswählen><en> Use the dropdown list to select which location you would like to update
<G-vec00106-002-s362><select.auswählen><de> Verwenden Sie die Pfeiltaste (C), um [LAN settings] (LAN-Einstellungen) auszuwählen, und drücken Sie die Taste [OK].
<G-vec00106-002-s362><select.auswählen><en> Use the arrow button (C) to select [LAN settings] and press the [OK] button.
<G-vec00106-002-s363><select.auswählen><de> Das versetzt Sie in die Lage, eine Pumpe auf der Grundlage von Auslassgröße und Motorwerten auszuwählen, damit Sie sich keine Sorgen über die genaue Pumpleistung machen müssen.
<G-vec00106-002-s363><select.auswählen><en> As a result you can now select a pump based on the outlet size and motor rating and not worry about exact pump performance. Pain Point
<G-vec00106-002-s364><select.auswählen><de> VoIP-Sicherheit Verwenden Sie diese Dropdownliste, um die VoIP-Sicherheitseinstellung für die UM-Wähleinstellungen auszuwählen.
<G-vec00106-002-s364><select.auswählen><en> VoIP VoIP security mode Use this drop-down list to select the VoIP security setting for the UM dial plan.
<G-vec00106-002-s365><select.auswählen><de> 3 Drücken Sie die SURROUND PARAMETER-Taste, um den Surround-Parameter-Modus auszuwählen.
<G-vec00106-002-s365><select.auswählen><en> 3 Press V or v to select the parameter you want to adjust.
<G-vec00106-002-s366><select.auswählen><de> Nutzen Sie die Drop-down-Menüs Typ und Name, um ein Installationspaket auszuwählen.
<G-vec00106-002-s366><select.auswählen><en> Use the Type and Name drop-down menus to select an installer package.
<G-vec00106-002-s367><select.auswählen><de> 1 Betätigen Sie HI, um ein Bild auszuwählen.
<G-vec00106-002-s367><select.auswählen><en> q Playback Menu 1 Use HI to select an image.
<G-vec00106-002-s368><select.auswählen><de> Halten Sie die STRG-Taste gedrückt, um mehrere Attribute auszuwählen.
<G-vec00106-002-s368><select.auswählen><en> Hold the Ctrl key pressed, to select multiple attributes.
<G-vec00106-002-s369><select.auswählen><de> Drehen Sie den Drehschalter, um ON oder OFF auszuwählen.
<G-vec00106-002-s369><select.auswählen><en> Setting the Time to automatically Adjust 1 Turn the Rotary encoder to select ON or OFF.
<G-vec00106-002-s370><select.auswählen><de> Wählen Sie die Folie mit der Zeichnung aus, und tippen oder klicken Sie auf die Zeichnung, um sie auszuwählen.
<G-vec00106-002-s370><select.auswählen><en> Choose the slide with the drawing, then tap or click the drawing to select it.
<G-vec00106-002-s371><select.auswählen><de> Verwenden Sie das Textwerkzeug, um die einzelnen Textrahmen auszuwählen.
<G-vec00106-002-s371><select.auswählen><en> Use the Text tool to select each of the text frames.
<G-vec00106-002-s372><select.auswählen><de> Sie haben auch die Möglichkeit, bei gedrückter S PenTaste einen Bereich auszuwählen.
<G-vec00106-002-s372><select.auswählen><en> Alternatively, select an area while pressing and holding the S Pen button.
<G-vec00106-002-s373><select.auswählen><de> Ermöglicht es Ihnen, auf der Garmin Connect Website nach Trainings und Trainingsplänen zu suchen und sie auszuwählen.
<G-vec00106-002-s373><select.auswählen><en> Allows you to browse for and select workouts and training plans on the Garmin Connect site.
<G-vec00106-002-s374><select.auswählen><de> 1 Drücken Sie FUNCTION +/, um die USB-Funktion auszuwählen.
<G-vec00106-002-s374><select.auswählen><en> Tuning automatically 1 Select the band, then press +/ to search for the station.
<G-vec00106-002-s375><select.auswählen><de> Wenn Sie die obere Menüleiste sehen, drücken Sie die Alt Taste um sie auszuwählen.
<G-vec00106-002-s375><select.auswählen><en> If you do not see the top menu bar, press the Alt key to select it.
<G-vec00106-002-s376><select.auswählen><de> Verwenden Sie die NACH-OBEN-TASTE und die NACH-UNTEN-TASTE, um die zu öffnende Tabelle, das zu öffnende Formular oder den zu öffnenden Bericht auszuwählen.
<G-vec00106-002-s376><select.auswählen><en> Use the UP ARROW and DOWN ARROW keys to select the table, form, or report that you want to open.
<G-vec00106-002-s377><select.auswählen><de> Verwenden Sie die [PFEILTASTEN], um ein Betriebssystem auszuwählen, und drücken Sie anschließend die [EINGABETASTE].
<G-vec00106-002-s377><select.auswählen><en> Use the arrow keys to select an operating system, and then press ENTER.
<G-vec00106-002-s378><select.auswählen><de> Verwenden Sie die Liste Format, um Zahl auszuwählen.
<G-vec00106-002-s378><select.auswählen><en> Use the Format list to select Number.
<G-vec00106-002-s379><select.auswählen><de> Klicke dafür zuerst auf Zelle B4, um sie auszuwählen, und dann auf die Formel-Leiste.
<G-vec00106-002-s379><select.auswählen><en> Do this by clicking first on cell B4 to select it and then by clicking inside the formula bar.[5]
<G-vec00106-002-s437><select.auswählen><de> Wähle ein Titelbild für dein Meetup aus.
<G-vec00106-002-s437><select.auswählen><en> Select a cover photo for your group.
<G-vec00106-002-s438><select.auswählen><de> Wähle in der Übersicht die Playlist aus, die du bearbeiten möchtest.
<G-vec00106-002-s438><select.auswählen><en> Select the playlist you’d like to edit in the Guide.
<G-vec00106-002-s439><select.auswählen><de> Geh auf crownchampionship.clashroyale.com und wähle deine Region aus, um einen Account zu registrieren.
<G-vec00106-002-s439><select.auswählen><en> Visit crownchampionship.clashroyale.com and select your region to register for an account.
<G-vec00106-002-s440><select.auswählen><de> Wähle dein Netzwerk aus.
<G-vec00106-002-s440><select.auswählen><en> Select your Wi-Fi network.
<G-vec00106-002-s441><select.auswählen><de> Wähle eine beliebige Farbe aus und erstelle einzigartige Muster.
<G-vec00106-002-s441><select.auswählen><en> You can select any color and form a unique picture.
<G-vec00106-002-s442><select.auswählen><de> Setze das Häkchen in der Checkbox Aktiv und wähle eine Kategorie aus, in welcher der Artikel auf Amazon gelistet werden soll.
<G-vec00106-002-s442><select.auswählen><en> Mark the Active checkbox and select a category in which the article should be listed on Amazon.
<G-vec00106-002-s443><select.auswählen><de> Erfahre mehr über NotifyVisitors Benachrichtigungsverwaltungs- und Automatisierungstool – zeige Benachrichtigungen basierend auf dem Besucherverhalten an und wähle aus mehreren Targeting-Regeln aus.
<G-vec00106-002-s443><select.auswählen><en> Learn more about NotifyVisitors Notification management and automation tool - show notifications based on visitor behaviour and select from multiple targeting rules.
<G-vec00106-002-s444><select.auswählen><de> Beschreibung Wähle dein Instrument aus und versuche, die ausgewählte Melodie nachzuspielen.
<G-vec00106-002-s444><select.auswählen><en> Description Select your instrument and play back the tune you have chosen.
<G-vec00106-002-s445><select.auswählen><de> Wähle einen Hinweis im OSM-Hinweis-Dialog aus und drücke Strg+C, um die ID des Hinweises und den Text des ersten Kommentars in die Zwischenablage zu kopieren.
<G-vec00106-002-s445><select.auswählen><en> Select a note in the Notes Dialog and press Ctrl+C to copy the ID of the note and the text of the first comment to the clipboard.
<G-vec00106-002-s446><select.auswählen><de> Klicke auf "Netzwerk" und wähle dann die aktive Netzwerkverbindung aus.
<G-vec00106-002-s446><select.auswählen><en> Click "Network", then select your active network connection.
<G-vec00106-002-s447><select.auswählen><de> In die Einkaufstasche XbyO Originals Jacke Wähle jetzt deine Größe aus und erhalte eine Mail wenn diese wieder verfügbar ist.
<G-vec00106-002-s447><select.auswählen><en> Add To Bag XbyO Track Jacket Select your size, and we'll email you when it's back in stock.
<G-vec00106-002-s448><select.auswählen><de> Öffne die Google Fotos App, tippe auf die Schaltfläche "Menü" und wähle "Einstellungen" aus.
<G-vec00106-002-s448><select.auswählen><en> Open the Photos app, touch the menu button and select Settings.
<G-vec00106-002-s449><select.auswählen><de> Klicke dazu mit der rechten Maustaste auf das Porträt des gewünschten Gegners und wähle Duell aus.
<G-vec00106-002-s449><select.auswählen><en> To do so, right-click on the portrait of the desired opponent and select Duel.
<G-vec00106-002-s450><select.auswählen><de> Ultra Energy Shorts Wähle jetzt deine Größe aus und erhalte eine Mail wenn diese wieder verfügbar ist.
<G-vec00106-002-s450><select.auswählen><en> Add To Bag Response Shorts Select your size and we'll email you if it's back in stock
<G-vec00106-002-s451><select.auswählen><de> Wähle rechts oben auf der Seite Meine Kurse aus.
<G-vec00106-002-s451><select.auswählen><en> Select My Courses at the top right of the page
<G-vec00106-002-s452><select.auswählen><de> Wähle die Extrusionsrichtung mit dem Slider aus.
<G-vec00106-002-s452><select.auswählen><en> Select the direction of extrusion with the slider.
<G-vec00106-002-s453><select.auswählen><de> Wähle eine Videoqualität aus.
<G-vec00106-002-s453><select.auswählen><en> Select a video quality.
<G-vec00106-002-s454><select.auswählen><de> Wähle die Festplatte aus und klicke auf den Button "Erste Hilfe".
<G-vec00106-002-s454><select.auswählen><en> Select your drive and click the "First Aid" button.
<G-vec00106-002-s455><select.auswählen><de> Wähle einen Artikel aus unserem Onlineshop aus, für den der Gutscheinrabatt verwendet werden kann.
<G-vec00106-002-s455><select.auswählen><en> Select an article from our online shop for which the discount voucher is valid.
<G-vec00106-002-s532><select.auswählen><de> Wählt euer USB-Laufwerk nun aus.
<G-vec00106-002-s532><select.auswählen><en> Now select your USB drive.
<G-vec00106-002-s533><select.auswählen><de> Schritt 4: Wählt „Overwatch-Gratiswochenende“ aus den Ergebnissen aus und danach „Herunterladen“.
<G-vec00106-002-s533><select.auswählen><en> Step 4: Select “Overwatch Free Weekend” from the search results and then click “Download.”
<G-vec00106-002-s534><select.auswählen><de> Das International Faculty Office wählt einen Buddy für Sie aus und wird Ihnen vor Ihrer Abreise nach Deutschland die Kontaktdaten zusenden.
<G-vec00106-002-s534><select.auswählen><en> The International Faculty Office will select one for you and will send you the contact details before you travel to Germany.
<G-vec00106-002-s535><select.auswählen><de> Nach der Untersuchung des Kindes und der Untersuchung der Umfragedaten wählt der Arzt ein Behandlungsregime für ihn aus.
<G-vec00106-002-s535><select.auswählen><en> After examining the baby and having examined the survey data, the doctor will select a treatment regimen for him.
<G-vec00106-002-s536><select.auswählen><de> Hat man ein anderes Überfüllungsset erstellt und möchte dies auf einige oder alle Seiten anwenden, wählt man oben jeweils das gewünschte Überfüllungsset aus, in der Zeile darunter die entsprechenden Seiten und klickt dann auf Zuweisen.
<G-vec00106-002-s536><select.auswählen><en> If you have created a different trapping set and want to apply this to some or all of the pages, select the desired trapping set at the top, the appropriate page in the row underneath, and then click Assign.
<G-vec00106-002-s537><select.auswählen><de> Wählt den Manastein per Doppelklick (oder Rechtsklick) an und wählt dann den Gegenstand für die Verankerung aus.
<G-vec00106-002-s537><select.auswählen><en> Activate the Manastone item by double-clicking (or right-clicking) it, then select an item to socket the manastone.
<G-vec00106-002-s538><select.auswählen><de> Meldet euch dafür auf Flickr an, wählt aus, wo eure Fotos gespeichert sind und los geht’s.
<G-vec00106-002-s538><select.auswählen><en> Log into your Flickr account, select where your photos are stored and you’re all set.
<G-vec00106-002-s539><select.auswählen><de> (SHIFT ALT A) - Wählt Dateien anhand eines Regulären Ausdrucks aus.
<G-vec00106-002-s539><select.auswählen><en> (SHIFT ALT A) - Select files according to a regular expression.
<G-vec00106-002-s540><select.auswählen><de> Aus diesen aussagekräftigen Kurzbewerbungen wählt eine Kommission aus Fachleuten die überzeugendsten Produkte aus.
<G-vec00106-002-s540><select.auswählen><en> A commission of experts will then select the most convincing products from these applications.
<G-vec00106-002-s541><select.auswählen><de> Wählt einen festen Gutscheinwert aus, bezahlt bequem mit Paypal, Sofortüberweisung oder Kreditkarte und erhaltet im Anschluss euren persönlichen Gutscheincode per Mail.
<G-vec00106-002-s541><select.auswählen><en> Simply select an amount of money, pay easily with Paypal, bank transfer or credit card and receive your personal coupon code by email.
<G-vec00106-002-s542><select.auswählen><de> • Eine Jury wählt den besten Brief des Wettbewerbs Ich erinnere mich… aus.
<G-vec00106-002-s542><select.auswählen><en> • Epistolary competition: I remember…A jury will select the best letter.
<G-vec00106-002-s543><select.auswählen><de> In diesem Fall, wenn Sie "Blumenlieferdienst" eingeben, wählt Google aus Unternehmen aus, die mit dem gleichen Schlüsselwort bei Google my Business gelistet sind.
<G-vec00106-002-s543><select.auswählen><en> In this case, when you type in “flower delivery service,” Google will select from businesses that are listed with Google Business Places using the same keyword.
<G-vec00106-002-s544><select.auswählen><de> Unter der Schirmherrschaft von smart Leiterin Dr. Annette Winkler bewertet die smart urban pioneers Jury alle eingegangenen Ideen und wählt zwölf herausragende Projekte aus, die ihre Idee einem Livepublikum auf der IAA präsentieren dürfen.
<G-vec00106-002-s544><select.auswählen><en> The smart urban pioneers jury, headed by smart boss Dr Annette Winkler, will assess all of the ideas submitted and select twelve stand-out projects. The innovators behind these will be able to pitch their idea to a live audience at the IAA.
<G-vec00106-002-s545><select.auswählen><de> Shows Wählt in dem Menü Staat, Ort und Datum aus, und prüft hier die Verfügbarkeit der von euch bevorzugten Show.
<G-vec00106-002-s545><select.auswählen><en> Use the state, city, and date menus below to select your destination and check the availability of your preferred show.
<G-vec00106-002-s546><select.auswählen><de> Man wählt einfach aus mit wem man etwas teilen möchte und AirDrop erledigt den Rest.
<G-vec00106-002-s546><select.auswählen><en> Just select who you want to share with and AirDrop does the rest.
<G-vec00106-002-s547><select.auswählen><de> Klickt dazu auf die Symbolleiste „Filter“, wählt „Baumdetails“ aus und klickt dann auf die Option „Theory of Family Relativity™ vorhanden“.
<G-vec00106-002-s547><select.auswählen><en> Do this by clicking the “Filter” toolbar, select “Tree details” and then click on the “Has Theory of Family Relativity™” option.
<G-vec00106-002-s548><select.auswählen><de> Wählt als Vordergrundfarbe Schwarz aus.
<G-vec00106-002-s548><select.auswählen><en> Select Black as new foreground color.
<G-vec00106-002-s549><select.auswählen><de> Danach wählt man einen Speicherort für den neuen stabilisierten Videoclip aus.
<G-vec00106-002-s549><select.auswählen><en> Then select a location to save the new stabilized video clip.
<G-vec00106-002-s550><select.auswählen><de> Das QSL-Führungsteam überprüft jährlich ihre aktuellen und geplanten Technologieinvestitionen und wählt nur solche Lösungen aus, die sich an der Strategie ausrichten und messbare Geschäftsvorteile bieten.
<G-vec00106-002-s550><select.auswählen><en> QSL’s leadership team review their current and proposed technology investments annually and select only those solutions that align with strategy and deliver measurable business benefits.
