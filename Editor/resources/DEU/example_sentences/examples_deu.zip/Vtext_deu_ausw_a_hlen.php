<G-vec00297-002-s475><choose.auswählen><de> Bahne dir deinen Weg, wähle zwischen Held oder Schurke und erlebe die Kämpfe aus der Reihe hautnah.
<G-vec00297-002-s475><choose.auswählen><en> arena fighter. Pave your path and choose between hero or villain
<G-vec00297-002-s476><choose.auswählen><de> Wähle dann aus der unten stehenden Liste aus, was Peter mag und was er nicht mag.
<G-vec00297-002-s476><choose.auswählen><en> Then choose from the list below what Peter likes and what he doesn't like.
<G-vec00297-002-s477><choose.auswählen><de> Wähle aus einer Liste deiner gespeicherten Kreditkarten aus.
<G-vec00297-002-s477><choose.auswählen><en> Choose from a list of your stored credit cards.
<G-vec00297-002-s478><choose.auswählen><de> Dann wähle die richtige Antwort aus.
<G-vec00297-002-s478><choose.auswählen><en> Then choose the correct reply.
<G-vec00297-002-s479><choose.auswählen><de> Probiere ein paar komplett unterschiedliche Überschriften aus und wähle die beste aus.
<G-vec00297-002-s479><choose.auswählen><en> Try a few drastically different extended headlines and choose the best one to continue with.
<G-vec00297-002-s480><choose.auswählen><de> Objekte nach einem Tags gruppieren: Klicke auf die Taste „Gruppe“ und wähle „Tags“ aus.
<G-vec00297-002-s480><choose.auswählen><en> Group items by a tag: Click the Group button, then choose Tags.
<G-vec00297-002-s481><choose.auswählen><de> Passe Zifferblätter und App-Mitteilungen an, wähle die Apps im Dock aus und ordne sie, wie es dir gefällt, und wähle Fotos und Musik, die du synchronisieren willst.
<G-vec00297-002-s481><choose.auswählen><en> Customize your watch faces and app notifications, choose and arrange the apps in your Dock, select photos and music to sync, and more.
<G-vec00297-002-s482><choose.auswählen><de> Auschecken Für Preise und VerfügbarkeFreunden Grund- /Hauptschule Haupt-/Oberschule Universität Geschäftsreise Polterabend Sportsgruppen Kulturgruppen Bitte wähle eine Gruppenart aus.
<G-vec00297-002-s482><choose.auswählen><en> Check Out To view prices and availability, please enter a Friends Junior/Primary School High/Secondary School College/University Business Trip Stag / Hen / Bachelor Party Sports Group Cultural Group You must choose a group type.
<G-vec00297-002-s483><choose.auswählen><de> Wähle aus, ob die E-Mails in deinem Posteingang erscheinen sollen.
<G-vec00297-002-s483><choose.auswählen><en> Choose whether or not the messages should appear in your inbox.
<G-vec00297-002-s484><choose.auswählen><de> Wähle oben rechts mit einem Klick das Teammitglied aus, das du entfernen möchtest.
<G-vec00297-002-s484><choose.auswählen><en> In the upper right corner, choose the team member you want to remove.
<G-vec00297-002-s485><choose.auswählen><de> Long Road To HellRock Rebel by EMPWinterjacke Bitte wähle eine Größe aus.
<G-vec00297-002-s485><choose.auswählen><en> Skull Jacket IIRock Rebel by EMPWinter Jacket Please choose a size Jacket
<G-vec00297-002-s486><choose.auswählen><de> Cat Bitte wähle eine Größe aus.
<G-vec00297-002-s486><choose.auswählen><en> Please choose a size XXL
<G-vec00297-002-s487><choose.auswählen><de> Um Elixiere zu mischen, gehe zu deinem Heiligtum des Asklepios, öffne den Tab "Amphorenkammer" und wähle die Elixiere aus, die du miteinander mischen möchtest.
<G-vec00297-002-s487><choose.auswählen><en> To combine Potions, go to your Alchemist's Shop, open the "Laboratory" tab and choose the Potions you wish to mix.
<G-vec00297-002-s488><choose.auswählen><de> Wähle einfach deinen Lieblingsstream aus und gib dir die volle Dröhnung.
<G-vec00297-002-s488><choose.auswählen><en> Just choose your favorite stream and give you the full roar.
<G-vec00297-002-s489><choose.auswählen><de> Wähle in Choices: Stories you Play eine Geschichte nach deinen Wünschen aus und begib dich zu neuen Abenteuern, triff neue Bekannte und vielleicht auch deine Liebe.
<G-vec00297-002-s489><choose.auswählen><en> Votes: 299 Choices: Stories you play - choose a story to your liking and go to find adventures, new meetings and maybe love.
<G-vec00297-002-s490><choose.auswählen><de> Wähle etwas aus, was zu deiner Gesichtsform passt.
<G-vec00297-002-s490><choose.auswählen><en> Choose something that will flatter your face shape.
<G-vec00297-002-s491><choose.auswählen><de> Wähle aus, wohin du die Channels transferieren möchtest, indem du auf einen Workspace klickst.
<G-vec00297-002-s491><choose.auswählen><en> Choose where you'd like to move the channelsÂ by clicking on a workspace.
<G-vec00297-002-s492><choose.auswählen><de> Wähle Nahrungsmittel aus, die den Speichelfluss anregen, um über den Tag die Plaque fernzuhalten.
<G-vec00297-002-s492><choose.auswählen><en> Choose foods that make you salivate as a way to keep plaque away during the day.
<G-vec00297-002-s493><choose.auswählen><de> Art der Gruppe Urlaub mit Freunden Grund- /Hauptschule Haupt-/Oberschule Universität Geschäftsreise Polterabend Sportsgruppen Kulturgruppen Bitte wähle eine Gruppenart aus.
<G-vec00297-002-s493><choose.auswählen><en> Group Type Holiday with Friends Junior/Primary School High/Secondary School College/University Business Trip Stag / Hen / Bachelor Party Sports Group Cultural Group You must choose a group type.
<G-vec00297-002-s097><opt.auswählen><de> Um die Anmeldeinformationen für die Authentifizierung vollständig zu schützen, müssen bestimmte Anwendungen auf diesen Plattformen immer noch den Mechanismus auswählen.
<G-vec00297-002-s097><opt.auswählen><en> In order to fully protect authentication credentials, specific applications on these operating systems still need to opt in to the mechanism.
<G-vec00297-002-s098><opt.auswählen><de> Das Angebot richtet sich an Kundinnen, die auf die Pflege ihrer Haut achten und gleichzeitig umweltbewusst Produkte auswählen.
<G-vec00297-002-s098><opt.auswählen><en> The product range is aimed at customers who pay attention to their skin care and also opt for environmentally conscious products.
<G-vec00297-002-s099><opt.auswählen><de> Unser Gold ist immer 18 Karat, egal ob Sie Weiß-, Gelb- oder Rotgold auswählen.
<G-vec00297-002-s099><opt.auswählen><en> Our gold is always 18 carat, regardless of whether you opt for white, yellow or red gold.
<G-vec00297-002-s100><opt.auswählen><de> Auswählen und verlinken Sie Ihren Gnatta service HelpDesk mit HDM.
<G-vec00297-002-s100><opt.auswählen><en> Opt and connect your Activate support desk with HDM.
<G-vec00297-002-s101><opt.auswählen><de> Dann können Sie auf Ihrem iPhone "Wiederherstellen von iTunes Backup" auswählen.
<G-vec00297-002-s101><opt.auswählen><en> Then on your iPhone, you can now opt to "Restore from iTunes Backup".
<G-vec00297-002-s102><opt.auswählen><de> Ihr könnt die Unterkunft an Bord im Rahmen eures Budgets auswählen: entscheidet euch für eine der kostengünstigen Schlafkojen oder gönnt euch einer Doppelbett-Kabine mit eigenem Bad.
<G-vec00297-002-s102><opt.auswählen><en> Choose your onboard accommodation to suit your budget: opt for one of our best value 6-berth bunks or splash out on a double ensuite private cabin.
<G-vec00297-002-s103><opt.auswählen><de> Wenn Sie dies auswählen, kreuzen Sie einfach das Kästchen auf der Download-Seite an und klicken anschließend auf Download.
<G-vec00297-002-s103><opt.auswählen><en> If you’d like to opt for this, just check the box on the download page, then click Download.
<G-vec00297-002-s104><opt.auswählen><de> Sie können auch auswählen, diese Zahlen für 2, 4 oder 8 aufeinanderfolgende Ziehungen zu verwenden und/oder die selbe Wette bei 2,4 oder 8 aufeinanderfolgenden Wettbewerben (“Teimosinha”) zu machen.
<G-vec00297-002-s104><opt.auswählen><en> They can also opt to enter these numbers for 2, 4 or 8 consecutive draws in advance and / or compete with the same bet by 2, 4 or 8 consecutive contests (“Teimosinha”).
<G-vec00322-002-s182><specify.auswählen><de> Legen Sie fest, ob Sie eine ganze Gruppe von Dokumenten bearbeiten möchten, nur die derzeit angezeigte Kopie oder einen Teil der Gruppe, den Sie nach Datensatznummern auswählen.
<G-vec00322-002-s182><specify.auswählen><en> Choose whether you want to edit the whole set of labels, only the label that is currently visible, or a subset of the set, which you specify by record number.
<G-vec00322-002-s183><specify.auswählen><de> Die Stärke des Wasserdrucks, Position des Duscharms, Wunschtemperatur, Strahlart und Reinigungsverfahren lassen sich ganz nach persönlichen Vorlieben auswählen.
<G-vec00322-002-s183><specify.auswählen><en> Extensive personalization options allow the user to specify the water pressure, the position of the shower arm and the preferred water temperature, as well as the spray pattern and the cleansing procedure.
<G-vec00322-002-s184><specify.auswählen><de> Hier kannst du auswählen, wieviele Prozessor-Threads Gsdx mit dem Software Renderer verwenden soll, um alle Kerne deines Prozessors auszunützen.
<G-vec00322-002-s184><specify.auswählen><en> Here you can specify how many threads GSdx will use while software rendering, to take advantage of all cores your processor might have, e.g.
<G-vec00322-002-s185><specify.auswählen><de> In den MIME-Einstellungen können Sie auswählen, welche Formate QuickTime in Firefox abspielen soll.
<G-vec00322-002-s185><specify.auswählen><en> In the MIME Types window, you can specify the media formats you want QuickTime to play in Firefox.
<G-vec00322-002-s186><specify.auswählen><de> Abbildung 6: Zeitfenster auswählen.
<G-vec00322-002-s186><specify.auswählen><en> Figure 6: Specify a time frame
<G-vec00322-002-s187><specify.auswählen><de> Als Spieler kann man auswählen, auf wie viele Gewinnlinien man wetten möchte.
<G-vec00322-002-s187><specify.auswählen><en> As a player, you can specify the number of active pay lines you want to wager on.
<G-vec00322-002-s188><specify.auswählen><de> Die exklusiven GLK-Modelle werden in der Basisausführung in Calcitweiß angeboten, allerdings kann der Kunde auch jede andere Lackierung auswählen.
<G-vec00322-002-s188><specify.auswählen><en> The exclusive GLK models are available in calcite white in the basic version, although customers may specify any other paint finish.
<G-vec00322-002-s189><specify.auswählen><de> Neben den angegebenen Farbkombinationen können Sie daher die Farbe der lackierten Oberflächen dieses Möbelstücks selbst aus der Palette der RAL-Töne auswählen (ein- oder zweifarbige Lackierung möglich).
<G-vec00322-002-s189><specify.auswählen><en> Colour on request: Müller produces the furniture order-related. In addition to the colours selected by us, you may specify the furniture colours (monochrome or two-tone) from the palette of RAL colours.
<G-vec00322-002-s190><specify.auswählen><de> Sie müssen auf der Seite, auf die wir verlinken, lediglich Ihr Scanner-Modell auswählen.
<G-vec00322-002-s190><specify.auswählen><en> You will just have to specify your scanner model on the page we link to.
<G-vec00322-002-s191><specify.auswählen><de> Hier kannst du auch die Rechnungsadresse auswählen.
<G-vec00322-002-s191><specify.auswählen><en> It is also during this step that you can specify a billing address.
<G-vec00322-002-s192><specify.auswählen><de> Du kannst ein bestimmtes Genre auswählen, dir Songs und Alben eines Interpreten wünschen oder die Wunschlisten von Communitymitgliedern zum Mitschneiden auswählen.
<G-vec00322-002-s192><specify.auswählen><en> You can specify the genre, request specific songs and albums or choose to have your personal wishlist available for community members to record.
<G-vec00322-002-s193><specify.auswählen><de> Neben diesen Systemkomponenten können Sie nach Bedarf weitere Komponenten und Technologien (beispielsweise ZigBee, EnOcean oder andere) auswählen.
<G-vec00322-002-s193><specify.auswählen><en> In addition to these system components you can also specify other components and technologies (e.g. ZigBee, EnOcean etc.) according to your needs.
<G-vec00488-002-s033><designate.auswählen><de> Sind mehrere Gruppen mit der gleichen Berechtigung auf einem Ordner angelegt, so kann man die Gruppe auswählen, die man in tenfold registrieren möchte.
<G-vec00488-002-s033><designate.auswählen><en> If several groups have the same access right to a folder, it is possible to designate one of these groups for registration in tenfold.
