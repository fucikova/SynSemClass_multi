<G-vec00441-002-s022><punch.ausstanzen><de> Stanz die Hälfte: Man muss ja nicht immer alles auf einmal ausstanzen, manchmal reicht auch nur ein Teil der Stanze, um einen interessanten Effekt zu erzielen.
<G-vec00441-002-s022><punch.ausstanzen><en> Stamping the Half: You do not always have to punch out everything at once, sometimes only a part of the punch is sufficient to achieve an interesting effect.
<G-vec00441-002-s023><punch.ausstanzen><de> Dazu einfach mit einem Papierstanzer ein Flugzeugmotiv aus der FIMO leather-effect Platte ausstanzen, ein Loch hineinbohren und einen Ring durchziehen.
<G-vec00441-002-s023><punch.ausstanzen><en> To do this, simply stamp an aeroplane shape out of the FIMO leather‑effect sheet using a punch, pierce a hold in it and thread it onto a ring.
<G-vec00441-002-s024><punch.ausstanzen><de> Sockel ausschneiden oder mit Spellbinder Label 14 - mittlere Stanze - ausstanzen.
<G-vec00441-002-s024><punch.ausstanzen><en> Cut or punch out the base with Spellbinder Label 14 - medium punch.
