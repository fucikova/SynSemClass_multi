<G-vec00555-002-s027><dismiss.abwerten><de> Während sie früher als "Bauernsprache" abgewertet wurde, gilt sie heute als hip.
<G-vec00555-002-s027><dismiss.abwerten><en> Whereas at one time it was fashionable to dismiss it as a "language of peasants", today it is “in”.
