<G-vec00081-001-s038><break.abbrechen><de> """Wenn wir bei der Hälfte eines Jobs abbrechen müssen, können wir die Einstellungen einfach speichern, einen anderen Job laufen lassen und später zu dem ursprünglichen Job zurückkehren."
<G-vec00081-001-s038><break.abbrechen><en> """If we need to break in the middle of a job, we can easily save the settings, run a different job and reset back to the previous job at a later time."
<G-vec00081-001-s039><break.abbrechen><de> Ich wollte schon abbrechen und hatte mir vorgenommen einen größeren Drachen zu bauen, da bemerkte ich, dass der Wind auffrischte.
<G-vec00081-001-s039><break.abbrechen><en> Also the kite was flying very bad and restless, too. I was ready to have a break and go home, as I felt that the wind was getting stronger.
<G-vec00081-001-s040><break.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00081-001-s040><break.abbrechen><en> 12 They will plunder your wealth and loot your merchandise; they will break down your walls and demolish your fine houses and throw your stones, timber and rubble into the sea.
<G-vec00081-001-s041><break.abbrechen><de> Oft kommt es auch vor, dass Aeste durch dieses enorme Gewicht abbrechen.
<G-vec00081-001-s041><break.abbrechen><en> It often happens that branches break under this enormous weight.
<G-vec00081-001-s042><break.abbrechen><de> Wenn Raubangriffe, die Eidechse sein eigenes Endstück als abbrechen können Mittel der Ablenkung.
<G-vec00081-001-s042><break.abbrechen><en> When a predator attacks, the lizard can break off its own tail as a means of distraction.
<G-vec00081-001-s043><break.abbrechen><de> Dann, beginnend an der Basis, biegen Sie die harten äußeren Blätter zurück, bis sie abbrechen.
<G-vec00081-001-s043><break.abbrechen><en> Then, starting at the base, bend the tough outer leaves back until they break off.
<G-vec00081-001-s044><break.abbrechen><de> Ohne Umstell-Rädchen, Lämpchen, Turbinen oder andere bewegliche Teile, die früher oder später abbrechen oder verkalken.
<G-vec00081-001-s044><break.abbrechen><en> No moving parts such as adjuster wheels, lights, turbines, or other components that will sooner or later break or calcify.
<G-vec00081-001-s045><break.abbrechen><de> Lucas Auer: Ich würde alle Teile, die leicht abbrechen können, vom Auto verbannen.
<G-vec00081-001-s045><break.abbrechen><en> Lucas Auer: I would ban all parts that can easily break off the car.
<G-vec00081-001-s046><break.abbrechen><de> 16:39 Und will dich in ihre Hände geben, daß sie deine Kapellen abbrechen und deine Altäre umreißen und dir deine Kleider ausziehen und dein schönes Gerät dir nehmen und dich nackt und bloß sitzen lassen.
<G-vec00081-001-s046><break.abbrechen><en> 16:39 I will also give you into their hand, and they shall throw down your vaulted place, and break down your lofty places; and they shall strip you of your clothes, and take your beautiful jewels; and they shall leave you naked and bare.
<G-vec00081-001-s047><break.abbrechen><de> Die For Each- Einstellung kann mit oder ohne die Schleife abbrechen, wenn -Einstellung definiert werden.
<G-vec00081-001-s047><break.abbrechen><en> The For Each setting can be specified with or without the Break Loop If setting.
<G-vec00081-001-s048><break.abbrechen><de> Ihren Deutschkurs sollten Sie auf keinen Fall vor dieser Stufe abbrechen, da Sie sonst das Gelernte schnell vergessen werden.
<G-vec00081-001-s048><break.abbrechen><en> Under no circumstances should you break off your German courses before this level, as otherwise you will quickly forget what you have learned.
<G-vec00081-001-s049><break.abbrechen><de> Als ich stehen blieb und eine Géanit des batailles betrachtete, die drei wundervolle Knospen trug, sah ich ganz deutlich, ganz nahe neben mir, einen der Stiele sich herumlegen, als ob eine unsichtbare Hand ihn gefaßt hätte, sah ihn abbrechen, wie wenn diese Hand ihn gepflückt.
<G-vec00081-001-s049><break.abbrechen><en> As I stopped to look at a Géant de Bataille, which had three splendid blooms, I distinctly saw the stalk of one of the roses bend, close to me, as if an invisible hand had bent it, and then break, as if that hand had picked it!
<G-vec00081-001-s050><break.abbrechen><de> Außerdem, ist es für die Frau die Nutzen für sie abbrechen, der Lage sein, einen Mann, der voll und ganz auf eine Beziehung begangen werden kann gerecht sein.
<G-vec00081-001-s050><break.abbrechen><en> In addition, it is for the woman's benefit to break it off, to be able to meet a man who can be fully committed to having a relationship.
<G-vec00081-001-s051><break.abbrechen><de> Der Sandsturm war so stark, dass wir auf halber Strecke abbrechen mussten.
<G-vec00081-001-s051><break.abbrechen><en> The sand storm was too strong so we had to break up the mission half way down.
<G-vec00081-001-s052><break.abbrechen><de> Jeden Tag Make-up zu tragen kann deine Wimpern austrocknen und deine Augen reizen, was bewirken kann, dass die Wimpern abbrechen oder sogar ausfallen.
<G-vec00081-001-s052><break.abbrechen><en> Wearing makeup every day can dry out your lashes and irritate your eyes, which can cause your lashes to break or even fall out.
<G-vec00081-001-s053><break.abbrechen><de> Nein (nervöses Gestammle), ich muss jetzt leider das Gespräch abbrechen.
<G-vec00081-001-s053><break.abbrechen><en> No (inaudible), I must unfortunately break the discussion off now, sorry.
<G-vec00081-001-s054><break.abbrechen><de> Diese Methode ist jedoch nicht so zuverlässig wie die Verwendung von Softwarelösungen, da der Download abbrechen kann oder der Dienst genau dann, wenn Sie ihn benötigen, ausfällt.
<G-vec00081-001-s054><break.abbrechen><en> This method is not as reliable as using software solutions though, as the download can break or the service may be down at exactly that moment when you need it.
<G-vec00081-001-s055><break.abbrechen><de> Großmutter würde ein Blatt von ihrem Aloe Vera Betrieb abbrechen und zu meiner Rettung kommen.
<G-vec00081-001-s055><break.abbrechen><en> Grandma would break off a leaf from her Aloe Vera plant and come to my rescue.
<G-vec00081-001-s056><break.abbrechen><de> "Klicken Sie im Dialogfeld ""Abbrechen"" auf das Symbol Alle Klicken Sie auf die Schaltfläche, um alle Mitglieder auszuwählen Ok Klicken Sie auf und dann auf Ja Schaltfläche im neuen Kutools für Outlook-Dialogfeld."
<G-vec00081-001-s056><break.abbrechen><en> In the Break dialog, click the All button to select all memebers, click the Ok button, and finally click the Yes button in the new Kutools for Outlook dialog.
<G-vec00081-001-s021><discontinue.abbrechen><de> Sie müssen möglicherweise ihre Ausbildung abbrechen, weil ihr Vater verfolgt wird und sie sich den Unterricht nicht mehr leisten können.
<G-vec00081-001-s021><discontinue.abbrechen><en> But they may have to discontinue their education because their father is being persecuted and they can't afford the tuition.
<G-vec00081-001-s022><discontinue.abbrechen><de> Sie sollten die Einnahme dieses Arzneimittels niemals abrupt abbrechen, wenn Sie mit der Einnahme begonnen haben, da dies zu Entzugserscheinungen führen kann.
<G-vec00081-001-s022><discontinue.abbrechen><en> You should never abruptly discontinue taking this medication once you have started taking it, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s023><discontinue.abbrechen><de> Nicht Behandlung abbrechen, es sei denn gesagt, so von Ihrem Arzt zu tun.
<G-vec00081-001-s023><discontinue.abbrechen><en> Do not discontinue treatment unless told to do so by your physician.
<G-vec00081-001-s024><discontinue.abbrechen><de> Bei Benchmark dürfen wir jegliche Produkte oder Dienste, teilweise oder ganz, entweder dauerhaft oder vorübergehend und ohne Ankündigung, überarbeiten, ändern, modifizieren oder abbrechen.
<G-vec00081-001-s024><discontinue.abbrechen><en> We at Benchmark can revise, change, modify, suspend or discontinue any of our products or services, in part or whole, either permanently or temporarily without any notice.
<G-vec00081-001-s025><discontinue.abbrechen><de> Patienten sollten die Einnahme dieses Medikaments niemals abrupt abbrechen, da dies zu Entzugssymptomen führen kann.
<G-vec00081-001-s025><discontinue.abbrechen><en> Patients should never abruptly discontinue taking this medication, as this may cause withdrawal symptoms.
<G-vec00081-001-s022><interrupt.abbrechen><de> Ein paarmal mussten wir zwischendurch abbrechen und eine Passage genauer durchgehen, aber im Grunde hab ich sie jetzt alle drauf.
<G-vec00081-001-s022><interrupt.abbrechen><en> Sometimes we had to interrupt and re-check a part, but basically I know them all by now.
<G-vec00081-001-s023><interrupt.abbrechen><de> Die Erhitzung abbrechen, sobald man den ganzen Kalk gut durcherhitzt hat und kaum noch Destillat übergeht.
<G-vec00081-001-s023><interrupt.abbrechen><en> Interrupt the heating as soon as all of the lime has been thoroughly heated and hardly any distillate develops.
<G-vec00081-001-s024><interrupt.abbrechen><de> Studien belegen auch, dass Männer eine Behandlung später als Frauen beginnen, diese abbrechen, oder sie nicht fortführen.
<G-vec00081-001-s024><interrupt.abbrechen><en> Studies show that men are more likely than women to start treatment late, to interrupt treatment and to be lost to treatment follow-up.
<G-vec00081-001-s025><interrupt.abbrechen><de> Während einer Verkehrsdurchsage können Sie die aktuelle Verkehrsdurchsage abbrechen, indem Sie kurz auf den Ein-/Ausschaltknopf drücken Abb.2.
<G-vec00081-001-s025><interrupt.abbrechen><en> While a traffic report is being played, you can interrupt the current traffic report by briefly pressing the ON/OFF button Fig.2.
<G-vec00081-001-s026><interrupt.abbrechen><de> Eine Unterbrechung der Dateiübertragung: Angenommen, Sie sind ein Bündel von Sony Vegas-Datei von Ihrer Festplatte auf USB-Laufwerk zu übertragen, dann, wenn Sie diesen Vorgang abbrechen, indem Sie Gerät trennen oder PC Absperren von Netzkabel abgetrennt wird, wird dies zu einem Verlust der Datei führt, die bei der Übertragung von Modus werden.
<G-vec00081-001-s026><interrupt.abbrechen><en> Interrupting file transfer process: Â Suppose you are transferring a bundle of Sony Vegas file from your hard disk to USB drive, then if you interrupt this process by disconnecting device or shutting PC off by unplugging power cable, this will leads to loss of file which are being in transferring mode.
<G-vec00081-001-s030><discontinue.abbrechen><de> Es ist wichtig, die Einnahme dieses Arzneimittels nach dem Beginn der Einnahme nicht abrupt abzubrechen, da dies zu Entzugserscheinungen führen kann.
<G-vec00081-001-s030><discontinue.abbrechen><en> It is important not to abruptly discontinue taking this medication once you have started taking it, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s031><discontinue.abbrechen><de> Nach dessen Erfolg beschloss er sein Studium abzubrechen und sich ausschließlich dem künstlerischen Schaffen zu widmen.
<G-vec00081-001-s031><discontinue.abbrechen><en> Following its success, he decided to discontinue his studies and concentrate fully on his artistic work.
<G-vec00081-001-s032><discontinue.abbrechen><de> Im Dezember 1273 rief er seinen Freund und Sekretär Reginald zu sich, um ihm seinen Entschluß mitzuteilen, alle Arbeiten abzubrechen, da er während der Feier der Messe infolge einer übernatürlichen Offenbarung verstanden hatte, daß alles, was er bisher geschrieben hatte, nichts weiter als »ein Haufen Spreu« war.
<G-vec00081-001-s032><discontinue.abbrechen><en> "In December 1273, he summoned his friend and secretary Reginald to inform him of his decision to discontinue all work because he had realized, during the celebration of Mass subsequent to a supernatural revelation, that everything he had written until then ""was worthless""."
<G-vec00081-001-s033><discontinue.abbrechen><de> Talk Online Panel behält sich das Recht vor, fristlos und nach alleinigem Ermessen oder vom Gesetz oder lokalen Autoritäten angeordnet, seine Geschäfte in einem speziellen Land oder überall abzubrechen oder zu beenden, womit auch individuelle Konten geschlossen werden, was zum jeweiligen Verfall der Punkte führt.
<G-vec00081-001-s033><discontinue.abbrechen><en> Talk Online Panel reserves the right, without notice and in its sole discretion, on its own volition or as dictated by law or local authorities, to discontinue or terminate its operation in a particular country or overall, thus also terminating individual accounts, leading to the forfeiture of points therein.
<G-vec00081-001-s034><discontinue.abbrechen><de> EnergyCasino behält sich das Recht vor, die Cash Rewards Aktion nach eigenem Ermessen der Firma zu verändern oder abzubrechen.
<G-vec00081-001-s034><discontinue.abbrechen><en> EnergyCasino reserves the right to alter or discontinue the Cash Rewards promotion at the company's sole discretion. English English
<G-vec00081-001-s035><discontinue.abbrechen><de> """Sie versuchten uns zu zwingen, das Programm abzubrechen."
<G-vec00081-001-s035><discontinue.abbrechen><en> """They attempted to force us to discontinue the programme."
<G-vec00081-001-s027><interrupt.abbrechen><de> Zürich Tourismus ist berechtigt, jederzeit Verbesserungen oder Änderungen an der Aktion vorzunehmen sowie die Aktion ohne Angabe von Gründen auszusetzen, abzubrechen oder zu beenden.
<G-vec00081-001-s027><interrupt.abbrechen><en> Zürich Tourism is entitled to improve or modify the terms and conditions of the competition at any time, as well as to abandon, interrupt or discontinue the competition without giving any reason.
<G-vec00081-001-s028><interrupt.abbrechen><de> Die Sandoz-Familienstiftung behält sich die Möglichkeit vor, das Programm abzubrechen, wobei bereits angestellte Begünstigte bis zum Ablauf ihres Arbeitsvertrags finanziert werden.
<G-vec00081-001-s028><interrupt.abbrechen><en> The Sandoz Family Foundation reserves the right to interrupt the programme, in which case beneficiaries already employed will continue to receive funding until their contracts expire.
<G-vec00081-001-s029><interrupt.abbrechen><de> Um den Update-Vorgang abzubrechen, klicken Sie auf Update abbrechen .
<G-vec00081-001-s029><interrupt.abbrechen><en> To interrupt the update click Cancel update .
<G-vec00081-001-s088><discontinue.abbrechen><de> Haben Sie dann immer noch Beschwerden, brechen Sie die Behandlung ab und sprechen Sie mit Ihrem Zahnarzt.
<G-vec00081-001-s088><discontinue.abbrechen><en> Again, if the discomfort continues, discontinue the treatment and consult your dental professional.
<G-vec00081-001-s106><discontinue.abbrechen><de> Wenn Sie die Übersetzung vor Abschluss der Übersetzung abbrechen, erstellen Sie die tmx-Dateien für die Übersetzungen, die Sie erstellt haben, und laden Sie sie in das Translation Memory-Repository hoch.
<G-vec00081-001-s106><discontinue.abbrechen><en> If you discontinue before completing the translation, please do create the tmx files for the you have done and upload them to the translation memory repository.
<G-vec00081-001-s107><discontinue.abbrechen><de> Bei starkem Brennen, die Anwendung abbrechen.
<G-vec00081-001-s107><discontinue.abbrechen><en> In thecase of excessive burning, discontinue use.
<G-vec00081-001-s108><discontinue.abbrechen><de> Aber halten Sie die Vorsichtsmaßnahmen im Auge - wenn die Haut erscheint gereizt oder sogar noch mehr, Wunden, die Behandlung abzubrechen und sofort mit Ihrem Hautarzt konsultieren.
<G-vec00081-001-s108><discontinue.abbrechen><en> But keep in mind the precautions - if the skin appears irritated or even more so, sores, discontinue treatment and immediately consult your dermatologist.
<G-vec00081-001-s186><discontinue.abbrechen><de> GPRO behält sich das Recht vor, von Zeit zu Zeit, zu jeder Zeit, ohne Benachrichtigung den Service (oder einen Teil davon), zu modifizieren oder, entweder kurzzeitig oder permanent, abzubrechen.
<G-vec00081-001-s186><discontinue.abbrechen><en> GPRO reserves the right from time to time, at any time, to modify or discontinue, temporarily or permanently, the Service (or any part thereof) with or without notice.
<G-vec00081-001-s192><discontinue.abbrechen><de> Wenn einer dieser Fälle passieren dann sollte man den Lauf abbrechen und einen Arzt sofort aufsuchen.
<G-vec00081-001-s192><discontinue.abbrechen><en> If any of these happen then one should discontinue the course and consult a medical professional immediately.
<G-vec00081-001-s206><discontinue.abbrechen><de> Er kann seine Daten bis zur Betätigung der Schaltfläche „Complete Registration“ jederzeit korrigieren oder die Registrierung durch Schließen seines Browserfensters oder Betätigung der Schaltfläche „Zurück“ seines Browsers abbrechen.
<G-vec00081-001-s206><discontinue.abbrechen><en> "It can correct its data at all times until the ""Complete Registration"" button is pressed or discontinue the registration by closing its browser window or pressing the ""Back"" button of its browser."
<G-vec00081-001-s270><discontinue.abbrechen><de> interVista behält sich das Recht vor, zu jeglicher Zeit und von Zeit zu Zeit die Services (oder Teile davon) mit oder ohne Ankündigung zu aktualisieren, vorübergehend oder dauerhaft zu unterbrechen oder abzubrechen.
<G-vec00081-001-s270><discontinue.abbrechen><en> Escapia Inc. reserves the right at any time and from time to time to modify or discontinue, temporarily or permanently, the Services (or any part thereof) with or without notice.
<G-vec00081-001-s282><discontinue.abbrechen><de> Eine Unverträglichkeit des Arzneimittels ist äußerst selten, aber wenn eine allergische Reaktion festgestellt wird, muss der Verlauf des Vitaminpräparats abgebrochen und ein Arzt konsultiert werden.
<G-vec00081-001-s282><discontinue.abbrechen><en> Intolerance of the drug is extremely rare, but if an allergic reaction is identified, it is necessary to discontinue the course of the vitamin preparation and consult a doctor.
<G-vec00218-002-s019><break.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00218-002-s019><break.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00218-002-s020><break.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00218-002-s020><break.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00218-002-s021><break.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00218-002-s021><break.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00218-002-s022><break.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00218-002-s022><break.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00218-002-s024><break.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00218-002-s024><break.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00218-002-s025><break.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00218-002-s025><break.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00218-002-s026><break.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00218-002-s026><break.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00218-002-s027><break.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00218-002-s027><break.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00218-002-s028><break.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00218-002-s028><break.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00218-002-s029><break.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00218-002-s029><break.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00218-002-s030><break.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00218-002-s030><break.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00218-002-s031><break.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00218-002-s031><break.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00218-002-s032><break.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00218-002-s032><break.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00218-002-s033><break.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00218-002-s033><break.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00218-002-s034><break.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00218-002-s034><break.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00218-002-s035><break.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00218-002-s035><break.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00218-002-s036><break.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00218-002-s036><break.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00218-002-s037><break.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00218-002-s037><break.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00376-002-s037><discontinue.abbrechen><de> Darüber hinaus könnte Gilead die strategische Entscheidung treffen, die Entwicklung dieser Substanz abzubrechen, wenn das Unternehmen zum Beispiel der Ansicht ist, dass eine Markteinführung im Vergleich zu anderen Produkten in der Pipeline schwierig sein wird.
<G-vec00376-002-s037><discontinue.abbrechen><en> In addition, Gilead may make a strategic decision to discontinue development of the compound if, for example, Gilead believes commercialization will be difficult relative to other opportunities in its pipeline.
<G-vec00376-002-s038><discontinue.abbrechen><de> ICB behält sich das Recht vor, die Aktion aufgrund unvorhersehbarer Umstände ohne Vorankündigung abzubrechen oder beenden zu können.
<G-vec00376-002-s038><discontinue.abbrechen><en> ICB reserves the right to discontinue or terminate the competition due to unforeseeable circumstances without prior notice.
<G-vec00376-002-s039><discontinue.abbrechen><de> Daher beschloss PAION im Februar 2016, die Studie abzubrechen, um eine langwierige und teure Fortführung mit diesem Studiendesign zu vermeiden.
<G-vec00376-002-s039><discontinue.abbrechen><en> Therefore, in February 2016, PAION decided to discontinue the trial in order to avoid a long and expensive study with the existing design.
<G-vec00376-002-s041><discontinue.abbrechen><de> EnergyCasino behält sich das Recht vor, die Teilnahmebedingungen dieser Aktion jederzeit ohne Grund und Vorwarnung zu ändern und/oder abzubrechen.
<G-vec00376-002-s041><discontinue.abbrechen><en> EnergyCasino reserves the right to change the Terms and Conditions and/or discontinue or withdraw the promotion, due to unforeseen circumstances (e.g.
<G-vec00389-002-s019><demolish.abbrechen><de> Mit über 325 Jahren gelebter Innovation und Leidenschaft bietet Husqvarna® Bauprofis Support, Service und ein breites Angebot an Maschinen, Diamantwerkzeugen und Zubehör, das Sie zum Schneiden, Sägen, Bohren, Abbrechen, Abschleifen und Polieren von Beton benötigen.
<G-vec00389-002-s019><demolish.abbrechen><en> Wire saws With over 325 years of innovation and passion, Husqvarna provides construction professionals with support, service and a wide range of machines, diamond tools and all accessories that you need to cut, saw, drill, demolish, grind and polish concrete.
<G-vec00389-002-s019><destroy.abbrechen><de> 57Und etliche standen auf und gaben falsches Zeugnis wider ihn und sprachen: 58Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s019><destroy.abbrechen><en> 14:57 Some stood up and gave this false testimony against him: 5 14:58 “We heard him say, ‘I will destroy this temple made with hands and in three days build another not made with hands.’”
<G-vec00389-002-s020><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen, und sprachen: Er hat gesagt: Ich kann den Tempel Gottes abbrechen, und in drei Tagen denselben bauen.
<G-vec00389-002-s020><destroy.abbrechen><en> But last of all 2 false witnesses came forward, 61 and said, "This Man said, 'I am able to destroy the Temple of God, and to rebuild it after 3 days.'
<G-vec00389-002-s021><destroy.abbrechen><de> 14:58 Wir haben gehört, daß er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s021><destroy.abbrechen><en> 14:58 "We heard him say, 'I will destroy this man-made temple and in three days will build another, not made by man.' "
<G-vec00389-002-s022><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen 61 und sprachen: Er hat gesagt: Ich kann den Tempel Gottes abbrechen und in drei Tagen ihn bauen.
<G-vec00389-002-s022><destroy.abbrechen><en> 58 We heard him say, I will destroy this temple that is made with hands, and within three days I will build another made without hands.
<G-vec00389-002-s023><destroy.abbrechen><de> Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s023><destroy.abbrechen><en> "We heard him say, 'I will destroy this temple that is made with hands, and in three days I will build another made without hands.'"
<G-vec00389-002-s024><destroy.abbrechen><de> Vor dem am Kreuz hängenden Christus beziehen sich Spötter auf das gleiche Wort und rufen ihm zu: „Der du den Tempel abbrechen und in drei Tagen wieder aufbauen kannst, rette dich selbst“ (Mt 27, 40).
<G-vec00389-002-s024><destroy.abbrechen><en> In front of Christ hanging on the Cross some people, taunting him, referred to these same words: "You who would destroy the temple and build it in three days, save yourself!" (Mt 27: 40).
<G-vec00389-002-s027><destroy.abbrechen><de> Und einige standen auf und gaben falsches Zeugnis ab gegen ihn und sprachen: Wir haben gehört, daß er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s027><destroy.abbrechen><en> 57 And some stood up and bore false witness against him, saying, 58 “We heard him say, ‘I will destroy this temple that is made with hands, and in three days I will build another, not made with hands.’”
<G-vec00389-002-s028><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen 61 und sprachen: Er hat gesagt: Ich kann den Tempel GOttes abbrechen und in dreien Tagen denselben bauen.
<G-vec00389-002-s028><destroy.abbrechen><en> Finally, two men came forward 61 who declared, "This man said, 'I am able to destroy the Temple of God and rebuild it in three days.'"
<G-vec00389-002-s029><destroy.abbrechen><de> 14:57 Und etliche standen auf und gaben falsches Zeugnis wider ihn und sprachen: 14:58 Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s029><destroy.abbrechen><en> 57Some stood up and began to give false testimony against Him, saying, 58“We heard Him say, ‘I will destroy this temple made with hands, and in three days I will build another made without hands.’”
<G-vec00389-002-s030><destroy.abbrechen><de> 58 Wir haben gehört, dass er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s030><destroy.abbrechen><en> 58 “We heard him say, ‘I will destroy this temple made with human hands and in three days will build another, not made with hands.’ ”
<G-vec00296-003-s019><break_down.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00296-003-s019><break_down.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00296-003-s020><break_down.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00296-003-s020><break_down.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00296-003-s021><break_down.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00296-003-s021><break_down.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00296-003-s022><break_down.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00296-003-s022><break_down.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00296-003-s023><break_down.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00296-003-s023><break_down.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00296-003-s024><break_down.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00296-003-s024><break_down.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00296-003-s025><break_down.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00296-003-s025><break_down.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00296-003-s026><break_down.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00296-003-s026><break_down.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00296-003-s027><break_down.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00296-003-s027><break_down.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00296-003-s028><break_down.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00296-003-s028><break_down.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00296-003-s029><break_down.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00296-003-s029><break_down.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00296-003-s030><break_down.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00296-003-s030><break_down.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00296-003-s031><break_down.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00296-003-s031><break_down.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00296-003-s032><break_down.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00296-003-s032><break_down.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00296-003-s033><break_down.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00296-003-s033><break_down.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00296-003-s034><break_down.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00296-003-s034><break_down.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00296-003-s035><break_down.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00296-003-s035><break_down.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00296-003-s036><break_down.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00296-003-s036><break_down.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00296-003-s037><break_down.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00296-003-s037><break_down.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00486-002-s019><suspend.abbrechen><de> Denn es ist einfach unmöglich durchzuführen und zu kontrollieren, daß die zu Übungen oder gar zu den Kontrollversammlungen einberufenen Mannschaften zum Beispiel ihr Verhältnis zu den Gewerkschaften und andren sogenannten revolutionären Organisationen für die Dauer ihrer Übung oder gar für die Dauer des Tags der Kontrollversammlung lösen, daß sie für diese Zeit die Abonnements auf die Arbeiterblätter abbrechen (eine technisch gar nicht durchführbare Sache) oder gar, daß sie in dieser Zeit die verpönte revolutionäre Literatur aus ihrer Wohnung verbannen und nicht lesen.
<G-vec00486-002-s019><suspend.abbrechen><en> It is simply impossible to control such persons, to enforce for example that they sever their connections with the trade unions and other so-called revolutionary organizations for the duration of their training or even on the day of the inspection, or that they should for the period in question suspend their subscriptions to the labour papers (a technical impossibility), or even that they should for this period cease to read the forbidden revolutionary literature and banish it from their homes.
<G-vec00486-002-s020><suspend.abbrechen><de> - Bei allergischen Reaktionen auf das Gel der Elektroden die Behandlung abbrechen und einen Arzt aufsuchen.
<G-vec00486-002-s020><suspend.abbrechen><en> - Patients allergic to the gel of the electrodes should suspend treatment and see a doctor.
<G-vec00486-002-s021><suspend.abbrechen><de> • Bei allergischen Reaktionen auf das Gel der Elektroden die Behandlung abbrechen und einen Arzt aufsuchen.
<G-vec00486-002-s021><suspend.abbrechen><en> • In case of allergy to the electrode gel, suspend treatment and see a doctor.
