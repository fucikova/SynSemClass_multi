<G-vec00547-001-s053><bother.behelligen><de> Solange das Mana floss, würde niemand sie behelligen.
<G-vec00547-001-s053><bother.behelligen><en> As long as the mana kept moving, nobody would bother them.
<G-vec00547-001-s054><bother.behelligen><de> Ihr könnt los lassen, was euch behelligt oder behelligen könnte oder behelligt hat.
<G-vec00547-001-s054><bother.behelligen><en> You can let go of that which bothers you or might bother you or has bothered you.
<G-vec00547-001-s055><bother.behelligen><de> Der Professor Ladenburg kennt kein Substrat der Seele; also soll er die Welt nicht mit den Ergebnissen seiner Unkenntnis behelligen.
<G-vec00547-001-s055><bother.behelligen><en> Professor Ladenburg does not know anything about a substratum of the soul; he, therefore, should not bother the world with the findings of his ignorance.
