<G-vec00372-002-s285><weigh.abwiegen><de> Wiege keine Situationen und keine Erfahrung in Bezug auf ihren augenscheinlichen Wert ab.
<G-vec00372-002-s285><weigh.abwiegen><en> Do not weigh situations and experience in terms of their apparent value.
<G-vec00372-002-s286><weigh.abwiegen><de> Wiege die Vor- und Nachteile eines Spiegels ab.
<G-vec00372-002-s286><weigh.abwiegen><en> Weigh the pros and cons of a mirror.
