<G-vec00078-001-s044><commit.begehen><de> Demnach haben Verurteilte in speziellen Bildungsprogrammen eine um 43 Prozent geringere Wahrscheinlichkeit, erneut Straftaten zu begehen, und 13 Prozent erhöhen ihre Chancen, nach ihrer Entlassung eine Arbeit zu finden.
<G-vec00078-001-s044><commit.begehen><en> According to this, convicts in special educational programs are 43 percent less likely to commit crimes again and 13 percent increase their chances of finding work after their release.
<G-vec00078-001-s045><commit.begehen><de> Das gilt selbst für die meisten der sogenannten Mehrfach- und Intensivtäter, also Jugendliche die oft Straftaten begehen oder sehr gewalttätig sind.
<G-vec00078-001-s045><commit.begehen><en> This applies even to prolific and serial offenders, young people who often commit crimes or are very violent.
<G-vec00078-001-s046><commit.begehen><de> Hinzu kommt, dass, Geld Cyber-Kriminelle geben wird höchstwahrscheinlich dazu motivieren, mehr Ransomware Viren zu erstellen oder andere kriminelle Aktivitäten begehen.
<G-vec00078-001-s046><commit.begehen><en> Adding to that, giving money to cybercriminals will most likely motivate them to create more ransomware viruses or commit different criminal activities.
<G-vec00078-001-s047><commit.begehen><de> Beamte der Regierung begehen alle Formen von Verbrechen, wenn sie einmal an der Macht sind und Geld haben.
<G-vec00078-001-s047><commit.begehen><en> Government officials commit all types of crimes once they have power and money.
<G-vec00078-001-s048><commit.begehen><de> Die katholische Kirche hat einen solchen Einfluß in der Gesellschaft, durch ihre Mitglieder, durch Korruption, durch Bestechung, und alle anderen Manipulationen, daß jeder katholische Priester weiß, daß seine Position grundsätzlich absolut sicher ist, jede Art von Verbrechen zu begehen, die er will.
<G-vec00078-001-s048><commit.begehen><en> The Catholic Church has such an influence in society, through their members, through corruption, through bribery, and all other kinds of manipulation, that every Catholic priest knows that his position is basically absolute safe for him to commit any crime he wants.
<G-vec00078-001-s049><commit.begehen><de> Später sagten sie, dass Frau Zhao Selbstmord begehen wollte.
<G-vec00078-001-s049><commit.begehen><en> Later, they said that Ms. Zhao wanted to commit suicide.
<G-vec00078-001-s050><commit.begehen><de> Naturns hat eine Seilbahn und viele Wanderwege von leicht bis schwer zu begehen.
<G-vec00078-001-s050><commit.begehen><en> Naturns has to commit a cable car and many hiking trails from easy to difficult.
<G-vec00078-001-s051><commit.begehen><de> Das schließt die Sünden ein, die der Gläubige vor der Bekehrung beging, und auch die Sünden, die er nach der Bekehrung noch begehen wird.
<G-vec00078-001-s051><commit.begehen><en> This includes the sins the believer committed before salvation and the ones he has committed and will commit after salvation.
<G-vec00078-001-s052><commit.begehen><de> Das US-Justizministerium erklärt: Der Patriot Act verhängt harte Strafen über diejenigen, die terroristische Operationen begehen und unterstützen, sowohl zu Hause als auch im Ausland.
<G-vec00078-001-s052><commit.begehen><en> "According to the US Justice Department: The Patriot Act imposed tough new penalties on those who commit and support terrorist operations, both at home and abroad."""
<G-vec00078-001-s053><commit.begehen><de> Sie begehen ihre Zeit und Know-how, damit Programme und Dienste besser Gemeinschaften unterstützen.
<G-vec00078-001-s053><commit.begehen><en> They commit their time and expertise so that programs and services better support communities.
<G-vec00078-001-s054><commit.begehen><de> Eine Todsünde begehen für euer Land, euren Glauben oder aus Haß, wird eure Seele kosten, und kein Land ist das wert.
<G-vec00078-001-s054><commit.begehen><en> To commit mortal sin for your country, your faith, or in revenge will cost your soul and no country is worth that.
<G-vec00078-001-s055><commit.begehen><de> Davon ausgehend versteht das Oberste Gericht Rußlands unter ihr “eine dauerhafte Gruppe aus zwei oder mehr Personen, die durch den Vorsatz verbunden [sind], eine oder mehrere Straftaten zu begehen”.43 Sie sei in aller Regel durch ein hohes Maß an Organisiertheit, Planmäßigkeit und die sorgfältige Vorbereitung der Straftat, durch die Verteilung der Rollen zwischen den Teilnehmern gekennzeichnet.
<G-vec00078-001-s055><commit.begehen><en> Russia’s Supreme Court understands the term to mean “a permanent group of two or more people who are linked to one another by the intent to commit one or more criminal offences.”43 As a rule, an “organized group” is characterized by a high level of organization, planning, and careful preparation of a criminal offence with roles distributed among the participants.
<G-vec00078-001-s056><commit.begehen><de> "Zur Beteuerung der Medien, ""kein Amerikaner würde so etwas Schreckliches tun und dabei auch noch Selbstmord begehen"", muss daran erinnert werden, daß es schon 1995 mit dem Bombenanschlag in Oklahoma City einen Fall massenmörerischen Terrorismus gab, an dem der amerikanische Militärveteran Timothy McVeigh beteiligt war."
<G-vec00078-001-s056><commit.begehen><en> "Concerning the media line that ""no American would commit such an monstrous act of destruction combined with suicide,"" it must be recalled, that in 1995, there was the mass terrorism in Oklahoma City, carried out by the American military veteran Timothy McVeigh ."
<G-vec00078-001-s057><commit.begehen><de> In diesem Fall ist die Aufgabe der Schutz nicht so sehr die andere Nutzer als Anwender selbst “allmählich”, wie im betrunkenen Zustand, er kann Hautausschlag Handlungen zu begehen, und im virtuellen Raum.
<G-vec00078-001-s057><commit.begehen><en> In this case, the object of protection is not so much the other users as user himself “by degrees”, as in a drunken state, he can commit rash acts, and in virtual space.
<G-vec00078-001-s058><commit.begehen><de> Diejenigen, die die mütterliche Rolle einer Frau mißachen, sie mit Tyrannei oder mit Strenge behandeln, begehen eine sehr ernsthafte Sünde.
<G-vec00078-001-s058><commit.begehen><en> Those who treat a woman's motherly role with contempt, tyranny, or harshness commit a very grave sin.
<G-vec00078-001-s059><commit.begehen><de> Noch rücksichtslosere und hart gesottenere Kriminelle begehen Fahrzeugentführungen.
<G-vec00078-001-s059><commit.begehen><en> More ruthless, hardened criminals commit car-jackings.
<G-vec00078-001-s060><commit.begehen><de> Auf der Basis dieser Elitevorstellung fällt es ihnen leicht, politisch motivierte Verbrechen zu begehen oder zu akzeptieren.
<G-vec00078-001-s060><commit.begehen><en> On the basis of these elite ideas it is easy for them to commit politically motivated crimes or to accept them.
<G-vec00078-001-s061><commit.begehen><de> Einige Menschen arbeiten wirklich hart und begehen keine Sünden.
<G-vec00078-001-s061><commit.begehen><en> Some people are working very hard and do not commit sins.
<G-vec00078-001-s062><commit.begehen><de> Einige seiner berühmtesten Oxymorons aus dem Stück kommen vor, als Juliet anfangs der Meinung war, Romeo sei ein kaltblütiger Mörder, kann aber auch nicht glauben, dass jemand, der so schön ist, eine so hässliche Tat begehen könnte.
<G-vec00078-001-s062><commit.begehen><en> Some of his most famous oxymorons from the play occur when Juliet initially believes that Romeo is a cold-blooded murderer, but also can't believe that someone so beautiful could commit such an ugly deed.
<G-vec00078-001-s063><commit.begehen><de> Wenn eine Zeuge Jehovas Gewalttätigkeit oder andere Verbrechen begeht, ernennt die Versammlung ein Komitee aus Ältesten, um sich des Problems anzunehmen, und weisen mit der Bibel zurecht, statt zur Polizei zu gehen.
<G-vec00078-001-s063><commit.begehen><en> If a Jehovah's Witness commit violence or other crimes, the congregation appoints a committee of elders to deals with the problem and gives biblical reprimands instead of going to the police.
<G-vec00078-001-s064><commit.begehen><de> Wenn er gegen die Gebote Gottes verstößt, begeht er Sünde und ist der ewigen Verdammnis verfallen.
<G-vec00078-001-s064><commit.begehen><en> If they violate God’s commandments, they commit sin and fall into eternal damnation.
<G-vec00078-001-s065><commit.begehen><de> Es fallen euch jegliche Sünden zur Last, die ihr begeht an eurem Nächsten und ihr somit auch wider Mich Selbst sündigt, Der Ich euch das Gebot der Liebe gab.
<G-vec00078-001-s065><commit.begehen><en> All sins become a burden on you, which you commit against your neighbour and therefore also again sin against me myself, who gave to you the commandment of love.
<G-vec00078-001-s066><commit.begehen><de> Wenn ein einzelner Muslim eine terroristische Handlung begeht, macht sich diese Person im Sinne der islamischen Gesetze strafbar.
<G-vec00078-001-s066><commit.begehen><en> If an individual Muslim were to commit an act of terrorism, this person would be guilty of violating the laws of Islam.
<G-vec00078-001-s067><commit.begehen><de> Doch sowohl Kaganowitsch wie Ordshonikidse fahren gleichsam absichtlich nicht nach Tscheljabinsk, jedenfalls begegnet N. Lurie dort niemandem von ihnen und begeht folglich auch kein Attentat.
<G-vec00078-001-s067><commit.begehen><en> But neither Kaganovich nor Ordzhonikidze, as if on purpose, comes to Cheliabinsk; in any case, N. Lurie does not meet any of them there and does not commit, of course, any attack.
<G-vec00078-001-s068><commit.begehen><de> So ihn das Weib verlässt und ehelicht einen andern, so begeht sie keinen Ehebruch.
<G-vec00078-001-s068><commit.begehen><en> If the wife leaves him and marries another, she does not commit adultery.
<G-vec00078-001-s069><commit.begehen><de> Wenn ihr immer euren eigenen Verstand benutzt ohne seine Hilfe in Anspruch zu nehmen, dann ist es ganz normal, dass ihr Fehler begeht.
<G-vec00078-001-s069><commit.begehen><en> If you always use your own mind without ever taking its support, then it is but natural that you will commit mistakes.
<G-vec00078-001-s070><commit.begehen><de> 17 Der Jähzornige begeht Narrheit, und der Ränkeschmied wird gehaßt.
<G-vec00078-001-s070><commit.begehen><en> 17 He who is quick to become angry will commit folly, and a crafty man is hated.
<G-vec00078-001-s071><commit.begehen><de> Wenn man ein Verbrechen begeht, das gegen die U-Bahnregeln ist, kann die U-Bahn für diese Person für das ganze Leben verboten werden.
<G-vec00078-001-s071><commit.begehen><en> If you commit a crime that goes against the subway rules you can be banned for life.
<G-vec00078-001-s072><commit.begehen><de> "Sogenannte ""Grey Hat Hacker"" halten sich hufig an eine andere Form von Hacker-Ethik, die besagt, dass es akzeptabel ist, in Systeme einzubrechen, solange der Hacker nicht Diebstahl begeht oder den Datenschutz verletzt."
<G-vec00078-001-s072><commit.begehen><en> Grey hat hackers typically subscribe to another form of the hacker ethic, which says it is acceptable to break into systems as long as the hacker does not commit theft or breach confidentiality.
<G-vec00078-001-s073><commit.begehen><de> 9 Doch nehmt ihr auf die Menschen Rücksicht, alsdann begeht ihr eine Sünde, und es überführt euch das Gesetz als Übertreter.
<G-vec00078-001-s073><commit.begehen><en> 9 But if ye have respect of persons, ye commit sin, being convicted by the law as transgressors.
<G-vec00078-001-s074><commit.begehen><de> In Bezug auf terroristische Straftaten kann der Gesetzgeber stattdessen aber auch darauf abstellen, ob das individuelle Verhalten einer Person die konkrete Wahrscheinlichkeit begründet, dass sie in überschaubarer Zukunft terroristische Straftaten begeht (siehe oben C IV 1 b).
<G-vec00078-001-s074><commit.begehen><en> In respect of terrorist offences, the legislature can alternatively also apply the standard of whether the individual behaviour of a person substantiates the specific probability that the person will commit a terrorist offence in the near future (see above, C IV 1 b).
<G-vec00078-001-s075><commit.begehen><de> 22:29 Das Volk des Landes verübt Erpressung und begeht Raub; und den Elenden und Dürftigen bedrücken sie, und den Fremdling übervorteilen sie widerrechtlich.
<G-vec00078-001-s075><commit.begehen><en> 22:29 The people of the land practice extortion and commit robbery; they oppress the poor and needy and mistreat the alien, denying them justice.
<G-vec00078-001-s076><commit.begehen><de> Das widerspricht jedoch einem Urteil des Europäischen Menschenrechtsgerichtshofs: Das Recht auf friedliche Versammlungsfreiheit ist demgemäss so wichtig, dass niemand für die Teilnahme an einer Demonstration bestraft werden darf, solange er oder sie keine Straftat begeht.
<G-vec00078-001-s076><commit.begehen><en> "Young people who have no job cannot afford to pay the fines."" The European Court of Human Rights has stated that freedom to take part in a peaceful assembly is of such importance that participants should not be penalised unless they commit a crime."
