<G-vec00092-001-s038><request.anfordern><de> Beschwerden und weitere Informationen: Falls Sie eine Beschwerde einreichen oder weitere Informationen anfordern möchten, können Sie sich schriftlich, telefonisch oder per Email an den Anbieter wenden.
<G-vec00092-001-s038><request.anfordern><en> Complaints and further information: In the event of a complaint, or to request further information, the provider may be contacted in writing at Garmin International, Inc.
<G-vec00092-001-s039><request.anfordern><de> Zum anfordern oder erneuern eines Tokens klicken Sie auf «Token anfordern».
<G-vec00092-001-s039><request.anfordern><en> To request or renew a token, click on «Request Token».
<G-vec00092-001-s040><request.anfordern><de> Zum anfordern oder erneuern eines Tokens klicken Sie auf «Token anfordern».
<G-vec00092-001-s040><request.anfordern><en> To request or renew a token, click on «Request Token».
<G-vec00092-001-s041><request.anfordern><de> Angebot anfordern Ihre Informationsanfrage wurde gesendet an: BEULCO GMBH & CO.
<G-vec00092-001-s041><request.anfordern><en> Your request for information has been sent to: BEULCO GMBH & CO.
<G-vec00092-001-s042><request.anfordern><de> Die personenbezogenen von den Nutzern, die zu übermittelndes Informationsmaterial anfordern, angegebenen Daten werden ausschließlich genutzt, um die angeforderten Dienstleistungen auszuführen, und werden Dritten nur dann mitgeteilt, wenn dies im Rahmen dieses Zwecks erforderlich ist (Spediteure).
<G-vec00092-001-s042><request.anfordern><en> Personal data supplied by those users who request any material (information, e-shop), used exclusively to carry out the service or the order: they are given to third parties only if it is necessary (e.g. for courier services).
<G-vec00092-001-s043><request.anfordern><de> Auch bei einem medizinischen Notfall oder als Zeuge eines Unfalls genügt ein Druck auf den Notruf-Knopf und ein OnStar-Ansprechpartner kann Hilfe anfordern.
<G-vec00092-001-s043><request.anfordern><en> Even if it's a medical emergency, or you witness a crash, just press your emergency button and OnStar can request help.
<G-vec00092-001-s044><request.anfordern><de> In einigen Fällen kann die Datenschutzbehörde Nachrichten und Informationen gemäß Artikel 157 und nachfolgender Artikel des Kodex anfordern, um die Verarbeitung personenbezogener Daten zu kontrollieren.
<G-vec00092-001-s044><request.anfordern><en> In some cases, the Data Protection Authority may request news and information in accordance with Article 157 and subsequent Articles of the Code, for personal data processing control purposes.
<G-vec00092-001-s045><request.anfordern><de> Wenn Sie Informationsmaterial auf dem Postweg anfordern möchten, laden Sie bitte das entsprechende PDF-Dokument herunter und schicken Sie es uns ausgefüllt zu.
<G-vec00092-001-s045><request.anfordern><en> If you want to request information by mail, please download the according PDF document, complete it and send it back to us.
<G-vec00092-001-s046><request.anfordern><de> Mit mod_rewrite können Sie URLs auf Basis verschiedener Regeln umleiten, Header anfordern und einiges mehr.
<G-vec00092-001-s046><request.anfordern><en> With mod_rewrite, you can redirect URLs based on multiple rules, request headers, and more.
<G-vec00092-001-s047><request.anfordern><de> Online-Reparaturanfrage Über diese Online-Reparaturanfrage können Sie einen Servicetechniker zur Reparatur Ihres Liebherr-Gerätes anfordern.
<G-vec00092-001-s047><request.anfordern><en> You can use this online repair order to request a service technician to repair your Liebherr appliance.
<G-vec00092-001-s048><request.anfordern><de> Uhrenkollektionen kostenlos anfordern.
<G-vec00092-001-s048><request.anfordern><en> watch collections request free.
<G-vec00092-001-s049><request.anfordern><de> Stammdaten, Kontaktdaten und etwaige Spezialkategorien von personenbezogenen Daten Je nach den vom Benutzer geforderten Diensten kann die FIRMA je nach Bedarf folgende Informationen anfordern: Von der FIRMA zugewiesener Lieferantencode, Firmenname, Name des Anfragenden, Funktion des Anfragenden, Land, Telefon, Fax, E-Mail-Adresse des Betriebs usw.
<G-vec00092-001-s049><request.anfordern><en> Personal data, contact data and any other particular category of Personal Data Depending on the services required by the User, the COMPANY may request information, such as: Supplier code assigned by the COMPANY, Company name, Name of the inquirer, Company role of the inquirer, Country, Telephone, Fax, Company e-mail, etc.
<G-vec00092-001-s050><request.anfordern><de> Eine Ihrer besten Ressourcen ist unsere Expat Services-Website, Expat-Quotes, in der Sie sich befinden kann Beiträge von Expats lesen, die in Zypern leben und kostenlose Angebote anfordern.
<G-vec00092-001-s050><request.anfordern><en> One of your best resources is our expat services site, Expat-Quotes, in which you can read posts by expats who live in Cyprus and request free quotes.
<G-vec00092-001-s051><request.anfordern><de> Beschreibung:Touristischer Ort, Siegel-Heiligtum, anfordern.
<G-vec00092-001-s051><request.anfordern><en> Description:Tourist place, seal sanctuary, request.
<G-vec00092-001-s052><request.anfordern><de> Wenn Sie ein Preisangebot anfordern, werden Sie eine Rechnung erhalten.
<G-vec00092-001-s052><request.anfordern><en> When you request a price quote you will be given an invoice.
<G-vec00092-001-s053><request.anfordern><de> (ein) In dem unwahrscheinlichen Fall, dass OutlookImport nicht in der Lage, eine Dateireparatur durchzuführen ist, Wir behalten uns ausdrücklich das Recht zum anfordern und empfangen eine Kopie der beschädigten Datei, wo der Kunde uns eines Ausfalls des OutlookImport benachrichtigt zu reparieren oder wiederherstellen die betroffene Datei.
<G-vec00092-001-s053><request.anfordern><en> (a) In the unlikely event that OutlookImport is unable to perform a file repair, we expressly reserve the right to request and receive a copy of the damaged file where the customer notifies us of a failure of OutlookImport to repair or recover the affected file.
<G-vec00092-001-s054><request.anfordern><de> „Ein Angebot muss der Kunde im Vorfeld nicht mehr anfordern.
<G-vec00092-001-s054><request.anfordern><en> """The buyer must no longer request a quotation in advance."
<G-vec00092-001-s055><request.anfordern><de> Die persönlichen Daten von Nutzern, die Versendung von Informationsmaterial anfordern wird nur verwendet, um den Service oder Hilfe angefordert auszuführen und werden nur an Dritte weitergegeben, wenn dies zu diesem Zweck notwendig ist.
<G-vec00092-001-s055><request.anfordern><en> The personal information provided by users who request dispatch of informative material is used only to perform the service or assistance requested and are disclosed to third parties only if this is necessary for that purpose.
<G-vec00092-001-s056><request.anfordern><de> (c) Wenn das Boot, gegen das protestiert wurde, nicht reagiert, kann das protestierende Boot durch deutlich sichtbares Zeigen einer gelben Flagge und Rufen des Wortes „Umpire“ eine Entscheidung anfordern.
<G-vec00092-001-s056><request.anfordern><en> (c) If the protested boat fails to respond, the protesting boat may request a decision by conspicuously displaying a yellow flag and hailing ‘Umpire’.
<G-vec00272-001-s038><request.anfordern><de> Beschwerden und weitere Informationen: Falls Sie eine Beschwerde einreichen oder weitere Informationen anfordern möchten, können Sie sich schriftlich, telefonisch oder per Email an den Anbieter wenden.
<G-vec00272-001-s038><request.anfordern><en> Complaints and further information: In the event of a complaint, or to request further information, the provider may be contacted in writing at Garmin International, Inc.
<G-vec00272-001-s039><request.anfordern><de> Zum anfordern oder erneuern eines Tokens klicken Sie auf «Token anfordern».
<G-vec00272-001-s039><request.anfordern><en> To request or renew a token, click on «Request Token».
<G-vec00272-001-s040><request.anfordern><de> Zum anfordern oder erneuern eines Tokens klicken Sie auf «Token anfordern».
<G-vec00272-001-s040><request.anfordern><en> To request or renew a token, click on «Request Token».
<G-vec00272-001-s041><request.anfordern><de> Angebot anfordern Ihre Informationsanfrage wurde gesendet an: BEULCO GMBH & CO.
<G-vec00272-001-s041><request.anfordern><en> Your request for information has been sent to: BEULCO GMBH & CO.
<G-vec00272-001-s042><request.anfordern><de> Die personenbezogenen von den Nutzern, die zu übermittelndes Informationsmaterial anfordern, angegebenen Daten werden ausschließlich genutzt, um die angeforderten Dienstleistungen auszuführen, und werden Dritten nur dann mitgeteilt, wenn dies im Rahmen dieses Zwecks erforderlich ist (Spediteure).
<G-vec00272-001-s042><request.anfordern><en> Personal data supplied by those users who request any material (information, e-shop), used exclusively to carry out the service or the order: they are given to third parties only if it is necessary (e.g. for courier services).
<G-vec00272-001-s043><request.anfordern><de> Auch bei einem medizinischen Notfall oder als Zeuge eines Unfalls genügt ein Druck auf den Notruf-Knopf und ein OnStar-Ansprechpartner kann Hilfe anfordern.
<G-vec00272-001-s043><request.anfordern><en> Even if it's a medical emergency, or you witness a crash, just press your emergency button and OnStar can request help.
<G-vec00272-001-s044><request.anfordern><de> In einigen Fällen kann die Datenschutzbehörde Nachrichten und Informationen gemäß Artikel 157 und nachfolgender Artikel des Kodex anfordern, um die Verarbeitung personenbezogener Daten zu kontrollieren.
<G-vec00272-001-s044><request.anfordern><en> In some cases, the Data Protection Authority may request news and information in accordance with Article 157 and subsequent Articles of the Code, for personal data processing control purposes.
<G-vec00272-001-s045><request.anfordern><de> Wenn Sie Informationsmaterial auf dem Postweg anfordern möchten, laden Sie bitte das entsprechende PDF-Dokument herunter und schicken Sie es uns ausgefüllt zu.
<G-vec00272-001-s045><request.anfordern><en> If you want to request information by mail, please download the according PDF document, complete it and send it back to us.
<G-vec00272-001-s046><request.anfordern><de> Mit mod_rewrite können Sie URLs auf Basis verschiedener Regeln umleiten, Header anfordern und einiges mehr.
<G-vec00272-001-s046><request.anfordern><en> With mod_rewrite, you can redirect URLs based on multiple rules, request headers, and more.
<G-vec00272-001-s047><request.anfordern><de> Online-Reparaturanfrage Über diese Online-Reparaturanfrage können Sie einen Servicetechniker zur Reparatur Ihres Liebherr-Gerätes anfordern.
<G-vec00272-001-s047><request.anfordern><en> You can use this online repair order to request a service technician to repair your Liebherr appliance.
<G-vec00272-001-s048><request.anfordern><de> Uhrenkollektionen kostenlos anfordern.
<G-vec00272-001-s048><request.anfordern><en> watch collections request free.
<G-vec00272-001-s049><request.anfordern><de> Stammdaten, Kontaktdaten und etwaige Spezialkategorien von personenbezogenen Daten Je nach den vom Benutzer geforderten Diensten kann die FIRMA je nach Bedarf folgende Informationen anfordern: Von der FIRMA zugewiesener Lieferantencode, Firmenname, Name des Anfragenden, Funktion des Anfragenden, Land, Telefon, Fax, E-Mail-Adresse des Betriebs usw.
<G-vec00272-001-s049><request.anfordern><en> Personal data, contact data and any other particular category of Personal Data Depending on the services required by the User, the COMPANY may request information, such as: Supplier code assigned by the COMPANY, Company name, Name of the inquirer, Company role of the inquirer, Country, Telephone, Fax, Company e-mail, etc.
<G-vec00272-001-s050><request.anfordern><de> Eine Ihrer besten Ressourcen ist unsere Expat Services-Website, Expat-Quotes, in der Sie sich befinden kann Beiträge von Expats lesen, die in Zypern leben und kostenlose Angebote anfordern.
<G-vec00272-001-s050><request.anfordern><en> One of your best resources is our expat services site, Expat-Quotes, in which you can read posts by expats who live in Cyprus and request free quotes.
<G-vec00272-001-s051><request.anfordern><de> Beschreibung:Touristischer Ort, Siegel-Heiligtum, anfordern.
<G-vec00272-001-s051><request.anfordern><en> Description:Tourist place, seal sanctuary, request.
<G-vec00272-001-s052><request.anfordern><de> Wenn Sie ein Preisangebot anfordern, werden Sie eine Rechnung erhalten.
<G-vec00272-001-s052><request.anfordern><en> When you request a price quote you will be given an invoice.
<G-vec00272-001-s053><request.anfordern><de> (ein) In dem unwahrscheinlichen Fall, dass OutlookImport nicht in der Lage, eine Dateireparatur durchzuführen ist, Wir behalten uns ausdrücklich das Recht zum anfordern und empfangen eine Kopie der beschädigten Datei, wo der Kunde uns eines Ausfalls des OutlookImport benachrichtigt zu reparieren oder wiederherstellen die betroffene Datei.
<G-vec00272-001-s053><request.anfordern><en> (a) In the unlikely event that OutlookImport is unable to perform a file repair, we expressly reserve the right to request and receive a copy of the damaged file where the customer notifies us of a failure of OutlookImport to repair or recover the affected file.
<G-vec00272-001-s054><request.anfordern><de> „Ein Angebot muss der Kunde im Vorfeld nicht mehr anfordern.
<G-vec00272-001-s054><request.anfordern><en> """The buyer must no longer request a quotation in advance."
<G-vec00272-001-s055><request.anfordern><de> Die persönlichen Daten von Nutzern, die Versendung von Informationsmaterial anfordern wird nur verwendet, um den Service oder Hilfe angefordert auszuführen und werden nur an Dritte weitergegeben, wenn dies zu diesem Zweck notwendig ist.
<G-vec00272-001-s055><request.anfordern><en> The personal information provided by users who request dispatch of informative material is used only to perform the service or assistance requested and are disclosed to third parties only if this is necessary for that purpose.
<G-vec00272-001-s056><request.anfordern><de> (c) Wenn das Boot, gegen das protestiert wurde, nicht reagiert, kann das protestierende Boot durch deutlich sichtbares Zeigen einer gelben Flagge und Rufen des Wortes „Umpire“ eine Entscheidung anfordern.
<G-vec00272-001-s056><request.anfordern><en> (c) If the protested boat fails to respond, the protesting boat may request a decision by conspicuously displaying a yellow flag and hailing ‘Umpire’.
<G-vec00272-001-s020><solicit.anfordern><de> "Diese anderen Webseiten können unabhängig voneinander Daten sammeln, persönliche Informationen anfordern oder Ihnen eigene ""Cookies"" senden."
<G-vec00272-001-s020><solicit.anfordern><en> "These other sites may independently collect data, solicit personal information, or send their own ""cookies"" to you."
<G-vec00272-001-s021><solicit.anfordern><de> In seltenen Fällen kann ein ForeSee-Kunde sich entscheiden, Kinder unter 13 Jahren zu befragen; bei solchen Befragungen werden aber keine personenbezogenen Daten angefordert.
<G-vec00272-001-s021><solicit.anfordern><en> In rare instances, a ForeSee Client may choose to survey children under 13; such surveys will not solicit Personal Data.
<G-vec00272-001-s022><solicit.anfordern><de> Über diese externen Websites können eigene Cookies an Benutzer gesendet, Daten erfasst oder personenbezogene Daten angefordert werden.
<G-vec00272-001-s022><solicit.anfordern><en> These other sites may send their own cookies to users, collect data, or solicit personal information.
<G-vec00092-001-s209><request.anfordern><de> Wir behalten uns vor, bei entscheidungserheblichen Fragen eine Übersetzung ins Deutsche anzufordern.
<G-vec00092-001-s209><request.anfordern><en> DEHSt reserves the right to request a German translation for questions material to making a decision.
<G-vec00092-001-s210><request.anfordern><de> Um die oben genannten Rechte ausüben zu können und Informationen anzufordern, können die Nutzer an folgende E-Mail-Adresse wolfenbuettel@engelvoelkers.com [A10] oder an die Postanschrift Engel & Völkers Braunschweig Immobilien GmbH, Lange Herzogstraße 43, 38300 Wolfenbüttel, Deutschland [A11] schreiben.
<G-vec00092-001-s210><request.anfordern><en> In order to exercise the above rights and request information, users can contact us at the email address: info@engelvoelkers.com or at the postal address: Engel & Völkers AG, Stadthausbrücke 5, 20355 Hamburg, Germany.
<G-vec00092-001-s211><request.anfordern><de> Die EZB und die BaFin haben gegenüber der Bank umfassende Aufsichts- und Ermittlungsbefugnisse einschließlich der Möglichkeit, Informationen anzufordern und Untersuchungen durchzuführen.
<G-vec00092-001-s211><request.anfordern><en> The ECB and the BaFin have extensive supervisory and investigatory powers with regard to the Bank, including the ability to request information and conduct investigations.
<G-vec00092-001-s212><request.anfordern><de> Sie haben auf unseren Webseiten verschiedene Möglichkeiten uns zu kontaktieren oder Informationen über unser Unternehmen anzufordern.
<G-vec00092-001-s212><request.anfordern><en> On our website you will find different ways of contacting us. Furthermore you have the possibility to request information.
<G-vec00092-001-s213><request.anfordern><de> "Aus Sicherheitsgründen bitten wir Sie, unter "" Passwort vergessen "" die E-Mail-Adresse Ihres Corbis Kontos einzugeben und ein neues Passwort anzufordern."
<G-vec00092-001-s213><request.anfordern><en> To ensure security, please go to the forgot password page, enter your Corbis account email address twice and request a new password.
<G-vec00092-001-s214><request.anfordern><de> Ermöglicht der App, die Installation von Paketen anzufordern.
<G-vec00092-001-s214><request.anfordern><en> Allows an application to request installation of packages.
<G-vec00092-001-s215><request.anfordern><de> Wenn Sie nicht mit dem Verlauf in der ersten erfüllt 3 Tagen der Nutzung können Sie Ihr Geld zurück, solange Sie nicht mehr als zugegriffen haben, anzufordern 50% des Kurses.
<G-vec00092-001-s215><request.anfordern><en> If you are not satisfied with the course within the first 3 days of usage you can request your money back as long as you haven’t accessed more than 50% of the course.
<G-vec00092-001-s216><request.anfordern><de> Um beim Browsen die Desktop-Version einer Website anzufordern, tippen Sie auf und auf den Schieberegler Desktop-Site .
<G-vec00092-001-s216><request.anfordern><en> To request the desktop version of a website, while browsing, tap and tap the Desktop site slider.
<G-vec00092-001-s217><request.anfordern><de> Die Subjekte, auf die sich die personenbezogenen Daten beziehen, haben jederzeit das Recht, eine Bestätigung über das Vorhandensein oder Nichtvorhandensein derselben mit dem Datenverwalter zu erhalten, seinen Inhalt und Ursprung zu kennen, seine Richtigkeit zu überprüfen oder seine Integration anzufordern die Löschung, Aktualisierung, Berichtigung, Umwandlung in anonyme Form oder Sperrung von personenbezogenen Daten, die unter Verletzung des Gesetzes verarbeitet werden, sowie aus legitimen Gründen in jedem Fall ihrer Verarbeitung zu widersprechen.
<G-vec00092-001-s217><request.anfordern><en> The subjects to whom the Personal Data refer have the right at any time to obtain confirmation of the existence or otherwise of the same with the Data Controller, to know its content and origin, to verify its accuracy or request its integration, the cancellation, updating, rectification, transformation into anonymous form or blocking of Personal Data processed in violation of the law, as well as to oppose in any case, for legitimate reasons, to their processing.
<G-vec00092-001-s218><request.anfordern><de> Wenden Sie sich unter Angabe Ihrer Kundennummer an Greenbone um einen entsprechenden Stick anzufordern.
<G-vec00092-001-s218><request.anfordern><en> Contact Greenbone providing your customer number to request a respective USB key.
<G-vec00092-001-s219><request.anfordern><de> Bitte folgen Sie dem nachstehenden Link, um digitale Informationen zu unserem Studienangebot anzufordern.
<G-vec00092-001-s219><request.anfordern><en> Please follow the link below to request information about our range of degree programmes in digital form.
<G-vec00092-001-s220><request.anfordern><de> *) Sie können ein Angebot anzufordern, wenn Sie größere Mengen über 100 Stück oder mehr bestellen möchten.
<G-vec00092-001-s220><request.anfordern><en> *) You can request a quote if you wish to order larger quantities over 100 pieces or more.
<G-vec00092-001-s221><request.anfordern><de> "Wenn Sie noch nicht registriert sind, auf ""Neuer Benutzer"" finden Sie und füllen Sie die Felder, um Ihre persönlichen Benutzernamen und Kennwort anzufordern."
<G-vec00092-001-s221><request.anfordern><en> If you have not registered yet, please go to “New user and fill in the boxes to request your personal user name and password.
<G-vec00092-001-s222><request.anfordern><de> Um den rechtzeitigen Erhalt der Eintrittskarten sicherzustellen, bitten wir die Aktionäre, die an der Hauptversammlung teilnehmen wollen, möglichst frühzeitig eine Eintrittskarte bei ihrem depotführenden Institut anzufordern.
<G-vec00092-001-s222><request.anfordern><en> In order to ensure the timely receipt of these admission cards, we ask that shareholders intending to attend the Annual General Meeting request an admission card from their depositary bank at the earliest possible time.
<G-vec00092-001-s223><request.anfordern><de> Sonst werden Größe- und Positionstipps verwendet, um das gewünschte Layout anzufordern.
<G-vec00092-001-s223><request.anfordern><en> Otherwise, it uses size and position hints to request the desired layout.
<G-vec00092-001-s224><request.anfordern><de> Untersuchen Sie die Nutzungsbedingungen und vergleichen privaten Versicherungsunternehmen vor der Anmeldung und ein Angebot anzufordern.
<G-vec00092-001-s224><request.anfordern><en> Investigate the terms and compare private insurance companies before signing up and request a quote.
<G-vec00092-001-s225><request.anfordern><de> Klicken Sie auf Wiederherstellen, um die Wiederherstellungsaktion anzufordern.
<G-vec00092-001-s225><request.anfordern><en> Click Restore to request the file restore action.
<G-vec00092-001-s226><request.anfordern><de> Recht auf Auskunft Sie haben das Recht, jederzeit eine Bestätigung von uns darÃ1⁄4ber anzufordern, welche Informationen wir Ã1⁄4ber Sie gespeichert haben, und uns aufzufordern, diese Informationen zu ändern, zu aktualisieren oder zu löschen.
<G-vec00092-001-s226><request.anfordern><en> Right to access information At any time, you have the right to request us to confirm which information we have saved about you, and to request that this information be changed, updated, or deleted.
<G-vec00092-001-s227><request.anfordern><de> Unter kalifornischem Recht haben Kunden von artnet, die ihren Wohnsitz in Kalifornien haben, die Möglichkeit, bestimmte Informationen bezüglich der Offenlegung ihrer personenbezogenen Daten gegenüber Dritten für deren Direktmarketing anzufordern.
<G-vec00092-001-s227><request.anfordern><en> Under California law, artnet customers residing in California may request certain information regarding the disclosure of personal information to third parties for their direct marketing purposes.
<G-vec00272-001-s209><request.anfordern><de> Wir behalten uns vor, bei entscheidungserheblichen Fragen eine Übersetzung ins Deutsche anzufordern.
<G-vec00272-001-s209><request.anfordern><en> DEHSt reserves the right to request a German translation for questions material to making a decision.
<G-vec00272-001-s210><request.anfordern><de> Um die oben genannten Rechte ausüben zu können und Informationen anzufordern, können die Nutzer an folgende E-Mail-Adresse wolfenbuettel@engelvoelkers.com [A10] oder an die Postanschrift Engel & Völkers Braunschweig Immobilien GmbH, Lange Herzogstraße 43, 38300 Wolfenbüttel, Deutschland [A11] schreiben.
<G-vec00272-001-s210><request.anfordern><en> In order to exercise the above rights and request information, users can contact us at the email address: info@engelvoelkers.com or at the postal address: Engel & Völkers AG, Stadthausbrücke 5, 20355 Hamburg, Germany.
<G-vec00272-001-s211><request.anfordern><de> Die EZB und die BaFin haben gegenüber der Bank umfassende Aufsichts- und Ermittlungsbefugnisse einschließlich der Möglichkeit, Informationen anzufordern und Untersuchungen durchzuführen.
<G-vec00272-001-s211><request.anfordern><en> The ECB and the BaFin have extensive supervisory and investigatory powers with regard to the Bank, including the ability to request information and conduct investigations.
<G-vec00272-001-s212><request.anfordern><de> Sie haben auf unseren Webseiten verschiedene Möglichkeiten uns zu kontaktieren oder Informationen über unser Unternehmen anzufordern.
<G-vec00272-001-s212><request.anfordern><en> On our website you will find different ways of contacting us. Furthermore you have the possibility to request information.
<G-vec00272-001-s213><request.anfordern><de> "Aus Sicherheitsgründen bitten wir Sie, unter "" Passwort vergessen "" die E-Mail-Adresse Ihres Corbis Kontos einzugeben und ein neues Passwort anzufordern."
<G-vec00272-001-s213><request.anfordern><en> To ensure security, please go to the forgot password page, enter your Corbis account email address twice and request a new password.
<G-vec00272-001-s214><request.anfordern><de> Ermöglicht der App, die Installation von Paketen anzufordern.
<G-vec00272-001-s214><request.anfordern><en> Allows an application to request installation of packages.
<G-vec00272-001-s215><request.anfordern><de> Wenn Sie nicht mit dem Verlauf in der ersten erfüllt 3 Tagen der Nutzung können Sie Ihr Geld zurück, solange Sie nicht mehr als zugegriffen haben, anzufordern 50% des Kurses.
<G-vec00272-001-s215><request.anfordern><en> If you are not satisfied with the course within the first 3 days of usage you can request your money back as long as you haven’t accessed more than 50% of the course.
<G-vec00272-001-s216><request.anfordern><de> Um beim Browsen die Desktop-Version einer Website anzufordern, tippen Sie auf und auf den Schieberegler Desktop-Site .
<G-vec00272-001-s216><request.anfordern><en> To request the desktop version of a website, while browsing, tap and tap the Desktop site slider.
<G-vec00272-001-s217><request.anfordern><de> Die Subjekte, auf die sich die personenbezogenen Daten beziehen, haben jederzeit das Recht, eine Bestätigung über das Vorhandensein oder Nichtvorhandensein derselben mit dem Datenverwalter zu erhalten, seinen Inhalt und Ursprung zu kennen, seine Richtigkeit zu überprüfen oder seine Integration anzufordern die Löschung, Aktualisierung, Berichtigung, Umwandlung in anonyme Form oder Sperrung von personenbezogenen Daten, die unter Verletzung des Gesetzes verarbeitet werden, sowie aus legitimen Gründen in jedem Fall ihrer Verarbeitung zu widersprechen.
<G-vec00272-001-s217><request.anfordern><en> The subjects to whom the Personal Data refer have the right at any time to obtain confirmation of the existence or otherwise of the same with the Data Controller, to know its content and origin, to verify its accuracy or request its integration, the cancellation, updating, rectification, transformation into anonymous form or blocking of Personal Data processed in violation of the law, as well as to oppose in any case, for legitimate reasons, to their processing.
<G-vec00272-001-s218><request.anfordern><de> Wenden Sie sich unter Angabe Ihrer Kundennummer an Greenbone um einen entsprechenden Stick anzufordern.
<G-vec00272-001-s218><request.anfordern><en> Contact Greenbone providing your customer number to request a respective USB key.
<G-vec00272-001-s219><request.anfordern><de> Bitte folgen Sie dem nachstehenden Link, um digitale Informationen zu unserem Studienangebot anzufordern.
<G-vec00272-001-s219><request.anfordern><en> Please follow the link below to request information about our range of degree programmes in digital form.
<G-vec00272-001-s220><request.anfordern><de> *) Sie können ein Angebot anzufordern, wenn Sie größere Mengen über 100 Stück oder mehr bestellen möchten.
<G-vec00272-001-s220><request.anfordern><en> *) You can request a quote if you wish to order larger quantities over 100 pieces or more.
<G-vec00272-001-s221><request.anfordern><de> "Wenn Sie noch nicht registriert sind, auf ""Neuer Benutzer"" finden Sie und füllen Sie die Felder, um Ihre persönlichen Benutzernamen und Kennwort anzufordern."
<G-vec00272-001-s221><request.anfordern><en> If you have not registered yet, please go to “New user and fill in the boxes to request your personal user name and password.
<G-vec00272-001-s222><request.anfordern><de> Um den rechtzeitigen Erhalt der Eintrittskarten sicherzustellen, bitten wir die Aktionäre, die an der Hauptversammlung teilnehmen wollen, möglichst frühzeitig eine Eintrittskarte bei ihrem depotführenden Institut anzufordern.
<G-vec00272-001-s222><request.anfordern><en> In order to ensure the timely receipt of these admission cards, we ask that shareholders intending to attend the Annual General Meeting request an admission card from their depositary bank at the earliest possible time.
<G-vec00272-001-s223><request.anfordern><de> Sonst werden Größe- und Positionstipps verwendet, um das gewünschte Layout anzufordern.
<G-vec00272-001-s223><request.anfordern><en> Otherwise, it uses size and position hints to request the desired layout.
<G-vec00272-001-s224><request.anfordern><de> Untersuchen Sie die Nutzungsbedingungen und vergleichen privaten Versicherungsunternehmen vor der Anmeldung und ein Angebot anzufordern.
<G-vec00272-001-s224><request.anfordern><en> Investigate the terms and compare private insurance companies before signing up and request a quote.
<G-vec00272-001-s225><request.anfordern><de> Klicken Sie auf Wiederherstellen, um die Wiederherstellungsaktion anzufordern.
<G-vec00272-001-s225><request.anfordern><en> Click Restore to request the file restore action.
<G-vec00272-001-s226><request.anfordern><de> Recht auf Auskunft Sie haben das Recht, jederzeit eine Bestätigung von uns darÃ1⁄4ber anzufordern, welche Informationen wir Ã1⁄4ber Sie gespeichert haben, und uns aufzufordern, diese Informationen zu ändern, zu aktualisieren oder zu löschen.
<G-vec00272-001-s226><request.anfordern><en> Right to access information At any time, you have the right to request us to confirm which information we have saved about you, and to request that this information be changed, updated, or deleted.
<G-vec00272-001-s227><request.anfordern><de> Unter kalifornischem Recht haben Kunden von artnet, die ihren Wohnsitz in Kalifornien haben, die Möglichkeit, bestimmte Informationen bezüglich der Offenlegung ihrer personenbezogenen Daten gegenüber Dritten für deren Direktmarketing anzufordern.
<G-vec00272-001-s227><request.anfordern><en> Under California law, artnet customers residing in California may request certain information regarding the disclosure of personal information to third parties for their direct marketing purposes.
<G-vec00272-001-s024><solicit.anfordern><de> Es kommt auch vor, dass der Stiefvater beginnt, sexuelle Handlungen mit dem Kind anzufordern oder auszuführen.
<G-vec00272-001-s024><solicit.anfordern><en> It also happens that the stepfather begins to solicit or perform acts of a sexual nature with the child.
<G-vec00272-001-s025><solicit.anfordern><de> das Benutzerkonto anderer ohne Erlaubnis zu verwenden oder die Anmeldedaten anderer Benutzer anzufordern, zu sammeln und zu verwenden.
<G-vec00272-001-s025><solicit.anfordern><en> Use another User's account without permission, or solicit, collect or use the login credentials of other users; or
<G-vec00272-001-s175><urge.anfordern><de> Zusätzlich zu den weiterhin andauernden Protesten vor den Chinesischen Botschaften und Konsulaten weltweit werden in vielen der Hauptstädte weltweit Proteste vor den Thailändischen Botschaften stattfinden, um die Thailändische Regierung dazu aufzufordern, sich nicht dem Druck der Chinesischen Botschaft zu beugen.
<G-vec00272-001-s175><urge.anfordern><en> In addition to the ongoing protests outside Chinese embassies and consulates worldwide, protests outside Thai embassies are under way in many of the world's major cities to urge the Thai government not to bow to Chinese government pressure.
<G-vec00272-001-s176><urge.anfordern><de> Wir bitten respektvoll, diese Angelegenheit mit Eutelsat weiterzuleiten und sie dazu aufzufordern, ihre Entscheidung, die Arbeit mit NTDTV aufzugeben, noch einmal zu überdenken.
<G-vec00272-001-s176><urge.anfordern><en> We respectfully request that you address this issue with Eutelsat and urge them to reconsider their decision to deny service to NTDTV.
<G-vec00272-001-s177><urge.anfordern><de> Die Teilnehmer sagten, daß sie ihren Parlamentsmitgliedern schreiben wollen, um sie dazu aufzufordern, die Resolution zu unterstützen.
<G-vec00272-001-s177><urge.anfordern><en> They said that they would write to their Members of Parliament and urge them to sign the motion.
<G-vec00272-001-s178><urge.anfordern><de> Über 28.000 Global Citizens haben deshalb eine Petition unterschrieben, um die Staats- und Regierungschefs der G20 dazu aufzufordern, in Präventionsmaßnahmen für Pandemien zu investieren - und zwar jetzt.
<G-vec00272-001-s178><urge.anfordern><en> So far, over 26,000 Global Citizens have signed a petition to urge the G20 to invest now in pandemic preparedness — ensuring our health systems are ready to manage the next big — and inevitable — outbreak of infectious diseases.
<G-vec00272-001-s078><solicit.anfordern><de> Diese anderen Websites können ihre eigenen Cookies oder andere Dateien auf Ihren Computer spielen, Daten erfassen oder persönliche Angaben von Ihnen anfordern.
<G-vec00272-001-s078><solicit.anfordern><en> These other websites may place their own cookies or other files on your computer, collect data or solicit personal information from you.
<G-vec00272-001-s087><solicit.anfordern><de> (Bush, der Microsoft bei der zweiten Verurteilung aus der Patsche half, wurde ins Microsoft-Hauptquartier eingeladen, um Geldmittel für die Wahlen 2000 anzufordern.
<G-vec00272-001-s087><solicit.anfordern><en> Microsoft persistently engages in anti-competitive behaviour, and has been convicted three times. (Bush, who let Microsoft off the hook for the second US conviction, was invited to Microsoft headquarters to solicit funds for the 2000 election.
