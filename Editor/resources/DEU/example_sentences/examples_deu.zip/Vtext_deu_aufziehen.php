<G-vec00169-001-s186><raise.aufziehen><de> Die Bibel warnt, dass Sex außerhalb der Ehe Sünde ist, gefährlich ist und zu Problemen führt, eines davon könnte sein, dass eine Frau ein Kind allein aufziehen muss, was zweifelsfrei sehr schwer ist.
<G-vec00169-001-s186><raise.aufziehen><en> The Bible warns that sex outside of marriage is sinful and dangerous and will bring troubles, one of which is that a woman might have to raise a child by herself, which is undoubtedly difficult.
<G-vec00169-001-s187><raise.aufziehen><de> Mein Ehemann starb bei einem Arbeitsunfall, als meine Tochter 18 Monate alt war, also musste ich sie alleine aufziehen.
<G-vec00169-001-s187><raise.aufziehen><en> My husband died of an accident at work when my daughter was 18 months old, so I had to raise her alone.
<G-vec00169-001-s188><raise.aufziehen><de> Ich blieb beim Aufsteigen stehen und versuchte daran zu denken, ob es in meiner Familie jemand gibt, der meine Kinder aufziehen könnte.
<G-vec00169-001-s188><raise.aufziehen><en> I stopped ascending and tried to think of someone in my family to raise my children.
<G-vec00169-001-s189><raise.aufziehen><de> Das Aufziehen der Jungen in der kargen Tundra ist nicht einfach.
<G-vec00169-001-s189><raise.aufziehen><en> It's not easy to raise chicks on the barren tundra.
<G-vec00169-001-s190><raise.aufziehen><de> Sie sollten Ihr Kind so aufziehen, dass Sie es nicht kontrollieren müssen, damit es zu allen Zeiten im vollen Besitz seiner selbst sein wird.
<G-vec00169-001-s190><raise.aufziehen><en> You want to raise your child in such a way that you don't have to control him, so that he will be in full possession of himself at all times.
<G-vec00169-001-s191><raise.aufziehen><de> Die Frau mag wohl selbst keine öffentliche Führung in der Gemeinde übernehmen, aber sie kann fromme Kinder aufziehen, die die zukünftigen gottgemäßen Führer werden.
<G-vec00169-001-s191><raise.aufziehen><en> While the woman may not exercise public leadership in the church, she can raise godly children who may become godly leaders of the future.
<G-vec00169-001-s192><raise.aufziehen><de> Sie wollen gegen den Willen ihrer Eltern ein Kind aufziehen und stehen dabei nicht nur vor finanziellen Herausforderungen.
<G-vec00169-001-s192><raise.aufziehen><en> They want to raise a child against the will of their parents, which poses not just financial challenges.
<G-vec00169-001-s193><raise.aufziehen><de> Mit dem Compact bietet Förster-Technik Milchviehbetrieben, die wenige Kälber pro Jahr aufziehen, ein kostengünstiges Einstiegsmodell in die automatische Kälbertränketechnik.
<G-vec00169-001-s193><raise.aufziehen><en> Foerster Technik offers dairy operations that raise few calves per year a cost-effective entry model for the automatic calf feeding technology with the Compact.
<G-vec00169-001-s194><raise.aufziehen><de> Insbesondere geschlechtsreife Tiere, die Junge aufziehen, mit denen sie gar nicht verwandt sind und dabei viel Energie und Zeit in die Brutpflege investieren ohne ihre eigenen Gene weiterzugeben, lassen auch heute noch viele Biologen rätseln.
<G-vec00169-001-s194><raise.aufziehen><en> Scientists puzzle over adult animals that raise young with whom they are not related, but for whom they invest a lot of energy and time without being able to pass on their genes.
<G-vec00169-001-s195><raise.aufziehen><de> Suche dir die Gegend aus, in der du in den nächsten 10 bis 30 Jahren Vieh aufziehen willst.
<G-vec00169-001-s195><raise.aufziehen><en> Locate the area where you want to raise cattle for the next 10 to 30 or more years.
<G-vec00169-001-s196><raise.aufziehen><de> Sie konnte das: unbekannte Kinder aufziehen.
<G-vec00169-001-s196><raise.aufziehen><en> She could do that: raise unknown children.
<G-vec00169-001-s197><raise.aufziehen><de> Die DDR hatte wohl das fortschrittlichste soziale System auf der Welt: 90Prozent der Frauen hatten Jobs; es gab ein breites Netz von Kindergärten, das sogenannte „Babyjahr“, in dem man zu Hause bleiben, das Baby aufziehen konnte und trotzdem Lohn erhielt.
<G-vec00169-001-s197><raise.aufziehen><en> The DDR had probably the most advanced social system in the world: 90 per cent of women had jobs; there was a broad system of kindergartens, a so-called “baby year” during which you could stay home to raise a baby and get your salary.
<G-vec00169-001-s198><raise.aufziehen><de> Jedoch das ist kein Land, wo kann man normal leben, aufziehen die Kinder, erschaffen etwas nützlich, sich vervollkommnen und sich freuen des Lebens.
<G-vec00169-001-s198><raise.aufziehen><en> However this is not a country where one could live normally, raise the children, create something useful, perfect himself and rejoice over the life.
<G-vec00169-001-s199><raise.aufziehen><de> Ich glaube dass ich hier bin weil niemand meine Kinder so aufziehen kann wie ich.
<G-vec00169-001-s199><raise.aufziehen><en> I believe that I am here today because no one can raise my kids like I can.
<G-vec00169-001-s200><raise.aufziehen><de> Auf Basis ethnographischer Untersuchungen mit immigrierten kamerunischen Müttern in Berlin, inspiriert durch die „legal consciousness“-Schule, beschreibt dieser Vortrag, wie alltägliche Erfahrungen und Rechtsauffassungen die Art und Weise beeinflussen, wie Migrantinnen Partner finden, sich verheiraten, Kinder gebären und diese aufziehen.
<G-vec00169-001-s200><raise.aufziehen><en> Based upon ethnographic research with Cameroonian migrant mothers in Berlin and ideas about legal consciousness, this presentation focuses on how everyday experiences and understandings of law shape the ways migrant mothers find partners, get married, bear children, and raise them.
<G-vec00169-001-s201><raise.aufziehen><de> Ich denke, es kommt daher, weil ich schon ganz früh meine Eltern verloren habe und meine jüngeren Brüder und Schwestern aufziehen musste.
<G-vec00169-001-s201><raise.aufziehen><en> I think it is because I lost my parents at an early age and had to raise my younger brothers and sisters.
<G-vec00169-001-s202><raise.aufziehen><de> Egal ob du ein paar für die Bedürfnisse deiner Familie oder eine ganze Herde aufziehen möchtest, es gibt ein paar Grundlagen, wie man eine Viehaufzucht betreibt; vom Landkauf zum Auswählen der Tiere, die du halten möchtest.
<G-vec00169-001-s202><raise.aufziehen><en> Whether you want to have a few head for your family's needs or raise a herd to sell, there are a few basics about how to raise cattle; from purchasing land to selecting the cattle you want to raise. Steps
<G-vec00169-001-s203><raise.aufziehen><de> Während es sicherlich möglich, ein Kind allein aufziehen, Kinder Messe besser als in der Heimat mit beiden Eltern erzogen.
<G-vec00169-001-s203><raise.aufziehen><en> While it is certainly possible to raise a child alone, children fair better when raised in the home with both parents.
<G-vec00169-001-s204><raise.aufziehen><de> Als sie 34 Jahre alt war, musste sie ganz allein meine Schwester und mich aufziehen.
<G-vec00169-001-s204><raise.aufziehen><en> At 34 years old, she had to raise my sister and me all by herself.
<G-vec00179-001-s188><raise.aufziehen><de> Ich blieb beim Aufsteigen stehen und versuchte daran zu denken, ob es in meiner Familie jemand gibt, der meine Kinder aufziehen könnte.
<G-vec00179-001-s188><raise.aufziehen><en> I stopped ascending and tried to think of someone in my family to raise my children.
<G-vec00169-001-s240><raise.aufziehen><de> Ist angenehm, dass sie sich entschieden haben die guten Freunde und zusammen zu bleiben, die Kinder aufzuziehen.
<G-vec00169-001-s240><raise.aufziehen><en> Pleasantly that all of them decided to remain good friends and together to raise the children.
<G-vec00169-001-s241><raise.aufziehen><de> Der beste Weg, ein Kind aufzuziehen und zu erziehen, ist ein Spiel, weil es im Spiel die Welt um sich herum kennt und das Denken lernt.
<G-vec00169-001-s241><raise.aufziehen><en> The best way to raise and educate a child is a game, because in the game he knows the world around him and learns to think.
<G-vec00169-001-s242><raise.aufziehen><de> Szenen aus der Zukunft der Welt Mir wurde klar gemacht wenn ich zurückgehen würde, so würde ich lang genug leben um meine Kinder aufzuziehen und sehen wie sie ihre Unabhängigkeit erreichen würden.
<G-vec00169-001-s242><raise.aufziehen><en> Scenes from the world's future I was given to know that if I went back, I would live long enough to raise my children and see them achieve independence.
<G-vec00169-001-s243><raise.aufziehen><de> Im Gegensatz zu Kanonikern und Theologen des dreizehnten Jahrhunderts – mit Thomas Aquinas an der Spitze – die glaubten, dass jüdische Kinder nicht gegen den Willen ihrer Eltern getauft werden sollten, hielt es Duns Scotus für die Pflicht der Könige, jüdische Kinder von ihren Eltern wegzunehmen, sie zu retten und sie zu taufen und als Christen aufzuziehen.
<G-vec00169-001-s243><raise.aufziehen><en> Unlike canonists and theologians of the thirteenth century – with Thomas Aquinas at their head – who believed Jewish children should not be baptized against the wishes of their parents, Duns Scotus believed it was the very duty of kings to take Jewish children away from their parents, to rescue them, and to baptize and raise them as Christians.
<G-vec00169-001-s244><raise.aufziehen><de> Es entsteht solches Gefühl, dass jede Generation ein und derselbe Aufgaben entscheiden soll: die Kinder zu heben, die Gärten, aufzuziehen, die Vernichtung sich ähnlich nicht zuzulassen.
<G-vec00169-001-s244><raise.aufziehen><en> There is such feeling that each generation has to solve the same problems: to lift children, to raise gardens, not to allow destruction similar.
<G-vec00169-001-s245><raise.aufziehen><de> Viele Mütter versuchen nicht, ihr Kind im ersten Fall aufzuziehen.
<G-vec00169-001-s245><raise.aufziehen><en> Many mothers do not seek to raise their child at the first fall.
<G-vec00169-001-s246><raise.aufziehen><de> Für die arbeitenden Massen und die Armen, die keinen Reichtum haben, den sie neuen Generationen vermachen könnten, dient die Familie dazu, die Arbeiter zu nähren und zu kleiden und die nächste Generation aufzuziehen.
<G-vec00169-001-s246><raise.aufziehen><en> For the working masses and the poor who have no wealth to pass on to new generations, the family serves to feed and clothe the workers and raise the next generation.
<G-vec00169-001-s247><raise.aufziehen><de> Ich schätze es sehr dass mir erlaubt wurde zurückzukommen und meine Söhne aufzuziehen.
<G-vec00169-001-s247><raise.aufziehen><en> I mostly appreciate that I was allowed to come back and raise my sons.
<G-vec00169-001-s248><raise.aufziehen><de> Ja Ich kehrte zurück um meine Kinder aufzuziehen.
<G-vec00169-001-s248><raise.aufziehen><en> Yes I was returning to raise my children.
<G-vec00169-001-s249><raise.aufziehen><de> Deshalb ist es besser, künstliche Kittenmilch (Milchersatznahrung) zu benutzen um Kätzchen aufzuziehen.
<G-vec00169-001-s249><raise.aufziehen><en> Therefore it is better to use artificial milk (formula) to raise kittens.
<G-vec00169-001-s250><raise.aufziehen><de> Es ist schwer genug, Kinder aufzuziehen, so wie es ist, aber noch schlimmer, wenn das Kind nicht älter zu werden scheint.
<G-vec00169-001-s250><raise.aufziehen><en> It's hard enough to raise a child as it is, but even harder when the child never seems to grow up.
<G-vec00169-001-s251><raise.aufziehen><de> Ich bestärke Sie auch nachdrücklich in Ihren politischen Bemühungen, Umstände zu fördern, die es jungen Paaren ermöglichen, Kinder aufzuziehen.
<G-vec00169-001-s251><raise.aufziehen><en> I also decisively support you in your political efforts to favour conditions enabling young couples to raise children.
<G-vec00169-001-s252><raise.aufziehen><de> Meine ganze Hoffnung war, in der Lage zu sein, meine Kinder aufzuziehen, doch ich dachte nicht, dass ich noch eine Zukunft hatte.
<G-vec00169-001-s252><raise.aufziehen><en> My only hope was to be able to raise my children, as I did not think there would be a future for myself.
<G-vec00169-001-s253><raise.aufziehen><de> Für Paare und Einzelpersonen, die mit Unfruchtbarkeit, gleichgeschlechtliche Paare und viele andere diagnostiziert werden, ist die Annahme das beliebteste der begrenzten Möglichkeiten, die diese Personen haben könnte, um ein Kind aufzuziehen.
<G-vec00169-001-s253><raise.aufziehen><en> For couples and individuals that are diagnosed with infertility, same sex couples and many others, adoption is the most popular of the limited options these individuals might have to raise a child.
<G-vec00169-001-s254><raise.aufziehen><de> Alle Jungtiere befinden sich derzeit in der Obhut der Baby-Station des Loro Parque, um sie von Hand aufzuziehen, dabei erweisen sich die Jungtiere nicht gerade als sehr pflegeleicht, aber das Tierärzteteam des Loro Parque hat ein besonderes Auge auf die seltenen Küken und bisher entwickeln sich alle Jungtiere sehr zufriedenstellend.
<G-vec00169-001-s254><raise.aufziehen><en> All youngsters have been taken into the Baby-Station of Loro Parque in order to hand raise them. These rare chicks seem to be doing their best not to help us, but our team is doing a great job rearing them, and they are all developing well so far.
<G-vec00169-001-s255><raise.aufziehen><de> Buckelwale kommen jedes Jahr von Juli bis November in die Hervey Bucht, um ihre Jungen aufzuziehen und für die kalten Gewässer der Antarktis vorzubereiten.
<G-vec00169-001-s255><raise.aufziehen><en> Coming closer we discover a huge bone of a Humpback. Each year between July and November whales come to Hervey Bay to nurse and raise their calves and prepare them for the cold Antarctic waters.
<G-vec00169-001-s256><raise.aufziehen><de> """Heute bringen die Ordensmitglieder enorme Opfer, um die schwächsten Menschen unseres Planeten zu verteidigen, zu beschützen und aufzuziehen"", konstatierte er."
<G-vec00169-001-s256><raise.aufziehen><en> """Today members of the Order make great sacrifices to defend protect and raise up some of the poorest and most vulnerable people on our planet"" he stated."
<G-vec00169-001-s257><raise.aufziehen><de> Das Gelübde der Keuschheit ist ein Ordensbekenntnis, durch das Menschen des geweihten Lebens auf die Freiheit der Laien verzichten, eine Ehe einzugehen und Kinder aufzuziehen.
<G-vec00169-001-s257><raise.aufziehen><en> The vow of chastity is something religious profess. By it they sacrifice the freedom the laity have to marry and raise children.
<G-vec00169-001-s258><raise.aufziehen><de> Ein Uhrenbeweger hat das Ziel Automatikuhren möglichst Uhrwerk schonend aufzuziehen.
<G-vec00169-001-s258><raise.aufziehen><en> A watch winder has raise the target automatic watches movement gently as possible.
<G-vec00246-002-s167><raise.aufziehen><de> Die kostenlose App zaubert eine Eieruhr auf den Touchscreen, die sich mit dem Finger leicht aufziehen lässt.
<G-vec00246-002-s167><raise.aufziehen><en> The free app brings up an egg timer on the screen, which can easily raise with your finger.
<G-vec00246-002-s168><raise.aufziehen><de> Die räumliche Quaderbegrenzung wird im Programm mit zwei Punkten beschrieben, welche eine Projektionsebene zwischen den globalen Koordinatenachsen aufziehen.
<G-vec00246-002-s168><raise.aufziehen><en> The spatial cuboid boundary is defined in the program by two points which raise a projection plane between the global coordinate axes.
<G-vec00246-002-s169><raise.aufziehen><de> Ich bat darum, zurückgeschickt zu werden, denn ich hatte Angst, wer mein Baby aufziehen würde.
<G-vec00246-002-s169><raise.aufziehen><en> I begged to be sent back because I was afraid of 'who' would raise my baby.
<G-vec00246-002-s170><raise.aufziehen><de> Eine Frau kann in dieser Zeit ihre Kinder aufziehen, eine neue Karriere starten und ihre Träume verwirklichen.
<G-vec00246-002-s170><raise.aufziehen><en> A woman could raise her children, start a new career, realise her dreams.
<G-vec00246-002-s172><raise.aufziehen><de> Es scheint, Morgen - ich fühle, wie sie mich aufziehen, verschieben Sie mich.
<G-vec00246-002-s172><raise.aufziehen><en> It seems, morning - I feel how they raise me, shift me.
<G-vec00246-002-s173><raise.aufziehen><de> Die meiste Zeit des Jahres besteht das Bienenvolk nur aus Weibchen: der Königin, die als einzige Eier legt (bis zu 2.000 Stück am Tag), und den unfruchtbaren Arbeiterinnen, die Pollen und Nektar sammeln, die Larven aufziehen und den Stock bei Gefahr verteidigen.
<G-vec00246-002-s173><raise.aufziehen><en> Most of the time of year the bee colony consists only of females: the Queen, the only one who is oviparous (up to 2,000 eggs a day), and infertile workers, which gather pollen and nectar, raise the larvae and defend the stock at risk.
<G-vec00246-002-s174><raise.aufziehen><de> Man sollte einen Vogel aufziehen.
<G-vec00246-002-s174><raise.aufziehen><en> You would raise a bird.
<G-vec00246-002-s175><raise.aufziehen><de> Wo du lebst, wird bestimmen, welche Arten von Wetter und Naturkatastrophen du erwarten sollst und welche Tiere du erfolgreich aufziehen kannst.
<G-vec00246-002-s175><raise.aufziehen><en> Where you live will dictate what kind of severe weather to expect and whether or not you can raise certain livestock with success or failure.
<G-vec00246-002-s177><raise.aufziehen><de> In deiner Fantasy-Welt von Magoia kannst du fantastische Pflanzen ernten, magische Tränke brauen und verlassene Drachen aufziehen.
<G-vec00246-002-s177><raise.aufziehen><en> In Magoia you can harvest fantastic plants, brew magic potions and raise up left-behind dragons.
<G-vec00246-002-s178><raise.aufziehen><de> Wenn du Fleisch- und Milchprodukte zu dir nimmst, entscheide dich für Qualitätsprodukte von kleinen, ökologischen Bauernhöfen, die Tiere unter gesünderen Bedingungen und ohne übermäßigen Einsatz von Antibiotika aufziehen.
<G-vec00246-002-s178><raise.aufziehen><en> When you eat meat and dairy, consider choosing quality by supporting ecological small-scale farms, which raise animals in a healthier environment, without excessive use of antibiotics.
<G-vec00246-002-s179><raise.aufziehen><de> Mehr als fünfzig verschiedene Drachenarten kann man einsammeln und aufziehen, alle mit ihrer individuellen Form, Größe und Farbe.
<G-vec00246-002-s179><raise.aufziehen><en> You can raise and collect more than fifty different types of dragons, all with different shapes, sizes, and colors.
<G-vec00246-002-s180><raise.aufziehen><de> In Mecklenburg-Vorpommern arbeiten wir zurzeit mit neun Vertragslandwirten zusammen, die 1.100 Uckermärker-Rinder sowie Uckermärker-Kreuzungen für uns aufziehen.
<G-vec00246-002-s180><raise.aufziehen><en> In Mecklenburg-West Pomerania we are currently working with nine contract farmers who raise 1,100 German Uckermark and Uckermark cross breeds for us.
<G-vec00246-002-s181><raise.aufziehen><de> Ich wolle zurückkehren und meine zwei Söhne aufziehen bis sie mich nicht mehr benötigten.
<G-vec00246-002-s181><raise.aufziehen><en> I wanted to go back and raise my two sons until they did not need me anymore.
<G-vec00246-002-s182><raise.aufziehen><de> Natürlich Unser Rindfleisch stammt zu 100% von unseren Tieren, die wir liebevoll aufziehen.
<G-vec00246-002-s182><raise.aufziehen><en> Our beef meat comes 100% from our own cattle which we raise lovingly on our own.
<G-vec00246-002-s183><raise.aufziehen><de> Ausrufpreis: 300,00 EUR Gold und Silberschmuck Damen Gesamtgewicht von dem Gehäuse und Armband 11,20g, Gehäuse und Glas zerkratzt, guter Zustand, lässt sich nicht aufziehen, nicht funktionstüchtig.
<G-vec00246-002-s183><raise.aufziehen><en> Gold and Silver Jewellery Ladies wrist watch... - weight from the case and bracelet 11, 20 g, case and glass scratched, good condition, lets be not raise, not functionally.
<G-vec00246-002-s184><raise.aufziehen><de> Er sagte mir dass ich zurückgehen müsste und meine Kinder aufziehen, und dass es noch nicht meine Zeit sei zu bleiben.
<G-vec00246-002-s184><raise.aufziehen><en> He told me that I had to go back and raise my children and that it wasn't my time to stay.
<G-vec00484-002-s023><tuck_away.aufziehen><de> Untere Profillinie und Bauch: Wenig aufgezogen.
<G-vec00484-002-s023><tuck_away.aufziehen><en> Lower line and Belly: Slight tuck up.
