<G-vec00060-001-s038><list.auflisten><de> Wenn Sie jedoch alle Verknüpfungen einer Arbeitsmappe in Excel auflisten möchten, ist es schwierig, alle externen Referenzen (Links) zu finden und aufzulisten.
<G-vec00060-001-s038><list.auflisten><en> But when you want to list all links of a workbook in Excel, it seems hard to find out and list all external references (links).
<G-vec00060-001-s039><list.auflisten><de> So haben wir die beiden wichtigsten Faktoren sortiert (supra), aber es gibt noch eine Menge zusätzlicher Tests und Analysen ein, bevor wir ein Casino auf der Website auflisten.
<G-vec00060-001-s039><list.auflisten><en> So we have the two most important factors sorted (see above), but there are still a lot of extra testing and analysis a do before we can list a casino on the site.
<G-vec00060-001-s040><list.auflisten><de> Wir stellen Links zu verschiedenen Websites zur Verfügung, die Ferienwohnungen in Panama auflisten, und wir bieten auch Links zu verschiedenen Immobilienmaklern in Boquete und in Bocas del Toro (da wir selber kein Immobilienmakler sind).
<G-vec00060-001-s040><list.auflisten><en> Within our website we provide links to several sites that list vacation rentals in Panama, and we also provide links to different real estate agents in Boquete and in Bocas del Toro (as we are not real estate agents ourselves).
<G-vec00060-001-s041><list.auflisten><de> Alles auflisten Schiffe in der gleichen Basis (Split) .
<G-vec00060-001-s041><list.auflisten><en> List all yachts in the same base (Split) .
<G-vec00060-001-s042><list.auflisten><de> Bitte haben Sie dafür Verständnis, dass wir hier nicht alle Firmen auflisten können.
<G-vec00060-001-s042><list.auflisten><en> Please kindly understand, that we can´t display a complete list of our clients.
<G-vec00060-001-s043><list.auflisten><de> Wir können hier nur einige allgemeine Probleme auflisten und generelle Empfehlungen geben, wie Sie damit umgehen sollten.
<G-vec00060-001-s043><list.auflisten><en> We can only list some common issues and provide general suggestions on how to deal with them.
<G-vec00060-001-s044><list.auflisten><de> Mit dieser Funktion können Sie die Arbeitsblattnamen der aktiven Arbeitsmappe schnell in einem neuen Arbeitsblatt auflisten und Hyperlinks oder Makroschaltflächen hinzufügen, die mit entsprechenden Arbeitsblättern verknüpft sind.
<G-vec00060-001-s044><list.auflisten><en> With this feature, you can quickly list the worksheet names of the active workbook in a new worksheet, and add hyperlinks or macro buttons linking to corresponding worksheets.
<G-vec00060-001-s045><list.auflisten><de> Innerhalb unserer Website stellen wir Links zu verschiedenen Websites zur Verfügung, die Ferienwohnungen in Panama auflisten, und wir bieten auch Links zu verschiedenen Immobilienmaklern in Boquete und in Bocas del Toro (da wir selber kein Immobilienmakler sind).
<G-vec00060-001-s045><list.auflisten><en> Within our website we provide links to several sites that list vacation rentals in Panama, and we also provide links to different real estate agents in Boquete and in Bocas del Toro (as we are not real estate agents ourselves).
<G-vec00060-001-s046><list.auflisten><de> Alles auflisten Catamaran Schiffe in unserem Angebot.
<G-vec00060-001-s046><list.auflisten><en> List all Catamaran yachts in our offer.
<G-vec00060-001-s047><list.auflisten><de> Diese Datei sollte die Tests auflisten, die aus der Ferne gestartet werden können, und die IP-Adressen der Rechner, die sie auslösen dürfen.
<G-vec00060-001-s047><list.auflisten><en> This file should list the tests that can be started remotely, and the IP addresses of the machines allowed to trigger them.
<G-vec00060-001-s048><list.auflisten><de> • Download-Aufgaben: Alle BT-Aufgaben basierend auf ihrem Download-Status auflisten (Alle, Wird heruntergeladen, Unterbrochen, Abgeschlossen, Aktiv und Inaktiv).
<G-vec00060-001-s048><list.auflisten><en> • Tasks: List all BT tasks based on their download status (All, Downloading, Paused, Completed, Active and Inactive.)
<G-vec00060-001-s049><list.auflisten><de> Alles auflisten Hanse Schiffe in unserem Angebot.
<G-vec00060-001-s049><list.auflisten><en> List all Elan yachts in our offer.
<G-vec00060-001-s050><list.auflisten><de> Kutools for Word AutoText-Fenster kann Autotext-Einträge einfach im Dokument speichern, auflisten und einfügen.
<G-vec00060-001-s050><list.auflisten><en> Kutools for Word’s AutoText Pane can save, list and insert autotext entries easily in document.
<G-vec00060-001-s051><list.auflisten><de> In einem früheren Artikel habe ich beschrieben, mit dem ps-Befehl zum auflisten von Prozessen und, wie um Sie zu töten, aber das ist ein Aufwand.
<G-vec00060-001-s051><list.auflisten><en> In a previous article I described using the ps command to list processes and how to kill them, but that’s a hassle.
<G-vec00060-001-s052><list.auflisten><de> Diese Methode führt Sie zum Erstellen eines benutzerdefinierten Suchordners und zum Auflisten aller E-Mails mit großen Anhängen.
<G-vec00060-001-s052><list.auflisten><en> This method will guide you to create a custom search folder and list all emails with large attachments.
<G-vec00060-001-s053><list.auflisten><de> Alles auflisten Privilege Schiffe in unserem Angebot.
<G-vec00060-001-s053><list.auflisten><en> List all Privilege yachts in our offer.
<G-vec00060-001-s054><list.auflisten><de> Bei Verwendung bestehender Normen, diese bitte auflisten.
<G-vec00060-001-s054><list.auflisten><en> If using existing Standards, please list.
<G-vec00060-001-s055><list.auflisten><de> Alles auflisten Maiora Schiffe in unserem Angebot.
<G-vec00060-001-s055><list.auflisten><en> List all Maiora yachts in our offer.
<G-vec00060-001-s056><list.auflisten><de> Alles auflisten Galeon Schiffe in unserem Angebot.
<G-vec00060-001-s056><list.auflisten><en> List all Galeon yachts in our offer.
<G-vec00507-002-s076><list.auflisten><de> Ich würde mehr als nur Ereignisse auflisten; ich würde mir die Zeit nehmen, über alles nachzudenken, was an diesem Tag geschehen war, und dann meine Gedanken und Gefühle zum Ausdruck bringen.
<G-vec00507-002-s076><list.auflisten><en> I would do more than just list events; I’d take the time to contemplate all that had happened that day and then express my thoughts and feelings.
<G-vec00507-002-s077><list.auflisten><de> Es gibt zu viele neue Entwicklungen, als dass man sie auflisten könnte, aber hier sind einige einschlägige Veränderungen, die das Spiel seit der ersten Enthüllung durchlaufen hat.
<G-vec00507-002-s077><list.auflisten><en> The developments are too long to list, but here are some of the ways the game has changed since that very first reveal.
<G-vec00507-002-s078><list.auflisten><de> Aufgrund der Vielzahl solcher Unternehmen können wir diese hier nicht alle auflisten; aber unabhängig davon, ob sie innerhalb oder außerhalb der Europäischen Union ansässig sind, werden wir nur mit Unternehmen zusammenarbeiten, denen wir vertrauen, dass Ihre Informationen geschützt werden.
<G-vec00507-002-s078><list.auflisten><en> As there are a large number of such companies, we cannot list them all here, but whether they are based inside or outside of the European Union, we will only work with companies who we trust to keep your information safe.
<G-vec00507-002-s079><list.auflisten><de> Wenn der Anzeigemodus oder die Auflösung noch nicht wählbar ist, klicken Sie aufStart,Systemsteuerung,Anzeige,Einstellungen,Erweiterte,Adapter, undAlle Modi auflisten.
<G-vec00507-002-s079><list.auflisten><en> If the display mode or resolution is still not selectable, click Start, Control Panel, Display, Settings, Advanced, Adapter, and List all modes.
<G-vec00507-002-s080><list.auflisten><de> Es klingt sogar beinahe absurd, wie hilfreich dieses Cannabidiol sein kann, aber alles, was wir auflisten werden, ist wahr.
<G-vec00507-002-s080><list.auflisten><en> It even sounds ridiculous how helpful this Cannabidiol can be but everything we’re about to list is true.
<G-vec00507-002-s081><list.auflisten><de> Dann geben Sie Ihre iCloud Details ein, nachdem die App Ihre iCloud Backups für Sie zur Auswahl auflisten wird.
<G-vec00507-002-s081><list.auflisten><en> Then enter your iCloud details, after which the app will list your iCloud backups for you to choose.
<G-vec00507-002-s082><list.auflisten><de> Der Befehl ipconfig kann sowohl IPv4- als auch IPv6-Adressen auflisten.
<G-vec00507-002-s082><list.auflisten><en> The ipconfig command can list both IPv4 and IPv6 addresses.
<G-vec00507-002-s083><list.auflisten><de> Eine Gruppenadresse muss auch bei uns definiert werden, sie verfügt eventuell nicht über ein Postfach auf Ihrem Server, aber Sie müssen sie dennoch als eine aktive E-Mail-Adresse in Ihrer Domain auflisten.
<G-vec00507-002-s083><list.auflisten><en> A group address must also be defined with us, it may not have a mailbox on your server but you must still list it as an active email address at your domain.
<G-vec00507-002-s084><list.auflisten><de> Die Ausgabe ist eine Liste von Schlüsseln im XML-Format, die der S3-Antwort auf die Anforderung zum Auflisten von Buckets ähnlich ist.
<G-vec00507-002-s084><list.auflisten><en> The output will be a list of keys in XML that is similar to the S3 list buckets response.
<G-vec00507-002-s085><list.auflisten><de> An EU-Gesetzen mitschreibende Europaabgeordnete müssen ihre Treffen mit Lobbyisten öffentlich auflisten.
<G-vec00507-002-s085><list.auflisten><en> Members of the European Parliament who write EU laws must publicly list their meetings with lobbyists.
<G-vec00507-002-s086><list.auflisten><de> Ebenfalls am Ende werden wir einige kritische Maßnahmen auflisten, die Ihnen helfen werden, sich gegen die unvermeidlichen Datenverlustsituationen zu schützen.
<G-vec00507-002-s086><list.auflisten><en> Also at the end, we will list a few critical measures that will help you safeguard against the inevitable data loss situations.
<G-vec00507-002-s087><list.auflisten><de> Die Begriffe „Benutzer“ oder „Sie“, wie in dieser Datenschutzregelung verwendet, beziehen sich auf Reisende, die bei HomeAway.at nach Mietobjekten suchen, und auf Vermieter-Kunden, die sich HomeAway.at anschließen und ihre Mietobjekte dort auflisten.
<G-vec00507-002-s087><list.auflisten><en> The terms “users” or “you” as used in this Privacy Policy, refer to both travelers, who use the Site to look for properties to rent, and members who subscribe to the Site and list their properties for rent.
<G-vec00507-002-s088><list.auflisten><de> Synkope (Ohnmacht): Ärzte und viele Patienten, die eine Synkope hatten, können eine Reihe von Ursachen auflisten.
<G-vec00507-002-s088><list.auflisten><en> Syncope (fainting): Doctors and many patients who had syncope can list a number of causes.
<G-vec00507-002-s089><list.auflisten><de> Damit man per Google-Suche verdächtige Kommentare findet und als SPAM enttarnen kann werde ich diese hier auflisten.
<G-vec00507-002-s089><list.auflisten><en> For everybody who is unsure I created this post: Here I will list all SPAM comments I receive.
<G-vec00507-002-s090><list.auflisten><de> Die Vorteile sind so vielfältig, dass ich nicht alle auflisten kann.
<G-vec00507-002-s090><list.auflisten><en> The benefits are so many that we can’t list them all.
<G-vec00507-002-s091><list.auflisten><de> Sortimente Mit dem Button „Artikel auflisten“ werden Ihnen alle lieferbaren Artikel aus der gewählten Kategorie angezeigt.
<G-vec00507-002-s091><list.auflisten><en> If you click the "List items" button, all of the available items in the selected category are displayed.
<G-vec00507-002-s092><list.auflisten><de> Wir haben etliche Webpages über Angela Merkel und ihr Verhältnis zu Obama gebracht und wie dies Verhältnis ein Verhältnis zwischen Kriminellen wurde und auf dieser Webpage wollen wir einfach einige dieser Webpages auflisten.
<G-vec00507-002-s092><list.auflisten><en> We have brought a couple of webpages about Angela Merkel and her relationship with Obama and how this relationship became a relationship between criminals and on this webpage we simply want to list links to some of these webpages.
<G-vec00507-002-s093><list.auflisten><de> # Wenn Sie mehrere Netzwerkschnittstellen haben, dann müssen Sie sie hier auflisten.
<G-vec00507-002-s093><list.auflisten><en> # If you have multiple network interfaces then you must list them here.
<G-vec00507-002-s094><list.auflisten><de> Beim Start wird Disk Drill alle entdeckten Dateien und Partitionen auflisten.
<G-vec00507-002-s094><list.auflisten><en> Upon opening, Disk Drill will list all the detected disks and partitions.
