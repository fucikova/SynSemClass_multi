<G-vec00298-002-s099><swell.aufquellen><de> Leider neigt Papier bekanntlich dazu, im Wasser aufzuquellen und aufzuweichen.
<G-vec00298-002-s099><swell.aufquellen><en> Unfortunately, paper tends to swell and soften in the water.
