<G-vec00251-002-s084><deter.ausschalten><de> Die innovativen Touch-Bedienelemente erlauben Ihnen, die Hydromassage zu starten, die Luftzufuhr zu regulieren sowie die Funktion Cromodream® an- und auszuschalten, ohne das saubere und minimalistische Design des MyWay zu beeinträchtigen.
<G-vec00251-002-s084><deter.ausschalten><en> Innovative flat touch controls ensures the pump, air regulation and lighting are easy to use and don’t deter away from the clean lines of the MyWay’s styling.
<G-vec00365-002-s056><assassinate.ausschalten><de> Schalte 50 Politiker aus.
<G-vec00365-002-s056><assassinate.ausschalten><en> Assassinate 50 politicians.
<G-vec00365-002-s044><eliminate.ausschalten><de> Chibi der kleine Ritter muss das Land verteidigen und die Monster ausschalten.
<G-vec00365-002-s044><eliminate.ausschalten><en> Chibi the knight must defend his country and eliminate the monsters. Share this
<G-vec00365-002-s045><eliminate.ausschalten><de> Sobald die Anfrage eingeht, kann der Verkäufer den Überprüfungsprozess starten und frühzeitig potenziellen Tourismus ausschalten.
<G-vec00365-002-s045><eliminate.ausschalten><en> Once the request comes in the seller can start the vetting process and eliminate early potential tourism
<G-vec00365-002-s046><eliminate.ausschalten><de> Das müssen Sie also vom inneren Leben ausschalten, was von außen durch die Empfindungsseele aufgenommen und durch die Verstandes- oder Gemütsseele verarbeitet wird.
<G-vec00365-002-s046><eliminate.ausschalten><en> You must therefore eliminate from the inner life that which is received from outside through the sentient-soul and distinguish it from what is worked upon by the intellectual-soul or mind-soul feelings.
<G-vec00365-002-s047><eliminate.ausschalten><de> Wir müssen wohl akzeptieren, dass wir, ebenso wie in der physischen Welt, nie alle Risiken komplett ausschalten können.
<G-vec00365-002-s047><eliminate.ausschalten><en> I think that we have to recognize that just like in the physical world you can never completely eliminate all risks.
<G-vec00365-002-s048><eliminate.ausschalten><de> Vermutlich wollte man einen potenziellen Verräter ausschalten.
<G-vec00365-002-s048><eliminate.ausschalten><en> Probably they wanted to eliminate a potential traitor.
<G-vec00365-002-s049><eliminate.ausschalten><de> Verträge können dieses Risiko nicht ausschalten, jedoch zu einem gewissen Grad minimieren.
<G-vec00365-002-s049><eliminate.ausschalten><en> Contracts cannot eliminate this risk completely, but mitigate it as far as possible.
<G-vec00365-002-s050><eliminate.ausschalten><de> "Als Chiropraktikerin für Tiere bin ich immer auf der Suche nach Halsbändern, die sanft sind, wenig Druck ausüben und grundsätzlich die möglichen Verletzungsgefahren für Nacken und Wirbelsäule des Hundes ausschalten.
<G-vec00365-002-s050><eliminate.ausschalten><en> "As an animal chiropractor, I am always looking for collars that are gentle, reduce the amount of stress, and essentially eliminate the potential for injury to a dog’s neck and spine.
<G-vec00365-002-s051><eliminate.ausschalten><de> In Total KO-Turnieren müssen Sie also andere Spieler ausschalten, um deren Bounty zu gewinnen und Ihre eigene Bounty zu erhöhen.
<G-vec00365-002-s051><eliminate.ausschalten><en> In other words, in Total KO tournaments, you need to eliminate other players to win their bounty as well as increase your own bounty.
<G-vec00365-002-s052><eliminate.ausschalten><de> Wer sie mit Bomben ausschalten will, muss ganz Mosul in Schutt und Asche legen und zigtausende Zivilisten töten.
<G-vec00365-002-s052><eliminate.ausschalten><en> Whoever wants to eliminate them with bombs would have to first turn all of Mosul into rubble and kill thousands of civilians.
<G-vec00365-002-s053><eliminate.ausschalten><de> Auch wenn wir zwar aktuelle Technologie und interne Verfahren dazu nutzen, Ihre Kontodaten und sonstige personenbezogene Daten vor Eindringlingen zu schützen, können wir dennoch keine Garantie dafür abgeben, dass die Technologie und die Verfahren sämtliche Risiken hinsichtlich Diebstahl, Verlust oder Missbrauch ausschalten können.
<G-vec00365-002-s053><eliminate.ausschalten><en> While we have in place up-to-date technology and internal procedures to keep your Account Information and other Personal Data secure from intruders, there is no guarantee that such technology or procedures can eliminate all of the risks of theft, loss or misuse.
<G-vec00365-002-s054><eliminate.ausschalten><de> Dies minimiert die Systemeinflüsse weitgehend, kann sie aber leider nicht völlig ausschalten.
<G-vec00365-002-s054><eliminate.ausschalten><en> This minimizes the system influence, but unfortunately cannot eliminate it entirely.
<G-vec00365-002-s055><eliminate.ausschalten><de> Neben dem Gewinn einer Knockout-Prämie für das Ausschalten eines anderen Spielers, wird ein Teil der Bounty Ihrer eigenen Kopfprämie hinzuaddiert.
<G-vec00365-002-s055><eliminate.ausschalten><en> In addition to winning a knockout bounty when you eliminate another player, a percentage of every knockout bounty goes to increasing the bounty on your head.
<G-vec00365-002-s056><eliminate.ausschalten><de> Um diese Art der Verzerrung ausschalten zu können, muss eine Vorspannung an die Basisanschlüsse der beiden Transistoren gelegt werden.
<G-vec00365-002-s056><eliminate.ausschalten><en> To eliminate those distortions, a bias voltage has to be applied to the base pins of the two transistors.
<G-vec00376-002-s154><shut.ausschalten><de> Es ist nicht zufällig, dass dieser Versuch, Russia Today auszuschalten, in eine Zeit fällt, da die westlichen Medien inklusive BBC einen Propagandakrieg gegen Russland führen, der dem der Entente gegen Deutschland vor und während des Ersten Weltkriegs in nichts nachsteht.
<G-vec00376-002-s154><shut.ausschalten><en> It is no coincidence that this attempt to shut down the accounts of Russia Today in the UK comes at a time when the western media, including the BBC, are waging a propaganda war against Russia which is no less intense than that waged by the Entente against Germany before and during the First World War.
<G-vec00376-002-s155><shut.ausschalten><de> Große Firmen werden einfach versuchen kleine Konkurrenz auszuschalten.
<G-vec00376-002-s155><shut.ausschalten><en> Big companies will just try to shut down small competitors.
<G-vec00376-002-s156><shut.ausschalten><de> Die Firewall kann Ratenbegrenzungdienste (Rate Limiting Services) bereitstellen, um Angreifer auszuschalten, die einen Server lahm legen möchten.
<G-vec00376-002-s156><shut.ausschalten><en> The firewall can provide rate limiting services to shut down attackers trying to overwhelm the server.
<G-vec00376-002-s157><shut.ausschalten><de> Vergisst du, sie auszuschalten, ist es auch kein Problem: Nach 10 sec erledigt sie das von selbst.
<G-vec00376-002-s157><shut.ausschalten><en> If you forget to shut it off, that’s not a problem: After 10 seconds it will do that on its own.
<G-vec00376-002-s158><shut.ausschalten><de> Um Ihren Computer auszuschalten: 1 Öffnen Sie die Charms und wählen Sie dann Einstellungen.
<G-vec00376-002-s158><shut.ausschalten><en> To shut down your tablet: 1 Open the charms, and then select Settings.
<G-vec00376-002-s159><shut.ausschalten><de> Um zu verhindern, dass der Schaden noch größer wird, ist es bei diesem Fehler besonders wichtig, sofort den Server auszuschalten und nicht mehr unter Strom zu setzen.
<G-vec00376-002-s159><shut.ausschalten><en> To prevent the damage from getting worse it is very important to shut the server down immediately and not apply power anymore.
<G-vec00376-002-s160><shut.ausschalten><de> Das Dunkel verstand, dass dies von großer Wichtigkeit für die Entwicklung der Seele war, und sehr früh in der Existenz der Menschheit, wob das Dunkel sein tückisches Netz, um dieses zusammengesetzte Zentrum auszuschalten.
<G-vec00376-002-s160><shut.ausschalten><en> The dark understood that this was of great importance to the development of thesoul and very early in humanity's existence, the dark wove its nefarious web in order to shut down this composite center.
<G-vec00376-002-s161><shut.ausschalten><de> Ihr seid in einem menschlichen Körper, ihr seid Kräften unterworfen, die über euer Verständnis hinausgehen, aber nicht jenseits Meiner Macht, sie auszuschalten.
<G-vec00376-002-s161><shut.ausschalten><en> You are in a human body, subject to forces beyond your understanding, but not beyond My power to shut down.
<G-vec00389-002-s029><crush.ausschalten><de> Als Wang Mang erkannte, dass Gengshi sich zu einer ernsthaften Bedrohung entwickelte, schickte er seinen Vetter Wang Yi (mit einer Streitmacht von 430.000 Mann aus, um die neu eingesetzte Han-Dynastie auszuschalten.
<G-vec00389-002-s029><crush.ausschalten><en> He sent his cousin Wang Yi (with what he considered to be overwhelming force, some 430,000 men, intending to crush the newly constituted Han regime.
<G-vec00389-002-s030><crush.ausschalten><de> Wag dich in einem der gefährlichsten Konfliktgebiete der Geschichte hinter die feindlichen Linien und gib alles, um die Achsenmächte ein für alle Mal auszuschalten.
<G-vec00389-002-s030><crush.ausschalten><en> Go behind enemy lines in one of history’s hottest conflict zones and do what it takes to crush the axis powers once and for all.
<G-vec00376-003-s154><shut_down.ausschalten><de> Es ist nicht zufällig, dass dieser Versuch, Russia Today auszuschalten, in eine Zeit fällt, da die westlichen Medien inklusive BBC einen Propagandakrieg gegen Russland führen, der dem der Entente gegen Deutschland vor und während des Ersten Weltkriegs in nichts nachsteht.
<G-vec00376-003-s154><shut_down.ausschalten><en> It is no coincidence that this attempt to shut down the accounts of Russia Today in the UK comes at a time when the western media, including the BBC, are waging a propaganda war against Russia which is no less intense than that waged by the Entente against Germany before and during the First World War.
<G-vec00376-003-s155><shut_down.ausschalten><de> Große Firmen werden einfach versuchen kleine Konkurrenz auszuschalten.
<G-vec00376-003-s155><shut_down.ausschalten><en> Big companies will just try to shut down small competitors.
<G-vec00376-003-s156><shut_down.ausschalten><de> Die Firewall kann Ratenbegrenzungdienste (Rate Limiting Services) bereitstellen, um Angreifer auszuschalten, die einen Server lahm legen möchten.
<G-vec00376-003-s156><shut_down.ausschalten><en> The firewall can provide rate limiting services to shut down attackers trying to overwhelm the server.
<G-vec00376-003-s157><shut_down.ausschalten><de> Vergisst du, sie auszuschalten, ist es auch kein Problem: Nach 10 sec erledigt sie das von selbst.
<G-vec00376-003-s157><shut_down.ausschalten><en> If you forget to shut it off, that’s not a problem: After 10 seconds it will do that on its own.
<G-vec00376-003-s158><shut_down.ausschalten><de> Um Ihren Computer auszuschalten: 1 Öffnen Sie die Charms und wählen Sie dann Einstellungen.
<G-vec00376-003-s158><shut_down.ausschalten><en> To shut down your tablet: 1 Open the charms, and then select Settings.
<G-vec00376-003-s159><shut_down.ausschalten><de> Um zu verhindern, dass der Schaden noch größer wird, ist es bei diesem Fehler besonders wichtig, sofort den Server auszuschalten und nicht mehr unter Strom zu setzen.
<G-vec00376-003-s159><shut_down.ausschalten><en> To prevent the damage from getting worse it is very important to shut the server down immediately and not apply power anymore.
<G-vec00376-003-s160><shut_down.ausschalten><de> Das Dunkel verstand, dass dies von großer Wichtigkeit für die Entwicklung der Seele war, und sehr früh in der Existenz der Menschheit, wob das Dunkel sein tückisches Netz, um dieses zusammengesetzte Zentrum auszuschalten.
<G-vec00376-003-s160><shut_down.ausschalten><en> The dark understood that this was of great importance to the development of thesoul and very early in humanity's existence, the dark wove its nefarious web in order to shut down this composite center.
<G-vec00376-003-s161><shut_down.ausschalten><de> Ihr seid in einem menschlichen Körper, ihr seid Kräften unterworfen, die über euer Verständnis hinausgehen, aber nicht jenseits Meiner Macht, sie auszuschalten.
<G-vec00376-003-s161><shut_down.ausschalten><en> You are in a human body, subject to forces beyond your understanding, but not beyond My power to shut down.
<G-vec00496-002-s095><switch.ausschalten><de> Dies ist ein Ein- / Ausschalter mit 7 Kanälen.
<G-vec00496-002-s095><switch.ausschalten><en> This is a power on/off timer switch with 7 channels.
<G-vec00496-002-s096><switch.ausschalten><de> Unser Gerät hat einen praktischen Ein- und Ausschalter, der Rahmen kann bequem am Rand befestigt werden.
<G-vec00496-002-s096><switch.ausschalten><en> Our device has a handy on / off switch, the frame can be easily attached to the edge.
<G-vec00496-002-s097><switch.ausschalten><de> Ein-/Ausschalter auf der Spieluhr.
<G-vec00496-002-s097><switch.ausschalten><en> On/Off switch on music box.
<G-vec00496-002-s098><switch.ausschalten><de> Es handelt sich um einen einfachen Ein- / Ausschalter.
<G-vec00496-002-s098><switch.ausschalten><en> It is a simple on/off switch.
<G-vec00496-002-s099><switch.ausschalten><de> Aus der DE-A-36 23 688 ist ein HF-Chirurgiegerät mit einer Überwachungs- und Steuerschaltung bekannt, bei der an einem ersten Ausgang einer HF-Leistungsstufe ein von anschließbaren Patientenelektroden gesonderter Strompfad angeschlossen ist, in welchem ein Lastwiderstand über einen An-/Ausschalter mit einem gegenphasigen Ausgang der HF-Leistungsstufe verbindbar ist.
<G-vec00496-002-s099><switch.ausschalten><en> From DE-A-36 23 688 a HF surgery device with a monitoring and control circuit is known in which a is connected by the connectable patient electrodes separate current path at a first output of a RF power level, in which a load resistor via an on / switch with an opposite-phase output of the RF power level is connectable.
<G-vec00496-002-s100><switch.ausschalten><de> Drücken Sie nach dem auto- matischen Abschalten des Elektrowerkzeuges nicht weiter auf den Ein-/Ausschalter.
<G-vec00496-002-s100><switch.ausschalten><en> Do not continue to press the On/Off switch after the ma- chine has been automatically switched off.
<G-vec00496-002-s101><switch.ausschalten><de> Die Wandleuchte Tolomeo Mega Parete ist mit einem Ein-/Ausschalter oder mit einem Dimmer am Stromkabel erhältlich.
<G-vec00496-002-s101><switch.ausschalten><en> The wall light Tolomeo Mega Parete features an on/off switch or a suspension lamp from € 408,00 %22>
<G-vec00496-002-s102><switch.ausschalten><de> CON (MATRIX-Send ein/aus) Dies ist ein Ein-/Ausschalter fur das Signal, das vom MIX-Kanal an den MATRIX-Bus gesendet wird.
<G-vec00496-002-s102><switch.ausschalten><en> BON (MATRIX send on/off) This is an on/off switch for the signal sent from the MIX channel to the MATRIX bus.
<G-vec00496-002-s103><switch.ausschalten><de> Kärcher BP 1 Barrel Set Das Komplettpaket BP 1 Barrel Set (vorherige Bezeichnung: SBP 3800 Set) bestehend aus der innovativen Fasspumpe mit direktem Ein-/Ausschalter an der Fassrandbefestigung, 15m PrimoFlex®-Schlauch, Spritzpistole, Universal-Schlauchkupplung und Universal-Schlauchkupplung mit Aqua Stop.
<G-vec00496-002-s103><switch.ausschalten><en> The all-in-one package BP 1 Barrel Set (former name: SBP 3800 Set) consist of the innovative barell pump SBP 3800 with direct on-/off switch at the clamping device, 15m PrimoFlex® Hose (1/2 inch), Spray gun, Universal hose connector and Universal hose connector with Aqua Stop.
<G-vec00496-002-s104><switch.ausschalten><de> Im Prinzip gibt es nur einen Ein-/Ausschalter, einen Selbstauslöser, den Filmtransporthebel und die Einstellung für die Filmempfindlichkeit unter der Rückspulkurbel.
<G-vec00496-002-s104><switch.ausschalten><en> There is only a on / off switch, a self timer, the winding lever, and the film speed dial around the rewind crank.
<G-vec00496-002-s105><switch.ausschalten><de> An-/Ausschalter auf Rückseite Metall, außen Kunststoff.
<G-vec00496-002-s105><switch.ausschalten><en> On/off switch on the back of the bulb holder.
<G-vec00496-002-s106><switch.ausschalten><de> 12 zeigt einen Vakuumkolben, in dem ein Ausschalter und ein Erdungsschalter aufgebaut sind.
<G-vec00496-002-s106><switch.ausschalten><en> 12 shows a vacuum bulb in which a breaker and an earthing switch are built-up.
<G-vec00496-002-s107><switch.ausschalten><de> uSchieben Sie den Ein-/Ausschalter(1) zurück in die Stellung 0, um das Gerät auszuschalten.
<G-vec00496-002-s107><switch.ausschalten><en> uTo switch the appliance off, slide the on/off switch (1) back to position 0.
<G-vec00496-002-s108><switch.ausschalten><de> Costanza (D13i) mit Teleskopstange (ausfahrbarem Alustab) und An/Ausschalter.
<G-vec00496-002-s108><switch.ausschalten><en> Costanza (D13i) with telescope arm (extendable aluminium rod) and on/off switch.
<G-vec00496-002-s109><switch.ausschalten><de> Ein-/Ausschalter am Netzkabel.
<G-vec00496-002-s109><switch.ausschalten><en> On/Off switch on the power cord.
<G-vec00496-002-s110><switch.ausschalten><de> Versorgungsmaterial-Der Rotisserie-Motor aus Edelstahl Mit wasserdichtem Ein- / Ausschalter und Auto-Reverse-Funktion.
<G-vec00496-002-s110><switch.ausschalten><en> The Stainless Steel Rotisserie Motor with waterproof on/off switch and auto reverse function.
<G-vec00496-002-s111><switch.ausschalten><de> Der HGG 200 Niro Vario ist mit einem praktischen Tragegriff zum einfachen Transport und einem Ein-/ Ausschalter für den Lüfter ausgestattet.
<G-vec00496-002-s111><switch.ausschalten><en> The HGG 200 Niro Vario is fitted with a handy carry handle for easy transport and an On/Off switch for the fan.
<G-vec00496-002-s112><switch.ausschalten><de> Unbemannte Flugobjekte, Dronen, Überwachungsballons, Minihubschrauber mit Kameras und andere Flugobjekte mit einem Ein-/Ausschalter.
<G-vec00496-002-s112><switch.ausschalten><en> Unmanned aerial devices, drones, survey balloons, photography mini-copters, and any flying device with an on/off switch.
<G-vec00496-002-s113><switch.ausschalten><de> Der Ein-/Ausschalter ist ausschließlich für die DockingStation selbst.
<G-vec00496-002-s113><switch.ausschalten><en> The on/off switch is only for the DockingStation itself.
<G-vec00514-002-s154><shut_up.ausschalten><de> Es ist nicht zufällig, dass dieser Versuch, Russia Today auszuschalten, in eine Zeit fällt, da die westlichen Medien inklusive BBC einen Propagandakrieg gegen Russland führen, der dem der Entente gegen Deutschland vor und während des Ersten Weltkriegs in nichts nachsteht.
<G-vec00514-002-s154><shut_up.ausschalten><en> It is no coincidence that this attempt to shut down the accounts of Russia Today in the UK comes at a time when the western media, including the BBC, are waging a propaganda war against Russia which is no less intense than that waged by the Entente against Germany before and during the First World War.
<G-vec00514-002-s155><shut_up.ausschalten><de> Große Firmen werden einfach versuchen kleine Konkurrenz auszuschalten.
<G-vec00514-002-s155><shut_up.ausschalten><en> Big companies will just try to shut down small competitors.
<G-vec00514-002-s156><shut_up.ausschalten><de> Die Firewall kann Ratenbegrenzungdienste (Rate Limiting Services) bereitstellen, um Angreifer auszuschalten, die einen Server lahm legen möchten.
<G-vec00514-002-s156><shut_up.ausschalten><en> The firewall can provide rate limiting services to shut down attackers trying to overwhelm the server.
<G-vec00514-002-s157><shut_up.ausschalten><de> Vergisst du, sie auszuschalten, ist es auch kein Problem: Nach 10 sec erledigt sie das von selbst.
<G-vec00514-002-s157><shut_up.ausschalten><en> If you forget to shut it off, that’s not a problem: After 10 seconds it will do that on its own.
<G-vec00514-002-s158><shut_up.ausschalten><de> Um Ihren Computer auszuschalten: 1 Öffnen Sie die Charms und wählen Sie dann Einstellungen.
<G-vec00514-002-s158><shut_up.ausschalten><en> To shut down your tablet: 1 Open the charms, and then select Settings.
<G-vec00514-002-s159><shut_up.ausschalten><de> Um zu verhindern, dass der Schaden noch größer wird, ist es bei diesem Fehler besonders wichtig, sofort den Server auszuschalten und nicht mehr unter Strom zu setzen.
<G-vec00514-002-s159><shut_up.ausschalten><en> To prevent the damage from getting worse it is very important to shut the server down immediately and not apply power anymore.
<G-vec00514-002-s160><shut_up.ausschalten><de> Das Dunkel verstand, dass dies von großer Wichtigkeit für die Entwicklung der Seele war, und sehr früh in der Existenz der Menschheit, wob das Dunkel sein tückisches Netz, um dieses zusammengesetzte Zentrum auszuschalten.
<G-vec00514-002-s160><shut_up.ausschalten><en> The dark understood that this was of great importance to the development of thesoul and very early in humanity's existence, the dark wove its nefarious web in order to shut down this composite center.
<G-vec00514-002-s161><shut_up.ausschalten><de> Ihr seid in einem menschlichen Körper, ihr seid Kräften unterworfen, die über euer Verständnis hinausgehen, aber nicht jenseits Meiner Macht, sie auszuschalten.
<G-vec00514-002-s161><shut_up.ausschalten><en> You are in a human body, subject to forces beyond your understanding, but not beyond My power to shut down.
<G-vec00555-002-s102><dismiss.ausschalten><de> Man sucht wissenschaftlich alles in der Schöpfung zu erklären und begründen, eine erschaffende Macht aber auszuschalten - also sie gänzlich zu leugnen.
<G-vec00555-002-s102><dismiss.ausschalten><en> Scientifically one seeks to explain and justify everything in creation, but to dismiss a creating power - so to completely deny it.
