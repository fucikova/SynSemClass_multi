<G-vec00042-001-s100><attend.besuchen><de> Bei Bedarf bietet Ihnen die Credit Suisse gerne ein Beratungsgespräch an, zusätzlich können Sie den folgenden Kurs besuchen: «Clever eine Firma gründen» (Terminvereinbarung über Startups.ch).
<G-vec00042-001-s100><attend.besuchen><en> "If required, Credit Suisse will be happy to offer a personal consultation, and you can also attend the following course: ""Founding a company"" (dates and registration via Startups.ch)."
<G-vec00042-001-s101><attend.besuchen><de> Aufnahme von Schülerinnen und Schülern als Besucher Besucherinnen und Besucher sind ehemalige Schülerinnen und Schüler unserer Schule, die bis zu 10 Tagen an der GISW den Unterricht besuchen.
<G-vec00042-001-s101><attend.besuchen><en> Visiting Students are former students of our school who would like to visit the German International School Washington D.C. for up to 10 days and attend classes during that time.
<G-vec00042-001-s102><attend.besuchen><de> Deshalb hat Foks die Kräfte zusammengenommen und fing an, die Kurse der Rehabilitierung zu besuchen.
<G-vec00042-001-s102><attend.besuchen><en> Therefore Fox collected the strength and began to attend rehabilitation courses.
<G-vec00042-001-s103><attend.besuchen><de> "Die Leute kommen aus der ganzen Welt an private und öffentliche Maskenbälle besuchen und maskierte Personen überfallen all die vielen ""Campi"", wo Musik und Tanz geht weiter, bis zum nächsten Tag."
<G-vec00042-001-s103><attend.besuchen><en> "People come from all the world over to attend private and public masked balls and masked people invade all the numerous ""campi"" where music and dancing continues until the day after."
<G-vec00042-001-s104><attend.besuchen><de> Der Referent kann dann selbst verwalten, an welchen Tagen er vor Ort sein wird und welche Workshops er besuchen möchte.
<G-vec00042-001-s104><attend.besuchen><en> The speaker himself can then manage which days he will be on site and which workshops he would like to attend.
<G-vec00042-001-s105><attend.besuchen><de> Im Anschluss an die Führung besteht um 18.15 Uhr die Möglichkeit, einenArtist Talk von Miet Warlop sowie um 19.30 Uhr die Aufführung von Mystery Magnet in der TQW Halle G zu besuchen.
<G-vec00042-001-s105><attend.besuchen><en> After the tour you have the option to attend anArtist Talkwith Miet Warlop at 18.15 as well as the show Mystery Magnetat 19.30 at TQW Halle G.
<G-vec00042-001-s106><attend.besuchen><de> "Berühmte russische Ballerina Anastasia ging eine Einladung an das Festival, ""Der große Unterschied"" in Odessa besuchen .."
<G-vec00042-001-s106><attend.besuchen><en> "Famous Russian ballerina Anastasia declined an invitation to attend the festival, ""The big difference"" in Odessa .."
<G-vec00042-001-s107><attend.besuchen><de> 2013 gaben etwa 60 Prozent der befragten Tunesier an, keine Moschee mehr zu besuchen, sondern lieber zu Hause zu beten.
<G-vec00042-001-s107><attend.besuchen><en> In 2013, about 60 percent of Tunisians polled said that they no longer attend mosques but instead pray at home.
<G-vec00042-001-s108><attend.besuchen><de> Durch die Nähe zu allen Fachbereichen eignet sich die Wohnanlage Kleeburger Weg gut für Studierende, die täglich an unterschiedlichen Standorten Vorlesungen besuchen.
<G-vec00042-001-s108><attend.besuchen><en> Thanks to its proximity to all faculties, the Kleeburger Weg residence is good for students that attend lectures at different locations every day.
<G-vec00042-001-s109><attend.besuchen><de> Bitte geben Sie auf dem Onlineformular an, ob Sie die Pressekonferenz und die Preview Days in Athen, in Kassel, oder in beiden Städten besuchen wollen.
<G-vec00042-001-s109><attend.besuchen><en> Please indicate on the online form whether you would like to attend the press or preview days in Athens, Kassel, or both cities.
<G-vec00301-001-s319><attend.besuchen><de> "Diese ermöglicht ihm den Besuch der ""Technischen Bildungsanstalt"" in Dresden und damit eine Ausbildung, wie sie damals gewöhnlich nur einem Ingenieur oder Techniker zuteil wird."
<G-vec00301-001-s319><attend.besuchen><en> This enables him to attend the Technical School in Dresden and thus receive an education that is usually only bestowed upon engineers and technicians at the time.
<G-vec00301-001-s320><attend.besuchen><de> Studierende, die aus wichtigen Gründen (Krankheit, Unfall, Mutterschaft, Praktika, Militärdienst oder Zivildienst) während längerer Zeit am Besuch der Lehrveranstaltungen vollständig verhindert sind, können auf ein schriftliches Gesuch hin vom zuständigen Dekanat beurlaubt werden.
<G-vec00301-001-s320><attend.besuchen><en> Students who are entirely unable to attend any lectures over a prolonged period on important grounds (illness, accident, maternity, work placement, military or civil service) can be granted a leave of absence by the responsible Dean's office upon written request.
<G-vec00301-001-s321><attend.besuchen><de> Ich bete jetzt besonders für Priester, speziell beim Besuch der täglichen Heiligen Messe.
<G-vec00301-001-s321><attend.besuchen><en> I pray specially for priests now, especially when I attend the Mass daily.
<G-vec00301-001-s322><attend.besuchen><de> Um auch Kindern, deren Eltern die Schulgelder nicht bezahlen können, den Besuch der Schule Cruz del Sur ermöglichen zu können, werden Patenschaften gesucht.
<G-vec00301-001-s322><attend.besuchen><en> In order to allow children to attend school, even though some of their parents are not able to cover the school fee, the initiative keeps on searching for donations and educational sponsorships.
<G-vec00301-001-s323><attend.besuchen><de> Während seiner Studienzeit ermöglichte ihm das Erasmus/Sokrates-Stipendium einen zwölfmonatigen Besuch der École Nationale Supérieure des Beaux-Arts in Paris.
<G-vec00301-001-s323><attend.besuchen><en> During his studies, an Erasmus/Socrates Scholarship allowed him to attend the École Nationale Supérieure des Beaux-Arts in Paris for twelve months.
<G-vec00301-001-s324><attend.besuchen><de> "Datenverarbeitung bei der Umpersonalisierung personalisierter Tickets Wenn Sie ein personalisiertes Ticket gekauft haben und das Recht zum Besuch der Veranstaltung auf einen Dritten übertragen haben (Abtretung), muss der Name des Dritten auf dem Ticket vermerkt werden (""Umpersonalisierung""), damit dieser Einlass in die gebuchte Veranstaltung erhält."
<G-vec00301-001-s324><attend.besuchen><en> Data processing when re-personalizing personalized tickets When you purchased a personalized ticket and transferred the right to attend the event to a third party (assignment), the name of the third party must be noted on the ticket (re-personalization) so that he or she will be granted entrance to the booked event.
<G-vec00301-001-s325><attend.besuchen><de> Nachdem Herr Bai zum Besuch der Gehirnwäschekurse gezwungen worden und für ein Jahr im Macheng Gefängnis Nr.1 eingesperrt war, wurde er zu vier Jahren Gefängnis verurteilt.
<G-vec00301-001-s325><attend.besuchen><en> After Mr. Bai was forced to attend brainwashing sessions and detained in the Macheng No. 1 Detention Centre for a year, he was sentenced to four years in prison.
<G-vec00301-001-s326><attend.besuchen><de> Die Zusammenarbeit von Roche und den Salzburger Festspielen ermöglicht vor allem Jugendlichen aus europäischen Hochschulen den Besuch von Veranstaltungen zeitgenössischer Musik in Salzburg und versucht eine Verbindung zwischen Innovationen in Kunst und Musik einer- und Naturwissenschaften anderseits aufzuzeigen.
<G-vec00301-001-s326><attend.besuchen><en> This collaboration between Roche and the Salzburg Festival will primarily allow European university and college students to attend contemporary music events in Salzburg, and will attempt to uncover the link between innovation in music and art on the one hand and science on the other.
<G-vec00301-001-s327><attend.besuchen><de> Besuch aller fälle von psychopathologischen erkrankungen entstehen und porhaber, wir sind ein team für ihr wohlergehen in der stadt tacna.
<G-vec00301-001-s327><attend.besuchen><en> Attend all cases of psychopathological diseases incurred and porhaber, we are a team working for their welfare in the city of tacna.
<G-vec00301-001-s328><attend.besuchen><de> Jüdischen Jugendlichen wurde der Besuch von höheren Schulen verboten, die systematische Ausplünderung der Besitzenden begann.
<G-vec00301-001-s328><attend.besuchen><en> Jewish youths were forbidden attend to higher schools, the systematic plundering of the propertied class began.
<G-vec00301-001-s329><attend.besuchen><de> Eine Akkreditierung im Bereich MEDIEN hat nur für die antragstellende Person Gültigkeit, d.h. ist personengebunden und damit nicht übertragbar, und berechtigt ausschließlich zur Nutzung eines von dem Club zugeteilten Arbeitsplatzes auf der Pressetribüne sowie nach Spielende - je nach Kapazität - auch zum Zutritt zur Mixed-Zone und zum Besuch der Pressekonferenz.
<G-vec00301-001-s329><attend.besuchen><en> Once issued, a media accreditation is non-transferable and entitles the holder (i) to occupy and use a working space on the post match press stand, (ii) to access the mixed zone after the match, and (iii) to attend the press conference, subject to space restrictions.
<G-vec00301-001-s330><attend.besuchen><de> Sie ermöglicht Kindern aus den ärmsten Familien den kostenlosen Besuch des Kindergartens und der Primarschule.
<G-vec00301-001-s330><attend.besuchen><en> It enables children from the poorest families to attend nursery and primary school free of cost.
<G-vec00301-001-s331><attend.besuchen><de> Sehr zu empfehlen ist auch ein Besuch des Ritterlagers und des mittelalterlichen Markts.
<G-vec00301-001-s331><attend.besuchen><en> Visitors are also encouraged to attend the knight camp and medieval market.
<G-vec00301-001-s332><attend.besuchen><de> Um dieses Ideal wirklich zu leben und Kindern überall auf der Welt den Besuch einer Schule zu ermöglichen, ist es wichtig, dass wir uns an diesen wesentlichen Impuls erinnern und uns über Landesgrenzen hinaus einander helfend die Hände reichen – von Kontinent zu Kontinent, von Kultur zu Kultur, von Mensch zu Mensch.
<G-vec00301-001-s332><attend.besuchen><en> In order to truly live this ideal and to allow children everywhere in this world to attend school, it is important to remind us of this essential impulse by reaching out to one another beyond national borders – from one continent to another, from one human being to another.
<G-vec00301-001-s333><attend.besuchen><de> Die gemeinsame Sprache ist die Voraussetzung für den Besuch weiterführender Schulen, die durch staatliche und karitative Träger in Togo angeboten werden.
<G-vec00301-001-s333><attend.besuchen><en> This common language is the prerequisite for going on to attend secondary schools, which is funded in Togo by the state and by charitable means.
<G-vec00301-001-s334><attend.besuchen><de> Wir werden die von Ihnen hochgeladenen Daten unverzüglich wieder löschen, wenn die Umpersonalisierung abgeschlossen ist.Für diesen Fall wird klargestellt, dass es sich hierbei nicht um eine Übertragung des Vertrags mit dem Veranstalter (Ziffer 11.1) handelt, sondern es wird lediglich das Recht zum Besuch der Veranstaltung übertragen, wie in Ziffer 10.1 geregelt.
<G-vec00301-001-s334><attend.besuchen><en> It is hereby made clear for the above case that this is not a transfer of the contract with the event organizer (Clause 11.1.), and that solely the right to attend the event is transferred as provided for in Clause 10.1.
<G-vec00301-001-s335><attend.besuchen><de> Vereinzelt wurde gefordert, Juden sollten zum Besuch evangelischer Predigtgottesdienste gezwungen werden.
<G-vec00301-001-s335><attend.besuchen><en> A few individuals called for Jews to be compelled to attend Protestant preaching services.
<G-vec00301-001-s336><attend.besuchen><de> "Das neue Gesetz, das auch als ""Gesetz über die Verantwortlichkeit der Eltern"" genannt wird, verbietet Kindern und Jugendlichen den Besuch von Orten oder Versammlungen sowie von Religionsschulen, die nicht vom Staat anerkannt werden."
<G-vec00301-001-s336><attend.besuchen><en> "Called ""law on parental responsibility"", the law, promoted by the government, declares it illegal to make children attend assemblies and places of worship or religious schools which are not recognized by the state."
<G-vec00301-001-s337><attend.besuchen><de> Der Besuch einer Comedy-Show in Paris verspricht Spaß pur.
<G-vec00301-001-s337><attend.besuchen><en> A fun thing to do in Paris at night is attend a comedy show.
<G-vec00042-001-s338><attend.besuchen><de> Besuche die Hochzeit im Level „Sommer“.
<G-vec00042-001-s338><attend.besuchen><en> Attend the wedding on the SUMMER level.
<G-vec00042-001-s339><attend.besuchen><de> Wenn du es genauer wissen willst, besuche einen unserer Schnupperinfotage, die wir im Frühjahr an verschiedenen Standorten in der Schweiz und für unterschiedliche Lehrberufe anbieten.
<G-vec00042-001-s339><attend.besuchen><en> If you would like to know more, simply attend one of our career information days held in spring at several locations across Switzerland for a range of apprenticeship trades.
<G-vec00042-001-s340><attend.besuchen><de> Ich besuche in einer Spezialklasse ür Physik.
<G-vec00042-001-s340><attend.besuchen><en> I attend a special class in physics.
<G-vec00042-001-s341><attend.besuchen><de> Jetzt glaube ich an Gott aber ich besuche die Kirche nicht regelmäßig, bete aber jeden Abend und bin dankbar für meine Kinder meine Frau und meine Karriere.
<G-vec00042-001-s341><attend.besuchen><en> Now I believe in God but I don't attend church on a regular basis, but pray every night and I'm thankful for my kids and wife and my career.
<G-vec00042-001-s342><attend.besuchen><de> Kommentar: Lerne Italienisch in einer angenehmen und entspannenden Umgebung und besuche eine Vielzahl von kulturellen Aktivitäten.
<G-vec00042-001-s342><attend.besuchen><en> Comments: Learn Italian in a pleasant and relaxing environment and attend a wide variety of cultural activities.
<G-vec00042-001-s343><attend.besuchen><de> Von einem Graduiertenkolleg (GRK) wird erwartet, dass es enge Kontakte ins Ausland pflegt, Gastwissenschaftlerinnen und Gastwissenschaftler aus dem Ausland einlädt, Promovierende international rekrutiert und ihnen Auslandsaufenthalte und Besuche von internationalen Konferenzen ermöglicht.
<G-vec00042-001-s343><attend.besuchen><en> A Research Training Group (RTG) is expected to maintain close contacts with researchers in other countries, invite visiting researchers from abroad, recruit doctoral researchers internationally and allow them to spend time working abroad and attend international conferences.
<G-vec00042-001-s344><attend.besuchen><de> "guten Abend, Ich glaube nicht, ""ich besuche"" diese Websites, die Sie don erwähnt Ariel und ich habe die Zeit und intellektuelle Fähigkeiten beurteilen zu können,."
<G-vec00042-001-s344><attend.besuchen><en> "Good evening, I don't ""I attend"" These sites you don Ariel and I did not mention the time and brainpower in order to form an opinion."
<G-vec00042-001-s345><attend.besuchen><de> Ich besuche mindestens zwei große Lehrgänge zur Kompetenzsteigerung pro Jahr, 2017 Jahr waren es sogar fünf.
<G-vec00042-001-s345><attend.besuchen><en> I attend at least two major training courses to enhance my skills each year; in 2017, I even took part in five.
<G-vec00042-001-s346><attend.besuchen><de> Ich besuche die Freie Waldorfschule Dresden.
<G-vec00042-001-s346><attend.besuchen><en> I attend the Free Waldorf School in Dresden.
<G-vec00042-001-s347><attend.besuchen><de> Ich besuche die Berufsschule in Plön und mache momentan mein Fachabitur mit einer Ausbildung zur kaufmännischen Assistentin.
<G-vec00042-001-s347><attend.besuchen><en> I attend the vocational school in Plön and am currently doing my professional education with a training as a commercial assistant.
<G-vec00042-001-s348><attend.besuchen><de> "Während des Semesters bin ich genauso wie ""normale"" Studenten an der Hochschule und besuche die Vorlesungen."
<G-vec00042-001-s348><attend.besuchen><en> "During the semester, I go to school just like the ""regular"" students and attend lectures."
<G-vec00042-001-s349><attend.besuchen><de> Geplant war, dass ich zwei Wochen eine Sprachschule besuche und danach viereinhalb Monate eine Freiwilligenarbeit in einem Waisenheim mache.
<G-vec00042-001-s349><attend.besuchen><en> The plan was to attend a language school for two weeks, and after that volunteer in an orphanage for four and a half months.
<G-vec00042-001-s350><attend.besuchen><de> Gottes Liebe für seine Kinder basiert nicht auf der Anzahl der Besuche des Gottesdienstes.
<G-vec00042-001-s350><attend.besuchen><en> God’s love for His children is not based on the number of times they attend formal services.
<G-vec00042-001-s351><attend.besuchen><de> In der Probe, die ich besuche, arbeitet die Gruppe gerade an einer Szene, in der Edith von Kekesfalva, die lahme Tochter des Barons, zu laufen versucht.
<G-vec00042-001-s351><attend.besuchen><en> In the rehearsal I attend, they work on a scene where the Baron's lame daughter, Edith von Kekesfalva, tries to walk.
<G-vec00042-001-s352><attend.besuchen><de> Ich besuche die Pfarrei, nicht nur die Sonntagsmesse, sondern auch verschiedene Sitzungen, Katechese, usw..
<G-vec00042-001-s352><attend.besuchen><en> I attend the parish, not only Sunday Mass, but also various meetings, catechesis, etc..
<G-vec00042-001-s353><attend.besuchen><de> Besuche eines der vielen Freestylecamps - du wirst sehen, wie schnell du Fortschritte machst.
<G-vec00042-001-s353><attend.besuchen><en> Attend one of the many freestyle camps – you'll be amazed how quickly you make progress.
<G-vec00042-001-s354><attend.besuchen><de> Ich besuche regelmäßig Meetups in Berlin – die Stadt ist sehr aktiv in diesem Bereich.
<G-vec00042-001-s354><attend.besuchen><en> I usually attend many meetups in Berlin, and the city is very active in this way.
<G-vec00042-001-s355><attend.besuchen><de> Besuche öffentliche Konzerte, Feste, Feierlichkeiten und Festessen für Diwali.
<G-vec00042-001-s355><attend.besuchen><en> Attend public concerts, parties, celebratory events, and feasts for Diwali.
<G-vec00042-001-s356><attend.besuchen><de> Lukas Trautmann: Ich bin 17 Jahre, aus Salzburg in Österreich, besuche eine Handelsschule für Sport und fahre jetzt im dritten Jahr den Red Bull Rookies Cup.
<G-vec00042-001-s356><attend.besuchen><en> I am 17 years old from Salzburg in Austria. I attend a trade school for sports and this is now my third year in the Red Bull Rookies Cup.
<G-vec00301-001-s338><attend.besuchen><de> Besuche die Hochzeit im Level „Sommer“.
<G-vec00301-001-s338><attend.besuchen><en> Attend the wedding on the SUMMER level.
<G-vec00301-001-s339><attend.besuchen><de> Wenn du es genauer wissen willst, besuche einen unserer Schnupperinfotage, die wir im Frühjahr an verschiedenen Standorten in der Schweiz und für unterschiedliche Lehrberufe anbieten.
<G-vec00301-001-s339><attend.besuchen><en> If you would like to know more, simply attend one of our career information days held in spring at several locations across Switzerland for a range of apprenticeship trades.
<G-vec00301-001-s340><attend.besuchen><de> Ich besuche in einer Spezialklasse ür Physik.
<G-vec00301-001-s340><attend.besuchen><en> I attend a special class in physics.
<G-vec00301-001-s341><attend.besuchen><de> Jetzt glaube ich an Gott aber ich besuche die Kirche nicht regelmäßig, bete aber jeden Abend und bin dankbar für meine Kinder meine Frau und meine Karriere.
<G-vec00301-001-s341><attend.besuchen><en> Now I believe in God but I don't attend church on a regular basis, but pray every night and I'm thankful for my kids and wife and my career.
<G-vec00301-001-s342><attend.besuchen><de> Kommentar: Lerne Italienisch in einer angenehmen und entspannenden Umgebung und besuche eine Vielzahl von kulturellen Aktivitäten.
<G-vec00301-001-s342><attend.besuchen><en> Comments: Learn Italian in a pleasant and relaxing environment and attend a wide variety of cultural activities.
<G-vec00301-001-s343><attend.besuchen><de> Von einem Graduiertenkolleg (GRK) wird erwartet, dass es enge Kontakte ins Ausland pflegt, Gastwissenschaftlerinnen und Gastwissenschaftler aus dem Ausland einlädt, Promovierende international rekrutiert und ihnen Auslandsaufenthalte und Besuche von internationalen Konferenzen ermöglicht.
<G-vec00301-001-s343><attend.besuchen><en> A Research Training Group (RTG) is expected to maintain close contacts with researchers in other countries, invite visiting researchers from abroad, recruit doctoral researchers internationally and allow them to spend time working abroad and attend international conferences.
<G-vec00301-001-s344><attend.besuchen><de> "guten Abend, Ich glaube nicht, ""ich besuche"" diese Websites, die Sie don erwähnt Ariel und ich habe die Zeit und intellektuelle Fähigkeiten beurteilen zu können,."
<G-vec00301-001-s344><attend.besuchen><en> "Good evening, I don't ""I attend"" These sites you don Ariel and I did not mention the time and brainpower in order to form an opinion."
<G-vec00301-001-s345><attend.besuchen><de> Ich besuche mindestens zwei große Lehrgänge zur Kompetenzsteigerung pro Jahr, 2017 Jahr waren es sogar fünf.
<G-vec00301-001-s345><attend.besuchen><en> I attend at least two major training courses to enhance my skills each year; in 2017, I even took part in five.
<G-vec00301-001-s346><attend.besuchen><de> Ich besuche die Freie Waldorfschule Dresden.
<G-vec00301-001-s346><attend.besuchen><en> I attend the Free Waldorf School in Dresden.
<G-vec00301-001-s347><attend.besuchen><de> Ich besuche die Berufsschule in Plön und mache momentan mein Fachabitur mit einer Ausbildung zur kaufmännischen Assistentin.
<G-vec00301-001-s347><attend.besuchen><en> I attend the vocational school in Plön and am currently doing my professional education with a training as a commercial assistant.
<G-vec00301-001-s348><attend.besuchen><de> "Während des Semesters bin ich genauso wie ""normale"" Studenten an der Hochschule und besuche die Vorlesungen."
<G-vec00301-001-s348><attend.besuchen><en> "During the semester, I go to school just like the ""regular"" students and attend lectures."
<G-vec00301-001-s349><attend.besuchen><de> Geplant war, dass ich zwei Wochen eine Sprachschule besuche und danach viereinhalb Monate eine Freiwilligenarbeit in einem Waisenheim mache.
<G-vec00301-001-s349><attend.besuchen><en> The plan was to attend a language school for two weeks, and after that volunteer in an orphanage for four and a half months.
<G-vec00301-001-s350><attend.besuchen><de> Gottes Liebe für seine Kinder basiert nicht auf der Anzahl der Besuche des Gottesdienstes.
<G-vec00301-001-s350><attend.besuchen><en> God’s love for His children is not based on the number of times they attend formal services.
<G-vec00301-001-s351><attend.besuchen><de> In der Probe, die ich besuche, arbeitet die Gruppe gerade an einer Szene, in der Edith von Kekesfalva, die lahme Tochter des Barons, zu laufen versucht.
<G-vec00301-001-s351><attend.besuchen><en> In the rehearsal I attend, they work on a scene where the Baron's lame daughter, Edith von Kekesfalva, tries to walk.
<G-vec00301-001-s352><attend.besuchen><de> Ich besuche die Pfarrei, nicht nur die Sonntagsmesse, sondern auch verschiedene Sitzungen, Katechese, usw..
<G-vec00301-001-s352><attend.besuchen><en> I attend the parish, not only Sunday Mass, but also various meetings, catechesis, etc..
<G-vec00301-001-s353><attend.besuchen><de> Besuche eines der vielen Freestylecamps - du wirst sehen, wie schnell du Fortschritte machst.
<G-vec00301-001-s353><attend.besuchen><en> Attend one of the many freestyle camps – you'll be amazed how quickly you make progress.
<G-vec00301-001-s354><attend.besuchen><de> Ich besuche regelmäßig Meetups in Berlin – die Stadt ist sehr aktiv in diesem Bereich.
<G-vec00301-001-s354><attend.besuchen><en> I usually attend many meetups in Berlin, and the city is very active in this way.
<G-vec00301-001-s355><attend.besuchen><de> Besuche öffentliche Konzerte, Feste, Feierlichkeiten und Festessen für Diwali.
<G-vec00301-001-s355><attend.besuchen><en> Attend public concerts, parties, celebratory events, and feasts for Diwali.
<G-vec00301-001-s356><attend.besuchen><de> Lukas Trautmann: Ich bin 17 Jahre, aus Salzburg in Österreich, besuche eine Handelsschule für Sport und fahre jetzt im dritten Jahr den Red Bull Rookies Cup.
<G-vec00301-001-s356><attend.besuchen><en> I am 17 years old from Salzburg in Austria. I attend a trade school for sports and this is now my third year in the Red Bull Rookies Cup.
<G-vec00042-001-s357><attend.besuchen><de> Alle internationalen Vollzeitstudierenden sind außerdem herzlich eingeladen, zusätzlich die regulären Orientierungswochen zu besuchen, die von den jeweiligen Fachschaften organisiert werden.
<G-vec00042-001-s357><attend.besuchen><en> In addition to that, international degree-seeking students are welcome to also attend the regular Orientation Weeks, organised by the respective faculty student representative committees.
<G-vec00042-001-s358><attend.besuchen><de> 37 Prozent der Schülerinnen und Schüler besuchen in Österreich in der Sekundarstufe II demnach eine berufsbildende Schule (OECD: 31 Prozent), 33 Prozent machen eine Lehre (OECD: 13 Prozent).
<G-vec00042-001-s358><attend.besuchen><en> 37% of pupils in Austria at the upper secondary level attend a vocational school (OECD: 31%), 33% are involved in apprenticeship training (OECD: 13%). The remaining 30% (OECD: 56%) are getting a general education in the upper grades of an academic secondary school.
<G-vec00042-001-s359><attend.besuchen><de> Wier empfehlen nachdrücklich die Termindaten der Veranstaltung die Sie besuchen möchten zu überprüfen, bevor Sie ein Hotel oder ein Auto in Cherbourg mieten.
<G-vec00042-001-s359><attend.besuchen><en> You are strongly advised to check the dates of the event you plan to attend before you book a hotel or rent a car in Cherbourg.
<G-vec00042-001-s360><attend.besuchen><de> "So können die Studierenden der HFF Lehrveranstaltungen aus dem Angebot des TUM Sprachenzentrums besuchen, um sich entweder gezielt auf geplante Auslandsaufenthalte vorzubereiten oder mittels Lehrveranstaltungen ""Deutsch als Fremdsprache"" ihre Deutschkenntnisse zu vertiefen."
<G-vec00042-001-s360><attend.besuchen><en> "HFF students can attend courses offered by the TUM Language Center in 17 languages, either to prepare for planned stays abroad or to deepen their knowledge of German through ""German as a foreign language"" courses."
<G-vec00042-001-s361><attend.besuchen><de> Auch werden bei Lehrern, die den Kurs besuchen, Werkzeuge ihnen vorgesehen sein, dass sie ihren Schülern diese Techniken aus eigener Erfahrung beibringen können.
<G-vec00042-001-s361><attend.besuchen><en> Also, in the case of teachers who attend the course, tools will be provided them so that they can teach their students these techniques from personal experience.
<G-vec00042-001-s362><attend.besuchen><de> Anstatt also den Abend mit Fliegenjagd in unserem Hotel zu verbringen, erschien es viel sinnvoller, das Konzert von Valkyrien Allstars in Sandane zu besuchen.
<G-vec00042-001-s362><attend.besuchen><en> So instead of spending the evening fly-hunting in our hotel, it had seemed to be a much better decision to attend Valkyrien Allstars concert in Sandane.
<G-vec00042-001-s363><attend.besuchen><de> Besuchen Sie per Fahrrad eine kostenlose Show im Central Park, eine Gospelfeier in Harlem oder eine Dachparty im MoMa PS1 in Long Island City.
<G-vec00042-001-s363><attend.besuchen><en> Grab a free show at Central Park, attend a gospel celebration in Harlem or head to Long Island City for a rooftop party at MoMa PS1.
<G-vec00042-001-s364><attend.besuchen><de> Die erste große Veranstaltung für Airwheel Balance Elektroroller im Jahr 2016 soll der Consumer Electronics Show in Las Vegas, vom 6. bis 9., Jan, 2016 ausgetragen zu besuchen.
<G-vec00042-001-s364><attend.besuchen><en> The first big event for Airwheel self-balancing electric scooter in 2016 is to attend the Consumer Electronics Show, held in Las Vegas, from 6th to 9th, Jan, 2016.
<G-vec00042-001-s365><attend.besuchen><de> Aufgrund der unterschiedlichen Studienstrukturen wird jedes Departement anhand des vorliegenden Konzepts die Elemente definieren, die Studierenden besuchen können, um Portfoliopunkte für das Zertifikat zu sammeln.
<G-vec00042-001-s365><attend.besuchen><en> On the basis of the various different study structures, each departmentwill use the existing concept to define the study elements students can attend in order to gain portfolio points for the certificate.
<G-vec00042-001-s366><attend.besuchen><de> Abend auf dem Balkon des Rathauses sind frei Weihnachtskonzerte, und einen Tag mit ihren Kindern können die Lektionen der Backen köstliche bayerische Cookies besuchen.
<G-vec00042-001-s366><attend.besuchen><en> Evening on the balcony of the Town Hall are free Christmas concerts, and a day with their children can attend the lessons of baking delicious Bavarian cookies.
<G-vec00042-001-s367><attend.besuchen><de> Alleine in Ontario etwa gibt es mehr als 650 Golfplätze zu besuchen .
<G-vec00042-001-s367><attend.besuchen><en> In Ontario alone, there are about more than 650 To attend courses.
<G-vec00042-001-s368><attend.besuchen><de> """Die Treffen mit den OEMs produktiv waren, wie wir neue treffen könnten und besuchen ihre Anfragen und Angebote"", sagte der verantwortlich für die Spritzgussabteilung in Spanien, bei EQUIPLAST."
<G-vec00042-001-s368><attend.besuchen><en> Thanks to its proximity, this is a great opportunity for MachinePoint to focus on the Spanish customers and present them the latest news on used machinery for this market. “The meetings with the OEMs were productive as we could meet new ones and attend their requests and offers”, said the responsible for the injection moulding department in Spain, at EQUIPLAST.
<G-vec00042-001-s369><attend.besuchen><de> “Menschen, die unter Ängsten leiden, können solche Orte oft nicht besuchen.
<G-vec00042-001-s369><attend.besuchen><en> """People who have anxiety, they can't attend places like that."
<G-vec00042-001-s370><attend.besuchen><de> Wenn Sie vorhaben, eine Hochzeitsfeier als Gast oder die Mutter der Braut zu besuchen sind, haben Sie für einen guten Zweck dieses Kleid ist Meerjungfrau Silhouette und die bodenlange voller Eleganz zu nehmen.
<G-vec00042-001-s370><attend.besuchen><en> If you are going to attend a wedding ceremony as the guest or the mother of the brides, you have to take good use of this dress's mermaid silhouette and the floor-length full of elegance.
<G-vec00042-001-s371><attend.besuchen><de> Zudem können Sie sich die Galerie mit zahlreichen Skulpturen, Gemälden und Fotos anschauen, die je nach Jahreszeit wechseln, sowie Ausstellungen besuchen, um die Geheimnisse heutiger Künstler zu entdecken.
<G-vec00042-001-s371><attend.besuchen><en> Lastly, experience the 'Art Gallery' packed with sculptures, paintings and photographs that change with the seasons, and attend exhibitions to discover or rediscover all the secrets of current artists.
<G-vec00042-001-s372><attend.besuchen><de> In Istrien und auf den Kvarner Inseln war es den Kroaten und Slowenen (mehrheitliche Bevölkerung), die Mittelschule auf der Muttersprache zu besuchen.
<G-vec00042-001-s372><attend.besuchen><en> In Istria and on Kvarner islands, the Croats and Slovenians (the majority peoples) were allowed to attend secondary school in their mother tongues.
<G-vec00042-001-s373><attend.besuchen><de> Konstrukteure/ -innen werden im Ausbildungsbetrieb ausgebildet und besuchen während maximal zwei Tagen pro Woche die Berufsschule.
<G-vec00042-001-s373><attend.besuchen><en> Designers are trained in the in-house training facility and attend vocational school for a maximum of two days a week.
<G-vec00042-001-s374><attend.besuchen><de> Apprentissage Blackjack sich von einem Glücksspiel Schule nicht unbedingt erforderlich ist, Casinos da zu keinem Zeitpunkt im Wesentlichen verlangen, dass Sie zu einem privaten Händler Schule zu besuchen.
<G-vec00042-001-s374><attend.besuchen><en> Learning blackjack dealing from a casino school is not compulsory, as casinos do not actually require you to attend a private dealer school.
<G-vec00042-001-s375><attend.besuchen><de> Das bedeutet, dass keine zusätzliche Zeit benötigt wird, um CDs in einem entspannten Zustand zu hören oder Therapien oder Hypnose-Sessions zu besuchen.
<G-vec00042-001-s375><attend.besuchen><en> MindZoom mingles in your own time. This means no extra time to listen to CDs on a relaxed state, or attend Therapies or Hypnosis sessions.
<G-vec00301-001-s357><attend.besuchen><de> Alle internationalen Vollzeitstudierenden sind außerdem herzlich eingeladen, zusätzlich die regulären Orientierungswochen zu besuchen, die von den jeweiligen Fachschaften organisiert werden.
<G-vec00301-001-s357><attend.besuchen><en> In addition to that, international degree-seeking students are welcome to also attend the regular Orientation Weeks, organised by the respective faculty student representative committees.
<G-vec00301-001-s358><attend.besuchen><de> 37 Prozent der Schülerinnen und Schüler besuchen in Österreich in der Sekundarstufe II demnach eine berufsbildende Schule (OECD: 31 Prozent), 33 Prozent machen eine Lehre (OECD: 13 Prozent).
<G-vec00301-001-s358><attend.besuchen><en> 37% of pupils in Austria at the upper secondary level attend a vocational school (OECD: 31%), 33% are involved in apprenticeship training (OECD: 13%). The remaining 30% (OECD: 56%) are getting a general education in the upper grades of an academic secondary school.
<G-vec00301-001-s359><attend.besuchen><de> Wier empfehlen nachdrücklich die Termindaten der Veranstaltung die Sie besuchen möchten zu überprüfen, bevor Sie ein Hotel oder ein Auto in Cherbourg mieten.
<G-vec00301-001-s359><attend.besuchen><en> You are strongly advised to check the dates of the event you plan to attend before you book a hotel or rent a car in Cherbourg.
<G-vec00301-001-s360><attend.besuchen><de> "So können die Studierenden der HFF Lehrveranstaltungen aus dem Angebot des TUM Sprachenzentrums besuchen, um sich entweder gezielt auf geplante Auslandsaufenthalte vorzubereiten oder mittels Lehrveranstaltungen ""Deutsch als Fremdsprache"" ihre Deutschkenntnisse zu vertiefen."
<G-vec00301-001-s360><attend.besuchen><en> "HFF students can attend courses offered by the TUM Language Center in 17 languages, either to prepare for planned stays abroad or to deepen their knowledge of German through ""German as a foreign language"" courses."
<G-vec00301-001-s361><attend.besuchen><de> Auch werden bei Lehrern, die den Kurs besuchen, Werkzeuge ihnen vorgesehen sein, dass sie ihren Schülern diese Techniken aus eigener Erfahrung beibringen können.
<G-vec00301-001-s361><attend.besuchen><en> Also, in the case of teachers who attend the course, tools will be provided them so that they can teach their students these techniques from personal experience.
<G-vec00301-001-s362><attend.besuchen><de> Anstatt also den Abend mit Fliegenjagd in unserem Hotel zu verbringen, erschien es viel sinnvoller, das Konzert von Valkyrien Allstars in Sandane zu besuchen.
<G-vec00301-001-s362><attend.besuchen><en> So instead of spending the evening fly-hunting in our hotel, it had seemed to be a much better decision to attend Valkyrien Allstars concert in Sandane.
<G-vec00301-001-s363><attend.besuchen><de> Besuchen Sie per Fahrrad eine kostenlose Show im Central Park, eine Gospelfeier in Harlem oder eine Dachparty im MoMa PS1 in Long Island City.
<G-vec00301-001-s363><attend.besuchen><en> Grab a free show at Central Park, attend a gospel celebration in Harlem or head to Long Island City for a rooftop party at MoMa PS1.
<G-vec00301-001-s364><attend.besuchen><de> Die erste große Veranstaltung für Airwheel Balance Elektroroller im Jahr 2016 soll der Consumer Electronics Show in Las Vegas, vom 6. bis 9., Jan, 2016 ausgetragen zu besuchen.
<G-vec00301-001-s364><attend.besuchen><en> The first big event for Airwheel self-balancing electric scooter in 2016 is to attend the Consumer Electronics Show, held in Las Vegas, from 6th to 9th, Jan, 2016.
<G-vec00301-001-s365><attend.besuchen><de> Aufgrund der unterschiedlichen Studienstrukturen wird jedes Departement anhand des vorliegenden Konzepts die Elemente definieren, die Studierenden besuchen können, um Portfoliopunkte für das Zertifikat zu sammeln.
<G-vec00301-001-s365><attend.besuchen><en> On the basis of the various different study structures, each departmentwill use the existing concept to define the study elements students can attend in order to gain portfolio points for the certificate.
<G-vec00301-001-s366><attend.besuchen><de> Abend auf dem Balkon des Rathauses sind frei Weihnachtskonzerte, und einen Tag mit ihren Kindern können die Lektionen der Backen köstliche bayerische Cookies besuchen.
<G-vec00301-001-s366><attend.besuchen><en> Evening on the balcony of the Town Hall are free Christmas concerts, and a day with their children can attend the lessons of baking delicious Bavarian cookies.
<G-vec00301-001-s367><attend.besuchen><de> Alleine in Ontario etwa gibt es mehr als 650 Golfplätze zu besuchen .
<G-vec00301-001-s367><attend.besuchen><en> In Ontario alone, there are about more than 650 To attend courses.
<G-vec00301-001-s368><attend.besuchen><de> """Die Treffen mit den OEMs produktiv waren, wie wir neue treffen könnten und besuchen ihre Anfragen und Angebote"", sagte der verantwortlich für die Spritzgussabteilung in Spanien, bei EQUIPLAST."
<G-vec00301-001-s368><attend.besuchen><en> Thanks to its proximity, this is a great opportunity for MachinePoint to focus on the Spanish customers and present them the latest news on used machinery for this market. “The meetings with the OEMs were productive as we could meet new ones and attend their requests and offers”, said the responsible for the injection moulding department in Spain, at EQUIPLAST.
<G-vec00301-001-s369><attend.besuchen><de> “Menschen, die unter Ängsten leiden, können solche Orte oft nicht besuchen.
<G-vec00301-001-s369><attend.besuchen><en> """People who have anxiety, they can't attend places like that."
<G-vec00301-001-s370><attend.besuchen><de> Wenn Sie vorhaben, eine Hochzeitsfeier als Gast oder die Mutter der Braut zu besuchen sind, haben Sie für einen guten Zweck dieses Kleid ist Meerjungfrau Silhouette und die bodenlange voller Eleganz zu nehmen.
<G-vec00301-001-s370><attend.besuchen><en> If you are going to attend a wedding ceremony as the guest or the mother of the brides, you have to take good use of this dress's mermaid silhouette and the floor-length full of elegance.
<G-vec00301-001-s371><attend.besuchen><de> Zudem können Sie sich die Galerie mit zahlreichen Skulpturen, Gemälden und Fotos anschauen, die je nach Jahreszeit wechseln, sowie Ausstellungen besuchen, um die Geheimnisse heutiger Künstler zu entdecken.
<G-vec00301-001-s371><attend.besuchen><en> Lastly, experience the 'Art Gallery' packed with sculptures, paintings and photographs that change with the seasons, and attend exhibitions to discover or rediscover all the secrets of current artists.
<G-vec00301-001-s372><attend.besuchen><de> In Istrien und auf den Kvarner Inseln war es den Kroaten und Slowenen (mehrheitliche Bevölkerung), die Mittelschule auf der Muttersprache zu besuchen.
<G-vec00301-001-s372><attend.besuchen><en> In Istria and on Kvarner islands, the Croats and Slovenians (the majority peoples) were allowed to attend secondary school in their mother tongues.
<G-vec00301-001-s373><attend.besuchen><de> Konstrukteure/ -innen werden im Ausbildungsbetrieb ausgebildet und besuchen während maximal zwei Tagen pro Woche die Berufsschule.
<G-vec00301-001-s373><attend.besuchen><en> Designers are trained in the in-house training facility and attend vocational school for a maximum of two days a week.
<G-vec00301-001-s374><attend.besuchen><de> Apprentissage Blackjack sich von einem Glücksspiel Schule nicht unbedingt erforderlich ist, Casinos da zu keinem Zeitpunkt im Wesentlichen verlangen, dass Sie zu einem privaten Händler Schule zu besuchen.
<G-vec00301-001-s374><attend.besuchen><en> Learning blackjack dealing from a casino school is not compulsory, as casinos do not actually require you to attend a private dealer school.
<G-vec00301-001-s375><attend.besuchen><de> Das bedeutet, dass keine zusätzliche Zeit benötigt wird, um CDs in einem entspannten Zustand zu hören oder Therapien oder Hypnose-Sessions zu besuchen.
<G-vec00301-001-s375><attend.besuchen><en> MindZoom mingles in your own time. This means no extra time to listen to CDs on a relaxed state, or attend Therapies or Hypnosis sessions.
<G-vec00078-001-s019><come.besuchen><de> Kontakt Aktivitäten Besuchen Sie uns auf der Bauma 2019 in München.
<G-vec00078-001-s019><come.besuchen><en> Contact Activities Come and meet us at Bauma 2019 in Munich.
<G-vec00078-001-s020><come.besuchen><de> You suchen sollte, wie die Wahl der ersten Anwalt Rausfinden vielleicht das Gefühl, die Sie besuchen.
<G-vec00078-001-s020><come.besuchen><en> You should not want to pick the first lawyer you come across.
<G-vec00078-001-s021><come.besuchen><de> Besuchen Sie eine unserer Filialen oder kontaktieren Sie KBC Live.
<G-vec00078-001-s021><come.besuchen><en> Come and talk to us at one of our branches or contact KBC Live.
<G-vec00078-001-s022><come.besuchen><de> Besuchen Sie die Bike Library im Civic Park jederzeit zwischen 11 und 16 Uhr, um einen Workshop zum Reparieren eines Fahrrads zu erhalten.
<G-vec00078-001-s022><come.besuchen><en> Come to the Bike Library in Civic Park anytime 11am - 4pm for a workshop on fixing a bike.
<G-vec00078-001-s023><come.besuchen><de> 29:10 Denn so spricht der HERR: Wenn zu Babel siebenzig Jahre aus sind, so will ich euch besuchen und will mein gnädiges Wort über euch erwecken, daß ich euch wieder an diesen Ort bringe.
<G-vec00078-001-s023><come.besuchen><en> 29:10 For this is what the Lord has said: When seventy years are ended for Babylon, I will have pity on you and give effect to my good purpose for you, causing you to come back to this place.
<G-vec00078-001-s024><come.besuchen><de> Machen Sie eine Pause von den üblichen Sightseeing- und Shopping-Touren und besuchen Sie Play In The Clay mit einer 3-4-stündigen Einführung in die Töpferscheibe.
<G-vec00078-001-s024><come.besuchen><en> Take a break from the usual sightseeing and shopping and come Play In The Clay with a 3-4 hour introductory Pottery Wheel Class.
<G-vec00078-001-s025><come.besuchen><de> Produkte zu sehen und anzufassen und die Menschen hinter dem Produkt zu kennen ist wichtig - Besuchen Sie uns auf unseren Messeständen.
<G-vec00078-001-s025><come.besuchen><en> It’s so important to see and touch products and to get to know the people behind them – come and meet us at our next events.
<G-vec00078-001-s026><come.besuchen><de> Besuchen Sie uns bald und sich in dem Spaß und der Sonne.
<G-vec00078-001-s026><come.besuchen><en> Come see us soon and get into the fun and the sun.
<G-vec00078-001-s027><come.besuchen><de> Besuchen Sie uns an unserem Messestand D16 und machen Sie sich mit unseren Neuheiten vertraut.
<G-vec00078-001-s027><come.besuchen><en> Come see us at stall D16 and get to know our new products.
<G-vec00078-001-s028><come.besuchen><de> "Besuchen Sie die Ausstellung Motorräder 2014 und erfahren Sie alles über den ""Eisernen Pferde"" fühlen die echte Laufwerk und Durst nach Geschwindigkeit."
<G-vec00078-001-s028><come.besuchen><en> "Come to the exhibition Motorrader 2014 and learn all about the ""iron horses"" feel the real drive and thirst for speed."
<G-vec00078-001-s029><come.besuchen><de> Wenn Ihnen der Komfort der Kunden Ihres Dropshipping-Shops am Herzen liegt, dann besuchen Sie BigBuy und kaufen Sie unsere große Auswahl an Wohlfühl-Produkten wie die Big Tribe Snug Snug Decke mit Ärmeln zum Großhandelspreis.
<G-vec00078-001-s029><come.besuchen><en> If you're interested in the comfort of your dropshipping shop customers, come to BigBuy and purchase our range of wellbeing products, like the fun Big Tribe Snug Snug blanket with sleeves, at wholesale price.
<G-vec00078-001-s030><come.besuchen><de> Besuchen Sie uns also und spielen Sie den Online Spielautomaten Innocence or Temptation.
<G-vec00078-001-s030><come.besuchen><en> So come join us for a game of Innocence or Temptation online slots.
<G-vec00078-001-s031><come.besuchen><de> Für David wird es ein neuer Eurolanche Rekord, da er bereits das fünfte mal die beste NHL Stadt der USA besuchen wird.
<G-vec00078-001-s031><come.besuchen><en> It will be record-breaking appearance for David in Denver, as he will come back to the best NHL town in the USA for the fifth time.
<G-vec00078-001-s032><come.besuchen><de> Die Isolotto della Paolina verdankt ihren Ruhm und ihren Nahmen der Schwester von Napoleon Bonaparte (Paolina Borghese), die es während des Exils ihres Bruders liebte, diesen Ort zum sonnen und schwimmen gehen zu besuchen.
<G-vec00078-001-s032><come.besuchen><en> The islet of Paolina owes its fame and its name to the sister of Napoleon Bonaparte (Paolina Borghese), who during the period of exile of his brother Emperor, liked to come to this place to sunbathe and swim.
<G-vec00078-001-s033><come.besuchen><de> Besuchen Sie uns noch, wir warten auf Sie!Bitte beachten Sie: Obwohl wir jeden Versuch, dies zu tun zu machen, knnen wir nicht garantieren, dass jeder in Ihrer Partei in der Lage, im selben Raum bleiben.
<G-vec00078-001-s033><come.besuchen><en> Come check us out, we're waiting to meet you!Please Note: Though we make every attempt to do so, we cannot guarantee that everyone in your party will be able to stay in the same room.
<G-vec00078-001-s034><come.besuchen><de> “Wir besuchen die Messe, um über aktuelle Snack-Trends zu informieren und Informationen zwischen Snack-Herstellern und -anbietern auszutauschen“, erklärt Charlotte Huggins, Business Development Director bei Symrise.
<G-vec00078-001-s034><come.besuchen><en> “We have come to the exhibition to share our information on the latest Snack trends and to exchange information between snack producers and suppliers”, says Charlotte Huggins, Business Development Director at Symrise.
<G-vec00078-001-s035><come.besuchen><de> Besuchen Sie diese Stadt in Andalusien und machen Sie Ihre geschäftliche Sitzung zu etwas Unvergesslichem.
<G-vec00078-001-s035><come.besuchen><en> Come to this city in Andalusia and make your business meeting into something unforgettable.
<G-vec00078-001-s036><come.besuchen><de> Besuchen Sie die außergewöhnliche überdachte zweigeschossige Kartrennbahn in Olomouc.
<G-vec00078-001-s036><come.besuchen><en> Come and try out this unique two-story indoor kart racing track in Olomouc.
<G-vec00078-001-s037><come.besuchen><de> Wenn Sie verursachen in diesem Bereich setzen, achten Sie darauf das Honey Valley besuchen, vertrauen Sie, werden Sie nicht bereuen.
<G-vec00078-001-s037><come.besuchen><en> If you end up near this area, you should certainly come to Honeymoon Valley; trust us - you will not regret it.
<G-vec00042-001-s376><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Beijing, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s376><attend.besuchen><en> Attend our monthly events and activities for Beijing expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s377><attend.besuchen><de> Genießen Sie Hamburg bei Nacht auf der berühmten Reeperbahn oder besuchen Sie eines der Musicals, Festivals oder Events, welche über das ganze Jahr hinweg stattfinden.
<G-vec00042-001-s377><attend.besuchen><en> "Enjoy Hamburg by night on the famous ""Reeperbahn"" street or attend to one of the musicals, festivals or events taking place throughout the year."
<G-vec00042-001-s378><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Birmingham, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s378><attend.besuchen><en> Attend our monthly events and activities for Birmingham expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s379><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Perth, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s379><attend.besuchen><en> Attend our monthly events and activities for Perth expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s380><attend.besuchen><de> Besuchen Sie ein kompaktes Update Training und sparen dadurch wertvolle Arbeitszeit.
<G-vec00042-001-s380><attend.besuchen><en> Attend a brief update training course and save valuable working time.
<G-vec00042-001-s381><attend.besuchen><de> Bewundern Sie einen Sonnenuntergang mit einer Austernverkostung auf der Insel Fort Brescou, besuchen Sie ein Feuerwerk oder entdecken Sie unser Gebiet während einer geführten Wanderung...
<G-vec00042-001-s381><attend.besuchen><en> Come admire a sunset with oyster tasting on the island of Fort Brescou, attend a fireworks display or discover our territory during a guided walk...
<G-vec00042-001-s382><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Jerusalem, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s382><attend.besuchen><en> Attend our monthly events and activities for Jerusalem expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s383><attend.besuchen><de> Besuchen Sie eine Winter-Soiree in unserer Judy Mosaik zusammengesetzt Nerz Bomberjacke in Whiskey Ombre für Frauen aus Pelz Hut Welt.
<G-vec00042-001-s383><attend.besuchen><en> Attend a winter soiree in our Judy Mosaic Pieced Mink Bomber Jacket in Whiskey Ombre for women from Fur Hat World.
<G-vec00042-001-s384><attend.besuchen><de> Besuchen Sie die productronica 2019 und profitieren von einem einmaligen Umfeld.
<G-vec00042-001-s384><attend.besuchen><en> Attend productronica 2019 and profit from its unique atmosphere.
<G-vec00042-001-s385><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Raleigh, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s385><attend.besuchen><en> Attend our monthly events and activities for Raleigh expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s386><attend.besuchen><de> Besuchen sie das zentrum bild, souks 211, ecke arauco, ovalle.
<G-vec00042-001-s386><attend.besuchen><en> Attend the center image, souks 211, corner arauco, ovalle.
<G-vec00042-001-s387><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Kuala Lumpur, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s387><attend.besuchen><en> Attend our monthly events and activities for Kuala Lumpur expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s388><attend.besuchen><de> Besuchen Sie dann die extravagante Mittagszeremonie, um zu sehen, wie die Anhänger von Cao Dai ihre tägliche Messe abhalten.
<G-vec00042-001-s388><attend.besuchen><en> Then attend the extravagant midday ceremony to witness how the Cao Dai followers conduct daily mass.
<G-vec00042-001-s389><attend.besuchen><de> Besuchen Sie einen von ihnen und entdecken Sie Maribor und seine Umgebung aus einem ganz anderen Gesichtspunkt.
<G-vec00042-001-s389><attend.besuchen><en> Attend one of them and discover Maribor and its surroundings from a completely different angle.
<G-vec00042-001-s390><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Genoa, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s390><attend.besuchen><en> Attend our monthly events and activities for Genoa expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s391><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Groningen, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s391><attend.besuchen><en> Attend our monthly events and activities for Groningen expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s392><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Blantyre, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s392><attend.besuchen><en> Attend our monthly events and activities for Blantyre expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s393><attend.besuchen><de> "Genießen Sie die ""Route der weißen Dörfer"" (Ronda, 120 Km) oder besuchen Sie Malaga (230 Km) oder die Alhambra in Granada (320 Km)."
<G-vec00042-001-s393><attend.besuchen><en> "Enjoy the "" route of the white villages "" (Ronda, 120 kms) or attend Malaga (230 kms) or Alhambra in Granada (320 kms)."
<G-vec00042-001-s394><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Liverpool, um Gleichgesinnte vor Ort zu treffen.
<G-vec00042-001-s394><attend.besuchen><en> Attend our monthly events and activities for Liverpool expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s376><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Beijing, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s376><attend.besuchen><en> Attend our monthly events and activities for Beijing expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s377><attend.besuchen><de> Genießen Sie Hamburg bei Nacht auf der berühmten Reeperbahn oder besuchen Sie eines der Musicals, Festivals oder Events, welche über das ganze Jahr hinweg stattfinden.
<G-vec00301-001-s377><attend.besuchen><en> "Enjoy Hamburg by night on the famous ""Reeperbahn"" street or attend to one of the musicals, festivals or events taking place throughout the year."
<G-vec00301-001-s378><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Birmingham, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s378><attend.besuchen><en> Attend our monthly events and activities for Birmingham expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s379><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Perth, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s379><attend.besuchen><en> Attend our monthly events and activities for Perth expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s380><attend.besuchen><de> Besuchen Sie ein kompaktes Update Training und sparen dadurch wertvolle Arbeitszeit.
<G-vec00301-001-s380><attend.besuchen><en> Attend a brief update training course and save valuable working time.
<G-vec00301-001-s381><attend.besuchen><de> Bewundern Sie einen Sonnenuntergang mit einer Austernverkostung auf der Insel Fort Brescou, besuchen Sie ein Feuerwerk oder entdecken Sie unser Gebiet während einer geführten Wanderung...
<G-vec00301-001-s381><attend.besuchen><en> Come admire a sunset with oyster tasting on the island of Fort Brescou, attend a fireworks display or discover our territory during a guided walk...
<G-vec00301-001-s382><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Jerusalem, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s382><attend.besuchen><en> Attend our monthly events and activities for Jerusalem expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s383><attend.besuchen><de> Besuchen Sie eine Winter-Soiree in unserer Judy Mosaik zusammengesetzt Nerz Bomberjacke in Whiskey Ombre für Frauen aus Pelz Hut Welt.
<G-vec00301-001-s383><attend.besuchen><en> Attend a winter soiree in our Judy Mosaic Pieced Mink Bomber Jacket in Whiskey Ombre for women from Fur Hat World.
<G-vec00301-001-s384><attend.besuchen><de> Besuchen Sie die productronica 2019 und profitieren von einem einmaligen Umfeld.
<G-vec00301-001-s384><attend.besuchen><en> Attend productronica 2019 and profit from its unique atmosphere.
<G-vec00301-001-s385><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Raleigh, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s385><attend.besuchen><en> Attend our monthly events and activities for Raleigh expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s386><attend.besuchen><de> Besuchen sie das zentrum bild, souks 211, ecke arauco, ovalle.
<G-vec00301-001-s386><attend.besuchen><en> Attend the center image, souks 211, corner arauco, ovalle.
<G-vec00301-001-s387><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Kuala Lumpur, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s387><attend.besuchen><en> Attend our monthly events and activities for Kuala Lumpur expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s388><attend.besuchen><de> Besuchen Sie dann die extravagante Mittagszeremonie, um zu sehen, wie die Anhänger von Cao Dai ihre tägliche Messe abhalten.
<G-vec00301-001-s388><attend.besuchen><en> Then attend the extravagant midday ceremony to witness how the Cao Dai followers conduct daily mass.
<G-vec00301-001-s389><attend.besuchen><de> Besuchen Sie einen von ihnen und entdecken Sie Maribor und seine Umgebung aus einem ganz anderen Gesichtspunkt.
<G-vec00301-001-s389><attend.besuchen><en> Attend one of them and discover Maribor and its surroundings from a completely different angle.
<G-vec00301-001-s390><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Genoa, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s390><attend.besuchen><en> Attend our monthly events and activities for Genoa expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s391><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Groningen, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s391><attend.besuchen><en> Attend our monthly events and activities for Groningen expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s392><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Blantyre, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s392><attend.besuchen><en> Attend our monthly events and activities for Blantyre expatriates to get to know like-minded expatriates in real life.
<G-vec00301-001-s393><attend.besuchen><de> "Genießen Sie die ""Route der weißen Dörfer"" (Ronda, 120 Km) oder besuchen Sie Malaga (230 Km) oder die Alhambra in Granada (320 Km)."
<G-vec00301-001-s393><attend.besuchen><en> "Enjoy the "" route of the white villages "" (Ronda, 120 kms) or attend Malaga (230 kms) or Alhambra in Granada (320 kms)."
<G-vec00301-001-s394><attend.besuchen><de> Besuchen Sie unsere regelmäßigen Events und Aktivitäten für Expats in Liverpool, um Gleichgesinnte vor Ort zu treffen.
<G-vec00301-001-s394><attend.besuchen><en> Attend our monthly events and activities for Liverpool expatriates to get to know like-minded expatriates in real life.
<G-vec00042-001-s395><attend.besuchen><de> "Van Doesburg reagiert darauf, indem er in seinem eigenen Atelier in Weimar einen Kurs über ""De Stijl"" organisiert, der von vielen Bauhaus/Studenten besucht wird.... nach Paris Danach verlässt Van Doesburg Weimar und zieht Richtung Paris."
<G-vec00042-001-s395><attend.besuchen><en> In response, Van Doesburg organizes a course on De Stijl in his own studio in Weimar, which many Bauhaus students attend. … to Paris After this, Van Doesburg leaves for Paris.
<G-vec00042-001-s396><attend.besuchen><de> Kunstliebhaber, jedes Jahr Space Rohan bietet farbenfrohe kulturelle Saison, während die euch gegeben, verschiedene Theateraufführungen besucht werden.
<G-vec00042-001-s396><attend.besuchen><en> Art lovers, each year, Space Rohan offers colorful cultural season, during which you will be given to attend various theatrical performances.
<G-vec00042-001-s397><attend.besuchen><de> In der Türkei finanziert Malteser International eine Schule im Distrikt Killis, an der Grenze zu Syrien, die von 1.350 syrischen Kindern besucht wird.
<G-vec00042-001-s397><attend.besuchen><en> In Turkey, Malteser International is also supporting a school in the border district of Kilis, at the Syrian border, where 1,350 Syrian children currently attend classes.
<G-vec00042-001-s398><attend.besuchen><de> Es gibt weit weniger Privatschulen als öffentliche Schulen in Bulgarien und nur ein kleiner Prozentsatz der Schüler besucht sie.
<G-vec00042-001-s398><attend.besuchen><en> There are far less private schools than public schools in Bulgaria and only a small percentage of students attend them.
<G-vec00042-001-s399><attend.besuchen><de> Das zehnminütige Programm konnte an drei Abenden im Mai 2016 kostenlos besucht werden.
<G-vec00042-001-s399><attend.besuchen><en> The special ten minute programme was free to attend and took place over three nights in May 2016.
<G-vec00042-001-s400><attend.besuchen><de> André Rieu polo shirt Wer regelmäßig ein André Rieu-Konzert besucht, dem sind sie bestimmt schon aufgefallen - die vielen hilfreichen Mitarbeiter, die hinter den Kulissen nichts dem Zufall überlassen.
<G-vec00042-001-s400><attend.besuchen><en> André Rieu polo shirt If you regularly attend André's concerts, you will certainly have noticed the staff members who make sure that everything is in order behind the scenes.
<G-vec00042-001-s401><attend.besuchen><de> Er fügte jedoch hinzu, dass die Einreise in das Land gründlich geprüft würde, ob sie bei ihrem vorherigen Aufenthalt nicht gegen die ukrainischen Rechtsvorschriften verstoßen hätten, wenn sie nicht das von Russland besetzte Gebiet besucht hätten.
<G-vec00042-001-s401><attend.besuchen><en> He added, however, that those entering the country would be thoroughly examined whether they had not violated the Ukrainian legislation at the time of their previous stay if they did not attend the territory temporarily occupied by Russia.
<G-vec00042-001-s402><attend.besuchen><de> Die Vielfalt der Lehrinhalte, die euch in den Universitäten und Studienzentren, die ihr besucht, angeboten werden, will dazu beitragen, auf diese große und dringliche kulturelle und geistliche Herausforderung zu antworten.
<G-vec00042-001-s402><attend.besuchen><en> The multiplicity of the subjects taught at the Athenaeums and Study Centres that you attend intends to respond to this vast and urgent cultural and spiritual challenge.
<G-vec00042-001-s403><attend.besuchen><de> Natürlich gibt es Vorgaben, welche Kurse im Verlauf eines Studiums besucht werden müssen.
<G-vec00042-001-s403><attend.besuchen><en> Of course there are requirements as to which courses you have to attend during a degree programme.
<G-vec00042-001-s404><attend.besuchen><de> Allgemein scheint es zu sein, daß diese Kinder den größten Teil des Sonntags im Bette zubringen, um sich einigermaßen von der Anstrengung der Woche zu erholen; Kirche und Schule werden nur von wenigen besucht, und bei diesen klagen die Lehrer über große Schläfrigkeit und Abstumpfung bei aller Lernbegierde.
<G-vec00042-001-s404><attend.besuchen><en> Generally, it seems that these children spend most of the Sunday in bed to recover from the week's exertion; only a few attend church and school, and teachers complain about drowsiness and dullness despite all the curiosity to learn. The same thing happens with older girls and women.
<G-vec00042-001-s405><attend.besuchen><de> An allen anderen polnischen Volksschulen, die auch von den deutschen Schulkindern besucht werden mussten, war die Erteilung des evangelischen Religionsunterrichts die einzige Möglichkeit, die deutschen Kinder in ihrer Muttersprache notdürftig zu unterweisen.
<G-vec00042-001-s405><attend.besuchen><en> In all other Polish elementary schools, which the German school children necessarily also had to attend, Protestant religious education classes were the only opportunity to give the German children any instruction in their mother tongue.
<G-vec00042-001-s406><attend.besuchen><de> Rund 25% der Kinder in ländlichen Gebieten weniger entwickelter Länder haben die Schule 2005/06 nicht besucht.
<G-vec00042-001-s406><attend.besuchen><en> Some 25% of children in rural areas of the less developed world did not attend school in 2005/2006.
<G-vec00042-001-s407><attend.besuchen><de> Wer dieses Jahr nur eine Veranstaltung besucht, der wird die IDEA auf keinen Fall verpassen wollen.
<G-vec00042-001-s407><attend.besuchen><en> If there's only one event to attend this year, it is this one so you don't want to miss IDEA.
<G-vec00042-001-s408><attend.besuchen><de> Am Silvesterabend lädt man Gäste zu sich nach Hause ein, trifft sich in Restaurants, besucht Tanzveranstaltungen und genießt beschwingende Konzerte.
<G-vec00042-001-s408><attend.besuchen><en> On New Year's Eve, people host guests at home, meet up in restaurants, attend special gala dances and enjoy lively concerts.
<G-vec00042-001-s409><attend.besuchen><de> In der gesamten Zeit der Ausbildung besucht man den Unterricht an der Technischen Berufsschule 1 in Bochum.
<G-vec00042-001-s409><attend.besuchen><en> Throughout the training you attend classes at the Technischen Berufsschule [technical vocational college] 1 in Bochum.
<G-vec00042-001-s410><attend.besuchen><de> „Ich habe keine höhere Schule besucht, aber der Große Geist gab mir, was ich in keinem Klassenzimmer hätte lernen können (…).
<G-vec00042-001-s410><attend.besuchen><en> „I did not attend a higher scholl but the Great Spirit gave to me what I would not have learned in any class room (…).
<G-vec00042-001-s411><attend.besuchen><de> Es sei hier lediglich gesagt, besucht das Camp und findet es heraus.
<G-vec00042-001-s411><attend.besuchen><en> Suffice it to say, attend the camp and find out.
<G-vec00042-001-s412><attend.besuchen><de> Als Au Pair lebt man in einer japanischen Familie, betreut deren Kinder und besucht Sprachkurse.
<G-vec00042-001-s412><attend.besuchen><en> As an Au Pair you live with a Japanese family, tend to their children and attend language courses.
<G-vec00042-001-s413><attend.besuchen><de> Diejenigen, die die WSIS-Gipfel in Genf und Tunis besucht haben, erzählen, dass sie als wichtigsten und nachhaltigsten Vorteil die Möglichkeiten zum Vernetzen ansahen, die hier geboten wurden.
<G-vec00042-001-s413><attend.besuchen><en> Those who did attend the WSIS Summits in Geneva and Tunis indicated that the major and lasting benefit that they saw arising from their attendance was the networking opportunities that it afforded.
<G-vec00301-001-s395><attend.besuchen><de> "Van Doesburg reagiert darauf, indem er in seinem eigenen Atelier in Weimar einen Kurs über ""De Stijl"" organisiert, der von vielen Bauhaus/Studenten besucht wird.... nach Paris Danach verlässt Van Doesburg Weimar und zieht Richtung Paris."
<G-vec00301-001-s395><attend.besuchen><en> In response, Van Doesburg organizes a course on De Stijl in his own studio in Weimar, which many Bauhaus students attend. … to Paris After this, Van Doesburg leaves for Paris.
<G-vec00301-001-s396><attend.besuchen><de> Kunstliebhaber, jedes Jahr Space Rohan bietet farbenfrohe kulturelle Saison, während die euch gegeben, verschiedene Theateraufführungen besucht werden.
<G-vec00301-001-s396><attend.besuchen><en> Art lovers, each year, Space Rohan offers colorful cultural season, during which you will be given to attend various theatrical performances.
<G-vec00301-001-s397><attend.besuchen><de> In der Türkei finanziert Malteser International eine Schule im Distrikt Killis, an der Grenze zu Syrien, die von 1.350 syrischen Kindern besucht wird.
<G-vec00301-001-s397><attend.besuchen><en> In Turkey, Malteser International is also supporting a school in the border district of Kilis, at the Syrian border, where 1,350 Syrian children currently attend classes.
<G-vec00301-001-s398><attend.besuchen><de> Es gibt weit weniger Privatschulen als öffentliche Schulen in Bulgarien und nur ein kleiner Prozentsatz der Schüler besucht sie.
<G-vec00301-001-s398><attend.besuchen><en> There are far less private schools than public schools in Bulgaria and only a small percentage of students attend them.
<G-vec00301-001-s399><attend.besuchen><de> Das zehnminütige Programm konnte an drei Abenden im Mai 2016 kostenlos besucht werden.
<G-vec00301-001-s399><attend.besuchen><en> The special ten minute programme was free to attend and took place over three nights in May 2016.
<G-vec00301-001-s400><attend.besuchen><de> André Rieu polo shirt Wer regelmäßig ein André Rieu-Konzert besucht, dem sind sie bestimmt schon aufgefallen - die vielen hilfreichen Mitarbeiter, die hinter den Kulissen nichts dem Zufall überlassen.
<G-vec00301-001-s400><attend.besuchen><en> André Rieu polo shirt If you regularly attend André's concerts, you will certainly have noticed the staff members who make sure that everything is in order behind the scenes.
<G-vec00301-001-s401><attend.besuchen><de> Er fügte jedoch hinzu, dass die Einreise in das Land gründlich geprüft würde, ob sie bei ihrem vorherigen Aufenthalt nicht gegen die ukrainischen Rechtsvorschriften verstoßen hätten, wenn sie nicht das von Russland besetzte Gebiet besucht hätten.
<G-vec00301-001-s401><attend.besuchen><en> He added, however, that those entering the country would be thoroughly examined whether they had not violated the Ukrainian legislation at the time of their previous stay if they did not attend the territory temporarily occupied by Russia.
<G-vec00301-001-s402><attend.besuchen><de> Die Vielfalt der Lehrinhalte, die euch in den Universitäten und Studienzentren, die ihr besucht, angeboten werden, will dazu beitragen, auf diese große und dringliche kulturelle und geistliche Herausforderung zu antworten.
<G-vec00301-001-s402><attend.besuchen><en> The multiplicity of the subjects taught at the Athenaeums and Study Centres that you attend intends to respond to this vast and urgent cultural and spiritual challenge.
<G-vec00301-001-s403><attend.besuchen><de> Natürlich gibt es Vorgaben, welche Kurse im Verlauf eines Studiums besucht werden müssen.
<G-vec00301-001-s403><attend.besuchen><en> Of course there are requirements as to which courses you have to attend during a degree programme.
<G-vec00301-001-s404><attend.besuchen><de> Allgemein scheint es zu sein, daß diese Kinder den größten Teil des Sonntags im Bette zubringen, um sich einigermaßen von der Anstrengung der Woche zu erholen; Kirche und Schule werden nur von wenigen besucht, und bei diesen klagen die Lehrer über große Schläfrigkeit und Abstumpfung bei aller Lernbegierde.
<G-vec00301-001-s404><attend.besuchen><en> Generally, it seems that these children spend most of the Sunday in bed to recover from the week's exertion; only a few attend church and school, and teachers complain about drowsiness and dullness despite all the curiosity to learn. The same thing happens with older girls and women.
<G-vec00301-001-s405><attend.besuchen><de> An allen anderen polnischen Volksschulen, die auch von den deutschen Schulkindern besucht werden mussten, war die Erteilung des evangelischen Religionsunterrichts die einzige Möglichkeit, die deutschen Kinder in ihrer Muttersprache notdürftig zu unterweisen.
<G-vec00301-001-s405><attend.besuchen><en> In all other Polish elementary schools, which the German school children necessarily also had to attend, Protestant religious education classes were the only opportunity to give the German children any instruction in their mother tongue.
<G-vec00301-001-s406><attend.besuchen><de> Rund 25% der Kinder in ländlichen Gebieten weniger entwickelter Länder haben die Schule 2005/06 nicht besucht.
<G-vec00301-001-s406><attend.besuchen><en> Some 25% of children in rural areas of the less developed world did not attend school in 2005/2006.
<G-vec00301-001-s407><attend.besuchen><de> Wer dieses Jahr nur eine Veranstaltung besucht, der wird die IDEA auf keinen Fall verpassen wollen.
<G-vec00301-001-s407><attend.besuchen><en> If there's only one event to attend this year, it is this one so you don't want to miss IDEA.
<G-vec00301-001-s408><attend.besuchen><de> Am Silvesterabend lädt man Gäste zu sich nach Hause ein, trifft sich in Restaurants, besucht Tanzveranstaltungen und genießt beschwingende Konzerte.
<G-vec00301-001-s408><attend.besuchen><en> On New Year's Eve, people host guests at home, meet up in restaurants, attend special gala dances and enjoy lively concerts.
<G-vec00301-001-s409><attend.besuchen><de> In der gesamten Zeit der Ausbildung besucht man den Unterricht an der Technischen Berufsschule 1 in Bochum.
<G-vec00301-001-s409><attend.besuchen><en> Throughout the training you attend classes at the Technischen Berufsschule [technical vocational college] 1 in Bochum.
<G-vec00301-001-s410><attend.besuchen><de> „Ich habe keine höhere Schule besucht, aber der Große Geist gab mir, was ich in keinem Klassenzimmer hätte lernen können (…).
<G-vec00301-001-s410><attend.besuchen><en> „I did not attend a higher scholl but the Great Spirit gave to me what I would not have learned in any class room (…).
<G-vec00301-001-s411><attend.besuchen><de> Es sei hier lediglich gesagt, besucht das Camp und findet es heraus.
<G-vec00301-001-s411><attend.besuchen><en> Suffice it to say, attend the camp and find out.
<G-vec00301-001-s412><attend.besuchen><de> Als Au Pair lebt man in einer japanischen Familie, betreut deren Kinder und besucht Sprachkurse.
<G-vec00301-001-s412><attend.besuchen><en> As an Au Pair you live with a Japanese family, tend to their children and attend language courses.
<G-vec00301-001-s413><attend.besuchen><de> Diejenigen, die die WSIS-Gipfel in Genf und Tunis besucht haben, erzählen, dass sie als wichtigsten und nachhaltigsten Vorteil die Möglichkeiten zum Vernetzen ansahen, die hier geboten wurden.
<G-vec00301-001-s413><attend.besuchen><en> Those who did attend the WSIS Summits in Geneva and Tunis indicated that the major and lasting benefit that they saw arising from their attendance was the networking opportunities that it afforded.
