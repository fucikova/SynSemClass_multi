<G-vec00078-001-s038><clear.deaktivieren><de> Wir haben von Deaktivieren Sie Briefmarken für scrapbooking verbesserte Qualitätskontrolle, jede Export qualifiziertes Produkt zu gewährleisten.
<G-vec00078-001-s038><clear.deaktivieren><en> We have improved quality control processes of clear stamps for scrapbooking to ensure each export qualified product.
<G-vec00078-001-s039><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr um sicherzustellen, dass Ihre physischen Körper viel mehr Fettgewebe deaktivieren kann.
<G-vec00078-001-s039><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body can clear more fat.
<G-vec00078-001-s040><clear.deaktivieren><de> Aktivieren oder deaktivieren Sie das Kontrollkästchen Internationale Einstellungen verwenden.
<G-vec00078-001-s040><clear.deaktivieren><en> Select or clear the Use international settings check box.
<G-vec00078-001-s041><clear.deaktivieren><de> Deaktivieren Sie dann die Wand Pinsel und mit Wasser angefeuchtet.
<G-vec00078-001-s041><clear.deaktivieren><en> Then clear the wall brush and moistened with water.
<G-vec00078-001-s042><clear.deaktivieren><de> Deaktivieren Sie die Optionen Automatisch Datum & Uhrzeit und Automatische Zeitzone und stellen Sie anschließend die Zeitzone, das Datum und die Uhrzeit ein.
<G-vec00078-001-s042><clear.deaktivieren><en> Clear Automatic date & time and Automatic time zone, and then set the time zone, date, and time as required.
<G-vec00078-001-s043><clear.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Ressourcenpartner aktivieren das Kontrollkästchen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00078-001-s043><clear.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00078-001-s044><clear.deaktivieren><de> Bobble Shooter - Deaktivieren Sie alle Blasen vom Spielfeld.
<G-vec00078-001-s044><clear.deaktivieren><en> Bobble Shooter - Clear all the bubbles from the board .
<G-vec00078-001-s045><clear.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Diesen Ressourcenpartner aktivieren das Kontrollkästchen Diesen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00078-001-s045><clear.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00078-001-s046><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: dieser Stoff hilft Ihre metabolische Preis um sicherzustellen, dass Ihre physischen Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00078-001-s046><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This active ingredient really helps up your metabolic price so that your body could clear much more fat deposits.
<G-vec00078-001-s047><clear.deaktivieren><de> Deaktivieren Sie diese Option, um das Ausführen der Webdiensterweiterungen auf dem Server nicht zuzulassen.
<G-vec00078-001-s047><clear.deaktivieren><en> Clear this option to prohibit Web service extensions from running on your Web server.
<G-vec00078-001-s048><clear.deaktivieren><de> um zu erkennen, subtil, zu halten deaktivieren Sie das Gehirn, lesen Sie die Gedanken derer, die daran denken, Sie, sehr hilfsbereit und gute Hilfe Atemübungen, die verschiedenen Nasenlöcher zu erzeugen, kann es getan sitzen oder stehen vor dem offenen Fenster, in einem gut werdenbelüfteten Raum.
<G-vec00078-001-s048><clear.deaktivieren><en> order to detect subtle, keep clear the brain, read the thoughts of those who are thinking of you, very helpful and good help breathing exercises that produce different nostrils, it can be done sitting or standing in front of the open window, in a wellventilated room.
<G-vec00078-001-s049><clear.deaktivieren><de> Deaktivieren Sie die Äpfel aus Samen und Rinde, in Streifen geschnitten.
<G-vec00078-001-s049><clear.deaktivieren><en> Clear the apples from seeds and rind, cut into strips.
<G-vec00078-001-s050><clear.deaktivieren><de> Deaktivieren Sie alle Optionen.
<G-vec00078-001-s050><clear.deaktivieren><en> Clear all options.
<G-vec00078-001-s051><clear.deaktivieren><de> Aktivieren oder deaktivieren Sie Anzeigen von abgelehnten Netzwerken für Benutzer zulassen, um zu ermöglichen oder zu verhindern, dass Drahtlosnetzwerke im Dialogfeld Verbindung mit einem Netzwerk herstellen angezeigt werden.
<G-vec00078-001-s051><clear.deaktivieren><en> To enable or prevent wireless networks from displaying in the Connect to a network dialog box, either select or clear Allow user to view denied networks.
<G-vec00078-001-s052><clear.deaktivieren><de> Wenn der See steigt ein anderer 2 oder 3 Füße, Sonnenlicht wird nicht an die Wurzeln der Pflanzen, und sie werden sterben, und deaktivieren Sie die Oberfläche.
<G-vec00078-001-s052><clear.deaktivieren><en> When the lake level rises another 2 or 3 feet, sunlight won’t reach the roots of plants and they will die and clear out the surface.
<G-vec00078-001-s053><clear.deaktivieren><de> Wenn Sie jemals benötigt wird, um Gewalt zu stoppen, oder deaktivieren Sie die Daten / Cache aus einer App, Dies ist eine willkommene Ergänzung, da es viel zu finden Diese Seite macht, viel einfacher.
<G-vec00078-001-s053><clear.deaktivieren><en> If you’ve ever needed to force stop, or clear the data/cache from an app, this is a welcome addition as it makes finding this page much, much easier.
<G-vec00078-001-s054><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00078-001-s054><clear.deaktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00078-001-s055><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr, damit Ihr Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00078-001-s055><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body could clear much more fat deposits.
<G-vec00078-001-s056><clear.deaktivieren><de> Deaktivieren Sie in der Schlüsseltabelle das Kontrollkästchen neben Abbild, um die gesamte Filterung zu beenden.
<G-vec00078-001-s056><clear.deaktivieren><en> To stop filtering altogether, in the key table, clear the check box next to Image.
<G-vec00301-001-s038><clear_up.deaktivieren><de> Wir haben von Deaktivieren Sie Briefmarken für scrapbooking verbesserte Qualitätskontrolle, jede Export qualifiziertes Produkt zu gewährleisten.
<G-vec00301-001-s038><clear_up.deaktivieren><en> We have improved quality control processes of clear stamps for scrapbooking to ensure each export qualified product.
<G-vec00301-001-s039><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr um sicherzustellen, dass Ihre physischen Körper viel mehr Fettgewebe deaktivieren kann.
<G-vec00301-001-s039><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body can clear more fat.
<G-vec00301-001-s040><clear_up.deaktivieren><de> Aktivieren oder deaktivieren Sie das Kontrollkästchen Internationale Einstellungen verwenden.
<G-vec00301-001-s040><clear_up.deaktivieren><en> Select or clear the Use international settings check box.
<G-vec00301-001-s041><clear_up.deaktivieren><de> Deaktivieren Sie dann die Wand Pinsel und mit Wasser angefeuchtet.
<G-vec00301-001-s041><clear_up.deaktivieren><en> Then clear the wall brush and moistened with water.
<G-vec00301-001-s042><clear_up.deaktivieren><de> Deaktivieren Sie die Optionen Automatisch Datum & Uhrzeit und Automatische Zeitzone und stellen Sie anschließend die Zeitzone, das Datum und die Uhrzeit ein.
<G-vec00301-001-s042><clear_up.deaktivieren><en> Clear Automatic date & time and Automatic time zone, and then set the time zone, date, and time as required.
<G-vec00301-001-s043><clear_up.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Ressourcenpartner aktivieren das Kontrollkästchen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00301-001-s043><clear_up.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00301-001-s044><clear_up.deaktivieren><de> Bobble Shooter - Deaktivieren Sie alle Blasen vom Spielfeld.
<G-vec00301-001-s044><clear_up.deaktivieren><en> Bobble Shooter - Clear all the bubbles from the board .
<G-vec00301-001-s045><clear_up.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Diesen Ressourcenpartner aktivieren das Kontrollkästchen Diesen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00301-001-s045><clear_up.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00301-001-s046><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: dieser Stoff hilft Ihre metabolische Preis um sicherzustellen, dass Ihre physischen Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00301-001-s046><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This active ingredient really helps up your metabolic price so that your body could clear much more fat deposits.
<G-vec00301-001-s047><clear_up.deaktivieren><de> Deaktivieren Sie diese Option, um das Ausführen der Webdiensterweiterungen auf dem Server nicht zuzulassen.
<G-vec00301-001-s047><clear_up.deaktivieren><en> Clear this option to prohibit Web service extensions from running on your Web server.
<G-vec00301-001-s048><clear_up.deaktivieren><de> um zu erkennen, subtil, zu halten deaktivieren Sie das Gehirn, lesen Sie die Gedanken derer, die daran denken, Sie, sehr hilfsbereit und gute Hilfe Atemübungen, die verschiedenen Nasenlöcher zu erzeugen, kann es getan sitzen oder stehen vor dem offenen Fenster, in einem gut werdenbelüfteten Raum.
<G-vec00301-001-s048><clear_up.deaktivieren><en> order to detect subtle, keep clear the brain, read the thoughts of those who are thinking of you, very helpful and good help breathing exercises that produce different nostrils, it can be done sitting or standing in front of the open window, in a wellventilated room.
<G-vec00301-001-s049><clear_up.deaktivieren><de> Deaktivieren Sie die Äpfel aus Samen und Rinde, in Streifen geschnitten.
<G-vec00301-001-s049><clear_up.deaktivieren><en> Clear the apples from seeds and rind, cut into strips.
<G-vec00301-001-s050><clear_up.deaktivieren><de> Deaktivieren Sie alle Optionen.
<G-vec00301-001-s050><clear_up.deaktivieren><en> Clear all options.
<G-vec00301-001-s051><clear_up.deaktivieren><de> Aktivieren oder deaktivieren Sie Anzeigen von abgelehnten Netzwerken für Benutzer zulassen, um zu ermöglichen oder zu verhindern, dass Drahtlosnetzwerke im Dialogfeld Verbindung mit einem Netzwerk herstellen angezeigt werden.
<G-vec00301-001-s051><clear_up.deaktivieren><en> To enable or prevent wireless networks from displaying in the Connect to a network dialog box, either select or clear Allow user to view denied networks.
<G-vec00301-001-s052><clear_up.deaktivieren><de> Wenn der See steigt ein anderer 2 oder 3 Füße, Sonnenlicht wird nicht an die Wurzeln der Pflanzen, und sie werden sterben, und deaktivieren Sie die Oberfläche.
<G-vec00301-001-s052><clear_up.deaktivieren><en> When the lake level rises another 2 or 3 feet, sunlight won’t reach the roots of plants and they will die and clear out the surface.
<G-vec00301-001-s053><clear_up.deaktivieren><de> Wenn Sie jemals benötigt wird, um Gewalt zu stoppen, oder deaktivieren Sie die Daten / Cache aus einer App, Dies ist eine willkommene Ergänzung, da es viel zu finden Diese Seite macht, viel einfacher.
<G-vec00301-001-s053><clear_up.deaktivieren><en> If you’ve ever needed to force stop, or clear the data/cache from an app, this is a welcome addition as it makes finding this page much, much easier.
<G-vec00301-001-s054><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00301-001-s054><clear_up.deaktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00301-001-s055><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr, damit Ihr Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00301-001-s055><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body could clear much more fat deposits.
<G-vec00301-001-s056><clear_up.deaktivieren><de> Deaktivieren Sie in der Schlüsseltabelle das Kontrollkästchen neben Abbild, um die gesamte Filterung zu beenden.
<G-vec00301-001-s056><clear_up.deaktivieren><en> To stop filtering altogether, in the key table, clear the check box next to Image.
<G-vec00246-002-s027><reactivate.deaktivieren><de> Klicke auf das Symbol mit den drei Punkten rechts neben dem Mitglied, das du deaktivieren möchtest.
<G-vec00246-002-s027><reactivate.deaktivieren><en> Click the three dots icon next to the account you want to reactivate.
<G-vec00279-002-s038><clear.deaktivieren><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00279-002-s038><clear.deaktivieren><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00279-002-s039><clear.deaktivieren><de> Deaktivieren Sie alle IIS Resource Kit Tools und Komponenten Kontrollkästchen außer dem KontrollkästchenMetabase Explorer 1.6 .
<G-vec00279-002-s039><clear.deaktivieren><en> Clear all the IIS Resource Kit Tools and components check boxes except the Metabase Explorer 1.6 check box.
<G-vec00279-002-s040><clear.deaktivieren><de> * Wort wischen: Deaktivieren Sie das Board für eine Power-Point-Bonus.
<G-vec00279-002-s040><clear.deaktivieren><en> * Word wipe: Clear the board for a Power Point bonus.
<G-vec00279-002-s041><clear.deaktivieren><de> Alles, was Sie brauchen, ist 45.000 Punkte und dann deaktivieren Sie alle Gelees.
<G-vec00279-002-s041><clear.deaktivieren><en> All you need is 45,000 points and then clear all the jellies.
<G-vec00279-002-s042><clear.deaktivieren><de> Wenn Sie die Einstellung jedoch auf ausgehende E-Mails beschränken möchten, können Sie alle Kontrollkästchen außer "Ausgehend" deaktivieren.
<G-vec00279-002-s042><clear.deaktivieren><en> However if, for example, you want to limit the Objectionable content policy to outbound mail, you can clear all check boxes except Outbound.
<G-vec00279-002-s043><clear.deaktivieren><de> Deaktivieren Sie Kontrollkästchen für Produkte, die nicht repariert werden sollen.
<G-vec00279-002-s043><clear.deaktivieren><en> Clear the check boxes for products you do not want to repair.
<G-vec00279-002-s044><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen neben dem Ordner, der auf diesem Gerät nicht angezeigt werden soll.
<G-vec00279-002-s044><clear.deaktivieren><en> Clear the check box next to the folder you want to keep off this device.
<G-vec00279-002-s045><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00279-002-s045><clear.deaktivieren><en> Clear this check box to hide these updates.
<G-vec00279-002-s046><clear.deaktivieren><de> Öffnen Sie die Dokumentbibliothek, und deaktivieren Sie alle Häkchen, sodass keine Dateien ausgewählt sind.
<G-vec00279-002-s046><clear.deaktivieren><en> Open the document library and clear all check marks so no files are selected.
<G-vec00279-002-s047><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen Exchange-Cache-Modus verwenden, klicken Sie auf Weiterund dann auf Fertig stellenklicken.
<G-vec00279-002-s047><clear.deaktivieren><en> Click to clear the Use Cached Exchange Mode checkbox, click Next, and then click Finish.
<G-vec00279-002-s048><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00279-002-s048><clear.deaktivieren><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00279-002-s049><clear.deaktivieren><de> Deaktivieren Sie alle acht spannende Levels und genießen das Spiel.
<G-vec00279-002-s049><clear.deaktivieren><en> Clear all eight exciting levels and enjoy the
<G-vec00279-002-s050><clear.deaktivieren><de> Deaktivieren Sie die Einstellung, die die Aktivierung blockiert.
<G-vec00279-002-s050><clear.deaktivieren><en> Clear the setting that blocks activation.
<G-vec00279-002-s051><clear.deaktivieren><de> Aktivieren Sie das Kontrollkästchen Temporäre Internetdateien, deaktivieren Sie die übrigen Kontrollkästchen, und klicken Sie auf Löschen.
<G-vec00279-002-s051><clear.deaktivieren><en> Select the Temporary Internet files check box, clear the other check boxes, and then click Delete.
<G-vec00279-002-s052><clear.deaktivieren><de> Wenn das Fenster Mit dem MobiLink-Server verbinden beim Aufruf des MobiLink-Monitors ohne Befehlszeilenoptionen nicht erscheinen soll, deaktivieren Sie das Kontrollkästchen zu dieser Option.
<G-vec00279-002-s052><clear.deaktivieren><en> If you do not want the Connect to MobiLink Server dialog to appear when you start the Monitor without command line options, clear the checkbox beside this option.
<G-vec00279-002-s053><clear.deaktivieren><de> Essen Sie alle das Gras und deaktivieren Sie die Ebene.
<G-vec00279-002-s053><clear.deaktivieren><en> Eat a grass and clear a level.
<G-vec00279-002-s054><clear.deaktivieren><de> Deaktivieren Sie alle Ebenen und gewinnen das Spiel zu.
<G-vec00279-002-s054><clear.deaktivieren><en> Clear series of exiting levels and have fun.
<G-vec00279-002-s055><clear.deaktivieren><de> Hinweis: Wenn Sie keine Tabellenüberschriften anzeigen möchten, können Sie sie später deaktivieren.
<G-vec00279-002-s055><clear.deaktivieren><en> If you do not want to display table headers, on the Tables tab, under Table Options, clear Header Row.
<G-vec00279-002-s056><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um den Andockbereich unten im Vegas-Fenster anzuzeigen.
<G-vec00279-002-s056><clear.deaktivieren><en> Clear the check box to display the docking area at the bottom of the window.
<G-vec00297-002-s112><opt.deaktivieren><de> Wenn Sie diese Cookies deaktivieren möchten, verwenden Sie bitte unser Einrichtungstool für Cookies.
<G-vec00297-002-s112><opt.deaktivieren><en> If you would like to opt out of these, please use our Cookie Settings Tool.
<G-vec00297-002-s113><opt.deaktivieren><de> Alternativ können Nutzer die Verwendung von Cookies durch Drittanbieter deaktivieren, indem sie die Deaktivierungsseite der Netzwerkwerbeinitiative aufrufen.
<G-vec00297-002-s113><opt.deaktivieren><en> (Alternatively you can point users to opt out of a third party vendor's use of cookies by visiting the Network Advertising Initiative opt out page.)
<G-vec00297-002-s114><opt.deaktivieren><de> Deaktivieren des Conversion-Cookies: Wenn Sie Cookies für Conversion-Tracking deaktivieren möchten, können Sie Ihren Browser so einstellen, dass Cookies von der Domain „googleadservices.com“ blockiert werden.
<G-vec00297-002-s114><opt.deaktivieren><en> How to opt out of the conversion cookie: If you want to disable conversion tracking cookies, you can set your browser to block cookies from the googleadservices.com domain.
<G-vec00297-002-s115><opt.deaktivieren><de> Nutzer können die Verwendung des DART-Cookies deaktivieren, indem sie die Datenschutzbestimmungen des Werbenetzwerks und Content-Werbenetzwerks von Google aufrufen.
<G-vec00297-002-s115><opt.deaktivieren><en> – Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy.
<G-vec00297-002-s116><opt.deaktivieren><de> Sie können die von uns verwendeten Google Analytics-Werbefunktionen deaktivieren, indem Sie Ihre Präferenzen angeben durch hier auf den interessenbezogenen Opt-Out-Link zu klicken.
<G-vec00297-002-s116><opt.deaktivieren><en> You can opt out of the Google Analytics Advertising Features we use by indicating your preference using the interest-based opt-out link here.
<G-vec00297-002-s117><opt.deaktivieren><de> Sie können Cookies für Conversion-Tracking auch deaktivieren, indem Sie Ihren Browser so einstellen, dass Cookies von der Domain „googleadservices.com“ blockiert werden.
<G-vec00297-002-s117><opt.deaktivieren><en> You can also specifically opt out of cookies for Conversion Tracking by setting your browser to reject cookies from the "googleadservices.com" domain.
<G-vec00297-002-s118><opt.deaktivieren><de> Nutzer können die Verwendung des DART-Cookies deaktivieren, in dem sie die Datenschutzbestimmungen des Werbenetzwerks und Content-Werbenetzwerks von Google aufrufen.
<G-vec00297-002-s118><opt.deaktivieren><en> Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy. Recent Articles
<G-vec00297-002-s119><opt.deaktivieren><de> Wenn Sie die oben genannten Google Analytics-Funktionen deaktivieren möchten, finden Sie weitere Informationen zum Abmelden unter hier.
<G-vec00297-002-s119><opt.deaktivieren><en> If you want to opt out of the above Google Analytics features, you can find more about signing out at here.
<G-vec00297-002-s120><opt.deaktivieren><de> Alternativ haben Sie die Möglichkeit, ein Browser-Plug-in zu installieren, um personalisierte Werbung zu deaktivieren.
<G-vec00297-002-s120><opt.deaktivieren><en> Alternatively, you can install a browser plugin to keep your preference to opt out of personalized ads.
<G-vec00297-002-s121><opt.deaktivieren><de> Es wird ein Opt-Out-Cookie gesetzt, der die Erfassung Ihrer Daten bei zukünftigen Besuchen dieser Website verhindert: Google Analytics deaktivieren.
<G-vec00297-002-s121><opt.deaktivieren><en> An opt-out cookie will be stored on your computer which prevents the future collection of your data when you visit this website: Click here to opt out of Google Analytics.
<G-vec00297-002-s122><opt.deaktivieren><de> Mit NAI- und IAB-Mitgliedern können Sie die Verhaltenswerbung deaktivieren.
<G-vec00297-002-s122><opt.deaktivieren><en> NAI and IAB members allow you to opt out of the behavioral advertising.
<G-vec00297-002-s123><opt.deaktivieren><de> Sie können die automatische Profilerstellung jederzeit deaktivieren (siehe Abschnitt über Ihre Rechte).
<G-vec00297-002-s123><opt.deaktivieren><en> You may opt out of automatic profiling at any time (see the section about your rights).
<G-vec00297-002-s124><opt.deaktivieren><de> Unsere Kunden können die E-Mail-Kommunikation über die gesendeten E-Mails oder auf unserer Website deaktivieren.
<G-vec00297-002-s124><opt.deaktivieren><en> Subscribers can opt out of email communication via the emails sent or on our site.
<G-vec00297-002-s125><opt.deaktivieren><de> Des Weiteren können Sie in den Einstellungen bei Google personalisierte Werbung deaktivieren.
<G-vec00297-002-s125><opt.deaktivieren><en> Furthermore you can opt out of interest-based advertising in the Google settings.
<G-vec00297-002-s126><opt.deaktivieren><de> Nach dem Deaktivieren erhalten Sie weiterhin Werbung, die jedoch möglicherweise nicht mehr Ihren Interessen angepasst ist.
<G-vec00297-002-s126><opt.deaktivieren><en> If you opt out, you will still receive ads but they may not be as relevant to you and your interests.
<G-vec00297-002-s127><opt.deaktivieren><de> Zur Deaktivierung von interessenbasierter Werbung auf Android öffnen Sie Ihre Google-Einstellungen und aktivieren unter „Anzeigen" die Option „Personalisierte Werbung deaktivieren".
<G-vec00297-002-s127><opt.deaktivieren><en> To opt-out of Google interest-based ads on Android, open your Google Settings app > Ads > Enable "Opt out of interest-based advertising"
<G-vec00297-002-s128><opt.deaktivieren><de> Wenn Sie auf das Wort „Anzeige“ oder den Link klicken, gelangen Sie auf eine Website, auf der Sie die Verwendung von Daten über Ihren Browserverlauf, die für verhaltensbasierte Online-Werbung verwendet werden, verwalten oder deaktivieren können.
<G-vec00297-002-s128><opt.deaktivieren><en> Clicking on the icon or link will take you to a website where you can manage or opt out of the use of data about your browsing history that is used for the delivery of online behavioural advertising.
<G-vec00297-002-s129><opt.deaktivieren><de> Bitte beachten Sie, dass Sie womöglich weiterhin andere Arten von Werbung erhalten, wenn Sie bestimmte Arten von interessensbasierter Werbung deaktivieren können.
<G-vec00297-002-s129><opt.deaktivieren><en> Please be aware that, even if you are able to opt out of certain kinds of Interest-based Advertising, you may continue to receive other types of ads.
<G-vec00297-002-s130><opt.deaktivieren><de> Hier können Sie auch bestimmte Google-Werbedienste deaktivieren.
<G-vec00297-002-s130><opt.deaktivieren><en> You can also opt out of certain Google advertising services here.
<G-vec00245-003-s209><turn_up.deaktivieren><de> Wenn Sie wieder zur Verwendung des Startbildschirms zurückkehren möchten, deaktivieren Sie einfach die Option für das Startmenü.
<G-vec00245-003-s209><turn_up.deaktivieren><en> If you want to go back to using the Start screen again, just turn the Start menu option off.
<G-vec00245-003-s210><turn_up.deaktivieren><de> Cookies deaktivieren: Deaktivieren Sie Speichern und Lesen von Cookiedaten zulassen.
<G-vec00245-003-s210><turn_up.deaktivieren><en> Turn off cookies: Turn off Allow sites to save and read cookie data.
<G-vec00245-003-s211><turn_up.deaktivieren><de> Möchten Sie ein Norton-Produkt, das im automatischen Verlängerungsservice von Norton registriert ist, weiterhin nutzen, überspringen Sie die Schritte zum Deaktivieren des Service und folgen Sie den Anweisungen unter Download your Norton product.
<G-vec00245-003-s211><turn_up.deaktivieren><en> If you want to continue using the Norton product that is currently enrolled in the Norton Automatic Renewal service, skip the steps to turn off the Norton Automatic Renewal service, and Download your Norton product.
<G-vec00245-003-s212><turn_up.deaktivieren><de> Wenn Sie über einen Zune Music Pass oder Xbox Music Pass verfügen und nicht möchten, dass Songs aus dem Marktplatzkatalog enthalten sind, deaktivieren Sie die Drahtlosverbindung.
<G-vec00245-003-s212><turn_up.deaktivieren><en> If you have a Zune Music Pass or Xbox Music Pass and you don’t want songs from the Marketplace catalog included, turn off the wireless connection.
<G-vec00245-003-s213><turn_up.deaktivieren><de> Deaktivieren Sie abgerundete Ecken, um die Folie auszuwählen.
<G-vec00245-003-s213><turn_up.deaktivieren><en> Turn off rounded corners to select foil.
<G-vec00245-003-s214><turn_up.deaktivieren><de> Deaktivieren Sie im Menü „LOGIK“ alle Logikeinstellungen für die Umfrage.
<G-vec00245-003-s214><turn_up.deaktivieren><en> In the LOGIC menu, turn off all survey logic.
<G-vec00245-003-s215><turn_up.deaktivieren><de> Deaktivieren Sie in diesem Fall den privaten Modus und versuchen Sie es noch einmal.
<G-vec00245-003-s215><turn_up.deaktivieren><en> In that case, turn off Private Browsing and try again.
<G-vec00245-003-s216><turn_up.deaktivieren><de> Wenn Sie das Konto manuell konfigurieren, deaktivieren Sie die Citrix Gateway-Option Neues Konto.
<G-vec00245-003-s216><turn_up.deaktivieren><en> If you are manually configuring the account, then turn off the Citrix Gateway option New Account dialog.
<G-vec00245-003-s217><turn_up.deaktivieren><de> Wenn Sie Ihr Abonnement beenden möchten und der Kauf mehr als 30 Tage zurückliegt, deaktivieren Sie die wiederkehrende Abrechnung, um zu vermeiden, dass Ihnen nach Ablauf des Abonnements Gebühren berechnet werden.
<G-vec00245-003-s217><turn_up.deaktivieren><en> If it's been more than 30 days since you bought the subscription and you want to stop your subscription, turn off recurring billing to or it won't turn off, try the following:
<G-vec00245-003-s218><turn_up.deaktivieren><de> Um NFC auszuschalten, deaktivieren Sie die entsprechende Einstellung NFC.
<G-vec00245-003-s218><turn_up.deaktivieren><en> To turn off NFC, turn off the NFC switch.
<G-vec00245-003-s219><turn_up.deaktivieren><de> Wenn Sie es vorziehen, dass Personen nur die von Ihnen angegebenen Werte verwenden, deaktivieren Sie die Auswahlmöglichkeiten für das Ausfüllen.
<G-vec00245-003-s219><turn_up.deaktivieren><en> If you prefer that people use only the values that you specify, turn off fill-in choices.
<G-vec00245-003-s220><turn_up.deaktivieren><de> So deaktivieren Sie Apps auswählen, die Ihre Kamera verwenden können Deaktivieren Sie das Feature in der Benutzeroberfläche der einzelnen Apps.
<G-vec00245-003-s220><turn_up.deaktivieren><en> To turn off Choose apps that can use your camera: Turn off the feature in the UI for each app.
<G-vec00245-003-s222><turn_up.deaktivieren><de> Wählen Sie die Schaltfläche Start und dann Einstellungen > Netzwerk und Internet > Flugzeugmodus aus, und deaktivieren Sie den Flugzeugmodus, falls er aktiviert ist.
<G-vec00245-003-s222><turn_up.deaktivieren><en> Select the Start button, then select Settings > Network & Internet > Airplane mode and turn off airplane mode if it's on.
<G-vec00245-003-s223><turn_up.deaktivieren><de> Schritt 05: Deaktivieren Sie die Option "Warnungen nicht stören", indem Sie sie nach links schalten.
<G-vec00245-003-s223><turn_up.deaktivieren><en> Step 05: Turn off the Hide Alerts Do Not Disturb option by toggling it to the left.
<G-vec00245-003-s224><turn_up.deaktivieren><de> Android 6.0 Marshmallow: Gehen Sie zu Einstellungen, Akku, Akku-Sparmodus und deaktivieren Sie den Akku-Sparmodus.
<G-vec00245-003-s224><turn_up.deaktivieren><en> Android 6.0 Marshmallow: go to Settings, Battery, Battery Saver, and turn off the battery saver mode.
<G-vec00245-003-s225><turn_up.deaktivieren><de> Deaktivieren Sie ihn auf der Registerkarte 'Druckereigenschaften' im Treiber.
<G-vec00245-003-s225><turn_up.deaktivieren><en> Turn off Toner Save mode in the printer Properties tab of the driver.
<G-vec00245-003-s226><turn_up.deaktivieren><de> Deaktivieren Sie die Datei- und Druckerfreigabe auf Ihrem Computer.
<G-vec00245-003-s226><turn_up.deaktivieren><en> Turn off file and printer sharing on your computer.
<G-vec00245-003-s227><turn_up.deaktivieren><de> Deaktivieren Sie “System Restore” – Rechtsklick auf meinem Computer und dann auf Eigenschaften klicken, wählen Sie die Registerkarte Systemwiederherstellung und markieren Sie das Kontrollkästchen “Deaktivieren Sie die Systemwiederherstellung auf allen Laufwerken wiederherstellen”.
<G-vec00245-003-s227><turn_up.deaktivieren><en> Disable “System Restore” – Right click on my computer, then click on properties, select system Restore Tab and tick the check box of “Turn off System Restore on all drives”.
<G-vec00301-003-s038><clear_up.deaktivieren><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00301-003-s038><clear_up.deaktivieren><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00301-003-s039><clear_up.deaktivieren><de> Deaktivieren Sie alle IIS Resource Kit Tools und Komponenten Kontrollkästchen außer dem KontrollkästchenMetabase Explorer 1.6 .
<G-vec00301-003-s039><clear_up.deaktivieren><en> Clear all the IIS Resource Kit Tools and components check boxes except the Metabase Explorer 1.6 check box.
<G-vec00301-003-s040><clear_up.deaktivieren><de> * Wort wischen: Deaktivieren Sie das Board für eine Power-Point-Bonus.
<G-vec00301-003-s040><clear_up.deaktivieren><en> * Word wipe: Clear the board for a Power Point bonus.
<G-vec00301-003-s041><clear_up.deaktivieren><de> Alles, was Sie brauchen, ist 45.000 Punkte und dann deaktivieren Sie alle Gelees.
<G-vec00301-003-s041><clear_up.deaktivieren><en> All you need is 45,000 points and then clear all the jellies.
<G-vec00301-003-s042><clear_up.deaktivieren><de> Wenn Sie die Einstellung jedoch auf ausgehende E-Mails beschränken möchten, können Sie alle Kontrollkästchen außer "Ausgehend" deaktivieren.
<G-vec00301-003-s042><clear_up.deaktivieren><en> However if, for example, you want to limit the Objectionable content policy to outbound mail, you can clear all check boxes except Outbound.
<G-vec00301-003-s043><clear_up.deaktivieren><de> Deaktivieren Sie Kontrollkästchen für Produkte, die nicht repariert werden sollen.
<G-vec00301-003-s043><clear_up.deaktivieren><en> Clear the check boxes for products you do not want to repair.
<G-vec00301-003-s044><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen neben dem Ordner, der auf diesem Gerät nicht angezeigt werden soll.
<G-vec00301-003-s044><clear_up.deaktivieren><en> Clear the check box next to the folder you want to keep off this device.
<G-vec00301-003-s045><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00301-003-s045><clear_up.deaktivieren><en> Clear this check box to hide these updates.
<G-vec00301-003-s046><clear_up.deaktivieren><de> Öffnen Sie die Dokumentbibliothek, und deaktivieren Sie alle Häkchen, sodass keine Dateien ausgewählt sind.
<G-vec00301-003-s046><clear_up.deaktivieren><en> Open the document library and clear all check marks so no files are selected.
<G-vec00301-003-s047><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen Exchange-Cache-Modus verwenden, klicken Sie auf Weiterund dann auf Fertig stellenklicken.
<G-vec00301-003-s047><clear_up.deaktivieren><en> Click to clear the Use Cached Exchange Mode checkbox, click Next, and then click Finish.
<G-vec00301-003-s048><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00301-003-s048><clear_up.deaktivieren><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00301-003-s049><clear_up.deaktivieren><de> Deaktivieren Sie alle acht spannende Levels und genießen das Spiel.
<G-vec00301-003-s049><clear_up.deaktivieren><en> Clear all eight exciting levels and enjoy the
<G-vec00301-003-s050><clear_up.deaktivieren><de> Deaktivieren Sie die Einstellung, die die Aktivierung blockiert.
<G-vec00301-003-s050><clear_up.deaktivieren><en> Clear the setting that blocks activation.
<G-vec00301-003-s051><clear_up.deaktivieren><de> Aktivieren Sie das Kontrollkästchen Temporäre Internetdateien, deaktivieren Sie die übrigen Kontrollkästchen, und klicken Sie auf Löschen.
<G-vec00301-003-s051><clear_up.deaktivieren><en> Select the Temporary Internet files check box, clear the other check boxes, and then click Delete.
<G-vec00301-003-s052><clear_up.deaktivieren><de> Wenn das Fenster Mit dem MobiLink-Server verbinden beim Aufruf des MobiLink-Monitors ohne Befehlszeilenoptionen nicht erscheinen soll, deaktivieren Sie das Kontrollkästchen zu dieser Option.
<G-vec00301-003-s052><clear_up.deaktivieren><en> If you do not want the Connect to MobiLink Server dialog to appear when you start the Monitor without command line options, clear the checkbox beside this option.
<G-vec00301-003-s053><clear_up.deaktivieren><de> Essen Sie alle das Gras und deaktivieren Sie die Ebene.
<G-vec00301-003-s053><clear_up.deaktivieren><en> Eat a grass and clear a level.
<G-vec00301-003-s054><clear_up.deaktivieren><de> Deaktivieren Sie alle Ebenen und gewinnen das Spiel zu.
<G-vec00301-003-s054><clear_up.deaktivieren><en> Clear series of exiting levels and have fun.
<G-vec00301-003-s055><clear_up.deaktivieren><de> Hinweis: Wenn Sie keine Tabellenüberschriften anzeigen möchten, können Sie sie später deaktivieren.
<G-vec00301-003-s055><clear_up.deaktivieren><en> If you do not want to display table headers, on the Tables tab, under Table Options, clear Header Row.
<G-vec00301-003-s056><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um den Andockbereich unten im Vegas-Fenster anzuzeigen.
<G-vec00301-003-s056><clear_up.deaktivieren><en> Clear the check box to display the docking area at the bottom of the window.
<G-vec00309-003-s190><turn_out.deaktivieren><de> Blättern Sie dann nach unten zu „In-App-Käufe“ und deaktivieren Sie die Option mithilfe des Schalters auf der linken Seite.
<G-vec00309-003-s190><turn_out.deaktivieren><en> Then scroll down to 'In-App Purchases' and turn this off by tapping the switch left
<G-vec00309-003-s191><turn_out.deaktivieren><de> Klicken Sie auf das Symbol, um „Privates Surfen“ zu deaktivieren.
<G-vec00309-003-s191><turn_out.deaktivieren><en> Click on the icon to turn off Private Browsing
<G-vec00309-003-s192><turn_out.deaktivieren><de> In solchen Fällen können Sie die Verschlüsselungsfunktion einfach deaktivieren.
<G-vec00309-003-s192><turn_out.deaktivieren><en> In such cases, you can easily turn off the encryption feature.
<G-vec00309-003-s193><turn_out.deaktivieren><de> Wenn Sie sich entschließen, „Bearbeiten von Beantwortungen“ zu deaktivieren, können die Befragten ihre Antworten zwar weiterhin bearbeiten, solange sie sich noch auf der betreffenden Umfrageseite befinden, doch sie können Beantwortungen auf zurückliegenden Seiten nicht mehr bearbeiten.
<G-vec00309-003-s193><turn_out.deaktivieren><en> If you choose to turn Response Editing off, respondents can still edit answers when they're on a given survey page, but not on previous pages—the Previous button is hidden from respondents when they're taking your survey.
<G-vec00309-003-s194><turn_out.deaktivieren><de> Sie haben die Möglichkeit, die Funktion „personalisierte Anzeigen“ in den Einstellungen Ihres Google-Kontos zu deaktivieren und damit die geräteübergreifende Analyse abzustellen.
<G-vec00309-003-s194><turn_out.deaktivieren><en> You have the option of deactivating the "personalized ads" function in the settings of your Google account and thus turn off the cross-device analysis.
<G-vec00309-003-s195><turn_out.deaktivieren><de> HINWEIS: Die Vorgehensweise zum Deaktivieren der AVLS-Funktion ist je nach Modell unterschiedlich.
<G-vec00309-003-s195><turn_out.deaktivieren><en> The procedure to turn off the AVLS feature varies by model.
<G-vec00309-003-s196><turn_out.deaktivieren><de> Um die Batterielaufzeit bei längeren Geh- und Laufaktivitäten zu verlängern, können Sie den Herzfrequenzsensor deaktivieren.
<G-vec00309-003-s196><turn_out.deaktivieren><en> To preserve your battery life on long walks and runs, you can turn off the heart rate sensor.
<G-vec00309-003-s197><turn_out.deaktivieren><de> Sie haben zwar die Möglichkeit, die Einstellung für mobile Geräte zu deaktivieren, dies wird jedoch nicht empfohlen.
<G-vec00309-003-s197><turn_out.deaktivieren><en> Although you have the option to turn off the ‘mobile-friendly’ setting, this is not recommended.
<G-vec00309-003-s198><turn_out.deaktivieren><de> Ein Kind kann das Blockieren unerwünschter Websites deaktivieren.
<G-vec00309-003-s198><turn_out.deaktivieren><en> A child can turn on display of unwanted websites.
<G-vec00309-003-s199><turn_out.deaktivieren><de> Um die Erinnerung zu deaktivieren, wählen Sie keine aus.
<G-vec00309-003-s199><turn_out.deaktivieren><en> To turn the reminder off, select None.
<G-vec00309-003-s200><turn_out.deaktivieren><de> • Um Hintergrunddaten für alle Apps und Dienste auf Ihrem Gerät zu deaktivieren, tippen Sie auf > Hintergrunddaten beschränken und dann auf OK.
<G-vec00309-003-s200><turn_out.deaktivieren><en> • To turn off background data for all apps and services on your device, tap > Restrict background data, and then
<G-vec00309-003-s201><turn_out.deaktivieren><de> HochDieser Artikel enthält Informationen dazu, wie Sie Sicherheitseinstellungen herabsetzen oder Sicherheitsfeatures auf einem Computer vorübergehend deaktivieren.
<G-vec00309-003-s201><turn_out.deaktivieren><en> ImportantThis article contains information that shows how to help lower security settings or how to temporarily turn off security features on a computer.
<G-vec00309-003-s202><turn_out.deaktivieren><de> Sie können dann die iCloud-Fotomediathek deaktivieren.
<G-vec00309-003-s202><turn_out.deaktivieren><en> Then you can turn off iCloud Photo Library.
<G-vec00309-003-s203><turn_out.deaktivieren><de> Wenn Sie keine Push-Benachrichtigungen erhalten wollen, können Sie diese in den Einstellungen Ihres Geräts deaktivieren.
<G-vec00309-003-s203><turn_out.deaktivieren><en> If you no longer wish to receive push notifications, you may turn them off at the device level.
<G-vec00309-003-s204><turn_out.deaktivieren><de> Sie können die Einstellung Dateiüberprüfung deaktivieren, um die Office-Dateiüberprüfung zu deaktivieren.
<G-vec00309-003-s204><turn_out.deaktivieren><en> You can turn off Office File Validation by setting specific registry keys to disable Office File Validation.
<G-vec00309-003-s205><turn_out.deaktivieren><de> Beispielsweise kann der Betriebsplan Befehle enthalten, um eine Welle zu deaktivieren oder um antreibende und/oder bremsende Kräfte der Welle zu begrenzen.
<G-vec00309-003-s205><turn_out.deaktivieren><en> For example, the operation schedule may include instructions to turn off a shaft or to limit driving and / or braking forces of the shaft.
<G-vec00309-003-s206><turn_out.deaktivieren><de> Deshalb habt ihr die Möglichkeit, die Hintergrundmusik und die Soundeffekte zu deaktivieren.
<G-vec00309-003-s206><turn_out.deaktivieren><en> You have an option to turn off background music and sound effects, so your kids can keep watching while you catch a breath.
<G-vec00309-003-s207><turn_out.deaktivieren><de> Dozenten und Administratoren können die alternativen Formate für ein einzelnes Inhaltselement in einem Kurs deaktivieren.
<G-vec00309-003-s207><turn_out.deaktivieren><en> Instructors and administrators can turn off the alternative formats for an individual content item within a course.
<G-vec00309-003-s208><turn_out.deaktivieren><de> Gehen Sie zu Ansicht > in den Präsentationsmodus wechseln/Präsentationsmodus beenden um den Präsentationsmodus zu deaktivieren.
<G-vec00309-003-s208><turn_out.deaktivieren><en> Go to View > Enter/Exit Presentation Mode to turn off presentation mode.
<G-vec00331-003-s209><turn_out.deaktivieren><de> Wenn Sie wieder zur Verwendung des Startbildschirms zurückkehren möchten, deaktivieren Sie einfach die Option für das Startmenü.
<G-vec00331-003-s209><turn_out.deaktivieren><en> If you want to go back to using the Start screen again, just turn the Start menu option off.
<G-vec00331-003-s210><turn_out.deaktivieren><de> Cookies deaktivieren: Deaktivieren Sie Speichern und Lesen von Cookiedaten zulassen.
<G-vec00331-003-s210><turn_out.deaktivieren><en> Turn off cookies: Turn off Allow sites to save and read cookie data.
<G-vec00331-003-s211><turn_out.deaktivieren><de> Möchten Sie ein Norton-Produkt, das im automatischen Verlängerungsservice von Norton registriert ist, weiterhin nutzen, überspringen Sie die Schritte zum Deaktivieren des Service und folgen Sie den Anweisungen unter Download your Norton product.
<G-vec00331-003-s211><turn_out.deaktivieren><en> If you want to continue using the Norton product that is currently enrolled in the Norton Automatic Renewal service, skip the steps to turn off the Norton Automatic Renewal service, and Download your Norton product.
<G-vec00331-003-s212><turn_out.deaktivieren><de> Wenn Sie über einen Zune Music Pass oder Xbox Music Pass verfügen und nicht möchten, dass Songs aus dem Marktplatzkatalog enthalten sind, deaktivieren Sie die Drahtlosverbindung.
<G-vec00331-003-s212><turn_out.deaktivieren><en> If you have a Zune Music Pass or Xbox Music Pass and you don’t want songs from the Marketplace catalog included, turn off the wireless connection.
<G-vec00331-003-s213><turn_out.deaktivieren><de> Deaktivieren Sie abgerundete Ecken, um die Folie auszuwählen.
<G-vec00331-003-s213><turn_out.deaktivieren><en> Turn off rounded corners to select foil.
<G-vec00331-003-s214><turn_out.deaktivieren><de> Deaktivieren Sie im Menü „LOGIK“ alle Logikeinstellungen für die Umfrage.
<G-vec00331-003-s214><turn_out.deaktivieren><en> In the LOGIC menu, turn off all survey logic.
<G-vec00331-003-s215><turn_out.deaktivieren><de> Deaktivieren Sie in diesem Fall den privaten Modus und versuchen Sie es noch einmal.
<G-vec00331-003-s215><turn_out.deaktivieren><en> In that case, turn off Private Browsing and try again.
<G-vec00331-003-s216><turn_out.deaktivieren><de> Wenn Sie das Konto manuell konfigurieren, deaktivieren Sie die Citrix Gateway-Option Neues Konto.
<G-vec00331-003-s216><turn_out.deaktivieren><en> If you are manually configuring the account, then turn off the Citrix Gateway option New Account dialog.
<G-vec00331-003-s217><turn_out.deaktivieren><de> Wenn Sie Ihr Abonnement beenden möchten und der Kauf mehr als 30 Tage zurückliegt, deaktivieren Sie die wiederkehrende Abrechnung, um zu vermeiden, dass Ihnen nach Ablauf des Abonnements Gebühren berechnet werden.
<G-vec00331-003-s217><turn_out.deaktivieren><en> If it's been more than 30 days since you bought the subscription and you want to stop your subscription, turn off recurring billing to or it won't turn off, try the following:
<G-vec00331-003-s218><turn_out.deaktivieren><de> Um NFC auszuschalten, deaktivieren Sie die entsprechende Einstellung NFC.
<G-vec00331-003-s218><turn_out.deaktivieren><en> To turn off NFC, turn off the NFC switch.
<G-vec00331-003-s219><turn_out.deaktivieren><de> Wenn Sie es vorziehen, dass Personen nur die von Ihnen angegebenen Werte verwenden, deaktivieren Sie die Auswahlmöglichkeiten für das Ausfüllen.
<G-vec00331-003-s219><turn_out.deaktivieren><en> If you prefer that people use only the values that you specify, turn off fill-in choices.
<G-vec00331-003-s220><turn_out.deaktivieren><de> So deaktivieren Sie Apps auswählen, die Ihre Kamera verwenden können Deaktivieren Sie das Feature in der Benutzeroberfläche der einzelnen Apps.
<G-vec00331-003-s220><turn_out.deaktivieren><en> To turn off Choose apps that can use your camera: Turn off the feature in the UI for each app.
<G-vec00331-003-s222><turn_out.deaktivieren><de> Wählen Sie die Schaltfläche Start und dann Einstellungen > Netzwerk und Internet > Flugzeugmodus aus, und deaktivieren Sie den Flugzeugmodus, falls er aktiviert ist.
<G-vec00331-003-s222><turn_out.deaktivieren><en> Select the Start button, then select Settings > Network & Internet > Airplane mode and turn off airplane mode if it's on.
<G-vec00331-003-s223><turn_out.deaktivieren><de> Schritt 05: Deaktivieren Sie die Option "Warnungen nicht stören", indem Sie sie nach links schalten.
<G-vec00331-003-s223><turn_out.deaktivieren><en> Step 05: Turn off the Hide Alerts Do Not Disturb option by toggling it to the left.
<G-vec00331-003-s224><turn_out.deaktivieren><de> Android 6.0 Marshmallow: Gehen Sie zu Einstellungen, Akku, Akku-Sparmodus und deaktivieren Sie den Akku-Sparmodus.
<G-vec00331-003-s224><turn_out.deaktivieren><en> Android 6.0 Marshmallow: go to Settings, Battery, Battery Saver, and turn off the battery saver mode.
<G-vec00331-003-s225><turn_out.deaktivieren><de> Deaktivieren Sie ihn auf der Registerkarte 'Druckereigenschaften' im Treiber.
<G-vec00331-003-s225><turn_out.deaktivieren><en> Turn off Toner Save mode in the printer Properties tab of the driver.
<G-vec00331-003-s226><turn_out.deaktivieren><de> Deaktivieren Sie die Datei- und Druckerfreigabe auf Ihrem Computer.
<G-vec00331-003-s226><turn_out.deaktivieren><en> Turn off file and printer sharing on your computer.
<G-vec00331-003-s227><turn_out.deaktivieren><de> Deaktivieren Sie “System Restore” – Rechtsklick auf meinem Computer und dann auf Eigenschaften klicken, wählen Sie die Registerkarte Systemwiederherstellung und markieren Sie das Kontrollkästchen “Deaktivieren Sie die Systemwiederherstellung auf allen Laufwerken wiederherstellen”.
<G-vec00331-003-s227><turn_out.deaktivieren><en> Disable “System Restore” – Right click on my computer, then click on properties, select system Restore Tab and tick the check box of “Turn off System Restore on all drives”.
