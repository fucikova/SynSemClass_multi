<G-vec00078-001-s038><clear.deaktivieren><de> Wir haben von Deaktivieren Sie Briefmarken für scrapbooking verbesserte Qualitätskontrolle, jede Export qualifiziertes Produkt zu gewährleisten.
<G-vec00078-001-s038><clear.deaktivieren><en> We have improved quality control processes of clear stamps for scrapbooking to ensure each export qualified product.
<G-vec00078-001-s039><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr um sicherzustellen, dass Ihre physischen Körper viel mehr Fettgewebe deaktivieren kann.
<G-vec00078-001-s039><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body can clear more fat.
<G-vec00078-001-s040><clear.deaktivieren><de> Aktivieren oder deaktivieren Sie das Kontrollkästchen Internationale Einstellungen verwenden.
<G-vec00078-001-s040><clear.deaktivieren><en> Select or clear the Use international settings check box.
<G-vec00078-001-s041><clear.deaktivieren><de> Deaktivieren Sie dann die Wand Pinsel und mit Wasser angefeuchtet.
<G-vec00078-001-s041><clear.deaktivieren><en> Then clear the wall brush and moistened with water.
<G-vec00078-001-s042><clear.deaktivieren><de> Deaktivieren Sie die Optionen Automatisch Datum & Uhrzeit und Automatische Zeitzone und stellen Sie anschließend die Zeitzone, das Datum und die Uhrzeit ein.
<G-vec00078-001-s042><clear.deaktivieren><en> Clear Automatic date & time and Automatic time zone, and then set the time zone, date, and time as required.
<G-vec00078-001-s043><clear.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Ressourcenpartner aktivieren das Kontrollkästchen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00078-001-s043><clear.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00078-001-s044><clear.deaktivieren><de> Bobble Shooter - Deaktivieren Sie alle Blasen vom Spielfeld.
<G-vec00078-001-s044><clear.deaktivieren><en> Bobble Shooter - Clear all the bubbles from the board .
<G-vec00078-001-s045><clear.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Diesen Ressourcenpartner aktivieren das Kontrollkästchen Diesen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00078-001-s045><clear.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00078-001-s046><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: dieser Stoff hilft Ihre metabolische Preis um sicherzustellen, dass Ihre physischen Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00078-001-s046><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This active ingredient really helps up your metabolic price so that your body could clear much more fat deposits.
<G-vec00078-001-s047><clear.deaktivieren><de> Deaktivieren Sie diese Option, um das Ausführen der Webdiensterweiterungen auf dem Server nicht zuzulassen.
<G-vec00078-001-s047><clear.deaktivieren><en> Clear this option to prohibit Web service extensions from running on your Web server.
<G-vec00078-001-s048><clear.deaktivieren><de> um zu erkennen, subtil, zu halten deaktivieren Sie das Gehirn, lesen Sie die Gedanken derer, die daran denken, Sie, sehr hilfsbereit und gute Hilfe Atemübungen, die verschiedenen Nasenlöcher zu erzeugen, kann es getan sitzen oder stehen vor dem offenen Fenster, in einem gut werdenbelüfteten Raum.
<G-vec00078-001-s048><clear.deaktivieren><en> order to detect subtle, keep clear the brain, read the thoughts of those who are thinking of you, very helpful and good help breathing exercises that produce different nostrils, it can be done sitting or standing in front of the open window, in a wellventilated room.
<G-vec00078-001-s049><clear.deaktivieren><de> Deaktivieren Sie die Äpfel aus Samen und Rinde, in Streifen geschnitten.
<G-vec00078-001-s049><clear.deaktivieren><en> Clear the apples from seeds and rind, cut into strips.
<G-vec00078-001-s050><clear.deaktivieren><de> Deaktivieren Sie alle Optionen.
<G-vec00078-001-s050><clear.deaktivieren><en> Clear all options.
<G-vec00078-001-s051><clear.deaktivieren><de> Aktivieren oder deaktivieren Sie Anzeigen von abgelehnten Netzwerken für Benutzer zulassen, um zu ermöglichen oder zu verhindern, dass Drahtlosnetzwerke im Dialogfeld Verbindung mit einem Netzwerk herstellen angezeigt werden.
<G-vec00078-001-s051><clear.deaktivieren><en> To enable or prevent wireless networks from displaying in the Connect to a network dialog box, either select or clear Allow user to view denied networks.
<G-vec00078-001-s052><clear.deaktivieren><de> Wenn der See steigt ein anderer 2 oder 3 Füße, Sonnenlicht wird nicht an die Wurzeln der Pflanzen, und sie werden sterben, und deaktivieren Sie die Oberfläche.
<G-vec00078-001-s052><clear.deaktivieren><en> When the lake level rises another 2 or 3 feet, sunlight won’t reach the roots of plants and they will die and clear out the surface.
<G-vec00078-001-s053><clear.deaktivieren><de> Wenn Sie jemals benötigt wird, um Gewalt zu stoppen, oder deaktivieren Sie die Daten / Cache aus einer App, Dies ist eine willkommene Ergänzung, da es viel zu finden Diese Seite macht, viel einfacher.
<G-vec00078-001-s053><clear.deaktivieren><en> If you’ve ever needed to force stop, or clear the data/cache from an app, this is a welcome addition as it makes finding this page much, much easier.
<G-vec00078-001-s054><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00078-001-s054><clear.deaktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00078-001-s055><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr, damit Ihr Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00078-001-s055><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body could clear much more fat deposits.
<G-vec00078-001-s056><clear.deaktivieren><de> Deaktivieren Sie in der Schlüsseltabelle das Kontrollkästchen neben Abbild, um die gesamte Filterung zu beenden.
<G-vec00078-001-s056><clear.deaktivieren><en> To stop filtering altogether, in the key table, clear the check box next to Image.
<G-vec00301-001-s038><clear_up.deaktivieren><de> Wir haben von Deaktivieren Sie Briefmarken für scrapbooking verbesserte Qualitätskontrolle, jede Export qualifiziertes Produkt zu gewährleisten.
<G-vec00301-001-s038><clear_up.deaktivieren><en> We have improved quality control processes of clear stamps for scrapbooking to ensure each export qualified product.
<G-vec00301-001-s039><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr um sicherzustellen, dass Ihre physischen Körper viel mehr Fettgewebe deaktivieren kann.
<G-vec00301-001-s039><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body can clear more fat.
<G-vec00301-001-s040><clear_up.deaktivieren><de> Aktivieren oder deaktivieren Sie das Kontrollkästchen Internationale Einstellungen verwenden.
<G-vec00301-001-s040><clear_up.deaktivieren><en> Select or clear the Use international settings check box.
<G-vec00301-001-s041><clear_up.deaktivieren><de> Deaktivieren Sie dann die Wand Pinsel und mit Wasser angefeuchtet.
<G-vec00301-001-s041><clear_up.deaktivieren><en> Then clear the wall brush and moistened with water.
<G-vec00301-001-s042><clear_up.deaktivieren><de> Deaktivieren Sie die Optionen Automatisch Datum & Uhrzeit und Automatische Zeitzone und stellen Sie anschließend die Zeitzone, das Datum und die Uhrzeit ein.
<G-vec00301-001-s042><clear_up.deaktivieren><en> Clear Automatic date & time and Automatic time zone, and then set the time zone, date, and time as required.
<G-vec00301-001-s043><clear_up.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Ressourcenpartner aktivieren das Kontrollkästchen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00301-001-s043><clear_up.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00301-001-s044><clear_up.deaktivieren><de> Bobble Shooter - Deaktivieren Sie alle Blasen vom Spielfeld.
<G-vec00301-001-s044><clear_up.deaktivieren><en> Bobble Shooter - Clear all the bubbles from the board .
<G-vec00301-001-s045><clear_up.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Diesen Ressourcenpartner aktivieren das Kontrollkästchen Diesen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00301-001-s045><clear_up.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00301-001-s046><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: dieser Stoff hilft Ihre metabolische Preis um sicherzustellen, dass Ihre physischen Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00301-001-s046><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This active ingredient really helps up your metabolic price so that your body could clear much more fat deposits.
<G-vec00301-001-s047><clear_up.deaktivieren><de> Deaktivieren Sie diese Option, um das Ausführen der Webdiensterweiterungen auf dem Server nicht zuzulassen.
<G-vec00301-001-s047><clear_up.deaktivieren><en> Clear this option to prohibit Web service extensions from running on your Web server.
<G-vec00301-001-s048><clear_up.deaktivieren><de> um zu erkennen, subtil, zu halten deaktivieren Sie das Gehirn, lesen Sie die Gedanken derer, die daran denken, Sie, sehr hilfsbereit und gute Hilfe Atemübungen, die verschiedenen Nasenlöcher zu erzeugen, kann es getan sitzen oder stehen vor dem offenen Fenster, in einem gut werdenbelüfteten Raum.
<G-vec00301-001-s048><clear_up.deaktivieren><en> order to detect subtle, keep clear the brain, read the thoughts of those who are thinking of you, very helpful and good help breathing exercises that produce different nostrils, it can be done sitting or standing in front of the open window, in a wellventilated room.
<G-vec00301-001-s049><clear_up.deaktivieren><de> Deaktivieren Sie die Äpfel aus Samen und Rinde, in Streifen geschnitten.
<G-vec00301-001-s049><clear_up.deaktivieren><en> Clear the apples from seeds and rind, cut into strips.
<G-vec00301-001-s050><clear_up.deaktivieren><de> Deaktivieren Sie alle Optionen.
<G-vec00301-001-s050><clear_up.deaktivieren><en> Clear all options.
<G-vec00301-001-s051><clear_up.deaktivieren><de> Aktivieren oder deaktivieren Sie Anzeigen von abgelehnten Netzwerken für Benutzer zulassen, um zu ermöglichen oder zu verhindern, dass Drahtlosnetzwerke im Dialogfeld Verbindung mit einem Netzwerk herstellen angezeigt werden.
<G-vec00301-001-s051><clear_up.deaktivieren><en> To enable or prevent wireless networks from displaying in the Connect to a network dialog box, either select or clear Allow user to view denied networks.
<G-vec00301-001-s052><clear_up.deaktivieren><de> Wenn der See steigt ein anderer 2 oder 3 Füße, Sonnenlicht wird nicht an die Wurzeln der Pflanzen, und sie werden sterben, und deaktivieren Sie die Oberfläche.
<G-vec00301-001-s052><clear_up.deaktivieren><en> When the lake level rises another 2 or 3 feet, sunlight won’t reach the roots of plants and they will die and clear out the surface.
<G-vec00301-001-s053><clear_up.deaktivieren><de> Wenn Sie jemals benötigt wird, um Gewalt zu stoppen, oder deaktivieren Sie die Daten / Cache aus einer App, Dies ist eine willkommene Ergänzung, da es viel zu finden Diese Seite macht, viel einfacher.
<G-vec00301-001-s053><clear_up.deaktivieren><en> If you’ve ever needed to force stop, or clear the data/cache from an app, this is a welcome addition as it makes finding this page much, much easier.
<G-vec00301-001-s054><clear_up.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00301-001-s054><clear_up.deaktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00301-001-s055><clear_up.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr, damit Ihr Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00301-001-s055><clear_up.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body could clear much more fat deposits.
<G-vec00301-001-s056><clear_up.deaktivieren><de> Deaktivieren Sie in der Schlüsseltabelle das Kontrollkästchen neben Abbild, um die gesamte Filterung zu beenden.
<G-vec00301-001-s056><clear_up.deaktivieren><en> To stop filtering altogether, in the key table, clear the check box next to Image.
<G-vec00246-002-s027><reactivate.deaktivieren><de> Klicke auf das Symbol mit den drei Punkten rechts neben dem Mitglied, das du deaktivieren möchtest.
<G-vec00246-002-s027><reactivate.deaktivieren><en> Click the three dots icon next to the account you want to reactivate.
<G-vec00279-002-s038><clear.deaktivieren><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00279-002-s038><clear.deaktivieren><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00279-002-s039><clear.deaktivieren><de> Deaktivieren Sie alle IIS Resource Kit Tools und Komponenten Kontrollkästchen außer dem KontrollkästchenMetabase Explorer 1.6 .
<G-vec00279-002-s039><clear.deaktivieren><en> Clear all the IIS Resource Kit Tools and components check boxes except the Metabase Explorer 1.6 check box.
<G-vec00279-002-s040><clear.deaktivieren><de> * Wort wischen: Deaktivieren Sie das Board für eine Power-Point-Bonus.
<G-vec00279-002-s040><clear.deaktivieren><en> * Word wipe: Clear the board for a Power Point bonus.
<G-vec00279-002-s041><clear.deaktivieren><de> Alles, was Sie brauchen, ist 45.000 Punkte und dann deaktivieren Sie alle Gelees.
<G-vec00279-002-s041><clear.deaktivieren><en> All you need is 45,000 points and then clear all the jellies.
<G-vec00279-002-s042><clear.deaktivieren><de> Wenn Sie die Einstellung jedoch auf ausgehende E-Mails beschränken möchten, können Sie alle Kontrollkästchen außer "Ausgehend" deaktivieren.
<G-vec00279-002-s042><clear.deaktivieren><en> However if, for example, you want to limit the Objectionable content policy to outbound mail, you can clear all check boxes except Outbound.
<G-vec00279-002-s043><clear.deaktivieren><de> Deaktivieren Sie Kontrollkästchen für Produkte, die nicht repariert werden sollen.
<G-vec00279-002-s043><clear.deaktivieren><en> Clear the check boxes for products you do not want to repair.
<G-vec00279-002-s044><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen neben dem Ordner, der auf diesem Gerät nicht angezeigt werden soll.
<G-vec00279-002-s044><clear.deaktivieren><en> Clear the check box next to the folder you want to keep off this device.
<G-vec00279-002-s045><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00279-002-s045><clear.deaktivieren><en> Clear this check box to hide these updates.
<G-vec00279-002-s046><clear.deaktivieren><de> Öffnen Sie die Dokumentbibliothek, und deaktivieren Sie alle Häkchen, sodass keine Dateien ausgewählt sind.
<G-vec00279-002-s046><clear.deaktivieren><en> Open the document library and clear all check marks so no files are selected.
<G-vec00279-002-s047><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen Exchange-Cache-Modus verwenden, klicken Sie auf Weiterund dann auf Fertig stellenklicken.
<G-vec00279-002-s047><clear.deaktivieren><en> Click to clear the Use Cached Exchange Mode checkbox, click Next, and then click Finish.
<G-vec00279-002-s048><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00279-002-s048><clear.deaktivieren><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00279-002-s049><clear.deaktivieren><de> Deaktivieren Sie alle acht spannende Levels und genießen das Spiel.
<G-vec00279-002-s049><clear.deaktivieren><en> Clear all eight exciting levels and enjoy the
<G-vec00279-002-s050><clear.deaktivieren><de> Deaktivieren Sie die Einstellung, die die Aktivierung blockiert.
<G-vec00279-002-s050><clear.deaktivieren><en> Clear the setting that blocks activation.
<G-vec00279-002-s051><clear.deaktivieren><de> Aktivieren Sie das Kontrollkästchen Temporäre Internetdateien, deaktivieren Sie die übrigen Kontrollkästchen, und klicken Sie auf Löschen.
<G-vec00279-002-s051><clear.deaktivieren><en> Select the Temporary Internet files check box, clear the other check boxes, and then click Delete.
<G-vec00279-002-s052><clear.deaktivieren><de> Wenn das Fenster Mit dem MobiLink-Server verbinden beim Aufruf des MobiLink-Monitors ohne Befehlszeilenoptionen nicht erscheinen soll, deaktivieren Sie das Kontrollkästchen zu dieser Option.
<G-vec00279-002-s052><clear.deaktivieren><en> If you do not want the Connect to MobiLink Server dialog to appear when you start the Monitor without command line options, clear the checkbox beside this option.
<G-vec00279-002-s053><clear.deaktivieren><de> Essen Sie alle das Gras und deaktivieren Sie die Ebene.
<G-vec00279-002-s053><clear.deaktivieren><en> Eat a grass and clear a level.
<G-vec00279-002-s054><clear.deaktivieren><de> Deaktivieren Sie alle Ebenen und gewinnen das Spiel zu.
<G-vec00279-002-s054><clear.deaktivieren><en> Clear series of exiting levels and have fun.
<G-vec00279-002-s055><clear.deaktivieren><de> Hinweis: Wenn Sie keine Tabellenüberschriften anzeigen möchten, können Sie sie später deaktivieren.
<G-vec00279-002-s055><clear.deaktivieren><en> If you do not want to display table headers, on the Tables tab, under Table Options, clear Header Row.
<G-vec00279-002-s056><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um den Andockbereich unten im Vegas-Fenster anzuzeigen.
<G-vec00279-002-s056><clear.deaktivieren><en> Clear the check box to display the docking area at the bottom of the window.
<G-vec00297-002-s112><opt.deaktivieren><de> Wenn Sie diese Cookies deaktivieren möchten, verwenden Sie bitte unser Einrichtungstool für Cookies.
<G-vec00297-002-s112><opt.deaktivieren><en> If you would like to opt out of these, please use our Cookie Settings Tool.
<G-vec00297-002-s113><opt.deaktivieren><de> Alternativ können Nutzer die Verwendung von Cookies durch Drittanbieter deaktivieren, indem sie die Deaktivierungsseite der Netzwerkwerbeinitiative aufrufen.
<G-vec00297-002-s113><opt.deaktivieren><en> (Alternatively you can point users to opt out of a third party vendor's use of cookies by visiting the Network Advertising Initiative opt out page.)
<G-vec00297-002-s114><opt.deaktivieren><de> Deaktivieren des Conversion-Cookies: Wenn Sie Cookies für Conversion-Tracking deaktivieren möchten, können Sie Ihren Browser so einstellen, dass Cookies von der Domain „googleadservices.com“ blockiert werden.
<G-vec00297-002-s114><opt.deaktivieren><en> How to opt out of the conversion cookie: If you want to disable conversion tracking cookies, you can set your browser to block cookies from the googleadservices.com domain.
<G-vec00297-002-s115><opt.deaktivieren><de> Nutzer können die Verwendung des DART-Cookies deaktivieren, indem sie die Datenschutzbestimmungen des Werbenetzwerks und Content-Werbenetzwerks von Google aufrufen.
<G-vec00297-002-s115><opt.deaktivieren><en> – Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy.
<G-vec00297-002-s116><opt.deaktivieren><de> Sie können die von uns verwendeten Google Analytics-Werbefunktionen deaktivieren, indem Sie Ihre Präferenzen angeben durch hier auf den interessenbezogenen Opt-Out-Link zu klicken.
<G-vec00297-002-s116><opt.deaktivieren><en> You can opt out of the Google Analytics Advertising Features we use by indicating your preference using the interest-based opt-out link here.
<G-vec00297-002-s117><opt.deaktivieren><de> Sie können Cookies für Conversion-Tracking auch deaktivieren, indem Sie Ihren Browser so einstellen, dass Cookies von der Domain „googleadservices.com“ blockiert werden.
<G-vec00297-002-s117><opt.deaktivieren><en> You can also specifically opt out of cookies for Conversion Tracking by setting your browser to reject cookies from the "googleadservices.com" domain.
<G-vec00297-002-s118><opt.deaktivieren><de> Nutzer können die Verwendung des DART-Cookies deaktivieren, in dem sie die Datenschutzbestimmungen des Werbenetzwerks und Content-Werbenetzwerks von Google aufrufen.
<G-vec00297-002-s118><opt.deaktivieren><en> Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy. Recent Articles
<G-vec00297-002-s119><opt.deaktivieren><de> Wenn Sie die oben genannten Google Analytics-Funktionen deaktivieren möchten, finden Sie weitere Informationen zum Abmelden unter hier.
<G-vec00297-002-s119><opt.deaktivieren><en> If you want to opt out of the above Google Analytics features, you can find more about signing out at here.
<G-vec00297-002-s120><opt.deaktivieren><de> Alternativ haben Sie die Möglichkeit, ein Browser-Plug-in zu installieren, um personalisierte Werbung zu deaktivieren.
<G-vec00297-002-s120><opt.deaktivieren><en> Alternatively, you can install a browser plugin to keep your preference to opt out of personalized ads.
<G-vec00297-002-s121><opt.deaktivieren><de> Es wird ein Opt-Out-Cookie gesetzt, der die Erfassung Ihrer Daten bei zukünftigen Besuchen dieser Website verhindert: Google Analytics deaktivieren.
<G-vec00297-002-s121><opt.deaktivieren><en> An opt-out cookie will be stored on your computer which prevents the future collection of your data when you visit this website: Click here to opt out of Google Analytics.
<G-vec00297-002-s122><opt.deaktivieren><de> Mit NAI- und IAB-Mitgliedern können Sie die Verhaltenswerbung deaktivieren.
<G-vec00297-002-s122><opt.deaktivieren><en> NAI and IAB members allow you to opt out of the behavioral advertising.
<G-vec00297-002-s123><opt.deaktivieren><de> Sie können die automatische Profilerstellung jederzeit deaktivieren (siehe Abschnitt über Ihre Rechte).
<G-vec00297-002-s123><opt.deaktivieren><en> You may opt out of automatic profiling at any time (see the section about your rights).
<G-vec00297-002-s124><opt.deaktivieren><de> Unsere Kunden können die E-Mail-Kommunikation über die gesendeten E-Mails oder auf unserer Website deaktivieren.
<G-vec00297-002-s124><opt.deaktivieren><en> Subscribers can opt out of email communication via the emails sent or on our site.
<G-vec00297-002-s125><opt.deaktivieren><de> Des Weiteren können Sie in den Einstellungen bei Google personalisierte Werbung deaktivieren.
<G-vec00297-002-s125><opt.deaktivieren><en> Furthermore you can opt out of interest-based advertising in the Google settings.
<G-vec00297-002-s126><opt.deaktivieren><de> Nach dem Deaktivieren erhalten Sie weiterhin Werbung, die jedoch möglicherweise nicht mehr Ihren Interessen angepasst ist.
<G-vec00297-002-s126><opt.deaktivieren><en> If you opt out, you will still receive ads but they may not be as relevant to you and your interests.
<G-vec00297-002-s127><opt.deaktivieren><de> Zur Deaktivierung von interessenbasierter Werbung auf Android öffnen Sie Ihre Google-Einstellungen und aktivieren unter „Anzeigen" die Option „Personalisierte Werbung deaktivieren".
<G-vec00297-002-s127><opt.deaktivieren><en> To opt-out of Google interest-based ads on Android, open your Google Settings app > Ads > Enable "Opt out of interest-based advertising"
<G-vec00297-002-s128><opt.deaktivieren><de> Wenn Sie auf das Wort „Anzeige“ oder den Link klicken, gelangen Sie auf eine Website, auf der Sie die Verwendung von Daten über Ihren Browserverlauf, die für verhaltensbasierte Online-Werbung verwendet werden, verwalten oder deaktivieren können.
<G-vec00297-002-s128><opt.deaktivieren><en> Clicking on the icon or link will take you to a website where you can manage or opt out of the use of data about your browsing history that is used for the delivery of online behavioural advertising.
<G-vec00297-002-s129><opt.deaktivieren><de> Bitte beachten Sie, dass Sie womöglich weiterhin andere Arten von Werbung erhalten, wenn Sie bestimmte Arten von interessensbasierter Werbung deaktivieren können.
<G-vec00297-002-s129><opt.deaktivieren><en> Please be aware that, even if you are able to opt out of certain kinds of Interest-based Advertising, you may continue to receive other types of ads.
<G-vec00297-002-s130><opt.deaktivieren><de> Hier können Sie auch bestimmte Google-Werbedienste deaktivieren.
<G-vec00297-002-s130><opt.deaktivieren><en> You can also opt out of certain Google advertising services here.
