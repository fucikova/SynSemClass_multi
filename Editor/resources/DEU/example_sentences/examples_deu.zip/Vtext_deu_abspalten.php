<G-vec00599-002-s013><disintegrate.abspalten><de> Sie würde euren Mond zerstören oder vielmehr die Anziehung, die euren Mond festhält, indem sie ihn dazu bringen würde, sich abzuspalten und auseinanderzufallen.
<G-vec00599-002-s013><disintegrate.abspalten><en> It would destroy your Moon, or rather, destroy the attraction holding your Moon, causing it to spin off and disintegrate.
