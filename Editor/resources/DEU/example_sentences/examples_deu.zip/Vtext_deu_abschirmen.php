<G-vec00047-002-s030><isolate.abschirmen><de> Jahrhundertelang versuchte China diese Entwicklung aufzuhalten - sich gegen die Außenwelt abzuschirmen.
<G-vec00047-002-s030><isolate.abschirmen><en> For hundreds of years China tried to bring this development to a halt - tried to isolate itself from the outside world.
<G-vec00047-002-s031><isolate.abschirmen><de> Ins kompakte Design des SMX-15 wurde eine Schock-absorbierende Blitzschuh-Halterung integriert, um das Mikrofon vom Kamera-Zoommotor und Bedienungsgeräuschen bestmöglich abzuschirmen.
<G-vec00047-002-s031><isolate.abschirmen><en> Integrated into the design of the SMX-15 is a custom made, shock absorbing shoe mount to isolate the microphone from camera motor and handling noise.
