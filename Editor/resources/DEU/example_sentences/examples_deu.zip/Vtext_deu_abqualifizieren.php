<G-vec00555-002-s003><disqualify.abqualifizieren><de> Es helfe dabei aber nicht weiter, andere EU-Länder von Deutschland aus "moralisch abzuqualifizieren".
<G-vec00555-002-s003><disqualify.abqualifizieren><en> However, it does not help when Germans "morally disqualify" other EU countries.
