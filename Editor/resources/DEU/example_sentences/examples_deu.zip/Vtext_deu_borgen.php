<G-vec00505-001-s089><borrow.borgen><de> Aber zu schnell zurückerstatten, wenn man nicht übertriebene Monatszahlungen stützen kann, das sagen möchte, kleiner zu borgen.
<G-vec00505-001-s089><borrow.borgen><en> But to quickly refund, if one cannot support exorbitant monthly payments, that wants to say to borrow less.
<G-vec00505-001-s090><borrow.borgen><de> Wenn niemand die Kapital borgen möchte, um Käufe abzuschließen dann, ist die Verwendbarkeit der Kapital in den Finanzinstituten irrelevant.
<G-vec00505-001-s090><borrow.borgen><en> If no one wants to borrow the funds to make purchases then the availability of funds in the financial institutions is irrelevant.
<G-vec00505-001-s091><borrow.borgen><de> Solange der Zinssatz deutlich unter der Profitrate liegt, werden Unternehmer voraussichtlich borgen und investieren, bis sich diese Lücke schließt.
<G-vec00505-001-s091><borrow.borgen><en> As long as the interest rate is substantially below the profit rate entrepreneurs will presumably borrow and invest until this gap is eliminated.
<G-vec00505-001-s092><borrow.borgen><de> "Und der Zusammenhang bestätigt das richtige Verständnis, denn Jesus fährt fort, indem er sagt: ""Gebt demjenigen der euch bittet und wenn jemand etwas von euch borgen möchte, dann weist ihn nicht ab."
<G-vec00505-001-s092><borrow.borgen><en> "And the context confirms the right understanding for Jesus continues: ""Give to him who asks of you, and if someone wants to borrow something, don't turn them away."
<G-vec00505-001-s093><borrow.borgen><de> "Das tiefe Verständnis von ""Temperatur"" ist der Schlüssel, um die Tür zu öffnen, keine Temperaturregelung, wird nicht in der Lage sein, den einzigartigen Geschmack von Schokolade und weichen Geschmack zu inspirieren, wird auch nicht in der Lage sein zu borgen Schokolade bieten das Geständnis der Liebe."
<G-vec00505-001-s093><borrow.borgen><en> "The profound understanding of, ""temperature"" is the key to open the door, no temperature control, will not be able to inspire the unique flavor of chocolate and smooth taste, also won't be able to borrow chocolate offer the confession of love."
<G-vec00505-001-s094><borrow.borgen><de> Die Menge des Geldes, das Sie borgen, wird Direktion genannt, und Interesse ist die Kosten für das Borgen des Geldes.
<G-vec00505-001-s094><borrow.borgen><en> The amount of money you borrow is called principal, and interest is the cost for borrowing the money.
<G-vec00505-001-s095><borrow.borgen><de> Wenn Sie das Geld borgen werden, um die Expansion Ihres Geschäfts zu finanzieren, müssen Sie überprüfen, ob Sie nicht sich in eine Bargeldknirschensituation erhalten werden.
<G-vec00505-001-s095><borrow.borgen><en> If you are going to borrow the money to finance the expansion of your business, you need to make sure that you are not going to get yourself into a cash crunch situation.
<G-vec00505-001-s096><borrow.borgen><de> So hinter dem barbarischen Namen der nachfüllbaren Hypothek, möchte Bercy die Franzosen anregen, ihre europäischen Nachbarn soviel wie zu borgen.
<G-vec00505-001-s096><borrow.borgen><en> The real mortgage will be an instrument to reach that point. Thus, behind the barbarian name of refillable mortgage, Bercy wants to encourage the French to borrow as much as their European neighbors.
<G-vec00505-001-s097><borrow.borgen><de> Sie fuhren fort, zu borgen.
<G-vec00505-001-s097><borrow.borgen><en> They continued to borrow.
<G-vec00505-001-s098><borrow.borgen><de> "Wenn Sie nicht ein Mac-Benutzer, sondern möchte neues Design al Yosemite-System und wollen zu ""borgen"" Ihr System Windows- Sie können herunterladen und installieren Dritter Thema Swift OS X Yosemite für Windows-7 si Windows-8 / 8.1 ."
<G-vec00505-001-s098><borrow.borgen><en> "If you are not a Mac user but would like new design al Yosemite system and want to ""borrow"" your system Windows You can download and install third-party theme Swift OS X Yosemite for Windows 7 si Windows 8 / 8.1 ."
<G-vec00505-001-s099><borrow.borgen><de> Aber wer würde borgen wollen, um die Kapazität in einer Rezession zu erhöhen.
<G-vec00505-001-s099><borrow.borgen><en> But who would want to borrow to increase capacity in a recession.
<G-vec00505-001-s100><borrow.borgen><de> 2007-11-13 22:16:19 - Geheimnisse u. Nutzen der gesicherten Darlehen Geld zu borgen ist in Großbritannien seit einigen Jahren immer mehr populär geworden, und dieses liegt an der Tatsache teils, der es weit einfacher geworden ist, Geld zu borgen.
<G-vec00505-001-s100><borrow.borgen><en> 2007-11-13 22:16:19 - Secrets & benefits of secured loans Borrowing money has become more and more popular in the UK over recent years, and this is partly due to the fact that it has become far easier to borrow money.
<G-vec00505-001-s101><borrow.borgen><de> Wir weisen darauf hin, denn wir glauben, dass Sie es nicht wissen, dass das Sindicato Mexicano de Electricistas (SME) (= mexikanische Elektrikergewerkschaft) sich geweigert hat, uns, dem CNI und der EZLN, eines ihrer Gebäude im DF zu borgen, damit wir dort den kulturellen Teil des Ersten Weltfestivals der Widerstände und der Rebellionen gegen den Kapitalismus mit dem Titel ´Wo die von oben zerstören, widmen sich die von unten dem Wideraufbau´ abhalten könnten.
<G-vec00505-001-s101><borrow.borgen><en> We would like to let you know, in case you haven’t heard, that the Mexican Electrical Union (SME) refused to let us, the CNI and the EZLN, borrow one of their facilities for the celebration of cultural events in Mexico City during the First World Festival of Resistance and Rebellion against Capitalism: «Where Those Above Destroy, We Below Rebuild.»
<G-vec00505-001-s102><borrow.borgen><de> Also können die Banken wieder von der Schweiz borgen und weiter Geld in die Schweiz schicken.
<G-vec00505-001-s102><borrow.borgen><en> So the banks will again borrow from Switzerland and send the money again to Switzerland.
<G-vec00505-001-s103><borrow.borgen><de> Wir borgen die vom Lender gelieferten Titel, um diese sogleich an den Borrower weiterzureichen.
<G-vec00505-001-s103><borrow.borgen><en> We borrow the securities provided by the lender and pass them on immediately to the borrower.
<G-vec00505-001-s104><borrow.borgen><de> "Folglich müssen Sie andere Wege finden, Ihrer Web site die Belichtung zu geben, die sie erfordert, um Verkehr zu erzeugen.One-way ist ""borgen"" den Verkehr von vorhandenen Aufstellungsorten."
<G-vec00505-001-s104><borrow.borgen><en> "Therefore you will have to find other ways to give your website the exposure it requires to generate traffic.One way is to "" borrow"" the traffic from existing sites."
<G-vec00505-001-s105><borrow.borgen><de> Und du wirst vielen Völkern leihen; du aber wirst von niemand borgen.
<G-vec00505-001-s105><borrow.borgen><en> You shall lend to many nations, but you shall not borrow.
<G-vec00505-001-s106><borrow.borgen><de> Sie nötigten die Gemeinfreien, die die Steuerlast erdrückte, bei ihnen zu borgen und zuerst tatsächlich als Schuldner, dann rechtlich als Hörige sich ihrer Freiheit zu begeben.
<G-vec00505-001-s106><borrow.borgen><en> They forced the common freemen, overwhelmed by the taxes which they had themselves imposed, to borrow of them, and then, first as their debtors, afterward legally as their serfs, to surrender their liberty.
<G-vec00505-001-s107><borrow.borgen><de> Sie können nicht anlegen und können nicht borgen, und zunehmend können sie auch nicht mehr arbeiten.
<G-vec00505-001-s107><borrow.borgen><en> They can not save and they can not borrow, and in increasing numbers, they can not work.
<G-vec00505-001-s108><borrow.borgen><de> Mat 5:42 Wer dich bittet, dem gib; wer von dir borgen will, den weise nicht ab.
<G-vec00505-001-s108><borrow.borgen><en> 42 Give to the one who asks you, and do not turn away from the one who wants to borrow from you.
<G-vec00505-001-s109><borrow.borgen><de> 42 Dem, der dich bittet, gib; wenn einer von dir borgen will, weise ihn nicht ab.
<G-vec00505-001-s109><borrow.borgen><en> 42 Whoever asks of you, give to him. And if anyone would borrow from you, do not turn away from him.
<G-vec00505-001-s119><borrow.borgen><de> Bitte schlucke deinen Stolz herunter, Sollte ich Sachen haben, die du dir borgen musst.
<G-vec00505-001-s119><borrow.borgen><en> Please swallow your pride, if have things you need to borrow.
<G-vec00505-001-s120><borrow.borgen><de> Frage nach une opinion oder ob ein Freund CDs hat, die du dir borgen kannst.
<G-vec00505-001-s120><borrow.borgen><en> Ask around for une opinion or if a friend has a set of CDs or a program you can borrow.
<G-vec00505-001-s254><borrow.borgen><de> Praktisch für alle, die sich etwas borgen möchten, ohne dabei erwischt zu werden.
<G-vec00505-001-s254><borrow.borgen><en> Useful for those wishing to borrow items without getting caught.
<G-vec00505-001-s255><borrow.borgen><de> "Investmentbanken streichen für ihre Beratungstätigkeit und die Fremdkapitalvermittlung Honorare und Zinsen ein, aber der wirkliche warme Regen fällt auf die Private Equity Firmen, die neben dem ""carried interest"" bei einem erfolgreichen ""Ausstieg"" Verwaltungs-, Übernahme- und ""Finanzberatungs""honorare kassieren, wann immer sie sich Geld borgen."
<G-vec00505-001-s255><borrow.borgen><en> "Investment banks rake in fees and interest from advising on the deals and trading the debt, but the real bonanza falls to the private equity firms, who in addition to the ""carried interest"" from a successful ""exit"" earn management fees, acquisition fees and ""financial advisory"" fees whenever they borrow money."
<G-vec00505-001-s286><borrow.borgen><de> 5:42 Gib dem, der dich bittet, und weise den nicht ab, der von dir borgen will.
<G-vec00505-001-s286><borrow.borgen><en> 5:42 To him that asks of thee give, and from him that desires to borrow of thee turn not away.
<G-vec00505-001-s287><borrow.borgen><de> Gib dem, der dich bittet, und weise den nicht ab, der von dir borgen will.
<G-vec00505-001-s287><borrow.borgen><en> Give to him who asks you, and don't turn away him who desires to borrow from you.
<G-vec00505-001-s288><borrow.borgen><de> 42 Gib dem, der dich bittet, und weise den nicht ab, (O. wende dich nicht von dem ab) der von dir borgen will.
<G-vec00505-001-s288><borrow.borgen><en> 42 To him that asks of thee give, and from him that desires to borrow of thee turn not away.
