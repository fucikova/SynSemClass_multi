<G-vec00081-001-s280><cease.enden><de> Sie lässt uns gleichzeitig hoffen, dass die Gewalt in Kenia nun umgehend ein Ende findet.
<G-vec00081-001-s280><cease.enden><en> At the same time, it gives us reason to hope that the violence in Kenya will cease without delay.
<G-vec00081-001-s281><cease.enden><de> 33:28 Und ich werde das Land zur Wüste und Verwüstung machen, und der Stolz seiner Stärke wird ein Ende haben; und die Berge Israels werden wüst sein, so daß niemand darüber hinwandert.
<G-vec00081-001-s281><cease.enden><en> 33:28 I will make the land a desolation and an astonishment; and the pride of her power shall cease; and the mountains of Israel shall be desolate, so that none shall pass through.
<G-vec00081-001-s282><cease.enden><de> "Und als 1901 mit Francis Valentine Woodhouse der letzte der zwölf 1835 ausgesonderten Apostel starb, durften auch die überlebenden Koadjutoren keine apostolischen Funktionen mehr durchführen.Somit stellen wir fest, dass in einer Zeit, als die Apostel mit dem Ende ihrer Tätigkeit rechneten, soweit möglich noch nachgeholt wurde, was bisher an den ""Ordnungen"", also an den Ämtern der Universalkirche, fehlte."
<G-vec00081-001-s282><cease.enden><en> "When Francis Valentine Woodhouse, the last of the Apostles separated in 1835, died in 1901 the surviving Coadjutors were not allowed to fulfil any apostolic functions.Thus we find that at a time when they felt sure that their ministry would cease, the Apostles took steps towards a ""perfection of the ordinances"" by appointing those ministers of the Uni-versal Church that were still missing according to the original plan."
<G-vec00081-001-s283><cease.enden><de> Pro 22:10 Den Spötter treibe fort, dann geht auch der Streit mit weg, und Zanken und Schimpfen haben ein Ende.
<G-vec00081-001-s283><cease.enden><en> 10 Drive out the scoffer, and contention will go out, Even strife and dishonor will cease.
<G-vec00081-001-s284><cease.enden><de> Denn es ist noch gar um ein kleines zu tun, so wird die Ungnade und mein Zorn über ihre Untugend ein Ende haben.
<G-vec00081-001-s284><cease.enden><en> For yet a very little while, and the indignation shall cease, and mine anger in their destruction.
<G-vec00081-001-s285><cease.enden><de> Ihre gegenseitigen Beziehungen sind zu Ende mit dem Verfalltag des zwischen ihnen abgeschloßnen Vertrags.
<G-vec00081-001-s285><cease.enden><en> Their mutual relations cease with the termination of their mutual contract.
<G-vec00081-001-s286><cease.enden><de> 30:18 Thachphanhes wird einen finstern Tag haben, wenn ich das Joch Ägyptens daselbst zerbrechen werde, daß die Hoffart seiner Macht darin ein Ende habe; sie wird mit Wolken bedeckt werden, und ihre Töchter werden gefangen weggeführt werden.
<G-vec00081-001-s286><cease.enden><en> 30:18 At Tehaphnehes also the day shall withdraw itself, when I shall break there the yokes of Egypt, and the pride of her power shall cease in her: as for her, a cloud shall cover her, and her daughters shall go into captivity.
<G-vec00081-001-s287><cease.enden><de> 2:11 Und ich will ein Ende machen mit allen ihren Freuden, Festen, Neumonden, Sabbaten und allen ihren Feiertagen.
<G-vec00081-001-s287><cease.enden><en> 2:11 I will also cause all her delight to cease, her feast days, her new moons, and her sabbaths, and all her solemn feasts.
<G-vec00081-001-s288><cease.enden><de> 7:24 So will ich die Ärgsten unter den Heiden kommen lassen, daß sie sollen ihre Häuser einnehmen, und will der Hoffart der Gewaltigen ein Ende machen und ihre Heiligtümer entheiligen.
<G-vec00081-001-s288><cease.enden><en> 7:24 Wherefore I will bring the worst of the heathen, and they shall possess their houses: I will also make the pomp of the strong to cease; and their holy places shall be defiled.
<G-vec00081-001-s289><cease.enden><de> Und so ist wahrlich der Mensch schon eine Miniaturschöpfung des gesamten Schöpfungsmenschen, ein unvergleichliches Wunder für die geistig schauende Seele, die kein Ende finden wird, sich selbst zu betrachten....
<G-vec00081-001-s289><cease.enden><en> And thus the human being is in fact already a miniature creation of the great universal man; it is a matchless wonder for a soul with spiritual vision, which will never cease contemplating itself....
<G-vec00081-001-s290><cease.enden><de> "Die USA baten Israel bei den Einfällen keine zivilen Opfer zu hinterlassen... währenddessen warnen sie die Hamas, die Raketenangriffe zu stoppen, um ""der Gewalt ein Ende zu bereiten""."
<G-vec00081-001-s290><cease.enden><en> "The United States begged that Israel's incursions do not bring about civilian casualties... while warning Hamas to stop its rocket attacks in order ""to cease the violence."""
<G-vec00081-001-s291><cease.enden><de> Über diese Welt sagte Gott durch den Propheten Jesaja: „Ich werde die Welt für ihre Schlechtigkeit und die bösen Menschen für ihre Sünden bestrafen und dem Hochmut der Stolzen werde Ich ein Ende machen und die Arroganz der Unterdrücker demütigen “ (Jesaja 13:11).
<G-vec00081-001-s291><cease.enden><en> "Through the prophet Isaiah, God said about this world: ""And I will punish the world for evil, and the wicked for their iniquity; and I will make the arrogance of the proud to cease,and will bring low the haughtiness of the violent "" (Isaiah 13:11d)."
<G-vec00081-001-s292><cease.enden><de> 12:23 Darum sprich zu ihnen: So spricht der Herr, Jehova: Ich will diesem Spruche ein Ende machen, und man soll ihn nicht mehr als Spruch gebrauchen in Israel; sondern rede zu ihnen: Nahe sind die Tage und das Wort eines jeden Gesichts.
<G-vec00081-001-s292><cease.enden><en> 12:23 Tell them therefore, Thus says the Lord Yahweh: I will make this proverb to cease, and they shall no more use it as a proverb in Israel; but tell them, The days are at hand, and the fulfillment of every vision.
<G-vec00081-001-s293><cease.enden><de> 28 Denn ich will das Land gar verwüsten und seiner Hoffart und Macht ein Ende machen, daß das Gebirge Israel so wüst werde, daß niemand dadurchgehe.
<G-vec00081-001-s293><cease.enden><en> 28 And I will make the land a desolation and an astonishment; and the pride of her power shall cease; and the mountains of Israel shall be desolate, so that none shall pass through.
<G-vec00081-001-s294><cease.enden><de> 48:35 Und ich mache ein Ende in Moab, spricht Jehova, dem, der auf die Höhe steigt und seinen Göttern räuchert.
<G-vec00081-001-s294><cease.enden><en> 48:35 Moreover I will cause to cease in Moab, says Yahweh, him who offers in the high place, and him who burns incense to his gods.
<G-vec00081-001-s295><cease.enden><de> 30:18 Thachphanhes wird einen finstern Tag haben, wenn ich das Joch Ägyptens daselbst zerbrechen werde, daß die Hoffart seiner Macht darin ein Ende habe; sie wird mit Wolken bedeckt werden, und ihre Töchter werden gefangen weggeführt werden.
<G-vec00081-001-s295><cease.enden><en> 30:18 At Tehaphnehes also the day shall be darkened, when I shall break there the yokes of Egypt: and the pomp of her strength shall cease in her: as for her, a cloud shall cover her, and her daughters shall go into captivity.
<G-vec00081-001-s296><cease.enden><de> Und ich mache das Land zur Öde und zum Grausen, und der Stolz seiner Macht wird ein Ende haben; und die Berge Israels werden wüst daliegen, so daß niemand darüber hinwandert.
<G-vec00081-001-s296><cease.enden><en> I will make the land a desolation and an astonishment; and the pride of her power shall cease; and the mountains of Israel shall be desolate, so that none shall pass through.
<G-vec00081-001-s297><cease.enden><de> Wie jede Wirklichkeit einen Anfang und ein Ende hat, so wird der Staat, der aus Not beginnt, sein Ende finden, nur wann es die Notwendigkeit nicht mehr geben wird.
<G-vec00081-001-s297><cease.enden><en> 385. As every reality has a beginning and an end, State was established out of necessity, and will cease to exist only when there will no longer be the need for it.
<G-vec00081-001-s298><cease.enden><de> Dann wird er Dinge erfahren, die in keinem Buche geschrieben stehen, und er wird immer tiefer eindringen dürfen in göttliche Weisheit, und er wird des Staunens kein Ende finden....
<G-vec00081-001-s298><cease.enden><en> Then he will learn things which are not written in any book, and he may penetrate divine wisdom ever more and will never cease to be amazed....
<G-vec00081-001-s303><cease.enden><de> Korruption wird enden – es wird keinen Platz geben, für die Unehrlichen, um sich zu verbergen.
<G-vec00081-001-s303><cease.enden><en> Corruption will cease - there will be no place for the dishonest to hide.
<G-vec00081-001-s304><cease.enden><de> Aufgrund von Einschränkungen der Lizenzgeber kann der Zugang zu den Inhalten über den PSB enden (siehe Abschnitt 7.4).
<G-vec00081-001-s304><cease.enden><en> Due to Licensor restrictions, access to the Content via the PSA may cease (see Section 7.4).
<G-vec00081-001-s305><cease.enden><de> Nach einigen Tagen, am Fest des Unbefleckten Herzens Mariens, enden die feindlichen Auseinandersetzungen in Kroatien.
<G-vec00081-001-s305><cease.enden><en> A few days later, on the feast of the Immaculate Heart of Mary, the hostilities cease in Croatia.
<G-vec00081-001-s306><cease.enden><de> Vor der Eucharistie betrachten die Gläubigen Jesus in der Stunde seiner Einsamkeit und beten, daß alle Einsamkeit auf der Welt enden möge.
<G-vec00081-001-s306><cease.enden><en> Before the Eucharist, the faithful contemplate Jesus in the hour of his solitude and pray that all the loneliness in the world may cease.
<G-vec00081-001-s307><cease.enden><de> Als er die Wahrheit über die Verfolgung sah, sagte er: „Diese brutale Verfolgung sollte ganz schnell enden.
<G-vec00081-001-s307><cease.enden><en> "After seeing the truth of the persecution, he said: ""This sort of brutal persecution should quickly cease."
<G-vec00081-001-s308><cease.enden><de> Sie kam in Abhängigkeit von Ursachen, Wenn die Ursache verschwindet, dann wird Sie enden.
<G-vec00081-001-s308><cease.enden><en> It has come to be dependent on a cause, When the cause dissolves then it will cease.
<G-vec00081-001-s309><cease.enden><de> Für diese Personen wird die Welt enden.
<G-vec00081-001-s309><cease.enden><en> For those individuals, the world will cease.
<G-vec00081-001-s310><cease.enden><de> Es schien, als würden die Wunder niemals enden.
<G-vec00081-001-s310><cease.enden><en> It seemed that wonders would never cease.
<G-vec00081-001-s311><cease.enden><de> (2) Nimmt ein Richter die Wahl in den Deutschen Bundestag oder in die gesetzgebende Körperschaft eines Landes an oder wird ein Richter mit seiner Zustimmung zum Mitglied der Bundesregierung oder der Regierung eines Landes ernannt, so enden das Recht und die Pflicht zur Wahrnehmung des Richteramts ohne gerichtliche Entscheidung nach näherer Bestimmung der Gesetze.
<G-vec00081-001-s311><cease.enden><en> (2) Where a judge accepts election to the German Bundestag or to the legislative body of a Land or where the judge is appointed, with his own consent, a member of the Federal Government or of the government of a Land, the right and the duty to hold judicial office shall cease without a court decision and in accordance with specific statutory provision.
<G-vec00081-001-s312><cease.enden><de> Korruption wird enden – es wird keinen Platz geben, für die Unehrlichen, um sich zu verbergen.
<G-vec00081-001-s312><cease.enden><en> Corruption will cease — there will be no place for the dishonest to hide.
<G-vec00081-001-s313><cease.enden><de> Hier ist der Ruhepunkt, auch bekannt als Zentrum der Schwerkraft in Erden oder Sonnen wo Bewegung und Krümmung enden.
<G-vec00081-001-s313><cease.enden><en> This is the point of rest which is known as the center of gravity in earths or suns where motion and curvature cease.
<G-vec00081-001-s314><cease.enden><de> Die religiöse Gleichgültigkeit der westlichen Kultur wird enden, und säkular orientierte Menschen sind dann gezwungen, zwischen dem allumfassenden Allerweltsgott und dem Gott der Bibel zu wählen.
<G-vec00081-001-s314><cease.enden><en> The present religious indifference of secular Western culture will cease as materially-oriented people will be forced to choose between the universal god and the God of the Bible.
<G-vec00081-001-s315><cease.enden><de> Sicher, es gibt Offline-Entwicklungen, die sich auch in der Online-Sphäre spiegeln – entscheidend ist jedoch, wo die Parallelen enden, genauer: wo der Spiegeleffekt seine Bedeutung verliert und wo die Übersetzung beginnt.
<G-vec00081-001-s315><cease.enden><en> Certainly, there are offline developments that are reflected in the online sphere – but what is decisive is where the parallels cease, or, to be more precise, where the reflection effect loses its meaning and where the translation begins.
<G-vec00081-001-s316><cease.enden><de> Obwohl Gottes Liebe für alle seine Kinder nie enden wird, wird er sie, mit Bedauern, von ihm weggehen lassen, nur weil er ihre Wahl respektiert, eine Wahl auf freiem Willen, den er ihnen seit ihrer Empfängnis gewährt hat.
<G-vec00081-001-s316><cease.enden><en> Although God's love for all His children will never cease, He will, with regret, let them go awayfrom Him only because He respects their choice based on the freewill that He has granted them since they were conceived.
<G-vec00081-001-s317><cease.enden><de> Treibe den Spötter hinaus, und der Zank wird fort gehen; Selbst Hader und Schmähung werden enden (22:10).
<G-vec00081-001-s317><cease.enden><en> Drive out the scoffer, and contention will go out, Even strife and dishonor will cease (22:10).
<G-vec00081-001-s318><cease.enden><de> Dieser heilige Prozess wird weitergehen und erst dann enden, wenn ihr erfolgreich durch die wundersamen Nuancen der Kristall-LICHT-Kammern navigiert seid.
<G-vec00081-001-s318><cease.enden><en> This sacred process is to continue and will cease once you have successfully navigated the wondrous nuances of the Crystal Light Chambers.
<G-vec00081-001-s319><cease.enden><de> Somit wird Heilung nie enden.
<G-vec00081-001-s319><cease.enden><en> So healing will never cease.
<G-vec00081-001-s320><cease.enden><de> Das bedeutet also,... verstehst du Blossom, dass eine Zeit kommen muss, wo das endet.
<G-vec00081-001-s320><cease.enden><en> This therefore, means... do you see Blossom? That there has to come a time when this shall cease.
<G-vec00081-001-s321><cease.enden><de> Im Falle einer solchen Zuwiderhandlung endet unverzüglich Ihr Recht, die App oder Website zu nutzen.
<G-vec00081-001-s321><cease.enden><en> In the event of such a breach, your right to use the App or Website will cease immediately.
<G-vec00081-001-s322><cease.enden><de> a. die Übergabe der Aufzeichnungen nach Artikel 39 und der wichtigen Unterlagen ans Institut oder deren Aufbewahrung vorsehen, wenn die Geschäftstätigkeit vor Ablauf der Aufbewahrungsfrist endet; b. für Eigenblutspenden Ausnahmen von der Aufbewahrungspflicht vorsehen.
<G-vec00081-001-s322><cease.enden><en> a. make provision for the transfer to the Agency, or the archiving, of the records referred to in Article 39 and any important documents, should the establishment cease its activity prior to the expiry of the archiving period;
<G-vec00081-001-s323><cease.enden><de> 8.4 Die Gefahrtragung des Mieters endet, sobald der Mietgegenstand wieder auf dem Betriebsgelände des Vermieters aus Anlass der oder im Anschluss an die Beendigung dieses Vertrages zurück übergeben wird (Tag der tatsächlichen Rückgabe).
<G-vec00081-001-s323><cease.enden><en> 8.4 The Lessee shall cease to bear the risk as soon as the machine has been returned to the Lessor's premises due to or following the end of this Agreement (date of the actual return).
<G-vec00081-001-s324><cease.enden><de> Im Falle einer solchen Kündigung endet Ihr Recht auf Benutzung der Website unverzüglich.
<G-vec00081-001-s324><cease.enden><en> Upon any such termination, your right to use the Site will immediately cease.
<G-vec00081-001-s325><cease.enden><de> Das Ego ist ein Gebilde der Natur; doch ist es kein Gebilde der stofflichen Natur allein und endet daher nicht mit dem Körper.
<G-vec00081-001-s325><cease.enden><en> The ego is a formation of Nature; but it is not a formation of physical nature alone, therefore it does not cease with the body.
<G-vec00081-001-s326><cease.enden><de> Aus der Beendigung von Geburt, endet dann alles Altern und Tod, Kummer, Wehklage, Schmerz, Bedrängnis und Verzweiflung.
<G-vec00081-001-s326><cease.enden><en> From the cessation of birth, then aging & death, sorrow, lamentation, pain, distress, & despair all cease.
