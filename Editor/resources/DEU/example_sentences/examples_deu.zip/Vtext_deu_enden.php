<G-vec00081-001-s280><cease.enden><de> Sie lässt uns gleichzeitig hoffen, dass die Gewalt in Kenia nun umgehend ein Ende findet.
<G-vec00081-001-s280><cease.enden><en> At the same time, it gives us reason to hope that the violence in Kenya will cease without delay.
<G-vec00081-001-s281><cease.enden><de> 33:28 Und ich werde das Land zur Wüste und Verwüstung machen, und der Stolz seiner Stärke wird ein Ende haben; und die Berge Israels werden wüst sein, so daß niemand darüber hinwandert.
<G-vec00081-001-s281><cease.enden><en> 33:28 I will make the land a desolation and an astonishment; and the pride of her power shall cease; and the mountains of Israel shall be desolate, so that none shall pass through.
<G-vec00081-001-s282><cease.enden><de> "Und als 1901 mit Francis Valentine Woodhouse der letzte der zwölf 1835 ausgesonderten Apostel starb, durften auch die überlebenden Koadjutoren keine apostolischen Funktionen mehr durchführen.Somit stellen wir fest, dass in einer Zeit, als die Apostel mit dem Ende ihrer Tätigkeit rechneten, soweit möglich noch nachgeholt wurde, was bisher an den ""Ordnungen"", also an den Ämtern der Universalkirche, fehlte."
<G-vec00081-001-s282><cease.enden><en> "When Francis Valentine Woodhouse, the last of the Apostles separated in 1835, died in 1901 the surviving Coadjutors were not allowed to fulfil any apostolic functions.Thus we find that at a time when they felt sure that their ministry would cease, the Apostles took steps towards a ""perfection of the ordinances"" by appointing those ministers of the Uni-versal Church that were still missing according to the original plan."
<G-vec00081-001-s283><cease.enden><de> Pro 22:10 Den Spötter treibe fort, dann geht auch der Streit mit weg, und Zanken und Schimpfen haben ein Ende.
<G-vec00081-001-s283><cease.enden><en> 10 Drive out the scoffer, and contention will go out, Even strife and dishonor will cease.
<G-vec00081-001-s284><cease.enden><de> Denn es ist noch gar um ein kleines zu tun, so wird die Ungnade und mein Zorn über ihre Untugend ein Ende haben.
<G-vec00081-001-s284><cease.enden><en> For yet a very little while, and the indignation shall cease, and mine anger in their destruction.
<G-vec00081-001-s285><cease.enden><de> Ihre gegenseitigen Beziehungen sind zu Ende mit dem Verfalltag des zwischen ihnen abgeschloßnen Vertrags.
<G-vec00081-001-s285><cease.enden><en> Their mutual relations cease with the termination of their mutual contract.
<G-vec00081-001-s286><cease.enden><de> 30:18 Thachphanhes wird einen finstern Tag haben, wenn ich das Joch Ägyptens daselbst zerbrechen werde, daß die Hoffart seiner Macht darin ein Ende habe; sie wird mit Wolken bedeckt werden, und ihre Töchter werden gefangen weggeführt werden.
<G-vec00081-001-s286><cease.enden><en> 30:18 At Tehaphnehes also the day shall withdraw itself, when I shall break there the yokes of Egypt, and the pride of her power shall cease in her: as for her, a cloud shall cover her, and her daughters shall go into captivity.
<G-vec00081-001-s287><cease.enden><de> 2:11 Und ich will ein Ende machen mit allen ihren Freuden, Festen, Neumonden, Sabbaten und allen ihren Feiertagen.
<G-vec00081-001-s287><cease.enden><en> 2:11 I will also cause all her delight to cease, her feast days, her new moons, and her sabbaths, and all her solemn feasts.
<G-vec00081-001-s288><cease.enden><de> 7:24 So will ich die Ärgsten unter den Heiden kommen lassen, daß sie sollen ihre Häuser einnehmen, und will der Hoffart der Gewaltigen ein Ende machen und ihre Heiligtümer entheiligen.
<G-vec00081-001-s288><cease.enden><en> 7:24 Wherefore I will bring the worst of the heathen, and they shall possess their houses: I will also make the pomp of the strong to cease; and their holy places shall be defiled.
<G-vec00081-001-s289><cease.enden><de> Und so ist wahrlich der Mensch schon eine Miniaturschöpfung des gesamten Schöpfungsmenschen, ein unvergleichliches Wunder für die geistig schauende Seele, die kein Ende finden wird, sich selbst zu betrachten....
<G-vec00081-001-s289><cease.enden><en> And thus the human being is in fact already a miniature creation of the great universal man; it is a matchless wonder for a soul with spiritual vision, which will never cease contemplating itself....
<G-vec00081-001-s290><cease.enden><de> "Die USA baten Israel bei den Einfällen keine zivilen Opfer zu hinterlassen... währenddessen warnen sie die Hamas, die Raketenangriffe zu stoppen, um ""der Gewalt ein Ende zu bereiten""."
<G-vec00081-001-s290><cease.enden><en> "The United States begged that Israel's incursions do not bring about civilian casualties... while warning Hamas to stop its rocket attacks in order ""to cease the violence."""
<G-vec00081-001-s291><cease.enden><de> Über diese Welt sagte Gott durch den Propheten Jesaja: „Ich werde die Welt für ihre Schlechtigkeit und die bösen Menschen für ihre Sünden bestrafen und dem Hochmut der Stolzen werde Ich ein Ende machen und die Arroganz der Unterdrücker demütigen “ (Jesaja 13:11).
<G-vec00081-001-s291><cease.enden><en> "Through the prophet Isaiah, God said about this world: ""And I will punish the world for evil, and the wicked for their iniquity; and I will make the arrogance of the proud to cease,and will bring low the haughtiness of the violent "" (Isaiah 13:11d)."
<G-vec00081-001-s292><cease.enden><de> 12:23 Darum sprich zu ihnen: So spricht der Herr, Jehova: Ich will diesem Spruche ein Ende machen, und man soll ihn nicht mehr als Spruch gebrauchen in Israel; sondern rede zu ihnen: Nahe sind die Tage und das Wort eines jeden Gesichts.
<G-vec00081-001-s292><cease.enden><en> 12:23 Tell them therefore, Thus says the Lord Yahweh: I will make this proverb to cease, and they shall no more use it as a proverb in Israel; but tell them, The days are at hand, and the fulfillment of every vision.
<G-vec00081-001-s293><cease.enden><de> 28 Denn ich will das Land gar verwüsten und seiner Hoffart und Macht ein Ende machen, daß das Gebirge Israel so wüst werde, daß niemand dadurchgehe.
<G-vec00081-001-s293><cease.enden><en> 28 And I will make the land a desolation and an astonishment; and the pride of her power shall cease; and the mountains of Israel shall be desolate, so that none shall pass through.
<G-vec00081-001-s294><cease.enden><de> 48:35 Und ich mache ein Ende in Moab, spricht Jehova, dem, der auf die Höhe steigt und seinen Göttern räuchert.
<G-vec00081-001-s294><cease.enden><en> 48:35 Moreover I will cause to cease in Moab, says Yahweh, him who offers in the high place, and him who burns incense to his gods.
<G-vec00081-001-s296><cease.enden><de> Und ich mache das Land zur Öde und zum Grausen, und der Stolz seiner Macht wird ein Ende haben; und die Berge Israels werden wüst daliegen, so daß niemand darüber hinwandert.
<G-vec00081-001-s296><cease.enden><en> I will make the land a desolation and an astonishment; and the pride of her power shall cease; and the mountains of Israel shall be desolate, so that none shall pass through.
<G-vec00081-001-s297><cease.enden><de> Wie jede Wirklichkeit einen Anfang und ein Ende hat, so wird der Staat, der aus Not beginnt, sein Ende finden, nur wann es die Notwendigkeit nicht mehr geben wird.
<G-vec00081-001-s297><cease.enden><en> 385. As every reality has a beginning and an end, State was established out of necessity, and will cease to exist only when there will no longer be the need for it.
<G-vec00081-001-s298><cease.enden><de> Dann wird er Dinge erfahren, die in keinem Buche geschrieben stehen, und er wird immer tiefer eindringen dürfen in göttliche Weisheit, und er wird des Staunens kein Ende finden....
<G-vec00081-001-s298><cease.enden><en> Then he will learn things which are not written in any book, and he may penetrate divine wisdom ever more and will never cease to be amazed....
<G-vec00081-001-s303><cease.enden><de> Korruption wird enden – es wird keinen Platz geben, für die Unehrlichen, um sich zu verbergen.
<G-vec00081-001-s303><cease.enden><en> Corruption will cease - there will be no place for the dishonest to hide.
<G-vec00081-001-s304><cease.enden><de> Aufgrund von Einschränkungen der Lizenzgeber kann der Zugang zu den Inhalten über den PSB enden (siehe Abschnitt 7.4).
<G-vec00081-001-s304><cease.enden><en> Due to Licensor restrictions, access to the Content via the PSA may cease (see Section 7.4).
<G-vec00081-001-s305><cease.enden><de> Nach einigen Tagen, am Fest des Unbefleckten Herzens Mariens, enden die feindlichen Auseinandersetzungen in Kroatien.
<G-vec00081-001-s305><cease.enden><en> A few days later, on the feast of the Immaculate Heart of Mary, the hostilities cease in Croatia.
<G-vec00081-001-s306><cease.enden><de> Vor der Eucharistie betrachten die Gläubigen Jesus in der Stunde seiner Einsamkeit und beten, daß alle Einsamkeit auf der Welt enden möge.
<G-vec00081-001-s306><cease.enden><en> Before the Eucharist, the faithful contemplate Jesus in the hour of his solitude and pray that all the loneliness in the world may cease.
<G-vec00081-001-s307><cease.enden><de> Als er die Wahrheit über die Verfolgung sah, sagte er: „Diese brutale Verfolgung sollte ganz schnell enden.
<G-vec00081-001-s307><cease.enden><en> "After seeing the truth of the persecution, he said: ""This sort of brutal persecution should quickly cease."
<G-vec00081-001-s308><cease.enden><de> Sie kam in Abhängigkeit von Ursachen, Wenn die Ursache verschwindet, dann wird Sie enden.
<G-vec00081-001-s308><cease.enden><en> It has come to be dependent on a cause, When the cause dissolves then it will cease.
<G-vec00081-001-s309><cease.enden><de> Für diese Personen wird die Welt enden.
<G-vec00081-001-s309><cease.enden><en> For those individuals, the world will cease.
<G-vec00081-001-s310><cease.enden><de> Es schien, als würden die Wunder niemals enden.
<G-vec00081-001-s310><cease.enden><en> It seemed that wonders would never cease.
<G-vec00081-001-s311><cease.enden><de> (2) Nimmt ein Richter die Wahl in den Deutschen Bundestag oder in die gesetzgebende Körperschaft eines Landes an oder wird ein Richter mit seiner Zustimmung zum Mitglied der Bundesregierung oder der Regierung eines Landes ernannt, so enden das Recht und die Pflicht zur Wahrnehmung des Richteramts ohne gerichtliche Entscheidung nach näherer Bestimmung der Gesetze.
<G-vec00081-001-s311><cease.enden><en> (2) Where a judge accepts election to the German Bundestag or to the legislative body of a Land or where the judge is appointed, with his own consent, a member of the Federal Government or of the government of a Land, the right and the duty to hold judicial office shall cease without a court decision and in accordance with specific statutory provision.
<G-vec00081-001-s313><cease.enden><de> Hier ist der Ruhepunkt, auch bekannt als Zentrum der Schwerkraft in Erden oder Sonnen wo Bewegung und Krümmung enden.
<G-vec00081-001-s313><cease.enden><en> This is the point of rest which is known as the center of gravity in earths or suns where motion and curvature cease.
<G-vec00081-001-s314><cease.enden><de> Die religiöse Gleichgültigkeit der westlichen Kultur wird enden, und säkular orientierte Menschen sind dann gezwungen, zwischen dem allumfassenden Allerweltsgott und dem Gott der Bibel zu wählen.
<G-vec00081-001-s314><cease.enden><en> The present religious indifference of secular Western culture will cease as materially-oriented people will be forced to choose between the universal god and the God of the Bible.
<G-vec00081-001-s315><cease.enden><de> Sicher, es gibt Offline-Entwicklungen, die sich auch in der Online-Sphäre spiegeln – entscheidend ist jedoch, wo die Parallelen enden, genauer: wo der Spiegeleffekt seine Bedeutung verliert und wo die Übersetzung beginnt.
<G-vec00081-001-s315><cease.enden><en> Certainly, there are offline developments that are reflected in the online sphere – but what is decisive is where the parallels cease, or, to be more precise, where the reflection effect loses its meaning and where the translation begins.
<G-vec00081-001-s316><cease.enden><de> Obwohl Gottes Liebe für alle seine Kinder nie enden wird, wird er sie, mit Bedauern, von ihm weggehen lassen, nur weil er ihre Wahl respektiert, eine Wahl auf freiem Willen, den er ihnen seit ihrer Empfängnis gewährt hat.
<G-vec00081-001-s316><cease.enden><en> Although God's love for all His children will never cease, He will, with regret, let them go awayfrom Him only because He respects their choice based on the freewill that He has granted them since they were conceived.
<G-vec00081-001-s317><cease.enden><de> Treibe den Spötter hinaus, und der Zank wird fort gehen; Selbst Hader und Schmähung werden enden (22:10).
<G-vec00081-001-s317><cease.enden><en> Drive out the scoffer, and contention will go out, Even strife and dishonor will cease (22:10).
<G-vec00081-001-s318><cease.enden><de> Dieser heilige Prozess wird weitergehen und erst dann enden, wenn ihr erfolgreich durch die wundersamen Nuancen der Kristall-LICHT-Kammern navigiert seid.
<G-vec00081-001-s318><cease.enden><en> This sacred process is to continue and will cease once you have successfully navigated the wondrous nuances of the Crystal Light Chambers.
<G-vec00081-001-s319><cease.enden><de> Somit wird Heilung nie enden.
<G-vec00081-001-s319><cease.enden><en> So healing will never cease.
<G-vec00081-001-s320><cease.enden><de> Das bedeutet also,... verstehst du Blossom, dass eine Zeit kommen muss, wo das endet.
<G-vec00081-001-s320><cease.enden><en> This therefore, means... do you see Blossom? That there has to come a time when this shall cease.
<G-vec00081-001-s321><cease.enden><de> Im Falle einer solchen Zuwiderhandlung endet unverzüglich Ihr Recht, die App oder Website zu nutzen.
<G-vec00081-001-s321><cease.enden><en> In the event of such a breach, your right to use the App or Website will cease immediately.
<G-vec00081-001-s322><cease.enden><de> a. die Übergabe der Aufzeichnungen nach Artikel 39 und der wichtigen Unterlagen ans Institut oder deren Aufbewahrung vorsehen, wenn die Geschäftstätigkeit vor Ablauf der Aufbewahrungsfrist endet; b. für Eigenblutspenden Ausnahmen von der Aufbewahrungspflicht vorsehen.
<G-vec00081-001-s322><cease.enden><en> a. make provision for the transfer to the Agency, or the archiving, of the records referred to in Article 39 and any important documents, should the establishment cease its activity prior to the expiry of the archiving period;
<G-vec00081-001-s323><cease.enden><de> 8.4 Die Gefahrtragung des Mieters endet, sobald der Mietgegenstand wieder auf dem Betriebsgelände des Vermieters aus Anlass der oder im Anschluss an die Beendigung dieses Vertrages zurück übergeben wird (Tag der tatsächlichen Rückgabe).
<G-vec00081-001-s323><cease.enden><en> 8.4 The Lessee shall cease to bear the risk as soon as the machine has been returned to the Lessor's premises due to or following the end of this Agreement (date of the actual return).
<G-vec00081-001-s324><cease.enden><de> Im Falle einer solchen Kündigung endet Ihr Recht auf Benutzung der Website unverzüglich.
<G-vec00081-001-s324><cease.enden><en> Upon any such termination, your right to use the Site will immediately cease.
<G-vec00081-001-s325><cease.enden><de> Das Ego ist ein Gebilde der Natur; doch ist es kein Gebilde der stofflichen Natur allein und endet daher nicht mit dem Körper.
<G-vec00081-001-s325><cease.enden><en> The ego is a formation of Nature; but it is not a formation of physical nature alone, therefore it does not cease with the body.
<G-vec00081-001-s326><cease.enden><de> Aus der Beendigung von Geburt, endet dann alles Altern und Tod, Kummer, Wehklage, Schmerz, Bedrängnis und Verzweiflung.
<G-vec00081-001-s326><cease.enden><en> From the cessation of birth, then aging & death, sorrow, lamentation, pain, distress, & despair all cease.
<G-vec00213-002-s259><cease.enden><de> Nie wird unser Dank enden können.
<G-vec00213-002-s259><cease.enden><en> Our thanks will never cease.
<G-vec00213-002-s261><cease.enden><de> Im Falle einer solchen Verletzung wird eure Berechtigung, unsere Seite zu nutzen, unmittelbar enden.
<G-vec00213-002-s261><cease.enden><en> In the event of such a breach, your right to use Site will cease immediately.
<G-vec00213-002-s261><conclude.enden><de> Unsere Kundgebung beginnt um 12:00Uhr und wir werden zur Prager Burg laufen, wo unsere Aktivität auch enden wird.
<G-vec00213-002-s261><conclude.enden><en> Our rally will start at 12 a.m. and we shall march to the Prague Castle where our event will conclude.
<G-vec00213-002-s262><conclude.enden><de> Präsident Young und sein Zweiter Ratgeber, Präsident Daniel H. Wells, erklärten in einem Brief an Präsident Smith: „Wir wünschen, dass Sie genau darauf achten, welche Möglichkeiten es für die Verkündigung des Evangeliums in den verschiedenen Ländern, die Sie besuchen, bereits gibt oder wo man sie schaffen könnte.“ Die Reise sollte im Heiligen Land enden, wo Präsident Smith „dieses Land dem Herrn weihen“ wollte.
<G-vec00213-002-s262><conclude.enden><en> In a letter to President Smith, President Young and his Second Counselor, President Daniel H. Wells, said, “We desire that you observe closely what openings now exist, or where they may be effected, for the introduction of the Gospel into the various countries you shall visit.” The journey was to conclude in the Holy Land, where President Smith would “dedicate and consecrate that land to the Lord.”
<G-vec00213-002-s263><conclude.enden><de> Die Feierlichkeiten enden in der Regel mit Unterhaltung und Tanz bis spät in den Abend unter dem Sternenhimmel.
<G-vec00213-002-s263><conclude.enden><en> The festivities usually conclude with entertainment and dancing late into the evening under the night sky.
<G-vec00213-002-s264><conclude.enden><de> Der Workshop wird mit der Preisverleihung enden.
<G-vec00213-002-s264><conclude.enden><en> The award ceremony will conclude the workshop.
<G-vec00213-002-s265><conclude.enden><de> Iberisch ist der äolische Modus seines Refrains samt erniedrigter Septime … der Charakter seiner metrischen Akzentsetzung (bei einem echten Bolero enden alle Perioden auf einem bekräftigenden ersten Schlag, nicht jedoch bei einer Polonaise, dort bevorzugen sie den schwächeren Akzent – eine Feinheit des Kadenzierens, der Chopin eifrig huldigt).
<G-vec00213-002-s265><conclude.enden><en> Iberian is the Aeolian flattened 7th modality of its refrain and the nature of its metric stress (in a true bolero all periods conclude on an assertive downbeat, in a polonaise they don’t, they favour the weaker accent – a nicety of cadencing Chopin observes with alacrity).
<G-vec00213-002-s266><conclude.enden><de> - Novartis-Kooperation: Wie bereits kommuniziert und in der Finanzprognose für 2017 abgebildet, wird die Zusammenarbeit mit Novartis Ende November 2017 vertragsgemäß enden.
<G-vec00213-002-s266><conclude.enden><en> - Novartis collaboration: As previously communicated and as reflected in the Company's 2017 guidance, the collaboration with Novartis will conclude at the end of November 2017 in accordance with the contract.
<G-vec00213-002-s267><conclude.enden><de> Es folgt 'For he was cut off' [denn er ward weggerissen], ein Air im Dreiertakt, das mit Purcells persönlichen Echoangaben und der abschließenden Anweisung versehen ist: Den Chor 'All we like sheep' wiederholen und damit enden.
<G-vec00213-002-s267><conclude.enden><en> This is followed by a triple-time air ‘For he was cut off’, complete with Purcell’s own echoes, and the final direction to ‘Repeat the Chorus All we like sheep and so conclude.’ from Recordings
<G-vec00213-002-s019><culminate.enden><de> Angst und Mißtrauen würden geboren, Verschwörungen würden sich entwickeln und alles würde in einer Herrschaft des Terrors enden, die in der Vergangenheit noch immer die Revolution getötet hat.
<G-vec00213-002-s019><culminate.enden><en> It would generate fear and distrust, would hatch conspiracies, and culminate in a reign of terror which has always killed revolutions in the past.
<G-vec00213-002-s285><end.enden><de> Natürlich endet unser Service aber nicht, sobald Sie einen passenden Austragungsort gefunden haben, denn eine gelungene Veranstaltung beinhaltet auch die Ausstattung, einen kulinarischen Rahmen und Dekorationselemente.
<G-vec00213-002-s285><end.enden><en> Of course, our service does not end as soon as you have found a suitable venue, because a successful event also includes equipment, a culinary framework and decoration elements.
<G-vec00213-002-s286><end.enden><de> Auf dem Boden endet Ihr Flug.
<G-vec00213-002-s286><end.enden><en> Hitting the ground will end your flight.
<G-vec00213-002-s287><end.enden><de> Wenn die zweite Karte des Gebers zu einem Blackjack führt, wird Ihr gesamter Einsatz vom Geber eingezogen, und das Spiel endet.
<G-vec00213-002-s287><end.enden><en> If the dealer’s second card results in a blackjack, your entire wager will be collected by the dealer and the game will come to an end.
<G-vec00213-002-s288><end.enden><de> Und das ist furchtbar, denn es könnte einen Krieg heraufbeschwören, der nie endet“, erklärt er anlässlich der Uraufführung von „Three Posters“ in Europa.
<G-vec00213-002-s288><end.enden><en> And that is terrible, it could give rise to a war that will never end,” he said at the European premiere.
<G-vec00213-002-s289><end.enden><de> Unsere Programmphilosophie endet damit aber nicht.
<G-vec00213-002-s289><end.enden><en> But our program philosophy doesn't end there.
<G-vec00213-002-s290><end.enden><de> Der Bauprozess endet bis zum Ende des Sommers 2017.
<G-vec00213-002-s290><end.enden><en> The building process will end by the end of Summer 2017.
<G-vec00213-002-s291><end.enden><de> Damit der Genuss nicht endet, wenn Sie den Gasthof Brandstätter in Salzburg wieder verlassen müssen, können Sie die Köstlichkeiten auch gerne mit nach Hause nehmen.
<G-vec00213-002-s291><end.enden><en> Pleasure doesn’t need to end when you leave the Gasthof Brandstätter to return home. You can also take some delicious items home with you.
<G-vec00213-002-s292><end.enden><de> Das Löschungsverfahren vor dem Harmonisierungsamt endet mit einem Beschluss, mit dem die angegriffene Marke gelöscht oder teilweise gelöscht wird oder mit dem der Antrag auf Löschung zurückgewiesen wird.
<G-vec00213-002-s292><end.enden><en> The cancellation proceedings before OHIM end with a decision, with which the opposed trademark is cancelled or partially cancelled or with which the request for cancellation is rejected.
<G-vec00213-002-s293><end.enden><de> Im September 2020 endet die Konzeptionsphase.
<G-vec00213-002-s293><end.enden><en> The conception phase will end in September 2020.
<G-vec00213-002-s294><end.enden><de> Conditions WICHTIGE MITTEILUNG Alle Bahnfahrten ab Madrid, oder die über Madrid gehen, mit Ankunft in Castellón de la Plana oder Oropesa Del Mar sind betroffen, und die Fahrt endet bis auf weiteres in Valencia; wir benachrichtigen Sie sofort, falls RENFE uns Änderungen mitteilen sollte.
<G-vec00213-002-s294><end.enden><en> Conditions IMPORTANT NOTIFICATION All those high speed departures from Madrid, or those that pass through Madrid to Castellón or Oropesa del Mar, will be affected until further notice with the end of the line being Valencia.
<G-vec00213-002-s295><end.enden><de> Almabtrieb mit Herbstfest Für die Kühe, Kälber und Schafe endet damit der Aufenthalt in luftiger Höhe, bei frischer Bergluft, würzigem Gras und kühlen Nächten.
<G-vec00213-002-s295><end.enden><en> For over 100 cows, calves and sheep this event marks the end of their stay in altitude where they enjoyed the fresh mountain air, tasty grass and cool nights.
<G-vec00213-002-s296><end.enden><de> Doch ganz ohne Glauben abzuscheiden von der Erde ist hoffnungslos und endet mit der Neubannung, weil das Jenseits die Tore geschlossen hat mit dem Moment des Auflösens der alten Erde.
<G-vec00213-002-s296><end.enden><en> But to depart entirely without faith from earth is a hopeless state and will end with renewed banishment, because the gates of the beyond will close the moment the old earth is dissolved.
<G-vec00213-002-s297><end.enden><de> Als fühlendes Wesen, alle Gedanken, die Sie im Leben haben, wird mit dem Tod endet.
<G-vec00213-002-s297><end.enden><en> As a sentient being, all the thoughts you have in life will end with death.
<G-vec00213-002-s298><end.enden><de> Es ist wirklich schwer, dies zu bewältigen, weil ich dazu neige, es mit mir mitzutragen und es endet damit, daß ich mir selbst wehtue.
<G-vec00213-002-s298><end.enden><en> That's really hard to cope with, because I tend to get carried away by it, and end up being hurt myself.
<G-vec00213-002-s299><end.enden><de> Ihre Amtszeit endet daher mit Beendigung der Hauptversammlung, die über die Entlastung für das Geschäftsjahr 2013 beschließt.
<G-vec00213-002-s299><end.enden><en> Therefore, their terms of office end with the conclusion of the Annual General Meeting that decides on discharge for the 2013 financial year.
<G-vec00213-002-s300><end.enden><de> Doch das Gebet des Psalm 40 endet nicht mit diesem finsteren Gedanken.
<G-vec00213-002-s300><end.enden><en> The prayer of Psalm 40, however, does not end against such a dark background.
<G-vec00213-002-s301><end.enden><de> Die Vorbereitung endet nicht mit der Registrierung und der Buchung Ihrer Reise.
<G-vec00213-002-s301><end.enden><en> Preparation does not end with registration and booking your trip.
<G-vec00213-002-s302><end.enden><de> Die Frist zur Annahme des Angebots beginnt am Tag nach der Absendung des Angebots durch den Kunden zu laufen und endet mit dem Ablauf des fünften Tages, welcher auf die Absendung des Angebots folgt.
<G-vec00213-002-s302><end.enden><en> The deadline for accepting the offer begins on the day following the dispatch of the offer by the customer immediately and shall end with the end of the fifth day, which follows the dispatch of the offer.
<G-vec00213-002-s303><end.enden><de> (1) Bestimmt die EZB, dass die direkte Beaufsichtigung eines beaufsichtigten Unternehmens oder einer beaufsichtigten Gruppe durch die EZB endet, erlässt die EZB für jedes betroffene beaufsichtigte Unternehmen einen Beschluss, in dem der Tag festgelegt wird, an dem die direkte Beaufsichtigung endet, und die Gründe für die Beendigung.
<G-vec00213-002-s303><end.enden><en> 1. When the ECB determines that direct supervision by the ECB of a supervised entity or a supervised group will end, the ECB shall issue an ECB decision to each supervised entity concerned specifying the date and reasons why the direct supervision will end.
<G-vec00213-002-s089><finalize.enden><de> Unser Karosseriecheck endet mit dem Begutachten des Dachs und des Bodens.
<G-vec00213-002-s089><finalize.enden><en> We finalize the bodywork check by looking at the roof and the bottom.
<G-vec00213-002-s247><finish.enden><de> Die nächste Runde wie folgt stricken: 2 Maschen rechts, A.5B (= 16 Maschen, die auf 14 Maschen abgenommen werden), 2 Maschen rechts zusammenstricken, 8 Maschen rechts, 2 Maschen rechts zusammenstricken und enden mit 8 Maschen rechts = 34-34 Maschen auf der Nadel.
<G-vec00213-002-s247><finish.enden><en> The next round is worked as follows: Knit 2 stitches, work A.5B (= 16 stitches which decrease to 14 stitches) knit 2 together, knit 8, knit 2 together and finish with knit 8 = 34-34 stitches on needle.
<G-vec00213-002-s248><finish.enden><de> Es geht auch umgekehrt: von einem Input Pin starten und bei einem Output Pin enden.
<G-vec00213-002-s248><finish.enden><en> Alternatively you can start a connection from an input pin and finish it on an output pin.
<G-vec00213-002-s249><finish.enden><de> Die Kurse starten um 17.30 Uhr und enden gegen 22.00 Uhr.
<G-vec00213-002-s249><finish.enden><en> The workshops start at 6.30pm and usually finish at around 10pm.
<G-vec00213-002-s250><finish.enden><de> Der Prozess des Erscheinens des Babys zum Licht kann in einem beschleunigten Tempo gehen und in ein paar Stunden enden.
<G-vec00213-002-s250><finish.enden><en> The process of the appearance of the baby to the light can go at an accelerated pace and finish in a few hours.
<G-vec00213-002-s251><finish.enden><de> Die nächste Hin-Reihe wie folgt stricken: 3 Blenden-Maschen kraus rechts, A.1 über die 4 ersten Maschen, A.2 bis noch 6 Maschen auf der Nadel sind (= 10-17 Rapporte à 6 Maschen), A.3 über die nächsten 3 Maschen und enden mit 3 Blenden-Maschen kraus rechts.
<G-vec00213-002-s251><finish.enden><en> Work next row as follows from right side: 3 edge stitches in garter stitch, work A.1 over the first 4 stitches, work A.2 until 6 stitches remain on needle (= 10-17 repetitions of 6 stitches), work A.3 over the next 3 stitches and finish with 3 edge stitches in garter stitch.
<G-vec00213-002-s252><finish.enden><de> Erwarten Sie durchschnittliche Erträge mit dichten Blüten, die in 8-9 Wochen enden.
<G-vec00213-002-s252><finish.enden><en> Expect to see average yields with dense flowers that finish in 8-9 weeks.
<G-vec00213-002-s253><finish.enden><de> Ihre Leistungen beginnen im Frühstadium der Entwicklung und enden bei der schlüsselfertigen Projektübergabe.
<G-vec00213-002-s253><finish.enden><en> Their services begin in the early stages of the development and finish with the turnkey project transfer.
<G-vec00213-002-s254><finish.enden><de> Die Veranstaltungen enden mit dem Probieren von Kaffees aus verschiedenen Teilen der Erde, um die wichtigsten Sinneseigenschaften des Getränks zu erkennen: Bitterkeit, Säure und Süße.
<G-vec00213-002-s254><finish.enden><en> The trainings finish with the cupping of different coffees from all over the world, trying to individuate their most important sensory characteristics: the bitterness, the acidity and the sweetness.
<G-vec00213-002-s255><finish.enden><de> GRÖSSE L und XL: Wenn A.1 1 x in der Höhe gestrickt wurde, in der nächsten Reihe die Ärmelmaschen wie folgt stricken: A.2 (= 13 Maschen), A.3 über die nächsten 24 Maschen (= 2 Rapporte à 12 Maschen), enden mit A.4 (= 8 Maschen).
<G-vec00213-002-s255><finish.enden><en> SIZE L and XL: When A.1 has been worked 1 time vertically, work next round as follows over stitches on sleeves: Work A.2 (= 13 stitches), work A.3 over the next 24 stitches (= 2 repetition of 12 stitches), and finish with A.4 (= 8 stitches).
<G-vec00213-002-s256><finish.enden><de> Die Runde am Markierungsfaden beginnen und wie folgt stricken: 4-7-6-9-5-7 Maschen glatt rechts, A.8 (= 5 Maschen), A.3 über die nächsten 60-60-72-72-84-84 Maschen (= 5-5-6-6-7-7 Rapporte à 12 Maschen) und enden mit 4-7-6-9-5-7 Maschen glatt rechts.
<G-vec00213-002-s256><finish.enden><en> Begin round at the marker thread and work as follows: Work 4-7-6-9-5-7 stitches in stocking stitch, work A.8 (= 5 stitches), work A.3 over the next 60-60-72-72-84-84 stitches (= 5-5-6-6-7-7 repetitions of 12 stitches) and finish with 4-7-6-9-5-7 stitches in stocking stitch.
<G-vec00213-002-s257><finish.enden><de> 1 Rand-Masche kraus rechts, 1 Masche rechts, 1 Umschlag (= 1 Masche zugenommen), rechts stricken bis noch 2 Maschen übrig sind, 1 Umschlag (= 1 Masche zugenommen), 1 Masche rechts und enden mit 1 Rand-Masche kraus rechts (= insgesamt 2 Maschen zugenommen).
<G-vec00213-002-s257><finish.enden><en> Work 1 edge stitch in garter stitch, knit 1, 1 yarn over (= 1 stitch increased), knit until 2 stitches remain, 1 yarn over (= 1 stitch increased), knit 1 and finish with 1 edge stitch in garter stitch (= 2 stitches increased in total).
<G-vec00213-002-s258><finish.enden><de> In Runden im Muster gemäß Diagramm A.1b häkeln, A.1b insgesamt 6 x in der Runde arbeiten - A.1a zeigt, wie die Runden beginnen und enden und wird zusätzlich zu A.1b gehäkelt.
<G-vec00213-002-s258><finish.enden><en> Work pattern in the round according to diagram A.1b a total of 6 times on the round - A.1a shows how rounds start and finish and is worked in addition to A.1b.
<G-vec00213-002-s259><finish.enden><de> Sie ist kräftig, sehr schimmelresistent und wird von Mitte bis Ende September auch in feuchtem und kaltem Klima sehr früh im Freien enden.
<G-vec00213-002-s259><finish.enden><en> She is vigorous, very mold-resistant and will finish VERY EARLY outdoors, from the middle to end of September, even in a humid and cold climate.
<G-vec00213-002-s260><finish.enden><de> Und eine Combination-Forecast beinhaltet die Auswahl von 3 oder mehr Pferden, die in beliebiger Reihenfolge als Erster oder Zweiter enden.
<G-vec00213-002-s260><finish.enden><en> And a combination forecast involves choosing 3 or more horses to finish first or second in any order.
<G-vec00213-002-s261><finish.enden><de> Wenn also eine Indica zum Blühen gebracht wird, wenn ihre Größe fast die halbe Höhe des Raumes misst, wird sie wahrscheinlich knapp unterhalb der Decke enden.
<G-vec00213-002-s261><finish.enden><en> So if the flowering of an Indica is activated once it has reached the middle of the growing space, it is likely that it will finish just below the ceiling.
<G-vec00213-002-s262><finish.enden><de> Nun den ersten Teil der Stola wie folgt im Diagramm häkeln (= ab der Rück-R): A.1A über die 3 ersten Lm-Bögen, A.1B über die nächsten 12 Lm-Bögen und enden mit A.1C über den letzten Lm-Bogen.
<G-vec00213-002-s262><finish.enden><en> Then work the first part of the stole according to diagram as follows (= from WS): Work A.1A over the first 3 ch-spaces, A.1B over the next 12 ch-spaces and finish with A.1C over last ch-space.
<G-vec00213-002-s263><finish.enden><de> Wenn A.1 zu Ende gestrickt wurde, A.2 ebenso stricken, d.h. die erste Reihe wie folgt stricken (= Hin-Reihe): 5 Blenden-Maschen kraus rechts, siehe Kästchen in A.Y (das Kästchen ist nur eine Erklärung der Reihe und wird nicht gestrickt), A.2A bis noch 6 Maschen auf der Nadel sind (= 36-38-40-43-45-47 Rapporte A.2A à 6 Maschen), A.2B (= 1 Masche) und enden mit 5 Blenden-Maschen kraus rechts.
<G-vec00213-002-s263><finish.enden><en> When A.1 has been worked, work A.2 the same way, i.e. work first row as follows from right side: 5 band stitches in garter stitch, see square in A.Y (square is only an explanation on row and should not be worked), work A.2A until 6 stitches remain on needle (= 36-38-40-43-45-47 repetitions of A.2A of 6 stitches), work A.2B (= 1 stitch) and finish with 5 band stitches in garter stitch.
<G-vec00213-002-s264><finish.enden><de> In dieser Weise 9 cm stricken – nach einer Hin-Reihe enden, den Faden abschneiden und dann die Maschen gesondert stilllegen.
<G-vec00213-002-s264><finish.enden><en> Continue for 9 cm - finish from right side, cut the yarn and slip stitches on another stitch holder.
<G-vec00213-002-s265><finish.enden><de> Wenn alles gut geht, wird Dein neues Arch Linux System nun starten und mit einer Login-Eingabe enden (Du solltest in Deinem BIOS die Startreihenfolge zurückstellen auf das Starten von Festplatte).
<G-vec00213-002-s265><finish.enden><en> Your new Arch Linux system will boot up and finish with a login prompt (you may want to change the boot order in your BIOS back to booting from hard disk).
<G-vec00217-002-s267><conclude.enden><de> Es folgt 'For he was cut off' [denn er ward weggerissen], ein Air im Dreiertakt, das mit Purcells persönlichen Echoangaben und der abschließenden Anweisung versehen ist: Den Chor 'All we like sheep' wiederholen und damit enden.
<G-vec00217-002-s267><conclude.enden><en> This is followed by a triple-time air ‘For he was cut off’, complete with Purcell’s own echoes, and the final direction to ‘Repeat the Chorus All we like sheep and so conclude.’ from Recordings
