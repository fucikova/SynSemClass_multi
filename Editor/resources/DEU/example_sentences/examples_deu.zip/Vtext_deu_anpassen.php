<G-vec00407-001-s055><amend.anpassen><de> Zettels kann diese Datenschutzbestimmung von Zeit zu Zeit anpassen.
<G-vec00407-001-s055><amend.anpassen><en> Zettels may amend this data protection provision from time to time.
<G-vec00407-001-s056><amend.anpassen><de> Daybreak kann neue Kostenpflichtige Inhalte, Produkte und andere Dienstleistungen gegen zusätzliche Gebühren und Entgelte hinzufügen oder Gebühren und Entgelte für bestehende Produkte, Dienstleistungen und/oder Kostenpflichtige Inhalte zu jeder Zeit und nach eigenem Ermessen anpassen.
<G-vec00407-001-s056><amend.anpassen><en> Daybreak may add new Paid Content, products and/or services for additional fees and charges, or amend fees and charges for existing products, services and/or Paid Content, at any time and in its sole discretion.
<G-vec00407-001-s057><amend.anpassen><de> Nach der Analyse der vorgeschlagenen Änderungsanträge haben wir ein besseres Verständnis dafür, wie bestimmte Gruppen von Abgeordneten den berüchtigten Artikel 13 anpassen möchten, dessen Vorgängerversion die Internetunternehmen verpflichtet hätte, Upload-Filter zu installieren.
<G-vec00407-001-s057><amend.anpassen><en> After analyzing the proposed amendments, we have a better sense of how certain groups of MEPs would like to amend the infamous Article 13, the previous version of which would have obliged internet companies to install upload filters.
<G-vec00407-001-s058><amend.anpassen><de> Natürlich können Sie die Liste jederzeit anpassen, oder nur einzelne Dokumente downloaden.
<G-vec00407-001-s058><amend.anpassen><en> As you would expect, you can also amend the list at any time or download individual documents.
<G-vec00407-001-s059><amend.anpassen><de> 1 Aktiengesellschaften und Kommanditaktiengesellschaften, die im Zeitpunkt des Inkrafttretens dieses Gesetzes im Handelsregister eingetragen sind, jedoch den neuen gesetzlichen Vorschriften nicht entsprechen, müssen innert fünf Jahren ihre Statuten den neuen Bestimmungen anpassen.
<G-vec00407-001-s059><amend.anpassen><en> 1 Â Companies limited by shares and partnerships limited by shares that are entered in the commercial register when this Act comes into force, but which do not comply with the new statutory provisions, must amend their articles of association to the new provisions within five years.
<G-vec00407-001-s060><amend.anpassen><de> Die Gesellschaft wird diese Verträge im Frühjahr 2010, d. h. binnen dieser Übergangsfrist, der neuen Ziffer 3.8 des Deutschen Corporate Governance Kodex anpassen und einen Selbstbehalt von mindestens 10 % des Schadens bis mindestens zur Höhe des Eineinhalbfachen der festen jährlichen Vergütung vereinbaren.
<G-vec00407-001-s060><amend.anpassen><en> The company will amend this insurance in early 2010, i.e. within the stated transitional period, in order to comply with the new Section 3.8 of the German Corporate Governance Code and will agree a new deductible amounting to at least 10 % of the loss and up to at least 150 % of the fixed portion of the annual compensation of each board member.
<G-vec00407-001-s061><amend.anpassen><de> Gegebenenfalls können wir auch die Versicherungsbeiträge anpassen.
<G-vec00407-001-s061><amend.anpassen><en> Where applicable, we can also amend your insurance premiums.
<G-vec00407-001-s062><amend.anpassen><de> Die Liste der Experten stellt keine Offerte dar und Helsana kann die Liste jederzeit anpassen.
<G-vec00407-001-s062><amend.anpassen><en> The list of experts does not represent an offer and Helsana may amend the list at any time.
<G-vec00407-001-s063><amend.anpassen><de> In diesen Fällen werden wir auch unsere Hinweise zum Datenschutz entsprechend anpassen.
<G-vec00407-001-s063><amend.anpassen><en> In such cases, we will amend our data protection information to reflect this.
<G-vec00407-001-s067><amend.anpassen><de> Scout24 behält sich vor, das vorliegende Dokument (COW) jederzeit anzupassen.
<G-vec00407-001-s067><amend.anpassen><en> Scout24 reserves the right to amend the present document (COA) at any time.
<G-vec00407-001-s068><amend.anpassen><de> Rivalo behält sich vor, die Länderliste jederzeit und ohne vorherige Ankündigung anzupassen.
<G-vec00407-001-s068><amend.anpassen><en> Rivalo reserves the right to amend this list of countries at any time and without prior notice.
<G-vec00407-001-s069><amend.anpassen><de> Die Banken in der Schweiz sind aufgefordert, ihre Geschäftsmodelle konsequent zu hinterfragen und an die skizzierten Herausforderungen anzupassen.
<G-vec00407-001-s069><amend.anpassen><en> The banks in Switzerland are called on to scrutinise their business models systematically and to amend these in line with the challenges that have been outlined.
<G-vec00407-001-s070><amend.anpassen><de> Die DIESEL TECHNIC AG behält sich vor, diese Datenschutzerklärung gegebenenfalls entsprechend künftigen Änderungen bei der Verwendung Ihrer persönlichen Daten anzupassen.
<G-vec00407-001-s070><amend.anpassen><en> DIESEL TECHNIC AG reserves the right to amend this data protection declaration, if necessary, in line with future changes in the use of your personal data.
<G-vec00407-001-s071><amend.anpassen><de> BetVoyager Casino behält sich das Recht vor, ohne vorherige Ankündigung, jegliche Sonderangebote zu jedem Zeitpunkt zu ändern, anzupassen oder einzustellen.
<G-vec00407-001-s071><amend.anpassen><en> BetVoyager Casino retains the right to change, amend or discontinue any special offers at any point for any reason without advance warning.
<G-vec00407-001-s072><amend.anpassen><de> Aufgrund technischer Weiterentwicklung und/oder aufgrund geänderter gesetzlicher und/oder behördlicher Vorgaben kann es notwendig werden, diese Datenschutzinformationen anzupassen.
<G-vec00407-001-s072><amend.anpassen><en> It may be necessary to amend this Privacy Policy due to technical developments and/or changes to statutory or regulatory requirements.
<G-vec00407-001-s073><amend.anpassen><de> Der Veranstalter behält sich das Recht vor, dieses Angebot zu aktualisieren oder einzustellen und/oder die Nutzungsbedingungen im Fall unvorhergesehener Umstände, oder wenn dies seiner Meinung nach nötig ist, anzupassen.
<G-vec00407-001-s073><amend.anpassen><en> The Promoter reserves the right to alter or cancel this Offer or update and/or amend these terms and conditions at any stage, if deemed necessary in its opinion or in the event of unforeseen circumstances.
<G-vec00407-001-s074><amend.anpassen><de> Der Betreiber behält sich das Recht vor, die Nutzungsbedingungen jederzeit anzupassen.
<G-vec00407-001-s074><amend.anpassen><en> The Operator reserves the right to amend the Terms of Service at any time.
<G-vec00407-001-s075><amend.anpassen><de> Oris behält sich das Recht vor, die Geschäftsbedingungen nötigenfalls anzupassen.
<G-vec00407-001-s075><amend.anpassen><en> Oris reserves the right to amend any terms it may deem necessary.
<G-vec00407-001-s076><amend.anpassen><de> Der Vermieter behält sich das Recht vor, die Reisesumme anzupassen, wenn Änderungen der zu zahlenden Gebühren, Geldkurse und Steuern dazu Anlass geben.
<G-vec00407-001-s076><amend.anpassen><en> The Letter reserves the right to amend the booking price if occasioned by changes to owed levies, exchange rates and taxes.
<G-vec00407-001-s077><amend.anpassen><de> Der Verantwortliche behält sich vor, diese Datenschutzerklärung anzupassen, und wird etwaige Änderungen an dieser Stelle bekannt geben.
<G-vec00407-001-s077><amend.anpassen><en> The controller reserves the right to amend this Privacy Policy and will announce any changes here.
<G-vec00407-001-s078><amend.anpassen><de> Wir behalten uns das Recht vor, diese Datenschutzerklärung jederzeit mit Wirkung für die Zukunft anzupassen oder zu ändern.
<G-vec00407-001-s078><amend.anpassen><en> We reserve the right to amend or change this data protection declaration at any time with effect for the future.
<G-vec00407-001-s079><amend.anpassen><de> Der Veranstalter behält sich das Recht vor, diese Aktion zu aktualisieren oder einzustellen und/oder die Nutzungsbedingungen im Fall unvorhergesehener Umstände, oder wenn dies seiner Meinung nach nötig ist, anzupassen.
<G-vec00407-001-s079><amend.anpassen><en> The Promoter reserves the right to alter or cancel this promotion or update and/or amend these terms and conditions at any stage, if deemed necessary in its opinion or in the event of unforeseen circumstances.
<G-vec00407-001-s080><amend.anpassen><de> Sollte TP nach Fertigstellung des Rapid Tooling Werkzeuges feststellen, dass die Zykluszeit des Werkzeuges gravierend von der vorher geschätzten Zeit abweicht, behalten wir uns hiermit ausdrücklich das Recht vor, die Teilepreise erneut anzupassen, und hierfür ein neues Angebot zu erstellen.
<G-vec00407-001-s080><amend.anpassen><en> Should TP – after having finished the Rapid Tooling tool – find out that the tool's cycle time substantially deviates from the previously estimated time, we expressly reserve the right to amend the prices per part again and to issue a new offer.
<G-vec00407-001-s081><amend.anpassen><de> Wir behalten uns vor, diese Datenschutzerklärung jederzeit anzupassen.
<G-vec00407-001-s081><amend.anpassen><en> We reserve the right to amend this Privacy Notice at any time.
<G-vec00407-001-s082><amend.anpassen><de> "Zum Abschluss seines Vortrages schlug Timur Bondaryev eine Reihe von Maßnahmen zur Erhöhung der Effizienz der einstweiligen Verfügung im internationalen Schiedsverfahren, unter anderem die ukrainische Gesetzgebung ""Über internationale Schiedsgerichtsbarkeit"" an die internationalen Verfahren UNCITRAL über die internationale Handelsschiedsgerichtsbarkeit anzupassen, die Regel des IHSG an der IHK der Ukraine zu ergänzen und breitere Möglichkeiten für die Anwendung der einstweiligen Verfügung vorzusehen, entsprechende Änderungen in der Zivil- und Wirtschaftsprozessordnung der Ukraine vorzunehmen und die Möglichkeit der Sicherung von Schiedsklagen durch die staatlichen Gerichte vor und während des Schiedsverfahrens direkt vorzusehen und, schließlich, für Zusammenarbeit zwischen den Schiedsgerichten und staatlichen Gerichten sowie Vollstreckungsbehörden zu sorgen."
<G-vec00407-001-s082><amend.anpassen><en> "In conclusion of his speech Timur Bondaryev proposed a number of measures to increase efficiency of injunction for international commercial arbitration, in particular, to bring Ukrainian legislation ""On International Commercial Arbitration"" in line with international procedures UNCITRAL about international commercial arbitration, to amend Rules of the ICA at the UCCI with provisions on extended powers for application of injunction, to amend respectively the Civil Procedural and the Economic Procedural Code of Ukraine directly providing a possibility of injunction prior or during arbitration proceeding and, finally, to adjust cooperation between arbitration institutions and national courts and state enforcement authorities as well."
<G-vec00407-001-s145><amend.anpassen><de> Interroll behält sich das Recht vor, diese Datenschutzrichtlinie jederzeit anzupassen.
<G-vec00407-001-s145><amend.anpassen><en> Interroll reserves the right to amend this privacy statement from time to time.
<G-vec00407-001-s146><amend.anpassen><de> Noble-House NV behält sich dabei das Recht vor, Inhalte jederzeit anzupassen oder Teile davon zu entfernen, ohne Sie hierüber vorab in Kenntnis zu setzen.
<G-vec00407-001-s146><amend.anpassen><en> Noble House NV reserves the right to amend the content or remove sections of the website without notice at any time.
<G-vec00407-001-s197><amend.anpassen><de> PULSION behält sich das Recht vor, diese Nutzungsbedingungen von Zeit zu Zeit zu modifizieren und sie der technischen sowie rechtlichen Entwicklung anzupassen.
<G-vec00407-001-s197><amend.anpassen><en> PULSION retains the right to modify these terms of use from time to time and to amend them in line with technical and legal developments.
<G-vec00407-001-s198><amend.anpassen><de> Runtastic behält sich das Recht vor, diese AGB von Zeit zu Zeit anzupassen, um vor allem, aber nicht beschränkt darauf, die gesetzlichen Bestimmungen oder Anforderungen einzuhalten, der Wirtschaftlichkeit zu entsprechen oder den Benutzerinteressen entgegenzukommen.
<G-vec00407-001-s198><amend.anpassen><en> Runtastic reserves the right to amend these T&C from time to time for a number of reasons including, without limitation, for commercial reasons, to comply with applicable law or regulations, or for customer service reasons.
<G-vec00250-002-s021><conform.anpassen><de> Sie werden sicherlich genau sehen, wie das Element der Nutzung und der Job für Sie anpassen muss.
<G-vec00250-002-s021><conform.anpassen><en> You will certainly see just how the item must conform to the use and job to you.
<G-vec00250-002-s022><conform.anpassen><de> Auch wenn wir unsere Faltenbälge standardmäßig in funktionalem Grau anbieten, können wir den Faltenbalg optisch an das Design des Einsatzfahrzeugs anpassen.
<G-vec00250-002-s022><conform.anpassen><en> Even though our folding bellows are offered in a standard functional gray color, we can also customize folding bellows to conform with the design of the vehicle they're a part of.
<G-vec00250-002-s023><conform.anpassen><de> Der Wirkungsgrad einer passiven Ölsperre ist umso größer, je besser sich die schwimmende Ölsperre der Wellenbewegung anpassen kann.
<G-vec00250-002-s023><conform.anpassen><en> Efficiency The better the floating oil boom can conform to wave motion, the greater the efficiency of a passive oil boom.
<G-vec00250-002-s024><conform.anpassen><de> Unter bestimmten Umständen gibt es diejenigen, die sich traditionellen Regeln nicht anpassen wollen und unorthodoxe Strategien ausprobieren, etwa gleichzeitig als Künstler und Kurator zu spielen.
<G-vec00250-002-s024><conform.anpassen><en> On certain occasions, there are those who do not wish to conform to traditional rules and attempt unorthodox strategies such as playing simultaneously both curator and artist.
<G-vec00250-002-s025><conform.anpassen><de> Dieser Abschnitt ist sehr wichtig, weil er uns sagt, dass wir uns nicht dieser Welt anpassen sollen, sondern stattdessen den Werken Gottes dienen und durch die Erneuerung unseres Geistes verändert werden.
<G-vec00250-002-s025><conform.anpassen><en> This passage is very important because it tells us that we should not conform to this world, and that instead, we should serve God’s works and be transformed by the renewal of our minds.
<G-vec00250-002-s026><conform.anpassen><de> Gewölbte Rollen finden am besten Anwendung bei dünnen Bändern, da sich das Bandgewebe an die gewölbte Oberfläche der Rolle anpassen muss.
<G-vec00250-002-s026><conform.anpassen><en> Crowned pulleys work best on thin belts as the belt web must conform to the crowned face of the pulley.
<G-vec00250-002-s027><conform.anpassen><de> Zu niedrig: Ein niedriger Druck erhöht dank der größeren Kontaktfläche den Grip und verbessert die Traktion in Kurven, da sich der Reifen dem Trail besser anpassen kann.
<G-vec00250-002-s027><conform.anpassen><en> Too low: Low pressures increase grip with a larger contact patch and improve cornering traction as the softer tire can conform to the terrain.
<G-vec00250-002-s057><match.anpassen><de> Bereits in den 60er Jahren entwickelte Wera in Zusammenarbeit mit dem renommierten Fraunhofer-Institut für Arbeitswirtschaft und Organisation einen Schraubendrehergriff, der in seiner Form an die Anatomie der menschlichen Hand angepasst ist.
<G-vec00250-002-s057><match.anpassen><en> In the 1960s, Wera developed a screwdriver handle designed to match the shape of the human hand in cooperation with the internationally recognised Fraunhofer IAO Institute.
<G-vec00250-002-s058><match.anpassen><de> Bei Bedarf kann die sichtbare Deckplatte vom Kunden selbst mit einem beliebigen Furnier versehen und somit der Oberfläche des Tisches angepasst werden.
<G-vec00250-002-s058><match.anpassen><en> If required, the cover surface can be finished by the customer with a special veneer to match the table surface, allowing the technology to be integrated discreetly in any conference table.
<G-vec00250-002-s059><match.anpassen><de> Die für Atelier Haußmann entstandene erste Serie aus 31 Unikaten besteht aus jeweils einem Reststück Marmorplatte mit Bruchstelle, eingefasst von einem Stahlwinkelgestell, das an jede Zufallsform der Platten einzeln angepasst wird und an der Bruchkante offen bleibt.
<G-vec00250-002-s059><match.anpassen><en> The series developed for Atelier Haußmann is comprised of 31 unique objects each consisting of a remnant marble slab with a breakpoint, surrounded by a steel angle frame which has been individually composed to match the random shape of the slabs, yet remaining open at the breakpoint. DIMENSIONS
<G-vec00250-002-s060><match.anpassen><de> Mit dem Programm sollen das Unternehmertum gefördert, die Qualifikationen der Arbeitslosen an den Bedarf des Arbeitsmarktes angepasst und Verkehrsverbindungen in der gesamten Region ausgebaut werden.
<G-vec00250-002-s060><match.anpassen><en> The aims of the Programme are to promote entrepreneurship, match the skills of the unemployed with those required in the labour market, and upgrade transport links across the region.
<G-vec00250-002-s061><match.anpassen><de> Auf Implantaten befestigte Zähne wirken optisch wie die eigenen, da sie der Zahnumgebung in Farbe und Form angepasst werden und fügen sich gleichmäßig in die vorhandene Bezahnung ein.
<G-vec00250-002-s061><match.anpassen><en> Dentures which have been affixed to the implants look optically like your own, because they are custom-made to match the colour and shape of the teeth around them and fit in evenly within the existing row of teeth.
<G-vec00250-002-s062><match.anpassen><de> Die Scharniere X 8 PA sind in Form und Farbgebung an die Profile X 8 angepasst.
<G-vec00250-002-s062><match.anpassen><en> The shape and colour of Hinges X 8 PA match Profiles X 8.
<G-vec00250-002-s063><match.anpassen><de> Codierungslösungen bei Herstellern von Drähten, Kabeln und Rohren müssen an die Realität im Produktionsprozess angepasst sein.
<G-vec00250-002-s063><match.anpassen><en> The performance of coding solutions in wire, cable and pipe industries needs to match the realities of the production process.
<G-vec00250-002-s064><match.anpassen><de> Alle Produkte werden deshalb von unseren deutschen und niederländischen Ingenieuren selber entwickelt und an die lokalen Anforderungen und Gegebenheiten individuell angepasst.
<G-vec00250-002-s064><match.anpassen><en> Products are engineered in Germany and The Netherlands to match local requirements and produced by our quality production facilities in the United States and China.
<G-vec00250-002-s065><match.anpassen><de> Die Vorspannung der Federn kann stufenlos eingestellt werden und kann somit an die Anforderungen Ihrer Anwendung angepasst werden.
<G-vec00250-002-s065><match.anpassen><en> Both ranges are adjustable to match bench loading with the requirements for your application.
<G-vec00250-002-s066><match.anpassen><de> Für das Finish in Space Grau haben wir mit physikalischer Gasphasenabscheidung (PVD) die Farbe des Edelstahlrahmens genau an die des Glases angepasst.
<G-vec00250-002-s066><match.anpassen><en> For the space grey finish, we use a process called physical vapour deposition to precisely match the colour of the stainless steel band to that of the glass.
<G-vec00250-002-s067><match.anpassen><de> Die Geschwindigkeit des fortgeschrittenen Kriegers beim Anvisieren und Aufladen von Angriffen wurde leicht erhöht und an seine normale Bewegungsgeschwindigkeit angepasst.
<G-vec00250-002-s067><match.anpassen><en> Adv Warrior speed increased slightly when locked on and charging to match his normal movement speed Adv Warrior damage increased
<G-vec00250-002-s068><match.anpassen><de> Kombiniert können sie nahezu jedem Risikoprofil angepasst werden.
<G-vec00250-002-s068><match.anpassen><en> Used in combination, they can match virtually any risk profile.
<G-vec00250-002-s069><match.anpassen><de> Darüberhinaus wird die Software oft nicht genügend auf die individuellen Anforderungen des Unternehmens angepasst.
<G-vec00250-002-s069><match.anpassen><en> In addition, it also happens that a software does not match with the requirements or is not enough updated to the customer.
<G-vec00250-002-s070><match.anpassen><de> In den letzten Wochen haben wir auch das Aussehen und Verhalten der Benutzeroberfläche an den neuen Google-Stil angepasst.
<G-vec00250-002-s070><match.anpassen><en> In recent weeks, we also updated the look & feel of our user interface to match Google's new style.
<G-vec00250-002-s071><match.anpassen><de> Die Länge der Schiene ist der Größe des Skates angepasst.
<G-vec00250-002-s071><match.anpassen><en> The length of the frame and the size of the wheels match the size of the skate.
<G-vec00250-002-s072><match.anpassen><de> Farblich an Ihre Badeinrichtung angepasst oder im selben Material ausgeführt wie der Badezimmerboden.
<G-vec00250-002-s072><match.anpassen><en> In a colour to match your bathroom furnishings or designed in the same material as the bathroom floor.
<G-vec00250-002-s073><match.anpassen><de> Damit ist die Leuchte besser sichtbar, und die Lichtintensität optimal an den Signalisierungsbereich des zugehörigen Schallgebers angepasst.
<G-vec00250-002-s073><match.anpassen><en> As such, the light is more visible. Additionally, the light’s intensity is properly sized to match the coverage area of the associated sounder.
<G-vec00250-002-s074><match.anpassen><de> Je nach Tagesform oder Art der Strecke (lange Bergauffahrt, Gegenwind) kann der Lenker ganz einfach an die Bedingungen angepasst werden.
<G-vec00250-002-s074><match.anpassen><en> Depending on the day’s itinerary, the distance to be covered and other environmental factors (long climbs, headwinds) you can position the handlebars to precisely match the required conditions.
<G-vec00250-002-s075><match.anpassen><de> Eine drahtlose Vorrichtung A wireless device 1400 1400, die durch ein gefärbtes Quadrat angezeigt ist, ist in der tatsächlichen Umgebung vorhanden, und jede Messvorrichtung berichtet HF-Die Positionsberechnungsanwendung vergleicht die gemessenen HF- Kanalcharakteristika der drahtlosen Vorrichtung mit den Leistungsnachschlagtabellen, die den Knoten des Gitters zugeordnet sind, um den Satz von Knoten, dessen Nachschlagtabellen am nächsten an die gemessenen HF-Kanalcharakteristika angepasst sind, zu bestimmen.
<G-vec00250-002-s075><match.anpassen><en> A wireless device 1400 indicated by a colored square is present within the actual environment, and each measuring device reports RF channel characteristics for the wireless device to the position calculation application. The position calculation application compares the measured RF channel characteristics of the wireless device with the performance lookup tables associated with the vertices of the mesh to determine the set of vertices whose lookup tables most closely match the measured RF channel characteristics.
<G-vec00290-002-s031><brace.anpassen><de> Bei herausnehmbaren Zahnspangen wird erst ein Gebissabdruck genommen, anhand dessen eine Zahnspange angefertigt und angepasst wird, die aus einer Plastikplatte und Drähten besteht.
<G-vec00290-002-s031><brace.anpassen><en> For removable braces, an impression of the teeth is taken and a technician makes the removable brace consisting of a plastic plate and wires. The brace is then fitted on teeth.
<G-vec00318-002-s114><align.anpassen><de> Weniger Layouts bieten eine Grundstruktur, mit deren Hilfe Sie Steuerelemente in Formularen und Berichten anpassen und deren Größe ändern können.
<G-vec00318-002-s114><align.anpassen><en> Less Layouts are guides that help you align and resize controls on forms and reports.
<G-vec00318-002-s115><align.anpassen><de> Die Texte wurden automatisch an die richtige Stelle platziert, sodass unsere DTP-Spezialisten abschließend in den AutoCAD-Dateien nur noch die längeren russischen Texte ans bestehende Layout anpassen mussten.
<G-vec00318-002-s115><align.anpassen><en> The texts were automatically inserted at the correct place. Thus, our desktop publishing specialist simply had to align the longer Russian texts to the existing layout in the AutoCAD files.
<G-vec00318-002-s116><align.anpassen><de> Zu den wichtigen bilateralen Handelsabkommen, die sich wahrscheinlich den im TTIP beschlossenen neuen Lebensmittelsicherheitsnormen anpassen müssten, gehören die aktuellen oder anstehenden Gespräche der EU mit Indien, den südostasiatischen Mitgliedern von ASEAN und China.
<G-vec00318-002-s116><align.anpassen><en> Key bilateral trade negotiations that would likely have to align with any new food safety-related norms coming out of TTIP include the EU's current or upcoming talks with India, the Southeast Asian members of ASEAN and China.
<G-vec00318-002-s117><align.anpassen><de> Wenn Du willst, dass deine Google-Anzeige so viele Klicks wie möglich generiert, musst Du sie an deine Zielseite anpassen.
<G-vec00318-002-s117><align.anpassen><en> If you want your Google ad copy to generate the most clicks possible, you have to align it with your landing page.
<G-vec00318-002-s118><align.anpassen><de> Es veränderte tatsächlich meine Sicht aufs Leben und ich wollte meine Lebensweise mehr an einen nachhaltigen und sanften Lebensstil anpassen.
<G-vec00318-002-s118><align.anpassen><en> It really changed my perspective on life and I wanted to align my way of living more towards eco and slow living.
<G-vec00318-002-s119><align.anpassen><de> Neben komplett kundenspezifischen Lösungen bieten wir auch Standard-Freistrahlmaschinen an, die wir ebenfalls vollständig Ihren Bedürfnissen anpassen können.
<G-vec00318-002-s119><align.anpassen><en> Besides fully tailored solutions we also provide standard wheel blasting machines, which we can also fully align to your requirements. Datasheet
<G-vec00360-002-s190><evolve.anpassen><de> Mozy ist so aufgebaut, dass sich der Service einfach an die Anforderungen der Zukunft anpassen lässt.
<G-vec00360-002-s190><evolve.anpassen><en> Mozy is built upon a foundation that enables us to evolve our service as we move into the future.
<G-vec00360-002-s191><evolve.anpassen><de> Trotz Smartphones werden auch heute noch Briefe verschickt – aber Postunternehmen müssen sich anpassen, um das einbrechende Briefgeschäft zu kompensieren – zum Beispiel durch die Zustellung von Paketen von Online-Versandhäusern.
<G-vec00360-002-s191><evolve.anpassen><en> As ubiquitous as smartphones are nowadays, people continue to send letters – but mail firms need to evolve to make up for the downturn in postal business, for example, by delivering parcels sent by online mail order companies.
<G-vec00360-002-s192><evolve.anpassen><de> Dementsprechend sollten sich Ihr Werkzeug und Ihre Strategie anpassen.
<G-vec00360-002-s192><evolve.anpassen><en> Behaviors evolve. Your tool and strategy should too.
<G-vec00250-003-s057><match_up.anpassen><de> Bereits in den 60er Jahren entwickelte Wera in Zusammenarbeit mit dem renommierten Fraunhofer-Institut für Arbeitswirtschaft und Organisation einen Schraubendrehergriff, der in seiner Form an die Anatomie der menschlichen Hand angepasst ist.
<G-vec00250-003-s057><match_up.anpassen><en> In the 1960s, Wera developed a screwdriver handle designed to match the shape of the human hand in cooperation with the internationally recognised Fraunhofer IAO Institute.
<G-vec00250-003-s058><match_up.anpassen><de> Bei Bedarf kann die sichtbare Deckplatte vom Kunden selbst mit einem beliebigen Furnier versehen und somit der Oberfläche des Tisches angepasst werden.
<G-vec00250-003-s058><match_up.anpassen><en> If required, the cover surface can be finished by the customer with a special veneer to match the table surface, allowing the technology to be integrated discreetly in any conference table.
<G-vec00250-003-s059><match_up.anpassen><de> Die für Atelier Haußmann entstandene erste Serie aus 31 Unikaten besteht aus jeweils einem Reststück Marmorplatte mit Bruchstelle, eingefasst von einem Stahlwinkelgestell, das an jede Zufallsform der Platten einzeln angepasst wird und an der Bruchkante offen bleibt.
<G-vec00250-003-s059><match_up.anpassen><en> The series developed for Atelier Haußmann is comprised of 31 unique objects each consisting of a remnant marble slab with a breakpoint, surrounded by a steel angle frame which has been individually composed to match the random shape of the slabs, yet remaining open at the breakpoint. DIMENSIONS
<G-vec00250-003-s060><match_up.anpassen><de> Mit dem Programm sollen das Unternehmertum gefördert, die Qualifikationen der Arbeitslosen an den Bedarf des Arbeitsmarktes angepasst und Verkehrsverbindungen in der gesamten Region ausgebaut werden.
<G-vec00250-003-s060><match_up.anpassen><en> The aims of the Programme are to promote entrepreneurship, match the skills of the unemployed with those required in the labour market, and upgrade transport links across the region.
<G-vec00250-003-s061><match_up.anpassen><de> Auf Implantaten befestigte Zähne wirken optisch wie die eigenen, da sie der Zahnumgebung in Farbe und Form angepasst werden und fügen sich gleichmäßig in die vorhandene Bezahnung ein.
<G-vec00250-003-s061><match_up.anpassen><en> Dentures which have been affixed to the implants look optically like your own, because they are custom-made to match the colour and shape of the teeth around them and fit in evenly within the existing row of teeth.
<G-vec00250-003-s062><match_up.anpassen><de> Die Scharniere X 8 PA sind in Form und Farbgebung an die Profile X 8 angepasst.
<G-vec00250-003-s062><match_up.anpassen><en> The shape and colour of Hinges X 8 PA match Profiles X 8.
<G-vec00250-003-s063><match_up.anpassen><de> Codierungslösungen bei Herstellern von Drähten, Kabeln und Rohren müssen an die Realität im Produktionsprozess angepasst sein.
<G-vec00250-003-s063><match_up.anpassen><en> The performance of coding solutions in wire, cable and pipe industries needs to match the realities of the production process.
<G-vec00250-003-s064><match_up.anpassen><de> Alle Produkte werden deshalb von unseren deutschen und niederländischen Ingenieuren selber entwickelt und an die lokalen Anforderungen und Gegebenheiten individuell angepasst.
<G-vec00250-003-s064><match_up.anpassen><en> Products are engineered in Germany and The Netherlands to match local requirements and produced by our quality production facilities in the United States and China.
<G-vec00250-003-s065><match_up.anpassen><de> Die Vorspannung der Federn kann stufenlos eingestellt werden und kann somit an die Anforderungen Ihrer Anwendung angepasst werden.
<G-vec00250-003-s065><match_up.anpassen><en> Both ranges are adjustable to match bench loading with the requirements for your application.
<G-vec00250-003-s066><match_up.anpassen><de> Für das Finish in Space Grau haben wir mit physikalischer Gasphasenabscheidung (PVD) die Farbe des Edelstahlrahmens genau an die des Glases angepasst.
<G-vec00250-003-s066><match_up.anpassen><en> For the space grey finish, we use a process called physical vapour deposition to precisely match the colour of the stainless steel band to that of the glass.
<G-vec00250-003-s067><match_up.anpassen><de> Die Geschwindigkeit des fortgeschrittenen Kriegers beim Anvisieren und Aufladen von Angriffen wurde leicht erhöht und an seine normale Bewegungsgeschwindigkeit angepasst.
<G-vec00250-003-s067><match_up.anpassen><en> Adv Warrior speed increased slightly when locked on and charging to match his normal movement speed Adv Warrior damage increased
<G-vec00250-003-s068><match_up.anpassen><de> Kombiniert können sie nahezu jedem Risikoprofil angepasst werden.
<G-vec00250-003-s068><match_up.anpassen><en> Used in combination, they can match virtually any risk profile.
<G-vec00250-003-s069><match_up.anpassen><de> Darüberhinaus wird die Software oft nicht genügend auf die individuellen Anforderungen des Unternehmens angepasst.
<G-vec00250-003-s069><match_up.anpassen><en> In addition, it also happens that a software does not match with the requirements or is not enough updated to the customer.
<G-vec00250-003-s070><match_up.anpassen><de> In den letzten Wochen haben wir auch das Aussehen und Verhalten der Benutzeroberfläche an den neuen Google-Stil angepasst.
<G-vec00250-003-s070><match_up.anpassen><en> In recent weeks, we also updated the look & feel of our user interface to match Google's new style.
<G-vec00250-003-s071><match_up.anpassen><de> Die Länge der Schiene ist der Größe des Skates angepasst.
<G-vec00250-003-s071><match_up.anpassen><en> The length of the frame and the size of the wheels match the size of the skate.
<G-vec00250-003-s072><match_up.anpassen><de> Farblich an Ihre Badeinrichtung angepasst oder im selben Material ausgeführt wie der Badezimmerboden.
<G-vec00250-003-s072><match_up.anpassen><en> In a colour to match your bathroom furnishings or designed in the same material as the bathroom floor.
<G-vec00250-003-s073><match_up.anpassen><de> Damit ist die Leuchte besser sichtbar, und die Lichtintensität optimal an den Signalisierungsbereich des zugehörigen Schallgebers angepasst.
<G-vec00250-003-s073><match_up.anpassen><en> As such, the light is more visible. Additionally, the light’s intensity is properly sized to match the coverage area of the associated sounder.
<G-vec00250-003-s074><match_up.anpassen><de> Je nach Tagesform oder Art der Strecke (lange Bergauffahrt, Gegenwind) kann der Lenker ganz einfach an die Bedingungen angepasst werden.
<G-vec00250-003-s074><match_up.anpassen><en> Depending on the day’s itinerary, the distance to be covered and other environmental factors (long climbs, headwinds) you can position the handlebars to precisely match the required conditions.
<G-vec00250-003-s075><match_up.anpassen><de> Eine drahtlose Vorrichtung A wireless device 1400 1400, die durch ein gefärbtes Quadrat angezeigt ist, ist in der tatsächlichen Umgebung vorhanden, und jede Messvorrichtung berichtet HF-Die Positionsberechnungsanwendung vergleicht die gemessenen HF- Kanalcharakteristika der drahtlosen Vorrichtung mit den Leistungsnachschlagtabellen, die den Knoten des Gitters zugeordnet sind, um den Satz von Knoten, dessen Nachschlagtabellen am nächsten an die gemessenen HF-Kanalcharakteristika angepasst sind, zu bestimmen.
<G-vec00250-003-s075><match_up.anpassen><en> A wireless device 1400 indicated by a colored square is present within the actual environment, and each measuring device reports RF channel characteristics for the wireless device to the position calculation application. The position calculation application compares the measured RF channel characteristics of the wireless device with the performance lookup tables associated with the vertices of the mesh to determine the set of vertices whose lookup tables most closely match the measured RF channel characteristics.
<G-vec00407-002-s038><amend.anpassen><de> Wir können diese Datenschutzerklärung jederzeit ohne Vorankündigung anpassen.
<G-vec00407-002-s038><amend.anpassen><en> We may amend this Privacy Notice at any time without notice.
<G-vec00407-002-s039><amend.anpassen><de> Um Sie darüber in Kenntnis zu setzen, wann wir Änderungen an dieser Datenschutzerklärung vornehmen, werden wir das Überarbeitungsdatum am Seitenanfang anpassen.
<G-vec00407-002-s039><amend.anpassen><en> When we make changes to this privacy statement, we will amend the revision date at the top of this page.
<G-vec00407-002-s040><amend.anpassen><de> GoEuro kann bei Bedarf diese Datenschutzrichtlinien aktualisieren und anpassen.
<G-vec00407-002-s040><amend.anpassen><en> GoEuro may update and amend this Privacy Policy Statement as necessary.
<G-vec00407-002-s041><amend.anpassen><de> Falls möglich, können Sie Ihre bisherigen Einstellungen auf dieser Website anpassen oder klicken Sie auf den „unsubscribe email"-Link, um personalisierte Emails zu deaktivieren.
<G-vec00407-002-s041><amend.anpassen><en> If available, you can amend your previous preference on our website or use our "unsubscribe email" link to opt-out of personalized emails.
<G-vec00407-002-s042><amend.anpassen><de> Sollten neue Entwicklungen dies verlangen, ist es möglich, dass wir unsere Datenschutzerklärung anpassen.
<G-vec00407-002-s042><amend.anpassen><en> We may amend our privacy policy in response to new developments.
<G-vec00407-002-s043><amend.anpassen><de> Booking.com kann die Datenschutz- und Cookie-Richtlinien von Zeit zu Zeit anpassen, also schauen Sie regelmäßig auf dieser Seite vorbei, um immer auf dem neuesten Stand zu sein.
<G-vec00407-002-s043><amend.anpassen><en> Booking.com may amend the Privacy and Cookies Policy from time to time, so visit this page regularly to stay up to date.
<G-vec00407-002-s044><amend.anpassen><de> Wir werden die Datenschutzerklärung anpassen, sobald die Änderungen an der Datenverarbeitung dies erfordern.
<G-vec00407-002-s044><amend.anpassen><en> We will amend the Privacy Policy as data processing changes so require.
<G-vec00407-002-s045><amend.anpassen><de> Wir können unsere Datenschutzerklärung von Zeit zu Zeit anpassen.
<G-vec00407-002-s045><amend.anpassen><en> We may amend this privacy notice from time to time.
<G-vec00407-002-s046><amend.anpassen><de> In solchen Fällen muss die Person, die auf unzutreffende Daten zugreifen oder diese korrigieren, anpassen oder löschen will, ihre Bitte direkt an den Partner von Blackhawk richten, mit der die direkte Beziehung besteht (der Partei, deren Kontrolle die Daten unterliegen).
<G-vec00407-002-s046><amend.anpassen><en> In those situations, an individual who seeks access, or who seeks to correct, amend, or delete inaccurate data, should direct their query to Blackhawk’s partner who has the direct relationship (the data controller).
<G-vec00407-002-s048><amend.anpassen><de> Die schnelle technologische Entwicklung des Internets und die Änderungen von Recht und Gesetz im Bereich des Datenschutzes machen es erforderlich, dass wir unserer Datenschutzerklärung von Zeit zu Zeit den neuen Anforderungen anpassen.
<G-vec00407-002-s048><amend.anpassen><en> Due to the speed of advances in internet technology and changes to data protection rights and laws, from time to time it is necessary to amend our data protection statement so that it complies with new requirements.
<G-vec00407-002-s051><amend.anpassen><de> f) erforderlichenfalls auf der Grundlage der Bewertung der Auswirkungen der unter Buchstabe e genannten Informationen die Kontrollmaßnahmen gemäß den Anforderungen nach Abschnitt 4 anpassen.
<G-vec00407-002-s051><amend.anpassen><en> f) | based on the evaluation of the impact of the information referred to in point (e), if necessary amend control measures in line with the requirements of Section 4.
<G-vec00095-002-s086><adapt.anpassen><de> Mit einer Generalüberholung können solche Fahrzeuge mit dem vernetzten Know-how des Herstellers von Grund auf modernisiert und an heutige Anforderungen vollständig angepasst werden.
<G-vec00095-002-s086><adapt.anpassen><en> A general overhaul can modernise such vehicles with the networked expertise of the manufacturer from top to bottom and can adapt them completely to today's requirements.
<G-vec00095-002-s087><adapt.anpassen><de> Aussehen und Positionierung einzelner Bedienelemente sind dabei in hohem Maße veränderbar, sodass Sie die Umgebung schnell an die eigenen Vorstellungen angepasst haben.
<G-vec00095-002-s087><adapt.anpassen><en> The appearance and positioning of individual operating elements can be changed to a great extent to quickly adapt the environment to your own requirements.
<G-vec00095-002-s088><adapt.anpassen><de> Als „Gesicht“ des THESEUS Programms bietet das Kerntechnologien-Cluster für die unterschiedlichen Use Cases oder Teilprojekte des THESEUS Programms adaptierbare Ansätze für die Wissensvisualisierung, die an dem jeweiligen Zusammenhang aber auch an die Benutzer angepasst werden können.
<G-vec00095-002-s088><adapt.anpassen><en> Being the face of the THESEUS program, the Core Technology Cluster provides adaptable knowledge visualization approaches for several use cases of the THESEUS program. These approaches provide the ability to adapt the visualization to specific contexts or users.
<G-vec00095-002-s089><adapt.anpassen><de> Wenn Ihre Umfrage nicht wirklich ihre Befragten “erhört”, sollte sie an das laufende Gespräch angepasst werden.
<G-vec00095-002-s089><adapt.anpassen><en> If your survey can truly ‘listen’ to its respondents, it should then adapt the conversation on the fly.
<G-vec00095-002-s090><adapt.anpassen><de> Die Ausführungen sind an die maschinelle Abrichteinheit angepasst.
<G-vec00095-002-s090><adapt.anpassen><en> Types are adapt to the dressing unit.
<G-vec00095-002-s091><adapt.anpassen><de> Der eigene gastronomische Bereich unseres Hotels im Geschäftsviertel von León bietet eine laufend aktualisierte Auswahl an Gerichten aus der traditionellen lokalen Küche, die den aktuellen Trends angepasst wurde.
<G-vec00095-002-s091><adapt.anpassen><en> Our hotel's own restaurant space in the very heart of León's commercial hub offers a regularly-updated menu which seeks to adapt to current trends, based on local traditional cuisine.
<G-vec00095-002-s092><adapt.anpassen><de> Daher benötigen Ingenieure flexible Software und Messtechnik zur Entwicklung neuartiger C4ISR-Kommunikationssysteme, die Bedrohungen rechtzeitig erkennen und an komplexe Signaltypen angepasst werden können.
<G-vec00095-002-s092><adapt.anpassen><en> Engineers need flexible hardware, software, and instrumentation to adapt these systems to new signal types and threats. Flexible Solutions Across the RF Spectrum
<G-vec00095-002-s093><adapt.anpassen><de> Auf dem heutigen Weltmarkt müssen Führungskräfte sicherstellen, dass sie eine skalierbare Umgebung haben, die einfach an den unvermeidbaren Wandel angepasst werden kann – insbesondere, wenn sie wachsen“, so das Fazit von Müller-Wolf von Epicor Software.
<G-vec00095-002-s093><adapt.anpassen><en> In today’s global marketplace, business leaders need to ensure they have scalable support which can easily adapt to inevitable change, especially as they grow.” concluded Gill at Epicor Software.
<G-vec00095-002-s094><adapt.anpassen><de> Wir bieten umfassende und flexible Lösungen an, die Ihren Bedürfnissen gerecht werden und an Ihren Lebenszyklus angepasst sind, damit Sie unbeschwert wohnen und leben, reisen, auf Ihre Gesundheit achten, Ihren Ruhestand vorbereiten, sparen, Ihre Familie schützen und ein Vermögen aufbauen können.
<G-vec00095-002-s094><adapt.anpassen><en> Comprehensive, flexible solutions that meet your needs and adapt to your life situation, so you can live peacefully in your home, travel, protect your health, prepare for retirement, save and protect your family and build up an estate.
<G-vec00095-002-s095><adapt.anpassen><de> Mithilfe dieser Lösung können die Prozesse im Unternehmen verschlankt, flexibilisiert und an aktuelle Herausforderungen angepasst werden.
<G-vec00095-002-s095><adapt.anpassen><en> This solution enables companies to streamline their processes, make them more flexible, and adapt them to current challenges.
<G-vec00095-002-s096><adapt.anpassen><de> Die Vietnamesen waren schon immer den anderen Kulturen gegenüber sehr offen und haben sie an ihre eigenen Lebensbedingungen zum Teil angepasst.
<G-vec00095-002-s096><adapt.anpassen><en> But the distinctive feature of the Vietnamese has always been the ability to perceive foreign culture and adapt it to their own conditions.
<G-vec00095-002-s097><adapt.anpassen><de> Stattdessen sollte „die über viele Jahre gewachsene Struktur der Förderprogramme an die aktuelle Schwerpunktsetzung der wirtschaftlichen Themen“ angepasst werden.
<G-vec00095-002-s097><adapt.anpassen><en> Instead, the aim was “to adapt the historically grown structure of the financial assistance programmes to current economic priorities.”
<G-vec00095-002-s098><adapt.anpassen><de> Es sind Dokumente mit festem Layout — sie können sich weder selbst anpassen, noch an unterschiedliche Bildschirmgrößen angepasst werden.
<G-vec00095-002-s098><adapt.anpassen><en> They're fixed-layout documents — they can't adjust or adapt to different screen sizes.
<G-vec00095-002-s099><adapt.anpassen><de> Aufgrund des modularen Aufbaus konnte das CAQ-System individuell an die Anforderungen des Markenherstellers angepasst werden.
<G-vec00095-002-s099><adapt.anpassen><en> Due to its modular structure, it was possible to individually adapt the CAQ system to the brand manufacturer’s requirements.
<G-vec00095-002-s100><adapt.anpassen><de> Die Buntbarsche (Cichliden) haben sich im Laufe der Evolution an die verschiedenen Lebensräume des Sees angepasst und endemische (nur dort lebende) Arten ausgebildet.
<G-vec00095-002-s100><adapt.anpassen><en> The cichlids have evolved to adapt to the lake’s diverse habitats and developed endemic (only existent there) species.
<G-vec00095-002-s101><adapt.anpassen><de> Leicht verständlicher und anwenderfreundlicher Entscheidungsalgorithmus, der rasch an neue Vorgehensweisen von Betrügern angepasst werden kann.
<G-vec00095-002-s101><adapt.anpassen><en> Easy to understand and user-friendly decision algorithms that can quickly adapt to a new modus operandi of fraudsters.
<G-vec00095-002-s102><adapt.anpassen><de> Da die Software flexible ist, kann sie leicht an die speziellen Bedürfnisse angepasst werden.
<G-vec00095-002-s102><adapt.anpassen><en> Since the Software are flexible it is easy to adapt the tools to various needs.
<G-vec00095-002-s103><adapt.anpassen><de> Ist flexibel, um an Innovationen und neue Geschäftsprozesse schnell und einfach angepasst zu werden.
<G-vec00095-002-s103><adapt.anpassen><en> Accelerator offers the flexibility to adapt Planon innovations and new business processes easily and quickly.
<G-vec00095-002-s104><adapt.anpassen><de> Mit der Entwicklung des Unternehmens brauchen wir mehr und mehr Talente, um mitzumachen, und jeden Monat wird eine Party stattfinden, eine neue Begrüßungszeremonie, die schnell vertraut und an das Unternehmen angepasst ist.
<G-vec00095-002-s104><adapt.anpassen><en> With the development of company, we need more and more talent to join in, and every month will hold a party for fresh, a new welcoming ceremony, which is a fast familiar with and adapt to the company.
<G-vec00095-002-s105><adapt.anpassen><de> Mit Siebdruck können wir auch solche Motive schaffen, die sie nach dem Druck auf ebene Bogenfläche an die Artikelform anpassen.
<G-vec00095-002-s105><adapt.anpassen><en> With silk screen printing on plastic or metal we can create motives that after the printing on a flat surface of a sheet subsequently “adapt” to the shape of a product.
<G-vec00095-002-s106><adapt.anpassen><de> Wenn Sie Ihr Fotoalbum oder Blog mit Ihrem Mobiltelefon abrufen, wird sich der Text und die Bilder nun an die Bildschirmgröße anpassen.
<G-vec00095-002-s106><adapt.anpassen><en> When you access your photo albums or blog with your mobile phone, the text and images will now adapt to the screen size.
<G-vec00095-002-s107><adapt.anpassen><de> Der Visualisierungs-Ersteller kann die Designs einfach im neuen grafischen Editor an die eigenen Bedürfnisse und Vorgaben anpassen.
<G-vec00095-002-s107><adapt.anpassen><en> HMI developers can simply open these templates in the new visual editor and quickly adapt them to their needs.
<G-vec00095-002-s108><adapt.anpassen><de> Den Blitz der EXILIM EX-Z800 können Sie an unterschiedliche Situationen anpassen.
<G-vec00095-002-s108><adapt.anpassen><en> You can adapt the flash of the EXILIM EX-Z800 to different situations.
<G-vec00095-002-s109><adapt.anpassen><de> Wenn nur ein geringer Teil dieser Einnahmen an arme Länder geht, damit diese sich dem Klimawandel anpassen können, könnten die Lebengrundlagen Millionen armer Menschen geschützt werden.
<G-vec00095-002-s109><adapt.anpassen><en> If a modest portion of these revenues were devoted to helping poor countries adapt to climate change, it would protect the livelihoods of millions of very poor people.
<G-vec00095-002-s110><adapt.anpassen><de> Röhlig wird auch seine Zukunft als unabhängiges Familienunternehmen in die Hand nehmen, sich schneller als andere Unternehmen an die Veränderungen auf dem Markt anpassen und nachhaltig auf einer gesunden, finanziellen Grundlage expandieren, auch in schlechten Zeiten.
<G-vec00095-002-s110><adapt.anpassen><en> Röhlig will also establish its future as an independent family business, able to adapt to changing markets faster than others and expanding its business strongly on a healthy financial basis even in times of weaker economic growth.
<G-vec00095-002-s111><adapt.anpassen><de> Bitdefender Photon™ Dank dieser innovativen und einzigartigen Technologie kann sich Bitdefender Total Security Multi-Device 2019 an die Hardware- und Software-Konfiguration Ihres Systems anpassen.
<G-vec00095-002-s111><adapt.anpassen><en> This innovative, exclusive technology helps Bitdefender Internet Security 2019 adapt to the hardware and software configuration of your system to save computing resources and improve speed and performance.
<G-vec00095-002-s112><adapt.anpassen><de> So kannst du dich blitzschnell an wechselnde Lichtbedingungen anpassen und deine Sichtscheiben im Handumdrehen reinigen.
<G-vec00095-002-s112><adapt.anpassen><en> It lets you quickly adapt to changing light conditions and makes cleaning a breeze.
<G-vec00095-002-s113><adapt.anpassen><de> Aber dank unserer tollen Spielergemeinschaft konnten wir unseren Cheat Boom Beach schnell an das aktualisierte Spiel anpassen.
<G-vec00095-002-s113><adapt.anpassen><en> But thanks to our great community of players, we were able to quickly adapt our cheat Boom Beach to the updated game.
<G-vec00095-002-s114><adapt.anpassen><de> Kaffeefarmer können die Qualität und Quantität ihrer Erträge nur halten oder verbessern, wenn sie ihre Anbaupraktiken an die Folgen der globalen Erwärmung anpassen.
<G-vec00095-002-s114><adapt.anpassen><en> Coffee farmers can only maintain or improve the quality and quantity of their yields if they adapt their farming practices to the consequences of global warming.
<G-vec00095-002-s115><adapt.anpassen><de> Man befürchtete, dass sich die vielfältige geometrische Modularität auf horizontaler als auch auf vertikaler Ebene schlecht an die Keramikformate anpassen könnte, falls keine kompensierenden Elemente eingefügt würden, die jedoch wiederum die modulare Kontinuität der Verkleidung unterbrochen hätten.
<G-vec00095-002-s115><adapt.anpassen><en> The variuos geometric modularity both horizontally and vertically made us afraid that it could not adapt to ceramic formats without the introduction of compensating elements, that would have interrupted the modular continuity of the coverage.
<G-vec00095-002-s116><adapt.anpassen><de> Kommentare Wenn sich unsere verschiedene Abonnements nicht an die Bedürfnisse Ihres Unternehmens anpassen und Sie sind auf der Suche nach etwas mehr, installieren Sie eine Lizenz von Einfacheumfrage.de, die Onlineumfragen-Software Nummer 1 in Europa und Lateinamerika.
<G-vec00095-002-s116><adapt.anpassen><en> Comments If our various types of subscriptions do not adapt to your company needs and you are looking for more, install the encuestafacil.com license, the online survey software number 1 in Europe and Latin America!
<G-vec00095-002-s117><adapt.anpassen><de> Bitdefender Photon™ Dank dieser innovativen und einzigartigen Technologie kann sich Bitdefender Internet Security 2019 an die Hardware- und Software-Konfiguration Ihres Systems anpassen.
<G-vec00095-002-s117><adapt.anpassen><en> This innovative, exclusive technology helps Bitdefender Internet Security 2019 adapt to the hardware and software configuration of your system to save computing resources and improve speed and performance.
<G-vec00095-002-s118><adapt.anpassen><de> Die neueste Version des Cruz Kajaks wurde durchdacht, so dass jeder Kajakfischer seine Kajaks problemlos an jeden Fischfang anpassen kann, ohne jemals in den Rumpf dieses Kajaks bohren zu müssen.
<G-vec00095-002-s118><adapt.anpassen><en> The newest version of the Cruz kayak has been thought out so that every kayak fisherman can easily adapt their kayak to any fishing style without ever drilling into the hull of this kayak. Recipient:
<G-vec00095-002-s119><adapt.anpassen><de> Durch Standardisierung und Berücksichtigung der Weiterentwicklung der Software können die Partner von Woodward Software aus den 1990er Jahren mit nur geringen oder gar keinen Änderungen an die heutigen fortschrittlichen Steuerplattformen anpassen.
<G-vec00095-002-s119><adapt.anpassen><en> Through standardization and attention to software evolution, Woodward’s partners can adapt 1990’s software into today’s advanced control platforms with minimal changes or when none are required.
<G-vec00095-002-s120><adapt.anpassen><de> Unser Ziel ist es, den Versuchsaufbau an alle möglichen Fragestellungen anpassen zu können, die uns im Bereich Industrie 4.0 interessieren.“ Man merkt deutlich: Nicht nur für Arora Chaudha- ry war diese Mischung aus Anwendungsbezogenheit und Grundlagenforschung spannend und neu.
<G-vec00095-002-s120><adapt.anpassen><en> But laboratory head Lass dismisses her objections: “It is not a question of achieving a perfect simulation of reality. Our goal is to be able to adapt our test set-up so that we can explore all the possible issues that interest us in the area of Industry 4.0.”
<G-vec00095-002-s121><adapt.anpassen><de> Die geografischen Unterschiede in der Färbung sind eine wichtige Grundlage für das Verständnis dafür, wie sich Tiere an klimatische Änderungen anpassen können.
<G-vec00095-002-s121><adapt.anpassen><en> Understanding the geographical differences in coloration may be important to predict how animals adapt to climate change.
<G-vec00095-002-s122><adapt.anpassen><de> Wir werden nach und nach alle Produkte an das neue CI anpassen.
<G-vec00095-002-s122><adapt.anpassen><en> We will adapt all the products to conform to the new CI.
<G-vec00095-002-s123><adapt.anpassen><de> Du sollst dich nicht an das Universum anpassen.
<G-vec00095-002-s123><adapt.anpassen><en> You should not adapt yourself to the universe.
<G-vec00095-002-s124><adapt.anpassen><de> Anwendern bieten solche Konzepte laut Perrot eine vereinfachte Möglichkeit, Beleuchtungen optimal an die Einsatzbedingungen anzupassen und über einen langen Zeitraum eine stabile Helligkeit zu erzielen, um Produktionsanlagen somit effizienter zu machen.
<G-vec00095-002-s124><adapt.anpassen><en> According to Perrot, these concepts provider users with an easier opportunity to ideally adapt illumination to their utilisation conditions and achieve stable brightness over a longer period of time so that production machines are made more efficient.
<G-vec00095-002-s125><adapt.anpassen><de> Alle Mitarbeiter/-innen sind bestrebt, die in ihrem Verantwortungsbereich geltenden Regelungen anzuwenden, ihre Wirksamkeit ständig zu überwachen und an die neuesten Kenntnisse und Erfordernisse anzupassen.
<G-vec00095-002-s125><adapt.anpassen><en> All employees are endeavored to apply the rules in their area of responsibility, to monitor their effectiveness continuously and to adapt to the latest knowledge and requirements.
<G-vec00095-002-s126><adapt.anpassen><de> Wir verwenden Ihre Informationen außerdem, um den Inhalt unserer Werbekampagnen und unserer Website zukünftig an Ihre Präferenzen und persönlichen Charakteristika anzupassen.
<G-vec00095-002-s126><adapt.anpassen><en> We also use your information to adapt the content of our advertising campaigns and our website to your preferences and personal characteristics in the future.
<G-vec00095-002-s127><adapt.anpassen><de> Fertige, progressive Antworten, leichte, intuitive Bedienelemente, verschiedene Einstellungen und Betriebsparameter, die individuell eingerichtet werden können, erlauben die Umschlagmaschine an die für die auszuführende Arbeit notwendigen Leistungen anzupassen und damit die bestmögliche Wirtschaftlichkeit im Betrieb zu erzielen.
<G-vec00095-002-s127><adapt.anpassen><en> Ready and progressive answers, easy and intuitive controls, different settings and customizable operating parameters make it possible to adapt the performances to the work to be carried out, enabling thus the maximum operating economy.
<G-vec00095-002-s128><adapt.anpassen><de> Deshalb ist es an der Zeit unsere Webseite an die neue temicon anzupassen, damit Sie erleben, was wir für Sie verwirklichen können.
<G-vec00095-002-s128><adapt.anpassen><en> Therefore, it is high time to adapt our website to the new temicon, so that you can experience what we can achieve for you.
<G-vec00095-002-s129><adapt.anpassen><de> Der neue Pflegebedürftigkeitsbegriff muss somit zum Anlass genommen werden, die Personalausstattung zu überprüfen und an den sich verändernden Bedarf anzupassen.
<G-vec00095-002-s129><adapt.anpassen><en> The new definition of the need for long-term care must be taken as an opportunity to review staffing levels and adapt them to meet changing needs.
<G-vec00095-002-s130><adapt.anpassen><de> Die beste Art, Ihre Website ohne Programmierungskenntnisse zu erstellen oder an mobile Geräte anzupassen.
<G-vec00095-002-s130><adapt.anpassen><en> The best way to create or adapt your website to mobile devices without programming skills.
<G-vec00095-002-s131><adapt.anpassen><de> Der Einsatz von Cookies ermöglicht es uns, Informationen über die Nutzung unserer Dienstleistungen zu sammeln und diese zu verbessern und an den Wünschen unserer Besucher anzupassen.
<G-vec00095-002-s131><adapt.anpassen><en> Cookies enable us to gather information on the use of our services and to improve and adapt these services to our visitors’ wishes.
<G-vec00095-002-s132><adapt.anpassen><de> Die Spieler übernehmen die Kontrolle über eine Fraktion, die durch die Wahl der Truppen, der Charaktere und der Spielkarten geformt werden kann, um sie an den Spielstil des jeweiligen Spielers anzupassen.
<G-vec00095-002-s132><adapt.anpassen><en> The players take control of a faction that can be shaped by choosing troops, characters and cards that best adapt to their game style. show more show less
<G-vec00095-002-s133><adapt.anpassen><de> Sport bringt den Körper dazu, durch die Bewegungsabläufe und den Energieumsatz die Muskulatur umzuformen und an die Anforderungen des Sports anzupassen.
<G-vec00095-002-s133><adapt.anpassen><en> Sport brings the body to convert the motion and energy expenditure muscles and adapt to the demands of the sport.
<G-vec00095-002-s134><adapt.anpassen><de> Kardiale Synkopen entstehen entweder infolge einer Verminderung der Herzleistung bei Arrhythmie oder infolge einer mangelnden Kapazität des Herzens bei Herzkrankheit, die Herzleistung an einen erhöhten Bedarf anzupassen.
<G-vec00095-002-s134><adapt.anpassen><en> Cardiac syncope occurs either due to a reduction in cardiac output because of arrhythmia or due to the inability of the heart to adapt the heart's function to higher work loads because of heart disease.
<G-vec00095-002-s135><adapt.anpassen><de> Bitte helfen Sie mit, unseren Shop optimal an Ihre Bedürfnisse anzupassen und senden Sie uns eine E-Mail mit Ihren Vorschlägen.
<G-vec00095-002-s135><adapt.anpassen><en> Please help to optimally adapt our shop to your requirements and send us an e-mail with your suggestions.
<G-vec00095-002-s136><adapt.anpassen><de> Als Entwickler und Vertreiber unserer eigenen Fahrsimulationslösung OpenDS sind wir in der Lage, Software und Hardware schnell und kostengünstig an Ihre spezifischen Bedürfnisse anzupassen.
<G-vec00095-002-s136><adapt.anpassen><en> As developers and distributors of our own driving simulation solution OpenDS we are able to quickly and inexpensively adapt the software and hardware to meet your specific needs.
<G-vec00095-002-s137><adapt.anpassen><de> Durch unsere starke Marktposition in der DACH Region und mit Hilfe unserer hochqualifizierten Spezialisten, unterstützen wir unsere Kunden dabei ihre Geschäftsmodelle zu überdenken undsich an branchenspezifische und regulatorische Anforderungen anzupassen.
<G-vec00095-002-s137><adapt.anpassen><en> With of our strong market position in the DACH region and our high qualified specialists, we support our customers by redesigning business models and by helping them to adapt to the sector-specific and regulatory requirements.
<G-vec00095-002-s138><adapt.anpassen><de> So haben Anwender mit dem Pepperl+Fuchs Box-Thin-Client-Portfolio die volle Flexibilität, um die Überwachung in der Leitwarte ganz an ihren individuellen Bedarf anzupassen.
<G-vec00095-002-s138><adapt.anpassen><en> Sow with the Pepperl+Fuchs box thin client portfolio, users can adapt monitoring in the control room to their individual needs.
<G-vec00095-002-s139><adapt.anpassen><de> Diverse Parameter erlauben es dem Benutzer unter anderem Beleuchtung und Hintergründe einzustellen und an sein Bauteil anzupassen.
<G-vec00095-002-s139><adapt.anpassen><en> Various parameters allow the user to set, among other things, lighting and backgrounds and to adapt them to his model.
<G-vec00095-002-s140><adapt.anpassen><de> Neue Akteure, die auf den Markt drängen, und die hohe Geschwindigkeit bei Markteinführungen neuer Produkte und Moden haben den Druck erhöht, das Marketing schnell an die Bedürfnisse der digitalen Verbraucher anzupassen.
<G-vec00095-002-s140><adapt.anpassen><en> The go-to market speed of new products and styles has also created pressure to quickly adapt marketing to digital consumers’ needs.
<G-vec00095-002-s141><adapt.anpassen><de> Ein weitere wichtige Freiheit, die Freie Software garantiert, ist die Freiheit, das Programm zu modifizieren und an die Bedürfnisse des Nutzers anzupassen und Kopien der modifizierten Version verbreiten zu dürfen.
<G-vec00095-002-s141><adapt.anpassen><en> Another significant freedom that Free Software guarantees is the freedom to modify the program so as to adapt it to the user's needs and to redistribute copies of the modified version.
<G-vec00095-002-s142><adapt.anpassen><de> Sie haben auch die Möglichkeit, Illustrator an Ihre spezifische Arbeitsweise anzupassen, indem Sie einen von mehreren vordefinierten Arbeitsbereichen wählen oder Ihren eigenen Arbeitsbereich erstellen.
<G-vec00095-002-s142><adapt.anpassen><en> You can adapt Photoshop to the way you work by selecting from several preset workspaces or by creating one of your own. Home screen
<G-vec00095-002-s143><adapt.anpassen><de> Damit das Motorrad einwandfrei funktioniert, muss die Motorradelektronik an einen Aprilia-Händler angepasst werden.
<G-vec00095-002-s143><adapt.anpassen><en> For correct operation of the motorcycle, it is necessary to adapt the motorcycle electronics to an Aprilia dealer.
<G-vec00095-002-s144><adapt.anpassen><de> - Textlänge: Wenn dein Text lang ist, werden Animationen angepasst, damit mehr Zeit zum Lesen bleibt.
<G-vec00095-002-s144><adapt.anpassen><en> - Text Length: when your text is long, animations adapt so there is more time to read it.
<G-vec00095-002-s145><adapt.anpassen><de> Jetzt müssen sie mit den Mitgliedstaaten zusammenarbeiten, um weiterhin Fortschritte bei Modellen der Flexicurity zu erreichen, mit denen die Arbeitsmärkte an eine globalisierte Welt angepasst werden, während gleichzeitig die Arbeitnehmer wirksam geschützt und ihnen neue Möglichkeiten eröffnet werden.
<G-vec00095-002-s145><adapt.anpassen><en> They now need to work with Member States to keep moving towards flexicurity models which adapt labour markets to a globalised world while giving workers meaningful protection and new opportunities.
<G-vec00095-002-s146><adapt.anpassen><de> Setzen Sie Ihr Haustier Spielzeug und Zubehör im Bett, so dass das Tier an das neue Bett ASAP angepasst werden kann.
<G-vec00095-002-s146><adapt.anpassen><en> Put your pet’s toys and accessories in the bed, so that the pet can adapt to the new bed ASAP.
<G-vec00095-002-s147><adapt.anpassen><de> Unabhängig davon, ob ein Objekt neu gebaut wird, es eine Nutzungsänderung erfährt, die Nutzer des Gebäudes durch Änderungen jedweder Art einer höheren Gefährdung ausgesetzt sind oder die Gefährdungslage insgesamt höher wird - Sicherheitsmaßnahmen müssen den Risiken angepasst werden können, nicht umgekehrt.
<G-vec00095-002-s147><adapt.anpassen><en> Regardless of whether a new building is being planned, an existing building is to undergo a change of purpose, a building's users are exposed to a higher level of danger as a result of changes of some kind, or the general risk situation is becoming more severe – it must be possible to adapt security measures to suit the risks involved, and not the other way round.
<G-vec00095-002-s148><adapt.anpassen><de> Dadurch wird die Geschwindigkeit an Ihre Grafik angepasst.
<G-vec00095-002-s148><adapt.anpassen><en> This will adapt the speed to your graphic.
<G-vec00095-002-s149><adapt.anpassen><de> Der Energieverbrauch des Gebäudes: Die Heizungssysteme werden angepasst um am wenigsten zu verbrauchen.
<G-vec00095-002-s149><adapt.anpassen><en> Energy consumption of houses: we adapt the heating system to consume less.
<G-vec00095-002-s150><adapt.anpassen><de> So wird beispielsweise ein Deckenanschluss für die Kopfbrause verlängert und dadurch an die architektonischen Gegebenheiten in einem Altbau angepasst.
<G-vec00095-002-s150><adapt.anpassen><en> For example, a ceiling connector for the overhead shower can be extended in order to adapt it to the architectural features in an old building.
<G-vec00095-002-s151><adapt.anpassen><de> Um Active Wear erfolgreich zu besticken, muss die Programmierung an den Stoff angepasst, das richtige Stickgarn und einen geeigneten Stabilisator ausgewählt werden - nur so können perfekte Ergebnisse erzielt werden.
<G-vec00095-002-s151><adapt.anpassen><en> For successful embroidery onto active wear, it is essential to adapt the digitising to the fabric, select the correct embroidery thread and choose the right stabiliser to achieve top-quality results.
<G-vec00095-002-s152><adapt.anpassen><de> Es befasst sich mit der aktuellen Umwelt-Governance in der marinen Arktis, untersucht, wie politische Rahmenbedingungen an neue Herausforderungen angepasst werden können und prüft Möglichkeiten für die Zusammenarbeit von EU und USA.
<G-vec00095-002-s152><adapt.anpassen><en> "Arctic Marine Governance: Opportunities for Transatlantic Cooperation" looks at the current governance environment in the marine Arctic, considers how policy frameworks can adapt to address new challenges in the region, and examines opportunities for cooperation between the European Union and the United States.
<G-vec00095-002-s153><adapt.anpassen><de> Im Zuge der Konsultationen zum Datenschutz-Gesamtkonzept stellte eine breite Mehrheit der Teilnehmer fest, dass die allgemeinen Grundsätze zwar nach wie vor gültig sind, die derzeitige Regelung aber angepasst werden muss, um besser auf die rasante Entwicklung neuer Technologien (vor allem von Online-Technologien) und die zunehmende Globalisierung reagieren zu können.
<G-vec00095-002-s153><adapt.anpassen><en> A large majority of stakeholders agreed that the general principles remain valid but that there is a need to adapt the current framework in order to better respond to challenges posed by the rapid development of new technologies (particularly online) and increasing globalisation, while maintaining the technological neutrality of the Directive.
<G-vec00095-002-s154><adapt.anpassen><de> Um die Leistung zu erhöhen, kann dieser Nilfisk auf eine breite Palette von optionalem Zubehör angepasst werden.
<G-vec00095-002-s154><adapt.anpassen><en> To increase performance, this Nilfisk can adapt to a wide range of optional accessories.
<G-vec00095-002-s155><adapt.anpassen><de> Somit können die Studien- und Lernzeiten flexibel den individuellen Arbeitszeiten und persönlichen Bedingungen angepasst werden.
<G-vec00095-002-s155><adapt.anpassen><en> This allows you to adapt studying and learning times flexibly to your individual working hours and personal circumstances.
<G-vec00095-002-s156><adapt.anpassen><de> Die Lehre kann auf dieser Basis auf die Bedürfnisse der Studierenden angepasst und zielgruppengerechter gestaltet werden, zum Beispiel durch das Angebot von Veranstaltungen, die das unterschiedliche Vorwissen oder unterschiedlichen Lernerfolg berücksichtigen.
<G-vec00095-002-s156><adapt.anpassen><en> This allows us to adapt our teaching to the needs of the students and to design it according to the target group; for example, by offering courses that take different previous knowledge levels or different learning outcomes into account.
<G-vec00095-002-s157><adapt.anpassen><de> Der Einführungsvortrag der Konferenz fragt vor diesem Hintergrund, ob stattdessen unsere Vorstellungen von Freiheit und Sicherheit den technischen Entwicklungen und Gegebenheiten angepasst werden müssen.
<G-vec00095-002-s157><adapt.anpassen><en> Against this background, the opening lecture of the conference examines whether we must rather adapt our ideas of freedom and security to changing technical developments and circumstances.
<G-vec00095-002-s158><adapt.anpassen><de> Unser Zentrum für Betreuer vermittelt Ihnen, was Sie erwartet und wie die Pflege im Früh-, Mittel- und Endstadium von Alzheimer angepasst werden muss.
<G-vec00095-002-s158><adapt.anpassen><en> Our Caregiver Center provides insight on what to expect and how to adapt care during the early, middle and late stages of Alzheimer's disease.
<G-vec00095-002-s159><adapt.anpassen><de> Wir haben fleißig gearbeitet, die Zeiten wurden immer besser, so konnte das Hotel mehrmals erweitert und den neuen Bedürfnissen angepasst werden.
<G-vec00095-002-s159><adapt.anpassen><en> Gisela Waldthaler Moser: "We worked hard, things got better and we were able to expand the hotel and adapt it to meet the new needs.
<G-vec00095-002-s160><adapt.anpassen><de> So wird das Energiemanagement immer wieder auf die aktuelle Situationen selbständig angepasst und präzise umgesetzt.
<G-vec00095-002-s160><adapt.anpassen><en> So the energy management will always automatically adapt to the current situations in the rooms - exact and automatic.
<G-vec00095-002-s161><adapt.anpassen><de> Die neue Softwareversion stellt sicher, dass SPIDERweb auch in Zukunft den neuen Technologien angepasst und weiterentwickelt werden kann.
<G-vec00095-002-s161><adapt.anpassen><en> The new software version ensures that SPIDERweb can also in future adapt to new technologies and be further developed.
<G-vec00095-002-s162><adapt.anpassen><de> Da die modernen Kunden sich von einer sorgfältig gestalteten Einkaufsreise wegbewegen, ist es der Marketer, der sich schnell anpassen kann, der die Früchte seiner Arbeit ernten wird.
<G-vec00095-002-s162><adapt.anpassen><en> With modern consumers going off-piste from carefully crafted buying journeys, it’s the marketer who is able to adapt quickly who will reap the rewards.
<G-vec00095-002-s163><adapt.anpassen><de> So können Sie komplexe Kontakt-Center-Technologien bereitstellen, Ihre Enterprise-Kontakt-Center transformieren und Ihre Prozesse an die Erwartungen Ihrer Kunden anpassen.
<G-vec00095-002-s163><adapt.anpassen><en> So you can continue to deploy complex contact center technologies, transform your enterprise contact centers, and adapt your processes to meet the expectations of your customers.
<G-vec00095-002-s164><adapt.anpassen><de> Dank der Kommentare und Meinungen über das Soller Bay Hotel by Ona Hotels, die uns unsere Gäste geschrieben haben, können wir die Wünsche der einzelnen Reisenden besser verstehen und unsere Serviceleistungen ihrem Bedarf anpassen.
<G-vec00095-002-s164><adapt.anpassen><en> Reviews Hotel in Puerto de Soller, Mallorca The reviews and opinions about the Soller Bay Hotel by Ona Hotels allow us to get to know our guests and to adapt our services to their needs.
<G-vec00095-002-s165><adapt.anpassen><de> Auf die gleiche Weise könnt ihr natürlich auch das Kleid "Ella CLASSIC" anpassen.
<G-vec00095-002-s165><adapt.anpassen><en> In the same way you can of course also adapt something like the Ella dress.
<G-vec00095-002-s166><adapt.anpassen><de> “Parallel Sysplex” formt eine wachsende Infrastruktur zu einer effektiven, belastbaren Basis, die sich neuen Technologien anpassen kann und Wachstumschancen fördert.
<G-vec00095-002-s166><adapt.anpassen><en> Parallel Sysplex enables an expanding infrastructure to be an effective, resilient foundation that can adapt to new technologies and support opportunities for growth.
<G-vec00095-002-s167><adapt.anpassen><de> Zur Sicherung Ihrer Daten unterhalten wir technische- und organisatorische Sicherungsmaßnahmen, die wir immer wieder dem Stand der Technik anpassen.
<G-vec00095-002-s167><adapt.anpassen><en> To secure your data, we maintain technical and organizational security measures, which we continually adapt to the state of the art.
<G-vec00095-002-s168><adapt.anpassen><de> Der Schilli Implantology Circle um Prof. Dr. Wilfried Schilli hat seine wissenschaftliche Erfahrung permanent im klinischen Alltag den Erfordernissen der modernen Implantattherapie anpassen können.
<G-vec00095-002-s168><adapt.anpassen><en> The Schilli Implantology Circle around Prof. Dr. Wilfried Schilli has always been able to adapt its scientific experience in ordinary clinical practice to the demands of modern implant therapy.
<G-vec00095-002-s169><adapt.anpassen><de> Die Volatilitätszunahme dürfte viele Forex Trader erleichtert aufatmen lassen, aber dies bedeutet auch, dass wir unsere Tradingtechnik diesen Veränderungen anpassen müssen.
<G-vec00095-002-s169><adapt.anpassen><en> The increase in volatility is sight for sore eyes for most Forex traders, but this also means we need to adapt our trading technique to match these changes.
<G-vec00095-002-s170><adapt.anpassen><de> Es müsse eine Minderheit nur genügend hartnäckig sein, dann würden sich die Mehrheiten schon anpassen: siehe Gendertalk, vegetarische oder koschere Speiseangebote, schmale Kravatten und kurze Konfirmandensakkos (die tatsächlich von EINEM Tagesschausprecher, Jens Riewa, durchgesetzt worden sind) oder das Tragen von Bärten.
<G-vec00095-002-s170><adapt.anpassen><en> A minority must only be sufficiently persistent, then the majorities would already adapt: see gender talk, vegetarian or kosher food offers, narrow ties and short confirmation jackets (which were actually enforced by ONE Tagesschau-anchorman, Jens Riewa) or the wearing of beards.
<G-vec00095-002-s171><adapt.anpassen><de> Wir müssen realistisch sein, Spanien ist anders, aber ist nicht mehr das, was es war, unsere Rolle verändert sich und wir müssen wissen, wie unsere neue Position anpassen und akzeptieren, dass sie vor anderen Staaten, die nicht so sehr die Krise erlitten haben, I, die effektivste und Chamäleon später unsere Glückwünsche an Länder wie die Türkei und China zu folgen, die in unserem Land zur Bewältigung der neuen Technologien ausgenutzt haben die Gebühren des Marktes, die wir frei verlassen.
<G-vec00095-002-s171><adapt.anpassen><en> We have to be realistic, Spain is different but is no longer what it was, our role is changing and we must know how to adapt to our new position and accept that they are ahead of other countries that have not suffered so much the crisis I that have been most effective and Chameleon to follow later, our congratulations to countries such as Turkey and China which have taken advantage of new technologies in our country to deal with the fees of market that we are leaving free.
<G-vec00095-002-s172><adapt.anpassen><de> So können Sie Ihr Paket ohne dauerhafte Bindung an Ihren Bedarf anpassen.
<G-vec00095-002-s172><adapt.anpassen><en> You can therefore adapt your plan to suit your needs without permanently hiking up your bill.
<G-vec00095-002-s173><adapt.anpassen><de> Bei jedem Start eines neuen Levels wird eine einzigartige Welt generiert, weswegen Sie Ihre Strategien und Taktiken während jeder Sitzung dynamisch anpassen müssen.
<G-vec00095-002-s173><adapt.anpassen><en> A unique world is generated each time a new level starts, so you will need to dynamically adapt your strategies and tactics during each session.
<G-vec00095-002-s174><adapt.anpassen><de> Der Fahrer kann dadurch das Arbeitsergebnis an verschiedene Bodenarten oder variierende Bedingungen im Feld anpassen.
<G-vec00095-002-s174><adapt.anpassen><en> This allows the driver to adapt the working result to different soil types or varying conditions in the field.
<G-vec00095-002-s175><adapt.anpassen><de> Hier erfahren Sie, wie wir unsere Dienstleistung an Ihre Anforderungen anpassen.
<G-vec00095-002-s175><adapt.anpassen><en> Here, you can learn how we adapt our solutions to your needs.
<G-vec00095-002-s176><adapt.anpassen><de> Außerdem haben Sie auch die Möglichkeit, individuell einzurichten, wie der Benachrichtigungszähler neben den Icons Ihres Anwendungsbereichs gezeigt wird, wobei Sie die Größe und die Farbe des Kennzeichens ändern und anpassen können.
<G-vec00095-002-s176><adapt.anpassen><en> Furthermore, you've also got the possibility to customize how the notifications counter will be shown next to the icons of your application tray, being able to modify and adapt the size and color of the badge.
<G-vec00095-002-s177><adapt.anpassen><de> Offensichtlich musst du dich an die Antworten des Gesprächspartners anpassen, aber eine Reihung kann hilfreich sein, um dich auf dem richtigen Weg zu halten, wenn du während des Telefonats nervös wirst.
<G-vec00095-002-s177><adapt.anpassen><en> You’ll obviously have to adapt based on your partner’s responses, but that may help keep you on track if you’re nervous about talking on the phone.
<G-vec00095-002-s178><adapt.anpassen><de> Abschätzen, anpassen und angreifen – Das gefeierte Sandbox-Gameplay von Crysis ist wieder da, mit noch mehr offenen Leveln, in denen Spieler ihren Weg und ihre Spielweise selbst bestimmen können.
<G-vec00095-002-s178><adapt.anpassen><en> Assess, Adapt, and Attack – Crysis’s highly-acclaimed sandbox gameplay is back with more open levels to let players choose their path and approach.
<G-vec00095-002-s179><adapt.anpassen><de> Greifen Sie jederzeit auf Ihre Daten zu und nutzen Sie die Vielzahl der Standardauswertungen, welche Sie ohne großen Aufwand an Ihre Bedürfnisse anpassen können.
<G-vec00095-002-s179><adapt.anpassen><en> Access your data at any time using the variety of standard reports which you can adapt easily to suit your needs. Fiscal year statistics
<G-vec00095-002-s180><adapt.anpassen><de> Wir können diese Datenschutzerklärung jederzeit ohne Vorankündigung anpassen.
<G-vec00095-002-s180><adapt.anpassen><en> We may adapt this data privacy policy at any time without prior notice.
<G-vec00095-002-s181><adapt.anpassen><de> Hier finden Sie eine Auswahl moderner Accessoires, mit denen Sie den Fahrzeuginnenraum an Ihren Stil anpassen können.
<G-vec00095-002-s181><adapt.anpassen><en> Here you will find a selection of modern accessories that allow you to adapt the vehicle interior to your style.
<G-vec00095-002-s182><adapt.anpassen><de> Interaktionen mit unseren Internetseiten werden mithilfe von Cookies und den nachfolgend genannten Technologien nachverfolgt, um diese für Sie anpassen zu können.
<G-vec00095-002-s182><adapt.anpassen><en> Interactions with our websites are tracked using cookies and the technologies specified below in order to adapt them for you.
<G-vec00095-002-s183><adapt.anpassen><de> Technische Cookies: um Ihnen eine bedienungsfreundliche und effektive Website anzubieten, verwenden wir technische Cookies, damit wir sie Ihren Bedürfnissen anpassen können.
<G-vec00095-002-s183><adapt.anpassen><en> Technical Cookies: to offer you a cutting edge and easy to use website, we use technical cookies to adapt it to your needs.
<G-vec00095-002-s184><adapt.anpassen><de> Diese Website setzt anonymisierte Cookies ein, um die Webseite bestmöglich an die Bedürfnisse unserer Besucher anpassen zu können.
<G-vec00095-002-s184><adapt.anpassen><en> This website uses anonymous cookies in order to adapt the website in the best possible way to the needs of our visitors.
<G-vec00095-002-s185><adapt.anpassen><de> Um die Größe der Blockadestelle der Ausdehnung des Gewebes 7 anpassen zu können, ist es von Vorteil, wenn der Ballon 5 nicht starr- wie in Figur 1 angedeutet - sondern auf dem Behandlungskatheter 1 verschiebbar angeordnet ist.
<G-vec00095-002-s185><adapt.anpassen><en> In order to adapt the size of the block site of the expansion of the fabric 7, it is advantageous when the balloon 5 is not rigid-as indicated in figure 1 - but slidably disposed on the treatment catheter.
<G-vec00095-002-s186><adapt.anpassen><de> Die Apfelproduzenten erhalten die Ergebnisse zeitnah, sodass sie ihren Pflanzenschutz entsprechend anpassen können.
<G-vec00095-002-s186><adapt.anpassen><en> The apple growers will receive up to date and timely information that will allow them to adapt their plant protection accordingly.
<G-vec00095-002-s187><adapt.anpassen><de> Schließlich kann die Anwendung mit einer Vielzahl von Geräten synchronisiert werden, sodass Sie Ihre Multimedia-Inhalte auf das gewünschte Gerät anpassen können.
<G-vec00095-002-s187><adapt.anpassen><en> Finally, the application can synchronize with a large variety of devices, letting you adapt your multimedia contents for the device you want.
<G-vec00095-002-s188><adapt.anpassen><de> Das Ziel von ATOSS Workforce Management ist es, die vorhandenen Personalkapazitäten intelligenter einsetzen und jederzeit schnell und agil an sich ändernde Rahmenbedingungen anpassen zu können, ohne dabei die Interessen der Mitarbeiter aus den Augen zu verlieren.
<G-vec00095-002-s188><adapt.anpassen><en> The aim of ATOSS Workforce Management is to deploy the existing personnel capacity more intelligently and give companies the ability at all times to adapt quickly and flexibly to changing framework conditions without losing sight of employees' interests.
<G-vec00095-002-s189><adapt.anpassen><de> DATENSCHUTZ SITEMAP Diese Website setzt anonymisierte Cookies ein, um die Webseite bestmöglich an die Bedürfnisse unserer Besucher anpassen zu können.
<G-vec00095-002-s189><adapt.anpassen><en> This website uses anonymous cookies in order to adapt the website in the best possible way to the needs of our visitors.
<G-vec00095-002-s190><adapt.anpassen><de> Dieser Fragebogen muss ein Monat im Voraus ausgefüllt und zurück gesendet werden, damit die Kursleiter die Unterrichtsinhalte den Interessen der Teilnehmer anpassen können.
<G-vec00095-002-s190><adapt.anpassen><en> It should be completed and send to us a month before the start of the course. The tutors will adapt the contents to the interests of the participants.
<G-vec00095-002-s191><adapt.anpassen><de> Der Text verlangt insbesondere die Errichtung eines spezifischen europäischen Handlungsrahmens für den Umgang mit den Problemen dieser Regionen, damit diese ihre dauerhafte Benachteiligung besser bewältigen und ihr Entwicklungsmodell anpassen können, um das Beste aus ihren Vorteilen zu machen.
<G-vec00095-002-s191><adapt.anpassen><en> In particular, the text calls for the establishment of a specific European policy framework to deal with the problems that these areas face in order to enable them to better overcome the permanent disadvantages and to adapt their development model by making the most of all their assets.
<G-vec00095-002-s192><adapt.anpassen><de> Die integrierte Neigefunktion der festen Wandhalterung PDW T XL sorgt für die nötige Flexibilität, um die Bildschirminstallation an die jeweiligen Anforderungen jedes radiologischen Besprechungsraums anpassen zu können.
<G-vec00095-002-s192><adapt.anpassen><en> The integrated tilt function of the solid Wall Mount PDW T XL which provides the flexibility that is needed to adapt the screen installation to the individual requirements existing for each MDT room.
<G-vec00095-002-s193><adapt.anpassen><de> Wir verwenden Cookies, um unsere Webseiten an Ihre Bedürfnisse anpassen zu können.
<G-vec00095-002-s193><adapt.anpassen><en> We use cookies in order to adapt our websites to your needs.
<G-vec00095-002-s194><adapt.anpassen><de> Genauso wichtig ist es jedoch, dass wir uns zusammenschließen, um unsere Regierungen und Firmen dazu bringen, die mutigen Taten zu setzen, die nötig sind, um die wirklich katastrophalen Auswirkungen des Klimawandels zu vermeiden, die Folgen, an die wir uns unmöglich anpassen können.
<G-vec00095-002-s194><adapt.anpassen><en> Equally important, though, is that we organise to make our governments and businesses take the bold action needed to prevent the truly catastrophic effects of climate change, the effects that are impossible to adapt to.
<G-vec00095-002-s195><adapt.anpassen><de> Zu diesem Zweck werden die entwickelten Softwarewerkzeuge in Form von Open Source zur Verfügung gestellt, sodass auch andere Forschungseinrichtungen mit Medienarchiven von den Algorithmen zur Personen- und Konzepterkennung sowie den Visualisierungstechniken profitieren und diese mit geringem Aufwand für eigene Zwecke anpassen können.
<G-vec00095-002-s195><adapt.anpassen><en> For this purpose, the software tools developed within the project will be made available in open source, enabling other research institutions with media archives to benefit from the person lexicon, concept lexicon and visualisation techniques, and to adapt them to their own needs with little effort.
<G-vec00095-002-s196><adapt.anpassen><de> Diese Datenerhebung zeigt uns, welche Browser eingesetzt werden, damit wir unsere Website entsprechend anpassen können.
<G-vec00095-002-s196><adapt.anpassen><en> This collection of data points out the browsers used in order to adapt the website accordingly.
<G-vec00095-002-s197><adapt.anpassen><de> Das Sitzungs-Cookie erfasst, welche Bereiche der Website bei einem Besuch betrachtet werden, sodass wir die Website daran anpassen können.
<G-vec00095-002-s197><adapt.anpassen><en> The session cookie records what parts of the website are looked at during a visit, and that allows us to adapt our website accordingly.
<G-vec00095-002-s198><adapt.anpassen><de> Im ersten Abschnitt jedes Werkzeugs wird erklärt, für welche Probleme (siehe Schritt 1) die Instrumente geeignet sind, die folgenden Abschnitte erklären Ihnen, wie Sie die Instrumente an Ihren Kontext anpassen können.
<G-vec00095-002-s198><adapt.anpassen><en> The first section of each tool explains what problems (see Step 1) the instruments are appropriate for, and the following sections explain how to adapt them to context. 2.2.3.2
<G-vec00095-002-s250><adapt.anpassen><de> Darüber hinaus erlauben uns Cookies, unsere Websites an Ihre speziellen Anforderungen anzupassen.
<G-vec00095-002-s250><adapt.anpassen><en> Cookies also enable us to adapt our website to your specific requirements.
<G-vec00095-002-s251><adapt.anpassen><de> Diese Entwicklung des Cybercrime zwingt Unternehmen aller Größen dazu, ihre Cybersecurity-Strategien anzupassen.
<G-vec00095-002-s251><adapt.anpassen><en> Companies of all sizes must adapt their cyber security strategies. Read more
<G-vec00095-002-s252><adapt.anpassen><de> Steuern: 166,60 € Kurzbeschreibung Dieser VGB-Standard wurde aufgestellt, um die Auslegung von Mess- und Analyse-/ Entnahmeleitungen an die erhöhten Dampfparameter und die aktualisierten Zeitstandkennwerte anzupassen.
<G-vec00095-002-s252><adapt.anpassen><en> Selection of impulse pipes and sampling lines for water and steam sectors in thermal This VGB-Standard was created to adapt the design of measurement and analytical/ discharge lines to the increased steam parameters and the updated long-term parameters.
<G-vec00095-002-s253><adapt.anpassen><de> Gen10 Server verhelfen Ihnen zu mehr Agilität und ebnen Ihnen den Weg, um Ihre IT mit Intelligent System Tuning, HPE Persistent Memory, Server Networking und innovativem Storage schnell an sich ändernde Anforderungen anzupassen.
<G-vec00095-002-s253><adapt.anpassen><en> And, Gen10 servers can improve your customers’ business agility by making it easy to adapt their IT quickly to changing requirements with Intelligent System Tuning, HPE Persistent Memory, and server networking and storage advances.
<G-vec00095-002-s254><adapt.anpassen><de> Kontinuität erfordert Verfügbarkeit und die Fähigkeit, unsere Hilfe zu modifizieren und der Zeit anzupassen, in Beziehung zur veränderten Situation des alten Menschen.
<G-vec00095-002-s254><adapt.anpassen><en> Continuity also requires being available and the ability to modify and adapt our help in time according to the changing situation of the elderly.
<G-vec00095-002-s255><adapt.anpassen><de> Im Verlauf der Jahre hat die Gesellschaft ihre Fähigkeit gezeigt, sich nicht nur an die wechselnden Marktbedingungen aber vor allem an die immer steigenden Kundenansprüche an Qualität, Genauigkeit und Zuverlässigkeit der gelieferten Maschinen anzupassen.
<G-vec00095-002-s255><adapt.anpassen><en> Over the years the company has shown its ability to adapt itself not only to the varying market conditions but most of all to the increasing customers’ demands on quality, accuracy and reliability of supplied machines.
<G-vec00095-002-s256><adapt.anpassen><de> Dabei stehen uns spezielle Prüfmethoden zur Verfügung, um die Profilform innerhalb der Freiheitsgrade (welche die einzelnen Polymere uns bieten) für jeden Kundenbedarf wiederholgenau anzupassen.
<G-vec00095-002-s256><adapt.anpassen><en> We use special test methods to adapt the profile form within the degrees of freedom (provided by the individual polymers) perfectly to each customer requirement with absolute repeat accuracy.
<G-vec00095-002-s257><adapt.anpassen><de> Der Kunde ist verpflichtet die erforderlichen technischen Voraussetzungen sowohl hinsichtlich Hard- als auch Software herzustellen und sofern erforderlich auch während der Vertragslaufzeit ständig anzupassen.
<G-vec00095-002-s257><adapt.anpassen><en> The customer is obliged to produce the necessary technical requirements both in terms of hardware and software and, if necessary, to constantly adapt them during the contract period.
<G-vec00095-002-s258><adapt.anpassen><de> (4) Der Kommission wird die Befugnis übertragen, delegierte Rechtsakte gemäß Artikel 48 zu erlassen, um die in Absatz 1 Unterabsatz 2 des vorliegenden Artikels genannte Methode an jede Änderung der im GPA vorgesehenen Methode anzupassen und so den in Artikel 8 Absatz 1 genannten Schwellenwert neu festzusetzen und den Gegenwert gemäß Absatz 2 in den nationalen Währungen der Mitgliedstaaten, deren Währung nicht der Euro ist, festzulegen.
<G-vec00095-002-s258><adapt.anpassen><en> 4. The Commission shall be empowered to adopt delegated acts in accordance with Article 103 to adapt the methodology set out in the second subparagraph of paragraph 1 of this Article to any change in the methodology provided in the GPA for the revision of the thresholds referred to in points (a) and (b) of Article 15 and for the determination of the corresponding values in the national currencies of the Member States, whose currency is not the euro, as referred to in paragraph 2 of this Article.
<G-vec00095-002-s259><adapt.anpassen><de> Heute entsteht mit dem elektrobetriebenen Fahrzeug die Chance, das Auto dem tatsächlichem Bedarf anzupassen.
<G-vec00095-002-s259><adapt.anpassen><en> Today, with the electric vehicle, the opportunity arises to adapt the car to the actual needs.
<G-vec00095-002-s260><adapt.anpassen><de> Wie wir schon vor längerer Zeit gemacht haben, erneuern wir die Empfehlung in nächster Zukunft Ihre Webseite für Mobilgeräte anzupassen.
<G-vec00095-002-s260><adapt.anpassen><en> As we did long ago, we renew the recommendation to adapt your website for mobile devices in the near future.
<G-vec00095-002-s261><adapt.anpassen><de> Der Zweck des Redmine-Implementierungsservice ist es, die Software an die Projekte und Prozesse der Kunden anzupassen und den maximalen Wert durch Easy Redmine zu liefern.
<G-vec00095-002-s261><adapt.anpassen><en> The purpose of the Redmine implementation service is to adapt the software to the clients' projects and processes and deliver maximum value from Easy Redmine.
<G-vec00095-002-s262><adapt.anpassen><de> Deshalb ist es vernünftig, die Lehren davon zu ziehen, um sie durch präzise Handlungen anzupassen, um die Qualität und die Harmonie der Umgebung zu verbessern.
<G-vec00095-002-s262><adapt.anpassen><en> So it is sensible to pull the lessons of it to adapt them through precise actions to improve the quality and the harmony of the environment.
<G-vec00095-002-s263><adapt.anpassen><de> Cookies erlauben es beispielsweise, eine Website Ihren Interessen anzupassen oder Ihr Kennwort zu speichern, damit Sie es nicht jedes Mal neu eingeben müssen.
<G-vec00095-002-s263><adapt.anpassen><en> Cookies allow us to adapt a website to your interests, for example, or to save your password so that you do not have to enter it every time you visit the site.
<G-vec00095-002-s264><adapt.anpassen><de> Unser berechtigtes Interesse an der Datenverarbeitung liegt dabei darin, die Website-Einstellungen für das von Ihnen verwendete Endgerät zu optimieren und die Benutzeroberflächen anzupassen.
<G-vec00095-002-s264><adapt.anpassen><en> The legitimate interest that we pursue when processing data is to optimise the website settings for the device you are using and to adapt the user interface accordingly.
<G-vec00095-002-s265><adapt.anpassen><de> Da Reiten ein Lebensstil ist, entwirft Harcour jedes Jahr 2 Kollektionen in limitierter Auflage und widmet sich der Pferdesportwelt, um diese dem Alltag der Reiter anzupassen und ihnen Produkte anzubieten, die sowohl modisch als auch zeitgemäß sind.
<G-vec00095-002-s265><adapt.anpassen><en> As riding is a life-style, Harcour designs each year 2 collections in limited edition and dedicated to the equestrian world to adapt riders' everyday life and to offer them products with eye-appeal that are both fashion & up-to-date.
<G-vec00095-002-s266><adapt.anpassen><de> Auswahl von Mess- und Probenahmeleitungen für die Wasser- und Dampfbereiche im Wärmekraftwerk - Dieser VGB-Standard wurde aufgestellt, um die Auslegung von Mess- und Analyse-/ Entnahmeleitungen an die erhöhten Dampfparameter und die aktualisierten Zeitstandkennwerte anzupassen.
<G-vec00095-002-s266><adapt.anpassen><en> gedacht. Selection of impulse pipes and sampling lines for water and steam sectors was created to adapt the design of measurement and analytical/ discharge lines to the increased steam parameters and the updated long-term parameters.
<G-vec00095-002-s267><adapt.anpassen><de> Die Existenz Freier Software verlässt sich auf das Recht eines Autors seine Software zusammen mit dem Quellcode zu veröffentlichen, und jedem das Recht zu gewähren, sie zu nutzen, zu kopieren, anzupassen und weiter in ihrer originalen oder veränderten Form zu verbreiten.
<G-vec00095-002-s267><adapt.anpassen><en> Its existence relies upon the right for an author to release their software along with the source code, and to grant everyone the right to use, copy, adapt and redistribute it, in its original or in a modified form.
<G-vec00095-002-s268><adapt.anpassen><de> Smoobu ist berechtigt, den Inhalt seiner Leistungen einschließlich der bereitgestellten Software im Rahmen von nutzeroberflächenbezogenen, technologischen oder inhaltlichen Weiterentwicklungen zu verändern und anzupassen, sofern die vereinbarten Funktionalitäten der Software hierdurch nicht wesentlich eingeschränkt werden.
<G-vec00095-002-s268><adapt.anpassen><en> Smoobu shall be entitled to modify and adapt the content of its services, including the software provided, in the context of user-related, technological or substantive further developments, provided that the agreed functionalities of the software are not substantially restricted thereby.
<G-vec00095-002-s269><adapt.anpassen><de> Um den Markt anzupassen, bemüht sich die Forschungs- und Entwicklungsabteilung kontinuierlich um technologische Innovationen und Muster neuer Produkte.
<G-vec00095-002-s269><adapt.anpassen><en> In order to adapt the market, R&D department continuously makes efforts on the technology innovation,and pattern of new products.
<G-vec00095-002-s270><adapt.anpassen><de> Eine wesentliche Herausforderung in den kommenden Jahren wird darin bestehen, die Beschäftigungs- und Sozialpolitik anzupassen, um sich den von der Digitalwirtschaft geschaffenen Bedürfnissen des sich schnell entwickelnden Arbeitsmarktes gerecht zu werden.
<G-vec00095-002-s270><adapt.anpassen><en> A key challenge in the years to come will be to adapt employment and social policies to better meet the rapidly evolving labour-market needs generated by the digital economy.
<G-vec00095-002-s271><adapt.anpassen><de> Das Ziel dieser Verordnung ist daher, den harmonisierten Rechtsrahmen zum Schutz des Urheberrechts und der verwandten Schutzrechte anzupassen und ein gemeinsames Konzept für die Bereitstellung von Online-Inhaltediensten für Abonnenten, die sich vorübergehend in einem anderen Mitgliedstaat als ihrem Wohnsitzmitgliedstaat aufhalten, zu schaffen, indem die Hindernisse für die grenzüberschreitende Portabilität von Online-Inhaltediensten, die rechtmäßig erbracht werden, beseitigt werden.
<G-vec00095-002-s271><adapt.anpassen><en> Therefore, the objective of this Regulation is to adapt the harmonised legal framework on copyright and related rights and to provide a common approach to the provision of online content services to subscribers temporarily present in a Member State other than their Member State of residence by removing barriers to cross-border portability of online content services which are lawfully provided.
<G-vec00095-002-s272><adapt.anpassen><de> Bei bereits bestehenden Hotels sind die Eigentümer und vor allem die Hotelbetreiber gezwungen, immer schneller zu reagieren und die Strukturen anzupassen, da sich in den letzten Jahren nicht nur der Wettbewerb in der Hotelbranche zunehmend verschärft hat sondern sich auch das Marktumfeld ständig weiterentwickelt.
<G-vec00095-002-s272><adapt.anpassen><en> For existing hotels their owners and particularly their operators are forced to respond even faster and adapt the structures, as competition in the hotel sector has intensified within the last few years and the market environment is permanently developing further. Under the heading of ‘MICE’ and wellness
<G-vec00095-002-s273><adapt.anpassen><de> Angesichts einer so stark individuell bestimmten Lyrik, und um sie dem eigenen Erwartungshorizont anzupassen, bemühten sich die Interpreten um eine Übersetzung in die Kategorien einer kollektiven Wahrheit.
<G-vec00095-002-s273><adapt.anpassen><en> Confronted with poetry of such an individual nature, and in order to adapt it to their own culturel horizon, the interpreters tried to translate the sentences into the terms of a collective truth.
<G-vec00095-002-s274><adapt.anpassen><de> Um den Markt anzupassen, bemüht sich die Forschungs- und Entwicklungsabteilung kontinuierlich um die technologische Innovation und das Muster neuer Produkte.
<G-vec00095-002-s274><adapt.anpassen><en> In order to adapt the market, R & D department continuously makes efforts on the technologyinnovation,and pattern of new products.
<G-vec00095-002-s275><adapt.anpassen><de> Damit stellt die internationale Klimapolitik nicht qualitative Veränderungen von Wirtschaft und Gesellschaft in den Mittelpunkt ihrer Bemühungen - Veränderungen, die lokale Besonderheiten berücksichtigen und darauf abzielen, globales Wirtschaften so anzupassen, dass es sich in die natürlichen Grenzen des Planeten einfügt.
<G-vec00095-002-s275><adapt.anpassen><en> In so doing, policy fails to concentrate its efforts on qualitative changes in industry and society – changes that take account of local conditions and aim to adapt global trade and industry so that they remain within planetary boundaries.
<G-vec00095-002-s276><adapt.anpassen><de> Zusätzlich besteht die Möglichkeit, die Strahlarten dem persönlichen Bedürfnis anzupassen, so dass diese sich auf die jeweilige Stimmung einstellen lässt.
<G-vec00095-002-s276><adapt.anpassen><en> In addition, it is possible to adapt the jet types to your personal needs, so that they can be adjusted to the respective mood.
<G-vec00095-002-s277><adapt.anpassen><de> Die Stiftung The Ark wird es den Forschern von Martinach über ihre Dienstleistung Accelerator ermöglichen, ihre Algorithmen anzupassen, damit sie sich in ein Armband integrieren lassen und mit einer Identifizierung der Venen des Handgelenks kompatibel sind.
<G-vec00095-002-s277><adapt.anpassen><en> The Ark Foundation, through its Accelerator service, will enable the researchers from Martigny to adapt their algorithms for integration into a bracelet, where they can be used to identify the veins of the wrist.
<G-vec00095-002-s278><adapt.anpassen><de> Diese Entwicklungen zeugen nicht nur von der herausragenden Arbeit des Amts und seiner Bediensteten, sondern auch von dauerhaften Trends, die das EPA veranlasst haben, Dienstleistungen, Verfahren und unlängst auch seine interne Struktur an das rasch veränderliche internationale Patentsystem anzupassen, in dem es sich gegen immer mehr wichtige Akteure behaupten muss.
<G-vec00095-002-s278><adapt.anpassen><en> These developments not only testify to the outstanding work of the Office and our staff, but they are also indicative of persistent trends that have led the EPO to adapt services, procedures and, last year, our internal structure to respond to a rapidly evolving international patent system with a growing number of important actors among which the EPO needs to secure its position.
<G-vec00095-002-s296><adapt.anpassen><de> Passe dein Spiel an.
<G-vec00095-002-s296><adapt.anpassen><en> Adapt your game accordingly.
<G-vec00095-002-s297><adapt.anpassen><de> Ich passe mich leicht Veränderungen an.
<G-vec00095-002-s297><adapt.anpassen><en> I easily adapt myself to changes.
<G-vec00095-002-s298><adapt.anpassen><de> Die Energie in der Form von Kohlenhydraten passe ich der Intensität und der Trainingsabsicht an.
<G-vec00095-002-s298><adapt.anpassen><en> I adapt the energy in the form of carbohydrates to the intensity and the training intention.
<G-vec00095-002-s299><adapt.anpassen><de> Ich passe mein Aussehen und meine Kleidung der Corporate Identity deines Unternehmens an: Ich kann die Stewardess sein, die Sicherheitsanweisungen gibt.
<G-vec00095-002-s299><adapt.anpassen><en> I adapt my looks and clothes to the corporate identity of your company: I can be the stewardess who gives safety instructions.
<G-vec00095-002-s300><adapt.anpassen><de> Dieses ist sogar verstellbar: Passe es auf die geeignete Länge zu Deinem Regenfass an, um das Wasser verlustarm und knickfrei über den Fassrand zu führen.
<G-vec00095-002-s300><adapt.anpassen><en> You can even adjust it: Adapt it to the length of your rain barrel, in order to lead the water without loss and kinking over the barrel edge.
<G-vec00095-002-s301><adapt.anpassen><de> Ich passe meine Zeichnungen generell dem Szenario an.
<G-vec00095-002-s301><adapt.anpassen><en> TA: Generally, I tend to adapt my style to the story.
<G-vec00095-002-s302><adapt.anpassen><de> Passe deinen Kartensatz an, entwickle deine Strategie und blicke dem Tod ins Auge, während du deine Gegner besiegst.
<G-vec00095-002-s302><adapt.anpassen><en> Adapt your deck, evolve your strategy and prepare to die as you try to defeat your enemies.
<G-vec00095-002-s303><adapt.anpassen><de> Kombiniere Diana mit verschiedenen Riemen und passe sie deinem persönlichen Style an.
<G-vec00095-002-s303><adapt.anpassen><en> Carry Diana with different straps and adapt them to your personal style.
<G-vec00095-002-s304><adapt.anpassen><de> Passe Tutanota auf alle Bedürfnisse deines Unternehmens an.
<G-vec00095-002-s304><adapt.anpassen><en> Adapt your Tutanota account to all your professional needs.
<G-vec00095-002-s305><adapt.anpassen><de> Schwierigkeitsstufen Wähle die Schwierigkeit, die du möchtest, und passe mithilfe dieser zwei Schwierigkeitsstufen das Spiel an deinen Stil an: Aufstrebender Detektiv und Meisterdetektiv.
<G-vec00095-002-s305><adapt.anpassen><en> Select the level you want to be challenged at and adapt the game to your style with two levels of difficulty: Keen detective and Master sleuth.
<G-vec00095-002-s306><adapt.anpassen><de> + Mit meinem Element-System (Grund- und Anbau) passe ich mich genau deinem Raum an – sogar über Eck.
<G-vec00095-002-s306><adapt.anpassen><en> + With my element system (basic and extension) I adapt exactly to your room – even around corners.
<G-vec00095-002-s307><adapt.anpassen><de> Gestalte unsere unterschiedlichen Gestelle und Tischplatten und passe sie an Deine Vorstellungen an.
<G-vec00095-002-s307><adapt.anpassen><en> Combine our different frames and table tops and adapt them to your ideas.
<G-vec00095-002-s308><adapt.anpassen><de> Passe unseren leistungsstarken SSD-Cloud Storage an die Anforderungen deiner Anwendung an.
<G-vec00095-002-s308><adapt.anpassen><en> Adapt our high performance SSD cloud storage to the requirements of your application.
<G-vec00095-002-s309><adapt.anpassen><de> Passe, wenn nötig, den Boden des Gebäudes an.
<G-vec00095-002-s309><adapt.anpassen><en> Adapt the building's floor if necessary.
<G-vec00095-002-s310><adapt.anpassen><de> Dabei gehen wir stets von den Wünschen des Kunden aus und passen die Regale dem Transportgut an.
<G-vec00095-002-s310><adapt.anpassen><en> We always come to the customer’s request and we adapt the racks to the overproduct.
<G-vec00095-002-s311><adapt.anpassen><de> Finden Sie das notwendige Produkt und die zugehörigen Produktinformationen schneller und passen Sie diese an die aktuellen Trends und Marktanforderungen an.
<G-vec00095-002-s311><adapt.anpassen><en> Find the necessary product and related product information faster and adapt it to current trends and market requirements.
<G-vec00095-002-s312><adapt.anpassen><de> Maßgefertigt hergestellt, besteht Brera B aus Profilen, die so konzipiert sind, dass sie Mindestabmessungen haben und diskret in bereits vorhandenen Räumen passen.
<G-vec00095-002-s312><adapt.anpassen><en> Brera B is customized and made up of profiles that are conceived to take up a minimal amount of space and to discreetly adapt in pre-existing spaces.
<G-vec00095-002-s313><adapt.anpassen><de> Zentrales Mitarbeiterprofil: Passen Sie administrative Personaldaten aus Ihren HR-Datenbank an den organisatorischen, technischen und rechtlichen Kontext Ihres Unternehmens an.
<G-vec00095-002-s313><adapt.anpassen><en> Unique employee file: Adapt the administrative data in your HR database to your company’s organisational, technical, and regulatory context.
<G-vec00095-002-s314><adapt.anpassen><de> Mit unseren integrierten und skalierbaren ERP-Lösungen passen Sie Ihre Planungs- und Steuerungsprozesse stets den Anforderungen Ihres Unternehmens an und erreichen so Ihre Ziele.
<G-vec00095-002-s314><adapt.anpassen><en> With our integrated and scalable solutions (ERP), you adapt to planning and management methods and achieve your goals.
<G-vec00095-002-s315><adapt.anpassen><de> Bitte passen Sie im Bauplan der Zeitschrift die Größe der Aussparung für das neue Verstärkermodul an.
<G-vec00095-002-s315><adapt.anpassen><en> Please adapt the cut-out for the amplifier module in the building plan.
<G-vec00095-002-s316><adapt.anpassen><de> Wir überprüfen unsere Sicherheitsmaßnahmen regelmäßig und passen sie dem technologischen Fortschritt an.
<G-vec00095-002-s316><adapt.anpassen><en> We review our security measures regularly and adapt them to technological advances.e review our security measures regularly and adapt them to technological advances.
<G-vec00095-002-s317><adapt.anpassen><de> Wir entwickeln unsere Fertigungstechnologien kontinuierlich weiter und passen sie auf Kundenbedürfnisse an.
<G-vec00095-002-s317><adapt.anpassen><en> We continually develop our manufacturing technology and adapt it to meet customer requirements.
<G-vec00095-002-s318><adapt.anpassen><de> Die Kamera wird nahezu jeder kreativen Herausforderung gerecht: Sie ist schnell, hat ein hervorragendes Ansprechverhalten und Funktionen, die zu allen Anforderungen, von der Studio-Fotografie bis zur kreativen Videogestaltung, passen und Ergebnisse auf h?chstem Niveau liefern.
<G-vec00095-002-s318><adapt.anpassen><en> This camera has been designed to meet virtually any creative challenge – it’s faster, more responsive and features the tools to adapt to everything from studio photography to creative videography, while producing results of the highest quality.”
<G-vec00095-002-s319><adapt.anpassen><de> Zusätzlich passen wir das Handling individuell auf die Vorgaben der Kunden oder des Formteils an.
<G-vec00095-002-s319><adapt.anpassen><en> In addition, we adapt the handling individually to the specifications of the customer or the molded part.
<G-vec00095-002-s320><adapt.anpassen><de> Um unser Sortiment für Sie aktuell zu halten, passen wir es laufend an die sich wandelnden Markterfordernisse sowie modische Änderungen in Design und Farbe an.
<G-vec00095-002-s320><adapt.anpassen><en> To keep our range up-to-date for you, we continuously adapt it to the changing demands of the market as well as making fashionable changes to colour and design.
<G-vec00095-002-s321><adapt.anpassen><de> Wir passen uns beim Zerlegen an die Wünsche jedes einzelnen Kunden an, der uns den Bearbeitungsgrad vorgibt: rohes Schlachtfleisch, halb-pariertes Fleisch, grob- und feinzerlegtes Fleisch.
<G-vec00095-002-s321><adapt.anpassen><en> We adapt our cutting to the wishes of each customer with a level of finishing of their choice: raw meat, semi-pared meat, ready to cut/slice meat.
<G-vec00095-002-s322><adapt.anpassen><de> Je nach Anwendungsfall passen unsere Experten den Stoffauflauf optimal an die Produktionsanforderungen und Papiersorten an.
<G-vec00095-002-s322><adapt.anpassen><en> Subject to the case of application, our experts adapt the headbox ideally to the range of grades to be produced.
<G-vec00095-002-s323><adapt.anpassen><de> Hierfür schaffen wir im Zusammenwirken mit weiteren Akteuren der LNG-Plattform die infrastrukturellen Voraussetzungen und passen die regulatorischen Rahmenbedingungen laufend den Erfordernissen an.
<G-vec00095-002-s323><adapt.anpassen><en> Therefore we create the needed infrastructural preconditions as well as adapt the regulatory framework to LNG-usage in cooperation with members and partners of the LNG-Initiative.
<G-vec00095-002-s324><adapt.anpassen><de> Auf dem Weg zu maßgeschneiderten Biokatalysatoren suchen und produzieren wir Enzyme und passen diese Ihren Aufgabenstellungen an.
<G-vec00095-002-s324><adapt.anpassen><en> On the way to tailor-made biocatalysts, we discover and produce enzymes and adapt them to your requirements.
<G-vec00095-002-s325><adapt.anpassen><de> Wir passen unser Programm an Dach-, teil- und vollintegrierten Klimaanlagen dem jeweiligen Fahrzeugdesign an.
<G-vec00095-002-s325><adapt.anpassen><en> We adapt our program to the respective vehicle design of roof-mounted, sub- and fully integrated air conditioning equipment.
<G-vec00095-002-s326><adapt.anpassen><de> Mit unserem technischen Marine-Knowhow passen wir uns den individuellen Anforderungen an Bord an.
<G-vec00095-002-s326><adapt.anpassen><en> Our technical know-how in the marine sector allows us to adapt to the individual requirements aboard each vessel.
<G-vec00095-002-s327><adapt.anpassen><de> Die Multi-Adapter in verschiedenen Holztypen passen optisch perfekt zu den NOHrD Sprossenwänden.
<G-vec00095-002-s327><adapt.anpassen><en> Multi-Adapter The multi adapter in different types of wood adapt perfectly to NOHrD wallbars
<G-vec00095-002-s328><adapt.anpassen><de> Enlarge Bahnautomatisierung, Bahnelektrifizierung, Lokomotiven, Straßenbahnen, Metrosysteme, Regional- und Hochgeschwindigkeitszüge, Depots – wir passen Fahrzeuge und Systeme auf Ihr individuelles Projekt an und stimmen alle Komponenten aufeinander ab.
<G-vec00095-002-s328><adapt.anpassen><en> Whatever your project – rail automation, railway electrification, locomotives, trams, metro systems, regional and high-speed trains or depots – we adapt vehicles and systems to your individual requirements, and perfectly coordinate all components.
<G-vec00095-002-s329><adapt.anpassen><de> Durch unsere Kooperation mit zahlreichen professionellen Partnern aus den Bereichen Warehousing and Distribution passen wir unsere Leistungen optimal an Ihre Bedürfnisse an.
<G-vec00095-002-s329><adapt.anpassen><en> Through our cooperation with numerous professional partners from the fields of warehousing and distribution, we can optimally adapt our services to your personal needs.
<G-vec00095-002-s330><adapt.anpassen><de> Die Schwenkarm- und Handreste passen Front zur Rückseite sowie auf und ab an.
<G-vec00095-002-s330><adapt.anpassen><en> The adjustable arm and hand rests adapt front to back as well as up and down.
<G-vec00095-002-s331><adapt.anpassen><de> Reisepakete und Dienstleistungen erstellen wir anhand Ihrer Wünsche und passen das Angebot unmittelbar an Ihre Bedürfnisse an.
<G-vec00095-002-s331><adapt.anpassen><en> We create travel packages and services based on your wishes and adapt the offer directly to your needs.
<G-vec00095-002-s332><adapt.anpassen><de> Starten Sie die Planungsvorlagen mit einem Klick und passen Sie das Bad dann einfach und schnell in unserem kostenfreien 3D-Badplaner an Ihre individuellen Wünsche und Bedürfnisse an.
<G-vec00095-002-s332><adapt.anpassen><en> Open the planning templates with a single click and then quickly and easily adapt the bathroom to suit your individual wishes and needs in our free 3D Bathroom Planner.
<G-vec00095-002-s333><adapt.anpassen><de> Anstelle dieser Produkte verwenden wir dann lieber Regionales und passen unsere Karte dem Erntekalender an.
<G-vec00095-002-s333><adapt.anpassen><en> Instead of these products, we prefer to use regional products and adapt our menu to the harvest calendar.
<G-vec00095-002-s334><adapt.anpassen><de> Pflanzen passen die Wurzeleisengewinnung an den aktuellen Bedarf an.
<G-vec00095-002-s334><adapt.anpassen><en> Plants adapt the iron acquisition in their roots to their current requirements.
<G-vec00095-002-s335><adapt.anpassen><de> Denn als Spezialisten-Team mit klarem Technik-Fokus kennen wir diesen Bereich wie kaum ein zweiter, nehmen als kleines Unternehmen jeden Auftrag gleichermaßen ernst und passen unsere Arbeit unkompliziert an Ihre Prozesse an.
<G-vec00095-002-s335><adapt.anpassen><en> Because as a specialist team with a clear technology focus, we know this field like no other, and - as a small company - we take each job equally serious and adapt our work to your processes without fuss.
<G-vec00095-002-s336><adapt.anpassen><de> Sowohl die Profiliergetriebe als auch die Gerüste oder Werkzeuge fertigen wir nach Ihren Wünschen, gegebenenfalls passen wir dabei Standardkomponenten an Ihre Anforderungen an.
<G-vec00095-002-s336><adapt.anpassen><en> We manufacture both the roll forming gearboxes and the frames and dies according to your wishes and where necessary we adapt standard components to meet your requirements.
<G-vec00095-002-s337><adapt.anpassen><de> Wir passen den Transport an die Bedürfnisse des Kunden an.
<G-vec00095-002-s337><adapt.anpassen><en> We adapt the transport to suit our customer´s requirements.
<G-vec00095-002-s338><adapt.anpassen><de> Beispiele von Verbotsschildern - Wählen Sie eines unserer Musterschilder und passen Sie es nach eigenen Wünschen an.
<G-vec00095-002-s338><adapt.anpassen><en> Examples of Prohibition signs - Choose one of our example signs and adapt it to your requirements.
<G-vec00095-002-s339><adapt.anpassen><de> Beispiele von Hotelschildern - Wählen Sie eines unserer Musterschilder und passen Sie es nach eigenen Wünschen an.
<G-vec00095-002-s339><adapt.anpassen><en> Examples of Hotel parking signs - Choose one of our example signs and adapt it to your requirements.
<G-vec00095-002-s340><adapt.anpassen><de> Außerdem passen wir Höhe, Volumen und Anordnung der Silozellen individuell an Ihre Produktionsstätte an.
<G-vec00095-002-s340><adapt.anpassen><en> In addition, we adapt the height, volume and layout of the silo compartments individually to your production plant.
<G-vec00095-002-s341><adapt.anpassen><de> "Vernünftige Menschen passen sich der Welt an; die unvernünftigen versuchen, sie zu verändern.
<G-vec00095-002-s341><adapt.anpassen><en> «Reasonable men adapt themselves to the world; unreasonable men persist in trying to adapt the world to themselves.
<G-vec00095-002-s342><adapt.anpassen><de> Behalten Sie jederzeit die vollen Kosten im Blick und passen Sie die Leistungen flexibel an Ihren Bedarf an.
<G-vec00095-002-s342><adapt.anpassen><en> Maintain full transparency over costs at all times and flexibly adapt the services to your needs.
<G-vec00095-002-s343><adapt.anpassen><de> Im Grossen und Ganzen passen wir uns – soweit uns das möglich ist - den Lebensgewohnheiten an und tauchen dabei in die Landschaft, die Lebens- und Arbeitsweisen und die Kultur ein.
<G-vec00095-002-s343><adapt.anpassen><en> As far as possible, we adapt to the lifestyle and immerse ourselves in the countryside and the life, work and culture of the people.
<G-vec00095-002-s344><adapt.anpassen><de> Welche Herausforderung auch vor Ihnen liegt, durch unser kompetentes Beratungsangebot im Innendienst und bei Ihnen vor Ort passen wir uns gezielt Ihrem Bedarf an.
<G-vec00095-002-s344><adapt.anpassen><en> Whatever challenges you may face, with our professional consulting services at our office and your site we specifically adapt to your needs.
<G-vec00095-002-s345><adapt.anpassen><de> Die Länge des Programmes passen wir an Ihre Wünsche an.
<G-vec00095-002-s345><adapt.anpassen><en> We adapt the length of the program to your wishes.
<G-vec00095-002-s346><adapt.anpassen><de> Wir passen uns den Anforderungen unserer nationalen und internationalen Kunden an und sind daher jetzt auch nach AEO-C zertifiziert.
<G-vec00095-002-s346><adapt.anpassen><en> We adapt ourselves to the requirements of our national and international customers. Therefore, we are certified according to AEO-C now.
<G-vec00095-002-s347><adapt.anpassen><de> Wir haben die Idee, entwickeln daraus das Konzept und passen es Ihren wünschen an.
<G-vec00095-002-s347><adapt.anpassen><en> We have the idea, develop the concept from it and adapt it to your wishes.
<G-vec00095-002-s348><adapt.anpassen><de> WC und Waschtische passen sich auf Knopfdruck den unterschiedlichsten Bedürfnissen an.
<G-vec00095-002-s348><adapt.anpassen><en> WC and Wash Basins adapt to the most different of needs at the touch of a button.
<G-vec00095-002-s349><adapt.anpassen><de> Die weichen Seiten aus Gummi passen sich den Konturen deiner Zähne und des Zahnfleischs an, um so übermässigen Druck zu absorbieren.
<G-vec00095-002-s349><adapt.anpassen><en> The soft rubber sides adapt to the contours of your teeth and gums to absorb excessive pressure.
<G-vec00095-002-s350><adapt.anpassen><de> Es gibt ihn in hellblau oder rosa und beide Farben passen sich der Haut sehr gut an.
<G-vec00095-002-s350><adapt.anpassen><en> There is a light blue and pink version of it and both shades adapt perfectly to the skin’s tone.
<G-vec00095-002-s351><adapt.anpassen><de> Die von Mopar® vertriebenen Scheibenwischerblätter von Fiat, Alfa Romeo, Lancia, Fiat Professional, Jeep® und Abarth ermöglichen auf all das zu vertrauen und passen sich perfekt an die Form und Schräge der Windschutzscheibe der Fahrzeuge der FIAT Gruppe an, da sie auf Maß designt wurden.
<G-vec00095-002-s351><adapt.anpassen><en> This you can rely on with the wiper blades distributed by Mopar® for Fiat, Alfa Romeo, Lancia, Fiat Professional, Jeep® and Abarth vehicles, because they are designed to measure and adapt perfectly to the shape and inclination of the windscreen of all FCA vehicles.
<G-vec00095-002-s352><adapt.anpassen><de> Unsere Services passen sich effizient an Ihre Geschäftsanforderungen an und fördern die richtigen Ergebnisse für Ihr Unternehmen.
<G-vec00095-002-s352><adapt.anpassen><en> Our services adapt efficiently to your business needs and drive the right business outcomes for your company.
<G-vec00095-002-s353><adapt.anpassen><de> Die unterschiedlichen Lamellen passen sich flexibel an alle Wetterumschwünge an und stellen so kompromisslosen Grip, kontrollierten Fahrspaß und eine ruhige Fahrt sicher.
<G-vec00095-002-s353><adapt.anpassen><en> The different sipes flexibly adapt to all weather variations, offering relentless grip and enjoyably controlled and quiet driving.
<G-vec00095-002-s354><adapt.anpassen><de> Die UMC Generatoren passen sich dabei mit 250 oder 500 Watt Leistung optimal an individuelle Reinigungsanforderungen an.
<G-vec00095-002-s354><adapt.anpassen><en> With power outputs of 250 or 500 Watt, the UMC generators are able to optimally adapt to individual cleaning requirements.
<G-vec00095-002-s355><adapt.anpassen><de> Die ICE-Bahnhöfe Limburg und Montabaur passen sich „eindrucksvoll“ in transeuropäische Netze ein.
<G-vec00095-002-s355><adapt.anpassen><en> The high speed ICE stations Limburg and Montabaur adapt impressively into trans-European networks.
<G-vec00095-002-s356><adapt.anpassen><de> Die realisierten Produkte passen sich den Anforderungen Ihrer Produktion perfekt an und verbessern zudem in jedem Stadium ihre Leistung.
<G-vec00095-002-s356><adapt.anpassen><en> The manufactured products adapt perfectly to the needs of your production, amplifying the performances in each phase.
<G-vec00095-002-s357><adapt.anpassen><de> Sie passen sich ihrer jeweiligen Umgebung hervorragend an, und es gab sie schon lange vor dem Menschen.
<G-vec00095-002-s357><adapt.anpassen><en> They adapt excellently to their respective environment, and they existed long before humans.
<G-vec00095-002-s358><adapt.anpassen><de> Aufgrund ihres elegant schlichten Designs und der stromlinienförmigen Ausrichtung passen sich die Möbel der Outdoor Kollektion Alize problemlos einer Vielzahl von Umgebungen an.
<G-vec00095-002-s358><adapt.anpassen><en> Due to its elegant and light design and the streamlined orientation the outdoor furniture collection Alize easily adapt to a variety of furnishings.
<G-vec00095-002-s359><adapt.anpassen><de> Aus diesem Grund passen sich Jacken mit hydrophilen Membranen deinem Aktivitätsniveau an und speichern hervorragend Wärme.
<G-vec00095-002-s359><adapt.anpassen><en> As a result jackets that use hydrophilic membranes adapt to your activity level and retain heat well.
<G-vec00095-002-s360><adapt.anpassen><de> Fast eine Milliarde winzig kleiner Fasern im inneren Kissen passen sich deinen Bewegungen an und sorgen für angenehm federnde Unterstützung.
<G-vec00095-002-s360><adapt.anpassen><en> Nearly a billion shorter fibers adapt to your movements to create our pillow’s signature springy support.
<G-vec00095-002-s361><adapt.anpassen><de> Personalisierbare Fronten und individuelle Erscheinung passen sich der CI und dem Einsatzort flexibel an.
<G-vec00095-002-s361><adapt.anpassen><en> Personalizable front panels and individual appearance adapt flexible to the CI and the application site.
<G-vec00095-002-s362><adapt.anpassen><de> Die MEX-Schwanenhalsmikrofone mit ihrem zahlreichen Montagezubehör passen sich jeder Umgebung bestens an.
<G-vec00095-002-s362><adapt.anpassen><en> The MEX gooseneck microphones with their numerous mounting accessories adapt perfectly to any environment.
<G-vec00095-002-s363><adapt.anpassen><de> Aus hochwertigen, weichen Materialien passen sie sich den Veränderungen der Figur perfekt an und sorgen so für Ihr Wohlgefühl.
<G-vec00095-002-s363><adapt.anpassen><en> Made from high-quality, soft materials, they adapt perfectly to the changes in your figure, ensuring that you feel comfortable.
<G-vec00095-002-s364><adapt.anpassen><de> Die meisten passen sich so schnell wie jeder andere Mitarbeiter an, einige brauchen mehr Zeit und passen sich gradweise an.
<G-vec00095-002-s364><adapt.anpassen><en> Most adapt as fast as any other employee, some need more time and adapt gradually.
<G-vec00095-002-s366><adapt.anpassen><de> Durch Echtzeitüberwachung der Betriebe minimieren Sie Verspätungen und passen sich unvorhergesehenen Umständen an.
<G-vec00095-002-s366><adapt.anpassen><en> Minimize delays and adapt to unforeseen circumstances with real-time monitoring of operations.
<G-vec00095-002-s367><adapt.anpassen><de> (1) Jedes Organ passt seine Geschäftsordnung an die Bestimmungen dieser Verordnung an.
<G-vec00095-002-s367><adapt.anpassen><en> 1. Each institution shall adapt its rules of procedure to the provisions of this Regulation.
<G-vec00095-002-s368><adapt.anpassen><de> Aufgrund der gesammelten Informationen passt ein Stellantrieb an der Mischergruppe die Vorlauftemperatur fortlaufend an den tatsächlichen Heizbedarf an.
<G-vec00095-002-s368><adapt.anpassen><en> Based on the information, an actuator on the mixing shunt will constantly adapt the supply temperature to the actual heat demand.
<G-vec00095-002-s369><adapt.anpassen><de> Gemeinsam mit den Fachbereichen entwickelt die Abteilung IT & Organisation neue Software-Lösungen und passt sie an die Arbeitsabläufe in den jeweiligen Arbeitsbereichen an.
<G-vec00095-002-s369><adapt.anpassen><en> Together with the technical departments, they develop new software solutions and adapt these with the flow of work in the respective departments.
<G-vec00095-002-s370><adapt.anpassen><de> Unser Team passt die Gerichte in Bezug auf spezielle Essgewohnheiten gerne an, wenn wir im Vorfeld informiert werden.
<G-vec00095-002-s370><adapt.anpassen><en> Our team will be happy to adapt to specific diets when previously informed.
<G-vec00095-002-s371><adapt.anpassen><de> Bei der Gelegenheit passt man die Haube an, die nun aus Blech und nicht mehr aus Kunststoff geformt ist.
<G-vec00095-002-s371><adapt.anpassen><en> On the occasion you adapt the hood, which is now made of sheet metal and no longer of plastic.
<G-vec00095-002-s372><adapt.anpassen><de> Durch die Varioflex Technologie passt das Visier seine Tönung automatisch den Lichtverhältnissen an.
<G-vec00095-002-s372><adapt.anpassen><en> The Varioflex technology allows the visor to adapt its tint to the prevailing lighting conditions.
<G-vec00095-002-s373><adapt.anpassen><de> 3 Der Bundesrat passt den Inhalt der Grundversorgung periodisch den gesellschaftlichen und wirtschaftlichen Bedürfnissen und dem Stand der Technik an.
<G-vec00095-002-s373><adapt.anpassen><en> 3 The Federal Council shall periodically adapt the content of the universal service in accordance with the state of the art and social and economic requirements.
<G-vec00095-002-s374><adapt.anpassen><de> SB ist völlig responsive und passt sich jedem Gerät an.
<G-vec00095-002-s374><adapt.anpassen><en> SB is fully responsive and will adapt itself to any mobile or tablet device.
<G-vec00095-002-s375><adapt.anpassen><de> Auch das AMG DYNAMIC SELECT passt die Charakteristik des Fahrzeugs auf Ihre Wünsche und Bedürfnisse an: von effizient, komfortabel über sportlich bis hin zu besonders sportlich.
<G-vec00095-002-s375><adapt.anpassen><en> Even the AMG DYNAMIC SELECT can adapt the vehicle’s characteristics to your wishes and needs: From efficient to comfortable to sporty to extremely sporty.
<G-vec00095-002-s376><adapt.anpassen><de> Ob Armbänder, Dockingstation mit Ladefunktion, Halterungen oder Ständer: Wer stilsicher unterwegs ist, der passt sein Apple Watch Zubehör von xMount der Uhr, dem Trend und dem täglich wechselnden Stil an.
<G-vec00095-002-s376><adapt.anpassen><en> Whether wristbands, docking station or mounts: People with an assured sense of style adapt their Apple Watch accessories to the watch, the trend and daily changing style.
<G-vec00095-002-s377><adapt.anpassen><de> Die Kalibrierung eines Schichtdicken- messgerätes ist in wenigen Schritten durchgeführt und passt den MiniTest optimal an die Messaufgabe an, um höchste Präzision in der Schichtdicken- messung zu gewährleisten.
<G-vec00095-002-s377><adapt.anpassen><en> Only a few calibration steps are necessary to adapt a coating thickness gauges perfectly to the measuring task thus assuring highest precision in coating thickness measurement.
<G-vec00095-002-s378><adapt.anpassen><de> Per Klettverschluss und Gummizug passt du dieses Beinkleid an deine Körpermaße an.
<G-vec00095-002-s378><adapt.anpassen><en> By Velcro and elastic band you adapt this leg dress to your body measurements.
<G-vec00095-002-s379><adapt.anpassen><de> Das Getriebe passt die hohe Drehzahl des Motors an die niedrigere Drehzahl des Rades an.
<G-vec00095-002-s379><adapt.anpassen><en> The gears adapt the motor's high rotational speed to the low rotational speed of the wheel.
<G-vec00095-002-s380><adapt.anpassen><de> Zudem entwickelt der Vorstand die Führungskultur weiter und passt sie an die neuen Herausforderungen an.
<G-vec00095-002-s380><adapt.anpassen><en> Moreover, the Executive Board wants to further develop our management culture and to adapt it to new challenges.
<G-vec00095-002-s381><adapt.anpassen><de> Die neue DAB e.sybox mini bietet eine komplette Lösung und passt sich den ständig wechselnden Anforderungen des Systems an.
<G-vec00095-002-s381><adapt.anpassen><en> The new DAB e.sybox mini offers a complete solution and will adapt itself to the ever changing demands of the system.
<G-vec00095-002-s382><adapt.anpassen><de> Kreative Steuerung des Fokus Die Steuerung der AF-Reaktion und AF-Geschwindigkeit des Dual Pixel CMOS AF passt den Autofokus an die Aufnahmesituation an und verleiht Ihren Videos damit ein einzigartiges Aussehen.
<G-vec00095-002-s382><adapt.anpassen><en> Control over Dual Pixel CMOS AF sensitivity and speed for movies allows you to adapt the focus to the shooting situation and create a slow, natural or fast-paced look for your movie.
<G-vec00095-002-s383><adapt.anpassen><de> Es passt seine Lichtleistung automatisch und kontinuierlich der jeweiligen Verkehrssituation und Umgebung an.
<G-vec00095-002-s383><adapt.anpassen><en> The glare-free matrix headlights automatically and continuously adapt to the prevailing traffic situation and surroundings.
<G-vec00095-002-s384><adapt.anpassen><de> Er entwickelt Projekte für die Menschen in einem bestimmten Kiez – hier das Rollbergviertel – und passt seine Angebote flexibel den Bedürfnissen der Zielgruppe an.
<G-vec00095-002-s384><adapt.anpassen><en> We develop projects for people in a particular area - here the Rollberg district - and adapt our offers flexibly to the needs of the target group.
<G-vec00095-002-s385><adapt.anpassen><de> Passt euch an den Tag/Nacht-Zyklus und die sich ändernden Wetterbedingungen an, während ihr Waffen herstellt, um eure Feinde in spannenden und taktischen Kämpfen zu besiegen.
<G-vec00095-002-s385><adapt.anpassen><en> Adapt to the day/night cycle and changing weather conditions as you craft weapons to take down your foes in tense tactical combat.
<G-vec00095-002-s386><adapt.anpassen><de> Gefertigt aus einem weichen und besonders dehnbaren Material ist dieses Babydoll angenehm zu tragen und passt sich leicht den weiblichen Kurven an.
<G-vec00095-002-s386><adapt.anpassen><en> Made from soft and exceptionally stretchy material, this comfortable babydoll will adapt to your feminine curves.
<G-vec00095-002-s387><adapt.anpassen><de> Die Fahrdynamik passt sich auf Knopfdruck mit vier Fahroptionen "Komfort", "Sport", "Eco" und "Individual" Ihrer Stimmung an.
<G-vec00095-002-s387><adapt.anpassen><en> The driving dynamics adapt to your mood at the touch of a button with four driving options "Comfort", "Sport", "Eco" and "Individual".
<G-vec00095-002-s388><adapt.anpassen><de> Dieser Laufschuh zum Aufpumpen passt sich wie kein anderer deiner Fußform an und überzeugt durch sein perfekt durchdachtes Design.
<G-vec00095-002-s388><adapt.anpassen><en> Obsessively engineered and made to adapt, this pumped up runner conforms to your foot in a way no other shoe can touch.
<G-vec00095-002-s389><adapt.anpassen><de> Die Pflanze passt sich je nach Standort optimal an, sei es als niedriger oder breit ausladender Strauch, sei es als säulenförmiger Baum.
<G-vec00095-002-s389><adapt.anpassen><en> Depending on its location, the plant has the ability to adapt ideally to its surroundings, whether as low-lying or wide shrubs, or as columnar trees.
<G-vec00095-002-s390><adapt.anpassen><de> Der flach profilierte Pulse IGNITE XT Swan ist unser dynamischster Crosstraining-Schuh für Frauen, passt sich jederzeit an deine Trainingsintensität an und bietet genau die Flexibilität, die dein Workout gerade verlangt.
<G-vec00095-002-s390><adapt.anpassen><en> As our most dynamic women's cross-training shoe, the low-profile Pulse IGNITE XT is designed to adapt to the boldness and flexibility of any workout.
<G-vec00095-002-s391><adapt.anpassen><de> Die frei erweiterbare Infrastruktur für inkrementelle Datenintegration und semantische Datenanalyse passt sich dynamisch Ihrem System-, Prozess- und Informationsbedarf an.
<G-vec00095-002-s391><adapt.anpassen><en> Extensible infrastructure keeps pace with business dynamics, using incremental data integration and semantic analysis to dynamically adapt to changing systems, process, and information needs.
<G-vec00095-002-s392><adapt.anpassen><de> Die Lichtlösung „Tunable White“ bildet deshalb das Tageslicht nach und passt sich individuellen Bedürfnissen an.
<G-vec00095-002-s392><adapt.anpassen><en> The “Tunable White” solution simulates natural daylight and can adapt to personal requirements.
<G-vec00095-002-s393><adapt.anpassen><de> Dank der umklappbaren Beifahrersitzlehne und der verschiebbaren Rücksitzbank ist er geräumig und passt sich flexibel an Ihre Wünsche an.
<G-vec00095-002-s393><adapt.anpassen><en> Thanks to the sliding rear seat bench, it is spacious and also flexible enough to adapt to any requirements.
<G-vec00095-002-s394><adapt.anpassen><de> Focke Meler passt sich den besonderen Anforderungen jeder Anwendung zu einem wettbewerbsfähigen Preis mit einem ausgezeichneten Beratungsservice vor und nach dem Verkauf und einem technischen Kundendienst in der ganzen Welt sowie extrem kurzen Lieferzeiten (zwischen 24 und 48 Stunden bei Standardmaterialien) an.
<G-vec00095-002-s394><adapt.anpassen><en> At Focke Meler, we adapt to the specific needs of each application, offering a very competitive price, an excellent pre and after sales service, with technical assistance all over the world and minimal delivery times (between 24 and 48 hours for standard material).
<G-vec00095-002-s395><adapt.anpassen><de> MyFairs ist in den Sprachen deutsch und englisch erhältlich; die Anwendung passt sich der jeweiligen Landeseinstellung an.
<G-vec00095-002-s395><adapt.anpassen><en> MyFairs is available in German and English. App functions automatically adapt to the language selection.
<G-vec00095-002-s453><adapt.anpassen><de> Die SRAM Guide R mit einem bewährten 4-Kolben-Bremssattel lässt sich dank des integrierten Flip Chips präzise auf unterschiedliche Terrains und deinen Fahrstil anpassen.
<G-vec00095-002-s453><adapt.anpassen><en> The integrated Flip Chip lets you further adapt the bike’s geometry to suit your technique and terrain.
<G-vec00095-002-s454><adapt.anpassen><de> Das integrierte Motion System verleiht der Binde eine unglaubliche Flexibilität, wodurch sie sich sogar heftigen Bewegungen anpassen kann.
<G-vec00095-002-s454><adapt.anpassen><en> Integrated Motion system that gives incredible flexibility to the pad, allowing it to adapt even to more extreme movements.
<G-vec00095-002-s455><adapt.anpassen><de> Einige langfristige Trends verändern das globale Umfeld und treiben den Aufstieg neuer hochkarätiger Marken voran – während andere sich nicht anpassen können.
<G-vec00095-002-s455><adapt.anpassen><en> A number of long-term trends are reshaping the global landscape, awakening new high profile brands - while others may fail to adapt.
<G-vec00095-002-s456><adapt.anpassen><de> Man muss sich anpassen wenig von Perspektiven, wie groß der Schwimmer sein sollte.
<G-vec00095-002-s456><adapt.anpassen><en> One must adapt little by prospects how great the float should be.
<G-vec00095-002-s457><adapt.anpassen><de> G-1000 Heavy Duty ist zwar vorgewachst, doch es lohnt sich, das Auftragen und Entfernen des Wachses zu lernen, damit du deine Jacke den Bedingungen entsprechend anpassen kannst.
<G-vec00095-002-s457><adapt.anpassen><en> Most of our G-1000 materials come pre-waxed, but it’s still a good idea to know how to re-apply and remove the wax to adapt your jacket to the conditions.
<G-vec00095-002-s458><adapt.anpassen><de> Andere Arten müssen sich anpassen oder sterben.
<G-vec00095-002-s458><adapt.anpassen><en> Other species must adapt or die.
<G-vec00095-002-s459><adapt.anpassen><de> Diese Eigenschaft bedeutet, dass sie sich leicht an die Umwelt während ihres Wachstums anpassen.
<G-vec00095-002-s459><adapt.anpassen><en> This feature means that they easily adapt to the environment during their growth.
<G-vec00095-002-s460><adapt.anpassen><de> Bei einer Modernisierung hingegen muss man sich den Gegebenheiten anpassen.
<G-vec00095-002-s460><adapt.anpassen><en> For modernizations, we have to adapt to the existing situation.
<G-vec00095-002-s461><adapt.anpassen><de> Der einzigartige Mädchen Bikini ist vollständig mit elastischen Bändern eingefasst, die sich dem Körper individuell anpassen.
<G-vec00095-002-s461><adapt.anpassen><en> This unique girl's bikini is completely bordered with elasticated straps which adapt individually to the
<G-vec00095-002-s462><adapt.anpassen><de> Mit HÜPPE Studio Paris elegance können Sie sich fexibel an die baulichen Gegebenheiten Ihres Bades anpassen, ohne Kompromisse im Design eingehen zu müssen.
<G-vec00095-002-s462><adapt.anpassen><en> HÜPPE Studio Paris elegance allows you to adapt the shower space to the structural elements in your bathroom without having to compromise on design.
<G-vec00095-002-s463><adapt.anpassen><de> Doch sobald Lawinengefahr herrscht, verschwinden die Tiere, wie von Zauberhand weggebracht: „Gämsen können sich ihrer alpinen Umgebung sehr gut anpassen“, sagt Wildhüter Bruno Tscherrig.
<G-vec00095-002-s463><adapt.anpassen><en> But as soon as there is danger of an avalanche the animals vanish as if by magic: ‘‘Chamois can adapt themselves very well to their alpine environment“, says game warden Bruno Tscherrig.
<G-vec00095-002-s464><adapt.anpassen><de> Viertens kann sich es schwierigen Arbeitsbedingungen anpassen; es wird in hohem Grade vor Staub und Feuchtigkeit mit Dichtung IP67 geschützt.
<G-vec00095-002-s464><adapt.anpassen><en> Fourthly, It can adapt to difficult working conditions; it is highly protected from dust and moisture with IP67 sealing.
<G-vec00095-002-s465><adapt.anpassen><de> Es besitzt eine Reihe von Vorteilen: Die Produktionsverfahren sind für die entsprechenden Produkte am besten geeignet; es ist insofern flexibel, als es sich rasch an kleinere Veränderungen der den Daten zugrundeliegenden Phänomene anpassen lässt; es unterliegt der Kontrolle des Bereichsleiters und weist eine risikoarme Geschäftsarchitektur auf, da ein Problem in einem Produktionsprozess in der Regel keine Auswirkungen auf die übrige Produktion haben dürfte.
<G-vec00095-002-s465><adapt.anpassen><en> It has a number of advantages: the production processes are best adapted to the corresponding products; it is flexible in that it can adapt quickly to relatively minor changes in the underlying phenomena that the data describe; it is under the control of the domain manager and it results in a low-risk business architecture, as a problem in one of the production processes should normally not affect the rest of the production.
<G-vec00095-002-s466><adapt.anpassen><de> Das Bett kann sich der Entwicklung Ihres Kindes anpassen und Ihr Kind die gesamte Kindheit begleiten.
<G-vec00095-002-s466><adapt.anpassen><en> One bed can adapt to your child’s development and age the entire childhood.
<G-vec00095-002-s467><adapt.anpassen><de> Im Namen der Solidarität sollten Sie sich den Umständen anpassen und die Gruppe unterstützen.
<G-vec00095-002-s467><adapt.anpassen><en> In the name of solidarity you should adapt to the circumstances and support the group.
<G-vec00095-002-s468><adapt.anpassen><de> Basierend auf unserem transversalen Wissen, gesammelte Erfahrung und Empathie mit den Nutzern, gestalten und entwickeln wir personalisierte Werkzeuge, die sich an die jeweiligen Bedürfnisse anpassen, die produktive Prozesse unserer Kunde vereinfachen, optimieren und sich damit integrieren.
<G-vec00095-002-s468><adapt.anpassen><en> Parting from our transversal knowledge, accumulated experience and user empathy, we design and develop custom tools that adapt to any particular needs and facilitate, optimise and integrate with the productive processes of our clients.
<G-vec00095-002-s469><adapt.anpassen><de> Und da die Hindernisse und Gelegenheiten in der Konkurrenz des Weltmarktes sich in Raum und Zeit immer wieder ändern, muss die wirtschaftliche Katze, gleich welcher Farbe, um Erfolg zu haben, sich diesen Veränderungen anpassen oder sie schafft es nicht, irgendwelche Mäuse zu fangen.
<G-vec00095-002-s469><adapt.anpassen><en> And since the obstacles and opportunities in the competitive world market change over time and in place, to succeed the economic cat, no matter what its color, must adapt to these changes or fail to catch any mice at all.
<G-vec00095-002-s470><adapt.anpassen><de> Der Mensch kann unter jedem Wirtschaftsverhältnis leben, er kann sich jeder Form des politischen Lebens anpassen, ohne daß dadurch die Gesetze, denen sein physisches Sein unterworfen ist, berührt würden.
<G-vec00095-002-s470><adapt.anpassen><en> Man can live in any economic relationship, can adapt himself to any form of political life, without affecting in the slightest the laws to which his physical being is subject.
<G-vec00095-002-s471><adapt.anpassen><de> Unter diesen extremen Bedingungen waren Rettungseinsätze schon immer eine Priorität für die Bevölkerung und die Küstenhäfen mussten sich anpassen und mit immer leistungsfähigeren Geräten ausstatten.
<G-vec00095-002-s471><adapt.anpassen><en> In these extreme conditions, rescue operations have always been a priority for the population and coastal ports have had to adapt and endow themselves with ever more efficient equipment.
<G-vec00095-002-s472><adapt.anpassen><de> Oder Sie liefern die Anzeige als HTML-Snippet, welches sich dank CSS Media Queries an die jeweilige Bildschirmgröße anpasst.
<G-vec00095-002-s472><adapt.anpassen><en> Or you can provide an HTML snippet, which can adapt to the current screen size via css media queries and utilize the full size of the area.
<G-vec00095-002-s473><adapt.anpassen><de> Diese Methode ermöglicht es, dass das Leder des Schuhs flexibler ist und sich dem Fuß jeder Person anpasst, wodurch maximaler Komfort erreicht wird.
<G-vec00095-002-s473><adapt.anpassen><en> This method allows the shoe's leather to be more flexible and adapt to each person's foot, achieving maximum comfort.
<G-vec00095-002-s474><adapt.anpassen><de> Und auch wenn gute Konzepte greifen, ist es unabdingbar, dass das Startup sich stetig anpasst, um am Markt dran zu sein und seinen Vorsprung weiter auszubauen.
<G-vec00095-002-s474><adapt.anpassen><en> And even if a concept is well accepted, it is imperative for a startup to constantly adapt in order to keep up with the market and continue to build on its lead.
<G-vec00095-002-s475><adapt.anpassen><de> Durch das innovative Design der AirFit N20 mit seiner speziellen Form und Oberfläche wird sichergestellt, dass die Maske sich den individuellen Gesichtskonturen jedes Ihrer Patienten anpasst und, unabhängig von Gesichtsform und -größe, eine zuverlässige Abdichtung bietet.
<G-vec00095-002-s475><adapt.anpassen><en> With its innovative design, AirFit N20 has been finished and shaped to adapt to the unique facial contours of each of your patients, offering a robust seal regardless of face shape or size.
<G-vec00095-002-s476><adapt.anpassen><de> Gummi und die Abdeckfeder nehmen den Gummi auf, der gegen Ozon und UV beständig ist und sich an verschiedene klimatische Bedingungen anpasst.
<G-vec00095-002-s476><adapt.anpassen><en> Rubber and the covering spring take the rubber, which are resistant to ozone and UV and adapt to different climatic conditions.
<G-vec00095-002-s477><adapt.anpassen><de> Die Basic-BHs werden neu erfunden, um ein Sortiment anbieten zu können, das sich besser an die verschiedensten Silhouetten, Materialien und Trends anpasst.
<G-vec00095-002-s477><adapt.anpassen><en> See now Basic bras have been reinvented to better adapt to different silhouettes, materials and trends.
<G-vec00095-002-s478><adapt.anpassen><de> In einer sich schnell verändernden Welt ist es von größter Wichtigkeit, dass der IWF weiterhin flexibel reagiert und sich den neuen Umständen schnell anpasst.
<G-vec00095-002-s478><adapt.anpassen><en> In a rapidly changing world, it is key that the Fund remains flexible in its response and adapt rapidly to the changing circumstances.
<G-vec00095-002-s479><adapt.anpassen><de> Sein Querprofil mit der Einzelarmabstützung der Abfederungselemente ist so konstruiert, dass es sich immer sehr genau der Fahrbahn anpasst.
<G-vec00095-002-s479><adapt.anpassen><en> Its cross-section with single-arm suspension system for the Number of elements is designed so as to adapt constantly and accurately to the road surface.
<G-vec00095-002-s480><adapt.anpassen><de> Daher auch nur eine Tanzfläche, deren Groove sich so organisch wie das Spiel von Sonne und Mond verändert, wobei sich die Musik der jeweiligen Tages- oder Nachtzeit anpasst.
<G-vec00095-002-s480><adapt.anpassen><en> For this very reason there is only one dance floor with its groove changing organically just like the circle of sun and moon - the music will adapt to the atmosphere of the day or the night.
<G-vec00095-002-s481><adapt.anpassen><de> Und dem noch mehr: Die Multifunktionalität dieses Produkts spiegelt sich auch in der Einbauweise wider, die sich verschiedenartigen Wannen anpasst: Zwischen zwei Wänden oder in der Ecke, es gibt immer eine Lösung, die für Ihre Entwurfs- und Platzbedürfnisse geeignet ist.
<G-vec00095-002-s481><adapt.anpassen><en> Not only: the multifunctional character of this product is also reflected in the installation procedures which adapt to baths of different types: between two walls or corner fitting, there is always a solution suited to your planning and space needs.
<G-vec00095-002-s482><adapt.anpassen><de> Padel Weltpresse .- Wenn Sie ein Padel-Spieler sind, der Erfahrung auf dem Platz hat und Macht liebt, zögern Sie nicht und entdecken Sie das Neue KOPF Alpha Touch 2021, eine Schaufel, die sich wie angegossen an Ihre Bedürfnisse anpasst.
<G-vec00095-002-s482><adapt.anpassen><en> Padel World Press .- If you are a padel player who has experience on the court and loves power, do not hesitate and discover the new HEAD Alpha Touch 2021, a shovel that will adapt like a glove to your needs.
<G-vec00095-002-s483><adapt.anpassen><de> flexCloud Frei skalierbare Cloud-Lösung, die sich jederzeit an die Anforderungen Ihres Unternehmen anpasst.
<G-vec00095-002-s483><adapt.anpassen><en> flexCloud Freely scalable cloud solution which can adapt to your company requirements at any time.
<G-vec00095-002-s484><adapt.anpassen><de> Der Penisring Counter Ring ist aus elastischem Material, das sich mühelos an jede Penisgrösse anpasst.
<G-vec00095-002-s484><adapt.anpassen><en> The Counter Ring ring is made of elastic material to easily adapt to any penis size.
<G-vec00095-002-s485><adapt.anpassen><de> Im zweiten Trimester, wenn sich der Körper gerade erst an das neue Gewicht anpasst und die Belastung der Beine zunimmt, trifft dies besonders zu.
<G-vec00095-002-s485><adapt.anpassen><en> In the 2nd trimester, when the body is just beginning to adapt to the new weight and the load on the legs increases, this is especially true.
<G-vec00095-002-s486><adapt.anpassen><de> Eine erwähnenswerte Eigenschaft ist, dass dieses Spiel sich scheinbar an die räumlichen Gegebenheiten des Spielers anpasst.
<G-vec00095-002-s486><adapt.anpassen><en> A notable feature is that the game seems to adapt to the spatial conditions of the player.
<G-vec00095-002-s487><adapt.anpassen><de> AUVESY ist ein solides, inhabergeführtes Unternehmen des deutschen Mittelstandes, das über das komplette branchenübergreifende Know-how verfügt und sich flexibel und schnell an die Bedürfnisse seiner Kunden anpasst.
<G-vec00095-002-s487><adapt.anpassen><en> AUVESY is a solid, owner-managed, traditional German SME with an expertise base spanning multiple industries and the capacity to quickly and flexibly adapt to customer requirements.
<G-vec00095-002-s488><adapt.anpassen><de> Außerdem wurde der Webauftritt im Responsive Design gestaltet, sodass sich die Darstellung der Seiten auch beim Zugriff über mobile Endgeräte automatisch dem jeweiligen Ausgabemedium optimal anpasst.
<G-vec00095-002-s488><adapt.anpassen><en> Also, the website was created using responsive design, which enables the page to adapt automatically to the screen size of the device (iPad, tablet, mobile phone) it is accessed from for an optimal display.
<G-vec00095-002-s489><adapt.anpassen><de> FORMOTION® ist ein freibewegliches und entkoppeltes Fersenelement, das sich deinem individuellen Laufstil anpasst.
<G-vec00095-002-s489><adapt.anpassen><en> FORMOTION® is a freely moving heel system that is de-coupled allowing to adapt to your individual running style.
<G-vec00095-002-s490><adapt.anpassen><de> Herausragende Projekte sind bis dato die Bounce Family (2012), eine Kollektion von Stahlcontainern, die mit Lycra bezogen sind, sich dehnen und ungewöhnlich viel Gewicht tragen können; und Dry (2012), ein skulpturales und stapelbares Trockengestell, das aus vier beweglichen, bunten und thermolackierten Stahlelementen besteht und sich so den heutigen Mehrzweck-Wohnräumen anpasst.
<G-vec00095-002-s490><adapt.anpassen><en> Standout projects to date include Bounce Family (2012), a collection of containers composed of Lycra-covered steel that stretch and hold much more than expected; and Dry (2012), a sculptural, stackable drying rack made of four movable, colorful, thermo-lacquered steel components designed to adapt to today’s multipurpose living spaces.
<G-vec00095-002-s491><adapt.anpassen><de> Schlanke Organisationsstrukturen und hochmoderne Konstruktionsarbeitsplätze bilden die Grundlage zur schnellen Entwicklung von Produkten, um sich den ständig ändernden Anforderungen der Industrie anzupassen.
<G-vec00095-002-s491><adapt.anpassen><en> A lean organisational structure and ultra-modern manufacturing are the basis for the fast development of products to adapt to the ever changing requirements of the industry.
<G-vec00095-002-s492><adapt.anpassen><de> Unternehmen, die versuchen, sich an diese neue Wirklichkeit anzupassen, stellen daher fest, dass jede Art von Kontaktaufnahme durch den Kunden, sei es sprachbasiert, über soziale Netzwerke, Text oder Chat, eine wichtige Absatzchance darstellen kann.
<G-vec00095-002-s492><adapt.anpassen><en> As a result, businesses that try to adapt to this new reality find that all types of contact initiated by customers—voice, social, text, chat—can be great revenue-producing opportunities.
<G-vec00095-002-s493><adapt.anpassen><de> Da wird es wahrscheinlich sogar für die kleinen Labels einfacher sein, sich anzupassen.
<G-vec00095-002-s493><adapt.anpassen><en> And it’s probably going to be easier for small labels to adapt.
<G-vec00095-002-s494><adapt.anpassen><de> Wasser hat seine eigenen Gesetzmäßigkeiten, und der Mensch muss lernen, sich diesen anzupassen.
<G-vec00095-002-s494><adapt.anpassen><en> Water has its own rules, and we as humans have to learn how to adapt to these rules.
<G-vec00095-002-s495><adapt.anpassen><de> Ich glaube an sichere, flexible und schnelle Lösungen, die es leicht machen, sich so schnell wie möglich an neue Herausforderungen anzupassen.
<G-vec00095-002-s495><adapt.anpassen><en> I believe in secure, flexible and fast solutions, that make it easy to adapt to new challenges as fast as needed.
<G-vec00095-002-s496><adapt.anpassen><de> Kathrin Wehrli, Remo Lütolf und Yogesh Maheshwari diskutieren, wie Vielfalt eine entscheidende Rolle für den Geschäftserfolg spielen kann und warum sie für die Fähigkeit eines Unternehmens, sich an ein sich schnell veränderndes Umfeld anzupassen, entscheidend ist.
<G-vec00095-002-s496><adapt.anpassen><en> Kathrin Wehrli, Remo Lütolf and Yogesh Maheshwari will discuss how diversity can play an integral role on business success and why it is critical to an organization’s ability to adapt to a fast-changing environment.
<G-vec00095-002-s497><adapt.anpassen><de> (3) Ein Mitgliedstaat, auf den Absatz 2 Anwendung findet, verfügt erforderlichenfalls über einen zusätzlichen Zeitraum von höchstens zwei Jahren, um die Wirtschaftsteilnehmer in diesem Mitgliedstaat in die Lage zu versetzen, sich unter Wahrung ihrer wirtschaftlichen Lebensfähigkeit allmählich an das Folgerechtssystem anzupassen, bevor dieses Recht zugunsten der nach dem Tod des Künstlers anspruchsberechtigten Rechtsnachfolger angewandt werden muss.
<G-vec00095-002-s497><adapt.anpassen><en> A Member State to which paragraph 2 applies may have up to two more years, if necessary to enable the economic operators in that Member State to adapt gradually to the resale right system while maintaining their economic viability, before it is required to apply the resale right for the benefit of those entitled under the artist after his/her death.
<G-vec00095-002-s498><adapt.anpassen><de> Allgemeine Powerbanks verfügen über einen relativ großen Ladebereich, um sich an die meisten Mobiltelefone anzupassen.
<G-vec00095-002-s498><adapt.anpassen><en> General power banks have a relatively large range of charging in order to adapt to most mobile phones.
<G-vec00095-002-s499><adapt.anpassen><de> Kollaborierende Roboter sind darauf ausgelegt, wie ein menschlicher Mitarbeiter zu lernen und sich anzupassen, was eine kontrollierte, sichere Bewegung erfordert.
<G-vec00095-002-s499><adapt.anpassen><en> Collaborative robots are designed to learn and adapt as if they were a human coworker, which requires controlled, safe motion.
<G-vec00095-002-s500><adapt.anpassen><de> Wenn der Mensch neu inkarniert, nimmt er bestimmte Anlagen mit, im Prinzip solche, um sich total dem Irdischen anzupassen, d.h. er sieht von hier aus eine Konstellation und paßt sich an.
<G-vec00095-002-s500><adapt.anpassen><en> If a human incarnates he takes certain abilities into his life, principally to adapt to earthly conditions, that means he automatically accepts the conditions and adjusts to them.
<G-vec00095-002-s501><adapt.anpassen><de> Das Skigebiet und die Zuständigen von TechnoAlpin haben sich über mehrere Monate getroffen um das Projekt zu planen und eine fortschrittliche Beschneiungsanlage an die Gegebenheiten des Ortes anzupassen.
<G-vec00095-002-s501><adapt.anpassen><en> The ski resort and the TechnoAlpin staff in charge of the project met over several months in order to plan the design and to adapt an advanced snowmaking system to the conditions of the location.
<G-vec00095-002-s502><adapt.anpassen><de> Beide waren gezwungen, sich dem Rhythmus der Worte des anderen anzupassen.
<G-vec00095-002-s502><adapt.anpassen><en> Both were forced to adapt to the other’s rhythm of words.
<G-vec00095-002-s503><adapt.anpassen><de> Das Schienbeinpolster ist verstellbar, um sich Nutzern unterschiedlicher Körpergrößen anzupassen.
<G-vec00095-002-s503><adapt.anpassen><en> The tibia roller pad can be adjusted to adapt to different user heights.
<G-vec00095-002-s504><adapt.anpassen><de> Wenn der Körper beginnt, sich anzupassen, benötigt er Körperfett, um Schritt zu halten mit der Energie-Anforderungen, die mit einem Trainingsprogramm kommen.
<G-vec00095-002-s504><adapt.anpassen><en> Once the body begins to adapt, it consumes body fat in order to keep pace with energy demands that come with the curriculum.
<G-vec00095-002-s505><adapt.anpassen><de> Angesichts des globalen Trends zu trägerbandlosen Etiketten – drucksensitive Etiketten ohne Trägerpapier – beweist die Branche insgesamt ihre Bereitschaft, sich unabhängig vom Fertigungsland an das kulturelle und politische Streben nach Ressourcenschonung anzupassen.
<G-vec00095-002-s505><adapt.anpassen><en> With a global move towards linerless labels – pressure-sensitive labels without backing paper – the industry as a whole is demonstrating a willingness to adapt to the cultural and political drive towards environmentalism, regardless of the country of production.
<G-vec00095-002-s506><adapt.anpassen><de> Praktisch sieht die Alternative noch deutlicher aus: Entweder wird die Sozialdemokratie, wie ehemalige junge Draufgänger und heutige alte Betschwestern in unseren Reihen bereits reumütig ankündigen, vor der vaterländischen Bourgeoisie pater, peccavi sagen und auch im Frieden ihre ganze Taktik und ihre Grundsätze gründlich revidieren müssen, um sich ihrer heutigen sozialimperialistischen Position anzupassen, oder sie wird vor dem internationalen Proletariat pater, peccavi sagen und ihr Verhalten im Kriege ihren Prinzipien im Frieden anpassen müssen.
<G-vec00095-002-s506><adapt.anpassen><en> In practice the alternative is even clearer: either Social Democracy must say pater peccavi to the patriotic bourgeoisie (as former young daredevils and present day old devotees in our ranks are already proclaiming contritely) and thus have to revise fundamentally all its tactics and principles, in peace-time as well as in war-time, in order to adapt to its present social-imperialist position; or the party will have to say pater peccavi to the international proletariat and adapt its behaviour during the war to its principles in peace-time.
<G-vec00095-002-s507><adapt.anpassen><de> Die Ladestecker der udoq Kabel können in der Höhe verstellt werden, um sich an die meisten Schutzhüllen anzupassen.
<G-vec00095-002-s507><adapt.anpassen><en> The connectors of the udoq cables can be adjusted in height to adapt to most protective cases.
<G-vec00095-002-s508><adapt.anpassen><de> Um die Öffnungsraten also weiterhin zu halten oder zu steigern, ist es für E-Mail-Marketer unumgänglich, sich an den mobilen Trend anzupassen.
<G-vec00095-002-s508><adapt.anpassen><en> In order to maintain or raise the opening rates, it is essential for e-Mail marketers to adapt to the mobile trend.
<G-vec00095-002-s509><adapt.anpassen><de> Peru beheimatet Tausende von Arten, die noch immer Überraschungen für die Wissenschaft bereithalten, vor allem die örtlich begrenzt auftretenden Spezies, deren Schönheit, charakteristische Merkmale und Fähigkeit, sich schwierigen klimatischen Bedingungen anzupassen, sie zu einer echten Attraktion machen.
<G-vec00095-002-s509><adapt.anpassen><en> Peru is home to thousands of species that continue to amaze the scientific world, especially the endemic species, whose beauty, peculiar features and ability to adapt to challenging climates make them a special attraction.
<G-vec00095-002-s548><adapt.anpassen><de> Unternehmen können so ihre Prozesse dem permanent steigenden Wettbewerbsdruck anpassen.
<G-vec00095-002-s548><adapt.anpassen><en> It allows companies to adapt their presence to constantly increasing competition.
<G-vec00095-002-s549><adapt.anpassen><de> So können wir unsere Leistungen innerhalb kürzester Zeit den jeweiligen Anforderungen anpassen.
<G-vec00095-002-s549><adapt.anpassen><en> We are able to adapt our services to special requirements within a short time frame.
<G-vec00095-002-s550><adapt.anpassen><de> Als Landwirte können wir Teil der Lösung sein und unsere Zucht- und Anbaumethoden so anpassen und weiterentwickeln, dass sie widerstandsfähiger gegenüber diesen sich verändernden Umgebungsbedingungen sind.
<G-vec00095-002-s550><adapt.anpassen><en> As farmers, we can be part of the solution and adapt and develop our farming systems to be more resilient to these changing environmental conditions.
<G-vec00095-002-s551><adapt.anpassen><de> Leider war ich nie so flexibel wie Du, weshalb ich mich auch nie so anpassen konnte wie Du das konntest.
<G-vec00095-002-s551><adapt.anpassen><en> Unfortunately, I was never as flexible as you, which is why I could never adapt as you could.
<G-vec00095-002-s552><adapt.anpassen><de> So können Ärzte die Therapie frühzeitig anpassen und eine Verschlechterung von Grunderkrankungen sowie Schlaganfälle oder Hospitalisierungen verhindern.
<G-vec00095-002-s552><adapt.anpassen><en> Physicians can adapt therapies early and prevent the worsening of underlying conditions, stroke or hospitalizations. For the
<G-vec00095-002-s553><adapt.anpassen><de> Indem wir rasch auf Meldungen reagiert haben, konnten wir uns genau zu dem Zeitpunkt um unsere Patienten kümmern, an dem eine Behandlung medizinisch erforderlich war, und so ihre Therapie entsprechend anpassen“, erläuterte Professor Dr. Peter Sogaard, Universitätsklink Aalborg, Dänemark.
<G-vec00095-002-s553><adapt.anpassen><en> By reacting quickly to notifications, we were able to follow up with patients exactly when they needed medical attention, and adapt their therapy accordingly,” said Dr. Peter Sogaard, Aalborg University Hospital, Denmark.
<G-vec00095-002-s554><adapt.anpassen><de> Der Bediener hat so dauerhaften Zugang zu allen Einstellungen und kann diese je nach Anwendung anpassen ohne wieder zurück zur Maschine gehen zu müssen.
<G-vec00095-002-s554><adapt.anpassen><en> Allows the operator permanent access to all settings, possibility to adapt settings according to the applications without having to go back to the machine.
<G-vec00095-002-s555><adapt.anpassen><de> Fertigen Sie in regelmäßigen Abständen eher geringe Stückzahlen, so können Sie die Schablone an diese Stückzahlen anpassen.
<G-vec00095-002-s555><adapt.anpassen><en> If you produce small quantities at regular intervals, you can adapt the template to these quantities.
<G-vec00095-002-s556><adapt.anpassen><de> In Anbetracht der Tatsache, dass Terroristen ihr Verhalten so anpassen, dass sie nicht entdeckt werden können, dürften die derzeit von Sicherheitsdiensten verwendeten Erkennungsmethoden weitaus weniger genau sein.
<G-vec00095-002-s556><adapt.anpassen><en> Considering that terrorists adapt their behaviour to avoid detection, detection methods currently used by security services are likely to be much less accurate.
<G-vec00095-002-s557><adapt.anpassen><de> Mit Hilfe der Backup-Zeitpläne können Sie so individuell das Backup der Datenbanken an Ihre Bedürfnisse anpassen.
<G-vec00095-002-s557><adapt.anpassen><en> By means of the backup time schedules you can individually adapt the backup of the databases to your requirements.
<G-vec00095-002-s572><adapt.anpassen><de> Wir haben und werden immer in diesem Umfeld leben, entsprechend handeln und uns anpassen.
<G-vec00095-002-s572><adapt.anpassen><en> We have and will always live in this environment and act and adapt accordingly.
<G-vec00095-002-s573><adapt.anpassen><de> Die Natur ist nichts, was wir kontrollieren können, also müssen wir uns der Natur anpassen.
<G-vec00095-002-s573><adapt.anpassen><en> Nature is not something that we can control and therefore we need to adapt to the weather.
<G-vec00095-002-s574><adapt.anpassen><de> Da sich unser Geschäft ständig ändert, müssen wir uns an die neuen Umstände anpassen, neue Ziele setzen und intelligentere Lösungen implementieren.
<G-vec00095-002-s574><adapt.anpassen><en> Because our business is constantly changing, we must adapt to the changing circumstances and set new goals and implement smarter solutions.
<G-vec00095-002-s575><adapt.anpassen><de> Aber wir mussten uns genauso an die Hunde anpassen.
<G-vec00095-002-s575><adapt.anpassen><en> But we had to adapt to the dogs as well.
<G-vec00095-002-s576><adapt.anpassen><de> Leider können wir nicht immer wählen, also müssen wir uns anpassen, deshalb hier ein paar Tipps für effektives Arbeiten im Freiraum.
<G-vec00095-002-s576><adapt.anpassen><en> Unfortunately, we can not always choose, so we must adapt, so here are some tips for working effectively in open space.
<G-vec00095-002-s577><adapt.anpassen><de> Mit unserer umfassenden Erfahrung können wir uns genau Ihren Anforderungen anpassen.
<G-vec00095-002-s577><adapt.anpassen><en> Our extensive experience allows as to adapt precisely to your needs.
<G-vec00095-002-s578><adapt.anpassen><de> Man erwartet von uns, dass wir uns allen Trends anpassen und den Ansprüchen und Bedürfnissen der Konsumenten immer einen Schritt voraus sind.
<G-vec00095-002-s578><adapt.anpassen><en> We are expected to adapt to the trends and try to stay one step ahead of our customer, their needs and perceptions.
<G-vec00095-002-s579><adapt.anpassen><de> Während wir als Gruppe lernen, uns anpassen und wachsen, möchten wir euer Feedback hören.
<G-vec00095-002-s579><adapt.anpassen><en> As we learn, adapt, and grow as a group, we want to hear from you.
<G-vec00095-002-s580><adapt.anpassen><de> Wir sind flexibel und können uns dem Kunde und seinem spezifischen Arbeitssystem anpassen.
<G-vec00095-002-s580><adapt.anpassen><en> „NYSA” can adapt to and fully accept each customer's unique way of doing business.
<G-vec00095-002-s581><adapt.anpassen><de> Wir sind somit nicht nur in der Lage Ihre Zeit und Ihre Kosten zu sparen, sondern können uns auch auf die veränderlichen Bedürfnisse unserer Kunden anpassen.
<G-vec00095-002-s581><adapt.anpassen><en> So we’re not only able to lower costs and save time, but as well to adapt to the variable needs of our purchasers.
<G-vec00095-002-s582><adapt.anpassen><de> Die Wirtschaft hat ihre eigenen Zyklen und wir müssen uns anpassen und auf ihre Reize reagieren.
<G-vec00095-002-s582><adapt.anpassen><en> The economy has its own cycles and we need to adapt and respond to their stimuli.
<G-vec00095-002-s583><adapt.anpassen><de> Als absolute Technikenthusiasten arbeiten wir exakt und pflichtbewusst, folgen den Prinzipien der agilen Softwareentwicklung und können uns spontan an Ihre Bedürfnisse anpassen.
<G-vec00095-002-s583><adapt.anpassen><en> As full-fledged technology enthusiasts, we work precisely and dutifully, following the principles of agile software development and can adapt spontaneously to your needs.
<G-vec00095-002-s584><adapt.anpassen><de> Wir müssen uns anpassen.
<G-vec00095-002-s584><adapt.anpassen><en> We need to adapt.
<G-vec00095-002-s585><adapt.anpassen><de> Auch wenn wir längst volljährig, „erwachsen“, sind, heißt das doch nicht, dass uns zwanghafte Gebote und Verbote besser motivieren (auch wenn wir vielleicht inzwischen gelernt haben, uns dem vermeintlichen Zwang anzupassen).
<G-vec00095-002-s585><adapt.anpassen><en> Even if we have grown up, I do not think it means we can be motivated with compulsive orders or prohibitions (even if we might have learned to adapt to those).
<G-vec00095-002-s586><adapt.anpassen><de> Was wir alle über alle Generationen hinweg gemeinsam haben, ist das Geschenk, uns selbst zu lernen, zu verändern, uns anzupassen und zu entwickeln.
<G-vec00095-002-s586><adapt.anpassen><en> What we all have in-common across all generations is the gift to learn,change, adapt and develop ourselves.
<G-vec00095-002-s587><adapt.anpassen><de> Cookies erlauben es uns beispielsweise, eine Webseite Ihren Interessen anzupassen oder Ihr Kennwort zu speichern, damit Sie es nicht jedes Mal neu eingeben müssen.
<G-vec00095-002-s587><adapt.anpassen><en> Cookies enable a website, for instance, to adapt to your specific interests or to save your password so that it is not necessary to enter it again every time.
<G-vec00095-002-s588><adapt.anpassen><de> Wir wissen, dass es sich um eine besondere Situation handelt, in der wir gezwungen sind, uns schnell an neue Umstände anzupassen.
<G-vec00095-002-s588><adapt.anpassen><en> We know that this is a special situation, in which we are forced to adapt rapidly to new circumstances.
<G-vec00095-002-s589><adapt.anpassen><de> Unsere Erfahrung im Umgang mit den Menschen und die Kenntnis der Geschichte der Länder, mit denen wir Handel betreiben, verleiht uns die nötige Expertise und die Flexibilität, uns dem stetigen politischen, ökonomischen und sozialen Wandel anzupassen.
<G-vec00095-002-s589><adapt.anpassen><en> It gives us a better understanding of the people and the history of the countries we trade with. Experience gives us the ability to adapt to continuously changing political, economic and social situations.
<G-vec00095-002-s590><adapt.anpassen><de> Wir setzen auf eine langfristige Zusammenarbeit mit unseren Mandanten, um uns mit ihren Anliegen bestens vertraut zu machen und uns ihren Bedürfnissen anzupassen.
<G-vec00095-002-s590><adapt.anpassen><en> Our intention is to build long term relationships with clients, understand closely their issues and adapt us to their needs.
<G-vec00095-002-s591><adapt.anpassen><de> Schon seit unseren frühen Anfängen war es immer unser Ziel, uns nach Ihren Wünschen zu richten und uns Ihren Erwartungen anzupassen.
<G-vec00095-002-s591><adapt.anpassen><en> Since our earliest days we have always been eager to respond to your needs and adapt to your expectations.
<G-vec00095-002-s592><adapt.anpassen><de> Um uns Ihren Bedürfnissen anzupassen, war es leider notwendig den Anrufbeantworter in Quarantäne zu schicken.
<G-vec00095-002-s592><adapt.anpassen><en> In order to adapt to your needs, it was unfortunately necessary to send the telephone answering machine into quarantine.
<G-vec00095-002-s593><adapt.anpassen><de> Die Auswertungen dienen uns viel mehr dazu, die Lesegewohnheiten unserer Nutzer zu erkennen und unsere Inhalte auf sie anzupassen oder unterschiedliche Inhalte entsprechend den Interessen unserer Nutzer zu versenden.
<G-vec00095-002-s593><adapt.anpassen><en> The evaluations serve to recognise the reading habits of our users and to adapt the contents of our newsletters to them or to send different content according to the interests of our users.
<G-vec00095-002-s594><adapt.anpassen><de> Wann immer möglich, werden wir versuchen unser Bestes, um uns Ihre Wünsche anzupassen.
<G-vec00095-002-s594><adapt.anpassen><en> Wherever possible, we will try to better adapt to your demands.
<G-vec00095-002-s595><adapt.anpassen><de> „Wir haben von den reichen Ländern kein Geld gesehen, um uns zu helfen, uns anzupassen.
<G-vec00095-002-s595><adapt.anpassen><en> "We have not seen money from rich countries to help us adapt.
<G-vec00095-002-s596><adapt.anpassen><de> Wir müssen lernen, uns anzupassen und in Bewegung zu setzen, um an diesen Käse zu gelangen.
<G-vec00095-002-s596><adapt.anpassen><en> We have to learn to adapt, and move to get to that cheese.
<G-vec00095-002-s597><adapt.anpassen><de> Als kleines, aber überaus flexibles Unternehmen sind wir in der Lage, uns den Wünschen unserer Kunden anzupassen und individuelle Sonderlösungen zu entwickeln.
<G-vec00095-002-s597><adapt.anpassen><en> As a small but thoroughly flexible company, we are in a position to adapt to the wishes of our customers and to develop individual special solutions.
<G-vec00095-002-s598><adapt.anpassen><de> Mit solchem erhoehten Verstaendnis, wird es auch leichter mit den kulturellen Unterschieden umzugehen, uns anzupassen und so erfolgreich die sich daraus ergebende vergrößerte Sichtweise zu nutzen.
<G-vec00095-002-s598><adapt.anpassen><en> It will be easier to accept cultural differences, adapt (to) them, and benefit from a much broader perspective.
<G-vec00095-002-s599><adapt.anpassen><de> Solche über die in den Newslettern enthaltenen Zählpixel erhobenen personenbezogenen Daten, werden von uns gespeichert und ausgewertet, um den Newsletterversand zu optimieren und den Inhalt zukünftiger Newsletter noch besser Ihren Interessen anzupassen.
<G-vec00095-002-s599><adapt.anpassen><en> Such personal data collected in the tracking pixels contained in the newsletters are stored and analyzed by the controller in order to optimize the shipping of the newsletter, as well as to adapt the content of future newsletters even better to the interests of the data subject.
<G-vec00095-002-s600><adapt.anpassen><de> Wir lieben es, uns dem Gegner anzupassen, da es so es einfacher ist zu verstehen, wie sie spielen und welcher Gegenangriff funktioniert.
<G-vec00095-002-s600><adapt.anpassen><en> We love to adapt to the command of the enemy. Because it’s easier to understand how they play and which counter-attack will work.
<G-vec00095-002-s072><adjust.anpassen><de> Sie können ihr Objekt ganz einfach an die gesamte Größe des Etiketts anpassen.
<G-vec00095-002-s072><adjust.anpassen><en> It is easy to adjust an object to the size of the label.
<G-vec00095-002-s073><adjust.anpassen><de> Hierbei können Sie zwischen unterschiedlichen Papierarten wählen und so Ihre Postkarten optimal an den gewünschten Verwendungszweck anpassen.
<G-vec00095-002-s073><adjust.anpassen><en> You can choose between different paper types here, and thus optimally adjust your postcards to suit your intended purpose.
<G-vec00095-002-s074><adjust.anpassen><de> Wie Sie die Höhe des Kinderschreibtische optimal an die Körpergröße Ihres Kindes anpassen, erfahren Sie in unserem Produktberater.
<G-vec00095-002-s074><adjust.anpassen><en> Please visit our product advisor to find out more about how to ergonomically adjust the height of the children’s desk.
<G-vec00095-002-s075><adjust.anpassen><de> Die Aussichten für die Zukunft sind damit ebenfalls hervorragend – wenn sich die Unternehmen an die sich wandelnden Rahmenbedingungen anpassen.
<G-vec00095-002-s075><adjust.anpassen><en> The outlook for the future is also outstanding – always assuming companies can adjust themselves to changing conditions affecting the industry.
<G-vec00095-002-s076><adjust.anpassen><de> Die Rheinmetall Aktiengesellschaft übernimmt keine Haftung oder Gewähr für solche zukunftsgerichteten Aussagen und wird sie nicht an künftige Ergebnisse und Entwicklungen anpassen.
<G-vec00095-002-s076><adjust.anpassen><en> Rheinmetall Aktiengesellschaft does not assume any liability or guarantee for such forward-looking statements and will not adjust them to any future results and developments.
<G-vec00095-002-s077><adjust.anpassen><de> Ein garantierter Weg, sich keine Sorgen über Hautreizungen zu machen, ist die Weigerung, sich zu rasieren, aber in den meisten Fällen können sich Frauen einfach nicht an die Experimente mit Wachs oder Zucker anpassen.
<G-vec00095-002-s077><adjust.anpassen><en> A guaranteed way not to worry about skin irritation is the refusal to shave, but in most cases, women just can't adjust to the experiments with wax or sugar-based.
<G-vec00095-002-s078><adjust.anpassen><de> Sie können zwischen unterschiedlichen Papierarten wählen und so Ihre Postkarten optimal an den gewünschten Verwendungszweck anpassen.
<G-vec00095-002-s078><adjust.anpassen><en> You can choose between different paper types here, and thus optimally adjust your postcards to suit your intended purpose.
<G-vec00095-002-s079><adjust.anpassen><de> Dadurch kann sich der Rasierer automatisch an jede Kopf-, Gesichts- oder Beinlinie anpassen, um eine komfortable und sanfte Rasur zu erzielen.
<G-vec00095-002-s079><adjust.anpassen><en> This allows the shaver to automatically adjust to every curve of one’s scalp, face or leg for a comfortable and smooth shave.
<G-vec00095-002-s080><adjust.anpassen><de> Darüber hinaus geben 61 % an, dass sie wegen stärkerer Handelskonflikte und Strafzölle ihre Supply-Chain anpassen oder das in naher Zukunft tun werden.
<G-vec00095-002-s080><adjust.anpassen><en> In addition, 61% say they will adjust their supply chain or do so in the near future due to stronger trade conflicts and punitive tariffs.
<G-vec00095-002-s081><adjust.anpassen><de> Sie können den Facet ganz an Ihre Bedürfnisse anpassen.
<G-vec00095-002-s081><adjust.anpassen><en> You can adjust the Facet to suit your exact needs.
<G-vec00095-002-s082><adjust.anpassen><de> Mittels verstellbarer Rückenlänge (Bergans QuickAdjust II) und Stabilisierungsriemen lässt sich der Rucksack im Handumdrehen an die jeweiligen Bedürfnisse anpassen.
<G-vec00095-002-s082><adjust.anpassen><en> With adjustable torso length (Bergans QuickAdjust II) and top tensioners, you can quickly adjust the backpack to the day’s requirements.
<G-vec00095-002-s083><adjust.anpassen><de> An dieser Stelle können Sie auch der Verwendung von Cookies widersprechen und die Browsereinstellungen entsprechend anpassen.
<G-vec00095-002-s083><adjust.anpassen><en> You can also refuse the use of cookies and adjust your browser configuration. forward bookmark list []
<G-vec00095-002-s084><adjust.anpassen><de> Jetzt können Sie die Tendenzen mit paar Mausklicken prüfen, den Betrieb Ihres Unternehmens an diese anpassen und jede Ressource optimieren.
<G-vec00095-002-s084><adjust.anpassen><en> Now, however, you can check trends with a few clicks and adjust the operation of your business accordingly, thereby optimizing all resources.
<G-vec00095-002-s085><adjust.anpassen><de> Mit der Farbvielfalt von WAREMA können Sie Ihre Außenjalousien individuell an Ihre Fassade anpassen.
<G-vec00095-002-s085><adjust.anpassen><en> With the colour variety of WAREMA you can individually adjust your external venetian blinds to your facade.
<G-vec00095-002-s086><adjust.anpassen><de> Durch die technisch anspruchsvollen Strecken mussten die Teilnehmer hart arbeiten und ihr Tempo an die schwierigen Bedingungen anpassen.
<G-vec00095-002-s086><adjust.anpassen><en> "The technically demanding routes meant that riders had to work hard and adjust their pace were a constant companion.
<G-vec00095-002-s087><adjust.anpassen><de> High-sich Obendreher von Liebherr an jede spezifische Anforderung anpassen.
<G-vec00095-002-s087><adjust.anpassen><en> Top-slewing cranes from Liebherr can adjust to any specific requirement.
<G-vec00095-002-s088><adjust.anpassen><de> Der Gillette Sensor Excel Rasierer für Männer verfügt über selbst justierende Doppelklingen, die sich automatisch an jede Kurve Ihres Gesichts anpassen.
<G-vec00095-002-s088><adjust.anpassen><en> The Gillette Sensor Excel razor for men features self-adjusting twin blades that automatically adjust to every curve of your face.
<G-vec00095-002-s089><adjust.anpassen><de> Mit dem optional erhältlichen Virtual Cockpit kann der Fahrer die Anzeigen ganz an seine persönlichen Vorlieben anpassen.
<G-vec00095-002-s089><adjust.anpassen><en> When the car is equipped with the optional virtual cockpit, the driver can adjust how the instruments are displayed to suit their preferences.
<G-vec00095-002-s090><adjust.anpassen><de> Nicht nur eine Frage der Optik: Mit BMW M Performance Parts können Sie das Fahrwerk Ihres BMW optimal an Ihre Wünsche und Ihr Fahrverhalten anpassen.
<G-vec00095-002-s090><adjust.anpassen><en> Not just a question of looks: BMW M Performance Parts let you adjust the chassis of your BMW to suit your needs and your driving style perfectly.
<G-vec00095-002-s091><adjust.anpassen><de> Für eine volle Bildfüllung ist es erforderlich, jedes mal den Zoom und Fokus an das Format anzupassen oder mit teuren Anamorphoten Objektiven zu arbeiten.
<G-vec00095-002-s091><adjust.anpassen><en> To fully utilize the screen area with different aspect contents, it required the user to use an additional anamorphic lens or manually adjust the zoom/focus every time.
<G-vec00095-002-s092><adjust.anpassen><de> Tchibo hat daraufhin beschlossen, bei der Beschaffung der Versandverpackungen die Größen ab Mitte 2015 schrittweise an die Ergebnisse der Studie anzupassen.
<G-vec00095-002-s092><adjust.anpassen><en> Tchibo therefore decided to gradually adjust the sizes when procuring its shipping packages, from mid-2015, to reflect the results of the study.
<G-vec00095-002-s093><adjust.anpassen><de> Smart Unsere Roboter sind mit minimalen Anweisungen eines Mitarbeiters in der Lage, sich schnell an eine neue Bestellung, eine Veränderung der Umgebung oder Produktvariationen anzupassen.
<G-vec00095-002-s093><adjust.anpassen><en> Smart With minimal instructions of an employee, our robots can easily adjust themselves to a new assignment, changes in the environment or product variations.
<G-vec00095-002-s094><adjust.anpassen><de> Ursprünglich existierte der Haldenberg nicht, entstand infolge des Uranabbaus und wurde nun saniert, um die Auswirkungen auf Bevölkerung und Umwelt nachhaltig an den Naturraum anzupassen.
<G-vec00095-002-s094><adjust.anpassen><en> Originally, the mound did not exist, was created as a result of uranium mining and has now been redeveloped to sustainably adjust impacts on the population and the environment to the natural environment.
<G-vec00095-002-s095><adjust.anpassen><de> Um den Verlauf der UTC-Zeit an die tatsächliche Erddrehung anzupassen, werden von Zeit zu Zeit sogenannte Schaltsekunden in die UTC-Zeitskala eingefügt.
<G-vec00095-002-s095><adjust.anpassen><en> This is the reason why so called leap seconds are inserted into the UTC time scale, they adjust process of the UTC time to the real earth rotation.
<G-vec00095-002-s096><adjust.anpassen><de> Kanban gibt uns die Flexibilität, Entwicklungsprozesse individuell an Kapazitäten und Abläufe in unserem Unternehmen anzupassen.
<G-vec00095-002-s096><adjust.anpassen><en> Kanban gives us the flexibility to individually adjust development processes to capacities and procedures in our company.
<G-vec00095-002-s097><adjust.anpassen><de> Die Änderung der Teilobergrenze der Rubrik 2 zu jeweiligen Preisen erfordert die Umwandlung in Preise von 2011, um die MFR-Tabelle technisch an die Preise von 2011 anzupassen.
<G-vec00095-002-s097><adjust.anpassen><en> The modification of the H2 sub-ceiling in current prices needs to be translated into 2011 prices in order to technically adjust the MFF table in 2011 prices.
<G-vec00095-002-s098><adjust.anpassen><de> Kontakt Lösungen Die ROVEMA Retrofit GmbH bietet ihren Kunden spezifische und individuelle Lösungen für Umbau, Erneuerung oder Ergänzung von gebrauchten Verpackungsmaschinen, um diese effektiv und erfolgreich an neue Verpackungsanforderungen und technische Entwicklungen anzupassen.
<G-vec00095-002-s098><adjust.anpassen><en> contact solutions ROVEMA Retrofit GmbH offers its customers specific and individual solutions for converting, renewing and complementing second-hand packaging machines in order to effectively and successfully adjust them to new packaging requirements and technical developments.
<G-vec00095-002-s099><adjust.anpassen><de> Wir behalten uns vor, die Datenschutzerklärung zu gegebener Zeit zu aktualisieren, um den Datenschutz zu verbessern und/oder an geänderte Behördenpraxis oder Rechtsprechung anzupassen.
<G-vec00095-002-s099><adjust.anpassen><en> We reserve the right to update our privacy policy in due course to improve privacy and / or to adjust it according to changes in regulatory practice or jurisdiction.
<G-vec00095-002-s100><adjust.anpassen><de> Die SKW Stahl-Metallurgie Holding AG beabsichtigt nicht und übernimmt keinerlei Verpflichtung, derartige zukunftsgerichtete Aussagen zu aktualisieren und an zukünftige Ereignisse oder Entwicklungen anzupassen.
<G-vec00095-002-s100><adjust.anpassen><en> SKW Stahl-Metallurgie Holding AG does not intend and assumes no liability to update such forward-looking statements and to adjust them to future events and developments.
<G-vec00095-002-s101><adjust.anpassen><de> Der Lieferant ist in diesem Fall verpflichtet, die vertraglichen Regelungen im Rahmen des Zumutbaren an die veränderten Verhältnisse anzupassen.
<G-vec00095-002-s101><adjust.anpassen><en> Should this be the case, the supplier shall be required to reasonably adjust the contractual regulations in line with the changing conditions.
<G-vec00095-002-s102><adjust.anpassen><de> Das Wii U-Projekt nahm seinen Ursprung, als wir begannen, darüber nachzudenken, unsere Technologie an den neuen HD-Standard der heimischen Fernsehgeräte anzupassen.
<G-vec00095-002-s102><adjust.anpassen><en> The Wii U project kicked off when we thought that we should adjust to the new HD standard for home televisions.
<G-vec00095-002-s103><adjust.anpassen><de> IXOLIT ist berechtigt, die Vergütung entsprechend der Preissteigerung des jeweiligen Verbraucherpreisindex (VPI) oder eines an seine Stelle tretenden Index einmal jährlich anzupassen.
<G-vec00095-002-s103><adjust.anpassen><en> IXOLIT shall be entitled to adjust the remuneration once a year according to the price in-crease of the current consumer price index (CPI) or an index replacing it.
<G-vec00095-002-s104><adjust.anpassen><de> Die Analyse des Nutzerverhaltens mittels Tracking hilft uns, die Effektivität unserer Services zu überprüfen, sie zu optimieren und an die Bedürfnisse der Nutzer anzupassen sowie Fehler zu beheben.
<G-vec00095-002-s104><adjust.anpassen><en> Analysing user behaviour through tracking helps us to review the effectiveness of our Services, to optimise them and adjust them to meet the needs of the user, as well as to resolve errors.
<G-vec00095-002-s105><adjust.anpassen><de> Um das Angebot der GGG und die Ausrichtung der Methodenwoche noch besser an die Wünsche und Bedürfnisse der Promovierenden anzupassen, wird die Methodenwoche regelmäßig evaluiert.
<G-vec00095-002-s105><adjust.anpassen><en> To continue improving our services and adjust them to the necessities of PhD students, the Methodenwoche is regularly evaluated.
<G-vec00095-002-s106><adjust.anpassen><de> RLT-Anlagen sollten mit einer variablen Volumenstromregelung und drehzahlgeregelten Ventilatoren arbeiten, um sich effizient an ein geändertes Nutzungsverhalten anzupassen.
<G-vec00095-002-s106><adjust.anpassen><en> Ideally, air conditioning systems should include variable volume flow control and speed-controlled fans such that they can adjust efficiently to changes of usage.
<G-vec00095-002-s107><adjust.anpassen><de> Vollautomatisch wird das Finishing® an die Bedürfnisse der jeweiligen Speisen angepasst, die Qualität bleibt aber jederzeit auf höchstem Niveau.
<G-vec00095-002-s107><adjust.anpassen><en> Fully automatically, Finishing® will adjust to the requirements of the relevant food, but the quality remains at the highest level at all times.
<G-vec00095-002-s108><adjust.anpassen><de> In diesem Fall muss die Dosierung Ihrer anderen Antiparkinson-Arzneimittel, insbesondere von Levodopa, angepasst werden, um eine ausreichende Kontrolle Ihrer Parkinson-Beschwerden zu erzielen.
<G-vec00095-002-s108><adjust.anpassen><en> In such a case your doctor may need to adjust your other antiparkinson medicines, especially levodopa, to give sufficient control of your symptoms.
<G-vec00095-002-s109><adjust.anpassen><de> Mit der Funktion „Metadaten ändern“ können einzelne Informationen bei mehreren Items gleichzeitig angepasst werden, ohne die Detailansicht der Fragen zu öffnen.
<G-vec00095-002-s109><adjust.anpassen><en> The "Change metadata" function allows you to adjust single information statements simultaneously for multiple items, without entering the detailed view. Changes cannot be canceled.
<G-vec00095-002-s110><adjust.anpassen><de> Mit den unteren Aktivpunkten wird die Weichheit (Randtransparenz) angepasst, die der Luma-Kanal zur Stanzmaske beiträgt.
<G-vec00095-002-s110><adjust.anpassen><en> The lower handles adjust the softness (edge transparency) of the luma channel’s contribution to the key.
<G-vec00095-002-s111><adjust.anpassen><de> Unserem und Ihrem Interesse an Datensicherheit entsprechend werden diese Sicherungsmaßnahmen laufend überprüft und angepasst, um einen höheren Schutzstandard zu erreichen.
<G-vec00095-002-s111><adjust.anpassen><en> According to your and our interest in data security we continuously check and adjust our security measures in order to achieve a higher protection standard.
<G-vec00095-002-s112><adjust.anpassen><de> Perfekte Länge, nicht zu weit, nicht zu eng, und in der Taille kann die Weite sogar angepasst werden.
<G-vec00095-002-s112><adjust.anpassen><en> Perfect length, not too wide, not too tight, and you can adjust it in the waist.
<G-vec00095-002-s113><adjust.anpassen><de> Durch die große Bandbreite an erhältlichen Schichtdicken (50 bis zu 400 können die Eigenschaften perfekt an die Umgebungsbedingungen angepasst werden.
<G-vec00095-002-s113><adjust.anpassen><en> Due to the big range of available thicknesses (50 up to 400 you are able to adjust the performance of the screen perfectly to your environment.
<G-vec00095-002-s114><adjust.anpassen><de> Wenn das Formular zum Verfassen des Termins bereits eine Endzeit aufweist, werden durch das spätere Festlegen der Endzeit die Dauer und die Endzeit angepasst.
<G-vec00095-002-s114><adjust.anpassen><en> If the appointment compose form already has an existing end time, setting the end time subsequently will adjust both the duration and end time.
<G-vec00095-002-s115><adjust.anpassen><de> Anschließend werden von einem sogenannten Strukturgenerator Kugeln gemäß einer vorgegebenen Größenverteilung in einer virtuellen Box platziert und deren Größe angepasst, um eine beliebige vordefinierte Porosität einzuhalten.
<G-vec00095-002-s115><adjust.anpassen><en> Subsequently, the so-called “structure generator” places spheres according to the given size distribution in a virtual box and adjust the size to satisfy an arbirtraily defined porosity.
<G-vec00095-002-s116><adjust.anpassen><de> Wie zahlreiche Referenzen zeigen, gewährt der Biturox®-Prozess maximale Flexibilität bei der Auswahl der Rohöle, da in diesem Prozess – im Gegensatz zu einfacher physikalischer Destillation – das strukturelle Gleichgewicht und die molekulare Verteilung des Bitumens durch chemische Umwandlung angepasst werden kann.
<G-vec00095-002-s116><adjust.anpassen><en> As the numerous references show, the Biturox® Process grants a maximum flexibility in crude selection – as it can – different to just physical distillation - adjust the structural balance and the molecular distribution of the bitumen by chemical conversion.
<G-vec00095-002-s117><adjust.anpassen><de> Die horizontalen und/oder vertikalen Abstände zwischen mehreren Elemente eines Dialogs lassen sich vereinheitlichen, indem diese zunächst per Mehrfachauswahl markiert werden und anschließend über die Icons oder in der Symbolleiste des Target Editor oder über die entsprechenden Befehle im Kontextmenü angepasst werden.
<G-vec00095-002-s117><adjust.anpassen><en> The horizontal and/or vertical spaces between several elements of a dialog can be distributed evenly by selecting them via multiple selection and then using the or icon in the toolbar of the Target Editor or the corresponding commands in the text menu to adjust them.
<G-vec00095-002-s118><adjust.anpassen><de> Ab sofort können die Formatsteuerungen in Alchemy mit Logic Remote angepasst werden.
<G-vec00095-002-s118><adjust.anpassen><en> You can now use Logic Remote to adjust Format controls in Alchemy.
<G-vec00095-002-s119><adjust.anpassen><de> Würde als DDS ein Discovery Service eines anderen Standorts gewählt werden, müssen die Proxy-Einstellungen dieser DDS Installation zuvor angepasst werden.
<G-vec00095-002-s119><adjust.anpassen><en> If you selected the Discovery Service of another location as the DDS, you would have to adjust the proxy settings for this DDS installation.
<G-vec00095-002-s120><adjust.anpassen><de> Aufgrund sozialer Distanzierung und Bewegungseinschränkungen haben wir unsere Arbeitspraxis angepasst und neue Technologien eingeführt.
<G-vec00095-002-s120><adjust.anpassen><en> Thanks to social distancing and restrictions on movement, we have had to adjust our working practice and adapt to new technologies.
<G-vec00095-002-s121><adjust.anpassen><de> Die Zuglaschen erleichtern das Aufsetzen des Produkts auf den Körper und das Entfernen nach Gebrauch und können während des Spielens angepasst werden.
<G-vec00095-002-s121><adjust.anpassen><en> The pull tabs are designed to ease putting the product on the body and removing easily after use and can be used to adjust during play.
<G-vec00095-002-s122><adjust.anpassen><de> Wenn Sie die Größe/Form des markierten Objekts ändern, wird das Seitenverhältnis automatisch angepasst.
<G-vec00095-002-s122><adjust.anpassen><en> If you change the size/shape of the selected item, the aspect ratio will automatically adjust.
<G-vec00095-002-s123><adjust.anpassen><de> Im "Zeigen"-Navigator kann die Darstellung so angepasst werden, dass die Stabverformungen auch als gerenderte Querschnitte angezeigt werden (Bild 1).
<G-vec00095-002-s123><adjust.anpassen><en> In the "Display" navigator, you can adjust the display so that the member deformations are also shown as rendered cross-sections.
<G-vec00095-002-s124><adjust.anpassen><de> So wird die allgemeine Helligkeit des Bildes angepasst.
<G-vec00095-002-s124><adjust.anpassen><en> This will adjust the overall brightness of the image.
<G-vec00095-002-s125><adjust.anpassen><de> Durch das Trinken von aktivem Wasser kann das Elektrolythaushalt des menschlichen Körpers schnell angepasst, der Durst gelöscht und Alkohol und Fett beseitigt werden.
<G-vec00095-002-s125><adjust.anpassen><en> Drinking active water can quickly adjust electrolyte balance of human body, quench thirst, and eliminate alcohol and fatness.
<G-vec00095-002-s126><adjust.anpassen><de> *Die Preise können aufgrund des Umrechnungskurses von US-Dollar zum Euro angepasst werden.
<G-vec00095-002-s126><adjust.anpassen><en> *Prices may adjust based on the US dollar to Euro conversion rate.
<G-vec00095-002-s127><adjust.anpassen><de> Deine LAiMER Holzuhr kann von jedem Juwelier und Uhrmacher auf die gewünschte Größe angepasst werden.
<G-vec00095-002-s127><adjust.anpassen><en> Every jeweller or watch maker can adjust your LAiMER watch to the desired size.
<G-vec00095-002-s128><adjust.anpassen><de> Zwanzig Höhenpositionen sind einstellbar, sodass das Rack je nach individuellem Bedarf und gewählter Übung angepasst werden kann.
<G-vec00095-002-s128><adjust.anpassen><en> Twenty adjustable height positions allow you to adjust the rack according to your individual needs and selected exercises.
<G-vec00095-002-s129><adjust.anpassen><de> Die Aktivitäten müssen nur an ihre Bedürfnisse angepasst werden.
<G-vec00095-002-s129><adjust.anpassen><en> We just have to adjust the activities to their requirements.
<G-vec00095-002-s130><adjust.anpassen><de> Die Serva App dient als digitales Ticket mit der jederzeit die Abholzeit individuell angepasst werden kann, um Wartezeiten zu vermeiden.
<G-vec00095-002-s130><adjust.anpassen><en> The app serves as a digital ticket and lets you individually adjust the pick-up moment to avoid waiting time.
<G-vec00095-002-s131><adjust.anpassen><de> Einstellungen jedes unterstützten Ausgabeformats können angepasst werden, um bessere Qualität oder kleinere Dateigröße zu erzielen.
<G-vec00095-002-s131><adjust.anpassen><en> With every supported output format, you can adjust its settings to get better quality or smaller file size.
<G-vec00095-002-s132><adjust.anpassen><de> Da unsere Produkte über Jahre hergestellt werden, müssen unsere Prozesse ständig neuen Materialien und Formen angepasst werden.
<G-vec00095-002-s132><adjust.anpassen><en> Since we have been manufacturing our products for many years, it is necessary for us to adjust our manufacturing processes to new materials and shapes.
<G-vec00095-002-s133><adjust.anpassen><de> Behoben: Übergangslänge von Ausrichten/Feder Keys konnte nicht angepasst werden.
<G-vec00095-002-s133><adjust.anpassen><en> Fixed: Fixed inability to adjust the transition length for Reach/Spring Key.
<G-vec00095-002-s134><adjust.anpassen><de> Somit kann die Sitzgröße des Sattels an den jeweiligen Reiter angepasst werden.
<G-vec00095-002-s134><adjust.anpassen><en> You can therefore adjust the seat size of the saddle to suit each individual rider.
<G-vec00095-002-s135><adjust.anpassen><de> Diese Einstellung kann über das mobile Web derzeit noch nicht angepasst werden.
<G-vec00095-002-s135><adjust.anpassen><en> You can’t adjust this setting on the mobile web just yet.
<G-vec00095-002-s136><adjust.anpassen><de> Mithilfe der Control-Unit können sämtliche Einstellungen angezeigt sowie angepasst werden.
<G-vec00095-002-s136><adjust.anpassen><en> Using the control-unit, it is possible to view and adjust all settings.
<G-vec00095-002-s137><adjust.anpassen><de> Zusätzlich kann über das Spezialventil der statische Vordruck feinjustiert an die Umgebungstemperatur angepasst werden.
<G-vec00095-002-s137><adjust.anpassen><en> Moreover we can adjust the static pressure to the ambient temperature via the special valve.
<G-vec00095-002-s138><adjust.anpassen><de> Wichtig ist auch, dass die Beleuchtung individuell angepasst werden kann – schließlich unterscheiden sich die Bedürfnisse der einzelnen Mitarbeiter.
<G-vec00095-002-s138><adjust.anpassen><en> The ability to adjust the lighting individually is also important, as employees do ultimately have different needs.
<G-vec00095-002-s139><adjust.anpassen><de> ...ein manueller Trailing Stop-Loss denselben Prinzipien wie ein automatischer Trailing Stop-Loss unterliegt, wobei die Position jedoch vom Trader manuell angepasst werden muss.
<G-vec00095-002-s139><adjust.anpassen><en> a manual trailing stop loss order follows the same principle as an automated trailing stop loss but you manually adjust its position as the price moves.
<G-vec00095-002-s140><adjust.anpassen><de> Mit drei verschiedenen Fokusbereichen kann jede Fokusdistanz superschnell und einfach angepasst werden.
<G-vec00095-002-s140><adjust.anpassen><en> With three different zone focusing areas, it’s super-fast and easy to adjust to every focusing distance desired.
<G-vec00095-002-s141><adjust.anpassen><de> Die Tiefe deines 3D-Bildes kann durch Verschieben des Touchpens auf dem Touchscreen angepasst werden.
<G-vec00095-002-s141><adjust.anpassen><en> Adjust the depth of the 3D image by simply sliding your stylus on the Touch Screen.
<G-vec00095-002-s142><adjust.anpassen><de> Bei der Edition 2017 wurde der Fokussiermechanismus grundlegend überarbeitet, sodass der Fokusabstand schneller und genauer angepasst werden kann.
<G-vec00095-002-s142><adjust.anpassen><en> The focusing mechanism was fundamentally reworked in the 2017 edition to make it possible to more quickly and accurately adjust the focal distance.
<G-vec00095-002-s143><adjust.anpassen><de> Eine Mais-Einheits-Erntemaschine kann verwendet werden, um Reis, Weizen und Gerste, Bohnen, Mais, Sorghum, Sonnenblumen und andere Pflanzen zu ernten, solange die Teile gewechselt und angepasst werden.
<G-vec00095-002-s143><adjust.anpassen><en> A corn united harvest machine as long as the change and adjust a few parts, can be used to harvest rice, wheat and barley, beans, corn, sorghum, and sunflower and other crops.
<G-vec00095-002-s144><adjust.anpassen><de> Neben Songtitel und Lautsprecherstandort, kann nach weiteren Songs gesucht, die Reihenfolge verändert oder die Lautstärke angepasst werden.
<G-vec00095-002-s144><adjust.anpassen><en> In addition to viewing the song title and speaker position, you can search for other songs, change the order or adjust the volume.
<G-vec00095-002-s145><adjust.anpassen><de> Auch bei Dailymotion können Sie die Monetisierung von Videos freischalten, den Player anpassen und per Analyse-Tool die Einnahmen kontrollieren.
<G-vec00095-002-s145><adjust.anpassen><en> You can also make money with videos on Dailymotion, adjust the player, and oversee revenue with the analysis tool.
<G-vec00095-002-s146><adjust.anpassen><de> Landesspezifische Standards für die Darstellung von Datum, Uhrzeit und Adressen sollten sich ebenfalls anpassen lassen.
<G-vec00095-002-s146><adjust.anpassen><en> It should also be possible to adjust dates, times and addresses to suit the customary styles in specific countries.
<G-vec00095-002-s147><adjust.anpassen><de> Wir können die Produktgröße anpassen, um das Produkt bequem zu installieren und die Produktionseffizienz des Kunden zu verbessern.
<G-vec00095-002-s147><adjust.anpassen><en> We can adjust product size to make product install conveniently, improve the customer's production efficiency.
<G-vec00095-002-s148><adjust.anpassen><de> Wenn der Mehrwertsteuersatz sich jedoch zwischen dem Datum Ihrer Bestellung und dem Lieferdatum ändert, werden wir die von Ihnen zu zahlende Mehrwertsteuer anpassen, es sei denn, Sie haben die Produkte bereits vollständig bezahlt, bevor die Änderung des Mehrwertsteuersatzes in Kraft tritt.
<G-vec00095-002-s148><adjust.anpassen><en> If VAT is applicable and the rate changes between your order date and the date we supply the product, we will adjust the rate of VAT that you pay, unless you have already paid for the product in full before the change in the rate of VAT takes effect.
<G-vec00095-002-s149><adjust.anpassen><de> Der CL-E321 ist einfach und intuitiv zu bedienen, so dass Benutzer keine Zeit verschwenden, wenn Sie Etiketten ändern oder Einstellungen anpassen.
<G-vec00095-002-s149><adjust.anpassen><en> The CL-E321 is simple and intuitive to use, so that Users do not waste Time when they change Labels or adjust Settings.
<G-vec00095-002-s150><adjust.anpassen><de> Hier können Sie das Ausgabeformat als MP3, AAC, FLAC oder WAV wählen und Ausgabequalität bis zu 320 Kbps anpassen.
<G-vec00095-002-s150><adjust.anpassen><en> Here you can choose format as MP3, AAC, FLAC or WAV and adjust the output quality as required.
<G-vec00095-002-s151><adjust.anpassen><de> Mithilfe des Lely Vector können Viehhalter ihre Fütterungsstrategie für unterschiedliche Gruppen von Kühen definieren und exakt anpassen.
<G-vec00095-002-s151><adjust.anpassen><en> The Lely Vector enables cattle farmers to define and adjust their feeding strategy for different groups of animals.
<G-vec00095-002-s152><adjust.anpassen><de> Sie können die Einstellungen auch so anpassen, dass Ihr Browser alle Cookies (oder nur Cookies von Dritten) ablehnt.
<G-vec00095-002-s152><adjust.anpassen><en> You can also adjust the settings so that your browser rejects all cookies (or only third party cookies).
<G-vec00095-002-s153><adjust.anpassen><de> Sie können den Farbton eines einzelnen Objekts anpassen oder Farbtöne mithilfe des Farbton-Schiebereglers im Farbfeld- oder Farbbedienfeld erstellen.
<G-vec00095-002-s153><adjust.anpassen><en> You can adjust the tint of an individual object, or create tints by using the Tint slider in the Swatches panel or Color panel.
<G-vec00095-002-s154><adjust.anpassen><de> Administratoren können nun Lightweight Directory Access Protocol (LDAP) Anfragen anpassen, um öffentliche Schlüssel von Servern zu erhalten, die ein anderes Schema verwenden.
<G-vec00095-002-s154><adjust.anpassen><en> Administrators can now adjust Lightweight Directory Access Protocol (LDAP) queries to obtain public keys from servers that use a different schema.
<G-vec00095-002-s155><adjust.anpassen><de> Mit der integrierten Firewall können Sie das Gerät komplett Ihren Anforderungen anpassen.
<G-vec00095-002-s155><adjust.anpassen><en> With the built-in firewall, you can adjust the device completely to your requirements.
<G-vec00095-002-s156><adjust.anpassen><de> Er kann die Aufstellung dadurch taktisch dem Gegner anpassen.
<G-vec00095-002-s156><adjust.anpassen><en> This allows him to tactically adjust the line-up to the opposing team.
<G-vec00095-002-s157><adjust.anpassen><de> Description (Multi-Speed + LCD-Bildschirm): Mit Geschwindigkeiten von 1 bis 6 km / h können Sie mit dem Laufband die Geschwindigkeit per Fernbedienung an Ihre körperliche Verfassung und Ihre Trainingsbedürfnisse anpassen.
<G-vec00095-002-s157><adjust.anpassen><en> (Multi-Speed + LCD screen): With speeds ranging from 1 - 6 km / h, the treadmill allows you to adjust the speed by remote control according to your physical condition and your exercise needs.
<G-vec00095-002-s158><adjust.anpassen><de> Man muss nur seine Geschwindigkeit anpassen.
<G-vec00095-002-s158><adjust.anpassen><en> One only has to adjust his speed.
<G-vec00095-002-s159><adjust.anpassen><de> Wenn man beispielsweise die Blende anpassen möchte, erscheint die Meldung „Objektivöffnung: Passen Sie die einströmende Lichtmenge und die Hintergrundunschärfe an, indem Sie diesen Wert erhöhen oder verringern”.
<G-vec00095-002-s159><adjust.anpassen><en> For example, if you want to adjust the f-stop, the following notification appears: `Lens opening - adjust the amount of incoming light and background blur by increasing or decreasing this value`.
<G-vec00095-002-s160><adjust.anpassen><de> Mit individuellen Optionen gestaltest du deine Stadt nach deinen Vorstellungen und du kannst deine Spielerfahrung an neue Herausforderungen anpassen.
<G-vec00095-002-s160><adjust.anpassen><en> Custom options allow you to set up your city the way you see fit, and it allows you to change your gaming experience as you adjust to new challenges.
<G-vec00095-002-s161><adjust.anpassen><de> Außerdem können Sie die Helligkeit und Sättigung anpassen.
<G-vec00095-002-s161><adjust.anpassen><en> You can also adjust the collage's lightness and saturation in the graphics editor.
<G-vec00095-002-s162><adjust.anpassen><de> Klicken Sie auf „Anpassen“, um das Bedienfeld „Anpassen“ zu öffnen.
<G-vec00095-002-s162><adjust.anpassen><en> Click Adjust to open the Adjust panel.
<G-vec00095-002-s164><adjust.anpassen><de> Wir haben praxiserprobte Produkte, mit denen Sie die Verarbeitungseigenschaften des Betons gezielt Ihren eigenen Bedürfnissen anpassen können.
<G-vec00095-002-s164><adjust.anpassen><en> We have tried and tested products that allow you to adjust the processing properties of the concrete, targeted to your own needs.
<G-vec00095-002-s165><adjust.anpassen><de> Wünschenswert wäre hier im Lieferumfang noch eine etwas schwächere Feder gewesen, um den Joystick an andere Flugzeugtypen anpassen zu können.
<G-vec00095-002-s165><adjust.anpassen><en> It would be desirable if the set contains another weaker spring to adjust the joystick to other aircraft types.
<G-vec00095-002-s166><adjust.anpassen><de> Sie können aus einer Liste mit EQ-Vorgaben auswählen, die Sie mit Ihrem Audio testen und anhand des Schiebereglers anpassen können.
<G-vec00095-002-s166><adjust.anpassen><en> You can choose from a list of EQ presets that you can use on your audio and adjust the amount using the slider.
<G-vec00095-002-s167><adjust.anpassen><de> Eine Stärke von Vivaldi ist die Möglichkeit, den Browser ganz so anpassen zu können wie man es als Nutzer braucht.
<G-vec00095-002-s167><adjust.anpassen><en> A thickness of Vivaldi, the possibility of the Browser, so adjust as you need it as a user.
<G-vec00095-002-s168><adjust.anpassen><de> Auf dem HUD wird Ihre Geschwindigkeit neben der Geschwindigkeitsbegrenzung direkt vor Ihnen angezeigt, damit Sie Ihre Fahrweise jederzeit anpassen können.
<G-vec00095-002-s168><adjust.anpassen><en> Speed limit respect: With the HUD, your speed is displayed next to the speed limit right in front of you to let you adjust your driving at any moment.
<G-vec00095-002-s169><adjust.anpassen><de> Sie sind besonders praktisch, da Sie Ihre Parkdauer anpassen können: wenn Sie früher zum Fahrzeug zurückkehren, können Sie über die App die Parkzeit verkürzen und zahlen dann weniger.
<G-vec00095-002-s169><adjust.anpassen><en> They are very convenient because they allow you to adjust your parking time. For example, if you return to your vehicle faster than expected, you can use one of the applications to only pay for the time you actually spent on the parking spot.
<G-vec00095-002-s170><adjust.anpassen><de> In Abhängigkeit vom System und Ihrem Therapiebedarf, erhalten Sie ein Handgerät (unten abgebildet), mit dem Sie das System ein- und ausschalten, die Stimulation anpassen und den Batteriestatus prüfen können.
<G-vec00095-002-s170><adjust.anpassen><en> Depending on the system and your therapy needs, you may have a controller that allows you to turn the system on and off, adjust the stimulation, and check the battery.
<G-vec00095-002-s171><adjust.anpassen><de> Je nachdem welchen Style Sie wählen, werden weitere Anpassungen angezeigt, mit denen Sie Etiketten hinzufügen können und die Button Optionen anpassen können.
<G-vec00095-002-s171><adjust.anpassen><en> Depending on which style you choose, more tweaks will appear to add labels and adjust the button options.
<G-vec00095-002-s172><adjust.anpassen><de> Es handelt sich um einen Verwischeffekt, mit dem Sie den Winkel des Übergangs anpassen können.
<G-vec00095-002-s172><adjust.anpassen><en> It is a wipe effect that allows you to adjust the angle of the transition.
<G-vec00095-002-s173><adjust.anpassen><de> Entdecken Sie die umfassenden Tools und benutzerfreundlichen Funktionen von PhotoDirector, mit denen Sie Fotos professionell bearbeiten und anpassen können.
<G-vec00095-002-s173><adjust.anpassen><en> Discover PhotoDirector's comprehensive tools and easy-to-use features that make it easier than ever to professionally edit and adjust photos.
<G-vec00095-002-s174><adjust.anpassen><de> Wenn mindestens zwei Felder im Dialogfeld enthalten sind und Sie ein Feld auswählen, werden die Schaltflächen zum Verschieben aktiviert, sodass Sie die Reihenfolge der Felder anpassen können.
<G-vec00095-002-s174><adjust.anpassen><en> When there are at least two or more fields in the dialog and if you select a field the “Move” buttons will become enabled and let you adjust the order of the fields.
<G-vec00095-002-s175><adjust.anpassen><de> Außerdem ist parallel zur Einführung von Ultra High Definition TV (UHDTV) und 4K ein neues Tonformat entstanden, das neben beeindruckenden Klangerlebnissen weiteren Mehrwert für das TV-Publikum bereithält: Basierend auf dem maßgeblich vom Fraunhofer IIS mitentwickelten MPEG-H Audio Standard sollen Zuschauer künftig zwischen verschiedenen Sprachen oder Tonspuren wechseln und Moderatoren oder Dialoge in der Lautstärke anpassen können.
<G-vec00095-002-s175><adjust.anpassen><en> Similar to the introduction of Ultra High Definition TV (UHDTV) and 4K, the new audio format MPEG-H audio was created to deliver impressive sound to TV audiences, further adding to their audio experience. As a core contributor, Fraunhofer IIS played a major role in the co-development of the new MPEG-H audio standard which will give TV viewers the ability to tailor the sound mix to their personal preferences, e.g. to switch between different languages and audio tracks or to adjust the audio balance of television presenters and dialogues.
<G-vec00095-002-s176><adjust.anpassen><de> Es gibt auch einen Standard-Windows-Lüftereinstellungsmodus und einen manuellen Modus, mit dem Benutzer die Geschwindigkeit der dedizierten GPU- und CPU-Lüfter individuell anpassen können.
<G-vec00095-002-s176><adjust.anpassen><en> There is also a default Windows fan settings mode, and a Manual mode for users to individually adjust the speed of the dedicated GPU and CPU fans.
<G-vec00095-002-s177><adjust.anpassen><de> In diesen Cookies werden Informationen zu Ihren persönlichen Einstellungen hinterlegt, sodass wir unsere Webseite an Ihre Bedürfnisse anpassen können.
<G-vec00095-002-s177><adjust.anpassen><en> They save your personal settings in order to adjust the website to your needs.
<G-vec00095-002-s178><adjust.anpassen><de> Last but not least, Metall-Teleskoprohr, mit dem Sie die Höhe leicht anpassen können.
<G-vec00095-002-s178><adjust.anpassen><en> Last but not least, metal telescopic tube, which allows you to easily adjust the height.
<G-vec00095-002-s179><adjust.anpassen><de> Die Simulation der Straße erfolgt mit verschiedenen Positionen, die Sie selbst anpassen können.
<G-vec00095-002-s179><adjust.anpassen><en> The road is simulated using different positions that you adjust yourself.
<G-vec00095-002-s180><adjust.anpassen><de> Dieses Fach ist mit robusten internen Trennwänden ausgestattet, mit denen Sie das Layout nach Ihren Wünschen anpassen können.
<G-vec00095-002-s180><adjust.anpassen><en> This compartment is equipped with sturdy internal dividers that allow you to adjust the layout to your liking.
<G-vec00095-002-s181><adjust.anpassen><de> Das Spiel ist völlig konfigurierbar, sodass Sie den Schwierigkeitsgrad anpassen können.
<G-vec00095-002-s181><adjust.anpassen><en> The game is totally customizable, in such a way that you will have the possibility to adjust the difficulty.
<G-vec00095-002-s182><adjust.anpassen><de> - Vollständige und bequeme Anpassung der Einstellungen an die unterschiedliche Körperform des Benutzers, sodass Sie das Training für alle anpassen können.
<G-vec00095-002-s182><adjust.anpassen><en> - Full and convenient adjustment of settings to the different body shape of the user, allowing you to adjust the training for everyone.
<G-vec00095-002-s183><adjust.anpassen><de> Zudem können Sie Windows 8.1 mit Avast Cleanup optimieren, dass Ihre Einstellungen anpasst, Datenmüll leert und die Registry aufräumt, damit Ihr Windows 8.1-PC wieder wie neu läuft.
<G-vec00095-002-s183><adjust.anpassen><en> In addition, you can optimize Windows 8.1 with Avast Cleanup, which will adjust settings, clear junk data, and clean out your registry to get your Windows 8.1 PC running as good as new.
<G-vec00095-002-s184><adjust.anpassen><de> Der POS steht unter Zugzwang – wer sich nicht den Bedürfnissen der Kunden anpasst, wie es jeder Online-Händler tut, hat in Zukunft keine Chance.
<G-vec00095-002-s184><adjust.anpassen><en> The POS is forced to take action, and it only has chance in the future, if they do adjust their services to the needs of the customers, just as online retailers do.
<G-vec00095-002-s185><adjust.anpassen><de> Wenn du das Design anpasst, dann siehst du sofort, falls Inhalte nicht mehr in den Bereich passen und kannst das ändern.
<G-vec00095-002-s185><adjust.anpassen><en> If you adjust the design, you will see immediately if content no longer fits into the area and can change this.
<G-vec00095-002-s186><adjust.anpassen><de> Erweitertes Energiemanagement, das auf Grundlage der an den Prozessor gestellten Leistungsanforderungen automatisch und unmittelbar Leistung und Funktionen anpasst.
<G-vec00095-002-s186><adjust.anpassen><en> Enhanced power management features automatically and instantaneously adjust performance states and features based on processor performance requirements, helping users get more efficient performance by dynamically activating or turning off parts of the processor.
<G-vec00095-002-s187><adjust.anpassen><de> Wer nicht ständig zwischen der normalen Alltagsbrille und der Sonnenbrille bei Lichtwechsel tauschen möchte, dem kann die Drinnen-/Draußen-Brille, die sich mit automatisch verfärbenden Brillengläsern den Lichtverhältnissen anpasst, weiterhelfen: PhotoFusion heißt das Zauberwort.
<G-vec00095-002-s187><adjust.anpassen><en> If you prefer not to constantly have to switch back and forth between glasses and sunglasses as light conditions change, you might want to consider an indoor/outdoor solution with lenses that automatically adjust to changing light conditions: PhotoFusion.
<G-vec00095-002-s188><adjust.anpassen><de> Ahmt Gehen, Joggen oder Laufen nach und fügt mit Octanes charakteristischem SmartStride, der die Schrittlänge, basierend auf dem Tempo des Nutzers, automatisch zwischen 51 und 71 cm anpasst, neue Herausforderungen hinzu.
<G-vec00095-002-s188><adjust.anpassen><en> Solicite un presupuesto Email a and automatically adjust the stride length to replicate walking, jogging and running for greater comfort, variety and challenge.
<G-vec00095-002-s189><adjust.anpassen><de> Viel sinnvoller ist eine flexible Steuerung, die auf Verkehrslage und Wetter Rücksicht nimmt und die Höchstgeschwindigkeit situationsabhängig anpasst.
<G-vec00095-002-s189><adjust.anpassen><en> Far more useful would be flexible controls that take into account specific traffic and weather conditions and adjust the maximum speed depending on the situation.
<G-vec00095-002-s190><adjust.anpassen><de> Das Miteinander funktioniert dann gut, wenn genügend Platz vorhanden ist, bei gemischten Flächen kein Verkehrsmittel einen Vorrang suggeriert bekommt, der Gesamteindruck eindeutig ist in dem Sinne, dass der Radverkehr bei den Fußgängern "zu Gast" ist und sich entsprechend in der Fahrgeschwindigkeit anpasst.
<G-vec00095-002-s190><adjust.anpassen><en> Shared use is likely to be successful provided that enough space is available, that implied priority for any means of transport is removed, and that the overall impression is clearly transmitted to cyclists that they are 'guests' on pedestrian spaces and thus have to adjust their cycling speed.
<G-vec00095-002-s191><adjust.anpassen><de> iQ flow control, das dritte auf der Plastimagen präsentierte Assistenzsystem, vernetzt die mit einem elektronischen Temperierwasserverteiler vom Typ e flomo ausgestattete Spritzgießmaschine mit dem Temperiergerät, so dass sich die Drehzahl der Pumpe automatisch an den tatsächlichen Bedarf anpasst.
<G-vec00095-002-s191><adjust.anpassen><en> iQ flow control, the third assistance system presented at the Plastimagen, will connect the injection moulding machine, which is equipped with an e-flomo electronic temperature control water distributor, to the temperature control unit, enabling the pump speed to automatically adjust to the actual requirement.
<G-vec00095-002-s192><adjust.anpassen><de> Wenn der technische Aufbau abgeschlossen ist und alles richtig funktioniert, ist wieder der Intonateur gefordert, der – wie schon bei der Vorintonation in der Werkstatt – den Klang jeder Pfeife im Zusammenhang mit den anderen Pfeifen und Registern sowie der Raumakustik anpasst.
<G-vec00095-002-s192><adjust.anpassen><en> Voicing and final tuning When the technical assembly is completed and everything is working properly the voicer comes in once again to adjust the sound of each pipe to the rest of the pipes and ranks and to the acoustics of the place of destination.
<G-vec00095-002-s193><adjust.anpassen><de> Erschwert wird der Rennfahreralltag allerdings dadurch, dass sich die KI sehr schnell an das Können des Spielers anpasst: Selbst auf niedrigeren Schwierigkeitsstufen kann man nur zwei bis drei Rennen in Folge problemlos gewinnen, bis sich die Konkurrenz insoweit angepasst hat, dass die nächste Podiumsplatzierung ein hartes Stück Arbeit wird.
<G-vec00095-002-s193><adjust.anpassen><en> However, the AI drivers are able to adjust very rapidly to the player's skill level: Even on the lower difficulty settings, you are only able to win two up to three consecutive races. By then, your competitors have adapted insofar as your next podium finish will require hard work.
<G-vec00095-002-s194><adjust.anpassen><de> Es ist deshalb sehr wichtig, dass sich der Laser automatisch “on the fly” anpasst und ein Gleichgewicht bei jeder Lagenstärke findet.
<G-vec00095-002-s194><adjust.anpassen><en> It is therefore important for the laser to automatically adjust itself ‘on the fly’ to balance out any variation in film thickness.
<G-vec00095-002-s195><adjust.anpassen><de> Wir möchten, dass er sich gemeinsam mit uns verändert und sich an unseren Stil anpasst, der schließlich nicht statisch ist: unser Stil variiert je nach Alter, Umgebung und den Situationen, mit denen uns das Leben konfrontiert.
<G-vec00095-002-s195><adjust.anpassen><en> We want it to change with us and adjust to our taste, which of course doesn't stay the same: it changes depending on our age, surroundings, the situation of our life.
<G-vec00095-002-s196><adjust.anpassen><de> Der Vorteil eines deutschen Anbieters liegt darin, dass er die Begebenheiten und Regelungen vor Ort kennt und die Leistungen darauf anpasst, außerdem erhält man meist gleich die Bestätigung, die bei der Universität oder bei der Einreise vorgelegt werden muss.
<G-vec00095-002-s196><adjust.anpassen><en> The advantage of taking a German company is that they know the rules and regulations of the German system very well and adjust the benefits to these conditions. You also normally receive the document to show at university or when passing the boarder right away.
<G-vec00095-002-s197><adjust.anpassen><de> Dem Umschnallgurt selbst, der normalerweise aus einem gepolsterten Vorderteil und einer Reihe von gepolsterten Gurten besteht, in die man hineinsteigt und anschließend an der Taille und/oder den Beinen anpasst.
<G-vec00095-002-s197><adjust.anpassen><en> The strap-on harness itself, which usually has a padded front section and a series of adjustable straps that you step into and then adjust at the waist and/or the legs.
<G-vec00095-002-s198><adjust.anpassen><de> Headset-Mikrofon: Das Mikrofon enthält einen Kopfbügel, der dem Kopf anpasst wird.
<G-vec00095-002-s198><adjust.anpassen><en> Headset or head microphones: The microphone includes a headband to adjust onto the guide’s head.
<G-vec00095-002-s199><adjust.anpassen><de> Retuschiere Bilder, indem du sie aufhellst oder die Farben anpasst, entscheide dich für ein Format und eine Größe und drücke auf Drucken.
<G-vec00095-002-s199><adjust.anpassen><en> Retouch the picture to make it brighter or adjust the colors, decide the format and size, and click on the Print button.
<G-vec00095-002-s200><adjust.anpassen><de> Sofern Ihr die Seifenblase nicht immer im selben Abstand zum Blitz positioniert, macht Ihr es Euch am einfachsten, wenn Ihr den Blitz auf Automatik (TTL) stellt und die Helligkeit nötigenfalls mit der Blitzbelichtungskorrektur anpasst.
<G-vec00095-002-s200><adjust.anpassen><en> In case you do not position the bubble on the same spot every time, the most convenient option is to set the flash to auto-exposure (TTL) and use flash exposure compensation to adjust its brightness as needed.
<G-vec00095-002-s201><adjust.anpassen><de> In diesem Tutorial wird Dir gezeigt wie Du Reporte erstellst und anpasst.
<G-vec00095-002-s201><adjust.anpassen><en> In this tutorial you will be shown how to create and adjust these reports.
<G-vec00095-002-s221><adjust.anpassen><de> Sie beauftragte Tebis Berater, um Interne Abläufe anzupassen und vorhandene Potenziale besser zu nutzen.
<G-vec00095-002-s221><adjust.anpassen><en> They ordered Tebis consultants to adjust internal procedures and to better utilize existing potential.
<G-vec00095-002-s222><adjust.anpassen><de> Bei diesem Update lag unser Hauptaugenmerk darauf, die Karten mit der Fähigkeit "Erschaffen" zu ändern, sowie die Austausch-Mechanik anzupassen.
<G-vec00095-002-s222><adjust.anpassen><en> With this update, our main focus was to change cards with the Create ability, as well as to adjust the Swap mechanic. See more
<G-vec00095-002-s223><adjust.anpassen><de> Flex-Connect können Sie Ihr Sealife Kamera-Set von der kompakten Version transformieren, um mit vollem Funktionsumfang in nur wenigen Sekunden, eine schnelle Möglichkeit zu haben, um die Sealife Unterwasserkamera bei jedem Tauchgang dem Umfeld anzupassen.
<G-vec00095-002-s223><adjust.anpassen><en> Flex-Connect allows you to transform your camera set from compact to full-featured in just seconds, providing a quick way to adjust to any dive environment.
<G-vec00095-002-s224><adjust.anpassen><de> Als erfahrener und sehr gut vernetzter Immobilieninvestor ist es uns deshalb sehr wichtig eng am Markt zu sein, um Chancen für unsere Anleger aktiv wahrzunehmen und dort, wo es notwendig ist, in enger Abstimmung mit dem Fondsmanagement Portfoliostrategien anzupassen.
<G-vec00095-002-s224><adjust.anpassen><en> As an experienced and very well networked real estate investor, it is therefore very important for us to be close to the market in order to actively seize opportunities for our investors and, where necessary, adjust portfolio strategies in close coordination with fund management.
<G-vec00095-002-s225><adjust.anpassen><de> Dabei gibt es viele Möglichkeiten die Licht-Einstellungen auf den eigenen Geschmack anzupassen.
<G-vec00095-002-s225><adjust.anpassen><en> There are many ways to adjust the light settings to your own taste.
<G-vec00095-002-s226><adjust.anpassen><de> Im Vergleich zu herkömmlichen Kameras haben wir bei den Kameras unserer Smartphones nur begrenzt die Möglichkeit, Blende, Belichtungszeit und anderen Einstellungen anzupassen.
<G-vec00095-002-s226><adjust.anpassen><en> Smartphone cameras restrict the ability to adjust aperture, shutter speed and other settings, as you might do on a conventional camera.
<G-vec00095-002-s227><adjust.anpassen><de> Um schnell gut zu werden ist es notwendig, manche Verhaltensformen anzupassen oder zu verändern.
<G-vec00095-002-s227><adjust.anpassen><en> To see quick results it is necessary to adjust and change some forms of behavior.
<G-vec00095-002-s228><adjust.anpassen><de> Um die Intensität anzupassen, genügt ein erneuter Fingertipp auf den ausgewählten Filter.
<G-vec00095-002-s228><adjust.anpassen><en> To adjust the intensity, simply tap the selected filter again.
<G-vec00095-002-s229><adjust.anpassen><de> Von diesem neuen Wissen getrieben, organisierte sie verschiedene Programme über Weben, Wollverarbeitung und Stricken, mit dem Ziel, handwerkliche Produkte dem Markt anzupassen.
<G-vec00095-002-s229><adjust.anpassen><en> Influenced with this new knowledge she organized different programs that would encourage women to do weaving, by processing of wool and knitting, in a way to adjust this products to the necessities of a market.
<G-vec00095-002-s230><adjust.anpassen><de> Klicken Sie im Bereich "Datenschutz" auf Inhaltseinstellungen, um Ihre Berechtigungen für Cookies, Bilder, JavaScript, Plug-ins, Pop-ups sowie für die Standortfreigabe anzupassen.
<G-vec00095-002-s230><adjust.anpassen><en> Click Content settings in the "Privacy" section to adjust your permissions for cookies, images, JavaScript, plug-ins, pop-ups and location sharing.
<G-vec00095-002-s231><adjust.anpassen><de> Der Begriff „eine Anweisung zur Anpassung” bedeutet eine Anweisung, eine Rechenanweisung, einen Algorithmus, einen Faktor oder im weitesten Sinne eine Information, welche von der Signalverarbeitungseinrichtung des Hörgeräts genutzt werden kann, um die Verstärkungseigenschaften des Hörgeräts an die Bedürfnisse des Trägers anzupassen.
<G-vec00095-002-s231><adjust.anpassen><en> The term "an instruction to adaptation" means a statement that a computing instruction, an algorithm, a factor or in the broadest sense information which can be used by the signal processing device of the hearing aid to adjust the amplification characteristics of the hearing aid to the needs of the wearer.
<G-vec00095-002-s232><adjust.anpassen><de> Griffweiteneinstellung: Wenn du mit nur einem Finger deine Fahrt kontrollieren kannst, ist es äußerst wichtig, die Bremsgriffe exakt an die einzigartige Form deiner Hände anzupassen.
<G-vec00095-002-s232><adjust.anpassen><en> Grip width adjustment If you can control your ride with just one finger, it’s extremely important to adjust the brake grips exactly to the unique shape of your hands.
<G-vec00095-002-s233><adjust.anpassen><de> Die Person ist nicht in der Lage ihren Schlaf-Wach-Rhythmus an die Länge eines Tages anzupassen und ihre Schlafzeiten wandern stetig um die Uhr.
<G-vec00095-002-s233><adjust.anpassen><en> The person is unable to adjust his sleep/wake cycle to the length of the day, and his sleep time progresses around the clock.
<G-vec00095-002-s234><adjust.anpassen><de> Sobald sie sich im Zimmer befinden, können Ihre Gäste das dort verfügbare Tablet oder das Hotel TV mit LYNC HMS-Lösung nutzen, um die Beleuchtung und die Jalousien bequem anzupassen, ohne dass sie sich dazu bewegen müssen.
<G-vec00095-002-s234><adjust.anpassen><en> Once inside the room, guests can use the in-room tablet or the Hospitality TV with LYNC HMS solution to easily adjust the lighting and draw the blinds, all without having to move.
<G-vec00095-002-s235><adjust.anpassen><de> Um den produktinternen Status im ersten Bereich von ESET Endpoint Security anzupassen, navigieren Sie zu Benutzeroberfläche > Elemente der Benutzeroberfläche > Anzuzeigende Hinweise in den erweiterten Einstellungen von ESET Endpoint Security.
<G-vec00095-002-s235><adjust.anpassen><en> Application statuses To adjust in-product statuses in the first pane of ESET Endpoint Antivirus navigate to User interface > User interface elements > Application statuses of the ESET Endpoint Antivirus Advanced setup tree.
<G-vec00095-002-s236><adjust.anpassen><de> Für diejenigen, die abnehmen wollen, oder ein wenigSie können diese Art der Massage auch verwenden, um die Figur anzupassen.
<G-vec00095-002-s236><adjust.anpassen><en> For those who want to lose weight, or a littleYou can also use this kind of massage to adjust the figure.
<G-vec00095-002-s237><adjust.anpassen><de> h) Sollten sich nach Vertragsschluss Kostensenkungen oder Kostenerhöhungen ergeben, ist WRW berechtigt, die vereinbarten Preise anzupassen.
<G-vec00095-002-s237><adjust.anpassen><en> h) Should cost reductions or cost increases arise after the contract has been concluded, WRW is entitled to adjust the agreed upon price.
<G-vec00095-002-s238><adjust.anpassen><de> Es ist’ jedoch wichtig, die Hörgeräte so häufig und lange wie möglich zu tragen, um dem Gehirn Zeit zu geben, sich anzupassen.
<G-vec00095-002-s238><adjust.anpassen><en> But it’s important to wear the hearing aids as much as possible, to give the brain time to adjust.
<G-vec00095-002-s239><adjust.anpassen><de> PROTIQ ist berechtigt, die vereinbarte monatliche Anbietergebühr bei jeder Laufzeitverlängerung des Anbieterkontos anzupassen.
<G-vec00095-002-s239><adjust.anpassen><en> PROTIQ is entitled to adjust the agreed monthly dealer fee on each extension of the term of the dealer account.
<G-vec00095-002-s259><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von San Francisco nach Hong Kong basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s259><adjust.anpassen><en> Airlines can adjust prices for tickets from San Francisco to Hong Kong based on the day and time that you decide to book your flight.
<G-vec00095-002-s260><adjust.anpassen><de> Eine solche höhere Deckungssumme sollte in Geltungsdauer und -umfang begrenzt sein, und die betreffenden Mitgliedstaaten sollten die Zielausstattung und die in ihre Einlagensicherungssysteme eingezahlten Beiträge proportional anpassen.
<G-vec00095-002-s260><adjust.anpassen><en> Such higher coverage level should be limited in time and in scope and the Member States concerned should adjust the target level and contributions paid to their DGSs proportionately.
<G-vec00095-002-s261><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Seoul nach Hong Kong basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s261><adjust.anpassen><en> Airlines can adjust prices for tickets from Seoul to Hong Kong based on the day and time that you decide to book your flight.
<G-vec00095-002-s262><adjust.anpassen><de> Wenn Sie diese Funktion verwenden, können Sie die Unterschiede der Körperhaltung zwischen G2, G3 und G5 Charakteren anpassen und Fehler beim Einsetzen von Bewegungen für einen Charakter, wie das Vor- oder Zurücklehnen des Körpers oder Körpergliedmaßen, die den Körper durchdringen, zu vermeiden.
<G-vec00095-002-s262><adjust.anpassen><en> Using this feature you can adjust the posture differences between G2, G3 and G5 characters, and prevent issues such as body leans forward or backward or limb penetration into the body when you apply motions to a character with unique body proportions.
<G-vec00095-002-s263><adjust.anpassen><de> Sie können die Menge an interessenbezogener Werbung, die Sie von uns erhalten, anpassen, indem Sie Ihre Cookie-Einstellungen ändern und / oder aus Werbenetzwerken aussteigen.
<G-vec00095-002-s263><adjust.anpassen><en> You may adjust the amount of interest-based advertising you may receive from us by changing your cookie settings and/or opting out of advertising networks.
<G-vec00095-002-s264><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Delhi nach Hong Kong basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s264><adjust.anpassen><en> Airlines can adjust prices for tickets from Delhi to Hong Kong based on the day and time that you decide to book your flight.
<G-vec00095-002-s265><adjust.anpassen><de> Die Gäste können die Temperatureinstellungen in ihren Zimmern nach wie vor anpassen, doch sorgt die intelligente Steuerung der Energieversorgung dafür, dass Hotels Energiekosten senken, die Leistung des Energiesystems steigern und die betriebliche Effizienz fördern können.
<G-vec00095-002-s265><adjust.anpassen><en> While guests can adjust temperature settings in their rooms, anticipating opportunities to more intelligently control energy distribution helps hotels reduce energy costs, promote energy system performance and drive operational efficiency.
<G-vec00095-002-s266><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Atlanta nach Washington, District of Columbia basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s266><adjust.anpassen><en> Airlines can adjust prices for tickets from Atlanta to Washington, District of Columbia based on the day and time that you decide to book your flight.
<G-vec00095-002-s267><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Delhi nach Dallas basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s267><adjust.anpassen><en> Airlines can adjust prices for tickets from Delhi to Dallas based on the day and time that you decide to book your flight.
<G-vec00095-002-s268><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Toronto nach Bangkok basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s268><adjust.anpassen><en> Airlines can adjust prices for tickets from Toronto to Bangkok based on the day and time that you decide to book your flight.
<G-vec00095-002-s269><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Detroit nach New York City basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s269><adjust.anpassen><en> Airlines can adjust prices for tickets from Detroit to New York City based on the day and time that you decide to book your flight.
<G-vec00095-002-s270><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Miami, Florida nach Toronto basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s270><adjust.anpassen><en> Airlines can adjust prices for tickets from Miami, Florida to Toronto based on the day and time that you decide to book your flight.
<G-vec00095-002-s271><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Paris, France nach Miami, Florida basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s271><adjust.anpassen><en> Airlines can adjust prices for tickets from Paris, France to Miami, Florida based on the day and time that you decide to book your flight.
<G-vec00095-002-s272><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von New York City nach Guayaquil basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s272><adjust.anpassen><en> Airlines can adjust prices for tickets from New York City to Guayaquil based on the day and time that you decide to book your flight.
<G-vec00095-002-s273><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von New York City nach Montreal basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s273><adjust.anpassen><en> Airlines can adjust prices for tickets from New York City to Montreal based on the day and time that you decide to book your flight.
<G-vec00095-002-s274><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Los Angeles, California nach Seoul basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s274><adjust.anpassen><en> Airlines can adjust prices for tickets from Los Angeles, California to Seoul based on the day and time that you decide to book your flight.
<G-vec00095-002-s275><adjust.anpassen><de> Während dieser Zeit kann sich die Waage an die Umgebungstemperatur und -bedingungen anpassen.
<G-vec00095-002-s275><adjust.anpassen><en> This period allows the balance to adjust to ambient temperature and stabilise to its environment.
<G-vec00095-002-s276><adjust.anpassen><de> Die Fluggesellschaften können die Preise für Tickets von Rome, Italy nach Chicago basierend auf dem Tag und der Uhrzeit Ihrer Flugbuchung anpassen.
<G-vec00095-002-s276><adjust.anpassen><en> Airlines can adjust prices for tickets from Rome, Italy to Chicago based on the day and time that you decide to book your flight.
<G-vec00095-002-s277><adjust.anpassen><de> Sie können die Musiklautstärke anpassen oder Lieder ändern oder Kopfhörer laden, indem Sie sie leicht berühren.
<G-vec00095-002-s277><adjust.anpassen><en> You could adjust music volume or change songs or charging earbuds by touching easily.
<G-vec00095-002-s297><adjust.anpassen><de> Dignita behält sich das Recht vor, die Preise jederzeit anzupassen.
<G-vec00095-002-s297><adjust.anpassen><en> Dignita reserves the right to adjust prices at any time.
<G-vec00095-002-s298><adjust.anpassen><de> Die Möglichkeit, die Größe und Widerstandsfähigkeit der Palette an die Spezifität der Ladung anzupassen.
<G-vec00095-002-s298><adjust.anpassen><en> Possibility to adjust the dimensions and strength parameters of the pallet to the specificity of the load.
<G-vec00095-002-s299><adjust.anpassen><de> Der iMac nutzt den Umgebungslichtsensor, um die Bildschirmhelligkeit des Displays an Ihre Umgebung anzupassen.
<G-vec00095-002-s299><adjust.anpassen><en> Your iMac uses the ambient light sensor to adjust the display's brightness based on your environment.
<G-vec00095-002-s300><adjust.anpassen><de> Ziehen Sie Ihren Finger über den Bildschirm, um die Helligkeit oder die Geschwindigkeit von den verschiedenen Modi anzupassen.
<G-vec00095-002-s300><adjust.anpassen><en> Swipe up or down the screen to adjust brightness or change the speed of the different modes.
<G-vec00095-002-s301><adjust.anpassen><de> 2005 bekam Toon Thellier den Auftrag die all abendliche für tausende von Besuchern inszenierte Sound und Lichtshow neu zu überarbeiten und die Technik den modernen Anforderungen eines Show Control Systems anzupassen.
<G-vec00095-002-s301><adjust.anpassen><en> In 2005, Toon Thellier was asked to alter and revise the sound and light show attended by thousands of visitors every evening and to adjust technology to the demanding requirements of a modern show control system.
<G-vec00095-002-s302><adjust.anpassen><de> Ziehen Sie den Regler „Dichte“, um die Deckkraft der Maske anzupassen, oder den Regler „Weiche Kante“, um Maskenkanten weichzuzeichnen.
<G-vec00095-002-s302><adjust.anpassen><en> Drag the Density slider to adjust mask opacity, or the Feathering slider to feather mask edges.
<G-vec00095-002-s303><adjust.anpassen><de> Um die Helligkeit der Statusanzeige anzupassen oder eine Benachrichtigung zu verwerfen, drücken Sie die Multifunktionstaste.
<G-vec00095-002-s303><adjust.anpassen><en> To adjust the indicator light brightness, or to dismiss a notification, press the multifunction key.
<G-vec00095-002-s304><adjust.anpassen><de> SEMIKRON behält sich ausdrücklich das Recht vor, die Preise für 2019 Lieferungen anzupassen.
<G-vec00095-002-s304><adjust.anpassen><en> SEMIKRON expressly reserves the right to adjust prices for 2019 deliveries.
<G-vec00095-002-s305><adjust.anpassen><de> Bei Vertragslaufzeiten von länger als einem Jahr behält info-key sich das Recht vor, die Höhe der jährlichen Gebühr nach einer Preisbindung von einem Jahr anzupassen.
<G-vec00095-002-s305><adjust.anpassen><en> For contract terms longer than one year, info-key reserves the right to adjust the annual license fee after one year of fixed pricing.
<G-vec00095-002-s306><adjust.anpassen><de> Consel Group AG behält sich das Recht vor, die Preise jederzeit ohne Vorankündigung anzupassen.
<G-vec00095-002-s306><adjust.anpassen><en> Consel Group AG reserves the right to adjust prices at any time without prior notice.
<G-vec00095-002-s307><adjust.anpassen><de> Tippen Sie einfach auf das Display, um die Belichtung anzupassen.
<G-vec00095-002-s307><adjust.anpassen><en> Just tap on the screen to adjust exposure.
<G-vec00095-002-s308><adjust.anpassen><de> Navigiere in der Zeitachse von Audiodateien einfach mittels dem Projektcursor und füge Ein- / Ausblendpunkte an genauen Stellen hinzu, um die Lautstärke oder den Schwenk dem Audio anzupassen.
<G-vec00095-002-s308><adjust.anpassen><en> Navigate the timeline of your audio files easily using the project cursor, and add fade points at precise locations to adjust volume or to pan the audio.
<G-vec00095-002-s309><adjust.anpassen><de> Wir behalten uns das Recht vor, die Preise für unsere Kostenpflichtigen Services oder Bestandteile derselben jederzeit und in jeder Hinsicht anzupassen.
<G-vec00095-002-s309><adjust.anpassen><en> We reserve the right to adjust pricing for our Paid Services or any components thereof in any manner and at any time.
<G-vec00095-002-s310><adjust.anpassen><de> Selbstverständlich verfügt die HC MK3 PRO Haldexsteuerung über ein Rundstreckenprogramm, das es ermöglicht, die Fahrdynamik des Fahrzeugs zu beeinflussen und um die Leistungsverteilung optimal auf die jeweilige Rennstrecke anzupassen.
<G-vec00095-002-s310><adjust.anpassen><en> Of course, the CRC Performance HC MK3 PRO Haldex controller has got a racetrack mode enabling it to take an influence on vehicle dynamics and to adjust power distribution to the relevant speedway optimally.
<G-vec00095-002-s311><adjust.anpassen><de> Es war schwierig, die auf dem Markt verfügbaren neuen Platinen an die bereits installierten und an die bestehende Struktur anzupassen.
<G-vec00095-002-s311><adjust.anpassen><en> It was difficult to adjust the new boards available on the market to those already installed and to the existing structure.
<G-vec00095-002-s312><adjust.anpassen><de> Das Vade-SOC nutzt das Feedback, um die Bedrohung zu beseitigen, die heuristischen Regeln anzupassen und unsere Algorithmen für Machine Learning und Computer Vision zu trainieren.
<G-vec00095-002-s312><adjust.anpassen><en> Vade’s SOC uses the feedback to mitigate the threat, adjust heuristic rules, and train our machine learning and computer vision algorithms.
<G-vec00095-002-s313><adjust.anpassen><de> Doppelklicken Sie auf ein Feld, um die Feldeigenschaften anzupassen.
<G-vec00095-002-s313><adjust.anpassen><en> Double-click a field to adjust field properties.
<G-vec00095-002-s314><adjust.anpassen><de> Die individuelle Ausführung und das moderne Design erlauben, die Garage an Ihre Bedürfnisse und Anforderungen anzupassen.
<G-vec00095-002-s314><adjust.anpassen><en> Individual finishes and a modern design allows you to adjust the prefabrication to your personal needs and requirements.
<G-vec00095-002-s315><adjust.anpassen><de> Dadurch können Tumoren und gesunde Gewebe über den Behandlungszeitraum hinweg sehr genau lokalisiert werden, um die Strahlentherapie individuell anzupassen, falls sich der Tumor im Vergleich zur letzten Behandlung verschoben oder in seiner Größe verändert hat.
<G-vec00095-002-s315><adjust.anpassen><en> This makes it possible to localize tumors and healthy tissue very precisely over the whole treatment period in order to adjust radiation therapy individually if the tumor has shifted since the last treatment or if its size has changed.
<G-vec00095-002-s439><adjust.anpassen><de> Dank der werkzeugfreien Fokusoption kann der Benutzer den richtigen Arbeitsabstand entsprechend der Anwendung leicht manuell anpassen.
<G-vec00095-002-s439><adjust.anpassen><en> Thanks to the tool-free focus option, the user can manually adjust the correct working distance.
<G-vec00095-002-s440><adjust.anpassen><de> Analysen Das Buchungssystem für Werksführungen kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s440><adjust.anpassen><en> The Booking System for Amusement Parks and Zoos can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s441><adjust.anpassen><de> Dadurch kann er die Luftleistung an die Intensität der Kochdünste entsprechend anpassen.
<G-vec00095-002-s441><adjust.anpassen><en> The speed of the fan is controlled in 3 stages so you can easily adjust the capacity of the cooker hood to the intensity of cooking fumes.
<G-vec00095-002-s442><adjust.anpassen><de> Das Buchungssystem für Virtual Reality Arenen kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s442><adjust.anpassen><en> The Booking System for Bus Tours can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s443><adjust.anpassen><de> Wenn diese Position ausgewählt wird, wird man andere Optionen entsprechend anpassen müssen.
<G-vec00095-002-s443><adjust.anpassen><en> Colour:Graphite White Choosing this will cause the need to adjust other options.
<G-vec00095-002-s445><adjust.anpassen><de> Wenn bei Ihnen strengere Vorschriften gelten, werden wir unsere Praxis entsprechend anpassen, um sicherzustellen, dass Ihre Daten bei uns sicher sind, egal wo auf der Welt Sie sich befinden.
<G-vec00095-002-s445><adjust.anpassen><en> Where your local rules require more from us than that, we will adjust our practice to make sure your data is safe with us no matter where in the world you are!
<G-vec00095-002-s447><adjust.anpassen><de> Das Buchungssystem für Bubble Soccer kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s447><adjust.anpassen><en> The Booking System for Bubble Soccer can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s448><adjust.anpassen><de> Sie können Ihre E-Mail-Einstellungen entsprechend anpassen, wenn Sie keine E-Mails oder andere Post von uns erhalten wollen.
<G-vec00095-002-s448><adjust.anpassen><en> If you do not want to receive e-mail or other mail from us, please use our User Administration pages to adjust your preferences.
<G-vec00095-002-s450><adjust.anpassen><de> Das Buchungssystem für geführte Touren kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s450><adjust.anpassen><en> The Booking System for Events can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s451><adjust.anpassen><de> Das Buchungssystem für Wassersport kann Ihre Verkäufe und Kundendaten analysieren, sodass Sie Ihre Angebote entsprechend anpassen können.
<G-vec00095-002-s451><adjust.anpassen><en> The Booking System for Trampoline Halls can analyze your sales and customer data so you can adjust your offers when needed.
<G-vec00095-002-s452><adjust.anpassen><de> Die MTU beobachtet mögliche Auswirkungen der Coronavirus-Problematik und wird ihre Prognose im Jahresverlauf gegebenenfalls entsprechend anpassen.
<G-vec00095-002-s452><adjust.anpassen><en> MTU is observing the potential impact of the coronavirus issue and will, if necessary, adjust its forecast in the course of the year.
<G-vec00095-002-s453><adjust.anpassen><de> Darüber hinaus überzeugt SMARTCRM 19.1 mit neuer Funktionalität: So können User Ihren persönlichen Startbildschirm, das SMART Board, dank der variablen Spaltenanzahl noch individueller gestalten und den eigenen Bedürfnissen entsprechend anpassen.
<G-vec00095-002-s453><adjust.anpassen><en> In addition, SMARTCRM 19.1 scores with new functionalities: users can personalize their own start screen, the SMART Board, using the variable number of columns and adjust it to their proper needs.
<G-vec00095-002-s454><adjust.anpassen><de> • Sie können Ihr Benutzerkonto entsprechend anpassen, wenn Sie keine E-Mails oder andere Post von uns erhalten wollen.
<G-vec00095-002-s454><adjust.anpassen><en> If you do not want to receive e-mail or other mail from us, please adjust your Customer Communication Preferences.
<G-vec00095-002-s456><adjust.anpassen><de> Lampa Wenn diese Position ausgewählt wird, wird man andere Optionen entsprechend anpassen müssen.
<G-vec00095-002-s456><adjust.anpassen><en> Lampa Choosing this will cause the need to adjust other options.
<G-vec00095-002-s457><adjust.anpassen><de> In diesen Fällen wird Ciuvo auch die Hinweise zum Datenschutz entsprechend anpassen.
<G-vec00095-002-s457><adjust.anpassen><en> In these cases Ciuvo will also adjust the details of the terms and privacy policy.
<G-vec00095-002-s533><adjust.anpassen><de> Passe die Zauberstab-Einstellungen an.
<G-vec00095-002-s533><adjust.anpassen><en> Adjust the magic-wand settings.
<G-vec00095-002-s534><adjust.anpassen><de> Für den Geschmackstest passe ich meine Ausrüstung an, um einen lauwarmen Dampf und einen korrekten Dampf zu erhalten.
<G-vec00095-002-s534><adjust.anpassen><en> For the taste test, I choose to adjust my equipment to obtain a lukewarm vape and a correct vapor.
<G-vec00095-002-s535><adjust.anpassen><de> Passe den Schwierigkeitsgrad an oder verleihe dir selbst mehr Leben, um jedes Spiel komplett durchspielen zu können.
<G-vec00095-002-s535><adjust.anpassen><en> Adjust your difficulty settings or give yourself more lives to battle through each game in its entirety.
<G-vec00095-002-s536><adjust.anpassen><de> Passe die Frequenz an, um die Resonanzspitze herauszufinden.
<G-vec00095-002-s536><adjust.anpassen><en> Adjust the frequency to find the resonance peak.
<G-vec00095-002-s537><adjust.anpassen><de> Gib deinem Vlog einen Titel und eine Beschreibung, passe ihn an deine bevorzugte Qualität an, wähle Kategorie und Datenschutz und klicke dann auf die Schaltfläche „Export“.
<G-vec00095-002-s537><adjust.anpassen><en> Give a title and description to your vlog, adjust to your preferred quality, and select category and privacy then hit on "Export" button.
<G-vec00095-002-s538><adjust.anpassen><de> Erinnere dich daran, wie dein Mobile aussah, bevor du angefangen hast, damit zu experimentieren und passe die Breite und Länge in den Kacheln an, um die Größe anzupassen.
<G-vec00095-002-s538><adjust.anpassen><en> Remember what your mobile looked like before you started experimenting with it and adjust the width and length in the tiles to resize it.
<G-vec00095-002-s539><adjust.anpassen><de> Bitte passe die tägliche Futtermenge dementsprechend an und stelle bitte immer frisches Trinkwasser zur Verfügung.
<G-vec00095-002-s539><adjust.anpassen><en> Please adjust the daily feed amount accordingly and please always provide fresh drinking water.
<G-vec00095-002-s540><adjust.anpassen><de> Probiere die Kette und passe sie nach Bedarf an.
<G-vec00095-002-s540><adjust.anpassen><en> Try on the necklace and adjust it as needed.
<G-vec00095-002-s541><adjust.anpassen><de> Deine Locken beginnen dort, wo das Stirnband sitzt, also passe es an, je nachdem, wie deine Locken aussehen sollen.
<G-vec00095-002-s541><adjust.anpassen><en> Your curls will start where the headband sits, so adjust it based on how you want your curls to look.
<G-vec00095-002-s542><adjust.anpassen><de> Passe deine Haarfarbe an, um deinen Teint hervorzubringen.
<G-vec00095-002-s542><adjust.anpassen><en> Adjust your hair color to bring out your complexion.
<G-vec00095-002-s543><adjust.anpassen><de> Schnelle Lösung: passe Deine BH-Träger an und lockere sie.
<G-vec00095-002-s543><adjust.anpassen><en> Quick fix: adjust your bra straps and loosen them.
<G-vec00095-002-s544><adjust.anpassen><de> Wähle dein Tablet-Modell und den Handyhüllentyp, lade anschließend ein Bild hoch und passe es an.
<G-vec00095-002-s544><adjust.anpassen><en> Choose your tablet model and case type, upload a photo and adjust it, then check-out.
<G-vec00095-002-s545><adjust.anpassen><de> Wenn Du nicht möchtest, dass wir deinen Computer wiedererkennen, dann passe bitte deine Browsereinstellung an um automatisch alle Cookies zu blockieren oder löschen oder Dich zu warnen bevor dein Browser einen Cookie speichert.
<G-vec00095-002-s545><adjust.anpassen><en> If you don’t want us to recognize your computer, please adjust your browser settings to delete or block all cookies or to warn you before saving a cookie.
<G-vec00095-002-s546><adjust.anpassen><de> Passe das Display an, um auf jeder Seite bis zu 8 Datenfelder anzuzeigen.
<G-vec00095-002-s546><adjust.anpassen><en> Adjust the display to display up to 8 data fields on each page.
<G-vec00095-002-s547><adjust.anpassen><de> Wenn einige Zweige dunkler oder heller als andere erscheinen, passe die Lichter an, hole sie mehr heraus oder verstecke sie etwas im Grün, um zu dimmen.
<G-vec00095-002-s547><adjust.anpassen><en> If some branches seem dimmer or brighter than others, adjust the lights as necessary, bringing them out to pop or nestling them in to be a bit dimmer.
<G-vec00095-002-s548><adjust.anpassen><de> {Passe mit dem Schieberegler "Ecken" an, wie abgerundet die Ecken sein werden.
<G-vec00095-002-s548><adjust.anpassen><en> Use the "Corners" slider to adjust how rounded your corners will be.
<G-vec00095-002-s549><adjust.anpassen><de> Passe die Deckstärke der einzelnen Elemente an, indem du auf den Pfeil nach unten klickst und den Schieberegler für die Transparenz einstellst.
<G-vec00095-002-s549><adjust.anpassen><en> Adjust each design element’s opacity by clicking on the down arrow and adjusting the transparency slider.
<G-vec00095-002-s550><adjust.anpassen><de> Wenn du in der Nacht nicht geweckt werden willst, deaktiviere die automatische Zeitanpassung auf dem Smartphone am Abend bevor die Zeitumstellung erfolgt und passe die Zeit am nächsten Morgen manuell an.
<G-vec00095-002-s550><adjust.anpassen><en> If you do not want to be awakened at night, deactivate the automatic daylight saving time changeover on the mobile phone in the evening before the time changeover and adjust the times manually the next morning.
<G-vec00095-002-s551><adjust.anpassen><de> Mein Dienstleistungsportfolio passe ich auf Wunsch für meine Agenturkunden grafisch so an, dass es auf Ihr CI abgestimmt ist (farblich und mit Logo).
<G-vec00095-002-s551><adjust.anpassen><en> Upon request, I adjust my service portfolio graphically for my agency clients so that it is tailored to your CI (colour and logo).
<G-vec00095-002-s552><adjust.anpassen><de> Passe die Federkonstanten deines Motorrads, den Reifendruck und die Beschleunigung an.
<G-vec00095-002-s552><adjust.anpassen><en> Adjust your motorbike's spring constants, tire pressure, and acceleration.
<G-vec00095-002-s553><adjust.anpassen><de> Passe manuell die Helligkeit unter bestimmten Umgebungsbedingungen an.
<G-vec00095-002-s553><adjust.anpassen><en> Manually adjust your brightness for certain conditions.
<G-vec00095-002-s554><adjust.anpassen><de> Passe das Foto an und lege es nach Belieben auf die Hülle.
<G-vec00095-002-s554><adjust.anpassen><en> Adjust the photo and place it on the case until it looks exactly as you have been envisioning it.
<G-vec00095-002-s555><adjust.anpassen><de> Passe die allgemeine Qualität der Shader an.
<G-vec00095-002-s555><adjust.anpassen><en> Adjust the overall quality of shaders.
<G-vec00095-002-s556><adjust.anpassen><de> Wenn du siehst, was wirklich passiert, passe deine Handlungen oder Reaktionen so gut wie möglich an.
<G-vec00095-002-s556><adjust.anpassen><en> As you see what really does transpire, adjust your actions or responses as best as you can.
<G-vec00095-002-s557><adjust.anpassen><de> Halte das Verhältnis von Butter und Wasser gleich und passe einfach die Menge des Marihuanas an, das du hinein mahlst.
<G-vec00095-002-s557><adjust.anpassen><en> Keep the butter and water ratio the same and simply adjust the amount of bud you grind in.
<G-vec00095-002-s558><adjust.anpassen><de> Wenn die Erde bei dir alkalisch ist, besorge dir aus dem Gartencenter oder einer Gärtnerei ein pH-Kit und passe den pH-Wert auf 6,1 bis 6,5 an.
<G-vec00095-002-s558><adjust.anpassen><en> If soil in your area is alkaline, adjust it to between 6.1 and 6.5 pH using a garden store pH kit.
<G-vec00095-002-s559><adjust.anpassen><de> Passe dann entweder den Zeitrahmen oder die Ziele selbst an.
<G-vec00095-002-s559><adjust.anpassen><en> Then, adjust either the time frame or your goals themselves.
<G-vec00095-002-s560><adjust.anpassen><de> Passe ein bisschen an, prüfe und passe weiter an.
<G-vec00095-002-s560><adjust.anpassen><en> Adjust a little bit, check, and adjust
<G-vec00095-002-s561><adjust.anpassen><de> • Passe den Stil deines Titels, Text oder Satzzeichen ganz einfach an oder füge Emoji hinzu.
<G-vec00095-002-s561><adjust.anpassen><en> • Easily change the style of your title, adjust text and punctuation, or add inline emoji
<G-vec00095-002-s562><adjust.anpassen><de> Passe das Bild an.
<G-vec00095-002-s562><adjust.anpassen><en> Adjust the image.
<G-vec00095-002-s563><adjust.anpassen><de> Inseriere dein Logo, ändere die Maße und passe sie an die von dir gewählten Linien an.
<G-vec00095-002-s563><adjust.anpassen><en> Add your logo, decide sizes and position and adjust it to the items you have chosen.
<G-vec00095-002-s564><adjust.anpassen><de> Wenn dein CPA zu hoch ist, passe dein Gebot pro Seite an, bevor du mehrere Seiten auf einmal pausierst.
<G-vec00095-002-s564><adjust.anpassen><en> Adjust your bid per site before blocking specific sites altogether if your CPA is high.
<G-vec00095-002-s565><adjust.anpassen><de> Passe die Raumtemperatur an.
<G-vec00095-002-s565><adjust.anpassen><en> Adjust the room temperature.
<G-vec00095-002-s566><adjust.anpassen><de> Passe deine Zimmertemperatur an.
<G-vec00095-002-s566><adjust.anpassen><en> Adjust your room temperature.
<G-vec00095-002-s567><adjust.anpassen><de> Ob Anfänger oder Fortgeschrittener - wir passen die Trainingsbelastung an Ihren individuellen Trainingsstand an.
<G-vec00095-002-s567><adjust.anpassen><en> Beginner or advanced? we adjust the training to your individual fitness level.
<G-vec00095-002-s568><adjust.anpassen><de> Abhängig von der Applikationsgeschwindigkeit, dem Materialfluss und dem benötigten Durchmesser der Swirlapplikation passen wir die Parameter der Spritzpistole und des gesamten Systems an.
<G-vec00095-002-s568><adjust.anpassen><en> Depending on the application speed, the material flow, the diameter required of swirl bead, we adjust the parameters of the gun and the complete system behind. typical Layout
<G-vec00095-002-s569><adjust.anpassen><de> Wenn sich die Rahmenbedingungen ändern, passen wir die Suche pragmatisch an.
<G-vec00095-002-s569><adjust.anpassen><en> If circumstances change, we adjust our efforts to meet your new requirements.
<G-vec00095-002-s570><adjust.anpassen><de> Auch diesen Graphen übernehmen wir in unseren Report (hierzu können wir jetzt den Reportnamen in der Auswahl anklicken), passen die Zeitachse entsprechend an und geben der Box einen Titel.
<G-vec00095-002-s570><adjust.anpassen><en> We add this graph to our report (we can now simply click on the report name in the report-selection), adjust the time axis accordingly and give the box a title.
<G-vec00095-002-s571><adjust.anpassen><de> Wir passen die Sicherheit immer an die gesetzlichen Anforderungen an.
<G-vec00095-002-s571><adjust.anpassen><en> We always adjust the security in accordance with the legal requirements.
<G-vec00095-002-s572><adjust.anpassen><de> Um das Verhältnis der Überlappung zwischen Events zu ändern, passen Sie im Dialogfeld-Abschnitt Konvertierung für Cutüberschneidung die Einstellung Verhältnis an.
<G-vec00095-002-s572><adjust.anpassen><en> To change the amount of overlap between events, adjust the Amount setting in the Cut-to-overlap conversion section of the dialog.
<G-vec00095-002-s573><adjust.anpassen><de> Wir passen jedes UV-Konverterrohr an die zugehörige BEAMAGE-Kamera an.
<G-vec00095-002-s573><adjust.anpassen><en> We adjust each UV converter tube to its associated BEAMAGE camera.
<G-vec00095-002-s574><adjust.anpassen><de> (2) Ratifiziert ein AKP-Staat dieses Abkommen nicht oder kündigt er es, so passen die Vertragsparteien die im Finanzprotokoll in Anhang I vorgesehenen Beträge an.
<G-vec00095-002-s574><adjust.anpassen><en> 2. Should an ACP State fail to ratify this Agreement or denounce it, the Parties shall adjust the amounts of the resources provided for in the Financial Protocol set out in Annex I. Adjustment of the financial resources shall also apply upon:
<G-vec00095-002-s575><adjust.anpassen><de> In diesem Fall zählen wir die Wörter und passen die Kosten an.
<G-vec00095-002-s575><adjust.anpassen><en> If this is the case, we will do the word count and adjust for the fee.
<G-vec00095-002-s576><adjust.anpassen><de> Mit dem von uns entwickelten „StyleEdit“ passen Sie Ihren Shop ohne Programmierkenntnisse nach Ihren Vorstellungen an.
<G-vec00095-002-s576><adjust.anpassen><en> With our self-developed "StyleEdit" you can adjust your shop according to your wishes and needs without any programming skills.
<G-vec00095-002-s577><adjust.anpassen><de> Unsere Gebäude passen sich veränderten Nutzeranforderungen an.
<G-vec00095-002-s577><adjust.anpassen><en> Our buildings adjust to changed user requirements.
<G-vec00095-002-s578><adjust.anpassen><de> Unsere Trainer sind nicht nur Experten der Buiness Analyse, sie erkennen auch die Unterschiede im Lernstil und passen den Prozess des Kompetenztransfers an die Bedürfnisse jedes einzelnen Kunden an.
<G-vec00095-002-s578><adjust.anpassen><en> Beyond being experts in business analysis, our coaches are aware of learning style differences and adjust the skills transfer process to fit the needs of each person.
<G-vec00095-002-s579><adjust.anpassen><de> Passen zum heutigen Rumstag kann ich Euch mein Ergebnis präsentieren.
<G-vec00095-002-s579><adjust.anpassen><en> Adjust the present Rumstag I can present you my result.
<G-vec00095-002-s580><adjust.anpassen><de> Ändern Sie die Zahnräder mit der Space-Taste, passen Sie die Winkel der Sprung mit der Leertaste.
<G-vec00095-002-s580><adjust.anpassen><en> Change the gears with the space key, adjust your angle of the jump with the spacebar.
<G-vec00095-002-s581><adjust.anpassen><de> Wenn gewünscht, passen wir Ihr Wasserbett auch so an, dass es in Ihr Bettgestell passt.
<G-vec00095-002-s581><adjust.anpassen><en> If you wish, we can adjust your waterbed to fit into your existing bed frame.
<G-vec00095-002-s582><adjust.anpassen><de> Wir passen die Datenschutzerklärung an, sobald die Änderungen der von uns durchgeführten Datenverarbeitungen dies erforderlich machen.
<G-vec00095-002-s582><adjust.anpassen><en> We will adjust the privacy policy as soon as there are changes in the data processing required.
<G-vec00095-002-s583><adjust.anpassen><de> Diese lassen sich ganz einfach über das Bedienfeld des Kochfeldes steuern und passen ihre Leistung automatisch der Wärmebildung des Kochfeldes an.
<G-vec00095-002-s583><adjust.anpassen><en> These can be easily controlled via the hob operating panel and automatically adjust their output to the amount of heat generated by the hob.
<G-vec00095-002-s584><adjust.anpassen><de> Dann müssen Sie flexibel sein und passen ihre Pläne.
<G-vec00095-002-s584><adjust.anpassen><en> Then you need to be flexible and adjust their plans.
<G-vec00095-002-s585><adjust.anpassen><de> Die oberen Aktivpunkte (nur im Modus „Manuell“ verfügbar) passen die Toleranz (Kerntransparenz) an, die der Luma-Kanal zur Stanzmaske beiträgt.
<G-vec00095-002-s585><adjust.anpassen><en> The upper handles (which appear only in Manual mode) adjust the tolerance (core transparency) of the luma channel’s contribution to the key.
<G-vec00095-002-s586><adjust.anpassen><de> Genuss ohne Kompromisse: Wählen Sie Ihre Kaffeestärke und Temperatur: Mit einer einzigen Drehung passen Sie außerdem die Kaffeemenge an die bevorzugte Tassengröße (30 - 220 ml) an.
<G-vec00095-002-s586><adjust.anpassen><en> Indulgence without compromise: you choose your coffee strength and the temperature. Added to that, one single rotation is all it takes to adjust the amount of coffee to the preferred cup size.
<G-vec00095-002-s587><adjust.anpassen><de> Passen Sie in Zukunft den Adapter und die Werkzeugköpfe doch einfach Ihrer gewünschten Arbeitsposition an, denn diese sind ab sofort um 360° drehbar.
<G-vec00095-002-s587><adjust.anpassen><en> In the future you will be able to adjust the adapter and the tool heads to your required working position, as they are now rotatable by 360°.
<G-vec00095-002-s588><adjust.anpassen><de> Je nach Anwendungszweck wählen Sie eine vorgestaltete Kampagne aus, passen die Vorlagen nach Ihren Wünschen an und laden Ihre Adressdaten hoch – fertig.
<G-vec00095-002-s588><adjust.anpassen><en> Depending on the goals and objectives, you simply select a pre-defined template, adjust the template according to your needs and upload your addresses – done.
<G-vec00095-002-s589><adjust.anpassen><de> Nutzen Sie dafür eines der folgenden Beispiele und passen diese auf Ihre Bedürfnisse an.
<G-vec00095-002-s589><adjust.anpassen><en> Use one of the following examples and adjust them to your needs.
<G-vec00095-002-s590><adjust.anpassen><de> Als erstes passen wir die Voreinstellungen an.
<G-vec00095-002-s590><adjust.anpassen><en> First of we adjust our project settings.
<G-vec00095-002-s591><adjust.anpassen><de> Die Eingabemasken (Informationsfelder) passen sich jedem dieser spezifischen Anlageinstrumenten an.
<G-vec00095-002-s591><adjust.anpassen><en> The masks for the feeding in process (information fields) adjust themselves to any of these specific investment instruments.
<G-vec00095-002-s592><adjust.anpassen><de> Je nach Situation passen die Audi Matrix LED-Scheinwerfer die Lichtverteilung Ihres Audi TT Roadster optimal an.
<G-vec00095-002-s592><adjust.anpassen><en> The Audi Matrix LED headlights can adjust the light distribution from your Audi RS 6 Avant to perfection, depending on the situation.
<G-vec00095-002-s593><adjust.anpassen><de> Um dir den optimalen Versicherungsschutz zu garantieren, passen wir unsere Versicherungspakete individuell an deine Lebenssituation, Wünsche und Vorstellungen an.
<G-vec00095-002-s593><adjust.anpassen><en> To guarantee you the best possible insurance protection, we adjust our insurance packages individually to your life situation, needs and preferences.
<G-vec00095-002-s594><adjust.anpassen><de> Wir streben ständig nach Perfektion und passen deshalb für jedes Projekt die Spezifikationen an, um die Anforderungen, die sich aus der spezifischen Benutzung Ihres Bootes oder Schiffes ergeben, zu erfüllen.
<G-vec00095-002-s594><adjust.anpassen><en> We always aim for perfection and will therefore adjust the specifications for each project, to suit the requirements for the work to be performed on the vessel.
<G-vec00095-002-s595><adjust.anpassen><de> Wir stimmen das Design mit Ihnen ab und passen dieses entsprechend an.
<G-vec00095-002-s595><adjust.anpassen><en> We discuss the design with you and adjust it accordingly.
<G-vec00095-002-s597><adjust.anpassen><de> Wir passen Ihre Dokumentationswerkzeuge an Ihre Anforderungen an und entwickeln Lösungen für die Publikation Ihrer Inhalte auf Web-Portalen oder als App.
<G-vec00095-002-s597><adjust.anpassen><en> Developing. We adjust your documentation tools according to your needs and develop publishing solutions for web portals or apps.
<G-vec00095-002-s598><adjust.anpassen><de> Deckungsgrad-Hüllkurven passen die Transparenz eines Events an und ermöglichen es, das Event vor einem Hintergrund einzublenden.
<G-vec00095-002-s598><adjust.anpassen><en> Opacity envelopes adjust the transparency of an event, allowing it to fade in over a background.
<G-vec00095-002-s599><adjust.anpassen><de> Gern passen wir unsere Öffnungszeiten nach Absprache Ihren Wünschen an.
<G-vec00095-002-s599><adjust.anpassen><en> We are happy to adjust our opening times at negotiable your wishes.
<G-vec00095-002-s600><adjust.anpassen><de> Während des Spieltrainings planen Ihre Mitarbeiter die Aktivitäten ihres Unternehmens oder ihrer Einheiten, analysieren Märkte und Aktivitäten von Wettbewerbern, passen Prozesse an und optimieren sie, konkurrieren, kooperieren und handeln nicht nur mit dem Computer, sondern untereinander.
<G-vec00095-002-s600><adjust.anpassen><en> During the game training, your employees plan the activities of their business or units, analyze the markets and activities of competitors, adjust and optimize processes, compete, cooperate, trade not only with the computer, but with each other.
<G-vec00095-002-s601><adjust.anpassen><de> Wir befragen unsere Lieferanten regelmäßig nach Verbesserungsvorschlägen und passen WE kontinuierlich an die Bedürfnisse der Beschäftigten an.
<G-vec00095-002-s601><adjust.anpassen><en> Through regular surveys of our suppliers, we continuously adjust the WE Programme to meet the needs of workers.
<G-vec00095-002-s602><adjust.anpassen><de> Wenn Sie nicht möchten, dass wir personenbezogene Daten verwenden, die wir Dritten zur Verfügung stellen, um Anzeigen, die wir Ihnen zeigen, zu personalisieren, passen Sie bitte Ihre Werbepräferenzen an.
<G-vec00095-002-s602><adjust.anpassen><en> If you do not want us to use personal information that we gather to allow third parties to personalize advertisements we display to you, please adjust your Advertising Preferences .
<G-vec00095-002-s603><adjust.anpassen><de> Sie gehen an die Geschichte mit einer vorgefassten Meinung heran und passen die Beweise entsprechend an.
<G-vec00095-002-s603><adjust.anpassen><en> They approach history with a preconceived notion and then adjust the evidence accordingly.
<G-vec00095-002-s604><adjust.anpassen><de> Wir unterliegen keiner strikten Einschränkung durch das modulare System, sondern passen die Förderanlage konstruktionell Ihren Bedürfnissen genau an.
<G-vec00095-002-s604><adjust.anpassen><en> We are not strictly limited by a modular system, we can adjust the design of a conveyor exactly as you need.
<G-vec00095-002-s605><adjust.anpassen><de> Passen Sie die Einstellungen für Ihr neues Passwort an und kopieren Sie es dann in die Zwischenablage oder füllen Sie es auf der Seite aus.
<G-vec00095-002-s605><adjust.anpassen><en> Adjust the settings for your new password, then copy it to the clipboard or fill it on the page.
<G-vec00095-002-s606><adjust.anpassen><de> Um Bildwasserzeichen hinzuzufügen, klicken Sie bitte auf „Bildwasserzeichen hinzufügen“, wählen Sie ein Bild aus dem geöffneten Dialog aus und passen Sie die Einstellungen an.
<G-vec00095-002-s606><adjust.anpassen><en> To add picture watermark, please click "Add Picture Watermark" button, and choose a picture in the dialog that opens, and adjust the settings below.
<G-vec00095-002-s607><adjust.anpassen><de> Passen Sie die Geschwindigkeit des Schlittens.
<G-vec00095-002-s607><adjust.anpassen><en> Adjust the speed of the slide.
<G-vec00095-002-s608><adjust.anpassen><de> Solange Sie mit dem Synchronlauf nicht zufrieden sind, passen Sie den Korrekturverlauf durch wohlüberlegtes Setzen weiterer Splinemarker an.
<G-vec00095-002-s608><adjust.anpassen><en> As long as you are not contented with the synchronous run, adjust the correction course by well-considered defining of additional Spline markers.
<G-vec00095-002-s609><adjust.anpassen><de> Erhöhen Sie die Wirkung Ihrer Videospuren und passen Sie die Deckkraft eines Videoclips an, damit mehrere Clips gleichzeitig zu sehen sind; erzeugen Sie Überlagerungs- und eigene Ein- und Ausblendeffekte.
<G-vec00095-002-s609><adjust.anpassen><en> Add impact to your video tracks and adjust the opacity of a video clip, so you can see multiple clips at the same time, create superimposed effects or custom fade-in / fade-out transitions.
<G-vec00095-002-s610><adjust.anpassen><de> Farbton vs. Sättigung –Passen Sie die Sättigung der Pixel in einem ausgewählten Farbtonbereich an.
<G-vec00095-002-s610><adjust.anpassen><en> Hue versus Saturation - Adjust the saturation of pixels in a selected hue range.
<G-vec00095-002-s611><adjust.anpassen><de> Fügen Sie den Comic-Filter hinzu, und passen Sie ihn im Informationsfenster oder in der Schwebepalette an.
<G-vec00095-002-s611><adjust.anpassen><en> You can add the Comic filter, then adjust it in the inspector or the heads-up display (HUD).
<G-vec00095-002-s612><adjust.anpassen><de> Passen Sie die Datumsangaben in den Spalten Startdatum und Fälligkeitsdatum gemäß den Beziehungen zwischen den Aufgaben an.
<G-vec00095-002-s612><adjust.anpassen><en> Adjust the dates in the Start Date and Due Date columns to reflect the relationships between the tasks.
<G-vec00095-002-s613><adjust.anpassen><de> Passen Sie Ihre Gebote auf der Grundlage des Ankunftstags im Hotel an.
<G-vec00095-002-s613><adjust.anpassen><en> Adjust your bids based on the day of check in at the hotel.
<G-vec00095-002-s614><adjust.anpassen><de> Passen Sie die Anzahl der Farben im Nachzeichnerergebnis an, wenn als Modus „Farbe“ festgelegt wurde.
<G-vec00095-002-s614><adjust.anpassen><en> Adjust the number of colors in the tracing result when Mode is set to Color. Grays
<G-vec00095-002-s615><adjust.anpassen><de> Passen Sie zunächst Helligkeit an und anschließend, falls erforderlich, den Kontrast.
<G-vec00095-002-s615><adjust.anpassen><en> Adjust Brightness first, then adjust Contrast only if further adjustment is necessary.
<G-vec00095-002-s616><adjust.anpassen><de> Passen Sie die Einstellung des Verbindungsparameters CompressionThreshold an.
<G-vec00095-002-s616><adjust.anpassen><en> Adjust the CompressionThreshold setting.
<G-vec00095-002-s617><adjust.anpassen><de> Optimieren Sie Bilder mit nur einem Klick oder passen Sie Dinge wie Helligkeit, Kontrast, Sättigung, Foto-Temperatur, Farbtonregelung u.v.m.
<G-vec00095-002-s617><adjust.anpassen><en> Optimize images with a click or adjust brightness, contrast, saturation, photo temperature, hue control etc.
<G-vec00095-002-s618><adjust.anpassen><de> Optional: Wechseln Sie in den Reiter Template und passen Sie die Versanddauer an, indem Sie die Anzahl der Tage ändern (standardmäßig 10).
<G-vec00095-002-s618><adjust.anpassen><en> Optional: In the Body tab, change and adjust the sending time by changing the number of days. —Image—
<G-vec00095-002-s619><adjust.anpassen><de> Legen Sie den Ring auf den Bildschirm und passen Sie den Kreis an, bis er mit dem inneren Umriss des Ringes übereinstimmt.
<G-vec00095-002-s619><adjust.anpassen><en> Place your borrowed ring on the screen and adjust the circle until it aligns with the inner outline of the ring.
<G-vec00095-002-s620><adjust.anpassen><de> Passen Sie die Einstellungen für den Proxyserver im Programm, wenn Sie einen Proxyserver für den Internetzugriff verwenden.
<G-vec00095-002-s620><adjust.anpassen><en> If your computer is connected to the Internet via the proxy server, adjust proxy server settings in the product.
<G-vec00095-002-s621><adjust.anpassen><de> Wenn dies zu einem abgehackten Sound führt, passen Sie den Prozentsatz an, um ein Gleichgewicht zwischen den beiden Effekten herzustellen.
<G-vec00095-002-s621><adjust.anpassen><en> If doing so produces a choppy sound, adjust the percentage to strike a balance between choppiness and chorusing.
<G-vec00095-002-s622><adjust.anpassen><de> Passen Sie über das Drop-down-Menü den Zeitraum an, um ältere Daten einzubeziehen.
<G-vec00095-002-s622><adjust.anpassen><en> To view previous invoices, adjust the date range using the drop-down menu.
<G-vec00095-002-s623><adjust.anpassen><de> Passen Sie die iGO Camper & Truck Navisoftware Ihrem Wohnmobil an und hinterlegen Sie Ihre Fahrzeugparameter.
<G-vec00095-002-s623><adjust.anpassen><en> Adjust the iGO navigation software for campers to your RV and adjust your vehicle parameters.
<G-vec00095-002-s624><adjust.anpassen><de> ● Doppelter Knopf passt Luftvolumen, Temperatur und digitale visuelle Anzeige für präzise Steuerung.
<G-vec00095-002-s624><adjust.anpassen><en> Knob adjust air volume, digital display air volume gear, realize precise control.
<G-vec00095-002-s625><adjust.anpassen><de> Wenn Sie bei der Installation oder beim Ändern von Einstellungen eine ungenaue Übersetzung bemerken oder wenn die Übersetzung nicht zum Kontext passt, machen Sie sich Notizen zu der Übersetzung und wo Sie sie gefunden haben, um sie möglichst bald zu korrigieren.
<G-vec00095-002-s625><adjust.anpassen><en> If at the moment of an installation or modification of the adjustments of SME Server it detects an inexact translation or that one does not adjust to the context, please, takes note precise from the same one and in where it found it, soon to correct it.
<G-vec00095-002-s626><adjust.anpassen><de> Man füttert sie mit einem bestimmten Input und passt die Verbindungen zwischen den Neuronen so an, dass am Ende „hochwahrscheinlich“ der gewünschte Output erscheint.
<G-vec00095-002-s626><adjust.anpassen><en> You enter certain input into them and adjust the connections among the neurons in such a way that the desired output will “most probably” appear in the end.
<G-vec00095-002-s627><adjust.anpassen><de> Der Gehäuselüfter des SFX Pro passt die Lüftergeschwindigkeit automatisch an die Temperatur des Netzteils an.
<G-vec00095-002-s627><adjust.anpassen><en> SFX Pro’s sleeve fan will automatically adjust its fan speed according to the PSU’s temperature.
<G-vec00095-002-s628><adjust.anpassen><de> Photoshop passt sich auf der Grundlage euer Windows-Einstellungen automatisch an, wodurch das Setup ein Kinderspiel wird.
<G-vec00095-002-s628><adjust.anpassen><en> Photoshop will now automatically adjust itself based on your Windows settings, making it simple to set up.
<G-vec00095-002-s629><adjust.anpassen><de> Die intelligente Beleuchtung lernt die Nutzung der Räume und passt die Beleuchtung entsprechend an.
<G-vec00095-002-s629><adjust.anpassen><en> Intelligent lighting learns how you use the premises and adjust the lighting according to it.
<G-vec00095-002-s630><adjust.anpassen><de> (1) Die zuständige Behörde des ersuchten Mitgliedstaats passt, sofern und soweit erforderlich, die faktischen Elemente der Schutzmaßnahme an, um der Schutzmaßnahme in diesem Mitgliedstaat Wirkung zu verleihen.
<G-vec00095-002-s630><adjust.anpassen><en> 1. The competent authority of the Member State addressed shall, where and to the extent necessary, adjust the factual elements of the protection measure in order to give effect to the protection measure in that Member State.
<G-vec00095-002-s631><adjust.anpassen><de> Die Entscheidung fällt auf die Karlsruher Unternehmenssoftware, nicht nur, weil sie von der Leistungsfähigkeit ideal zur Betriebsgröße passt, sondern vor allem aufgrund des Funktionsumfangs, der schon im Standard weitestgehend zum Blechbearbeitungsbetrieb passt und darüber hinaus umfangreiche Möglichkeiten bietet, eigene Anforderungen umzusetzen.
<G-vec00095-002-s631><adjust.anpassen><en> The decision was made for the Karlsruhe, Germany, based business software not only because the system's scalability was ideal for their growing operation, but also because the function range included in the standard release was a good fit for a sheet metal processing operation while still providing extensive options to adjust the system to their own requirements.
<G-vec00095-002-s632><adjust.anpassen><de> Die Option Freie Transformation ("Freie Transformation")Menü Bearbeiten ("Bearbeiten") passt die Abmessungen des eingefügten Bildes an die Größe der Figur im Foto an.
<G-vec00095-002-s632><adjust.anpassen><en> The option Free Transform ("Free Transformation")menu Edit ("Edit") adjust the dimensions of the inserted image to the size of the figure in the photo.
<G-vec00095-002-s633><adjust.anpassen><de> Sollte euer Seidentofu in anderen Packungsgrößen kommen, dann benutzt zunächst etwas mehr / weniger Mandelmilch und passt die Menge bei Bedarf später noch an.
<G-vec00095-002-s633><adjust.anpassen><en> If your package sizes differ from my – don’t worry. Just add a little more / less milk and adjust the creaminess later on.
<G-vec00095-002-s634><adjust.anpassen><de> Dieser Regler passt die Anzahl der Beats pro Minute (BPM) an und ist entscheidend, um beide Tracks vor dem Einfügen eines Übergangs auf dasselbe Tempo anzupassen.
<G-vec00095-002-s634><adjust.anpassen><en> This control lets you adjust the number of beats per minute (BPM) and is essential for adjusting both tracks to play at the same speed before making a transition.
<G-vec00095-002-s635><adjust.anpassen><de> Wir übernehmen die Auslegung der Radbremse – die Konstruktion der Bremsscheibe sowie die Auswahl der Bremsbeläge und des Bremssattels – und passt die Radbremse in das Fahrzeugkonzept ein.
<G-vec00095-002-s635><adjust.anpassen><en> We cover the designing of the brake – the construction of the brake disk as well as the selection of the friction layers and the caliper – and adjust the brake into the concept of the vehicle.
<G-vec00095-002-s636><adjust.anpassen><de> Man bestimmt in dem Bild die Hautfarbe und passt den Belichtigungsausgleich und den Weißabgleich an.
<G-vec00095-002-s636><adjust.anpassen><en> Specify a skin color in an image and adjust the exposure and white balance. 1.
<G-vec00095-002-s637><adjust.anpassen><de> Intelligente Geschwindigkeitsregelung Sie stellen die Geschwindigkeit und den Sicherheitsabstand ein und die intelligente Geschwindigkeitsregelung passt Ihre Geschwindigkeit automatisch dem Verkehrsfluss an.
<G-vec00095-002-s637><adjust.anpassen><en> Set your speed and safe following distance, and let Intelligent Cruise Control not only maintain but automatically adjust your speed to adapt to the traffic flow.
<G-vec00095-002-s638><adjust.anpassen><de> Kein Kind freut sich über einen langweilig aussehenden Stuhl, dessen Sitzhöhe nicht zu ihm passt und auf dem es unruhig hin- und herrutschen muss, um eine angenehme Sitzposition zu finden.
<G-vec00095-002-s638><adjust.anpassen><en> No child is pleased with a boring-looking chair with a seat height that doesn’t adjust to them and where they have to slip restlessly back and forth to find a comfortable seating position.
<G-vec00095-002-s639><adjust.anpassen><de> Der mit Klettverschluss verstellbare Gummibund passt für jede Größe.
<G-vec00095-002-s639><adjust.anpassen><en> Elasticated bust with Velcro tab to adjust to any size.
<G-vec00095-002-s640><adjust.anpassen><de> Bei der jeweils eingesetzten Konfiguration reagiert die Anzeige des HMIs (Human Machine Interface) sowie des Tablets auf die geänderte Datenlage und passt dynamisch die notwendigen Dokumentationen automatisch an.
<G-vec00095-002-s640><adjust.anpassen><en> In the particular configuration opted for, the HMI (Human Machine Interface) display and the tablet display react to changes in the data situation and dynamically and automatically adjust the necessary documentation.
<G-vec00095-002-s641><adjust.anpassen><de> Stuttgart, 27.03.2018 - Die Daimler AG passt mit dem Geschäftsjahr 2018 die Bilanzierung an die neuen Standards IFRS 9 und 15 an.
<G-vec00095-002-s641><adjust.anpassen><en> Stuttgart, Mar 27, 2018 - As of financial year 2018, Daimler AG will adjust its financial reporting to comply with the new standards IFRS 9 and 15.
<G-vec00095-002-s642><adjust.anpassen><de> Mit den Tasten spielst du schnell Songs ab, stoppst, wechselst das Lied und passt die Lautstärke an.
<G-vec00095-002-s642><adjust.anpassen><en> Buttons let you quickly play, pause and change songs or adjust the volume.
<G-vec00095-002-s643><adjust.anpassen><de> Passt die Helligkeit der Videoausgabe an (Standard: 0).
<G-vec00095-002-s643><adjust.anpassen><en> Adjust the brightness of the video signal (default: 0).
<G-vec00095-002-s644><adjust.anpassen><de> Gammakorrektur – passt den Weißpunkt an.
<G-vec00095-002-s644><adjust.anpassen><en> Gamma Correction - To adjust the white point.
<G-vec00095-002-s645><adjust.anpassen><de> Die nun von Uvex präsentierte Variotronic setzt auf ein komplett neues Konzept und passt die Gläser innerhalb einer zehntel Sekunde an die vorherrschende Lichtsituation an.
<G-vec00095-002-s645><adjust.anpassen><en> The newly presented Uvex Variotronic is based on a completely new concept whereby the lenses adjust to light conditions within tenths of a second.
<G-vec00095-002-s646><adjust.anpassen><de> Das intelligente Betriebssystem passt die Einstellungen des Gefriertunnels automatisch an.
<G-vec00095-002-s646><adjust.anpassen><en> The intelligent management system will automatically adjust the settings for the freezing tunnel.
<G-vec00095-002-s647><adjust.anpassen><de> CONT (Contrast) Passt den Kontrast des Druckbildes an.
<G-vec00095-002-s647><adjust.anpassen><en> Function CONT (Contrast) Function Adjust the contrast of printing image.
<G-vec00095-002-s648><adjust.anpassen><de> Mit dem integrierten Built-In-Pressure System justiert der Patient den Kompressionsbereich einfach mit einer handlichen Messkarte nach und passt ihn an den verringerten Umfang an.
<G-vec00095-002-s648><adjust.anpassen><en> By using the integrated Built-In-Pressure system and the handy BPS card, the patient can easily adjust the compression range to maintain the therapeutic compression level.
<G-vec00095-002-s649><adjust.anpassen><de> Der Laser passt die Höhe automatisch an die Dicke des Materials an, das Sie schneiden oder gravieren.
<G-vec00095-002-s649><adjust.anpassen><en> The laser will automatically adjust to the correct height based on the thickness of the material you are cutting or engraving.
<G-vec00095-002-s650><adjust.anpassen><de> Falls eine Zeitumstellung auf Ihre gewählte Zeitzone zutrifft, passt Hootsuite die Dashboard-Zeit um 2 Uhr an.
<G-vec00095-002-s650><adjust.anpassen><en> If your selected time zone observes DST, Hootsuite will comply with that observance and adjust the dashboard time at 2am.
<G-vec00095-002-s651><adjust.anpassen><de> Es sind fertige Positionen (Start- und Landung, Essen, Lounge) gespeichert, oder aber der Gast passt es nach Bedarf an.
<G-vec00095-002-s651><adjust.anpassen><en> Prepared positions are saved (for takeoff and landing, eating, lounge) or you can adjust it after your needs.
<G-vec00095-002-s652><adjust.anpassen><de> ReSound verwendet bewährte Technologien, mit denen sich Stimmen in lärmiger Umgebung präzise identifizieren lassen und passt die Einstellungen automatisch an, sodass Sie Sprache klarer hören können, ohne dabei den Kontakt zu anderen Geräuschen zu verlieren.
<G-vec00095-002-s652><adjust.anpassen><en> ReSound uniquely applies proven technologies that can accurately identify voices in noisy backgrounds and automatically adjust settings so that you can hear speech more clearly, but without losing touch with other sounds.
<G-vec00095-002-s653><adjust.anpassen><de> Passt die Lautstärke zwischen dem linken und dem rechten Lautsprecher an.
<G-vec00095-002-s653><adjust.anpassen><en> Adjust the volume from the left and right speaker.
<G-vec00095-002-s654><adjust.anpassen><de> Dank diesem innovativen System erkennt das tragbare Ladegerät automatisch die vom Gerät aufgenommene Höchstleistung und passt sie dementsprechend an.
<G-vec00095-002-s654><adjust.anpassen><en> The Intelligent Charge technology allows this portable charger to automatically recognize the maximum absorbable charging level of your device and adjust it accordingly.
<G-vec00095-002-s655><adjust.anpassen><de> Und damit Sie in jeder Situation den besten Durchblick haben, passt sich die Leuchtstärke auf Wunsch an die jeweiligen Lichtbedingungen an.
<G-vec00095-002-s655><adjust.anpassen><en> And to ensure that you have the best view in any situation, you can adjust the luminosity intensity as you wish to suit the individual lighting conditions.
<G-vec00095-002-s656><adjust.anpassen><de> Entsprechend dem geschweißten Material und dem Rohrdurchmesser sowie abhängig von Durchfluss und Druck des Mediums passt unsere intelligente Ausrüstung Ihr Schweißverfahren an.
<G-vec00095-002-s656><adjust.anpassen><en> Our intelligent equipment adjust your welding procedure according to the welded material and the pipe diameter, liquid influx/flow and pressure.
<G-vec00095-002-s657><adjust.anpassen><de> Abhängig von deinen täglichen Erfolgen passt das Gerät dein Ziel für den nächsten Tag an und bringt dich damit einem gesunden Lebensstil näher.
<G-vec00095-002-s657><adjust.anpassen><en> As you meet your milestones, it will adjust your goal for the next day, gradually nudging you toward a healthier lifestyle.
<G-vec00095-002-s658><adjust.anpassen><de> Weiterhin passt du, wenn nötig, Kreditlimits an und schickst jeden Monat Berichte an die entsprechenden Abteilungen.
<G-vec00095-002-s658><adjust.anpassen><en> You will also be required to adjust credit limits where needed and provide monthly reports for the relevant departments.
<G-vec00095-002-s659><adjust.anpassen><de> Der Editor passt dabei automatisch die Maße der anderen Fotos an.
<G-vec00095-002-s659><adjust.anpassen><en> The Editor will then automatically adjust the proportions of the other photos.
<G-vec00095-002-s660><adjust.anpassen><de> Wenn du eine Bildrate von mehr als 60 FPS oder weniger als 15 FPS hochlädst, passt Vimeo die Bildrate automatisch für dich an - aber wir können nicht garantieren, dass die Ergebnisse immer wie erwartet aussehen.
<G-vec00095-002-s660><adjust.anpassen><en> If you upload a frame rate that is higher than 60 FPS or lower than 15 FPS, Vimeo will automatically adjust the frame rate for you — but we can't guarantee the results will always look as expected.
<G-vec00095-002-s714><adjust.anpassen><de> Über die Listen lassen sich die Verankerungsart und der Verbund anpassen.
<G-vec00095-002-s714><adjust.anpassen><en> You can adjust the Anchorage type and the Bond type by using the lists.
<G-vec00095-002-s715><adjust.anpassen><de> Der leistungsstarke Trimmerkopf gewährleistet gute Ergebnisse und lässt sich ganz einfach durch die Wahl eines anderen Schneideblatts an die entsprechende Aufgabe anpassen: von Feinbearbeitung bis hin zu harter Arbeit in anspruchsvollem Gelände.
<G-vec00095-002-s715><adjust.anpassen><en> The efficient trimmer head ensures good results and you can easily adjust it by changing the type of blade, depending on the task – from fine trimming to heavy work in rough terrain.
<G-vec00095-002-s716><adjust.anpassen><de> Tastaturkurzbefehle lassen sich in OS X für jedes Programm unter »Systemeinstellungen > Tastatur > Kurzbefehle« anpassen.
<G-vec00095-002-s716><adjust.anpassen><en> In OS X, you can adjust keyboard shortcuts for each program under »System Preferences > Keyboard > Shortcuts«.
<G-vec00095-002-s717><adjust.anpassen><de> Sie können sich die Gebrauchsmenge und den Gebrauchbereich entsprechend Ihrem Bedarf anpassen.
<G-vec00095-002-s717><adjust.anpassen><en> You can adjust the using quantity and using area according to your need.
<G-vec00095-002-s718><adjust.anpassen><de> 2 Stück leichte reaktive Linsen, die sich eine Vielzahl von wechselnden Licht Bedingungen anpassen.
<G-vec00095-002-s718><adjust.anpassen><en> 2 piece light reactive lenses that adjust to a wide range of changing light conditions.
<G-vec00095-002-s719><adjust.anpassen><de> SDS lässt sich je nach Ihren Kapazitätsbedürfnissen automatisch anpassen.
<G-vec00095-002-s719><adjust.anpassen><en> SDS can adjust automatically based on your capacity needs.
<G-vec00095-002-s720><adjust.anpassen><de> Sein abgerundeter Klingenkopf, fünf Klingen, die sich jeder Kurve anpassen, und das Feuchtigkeitsband garantieren glatte Ergebnisse.
<G-vec00095-002-s720><adjust.anpassen><en> Its rounded head, five blades that adjust to every curve, and Ribbon of MoistureTM ensure smooth results.
<G-vec00095-002-s721><adjust.anpassen><de> Sie muss sich der Zeit und den neuen Gegebenheiten anpassen.
<G-vec00095-002-s721><adjust.anpassen><en> It must adjust with the times and new circumstances.
<G-vec00095-002-s722><adjust.anpassen><de> Mit vier Slide Bloc-Schnallen ausgestattet lässt sich der Ophir Kids in Sekundenschnelle an jede Kindergröße anpassen.
<G-vec00095-002-s722><adjust.anpassen><en> Equipped with four Slide Bloc buckles, you can adjust the Ophir Kids to any child size within seconds.
<G-vec00095-002-s723><adjust.anpassen><de> Die Neuentwicklung unterstützt die Effizienz und Wirtschaftlichkeit von Klettersystemen, indem sie sich flexibel an die Bauwerksgeometrie anpassen lässt und größere Schalungseinheiten erlaubt.
<G-vec00095-002-s723><adjust.anpassen><en> The new development supports the efficiency and cost effectiveness of climbing systems insomuch that they adjust flexibly to the structure geometry and permit larger formwork units.
<G-vec00095-002-s724><adjust.anpassen><de> Euer Körper wird sich anpassen, um das zu ermöglichen, und ihr werdet bald unterschiedliche Veränderungen sehen, darunter auch Bewusstseinsverschiebungen.
<G-vec00095-002-s724><adjust.anpassen><en> Your body will adjust to make that happen and you will begin to see changes in many ways, including some of the shifts in consciousness.
<G-vec00095-002-s725><adjust.anpassen><de> Aber sie konnten sich schnell anpassen.
<G-vec00095-002-s725><adjust.anpassen><en> But they were able to adjust quickly.
<G-vec00095-002-s726><adjust.anpassen><de> Das Sicherheitskissen lässt sich dadurch leicht dem Körper des Kindes anpassen.
<G-vec00095-002-s726><adjust.anpassen><en> The safety cushion is therefore able to easily adjust to the child’s body.
<G-vec00095-002-s727><adjust.anpassen><de> Das bedeutet das egal welche Monitorauflösung man einstellt, sich alle Elemente automatisch in der Größe anpassen.
<G-vec00095-002-s727><adjust.anpassen><en> This means that no matter what monitor resolution you set, all elements adjust the size automatically.
<G-vec00095-002-s728><adjust.anpassen><de> Die Taurus Pec Fly/Rear Delt IT95 verfügt über schwenkbare, bewegliche Arme, die sich automatisch der Armlänge des Trainierenden anpassen.
<G-vec00095-002-s728><adjust.anpassen><en> The Rear Delt/Pec Fly machine is equipped with swivelling, mobile arms, which adjust automatically to the arm length of the user.
<G-vec00095-002-s729><adjust.anpassen><de> Ohne Verlust der Bildqualität lassen sich Weißabgleich, Tonwertbereich, Kontrast, Farbsättigung und Schärfe von Kamera-Rohdateien, wie jeweils gewünscht, anpassen.
<G-vec00095-002-s729><adjust.anpassen><en> You can adjust the white balance, tonal range, contrast, color saturation, and sharpness of a raw image without any loss of image quality.
<G-vec00095-002-s730><adjust.anpassen><de> Und ich weiß, dass ich schnell bin: Mein Skifahren muss sich nur an die Performance des Materials anpassen, dann ist alles gut“, war für die Gesamtweltcupsiegerin im Atomic Facebook Livestream schnell wieder ein Haken unter dem Rennen.
<G-vec00095-002-s730><adjust.anpassen><en> And I know that I’m fast: my skiing just needs to adjust to the material’s performance, then everything will be fine”, as the World Cup winner quickly put the race behind her again in the Atomic Facebook Livestream.
<G-vec00095-002-s731><adjust.anpassen><de> Damit lässt sich der Gurt optimal an jede Körpergröße anpassen und wird nicht so schnell zu klein.
<G-vec00095-002-s731><adjust.anpassen><en> This allows the belt to adjust optimally to any height und will not soon be too small.
<G-vec00095-002-s732><adjust.anpassen><de> Dabei lassen sich die Farb- und Wertezuweisungen des Panels anpassen.
<G-vec00095-002-s732><adjust.anpassen><en> For this, you can adjust the colors and values assigned in the panel.
<G-vec00095-002-s733><adjust.anpassen><de> Wissenschaftler am Institut für Neurobiologie in Brüssel erforschen, wie lang unser Gehirn braucht, um sich an diese neue Dynamik anzupassen.
<G-vec00095-002-s733><adjust.anpassen><en> Researchers from the Institute of Neuroscience in Brussels are studying how long it takes our brains to adjust to this dynamic.
<G-vec00095-002-s734><adjust.anpassen><de> Trotz immer neuer Dienste und Distributionswege bleibt alten Strukturen noch genug Zeit, sich anzupassen.
<G-vec00095-002-s734><adjust.anpassen><en> As new services and means of distribution arise, old staples will still have time to adjust.
<G-vec00095-002-s735><adjust.anpassen><de> Ein stabiler rechtlicher und aufsichtsrechtlicher Rahmen, der gleichzeitig flexibel genug ist, um sich schnell an veränderte Rahmenbedingungen anzupassen.
<G-vec00095-002-s735><adjust.anpassen><en> a legal and regulatory environment that is stable but also flexible enough to adjust swiftly to a constantly changing environment,
<G-vec00095-002-s736><adjust.anpassen><de> Weil wir mit einem agilen Prozess entwickeln, ist das Team in der Lage, sich spontan anzupassen.
<G-vec00095-002-s736><adjust.anpassen><en> Because we are developing using an agile process the team is able to adjust on the fly.
<G-vec00095-002-s737><adjust.anpassen><de> Wenn Sie vorhaben, mit einer Familie zu leben, sollten Sie daran denken, dass Sie ein gewisses Maß an Flexibilität mitbringen sollten, um sich an die peruanischen Gewohnheiten und den Lebensstil anzupassen.
<G-vec00095-002-s737><adjust.anpassen><en> If you choose to stay with a family, you should recognize that a certain degree of flexibility will be required to adjust to Peruvian customs and way of life.
<G-vec00095-002-s738><adjust.anpassen><de> Da die Haut noch eine längere Zeit braucht, um sich der neuen Unterlage möglichst glatt anzupassen, ist das Tragen der Miederware für einen Zeitraum von etwa vier bis acht Wochen sinnvoll.
<G-vec00095-002-s738><adjust.anpassen><en> Since the skin still needs a while to adjust to the new underlay as smooth as possible, wearing the corsetry is useful for a period of about four to eight weeks.
<G-vec00095-002-s739><adjust.anpassen><de> Unsere Augen haben die natürliche Fähigkeit, sich an diese verschiedenen Arten der Beleuchtung anzupassen, aber eine Kamera nicht.
<G-vec00095-002-s739><adjust.anpassen><en> Our eyes have the natural ability to adjust to these different types of lighting, but a camera doesn’t.
<G-vec00095-002-s740><adjust.anpassen><de> Beschreibung Als Teil unseres Tauchzubehörs, dem Mundstück MP-400, verwenden herkömmliche Mundstücke ein extrem flexibles Material, um sich an die verschiedenen Konfigurationen von Zähnen und Backen anzupassen, die von unserem speziellen Design, dem weichen Silikon, verlangt werden.
<G-vec00095-002-s740><adjust.anpassen><en> Description As part of our diving accessories, MP-400 scuba mouthpiece, a conventional scuba mouthpieces use an extremely flexible material in order to adjust to all the various configurations of teeth and jaws required by the our special design, soft silicone.
<G-vec00095-002-s741><adjust.anpassen><de> Um sich an die individuellen Bedürfnisse jedes Kunden anzupassen, bieten wir die Möglichkeit, unterschiedliche Arten von Fertigungselementen sowie untypischen Produkten – aufgrund von Mustern oder technischen Zeichnungen herzustellen.
<G-vec00095-002-s741><adjust.anpassen><en> Individual MDF product orders In order to adjust to individual needs of every client, we offer the possibility to order finishing materials of different kinds or non-standard products based on samples or technical drawings.
<G-vec00095-002-s742><adjust.anpassen><de> Dennoch fällt es vielen Medien schwer, sich an die sich rasch wandelnde Medienkultur anzupassen.
<G-vec00095-002-s742><adjust.anpassen><en> Even so, many struggle to adjust to the rapidly changing media culture.
<G-vec00095-002-s743><adjust.anpassen><de> Das Hotel Elaphusa bietet eine breite Palette verschiedenartiger Erlebnisse und Dienstleistungen und ist bemüht, sich den Bedürfnissen und Wünschen seiner Gäste anzupassen.
<G-vec00095-002-s743><adjust.anpassen><en> Elaphusa Hotel offers a wide selection of different experiences and services and tries to adjust fully to the needs and wishes of its guests.
<G-vec00095-002-s744><adjust.anpassen><de> Dieses Design ist stationär - es kann nicht überall bewegt oder aufgestellt werden, wenn der Flur umgebaut wird, jedoch ist es aufgrund der Vielfalt der Materialien immer möglich, die Außenfassade zu ändern, um sich absolut jedem Stil des Interieurs anzupassen - sei es klassischer oder moderner Minimalismus.
<G-vec00095-002-s744><adjust.anpassen><en> This design is stationary - it can not be moved or deployed anywhere if the hallway is converted, however, due to the variety of materials, it is always possible to change the exterior facade, to adjust absolutely to any style of the interior - be it classic or modern minimalism.
<G-vec00095-002-s745><adjust.anpassen><de> Gib den neuen Geschwisterkindern Zeit sich anzupassen.
<G-vec00095-002-s745><adjust.anpassen><en> Give the new siblings time to adjust.
<G-vec00095-002-s746><adjust.anpassen><de> Griff mit Stollen hat die Möglichkeit, sich anzupassen (2 Stufen), ermöglicht individuelle Anpassung an das Wachstum.
<G-vec00095-002-s746><adjust.anpassen><en> Handle with lug has possibility to adjust (2 levels), allows to individual personalisation to growth.
<G-vec00095-002-s747><adjust.anpassen><de> Die Persönlichkeit hilft Ihnen, sich anzupassen Ihre Persönlichkeit hilft Ihnen, zu überleben und die täglichen Herausforderungen zu meistern.
<G-vec00095-002-s747><adjust.anpassen><en> Personality helps you to adjust Your personality helps you to "survive" and deal with the daily challenges surrounding you.
<G-vec00095-002-s748><adjust.anpassen><de> Am besten ist es, sich anzupassen, während die Fühlerlehre zwischen beiden ist.
<G-vec00095-002-s748><adjust.anpassen><en> It is best to adjust while the feeler gauge is between.
<G-vec00095-002-s749><adjust.anpassen><de> Die Europäische Union wird ein integriertes Bewirtschaftungskonzept verabschieden, um sich an die Merkmale der Mittelmeerfischerei anzupassen.
<G-vec00095-002-s749><adjust.anpassen><en> The European Union will adopt an integrated method of management to adjust to the characteristics of fisheries in the Mediterranean.
<G-vec00095-002-s750><adjust.anpassen><de> Wie in allen neuen Situationen braucht man Zeit, sich anzupassen.
<G-vec00095-002-s750><adjust.anpassen><en> As with all new situations, it takes time to adjust.
<G-vec00095-002-s787><adjust.anpassen><de> Wenn Sie feststellen, dass die Temperaturgleichmäßigkeit von oben nach unten verändert werden muss, dann können Sie dieses Verhältnis einfach anpassen.
<G-vec00095-002-s787><adjust.anpassen><en> If you find that the temperature uniformity has to be changed from top to bottom, you simply adjust the ratio.
<G-vec00095-002-s788><adjust.anpassen><de> GS1 Logistiklabels Natürlich können Sie diese Formulare an Ihre Anforderungen anpassen oder komplett neue Formulare, Labels und Etiketten selbst erstellen.
<G-vec00095-002-s788><adjust.anpassen><en> It is possible to adjust these templates according to your specific needs. If required create custom forms, labels and reports by yourself.
<G-vec00095-002-s789><adjust.anpassen><de> Sie lernen, wie Sie Ihre Prezi an verschiedene Themen anpassen, und welche visuellen Konzepte man hierzu am Besten wählt.
<G-vec00095-002-s789><adjust.anpassen><en> You will learn how to adjust your Prezi to different topics and what visual concept to choose in those cases.
<G-vec00095-002-s790><adjust.anpassen><de> Entsprechend müssen Sie Ihr Beratungspaket und Ihre Vorsorge anpassen.
<G-vec00095-002-s790><adjust.anpassen><en> Your advisory package and financial plan will have to adjust accordingly.
<G-vec00095-002-s791><adjust.anpassen><de> Richtige Ernährung Vergessen Sie nicht, wie Sie Ihre Diät für die Zeit der Krankheit anpassen.
<G-vec00095-002-s791><adjust.anpassen><en> Proper nutrition Do not forget about how to adjust your diet for the time of illness.
<G-vec00095-002-s792><adjust.anpassen><de> Da der nächste Gegner bekanntlich immer der schwerste ist, musst du deine Kontrahenten ständig im Blick behalten und deine Aufstellung auf sie anpassen.
<G-vec00095-002-s792><adjust.anpassen><en> As the saying goes, the next opponent is always the hardest; you’ll need to maintain a constant overview of your competition and adjust your squad accordingly.
<G-vec00095-002-s793><adjust.anpassen><de> In diesem Video wird gezeigt, wie Sie die Trinkmenge für einen Cappuccino anpassen und speichern.
<G-vec00095-002-s793><adjust.anpassen><en> The video shows how to adjust and save the size for a cappuccino.
<G-vec00095-002-s794><adjust.anpassen><de> Wenn Sie Auto Invest auf Mintos verwenden und in die neuen ID Finance-Darlehen investieren möchten, die in Spanien ausgegeben werden, stellen Sie sicher, dass Sie Ihre Auto Invest-Einstellungen entsprechend anpassen.
<G-vec00095-002-s794><adjust.anpassen><en> If you use Auto Invest on Mintos and want to invest in new ID Finance loans issued in Spain, be sure to adjust your Auto Invest settings accordingly.
<G-vec00095-002-s795><adjust.anpassen><de> Optional können Sie auf der Registerseite Exportoptionen die Exportgenauigkeit anpassen.
<G-vec00095-002-s795><adjust.anpassen><en> Under Export options optionally adjust the Export accuracy.
<G-vec00095-002-s796><adjust.anpassen><de> Sie können die Breite und den Bogen der Angriffslinie anpassen.
<G-vec00095-002-s796><adjust.anpassen><en> The player can adjust the width and the arc of their offensive line.
<G-vec00095-002-s797><adjust.anpassen><de> Möglicherweise müssen Sie die Größe einiger Callouts an den übersetzten Text anpassen.
<G-vec00095-002-s797><adjust.anpassen><en> You may need to adjust the size of some callouts to fit the translated text.
<G-vec00095-002-s798><adjust.anpassen><de> Somit vermeiden Sie Pilze oder andere Infektionen.</p> Marc-Dorcel add-to-Ring ist ein Penisring, der sich leicht an alle Penisgrößen anpassen kann.
<G-vec00095-002-s798><adjust.anpassen><en> The cockring Marc Dorcel Adjust Ring is a cock ring that can easily be adapted to any size of penis.
<G-vec00095-002-s799><adjust.anpassen><de> Haben Sie einen Basis-Lebenslauf, den Sie für jeden Job, für den Sie sich bewerben, anpassen können.
<G-vec00095-002-s799><adjust.anpassen><en> Have a base CV that you can adjust to each job you are applying for.
<G-vec00095-002-s800><adjust.anpassen><de> Verwenden Sie den Abstand, um den Abstand zwischen dem Text in das Textfeld anpassen.
<G-vec00095-002-s800><adjust.anpassen><en> Use padding to adjust the spacing around the text inside the text box.
<G-vec00095-002-s801><adjust.anpassen><de> ● Einzigartige weit verbreitete Technologie: Erkennt nicht nur die Erkennung von Buchclips, sondern kann auch super große Cutter und verbotene Objekte erkennen, indem Sie die Empfindlichkeit des Sicherheitsgates im Menü der Menüeinstellungen anpassen.
<G-vec00095-002-s801><adjust.anpassen><en> ● Unique widely adaption technology: not only can realize detecting book clip, but also can make it detect super large cutter & prohibited item via adjust the sensitivity of the security gate in its panel setting menu.
<G-vec00095-002-s802><adjust.anpassen><de> Wenn Sie andere Baugruppen verwenden, dann müssen Sie Punkte 8 und 10 im Python Skript anpassen.
<G-vec00095-002-s802><adjust.anpassen><en> If you are using other modules, you must adjust points 8 and 10 in the Python script.
<G-vec00095-002-s803><adjust.anpassen><de> Mit Leichtigkeit werden Sie die Bedachung der Gebäudefassade und seiner Umgebung anpassen.
<G-vec00095-002-s803><adjust.anpassen><en> You can easily adjust the roofing to the facade of the building and its surroundings.
<G-vec00095-002-s804><adjust.anpassen><de> Wenn Sie nicht sicher sind, wie Sie diese Steuerungen anpassen, finden Sie weitere Informationen in der Dokumentation des Monitors oder auf der Website des Herstellers.
<G-vec00095-002-s804><adjust.anpassen><en> If you're unsure of how to adjust these controls, check the manual for your monitor or the manufacturer's website.
<G-vec00095-002-s805><adjust.anpassen><de> Unter Einstellungen für E-Mail-Benachrichtigungen können Sie die Einstellungen anpassen.
<G-vec00095-002-s805><adjust.anpassen><en> To adjust the settings, go to Notification Emails settings.
<G-vec00095-002-s087><alter.anpassen><de> Ich sprach im Live-Chat mit jemandem über individuelle Anpassung und sie waren so hilfreich, wenn sie mich durchführten, wie ich mein Kleid an meine Größe und Heilung anpassen musste.
<G-vec00095-002-s087><alter.anpassen><en> I talked on the live chat to someone about custom fitting and they were so helpful in guiding me through how I needed to alter my dress to my height and heals.
<G-vec00095-002-s088><alter.anpassen><de> Sie können nicht nur die Benutzeroberfläche der von ihnen entwickelten Erweiterungen anpassen, sondern auch neue Funktionen hinzufügen.
<G-vec00095-002-s088><alter.anpassen><en> Not only can they alter the user interface of Extensions they built, but they can also add new functionality.
<G-vec00095-002-s089><alter.anpassen><de> Der Chirurg wird einfach die Einschnittsstelle anpassen oder eine eher vorsichtige Operation durchführen.
<G-vec00095-002-s089><alter.anpassen><en> The surgeon will simply alter the incision location or perform a more conservative operation.
<G-vec00095-002-s090><alter.anpassen><de> Obwohl die Mitglieder der Eurozone weder ihre Zinssätze noch ihren Wechselkurs anpassen können, können sie ihre Steuervorschriften anpassen, um zu Ausgaben anzuregen und die Nachfrage anzukurbeln, wobei sich die angemessenen politischen Strategien möglicherweise von Land zu Land unterscheiden.
<G-vec00095-002-s090><alter.anpassen><en> Though eurozone members cannot adjust their interest rates or their exchange rates, they can alter their tax rules to stimulate spending and demand, with the appropriate policy possibly differing from country to country.
<G-vec00095-002-s091><alter.anpassen><de> Kommt es zu Abweichungen zu der real gefahrenen Geschwindigkeit, können Sie den cwA-Wert solange anpassen, bis die gerechneten Werte etwa mit der Praxis übereinstimmen.
<G-vec00095-002-s091><alter.anpassen><en> If there is a difference between the speed actually ridden and the calculated one,you can alter the CdA value until the speeds coincide.
<G-vec00095-002-s092><alter.anpassen><de> Das alles wird mit mehreren Fenstern gesteuert, über die sich das Bild mit nur einem Klick anpassen lässt.
<G-vec00095-002-s092><alter.anpassen><en> All of that is managed from different windows that only require one click to alter the image.
<G-vec00095-002-s093><alter.anpassen><de> (iii) Ohne unsere vorherige schriftliche Zustimmung dürfen Sie die Inhalte oder Services weder ganz noch teilweise modifizieren, verändern oder anpassen.
<G-vec00095-002-s093><alter.anpassen><en> You will not interfere with, modify or alter or attempt to interfere with, modify or alter the Services in any way.
<G-vec00095-002-s094><alter.anpassen><de> Es ist mit vielen Finnenmarken kompatibel, sodass Sie die Finnen an die Bedingungen anpassen oder die Leistung des Boards verbessern können.
<G-vec00095-002-s094><alter.anpassen><en> Compatible with other fin two tab systems, allowing you to change your fins to suit conditions or alter board performance.
<G-vec00095-002-s095><alter.anpassen><de> Wir haben eigentlich nur einen Sprecher ausgewählt, dessen Stimme möglichst gut zu unseren Vorstellungen passte, damit wir später nicht mehr so viel anpassen mussten.
<G-vec00095-002-s095><alter.anpassen><en> All we did was hire a voice actor who fit the image we were going for so we wouldn’t have to alter it much later.
<G-vec00095-002-s096><alter.anpassen><de> In diesen Fällen werden wir auch unsere Hinweise zum Datenschutz entsprechend anpassen.
<G-vec00095-002-s096><alter.anpassen><en> In these cases we will also alter our references to data protection accordingly.
<G-vec00095-002-s097><alter.anpassen><de> Wenn du jeden Tag Make Up trägst, dann versuche deinen Basic Look zu finden, den du je nach Gelegenheit anpassen kannst.
<G-vec00095-002-s097><alter.anpassen><en> If you tend to wear makeup on a daily basis, consider settling into a basic look that you can alter up or down depending on your needs.
<G-vec00095-002-s099><alter.anpassen><de> Hier können Sie beispielsweise das Format des gezeigten Datums im Inhaltssteuerelement Datumsauswahl oder die verfügbaren Eingaben in einer Dropdownliste anpassen.
<G-vec00095-002-s099><alter.anpassen><en> Here you can, for example, change the format of the displayed date in Date Pickers or alter the available options in a Drop Down List.
<G-vec00095-002-s100><alter.anpassen><de> Mit der neuen Server Version 2016 wird Microsoft voraussichtlich auch das Lizenzmodell anpassen.
<G-vec00095-002-s100><alter.anpassen><en> Microsoft is also expected to alter the licensing model in the new 2016 server version.
<G-vec00095-002-s101><alter.anpassen><de> Die Konfiguration für den Server muss man bei Bedarf manuell anpassen.
<G-vec00095-002-s101><alter.anpassen><en> 95 You must alter the server configuration manually.
<G-vec00095-002-s102><alter.anpassen><de> Dies bedeutete, dass wir den Designer um eine Anpassung bitten mussten, einige der Sticker neu gedruckt werden mussten und dass der Tischler den Kleiderschrank anpassen musste.
<G-vec00095-002-s102><alter.anpassen><en> That meant we had to ask the designer to adapt the jeans, reprint some of the stickers and have the carpenter alter the wardrobe.
<G-vec00095-002-s103><alter.anpassen><de> Der Anbieter behält sich das Recht vor, die Abholzeiten entsprechend örtlicher Anforderungen anzupassen.
<G-vec00095-002-s103><alter.anpassen><en> The supplier reserves the right to alter pick up times according to local needs.
<G-vec00095-002-s104><alter.anpassen><de> Die Aborigines haben jedoch überhaupt nicht den Wunsch, das Land anzupassen und in die Natur einzugreifen.
<G-vec00095-002-s104><alter.anpassen><en> The Aborigines, however, have no need to cultivate the land or to alter nature.
<G-vec00095-002-s105><alter.anpassen><de> Die Gesellschaft behält sich das Recht vor, die Nutzungsbedingungen aus unterschiedlichen Gründen zu ändern, zu bearbeiten, zu aktualisieren oder anzupassen, einschließlich kommerzieller, rechtlicher (nach neuen Gesetzen und Verordnungen) Gründe, sowie aus Gründen, die mit dem Kundendienst zusammenhängen.
<G-vec00095-002-s105><alter.anpassen><en> The Company reserves the right to modify, edit, update or alter any of the Terms for a variety of reasons, including commercial, legal (as per new laws and regulations), as well as for reasons related to customer service.
<G-vec00095-002-s106><alter.anpassen><de> Die YOC AG übernimmt keine Verpflichtung, derartige zukunftsgerichtete Aussagen fortzuschreiben und an zukünftige Ereignisse und Entwicklungen anzupassen.
<G-vec00095-002-s106><alter.anpassen><en> YOC AG has no obligation to act in keeping with such statements regarding future developments or to alter its actions to accommodate future events and developments.
<G-vec00095-002-s057><modify.anpassen><de> Falls man damit noch nicht zufrieden ist, lassen sich einige Aspekte anpassen, etwa Tempo oder Tonhöhe.
<G-vec00095-002-s057><modify.anpassen><en> If you don’t like it very much, you will be able to modify some aspects of the remix, such as the tempo or tone to custom it.
<G-vec00095-002-s058><modify.anpassen><de> Auch erwähnenswert ist das Panel für Effekte, mit dem sich Songs während sie gespielt werden, also in Echtzeit, anpassen lassen.
<G-vec00095-002-s058><modify.anpassen><en> The special effects panel is another feature that needs mention, as it allows you to modify the sounds being played, all in real time.
<G-vec00095-002-s059><modify.anpassen><de> Jeder kann den Code nutzen und ihn an seine jeweiligen Bedürfnisse anpassen.
<G-vec00095-002-s059><modify.anpassen><en> Everybody can use the code and modify it for their needs.
<G-vec00095-002-s060><modify.anpassen><de> Ich werde die Reise dann einfach den Gegebenheiten anpassen.
<G-vec00095-002-s060><modify.anpassen><en> I will then simply modify the journey to the conditions.
<G-vec00095-002-s061><modify.anpassen><de> Beim erzeugen der Ansichten können Sie über die Optionen zur Sichtbarkeit von Kategorien die dargestellten Inhalte anpassen.
<G-vec00095-002-s061><modify.anpassen><en> While creating the views, you can modify their contents using the options for the visibility of the categories
<G-vec00095-002-s062><modify.anpassen><de> Sie können ihre Browsereinstellungen ganz einfach anpassen um alle Cookies abzuschalten.
<G-vec00095-002-s062><modify.anpassen><en> You can modify the settings of your browser to turn off cookies through a very simple procedure.
<G-vec00095-002-s063><modify.anpassen><de> Sie können Ihre Browsereinstellungen so anpassen, dass Sie benachrichtigt werden, wenn Cookies an Ihren Browser gesendet werden, oder Sie können Cookies generell ablehnen.
<G-vec00095-002-s063><modify.anpassen><en> It is possible to modify your browser so that it notifies you when cookies are sent to it or you can refuse cookies altogether.
<G-vec00095-002-s064><modify.anpassen><de> Sie können unsere Software Contenta Converter PREMIUM verwenden, um den Gamma-Wert von Tausenden von PDF anpassen.
<G-vec00095-002-s064><modify.anpassen><en> You can use our software Contenta Converter PREMIUM to modify the description from thousands of PDF.
<G-vec00095-002-s065><modify.anpassen><de> Ihr könnt die Grafiken und Meshes komplett euren Bedürfnissen anpassen.
<G-vec00095-002-s065><modify.anpassen><en> You can modify my graphics and meshes in every needed way to fit it to your needs.
<G-vec00095-002-s066><modify.anpassen><de> Sie können die Halle den von Ihnen gelagerten Produkten anpassen.
<G-vec00095-002-s066><modify.anpassen><en> You can modify the space according to the products stored within it.
<G-vec00095-002-s067><modify.anpassen><de> Auf der Warenkorb Seite können Sie Ihre Bestellung anpassen.
<G-vec00095-002-s067><modify.anpassen><en> Here you can modify the items in your cart.
<G-vec00095-002-s068><modify.anpassen><de> Dank dieser Information konnte unser Mandant rechtzeitig seine Strategie und seine Geschäftsziele anpassen.
<G-vec00095-002-s068><modify.anpassen><en> This information encouraged our client to modify his strategy and business goals just in time. Purchasing Undercover
<G-vec00095-002-s069><modify.anpassen><de> Man kann auch traditionelle Bildrahmen zu den Bildern ergänzen oder Helligkeit, Kontrast sowie Sättigung anpassen.
<G-vec00095-002-s069><modify.anpassen><en> You can also add a traditional picture frame to each image, or modify it by retouching the brightness, contrast or saturation.
<G-vec00095-002-s070><modify.anpassen><de> Der Fahrer muss sein Fahrverhalten anpassen, um kritische Situationen zu vermeiden.
<G-vec00095-002-s070><modify.anpassen><en> Drivers have to modify their driving style to avoid critical situations.
<G-vec00095-002-s071><modify.anpassen><de> Ich würde gerne einige der automatisch vorgenommenen Korrekturen deaktivieren oder anpassen.
<G-vec00095-002-s071><modify.anpassen><en> I would like to deactivate or modify certain corrections automatically applied by an Optics Module.
<G-vec00095-002-s072><modify.anpassen><de> Die vorhandenen Gruppierungen lassen sich bei Bedarf anpassen.
<G-vec00095-002-s072><modify.anpassen><en> You can modify existing groupings if required.
<G-vec00095-002-s073><modify.anpassen><de> Wir können diese Datenschutzerklärung jederzeit ohne Vorankündigung anpassen.
<G-vec00095-002-s073><modify.anpassen><en> We may modify this privacy policy at any time without notice.
<G-vec00095-002-s074><modify.anpassen><de> All unsere Arbeit ist frei zum Benutzen, Anpassen und Weitergeben.
<G-vec00095-002-s074><modify.anpassen><en> This means that all our work is free to use, modify and redistribute.
<G-vec00095-002-s075><modify.anpassen><de> Klicken Sie auf die Schaltfläche Anpassen, um die Sicherheitseinstellungen zu ändern.
<G-vec00095-002-s075><modify.anpassen><en> Click the Modify button to change the security settings.
<G-vec00095-002-s076><modify.anpassen><de> Wir behalten uns vor, diese Datenschutzerklärung gelegentlich anzupassen, damit sie stets den aktuellen rechtlichen Anforderungen entspricht oder um Änderungen unserer Leistungen in der Datenschutzerklärung umzusetzen, z.
<G-vec00095-002-s076><modify.anpassen><en> We reserve the right to occasionally modify this data protection notice to ensure its compliance with the effective legal requirements or to reflect changes in our services, e.g.
<G-vec00095-002-s077><modify.anpassen><de> WEH ist berechtigt, die Preisliste entsprechend dem Einfluss der angegebenen Kostenfaktoren in angemessenem Umfang anzupassen.
<G-vec00095-002-s077><modify.anpassen><en> WEH has the right to modify the price list to a reasonable extent in proportion to the influence of the said cost factors.
<G-vec00095-002-s078><modify.anpassen><de> Anstatt die SQL-Anweisungen sofort auszuführen, können Sie sie als Skript generieren lassen, um sie individuell anzupassen oder in einer anderen Datenbank auszuführen.
<G-vec00095-002-s078><modify.anpassen><en> Instead of running the SQL commands immediately, you can also generate them as script so that you can modify them individually or run them in another database.
<G-vec00095-002-s079><modify.anpassen><de> Wir behalten uns das Recht vor die Datenschutzrichtlinien zu jeder Zeit anzupassen.
<G-vec00095-002-s079><modify.anpassen><en> We reserve the right to modify this privacy policy at any time.
<G-vec00095-002-s080><modify.anpassen><de> • Melden Sie sich bei Ihrem Digital River-Benutzerkonto an, um die Option anzupassen.
<G-vec00095-002-s080><modify.anpassen><en> • Log in to your 2Checkout account to modify the option.
<G-vec00095-002-s081><modify.anpassen><de> Beachten Sie, dass alle über dieses Installationsprogramm bereitgestellte Jump Clients anfänglich über die gleichen Kommentare verfügen werden, es sei denn, Sie aktivieren Überschreibung während der Installation zulassen und verwenden die verfügbaren Parameter, um das Installationsprogramm für individuelle Installationen anzupassen.
<G-vec00095-002-s081><modify.anpassen><en> Note that all Jump Clients deployed via this installer have the same comments set initially, unless you check Allow Override During Installation and use the available parameters to modify the installer for individual installations.
<G-vec00095-002-s082><modify.anpassen><de> Dem LIZENZNEHMER ist es nicht gestattet, die NCP Software zu ändern, anzupassen, mit anderer Software zu vereinen oder auf Basis der NCP Software oder deren Teilen andere Softwareprodukte zu entwickeln oder herzustellen.
<G-vec00095-002-s082><modify.anpassen><en> LICENCEE is not permitted to change, modify or combine the NCP software with other programs or to develop other software products based on the NCP software or parts of it.
<G-vec00095-002-s083><modify.anpassen><de> Hierzu gehören auch Field-Programmable- Gate-Arrays (FPGA), welche es erlauben, komplexe Signalverarbeitung zu implementieren und diese später an geänderte Spezifikationen anzupassen.
<G-vec00095-002-s083><modify.anpassen><en> This includes also Field Programmable Gate Arrays (FPGA), which allows the implementation of complex signal processing algorithms with the option to modify it afterwards.
<G-vec00095-002-s084><modify.anpassen><de> Wir behalten uns das Recht vor, unsere Datenschutzerklärung gelegentlich anzupassen, damit sie stets den aktuellen rechtlichen Anforderungen entspricht oder um Änderungen unserer Leistungen in der Datenschutzerklärung umzusetzen.
<G-vec00095-002-s084><modify.anpassen><en> We reserve the right to modify this privacy policy at any time to ensure it always meets current legal requirements or in order to implement changes to our services in the privacy policy.
<G-vec00095-002-s085><modify.anpassen><de> Wir sind bemüht, die angebotenen Inhalte ständig zu aktualisieren und anzupassen, so dass Sie immer die neuesten Informationen erhalten.
<G-vec00095-002-s085><modify.anpassen><en> We try to update and modify the offered contents on an ongoing basis so that you can always receive the latest information.
<G-vec00095-002-s086><modify.anpassen><de> Intera basiert auf einer grafischen Nutzeroberfläche und erlaubt es Mitarbeitern, Aufgaben des Roboters ganz nach Bedarf zu erstellen und anzupassen.
<G-vec00095-002-s086><modify.anpassen><en> Fastest to Deploy Intera provides a graphical user interface that enables existing personnel to create and modify robot tasks as needed.
<G-vec00095-002-s087><modify.anpassen><de> Citrix Online behält sich das Recht vor, ohne vorherige Ankündigung und ohne Haftung gegenüber dem Kunden oder einem Endnutzer die Dienste anzupassen, egal aus welchem Grund.
<G-vec00095-002-s087><modify.anpassen><en> Citrix Online reserves the right to modify the Services for any reason, without notice and without liability to Customer or any end user.
<G-vec00095-002-s088><modify.anpassen><de> JUUL Labs ist berechtigt, und behält sich das Recht vor, die Website und diese Nutzungsbedingungen jederzeit anzupassen, zu beschränken, zu ändern, auszusetzen oder zu ersetzen.
<G-vec00095-002-s088><modify.anpassen><en> JUUL Labs may, and reserves the right to, from time to time modify, limit, change, discontinue, or replace the Website, any app and these Terms of Service at any time.
<G-vec00095-002-s089><modify.anpassen><de> Sie können jede Seite des Bereichs ziehen, um den Löschbereich anzupassen.
<G-vec00095-002-s089><modify.anpassen><en> You may drag each side of the range to modify the length for deleting.
<G-vec00095-002-s090><modify.anpassen><de> Klicken Sie auf Software, um die Auswahl der Software-Muster zu starten und den Installationsbereich entsprechend Ihren Bedürfnissen anzupassen.
<G-vec00095-002-s090><modify.anpassen><en> Click Software to start the pattern selection and modify the installation scope according to your needs.
<G-vec00095-002-s091><modify.anpassen><de> Es ist wichtig, deine HIIT-Übungen anzupassen, damit sie sich für dein Fitnesslevel eignen.
<G-vec00095-002-s091><modify.anpassen><en> It’s important to modify your HIIT workout so that it’s suitable for your fitness level.
<G-vec00095-002-s092><modify.anpassen><de> Aus diesem Grund ist es erforderlich: 1) die Begünstigten der europäischen Netzwerke in die Lage zu versetzen, Aspekte ihrer Projektaktivitäten an neue technologische oder markspezifische Trends anzupassen, und 2) eine weitere thematische Relevanz von Kooperationsprojekten sicherzustellen, indem Begünstigte ihre Aktivitäten leichter ändern oder abwandeln können.
<G-vec00095-002-s092><modify.anpassen><en> Therefore it is necessary to: - enable European Networks beneficiaries to modify aspects of their project activities in response to new technological or market trends; - ensure continued thematic relevance for Cooperation Projects by enabling beneficiaries to more easily change or modify their activities.
<G-vec00095-002-s093><modify.anpassen><de> Kombiniere Nodes mit unterschiedlichen Geschwindigkeiten, um die Performance anzupassen, oder such dir die Farbe aus, die perfekt zu deiner Einrichtung passt.
<G-vec00095-002-s093><modify.anpassen><en> Mix and match nodes with different speeds to modify performance or interchange colors to coordinate with your home decor.
<G-vec00095-002-s094><modify.anpassen><de> Die British American Tobacco (Germany) GmbH behält sich vor, diese Website jederzeit und ohne Vorankündigung zu erweitern, anzupassen, zu verändern und vollständig oder partiell vorübergehend oder dauerhaft einzustellen sowie den Zugang dazu zu beschränken oder zu untersagen.
<G-vec00095-002-s094><modify.anpassen><en> British American Tobacco reserves the right at any time and without notice to enhance, modify, alter, suspend or permanently discontinue all or any part of this website and to restrict or prohibit access to it.
<G-vec00095-002-s021><reshape.anpassen><de> Auch haben Sie die Möglichkeit, Ihr Spiel durch Abnehmen der Grad der Risiken, die Sie wünschen, um mit zu spielen anzupassen.
<G-vec00095-002-s021><reshape.anpassen><en> Also you have an opportunity to reshape your game by selecting the level of risks you want to play with.
<G-vec00095-002-s022><reshape.anpassen><de> Auch haben Sie die Möglichkeit, Ihr Spiel, indem Sie den Grad der Einsätze, die Sie spielen wollen, anzupassen.
<G-vec00095-002-s022><reshape.anpassen><en> Also you have a chance to reshape your game by choosing the level of stakes you want to play.
<G-vec00095-002-s029><revise.anpassen><de> Die Nutzungsbedingungen für diese Website können jederzeit ohne Hinweis darauf angepasst werden.
<G-vec00095-002-s029><revise.anpassen><en> Company may revise these terms of use for its web site at any time without notice.
<G-vec00095-002-s030><revise.anpassen><de> Vor dem Hintergrund des aktuellen Trends der Ergebnisentwicklung und der Verschlechterung des gesamtwirtschaftlichen Umfelds hat Brenntag seine Prognose für das Gesamtjahr 2019 im Juli angepasst: Der Konzern geht weiterhin von einem Wachstum beim Rohertrag aus.
<G-vec00095-002-s030><revise.anpassen><en> In light of the current trend in earnings performance and the deterioration in the macroeconomic environment, Brenntag decided in July to revise its forecast for full-year 2019: the Group still expects to see growth in operating gross profit.
<G-vec00095-002-s031><revise.anpassen><de> Mit der Hilfe des inneren Kreises deiner Mitbegründer kannst du deine Leitlinie diskutieren und anpassen.
<G-vec00095-002-s031><revise.anpassen><en> With the help of your core group of co-founders, discuss and revise your mission statement.
<G-vec00095-002-s032><revise.anpassen><de> Gelegentlich aktualisieren wir diese Datenschutzerklärung, beispielsweise wenn wir unsere Website anpassen oder sich die gesetzlichen oder behördlichen Vorgaben ändern.
<G-vec00095-002-s032><revise.anpassen><en> We occasionally update this Data Privacy Policy, for instance when we revise our website or in the case of changes to statutory or official regulations.
<G-vec00095-002-s033><revise.anpassen><de> Der anhaltende Trend zur sogenannten „Smarter World“ mit unbegrenzter drahtloser Konnektivität bedeutet, dass 7layers seine Services und Produktsparten kontinuierlich anpassen und ausbauen muss.
<G-vec00095-002-s033><revise.anpassen><en> With the trend developing towards a smarter world and ubiquitous wireless connectivity, 7layers needs to continuously revise and improve its services and its product lines.
<G-vec00095-002-s034><revise.anpassen><de> Wenn wir Änderungen an dieser Erklärung vornehmen, werden wir das Datum der letzten Aktualisierung oben auf dieser Seite anpassen.
<G-vec00095-002-s034><revise.anpassen><en> When we make changes to this statement, we will revise the "last updated" date at the top of this page.
<G-vec00095-002-s035><revise.anpassen><de> Weder die ALNO AG noch die mit ihr verbundenen Unternehmen übernehmen eine Verpflichtung, derartige zukunftsgerichtete Aussagen zu aktualisieren und an zukünftige Ereignisse oder Entwicklungen anzupassen.
<G-vec00095-002-s035><revise.anpassen><en> Neither ALNO AG nor its affiliated companies are under any obligation to update such forward-looking statements or to revise them in light of future events or developments.
<G-vec00095-002-s036><revise.anpassen><de> Werden nach Abschluss einer Vereinbarung Ein- oder Ausfuhrzölle, Zollgebühren, Steuern für Ausfuhr, Einfuhr oder Lieferung oder ähnliche Abgaben oder Gebühren erhöht oder neue Abgaben, Steuern und/oder Gebühren eingeführt, die für die Waren oder Dienstleistungen gelten, so ist der Lieferant berechtigt, den Preis entsprechend anzupassen.
<G-vec00095-002-s036><revise.anpassen><en> Should, after an agreement has been concluded and entered into, export or import duties, custom charges, taxes on export, import or delivery or similar duties or charges increase or should new duties, taxes and/or charges be introduced and implemented in respect of the Goods or Services, the Supplier shall be entitled to revise the price accordingly.
<G-vec00095-002-s037><revise.anpassen><de> Auch haben Sie die Möglichkeit, Ihr Spiel, indem Sie den Grad der Einsätze, die Sie spielen wollen, anzupassen.
<G-vec00095-002-s037><revise.anpassen><en> Also you have a chance to revise your game by selecting the level of stakes you wish to play.
