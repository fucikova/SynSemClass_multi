<G-vec00595-002-s045><purge.ausleiten><de> Die Kur hilft dem Körper, Schadstoffe besser auszuleiten.
<G-vec00595-002-s045><purge.ausleiten><en> The cure helps the body to purge pollutants.
