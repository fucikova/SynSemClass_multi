<G-vec00081-001-s665><stop.bleiben><de> Es blieben vor dem Balkon auch zufällige Bürgergruppen stehen, deren Neugier periodisch durch einen Zeitungslärm geweckt wurde.
<G-vec00081-001-s665><stop.bleiben><en> Accidental groups of citizens would also stop before the balcony, their curiosity aroused by some uproar in the newspapers.
<G-vec00081-001-s666><stop.bleiben><de> "Natürlich bin ich trostlos, weil ""diese Bewertung eine sehr hohe Durchschnittsnote senken kann und ein abgelenkter Nutzer, der bei einer einfachen Analyse der durchschnittlichen Bewertung von Bewertungen stehen sollte, eine vollständig verzerrte Vorstellung von der Zufriedenheit unserer Gäste hätte."
<G-vec00081-001-s666><stop.bleiben><en> Of course I'm desolate because 'this review can lower a very high average rating, and a distracted user who should stop at a simple analysis of the average rating of reviews, would risk having a completely distorted idea of??the degree of satisfaction of our guests.
<G-vec00081-001-s667><stop.bleiben><de> Natürlich verrichtete man in der Zwischenzeit auch manche andere tägliche Arbeit; aber die vorerwähnte war für die bezeichnete Zeit eine Hauptarbeit, und weil die Sonne da wieder unter ein neues Zeichen zu stehen kam, so nannte man dieses Zeichen den,Widder' (Kostron).
<G-vec00081-001-s667><stop.bleiben><en> Naturally in the meantime one had some other daily tasks, but the previously mentioned was the main job for this time described and because the sun came to stop again under another sign, this sign was called the ram (Aries). 102,19.
<G-vec00081-001-s668><stop.bleiben><de> Passanten blieben stehen und sahen sich die Banner und Plakate an und unterschrieben die Petition, die ein Ende der Verfolgung fordert Die Falun Gong-Übenden rollten zwei Banner aus.
<G-vec00081-001-s668><stop.bleiben><en> Passers-by stop to look at banners and posters and sign petition calling for an end of the persecution
<G-vec00081-001-s669><stop.bleiben><de> Andrea Földi-Kovács: Nun, bleiben wir an diesem Punkt für einen Moment stehen.
<G-vec00081-001-s669><stop.bleiben><en> Andrea Földi-Kovács: Let's stop here for a moment.
<G-vec00081-001-s670><stop.bleiben><de> Ich vergebe mir, dass ich erlaubt und akzeptiert habe nicht aufzustehen und als diese Erkenntnis, dass ich verantwortlich bin zu stehen, eins und gleich.
<G-vec00081-001-s670><stop.bleiben><en> I forgive myself that I have accepted and allowed myself to believe that I am unable to stop myself
<G-vec00081-001-s671><stop.bleiben><de> Um den Buggy schnell und kontrolliert zum Stehen zu bekommen, brauch man auch die richtigen Bremsen.
<G-vec00081-001-s671><stop.bleiben><en> Bringing everything to a fast and controlled stop are a pair of vented steel disc brakes.
<G-vec00081-001-s672><stop.bleiben><de> Von der fröhlichen Musik angezogen, blieben viele Leute stehen und schauten zu.
<G-vec00081-001-s672><stop.bleiben><en> The joyful music attracted many people to stop and watch.
<G-vec00081-001-s673><stop.bleiben><de> """royal squad"", ist ein strategic tower game indem dir bögen, zaubersprüche, fallen und soldaten zur verfügung stehen um die f.."
<G-vec00081-001-s673><stop.bleiben><en> Royal squad is classified as strategic tower game, where you use archery, spells, traps and soldiers to stop the enemy from p..
<G-vec00081-001-s674><stop.bleiben><de> In ganz Europa blieben Züge mitten auf der Strecke stehen oder konnten nur mit reduzierter Leistungihre Fahrt fortsetzen, weil in die Schienenfahrzeuge eingedrungener Schnee elektrische Komponenten außer Funktion gesetzt hatte.
<G-vec00081-001-s674><stop.bleiben><en> In whole Europe trains had to stop at half distance or only could continue driving with reduced power, because the penetrated snow had put electronic components out of operation.
<G-vec00081-001-s675><stop.bleiben><de> – Dann bleibt die Zeit stehen.
<G-vec00081-001-s675><stop.bleiben><en> “Then time will stop.”
<G-vec00081-001-s676><stop.bleiben><de> Wenn ein Patrouillenpunkt nicht erreichbar ist, bleiben die Einheiten auf dem Weg zu diesem nicht mehr stehen.
<G-vec00081-001-s676><stop.bleiben><en> If a patrol point is not accessible the patrolling units no longer simply stop on the path to it
<G-vec00081-001-s677><stop.bleiben><de> Wichtiger Hinweis: Der Bedienungsknopf zum Herbeirufen oder zur Fahrt muss während der ganzen Fahrtzeit gedrückt gehalten werden, sonst bleibt die Fahrplattform stehen.
<G-vec00081-001-s677><stop.bleiben><en> Important notice: The control button for calling or riding the elevator must be kept pressed for the entire travel time of the platform, otherwise the platform will stop.
<G-vec00081-001-s678><stop.bleiben><de> Aber Pablo blieb nicht dabei stehen.
<G-vec00081-001-s678><stop.bleiben><en> But Pablo did not stop there.
<G-vec00081-001-s679><stop.bleiben><de> Stand man in der Öffentlichkeit auf Bänken oder ähnlichem herum, um Selbstportraits von sich zu schießen, so blieben vorbeigehende Leute oft unvermittelt stehen und schauten verwundert, belustigt und neugierig zu.
<G-vec00081-001-s679><stop.bleiben><en> When standing on benches or something similar in public to take a self portrait, people passing would often stop and look puzzled, amused, and curious.
<G-vec00081-001-s680><stop.bleiben><de> Doch dann öffnet der Himmel seine Schleusen, der Bus verlangsamt sein Tempo und bleibt dann stehen.
<G-vec00081-001-s680><stop.bleiben><en> But then the heavens open, and the bus slows down and finally comes to a stop.
<G-vec00081-001-s681><stop.bleiben><de> Weil die Fleischmann Weichen 9178/9179 Stoppfunktionen haben, bleiben die Züge stehen, wenn die Weiche falsch liegt.
<G-vec00081-001-s681><stop.bleiben><en> As the Fleischmann turnouts 9178/9179 are intelligent, the trains stop, if the turnout lies wrong.
<G-vec00081-001-s682><stop.bleiben><de> Uhren, die unter Magnetfeldeinfluß (siehe Magnetismus) bestimmter Stärke nicht stehen bleiben und deren Gangveränderungen bestimmte Grenzen nach einem Magnetfeldeinfluß nicht überschreiten, dürfen nach DIN antimagnetisch genannt werden.
<G-vec00081-001-s682><stop.bleiben><en> According to DIN, watches which do not stop when exposed to a magnetic field (see magnetism) and the accuracy of which does not exceed specified limits when exposed to a magnetic field may be described as antimagnetic.
<G-vec00081-001-s683><stop.bleiben><de> Das brachte die Panzer entweder zum Stehen, weil die Besatzung annahm, es handele sich um Minen, oder aber zwang die Soldaten auszusteigen, um nachzusehen; auf diese Weise wurden die Panzer auch mit kleineren Waffen angreifbar.
<G-vec00081-001-s683><stop.bleiben><en> This tended either to stop the tanks, the tank crew thinking they were mines, or got the soldiers out of their tanks investigating, thus becoming vulnerable to small arms fire.
<G-vec00211-002-s190><keep.bleiben><de> Deshalb arbeiten wir mit Tausenden von Ortsansässigen zusammen, die dafür sorgen, dass Shymkent in Bewegung bleibt.
<G-vec00211-002-s190><keep.bleiben><en> That’s why we partner with thousands of locals who keep Shymkent moving.
<G-vec00211-002-s191><keep.bleiben><de> Damit die Nutzungsfrequenz hoch bleibt, unternehmen Suchmaschinen eine Vielzahl von Maßnahmen.
<G-vec00211-002-s191><keep.bleiben><en> Search engines employ a whole range of measures to keep user frequency high.
<G-vec00211-002-s192><keep.bleiben><de> Michael bleibt durch Fernwanderungen und Mountainbike fahren fit, außerdem fotografiert er gerne und beschäftigt sich mit IT.
<G-vec00211-002-s192><keep.bleiben><en> Long distance walking and mountain biking keep Michael fit and he also enjoys IT and photography.
<G-vec00211-002-s193><keep.bleiben><de> 15:6 Wer nicht in mir bleibt, der wird weggeworfen wie eine Rebe und verdorrt, und man sammelt sie und wirft sie ins Feuer, und sie müssen brennen.
<G-vec00211-002-s193><keep.bleiben><en> 15:6 If a man does not keep himself in me, he becomes dead and is cut off like a dry branch; such branches are taken up and put in the fire and burned.
<G-vec00211-002-s194><keep.bleiben><de> Die andere Hand bleibt frei, um Ihr Fahrrad festzuhalten.
<G-vec00211-002-s194><keep.bleiben><en> So, this way you keep the other hand free to hold the bike.
<G-vec00211-002-s195><keep.bleiben><de> Wenn Sie ihren Diamantring während bestimmter Aktivitäten ablegen, bleibt der Ring nicht nur so lange wie möglich wunderschön und glänzend, sondern Sie können so auch mögliche Schäden vermeiden.
<G-vec00211-002-s195><keep.bleiben><en> Removing your diamond ring during certain activities can not only keep the ring looking great and shiny for as long as possible, but it can also help prevent serious possible damage.
<G-vec00211-002-s196><keep.bleiben><de> Bleibt ruhig und gelassen und helft mit, den allgemeinen Schwingungs-Level anzuheben, indem ihr eure Eigenschwingung hochhaltet und liebevolle Gedanken dorthin sendet, wo ihr Zwietracht oder Negativität beobachtet.
<G-vec00211-002-s196><keep.bleiben><en> Keep calm and help to raise the vibrations by keeping your own steady, and send out loving thoughts where you find discord or negativity.
<G-vec00211-002-s197><keep.bleiben><de> Der Anlass bleibt allen in bester Erinnerung.
<G-vec00211-002-s197><keep.bleiben><en> We all will keep best memories of our event at your Garden Villa.
<G-vec00211-002-s198><keep.bleiben><de> Die rechtsgewinkelte SATA-Verbindung ermöglicht das Anschließen einer Serial ATA-Festplatte an schwer erreichbaren oder engen Stellen, während das kompakte und flexible Design des Kabels die Luftzirkulation verbessert und Kabelsalat in Computergehäusen reduziert, sodass das Gehäuse sauber und kühl bleibt.
<G-vec00211-002-s198><keep.bleiben><en> The right-angled SATA connection enables you to plug in your Serial ATA hard drive in hard to reach areas or tight spaces, while the low profile and flexible design of the cable improves airflow and reduces clutter in your computer case, helping to keep the case clean and cool.
<G-vec00211-002-s199><keep.bleiben><de> Werkzeuge und Zubehör sind griffbereit: Der Zubehörbereich mit rutschfester Matte befindet sich auf der Oberseite der Maschine, sodass der Arbeitsbereich durchgehend sauber und aufgeräumt bleibt und die Werkzeuge griffbereit sind.
<G-vec00211-002-s199><keep.bleiben><en> Tools and accessories close to hand: On top of the machine there is a utensil tray with non-slip mat to help you keep your work bench neat and tidy and keep all your tools and accessories within easy reach.
<G-vec00211-002-s200><keep.bleiben><de> • Damit Ihr Gerät entsperrt bleibt, wenn es erkennt, dass es sich zu Hause oder an einem anderen vertrauenswürdigen Ort befindet, tippen Sie auf Vertrauenswürdige Orte.
<G-vec00211-002-s200><keep.bleiben><en> • To keep your device unlocked when it detects it is at home or at another trusted location, tap Trusted places.
<G-vec00211-002-s201><keep.bleiben><de> Twitter ist und bleibt jedoch weiterhin ein Kurznachrichtendienst, vorerst zumindest.
<G-vec00211-002-s201><keep.bleiben><en> However, it will still keep its character as a short messaging service.
<G-vec00211-002-s202><keep.bleiben><de> Mit dieser speziellen Vorrichtung bleibt der Munde weit geöffnet.
<G-vec00211-002-s202><keep.bleiben><en> Keep their mouth nice and wide with this special mouth gag.
<G-vec00211-002-s203><keep.bleiben><de> Lasst euch nicht verbrühen und bleibt mit dem Kopf über Wasser.
<G-vec00211-002-s203><keep.bleiben><en> Try not to get burned and keep your head above water.
<G-vec00211-002-s204><keep.bleiben><de> „Es gibt viele gute Gründe, die für einen Einstieg in den ADAC Opel Rallye Cup sprechen, und wir werden alles dafür tun, dass dies so bleibt“, betont Opel-Motorsport-Direktor Jörg Schrott.
<G-vec00211-002-s204><keep.bleiben><en> “There are many good reasons to join the ADAC Opel Rallye Cup and we will do everything in our power to keep it that way,” says Opel Motorsport Director Jörg Schrott.
<G-vec00211-002-s205><keep.bleiben><de> Weiter einkaufen „Das Wunder bleibt länger als 3 Tage bestehen“ wurde deinem Warenkorb hinzugefügt.
<G-vec00211-002-s205><keep.bleiben><en> Continue shopping “The wonder keep on more than 3 days” has been added to your cart.
<G-vec00211-002-s206><keep.bleiben><de> Der Kaffee & Teebereiter ist doppelwandig, dadurch bleibt ihr Kaffee oder Tee länger warm.
<G-vec00211-002-s206><keep.bleiben><en> The coffee & tea maker is double-walled to keep your coffee or tea warm for longer.
<G-vec00211-002-s207><keep.bleiben><de> Mit dem Parameter /s oder /service wird der Anti-Malware-Dienst gestartet und bleibt für spätere Scans aktiv.
<G-vec00211-002-s207><keep.bleiben><en> Using the /s or /service parameter makes the Anti-Malware service load the engine and keep it loaded for later scans.
<G-vec00211-002-s208><keep.bleiben><de> Damit der Wärmestrom möglichst klein bleibt, muss die Aluminiumschicht in der Folie gering gehalten werden (vorzugsweise < 100 nm).
<G-vec00211-002-s208><keep.bleiben><en> The aluminium layer in the envelope foil therefore has to be made as thin as possible (preferably < 100 nm) to keep the heat flow at a minimum.
<G-vec00213-002-s153><halt.bleiben><de> Man belud also einen von zwei Ochsen gezogenen Karren mit Baumaterial und ließ die Tiere so lange frei über das Land ziehen, bis sie an einer bestimmten Stelle plötzlich stehen blieben, niederknieten und dadurch anzeigten, dass es sich hier um den geeigneten Ort für den Tempel handelte.
<G-vec00213-002-s153><halt.bleiben><en> A cart full of building materials was harnessed to two oxen who were then allowed to ramble freely around the countryside until, at a certain point, they came to a halt and knelt down, thus indicating the most suitable place to build the temple.
<G-vec00213-002-s154><halt.bleiben><de> Der Fotograf hockte auf ein Knie abgestützt da, ein Auge am Sucher, als zwei sehr große, arabisch aussehende Männer hinter ihm stehen blieben und mich über seinen Rücken hinweg ansprachen.
<G-vec00213-002-s154><halt.bleiben><en> He had dropped to one knee, with one eye glued to the eyepiece, when two very large men of Arab appearance drew to a halt behind him and addressed me over his back.
<G-vec00251-002-s171><keep.bleiben><de> Ein Urlaub mit Internet ist heutyutage sehr nützlich, nicht nur für die Arbeit, aber manchmal auch in Verbindung mit alle zu bleiben.
<G-vec00251-002-s171><keep.bleiben><en> A holiday with internet is nowadays very useful, not only to work but sometimes also to keep in touch with everyone.
<G-vec00251-002-s172><keep.bleiben><de> Bleiben Sie mit Ihren Verbrauch auf dem Laufenden mit einer aktualisierten Anrufliste.
<G-vec00251-002-s172><keep.bleiben><en> Keep up with your usage with an updated call history.
<G-vec00251-002-s173><keep.bleiben><de> Kleine und empfindliche Artikel bleiben durch die serienmäßig eingebauten Spannbänder in den Regalen auch während der Fahrt zuverlässig geschützt.
<G-vec00251-002-s173><keep.bleiben><en> The shelves are fitted with tensioning straps as standard to keep small and fragile items secure while the vehicle is in motion.
<G-vec00251-002-s174><keep.bleiben><de> Nutzer verwenden Facebook, um mit ihren Freunden in Verbindung zu bleiben, eine unbegrenzte Anzahl an Fotos hochzuladen, Links und Videos zu posten sowie mehr über die Personen zu erfahren, die sie kennenlernen.
<G-vec00251-002-s174><keep.bleiben><en> People use arabfacebook.net to keep up with friends, upload an unlimited number of photos, post links and videos, Articles,Heroes,Polls,Music,Groups,Events,Blog
<G-vec00251-002-s175><keep.bleiben><de> E-Mail-Newsletter, um mit der weltweiten SRF-Familie in Verbindung zu bleiben.
<G-vec00251-002-s175><keep.bleiben><en> Email newsletter to keep connected with the SRF community worldwide
<G-vec00251-002-s176><keep.bleiben><de> Bleiben Sie mit James über seine Website, über Facebook und über Soundcloud in Verbindung.
<G-vec00251-002-s176><keep.bleiben><en> Keep up with Jimmy Edgar on his website and Soundcloud.
<G-vec00251-002-s177><keep.bleiben><de> Leistungsstarke Algorithmen - Erfahren Sie mehr über die Welt - Bleiben Sie informiert mit den prudsys eNews.
<G-vec00251-002-s177><keep.bleiben><en> prudsys Realtime Analytics news worldwide - Keep up to date with the prudsys eNews.
<G-vec00251-002-s178><keep.bleiben><de> Kürbisse helfen uns dabei, kräftig und gesund zu bleiben.
<G-vec00251-002-s178><keep.bleiben><en> Pumpkins help keep us strong and healthy.
<G-vec00251-002-s179><keep.bleiben><de> Kein Unternehmen kann selbst über alle Sicherheitsfortschritte auf dem Laufenden bleiben, kein Unternehmen kann intern über die Ressourcen verfügen, um angemessene Sicherheitsprinzipien zu gewährleisten, wenn alle zwei Monate disruptive Technologien den Markt verändern.
<G-vec00251-002-s179><keep.bleiben><en> No one company can keep up to date with security advancements, no one company can have the resources internally to guarantee appropriate security principles when technology disruption occurs bi-monthly.
<G-vec00251-002-s180><keep.bleiben><de> Über das Internet ist es natürlich um einiges einfacher, mit den Leuten zuhause über Dinge wie Facebook, Email oder Skype in Kontakt zu bleiben, doch es ist einfach nicht dasselbe, wie eine face-to-face Unterhaltung, wie man sie normalerweise gewöhnt ist.
<G-vec00251-002-s180><keep.bleiben><en> With the internet, it’s a lot simpler to keep in touch with these people through programs and sites like Facebook, email, or Skype, but it’s a lot different than the face-to-face interaction that you may be used to on a regular basis.
<G-vec00251-002-s181><keep.bleiben><de> Durch diesen zusätzlichen Schutz bleiben Ihre Haare gesund und glänzend.
<G-vec00251-002-s181><keep.bleiben><en> This gives added protection and thus helps to keep your hair healthy and shiny.
<G-vec00251-002-s182><keep.bleiben><de> Es kann ganz hilfreich sein, während des Übersetzungsvorgangs bei einer Sprache zu bleiben.
<G-vec00251-002-s182><keep.bleiben><en> In any case, it can be helpful to keep to a language, while you are in the translation process.
<G-vec00251-002-s183><keep.bleiben><de> Die Neuankömmlinge im Norden können nicht die ausschließlich fleischhaltige Ernährungsweise aufnehmen, die das Land bietet, sondern brauchen eine Menge Unterstützung der Außenweltin Form von Komfort und spezieller Nahrung, um gesund und glücklich zu bleiben.
<G-vec00251-002-s183><keep.bleiben><en> City's anniversary celebration These newcomers cannot cope with the all-meat diet which the land provides and they need a lot of support from the outside world to keep them healthy and happy, in the form of special food and comforts.
<G-vec00251-002-s184><keep.bleiben><de> Sie können Hochgeschwindigkeits-WLAN-Internetzugang (kostenlos) im DoubleTree by Hilton Hotel Edinburgh City Centre nutzen, um online zu bleiben.
<G-vec00251-002-s184><keep.bleiben><en> You can use wireless high-speed Internet access (complimentary) of DoubleTree by Hilton Hotel Edinburgh City Centre to keep connected.
<G-vec00251-002-s185><keep.bleiben><de> Dank dem kostenfreien WLAN in den öffentlichen Bereichen werfen Sie ganz in Ruhe einen Blick in Ihre E-Mails und bleiben auf dem Laufenden.
<G-vec00251-002-s185><keep.bleiben><en> Check your email or keep up with current affairs with the free Wi-Fi access available in public areas of the hotel.
<G-vec00251-002-s186><keep.bleiben><de> Die Evangelisten haben es unterlassen, die unvorstellbare Peinigung eines solchen Geschehens zu veranschaulichen, und auch wir wollen bei der nüchternen, sachlichen Wiedergabe des Geschehens bleiben.
<G-vec00251-002-s186><keep.bleiben><en> The evangelists refrained from illustrating the unimaginable torture of such an event, and we too will keep to a sober, objective portrayal of the events.
<G-vec00251-002-s187><keep.bleiben><de> Nachdem du deinen Fahrer ausgewählt hast, musst du bei deiner Auswahl bis zum Ende des Spiels bleiben.
<G-vec00251-002-s187><keep.bleiben><en> Upon selecting your pilot, you'll need to keep the selection until the end of the entire match.
<G-vec00251-002-s188><keep.bleiben><de> Ja, die geschaffene Ordnung mag in einem unvollkommenen Status sein, voller Verletzung und Schmerz und damit kämpfend, auf Kurs zu bleiben.
<G-vec00251-002-s188><keep.bleiben><en> Yes, the created order might be in an imperfect state, full of hurt and pain, struggling to keep on course.
<G-vec00251-002-s189><keep.bleiben><de> Ich versuchte zuerst ihn einzuholen, empfand es aber bald als normal drei Schritte hinter ihm zu bleiben.
<G-vec00251-002-s189><keep.bleiben><en> I first tried to catch up with him, but soon found it reasonable to keep three steps behind him.
<G-vec00254-002-s428><affect.bleiben><de> Sollte eine Bestimmung der Benutzungsbedingungen unwirksam oder Undurchführbar werden, bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s428><affect.bleiben><en> Should any provision of the Terms of Use be deemed invalid or incapable of being realized, this shall not affect the validity of the remaining provisions.
<G-vec00254-002-s429><affect.bleiben><de> Alle Arendal Sound Lautsprecher kommen mit einem gelochten Metallgitter für ein freies Durchströmen der Schallwellen, damit die hohe Klangqualität erhalten bleibt.
<G-vec00254-002-s429><affect.bleiben><en> For all Arendal Sound speakers we have made a free flowing, perforated metal grill which does not affect sound quality.
<G-vec00254-002-s430><affect.bleiben><de> Sollte eine Bestimmung dieser Bedingungen unwirksam sein, so bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s430><affect.bleiben><en> If a provision of these terms and condition becomes null and void, this shall not affect the validity of the remaining provisions.
<G-vec00254-002-s431><affect.bleiben><de> 8.1 Sollte eine Bestimmung dieser AGB unwirksam sein oder werden, so bleibt die Rechtswirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s431><affect.bleiben><en> 8.1 Should any provision of these GTC be or become invalid, this shall not affect the legal validity of the remaining provisions.
<G-vec00254-002-s432><affect.bleiben><de> Sollten einzelne Bestimmungen unserer Verträge mit dem Käufer/Besteller oder dieser AGB ganz oder teilweise unwirksam sein oder werden, bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s432><affect.bleiben><en> Should individual provisions of our agreements with the buyer/ customer or these GTCs be or become wholly or partially invalid, this shall not affect the validity of the remaining provisions.
<G-vec00254-002-s433><affect.bleiben><de> Sollte eine Bestimmung dieser Nutzungsbedingungen unwirksam sein, so bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s433><affect.bleiben><en> If any provision of these terms and conditions of use are invalid, this shall not affect the validity of the remaining provisions hereof.
<G-vec00254-002-s434><affect.bleiben><de> 10.2 Ist eine Bestimmung des Vertrags und/oder dieser Allgemeinen Geschäftsbedingungen ganz oder teilweise unwirksam, so bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s434><affect.bleiben><en> 10.2 Should any provision of the contract and/or of these General Terms and Conditions be fully or partially invalid, this shall not affect the validity of the other provisions.
<G-vec00254-002-s435><affect.bleiben><de> Sollten einzelne Bestimmungen dieser AGB unwirksam sein oder werden, so bleibt die Wirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s435><affect.bleiben><en> If individual regulations of these standard business conditions should be or become totally or partly ineffective, this does not affect the validity of the remaining regulations.
<G-vec00254-002-s437><affect.bleiben><de> Sollte eine Bestimmung dieser Bedingungen von einem entsprechend zuständigen Gericht für ungültig befunden werden, so bleibt die Gültigkeit der übrigen Bestimmungen dieser Bedingungen von der Ungültigkeit dieser Bestimmung unberührt.
<G-vec00254-002-s437><affect.bleiben><en> If any provision of these Terms and Conditions is found to be invalid by any court having competent jurisdiction, the invalidity of such provision shall not affect the validity of the remaining provisions of these Terms and Conditions, which shall remain in full force and effect.
<G-vec00254-002-s438><affect.bleiben><de> Der Verkäufer ist berechtigt, die Art der gewählten Nacherfüllung zu verweigern, wenn sie nur mit unverhältnismäßigen Kosten möglich ist und die andere Art der Nacherfüllung ohne erhebliche Nachteile für den Verbraucher bleibt.
<G-vec00254-002-s438><affect.bleiben><en> We are entitled to refuse the method of subsequent improvement if the costs are disproportionate to the value of the goods and an alternate method does not adversely affect the customer.
<G-vec00254-002-s439><affect.bleiben><de> Wird eine der Bestimmungen im vorliegenden Dokument von einem zuständigen Gericht für ungültig erklärt, bleibt die Gültigkeit der verbleibenden Bestimmungen davon unberührt.
<G-vec00254-002-s439><affect.bleiben><en> If any provision of these Terms is found to be invalid by any court having competent jurisdiction, the invalidity of such provision shall not affect the validity of the remaining provisions of these Terms, which shall remain in full force and effect.
<G-vec00254-002-s440><affect.bleiben><de> Sollte eine Bestimmung dieser Vereinbarung für ungültig erklärt werden, bleibt die Gültigkeit der übrigen Teile dieser Vereinbarung davon unberührt.
<G-vec00254-002-s440><affect.bleiben><en> If any provision of this Agreement is ruled invalid, such invalidity shall not affect the validity of the remaining portions of this Agreement.
<G-vec00254-002-s441><affect.bleiben><de> Durch den Widerruf bleibt die Rechtmäßigkeit der aufgrund der Einwilligung bis zum Widerruf erfolgten Verarbeitungen unberührt.
<G-vec00254-002-s441><affect.bleiben><en> The cancellation does not affect the lawfulness of the data pro-cessing that took place based on the declaration of consent up until the objection.
<G-vec00254-002-s442><affect.bleiben><de> Wenn der vorliegende Vertrag eine Lücke enthält oder eine Bestimmung ganz oder teilweise unwirksam ist oder wird, so bleibt der Vertrag im Übrigen wirksam.
<G-vec00254-002-s442><affect.bleiben><en> If this contract contains an omission or a provision is or becomes invalid in whole or in part, this will not affect the validity of the remaining provisions hereof.
<G-vec00254-002-s443><affect.bleiben><de> §11 Teilunwirksamkeit Bei Unwirksamkeit einzelner Teile bleibt die Geltung der übrigen Bestimmungen erhalten.
<G-vec00254-002-s443><affect.bleiben><en> If any term of this agreement is or becomes invalid, the validity of the contract will not affect the remainder hereof.
<G-vec00254-002-s444><affect.bleiben><de> Sollten einzelne Bestimmungen dieses Vertrages unwirksam oder undurchführbar sein oder nach Vertragsschluss unwirksam oder undurchführbar werden, bleibt davon die Wirksamkeit des Vertrages im Übrigen unberührt.
<G-vec00254-002-s444><affect.bleiben><en> Should individual provisions of this Agreement be invalid or unenforceable or become invalid or unenforceable after the Agreement is concluded, this shall not affect the validity of the remaining provisions of the Agreement.
<G-vec00254-002-s445><affect.bleiben><de> Wird eine dieser Bestimmungen für ungültig, nichtig oder aus irgendeinem Grund undurchführbar befunden, so bleibt die Gültigkeit und Durchführbarkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s445><affect.bleiben><en> If any of these conditions shall be deemed invalid, void, or for any reason unenforceable, that condition shall be deemed severable and shall not affect the validity and enforceability of any remaining condition.
<G-vec00254-002-s446><affect.bleiben><de> Sollte eine Bestimmung der zwischen dem Kunden und der Wüest Partner AG abgeschlossenen Vereinbarung unwirksam oder nichtig werden, so bleibt die Rechtswirksamkeit der übrigen Bestimmungen hiervon unberührt.
<G-vec00254-002-s446><affect.bleiben><en> Should a provision of the agreement concluded between the client and Wüest Partner AG become ineffective or void, this shall not affect the validity of the remaining provisions.
<G-vec00261-002-s133><continue.bleiben><de> Einfach genial und ein Blickfang der nicht ohne Kommentar bleibt.
<G-vec00261-002-s133><continue.bleiben><en> Simply brilliant and eye-catching does not continue without comment.
<G-vec00261-002-s134><continue.bleiben><de> Wenn ein Teil oder Teile dieser Schiedsvereinbarung von einem zuständigen Gericht für ungültig oder nicht durchsetzbar erklärt werden, außer wie in Abschnitt 10(d) vorgesehen, sind diese Teile oder Teile weder rechtskräftig noch wirksam, aber der Rest der Schiedsvereinbarung bleibt in vollem Umfang in Kraft und Wirkung.
<G-vec00261-002-s134><continue.bleiben><en> If any part or parts of this Arbitration Agreement are found under the law to be invalid or unenforceable by a court of competent jurisdiction, then such specific part or parts shall be of no force and effect and shall be severed and the remainder of the Agreement shall continue in full force and effect.
<G-vec00261-002-s135><continue.bleiben><de> Wir rechnen daher damit, dass die fiskalische Unterstützung stark genug bleibt, damit Arbeitnehmer und Unternehmen den Wachstumseinbruch überleben.
<G-vec00261-002-s135><continue.bleiben><en> Accordingly, we expect fiscal support to continue to the degree necessary to allow workers and businesses to survive the collapse in growth.
<G-vec00261-002-s136><continue.bleiben><de> Johannes 8:31,32 Wenn ihr in meinem Wort bleibt, so seid ihr wahrhaftig meine Jünger und werdet die Wahrheit erkennen, und die Wahrheit wird euch frei machen.
<G-vec00261-002-s136><continue.bleiben><en> John 8: 31 If ye continue in my word, then are ye my disciples indeed; 32 And ye shall know the truth, and the truth shall make you free.
<G-vec00261-002-s137><continue.bleiben><de> Und im Kern basieren beide Erfolgsgeschichten auf der gleichen Haltung: „Tradition bedeutet nicht, dass man immer beim Alten bleibt.
<G-vec00261-002-s137><continue.bleiben><en> Both success stories are based on the same mindset: “Tradition does not mean you always have to continue your old ways.
<G-vec00261-002-s138><continue.bleiben><de> Wir brauchen diese gemeinsame Erinnerung – wenn wir uns dauerhaft gegeneinander definieren, bleibt es schwierig, eine gemeinsame, friedliche Zukunft zu schaffen und zu garantieren.
<G-vec00261-002-s138><continue.bleiben><en> We need this shared remembrance – if we define ourselves in contrast to one another in perpetuity, it will continue to be difficult to achieve and build a common, peaceful future.
<G-vec00261-002-s139><continue.bleiben><de> Wenn ein zuständiges Gericht aus irgendeinem Grund feststellt, dass eine Bestimmung dieser Bedingungen oder eines Teils davon nicht durchsetzbar ist, wird diese Bestimmung im maximal zulässigen Umfang durchgesetzt, um die Absicht dieser Bedingungen zu verwirklichen, und der Rest dieser Bedingungen bleibt in vollem Umfang in Kraft und Wirkung.
<G-vec00261-002-s139><continue.bleiben><en> Severability. If any part or parts of this Arbitration Agreement are found under the law to be invalid or unenforceable by a court of competent jurisdiction, then such specific part or parts shall be of no force and effect and shall be severed and the remainder of the Terms shall continue in full force and effect.
<G-vec00261-002-s140><continue.bleiben><de> Es bleibt jedoch noch viel zu tun, um die Luftverschmutzung zu senken und die Ziele der Europäischen Union für 2030 und darüber hinaus zu erfüllen.
<G-vec00261-002-s140><continue.bleiben><en> But more work is needed to continue to reduce pollution levels and meet European Union targets for 2030 and beyond.
<G-vec00261-002-s141><continue.bleiben><de> Zur Einziehung der Forderung bleibt der Käufer neben uns ermächtigt.
<G-vec00261-002-s141><continue.bleiben><en> Besides us, the customer shall continue to be authorised to collect the receivables.
<G-vec00261-002-s142><continue.bleiben><de> Wenn ein Client keine Sicherheit anfordert, kann der FTPS-Server entweder zulassen, dass der Client unsicher bleibt, oder die Verbindung ablehnen.
<G-vec00261-002-s142><continue.bleiben><en> If a client does not request security, the FTPS server can either allow the client to continue insecure or refuse/limit the connection.
<G-vec00261-002-s143><continue.bleiben><de> Falls ein zuständiges Gericht, gleich aus welchem Grund, feststellt, dass irgendeine Bestimmung der Vereinbarung oder ein Teil derselben nicht einklagbar ist, ist die betreffende Bestimmung im maximal möglichen Umfang geltend zu machen, wie es der Absicht der Vereinbarung entspricht, und der Rest dieser Vereinbarung bleibt in vollem Umfang in Kraft.
<G-vec00261-002-s143><continue.bleiben><en> If for any reason a court of competent jurisdiction finds any provision of this Agreement or portion thereof, to be unenforceable, that provision shall be enforced to the maximum extent permissible in order to give effect to the intent of this Agreement, and the remainder of this Agreement shall continue in full force and effect. 14.
<G-vec00261-002-s144><continue.bleiben><de> 28Und nun, Kinder, bleibt in ihm, damit wir, wenn er offenbart wird, Zuversicht haben und nicht zuschanden werden vor ihm, wenn er kommt.
<G-vec00261-002-s144><continue.bleiben><en> 28 And now, dear children, continue in union with Him; so that, if He re-appears, we may have perfect confidence, and may not shrink away in shame from His presence at His Coming.
<G-vec00261-002-s145><continue.bleiben><de> Auch in der dritten Staffel von „House of Cards“ bleibt sich Frank Underwood, der Mann mit den Fuck-You-Initialen FU, treu.
<G-vec00261-002-s145><continue.bleiben><en> One thing is certain, in House of Cards’ third season, Frank Underwood will continue to stick to his guns.
<G-vec00261-002-s146><continue.bleiben><de> 1 Der Mensch, vom Weibe geboren, lebt kurze Zeit und ist voll Unruhe, 2 geht auf wie eine Blume und fällt ab, flieht wie ein Schatten und bleibt nicht.
<G-vec00261-002-s146><continue.bleiben><en> 1 For a mortal born of a woman is short lived, and full of wrath. 2 Or he falls like a flower that has bloomed; and he departs like a shadow, and can’t continue.
<G-vec00261-002-s147><continue.bleiben><de> All euer Verlust wird euch in der Auferstehung wettgemacht werden, sofern ihr treu bleibt.
<G-vec00261-002-s147><continue.bleiben><en> All your losses will be made up to you in the resurrection, provided you continue faithful.
<G-vec00261-002-s148><continue.bleiben><de> Sollten eine oder mehrere Bestimmungen des Vertrags einschließlich dieser AGB ganz oder teilweise unwirksam sein oder werden, oder der Vertrag eine Lücke enthalten, so bleibt die Wirksamkeit des Vertrages im Übrigen hiervon unberührt.
<G-vec00261-002-s148><continue.bleiben><en> If any provision of the contract, including these T&C, are or become fully or partially unenforceable or invalid under applicable law, such provision shall be ineffective only to the extent of such unenforceability or invalidity and the remaining provisions of the contract or the T&C, respectively, shall continue to be binding and in full force and effect.
<G-vec00261-002-s149><continue.bleiben><de> „China ist und bleibt einer der wichtigsten Brückenköpfe im Zuge des Ausbaus unseres interkontinentalen Netzwerks“, sagt Thomas Reuter, Geschäftsführer Dachser Air & Sea Logistics.
<G-vec00261-002-s149><continue.bleiben><en> “China is and will continue to be a key bridgehead for the expansion of our intercontinental network,” says Thomas Reuter, managing director of Dachser Air & Sea Logistics.
<G-vec00261-002-s150><continue.bleiben><de> Die Einkommensteuerbelastung bleibt bei 16 %.
<G-vec00261-002-s150><continue.bleiben><en> The personal income tax payable will continue to be 16%.
<G-vec00261-002-s151><continue.bleiben><de> Die Farben bleiben optimal erhalten, das Gebäude bleibt im Ursprungszustand und verblasst nicht.
<G-vec00261-002-s151><continue.bleiben><en> The colours are maintained optimally, so the building will continue to appear as originally intended without fading.
<G-vec00261-002-s165><persist.bleiben><de> Das Umfeld im Öl- und Gasmarkt bleibt anspruchsvoll.
<G-vec00261-002-s165><persist.bleiben><en> Headwinds from the oil and gas market persist.
<G-vec00261-002-s166><persist.bleiben><de> Die erfrischende Säure unterstützt die Explosion von Aromen, die elegant im Nachgeschmack bleibt.
<G-vec00261-002-s166><persist.bleiben><en> The refreshing acidity sustains the burst of flavours, which elegantly persist in the aftertaste.
<G-vec00261-002-s167><persist.bleiben><de> Gameplay Behoben – Das Fadenkreuz des Gerätes bleibt nach dem Wechsel zum Drohnenwurf.
<G-vec00261-002-s167><persist.bleiben><en> Gameplay Fixed - The gadget crosshair will persist after switching to drone toss.
<G-vec00261-002-s133><stick.bleiben><de> Sie benutzt Lipgloss in allen Farben aber keinen Lippenstift, die Hälfte bleibt sowieso am Flaschenrand hängen und wird nach 12 Stunden Club Tour bröckelig.
<G-vec00261-002-s133><stick.bleiben><en> She only uses lip gloss in different colors, but no lipstick because half of the lipstick would stick to the bottle anyway. After 12 hours of clubbing, the lipstick will dry out or be gone.
<G-vec00261-002-s134><stick.bleiben><de> Im Fußgängermodus korrigiert das GPS das Signal nicht künstlich, damit es auf der Straße bleibt, es hat keine Markierungen, so dass Sie die aktuelle Position sehen können.
<G-vec00261-002-s134><stick.bleiben><en> In pedestrian mode, the GPS does not artificially correct the signal to stick to the road, it has no markings, so you can see the actual position.
<G-vec00261-002-s135><stick.bleiben><de> Mal sehen, ob die Argumentationsweise des Durchschnittskneipenbesuchers sich entsprechend ändert - oder ob er dickköpfig beim Alten bleibt.
<G-vec00261-002-s135><stick.bleiben><en> We shall see whether the style of argumentation of the average pub patron will now change appropriately - or whether he will stubbornly stick to his ways.
<G-vec00261-002-s136><stick.bleiben><de> Die Marke AVENTICS™ bleibt erhalten – sie ist Teil des Themenbereichs Fluid Control & Pneumatics von Emerson Automation Solutions.
<G-vec00261-002-s136><stick.bleiben><en> The AVENTICS™ brand will stick around as part of the Fluid Control & Pneumatics areas of Emerson Automation Solutions.
<G-vec00261-002-s137><stick.bleiben><de> Allerdings bleibt oftmals im Berufsalltag das „Sie“ selbst nach vielen Jahren der Zusammenarbeit unter Kollegen oder mit dem Chef üblich.
<G-vec00261-002-s137><stick.bleiben><en> However, it is still very common to stick with the formal “Sie” at work, even after working with colleagues and managers for many years.
<G-vec00261-002-s138><stick.bleiben><de> Denn oftmals bleibt es für die neuen Unbekannten bei einer, höchstens zwei Saisons, um danach wieder für immer aus dem Radar der Berliner Modelandschaft zu verschwinden.
<G-vec00261-002-s138><stick.bleiben><en> Because often the new unknown only stick around for one, tops two seasons, to then disappear for ever out of the radar of the fashion scape of Berlin.
<G-vec00261-002-s139><stick.bleiben><de> Bleibt mit Jesus.
<G-vec00261-002-s139><stick.bleiben><en> Stick with Jesus.
<G-vec00261-002-s140><stick.bleiben><de> Der beständige Speicherbereich auf dem USB-Stick bleibt erhalten.
<G-vec00261-002-s140><stick.bleiben><en> The persistent storage on the USB stick will be preserved.
<G-vec00261-002-s141><stick.bleiben><de> Während es für die Industrieproduktion insgesamt also bei unserer bisherigen Prognose bleibt, haben wir die Veröffentlichung der Quartalsergebnisse zum Anlass genommen, unseren Ausblick für einzelne Industriebranchen für 2014 anzupassen.
<G-vec00261-002-s141><stick.bleiben><en> While we stick to our forecast for industrial production as a whole, the publication of Q1 data has induced us to adjust our 2014 outlook for individual sectors.
<G-vec00261-002-s142><stick.bleiben><de> Romantisch und ladylike: Bleibt in den gleichen Farben und Nuancen (beige oder rosa) für eine extra Portion Eleganz.
<G-vec00261-002-s142><stick.bleiben><en> Romantic and ladylike: Stick to the same colors and shades (beige or rose) for an extra portion of classiness.
<G-vec00261-002-s143><stick.bleiben><de> Dieses Phänomen wurde mir zum ersten Mal in dem fantastischen Buch “Was bleibt” von Chip und Dan Heath klar.
<G-vec00261-002-s143><stick.bleiben><en> I first came across this phenomenon in the fantastic book by Chip and Dan Heath called Made to Stick.
<G-vec00261-002-s144><stick.bleiben><de> Wenn Du in die Welt hinausgehst, pass auf den Verkehr auf, haltet euch an den Händen und bleibt zusammen.
<G-vec00261-002-s144><stick.bleiben><en> * When you go out in the world, watch out for traffic, hold hands and stick together.
<G-vec00261-002-s145><stick.bleiben><de> Deshalb ist es wichtig, dass der Nutzer so lange wie möglich bei uns bleibt.
<G-vec00261-002-s145><stick.bleiben><en> Therefore we need the user to stick with us as long as possible.
<G-vec00261-002-s146><stick.bleiben><de> Bleibt nah an eurem Team und ihr habt eine größere Chance auf Erfolg.
<G-vec00261-002-s146><stick.bleiben><en> Stick close to your squad, and you’ll have a greater chance at success.
<G-vec00261-002-s147><stick.bleiben><de> Dass seitdem auch vermehrt Promos ins Haus flattern, ist zwar ebenso ein Grund zur Freude, letztlich aber bleibt die Clique doch unter sich.
<G-vec00261-002-s147><stick.bleiben><en> Although they have since then experienced an increased influx of promos, which is also a reason for joy, the clique would rather stick to one another.
<G-vec00261-002-s148><stick.bleiben><de> Moderne Kundenansprache für den Handel Es erscheint fast wie ein Anachronismus: Während sich der Handel selbst zunehmend im Internet abspielt und die eTailer dem stationären Einzelhandel immer größere Marktanteile streitig machen, bleibt der deutsche Handel bei der...
<G-vec00261-002-s148><stick.bleiben><en> It almost seems like an anachronism: while retailing increasingly takes place on the Internet and e-tailers are taking away more and more market shares from brick and mortar retailers, the German retail market prefers to stick with traditional types...
<G-vec00261-002-s149><stick.bleiben><de> Im Bereich der taktischen Granaten könnt ihr eine Rauchgranate freischalten, die für alle Betroffenen die Minikarte vernebelt, oder ihr bleibt bei der zuverlässigen Erschütterungsgranate, die Feinde je nach Nähe zum Zentrum der Explosion 2 - 4 Sekunden lang betäubt.
<G-vec00261-002-s149><stick.bleiben><en> As for tactical grenades, you can unlock a smoke grenade that obscures the mini-map for anyone caught inside, or stick with the old reliable concussion grenade that will daze enemies for 2-4 seconds, depending on how close they are to the explosion.
<G-vec00261-002-s150><stick.bleiben><de> Überlegen Sie sich, ob Sie die Petition nicht offline persönlich übergeben möchten, arrangieren Sie ein Treffen, veranstalten Sie einen Event, der im Gedächtnis bleibt und die Medien auf den Plan ruft, oder alles andere, was Ihnen einfällt.
<G-vec00261-002-s150><stick.bleiben><en> Consider taking the petition offline for an in-person delivery, arranging a meeting, doing a stunt to stick in their memory or get media attention, and anything else you can think of. KEEP GOING
<G-vec00261-002-s151><stick.bleiben><de> Nachdem neben weiteren Firmen bereits Magura, Fox und Shimano seit Anfang 2013 größere Rückrufaktionen gestartet haben, bleibt die letzte Saison vielen Brancheninsidern als eigentliches Pannenjahr in Erinnerung.
<G-vec00261-002-s151><stick.bleiben><en> After important product recalls of many companies including Magura, Fox and Shimano 2013 since the beginning of 2013, the last season will stick in mind to many insiders of the sector as a year of mishaps.
<G-vec00308-002-s094><reside.bleiben><de> Während die Gesamtheit des Copyrights weit über die Möglichkeiten dieses Dokuments hinausgeht, sind einige grundsätzlichen Dinge doch nötig: Unter dem momentanen Copyright Gesetz sind Copyrights bei Erschaffung eines neuen Produkts automatisch eingeschlossen und bleiben beim Autor bis es anders deklariert wird.
<G-vec00308-002-s094><reside.bleiben><en> While the overall subject of copyright law is far beyond the scope of this document, some basics are in order. Under the current copyright law, copyrights are implicit in the creation of a new work and reside with the creator, unless otherwise assigned.
<G-vec00308-002-s095><reside.bleiben><de> Provisorische Aufnahme: Personen, auf deren Asylantrag nicht eingetreten wird, deren Rückschaffung aber unmöglich ist, weil Krieg herrscht oder ein Verstoss gegen internationale Konventionen vorliegt, können mit einer Bewilligung F vorübergehend in der Schweiz bleiben.
<G-vec00308-002-s095><reside.bleiben><en> Provisional acceptance: People whose applications for asylum are not considered but who are unable to return to their country of origin due to war or a violation of the international convention can reside temporarily in Switzerland with an F permit.
<G-vec00308-002-s096><reside.bleiben><de> Als neu angekommene/-r Arbeitssuchende/-r dürfen Sie zur Arbeitssuche bis zu 6 Monaten in diesem Land bleiben - und länger, wenn Sie nachweisen können, dass Sie weiterhin nach einem Arbeitsplatz suchen und gute Aussichten auf Erfolg haben.
<G-vec00308-002-s096><reside.bleiben><en> As a newly-arrived jobseeker, you have a right to reside in that country to look for work for up to 6 months - and longer, if you can prove you're still looking for a job and have a good chance of finding one.
<G-vec00325-002-s114><spend.bleiben><de> Ich war nicht in der Lage neun Monate in Taiwan zu bleiben und war ziemlich frustriert, dass keine ENRAC CMT Ärzte in Europa waren.
<G-vec00325-002-s114><spend.bleiben><en> I was unable to spend nine months in Taiwan and was very frustrated that there were no Enrac CMT practitioners anywhere in Europe.
<G-vec00325-002-s115><spend.bleiben><de> Acht Wochen bleiben die Patienten stationär in Eggenburg zur Therapie.
<G-vec00325-002-s115><spend.bleiben><en> Patients spend eight weeks in Eggenburg for therapy.
<G-vec00325-002-s116><spend.bleiben><de> Wenn du weniger als 30 Tage in Kambodscha bleiben möchtest, kannst du ohne Visum in das Land einreisen.
<G-vec00325-002-s116><spend.bleiben><en> If you will spend up no longer than 30 days volunteering in Zambia you need to apply for a visitor visa.
<G-vec00325-002-s117><spend.bleiben><de> Wir bleiben einen zweiten Tag bei den freundlichen und liebenswerten Waldnomaden.
<G-vec00325-002-s117><spend.bleiben><en> We will spend a second day with the friendly forest nomads.
<G-vec00325-002-s118><spend.bleiben><de> Die meiste Zeit würden sie in ihren eigenen Zimmern bleiben, oder Asuka wäre im Garten, während Shinji ein bisschen im Haus putzen würde, oder er würde fischen gehen, oder sie würde in die Stadt gehen um Vorräte zu holen, oder...
<G-vec00325-002-s118><spend.bleiben><en> Most of the time they would spend in their respective rooms, or Asuka would be in the garden while Shinji did some cleaning in the house, or he would go fishing, or she would go to the city for supplies, or...
<G-vec00325-002-s119><spend.bleiben><de> 1 Nacht musste ich noch bleiben und danach bin ich so schnell wie möglich weggegangen.
<G-vec00325-002-s119><spend.bleiben><en> I had to spend one night there, after that i left as quickly as possible.
<G-vec00325-002-s120><spend.bleiben><de> Eigentümer von Freizeiteinrichtungen, in denen Besucher mindestens eine Nacht bleiben, haben oft mehrere Einrichtungen an ihrem Standort.
<G-vec00325-002-s120><spend.bleiben><en> As a result, the proprietors of establishments where guests generally spend at least one night often equip their site with various facilities.
<G-vec00325-002-s121><spend.bleiben><de> Nach der Rennsaison 2016 konnte sich Vero den Flug zurück nach Neuseeland nicht leisten und entschied sich, den Winter zum Arbeiten in Wales zu bleiben.
<G-vec00325-002-s121><spend.bleiben><en> After racing the 2016 season, Vero couldn’t afford the flight back home to New Zealand and decided to spend the off-season working in South Wales.
<G-vec00325-002-s122><spend.bleiben><de> Eigentlich wollte er nur ein bis zwei Jahre am Main bleiben.
<G-vec00325-002-s122><spend.bleiben><en> Actually, he only wanted to spend between one and two years in Frankfurt am Main.
<G-vec00325-002-s123><spend.bleiben><de> Schuhe, Schneemobil-Overall, Mütze und Handschuhe – damit wir draußen bleiben können, ohne zu frieren.
<G-vec00325-002-s123><spend.bleiben><en> Shoes and snowmobile overall, hat and gloves, so we can spend time outdoors without being cold.
<G-vec00325-002-s124><spend.bleiben><de> Einige kommen dort gut zurecht, bleiben vielleicht ein Leben lang.
<G-vec00325-002-s124><spend.bleiben><en> Some expatriates get along there just fine; maybe even spend a lifetime there.
<G-vec00325-002-s125><spend.bleiben><de> Hier werden wir ein bisschen bleiben, um die Felsen zu erkunden.
<G-vec00325-002-s125><spend.bleiben><en> Here we will spend some time exploring the cliffs.
<G-vec00325-002-s126><spend.bleiben><de> Nach einer Schulterverletzung und mit Arthrose in den Beinen wird er sein Leben lang bei uns bleiben und darf sein Rentnerleben auf der Weide genießen.
<G-vec00325-002-s126><spend.bleiben><en> Due to a shoulder injury and proceeding arthrosis in his legs, Loki will spend the rest of his life with us and may spend his retirement on the meadow.
<G-vec00325-002-s127><spend.bleiben><de> Wir machen uns abends ein leckeres Hühnerfrikassee und beschließen ein paar Tage in Cherbourg zu bleiben.
<G-vec00325-002-s127><spend.bleiben><en> For dinner we prepare a nice chicken fricassee and decide to spend some days in Cherbourg.
<G-vec00325-002-s128><spend.bleiben><de> Dieser Kurs ist für diejenigen gedacht, die keine oder nur wenige Kenntnisse der spanischen Sprache haben und eine längere Zeit in Spanien (Málaga) bleiben möchten.
<G-vec00325-002-s128><spend.bleiben><en> LONG TERM COURSES These courses are designed for students who wish to spend a longer period in Spain, Malaga and only have a basic level or little knowledge of Spanish.
<G-vec00325-002-s129><spend.bleiben><de> Da antwortete der Levit, der Mann der Frau, die getötet worden war, und sprach: Ich kam mit meiner Nebenfrau nach Gibea in Benjamin, um dort über Nacht zu bleiben.
<G-vec00325-002-s129><spend.bleiben><en> And the Levite, the husband of the woman who was killed, answered and said to them, I came into Gibeah, that belongs to Benjamin, I and my concubine, to spend the night.
<G-vec00325-002-s130><spend.bleiben><de> Ich würde gerne in den ersten Tagen mit dem Kind in der Kinderkrippe bleiben.
<G-vec00325-002-s130><spend.bleiben><en> I would like to spend the first days at the nursery with my child.
<G-vec00325-002-s131><spend.bleiben><de> Heutzutage ist es jedoch für die Beschäftigten normal geworden, nur ein oder zwei Jahre bei einer Firma zu bleiben und dann zu einem anderen Unternehmen zu wechseln, das eine bessere Arbeitskultur bietet.
<G-vec00325-002-s131><spend.bleiben><en> In today’s world, however, it’s common for employees to spend just one or two years at a company before moving onto another opportunity that offers a better work culture.
<G-vec00325-002-s132><spend.bleiben><de> Wenn es sich aber um Leute handelt, die noch fleischlich sind, die Jahrelang in der Gemeinde Jesus Christus bleiben, ohne sich zu verändern, ist es besser für die Frauen, Männer abzulehnen, die weniger gebildet als sie sind; dies wegen des Hochmuts.
<G-vec00325-002-s132><spend.bleiben><en> But when we still have to deal with carnal people who spend years in the Church of Jesus Christ without changing, it will not be advisable for women to get married to men who are less educated than them; this is simply because of pride.
<G-vec00326-002-s190><maintain.bleiben><de> Es ermöglicht uns auch, mit Ihnen in Kontakt zu bleiben, wo auch immer Sie sind.
<G-vec00326-002-s190><maintain.bleiben><en> It also enables us to maintain contact with you wherever you are.
<G-vec00326-002-s191><maintain.bleiben><de> Auch nach Ihrem Abschluss an der TUM können Sie durch Veranstaltungen mit der TUM verbunden bleiben.
<G-vec00326-002-s191><maintain.bleiben><en> Even after graduating from TUM, you can still maintain your connection to the university by attending events here.
<G-vec00326-002-s192><maintain.bleiben><de> Vorbeugend – es zeigt Wege, um dauerhaft im Gleichgewicht zu bleiben.
<G-vec00326-002-s192><maintain.bleiben><en> Preventive – it shows you how to maintain the right balance permanently.
<G-vec00326-002-s193><maintain.bleiben><de> Bei sexueller Erregung eregieren auch die Brustwarzen, die dann auch bis zum Orgasmus eregiert bleiben.
<G-vec00326-002-s193><maintain.bleiben><en> During sexual excitement, the nipples of the breasts become erect and maintain this erection throughout the other phases.
<G-vec00326-002-s194><maintain.bleiben><de> - von dieser Richtlinie ihre Gesellschaften auszunehmen, die nicht während eines ununterbrochenen Zeitraums von mindestens zwei Jahren im Besitz einer Beteiligung bleiben, aufgrund deren sie als Muttergesellschaften gelten, oder an denen eine Gesellschaft eines anderen Mitgliedstaats nicht während eines ununterbrochenen Zeitraums von mindestens zwei Jahren eine solche Beteiligung hält.
<G-vec00326-002-s194><maintain.bleiben><en> (b) not applying this Directive to companies of that Member State, which do not maintain for an uninterrupted period of at least 2 years holdings qualifying them as parent companies, or to those of their companies in which a company of another Member State does not maintain such a holding for an uninterrupted period of at least 2 years.
<G-vec00326-002-s195><maintain.bleiben><de> Du musst pro Tag mindestens 150 Minuten moderat trainieren, um gesund zu bleiben.
<G-vec00326-002-s195><maintain.bleiben><en> At a minimum, you need 150 minutes of moderate exercise each day to maintain your good health.
<G-vec00326-002-s196><maintain.bleiben><de> So vertieft sie gerade ihr Bachelorfach “Vergleichende Kulturwissenschaft” im Masterprogramm; ihr zweites Fach “Bildende Kunst” hat sie abgeschlossen – die Liebe zur Kunst wird ihr jedoch immer bleiben.
<G-vec00326-002-s196><maintain.bleiben><en> Thus, she is deepening her Bachelor’s subject “Comparative Cultural Science” in a Master’s Program; Her second subject “Visual Art and Aesthetic Education” is completed – however, her love of art will always maintain.
<G-vec00326-002-s197><maintain.bleiben><de> Zur Nutzung der Dienste erklären Sie sich bereit, (a) wahrheitsgemäße, genaue, aktuelle und vollständige Angaben zu Ihrer Person (nachstehend "Registrierungsdaten") nach der Vorgabe des Anmeldeformulars zu machen, und (b) diese Registrierungsdaten gegebenenfalls zu aktualisieren, damit sie wahrheitsgemäß, genau, aktuell und vollständig bleiben.
<G-vec00326-002-s197><maintain.bleiben><en> provide true, accurate, current and complete information about yourself as prompted by the PressDoc Service's registration form (the "Registration Data") and maintain and promptly update the Registration Data to keep it true, accurate, current and complete.
<G-vec00326-002-s198><maintain.bleiben><de> Schnelle und reibungslose Unternehmensabläufe sind wichtig für die Kundenzufriedenheit, helfen Kosten zu reduzieren und damit wettbewerbsstark auf dem Markt zu bleiben.
<G-vec00326-002-s198><maintain.bleiben><en> Fast and smooth business processes are important for customer satisfaction, and they help to reduce costs and thus maintain your competitive strength on the market.
<G-vec00326-002-s199><maintain.bleiben><de> LE: Gesetzt den Fall, jemand fühlt sich gesund, möchte aber diese Technologie nutzen um gesund zu bleiben oder noch gesünder zu werden.
<G-vec00326-002-s199><maintain.bleiben><en> LE: Let's say a person who considers him or herself to be healthy desires to use this technology to maintain health and get even healthier.
<G-vec00326-002-s200><maintain.bleiben><de> Wenn du ins Fitnessstudio gehst, mit den öffentlichen Verkehrsmitteln unterwegs bist oder jeden Tag mit kranken Menschen zu tun hast, dann solltest du dich täglich duschen, um ein Ausbreiten von Keimen zu vermeiden und sauber zu bleiben.
<G-vec00326-002-s200><maintain.bleiben><en> If you go to the gym, commute on public transit or come into contact with sick people daily, you should shower every day to avoid the spread of germs and to maintain cleanliness.
<G-vec00326-002-s201><maintain.bleiben><de> Wir bleiben flexibel und passen uns den individuellen Bedürfnissen unserer Partner an.
<G-vec00326-002-s201><maintain.bleiben><en> We maintain flexibility by adapting to the individual needs of our business partners.
<G-vec00326-002-s202><maintain.bleiben><de> Ein Vape Pen ist immer praktisch und ist besonders effektiv, wenn Du unterwegs bist und diskret bleiben willst.
<G-vec00326-002-s202><maintain.bleiben><en> A vape pen is always handy and is particularly effective if you are out and about and want to maintain discretion.
<G-vec00326-002-s203><maintain.bleiben><de> Burns Original Huhn & Reis ist ein komplettes, hochverdauliches, hypoallergenes Hundefutter für erwachsene Hunde (ab 6 Monaten), um gesund zu bleiben.
<G-vec00326-002-s203><maintain.bleiben><en> Burns Chicken & Rice is a complete highly digestible hypo-allergenic diet for adult dogs (from 6 months onwards) to maintain good health.
<G-vec00326-002-s204><maintain.bleiben><de> Einmal eingestellt, wird die Temperatur immer gleich bleiben, egal wie warm oder kalt das Haus oder die Küche ist.
<G-vec00326-002-s204><maintain.bleiben><en> Once set, they will maintain the setting, regardless of how warm or cold your home or kitchen may be.
<G-vec00326-002-s205><maintain.bleiben><de> London wird zwar Europas wichtigstes Finanzzentrum bleiben, aber Frankfurt ist in der Pole Position, wenn es um Verlagerungen in die Eurozone geht.
<G-vec00326-002-s205><maintain.bleiben><en> We believe that London should maintain its position as Europe’s leading financial centre; however, some operations will still need to relocate into the Eurozone. In this regard, Frankfurt is in the pole position.
<G-vec00326-002-s206><maintain.bleiben><de> "Wir bleiben bei unserer Position.
<G-vec00326-002-s206><maintain.bleiben><en> "We maintain our position.
<G-vec00326-002-s207><maintain.bleiben><de> Das Dispergiermittel fungiert als Stabilisator und sorgt dafür, dass die Pigmente in der Tätowiertinte gleichmäßig gelöst und dispergiert bleiben und verhindert eine Verklumpen der Pigmente.
<G-vec00326-002-s207><maintain.bleiben><en> The dispersing agent or dissolvent functions as a stabilizer and ensures that the pigments in the tattoo ink maintain in an evenly dissolved or suspended status.
<G-vec00326-002-s208><maintain.bleiben><de> Er wird dem Unternehmen langfristig als Aufsichtsrat und als einer der Hauptaktionäre verbunden bleiben.
<G-vec00326-002-s208><maintain.bleiben><en> will maintain close ties to the company as a Supervisory Board member and as a major shareholder on a long-term basis.
<G-vec00340-002-s111><sustain.bleiben><de> Ich habe David gefunden, meinen Knecht – mit meinem heiligen Öl habe ich ihn gesalbt –, mit dem meine Hand fest bleiben soll, und mein Arm soll ihn stärken.
<G-vec00340-002-s111><sustain.bleiben><en> I have found David my servant; with my sacred oil I have anointed him. My hand will sustain him; surely my arm will strengthen him.
<G-vec00340-002-s112><sustain.bleiben><de> Wie wir bereits erwähnt haben, brauchen die Menschen Propheten und Gesandte, genauso wie sie Speise und Trank benötigen, um bestehen zu bleiben.
<G-vec00340-002-s112><sustain.bleiben><en> As we mentioned previously, people are in need of Prophets and Messengers as they are in need of food and drink to sustain themselves.
<G-vec00340-002-s113><sustain.bleiben><de> Erfolgreiche Business Relationship Manager zeichnen sich durch ausgeprägte Kommunikations-, Beratungs- und Verhandlungsfähigkeit sowie die persönliche Stärke aus, auch in schwierigen Situationen glaubwürdig, empathisch und vertrauenswürdig zu bleiben.
<G-vec00340-002-s113><sustain.bleiben><en> Successful BRMs have strong communication, consulting and negotiating skills, as well as the personal power needed to sustain credibility, empathy and trust, even while coping with difficult situations.
<G-vec00367-002-s027><restrain.bleiben><de> Hätte sie nur in ihr bleiben können.
<G-vec00367-002-s027><restrain.bleiben><en> Perhaps she might have been just able to restrain herself.
<G-vec00370-002-s023><lag.bleiben><de> Teilweise bleiben die Frameraten sogar hinter denen der DDR3-Varianten zurück, was aber je nach Game und Prozessor im Vergleichsgerät auch an einer CPU-Limitierung wegen der nur zwei physisches Cores des i7 im Testgerät liegen kann.
<G-vec00370-002-s023><lag.bleiben><en> The frame rates sometimes even lag behind the DDR3 versions, but depending on the game and the processor in the comparison device, it could also be due to a CPU limitation on account of the only two physical cores of the i7 in the review sample.
<G-vec00370-002-s024><lag.bleiben><de> Die Ärmeren bleiben immer weiter hinter den Reicheren zurück, wenn es um die Lebenserwartung geht.
<G-vec00370-002-s024><lag.bleiben><en> The poor lag farther and farther behind when it comes to life expectancy.
<G-vec00394-002-s152><remain.bleiben><de> Unsere Fahrradtaschen bleiben auch 2018 auf der Erfolgsspur.
<G-vec00394-002-s152><remain.bleiben><en> Our bicycle bags remain on track for success in 2018.
<G-vec00394-002-s153><remain.bleiben><de> Auf Tastendruck kann man in den Standalone-Modus springen, die gewählten Ausgänge bleiben auch ohne Empfängersignal aktiv.
<G-vec00394-002-s153><remain.bleiben><en> On keypress the stand alone mode can be activated. The selected outputs remain active without receiver signal.
<G-vec00394-002-s154><remain.bleiben><de> Alles in allem, wenn die Gauner gut genug sind, bleiben sowohl Smishing als auch Phishing äußerst lukrative Methoden, um sensible Daten zu stehlen und die Konten von Personen zu gefährden.
<G-vec00394-002-s154><remain.bleiben><en> All in all, if the crooks are good enough, both smishing and phishing remain extremely lucrative schemes for stealing sensitive data and compromising people's accounts.
<G-vec00394-002-s155><remain.bleiben><de> Dank der ionischen Materialoberfläche bleiben die Linsen auch über längere Zeiträume ausreichend benetzt.
<G-vec00394-002-s155><remain.bleiben><en> Thanks to the ionic material surface, the lenses remain sufficiently wetted for longer periods of time.
<G-vec00394-002-s156><remain.bleiben><de> Die Ansprechpartner im Unternehmen bleiben auch nach der Übernahme unverändert.
<G-vec00394-002-s156><remain.bleiben><en> Contacts within the company will remain unchanged following the merger.
<G-vec00394-002-s157><remain.bleiben><de> Vor allem KMU bleiben damit auch bei hohen Nachfrageschwankungen wettbewerbsfähig.
<G-vec00394-002-s157><remain.bleiben><en> Small and medium sized businesses, particularly sensitive to extreme fluctuations in demand, remain competitive.
<G-vec00394-002-s158><remain.bleiben><de> 9.1 Diese AGB und die weiteren Vereinbarung zwischen ela-soft und dem Kunden bleiben auch bei rechtlicher Unwirksamkeit einzelner Bestimmungen in ihren übrigen Teilen verbindlich.
<G-vec00394-002-s158><remain.bleiben><en> In the event of legal ineffectiveness of individual provisions of these terms and conditions and the further agreement between ela-soft and the customer, the remaining provisions shall remain binding.
<G-vec00394-002-s159><remain.bleiben><de> Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen bleiben auch im Falle der Nichtverantwortlichkeit unberührt, sofern die FAP Invest GmbH hiervon Kenntnis erlangt hat.
<G-vec00394-002-s159><remain.bleiben><en> Even where we are not responsible, the obligations to remove or block the use of information in accordance with general legislation remain unaffected, provided that FAP Invest GmbH has acquired knowledge of this.
<G-vec00394-002-s160><remain.bleiben><de> Die Urheberrechte liegen bei der uvex Gruppe und bleiben auch in vollem Umfang bestehen, wenn Bilder elektronisch / händisch in ein Archiv übernommen werden.
<G-vec00394-002-s160><remain.bleiben><en> The copyrights belong to uvex group and remain undiminished if the pictures are incorporated into an archive, either electronically or manually.
<G-vec00394-002-s161><remain.bleiben><de> Mit Babyfotos und -videos bleiben Angehörige auch über große Entfernungen informiert und begleiten den neu geborenen Menschen so Schritt für Schritt ins Leben.
<G-vec00394-002-s161><remain.bleiben><en> With baby photos and videos, relatives remain up to date no matter how far they are and as such, they accompany the newborn at each new step in life.
<G-vec00394-002-s162><remain.bleiben><de> Persistente Cookies bleiben auch nach dem Schließen des Browsers auf dem Computer des Benutzers gespeichert.
<G-vec00394-002-s162><remain.bleiben><en> Persistent cookies remain saved on the user’s computer after the browser has been closed.
<G-vec00394-002-s163><remain.bleiben><de> Das Thema Energie und die damit einhergehenden Risiken, die derzeit als „mittel“ eingestuft werden, bleiben auch zukünftig für Aurubis als stromintensives Unternehmen sehr bedeutend.
<G-vec00394-002-s163><remain.bleiben><en> The topic of energy and the associated risks, currently classified as “medium”, will remain relevant for Aurubis as an energy-intensive company in the future as well.
<G-vec00394-002-s164><remain.bleiben><de> Fahrkarten, die vor Bekanntmachung einer Preisänderung erworben wurden, bleiben auch nach Inkrafttreten der Fahrpreisänderung zu den Konditionen, die zum Zeitpunkt des Erwerbs galten, gültig.
<G-vec00394-002-s164><remain.bleiben><en> Tickets purchased prior to the announcement of a price change remain valid after the enactment of the price change according to the conditions applicable at the time of purchase.
<G-vec00394-002-s165><remain.bleiben><de> Qualität, Kontinuität und Innovation bleiben damit auch künftig die Eckpfeiler des Unternehmens.
<G-vec00394-002-s165><remain.bleiben><en> "The new dual leadership will pursue the values of the company. Quality, continuity and innovation will therefore remain MicroNova cornerstones.
<G-vec00394-002-s166><remain.bleiben><de> Es gibt einfach immer neue Motive, und auch die »alten Stellen« bleiben auch nach dem xten Besuch noch toll.
<G-vec00394-002-s166><remain.bleiben><en> There are always new motives, and even the "old places" remain great after the xten visit.
<G-vec00394-002-s167><remain.bleiben><de> Mit den individuell zusammengestellten exklusiven Wellness All Inklusive-Pauschalen bleiben auch in den großzügig gestalteten Wellness & Beautyanlagen garantiert keine Wünsche offen.
<G-vec00394-002-s167><remain.bleiben><en> With the individually compiled exclusive Wellness All Inclusive Packages & Beauty facilities no wishes remain in the spacious spa open guarantee.
<G-vec00394-002-s168><remain.bleiben><de> Viele Badtextilien bleiben auch lange in unserer Kollektion, so dass Sie zu Hause Ihre eigene Kollektion immer wieder ergänzen und erweitern können.
<G-vec00394-002-s168><remain.bleiben><en> Most of our bath linens remain in our collection for a long time so you can replenish or complete your own collection at home later if you need or want to.
<G-vec00394-002-s169><remain.bleiben><de> Sämtliche Bestimmungen des Vertrags, deren Gültigkeit nicht auf die Laufzeit des Vertrags beschränkt sein kann, bleiben auch nach dessen Beendigung oder Ablauf seiner Gültigkeit gültig, einschließlich alle Ihre Aussagen, Verpflichtungen und Garantien gegen Haftungsschutz.
<G-vec00394-002-s169><remain.bleiben><en> Any conditions of Treaty, duration of which due to its essence can not be restricted by Agreement duration, remain valid after its termination or its expire of validity, including, among other issues, all Your complaints, liabilities and warranties of responsibility protection.
<G-vec00394-002-s170><remain.bleiben><de> Komplexe Projektstrukturen werden von Beginn an methodisch und effizient angelegt und bleiben auch in Zukunft ebenso übersichtlich wie durchschaubar.
<G-vec00394-002-s170><remain.bleiben><en> Complex project structures are designed methodically and efficiently from the very beginning. They will remain just as clear and transparent in the future.
<G-vec00394-002-s114><stay.bleiben><de> Ich bleibe viel mit mir allein.
<G-vec00394-002-s114><stay.bleiben><en> I stay to myself a lot.
<G-vec00394-002-s115><stay.bleiben><de> Warnungen Bleibe aus dem Weg deiner Lichtquelle oder stelle sie so auf, dass du keine ablenkenden Schatten über deiner Animation erzeugst, die in jeder einzelnen Aufnahme anders sind.
<G-vec00394-002-s115><stay.bleiben><en> Warnings Stay out of the way of your light source or position it so you don't create distracting shadows over your animation that change with each frame.
<G-vec00394-002-s116><stay.bleiben><de> Lukas 24:29 Und sie nötigten ihn und sprachen: Bleibe bei uns; denn es will Abend werden, und der Tag hat sich geneigt.
<G-vec00394-002-s116><stay.bleiben><en> But they urged Him, saying, "Stay with us, for it is getting toward evening, and the day is now nearly over."
<G-vec00394-002-s117><stay.bleiben><de> Bleibe ruhig und konzentriert.
<G-vec00394-002-s117><stay.bleiben><en> Stay calm and focused.
<G-vec00394-002-s118><stay.bleiben><de> Bleibe mit der Xbox Live-Community in Kontakt, beginne Party-Chats, stürze dich in den geräteübergreifenden Multiplayer, und streame Xbox One Spiele auf jeden Windows 10-PC in deinem Zuhause.
<G-vec00394-002-s118><stay.bleiben><en> Stay connected to the Xbox Live community, start party chats, launch into cross-device multiplayer and stream Xbox One games to any Windows 10 PC in your home. SEE DETAILS
<G-vec00394-002-s119><stay.bleiben><de> Meine Gesundheit geht vor, auch wenn sich mein Dienstplan und private Pläne dann ändern, bleibe ich lieber zu Hause.
<G-vec00394-002-s119><stay.bleiben><en> My health is my priority, although my schedule and private plans change, I prefer to stay home.
<G-vec00394-002-s120><stay.bleiben><de> Den Tee anstarrend bleibe ich, wo ich bin.
<G-vec00394-002-s120><stay.bleiben><en> Staring at the tea, I stay where I am.
<G-vec00394-002-s121><stay.bleiben><de> Bleibe bei ihnen, solange du kannst oder bis sie den natürlichen Lauf der Dinge nehmen.
<G-vec00394-002-s121><stay.bleiben><en> Stay with them as long as you can or until they run their natural course.
<G-vec00394-002-s122><stay.bleiben><de> 29:19 Laban antwortete: Es ist besser, ich gebe sie dir denn einem andern; bleibe bei mir.
<G-vec00394-002-s122><stay.bleiben><en> 29:19 Lahan answered: It is better that I give her thee than to another man; stay with me.
<G-vec00394-002-s123><stay.bleiben><de> Also bleibe ruhig.
<G-vec00394-002-s123><stay.bleiben><en> So stay calm.
<G-vec00394-002-s124><stay.bleiben><de> Kontakte-Manager Bleibe mit dem Campayn-Kontakte-Manager auf einfache Weise mit Deinen Kunden in Verbindung.
<G-vec00394-002-s124><stay.bleiben><en> Stay connected to your customers in a more meaningful way with Campayn's Contacts Manager.
<G-vec00394-002-s125><stay.bleiben><de> In ihrem Haus beherbergen sie zudem einige der Kinder, die keine Bleibe haben und dienen ihnen als Familienersatz.
<G-vec00394-002-s125><stay.bleiben><en> Further more the couple have opened the doors of their home to accommodate some of the children who have nowhere else to stay, treating them as members of their own family.
<G-vec00394-002-s126><stay.bleiben><de> Wenn du einmal deine Entscheidung getroffen hast, dann verfolge sie und bleibe deinen Werten treu.
<G-vec00394-002-s126><stay.bleiben><en> Once you've made your decision, follow through with it and stay true to your values.
<G-vec00394-002-s127><stay.bleiben><de> Bleibe flexibel und trainiere.
<G-vec00394-002-s127><stay.bleiben><en> Stay flexible and exercise.
<G-vec00394-002-s128><stay.bleiben><de> Tauche stilsicher in deine Musik ab und bleibe trotzdem immer mit der Welt verbunden.
<G-vec00394-002-s128><stay.bleiben><en> Dive into your music in style and still stay connected to the world.
<G-vec00394-002-s129><stay.bleiben><de> 12) Bleibe gesund indem du nur ausgewogene Ernährung zu dir nimmst – ohne Weizen und mit einer angemessen Dosis dunkler Lindt Schokoladentrüffel (die kleinen, runden, blauen).
<G-vec00394-002-s129><stay.bleiben><en> 12) Stay healthy by eating a well balanced diet absent of wheat and a healthy dose of Lindt dark chocolate truffles (the little blue round ones).
<G-vec00394-002-s130><stay.bleiben><de> Bleibe motiviert indem du spürst, wie viel besser du dich mit einer gesunden Ernährung „fühlst“ anstatt nur besser aussehen zu wollen.
<G-vec00394-002-s130><stay.bleiben><en> Stay motivated by noticing the ways in which a healthy diet makes you feel better, instead of simply looking better.
<G-vec00394-002-s131><stay.bleiben><de> Bleibe HÖCHSTENS vier Wochen in Phase 1.
<G-vec00394-002-s131><stay.bleiben><en> Stay in Phase 1 for NO MORE than 4 weeks.
<G-vec00394-002-s132><stay.bleiben><de> "Dieses tadellose Hotel ist eine nette Bleibe.
<G-vec00394-002-s132><stay.bleiben><en> "This pristine property is a pleasant place to stay.
