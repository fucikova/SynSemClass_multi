<G-vec00158-002-s019><starve.aushungern><de> Damit würden mögliche Tumorzellen förmlich ausgehungert.
<G-vec00158-002-s019><starve.aushungern><en> This potential tumor cells would literally starve.
