<G-vec00283-003-s019><roll_over.aufrollen><de> Jeden Teigfladen mit Frischkäse bestreichen, mit je 2 Schinkenscheiben belegen, Bohnen darauf verteilen, Teigfladen fest aufrollen, etwa vier- bis fünfmal oder öfter durchschneiden, eventuell mit Hölzchen feststecken und servieren.
<G-vec00283-003-s019><roll_over.aufrollen><en> Let it cool down and spread each wrap with cream cheese, top with 2 slices of ham, beans Spread on top, roll up dough flat. Cut and pin with a toothpick and serve. Informationen
<G-vec00283-003-s020><roll_over.aufrollen><de> Von der langen Seite her aufrollen, die Enden zusammendrücken, damit die Füllung nicht auslaufen kann, dann zu Hörnchen formen.
<G-vec00283-003-s020><roll_over.aufrollen><en> Roll up from the long side, squeeze the ends together so that the filling does not leak, then form into croissants.
<G-vec00283-003-s021><roll_over.aufrollen><de> Die Lasagnenudeln dann vorsichtig aufrollen und mit der Naht nach unten in die Auflaufform legen.
<G-vec00283-003-s021><roll_over.aufrollen><en> Carefully roll them and place them seam side down into the baking dish.
<G-vec00283-003-s022><roll_over.aufrollen><de> Dann wie das restliche Werkstück in heiße Bänke gießen und aufrollen.
<G-vec00283-003-s022><roll_over.aufrollen><en> Then, like the rest of the workpiece, pour into hot banks and roll up.
<G-vec00283-003-s023><roll_over.aufrollen><de> Den Teig auf der langen Seite aufrollen und anschließend mit einem scharfen Messer in 12 gleichgroße Stücke schneiden.
<G-vec00283-003-s023><roll_over.aufrollen><en> Then, starting at the long end, roll up the dough and cut log into 12 equally sized pieces with a sharp knife.
<G-vec00283-003-s024><roll_over.aufrollen><de> Wenn der "faule" Pfeffer vollständig fertig ist, Essig hineingießen, über die Dosen verteilen und aufrollen.
<G-vec00283-003-s024><roll_over.aufrollen><en> When the "lazy" pepper is completely ready, pour vinegar into it, spread it over the cans and roll up.
<G-vec00283-003-s025><roll_over.aufrollen><de> Nach dem Kochen können Sie Adjika aus Zucchini in sterile Gläser füllen und aufrollen.
<G-vec00283-003-s025><roll_over.aufrollen><en> After cooking, you can pour adjika from courgettes into sterile jars and roll up.
<G-vec00283-003-s026><roll_over.aufrollen><de> Die Außenseiten einklappen und das Reisblatt wie einen Strudel aufrollen.
<G-vec00283-003-s026><roll_over.aufrollen><en> Place pickle half on narrow end of each and roll up.
<G-vec00283-003-s027><roll_over.aufrollen><de> Den Teig mit dem Geschirrtuch aufrollen und abkühlen lassen.
<G-vec00283-003-s027><roll_over.aufrollen><en> Roll up the dough with the tea towel and allow to cool.
<G-vec00283-003-s028><roll_over.aufrollen><de> Ein Knicken oder Aufrollen der Tube ist zur Entnahmen der Augensalbe nicht notwendig.
<G-vec00283-003-s028><roll_over.aufrollen><en> It is not necessary to fold or roll the tube to extract the eye ointment.
<G-vec00283-003-s029><roll_over.aufrollen><de> Die Champignons einfach in einen sterilisierten Behälter geben, die Marinade einfüllen und den Deckel aufrollen.
<G-vec00283-003-s029><roll_over.aufrollen><en> Just put the mushrooms in a sterilized container, pour the marinade and roll up the lid.
<G-vec00283-003-s030><roll_over.aufrollen><de> Sie können Ihre Servietten stilvoll falten, um Ihrer Festtafel einen festlichen und feinen Look zu geben – Sie könnten aber auch Servietten aus Leinen ganz einfach aufrollen und mit einem stilvollen Serviettenring verzieren.
<G-vec00283-003-s030><roll_over.aufrollen><en> You can fold your napkins into different shapes but you can also just roll up your napkins and present them in a matching napkin ring.
<G-vec00283-003-s031><roll_over.aufrollen><de> Der Länge nach aufrollen und mit einem scharfen Messer in 16 gleichgroße Stücke schneiden.
<G-vec00283-003-s031><roll_over.aufrollen><en> Then roll the dough up like a Swiss role and use a sharp knife to portion it into 16 equally thick slices.
<G-vec00283-003-s032><roll_over.aufrollen><de> Dort treffen der Unterdruck der Tragflächenoberseite und der Überdruck der Tragflächenunterseite zusammen, was zu einem Aufrollen der Wirbel führt.
<G-vec00283-003-s032><roll_over.aufrollen><en> The reduced pressure of the upper side of the wing combines with the increased pressure on the underside of the wing, causing the air to roll over the wingtip and form a vortex.
<G-vec00283-003-s033><roll_over.aufrollen><de> Parmesanscheiben, Kopfsalat, Tomatenwürfel und Frühlingszwiebel auf die Wraps verteilen und die Wraps aufrollen.
<G-vec00283-003-s033><roll_over.aufrollen><en> Roll firmly with some Parmesan shavings, head lettuce, diced tomatoes and spring onions on top.
<G-vec00283-003-s034><roll_over.aufrollen><de> Hierdurch kann man Ihre Anlage schneller aufrollen.
<G-vec00283-003-s034><roll_over.aufrollen><en> This will also allow you to roll up your installation faster.
<G-vec00283-003-s035><roll_over.aufrollen><de> Der Großvater zwirbelt mit einer filigranen Technik die Tierhaare zu einem Faden, während die Jungs den Faden dann aufrollen.
<G-vec00283-003-s035><roll_over.aufrollen><en> The grandfather twists the animal hair to a thread with a filigree technique, while the boys then roll up the thread.
<G-vec00283-003-s036><roll_over.aufrollen><de> Wenn es an der Zeit ist wieder nach Hause zu gehen, dann können Sie sie ganz einfach wieder aufrollen und sie lässt sich leicht an dem Tragegurt tragen.
<G-vec00283-003-s036><roll_over.aufrollen><en> When you are done using it, then you can just roll it up and it’s easy to lug around by its carrying strap.
<G-vec00283-003-s037><roll_over.aufrollen><de> Die fertige Gemüsemasse in Bänken vorverpacken und aufrollen.
<G-vec00283-003-s037><roll_over.aufrollen><en> Prepack the finished vegetable mass in banks and roll up.
<G-vec00342-003-s019><roll_out.aufrollen><de> Jeden Teigfladen mit Frischkäse bestreichen, mit je 2 Schinkenscheiben belegen, Bohnen darauf verteilen, Teigfladen fest aufrollen, etwa vier- bis fünfmal oder öfter durchschneiden, eventuell mit Hölzchen feststecken und servieren.
<G-vec00342-003-s019><roll_out.aufrollen><en> Let it cool down and spread each wrap with cream cheese, top with 2 slices of ham, beans Spread on top, roll up dough flat. Cut and pin with a toothpick and serve. Informationen
<G-vec00342-003-s020><roll_out.aufrollen><de> Von der langen Seite her aufrollen, die Enden zusammendrücken, damit die Füllung nicht auslaufen kann, dann zu Hörnchen formen.
<G-vec00342-003-s020><roll_out.aufrollen><en> Roll up from the long side, squeeze the ends together so that the filling does not leak, then form into croissants.
<G-vec00342-003-s021><roll_out.aufrollen><de> Die Lasagnenudeln dann vorsichtig aufrollen und mit der Naht nach unten in die Auflaufform legen.
<G-vec00342-003-s021><roll_out.aufrollen><en> Carefully roll them and place them seam side down into the baking dish.
<G-vec00342-003-s022><roll_out.aufrollen><de> Dann wie das restliche Werkstück in heiße Bänke gießen und aufrollen.
<G-vec00342-003-s022><roll_out.aufrollen><en> Then, like the rest of the workpiece, pour into hot banks and roll up.
<G-vec00342-003-s023><roll_out.aufrollen><de> Den Teig auf der langen Seite aufrollen und anschließend mit einem scharfen Messer in 12 gleichgroße Stücke schneiden.
<G-vec00342-003-s023><roll_out.aufrollen><en> Then, starting at the long end, roll up the dough and cut log into 12 equally sized pieces with a sharp knife.
<G-vec00342-003-s024><roll_out.aufrollen><de> Wenn der "faule" Pfeffer vollständig fertig ist, Essig hineingießen, über die Dosen verteilen und aufrollen.
<G-vec00342-003-s024><roll_out.aufrollen><en> When the "lazy" pepper is completely ready, pour vinegar into it, spread it over the cans and roll up.
<G-vec00342-003-s025><roll_out.aufrollen><de> Nach dem Kochen können Sie Adjika aus Zucchini in sterile Gläser füllen und aufrollen.
<G-vec00342-003-s025><roll_out.aufrollen><en> After cooking, you can pour adjika from courgettes into sterile jars and roll up.
<G-vec00342-003-s026><roll_out.aufrollen><de> Die Außenseiten einklappen und das Reisblatt wie einen Strudel aufrollen.
<G-vec00342-003-s026><roll_out.aufrollen><en> Place pickle half on narrow end of each and roll up.
<G-vec00342-003-s027><roll_out.aufrollen><de> Den Teig mit dem Geschirrtuch aufrollen und abkühlen lassen.
<G-vec00342-003-s027><roll_out.aufrollen><en> Roll up the dough with the tea towel and allow to cool.
<G-vec00342-003-s028><roll_out.aufrollen><de> Ein Knicken oder Aufrollen der Tube ist zur Entnahmen der Augensalbe nicht notwendig.
<G-vec00342-003-s028><roll_out.aufrollen><en> It is not necessary to fold or roll the tube to extract the eye ointment.
<G-vec00342-003-s029><roll_out.aufrollen><de> Die Champignons einfach in einen sterilisierten Behälter geben, die Marinade einfüllen und den Deckel aufrollen.
<G-vec00342-003-s029><roll_out.aufrollen><en> Just put the mushrooms in a sterilized container, pour the marinade and roll up the lid.
<G-vec00342-003-s030><roll_out.aufrollen><de> Sie können Ihre Servietten stilvoll falten, um Ihrer Festtafel einen festlichen und feinen Look zu geben – Sie könnten aber auch Servietten aus Leinen ganz einfach aufrollen und mit einem stilvollen Serviettenring verzieren.
<G-vec00342-003-s030><roll_out.aufrollen><en> You can fold your napkins into different shapes but you can also just roll up your napkins and present them in a matching napkin ring.
<G-vec00342-003-s031><roll_out.aufrollen><de> Der Länge nach aufrollen und mit einem scharfen Messer in 16 gleichgroße Stücke schneiden.
<G-vec00342-003-s031><roll_out.aufrollen><en> Then roll the dough up like a Swiss role and use a sharp knife to portion it into 16 equally thick slices.
<G-vec00342-003-s032><roll_out.aufrollen><de> Dort treffen der Unterdruck der Tragflächenoberseite und der Überdruck der Tragflächenunterseite zusammen, was zu einem Aufrollen der Wirbel führt.
<G-vec00342-003-s032><roll_out.aufrollen><en> The reduced pressure of the upper side of the wing combines with the increased pressure on the underside of the wing, causing the air to roll over the wingtip and form a vortex.
<G-vec00342-003-s033><roll_out.aufrollen><de> Parmesanscheiben, Kopfsalat, Tomatenwürfel und Frühlingszwiebel auf die Wraps verteilen und die Wraps aufrollen.
<G-vec00342-003-s033><roll_out.aufrollen><en> Roll firmly with some Parmesan shavings, head lettuce, diced tomatoes and spring onions on top.
<G-vec00342-003-s034><roll_out.aufrollen><de> Hierdurch kann man Ihre Anlage schneller aufrollen.
<G-vec00342-003-s034><roll_out.aufrollen><en> This will also allow you to roll up your installation faster.
<G-vec00342-003-s035><roll_out.aufrollen><de> Der Großvater zwirbelt mit einer filigranen Technik die Tierhaare zu einem Faden, während die Jungs den Faden dann aufrollen.
<G-vec00342-003-s035><roll_out.aufrollen><en> The grandfather twists the animal hair to a thread with a filigree technique, while the boys then roll up the thread.
<G-vec00342-003-s036><roll_out.aufrollen><de> Wenn es an der Zeit ist wieder nach Hause zu gehen, dann können Sie sie ganz einfach wieder aufrollen und sie lässt sich leicht an dem Tragegurt tragen.
<G-vec00342-003-s036><roll_out.aufrollen><en> When you are done using it, then you can just roll it up and it’s easy to lug around by its carrying strap.
<G-vec00342-003-s037><roll_out.aufrollen><de> Die fertige Gemüsemasse in Bänken vorverpacken und aufrollen.
<G-vec00342-003-s037><roll_out.aufrollen><en> Prepack the finished vegetable mass in banks and roll up.
