<G-vec00322-002-s106><assess.auswerten><de> Diese Überzeugung stützt sich auf aktuelle Erkenntnisse unabhängiger nationaler und internationaler Expertengremien, die ständig alle relevanten Studien auswerten und die Sicherheitsstandards überprüfen.
<G-vec00322-002-s106><assess.auswerten><en> This conviction is based on the current findings of independent national and international expert bodies, which continually assess all relevant studies and check safety standards.
<G-vec00322-002-s107><assess.auswerten><de> Innerhalb einiger Monate werden wir sehen und auswerten, was für Ergebnisse unsere Teilnahme gebracht hat.
<G-vec00322-002-s107><assess.auswerten><en> Within a few months we will see and assess what the outcome of our involvement has brought.
<G-vec00322-002-s108><assess.auswerten><de> Ein Techniker möchte die Prozessfähigkeit eines Prozesses auswerten, bei dem große Papierrollen mit einem dünnen Überzug beschichtet werden.
<G-vec00322-002-s108><assess.auswerten><en> An engineer wants to assess the capability of a process that coats large rolls of paper with a thin film.
<G-vec00322-002-s109><assess.auswerten><de> Über ihre Nachrichten und Interaktionen kann Larry Reiff auswerten, wie viel sie tatsächlich verstanden haben.
<G-vec00322-002-s109><assess.auswerten><en> Through their interaction on Twitter, Larry can assess their level of understanding.
<G-vec00322-002-s110><assess.auswerten><de> Dieses Formular wird einem Servicemitarbeiter übermittelt, dieser wird die Daten aus dem Formular auswerten und sich mit Ihnen in Verbindung setzen.
<G-vec00322-002-s110><assess.auswerten><en> This form will be submitted to a member of our service staff, who will assess it and get in touch with you.
<G-vec00322-002-s111><assess.auswerten><de> Sie und Ihre Mitarbeiter können Verbände und Aufgaben hinzufügen, die wir auswerten.
<G-vec00322-002-s111><assess.auswerten><en> You and your employees can add charities and missions, we assess them.
<G-vec00322-002-s112><assess.auswerten><de> Das Testset besteht aus zwei Testblättern für das Motoröl, einer MOTORcheckUP-Schablone sowie einer Broschüre zum Auswerten der Testergebnisse.
<G-vec00322-002-s112><assess.auswerten><en> The test set comprises two test papers for the motor oil, a MOTORcheckUP gauge as well as a brochure to assess the test results.
<G-vec00322-002-s113><assess.auswerten><de> Während eines Schadens kann man die Qualität seines Versicherungsschutzes am besten auswerten.
<G-vec00322-002-s113><assess.auswerten><en> It’s in the event of a claim that we can really assess the quality of your insurance coverage.
<G-vec00322-002-s114><assess.auswerten><de> Nachdem auf dem Projekt seit 1992 keine Arbeiten mehr stattgefunden haben, muss das Unternehmen die Bohrstandorte, Querschnitte, EM-Daten und den geplanten Minenplans der früheren Betreiber auswerten.
<G-vec00322-002-s114><assess.auswerten><en> Due to the project having been left dormant since 1992, the Company needs to assess the drill locations, cross sections, EM data, and proposed mine plan from previous operators.
<G-vec00322-002-s115><assess.auswerten><de> Ein Qualitätstechniker für einen Hersteller von Nahrungsmittelzusätzen möchten den Kalziumgehalt in Vitaminkapseln auswerten.
<G-vec00322-002-s115><assess.auswerten><en> A quality engineer for a nutritional supplement company wants to assess the calcium content in vitamin capsules.
<G-vec00322-002-s116><assess.auswerten><de> Mit bookingkit kannst du dein Geschäft detailliert analysieren, auswerten und die richtigen Entscheidungen für Verbesserungen treffen.
<G-vec00322-002-s116><assess.auswerten><en> With bookingkit you can analyze and assess your business in depth and find the biggest opportunities for improvement.
<G-vec00364-002-s027><relive.auswerten><de> Auf der Karte kannst du deine Trainingsdaten detailliert auswerten.
<G-vec00364-002-s027><relive.auswerten><en> You can also relive other people’s public workouts on the Explore tab.
<G-vec00402-002-s079><interpret.auswerten><de> Wenn man sich weigert, diese Schwierigkeiten schöpferisch auszuwerten, so kann man es nur zu einer Sammlung von immer bedeutungsloseren, zunehmend segmentären, peripheren und sogar trivialen Daten bringen...
<G-vec00402-002-s079><interpret.auswerten><en> Refusing to look for ways to creatively interpret this we will end with collections of more and more meaningless, increasingly segmented, peripheral and even trivial data...
<G-vec00402-002-s080><interpret.auswerten><de> Marketingtests umfassen idealerweise eine klare Vorgehensweise, sind leicht auszuwerten und tragen zu einem kontinuierlichen Lern- und Verbesserungsprozess bei.
<G-vec00402-002-s080><interpret.auswerten><en> The best marketing experimentation follows a clear design process, is easy to interpret and leads to continued learning and refinement.
<G-vec00402-002-s081><interpret.auswerten><de> Wir nutzen die von Google aufbereiteten Informationen, um deine Nutzung der App auszuwerten, um die Optimierung und Weiterentwicklung der App zu erleichtern.
<G-vec00402-002-s081><interpret.auswerten><en> We use the information prepared by Google to interpret your use of the Mobile App for its optimization and further development.
<G-vec00402-002-s082><interpret.auswerten><de> Die erhaltenen Daten sind einfach auszuwerten: der erhöhte Schwingungspegel tritt in axialer Richtung beim Winkelversatz, in horizontaler Richtung bei der Unwucht und in vertikaler Richtung beim Lösen des Fundaments oder der Füße hervor.
<G-vec00402-002-s082><interpret.auswerten><en> It is very easy to interpret the received data: the increased vibration in the axial direction indicates the misalignment condition, the increased vibration in the horizontal direction indicates unbalance, and the increased vibration in the vertical direction indicates the looseness of foundation or supports.
<G-vec00402-002-s083><interpret.auswerten><de> Von Beginn an war eine von Gefrans Stärken die Fähigkeit exakt zu verstehen, auszuwerten und zu produzieren, was die Kunden benötigen.
<G-vec00402-002-s083><interpret.auswerten><en> Right from the start, Gefran’s differentiating strength was its capacity to understand, interpret and produce exactly what its customers needed.
