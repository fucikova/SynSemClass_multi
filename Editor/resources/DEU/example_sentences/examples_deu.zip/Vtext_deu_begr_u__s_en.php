<G-vec00135-001-s076><welcome.begrüßen><de> """Ich begrüße die Freilassung von Dogan Akhanli."
<G-vec00135-001-s076><welcome.begrüßen><en> “I welcome the release of Dogan Akhanli.
<G-vec00135-001-s077><welcome.begrüßen><de> Ich begrüße E-Mail über jeden Song, den Sie mögen, hier diskutieren, sowie E-Mail einrichten, um jemand anderen folgen Kommentare über einen Song.
<G-vec00135-001-s077><welcome.begrüßen><en> I welcome email about any song you would like to discuss here, as well as follow up email to anyone else’s comments about a song.
<G-vec00135-001-s078><welcome.begrüßen><de> Darüber hinaus ist für Sie sehnen sich, dass vergoldeter Bronze, das Aussehen, die senden das andere Geschlecht in eine tizzy.Well, in diesem Fall möchte ich begrüße Sie zu den erstaunlichen Welt der Sonnenbank Produkte.
<G-vec00135-001-s078><welcome.begrüßen><en> Beyond that, you crave for that golden bronze look, the look that would send the opposite sex into a tizzy.Well, in that case let me welcome you to the amazing world of tanning bed products.
<G-vec00135-001-s079><welcome.begrüßen><de> Ich begrüße die konstruktive Tonlage, die Präsident Putin nach der Begegnung mit OSZE-Vorsitzenden Burkhalter angeschlagen hat.
<G-vec00135-001-s079><welcome.begrüßen><en> I welcome the constructive tone that President Putin adopted after his meeting with OSCE Chairperson-in-Office Burkhalter.
<G-vec00135-001-s080><welcome.begrüßen><de> Ich begrüße die Entscheidung des Bundesverfassungsgerichts.
<G-vec00135-001-s080><welcome.begrüßen><en> I welcome the decision by the German Federal Constitutional Court.
<G-vec00135-001-s081><welcome.begrüßen><de> Ich begrüße die Vorlage des „Budget Review“-Berichts durch die EU-Kommission.
<G-vec00135-001-s081><welcome.begrüßen><en> I welcome the presentation of the Budget Review by the European Commission.
<G-vec00135-001-s082><welcome.begrüßen><de> In der Freude am Glauben, dessen Verkündigung unser gemeinsamer Hirtendienst ist, begrüße ich Euch zu dieser Begegnung der ersten Gruppe deutscher Bischöfe anläßlich des ad limina Besuchs.
<G-vec00135-001-s082><welcome.begrüßen><en> In the joy of the faith, whose proclamation is our common service as Pastors, I welcome you at this meeting of the first group of German Bishops on the occasion of your ad limina visit.
<G-vec00135-001-s083><welcome.begrüßen><de> """Ich begrüße die Entscheidung von Gouverneur Pat Quinn ausdrücklich."
<G-vec00135-001-s083><welcome.begrüßen><en> “I expressly welcome Governor Quinn’s decision.
<G-vec00135-001-s084><welcome.begrüßen><de> Ich begrüße die Gelegenheit, Ihnen meine besten Grüße zu bieten.
<G-vec00135-001-s084><welcome.begrüßen><en> I welcome the opportunity to offer you my best regards.
<G-vec00135-001-s085><welcome.begrüßen><de> """Ich begrüße, dass die Regierungen beider Länder die Vorschläge der Bank zur Neuausrichtung unterstützen."
<G-vec00135-001-s085><welcome.begrüßen><en> “I welcome the fact that the governments of both states support the proposals made by the Bank on its realignment.
<G-vec00135-001-s086><welcome.begrüßen><de> Begrüße sie in angemessener Weise.
<G-vec00135-001-s086><welcome.begrüßen><en> Welcome them properly.
<G-vec00135-001-s087><welcome.begrüßen><de> Verbraucherschutzkommissar Neven Mimica kommentierte das Programm mit den Worten: „Ich begrüße die Verabschiedung des europäischen Parlaments über das neue Verbraucherprogramm sehr.
<G-vec00135-001-s087><welcome.begrüßen><en> "Neven Mimica, Commissioner for Consumer Policy comments: ""I very much welcome the adoption of the Consumer programme by the European Parliament."
<G-vec00135-001-s088><welcome.begrüßen><de> Diese Haltung begrüße ich, umso mehr, als Untersuchungen gegen weitere Mittäter und Hintermänner fortgesetzt werden.
<G-vec00135-001-s088><welcome.begrüßen><en> I welcome this stance all the more in light of the continuing investigations of other accomplices and instigators.
<G-vec00135-001-s089><welcome.begrüßen><de> """Ich begrüße den Geist des Dialogs und der Verantwortungsbereitschaft, der einen Konsensbeschluss zum Nahen Osten im Rahmen des Exekutivrats ermöglicht hat."
<G-vec00135-001-s089><welcome.begrüßen><en> """I welcome the spirit of dialogue and responsibility that has allowed a consensual decision to be reached in the framework of the Executive Board during its discussions concerning the Middle East."
<G-vec00135-001-s090><welcome.begrüßen><de> Reise auf einem Art Deco Festival in die Vergangenheit, erlebe ein Winterfestival oder begrüße das Maori-Neujahr auf diesen einzigartigen Events.
<G-vec00135-001-s090><welcome.begrüßen><en> Go back in time with an Art Deco festival, experience a magical winter festival, or welcome the Maori New Year at one of these unique, cultural events.
<G-vec00135-001-s091><welcome.begrüßen><de> Ich begrüße, dass es der malischen Armee mit Unterstützung Frankreichs und afrikanischer Staaten gelungen ist, den Vormarsch der Islamisten zu stoppen.
<G-vec00135-001-s091><welcome.begrüßen><en> I welcome the success of the efforts by the Malian army, aided by France and African states, to stop the advances of the Islamists.
<G-vec00135-001-s092><welcome.begrüßen><de> Dieses Engagement begrüße ich außerordentlich, da wir kontinuierlich auf der Suche nach außerschulischen Lernorten sind, die den Bildungsauftrag unserer Schulen sinnvoll ergänzen.
<G-vec00135-001-s092><welcome.begrüßen><en> I very much welcome this idea since we are always looking for extracurricular learning centers that meaningfully complement our schools’ educational mission.
<G-vec00135-001-s093><welcome.begrüßen><de> Ich begrüße, dass die Internationale Solar-Allianz heute den Status einer internationalen Organisation erhalten hat.
<G-vec00135-001-s093><welcome.begrüßen><en> I welcome the achievement today by the International Solar Alliance of status as an international organization.
<G-vec00135-001-s094><welcome.begrüßen><de> „Ich begrüße die Bemühungen der afghanischen Regierung, für das immense Potential Afghanistans als Rohstoffland auch gegenüber der deutschen Wirtschaft zu werben.
<G-vec00135-001-s094><welcome.begrüßen><en> “I welcome the Afghan Government’s efforts to encourage German business to invest in Afghanistan’s enormous potential as a country rich in raw materials.
<G-vec00586-001-s034><appreciate.begrüßen><de> wir begrüßen Sie alle herzlich zur offiziellen Einweihung des Weyermann Logistikzentrums.
<G-vec00586-001-s034><appreciate.begrüßen><en> we cordially appreciate you all today to our inauguration of the new Weyermann-logistic centre.
<G-vec00586-001-s035><appreciate.begrüßen><de> Die Menschen wissen, dass es Homosexualität gibt, aber die überwiegende Stimmung ist, dass Leute es begrüßen würden, wenn es ihnen nicht unter die Nase gerieben würde.
<G-vec00586-001-s035><appreciate.begrüßen><en> People know homosexuality exists, but the overriding sentiment is that people would appreciate that it is not enwrapped in their faces.
<G-vec00586-001-s036><appreciate.begrüßen><de> Einen Link auf Ihrer Homepage würden wir begrüßen.
<G-vec00586-001-s036><appreciate.begrüßen><en> We would appreciate your linking to us.
<G-vec00586-001-s037><appreciate.begrüßen><de> Die Bewegung nennt sich selbst „Patriotische Europäer“, doch ihre Grundwerte stehen im Widerspruch zu den unsrigen, denn die Jungen Europäischen Föderalisten begrüßen Vielfalt und schützen Minderheiten vor der Tyrannei der Mehrheit.
<G-vec00586-001-s037><appreciate.begrüßen><en> The movement calls itself “Patriotic Europeans”, but their core values contradict with ours, for we as Young European Federalists appreciate diversity and protect minorities from the tyranny of the majority.
<G-vec00586-001-s038><appreciate.begrüßen><de> Wir würden es auch begrüßen, wenn Sie verdächtige E-Mails an security@perfectwelding.com.tw weiterleiten, damit wir diese Betrugsaktivitäten den lokalen Behörden melden können.
<G-vec00586-001-s038><appreciate.begrüßen><en> We would also appreciate that you forward any suspicious emails to security@perfectwelding.com.tw so we can report this fraud activity to the local authorities.
<G-vec00586-001-s039><appreciate.begrüßen><de> Ein universitätsinternes Intranet würden sie begrüßen, damit interne Informationen und Dokumente, die nur für Mitglieder der Universität bestimmt sind, nicht auf den Webseiten vorgehalten werden müssen und damit nicht mehr der Öffentlichkeit zugänglich sind.
<G-vec00586-001-s039><appreciate.begrüßen><en> They would appreciate a university-wide intranet so that information and documents intended only for employees would no longer need to be accessed trough the website and thus not be publicly available.
<G-vec00586-001-s040><appreciate.begrüßen><de> Die im Aktionsbündnis Landmine.de zusammengeschlossenen Nichtregierungsorganisationen begrüßen die Absichtserklärung der Konferenz als ersten Schritt in Richtung eines möglichen Verbotes, zeigen sich aber besorgt über die Unverbindlichkeit der Abschlusserklärung.
<G-vec00586-001-s040><appreciate.begrüßen><en> The NGOs forming the Action Group Landmine.de appreciate the conference's declaration of intend as a first step towards a possible ban, but show themselves worried about the unbinding character of the declaration.
<G-vec00586-001-s041><appreciate.begrüßen><de> „Wir heißen Patrick Steppe im Vorstand herzlich Willkommen und begrüßen es sehr, dass er unserem Wunsch entsprochen hat und die Aufgabe als Chief Sales Officer (CSO) der Lekkerland AG & Co. KG übernimmt“, erläutert Michael Hoffmann, Chief Executive Officer der Lekkerland AG & Co. KG.
<G-vec00586-001-s041><appreciate.begrüßen><en> „We welcome Patrick Steppe to the Board of Management and we appreciate it very much, that he was in compliance with our wish and takes over the position as Chief Sales Officer (CSO) of Lekkerland AG & Co. KG“, explains Michael Hoffmann, Chief Executive Officer of Lekkerland AG & Co. KG.
<G-vec00586-001-s042><appreciate.begrüßen><de> """Die Menschen hier begrüßen das Engagement von Betty Bigombe, die versucht bei den Gesprächen mit den Anführern zu vermitteln."
<G-vec00586-001-s042><appreciate.begrüßen><en> """People appreciate and respect the work of Betty Bigombe, who is leading mediation with the rebel leaders."
<G-vec00586-001-s043><appreciate.begrüßen><de> Wenn Ihnen viel Vergnügen beim Lesen meiner Beiträge, würde ich es begrüßen, wenn man sich das Wort und teilen Stellen Sie mit Ihren Freunden, wenn Sie denken, dass sie, wie sie.
<G-vec00586-001-s043><appreciate.begrüßen><en> If you enjoy reading my posts, I’d appreciate it if you could spread the word and share posts with your friends, if you think they’ll like them.
<G-vec00586-001-s044><appreciate.begrüßen><de> Wir begrüßen, dass beide Parteien unserem Vorschlag hinsichtlich der Prinzipien für die Zusammenarbeit im Parlament zustimmen konnten.
<G-vec00586-001-s044><appreciate.begrüßen><en> “We appreciate that both parties were able to agree on our proposal concerning the principles of cooperation in the parliament.
<G-vec00586-001-s045><appreciate.begrüßen><de> Ich glaube, dass Ausländer dies begrüßen würden, aber wahrscheinlich nicht viel verstehen werden.
<G-vec00586-001-s045><appreciate.begrüßen><en> I believe foreigners would appreciate but probably do not understand much.
<G-vec00586-001-s046><appreciate.begrüßen><de> "Unseren Kunden können wir hier eine Plattform bieten, wichtige Entscheider zu erreichen, und die Messebesucher werden es begrüßen, eine große Anzahl von Trevira CS Neuheiten und Kollektionen bei einem ""one-stop-shop"" zu finden"", so Marketingleiterin Anke Vollenbröker."
<G-vec00586-001-s046><appreciate.begrüßen><en> "It enables us to offer a platform to our clients allowing them to reach important decision-makers. In addition, visitors to the trade fair will appreciate being able to find such a large number of Trevira CS novelties and collections in a one-stop-shop,"" says Anke Vollenbröker, Head of Marketing."
<G-vec00586-001-s047><appreciate.begrüßen><de> "Bologna-Ziel: Promotion als ""Third cycle"" Empfehlung ARGE TU/TH und TU9 Die deutschen Technischen Universitäten begrüßen eine Weiterentwicklung der Promotion in Richtung einer strukturierten Doktorandenausbildung und vollziehen diese bereits aktiv."
<G-vec00586-001-s047><appreciate.begrüßen><en> "Bologna-Objective: Doctoral phase as a ""third cycle"" Recommendation of ARGE TU/TH and TU9 The German Technical Universities appreciate the trend towards a structured programme for PhD candidates and already implement these actively."
<G-vec00586-001-s048><appreciate.begrüßen><de> BesucherInnen mögen die Geschichte in Bildern und kurzen Texten; sie würden es jedoch begrüßen, wenn man in der Ausstellung direkt im Internet zu weiteren Informationen surfen kann.
<G-vec00586-001-s048><appreciate.begrüßen><en> Visitors like the short history explained through pictures and short texts; they would also appreciate the chance to browse for further information about this topic within the exhibition.
<G-vec00586-001-s049><appreciate.begrüßen><de> """Wir sind mit dem Ergebnis des Meetings sehr zufrieden und begrüßen die Bereitschaft des Forest Service, sich mit uns zu treffen und an den restlichen vier Themen zu arbeiten"", sagte Mari-Ann Green, Chairman und CEO von Formation Capital Corporation, die ebenfalls am Meeting teilnahm."
<G-vec00586-001-s049><appreciate.begrüßen><en> """We are very pleased with the outcome of the meeting and appreciate the Forest Service's willingness to meet and work with us on these last remaining issues"", stated Mari-Ann Green, Chairman and CEO of Formation Capital Corporation, who was present at the meeting."
<G-vec00586-001-s050><appreciate.begrüßen><de> Um individuelle Interessen rechtzeitig berücksichtigen zu können, würden wir einen persönlichen Kontakt frühzeitig vor Antritt Ihrer Reise sehr begrüßen.
<G-vec00586-001-s050><appreciate.begrüßen><en> To cover your personal interests, we would greatly appreciate an early contact.
<G-vec00586-001-s051><appreciate.begrüßen><de> Erklärt, dass sie über ihn, und Sie würden es begrüßen, wenn sie nicht.
<G-vec00586-001-s051><appreciate.begrüßen><en> Explain that they have crossed it, and you would appreciate it if they didn’t.
<G-vec00586-001-s052><appreciate.begrüßen><de> "Manfred Santen, Pestizidexperte von Greenpeace: ""Wir begrüßen die Absenkung von Höchstmengen, stellen aber gleichzeitig fest, dass dies lediglich ein erster Schritt in die richtige Richtung ist."
<G-vec00586-001-s052><appreciate.begrüßen><en> "Manfred Santen, pesticide expert from Greenpeace: ""We appreciate the reduction of the MRLs, but also point out that this is only a first step in the right direction."
<G-vec00135-001-s109><embrace.begrüßen><de> Wir begrüßen Technologien und nutzen sie, um laufend innovative Lösungen weiterzuentwickeln, die die Vision und die Anforderungen unserer Regierungskunden unterstützen.
<G-vec00135-001-s109><embrace.begrüßen><en> We embrace technology and leverage it to continuously develop innovative solutions which support the vision and requirements of our client governments.
<G-vec00135-001-s110><embrace.begrüßen><de> Wir sind hier und wir anerkennen und begrüßen euch als die galaktischen Bürger die ihr seid.
<G-vec00135-001-s110><embrace.begrüßen><en> We are here, and we acknowledge and embrace you as the Galactic Citizens that you are.
<G-vec00135-001-s111><embrace.begrüßen><de> "Die Brutalität der Dschihadisten ist kein Grund für die irakischen Arbeiter, die zynischen ""demokratischen"" Imperialisten und ihren ""Krieg gegen den Terror"" zu begrüßen."
<G-vec00135-001-s111><embrace.begrüßen><en> "The brutality of the jihadis is no reason for Iraqi workers to embrace the cynical ""democratic"" imperialists and their ""war on terror."""
<G-vec00135-001-s112><embrace.begrüßen><de> Sie streben an zu beweisen, dass es vernünftig ist sowohl strukturelle Armut zu bekämpfen als auch befreite Märkte zu befürworten, sowohl Würde am Arbeitsplatz als auch stabilen Schutz für gerechte Eigentumsansprüche anzustreben, die Freiheit von Verbindungen zu begrüßen und zugleich willkürliche Diskriminierung zu bekämpfen, sowohl Frieden als auch ökonomische Freiheit zu fördern, die Ablehnung von Krieg und Imperialismus mit der Unterstützung von friedlichen, freiwilligen Kooperationen auf allen Ebenen zu verbinden.
<G-vec00135-001-s112><embrace.begrüßen><en> They seek to demonstrate that it's reasonable both to oppose structural poverty and to favor freed markets, to seek both workplace dignity and robust protections for just possessory claims, to embrace freedom of association while opposing arbitrary discrimination, to foster both peace and economic liberty, to link rejection of war and imperialism with support for peaceful, voluntary cooperation at all levels.
<G-vec00135-001-s113><embrace.begrüßen><de> Einige Erdbewohner waren dadurch wach-gerüttelt, das LICHT zu begrüßen, das das Leben des Planeten rettete, und sie waren in der Lage, die Fesseln der Marionetten abzuwerfen, die sie bisher gefangen gehalten hatten.
<G-vec00135-001-s113><embrace.begrüßen><en> Some residents were stirred to embrace the light that saved the planet's life, and by so doing, they were able to cast off the puppets' shackles that had held them captive.
<G-vec00135-001-s114><embrace.begrüßen><de> Wir begrüßen Israels demokratische Ideologie, ein Staat zu sein für das jüdische Volk und all seine Bürger, unabhängig von ethnischer Zugehörigkeit oder Glaubensbekenntnis.
<G-vec00135-001-s114><embrace.begrüßen><en> We embrace Israel’s democratic ideology as a state for the Jewish people and all of its citizens, regardless of ethnicity or creed.
<G-vec00135-001-s115><embrace.begrüßen><de> """Im Radisson Hotel Bangkok Sathorn sind wir bestens vorbereitet, diesen Wandel zu begrüßen."
<G-vec00135-001-s115><embrace.begrüßen><en> """At Radisson Hotel Bangkok Sathorn, we are prepared to embrace this change."
<G-vec00135-001-s116><embrace.begrüßen><de> "Aber PASST AUF: Ich sage nicht, dass wir negative Emotionen haben, ausleben oder begrüßen sollten; genauso wenig wie die Cassiopaeaner jemals gesagt haben, dass wie ""die Dunkelheit annehmen"" sollten."
<G-vec00135-001-s116><embrace.begrüßen><en> "Now please note: I am not saying that we are to have, express, or embrace negative emotions; just as I have never said, nor have the Cassiopaeans ever said that we are to ""embrace the darkness."""
<G-vec00135-001-s117><embrace.begrüßen><de> """Wir begrüßen eine Leitphilosophie, um allen, die Gartenmöbel kaufen, eine freundliche, lehrreiche und sichere Erfahrung zu bieten."
<G-vec00135-001-s117><embrace.begrüßen><en> "After-sale Service ""We embrace a guiding philosophy to provide a friendly, educational and secure experience to anyone buying outdoor furniture."
<G-vec00135-001-s118><embrace.begrüßen><de> Es gibt viele, die den Fortschritt befürchten und andere die ihn begrüßen; trotzdem möchte keiner traditionelle Lebensweisen verlieren, Wälder abgebaut oder historische Gebäude in Ruinen sehen.
<G-vec00135-001-s118><embrace.begrüßen><en> There are many who fear progress and others who embrace it; regardless, no one wishes to see traditional ways of life lost, forests cut down, or historic buildings in ruins. Read more
<G-vec00135-001-s119><embrace.begrüßen><de> Helena Blavatsky und Henry Steel Olcott, Gründer der Theosophical Society, kommen aus den USA in Sri Lanka an, begrüßen Buddhismus und beginnen eine Kampagne um Buddhismus auf der Insel wiederzubeleben, indem sie zur Etablierung von buddhistischen Schulen anregen.
<G-vec00135-001-s119><embrace.begrüßen><en> Helena Blavatsky and Henry Steel Olcott, founders of the Theosophical Society, arrive in Sri Lanka from the USA, embrace Buddhism, and begin a campaign to restore Buddhism on the island by encouraging the establishment of Buddhist schools.
<G-vec00135-001-s120><embrace.begrüßen><de> Abenteuerlustig, kreativ und offen– Obwohl man niemals leichtsinnig sein sollte, sollte man doch Risiken eingehen und Kreativität begrüßen.
<G-vec00135-001-s120><embrace.begrüßen><en> Be Adventurous, Creative And Open-Minded– While you never want to be reckless, it’s important to take risks and embrace your creativity.
<G-vec00135-001-s121><embrace.begrüßen><de> Die Menschen der dritten Dimension begrüßen spirituelle und universelle Erleuchtung zum richtigen Zeitpunkt für jeden Einzelnen, und eure endgültige Verantwortung muss eurer eigenen Weiterentwicklung in dieser Hinsicht gelten.
<G-vec00135-001-s121><embrace.begrüßen><en> Third-density peoples embrace spiritual and universal enlightenment at the right time for each of them, and your ultimate responsibility is your own evolution in those respects.
<G-vec00135-001-s122><embrace.begrüßen><de> Von ganzem Herzen begrüßen sie den globalen, multinationalen Modus, den sie Fortschritt nennen.
<G-vec00135-001-s122><embrace.begrüßen><en> They wholeheartedly embrace the global, multinational mode of operation and call it progress.
<G-vec00135-001-s123><embrace.begrüßen><de> Lasst zu, dass ihr das begrüßen könnt, was wir euch berichten, anstelle der Dinge, die Andere glauben, denn zuweilen gibt es Vorurteile uns gegenüber, weil unsere Präsenz alte Glaubensvorstellungen herausfordert.
<G-vec00135-001-s123><embrace.begrüßen><en> Let yourself embrace what we tell you rather than what others believe, as sometimes there is a bias against us because our presence challenges old beliefs.
<G-vec00135-001-s124><embrace.begrüßen><de> Der nächste Schritt im Diskurs um Menschenrechte und Internet könnte sein, sich dafür stark zu machen gezielt jene Stakeholder zum Gespräch einzuladen, von denen kein Konsens zu erwarten ist, ihnen zuzuhören, die Kontroverse zu begrüßen um an ihr zu gedeihen.
<G-vec00135-001-s124><embrace.begrüßen><en> To run on a par in the field of Internet Governance, the next step in the discourse about human rights could be to agitate for inviting particularly those stakeholders to the dialog, from whom no consensus is to be expected – to listen to them, embrace the controversy in order to grow with it.
<G-vec00135-001-s038><hail.begrüßen><de> Während wir uns an die Opfer unserer Mitarbeiter erinnern, begrüßen wir auch ihre Errungenschaften.
<G-vec00135-001-s038><hail.begrüßen><en> As we remember the heavy sacrifices of our staff, we also hail their accomplishments.
<G-vec00135-001-s039><hail.begrüßen><de> Darum begrüßen wir den ältesten, den Raja Yoga.
<G-vec00135-001-s039><hail.begrüßen><en> Therefore, we hail the yoga of the past — the Raja Yoga.
<G-vec00135-001-s040><hail.begrüßen><de> Außerdem begrüßen wir die Verabschiedung von Resolutionen über Diskriminierung und Gewalt gegen Frauen und über Zwangs- und Kinderehe, sowie über Jugend und Menschenrechte, und die Verlängerung des Mandats der Sonderberichterstatter zu außergerichtlichen, summarischen oder willkürlichen Hinrichtungen, zum Menschenhandel und zur Unabhängigkeit der Richter und Rechtsanwälte.
<G-vec00135-001-s040><hail.begrüßen><en> We also hail the adoption of resolutions on discrimination, violence against women and forced or early marriages, young people, and human rights, as well as the renewal of the mandates of special rapporteurs on summary, arbitrary or extrajudicial executions, human trafficking, and the independence of judges and attorneys.
<G-vec00135-001-s041><hail.begrüßen><de> "So begrüßen sie die ""Wirtschaftswunder"" der ""asiatischen Tigerstaaten"" (Hongkong, Singapur, Südkorea, Taiwan und Malaysia), Brasilien oder Chile."
<G-vec00135-001-s041><hail.begrüßen><en> "So they hail the ""economic miracles"" of the so-called ""Asian Tigers"" (Hong Kong, Singapore, South Korea, Taiwan and Malaysia), Brazil or Chile."
<G-vec00135-001-s095><welcome.begrüßen><de> Als eine der Messegeschaften mit relativ vielen Veranstaltungen, die weltweit an den verschiedensten Standorten stattfinden, begrüßen wir die Inititiative der UFI.
<G-vec00135-001-s095><welcome.begrüßen><en> As one of the trade fair companies with a relatively large number of events in a variety of locations around the world, we welcome this UFI initiative.
<G-vec00135-001-s096><welcome.begrüßen><de> Wir begrüßen Sie auf eine attraktive Wohnung im privaten Haus durch den Garten ein exzellenter Lage, umgeben.
<G-vec00135-001-s096><welcome.begrüßen><en> We welcome you to an attractive apartment situated in the private house surrounded by the garden an excellent position.
<G-vec00135-001-s097><welcome.begrüßen><de> Wir sind stark in der Entwicklung neuer Produkte, wir begrüßen OEM / ODM-Bestellungen und können Käuferlogos drucken und kundenspezifische Verpackungen liefern.
<G-vec00135-001-s097><welcome.begrüßen><en> We are strong in developing new products, we welcome OEM/ODM orders and can print buyer`s logos and provide customerized packaging.
<G-vec00135-001-s098><welcome.begrüßen><de> Diese Art der Blume USB-Sticks brechen die sterotype Leute denken, Leder heißt robust, es ist romantisch suchen begrüßen die von den meisten Weibchen oder Künstler.
<G-vec00135-001-s098><welcome.begrüßen><en> This kind of flower usb flash drives break the sterotype of people think leather means robust, It's romantic looking welcome by most of the females or artists.
<G-vec00135-001-s099><welcome.begrüßen><de> Mit dieser Ausgabe begrüßen wir auch Pablo Romero Fresco als unseren neuen Veranstaltungskalenderbeauftragten.
<G-vec00135-001-s099><welcome.begrüßen><en> With this issue, we also welcome Pablo Romero Fresco as our new calendar of events officer.
<G-vec00135-001-s100><welcome.begrüßen><de> Der Tag lässt sich am besten bei einem reichhaltigen Frühstück vom Buffet am Swimmingpoolpark begrüßen, aber auch mittags und abends werden selbst die feinsten Gaumen verwöhnt: Die abwechslungsreichen Menüs werden täglich mit frischen Produkten aus dem Umland, teilweise vom eigenen Bauernhof, zubereitet.
<G-vec00135-001-s100><welcome.begrüßen><en> The tag lets itself most welcome with a rich breakfast buffet in the pool park, but also for lunch and dinner, even the most delicate palates are spoiled: The menus are varied daily with fresh produce from the surrounding area, partly from her own farm prepared.
<G-vec00135-001-s101><welcome.begrüßen><de> Wir begrüßen es, wenn Sie alle in Ordnung mit ihm, alle Arten von sex Erwachsener Mensch haben kann.
<G-vec00135-001-s101><welcome.begrüßen><en> We welcome if they are all okay with it, all kinds of sex adult humans can have.
<G-vec00135-001-s102><welcome.begrüßen><de> Wir begrüßen unsere Gäste mit einer Tageskarte, Auf unserer Facebook-Seite sehen Sie das wöchentliche Menü.
<G-vec00135-001-s102><welcome.begrüßen><en> We welcome our guests with a daily menu, On our Facebook page you can see the weekly menu.
<G-vec00135-001-s103><welcome.begrüßen><de> Wir begrüßen Sie auf unserer neuen Website.
<G-vec00135-001-s103><welcome.begrüßen><en> We welcome you to our new website.
<G-vec00135-001-s104><welcome.begrüßen><de> Xiamen Meto Auto Parts Industry Co., Ltd ist einer der führenden China Multifunktions-Heckscheibenwischer Klinge Hersteller, begrüßen zu billig multifunktionalen Heckscheibenwischer Klinge aus unserer Fabrik.
<G-vec00135-001-s104><welcome.begrüßen><en> Xiamen Meto Auto Parts Industry Co.,Ltd is one of the leading China multifunctional rear wiper blade manufacturers, welcome to wholesale cheap multifunctional rear wiper blade from our factory.
<G-vec00135-001-s105><welcome.begrüßen><de> Sie begrüßen heute den Dorfmarkt.
<G-vec00135-001-s105><welcome.begrüßen><en> They welcome today the village market.
<G-vec00135-001-s106><welcome.begrüßen><de> Wir bieten unseren freundlichen Gruß an und begrüßen Sie, um am Hotel Park Avenue zu stoppen.
<G-vec00135-001-s106><welcome.begrüßen><en> We offer our kind greeting and welcome you to stop at Hotel Park Avenue.
<G-vec00135-001-s107><welcome.begrüßen><de> Während in anderen Ländern die meisten davor zurückschrecken, fotografiert zu werden, neigen Nepalesen dazu, solche Gelegenheiten zu begrüßen.
<G-vec00135-001-s107><welcome.begrüßen><en> While in other countries, most would shy away from being photographed, Nepalese tend to welcome such opportunities.
<G-vec00135-001-s108><welcome.begrüßen><de> Wir begrüßen Kunden von in- und auswärts, um mit uns für gegenseitige Vorteile und gemeinsame Entwicklung zusammenzuarbeiten.
<G-vec00135-001-s108><welcome.begrüßen><en> We welcome customers from domestic and abroad to co-operate with us for mutual benefits and common development.
<G-vec00135-001-s109><welcome.begrüßen><de> Die Beschäftigten berichteten, sie seien aus dem einzigen Grund entlassen worden, dass sie sagten, sie würden den Beitritt zu einer Gewerkschaft zum Schutz ihrer Rechte begrüßen.
<G-vec00135-001-s109><welcome.begrüßen><en> Workers have reported that they have been dismissed just for saying they would welcome joining a union to protect their rights.
<G-vec00135-001-s110><welcome.begrüßen><de> Aus der Form erinnert an einen Schmetterling, wird Flap geformt und gefaltet, um eine Platte gewundenen bereit, Objekte und Bücher begrüßen werden.
<G-vec00135-001-s110><welcome.begrüßen><en> From the shape reminiscent of a butterfly, Flap is shaped and folded to become a slab sinuous ready to welcome objects and books.
<G-vec00135-001-s111><welcome.begrüßen><de> Deshalb begrüßen wir es, dass es neuerdings einen von der IETF vorgeschlagenen Standard gibt, um DNS-Anfragen zu verschlüsseln: das DNS over TLS (DoT).
<G-vec00135-001-s111><welcome.begrüßen><en> Therefore we welcome the fact that there is now a standard proposed by the IETF to encrypt DNS requests: the DNS over TLS (DoT).
<G-vec00135-001-s112><welcome.begrüßen><de> Das WM-Maskottchen Kebowlino war gestern am Flughafen in München, um die Teilnehmer der Weltmeisterschaften zu begrüßen.
<G-vec00135-001-s112><welcome.begrüßen><en> Yesterday Kebowlino - mascot of World Men Championships 2010 - had been at Munich Airport to welcome the participants of the championships.
<G-vec00135-001-s113><welcome.begrüßen><de> Wir begrüßen Sie in Shan Translation, ein innovatives und inspirierendes Unternehmen, das zu einem wesentlichen Bestandteil der weltweit lebendigsten und führenden Industrie - der Sprachendienst geworden ist.
<G-vec00135-001-s113><welcome.begrüßen><en> We are pleased to welcome you at Shan Translation, an innovative and inspirational company that has become an essential part of the world’s most vibrant and leading industry – the languages service.
<G-vec00135-001-s114><welcome.begrüßen><de> Oder reisen Sie im Menü links die Etappen virtuell einzeln durch - wir würden uns freuen, Sie bei einer oder mehreren der 43 Etappen begrüßen zu dürfen.
<G-vec00135-001-s114><welcome.begrüßen><en> Alternatively, use the menu on the left-hand side to take a virtual journey through the stages - we would be delighted to welcome you to one or more of the 43 stages.
<G-vec00135-001-s115><welcome.begrüßen><de> Wir freuen uns, Sie auf der neuen Internet-Seite der Bavaria-Alm begrüßen zu dürfen.
<G-vec00135-001-s115><welcome.begrüßen><en> We are glad to welcome you on the new internet of Bavaria Alp.
<G-vec00135-001-s116><welcome.begrüßen><de> Wir freuen uns ganz besonders, Sie bei uns als Gast begrüßen zu dürfen.
<G-vec00135-001-s116><welcome.begrüßen><en> We are especially pleased to welcome you as our guest.
<G-vec00135-001-s117><welcome.begrüßen><de> """Vielfalt ist bei uns kein leeres Schlagwort"", erklärt er und ergänzt, dass die WHU anstrebe, in Zukunft mehr afrikanische Studenten an ihren Standorten begrüßen zu dürfen."
<G-vec00135-001-s117><welcome.begrüßen><en> """Diversity is not an empty buzzword for us,"" he explained, adding that WHU was aiming to welcome more African students to its campuses in future."
<G-vec00135-001-s118><welcome.begrüßen><de> Wir hoffen, Sie bei uns begrüßen zu dürfen.
<G-vec00135-001-s118><welcome.begrüßen><en> We hope to welcome you with us.
<G-vec00135-001-s119><welcome.begrüßen><de> Wir freuen uns, den Schauspieler und Sänger Brent Spiner auf der FedCon 27 im Hotel Maritim Bonn, begrüßen zu dürfen.
<G-vec00135-001-s119><welcome.begrüßen><en> We are pleased to welcome actor and singer Brent Spiner at the FedCon 27 in the Hotel Maritim Bonn.
<G-vec00135-001-s120><welcome.begrüßen><de> Wir würden uns freuen Sie auf dem Messestand von Elvstrøm Sails A/S (Halle 11 / F21) begrüßen zu dürfen.
<G-vec00135-001-s120><welcome.begrüßen><en> We would be pleased to welcome you at the stand of ElvstrÃ ̧m Sails A/S (Hall 11 / F21) .
<G-vec00135-001-s121><welcome.begrüßen><de> Wir würden uns freuen, Sie auf unserem Messestand begrüßen zu dürfen, um Ihnen den gesamten Umfang unseres Angebotes persönlich vorstellen zu können.
<G-vec00135-001-s121><welcome.begrüßen><en> We are looking forward to welcome you to our stand to present our whole product range to you personally.
<G-vec00135-001-s122><welcome.begrüßen><de> Werfen Sie auch einen Blick in unseren Messekalender, wir würden uns freuen, Sie auf einem unserer Messestände überall auf der Welt begrüßen zu dürfen.
<G-vec00135-001-s122><welcome.begrüßen><en> We would be delighted to welcome you toÂ our stand at one of the many trade fairs we attend all over the world.
<G-vec00135-001-s123><welcome.begrüßen><de> Vielen Dank für Ihre Bewertung, werden wir Sie gerne wieder in unserem Hotel begrüßen zu dürfen.
<G-vec00135-001-s123><welcome.begrüßen><en> Thank you for the review, we will be happy to welcome you again at our facility.
<G-vec00135-001-s124><welcome.begrüßen><de> Die Hostellerie Provençale und sein Personal freuen sich darauf, Sie begrüßen zu dürfen.
<G-vec00135-001-s124><welcome.begrüßen><en> The Hostellerie Provençale and its staff are pleased to welcome you.
<G-vec00135-001-s125><welcome.begrüßen><de> Kontaktieren Sie uns, wir werden uns freuen, Sie begrüßen zu dürfen.
<G-vec00135-001-s125><welcome.begrüßen><en> Contact us, we will be glad to welcome you.
<G-vec00135-001-s126><welcome.begrüßen><de> Die ActiLingua Academy war sehr erfreut, Damon, einen jungen Reise-Vlogger, im wunderschönen Wien begrüßen zu dürfen.
<G-vec00135-001-s126><welcome.begrüßen><en> The ActiLingua Academy was extremely happy to welcome Damon, a young travel vlogger, in the beautiful city of Vienna.
<G-vec00135-001-s127><welcome.begrüßen><de> "CEO und Director Bradford Cooke meinte dazu: ""Es freut mich außerordentlich, Tomas in der Geschäftsleitung von Endeavour begrüßen zu dürfen."
<G-vec00135-001-s127><welcome.begrüßen><en> "Bradford Cooke, CEO and Director, commented, ""I am thrilled t o welcome Tomas to the Endeavour management team."
<G-vec00135-001-s128><welcome.begrüßen><de> Dies ist perfekt für diejenigen von uns, wollen die Kneipe zu machen, oder um einige Besucher in den optimalen Bedingungen für die Umwandlung begrüßen zu dürfen.
<G-vec00135-001-s128><welcome.begrüßen><en> This will be perfect for those of us wanting to make the pub, or to welcome some visitors in the optimal conditions for conversion.
<G-vec00135-001-s129><welcome.begrüßen><de> Kontaktieren Sie uns per E-Mail, indem Sie hier oder +33 (0)4 90 46 91 12 und wir schicken Ihnen ein individuelles Angebot für Ihre Bedürfnisse, und hoffen, Sie bald in unserer Region begrüßen zu dürfen.
<G-vec00135-001-s129><welcome.begrüßen><en> Contact us by email by clicking here or +33 (0)4 90 46 91 12 and we will send you a customized offer for your needs, and hope to welcome you soon in our place. Reservation
<G-vec00135-001-s130><welcome.begrüßen><de> Wir tun unser Bestes, damit unsere Gäste begrüßen zu dürfen.
<G-vec00135-001-s130><welcome.begrüßen><en> We do our best to make our guests welcome.
<G-vec00135-001-s131><welcome.begrüßen><de> Drei Wohnungen in verschiedenen Größen und alle mit großer Sorgfalt eingerichtet, werden wir uns freuen, Sie für Ihren Urlaub im Herzen der Toskana, begrüßen zu dürfen.
<G-vec00135-001-s131><welcome.begrüßen><en> Three apartments of different sizes and all furnished with great care, we will be happy to welcome you for your holiday in the heart of Tuscany.
<G-vec00135-001-s132><welcome.begrüßen><de> Darüber hinaus sind wir sehr stolz, immer wieder eine Vielzahl an BesucherInnen bei internen und externen Veranstaltungen begrüßen zu dürfen.
<G-vec00135-001-s132><welcome.begrüßen><en> Besides that we are also proud to welcome a multitude of visitors at our expert events organised either in-house or at external venues.
<G-vec00135-001-s133><welcome.begrüßen><de> Im kleinen Bergdorf Trafoi, wo die Natur ihre Ursprünglichkeit bewahrt hat, begrüßt die Familie der Skilegende Gustav Thöni seine Gäste im behutsam renovierten Traditionshotel.
<G-vec00135-001-s133><welcome.begrüßen><en> The family of skiing legend Gustav Thöni welcome guests to their carefully renovated yet traditional hotel, surrounded by unspoilt nature in the small mountain village of Trafoi.
<G-vec00135-001-s134><welcome.begrüßen><de> Anfragen von den globalen Grossisten, von den Verteilern, von den Kunden, von den Mitteln und von der OEM/ODM werden begrüßt.
<G-vec00135-001-s134><welcome.begrüßen><en> Enquiries from global wholesalers, distributors, buyers, agents, and DC Air Curtains OEM/ODM are welcome.
<G-vec00135-001-s135><welcome.begrüßen><de> Nominierungen qualifizierter Wissenschaftlerinnen werden besonders begrüßt.
<G-vec00135-001-s135><welcome.begrüßen><en> Nominations for qualified female scientific researchers are especially welcome.
<G-vec00135-001-s136><welcome.begrüßen><de> Nach einer Stunde Flug wurden wir dort sehr freundschaftlich begrüßt und ins Hotel gebracht.
<G-vec00135-001-s136><welcome.begrüßen><en> After an hourÂ ́s flight we received a very friendly welcome and were taken to our hotel.
<G-vec00135-001-s137><welcome.begrüßen><de> In dem Canada Hotel Budapest werden die Kleintiere auch begrüßt.
<G-vec00135-001-s137><welcome.begrüßen><en> In Canada Hotel Budapest pets are also welcome.
<G-vec00135-001-s138><welcome.begrüßen><de> In vielen Dörfern werden die Besucher, die ebenfalls dazu eingeladen sind, an dem Rennen teilzunehmen, an Verpflegungsständen mit Musik begrüßt.
<G-vec00135-001-s138><welcome.begrüßen><en> A number of villages with food stands and musical entertainment welcome the spectators who are also invited to take part in this walk.
<G-vec00135-001-s139><welcome.begrüßen><de> Wir wurden gleich von den Besitzern, Sunny und Bob begrüßt und mit ersten Informationen versorgt.
<G-vec00135-001-s139><welcome.begrüßen><en> Sunny and Bob, the owners gave us a warm welcome and some first essential informations.
<G-vec00135-001-s141><welcome.begrüßen><de> Jean-Pierre Clerc ist Ski- und Wanderlehrer und sein Team begrüßt alle Besucher, Sportler oder Anfänger - immer mit einem Lächeln und Leidenschaft.
<G-vec00135-001-s141><welcome.begrüßen><en> Skiing and hiking instructor, Jean-Pierre Clerc and his team welcome visitors, athletes or beginners, with a smile and enthusiasm.
<G-vec00135-001-s142><welcome.begrüßen><de> „Uni für Einsteiger“ startet um 8.30 Uhr im Audimax (Straße am Forum 1, Gebäude 30.95): Professor Norbert Henze, Prorektor für Struktur, begrüßt die Schülerinnen und Schüler.
<G-vec00135-001-s142><welcome.begrüßen><en> “Uni für Einsteiger” will start at 8.30 hrs at the Audimax (Straße am Forum 1, building 30.95): Professor Norbert Henze, Vice-President for Structural Matters, will welcome the pupils.
<G-vec00135-001-s143><welcome.begrüßen><de> Ambient begrüßt dich im Morgengrauen mit einer warmen Umarmung, um die Angst zu entfernen und die Kraft mit einem fantastischen Frühstück wiederzuerlangen, wenn du zurückkommst “Halloween nach Party “Die im Zelt im königlichen Park, am Fuße der Burg Bran, stattfinden wird.
<G-vec00135-001-s143><welcome.begrüßen><en> Ambient will welcome you at dawn with a warm embrace to remove the fear and regain strength with a fantastic breakfast, when you return from “Halloween After Party” which will be held in the tent located in the Royal Park, at the foot of Castle Bran.
<G-vec00135-001-s144><welcome.begrüßen><de> Frère Roger begrüßt ihn, von einigen Kindern begleitet, mit kurzen Worten.
<G-vec00135-001-s144><welcome.begrüßen><en> Brother Roger, surrounded by children, says a few words of welcome.
<G-vec00135-001-s146><welcome.begrüßen><de> Ferner betreut Gondwana in diesem Jahr den Checkpoint 3 auf halber Strecke nach Swakopmund, und begrüßt dort die Fahrer und ihre Unterstützer mit leckeren und gesunden Snacks sowie heißen und kalten Getränken.
<G-vec00135-001-s146><welcome.begrüßen><en> This year, Gondwana Collection will welcome riders and support staff at the ‘Gondwana Village’ Checkpoint 3 with tasty and healthy snacks as well as hot and cold drinks.
<G-vec00135-001-s147><welcome.begrüßen><de> Die Initiativen der Europäischen Kommission zur Verbesserung der Qualität europäischer Rechtsakte werden als Beitrag zu einer europaweiten Subsidiaritätskultur ausdrücklich begrüßt.
<G-vec00135-001-s147><welcome.begrüßen><en> The European Commission’s initiatives to improve the quality of European legal acts are a very welcome contribution to the promotion of a culture of subsidiarity throughout Europe.
<G-vec00135-001-s148><welcome.begrüßen><de> Die Hochschule begrüßt jedes Semester mehrere hundert Gaststudierende aus aller Welt.
<G-vec00135-001-s148><welcome.begrüßen><en> Each semester we welcome several hundred exchange students from all over the world.
<G-vec00135-001-s149><welcome.begrüßen><de> Der Governor von Tamil Nadu begrüßt die Teilnehmer.
<G-vec00135-001-s149><welcome.begrüßen><en> The governor ot Tamil Nadu gives a speech to welcome the participants.
<G-vec00135-001-s150><welcome.begrüßen><de> Unsere Crew begrüßt dich mit einem edlen Cocktail und gibt dir Insidertipps für Sehenswürdigkeiten und tolle Unternehmungen in der Stadt.
<G-vec00135-001-s150><welcome.begrüßen><en> Our crew will welcome you with a cocktail and inside advice on what to see and do in their city.
<G-vec00135-001-s151><welcome.begrüßen><de> Gäste werden bei der Ankunft mit einem Willkommenscocktail begrüßt und ein im Preis inbegriffenes amerikanisches Frühstück wird jeden Morgen serviert.
<G-vec00135-001-s151><welcome.begrüßen><en> Guests are served a welcome cocktail upon arrival and a complimentary American breakfast each morning.
<G-vec00366-002-s106><embrace.begrüßen><de> Als Unternehmen haben wir die Entscheidung der Veranstalter, PVC und alle seine wunderbaren Eigenschaften beim Bau des Olympic Parks einzusetzen, sehr begrüßt.
<G-vec00366-002-s106><embrace.begrüßen><en> As a company, it had been greatly cheered by the Olympic organisers’ decision to embrace PVC and all its magical qualities in creating the Olympic Park.
<G-vec00366-002-s107><embrace.begrüßen><de> Und wer diese Werte nicht begrüßt, wird häufig – besonders in liberalen Kreisen – als sozialer und intellektueller Schwachkopf bezeichnet.
<G-vec00366-002-s107><embrace.begrüßen><en> And those who do not embrace these virtues are often regarded, especially in liberal circles, as social and intellectual dunces.
<G-vec00366-002-s108><embrace.begrüßen><de> “Wir glauben, wie eine Vielzahl von fortschrittlichen Unternehmen auch, dass die europäische Industrie nur wettbewerbsfähig bleiben kann, wenn sie Maßnahmen für eine kohlenstoffarme und ressourceneffiziente Wirtschaft und einen starken Sozial-, Arbeits-, Verbraucher- und Umweltschutz begrüßt, schreiben die NGOs in dem Brief.
<G-vec00366-002-s108><embrace.begrüßen><en> “We believe, as do a vast number of progressive companies, that the only way for European industry to be competitive is to innovate with the limits of a low carbon and resource efficient economy, and to embrace strong social, labour, consumer and environmental protection measures,” the letter said.
