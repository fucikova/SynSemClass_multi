<G-vec00332-001-s093><alert.alarmieren><de> Wenn ein Mädchen träumt, wie sie Geliebte verwandelte sich in eine riesige schwarze SpinneEin solcher Traum sollte sie alarmieren.
<G-vec00332-001-s093><alert.alarmieren><en> If a girl dreams, like her beloved turned into a huge black spider, such a dream should alert her.
<G-vec00332-001-s094><alert.alarmieren><de> Wir wissen nicht, was die Ergebnisse der Prüfung weil ’ zu alarmieren, Krankenhauspersonal ist eine Frau die Schwangerschaft.
<G-vec00332-001-s094><alert.alarmieren><en> We don't know what the results of the exam because ’ to alert hospital staff is a woman's pregnancy.
<G-vec00332-001-s095><alert.alarmieren><de> Die Listen werden mit Spur Namen gesät, die die Publikationen Ihrer Wiederverwendung der Namen alarmieren.
<G-vec00332-001-s095><alert.alarmieren><en> The lists are seeded with trace names that will alert the publications of your re-use of the names.
<G-vec00332-001-s096><alert.alarmieren><de> Tumoren oder andere Brustkrankheiten mißt Wärmer als umgebendes Gewebe und kann einen Arzt zu einem Problem dadurch alarmieren, bevor ein Tumor wirklich offensichtlich ist.Medizinische Doktoren, die die Brustscans sind das bestätigte Brett deuten und halten zusätzlichen zwei Jahre der Ausbildung aus, zum als thermologist zu qualifizieren.
<G-vec00332-001-s096><alert.alarmieren><en> Tumors or other breast diseases measures warmer than surrounding tissue and can thereby alert a physician to a problem before a tumor is actually palpable.Medical doctors who interpret the breast scans are board certified and endure an additional two years of training to qualify as a thermologist.
<G-vec00332-001-s097><alert.alarmieren><de> Ein Babyphon am Kinderbett, dort wo es Ihr Kind nicht erreichen kann, wird Sie nachts alarmieren – zum Beispiel, wenn Ihr Kind aufhört zu atmen.
<G-vec00332-001-s097><alert.alarmieren><en> A baby monitor attached to the crib (where baby can’t reach it) will alert you to any nighttime—including struggling if baby stops breathing.
<G-vec00332-001-s098><alert.alarmieren><de> Versuchen Sie, diese Personen telefonisch zu erreichen und zu alarmieren.
<G-vec00332-001-s098><alert.alarmieren><en> Try to reach and alert these people by telephone.
<G-vec00332-001-s099><alert.alarmieren><de> Mehr noch: Springt ein Bewegungsmelder an, kann das Smart Home einen Sicherheitsdienst alarmieren und eine Videoaufnahme auf das Smartphone des Hausbewohners übermitteln.
<G-vec00332-001-s099><alert.alarmieren><en> What is more, if a motion sensor is triggered, the smart home can alert a security service and feed a video stream to the owner’s smartphone.
<G-vec00332-001-s100><alert.alarmieren><de> Alarmieren Sie einen Arzt in diesem Fall.
<G-vec00332-001-s100><alert.alarmieren><en> Alert a doctor in that case.
<G-vec00332-001-s101><alert.alarmieren><de> Ein vollständiger Standort, der insbesondere den Verdienst hat, gegen die (zahlreich) Handhabungs- und Wiedergewinnungsrisiken durch Sekten zu alarmieren.
<G-vec00332-001-s101><alert.alarmieren><en> A complete site which has in particular the merit to alert against (many) the risks of handling and recovery by sects.
<G-vec00332-001-s102><alert.alarmieren><de> Die Sirene kann nicht nur den Eindringling wegschrecken, sondern auch Sie und Ihren Nachbarn alarmieren, auch Menschen, die um.
<G-vec00332-001-s102><alert.alarmieren><en> The siren not only can scare away the intruder, but also alert you and your neighbor, also people that around.
<G-vec00332-001-s103><alert.alarmieren><de> Genauso ist es ein erfahrener Arzt, dessen Job es ist, die Gesundheit Ihrer Festplatte zu überwachen und Sie zu alarmieren, falls er mögliche Probleme entdeckt; es ist eine Putzfee für Ihre Festplatte, die alle ungenutzten Dateien und Speicherfresser erspähen kann; es ist eine Bank mit einem sehr sicheren Tresorraum, wo Sie all Ihre wichtigsten Dokumente und Bilder speichern können.
<G-vec00332-001-s103><alert.alarmieren><en> It’s also an experienced doctor whose job is to monitor the health of your hard drive and alert you in case it detects any potential issues; it’s a cleaning lady for your hard drive who can spot all unused files and space hogs; it’s a bank with a highly secure vault where you can store all your most important documents and images.
<G-vec00332-001-s104><alert.alarmieren><de> Systeme für die Reifendruckkontrolle überwachen den Reifendruck und alarmieren den Fahrer, wenn der tatsächliche Druck vom Sollwert abweicht.
<G-vec00332-001-s104><alert.alarmieren><en> Tire pressure monitoring systems are designed to monitor the air pressure of tires and to alert the driver in case of pressure loss.
<G-vec00332-001-s105><alert.alarmieren><de> Die Ankündigung der Apokalypse ist ein letzter Weckruf, um die Welt über ihren so nahe bevorstehenden drastischen Wandel zu alarmieren; umso ernster müssen wir diese Warnung nehmen.
<G-vec00332-001-s105><alert.alarmieren><en> The announcement of the Apocalypse is the last wake-up call to alert the world to the drastic changes that will soon occur; therefore, we must take this warning seriously.
<G-vec00332-001-s106><alert.alarmieren><de> Benachrichtigen und Alarmieren.
<G-vec00332-001-s106><alert.alarmieren><en> To inform and Alert.
<G-vec00332-001-s107><alert.alarmieren><de> Ein hochwertiges freies Mac spyware AbbauprogrammIST auch in der Lage, Sie zu alarmieren, jedesmal wenn ein Versuch, spyware oder adware auf Ihren Mac anzubringen gebildet wird.
<G-vec00332-001-s107><alert.alarmieren><en> A high-quality free mac spyware removal program will also be able to alert you every time an attempt to install spyware or adware on your mac is made.
<G-vec00332-001-s108><alert.alarmieren><de> """Gut-verwendete Sorge kann uns zu den Bereichen in unseren Leben alarmieren, die Aufmerksamkeit und benötigen, ändern."
<G-vec00332-001-s108><alert.alarmieren><en> """Well-used worry can alert us to areas in our lives that need attention and change."
<G-vec00332-001-s109><alert.alarmieren><de> Ein sicheres Areal erlaubt der Gruppe, Sicher Zu Schlafen, aber Hupende Gänse oder ein Bewegungentdeckendes Tachometer kann jene alarmieren, die gerade schlafen.
<G-vec00332-001-s109><alert.alarmieren><en> A secure area allows the group to Sleep Safe, but Honking Geese or a motion detecting Tachometer can alert those who are sleeping.
<G-vec00332-001-s110><alert.alarmieren><de> Es wird Ihnen auch für den Fall, alarmieren die SIM-Karte gewechselt wurde.
<G-vec00332-001-s110><alert.alarmieren><en> It will also alert you in case the SIM card has been changed.
<G-vec00332-001-s111><alert.alarmieren><de> Wir, in den höheren Regionen, versuchen unser Bestes, die Menschen darüber zu alarmieren, was im Begriff ist zu geschehen.
<G-vec00332-001-s111><alert.alarmieren><en> We, in the higher regions, are trying our best to alert people to what is about to happen.
<G-vec00332-001-s112><alert.alarmieren><de> "Es ist eine Art... nicht Besorgnis, aber vor allem eine Wachsamkeit, als ob sie alarmiert worden wären: ""Nur tun, was Du willst, nur denken, was Du willst, nur fühlen, was Du willst, nur sagen, was Du willst..."" So ist das ständig, ununterbrochen, Tag und Nacht."
<G-vec00332-001-s112><alert.alarmieren><en> It's a sort of... not anxiety, but above all a vigilance, as if they were on the alert: “May we do nothing but what You want, think nothing but what You want, feel nothing but what You want, say nothing but what You want....” Constantly, uninterruptedly, night and day.
<G-vec00332-001-s113><alert.alarmieren><de> Aber alarmiert zu sein genügt nicht.
<G-vec00332-001-s113><alert.alarmieren><en> But being on high alert is just not enough.
<G-vec00332-001-s114><alert.alarmieren><de> Guerillakräfte sollten immer alarmiert sein, mobil sein, sich schnell bewegen und die Geheimhaltung erhalten.
<G-vec00332-001-s114><alert.alarmieren><en> Guerilla forces should always stay alert, be mobile, move swiftly and maintain secrecy.
<G-vec00332-001-s115><alert.alarmieren><de> Kollabiert ein Besucher am Eingang, beginnt das Empfangspersonal unverzüglich mit der Basisversorgung, alarmiert hausintern Ärzte und Pflegepersonal, die dann die weitere Behandlung übernehmen, so dass eine lückenlose Versorgung von Notfallpatienten bis zur Übergabe an eine Intensivstation oder den Rettungsdienst gewährleistet ist.
<G-vec00332-001-s115><alert.alarmieren><en> If a visitor collapses near the entrance, the reception staff immediately start primary care and alert the doctors and nursing staff in the house. They take care of all further treatment, so that consistent care of emergency patients up to the transfer to an intensive care unit or emergency medical services is guaranteed.
<G-vec00332-001-s116><alert.alarmieren><de> Du kannst es so einstellen, dass Dich das Tool automatisch alarmiert, wenn die exakte Überschrift Deines Posts irgendwo erscheint, indem Du ihn in Anführungszeichen setzt.
<G-vec00332-001-s116><alert.alarmieren><en> You can set up an alert when the exact title of your post appears, by putting it in quotation marks.
<G-vec00332-001-s117><alert.alarmieren><de> Wir können versuchen ein System zu konstruieren, dass zumindest alarmiert wenn etwas merkwürdiges passiert und das Ihnen im Detail zeigt was passierte als die Maschine abstürzte und das es Ihnen ermöglicht Ihre Arbeit zu speichern und dann abstürzt.
<G-vec00332-001-s117><alert.alarmieren><en> What we could try to construct is a system which will at least alert if something dubious is happening and which can tell you in great detail what was happening when the machine crashed and which will allow you to save your work and then crash.
<G-vec00332-001-s118><alert.alarmieren><de> Preisstufen Alarm Indicator herunterladen Preisstufen Warnanzeige alarmiert, wenn der Kurs voreingestellten Werte erreicht.
<G-vec00332-001-s118><alert.alarmieren><en> Price Levels Alert Indicator Download Price Levels Alert Indicator will alert when price reaches preset levels.
<G-vec00332-001-s119><alert.alarmieren><de> Dr. Sonoiya, Leiter der Gesundheitsreferats im Headquarter der Ostafrikanischen Union, berichtet, die Ostafrikanische Union sei durch die Ebola-Ausbrüche in der DRC höchst alarmiert.
<G-vec00332-001-s119><alert.alarmieren><en> Dr. Sonoiya, head of the health department at the EAC headquarters, Arusha, Tanzania, reports that the EAC is on high alert due to the current Ebola outbreaks in the DRC.
<G-vec00332-001-s120><alert.alarmieren><de> Das ist ein Notfall Code, welcher sofort die Flugverkehrskontrolle alarmiert, dass ein Notfall besteht.
<G-vec00332-001-s120><alert.alarmieren><en> This is an emergency code that will quickly alert air traffic controllers that you have an emergency.
<G-vec00332-001-s121><alert.alarmieren><de> Ich frage mich, ob ihre wirtschaftlichen und politischen Entscheidungen richtig sind und wieso sie die internationale Gemeinschaft so spät alarmiert, da ja die Hungersnot voraussehbar war.
<G-vec00332-001-s121><alert.alarmieren><en> First I am asking what is the responsibility of the Nigeria government in its economic and political choices, in its delay to alert the international community because this famine could have been predicted.
<G-vec00332-001-s122><alert.alarmieren><de> Sobald unsere Threat Hunter bestätigen, dass eine Anomalie tatsächlich eine Bedrohung darstellt, werden Sie in weniger als 30 Minuten alarmiert.
<G-vec00332-001-s122><alert.alarmieren><en> Once our threat hunters have confirmed that an anomaly is an actual threat, they will alert you in less than 30 minutes.
<G-vec00332-001-s123><alert.alarmieren><de> Türkische Wissenschaftler sind allerdings alarmiert.
<G-vec00332-001-s123><alert.alarmieren><en> Indeed Turkey’s scientists are on the alert.
<G-vec00332-001-s124><alert.alarmieren><de> Rhinozerosse: Trauriges Verschwinden zu einem Zeitpunkt, an dem alle Gewissen durch die Risiken des Artensterbens und seiner Folgen für die Menschheit alarmiert sind, zu einem Zeitpunkt, an dem wir all unser Wissen und unsere Technologien in den Dienst des Schutzes unserer Arten stellen könnten, da stirbt das letzte männliche weiße Rhinozeros aus...
<G-vec00332-001-s124><alert.alarmieren><en> The White Rhinoceros Its sad disappearance has come at a time when everyone is alert to the risks of ecological extinction and its consequences for humanity and at a time when all the understanding and technology at our disposal could be channelled towards the protection of this species.
<G-vec00332-002-s114><alert.alarmieren><de> Mehr über Intercom Anywhere Seien Sie alarmiert, wenn Personen kommen und gehen, ein Wasserleck erkannt wird oder wenn das Garagentor offen gelassen wurde.
<G-vec00332-002-s114><alert.alarmieren><en> Create your own personalized push notifications to alert you when people come and go, a water leak is detected, even if the garage door has been left ajar.
<G-vec00332-002-s115><alert.alarmieren><de> Im Notfall drücken Sie einfach auf den Alarmknopf und Ihre Helfer werden alarmiert.
<G-vec00332-002-s115><alert.alarmieren><en> If an emergency arises, just press the alarm button to alert your helpers.
<G-vec00332-002-s116><alert.alarmieren><de> 3.3 x 3.3, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s116><alert.alarmieren><en> 4.1 x 3.9, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s117><alert.alarmieren><de> Bronze, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s117><alert.alarmieren><en> Analog, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s118><alert.alarmieren><de> Armbanduhren, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s118><alert.alarmieren><en> Black, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s119><alert.alarmieren><de> Black, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s119><alert.alarmieren><en> Multi-Colored, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s120><alert.alarmieren><de> Silber, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s120><alert.alarmieren><en> Pink, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s121><alert.alarmieren><de> Video FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s121><alert.alarmieren><en> FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s122><alert.alarmieren><de> Uptrends prüft, ob deine Zertifikate richtig funktionieren, und alarmiert dich, wenn sie gehackt wurden oder abgelaufen sind.
<G-vec00332-002-s122><alert.alarmieren><en> Uptrends verifies that your certificates are running properly, and will alert you in the event yours has been hacked or has expired.
<G-vec00332-002-s124><alert.alarmieren><de> Unsere leistungsfähige Spion-Software alarmiert dich, falls dein Kind etwas misstrauisch geworden ist.
<G-vec00332-002-s124><alert.alarmieren><en> Our powerful spy software will alert you when your child is into something suspicious
<G-vec00332-002-s125><alert.alarmieren><de> 30m, FAQs Alarm: Alarmiert den Träger zu einer bestimmten, vorher eingestellten Zeit.
<G-vec00332-002-s125><alert.alarmieren><en> 4, FAQs Alarm: This feature is designed to alert the watch wearer to a specific, pre-designated time.
<G-vec00332-002-s127><alert.alarmieren><de> Das IIPSC erforscht, debattiert und alarmiert die Bedeutung der frühen Warnzeichen und Signale, agiert als internationaler “Wachhund”, erzieht/belehrt und fördert Lösungen zu Fragen von Bedeutung wie der Cyber-Sicherheit, globalen Bedrohungen und wissenschaftlicher Ausbildung an Alle Ebenen.
<G-vec00332-002-s127><alert.alarmieren><en> International Information Policy and Security Council (IIPSC) researches, debates and alert the importance of early warning signs and signals that act as an international ” Watchdog ” to educate and promote solutions to issues of importance such as cyber security, global threats and scholarly education at all levels.
<G-vec00332-002-s129><alert.alarmieren><de> Nach 10-minütiger Inaktivität, bei der keine Tasten gedrückt werden, alarmiert Sie das Gerät und schaltet sich anschließend ab.
<G-vec00332-002-s129><alert.alarmieren><en> After 10 minutes of inactivity, or no button pushes, the device will alert you and then shut off.
<G-vec00332-002-s130><alert.alarmieren><de> Der Sensor wird durch Magensaft aktiviert und die physiologischen Parameter des Patienten an eine zugehörige Smartphone-App weitergeleitet, die den Betroffenen alarmiert, wenn das Medikament falsch eingenommen wurde.
<G-vec00332-002-s130><alert.alarmieren><en> The sensor is activated (and powered) by stomach fluid, and the patient’s physiological data is output to an accompanying smartphone app, that will alert them if a medicine isn’t taken as scheduled.
<G-vec00332-002-s131><alert.alarmieren><de> Unser tausendfach bewährter Analysealgorithmus erkennt die Größe, die Geschwindigkeit und die Bewegungsrichtung eines Objekts und alarmiert in Echtzeit Ihre Überwachungszentrale.
<G-vec00332-002-s131><alert.alarmieren><en> Our proven analysis algorithms detect the size, speed and direction of movement of an object and alert the monitoring control center in real time.
<G-vec00761-002-s184><alarm.alarmieren><de> Amok-Sicherheit Amok-Sicherheit Während einer Amok-Bedrohung ist es wichtig, dass innerhalb eines Gebäudes oder Campus so schnell als möglich alarmiert wird.
<G-vec00761-002-s184><alarm.alarmieren><en> Whilst there is the threat of a violent attack, it is important that the alarm is sounded as quickly as possible within a building or campus.
<G-vec00761-002-s185><alarm.alarmieren><de> Bei einem Inspektionsgerät wird die Maschine automatisch alarmiert und angehalten, wenn der Draht nicht ordnungsgemäß abfällt.
<G-vec00761-002-s185><alarm.alarmieren><en> With an inspecting device, will alarm and stop the machine automatically if the wire dropping improperly.
<G-vec00761-002-s186><alarm.alarmieren><de> In der Anwendung bedeutet das, es wird sofort alarmiert, wenn eine Kamera verdreht wird, zum Beispiel so dass Mitarbeiter an Ihrem Arbeitsplatz „observiert“ werden könnten.
<G-vec00761-002-s186><alarm.alarmieren><en> In practical application, this means that an alarm is issued immediately when a camera is rotated, for example so that employees could be "observed" at their workstation.
<G-vec00761-002-s187><alarm.alarmieren><de> Dieser Kontrast alarmiert den Fisch in keiner Größe.
<G-vec00761-002-s187><alarm.alarmieren><en> This contrast does not alarm the fish of any size.
<G-vec00761-002-s188><alarm.alarmieren><de> So behält die Kamera stets das Wesentliche im Blick und alarmiert nur bei sicherheitsrelevanten Ereignissen.
<G-vec00761-002-s188><alarm.alarmieren><en> This means that the camera always keeps an eye on the essentials and only triggers an alarm for security-relevant events.
<G-vec00761-002-s189><alarm.alarmieren><de> Das Alarmsystem ist eine einfache, preisgünstige und besonders effektive Art und Weise, alarmiert zu werden.
<G-vec00761-002-s189><alarm.alarmieren><en> The alarm system is a simple, cheap and particularly effective way of raising an alarm/message.
<G-vec00761-002-s190><alarm.alarmieren><de> Merkmal Das Gerät alarmiert beim Erkennen bestimmter Objekte mit einem Ton- und Lichtsignal.
<G-vec00761-002-s190><alarm.alarmieren><en> The machine would alarm with sound and light signal when detecting specific objects; baggage screening machine
<G-vec00761-002-s191><alarm.alarmieren><de> Der Monitor kann bis zu 34 Räder überwachen und alarmiert bei Abfallen des Reifendrucks.
<G-vec00761-002-s191><alarm.alarmieren><en> The monitor can monitor up to 34 wheels, and triggers an alarm if tyre air pressure drops.
<G-vec00761-002-s192><alarm.alarmieren><de> Die Lampe zeigt über eine farbige Status LED den aktuellen Leuchtmodus an und alarmiert mit roten Licht bei einem niedrigen Akkustand.
<G-vec00761-002-s192><alarm.alarmieren><en> The lamp displays a color status LED indicates the current lighting mode and alarm with red light at a low battery level.
<G-vec00761-002-s193><alarm.alarmieren><de> Als der türkische Präsident Recep Tayyip Erdoğan Ende September Kritik am Vertrag von Lausanne äußerte, in dem die Grenzen der modernen Türkei festgelegt worden sind, waren die Nachbarn alarmiert.
<G-vec00761-002-s193><alarm.alarmieren><en> When in late September Turkish President Recep Tayyip Erdogan criticised the Treaty of Lausanne, which established the borders of modern Turkey, the neighbouring states reacted with alarm.
<G-vec00761-002-s194><alarm.alarmieren><de> Die Kamera ist außerdem mit einer Schock-Erkennung ausgestattet, die das Personal im Falle eines Vandalismusversuchs alarmiert.
<G-vec00761-002-s194><alarm.alarmieren><en> The camera is further protected with shock detection, a capability that sends an alarm to personnel during attempted vandalism.
<G-vec00761-002-s195><alarm.alarmieren><de> Die Stelle hatte sich seit ein paar Wochen schmerzhaft angefühlt, und die Frau sagte alarmiert, dass ich sobald wie möglich eine Tiefenreinigung benötigte und danach häufiger zur normalen Reinigung kommen müsse.
<G-vec00761-002-s195><alarm.alarmieren><en> I had felt discomfort in that area in recent weeks, and with some alarm she said that I should come back for a more invasive cleaning as soon as possible, along with coming in more frequently for regular cleanings.
<G-vec00761-002-s196><alarm.alarmieren><de> “Er hat dich nicht etwa doch getroffen, oder?“, fragte Don alarmiert und seine Hände suchten nach Verletzungen.
<G-vec00761-002-s196><alarm.alarmieren><en> “He didn’t hit you, right?“ Don asked in alarm and his hands were looking for injuries.
<G-vec00761-002-s197><alarm.alarmieren><de> Auch die Europäische Union ist alarmiert.
<G-vec00761-002-s197><alarm.alarmieren><en> The European Union is among those viewing these developments with alarm.
<G-vec00761-002-s198><alarm.alarmieren><de> Die Empfänger werden alarmiert, sobald das Dokument auf den Adarvo-Server hochgeladen wurde.
<G-vec00761-002-s198><alarm.alarmieren><en> The recipient is sent an alarm message to notify them as soon as the document has been uploaded to the Adarvo server.
<G-vec00761-002-s199><alarm.alarmieren><de> Der Rauchmelder alarmiert Sie im Brandfall mit einem akustischen Signal und löst automatisch einen Anruf aus.
<G-vec00761-002-s199><alarm.alarmieren><en> The smoke alarm alerts you with an audible signal in the event of a fire and automatically triggers an emergency call.
<G-vec00761-002-s200><alarm.alarmieren><de> Der hohe Energieverbrauch und die damit verbundene Luftverschmutzung haben die chinesische Regierung alarmiert.
<G-vec00761-002-s200><alarm.alarmieren><en> Such high energy consumption and the resulting air pollution have set alarm bells ringing in government quarters.
<G-vec00761-002-s201><alarm.alarmieren><de> Sofort erscheint auf seinem Bildschirm ein Hinweis mit Senderkennung und ID, begleitet von einem Hochfrequenzton — die Crew ist sofort alarmiert (siehe kleines Bild rechts).
<G-vec00761-002-s201><alarm.alarmieren><en> A window appears on its screen showing the Beacon number and ID parallel to an audible high frequency alarm – now, the crew is immediately informed about the case of emergency.
<G-vec00761-002-s202><alarm.alarmieren><de> Ab 35 ppm alarmiert Sie das Gerät zudem mit einem Ton, dessen Intervall sich bei steigender Konzentration verkürzt und der ab 200 ppm als permanenter Warnton ausgegeben wird.
<G-vec00761-002-s202><alarm.alarmieren><en> Beginning at 35 ppm the instrument gives off an alarm sound, the interval between them becomes shorter as the concentration increases and the tone is emitted as a permanent warning sound above 200 ppm.
