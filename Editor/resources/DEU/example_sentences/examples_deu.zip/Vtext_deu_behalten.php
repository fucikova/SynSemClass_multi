<G-vec00197-001-s057><bear.behalten><de> Sie sollten auch Im Kopf behalten, dass wegen eines derartigen Terrors und unter der Schirmherrschaft der Vereinten Nationen 330.000Personen aus Kosovo und Methohija vertrieben wurden.
<G-vec00197-001-s057><bear.behalten><en> You should also bear in mind that because of such terror and under the Untied Nations auspices 330,000persons were driven from Kosovo and Metohia.
<G-vec00197-001-s058><bear.behalten><de> Es ist sehr wichtig, im Auge zu behalten, die Warzen überall am Körper auftauchen könnten.
<G-vec00197-001-s058><bear.behalten><en> It is very important to bear in mind that warts could appear anywhere on the body.
<G-vec00197-001-s059><bear.behalten><de> Wenn Ihr Pastor Ihnen sagt, dass das Blut Jesu Christi da ist, damit Sie Sünde begehen und es benutzten, um sich damit wie Badewasser zu baden, behalten Sie im Geist, dass das so nicht funktioniert.
<G-vec00197-001-s059><bear.behalten><en> If your pastor tells you that the blood of Jesus Christ is there for you to commit sin and use it to bathe as bathing water, bear in mind that it does not work like that.
<G-vec00197-001-s060><bear.behalten><de> Es geht ihm gut, aber die Spuren der Katastrophe wird er für immer behalten: als Narben an den Beinen, und auch in seinen Erinnerungen.
<G-vec00197-001-s060><bear.behalten><en> (Although he will always bear the scars caused by the catastrophe on his legs and in his memories).
<G-vec00197-001-s061><bear.behalten><de> Wir versuchen die Gaben mit einem glücklichen Geisteszustand darzubringen, und wir stellen uns vor, wie unsere geehrten Gäste es sich bequem machen und sich glücklich fühlen, und wir behalten die Leerheit von all den Dingen im Sinn, die mit dem Darbringen verbunden sind.
<G-vec00197-001-s061><bear.behalten><en> We offer them with a happy state of mind, imagining that our honored guests are made comfortable and happy by them, and we bear in mind the voidness of everything involved in this.
<G-vec00197-001-s062><bear.behalten><de> Und auch den weiteren Text in diesem Vers: „und wie ein Rauschen vieler Wasser und wie ein Rollen starker Donner” sollten wir im Auge behalten, denn wir finden ihn in genau derselben Formulierung noch einmal – und nur noch einmal - in der Offenbarung, und er wird uns auch helfen, die Braut zu identifizieren.
<G-vec00197-001-s062><bear.behalten><en> "And we should also bear in mind the further text in this verse: ""and like the sound of many waters and like the sound of mighty peals of thunder"", for we find it in just the same formulation once again – and only once again – in the Revelation, and it will also help us to identify the bride."
<G-vec00197-001-s063><bear.behalten><de> Genau das sollten Unternehmen bei der Planung von Blogger Engagement im Hinterkopf behalten.
<G-vec00197-001-s063><bear.behalten><en> Companies need to bear this in mind when planning blogger engagement.
<G-vec00197-001-s064><bear.behalten><de> Es ist sehr wichtig, im Auge zu behalten, dass Warzen auf eine beliebige Stelle auf dem Körper zeigen.
<G-vec00197-001-s064><bear.behalten><en> It is essential to bear in mind that warts could appear anywhere on the body.
<G-vec00197-001-s065><bear.behalten><de> Lediglich im Auge behalten, sollten Sie dennoch eine effektive Post Cycle Therapie (PCT) zu tun und auch die entsprechenden Ergänzungen Sicherheit auf der Straße zu gewährleisten.
<G-vec00197-001-s065><bear.behalten><en> Merely bear in mind, you still should do a reliable Blog post Cycle Treatment (PCT) as well as take the appropriate supplements to guarantee security along the road.
<G-vec00197-001-s066><bear.behalten><de> Wir sollten im Kopf behalten, dass es die Rolle des Gesetzes ist, uns zu Christus zu bringen und uns zu helfen, durch Ihn an die Gerechtigkeit Gottes zu glauben.
<G-vec00197-001-s066><bear.behalten><en> We should bear in mind that the role of the Law is to bring us to Christ and to help us believe in God’s righteousness through Him.
<G-vec00197-001-s067><bear.behalten><de> Es lohnt sich auch, die Tipps, die wir in den anderen Teilen der Blogserie gegeben haben, in Erinnerung zu behalten.
<G-vec00197-001-s067><bear.behalten><en> You should also bear in mind the tips we have given in the previous parts of this blog series.
<G-vec00197-001-s068><bear.behalten><de> So ermahnt uns der Verfasser des Briefes an die Hebräer, jene in Erinnerung zu behalten, die uns das Evangelium verkündigt haben und bereits von uns gegangen sind.
<G-vec00197-001-s068><bear.behalten><en> Thus, the author of the Epistle to the Hebrews exhorts us to bear in mind those who announced the Gospel to us and who have already departed.
<G-vec00197-001-s069><bear.behalten><de> "Die Hauptsache im Auge zu behalten, viel Anavar der ""Milde"" wird zusätzlich auf der Basis sehr frühen Forschungsstudie, wo die Dosierung zwischen 2 und 15 mgs war."
<G-vec00197-001-s069><bear.behalten><en> One thing to bear in mind, much of Anavar's 'mildness' is likewise based upon very early research study where the dosing was in between 2 as well as 15 mgs.
<G-vec00197-001-s070><bear.behalten><de> Wir müssen im Auge behalten, dass eine wandernde Truppe aus irgend einem halb civilisirten Lande, wenn sie an die Küsten von Amerika angetrieben würde, nach dem geringen Einflüsse der meisten Missionäre zu urtheilen, keine ausgesprochene Wirkung auf die Eingeborenen geäussert haben würde, wenn diese nicht bereits in einem gewissen Grade fortgeschritten gewessen wären.
<G-vec00197-001-s070><bear.behalten><en> We should bear in mind that, judging from the small influence of most missionaries, a wandering crew from some semi-civilised land, if washed to the shores of America, would not have produced any marked effect on the natives, unless they had already become somewhat advanced.
<G-vec00197-001-s071><bear.behalten><de> Man sollte in Erinnerung behalten, dass NGOs zwar viel für die Stärkung der Demokratie tun können - aber doch keine Alleskönner sind.
<G-vec00197-001-s071><bear.behalten><en> One shall bear in mind that NGOs can do a lot to strengthen democracy, but not everything - democratic authorities have to assume their own responsibility.
<G-vec00197-001-s072><bear.behalten><de> Wie bei jeder Art von Drogen oder zu ergänzen, gibt es einige Nebenwirkungen von Anavar im Auge zu behalten.
<G-vec00197-001-s072><bear.behalten><en> Like any type of medicine or supplement, there are some negative effects of Anavar to bear in mind.
<G-vec00197-001-s073><bear.behalten><de> "Die Hauptsache im Auge zu behalten, viel von Anavar der ""Milde"" wird zusätzlich auf Basis der frühen Forschung, wo die Anwendung zwischen 2 und 15 mgs war."
<G-vec00197-001-s073><bear.behalten><en> The main thing to bear in mind, a lot of Anavar's 'mildness' is additionally based upon very early research study where the application was between 2 and 15 mgs.
<G-vec00197-001-s074><bear.behalten><de> Wir sollten indessen in Bezug auf die Folgerung, dass Färbungen, welche uns trübe erscheinen, auch den Weibchen gewisser Species nicht anziehend sind, vorsichtig sein; wir sollten derartige Fälle im Sinne behalten, wie den gemeinen Haussperling, bei welchem das Männchen bedeutend vom Weibchen abweicht, aber keine hellen Farbentöne darbietet.
<G-vec00197-001-s074><bear.behalten><en> We ought, however, to be cautious in concluding that colours which appear to us dull, are not attractive to the females of certain species; we should bear in mind such cases as that of the common house-sparrow, in which the male differs much from the female, but does not exhibit any bright tints.
<G-vec00197-001-s075><bear.behalten><de> Es ist wichtig, diesen Punkt im Auge zu behalten, wenn wir uns mit zwei Kritikpunkten auseinandersetzen, die oft gegen die vier Kategorien der geeigneten Aufmerksamkeit ins Feld geführt werden.
<G-vec00197-001-s075><bear.behalten><en> This point is important to bear in mind when we reflect on the two criticisms often leveled against the four categories of appropriate attention.
<G-vec00057-001-s095><hold.behalten><de> Wir behalten deine Zahlung so lange ein, bis du dein Paket erhalten hast.
<G-vec00057-001-s095><hold.behalten><en> We hold your payment until you have received the items
<G-vec00057-001-s096><hold.behalten><de> Die Kabalen werden keine Mühe scheuen, in ihrem Versuch die Kontrolle zu behalten.
<G-vec00057-001-s096><hold.behalten><en> The Cabal will go to any lengths to try to hold on to control.
<G-vec00057-001-s097><hold.behalten><de> Ob in der Stadt oder im Gelände – Die fēnix 5 Plus-Serie hilft Ihnen dabei, mit integrierten Karten und Navigationsfunktionen die Orientierung zu behalten und auf dem richtigen Weg zu bleiben.
<G-vec00057-001-s097><hold.behalten><en> Whether you're in the city or in the wilderness - The fenix 5 Plus series will help you hold your orientation and stay on track with integrated maps and navigational functions.
<G-vec00057-001-s098><hold.behalten><de> 14 Denn wir sind Christi teilhaftig geworden, wenn anders wir die Zuversicht vom Anfang bis ans Ende fest behalten.
<G-vec00057-001-s098><hold.behalten><en> 14 For we are made partakers of Christ: yet so, if we hold the beginning of his substance firm unto the end.
<G-vec00057-001-s099><hold.behalten><de> Wer während einer schwachen Konjunktur in Immobilien investiert, sollte sich darauf einstellen, diese für einen gewissen Zeitraum zu behalten, bevor die wirtschaftlichen Faktoren sich wieder verbessern.
<G-vec00057-001-s099><hold.behalten><en> An investor in a property purchased during an economic recession should be prepared to hold the property for a period of time before economic conditions begin improving again.
<G-vec00057-001-s100><hold.behalten><de> Entsprechend dieser Theorie muss ein Pädagoge, um effektiv zu sein, die Aufmerksamkeit der Zuhörer erhalten und behalten, muss verständlich sein (begreifen), muss Akzeptanz bei denjenigen hervorrufen, die seiner Botschaft ausgesetzt sind (nachgeben), die Akzeptanz muss eine Zeit lang beibehalten werden (Aufrechterhaltung) und dabei in entsprechenden Situationen in Aktion übertragen werden.
<G-vec00057-001-s100><hold.behalten><en> According to this theory, to be effective an educator must get and hold the listeners' attention, must be understandable (comprehension), must elicit acceptance on the part of the person exposed to the message (yielding), the acceptance must be retained over time (retention), and thereby be translated into action in appropriate situations.
<G-vec00057-001-s101><hold.behalten><de> Mit einer guten Pflege können Sie dafür sorgen, dass Sie Ihre Schuhe noch lange behalten können.
<G-vec00057-001-s101><hold.behalten><en> The right care will ensure that you can hold on to your shoes a lot longer.
<G-vec00057-001-s102><hold.behalten><de> Ranas Werke erzeugen eine Wahrnehmungsdissonanz und sind von einer solchen geschaffen und behalten eine kognitive und affektive Macht über ihr Publikum.
<G-vec00057-001-s102><hold.behalten><en> Rana's works create and are created by perceptual dissonance, and continue to hold cognitive and affective power over their audience.
<G-vec00057-001-s103><hold.behalten><de> Auch dies wird dazu beitragen, Sie verhindern, dass Langeweile und so verhindern, dass Sie von der Suche nach Ausreden, warum Sie shouldn 't Gebrauch behalten.
<G-vec00057-001-s103><hold.behalten><en> Again, this will help prevent you become bored and so prevents you from making excuses why you do not have to hold the exercises.
<G-vec00057-001-s104><hold.behalten><de> Die All Blacks, erneut Favorit der Meisterschaft und Titelverteidiger, sind darauf bedacht, ihren Titel zu behalten, den sie gegen Frankreich gewannen.
<G-vec00057-001-s104><hold.behalten><en> The All Blacks are once again the favorites and as current world champions they intend to hold onto the title they fought so hard to win against France.
<G-vec00057-001-s105><hold.behalten><de> Exeter wird das Projekt Caspiche in Nord-Chile behalten und sich in weiterer Folge auf den Ausbau des Projekts konzentrieren.
<G-vec00057-001-s105><hold.behalten><en> Exeter will continue to hold and focus on advancing its Caspiche Project, located in northern Chile.
<G-vec00057-001-s106><hold.behalten><de> Christen werden ermahnt, alles zu prüfen und das Gute zu behalten.
<G-vec00057-001-s106><hold.behalten><en> Christians are admonished to test all things and hold to what is good.
<G-vec00057-001-s107><hold.behalten><de> "Handelt es sich um eine ""Swisscom TV-Box UHD"", können sie diese behalten, da sie Ihr Eigentum ist."
<G-vec00057-001-s107><hold.behalten><en> "If it is a ""Swisscom TV-Box UHD"", you may hold onto it as it is your property."
<G-vec00057-001-s108><hold.behalten><de> Man muss beide im Sinn behalten.
<G-vec00057-001-s108><hold.behalten><en> One has to hold the two things in mind.
<G-vec00057-001-s109><hold.behalten><de> Wird dieser Gesetzgeber nicht anerkannt, fühlt sich der Mensch frei von jeglicher Verantwortung einem Herrn gegenüber, dann ist er noch offensichtlich in Gott-gegnerischer Gewalt, denn diese wird den Menschen immer so zu beeinflussen suchen, daß das Erdenleben ihm keinen Fortschritt einträgt, daß jeglicher Glaube an Zweck und Ziel des Erdendaseins schwindet, auf daß jene Macht selbst ihn für sich behalten kann wieder ewige Zeiten hindurch....
<G-vec00057-001-s109><hold.behalten><en> If this lawgiver is not acknowledged, then the human being will not feel responsible to a Lord; then he is clearly still subject to a God-opposing power, which always tries to influence a person such that his earthly life will be to no avail, that any belief in a purpose and aim of earthly existence fades away, so that this power can hold on to him again for an infinitely long time....
<G-vec00057-001-s110><hold.behalten><de> Auch wir müssen die Schönheit wiederentdecken, den Auferstandenen zu bezeugen, indem wir aus selbstbezogenen Haltungen herauskommen und darauf verzichten, die Gaben Gottes für uns zu behalten, und nicht der Mittelmäßigkeit nachgeben.
<G-vec00057-001-s110><hold.behalten><en> We too need to rediscover the beauty of witnessing to the Risen One, by leaving behind self-referential attitudes, by ceasing to hold back the gifts of God and by not giving in to mediocrity.
<G-vec00057-001-s111><hold.behalten><de> Die Früchte wie Pfirsiche, Pflaumen und Aprikosen sind eine beliebte Wahl zum Fermentieren, weil sie schmackhaft sind und ihre Farbe gut behalten.
<G-vec00057-001-s111><hold.behalten><en> Fruits like peaches, plums and apricots are a popular choice for fermenting, as they are tasty and hold their color well.
<G-vec00057-001-s112><hold.behalten><de> Der Brechreiz und die Schmerzen wurden weniger und ich konnte wieder etwas Nahrung bei mir behalten.
<G-vec00057-001-s112><hold.behalten><en> The vomiting and pain were reduced, and I was able to hold down some food.
<G-vec00057-001-s113><hold.behalten><de> ZUGRIFF AUF UNSERE WEBSITE Der Zugriff auf unsere Website ist vorübergehend gestattet und wir behalten uns das Recht vor, den auf unserer Website bereitgestellten Service ohne vorherige Mitteilung einzustellen oder zu ändern (siehe unten).
<G-vec00057-001-s113><hold.behalten><en> Access To Our Site 1.1 Accessing our website is allowed on a temporary basis, and we hold the right to withdraw or amend the service we provide without any notice (see below).
<G-vec00211-002-s057><keep.behalten><de> Erstelle dein eigenes Spielerprofil und behalte den Überblick über deine Spiel- und Trainingsdaten.
<G-vec00211-002-s057><keep.behalten><en> Create your own player profile and keep track of your game and training data.
<G-vec00211-002-s058><keep.behalten><de> Behalte den cleanen Bass und Attack und mische ihn mit soviel Schmutz wie du willst.
<G-vec00211-002-s058><keep.behalten><en> Keep all the clear low end and attack of your bass signal and mix in as much dirt as you want...
<G-vec00211-002-s059><keep.behalten><de> Behalte Deine Geschwindigkeit bei oder Du wirst stehenbleiben.
<G-vec00211-002-s059><keep.behalten><en> Keep your speed up or you will stall.
<G-vec00211-002-s060><keep.behalten><de> 71Mein Sohn, behalte meine Rede und verwahre meine Gebote bei dir.
<G-vec00211-002-s060><keep.behalten><en> My son, keep my words, and lay up my precepts with thee.
<G-vec00211-002-s061><keep.behalten><de> Behalte diese Karte für 2 Züge und verliere jeden Zug 2 Gesundheit.
<G-vec00211-002-s061><keep.behalten><en> Keep this card for two turns and lose 2 health each turn.
<G-vec00211-002-s062><keep.behalten><de> Behalte im Hinterkopf, dass du ihr Fragen stellen und Antworten von ihr bekommen musst.
<G-vec00211-002-s062><keep.behalten><en> Keep in mind that you have to ask her questions and get answers from her.
<G-vec00211-002-s063><keep.behalten><de> Behalte das Tier, wenn möglich, bei dir Zuhause während du Menschen darauf aufmerksam machst, dass dir ein Tier zugelaufen ist.
<G-vec00211-002-s063><keep.behalten><en> Source If possible, keep the animal in your home while you try to make people aware of their disapearance.
<G-vec00211-002-s064><keep.behalten><de> Ja, und weil sie tiefsinnig für mich sind, behalte ich sie für mich.
<G-vec00211-002-s064><keep.behalten><en> Yes and because they are meaningful to me I keep them private.
<G-vec00211-002-s065><keep.behalten><de> Tipp: Behalte den Wasserstand Deiner Vase im Auge; alle Stielenden müssen im Wasser stehen.
<G-vec00211-002-s065><keep.behalten><en> Do: Keep an eye on whether your flowers look dry. Keep those stems hydrated!
<G-vec00211-002-s066><keep.behalten><de> Ich behalte Ursula im Auge, bis sie nur noch ein rot–weißer Punkt ist.
<G-vec00211-002-s066><keep.behalten><en> I keep looking at Ursula until she becomes a red and white dot.
<G-vec00211-002-s067><keep.behalten><de> Behalte den Überblick über deine Schlafmittel (egal ob rezeptfrei oder nicht), da solche Medikamente süchtig machen können, wodurch du ohne sie nicht mehr fähig wärst einzuschlafen.
<G-vec00211-002-s067><keep.behalten><en> Keep track of your use of sleep medication (over the counter or not), as such medication can become addictive, leaving you unable to fall asleep without them.
<G-vec00211-002-s068><keep.behalten><de> Zum Beispiel packe ich jeden Monat 20 Dollar in ein Gefäß, in dem ich Malsachen aufbewahre, Münzen und Trinkgeld kommen in ein Glas, ein Notfallgroschen von 10 oder 20 Dollar ist meiner Handtasche versteckt, das Geld für die Miete und Ersparnisse sind in einer Blechbüchse verschlossen, und dann behalte ich noch vielleicht 40 Dollar in meinem Portemonnaie bis zum nächsten Zahltag (der bei mir und meinem Job unregelmäßig ist).
<G-vec00211-002-s068><keep.behalten><en> For example, I put $20 a month in a container I keep my painting supplies in, coins and tip money in a jar, an emergency $10 or $20 hidden in my purse, rent money and savings locked in a tin, then I keep maybe $40 in my wallet until next payday (which is random for me and my job).
<G-vec00211-002-s069><keep.behalten><de> Behalte diese Auffassung in deinem Sinn.
<G-vec00211-002-s069><keep.behalten><en> Keep that idea in your mind.
<G-vec00211-002-s070><keep.behalten><de> Behalte den Überblick über Indikation, Verfallsdatum und Bestand der Medikamente und medizinischen Hilfsmittel in Deiner Bordapotheke.
<G-vec00211-002-s070><keep.behalten><en> Keep track of indication, expiration date and storage location of all medical aids in your ship's first-aid box.
<G-vec00211-002-s071><keep.behalten><de> Aber ich behalte den Pokal, wenn wir gewinnen.
<G-vec00211-002-s071><keep.behalten><en> But I keep the trophy when we win, deal?
<G-vec00211-002-s072><keep.behalten><de> 6 Behalte diese Karte.
<G-vec00211-002-s072><keep.behalten><en> 6 Keep this card.
<G-vec00211-002-s073><keep.behalten><de> Wenn es welche gibt, die du benutzen kannst, behalte sie.
<G-vec00211-002-s073><keep.behalten><en> If there’s ones that you might use, keep them.
<G-vec00211-002-s074><keep.behalten><de> Behalte im Hinterkopf, dass “Eltern-Kind-Entfremdung“ keine offizielle medizinische Bezeichnung darstellt, was bedeutet, dass es sich nicht um ein psychisches Problem einer involvierten Person handelt.
<G-vec00211-002-s074><keep.behalten><en> Keep in mind that parental alienation syndrome is not a true "syndrome" in the medical sense, in that it's not a mental condition occurring within one person.
<G-vec00211-002-s075><keep.behalten><de> Behalte es bei dir, diese Schönheit und Herrlichkeit der Weite.
<G-vec00211-002-s075><keep.behalten><en> Keep it to you, this beauty and magnificence of Vastness.
<G-vec00326-002-s114><hold.behalten><de> Unsere Kunden sollen zufrieden sein und ihren Tag im Atelier als eine schöne Erfahrung in Erinnerung behalten.
<G-vec00326-002-s114><hold.behalten><en> At the end of the day we want our customers to be satisfied and hold their experience at our studio as a dear memory.
<G-vec00326-002-s115><hold.behalten><de> "Deine Verbindung mit deinem Erleuchteten Selbst bringt die Wahrheit in deine Wahrnehmung, zusammen behalten wir deine Stärke in der Realität, die innerhalb deiner zellularen Matrix liegt.
<G-vec00326-002-s115><hold.behalten><en> 'Your connection with your Enlightened Self brings the Truth to your awareness, together we hold your strength in Reality that is within your cellular Matrix.
<G-vec00326-002-s116><hold.behalten><de> Wir entschuldigen uns für etwaige Unannehmlichkeiten, die dazu führen, dass diejenigen, die Tickets für Shows haben, die Fans jedoch die bestehenden Tickets behalten möchten, da sie gültig sind für die neu geplanten Termine, die in Kürze bekannt gegeben werden.
<G-vec00326-002-s116><hold.behalten><en> "We apologize for any inconvenience this causes those who have tickets to shows but wish to reassure fans to hold onto these existing tickets, as they will be valid for the rescheduled dates, which will be announced shortly.
<G-vec00326-002-s117><hold.behalten><de> Bestimmte Luxusgüter behalten ihren Wert oder steigen sogar nach ihrem Ankauf im Wert.
<G-vec00326-002-s117><hold.behalten><en> And certain luxury goods can hold their value, or even gain in price after you’ve bought them.
<G-vec00326-002-s119><hold.behalten><de> Gewebte Etiketten behalten ihre Farbe und Form auch bei starker Nutzung und nach unzähligen Waschvorgängen in der Waschmaschine.
<G-vec00326-002-s119><hold.behalten><en> Woven Labels also hold their color and shape through immense wear and tear or countless cycles through the washing machine.
<G-vec00326-002-s120><hold.behalten><de> Glaubt er weiter an die Krankheit, wird er sie auch behalten, doch ringt er sich zum Glauben an die Gesundheit durch, so wird sich der Heilungsprozess vollziehen.
<G-vec00326-002-s120><hold.behalten><en> If they continue to believe in their illness, they will hold on to it. But if they decide to believe in health, the healing process will take place.
<G-vec00326-002-s121><hold.behalten><de> Nach dem Auswählen der Karten die er behalten möchte, muss er den DEAL/DRAW Knopf drücken.
<G-vec00326-002-s121><hold.behalten><en> After selecting the cards the player wants to hold, he needs to press the DEAL/DRAW button.
<G-vec00326-002-s122><hold.behalten><de> Wir versagen uns diese großartige Liebe, weil wir nicht glauben können dass wir würdig genug sind, oder groß genug sind um sie zu behalten.
<G-vec00326-002-s122><hold.behalten><en> We deny ourselves this great love because we can't believe that we are worthy enough or large enough to hold it.
<G-vec00326-002-s123><hold.behalten><de> 6 Wir behalten deine Zahlung so lange ein, bis du dein Paket erhalten hast.
<G-vec00326-002-s123><hold.behalten><en> 6 We hold your payment until you have received the items
<G-vec00326-002-s124><hold.behalten><de> Bei Umsetzung der Zusammenlegung behalten die Anteilsinhaber des übernehmenden Teilfonds dieselben Anteile des übernehmenden Teilfonds wie bisher, und es erfolgt keine Änderung an den mit diesen Anteilen verbundenen Rechten.
<G-vec00326-002-s124><hold.behalten><en> On implementation of the merger, shareholders in the Receiving Sub-Fund will continue to hold the same shares in the Receiving Sub-Fund as before and there will be no change in the rights attaching to such shares.
<G-vec00326-002-s125><hold.behalten><de> Auch in der Vorstartphase, oder an der ersten Luvtonne verzichtete Team Neuseeland einige Male darauf sein Luvrecht exzessiv auszunutzen und den Gegner in den Wind zu stellen und dadurch die entscheidenden Meter Vorsprung herauszufahren, die eventuell gereicht hätten, die Führung während des Rennens zu behalten.
<G-vec00326-002-s125><hold.behalten><en> Also in the pre-start phase, or at the first windward mark, Team NZ abstained several times from excessive use of its right to luff. to put its opponent in the wind and make the most of the critical meters, which could have been sufficient to hold the lead in the race.
<G-vec00326-002-s126><hold.behalten><de> Christus aber als Sohn über sein eigenes Haus; sein Haus sind wir, wenn wir die Freimütigkeit und den Ruhm der Hoffnung bis zum Ende fest behalten.
<G-vec00326-002-s126><hold.behalten><en> But Christ as a son over his own house; whose house are we, if we hold fast the confidence and the rejoicing of the hope firm unto the end.
<G-vec00326-002-s127><hold.behalten><de> Das Einzige, das ich empfehlen kann, ist ihn im Moment zu behalten.
<G-vec00326-002-s127><hold.behalten><en> The only thing I can suggest is to hold on to it for now.
<G-vec00326-002-s128><hold.behalten><de> Au Pair und Familie bemühen sich nicht um offene Gespräche und behalten Bedürfnisse und Wünsche für sich.
<G-vec00326-002-s128><hold.behalten><en> Neither Au Pair nor host family exert themselves on an open conversation and hold their needs and wishes back.
<G-vec00326-002-s129><hold.behalten><de> Und sie können ihr Wasser behalten, was sie zu einer idealen Vase macht.
<G-vec00326-002-s129><hold.behalten><en> And they can hold their water, making it an ideal vase.
<G-vec00326-002-s130><hold.behalten><de> Die Karten die er behalten hat bleiben auf dem Bildschirm während die Maschine neue Karten aus dem virtuellen Deck austeilt an Stelle von denen die der Spieler nicht behalten hat.
<G-vec00326-002-s130><hold.behalten><en> The cards that he chooses to hold, stay on the screen while the game deals new cards from the virtual deck on the place of those which the poker player has chosen throw away.
<G-vec00326-002-s131><hold.behalten><de> Danach klicken Sie auf die Karten, die Sie behalten wollen oder klicken Sie auf den HOLD-Button darunter.
<G-vec00326-002-s131><hold.behalten><en> Click on the cards you wish to hold from this hand, and those cards will be held through all 5 hands.
<G-vec00326-002-s132><hold.behalten><de> Passend zu diesem Glauben behalten Spieler keine hohen Karten (eine, zwei oder drei), wenn diese nicht verbunden sind.
<G-vec00326-002-s132><hold.behalten><en> In line with this school of thought is the following: Do not hold one, two, or three unrelated high cards.
<G-vec00326-002-s095><maintain.behalten><de> Indem du auf das Gelcoat Wachs aufträgst, wird es seinen Glanz für lange Zeit behalten und eine Schutzschicht gegen Schäden durch Wasser haben.
<G-vec00326-002-s095><maintain.behalten><en> Keeping gelcoat coated with wax can help the gelcoat maintain its shine for a long time, offering a protective buffer between the coat and the water.
<G-vec00326-002-s096><maintain.behalten><de> Leggings von Speedo, weicher Powerflex-Eco-Stoff, mit recycelten Polymeren hergestellt, entwickelt, um seine Form zu behalten, mittelhoher Taillenbund, verdeckte Reißverschlusstasche, sitzt wie eine zweite Haut, Handwäsche, 78% Polyamid, 22% Elastan, Model trägt UK-Größe S/EU-Größe S/US-Größe XS und ist 175 cm / 5 Fuß 9 Zoll groß.
<G-vec00326-002-s096><maintain.behalten><en> Sleek one-piece swimsuits and Leggings by Speedo, Soft Powerflex Eco fabric, Made with recycled polymers, Designed to maintain its shape, Mid-rise waist, Hidden zip pocket, Second skin fit, Hand wash, 78% Polyamide, 22% Elastane, Our model wears a UK S/EU S/US XS and is 175cm/5'9"" tall.
<G-vec00326-002-s097><maintain.behalten><de> Damit hilft der Schliessplan, die Kontrolle über die Anlage zu behalten.
<G-vec00326-002-s097><maintain.behalten><en> In this way, the locking plan helps to maintain control over the system.
<G-vec00326-002-s098><maintain.behalten><de> Diese Klammern, wenn sie verlängert werden, scheinen, ein „örtlich festgelegter“ Ausleger zu sein, aber behalten noch die Fähigkeit bei, für Lagerung, Nachsaison oder Caravaning einzustürzen.
<G-vec00326-002-s098><maintain.behalten><en> These clamps, when extended, appear to be a “fixed” outrigger, but still maintain the ability to collapse for storage, off-season or trailering.
<G-vec00326-002-s099><maintain.behalten><de> Zur Zielgruppe gehören sowohl technische Redakteure, die Ihre Projekte besser im Blick behalten möchten, wie auch Abteilungsleiter, die immer über den aktuellsten Stand der Projekte informiert sein möchten.
<G-vec00326-002-s099><maintain.behalten><en> The target group includes both technical editors who wish to be better able to maintain an overview of their tasks and departmental managers who wish to be able to make better estimates for time required for tasks and, therefore, projects.
<G-vec00326-002-s100><maintain.behalten><de> Objekt- und Merkmalserkennung: Durch KUKA.VisionTech können Sie Ihren Roboter auch in unstrukturierten Umgebungen einsetzen und behalten den Überblick über Ihre Ware.
<G-vec00326-002-s100><maintain.behalten><en> Object and feature recognition: With KUKA.VisionTech, you can also use your robot in unstructured environments and maintain an overview of your goods.
<G-vec00326-002-s101><maintain.behalten><de> Bald kämpfte ich darum das Bewusstsein zu behalten, also versuchte ich 911 anzurufen, mit dem Telefon auf dem Tisch neben meinem Bett.
<G-vec00326-002-s101><maintain.behalten><en> I was soon struggling to maintain consciousness so I tried to call 911 with the phone at my bedside table.
<G-vec00326-002-s102><maintain.behalten><de> So behalten Sie Ihre Verkäufe selbst in der Hand.
<G-vec00326-002-s102><maintain.behalten><en> In this way you will maintain control over your sales.
<G-vec00326-002-s103><maintain.behalten><de> Sie behalten auch in turbulenten Marktphasen den Überblick.
<G-vec00326-002-s103><maintain.behalten><en> You'll maintain an overview of your assets, even in turbulent times.
<G-vec00326-002-s104><maintain.behalten><de> Die Forscherin L.Veccia Vaglieri sagte: "Diese Bevölkerung besitzt ihre Freiheit, ihren alten Glauben und ihre Traditionen zu behalten unter einer Bedingung, dass diejenigen, die den Islam ablehnen, eine gerechte Kopfsteuer an die Regierung zahlen, sie wird Jiziah genannt.
<G-vec00326-002-s104><maintain.behalten><en> L. Veccia Vaglieri, in her book entitled “Defending Islam” says: “Conquered people by Islamic governments were given full freedom to maintain and preserve their faith and traditions provided that individuals who elected this option and did not accept Islam as a way of life, would pay a fair head tax to the Islamic government.
<G-vec00326-002-s105><maintain.behalten><de> Ich habe einen Alumni-Club gegründet, um diesen Kontakt zu behalten.
<G-vec00326-002-s105><maintain.behalten><en> I’ve founded an alumni club to maintain this contact.
<G-vec00326-002-s106><maintain.behalten><de> Wir behalten unseren klaren strategischen Fokus bei und nehmen weiter Kurs auf Emissionen & Verbrauch.
<G-vec00326-002-s106><maintain.behalten><en> Our strategic focus remains clear and we continue to maintain our guidance for the full year.
<G-vec00326-002-s107><maintain.behalten><de> Gerade bei Expansionen ist es zum Teil schwer, die bestehenden Finanzstrukturen so im Blick zu behalten, dass an allen Unternehmensbereichen das Optimum hinsichtlich einer nachhaltigen und stabilen Finanzplanung gewährleistet ist.
<G-vec00326-002-s107><maintain.behalten><en> Particularly during expansions, it is often difficult to maintain a clear picture of the existing financial structures, allowing all sections of the company to operate under optimized, sustainable and stable financial planning parameters.
<G-vec00326-002-s108><maintain.behalten><de> Sie behalten immer die Übersicht – und Dank unseres Monitortragarmsystems ist immer genug Platz auf der Arbeitsplatte.
<G-vec00326-002-s108><maintain.behalten><en> You always maintain an overview – and thanks to our monitor support arm system there is always enough space on your work surface.
<G-vec00326-002-s109><maintain.behalten><de> Aber statt eines Längenausgleichs behalten diese Gelenkwellen ihre exakte Länge bei.
<G-vec00326-002-s109><maintain.behalten><en> Although instead of having a length compensation, these axles maintain their full length.
<G-vec00326-002-s110><maintain.behalten><de> Das Spiel wird nicht im Auge behalten, denn am Ende, die Zahlen sind zu waschen.
<G-vec00326-002-s110><maintain.behalten><en> The appliance does not maintain track, because in the end, the numbers work out.
<G-vec00326-002-s111><maintain.behalten><de> Übersetzungsmanagementsysteme helfen, die Kontrolle bei vollautomatisierten Prozessen zu behalten und technische Sicherheit zu gewähren.
<G-vec00326-002-s111><maintain.behalten><en> Translation management systems help to maintain control in fully automated processes and to provide technical security.
<G-vec00326-002-s112><maintain.behalten><de> Die firmenweiten Listen behalten dabei die höchste Priorität und lassen sich übersichtlich auf die wesentlichen Einträge reduzieren.
<G-vec00326-002-s112><maintain.behalten><en> Company-wide lists maintain the highest priority and can be reduced to the most essential entries, helping to keep them to a manageable dimension.
<G-vec00326-002-s113><maintain.behalten><de> Obwohl die Grund Anavar Dosis eher vielseitig ist, ist es wichtig, zahlreiche Punkte im Auge zu behalten.
<G-vec00326-002-s113><maintain.behalten><en> Although the general Anavar dose is fairly versatile, it is important to maintain numerous things in mind.
<G-vec00394-002-s057><remain.behalten><de> Ich glaube, jeder weiß, dass die Menschen nur dann, wenn wir die Bleibeperspektiven in der Region verbessern, die Hoffnung behalten, dass sie irgendwann in ihre Heimat zurückkehren können.
<G-vec00394-002-s057><remain.behalten><en> I think all of us know that people will only remain hopeful that they will be able to return to their homeland some time in the future if we improve the opportunities for them in the region.
<G-vec00394-002-s058><remain.behalten><de> Bereits gekaufte Tickets und Fluggutscheine behalten ihre Gültigkeit.
<G-vec00394-002-s058><remain.behalten><en> Tickets and flight vouchers purchased to date remain valid.
<G-vec00394-002-s059><remain.behalten><de> Falls ein zust?ndiges Gericht eine Bestimmung dieser Bedingungen als ungültig erkennt, vereinbaren die Parteien trotzdem, dass das Gericht bemüht sein sollte, dem in der Bestimmung dokumentierten Parteiwillen Wirkung zu verleihen, wobei die anderen Bestimmungen dieser Bedingungen volle Rechtskraft und Wirkung behalten.
<G-vec00394-002-s059><remain.behalten><en> If any provision of the Terms is found by a court of competent jurisdiction to be invalid, the parties nevertheless agree that the court should endeavor to give effect to the parties' intentions as reflected in the provision, and the other provisions of the Terms remain in full force and effect.
<G-vec00394-002-s060><remain.behalten><de> (1) Wir behalten uns das Eigentum an der Kauf -/Werksache bis zum Eingang aller Zahlungen aus der Geschäftsbeziehung mit dem Besteller vor.
<G-vec00394-002-s060><remain.behalten><en> Until all payments have been received in full, the goods remain our property.
<G-vec00394-002-s061><remain.behalten><de> Diese Bedingungen behalten ihre Gültigkeit, auch wenn Sie die VMware-Websites nicht mehr verwenden.
<G-vec00394-002-s061><remain.behalten><en> These Terms shall remain in full force and effect notwithstanding any termination of your use of the VMware Websites.
<G-vec00394-002-s062><remain.behalten><de> Bereits im Vorverkauf erworbene Tickets für das Konzert behalten ihre Gültigkeit für die Ersatzshow oder müssen bis 14 Tage vor dem neuen Termin bei der entsprechenden Vorverkaufsstelle zurückgegeben werden.
<G-vec00394-002-s062><remain.behalten><en> Previously purchased tickets remain valid for the new date or may be returned at the point of purchase until 14 days before the new date.
<G-vec00394-002-s063><remain.behalten><de> Unauffällig und clever: Behalten Sie mit dem multifunktionalen Staubsaugerroboter auch in Ihrer Abwesenheit den vollen Überblick über all das, was zu Hause geschieht.
<G-vec00394-002-s063><remain.behalten><en> Unobtrusive and clever: Even when you're not there, remain fully abreast of everything that is going on at home with the multifunctional robot vacuum cleaner.
<G-vec00394-002-s064><remain.behalten><de> Wir behalten uns das Eigentum an der Kaufsache bis zum Eingang aller Zahlungen aus der Geschäftsverbindung mit dem Besteller vor.
<G-vec00394-002-s064><remain.behalten><en> a) All delivered items remain our property until complete payment of all claims arising from the business relationship with the customer; this also includes conditional claims.
<G-vec00394-002-s065><remain.behalten><de> Unsere bisherigen E-Mail-Adressen (nachname@auerhammer-metallwerk.de) behalten für den Übergangszeitraum noch ihre Gültigkeit, sodass alle E-Mails, die noch an diese Adressen gesendet werden, weiterhin bei uns ankommen.
<G-vec00394-002-s065><remain.behalten><en> Our former e-mail addresses (surname@auerhammer-metallwerk.de) remain valid for the transitional period, so that all e-mails sent to these addresses will continue to arrive.
<G-vec00394-002-s066><remain.behalten><de> Sollte eine Bestimmung dieser Nutzungsbedingungen von einem zuständigen Gericht als nichtig befunden werden, vereinbaren die Parteien trotzdem, dass das Gericht bestrebt sein sollte, den Absichten der Parteien, wie in der Bestimmung festgelegt, Rechtskraft zu verleihen, wobei die anderen Bestimmungen der Nutzungsbedingungen volle Rechtskraft und Wirkung behalten.
<G-vec00394-002-s066><remain.behalten><en> If any provision of the Terms of Service is found by a court of competent jurisdiction to be invalid, the parties nevertheless agree that the court should endeavour to give effect to the parties' intentions as reflected in the provision, and the other provisions of the Terms of Service remain in full force and effect. Entire agreement.
<G-vec00394-002-s067><remain.behalten><de> Das Konzept selbst ist in Vergessenheit geraten, da es nicht gelungen war, es hoch auf der Tagesordnung der Politiker zu behalten.
<G-vec00394-002-s067><remain.behalten><en> The concept itself has fallen into abeyance as it has failed to remain high on the agenda of policymakers.
<G-vec00394-002-s068><remain.behalten><de> Behalten Sie das ursprüngliche Videoformat, aber verändern Sie Größen wie die Auflösung, Bildrate und Seitenverhältnis, um die Größe zu verringern.
<G-vec00394-002-s068><remain.behalten><en> Remain original video format but reset video parameters including Video Size (Resolution), Frame Rate and Aspect Ratio to shrink video size.
<G-vec00394-002-s069><remain.behalten><de> Aber die meisten von ihnen bevorzugen es, die Interaktionen rein virtuell zu halten, sei es zu ihrer Sicherheit und Privatsphäre oder einfach weil die Männer das größere Interesse behalten, wenn die Phantasie nicht real wird.
<G-vec00394-002-s069><remain.behalten><en> But most of them prefer to keep the interactions virtual, be it for their security and privacy, or just because the men tend to remain more interested while the fantasy is not realized.
<G-vec00394-002-s070><remain.behalten><de> (1)Wir behalten uns das Eigentum an der Kaufsache bis zum Eingang aller Zahlungen aus der Geschäftsverbindung mit dem Kunden vor.
<G-vec00394-002-s070><remain.behalten><en> All goods delivered to the customer remain our property until all claims arising from the business relationship with the customer are paid in full.
<G-vec00394-002-s071><remain.behalten><de> Wir behalten uns Änderungen auf der Homepage ohne vorherige Ankündigung vor.
<G-vec00394-002-s071><remain.behalten><en> We remain the right to change any parts of the website without prior announcement.
<G-vec00394-002-s072><remain.behalten><de> Tickets behalten ihre Gültigkeit.
<G-vec00394-002-s072><remain.behalten><en> Tickets remain valid.
<G-vec00394-002-s073><remain.behalten><de> Allfällige Restbestellungen behalten ihre Gültigkeit.
<G-vec00394-002-s073><remain.behalten><en> Any remaining orders remain valid.
<G-vec00394-002-s074><remain.behalten><de> Wir verstehen, dass Sie die Kontrolle über Ihre persönlichen Informationen behalten möchten und dass wir Ihr Vertrauen verdienen und behalten müssen.
<G-vec00394-002-s074><remain.behalten><en> We understand you want to remain in control of your personal information and that We must earn and retain your trust.
<G-vec00394-002-s075><remain.behalten><de> Auch wenn sich Ihre Strategie für Führungskräfte mit der Zeit ändern kann, werden einige Grundkomponenten vermutlich ihre Gültigkeit behalten.
<G-vec00394-002-s075><remain.behalten><en> Your leadership plan may change over time, but some core tenets may remain.
