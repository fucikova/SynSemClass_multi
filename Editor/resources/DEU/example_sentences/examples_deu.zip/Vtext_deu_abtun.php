<G-vec00555-002-s147><dismiss.abtun><de> Szenen aus der Zukunft der Welt Ich weiß Dinge, bevor sie passieren, aber für gewöhnlich tue ich es als logische Folge früherer Ereignisse ab.
<G-vec00555-002-s147><dismiss.abtun><en> Scenes from the world's future I know things before they happen but I usually dismiss it as a logical outcome of previous events.
