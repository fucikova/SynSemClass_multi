<G-vec00555-002-s051><dismiss.abweisen><de> 45 Die Kommission beantragt, – die Klage abzuweisen; – der Klägerin die Kosten aufzuerlegen.
<G-vec00555-002-s051><dismiss.abweisen><en> 37 The Commission contends that the Court should: – dismiss the action; – order the applicants to pay the costs.
<G-vec00555-002-s052><dismiss.abweisen><de> Mit der vom Berufungsgericht zugelassenen Revision verfolgt der Beklagte seinen Antrag, die Klage abzuweisen, weiter.
<G-vec00555-002-s052><dismiss.abweisen><en> With the appeal approved by the Court of Appeal, the defendant continues to pursue its claim to dismiss the action.
<G-vec00555-002-s053><dismiss.abweisen><de> Bei unsinnigen Eingaben, beispielsweise die Eingabe eines Textes in ein Datumsfeld, ist es angemessen, diese Eingabe abzuweisen.
<G-vec00555-002-s053><dismiss.abweisen><en> Nonsensical input, for example, the input of text in a date field, it is appropriate to dismiss this entry.
<G-vec00555-002-s054><dismiss.abweisen><de> Diese Charakteristik wird nicht an ausgebildete Einheiten vergeben, weshalb es unklug sein mag, Freiwillige abzuweisen oder unsinnigerweise in den sicheren Tod zu schicken.
<G-vec00555-002-s054><dismiss.abweisen><en> This trait is never given to recruited units, so it may be unwise to dismiss such units or to send them to a foolish death.
