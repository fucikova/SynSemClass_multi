<G-vec00135-001-s019><cheer.anfeuern><de> Erste Erfahrungen sammeln die Kleinen bei der Optimisten-Regatta, anfeuern kann man auch noch die Modellsegelboote .
<G-vec00135-001-s019><cheer.anfeuern><en> First experiences collecting the little ones in the Optimist Regatta, You can also cheer the model sailboat.
<G-vec00135-001-s020><cheer.anfeuern><de> Anfeuern: Ähnlich wie ein Pet, dass seinen Meister anfeuert, kann Ranos HP regenerieren, indem Shinee und Munstar ihn anfeuern.
<G-vec00135-001-s020><cheer.anfeuern><en> Encouragement: Similar to a Pet encouraging their master, Lanos can regain health by having Shinee and Moonstar cheer him on.
<G-vec00135-001-s021><cheer.anfeuern><de> Nur wenige Minuten entfernt, an den Sandstränden von Presque Isle State Park, einem beliebten Gannon Student Hangout oder anfeuern Erie professionell verbundenen Hockey, Baseball und Basketball-Teams entspannen.
<G-vec00135-001-s021><cheer.anfeuern><en> Just minutes away, relax on the sandy beaches of Presque Isle State Park, a popular Gannon student hangout, or cheer on Erie's professionally affiliated hockey, baseball, and basketball teams.
<G-vec00135-001-s022><cheer.anfeuern><de> Kommen und erleben Sie die Atmosphäre in der Stadt, wenn 200.000 Zuschauer die Läufer anfeuern und rund 50 verschiedene Musikgruppen und Bands die Strecke säumen.
<G-vec00135-001-s022><cheer.anfeuern><en> Come and experience the atmosphere in Gothenburg city centre, where 200,000 spectators cheer on the runners and around 50 different musical entertainers line the route.
<G-vec00135-001-s023><cheer.anfeuern><de> Neben den Wettkämpfen im Olympiastadion könnt ihr auch die Teilnehmer der Geher-Wettbewerbe und die Marathonläufe in der City West anfeuern.
<G-vec00135-001-s023><cheer.anfeuern><en> In addition to the competitions in the Olympic Stadium, you can also cheer for the participants in the walking competitions and the marathons in the City West.
<G-vec00135-001-s024><cheer.anfeuern><de> Die Mitglieder und Fans, die ihr Team anfeuern möchten, können das Stadion anhand jeglichem Zug erreichen der in der Coslada Station Halt macht, insbesondere die C-2 oder C-7 Linien .
<G-vec00135-001-s024><cheer.anfeuern><en> Club members and fans can visit the stadium to cheer their team on by taking any train which stops at the Coslada station, specifically the C-2 or C-7 lines.
<G-vec00135-001-s025><cheer.anfeuern><de> Abfahren, anfeuern, alles geben – entdecken Sie die ikonische Team Collection by Bogner, die nicht nur den Profis vorbehalten ist.
<G-vec00135-001-s025><cheer.anfeuern><en> Drive off, cheer, give everything - discover the iconic Team Collection by Bogner, which is not only reserved for professionals.
<G-vec00135-001-s026><cheer.anfeuern><de> Pünktlich zur Fußball-Weltmeisterschaft 2010, werden auch über 2.000 Menschen in entlegenen Dörfern Südafrikas ihre Mannschaft anfeuern können, die bisher ohne jeden Zugang zu Strom und Medien waren.
<G-vec00135-001-s026><cheer.anfeuern><en> Just in time for the Football World Cup 2010 more than 2,000 people in remote villages in South Africa who have so far had no access to electricity or the media will be able to watch and cheer on their team.
<G-vec00135-001-s027><cheer.anfeuern><de> Leute versammelten sich um uns und ich sagte ihnen, dass sie die Schlampen anfeuern sollten.
<G-vec00135-001-s027><cheer.anfeuern><en> People started gathering and I ordered them to cheer on the sluts.
<G-vec00135-001-s028><cheer.anfeuern><de> Außerdem kann ich schon in fast 20 Sprachen grüßen und anfeuern.
<G-vec00135-001-s028><cheer.anfeuern><en> Moreover, I can greet and cheer on in nearly 20 languages.
<G-vec00135-001-s029><cheer.anfeuern><de> Obwohl kein Fan von Maggie, Es ist wirklich schwer nicht zu ihr in den beiden anfeuern chattet mit ’ Mann, der Hoffnung, dass jederzeit alles andere ’ legte sie nicht nur Worte.
<G-vec00135-001-s029><cheer.anfeuern><en> Although not a fan of Maggie, It is really hard not to cheer her on in both chats which with ’ man, hoping that at any moment all else ’ put it down not just words.
<G-vec00135-001-s030><cheer.anfeuern><de> Egal ob Sie eine Show im Theater District mit mehr als 12.000 Plätzen besuchen, in einem der 11.000 Restaurants essen, ein lokales Sportteam anfeuern möchten oder etwas dazwischen, Houston bietet für jeden etwas.
<G-vec00135-001-s030><cheer.anfeuern><en> Whether you want to take in a show in the Theater District that boasts more than 12,000 seats, eat at one of the 11,000 restaurants, cheer on a local sports team or anything in between, Houston offers something for everyone.
<G-vec00135-001-s031><cheer.anfeuern><de> Eben das gleiche Ruder hält dich fest an deinem Weg, und, ob die Massen dich anfeuern oder nicht, ist gegenüber deinem Kurs durch das Leben nebensächlich.
<G-vec00135-001-s031><cheer.anfeuern><en> The self-same rudder keeps you firmly on your path, and whether the crowds cheer or not cheer is immaterial to your course through life.
<G-vec00135-001-s032><cheer.anfeuern><de> Geniessen Sie eine herzhafte Mahlzeit während Sie Ihren Favoriten zum Sieg anfeuern.
<G-vec00135-001-s032><cheer.anfeuern><en> Enjoy a hearty medieval banquet as you cheer on your favorite champion to victory.
<G-vec00135-001-s033><cheer.anfeuern><de> """Fans wollen ihre Mannschaften nicht in Stadien anfeuern, die ausländische Arbeiter das Leben gekostet haben."
<G-vec00135-001-s033><cheer.anfeuern><en> """Fans don't want to cheer teams in stadiums that cost migrant workers their lives."
<G-vec00135-001-s034><cheer.anfeuern><de> Sie sehen dann, wo du gerade läufst oder mit dem Rad fährst und können dich mit motivierenden Cheers anfeuern .
<G-vec00135-001-s034><cheer.anfeuern><en> They see where you are currently running or cycling and can cheer you on with motivational messages .
<G-vec00135-001-s035><cheer.anfeuern><de> Die Stadt ist auch ein Tor zum Maribor Pohorje, einem beliebten Freizeit-Skigebiet, wo Sie Skifahrer anfeuern können, die um den Golden Fox, den Weltcup-Wettbewerb für Frauen, kämpfen.
<G-vec00135-001-s035><cheer.anfeuern><en> The city is also a gateway to the Maribor Pohorje, a popular recreational ski resort where you can cheer for skiers competing for the Golden Fox, the World Cup competition for women.
<G-vec00135-001-s036><cheer.anfeuern><de> FEBRUAR Im Februar eröffnet sich Ihnen die Chance für sportliche Höchstleistungen - oder Sie können die Teilnehmer zumindest anfeuern.
<G-vec00135-001-s036><cheer.anfeuern><en> FEBRUARY February offers the opportunity to take part in a challenging sporting event, or at least to cheer on its competitors.
<G-vec00135-001-s037><cheer.anfeuern><de> Während die All Stars auf dem Platz dominieren (90% Siegquote über die letzten 12 Saisons), setzt er in den Zuschauerrängen sein „Gesetz“ durch, indem er sich auf seine ihm eigene Art um die Anhänger kümmert, die sein Team nicht laut genug anfeuern, ganz zu schweigen von den Verrückten, die sich trauen, das gegnerische Team zu unterstützen.
<G-vec00135-001-s037><cheer.anfeuern><en> And while the All Stars have been making their mark on the court (90% success in the past 12 seasons), Spudd has been making his in the bleachers, taking care, in his own special way, of supporters who don't cheer on the team enough, not to mention the crazies who dare to support the opposing team.
<G-vec00135-001-s038><cheer.anfeuern><de> Dich während des Laufs mit der LIVE-Cheering-Funktion der Runtastic App von deinen Freunden anfeuern zu lassen und dann im Ziel in die Arme deiner Familie zu fallen, ist die beste Motivation und der beste Preis.
<G-vec00135-001-s038><cheer.anfeuern><en> Hearing your friends cheer you on during the run through live cheering in the Runtastic app pushes you forward, and falling into the arms of your family after crossing the finish line is the best reward.
<G-vec00135-001-s039><cheer.anfeuern><de> An der Strecke erwarten einen die wichtigsten Sehenswürdigkeiten der Stadt sowie gute Musik und eine spektakuläre Stimmung unter den anfeuernden Zuschauern.
<G-vec00135-001-s039><cheer.anfeuern><en> Visitors will enjoy the view of some of the most important city monuments, good music and fabulous atmosphere from the spectators out to cheer on the runners.
<G-vec00135-001-s041><cheer.anfeuern><de> Besonders in den Sommermonaten, wenn die über 3 000 Teilnehmer des Düsseldorfer Marathons auf ihrem Lauf durch die Altstadt von den begeisterten Zuschauern angefeuert werden oder wenn bei der alljährlich stattfindenden Rollnacht tausende Inlineskater die Stadt in eine riesige Partymeile verwandeln.
<G-vec00135-001-s041><cheer.anfeuern><en> Especially in the summer months, when enthusiastic onlookers cheer on the more than 3,000 participants in the Düsseldorf marathon during their run through the old city, or when thousands of inline skaters transform the city into a huge party during one of their annual Roller Nights.
<G-vec00135-001-s046><cheer.anfeuern><de> "Außerdem erweist es sich als geschickter Schachzug, dass die Electro-Metaller inzwischen wieder das Beatles-Cover ""Eleanor Rigby"" in ihr Programm aufgenommen haben: Die französischen Zuschauer veranstalten einen Krach, als gelte es, den Headliner anzufeuern."
<G-vec00135-001-s046><cheer.anfeuern><en> "Besides it turns out a clever move that the electro-metal men yet included the Beatles cover ""Eleanor Rigby"" into their program: the French audience makes such a noise as if it's necessary to cheer on the headliner."
<G-vec00135-001-s047><cheer.anfeuern><de> Sie stöhnte, um ihn anzufeuern und sagte ihm, dass er sie zwischen die Finger nehmen und sie massieren solle, was er auch sogleich tat.
<G-vec00135-001-s047><cheer.anfeuern><en> She moaned to cheer him on and told him to get it between his fingers and massage it, which he did immediately.
<G-vec00135-001-s048><cheer.anfeuern><de> Die Gäste hatten Gelegenheit, an der Regattastrecke von Eton Dorney die olympischen Wettkämpfe im Rudern zu verfolgen und den monegassischen Ruderer Mathias Raymond anzufeuern.
<G-vec00135-001-s048><cheer.anfeuern><en> The guests were able to watch the Olympic rowing races on the lake at Eton Dorney and could cheer on Monegasque rower Mathias Raymond.
<G-vec00135-001-s049><cheer.anfeuern><de> An den Austragungsort, den Strand von Scheveningen, ein sehr beliebter Touristenort in den Niederlanden, kamen 100.000 Zuschauer, um ihren Lokalhelden anzufeuern.
<G-vec00135-001-s049><cheer.anfeuern><en> Raced around the beach of Scheveningen, a very popular tourist spot in the Netherlands, it was little worry that 100,000 spectators turned up to cheer on the local hero.
<G-vec00135-001-s050><cheer.anfeuern><de> Unter den wachsamen Augen des erfahrenen Carlo Janka (1), der 2016 hier in Kitzbühel Dritter wurde, kommen der Langlauf-Weltmeister Federico Pellegrino (2), die Behinderten-Skifahrer Marie Bochet (3), Träger von 15 internationalen Goldmedaillen, und der Kanadier Alexis Guimond (4), seines Zeichens Bronzemedaillengewinner bei den letzten Weltmeisterschaften, hinzu, um die jungen Rennfahrer anzufeuern.
<G-vec00135-001-s050><cheer.anfeuern><en> Under the watchful eye of the experienced Carlo Janka (1), who finished third here in KitzbÃ1⁄4hel in 2016, cross-country skiing world champion Federico Pellegrino (2), disability skiers Marie Bochet (3), holder of 15 international gold medals, and the Canadian Alexis Guimond (4), a bronze medallist at the last World Championships, join in to cheer on the young racers.
<G-vec00135-001-s051><cheer.anfeuern><de> Minun liebt es, seinen Partner im Kampf anzufeuern.
<G-vec00135-001-s051><cheer.anfeuern><en> Minun loves to cheer on its partner in battle.
<G-vec00135-001-s052><cheer.anfeuern><de> Rund 500 Gäste waren gekommen, um ihre Mannschaft anzufeuern, als das Spiel um 19:30 durch Franck Houdebert (Chief Human Resources Officer) eröffnet wurde.
<G-vec00135-001-s052><cheer.anfeuern><en> Around 500 supporters were there to cheer on the two All-Star teams when at 19:30, Franck Houdebert (Chief Human Resources Officer) announced the start of the game.
<G-vec00135-001-s053><cheer.anfeuern><de> Nachdem Wochenende war kamen einige vorbei um uns zu sehen, anzufeuern oder ein Stück mit uns zu laufen.
<G-vec00135-001-s053><cheer.anfeuern><en> Because it was weekend some people came over to visit us, cheer us and run a bit with us.
<G-vec00135-001-s054><cheer.anfeuern><de> Hierher kommen die Einwohner Rouens um die Dragons anzufeuern, lokale Eishockey Mannschaft, die bereits zahlreiche Europatitel gewann.
<G-vec00135-001-s054><cheer.anfeuern><en> This is where the inhabitants of Rouen come to cheer the Dragons, the local ice hockey team, which has won many European titles.
<G-vec00135-001-s055><cheer.anfeuern><de> Foto: unbekannt Vier Frauen englischer Spieler sind gekommen, um das Team beim Spiel gegen Brasilien anzufeuern: Kathy Peters (Frau von Martin), Judith Hurst (Geoff), Tina Moore (Bobby) und Frances Bonetti (Peter).
<G-vec00135-001-s055><cheer.anfeuern><en> The wives of four England players are present to cheer on the team as they face Brazil. They are Kathy Peters (wife of Martin), Judith Hurst (Geoff), Tina Moore (Bobby) and Frances Bonetti (Peter).
<G-vec00135-001-s056><cheer.anfeuern><de> Ich kann es kaum erwarten, Schüler aus der ganzen Welt kennenzulernen und anzufeuern.
<G-vec00135-001-s056><cheer.anfeuern><en> I can't wait meeting pupils from all around the world and cheer for them.
<G-vec00135-001-s057><cheer.anfeuern><de> Ich werde jedoch zu den Spielen gehen und die Mädchen und Paki anzufeuern.
<G-vec00135-001-s057><cheer.anfeuern><en> I will be going to the games though to cheer the girls and Paki on.
<G-vec00135-001-s058><cheer.anfeuern><de> Garmisch ist meine Heimat, hier leben meine Familie, meine Freunde und ich weiß, sie alle kommen zu den Rennen um mich anzufeuern.
<G-vec00135-001-s058><cheer.anfeuern><en> Garmisch is my home, my family lives here and I know, they all will attend the races and will cheer for me.
<G-vec00135-001-s059><cheer.anfeuern><de> Das ist unter anderen in Bond-Filmen zu sehen, in denen der Geheimagent schöne Frauen mitbringt, um ihn anzufeuern oder auf seinen Würfel zu blasen.
<G-vec00135-001-s059><cheer.anfeuern><en> Especially in the Bond films, when the secret agent brings along beautiful women to cheer him on or blow on his dice.
<G-vec00135-001-s060><cheer.anfeuern><de> Viele Besucher reisen an, um die Fahrer anzufeuern und die Festlichkeiten zu genießen.
<G-vec00135-001-s060><cheer.anfeuern><en> Lots of visitors arrive to cheer on the racers and enjoy the festivities.
<G-vec00135-001-s061><cheer.anfeuern><de> Jeder befragte Läufer zeigte sich jedoch erfreut über die unglaubliche Menge an Einheimischen, die herauskamen und die Strecke säumten, um sie anzufeuern und sie zu ermutigen, ihr Ziel zu erreichen, die Ziellinie zu erreichen.
<G-vec00135-001-s061><cheer.anfeuern><en> However, every runner interviewed expressed delight at the unbelievable crowds of local people who came out and lined the route to cheer them on and give them encouragement to achieve their objective of reaching the finish line.
<G-vec00135-001-s062><cheer.anfeuern><de> Die Laeufer sind herzlich eingeladen, die Skater bei ihrem Wettkampf genau unter die Lupe zu nehmen und anzufeuern.
<G-vec00135-001-s062><cheer.anfeuern><en> The runners are very welcome to get a closer look at the skaters and cheer them on during their race.
<G-vec00135-001-s063><cheer.anfeuern><de> Dieses Mal - für einen hübschen Cheerleaders, die für Ihr Lieblingsteam anzufeuern kam.
<G-vec00135-001-s063><cheer.anfeuern><en> This time - for a pretty cheerleader who came to cheer for their favorite team.
<G-vec00135-001-s064><cheer.anfeuern><de> Wenn sich Menschen aller Herkünfte, Religionen und Schichten im Stadion finden, um ihr Team anzufeuern, dann sind sie für diesen Zeitraum Gleichgesinnte.
<G-vec00135-001-s064><cheer.anfeuern><en> When people of all social, economic and religious backgrounds come together in a stadium to cheer for their beloved team, then they are like-minded people for that time.
<G-vec00135-001-s334><cheer.anfeuern><de> Eine Nation wird gewinnen und daher sollte man seine favorisierte Mannschaft mit aller Kraft unterstüzen und anfeuern.
<G-vec00135-001-s334><cheer.anfeuern><en> A nation will win and therefore you should support your favorite team with all their strength and cheer.
