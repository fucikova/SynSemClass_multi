<G-vec00429-002-s132><replace.auswechseln><de> Auf die Beschwerde hin: “Meine Handy-batterie ist immer gleich leer!“, wird der Laden, wenn kein Batterietester zur Verfügung steht, die Batterie einfach auswechseln, ohne damit das Problem wirklich zu lösen.
<G-vec00429-002-s132><replace.auswechseln><en> On a complaint, “My phone does not hold charge,” stores without testing services may simply replace the battery, only to have the problem recur.
<G-vec00429-002-s133><replace.auswechseln><de> Alle 3 Monate auswechseln.
<G-vec00429-002-s133><replace.auswechseln><en> Replace every 3 months.
<G-vec00429-002-s134><replace.auswechseln><de> Die Produktreihe ist so konzipiert, dass Endverbraucher in Betrieben einstufige Inline-Ejektoren leicht auswechseln können.
<G-vec00429-002-s134><replace.auswechseln><en> The product range is designed so that end-users in factories can easily replace single-stage inline ejectors.
<G-vec00429-002-s135><replace.auswechseln><de> Mit dem Fersensystem adjustable heel retention bietet SIDI ein passendes Ersatzteil zum einfachen Auswechseln des regulierbaren Fersensystems an deinen SIDI Shot oder SIDI Tiger Radschuhen.
<G-vec00429-002-s135><replace.auswechseln><en> The adjustable heel retention system by SIDI allows you to replace the heel retention system if your SIDI Shot or SIDI Tiger cycling shoes.
<G-vec00429-002-s136><replace.auswechseln><de> Bei Verwendung Fenderschilden (mehrere Fender) lassen sich defekte Einzelelemente leicht auswechseln.
<G-vec00429-002-s136><replace.auswechseln><en> When using fender shields (several fenders), faulty elements are easy to replace.
<G-vec00429-002-s137><replace.auswechseln><de> Im Falle eines gebrochenen oder kaputten Bildschirms kann der Hersteller den Bildschirm nach eigenem Ermessen reparieren oder auswechseln, ohne dies dem Teilnehmer in Rechnung zu stellen.
<G-vec00429-002-s137><replace.auswechseln><en> In the event of a cracked or broken screen, Manufacturer may on its sole discretion, repair or replace the screen at no cost to the participant.
<G-vec00429-002-s138><replace.auswechseln><de> Ich brauche ein bis zwei HME Cassetten pro Tag und kann diese leicht auswechseln.
<G-vec00429-002-s138><replace.auswechseln><en> I use 1 to 2 HME cassettes per day and these are easy to replace.
<G-vec00429-002-s139><replace.auswechseln><de> Man muss nicht unbedingt einen neuen Grinder kaufen, sondern kann auch einfach die Verschleissteile seines Cali Dichtungsringe Set auswechseln.
<G-vec00429-002-s139><replace.auswechseln><en> There is no need to buy a new grinder if you can simply replace the worn and torn items of your Cali Crusher Homegrown Pocket 4 piece grinder with this Cali Crusher Homegrown Pocket screen & O-ring set.
<G-vec00429-002-s140><replace.auswechseln><de> Waschen Sie sich nach dem Auswechseln der Lampe die Hände.
<G-vec00429-002-s140><replace.auswechseln><en> Ask your dealer to replace the lamp and to inspect the inside of the projector.
<G-vec00429-002-s141><replace.auswechseln><de> Die Wände freuen sich über einen neuen Anstrich, in der Küche die Dichtungen am Wasserhahn auswechseln.
<G-vec00429-002-s141><replace.auswechseln><en> The walls are pleased with a new coat of paint, replace the seals in the kitchen at the tap.
<G-vec00429-002-s142><replace.auswechseln><de> Wenn beispielsweise smarte Kleidung zum Massenprodukt wird, möchte manch einer vielleicht seine ganze Garderobe auswechseln.
<G-vec00429-002-s142><replace.auswechseln><en> If smart clothing becomes a mass product, for instance, some people might want to replace their entire wardrobe.
<G-vec00429-002-s143><replace.auswechseln><de> Anweisungen zum Auswechseln der Scherköpfe Ihres Rasierers finden Sie in der Bedienungsanleitung.
<G-vec00429-002-s143><replace.auswechseln><en> For instructions on how to replace the shaving heads of your shaver refer to your user manual.
<G-vec00429-002-s144><replace.auswechseln><de> Es gibt Komponenten, die Sie selbst auswechseln können.
<G-vec00429-002-s144><replace.auswechseln><en> There are components you can replace on your own.
<G-vec00429-002-s145><replace.auswechseln><de> Für das Auswechseln der Bremsbeläge ist keinerlei Werkzeug erforderlich.
<G-vec00429-002-s145><replace.auswechseln><en> No tools are required to replace the brake pads.
<G-vec00429-002-s146><replace.auswechseln><de> Die Zündbox auswechseln, wenn die Anzeige nicht dem vorgeschriebenen Wert entspricht.
<G-vec00429-002-s146><replace.auswechseln><en> If the tester does not read as specified, replace the coil with a new one.
<G-vec00429-002-s147><replace.auswechseln><de> Natürlich kann der Betreiber den Filter statt einer Regenerierung auch auswechseln.
<G-vec00429-002-s147><replace.auswechseln><en> Of course, the operator may also opt to replace, rather than regenerate the filter.
<G-vec00429-002-s148><replace.auswechseln><de> Kleinere Kratzer stören nicht weiter, aber Schaufeln mit größeren Rissen oder Dellen muss ich auswechseln.
<G-vec00429-002-s148><replace.auswechseln><en> Minor scratches are not a problem, but I do have to replace any blades showing larger cracks or dents.
