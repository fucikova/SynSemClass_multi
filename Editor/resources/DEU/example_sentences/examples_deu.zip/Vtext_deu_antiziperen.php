<G-vec00003-002-s030><anticipate.antiziperen><de> Antizipiere Anzeichen für potentiell gewalttätiges Verhalten.
<G-vec00003-002-s030><anticipate.antiziperen><en> Anticipate signs of potentially violent behavior.
<G-vec00003-002-s031><anticipate.antiziperen><de> Mache Pläne und vervollständige sie mit so vielen Berechnungen wie möglich, dann antizipiere alles, was schiefgehen kann.
<G-vec00003-002-s031><anticipate.antiziperen><en> Make plans, complete with as many calculations as possible, then anticipate everything that can go wrong.
<G-vec00003-002-s032><anticipate.antiziperen><de> Antizipiere wo ein Mitspieler sein wird.
<G-vec00003-002-s032><anticipate.antiziperen><en> Anticipate where a player is going to be.
