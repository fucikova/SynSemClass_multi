<G-vec00206-001-s152><account.berichten><de> Der biblische Bericht über die Schöpfung und die Geschichte vom Garten Eden über den Sündenfall sind von den Anhängern der Evolutionstheorie vielleicht am meisten kritisiert worden.
<G-vec00206-001-s152><account.berichten><en> The Bible account of creation and the Garden of Eden story of man's fall have come in for the greatest amount of criticism on the part of evolutionists.
<G-vec00206-001-s153><account.berichten><de> Für die Zwecke der internen Qualitätskontrolle fasst der Prüfer die Recherchenabteilung nach dem Abschluss der Recherche in einem Bericht alle Informationen zusammen, die die Auditoren benötigen, um zu verstehen, was (siehe B‑III, 3) wo (siehe B‑III, 2) und wie (siehe B‑IV, 2) recherchiert wurde.
<G-vec00206-001-s153><account.berichten><en> For internal quality purposes, at the end of the search the search division completes an account summarising all the information necessary for auditors to understand what has been searched (seeB‑III, 3), as well as where (seeB‑III, 2) and how (seeB‑IV, 2) the search was carried out.
<G-vec00206-001-s154><account.berichten><de> Ihm gelang im November 1942 die Flucht und nach dem Krieg schrieb er einen Bericht über sein Leben im Lager.
<G-vec00206-001-s154><account.berichten><en> He managed to escape in November 1942, and after the war wrote an account of his life in the camp
<G-vec00206-001-s155><account.berichten><de> Laut dem Bericht in 1 Mac 12: 30-32 war seine Heimatstadt NW von Damaskus.
<G-vec00206-001-s155><account.berichten><en> According to the account in 1 Mac 12: 30-32, its home was NW of Damascus.
<G-vec00206-001-s156><account.berichten><de> Nun betrachten wir den folgenden kondensierten Bericht eines Falles von angeblicher dämonischer Heimsuchung, Obsession, und möglicher ultimativer Besessenheit, der im Buch The Demon Syndrome von Nancy Osborn näher dokumentiert und beschrieben wurde.
<G-vec00206-001-s156><account.berichten><en> The following is a condensed account of a case of demonstrably demonic infestation, obssession and possible ultimate possession which has been thoroughly documented and described in The Demon Syndrome by Nancy Osborn:
<G-vec00206-001-s157><account.berichten><de> "Mike Brown spricht in einem mitreissenden Bericht über die ""Initiative Südsudan"", den Bemühungen IofCs, die Südsudanesen bei ihrer Reise der Heilung für nationale Aussöhnung zu unterstützen."
<G-vec00206-001-s157><account.berichten><en> Mike Brown shares a stirring account of the South Sudan Initiative, IofC's effort to support South Sudanese working on a Journey of Healing for National Reconciliation.
<G-vec00206-001-s158><account.berichten><de> Abbé Desgenettes bat letzteren um einen detaillierten Bericht über Alphonses Bekehrung und veröffentlichte ihn im April 1842 in den Annalen.
<G-vec00206-001-s158><account.berichten><en> The pastor insisted on obtaining a detailed account of Alphonse's conversion which he published in the Annals in April 1842.
<G-vec00206-001-s159><account.berichten><de> Im Bericht werden die wichtigsten Risiken aus dem internationalen Umfeld und die Risikolage des deutschen Finanzsystems dargelegt.
<G-vec00206-001-s159><account.berichten><en> It gives an account of the principal risks arising from the international environment and the risk situation of the German financial system.
<G-vec00206-001-s160><account.berichten><de> Umm Mabad hatte keine Ahnung, sie habe in der Firma des Propheten gewesen (salla Allahu alihi wa salam) und hatte nicht schüchtern, um seine Züge zu beobachten gewesen; es ist durch ihre Beobachtungen und anderen wie ihr, dass wir einen ausführlichen Bericht über seine physikalische Beschreibung zu erhalten.
<G-vec00206-001-s160><account.berichten><en> Umm Mabad had no idea she had been in the company of the Prophet (salla Allahu alihi wa sallam) and had not been shy to observe his features; it is through her observations and another like her that we receive a detailed account of his physical description.
<G-vec00206-001-s161><account.berichten><de> Später an diesem Tag teilte der offizielle Bericht von Smartisan Weibo einem Brief, den sie an eine Publikation schickte, in dem sie darauf hinwies, dass die Mail mit unbegründeten Anschuldigungen gegen sie und ihren CEO gefüllt war.
<G-vec00206-001-s161><account.berichten><en> Later that day, Smartisan Weibo’s official account shared a letter she sent to a publication stating that the mail was filled with unfounded accusations against her and her CEO.
<G-vec00206-001-s162><account.berichten><de> Liu Xiaotian, dessen Eltern wegen des Übens von Falun Gong durch das kommunistische Regime Chinas ermordet worden sind, trug bei der Konferenz ebenfalls einen Bericht über die wirkliche Situation in China vor.
<G-vec00206-001-s162><account.berichten><en> Liu Xiaotian, whose parents were persecuted to death by the Chinese communist regime because of practicing Falun Gong, also gave an account of the real situation.
<G-vec00206-001-s163><account.berichten><de> Einen analogen Bericht habe ich auch von Dr. Günther erhalten, welcher gesehen hat, wie sich eine Maus an dem Schwänze aufhieng.
<G-vec00206-001-s163><account.berichten><en> I have received an analogous account from Dr. Günther, who has seen a mouse thus suspend itself.
<G-vec00206-001-s164><account.berichten><de> Wir haben den Bericht gelesen, wie diese Gemeinde in Philippi entstanden ist, und wir haben die Geschichte dort aufgenommen, wo Paulus und seine Gefährten betend, im Geist vorwärts schritten in ihrem großen Dienst.
<G-vec00206-001-s164><account.berichten><en> We have read from the account of how this church at Philippi came into being, and we picked up the story at the point where Paul and his companions were moving prayerfully, and in the Spirit, forward in their great ministry.
<G-vec00206-001-s165><account.berichten><de> Im Folgenden der Bericht von Herrn Lin über seine Erlebnisse aus den vergangenen mehr als zehn Jahren.
<G-vec00206-001-s165><account.berichten><en> The following is Mr. Lin's account of his experiences over the last ten plus years:
<G-vec00206-001-s166><account.berichten><de> Um zu verstehen, leichter die Bedeutung der Kanon darf nicht vergessen werden, dass die Bezugnahme hier nicht zu Presbytern, wurden geopfert auf dem Altar, sondern auf diejenigen, boten zusammen mit dem Bischof, war dabei, durch ein Ritus nicht im Gegensatz zu dem, was auf - Tag statt, wenn die neu ordiniert Presbytern oder Bischöfe feiern Messe mit der ordaining Bischof, und dieser Ritus in alten Zeiten war der täglichen Auftreten, für einen vollständigen Bericht über die siehe Morinus De SS.
<G-vec00206-001-s166><account.berichten><en> To understand more easily the meaning of the canon it must be remembered that the reference here is not to the presbyters who were sacrificing at the altar but to those who were offering together with the bishop who was sacrificing; by a rite not unlike that which to-day takes place, when the newly ordained presbyters or bishops celebrate mass with the ordaining bishop; and this rite in old times was of daily occurrence, for a full account of which see Morinus De SS.
<G-vec00206-001-s167><account.berichten><de> Der geschichtliche Bericht darüber, daß Salomon einen bestimmten Meteorstein verehrte, hat eine wissenschaftliche Grundlage.
<G-vec00206-001-s167><account.berichten><en> The historical account about Solomon revering a particular Aerolite has a scientific basis.
<G-vec00206-001-s168><account.berichten><de> Laut einem Bericht »haben Agenten der Central Intelligence Agency (CIA) die Netzwerke von Taliban und al-Qaida infiltriert und mit der der Tehrik-e-Taliban Pakistan (TTP) ihre eigene Gruppierung zur Destabilisierung Pakistans geschaffen«.
<G-vec00206-001-s168><account.berichten><en> According to one account, “Central Intelligence Agency (CIA) operatives have infiltrated the Taliban and Al-Qaeda networks, and have created their own Tehrik-e-Taliban Pakistan (TTP) force in order to destabilize Pakistan.”
<G-vec00206-001-s169><account.berichten><de> Die charakteristische Gewohnheit der Christen, sich am ersten Tag nach dem Sabbat zu versammeln, um die Auferstehung Christi zu feiern, ist - nach dem Bericht des heiligen Märtyrers Justin (205) - auch das Faktum, welches die Lebensform bestimmt, die durch die Begegnung mit Christus erneuert ist.
<G-vec00206-001-s169><account.berichten><en> The Christians' customary practice of gathering on the first day after the Sabbath to celebrate the resurrection of Christ – according to the account of Saint Justin Martyr(205) – is also what defines the form of a life renewed by an encounter with Christ.
<G-vec00206-001-s170><account.berichten><de> Dazu gehörte insbesondere der Bericht über seine erste Begegnung mit Paramahansa Yogananda.
<G-vec00206-001-s170><account.berichten><en> Among the most inspiring was his account of his first meeting with Paramahansaji.
<G-vec00060-001-s038><report.berichten><de> Die unten angezeigten neuesten Bella Coola Heli Sports-Pantheon Schnee Berichte wurde am 9 Feb 2019 aktualisiert.
<G-vec00060-001-s038><report.berichten><en> The latest Bella Coola Heli Sports-Pantheon snow report shown below was updated on 24 Feb 2019 .
<G-vec00060-001-s039><report.berichten><de> Die unten angezeigten neuesten Ax 3 Domaines Schnee Berichte wurde am 10 Feb 2019 aktualisiert.
<G-vec00060-001-s039><report.berichten><en> The latest Ax 3 Domaines snow report shown below was updated on 6 Feb 2019 .
<G-vec00060-001-s040><report.berichten><de> Die unten angezeigten neuesten Oberiberg Schnee Berichte wurde am 10 Feb 2019 aktualisiert.
<G-vec00060-001-s040><report.berichten><en> The latest Oberiberg snow report shown below was updated on 6 Feb 2019 .
<G-vec00060-001-s041><report.berichten><de> Die unten angezeigten neuesten Houdaigi Schnee Berichte wurde am 10 Feb 2019 aktualisiert.
<G-vec00060-001-s041><report.berichten><en> The latest Houdaigi snow report shown below was updated on 5 Feb 2019 .
<G-vec00060-001-s042><report.berichten><de> Die unten angezeigten neuesten Naltar Valley Schnee Berichte wurde am 8 Feb 2019 aktualisiert.
<G-vec00060-001-s042><report.berichten><en> The latest Naltar Valley snow report shown below was updated on 6 Feb 2019 .
<G-vec00060-001-s043><report.berichten><de> Die unten angezeigten neuesten Purgatory Schnee Berichte wurde am 10 Feb 2019 aktualisiert.
<G-vec00060-001-s043><report.berichten><en> The latest Purgatory snow report shown below was updated on 5 Feb 2019 .
<G-vec00060-001-s044><report.berichten><de> Die unten angezeigten neuesten Lyndon Outing Club Schnee Berichte wurde am 9 Feb 2019 aktualisiert.
<G-vec00060-001-s044><report.berichten><en> The latest Lyndon Outing Club snow report shown below was updated on 4 Feb 2019 .
<G-vec00060-001-s045><report.berichten><de> Die unten angezeigten neuesten Bald Mountain Schnee Berichte wurde am 24 Feb 2019 aktualisiert.
<G-vec00060-001-s045><report.berichten><en> The latest Bald Mountain snow report shown below was updated on 24 Feb 2019 .
<G-vec00060-001-s046><report.berichten><de> Die unten angezeigten neuesten Sarnano Schnee Berichte wurde am 4 Feb 2019 aktualisiert.
<G-vec00060-001-s046><report.berichten><en> The latest Sarnano snow report shown below was updated on 4 Feb 2019 .
<G-vec00060-001-s047><report.berichten><de> Die unten angezeigten neuesten Troják Schnee Berichte wurde am 4 Feb 2019 aktualisiert.
<G-vec00060-001-s047><report.berichten><en> The latest Troják snow report shown below was updated on 4 Feb 2019 .
<G-vec00060-001-s048><report.berichten><de> Die unten angezeigten neuesten Fideris - Fideriser Heuberge Schnee Berichte wurde am 8 Feb 2019 aktualisiert.
<G-vec00060-001-s048><report.berichten><en> The latest Fideris - Fideriser Heuberge snow report shown below was updated on 4 Feb 2019 .
<G-vec00060-001-s049><report.berichten><de> Die unten angezeigten neuesten Shokawa Kogen Schnee Berichte wurde am 10 Feb 2019 aktualisiert.
<G-vec00060-001-s049><report.berichten><en> The latest Shokawa Kogen snow report shown below was updated on 2 Feb 2019 .
<G-vec00060-001-s050><report.berichten><de> Die unten angezeigten neuesten Reiteralm Schnee Berichte wurde am 8 Feb 2019 aktualisiert.
<G-vec00060-001-s050><report.berichten><en> The latest Reiteralm snow report shown below was updated on 4 Feb 2019 .
<G-vec00060-001-s051><report.berichten><de> Die unten angezeigten neuesten High Point Cross Country Ski Center Schnee Berichte wurde am 31 Jan 2019 aktualisiert.
<G-vec00060-001-s051><report.berichten><en> The latest High Point Cross Country Ski Center snow report shown below was updated on 31 Jan 2019 .
<G-vec00060-001-s052><report.berichten><de> Die unten angezeigten neuesten Alvares Winter Sports Complex Schnee Berichte wurde am 10 Feb 2019 aktualisiert.
<G-vec00060-001-s052><report.berichten><en> The latest Alvares Winter Sports Complex snow report shown below was updated on 23 Feb 2019 .
<G-vec00060-001-s053><report.berichten><de> Die unten angezeigten neuesten Brezovica Schnee Berichte wurde am 7 Feb 2019 aktualisiert.
<G-vec00060-001-s053><report.berichten><en> The latest Brezovica snow report shown below was updated on 2 Feb 2019 .
<G-vec00060-001-s054><report.berichten><de> Die unten angezeigten neuesten Gerlos Schnee Berichte wurde am 8 Feb 2019 aktualisiert.
<G-vec00060-001-s054><report.berichten><en> The latest Gerlos snow report shown below was updated on 6 Feb 2019 .
<G-vec00060-001-s055><report.berichten><de> Die unten angezeigten neuesten Krupka - Komáří Vížka Schnee Berichte wurde am 8 Feb 2019 aktualisiert.
<G-vec00060-001-s055><report.berichten><en> The latest Krupka - Komáří Vížka snow report shown below was updated on 4 Feb 2019 .
<G-vec00060-001-s056><report.berichten><de> Die unten angezeigten neuesten Jánské Lázně - Černá hora Schnee Berichte wurde am 9 Feb 2019 aktualisiert.
<G-vec00060-001-s056><report.berichten><en> The latest Jánské Lázně - Černá hora snow report shown below was updated on 6 Feb 2019 .
<G-vec00060-001-s057><report.berichten><de> Mitglieder der Selbsthilfegruppe berichten über ihre Erfahrungen mit diesem Krankheitsbild.
<G-vec00060-001-s057><report.berichten><en> Members of the support group report on their experiences with this disease.
<G-vec00060-001-s058><report.berichten><de> Die Online-HerSolution Bewertungen zeigen eine Reihe von glücklichen Kunden, die alle eine Erhöhung der Erregung und intensivere Orgasmen berichten.
<G-vec00060-001-s058><report.berichten><en> The online HerSolution reviews show a range of happy customers who all report an increase in arousal and more intense orgasms.
<G-vec00060-001-s059><report.berichten><de> In etwa einem Drittel der Fälle zeigt sich eine ophthalmologische Manifestation, wobei Uvea, Retina, Conjunctiva oder das Tränenwegssystem betroffen sein können.Methode: Wir berichten über eine 48-jährige Patientin, die sich erstmals im August 2001 mit einer einseitigen Periphlebits retinae, Maculaödem sowie einseitiger Epiphora vorstellte.
<G-vec00060-001-s059><report.berichten><en> In about one third of all cases ophthalmic manifestation occurs most often involving uvea, retina, conjunctiva and the lacrimal system.Method: We report about a 48 year-old female patient who was sent to us in August 2001 presenting with unilateral retinal periphlebitis, macula edema, and epiphora.
<G-vec00060-001-s060><report.berichten><de> Auf Verlangen hat der Promotionsausschuss dem Bereichsrat über seine Tätigkeit zu berichten.
<G-vec00060-001-s060><report.berichten><en> Upon request, the Doctorate Committee must report to the School Committee on its activities.
<G-vec00060-001-s061><report.berichten><de> Ich bin froh zu berichten, was Kazsport TV-Sender im Paket OTAy TV erfolgreich übertragen in HD-Format.
<G-vec00060-001-s061><report.berichten><en> I am pleased to report, the Kazsport TV channel in the package Otau TV successfully transferred to the HD format.
<G-vec00060-001-s062><report.berichten><de> Vermisste Kinder sollten im The WaterFire Store auf Steeple Straße während der Veranstaltung gebracht werden und Eltern sollten hier berichten, mit ihnen zu verbinden.
<G-vec00060-001-s062><report.berichten><en> Missing children should be brought to the The WaterFire Store on Steeple Street during the event and parents should report here to reconnect with them.
<G-vec00060-001-s063><report.berichten><de> Presse und Fernsehen waren zahlreich vertreten und werden über diesen Empfang berichten.
<G-vec00060-001-s063><report.berichten><en> A lot of members of the press and television were there who will report on the reception.
<G-vec00060-001-s064><report.berichten><de> Das Verteidigungsministerium und die 9/11-Kommission unterließen es, über alle Übungen, die an diesem Morgen liefen, außer einer zu berichten.
<G-vec00060-001-s064><report.berichten><en> The Department of Defense and the 9/11 Commission failed to report all but one of the exercises that occurred that morning.
<G-vec00060-001-s065><report.berichten><de> Wir berichten über eine immunkompetente, weitgehend asymptomatische Patientin mit beidseitigem Papillenödem bei Perineuritis nervi optici im Rahmen einer Lues cerebrospinalis.
<G-vec00060-001-s065><report.berichten><en> We report on an immunocompetent ophthalmologically asymptomatic patient with bilateral papilledema due to perineuritis optici in lues cerebrospinalis.
<G-vec00060-001-s066><report.berichten><de> Wir sind erfreut zu berichten, dass die ersten drei Löcher weiterhin starke Analyseergebnisse liefern, welche die kontinuierliche Goldmineralisierung erweitern.
<G-vec00060-001-s066><report.berichten><en> We are pleased to report that the first three holes continue to produce very strong assay results that expand the continuous gold mineralization.
<G-vec00060-001-s067><report.berichten><de> Sie berichten, dass der Schraubendreher ermöglicht eine 16-mm-Loch im Mauerwerk oder Holz zu machen.
<G-vec00060-001-s067><report.berichten><en> They report that allows the screwdriver to make a 16 mm hole in masonry or wood.
<G-vec00060-001-s068><report.berichten><de> Er wollte festhalten, auf welch verschiedene Weise BBC, CNN, Aljazeera, Dubai Tv und andere Sender über dieselben Ereignisse berichten und damit den Zuschauern ein unterschiedliches Verständnis der Realität vermitteln.
<G-vec00060-001-s068><report.berichten><en> He wanted to show how differently BBC, CNN, Aljazeera, Dubai TV and other broadcasters report the same event, thereby communicating a divergent understanding of reality to their viewers.
<G-vec00060-001-s069><report.berichten><de> Im sechzehnten Jahrhundert Bischofspalast erwartet Sie enthält Werke von der Kathedrale und Objekte, die dem Kult des Heiligen Gürtel beziehen, einschließlich zu berichten, sind die Ergebnisse der ursprünglichen Kanzel von Donatello und Gemälde von Paolo Uccello, Filippo und Filippino Lippi.
<G-vec00060-001-s069><report.berichten><en> Set in the sixteenth century Bishop's Palace, contains works from the cathedral and objects related to the cult of the Sacred Belt, including to report are the findings of the original pulpit of Donatello and paintings by Paolo Uccello, Filippo and Filippino Lippi.
<G-vec00060-001-s070><report.berichten><de> Viel Besonderes gibt es eigentlich nicht zu berichten – dafür war die Zeit zu kurz.
<G-vec00060-001-s070><report.berichten><en> There's not much special to report here – the time was too short for that.
<G-vec00060-001-s071><report.berichten><de> Die Angelegenheit hat internationale Auswirkungen für die Zeugen, die etwa eine Million US-Anhänger und 6 Millionen weltweit berichten.
<G-vec00060-001-s071><report.berichten><en> The issue has international ramifications for the Witnesses, who report about 1 million U.S. followers and 6 million worldwide.
<G-vec00060-001-s072><report.berichten><de> Wissenschaftler berichten dabei, wie sie aus diesem einfachen experimentellen Aufbau riesige Experimente aufbauen, um den ungelösten Rätseln des Universums auf die Spur zu kommen (Halle 6).
<G-vec00060-001-s072><report.berichten><en> Scientists will report how they build gigantic experiments from this simple experimental arrangement in order to solve the mysteries of the universe (hall 6).
<G-vec00060-001-s073><report.berichten><de> Sie berichten darüber hinaus, dass sie wirklich mehr Energie fühlen.
<G-vec00060-001-s073><report.berichten><en> They additionally report that they feel much more energetic.
<G-vec00060-001-s074><report.berichten><de> „Das Dirndl wurde schließlich an einer Schneiderpuppe angebracht, und geht von dort auch nicht mehr runter“, berichten die beiden Studentinnen.
<G-vec00060-001-s074><report.berichten><en> “Finally, the Dirndl was fixed to a dressmaker’s dummy, and that is where it is going to stay,” report the two students.
<G-vec00060-001-s075><report.berichten><de> IP-Adressen und Cookies Es kann sein, dass wir Informationen über Ihren Computer einschließlich soweit bekannt Ihre IP-Adresse, Betriebssystem und Browser zum Zwecke der Systemadministration und zur Erstellung von Berichten mit zusammengefassten Informationen ermitteln.
<G-vec00060-001-s075><report.berichten><en> 1.2.2 information about your computer, including where available the internet protocol (IP) address used to connect your computer to the Internet, operating system and browser type, for system administration and to report aggregated information to our advertisers.
<G-vec00060-001-s057><tell.berichten><de> Wir werden hier weiterhin jeden Tag herkommen, um den Menschen der Welt über die Verfolgung in China zu berichten.
<G-vec00060-001-s057><tell.berichten><en> We will persist in coming here everyday to tell all the people in the world about the cruel persecution in China.
<G-vec00060-001-s058><tell.berichten><de> Unsere Freunde von Nashet berichten, dass die Jugend des Lagers sich isoliert, kriminalisiert und jeder Möglichkeit, ihre Zukunft zu entscheiden, beraubt sieht: Ihre Hoffnung auf eine gerechte Lösung der Flüchtlingsfrage (das Recht auf Rückkehr) schwindet mehr und mehr.
<G-vec00060-001-s058><tell.berichten><en> Our friends from Nashet tell us that the youth of the camp feel isolated, criminalized, prohibited from deciding about their future, and discouraged: their hope in a fair solution to the refugee question (the right of return) is becoming weaker and weaker.
<G-vec00060-001-s059><tell.berichten><de> Zum Tuning gibt es leider nicht viel zu berichten, da ich diesen Part des Spiels nicht zu sehen bekam.
<G-vec00060-001-s059><tell.berichten><en> I can't tell you much about tuning since I couldn't take a look at this part of the game.
<G-vec00060-001-s060><tell.berichten><de> Die Schriften des Neuen Testaments berichten uns nichts darüber.
<G-vec00060-001-s060><tell.berichten><en> The New Testament writings tell us nothing of the event.
<G-vec00060-001-s061><tell.berichten><de> Heute kann ich Ihnen berichten, daß die Tragödie der Opfer der Aggression – der arabischen Völker im Irak und in Palästina – von uns, Russen und anderen Völkern Rußlands als ihre eigene nationale Tragödie empfunden wird und dieses Empfinden sich wesentlich von der Nichtverhinderung der Aggression unterscheidet, die unsere heutige Exekutive nicht in Wort sondern in den Taten geschehen lässt.
<G-vec00060-001-s061><tell.berichten><en> Today I can tell you, that the tragedy of victims of the aggression – the Arabian peoples of Iraq and Palestine - is perceived by us, Russians, and other peoples of Russia as a personal, national tragedy, and this perception essentially differs from that connivance to aggressors which is not in words, but in practice demonstrated by our present executive authority.
<G-vec00060-001-s062><tell.berichten><de> Black Donuts ' der neue CEO von Black Donuts, nahm sich auf der Messe etwas Zeit, um uns von einer neuen schlüsselfertigen Greenfield-Reifenfabrik zu berichten, an der das Unternehmen beteiligt ist.
<G-vec00060-001-s062><tell.berichten><en> Black Donuts ' newly appointed CEO, Derek Carruthers, takes time out of his busy schedule at the show to tell us about a new turnkey and greenfield tire manufacturing plant the company is involved with.
<G-vec00060-001-s063><tell.berichten><de> Und mit einem Schmunzeln im Gesicht berichten Vater und Sohn vom Besuch in der Heimatstadt Sontra im Jahr 2004.
<G-vec00060-001-s063><tell.berichten><en> And with a smile on their faces, father and son tell of their visit to Zeev's hometown Sontra, in 2004.
<G-vec00060-001-s064><tell.berichten><de> Mit zeitweise atemberaubender Offenheit berichten sie über ihre Regelbrüche, mit denen sie neue Märkte entdeckt, ganze Branchen an den Rand des Abgrunds gebracht, Millionen verdient und mit eigenen Händen unsere Welt verändert haben...
<G-vec00060-001-s064><tell.berichten><en> With occasionally breathtaking frankness they tell about their rule-breaking with which they discovered new markets, brought entire industries to the brink, earned millions and with their own two hands changed our world...
<G-vec00060-001-s065><tell.berichten><de> Hier bekamen die Seminarteilnehmenden auch abwechselnd die Möglichkeit, interessierten Standbesuchern über ihr Studium und ihre Heimatländer zu berichten.
<G-vec00060-001-s065><tell.berichten><en> Here, the seminar participants also took the opportunity to tell interested visitors about their studies and their home countries.
<G-vec00060-001-s066><tell.berichten><de> Eines Tages ließ Jie Xiang dem König durch andere berichten, dass er krank sei.
<G-vec00060-001-s066><tell.berichten><en> One day Jie Xiang asked someone to tell the King that he himself was sick.
<G-vec00060-001-s067><tell.berichten><de> Praktizierende aus der ganzen Tschechischen Republik, unterstützt von einer Gruppe von Praktizierenden aus England, versammelten sich in Brünn, um den Menschen über die Völkermordkampagne der Kommunistischen Partei Chinas gegen Falun Gong in China zu berichten.
<G-vec00060-001-s067><tell.berichten><en> Practitioners from all over the Czech Republic, supported by a group of practitioners from England, gathered in Brno to tell the local people about the Chinese Communist Party's campaign of genocide against Falun Gong in China.
<G-vec00060-001-s068><tell.berichten><de> Berichten Sie Ihrem Arzt über all Ihre Hautprobleme.
<G-vec00060-001-s068><tell.berichten><en> Tell your doctor about all your skin problems.
<G-vec00060-001-s069><tell.berichten><de> Der Rechtsanwalt wird dir von meiner letzten Stunde berichten.
<G-vec00060-001-s069><tell.berichten><en> The lawyer will tell you about my last hour.
<G-vec00060-001-s070><tell.berichten><de> Bitte ihn, in ein paar Tagen zu dir zu kommen und dir zu berichten, wie er sich fühlt.
<G-vec00060-001-s070><tell.berichten><en> In a few days, ask him to come and see you to tell you how he feels.
<G-vec00060-001-s071><tell.berichten><de> Glücklicherweise gibt es Leute, die nicht stillhalten und die von ihren starken persönlichen Erfahrungen berichten wollen.
<G-vec00060-001-s071><tell.berichten><en> Fortunately there are people who do not keep silence and who wish to tell of their strong personal experiences.
<G-vec00060-001-s072><tell.berichten><de> Die Begeisterung, mit der die einheimischen Wander-, Bike-, Kultur- und Genussführer von ihrem ganz persönlichen Steckenpferd berichten, wird Sie überzeugen.
<G-vec00060-001-s072><tell.berichten><en> The enthusiasm with which the local hiking, bike, culture and pleasure guides tell their own personal stories and hobbies are sure to convince you.
<G-vec00060-001-s073><tell.berichten><de> Berichten Sie uns über Ihre Fähigkeiten, OKPAY in Ihrem Land bekannt zu machen.
<G-vec00060-001-s073><tell.berichten><en> Tell us about your abilities to promote OKPAY in your country.
<G-vec00060-001-s074><tell.berichten><de> Ich habe im gleichen Artikel versprochen, zu berichten, ob nach der Transformation noch Dämonen auftauchten.
<G-vec00060-001-s074><tell.berichten><en> In that article I promised to tell you, whether we met more of these demons.
<G-vec00060-001-s075><tell.berichten><de> Seit Januar, als einige Falun Gong Praktizierende in Paris auf Grund des Drucks der Lügen des Jiang Regimes willkürlich verhaftet wurden, entschieden Falun Gong Praktizierende, alle Parlamentsmitglieder in Frankreich zu kontaktieren und ihnen über diesen Vorfall, der die Menschenrechte in Frankreich verletzt, zu berichten.
<G-vec00060-001-s075><tell.berichten><en> Since January, when some Falun Gong practitioners were detained arbitrarily in Paris due to pressure from the Jiang regime's lies, Falun Gong practitioners decided to contact all MPs in France to tell them about this incident that violated human rights in France.
<G-vec00060-001-s114><report.berichten><de> (2) Die Kommission berichtet dem Europäischen Parlament und dem Rat 2010 und 2012 über das Funktionieren der in Absatz 1 beschriebenen Massenbilanzüberprüfungsmethode und über die Möglichkeit, andere Überprüfungsmethoden in Bezug auf einige oder sämtliche Arten von Rohstoffen, Biokraftstoffen oder flüssigen Biobrennstoffen zu erlauben.
<G-vec00060-001-s114><report.berichten><en> The Commission shall report to the European Parliament and the Council in 2010 and 2012 on the operation of the mass balance verification method described in paragraph 1 and on the potential for allowing for other verification methods in relation to some or all types of raw material, biofuel or bioliquids.
<G-vec00060-001-s115><report.berichten><de> Basierend auf -Bewertungen Übersicht Nutzer, die mit Amtrak City of New Orleans gereist sind, haben berichtet, dass sie mit dem WLAN an Bord zu 67 Prozent der Zeit zufrieden waren.
<G-vec00060-001-s115><report.berichten><en> Based on 4 reviews Overview Users that traveled with Amtrak City of New Orleans report that they were happy with the WiFi on board 67 percent of the time.
<G-vec00060-001-s116><report.berichten><de> In den meisten Studien wird über ein gemischtes Patientinnengut berichtet und die jeweiligen Daten wurden nicht immer getrennt ausgewertet.
<G-vec00060-001-s116><report.berichten><en> Most studies report on a mixed patient group, and the respective data are not always analyzed separately.
<G-vec00060-001-s117><report.berichten><de> Ein kleiner, aber doch bedeutender Anteil der Patienten, die häusliche Pflege in Anspruch nehmen, berichtet von Diebstahl, Vernachlässigung oder Misshandlung.
<G-vec00060-001-s117><report.berichten><en> A small, but meaningful, proportion of patients who utilize in-home helpers report concerns of theft, neglect, or mistreatment.
<G-vec00060-001-s118><report.berichten><de> Eine Stunde später, um 15:30 Uhr, berichtet das Projektteam vom konkreten Arbeitsalltag mit neuen Werkzeugen und Möglichkeiten am Beispiel des Spitalzentrum Oberwallis in Brig.
<G-vec00060-001-s118><report.berichten><en> One hour later, at 3:30 pm, the project team will report on everyday work in practice with new tools and options, taking the Upper Valais medical center in Brig as an example.
<G-vec00060-001-s119><report.berichten><de> Ich habe nie von jemand gewusst, welcher berichtet jemand zu 'sehen' welcher noch lebt, aber nicht wirklich im Zimmer ist.
<G-vec00060-001-s119><report.berichten><en> I've never known someone to report 'seeing' someone who is still living but isn't really in the room.
<G-vec00060-001-s120><report.berichten><de> Er berichtet an den Finanzvorstand Prof. Dr. Dirk Jens Nonnenmacher.
<G-vec00060-001-s120><report.berichten><en> He will report to CFO Prof. Dr. Dirk Jens Nonnenmacher.
<G-vec00060-001-s121><report.berichten><de> Sie oder er überwacht im Einvernehmen mit dem Gericht die Erfüllung der Auflagen und Weisungen sowie der Anerbieten und Zusagen und berichtet über die Lebensführung der verurteilten Person in Zeitabständen, die das Gericht bestimmt.
<G-vec00060-001-s121><report.berichten><en> In cooperation with the court he shall supervise the fulfilment of any conditions and directions as well as of any offers and assurances. He shall report on the way the convicted person is conducting himself, at intervals determined by the court.
<G-vec00060-001-s122><report.berichten><de> Wie Kline berichtet, habe beispielsweise die Marke Sephora eine Online-Schmink-Schule gestartet.
<G-vec00060-001-s122><report.berichten><en> As Kline report, a brand like Sephora, for instance, has launched an online make-up school.
<G-vec00060-001-s123><report.berichten><de> Damit berichtet das Unternehmen künftig nur noch über zwei Segmente.
<G-vec00060-001-s123><report.berichten><en> Thus, the company will report on only two segments going forward.
<G-vec00060-001-s124><report.berichten><de> In dem Beitrag setzt sich die Autorin mit der Anwendung des latenten Klassenmodells auseinander und berichtet über praktische Erfahrungen mit dessen Umsetzung.
<G-vec00060-001-s124><report.berichten><en> In their article, the authors examine the use of the latent class model and report on practical experience in applying it.
<G-vec00060-001-s125><report.berichten><de> Philipp berichtet wider Erwarten wohlbehalten aus dem Schwarzwald und lässt sich von der ausgelassenen Atmosphäre des Karnevalstreibens anstecken.
<G-vec00060-001-s125><report.berichten><en> Despite difficulties, Philipp manages to report safely from the Black Forest and gets into the Carnival spirit himself.
<G-vec00060-001-s126><report.berichten><de> < 28:21 Sie aber sprachen zu ihm: Wir haben über dich weder Briefe von Judäa empfangen, noch ist jemand von den Brüdern hergekommen und hat uns über dich etwas Böses berichtet oder gesagt.
<G-vec00060-001-s126><report.berichten><en> < 28:21 And they said unto him, We neither received letters from Judaea concerning thee, nor did any of the brethren come hither and report or speak any harm of thee.
<G-vec00060-001-s127><report.berichten><de> Sie berichtet direkt an Dr. Jens Schulte, Chief Financial Officer und Mitglied des Vorstands der SCHOTT AG.
<G-vec00060-001-s127><report.berichten><en> She will report directly to Dr. Jens Schulte, SCHOTT's Chief Financial Officer and Member of its Management Board.
<G-vec00060-001-s128><report.berichten><de> Basierend auf -Bewertungen Übersicht Nutzer, die mit Amtrak Empire Service gereist sind, haben berichtet, dass sie mit dem WLAN an Bord zu 67 Prozent der Zeit zufrieden waren.
<G-vec00060-001-s128><report.berichten><en> Based on 3 reviews Overview Users that traveled with Amtrak Empire Service report that they were happy with the WiFi on board 67 percent of the time.
<G-vec00060-001-s129><report.berichten><de> (23) Das Internationale Datenzentrum überwacht ständig den Betriebszustand der Einrichtungen des Internationalen Überwachungssystems, der Nachrichtenverbindungen und seiner eigenen Verarbeitungssysteme und berichtet darüber.
<G-vec00060-001-s129><report.berichten><en> 23. The International Data Centre shall continuously monitor and report on the operational status of the International Monitoring System facilities, of communications links, and of its own processing systems.
<G-vec00060-001-s130><report.berichten><de> Washington Cucurto liest aus seinem Buch und berichtet über die Entstehungsgeschichte und Produktionsweise seines Verlagsprojekts Eloisa Cartonera in Buenos Aires.
<G-vec00060-001-s130><report.berichten><en> Washington Curcurto will read from his book and report on the founding and establishment of Eloisa Cartonera in Buenos Aires.
<G-vec00060-001-s131><report.berichten><de> Er berichtet an den Vorsitzenden der Geschäftsführung der Messe Berlin, Dr. Christian Göke.
<G-vec00060-001-s131><report.berichten><en> He will report to Dr. Christian Göke, Chief Executive Officer of Messe Berlin.
<G-vec00060-001-s132><report.berichten><de> Unser Newsletter berichtet vierteljährlich darüber, wie Ideen für nachhaltige gesellschaftliche Entwicklung ganz lokal, aber vielfach auch in regionen- und länderübergreifender Zusammenarbeit Wirklichkeit werden.
<G-vec00060-001-s132><report.berichten><en> Our newsletter provides a quarterly report on how ideas for sustainable social development are implemented locally and through regional and cross-border cooperation.
<G-vec00328-002-s054><relate.berichten><de> Zeitgenössische Quellen berichten, dass sie sich sehr für die Behandlung von Kranken aus der Umgebung einsetzte.
<G-vec00328-002-s054><relate.berichten><en> Contemporary sources relate that she took an active part in the treatment of the sick in the city and its environs.
<G-vec00328-002-s055><relate.berichten><de> Aber ich habe niemals eine solch einzigartige und unvorhersehbare Verkettung an Umständen erlebt, von welcher ich hier berichten werde.
<G-vec00328-002-s055><relate.berichten><en> But I have never experienced such a unique and unforeseeable concatenation of circumstances as that which I am about to relate here.
<G-vec00328-002-s056><relate.berichten><de> Vielleicht möchten Sie auch von einem persönlichen Erlebnis berichten.
<G-vec00328-002-s056><relate.berichten><en> You may want to relate a personal experience of your own.
<G-vec00328-002-s057><relate.berichten><de> Scharfkantig und distanziert scheinen jene Objekte aus einer virtuellen Welt gefallen zu sein und berichten in ihrer Kühle und Perfektion von imaginären Räumen, die keine Individualität offenbaren.
<G-vec00328-002-s057><relate.berichten><en> Sharp edges and distant objects that seem to have fallen from a virtual world, relate in their coolness and perfection to imaginary spaces that reveal no individuality.
<G-vec00328-002-s058><relate.berichten><de> Wir sollten uns auch hüten, zu denken, wie einige israelische Dichter berichten, dass das Meer sich weigerte, dem Willen seines Schöpfers gefügig zu sein, und dass Gott gezwungen war, es sich untertan zu machen und zum Gehorsam zu zwingen.
<G-vec00328-002-s058><relate.berichten><en> Far be it also from you to imagine, as some Israelite poets relate, that the sea refused to do the will of its maker, and that He was compelled to subdue it and force it to obey.
<G-vec00328-002-s059><relate.berichten><de> Ja Ich versuchte sie gleich zu erzählen, aber es dauerte eine Weile für mich, um mental fähig zu sein sie korrekt zu berichten, obwohl sie sich nie in meinem Geist und Bewusstsein veränderte.
<G-vec00328-002-s059><relate.berichten><en> Yes I tried to tell it right away, but it took a while for me to be mentally able to relate it correctly although it has never changed in my spirit and mind.
<G-vec00328-002-s060><relate.berichten><de> Zwei freiwillige Pflegekräfte des Dänischen Roten Kreuzes berichten über ihre Erfahrungen in der Bemühung, die Lücke in der Gesundheitsversorgung für jene zu schließen, die keine Papiere und keinen Zugang zur Gesundheitsversorgung haben.
<G-vec00328-002-s060><relate.berichten><en> Two volunteer nurses for the Danish Red Cross relate their experience of helping to bridge the health-care gap for those who find themselves undocumented and unable to access health care.
<G-vec00328-002-s061><relate.berichten><de> Heute ist unser erster Seetag – da gibt es nicht viel zu berichten.
<G-vec00328-002-s061><relate.berichten><en> Today is our first day at sea – not much to relate.
