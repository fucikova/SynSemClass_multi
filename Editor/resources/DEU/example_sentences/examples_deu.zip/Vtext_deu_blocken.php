<G-vec00081-001-s095><block.blocken><de> "Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00081-001-s095><block.blocken><en> "It is also possible to block Facebook social plugins with add-ons for your browser, for example with the ""Facebook Blocker""."
<G-vec00081-001-s096><block.blocken><de> Anschließend versuchte die Polizei, die Nachrichten hierüber zu blocken.
<G-vec00081-001-s096><block.blocken><en> Afterwards, the police tried to block the news.
<G-vec00081-001-s097><block.blocken><de> Die einfache Annaeherung daran wuerde sein, alle einkommenden TCP-Pakete von diesem Server zu blocken.
<G-vec00081-001-s097><block.blocken><en> The naive approach would be to block TCP packets coming from the server.
<G-vec00081-001-s098><block.blocken><de> Blocken: Benötigt zur Aktivierung nun 10% der Ausdauer (zuvor: 20%).
<G-vec00081-001-s098><block.blocken><en> Block: Now requires 10% of your stamina bar to activate (down from 20%)
<G-vec00081-001-s099><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00081-001-s099><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00081-001-s101><block.blocken><de> Falls Sie unsere Cookies in Ihrem Browser blocken, können Sie manche Bereiche unserer Website nicht nutzen.
<G-vec00081-001-s101><block.blocken><en> If you block our cookies in your browser, you may not be able to us some of areas of our website.
<G-vec00081-001-s102><block.blocken><de> In diesem Fall ist es sinnvoll, die Robots.txt zum Blocken der Suchmaschinen zu nutzen und gleichzeitig ein Passwortschutz für zusätzliche Sicherheit einzurichten.
<G-vec00081-001-s102><block.blocken><en> In this case, it's a good idea to use robots.txt to block the search engines and at the same time add password protection as an extra level of security.
<G-vec00081-001-s103><block.blocken><de> "Sie können im Übrigen Facebook-Social-Plugins mit Add-ons für Ihren Browser blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00081-001-s103><block.blocken><en> "You can also block Facebook social plugins with add-ons for your browser, for example with the ""Facebook blocker""."
<G-vec00081-001-s104><block.blocken><de> Im gegebenen Beispiel würdet Ihr (1) das Reiterlager sowie (2) das Nahkampflager mit Euren schweren Einheiten blocken und dann (3) den Sektorboss mit Euren Angriffseinheiten und drei Marschällen besiegen.
<G-vec00081-001-s104><block.blocken><en> In the given example, you would (1) block the cavalry camp and (2) the melee camp with your heavy units and then (3) defeat the sector boss with your attack units, utilizing your three Marshals.
<G-vec00081-001-s105><block.blocken><de> Falls Sie in Ihren Browsereinstellungen alle Cookies blocken, können Sie möglicherweise nicht auf alle Teile unserer Websites zugreifen.
<G-vec00081-001-s105><block.blocken><en> However, if you use your browser settings to block all cookies you may not be to access some parts of our site.
<G-vec00081-001-s106><block.blocken><de> Enthält eine Blocken-Funktion, mit der Sie unangemessene Webseiten und Nachrichten blocken können.
<G-vec00081-001-s106><block.blocken><en> It comes with a block feature that allows you to solely block out profane websites and messages.
<G-vec00081-001-s107><block.blocken><de> – Cookies von externen Drittanbietern blocken.
<G-vec00081-001-s107><block.blocken><en> – block third-party cookies.
<G-vec00081-001-s108><block.blocken><de> Erhöht die Wahrscheinlichkeit einen Angriff zu blocken um 0.9% .
<G-vec00081-001-s108><block.blocken><en> Increases the chance to block an attack by 0.9% .
<G-vec00081-001-s109><block.blocken><de> Blocken: Der Echsenmensch hebt seinen Speer um sich gegen kommende Angriffe zu schützen.
<G-vec00081-001-s109><block.blocken><en> Block: The Lizardman can sometimes hold up their spear to defend themselves against oncoming attacks.
<G-vec00081-001-s110><block.blocken><de> Sie können versuchen Dirk Nowitzki zu blocken.
<G-vec00081-001-s110><block.blocken><en> Try to block Dirk Nowitzki!
<G-vec00081-001-s111><block.blocken><de> Firewall gegen Angriffe von Außen und Blocken von Ports und unerwünschter Dienste.
<G-vec00081-001-s111><block.blocken><en> Firewall to block scanning, attacks, and other hostile activity from external networks.
<G-vec00081-001-s112><block.blocken><de> "Ergänzend besteht im Einzelfall die Möglichkeit, Socialplug-ins mithilfe von Add-ons für Ihren Browser zu blocken, so etwa das Facebook plug-in mit dem ""Facebook Blocker""."
<G-vec00081-001-s112><block.blocken><en> "Furthermore, in individual cases, it is possible to block social media plugins using add-ons for your browser, e.g., blocking the Facebook plugin using ""Facebook Blocker""."
<G-vec00081-001-s113><block.blocken><de> Bitte beachte, dass das Blocken von Cookies die Funktionalität der Internetseite beeinträchtigen kann.
<G-vec00081-001-s113><block.blocken><en> A block of cookies may affect the functionality of your Website session.
<G-vec00367-001-s096><block.blocken><de> Anschließend versuchte die Polizei, die Nachrichten hierüber zu blocken.
<G-vec00367-001-s096><block.blocken><en> Afterwards, the police tried to block the news.
<G-vec00367-001-s110><block.blocken><de> Sie können versuchen Dirk Nowitzki zu blocken.
<G-vec00367-001-s110><block.blocken><en> Try to block Dirk Nowitzki!
<G-vec00367-002-s076><block.blocken><de> Die Nutzer müssen die Kontaktaufnahme übrigens selbst auslösen und können Unternehmen zudem wieder blocken oder im Fall der Fälle auch als Spam melden.
<G-vec00367-002-s076><block.blocken><en> Incidentally, users must initiate contact themselves and can also block companies again or report them as spam if the worst comes to the worst.
<G-vec00367-002-s077><block.blocken><de> Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem “uBlock Origin“.
<G-vec00367-002-s077><block.blocken><en> It is also possible to block Facebook social plugins with add-ons for your browser, for example with the "uBlock Origin".
<G-vec00367-002-s078><block.blocken><de> Es ist möglich, einen Ball eines Zielschlags oder eines anderen Spezialschlags zu blocken, indem die Schlagtaste zum richtigen Zeitpunkt gedrückt wird, selbst wenn ein Trickschlag ausgeführt wird.
<G-vec00367-002-s078><block.blocken><en> It is possible to block the ball from a Zone Shot or another Special Shot by pressing the shot button with good timing, even when while using a Trick Shot.
<G-vec00367-002-s079><block.blocken><de> Wenn man gleichzeitig zwei Waffen führt, kann man überhaupt nicht blocken.
<G-vec00367-002-s079><block.blocken><en> If you are wielding two weapons, you can't block at all.
<G-vec00367-002-s080><block.blocken><de> Darüber hinaus kann die Gesellschaft im Falle verdächtiger Transaktionen die Konten der betreffenden Spieler sperren, blocken oder schließen und jegliches Guthaben in den jeweiligen Spielerkonten einbehalten, wie dies gesetzlich vorgeschrieben ist und / oder von den zuständigen Behörden.
<G-vec00367-002-s080><block.blocken><en> Furthermore, in the event of any suspicious transactions/activities, the company may suspend, block or close the account(s) of the relevant player(s) and withhold funds as may be required by law and/or by the competent Authorities.
<G-vec00367-002-s081><block.blocken><de> Inbrünstige kann nicht angreifen oder blocken, es sei denn, du hast eine oder weniger Karten auf deiner Hand.
<G-vec00367-002-s081><block.blocken><en> Hazoret the Fervent can't attack or block unless you have one or fewer cards in hand.
<G-vec00367-002-s082><block.blocken><de> Dies bedeutet, dass die Pumpleistung des Herzens zunimmt und der Blutdruck zunimmt.Der Betablocker Bisoprolol besitzt die Fähigkeit diese Rezeptoren zu blocken, sodass Adrenalin und Noradrenalin nicht mehr andocken können, was eine Abschwächung der Adrenalinwirkung bewirkt.
<G-vec00367-002-s082><block.blocken><en> This means that the pumping power of the heart increases and the blood pressure increases.The beta-blocker Bisoprolol has the ability to block these receptors so that epinephrine and norepinephrine can no longer dock, causing a decrease in adrenaline.
<G-vec00367-002-s083><block.blocken><de> Segen des Refugiums: Gewährt nun nur Mana bei Ausweichen/Parieren/Blocken.
<G-vec00367-002-s083><block.blocken><en> Blessing of Sanctuary: Now only grants mana on dodge/parry/block.
<G-vec00367-002-s084><block.blocken><de> Blue Route/Block- und Release-TEs werden jetzt Pässe blocken, bis der Nutzer seine Receiver-Taste drückt und ihn so auf seine Route schickt – je höher die Awareness des TEs, desto schneller wird er auf den Knopfdruck reagieren.
<G-vec00367-002-s084><block.blocken><en> Blue route/Block and Release TE’s will now pass block until the user presses his receiver icon to release him into his route – the higher the TE’s awareness, the more responsive he will be to the button press.
<G-vec00367-002-s085><block.blocken><de> - Schieben Sie den Regler auf „Alle Cookies blocken“.
<G-vec00367-002-s085><block.blocken><en> - Move the slider up to the "Block all Cookies" button
<G-vec00367-002-s086><block.blocken><de> Sie können Cookies von unserer Webseite mit Hilfe unseres Webbrowsers einschränken, blocken oder löschen (bitte beachten Sie, dass die Software der meisten Webbrowser in der Regel so eingestellt ist, dass sie Cookies akzeptiert).
<G-vec00367-002-s086><block.blocken><en> You can restrict, block or delete cookies from our site using your web browser (note that most web browser software is initially set up to accept cookies).
<G-vec00367-002-s087><block.blocken><de> Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem “Facebook Blocker“.
<G-vec00367-002-s087><block.blocken><en> It is also possible to block Facebook social plugins with add-ons for your browser, for example with the "Facebook Blocker".
<G-vec00367-002-s088><block.blocken><de> Das Blocken oder Deaktivieren des Trackings geht genauso leicht, da Sygic sich sehr der Privatsphären-Problematik bewusst ist, die auftauchen kann, so dass der User den Ortungsdienst canceln kann.
<G-vec00367-002-s088><block.blocken><en> About how to disable or block the tracking, it's equally easy since Sygic is very aware of the privacy issues that may arise, allowing the user to cancel the location service.
<G-vec00367-002-s089><block.blocken><de> Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für den Browser zu blocken, zum Beispiel mit dem “Facebook Blocker”.
<G-vec00367-002-s089><block.blocken><en> Furthermore it is possible to block the data generation of Facebook Plug-ins by using browser add-ons such as „Facebook Blocker“
<G-vec00367-002-s090><block.blocken><de> Auf Seite 20 ist als dominierende Eigenschaft für das Blocken Geschicklichkeit angegeben.
<G-vec00367-002-s090><block.blocken><en> Page 20 states the Governing Attribute for Block is Agility.
<G-vec00367-002-s091><block.blocken><de> Das ist eine gute Methode, weil es heute schon funktioniert und es effektiv möglich macht, fast alle Tracking-Versuche zu blocken.
<G-vec00367-002-s091><block.blocken><en> This is a great method, because it works today and allows you to effectively block almost all tracking.
<G-vec00367-002-s092><block.blocken><de> Mein Gegner opfert daraufhin den Kriegsboss für seinen Skirk-Schürfer und behauptet, dass dadurch mein Spruch neutralisiert wird und er mit einem anderen Goblin blocken kann.
<G-vec00367-002-s092><block.blocken><en> My opponent sacrificed the Warboss to his Skirk Prospector, claiming that my spell is now countered, and he can chump block with another goblin.
<G-vec00367-002-s093><block.blocken><de> Wir blocken für euch den Gruppenflug und das Hotelzimmer.
<G-vec00367-002-s093><block.blocken><en> We will block flights from our contingent and your hotel accommodation for you.
<G-vec00367-002-s094><block.blocken><de> Besonderer Mehrwert hier ist die Tatsache, dass dieser Blocker automatisch dazulernt und somit immer mehr Tracking-Versuche erkennt und damit blocken kann.
<G-vec00367-002-s094><block.blocken><en> Special added value here is the fact that this blocker learns automatically and thus recognizes more and more tracking attempts and thus can block.
