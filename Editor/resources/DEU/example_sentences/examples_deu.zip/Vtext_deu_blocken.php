<G-vec00081-001-s095><block.blocken><de> "Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00081-001-s095><block.blocken><en> "It is also possible to block Facebook social plugins with add-ons for your browser, for example with the ""Facebook Blocker""."
<G-vec00081-001-s096><block.blocken><de> Anschließend versuchte die Polizei, die Nachrichten hierüber zu blocken.
<G-vec00081-001-s096><block.blocken><en> Afterwards, the police tried to block the news.
<G-vec00081-001-s097><block.blocken><de> Die einfache Annaeherung daran wuerde sein, alle einkommenden TCP-Pakete von diesem Server zu blocken.
<G-vec00081-001-s097><block.blocken><en> The naive approach would be to block TCP packets coming from the server.
<G-vec00081-001-s098><block.blocken><de> Blocken: Benötigt zur Aktivierung nun 10% der Ausdauer (zuvor: 20%).
<G-vec00081-001-s098><block.blocken><en> Block: Now requires 10% of your stamina bar to activate (down from 20%)
<G-vec00081-001-s099><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00081-001-s099><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00081-001-s100><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00081-001-s100><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00081-001-s101><block.blocken><de> Falls Sie unsere Cookies in Ihrem Browser blocken, können Sie manche Bereiche unserer Website nicht nutzen.
<G-vec00081-001-s101><block.blocken><en> If you block our cookies in your browser, you may not be able to us some of areas of our website.
<G-vec00081-001-s102><block.blocken><de> In diesem Fall ist es sinnvoll, die Robots.txt zum Blocken der Suchmaschinen zu nutzen und gleichzeitig ein Passwortschutz für zusätzliche Sicherheit einzurichten.
<G-vec00081-001-s102><block.blocken><en> In this case, it's a good idea to use robots.txt to block the search engines and at the same time add password protection as an extra level of security.
<G-vec00081-001-s103><block.blocken><de> "Sie können im Übrigen Facebook-Social-Plugins mit Add-ons für Ihren Browser blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00081-001-s103><block.blocken><en> "You can also block Facebook social plugins with add-ons for your browser, for example with the ""Facebook blocker""."
<G-vec00081-001-s104><block.blocken><de> Im gegebenen Beispiel würdet Ihr (1) das Reiterlager sowie (2) das Nahkampflager mit Euren schweren Einheiten blocken und dann (3) den Sektorboss mit Euren Angriffseinheiten und drei Marschällen besiegen.
<G-vec00081-001-s104><block.blocken><en> In the given example, you would (1) block the cavalry camp and (2) the melee camp with your heavy units and then (3) defeat the sector boss with your attack units, utilizing your three Marshals.
<G-vec00081-001-s105><block.blocken><de> Falls Sie in Ihren Browsereinstellungen alle Cookies blocken, können Sie möglicherweise nicht auf alle Teile unserer Websites zugreifen.
<G-vec00081-001-s105><block.blocken><en> However, if you use your browser settings to block all cookies you may not be to access some parts of our site.
<G-vec00081-001-s106><block.blocken><de> Enthält eine Blocken-Funktion, mit der Sie unangemessene Webseiten und Nachrichten blocken können.
<G-vec00081-001-s106><block.blocken><en> It comes with a block feature that allows you to solely block out profane websites and messages.
<G-vec00081-001-s107><block.blocken><de> – Cookies von externen Drittanbietern blocken.
<G-vec00081-001-s107><block.blocken><en> – block third-party cookies.
<G-vec00081-001-s108><block.blocken><de> Erhöht die Wahrscheinlichkeit einen Angriff zu blocken um 0.9% .
<G-vec00081-001-s108><block.blocken><en> Increases the chance to block an attack by 0.9% .
<G-vec00081-001-s109><block.blocken><de> Blocken: Der Echsenmensch hebt seinen Speer um sich gegen kommende Angriffe zu schützen.
<G-vec00081-001-s109><block.blocken><en> Block: The Lizardman can sometimes hold up their spear to defend themselves against oncoming attacks.
<G-vec00081-001-s110><block.blocken><de> Sie können versuchen Dirk Nowitzki zu blocken.
<G-vec00081-001-s110><block.blocken><en> Try to block Dirk Nowitzki!
<G-vec00081-001-s111><block.blocken><de> Firewall gegen Angriffe von Außen und Blocken von Ports und unerwünschter Dienste.
<G-vec00081-001-s111><block.blocken><en> Firewall to block scanning, attacks, and other hostile activity from external networks.
<G-vec00081-001-s112><block.blocken><de> "Ergänzend besteht im Einzelfall die Möglichkeit, Socialplug-ins mithilfe von Add-ons für Ihren Browser zu blocken, so etwa das Facebook plug-in mit dem ""Facebook Blocker""."
<G-vec00081-001-s112><block.blocken><en> "Furthermore, in individual cases, it is possible to block social media plugins using add-ons for your browser, e.g., blocking the Facebook plugin using ""Facebook Blocker""."
<G-vec00081-001-s113><block.blocken><de> Bitte beachte, dass das Blocken von Cookies die Funktionalität der Internetseite beeinträchtigen kann.
<G-vec00081-001-s113><block.blocken><en> A block of cookies may affect the functionality of your Website session.
<G-vec00367-001-s095><block.blocken><de> "Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00367-001-s095><block.blocken><en> "It is also possible to block Facebook social plugins with add-ons for your browser, for example with the ""Facebook Blocker""."
<G-vec00367-001-s096><block.blocken><de> Anschließend versuchte die Polizei, die Nachrichten hierüber zu blocken.
<G-vec00367-001-s096><block.blocken><en> Afterwards, the police tried to block the news.
<G-vec00367-001-s097><block.blocken><de> Die einfache Annaeherung daran wuerde sein, alle einkommenden TCP-Pakete von diesem Server zu blocken.
<G-vec00367-001-s097><block.blocken><en> The naive approach would be to block TCP packets coming from the server.
<G-vec00367-001-s098><block.blocken><de> Blocken: Benötigt zur Aktivierung nun 10% der Ausdauer (zuvor: 20%).
<G-vec00367-001-s098><block.blocken><en> Block: Now requires 10% of your stamina bar to activate (down from 20%)
<G-vec00367-001-s099><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00367-001-s099><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00367-001-s100><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00367-001-s100><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00367-001-s101><block.blocken><de> Falls Sie unsere Cookies in Ihrem Browser blocken, können Sie manche Bereiche unserer Website nicht nutzen.
<G-vec00367-001-s101><block.blocken><en> If you block our cookies in your browser, you may not be able to us some of areas of our website.
<G-vec00367-001-s102><block.blocken><de> In diesem Fall ist es sinnvoll, die Robots.txt zum Blocken der Suchmaschinen zu nutzen und gleichzeitig ein Passwortschutz für zusätzliche Sicherheit einzurichten.
<G-vec00367-001-s102><block.blocken><en> In this case, it's a good idea to use robots.txt to block the search engines and at the same time add password protection as an extra level of security.
<G-vec00367-001-s103><block.blocken><de> "Sie können im Übrigen Facebook-Social-Plugins mit Add-ons für Ihren Browser blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00367-001-s103><block.blocken><en> "You can also block Facebook social plugins with add-ons for your browser, for example with the ""Facebook blocker""."
<G-vec00367-001-s104><block.blocken><de> Im gegebenen Beispiel würdet Ihr (1) das Reiterlager sowie (2) das Nahkampflager mit Euren schweren Einheiten blocken und dann (3) den Sektorboss mit Euren Angriffseinheiten und drei Marschällen besiegen.
<G-vec00367-001-s104><block.blocken><en> In the given example, you would (1) block the cavalry camp and (2) the melee camp with your heavy units and then (3) defeat the sector boss with your attack units, utilizing your three Marshals.
<G-vec00367-001-s105><block.blocken><de> Falls Sie in Ihren Browsereinstellungen alle Cookies blocken, können Sie möglicherweise nicht auf alle Teile unserer Websites zugreifen.
<G-vec00367-001-s105><block.blocken><en> However, if you use your browser settings to block all cookies you may not be to access some parts of our site.
<G-vec00367-001-s106><block.blocken><de> Enthält eine Blocken-Funktion, mit der Sie unangemessene Webseiten und Nachrichten blocken können.
<G-vec00367-001-s106><block.blocken><en> It comes with a block feature that allows you to solely block out profane websites and messages.
<G-vec00367-001-s107><block.blocken><de> – Cookies von externen Drittanbietern blocken.
<G-vec00367-001-s107><block.blocken><en> – block third-party cookies.
<G-vec00367-001-s108><block.blocken><de> Erhöht die Wahrscheinlichkeit einen Angriff zu blocken um 0.9% .
<G-vec00367-001-s108><block.blocken><en> Increases the chance to block an attack by 0.9% .
<G-vec00367-001-s109><block.blocken><de> Blocken: Der Echsenmensch hebt seinen Speer um sich gegen kommende Angriffe zu schützen.
<G-vec00367-001-s109><block.blocken><en> Block: The Lizardman can sometimes hold up their spear to defend themselves against oncoming attacks.
<G-vec00367-001-s110><block.blocken><de> Sie können versuchen Dirk Nowitzki zu blocken.
<G-vec00367-001-s110><block.blocken><en> Try to block Dirk Nowitzki!
<G-vec00367-001-s111><block.blocken><de> Firewall gegen Angriffe von Außen und Blocken von Ports und unerwünschter Dienste.
<G-vec00367-001-s111><block.blocken><en> Firewall to block scanning, attacks, and other hostile activity from external networks.
<G-vec00367-001-s112><block.blocken><de> "Ergänzend besteht im Einzelfall die Möglichkeit, Socialplug-ins mithilfe von Add-ons für Ihren Browser zu blocken, so etwa das Facebook plug-in mit dem ""Facebook Blocker""."
<G-vec00367-001-s112><block.blocken><en> "Furthermore, in individual cases, it is possible to block social media plugins using add-ons for your browser, e.g., blocking the Facebook plugin using ""Facebook Blocker""."
<G-vec00367-001-s113><block.blocken><de> Bitte beachte, dass das Blocken von Cookies die Funktionalität der Internetseite beeinträchtigen kann.
<G-vec00367-001-s113><block.blocken><en> A block of cookies may affect the functionality of your Website session.
