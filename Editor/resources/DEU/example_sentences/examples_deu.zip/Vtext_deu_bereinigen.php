<G-vec00301-001-s068><rectify.bereinigen><de> Die USA und Israel haben gegen aufeinander folgende UN-Resolutionen gestimmt, die versuchten, die Situation gemäß diesem internationalen Konsens zu bereinigen.
<G-vec00301-001-s068><rectify.bereinigen><en> The US and Israel have voted against successive UN resolutions attempting to rectify the situation according to this international consensus.
<G-vec00301-001-s069><rectify.bereinigen><de> Aber ich möchte die Situation bereinigen.
<G-vec00301-001-s069><rectify.bereinigen><en> But I want to rectify the situation.
<G-vec00301-001-s070><rectify.bereinigen><de> Ich fordere Sie auf, diese Situation zu bereinigen.
<G-vec00301-001-s070><rectify.bereinigen><en> I ask you to rectify this situation.
<G-vec00301-001-s071><rectify.bereinigen><de> Und wenn die Berufungsgerichte weigern sich, die Situation zu bereinigen, dann müssen sie auch zu sauber gefegt.
<G-vec00301-001-s071><rectify.bereinigen><en> And if the appellate courts refuse to rectify the situation, then they too need to be swept clean.
<G-vec00301-001-s072><rectify.bereinigen><de> Wenn wir es klar erkennen, müssen wir versuchen die Situation zu bereinigen, indem wir die verschiedenen Methoden der Achtsamkeit und Paññā anwenden, bis diese Sache ohne weitere Verbindungen vom Citta abgeschnitten ist.
<G-vec00301-001-s072><rectify.bereinigen><en> When we know this clearly, we have to try to rectify the situation, using the various methods of mindfulness and discernment until that thing is cut away from the mind with no more connections.
<G-vec00301-001-s073><rectify.bereinigen><de> Um diese Situation zu bereinigen, kann der Inhalt der Link-Funktion in eine init-Funktion gekapselt werden, die dann je nach Lage entweder sofort oder erst später ausgeführt wird.
<G-vec00301-001-s073><rectify.bereinigen><en> To rectify the situation, the original body of the link function can be wrapped into an init function, which either executes immediately or gets delayed as necessary.
<G-vec00301-002-s068><rectify.bereinigen><de> Hoffentlich wird der neue BDO Vorstand das bereinigen und das Turnier wieder seinen ursprünglichen Glanz zurückgeben.
<G-vec00301-002-s068><rectify.bereinigen><en> Hopefully the new BDO board will rectify this and restore the event to its former glory.
