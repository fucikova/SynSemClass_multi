<G-vec00301-001-s068><rectify.bereinigen><de> Die USA und Israel haben gegen aufeinander folgende UN-Resolutionen gestimmt, die versuchten, die Situation gemäß diesem internationalen Konsens zu bereinigen.
<G-vec00301-001-s068><rectify.bereinigen><en> The US and Israel have voted against successive UN resolutions attempting to rectify the situation according to this international consensus.
<G-vec00301-001-s069><rectify.bereinigen><de> Aber ich möchte die Situation bereinigen.
<G-vec00301-001-s069><rectify.bereinigen><en> But I want to rectify the situation.
<G-vec00301-001-s070><rectify.bereinigen><de> Ich fordere Sie auf, diese Situation zu bereinigen.
<G-vec00301-001-s070><rectify.bereinigen><en> I ask you to rectify this situation.
<G-vec00301-001-s071><rectify.bereinigen><de> Und wenn die Berufungsgerichte weigern sich, die Situation zu bereinigen, dann müssen sie auch zu sauber gefegt.
<G-vec00301-001-s071><rectify.bereinigen><en> And if the appellate courts refuse to rectify the situation, then they too need to be swept clean.
<G-vec00301-001-s072><rectify.bereinigen><de> Wenn wir es klar erkennen, müssen wir versuchen die Situation zu bereinigen, indem wir die verschiedenen Methoden der Achtsamkeit und Paññā anwenden, bis diese Sache ohne weitere Verbindungen vom Citta abgeschnitten ist.
<G-vec00301-001-s072><rectify.bereinigen><en> When we know this clearly, we have to try to rectify the situation, using the various methods of mindfulness and discernment until that thing is cut away from the mind with no more connections.
<G-vec00301-001-s073><rectify.bereinigen><de> Um diese Situation zu bereinigen, kann der Inhalt der Link-Funktion in eine init-Funktion gekapselt werden, die dann je nach Lage entweder sofort oder erst später ausgeführt wird.
<G-vec00301-001-s073><rectify.bereinigen><en> To rectify the situation, the original body of the link function can be wrapped into an init function, which either executes immediately or gets delayed as necessary.
<G-vec00301-002-s068><rectify.bereinigen><de> Hoffentlich wird der neue BDO Vorstand das bereinigen und das Turnier wieder seinen ursprünglichen Glanz zurückgeben.
<G-vec00301-002-s068><rectify.bereinigen><en> Hopefully the new BDO board will rectify this and restore the event to its former glory.
<G-vec00380-003-s019><clean_up.bereinigen><de> Dies hilft, die Ränder um das kodierte Bild zu bereinigen.
<G-vec00380-003-s019><clean_up.bereinigen><en> This helps to clean up the edges around the Keyed image.
<G-vec00380-003-s020><clean_up.bereinigen><de> Es hat die Fähigkeit, Ihre Junk-Datei zu bereinigen.
<G-vec00380-003-s020><clean_up.bereinigen><en> It has the ability to clean your junk file.
<G-vec00380-003-s021><clean_up.bereinigen><de> Verbessern, bereinigen und reichern Sie Ihre Produktdaten an, um perfekt optimierte Daten-Feeds zu erstellen.
<G-vec00380-003-s021><clean_up.bereinigen><en> Correct, clean up and enrich your product data to create tailored, optimized data feeds.
<G-vec00380-003-s022><clean_up.bereinigen><de> Sie sind dafür verantwortlich, Ihre E-Mail-Listen außerhalb von SurveyMonkey zu bereinigen, bevor Sie sie auf der Website verwenden.
<G-vec00380-003-s022><clean_up.bereinigen><en> It's your responsibility to clean your email lists outside of SurveyMonkey before using them on the site.
<G-vec00380-003-s023><clean_up.bereinigen><de> Die HTML-basierten Dokumentationsformate (CHM, HTML, ePub, Kindle und Qt-Hilfe) können jetzt das Ausgabeverzeichnis optional vor der Generierung der Dokumentation bereinigen, sodass Sie auf einfache Weise eine einwandfrei saubere Dokumentation ohne gelöschte oder veraltete Inhalte erstellen können: Sie können unter den Build-Einstellungen zwischen “Nie bereinigen”, “Immer bereinigen” oder “Vor dem Bereinigen fragen” auswählen und so die für Ihren spezifischen Arbeitsablauf passende Einstellung auswählen.
<G-vec00380-003-s023><clean_up.bereinigen><en> HTML based documentation formats (CHM, HTML, ePub, Kindle and Qt Help) can now optionally clean the output directory before generating the documentation, making it easier to create perfectly clean documentation without any deleted or outdated content: you can choose between “Never clean”, “Always clean” or “Ask before cleaning” from the build settings to make sure that it fits your specific workflow.
<G-vec00380-003-s026><clean_up.bereinigen><de> Bereinigen Sie die Nachbarschaft durch die Zerstörung der Goos mit Koala Koala und seinem Arsenal von Zaubertränken.
<G-vec00380-003-s026><clean_up.bereinigen><en> Clean up the neighborhood by destroying the goos with Koala Koala and his arsenal of magic potions.
<G-vec00380-003-s027><clean_up.bereinigen><de> Jean Marie bereinigen die Zimmer jeden Tag.
<G-vec00380-003-s027><clean_up.bereinigen><en> Jean Marie clean up the rooms every day.
<G-vec00380-003-s028><clean_up.bereinigen><de> Mehr als 30 One-Touch-Tools: Laufwerke bereinigen, private Dateien sichern, Screenshots erstellen oder Videos herunterladen – alles mit nur einem Klick.
<G-vec00380-003-s028><clean_up.bereinigen><en> Over 30 one-touch tools—clean your drive, secure private files, take screenshots, or download a video all with just a single click.
<G-vec00380-003-s029><clean_up.bereinigen><de> 3×02 Phoenix – Clark muss das Chaos bereinigen, welches er hinterlassen hat, was eine neue Blutprobe einschließt.
<G-vec00380-003-s029><clean_up.bereinigen><en> 3×02 Phoenix – Clark has to clean up his mess, including the providing of another blood sample.
<G-vec00380-003-s030><clean_up.bereinigen><de> Und das passiert auch auf iPhone und iPad, aber Sie können sich aber eine Anwendung holen, die Ihnen hilft, Ihr iOS zu bereinigen und die Leistung zu verbessern.
<G-vec00380-003-s030><clean_up.bereinigen><en> And this also happens on iPhone and iPad, but you can get hold of an application that helps you to clean iOS and improve its performance.
<G-vec00380-003-s031><clean_up.bereinigen><de> Dies ist erforderlich, da Kunden im Rahmen des Upgrades ihre SharePoint-Lösungen meist bereinigen und neu gestalten, was wir empfehlen.
<G-vec00380-003-s031><clean_up.bereinigen><en> This is a requirement because customers typically clean up and architect their SharePoint solutions again as part of the upgrade, which we recommend.
<G-vec00380-003-s032><clean_up.bereinigen><de> Mit Autodesk ReCap haben Sie Zugriff auf eine Vielzahl von Werkzeugen und können beispielsweise unerwünschte Objekte bereinigen, um ein präzises 3D-Modell zu erhalten.
<G-vec00380-003-s032><clean_up.bereinigen><en> With Autodesk ReCap you can also access a wide range of tools and, for instance, clean the unwanted objects to work more specifically on a precise object!
<G-vec00380-003-s033><clean_up.bereinigen><de> Bereinigen Sie alle Dateien, die Ihre Passwörter, Nachrichten und Fotos enthalten.
<G-vec00380-003-s033><clean_up.bereinigen><en> Clean up all of your files that include your account passwords, messages and photos.
<G-vec00380-003-s034><clean_up.bereinigen><de> Wählen Sie auf der nächsten Seite diejenigen Kontakte, die Sie bereinigen möchten.
<G-vec00380-003-s034><clean_up.bereinigen><en> Select the type of contacts you want to clean out.
<G-vec00380-003-s035><clean_up.bereinigen><de> Sie können diese Listen bereinigen.
<G-vec00380-003-s035><clean_up.bereinigen><en> You can clean up these lists.
<G-vec00380-003-s036><clean_up.bereinigen><de> Das Programm lässt sich in die meisten modernen Browser integrieren, kann den Besuchsverlauf bereinigen, temporäre Dateien und Daten bereinigen, enthält ein Fenster mit detaillierten Verbindungsstatistiken, kann Protokolle im TXT-Format aufzeichnen und exportieren.
<G-vec00380-003-s036><clean_up.bereinigen><en> The program integrates into most modern browsers, can clean their visiting history, temporary files and data, includes a window with detailed connection statistics, can record and export logs in txt format.
<G-vec00380-003-s037><clean_up.bereinigen><de> Prüfen Sie Ihren Computer auf PUPs und bereinigen Sie ihn regelmäßig, zum Beispiel auch mit dem kostenlosen Emsisoft Emergency Kit.
<G-vec00380-003-s037><clean_up.bereinigen><en> Scan and clean your computer from PUPs periodically with our the Free Emsisoft Emergency Kit.
