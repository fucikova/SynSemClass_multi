<G-vec00486-002-s019><defer.anweisen><de> Die Menschen sind auf sie angewiesen, wenn sie Fragen haben, was sie dürfen und was nicht.
<G-vec00486-002-s019><defer.anweisen><en> People defer to them when they have questions about what they should and should not do.
<G-vec00555-002-s056><dismiss.anweisen><de> Wenn Sie keine Erinnerung für Ereignisse in der Vergangenheit sehen möchten, können Sie Outlook anweisen, die Erinnerung für vergangene Ereignisse automatisch zu schließen.
<G-vec00555-002-s056><dismiss.anweisen><en> If you don't want to see reminders for events in the past, you can tell Outlook to automatically dismiss reminders for past events.
