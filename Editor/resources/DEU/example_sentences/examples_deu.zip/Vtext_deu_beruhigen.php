<G-vec00535-001-s012><reassure.beruhigen><de> 1Jo 3:19 Und daran werden wir erkennen, daß wir aus der Wahrheit sind, und unser Herz vor ihm beruhigen.
<G-vec00535-001-s012><reassure.beruhigen><en> 19 By this we shall know that we are of the truth and reassure our heart before him;
<G-vec00535-001-s015><reassure.beruhigen><de> Beruhige mich über die Situation bei Dir.
<G-vec00535-001-s015><reassure.beruhigen><en> Reassure me about the situation where you are.
<G-vec00535-001-s016><reassure.beruhigen><de> [BM 112.28] Ich aber beruhige Chanchah sogleich damit, daß Ich ihr verheiße, auch sie werde den Lama bald erkennen und erschauen, und damit ist sie auch zufrieden.
<G-vec00535-001-s016><reassure.beruhigen><en> [BM 112.28] But I reassure Chanchah that she, too, will soon recognize Lama, and she is quite satisfied.
<G-vec00535-001-s017><reassure.beruhigen><de> Ich musste ihn beruhigen.
<G-vec00535-001-s017><reassure.beruhigen><en> I needed to reassure him.
<G-vec00535-001-s018><reassure.beruhigen><de> Experimentieren Sie mit Fernsehen oder halten auf sagen laut beruhigende Sätze und beruhigen Sie sich, dass es nichts zu befürchten.
<G-vec00535-001-s018><reassure.beruhigen><en> Experiment with watching television or keep on saying out loud calming phrases and reassure yourself that there isn’t anything to worry about.
<G-vec00535-001-s019><reassure.beruhigen><de> Der Minister für Aussöhnung besuchte sie in ihren Unterkünften in Niger, Mauretanien und Burkina Faso, um sie zu beruhigen und um die Rückkehr nach Mali zu bitten”.
<G-vec00535-001-s019><reassure.beruhigen><en> "The Minister of Reconciliation went to visit them in reception centers, in Niger, Mauritania and Burkina Faso, to try to reassure them and to ask them to return to Mali""."
<G-vec00535-001-s020><reassure.beruhigen><de> "Animation 7 zu 7 > ""100% Spaß jeden Tag, den ganzen Tag"", also beruhigen wir Eltern und lassen sie sich entspannen, während die Kinder Spaß mit unserem Animationsteam haben."
<G-vec00535-001-s020><reassure.beruhigen><en> "Animation 7 on 7 > ""100% fun every day, all day"" so we reassure parents and let them relax while the kids have fun with our animation team."
<G-vec00535-001-s021><reassure.beruhigen><de> "Um diese krank, sogar in den Sechzigern, Es war eine Atmosphäre von großer Spannung und Schmerz, von seiner Frau und zwei Töchtern; und während der Diakon zu erklären versuchte, dass er es nicht konnte... der Onkologe sagte ihm, diese ""Blick auf den Zustand des Patienten und die Menschen und unabhängig von Strom oder kein Strom, beruhigen sie und erhellen sie""."
<G-vec00535-001-s021><reassure.beruhigen><en> "Around that sick, even in his sixties, There was an atmosphere of great tension and pain, by his wife and two daughters; and while the deacon was trying to explain that he could not... the oncologist told him this ""look at the state of the patient and the people and regardless of power or no power, reassure them and brighten them""."
<G-vec00535-001-s022><reassure.beruhigen><de> Um die Imperialisten zu beruhigen, versprach die Regierung keine ausländischen Investitionen anzugreifen, obwohl Chávez laut Richard Gott sich bemühte, jede persönliche Verantwortung für diese Maßnahme zu vermeiden, dadurch dass er sich zum Zeitpunkt der Verkündung außer Landes befand.
<G-vec00535-001-s022><reassure.beruhigen><en> To reassure the imperialists, the government pledged not to touch any foreign investments, although, according to Gott, Chávez sought to avoid personal responsibility for this measure by arranging to be out of the country when it was announced.
<G-vec00535-001-s023><reassure.beruhigen><de> In dieser Zeit der turbulenten Geopolitik ist ein gemeinsames europäisches Vorgehen erforderlich, damit die Europäische Union ihre wirtschaftliche Erholung stärken und ihre Bürger im Hinblick auf ihre Lebensperspektiven und Arbeitsbedingungen beruhigen kann.
<G-vec00535-001-s023><reassure.beruhigen><en> """In these times of turbulent geopolitics, a common European course of action is needed for Europe to strengthen its economic recovery and reassure citizens about their life prospects and working conditions."
<G-vec00535-001-s024><reassure.beruhigen><de> Sie blickte zurück zur Mutter, deren Zornesfalten sich bereits wieder glätteten, und die versuchte, ihr weinendes Kind zu beruhigen.
<G-vec00535-001-s024><reassure.beruhigen><en> She looked back to the mother, that angry face already softening and seeking to reassure her wailing child.
<G-vec00535-001-s025><reassure.beruhigen><de> Sie wären glaubwürdiger, würden sie sich bemühen, gleichzeitig Russland sowie die baltischen Länder und Polen zu beruhigen.
<G-vec00535-001-s025><reassure.beruhigen><en> They would be more credible if they tried to reassure Russia at the same time as they reassure Poland and the Baltic states.
<G-vec00535-001-s026><reassure.beruhigen><de> HUDLIB, der beruhigen will, sagt, wir sollten uns glücklich schätzen, eine zweite Chance zu bekommen, eine Anspielung auf das Seminar, in dem wir als Material (als Versuchskaninchen vor allem) für alle möglichen literarischen und bildhauerischen Experimente unter der Leitung dieses oulipotischen, borgesianischen und schrulligen Künstlers dienen, der mit großem Pomp angekündigt wurde und der sein Amt vor einer Woche angetreten hat.
<G-vec00535-001-s026><reassure.beruhigen><en> AUHDB, wanting to reassure, says that we should consider our­selves fortunate to have a second chance, an allusion to this workshop where we act as material (guinea pigs most of all) for all kinds of literary and artistic experimentations under the supervision of this Oulipian, Borgesian, and whimsical artist announced with great pomp, and who took up his post a week ago.
<G-vec00535-001-s027><reassure.beruhigen><de> B«Aber diese in keiner Weise bedeutet, dass die Krankheit hat sich in Moskau, aufgrund der schlechten QualitГ¤t ErfrischungsgetrГ¤nke Rzhevskogo UnternehmenB« Rzhevpivo B», - eilte zu beruhigen Moskau Onyshchenko.
<G-vec00535-001-s027><reassure.beruhigen><en> B«But this in no way means that the disease has spread to Moscow, due to poor quality soft drinks Rzhevskogo enterpriseB« Rzhevpivo B», - hastened to reassure Moscow Onyshchenko.
<G-vec00535-001-s028><reassure.beruhigen><de> Die Person beruhigen und ihr dabei helfen, sich zu entspannen.
<G-vec00535-001-s028><reassure.beruhigen><en> Reassure the person and help her relax.
<G-vec00535-001-s029><reassure.beruhigen><de> Die laufenden Bemühungen suchen Abhilfen Datenschützern zu beruhigen, während die Fähigkeit, für die richtige Emoji-Rendering Fähigkeit zu überprüfen Halte.
<G-vec00535-001-s029><reassure.beruhigen><en> Ongoing efforts seek workarounds to reassure privacy advocates while retaining the ability to check for proper emoji rendering capability.
<G-vec00535-001-s030><reassure.beruhigen><de> Orpheus versucht Hercules zu beruhigen.
<G-vec00535-001-s030><reassure.beruhigen><en> Orpheus tries to reassure Hercules.
<G-vec00535-001-s031><reassure.beruhigen><de> Ebenso obligatorisch war die Einbeziehung einer Option zum Deaktivieren der Funktion SICHERES BOOTEN Soll beruhigen Nutzer besorgt, dass es vielleicht mit stecken Windows-8 .
<G-vec00535-001-s031><reassure.beruhigen><en> Equally obligatory was the inclusion of an option to disable the function Secure Boot Meant to reassure worried that users might get stuck with Windows 8 .
<G-vec00535-001-s032><reassure.beruhigen><de> Ich kam aus dem Wasser zu ihm, dass meine Arme und Beine flattern beruhigen, nicht flailingIch machte die Bewegungen auf dem Land, wie eine Verrückte, dass wenn ich schwamm fast aus den Augen, Ich würde auf dem Festland und zu ihm zurückkehren: Ich werde dich nie verlassen.
<G-vec00535-001-s032><reassure.beruhigen><en> I came out of the water to reassure him that my arms and legs were fluttering, not flailingI made the motions on land, like a madwoman that though I swam nearly out of his sight, I would return to terra firma and to him: I will never leave you.
<G-vec00535-001-s033><reassure.beruhigen><de> Bachblüten RESCUE SPRAY Komfort und Beruhigen: Sprayflasche gefärbt mit...
<G-vec00535-001-s033><reassure.beruhigen><en> Bach Flowers RESCUE SPRAY Comfort and Reassure: Tinted Spray Bottle with...
<G-vec00535-001-s034><reassure.beruhigen><de> Zu Beginn gab es eine Menge Arbeit, die wir leisten mussten, um die Leute hinsichtlich dessen, was wir zu tun versuchten, zu beruhigen: Dass sie zum Beispiel nicht in [rechtliche] Schwierigkeiten kommen würden, dass es Möglichkeiten geben würde, den Leuten Kontrolle über ihre Geschichten zu geben.
<G-vec00535-001-s034><reassure.beruhigen><en> In the beginning there was a lot of work we had to do to reassure people about what we were trying to do, such as that they weren't going to get into [legal] trouble, that there would be ways to give people control over their stories.
<G-vec00535-001-s035><reassure.beruhigen><de> Ich hatte den Eindruck dass dieser Ort als Empfang für Kinder oder junge Personen diente, und dass diese Umgebung 'gebaut' wurde um sie zu beruhigen und zu beschwichtigen.
<G-vec00535-001-s035><reassure.beruhigen><en> I had the sensation that this place was used as a place of welcoming for children or young people and that this environment had been built to reassure and appease them.
<G-vec00535-001-s036><reassure.beruhigen><de> Wenn wir allerdings immer nur beruhigen wollen, wird Beschwichtigen zur Gewohnheit.
<G-vec00535-001-s036><reassure.beruhigen><en> But if all we do is reassure, soothing becomes a habit.
<G-vec00535-001-s037><reassure.beruhigen><de> In jedem Fall ist eine ärztliche Untersuchung ratsam, entweder, um den Patienten zu beruhigen oder um eine nötige Therapie einzuleiten.
<G-vec00535-001-s037><reassure.beruhigen><en> In all cases, a medical examination is advisable, either to reassure the patient or to start some treatment if necessary.
<G-vec00535-001-s038><reassure.beruhigen><de> Beruhigen Sie Beruhigen Sie den Schüler dass der Gewaltvorfall/Aggression nicht durch seine Schuld vorkam.
<G-vec00535-001-s038><reassure.beruhigen><en> Reassure Reassure the student that the abuse/assault is not her/his fault.
<G-vec00535-001-s039><reassure.beruhigen><de> Sobald sie ein Geräusch hören, das einem Flugzeug ähnelt, müssen wir sie beruhigen und ihnen versichern, dass sie nicht in Gefahr sind.
<G-vec00535-001-s039><reassure.beruhigen><en> As soon as they hear a noise like that of a plane, we have to reassure them and tell them they are not in danger.
<G-vec00535-001-s040><reassure.beruhigen><de> Zum Glück sehe ich zwei Italiener, FAO tätig, beruhigen, was mir und ich garantiere wird mit nach Hause nehmen.
<G-vec00535-001-s040><reassure.beruhigen><en> Luckily I see two Italians, working for FAO, reassure me and I guarantee you will take home.
<G-vec00535-001-s041><reassure.beruhigen><de> Mit Blickkontakt können Sie Ihren Gesprächspartner beruhigenund Ihr Interesse zeigen.
<G-vec00535-001-s041><reassure.beruhigen><en> You can reassure your conversation partner with eye contact, show him that you are interested.
<G-vec00535-001-s042><reassure.beruhigen><de> Beruhigt und kontrolliert die soziale Orientierung der Einrichtungen, in denen Hat nicht bestanden aus sozialem Ausschuß.
<G-vec00535-001-s042><reassure.beruhigen><en> Reassure and controls the social orientation of the establishments in which A did not consist of social Committee.
<G-vec00535-001-s043><reassure.beruhigen><de> Während sich der Mensch beruhigt, wirkt die Natur trügerisch im Stillen.
<G-vec00535-001-s043><reassure.beruhigen><en> Whilst the humans reassure themselves, deceptive nature works quietly.
<G-vec00535-001-s044><reassure.beruhigen><de> Wenn er verärgert ist, beruhigt sie ihn mit ihrem Schnurren.
<G-vec00535-001-s044><reassure.beruhigen><en> If he is upset, then she will reassure him with her purr.
<G-vec00535-001-s045><reassure.beruhigen><de> Wenn nach all dies geschah, sah das Kind eine Szene, die Gewalt oder was enthält - oder Katastrophe, hug Brösel, beruhigt ihn sanft.
<G-vec00535-001-s045><reassure.beruhigen><en> If after all this happened, the child saw a scene that contains violence or what - or catastrophe, hug crumbs, gently reassure him.
<G-vec00535-001-s059><reassure.beruhigen><de> Sie sangen, um die Bürger damit zu beruhigen, dass Wacht gehalten wurde, aber auch, weil nur die wenigsten Personen damals eine Uhr besaßen.
<G-vec00535-001-s059><reassure.beruhigen><en> He sang to reassure the citizens that he was keeping watch, but also because very few people had a watch at that time.
<G-vec00535-001-s060><reassure.beruhigen><de> """Diese Gefängnisse sind sowieso wie Studentenwohnheime"", sagt er und versucht damit offensichtlich, mindestens einen von uns zu beruhigen."
<G-vec00535-001-s060><reassure.beruhigen><en> """These prisons, by the way, are like dorms,"" he says, evidently trying to reassure at least one of us."
<G-vec00535-001-s064><reassure.beruhigen><de> „Für Christen gibt es im Norden Nigerias noch immer keine Entwarnung, selbst wenn Armee und Politiker sich bemühen, die Zivilbevölkerung zu beruhigen und eine baldige Zerschlagung Boko Harams in Aussicht stellen“, kritisierte der GfbV-Afrikareferent Ulrich Delius.
<G-vec00535-001-s064><reassure.beruhigen><en> """The Christian population in northern Nigeria is still not safe, even if the army and politicians are trying to reassure the civilian population by promising to break up Boko Haram soon,"" criticized the STP's Africa-consultant, Ulrich Delius."
<G-vec00535-001-s084><reassure.beruhigen><de> Ich konnte sie jedoch beruhigen.
<G-vec00535-001-s084><reassure.beruhigen><en> I was able to reassure her.
<G-vec00535-001-s095><reassure.beruhigen><de> Augenblicklich geriethen die Passagiere in großen Schrecken; aber der Kapitän Anderson war im Stande sie unverzüglich zu beruhigen.
<G-vec00535-001-s095><reassure.beruhigen><en> At first the passengers were quite frightened, but Captain Anderson hastened to reassure them.
<G-vec00535-001-s097><reassure.beruhigen><de> "Bei jeder Prophet (salla Allahu alihi wa salam) würde sie zu tröstenmit Worten der Zärtlichkeit und beruhigen sie und sagte: ""Töchterchen Weine nicht, Allah wird deinen Vater zu schützen"", und küsste sie, während er trocknet sich die Tränen von ihrem süßen kleinen Gesicht."
<G-vec00535-001-s097><reassure.beruhigen><en> "On each occasion the Prophet (salla Allahu alihi wa sallam) would comfort her with words of tenderness and reassure her saying, ""Do not cry little daughter, Allah will protect your father,"" and kissed her as he dried away the tears from her darling little face."
<G-vec00535-001-s103><reassure.beruhigen><de> Es handelt sich um eine symbolische Aktion, um alle zu beruhigen, die daran zweifeln, dass Deutschlands Gold noch vorhanden ist.
<G-vec00535-001-s103><reassure.beruhigen><en> It is a symbolic act to reassure all sceptics who doubt that Germany's gold is still there.
<G-vec00535-001-s104><reassure.beruhigen><de> Es handelt sich um eine symbolische Aktion, um alle zu beruhigen, die daran zweifeln, dass Deutschlands Gold noch vorhanden ist.
<G-vec00535-001-s104><reassure.beruhigen><en> It is a symbolic act to reassure all sceptics who doubt that Germany’s gold is still there.
<G-vec00535-001-s105><reassure.beruhigen><de> Ich bemerkte im zweiten Fall, daß Gott ihnen gewährt, um ähnliche Seelen zu fahren und beruhigen, obwohl das Herr kann diese Anmut gewähren, wie Es gefällt und zu derjenige Es gefällt.
<G-vec00535-001-s105><reassure.beruhigen><en> In the second case I have noticed that God grants her/it to drive and to reassure similar souls, although the Lord can grant this grace as He likes and to whom likes Him.
<G-vec00535-001-s139><reassure.beruhigen><de> Die britische Regierung ist bemüht, Goldman Sachs, Morgan Stanley und die anderen Wall-Street-Namen zu beruhigen, dass sie weiterhin in der Lage sein werden, in London zu operieren, während europäische Führer die Gelegenheit sehen, Arbeitsplätze zu stehlen.
<G-vec00535-001-s139><reassure.beruhigen><en> The UK government is keen to reassure Goldman Sachs, Morgan Stanley, and the other Wall Street names that they'll still be able to operate in the London, while European leaders see the opportunity to steal jobs.
