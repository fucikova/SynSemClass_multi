<G-vec00372-002-s021><tarnish.anlaufen><de> Ein Anlaufen des Laufrades wird so verhindert, es entsteht nur Flüssigkeitsreibung und dadurch ein guter Wirkungsgrad.
<G-vec00372-002-s021><tarnish.anlaufen><en> This prevents a tarnish of the open impeller, it only arises fluid friction and thereby a good efficiency.
<G-vec00372-002-s022><tarnish.anlaufen><de> Benutzen Sie Flamex PA nicht für Metallic-Farben, da die Metallpigmente reagieren und anlaufen oder korrodieren können.
<G-vec00372-002-s022><tarnish.anlaufen><en> Do not use Flamex PA with metallic paints as the metal pigments may react and tarnish or corrode.
<G-vec00372-002-s023><tarnish.anlaufen><de> Sehr nützliches Zubehör für die Lagerung von Schmuckteilen aus Silber, Kupfer oder Messing, sowie allen platierten Materialien, die leicht anlaufen können.
<G-vec00372-002-s023><tarnish.anlaufen><en> Very useful tool for storage of jewelries made of silver, copper or brass and all plated materials that can easily tarnish.
<G-vec00372-002-s024><tarnish.anlaufen><de> Mit der Zeit und dem Verschleiß wird Bronze natürlich anlaufen, aber eine PU-Beschichtung kann hinzugefügt werden, um den Prozess zu verlangsamen.
<G-vec00372-002-s024><tarnish.anlaufen><en> With time and wear, bronze will naturally tarnish but a PU coating can be added to slow down the process
<G-vec00372-002-s025><tarnish.anlaufen><de> Wegen der hohen Reaktivität von Silber (Anlaufen) ist die Konservierung der metallischen Oberflächen von besonderer Bedeutung.
<G-vec00372-002-s025><tarnish.anlaufen><en> Due to the high reactivity of silver (tarnish) the preservation of the metallic surfaces is of particular importance.
<G-vec00372-002-s026><tarnish.anlaufen><de> Das Material aus rostfreiem Edelstahl, unter dem Namen Cromargan® bekannt gemacht, kann nicht anlaufen, es ist rostfrei, säurebeständig, unzerbrechlich, pflegeleicht und damit äußerst langlebig.
<G-vec00372-002-s026><tarnish.anlaufen><en> The material, which is known by the name Cromargan®, cannot tarnish, is rustproof, acid-resistant, unbreakable, easy to clean and so is extremely durable.
