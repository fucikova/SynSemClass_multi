<G-vec00599-002-s019><disintegrate.aufschließen><de> Sie wollen Biomasse aufschließen.
<G-vec00599-002-s019><disintegrate.aufschließen><en> You want to disintegrate biomass.
