<G-vec00510-002-s097><sprout_up.austreiben><de> An der Basis können zahlreiche Seitensprossen austreiben und neue "Köpfe" bilden.
<G-vec00510-002-s097><sprout_up.austreiben><en> At the base of the cactus, numerous side shoots can sprout and form new "heads".
<G-vec00555-002-s041><expel.austreiben><de> 10 Er rief also seine zwölf Jünger zu sich und gab ihnen Macht über böse* Geister,+ sodass sie sie austreiben und alle möglichen Krankheiten und Leiden heilen konnten.
<G-vec00555-002-s041><expel.austreiben><en> 10 So he summoned his 12 disciples and gave them authority over unclean spirits,+ in order to expel these and to cure every sort of disease and every sort of infirmity.
