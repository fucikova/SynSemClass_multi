<G-vec00092-001-s019><enforce.aufzwingen><de> Für unsere Vorstellung ist es von hier aus nur noch ein kleiner Schritt zu einem Organ, das einem zweiten Gehirn eine Veränderung aufzwingen kann.
<G-vec00092-001-s019><enforce.aufzwingen><en> Starting from here, for our imagination it's only a small step towards an organ, that can enforce a change onto a second brain.
<G-vec00092-001-s020><enforce.aufzwingen><de> Wir möchten auch niemandem unsere Meinung aufzwingen, eher lieber zur einer gesunden Diskussion einladen und zu ein paar Gedanken anregen.
<G-vec00092-001-s020><enforce.aufzwingen><en> I don't want to enforce my opinion to someone, but invite them into a healthy discussion and to get some interesting views and thoughts.
<G-vec00092-001-s021><enforce.aufzwingen><de> Die Welt ist im Orwellischen Staat angekommen, wo nur wenige ihren Willen allen anderen aufzwingen.
<G-vec00092-001-s021><enforce.aufzwingen><en> The world has arrived into the Orwellian State where few enforce their will on everyone else.
<G-vec00092-001-s022><enforce.aufzwingen><de> Anstatt ihren Willen Hunderten von Individuen aufzwingen zu müssen, müssen sie ihn nur denen aufzwingen, die die Parteien kontrollieren, und sie würden ihn wiederum ihren Mitgliedern aufzwingen.
<G-vec00092-001-s022><enforce.aufzwingen><en> Instead of having to force their will upon hundreds of individuals, all they had to do was force it upon those who controlled the parties and they, in turn, would enforce it upon their members.
<G-vec00092-001-s023><enforce.aufzwingen><de> Jeder Bitcoin-Client, der sich nicht an die Regeln hält, kann seine eigenen Regeln nicht einfach anderen Nutzern aufzwingen.
<G-vec00092-001-s023><enforce.aufzwingen><en> Any Bitcoin client that doesn't comply with the same rules cannot enforce their own rules on other users.
<G-vec00179-001-s019><enforce.aufzwingen><de> Für unsere Vorstellung ist es von hier aus nur noch ein kleiner Schritt zu einem Organ, das einem zweiten Gehirn eine Veränderung aufzwingen kann.
<G-vec00179-001-s019><enforce.aufzwingen><en> Starting from here, for our imagination it's only a small step towards an organ, that can enforce a change onto a second brain.
<G-vec00179-001-s020><enforce.aufzwingen><de> Wir möchten auch niemandem unsere Meinung aufzwingen, eher lieber zur einer gesunden Diskussion einladen und zu ein paar Gedanken anregen.
<G-vec00179-001-s020><enforce.aufzwingen><en> I don't want to enforce my opinion to someone, but invite them into a healthy discussion and to get some interesting views and thoughts.
<G-vec00179-001-s021><enforce.aufzwingen><de> Die Welt ist im Orwellischen Staat angekommen, wo nur wenige ihren Willen allen anderen aufzwingen.
<G-vec00179-001-s021><enforce.aufzwingen><en> The world has arrived into the Orwellian State where few enforce their will on everyone else.
<G-vec00179-001-s022><enforce.aufzwingen><de> Anstatt ihren Willen Hunderten von Individuen aufzwingen zu müssen, müssen sie ihn nur denen aufzwingen, die die Parteien kontrollieren, und sie würden ihn wiederum ihren Mitgliedern aufzwingen.
<G-vec00179-001-s022><enforce.aufzwingen><en> Instead of having to force their will upon hundreds of individuals, all they had to do was force it upon those who controlled the parties and they, in turn, would enforce it upon their members.
<G-vec00179-001-s023><enforce.aufzwingen><de> Jeder Bitcoin-Client, der sich nicht an die Regeln hält, kann seine eigenen Regeln nicht einfach anderen Nutzern aufzwingen.
<G-vec00179-001-s023><enforce.aufzwingen><en> Any Bitcoin client that doesn't comply with the same rules cannot enforce their own rules on other users.
