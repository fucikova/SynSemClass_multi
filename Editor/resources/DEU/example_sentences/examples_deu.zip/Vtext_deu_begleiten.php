<G-vec00407-001-s019><accompany.begleiten><de> Ich begleite euch so, wie ich nun einmal bin, ich folge dem Gefühl.
<G-vec00407-001-s019><accompany.begleiten><en> I accompany you thus as I am, as I feel.
<G-vec00407-001-s020><accompany.begleiten><de> Die allerseligste Jungfrau begleite euch und lasse euch wachsen in der Treue zu eurer Sendung in der Kirche.
<G-vec00407-001-s020><accompany.begleiten><en> May the Blessed Virgin accompany you and make you ever more faithful to your mission in the Church.
<G-vec00407-001-s021><accompany.begleiten><de> Ich begleite Sie bei jedem Schritt Ihrer Behandlung bei uns: Angefangen beim Erstgespräch, in dem wir all Ihre Fragen klären, über die einzelnen Schritte Ihrer individuellen Therapie bis zur Schwangerschaft.
<G-vec00407-001-s021><accompany.begleiten><en> I will accompany you through every step of your treatment with us: beginning with the initial consultation, where we clarity all your questions, to the individual steps of your personal therapy, through to pregnancy.
<G-vec00407-001-s022><accompany.begleiten><de> "Ich fühle mich als Begleiter und daher begleite ich in der Grundbedeutung des Wortes (""und immer begleitet etwas Furcht die Liebe"", Britannicus, V/3), sowie die große konstruktivistische Fiktion, den Mythos der Goldquelle als auch die Romanze, die Hymne auf die Moderne und den Beziehungsarchaismus."
<G-vec00407-001-s022><accompany.begleiten><en> "I feel like a companion and therefore I accompany, in the literal sense (""and always some fear accompanies love"", Britannicus, Racine, v. 3). The great constructivist fiction, the myth of the source of gold as much as the romance. The hymn to modernity, and relational archaism."
<G-vec00407-001-s023><accompany.begleiten><de> Die Mutter Christi begleite immer und überall die Verkündigung des Evangeliums, auf daß sich in der Welt die Räume mehren und weiten, in denen die Menschen die Freude eines Lebens als Kinder Gottes wiederfinden.
<G-vec00407-001-s023><accompany.begleiten><en> May Christ’s Mother accompany the proclamation of the Gospel always and everywhere, so that the places where men rediscover the joy of living as children of God will multiply and spread in the world.
<G-vec00407-001-s024><accompany.begleiten><de> Normalerweise begleite ich ihn nicht zur Schule, doch diese Woche regnete es heftig, unter Blitz und Donner.
<G-vec00407-001-s024><accompany.begleiten><en> I don't usually accompany him to school, but that week it was raining heavily with thunder and lightning.
<G-vec00407-001-s025><accompany.begleiten><de> Hinweis: Bei einigen Abfahrten ist es aus Sicherheitsgründen notwendig, dass ich Sie mit Skis begleite, denn nur mit Skis ist es mir möglich, jederzeit schnell Hilfestellung zu leisten.
<G-vec00407-001-s025><accompany.begleiten><en> Notice: On certain descents it's necessary that I accompany you with skis for safety reasons, only with skis it's possible to give you quick assistance at any time.
<G-vec00407-001-s026><accompany.begleiten><de> Sie stütze und begleite uns in diesem neuen Jahr;sie erlange für uns und für die ganze Welt das ersehnte Geschenk des Friedens.
<G-vec00407-001-s026><accompany.begleiten><en> May she support and accompany us in this new year; may she obtain for us and for the whole world the desired gift of peace!
<G-vec00407-001-s027><accompany.begleiten><de> Der Herr begleite euch stets mit seiner Gnade und geleite euch in eurem künftigen Leben.
<G-vec00407-001-s027><accompany.begleiten><en> May the Lord accompany you always with his Grace and guide you in your future lives.
<G-vec00407-001-s028><accompany.begleiten><de> Ich begleite diesen Wunsch mit der Zusicherung meines steten Gebetsgedenkens und segne alle von Herzen.
<G-vec00407-001-s028><accompany.begleiten><en> I accompany these wishes with the assurance of my prayerful remembrance, and I bless you all with affection.
<G-vec00407-001-s029><accompany.begleiten><de> Für das Wohlergehen der ganzen Bevölkerung spreche ich meine herzlichsten Wünsche aus, die ich mit einem besonderen Apostolischen Segen begleite, bekräftigt durch das Gebet für Sie, für die Autoritäten, für Ihre Lieben und für alle Bürger Ihrer geschätzten Nation.
<G-vec00407-001-s029><accompany.begleiten><en> I express fervent good wishes for the well-being of the entire population, which I accompany with a special Apostolic Blessing strengthened by prayer for you, for the Authorities, for your loved ones and for all the citizens of your illustrious Nation.
<G-vec00407-001-s030><accompany.begleiten><de> Der Herr begleite euch.
<G-vec00407-001-s030><accompany.begleiten><en> May the Lord accompany you.
<G-vec00407-001-s031><accompany.begleiten><de> Das ist mein Wunsch, den ich an Sie richten möchte und den ich mit meinem Gebet begleite, damit der Akademie der Sozialwissenschaften niemals die lebenspendende Hilfe des Heiligen Geistes fehlen möge.
<G-vec00407-001-s031><accompany.begleiten><en> This is the hope I address to you, and accompany with my prayer so that the Academy of Social Sciences may never lack the life-giving aid of the Spirit.
<G-vec00407-001-s032><accompany.begleiten><de> Es begleite uns der Apostel Paulus, es geleite uns Maria, die aufmerksame Jungfrau des Hörens und demütige Magd des Herrn.
<G-vec00407-001-s032><accompany.begleiten><en> May the Apostle Paul accompany us; may Mary, the attentive Virgin of listening and the humble Handmaid of the Lord guide us.
<G-vec00407-001-s033><accompany.begleiten><de> Nach dem Kurs begleite ich meine Massage-Mitschülerin Carla ins Hippie-Café nebenan.
<G-vec00407-001-s033><accompany.begleiten><en> After the course, I accompany fellow massage student Carla to the hippy café next door.
<G-vec00407-001-s034><accompany.begleiten><de> Ich begleite Sie auch.
<G-vec00407-001-s034><accompany.begleiten><en> I shall also accompany you.
<G-vec00407-001-s035><accompany.begleiten><de> Es begleite euch die Jungfrau Maria, die Mutter Christi.
<G-vec00407-001-s035><accompany.begleiten><en> May the Virgin Mother of Christ accompany you.
<G-vec00407-001-s036><accompany.begleiten><de> Begleite deinen Avatar im MMOG Lagoonia bei seinen ersten Schritten auf deiner Südseeinsel.
<G-vec00407-001-s036><accompany.begleiten><en> Accompany your avatar through the MMOG Lagoonia as you take your first steps on the tropical island.
<G-vec00407-001-s037><accompany.begleiten><de> Es begleite sie mit ihrer mütterlichen Sorge die allerseligste Jungfrau und öffne ihnen die Tore des Paradieses.
<G-vec00407-001-s037><accompany.begleiten><en> May the Blessed Virgin, with her maternal care, accompany them and open to them the gates of Paradise.
<G-vec00042-001-s133><join.begleiten><de> Storm Chasers: Tornado Islands Begleite Alex, Ihren Freund Professor Finch und ihren treuen Hund Muffin in einem exotischen Match 3-Abenteuer.
<G-vec00042-001-s133><join.begleiten><en> Storm Chasers: Tornado Islands Join Alex, her friend Professor Finch, and her faithful dog Muffin in an exotic Match 3 adventure.
<G-vec00042-001-s134><join.begleiten><de> Begleite den unglaublichen Gitarristen, Rainbow Ryan und schaue zu, wie er die Bühne rockt.
<G-vec00042-001-s134><join.begleiten><en> Join the amazing guitarist, Rainbow Ryan and watch him rock the stage.
<G-vec00042-001-s135><join.begleiten><de> Begleite uns; der Platz ist begrenzt.
<G-vec00042-001-s135><join.begleiten><en> Join us; space is limited.
<G-vec00042-001-s136><join.begleiten><de> Begleite sie auf einer Sexreise, die jeden Beteiligten live auf XXX Webcams zum Orgasmus bringt.
<G-vec00042-001-s136><join.begleiten><en> Join them on a sex journey that is bound to bring everyone involved to orgasm live on xxx webcams.
<G-vec00042-001-s137><join.begleiten><de> Begleite uns zu einem epischen Event mit praxisnahen Einblicken der weltweit führenden Marketing- und Optimierungsexperten.
<G-vec00042-001-s137><join.begleiten><en> Join us for an epic event with actionable insights from the world's leading marketing and optimization experts.
<G-vec00042-001-s138><join.begleiten><de> Agatha Christie: Dead Man's Folly Begleite den Detektiv Hercule Poirot und nimm an einer Scharade teil, die die perfekte Tarnung für ein perfektes Verbrechen sein könnte.
<G-vec00042-001-s138><join.begleiten><en> Agatha Christie: Dead Man's Folly Join detective Hercule Poirot as you take part in a charade that could be the perfect disguise for a despicable scheme.
<G-vec00042-001-s139><join.begleiten><de> Begleite unsere Charaktere und entdecke verschiedene Geschäfte und Aktivitäten.
<G-vec00042-001-s139><join.begleiten><en> Join our characters and explore various shops and activities within.
<G-vec00042-001-s140><join.begleiten><de> Begleite in diesem traditionellen Slot mit 3 Walzen und 9 Gewinnlinien, chinesische Helden.
<G-vec00042-001-s140><join.begleiten><en> Join the legendary Chinese heroes in this traditional 3-reeled slot with 9 paylines.
<G-vec00042-001-s141><join.begleiten><de> Begleite ihn und erlebe ein Abenteuer im zentralamerikanischen Dschungel mit Gonzo's QuestTM - einer der besten klassischen Slots von NetEnt.
<G-vec00042-001-s141><join.begleiten><en> Join him and experience an adventure in the central American jungles, with Gonzo's QuestTM - one of NetEnt's all-time classic slots.
<G-vec00042-001-s142><join.begleiten><de> Begleite Tako Sensei in diesem Kanji-Spiel, in dem du lernen wirst, Japanisch zu schreiben und zu lesen.
<G-vec00042-001-s142><join.begleiten><en> Join Tako Sensei in this kanji game in which you'll learn to write and read Japanese.
<G-vec00042-001-s143><join.begleiten><de> Begleite uns auf eine Reise durch die atemberaubende Winterlandschaft der Olympiaregion Seefeld mit den fÃ1⁄4nf Orten: Seefeld, Leutasch, Mösern-Buchen, Reith und Scharnitz.
<G-vec00042-001-s143><join.begleiten><en> Join us on a journey through the breathtaking winter landscape of the Olympiaregion Seefeld, with the five places: Seefeld, Leutasch, Mösern-Buchen, Reith and Scharnitz.
<G-vec00042-001-s144><join.begleiten><de> Begleite ihn auf einer wilden Reise durch die Zeit und finde die Teile einer Zeitbombe, um das Zeitportal zu schießen, bevor es zu spät ist.
<G-vec00042-001-s144><join.begleiten><en> Join Mortimer for a wild trip through time to find a scattered time bomb, put it back together, and close the time portal before it's too late.
<G-vec00042-001-s145><join.begleiten><de> Begleite die geliebten charaktere Elsa und Olaf in das Abenteuer auf dem markt von Elsa.
<G-vec00042-001-s145><join.begleiten><en> Join the beloved characters Elsa and Olaf in the Adventure to the market of Elsa.
<G-vec00042-001-s146><join.begleiten><de> Begleite die Archäologin Jess auf eine tropische Insel, die von einer Vulkanexplosion schwer verwüstet wurde.
<G-vec00042-001-s146><join.begleiten><en> Join archaeologist Jess as she travels to a tropical island decimated by a volcanic eruption.
<G-vec00042-001-s147><join.begleiten><de> Begleite den Pharaoh auf seinen atemberaubenden Reisen.
<G-vec00042-001-s147><join.begleiten><en> Join the Pharaoh on his breathtaking journey.
<G-vec00042-001-s148><join.begleiten><de> Begleite Mickey Mouse und Minnie Mouse durch einen inspirierenden Spaziergang durch die Vergangenheit um Magie und Familienspaß zu garantieren.
<G-vec00042-001-s148><join.begleiten><en> Join Mickey Mouse and Minnie Mouse on an inspiring walk down memory lane in celebration of magic and family fun.
<G-vec00042-001-s149><join.begleiten><de> Begleite Alex Mason und entdecke, was seine Erinnerungen parat haben.
<G-vec00042-001-s149><join.begleiten><en> Join Alex Mason and discover what his memories hold.
<G-vec00042-001-s150><join.begleiten><de> "Begleite ""Bloody Harry"" bei seine..."
<G-vec00042-001-s150><join.begleiten><en> "Join ""Bloody Harry"" on his hunt..."
<G-vec00042-001-s151><join.begleiten><de> Begleite die Hobbits auf ihrer Reise, entweder nach Neuseeland oder unserer Produktkategorie.
<G-vec00042-001-s151><join.begleiten><en> Join the Hobbits on their journey, either to New Zealand or our product category.
<G-vec00407-001-s038><accompany.begleiten><de> In CivCity: Rom, einer durch die renommierte Civilization-Reihe von Sid Meier inspirierten Simulation, sind Sie ganz persönlich der Herrscher über eine römische Stadt, die Sie von ihren bescheidenen Anfängen zu einer Glanzzeit voller Ruhm und Ehre begleiten werden.
<G-vec00407-001-s038><accompany.begleiten><en> In CivCity: Rome, a simulation inspired by Sid Meier's renowned Civilization series, you personally are the ruler of a Roman city, which you will accompany from its humble beginnings to a heyday filled with honour and glory.
<G-vec00407-001-s039><accompany.begleiten><de> Details verraten die Zeitebenen: Anhaltspunkte in Ferdls Welt sind Wahlplakate und Gespräche über Waldheim, in den Kapiteln, die von Anni handeln, wird mit „Heil Hitler“ gegrüßt, und Karl begleiten wir auf der Flucht nach Südamerika.
<G-vec00407-001-s039><accompany.begleiten><en> In Ferdl’s world, there are revealing campaign posters and conversations about Waldheim, Austria’s president in the late ’80s and early ’90s; the characters in Anni’s chapters greet one another with “Heil Hitler”; and we accompany Karl on his escape to South America.
<G-vec00407-001-s040><accompany.begleiten><de> Es ist nicht nur eine Frage der Kauf von Geräten, sondern ein Geschäftspartner, der die Kunden über die gesamte Länge des Projekts zu liefern ihnen eine maßgeschneiderte Lösung kann zu begleiten.
<G-vec00407-001-s040><accompany.begleiten><en> It is not just a question of buying equipment, but rather a business partner that can accompany the customers along the whole length of the project to deliver them a customized solution.
<G-vec00407-001-s041><accompany.begleiten><de> 1961 hatte Winfried Junge eine Idee des Dokumentaristen Karl Gass aufgegriffen: Eine Schulklasse sollte gedreht werden, mit der Vision, diese Kinder mit der Kamera durchs Leben zu begleiten.
<G-vec00407-001-s041><accompany.begleiten><en> In 1961, Winfried Junge took up the idea and vision of documentary filmmaker Karl Gass to make a film about a school class and to accompany the childrenÂ’s life with the camera.
<G-vec00407-001-s042><accompany.begleiten><de> Alles ausgezeichnet, von gemütlich, gepflegt, sauber und den rechtzeitigen Austausch von dem Zeug jeden Morgen; ausgezeichnetes Abendessen, die alle sehr gut km0 ohne viel; schöne Lage zwischen den Olivenhain, das Unternehmen und die Aussicht auf die Berge der Umgebung; tolles Personal, immer zur Verfügung, um uns zu begleiten und kommen und von den lokalen bis Stadtzentrum nehmen, die alle sehr freundlich und immer mit einem Lächeln (Erzeugnis in seiner eigenen Presse, eine köstliche Zitrone gewürzt Olivenöl); gut genug, um die Gesamtkosten für den Service.
<G-vec00407-001-s042><accompany.begleiten><en> All the best, starting from the welcoming, well maintained, clean rooms and with the replacement of timely stuff each morning; Great dinner, very good at km0 without spending much; A splendid location between the olive grove, the farm and the landscape around the mountains; Impeccable staff, always available to accompany us and come and pick us up from the restaurant to the center of town, very kind and always with the smile (they produce in their own oil mill, a very good lemon flavored olive oil); Fairly good total cost for the service offered.
<G-vec00407-001-s043><accompany.begleiten><de> Im Rahmen eines touristischen Plans freuen wir uns, Firmen und Privatpersonen auf einer Führung durch den Keller und Lagerung Keller, Weinberge und Gärten der Herdade das Servas zu begleiten.
<G-vec00407-001-s043><accompany.begleiten><en> As part of a tourism plan, we are delighted to accompany companies and private individuals on a guided tour of the cellar and storage basement, vineyards and gardens of the Herdade das Servas.
<G-vec00407-001-s044><accompany.begleiten><de> Seine kleinen Rahmen–28.fünfundsiebzig von fünf 26.seventy x 25 Zoll – ist mit 9,5-Zoll-Fest installiert, nie-Flach Räder und ein Klapp verwalten, so kann es einfach begleiten Sie, wohin Sie gehen.
<G-vec00407-001-s044><accompany.begleiten><en> Its small frame–28.seventy five by 26.seventy five x 25 inches – is installed with 9.5-inch solid, never-flat wheels and a fold-down manage, so it may simply accompany you wherever you go. And with its solidified metal-tube cradle, this particular rugged electrical generator holds up properly for regular travel, permitting you to stay up for years of procedure.
<G-vec00407-001-s045><accompany.begleiten><de> Begleiten Sie leichte Speisen, Obst und Süßigkeiten.
<G-vec00407-001-s045><accompany.begleiten><en> GOES WELL WITH: Accompany light dishes, fruits and sweets.
<G-vec00407-001-s046><accompany.begleiten><de> Wer anderen auf Augenhöhe begegnen und eingreifende Veränderungen begleiten möchte, braucht Persönlichkeit und fundierte Kenntnisse in den unterschiedlichsten Fachgebieten und Branchen.
<G-vec00407-001-s046><accompany.begleiten><en> Those who want to meet others at eye level and accompany interfering changes need personality and a good knowledge in the most diverse subject areas and sectors.
<G-vec00407-001-s047><accompany.begleiten><de> Es ist ein guter Wein, um die Pasta, Reis und Salat zu begleiten.
<G-vec00407-001-s047><accompany.begleiten><en> It is a good wine to accompany the pasta, rice and salad.
<G-vec00407-001-s048><accompany.begleiten><de> Wie erinnert in unserer allgemeinen Versammlung, sind die Herausforderungen zahlreich, die und folglich eine zusätzliche organisations- und projekt- Mühe für sie zu können der die zukunft unsere Mitglieder wird notwendig sein wird in richtung zu sie führen warten, entlang dem Kurs begleiten.
<G-vec00407-001-s048><accompany.begleiten><en> Like remembered in our public assembly, the challenges are numerous that attend our associates and therefore an ulterior organizational and progettuale effort for being able will be necessary to accompany them along the distance that will lead them towards the future.
<G-vec00407-001-s049><accompany.begleiten><de> Es werden fundierte Kenntnisse der Rahmenbedingungen, die eine wirtschaftliche Tätigkeit in der Union prägen, vermittelt und die besonderen Regelungen, denen eine solche Tätigkeit unterworfen sein kann (Europäisches Wettbewerbsrecht, Wirtschafts- und Wettbewerbspolitik) oder die sie begleiten (Urheberrecht und Gewerblicher Rechtsschutz in der Union), vertieft.
<G-vec00407-001-s049><accompany.begleiten><en> Students may also deepen their knowledge of more particular regulations which economic activities in the EU might be subject to (e.g. European Competition Law, Economic and Competition Policy) or that potentially accompany such activities (e.g. Intellectual Property Law).
<G-vec00407-001-s050><accompany.begleiten><de> Als Geldgeber agieren wir mit Start-ups auf Augenhöhe: Wir fordern und fördern Gründer, die hoch hinauswollen, und begleiten sie flexibel von der Strategie bis zur Produktentwicklung.
<G-vec00407-001-s050><accompany.begleiten><en> As investors we deal with start-ups as equals: We provide support but also have high expectations, we accompany founders flexibly from strategy to product development to market entry.
<G-vec00407-001-s051><accompany.begleiten><de> An euren Arbeiten nehmen die Päpstlichen Vertreter in Jerusalem, im Libanon, in Syrien, im Irak und Jordanien sowie in der Ukraine teil, die das Leben der Kirchen und Völker jener Länder begleiten, indem sie durch Begegnungen, aber auch durch Gesten konkreter Nächstenliebe in Abstimmung mit allen beteiligten Behörden der Römischen Kurie die Nähe des Papstes und des Heiligen Stuhls bezeugen.
<G-vec00407-001-s051><accompany.begleiten><en> They accompany the life of the Churches and peoples of those countries, demonstrating the closeness of the Pope and the Holy See not only through their contacts but also through gestures of concrete charity, in coordination with all the concerned offices of the Holy See.
<G-vec00407-001-s052><accompany.begleiten><de> In der Lobby Gallery sind Zeichnungen zu sehen, die analog zu Rottenbergs Installationen entstehen und diese begleiten – Diagramme die von Pollen, Blumen und Reizstoffen nur so wimmeln.
<G-vec00407-001-s052><accompany.begleiten><en> The Lobby Gallery is also showing drawings that arose parallel to Rottenburg's installations and accompany them – diagrams that teem with pollen, flowers, and irritants.
<G-vec00407-001-s053><accompany.begleiten><de> Leichte Trommelwirbel und der Duft von Zitrusfrüchten begleiten Sie dabei.
<G-vec00407-001-s053><accompany.begleiten><en> Drum rolls and the aroma of citrus fruits will accompany you.
<G-vec00407-001-s054><accompany.begleiten><de> Die sieben Sänger der hochangesehenen korsischen Gruppe „A Filetta“ begleiten das Geschehen mit wundersamen, wunderschönen, fremdartigen Gesängen, beruhend auf liturgischen und poetischen Texten.
<G-vec00407-001-s054><accompany.begleiten><en> The seven singers of the renowned Corsican group “A Filetta” accompany the action with their wondrous, beautiful and exotic songs, which are based on liturgical and poetic texts.
<G-vec00407-001-s055><accompany.begleiten><de> Unser Research analysiert über 600 europäische Aktienwerte, darüber hinaus begleiten wir Börsengänge, Kapitalerhöhungen sowie Sondertransaktionen und beraten bei Fusionen und Unternehmensübernahmen.
<G-vec00407-001-s055><accompany.begleiten><en> Our Research department analyses over 600 European equities, and we also accompany IPOs, capital increases and special transactions, and provide advice for mergers and acquisitions.Â
<G-vec00407-001-s056><accompany.begleiten><de> Vielmehr sollten sie die weitere situationsgerechte Ausgestaltung der Geschlechterrollen offen begleiten und sie mit der Vision inspirieren, daß die Geschlechter für den christlichen Glauben gleichwertig in (selbstbestimmter) Differenz sind und darum die gleichen Rechte auf Zugang zu Lebenschancen haben.
<G-vec00407-001-s056><accompany.begleiten><en> They should rather openly accompany the further appropriate organisation of the gender roles, and inspire them with the vision that in Christian faith the sexes are, in (self-determined) difference, of the same value and have therefore the same rights of access to opportunities in life.
<G-vec00301-001-s232><attend.begleiten><de> Die Empfehlung des Verbandes ist, dass immer zwei Hebammen eine Geburt begleiten.
<G-vec00301-001-s232><attend.begleiten><en> The Chamber recommends that always two midwives attend a birth.
<G-vec00301-001-s233><attend.begleiten><de> - hilft Projekte und Vorhaben laufend zu begleiten...
<G-vec00301-001-s233><attend.begleiten><en> - helps to attend projekts and plans ongoing...
<G-vec00301-001-s234><attend.begleiten><de> Beim zweiten Versuch führen die sekundären Supernaphim die ihnen Anvertrauten unfehlbar zum Erfolg, und es sind immer dieselben superaphischen Betreuer und anderen Führer, welche die Kandidaten während des zweiten Abenteuers begleiten.
<G-vec00301-001-s234><attend.begleiten><en> Never do the secondary supernaphimˆ fail to pilot their subjects successfully on the second attempt, and the same superaphicˆ ministers and other guides always attend these candidates during this second adventure.
<G-vec00301-001-s235><attend.begleiten><de> Für unsere Klienten führen und begleiten wir Verfahren vor Behörden und Verwaltungsinstitutionen des Bundes, der Kantone und Gemeinden, vor Selbstregulierungsorganisationen sowie vor allen verwaltungsrechtlichen Instanzen.
<G-vec00301-001-s235><attend.begleiten><en> On behalf of our clients we conduct and attend to cases before federal, cantonal and local authorities and administrative institutions, self-regulatory organizations and all administrative law courts.
<G-vec00301-001-s236><attend.begleiten><de> Im Gegensatz zu vielen anderen Existenzgründerberatungen profitieren Sie bei unserer Existenzgründerberatung durch die Zusammenarbeit mit einem integrierten Team aus Strategie-, Marketing- und Finanzexperten, die neben Existenzgründern auch viele mittelständische Unternehmen wirtschaftlich begleiten, und Ihnen so über die Existenzgründungsberatung hinaus ein hohes Potential an aktiver Unterstützung in der kontinuierlichen Existenzgründungsstabilisierung bieten.
<G-vec00301-001-s236><attend.begleiten><en> In contrast to many other start-up consultancies, with our start-up consultancy you profit from the cooperation with an integrated team from strategy, marketing and finance experts who attend founders of new businesses and many medium-sized businesses economically and thus offer you not only the start-up consulting but also a high potential of active support in the continuous start-up stabilization.
<G-vec00301-001-s237><attend.begleiten><de> In unserer Praxis begleiten wir Sie während der gesamten Kur.
<G-vec00301-001-s237><attend.begleiten><en> At our day clinic, we will attend you throughout the entire treatment.
<G-vec00301-001-s238><attend.begleiten><de> Unter der Federführung von Ernst Eckert, einem Sproß der Gründerfamilie Ott, entsteht so ein Unternehmen, dessen Produkte und Leistungen die Tabak- und Rauchkultur in Europa und Übersee begleiten und nachhaltig prägen sollten - seit nunmehr über 150 Jahren.
<G-vec00301-001-s238><attend.begleiten><en> In this way a business is created under the management of Ernst Eckert, a scion of the founding family Ott, and its products and services were to attend and shape the culture of tobacco and smoking in Europe and overseas for a long time - for 150 years now.
<G-vec00301-001-s239><attend.begleiten><de> Wir begleiten Sie in Phasen des Wachstums, Start-Ups oder in der Krise mit zielführendem Controlling.
<G-vec00301-001-s239><attend.begleiten><en> We attend you in the phases of growth, start-up or in the crisis with purposeful controlling.
<G-vec00301-001-s240><attend.begleiten><de> Wir werden das Thema LSBTI in Mexiko weiter begleiten und sind gespannt, wie die einzelnen Initiativen laufen“, erklärt von Schönfeld abschließend.
<G-vec00301-001-s240><attend.begleiten><en> We are going to continue to attend to the issue of LGBTI in Mexico and are curious how the individual initiatives will work out”, von Schönfeld finally explains.
<G-vec00301-001-s241><attend.begleiten><de> Die Zielsetzung des Trainingsprogramms ist, einen Prozess der Veränderung der gewalttätigen Frauen zu befördern und zu begleiten.
<G-vec00301-001-s241><attend.begleiten><en> The idea of this program is to attend and promote the process of change of violent women.
<G-vec00301-001-s242><attend.begleiten><de> Wenn nötig, begleiten Dolmetscher diese medizinischen Untersuchungen und Betreuung.
<G-vec00301-001-s242><attend.begleiten><en> Where necessary, interpreters attend these check-ups and medical care.
<G-vec00301-001-s243><attend.begleiten><de> Bevor wir IT Outsourcing Projekte starten oder begleiten, erstellen wir eine Kosten- und Nutzenanalyse zum IT Outsourcing Vorhaben für unsere Kunden, damit IT Outsourcing auch langfristig wirtschaftlich erfolgreich wird.
<G-vec00301-001-s243><attend.begleiten><en> Before we start or attend IT outsourcing projects, we make a cost-benefit analysis regarding the IT outsourcing project for our customers so that the IT outsourcing will be economically successful in the long term.
<G-vec00301-001-s244><attend.begleiten><de> Nun gibt es nichts, was so geeignet wäre, das Tonerkennen zu üben, als das Begleiten, weil man immer auf die Prinzipalstimmen Acht geben und ihre Bewegung verfolgen muss.
<G-vec00301-001-s244><attend.begleiten><en> It does not seem that anything would be more suitable to practice than harmonizing, because one must always attend to the principal singers and follow their movement.
<G-vec00301-001-s245><attend.begleiten><de> Das ist nur die erste der sukzessiven administrativen Anpassungen, die die Entfaltung der aufeinander folgenden Zeitalter immer strahlenderen Vollbringens begleiten, während die bewohnten Welten vom ersten zum siebenten Stadium gefestigter Exi stenz vorrücken.
<G-vec00301-001-s245><attend.begleiten><en> This is merely the first of the successive administrative adjustments which attend the unfolding of the successive ages of increasingly brilliant attainment on the inhabited worlds as they pass from the first to the seventh stage of settled existence.
<G-vec00301-001-s246><attend.begleiten><de> Wir begleiten und kommunizieren die nachhaltige Wertorientierung des gesamten Unternehmens.
<G-vec00301-001-s246><attend.begleiten><en> We attend and communicate the sustainable value orientation of the entire company.
<G-vec00301-001-s247><attend.begleiten><de> Nicht nur außen lässt sich hier ein gelungenes Designstück entdecken, im Inneren begleiten eine Mischung aus weichen Noppen, Rillen, Kurven und Erhebungen dein bestes Stück zu einem einzigartigen Massageerlebnis.
<G-vec00301-001-s247><attend.begleiten><en> Not only form outside you can discovery an impressive piece of design, at inside attend a mix of nubs, grooves and curves you to a unique massage pleasure.
<G-vec00301-001-s248><attend.begleiten><de> Liebe, Vertrauen und tiefe Zuneigung begleiten sie mit jeder ihrer Gesten durch den Tag.
<G-vec00301-001-s248><attend.begleiten><en> Love, trust and deep affection attend them with every gesture through this day.
<G-vec00301-001-s249><attend.begleiten><de> "Dabei finde ich es neben den Trainingsveranstaltungen, die uns ein direktes Feedback zur Arbeit geben, besonders spannend, größere Veränderungsvorhaben in interdisziplinären Teams zu planen und zu begleiten, bei denen man die Umsetzung und die Ergebnisse seiner Arbeit hinterher ""live"" sehen kann."
<G-vec00301-001-s249><attend.begleiten><en> "Aside from the training events, which provide us with direct feedback on our work, I find it extremely interesting to plan and attend to larger change projects in interdisciplinary teams, where one can see the execution and results of one's work ""live."""
<G-vec00301-001-s250><attend.begleiten><de> Wir begleiten Demonstrationen für eine Sache.
<G-vec00301-001-s250><attend.begleiten><en> We attend demonstrations for a cause .
<G-vec00042-001-s152><join.begleiten><de> Als Ali holte mit dem Propheten (salla Allahu alihi war ihm), suchte erseine Erlaubnis, ihn zu begleiten.
<G-vec00042-001-s152><join.begleiten><en> When Ali caught up with the Prophet, (salla Allahu alihi was sallam), he sought his permission to join him.
<G-vec00042-001-s153><join.begleiten><de> Sie begleiten die beiden Fahrer, ein Mädchen und ihren Hund, und fahren mit ihnen einem neuen Tag entgegen.
<G-vec00042-001-s153><join.begleiten><en> They join the drivers, a girl and her dog, as they journey into a new day.
<G-vec00042-001-s154><join.begleiten><de> "Wir sind zuversichtlich, unsere Aktionäre davon zu überzeugen, uns auf diesem Weg zu begleiten"", ergänzt der Vorsitzende des Aufsichtsrates Volker Stegmann abschließend."
<G-vec00042-001-s154><join.begleiten><en> "We are confident, to convince our shareholders to join us on this way forward, ""concludes the Chairman of the Supervisory Board, Volker Stegmann."
<G-vec00042-001-s155><join.begleiten><de> Fähigkeit, ein Gespräch als Gast auf Skype.com mit Skype for Web zu begleiten.
<G-vec00042-001-s155><join.begleiten><en> Ability to join a conversation as a Guest on Skype.com using Skype for Web.
<G-vec00042-001-s156><join.begleiten><de> Alternativ für diejenigen, die planen, in diesem Herbst im Vereinigten Königreich sich aufzuhalten, aber immer noch traditionelle bayerische Kultur erleben möchten, können Mitglieder wählen, sich als Führer zu registrieren, um unbegleitete Reisende von der ganzen Welt zu begleiten, die auch die Erkundung zahlreicher Bierzelte auf Londons eigenem Oktoberfest planen.
<G-vec00042-001-s156><join.begleiten><en> Alternatively, for those who plan to stay in the UK this autumn but still want to experience traditional Bavarian culture, members can choose to register as a Guide to join unaccompanied travellers from around the world who also plan on exploring the numerous beer tents at London's very own Oktoberfest.
<G-vec00042-001-s157><join.begleiten><de> Wir begleiten sie auf ihrer Achterbahnfahrt durch das gesamte Spektrum menschlicher Emotionen, von totaler Euphorie bis zum größtmöglichen Schmerz.
<G-vec00042-001-s157><join.begleiten><en> We join her on a rollercoaster ride across the full spectrum of human emotions, catapulting from total euphoria to devastating loss, living life at full force and in glorious technicolour.
<G-vec00042-001-s158><join.begleiten><de> Begleiten Sie in der vierten Staffel „Alaska State Troopers“ die Männer und Frauen in Blau bis in den letzten Winkel Alaskas: von Drogenrazzien im Mat-Su Valley über Hochgeschwindigkeits-Verfolgungsjagden durch Fairbanks bis hin zur Verfolgung von Verdächtigen bis in die entlegensten Ortschaften.
<G-vec00042-001-s158><join.begleiten><en> The fourth season of “Alaska State Troopers” invites you to join the men and women in blue as they fan out to every corner of Alaska; from drug busts in the Mat-Su Valley to high-speed chases through Fairbanks and to tracking suspects all the way to remote villages, the Troopers go head-first into danger. Below-freezing temperatures, icy roadways, big game animals and endless daylight add a whole new element of danger and risk to the mix.
<G-vec00042-001-s159><join.begleiten><de> Wir begleiten Ernst Herzfeld auf seiner letzten Expedition nach Persepolis im Jahre 1923, reisen mit dem Mann nach Mexiko, der den Azteken-Kalender entschlüsselte, besuchen die weltgrößte präindustrielle Stadt Angkor in Kambodscha, begleiten Isidoro Falchi, der Beweise für die Existenz der Etrusker findet und sehen, wie Alfred Merlin durch seine Entdeckung von Schiffswracks im Mittelmeer die Disziplin der Meeresarchäologie begründete.
<G-vec00042-001-s159><join.begleiten><en> In these installments we accompany Ernst Herzfeld on his last expedition to Persepolis in 1923; we travel to Mexico with the man who cracked the code of the Aztec calendar; we visit the greatest pre-industrial city on earth at Angkor; we join Isidoro Falchi as he discovers proof of the existence of the Etruscans; and we watch Alfred Merlin found the discipline of marine archaeology when he discovers shipwrecks in the Mediterranean.
<G-vec00042-001-s160><join.begleiten><de> Guillermo Cruz, eine junge Schlampe im Dienst von Gustav (Matt Kennedy), beschloss, dem Agenten Craig (Doryann Marguet) zu helfen, ihn einzuladen, ihn auf den Höhen von Cannes zu begleiten.
<G-vec00042-001-s160><join.begleiten><en> Guillermo Cruz, a young slut in the service of Gustav (Matt Kennedy), decided to help agent Craig (Doryann Marguet) by inviting him to join him on the heights of Cannes.
<G-vec00042-001-s161><join.begleiten><de> Allerdings begleiten die Kinder ihre Eltern in den meisten Fällen auch auf die Plantagen – entweder, um zusätzliches Geld für die Familie zu verdienen oder einfach, weil es keine Kinderbetreuung vor Ort gibt.
<G-vec00042-001-s161><join.begleiten><en> But traditionally, the children would join their parents in the orchards – either to earn extra income for their family, or simply because there is no other child care available.
<G-vec00042-001-s162><join.begleiten><de> Bis vergangenes Jahr eine kleine Gruppe von Leuten versuchte, mit eigenen Inhalten den Marsch zu begleiten.
<G-vec00042-001-s162><join.begleiten><en> Until last year, a small group of people trying to join the march with your own content.
<G-vec00042-001-s163><join.begleiten><de> Hans Lampe (Schlagzeug / La Dsseldorf) und Franz Bargmann (Gitarre / Camera) begleiten Michael Rother auf dem Phono Festival 2014 als seine Special Guests.
<G-vec00042-001-s163><join.begleiten><en> Hans Lampe (La Dsseldorf / drums) and Franz Bargmann (Camera / guitar) join Michael Rother at Phonofestivalen 2014 as his Special Guests.
<G-vec00042-001-s164><join.begleiten><de> Begleiten Sie in der vierten Staffel „Alaska State Troopers“ die Männer und Frauen in Blau bis in den letzten Winkel Alaskas: von Drogenrazzien im Mat-Su Valley über Hochgeschwindigkeits...
<G-vec00042-001-s164><join.begleiten><en> The fourth season of “Alaska State Troopers” invites you to join the men and women in blue as they fan out to every corner of Alaska; from drug busts in the Mat-Su Valley to high-speed chases...
<G-vec00042-001-s165><join.begleiten><de> Begleiten Sie uns durch die reiche Geschichte und die Aromen des Gins mit dem Gin-Experten und Gastgeber hier im Solar Branco Estate, Ali Bullock.
<G-vec00042-001-s165><join.begleiten><en> Join us as you are guided through the rich history and flavours of gin with gin expert and host here at the Solar Branco Estate, Ali Bullock.
<G-vec00042-001-s166><join.begleiten><de> Für unseren Streifzug durch die deutsche Kunst und Kultur haben wir verschiedene deutsche und ausländische Autoren gebeten, uns zu begleiten.
<G-vec00042-001-s166><join.begleiten><en> We have asked various German and foreign artists to join us in our exploration of German art and culture.
<G-vec00042-001-s167><join.begleiten><de> In den Sommermonaten, würden wir Sie gerne einladen unseren Fremdenführer auf eine Wanderung zum Horseshoe Bend zu begleiten, nachdem Sie im Hotel eingecheckt haben.
<G-vec00042-001-s167><join.begleiten><en> In the summer months, after checking in at your hotel we invite you to join our guide for a hike to Horseshoe Bend.
<G-vec00042-001-s168><join.begleiten><de> Mit den unterschiedlichen Kooperationsmodellen – sei es in Form eines Kultursponsorings, einer Spende, Schenkung oder Zustiftung, sei es als Freund, Förderer oder Mäzen – laden wir Sie ein, uns auf unserem Weg zu begleiten.
<G-vec00042-001-s168><join.begleiten><en> We offer different cooperation models – whether in the form of cultural sponsoring, a donation, a gift, or an endowment contribution, whether as a friend, a sponsor, or a patron – and invite you to join us on our journey.
<G-vec00042-001-s169><join.begleiten><de> Wir würden Sie gerne auf Ihrem begleiten.
<G-vec00042-001-s169><join.begleiten><en> We would like to join you on your way.
<G-vec00042-001-s170><join.begleiten><de> Wir begleiten diese Reise und treffen dabei auf die unterschiedlichsten Menschen und Geschichten entlang der Strecke.
<G-vec00042-001-s170><join.begleiten><en> We join the train on its journey and meet a variety of people and stories along the way.
<G-vec00042-001-s171><join.begleiten><de> Begleiten Sie die extrem erfahrene und leidenschaftliche Crew an Bord der M/V Horizon fÃ1⁄4r eine unvergessliche Käfigtauchsafari in Guadalupe.
<G-vec00042-001-s171><join.begleiten><en> Join the extremely experienced and passionate crew of the M/V Horizon liveaboard for an unforgettable shark cage diving adventure at Guadalupe.
<G-vec00042-001-s172><join.begleiten><de> Sausalito, Kalifornien Begleiten Sie uns auf unseren Muir Woods Gruppen Touren & Muir Woods Private SUV Tour mehr...
<G-vec00042-001-s172><join.begleiten><en> Sausalito, California Join us on our Muir Woods Group Tours & Muir Woods Private SUV Tour Â more...
<G-vec00042-001-s173><join.begleiten><de> Begleiten Sie uns zu einem Gespräch nach dem Film unter der Regie von Eren McGinnis und Rutgers Professoren Ebelia Hernandez, Dan Battey und Nora Hyland von der Graduate School of Education.
<G-vec00042-001-s173><join.begleiten><en> Join us for a conversation after the film with director Eren McGinnis and Rutgers professors Ebelia Hernandez, Dan Battey and Nora Hyland of the Graduate School of Education.
<G-vec00042-001-s174><join.begleiten><de> Begleiten Sie uns auf unserer Reise einen Unterschied in unserer Welt zu machen.
<G-vec00042-001-s174><join.begleiten><en> Join us in our journey to make a difference in our world.
<G-vec00042-001-s175><join.begleiten><de> Begleiten Sie uns auf unserer 1,5-stündigen Tour, um die Orte in Madrid zu entdecken, an denen Sie zusammen mit unserem erfahrenen kulinarischen Führer Süßigkeiten für Schokoladenliebhaber genießen können.
<G-vec00042-001-s175><join.begleiten><en> Join us on our 1.5-hour tour to discover the places in Madrid where you can enjoy sweets for chocolate lovers, along with our expert culinary guide.
<G-vec00042-001-s176><join.begleiten><de> Begleiten Sie die Aktion und gewinnen Sie Ihren Anteil am $ 5.000.000 an Preisgeldern garantiert jeden Monat.
<G-vec00042-001-s176><join.begleiten><en> Join the action and win your share of the $5 million in prizes guaranteed every month.
<G-vec00042-001-s177><join.begleiten><de> Begleiten Sie uns auf eine wundervolle Reise in eine charmante europäische Stadt, in der leuchtende Farben moderne Kunst und Architektur zum Leben erwecken, und in der Sie den Blick auf historischen Gebäude und grüne Täler genießen können.
<G-vec00042-001-s177><join.begleiten><en> Please join us for a Magnifique voyage into a charming European city where vivid colors bring modern art and architecture to life, and where panoramic views sweep over historic buildings and green valleys.
<G-vec00042-001-s178><join.begleiten><de> Übersicht • Begleiten Sie uns auf einer interessanten Tour dieses historischen Friedhofs.
<G-vec00042-001-s178><join.begleiten><en> Overview • Join us on an interesting tour of this historic cemetery.
<G-vec00042-001-s179><join.begleiten><de> Begleiten Sie unsere Crew zu einer 1,5-stündigen Segelboot-Tour im Fluss Tejo, um die schönsten Sehenswürdigkeiten von Lissabon zu genießen.
<G-vec00042-001-s179><join.begleiten><en> Join our crew for a 1,5-hour sailboat tour in the Tagus river, the best way to enjoy the beautiful sights of Lisbon.
<G-vec00042-001-s180><join.begleiten><de> Ob Sie nun in Saas-Fee, Saas-Grund, Saas-Almagell oder Saas-Balen die schönste Zeit des Jahres genießen: Begleiten Sie uns auf einen einstündigen Dorfrundgang und erfahren Sie viel Wissenswertes über Ihren Ferienort.
<G-vec00042-001-s180><join.begleiten><en> Whether you're enjoying the most beautiful time of year in Saas-Fee, Saas-Grund, Saas-Almagell, or Saas-Balen: join us on our hour-long village tour.
<G-vec00042-001-s181><join.begleiten><de> Begleiten sie Batman und Robin und The Joker kämpfen mit dem Bat-flugzeug leicht zu bauen und mit funktion zum schuss auf den flügeln, in diesem set, enthält auch der bolide flammenwerfer des Joker mehr in der Bat-höhle mit standort der landung Bat -, flugzeug -, zelle-und kontrollzentrum.
<G-vec00042-001-s181><join.begleiten><en> Join Batman and Robin fight The Joker with the Bat-plane is easy to build and is equipped with a function of shooting on the wings, this set contains also the fireball flamethrower of the Joker, more of the Bat-cave with location of landing of the Bat-plane, the cell and the control center.
<G-vec00042-001-s182><join.begleiten><de> Weitere Informationen darüber, wie wir mit Bett und Frühstück arbeiten, finden Sie unter B & amp; Bs - Begleiten Sie uns .
<G-vec00042-001-s182><join.begleiten><en> For more information on how we work with bed and breakfasts, please see B & Bs - Join us .
<G-vec00042-001-s183><join.begleiten><de> Begleiten Sie unseren Gastgeber Steve Harvey, der Ihnen die Projekte, Veranstaltungen und besten Orte in Dubai näher bringt.
<G-vec00042-001-s183><join.begleiten><en> Join our host Steve Harvey as he brings you closer to the projects, events, and best places around Dubai.
<G-vec00042-001-s184><join.begleiten><de> "Lappland für Einsteiger Begleiten Sie uns auf unserem entspannten Nachmittagsausflug, ein 2.5-stündiger ""Geschmack"" von unserer Kultur, Geschichte und Lebensweise auf der Nordkyn-Halbinsel."
<G-vec00042-001-s184><join.begleiten><en> "Join us on our relaxed afternoon excursion, a 2.5 hour ""taste"" of our culture, history and way of life on the Nordkyn Peninsula."
<G-vec00042-001-s185><join.begleiten><de> Begleiten Sie Mathieu Larouche, Produktmanager Framegrabber und Kamera Interfaces bei Matrox Imaging, bei Fragen zur Bedeutung von CXP 2.0 und der neuen Rapixo CXP-Serie.
<G-vec00042-001-s185><join.begleiten><en> Join Mathieu Larouche, Product Manager of Frame Grabbers and Camera Interfaces at Matrox Imaging, for a Q&A on the significance of CXP 2.0 and the new Matrox Rapixo CXP series.
<G-vec00042-001-s186><join.begleiten><de> Begleiten Sie uns auf einer Fahrt entlang der istrisch Küste in das malerische Hafenstädtchen Izola, nur einen Steinwurf südlich von Koper.
<G-vec00042-001-s186><join.begleiten><en> Join us for a cruise all the way to the picturesque ancient town of Izola, which lays only a stone's throw south of Koper.
<G-vec00042-001-s187><join.begleiten><de> Begleiten Sie uns in dieser exklusiven Tour in einem exquisiten Weingut & Keller in Nord-Lissabon, in einer Verkostung und historische Erfahrung, die Ihnen einen faszinierenden Einblick in die Welt der portugiesischen Weinproduktion bietet.
<G-vec00042-001-s187><join.begleiten><en> Join us in this exclusive tour in an exquisite winery & cellar in Northern Lisbon, in a tasting and historical experience that will provide you with a fascinating insight into the world of Portugal’s wine production.
<G-vec00042-001-s188><join.begleiten><de> Begleiten Sie uns auf Meereismessflügen in der Arktis, bohren Sie mit uns durch das zweitgrößte Schelfeis der Antarktis oder schauen Sie unseren Mathematikern dabei über die Schulter, wie sie neue Methoden für die Klimamodellierung entwickeln.
<G-vec00042-001-s188><join.begleiten><en> Join us for aerial sea-ice measurements above the Arctic, drilling trips to the second-largest ice shelf in the Antarctic, or learn how our mathematicians are developing new climate-modelling methods.
<G-vec00042-001-s189><join.begleiten><de> Begleiten Sie uns für einen ganzen Tag bei der Erkundung des Milford Sound von Te Anau, beginnend am weltberühmten Milford Track mit einer geführten Wanderung am Morgen.
<G-vec00042-001-s189><join.begleiten><en> Join us for a full day exploring Milford Sound from Te Anau, starting in the world-famous Milford Track with a guided walk tour in the morning.
<G-vec00407-001-s057><accompany.begleiten><de> Die Übung wird begleitend zur Vorlesung Physik angeboten, um durch selbstständiges Rechnen von Übungsbeispielen die in der Vorlesung erworbenen Kenntnisse zu vertiefen.
<G-vec00407-001-s057><accompany.begleiten><en> Exercises accompany the lectures to deepen the knowledge obtained in the lecture. Subject
<G-vec00407-001-s058><accompany.begleiten><de> Diese Aktion begleitend plant Thomann die Aktion „‘Wie süß!‘ 1-166.666,66“, indem er der amerikanischen Außenministerin 166.666,66 Kinderfotos in Einzelkuverts schicken will.
<G-vec00407-001-s058><accompany.begleiten><en> To accompany the letter Thomann plans the action 'Wie Süss!' 1-166,666.66 ('How Sweet' 1-166,666.66), in which he intends to send the American Minister concerned 166,666.66 photographs of children, each enclosed in a separate envelope.
<G-vec00407-001-s059><accompany.begleiten><de> Begleitend zu diesem Buch hielt er dann im Juli 1954 eine Reihe halbstündiger Vorträge, in denen er die Prinzipien, die Ausübung und Weisheit der Scientology festhielt.
<G-vec00407-001-s059><accompany.begleiten><en> To accompany the book, in July 1954, he then delivered a series of half-hour lectures encapsulating the principles, practice and wisdom of Scientology.
<G-vec00407-001-s060><accompany.begleiten><de> Begleitend werden Strategien zur wirtschaftlichen Erschließung dieses Potenzials entwickelt.
<G-vec00407-001-s060><accompany.begleiten><en> To accompany this, strategies are being developed to exploit this potential economically.
<G-vec00407-001-s061><accompany.begleiten><de> Bereits heute ist es für produzierende Unternehmen wichtig, begleitend zu ihren Produkten Dienstleistungen anzubieten.
<G-vec00407-001-s061><accompany.begleiten><en> Offering services to accompany the products they sell is already an important consideration for manufacturing companies.
<G-vec00407-001-s062><accompany.begleiten><de> Begleitend setzen die Szenen wird es klingt Spiele, Lichter und Rahmen der wichtigsten Film über das Leben von Jesus in Matera gedreht.
<G-vec00407-001-s062><accompany.begleiten><en> To accompany the scenes set there will be sounds games, lights and frames of the most important film about the life of Jesus filmed in Matera.
<G-vec00407-001-s063><accompany.begleiten><de> Begleitend zu den Spiel- und Dokumentarfilmen präsentiert das IFFF Dortmund | Köln ein Programm mit Kurzfilmen aus Bosnien-Herzegowina, Rumänien, Bulgarien, Kroatien, Serbien und dem Kosovo.
<G-vec00407-001-s063><accompany.begleiten><en> To accompany the feature fiction films and the documentaries, the Dortmund | Cologne International Women's Film Festival will be presenting a series of shorts films from Bosnia & Herzegovina, Romania, Bulgaria, Croatia, Serbia and Kosovo.
<G-vec00407-001-s064><accompany.begleiten><de> Anmerkungen: Der Film wurde auch begleitend für die Botticelli-Ausstellung im Frankfurter Städel Museum produziert und war dort 2010 von 400.000 Besuchern zu sehen.
<G-vec00407-001-s064><accompany.begleiten><en> Additional remarks: The film was also produced to accompany the Botticelli exhibition in the Frankfurt 'Städel Museum' and could be watched there by 400.000 visitors in 2010.
<G-vec00407-001-s065><accompany.begleiten><de> Vernetzung Begleitend zu meiner beruflichen Tätigkeit bin ich aktiv in den Verbänden der jeweiligen Branche und pflege die Kontakte meiner 30 jährigen internationalen Tätigkeit.
<G-vec00407-001-s065><accompany.begleiten><en> Networking To accompany my professional life I have been active in the associations of each industry and maintained the contacts of my 30 years of international activity.
<G-vec00407-001-s066><accompany.begleiten><de> Begleitend stellen Marbacher Mitarbeiter in der Deutschen Nationalbibliothek in einer Veranstaltungsreihe ihre Bestände vor.
<G-vec00407-001-s066><accompany.begleiten><en> To accompany the exhibition the Marbach staff will be presenting their holdings in a series of events held at the German National Library.
<G-vec00407-001-s067><accompany.begleiten><de> Diskursive Angebote nehmen aktuelle Debatten auf und vermitteln begleitend die Entstehung von zeitgenössischen Choreografien.
<G-vec00407-001-s067><accompany.begleiten><en> Current debates will be discussed in round talks: they will articulate and accompany the creation of current choreographies.
<G-vec00407-001-s068><accompany.begleiten><de> Begleitend zur Ausstellung ist ein Katalog erschienen.
<G-vec00407-001-s068><accompany.begleiten><en> A catalogue was published to accompany the exhibition.
<G-vec00407-001-s069><accompany.begleiten><de> Weniger häufig werden Weiterbildungsmaßnahmen begleitend oder unmittelbar in Anschluß an die berufliche Erstausbildung durchgeführt.
<G-vec00407-001-s069><accompany.begleiten><en> Professional training measures which accompany or immediately follow initial vocational training are less frequent.
<G-vec00407-001-s070><accompany.begleiten><de> Manche Analyseskripte und/oder Resulatet werden begleitend zu den Daten eingestellt.
<G-vec00407-001-s070><accompany.begleiten><en> In some cases analysis scripts and/or results are posted to accompany the data.
<G-vec00407-001-s071><accompany.begleiten><de> Begleitend zur Ausstellung erschien eine Anthologie mit Essays, unter anderen von Esther Choi und Kevin Lotery, in denen die verschiedenen Aspekte dieser Gegenüberstellung behandelt werden.
<G-vec00407-001-s071><accompany.begleiten><en> An anthology with essays has been published to accompany the exhibition, including contributions by Esther Choi and Kevin Lotery, in which the various aspects of this juxtaposition are examined.
<G-vec00407-001-s072><accompany.begleiten><de> "Katalogpräsentation Katalogpräsentation Begleitend zur Ausstellung ""Agnieszka Polska: The Demon's Brain"" erscheint im Dezember ein Katalog, der das theoretische Fundament des Projekts beinhaltet."
<G-vec00407-001-s072><accompany.begleiten><en> "To accompany the exhibition ""Agnieszka Polska: The Demon's Brain"" a catalogue, containing the theoretical foundation of the project, will be published in December."
<G-vec00407-001-s073><accompany.begleiten><de> Begleitend zur Ausstellung findet in Kooperation mit dem Kino Arsenal die von Dorothee Wenner und Nicole Wolf kuratierte Film- und Gesprächsreihe Moving Politics – Cinemas from India statt.
<G-vec00407-001-s073><accompany.begleiten><en> Accompany the exhibition, the film and talk series Moving Politics – Cinemas from India, curated by Dorothee Wenner and Nicole Wolf, will be held in cooperation with the Arsenal movie theater.
<G-vec00407-001-s074><accompany.begleiten><de> Begleitend zur IAA wurden vielfältige Fachveranstaltungen und Kongresse angeboten, die durchweg sehr gut besucht waren.
<G-vec00407-001-s074><accompany.begleiten><en> A wide variety of specialist events and congresses were offered to accompany IAA, and enjoyed very good levels of attendance throughout.
<G-vec00407-001-s075><accompany.begleiten><de> Begleitend zum Essen können die Gäste den berühmten Wein Lachryma Christi probieren.
<G-vec00407-001-s075><accompany.begleiten><en> To accompany the meal guests will be able to sample the famous Lachryma Christi wine.
<G-vec00407-001-s084><accompany.begleiten><de> Jede Frau, die zum ḥağğ aufbricht, braucht daher einen maḥram, der sie auf der Reise und während des ḥağğ begleitet, ungeachtet der Länge des Reiseweges.
<G-vec00407-001-s084><accompany.begleiten><en> Any woman who travels for Hajj must have a Mahram to accompany her in her journey and Hajj, regardless of the length of travel.
<G-vec00407-001-s085><accompany.begleiten><de> Ein Mitarbeiter begleitet Sie zu Ihrem Apartment und händigt Ihnen die Schlüssel aus.
<G-vec00407-001-s085><accompany.begleiten><en> A member of staff will accompany guests to the apartment and provide them with sets of keys.
<G-vec00407-001-s086><accompany.begleiten><de> Und ich danke euch für das Gebet, mit dem ihr meinen Dienst an der Kirche begleitet.
<G-vec00407-001-s086><accompany.begleiten><en> I thank you for the prayer with which you accompany me and my service to the Church.
<G-vec00407-001-s087><accompany.begleiten><de> Der String Obsessive 852-THC-1 kann auf Ihrem nackten Körper oder begleitet von einem sinnlichen Dessous aus der gleichen Kollektion getragen werden (siehe unten).
<G-vec00407-001-s087><accompany.begleiten><en> The Obsessive 852-THC-1 thong can be worn over your naked body or accompany a sensual piece of lingerie from the same collection (see below).
<G-vec00407-001-s088><accompany.begleiten><de> Kinder unter 16 Jahre müssen von Erwachsenen begleitet werden.
<G-vec00407-001-s088><accompany.begleiten><en> An adult must accompany children under 16 years of age.
<G-vec00407-001-s089><accompany.begleiten><de> Die Emission begleitet die IKB Deutsche Industriebank AG.
<G-vec00407-001-s089><accompany.begleiten><en> IKB Deutsche Industriebank AG will accompany the issue.
<G-vec00407-001-s090><accompany.begleiten><de> Die spektakuläre Show wird von den besten DJs begleitet.
<G-vec00407-001-s090><accompany.begleiten><en> The best DJs will accompany the grandiose show.
<G-vec00407-001-s091><accompany.begleiten><de> Das Programm zur Unterstützung der Zivilgesellschaft begleitet und ergänzt die der Ukraine im Rahmen des Vertrags über den Staatsaufbau geleistete Unterstützung, um zu gewährleisten, dass die zivilgesellschaftlichen Organisationen eine glaubwürdige und effektive Rolle bei der Überwachung des Stabilisierungsprozesses und der Durchführung wichtiger Reformen in der Ukraine einnehmen.
<G-vec00407-001-s091><accompany.begleiten><en> The Civil Society Support Programme will accompany and complement the support provided to Ukraine under the State Building Contract, to ensure a credible and effective role of the civil society organisations in monitoring the stabilisation process and the implementation of key reforms in the country.
<G-vec00407-001-s092><accompany.begleiten><de> OM-Klebetechnik begleitet Sie mit unabhängiger Beratung und erstklassiger Entwicklerkompetenz bis zur individuell maßgeschneiderten Lösung, die genau Ihre Anforderungen erfüllt.
<G-vec00407-001-s092><accompany.begleiten><en> OM-Klebetechnik accompany you with independent advice and first-class engineering expertise to individually tailored solution that exactly fulfills your requirements.Your products consequently get the maximum benefit in terms of user-friendliness, safety, efficiency and performance.
<G-vec00407-001-s093><accompany.begleiten><de> MachinePoint Engineering begleitet Investoren und Unternehmer, die neue Verarbeitungsanlagen zur Umwandlung von landwirtschaftlichen Produkten in verarbeitete Produkte, Verarbeitungslinien für Wasser, Säfte, kohlensäurehaltige Getränke und Milchprodukte errichten.
<G-vec00407-001-s093><accompany.begleiten><en> MachinePoint Engineering services accompany investors and entrepreneurs who are creating new processing production plants to transform agricultural products into processed products, processing lines for water, juices, carbonated drinks and dairy products.
<G-vec00407-001-s094><accompany.begleiten><de> Außerdem begleitet die Elefanten auf einen Fluss in der Nähe von zu sehen, wie sie ihre täglichen Bäder haben.
<G-vec00407-001-s094><accompany.begleiten><en> Also, accompany the Elephants to a river close by to see them having their daily baths.
<G-vec00407-001-s095><accompany.begleiten><de> Blasfolienkopf DOLCI, Das MachinePoint Team begleitet Sie durch den gesamten Kaufprozess der Maschine.
<G-vec00407-001-s095><accompany.begleiten><en> Blown film die head DOLCI, The team at MachinePoint will accompany you through the whole process of buying the machine.
<G-vec00407-001-s096><accompany.begleiten><de> Germano, von seiner Nachtschicht immer noch nicht ausgelastet, begleitet uns auf seinem Fahrrad.
<G-vec00407-001-s096><accompany.begleiten><en> Germano, from his night shift yet fully occupied, does not accompany us on his bicycle.
<G-vec00407-001-s097><accompany.begleiten><de> Es ist äußerst wichtig, daß ihr die in euren Teilkirchen lebenden Ordensmänner und Ordensfrauen weiterhin brüderlich begleitet und sie ermuntert, damit sie, während sie die evangelischen Räte ihrem Charisma gemäß getreu leben, nicht aufhören, ein starkes Zeugnis ihrer Gottesliebe, ihrer unverbrüchlichen Treue zum Lehramt der Kirche und ihrer eifrigen Zusammenarbeit mit den Pastoralplänen der Diözesen zu geben.
<G-vec00407-001-s097><accompany.begleiten><en> It is of the utmost importance that you continue to accompany and to animate in a brotherly manner the men and women religious present in your particular Churches so that, living faithfully the evangelical counsels in accordance with their own charism, they may continue to bear a lively witness of love for God, of firm adherence to the Magisterium of the Church and of collaboration with the diocesan pastoral programmes.
<G-vec00407-001-s098><accompany.begleiten><de> Genießen Sie Ihren Aufenthalt mit dem Wissen, dass unser Concierge-Service im Zimmerpreis enthalten ist und Sie während Ihres Aufenthaltes begleitet, vom Tag Ihrer Anreise, bis hin zu Ihrer Abreise.
<G-vec00407-001-s098><accompany.begleiten><en> Know that our concierge service included in your reservation will accompany you throughout your stay, as from your day of departure until you get back.
<G-vec00407-001-s099><accompany.begleiten><de> In Köln begleitet ihn die Gruppe BAP, in Mannheim darf Xavier Naidoo mit dem Österreicher musizieren.
<G-vec00407-001-s099><accompany.begleiten><en> In Cologne the group BAP will accompany him, in Mannheim Xavier Naidoo will be playing with the Austrian.
<G-vec00407-001-s100><accompany.begleiten><de> NATYA kann beispielsweise als herkömmlicher vibrierender Stimulator verwendet werden, aber auch als Vibrator für Paare, der die Penetration des männlichen Partners begleitet.
<G-vec00407-001-s100><accompany.begleiten><en> NATYA can for example be used as a conventional vibrating stimulator, but also as a vibrator for couples that can accompany the penetration of your male partner.
<G-vec00407-001-s101><accompany.begleiten><de> Kinder unter 4 Jahren sollten von den Eltern, oder einem Babysitter begleitet werden.
<G-vec00407-001-s101><accompany.begleiten><en> Parents or a baby-sitter should accompany all children under 4 years of age.
<G-vec00407-001-s102><accompany.begleiten><de> Das Teilprojekt begleitet den gesamten Bauprozess von der frühen Planungsphase über die Produktion auf der Baustelle bis hin zur Datendokumentation von leistungs- und qualitätsrelevanten Daten durch standardisierte EDV-Hilfsmittel, die entsprechend den Anforderungen der Bauplanung angepasst und weiterentwickelt werden.
<G-vec00407-001-s102><accompany.begleiten><en> The sub-project will accompany the entire construction process from the early planning phase to production on the building site, right up to the documentation of performance and quality-related data using standardized computer-aided tools, which will be aligned to the specific requirements of the construction planning and continually developed.
<G-vec00169-001-s035><reclaim.begleiten><de> Sie werden dann durch die Passkontrolle bis zur Gepäckausgabe begleitet, wo man Ihnen hilft, soweit nötig Gepäck und Mobilitätshilfen abzuholen.
<G-vec00169-001-s035><reclaim.begleiten><en> Assistance will then be provided through passport control and to the baggage reclaim where you will be helped to collect any luggage or mobility equipment, if necessary.
<G-vec00407-001-s103><accompany.begleiten><de> Barnabas begleitete Paulus jedoch nicht auf der zweiten Missionsreise, als die Galater nach der Galater-Theorie zum ersten Mal evangelisiert wurden.
<G-vec00407-001-s103><accompany.begleiten><en> But Barnabas did not accompany Paul on the Second Missionary Journey, when, on the Galatian theory, the Galatians were first evangelized.
<G-vec00407-001-s104><accompany.begleiten><de> """Ich brauchte immer Gesellschaft und jemanden, der mich begleitete, wohin ich auch ging."
<G-vec00407-001-s104><accompany.begleiten><en> """I was always in need of company and in need of someone to accompany me wherever I went."
<G-vec00407-001-s105><accompany.begleiten><de> Dann kam schließlich Erzbischof Martin herein, Präfekt des Päpstlichen Hauses, und begleitete uns in den Bibliothekssaal, wo die Audienz stattfand.
<G-vec00407-001-s105><accompany.begleiten><en> Archbishop Martin, Prefect of the Pontifical Household, came in to accompany us to the Library Room, where the audience was to take place.
<G-vec00407-001-s106><accompany.begleiten><de> Als Mutter begleitete ich Ihn Schritt für Schritt und sah wie gross Seine Liebe für alle war, und welche später sich in der totalen Hingabe für die Rettung der Menschheit vollzog.
<G-vec00407-001-s106><accompany.begleiten><en> As a Mother, I used to accompany Him step-by-step and I saw how great was His love for everyone, and later on, His total surrender for the Salvation of the humanity was complete.
<G-vec00407-001-s107><accompany.begleiten><de> Sie fragte, ob ich eine Frau hatte, und gewundert, warum sie mich nicht auf meinen Spielräumen begleitete.
<G-vec00407-001-s107><accompany.begleiten><en> She asked if I had a wife, and wondered why she did not accompany me on my travels.
<G-vec00407-001-s108><accompany.begleiten><de> Sie sollen bitten, dass der Arzt den Patienten dem Krankenhaus begleitete, um in der Lage zu sein, beliebigen Komplikationen entgegenzustehen, wenn das Sanitätsauto vom ausgebildeten mittleren medizinischen Personal nicht ausgestattet ist.
<G-vec00407-001-s108><accompany.begleiten><en> You should request that the physician accompany the patient to the hospital in order to be able to counter any complications, unless an ambulance is equipped with trained paramedical personnel.
<G-vec00407-001-s109><accompany.begleiten><de> Seine Frau Jiang Qing begleitete ihn nicht, ebensowenig wie seine Volksmassen.
<G-vec00407-001-s109><accompany.begleiten><en> His wife, Jiang Qing, did not accompany him, nor did his masses.
<G-vec00407-001-s110><accompany.begleiten><de> Wir begleiteten den Profialpinisten Stefan Glowacz beim Klettern und folgen Kajakern, Slacklinern und Basejumpern beim Ausleben ihrer Leidenschaften.
<G-vec00407-001-s110><accompany.begleiten><en> We accompany the professional alpinist Stefan Glowacz climbing, and follow the kayakers, slack liners and base jumpers celebrating their passions.
<G-vec00407-001-s111><accompany.begleiten><de> Wir begleiteten die Thiemanns durch ihren Alltag und gehen dabei der Frage nach, ob das Leben und Arbeiten in der Großfamilie eine mögliche Alternative in wirtschaftlich und sozial schweren Zeiten ist.
<G-vec00407-001-s111><accompany.begleiten><en> And that works pretty well, so far. We accompany the Thiemanns through their every day life and get into the matter, if living and working in an extended family is a possible alternative through economically and socially hard times.
<G-vec00407-001-s112><accompany.begleiten><de> Es war nicht unüblich, dass Hunde ihre reichen Besitzer auf Kreuzfahrten begleiteten.
<G-vec00407-001-s112><accompany.begleiten><en> It was not unusual for dogs to accompany their rich owners on a sea cruise.
<G-vec00407-001-s113><accompany.begleiten><de> Es entsprach der üblichen Form von diskursiven Ereignissen, die größere Kunstprogramme mit dem Ziel begleiteten, einen Raum für Reflexion und Kritik anzubieten, aber diese Räume wurden tatsächlich zu Orten, in denen Kritik gefördert, institutionalisiert und schließlich neutralisiert oder angeeignet wurde.
<G-vec00407-001-s113><accompany.begleiten><en> It paralleled the usual form of discursive events that accompany main art programs with the task of providing a space for reflection and criticism, but those spaces are actually becoming places where critique is fostered, institutionalized and, finally, neutralized or appropriated.
<G-vec00407-001-s114><accompany.begleiten><de> Manchmal war ein Reitpferd oder Wächter beigesetzt, die den Verstorbenen begleiteten.
<G-vec00407-001-s114><accompany.begleiten><en> Sometimes a horse or a guard was buried to accompany the deceased.
<G-vec00407-001-s115><accompany.begleiten><de> Die tägliche Herausforderung der Nahrungsbeschaffung für Mensch und Pferd und die Suche nach Übernachtungsmöglichkeit begleiteten sie noch viele Tage.
<G-vec00407-001-s115><accompany.begleiten><en> The daily challenge of finding food for all, including the horses, and the search for nightly quarters were to accompany them for many days to come.
<G-vec00407-001-s116><accompany.begleiten><de> In der gesamten Ausstellung kann man immer wieder die Macht natürlicher Energien bestaunen, die unser Leben begleiteten, die wir aber nur bedingt nutzen können.
<G-vec00407-001-s116><accompany.begleiten><en> Throughout the exhibition, visitors can marvel at the power of natural energies that accompany our lives, but which we can only put to use to a limited extent.
<G-vec00407-001-s117><accompany.begleiten><de> Co-Producer Al Carlson und Freund Matt McDermott begleiteten die Stücke beispielsweise mit Flöte, Orgel, Synthesizer und Piano, was den Sound bereichert und Pratts Faible für luftige, aber detailreiche Sixties-Arrangements genug Spielraum bietet.
<G-vec00407-001-s117><accompany.begleiten><en> Co-producer Al Carlson and friend Matt McDermott accompany the songs with flute, organ, synthesizer, and piano, which enriches the sound and gives enough room for Pratt’s penchant for airy but detailed 60s arrangements.
<G-vec00407-001-s118><accompany.begleiten><de> Die organisatorische Leitung lag in den Händen der jüdischen Wohlfahrtspflege Frankfurt a. M., deren Mitarbeiter die Kinder sehr wahrscheinlich bis Köln begleiteten.
<G-vec00407-001-s118><accompany.begleiten><en> The management was in the hands of the Frankfurt Jewish welfare agency, the employees of which would most likely accompany the children all the way to Cologne.
<G-vec00407-001-s119><accompany.begleiten><de> Leicht schwingende, unten weit ausgestellte Schlaghosen - sogenannte Trompetenhosen - der Name ist schon Rhythmus und Musik, begleiteten eine neu heranwachsende Generation aufbegehrender Jugendlicher in eine Zeit des Aufbruchs.
<G-vec00407-001-s119><accompany.begleiten><en> Light swinging, bottom wide flared pants - so called trumpet pants - the name is already rhythm and music, accompany a new grown up generation of protesting adolescents in a time of breakup.
<G-vec00407-001-s120><accompany.begleiten><de> In den wenigen Fällen, in denen die jungen Ehefrauen ihre Ehemänner in deren Heimatland begleiteten, wurden sie zu häuslicher Arbeit und Sexsklaverei gezwungen, sagte die Polizei.
<G-vec00407-001-s120><accompany.begleiten><en> In the few cases when the young brides did accompany their husbands back to their home country, they were forced into domestic servitude or sexual slavery, police said.
<G-vec00407-001-s121><accompany.begleiten><de> Zwei langjährige Mitarbeiter aus Roy Anderssons Team begleiteten die Dreharbeiten zu DAS JÜNGSTE GEWITTER und schufen einen Dokumentarfilm, der faszinierende Einblicke in die Visionen und Arbeitsweisen des schwedischen Ausnahmeregisseurs ermöglicht.
<G-vec00407-001-s121><accompany.begleiten><en> Two long time staff of Andersson's team accompany the shooting of YOU, THE LIVING and created a documentary allowing fascinating insight into visions and ways of working of the exceptional Swedish director.
<G-vec00407-001-s170><accompany.begleiten><de> Die webcam soll den Roboter dabei begleiten.
<G-vec00407-001-s170><accompany.begleiten><en> The webcam will accompany the robot.
<G-vec00407-001-s171><accompany.begleiten><de> Dabei begleiten wir Sie kontinuierlich und beraten Sie in schwierigen Situationen.
<G-vec00407-001-s171><accompany.begleiten><en> We accompany you on a continuous basis and consult you in difficult situations.
<G-vec00407-001-s172><accompany.begleiten><de> Dabei wird ein heimischer Koch Sie auf den Markt begleiten, um exotische Zutaten einzukaufen.
<G-vec00407-001-s172><accompany.begleiten><en> A local cook will accompany you to the market to shop for exotic ingredients.
<G-vec00407-001-s173><accompany.begleiten><de> Das tak wird sie dabei begleiten.
<G-vec00407-001-s173><accompany.begleiten><en> The tak will accompany them.
<G-vec00407-001-s174><accompany.begleiten><de> In ihrer Liebe für eine jede Seele, hätte sie es gerne, wenn sie alle dabei begleiten würden, das ist jedoch eine Frage der freien Willensentscheidung einer jeden Person.
<G-vec00407-001-s174><accompany.begleiten><en> In her love for each and every soul, she would like all to accompany her, but this is a matter of every person's free will choice.
<G-vec00407-001-s175><accompany.begleiten><de> Man zwar im Allgemeinen sagen, dass es sich dabei nicht nur um Stadien im Entwicklungsprozess des konventionellen Bodhichittas handelt, sondern dass sie Bodhichitta auch begleiten, aber sie sind nicht kongruent mit Bodhichitta.
<G-vec00407-001-s175><accompany.begleiten><en> Although, in general, we may say not only that they are stages in developing conventional bodhichitta, but also that they accompany bodhichitta; nevertheless, they are not congruent with bodhichitta.
<G-vec00407-001-s176><accompany.begleiten><de> P. Konrad Esser wird mich dabei begleiten.
<G-vec00407-001-s176><accompany.begleiten><en> Konrad Esser will accompany me.
<G-vec00407-001-s177><accompany.begleiten><de> Wie der Name vermuten lässt, handelt es sich dabei um die Vermittlung von Damen, die Herren zu bestimmten Anlässen begleiten sollen.
<G-vec00407-001-s177><accompany.begleiten><en> As the name implies, it is the mediation of ladies who are to accompany gentlemen on certain occasions.
<G-vec00169-001-s095><reclaim.begleiten><de> Diese Leuchtflächen begleiten die ankommenden Passagiere auf dem Weg zur Passkontrolle und zur Gepäckausgabe.
<G-vec00169-001-s095><reclaim.begleiten><en> They are visible to arriving passengers on their way to passport control and baggage reclaim.
<G-vec00211-002-s118><oversee.begleiten><de> Sie können direkt mitarbeiten oder den Prozess begleiten: Alles ist möglich und macht Spass.
<G-vec00211-002-s118><oversee.begleiten><en> You can work directly with us or simply oversee the process. Everything is possible, and the process is fun and rewarding.
<G-vec00211-002-s184><supervise.begleiten><de> Ein Team von Spezialisten berät Sie zunächst bei der Bedarfsermittlung, unterstützt Sie bei der Prozessfindung, begleitet Ihre Versuche im Technology Center und stellt Ihre Anlage schlüsselfertig auf.
<G-vec00211-002-s184><supervise.begleiten><en> A team of specialists will first assist you in analyzing your needs, support you in developing your process, supervise your trial runs in the Technology Center and assemble a turnkey line.
<G-vec00215-002-s019><advise.begleiten><de> Wir begleiten in Verfahren vor der Europäischen Kommission, zum Beispiel, wenn Unternehmen durch subventionierte Importe aus Nicht-EU-Staaten geschädigt werden.
<G-vec00215-002-s019><advise.begleiten><en> We advise and represent clients in proceedings before the European Commission, for example if they have been damaged by subsidised imports from non-EU countries.
<G-vec00215-002-s020><advise.begleiten><de> Prüfungen Wir planen und begleiten objektbezogene Prüfungen zur Ermittlung von Leistungswerten wie Schlagregendichtheit, Luftdurchlässigkeit etc.
<G-vec00215-002-s020><advise.begleiten><en> We design, assist and advise on project-specific tests to determine performance parameters such as tightness against heavy rain, air permeability etc.
<G-vec00215-002-s021><advise.begleiten><de> Dank eines großen Netzwerks können die Rechtsanwälte die Mandanten bei einer Sanierung weit über die juristische Arbeit hinaus begleiten.
<G-vec00215-002-s021><advise.begleiten><en> Thanks to a vast network, the lawyers are able to advise their clients far beyond the legal work during the course of reorganization.
<G-vec00215-002-s022><advise.begleiten><de> Wir begleiten unsere Mandanten sowohl projektbezogen als auch bei laufenden steuerlichen Angelegenheiten, bei nationalen sowie bei komplexen internationalen steuerlichen Belangen.
<G-vec00215-002-s022><advise.begleiten><en> We advise our clients on a project basis and with ongoing tax advice in national and in very complex international tax issues.
<G-vec00215-002-s023><advise.begleiten><de> Als Unternehmensberatung mit 30 Jahren Projekterfahrung in der Industrie und im Mittelstand begleiten wir Sie in allen Phasen der integrierten Produktentwicklung.
<G-vec00215-002-s023><advise.begleiten><en> ConMoto has 30 years of project experience in multinational corporations and medium-sized companies, we advise you during all phases of integrated product development.
<G-vec00215-002-s024><advise.begleiten><de> Wir begleiten namhafte Banken, Versicherungen, Automobilbauer und -zulieferer, Handelshäuser sowie IT-Unternehmen von der Strategie über die Konzeption bis zur organisatorischen und technischen Umsetzung.
<G-vec00215-002-s024><advise.begleiten><en> We advise leading banks, insurance firms, automobile manufacturers and suppliers, retailers and IT companies on strategy – from concept development to the implementation of operational and IT improvements.
<G-vec00215-002-s025><advise.begleiten><de> Stellenangebote Deutschland In Deutschland begleiten mehr als 130 Rechtsanwälte, Steuerberater und Notare – darunter 39 Partner – von Berlin, Düsseldorf, Hamburg und München aus namhafte Konzerne, große mittelständische Unternehmen, Investoren, Banken und andere Finanzdienstleister bei komplexen Projekten, grenzüberschreitenden Transaktionen und im Tagesgeschäft.
<G-vec00215-002-s025><advise.begleiten><en> In Germany, more than 130 lawyers, tax advisors and notaries – amongst them 39 Partners – advise renowned corporations, medium-sized companies, investors, banks and other financial service providers regarding complex projects, cross-border transactions as well as in their daily business from our offices based in Berlin, Dusseldorf, Hamburg and Munich.
<G-vec00215-002-s026><advise.begleiten><de> Banken informieren wir zudem über aufsichtsrechtliche Pflichten, begleiten bei Bankerlaubnisverfahren und beraten beim Erwerb und der Veräußerung von Kredit- und Finanzdienstleistungsinstituten.
<G-vec00215-002-s026><advise.begleiten><en> We keep banks informed of their supervisory duties, advise them on banking licensing issues and provide guidance on the acquisition and sale of lending institutions and financial services providers.
<G-vec00215-002-s027><advise.begleiten><de> Als M & A-Berater begleiten wir Sie durch den gesamten Transaktionsprozess – von der genauen Analyse Ihrer Handlungsoptionen, der Entscheidung für die grundsätzliche Strategie, der Vorbereitung und individuellen Strukturierung des Transaktionsprozesses über die Suche und Auswahl der richtigen Partner bis zur Vertragsunterschrift.
<G-vec00215-002-s027><advise.begleiten><en> M & A Advisory Services First-class financial advisory services As M & A specialists, we advise you throughout the entire transaction process – from the in-depth analysis of your strategic options and the resulting internal decision-making process to the preparation, structuring and consummation of a transaction with the right partner.
<G-vec00215-002-s028><advise.begleiten><de> Sie unterstützen und begleiten Kommunen, Institutionen und Bauherren bei ihrer strategischen Planung und dem Entwerfen ihrer Bauvorhaben.
<G-vec00215-002-s028><advise.begleiten><en> They support and advise municipal governments, public entities and building contractors in their strategic planning and in the design of their building projects.
<G-vec00215-002-s029><advise.begleiten><de> Die Kanzlei ist Mitglied im internationalen Netzwerk Multilaw und kann Mandanten dadurch weltweit begleiten.
<G-vec00215-002-s029><advise.begleiten><en> The law firm is a member of the international network Multilaw and can as a result advise and assist clients worldwide.
<G-vec00215-002-s030><advise.begleiten><de> Die Spezialisten von Schultze & Braun unterstützen und begleiten Mandanten umfassend in allen Phasen der Nachfolge: von den ersten Gesprächen und der Erarbeitung der Nachfolgeziele bis hin zur konkreten gesellschafts- und erbrechtlichen sowie steuerlichen Umsetzung.
<G-vec00215-002-s030><advise.begleiten><en> Schultze & Braun’s specialists support and advise clients throughout the succession planning process, from initial discussions and identification of succession objectives through to implementation of specific corporate, inheritance and tax measures. Our range of services:
<G-vec00215-002-s031><advise.begleiten><de> Auch begleiten wir unsere Mandanten während der Bauzeit in allen Konflikt- und Streitfällen.
<G-vec00215-002-s031><advise.begleiten><en> We also advise our clients during the construction period in the event conflicts and disputes arise.
<G-vec00215-002-s032><advise.begleiten><de> Erfahrene Businesscoaches begleiten und unterstützen Sie bei der Gründung, der Weiterentwicklung und dem nachhaltigen Wachstum Ihres eigenen Unternehmens.
<G-vec00215-002-s032><advise.begleiten><en> Experienced business coaches advise and support you while you found and develop your company and ensure its sustainable growth.
<G-vec00215-002-s033><advise.begleiten><de> Wir begleiten Sie von der Idee bis zum fertigen Produkt und meistern gekonnt alle logistischen Herausforderungen.
<G-vec00215-002-s033><advise.begleiten><en> We advise you every step of the way, from the initial idea to your finished product, all while deftly negotiating any logistical challenges that might arise.
<G-vec00215-002-s034><advise.begleiten><de> Unsere Experten begleiten Sie in allen Aspekten der funktionalen Sicherheit elektronischer Komponenten und Systeme in mobilen Anwendungen.
<G-vec00215-002-s034><advise.begleiten><en> Our experts are happy to advise you in all areas of functional safety for electronic components and systems in transportation applications.
<G-vec00215-002-s035><advise.begleiten><de> Sportrecht / Sportwirtschaftsrecht Nur wer als Rechtsberater den Sport, seine Beteiligten und seine besonderen Gepflogenheiten kennt – sprich: Nur wer die Sprache des Sports spricht –, kann den Abschluss etwa von Sponsoring- oder Sportvermarktungsverträgen erfolgreich begleiten und mitgestalten.
<G-vec00215-002-s035><advise.begleiten><en> An attorney can only successfully advise and be involved in the sports industry if he is familiar with the participants and especially the customs. Only someone who speaks the language of sports can be successful when concluding, for example, sponsoring or sports marketing contracts.
<G-vec00239-002-s133><join.begleiten><de> Meine Frau oder ich werden Sie auf Wunsch dorthin begleiten und im Vorfeld alles organisieren.
<G-vec00239-002-s133><join.begleiten><en> If you want my wife or myself will join you and organize everything.
<G-vec00239-002-s134><join.begleiten><de> Viele andere Wissenschaftler von Partnerinstituten werden die lokalen und über das Internet verbundenen Zuhörer während des Webcasts begleiten.
<G-vec00239-002-s134><join.begleiten><en> Many researchers from partner institutes will also join the local and Internet audiences during the live webcast.
<G-vec00239-002-s135><join.begleiten><de> Mehr Orientierung, mehr Input: In 2019 begleiten wir Sie erstmalig in geführten Rundgängen auf Ihrer Entdeckungstour über die FIBO.
<G-vec00239-002-s135><join.begleiten><en> A better overview and more input – in 2019 we are offering something new: guided tours of FIBO that allow us to join you on your tour of discovery.
<G-vec00239-002-s136><join.begleiten><de> Der Lohn war die Teilnahme an einem Backstage Meet-and-Greet mit dem King of Pop und die Möglichkeit, sein Idol am Ende des Konzerts auf die Bühne zu begleiten.
<G-vec00239-002-s136><join.begleiten><en> The reward was attending a backstage meet-and-greet with the King of Pop and the opportunity to join his idol on stage at the end of the concert.
<G-vec00239-002-s137><join.begleiten><de> Begleiten Sie uns auf einen Ausflug zur Atlantikstraße, einem von Norwegens meistbesuchten touristischen Reisezielen.
<G-vec00239-002-s137><join.begleiten><en> Here you can join a trip to the Atlantic Road, one of Norway’s most visited tourist destinations.
<G-vec00239-002-s138><join.begleiten><de> An der kurzen Leine geführt, darf Ihr Hund Sie gerne begleiten.
<G-vec00239-002-s138><join.begleiten><en> Taken on a short leash, your dog is welcome to join you.
<G-vec00239-002-s139><join.begleiten><de> Dr. Tony Robinson vom Trinity College in Dublin wird uns auf die Messe begleiten, um zu demonstrieren, wie unsere Infrarotwärmetechnik und unser Prototyp einer neuen Test-Vorrichtung die Grenze des zurzeit Machbaren für Hersteller und Produzenten weiter hinaus schieben.
<G-vec00239-002-s139><join.begleiten><en> Dr Tony Robinson of Trinity College, Dublin, will join us at the show, primarily to demonstrate how our new IR heat work – and prototype test equipment – is going to push the future envelope for manufacturers and producers worldwide.
<G-vec00239-002-s141><join.begleiten><de> Ihr dürft mich dabei begleiten und vielleicht sind Sachen dabei die euch irgendwie weiterhelfen.
<G-vec00239-002-s141><join.begleiten><en> You can join me and maybe I can help Powered by Blogger.
<G-vec00239-002-s142><join.begleiten><de> Das STAR TREK Universum... unendliche Weiten... dies sind die Missionen des Romulanischen Kreuzers Germania, die wir auf ihrem Flug durch das All begleiten.
<G-vec00239-002-s142><join.begleiten><en> STAR TREK Universe. The final frontier. These are the voyages of the Romulan Cruiser Germania on its ongoing missions... and we will join her.
<G-vec00239-002-s143><join.begleiten><de> Dein Baby, mein Neffe (irgendwie fühle ich, dass es ein Junge ist), wird uns bald in dieser Welt begleiten.
<G-vec00239-002-s143><join.begleiten><en> Your baby, my nephew (somehow I just feel it's a boy), will soon join us in this world.
<G-vec00239-002-s144><join.begleiten><de> Beowulf entscheidet sich, dem Drachen in dessen Versteck in Earnanæs zu folgen, aber nur sein junger schwedischer Verwandter Wiglaf wagt es, ihn dorthin zu begleiten.
<G-vec00239-002-s144><join.begleiten><en> Beowulf decides to follow the dragon to its lair at Earnanæs, but only his young Swedish relative Wiglaf, whose name means "remnant of valor",[a] dares to join him.
<G-vec00239-002-s145><join.begleiten><de> Mit der diesjährigen Agile Austria Conference, hoffen wir euch bei eurer Reise weiterzuhelfen und noch mehr Leute zu inspirieren, uns auf dem Weg zu begleiten.
<G-vec00239-002-s145><join.begleiten><en> With this year's Agile Austria Conference, we hope to help you further in your journey and to inspire even more people to join us.
<G-vec00239-002-s146><join.begleiten><de> Wie schon 1997 fragt mich mein Doktorvater: „Hast du Lust, für einen Kollegen einzuspringen und mich auf einer Forschungsreise nach Myanmar zu begleiten?“ Damals ging es nach China, in vier Wochen zwischen 1300 und 3000 Metern nahm ich als junger Student und unerfahrener Reisender sieben Kilo ab.
<G-vec00239-002-s146><join.begleiten><en> Just like he did in 1997, my thesis supervisor asks me, “How would you like to fill in for a colleague and join me on a research trip to Myanmar?” Back then, our destination was China, and as a young student and inexperienced traveler I ended up losing 7 kilos in four weeks, traveling at elevations between 1300 and 3000 meters.
<G-vec00239-002-s147><join.begleiten><de> Eine rote Rose für ein heißer Termin, dieser Dandy Reaper wartet auf Sie, um Ihn in einem guten Rauch zu begleiten.
<G-vec00239-002-s147><join.begleiten><en> A red rose for a hot date, this dandy reaper is waiting for you to join him in a good smoke.
<G-vec00239-002-s148><join.begleiten><de> Meine Freundin hatte sich entschlossen, auf Malta einen Sprachkurs zu besuchen, was mir die Gelegenheit gab, sie zu begleiten und mir dieses Malta mal etwas genauer anzusehen.
<G-vec00239-002-s148><join.begleiten><en> girlfriend decided to attend a language course on Malta, which gave me the opportunity to join her and to have a closer look on this Malta Island.
<G-vec00239-002-s149><join.begleiten><de> So genießen wir unser schönes Land und wir laden Sie ein, uns zu begleiten.
<G-vec00239-002-s149><join.begleiten><en> This is the way we ourselves enjoy discovering our beautiful country and we invite you to join us.
<G-vec00239-002-s150><join.begleiten><de> Wir freuen uns sehr, wenn Sie uns auf diese Reise nach Nirgenwo begleiten.
<G-vec00239-002-s150><join.begleiten><en> We cordially invite you to join our journey to nowhere.
<G-vec00239-002-s151><join.begleiten><de> Jedes seiner Bilder ist eine Einladung, ihn in seine privilegierte Welt zu begleiten, wo natürliche junge Frauen ihre intimsten Momente mit ihm teilen.
<G-vec00239-002-s151><join.begleiten><en> Each of his images is an invitation to join him in his privileged world where natural young women share their most intimate moments.
<G-vec00301-002-s138><attend.begleiten><de> Gerne beraten wir Sie unverbindlich bei Ihrer Produktstrategie und bieten Ihnen an, Sie frühzeitig auf dem kürzest möglichen Weg bis zur Serienlieferung zu begleiten.
<G-vec00301-002-s138><attend.begleiten><en> We appreciate to advise you with your product strategy and offer you to attend in time on the shortest possible way to a serial production.
<G-vec00301-002-s139><attend.begleiten><de> Verfall, Tod und Zerstörung begleiten den Kampf für ein besseres Leben.
<G-vec00301-002-s139><attend.begleiten><en> Waste, death, and destruction attend a fight for a better life.
<G-vec00301-002-s140><attend.begleiten><de> Wir begleiten Sie bei finanzbehördlichen Agenden und halten unser Versprechen.
<G-vec00301-002-s140><attend.begleiten><en> We attend you with all fiscal matters and keep our promises.
<G-vec00301-002-s141><attend.begleiten><de> Sie werden die Aufbauarbeiten und die Montage unserer Plasma-Monitore und Projektionsanlagen in den Warenhäusern und Einkaufszentren begleiten.
<G-vec00301-002-s141><attend.begleiten><en> You will attend the mounting and the installation of our plasma monitors and projection devices in warehouses and shopping centres.
<G-vec00301-002-s142><attend.begleiten><de> Daneben begleiten die Mitarbeiter lokale und regionale Agenda-Initiativen und fördern die deutsch-tschechische Zusammenarbeit.
<G-vec00301-002-s142><attend.begleiten><en> Furthermore, the employees attend to local and regional agenda initiatives and promote the German-Czech cooperation.
<G-vec00301-002-s144><attend.begleiten><de> Wir begleiten Werksabnahmen bei den Zulieferern, koordinieren die Fremdfirmen und begleiten das Projekt bis zur abnahmefähigen Installation.
<G-vec00301-002-s144><attend.begleiten><en> We attend acceptance procedures at suppliers, coordinate the contractors and accompany the project through to completed installation.
<G-vec00301-002-s145><attend.begleiten><de> Leider hatte Kinsky wieder einen Fieberanfall, so dass er mich nun zu dem folgenden Gala-Diner beim Nisam, welches für 8 Uhr angesagt war, nicht begleiten konnte.
<G-vec00301-002-s145><attend.begleiten><en> Unfortunately Kinsky had another fever attack and could not attend the Nizam’s gala dinner that was set for 8 o’clock.
<G-vec00301-002-s146><attend.begleiten><de> Wir werden Sie freundlich begleiten und Sie werden von unserer Professionalität überrascht sein.
<G-vec00301-002-s146><attend.begleiten><en> We will attend you kindly and you will be surprised by our professionalism.
<G-vec00301-002-s147><attend.begleiten><de> Im Sommer 2013 durfte ich die Arbeit des Vereins "Aktive Direkt Hilfe" im Kongo direkt vor Ort für drei Wochen begleiten.
<G-vec00301-002-s147><attend.begleiten><en> In the summer of 2013 I had the opportunity to attend the work of the organization “Aktive Direkt Hilfe” in the Congo directly on-site for three weeks.
<G-vec00301-002-s148><attend.begleiten><de> Entsprechend begleiten wir unsere Kunden in über 60% aller Projekte international.
<G-vec00301-002-s148><attend.begleiten><en> Hence we attend our clients in more than 60% of all project internationally.
<G-vec00301-002-s149><attend.begleiten><de> Als zuverlässiger Ansprechpartner begleiten und unterstützen wir Sie und Ihre Familie beim Fuß fassen und Einleben in der Schweiz.
<G-vec00301-002-s149><attend.begleiten><en> As a well experienced partner we attend and support you and your family during your integration and settle in Switzerland.
<G-vec00301-002-s150><attend.begleiten><de> Gerne begleiten wir Euch auch mehrere Tage – ganz nach Euren Wünschen.
<G-vec00301-002-s150><attend.begleiten><en> We are also happy to attend your celebration for several days – just according to your wishes.
<G-vec00301-002-s151><attend.begleiten><de> Lehrer für Englisch als Fremdsprache (EAL) und Deutsch als Fremdsprache (DaF) begleiten Schüler im Unterricht, um ihnen diese zusätzliche Förderung entsprechend des von dem EAL/DAF Team erstellten Entwicklungsplans zu ermöglichen.
<G-vec00301-002-s151><attend.begleiten><en> Teachers of English as an Additional Language (EAL) and Deutsch als Fremdsprache (DaF) (German as a Foreign Language) attend classes with students who require additional support or whose needs have been identified through assessment monitoring from our EAL core teacher.
