<G-vec00092-001-s057><call.bezeichnen><de> Ich würde die Angebote der Tantra-Szene, die ich kennengelernt habe, nicht als das bezeichnen wollen.
<G-vec00092-001-s057><call.bezeichnen><en> The offers of the tantric scene, which I got to know, I would not call the same.
<G-vec00092-001-s058><call.bezeichnen><de> Ich habe es gelesen und würde es als revolutionär bezeichnen.
<G-vec00092-001-s058><call.bezeichnen><en> Well, I read it and I would call it revolutionary.
<G-vec00092-001-s059><call.bezeichnen><de> So etwas würden WIR als hochkonzentriert bezeichnen.
<G-vec00092-001-s059><call.bezeichnen><en> That is something we would call highly concentrated.
<G-vec00092-001-s060><call.bezeichnen><de> Was die Leute heutzutage als Praxis bezeichnen, ist keine wirkliche Praxis mehr.
<G-vec00092-001-s060><call.bezeichnen><en> What people call practice these days is not really practice.
<G-vec00092-001-s061><call.bezeichnen><de> Ich würde das als »repressive Toleranz« bezeichnen, ein Prinzip, das auch heute noch zu beobachten ist.
<G-vec00092-001-s061><call.bezeichnen><en> I would call it repressive tolerance, and it's still the case today.
<G-vec00092-001-s062><call.bezeichnen><de> Als „mystischen Vogel“ bezeichnen die Rumänen den Auerhahn.
<G-vec00092-001-s062><call.bezeichnen><en> “Mystical bird” the Romanians call the capercaillie.
<G-vec00092-001-s063><call.bezeichnen><de> Zunächst löste die Einführung der gemeinsamen Währung eine enorme Kapitalbewegung in die Länder aus, die wir heute als PIIGS oder Peripheriestaaten bezeichnen.
<G-vec00092-001-s063><call.bezeichnen><en> First, the introduction of the common currency led to a huge movement of capital into those countries that we today call PIIGS or periphery countries.
<G-vec00092-001-s064><call.bezeichnen><de> Wir können sie nur als bösartige Polizisten bezeichnen.
<G-vec00092-001-s064><call.bezeichnen><en> We can only call them evil policemen.
<G-vec00092-001-s065><call.bezeichnen><de> """Ich wünschte, du würdest ihn als das bezeichnen, was er ist"", sagte sie."
<G-vec00092-001-s065><call.bezeichnen><en> """I wish you'd call it what it is,"" she said."
<G-vec00092-001-s066><call.bezeichnen><de> "Manche würden das jetzt als ""Fortschritt"" oder auf neudeutsch ""Innovation"" bezeichnen."
<G-vec00092-001-s066><call.bezeichnen><en> "Some people would call that ""progress"" or ""innovation""."
<G-vec00092-001-s067><call.bezeichnen><de> Ein Wesen kann auch einer unheilbaren Krankheit ausgesetzt sein, die den Organismus oder Körper unaufhaltsam seinem Untergang, d.h. dem, was wir als „Tod“ bezeichnen, entgegenführt, und die Situation ist damit körperlich gesehen hoffnungslos, aber trotzdem lodert hinter dieser Hoffnungslosigkeit eine kleine Flamme aus dem Paradies.
<G-vec00092-001-s067><call.bezeichnen><en> "A being can also have an incurable illness that is rapidly leading towards the destruction of the organism or body, towards what we call ""death"", and from the point of view of the body the situation is hopeless, but behind this hopelessness there is still burning a tiny flame from Paradise."
<G-vec00092-001-s068><call.bezeichnen><de> "Wenn ein Wort mehrere verschiedene Definitionen hat, können Sie Ihr Verstehen dieses Wortes nicht nur auf eine Definition beschränken und es als ""verstanden"" bezeichnen."
<G-vec00092-001-s068><call.bezeichnen><en> "When a word has several different definitions, you cannot limit your understanding of the word to one definition only and call the word ""understood."""
<G-vec00092-001-s069><call.bezeichnen><de> "Ja, das Genre an sich ist vornehmlich von den 80ern beeinflusst, aber hier hört man sofort, dass dies kein Hard Rock aus den 80ern ist, sondern etwas, dass ich persönlich als ""Modern Hard Rock"" bezeichnen würde."
<G-vec00092-001-s069><call.bezeichnen><en> "Yeah, the genre itself is mainly influenced by the 80s but if you listen to Santa Cruz, you hear right away that it`s not Hard Rock from the 80s; it`s rather something I would call ""Modern Hard Rock""."
<G-vec00092-001-s070><call.bezeichnen><de> Vielleicht sind aber auch die schlecht geschriebenen Dialoge daran schuld, dass man das Schauspiel selten als gelungen bezeichnen kann.
<G-vec00092-001-s070><call.bezeichnen><en> But maybe the badly written dialogues are to blame that you seldom can call the acting well done.
<G-vec00092-001-s071><call.bezeichnen><de> Nur eine willentliche Konzentration in einer besonderen Anordnung ergibt das, was wir als Körper bezeichnen – spontan fühlt er sich immer so (er hält nicht inne, sich zu beobachten, aber wenn etwas ihn veranlaßt, sich zu betrachten, spürt er es spontan so).
<G-vec00092-001-s071><call.bezeichnen><en> What people call this body is merely the result of a willed concentration organized in a specific way; that's how it spontaneously feels, all the time (not that it's observing itself, but if something forces it to observe itself, that's what it spontaneously feels).
<G-vec00092-001-s072><call.bezeichnen><de> "Daniel Pauly zeigt uns in einem Vortrag während der Mission Blue, dass wir jedes Mal, wenn sich die Zahlen der Normwerte nach unten bewegen, wir sie als das neue ""Normal"" bezeichnen."
<G-vec00092-001-s072><call.bezeichnen><en> "And yet, as Daniel Pauly shows us onstage at Mission Blue, each time the baseline drops, we call it the new ""normal."""
<G-vec00092-001-s073><call.bezeichnen><de> Es ist interessant, denn die Aktion ist sehr machtvoll, aber ich kann diese Zeit nicht als erfreulich bezeichnen.
<G-vec00092-001-s073><call.bezeichnen><en> It is interesting because the action is very powerful, but I can't call it pleasant.
<G-vec00092-001-s074><call.bezeichnen><de> "Micha Brum-lik stellt dar, dass wir vor allem Levinas eine Würdigung dessen verdanken, was man als ""Ostjudentum"" bezeichnen könnte."
<G-vec00092-001-s074><call.bezeichnen><en> "Micha Brumlik notes that, above all it is Levinas to whom we owe an appreciation of what one could call ""eastern European Jewry""."
<G-vec00092-001-s075><call.bezeichnen><de> Bei Springsteen würde ich diese Titel als sehr beliebig bezeichnen.
<G-vec00092-001-s075><call.bezeichnen><en> With Springsteen, I would call this title very arbitrary.
<G-vec00092-001-s304><call.bezeichnen><de> Die katholische Kirche und andere Eiferer bezeichnen Abtreibung immer noch als „Mord“, in den USA wurden Ärzte ermordet, die Abtreibungen durchführten.
<G-vec00092-001-s304><call.bezeichnen><en> The Catholic church and other bigots continue to call abortion “murder.” In the U.S., doctors who carry out abortions have been murdered.
<G-vec00092-001-s305><call.bezeichnen><de> Fast die Hälfte, 48 Prozent, sagten, dass sie sich als demokratische(r) Sozialist(in) oder Sozialist(in) bezeichnen würden, verglichen mit 39 Prozent, die sagten, dass sie sich als beides betrachteten.
<G-vec00092-001-s305><call.bezeichnen><en> Almost half, 48 percent, said they would call themselves a democratic socialist or socialist, compared to 39 percent who said they identified as neither.
<G-vec00092-001-s306><call.bezeichnen><de> Während der vergangenen anderthalb Jahrzehnte wart ihr einer Reihe subtiler Veränderungen unterworfen, die wir generell als Aufstiegs-Symptome bezeichnen.
<G-vec00092-001-s306><call.bezeichnen><en> Over the past decade and a half, you have been subjected to a number of subtle changes that we generally call Ascension Symptoms.
<G-vec00092-001-s307><call.bezeichnen><de> "Anwalt McMahon sagte: ""In unserer Anklage behaupten wir, dass es verschiedene Agenten, Spione oder wie man diese Personen auch immer bezeichnen will, gibt, die zu den Botschaften und Konsulaten hier in Amerika in Beziehung stehen."
<G-vec00092-001-s307><call.bezeichnen><en> "Attorney McMahon said, ""In our lawsuit we have alleged there are various agents, spies-- whatever you want to call them--who are attached to the embassies and consulates here in America."
<G-vec00092-001-s308><call.bezeichnen><de> Denn diese Kraft wird immer offensichtlicher – diese Kraft der Wahrheit –, und natürlich bedarf das menschliche Denken, das von kindlicher Beschaffenheit ist (es hat zum supramentalen Denken die gleiche Beziehung wie es das, was man als animalisches Denken oder Empfinden bezeichnen kann, dem menschlichen Empfinden und Denken gegenüber hegt), beinahe eines Aberglaubens (Aberglaube ist ein häßliches Wort für etwas, das nicht eigentlich häßlich, sondern ein unwissender, naiver und sehr vertrauensvoller Glaube ist), und genau dieser Glaube läßt einen dann an Wunder glauben, sobald man den Einfluß einer Kraft fühlt – er läßt einen denken, daß das Supramental sich bald manifestiert und man supramental wird und...
<G-vec00092-001-s308><call.bezeichnen><en> Because this Power is becoming more and more obvious – this Truth-Power – and naturally human thought, which is childish (it has the same attitude towards supramental thought as what we may call animal thought or sentiment has towards human thought or sentiment), has almost a need for superstition (“superstition” is an ugly word for something that's not ugly: it's an ignorant, ingenuous and very trusting faith), and, well, as soon as you feel the influence of a Power, that faith makes you believe in the miracle, it makes you believe that the Supramental is going to manifest now, that you are going to become supramental, and that...
<G-vec00092-001-s309><call.bezeichnen><de> Das Ergebnis nach Kapitalkosten bezeichnen wir als Business Value Contribution, kurz BVC.
<G-vec00092-001-s309><call.bezeichnen><en> We call the resulting earnings after cost of capital the business value contribution, or BVC .
<G-vec00092-001-s310><call.bezeichnen><de> Die Schiiten bezeichnen alle Nachkommen des Propheten Muhammad als Imame und schreiben ihnen einen quasi-göttlichen Status zu.
<G-vec00092-001-s310><call.bezeichnen><en> "The Shia call the male descendants of the Prophet Muhammad ""Imams"" and ascribe to them a quasi-divine status."
<G-vec00092-001-s311><call.bezeichnen><de> "Wir haben vielleicht keinen Namen dafür; ein Wurm hat keinen Namen für Wasser, aber er weiß, was das ist – etwas, das wir mit dem Wort ""Wasser"" bezeichnen würden."
<G-vec00092-001-s311><call.bezeichnen><en> "We don't have to have a name for it; a worm doesn't have a name for water, but it knows that that's water – what we would call water with the word ""water."""
<G-vec00092-001-s312><call.bezeichnen><de> Das ist schon eine taktische Frage, wie sie sie bezeichnen werden, aber am Ende wird es nur einen geben.
<G-vec00092-001-s312><call.bezeichnen><en> What they call them is a tactical question, but in the end they will agree to only run a single candidate.
<G-vec00092-001-s313><call.bezeichnen><de> Es wird angenommen, dass Sie ihre Kinder nicht als verstorbene Verwandte bezeichnen können.
<G-vec00092-001-s313><call.bezeichnen><en> It is believed that you can not call their children the names of deceased relatives.
<G-vec00092-001-s314><call.bezeichnen><de> Beim erreichen von Mayfield Bore müssen wir ab der Mühe lachen, die wir hatten um vorher genügend Brennholz zu sammeln.... es hat hier so viele Bäume, dass man es beinahe schon als Wald bezeichnen muss.
<G-vec00092-001-s314><call.bezeichnen><en> When we reach Mayfield Bore we get a bit of a laugh about our efforts before.... there are so many trees here one must almost call it a forest.
<G-vec00092-001-s315><call.bezeichnen><de> Seltsam, beim geringsten Nachlassen in der Haltung, zum Beispiel in einer Sekunde der Vergessenheit (was man als Vergessenheit bezeichnen könnte, d.h. die alte Haltung von früher, die alte irdische Seinsgewohnheit), spürt der Körper sofort, daß er sich auflösen wird.
<G-vec00092-001-s315><call.bezeichnen><en> "Strangely, as soon as there's the slightest slackening in the attitude, for instance, a second of forgetfulness (what I might call ""forgetfulness,"" that is, the former old habit, the old terrestrial habit of being), the body instantly feels about to be dissolved."
<G-vec00092-001-s316><call.bezeichnen><de> «Die interessieren sich doch nur für die Gesunden, weil die nichts kosten.» Wäre dem tatsächlich so, müssten wir uns als «Gesundenkasse» bezeichnen.
<G-vec00092-001-s316><call.bezeichnen><en> """They are only interested in healthy individuals because they don't cost anything."" If this was actually the case, we would have to call ourselves a ""healthy person insurer""."
<G-vec00092-001-s317><call.bezeichnen><de> Hier wird das Programm für das dreitägige Zertifizierungsseminar vorgestellt, deren Teilnehmerinnen und Teilnehmer sich nach der erfolgreichen Prüfungsteilnahme als HICHERT® IBCS Certified Consultant (HCC) bezeichnen können.
<G-vec00092-001-s317><call.bezeichnen><en> Here we present the program for the first three-day certification seminar. Following successful examination, participants have the right to call themselves HICHERT Certified Consultants (HCC).
<G-vec00092-001-s318><call.bezeichnen><de> Als ich damals diese Gedanken erwog und meine Pläne faßte, hatte ich zwar schon Verschiedenes geschrieben und an die Oeffentlichkeit gegeben, aber es war mir noch nicht eingefallen, mich als Schriftsteller oder gar als Künstler zu bezeichnen.
<G-vec00092-001-s318><call.bezeichnen><en> At this time, when I had considered these ideas and made my plans, I had already written and published various things, but I would not have dared to call myself an novelist or even an artist yet.
<G-vec00092-001-s319><call.bezeichnen><de> Produkte wie der Solaris befinden sich in einem Markt, den wir als Synthesizer-Nischenmarkt bezeichnen, sie sind somit für einen fachkundigeren Musiker gedacht.
<G-vec00092-001-s319><call.bezeichnen><en> Products like the Solaris are in what we call the boutique synthesizer market, and so are for a more specialized customer.
<G-vec00092-001-s320><call.bezeichnen><de> "Das bezeichnen wir dann als das ""psychische Wesen""."
<G-vec00092-001-s320><call.bezeichnen><en> "This is what we call the ""psychic being."""
<G-vec00092-001-s321><call.bezeichnen><de> "Diese Entdeckung machte ich mit fünfzehn oder vielleicht siebzehn; ich begann, diese ""Gaben"" klar zu sehen (wenn man das als Gaben bezeichnen kann), die mir vom Vater, der Mutter, den Großeltern, der Erziehung, den Leuten, die sich um mich kümmerten, übermittelt wurden – kurz, dieses ganze Morastloch, in dem man Hals über Kopf landet."
<G-vec00092-001-s321><call.bezeichnen><en> That discovery I made at the age of about fifteen or sixteen, or seventeen. I began to see clearly all the “gifts” (if we can call them that) that came from father, mother, parents, grandparents, education, people who looked after me, that whole mudhole, as it were, into which you fall headfirst.
<G-vec00092-001-s322><call.bezeichnen><de> Wenn ihr euch in einem solchen Zustand befindet, dann wird der Krebs durch diese Proteine ausgelöst, die sie als 52 und 58 bezeichnen.
<G-vec00092-001-s322><call.bezeichnen><en> Now, when you are in that state, the cancer is triggered by those proteins, which they call as 52 and 58.
<G-vec00060-001-s423><indicate.bezeichnen><de> Die ersten zwei Ziffern bezeichnen das verwendete Kaliber.
<G-vec00060-001-s423><indicate.bezeichnen><en> The first two digits indicate the used caliber.
<G-vec00060-001-s424><indicate.bezeichnen><de> Die am Rand aufgeführten Hinweise auf Artikel oder Regeln ohne zusätzliche Angaben bezeichnen die Artikel oder Regeln des Europäischen Patentübereinkommens, auf die sich das Gesagte stützt.
<G-vec00060-001-s424><indicate.bezeichnen><en> Marginal references to articles and rules without further identification indicate the Articles or Rules of the European Patent Convention which provides authority for what is stated.
<G-vec00060-001-s425><indicate.bezeichnen><de> Der Begriff Kundalini weist nicht auf etwas hin, das physisch im Sitz des Menschen lokalisiert werden kann, so wie das Wort „Intelligenz“ und das Wort „Wille“ nicht Dinge bezeichnen, die man in den Gehirnzellen oder der Wirbelsäule lokalisieren kann, um sie mit einem Röntgenbild zu entdecken.
<G-vec00060-001-s425><indicate.bezeichnen><en> The term Kundalini does not indicate something that is located physically in the seat of man, just as the word 'intelligence' and the word `will' do not indicate things that can be located in the brain cells or the spinal column to be detected by a radiograph.
<G-vec00060-001-s426><indicate.bezeichnen><de> """Wide Temperature"" (ein breiter Temperaturbereich) ist ein von der IPC-Branche angenommener Begriff, um Computer (oder Komponenten) zu bezeichnen, die in extremeren Umgebungen arbeiten können als in Ihrem standardmäßigen Bürogebäude."
<G-vec00060-001-s426><indicate.bezeichnen><en> Wide Temperature is a term that's been adopted by the IPC industry to indicate that a computer (or component) can operate in more extreme environments than your standard office building.
<G-vec00060-001-s427><indicate.bezeichnen><de> Wenn sie im Ausland wohnen, haben sie in der Schweiz ein Zustellungsdomizil zu bezeichnen, es sei denn, das Völkerrecht gestatte der Behörde, Mitteilungen im betreffenden Staat durch die Post zuzustellen.
<G-vec00060-001-s427><indicate.bezeichnen><en> If they live abroad, they must indicate a domicile for service in Switzerland, unless international law permits the authority to serve notices in the state concerned by post.
<G-vec00060-001-s428><indicate.bezeichnen><de> Die vorläufigen Forschungen bezeichnen, dass sich die Fleischer und die Arbeitsschlachthöfe in der Gefahr für den Krebs der Lunge und des Krebses anderer Bereiche des Systems der Atmungsorgane ebenso, wie einiger Leukosen befinden.
<G-vec00060-001-s428><indicate.bezeichnen><en> Preliminary studies indicate that butchers and slaughterhouse workers are at risk for lung cancer and cancer of other parts of the respiratory system as well as some leukemias.
<G-vec00060-001-s429><indicate.bezeichnen><de> 1 Der Kotierungsprospekt hat das auf das Sicherungsversprechen anwendbare Recht und den Gerichtsstand zu bezeichnen.
<G-vec00060-001-s429><indicate.bezeichnen><en> 1 The listing prospectus must indicate the law and place of jurisdiction that apply to the guarantee commitment.
<G-vec00060-001-s430><indicate.bezeichnen><de> Positive Werte bezeichnen dabei ein entsprechendes Übermaß, negative ein Spiel.
<G-vec00060-001-s430><indicate.bezeichnen><en> Positive values indicate an interference, negative values indicate a
<G-vec00060-001-s431><indicate.bezeichnen><de> 2 Wird die asylsuchende Person durch mehrere Bevollmächtigte vertreten und bezeichnen diese keine gemeinsame Zustelladresse, so stellt die Behörde ihre Mitteilungen der von der asylsuchenden Person zuerst bezeichneten bevollmächtigten Person zu.
<G-vec00060-001-s431><indicate.bezeichnen><en> 2 Â If the asylum seeker is represented by several agents and if these do not indicate a joint address for service, the authority shall address its communications to the first agent authorised by the asylum seeker.
<G-vec00060-001-s432><indicate.bezeichnen><de> Obwohl nicht alle Forschungen bezeichnen, dass die Programme der Vorbereitung BMD vergrossern konnen, vermutet die Mehrheit wirklich, dass tragend die Ladung der Aktivitat, solche wie die Lage, das Gehen, und die Ausbildung der Immunitat die Norm des Verlustes der Knochenmasse, und so verringern konnen, die Masse des Knochens wahrend des Alterns unterstutzen.
<G-vec00060-001-s432><indicate.bezeichnen><en> Although not all studies indicate that exercise programs can increase BMD, most do suggest that load-bearing activities such as standing, walking, and resistance training can reduce the rate of bone loss, and thereby maintain bone mass during aging.
<G-vec00060-001-s433><indicate.bezeichnen><de> Die drei Nummern bezeichnen demnach die Reihe, die Serie und die Position des Setzlings in der Reihe.
<G-vec00060-001-s433><indicate.bezeichnen><en> The three numbers therefore indicate: the row, the series and the number of the vine in the row.
<G-vec00060-001-s434><indicate.bezeichnen><de> Die europäischen Premium-Webseiten fälschlicherweise bezeichnen die Reichweite des Strahls, in dem dieses Paket sendet.
<G-vec00060-001-s434><indicate.bezeichnen><en> The European satellite sites erroneously indicate the coverage area of the beam, which broadcasts this package.
<G-vec00060-001-s435><indicate.bezeichnen><de> v) Konditionalsätze: Konditionale Nebensätze erläutern entweder die Bedingung, unter der der im Hauptsatz bezeichnete Sachverhalt zutrifft, oder sie bezeichnen eine hypothetische Voraussetzung für eine im Hauptsatz gemachte Aussage (vom Typ wenn - dann).
<G-vec00060-001-s435><indicate.bezeichnen><en> v) Conditional Clauses: Conditional subordinate clauses explain the conditions for which the facts of the main clause hold true or they indicate a hypothetical requirements for a statement of the main clause (of the type if... then).
<G-vec00060-001-s436><indicate.bezeichnen><de> Sofern der Gesuchsteller oder der Geschäftsführer seinen Wohnsitz im Ausland hat, ist eine inländische Zustelladresse zu bezeichnen.
<G-vec00060-001-s436><indicate.bezeichnen><en> If the applicant of the executive manager are domiciled abroad, it is necessary to indicate his/her inland postal address.
<G-vec00060-001-s437><indicate.bezeichnen><de> Beim ersten Hahnenschrei sollten zwei Reitertrupps respektive von Siena und von Florenz losreiten; der Ort, an dem sie sich treffen würden, sollte die Grenze zwischen den Gebieten der beiden Städte bezeichnen.
<G-vec00060-001-s437><indicate.bezeichnen><en> At the crow of a cockerel two groups left respectively from Siena and Florence; the place in which they would meet would indicate the confines of the two cities.
<G-vec00060-001-s438><indicate.bezeichnen><de> Eckige Klammern werden ebenfalls nicht mitgeschrieben; sie bezeichnen Kommandobestandteile, die auch weggelassen werden können.
<G-vec00060-001-s438><indicate.bezeichnen><en> Squared brackets don't have to be written; they indicate parts of a meta command that are optional and can be omitted.
<G-vec00060-001-s439><indicate.bezeichnen><de> Und doch verwende ich dieses Wort „Du“, weil es in meiner menschlichen Erfahrung das am wenigsten unangemessene ist, um jene unbekannte Gegenwart zu bezeichnen, die vollkommen über meine menschliche Erfahrung hinausgeht.
<G-vec00060-001-s439><indicate.bezeichnen><en> I use this word you because it is the least inadequate in my experience as a human being to indicate that unknown presence which is beyond comparison, more than my experience as a human being.
<G-vec00060-001-s440><indicate.bezeichnen><de> "Der Begriff Kundalini weist nicht auf etwas hin, das physisch im Sitz des Menschen lokalisiert werden kann, so wie das Wort ""Intelligenz"" und das Wort ""Wille"" nicht Dinge bezeichnen, die man in den Gehirnzellen oder der Wirbelsäule lokalisieren kann, um sie mit einem Röntgenbild zu entdecken."
<G-vec00060-001-s440><indicate.bezeichnen><en> The term Kundalini does not indicate something that is located physically in the seat of man, just as the word 'intelligence' and the word `will' do not indicate things that can be located in the brain cells or the spinal column to be detected by a radiograph.
<G-vec00060-001-s441><indicate.bezeichnen><de> "Nun, nach diesen Präliminarien, die gleichzeitig zu lang sind für die kurze Zeit, die uns zur Verfügung steht, und zu kurz, um nicht oberflächlich zu bleiben, lassen Sie mich drei Richtungen bezeichnen, die mir aus dieser Perspektive von besonderer Bedeutung scheinen: Eine dieser Richtungen beschäftigt sich mit den Dilemmata, den dichotomisierten Formulierungen des Universalismus in der Philosophie; eine zweite mit der immanenten Ambivalenz der Institution des Universalen oder des Universalen als ""Wahrheit""; die dritte schließlich handelt von dem, was ich in gleichsam Weber'scher Manier als die Verantwortung (oder Verantwortungen) einer ""Politik des Universalen"", der sich viele von uns verpflichtet fühlen, bezeichnen würde."
<G-vec00060-001-s441><indicate.bezeichnen><en> "And now, after these preliminaries, at the same time too long given the short time we have been allowed, and yet too rapid not to remain superficial, let me indicate the three directions that seem to me particularly significant from this point of view. One direction deals with the dilemmas or dichotomized enunciations of universalism in philosophy; a second deals with the intrinsic ambivalence of the institution of the universal, or the universal as ""truth""; finally, a third one deals with what, in a quasi-Weberian manner, I would like to call the responsibility (or responsibilities) involved in a ""politics of the universal"", to which many of us are committed."
<G-vec00228-002-s157><appoint.bezeichnen><de> Er bezeichnet den Sekretär, der dem Verwaltungsrat nicht angehören muss.
<G-vec00228-002-s157><appoint.bezeichnen><en> It shall appoint the secretary, who does not need to be a Board member.
<G-vec00228-002-s158><appoint.bezeichnen><de> Er bezeichnet diejenigen Personen, denen die rechtsverbindliche Unterschrift für die Gesellschaft zusteht.
<G-vec00228-002-s158><appoint.bezeichnen><en> The Board of Directors shall appoint persons duly authorized to act as signatories of the Company.
<G-vec00228-002-s057><nominate.bezeichnen><de> Sobald die revidierte Brüssel-I-Verordnung anwendbar sein wird, wird sie sich auch auf Gerichtsstandsvereinbarungen erstrecken, die von Parteien geschlossen wurden, die zwar nicht in der EU domiziliert sind, die in der Vereinbarung aber ein Gericht eines EU-Mitgliedstaates als ausschließlich zuständig bezeichneten.
<G-vec00228-002-s057><nominate.bezeichnen><en> Once the revised Brussels I Regulation becomes applicable, it will also extend to exclusive choice of court agreements concluded by parties not domiciled in the EU, but which nominate a member state court. 2.
<G-vec00347-002-s067><accuse.bezeichnen><de> Wenn Politiker diese Organisationen als Fake News bezeichnen, liegt das wahrscheinlich daran, dass die Wahrheit nicht ihre Zwecke erfüllt.
<G-vec00347-002-s067><accuse.bezeichnen><en> If politicians accuse those organisations of fake news, it's probably because the truth doesn't suit their purpose.
<G-vec00272-003-s323><call_for.bezeichnen><de> Bahlsen: So könnte man ihn bezeichnen.
<G-vec00272-003-s323><call_for.bezeichnen><en> Bahlsen: You could call him that.
<G-vec00272-003-s324><call_for.bezeichnen><de> Es ist mir daher unverständlich das die Gäste das Haus als nicht sauber bezeichnen.
<G-vec00272-003-s324><call_for.bezeichnen><en> It is therefore incomprehensible that the guests call me the house as not clean.
<G-vec00272-003-s325><call_for.bezeichnen><de> Weil es mittlerweile bereits vier Ishins gibt, von daher kann man es wohl getrost als Ladenkette bezeichnen.
<G-vec00272-003-s325><call_for.bezeichnen><en> Because there are already four of those restaurants, so I guess you can call it a chain.
<G-vec00272-003-s326><call_for.bezeichnen><de> Sowohl äußere Gestaltung als auch Bibelwort legten nahe, diese Glocke als "Christusglocke" zu bezeichnen.
<G-vec00272-003-s326><call_for.bezeichnen><en> External creation as well as quotation from the Bible urged to call this bell "Christ's bell".
<G-vec00272-003-s327><call_for.bezeichnen><de> Diese positive Bestätigung ästhetischer Interventionen war Motivation, die aktuellen Trends genauer zu untersuchen und eine Analyse auf Basis der historischen Entwicklung durchzuführen, die notwendigerweise unserer Auffassung nach zu einer veränderten Philosophie der ästhetischen Medizin führen muss, die wir mit dem Begriff Kompositorische Ästhetik bezeichnen wollen.
<G-vec00272-003-s327><call_for.bezeichnen><en> This positive confirmation of aesthetic interventions was the motivation to examine current trends more closely and to carry out an analysis based on historical developments, which, in our opinion, must necessarily lead to a changed philosophy of aesthetic medicine, which we would like to call Compositional Aesthetics.
<G-vec00272-003-s328><call_for.bezeichnen><de> Entsprechend bezeichnen die Juden Gott als Vater, im Christentum hat Gott sogar einen menschlichen Sohn gezeugt.
<G-vec00272-003-s328><call_for.bezeichnen><en> Thus the Jews call God the Father, and in Christianity God has even put forth a human Son.
<G-vec00272-003-s329><call_for.bezeichnen><de> Viele Wissenschaftler beschrieben bereits den Bereich, den wir als Informationsfeld bezeichnen, als ein Feld der mentalen und physischen Wechselwirkungen.
<G-vec00272-003-s329><call_for.bezeichnen><en> Many scientist have described what we call the information field as a "field of mental and physical interchange".
<G-vec00272-003-s330><call_for.bezeichnen><de> Als Boxermotor kann man ihn wohl nicht bezeichnen, weil gegenüberliegende Zylinder auf einem Pleuelzapfen laufen und damit immer die gleiche Bewegung ausführen.
<G-vec00272-003-s330><call_for.bezeichnen><en> As boxer engine you can not call it well, because opposite cylinders run on a connecting rod pin and thus always run the same movement.
<G-vec00272-003-s331><call_for.bezeichnen><de> Beim Wrestling mag zwar vieles Fake sein, aber immerhin haben die genügend Eier, ihren Ring als quadratischen Kreis zu bezeichnen.
<G-vec00272-003-s331><call_for.bezeichnen><en> Share On pinterest Pin Wrestling might be fake, but at least it has the chops to call it a squared circle.
<G-vec00272-003-s332><call_for.bezeichnen><de> Ich würde unsere ganze Gruppe als „Blauhelme“ bezeichnen, in Analogie zu den Friedensstiftern der UNO.
<G-vec00272-003-s332><call_for.bezeichnen><en> I would call our group “blue helmets” as an analogy to UN peacekeepers.
<G-vec00272-003-s333><call_for.bezeichnen><de> Nun kann ich mich selbst als bilingual bezeichnen, denn in meinem Alltag gebrauche ich sowohl Englisch als auch Deutsch.
<G-vec00272-003-s333><call_for.bezeichnen><en> I am now able to call myself bilingual, as I use both English and German in my daily life.
<G-vec00272-003-s334><call_for.bezeichnen><de> Wir bezeichnen sie stets als LR44-Batterien.
<G-vec00272-003-s334><call_for.bezeichnen><en> We always call them LR44 on Lovehoney.com
<G-vec00272-003-s335><call_for.bezeichnen><de> Man könnte Ihn als Hippie bezeichnen.
<G-vec00272-003-s335><call_for.bezeichnen><en> You can call Him a hippie, all right!
<G-vec00272-003-s336><call_for.bezeichnen><de> Es schließt auch diejenigen im Raum ein, die sich als Heiler bezeichnen, denn sie haben die gleiche Aufgabe wie die Channeler oder Lehrer, nämlich, eine wahrgenommene metaphorische Botschaft in etwas zu übersetzen, was 3D und praktisch ist.
<G-vec00272-003-s336><call_for.bezeichnen><en> It also extends to those who call themselves "healers" in this room, for they have the same task as the channeller or the teacher, and that is translating a perceptual, metaphörical message into something that is 3D and practical.
<G-vec00272-003-s337><call_for.bezeichnen><de> Mit unseren fast 30 Jahren Erfahrung und bereits realisierte, erfolgreiche Projekte können wir uns mit Recht als Solid Surface-Experten bezeichnen.
<G-vec00272-003-s337><call_for.bezeichnen><en> With our nearly 30 years of experience and extensive series of delivered projects, we can rightly call ourselves solid surface experts.
<G-vec00272-003-s338><call_for.bezeichnen><de> Wenn der Wert einer dieser Methoden einen bestimmten Grenzwert überschreitet, bezeichnen wir diesen Moment als „abnormal“ entsprechend der jeweiligen Methode.
<G-vec00272-003-s338><call_for.bezeichnen><en> If the score of any method is above a certain limit, then we call that moment “abnormal” according to that method.
<G-vec00272-003-s339><call_for.bezeichnen><de> Charakteristisch für Taiwan ist die auf der Landkarte eine Süßkartoffel ähnelnde Form, aufgrund deren sich die Min Nan Ureinwohner auch als „Kinder der Süßkartoffel“ bezeichnen.
<G-vec00272-003-s339><call_for.bezeichnen><en> The shape of the main island of Taiwan is similar to a sweet potato seen in a south-to-north direction, and therefore, Taiwanese (especially Min Nan speakers) often call themselves "children of the Sweet Potato.
<G-vec00272-003-s340><call_for.bezeichnen><de> Mit dem Ausdruck "böse Geister" bezeichnen wir Satan und all seine bösen Geister.
<G-vec00272-003-s340><call_for.bezeichnen><en> What we call "evil spirits" are Satan and all the evil spirit men on his side.
<G-vec00272-003-s341><call_for.bezeichnen><de> Als Top-Platz würde ich diesen Platz nicht bezeichnen.
<G-vec00272-003-s341><call_for.bezeichnen><en> As a top place I would not call this place.
<G-vec00361-003-s323><call_on.bezeichnen><de> Bahlsen: So könnte man ihn bezeichnen.
<G-vec00361-003-s323><call_on.bezeichnen><en> Bahlsen: You could call him that.
<G-vec00361-003-s324><call_on.bezeichnen><de> Es ist mir daher unverständlich das die Gäste das Haus als nicht sauber bezeichnen.
<G-vec00361-003-s324><call_on.bezeichnen><en> It is therefore incomprehensible that the guests call me the house as not clean.
<G-vec00361-003-s325><call_on.bezeichnen><de> Weil es mittlerweile bereits vier Ishins gibt, von daher kann man es wohl getrost als Ladenkette bezeichnen.
<G-vec00361-003-s325><call_on.bezeichnen><en> Because there are already four of those restaurants, so I guess you can call it a chain.
<G-vec00361-003-s326><call_on.bezeichnen><de> Sowohl äußere Gestaltung als auch Bibelwort legten nahe, diese Glocke als "Christusglocke" zu bezeichnen.
<G-vec00361-003-s326><call_on.bezeichnen><en> External creation as well as quotation from the Bible urged to call this bell "Christ's bell".
<G-vec00361-003-s327><call_on.bezeichnen><de> Diese positive Bestätigung ästhetischer Interventionen war Motivation, die aktuellen Trends genauer zu untersuchen und eine Analyse auf Basis der historischen Entwicklung durchzuführen, die notwendigerweise unserer Auffassung nach zu einer veränderten Philosophie der ästhetischen Medizin führen muss, die wir mit dem Begriff Kompositorische Ästhetik bezeichnen wollen.
<G-vec00361-003-s327><call_on.bezeichnen><en> This positive confirmation of aesthetic interventions was the motivation to examine current trends more closely and to carry out an analysis based on historical developments, which, in our opinion, must necessarily lead to a changed philosophy of aesthetic medicine, which we would like to call Compositional Aesthetics.
<G-vec00361-003-s328><call_on.bezeichnen><de> Entsprechend bezeichnen die Juden Gott als Vater, im Christentum hat Gott sogar einen menschlichen Sohn gezeugt.
<G-vec00361-003-s328><call_on.bezeichnen><en> Thus the Jews call God the Father, and in Christianity God has even put forth a human Son.
<G-vec00361-003-s329><call_on.bezeichnen><de> Viele Wissenschaftler beschrieben bereits den Bereich, den wir als Informationsfeld bezeichnen, als ein Feld der mentalen und physischen Wechselwirkungen.
<G-vec00361-003-s329><call_on.bezeichnen><en> Many scientist have described what we call the information field as a "field of mental and physical interchange".
<G-vec00361-003-s330><call_on.bezeichnen><de> Als Boxermotor kann man ihn wohl nicht bezeichnen, weil gegenüberliegende Zylinder auf einem Pleuelzapfen laufen und damit immer die gleiche Bewegung ausführen.
<G-vec00361-003-s330><call_on.bezeichnen><en> As boxer engine you can not call it well, because opposite cylinders run on a connecting rod pin and thus always run the same movement.
<G-vec00361-003-s331><call_on.bezeichnen><de> Beim Wrestling mag zwar vieles Fake sein, aber immerhin haben die genügend Eier, ihren Ring als quadratischen Kreis zu bezeichnen.
<G-vec00361-003-s331><call_on.bezeichnen><en> Share On pinterest Pin Wrestling might be fake, but at least it has the chops to call it a squared circle.
<G-vec00361-003-s332><call_on.bezeichnen><de> Ich würde unsere ganze Gruppe als „Blauhelme“ bezeichnen, in Analogie zu den Friedensstiftern der UNO.
<G-vec00361-003-s332><call_on.bezeichnen><en> I would call our group “blue helmets” as an analogy to UN peacekeepers.
<G-vec00361-003-s333><call_on.bezeichnen><de> Nun kann ich mich selbst als bilingual bezeichnen, denn in meinem Alltag gebrauche ich sowohl Englisch als auch Deutsch.
<G-vec00361-003-s333><call_on.bezeichnen><en> I am now able to call myself bilingual, as I use both English and German in my daily life.
<G-vec00361-003-s334><call_on.bezeichnen><de> Wir bezeichnen sie stets als LR44-Batterien.
<G-vec00361-003-s334><call_on.bezeichnen><en> We always call them LR44 on Lovehoney.com
<G-vec00361-003-s335><call_on.bezeichnen><de> Man könnte Ihn als Hippie bezeichnen.
<G-vec00361-003-s335><call_on.bezeichnen><en> You can call Him a hippie, all right!
<G-vec00361-003-s336><call_on.bezeichnen><de> Es schließt auch diejenigen im Raum ein, die sich als Heiler bezeichnen, denn sie haben die gleiche Aufgabe wie die Channeler oder Lehrer, nämlich, eine wahrgenommene metaphorische Botschaft in etwas zu übersetzen, was 3D und praktisch ist.
<G-vec00361-003-s336><call_on.bezeichnen><en> It also extends to those who call themselves "healers" in this room, for they have the same task as the channeller or the teacher, and that is translating a perceptual, metaphörical message into something that is 3D and practical.
<G-vec00361-003-s337><call_on.bezeichnen><de> Mit unseren fast 30 Jahren Erfahrung und bereits realisierte, erfolgreiche Projekte können wir uns mit Recht als Solid Surface-Experten bezeichnen.
<G-vec00361-003-s337><call_on.bezeichnen><en> With our nearly 30 years of experience and extensive series of delivered projects, we can rightly call ourselves solid surface experts.
<G-vec00361-003-s338><call_on.bezeichnen><de> Wenn der Wert einer dieser Methoden einen bestimmten Grenzwert überschreitet, bezeichnen wir diesen Moment als „abnormal“ entsprechend der jeweiligen Methode.
<G-vec00361-003-s338><call_on.bezeichnen><en> If the score of any method is above a certain limit, then we call that moment “abnormal” according to that method.
<G-vec00361-003-s339><call_on.bezeichnen><de> Charakteristisch für Taiwan ist die auf der Landkarte eine Süßkartoffel ähnelnde Form, aufgrund deren sich die Min Nan Ureinwohner auch als „Kinder der Süßkartoffel“ bezeichnen.
<G-vec00361-003-s339><call_on.bezeichnen><en> The shape of the main island of Taiwan is similar to a sweet potato seen in a south-to-north direction, and therefore, Taiwanese (especially Min Nan speakers) often call themselves "children of the Sweet Potato.
<G-vec00361-003-s340><call_on.bezeichnen><de> Mit dem Ausdruck "böse Geister" bezeichnen wir Satan und all seine bösen Geister.
<G-vec00361-003-s340><call_on.bezeichnen><en> What we call "evil spirits" are Satan and all the evil spirit men on his side.
<G-vec00361-003-s341><call_on.bezeichnen><de> Als Top-Platz würde ich diesen Platz nicht bezeichnen.
<G-vec00361-003-s341><call_on.bezeichnen><en> As a top place I would not call this place.
