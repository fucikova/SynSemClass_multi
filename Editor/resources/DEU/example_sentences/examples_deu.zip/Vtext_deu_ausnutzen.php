<G-vec00591-001-s042><exploit.ausnutzen><de> Sie können von Angreifern über das Netzwerk ausgenutzt werden, um an sensitive Informationen zu gelangen, beliebigen Code auszuführen oder auch einen Denial-of-Service auszulösen.
<G-vec00591-001-s042><exploit.ausnutzen><en> Unauthenticated remote attackers might exploit them to access confidential data, to execute arbitrary commands or do trigger a Denial-of-Service.
<G-vec00591-001-s043><exploit.ausnutzen><de> Um geeignete Maßnahmen zu entwickeln, müssen vorhandene Potenziale ausgenutzt und Fehlentwicklungen entgegensteuert werden.
<G-vec00591-001-s043><exploit.ausnutzen><en> In order to develop suitable measures, it is important to exploit existing potentials and counteract undesirable developments.
<G-vec00591-001-s044><exploit.ausnutzen><de> Sie können von Angreifern mit einem Account ausgenutzt werden, um ihre Rechte zu erweitern oder einen Denial-of-Service auszulösen.
<G-vec00591-001-s044><exploit.ausnutzen><en> Attackers with an existing account might exploit them to increase their privileges or to trigger a Denial-of-Service.
<G-vec00591-001-s045><exploit.ausnutzen><de> Wie diese Schwachstelle genau ausgenutzt wird, ist im Advisory dargestellt.
<G-vec00591-001-s045><exploit.ausnutzen><en> How to exploit this directory traversal vulnerability is shown in the advisory.
<G-vec00591-001-s046><exploit.ausnutzen><de> Der Begriff kann sich zwar auch auf nicht schädliche Aktivitäten beziehen, wird jedoch meist mit böswilligen Versuchen verbunden, bei denen Systemschwachstellen zum Vorteil des Täters ausgenutzt wurden.
<G-vec00591-001-s046><exploit.ausnutzen><en> While the term can also refer to non-malicious activities, it is most often associated with malevolent attempts to exploit system vulnerabilities for the benefit of the perpetrator.
<G-vec00591-001-s047><exploit.ausnutzen><de> Der Angreifer könnte auch manipulierte Websites oder Websites ausnutzen, die von Benutzern bereitgestellte Inhalte oder Werbeanzeigen akzeptieren oder hosten, indem er speziell entworfene Inhalte hinzufügt, mit denen die Sicherheitsanfälligkeiten ausgenutzt werden könnten.
<G-vec00591-001-s047><exploit.ausnutzen><en> The attacker could also take advantage of compromised websites, or websites that accept or host user-provided content or advertisements, by adding specially crafted content that could exploit the vulnerabilities.
<G-vec00591-001-s048><exploit.ausnutzen><de> """Der therapeutische Nutzen von Curcumin konnte bislang nicht voll ausgenutzt werden, da fettlösliches Curcumin nur eine sehr geringe Bioverfügbarkeit aufweist"", sagt Dr. Georg Wolz, Inhaber und Geschäftsführer des gleichnamigen Nahrungsergänzungsmittelherstellers."
<G-vec00591-001-s048><exploit.ausnutzen><en> """It had previously not been possible to fully exploit the therapeutic benefits of curcumin, because the fat-soluble substance only has very limited bioavailability,"" said Dr. Georg Wolz, owner and managing director of the company that bears his name."
<G-vec00591-001-s055><exploit.ausnutzen><de> Arbeitsgesetze sind bei uns eine ganz neue Erscheinung, die noch nie dagewesen ist, und die werktätigen Klassen stehen sehr unter dem Einfluß von revolutionären Parteien, die sie in ihrem eigenen Interesse ausnutzen.
<G-vec00591-001-s055><exploit.ausnutzen><en> Labour legislation with us is quite a new phenomenon without historical precedent, and the working classes are very much under the influence of revolutionary parties who exploit them in their own interests.
<G-vec00591-001-s056><exploit.ausnutzen><de> Das Projekt, das von der Provinz Livorno im Jahr 1998 koordiniert, war es von Anfang an das Ziel der Förderung der Tyrrhenischen Küste, als ein einzigartiges Produkt, das die Besonderheiten, die zu charakterisieren, zu erhalten und zu verbessern ausnutzen können zur gleichen Zeit, die platzierten Vielfalt, die bereichert dieses Gebiet, das von der Mündung des Magra an der Grenze zwischen Lazio erstreckt.
<G-vec00591-001-s056><exploit.ausnutzen><en> The project, coordinated by the Province of Livorno in 1998, it was placed from the outset the objective of promoting the Tyrrhenian coast as a unique product that can enhance the special features which characterize, conserve and exploit the same time, all diversity that enrich this area that extends from the mouth of the Magra on the border of Lazio.
<G-vec00591-001-s057><exploit.ausnutzen><de> Die Angreifer können die kompromittierten Websites verwenden digitale Münze Bergbau auszuführen oder bösartigen Code ausnutzen Host,“ – Palo Alto Forscher schrieb.
<G-vec00591-001-s057><exploit.ausnutzen><en> The attackers may use the compromised sites to perform digital coin mining or host malicious exploit code,” – Palo Alto researchers wrote.
<G-vec00591-001-s058><exploit.ausnutzen><de> So gibt es noch Schlupflöcher, welche die Tabakindustrie ausnutzen kann.
<G-vec00591-001-s058><exploit.ausnutzen><en> This creates loopholes that the tobacco industry can exploit.
<G-vec00591-001-s059><exploit.ausnutzen><de> Der Haken ist, dass einer dieser Staatsfonds soll einen Adobe Flash Sicherheitsanfälligkeit ausnutzen (CVE-2014-0569) dass wurde im vergangenen Oktober gepatcht.
<G-vec00591-001-s059><exploit.ausnutzen><en> The catch is that one of these SWFs is meant to exploit an Adobe Flash vulnerability (CVE-2014-0569) that has been patched last October.
<G-vec00591-001-s060><exploit.ausnutzen><de> Der dritte Strang des Symposiums untersuchen, wie Künstler ebenso wie Anwender und Konsumenten vergessene Kanäle, Risse und Funktionen im Exzess der vernetzten Kommunikation ausnutzen.
<G-vec00591-001-s060><exploit.ausnutzen><en> The third strand of the symposium examines how artists – like users and consumers – exploit forgotten channels, fissures and functions in excess of networked communication.
<G-vec00591-001-s061><exploit.ausnutzen><de> Der EuG prüfte die beiden in Rede stehenden Marken genau auf eine mögliche Verbindung und bestätigte heute, dass die angemeldete strittige Marke den guten Ruf der älteren Marke in unlauterer Weise ausnutzen könne.
<G-vec00591-001-s061><exploit.ausnutzen><en> adidas examined the two trade marks in question carefully to establish a possible link and confirmed today that the mark in dispute could unfairly exploit the good reputation of the earlier mark.
<G-vec00591-001-s062><exploit.ausnutzen><de> Anstatt fahren Sie mit einer Litanei von Beanstandungen in dieser Ader fort, würde ich bloß sagen, daß rassische Abteilungen die Vereinigte Staaten Energie Auslese Leute ohne wirkungsvollen Widerstand plündern und ausnutzen lassen.
<G-vec00591-001-s062><exploit.ausnutzen><en> Rather than continue with a litany of complaints in this vein, I would merely say that racial divisions allow the U.S. power elite to plunder and exploit people without effective resistance.
<G-vec00591-001-s063><exploit.ausnutzen><de> 6) Nicht den Nächsten ausnutzen und keine Sklaverei betreiben.
<G-vec00591-001-s063><exploit.ausnutzen><en> 6. Thou shalt not exploit nor enslave anyone.
<G-vec00591-001-s064><exploit.ausnutzen><de> Die heutige soziale Gerechtigkeit operiert mit der Vermutung, dass Reichtum immer Arme ausnutzt.
<G-vec00591-001-s064><exploit.ausnutzen><en> Today’s social justice operates under the assumption that the wealthy exploit the poor.
<G-vec00591-001-s065><exploit.ausnutzen><de> Ein sehr bedachter Nomade, der alle theoretischen und praktischen Räume bedenkt und gern ausnutzt.
<G-vec00591-001-s065><exploit.ausnutzen><en> A very considered nomad who deliberates all theoretical and practical spaces and likes to exploit them.
<G-vec00591-001-s066><exploit.ausnutzen><de> "Er hat eigentlich nur eine ""Marktlücke"" gefunden, indem er eine menschliche Schwäche geschickt für seine Zwecke ausnutzt."
<G-vec00591-001-s066><exploit.ausnutzen><en> All he did was find a gap in the market and exploit a human weakness for his own means.
<G-vec00591-001-s067><exploit.ausnutzen><de> Dieser sogenannte Payload ist ein Stück bösartiger Code, der Sicherheitslücken ausnutzt und das System des Anwenders mit der Malware infiziert, die der Cyber-Kriminelle gewählt hat.
<G-vec00591-001-s067><exploit.ausnutzen><en> The latter is merely a piece of malicious code able to exploit these vulnerabilities and infect the user's system with the malware that the cybercriminal has chosen.
<G-vec00591-001-s068><exploit.ausnutzen><de> SUPERFLEX Arbeiten werfen aber nicht nur Fragen nach verinnerlichten Formen des Handelsgeschäfts auf, sie fragen auch nach der Verantwortung des einzelnen, danach ob er Möglichkeiten sich zu bereichern ausnutzt oder auch möglichst viele andere daran teilhaben lässt.Free Shop in Graz Im September 2018 findet Free Shop in den Bezirken Lend und Gries statt.
<G-vec00591-001-s068><exploit.ausnutzen><en> SUPERFLEX's works not only raise questions about internalised forms of commercial transaction, but also examine the responsibility of the individual, whether one chooses to exploit opportunities to enrich oneself or instead share the chance with as many other people as possible.Free Shop in Graz In September 2018 Free Shop will take place in the Lend and Gries district.
<G-vec00591-001-s069><exploit.ausnutzen><de> Und nur aus seiner Sachkenntnis heraus könnte er kreativ ausnutzt, erweitert und neu definiert die Grenzen der Grammatik.
<G-vec00591-001-s069><exploit.ausnutzen><en> And only out of his expertise could he creatively exploit, expand and redefine the boundaries of grammar.
<G-vec00591-001-s070><exploit.ausnutzen><de> Der ausnutzt offen Port 8983 Apache Velocity-Vorlagen auf dem Solr-Server aktivieren, und dann diese Funktion zum Download verwendet und bösartigen Code ausführen.
<G-vec00591-001-s070><exploit.ausnutzen><en> The exploit used open port 8983 to enable Apache Velocity templates on the Solr server, and then used this function to download and run malicious code.
<G-vec00169-001-s021><capitalize.ausnutzen><de> Um ihn auszun5utzen, erhöht der Spieler seine aufeinander folgenden Wetten durch einen bestimmten Prozentsatz nachdem ihr zweiter Gewinn.
<G-vec00169-001-s021><capitalize.ausnutzen><en> To capitalize on it, the gambler increases his successive bets by a certain percentage after their second win.
<G-vec00591-001-s114><exploit.ausnutzen><de> Um diese Potentiale des intrinsischen Fügens für eine Breite von Komponenten ideal auszunutzen, werden mit dem Schleuder- und Wickelverfahren zwei Technologien zur Hybridisierung eingesetzt.
<G-vec00591-001-s114><exploit.ausnutzen><en> Two technologies - centrifugal casting and filament winding - are being used to produce hybrid materials to best exploit the potentials of intrinsic joining for a wide range of components.
<G-vec00591-001-s115><exploit.ausnutzen><de> Ich hoffe besonders, entgangene vorrückende bloße eigene Meinungen in den strittigen Punkten zu haben, da dilettanti in solch einem Fall wenig Geschäft zu eigenen allen möglichen Meinungen haben, und überhaupt keines, zum sie zu auszunutzen untutored, als ob sie Wert oder Gewicht hatten.
<G-vec00591-001-s115><exploit.ausnutzen><en> I hope especially to have escaped advancing mere personal opinions on moot points, since dilettanti in such a case have little business to own any opinions, and none at all to exploit them to the untutored as if they had importance or weight.
<G-vec00591-001-s116><exploit.ausnutzen><de> Der betroffene Preprozessor ist von Haus aus eingeschaltet und um die Lücke auszunutzen, muss ein Angreifer keine direkte Verbindung zum RPC Portmapper aufbauen.
<G-vec00591-001-s116><exploit.ausnutzen><en> The vulnerable preprocessor is enabled by default. It is not necessary to establish an actual connection to a RPC portmapper service to exploit this vulnerability.
<G-vec00591-001-s117><exploit.ausnutzen><de> Um das volle Potenzial der Maschine auszunutzen, arbeitete Bosch Rexroth in der Entwicklung eng mit Bühler zusammen.
<G-vec00591-001-s117><exploit.ausnutzen><en> To fully exploit the machine's potentials, Bosch Rexroth and BÃ1⁄4hler cooperated closely during the development project.
<G-vec00591-001-s118><exploit.ausnutzen><de> Er erwählte es nicht seine Privilegien auszunutzen, sondern wollte Seine große Autorität benutzen um die Menschheit mit dem Vater zu versöhnen.
<G-vec00591-001-s118><exploit.ausnutzen><en> He chose not to exploit His privilege, but wanted to use His great authority to restore mankind to the Father.
<G-vec00591-001-s119><exploit.ausnutzen><de> Doch die Fluros beginnen auf einmal zu mutieren und sich selbstständig zu machen, und es liegt an Arkwright, diese seltsame Entwicklung zu verstehen (und auszunutzen).
<G-vec00591-001-s119><exploit.ausnutzen><en> However, Fluros begin to mutate and run amok, and it's up to Arkwright to understand (and exploit) these strange evolutions.
<G-vec00591-001-s120><exploit.ausnutzen><de> Es ist einfacher das Profil der Gegner zu erkennen und auszunutzen und bspw.
<G-vec00591-001-s120><exploit.ausnutzen><en> It is easier to determine and exploit the opponents' profile, i.e.
<G-vec00591-001-s121><exploit.ausnutzen><de> Criminals begann schnell, diese Sicherheitsanfälligkeit auszunutzen.
<G-vec00591-001-s121><exploit.ausnutzen><en> Criminals quickly began to exploit this vulnerability.
<G-vec00591-001-s122><exploit.ausnutzen><de> Ziel des Angriffes war offensichtlich ein Versuch, die Pingback-Lücke von WordPress auszunutzen, über die bereits im März berichtet wurde.
<G-vec00591-001-s122><exploit.ausnutzen><en> The goal of this attack was obviously an attempt to exploit the pingback vulnerabilty of WordPress which already had been reported in March .
<G-vec00591-001-s270><exploit.ausnutzen><de> In der Zukunft werden solche Unternehmen führend sein, die vollen Nutzen aus großen Datenmengen und Analysen ziehen sowie gleichzeitig einen verstärkten Fokus auf industrielle Cybersicherheitsmaßnahmen legen, denn dem erhöhten Risiko, das mit mehr mit dem Internet verbundenen Betriebsabläufen und Anlagen einhergeht, muss entsprechend begegnet werden.
<G-vec00591-001-s270><exploit.ausnutzen><en> Leading companies of the future will be those that fully exploit big data and analytics and in parallel increase focus on industrial cybersecurity measures, as companies seek to offset the greater risk of cyberattack that comes with more connected operations and assets.
<G-vec00591-001-s271><exploit.ausnutzen><de> Sie nutzen nicht nur aus, dass die fehlenden Strukturen das Vertrauen der Bevölkerung in den Staat mindern, sondern locken gleichzeitig mit Einkommensquellen, die zwar illegal, aber oftmals die einzigen Möglichkeiten zum Lohnerwerb sind.
<G-vec00591-001-s271><exploit.ausnutzen><en> They not only exploit the fact that the lack of structures erodes the people's trust in the state, but at the same time tempt people with sources of income that may be illegal but are often the only option for earning money.
<G-vec00591-001-s272><exploit.ausnutzen><de> Die neuen Messungen nutzen aus, dass zwar normale Wasserstoffmoleküle keine nennenswerte Strahlung aussenden, aber dass Wasserstoffdeuterid – wie erwähnt: darin ist eines der Wasserstoffatome durch Deuterium ersetzt – im Zusammenhang mit Rotationen des Moleküls eine Million stärker strahlt als normale Wasserstoffmoleküle.
<G-vec00591-001-s272><exploit.ausnutzen><en> The new measurements exploit the fact that, while ordinary hydrogen molecules do not emit measurable radiation, hydrogen deuteride – hydrogen molecules in which one of the atoms is deuterium – emit radiation associated with rotational degrees of freedom which is a million times stronger than for ordinary molecular hydrogen.
<G-vec00591-001-s273><exploit.ausnutzen><de> Nutzen Sie durch die Optimierung der Aufstellung Ihres Teams die gegnerische Schwäche aus.
<G-vec00591-001-s273><exploit.ausnutzen><en> Exploit the enemy’s weakness by optimizing your team setup.
<G-vec00591-001-s274><exploit.ausnutzen><de> Die Würmer nutzen Netzwerkverwundbarkeiten aus.
<G-vec00591-001-s274><exploit.ausnutzen><en> The worms exploit network server vulnerabilities.
<G-vec00169-001-s148><capitalize.ausnutzen><de> Es ist der perfekte Zeitpunkt um ein noch für 2016 vorhandenes Budget vor dem Jahresende auszunutzen und das Jahr 2017 perfekt zu beginnen.
<G-vec00169-001-s148><capitalize.ausnutzen><en> Its the perfect time to start the budgetary quoting process to capitalize on any remaining 2016 budget at the end of the year while starting off 2017 right!
<G-vec00591-002-s205><exploit.ausnutzen><de> Es ist sinnvoll, den zulässigen Spielraum auszunützen und klar zu stellen, wem welche Ansprüche zustehen sollen.
<G-vec00591-002-s205><exploit.ausnutzen><en> It makes sense to exploit the permissible scope and to make it clear who is entitled to which benefits.
<G-vec00591-002-s206><exploit.ausnutzen><de> Diese Vorgänge zeigen, was die Liberalen hätten erreichen können, wenn sie die Lage auszunützen verstanden.
<G-vec00591-002-s206><exploit.ausnutzen><en> These statements show what the liberals might have accomplished, if they had known how to exploit the situation.
<G-vec00591-002-s207><exploit.ausnutzen><de> Zum Beispiel sollte die Idee des Losgelöstseins nicht – ich würde sagen – im Stil der Hippies sein, indem ihr euch das Recht nehmt, alle anderen auszunützen.
<G-vec00591-002-s207><exploit.ausnutzen><en> Like, idea of detachment should not be that, I would say hippy-style of detachment: that you have right to exploit everybody else.
<G-vec00591-002-s208><exploit.ausnutzen><de> Sie wird versuchen, ihren Status auszunützen, um ihre (und Al-Qaedas) übergeordnetes Ziel zu erreichen und Syrien in eine Frontbasis der Al-Qaeda im Herzen des Nahen Ostens zu verwandeln, die in unmittelbarer geografischer Nähe zu Israel, Europa und den pro-westlichen arabisch-muslimischen Staaten liegt.
<G-vec00591-002-s208><exploit.ausnutzen><en> It will try to exploit its status to promote its (and Al-Qaeda's) end goal of turning Syria into Al-Qaeda's front-line base in the heart of the Middle East, in close geographical proximity to Israel, Europe and the pro-Western Arab-Muslim states. 17.
<G-vec00169-002-s323><benefit.ausnutzen><de> Lassen Sie sich über bestimmte Preisänderungen benachrichtigen und nutzen Sie die automatische, auf Regeln basierte Preisoptimierung.
<G-vec00169-002-s323><benefit.ausnutzen><en> Get alerts on specific price changes, and benefit from automatic, rule-based price optimization.
<G-vec00169-002-s324><benefit.ausnutzen><de> Passen Sie Warenkörbe mit individuellem Layout und Text an und nutzen Sie flexible Cross-Selling-Funktionen, um Ihren Umsatz zu steigern.
<G-vec00169-002-s324><benefit.ausnutzen><en> Customize shopping carts with individual layouts and wording, plus benefit from cross selling features.
<G-vec00169-002-s325><benefit.ausnutzen><de> Nutzen Sie jetzt unsere Rabattaktion: Kaufen Sie zwei Vorsteckringe und erhalten Sie 10% Rabatt.
<G-vec00169-002-s325><benefit.ausnutzen><en> Benefit now from a stacking discount! Buy 2 stacking rings and get a 10% discount.
<G-vec00169-002-s326><benefit.ausnutzen><de> Nutzen Sie unsere jahrelange Erfahrung und den spezialisierten Maschinenpark unserer Werkstatt am Firmenstandort in Wendelstein bei Nürnberg.
<G-vec00169-002-s326><benefit.ausnutzen><en> Individual desires Benefit from our years of experience and the specialized machinery of our workshop at the company location in Wendelstein at Nuremberg.
<G-vec00169-002-s327><benefit.ausnutzen><de> Nutzen Sie die Gelegenheit, und schnappen Sie sich eine unserer einmaligen Aktionen wie beispielsweise 21=17 oder 14=11.
<G-vec00169-002-s327><benefit.ausnutzen><en> Benefit from this opportunity and book one of our promotional offers, such as 21 = 17 or 14 = 11.
<G-vec00169-002-s328><benefit.ausnutzen><de> Vermeiden Sie mit einem Ticket ohne Anstehen die Warteschlangen an der Prager Burg und nutzen Sie einen Minibus-Transfer ab dem Altstädter Ring.
<G-vec00169-002-s328><benefit.ausnutzen><en> Avoid the long lines to enter Prague Castle with a skip-the-line admission ticket, and benefit from a minibus transfer from Old Town Square.
<G-vec00169-002-s329><benefit.ausnutzen><de> Nutzen Sie alle Möglichkeiten eines Business Centers und passen Sie auch Ihre Büroräume Ihrem jeweils aktuellen Bedarf an.
<G-vec00169-002-s329><benefit.ausnutzen><en> Benefit from all the options at our business center – just tailor your office services and spaces according to your current needs.
<G-vec00169-002-s330><benefit.ausnutzen><de> Nutzen Sie das Insider-Wissen einer stilsicheren, niveauvollen und diskreten Einkaufsbegleitung, die Sie berät und inspiriert - bei einer ganz persönlichen Shopping-Tour durch Hamburg oder andere Metropolen dieser Welt.
<G-vec00169-002-s330><benefit.ausnutzen><en> Benefit from the insider knowledge of a fashion conscious, sophisticated and discreet shopping advisor, who will inspire and advise you on your very own personal shopping tour in Hamburg or any other city worldwide.
<G-vec00169-002-s331><benefit.ausnutzen><de> Nutzen Sie unsere praktischen, anwenderfreundlichen Lösungen, um Ihre Prozesse zu optimieren.
<G-vec00169-002-s331><benefit.ausnutzen><en> Benefit from our smart and convenient solutions to optimize your processes.
<G-vec00169-002-s332><benefit.ausnutzen><de> Nutzen Sie den 3 Tage gültigen Eintritt an allen Museumsstandorten.
<G-vec00169-002-s332><benefit.ausnutzen><en> Benefit from 3-day admission with one entry to each museum location.
<G-vec00169-002-s333><benefit.ausnutzen><de> Kontakt Ein etablierter Partner – Nutzen Sie unser internationales Vertriebsnetz.
<G-vec00169-002-s333><benefit.ausnutzen><en> Contact An established partner – benefit from our international sales network.
<G-vec00169-002-s334><benefit.ausnutzen><de> Nutzen Sie die Möglichkeit, sich selbst von Grape zu überzeugen.
<G-vec00169-002-s334><benefit.ausnutzen><en> Benefit from the possibility to convince yourself of Grape.
<G-vec00169-002-s335><benefit.ausnutzen><de> Nutzen Sie das MicroControl-Fachwissen bei CAN, CANopen, J1939 und EtherCAT für die Fortbildung Ihrer Mitarbeiter und die Wettbewerbsfähigkeit Ihres Unternehmens: In exklusiven Intensiv-Seminaren zeigen wir Ihnen, was die Bus-Technologien zukünftig möglich machen.
<G-vec00169-002-s335><benefit.ausnutzen><en> Intensive Workshops on BUS Technology Exclusive choice of up-to-date, practice-related workshops Benefit from MicroControl's know-how about CAN, CANopen, J1939 and EtherCAT We offer intensive workshops on these specific subjects where you will discover the opportunities of bus technologies.
<G-vec00169-002-s336><benefit.ausnutzen><de> Nutzen Sie dabei vielfältige PDF-Settings wie Passwort- und Rechteschutz, automatische Hyperlinkerstellung sowie Tagged PDF und PDF /A-1 Support.
<G-vec00169-002-s336><benefit.ausnutzen><en> Benefit from the varied PDF settings, such as password and rights protection, automatic hyperlink creation and tagged PDF and PDF /A-1 support.
<G-vec00169-002-s337><benefit.ausnutzen><de> Nutzen Sie den Luxus der sieben Sandtennisplätze direkt am Hotel „Die Post“.
<G-vec00169-002-s337><benefit.ausnutzen><en> Benefit from the luxury of having seven clay courts right at the “Die Post” Hotel.
<G-vec00169-002-s338><benefit.ausnutzen><de> Nutzen Sie die Erfahrung der Hartchrom Beck GmbH in Güglingen-Frauenzimmern für Flugzeuge, Autos, Hydraulik und viele andere Anlagen.
<G-vec00169-002-s338><benefit.ausnutzen><en> Benefit from the experience of the hard chrome Beck GmbH in Güglingen-Frauenzimmern for aircraft, automobiles, hydraulic and many other plants.
<G-vec00169-002-s339><benefit.ausnutzen><de> Nutzen Sie Investitionsberatung und Transaktionsunterstützung bei Kauf, Verkauf, Finanzierung und Mietgeschäften im Bereich der Büroimmobilien.
<G-vec00169-002-s339><benefit.ausnutzen><en> Benefit from investment consulting and transaction support when purchasing, selling, financing and renting office property.
<G-vec00169-002-s340><benefit.ausnutzen><de> Nutzen Sie die Möglichkeit, Weine des Hemel-en-Aarde Valleys zu verkosten.
<G-vec00169-002-s340><benefit.ausnutzen><en> Benefit from the option to taste the wines of the Hemel-en-Aarde Valley.
<G-vec00169-002-s341><benefit.ausnutzen><de> Nutzen Sie den einfachen Transport zu wichtigen Attraktionen wie dem Panathinaiko-Stadion und Parthenon an der Akropolis.
<G-vec00169-002-s341><benefit.ausnutzen><en> Benefit from easy transportation to key attractions, such as the Panathenaic Stadium and Parthenon at the Acropolis.
<G-vec00169-002-s023><capitalize.ausnutzen><de> In der Vorausschau erwarten wir, dass das Bestellaufkommen gleichmäßiger ausfallen wird, und wir bereiten uns darauf vor, zahlreiche globale Trends auszunutzen, um in 2018 wieder Wachstum zu erzielen.
<G-vec00169-002-s023><capitalize.ausnutzen><en> Looking ahead, we are expecting more normalized order patterns and are preparing to capitalize on numerous global developments to ensure we return to growth in 2018.
<G-vec00169-002-s024><capitalize.ausnutzen><de> Diese Entwicklungen und neuen Möglichkeiten das soziale Netzwerk auszunützen werden in dieser Diplomarbeit näher erläutert.
<G-vec00169-002-s024><capitalize.ausnutzen><en> These developments and new opportunities to capitalize the social network are explained in detail in this thesis.
<G-vec00169-002-s078><capitalize.ausnutzen><de> Werden auch Sie Teil der wachsenden Gemeinschaft der in Südkorea aktiven Unternehmen und nutzen Sie die Möglichkeiten, die das Freihandelsabkommen bereithält.
<G-vec00169-002-s078><capitalize.ausnutzen><en> Become part of a growing network of Korean- American commerce and exchange and capitalize on the opportunities that come with it.
<G-vec00169-002-s079><capitalize.ausnutzen><de> Nutzen Sie unsere Erfahrung und unser Know-how.
<G-vec00169-002-s079><capitalize.ausnutzen><en> Capitalize on our know-how and experience.
<G-vec00169-002-s080><capitalize.ausnutzen><de> Setzen Sie eine kostenfreie 0800-Servicerufnummer gezielt zur Neukundenakquise ein oder nutzen Sie den imagefördernden Effekt der freecall-Nummer zur Verbesserung der Kundenzufriedenheit mit Ihrer Servicequalität.
<G-vec00169-002-s080><capitalize.ausnutzen><en> Use a toll-free 0800 service number for new customer acquisition or capitalize on the image-enhancing effect of a toll-free number to increase customer satisfaction with your service quality.
<G-vec00169-002-s081><capitalize.ausnutzen><de> Nutzen Sie das Potenzial vorausschauender Analysen und entwickeln Sie innovative Lösungen, indem Sie Entscheidungsoptimierung und maschinelles Lernen kombinieren.
<G-vec00169-002-s081><capitalize.ausnutzen><en> Capitalize on the power of prescriptive analytics and build innovative solutions by combining decision optimization and machine learning.
<G-vec00169-002-s082><capitalize.ausnutzen><de> Nutzen Sie verfügbare Technologien, um die ständige Weiterentwicklung im Griff zu behalten, daraus einen Wettbewerbsvorteil zu generieren und patientenspezifische Therapien für einzelne Zielpopulationen zu anbieten zu können.
<G-vec00169-002-s082><capitalize.ausnutzen><en> Capitalize on available technologies to help manage this ongoing transformation, create competitive advantage, and deliver patient-specific therapies for targeted populations.
<G-vec00169-002-s083><capitalize.ausnutzen><de> Identifizieren und nutzen Sie vorhandene Verfahren zur Reaktion auf Zugriffsanfragen von Datensubjekten, und bestimmen Sie einen Ansprechpartner für Datenschutzthemen.
<G-vec00169-002-s083><capitalize.ausnutzen><en> Identify or capitalize on existing processes to help respond to data subject access requests, including appointing a privacy point of contact.
<G-vec00169-002-s084><capitalize.ausnutzen><de> Nutzen Sie die Möglichkeiten, die Ihren Bedürfnissen am besten entsprechen, aber seien Sie an möglichst vielen Orten präsent, sodass man Sie auch finden kann.
<G-vec00169-002-s084><capitalize.ausnutzen><en> Capitalize on the opportunities that best suit your needs, but list yourself in as many places as you can to ensure maximum visibility for your channel.
<G-vec00169-002-s085><capitalize.ausnutzen><de> Nutzen Sie diese Chance, indem Sie Ihre Website für das ZoneAlarm Affiliate-Programm registrieren.
<G-vec00169-002-s085><capitalize.ausnutzen><en> Capitalize on this opportunity by enrolling your website in the ZoneAlarm Affiliate program.
<G-vec00169-002-s120><capitalize.ausnutzen><de> Es ist der perfekte Zeitpunkt, um ein Restbudget von 2016 noch vor Jahresende auszunutzen und 2017 perfekt zu beginnen.
<G-vec00169-002-s120><capitalize.ausnutzen><en> Its the perfect time to start the budgetary quoting process to capitalize on any remaining 2016 budget at the end of the year while starting off 2017 right!
