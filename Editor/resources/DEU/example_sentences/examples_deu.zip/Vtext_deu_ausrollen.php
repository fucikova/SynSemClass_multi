<G-vec00239-002-s048><enroll.ausrollen><de> Klicken Sie auf Ausrollen und fahren Sie mit der Registrierung des iOS device fort.
<G-vec00239-002-s048><enroll.ausrollen><en> Click Enroll and proceed to Enroll your iOS device.
<G-vec00283-003-s057><roll_over.ausrollen><de> Ende des letzten Jahres startete die Auslieferung der ersten DryStar UV LED Systeme in Japan und es ist geplant, die UV LED-Technologie in den nächsten Monaten und Jahren in Europa auszurollen.
<G-vec00283-003-s057><roll_over.ausrollen><en> Delivery of the first DryStar UV LED systems started in Japan at the end of last year and there are plans to roll out UV LED technology in Europe over the coming months and years.
<G-vec00283-003-s058><roll_over.ausrollen><de> „Wir haben das Thema der Wertevermittlung früh aufgegriffen und zu Jahresbeginn begonnen Werte- und Orientierungskurse österreichweit auszurollen.
<G-vec00283-003-s058><roll_over.ausrollen><en> “We started to address the issue of the sharing of values at a very early point in time, and at the beginning of the year launched the roll out of Values and Orientation Courses across the whole of Austria.
<G-vec00283-003-s059><roll_over.ausrollen><de> Softwareentwickler, die mit Continuous Integration/Continuous Delivery (CI/CD)-Ansätzen arbeiten, nutzen häufig Container, um komplette Anwendungslandschaften auszurollen, zu stoppen oder zu verschieben.
<G-vec00283-003-s059><roll_over.ausrollen><en> Software developers who work with continuous integration / continuous delivery (CI/CD) methods often use containers to roll out, stop or move complete application landscapes.
<G-vec00283-003-s060><roll_over.ausrollen><de> 1 Bereite dich darauf vor, Teigstücke zu flachen Kreisen auszurollen.
<G-vec00283-003-s060><roll_over.ausrollen><en> 1 Prepare to roll pieces of dough into flat circles.
<G-vec00283-003-s061><roll_over.ausrollen><de> Dim Sum Maschinen Es ist nicht notwendig, den Teig mit einer anderen Maschine auszurollen.
<G-vec00283-003-s061><roll_over.ausrollen><en> Dim Sum machinery There is no need to roll out dough by another machine.
<G-vec00283-003-s062><roll_over.ausrollen><de> Es ist nicht notwendig, den Teig mit einer anderen Maschine auszurollen.
<G-vec00283-003-s062><roll_over.ausrollen><en> TAG: Seafood There is no need to roll out dough by another machine.
<G-vec00283-003-s063><roll_over.ausrollen><de> Denn Samsung und Google versuchen beide den App-Markt für faltbare Displays auszurollen.
<G-vec00283-003-s063><roll_over.ausrollen><en> Samsung and Google are both trying to roll out the app market for foldable displays.
<G-vec00283-003-s064><roll_over.ausrollen><de> Dr. Z plant, das Geschäftsmodell in alle größeren und mittleren deutschen Städte auszurollen, um ihre Leistungen flächendeckend anbieten zu können.
<G-vec00283-003-s064><roll_over.ausrollen><en> Dr. Z aims to roll out the business model in all major and medium-sized German cities in order to provide their services nationwide.
<G-vec00283-003-s065><roll_over.ausrollen><de> Dabei gilt es, ein klares Zielbild zu erstellen und priorisierte Ideen, die in kleinem Umfang erprobt werden, bei Erfolg mit hoher Geschwindigkeit auszurollen.
<G-vec00283-003-s065><roll_over.ausrollen><en> And these SMEs need to define a clear target and prioritized ideas that they can trial on a small scale and roll out rapidly if successful.
<G-vec00283-003-s066><roll_over.ausrollen><de> Unsere digitale Reise schreitet voran, wir wachsen stetig als Unternehmen zusammen und so wurde 2017 die wegweisende Entscheidung getroffen, die Marke A1 schrittweise über alle Länder, in denen wir tätig sind, auszurollen.
<G-vec00283-003-s066><roll_over.ausrollen><en> As our digital journey continues and we, as one company grow more and more together, in 2017 the decision was taken to gradually roll out our successful A1 brand in all of our countries.
<G-vec00283-003-s067><roll_over.ausrollen><de> Um das Sunrise-Angebot mit Glasfaser noch schneller und effizienter im Schweizer Markt auszurollen, hat sich Sunrise mit der Swiss Fibre Net AG zu einer strategischen Zusammenarbeit zusammengeschlossen.
<G-vec00283-003-s067><roll_over.ausrollen><en> To be able to roll out the Sunrise optical fiber offer more quickly and effectively in the Swiss market, Sunrise has agreed to a strategic co-operation with Swiss Fibre Net AG.
<G-vec00283-003-s068><roll_over.ausrollen><de> Ziel ist es, Produkte über eine Schnittstelle binnen Sekunden weltweit auszurollen.
<G-vec00283-003-s068><roll_over.ausrollen><en> The aim is to roll out products worldwide within seconds via an interface.
<G-vec00283-003-s069><roll_over.ausrollen><de> Um innovative Engineering-Ansätze in der Organisation nachhaltig auszurollen und zu etablieren, muss man sich damit beschäftigen, wie Kompetenzen in die eigene Organisation gelangen.
<G-vec00283-003-s069><roll_over.ausrollen><en> In order to sustainably roll out and establish innovative engineering approaches in an organization, one of the issues is dealing with how to get competencies into one’s own organization.
<G-vec00283-003-s070><roll_over.ausrollen><de> Tipp: Am einfachsten ist es, die FIMO Platte direkt auf Backpapier auszurollen, da sie sich dann später wieder leicht davon ablösen lässt.
<G-vec00283-003-s070><roll_over.ausrollen><en> 0.5 cm thick. Tip: Roll out the FIMO sheet directly onto baking paper – this will make it easier to remove later.
<G-vec00283-003-s071><roll_over.ausrollen><de> Das ermöglicht uns, Ihre Entwicklungsprogramme genau dort auszurollen, wo Sie diese gerade benötigen.
<G-vec00283-003-s071><roll_over.ausrollen><en> This allows us to roll out your development programs exactly where you need them.
<G-vec00342-003-s057><roll_out.ausrollen><de> Ende des letzten Jahres startete die Auslieferung der ersten DryStar UV LED Systeme in Japan und es ist geplant, die UV LED-Technologie in den nächsten Monaten und Jahren in Europa auszurollen.
<G-vec00342-003-s057><roll_out.ausrollen><en> Delivery of the first DryStar UV LED systems started in Japan at the end of last year and there are plans to roll out UV LED technology in Europe over the coming months and years.
<G-vec00342-003-s058><roll_out.ausrollen><de> „Wir haben das Thema der Wertevermittlung früh aufgegriffen und zu Jahresbeginn begonnen Werte- und Orientierungskurse österreichweit auszurollen.
<G-vec00342-003-s058><roll_out.ausrollen><en> “We started to address the issue of the sharing of values at a very early point in time, and at the beginning of the year launched the roll out of Values and Orientation Courses across the whole of Austria.
<G-vec00342-003-s059><roll_out.ausrollen><de> Softwareentwickler, die mit Continuous Integration/Continuous Delivery (CI/CD)-Ansätzen arbeiten, nutzen häufig Container, um komplette Anwendungslandschaften auszurollen, zu stoppen oder zu verschieben.
<G-vec00342-003-s059><roll_out.ausrollen><en> Software developers who work with continuous integration / continuous delivery (CI/CD) methods often use containers to roll out, stop or move complete application landscapes.
<G-vec00342-003-s060><roll_out.ausrollen><de> 1 Bereite dich darauf vor, Teigstücke zu flachen Kreisen auszurollen.
<G-vec00342-003-s060><roll_out.ausrollen><en> 1 Prepare to roll pieces of dough into flat circles.
<G-vec00342-003-s061><roll_out.ausrollen><de> Dim Sum Maschinen Es ist nicht notwendig, den Teig mit einer anderen Maschine auszurollen.
<G-vec00342-003-s061><roll_out.ausrollen><en> Dim Sum machinery There is no need to roll out dough by another machine.
<G-vec00342-003-s062><roll_out.ausrollen><de> Es ist nicht notwendig, den Teig mit einer anderen Maschine auszurollen.
<G-vec00342-003-s062><roll_out.ausrollen><en> TAG: Seafood There is no need to roll out dough by another machine.
<G-vec00342-003-s063><roll_out.ausrollen><de> Denn Samsung und Google versuchen beide den App-Markt für faltbare Displays auszurollen.
<G-vec00342-003-s063><roll_out.ausrollen><en> Samsung and Google are both trying to roll out the app market for foldable displays.
<G-vec00342-003-s064><roll_out.ausrollen><de> Dr. Z plant, das Geschäftsmodell in alle größeren und mittleren deutschen Städte auszurollen, um ihre Leistungen flächendeckend anbieten zu können.
<G-vec00342-003-s064><roll_out.ausrollen><en> Dr. Z aims to roll out the business model in all major and medium-sized German cities in order to provide their services nationwide.
<G-vec00342-003-s065><roll_out.ausrollen><de> Dabei gilt es, ein klares Zielbild zu erstellen und priorisierte Ideen, die in kleinem Umfang erprobt werden, bei Erfolg mit hoher Geschwindigkeit auszurollen.
<G-vec00342-003-s065><roll_out.ausrollen><en> And these SMEs need to define a clear target and prioritized ideas that they can trial on a small scale and roll out rapidly if successful.
<G-vec00342-003-s066><roll_out.ausrollen><de> Unsere digitale Reise schreitet voran, wir wachsen stetig als Unternehmen zusammen und so wurde 2017 die wegweisende Entscheidung getroffen, die Marke A1 schrittweise über alle Länder, in denen wir tätig sind, auszurollen.
<G-vec00342-003-s066><roll_out.ausrollen><en> As our digital journey continues and we, as one company grow more and more together, in 2017 the decision was taken to gradually roll out our successful A1 brand in all of our countries.
<G-vec00342-003-s067><roll_out.ausrollen><de> Um das Sunrise-Angebot mit Glasfaser noch schneller und effizienter im Schweizer Markt auszurollen, hat sich Sunrise mit der Swiss Fibre Net AG zu einer strategischen Zusammenarbeit zusammengeschlossen.
<G-vec00342-003-s067><roll_out.ausrollen><en> To be able to roll out the Sunrise optical fiber offer more quickly and effectively in the Swiss market, Sunrise has agreed to a strategic co-operation with Swiss Fibre Net AG.
<G-vec00342-003-s068><roll_out.ausrollen><de> Ziel ist es, Produkte über eine Schnittstelle binnen Sekunden weltweit auszurollen.
<G-vec00342-003-s068><roll_out.ausrollen><en> The aim is to roll out products worldwide within seconds via an interface.
<G-vec00342-003-s069><roll_out.ausrollen><de> Um innovative Engineering-Ansätze in der Organisation nachhaltig auszurollen und zu etablieren, muss man sich damit beschäftigen, wie Kompetenzen in die eigene Organisation gelangen.
<G-vec00342-003-s069><roll_out.ausrollen><en> In order to sustainably roll out and establish innovative engineering approaches in an organization, one of the issues is dealing with how to get competencies into one’s own organization.
<G-vec00342-003-s070><roll_out.ausrollen><de> Tipp: Am einfachsten ist es, die FIMO Platte direkt auf Backpapier auszurollen, da sie sich dann später wieder leicht davon ablösen lässt.
<G-vec00342-003-s070><roll_out.ausrollen><en> 0.5 cm thick. Tip: Roll out the FIMO sheet directly onto baking paper – this will make it easier to remove later.
<G-vec00342-003-s071><roll_out.ausrollen><de> Das ermöglicht uns, Ihre Entwicklungsprogramme genau dort auszurollen, wo Sie diese gerade benötigen.
<G-vec00342-003-s071><roll_out.ausrollen><en> This allows us to roll out your development programs exactly where you need them.
