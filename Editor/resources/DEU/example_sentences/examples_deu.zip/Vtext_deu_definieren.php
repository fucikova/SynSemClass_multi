<G-vec00060-001-s273><specify.definieren><de> Sie können eine Liste von Untermenüs für das neue Menüobjekt definieren und jeweils einen Wert und ein Skript mit ihnen verbinden.
<G-vec00060-001-s273><specify.definieren><en> You can specify a list of Submenus for the new Menu Item, and associate a value and a script with each.
<G-vec00060-001-s274><specify.definieren><de> Bitte beachten Sie: Jedes Element kann das Attribut xml:base erhalten, welches dazu dient, die Basis-URI dieses Elements zu definieren.
<G-vec00060-001-s274><specify.definieren><en> Note that each element can take the xml:base attribute, which is used to specify the base URI of that element.
<G-vec00060-001-s275><specify.definieren><de> Um die Variablen des Gültigkeitsbereichs Session gemeinsam zu nutzen, müssen Sie die J2EE-Sitzungsverwaltung in ColdFusion Administrator definieren.
<G-vec00060-001-s275><specify.definieren><en> To share session variables, you must specify J2EE session management in the ColdFusion Administrator.
<G-vec00060-001-s276><specify.definieren><de> XSL (eXtensible Stylesheet Language) ist eine Sprache zur Erstellung von Stylesheets, die definieren, wie Elemente in XML-Dokumenten dem Endbenutzer angezeigt werden.
<G-vec00060-001-s276><specify.definieren><en> XSL (eXtensible Stylesheet Language) is a language for creating stylesheets that specify how elements in XML documents should be displayed to the end-user, regardless of the chosen delivery mechanism.
<G-vec00060-001-s277><specify.definieren><de> Die Einzelteile sind meine Effizienz und verbesserte Größe als Zugabe zu einem Körper definieren.
<G-vec00060-001-s277><specify.definieren><en> The products have enhanced my efficiency as well as adding size to a more specify body.
<G-vec00060-001-s278><specify.definieren><de> Allerdings müssen weitere Untersuchungen sicher, dass diese Ergebnisse machen durchgeführt werden und auch definieren, es ist die Sicherheit.
<G-vec00060-001-s278><specify.definieren><en> Nonetheless, more research studies have to be executed to make certain these outcomes and also specify it’s safety.
<G-vec00060-001-s279><specify.definieren><de> Die Option Vario (Optionen) ermöglicht es, den dargestellten Ausschnitt des Meta-Screens zu definieren und ihn damit auch zu vergrößern oder zu verkleinern.
<G-vec00060-001-s279><specify.definieren><en> The option Vario (Options) allows to specify the displayed area of the meta screen and therefore to scale up or down the screen contents.
<G-vec00060-001-s280><specify.definieren><de> Die Meldung erscheint auch, wenn Sie einen Datensatz laden wollen, den Datenbrowser schließen, oder einen Filter definieren möchten.
<G-vec00060-001-s280><specify.definieren><en> This message is also displayed if you want to load a dataset, to close the data browser or if you want to specify a record filter.
<G-vec00060-001-s281><specify.definieren><de> Distanzbeschränkung kann auch verwendet werden, um einen exakten Radius zu definieren.
<G-vec00060-001-s281><specify.definieren><en> Distance constraint can be used to specify an exact radius.
<G-vec00060-001-s282><specify.definieren><de> Videoquelle im Cache Wenn die Eigenschaft Beim Laden wiedergeben (siehe unten) auf false gesetzt ist, können Sie eine Cache-Datei definieren, von der aus das Video wiedergegeben wird.
<G-vec00060-001-s282><specify.definieren><en> If the property Play on Load (see below) is set to false, then you can specify a cache file from which to play the video.
<G-vec00060-001-s283><specify.definieren><de> "Diese Funktionalität lässt sich im grafischen XBRL-Taxonomie-Editor über die Eingabehilfe ""Details"" aufrufen, um Preferred Labels für XBRL-Ressourcen zu definieren."
<G-vec00060-001-s283><specify.definieren><en> To access this functionality, developers can use the Details entry helper in the graphical XBRL Taxonomy Editor to specify preferred labels for XBRL resources.
<G-vec00060-001-s284><specify.definieren><de> In dieser Tabelle definieren Sie die vom Client-Binding überwachten Protokolle sowie deren Ports.
<G-vec00060-001-s284><specify.definieren><en> In this table, you specify the protocols and the associated ports for monitoring by the client binding.
<G-vec00060-001-s285><specify.definieren><de> Wenn Sie jedoch eigene Begrüßungsbildschirme für bestimmte Geräte und Ausrichtungen einrichten möchten, gehen Sie folgendermaßen vor: (i) Gehen Sie zu Supporting Files | Info.plist und löschen Sie Launch screen interface file base name; (ii) Klicken Sie auf images.xcassets, klicken Sie anschließend mit der rechten Maustaste in die Ansicht und wählen Sie New Launch Image; (iii) Definieren Sie ein Startbild für die einzelnen Auflösungen und Ausrichtungen.
<G-vec00060-001-s285><specify.definieren><en> If, however, you wish to set up individual splashscreens specific to different devices and orientations, do the following: (i) Go to Supporting Files | Info.plist and delete Launch screen interface file base name; (ii) Click images.xcassets, then right-click in the view and choose New Launch Image; (iii) Specify a launch image for each resolution and orientation.
<G-vec00060-001-s286><specify.definieren><de> Wir definieren zunächst die einzelnen Image Ressourcen in der Datei package.xml.
<G-vec00060-001-s286><specify.definieren><en> Firstly we specify the individual image resources in the file package.xml.
<G-vec00060-001-s287><specify.definieren><de> Die meisten GN&C-Projekte der NASA folgen einem konventionellen Verfahren: Experten und Analysten aus den beteiligten Fachgebieten definieren das Verhalten der Kernalgorithmen in detaillierten Anforderungsdokumenten.
<G-vec00060-001-s287><specify.definieren><en> Most NASA GN&C projects follow a traditional process: Domain experts and analysts specify the behavior of the core algorithms in detailed requirements documents.
<G-vec00060-001-s288><specify.definieren><de> Fünf Dos und drei Don'ts konnten die Kunden definieren.
<G-vec00060-001-s288><specify.definieren><en> Clients were allowed to specify five dos and three don'ts.
<G-vec00060-001-s289><specify.definieren><de> Die Einstellungen für die Registerhaltung und den Barcode können Sie beim Definieren der Sammelform für die Duplo-Weiterverarbeitung im Dialogfeld Marken festlegen.
<G-vec00060-001-s289><specify.definieren><en> When specifying Duplo for a gangup imposition layout, you can specify the registration and barcode in the Marks dialog box.
<G-vec00060-001-s290><specify.definieren><de> Eintragsdateien definieren Daten für die Katalogeinträge.
<G-vec00060-001-s290><specify.definieren><en> Entry files specify data for catalog entries.
<G-vec00060-001-s291><specify.definieren><de> Sie können den optionalen Parameter allowable_tags benutzen, um nicht zu entfernende Tags zu definieren.
<G-vec00060-001-s291><specify.definieren><en> You can use the optional second parameter to specify tags which should not be stripped.
<G-vec00060-001-s292><specify.definieren><de> "Wählen Sie unter ""Anmeldeinformationen"" einen vorhandenen Anmeldeinformationeneintrag aus oder definieren Sie lokale Anmeldeinformationen (siehe auch Anmeldeinformationen)."
<G-vec00060-001-s292><specify.definieren><en> Under Credentials, select an existing credential record or specify a local credential (see also Credentials).
<G-vec00060-001-s293><specify.definieren><de> Kategorie-Code (Komma als Trennzeichen) Definieren Sie die Kategorie des Eintrags.
<G-vec00060-001-s293><specify.definieren><en> Category Code (by comma). Specify the entry's category.
<G-vec00060-001-s294><specify.definieren><de> Definieren Sie die Zeit in Minuten, für die die Binding-Einträge für einen Client gültig sein sollen.
<G-vec00060-001-s294><specify.definieren><en> Specify the time in minutes for the binding entries to be valid for a client.
<G-vec00060-001-s295><specify.definieren><de> Definieren Sie den vollständig qualifizierten Host-Namen und Port für die Proxy-Server der jeweiligen Protokolle manuell.
<G-vec00060-001-s295><specify.definieren><en> Manually specify the fully qualified host name and port for the proxies of the respective protocols.
<G-vec00060-001-s296><specify.definieren><de> Um mehr als ein Schema-Dokument zu definieren, fügen Sie die Option mehrmals hinzu.
<G-vec00060-001-s296><specify.definieren><en> Add the option multiple times to specify more than one schema document.
<G-vec00060-001-s297><specify.definieren><de> Definieren Sie eine Oberkategorie über das Dropdown-Menü.
<G-vec00060-001-s297><specify.definieren><en> Specify the parent category via the dropdown menu.
<G-vec00060-001-s298><specify.definieren><de> Definieren Sie in strTable den Tabellennamen der Import-Root, die der Root-Node im neuen Dokument werden soll.
<G-vec00060-001-s298><specify.definieren><en> Specify in strTable the table name of the import root that will become the root node in the new document.
<G-vec00060-001-s299><specify.definieren><de> Um sie in eine Datei zu speichern, klicken Sie auf Ausgabe in Datei, wählen Sie einen Ort aus und definieren Sie einen Dateinamen, und klicken Sie auf Speichern .
<G-vec00060-001-s299><specify.definieren><en> To save it to a file, click Output to File, select a location and specify a file name, and click Save .
<G-vec00060-001-s300><specify.definieren><de> • Skript-URL: Definieren Sie eine HTTP URL zu einem automatischen Proxy-Konfigurationsskript (.pac), mit dem der Proxy-Server eingerichtet wird.
<G-vec00060-001-s300><specify.definieren><en> • Script URL: Specify an HTTP URL to a proxy-auto-configuration (.pac) script that is to be used for proxy setup.
<G-vec00060-001-s301><specify.definieren><de> Definieren Sie die Zeit, nach der ein AP die Verbindung zu seinem P2P-Partner als unterbrochen markiert.
<G-vec00060-001-s301><specify.definieren><en> Specify the time after which the AP tags the connection to its P2P partner as interrupted.
<G-vec00060-001-s302><specify.definieren><de> Sie können darüber hinaus auch die Ansichtsgröße definieren, bei der die Hilfslinie dargestellt wird (beim Standardwert 0% wird sie stets angezeigt).
<G-vec00060-001-s302><specify.definieren><en> You can also specify the View Scale at which the guide displays (at the default value, 0%, the guide will always display).
<G-vec00060-001-s303><specify.definieren><de> Definieren Sie die Wartezeit, nach welcher der AP in den Client-Modus wechselt und nach einem beliebigen AutoWDS-Basisnetz scannt, sofern noch keine Konfigurationsbestandteile von einem WLC vorliegen und die Wartezeit für den Beginn der vorkonfigurierten Integration (sofern gesetzt) abgelaufen ist.
<G-vec00060-001-s303><specify.definieren><en> Specify the wait time after which the AP switches to client mode and scans for any AutoWDS base networks. This assumes that there no configuration parts from a WLC available and the wait time for the start of the preconfigured integration (if set) has expired.
<G-vec00060-001-s304><specify.definieren><de> "Definieren Sie mit den Argumenten %FIRST_FILE%"" ""%SECOND_FILE% den vollständigen DiffDog-Pfad als externe Programmapplikation für diff/merge."
<G-vec00060-001-s304><specify.definieren><en> "Specify the DiffDog full path as External program application for diff/merge with arguments %FIRST_FILE%"" ""%SECOND_FILE% ."
<G-vec00060-001-s305><specify.definieren><de> Definieren Sie den vollständigen DiffDog-Pfad als Diff-Applikation und die Parameter %1 %2 als Parameter für den Vergleich in beide Richtungen.
<G-vec00060-001-s305><specify.definieren><en> Specify the DiffDog full path as Diff application, and the parameters %1 %2 as two-way differencing parameters.
<G-vec00060-001-s306><specify.definieren><de> Wenn Sie aufgefordert werden, einen Pfad für das neue UModel-Projekt zu definieren, lassen Sie die Standardeinstellungen unverändert und klicken Sie auf Fertigstellen .
<G-vec00060-001-s306><specify.definieren><en> When prompted to specify a location for the new UModel project, leave the default settings as is, and then click Finish .
<G-vec00060-001-s307><specify.definieren><de> Definieren Sie die Wartezeit, nach welcher der AP in den Client-Modus wechselt und entsprechend den Werten der Vorkonfiguration (der im AutoWDS-Profil hinterlegten SSID und Passphrase) nach einem AutoWDS-Basisnetz scannt, wenn sämtliche Weiterbetriebszeiten abgelaufen sind.
<G-vec00060-001-s307><specify.definieren><en> Specify the wait time after which the AP switches to client mode and scans for an AutoWDS base network using the values in the preconfiguration (the SSID and passphrase that are stored in the AutoWDS profile), if all continuation times have expired.
<G-vec00060-001-s308><specify.definieren><de> Definieren Sie hier welcher Dienst vom DNS wie aufgelöst werden soll.
<G-vec00060-001-s308><specify.definieren><en> Specify here which service should be resolved by DNS, and how.
<G-vec00060-001-s309><specify.definieren><de> Wenn Sie den HTTPs-Port einrichten und keine Browser-Warnungen darüber, dass das SSL-Zertifikat nicht mit der URL übereinstimmt, erhalten möchten, definieren Sie den Host-Namen des Rechners, auf dem die MobileTogether Server Konfigurationsseite geöffnet wird.
<G-vec00060-001-s309><specify.definieren><en> If you set up the HTTPS port and wish to avoid browser warnings about the SSL certificate not matching the URL, then specify the hostname of the computer on which the MobileTogether Server configuration page will be opened.
<G-vec00060-001-s310><specify.definieren><de> "Wählen Sie unter ""Anmeldeinformationen"" einen vorhandenen Eintrag aus oder definieren Sie lokale Anmeldeinformationen (siehe auch Anmeldeinformationen)."
<G-vec00060-001-s310><specify.definieren><en> Under Credentials, select an existing credential record or specify a local credential (see also Credentials).
<G-vec00322-002-s046><pinpoint.definieren><de> Das breite Spektrum von Glaubensrichtungen macht es schwer genau zu definieren, was Taoismus eigentlich ist.
<G-vec00322-002-s046><pinpoint.definieren><en> Because of this it is difficult to pinpoint exactly what Taoists believe.
<G-vec00322-002-s261><specify.definieren><de> Verschlüsselung Um eine Datenbank mit Verschlüsselung zu erstellen, definieren Sie einen Chiffrierschlüssel mit dem key=-Verbindungsparameter in der Verbindungszeichenfolge.
<G-vec00322-002-s261><specify.definieren><en> Encryption To create a database with encryption, specify an encryption key by specifying the key= connection parameter in the connection string.
<G-vec00322-002-s262><specify.definieren><de> In diesem Bereich definieren Sie das Zielverzeichnis und den Dateinamen für Ausgabedateien.
<G-vec00322-002-s262><specify.definieren><en> In this area, users can specify destination folders and file names for file output.
<G-vec00322-002-s263><specify.definieren><de> Definieren Sie die Höhe der Haupt Bilder.
<G-vec00322-002-s263><specify.definieren><en> Specify the width of the main images.
<G-vec00322-002-s264><specify.definieren><de> Definieren Sie nach Auswahl der gewünschten Versionskontrolle im nächsten Textfeld die Anmelde-ID dafür.
<G-vec00322-002-s264><specify.definieren><en> After selecting the required source control, specify the login ID for it in the next text box.
<G-vec00322-002-s265><specify.definieren><de> Unsere TimeMoto PC Plus Software fügt eine Vielzahl an erweiterten Funktionen zur ohnehin schon funktionsreichen PC Software hinzu: Teilen Sie alle 24 Stunden eines Tages in Schichten ein; protokollieren Sie die Ankunft und das Verlassen von Mitarbeitern außerhalb der normalen Arbeitszeiten; protokollieren Sie den Jahresurlaub und die jährliche Arbeitszeit von jedem Mitarbeiter; gleichen Sie Schichten aus, um Überstunden zu reduzieren; und definieren Sie Sonderurlaubsstunden zur Verwendung in Ihren Plänen.
<G-vec00322-002-s265><specify.definieren><en> Our PC Plus software adds a treasure trove of extended features to the PC software’s already rich set: schedule all 24 hours of the day in shifts; track employee arrival and departure outside standard work hours; track annual vacation and work time for each employee; balance schedules to minimize overtime; and specify special holiday hours for use in your scheduling. The range
<G-vec00322-002-s266><specify.definieren><de> Wählen Sie die Zu aktualisierende Dimension aus und definieren Sie die Schlüssel, die das Auffinden der Datensätze ermöglichen .
<G-vec00322-002-s266><specify.definieren><en> Using the targeting dimension: select the Dimension to update then specify the Keys for finding records .
<G-vec00322-002-s267><specify.definieren><de> Style: Breite: Definieren Sie die Breite der Bilder (in Pixeln).
<G-vec00322-002-s267><specify.definieren><en> Width: Specify the width (in pixels) for your images.
<G-vec00322-002-s268><specify.definieren><de> Definieren Sie eine Textdatei zum Speichern der überwachten Daten zur Analyse.
<G-vec00322-002-s268><specify.definieren><en> Specify the text document to save all intercepted data to for your analysis.
<G-vec00322-002-s269><specify.definieren><de> Definieren Sie Ihre Projektanfragen ab sofort einfach in einer effizienten Gesamtlösung aus 3D-Konstruktion, umfassender Projektdokumentation und abschließender Warenkorb-Anbindung mit direkter Bestellfunktion.
<G-vec00322-002-s269><specify.definieren><en> Specify your project queries straight away in an efficient end-to-end solution that includes 3D engineering, comprehensive project documentation and even a link to a shopping cart so you can place an order directly.
<G-vec00322-002-s270><specify.definieren><de> Port Definieren Sie den Port, über den Ihr WLC einen Daten-Tunnel zum Remote-WLC aufbaut.
<G-vec00322-002-s270><specify.definieren><en> Specify the port used by your WLC to establish a data tunnel to the remote WLC.
<G-vec00322-002-s271><specify.definieren><de> Definieren Sie das Kriterium für den DB-Filter.
<G-vec00322-002-s271><specify.definieren><en> Specify the criteria for the DB Filter.
<G-vec00322-002-s272><specify.definieren><de> Um die Download-Zeit zu verkürzen und den Festplatten-Speicherbedarf zu verringern, klappen Sie die Produktkomponenten auf und definieren Sie Nicht herunterladen für jene Komponenten, die Sie nicht benötigen.
<G-vec00322-002-s272><specify.definieren><en> To reduce your download time and disk space requirements, expand the product components and specify Do not download for those components you do not need.
<G-vec00322-002-s273><specify.definieren><de> Um die Informationen in eine Datei zu speichern, klicken Sie auf Ausgabe in Datei, wählen Sie einen Ort aus und definieren Sie einen Dateinamen, und klicken Sie auf Speichern.
<G-vec00322-002-s273><specify.definieren><en> To save the information to a file, click Output to File, select a location and specify a file name, and click Save.
