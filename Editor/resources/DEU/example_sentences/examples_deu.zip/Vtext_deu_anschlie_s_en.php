<G-vec00407-001-s162><attach.anschließen><de> An unsere Durchflusszählermodule (FRM: Flow Rate Meter) mit insgesamt 16digitalen Eingängen können Sie bis zu 8Durchflusszähler mit Schaumsonde oder alternativ Fassleermelder anschließen.
<G-vec00407-001-s162><attach.anschließen><en> You can attach to our flow rate meter modules with its 16 digital inputs up to 8 flow rate meters with foam probes or alternatively barrel-empty detectors.
<G-vec00407-001-s163><attach.anschließen><de> Also, um des Überlebens Willen sind Allianzen nützlich; wenn du einen Anführer oder eine Gruppe findest, die für deine Zwecke nützlich sind, warum sich nicht eine Weile anschließen, bis deine Nachkommenschaft dazu bereit ist, die ideologische Blutlinie herauszufordern.
<G-vec00407-001-s163><attach.anschließen><en> So, for the sake of survival, alliances are useful; if you find a leader or group that serves your purpose then why not attach yourself for a while until your progeny is ready to challenge the ideological blood line.
<G-vec00407-001-s164><attach.anschließen><de> Die Seneye Float ist entworfen, um mit dem Seneye Reef genutzt werden und bietet Flexibilität für Kunden, die nicht wollen, um den Sauger zu verwenden, um die Seneye Gerät anschließen.
<G-vec00407-001-s164><attach.anschließen><en> The Seneye Float is designed to be used with the Seneye Reef and offers flexibility for customers who do not wish to use the sucker to attach the Seneye device.
<G-vec00407-001-s165><attach.anschließen><de> Die Velopumpe ans Ventil anschließen und ungefähr 50 x pumpen.
<G-vec00407-001-s165><attach.anschließen><en> Attach the pump to the extension connector and pump about 50 times.
<G-vec00407-001-s166><attach.anschließen><de> Während der miner Verfahren können die verknüpfte Malware aktuell laufenden Windows-Dienste anschließen und auch von Drittanbietern montiert Anwendungen.
<G-vec00407-001-s166><attach.anschließen><en> During the miner procedures the linked malware can attach to currently running Windows services and also third-party mounted applications.
<G-vec00407-001-s167><attach.anschließen><de> Ihre frischen Look und hervorragende Qualität ermöglicht es Entwicklern, eine wirklich professionellen Look zu ihrem Projekt-Schnittstellen anschließen.
<G-vec00407-001-s167><attach.anschließen><en> Their fresh look and superb quality will enable developers to attach a genuinely professional feel to their project interfaces.
<G-vec00407-001-s168><attach.anschließen><de> Natürlich können Sie aber auch einen Schlauch für einen externen Kondensatablauf anschließen.
<G-vec00407-001-s168><attach.anschließen><en> But you can also, of course, attach a hose for an external condensate drain.
<G-vec00407-001-s169><attach.anschließen><de> Es kann noch perfekter sein, wenn wir diesen USB-Stick an eine schöne Lanyard anschließen.
<G-vec00407-001-s169><attach.anschließen><en> It can be even more perfect if we attach this USB drive to a nice lanyard.
<G-vec00407-001-s170><attach.anschließen><de> Sie müssen den All-In-One nicht an einen Computer anschließen, um Kopien zu erstellen, um auf Ihren Speicherkarten gespeicherte Fotos zu drucken oder um Fotos mithilfe von PictBridge direkt von einer Digitalkamera zu drucken.
<G-vec00407-001-s170><attach.anschließen><en> You do not need to attach the All-In-One to a computer to make copies, to print photos stored on memory cards, or to print photos directly from a digital camera using PictBridge.
<G-vec00407-001-s171><attach.anschließen><de> Die Autos werden sich anschließen, wenn Sie richtig parken.
<G-vec00407-001-s171><attach.anschließen><en> The cars will attach themselves once you park correctly.
<G-vec00407-001-s172><attach.anschließen><de> Audio-Geräte an den Anschluss der Zentraleinheit anschließen, stecken Sie den Stecker in die Spieler-Ausgänge sind auf der linken und der rechten Seite zur Verfügung.
<G-vec00407-001-s172><attach.anschließen><en> Audio devices attach to the connector of the central unit, insert the plug into the player outputs are available on the left and the right.
<G-vec00407-001-s173><attach.anschließen><de> Mit dem neuen iPadOS können Sie natürlich auch einen Controller, ein Gamepad oder einen Gaming-Joystick anschließen.
<G-vec00407-001-s173><attach.anschließen><en> Of course, the new iPadOS will also allow you to attach a controller, gamepad or gaming joystick.
<G-vec00407-001-s174><attach.anschließen><de> Um Radio zu hören, müssen Sie ein kompatibles Headset an das Gerät anschließen.
<G-vec00407-001-s174><attach.anschließen><en> To listen to the radio, you need to attach a compatible headset to the device.
<G-vec00407-001-s175><attach.anschließen><de> "In einer Studie aus der Schweiz wurde herausgefunden, dass ""...sich Drogenkonsumenten italienischer Abstammung eher bestimmten Personen als Institutionen anschließen."
<G-vec00407-001-s175><attach.anschließen><en> "A Swiss study found out that ""...the users of Italian descent seem to attach more to certain persons than to institutions."
<G-vec00407-001-s176><attach.anschließen><de> Sein schlankes Gehäuse ist nur 11 cm lang und 2 cm breit – einschließlich eines Anschlusses, an den Sie Ihren Sensor direkt, also ohne Kabel, anschließen können.
<G-vec00407-001-s176><attach.anschließen><en> Its slender housing measures only 11 cm long and 2 cm wide, including a connection to which you can attach your sensor directly, without a cable.
<G-vec00407-001-s177><attach.anschließen><de> Galleon Produkte reichen von Atomuhr, die auf einem eigenständigen PC anschließen ist die Atomuhren, die ein Befestigen Windows-Zeit-Server.
<G-vec00407-001-s177><attach.anschließen><en> Galleon products range from Atomic clock that attach to a standalone PC's to Atomic Clocks that Attach to a Windows time Server.
<G-vec00407-001-s178><attach.anschließen><de> Danach einfach die Tastatur am USB 3.0 Port anschließen, um ins UEFI Setup zu gelangen und alle Einstellungen vornehmen zu können.
<G-vec00407-001-s178><attach.anschließen><en> Afterwards simply attach the keyboard to the USB 3.0 port, in order to get into the UEFI Setup and to be able to setup all necessary settings.
<G-vec00407-001-s179><attach.anschließen><de> Wenn Sie mit dem Systemlaufwerk arbeiten, um Zugriff darauf zu erhalten, müssen Sie das vom Computer extrahieren und als sekundäre Festplatte an einen anderen Computer anschließen oder Ihren Mac in einer sicheren Umgebung mit UFS Explorer Backup and Emergency Recovery CD starten.
<G-vec00407-001-s179><attach.anschließen><en> If you need to work with the system disk, in order to get access to it, you will have to extract it from the machine and attach it to another computer as a secondary disk or boot your Mac in a safe environment using UFS Explorer Backup and Emergency Recovery CD.
<G-vec00407-001-s180><attach.anschließen><de> Sie sollten den Grassack an das Gerät anschließen und Sie sind bereit, den Mäher zu bewegen, um die Aufgabe zu erledigen.
<G-vec00407-001-s180><attach.anschließen><en> You should attach the grass bag to the unit and you are ready to move the mower to perform the job.
<G-vec00276-001-s029><plug.anschließen><de> Rayman muss zuerst Joes Neonwerbung wieder anschließen, wobei er die Spinnen meidet, um sich dann einen Weg inmitten der Stalaktiten der Höhle bis zum Versteck von Skops dem Skorpion zu bahnen.
<G-vec00276-001-s029><plug.anschließen><en> First of all, Rayman has to plug in Joe's shop sign avoiding the spiders, then he will work his way around the stalactites to the den of Skops the Scorpion. CANDY CHATEAU:
<G-vec00276-001-s030><plug.anschließen><de> Der Zugriff auf Daten, die auf der externen Festplatte gespeichert sind, ist eine einfache Aufgabe, da Sie nur die externe Festplatte an das System anschließen und dann mit dem Dateifreigabeprozess fortfahren müssen.
<G-vec00276-001-s030><plug.anschließen><en> Accessing data stored on external hard drive is an easy task as you just have to plug in external HDD to the system and then proceed with the file sharing process.
<G-vec00276-001-s031><plug.anschließen><de> Das schließt einiges der all-time bests, einschließlich Supernintendo Spiele und Playstation 1 Spiele, die wirklich preiswert sind, aber wert es mit ein, wenn Sie sie anschließen und spielen.
<G-vec00276-001-s031><plug.anschließen><en> That includes some of the all-time bests, including Super Nintendo games and Playstation 1 games that are really cheap but worth it when you plug them in and play.
<G-vec00276-001-s032><plug.anschließen><de> Falls Ihnen dieser Bildschirm nicht angezeigt wird, können Sie Ihren Scanner trotzdem an den Computer anschließen.
<G-vec00276-001-s032><plug.anschließen><en> If you do not see this screen, you should plug your scanner in to your computer anyway.
<G-vec00276-001-s033><plug.anschließen><de> Sie müssen das Gerät nicht an einen Computer anschließen oder gar zu Hause sein, um ein Backup mit iCloud zu erstellen.
<G-vec00276-001-s033><plug.anschließen><en> You don't need to plug your device into a computer or even be at home to back up with iCloud.
<G-vec00276-001-s035><plug.anschließen><de> Wenn Sie ein USB-Gerät an einen Thin Client anschließen, wird es in der Regel in einer lokalen Sitzung verfügbar.
<G-vec00276-001-s035><plug.anschließen><en> As a rule, when you plug a USB device into a thin client it becomes available in a local session.
<G-vec00276-001-s036><plug.anschließen><de> Bereit, in neue Telefone anschließen: Exynos 4 Quad ist “Pin-zu-Pin-kompatibel” mit den Exynos 4 Dual, ermöglicht Smartphone-und Tablet Lieferanten, um die neue Lösung ohne zusätzlichen Engineering-oder Design-Bemühungen übernehmen.
<G-vec00276-001-s036><plug.anschließen><en> Ready to plug into new phones: Exynos 4 Quad is “pin-to-pin compatible” with the Exynos 4 Dual, allowing smartphone and tablet suppliers to adopt the new solution without additional engineering or design efforts.
<G-vec00276-001-s037><plug.anschließen><de> Der 1/8 Zoll NPT Anschluss ist dafür gedacht, dass jeder Benutzer sein eigenes Sicherheitssystem daran anschließen kann.
<G-vec00276-001-s037><plug.anschließen><en> The 1/8″ NPT plug is provided for the user to install their own safety relief device.
<G-vec00276-001-s038><plug.anschließen><de> Starten Sie sofort – Sie können das TomTom LINK 201-Fahrzeugortungsgerät ganz einfach selbst anschließen.
<G-vec00276-001-s038><plug.anschließen><en> Get started quickly, you can simply plug in the LINK 201 vehicle tracking device yourself.
<G-vec00276-001-s039><plug.anschließen><de> BiDiB ist plug&play: die Adressierung funktioniert ähnlich wie USB – einfach anschließen und es geht.
<G-vec00276-001-s039><plug.anschließen><en> BiDiB is plug&play: Addressing is similar to USB – just plug it in and you are done.
<G-vec00276-001-s040><plug.anschließen><de> XS 3600 hat keine Modus-Taste - einfach nur ans Netz anschließen und die Batteriekabeln verbinden, um den Ladevorgang zu beginnen.
<G-vec00276-001-s040><plug.anschließen><en> XS 3600 has no mode button, just plug in main and connect battery cables to start charging.
<G-vec00276-001-s041><plug.anschließen><de> Also alles, was Sie tun müssen, ist Ihr Ladegerät anschließen und lassen die KI handhaben die rest.This Funktion ist sehr nützlich, wenn Sie Ihre Helden Stufe nach oben wollen: es braucht etwas Zeit, aber es wird getan werden, und da Sie nicht wirklich brauchen, etwas zu tun, Es ist großartig.
<G-vec00276-001-s041><plug.anschließen><en> So all you have to do is to plug your charger and let the AI handle the rest.This feature is extremely useful when you want to level up your heroes: it takes some time, but it will be done and since you don’t really need to do anything, it’s great.
<G-vec00276-001-s042><plug.anschließen><de> Der USB-Stack wird so virtualisiert, dass alles, was Sie an den lokalen Client anschließen, an die Remote-VM umgeleitet wird.
<G-vec00276-001-s042><plug.anschließen><en> The USB stack is virtualized such that anything you plug into the local client is sent to the remote VM.
<G-vec00276-001-s043><plug.anschließen><de> Einfach am USB 2.0 oder USB 3.0 oder eSATA Port anschließen, in das Fach legen und abschließen.
<G-vec00276-001-s043><plug.anschließen><en> Simply plug an USB 2.0 or USB 3.0 or eSATA device into the port, place it into the tray and lock the cover.
<G-vec00276-001-s044><plug.anschließen><de> Apple TV an das Stromnetz anschließen: Schließen Sie ein Ende des Netzkabels an den Netzanschluss Ihres Apple TV und das andere Ende an eine Steckdose an.
<G-vec00276-001-s044><plug.anschließen><en> Plug in Apple TV: Connect one end of the power cord to the power port on your Apple TV and the other end to a power outlet.
<G-vec00276-001-s045><plug.anschließen><de> Wenn sich Computer in unmittelbarer Nähe befinden, können Sie das Peripheriegerät einfach von einem Gerät trennen und jedes Mal an ein anderes anschließen, wenn Sie die Funktionen des Geräts nutzen möchten.
<G-vec00276-001-s045><plug.anschließen><en> Of course, if computers are located close to each other, you can simply unplug the peripheral from one machine and plug it into another one any time you need to make use of the device's functionality.
<G-vec00276-001-s046><plug.anschließen><de> Wenn Sie ein kompatibles Headset an den Xbox One Wireless Controller anschließen, wird die Chatfunktion über Kinect automatisch stummgeschaltet.
<G-vec00276-001-s046><plug.anschließen><en> When you plug a compatible headset into your Xbox One Wireless controller, chat audio through Kinect is automatically muted.
<G-vec00276-001-s047><plug.anschließen><de> Eine gute Möglichkeit ist das Vorhandensein von 3 g, IE, Sie können eine SIM-Karte direkt in ihre eigenen Tablet Zugriff auf das mobile Internet-Netzwerk anschließen..
<G-vec00276-001-s047><plug.anschließen><en> A great option is the presence of 3 g, IE, You can plug a SIM card straight in their own tablet to access the mobile internet network.
<G-vec00239-002-s112><enroll.anschließen><de> Das Unternehmen plant, die noch übrigen Terminals bis Ende des Jahres 2015 anzuschließen, abhängig von der Marktentwicklung und Nachfrage.
<G-vec00239-002-s112><enroll.anschließen><en> The company is looking to enroll the remaining terminals by the end of 2015, based on market and demand.
<G-vec00239-002-s076><join.anschließen><de> Egal, ob ihr selber einen Raum gebucht habt, und noch Mitspieler sucht, oder ihr euch einfach einer Gruppe, die demnächst irgendwo spielt, anschließen möchtet.
<G-vec00239-002-s076><join.anschließen><en> It does not matter if you have booked a room yourself and are still looking for other players, or you just want to join a group that is about to play somewhere.
<G-vec00239-002-s077><join.anschließen><de> Doch so sich ihm andere Gleichgesinnte anschließen, gewinnt alles an Bedeutung, was er redet und tut.
<G-vec00239-002-s077><join.anschließen><en> But so other like-minded ones join him, everything wins in importance, what he speaks and does.
<G-vec00239-002-s078><join.anschließen><de> Für diejenigen, die sich der Bewegung anschließen möchten, gibt es eine europäische Facebook-Gruppe, mit der wir weiterhin die Legalisierung von Snus in Europa fördern werden.
<G-vec00239-002-s078><join.anschließen><en> For those wishing to join the movement, there is a European Facebook group with which we will continue to promote the legalization of Snus in Europe.
<G-vec00239-002-s079><join.anschließen><de> Solche Dinge bleiben in einer kleinen Dorfgemeinschaft nicht unbemerkt, und je mehr Farmer sich dem Bio-Programm anschließen, desto größere Wellen schlägt die Initiative.
<G-vec00239-002-s079><join.anschließen><en> This kind of thing does not go unnoticed in a small community, and with more farmers coming forward to join the organic programme the ripples continue to spread.
<G-vec00239-002-s080><join.anschließen><de> Andere sagten mir, ich solle mich einer Gruppe anschließen die erlebt hatte was ich erlebte.
<G-vec00239-002-s080><join.anschließen><en> Others have told me I need to join a group that have experienced what I have.
<G-vec00239-002-s081><join.anschließen><de> Wenn sich die Menschen einer Geistesrichtung anschließen, die völlig irrig genannt werden kann, im Vergleich zur reinen Lehre Christi, so ist das ein irregeleitetes Denken, das um so folgenschwerer ist, je weniger es der Wahrheit entspricht.
<G-vec00239-002-s081><join.anschließen><en> When people join a school of thought, which can be called utterly wrong in comparison to the pure teaching of Christ, it is misguided thinking, and the less it corresponds to the truth, the more serious are the consequences.
<G-vec00239-002-s082><join.anschließen><de> Der Rat sollte sich dem Transparenzregister anschließen, einschließlich seiner Vorbereitungsgremien.
<G-vec00239-002-s082><join.anschließen><en> The Council should join the Transparency Register, including its preparatory bodies.
<G-vec00239-002-s083><join.anschließen><de> Ich bitte darum, dass wir uns ihnen anschließen und darum beten, dass die Mauer friedlich fällt, nicht im Hass.
<G-vec00239-002-s083><join.anschließen><en> I ask we join them praying that the wall comes down in peace and not in hatred.
<G-vec00239-002-s084><join.anschließen><de> Und er fuhr fort: „In diesen Tagen der intensiven Sammlung habe ich oft für alle Opfer dieser Attentate gebetet und heute möchte ich mich dem Gebet anschließen, das vom Bischofsrat in Ninive ersucht wird.
<G-vec00239-002-s084><join.anschließen><en> The Pope continued: “In these days of intense recollection I often prayed for all the victims of those attacks and today I would like to join myself spiritually in prayer for peace and the restoration of security promoted by the council of bishops at Nineveh.
<G-vec00239-002-s085><join.anschließen><de> Wir schätzen diese Anfragen nach mehr Informationen und hoffen, auf dieser Seite Antworten darauf geben zu können, wie Sie sich uns anschließen können.
<G-vec00239-002-s085><join.anschließen><en> We appreciate these requests for more information and hope to respond in this section with ways you can join us.
<G-vec00239-002-s086><join.anschließen><de> Und Er sehnt sich nach jener geistigen Partnerschaft, wo wir uns Ihm anschließen bei der Arbeit, Seelen zu erretten und zu heiligen.
<G-vec00239-002-s086><join.anschließen><en> And He longs for that spiritual partnership where we join with Him in the work of redeeming and sanctifying souls.
<G-vec00239-002-s087><join.anschließen><de> Sie werde, fügte sie hinzu, Arbeiter dringend auffordern, nicht für Le Pen zu stimmen, und sich gleichzeitig nicht dem Bündnis anschließen, das zur Stimmabgabe für Chirac aufruft.
<G-vec00239-002-s087><join.anschließen><en> She added she would urge workers not to vote for Le Pen, while refusing to join the coalition backing a vote for Chirac.
<G-vec00239-002-s088><join.anschließen><de> Abhängig davon, wie weit ihr selbst euch bereits entwickelt habt und welche Qualitäten ihr dabei zugleich entwickelt habt, gibt es außerdem viele andere Gruppen und zahlreiche Ratsgremien, denen ihr euch anschließen könnt.
<G-vec00239-002-s088><join.anschließen><en> Depending on how far you have evolved and which qualities you have developed, there are also many other groups and numerous councils you can join.
<G-vec00239-002-s089><join.anschließen><de> Seit neuestem ist meine Fanpage nun Mitglied im "Dark Angel Network", womit ich mich dessen Bestreben auf eine Fortsetzung von Dark Angel anschließen möchte.
<G-vec00239-002-s089><join.anschließen><en> Recently my fanpage became a member of the "Dark Angel Network", whereby I want to join its intention of getting a sequel of Dark Angel.
<G-vec00239-002-s090><join.anschließen><de> Ich sagte ihnen aber auch, dass ich mich erst dann ihrer Kirche anschließen würde, wenn ich wüsste, dass das, was sie mir erzählten, wahr ist.
<G-vec00239-002-s090><join.anschließen><en> But I told them that until I knew for sure that what they were teaching me was true, I wasn’t going to join their church.
<G-vec00239-002-s091><join.anschließen><de> An die Gaming-Oberklasse wollte das Notebook aber auch in dieser Ausstattung nicht wirklich anschließen, blieben doch Geräte mit GTX 280/285M oder HD 5870 Grafik, bislang erste Wahl für Gamer, außer Reichweite für das Toshiba Notebook.
<G-vec00239-002-s091><join.anschließen><en> The notebook couldn't really join the gamers' top-class even with this configuration. Devices with a GTX 280/285M or HD 5870, the first choice for gamers until now, remained out of reach for the Toshiba notebook.
<G-vec00239-002-s092><join.anschließen><de> Diejenigen, die ihnen folgen, oder die sie gutheißen, oder die sich ihnen anschließen, offen oder heimlich, sollen wirklich wissen, was auf sie in den nächsten Tagen wartet.
<G-vec00239-002-s092><join.anschließen><en> Those who follow them, or who agree with them, or who join them, openly or secretly, must clearly know what awaits them in the coming days.
<G-vec00239-002-s093><join.anschließen><de> Mit dem Zusatzmodul RF-/HOHLPROF lassen sich Verbindungen für Knoten untersuchen, an denen Hohlprofile anschließen.
<G-vec00239-002-s093><join.anschließen><en> In the RF‑/HSS add‑on module, you can analyze the connections for nodes at which hollow sections join.
<G-vec00239-002-s094><join.anschließen><de> Dies ist der Vertrag, den Muhammad, der Prophet, zwischen den Gläubigen von Quraisch und Medina und denen, die ihnen folgen, sich ihnen anschließen und mit ihnen zusammen kämpfen, abschließt.
<G-vec00239-002-s094><join.anschließen><en> This is the contract that Muhammad the prophet concludes between the believers from the Quraish and Medina, who follow them, who join them, and who fight along with them.
<G-vec00274-002-s020><prolong.anschließen><de> Vor diesem Hintergrund konnte der voestalpine-Konzern im zweiten Geschäftsquartal 2017/18 an die hervorragende Entwicklung des ersten Quartals anschließen und damit auch im ersten Halbjahr 2017/18 sowohl vom Umsatz her als auch in allen Ergebniskategorien gegenüber dem Vorjahr deutlich zulegen.
<G-vec00274-002-s020><prolong.anschließen><en> Against this backdrop, voestalpine Group was able to prolong the excellent development of the first business quarter 2017/18 and significantly increased sales and earnings in all categories in the first half of 2017/18 compared to the past business year.
<G-vec00276-002-s057><plug.anschließen><de> Sie lassen sich mit einem G½-Gewinde einfach installieren und werden mit einem M12-Stecker angeschlossen.
<G-vec00276-002-s057><plug.anschließen><en> They are easy to install with a G1/2 thread and feature an M12 plug connection.
<G-vec00276-002-s058><plug.anschließen><de> - Das Netzkabel wird häufi g angeschlossen und abgetrennt.
<G-vec00276-002-s058><plug.anschließen><en> Fully insert the power cord plug into the outlet.
<G-vec00276-002-s059><plug.anschließen><de> Prüfen Sie außerdem, dass Sie den Netzstecker richtig an eine funktionierende Steckdose angeschlossen haben und die Basisstation waagerecht und vollständig auf dem Boden steht.
<G-vec00276-002-s059><plug.anschließen><en> Also check that the mains plug is pushed correctly into a working socket and that the base station is standing fully level on the floor.
<G-vec00276-002-s060><plug.anschließen><de> SP1 DIRECT-Anschlusse 3 Werden abgeschaltet, wenn der Klinkenstecker eines Kopfhorers an der entsprechenden Buchse co vorne am Gerat angeschlossen ist, oder Sie die MUTE-Taste der Fernbedienung drucken.
<G-vec00276-002-s060><plug.anschließen><en> SP1 DIRECT terminals 3 Are switched off when a headphone jack plug is inserted in the headphone socket co on the front of the amplifier or, by pressing the MUTE button on the remote control handset.
<G-vec00276-002-s061><plug.anschließen><de> Dabei ist zu beachten, dass der blaue 16A-CEE-Stecker polungsrichtig angeschlossen wird (L1 muss geschaltet werden).
<G-vec00276-002-s061><plug.anschließen><en> It should be noted that the blue 16A CEE plug is connected with correct polarity (L1 must be switched).
<G-vec00276-002-s062><plug.anschließen><de> Praktisch alle Mäuse und Tastaturen werden über USB angeschlossen.
<G-vec00276-002-s062><plug.anschließen><en> Virtually all mice and keyboards plug in via USB.
<G-vec00276-002-s063><plug.anschließen><de> Typ-B-Anschlüsse auf der anderen Seite des USB-Kabels werden an Peripheriegeräte wie Festplatten und Smartphones angeschlossen.
<G-vec00276-002-s063><plug.anschließen><en> Type-B connectors, at the other side of USB cable, plug into a peripheral device like hard drive and smart phone.
<G-vec00276-002-s064><plug.anschließen><de> Er benötigt nur wenig Platz auf dem Schreibtisch und bietet genug Platz zwischen den einzelnen USB-Anschlüssen, sodass häufig genutzte Geräte schnell und einfach angeschlossen und getrennt werden können.
<G-vec00276-002-s064><plug.anschließen><en> There’s also ample space between the USB 3.0 ports, so it’s easy to plug and unplug the devices you use the most.
<G-vec00276-002-s065><plug.anschließen><de> Das Gerät kann überall angeschlossen werden, wo eine Steckdose vorhanden ist, um die Reichweite eines drahtlosen Heimnetzwerks zu vergrößern.
<G-vec00276-002-s065><plug.anschließen><en> You can plug the device into anywhere there is a power socket in your home to increase the range of your wireless network.
<G-vec00276-002-s066><plug.anschließen><de> Das Netzkabel muss an die korrekte Versorgungsspannung angeschlossen werden.
<G-vec00276-002-s066><plug.anschließen><en> The power cord must plug in to the right supply voltage.
<G-vec00276-002-s067><plug.anschließen><de> Der Current Doubler wird an zwei Ausgänge des Netzteils angeschlossen und verdoppelt so den Strom.
<G-vec00276-002-s067><plug.anschließen><en> Combines 2 isolated outputs from a power supply into one DC plug and doubles the current.
<G-vec00318-003-s095><join_up.anschließen><de> Ich hatte mich vor ein paar Tagen entschlossen, mich Gustavo auf dem Rest seiner Weltreise anzuschließen.
<G-vec00318-003-s095><join_up.anschließen><en> A few days ago I had decided to join Gustavo on the rest of his world trip.
<G-vec00318-003-s096><join_up.anschließen><de> Anstatt ein neues Projekt von Grund auf zu beginnen, beschlossen wir, uns einer Gruppe anzuschließen, die an vier Tagen pro Woche den Obdachlosen eine Mahlzeit pro Tag bietet.
<G-vec00318-003-s096><join_up.anschließen><en> Instead of starting a project from scratch, we decided to join a group that were supplying a meal per day to the homeless on four days a week.
<G-vec00318-003-s097><join_up.anschließen><de> Sie können 2-3 Freunde einzuladen, zu kommen und uns anzuschließen.
<G-vec00318-003-s097><join_up.anschließen><en> You can invite 2-3 friends to come and join us.
<G-vec00318-003-s098><join_up.anschließen><de> Angesichts dieser Gefahr hat eine Gruppe russischer Menschenrechtler ein spezielles Memorandum veröffentlicht und Gleichgesinnte aus anderen russischen Menschenrechtsorganisationen aufgefordert, sich ihm anzuschließen.
<G-vec00318-003-s098><join_up.anschließen><en> In the face of this threat, a group of Russian human rights activists issued a special Memorandum, and invited other like-minded members of Russian human rights NGOs to join the appeal.
<G-vec00318-003-s099><join_up.anschließen><de> "Ich bin sehr glücklich, mich Paris St. Germain anzuschließen", sagte Neymar nach seiner Ankunft in der französischen Hauptstadt: "Seit ich in Europa bin, war dieser Klub stets einer der ambitioniertesten.
<G-vec00318-003-s099><join_up.anschließen><en> "I am extremely happy to join Paris Saint-Germain," Neymar said in a statement. "Since I arrived in Europe, the club has always been one of the most competitive and most ambitious.
<G-vec00318-003-s100><join_up.anschließen><de> Wir rufen alle antirassistischen Kräfte, alle die, die sich täglich gegen die Diskriminierung der Asylpolitik wehren müssen und alle, die nicht zulassen wollen, dass Rassismus zum Mainstream wird, dazu auf, sich der karnevalesken Demonstration anzuschließen.
<G-vec00318-003-s100><join_up.anschließen><en> We are calling all anti-racist forces, all those involved in the daily struggles against the discriminatory asylum policies and all those who want to prevent racism from becoming mainstream, to join us.
<G-vec00318-003-s101><join_up.anschließen><de> Später arbeitete ich einige Zeit im staatlichen Sektor bei UKSUP im Bereich Saatgut und Setzlinge, wo ich die Möglichkeit hatte, mich der Slowakischen Nationalen Weinsammlung als Head Sommelier anzuschließen.
<G-vec00318-003-s101><join_up.anschließen><en> Later I worked for some time in the state sector at UKSUP in the field of seeds and seedlings, where I had the opportunity to join the Slovak National Collection of Wines as their Head Sommelier.
<G-vec00318-003-s102><join_up.anschließen><de> Von Interesse sind in diesem Zusammenhang auch die weiteren Äußerungen von Prof. Dr. Ernst Nolte: “Aber eben deshalb fühle ich mich durch ihn [den Revisionismus] herausgefordert und sehe mich dennoch nicht imstande, mich denjenigen anzuschließen, die den Staatsanwalt und die Polizei zum Einschreiten auffordern.
<G-vec00318-003-s102><join_up.anschließen><en> Some other remarks by Prof. Dr. Ernst Nolte on the subject of Revisionism are noteworthy: “I do indeed feel challenged by Revisionism, but I am unable to join those who demand that the state and the police intervene to repress Revisionism.
<G-vec00318-003-s103><join_up.anschließen><de> Seitdem bitten wir alle Mitarbeiter, die mit uns zusammenarbeiten, sich unserer Philosophie der ökologischen und sozialen Nachhaltigkeit anzuschließen, indem sie unseren Ethik-Kodex unterzeichnen.
<G-vec00318-003-s103><join_up.anschließen><en> Since 2012 we ask all our employees to follow our Code of Ethics on environmental and social sustainability. LEARN MORE Join Lavazza and Grow With Us
<G-vec00318-003-s104><join_up.anschließen><de> Keine Sorge, es wird der Zeitpunkt kommen, wo wir es ihnen verständlich machen werden, wir haben andere Möglichkeiten, uns ihnen anzuschließen.
<G-vec00318-003-s104><join_up.anschließen><en> At a certain moment we will make them understand, do not worry, we have other means to join them.
<G-vec00318-003-s105><join_up.anschließen><de> Ich lade euch ein, euch meinem Gebet für jene, die auf dramatische Weise verstorben sind, sowie für die Verletzten anzuschließen.
<G-vec00318-003-s105><join_up.anschließen><en> I invite you to join in my prayer for those who dramatically lost their lives, and for the injured.
<G-vec00318-003-s106><join_up.anschließen><de> Billy liebt, was er sieht und beschließt, die Ballett-Klasse anzuschließen statt der Boxen.
<G-vec00318-003-s106><join_up.anschließen><en> Billy loves what he sees and decides to join the ballet class instead of the boxing.
<G-vec00318-003-s107><join_up.anschließen><de> Wenn Sie einen Freund einladen, sich der Nutzergemeinde anzuschließen und mit ihm auf der Website in Verbindung treten, können wir seine Kontaktangaben lang genug nutzen und speichern, um Ihre Anfragen zu bearbeiten.
<G-vec00318-003-s107><join_up.anschließen><en> If you invite a friend to join and connect with you on the Site, we may use and store your friends' contact information long enough to process your requests.
<G-vec00318-003-s108><join_up.anschließen><de> Einmal in der Woche gabs eine Ausfahrt und ich wurde eingeladen, mich ihnen anzuschließen.
<G-vec00318-003-s108><join_up.anschließen><en> Once a week they went out with the bikes and i was invited to join them.
<G-vec00318-003-s109><join_up.anschließen><de> Wurm antwortete, dass jeder den Wahlkampf und den Aufbau der IYSSE unterstützen könne und die Entscheidung treffen solle, sich dem Kampf für Sozialismus anzuschließen.
<G-vec00318-003-s109><join_up.anschließen><en> Wurm responded that anyone could support the election campaign of the IYSSE and also make a conscious decision to become a member and join the fight for socialism.
<G-vec00318-003-s110><join_up.anschließen><de> Und vor allem werde ich euch bitten, euch der Arbeit anzuschließen, um diese Nation zu erneuern, auf die einzige Art, wie dies in Amerika seit 221 Jahren getan worden ist - Block um Block, Stein um Stein, schwielige Hand um schwielige Hand.
<G-vec00318-003-s110><join_up.anschließen><en> And, above all, I will ask you to join in the work of remaking this nation, the only way it's been done in America for 221 years -- block by block, brick by brick, calloused hand by calloused hand.
<G-vec00318-003-s111><join_up.anschließen><de> Herr Errejón Sainz de la Maza sagte: "Ich freue mich sehr darüber, mich der Von der Heyden Group anzuschließen.
<G-vec00318-003-s111><join_up.anschließen><en> Mr Javier Errejón Sainz de la Maza said: "I am very pleased to join the Von der Heyden Group.
<G-vec00318-003-s112><join_up.anschließen><de> Da wir statt uns dem IS anzuschließen, uns auf die Seite der Ukraine gestellt haben, wurden wir von seinen Ideologen offen als Ungläubige bezeichnet und uns wurde das Recht abgesprochen, Muslime zu sein.
<G-vec00318-003-s112><join_up.anschließen><en> Their ideologists openly called us apostates, denying the right to be Muslims, because of our decision to be on the side of Ukraine rather than emigrate to ISIS and join them.
<G-vec00318-003-s113><join_up.anschließen><de> « Ich freue mich sehr darauf, mich dem Team der La Ferme Saint Siméon anzuschließen.
<G-vec00318-003-s113><join_up.anschließen><en> « It is a great pleasure for me to join La Ferme Saint Simeon team.
