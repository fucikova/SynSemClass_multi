<G-vec00389-002-s055><thwart.ausbremsen><de> Effektive Klimaaktionen sind die Lösungen, die Ungerechtigkeit an der Wurzel packen und die vorherrschende Erzählungen von “Sicherheit” ausbremsen.
<G-vec00389-002-s055><thwart.ausbremsen><en> Effective climate actions are those solutions that address root causes of injustice and thwart the dominant narratives of “security”.
