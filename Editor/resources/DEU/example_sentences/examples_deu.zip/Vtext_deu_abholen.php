<G-vec00169-001-s019><collect.abholen><de> Ich wollte unsere Karten für die Sylvesterfeier abholen.
<G-vec00169-001-s019><collect.abholen><en> I wanted to collect our tickets for the New Years Eve party.
<G-vec00169-001-s020><collect.abholen><de> Wenn Sie mit Ihrem fahrzeug unzufrieren sind, sprechen Sie mit dem Anbieter vor Ort, wenn sie das Auto abholen.
<G-vec00169-001-s020><collect.abholen><en> If you are unhappy with your vehicle, speak to the local supplier when you collect your car.
<G-vec00169-001-s021><collect.abholen><de> Das Abholen oder Anmelden ist auch durch eine/n Bevollmächtigte/n möglich (Vollmacht, Kopie des Ausweises oder eine Kopie der Blue Card sind notwendig).
<G-vec00169-001-s021><collect.abholen><en> It is also possible to authorize someone to collect the decision letter and to do the exam registration (authorization letter, copy of ID card or copy of Blue Card required).
<G-vec00169-001-s022><collect.abholen><de> Die Tafel unterhält vier Fahrzeuge, mit denen Fahrerteams Lebensmittel an fünf Tagen die Woche bei kooperationsbereiten Firmen abholen.
<G-vec00169-001-s022><collect.abholen><en> The Tafel maintains four vehicles, each with teams of drivers that collect food from cooperating companies five days a week.
<G-vec00169-001-s023><collect.abholen><de> Umgekehrt müssen alle Mitarbeiter, die ein Paket verschicken wollen, den Pförtner anrufen, der das Paket am Arbeitsplatz abholen lässt und am Tor an einen bestellten Kurier übergibt.
<G-vec00169-001-s023><collect.abholen><en> The other way around, all employees, wanting to send a packet, have to inform the porter, which has to collect the packet at the workstation place and which will hand over the packet to the ordered courier at the gate.
<G-vec00169-001-s024><collect.abholen><de> Außerhalb der Öffnungszeiten Da nicht alle Autovermietungen 24 Stunden in St. Maarten geöffnet sind, können Sie Ihr Auto noch vor oder nach der Öffnungszeiten abholen.
<G-vec00169-001-s024><collect.abholen><en> Out of hours As not all car rental companies are open 24 hours at St Maarten, you will still be able to collect your car before or after opening hours.
<G-vec00169-001-s025><collect.abholen><de> Wir suchen die Medien für Sie heraus und Sie können sie in der Regel wenige Stunden danach abholen.
<G-vec00169-001-s025><collect.abholen><en> We find the media for you, and you can usually collect them a few hours later.
<G-vec00169-001-s026><collect.abholen><de> Vermerken Sie beim Beantragen Ihrer Karte klar und deutlich, dass Sie die Karte in Ihrer KBC Bank abholen wollen.
<G-vec00169-001-s026><collect.abholen><en> In that case, clearly indicate when applying for your card that you want to collect it in person from your KBC branch.
<G-vec00169-001-s027><collect.abholen><de> Wenn Sie nach Tschechische Republik reisen, kann Sie unser Fahrer abholen und Sie können Ihren Urlaub in Tschechische Republik sofort beginnen.
<G-vec00169-001-s027><collect.abholen><en> When traveling to Czech Republic you can have one of our drivers collect you and start your holidays in Czech Republic straight away.
<G-vec00169-001-s028><collect.abholen><de> Zur Zeit der Weinlese schickte er seine Boten zu den Pächtern, um den Ertrag abholen zu lassen.
<G-vec00169-001-s028><collect.abholen><en> When the harvest time approached, he sent his servants to the tenants to collect his fruit.
<G-vec00169-001-s029><collect.abholen><de> Die Schlüssel können Sie ab 15:00 Uhr in der Murray Street 34 abholen.
<G-vec00169-001-s029><collect.abholen><en> You can collect your keys from 34 Murray Street, after 15:00.
<G-vec00169-001-s030><collect.abholen><de> Da nicht alle Autovermieter 24 Stunden in Fort Lauderdale geöffnet sind, können Sie Ihr Auto noch vor oder nach der Öffnungszeiten abholen.
<G-vec00169-001-s030><collect.abholen><en> As not all car rental companies are open 24 hours at Fort Lauderdale, you will still be able to collect your car before or after opening hours.
<G-vec00169-001-s031><collect.abholen><de> Wenn Sie gebeten haben, die Produkte aus unseren Geschäften abzuholen, dürfen Sie sie jederzeit bei uns abholen, während der Öffnungszeiten der jeweiligen Shops.
<G-vec00169-001-s031><collect.abholen><en> If you have asked to collect the products from our stores, you can collect them from us at any time during the opening hours of the particular store.
<G-vec00169-001-s032><collect.abholen><de> Die bestellte Ware können Sie persönlich in unserem Werk abholen oder wir senden Ihnen diese bis ins Haus.
<G-vec00169-001-s032><collect.abholen><en> You may collect the ordered goods either in person in our plant or we will deliver them directly to the house.
<G-vec00169-001-s033><collect.abholen><de> "Wenn du aus Dänemark, Schweden oder Norwegen bestellst, kannst du „Im Store abholen"" als Versandmethode wählen."
<G-vec00169-001-s033><collect.abholen><en> When purchasing from Denmark or Sweden, you’re able to choose “Collect in Store” as a shipping method.
<G-vec00169-001-s034><collect.abholen><de> Bei der Ankunft können Kunden ihre Schusswaffen am Schusswaffenschalter abholen.
<G-vec00169-001-s034><collect.abholen><en> Upon arrival customers can proceed to the Firearm Desk to collect firearms.
<G-vec00169-001-s035><collect.abholen><de> Sie können Ihren Pass mit dem Visum per Kurierdienst an Ihre Privat- oder Geschäftsadresse in Österreich zustellen lassen (Premium Hauslieferung) oder sie bei DPD Wien City Hub (Selbst-Abholung) abholen.
<G-vec00169-001-s035><collect.abholen><en> You may choose to have your passport and visa returned to your home/business address in Austria via courier service (Premium Home Delivery) or collect them from the DPD City Hub (Pickup).
<G-vec00169-001-s036><collect.abholen><de> Bei internationalen Flügen müssen die Gäste ihr Gepäck abholen und am ersten Einreiseort den Zoll passieren.
<G-vec00169-001-s036><collect.abholen><en> For international flights, guests will have to collect their baggage and clear Customs at the first port of entry.
<G-vec00169-001-s037><collect.abholen><de> Selbstverständlich ist es ebenfalls möglich, die Waren direkt bei uns abholen.
<G-vec00169-001-s037><collect.abholen><en> Off course, it is possible to collect your order from our warehouse.
<G-vec00169-001-s019><fetch.abholen><de> Nun wollte ich Victor unbedingt mitteilen, dass er den Ring abholen sollte.
<G-vec00169-001-s019><fetch.abholen><en> Now I urgently wanted to tell Victor that he should fetch the ring.
<G-vec00169-001-s020><fetch.abholen><de> Selbst wenn wir am Wochenenden Teile benötigen, können wir sie aus Petershagen abholen.
<G-vec00169-001-s020><fetch.abholen><en> Even if we need parts at the weekend we can go and fetch them from Petershagen.
<G-vec00169-001-s021><fetch.abholen><de> Wir können Sie mit dem Auto vom Bahnhof oder Busbahnhof abholen.
<G-vec00169-001-s021><fetch.abholen><en> We can fetch you by car from the train station or bus station.
<G-vec00169-001-s022><fetch.abholen><de> Der Teufel sagte: “Setz dich, ich will dich waschen, kämmen, schnippen, die Haare und Nägel schneiden und die Augen auswischen,” und als er mit ihm fertig war, gab er ihm den Ranzen wieder voll Kehrdreck und sprach: “Geh hin und sage dem Wirt, er sollte dir dein Gold wieder herausgeben, sonst wollt ich kommen und ihn abholen, und er sollte an deinem Platz das Feuer schüren.” Hans ging hinauf und sprach zum Wirt: “Du hast mein Gold gestohlen, gibst du’s nicht wieder, so kommst du in die Hölle an meinen Platz und sollst aussehen so greulich wie ich.” Da gab ihm der Wirt das Gold und noch mehr dazu und bat ihn, nur still davon zu sein; und Hans war nun ein reicher Mann.
<G-vec00169-001-s022><fetch.abholen><en> The Devil said, “Seat yourself, I will wash, comb, and trim you, cut your hair and nails, and wash your eyes for you,” and when he had done with him, he gave him the knapsack back again full of sweepings, and said, “Go and tell the landlord that he must return you your money, or else I will come and fetch him, and he shall poke the fire in your place.” Hans went up and said to the landlord, “Thou hast stolen my money; if thou dost not return it, thou shalt go down to hell in my place, and wilt look as horrible as I.” Then the landlord gave him the money, and more besides, only begging him to keep it secret, and Hans was now a rich man.
<G-vec00169-001-s023><fetch.abholen><de> Ich kann die Visa von Steve und mir erst einen Tag vor Abflug vom Japanischen Konsulat in Düsseldorf abholen.
<G-vec00169-001-s023><fetch.abholen><en> I can fetch the visas for Steve and myself from the Japanese consulate in Dusseldorf just one day before take-off.
<G-vec00169-001-s024><fetch.abholen><de> Auf dem Luftweg muss der Kunde die Waren vom Flughafen abholen.
<G-vec00169-001-s024><fetch.abholen><en> By air, customer needs to fetch the goods from airport.
<G-vec00169-001-s025><fetch.abholen><de> Ich soll dich abholen“, sagte Günter leicht säuerlich.
<G-vec00169-001-s025><fetch.abholen><en> “Mother sent me to fetch you,” Günther said in a slightly acerbic tone.
<G-vec00169-001-s026><fetch.abholen><de> 2 Klicken Sie auf Log-Dateien abholen .
<G-vec00169-001-s026><fetch.abholen><en> 2 Click Fetch the log files .
<G-vec00169-001-s027><fetch.abholen><de> Die nächste, angrenzende Komponente kann von dort den Bus abholen.
<G-vec00169-001-s027><fetch.abholen><en> The next adjacent component may fetch the bus from this point.
<G-vec00169-001-s028><fetch.abholen><de> Der Beamte ist argwöhnisch geworden und hat die Polizei angerufen, und später musste ich die drei mit meinem Auto von der Wache abholen.
<G-vec00169-001-s028><fetch.abholen><en> The clerk became suspicious and called the police, and later I had to fetch the three girls from the police station in my car.
<G-vec00169-001-s029><fetch.abholen><de> Besonders bequem: Die Halter können ihr Fahrzeug nach der Nachrüstung inklusive der grünen Plakette abholen, so dass die Eintragung direkt mit übernommen wird.
<G-vec00169-001-s029><fetch.abholen><en> Especially comfortable: The holder can fetch their vehicle after the retrofit, including the green plaque, so that the registration is taken over directly.
<G-vec00169-001-s030><fetch.abholen><de> IMAP kann sowohl Nachrichten auf einem entfernten Server speichern als auch von dort abholen.
<G-vec00169-001-s030><fetch.abholen><en> IMAP can store messages on a remote server as well as fetch them.
<G-vec00169-001-s031><fetch.abholen><de> Dort wo sie gerade sind, werden sie die Engel des Herrn abholen, sie verwandeln, also „überkleiden”, wie es Paulus auch in 2Kor 5,4 formuliert, und mit sich fortnehmen, dem Herrn in den Wolken entgegen.
<G-vec00169-001-s031><fetch.abholen><en> Right where they are, the angels will fetch them and transform them, or “clothe” them, as Paul also puts it in 2Cor 5,4, and take them to meet the Lord in the clouds.
<G-vec00169-001-s024><reclaim.abholen><de> Die Taxis befinden sich an den Terminals 1, 2A, 2C, 2D, 2E, 2F, 3 und 2G bei den Ausgängen, wo Sie Ihr Gepäck abholen.
<G-vec00169-001-s024><reclaim.abholen><en> The taxi services are located at terminals 1, 2A, 2C, 2D, 2E, 2F, 3 and 2G at the exits of the baggage reclaim areas.
<G-vec00169-001-s025><reclaim.abholen><de> Man kann diese Gegenstände abholen, indem man mit dem NPC spricht.
<G-vec00169-001-s025><reclaim.abholen><en> Players will be able to reclaim these items by speaking to the NPC.
<G-vec00169-001-s057><collect.abholen><de> Sie haben zwei britische Depots, und Sie können entscheiden, Ihre Bestellung von ihnen abzuholen, wenn Sie lokal sind, sie sind in Bolton und Aylesbury.
<G-vec00169-001-s057><collect.abholen><en> They have two UK depots, and you can opt to collect your order from them if you are local, they are in Bolton and Aylesbury.
<G-vec00169-001-s059><collect.abholen><de> Es ist höchste Zeit, dass sie kommen kann, um ihn abzuholen.
<G-vec00169-001-s059><collect.abholen><en> It is high time that she was able to come and collect it.
<G-vec00169-001-s060><collect.abholen><de> Der Kunde verfügt über eine Frist von 15 Tagen ab dem Datum der Lieferung in der Boutique, um seine Bestellung abzuholen.
<G-vec00169-001-s060><collect.abholen><en> The Customer has 15 days from the in-store delivery date to collect their parcel.
<G-vec00169-001-s061><collect.abholen><de> Da er seine Eltern über seine finanzielle Situation und ihre Folgen anscheinend im Unklaren gelassen hatte, waren Theodor und Else Daltrop umso bestürzter, als sie eines Tages erfuhren, dass ihr Sohn völlig orientierungslos beim Betteln auf der Straße aufgegriffen worden war, und sie aufgefordert wurden, ihn umgehend abzuholen.
<G-vec00169-001-s061><collect.abholen><en> Since apparently he had left his parents in the dark about his financial situation and its effects, Theodor and Else Daltrop were all the more dismayed to find out one day that their son had been picked up, completely disoriented while begging on the street, and to find themselves requested to collect him immediately.
<G-vec00169-001-s062><collect.abholen><de> Die Praktizierenden dürfen ihre Zelle nicht verlassen, um sich notwendige Dinge zu holen, ihre Wäsche abzuholen oder in den Lagerraum zu gehen, um Kleidung zu bekommen.
<G-vec00169-001-s062><collect.abholen><en> Practitioners are not allowed to leave the cell to fetch any necessities, collect their laundry, nor are they allowed to go to the store room to get their clothing.
<G-vec00169-001-s063><collect.abholen><de> Unser Chauffeur wird den Flug verfolgen um euch rechtzeitig abzuholen.
<G-vec00169-001-s063><collect.abholen><en> Our chauffeur will collect you with a personalised sign.
<G-vec00169-001-s064><collect.abholen><de> Sie haben auf all unseren Campingplätzen die Möglichkeit jeden Morgen gegen Vorbestellung frisches Brot und Croissants an der Rezeption abzuholen.
<G-vec00169-001-s064><collect.abholen><en> Every morning, you can also collect your bread and croissants at reception (upon order) on all our sites.
<G-vec00169-001-s065><collect.abholen><de> In Berlin gehst du zur Gepäckausgabe, um dein Gepäck wie gewohnt abzuholen.
<G-vec00169-001-s065><collect.abholen><en> At Berlin, proceed to baggage reclaim to collect your bags as normal.
<G-vec00169-001-s066><collect.abholen><de> (5) Bei ungewöhnlichem Wetter wie Hagel und starkem Wind sollten sofort Schutzmaßnahmen ergriffen werden, um die Geräte im Lager abzuholen.
<G-vec00169-001-s066><collect.abholen><en> (5) In case of abnormal weather such as hail and squally winds, protective measures should be taken immediately to collect the equipment into the warehouse.
<G-vec00169-001-s067><collect.abholen><de> Avis/Budget bietet auch die Möglichkeit für Kunden an, die Mietwagen von Terminal 2 abzuholen.
<G-vec00169-001-s067><collect.abholen><en> Avis/Budget also offer a facility for customers to collect their rental cars from Terminal 2.
<G-vec00169-001-s068><collect.abholen><de> Sie haben 7 Tage Zeit, sie dort abzuholen.
<G-vec00169-001-s068><collect.abholen><en> Please collect it within 7 days.
<G-vec00169-001-s069><collect.abholen><de> In diesem Fall verfügen Sie über 10 Werktage ab Eingang Ihres Pakets im Postamt, um es abzuholen.
<G-vec00169-001-s069><collect.abholen><en> You will then have 10 working days, from when your order arrives at the post office, to collect it.
<G-vec00169-001-s070><collect.abholen><de> Dieses Zurückbehaltungsrecht besteht selbstverständlich dann nicht, wenn er selbst angeboten hat, die Ware beim Verbraucher abzuholen.
<G-vec00169-001-s070><collect.abholen><en> Of course, this right of retention does not apply if he himself has offered to collect the goods from the consumer.
<G-vec00169-001-s071><collect.abholen><de> Soweit der Lieferant nach den Bestimmungen der Verpackungsordnung verpflichtet ist, Verpackungen zurückzunehmen, hat er sie auf seine Kosten bei dem Besteller abzuholen.
<G-vec00169-001-s071><collect.abholen><en> Where, according to the provisions of the packaging legislation, the supplier is required to take back the packaging, it must collect this from the customer at its own cost.
<G-vec00169-001-s072><collect.abholen><de> Um das Gepäck abzuholen, muss der Fluggast den entsprechenden Gepäckschein, den er beim Check-in erhalten hat, vorweisen.
<G-vec00169-001-s072><collect.abholen><en> To collect his baggage, the Passenger should show the corresponding Baggage Check delivered to him at check-in.
<G-vec00169-001-s073><collect.abholen><de> Wir möchten Sie außerdem daran erinnern, dass Sie ab der Landung eine Stunde Zeit haben, um Ihr Gepäcke abzuholen und den Schalter zu erreichen, der auf dem Terravision-Gutschein angegeben ist.
<G-vec00169-001-s073><collect.abholen><en> We also remind you that, from the landing time, you will have an hour to collect your luggage and reach the desk mentioned on the Terravision Voucher.
<G-vec00169-001-s074><collect.abholen><de> Der Kunde ist verpflichtet, die Lieferung innerhalb 30 Tagen nach Erhalt der Mitteilung über die Verfügbarkeit am Lager der Produkte zu genehmigen oder abzuholen.
<G-vec00169-001-s074><collect.abholen><en> Customers are asked to authorize shipment or to collect the supply directly at our warehouse within 30 days from the communication of availability.
<G-vec00169-001-s075><collect.abholen><de> Ein INWB-Connector für die Compliance-Adressprüfung kann dieses Attribut auswerten, um Nachrichten in diesem Verzeichnis abzuholen oder abzulegen.
<G-vec00169-001-s075><collect.abholen><en> An INWB connector for the compliance address verification can analyze this attribute in order to collect messages from or store messages in this directory.
<G-vec00169-001-s052><fetch.abholen><de> -Luft, Dauert es ungefähr 4-5 Tage, um den Zielflughafen erhalten, müssen Sie die Waren selbst abzuholen.
<G-vec00169-001-s052><fetch.abholen><en> -Air, it will take about 4-5 days to get to destination airport, you need to fetch goods by yourself.
<G-vec00169-001-s053><fetch.abholen><de> Jedes der 5 Zentren ist in einer großen Stadt gelegen, so dass die Einzelhändler nicht allzu weit fahren müssen, um die Ware abzuholen.
<G-vec00169-001-s053><fetch.abholen><en> Each of the 5 centers is located in a big city, so that the retailers do not need to drive too far to fetch the goods.
<G-vec00169-001-s054><fetch.abholen><de> Das Mädchen aber sitzt im Dorf und lauert und lauert und meint, er komme, sie abzuholen, es kommt aber keiner.
<G-vec00169-001-s054><fetch.abholen><en> But the maiden sat in the village and watched and watched, and thought he would come and fetch her, but no one came.
<G-vec00169-001-s055><fetch.abholen><de> Dieser Häftling berichtet, wie Boger in Krankenhausblock des Stammlagers Auschwitz erschien, um einen Häftling abzuholen, der gerade eine Operation an der Blase hinter sich hatte und eine weitere Operation an der Prostata vor sich hatte.
<G-vec00169-001-s055><fetch.abholen><en> This prisoner reported how Boger came into the infirmary quarters of the main camp of Auschwitz to fetch a prisoner who had just undergone bladder surgery and was scheduled to have prostate surgery.
<G-vec00169-001-s056><fetch.abholen><de> Er bekommt den Job und reist mit Tick, Trick und Track nach Grönland, um eine Kiste Eis abzuholen.
<G-vec00169-001-s056><fetch.abholen><en> He gets the job and travels to the Arctic with Huey, Dewey and Louie to fetch a box of ice.
<G-vec00169-001-s119><reclaim.abholen><de> "Sollten allerdings die Kürzel 'JFK' darauf geschrieben stehen, folgen Sie bitte den gelben Schildern ""Arrivals/Baggage reclaim"" (Ankunft/Gepäckausgabe), um Ihr Gepäck abzuholen und es wie gewöhnlich für Ihren Anschlussflug einzuchecken."
<G-vec00169-001-s119><reclaim.abholen><en> If your baggage tag shows 'JFK', please follow the signs for 'Arrivals/Baggage reclaim' to collect your bags and check it in again as normal for your connecting flight.
<G-vec00169-001-s188><reclaim.abholen><de> Der Gast wird nicht verpflichtet sein, die Einwanderung nach Hongkong zu passieren oder sein Gepäck wieder abzuholen.
<G-vec00169-001-s188><reclaim.abholen><en> Guest will not be required to clear Hong Kong immigration or reclaim their bags.
<G-vec00298-002-s118><augment.abholen><de> Steigern Sie mit KI die menschliche Kreativität und kognitive Fähigkeiten, um Kunden dort abzuholen, wo sie sich befinden.
<G-vec00298-002-s118><augment.abholen><en> Augment human ingenuity with AI and cognitive capabilities to meet customers where they are.
<G-vec00355-002-s028><fetch.abholen><de> Als sie den Springer nach zwei Stunden abholten und auf eine Bahre legten, sah ich, wie Springer den Kopf noch ein klein wenig hob.
<G-vec00355-002-s028><fetch.abholen><en> When they came to fetch Springer two hours later, and put him on a stretcher, I saw him trying to raise his head slightly.
<G-vec00380-002-s020><unload.abholen><de> Nachfolgend bezahlen Sie an den Schaffner eine einmalige Aufbewahrungsgebühr für die Verwahrung während der Beförderung im Gepäckwagen und Sie erhalten einen Beleg über die Bezahlung (im Fall eines Kinderwagens erhalten Sie einen Beleg über eine unentgeltliche Verwahrung) mit einem Aufkleber mit dem Namen des Bahnhofes der Ausgabe (in dem Sie den hinterlegten Gegenstand im Zug abholen werden).
<G-vec00380-002-s020><unload.abholen><en> Next, you will pay the conductor the one-off storage fee for the luggage storage during transport service, and you will receive a payment receipt (in the case of a children’s pram, you will receive a receipt for free storage) marked with a sticker bearing the name of the station of release (where you will come to the train to unload the stored item).
<G-vec00536-002-s012><quell.abholen><de> Die verfahrene, chaotische und frustrierende Lage heute ist insofern der Erfolg der Angriffe rechtspopulistischer Hasardeure und zugleich das Versagen demokratischer Kräfte, die in mehr oder weniger großen Schritten auf diese Kräfte zugingen, um die populistische Revolte zu dämpfen und „abzuholen“, statt ihr entgegenzutreten.
<G-vec00536-002-s012><quell.abholen><en> The muddled, chaotic and frustrating situation in which the UK finds itself today is the result of onslaughts by right-wing populist opportunists and the failure of democratic forces, which to various extents moved in the direction of the populists in an attempt to quell and 'appropriate' the populist revolt, rather than countering it.
