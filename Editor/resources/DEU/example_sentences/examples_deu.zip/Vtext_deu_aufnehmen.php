<G-vec00476-001-s079><absorb.aufnehmen><de> Weil beide Substanzen schlecht wasserlöslich sind und deswegen vom menschlichen Körper nur schwer aufgenommen werden, komplexiert WACKER diese mit Cyclodextrinen.
<G-vec00476-001-s079><absorb.aufnehmen><en> As both substances are sparingly soluble in water and thus difficult for the human body to absorb, WACKER's approach is to convert them into cyclodextrin complexes.
<G-vec00476-001-s080><absorb.aufnehmen><de> Außerhalb des Getriebes befindet sich eine Reaktionsvorrichtung, mit der das Drehmoment aufgenommen wird, damit das Werkzeug mit geringem Kraftaufwand betrieben werden kann.
<G-vec00476-001-s080><absorb.aufnehmen><en> Outside the gearbox is a reaction device which is used to absorb the torque and allow the tool operator to use it with very little effort.
<G-vec00476-001-s081><absorb.aufnehmen><de> Feuchtigkeitsaufnahme Die iglidur® A180-Gleitlager nehmen durch Luftfeuchtigkeit (+23 °C, 50 % relative Luftfeuchtigkeit) bis zu 0,2 % Wasser auf, bei Sättigung mit Wasser werden bis zu 1,3 % aufgenommen.
<G-vec00476-001-s081><absorb.aufnehmen><en> humidity absorption / moisture absorption The iglidur® A180 bearings absorb up to 0.2% water through atmospheric humidity (+23°C, 50% relative atmospheric humidity), when saturated with water they absorb 1.3%.
<G-vec00476-001-s082><absorb.aufnehmen><de> Die winzigen Teilchen werden von vielen Organismen aufgenommen und gelangen so in die Nahrungskette.
<G-vec00476-001-s082><absorb.aufnehmen><en> Many organisms absorb these tiny particles and thus, enter the food chain this way.
<G-vec00476-001-s083><absorb.aufnehmen><de> Torf enthält große Mengen an Nährstoffen, Mineralstoffen und natürliche Spurenelemente, die durch das Bad ganz einfach von der Haut aufgenommen werden, sie pflegen, regenerieren und die Durchblutung fördern.
<G-vec00476-001-s083><absorb.aufnehmen><en> Peat contains a large amount of nutrients, minerals and natural trace elements which the bath helps absorb into the skin, nourishing, renewing and engorging the skin.
<G-vec00476-001-s084><absorb.aufnehmen><de> Es ist leicht von der Haut aufgenommen und hat einen angenehmen Geruch, der ein außergewöhnliches Gefühl von Freude während der Massage gibt.ANWENDUNG: Empfohlen für die tägliche Pflege des ganzen Körpers und Haar.
<G-vec00476-001-s084><absorb.aufnehmen><en> It is light, easily to absorb by the skin and has a pleasant smell, which gives a great feeling of pleasure during the massage.APPLICATION: Recommended for daily care of the whole body and hair.
<G-vec00476-001-s085><absorb.aufnehmen><de> Flüssiger Spurennährstoff-Mix wird sofort durch die Pflanze aufgenommen.
<G-vec00476-001-s085><absorb.aufnehmen><en> The plant can immediately absorb liquid trace element mix.
<G-vec00476-001-s086><absorb.aufnehmen><de> Ein anderer Ausdruck für rosten ist oxidieren, das heißt, Eisen (Fe2+) reagiert im Wasser mit dem gelösten Sauerstoff und geht dabei in wasserunlösliches Eisen (Fe3+) über, das von Wasserpflanzen auf normalem Weg nicht mehr aufgenommen werden kann.
<G-vec00476-001-s086><absorb.aufnehmen><en> Another expression for rusting is oxidating, which means that iron (Fe2+) reacts with the dissolved oxygen in the water and transforms into water insoluble iron (Fe3+) which aquatic plants can no longer absorb normally.
<G-vec00476-001-s087><absorb.aufnehmen><de> "Nur ein kleiner Teil dieser sogenannten ""Lebenseinheiten"" kann als Nahrung vom Organismus aufgenommen werden, nämlich die rot markierten Lebenseinheiten."
<G-vec00476-001-s087><absorb.aufnehmen><en> "The organism can absorb only a small number of these so-called ""life units"" as nourishment, namely, the life units that are coloured red."
<G-vec00169-001-s032><capture.aufnehmen><de> Der Joker in Batman müssen bei der Aufnahme.
<G-vec00169-001-s032><capture.aufnehmen><en> The joker in Batman have to capture at.
<G-vec00169-001-s033><capture.aufnehmen><de> Der Kocher ist eine Struktur, wo fermentierte Kot der Tiere und sogar Menschen als Überschuss und Schrott und Ablehnungen von Gemüse, Kaffee Zellstoff, erhalten Sie eine Gas als Biogas bezeichnet, nützlich zum Kochen, Heizen oder Warmwasserbereitung von kleinen Schweinen andere Nutzungen, wodurch eine saubere Energiequelle, die das Holz Pflüge nicht für einige als Stahl verwendet und um die Aufnahme von Gasen, die globale Erwärmung und die Entwaldung verursachen beitragen.
<G-vec00169-001-s033><capture.aufnehmen><en> The digester is a structure where fermented feces of animals and even human beings as surplus and scrap and rejections of vegetables, coffee pulp, you get a gas called biogas, useful for cooking, heating or water heating from small pigs other uses, thereby obtaining a clean energy source that plows the wood is not used for some than steel and will contribute to the capture of gases that cause global warming and deforestation.
<G-vec00169-001-s034><capture.aufnehmen><de> QTest speichert alle Input/Output-Flows des für die Aufnahme genutzten Browsers, den Kontext, die Reaktionszeit des Users und die Parallelitäten und Synchronisation zwischen den Verbindungen um das Nutzerverhalten komplett zu simulieren.
<G-vec00169-001-s034><capture.aufnehmen><en> QTest saves all of the input/output flow from the browser used for the capture, as well as the context, the user's thinking time, and the parallelism and synchronization between connections to comply with and guarantee the user's actual behavior.
<G-vec00169-001-s035><capture.aufnehmen><de> Durch das große Spektrum an Möglichkeiten zur Aufnahme von Bildern wie es von modernen elektronischen Geräten geboten wird ist es einfacher als je zuvor, die eigenen Bilder und Videos großartig aussehen zu lassen, wobei diese durch die Nutzung zusätzlicher Accessoires noch spektakulärer gestaltet werden können.
<G-vec00169-001-s035><capture.aufnehmen><en> With the full range of image capture capabilities offered by today's advanced electronic devices, it's never been easier to make your pictures and videos look great, while making them even more spectacular with the addition of accessories.
<G-vec00169-001-s036><capture.aufnehmen><de> Diese Lösungen erfordern oft spezielle Beleuchtungen, die Aufnahme mehrerer Bilder mit unterschiedlichen Lichtgeometrien und eine ausgeklügelte Softwareverarbeitung, um synthetische Bilder aus der Kombination der verschieden beleuchteten Bilder zu erzeugen.
<G-vec00169-001-s036><capture.aufnehmen><en> These solutions often require specialist illuminators, the capture of multiple images with different lighting geometries and then software processing to extract synthetic images from the combination of illumination images.
<G-vec00169-001-s037><capture.aufnehmen><de> Es hat einen historischen Rückgang aufgrund der Aufnahme und Ausgabe von Tausenden von Vögeln aus Angola, Dies hat dazu beigetragen,, zu einem großen Teil, eine deutliche Reduktion der Population Rosenköpfchen im Süden des Landes.
<G-vec00169-001-s037><capture.aufnehmen><en> There has been a historic decline due to the capture and export of thousands of birds from Angola, This has contributed, to a large extent, a significant reduction in the population Rosy-faced Lovebird in the south of the country.
<G-vec00169-001-s038><capture.aufnehmen><de> PMD Time-of-Flight-Technologie Mit der PMD-Time-of-Flight-Technologie werden Szenen und Objekte mit nur einer Aufnahme dreidimensional und ohne Bewegungsverzerrung erfasst.
<G-vec00169-001-s038><capture.aufnehmen><en> The PMD time-of-flight technology ensures detection of scenes and objects with just one image capture in three dimensions and without motion blur.
<G-vec00169-001-s039><capture.aufnehmen><de> Pro Szene können bis zu 8 Gesichter erkannt werden, wobei Optimalbelichtung, Weißabgleich, Blitz und andere Parameter zur Aufnahme von Porträts optimiert werden.
<G-vec00169-001-s039><capture.aufnehmen><en> Face Detection recognises up to 8 faces in a scene, optimising exposure, white balance, flash and other settings for portraits Capture spectacular panoramas
<G-vec00169-001-s040><capture.aufnehmen><de> Athen fiel im Jahre 1456 in Belgrad, und entkam nur knapp der Aufnahme, wenn ein Bauer Armee von der ungarischen Janos Hunyadi führte hielt einen Platz im selben Jahr jedoch, Serbien, Bosnien, der Walachei und der Khanat der Krim waren alle unter der osmanischen Kontrolle im Jahr 1478.
<G-vec00169-001-s040><capture.aufnehmen><en> Athens fell in 1456 in Belgrade, and narrowly escaped capture when a peasant army led by the Hungarian Janos Hunyadi held a place in the same year, however, Serbia, Bosnia, Wallachia and the Khanate of Crimea were all under the Ottoman control in 1478.
<G-vec00169-001-s041><capture.aufnehmen><de> Aber dass diese Screenshot nicht sagen, ist, dass 907 in drei sehr unterschiedliche Versionen von jedem anderen kommt, dass 907 bietet viele Anpassungsmöglichkeiten, und schließlich, dass diese Aufnahme Bildschirm nicht sagen, ist, dass nur ein paar Tage, dieses Thema zu den Bestsellern des Monats gestiegen.
<G-vec00169-001-s041><capture.aufnehmen><en> But that this screenshot does not tell you is that 907 comes in three very different versions of each other, that 907 offers many customization options, and finally, that this capture screen does not tell you is that only a few days, this topic has risen among the best sellers of the month.
<G-vec00169-001-s042><capture.aufnehmen><de> Die IEI USB 3.0 Unkomprimierte Full HD Aufnahmebox ermöglicht Benutzern die Aufnahme von hochauflösendem Video von HDMI Geräten für das Live Streaming über DJ2 Live.
<G-vec00169-001-s042><capture.aufnehmen><en> The IEI USB 3.0 Uncompressed Full HD Capture Box allows users to capture high-resolution footage from HDMI devices for livestreaming through DJ2 Live.
<G-vec00169-001-s043><capture.aufnehmen><de> Der HEPA-Filter hilft bei der Aufnahme des Feinstaubs, der die Allergie auslösenden Milben oder der tierischen Allergene.
<G-vec00169-001-s043><capture.aufnehmen><en> The HEPA filter helps to capture even the finest dust, allergenic mites or animal allergens.
<G-vec00169-001-s044><capture.aufnehmen><de> Sobald die Aufnahme gestartet ist werden USB 3.0 Daten unmittelbar auf dem Bildschirm angezeigt.
<G-vec00169-001-s044><capture.aufnehmen><en> Once the capture is started, USB 3.0 data is displayed immediately on the screen.
<G-vec00169-001-s045><capture.aufnehmen><de> Die Person, die in diesem Artikel war ziemlich anspruchsvoll, Sie vorsichtig bei Aufnahme und erhalten hatte, Informationen aus Müllcontainern(zerkleinern, diese Dokumente und Wischen Sie diese Festplatten), DDoS-Attacken bedroht, usw..
<G-vec00169-001-s045><capture.aufnehmen><en> The person in this article was quite sophisticated, wary of capture and had obtained information from dumpsters(shred those documents and wipe those hard drives), threatened DDoS attacks, etc.
<G-vec00169-001-s046><capture.aufnehmen><de> "Fünf verschiedene Sicherheitslücken in diesem Programm können durch ""speziellen"" Datenverkehr über ein Netzwerk ausgenutzt werden, wenn Ethereal gerade zum Sniffen oder zur Aufnahme von Daten genutzt wird."
<G-vec00169-001-s046><capture.aufnehmen><en> Five different vulnerabilities can be exploited by exposing the Ethereal program to specially created network traffic, be it by sniffing a live network or reading a capture file.
<G-vec00169-001-s047><capture.aufnehmen><de> Somit wird nicht nur ein Punkt, sondern eine komplette Szene in nur einer Aufnahme vermessen.
<G-vec00169-001-s047><capture.aufnehmen><en> That means that not only one point but a complete scene is measured in only one capture.
<G-vec00169-001-s048><capture.aufnehmen><de> Der Portrait-Modus wird verbessert, jetzt mit der Fähigkeit, das Niveau der Hintergrundunschärfe nach der Aufnahme anpassen, Das ist Spaß.
<G-vec00169-001-s048><capture.aufnehmen><en> The portrait mode has also been improved, now with the ability to adjust the level of background blur after capture, which is fun.
<G-vec00169-001-s049><capture.aufnehmen><de> Die beiden Stellar-Infinity-Detektoren und die Vectron-Röntgenröhren des Somatom Force benötigen für die Aufnahme des ganzen Oberkörpers nicht einmal eine Sekunde.
<G-vec00169-001-s049><capture.aufnehmen><en> The two Stellar Infinity detectors and the Vectron X-ray tube in the Somatom Force need less than a second to capture the entire upper body.
<G-vec00169-001-s050><capture.aufnehmen><de> Spyder5CAPTURE PRO: Das ultimative Bundle mit allen notwendigen Werkzeugen für das Farbmanagement im fotografischen Workflow von der Aufnahme bis zur Bildbearbeitung.
<G-vec00169-001-s050><capture.aufnehmen><en> Spyder5CAPTURE PRO: The ultimate bundle with all the essentials to manage color from capture to editing in any photography workflow.
<G-vec00476-001-s097><absorb.aufnehmen><de> Spathiphyllum verdampfen das Wasser, das sie mit ihren Wurzeln aufnehmen und dadurch die Feuchtigkeit verbessern.
<G-vec00476-001-s097><absorb.aufnehmen><en> Spathiphyllum evaporate the water that they absorb with their roots and thereby improve the humidity.
<G-vec00476-001-s098><absorb.aufnehmen><de> Damit unser Körper Omega-3 aus a-Linolensäure aufnehmen kann, muss sie in die langkettigen essentiellen Fettsäuren EPA (Eicosapentaensäure) und DHA (Docosahexaensäure) umgewandelt werden.
<G-vec00476-001-s098><absorb.aufnehmen><en> To enable us to absorb Omega-3 from ALA, it needs to be converted to the long-chain essential fatty acid forms EPA (eicosapentaenoic acid) and DHA (docosahexaenoic acid).
<G-vec00476-001-s099><absorb.aufnehmen><de> Flechten sind eine Lebensgemeinschaft oder Symbiose von Pilz und Alge, die Wasser aus der Luft aufnehmen kann.
<G-vec00476-001-s099><absorb.aufnehmen><en> Lichens are a life-form or symbiosis of fungi and algae which can absorb water from the air.
<G-vec00476-001-s100><absorb.aufnehmen><de> Im Vordergrund steht die Entwicklung neuartiger elektronischer Komponenten, die Strahlung aus dem für das Auge unsichtbaren nahen Infrarotbereich (NIR) aufnehmen beziehungsweise abgeben können.Darüber hinaus bietet die BayFOR Informationen über ihr Serviceportfolio und erweitert auf der Nanotexnology ihr Netzwerk, um mögliche Kooperationspartner für zukünftige EU-Förderanträge bayerischer Akteure zu identifizieren.
<G-vec00476-001-s100><absorb.aufnehmen><en> It concentrates primarily on the development of innovative electronic components that can absorb and/or emit radiation from the near infrared range which are imperceptible to the human eye. In addition to that, BayFOR provides information about its service portfolio and aims to expand its network at the Nanotexnology to identify possible cooperation partners for future EU funding applications of Bavarian stakeholders.
<G-vec00476-001-s101><absorb.aufnehmen><de> Fette und Proteine liegen in Verhältnissen vor, wie sie unser Körper benötigt und fast vollständig aufnehmen kann.
<G-vec00476-001-s101><absorb.aufnehmen><en> Fats and proteins are present in conditions that our body requires and can absorb almost completely.
<G-vec00476-001-s102><absorb.aufnehmen><de> Diese Hohlfasern kann bis zu 30% ihres Eigengewichts an Feuchtigkeit aufnehmen, ohne sich nass anzufühlen, halten Sie perfekt bei jedem Wetter trocken.
<G-vec00476-001-s102><absorb.aufnehmen><en> These hollow fibers can absorb up to 30% of their own weight in moisture without feeling wet, keeping you perfectly dry regardless of the weather.
<G-vec00476-001-s103><absorb.aufnehmen><de> "Darüber hinaus werden alle Parasiten, wie etwa Würmer, aus dem Körper gespült, was den Körper von allen Ablenkungen der ""alten"" Realität befreit und außerdem kann der Körper dadurch die Wirkstoffe besser aufnehmen."
<G-vec00476-001-s103><absorb.aufnehmen><en> "In addition, any parasites, such as worms, are rinsed out of the body which frees the body from any distractions of the ""old"" reality and the body can absorb the active substances more readily."
<G-vec00476-001-s104><absorb.aufnehmen><de> Es wird auch angenommen, dass die Puzzolane Feuchtigkeit aus der Luft, vom Tau der Nacht aufnehmen und übertragen auf die Pflanzen; ihre schwarze Farbe absorbiert maximale Wärme von der Sonne.
<G-vec00476-001-s104><absorb.aufnehmen><en> It is also thought that the pozzolan absorb moisture from the air, the dew of the night, and transmit to the plants; their black color absorbs maximum heat from the sun.
<G-vec00476-001-s105><absorb.aufnehmen><de> Nano Füllstoff-Masterbatch ist leicht Feuchtigkeit aus der Luft aufnehmen.
<G-vec00476-001-s105><absorb.aufnehmen><en> Nano filler masterbatch is easily to absorb moisture from air.
<G-vec00078-001-s266><accept.aufnehmen><de> Wir können in den Seminaren keine weiteren Kandidaten aufnehmen, weil wir nicht wissen, wohin wir sie anschließend zum priesterlichen Dienst schicken sollen, und wir können mit ihnen auch nicht anderen Kirchen außerhalb unseres Landes aushelfen, da die Mehrheit von ihnen ihr Priestertum mit dem Ehestand verbindet, weshalb ihnen die Länder des Westens verschlossen sind.
<G-vec00078-001-s266><accept.aufnehmen><en> We cannot accept any more in the seminary because we have no more places to send them to carry out their priestly service, and we cannot help in other churches outside of our country, given that most of them join their priestly life with married life and are thus precluded from Eastern lands.
<G-vec00078-001-s267><accept.aufnehmen><de> Egal, ob Sie auf dem Weg zu den Inseln durch Oban fahren oder ein paar Tage bleiben und das historische und wunderschöne Argyll erkunden, das Original Oban Backpackers ist der richtige Ort für Sie!Unser funky Hostel ist Teil der weltberühmten 'Scotland's Top Hostels' Kette und wir freuen uns darauf, Sie in Oban begrüßen zu dürfen.Da es sich bei unserer Unterkunft um Schlafsäle handelt, können wir nur Familien mit Kindern aufnehmen, wenn das ganze Zimmer zur alleinigen Belegung gebucht wurde.
<G-vec00078-001-s267><accept.aufnehmen><en> Whether you're passing through Oban on the way to the Islands, or staying for a couple of days and exploring historic and beautiful Argyll, the original Oban Backpackers is the place for you!Our funky hostel is part of the World famous 'Scotland's Top Hostels' chain and we look forward to welcoming you to Oban.As our accommodation is comprised of dorm rooms, we can only accept families with children if the whole room has been booked for sole occupancy.
<G-vec00078-001-s268><accept.aufnehmen><de> Sie bleibt hartnäckig und geduldig, auch wenn wir ihr nicht glauben und sie oberflächlich aufnehmen.
<G-vec00078-001-s268><accept.aufnehmen><en> She remains perseverant and patient even when we do not have faith in her and accept her superficially.
<G-vec00078-001-s269><accept.aufnehmen><de> Er kann auch bis zu 32 einzelne 0,2 ml PCR-Röhrchen aufnehmen.
<G-vec00078-001-s269><accept.aufnehmen><en> It will also accept up to 32 individual 0,2 ml tubes.
<G-vec00078-001-s270><accept.aufnehmen><de> Tatsächlich kann eine Konfrontation mit dem Westen die Situation in Russland grundlegend ändern, und zwar in allen sozialen Schichten, vor allem aber in der Oberschicht, die nicht nur verstehen, sondern am eigenen Leib spüren wird, dass die westliche Elite sie niemals in ihre Kreise aufnehmen wird, sondern dass sie ganz im Gegenteil früher oder später von ihr gefressen wird.
<G-vec00078-001-s270><accept.aufnehmen><en> Indeed, the confrontation with the West can fundamentally change the situation in Russia, in all social strata and above all in the upper class, which will not only understand but feel first-hand that the Western elite will never accept them in their circles, and sooner or later they will be devoured up.
<G-vec00078-001-s271><accept.aufnehmen><de> Das Arbeitslager wollte Li Zhen nicht aufnehmen, woraufhin ihn die Agenten des nationalen Sicherheitsbüros zu einer Untersuchung in ein Krankenhaus brachten.
<G-vec00078-001-s271><accept.aufnehmen><en> The labour camp authorities refused to accept him, and the National Security Bureau agents then took Li Zhen to a hospital for a physical exam.
<G-vec00078-001-s272><accept.aufnehmen><de> Zwar konnte sich Angela Merkel mit ihrem Vorschlag, die EU-Förderung für Mitgliedstaaten einzuschränken, die keine Flüchtlinge aufnehmen wollen, nicht richtig durchsetzen, doch auf die EU-Kommission, insbesondere auf den für Haushalt zuständigen deutschen Kommissar, Günther Oettinger, kann sich die Bundeskanzlerin verlassen.
<G-vec00078-001-s272><accept.aufnehmen><en> Although Angela Merkel has not been able to stand up for herself with her proposal to cut funding to member states that refuse to accept refugees, she can rely on the European Commission and in particular on the German Commissioner for Budget and Human Resources Günther Oettinger.
<G-vec00078-001-s273><accept.aufnehmen><de> Sagt folgendes:Von der großen Schatzkammer der Natur, wo sich so viel Weisheit und Liebe verbirgt, lasse ich meine Hände polarisieren, ich will die Weisheit und die Liebe aufnehmen, das Gute aufnehmen und die Verbindung, die alle Menschen der Erde vereinigt.
<G-vec00078-001-s273><accept.aufnehmen><en> "Say: ""I want my hands to be polarized from the great store of Nature, where great Wisdom and Love are hidden, so that I could accept them, I could accept Good – the uniting link, that serves to all the people on Earth."""
<G-vec00078-001-s275><accept.aufnehmen><de> Temporär können wir leider keine neuen Alumni-Stellenprofile aufnehmen.
<G-vec00078-001-s275><accept.aufnehmen><en> Temporarily, we can not accept any new alumni job profiles.
<G-vec00078-001-s276><accept.aufnehmen><de> Dieses Kennen wäre hingegen Gott in unser Leben aufnehmen, sich in Ihn verlieren, um Seine Liebe, Seinen Frieden, Seine Barmherzig-keit auszukosten.
<G-vec00078-001-s276><accept.aufnehmen><en> Instead, we are called to accept God into our life, to lose ourselves in Him, to savour His Love, His peace, His mercy, and thus to know Him.
<G-vec00078-001-s277><accept.aufnehmen><de> und wer irgend ein solches Kindlein aufnehmen wird in meinem Namen, nimmt mich auf.
<G-vec00078-001-s277><accept.aufnehmen><en> And whoever shall accept one such little child in my name, accepts me.
<G-vec00078-001-s278><accept.aufnehmen><de> Der Mensch, der den Willen hat, gut, also dem Willen Gottes gemäß, zu leben, wird niemals ohne geistigen Beistand gelassen, er wird geführt, sein Denken wird gelenkt, d.h., die Willensfreiheit wird ihm zwar nicht beschnitten, aber die Gedanken treten ihm so greifbar nahe, daß er sie aufnehmen muss, so er sich nicht bewußt abwendet von ihnen.
<G-vec00078-001-s278><accept.aufnehmen><en> A person with the will to live a good life, thus to live according to God’s will, is never left without spiritual guidance, he will be guided, his thoughts will be directed, i.e., although his freedom of will is not being curtailed, the thoughts will come so close to him that he has to accept them if he does not consciously reject them.
<G-vec00078-001-s279><accept.aufnehmen><de> 23:1 Du sollst kein falsches Gerücht aufnehmen; du sollst deine Hand nicht dem Gesetzlosen reichen, um ein ungerechter Zeuge zu sein.
<G-vec00078-001-s279><accept.aufnehmen><en> 23:1 Thou shalt not accept a false report; extend not thy hand to the wicked, to be an unrighteous witness.
<G-vec00078-001-s280><accept.aufnehmen><de> Der Betrieb ist nur zulässig, wenn die folgenden beiden Bedingungen erfüllt sind: (1) Dieses Gerät darf keine schädlichen Interferenzen erzeugen und (2) Dieses Gerät muss empfangene Interferenzen aufnehmen, auch wenn diese zu Betriebsstörungen führen können.
<G-vec00078-001-s280><accept.aufnehmen><en> Operation is subject to the following two conditions: (1) This device may not cause harmful interference, and (2) this device must accept any interference received, including interference that may cause undesired operation.
<G-vec00078-001-s281><accept.aufnehmen><de> Alle Personen (österreichische Staatsbürgerinnen wie nicht-österreichische StaatsbürgerInnen), die ihren Wohnsitz - oder mangels eines solchen ihren ständigen Aufenthaltsort - in Österreich haben, dem AMS einen Arbeitsvermittlungsauftrag erteilt haben, der Arbeitsvermittlung zur Verfügung stehen (das sind im wesentlichen Personen, die sofort eine Beschäftigung aufnehmen können und dürfen sowie arbeitsfähig und arbeitswillig sind), unabhängig davon, ob sie eine Leistung nach dem Arbeitslosenversicherungsgesetz beziehen oder nicht, und unabhängig davon, ob sie beschäftigt sind.
<G-vec00078-001-s281><accept.aufnehmen><en> · Anyone (whether an Austrian citizen or not) who resides in Austria – or in the absence of a permanent residence, has a habitual abode in Austria – and has filed a job placement application with the AMS, and is available to take a job (essentially, anyone who is practically and legally able to accept employment immediately and is fit and willing to work), irrespective of whether they are drawing benefits under the Unemployment Insurance Law, or whether they are already employed.
<G-vec00078-001-s282><accept.aufnehmen><de> Wir haben uns entschieden, diesem Ärger ein Ende zu setzen, indem wir endlich sämtliche Unterstützenden, unabhängig von der Natur ihrer Beiträge in das Herz des Debian-Projekts geholt und die Debian-Kontenführer eingeladen haben, Prozeduren zum Bewerten und Aufnehmen von nicht programmierenden Helferinnen und Helfern zu entwickeln.
<G-vec00078-001-s282><accept.aufnehmen><en> It was decided to end this nuisance by finally welcoming all contributors, regardless of the nature of their contribution into the heart of the Debian Project and invite the Debian Account Managers to establish procedures to evaluate and accept non-packaging contributors.
<G-vec00078-001-s283><accept.aufnehmen><de> Alle werden gerecht, die Gottes Wort aufnehmen, obgleich sie Sünder waren.
<G-vec00078-001-s283><accept.aufnehmen><en> Those who accept His Word are righteous, even though they were previously sinners.
<G-vec00078-001-s284><accept.aufnehmen><de> Der Saal Strossmayer ist nach den höchsten ästhetischen und technischen Kriterien eingerichtet und kann bis zu 50 Teilnehmer aufnehmen.
<G-vec00078-001-s284><accept.aufnehmen><en> The hall Strossmayer is equipped with the highest esthetical and technical criteria and can accept up to 50 participants.
<G-vec00503-001-s062><admit.aufnehmen><de> Das Gefängnis wollte ihn wegen seiner schlechten Gesundheit nicht aufnehmen, ihm wurde jedoch keine Freilassung aus medizinischen Gründen gewährt.
<G-vec00503-001-s062><admit.aufnehmen><en> The prison refused to admit him because of his poor health, but he was not granted release for medical reasons.
<G-vec00503-001-s063><admit.aufnehmen><de> Um weiterhin Kinder aus allen sozialen Schichten aufnehmen zu können, ist die Waldorfschule auf Unterstützung angewiesen.
<G-vec00503-001-s063><admit.aufnehmen><en> In order to continue to admit children from socially disadvantaged backgrounds, Windhoek Waldorf School remains dependent on your support.
<G-vec00503-001-s064><admit.aufnehmen><de> Fräulein Lederle konnte Simone noch nicht aufnehmen,da ihre Papiere noch nicht eingetroffen waren.
<G-vec00503-001-s064><admit.aufnehmen><en> Fraülein Lederle could not admit Simone because she had not yet received her paperwork.
<G-vec00503-001-s065><admit.aufnehmen><de> Seit dem Schuljahr 2007/08 darf die Schule auch äthiopische Staatsangehörige aufnehmen, die einen Bezug zu Deutschland haben.
<G-vec00503-001-s065><admit.aufnehmen><en> Since the 2007/08 school year, the School has also been allowed to admit Ethiopian nationals that have some connection with Germany.
<G-vec00503-001-s066><admit.aufnehmen><de> Doch die Mittel des Kindergartens sind nur sehr begrenzt, weshalb es enorm wichtig ist, durch Bildungsgutscheine (Patenschaften) dem Kindergarten zu ermöglichen, weitere Kinder aufnehmen zu können.
<G-vec00503-001-s066><admit.aufnehmen><en> Nonetheless, the financial means of the kindergarten remain restricted, which is why it is very important to allow the initiative to admit further children through educational sponsorships.
<G-vec00503-001-s067><admit.aufnehmen><de> Wir konnten so trotz großzügigster Vorgehensweise nur 86 Kinder in die Klassen VI aufnehmen und nur 56 für die Klassenstufe X.
<G-vec00503-001-s067><admit.aufnehmen><en> We managed, despite our generosity, to admit 86 children for grade VI and only 56 for grade X.
<G-vec00503-001-s068><admit.aufnehmen><de> 3.4 Der Verein kann assoziierte / außerordentliche Mitglieder aufnehmen.
<G-vec00503-001-s068><admit.aufnehmen><en> 3.4 The association can admit associated / extraordinary members.
<G-vec00503-001-s069><admit.aufnehmen><de> Private oder privatgewerbliche Einrichtungen können Kinder unabhängig von ihrem Wohnort aufnehmen.
<G-vec00503-001-s069><admit.aufnehmen><en> Private or private commercial facilities can admit children regardless of their place of residence.
<G-vec00503-001-s070><admit.aufnehmen><de> Während die unterschiedlichen jüdischen Gemeinschaften damit beschäftigt sind, zu klären, wen sie in ihre Reihen aufnehmen wollen, sind sich Nichtjuden oft nicht ganz sicher, mit wem sie es zu tun haben.
<G-vec00503-001-s070><admit.aufnehmen><en> Whereas many Jewish communities are currently attempting to clarify who they wish to admit into their ranks, non-Jews are often unsure of who they are dealing with.
<G-vec00078-001-s139><adopt.aufnehmen><de> Die Tatsache, dass Berufstätige ihrer Familie oder Freunden zuliebe oft nach Feierabend oder an ihren freien Tagen den normalen Tagesrhythmus wieder aufnehmen, verlangt kurzzeitige Anpassungen.
<G-vec00078-001-s139><adopt.aufnehmen><en> The fact that, in order to share with their families and for social reasons, these people adopt day rhythms on their days off or holidays makes for temporary adjustments.
<G-vec00078-001-s140><adopt.aufnehmen><de> Wer glaubt, in seiner Arbeit die beste Anstrengung für das Wohl der Menschheit zu leisten, muss den Herrscher in sein Herz aufnehmen.
<G-vec00078-001-s140><adopt.aufnehmen><en> He who in his labor hopes to bring the best efforts for the good of humanity must adopt the Lord with his heart.
<G-vec00078-001-s141><adopt.aufnehmen><de> Die feste Überzeugung vom freien Willen würde unvermeidlich auch als eine konkrete Vorschrift funktionieren, der einmal festgesetzte freie Wille würde in einem konkreten sozialen und ethischen Rahmen wie von allein feste Konturen aufnehmen.
<G-vec00078-001-s141><adopt.aufnehmen><en> The firm conviction of free will would work thus inevitably also as a concrete prescription, the once fixed free will would adopt, like on its own, solid contours in a concrete social and ethical framework.
<G-vec00078-001-s142><adopt.aufnehmen><de> Diese werden ganz verwundert große Augen machen, dass sie in mir einen Knaben erblicken, der ihrem Josoe so ähnlich sieht wie ein Auge dem andern; dann mag Jairus sagen, dass ich ein Findling sei und sogar den Namen des Verstorbenen führe, und meine Eltern werden mich ohne weiteres an Kindes Statt aufnehmen und mich lieben mehr denn ihren Josoe.
<G-vec00078-001-s142><adopt.aufnehmen><en> These shall look quite amazed at seeing a boy who resembles their Josoe like one eye another. Then Jairus can say that I am a foundling who even bears the name of the deceased, and my parents shall without much ado adopt me in place of the child, loving me even more than their Josoe.
<G-vec00078-001-s143><adopt.aufnehmen><de> Alle Nachbar- und andere Länder, die sie eroberten, werden in einem Augenblick ihren spezifischen Stil aufnehmen, den später das Römische Reich erben wird.
<G-vec00078-001-s143><adopt.aufnehmen><en> All the neighbor countries and the others conquered by them, will adopt, in one or another moment, its particular style, which later will be inherited by the Roman Empire.
<G-vec00078-001-s144><adopt.aufnehmen><de> Es gibt mehrere Regeln uz beachten: - Sie brauchen mindestens 0 Rufspunkte, um Einen Hund aus dem Tierheim aufnehmen zu können.
<G-vec00078-001-s144><adopt.aufnehmen><en> Several house rules: - You must have at least 0 reputation points to Adopt a dog from the sanctuary.
<G-vec00078-001-s145><adopt.aufnehmen><de> Wenn wir diese Da'wah Mission wirklich aufnehmen, eine Mission, die der Islam von uns allen verlangt, bete ich zu Allah – ta'ala -, dass wir vielmehr Erfolg haben werden, den Islam zu den Leuten Amerikas zu bringen, als die Leute zuvor.
<G-vec00078-001-s145><adopt.aufnehmen><en> If we truly adopt this da'wah mission, a mission which Islam requires of us, I pray to Allah ta'aala that we will have much more success in bringing Islam to the American people than ever before.
<G-vec00078-001-s146><adopt.aufnehmen><de> Verdichtungskostenstellen sind Kostenstellen, die Werte von anderen Kostenstellen aufnehmen und als Gesamtwert darstellen.
<G-vec00078-001-s146><adopt.aufnehmen><en> Rollup cost centers are cost centers which adopt values from other cost centers and display them as total value.
<G-vec00505-001-s023><borrow.aufnehmen><de> Es könnten Eurobonds zur Finanzierung der Industriepolitik aufgelegt werden; eine neue Europäische Öffentliche Investitionsbank könnte direkt bei der EZB Geld aufnehmen; die EZB könnte direkt Gelder fÃ1⁄4r die Industriepolitik bereitstellen.
<G-vec00505-001-s023><borrow.aufnehmen><en> Eurobonds could be created to fund industrial policy; a new European Public Investment Bank could borrow funds directly from the ECB; the ECB could directly provide funds for industrial policy.
<G-vec00505-001-s024><borrow.aufnehmen><de> 2014 will die Bank 70Milliarden Euro aufnehmen.
<G-vec00505-001-s024><borrow.aufnehmen><en> In 2014, the Bank plans to borrow EUR 70bn.
<G-vec00505-001-s025><borrow.aufnehmen><de> Die EIB verfügt über ein AAA-Rating und kann daher auf den internationalen Kapitalmärkten Mittel zu hervorragenden Bedingungen aufnehmen.
<G-vec00505-001-s025><borrow.aufnehmen><en> The EIB has an AAA credit rating and, therefore, is able to borrow funds at keen terms in international capital markets.
<G-vec00505-001-s026><borrow.aufnehmen><de> Zudem stellt Schaltbau mit den Erlösen aus der Transaktion die Finanzierung der Ende Februar anstehenden Kreditrückführungen sicher, ohne neue Fremdmittel aufnehmen zu müssen.
<G-vec00505-001-s026><borrow.aufnehmen><en> "In addition, the proceeds from the transaction ensure Schaltbau""s ability to finance loan repayments due at the end of February without needing to borrow new funds."
<G-vec00505-001-s027><borrow.aufnehmen><de> Die Partnerbanken tragen ebenfalls zur Finanzierung bei, so dass die Schulen insgesamt 600Mio EUR aufnehmen können.
<G-vec00505-001-s027><borrow.aufnehmen><en> The partner banks are also contributing to the financing which will enable schools to borrow a total of EUR 600m.
<G-vec00505-001-s028><borrow.aufnehmen><de> Aufgrund ihrer Satzung und ihrer Anteilseigner – die 27 Mitgliedstaaten, darunter Rumänien – verfügt die EIB über ein AAA-Rating und kann daher an den Kapitalmärkten Mittel zu günstigen Konditionen aufnehmen, die sie über Darlehen an ihre Kunden und Endbegünstigten weitergibt.
<G-vec00505-001-s028><borrow.aufnehmen><en> Thanks to its Statute and shareholders (the 27 Member States, including Romania), the EIB has a AAA rating and can therefore borrow funds on the capital markets on favourable terms, which it passes on via the loans that it grants to its customers and final beneficiaries.
<G-vec00169-001-s051><capture.aufnehmen><de> Fotos, Videos zusammen mit Serienaufnahmen, und lange Videos aufnehmen Mit der Zoe Kamera können Sie ein Foto, ein Video mit Serienaufnahmen und ein Video aufnehmen, ohne die Kameramodi ändern zu müssen.
<G-vec00169-001-s051><capture.aufnehmen><en> Capture photos, video along with burst shots, and long videos With Zoe Camera, you can take a photo, shoot video with burst shots, and capture video without having to switch camera modes.
<G-vec00169-001-s053><capture.aufnehmen><de> Es kann weiterhin die Fotos durch Hacken und Vorder- und Rückkamera des Android-Smartphones aufnehmen und auch aufnehmen hack das Mikrofon still zu notieren Konversation und Umgebung.
<G-vec00169-001-s053><capture.aufnehmen><en> It can further capture the photos by hacking and front and back camera of the Android smartphone and can also hack the microphone silently to record the conversation and surroundings.
<G-vec00169-001-s054><capture.aufnehmen><de> Mit der EX-TR150 können Sie brillante Full HD-Videos (H.264) mit einer Auflösung von bis zu 1920x1080 Pixel aufnehmen.
<G-vec00169-001-s054><capture.aufnehmen><en> Thanks to the EX-TR150, you are now able to capture brilliant videos in full HD (H.264) with a resolution of up to 1920x1080 pixels.
<G-vec00169-001-s055><capture.aufnehmen><de> Entwurf glücklich mit der Befestigung auf dem Monitor, hat auch auf die schnelle aufnehmen.
<G-vec00169-001-s055><capture.aufnehmen><en> Design a successful mount the monitor also has the button for quick image capture.
<G-vec00169-001-s056><capture.aufnehmen><de> Die eingebauten 6pcs IR-Cut LEDs ermöglichen diese Überwachungskamera Bilder bis zu 10 Meter Entfernung aufnehmen.
<G-vec00169-001-s056><capture.aufnehmen><en> The built-in 6pcs IR-cut LEDs enable this surveillance camera capture clear night vision images up to 10 meters distance.
<G-vec00169-001-s057><capture.aufnehmen><de> Bilder können durch Drücken des Gitter-Symbols in der Live-View-Ansicht (Aufnehmen) hinzugefügt werden.
<G-vec00169-001-s057><capture.aufnehmen><en> Pictures may be used by selecting the grid icon from the live view (capture) screen.
<G-vec00169-001-s058><capture.aufnehmen><de> Einfach den Computer mit dem USB-Kabel anschließen und mit Deiner bevorzugten Recordingssoftware Deinen Gesang mit Harmonisierung und Effekten aufnehmen.
<G-vec00169-001-s058><capture.aufnehmen><en> Just connect to your computer with a USB cable and use your favorite recording software to capture your voice with harmonies and effects.
<G-vec00169-001-s059><capture.aufnehmen><de> Sie können sehen, was Ihre Mitarbeiter in Bezug auf Bilder und Fotos heruntergeladen haben, oder sie haben die Handykamera zum Aufnehmen von Fotos verwendet.
<G-vec00169-001-s059><capture.aufnehmen><en> You can see what your employees have downloaded in terms of images and photos or they have used mobile phone camera to capture photos.
<G-vec00169-001-s060><capture.aufnehmen><de> Wenn du eine V4L-kompatible Radioempfänger karte hast und mit MPlayer Radio hören oder aufnehmen möchtest, lies den Abschnitt radio.
<G-vec00169-001-s060><capture.aufnehmen><en> If you have a V4L compatible radio tuner card, and wish to listen and capture sound with MPlayer, read the radio section.
<G-vec00169-001-s061><capture.aufnehmen><de> Mit der weltweit meistverkauften Suite für digitale Medien ist das Aufnehmen, Verbessern, Speichern und Weitergeben Ihrer Foto-, Video- und Audio-Projekte ein Leichtes.
<G-vec00169-001-s061><capture.aufnehmen><en> The world's best-selling digital media suite makes it easy to capture, enhance, save and share your photo, video and audio projects.
<G-vec00169-001-s062><capture.aufnehmen><de> Entscheide, ob du Videoclips mit der Kamera aufnehmen möchtest.
<G-vec00169-001-s062><capture.aufnehmen><en> Decide if you want to capture video with the camera.
<G-vec00169-001-s063><capture.aufnehmen><de> Alternativen zu Dashtis inszenierten Dokumentationen können in den Werken der Ägypterin Rana El Nemr und der Jordanierin Tanya Habjouqa gefunden werden, die beide Menschen im urbanen Umfeld direkt aufnehmen.
<G-vec00169-001-s063><capture.aufnehmen><en> Alternatives to Dashti’s staged documentaries can be found in the works of Egyptian Rana El Nemr and Jordanian Tanya Habjouqa, both of whom directly capture people in urban settings.
<G-vec00169-001-s064><capture.aufnehmen><de> Durch seine Konstruktion kann der Diahalter Rahmen in allen Stärken aufnehmen.
<G-vec00169-001-s064><capture.aufnehmen><en> Due to its structure, the slide adapter can capture frames of all thicknesses.
<G-vec00169-001-s065><capture.aufnehmen><de> Optimal für Ihr Android-Smartphone, Actionkameras oder Drohnen - mit dieser hochleistungsfähige microSD-Speicherkarte können Sie 4K UHD Video, Full HD Video und hochauflösende Fotos aufnehmen.
<G-vec00169-001-s065><capture.aufnehmen><en> Optimal for your Android smartphone, action cameras or drones, this high-performance microSD memory card lets you capture 4K UHD video, Full HD video and high-resolution photos.
<G-vec00169-001-s066><capture.aufnehmen><de> Sie können mit nur einem Mausklick große Panoramabilder in XYZ aufnehmen.
<G-vec00169-001-s066><capture.aufnehmen><en> You can capture large images in XYZ with just a single click.
<G-vec00169-001-s067><capture.aufnehmen><de> Und wenn Sie 24 Bilder eines Pferdes pro Sekunde aufnehmen können, dann haben Sie einen Film.
<G-vec00169-001-s067><capture.aufnehmen><en> And, if you can capture 24 images of a horse per second, then you have a movie.
<G-vec00169-001-s068><capture.aufnehmen><de> Voraussetzungen Meinungen Mit Ashampoo Snap für Android können Sie Screenshots und Bilder mühelos auf Ihrem Android Gerät aufnehmen, bearbeiten und teilen.
<G-vec00169-001-s068><capture.aufnehmen><en> Ashampoo Snap for Android is a fully-fledged mobile application to capture, edit and share screenshots and images on your Android device.
<G-vec00169-001-s069><capture.aufnehmen><de> Blaze Media Pro kann Video von verfügbaren Videogeräten aufnehmen (zum Beispiel, von einem TV-Tuner oder von einer Webkamera), DVD Filme rippen, Video aus Bilder oder Fotos erstellen, Videos dekompilieren, Ton aus Filmen extrahieren.
<G-vec00169-001-s069><capture.aufnehmen><en> Blaze Media Pro can capture video from available video devices (for example, from a TV tuner or a webcam), rip DVD movies, create videos from pictures or photos, decompile videos, extract audio from movies.
<G-vec00476-001-s009><consume.aufnehmen><de> Gebrauchsinformation FÃ1⁄4ttern Sie zwischen 8 und 17 °C, nur so viel, wie die Fische in kurzer Zeit aufnehmen.
<G-vec00476-001-s009><consume.aufnehmen><en> Directions for use Feed between 8 and 17°C water temperature, but only as much as the fish can consume within a short time.
<G-vec00476-001-s010><consume.aufnehmen><de> Fütterungsempfehlung Tetra Pond Colour Sticks: Füttern Sie mindestens 2 bis 3 Mal täglich nur so viel, wie Ihre Fische innerhalb weniger Minuten aufnehmen können.
<G-vec00476-001-s010><consume.aufnehmen><en> Feeding recommendation Tetra Pond Colour Sticks: Feed 2-3 times a day as much as the fish can consume within a few minutes.
<G-vec00476-001-s011><consume.aufnehmen><de> Denn durch das Wasser, das Sie aufnehmen, wird der infektiöse, schmerzende Schleim gelöst, und auch die Schleimhäute können sich wieder regenerieren.
<G-vec00476-001-s011><consume.aufnehmen><en> This is because with the water that you consume, the infectious, painful mucus is released and your mucous membranes can regenerate once again.
<G-vec00476-001-s012><consume.aufnehmen><de> Gebrauchsinformation FÃ1⁄4ttern Sie unter 12 °C, nur so viel, wie die Fische in kurzer Zeit aufnehmen.
<G-vec00476-001-s012><consume.aufnehmen><en> Directions for use Feed below 12°C water temperature, but only as much as the fish can consume within a short time.
<G-vec00476-001-s013><consume.aufnehmen><de> Es kann der Körper auch Ihm-Unzuträgliches aufnehmen, d.h. eine Kost, die noch im Übermaß unausgereiftes Geistiges birgt.... das nun sowohl den Körper als auch die Seele bedrängen kann.... was sich in Form von Krankheiten auswirkt....
<G-vec00476-001-s013><consume.aufnehmen><en> The body can also consume something unhealthy, that is, nourishment which still contains too many immature spiritual substances.... which then might not only bother the body but also the soul.... and manifest itself in the form of diseases....
<G-vec00476-001-s014><consume.aufnehmen><de> Probleme entstehen, wenn Sie große Mengen von Zucker aufnehmen.
<G-vec00476-001-s014><consume.aufnehmen><en> Problems arise when you consume a large amount of sugar.
<G-vec00476-001-s015><consume.aufnehmen><de> Da unsere Rollenbilder ja ganz stark von dem besetzt sind, was wir über die Medien aufnehmen, haben wir hier einen Ansatzpunkt gesehen.
<G-vec00476-001-s015><consume.aufnehmen><en> Since our role models are to a great extent shaped by what we consume in the media, we decided this would be a good approach.
<G-vec00476-001-s016><consume.aufnehmen><de> Die BARTEC-Komponenten, die zusammen 1,7 Megawatt Leistung aufnehmen, finden sich an den unterschiedlichsten Einsatzorten.
<G-vec00476-001-s016><consume.aufnehmen><en> The components from BARTEC, which consume a total of 1.7 megawatts of power, are used in a wide range of areas.
<G-vec00476-001-s017><consume.aufnehmen><de> Fütterungsempfehlung Tetra Malawi Flakes: Füttern Sie mehrmals täglich so viel, wie die Fische innerhalb weniger Minuten aufnehmen können.
<G-vec00476-001-s017><consume.aufnehmen><en> Recommended feeding for Tetra Malawi Flakes:Feed the fish several times a day with only as much food as the fish can consume within a few minutes.
<G-vec00169-001-s132><raise.aufnehmen><de> Sie bekommen Zugang zu langfristigen Kapitalquellen und können nach einem Börsengang wiederholt finanzielle Mittel durch Kapitalerhöhungen aufnehmen.
<G-vec00169-001-s132><raise.aufnehmen><en> They gain access to long-term capital sources and are able, in the wake of an IPO, to raise finance repeatedly through capital increases.
<G-vec00169-001-s133><raise.aufnehmen><de> In der Rechtsform der KGaA kann die KWS künftige Wachstumsmöglichkeiten noch agiler und flexibler nutzen und dafür benötigtes Eigenkapital aufnehmen, ohne dass der Charakter der Gesellschaft als börsennotiertes Familienunternehmen verloren geht.
<G-vec00169-001-s133><raise.aufnehmen><en> As a KGaA, KWS will be able to leverage future growth opportunities with greater agility and flexibility and raise the equity required for that without losing the company’s character as a listed family business. As part of the change in legal form, the newly formed KWS SE will join the company as general partner.
<G-vec00169-001-s134><raise.aufnehmen><de> Änderungen während dem Projektlebenszyklus in ein Verzeichnis aufnehmen, protokollieren, verfolgen und klären, sodass sie erkannt und effizient verwaltet werden.
<G-vec00169-001-s134><raise.aufnehmen><en> Raise, log, track, and resolve changes throughout the project lifecycle and maintain them in a register so they are recognized and managed efficiently.
<G-vec00169-001-s135><raise.aufnehmen><de> Daher kann die Bank auf den internationalen Kapitalmärkten zu sehr günstigen Konditionen Mittel aufnehmen.
<G-vec00169-001-s135><raise.aufnehmen><en> As a result, the Bank can raise funds on the world’s financial markets on very favourable terms.
<G-vec00169-001-s136><raise.aufnehmen><de> """Mit der 7-jährigen Anleihe konnte HeidelbergCement Kapital zu günstigeren Konditionen für eine längere Laufzeit aufnehmen als noch vor einen Jahr."
<G-vec00169-001-s136><raise.aufnehmen><en> """With the 7 year bond, HeidelbergCement could raise capital at more favourable terms for a longer maturity compared to one year ago."
<G-vec00169-001-s137><raise.aufnehmen><de> Vielleicht musst Du einen Kredit für ein Ladengeschäft aufnehmen.
<G-vec00169-001-s137><raise.aufnehmen><en> Maybe you need to raise funds for a physical store location.
<G-vec00169-001-s138><raise.aufnehmen><de> Trotzdem war Tesla wahrscheinlich schon weit genug gekommen, um unter normalen Umständen weiteres Kapital aufnehmen zu können.
<G-vec00169-001-s138><raise.aufnehmen><en> Still, Tesla was likely to have come far enough to raise more capital under normal circumstances.
<G-vec00169-001-s139><raise.aufnehmen><de> Sie betreibt integre, transparente und sichere Märkte für Investoren, die Kapital anlegen, und für Unternehmen, die Kapital aufnehmen wollen.
<G-vec00169-001-s139><raise.aufnehmen><en> It operates markets that provide integrity, transparency and security for investors wishing to invest capital and for issuers wishing to raise capital.
<G-vec00169-001-s140><raise.aufnehmen><de> Die Kommission kün­ digte daher im April 2011 eine Initiative an, durch die sichergestellt werden soll, dass die in einem Mitgliedstaat niedergelassenen Risikokapitalfonds EU-weit Mittel aufnehmen können (3).
<G-vec00169-001-s140><raise.aufnehmen><en> As a result, the Commission announced in April 2011 an initiative to ensure that venture capital funds established in any Member State can raise capital throughout the EU (3). 4.
<G-vec00169-001-s141><raise.aufnehmen><de> ->> Die Company muss kurzfristig Kredite aufnehmen (Reinhard, S.225).
<G-vec00169-001-s141><raise.aufnehmen><en> ->> In this situation the Company has to raise short term credits (Reinhard, vol.I, p.225).
<G-vec00169-001-s142><raise.aufnehmen><de> Durch Investitionen via digitaler Wertpapiere können die jungen Unternehmen fortan genau dann Kapital aufnehmen, wenn sie es benötigen.
<G-vec00169-001-s142><raise.aufnehmen><en> By investing via digital securities, young companies can now raise capital exactly when they need it.
<G-vec00169-001-s143><raise.aufnehmen><de> Der Rating agentur Standard & Poor’s zufolge müssen europäische Mit telständler bis zum Jahr 2018 etwa 3,5 Billionen Euro frisches Kapital aufnehmen.
<G-vec00169-001-s143><raise.aufnehmen><en> Accord ing to the rating agency Standard & Poor’s, European SMEs have to raise fresh capital in the amount of around 3.5 trillion euros by 2018.
<G-vec00169-001-s144><raise.aufnehmen><de> Gewinnorientierte Unternehmen müssen bei Bedarf Geldmittel an den Kapitalmärkten aufnehmen können.
<G-vec00169-001-s144><raise.aufnehmen><en> Profit-oriented corporates may need to raise funds on the capital markets.
<G-vec00169-001-s145><raise.aufnehmen><de> Der Unternehmensgegenstand umfasst die Förderung der Interessen ihrer Mitglieder nach Maßgabe der mit ihren Mitgliedern abgeschlossenen Vereinbarungen, einschließlich Kosteneinsparungen, wobei sie zur Förderung des Gesellschaftszwecks auch Kapital von den Mitgliedern aufnehmen und investieren kann.
<G-vec00169-001-s145><raise.aufnehmen><en> Its corporate purpose includes providing for material needs of its members, including cost savings, pursuant to the agreements concluded with its members, and may, in furtherance of its corporate purpose, raise funds from its members and invest these funds.
<G-vec00169-001-s146><raise.aufnehmen><de> Group Regulatory Strategy Group Regulatory Strategy Als eine der größten Börsenorganisationen der Welt organisieren wir integre, transparente und sichere Märkte für Investoren, die Kapital anlegen, und für Unternehmen, die Kapital aufnehmen.
<G-vec00169-001-s146><raise.aufnehmen><en> Group Regulatory Strategy As one of the largest exchange organisations in the world, we organise markets characterised by integrity, transparency and safety for investors that invest capital, and for companies to raise capital.
<G-vec00169-001-s147><raise.aufnehmen><de> Wenn es für die Wirtschaft des Landes notwendig wird, kann die BSP Kredite vergeben, Vorschüsse auszahlen, Kapital aufnehmen, Rabatte anbieten und als Depotbank für andere Finanzinstitute fungieren.
<G-vec00169-001-s147><raise.aufnehmen><en> Should it become necessary for the economy of the country it is possible for the BSP to extend loans, issue advances, raise capital, offer discounts, and act as a depository for other financial institutions.
<G-vec00169-001-s038><receive.aufnehmen><de> Sogar junge und gesunde Raucher sollten mehr Vitamin C und E aufnehmen als andere.
<G-vec00169-001-s038><receive.aufnehmen><en> Even young, healthy smokers should receive more vitamin E than others.
<G-vec00169-001-s039><receive.aufnehmen><de> Dann wird sie selbst auch liebefähig und liebewillig sein, und dann wird sie glauben können fest und ungezweifelt und in diesem Glauben sich Mir nähern; sie wird Mich ersehnen und auch Erfüllung finden, sie wird freiwillig zu Mir kommen, und Ich werde sie aufnehmen, weil sie Mich nun liebt und an Mich glaubt.
<G-vec00169-001-s039><receive.aufnehmen><en> Then it itself will also be able and willing to love, and then it will be able to believe firmly and undoubtedly and approach me in this faith; it will long for me and also find fulfilment; it will come to me voluntarily, and I will receive it, because it now loves me and believes in me.
<G-vec00169-001-s040><receive.aufnehmen><de> Und so viele euch etwa nicht aufnehmen werden, gehet fort aus jener Stadt und schüttelt auch den Staub von euren Füßen, zum Zeugnis wider sie.
<G-vec00169-001-s040><receive.aufnehmen><en> And whosoever will not receive you, when ye go out of that city, shake off the very dust from your feet for a testimony against them.
<G-vec00169-001-s041><receive.aufnehmen><de> Wir sind wie ein vollgeschriebenes Blatt, wir können keine Eindrücke von innen aufnehmen.
<G-vec00169-001-s041><receive.aufnehmen><en> We are like a sheet filled with writing, we cannot receive impressions from within.
<G-vec00169-001-s042><receive.aufnehmen><de> 5 und wer irgend ein solches Kindlein aufnehmen wird in meinem Namen, nimmt mich auf.
<G-vec00169-001-s042><receive.aufnehmen><en> 5 and whosoever shall receive one such little child in my name, receives me.
<G-vec00169-001-s043><receive.aufnehmen><de> Die Erziehung eines Menschen zum Gotteskind wird immer ein Leidensweg sein, der Mir zugewandten Willens gegangen werden muss bis zum Ende, auf daß Ich es dann aufnehmen kann in Mein Reich, auf daß Ich es ziehen kann an Mein Herz, um ihm seine Treue zu entlohnen.
<G-vec00169-001-s043><receive.aufnehmen><en> The upbringing of a man to the child of God will always be a way of suffering, which must be walked with a will turned towards me until the end, so that I can then receive it into my kingdom, so that I can draw it to my heart, to reward it its loyalty.
<G-vec00169-001-s044><receive.aufnehmen><de> Dies ist eine Offenbarung für die ganze Menschheit – eine Offenbarung, die, wenn sie verbreitet wird, offene Herzen finden wird, die sie mit großer Freude aufnehmen; ebenso wird sie auch auf hartnäckige Gegner und Bekämpfer stoßen.
<G-vec00169-001-s044><receive.aufnehmen><en> This is a revelation for all humanity, a revelation that when it is spread, shall find open hearts that receive it with great joy, just as it must also find human opponents and persecutors.
<G-vec00169-001-s045><receive.aufnehmen><de> 49:15 Gott aber wird meine Seele erlösen von der Gewalt des Scheols; denn er wird mich aufnehmen.
<G-vec00169-001-s045><receive.aufnehmen><en> far from their mansion. 49:15 But God will redeem my soul from the power of Sheol, for he will receive me.
<G-vec00169-001-s046><receive.aufnehmen><de> Doch wie wenige begehren Mich und bereiten Mir die Wohnung, wie wenige gestalten ihre Herzen so, daß sie Mich darin aufnehmen können.
<G-vec00169-001-s046><receive.aufnehmen><en> Yet how few desire Me and prepare an abode for Me, how few shape their hearts such that they can receive Me therein.
<G-vec00169-001-s047><receive.aufnehmen><de> Vielleicht denken wir, dass es hier und da bestimmt Klöster geben muss, die die Mönche aufnehmen.
<G-vec00169-001-s047><receive.aufnehmen><en> People have ideas about monasteries that might receive them here and there.
<G-vec00169-001-s048><receive.aufnehmen><de> Frankreich ist ein reiches Land, das mehr Fremde aufnehmen könnte.
<G-vec00169-001-s048><receive.aufnehmen><en> France is a rich country which could receive more foreigners.
<G-vec00169-001-s049><receive.aufnehmen><de> Der Unerfahrene kann leicht unterschätzen, wie viel schwerstkranke, scheinbar nicht mehr zur Kommunikation fähige Patienten wenn nicht verstehen, so doch noch aufnehmen und registrieren können.
<G-vec00169-001-s049><receive.aufnehmen><en> An inexperienced person can easily underestimate how much the seriously ill patient, who apparently is not able to communicate, can in fact receive and register.
<G-vec00169-001-s050><receive.aufnehmen><de> Mein Wort ist erkennbar, denn es predigt die Liebe - und also ist es geboten von der Liebe Selbst, von Mir, Der Ich im Wort zu den Menschen komme, um ihnen in ihrer großen geistigen Not zu helfen, Der Ich in ihre Herzen Einlaß begehre, um in den Herzen Selbst wirken zu können zum Segen aller, die Mich aufnehmen und Mir Wohnung bereiten.
<G-vec00169-001-s050><receive.aufnehmen><en> My word is recognizable because it preaches love – and therefore it is offered by love itself, by me, who comes in the word to men to help them in their great spiritual want, who desires admittance into their hearts to be able to have an effect in the hearts myself for the benefit of all who receive me and prepare a home for me.
<G-vec00169-001-s051><receive.aufnehmen><de> Oftmals sind die Kinderheime Wohnhäuser, die nur 10 bis 20 Kinder zwischen 1 und 9 Jahren aufnehmen können.
<G-vec00169-001-s051><receive.aufnehmen><en> The orphanages are often small homes that receive only between 10 and 20 children between 1 and 9 years.
<G-vec00169-001-s052><receive.aufnehmen><de> Wenn unser Denken rein, ruhig und empfänglich geworden ist, kann es das Licht aus höheren Kreisen aufnehmen.
<G-vec00169-001-s052><receive.aufnehmen><en> If our mind has become pure, calm and receptive, it can receive the Light from higher circles.
<G-vec00169-001-s053><receive.aufnehmen><de> Wie der Weg, auf dem erst Hunderte von Menschen gehen mussten, um ihn so hart zu machen wie er ist, musste auch dieser Erste Hunderte von Malen sein Herz verschließen und verhärten, um so hart zu werden, dass er schließlich auch das Wort Gottes nicht mehr aufnehmen konnte.
<G-vec00169-001-s053><receive.aufnehmen><en> Like the road, on which hundreds of people have had to travel to make it as hard as it is, so too this person must have closed and hardened his heart hundreds of times in the past to become so hard that he finally can no longer receive the word of God.
<G-vec00169-001-s054><receive.aufnehmen><de> Das Hintergrunddiagramm, das keine Daten aufnehmen kann, bleibt immer im Hintergrund.
<G-vec00169-001-s054><receive.aufnehmen><en> The background layer which cannot receive data, remains the background layer.
<G-vec00169-001-s055><receive.aufnehmen><de> Dieses sieht vor, dass die Türkei Migranten, die illegal über die türkische Grenze in die EU einreisen, wieder aufnehmen muss.
<G-vec00169-001-s055><receive.aufnehmen><en> It stipulates that Turkey has to receive migrants who have entered the EU illegally via the Turkish border.
<G-vec00169-001-s056><receive.aufnehmen><de> Von Herzen hoffe ich, daß jede kirchliche Gemeinschaft, der Migranten und Flüchtlinge sowie jene Menschen angehören, die sie aufnehmen, sich, von den Quellen der Gnade beseelt, unermüdlich für den Aufbau des Friedens einsetzen möge.
<G-vec00169-001-s056><receive.aufnehmen><en> I deeply hope that every Ecclesial Community, made up of migrants and refugees and those who receive them and drawing inspiration from the sources of grace, will untiringly engage in the construction of peace.
<G-vec00476-001-s018><soak_up.aufnehmen><de> Die sollte groß genug sein, um mit dem Hähnchen gleichzeitig die Kartoffeln und Schalotten aufnehmen, die den Geschmack des Fonds annehmen.
<G-vec00476-001-s018><soak_up.aufnehmen><en> The vessel should be large enough to accommodate not only the chicken but also the potatoes and shallots that will soak up the flavor of the meat juices.
<G-vec00476-001-s019><soak_up.aufnehmen><de> Chrom unterstützt Ihre Zellen so viel Zucker wie möglich aufnehmen, um sicherzustellen, dass Sie auf jeden Fall weniger Zucker Nahrungcravings erleben.
<G-vec00476-001-s019><soak_up.aufnehmen><en> Chromium supports your cells soak up as much sugar as possible, so that you will experience much less sugar desires.
<G-vec00476-001-s020><soak_up.aufnehmen><de> Falls Sie schon immer mehr Abenteuer im Auge hatten, dann könnten Sie an einer afrikanischen Safari teilnehmen und die faszinierenden Landschaften eines wunderschönen Kontinents in sich aufnehmen.
<G-vec00476-001-s020><soak_up.aufnehmen><en> If you have always had your eye on more adventure, you could take part in an African safari and soak up the lush landscapes of a beautiful continent.
<G-vec00092-001-s057><take.aufnehmen><de> Wir wollen heute das Evangelium Jesu wieder aufnehmen und auf neuer Ebene fortsetzen.
<G-vec00092-001-s057><take.aufnehmen><en> Today we wish to take up the Gospel of Jesus again, and to continue with it on a new level.
<G-vec00092-001-s058><take.aufnehmen><de> 10:8 Und wo ihr in eine Stadt kommt, und sie euch aufnehmen, da esset, was euch wird vorgetragen, 10:9 und heilet die Kranken, die daselbst sind, und saget ihnen: Das Reich Gottes ist nahe zu euch kommen.
<G-vec00092-001-s058><take.aufnehmen><en> 10:8 And into whatever town you go, if they take you in, take whatever food is given to you: 10:9 And make well those in it who are ill and say to them, The kingdom of God is near to you.
<G-vec00092-001-s059><take.aufnehmen><de> Versand Größe Grundversandkosten werden auf die in der Regel auf Basis Volumen (in Kubikfuß oder Meter), die Ihre verpackten Waren in einem Versandbehälter aufnehmen wird.
<G-vec00092-001-s059><take.aufnehmen><en> Basic shipping costs are usually based on the volume (in cubic feet or meters) that your packed goods will take up in a shipping container.
<G-vec00092-001-s060><take.aufnehmen><de> Diese können nur unmittelbar nach dem Geben angewandt werden, bevor Sie weitere Karten aufnehmen.
<G-vec00092-001-s060><take.aufnehmen><en> These side rules can only be used immediately after the deal, before you take any more cards.
<G-vec00092-001-s061><take.aufnehmen><de> Des Weiteren wird in Laborexperimenten gezeigt, wie Algen und andere Organismen den Stickstoff aufnehmen und weiterverarbeiten.
<G-vec00092-001-s061><take.aufnehmen><en> Furthermore, lab experiments will show how algae and other organisms take in and process nitrogen.
<G-vec00092-001-s062><take.aufnehmen><de> Danach soll die Agentur ihre Tätigkeit umgehend aufnehmen.
<G-vec00092-001-s062><take.aufnehmen><en> Following this, the agency will take up its work immediately.
<G-vec00092-001-s063><take.aufnehmen><de> Auf diese Weise können die Gründer ihr Unternehmen nachhaltig entwickeln – ohne zunächst große Summen an Risikokapital aufnehmen zu müssen.
<G-vec00092-001-s063><take.aufnehmen><en> In this way the founders can develop their company in a sustainable fashion – without first having to take on large sums of risk capital.
<G-vec00092-001-s064><take.aufnehmen><de> Also heißes Wasser, Seifen-Napf und und wieder Seife aufnehmen und das Gesicht mit sahnigem Schaum verwöhnen.
<G-vec00092-001-s064><take.aufnehmen><en> Thus take up hot water, soap cup and and again soap and the face with creamy foam spoil.
<G-vec00092-001-s065><take.aufnehmen><de> Die armen, verachteten, unwissenden Arbeiter werden die Träger dieser Umwälzung sein, indem sie den Kampf gegen die Bourgeoisie aufnehmen, dadurch Kraft und Fähigkeit erwerben und sich als Klasse organisieren; durch eine Revolution wird das Proletariat die politische Herrschaft erobern und die wirtschaftliche Umwälzung durchführen.
<G-vec00092-001-s065><take.aufnehmen><en> This force is the class struggle of the proletariat. The poor, scorned, ignorant workers will be in the forefront of those who will carry out this transformation, as they take up the struggle against the bourgeoisie, gaining in the process power and ability and organizing themselves as a class; by way of a revolution, the proletariat will conquer political power and carry out a comprehensive economic transformation.
<G-vec00092-001-s066><take.aufnehmen><de> Sie können sich vorstellen, was für ein widerliches Ding wir dann waschen, wenn Flöhe nicht alles aufnehmen.
<G-vec00092-001-s066><take.aufnehmen><en> You can imagine what a disgusting thing we wash then, if fleas do not take everything.
<G-vec00092-001-s067><take.aufnehmen><de> Die Fenster können über Grafik|Eigenschaften so konfiguriert werden, dass sie von vorneherein nur Elemente eines bestimmten Typs aufnehmen.
<G-vec00092-001-s067><take.aufnehmen><en> The windows can be configured in graphic|properties so that they only take elements of one special kind right from the beginning.
<G-vec00092-001-s068><take.aufnehmen><de> Atme so lange ein, bis du keine Luft mehr bequem aufnehmen kannst.
<G-vec00092-001-s068><take.aufnehmen><en> inhale until you cannot take in any more air comfortably.
<G-vec00092-001-s069><take.aufnehmen><de> Sämtliche Zaunöffnungen befinden sich im Bereich der nicht-öffentlichen Zone des Flughafens, in welcher flugzeugbegeisterte Fotografen entsprechende Öffnungen für ihre Objektive vorfinden, sodass sich im Handumdrehen interessante Bilder aufnehmen lassen.
<G-vec00092-001-s069><take.aufnehmen><en> In several places directly in the fence around the non-public zone of the airport, aviation fans can find openings for their camera lenses, so they can take interesting pictures easily.
<G-vec00092-001-s070><take.aufnehmen><de> Will man sich eine anständige Wohnung oder ein Haus anschaffen, so muss man dafür jahrlang arbeiten und sparen (d.h., auf sämtlichen Genuß verzichten) oder man muss Kredit aufnehmen (aber Kredit bekommt nur derjenige, der schon über ein bestimmtes Vermögen verfügt und dies vorweisen kann).
<G-vec00092-001-s070><take.aufnehmen><en> If you want to have a decent apartment or a house, you must work many years and save money (this means: renounce all enjoyments) or take a loan (but only who already possesses a certain property and can present it gets a credit).
<G-vec00092-001-s071><take.aufnehmen><de> Ab Ende November 2016 werden die ersten neuen Wagen den Fahrgastbetrieb auf der 13,3 Kilometer langen Strecke aufnehmen, bis Ende 2017 sollen dann alle 31 Fahrzeuge über die Stadt schweben und die alten Züge ersetzen.
<G-vec00092-001-s071><take.aufnehmen><en> From the end of November 2016, the first new cars will be ready to take passengers on the 13.3 km journey and by the end of 2017, all 31 vehicles will float above the city and replace the old trains.
<G-vec00092-001-s072><take.aufnehmen><de> rufen und alle abgelegten Karten vom -K an aufnehmen.
<G-vec00092-001-s072><take.aufnehmen><en> and take all the discards from K onward.
<G-vec00092-001-s073><take.aufnehmen><de> Die Anzeichen entstehen normalerweise innerhalb von Minuten von der Belastung durch die Nahrung, aber können zu zwei Stunden manchmal aufnehmen, um sich zu entwickeln.
<G-vec00092-001-s073><take.aufnehmen><en> The symptoms usually arise within minutes of exposure to the food, but can sometimes take up to two hours to develop.
<G-vec00092-001-s074><take.aufnehmen><de> Sie nicht mit der Kamera zur Zeit keine Bilder aufnehmen löschen Sie die Fotos versehentlich.
<G-vec00092-001-s074><take.aufnehmen><en> Do not take any pictures using the camera at the moment you delete the photos accidentally.
<G-vec00092-001-s075><take.aufnehmen><de> Dennoch besteht eine der ungewöhnlichsten Manifestationen, von denen Jesus je gesprochen hat, im Aufnehmen des Handtuchs.
<G-vec00092-001-s075><take.aufnehmen><en> Yet one of the most unusual of all the manifestations Christ talked about is His call to take up the towel.
<G-vec00476-001-s027><take_in.aufnehmen><de> Wir wollen heute das Evangelium Jesu wieder aufnehmen und auf neuer Ebene fortsetzen.
<G-vec00476-001-s027><take_in.aufnehmen><en> Today we wish to take up the Gospel of Jesus again, and to continue with it on a new level.
<G-vec00476-001-s028><take_in.aufnehmen><de> 10:8 Und wo ihr in eine Stadt kommt, und sie euch aufnehmen, da esset, was euch wird vorgetragen, 10:9 und heilet die Kranken, die daselbst sind, und saget ihnen: Das Reich Gottes ist nahe zu euch kommen.
<G-vec00476-001-s028><take_in.aufnehmen><en> 10:8 And into whatever town you go, if they take you in, take whatever food is given to you: 10:9 And make well those in it who are ill and say to them, The kingdom of God is near to you.
<G-vec00476-001-s029><take_in.aufnehmen><de> Versand Größe Grundversandkosten werden auf die in der Regel auf Basis Volumen (in Kubikfuß oder Meter), die Ihre verpackten Waren in einem Versandbehälter aufnehmen wird.
<G-vec00476-001-s029><take_in.aufnehmen><en> Basic shipping costs are usually based on the volume (in cubic feet or meters) that your packed goods will take up in a shipping container.
<G-vec00476-001-s030><take_in.aufnehmen><de> Diese können nur unmittelbar nach dem Geben angewandt werden, bevor Sie weitere Karten aufnehmen.
<G-vec00476-001-s030><take_in.aufnehmen><en> These side rules can only be used immediately after the deal, before you take any more cards.
<G-vec00476-001-s031><take_in.aufnehmen><de> Des Weiteren wird in Laborexperimenten gezeigt, wie Algen und andere Organismen den Stickstoff aufnehmen und weiterverarbeiten.
<G-vec00476-001-s031><take_in.aufnehmen><en> Furthermore, lab experiments will show how algae and other organisms take in and process nitrogen.
<G-vec00476-001-s032><take_in.aufnehmen><de> Danach soll die Agentur ihre Tätigkeit umgehend aufnehmen.
<G-vec00476-001-s032><take_in.aufnehmen><en> Following this, the agency will take up its work immediately.
<G-vec00476-001-s033><take_in.aufnehmen><de> Auf diese Weise können die Gründer ihr Unternehmen nachhaltig entwickeln – ohne zunächst große Summen an Risikokapital aufnehmen zu müssen.
<G-vec00476-001-s033><take_in.aufnehmen><en> In this way the founders can develop their company in a sustainable fashion – without first having to take on large sums of risk capital.
<G-vec00476-001-s034><take_in.aufnehmen><de> Also heißes Wasser, Seifen-Napf und und wieder Seife aufnehmen und das Gesicht mit sahnigem Schaum verwöhnen.
<G-vec00476-001-s034><take_in.aufnehmen><en> Thus take up hot water, soap cup and and again soap and the face with creamy foam spoil.
<G-vec00476-001-s035><take_in.aufnehmen><de> Die armen, verachteten, unwissenden Arbeiter werden die Träger dieser Umwälzung sein, indem sie den Kampf gegen die Bourgeoisie aufnehmen, dadurch Kraft und Fähigkeit erwerben und sich als Klasse organisieren; durch eine Revolution wird das Proletariat die politische Herrschaft erobern und die wirtschaftliche Umwälzung durchführen.
<G-vec00476-001-s035><take_in.aufnehmen><en> This force is the class struggle of the proletariat. The poor, scorned, ignorant workers will be in the forefront of those who will carry out this transformation, as they take up the struggle against the bourgeoisie, gaining in the process power and ability and organizing themselves as a class; by way of a revolution, the proletariat will conquer political power and carry out a comprehensive economic transformation.
<G-vec00476-001-s106><absorb.aufnehmen><de> Die Stromaufnahme ist der maximale Wert des Leerlaufstromes Io, den der Sensor ohne Last aufnimmt.
<G-vec00476-001-s106><absorb.aufnehmen><en> The current consumption is the maximum value of the noload current Io that the sensor can absorb without a load.
<G-vec00476-001-s107><absorb.aufnehmen><de> Mit jedem Atemzug absorbiert man ständig die ganze Dunkelheit, die ganze Lüge, all die Unordnung und Disharmonie der Welt (ohne all das andere zu berücksichtigen, was man mit der Nahrung aufnimmt, und all das – das Schlimmste von allem –, was man mental im Kontakt mit anderen absorbiert, mental und vital), all das muss man ständig ändern und transformieren.
<G-vec00476-001-s107><absorb.aufnehmen><en> Of course, it's all the Darkness, all the Falsehood, all the Disorder, all the Disharmony of the world that you constantly absorb every time you breathe (not to speak of all that you absorb with food, and all the rest – the worst of all – that you absorb mentally through contact with others, mentally and vitally).
<G-vec00476-001-s108><absorb.aufnehmen><de> So auch haben diese verhüllten Belehrungen den Zweck, den Menschen zum Denken anzuregen, auf daß er eindringet in geistiges Wissen und es nicht nur oberflächlich mit seinen leiblichen Ohren aufnimmt.
<G-vec00476-001-s108><absorb.aufnehmen><en> So also these veiled instructions have the purpose, to stimulate man to thinking, so that he penetrates into spiritual knowledge and does not just superficially absorb it with is bodily ears.
<G-vec00476-001-s109><absorb.aufnehmen><de> Die äußere Schicht besteht aus einem glatten Material, das keinen Schmutz aufnimmt, atmungsaktiv.
<G-vec00476-001-s109><absorb.aufnehmen><en> Its outer layer is made of a smooth material that does not absorb dirt and is breathable.
<G-vec00476-001-s110><absorb.aufnehmen><de> Flasche Plagron Alga Wuchs 500ml Plagron Alga-Wuchs ist eine organische flüssige N-P-K Nahrung, die die Pflanze direkt aufnimmt.
<G-vec00476-001-s110><absorb.aufnehmen><en> Plagron Alga-Grow, 500ml Plagron Alga-Grow is an organic, liquid N-P-P nutrient, which the plant can directly absorb.
<G-vec00476-001-s111><absorb.aufnehmen><de> Stromaufnahme Die Stromaufnahme ist der maximale Wert des Leerlaufstromes Io, den der Sensor ohne Last aufnimmt.
<G-vec00476-001-s111><absorb.aufnehmen><en> Current consumption The current consumption is the maximum value of the noload current Io that the sensor can absorb without a load.
<G-vec00476-001-s112><absorb.aufnehmen><de> Leinen braucht sehr viel Wasser beim Waschen, die Faser muss quellen können, da sie das Vielfache des eigenen Gewichtes an Flüssigkeit aufnimmt.
<G-vec00476-001-s112><absorb.aufnehmen><en> Linen needs a lot of water while washing because the fibre has to have the possibility to swell up and linen can absorb many times the amount of water of its own weight.
<G-vec00476-001-s113><absorb.aufnehmen><de> Der Verzicht auf Wasser bedeutet, dass die Luft in der Lackierkabine keine zusätzliche Feuchtigkeit aufnimmt und daher wiederverwendet werden kann.
<G-vec00476-001-s113><absorb.aufnehmen><en> Dispensing with the use of water means that the air in the painting booth does not absorb additional moisture and can therefore be re-used.
<G-vec00476-001-s114><absorb.aufnehmen><de> Im Deckel wird ein Weichschaumstoff verwendet, der kleinere Partikel aufnimmt und Kratzer auf der Glasfläche verhindern hilft.
<G-vec00476-001-s114><absorb.aufnehmen><en> In the lid, a soft foam is used, which will absorb smaller particles and prevent scratches on the glass surface.
<G-vec00476-001-s132><absorb.aufnehmen><de> Der Motor ist an ein Dynamometer gekoppelt, das dazu dient, die vom Motor erzeugte Energie aufzunehmen oder den Motor alternativ anzutreiben.
<G-vec00476-001-s132><absorb.aufnehmen><en> The engine is coupled to a dynamometer which is used to absorb the energy generated by the engine or alternatively physically motor the engine.
<G-vec00476-001-s133><absorb.aufnehmen><de> Je mehr Ihr Euer Chakrasystem balanciert, harmonisiert und stärkt, desto mehr werdet Ihr fähig sein, Göttliches Licht aufzunehmen.
<G-vec00476-001-s133><absorb.aufnehmen><en> The more you balance, harmonize and strengthen your chakra system, the more Divine Light you will be able to absorb.
<G-vec00476-001-s134><absorb.aufnehmen><de> Das unverstärkte Material ist modifiziert, um bei einem Unfall einen erheblichen Teil der Aufprallenergie aufzunehmen und der plastischen Verformung entgegenzuwirken.
<G-vec00476-001-s134><absorb.aufnehmen><en> The unfilled resin is modified to absorb significant energy and withstand plastic deformation in the event of a crash.
<G-vec00476-001-s135><absorb.aufnehmen><de> Hauptinhaltsstoffe sind: Aktivierte Kohle: Bekannt für seine Fähigkeit bis zu 200 Mal sein eigenes Gewicht in Giftstoffen aufzunehmen.
<G-vec00476-001-s135><absorb.aufnehmen><en> Activated Charcoal: Famous for its ability to absorb up to 200 times its weight in toxins, activated charcoal helps thoroughly remove impurities from the skin’s surface.
<G-vec00476-001-s136><absorb.aufnehmen><de> Fauna Mana hilft dem Körper besser Nährstoffe aufzunehmen, freie Radikale zu neutralisieren und Schwermetalle aus dem Körper abzuführen.
<G-vec00476-001-s136><absorb.aufnehmen><en> Fauna Mana helps the body to absorb good nutrients, neutralize free radicals and dispose heavy metals and toxins from the body.
<G-vec00476-001-s137><absorb.aufnehmen><de> Ausgezeichnet für reichen und schmackhaften risotti für sein Gut vom Kochen und die Fähigkeit und die Gewürze aufzunehmen.
<G-vec00476-001-s137><absorb.aufnehmen><en> Excellent for rich and tasty risotti for its estate of c ooking and the ability to absorb the seasonings.
<G-vec00476-001-s138><absorb.aufnehmen><de> Wir müssen den entleerenden Effekt der Erde fühlen, die so freundlich ist, unseren Schmutz aufzunehmen.
<G-vec00476-001-s138><absorb.aufnehmen><en> We need to feel the draining effect of the earth which is so kind as to absorb our pollution.
<G-vec00476-001-s139><absorb.aufnehmen><de> In den Modulen werden Themen wie allgemeine Computerterminologie, Apple spezifische Architekturen sowie Fehlerbeseitigung und vorbeugende Wartungsmaßnahmen in einem logisch strukturierten, leicht verständlichen Format erarbeitet, sodass es ganz einfach ist, neue Konzepte und Informationen aufzunehmen.
<G-vec00476-001-s139><absorb.aufnehmen><en> The modules cover such topics as general terminology, Apple-specific computer architectures, and troubleshooting and preventive maintenance in a logical, straightforward format that makes it easy to absorb new concepts and information.
<G-vec00476-001-s140><absorb.aufnehmen><de> Pyridoxin hilft Ihrem Körper, Proteine und Kohlenhydrate aufzunehmen, spendet Energie und bietet Gesundheit für die Haut.
<G-vec00476-001-s140><absorb.aufnehmen><en> Pyridoxine helps the body to absorb proteins and carbohydrates, boosting energy and preventing skin conditions.
<G-vec00078-001-s285><accept.aufnehmen><de> Es ist euch wahrlich eine umfassende Zeitspanne zugebilligt worden, um diese Willens- und Wesenswandlung zu erreichen, doch einmal nimmt auch die längste Zeit ihr Ende, und vor diesem Ende stehet ihr.... Ich kann euch nicht willkürlich so gestalten, daß ihr zum ewigen Leben eingehen könnet, ihr müsset selbst Hand anlegen an euch, ihr müsset wollen, denn Mein Wille ist jederzeit, euch aufzunehmen in Mein Reich, Mein Wille wird niemals sich eurem Willen entgegenstellen, wenn dieser zu Mir verlangt, wie er sich einstmals abwandte von Mir und euch in die Tiefe riß....
<G-vec00078-001-s285><accept.aufnehmen><en> You were truly granted an extensive period of time in order to achieve this change of will and nature, yet one day even the longest space of time comes to an end, and you are facing this end.... I cannot arbitrarily shape you such that you can enter eternal life, you must lend a hand yourselves, for it is always My will to accept you into My kingdom, My will would never reject your will if it desires to reach Me, just as it once turned away from Me and pulled you into the abyss.... Worlds will vanish before the last spiritual being has accomplished this transformation of will.... Nevertheless, My love wants to help you humans so that you will not remain distant from Me for eternities to come, so that you will not remain for eternities in a material form, which either keeps your will bound or, as a human being, gives you the final opportunity to reach your goal of uniting yourselves with Me again....
<G-vec00078-001-s286><accept.aufnehmen><de> Heute appelliere ich an alle Energie- und Umweltminister der Mitglieds- und Nachbarstaaten, mit Augenmerk, aber auch Weitsicht dieses Momentum zu nutzen und anspruchsvolle Vereinbarungen auch in der europäischen Nachbarschaftspolitik aufzunehmen und zu unterstützen.
<G-vec00078-001-s286><accept.aufnehmen><en> Today I call on all energy and environment ministers of the member states and neighbouring countries, to demonstrate their focus and foresight in using this momentum to accept and support ambitious agreements also in Europe's neighbourhood policy.
<G-vec00078-001-s287><accept.aufnehmen><de> Die Jungfrau Maria, Vorbild an Gefügigkeit und Gehorsam gegenüber dem Wort Gottes, lehre euch, den unerschöpflichen Reichtum der Heiligen Schrift immer besser aufzunehmen, nicht nur durch die intellektuelle Forschung, sondern auch in eurem Leben als Gläubige, damit eure Arbeit und euer Wirken dazu beitragen können, vor den Gläubigen immer mehr das Licht der Heiligen Schrift erstrahlen zu lassen.
<G-vec00078-001-s287><accept.aufnehmen><en> May the Virgin Mary, model of docility and obedience to the Word of God, teach you to accept ever better the inexhaustible riches of Sacred Scripture, not only through intellectual research but also in your lives as believers, so that your work and your action may contribute to making the light of Sacred Scripture shine ever brighter before the faithful.
<G-vec00078-001-s288><accept.aufnehmen><de> Der Application Manager hat die Macht, sich bewerbende Spieler abzulehnen oder in die Allianz aufzunehmen, durch die Diplomacy → Apps Seite.
<G-vec00078-001-s288><accept.aufnehmen><en> The application manager has the power to decline applying players or to accept them into the alliance through the Diplomacy → Apps page.
<G-vec00078-001-s289><accept.aufnehmen><de> Die Gründung der mit einem Internat ausgestatteten Akademie schafft die Möglichkeit, Schüler aus aller Welt aufzunehmen.
<G-vec00078-001-s289><accept.aufnehmen><en> The establishment of the academy, equipped with a boarding school, provides the opportunity to accept students from around the world.
<G-vec00078-001-s290><accept.aufnehmen><de> Sie wurden zu einer Haftanstalt gebracht, aber die Beamten der Haftanstalt weigerten sich, Frau Chen in ihrem schlechten Gesundheitszustand aufzunehmen.
<G-vec00078-001-s290><accept.aufnehmen><en> They drove to a detention centre, but the detention centre refused to accept Ms. Chen because of her health.
<G-vec00078-001-s291><accept.aufnehmen><de> Das Gefängnis weigerte sich jedoch, ihn in einer so schlechten körperlichen Verfassung aufzunehmen.
<G-vec00078-001-s291><accept.aufnehmen><en> The prison refused to accept him in such poor physical condition.
<G-vec00078-001-s292><accept.aufnehmen><de> B. Einschränkung verhaltensbezogener Werbung, Links zu sozialen Netzwerken, um beim Spielen Kontakt zu anderen Spielern aufzunehmen; die Option, Push-Benachrichtigungen zu erhalten, die über aufregende Neuigkeiten informieren, z.
<G-vec00078-001-s292><accept.aufnehmen><en> restrict behavioral ads; social networks links to connect with others while playing; option to accept push notifications to inform of exciting news e.g.
<G-vec00078-001-s293><accept.aufnehmen><de> Die Reintex beabsichtigt nicht, von Personen unter 14 Jahren Daten aufzunehmen, zu erfassen.
<G-vec00078-001-s293><accept.aufnehmen><en> Reintex does not accept and record personal data from persons below the age of 14.
<G-vec00078-001-s294><accept.aufnehmen><de> Sie hat Jesus durch das Wirken des Heiligen Geistes empfangen, und jeder Christ, jeder von uns, ist dazu berufen, das Wort Gottes aufzunehmen, Jesus in sich aufzunehmen und ihn dann zu allen zu bringen.
<G-vec00078-001-s294><accept.aufnehmen><en> She conceived Jesus by the work of the Holy Spirit, and every Christian, each one of us, is called to accept the Word of God, to accept Jesus inside of us and then to bring him to everyone.
<G-vec00078-001-s295><accept.aufnehmen><de> Die Jungfrau Maria ist Lehrerin auch dieses Gebets, da es keiner mehr und besser verstanden hat als sie, Jesus mit dem Blick des Glaubens zu betrachten und im Herzen das innerste Mitschwingen seiner menschlichen und göttlichen Gegenwart aufzunehmen.
<G-vec00078-001-s295><accept.aufnehmen><en> Moreover the Virgin Mary is also the teacher of this prayer because no one has been able better than Mary to contemplate Jesus with a gaze of faith and to accept in his or her heart the deep resonance of his human and divine presence.
<G-vec00078-001-s296><accept.aufnehmen><de> Dies ist ein Demonstrationsturnier in einem Format, welches das Ziel hat, Billard in das Programm der Olympischen Spiele 2024 in Paris aufzunehmen.
<G-vec00078-001-s296><accept.aufnehmen><en> This presentation is a demonstration tournament, formulated to support a new format for the IOC to accept Billiards as an additional Sport for inclusion into the programme of the 2024 Olympic Games in Paris.
<G-vec00078-001-s297><accept.aufnehmen><de> Zu diesem abscheulichen Verbrechen kam die Ablehnung der imperialistischen Alliierten, jüdische Flüchtlinge aufzunehmen.
<G-vec00078-001-s297><accept.aufnehmen><en> On top of this heinous crime came the refusal of the imperialist Allies to accept Jewish refugees.
<G-vec00078-001-s298><accept.aufnehmen><de> Wer diese Wahrheit akzeptiert und sich vorbereitet, um die Weisheit aufzunehmen, der empfängt sie als Geschenk.
<G-vec00078-001-s298><accept.aufnehmen><en> Those who accept this truth and are prepared to accept Wisdom, receive it as a gift.
<G-vec00078-001-s299><accept.aufnehmen><de> "Angesichts der globalen Tragweite des Flüchtlingsproblems, so der Bischof abschließend, ""sind Industriestaaten berufen Flüchtlinge aufzunehmen, ohne Maßnahmen zu ergreifen, die ihnen Schaden und Leid zufügen""."
<G-vec00078-001-s299><accept.aufnehmen><en> "According to the Australian Church, since that of refugees is a global phenomenon on the rise, ""the developed countries are called to accept the care for refugees, without measures that inflict harm and suffering""."
<G-vec00078-001-s300><accept.aufnehmen><de> Auch Frankreich ist sehr unwillig gewesen, die nordafrikanischen Massen-Flüchtlingsströme aufzunehmen - belehrt von den vielen Krawallen, die sie veranstalten.
<G-vec00078-001-s300><accept.aufnehmen><en> France also has been very reluctant to accept North African mass refugee flows - taught by the many riots they organize.
<G-vec00078-001-s301><accept.aufnehmen><de> Danach ist das Implantat in der Lage, die funktionelle Belastung einer prothetischen Versorgung als Stütz- und/oder Verankerungselement dauerhaft aufzunehmen.
<G-vec00078-001-s301><accept.aufnehmen><en> After that, the implant is able to accept permanently the functional load of a prosthetic restoration as a support and/or fixation element.
<G-vec00078-001-s302><accept.aufnehmen><de> Ein Ablehnungsrecht in diesen Ausnahmefällen hätte zur Folge, dass solchen Personen der Zugang zur privaten Krankenversicherung voraussichtlich gänzlich verschlossen wäre, weil sich kein Unternehmen bereiterklären würde sie aufzunehmen.
<G-vec00078-001-s302><accept.aufnehmen><en> If they were given a right to refuse in these exceptional cases, the result would be that such persons would probably have no access at all to private health insurance, because no undertaking would be prepared to accept them.
<G-vec00078-001-s303><accept.aufnehmen><de> Nach zwanzig Jahrhunderten der Geschichte fühlt sich die Kirche, »die die Säule und das Fundament der Wahrheit ist« (1 Tim 3,15), mehr denn je gerufen, den Plan Gottes mit der Menschheit aufzunehmen, die Stimme zu hören, die sich aus den verschiedenen Gesellschaften, den Kulturen und den Zivilisationen der ganzen Welt erhebt, ihre tiefsten Bedürfnisse zu erfassen, um sich in ihren Dienst zu stellen.
<G-vec00078-001-s303><accept.aufnehmen><en> "After 20 centuries of history, the Church, ""pillar and bulwark of the truth"" (1 Tm 3:15), feels called more than ever to accept God's plan for humanity, to hear the voice raised from the different societies, cultures and civilizations of the whole world, and to perceive their deepest needs so that she might serve them."
<G-vec00503-001-s071><admit.aufnehmen><de> Die Gefängnisleitung weigerte sich, sie aufzunehmen, weil eine Untersuchung offenbarte, dass Frau Li hohen Blutdruck hatte.
<G-vec00503-001-s071><admit.aufnehmen><en> The prison authorities refused to admit her because a physical exam revealed that Ms. Li had high blood pressure.
<G-vec00503-001-s072><admit.aufnehmen><de> Die Haftanstalt Nanjing weigerte sich, sie aufzunehmen, weil sie an Bluthochdruck litt.
<G-vec00503-001-s072><admit.aufnehmen><en> The Nanjing Detention Station refused to admit her since she suffered from hypertension.
<G-vec00503-001-s073><admit.aufnehmen><de> Das Gymnasium hatte kein Recht, einen Schüler ohne diese Bescheinigung aufzunehmen; solche Bescheinigungen wurden aber von nie mandem ausgestellt...Man kehrt anscheinend zu den Methoden der ver haßten Herren zurück.
<G-vec00503-001-s073><admit.aufnehmen><en> The high school had no right to admit students without such an affidavit; however, such affidavits were not issued by anybody. . .Now we are returning to the trail blazed by the nobility.
<G-vec00503-001-s074><admit.aufnehmen><de> Initiator des Gesetzes, das es der Russischen Föde ration erlaubt, unter dem Vorwand des Schutzes russischer Staatsangehöriger Gebiete eines anderen Staates ohne Zustimmung dieses Staates und ohne einen internationalen Vertrag in die Russische Föde ration aufzunehmen.
<G-vec00503-001-s074><admit.aufnehmen><en> Initiator of the bill allowing Russian Federation to admit in its composition, under the pretext of protection of Russian citizens, territories of a foreign country without a consent of that country or of an international treaty.
<G-vec00503-001-s075><admit.aufnehmen><de> Es braucht sicherlich einige Mut, Ihre Schwächen in der ganzen Welt aufzunehmen.
<G-vec00503-001-s075><admit.aufnehmen><en> This certainly needs some courage to admit their weaknesses, so that the whole world.
<G-vec00503-001-s076><admit.aufnehmen><de> Einen Monat später wurde ich in das Tonghua Zwangsarbeitslager gebracht, wo sich jedoch die Beamten weigerten, mich aufzunehmen.
<G-vec00503-001-s076><admit.aufnehmen><en> One month later I was sent to the Tonghua Forced Labour Camp, but the officials there refused to admit me.
<G-vec00503-001-s077><admit.aufnehmen><de> Vier Polizisten drückten ihn nieder und brachten ihn in die Hulan Haftanstalt, danach in die Harbin Haftanstalt und schließlich in die vierte Haftanstalt in Harbin (auch bekannt als das öffentliche Transportkrankenhaus von Harbin) Li Min, Direktor der vierten Haftanstalt, untersuchte Herrn Jin und weigerte sich, ihn aufzunehmen.
<G-vec00503-001-s077><admit.aufnehmen><en> With four policemen holding him down, they took him to the Hulan Detention Station, then to the Harbin Detention Station, and finally to the Fourth Detention Station in Harbin (also known as the Public Transportation Hospital in Harbin). Li Min, director of the Fourth Detention Station, examined Mr. Jin, then refused to admit him.
<G-vec00503-001-s078><admit.aufnehmen><de> Jedes Ding muss genau an seinem Platz sein und darüber hinaus flexibel und plastisch genug sein, um in einer fortschreitenden harmonischen Organisation all die neuen Elemente aufzunehmen, die sich ständig dem manifestierten Universum anfügen.
<G-vec00503-001-s078><admit.aufnehmen><en> Each thing must be exactly in its place, and what's more, be supple enough, plastic enough, to admit into a harmonious, progressive organization all the new elements constantly being added to the manifest universe.
<G-vec00503-001-s079><admit.aufnehmen><de> Der Arzt-Assistent, der uns vor etwa zwei Tagen versprochen hatte, die Patientin aufzunehmen, war selbst bei einer Operation.
<G-vec00503-001-s079><admit.aufnehmen><en> The assistant doctor, who had promised to admit the patient some two days ago, was unfortunately undergoing an operation.
<G-vec00503-001-s080><admit.aufnehmen><de> Das Interesse galt aber dem Geschlecht und nicht der Studentin, so dass man sich zwar bemühte, etwas mit mir zu unternehmen, aber nicht, mich in eine Lerngruppe aufzunehmen.
<G-vec00503-001-s080><admit.aufnehmen><en> But the interest counted the sex, not the student, so that the students exerted themselfes to undertook something with you, but not, to admit you to their study group.
<G-vec00503-001-s081><admit.aufnehmen><de> Als sie 2003 zu weiteren drei Jahren verurteilt worden war, weigerte sich das Arbeitslager sie aufzunehmen wegen ihres schlechten Gesundheitszustandes.
<G-vec00503-001-s081><admit.aufnehmen><en> The labour camp wouldn't admit her due to her poor health condition when she was sentenced to another three years in 2003.
<G-vec00503-001-s082><admit.aufnehmen><de> Um einen bestimmten Ersatzteil in Ihre Anfrage aufzunehmen, wählen Sie ihn bitte rechts von der Ersatzteilbeschreibung aus und übernehmen Ihre Wahl mit [Übernehmen].
<G-vec00503-001-s082><admit.aufnehmen><en> To add a Spare Part to your Request Page, please select the Spare Part on the right side and click [Add to Request Page] to admit your selection.
<G-vec00503-001-s083><admit.aufnehmen><de> Er hat daher beschlossen, die Stammesführer in die Priesterschaft aufzunehmen.
<G-vec00503-001-s083><admit.aufnehmen><en> Therefore he has decided to admit the leaders to priesthood.
<G-vec00503-001-s084><admit.aufnehmen><de> Gestatten die Zulassung erhalten Sie einer der Moderatoren des Projekts - ist eine glaubwürdige Künstler oder eine Fachkraft, die Organisatoren sagen, das Projekt kann beschließen, die Künstler in die Datenbank aufzunehmen.
<G-vec00503-001-s084><admit.aufnehmen><en> Permit registration will give you one of the moderators of the project - is a credible artist or a specialist, which organizers say the project may decide to admit the artist in the database.
<G-vec00503-001-s085><admit.aufnehmen><de> Sie müßte die Macht haben, Parteiorganisationen im Lande zu organisieren oder zu reorganisieren, Mitglieder aufzunehmen oder auszuschließen und lokale Führungen zu ernennen.
<G-vec00503-001-s085><admit.aufnehmen><en> This should have the power to organise or reorganise party branches inside the country, admit or expel members and appoint local committees.
<G-vec00503-001-s086><admit.aufnehmen><de> Wegen ihres Bluthochdrucks und schnellen Herzschlags weigerte die Haftanstalt sich, Frau Zhang aufzunehmen; doch die Polizisten ließen sie einfach dort.
<G-vec00503-001-s086><admit.aufnehmen><en> The detention centre initially refused to admit Ms. Zhang because she had high blood pressure and a rapid heartbeat, but the police simply left her there.
<G-vec00503-001-s087><admit.aufnehmen><de> So wurde Frau Deng in das Arbeitslager gebracht, aber Frau Zhang nicht, weil sie bei der medizinischen Untersuchung durchfiel und sich deshalb das Personal des Lagers weigerte, sie aufzunehmen.
<G-vec00503-001-s087><admit.aufnehmen><en> Ms. Deng was taken to the camp, but because Ms. Zhang failed the physical, labour camp personnel refused to admit her.
<G-vec00503-001-s088><admit.aufnehmen><de> Der UNO Sicherheitsrat empfiehlt einstimmig mit UNO SR Resolution 652 der UNO Vollversammlung, die Republik Namibia als Vollmitglied der Weltorganisation aufzunehmen.
<G-vec00503-001-s088><admit.aufnehmen><en> In UN SC Resolution 652 the UN Security Council resolves to recommend to the General Assembly to admit the Republic of Namibia as member to the world body.
<G-vec00169-001-s089><capture.aufnehmen><de> Sie machen es einfach, den Flug einen Vogels oder den Sprung eures Freundes in den Ozean aufzunehmen.
<G-vec00169-001-s089><capture.aufnehmen><en> They make it easy to capture the flight of a bird or your friend's jump into the ocean.
<G-vec00169-001-s090><capture.aufnehmen><de> Hinweis: Um ein mögliches Überschreiben von verlorenen Fotos zu vermeiden, sollten Sie die Digitalkamera nicht mehr verwenden, um ein neues Bild aufzunehmen.
<G-vec00169-001-s090><capture.aufnehmen><en> Note: To avoid possible overwriting of lost photos, stop further use of digital camera to capture any new picture.
<G-vec00169-001-s091><capture.aufnehmen><de> Dieses in der Praxis bewährte Datenmodell ist darauf ausgelegt, die Daten aus unterschiedlichsten Vorsystemen automatisiert aufzunehmen und zu messen.
<G-vec00169-001-s091><capture.aufnehmen><en> This data model, proven in practice, is designed to automatically capture and measure data from a wide variety of upstream systems.
<G-vec00169-001-s092><capture.aufnehmen><de> Santa Monica Studio hat unsere Vision unterstützt und uns die Mittel zur Verfügung gestellt, um die Welt zu bereisen und etwas ganz Besonderes aufzunehmen.
<G-vec00169-001-s092><capture.aufnehmen><en> Santa Monica Studio supported the vision and provided the means for us to globe trot and capture something special.
<G-vec00169-001-s093><capture.aufnehmen><de> Die Videoproduktionsschüler lernen, Videoproduktionen und Außenaufnahmen zu planen, hochwertige digitale Videobilder aufzunehmen, mit digitalen Videobearbeitungsgeräten zu arbeiten und direkte Mehrkamera-Videoproduktionen.
<G-vec00169-001-s093><capture.aufnehmen><en> Video Production students learn to plan video productions and field shoots, capture high-quality digital video images, work with digital video editing equipment, and direct multi-camera video productions.
<G-vec00169-001-s094><capture.aufnehmen><de> Plays.tv ermöglicht Ihnen Ihre besten Spielmomente aufzunehmen und zu teilen.
<G-vec00169-001-s094><capture.aufnehmen><en> A free app that allows you to capture and share your gaming best moments.
<G-vec00169-001-s095><capture.aufnehmen><de> Von HDV importieren und dann Ihren Camcorder aus dem Dropdown-Menü, um die Videos vom angehängten HDV Camcorder aufzunehmen und zu importieren.
<G-vec00169-001-s095><capture.aufnehmen><en> Import from HDV and then your camcorder from the drop down to capture and then import videos from an attached HDV camcorder.
<G-vec00169-001-s096><capture.aufnehmen><de> Der Osmo Mobile 2 bewegt sich automatisch, um mehrere Fotos aufzunehmen, und setzt sie dann zu einem nahtlosen Bild zusammen.
<G-vec00169-001-s096><capture.aufnehmen><en> The Osmo Mobile 2 moves automatically to capture multiple photos then stitches them together to create a seamless image.
<G-vec00169-001-s097><capture.aufnehmen><de> Wie beim Arbeiten mit natürlichem Licht musste ich nur meine Position ein wenig anpassen, um den Flare-Effekt wie in der goldenen Stunde aufzunehmen.
<G-vec00169-001-s097><capture.aufnehmen><en> Just like working with natural light, I only had to make small adjustments to my position to capture the golden hour flare I wanted.
<G-vec00169-001-s098><capture.aufnehmen><de> Von DV importieren und dann Ihren Camcorder aus dem Dropdown-Menü, um die Videos vom angehängten DV Camcorder aufzunehmen und zu importieren.
<G-vec00169-001-s098><capture.aufnehmen><en> Import from DV and then your camcorder from the drop down to capture and then import videos from an attached DV camcorder.
<G-vec00169-001-s099><capture.aufnehmen><de> Dieser Umstand ermöglicht es ihnen, Bilder direkt und sehr scharf aufzunehmen, die dann ohne Detailverlust viel stärker vergrößert werden können als digitale Fotos.
<G-vec00169-001-s099><capture.aufnehmen><en> This happenstance allows them to be used to capture images directly with great clarity that can be enlarged to sizes much bigger than traditional photography without loss of detail.
<G-vec00169-001-s100><capture.aufnehmen><de> Doch war ich nicht in der Lage, irgendetwas anderes aufzunehmen als etwas Weißes, das alles und zugleich nichts bedeutet.
<G-vec00169-001-s100><capture.aufnehmen><en> Yet I have been unable to capture anything but a whiteness that means something, and means nothing.
<G-vec00169-001-s101><capture.aufnehmen><de> Refraktorteleskope Linsen anstelle von Spiegeln das Bild aufzunehmen und es zu vergrößern.
<G-vec00169-001-s101><capture.aufnehmen><en> Refractor telescopes use lenses instead of mirrors to capture the image and magnify it.
<G-vec00169-001-s102><capture.aufnehmen><de> Die MCU (1) erhält vom angeschlossenen PC den Befehl, ein Bild aufzunehmen, und startet daraufhin den Schrittmotor des Manipulators (2).
<G-vec00169-001-s102><capture.aufnehmen><en> The MCU (1) gets the command from the connected PC to capture an image and starts the stepper motor of the manipulator.
<G-vec00169-001-s103><capture.aufnehmen><de> Die Technik beschleunigte die MRT-Aufnahmen noch einmal deutlich und erlaubt es, bis zu 100 Bilder pro Sekunde aufzunehmen.
<G-vec00169-001-s103><capture.aufnehmen><en> The technique again significantly increases the speed of MRI scans and can capture up to 100 images per second.
<G-vec00169-001-s104><capture.aufnehmen><de> Wir alle suchen eifrig den perfekten Moment, ein Foto aufzunehmen, mit Cinemagrammen wird das Ganze noch interessanter.
<G-vec00169-001-s104><capture.aufnehmen><en> We're all keen on searching the perfect moment to capture in a photo, but things get even more interesting with cinemagraphs.
<G-vec00169-001-s105><capture.aufnehmen><de> Software kann allerdings helfen, den Dynamik-Umfang während des Scannens zu optimieren, um dem Scanner zu ermöglichen, möglichst viele Bildinformationen aufzunehmen.
<G-vec00169-001-s105><capture.aufnehmen><en> However, software can help to optimize the Dynamic Range for scanning allowing the scanner to capture as much image information as possible.
<G-vec00169-001-s106><capture.aufnehmen><de> Viele Menschen versuchten, diese kostbare Szenerie mit ihren Fotoapparaten und Videokameras aufzunehmen.
<G-vec00169-001-s106><capture.aufnehmen><en> A lot of people tried to capture the precious scene with their cameras and camcorders.
<G-vec00169-001-s107><capture.aufnehmen><de> Tatsächlich ist diese Kamera mit Funktionen ausgestattet, die es ermöglichen, erstaunliche Fotos bei jeder Beleuchtung aufzunehmen.
<G-vec00169-001-s107><capture.aufnehmen><en> In fact, this camera is loaded with features that make it possible to capture amazing photos in any lighting.
<G-vec00169-001-s057><receive.aufnehmen><de> Machen wir darüber hinaus von der stets neu angebotenen Sündenvergebung und der alles krönenden Gnade Gebrauch, im Heiligen Abendmahl Leib und Blut Jesu in uns aufzunehmen, dann kann die neue Kreatur in uns wachsen und reifen, dann nähert sich unser Seelenzustand immer mehr dem Wesen Jesu, dann drängt die Auferstehungskraft zur Herrlichkeit, in die wir eingehen dürfen, wenn der Herr wiederkommt und die Seinen zu sich holt.
<G-vec00169-001-s057><receive.aufnehmen><en> Over and above this, let us avail ourselves of the always new offer of forgiveness of sins and the grace that crowns all things, assimilate the body and blood of Jesus that we receive in the Holy Communion; then the new creature within us can grow and ripen, then the condition of our soul becomes ever closer to the nature of Jesus, then the power of the resurrection impels us into glory, wherein we are permitted to enter when the Lord comes again and takes his own unto himself.
<G-vec00169-001-s058><receive.aufnehmen><de> Er kann sich nach oben ausstrecken, um das Licht der Sonne aufzunehmen, und gleichzeitig den Winden wehren, die ihn umwehen.
<G-vec00169-001-s058><receive.aufnehmen><en> They can reach up high to receive the sunlight and at the same time can resist the winds around them.
<G-vec00169-001-s059><receive.aufnehmen><de> Risikokapital aufzunehmen ist für Startups richtig und wichtig.
<G-vec00169-001-s059><receive.aufnehmen><en> It is appropriate and important for startups to receive venture capital.
<G-vec00169-001-s060><receive.aufnehmen><de> Und weil sie nichts und niemandem erlaubte, sie von diesem Ziel abzulenken, war sie fähig, die geistigen Gaben des Gurus ganz in sich aufzunehmen und in seinem Werk Gottes Licht und Segen in so reiner Form zu vermitteln.
<G-vec00169-001-s060><receive.aufnehmen><en> Perfecting that love became the supreme goal of her own life; and because she never allowed anything to distract her from that goal, she was able to receive fully his spiritual bounty and to be such a pure channel of God's light and blessings in this world.
<G-vec00169-001-s061><receive.aufnehmen><de> Es ist wohl der Verstand fähig, die ihm zuströmenden Gedanken aufzunehmen und zu verarbeiten, doch der Gedanke selbst entsteht nicht im Menschen, sondern er berührt sein Herz, entströmt aber dem Reich, das außerhalb irdischer Sphären liegt.
<G-vec00169-001-s061><receive.aufnehmen><en> The intellect is certainly able to receive and to process the thoughts flowing towards him, but the thought itself does not originate in man, but it touches his heart, but flows out of the kingdom, which lies outside of earthly spheres.
<G-vec00169-001-s062><receive.aufnehmen><de> Lasset euch nicht von weltlichen Sorgen niederdrücken, die sich von selbst wieder in nichts auflösen, sondern gedenket nur eurer Seele, die immer Kraft empfangen wird, der durch Mein Wort die Kraft aus Mir vermittelt wird, weshalb Mein Wort aufzunehmen für euch das Nötigste ist, was ihr nicht versäumen dürfet.
<G-vec00169-001-s062><receive.aufnehmen><en> Do not let yourselves be pressed down by worldly worries, which are again resolved of itself into nothing, but only remember your soul, which will always receive power, to which power is imparted through my word out of me, why to receive my word is the bare essentials for you, what you are not allowed to miss.
<G-vec00169-001-s063><receive.aufnehmen><de> "Wir verbringen im Normalfall also wesentlich weniger als 10% unseres Tages draußen, d.h. viele von uns sind nicht in der Lage ihre tägliche Dosis ""natürliches Tageslicht"" aufzunehmen."
<G-vec00169-001-s063><receive.aufnehmen><en> As a result, we generally spend much less than 10% of our daytime outside and many of us are now unable to receive our daily dose of natural daylight.
<G-vec00169-001-s064><receive.aufnehmen><de> "So bist du verflucht, verbannt vom Ackerboden, der seinen Mund aufgesperrt hat, um aus deiner Hand das Blut deines Bruders aufzunehmen"" (Gen 4,10-11)."
<G-vec00169-001-s064><receive.aufnehmen><en> "And now you are cursed from the ground, which has opened its mouth to receive your brother's blood from your hand.""58"
<G-vec00169-001-s065><receive.aufnehmen><de> Die Arbeit mit den Kräften des Tierkreises macht es möglich diese wunderbaren Sternenkräfte direkt in unser Gesamtgefüge von Körper, Seele und Geist aufzunehmen.
<G-vec00169-001-s065><receive.aufnehmen><en> By working with the Forces of the Zodiac we can receive these strongly healing and nourishing star forces directly into our body, soul and spirit.
<G-vec00169-001-s066><receive.aufnehmen><de> Progesteron mit Östrogen macht die Gebärmutterschleimhaut reift und sich vorbereitet, aufzunehmen und zu halten eine mögliche befruchteten Eizelle.
<G-vec00169-001-s066><receive.aufnehmen><en> Progesterone along with estrogen makes the endometrium matures and prepares to receive and support a possible fertilized egg.
<G-vec00169-001-s067><receive.aufnehmen><de> Die medjugorische Kirche war nicht groß genug, um alle aufzunehmen, die ihre Freude und guten Wünschen für die Brautleute ausdrücken wollten, auf dass sie ihren Weg fortsetzen mögen, den sie seit Jahren gehen.
<G-vec00169-001-s067><receive.aufnehmen><en> The church of Medjugorje was not big enough to receive all those who wanted to express their joy, their good wishes to the newlyweds, and the desire to see them continue on the way they were going for so many years now.
<G-vec00169-001-s068><receive.aufnehmen><de> Bei der Einkleidung empfängt Pierina Bertone den Namen Consolata, um Trost für die Liebe Jesu für so viel Misstrauen zu Seiner Güte und Barmherzigkeit zu sein, wobei sie die Trösterin des Herzens Jesu und all jener sein wollte, die nicht imstande waren, die Liebe des Herrn aufzunehmen.
<G-vec00169-001-s068><receive.aufnehmen><en> To console Jesus for the great mistrust in His Goodness and Mercy, Pierina Betrone took the name Consolata (she who is consoled) when she took her vows, in a desire to console the Heart of Jesus and all those who weren't able to perceive and receive the Lord's love.
<G-vec00169-001-s069><receive.aufnehmen><de> »Gott hat in seiner Weisheit und Güte beschlossen, sich selbst zu offenbaren und das Geheimnis seines Willens kundzutun..., um sie (die Menschen) in seine Gemeinschaft einzuladen und aufzunehmen».
<G-vec00169-001-s069><receive.aufnehmen><en> """It pleased God, in his goodness and wisdom, to reveal himself and to make known the mystery of his will [to men]...in order to invite and receive them into communion with himself""."
<G-vec00169-001-s070><receive.aufnehmen><de> Bei einigen ausgestorbenen Arten haben Wissenschaftler sogar Löcher entdeckt, die wie Augenansätze im mittleren hinteren Bereich des Schädels aussehen und es der Epiphyse ermöglicht haben könnten, das Licht direkt aufzunehmen, genau wie ein Auge.
<G-vec00169-001-s070><receive.aufnehmen><en> In some fossil species, scientists have even found holes just like eye sockets in the centre-rear part of the skull, which allowed the pineal gland to receive light directly, just like an eye.
<G-vec00169-001-s071><receive.aufnehmen><de> Weihnachten ist das Fest des Glaubens an die Herzen, die zur Krippe werden, um Ihn aufzunehmen, an die Seelen, die Gott erlauben, aus dem Stumpf ihrer Armut den Spross der Hoffnung, der Liebe und des Glaubens hervorwachsen zu lassen.
<G-vec00169-001-s071><receive.aufnehmen><en> Christmas is the feast of faith in hearts that become a manger to receive him and souls that allow God to make a shoot of hope, charity and faith sprout from the stump of their poverty.
<G-vec00169-001-s072><receive.aufnehmen><de> Das Ziel ist dann, den eigenen physischen Körper zunächst neu aufzubauen, indem man ihn von alten Giften reinigt, um fähig zu werden, neue und feinere Elemente höherwertiger Natur in sich aufzunehmen.
<G-vec00169-001-s072><receive.aufnehmen><en> One's aim is to reconstruct the physical body first by cleansing it of old toxins and elements in order to be able to successfully receive new and more refined elements of a higher nature.
<G-vec00169-001-s073><receive.aufnehmen><de> Wenn ein Haus mit Blick auf Fenster auf dem Süd-oder Süd-West, würde er eine starke Dosis von Yang-Energie aufzunehmen und für sie müssen sich in der Dekoration der kühle Farben verwendet werden, zu kompensieren.
<G-vec00169-001-s073><receive.aufnehmen><en> If a house overlooking windows on the south or south-west, he would receive a strong dose of energy Yang, and to compensate for her need to be used in the decoration of cool colors.
<G-vec00169-001-s074><receive.aufnehmen><de> Als er aber nach Achaja reisen wollte, schrieben die Brüder den Jüngern und ermahnten sie, ihn aufzunehmen.
<G-vec00169-001-s074><receive.aufnehmen><en> When he had determined to pass over into Achaia, the brothers encouraged him, and wrote to the disciples to receive him.
<G-vec00169-001-s075><receive.aufnehmen><de> Die Kraft und das Licht des Heiligen Geistes sind immer wirksam, doch es liegt an uns, sie aufzunehmen, durch unseren Glauben, den Wunsch und das Gebet.
<G-vec00169-001-s075><receive.aufnehmen><en> The power and light of the Spirit is always acting, but it depends on us to receive it, through faith, desire and prayer.
<G-vec00476-001-s030><soak_up.aufnehmen><de> Ihre spezifisch gebauten Wurzeln sind in der Lage Wasser aus der Atmosphäre aufzunehmen.
<G-vec00476-001-s030><soak_up.aufnehmen><en> The specific structure of their roots is capable to soak up water from the atmosphere.
<G-vec00476-001-s031><soak_up.aufnehmen><de> Viele Besucher strömen in die Außenbezirke von Melbourne, wie Carlton, Fitzroy und St Kilda, um dort die besondere Kulisse, die aufstrebende Kunst- und Musikszene und natürlich die hervorragende Küche in sich aufzunehmen.
<G-vec00476-001-s031><soak_up.aufnehmen><en> Visitors flock to the outer suburbs of Melbourne, like Carlton, Fitzroy, and St Kilda, for the chance to soak up scenery, emerging art and music scenes and, of course, the amazing cuisine.
<G-vec00476-001-s032><soak_up.aufnehmen><de> Nun ist Ihr Zweig wieder bereit, Änderungen von der Hauptentwicklungslinie aufzunehmen.
<G-vec00476-001-s032><soak_up.aufnehmen><en> Now your branch is ready to soak up changes from the trunk again.
<G-vec00476-001-s033><soak_up.aufnehmen><de> Auf das gewaschene Haar aufgetragen, ist diese Maske reich an Nährstoffen aus Paranussöl (hochkonzentriert in Fettsäuren, Selen und Vitamin E), dessen einzigartige Eigenschaften es dem Haar ermöglichen, Feuchtigkeit aufzunehmen, ohne es zu belasten.
<G-vec00476-001-s033><soak_up.aufnehmen><en> Applied to washed hair, this mask is rich in nourishing agents provided by Brazil nut oil (highly concentrated in fatty acids, selenium and vitamin E), whose unique properties allow hair to soak up moisture without being weighed down.
<G-vec00476-001-s034><soak_up.aufnehmen><de> Wo immer ich war, hab' ich versucht, mit der Natur Kontakt aufzunehmen, sie in mich aufzunehmen.
<G-vec00476-001-s034><soak_up.aufnehmen><en> Wherever I have been, I have tried to have contact with nature, to soak it up.
<G-vec00476-001-s035><soak_up.aufnehmen><de> Wahrscheinlich beides, jedoch ist es der Wandel der Vision, welcher den Wandel der Materie auslöst, der Wandel der Vision, welcher eine neue Handhabung der Materie erlaubt, so wie unsere Menschenaugen uns eine neue Handhabung der Welt ermöglichten; und dieser Wandel der Materie scheint erst dann möglich zu sein, wenn die Menschheit als Ganzes oder ein hin-reichend mächtiger Teil des großen irdischen Kör-pers – denn wir sind ein einziger Körper, das vergessen wir ständig – einwilligt, die neue Luft zu atmen, diesen Saft aufzunehmen, aufzuhören, an seine alten Phantome und Ängste, seine alten men-talen Unmöglichkeiten zu glauben.
<G-vec00476-001-s035><soak_up.aufnehmen><en> Doubtless it is both, but the change of vision is what triggers the change of matter; the change in vision is what permits a new manipulation of matter, as our human eyes have enabled a new manipulation of the world. And this change of matter seems possible only if humanity as a whole, or a sufficiently effective proportion of the great earthly body – because we are a single body, we always forget – consents to breathe the new air, to soak up that sap, to stop believing in its phantoms and fears and old mental impossibilities.
<G-vec00057-001-s133><contact.aufnehmen><de> Der Zufall will es, dass sie Kontakt mit einer fremden Lebensform aufnehmen.
<G-vec00057-001-s133><contact.aufnehmen><en> By coincidence, they establish contact with an alien form of life.
<G-vec00057-001-s134><contact.aufnehmen><de> Dem Wasser ist genug den Kontakt mit dem Stoff aufnehmen, um seine Eigenschaften zu erfahren und diese Information in seinem Gedächtnis halten zu können.
<G-vec00057-001-s134><contact.aufnehmen><en> For water is enough to come in contact with the substance to learn about its properties and to keep this information in its memory.
<G-vec00057-001-s135><contact.aufnehmen><de> Es ist sehr unwahrscheinlich, dass sich die Klienten Ihnen öffnen und Kontakt aufnehmen.
<G-vec00057-001-s135><contact.aufnehmen><en> It is very unlikely that clients are open with you and make contact.
<G-vec00057-001-s136><contact.aufnehmen><de> Um die Details abzuklären, bitte mit uns telefonisch Kontakt aufnehmen oder Ihre Telefonnummer in das Bemerkungsfeld eintragen, wir rufen gerne zurück.
<G-vec00057-001-s136><contact.aufnehmen><en> To clarify the details, please contact us by telephone contact or insert your phone number in the comments section, we will call you back.
<G-vec00057-001-s137><contact.aufnehmen><de> In diesem Fall und falls der Nutzer in geschäftliche Beziehungen mit Siemens treten möchte, sollte der Nutzer zu Siemens-Repräsentanten in dem jeweiligen Land Kontakt aufnehmen.
<G-vec00057-001-s137><contact.aufnehmen><en> In this case, and assuming that the user wishes to enter into business relations with Siemens, the user should contact the Siemens representatives in the respective country.
<G-vec00057-001-s138><contact.aufnehmen><de> Über das E-Mail-Formular können Sie direkten Kontakt zu unserer Pressestelle aufnehmen.
<G-vec00057-001-s138><contact.aufnehmen><en> You can contact our press office directly using the e-mail form.
<G-vec00057-001-s139><contact.aufnehmen><de> Einzelpersonen können verlangen, auf Informationen, die wir über sie haben, zuzugreifen, sie zu korrigieren, zu ändern oder zu löschen, indem sie auf unserer Kontaktseite Kontakt aufnehmen.
<G-vec00057-001-s139><contact.aufnehmen><en> Individuals may request to access, correct, amend or delete information we hold about them by contacting on our contact page.
<G-vec00057-001-s140><contact.aufnehmen><de> Sollte ein unautorisierter Kauf, vor Ihrer Notifikation, getätigt worden sein, so übernimmt Eu-pharmacy-online.net keine Haftung und Sie sollten mit dem Frachtführer Kontakt aufnehmen.
<G-vec00057-001-s140><contact.aufnehmen><en> In the event that an unauthorised purchase is dispatched prior to your notifying us of the unauthorised nature of the purchase, Eu-pharmacy-online.net accepts no liability or responsibility and you should make contact with the Carrier detailed in the Purchase Information.
<G-vec00057-001-s141><contact.aufnehmen><de> Als zuverlässiger Qualitätsanbieter, der in der Lage ist, schnell und flexibel auf wechselnde Marktanforderungen zu reagieren, sollten Sie Kontakt zu unserem strategischen Einkauf aufnehmen.
<G-vec00057-001-s141><contact.aufnehmen><en> Are you a reliable quality supplier who can respond rapidly and dynamically to changing market requirements? Please contact our Strategic Purchasing Department.
<G-vec00057-001-s142><contact.aufnehmen><de> Das Hospital und alle 28 Gemeinden verfügen über ein Funkgerät, um Kontakt aufnehmen zu können.
<G-vec00057-001-s142><contact.aufnehmen><en> The hospital and all 28 villages are equipped with radio appliances in order to establish contact.
<G-vec00057-001-s143><contact.aufnehmen><de> Sie können Kontakt aufnehmen, unter anderem um einen Besuch zu organisieren, um Fragen über die Arbeit der beiden Organe zu stellen oder um Dokumente anzufordern.
<G-vec00057-001-s143><contact.aufnehmen><en> You can get in contact to arrange a visit, ask questions about the work of both institutions, and request a document, among other services.
<G-vec00057-001-s144><contact.aufnehmen><de> E-Mails sind eigentlich ein tolles Werbemedium: Man kann praktisch umsonst Kontakt zu seinen Kunden aufnehmen, ihnen tagesaktuelle Inhalte schicken und ihnen die Möglichkeit zu einer direkten Reaktion anbieten.
<G-vec00057-001-s144><contact.aufnehmen><en> E-mails are actually a great means of advertising: You can make contact with your customers more or less for free, send them information which is up-to-the-minute and offer them a chance to give a direct reaction.
<G-vec00057-001-s145><contact.aufnehmen><de> HOCHLADEN VON MATERIALIEN AUF UNSERE WEBSITE Wenn Sie eine Funktion nutzen, mit der Sie Materialien auf unsere Website hochladen oder Kontakt mit anderen Benutzern unserer Website aufnehmen können, müssen Sie die Inhaltsanforderungen einhalten, die in unserer Richtlinie über die zulässige Nutzung dargelegt sind.
<G-vec00057-001-s145><contact.aufnehmen><en> Whenever you make use of a feature that allows you to upload material to our site, or to make contact with other users of our site, you must comply with the content standards set out in our Acceptable Use Policy .
<G-vec00057-001-s146><contact.aufnehmen><de> Ich habe meinen Computer aus Bauteilen gebaut; Ich habe keinen Systemhersteller, der Kontakt aufnehmen muss.
<G-vec00057-001-s146><contact.aufnehmen><en> I built my computer from components; I don't have a system manufacturer Â to contact.
<G-vec00057-001-s147><contact.aufnehmen><de> Innovation Nachhaltigkeit Hier können Sie Kontakt zur Siemens-Innovationskommunikation aufnehmen.
<G-vec00057-001-s147><contact.aufnehmen><en> Innovation Sustainability Here you can contact the Siemens Innovation Communications.
<G-vec00057-001-s148><contact.aufnehmen><de> Wenn Sie telefonisch mit uns Kontakt aufnehmen, behalten wir uns das Recht vor, diese Anrufe aufzunehmen.
<G-vec00057-001-s148><contact.aufnehmen><en> If You contact Us by telephone, We reserve the right to record such calls.
<G-vec00057-001-s149><contact.aufnehmen><de> Mit den Social-Media-Apps wie Facebook kann der Benutzer auswählen, wer Kontakt aufnehmen, eine Freundschaftsanfrage senden, Nachrichten senden und Social-Media-Beiträge anzeigen kann.
<G-vec00057-001-s149><contact.aufnehmen><en> The social media apps like Facebook let the user choose who can contact, send a friend request, transmit messages and see social media posts.
<G-vec00057-001-s150><contact.aufnehmen><de> Nach deiner Bewerbung über unser Anmeldeformular werden wir dies entsprechend prüfen und so schnell wie möglich mit dir Kontakt aufnehmen, um deine Nominierung zu bestätigen oder die Voraussetzungen zu erfüllen.
<G-vec00057-001-s150><contact.aufnehmen><en> After your application via our registration form, we will get in contact with you to take care about your nomination and the requirements as soon as possible.
<G-vec00057-001-s151><contact.aufnehmen><de> Per E-Mail können Sie mit uns schnell Kontakt aufnehmen.
<G-vec00057-001-s151><contact.aufnehmen><en> You can contact us quickly by email.
<G-vec00505-001-s152><borrow.aufnehmen><de> Ich kann Kredite bis zu £ 7.500 auf der Kreditkarte 1 und £ 6.000 auf der Kreditkarte 2.
<G-vec00505-001-s152><borrow.aufnehmen><en> I can borrow up to £ 7,500 on Credit Card 1 and £ 6,000 on Credit Card 2.
<G-vec00505-001-s153><borrow.aufnehmen><de> Bis 2008 war es üblich, Kredite bis zu 90% des Wertes der Eigenschaft, 95% oder sogar mehr als 100%.
<G-vec00505-001-s153><borrow.aufnehmen><en> Until 2008 it was usual to borrow up to 90% of the value of the property, 95% or even more than 100%.
<G-vec00505-001-s154><borrow.aufnehmen><de> Wenn die Darlehen gering sind und die Volkswirtschaft Mühe hat, dann wird eine Zentralbank oft die Zinssätze senken, um die Kredite zu fördern, was oft der schnellste Weg für ein Wirtschaftswachstum ist.
<G-vec00505-001-s154><borrow.aufnehmen><en> When borrowing is low and the economy is struggling, then a central bank will often look to the lower interest rates to boost incentives to borrow, which is often the quickest way to grow the economy.
<G-vec00505-001-s155><borrow.aufnehmen><de> 2011-08-17 05:00:15 - Kein Dokument Zahltag Darlehen - Kredite easy cash ohne lästige Formalitäten Wenn Sie sich für kurzfristige Darlehen Unterstützung, die Sie bei der Erfüllung verschiedener Tag-zu-Tag-und plötzliche Finanzkrise helfen suchen, können kein Dokument Zahltag Darlehen am besten geeigneten und bezahlbaren Kredit zu behandeln.
<G-vec00505-001-s155><borrow.aufnehmen><en> 2011-08-17 05:00:15 - No document payday loans - borrow easy cash without annoying formalities If you are searching for short term loan assistance that can help you in meeting various day-to-day and sudden financial crisis, no document payday loans can be the most suitable and affordable loan deal.
<G-vec00505-001-s156><borrow.aufnehmen><de> Ein Haus lässt sich mit Hilfe von Verwandten finanzieren, eine Firma kann Kredite auch bei anderen Firmen aufnehmen.
<G-vec00505-001-s156><borrow.aufnehmen><en> A house could be financed with the help of relations and a company could also borrow from other companies.
<G-vec00505-001-s157><borrow.aufnehmen><de> Dieses Symbol war eine klare Darstellung dessen, was Mintos tut: ein Verbindungspunkt zwischen denen, die nach Möglichkeiten zum Sparen und Investieren suchen, und denen, die Kredite aufnehmen möchten.
<G-vec00505-001-s157><borrow.aufnehmen><en> This symbol was a clear representation of what Mintos does: a point of connection between those looking for opportunities to save and invest and those looking to borrow.
<G-vec00505-001-s158><borrow.aufnehmen><de> B. von Unternehmen, die Kredite aufnehmen wollen) oder von Finanzinstitutionen, die die Gegenparteien der Firma sind.
<G-vec00505-001-s158><borrow.aufnehmen><en> corporations wanting to borrow money) or from financial institutions who are the firm's counterparties.
<G-vec00505-001-s159><borrow.aufnehmen><de> Aber nur reiche Leute, große Unternehmen oder Regierungen können zu so niedrigen Zinssätzen Kredite aufnehmen.
<G-vec00505-001-s159><borrow.aufnehmen><en> But only rich people, big corporations or governments get to borrow at such low rates.
<G-vec00505-001-s160><borrow.aufnehmen><de> Diese Situation besteht zu einer Zeit, in der einige Staaten laut McKinsey mit Bedarf für höhere Ausgaben Kredite zu den niedrigsten Zinssätzen überhaupt und sogar zu negativen Raten aufnehmen können.
<G-vec00505-001-s160><borrow.aufnehmen><en> This is at a time where some of the nations that McKinsey suggests need extra spending are able to borrow at all time low, and even negative, rates.
<G-vec00505-001-s161><borrow.aufnehmen><de> Bei Bedarf können die Systeme als letztes Mittel Kredite in begrenzter Höhe bei anderen Systemen aufnehmen (gegenseitige Kreditvergabe) oder auf andere Finanzierungsmöglichkeiten zurückgreifen.
<G-vec00505-001-s161><borrow.aufnehmen><en> "If necessary, schemes can borrow a limited amount from other schemes and other funding arrangements as a last resort (""mutual borrowing"")."
<G-vec00505-001-s162><borrow.aufnehmen><de> Aber Regierungen wurden in Unternehmen der Rothschild Khazarian Mafia gezwungen und sind daher verpflichtet, Kredite bei den Zentralbanken aufzunehmen.
<G-vec00505-001-s162><borrow.aufnehmen><en> But governments have been forced into enterprises owned by the Rothschild Khazarian Mafia and are consequently required to borrow from the central banks.
<G-vec00505-001-s163><borrow.aufnehmen><de> Von diesem Moment an wurde die Freiheit des Volkes, sich zu weigern Kredite bei den Banken aufzunehmen und Zinsen zu zahlen aufgehoben.
<G-vec00505-001-s163><borrow.aufnehmen><en> From that moment on, the freedom of the people to refuse to borrow from the banks and to refuse to pay interest was stripped away.
<G-vec00505-001-s164><borrow.aufnehmen><de> Dem Maastricht-Vertrag zufolge hätte sie keine Möglichkeit, Kredite aufzunehmen, um das Defizit abzudecken.
<G-vec00505-001-s164><borrow.aufnehmen><en> Under Maastricht, it would not be allowed to borrow money to cover the deficit.
<G-vec00505-001-s165><borrow.aufnehmen><de> Dies ermutigt viele Kunden, Kredite aufzunehmen – es wird mehr Buchgeld geschaffen.
<G-vec00505-001-s165><borrow.aufnehmen><en> This encourages many customers to borrow, thus more book money is created.
<G-vec00505-001-s166><borrow.aufnehmen><de> Weitere Optionen für die Verringerung der Kreditkarte Kosten Anleihen gegen Geld Ihrer Kreditkarte ist seit jeher zu den teuersten Möglichkeiten, Kredite aufzunehmen, und wenn Sie nicht zu zahlen Sie Ihre Rechnung in voller jeden Monat, Anleihe ist genau das, was du tust.
<G-vec00505-001-s166><borrow.aufnehmen><en> more options for reducing credit card costs Borrowing money against your credit cards has always been among the most expensive ways to borrow money, and when you fail to pay your bill in full each month, borrowing is exactly what you're doing.
<G-vec00476-001-s217><absorb.aufnehmen><de> Im Vergleich zu Beleuchtungslampen nehmen Besonnungslampen gleicher elektrischer Leistung mehr Strom auf und erzeugen dadurch eine höhere Strahlungsleistung.
<G-vec00476-001-s217><absorb.aufnehmen><en> In comparison with general lighting lamps, tanning lamps of the same electrical capacity absorb more power and thereby generate a higher irradiance.
<G-vec00476-001-s218><absorb.aufnehmen><de> Zwar nehmen alle Pflanzen Kohlendioxid auf, jedoch sind Bäume dafür am besten geeignet, da sie als Teil der Photosynthese und aufgrund ihrer Größe und ihres Wurzelwerks sehr viel mehr CO2 verarbeiten könnten als kleinere Pflanzen.
<G-vec00476-001-s218><absorb.aufnehmen><en> All plants absorb carbon dioxide (CO2), but trees are best because they process significantly more CO2 as part of photosynthesis than smaller plants due to their large size and extensive root structures.
<G-vec00476-001-s219><absorb.aufnehmen><de> Das Kölner Akrobaten- und Choreografenduo Overhead Project sowie die ChoreografInnen Lali Ayguadé und Simone Sandroni entwickeln die disziplinierten Bewegungsabläufe von Bohner weiter, streben der bebenden Konzentration und Präzision nach oder nehmen im Kontrast zu Angst und Geometrie flirrende Bewegungen auf.
<G-vec00476-001-s219><absorb.aufnehmen><en> The Cologne acrobatic and choreographic duo Overhead Project and the choreographers Lali Ayguadé and Simone Sandroni further develop Bohner's disciplined movement sequences, strive for quivering concentration and precision or absorb shimmering movements in contrast to fear and geometry.
<G-vec00476-001-s220><absorb.aufnehmen><de> Denn das, was Sie wollen, nehmen Sie auf und so sind auch Ihre Gedanken.
<G-vec00476-001-s220><absorb.aufnehmen><en> Because what you want you will absorb and so are your thoughts.
<G-vec00476-001-s221><absorb.aufnehmen><de> Wimpern nehmen so viele Nährstoffe auf, wie sie für die Regeneration benötigen.
<G-vec00476-001-s221><absorb.aufnehmen><en> Eyelashes will absorb as many nutrients as they need for recovery.
<G-vec00169-001-s120><reclaim.aufnehmen><de> "Folgen Sie den Schildern ""Arrivals/Baggage reclaim"" in London, um Ihr Gepäck aufzunehmen."
<G-vec00169-001-s120><reclaim.aufnehmen><en> Follow the signs for 'Arrivals/Baggage reclaim' in London to collect your bags.
<G-vec00239-002-s219><enroll.aufnehmen><de> Als die Schwester sagte, meine Spermienzahl sei außergewöhnlich hoch und die Klinik würde sich freuen, mich in ihr Spenderprogramm aufzunehmen, breitete ich meine Flügel aus und begann zu fliegen.
<G-vec00239-002-s219><enroll.aufnehmen><en> The nurse told me my sperm count was extraordinarily high and that they would be very happy to enroll me into the programme. From that moment on I began to spread my wings.
<G-vec00246-002-s118><raise.aufnehmen><de> Ein bereits kotiertes Unternehmen kann auf einfache Art zusätzliches Kapital aufnehmen.
<G-vec00246-002-s118><raise.aufnehmen><en> A company that is already listed on a stock exchange can easily raise additional capital.
<G-vec00246-002-s120><raise.aufnehmen><de> In unserer orthodoxen Kirche sind die Chöre diejenigen, welche ähnlich den engelsgleichen Liedern den Dank zu Gott aufnehmen, im orthodoxen Geist atmen und dem Glauben Kraft verleihen.
<G-vec00246-002-s120><raise.aufnehmen><en> In our Orthodox Church choirs, like angel singing, praise the God, raise the orthodox spirit and make our faith strong.
<G-vec00246-002-s121><raise.aufnehmen><de> An der Börse Frankfurt können große ebenso wie mittelständische, nationale wie internationale Unternehmen Eigen- oder Fremdkapital aufnehmen.
<G-vec00246-002-s121><raise.aufnehmen><en> The Frankfurt Stock Exchange allows companies of all kinds and sizes to raise equity or debt capital – SMEs or large enterprises, domestic or international.
<G-vec00246-002-s122><raise.aufnehmen><de> 23:1 Du sollst kein falsches Gerücht aufnehmen; du sollst deine Hand nicht dem Gesetzlosen reichen, um ein ungerechter Zeuge zu sein.
<G-vec00246-002-s122><raise.aufnehmen><en> 23:1 You shall not raise a false report: put not yours hand with the wicked to be an unrighteous witness.
<G-vec00246-002-s123><raise.aufnehmen><de> Indem wir Vertrauen herstellen, verbessert sich die Situation: Eine Bank, über deren Bilanz wieder Transparenz und Sicherheit herrscht, wird eher am Markt Mittel aufnehmen können.
<G-vec00246-002-s123><raise.aufnehmen><en> The situation will improve if we restore confidence: a bank will find it easier to raise funds in the market if there is transparency and certainty about its balance sheet.
<G-vec00246-002-s124><raise.aufnehmen><de> Auf diese Weise organisiert sie integre, transparente und sichere Märkte für Investoren, die Kapital anlegen, und für Unternehmen, die Kapital aufnehmen.
<G-vec00246-002-s124><raise.aufnehmen><en> It organises markets characterised by integrity, transparency and safety for investors who invest capital and for companies that raise capital.
<G-vec00246-002-s125><raise.aufnehmen><de> Emittenten dürfen binnen sieben Jahren in Summe nicht mehr als fünf Millionen Euro - abzüglich der bereits an die Anleger zurückgezahlten Beträge - aufnehmen.
<G-vec00246-002-s125><raise.aufnehmen><en> Issuers may not raise more than EUR 5 million in capital over a seven year period, less the amounts already paid back to investors.
<G-vec00246-002-s126><raise.aufnehmen><de> Darunter befinden sich zunächst russische Privatunternehmen, die Kapital am Aktienmarkt aufnehmen wollen.
<G-vec00246-002-s126><raise.aufnehmen><en> The first are private Russian companies that seek to raise funds through a share or a bond placement on the exchange.
<G-vec00246-002-s127><raise.aufnehmen><de> Da der Fremdkapitalgeber bei einem potenziell höheren Risiko als Kompensation eine höhere Verzinsung erwartet, kann ein Unternehmen mit einem sehr guten Rating und sonst gleichen Bedingungen zu günstigeren Konditionen Fremdkapital aufnehmen als ein Unternehmen mit einer weniger günstigen Einstufung.
<G-vec00246-002-s127><raise.aufnehmen><en> Since lenders expect to receive higher interest payments in return for exposure to higher risks, a company with a very good credit rating other circumstances being equal can raise debt capital on more favorable terms than one with a lower rating.
<G-vec00246-002-s128><raise.aufnehmen><de> Für diese Art Anleger besteht der eindeutige Vorteil darin, dass sie kein Fremdkapital aufnehmen müssen, um eine Hebelwirkung zu erzielen, denn um dies kümmert sich die entsprechende Fondsgesellschaft.
<G-vec00246-002-s128><raise.aufnehmen><en> For day traders, the best advantage is that they don’t have to raise the capital in order to leverage the ETF. Because that is something the respective fund company takes care of.
<G-vec00246-002-s023><reestablish.aufnehmen><de> Der Zweck dieser ersten Versammlung war es den Kontakt mit den Sozialpartnern wieder aufzunehmen und die Entwicklungsstrategie des Abkommens auszuarbeiten.
<G-vec00246-002-s023><reestablish.aufnehmen><en> The purpose of this first meeting was to reestablish the contacts with the social partners and to elaborate the development strategy of the Pact.
<G-vec00246-002-s034><reinstate.aufnehmen><de> In diesem Fall stellt sich die Frage, ob der Anmelder oder der Patentinhaber breitere Ansprüche wieder aufnehmen kann, die in einer früheren Phase des Verfahrens vorgeschlagen worden waren.
<G-vec00246-002-s034><reinstate.aufnehmen><en> In this case the question arises of whether the applicant or patent proprietor can reinstate broader claims which had been proposed at an earlier stage of the proceedings.
<G-vec00246-002-s019><resume.aufnehmen><de> Wenn Sie Fragen zu den Therapieformen oder Seminaren haben, können Sie gerne mit dem Feddback-Formular Kontakt zu mir aufnehmen.
<G-vec00246-002-s019><resume.aufnehmen><en> Jon Perrault Resume. If you have any questions, please contact me using the contact form above.
<G-vec00246-002-s020><resume.aufnehmen><de> Er war lobenswerter Weise der einzige, der das Palästina-Problem vorbrachte, als er erklärte, er werde an keiner Regierung teilnehmen, die nicht Gespräche mit den Palästinensern aufnehmen will.
<G-vec00246-002-s020><resume.aufnehmen><en> Laudably, he is the only one who has brought up the Palestinian issue, declaring that he will be no part of any government that does not resume talks with the Palestinians.
<G-vec00246-002-s021><resume.aufnehmen><de> Was auch immer der untreue Roberto Devereux an politischem Fehlverhalten bis hin zur offenen Rebellion gegen die Königin an den Tag legte, würde sie ihm vorbehaltlos verzeihen, wenn er noch einmal die Beziehung zu ihr aufnehmen wollte.
<G-vec00246-002-s021><resume.aufnehmen><en> Whatever political malefactions the disloyal Roberto Devereux may have indulged in so far, all the way to open rebellion against the queen, she would be ready to forgive him unconditionally if only he would resume his relationship with her.
<G-vec00246-002-s022><resume.aufnehmen><de> Die Netzwiederkehr wird somit sichergestellt und der entsprechende Verbraucher kann seinen normalen Betrieb aufnehmen.
<G-vec00246-002-s022><resume.aufnehmen><en> This ensures restoration of the supply and the corresponding consumer can resume its normal operation.
<G-vec00246-002-s023><resume.aufnehmen><de> Nach der Reparatur der defekten Computer oder Laptops stellen wir die gesicherten Daten auf das neue oder reparierte PC-Betriebssystem wieder her, so dass der Kunde seine Arbeit mit all seinen Daten wieder aufnehmen kann.
<G-vec00246-002-s023><resume.aufnehmen><en> After repairing the defective computers or laptops we restore the backed up data to the new or repaired PCs operating system so the client can resume working with his computer with all his data at his convenience afterwards.
<G-vec00260-002-s099><insure.aufnehmen><de> Allerdings sind die Unternehmen der privaten Krankenkassen nicht verpflichtet, alle Interessenten aufzunehmen.
<G-vec00260-002-s099><insure.aufnehmen><en> Private health insurance companies are not obliged to insure everyone who applies, however.
<G-vec00322-002-s076><establish.aufnehmen><de> Im "Petersberger Abkommen" einigen sich am 22.11.1949 die Alliierte Hohe Kommission und Bundeskanzler Adenauer auf die Revision des Statuts in einigen wesentlichen Punkten: Die BRD kann der Internationalen Ruhrbehörde beitreten und offizielle Konsular- und Handelsbeziehungen zu anderen Staaten aufnehmen.
<G-vec00322-002-s076><establish.aufnehmen><en> The "Petersberg Agreement" is drawn up between the tripartite Allied High Commission and the Federal Chancellor: the FRG can join the International Authority for the Ruhr and thus begin to establish consular and trade relations with other nations - a concession by the Allied Powers.
<G-vec00322-002-s077><establish.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser Verbindung zu den Servern von Google aufnehmen.
<G-vec00322-002-s077><establish.aufnehmen><en> For this purpose, the browser you are using needs to establish a connection with the Google servers.
<G-vec00322-002-s078><establish.aufnehmen><de> Egal ob Sie frühzeitig den Kontakt zu den besten Studierenden aus Aachen aufnehmen und ausgezeichnete Nachwuchskräfte fördern wollen oder einfach nur etwas zurückgeben und damit einen wesentlichen Beitrag zur Bildungsförderung an der RWTH Aachen leisten möchten – Ihr Förderengagement wird belohnt.
<G-vec00322-002-s078><establish.aufnehmen><en> Whether you want to establish contact early on with the best students in Aachen and help shape and develop outstanding young talent or simply want to "give back" and provide a crucial contribution to the RWTH Aachen Education Fund – your involvement will be rewarded.
<G-vec00322-002-s080><establish.aufnehmen><de> Den größten Einzelanteil der Millionen-Förderung – 6,4 Mio Pfund – erhält ein Bewerber, der ein BZ-Busprojekt in Aberdeen und Liverpool plant, in dessen Zuge 30 wasserstoffbetriebene Busse und eine Wasserstoff-Tankstelle ihren Dienst aufnehmen sollen.
<G-vec00322-002-s080><establish.aufnehmen><en> The biggest winner in the hydrogen competition was a fuel cell bus project, which aims to establish a hydrogen fueling station, as well as put 30 hydrogen-powered buses on the roads in Aberdeen and Liverpool (5 and 25, respectively).
<G-vec00322-002-s081><establish.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser Verbindung zu den Servern von Twitter aufnehmen.
<G-vec00322-002-s081><establish.aufnehmen><en> For such purpose, the browser you use must establish a connection to the Twitter servers.
<G-vec00322-002-s082><establish.aufnehmen><de> Sie können über Infrarot (IR) oder Bluetooth Verbindung mit anderen Geräten aufnehmen.
<G-vec00322-002-s082><establish.aufnehmen><en> You may also establish connection to the Internet wirelessly through another device using infrared (IR) or Bluetooth®.
<G-vec00322-002-s084><establish.aufnehmen><de> Dieser Aspekt drückt die Gemeinschaftsbeziehung gut aus, die Gott mit uns aufnehmen will und die wir selbst untereinander entfalten müssen.
<G-vec00322-002-s084><establish.aufnehmen><en> As such, it expresses the fellowship which God wishes to establish with us and which we ourselves must build with one another.
<G-vec00322-002-s085><establish.aufnehmen><de> Nach den hohen Kosten ihrer Ausbildung möchten viele gebildete japanische Frauen erst eine reguläre Beschäftigung aufnehmen, bevor sie Kinder haben.
<G-vec00322-002-s085><establish.aufnehmen><en> After the high cost of education, many educated Japanese women first want to establish regular employment before having children.
<G-vec00322-002-s088><establish.aufnehmen><de> Der Wert "locked" zeigt, dass Benutzer mit dieser Richtlinie keine neuen Verbindungen aufnehmen dürfen und der Wert max_connections zeigt die Anzahl der gleichzeitig zulässigen Verbindungen.
<G-vec00322-002-s088><establish.aufnehmen><en> The locked value indicates that users with the policy cannot establish new connections and the max_connections value limits the number of concurrent connections that are allowed.
<G-vec00322-002-s089><establish.aufnehmen><de> Den Dialog mit Umweltschutzgruppen und Rechtsexperten aufnehmen, um Wege zu finden, die ökologischen Ursachen der Vertreibung anzugehen.
<G-vec00322-002-s089><establish.aufnehmen><en> Establish dialogue with environmental concerns groups and legal experts to consider ways of addressing environmental causes of displacement.
<G-vec00322-002-s090><establish.aufnehmen><de> Sollten Sie uns die notwendigen Informationen und Unterlagen nicht zur Verfügung stellen, dürfen wir die von Ihnen gewünschte Geschäftsbeziehung nicht aufnehmen oder fortsetzen.
<G-vec00322-002-s090><establish.aufnehmen><en> If you fail to provide us with the necessary information and documents, we may not establish or continue the business relationship you have requested.
<G-vec00322-002-s091><establish.aufnehmen><de> Der Kunde wird ohne schriftliche Zustimmung der LSP mit Auftragnehmern der LSP weder selbst noch über Dritte während der Dauer des Vertrages, auf den diese Bedingungen Anwendung finden, und für weitere zwei Jahre nach seiner Beendigung Kontakt aufnehmen oder Verträge schließen oder vermitteln, die die vertragsgegenständlichen Leistungen oder Fabrikate, deren Weiterentwicklung und etwaige Nachfolgemodelle betreffen.
<G-vec00322-002-s091><establish.aufnehmen><en> Unless with the written consent of LSP, the customer shall not establish contact with contractors of LSP, directly or via third parties, or enter into contracts with or refer such contracts to them that relate to the performance or products constituting the subject matter of contract, their further development and follow-up models, if any, for the term of the contract to which these Terms and Conditions apply and for another two years after its end.
<G-vec00322-002-s092><establish.aufnehmen><de> Sollten Kunden uns die notwendigen Informationen und Unterlagen nicht zur Verfügung stellen, dürfen wir die Geschäftsbeziehungen nicht aufnehmen oder fortsetzen.
<G-vec00322-002-s092><establish.aufnehmen><en> If the customer does not provide us with the necessary information and documents, we will not be permitted to establish or continue the business relationship.
<G-vec00322-002-s093><establish.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser eine Verbindung zu den Servern von Google aufnehmen.
<G-vec00322-002-s093><establish.aufnehmen><en> For this purpose your browser has to establish a direct connection to Google servers.
<G-vec00322-002-s094><establish.aufnehmen><de> Dem Betrachter wird sofort klar, in welcher Weise er diesen Bildern ausgesetzt ist, wie er den Dialog aufnehmen kann.
<G-vec00322-002-s094><establish.aufnehmen><en> It is immediately clear to the viewer how the paintings present themselves, how the viewer can establish a dialogue.
<G-vec00326-002-s095><hold.aufnehmen><de> Dieses Feld soll später einen Wert aufnehmen, der die einzigartige Eigenschaft eines jeden Datensatzes ist.
<G-vec00326-002-s095><hold.aufnehmen><en> This field will later hold a value that is the unique property of each record.
<G-vec00326-002-s096><hold.aufnehmen><de> Es gibt auch ein Angestelltenapartment & ein riesiges Carport die 6 Fahrzeuge aufnehmen können.
<G-vec00326-002-s096><hold.aufnehmen><en> There is also a staff apartment & a huge carport which can hold 6 vehicles.
<G-vec00326-002-s097><hold.aufnehmen><de> Tragbare Solarzellen haben eine Größe von 1x1 und werden daher hauptsächlich in einfachen modularen Rüstungen eingesetzt, die nur ein 5x5-Raster aufweisen und die den viel leistungsfähigeren 4x4 großen tragbaren Fusionsreaktor nicht aufnehmen können.
<G-vec00326-002-s097><hold.aufnehmen><en> Portable solar panels are 1x1 in size and are therefore primarily used in modular armor, which has a 5x5 grid that cannot usefully hold a much more powerful 4x4 portable fusion reactor.
<G-vec00326-002-s098><hold.aufnehmen><de> Mit einer Tragkraft von 300 kg bis zu einer Tonne pro Palette je nach verwendeter Traverse kann unser Palettenregal bis zu 3 Tonnen palettierte Waren und 8 Tonnen pro Rahmen aufnehmen.
<G-vec00326-002-s098><hold.aufnehmen><en> Capable of bearing 300 kg to one ton per pallet depending on the beams used, our pallet rack can hold up to 3 tons of palletised goods and 8 tons per frame.
<G-vec00326-002-s099><hold.aufnehmen><de> Mutter Natur sorgt dafür, dass die Haare eine Schuppenschicht haben damit sie die richtige Menge an Feuchtigkeit aufnehmen können.
<G-vec00326-002-s099><hold.aufnehmen><en> Mother Nature wants the hair to have cuticle so that it can hold in the right amount of moisture.
<G-vec00326-002-s100><hold.aufnehmen><de> Jedes der Pfähle Tableau kann nur 1 Karte aufnehmen.
<G-vec00326-002-s100><hold.aufnehmen><en> Each of the tableau piles can only hold 1 card.
<G-vec00326-002-s101><hold.aufnehmen><de> Der Cachebehälter kann außer dem Logbuch auch kleine Travelbugs und Coins aufnehmen.
<G-vec00326-002-s101><hold.aufnehmen><en> The cache has 5 stages plus final. The Cachebox contains the logbook and can hold small travelbugs and coins.
<G-vec00326-002-s102><hold.aufnehmen><de> Wir haben der Aerotech-Jacke einige wesentliche Komponenten hinzugefügt, damit die Jacke einen Airbag aufnehmen kann.
<G-vec00326-002-s102><hold.aufnehmen><en> We added some essential elements to the Aerotech jacket so that this jacket can hold an airbag.
<G-vec00326-002-s103><hold.aufnehmen><de> Das Staufach wird an der Fahrerhausrückwand montiert und kann eine Flasche und Heftmappen aufnehmen.
<G-vec00326-002-s103><hold.aufnehmen><en> The storage box is fitted against the cab’s rear wall and can hold a bottle and binders.
<G-vec00326-002-s104><hold.aufnehmen><de> Einige speichern nur eine Art von Kryptowährung, während andere Dutzende oder Hunderte verschiedener Kryptowährungen aufnehmen können.
<G-vec00326-002-s104><hold.aufnehmen><en> Some store just one type of cryptocurrency, while others can hold dozens or hundreds of different cryptocurrencies.
<G-vec00326-002-s105><hold.aufnehmen><de> Diese Partitionen können einzelne Betriebssysteme aufnehmen.
<G-vec00326-002-s105><hold.aufnehmen><en> These partitions can be used to hold individual operating systems.
<G-vec00326-002-s106><hold.aufnehmen><de> Vermische die drei Zutaten in gleichen Mengen, indem du sie einfach in ein Glas gießt, das 100 ml aufnehmen kann.
<G-vec00326-002-s106><hold.aufnehmen><en> Mix three ingredients, equal amounts, by simply pouring into any glass that will hold 4 oz.
<G-vec00326-002-s107><hold.aufnehmen><de> Die Gondel kann bis zu 30 Personen aufnehmen.
<G-vec00326-002-s107><hold.aufnehmen><en> The basket can hold up to 30 persons.
<G-vec00326-002-s108><hold.aufnehmen><de> Dazu besteht die Maschine aus einem stabilen Grundgestell und einer Spannvorrichtung, die ganze Stämme aufnehmen kann.
<G-vec00326-002-s108><hold.aufnehmen><en> The machine is made out of a stable base and a clamping device that can hold the entire log.
<G-vec00326-002-s109><hold.aufnehmen><de> Die Netztasche im oberen Innenraum kann das drahtlose Etikett oder die Münzen aufnehmen, und das schwarze Gummiband kann Ihr Produkt festhalten.
<G-vec00326-002-s109><hold.aufnehmen><en> The mesh pocket in the top interior can hold the wireless label or coins, and black elastic band can hold your product tightly.
<G-vec00326-002-s110><hold.aufnehmen><de> Diese vertikalen Fahrradhaken können bis zu 14 kg (30 lbs) aufnehmen und können problemlos auf verschiedene Gladiator® Wandsysteme umgestellt werden.
<G-vec00326-002-s110><hold.aufnehmen><en> These vertical bike hooks can hold up to 14kg (30 lbs) and is easily relocated onto different Gladiator® Wall Systems.
<G-vec00326-002-s111><hold.aufnehmen><de> Batteriehalter ist eine kleine, separate Box, die vier Batterien der Größe sieben oder fünf aufnehmen kann.
<G-vec00326-002-s111><hold.aufnehmen><en> Battery Holder is a small, separate box that can hold four batteries of size seven or five Battery Holder.
<G-vec00326-002-s112><hold.aufnehmen><de> West Gut Ballkorb (bis 36 Bälle) Stabiler Ballbehälter, der bis zu 36 Bälle aufnehmen kann.
<G-vec00326-002-s112><hold.aufnehmen><en> West Gut Teaching Cart 36 Balls A durable and easy to use cart that can hold up to 36 tennis balls.
<G-vec00326-002-s113><hold.aufnehmen><de> Dieses Rack könnte alle Gitarren aufnehmen, einschließlich akustischer Gitarren, E-Gitarren und Bassgitarren.
<G-vec00326-002-s113><hold.aufnehmen><en> This rack would be possible to hold all guitars including acoustic guitars, electric guitars and bass guitars.
<G-vec00340-002-s057><take.aufnehmen><de> Zur Durchführung der Prüfung lieferte Atlas Copco Rental einen PNS 1250 100 % ölfreien fahrbaren dieselbetriebenen Hochdruckkompressor zusammen mit einem CD 47 Adsorptionstrockner, der bis zu 16 bar(e) Druck aufnehmen kann.
<G-vec00340-002-s057><take.aufnehmen><en> To carry out the test Atlas Copco Rental delivered a PNS1250 100% oil-free portable diesel driven high-pressure compressor together with a CD47 adsorption dryer which can take up to 16bar(e) pressure.
<G-vec00340-002-s058><take.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser Verbindung zu den Servern von Google aufnehmen.
<G-vec00340-002-s058><take.aufnehmen><en> To do this, the browser used by you must take up contact to the servers of Google.
<G-vec00340-002-s059><take.aufnehmen><de> Professor Becoming a professor ist der beste Job, den Sie aufnehmen kann mit der Hilfe von Ihrem Abschluss in Rechtswissenschaften.
<G-vec00340-002-s059><take.aufnehmen><en> Professor Becoming a professor is the best job that you can take up with the help of your law degree.
<G-vec00340-002-s060><take.aufnehmen><de> Jedes Boot kann bis zu 10 Taucher aufnehmen, so dass es ideal für große Gruppen ist.
<G-vec00340-002-s060><take.aufnehmen><en> Each boat can take up to 10 divers so it’s ideal for large groups.
<G-vec00340-002-s061><take.aufnehmen><de> Kamera-Übergabe: Wenn Sie mit Ihrem iPhone, iPad oder iPod touch ein Dokument scannen oder ein Foto aufnehmen, wird das Ergebnis sofort auf Ihrem Mac angezeigt.
<G-vec00340-002-s061><take.aufnehmen><en> Continuity Camera: Use your iPhone, iPad, or iPod touch to scan documents or take a picture and it appears instantly on your Mac.
<G-vec00340-002-s062><take.aufnehmen><de> Da die starken Vibrationen beim offroad fahren im Grenzgebiet zwischen Italien und Frankreich meine Videokamera zerstört hatten, entschied ich mich dieses Mal dazu meine Kamera so am Helm zu befestigen, dass ich während der Fahrt ruckelfreie Videos aufnehmen und gleichzeitig den Bildschirm der Kamera im Auge behalten kann.
<G-vec00340-002-s062><take.aufnehmen><en> Since the strong vibrations of my motorbike had damaged my video camera during my last off-road trip, this time I decided to attach my camera directly to my helmet, so I could take smooth videos and watch the screen while riding. A GoPro would have been too expensive.
<G-vec00340-002-s063><take.aufnehmen><de> Wenn jemand nur dann zu uns kommt, wenn er etwas braucht - also egoistisch und selbstsüchtig ist - dann werden wir sicherlich nicht leicht mit ihm eine Freundschaft aufnehmen und in Freundschaft leben.
<G-vec00340-002-s063><take.aufnehmen><en> If someone only comes to us when he needs something - when he is egotistical and selfish - then we shall certainly not easily take up a friendship with him and live in friendship.
<G-vec00340-002-s064><take.aufnehmen><de> • Aufnehmen eines Bilds.
<G-vec00340-002-s064><take.aufnehmen><en> • Take a picture.
<G-vec00340-002-s065><take.aufnehmen><de> Saubermacher stellt Ihnen für die Sammlung Behälter zur Verfügung und kümmert sich um die regelmäßige Abholung Ihres Altglases durch Spezialfahrzeuge, die im Rahmen einer Abholung sowohl Bunt- als auch Weißglas in zwei voneinander getrennten Kammern aufnehmen können.
<G-vec00340-002-s065><take.aufnehmen><en> Saubermacher provides you with collection receptacles and then hauls the pooled glass away at regular intervals using special vehicles which are able to take both coloured and clear glass in a single collection operation in two independent chambers.
<G-vec00340-002-s066><take.aufnehmen><de> Da das iPhone qualitativ hochwertige Fotos aufnehmen kann und immer dabei ist, nimmt es inzwischen den Platz der meisten Digitalkameras ein.
<G-vec00340-002-s066><take.aufnehmen><en> As iPhone can take high-quality photos and is easy to carry which almost takes place of the common digital cameras.
<G-vec00340-002-s067><take.aufnehmen><de> Mir fallen einige Leute ein, die mich jederzeit aufnehmen würden.
<G-vec00340-002-s067><take.aufnehmen><en> There are a few people who will take me in at any time.
<G-vec00340-002-s068><take.aufnehmen><de> Aber dort wollte man sie als Deutsche nicht aufnehmen.
<G-vec00340-002-s068><take.aufnehmen><en> But then they did not want to take her because she was German.
<G-vec00340-002-s069><take.aufnehmen><de> Zarte schlauchförmige Organe, welche die Eizelle aufnehmen und in denen die Befruchtung stattfindet; zuständig für den weiteren Transport der befruchteten Eizelle in die Gebärmutter.
<G-vec00340-002-s069><take.aufnehmen><en> Gentle and tube shaped organs that take the egg cell and where the impregnation takes place; responsible for the further transport of the fertilized egg cell into the uterus.
<G-vec00340-002-s070><take.aufnehmen><de> Mit Firefox Screenshots können Sie Bildschirmfotos mit nur einem Klick auf eine Schaltfläche aufnehmen, herunterladen und teilen.
<G-vec00340-002-s070><take.aufnehmen><en> You can use the Firefox Screenshots feature to take, download and share screenshots with just a click of a button.
<G-vec00340-002-s071><take.aufnehmen><de> Mit der App iXpand Drive können Sie Fotos und Videos verwalten, Videos direkt auf dem Laufwerk ansehen und sogar Videos mit der App aufnehmen, um sie direkt auf dem Laufwerk zu speichern.
<G-vec00340-002-s071><take.aufnehmen><en> The iXpand Drive app makes it easy to manage photos and videos, watch videos directly from the drive, and even take videos from the app and save them directly onto the drive.
<G-vec00340-002-s072><take.aufnehmen><de> Normalerweise können Sie Ihre gewohnte Arbeit nach 1-3 Tagen wieder aufnehmen oder Ihren täglichen Beschäftigungen nachgehen.
<G-vec00340-002-s072><take.aufnehmen><en> You can normally take up your work or pursue your normal daily activities again after 1-3 days.
<G-vec00340-002-s073><take.aufnehmen><de> Bevor Sie mit der Aufnahme beginnen, klicken Sie auf Schnappschuss aufnehmen.
<G-vec00340-002-s073><take.aufnehmen><en> Before you start recording, click Take my snapshot now.
<G-vec00340-002-s074><take.aufnehmen><de> e) das Spiel spielen und einen Screenshot („Bild“) aufnehmen und eine Antwort im Thread posten, die das Bild enthält.
<G-vec00340-002-s074><take.aufnehmen><en> e) play the game and take a screenshot (“Image”) and post a reply by uploading their Image to the Thread.
<G-vec00340-002-s075><take.aufnehmen><de> Makroobjektiv kann klare Fotos von kleinen Objekten aufnehmen.
<G-vec00340-002-s075><take.aufnehmen><en> Macro lens can take clear photos of small objects
<G-vec00365-002-s131><shoot.aufnehmen><de> Heutzutage haben Sie mit den meisten Digitalkameras die Option, in 16:9 aufzunehmen.
<G-vec00365-002-s131><shoot.aufnehmen><en> Today, most digital cameras will give you the option to shoot in 16:9.
<G-vec00365-002-s132><shoot.aufnehmen><de> ● Höhenstand halten Aktivieren Sie diesen Modus, wenn Sie eine bestimmte Höhe beibehalten möchten, um klare Fotos aufzunehmen.
<G-vec00365-002-s132><shoot.aufnehmen><en> Turn on this mode when you want it to maintain at a certain height to shoot clear photos.
<G-vec00365-002-s133><shoot.aufnehmen><de> Sie können Ihren Kopf bewegen und die Taste auf den Sitzen drücken, um das Ziel in den Filmen aufzunehmen.
<G-vec00365-002-s133><shoot.aufnehmen><en> You can move your head and press the button on the seats to shoot the target in the movies.
<G-vec00365-002-s134><shoot.aufnehmen><de> Kompatibilitäts Beschreibung Diese Integral UltimaPro SDHC Class 10 Speicherkarte verfügt über eine Übertragungsgeschwindigkeit von bis zu 80MB/s und ist somit die perfekte Lösung um hochauflösende Bilder zu erfassen und Full HD-Videos aufzunehmen.
<G-vec00365-002-s134><shoot.aufnehmen><en> Memory cards with Class 10 specification perform at up to 40MB/s transfer speed and are designed to be used where fast memory cards are crucial to capture high-resolution images and to shoot Full HD video.
<G-vec00365-002-s135><shoot.aufnehmen><de> So macht es keinerlei Sinn menschliche Bewegungen mit viel mehr als 1 000 Bilder/sek (oder gar 100 000 Bilder/sek) aufzunehmen.
<G-vec00365-002-s135><shoot.aufnehmen><en> So it definitely makes no sense to shoot human movement with much more than 1 000 frames/sec (or even 100 000 frames/sec).
<G-vec00365-002-s136><shoot.aufnehmen><de> Ja, es besteht die Versuchung, Bilder in so vielen Einstellungen wie möglich aufzunehmen.
<G-vec00365-002-s136><shoot.aufnehmen><en> Yes, there is that temptation to shoot pictures in as many settings as possible.
<G-vec00365-002-s137><shoot.aufnehmen><de> Aktivieren Sie diesen Schalter, um nur die Anzahl Bilder aufzunehmen, die wirklich notwendig ist.
<G-vec00365-002-s137><shoot.aufnehmen><en> Activate this switch to shoot only as many pictures as really needed.
<G-vec00365-002-s138><shoot.aufnehmen><de> Die unglaubliche Rechenpower ermöglicht, 4K Video mit erweitertem Dynamikbereich und Cinematic Videostabilisierung aufzunehmen – alles mit 60 fps.
<G-vec00365-002-s138><shoot.aufnehmen><en> Epic processing power means it can shoot 4K video with extended dynamic range and cinematic video stabilisation — all at 60 fps.
<G-vec00365-002-s139><shoot.aufnehmen><de> Halten Sie den Finger auf dem Bildschirm, um kontinuierlich Fotos aufzunehmen.
<G-vec00365-002-s139><shoot.aufnehmen><en> Hold your finger down to shoot photos continuously.
<G-vec00365-002-s140><shoot.aufnehmen><de> Auch darauf hat der Kirin 980 eine Antwort: Er verwendet eine neue Pipeline für die Verarbeitung von Videoaufnahmen, die es dem Kameramodul ermöglicht, Videos mit einer um 33 Prozent kürzeren Verzögerung aufzunehmen.
<G-vec00365-002-s140><shoot.aufnehmen><en> Kirin 980 adopts a new pipeline dedicated to processing video captures, allowing the camera module to shoot videos with 33 percent shorter delay. World-Class Connectivity
<G-vec00365-002-s141><shoot.aufnehmen><de> Wenn Sie ein Foto mit starkem Gegenlicht hinter dem Motiv aufnehmen, passt die Kamera die Belichtung an, um das Motiv richtig aufzunehmen.
<G-vec00365-002-s141><shoot.aufnehmen><en> When you take a photo in conditions where there is a strong backlight behind a subject, the camera adjusts the exposure so as to shoot a subject correctly.
<G-vec00365-002-s142><shoot.aufnehmen><de> Mit der stark beeindruckenden Leistung von Kingstons UHS-I Elite Karte Klasse 10 macht es einfach mehr Spa├»┬┐┬Ż, schnelle Action-Fotos und HD-Videos aufzunehmen.>Highlights- Beeindruckende UHS-I Gesc...
<G-vec00365-002-s142><shoot.aufnehmen><en> Manufacturer: Kingston Technology. Each. Kingston's Class 10 UHS-I Elite card features impressive performance that lets users shoot fast-action photos and HD video with higher sustained write speeds t...
<G-vec00365-002-s143><shoot.aufnehmen><de> Die Kamera würde mir helfen, die Geschichte aufzunehmen, weil sie so klein und einfach zu bedienen ist.
<G-vec00365-002-s143><shoot.aufnehmen><en> The camera would help me shoot the story because it’s small and easy to work with.
<G-vec00366-002-s088><encompass.aufnehmen><de> Der eine erfasste diesen Punkt, der andere jenen, aber keiner war imstande, das Ganze seines Unterrichts aufzunehmen.
<G-vec00366-002-s088><encompass.aufnehmen><en> One would grasp one point and one would comprehend another, but none of them could encompass the whole of his teaching.
<G-vec00366-002-s049><incorporate.aufnehmen><de> 100% stimmten zu, dass sie dieses Produkt in ihre tägliche Hautpflege aufnehmen würden.
<G-vec00366-002-s049><incorporate.aufnehmen><en> 100% agreed they would incorporate this product into their daily skin care routine.
<G-vec00366-002-s050><incorporate.aufnehmen><de> Sie erklären sich damit einverstanden, die KAndySoft UG und unsere Muttergesellschaft, Tochtergesellschaften, verbundene Unternehmen, Partner, Führungskräfte, Direktoren, Vertreter, Auftragnehmer, Lizenzgeber, Dienstleister, Subunternehmer, Zulieferer, Lieferanten, Praktikanten und Mitarbeiter schadlos zu halten und schadlos zu halten von jeglichen Ansprüchen oder Forderungen, einschließlich angemessener Anwaltsgebühren, die von Dritten aufgrund Ihrer Verletzung dieser Nutzungsbedingungen oder der Dokumente, die sie durch Verweis aufnehmen, oder Ihrer Verletzung eines Gesetzes oder der Rechte eines Dritten gestellt werden.
<G-vec00366-002-s050><incorporate.aufnehmen><en> You agree to indemnify, defend and hold harmless Game Day Ready and our parent, subsidiaries, affiliates, partners, officers, directors, agents, contractors, licensors, service providers, subcontractors, suppliers, interns and employees, harmless from any claim or demand, including reasonable attorneys’ fees, made by any third-party due to or arising out of your breach of these Terms of Service or the documents they incorporate by reference, or your violation of any law or the rights of a third-party.
<G-vec00366-002-s051><incorporate.aufnehmen><de> Die folgenden Storyboard-Aktivitäten sollen dieses Gerüst für die spanische Negation in diesen kostenlosen Spanischunterricht aufnehmen.
<G-vec00366-002-s051><incorporate.aufnehmen><en> The following storyboard activities are designed to incorporate this scaffolding for Spanish negation in these free Spanish lessons.
<G-vec00366-002-s052><incorporate.aufnehmen><de> Trader sollten eine zusätzliche Analyse in ihr Repertoire aufnehmen, um den Auswirkungen einer schief gelaufenen Wende zu entgehen; eine einfache Doji-Formation allein reicht nicht aus, um eine Wende zu traden.
<G-vec00366-002-s052><incorporate.aufnehmen><en> Traders want to look to incorporate additional analysis into their repertoire to avoid the effects of reversals gone awry; a simple doji formation is not enough alone to trade a reversal.
<G-vec00366-002-s053><incorporate.aufnehmen><de> Das liegt zum Teil auch daran, dass globale Indexanbieter chinesische Anleihen in ihre großen internationalen Anleihen-Benchmarks aufnehmen.
<G-vec00366-002-s053><incorporate.aufnehmen><en> This was partly in anticipation of moves by global index providers to incorporate Chinese bonds in their mainstream international bond benchmarks.
<G-vec00366-002-s054><incorporate.aufnehmen><de> 2 Untersteht der Genehmigungsbeschluss eines völkerrechtlichen Vertrags dem fakultativen Referendum, so kann die Bundesversammlung die Gesetzesänderungen, die der Umsetzung des Vertrages dienen, in den Genehmigungsbeschluss aufnehmen.
<G-vec00366-002-s054><incorporate.aufnehmen><en> 2 If the decision on ratification of an international treaty is subject to an optional referendum, the Federal Assembly may incorporate in the decision on ratification the amendments to the law that provide for the implementation of the treaty.
<G-vec00366-002-s055><incorporate.aufnehmen><de> Du kannst Symbole oder Figuren aus dem Buch oder Gedicht aufnehmen, um die es in dem Projekt geht.
<G-vec00366-002-s055><incorporate.aufnehmen><en> You can incorporate symbols or characters from the book or poem the project is about.
<G-vec00366-002-s056><incorporate.aufnehmen><de> Ebenso wenig sollte man sich bei der Suchmaschinenoptimierung nur auf eine Suchmaschine, wie etwa Google, konzentrieren, sondern auch andere Suchanbieter und -Dienste in die Strategie aufnehmen.
<G-vec00366-002-s056><incorporate.aufnehmen><en> Additionally, your SEO strategy should not focus exclusively on only one search engine (e.g. Google) but must also incorporate other search engines and services in its strategy.
<G-vec00366-002-s057><incorporate.aufnehmen><de> Daher sind wir stets auf der Suche nach Handelsprodukten, die wir in unsere Vertriebs- und Servicestrukturen aufnehmen können.
<G-vec00366-002-s057><incorporate.aufnehmen><en> For this reason we are always looking for trade products that we can incorporate in our sales and service structures.
<G-vec00366-002-s058><incorporate.aufnehmen><de> Auch wenn Kurkuma in roher Form manchmal ein wenig bitter und unangenehm schmecken kann, gibt es viele Möglichkeiten, wie du dieses kraftvolle Antioxidationsmittel in deine tägliche Ernährung und Gesundheitsroutine aufnehmen kannst.
<G-vec00366-002-s058><incorporate.aufnehmen><en> Although turmeric can be somewhat bitter and unpalatable in its raw form, there are many ways you can incorporate this powerful antioxidant into your daily diet and healthcare routine.
<G-vec00366-002-s060><incorporate.aufnehmen><de> Wenn Sie externe Geräte über MIDI aufnehmen müssen, bietet Helix Rack immer mehr Flexibilität als jede Multi-Effekt.
<G-vec00366-002-s060><incorporate.aufnehmen><en> When you need to incorporate external devices via MIDI, Helix Rack offers more flexibility than any multi-effect ever.
<G-vec00366-002-s061><incorporate.aufnehmen><de> Die Produkttypen B8 und B12 herrschen weiter stark vor, aber es ist doch offensichtlich, dass unter den neuen Produkten, die die Hersteller in ihren Katalog aufnehmen möchten, vor allem der Typ B4 und die Hourdis immer stärker vertreten sind.
<G-vec00366-002-s061><incorporate.aufnehmen><en> Although it is clear that among the new products that ceramists try to incorporate into their catalog, both the B4 and ceiling bricks are proliferating with a growing presence. No Comments Post A Comment Cancel Reply
<G-vec00366-002-s062><incorporate.aufnehmen><de> Sie müssen an gut wahrnehmbarer Stelle einen Hinweis aufnehmen, der genau angibt wie die Arbeit aus einer anderen Arbeit abgeleitet wird.
<G-vec00366-002-s062><incorporate.aufnehmen><en> Designer Credit Notification You must incorporate a prominent notice stating exactly how the work is derived from another work.
<G-vec00380-002-s044><discard.aufnehmen><de> Der Spieler, der dabei am langsamsten ist, muss alle Karten aus dem Ablagestapel aufnehmen und seinem Blatt hinzufügen.
<G-vec00380-002-s044><discard.aufnehmen><en> The slowest player to do so needs to pick up all cards from the discard pile and add them to his hand.
<G-vec00380-002-s045><discard.aufnehmen><de> In dieser Situation muss ein Spieler den Ablagestapel aufnehmen, wenn er nicht blockiert oder gesperrt ist und wenn die abgelegte Karte zu einer vorherigen Auslage der Partnerschaft dieses Spielers passt.
<G-vec00380-002-s045><discard.aufnehmen><en> In this situation a player must take the discard if the pile is not frozen and if the discard matches any of that player's melds.
<G-vec00380-002-s075><dispense.aufnehmen><de> Dadurch kann jeder Kanal 18 zur einer getrennten Kapillare werden, die Flüssigkeit unabhängig von den anderen Kanälen 18 im Reservoir 12 aufnimmt, speichert und abgibt.
<G-vec00380-002-s075><dispense.aufnehmen><en> Therefore, each channel 18 can become a discrete capillary that can acquire, store, and dispense liquid in a manner independent of the other channels 18 in the reservoir 12.
<G-vec00402-002-s026><conceive.aufnehmen><de> Nur einer von vielen Typen von Gedankenprozessen in eurem Verstand kann Dinge in einer linearen Weise aufnehmen.
<G-vec00402-002-s026><conceive.aufnehmen><en> Only one of many types of thought processes within your minds can conceive of things in a linear manner.
<G-vec00476-002-s401><absorb.aufnehmen><de> Wo an Strassen das Chlorid-Angebot gross ist, nehmen die Bäume auch mehr davon auf.
<G-vec00476-002-s401><absorb.aufnehmen><en> Where there is a large supply of chloride in a roadside location, the trees absorb more of it.
<G-vec00476-002-s402><absorb.aufnehmen><de> Sie nehmen den göttlichen Geist in sich auf.
<G-vec00476-002-s402><absorb.aufnehmen><en> You absorb the divine spirit.
<G-vec00476-002-s403><absorb.aufnehmen><de> Erfahren Sie mehr über die Geschichte Perus und der Inkas von Ihrem informativen Guide und nehmen Sie während Ihres 8-tägigen Abenteuers die lokale Kultur auf.
<G-vec00476-002-s403><absorb.aufnehmen><en> Learn about the history of Peru and the Incas from your informative guide and absorb the local culture during your 8-day adventure.
<G-vec00476-002-s404><absorb.aufnehmen><de> Zusätzlich nehmen Saugeinlagen in eingenähten Taschen den Schweiss auf.
<G-vec00476-002-s404><absorb.aufnehmen><en> the absorption pads in the integrated pockets absorb the sweat
<G-vec00476-002-s038><consume.aufnehmen><de> Aminosäuren Aminosäuren sind die Bausteine der Eiweiße, die wir über die Nahrung täglich aufnehmen müssen, damit unser Körper optimal funktioniert.
<G-vec00476-002-s038><consume.aufnehmen><en> Amino acids are the building blocks of the proteins we have to consume every day through food in order for our bodies to function well.
<G-vec00476-002-s040><consume.aufnehmen><de> Die akzeptable tägliche Aufnahmemenge ist ein toxikologischer Referenzwert, der angibt, wie viel Glyphosat wir täglich (unser Leben lang) mit der Nahrung aufnehmen dürfen, ohne dass dies Auswirkungen auf unseren Körper hat.
<G-vec00476-002-s040><consume.aufnehmen><en> The ADI is a toxicological reference value that indicates how much glyphosate we can consume daily (for our entire lives) with food, without any effect on our body.
<G-vec00476-002-s041><consume.aufnehmen><de> Es hilft sicher zu berechnen, wie viele Kalorien du aufnehmen darfst, damit du abnimmst.
<G-vec00476-002-s041><consume.aufnehmen><en> It may help to calculate how many calories you need to consume to lose weight before you get started.
<G-vec00476-002-s042><consume.aufnehmen><de> Die Obstbeutel schmecken mir wirklich gut und ich kann gleichzeitig die für mich optimale Menge an Kohlenhydraten aufnehmen.
<G-vec00476-002-s042><consume.aufnehmen><en> I really like the taste of these fruit pouches, and at the same time it allows me to consume the optimal amount of carbohydrates for my needs.
<G-vec00476-002-s043><consume.aufnehmen><de> Die Temperatur der Speise oder des Wassers das Sie aufnehmen ist nicht ausschlaggebend für das Anhaengen der Gedanken, da Sie nur mit dem Akasha arbeiten.
<G-vec00476-002-s043><consume.aufnehmen><en> The temperature of the food or water you consume is not a factor in regard to the impression of a thought since it is only the Akasha you are working with.
<G-vec00476-002-s044><consume.aufnehmen><de> Ölkuchen kann aufgrund seiner Eigenschaften enorme gesundheitliche Vorteile mit sich bringen, so dass er auch geringe Mengen an Allergien aufnehmen kann.
<G-vec00476-002-s044><consume.aufnehmen><en> Due to its properties, oilcake can bring tremendous health benefits, as a result of which it can consume even moderate amounts of allergies.
<G-vec00476-002-s045><consume.aufnehmen><de> Wenn du durstig bist, kannst du nur eine begrenzte Menge an Wasser aufnehmen.
<G-vec00476-002-s045><consume.aufnehmen><en> When you are thirsty; you can consume only a limited quantity of water.
<G-vec00476-002-s045><soak_up.aufnehmen><de> Er tut, was er kann, um so viel Sonnenlicht wie möglich aufzunehmen und die Photosynthese anzuregen, bei der das Licht in chemische Energie umgewandelt wird, in den „Brennstoff“, den fast jeder lebende Organismus braucht.
<G-vec00476-002-s045><soak_up.aufnehmen><en> They will do all in their power to soak in as much sunlight as possible to promote photosynthesis—the process of converting light energy into chemical energy, or the “fuel” used by almost all living organisms.
<G-vec00476-002-s057><take_in.aufnehmen><de> Zur Durchführung der Prüfung lieferte Atlas Copco Rental einen PNS 1250 100 % ölfreien fahrbaren dieselbetriebenen Hochdruckkompressor zusammen mit einem CD 47 Adsorptionstrockner, der bis zu 16 bar(e) Druck aufnehmen kann.
<G-vec00476-002-s057><take_in.aufnehmen><en> To carry out the test Atlas Copco Rental delivered a PNS1250 100% oil-free portable diesel driven high-pressure compressor together with a CD47 adsorption dryer which can take up to 16bar(e) pressure.
<G-vec00476-002-s058><take_in.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser Verbindung zu den Servern von Google aufnehmen.
<G-vec00476-002-s058><take_in.aufnehmen><en> To do this, the browser used by you must take up contact to the servers of Google.
<G-vec00476-002-s059><take_in.aufnehmen><de> Professor Becoming a professor ist der beste Job, den Sie aufnehmen kann mit der Hilfe von Ihrem Abschluss in Rechtswissenschaften.
<G-vec00476-002-s059><take_in.aufnehmen><en> Professor Becoming a professor is the best job that you can take up with the help of your law degree.
<G-vec00476-002-s060><take_in.aufnehmen><de> Jedes Boot kann bis zu 10 Taucher aufnehmen, so dass es ideal für große Gruppen ist.
<G-vec00476-002-s060><take_in.aufnehmen><en> Each boat can take up to 10 divers so it’s ideal for large groups.
<G-vec00476-002-s061><take_in.aufnehmen><de> Kamera-Übergabe: Wenn Sie mit Ihrem iPhone, iPad oder iPod touch ein Dokument scannen oder ein Foto aufnehmen, wird das Ergebnis sofort auf Ihrem Mac angezeigt.
<G-vec00476-002-s061><take_in.aufnehmen><en> Continuity Camera: Use your iPhone, iPad, or iPod touch to scan documents or take a picture and it appears instantly on your Mac.
<G-vec00476-002-s062><take_in.aufnehmen><de> Da die starken Vibrationen beim offroad fahren im Grenzgebiet zwischen Italien und Frankreich meine Videokamera zerstört hatten, entschied ich mich dieses Mal dazu meine Kamera so am Helm zu befestigen, dass ich während der Fahrt ruckelfreie Videos aufnehmen und gleichzeitig den Bildschirm der Kamera im Auge behalten kann.
<G-vec00476-002-s062><take_in.aufnehmen><en> Since the strong vibrations of my motorbike had damaged my video camera during my last off-road trip, this time I decided to attach my camera directly to my helmet, so I could take smooth videos and watch the screen while riding. A GoPro would have been too expensive.
<G-vec00476-002-s063><take_in.aufnehmen><de> Wenn jemand nur dann zu uns kommt, wenn er etwas braucht - also egoistisch und selbstsüchtig ist - dann werden wir sicherlich nicht leicht mit ihm eine Freundschaft aufnehmen und in Freundschaft leben.
<G-vec00476-002-s063><take_in.aufnehmen><en> If someone only comes to us when he needs something - when he is egotistical and selfish - then we shall certainly not easily take up a friendship with him and live in friendship.
<G-vec00476-002-s064><take_in.aufnehmen><de> • Aufnehmen eines Bilds.
<G-vec00476-002-s064><take_in.aufnehmen><en> • Take a picture.
<G-vec00476-002-s065><take_in.aufnehmen><de> Saubermacher stellt Ihnen für die Sammlung Behälter zur Verfügung und kümmert sich um die regelmäßige Abholung Ihres Altglases durch Spezialfahrzeuge, die im Rahmen einer Abholung sowohl Bunt- als auch Weißglas in zwei voneinander getrennten Kammern aufnehmen können.
<G-vec00476-002-s065><take_in.aufnehmen><en> Saubermacher provides you with collection receptacles and then hauls the pooled glass away at regular intervals using special vehicles which are able to take both coloured and clear glass in a single collection operation in two independent chambers.
<G-vec00476-002-s066><take_in.aufnehmen><de> Da das iPhone qualitativ hochwertige Fotos aufnehmen kann und immer dabei ist, nimmt es inzwischen den Platz der meisten Digitalkameras ein.
<G-vec00476-002-s066><take_in.aufnehmen><en> As iPhone can take high-quality photos and is easy to carry which almost takes place of the common digital cameras.
<G-vec00476-002-s067><take_in.aufnehmen><de> Mir fallen einige Leute ein, die mich jederzeit aufnehmen würden.
<G-vec00476-002-s067><take_in.aufnehmen><en> There are a few people who will take me in at any time.
<G-vec00476-002-s068><take_in.aufnehmen><de> Aber dort wollte man sie als Deutsche nicht aufnehmen.
<G-vec00476-002-s068><take_in.aufnehmen><en> But then they did not want to take her because she was German.
<G-vec00476-002-s069><take_in.aufnehmen><de> Zarte schlauchförmige Organe, welche die Eizelle aufnehmen und in denen die Befruchtung stattfindet; zuständig für den weiteren Transport der befruchteten Eizelle in die Gebärmutter.
<G-vec00476-002-s069><take_in.aufnehmen><en> Gentle and tube shaped organs that take the egg cell and where the impregnation takes place; responsible for the further transport of the fertilized egg cell into the uterus.
<G-vec00476-002-s070><take_in.aufnehmen><de> Mit Firefox Screenshots können Sie Bildschirmfotos mit nur einem Klick auf eine Schaltfläche aufnehmen, herunterladen und teilen.
<G-vec00476-002-s070><take_in.aufnehmen><en> You can use the Firefox Screenshots feature to take, download and share screenshots with just a click of a button.
<G-vec00476-002-s071><take_in.aufnehmen><de> Mit der App iXpand Drive können Sie Fotos und Videos verwalten, Videos direkt auf dem Laufwerk ansehen und sogar Videos mit der App aufnehmen, um sie direkt auf dem Laufwerk zu speichern.
<G-vec00476-002-s071><take_in.aufnehmen><en> The iXpand Drive app makes it easy to manage photos and videos, watch videos directly from the drive, and even take videos from the app and save them directly onto the drive.
<G-vec00476-002-s072><take_in.aufnehmen><de> Normalerweise können Sie Ihre gewohnte Arbeit nach 1-3 Tagen wieder aufnehmen oder Ihren täglichen Beschäftigungen nachgehen.
<G-vec00476-002-s072><take_in.aufnehmen><en> You can normally take up your work or pursue your normal daily activities again after 1-3 days.
<G-vec00476-002-s073><take_in.aufnehmen><de> Bevor Sie mit der Aufnahme beginnen, klicken Sie auf Schnappschuss aufnehmen.
<G-vec00476-002-s073><take_in.aufnehmen><en> Before you start recording, click Take my snapshot now.
<G-vec00476-002-s074><take_in.aufnehmen><de> e) das Spiel spielen und einen Screenshot („Bild“) aufnehmen und eine Antwort im Thread posten, die das Bild enthält.
<G-vec00476-002-s074><take_in.aufnehmen><en> e) play the game and take a screenshot (“Image”) and post a reply by uploading their Image to the Thread.
<G-vec00476-002-s075><take_in.aufnehmen><de> Makroobjektiv kann klare Fotos von kleinen Objekten aufnehmen.
<G-vec00476-002-s075><take_in.aufnehmen><en> Macro lens can take clear photos of small objects
<G-vec00486-002-s095><hold_off.aufnehmen><de> Dieses Feld soll später einen Wert aufnehmen, der die einzigartige Eigenschaft eines jeden Datensatzes ist.
<G-vec00486-002-s095><hold_off.aufnehmen><en> This field will later hold a value that is the unique property of each record.
<G-vec00486-002-s096><hold_off.aufnehmen><de> Es gibt auch ein Angestelltenapartment & ein riesiges Carport die 6 Fahrzeuge aufnehmen können.
<G-vec00486-002-s096><hold_off.aufnehmen><en> There is also a staff apartment & a huge carport which can hold 6 vehicles.
<G-vec00486-002-s097><hold_off.aufnehmen><de> Tragbare Solarzellen haben eine Größe von 1x1 und werden daher hauptsächlich in einfachen modularen Rüstungen eingesetzt, die nur ein 5x5-Raster aufweisen und die den viel leistungsfähigeren 4x4 großen tragbaren Fusionsreaktor nicht aufnehmen können.
<G-vec00486-002-s097><hold_off.aufnehmen><en> Portable solar panels are 1x1 in size and are therefore primarily used in modular armor, which has a 5x5 grid that cannot usefully hold a much more powerful 4x4 portable fusion reactor.
<G-vec00486-002-s098><hold_off.aufnehmen><de> Mit einer Tragkraft von 300 kg bis zu einer Tonne pro Palette je nach verwendeter Traverse kann unser Palettenregal bis zu 3 Tonnen palettierte Waren und 8 Tonnen pro Rahmen aufnehmen.
<G-vec00486-002-s098><hold_off.aufnehmen><en> Capable of bearing 300 kg to one ton per pallet depending on the beams used, our pallet rack can hold up to 3 tons of palletised goods and 8 tons per frame.
<G-vec00486-002-s099><hold_off.aufnehmen><de> Mutter Natur sorgt dafür, dass die Haare eine Schuppenschicht haben damit sie die richtige Menge an Feuchtigkeit aufnehmen können.
<G-vec00486-002-s099><hold_off.aufnehmen><en> Mother Nature wants the hair to have cuticle so that it can hold in the right amount of moisture.
<G-vec00486-002-s100><hold_off.aufnehmen><de> Jedes der Pfähle Tableau kann nur 1 Karte aufnehmen.
<G-vec00486-002-s100><hold_off.aufnehmen><en> Each of the tableau piles can only hold 1 card.
<G-vec00486-002-s101><hold_off.aufnehmen><de> Der Cachebehälter kann außer dem Logbuch auch kleine Travelbugs und Coins aufnehmen.
<G-vec00486-002-s101><hold_off.aufnehmen><en> The cache has 5 stages plus final. The Cachebox contains the logbook and can hold small travelbugs and coins.
<G-vec00486-002-s102><hold_off.aufnehmen><de> Wir haben der Aerotech-Jacke einige wesentliche Komponenten hinzugefügt, damit die Jacke einen Airbag aufnehmen kann.
<G-vec00486-002-s102><hold_off.aufnehmen><en> We added some essential elements to the Aerotech jacket so that this jacket can hold an airbag.
<G-vec00486-002-s103><hold_off.aufnehmen><de> Das Staufach wird an der Fahrerhausrückwand montiert und kann eine Flasche und Heftmappen aufnehmen.
<G-vec00486-002-s103><hold_off.aufnehmen><en> The storage box is fitted against the cab’s rear wall and can hold a bottle and binders.
<G-vec00486-002-s104><hold_off.aufnehmen><de> Einige speichern nur eine Art von Kryptowährung, während andere Dutzende oder Hunderte verschiedener Kryptowährungen aufnehmen können.
<G-vec00486-002-s104><hold_off.aufnehmen><en> Some store just one type of cryptocurrency, while others can hold dozens or hundreds of different cryptocurrencies.
<G-vec00486-002-s105><hold_off.aufnehmen><de> Diese Partitionen können einzelne Betriebssysteme aufnehmen.
<G-vec00486-002-s105><hold_off.aufnehmen><en> These partitions can be used to hold individual operating systems.
<G-vec00486-002-s106><hold_off.aufnehmen><de> Vermische die drei Zutaten in gleichen Mengen, indem du sie einfach in ein Glas gießt, das 100 ml aufnehmen kann.
<G-vec00486-002-s106><hold_off.aufnehmen><en> Mix three ingredients, equal amounts, by simply pouring into any glass that will hold 4 oz.
<G-vec00486-002-s107><hold_off.aufnehmen><de> Die Gondel kann bis zu 30 Personen aufnehmen.
<G-vec00486-002-s107><hold_off.aufnehmen><en> The basket can hold up to 30 persons.
<G-vec00486-002-s108><hold_off.aufnehmen><de> Dazu besteht die Maschine aus einem stabilen Grundgestell und einer Spannvorrichtung, die ganze Stämme aufnehmen kann.
<G-vec00486-002-s108><hold_off.aufnehmen><en> The machine is made out of a stable base and a clamping device that can hold the entire log.
<G-vec00486-002-s109><hold_off.aufnehmen><de> Die Netztasche im oberen Innenraum kann das drahtlose Etikett oder die Münzen aufnehmen, und das schwarze Gummiband kann Ihr Produkt festhalten.
<G-vec00486-002-s109><hold_off.aufnehmen><en> The mesh pocket in the top interior can hold the wireless label or coins, and black elastic band can hold your product tightly.
<G-vec00486-002-s110><hold_off.aufnehmen><de> Diese vertikalen Fahrradhaken können bis zu 14 kg (30 lbs) aufnehmen und können problemlos auf verschiedene Gladiator® Wandsysteme umgestellt werden.
<G-vec00486-002-s110><hold_off.aufnehmen><en> These vertical bike hooks can hold up to 14kg (30 lbs) and is easily relocated onto different Gladiator® Wall Systems.
<G-vec00486-002-s111><hold_off.aufnehmen><de> Batteriehalter ist eine kleine, separate Box, die vier Batterien der Größe sieben oder fünf aufnehmen kann.
<G-vec00486-002-s111><hold_off.aufnehmen><en> Battery Holder is a small, separate box that can hold four batteries of size seven or five Battery Holder.
<G-vec00486-002-s112><hold_off.aufnehmen><de> West Gut Ballkorb (bis 36 Bälle) Stabiler Ballbehälter, der bis zu 36 Bälle aufnehmen kann.
<G-vec00486-002-s112><hold_off.aufnehmen><en> West Gut Teaching Cart 36 Balls A durable and easy to use cart that can hold up to 36 tennis balls.
<G-vec00486-002-s113><hold_off.aufnehmen><de> Dieses Rack könnte alle Gitarren aufnehmen, einschließlich akustischer Gitarren, E-Gitarren und Bassgitarren.
<G-vec00486-002-s113><hold_off.aufnehmen><en> This rack would be possible to hold all guitars including acoustic guitars, electric guitars and bass guitars.
<G-vec00487-002-s057><take_out.aufnehmen><de> Zur Durchführung der Prüfung lieferte Atlas Copco Rental einen PNS 1250 100 % ölfreien fahrbaren dieselbetriebenen Hochdruckkompressor zusammen mit einem CD 47 Adsorptionstrockner, der bis zu 16 bar(e) Druck aufnehmen kann.
<G-vec00487-002-s057><take_out.aufnehmen><en> To carry out the test Atlas Copco Rental delivered a PNS1250 100% oil-free portable diesel driven high-pressure compressor together with a CD47 adsorption dryer which can take up to 16bar(e) pressure.
<G-vec00487-002-s058><take_out.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser Verbindung zu den Servern von Google aufnehmen.
<G-vec00487-002-s058><take_out.aufnehmen><en> To do this, the browser used by you must take up contact to the servers of Google.
<G-vec00487-002-s059><take_out.aufnehmen><de> Professor Becoming a professor ist der beste Job, den Sie aufnehmen kann mit der Hilfe von Ihrem Abschluss in Rechtswissenschaften.
<G-vec00487-002-s059><take_out.aufnehmen><en> Professor Becoming a professor is the best job that you can take up with the help of your law degree.
<G-vec00487-002-s060><take_out.aufnehmen><de> Jedes Boot kann bis zu 10 Taucher aufnehmen, so dass es ideal für große Gruppen ist.
<G-vec00487-002-s060><take_out.aufnehmen><en> Each boat can take up to 10 divers so it’s ideal for large groups.
<G-vec00487-002-s061><take_out.aufnehmen><de> Kamera-Übergabe: Wenn Sie mit Ihrem iPhone, iPad oder iPod touch ein Dokument scannen oder ein Foto aufnehmen, wird das Ergebnis sofort auf Ihrem Mac angezeigt.
<G-vec00487-002-s061><take_out.aufnehmen><en> Continuity Camera: Use your iPhone, iPad, or iPod touch to scan documents or take a picture and it appears instantly on your Mac.
<G-vec00487-002-s062><take_out.aufnehmen><de> Da die starken Vibrationen beim offroad fahren im Grenzgebiet zwischen Italien und Frankreich meine Videokamera zerstört hatten, entschied ich mich dieses Mal dazu meine Kamera so am Helm zu befestigen, dass ich während der Fahrt ruckelfreie Videos aufnehmen und gleichzeitig den Bildschirm der Kamera im Auge behalten kann.
<G-vec00487-002-s062><take_out.aufnehmen><en> Since the strong vibrations of my motorbike had damaged my video camera during my last off-road trip, this time I decided to attach my camera directly to my helmet, so I could take smooth videos and watch the screen while riding. A GoPro would have been too expensive.
<G-vec00487-002-s063><take_out.aufnehmen><de> Wenn jemand nur dann zu uns kommt, wenn er etwas braucht - also egoistisch und selbstsüchtig ist - dann werden wir sicherlich nicht leicht mit ihm eine Freundschaft aufnehmen und in Freundschaft leben.
<G-vec00487-002-s063><take_out.aufnehmen><en> If someone only comes to us when he needs something - when he is egotistical and selfish - then we shall certainly not easily take up a friendship with him and live in friendship.
<G-vec00487-002-s064><take_out.aufnehmen><de> • Aufnehmen eines Bilds.
<G-vec00487-002-s064><take_out.aufnehmen><en> • Take a picture.
<G-vec00487-002-s065><take_out.aufnehmen><de> Saubermacher stellt Ihnen für die Sammlung Behälter zur Verfügung und kümmert sich um die regelmäßige Abholung Ihres Altglases durch Spezialfahrzeuge, die im Rahmen einer Abholung sowohl Bunt- als auch Weißglas in zwei voneinander getrennten Kammern aufnehmen können.
<G-vec00487-002-s065><take_out.aufnehmen><en> Saubermacher provides you with collection receptacles and then hauls the pooled glass away at regular intervals using special vehicles which are able to take both coloured and clear glass in a single collection operation in two independent chambers.
<G-vec00487-002-s066><take_out.aufnehmen><de> Da das iPhone qualitativ hochwertige Fotos aufnehmen kann und immer dabei ist, nimmt es inzwischen den Platz der meisten Digitalkameras ein.
<G-vec00487-002-s066><take_out.aufnehmen><en> As iPhone can take high-quality photos and is easy to carry which almost takes place of the common digital cameras.
<G-vec00487-002-s067><take_out.aufnehmen><de> Mir fallen einige Leute ein, die mich jederzeit aufnehmen würden.
<G-vec00487-002-s067><take_out.aufnehmen><en> There are a few people who will take me in at any time.
<G-vec00487-002-s068><take_out.aufnehmen><de> Aber dort wollte man sie als Deutsche nicht aufnehmen.
<G-vec00487-002-s068><take_out.aufnehmen><en> But then they did not want to take her because she was German.
<G-vec00487-002-s069><take_out.aufnehmen><de> Zarte schlauchförmige Organe, welche die Eizelle aufnehmen und in denen die Befruchtung stattfindet; zuständig für den weiteren Transport der befruchteten Eizelle in die Gebärmutter.
<G-vec00487-002-s069><take_out.aufnehmen><en> Gentle and tube shaped organs that take the egg cell and where the impregnation takes place; responsible for the further transport of the fertilized egg cell into the uterus.
<G-vec00487-002-s070><take_out.aufnehmen><de> Mit Firefox Screenshots können Sie Bildschirmfotos mit nur einem Klick auf eine Schaltfläche aufnehmen, herunterladen und teilen.
<G-vec00487-002-s070><take_out.aufnehmen><en> You can use the Firefox Screenshots feature to take, download and share screenshots with just a click of a button.
<G-vec00487-002-s071><take_out.aufnehmen><de> Mit der App iXpand Drive können Sie Fotos und Videos verwalten, Videos direkt auf dem Laufwerk ansehen und sogar Videos mit der App aufnehmen, um sie direkt auf dem Laufwerk zu speichern.
<G-vec00487-002-s071><take_out.aufnehmen><en> The iXpand Drive app makes it easy to manage photos and videos, watch videos directly from the drive, and even take videos from the app and save them directly onto the drive.
<G-vec00487-002-s072><take_out.aufnehmen><de> Normalerweise können Sie Ihre gewohnte Arbeit nach 1-3 Tagen wieder aufnehmen oder Ihren täglichen Beschäftigungen nachgehen.
<G-vec00487-002-s072><take_out.aufnehmen><en> You can normally take up your work or pursue your normal daily activities again after 1-3 days.
<G-vec00487-002-s073><take_out.aufnehmen><de> Bevor Sie mit der Aufnahme beginnen, klicken Sie auf Schnappschuss aufnehmen.
<G-vec00487-002-s073><take_out.aufnehmen><en> Before you start recording, click Take my snapshot now.
<G-vec00487-002-s074><take_out.aufnehmen><de> e) das Spiel spielen und einen Screenshot („Bild“) aufnehmen und eine Antwort im Thread posten, die das Bild enthält.
<G-vec00487-002-s074><take_out.aufnehmen><en> e) play the game and take a screenshot (“Image”) and post a reply by uploading their Image to the Thread.
<G-vec00487-002-s075><take_out.aufnehmen><de> Makroobjektiv kann klare Fotos von kleinen Objekten aufnehmen.
<G-vec00487-002-s075><take_out.aufnehmen><en> Macro lens can take clear photos of small objects
<G-vec00491-002-s040><withstand.aufnehmen><de> Zouhair Chaib, Senior Technical Expert bei Nord-Lock in Frankreich, betont, wie wichtig es ist, auch zwischen der statischen und dynamischen Kapazität einer Schraube zu unterscheiden; eine Schraube kann eine hohe statische Last, aber nur eine geringe dynamische Last aufnehmen.
<G-vec00491-002-s040><withstand.aufnehmen><en> Zouhair Chaib, Senior Technical Expert at Nord-Lock Group in France, says it is also important to differentiate between the static and dynamic capacity of a screw; a screw can withstand a high static load, but only a small amount of dynamic load.
<G-vec00491-002-s041><withstand.aufnehmen><de> Die Beschichtungswerkstoffe müssen die durch Reibung und Walkarbeit entstehenden Temperaturen schadensfrei aufnehmen können.
<G-vec00491-002-s041><withstand.aufnehmen><en> The coating materials must be able to withstand the temperatures generated by friction and creep.
<G-vec00491-002-s042><withstand.aufnehmen><de> Es macht also Sinn, eine Etikettierlösung auszuwählen, die es mit allen Bedingungen in Ihrer Branche aufnehmen kann, damit Informationen nicht verloren gehen und Ihre Unternehmensprozesse nicht unnötigerweise unterbrochen werden.
<G-vec00491-002-s042><withstand.aufnehmen><en> It is wise to choose an identification solution that is ready to withstand all relevant conditions, to ensure the integrity of the information and the continuity of your business.
<G-vec00491-002-s043><withstand.aufnehmen><de> Durch das kippsteife Abtriebslager können die Antriebe hohe Lasten einfach aufnehmen und präzise führen.
<G-vec00491-002-s043><withstand.aufnehmen><en> The output bearing with high tilting capacity can easily withstand and accurately handle heavy payloads.
<G-vec00503-002-s042><admit.aufnehmen><de> Eure Schuld ist übergroß gewesen, doch sie ist getilgt durch Jesus Christus, Der für euch Menschen nun der schaubare Gott geworden ist, vorausgesetzt, daß ihr euch von Ihm erlösen lasset, denn ihr könnet in Ewigkeit nicht eure Schuld selbst abtragen; Ich kann euch aber auch nicht mit eurer Schuld aufnehmen in Mein Reich, denn Ich bin wohl ein Gott der Liebe, aber auch ein Gott der Gerechtigkeit....
<G-vec00503-002-s042><admit.aufnehmen><en> Your guilt has been immense but it is redeemed by Jesus Christ Who now has become the visible God for you humans, providing you allow yourselves to be redeemed by Him, because you cannot ever remove your guilt yourselves. I, however, cannot admit you into My kingdom with your guilt because, although I Am in fact a God of love, I Am also a God of justice....
<G-vec00503-002-s043><admit.aufnehmen><de> Wenn wir Sie nach dem Einstufungstest nicht in den Kurs aufnehmen können, weil Sie nicht in Deutschland sind und es keinen Platz mehr im Kurs gibt, werden wir Ihnen Ihre Anmeldegebühr (450 EUR) erstatten.
<G-vec00503-002-s043><admit.aufnehmen><en> If we cannot admit you into the course after the placement test, because you are not in Germany and because there is no place left in the course, we will refund your registration fee (EUR 450).
<G-vec00503-002-s044><admit.aufnehmen><de> Wir sind an dieser Stelle auf ihre aktive Mitarbeit angewiesen, da wir betroffene Hunde nur in diese Auflistung aufnehmen, wenn uns eine schriftliche Einverständniserklärung des Eigentümers des betroffenen Hundes sowie eine Kopie des Befundes und der Ahnentafel vorliegt.
<G-vec00503-002-s044><admit.aufnehmen><en> We depend on your active participation, because we only admit affected dogs in our list, if we have the written consent of the affected dog's owners, a copy of the dog's finding sheet and pedigree.
<G-vec00503-002-s045><admit.aufnehmen><de> Bitte beachten Sie, dass wir Kinder in der Krippe ab einem Alter von 6 Monaten aufnehmen.
<G-vec00503-002-s045><admit.aufnehmen><en> Please note that we admit children 6 months and older in our nursery.
<G-vec00505-002-s124><borrow.aufnehmen><de> Die Aufwärtskorrekturen beruhen auf unserer Einschätzung, dass die Haushalte bereit sind, weniger zu sparen (und mehr Kredite aufzunehmen), um den Konsum trotz der höheren Inflation und des Rückgangs der Realeinkommen aufrecht zu erhalten.
<G-vec00505-002-s124><borrow.aufnehmen><en> The upward revisions reflect our view that households are prepared to save less (borrow more) in order to smooth consumption in the face of higher inflation and a squeeze on real incomes.
<G-vec00505-002-s125><borrow.aufnehmen><de> Länder mit starken politischen Rahmenbedingungen haben Zugang zu Kreditinstrumenten wie der Flexiblen Kreditlinie (Flexible Credit Line – FCL) oder der Vorsorge-und-Liquiditäts-Linie (Precautionary and Liquidity Line – PLL), die es ihnen ermöglichen, falls nötig, kurzfristig Kredite aufzunehmen.
<G-vec00505-002-s125><borrow.aufnehmen><en> Countries with strong policy framework have access to facilities such as the Flexible Credit Line (FCL) or Precautionary and Liquidity Line (PLL), enabling them to borrow at short notice if needed.
<G-vec00514-002-s021><waffle.aufnehmen><de> Wunderschöne Aufnahmen...
<G-vec00514-002-s021><waffle.aufnehmen><en> That is the tiniest waffle...
<G-vec00530-002-s057><take_up.aufnehmen><de> Zur Durchführung der Prüfung lieferte Atlas Copco Rental einen PNS 1250 100 % ölfreien fahrbaren dieselbetriebenen Hochdruckkompressor zusammen mit einem CD 47 Adsorptionstrockner, der bis zu 16 bar(e) Druck aufnehmen kann.
<G-vec00530-002-s057><take_up.aufnehmen><en> To carry out the test Atlas Copco Rental delivered a PNS1250 100% oil-free portable diesel driven high-pressure compressor together with a CD47 adsorption dryer which can take up to 16bar(e) pressure.
<G-vec00530-002-s058><take_up.aufnehmen><de> Zu diesem Zweck muss der von Ihnen verwendete Browser Verbindung zu den Servern von Google aufnehmen.
<G-vec00530-002-s058><take_up.aufnehmen><en> To do this, the browser used by you must take up contact to the servers of Google.
<G-vec00530-002-s059><take_up.aufnehmen><de> Professor Becoming a professor ist der beste Job, den Sie aufnehmen kann mit der Hilfe von Ihrem Abschluss in Rechtswissenschaften.
<G-vec00530-002-s059><take_up.aufnehmen><en> Professor Becoming a professor is the best job that you can take up with the help of your law degree.
<G-vec00530-002-s060><take_up.aufnehmen><de> Jedes Boot kann bis zu 10 Taucher aufnehmen, so dass es ideal für große Gruppen ist.
<G-vec00530-002-s060><take_up.aufnehmen><en> Each boat can take up to 10 divers so it’s ideal for large groups.
<G-vec00530-002-s061><take_up.aufnehmen><de> Kamera-Übergabe: Wenn Sie mit Ihrem iPhone, iPad oder iPod touch ein Dokument scannen oder ein Foto aufnehmen, wird das Ergebnis sofort auf Ihrem Mac angezeigt.
<G-vec00530-002-s061><take_up.aufnehmen><en> Continuity Camera: Use your iPhone, iPad, or iPod touch to scan documents or take a picture and it appears instantly on your Mac.
<G-vec00530-002-s062><take_up.aufnehmen><de> Da die starken Vibrationen beim offroad fahren im Grenzgebiet zwischen Italien und Frankreich meine Videokamera zerstört hatten, entschied ich mich dieses Mal dazu meine Kamera so am Helm zu befestigen, dass ich während der Fahrt ruckelfreie Videos aufnehmen und gleichzeitig den Bildschirm der Kamera im Auge behalten kann.
<G-vec00530-002-s062><take_up.aufnehmen><en> Since the strong vibrations of my motorbike had damaged my video camera during my last off-road trip, this time I decided to attach my camera directly to my helmet, so I could take smooth videos and watch the screen while riding. A GoPro would have been too expensive.
<G-vec00530-002-s063><take_up.aufnehmen><de> Wenn jemand nur dann zu uns kommt, wenn er etwas braucht - also egoistisch und selbstsüchtig ist - dann werden wir sicherlich nicht leicht mit ihm eine Freundschaft aufnehmen und in Freundschaft leben.
<G-vec00530-002-s063><take_up.aufnehmen><en> If someone only comes to us when he needs something - when he is egotistical and selfish - then we shall certainly not easily take up a friendship with him and live in friendship.
<G-vec00530-002-s064><take_up.aufnehmen><de> • Aufnehmen eines Bilds.
<G-vec00530-002-s064><take_up.aufnehmen><en> • Take a picture.
<G-vec00530-002-s065><take_up.aufnehmen><de> Saubermacher stellt Ihnen für die Sammlung Behälter zur Verfügung und kümmert sich um die regelmäßige Abholung Ihres Altglases durch Spezialfahrzeuge, die im Rahmen einer Abholung sowohl Bunt- als auch Weißglas in zwei voneinander getrennten Kammern aufnehmen können.
<G-vec00530-002-s065><take_up.aufnehmen><en> Saubermacher provides you with collection receptacles and then hauls the pooled glass away at regular intervals using special vehicles which are able to take both coloured and clear glass in a single collection operation in two independent chambers.
<G-vec00530-002-s066><take_up.aufnehmen><de> Da das iPhone qualitativ hochwertige Fotos aufnehmen kann und immer dabei ist, nimmt es inzwischen den Platz der meisten Digitalkameras ein.
<G-vec00530-002-s066><take_up.aufnehmen><en> As iPhone can take high-quality photos and is easy to carry which almost takes place of the common digital cameras.
<G-vec00530-002-s067><take_up.aufnehmen><de> Mir fallen einige Leute ein, die mich jederzeit aufnehmen würden.
<G-vec00530-002-s067><take_up.aufnehmen><en> There are a few people who will take me in at any time.
<G-vec00530-002-s068><take_up.aufnehmen><de> Aber dort wollte man sie als Deutsche nicht aufnehmen.
<G-vec00530-002-s068><take_up.aufnehmen><en> But then they did not want to take her because she was German.
<G-vec00530-002-s069><take_up.aufnehmen><de> Zarte schlauchförmige Organe, welche die Eizelle aufnehmen und in denen die Befruchtung stattfindet; zuständig für den weiteren Transport der befruchteten Eizelle in die Gebärmutter.
<G-vec00530-002-s069><take_up.aufnehmen><en> Gentle and tube shaped organs that take the egg cell and where the impregnation takes place; responsible for the further transport of the fertilized egg cell into the uterus.
<G-vec00530-002-s070><take_up.aufnehmen><de> Mit Firefox Screenshots können Sie Bildschirmfotos mit nur einem Klick auf eine Schaltfläche aufnehmen, herunterladen und teilen.
<G-vec00530-002-s070><take_up.aufnehmen><en> You can use the Firefox Screenshots feature to take, download and share screenshots with just a click of a button.
<G-vec00530-002-s071><take_up.aufnehmen><de> Mit der App iXpand Drive können Sie Fotos und Videos verwalten, Videos direkt auf dem Laufwerk ansehen und sogar Videos mit der App aufnehmen, um sie direkt auf dem Laufwerk zu speichern.
<G-vec00530-002-s071><take_up.aufnehmen><en> The iXpand Drive app makes it easy to manage photos and videos, watch videos directly from the drive, and even take videos from the app and save them directly onto the drive.
<G-vec00530-002-s072><take_up.aufnehmen><de> Normalerweise können Sie Ihre gewohnte Arbeit nach 1-3 Tagen wieder aufnehmen oder Ihren täglichen Beschäftigungen nachgehen.
<G-vec00530-002-s072><take_up.aufnehmen><en> You can normally take up your work or pursue your normal daily activities again after 1-3 days.
<G-vec00530-002-s073><take_up.aufnehmen><de> Bevor Sie mit der Aufnahme beginnen, klicken Sie auf Schnappschuss aufnehmen.
<G-vec00530-002-s073><take_up.aufnehmen><en> Before you start recording, click Take my snapshot now.
<G-vec00530-002-s074><take_up.aufnehmen><de> e) das Spiel spielen und einen Screenshot („Bild“) aufnehmen und eine Antwort im Thread posten, die das Bild enthält.
<G-vec00530-002-s074><take_up.aufnehmen><en> e) play the game and take a screenshot (“Image”) and post a reply by uploading their Image to the Thread.
<G-vec00530-002-s075><take_up.aufnehmen><de> Makroobjektiv kann klare Fotos von kleinen Objekten aufnehmen.
<G-vec00530-002-s075><take_up.aufnehmen><en> Macro lens can take clear photos of small objects
