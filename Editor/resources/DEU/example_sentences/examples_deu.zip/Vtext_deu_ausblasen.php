<G-vec00599-002-s030><blow_up.ausblasen><de> Man sollte niemals eine Kerze ausblasen, da sonst die guten Geister verschwinden, die sich gern um Kerzen ansammeln.
<G-vec00599-002-s030><blow_up.ausblasen><en> You should never blow out a candle, because if you blow out the flame, you blow away the good spirits, who like to gather around candles.
<G-vec00599-002-s031><blow_up.ausblasen><de> Tanabe: Eine neue Fähigkeit von Donkey Kong ist, dass er seinen Atem ausblasen kann.
<G-vec00599-002-s031><blow_up.ausblasen><en> Tanabe: One new ability for Donkey Kong is the ability to blow out his breath.
<G-vec00599-002-s032><blow_up.ausblasen><de> Das Wasser war gefroren, bevor es in die Zisterne fließen konnte und die Rohre von der Zisterne zum Haus mussten wir jedes Mal unterbrechen und ausblasen, wenn wir Wasser gebraucht hatten.
<G-vec00599-002-s032><blow_up.ausblasen><en> And the water froze before going into the cistern, and the pipes running water to the house from the cistern (which we had to disconnect and blow out to dry every time we got water).
<G-vec00599-002-s033><blow_up.ausblasen><de> Dies stellt den idealen Einbaufall dar, da die Luft ungehindert ausblasen kann.
<G-vec00599-002-s033><blow_up.ausblasen><en> This is the ideal installation situation, since the air can blow out without hindrance.
<G-vec00599-002-s034><blow_up.ausblasen><de> Es kann bis zu 30 m³/h Luft ausblasen, die maximal erreichbare Temperatur liegt bei 650 °C.
<G-vec00599-002-s034><blow_up.ausblasen><en> It may take up to 30 m³/h of air blow, the maximum attainable temperature is 650° C.
<G-vec00599-002-s035><blow_up.ausblasen><de> Lasse ihn Laserstrahlen aus den Augen schießen, Feuer ausblasen oder andere Superhelden-Fähigkeiten ausführen um weiter zu kommen.
<G-vec00599-002-s035><blow_up.ausblasen><en> Let him shoot laser beams from his eyes, fire blow or perform other superhero skills to progress.
<G-vec00599-002-s036><blow_up.ausblasen><de> Bohrloch erstellen und ausblasen/ausbürsten.
<G-vec00599-002-s036><blow_up.ausblasen><en> Drill hole and blow out/brush.
<G-vec00599-002-s037><blow_up.ausblasen><de> Ist das schwarze Teil geschmolzen, die Flamme ausblasen (es muss aber auch nicht brennen, der Kunststoff muss nur weich werden) und dann entweder mit einem kleinen Messer, Löffel o. ä. platt drücken, richtig schön platt drücken.
<G-vec00599-002-s037><blow_up.ausblasen><en> When the black part has melted a bit, blow out the flame (but it doesn't have to burn either, the plastic just has to become soft) and then press it flat with a small knife, spoon or similar, press it really flat.
<G-vec00599-002-s038><blow_up.ausblasen><de> Ein gelungenes Ausblasen/Niederfahren des Ofens ist ein absolutes Muß für einen erfolgreichen Sauabstich und Abkühlungsprozeß und letzten Endes für einen rechtzeitigen Abschluß der Reparaturarbeiten selbst.
<G-vec00599-002-s038><blow_up.ausblasen><en> The successful blow–down of the furnace is an absolute necessity to allow a successful salamander tap and quench, and ultimately a timely completion of the repair work itself.
<G-vec00599-002-s039><blow_up.ausblasen><de> Die Räucherkegel werden an der Spitze angezündet, die Flamme dann ausblasen und auf einer feuerfesten Unterlage abbrennen.
<G-vec00599-002-s039><blow_up.ausblasen><en> The incense cones are lit at the top, then blow out the flame and burn on a fireproof surface.
<G-vec00599-002-s040><blow_up.ausblasen><de> Der Schmuck an sich wird meistens von Frauen angefertigt, die bereits Wochen zuvor mit dem Ausblasen und Anmalen von Hühner- und Gänseeiern beginnen.
<G-vec00599-002-s040><blow_up.ausblasen><en> The adornments are mainly made by women who start many weeks before to blow out and paint chicken and goose eggs.
