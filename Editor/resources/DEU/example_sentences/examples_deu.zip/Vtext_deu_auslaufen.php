<G-vec00351-002-s048><leak.auslaufen><de> Wenn der äußere Ring gedreht wird, führen die Lager, die mit hoher Geschwindigkeit laufen, dazu, dass das Fett ausläuft.
<G-vec00351-002-s048><leak.auslaufen><en> If the outer ring is turned, the bearings running at high speed will cause the grease to leak.
<G-vec00351-002-s049><leak.auslaufen><de> Der Eiswürfelbehälter ist aus Silikon gefertigt, der nicht ausläuft oder färbt und einfach in der Spülmaschine gewaschen werden kann.
<G-vec00351-002-s049><leak.auslaufen><en> The Ice Cube Tray is made of silicone that won't leak or stain and can simply be washed in the dishwasher.
<G-vec00351-002-s050><leak.auslaufen><de> Glasflasche sammeln 1405 Gassammelflasche mit eingeschliffenem Glasschieber Diese Art von Glasbehälter kann einen engen Kontakt mit Milchglas haben, das dazu beiträgt, dass das Gas in der Flasche nicht ausläuft, um die Reaktion zwischen Material und Gas zu verarbeiten.
<G-vec00351-002-s050><leak.auslaufen><en> 1405 Gas collecting bottle with ground-in glass slide This kind of glass container can maintain a close contact with frosted glass, which helps the gas inside the bottle not leak, used to process the reaction between material and gas.
<G-vec00351-002-s051><leak.auslaufen><de> Sie werden nicht bemerken, wie das Wasser durch den gebildeten Raum in der Toilette ausläuft.
<G-vec00351-002-s051><leak.auslaufen><en> You will not notice how the water will leak through the formed space in the toilet.
<G-vec00351-002-s052><leak.auslaufen><de> Die Müllsäcke sind ziemlich robust, sodass Sie sich keine Sorgen machen müssen, dass etwas ausläuft.
<G-vec00351-002-s052><leak.auslaufen><en> The trashbags are pretty sturdy so you don't have to worry that something might leak.
<G-vec00351-002-s053><leak.auslaufen><de> Zwei Boden-Stopper-Gassammelflasche mit eingeschliffenem Glasschieber Diese Art von Glasbehälter kann einen engen Kontakt mit Milchglas haben, das dazu beiträgt, dass das Gas in der Flasche nicht ausläuft, um die Reaktion zwischen Material und Gas zu verarbeiten.
<G-vec00351-002-s053><leak.auslaufen><en> 1405 Gas collecting bottle with ground-in glass slide This kind of glass container can maintain a close contact with frosted glass, which helps the gas inside the bottle not leak, used to process the reaction between material and gas.
<G-vec00351-002-s054><leak.auslaufen><de> Wenn Sie es über einen längeren Zeitraum tragen, wird das ständige und gleichmäßige Klopfen auf die Prostata langsam und stetig dazu führen, dass Ihr Schwanz ausläuft.
<G-vec00351-002-s054><leak.auslaufen><en> When worn for an extended period of time, the constant and steady tapping on the prostrate will slowly and steadily cause your Cock to leak.
<G-vec00351-002-s055><leak.auslaufen><de> Nehmen Sie Tupperware Schachteln und verschließbare Trinkflaschen, um sicher zu gehen, dass nichts ausläuft.
<G-vec00351-002-s055><leak.auslaufen><en> Use Tupperware containers and sealed drink bottles to make sure the contents don’t spill or leak.
<G-vec00113-002-s104><expire.auslaufen><de> Fünf Mitglieder für das Funds Dissemination Committee mit einer Amtszeit von zwei Jahren, die 2019 auslaufen wird.
<G-vec00113-002-s104><expire.auslaufen><en> Five members of the Funds Dissemination Committee to serve a two–year term which will expire in 2019.
<G-vec00113-002-s105><expire.auslaufen><de> Dieser Rahmen wird 2015 auslaufen und durch eine Reihe von langfristigen Zielen zur nachhaltigen Entwicklung (SDG) ersetzt werden.
<G-vec00113-002-s105><expire.auslaufen><en> This framework is set to expire in 2015 and be replaced by a set of long-term sustainable development goals.
<G-vec00113-002-s106><expire.auslaufen><de> Diese hohe Wachstumsrate ist – neben einer deutlichen Verbesserung des Konsumentenvertrauens – vor allem auch steuerlich bedingt: Ursprünglich hätte die im Februar in Kraft getretene Reduzierung der Verbrauchssteuer Ende Juni auslaufen sollen.
<G-vec00113-002-s106><expire.auslaufen><en> Alongside a distinct improvement in consumer confidence, this high growth rate is attributable above all to tax reasons. Initially the reduction in purchase tax that entered into force in February was scheduled to expire at the end of June.
<G-vec00113-002-s107><expire.auslaufen><de> Blut im Wasser: Die zeitliche Abstimmung wurde verbessert, sodass 'Wilder Biss' den Effekt von 'Zerfetzen' nun sofort auffrischt, statt nach einer kurzen Verzögerung (dies führte dazu, dass der Effekt von 'Zerfetzen' auslaufen konnte, obwohl er aufgefrischt wurde).
<G-vec00113-002-s107><expire.auslaufen><en> Blood in the Water: Timing on this effect has been improved so that Ferocious Bite will immediately refresh Rip, rather than be slightly delayed (which gave a chance for the Rip to expire despite being refreshed).
<G-vec00113-002-s108><expire.auslaufen><de> Was auch immer der genaue Grund für viele Arzneimittel sein mag, das Patent kann relativ kurz nach dem Markteintritt auslaufen.
<G-vec00113-002-s108><expire.auslaufen><en> Whatever the exact reason, for many medicines, the patent can expire relatively shortly after they appeared on the market.
<G-vec00113-002-s109><expire.auslaufen><de> Nach Ablauf der Registrierungslaufzeit kann der Domainnamen-Registrar den Domainnamen im Auftrag des Registranten jederzeit verlängern oder auslaufen lassen.
<G-vec00113-002-s109><expire.auslaufen><en> At the end of the registration period, the domain name registrant has the option to renew the domain name or let it expire. Find a Registrar
<G-vec00113-002-s110><expire.auslaufen><de> Diese Aktionen sind auf einen bestimmten Zeitraum beschränkt, deshalb empfehlen wir zu handeln, bevor diese großartigen Angebote auslaufen.
<G-vec00113-002-s110><expire.auslaufen><en> These promotions are for a limited time only, so be sure to act now before these great offers expire!
<G-vec00113-002-s111><expire.auslaufen><de> Oder Sie kaufen Kaufoptionsverträge mit einem Ausübungspreis von 100 USD, die in sechs Monaten für 400 USD auslaufen, und die gleiche Anzahl von Aktien für 2.000 USD, wodurch Sie 48.000 USD für andere Geschäftsmöglichkeiten übrig haben.
<G-vec00113-002-s111><expire.auslaufen><en> Or you could buy call option contracts with a strike price of $100 that expire in six months for $400 and control the same number of shares for $2,000, leaving you $48,000 to pursue other opportunities.
<G-vec00113-002-s112><expire.auslaufen><de> Nach der Premiere der Netflix-Dokumentation erhöhten eine empörte Weltöffentlichkeit, UNESCO, EU, das britische, das deutsche und zahlreiche andere Parlamente den Druck auf Soco so sehr, dass der Konzern seine Lizenz 2015 auslaufen ließ.
<G-vec00113-002-s112><expire.auslaufen><en> After the premiere of the Netflix documentary, an outraged world public, UNESCO, EU, the British, German and numerous other parliaments increased the pressure on Soco to such an extent that the company let its license expire in 2015.
<G-vec00113-002-s113><expire.auslaufen><de> Im vergangenen Monat hat Gazprom seine Absicht angekündigt, Lieferungen durch die Ukraine einzustellen, wenn die Verträge mit dem ukrainischen Energiekonzern Naftogaz 2019 auslaufen, der auch die Gas-Pipelines unterhält.
<G-vec00113-002-s113><expire.auslaufen><en> Last month, Gazprom announced its intention to cease shipments through Ukraine when the contracts with the country's gas pipeline company, Naftogaz, expire in 2019.
<G-vec00113-002-s114><expire.auslaufen><de> Die Finanzminister der Eurozone haben mit ihrem Beharren darauf, das derzeitige Hilfsprogramm am morgigen Dienstag auslaufen zu lassen, dem griechischen Regierungschef Alexis Tsipras in die Hände gespielt, meint Kolumnist Wolfgang Münchau in der wirtschaftsliberalen Tageszeitung Financial Times: "Der mit Abstand größte taktische Fehler des vergangenen Wochenendes war die Weigerung der Finanzminister der Eurozone, die Frist für das Hilfsprogramm für Griechenland um fünf Tage, über die Volksabstimmung hinaus zu verlängern.
<G-vec00113-002-s114><expire.auslaufen><en> The finance ministers of the Eurozone have played right into the hands of Greek Prime Minister Alexis Tsipras by insisting that the bailout programme expire this Tuesday, columnist Wolfgang Münchau writes in the liberal Financial Times newspaper: "By far the biggest tactical error committed over the weekend, however, was the rejection by eurozone finance ministers of a five-day extension of the Greek bailout programme to beyond the referendum.
<G-vec00113-002-s115><expire.auslaufen><de> Die Belieferung eines Großkunden wird Ende Februar 2019 auslaufen.
<G-vec00113-002-s115><expire.auslaufen><en> The frame contract with a major customer will expire at the end of February 2019.
<G-vec00113-002-s116><expire.auslaufen><de> Wenn Sie jedoch in der Regel monatlich zahlen müssen, wird Ihre Website höchstwahrscheinlich auslaufen, wenn Sie Ihre Webhosting-Gebühr nicht monatlich aktualisieren.
<G-vec00113-002-s116><expire.auslaufen><en> But usually, if you require to pay per month, most likely your site will expire if you do not update your web host fee monthly.
<G-vec00113-002-s117><expire.auslaufen><de> Mit den Predictive Services von SoftwareONE können Sie Ihre nicht unterstützten Umgebungen proaktiv bereinigen und gleichzeitig Upgrades für Software, die bald auslaufen wird, planen.
<G-vec00113-002-s117><expire.auslaufen><en> SoftwareONE’s Predictive Services enables you to proactively remediate your unsupported environments while planning ahead for upgrades on software that will soon expire.
<G-vec00113-002-s118><expire.auslaufen><de> Und Sie erkennen rechtzeitig, welche Verträge auslaufen, verlängert oder gekündigt werden müssen.
<G-vec00113-002-s118><expire.auslaufen><en> And you can identify in good time which contracts are expire and which contracts must be extended or canceled.
<G-vec00113-002-s119><expire.auslaufen><de> Vodafone kann das neu erworbene Spektrum bis zum Auslaufen der vom Regulierer eingeräumten Nutzungsrechte bis zum Jahr 2021 für den Ausbau seines Netzes verwenden.
<G-vec00113-002-s119><expire.auslaufen><en> Vodafone may use the newly acquired spectrum to expand its network until the rights of use granted by the regulator expire in 2021.
<G-vec00113-002-s120><expire.auslaufen><de> Daher müssen Reversal-Candlestick-Muster zum Beispiel nur eine vorübergehende Korrektur im Markt, statt eines totalen Reversals auslösen, damit die Optionen In-the-Money auslaufen.
<G-vec00113-002-s120><expire.auslaufen><en> Therefore, reversal candlestick patterns, for example, only need to provide a momentary correction in the market rather than a full-on reversal, in order for the options to expire in the money.
<G-vec00113-002-s121><expire.auslaufen><de> Bündnisse können zu jedem Zeitpunkt verlängert werden, unabhängig davon wann diese auslaufen.
<G-vec00113-002-s121><expire.auslaufen><en> MPPs can be proposed and voted for at any point before they expire.
<G-vec00113-002-s122><expire.auslaufen><de> Der Kampf gegen Tuberkulose ist Teil der acht Milenniumsentwicklungsziele (MDGs), die Ende des Jahres auslaufen.
<G-vec00113-002-s122><expire.auslaufen><en> Combatting TB is one of aspects of the Millennium Development Goals (MDGs), which expire at the end of the year.
<G-vec00113-002-s127><expire.auslaufen><de> 9.1 Vorbehaltlich der nachstehenden Bedingungen garantiert der Lieferant, dass die Waren zum Zeitpunkt der Lieferung mit ihren Spezifikationen übereinstimmen und für einen Zeitraum von 6 Monaten ab dem Datum ihrer ersten Verwendung oder 12 Monaten frei von Material- und Verarbeitungsfehlern sind ab der Lieferung, je nachdem, welcher zuerst ausläuft, und dass die Dienstleistungen mit angemessener Sachkenntnis und Sorgfalt ausgeführt werden.
<G-vec00113-002-s127><expire.auslaufen><en> 9.1 Subject to the conditions set out below the Supplier warrants that the Goods will correspond with their specification at the time of delivery and will be free from defects in material and workmanship for a period of 6 months from the date of their initial use or 12 months from delivery, whichever is the first to expire and that the Services shall be carried out with reasonable skill and care.
<G-vec00113-002-s128><expire.auslaufen><de> Wir werden uns außerdem weiter dafür einsetzen, dass Moskau und Washington den New-Start-Vertrag verlängern, der 2021 ausläuft und der die strategischen Waffen und Trägersysteme reduziert hat.
<G-vec00113-002-s128><expire.auslaufen><en> Furthermore, we will continue to work to ensure that Moscow and Washington extend the New START Treaty, which is to expire in 2021 and which has reduced strategic weapons and delivery systems.
<G-vec00113-002-s129><expire.auslaufen><de> Das Gesetz über den Nationalen Justizrat sieht in seiner endgültigen Fassung – wie alle vorherigen Fassungen auch – vor, dass mit Inkrafttreten des Gesetzes die Amtszeit aller bisherigen Mitglieder des Rats ausläuft.
<G-vec00113-002-s129><expire.auslaufen><en> The National Council of the Judiciary Act stipulated – as all its previous incarnations had done – that the terms of office of all existing Council members would expire with its entry into force.
<G-vec00113-002-s130><expire.auslaufen><de> Wenn Sie eine Generische Top-Level-Domain besitzen, informieren wir Sie in diesem Artikel über sogenannte Laufzeit-Benachrichtigungen, die Sie als Inhaber einer Domain automatisiert von uns erhalten, falls die Domain ausläuft oder sich verlängert.
<G-vec00113-002-s130><expire.auslaufen><en> About ICANN Domain Term E-mails This article contains information on run-time notifications that you automatically receive from us as a domain owner if the domain is set to expire, has expired or is renewed.
<G-vec00113-002-s131><expire.auslaufen><de> Erinnerungen können zu unterschiedlichen Zeitpunkten erfolgen, wenn ein Diplom ausläuft.
<G-vec00113-002-s131><expire.auslaufen><en> Reminders can be sent at different points in time when a diploma is about to expire.
<G-vec00113-002-s132><expire.auslaufen><de> Und in Deutschland wird die Mercedes-Benz AG zudem künftig Strom aus deutschen Windkraftanlagen beziehen, deren Förderung nach dem Erneuerbare-Energien-Gesetz (EEG) nach 2020 ausläuft.
<G-vec00113-002-s132><expire.auslaufen><en> In Germany, too, Mercedes-Benz AG will soon be sourcing electricity from German wind farms, the subsidies for which expire after 2020 under the German Renewable Energy Act (EEG).
<G-vec00113-002-s133><expire.auslaufen><de> Weil er ausläuft, müssen die Delegationen in Marrakesch nun einen neuen Fünf-Jahres-Plan aufstellen.
<G-vec00113-002-s133><expire.auslaufen><en> As it is due to expire, the delegations in Marrakesh must now set up a new five-year plan.
<G-vec00113-002-s259><expire.auslaufen><de> Die im Jahr 2000 vereinbarten Millenniumsentwicklungsziele (MDGs) laufen aus.
<G-vec00113-002-s259><expire.auslaufen><en> The Millennium Development Goals (MDGs) that were agreed in 2000 will soon expire.
<G-vec00113-002-s260><expire.auslaufen><de> Die Ausnahmeregelungen der USA für acht Länder, die iranisches Öl kaufen, laufen im Mai aus.
<G-vec00113-002-s260><expire.auslaufen><en> The US waivers to eight countries buying Iranian oil will expire in May.
<G-vec00113-002-s261><expire.auslaufen><de> Die Rettungs- und Umstrukturierungsleitlinien von 1999 laufen im Oktober 2004 aus.
<G-vec00113-002-s261><expire.auslaufen><en> The 1999 rescue and restructuring guidelines expire in October 2004.
<G-vec00113-002-s262><expire.auslaufen><de> Da Seltmann Weiden sein Sortiment regelmäßig der Mode und Nachfrage anpasst, laufen Serien aus und werden aus der Produktion genommen.
<G-vec00113-002-s262><expire.auslaufen><en> Because of the fact that Seltmann Weiden adapts its range to fashion and demand regularly, some series expire and will be taken out of production.
<G-vec00113-002-s263><expire.auslaufen><de> Sie laufen nach einem Jahr aus.
<G-vec00113-002-s263><expire.auslaufen><en> They expire after 1 year.
<G-vec00113-002-s298><expire.auslaufen><de> Tipps Falls du zu lange wartest, bevor du den QR-Code scannst, läuft der Code aus.
<G-vec00113-002-s298><expire.auslaufen><en> Tips If you wait too long to scan the QR code, it will expire.
<G-vec00113-002-s299><expire.auslaufen><de> Getrennt und unabhängig von den Datenschutzeinstellungen Ihres Lebenslaufs läuft dieser aus und wird gelöscht, wenn Sie sich über einen längeren Zeitraum nicht in Ihr Account einloggen.
<G-vec00113-002-s299><expire.auslaufen><en> Separately, and regardless of your CV privacy setting, if you do not log into your account for a significant period of time, it will expire and be scheduled for deletion.
<G-vec00113-002-s300><expire.auslaufen><de> Sollten Ihre Server aber inaktiv sein, läuft Ihre NPL dauerhaft aus.
<G-vec00113-002-s300><expire.auslaufen><en> However, if your virtual server(s) are inactive then your NPL will permanently expire.
<G-vec00113-002-s301><expire.auslaufen><de> Andernfalls läuft dein Probeaccount einfach aus.
<G-vec00113-002-s301><expire.auslaufen><en> Otherwise, your trial account will simply expire.
<G-vec00113-002-s302><expire.auslaufen><de> Danach läuft Ihr Vertrag automatisch aus.
<G-vec00113-002-s302><expire.auslaufen><en> Afterwards, the contract will expire automatically.
