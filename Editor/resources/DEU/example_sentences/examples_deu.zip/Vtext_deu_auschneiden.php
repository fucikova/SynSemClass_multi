<G-vec00555-002-s095><cut_off.auschneiden><de> Die Dynamic Photo-Funktion, mit der ein sich bewegendes Motiv ausgeschnitten und auf ein anderes unbewegtes Hintergrundbild gesetzt werden kann, wurde erheblich verbessert.
<G-vec00555-002-s095><cut_off.auschneiden><en> Great advancements have been achieved in the Dynamic Photo function, which enables users to cut out images of a moving subject and paste them on a different still image that acts as a background.
<G-vec00555-002-s096><cut_off.auschneiden><de> Auf das weiße Papier habe ich den Spruch gestempelt und es dann per Hand "ausgeschnitten" bevor ich dann noch den zweiten Teil hinzugestempelt habe.
<G-vec00555-002-s096><cut_off.auschneiden><en> On the latter I stamped the first part of the sentiment and then fussy cut it out before stamping the second part as well.
<G-vec00555-002-s097><cut_off.auschneiden><de> Der ist einmal mit schwarzer Tinte und einmal golden embossed gestempelt, ausgeschnitten und auf braunen Cardstock geklebt.
<G-vec00555-002-s097><cut_off.auschneiden><en> I stamped it once with black ink, once heat embossed it using golden embossing powder, then cut those out and put them on brown cardstock.
<G-vec00555-002-s098><cut_off.auschneiden><de> Bei den großen Waben werden die Kurven an jedem Ende verjüngt und aus der Platte ausgeschnitten.
<G-vec00555-002-s098><cut_off.auschneiden><en> With large honeycombs, the curves are cut out of the sheet and tapered at each end.
<G-vec00555-002-s099><cut_off.auschneiden><de> Ich habe den Jungen und das Mädchen abgestempelt, coloriert und dann anschließend konturengenau ausgeschnitten.
<G-vec00555-002-s099><cut_off.auschneiden><en> stamped the boy and girl images, colored them and then cut them out trimming closely.
<G-vec00555-002-s100><cut_off.auschneiden><de> Die Blüten habe ich nochmal extra gestempelt, mit Distress Inks farbig gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s100><cut_off.auschneiden><en> I stamped the flowers again, wiped them with Distress Inks in colour, cut them out and glued them on.
<G-vec00555-002-s101><cut_off.auschneiden><de> Einige Kinder haben ihren Fußabdruck ausgeschnitten und etwas aus der Natur darauf gemalt, was für sie besonders schützenswert ist.
<G-vec00555-002-s101><cut_off.auschneiden><en> Some children cut out their footprints and draw something on it that deserves protection for them.
<G-vec00555-002-s102><cut_off.auschneiden><de> Wo bisher langwierig ausgeschnitten und angepasst werden musste, kann das Rohr jetzt spielend leicht in die vorbereitete Zulauföffnung eingesteckt und der Regenfangkasten direkt an der Wand montiert werden.
<G-vec00555-002-s102><cut_off.auschneiden><en> Where it previously had to be tediously cut and adjusted, the pipe can now easily be inserted through the prepared inflow opening and the rainwater hopper mounted directly on the wall.
<G-vec00555-002-s103><cut_off.auschneiden><de> Das Motiv ist mit Copics coloriert und ausgeschnitten.
<G-vec00555-002-s103><cut_off.auschneiden><en> The image is colored with Copics and cut out by hand.
<G-vec00555-002-s104><cut_off.auschneiden><de> Als flächiges Material sind zB textile Materialien wie Gewebe oder Gewirke, aber auch Folien denkbar, aus denen die Markierungen zB ausgestanzt oder ausgeschnitten sind.
<G-vec00555-002-s104><cut_off.auschneiden><en> As a sheet material, for example textile materials such as woven or knitted fabrics, but also films are also conceivable, of which the markings are, for example punched or cut out.
<G-vec00555-002-s105><cut_off.auschneiden><de> Den weißen Cardstock im Hintergrund, den ich schwarz gemattet und auf eine weiße Grundkarte geklebt habe, ist mit Distress Ink Tumbled Glass und verschiedenen "Flecken" aus dem Distressed ein Bär aus dem Joyful Heart Bears Set und noch ein Schweinchen aus dem Piggy Pebbles Set) ist hinter den Rahmen geklebt und die Motive so ausgeschnitten, dass die eigentlich vom Rahmen abgedeckten Teile der Tiere vorne über den Rahmen überstehen.
<G-vec00555-002-s105><cut_off.auschneiden><en> Der Carstock mit den Motiven (eine Maus aus dem Mice Time to Celebrate Set, The paper with the stamped on images (a mouse from the Mice Time to Celebrate stamp set, one of the bears from the Joyful Heart Bears set and a piglet from the Piggy Pebbles set) ist glued behind the frame and the images were cut out so the pieces that would've been covered by the frame are on top of it.
<G-vec00555-002-s106><cut_off.auschneiden><de> Die Elefanten habe ich mit grauer Farbe gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s106><cut_off.auschneiden><en> I wiped the elephants with grey paint, cut them out and glued them on.
<G-vec00555-002-s107><cut_off.auschneiden><de> Umfangreiche Editierfunktionen (Blöcke können ausgeschnitten, eingefügt, verschoben oder in andere Programmfenster kopiert werden, auch direkt in andere Fenster ohne den Umweg über das Clipboard).
<G-vec00555-002-s107><cut_off.auschneiden><en> Comprehensive editing functions (e.g., block functions such as cut, copy, paste, move, even directly moving into other windows without using the clipboard).
<G-vec00555-002-s108><cut_off.auschneiden><de> Aus dem dichten Karton werden zwei identische Figuren ausgeschnitten.
<G-vec00555-002-s108><cut_off.auschneiden><en> From the dense cardboard, two identical figures are cut out.
<G-vec00555-002-s109><cut_off.auschneiden><de> Einige werden dann ausgeschnitten und so kann man sie als eine Art Objekt an die Wand hängen.
<G-vec00555-002-s109><cut_off.auschneiden><en> And some of them, being cut out, can come to be an object on the wall.
<G-vec00555-002-s110><cut_off.auschneiden><de> Die Spannweite liegt bei 2 Metern und es wurden für die Federn der Flügel eigene Teile per Hand ausgeschnitten.
<G-vec00555-002-s110><cut_off.auschneiden><en> The span is 2 meters and own parts were cut out by hand for the feathers of the wings.
<G-vec00555-002-s111><cut_off.auschneiden><de> Um den gewünschten Qualitätsstandard gewährleisten zu können, müssen diese kleinen Öffnungen sehr passgenau ausgeschnitten werden.
<G-vec00555-002-s111><cut_off.auschneiden><en> In order to ensure the desired quality standard, these small openings must be cut out precisely.
<G-vec00555-002-s112><cut_off.auschneiden><de> Jedes Foto kann danach als Postkarte ausgeschnitten und weitergeschickt werden.
<G-vec00555-002-s112><cut_off.auschneiden><en> Each photo can be cut out and send as a postcard.
<G-vec00555-002-s113><cut_off.auschneiden><de> Erstelle eine Collage aus Bildern, die du aus Zeitschriften ausgeschnitten hast, indem du sie überlappend auf dem Karton anbringst.
<G-vec00555-002-s113><cut_off.auschneiden><en> Make a collage of images you cut out from magazines by overlapping them on your cardstock.
