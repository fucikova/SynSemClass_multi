<G-vec00081-001-s209><break.brechen><de> In Chopper Mania Ihre Fähigkeiten werden mit Hochdruck Gameplay getestet werden, einschließlich Ihrer Maus und Tastatur verwendet, um Knöpfe, brechen Wände drücken, zu vermeiden beweglichen Teile und vor allem, Vorsicht vor Ihre Grenzen.
<G-vec00081-001-s209><break.brechen><en> In Chopper Mania your skills will be tested with high pressure gameplay, including your mouse and keyboard, used to press buttons, break walls, avoid moving parts and mostly, beware of your limits.
<G-vec00081-001-s210><break.brechen><de> Forex Trading Break-even-EA wird die Währung Handel gesetzt auch nach x + Pips zu brechen.
<G-vec00081-001-s210><break.brechen><en> Forex Trading Breakeven EA will set the currency trading to break even after x +pips.
<G-vec00081-001-s211><break.brechen><de> Um das Herz eines Jugendlichen zu brechen genügt es, ihm kein Vertrauen entgegenzubringen.
<G-vec00081-001-s211><break.brechen><en> To break a young person’s heart, it suffices to rebuff his confidence.
<G-vec00081-001-s212><break.brechen><de> SF6-Leistungsschalter ist die Verwendung eines Leistungsschalters des SF6-Gases als Isolier- und Lichtbogenlöschmittel, s ist ein farbloses, geruchloses, ungiftiges und brennbares Gas, seine chemischen Eigenschaften sind ziemlich stabil unter 150 °C, wenn auch hoch Temperatur wird brechen, um giftige Gas Unterbrecher Zustand zu produzieren, und wird eine kleine Menge des Wirkstoffs zu produzieren, aber durch die Verwendung der Adsorptionsmittel und der Kontakt hat eine Selbstreinigung Funktion, Ausrüstung und persönliche wird nicht schaden.
<G-vec00081-001-s212><break.brechen><en> SF6 Circuit Breaker is the use of a circuit breaker of the SF6 gas as the insulating and arc extinguishing medium, s is a colorless, odorless, non-toxic and flammable gases, its chemical properties are fairly stable below 150 ℃, although at a high temperature will break down to produce toxic gas interrupter state, and will produce a small amount of the active substance, but through the use of the adsorbent and the contact has a self-cleaning function, equipment and personal will not cause harm.
<G-vec00081-001-s213><break.brechen><de> Codes des Spiels verlangen, dass sie ihre Stiffs egal wie reich die Schuh-Hit ist in große Karten, die ihn brechen.
<G-vec00081-001-s213><break.brechen><en> Codes of the game require that she hit their stiffs no matter how rich the shoe is in large cards that will break him.
<G-vec00081-001-s214><break.brechen><de> Für uns Hopi ändern sich die Gesetze des Schöpfers niemals, noch brechen sie ein.
<G-vec00081-001-s214><break.brechen><en> For us the Creators laws never change or break down.
<G-vec00081-001-s215><break.brechen><de> Und wie die jungen Demonstranten riefen Achtundsechzig der â Peace and Loveâ mit Eisenstangen in der Hand, warfen Steine â â auf die Polizei und Bomben molotov zwischen einem Schrei der Liebe und der anderen, Heute in der Kirche, Diktatoren wurden in der nachkonziliaren Saison geboren, Menano gesperrt Knie und brechen deine Beine für jeden, der zum Grand dissents Revolution der Barmherzigkeit.
<G-vec00081-001-s215><break.brechen><en> "And as the young protesters shouted Sixty-eight of the ""Peace and Love"" with iron bars in hand, throwing stones at police and bombs molotov between a cry of love and the other, Today in the Church, dictators were born in the post-conciliar season, menano locked knees and break your legs to anyone who dissents to the Grand Revolution of Mercy."
<G-vec00081-001-s216><break.brechen><de> Sie haben eine anstrengende Wirkung auf die Haarwurzeln deiner Haare und es ist eher wahrscheinlich, dass sie an der Wurzel brechen.
<G-vec00081-001-s216><break.brechen><en> These place stress on the roots of your hair, making them more likely to break from the root.
<G-vec00081-001-s217><break.brechen><de> Verwenden Sie die Pfeiltasten zu steuern, beschleunigen und rückwärts und Raum zu brechen.
<G-vec00081-001-s217><break.brechen><en> Use the arrow keys to steer, accelerate and reverse and space to break.
<G-vec00081-001-s218><break.brechen><de> Diese Art der Blume USB-Sticks brechen die sterotype Leute denken, Leder heißt robust, es ist romantisch suchen begrüßen die von den meisten Weibchen oder Künstler.
<G-vec00081-001-s218><break.brechen><en> This kind of flower usb flash drives break the sterotype of people think leather means robust, It's romantic looking welcome by most of the females or artists.
<G-vec00081-001-s219><break.brechen><de> Die Masse der Arbeit, die Sie erledigen, da ein Ebay Verkäufer einfach und sich wiederholend ist, aber es ist die kleinen Details, die bilden oder Ihr Geschäft brechen.
<G-vec00081-001-s219><break.brechen><en> The bulk of the work you do as an Ebay seller will be easy and repetitive, but it is the minor details that will make or break your business.
<G-vec00081-001-s220><break.brechen><de> Mann sollte nicht kauen, zermalmen oder brechen die Testosteron-Tabletten.
<G-vec00081-001-s220><break.brechen><en> Man should not chew, crush or break the Testosterone pills.
<G-vec00081-001-s221><break.brechen><de> Ein revolutionäres, topisches Gel, Ihre Pumpe wird niemals mehr dieselbe sein.- Verbessert Muskulös, um Trough Plateaus zu brechen,-...
<G-vec00081-001-s221><break.brechen><en> A revolutionary topical gel, your pump will never be the same.- Enhances Muscular to Help Break Trough Plateaus,- Helps Flush Muscles by Increasing Blood...
<G-vec00081-001-s222><break.brechen><de> Die Welle vor uns baute sich zu einer furchterregenden Höhe auf und begann über uns zu brechen.
<G-vec00081-001-s222><break.brechen><en> The wave built itself up to a dreadful height, began to break above us and overturned the zodiac.
<G-vec00081-001-s223><break.brechen><de> Wenn wir jemals in friedlichen und gerechten Gemeinschaften leben wollen, müssen wir den Kreis der generationenlangen Kriegsunterweisung für junge Menschen brechen.
<G-vec00081-001-s223><break.brechen><en> If we are to ever live in peaceful and just communities, we must break the cycle of teaching war to young people, generation after generation.
<G-vec00081-001-s224><break.brechen><de> und sollen sie hinabführen in einen kiesigen Grund, der weder bearbeitet noch besät ist, und daselbst im Grund ihr den Hals brechen.
<G-vec00081-001-s224><break.brechen><en> and the elders of that city shall bring down the heifer unto a valley with running water, which is neither plowed nor sown, and shall break the heifer's neck there in the valley.
<G-vec00081-001-s225><break.brechen><de> Die Menschen beurteilen andere Menschen oft nach ihrem äußeren Erscheinungsbild, sie brechen auch manchmal ihre Versprechen, um ihre eigenen selbstsüchtigen Interessen zu schützen.
<G-vec00081-001-s225><break.brechen><en> People sometimes judge others by their appearances, and they sometimes break their promises in order to protect their own selfish interests.
<G-vec00081-001-s226><break.brechen><de> Es ist möglich, das Gerät zu verwurzeln und zu tun, was immer Sie wollen, und die Regeln zu brechen, die standardmäßig eingeschränkt wurden.
<G-vec00081-001-s226><break.brechen><en> It is possible through rooting the device and do whatever you want and break the rules which have been restricted by default.
<G-vec00081-001-s227><break.brechen><de> Diese erlauben uns, den Block des Stolzes und der menschlichen Logik zu brechen; sie helfen uns, ein bedingungsloses Vertrauen auf Gott zu haben.
<G-vec00081-001-s227><break.brechen><en> They help us to break down our pride and human logic, and to have an unconditioned trust in God.
<G-vec00081-001-s228><break.brechen><de> Die Verschärfung des Populismus, der Brexit, die Möglichkeit, dass die neue Verwaltung in Washington die Handelsabkommen mit den Europäern bricht, sind ebensoviele Bedrohungen gegen die Stabilität des Kontinents.
<G-vec00081-001-s228><break.brechen><en> The rise of populism in Europe, the crisis caused by Brexit, the risk that the new administration in Washington might break the trade agreements with Europeans have all been identified by German Chancellor Angela Merkel and the French President Francois Hollande as major threats to Europe's stability.
<G-vec00081-001-s229><break.brechen><de> Die Absonderung von Wadiy, eine dicke, klebrige Substanz, die nach dem Urinieren erscheint, ohne ein Gefühl von körperlicher Freude, bricht das Fasten nicht, und die Person muss kein Ghusl machen, sondern lediglich Istinjā' (die Intimsphäre reinigen) und Wudū' (Fatāwa al-Lajnah al-Dā'imah #10/279).
<G-vec00081-001-s229><break.brechen><en> The emission of wadiy, a thick sticky substance that comes out after urination, with no sense of physical pleasure, does not break the fast, and a person does not have to do ghusl, but he does have to do istinjaa' (clean his private parts) and do wudoo'.
<G-vec00081-001-s230><break.brechen><de> Rufus Wainwright hat Talent zum Verschwenden, den Charme eines Dandys, eine Stimme, die Herzen bricht, und eine große Zukunft vor sich.
<G-vec00081-001-s230><break.brechen><en> Rufus Wainwright has a plethora of talent, the charm of a dandy, a voice that can break your heart and a bright future.
<G-vec00081-001-s231><break.brechen><de> Auch wenn es von einer pragmatischen Einstellung herrührt und direkt auf den Zweck einer Eröffnung hindeutet, will es niemand sehen, dass man mit den Regeln des raffinierten Auftretens bei diesen Veranstaltungen bricht.
<G-vec00081-001-s231><break.brechen><en> Even though it arises from a pragmatic attitude and goes directly to the point in regards to the objective of openings, nobody likes to see when someone tries to break the appearance of the social refinement that these events have.
<G-vec00081-001-s232><break.brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00081-001-s232><break.brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00081-001-s233><break.brechen><de> Gesichts- und Körperbehandlungen Haarentfernung getan, vergessen konventionellen Techniken enthaaren mit Gewinde und fühlt sich anders an, bricht nicht die Haarwurzel extrahiert sie, verlangsamt das Wachstum...
<G-vec00081-001-s233><break.brechen><en> Facial and body waxing is done, forget conventional techniques depilate with thread and feels different, does not break the hair root extracts it, retards growth...
<G-vec00081-001-s234><break.brechen><de> Der 32-jährige Fotograf aus Miesbach im Voralpenland hält sich selbst für heimatverbunden und traditionsbewusst, aber in seinen Fotografien bricht er mit den üblichen Klischees.
<G-vec00081-001-s234><break.brechen><en> The 32-year-old photographer from Miesbach (Upper Bavaria) regards himself as patriotic and aware of his tradition; his photographs, however, break the usual clichés.
<G-vec00081-001-s235><break.brechen><de> Wenn einige Bedürfnisse 10 mm Fliesen, die Blöcke in der Dicke geschnitten, von 15 Millimeter (weniger als diese, die Platte bricht), wenn Sie brauchen 20 mm Fliesen, wir schneiden Sie die Blöcke in 20 mm Dicke und wenn Ihre Anforderung ist 30 mm Fliese, wir schneiden Sie es in 30 mm Dicke.
<G-vec00081-001-s235><break.brechen><en> If some needs 10 mm tiles, the blocks are cut in the thickness of 15 mm (less than this, the slab will break), if you need 20 mm tiles, we cut the blocks in 20 mm thickness and if your requirement is 30 mm tile, we will cut it in 30 mm thickness.
<G-vec00081-001-s236><break.brechen><de> Aber nur aus dieser Nacht bricht die Morgenröte der Auferstehung an.
<G-vec00081-001-s236><break.brechen><en> Yet only from that night do we see the dawn of the resurrection break forth.
<G-vec00081-001-s237><break.brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00081-001-s237><break.brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00081-001-s238><break.brechen><de> Takashi Miike ist dafür bekannt, dass er in seinen Filmen mit großer Entschlossenheit Tabus bricht und bei der Darstellung von Gewalt keine Rücksichten kennt.
<G-vec00081-001-s238><break.brechen><en> Japanese director Takashi Miike is well known for films that make a decisive break with taboos and conventions, and for his ruthlessly graphic portrayal of violence.
<G-vec00081-001-s239><break.brechen><de> Bent Nadel bricht, wenn die Nadel die Platte berührt.
<G-vec00081-001-s239><break.brechen><en> Bent needle will break, if the needle touches the plate.
<G-vec00081-001-s240><break.brechen><de> 7 Jetzt ruht die ganze Erde und ist still; man bricht in Jubel aus.
<G-vec00081-001-s240><break.brechen><en> 7 The whole earth is at rest and quiet; they break forth into singing.
<G-vec00081-001-s241><break.brechen><de> Die zusätzlichen Pfunde, die für die Beschaffung eines Gegenstandes aufgewendet werden, werden sich im Laufe der Zeit wiederholen, wenn dieser Gegenstand nicht bricht.
<G-vec00081-001-s241><break.brechen><en> Those extra pounds spent procuring an item will replay themselves over time when that item doesn't break.
<G-vec00081-001-s242><break.brechen><de> Weiter draußen befindet sich ein Riff, wo eine schöne, moderate Welle bricht, wer`s mag.
<G-vec00081-001-s242><break.brechen><en> Further outside there's a reef where moderate waves break.
<G-vec00081-001-s243><break.brechen><de> Nachdem es zu gebogenem Isolierglas verarbeitet wurde, ist es in der Glasarchitektur weit verbreitet, auch wenn das Glas bricht, zerbricht es in kleine, stumpfe Bruchstücke, wodurch die Verletzungsgefahr verringert wird.
<G-vec00081-001-s243><break.brechen><en> After being processed into curved insulated glass, it is widely used in glass architecture, even if the glass break, it will shatter into small blunt fragments reducing the risk of injury.
<G-vec00081-001-s244><break.brechen><de> Sie bricht mein Herz.
<G-vec00081-001-s244><break.brechen><en> It makes my heart break.
<G-vec00081-001-s245><break.brechen><de> Danach legt man den seitlich integrierten Brechstempel einfach um und bricht die Fliese damit sauber an der vorhandenen Ritzlinie – alles in einem Arbeitsschritt.
<G-vec00081-001-s245><break.brechen><en> Then you simply fold down the breaking stamp integrated into the sides and use it to break the tile cleanly at the scoring line – all in one step.
<G-vec00081-001-s246><break.brechen><de> Zusätzlich dazu sind viele Konten, die zum Verkauf stehen, gestohlen und die Spieler, die Konten teilen, gehen das Risiko ein, dass die Person das ausgeliehene Konto nicht wieder zurückgibt oder dass die Person eine Regel des Spiels bricht und das Konto gesperrt oder stummgeschaltet wird, wofür dann der Kontoinhaber haften muss.
<G-vec00081-001-s246><break.brechen><en> Additionally, many of the accounts on sale are stolen, and people who share accounts run the risk that the person using the account won't give it back, or that the person will break a game rule causing the account to be banned or muted for which the account creator will be accountable.
<G-vec00081-001-s304><break.brechen><de> Die Nägel beginnen sloitsja, das Haar - gebrochen zu werden und auszufallen.
<G-vec00081-001-s304><break.brechen><en> Nails start exfoliating, hair - to break and drop out.
<G-vec00081-001-s305><break.brechen><de> Sehr oft können beim Beugen fuchs- mit dem Knirschen gebrochen werden, und in einigen Fällen werden sie bei der Kompression nicht zerknittert.
<G-vec00081-001-s305><break.brechen><en> Very often when bending the fox can break with a crunch, and in certain cases they are not rumpled at compression.
<G-vec00081-001-s306><break.brechen><de> Das große Riemenrad ist bei einigen Fahrzeugen gebrochen, vor allem natürlich bei Fahrzeugen mit aufgedrehtem Ankerstrom (Drehmoment).
<G-vec00081-001-s306><break.brechen><en> The large belt wheel break, particularly in vehicles with more armature current (torque).
<G-vec00081-001-s307><break.brechen><de> Wenn die israelischen Zionisten Resolutionen zuhauf brechen, dann ist das kein Grund, aber wenn ein- oder zweimal eine Resolution gebrochen wird durch eine Organisation wie Hizbollah, dann ist das ein Grund, nicht etwa vorwiegend die Hizbollah, sondern das ganze libanesische Volk auf das Brutalste zu terrorisieren.
<G-vec00081-001-s307><break.brechen><en> If the Zionists break resolutions in throngs, this is no reason to behave, but if there is a break of a resolution once or twice by an organization like Hizbollah, this is a reason to terrorize in the most brutal way – not Hizbollah in the first place, but the whole Lebanese people.
<G-vec00081-001-s308><break.brechen><de> "Die Siegelabdrücke wurden meist als Monogramme, manchmal auch als geheimnisvolle Symbole angebracht und durften nur von bestimmten Personen ""gebrochen"" (geöffnet) werden."
<G-vec00081-001-s308><break.brechen><en> Mostly the seal was a monogram or sometimes a mysterious symbol and only a certain person was permitted to break the seal.
<G-vec00081-001-s309><break.brechen><de> Sollten ihre Gegnerinnen nicht absolut gelenkig sein, wird ihnen das Genick gebrochen, während Cindy auf ihren Gesicht sitzt.
<G-vec00081-001-s309><break.brechen><en> In case that her opponents have limited snake skills, they might easily break a neck while Cindy sits on their face.
<G-vec00081-001-s310><break.brechen><de> "Palmer weist darauf hin, dass Cannon, nachdem er 1925 mit Foster gebrochen hatte, für das Primat des Programms über die Fraktion argumentierte und darauf bestand, dass Abstimmungen stattfinden sollten über die „politische Hauptlinie, egal wer dafür und wer dagegen ist""."
<G-vec00081-001-s310><break.brechen><en> "Palmer points to the fact that Cannon, after his 1925 break with Foster, argued for the primacy of program over faction and insisted that votes should be taken on the ""main political line, regardless of who is for or against."""
<G-vec00081-001-s311><break.brechen><de> """Ich habe wirklich alle Regeln gebrochen."
<G-vec00081-001-s311><break.brechen><en> """I did break all the rules."
<G-vec00081-001-s312><break.brechen><de> Bei epiljazii auf der hohen Geschwindigkeit fein woloski werden nicht herausgezogen, wie es sein soll, und einfach werden gebrochen.
<G-vec00081-001-s312><break.brechen><en> At an epilation at a high speed thin hairs are not pulled out as it has to be, and simply break.
<G-vec00081-001-s313><break.brechen><de> Die Box hat einen riesigen Schaden der Post, nicht gebrochen, aber die...
<G-vec00081-001-s313><break.brechen><en> The box took a huge damage of post office, but did not break the...
<G-vec00081-001-s314><break.brechen><de> Egal ob gebrochen wird oder nicht, gebrochene Keramik gibt es immer in Fülle (wie der Brand, so ist auch das Brechen überflüssig).
<G-vec00081-001-s314><break.brechen><en> Whether we break them ourselves or not, there are always lots of broken ceramics about (as it is unnecessary to fire, so it is to break), and all of them are excellent.
<G-vec00081-001-s315><break.brechen><de> Womit ich nichts anfangen kann ist, wenn die Shinobi, darunter vor allem Goemon, hunderte von Meter weit springen und physikalische Gesetze nicht nur etwas gedehnt wurden, sondern schlichtweg gebrochen werden.
<G-vec00081-001-s315><break.brechen><en> What I can't bear, however, is when the shinobi, among them Goemon first of all, jump several hundreds of meters and not only stretch all laws of physics, but outright break them.
<G-vec00081-001-s316><break.brechen><de> werden die gut ausgetrockneten Pilze ein wenig gebogen, werden leicht gebrochen, aber bröckeln nicht ab.
<G-vec00081-001-s316><break.brechen><en> Well dried up mushrooms slightly bend, easily break, but do not crumble.
<G-vec00081-001-s317><break.brechen><de> "Aufrufe, die Firmen oder Regierungen in Ländern wie den USA oder Kanada unter Druck setzen sollen, damit sie gegen die israelische Regierung eine Seite mit den Palästinensern beziehen, verstärken genau die Illusionen in ""demokratischen"" Imperialismus, von denen junge Aktivisten und militante Arbeiter so dringend gebrochen werden müssen."
<G-vec00081-001-s317><break.brechen><en> "Calls to pressure corporations and governments in countries like the U.S. or Canada to take the side of the Palestinians against the Israeli government reinforce the very illusions in ""democratic"" imperialism from which young activists and working-class militants desperately need to break."
<G-vec00081-001-s318><break.brechen><de> Nur so kann der Zauber gebrochen werden.
<G-vec00081-001-s318><break.brechen><en> This is the only way to break the spell.
<G-vec00081-001-s319><break.brechen><de> 126 Es ist Zeit für Jehova zu handeln: sie haben dein Gesetz gebrochen.
<G-vec00081-001-s319><break.brechen><en> 126 It is time to act, LORD,for they break your Torah.
<G-vec00081-001-s320><break.brechen><de> Gefragt, warum sie uns herauspicken und kontrollieren, bekommt man für gewöhnlich von Seiten der Polizei zu hören: „Es ist unser Job, dich zu kontrollieren“, „Wir haben das Recht, dich zu überprüfen“ und: „Wir suchen Kriminelle, die das Gesetz gebrochen haben“.
<G-vec00081-001-s320><break.brechen><en> When asked why we are being singled out and controlled, the police reply is usually “it is our job to control you”, “we have the right to check you”, and “we are looking for criminals who break the law”.
<G-vec00081-001-s321><break.brechen><de> Nachdem das Volk den Bund gebrochen hatte, zeigte sich Gott vor Mose in einer Wolke, um jenen Bund zu erneuern, wobei er seinen Namen und dessen Bedeutung kundtat.
<G-vec00081-001-s321><break.brechen><en> When the people break the covenant, God presents himself to Moses in the cloud in order to renew that pact, proclaiming his own name and its meaning.
<G-vec00081-001-s322><break.brechen><de> Es muss der Griff der Einsamkeit gebrochen, der Solidarität und Zusammenarbeit Raum gegeben und neuen kollektiven Subjekten neues Leben verliehen werden, um das Leben von Gesellschaften und das Funktionieren von Institutionen hin zu einem sozialen Zusammenhalt und einem wirtschaftlichen und kulturellen Fortschritt auszurichten.
<G-vec00081-001-s322><break.brechen><en> For these reasons, it is more necessary than ever to strengthen the associative realities consolidated by a long experience, and those that can find new flowering and development, to break the grip of solitude, make room for solidarity and collaboration, and give life to new collective subjects to orient the life of societies and the functioning of institutions on the way of social cohesion and economic and cultural progress.
<G-vec00213-002-s019><idle.brechen><de> Trotz des fortgeschrittenen Produktionsstadiums wurden die Filmarbeiten eingestellt und die Sets lagen brach.
<G-vec00213-002-s019><idle.brechen><en> Despite the advanced state of production, the film was scrapped and the sets lay idle.
<G-vec00213-002-s020><idle.brechen><de> Möglichkeiten, Geld zu verdienen, gibt es für die meisten Menschen kaum noch: Fabriken sind geschlossen, der Handel mit Nachbarländern findet nicht mehr statt und die Landwirtschaft liegt brach.
<G-vec00213-002-s020><idle.brechen><en> For the majority of people, opportunities to earn money are scarce: Factories are closed, trade with neighbouring countries no longer takes place and agriculture lies idle.
<G-vec00213-002-s021><idle.brechen><de> Der Blog liegt selbstverständlich auch nicht brach, denn, so sehr wir uns auf fünf Tage ‚Dauerfeuer‘ freuen – niemals würden wir deswegen unsere geliebte Platform hier vernachlässigen.
<G-vec00213-002-s021><idle.brechen><en> Of course, the blog will not lie idle, as well. ‘Cause as much as we do look forward to five days of ‘Team No Sleep’ – we’d never neglect our much loved platform because of that.
<G-vec00213-002-s022><idle.brechen><de> Gründe dafür: die Reduktion der Anbauflächen um 3 Millionen Hektar; Gebiete, deren Boden von den 13 Millionen Minen verseucht ist, die die Deutschen zurückgelassen haben; das Verschwinden eines Drittels der Zugpferde, die von den Deutschen beschlagnahmt wurden; der Mangel an Düngemitteln, der für die Ernten verheerende Folgen hat, aber auch der Mangel an Arbeitskräften, der mit sich bringt, dass viele Flächen brach liegen.
<G-vec00213-002-s022><idle.brechen><en> The reason for this was the 3 million drop in the number of hectares being cultivated; stretches of land infested with the 13 million mines left by the Germans; the disappearance of one third of work horses, requisitioned by the Germans; the shortage of fertilizer, a fatal blow to crop yields, but also that the shortage of labour with numerous fields lying idle.
<G-vec00213-002-s023><idle.brechen><de> Es wurden woanders neue Hafeneinrichtungen gebaut, und die Docklands lagen nahezu brach, bis dort 1981 ein Entwicklungsprogramm initiiert wurde.
<G-vec00213-002-s023><idle.brechen><en> New facilities were built elsewhere, and the Docklands almost lay idle, until a development programme was initiated there in 1981.
<G-vec00213-002-s024><idle.brechen><de> Eine Lösung in Form einer europäischen Neuregelung des Common European Asylum System (CEAS) liegt seit langer Zeit brach, weil die Mitgliedsstaaten sich nicht einigen konnten.
<G-vec00213-002-s024><idle.brechen><en> A solution in the form of a new European regulation of the Common European Asylum System (CEAS) has been lying idle for a long time because the member states could not reach agreement.
<G-vec00218-002-s171><break.brechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00218-002-s171><break.brechen><en> HSL break the body fat shops within your cells.
<G-vec00218-002-s173><break.brechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00218-002-s173><break.brechen><en> Q Right – but you don’t break his nose.
<G-vec00218-002-s175><break.brechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00218-002-s175><break.brechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00218-002-s176><break.brechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00218-002-s176><break.brechen><en> The part could break without warning (see figure 80).
<G-vec00218-002-s177><break.brechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00218-002-s177><break.brechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00218-002-s178><break.brechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00218-002-s178><break.brechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00218-002-s179><break.brechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00218-002-s179><break.brechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00218-002-s180><break.brechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00218-002-s180><break.brechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00218-002-s181><break.brechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00218-002-s181><break.brechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00218-002-s182><break.brechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00218-002-s182><break.brechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00218-002-s183><break.brechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00218-002-s183><break.brechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00218-002-s184><break.brechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00218-002-s184><break.brechen><en> HSL break the fat stores within your cells.
<G-vec00218-002-s185><break.brechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00218-002-s185><break.brechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00218-002-s186><break.brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00218-002-s186><break.brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00218-002-s187><break.brechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00218-002-s187><break.brechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00218-002-s188><break.brechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00218-002-s188><break.brechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00218-002-s189><break.brechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00218-002-s189><break.brechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
<G-vec00279-002-s186><break.brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00279-002-s186><break.brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00280-002-s152><break.brechen><de> Sie verbleiben entweder vom Knochen bedeckt im Kiefer (Retention) oder brechen teilweise durch (Teilretention).
<G-vec00280-002-s152><break.brechen><en> They remain in the jaw covered by bone (referred to as impaction) or break through only partially (partial impaction).
<G-vec00280-002-s153><break.brechen><de> Wer nicht dazu geneigt ist oder gar widersteht, macht den schmerzhaften Prozess durch, gebrochen zu werden, denn „biegen oder brechen“ ist die Schlüsselnote der Wassermann-Energie.
<G-vec00280-002-s153><break.brechen><en> Those who are not ready or who resist, are put through the painful process of breaking, for „bend or break” is the keynote of the Aquarian energy.
<G-vec00280-002-s154><break.brechen><de> Sie sorgen sich um uns, vertrauen uns und so werden wir unser Versprechen nicht brechen.
<G-vec00280-002-s154><break.brechen><en> You cared about us, trust us, and we will not break our promise.
<G-vec00280-002-s155><break.brechen><de> Wenn du ein Carbonfaser-Teil beschädigst, könnte es brechen oder die Beschädigung nicht auf den ersten Blick zu erkennen sein.
<G-vec00280-002-s155><break.brechen><en> When you damage a carbon fiber part, it could break or it could conceal damage from the naked eye.
<G-vec00280-002-s156><break.brechen><de> 31,16 Und der HERR sprach zu Mose: Siehe, du wirst schlafen bei deinen Vätern, und dies Volk wird sich erheben und nachlaufen den fremden Göttern des Landes, in das sie kommen, und wird mich verlassen und den Bund brechen, den ich mit ihm geschlossen habe.
<G-vec00280-002-s156><break.brechen><en> Behold, thou shalt sleep with thy fathers; and this people will rise up, and go a whoring after the gods of the strangers of the land, whither they go to be among them, and will forsake me, and break my covenant which I have made with them.
<G-vec00280-002-s157><break.brechen><de> Es ist bekannt, dass es eine Reihe von möglichen Einschränkungen von CRISPR gibt, die das verursachen können, was wir "Off-Target-Effekte" nennen - wo es im Grunde genommen nicht nur das, was man brechen will, sondern auch etwas anderes in seinem Genom brechen kann.
<G-vec00280-002-s157><break.brechen><en> It’s well known that there are a series of potential limitations of CRISPR that can cause what we call “off-target effects”—where basically in addition to breaking what you want to break, it can break something else in your genome.
<G-vec00280-002-s159><break.brechen><de> Der Versuch geht nicht darum, Burts Rekord zu brechen, sondern darum sein Erbe zu würdigen.
<G-vec00280-002-s159><break.brechen><en> The attempt is not to break Burt’s record, but to appreciate his legacy.
<G-vec00280-002-s160><break.brechen><de> Die Schlaghämmer leiten die Energie in das Bauteil und brechen den Kern.
<G-vec00280-002-s160><break.brechen><en> The impact hammers conduct energy into the component and break up the core.
<G-vec00280-002-s161><break.brechen><de> Bringen Sie ein Glas Nadel auf die Mikroinjektor und nutzen Sie Ihre Zange an der Spitze der Nadel auf die gewünschte Breite zu brechen.
<G-vec00280-002-s161><break.brechen><en> Attach a glass needle onto the microinjector and use your forceps to break the tip of the needle to the desired width.
<G-vec00280-002-s162><break.brechen><de> Sie deutet darauf hin, dass die Installation eines Paketes ein anderes Paket (oder bestimmte Versionen davon) „brechen“ wird.
<G-vec00280-002-s162><break.brechen><en> It signals that the installation of a package will “break” another package (or particular versions of it).
<G-vec00280-002-s163><break.brechen><de> Zerquetschen Sie es, kauen Sie es, oder brechen Sie die Pillen nicht.
<G-vec00280-002-s163><break.brechen><en> Do not crush, chew, or break the tablet.
<G-vec00280-002-s164><break.brechen><de> Hazem Kassem, ein Sprecher im Namen der Hamas, sagte, dass das palästinensische Volk vor dem ersten Jahrestag der “Prozessionen” vorhatte, anlässlich des “Tag der Erde” mit der “Prozession der Millionen” an Land zu brechen, um die Hauptziele der “Prozessionen der großen Rückkehr” zu erfüllen.
<G-vec00280-002-s164><break.brechen><en> Hamas spokesman Hazem Qassem said that with the approach of the first anniversary of the “return marches,” the Palestinian people were planning to break [into Israeli territory] with the “million-man march” on Land Day to stress the main objectives of the marches.
<G-vec00280-002-s165><break.brechen><de> Zeitgleich wird die in das Bauteil eingebrachte Hammerenergie dazu verwendet, den Kernsand im Bauteil zu brechen, um diesen anschließend herausrütteln zu können.
<G-vec00280-002-s165><break.brechen><en> At the same time, the hammer energy introduced into the component is used to break up the core sand in the component, so this can subsequently be shaken out.
<G-vec00280-002-s166><break.brechen><de> Sie ist in mehr oder minder radikalmarxistischen Bewegungen zusammengefaßt, entschlossen, jeden geistigen Widerstand durch die Macht der Gewalt zu brechen.
<G-vec00280-002-s166><break.brechen><en> It is organized in more or less radical Marxist movements, determined to break all spiritual resistance by the power of violence.
<G-vec00280-002-s167><break.brechen><de> Nur zu schauen sei er gekommen, antwortet Wotan, nicht zu schaffen – und Alberich erinnert seinerseits daran, daß er den Vertrag mit Fafner nicht brechen dürfe, der ja den Ring und den gesamten Schatz als Bezahlung für die Errichtung Walhalls und die Freilassung der Göttin Freia erhalten habe.
<G-vec00280-002-s167><break.brechen><en> Wotan tells him that he comes only to watch, since he cannot, as Alberich reminds him, break his agreement with Fafner, who had been given the ring and other treasure in return for the release of the goddess Freia.
<G-vec00280-002-s168><break.brechen><de> Wir hoffen ein neues Brechen des Bohrkabels durch langsameres Bohren verhindern zu können.
<G-vec00280-002-s168><break.brechen><en> We hope to avoid a new break of the wireline by running it a little bit slower.
<G-vec00280-002-s169><break.brechen><de> Er würde alles tun, alles, um das zu brechen, was er den Aberglauben des Kreuzes nennt.
<G-vec00280-002-s169><break.brechen><en> He would do anything, anything, to break what he calls the superstition of the Cross.
<G-vec00280-002-s170><break.brechen><de> Zerquetschen Sie nicht, kauen Sie, brechen Sie, oder öffnen Sie eine Kapsel der verlängerten Ausgabe.
<G-vec00280-002-s170><break.brechen><en> Do not crush, chew, break, or open an extended-release capsule.
<G-vec00372-002-s056><disrupt.brechen><de> Klärende Verständnisfragen werden bei ausweichenden oder widersprüchlichen Antworten angewandt und brechen Alltagsselbstverständlichkeiten der Interviewten auf.
<G-vec00372-002-s056><disrupt.brechen><en> Clarifying questions for understanding are utilized in case of evasive or contradictory responses and disrupt that which is self-evident in daily life.
<G-vec00372-002-s057><disrupt.brechen><de> Nach aktuellem Stand steht die Energieunion dem Ausbau der Erneuerbaren Energien als „Graswurzelbewegung“ eher entgegen; und das, obwohl Prosumer wichtige Beiträge für die Erreichung der Ziele der Energieunion leisten: Sie fördern den Wettbewerb sowie die Diversifizierung der Erzeugungskapazitäten und des Energiemix, sie brechen Marktkonzentrationen und Energieoligopole auf und sie senken die Großhandelspreise.
<G-vec00372-002-s057><disrupt.brechen><en> The current status of the Energy Union opposes the expansion of renewable energies as “grassroot-movement” though prosumers are contributing significantly to the achievement of the energy union’s goals: they boost competition and the diversification of the generation capacities and the energy mix. They disrupt market concentration and energy oligopolies and they lower the wholesale market prices.
<G-vec00372-002-s058><disrupt.brechen><de> Des Weiteren würde dies die Preisstruktur für Aktionäre und Mitglieder brechen.
<G-vec00372-002-s058><disrupt.brechen><en> Furthermore, this would disrupt the price structure for Shareholders and Members.
<G-vec00389-002-s039><crush.brechen><de> Wir brechen mit unserem Steinbrechern der PTH Crusher & PTH Multi Crusher Serie ebenfalls problemlos Betonverbundpflaster, Asphaltbeläge oder Schotter auf Bahntrassen.
<G-vec00389-002-s039><crush.brechen><en> We also crush concrete compound paving stones or railway track ballast without any problems with our rock breaker, the PTH crusher.
<G-vec00389-002-s040><crush.brechen><de> · In der PEA wird angenommen, dass etwa 78 Prozent der Tonnage des mineralisierten Materials mittels Brechen und Anhäufung und die restlichen 22 Prozent mittels Förderverarbeitung behandelt werden.
<G-vec00389-002-s040><crush.brechen><en> · The PEA assumes treatment of approximately 78% of the mineralized material tonnage by crush and agglomeration, with the remaining 22% treated as run-of-mine.
<G-vec00389-002-s041><crush.brechen><de> Unfähig, die Spiritualität von Millionen zu brechen, die eine verbesserte Gesundheit und eine Verbesserung der Lebensqualität durch Falun Gong bekommen haben, hat Jiangs Regime seine Propagandakampagne entfacht, um die öffentliche Meinung gegen die Praxis aufzubringen, während es heimlich jene die es praktizieren einsperrt, foltert und zu Tode bringt.
<G-vec00389-002-s041><crush.brechen><en> Unable to crush the spirit of millions who had experienced improved health and positive life changes from Falun Gong, Jiang’s regime has intensified its propaganda campaign to turn public opinion against the practise while quietly imprisoning, torturing and even murdering those who practise it.
<G-vec00389-002-s042><crush.brechen><de> Im Mininggeschäft setzt Mario Sinacola & Sons die Maschinen bereits seit Jahren erfolgreich zum Abbau von Nutzmineralien ein, denn Wirtgen Surface Miner schneiden, brechen und verladen das Material in einem Arbeitsgang.
<G-vec00389-002-s042><crush.brechen><en> In mining business, Mario Sinacola & Sons have already successfully used the machines to mine pay minerals for many years, for Wirtgen surface miners cut, crush and load the material in a single operation.
<G-vec00389-002-s043><crush.brechen><de> Alle GT Probe-, RAB-, RC- und Diamantkernproben wurden mit dem Verfahren PRP70-250 (Brechen, Spalten und Pulverisieren von 250 g bis 200 mesh) hergestellt und mit der Methode FA430 (30g Brandprobe mit AAS-Finish) und AQ200 (0,5g, Aqua Regia-Aufschluss und ICP-MS-Analyse) analysiert.
<G-vec00389-002-s043><crush.brechen><en> All GT Probe, RAB, RC, and diamond core samples were prepared using procedure PRP70-250 (crush, split and pulverize 250 g to 200 mesh) and analyzed by method FA430 (30g fire assay with AAS finish) and AQ200 (0.5g, aqua regia digestion and ICP-MS analysis).
<G-vec00389-002-s044><crush.brechen><de> Eisbrecher haben eine andere Form - sie sind runder: anders als gedacht "teilen" Eisbrecher die Eisfläche nicht mit dem Bug; sondern "schieben" sich darauf um es mit ihrem immensen Gewicht nach unten zu brechen.
<G-vec00389-002-s044><crush.brechen><en> For a reason: unlike you might think, icebreakers do not forcefully "split" open the ice, but they "slide" on top of the iceshield and crush it down with their immense weight.
<G-vec00389-002-s045><crush.brechen><de> Das hochgradige, weiche, mittels freier Grabungen zugängliche Saprolitherz, das kein primäres Brechen oder Zerkleinern erfordert, führt zusammen mit einem einfachen und bewährten Fließschema zu einer geringen Kapitalintensität und extrem niedrigen Betriebskosten.
<G-vec00389-002-s045><crush.brechen><en> The high-grade, soft, free-dig saprolite-hosted ore, requiring no primary crush or grind combined with a simple and proven flowsheet results in low capital intensity and extremely low operating costs.
<G-vec00389-002-s046><crush.brechen><de> Ihr Panzer, genannt Fighting Girlfriend (wurde nach Smolensk beordert, um den deutschen Widerstand zu brechen.
<G-vec00389-002-s046><crush.brechen><en> Her tank, the Fighting Girlfriend (was sent to Smolensk to crush German resistance.
<G-vec00389-002-s047><crush.brechen><de> Brechen Sie die Tablette nicht.
<G-vec00389-002-s047><crush.brechen><en> Do not crush the tablet.
<G-vec00296-003-s171><break_down.brechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00296-003-s171><break_down.brechen><en> HSL break the body fat shops within your cells.
<G-vec00296-003-s172><break_down.brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00296-003-s172><break_down.brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00296-003-s173><break_down.brechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00296-003-s173><break_down.brechen><en> Q Right – but you don’t break his nose.
<G-vec00296-003-s174><break_down.brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00296-003-s174><break_down.brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00296-003-s175><break_down.brechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00296-003-s175><break_down.brechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00296-003-s176><break_down.brechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00296-003-s176><break_down.brechen><en> The part could break without warning (see figure 80).
<G-vec00296-003-s177><break_down.brechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00296-003-s177><break_down.brechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00296-003-s178><break_down.brechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00296-003-s178><break_down.brechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00296-003-s179><break_down.brechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00296-003-s179><break_down.brechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00296-003-s180><break_down.brechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00296-003-s180><break_down.brechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00296-003-s181><break_down.brechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00296-003-s181><break_down.brechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00296-003-s182><break_down.brechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00296-003-s182><break_down.brechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00296-003-s183><break_down.brechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00296-003-s183><break_down.brechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00296-003-s184><break_down.brechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00296-003-s184><break_down.brechen><en> HSL break the fat stores within your cells.
<G-vec00296-003-s185><break_down.brechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00296-003-s185><break_down.brechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00296-003-s186><break_down.brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00296-003-s186><break_down.brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00296-003-s187><break_down.brechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00296-003-s187><break_down.brechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00296-003-s188><break_down.brechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00296-003-s188><break_down.brechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00296-003-s189><break_down.brechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00296-003-s189><break_down.brechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
