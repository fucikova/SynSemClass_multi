<G-vec00185-001-s037><catch.aufholen><de> Irgendwann, und dem restlichen Russland ist beginnend mit der Hauptstadt, aber immer noch das aufholen ist langsamer und es gibt noch einen Unterschied.
<G-vec00185-001-s037><catch.aufholen><en> At some point, and the rest of Russia is beginning to catch up with the capital, but still this is slower and there is still a difference.
<G-vec00185-001-s038><catch.aufholen><de> """Nach der bevorstehenden EU-Erweiterung werden Rumänien und Bulgarien sicher rasch aufholen."
<G-vec00185-001-s038><catch.aufholen><en> """Following the forthcoming EU enlargement, I expect Romania and Bulgaria to catch up quickly."
<G-vec00185-001-s039><catch.aufholen><de> Wenn man wie der 25-Jährige aber schon so lange und so weit seiner Zeit voraus ist, dann kann man die Konkurrenz ganz zurückgelehnt auch mal etwas aufholen lassen – und mit einer kleinen EP wie dieser trotzdem vorlegen.
<G-vec00185-001-s039><catch.aufholen><en> But when someone is so far ahead of his time, and always has been, as it's the case with the 25-year-old rapper, it's alright to lean back and allow the competitors to catch up – and at the same time, he still defends his grounds, like with this little EP.
<G-vec00185-001-s040><catch.aufholen><de> Um anhaltendes Chaos zu vermeiden, und die Wirtschaft weiter wachsen zu lassen, sendete die Regierung von Panama einen Hilferuf aus, um schnelle, zuverlässige, kostengünstige Stromversorgung auf Zeit zu finden, bis das dauerhafte Energienetz aufholen konnte.
<G-vec00185-001-s040><catch.aufholen><en> To avoid the ongoing havoc and keep the economy growing, the Panamanian Government sent out an SOS to find quick, reliable, cost-effective interim power until the permanent energy grid could catch up.
<G-vec00185-001-s041><catch.aufholen><de> Über kurz oder lang werden die Digitalkameras hier sicher aufholen, zumal bei Digitalkameras ja im Gegensatz zu der eher konservativen Scanner-Industrie erheblich in Forschung und Entwicklung investiert wird.
<G-vec00185-001-s041><catch.aufholen><en> Sooner or later digital cameras will catch up, since there is a lot of research and development spended in digital cameras compared to scanners. in one point the photographing method is leading: The speed is significantly higher compared to a classic scan.
<G-vec00185-001-s042><catch.aufholen><de> Das Unternehmen geht davon aus, im zweiten Halbjahr bei der Leistung aufholen zu können und dass sich damit auch das Ergebnis besser entwickelt.
<G-vec00185-001-s042><catch.aufholen><en> The company expects to catch up with revenues in the second half of the year and that the earnings will also be better.
<G-vec00185-001-s043><catch.aufholen><de> Aber das Bewusstsein kann mit einem Ruck aufholen – das ist die wahre Bedeutung einer Revolution.
<G-vec00185-001-s043><catch.aufholen><en> But consciousness can catch up with a bang. That is the real meaning of a revolution.
<G-vec00185-001-s044><catch.aufholen><de> Sonos blieb konsequent auf Kurs und setzte auf Systeme und Technologien der nächsten Generation in der Überzeugung, dass die Verbraucher aufholen würden.
<G-vec00185-001-s044><catch.aufholen><en> Sonos determinedly stayed the course, making key bets on next-generation systems and technologies with the conviction that consumers would catch up.
<G-vec00185-001-s045><catch.aufholen><de> Das dritte Viertel konnten die Gäste mit 20:18 knapp für sich entscheiden, aber nicht entscheidend aufholen.
<G-vec00185-001-s045><catch.aufholen><en> The guests were able to win the third quarter with 20:18, but did not catch up decisively.
<G-vec00185-001-s046><catch.aufholen><de> Wenn die Hypothek wird, früher oder spГ¤ter BГ¤nde der regionalen Markt aufholen Hauptstadt Indikatoren und der Markt wird es sehr attraktiv, und daher hart umkГ¤mpft.
<G-vec00185-001-s046><catch.aufholen><en> If the mortgage will, sooner or later volumes of the regional market will catch up capital indicators, and the market it will be very attractive, and therefore highly competitive.
<G-vec00185-001-s047><catch.aufholen><de> Man schaut, wie sich die anderen kultiviert haben und wie wir selbst aufholen können.
<G-vec00185-001-s047><catch.aufholen><en> Seeing how others cultivate, we should figure out how we can catch up.
<G-vec00185-001-s048><catch.aufholen><de> Wir müssen etwas aufholen.
<G-vec00185-001-s048><catch.aufholen><en> We need to catch up a bit.
<G-vec00185-001-s049><catch.aufholen><de> Einer der Hauptgründe war, war es unvergesslich die Fähigkeit, auf dem Boot für eine schöne Fahrt zu gehen und eine ganze Reihe von Schwarzbarsch aufholen.
<G-vec00185-001-s049><catch.aufholen><en> One of the main reasons it was unforgettable was the ability to go out for a nice ride on the boat and catch up a whole bunch of smallmouth bass.
<G-vec00185-001-s050><catch.aufholen><de> Nicht nur im Bereich IT, sondern besonders auch im Bereich Nachhaltigkeit muss der Handel noch weiter aufholen - zu viele Einsparmöglichkeiten und Ressourcen sparende Potenziale liegen hier brach.
<G-vec00185-001-s050><catch.aufholen><en> Retail still needs to catch up in the IT sector, but also in terms of sustainability – huge potential savings in money and resources are laying idle here.
<G-vec00185-001-s051><catch.aufholen><de> Der deutschsprachige Münzhandel stellt traditionell einen großen Teil der Aussteller auf der New York International, wobei in den letzten Jahren vor allem Spanien und Italien aufholen.
<G-vec00185-001-s051><catch.aufholen><en> The German coin trade by tradition makes up a large part of the exhibitors at the New York International, although Italy and Spain in particular have started to catch up in recent years.
<G-vec00185-001-s052><catch.aufholen><de> Harrison war aber schneller und konnte schon 1,4 Sekunden aufholen.
<G-vec00185-001-s052><catch.aufholen><en> Harrison was faster and was able to catch up for 1.4 seconds.
<G-vec00185-001-s053><catch.aufholen><de> Gehen Sie den Hügel hinunter und Hilfe Scooby aufholen shaggy.
<G-vec00185-001-s053><catch.aufholen><en> Go down the hill and help Scooby catch up with shaggy.
<G-vec00185-001-s054><catch.aufholen><de> Wie Intel Low-Power-Chips kommen in mehr Geräte, mehr App-Hersteller werden für sie optimieren, und die großen Spieler (die machen die begehrtesten Anwendungen) werden wahrscheinlich schnell aufholen.
<G-vec00185-001-s054><catch.aufholen><en> As Intel low-power chips appear in more devices, more app producers will optimize for them, and the big players (who make the most desirable apps) are likely to catch up quickly.
<G-vec00185-001-s055><catch.aufholen><de> Es war gut, sich über die neuesten Marketing-Trends kennen 2018 werde mit den genannten Trends aufholen unser sowie unser Kundengeschäft zu einer völlig anderen Dimension wachsen überhaupt.
<G-vec00185-001-s055><catch.aufholen><en> It was good to know about the latest marketing trends in 2018 will catch up with the listed trends to grow our as well as our clients business to a totally different dimension at all.
<G-vec00185-001-s075><catch.aufholen><de> Ich fürchte auch in der kommenden Welle, in der es noch mehr um Daten geht und die unter KI/AI subsumiert ist, wird es uns schwer fallen die Rückstände aufzuholen.
<G-vec00185-001-s075><catch.aufholen><en> I’m also afraid that in the coming wave, which is even more about data and which is subsumed under AI, it will be difficult for us to catch up.
<G-vec00185-001-s076><catch.aufholen><de> Dann zurück zur Arbeit, um wieder aufzuholen.
<G-vec00185-001-s076><catch.aufholen><en> Then back to work to catch up.
<G-vec00185-001-s077><catch.aufholen><de> Tolle Software:Was mich begeistert hat, nachdem ich nach der Stilllegung der Seite zurückgekommen bin, war, dass ihre Software immer noch die beste war, sogar nachdem die Konkurrenz 16 Monate hatte um aufzuholen.
<G-vec00185-001-s077><catch.aufholen><en> Great Software: What amazed me when I got back after the shutdown is that their software is still the best, even after giving rivals 16 months to catch up.
<G-vec00185-001-s078><catch.aufholen><de> Falun Gong-Praktizierende bemühen sich sehr, mit dem Prozess der Fa-Berichtigung Schritt zu halten oder aufzuholen.
<G-vec00185-001-s078><catch.aufholen><en> Falun Gong practitioners are trying hard to maintain or catch up with the progress of the Fa-rectification.
<G-vec00185-001-s079><catch.aufholen><de> Verärgert über mich und diese Verwechslung fuhr ich wieder hinaus auf die Strecke mit dem Ziel, die verloren gegangene Zeit wieder aufzuholen.
<G-vec00185-001-s079><catch.aufholen><en> Angry about that me and that confusion i drove again out on the track with the aim to catch up the lost time.
<G-vec00185-001-s080><catch.aufholen><de> Vielmehr verlangsamt das Topping den vertikalen Wuchs und ermöglicht so den Seitenzweigen aufzuholen, während zwei neue Haupt-Colas entstehen.
<G-vec00185-001-s080><catch.aufholen><en> Rather topping slows vertical growth down allowing side branches to catch up while two new top colas are emerging.
<G-vec00185-001-s081><catch.aufholen><de> "Buch, mit 324%, sie das Unmögliche Wette, um aufzuholen und übertreffen die 315% ige Erhöhung der Goldpreis in Dollar verwaltet, ist der Euro das letzte Gold "", mit einer kleine ""183%."
<G-vec00185-001-s081><catch.aufholen><en> It managed the impossible bet to catch up and surpass the 315% increase in the gold price in dollars.
<G-vec00185-001-s082><catch.aufholen><de> Halten Sie auf den Pinguin, um ihn aufzuholen und hüpfen sie nach oben, bis er das Eis bricht und landet erfolgreich.
<G-vec00185-001-s082><catch.aufholen><en> Keep clicking on the penguin so as to catch it up and bounce it upwards until it breaks the ice and lands successfully.
<G-vec00185-001-s083><catch.aufholen><de> Also lassen Sie sich eine Tour um den Ecwid Speicher, um aufzuholen mit dem Updates der letzten drei Monate.
<G-vec00185-001-s083><catch.aufholen><en> So let's take a tour around your Ecwid store to catch up with the updates of the last three months.
<G-vec00185-001-s084><catch.aufholen><de> Zusammengefasst: Renzi ist im Nachteil, aber behält die Möglichkeit aufzuholen.
<G-vec00185-001-s084><catch.aufholen><en> In summary: Renzi is at a disadvantage, but retains the opportunity to catch up.
<G-vec00185-001-s085><catch.aufholen><de> Die Männer, die überfordert, um aufzuholen den richtigen Artikel sind häufig fallen für Ihre gefälschte Produkte, die aus billigen Zutaten und ineffizient Formel erstellt werden.
<G-vec00185-001-s085><catch.aufholen><en> The males who’re overwhelmed to catch up the proper item frequently drop for your bogus products which are created up of cheap ingredients and inefficient formula.
<G-vec00185-001-s086><catch.aufholen><de> Und die meisten von ihnen nur ein neues Telefon kaufen, um mit der neuesten Mode, um aufzuholen oder zeigen ihre Treue zu einem bestimmten Marke, wie Apple oder Samsung.
<G-vec00185-001-s086><catch.aufholen><en> And most of them just buy a new phone in order to catch up with the latest fashion or show their loyalty to some particular brand, like Apple or Samsung.
<G-vec00185-001-s087><catch.aufholen><de> "Bei der aktuellen Rate würde es 15 Jahre dauern, aufzuholen,"" schließt Ludovic Subran."
<G-vec00185-001-s087><catch.aufholen><en> "At the current rate, it would take 15 years to catch up,"" concludes Ludovic Subran."
<G-vec00185-001-s088><catch.aufholen><de> In Wahrheit, ich erwartet hatte, Geld zu erhalten, die mich auf die Hypothek aufzuholen erlauben würde und Zahlungen wieder aufzunehmen.
<G-vec00185-001-s088><catch.aufholen><en> In truth, I had been expecting to receive money that would allow me to catch up on the mortgage and resume payments.
<G-vec00185-001-s089><catch.aufholen><de> "Verdoppeln Sie sich ""nicht hinauf"" die Dosis aufzuholen."
<G-vec00185-001-s089><catch.aufholen><en> "Do not ""double-up"" the dose to catch up."
<G-vec00185-001-s090><catch.aufholen><de> Nach dem ›Big Bang‹ der REWE Deutschland war es auch für die REWE DORTMUND an der Zeit, aufzuholen.
<G-vec00185-001-s090><catch.aufholen><en> After the 'Big Bang' at REWE Germany, it was now time for REWE DORTMUND to catch up.
<G-vec00185-001-s091><catch.aufholen><de> Beide Objekte in dem, mit dem anderen aufzuholen beschleunigt fliegen schnell und hoch, einer von ihnen.
<G-vec00185-001-s091><catch.aufholen><en> Both objects where flying fast and high, one of them sped up as to catch up with the other.
<G-vec00185-001-s092><catch.aufholen><de> Sobald du Mir verschrieben bist, hast du nicht aufzuholen.
<G-vec00185-001-s092><catch.aufholen><en> When you are committed to Me, you do not have to catch up.
<G-vec00185-001-s093><catch.aufholen><de> Ich plane, mein Verlobter dort im Juli, weil ich war so begeistert von den Familien, die dort arbeiten, und ich will, dass sie erleben, was ich durchgemacht habe, und ich kann nicht warten, um aufzuholen mit meinen alten Freunden wieder berührt.
<G-vec00185-001-s093><catch.aufholen><en> I am planning to take my fiance there in July because i was so touched by the families that work there and I want her to experience what I went through and I can't wait to catch up with my old friends again. Love this place!
