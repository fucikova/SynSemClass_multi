<G-vec00003-001-s038><look.anschauen><de> Solange diese Karte offen auf dem Spielfeld liegt, kannst du in deiner Standby Phase 1 verdeckte Karte anschauen, die dein Gegner gesetzt hat.
<G-vec00003-001-s038><look.anschauen><en> During your Standby Phase, you can look at 1 face-down card that's been Set by your opponent as long as this card remains face-up on the field.
<G-vec00003-001-s039><look.anschauen><de> Am PC, Tablet oder Smartphone kannst Du Deine Lieblingsdesigns in aller Ruhe anschauen.
<G-vec00003-001-s039><look.anschauen><en> Sit back, relax and take a look at your favourite design from your laptop, tablet or smartphone.
<G-vec00003-001-s040><look.anschauen><de> D.h., er kann zum Beamer schauen, wenn etwas geteilt wird und er kann Personen direkt anschauen, wenn diskutiert wird.
<G-vec00003-001-s040><look.anschauen><en> I.e. he/she can look at the projector image when something is shared and look directly at people during discussions.
<G-vec00003-001-s041><look.anschauen><de> Die Beispiele werden sich weniger mit „Einflüssen“ beschäftigen sondern mit der Definition von bestimmten gemeinsamen Strukturen, die auftreten wenn wir uns anschauen wie visuelle Intuition Problemlösung betreibt.
<G-vec00003-001-s041><look.anschauen><en> The examples will be less concerned with ‘influence’ than in the defining of certain shared structures that emerge when we look at how visual intuition operates in problem-solving.
<G-vec00003-001-s042><look.anschauen><de> Warum das so ist, wollen wir uns in diesem Blogpost anschauen.
<G-vec00003-001-s042><look.anschauen><en> Let's take a look at why this is the case.
<G-vec00003-001-s043><look.anschauen><de> Erste Screenshots könnt ihr euch in der Gallery anschauen.
<G-vec00003-001-s043><look.anschauen><en> In our gallery you can look at some of the first screenshots.
<G-vec00003-001-s044><look.anschauen><de> Beispiel: Ein weißes Blatt Papier hat für uns das gleiche Weiß, wenn wir es im Tageslicht und dann unter Kunstlicht anschauen.
<G-vec00003-001-s044><look.anschauen><en> For example, a white sheet of paper always has the same white appearance regardless of whether we look at it in daylight or in artificial light.
<G-vec00003-001-s045><look.anschauen><de> Aber es fragt sich, ob man von der Theorie allein ausgehen will oder auch mal empirisch anschauen will, wie es bisher funktioniert hat.
<G-vec00003-001-s045><look.anschauen><en> But the question is whether we just want to focus on the theory, or whether we also want to look empirically at how it has functioned so far.
<G-vec00003-001-s046><look.anschauen><de> Es gab auch eine Mutter, die ihrem Kind sehr offen die Schautafeln anschauen ließ und geduldig die Fragen ihres Kindes beantwortete.
<G-vec00003-001-s046><look.anschauen><en> One mother encouraged her child to look at the display boards and answered patiently the child’s questions.
<G-vec00003-001-s047><look.anschauen><de> In Berlin auch anschauen es kann auf den kleinen Rest der berühmten Berliner Wand von der Ausdehnung anderthalb Kilometer.
<G-vec00003-001-s047><look.anschauen><en> Also it is possible to look in Berlin at the small rest of the well-known Berlin wall one and a half kilometer long.
<G-vec00003-001-s048><look.anschauen><de> Wenn Sie uns anschauen, Sie können immer noch sagen, dass wir wunderbare Geschöpfe sind, aber es ist auch klar, dass wir aufgebrochen sind.
<G-vec00003-001-s048><look.anschauen><en> If you look at us, you can still tell we're wonderful creatures, but it's also clear that we're broken.
<G-vec00003-001-s049><look.anschauen><de> Mit von der Partie sind außerdem Influencer, Stylisten und Blogger, die die neuesten Teile in den Marc Cain Show Rooms anschauen und anprobieren können.
<G-vec00003-001-s049><look.anschauen><en> In addition, bloggers, stylists and influencers take a look at the latest pieces in the Marc Cain Showroom and get the opportunity of trying on the looks.
<G-vec00003-001-s050><look.anschauen><de> Von denen, die uns anschauen, und er/sie sieht sich an und er/sie denkt uns und es entsteht eine Bruecke und dann entdeckt er/sie dass diese Worte, die er/sie schreibt, singt, wiederholt, umwandelt, nicht den Zapatistinnen und Zapatisten gehoeren, ja dass sie ihnen niemals gehoert haben, sondern dass sie Euch gehoeren, und allen und niemand, und dass sie Teil einer Partitur sind die sich weiß wo befindet, und dann entdeckt Ihr oder werdet in der Ueberzeugung bestaerkt, dass, wenn Ihr uns anschaut und seht wie wir Euch anschauen, Ihr dabei seid, ueber etwas Groesseres zu sprechen, etwas Groesseres anzuruehren, etwas, wofuer es noch keine Definition im Woerterbuch gibt und das keiner Gruppe, keinem Kollektiv, keiner Organisation, keiner Sekte, keiner Religion oder was auch immer gehoert, sondern versteht, dass der Schritt zur Menschlichkeit jetzt ´Rebellion´ heißt.
<G-vec00003-001-s050><look.anschauen><en> Those who look at us, and look at themselves thinking about us, and make themselves a bridge and then discover that these words that they write, sing, repeat, transform, do not belong to the Zapatistas, that they never did, that those words belong to you, they belong to everybody and to nobody, and that they are part of a larger whole, and who knows where that larger whole may be, and so you discover or confirm that when you look at us looking at ourselves looking at you, you are touching and talking about something bigger, something for which there is no alphabet yet, and that through this process you aren’t joining a group, collective, organization, sect, religion, or whatever you may call it, but rather that you are understanding that the passage to humanity today is called “rebellion.”
<G-vec00003-001-s051><look.anschauen><de> Aber setz dich für einen Augenblick hin und lasse dich anschauen und erinnere dich an die Momente, als er dich angeschaut hat und dass er dich jetzt gerade anschaut.
<G-vec00003-001-s051><look.anschauen><en> That is good but sit down a while and allow him to look at you and remember those times he looked at you and looks at you.
<G-vec00003-001-s052><look.anschauen><de> "Aber das ist kein Problem, wir können uns jederzeit den ""Lehrplan"" einiger Produkte anschauen."
<G-vec00003-001-s052><look.anschauen><en> T hat's not a problem, as we can always take a look at the 'curriculum' of some of these products.
<G-vec00003-001-s053><look.anschauen><de> Lass uns nun anschauen – da wir über die Assoziationen von Rot und Schwarz Bescheid wissen – wie sich die Farbpräferenzen zwischen den Geschlechtern unterscheiden.
<G-vec00003-001-s053><look.anschauen><en> Now that we understand the associations for red and black, let's look at how color preferences differ between the genders.
<G-vec00003-001-s054><look.anschauen><de> So lasst sie als erste ihre Augen schließen, und dann möge der Heiler die Patienten für ungefähr zwei Minuten anschauen.
<G-vec00003-001-s054><look.anschauen><en> So let them close their eyes first and let the healer look at the patients for about two minutes.
<G-vec00003-001-s055><look.anschauen><de> "Wir werden uns auch die Konjugation der Verben ""voir"", ""faire"" & ""dire"" im Präsens anschauen."
<G-vec00003-001-s055><look.anschauen><en> We will also take a look at the conjugation of verbs 'voir', 'faire' & 'dire' in the present tense.
<G-vec00003-001-s056><look.anschauen><de> Wenn wir uns das Datum etwas genauer anschauen, 1.11., ist der Bezug zu einem geraden Horn – auf der Stirnmitte – nicht völlig von der Hand zu weisen.
<G-vec00003-001-s056><look.anschauen><en> If we take a closer look at the date, 1.11., the reference to a straight horn – in the middle of the forehead – cannot be completely dismissed.
<G-vec00003-001-s076><look.anschauen><de> Mit dem Wissen um die Illuminati lohnt es sich auch, weitere Spielkarten mit weiteren Themen anzuschauen, die alle eine erstaunliche Ähnlichkeit zur Illuminati-Agenda aufweisen und zu Ereignissen, die man heute auf der Welt beobachten kann.
<G-vec00003-001-s076><look.anschauen><en> Bearing this point in mind, it’s worth taking a look at some of the other themes featured in the game that all bear significant similarities to the illuminati agenda and to events that can be seen happening around the world today.
<G-vec00003-001-s077><look.anschauen><de> Selbst wenn Sie nicht die Abfahrtsski sehr mögen, ist in Zakopane auf was, und wohin anzuschauen auszusteigen.
<G-vec00003-001-s077><look.anschauen><en> Even if you not really love mountain skiing, in Zakopane is on what to look and where to descend.
<G-vec00003-001-s078><look.anschauen><de> Zum Beispiel, die Benutzer können in die Liste eingeführt werden, erkennen, wo sich die Busse in der Echtzeit befinden, die Route auf der interaktiven Karte zu planen, den kürzesten Pfad zum Bestimmungsort ausgewählt, die Werbung auf dem elektronischen Bulletin Board anzuschauen und es ist einfach, sich das Web-Wellenreiten zu beschäftigen.
<G-vec00003-001-s078><look.anschauen><en> For example, users can familiarise with the time schedule, learn, where buses in real time are, to plan the path on an interactive map, having selected the shortest passage to destination, to look advertising on an electronic bulletin board and simply to be occupied by web surfing.
<G-vec00003-001-s079><look.anschauen><de> Um anzuschauen, wie balsamin zu pflanzen und durch ihn das Hofgrundstück zu schmücken, schauen Sie das Foto auf unserer Webseite an.
<G-vec00003-001-s079><look.anschauen><en> To look how to put a balsam and to decorate with it the personal plot, look at a photo on our site.
<G-vec00003-001-s080><look.anschauen><de> So dass, sich entscheidend, was man, in Paris anzuschauen, diese Insel von der Aufmerksamkeit nicht umgehen darf.
<G-vec00003-001-s080><look.anschauen><en> So, deciding that to look in Paris, it is impossible to ignore this island.
<G-vec00003-001-s081><look.anschauen><de> Eine ist, jeden Patienten individuell für ein paar Sekunden bei seinem Brauenzentrum anzuschauen.
<G-vec00003-001-s081><look.anschauen><en> One is - to look at each patient individually for a few seconds at his brow centre.
<G-vec00003-001-s082><look.anschauen><de> Das ist sehr schön anzuschauen und findet den ganzen Tag über statt.
<G-vec00003-001-s082><look.anschauen><en> This is very nice to look and it takes place as well throughout the daytime.
<G-vec00003-001-s083><look.anschauen><de> «Man nimmt sich sonst eh nie die Zeit durch die Wiesen zu gehen und sich etwas genauer anzuschauen.
<G-vec00003-001-s083><look.anschauen><en> «Normally you don't really take the time to walk through the meadows and take a closer look at things.
<G-vec00003-001-s084><look.anschauen><de> Was in Paris anzuschauen Die Menge der Menschen träumen, Paris — die Stadt der Romantik, das Herz Frankreichs zu sehen.
<G-vec00003-001-s084><look.anschauen><en> What to look in Paris Huge number of people dream to see Paris — the city of romanticism, heart of France.
<G-vec00003-001-s085><look.anschauen><de> Vergessen Sie nicht, dass es auch Spaß machen kann, kurze Videos anzuschauen und darüber zu sprechen.
<G-vec00003-001-s085><look.anschauen><en> Remember that short videos can also be great fun to look at and talk about.
<G-vec00003-001-s086><look.anschauen><de> Ich liebe es zu meditieren, eine Blume, einen Sonnenuntergang und das Meer anzuschauen und ich verliere mich, trete ein in einen Zustand der Trance und nichts stoert mich mehr.
<G-vec00003-001-s086><look.anschauen><en> I love meditating, I look at a flower, a sunset, the sea and I lose myself, I fall into a trance and nothing disturbs me any longer.
<G-vec00003-001-s087><look.anschauen><de> Und Mose verhüllete sein Angesicht, denn er fürchtete sich, Gott anzuschauen.
<G-vec00003-001-s087><look.anschauen><en> And Moses hid his face; for he was afraid to look upon God.
<G-vec00003-001-s088><look.anschauen><de> Wie widerlich, junge Leute mit schlaffem Bierbauch anzuschauen.
<G-vec00003-001-s088><look.anschauen><en> How disgusting to look at young guys with sagging beer belly.
<G-vec00003-001-s089><look.anschauen><de> Die ganze Stadt ist losgerannt, die Braut anzuschauen, kamen und teilten mir die frohe Nachricht mit: die Braut ist... auf der Person – keiner Sommersprosse sehr schön.
<G-vec00003-001-s089><look.anschauen><en> All city ran to look at the bride, came and told me a joyful message: the bride is very beautiful... on a face – any freckle.
<G-vec00003-001-s090><look.anschauen><de> Als die Zwölf, die durch das Gleichnis der Fußwaschung und die anschließenden Worte des Meisters schon viel von ihrem Selbstbewusstsein und Selbstvertrauen eingebüßt hatten, dies hörten, begannen sie, einander anzuschauen, und fragten mit Beunruhigung und Zögern in der Stimme: „Bin ich es?“ Und als sie alle so gefragt hatten, sagte Jesus: „Zwar ist es notwendig, dass ich zum Vater gehe, aber es war nicht erforderlich, dass, um des Vaters Willen zu erfüllen, einer von euch zum Verräter werde.
<G-vec00003-001-s090><look.anschauen><en> When the twelve heard this, having already been robbed of much of their self-assertiveness and self-confidence by the parable of the feet washing and the Master’s subsequent discourse, they began to look at one another while in disconcerted tones they hesitatingly inquired, “Is it I?” And when they had all so inquired, Jesus said: “While it is necessary that I go to the Father, it was not required that one of you should become a traitor to fulfill the Father’s will.
<G-vec00003-001-s091><look.anschauen><de> Eine andere Art den Pfad anzuschauen ist eine, bei der es ein Seil gibt, das aus acht Strängen gewoben ist.
<G-vec00003-001-s091><look.anschauen><en> Another way to look at the path is one in which there are eight strands of a rope woven together.
<G-vec00003-001-s092><look.anschauen><de> "Wir nutzen die Zeit, uns diese Stadt – auf Deutsch steht der Namen für ""roter Held"" - zwischen Tradition und Moderne anzuschauen, ehe wir am kommenden Morgen zu unserer Tour quer durch die Mongolei aufbrechen wollen."
<G-vec00003-001-s092><look.anschauen><en> "We use the time to take a look at this town - whose name translates as ""Red Hero"" - between the traditional and the modern, before starting our tour through Mongolia on the following day."
<G-vec00003-001-s093><look.anschauen><de> Präsentiert von FXCM Marketscope Charts Um die Psychologie hinter dem Unterstützungslevel zu verstehen und zu erkennen, warum es in die Zukunft weitergetragen werden kann, ist es hilfreich, unsere eigene Erfahrung anzuschauen.
<G-vec00003-001-s093><look.anschauen><en> To understand the psychology behind a support level and see why it may carry into the future, it is helpful to look at your own experience.
<G-vec00003-001-s094><look.anschauen><de> Bitten Sie den Redner, Sie anzuschauen, damit Sie beim Zuhören seine Lippen lesen können.
<G-vec00003-001-s094><look.anschauen><en> Ask the speaker to look at you so that you can lip read while listening.
<G-vec00211-002-s020><oversee.anschauen><de> Durch ein Fenster können Sie sich die Pferde des Eigentümers anschauen.
<G-vec00211-002-s020><oversee.anschauen><en> You can oversee the owner’s horses through a window.
<G-vec00310-002-s076><watch.anschauen><de> Netflix ist ein US-amerikanischer Anbieter, der es ermöglicht, über das Internet Filme und Serien anzuschauen.
<G-vec00310-002-s076><watch.anschauen><en> Netflix is a US company that enables its customers to watch films and series via the Internet.
<G-vec00310-002-s077><watch.anschauen><de> Klicken Sie hier, um die Videos anzuschauen und eine kostenlose Kopie des Best Practice-Leitfadens „Frischetheke“ anzufordern.
<G-vec00310-002-s077><watch.anschauen><en> Click here to watch the videos and request a free copy of the Fresh Counter Best Practice Guide.
<G-vec00310-002-s078><watch.anschauen><de> Durch die Gehirnwäschemethoden, wie grelles Licht und lautes Fernsehen bei Nacht, zwangen sie ihn, Falun Gong verleumderische Videos anzuschauen.
<G-vec00310-002-s078><watch.anschauen><en> Through brainwashing methods such as keeping a large light and loud TV on at night, they forced him to watch videos that slander Falun Gong.
<G-vec00310-002-s079><watch.anschauen><de> Und schaut auch auf die Proudly Ugly Webseite um weitere Songs von uns, aber auch von anderen Bands anzuschauen.
<G-vec00310-002-s079><watch.anschauen><en> Check this out and head over to the Proudly Ugly website to watch our other songs.
<G-vec00310-002-s080><watch.anschauen><de> Das genügt gerade, um zwei Spielfilme anzuschauen.
<G-vec00310-002-s080><watch.anschauen><en> This is enough time to watch two movies.
<G-vec00310-002-s081><watch.anschauen><de> Seit es Hustler gibt lieben es viele Menschen sich diese Mädchen anzuschauen, wir müssen Hustler also vertrauen, dass sie wissen was sie tun.
<G-vec00310-002-s081><watch.anschauen><en> Since Hustler was out, many people love to watch those chicks, so we must trust Hustler that they know what they’re doing.
<G-vec00310-002-s082><watch.anschauen><de> Aber das ist natürlich nicht alles: wählen Sie bequem (gekaufte oder geliehene) Spielfilme, Fernsehsendungen oder Podcasts aus, um sie anschließend in iTunes anzuschauen.
<G-vec00310-002-s082><watch.anschauen><en> But that is not all: select your (bought or rented) movies, podcasts or TV shows comfortably and watch them in iTunes.
<G-vec00310-002-s083><watch.anschauen><de> Wenn du glaubst, einen geeigneten Ort gefunden zu haben, um deinen Canary mit dem WLAN zu verbinden, versuche von dort aus, dir den Live-Stream anzuschauen.
<G-vec00310-002-s083><watch.anschauen><en> If you think you’ve found a suitable place and plan to connect Canary to Wi-Fi, try streaming Watch Live from your device there.
<G-vec00310-002-s084><watch.anschauen><de> Um diese Sachen noch besser zu machen, haben unsere Entwickler jetzt Unterstützung für mehrere DVB-Tuner (um mehrere Kanäle gleichzeitig anzuschauen) und eine besser Fehlersuche eingebaut.
<G-vec00310-002-s084><watch.anschauen><en> Determined to make things even better, developers have worked to enhance this support by adding support for multiple DVB tuners (watch multiple channels at once) and better troubleshooting diagnostics.
<G-vec00310-002-s085><watch.anschauen><de> Besuchen Sie bitte die Free to Play-Webseite, um den Trailer anzuschauen und weitere Informationen zu diesem Film zu erhalten.
<G-vec00310-002-s085><watch.anschauen><en> Visit the Free to Play website to watch the trailer and learn more about the film.
<G-vec00310-002-s086><watch.anschauen><de> Ihnen wurde außerdem gesagt, heimzugehen und sich gehorsam die Spiele anzuschauen und nicht auszugehen.
<G-vec00310-002-s086><watch.anschauen><en> They were also told to go home and obediently watch the Games, and that they should not go out.
<G-vec00310-002-s087><watch.anschauen><de> Nach einer Rundfahrt um die Kassan- dra fuhren wir gen Süden, vorbei am heiligen Berg Athos, zur Halbinsel Pilion und von da weiter nach Delphi, um uns auch einen Teil der griechischen Geschichte anzuschauen.
<G-vec00310-002-s087><watch.anschauen><en> After a tour around Cassandra we drove toward the south, passed this holy mountain Athos to the peninsula Pilion and from there further on to Delphi, also to watch a part in Greek history.
<G-vec00310-002-s088><watch.anschauen><de> Es wird jedenfalls ein lustiger Anblick sein, wenn Sie das Haus von Freunden betreten, um ein Spiel anzuschauen und diese ein Virtual-Reality-Headset tragen und dabei die Spieler ihres Teams anschreien.
<G-vec00310-002-s088><watch.anschauen><en> Even so, it will be a funny sight to see when you walk into a friends house to watch the game and they are wearing a VR headset yelling at their players.
<G-vec00310-002-s089><watch.anschauen><de> Konsultieren Sie Ihren Arzt (etwa einen Kinderarzt oder Augenarzt), bevor Sie kleinen Kindern erlauben, 3D-Videospiele anzuschauen oder stereoskopische 3DSpiele zu spielen.
<G-vec00310-002-s089><watch.anschauen><en> We recommend that you consult with your child’s doctor or optometrist before allowing young children to watch 3D video images or play stereoscopic 3D games.
<G-vec00310-002-s090><watch.anschauen><de> Wir waren auf der Durchreise mit dem Auto um Verona anzuschauen.
<G-vec00310-002-s090><watch.anschauen><en> We were on the transit with the car around Verona to watch.
<G-vec00310-002-s091><watch.anschauen><de> Klicken Sie hier, um das Praktikumsprogramm auf Video anzuschauen.
<G-vec00310-002-s091><watch.anschauen><en> Click here to watch the Internship Programme video.
<G-vec00310-002-s092><watch.anschauen><de> Ich empfehle euch allen diese mal anzuschauen, egal wo ihr seid, an was ihr glaubt, oder wieviel Geld ihr auch macht, denn ich glaube das sie eurem Leben und eurer Umgebung einen positiven Impuls geben kann.
<G-vec00310-002-s092><watch.anschauen><en> I strongly suggest to watch it to everyone and I believe that no matter where you are, what you believe in, and how much money you make that you can make an impact and change positively your surroundings.
<G-vec00310-002-s093><watch.anschauen><de> Wenn Du keinen Einsatz hast, besteht die Möglichkeit, nach Absprache mit dem Verantwortlichen des jeweiligen Einsatzbereiches die Spiele anzuschauen.
<G-vec00310-002-s093><watch.anschauen><en> However, there will be the opportunity depending on the respective operational area and after consultation with the volunteer manager to watch games.
<G-vec00310-002-s094><watch.anschauen><de> Vielleicht aber auch einfach das Handy positionieren, um sich Videos anzuschauen oder mit Freunden zu skypen.
<G-vec00310-002-s094><watch.anschauen><en> Maybe you just want to position your mobile phone to watch videos or Skype with friends.
<G-vec00211-003-s076><watch_over.anschauen><de> Netflix ist ein US-amerikanischer Anbieter, der es ermöglicht, über das Internet Filme und Serien anzuschauen.
<G-vec00211-003-s076><watch_over.anschauen><en> Netflix is a US company that enables its customers to watch films and series via the Internet.
<G-vec00211-003-s077><watch_over.anschauen><de> Klicken Sie hier, um die Videos anzuschauen und eine kostenlose Kopie des Best Practice-Leitfadens „Frischetheke“ anzufordern.
<G-vec00211-003-s077><watch_over.anschauen><en> Click here to watch the videos and request a free copy of the Fresh Counter Best Practice Guide.
<G-vec00211-003-s078><watch_over.anschauen><de> Durch die Gehirnwäschemethoden, wie grelles Licht und lautes Fernsehen bei Nacht, zwangen sie ihn, Falun Gong verleumderische Videos anzuschauen.
<G-vec00211-003-s078><watch_over.anschauen><en> Through brainwashing methods such as keeping a large light and loud TV on at night, they forced him to watch videos that slander Falun Gong.
<G-vec00211-003-s079><watch_over.anschauen><de> Und schaut auch auf die Proudly Ugly Webseite um weitere Songs von uns, aber auch von anderen Bands anzuschauen.
<G-vec00211-003-s079><watch_over.anschauen><en> Check this out and head over to the Proudly Ugly website to watch our other songs.
<G-vec00211-003-s080><watch_over.anschauen><de> Das genügt gerade, um zwei Spielfilme anzuschauen.
<G-vec00211-003-s080><watch_over.anschauen><en> This is enough time to watch two movies.
<G-vec00211-003-s081><watch_over.anschauen><de> Seit es Hustler gibt lieben es viele Menschen sich diese Mädchen anzuschauen, wir müssen Hustler also vertrauen, dass sie wissen was sie tun.
<G-vec00211-003-s081><watch_over.anschauen><en> Since Hustler was out, many people love to watch those chicks, so we must trust Hustler that they know what they’re doing.
<G-vec00211-003-s082><watch_over.anschauen><de> Aber das ist natürlich nicht alles: wählen Sie bequem (gekaufte oder geliehene) Spielfilme, Fernsehsendungen oder Podcasts aus, um sie anschließend in iTunes anzuschauen.
<G-vec00211-003-s082><watch_over.anschauen><en> But that is not all: select your (bought or rented) movies, podcasts or TV shows comfortably and watch them in iTunes.
<G-vec00211-003-s083><watch_over.anschauen><de> Wenn du glaubst, einen geeigneten Ort gefunden zu haben, um deinen Canary mit dem WLAN zu verbinden, versuche von dort aus, dir den Live-Stream anzuschauen.
<G-vec00211-003-s083><watch_over.anschauen><en> If you think you’ve found a suitable place and plan to connect Canary to Wi-Fi, try streaming Watch Live from your device there.
<G-vec00211-003-s084><watch_over.anschauen><de> Um diese Sachen noch besser zu machen, haben unsere Entwickler jetzt Unterstützung für mehrere DVB-Tuner (um mehrere Kanäle gleichzeitig anzuschauen) und eine besser Fehlersuche eingebaut.
<G-vec00211-003-s084><watch_over.anschauen><en> Determined to make things even better, developers have worked to enhance this support by adding support for multiple DVB tuners (watch multiple channels at once) and better troubleshooting diagnostics.
<G-vec00211-003-s085><watch_over.anschauen><de> Besuchen Sie bitte die Free to Play-Webseite, um den Trailer anzuschauen und weitere Informationen zu diesem Film zu erhalten.
<G-vec00211-003-s085><watch_over.anschauen><en> Visit the Free to Play website to watch the trailer and learn more about the film.
<G-vec00211-003-s086><watch_over.anschauen><de> Ihnen wurde außerdem gesagt, heimzugehen und sich gehorsam die Spiele anzuschauen und nicht auszugehen.
<G-vec00211-003-s086><watch_over.anschauen><en> They were also told to go home and obediently watch the Games, and that they should not go out.
<G-vec00211-003-s087><watch_over.anschauen><de> Nach einer Rundfahrt um die Kassan- dra fuhren wir gen Süden, vorbei am heiligen Berg Athos, zur Halbinsel Pilion und von da weiter nach Delphi, um uns auch einen Teil der griechischen Geschichte anzuschauen.
<G-vec00211-003-s087><watch_over.anschauen><en> After a tour around Cassandra we drove toward the south, passed this holy mountain Athos to the peninsula Pilion and from there further on to Delphi, also to watch a part in Greek history.
<G-vec00211-003-s088><watch_over.anschauen><de> Es wird jedenfalls ein lustiger Anblick sein, wenn Sie das Haus von Freunden betreten, um ein Spiel anzuschauen und diese ein Virtual-Reality-Headset tragen und dabei die Spieler ihres Teams anschreien.
<G-vec00211-003-s088><watch_over.anschauen><en> Even so, it will be a funny sight to see when you walk into a friends house to watch the game and they are wearing a VR headset yelling at their players.
<G-vec00211-003-s089><watch_over.anschauen><de> Konsultieren Sie Ihren Arzt (etwa einen Kinderarzt oder Augenarzt), bevor Sie kleinen Kindern erlauben, 3D-Videospiele anzuschauen oder stereoskopische 3DSpiele zu spielen.
<G-vec00211-003-s089><watch_over.anschauen><en> We recommend that you consult with your child’s doctor or optometrist before allowing young children to watch 3D video images or play stereoscopic 3D games.
<G-vec00211-003-s090><watch_over.anschauen><de> Wir waren auf der Durchreise mit dem Auto um Verona anzuschauen.
<G-vec00211-003-s090><watch_over.anschauen><en> We were on the transit with the car around Verona to watch.
<G-vec00211-003-s091><watch_over.anschauen><de> Klicken Sie hier, um das Praktikumsprogramm auf Video anzuschauen.
<G-vec00211-003-s091><watch_over.anschauen><en> Click here to watch the Internship Programme video.
<G-vec00211-003-s092><watch_over.anschauen><de> Ich empfehle euch allen diese mal anzuschauen, egal wo ihr seid, an was ihr glaubt, oder wieviel Geld ihr auch macht, denn ich glaube das sie eurem Leben und eurer Umgebung einen positiven Impuls geben kann.
<G-vec00211-003-s092><watch_over.anschauen><en> I strongly suggest to watch it to everyone and I believe that no matter where you are, what you believe in, and how much money you make that you can make an impact and change positively your surroundings.
<G-vec00211-003-s093><watch_over.anschauen><de> Wenn Du keinen Einsatz hast, besteht die Möglichkeit, nach Absprache mit dem Verantwortlichen des jeweiligen Einsatzbereiches die Spiele anzuschauen.
<G-vec00211-003-s093><watch_over.anschauen><en> However, there will be the opportunity depending on the respective operational area and after consultation with the volunteer manager to watch games.
<G-vec00211-003-s094><watch_over.anschauen><de> Vielleicht aber auch einfach das Handy positionieren, um sich Videos anzuschauen oder mit Freunden zu skypen.
<G-vec00211-003-s094><watch_over.anschauen><en> Maybe you just want to position your mobile phone to watch videos or Skype with friends.
<G-vec00417-002-s019><look.anschauen><de> Wir werden den Platz, an dem sie zukünftig leben soll, auf jeden Fall auch vorher anschauen.
<G-vec00417-002-s019><look.anschauen><en> We will look at the place, where she should live in the future, also previously in any case.
<G-vec00417-002-s020><look.anschauen><de> Es geht nicht mehr um die Gesellschaft und die herrschenden Medien, die auf die Immigration oder die Jugendlichen aus den Vierteln blicken, sondern um die Jugendlichen aus genau diesen Vierteln, die sich die Gesellschaft anschauen und ihre Meinung sagen.
<G-vec00417-002-s020><look.anschauen><en> It's no longer society and mainstream media that look at immigration or the kids from the neighborhoods, but it's the kids from these neighborhoods who look back at society and speak their mind about it.
<G-vec00417-002-s021><look.anschauen><de> "Da die VIRB Daten zu meinen Videos speichert, kann ich diese im Nachhinein anschauen, mich in Echtzeit sehen und dies in meinem Training nutzen.
<G-vec00417-002-s021><look.anschauen><en> "Because VIRB adds data to my videos, I can look back and see myself in real time and use that in my training.
<G-vec00417-002-s022><look.anschauen><de> Bis wir einander so ansehen koennen wie wir unsere Familie anschauen, mit anderen Worten, wenn ich dich zu 100% in meine Familie einschließen kann, wenn ich den Typ mit dem Turban als meinen Bruder ansehen kann, als meine Schwester, mein Kind und Elternteil, bis ich dies tun kann, werden wir Probleme haben.
<G-vec00417-002-s022><look.anschauen><en> Until we can look at each other in the way we look at our family, in other words, when I can include you 100% into my family, when I can look at the guy with the turban as my brother, as my sister, as my child and parent, until I can do that, we're gonna have problems.
<G-vec00417-002-s023><look.anschauen><de> {2} Daß diese Grenze nicht willkürlich gezogen ist, wird klar, wenn wir uns die regionalen Bischofskonferenzen in Asien anschauen.
<G-vec00417-002-s023><look.anschauen><en> {2} That this border is not arbitrarily drawn becomes clear when we look at the Regional Bishop's Conferences in Asia.
<G-vec00417-002-s024><look.anschauen><de> Das ist eine Lektion die manche von euch hören müssen und die manche von euch nicht anschauen werden, denn Menschen wollen das Böse anderen Wesen zuordnen.
<G-vec00417-002-s024><look.anschauen><en> This is a lesson that some of you need to hear and that some of you will not look at, because Human Beings want to assign evil to entities.
<G-vec00417-002-s025><look.anschauen><de> Wer sich auf die diesjährige Messer Macher Messe einstimmen möchte, kann sich gerne die Bilder der letzten Jahre anschauen.
<G-vec00417-002-s025><look.anschauen><en> To get yourself in the right mood for the fair, you can take a look at the pictures of last years.
<G-vec00417-002-s026><look.anschauen><de> Sie entkleideten uns Praktizierende und ließen männliche Kriminelle uns durch die Fenster anschauen.
<G-vec00417-002-s026><look.anschauen><en> They stripped us female practitioners naked and let the male criminals look at us through windows.
<G-vec00417-002-s027><look.anschauen><de> Viele Männer sagen, dass sie sich Pornos anschauen, weil es sie erregt.
<G-vec00417-002-s027><look.anschauen><en> Many men say that they like to look at porn because it excites them.
<G-vec00417-002-s028><look.anschauen><de> Man sollte sich die Farbe des Zahnfleischs unter natürlichem Licht anschauen, da künstliches Licht dem Zahnfleisch einen künstlichen cremigen oder gelben Farbton verpassen kann.
<G-vec00417-002-s028><look.anschauen><en> It is preferable to look at gum color in a room with natural lighting, since artificial lighting can give the gums an artificial creamy or yellow tinge.
<G-vec00417-002-s029><look.anschauen><de> Höchste Zeit also, dass wir uns endlich die Party Poker App genauer anschauen.
<G-vec00417-002-s029><look.anschauen><en> It’s about time to finally have a look at the Party Poker App in detail.
<G-vec00417-002-s030><look.anschauen><de> Wie in jedem Jahr kann man dort die neuesten Projekte aus dem Elektor-Labor und aktuelle Bücher zum Thema Mikrocontroller anschauen und mit Redakteuren und Entwicklern fachsimpeln.
<G-vec00417-002-s030><look.anschauen><en> As every year, you can take a look at the latest hot projects from the Elektor Labs and see the most recent books on microcontrollers or you might just wish to talk shop with our editors and developers.
<G-vec00417-002-s031><look.anschauen><de> Wenn Sie nach einem schönen Törn abends mit Freunden den Anleger genießen, lassen sich schon schöne Bilder des Tages durch die wasserdichte Kamera anschauen.
<G-vec00417-002-s031><look.anschauen><en> If you enjoy spending the evening on the pier with friends after a great sailing trip, why not look back on the day with the photos on the waterproof camera.
<G-vec00417-002-s032><look.anschauen><de> Ich würde gern anschauen, es ist verrückt, nonstop und jeden Tag.
<G-vec00417-002-s032><look.anschauen><en> I would like to look at it's crazy nonstop and everyday.
<G-vec00417-002-s033><look.anschauen><de> Dies bedeutet, dass ein schwuler Mann eine Frau anschauen kann und mit seiner Meinung über ihr Aussehen ehrlich ist.
<G-vec00417-002-s033><look.anschauen><en> This means that a gay man will look at a woman and be honest about his assessment of her appearance.
<G-vec00417-002-s034><look.anschauen><de> In zwei Galerien und einer Töpferwerkstatt können Sie sich die Kunstwerke anschauen oder auch käuflich erwerben.
<G-vec00417-002-s034><look.anschauen><en> In two galleries and one pottery workshop you can look at the works of art and also purchase them.
<G-vec00417-002-s035><look.anschauen><de> Man hat die Kulissen stehen gelassen, hat sie mit Farbe versehen und ist laufend am Instandsetzen, damit neugierige Touristen sich die herrlichen Gebäude anschauen können.
<G-vec00417-002-s035><look.anschauen><en> The setting was left standing, the houses were painted and there are repair works going on continuously, so that interested tourists can have a look at the fine buildings.
<G-vec00417-002-s036><look.anschauen><de> Damit Sie sich Bali nicht anschauen, werden Sie bestimmt nicht gelangweilt sein.
<G-vec00417-002-s036><look.anschauen><en> So that you do not decide to look at Bali, you definitely will not be bored.
<G-vec00417-002-s037><look.anschauen><de> 17 Denn das schnell vorübergehende Leichte der Drangsal bewirkt uns ein über die Maßen überreiches, ewiges Gewicht von Herrlichkeit, 18 da wir nicht das Sichtbare anschauen, sondern das Unsichtbare; denn das Sichtbare ist zeitlich, das Unsichtbare aber ewig.
<G-vec00417-002-s037><look.anschauen><en> 17 For our light affliction, which is but for a moment, worketh out for us a far more exceeding and eternal weight of glory; 18 While we look not at the things which are seen, but at the things which are not seen: for the things which are seen are temporal; but the things which are not seen are eternal.
