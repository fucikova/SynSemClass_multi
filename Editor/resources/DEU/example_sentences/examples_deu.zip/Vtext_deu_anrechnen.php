<G-vec00356-002-s027><offset.anrechnen><de> (4) Ein Mitverschulden ist Ihnen anzurechnen.
<G-vec00356-002-s027><offset.anrechnen><en> (4) Contributory negligence will be offset in accordance with the above.
<G-vec00356-002-s028><offset.anrechnen><de> Wir sind nach Rücknahme der Kaufsache zu deren Verwertung befugt, der Verwertungserlös ist auf die Verbindlichkeiten des Bestellers - abzüglich angemessener Verwertungskosten - anzurechnen.
<G-vec00356-002-s028><offset.anrechnen><en> Revenues from the resale shall be offset against the customer’s accounts payable, less appropriate costs of the resale. 10.3 The customer is under obligation to handle the purchased item with due care.
<G-vec00356-002-s029><offset.anrechnen><de> Diese Vertragsstrafe ist auf einen eventuellen Schadenersatzanspruch nicht anzurechnen.
<G-vec00356-002-s029><offset.anrechnen><en> This contractual penalty shall not be offset against any compensation claim.
<G-vec00356-002-s030><offset.anrechnen><de> Im Mai 2015 hat das EU-Parlament im Rahmen der Novellierung der Erneuerbaren Energie Richtlinie beschlossen, Wasserstoff, der aus regenerativen Ressourcen stammt, mit dem zweifachen seines Energiegehaltes auf die Treibhausgasminderungsverpflichtung der Kraftstoffe anzurechnen.
<G-vec00356-002-s030><offset.anrechnen><en> In May 2015, as part of the revision of the Renewable Energy Directive, the EU parliament decided that hydrogen generated from renewable resources was to count for double its energy content to offset the obligation to reduce greenhouse gas fuel emissions.
<G-vec00356-002-s031><offset.anrechnen><de> Die Vertragsstrafe ist auf einen durch den Verzug entstandenen Schaden anzurechnen.
<G-vec00356-002-s031><offset.anrechnen><en> The contractual penalty shall be offset against the damage or loss suffered through the default.
<G-vec00356-002-s032><offset.anrechnen><de> Der Verwertungserlös ist auf die gegenüber uns bestehenden Verbindlichkeiten des Bestellers – abzüglich angemessener Verwertungskosten – anzurechnen.
<G-vec00356-002-s032><offset.anrechnen><en> The sale amount shall be offset against purchaser’s payables due to us – less reasonable sales costs.
<G-vec00356-002-s033><offset.anrechnen><de> Die Vertragsstrafe ist auf Schadensersatzansprüche wegen Verzögerung der Leistung anzurechnen.
<G-vec00356-002-s033><offset.anrechnen><en> The contractual penalty is to be offset against claims for damages due to a delay in the performance of the service.
<G-vec00402-002-s033><count.anrechnen><de> Wenn dies der Fall ist, werden sie nicht in den Workflow aufgenommen und nicht auf die Zielkonversionsrate des Workflows angerechnet.
<G-vec00402-002-s033><count.anrechnen><en> If they do, they will not be enrolled in the workflow and will not count towards the workflow's goal conversion rate.
<G-vec00402-002-s034><count.anrechnen><de> Ein Einsatz wird in Abhängigkeit von der Zeit, in der sie platziert wurde, auf die Aufgabe angerechnet (unabhängig davon, wann sie gewertet wurde).
<G-vec00402-002-s034><count.anrechnen><en> A bet will count towards the Challenge according to the time it was placed (regardless of when it is settled).
<G-vec00402-002-s035><count.anrechnen><de> Die in iTunes gekauften Filme, Apps, Bücher und Musik werden auf Ihren iCloud-Speicher nicht angerechnet, da iTunes es erlaubt diese erneut herunterzuladen.
<G-vec00402-002-s035><count.anrechnen><en> Videos WhatsApp Backups Note: Movies, apps, books, and music bought in iTunes will not count towards your iCloud storage.
<G-vec00402-002-s036><count.anrechnen><de> Hinweis: Gadgets werden nicht auf Ihr Speicherplatzkontingent angerechnet.
<G-vec00402-002-s036><count.anrechnen><en> Note: Gadgets don’t count toward your storage limits.
<G-vec00402-002-s037><count.anrechnen><de> Gekaufte Musik, Apps, Bücher und Photo Stream werden nicht auf diese Speichergrenze angerechnet.
<G-vec00402-002-s037><count.anrechnen><en> Purchased music, apps, books and Photo Stream do not count against the storage limit.
<G-vec00402-002-s038><count.anrechnen><de> Alle Angebote sind für Lehrende der CAU kostenfrei und werden innerhalb der hochschuldidaktischen Zertifikate der Wissenschaftlichen Weiterbildung als Aufbauworkshops angerechnet.
<G-vec00402-002-s038><count.anrechnen><en> All offers are free of charge for teaching staff at Kiel University, and count as supplementary workshops for university didactic qualifications by the Continuing Professional Development Centre.
<G-vec00402-002-s039><count.anrechnen><de> Markierte Bewertungen werden entfernt und nicht auf die Sternebewertung eines Unternehmens angerechnet.
<G-vec00402-002-s039><count.anrechnen><en> Flagged reviews will be removed and not count toward a business’s star rating.
<G-vec00402-002-s040><count.anrechnen><de> Manuelle Einträge oder Trainingsfahrten werden nicht auf deine Herausforderungsleistungen angerechnet.
<G-vec00402-002-s040><count.anrechnen><en> Manual entries, trainer rides or rides marked private will not count towards your Challenge effort.
<G-vec00402-002-s041><count.anrechnen><de> Manuelle Einträge oder Läufe auf dem Laufband werden nicht auf deine Herausforderungsleistung angerechnet.
<G-vec00402-002-s041><count.anrechnen><en> Manual entries or treadmill runs will not count towards your Challenge effort.
<G-vec00402-002-s042><count.anrechnen><de> Sowohl das Echtgeld als auch das Bonusgeld werden für das Turnier angerechnet.
<G-vec00402-002-s042><count.anrechnen><en> Both Real and Bonus funds spins will count towards the Tournament.
<G-vec00402-002-s043><count.anrechnen><de> Für Stipendiatinnen und Stipendiaten wird die Zahlung des Stipendiums während eines Forschungsaufenthaltes fortgesetzt und auf die vereinbarte Förderdauer angerechnet.
<G-vec00402-002-s043><count.anrechnen><en> During a research visit, scholarship holders continue to receive their payments, which count as part of the agreed period of financial support.
<G-vec00402-002-s044><count.anrechnen><de> Jede nach dem vorliegenden Absatz durchgeführte Prüfung wird auf die nach Absatz 2 vorgeschriebene Mindestanzahl von Prüfungen angerechnet.
<G-vec00402-002-s044><count.anrechnen><en> Any tests carried out under this paragraph shall count towards the minimum number of tests required under paragraph 2.
<G-vec00402-002-s045><count.anrechnen><de> Die Mitteilung erfolgt durch jeden Mitgliedstaat, auf dessen nationales Gesamtziel der Prozentsatz oder die Menge der Elektrizität angerechnet werden soll.
<G-vec00402-002-s045><count.anrechnen><en> The notification shall be made by each Member State towards whose overall national target the proportion or amount of electricity is to count.
<G-vec00402-002-s046><count.anrechnen><de> Manuelle Einträge oder Trainingsfahrten werden nicht auf deine Herausforderung angerechnet.
<G-vec00402-002-s046><count.anrechnen><en> Manual entries or trainer rides will not count towards your Challenge effort.
<G-vec00402-002-s047><count.anrechnen><de> Bitte beachten Sie, dass das Datum der Ein- und Ausreise auf das 30-tägige Limit angerechnet wird.
<G-vec00402-002-s047><count.anrechnen><en> Please note that that date of entry and exit count towards the 30 days Total limit.
<G-vec00402-002-s048><count.anrechnen><de> Die Reservierungsgebühr wird auf die Platzmiete voll angerechnet.
<G-vec00402-002-s048><count.anrechnen><en> The reservation fee will count in full to the pitch hire fee.
<G-vec00402-002-s049><count.anrechnen><de> Eine Hotel-Bonusnacht ist jedoch nicht bonusberechtigend und wird nicht zur Erlangung der Qualifikation für einen Mitgliedslevel angerechnet.
<G-vec00402-002-s049><count.anrechnen><en> However, the hotel reward night is not point qualifying and does not count toward tier qualification.
