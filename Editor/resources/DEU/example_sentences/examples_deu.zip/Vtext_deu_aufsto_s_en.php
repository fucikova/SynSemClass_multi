<G-vec00307-002-s421><encounter.aufstoßen><de> Manchmal ist es zwar nur eine Frage der Umsetzung, aber hin und wieder stoßen wir doch auf Praktiken, die wir nicht erleben wollen.
<G-vec00307-002-s421><encounter.aufstoßen><en> Sometimes, it is just a question of realization, but every now and then we encounter a practice we do not want to experience.
<G-vec00307-002-s422><encounter.aufstoßen><de> Wenn Sie diesen Fehler gemacht haben, stoßen Sie vielleicht ebenfalls auf das iOS 12 WhatsApp Benachrichtigungsproblem.
<G-vec00307-002-s422><encounter.aufstoßen><en> If you have made the same mistake, then you can also encounter the iOS 14/13.7 WhatsApp notification problem.
<G-vec00307-002-s423><encounter.aufstoßen><de> Ungefähr vier von zehn Europäern (38 %) stoßen auf Probleme, wenn sie sich innerhalb der Städte fortbewegen.
<G-vec00307-002-s423><encounter.aufstoßen><en> Around four in ten Europeans encounter problems when travelling within cities (38%).
<G-vec00307-002-s424><encounter.aufstoßen><de> Die Benutzer, für die Sie schreiben, stoßen bei der Verwendung des Produkts vermutlich auf Probleme.
<G-vec00307-002-s424><encounter.aufstoßen><en> The user(s) you are writing for might encounter problems during the life cycle of the product.
<G-vec00307-002-s425><encounter.aufstoßen><de> Wenn Sie auf der Suche nach einer Rolex Mickey Mouse sind, stoßen Sie vermutlich als erstes auf ältere Datejust-Modelle, zum Beispiel mit der Referenznummer 1601.
<G-vec00307-002-s425><encounter.aufstoßen><en> When looking for a Rolex Mickey Mouse, you're likely to first encounter older Datejust models, such as the ref. 1601.
<G-vec00307-002-s426><encounter.aufstoßen><de> Vernachlässigen wir heute Menschen, stoßen wir morgen auf fehlende Zusammenarbeit.
<G-vec00307-002-s426><encounter.aufstoßen><en> If we neglect people today, we encounter non-cooperation tomorrow.
<G-vec00307-002-s427><encounter.aufstoßen><de> Die jährlichen internationalen Konzerttourneen des Orchesters stoßen auf außerordentliche Resonanz.
<G-vec00307-002-s427><encounter.aufstoßen><en> The orchestra’s annual international concert tours encounter extremely receptive audiences.
<G-vec00307-002-s428><encounter.aufstoßen><de> Gleich am Eingang stoßen wir auf der „Eames Lounge Chair“, in schwarzer Sonderedition.
<G-vec00307-002-s428><encounter.aufstoßen><en> At the entrance we encounter the “Eames Lounge Chair” in a black special edition.
<G-vec00307-002-s429><encounter.aufstoßen><de> Ausländische Touristen stoßen selten auf Probleme.
<G-vec00307-002-s429><encounter.aufstoßen><en> Foreign tourists rarely encounter problems.
<G-vec00307-002-s430><encounter.aufstoßen><de> Irgendwie sitzen sie überall zwischen den Stühlen: behinderte Menschen, die das gleiche Geschlecht lieben, stoßen auf Vorurteile und Ausgrenzung von allen Seiten.
<G-vec00307-002-s430><encounter.aufstoßen><en> Somehow they are caught between two worlds: disabled people who are being attracted to the same sex encounter lots of bias and ostracism.
<G-vec00307-002-s431><encounter.aufstoßen><de> Diese und noch viele weitere Veränderungen stoßen im Unternehmen auf eine Kultur, die bei der digitalen Transformation förderlich oder hinderlich wirken kann.
<G-vec00307-002-s431><encounter.aufstoßen><en> These and many other changes encounter a culture in the company that can promote or hinder digital transformation.
<G-vec00307-002-s432><encounter.aufstoßen><de> Dank ihnen stoßen wir einerseits auf praxisrelevante Fragestellungen, die Gegenstand eines Forschungsprojektes werden können.
<G-vec00307-002-s432><encounter.aufstoßen><en> Thanks to them, we encounter practice-relevant questions that can become the subject of a research project.
<G-vec00307-002-s433><encounter.aufstoßen><de> Natürlich, manchmal stoßen wir auf Schwierigkeiten.
<G-vec00307-002-s433><encounter.aufstoßen><en> Of course, sometimes we encounter difficulties.
<G-vec00307-002-s434><encounter.aufstoßen><de> Im pädagogischen Alltag stoßen die Fachleute häufig auf Schwierigkeiten bei der Förderung ihrer Schüler und Auszubildenden und fordern deshalb die Beratung von Fachdiensten ein.
<G-vec00307-002-s434><encounter.aufstoßen><en> In everyday life, educational professionals often encounter difficulties in promoting their pupils and apprentices and therefore call for a consultation of specialized services.
<G-vec00307-002-s435><encounter.aufstoßen><de> Weiter oben auf dem Hang stoßen Sie auf einen Wanderweg (44Min) (900 m) der steil empor steigt.
<G-vec00307-002-s435><encounter.aufstoßen><en> Climbing up the slope you encounter a track (44min) (900 m) and continue along it upwards.
<G-vec00307-002-s436><encounter.aufstoßen><de> Wenn tatsächlich Berufsstoffe in die Haut eindringen, stoßen sie dort auf die Polizeiwache der Oberhaut.
<G-vec00307-002-s436><encounter.aufstoßen><en> When professional products actually infiltrate the skin, they encounter the “security guards” of the outer skin there.
<G-vec00307-002-s437><encounter.aufstoßen><de> Wir stoßen fast ausschließlich auf die Spuren des durch Andere repräsentierten Teils der Lebenswirklichkeit der Romvölker und müssen aus ihnen den für nicht repräsentierbar befundenen Teil erschließen.
<G-vec00307-002-s437><encounter.aufstoßen><en> We encounter the traces of the reality experienced by the Roma almost exclusively through depictions by outsiders, and must use these to imagine those parts considered impossible to represent.
<G-vec00307-002-s438><encounter.aufstoßen><de> Dabei stoßen wir auch auf Neues und bislang Unbekanntes – das ist ja unser grundsätzliches Forschungsziel.
<G-vec00307-002-s438><encounter.aufstoßen><en> In the course of this, we also encounter new and previously unknown things – after all, this is our fundamental research goal.
<G-vec00307-002-s439><encounter.aufstoßen><de> Leider stoßen sie jedoch häufig auf ihre Grenzen, da beworbene Spielzeuge entweder nicht auf ihre Bedürfnisse angepasst sind oder sie beim Gruppenspielen angemessen gefördert werden.
<G-vec00307-002-s439><encounter.aufstoßen><en> However, children with disabilities often encounter difficulties in the game if the marketed toys are not adapted to their needs, or when playing group games.
