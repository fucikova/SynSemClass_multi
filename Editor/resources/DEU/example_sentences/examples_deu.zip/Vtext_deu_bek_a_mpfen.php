<G-vec00078-001-s049><contend.bekämpfen><de> 4 Wer die Weisung verläßt, rühmt den Gottlosen; wer sie aber bewahrt, der bekämpft ihn.
<G-vec00078-001-s049><contend.bekämpfen><en> 4 They that forsake the law praise the wicked: but such as keep the law contend with them.
<G-vec00301-001-s049><contend.bekämpfen><de> 4 Wer die Weisung verläßt, rühmt den Gottlosen; wer sie aber bewahrt, der bekämpft ihn.
<G-vec00301-001-s049><contend.bekämpfen><en> 4 They that forsake the law praise the wicked: but such as keep the law contend with them.
