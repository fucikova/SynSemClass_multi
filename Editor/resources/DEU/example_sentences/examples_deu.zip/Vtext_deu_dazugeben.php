<G-vec00060-001-s076><add.dazugeben><de> Kokosmilch dazugeben und alles mit dem Pürierstab pürieren.
<G-vec00060-001-s076><add.dazugeben><en> Add the coconut milk and blend with an immersion blender.
<G-vec00060-001-s077><add.dazugeben><de> Dann einen Karamell-Thermometer in den Topf legen: die Lebensmittelfarbe, Zimt und Gewürznelken dazugeben, sobald die Temperatur auf 100° ist.
<G-vec00060-001-s077><add.dazugeben><en> Put a caramel thermometer inside the pot: add food coloring, cinnamon and cloves as soon as the temperature reaches 100 degrees.
<G-vec00060-001-s078><add.dazugeben><de> Zum Schluss Essig dazugeben und mit den hartgekochten Eiern garnieren.
<G-vec00060-001-s078><add.dazugeben><en> Finally, add vinegar and garnish with the hard-boiled eggs.
<G-vec00060-001-s079><add.dazugeben><de> 13 Will es aber jemand unbedingt wieder auslösen, so soll er den fünften Teil deiner Schätzung dazugeben.
<G-vec00060-001-s079><add.dazugeben><en> 13 'But if he should ever wish to redeem it, then he shall add one-fifth of it to your valuation.
<G-vec00060-001-s080><add.dazugeben><de> Grappa Nonino Monovitigno® Chardonnay 12 Monate in Barriques, Amaro Nonino und Eis dazugeben.
<G-vec00060-001-s080><add.dazugeben><en> Add Grappa Nonino Chardonnay in barriques, Amaro Nonino and ice.
<G-vec00060-001-s081><add.dazugeben><de> Die gleiche Menge an Zucker in einem Topf leicht erhitzen, Zitronensaft dazugeben.
<G-vec00060-001-s081><add.dazugeben><en> Weigh the pulp and add equal amount of sugar.
<G-vec00060-001-s082><add.dazugeben><de> Wem die Salsa zu scharf ist, der kann die Avocado dazugeben und die Sauce nochmals gut pürieren.
<G-vec00060-001-s082><add.dazugeben><en> If you think the salsa is too spicy, add the avocado to the blender and mix again very well.
<G-vec00060-001-s083><add.dazugeben><de> Die Kartoffeln waschen und mit der Schale im salzigen Wasser kochen; in der Zeit den Speck mit Butter in einer Pfanne anbraten, nach einigen Minuten die gehackte Zwiebel dazugeben und köcheln lassen, solange bis sie weich und glasig ausschaut.
<G-vec00060-001-s083><add.dazugeben><en> Wash the potatoes and boil them in salted water in their skin. Meanwhile, brown the bacon with butter in a pan and, after a few minutes, add the chopped onion, turn off as soon as the onion is soft and transparent.
<G-vec00060-001-s084><add.dazugeben><de> Mehl und Hefe vermischen und die Milch dazugeben.
<G-vec00060-001-s084><add.dazugeben><en> Add the flour and lightly brown it.
<G-vec00060-001-s085><add.dazugeben><de> Kurz vor dem Servieren den Karamell dazugeben.
<G-vec00060-001-s085><add.dazugeben><en> Add caramel right before serving.
<G-vec00060-001-s086><add.dazugeben><de> Man kann auch Nüsse wie zum Beispiel Cashew dazugeben.
<G-vec00060-001-s086><add.dazugeben><en> You can add also nuts like cashew for example.
<G-vec00060-001-s087><add.dazugeben><de> Eierschwammerl und Thymian dazugeben und alles bissfest dünsten.
<G-vec00060-001-s087><add.dazugeben><en> Add chanterelles and thyme and stew all until al dente.
<G-vec00060-001-s088><add.dazugeben><de> Die Milch in einem Topf erhitzen und die Haferflocken dazugeben.
<G-vec00060-001-s088><add.dazugeben><en> Heat the milk in a pan and add the oatmeal.
<G-vec00060-001-s089><add.dazugeben><de> Anschließend Wasser, geriebene Kartoffeln, Gemüsebouillonwürfel und 1 TL Salz dazugeben und zum Kochen bringen.
<G-vec00060-001-s089><add.dazugeben><en> Then add the water, the grated potato, the stock cubes and 1 teaspoon of salt and bring to the boil.
<G-vec00060-001-s090><add.dazugeben><de> Fleischwürfel dazugeben und anbraten.
<G-vec00060-001-s090><add.dazugeben><en> Add meat cubes and fry them.
<G-vec00060-001-s091><add.dazugeben><de> Das zerkleinerte Hähnchen dazugeben und mit einer Prise Salz, Pfeffer und Petersilie würzen.
<G-vec00060-001-s091><add.dazugeben><en> Add the shredded chicken and season with a pinch of salt, pepper and parsley.
<G-vec00060-001-s092><add.dazugeben><de> Nun Bananen, Ananas (und weitere Früchte) dazugeben, Kokosraspeln beifügen und mit der Gemüsebouillon aufgiessen.
<G-vec00060-001-s092><add.dazugeben><en> Than add bananas, pineapple (and other fruits), add the coconut ice and pour the vegetable broth on it.
<G-vec00060-001-s093><add.dazugeben><de> 30 Minuten im auf 200° / Gas Stufe 4 vorgeheizten Ofen backen, gewürzte Lammkotelett je nach Dicke für die letzten 10-15 Minuten dazugeben.
<G-vec00060-001-s093><add.dazugeben><en> Bake it in a preheated oven for 30 minutes at 200 ° / gas level 4, add seasoned lamb chops to it depending on the thickness at the last 10 – 15 minutes.
<G-vec00060-001-s094><add.dazugeben><de> Wenn der ganze Zucker geschmolzen ist, weiche Butter und Salz dazugeben (wir empfehlen, sich von der Pfanne zu entfernen, da es spritzen kann undman sich verbrennen könnte).
<G-vec00060-001-s094><add.dazugeben><en> As soon as all the sugar is melted, add soft butter and salt (we suggest you to go away from the pan as it could splatter and you might burn yourself).
<G-vec00407-001-s076><add.dazugeben><de> Kokosmilch dazugeben und alles mit dem Pürierstab pürieren.
<G-vec00407-001-s076><add.dazugeben><en> Add the coconut milk and blend with an immersion blender.
<G-vec00407-001-s078><add.dazugeben><de> Zum Schluss Essig dazugeben und mit den hartgekochten Eiern garnieren.
<G-vec00407-001-s078><add.dazugeben><en> Finally, add vinegar and garnish with the hard-boiled eggs.
<G-vec00407-001-s081><add.dazugeben><de> Die gleiche Menge an Zucker in einem Topf leicht erhitzen, Zitronensaft dazugeben.
<G-vec00407-001-s081><add.dazugeben><en> Weigh the pulp and add equal amount of sugar.
<G-vec00407-001-s082><add.dazugeben><de> Wem die Salsa zu scharf ist, der kann die Avocado dazugeben und die Sauce nochmals gut pürieren.
<G-vec00407-001-s082><add.dazugeben><en> If you think the salsa is too spicy, add the avocado to the blender and mix again very well.
<G-vec00499-001-s091><add.dazugeben><de> Das zerkleinerte Hähnchen dazugeben und mit einer Prise Salz, Pfeffer und Petersilie würzen.
<G-vec00499-001-s091><add.dazugeben><en> Add the shredded chicken and season with a pinch of salt, pepper and parsley.
