<G-vec00078-001-s147><commit.committen><de> Wenn Sie denken, dass ein neues Dokument oder ein Verzeichnis aufgenommen werden sollte, erstellen und committen Sie es nicht einfach, schlagen Sie es vor auf der Liste.
<G-vec00078-001-s147><commit.committen><en> If you think a new document or directory should be added, don't just create and commit it, but propose it on the list.
<G-vec00078-001-s148><commit.committen><de> Wenn Sie es committen würden, selbst mit einem unscheinbaren Kommentar, könnte jemand die Änderung bemerken und verstehen.
<G-vec00078-001-s148><commit.committen><en> If you were to commit it, even with an innocent-looking log message, someone might notice and understand the change.
<G-vec00078-001-s149><commit.committen><de> Vollständig Commit-Berechtigte können über alles abstimmen, genau so wie sie überall committen können, und nur Vollberechtigte können über die Aufnahmen von neuen Committern jedweder Art abstimmen.
<G-vec00078-001-s149><commit.committen><en> Full committers can vote on anything, just as they can commit anywhere, and only full committers vote on adding new committers of any kind.
<G-vec00078-001-s150><commit.committen><de> Sie sind bereit, zu committen, jedoch sollten Sie zuerst die Ausgabe von svn stat und svn diff überprüfen, um sicher zu gehen, dass alles in Ordnung ist.
<G-vec00078-001-s150><commit.committen><en> You are ready to commit, but you should first check the output of svn stat and svn diff to make sure everything is in order.
<G-vec00078-001-s151><commit.committen><de> "Wenn Dateien HG noch nicht bekannt sind, musst du sie mit ""Add Files"" einfügen (Die Checkbox neben der Datei anklicken), damit du sie committen kannst."
<G-vec00078-001-s151><commit.committen><en> If some of your files aren't known to HG yet (the box before the file isn't ticked), you have to add them (tick the box) to be able to commit them.
<G-vec00078-001-s152><commit.committen><de> Committen Sie den Fix nicht zum Projektarchiv.
<G-vec00078-001-s152><commit.committen><en> Do not commit the fix to the repository.
<G-vec00078-001-s153><commit.committen><de> Der Abgleich von Ports aus der PR-Datenbank hilft uns diese schneller zu committen, und zeigt auch, dass Sie wissen, worum es geht.
<G-vec00078-001-s153><commit.committen><en> Checking ports in the PR database will both make it faster for us to commit them, and prove that you know what you are doing.
<G-vec00078-001-s154><commit.committen><de> Es kann zum Beispiel Freiwillige geben, die freien Zugriff auf die Dokumentation habem, die aber nicht an den Code selber committen können.
<G-vec00078-001-s154><commit.committen><en> For example, there might be contributors whose commit access gives them free rein in the documentation, but who do not commit to the code itself.
<G-vec00311-002-s145><commit.committen><de> Wenn Dateien HG noch nicht bekannt sind, musst du sie mit "Add Files" einfügen (Die Checkbox neben der Datei anklicken), damit du sie committen kannst.
<G-vec00311-002-s145><commit.committen><en> If some of your files aren't known to HG yet (the box before the file isn't ticked), you have to add them (tick the box) to be able to commit them.
<G-vec00311-002-s146><commit.committen><de> Ziel des Workshops ist es, alle produktrelevanten Perspektiven an einem Tisch zu versammeln und gemeinsam eine Projektdefinition zu erarbeiten, auf die sich alle anwesenden Stakeholder committen können.
<G-vec00311-002-s146><commit.committen><en> The goal of the workshop is to bring together all product-relevant perspectives and to jointly develop a project definition to which all present stakeholders can commit.
<G-vec00311-002-s147><commit.committen><de> Zu den Highlights gehören das Wiederherstellen einzelner Dateien oder des gesamten Projektes zu einem bestimmten Projektstand, das Hinzufügen von Tags direkt beim Committen oder im Nachgang, sowie das Ignorieren bestimmter Dateien oder Datentypen mit einem Klick.
<G-vec00311-002-s147><commit.committen><en> Among the highlights are the ability to restore individual files or the entire project at a certain project status, the addition of tags directly when executing the Commit command or subsequently, as well as the ability to ignore certain files or data types at the click of a button.
<G-vec00311-002-s148><commit.committen><de> In jedem Fall sollte die Standardvorgehensweise zum Einreichen von Änderungen beachtet werden - es sei denn, Sie haben das Recht diese direkt in den Ports-Baum zu committen.
<G-vec00311-002-s148><commit.committen><en> In either case, the standard procedure for submitting your change should be followed unless you have rights to commit it directly to the ports tree.
