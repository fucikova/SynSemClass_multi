<G-vec00169-001-s066><fetch.besorgen><de> Sie graben die Löcher für die Posten, besorgen Steine, setzen eine Lebhecke und flechten den Maschendrahtzaun selbst.
<G-vec00169-001-s066><fetch.besorgen><en> They dig the holes for the posts, fetch stones, put in hedges and weave the wire mesh themselves.
<G-vec00169-001-s067><fetch.besorgen><de> Nach dem Treffen müssen Sie sich den GnuPG-Schlüssel besorgen, um ihn signieren zu können.
<G-vec00169-001-s067><fetch.besorgen><en> After the meeting you'll have to fetch the GnuPG key in order to sign it.
<G-vec00169-001-s079><fetch.besorgen><de> Mit dem Fahrrad können Sie sich jeden Tag zum Deckfrühstück frische Brötchen und Ihre Zeitung besorgen.
<G-vec00169-001-s079><fetch.besorgen><en> And you can cycle off to fetch fresh rolls and your newspaper every day in time for your breakfast on deck.
<G-vec00169-001-s080><fetch.besorgen><de> Dann schmeckt Ihr Coq au Vin am Abend noch besser… Mit dem Fahrrad können Sie sich jeden Tag zum Deckfrühstück frische Brötchen und Ihre Zeitung besorgen.
<G-vec00169-001-s080><fetch.besorgen><en> Which will make your Coq au Vin in the evening taste even better… And you can cycle off to fetch fresh rolls and your newspaper every day in time for your breakfast on deck.
<G-vec00243-002-s187><concern.besorgen><de> - Es besorgt mich, dass die für Ende November geplante Umsiedlung der 24 Roma-Familien aus der Siedlung Belvil nach Orlovsko Naselje offenbar nicht angemessen vorbereitet wurde.
<G-vec00243-002-s187><concern.besorgen><en> - Expressing concern to the Mayor of Belgrade at the inadequate preparation by the City of Belgrade authorities for the resettlement of 24 families from the informal settlement at Belvil to Orlovsko naselje at the end of November.
<G-vec00243-002-s188><concern.besorgen><de> Im Juni 2015 zeigten sich die EU-Abgeordneten zutiefst besorgt "über die Unterstützung und Finanzierung radikaler und extremistischer Parteien in den EU-Mitgliedstaaten durch Russland".
<G-vec00243-002-s188><concern.besorgen><en> In June 2015 MEPs expressed deep concern with Russia’s financing of radical and extremist parties in the EU.
<G-vec00243-002-s189><concern.besorgen><de> Kirchenvertreter und Rabbiner unterstrichen im Neuen Rathaus von Hannover die Bedeutung des Asylrechts und zeigten sich tief besorgt über die Zunahme fremdenfeindlicher Gewalt in den vergangenen Monaten.
<G-vec00243-002-s189><concern.besorgen><en> In Hanover's New Town Hall, church leaders and rabbis underlined the importance of asylum law and expressed deep concern about the increase in xenophobic violence in the last few months.
<G-vec00243-002-s190><concern.besorgen><de> Viele von uns sind besorgt über ein gemeinsames Thema - Haarausfall.
<G-vec00243-002-s190><concern.besorgen><en> Many of us are concern about a common topic - hair loss.
<G-vec00243-002-s191><concern.besorgen><de> Ihr seid ständig unterwegs, strapaziert euren Körper und zermürbt euer Gehirn, um eures Fleisches willen und um eurer Söhne und Töchter willen, aber keiner von euch zeigt sich besorgt.
<G-vec00243-002-s191><concern.besorgen><en> You are constantly on the go, taxing your body and racking your brain, for the sake of your flesh, and for your sons and daughters, yet not one of you shows any concern for My will.
<G-vec00243-002-s192><concern.besorgen><de> Erscheinungsdatum 20.11.2011 Bundesaußenminister Guido Westerwelle hat sich besorgt über die Unruhen in Ägypten gezeigt.
<G-vec00243-002-s192><concern.besorgen><en> 20.11.2011 Federal Foreign Minister Guido Westerwelle has expressed his concern about the recent unrest in Egypt.
<G-vec00243-002-s193><concern.besorgen><de> Kinder sind unsere größte Inspiration und unser Daseinsgrund, aber gleichzeitig sind wir auch immer um ihre Sicherheit besorgt.
<G-vec00243-002-s193><concern.besorgen><en> Our biggest inspiration and reason for being, children, are also our biggest concern.
<G-vec00243-002-s194><concern.besorgen><de> Wenn wir unser Projekt über "Vielfalt bewirken" in Vorschulen vorstellen, zeigten sich die Menschen überrascht und besorgt.
<G-vec00243-002-s194><concern.besorgen><en> Often, when presenting our project about “bringing diversity” into pre-primary schools people showed surprise and concern.
<G-vec00243-002-s195><concern.besorgen><de> Und auf diese Weise wird es zum Mittelpunkt unseres Lebens und Paulus ist besorgt, dass Christen irgendwie von dieser einfachen Hingabe an Christus abgelenkt werden könnten und sie ihre Kicks durch andere Sachen bekämen, glaubt mir, das taten sie und tun es noch.
<G-vec00243-002-s195><concern.besorgen><en> And so that becomes the focus of our life and Paul's concern is that somehow Christians might get distracted from simplicity of devotion to Christ and they might get off on other stuff, which, believe me, they did and still do.
<G-vec00243-002-s196><concern.besorgen><de> Neben den Anliegen bezüglich der Anwendung der Todesstrafe zeigen sich die Mitgliedstaaten vor allem besorgt über das Behandeln ethnischer und religiöser Minderheiten, einschließlich Dr. Shaheeds, der über den Missbrauch der religiösen Minorität Baha’i und der kurdischen ethnischen Minorität im Iran berichtet.
<G-vec00243-002-s196><concern.besorgen><en> In addition to concerns over the application of the death penalty, member states primarily expressed concern over the treatment of ethnic and religious minorities, including Dr. Shaheed’s reports on abuses against the Baha’i religious minority and the Kurdish ethnic minority in Iran.
<G-vec00243-002-s197><concern.besorgen><de> Während des Treffens äußerte sich al-Maliki besorgt über die Entscheidung des UNRWA, seine Finanzhilfe zu stoppen und forderte die internationale Gemeinschaft auf, ihren Verpflichtungen nachzukommen und die Mittel zu liefern, die im Rahmen der Kairoer Geberkonferenz zum Wiederaufbau des Gazastreifens versprochen wurden.
<G-vec00243-002-s197><concern.besorgen><en> He expressed concern over UNRWA's decision to halt its financial support and urged the international community to keep its promises and transfer the funds pledged at the conference in Cairo.
<G-vec00243-002-s198><concern.besorgen><de> Ich konnte sehen, dass Sie besorgt waren, und plötzlich kamen alle Emotionen in mir hoch.
<G-vec00243-002-s198><concern.besorgen><en> I could see what was obvious concern on your face, and all of a sudden I was overcome with emotion.
<G-vec00243-002-s199><concern.besorgen><de> Lianne und Klaas sind sehr besorgt über ihre Gäste.
<G-vec00243-002-s199><concern.besorgen><en> and Klaas are very concern about their guests.
<G-vec00243-002-s200><concern.besorgen><de> Die Bürgerinnen und Bürger der Länder am unteren Ende des CPI zeigen sich in der Regel ebenso besorgt über Korruption, wie die Öffentlichkeit in den Ländern, die gute Werte erreichen.
<G-vec00243-002-s200><concern.besorgen><en> Citizens of those countries/territories that score at the lower end of the CPI often show the same concern about and condemnation of corruption as the public in countries that perform strongly.
<G-vec00243-002-s201><concern.besorgen><de> Bundesaußenminister Guido Westerwelle hat sich besorgt über den Ausbruch der Kämpfe im Sudan gezeigt.
<G-vec00243-002-s201><concern.besorgen><en> Federal Foreign Minister Guido Westerwelle expressed his grave concern about the new fighting in Darfur.
<G-vec00243-002-s202><concern.besorgen><de> Auch das UN-Komitee zur Abschaffung der Rassischen Diskriminierung zeigte sich mehrfach sehr besorgt.
<G-vec00243-002-s202><concern.besorgen><en> The UN Committee on the Elimination of Racial Discrimination also repeatedly expressed their concern.
<G-vec00243-002-s203><concern.besorgen><de> 1961 Auf einer Pressekonferenz unmittelbar vor Abschluss seines zweitägigen Berlin-Besuches zeigt sich Bundeskanzler Konrad Adenauer besorgt über die Fluchtwelle aus der DDR: „Es scheint eine Panik ausgebrochen zu sein in der Zone, und offenbar ist der Druck auf die Menschen dort verstärkt worden und dadurch dieses Gefühl: nun wollen wir noch so schnell wie möglich in die Freiheit kommen, zum Verbot „des sogenannten Kirchentages".
<G-vec00243-002-s203><concern.besorgen><en> 13 July 1961 At a press conference marking the conclusion of his two-day visit to Berlin, West German Chancellor Konrad Adenauer voices concern about the tide of refugees from the GDR: "Panic seems to have broken out in the Zone, and obviously pressure has been increased on people there, strengthening the feeling: now we want to get to freedom as quickly as possible. more
<G-vec00243-002-s204><concern.besorgen><de> In Russland zeigt man sich allerdings auch besorgt über gelegentliche frühere anti-russische Äußerungen dieser neuen Staatsführung und fürchtet, dass Präsident Saakaschwili Militäraktionen starten könnte, um die abtrünnigen Republiken Abchasien und Südossetien erneut unter georgische Kontrolle zu bringen.
<G-vec00243-002-s204><concern.besorgen><en> But there is also concern about the previous occasional anti-Russian statements of this new generation of leaders, and fear that President Saakashvili might launch a military campaign to bring the breakaway republics of Abkhazia and South Ossetia back under Tbilisi's rule.
<G-vec00243-002-s205><concern.besorgen><de> „Bist du okay?“ fragte Mark besorgt.
<G-vec00243-002-s205><concern.besorgen><en> “You’re okay, right?” Mark asked, concern on his face.
<G-vec00243-002-s435><worry.besorgen><de> Seien Sie unbesorgt, Ihre wertvollen Inhalte sind in guten Händen.
<G-vec00243-002-s435><worry.besorgen><en> Don’t worry, your valuable content is in good hands.
<G-vec00243-002-s436><worry.besorgen><de> Auch auf Smartphones, Tablets und Fire TV-Sticks können Sie unbesorgt surfen und streamen.
<G-vec00243-002-s436><worry.besorgen><en> You can surf and stream without worry, even on smartphones, tablets, and Fire TV Sticks.
<G-vec00243-002-s437><worry.besorgen><de> Doch seien Sie unbesorgt; wir haben eine Anleitung für Sie vorbereitet, die Sie unten finden können.
<G-vec00243-002-s437><worry.besorgen><en> But do not worry; we have prepared a guide for you, which you can find below.
<G-vec00243-002-s438><worry.besorgen><de> Dadurch wird für optimale Lichtdurchflutung gesorgt und wem das beim Schlafen stört, der sei unbesorgt, da wir Rollläden haben die das Schlafzimmer auf Wunsch komplett verdunkeln.
<G-vec00243-002-s438><worry.besorgen><en> This provides for optimum light transmission, and if that interferes with sleep, who do not worry because we have shutters which darken the bedroom at the request completely.
<G-vec00243-002-s439><worry.besorgen><de> Er hat einen großen Jagdhund - aber sei unbesorgt - der Hund rennt normalerweise nicht in der Wohnung herum.
<G-vec00243-002-s439><worry.besorgen><en> He has a big dog - but don't worry - the dog is normaly not running around.
<G-vec00243-002-s440><worry.besorgen><de> Wenn Sie sich noch immer nicht ganz sicher sind, welche Lagerraumgröße Sie benötigen, seien Sie unbesorgt.
<G-vec00243-002-s440><worry.besorgen><en> If you still are not completely sure about the unit size you need, don't worry.
<G-vec00243-002-s441><worry.besorgen><de> Sprechet unbesorgt, und lasset keinen Zweifel aufkommen, ob euer Handeln Meinem Willen entspricht, denn so die Zeit eures Wirkens für Mich gekommen ist, nehme Ich Besitz von euch, und widerstandslos sollet ihr Mir folgen, d.h. tun, was das Herz euch zu tun heißt.
<G-vec00243-002-s441><worry.besorgen><en> Speak without worry, and don't question whether your action corresponds to My will, for once the time for your activity comes I will take possession of you, and you shall follow Me without resistance, that is, you shall do whatever your heart tells you to do.
<G-vec00243-002-s442><worry.besorgen><de> Seien Sie unbesorgt, da wir Ihnen mindestens 2 Blastozysten garantieren (D+5 Embryonen).
<G-vec00243-002-s442><worry.besorgen><en> Don’t worry, we guarantee a minimum of two blastocysts (D+5 embryos).
<G-vec00243-002-s443><worry.besorgen><de> Seien Sie unbesorgt, Locaboat bietet mit seinen verschiedenen Typen die größte Hausbootflotte in Europa.
<G-vec00243-002-s443><worry.besorgen><en> Don’t worry, Locaboat offers the largest fleet and the widest range of pénichettes® in Europe.
<G-vec00243-002-s444><worry.besorgen><de> "Nein", antwortete er, "aber seien Sie unbesorgt.
<G-vec00243-002-s444><worry.besorgen><en> “No,” he replied, “but don’t worry.
<G-vec00243-002-s445><worry.besorgen><de> Nia: Seid unbesorgt.
<G-vec00243-002-s445><worry.besorgen><en> Nia: Don't worry, dear one.
<G-vec00243-002-s446><worry.besorgen><de> Dank unserer beheizten Pools können Sie auch früh morgens unbesorgt ins Wasser springen.
<G-vec00243-002-s446><worry.besorgen><en> There’s no need to worry about the temperature of the water: you can dive into our heated swimming pool while waiting for Summer.
<G-vec00243-002-s447><worry.besorgen><de> Falls Sie es vorziehen, Ihr eigenes Fahrrad mit in den Urlaub zu nehmen, seien Sie unbesorgt: Das Hotel Corallo Bibione gehört zur Vereinigung “Bike Hotel” und stellt Ihnen einen eigens dafür vorgesehenen Abstellraum mit einem Bereich für die Wartung Ihres treuen Zweirads zur Verfügung.
<G-vec00243-002-s447><worry.besorgen><en> If you are a true cycling enthusiast and prefer to take your bike on holiday, don’t worry: Hotel Corallo Bibione joins the "Bike Hotel" product club and provides you with a special area for storing and maintaining your bike.
