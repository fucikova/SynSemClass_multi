<G-vec00291-001-s024><allocate.allokieren><de> Ein zweiter Punkt betrifft die Fähigkeit, als Unternehmen Mittel und Ressourcen entlang der die Transformation schnell und entschlossen um zu allokieren.
<G-vec00291-001-s024><allocate.allokieren><en> A second point concerns the ability as a company to allocate means and resources along the transformation path quickly and determinedly.
<G-vec00291-001-s025><allocate.allokieren><de> Um dynamische Strukturen zu allokieren, verwenden Sie AllocateStructure() ().
<G-vec00291-001-s025><allocate.allokieren><en> To allocate dynamic structure, use AllocateStructure() (). Example
<G-vec00291-001-s026><allocate.allokieren><de> Dabei wird soweit wie möglich anerkannt, dass es einzelne heterogene Unternehmen sind, die durch ihre individuellen Fähigkeiten, Innovationen hervorzubringen und Ressourcen effizient zu allokieren, die Entwicklung auf höherer Aggregationsebene bestimmen.
<G-vec00291-001-s026><allocate.allokieren><en> Thereby, we recognize that these are individual heterogeneous firms with their specific capabilities to innovate and to efficiently allocate scarce resources that shape patterns at higher level of aggregation (e.g. cause structural change).
<G-vec00291-001-s027><allocate.allokieren><de> Man moechte dass die RPC-Routinen den Speicherplatz für die Uebertragenen Daten selbst allokieren.
<G-vec00291-001-s027><allocate.allokieren><en> One would like RPC functions to allocate memory for the transferred data.
<G-vec00291-001-s028><allocate.allokieren><de> Bei dynamisch verbundenen Treiber sollten die Entwickler vorsichtig sein, unbenutzte Bereiche der Portadressen für ihr Gerät zu allokieren.
<G-vec00291-001-s028><allocate.allokieren><en> For dynamically linked drivers, the developer should be careful to allocate unused range of port addresses for their device.
<G-vec00291-001-s029><allocate.allokieren><de> Mit CCH Tagetik Allokationen können Sie Ihre Fixkosten einfach identifizieren und variable Kosten auf sehr detaillierten Level allokieren, wodurch Sie wichtige Entscheidungsinformationen erhalten.
<G-vec00291-001-s029><allocate.allokieren><en> With CCH Tagetik Allocations, you can easily identify your fixed costs and allocate variable costs at a very detailed level that deliver real insights for decision-making.
<G-vec00291-001-s030><allocate.allokieren><de> Fondsmanager brauchen neben dem Tracking Error weitere Instrumente, um ihr Risiko zu allokieren.
<G-vec00291-001-s030><allocate.allokieren><en> Managers need other tools besides tracking error to help them allocate risk
