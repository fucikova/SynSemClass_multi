<G-vec00301-001-s030><rectify.beheben><de> Es ist Zeit für sie zu gehen, und für uns, den von ihnen auf eurem Planeten angerichteten Schaden zu beheben.
<G-vec00301-001-s030><rectify.beheben><en> It is time for them to leave, and for us to rectify the damage they have done on your planet.
<G-vec00301-001-s038><correct.beheben><de> Ihre Operationen sind umsonst, und sie können genau dieses Problem beheben.“ Die gute Nachricht machte der Familie Hoffnung.
<G-vec00301-001-s038><correct.beheben><en> They do surgeries, for free, to correct this problem.” The good news gave the family hope.
<G-vec00301-001-s039><correct.beheben><de> Die Regierung ist bemüht, dieses Problem zu beheben.
<G-vec00301-001-s039><correct.beheben><en> The government is working to correct this problem.
<G-vec00301-001-s040><correct.beheben><de> Es unterstützt uns dabei, Abläufe transparenter zu gestalten, Fehler systematisch zu beheben und einen reibungslosen Produktionsprozess unserer Temperaturbegrenzer sicherzustellen.
<G-vec00301-001-s040><correct.beheben><en> This allows us to make processes more transparent, correct errors systematically and ensure a smooth production process.
<G-vec00301-001-s041><correct.beheben><de> Die Validierung des Mappings ist ein optionaler Schritt, mit Hilfe dessen Sie potenzielle Mapping-Fehler- und Warnungen sehen und beheben können, bevor Sie das Mapping ausführen.
<G-vec00301-001-s041><correct.beheben><en> Validating a mapping is an optional step that enables you to see and correct potential mapping errors and warnings before you run the mapping.
<G-vec00301-001-s042><correct.beheben><de> WeatherTech Europe Srl garantiert Ihnen Folgendes: Wenn Sie mit der Leistung unseres Produkts nicht hundertprozentig zufrieden sind und wir das Problem nicht beheben können, senden Sie das Produkt einfach innerhalb von 30 Tagen nach dem Einkauf zurück und wir erstatten den gesamten Kaufbetrag.
<G-vec00301-001-s042><correct.beheben><en> WeatherTech Europe, Srl guarantees that if for any reason you are not 100% satisfied with the performance of our product, and we cannot correct the problem, simply return the product and we will refund the entire amount of your purchase within 30 days of purchase.
<G-vec00301-001-s043><correct.beheben><de> Die Partei und ihr Zentralkomitee haben sie nicht verheimlicht und haben sich bemüht, sie zu beheben.
<G-vec00301-001-s043><correct.beheben><en> The Party and the Central Committee did not conceal them and strove to correct them.
<G-vec00301-001-s044><correct.beheben><de> Treten Probleme auf, kann PepsiCo Fehler beheben, bevor daraus größere Komplikationen entstehen.
<G-vec00301-001-s044><correct.beheben><en> If issues arise, they can correct mistakes before causing any bigger problems downstream.
<G-vec00301-001-s045><correct.beheben><de> Unabhängig von den Auswirkungen, Sie müssen so schnell wie möglich das Problem beheben, wenn Sie möchten, die leistungsstarken Streaming-Features von Airplay genießen.
<G-vec00301-001-s045><correct.beheben><en> Regardless of the implications, you have to correct the issue as soon as possible, if you want to enjoy the powerful streaming features of Airplay.
<G-vec00301-001-s046><correct.beheben><de> 6.6 Die Gewährleistung erlischt, wenn der Besteller oder Dritte ohne unsere schriftliche Zustimmung Änderungen oder Reparaturen an unseren Produkten vornehmen, ferner, wenn der Besteller nicht umgehend geeignete Maßnahmen trifft, damit wir den Mangel beheben und damit der Schaden gemindert und nicht größer wird.
<G-vec00301-001-s046><correct.beheben><en> 6.6 The warranty is void if the customer or a third party undertakes without our written permission changes or repairs in our products, further, if the customer does not immediately take appropriate measures to ensure that we correct the deficiency and thus mitigated the damage and is not larger.
<G-vec00301-001-s047><correct.beheben><de> Mit Erfolg setzen Sie Aktionen in Gang, um soziale Ungerechtigkeiten zu beheben, und wer seine Untätigkeit mit Schwäche bemäntelt, hat bei Ihnen verspielt.
<G-vec00301-001-s047><correct.beheben><en> You can stimulate action to correct social injustices and will not tolerate weakness as a defense for inaction by anyone.
<G-vec00301-001-s048><correct.beheben><de> Manchmal führt es auch zu erheblichen Projektverzögerungen oder, schlimmer noch, ungeplanten Zusatzkosten, um den Fehler zu beheben.
<G-vec00301-001-s048><correct.beheben><en> Sometimes it also leads to considerable project delays or, worse, unplanned additional costs to correct the error.
<G-vec00301-001-s049><correct.beheben><de> "Um dies zu beheben, müssen Sie die Liste der Einträge für unsere Software in Ihrer Firewall finden und diesen die Berechtigung ""alles zulassen"" zuweisen (oder eine vergleichbare Berechtigung, die einen uneingeschränkten Zugriff gewährt)."
<G-vec00301-001-s049><correct.beheben><en> To correct this you will need to locate that list of programs, and set their permissions by selecting Permit All or the equivalent of unrestricted access.
<G-vec00301-001-s050><correct.beheben><de> So beheben Sie einen pathologischen Prozess mit solchen Eigenschaften der Zutaten von Nahrungsergänzungsmitteln, als entzündungshemmende, gallentreibend, reparative, Entgiftung und andere.
<G-vec00301-001-s050><correct.beheben><en> To correct a pathological process using such properties of ingredients of food supplements, as anti-inflammatory, cholagogue, reparative, detoxification, and others.
<G-vec00301-001-s051><correct.beheben><de> Und wir wussten nun, dass der Mensch ein ganz normales Lebewesen ist, welches sich aus den Affenartigen entwickelt hat und dieser am besten danach streben sollte, durch den Erwerb neuen Wissens Unklarheiten zu beseitigen, Fragen zu beantworten und Irrtümer zu beheben.
<G-vec00301-001-s051><correct.beheben><en> And we already knew that humans are just ordinary creatures that developed from ape-like ancestors and that they should ideally strive to abolish all uncertainties, answer questions and correct errors through knowledge acquisition.
<G-vec00301-001-s052><correct.beheben><de> Im ZIM-Forschungsnetzwerk IT-Großprojekte soll ein Toolset zur durchgängigen Unterstützung der Prozesse, Aktivitäten und Verfahrensabläufe von IT-Großprojekten implementiert werden, um den Ablauf konsequent von der Anforderungsbeschreibung bis zur Testphase effizienter zu gestalten und etwaige Fehler frühzeitig zu beheben.
<G-vec00301-001-s052><correct.beheben><en> "With the ZIM research network ""Large Scale IT Projects"", a tool set for the continuous support of processes, activities and procedures of large IT projects shall be implemented to make the entire process – from requirements prescription up to the testing phase – more efficient and to correct potential errors early on."
<G-vec00301-001-s053><correct.beheben><de> Microsoft stellt fest, dass das Problem fortbestehen können nach der installation des Updates und, dass die admins sollten zu entfernen und installieren Sie die Remote-NDIS-adapter erneut mit dem Geräte-Manager, um das Problem zu beheben.
<G-vec00301-001-s053><correct.beheben><en> Microsoft notes that the issue may persist after update installation, and that admins should remove and install the Remote NDIS adapter anew using the Device Manager to correct the issue.
<G-vec00301-001-s054><correct.beheben><de> Nach Diagnosestellung der Gynäkomastie ist oft eine kosmetische Operation vonnöten, um das Problem zu beheben.
<G-vec00301-001-s054><correct.beheben><en> Once gynaecomastia is diagnosed cosmetic surgery is often needed to correct the problem.
<G-vec00301-001-s055><correct.beheben><de> Was wir in diesem Bereich getan haben, ist die gebräuchlichen HTML Formatierungsfehler und Irrtümer aufzulisten - und wie man diese beheben kann.
<G-vec00301-001-s055><correct.beheben><en> What we've done in this space is list out the most common HTML formatting errors and mistakes – and how to correct them.
<G-vec00301-001-s056><correct.beheben><de> Wenn Sie die Windows-Firewall mithilfe einer Gruppenrichtlinie deaktivieren oder für die Windows-Firewall eine Regel konfigurieren, die den gesamten eingehenden Netzwerkverkehr zulässt, wird der Benutzer vom Windows-Sicherheitscenter benachrichtigt, dass Sicherheitsprobleme aufgetreten sind, die der Benutzer beheben sollte.
<G-vec00301-001-s056><correct.beheben><en> If you use Group Policy to disable Windows Firewall, or configure Windows Firewall with a rule that allows all inbound network traffic, then Windows Security Center will alert the user that there are security issues that the user should correct.
<G-vec00301-001-s057><fix.beheben><de> Als bester DLL Fix Tool hat DLL Suite gewidmet, um DLL-Fehler für viele Jahre zu beheben, und es kann als die meisten professionellen DLL Fix Tool-und DLL-Fehler Reparatur-Tool gezählt werden.
<G-vec00301-001-s057><fix.beheben><en> As the best utildll.dll fix tool, DLL Suite has been dedicated to fix DLL error for many years and can be counted as the most professional DLL fixer and DLL error repair tool.
<G-vec00301-001-s060><fix.beheben><de> Finden Sie hier die umfassendsten dr.fone-Lösungen, um die Probleme auf Ihrem Handy einfach zu beheben.
<G-vec00301-001-s060><fix.beheben><en> Find out here the most complete dr.fone solutions to easily fix the problems on your mobile.
<G-vec00301-001-s061><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, fxsclntr.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s061><fix.beheben><en> The DLL‐files.com Client can help you properly install fxsclntr.dll and fix your DLL error permanently.
<G-vec00301-001-s062><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, itss.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s062><fix.beheben><en> The DLL‐files.com Client can help you properly install itss.dll and fix your DLL error permanently.
<G-vec00301-001-s063><fix.beheben><de> Sie können auch die WinRAR Software zu beschädigten RAR Datei nach Wiedergewinnung beheben.
<G-vec00301-001-s063><fix.beheben><en> You can also use the WinRAR software to fix damaged or corrupted RAR file after recovery.
<G-vec00301-001-s064><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, bdesvc.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s064><fix.beheben><en> The DLL‐files.com Client can help you properly install bdesvc.dll and fix your DLL error permanently.
<G-vec00301-001-s066><fix.beheben><de> Ich habe deinstalliert und neu installiert aber es funktioniert nicht das Problem beheben.
<G-vec00301-001-s066><fix.beheben><en> I have uninstalled and reinstalled but it does not fix the problem.
<G-vec00301-001-s067><fix.beheben><de> Wir können Ihre Browserdaten dazu verwenden, die Nutzung unserer Website zu überwachen, um die Funktionalität zu verbessern und Probleme zu beheben, die wir identifizieren.
<G-vec00301-001-s067><fix.beheben><en> We may use your browsing data to monitor the usage of our website to improve the functionality and fix problems we identify.
<G-vec00301-001-s068><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, ext-ms-win-session-wtsapi32-l1-1-0.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s068><fix.beheben><en> The DLL‐files.com Client can help you properly install ext-ms-win-session-wtsapi32-l1-1-0.dll and fix your DLL error permanently.
<G-vec00301-001-s069><fix.beheben><de> Wir haben in Folge der Stromunterbrüche ein Problem mit dem swi-hpk-g21-2-a Wir sind daran das Problem zu beheben.
<G-vec00301-001-s069><fix.beheben><en> We have a problem with the swi-hpk-g21-2-a due to the current interruption We are going to fix the problem.
<G-vec00301-001-s070><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, ddaclsys.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s070><fix.beheben><en> The DLL‐files.com Client can help you properly install ddaclsys.dll and fix your DLL error permanently.
<G-vec00301-001-s071><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, cst.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s071><fix.beheben><en> The DLL‐files.com Client can help you properly install cst.dll and fix your DLL error permanently.
<G-vec00301-001-s073><fix.beheben><de> "Sie können in das gleiche Problem wie Arlie Bahm von Guinea laufen, mal sehen, was hilft, dieser Freund, es zu lösen - System.Web.DynamicData.Resources.dll wurde nicht gefunden ""Problem"" Meine Sony erlebt hat "", wenn Rollenspiel Tom Clancy's Rainbow 6: Patriots Und Gott sei Dank DLL Suite hat diese erstaunliche Tool zu beheben."
<G-vec00301-001-s073><fix.beheben><en> "You may run into the same problem as Norman Harsey from Italy, let's see what helps this friend solving it -- ""My Malata has experienced ""System.Web.DynamicData.Resources.dll was not found"" problem when playing Planescape: Torment. And thank god DLL Suite has this amazing efficiency to fix System.Web.DynamicData.Resources.dll""."
<G-vec00301-001-s074><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, uxlib.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s074><fix.beheben><en> The DLL‐files.com Client can help you properly install uxlib.dll and fix your DLL error permanently.
<G-vec00301-001-s075><fix.beheben><de> Der DLL‐files.com Client kann Ihnen helfen, brclrd06.dll richtig zu installieren und Ihre DLL-Fehler dauerhaft zu beheben.
<G-vec00301-001-s075><fix.beheben><en> The DLL‐files.com Client can help you properly install brclrd06.dll and fix your DLL error permanently.
<G-vec00301-001-s035><rectify.beheben><de> Dies ist ein häufiges Problem, das viele Menschen Gesicht und bis vor kurzem war es ein sehr langwieriger Problem zu versuchen und zu beheben.
<G-vec00301-001-s035><rectify.beheben><en> This is a common problem many people face and until recently it was a very tedious problem to try and rectify.
<G-vec00301-001-s036><rectify.beheben><de> Falls der Besitzer oder die für die Schlüssel verantwortliche Person nicht in der Lage sind die Mängel in angemessener Zeit zu beheben, wird der Kunde aufgefordert, dieses dem Mitarbeiter von Euro Tours mitzuteilen.
<G-vec00301-001-s036><rectify.beheben><en> In the event of the owner or person in charge of the keys being unable to rectify the irregularity within a reasonable period, it is the guest's duty to inform their agent or Euro Tours 's employee.
<G-vec00301-001-s037><rectify.beheben><de> Und für die Instandhalter stellt neben ihren Werkzeugen das Tablet das vornehmliche Arbeitsgerät dar: Mit Hilfe einer App können sie Störungen von Maschinen schnellstmöglich und direkt vor Ort erkennen und beheben.
<G-vec00301-001-s037><rectify.beheben><en> And for service engineers, alongside their usual tools, the tablet represents the principal working tool: with the help of an app, they are able to detect and rectify machine faults as soon as possible and directly on-site.
<G-vec00301-001-s038><rectify.beheben><de> Ursachen beheben: Neben allen genannten Gegenmaßen sollte nicht außer Acht gelassen werden, die eigentliche Ursache zu beheben und damit ein weiteres Andauern des Problems zu verhindern.
<G-vec00301-001-s038><rectify.beheben><en> Remedy the causes: In addition to all the countermeasures mentioned above, do not neglect to rectify the root cause and thus prevent a further occurrence of the problem.
<G-vec00301-001-s039><rectify.beheben><de> Außerdem haben Sie gegebenenfalls das Recht, Ungenauigkeiten oder Fehler zu beheben, die Verarbeitung zu löschen, einzuschränken, die Verarbeitung zu verweigern und die Einwilligung in die Verarbeitung Ihrer personenbezogenen Daten und gegebenenfalls das Recht auf Datenübertragbarkeit Ihrer personenbezogenen Daten zu widerrufen.
<G-vec00301-001-s039><rectify.beheben><en> To the extent required by applicable law, you have the right to access your personal data and confirm the processing of your personal data. Also, where applicable, you have the right to rectify inaccuracies or errors, erase, restrict the processing, object to processing, and withdraw consent to processing of your personal data, and where applicable, the right to data portability of your personal data.
<G-vec00301-001-s040><rectify.beheben><de> Wir werden uns bemühen, das Problem während der normalen Arbeitszeiten oder spätestens am nächsten Werktag schnellstmöglich zu beheben.
<G-vec00301-001-s040><rectify.beheben><en> We will endeavour to rectify the problem immediately during normal working hours or the next working day.
<G-vec00301-001-s041><rectify.beheben><de> Ich hoffe inständig, dass die menschliche Voodoo-Puppe zu überdenken und versuchen, zu beheben.
<G-vec00301-001-s041><rectify.beheben><en> I sincerely hope that the human voodoo doll to reconsider and try to rectify.
<G-vec00301-001-s042><rectify.beheben><de> Vor dem Gynectrol nehmen, meine Brustwarzen, wo ganz geschwollen und hatte ein Überschuss von tissure unter ihnen aufbauen, Nippel aufweist, die unter engen Tops oder Westen bleiben, so peinlich sein kann, so habe ich beschlossen, durch das Surfen im Web, das Problem zu beheben und auf der Suche, um zu sehen, was supplimemts ich bekommen konnte.
<G-vec00301-001-s042><rectify.beheben><en> Prior to taking the Gynectrol, my nipple areas where rather puffy and also had an unwanted of tissure build up under them, having nipples that protrude under tight tops or vests can be so embarrassing so I chose to rectify the trouble by surfing the internet as well as planning to see exactly what supplimemts I might get.
<G-vec00301-001-s043><rectify.beheben><de> 5.7.6.1 Falls der Range Officer den Beweis dafür findet, der das vermutete Problem bestätigt, hat der Teilnehmer kein Recht auf ein Reshoot, wird aber aufgefordert das Problem zu beheben.
<G-vec00301-001-s043><rectify.beheben><en> 5.7.6.1 If the Range Officer finds evidence that confirms the suspected problem, the competitor will not be entitled to a reshoot, but will be ordered to rectify the problem.
<G-vec00301-001-s044><rectify.beheben><de> Sollte es an Bord Ihres Fahrzeuges trotzdem einmal zu Schwierigkeiten mit dem Equipment kommen, tun wir alles, um diese schnell zu beheben.
<G-vec00301-001-s044><rectify.beheben><en> But should you nevertheless encounter difficulties with the equipment on-board your vehicle, we will do everything we can to rectify this quickly.
<G-vec00301-001-s045><rectify.beheben><de> Die heutige Überarbeitung des Europol-Mandats wird helfen, dies zu beheben.
<G-vec00301-001-s045><rectify.beheben><en> Today's revision of Europol's mandate will help to rectify this.
<G-vec00301-001-s046><rectify.beheben><de> In den meisten Fällen, Diese Lösung wird das Problem beheben und die Helligkeitseinstellungen wieder funktionieren.
<G-vec00301-001-s046><rectify.beheben><en> In most of the cases, this solution will rectify the issue and get the brightness adjustments working again.
<G-vec00301-001-s047><rectify.beheben><de> Fallen dem Techniker während der Überprüfung Mängel am Gerät auf, kann er diese in gewissem Umfang sofort beheben.
<G-vec00301-001-s047><rectify.beheben><en> If the technician should notice a fault during the inspection, he can rectify this immediately to a certain extent.
<G-vec00301-001-s048><rectify.beheben><de> Durch Auswählen der betroffenen Dreiecke in Milkshape 3D und anschließenden Klick im Menü auf Face->Reverse Vertex Order könnt ihr dieses Problem beheben, sofern es nicht an fehlenden Dreiecken liegt.
<G-vec00301-001-s048><rectify.beheben><en> Selecting the affected triangles in Milkshape 3D and clicking on Face->Reverse Vertex Order in the menu, should rectify the problem, unless missing triangles are responsible.
<G-vec00301-001-s049><rectify.beheben><de> Mit Hilfe der im Fronius Solar.web angezeigten Fehlerdaten können die Anlagen-Experten den Defekt leichter erkennen und beheben – und damit Ausfälle und Ertragseinbußen minimieren.
<G-vec00301-001-s049><rectify.beheben><en> The system experts can easily identify and rectify the fault with the help of the fault data displayed on the Fronius Solar.web platform, thus minimising failures and yield losses.
<G-vec00301-001-s050><rectify.beheben><de> Das Tool ist nicht nur unglaublich leistungsstark sondern auch sehr funktional, da es den gesamten Reinigungsprozess automatisiert, so dass es sehr einfach für Sie ist, Fehler in Ihrer iTunes-Bibliothek zu beheben.
<G-vec00301-001-s050><rectify.beheben><en> The tool is not only incredibly powerful but it is also highly functional since it automates the entire cleanup process, making it very simple and easy for you to rectify errors in your iTunes library.
<G-vec00301-001-s051><rectify.beheben><de> Mit dem Videoskop BO21 von Trotec können Sie einen genauen Blick in die versteckten Winkel der Karosse werfen und so frühzeitig Schwachstellen entdecken und beheben.
<G-vec00301-001-s051><rectify.beheben><en> With the BO21 Videoscope from Trotec, you can take a detailed look into the concealed corners of the body and thus identify and rectify deficiencies at an early stage.
<G-vec00301-001-s052><rectify.beheben><de> Mit der Unmöglichkeit dieses Problem länger zu ignorieren, wandte es sich an E-Mail um die Sache zu beheben.
<G-vec00301-001-s052><rectify.beheben><en> Unable to ignore the issue any longer, it turned to email to rectify the situation.
<G-vec00301-001-s053><rectify.beheben><de> So können wir dank „EffiLink“ beispielsweise bei Systemstörungen bereits aus der Ferne die Ursachen ermitteln und die Fehler direkt beheben.
<G-vec00301-001-s053><rectify.beheben><en> "For example, we can use ""EffiLink"" to identify the causes of system faults remotely and rectify the error directly."
<G-vec00301-001-s019><solve.beheben><de> "In diesem Artikel erfahren Sie, wie Sie den Fehler ""Systemreservierte Partition"" beim Aktualisieren auf Windows 10 beheben können."
<G-vec00301-001-s019><solve.beheben><en> In this article, we will guide you on how to solve the System Reserved Partition error while upgrading to Windows 10.
<G-vec00301-001-s020><solve.beheben><de> Wir haben den Fehler beheben können und bitten alle, die es frustriert aufgegeben haben, um Entschuldigung.
<G-vec00301-001-s020><solve.beheben><en> We were able to solve the problem and apologize for all those who gave up frustrated.
<G-vec00301-001-s021><solve.beheben><de> Dieser Vorschlag sieht die Einführung einer Visumschutzklausel vor, die eine vorübergehende Aufhebung der Befreiung eines Drittlandes von der Visumpflicht in Notlagen ermöglicht, in denen eine dringliche Reaktion erforderlich ist, um die Schwierigkeiten eines oder mehrerer Mitgliedstaaten zu beheben.
<G-vec00301-001-s021><solve.beheben><en> This proposal foresees a visa safeguard clause allowing the temporary suspension of the visa waiver for a third-country whose nationals are exempted from the visa obligation in the event of an emergency situation where an urgent response needs to be given to solve difficulties faced by one or more Member States.
<G-vec00301-001-s022><solve.beheben><de> Als das Lied dann mehr schlecht als recht runtergerotzt wurde, war erst einmal eine kurze Pause angesagt, um das Problem zu beheben.
<G-vec00301-001-s022><solve.beheben><en> As the song was performed poor rather than good, a short break was necessary to solve the problems.
<G-vec00301-001-s023><solve.beheben><de> Neue Versionen beheben das Problem.
<G-vec00301-001-s023><solve.beheben><en> New releases solve this problem.
<G-vec00301-001-s024><solve.beheben><de> Nachdem Sie + 200 Tattoo-Künstler und +20 Tattoo-Studios auf der ganzen Welt angehört haben, hat META die nächste Generation von Tattoo-Workstations entwickelt, die alle Ihre Wünsche und Probleme während Ihres Tattoo-Prozesses umsetzen und beheben werden.
<G-vec00301-001-s024><solve.beheben><en> After listening to + 200 tattoo artists and +20 tattoo studios around the world, META designed the next generation of tattoo workstation that will solve all your problems & needs during your tattoo process. Availability: In stock
<G-vec00301-001-s025><solve.beheben><de> Überarbeitete Pakete beheben dieses Problem.
<G-vec00301-001-s025><solve.beheben><en> Fixed packages solve this issue.
<G-vec00301-001-s026><solve.beheben><de> Um das Problem zu beheben, erneuern Sie Ihre WLAN-Verbindung und starten Sie die NAVIGON App erneut.
<G-vec00301-001-s026><solve.beheben><en> To solve this problem, renew your WLAN connection and start your NAVIGON App again.
<G-vec00301-001-s027><solve.beheben><de> Die Techniker wissen sofort was wo passiert ist und können den Fehler schnell beheben.
<G-vec00301-001-s027><solve.beheben><en> The technicians immediately know what has happened where and can solve the problem quickly.
<G-vec00301-001-s028><solve.beheben><de> Es ist wichtig, dass Sie die Ergebnisse Ihrer Lösungen, Ihre gezielten Kampagnen und die Verkaufszahlen verstehen, damit Sie richtig auf Ihre Kunden zugehen und Probleme mit Ihrer Lösung beheben können.
<G-vec00301-001-s028><solve.beheben><en> Monitor and manage results Understanding the results of your solutions, targeted campaigns, and sales figures is vital to making corrections in how you approach customers and solve problems with your solution.
<G-vec00301-001-s029><solve.beheben><de> Du kannst das Problem dann ganz leicht beheben.
<G-vec00301-001-s029><solve.beheben><en> You can easily address the problem and solve it.
<G-vec00301-001-s030><solve.beheben><de> Um dieses Problem zu beheben, arbeiten derzeit viele nationale und internationale Arbeitsgruppen an der Etablierung einer einheitlichen Messmethode zur Charakterisierung des UVASchutzes.
<G-vec00301-001-s030><solve.beheben><en> In order to solve this problem, numerous national and international working groups are involved in establishing of standardized measuring methods for the characterization of UVA-protection.
<G-vec00301-001-s031><solve.beheben><de> Sie können den folgenden VBA-Code ausführen, um dieses Problem zu beheben.
<G-vec00301-001-s031><solve.beheben><en> You can run the following VBA code to solve this problem.
<G-vec00301-001-s032><solve.beheben><de> Um Stabilitätsprobleme einzelner URL-Aufrufe zu beheben benötigen Sie die Unterstützung der Entwickler.
<G-vec00301-001-s032><solve.beheben><en> To solve stability problems with specific URLs, you will need the support of the Web Application developers.
<G-vec00301-001-s033><solve.beheben><de> Überarbeitete Pakete beheben die genannten Probleme.
<G-vec00301-001-s033><solve.beheben><en> Updated packages solve these problems.
<G-vec00301-001-s034><solve.beheben><de> Viele Probleme oder Störungen können Sie oft selbst beheben.
<G-vec00301-001-s034><solve.beheben><en> You can solve many problems yourself.
<G-vec00301-001-s035><solve.beheben><de> Vielleicht liegt kein Defekt vor und Sie können das Problem bereits selbst beheben.
<G-vec00301-001-s035><solve.beheben><en> Maybe nothing is broken and you can solve the issue yourself.
<G-vec00301-001-s036><solve.beheben><de> Unsere engagierten Teams sind in der Lage, Probleme schnell vorauszusehen, zu diagnostizieren und zu beheben.
<G-vec00301-001-s036><solve.beheben><en> the aggreko difference Our dedicated teams can anticipate, diagnose and solve problems quickly.
<G-vec00301-001-s037><solve.beheben><de> Man kann auch einen kostenlosen Anruf auf ihre Telefonnummer, und zu der genannten Zeit wird der Operator selbst anrufen, alles erforschen und alle Schwierigkeiten zu beheben helfen.
<G-vec00301-001-s037><solve.beheben><en> And you can also order a free call to your phone and at a specified time the operator will call you back, go into question and help to solve it.
<G-vec00301-001-s054><rectify.beheben><de> Ich allein kann die irdische Not beheben, und Ich werde dies auch tun, sowie die Menschen selbst sich bemühen, vorerst die geistige Not zu beheben.
<G-vec00301-001-s054><rectify.beheben><en> I alone can rectify earthly trouble, and I will also do this, as soon as men make an effort themselves to remove the spiritual misery for the time being.
<G-vec00301-001-s055><rectify.beheben><de> 6.6 Ohne unsere schriftliche Zustimmung darf der Abnehmer eventuelle Mängel nicht selbst beheben oder durch Dritte beseitigen lassen.
<G-vec00301-001-s055><rectify.beheben><en> 6.6 Purchaser is not permitted to rectify possible defects himself or have them corrected by third parties without our written consent.
<G-vec00301-001-s056><rectify.beheben><de> 5.2.Im Falle eines materiellen Fehlers in der Preisangabe, der für den Wert des Gutes offensichtlich irrelevant ist, hat der Verkäufer das Recht, ihn vor der Lieferung des Gutes zu beheben.Wenn der Kunde erklärt, dass er oder sie nicht zustimmt, den korrigierten Preis zu zahlen, wird der Kaufvertrag gelöst und der Preis, wenn bereits bezahlt, an den Kunden zurückgesandt.
<G-vec00301-001-s056><rectify.beheben><en> 5.2. In the event of material error in the price indication, which is manifestly irrelevant to the value of the Good, Seller will have the right to rectify it before the delivery of the Good. If the Customer informs you that you do not agree to pay the corrected price, the sales contract will be resolved and the price, if already paid, will be returned to the Customer.
<G-vec00301-001-s076><fix.beheben><de> Die Aktivierung von WRITE=YES innerhalb der Samba Konfiguration, so wird gesagt, behebt das Problem.
<G-vec00301-001-s076><fix.beheben><en> Enabling WRITE=YES in the samba configuration is said to fix/workaround it.
<G-vec00301-001-s077><fix.beheben><de> Ein iOS-Update behebt alle möglichen Probleme und Fehler im Zusammenhang mit der aktuellen Version.
<G-vec00301-001-s077><fix.beheben><en> An iOS update will fix all the potential issues and bugs associated with the current version.
<G-vec00301-001-s078><fix.beheben><de> Behebt ein Problem, durch das sich die Aufgabenabhängigkeit der öffentlich veröffentlichten Map nach dem Herunterladen von XMind.net verliert.
<G-vec00301-001-s078><fix.beheben><en> 7. Fix a bug that after downloading a public map from XMind.net, the task dependencies of the map disappear.
<G-vec00301-001-s079><fix.beheben><de> Nun, dann hoffen wir, dass die nächste Version von Windows ihn behebt (aber man muss wieder ein paar hundert Euronen zahlen).
<G-vec00301-001-s079><fix.beheben><en> Well then, let's hope the next version of Windows will fix it (but you'll need to pay another few hundred bucks).
<G-vec00301-001-s080><fix.beheben><de> Behebt ein Problem, durch das Bild in Notiz beim Importieren einer Mindmanager Map verschwindet.
<G-vec00301-001-s080><fix.beheben><en> 12. Fix an issue that image in notes disappears while importing a Mindmanager file.
<G-vec00301-001-s081><fix.beheben><de> Der vorliegende Patch behebt diese Probleme.
<G-vec00301-001-s081><fix.beheben><en> This patch will fix these problems.
<G-vec00301-001-s082><fix.beheben><de> Dies behebt vielleicht nicht den Fehler, kann aber wenigstens Probleme aufgrund von alten Einstellungen auf Ihrem PC eliminieren.
<G-vec00301-001-s082><fix.beheben><en> That may not fix the error, but at least may eliminate any problem due to old settings on your PC.
<G-vec00301-001-s083><fix.beheben><de> Wenn dies nicht behebt Ihre iPhone Neustart Fehler dann keine Sorge, es gibt auch andere Optionen zur Verfügung.
<G-vec00301-001-s083><fix.beheben><en> If this doesn’t fix your iPhone restarting error then don’t worry, there are other options available.
<G-vec00301-001-s084><fix.beheben><de> Es sollte dir helfen, wenn du Probleme hast, da es anzeigt, welche Probleme vorhanden sind und wie man sie behebt.
<G-vec00301-001-s084><fix.beheben><en> It should help you, when you have some problems, as it shows, what problem you have and how to fix it.
<G-vec00301-001-s085><fix.beheben><de> Macrovision hat einen Patch veröffentlicht, der das Problem behebt.
<G-vec00301-001-s085><fix.beheben><en> Macrovision has released a patch to fix the vulnerability.
<G-vec00301-001-s086><fix.beheben><de> DYMO hat ein Update entwickelt, dass dieses Problem behebt.
<G-vec00301-001-s086><fix.beheben><en> DYMO has developed an update that will fix this problem on these printers.
<G-vec00301-001-s087><fix.beheben><de> Ein Upgrade auf neuere Versionen behebt die Probleme.
<G-vec00301-001-s087><fix.beheben><en> An upgrade to newer versions than the affected ones fix this issues.
<G-vec00301-001-s088><fix.beheben><de> qemu-kvm Behebt Teilung durch 0 bei einigen Gästen; behebt zlib-Überlauf von vnc; bricht bei Hardwareproblemen nicht ab; verbessert Migration auf 32-bit.
<G-vec00301-001-s088><fix.beheben><en> Fix division by 0 with some guests; fix vnc zlib overflow; don't abort on user hardware errors; fix migration on 32-bit
<G-vec00301-001-s090><fix.beheben><de> Also, wenn jemand kommt über mein Problem, Sie sollte ein Test Post mit dem Satz in der Kopie nicht, habe es übersetzt und Korrektur der Übersetzung mit dem Apostroph nehmen daraus, Es behebt die URL in der Original übersetzt Post.
<G-vec00301-001-s090><fix.beheben><en> So if anyone comes across my problem, you should do a test post with the phrase inside the copy, have it translated and correct the translation to take the apostrophe out of it, it will fix the URL in the original translated post.
<G-vec00301-001-s091><fix.beheben><de> Wir raten Ihnen davon ab, diese Anwendung herunterzuladen, andernfalls werden Sie bald herausfinden, dass Driver Performer keine Fehler behebt, von denen Sie wissen, dass sie im System existieren.
<G-vec00301-001-s091><fix.beheben><en> We advise you against downloading this application as if you do so, soon you will find out that Driver Performer does not fix the errors which you known to exist in the system.
<G-vec00301-001-s092><fix.beheben><de> Der Entwickler behebt gemeldete Fehler und nimmt Vorschläge zu neuen Funktionen entgegen.
<G-vec00301-001-s092><fix.beheben><en> The developer will fix reported bugs and is open to receive feature requests.
<G-vec00301-001-s093><fix.beheben><de> Das Update behebt einige kleinere Probleme und wird für den fehlerfreien Betrieb des neuen VST Sound Instrument Sets Nashville benötigt.
<G-vec00301-001-s093><fix.beheben><en> The updates fix minor issues and are required in order for the new VST Sound Instrument Set Nashville to run seamlessly.
<G-vec00301-001-s094><fix.beheben><de> Regelmäßiges Aktualisieren allein macht Ihr System nicht sicher, aber es behebt zumindest einige bekannte Probleme.
<G-vec00301-001-s094><fix.beheben><en> Updating regularly won't make your system secure but would fix some known problems at least.
<G-vec00301-001-s114><fix.beheben><de> Dadurch wird der Dienst, der den EPP-Treiber lädt, neu gestartet; damit sollte das Problem behoben und die Fehlermeldung verschwunden sein.
<G-vec00301-001-s114><fix.beheben><en> This recreates the service that loads the EPP driver, and thus it should fix the problem and the error message should be gone.
<G-vec00301-001-s115><fix.beheben><de> - Kompatibler Fehler wurde behoben.
<G-vec00301-001-s115><fix.beheben><en> - Compatible bug fix.
<G-vec00301-001-s116><fix.beheben><de> Die Lösung war recht flexibel, wenn auch recht fehleranfällig und schwer zu warten (oft mussten fehlerhafte automatische Zusammenführungen wieder behoben werden).
<G-vec00301-001-s116><fix.beheben><en> The solution was quite flexible, albeit quite error-prone and hard to maintain (we often had to fix failing automatic merges).
<G-vec00301-001-s117><fix.beheben><de> Wenn ein solches Problem auftritt, muss es behoben werden.
<G-vec00301-001-s117><fix.beheben><en> And if such a problem arose, it is necessary to fix it.
<G-vec00301-001-s118><fix.beheben><de> Hierdurch werden sicherheitsrelevante Probleme in den Paketen sudo und telnet behoben.
<G-vec00301-001-s118><fix.beheben><en> These updates fix security related problems in sudo and telnet.
<G-vec00301-001-s119><fix.beheben><de> Durch die Anwendung dieses Filters wird die Umkehrung behoben.
<G-vec00301-001-s119><fix.beheben><en> Applying this filter will fix the inversion.
<G-vec00301-001-s120><fix.beheben><de> Wenn das nicht behoben werden kann, können wir euch einladen, nach vorne zu kommen oder euch irgendwo hinzusetzen, wo ihr hören könnt (Beifall).
<G-vec00301-001-s120><fix.beheben><en> (HANDS RAISED) If someone does not fix this, we can invite you to sit around here or some place where you can hear. (APPLAUSE)
<G-vec00301-001-s121><fix.beheben><de> Behoben: Die Original E-Mail wurde nicht geschlossen, wenn ReplyAll den Dialog (Adressliste oder BCC-Warnung) angezeigt hat.
<G-vec00301-001-s121><fix.beheben><en> Fix: The original e-mail was not closed when ReplyAll displayed the dialog (the address list or the BCC alert).
<G-vec00301-001-s122><fix.beheben><de> Achten Sie darauf, dass die Firmware auf Ihrem Gerät aktualisiert ist, dadurch arbeitet es effizienter und Probleme, die während der Nutzung aufgetreten sind, können behoben werden.
<G-vec00301-001-s122><fix.beheben><en> Keeping the firmware on your device updated will help it function more efficiently and fix issues you may have experienced while using it.
<G-vec00301-001-s123><fix.beheben><de> Dieses Problem wurde in der neuesten Version von DLS behoben.
<G-vec00301-001-s123><fix.beheben><en> DYMO has created an installer to fix this problem.
<G-vec00301-001-s124><fix.beheben><de> Diese Art des Angriffs kann nur verhindert werden, indem der entsprechende Fehler im Kernel behoben wird.
<G-vec00301-001-s124><fix.beheben><en> The latter can only be fixed by applying a bug fix to the kernel.
<G-vec00301-001-s125><fix.beheben><de> Im letzteren Fall verschwindet dieser Fehler, sobald Sie das ursprüngliche Problem behoben haben.
<G-vec00301-001-s125><fix.beheben><en> In the last case this error will disappear as soon as you fix the original problem.
<G-vec00301-001-s126><fix.beheben><de> Ursache: Überwachen Sie die Replikation regelmäßig, damit Probleme erkannt und behoben werden können, bevor sie größer werden.
<G-vec00301-001-s126><fix.beheben><en> Cause: Monitor replication regularly to help identify and fix problems before they grow.
<G-vec00301-001-s127><fix.beheben><de> - Crash bei Kanäle editieren behoben - Spanische sprache geändert - UNICABLE Problem gefixt.
<G-vec00301-001-s127><fix.beheben><en> - Crash in channel edit fix - spanish language update - UNICABLE problem fixed.
<G-vec00301-001-s128><fix.beheben><de> Sobald Fehler in einer Installation entdeckt und behoben wurden, wird eine neue Version der Installation auf der WHDLoad Webseite veröffentlicht.
<G-vec00301-001-s128><fix.beheben><en> As soon as a bug is discovered and removed, the new version of the fix is made available at the WHDLoad website.
<G-vec00301-001-s129><fix.beheben><de> Wir überprüfen beispielsweise fortlaufend, ob unsere Systeme ordnungsgemäß funktionieren, sodass Fehler erkannt und behoben werden können.
<G-vec00301-001-s129><fix.beheben><en> For example, we continuously monitor our systems to check that they are working as intended and in order to detect and fix errors.
<G-vec00301-001-s130><fix.beheben><de> Mit verbesserten Kernelpaketen für Red Hat Enterprise Linux 5 werden verschiedene sicherheitsrelevante Probleme und Fehler behoben.
<G-vec00301-001-s130><fix.beheben><en> Updated kernel packages that fix multiple security issues and several bugs are now available for Red Hat Enterprise Linux 5.
<G-vec00301-001-s131><fix.beheben><de> Dieses Problem ist genau das, was mit Omnichannel-Marketing behoben werden soll.
<G-vec00301-001-s131><fix.beheben><en> This problem is precisely what omnichannel marketing aims to fix.
<G-vec00301-001-s132><fix.beheben><de> Ein graphischer Glitch mit den Pluszeichen, welche es erlauben Punkte zu einem Weg hinzuzufügen, wurde behoben.
<G-vec00301-001-s132><fix.beheben><en> Fix a graphical glitch with the plus signs which allow to add nodes to ways.
<G-vec00301-001-s064><rectify.beheben><de> Über den Remote Service Client ist eine schnelle Online-Diagnose möglich, Störungen können problemlos von KUKA behoben werden, ohne direkt vor Ort zu sein.
<G-vec00301-001-s064><rectify.beheben><en> Quick online diagnosis is possible via the Remote Service Client – which allows KUKA to easily rectify faults without being directly on site.
<G-vec00301-001-s065><rectify.beheben><de> Durch das Gebäudemonitoring konnten Fehlfunktionen im Betrieb identifiziert und größtenteils bereits behoben werden.
<G-vec00301-001-s065><rectify.beheben><en> Monitoring the building enabled us to identify malfunctions in operation and to rectify most of them.
<G-vec00301-001-s167><rectify.beheben><de> So können Sie schnell reagieren und Fehler gegebenenfalls auch von unterwegs direkt beheben.
<G-vec00301-001-s167><rectify.beheben><en> You can therefore react quickly and, if necessary, rectify errors even when you are on the move.
<G-vec00301-001-s254><rectify.beheben><de> Viele der ursprünglichen elektronischen Systeme bei modernen Fahrzeugen können jetzt wieder mit Software programmiert werden; Änderungen an Software-Probleme zu beheben wäre historisch ein neues Steuergerät verbunden, das ist der einzige Weg, dass der unabhängige Markt heute in der Lage, diese Probleme zu überwinden und die würde von der Ersatzteilabteilung erworben werden.
<G-vec00301-001-s254><rectify.beheben><en> Many of the original electronic systems on modern vehicles can now be re programmed using software; historically any changes to rectify software problems would involve a new ECU which would be purchased from the parts department and that is the only way that the independent market today is able to overcome these problems.
<G-vec00301-001-s267><rectify.beheben><de> Vor dem Absenden der Bestellung an den Verkäufer ist der Käufer berechtigt, die vom Käufer in die Bestellung eingegebenen Daten zu überprüfen und zu ändern, auch im Hinblick auf die Möglichkeit des Käufers, Fehler, die bei der Eingabe der Daten in die Website aufgetreten sind, zu erkennen und zu beheben Auftrag.
<G-vec00301-001-s267><rectify.beheben><en> Prior to sending the order to the seller, the buyer is enabled to check and change the data which were inserted into the order by the buyer, also with regard to the buyer’s option to realize and rectify errors which occurred when the data were inserted into the order.
<G-vec00301-001-s513><fix.beheben><de> Ob dies Ihr Samsung schwarzer Bildschirm Problem zu beheben, ist ein bisschen wie ein Glücksspiel, vor allem, wenn Sie don ’ t wissen, was ’ s, die das Problem verursacht, aber es ’ ll Hilfe mehr als oft nicht.
<G-vec00301-001-s513><fix.beheben><en> Whether or not this will fix your Samsung black screen problem is a bit of a gamble, especially if you don’t know what’s causing the problem, but it’ll help more often than not.
<G-vec00301-001-s514><fix.beheben><de> Mit der Aufnahme von einfachen grafischen Benutzeroberfläche und starke Reparatur Algorithmen können Sie MOV Video-Datei innerhalb kürzester Zeit zu beheben und repariert MOV-Datei vor dem Speichern auf die jeweilige Zielposition anzeigen.
<G-vec00301-001-s514><fix.beheben><en> With the inclusion of simple graphical user interface and strong repair algorithms, you can fix MOV video file within no time and can preview repaired MOV file before saving it to the respective destination location.
<G-vec00301-001-s515><fix.beheben><de> Sie können daher leicht zu beheben, das Problem selbst zu.
<G-vec00301-001-s515><fix.beheben><en> You can therefore easily fix the problem yourself.
<G-vec00301-001-s516><fix.beheben><de> Sofort zu beheben beschädigte Photoshop PSD-Dateien auf Windows 7 OS mit Hilfe Yodot PSD Reparatur Dienstprogramm.
<G-vec00301-001-s516><fix.beheben><en> Instantly fix corrupted Photoshop PSD files on Windows 7 OS by using Yodot PSD Repair utility.
<G-vec00301-001-s517><fix.beheben><de> "Die Windows Systemwiederherstellung ermöglicht es Ihnen, auf Ihrem PC ""die Zeit zurück zu drehen"" um Ihnen zu helfen, Ihre ipwa.tmp-Probleme zu beheben."
<G-vec00301-001-s517><fix.beheben><en> "Windows System Restore allows you to ""go back in time"" with your PC to help fix your ipwa.tmp problems."
<G-vec00301-001-s518><fix.beheben><de> """Wir können Spiele-Entwickler nicht zu beheben ."
<G-vec00301-001-s518><fix.beheben><en> """We game developers can't fix it."
<G-vec00301-001-s519><fix.beheben><de> Heutzutage Benutzer keine Notwendigkeit, Sorgen darüber zu machen, denn mit Hilfe von Dritten Reparatur Anwendung wie Remo Reparatur PSD, können Sie erfolgreich alle Fragen der Korruption in Photoshop-Datei zu beheben und Ihnen eine gesunde Datei einfacher zu bereitzustellen Zugang.
<G-vec00301-001-s519><fix.beheben><en> Nowadays users no need to worry about it, because with the assistance of third party repair application like Remo Repair PSD, you can successfully fix any corruption issues in Photoshop file and provide you a healthy file to access easily.
<G-vec00301-001-s520><fix.beheben><de> "Die Windows Systemwiederherstellung ermöglicht es Ihnen, auf Ihrem PC ""die Zeit zurück zu drehen"" um Ihnen zu helfen, Ihre 6005FB811ACE3772FAEC5B2787854B67.swf-Probleme zu beheben."
<G-vec00301-001-s520><fix.beheben><en> "Windows System Restore allows you to ""go back in time"" with your PC to help fix your 6005FB811ACE3772FAEC5B2787854B67.swf problems."
<G-vec00301-001-s521><fix.beheben><de> In diesem Fall sind Sie an der richtigen Stelle, wo Sie wissen, die beste Lösung, um leicht zu beheben AVI-Datei.
<G-vec00301-001-s521><fix.beheben><en> In that case you are at the right place where you will know the best solution to easily fix AVI file.
<G-vec00301-001-s522><fix.beheben><de> Und von Drittanbietern Sony Xperia Kontakte Recovery kann Ihnen helfen, dieses Problem zu beheben.
<G-vec00301-001-s522><fix.beheben><en> And third-party Sony Xperia Contacts Recovery program can help you fix this problem.
<G-vec00301-001-s523><fix.beheben><de> Dieses Update wird allen Benutzern empfohlen, da es Thema, das in der Zukunft ergeben können zu beheben.
<G-vec00301-001-s523><fix.beheben><en> This update is recommended for all users, as it fix issue which may arise in the future.
<G-vec00301-001-s524><fix.beheben><de> Bei Malware das Antivirenprogramm findet, kann sie zu beheben.
<G-vec00301-001-s524><fix.beheben><en> In case the antivirus program finds malware, it can fix them.
<G-vec00301-001-s525><fix.beheben><de> "Die Windows Systemwiederherstellung ermöglicht es Ihnen, auf Ihrem PC ""die Zeit zurück zu drehen"" um Ihnen zu helfen, Ihre handlebar_partials_compiled.js-Probleme zu beheben."
<G-vec00301-001-s525><fix.beheben><en> "Windows System Restore allows you to ""go back in time"" with your PC to help fix your handlebar_partials_compiled.js problems."
<G-vec00301-001-s526><fix.beheben><de> "Die Windows Systemwiederherstellung ermöglicht es Ihnen, auf Ihrem PC ""die Zeit zurück zu drehen"" um Ihnen zu helfen, Ihre url_im.hlp-Probleme zu beheben."
<G-vec00301-001-s526><fix.beheben><en> "Windows System Restore allows you to ""go back in time"" with your PC to help fix your url_im.hlp problems."
<G-vec00301-001-s527><fix.beheben><de> Das wird uns dabei helfen, den Fehler so schnell wie möglich zu finden und zu beheben.
<G-vec00301-001-s527><fix.beheben><en> This will help us find the bug and fix it as soon as possible.
<G-vec00301-001-s528><fix.beheben><de> Diese hervorragende Anwendung kann Powerpoint-Dateien zu beheben erstellt mit MS Office-Versionen 2000, 2003, 2007 und 2010 auf die wichtigsten Windows-Betriebssystem Computer wie Windows 8, Windows 7, Windows 2003, Windows Vista, Windows XP und Server 2008.
<G-vec00301-001-s528><fix.beheben><en> This outstanding application can fix PowerPoint files created using MS Office versions like 2000, 2003, 2007, 2010, etc., on major Windows OS computers like Windows 8, Windows 7, Windows 2003, Windows Vista, Windows XP and Server 2008.
<G-vec00301-001-s529><fix.beheben><de> Diese Wesenheiten helfen uns Dinge zu beheben, indem sie unser Bewusstsein ausdehnen, welche die Quelle vom Dilemma sind in dem sich unser Planet befindet.
<G-vec00301-001-s529><fix.beheben><en> These entities are helping us fix things by expanding our awareness, which is the source of our predicament we find the planet in.
<G-vec00301-001-s530><fix.beheben><de> Ich manuell alle Berechtigungen, so dass es könnte sie zu beheben, Dann setzte sie zurück.
<G-vec00301-001-s530><fix.beheben><en> I manually set all permissions so that it could fix them, then set them back.
<G-vec00301-001-s531><fix.beheben><de> "Die Windows Systemwiederherstellung ermöglicht es Ihnen, auf Ihrem PC ""die Zeit zurück zu drehen"" um Ihnen zu helfen, Ihre Zea mays 1.thm-Probleme zu beheben."
<G-vec00301-001-s531><fix.beheben><en> "Windows System Restore allows you to ""go back in time"" with your PC to help fix your Zea mays 1.thm problems."
<G-vec00279-002-s029><overcome.beheben><de> HostPapa bietet One-Click-Installationen für eine Vielzahl von verschiedenen Content-Management-Systemen an und der Kundendienst kann mit Ihnen zusammenarbeiten, um mögliche Probleme zu beheben.
<G-vec00279-002-s029><overcome.beheben><en> HostPapa offers one-click installation for a variety of different content management systems, and their support teams can work with you to overcome any potential issues you run into right away.
<G-vec00279-002-s030><overcome.beheben><de> Verwenden Sie eine andere ZIP-Anwendung: Verwenden Sie eine Anwendung wie 7-zip, um dieses Problem zu beheben.
<G-vec00279-002-s030><overcome.beheben><en> Use a different ZIP application: Use an application like 7-zip to overcome this issue.
<G-vec00279-002-s031><overcome.beheben><de> SFWare Das Dienstprogramm zum Reparieren von RAR-Dateien ist die beste Anwendung, die von den meisten Computerfachleuten vorgeschlagen wird, um die Probleme zu beheben, die durch beschädigte RAR-Dateien verursacht werden.
<G-vec00279-002-s031><overcome.beheben><en> SFWare Repair RAR File utility is the best application that is suggested by majority of computer experts to overcome the problems caused by corrupt / damaged RAR files.
<G-vec00279-002-s032><overcome.beheben><de> Um dieses Problem zu beheben, unterstützt der Greenbone Security Manager (GSM) die Einrichtung eines verteilten Scansystems: Zwei oder mehr GSMs in unterschiedlichen Netzwerksegmenten können sicher verbunden werden, um Schwachstellentests in den Netzwerksegmente durchzuführen, die andernfalls nicht erreichbar sind.
<G-vec00279-002-s032><overcome.beheben><en> To overcome this issue, the Greenbone Security Manager (GSM) supports the setup of a distributed scan system: two or more GSMs in different network segments can be connected securely in order to run vulnerability tests for those network segments that are otherwise not accessible.
<G-vec00279-002-s033><overcome.beheben><de> In diesem Fall benötigen Sie das RAR Dateireparatur Tool, um solche Probleme zu beheben.
<G-vec00279-002-s033><overcome.beheben><en> In such case, you need RAR file repair tool to overcome such issues.
<G-vec00279-002-s034><overcome.beheben><de> Die verwendeten Daten weisen darauf hin, dass Finanzinstitute außerhalb der USA die Swap-Märkte in Anspruch nahmen, um ihren Mangel an US-Dollar-Finanzierungen zu beheben, und dass deswegen an diesen Märkten deutliche Abweichungen von den gedeckten Zinsparitäten sowie Liquiditätsengpässe auftraten.
<G-vec00279-002-s034><overcome.beheben><en> We find that the use of swap markets to overcome US dollar funding shortages by non-US financial institutions resulted in marked deviations from covered interest parity conditions and the impairment of liquidity in these markets.
<G-vec00279-002-s035><overcome.beheben><de> Vor 50 Jahren, im Dezember 1955, schloß die Bundesrepublik Deutschland den ersten Anwerbevertrag mit Italien, um den Arbeitskräftemangel zu beheben.
<G-vec00279-002-s035><overcome.beheben><en> Fifty years ago, in December 1955, the Federal Republic of Germany signed the first enlistment contract with Italy, in order to overcome the lack of workers.
<G-vec00279-002-s036><overcome.beheben><de> Diese Hilfsmittel und Fähigkeiten beinhalten wissenschaftliche Qualität, innovative Ideen und die Einschätzung kommerzieller Möglichkeiten verschiedener Ideen oder neuer Technologie, Marktanalysen und das Herausfinden der Möglichkeiten, wie man institutionelle und technische Einschränkungen einer Region beheben kann.
<G-vec00279-002-s036><overcome.beheben><en> Such tools and skills include scientific quality, innovative ideas and evaluation of the commercial possibilities for an idea or new technology, market analysis, and finally identification of ways to overcome the institutional and technical constraints in the individual regions.
<G-vec00279-002-s037><overcome.beheben><de> Die künftigen Mitgliedstaaten müssen nun ihre Schwächen beheben und die Programme fertig stellen, die sie vom ersten Tag des Beitritts an im Rahmen der Strukturfonds und des Kohäsionsfonds durchführen werden.
<G-vec00279-002-s037><overcome.beheben><en> From now on, the future Member States have to overcome their weaknesses and finalise the programmes that they will implement from the first day of accession under the Structural and Cohesion Funds.
<G-vec00297-002-s157><resolve.beheben><de> Wenden Sie sich bitte an den Xbox-Support, wenn das Problem nicht behoben werden konnte.
<G-vec00297-002-s157><resolve.beheben><en> If this does not resolve your problem, contact Xbox Support.
<G-vec00297-002-s158><resolve.beheben><de> Melden Sie sich im Online Service Center an, und klicken Sie zum Beantragen einer Reparatur auf Reparaturanfrage starten, wenn das Problem durch diese Schritte nicht behoben werden konnte.
<G-vec00297-002-s158><resolve.beheben><en> If the first two solutions didn’t resolve the issue, go to the Online Service Center and click Start request to request a repair.
<G-vec00297-002-s159><resolve.beheben><de> Rufen Sie das Online Service Center auf, und klicken Sie zum Beantragen einer Reparatur auf Reparaturanfrage starten, wenn das Problem durch diese Schritte nicht behoben werden konnte.
<G-vec00297-002-s159><resolve.beheben><en> If the previous solution didn’t resolve the problem, go to the Online Service Center and click Start Request to request a repair.
<G-vec00297-002-s160><resolve.beheben><de> Rufen Sie das Online-Servicecenter auf, und klicken Sie zum Beantragen einer Reparatur auf Reparaturanfrage starten, wenn das Problem durch diese Schritte nicht behoben werden konnte.
<G-vec00297-002-s160><resolve.beheben><en> If these steps don't resolve the problem, go to the Online Service Center and click Start Request to request a repair.
<G-vec00297-002-s161><resolve.beheben><de> Melden Sie sich im Online Service Center an, und klicken Sie zum Beantragen einer Reparatur auf Reparaturanfrage starten, wenn das Problem durch diese Lösungen nicht behoben werden konnte.
<G-vec00297-002-s161><resolve.beheben><en> If these solutions don't resolve the problem, go to the Online Service Center and click Start Request to
<G-vec00297-002-s162><resolve.beheben><de> Wenn das Problem durch die Aktualisierung von Windows nicht behoben werden konnte, deinstallieren Sie Microsoft Solitaire Collection und installieren Sie es erneut.
<G-vec00297-002-s162><resolve.beheben><en> If updating Windows doesn't resolve the problem, uninstall and then reinstall Microsoft Solitaire Collection.
<G-vec00297-002-s163><resolve.beheben><de> Tauschen Sie die fehlerhafte Tintenpatrone aus, wenn Sie auf der Druckqualitätsdiagnoseseite Fehler festgestellt haben und das Problem durch die vorherigen Schritte – selbst bei hinreichenden Tintenfüllständen – nicht behoben werden konnte.
<G-vec00297-002-s163><resolve.beheben><en> Replace the problem ink cartridge if you saw defects on the printout and the preceding steps did not resolve the issue, even if the ink cartridge is not low on ink.
<G-vec00297-002-s164><resolve.beheben><de> Navigieren Sie für eine Reparaturanfrage zum Online-Servicecenter, wenn das Problem durch diese Lösungen nicht behoben werden konnte.
<G-vec00297-002-s164><resolve.beheben><en> If these solutions don't resolve the problem, go to the Online Service Center and request a repair.
<G-vec00297-002-s165><resolve.beheben><de> Rufen Sie das Online-Servicecenter auf, um eine Reparatur anzufordern, wenn das Problem durch diese Schritte nicht behoben werden konnte.
<G-vec00297-002-s165><resolve.beheben><en> If these steps don't resolve the problem, you'll need to request a repair. Learn how to search
<G-vec00301-002-s019><correct.beheben><de> Falls du von einem anderen Teil unserer Webseite hier gelandet bist, kontaktiere uns bitte damit wir den Fehler beheben können.
<G-vec00301-002-s019><correct.beheben><en> If you reached this page from another part of our website, please contact us below so we can correct our mistake.
<G-vec00301-002-s020><correct.beheben><de> Aber unglücklicherweise, kann keine dieser Operationen das tatsächliche Problem beheben.
<G-vec00301-002-s020><correct.beheben><en> Unfortunately, none can correct the problem.
<G-vec00301-002-s021><correct.beheben><de> Das vollständige Beheben dieser Probleme kostete Monate, aber zum Ende der Meldefrist hatten sich landesweit etwa 7,3 Millionen Menschen bei einer Börse angemeldet.
<G-vec00301-002-s021><correct.beheben><en> It took months to fully correct these technical issues, but at the end of the open enrollment period, an estimated 7.3 million people had enrolled in an exchange nationwide.
<G-vec00301-002-s022><correct.beheben><de> Sie können das Problem beheben, indem Sie das Programm installieren, das dem im Hyperlink angegebenen Dokumenttyp zugeordnet ist.
<G-vec00301-002-s022><correct.beheben><en> To correct this problem, install the program that is associated with the document type that is specified in the hyperlink.
<G-vec00301-002-s023><correct.beheben><de> Die Daten werden ferner auch verwendet, um Fehler auf den Internetseiten ermitteln und beheben zu können.
<G-vec00301-002-s023><correct.beheben><en> The data is also used to identify and correct errors on the website.
<G-vec00301-002-s024><correct.beheben><de> Das lässt sich heute aber leicht beheben, denn für fast alle Sehprobleme gibt es die passende Seh-Lösung.
<G-vec00301-002-s024><correct.beheben><en> However, this is now easy to correct since there is a suitable solution for virtually all vision problems.
<G-vec00301-002-s025><correct.beheben><de> Mit den innovativen Fiery Werkzeugen für die Druckvorstufe lassen sich typische Probleme in Dateien frühzeitig erkennen und beheben, zum Beispiel fehlende Schriften und Probleme durch Spot-Farben, Bilder mit zu geringer Auflösung, gemischte Farbräume, Haarlinien unterhalb der vorgegebenen Mindeststärke, überdruckte und transparente Objekte und Artefakte sowie PostScript-Fehler.
<G-vec00301-002-s025><correct.beheben><en> Use advanced Fiery tools to identify and correct file issues before printing such as missing fonts, spot colors, low-resolution images, mixed source colors, hairlines below threshold, overprints, artifacts, transparencies and PostScript errors.
<G-vec00301-002-s026><correct.beheben><de> Nach Fertigstellung der Elektroinstallation werden alle erdverlegten Leitungen innerhalb des Solarfeldes mittels eines Hochspannungsgenerators geprüft, um mögliche Isolationsfehler festzustellen und zu beheben.
<G-vec00301-002-s026><correct.beheben><en> Once the electrical installation is complete, all sub-surface cables within the solar field are tested using a high-voltage generator to detect and correct any insulation problems.
<G-vec00301-002-s027><correct.beheben><de> Wir freuen uns, wenn Sie uns darauf hinweisen, damit wir den Fehler schnell beheben können.
<G-vec00301-002-s027><correct.beheben><en> We would appreciate it if you could tell us so that we may quickly correct the error.
<G-vec00301-002-s028><correct.beheben><de> Dieser Hotfix ist jedoch vorgesehen, um nur das Problem zu beheben, das in diesem Artikel beschrieben wird.
<G-vec00301-002-s028><correct.beheben><en> However, this hotfix is intended to correct only the problem that described in this article.
<G-vec00301-002-s029><correct.beheben><de> Bei der naturheilkundlichen Diagnostik schauen wir im Rahmen der Schmerztherapie insbesondere, ob auch ein Mangel an Vitaminen und Spurenelementen vorliegt und versuchen die Mangelzustände durch gezielte Ernährung oder den Einsatz orthomolekularer Präparate zu beheben.
<G-vec00301-002-s029><correct.beheben><en> As part of naturopathic diagnostics, particularly in the context of pain therapy, we determine whether there is a deficiency in vitamins and trace minerals and attempt to correct the deficiency conditions through targeted nutrition or use of orthomolecular preparations.
<G-vec00301-002-s030><correct.beheben><de> 6.2 Wir werden auf unsere Kosten alle wirtschaftlich angemessenen Anstrengungen unternehmen, um eventuelle Fehler zeitnah zu beheben oder Ihnen eine alternative Möglichkeit bieten, die gewünschte Leistung zu erreichen.
<G-vec00301-002-s030><correct.beheben><en> 6.2 We will, at our expense, use all reasonable commercial efforts to correct any non-conformance promptly, or provide you with an alternative means of accomplishing its desired performance.
<G-vec00301-002-s031><correct.beheben><de> Diese Logfile-Informationen werden in anonymisierter Form ausgewertet, um die Benutzerfreundlichkeit der MP Webseite und die Dienste von MP zu verbessern und etwaige Fehler zu identifizieren und zu beheben.
<G-vec00301-002-s031><correct.beheben><en> The information of these log files is assessed in anonymous manner with the aim to improve the user friendliness and identify and correct possible errors of the MP Website and the MP’s services.
<G-vec00301-002-s032><correct.beheben><de> Wenn Sie bereits auf dem Verwaltungsserver Root vor der Aktualisierung 971541 Update angewendet haben, können Sie problemlos erneut anwenden Update 971541, um dieses Problem zu beheben.
<G-vec00301-002-s032><correct.beheben><en> If you have already applied update 971541 on the Root Management Server before the upgrade, you can safely reapply update 971541 to correct this issue.
<G-vec00301-002-s033><correct.beheben><de> Aber es kann schwierig, wenn nicht gar unmöglich, werden, die Fehler eines fehlerhaften oder boshaften automatischen Bearbeitungsskripts zu beheben.
<G-vec00301-002-s033><correct.beheben><en> But it can be hard, if not impossible, to correct the mistakes of a buggy or malicious automated editing script.
<G-vec00301-002-s034><correct.beheben><de> Wenn nicht, müssen Sie herausfinden warum und das Problem umgehend beheben.
<G-vec00301-002-s034><correct.beheben><en> If they don't, you need to go back and find out why and correct the situation immediately.
<G-vec00301-002-s035><correct.beheben><de> Sollte während der Garantiezeit ein Fehler auftreten (wobei sich „Fehler“ als Problem definiert, das durch falsches Verhalten des unmodifizierten Computercodes in der Software oder durch eine falsche, zu unrichtigen Ergebnissen führenden Aussage oder Abbildung in der Dokumentation bedingt ist), unternimmt der Lizenzgeber alle wirtschaftlich zumutbaren Anstrengungen, um den besagten Fehler zu beheben, vorausgesetzt, Sie lassen dem Lizenzgeber Folgendes zukommen: (a) eine schriftliche Mitteilung des Garantieanspruchs einschließlich einer Beschreibung des im Widerspruch zur Dokumentation stehenden Leistungsmangels und einer genauen Beschreibung der Betriebsbedingungen (inklusive der jeweiligen Software/Hardware-Konfiguration), in denen der Fehler aufgetreten ist, und (b) in zumutbarem Maße ein repräsentatives Beispiel für Eingaben, die zu einem wiederholten Auftreten des Fehlers führen und dessen Analyse ermöglichen.
<G-vec00301-002-s035><correct.beheben><en> If, during the Warranty Period, an Error occurs (where “Error” is defined as a problem caused by an incorrect operation of the unmodified computer code in the Software or an incorrect statement or diagram in the Documentation that produces incorrect results), Licensor will use commercially reasonable efforts to correct such Error, provided you furnish Licensor with the following: (a) written notice of the warranty claim, including a description of the failure to perform in accordance with the Documentation and a specific description of the operating conditions (including the specific software/hardware configuration) under which the failure occurred and (b) to the extent feasible, a representative sample of inputs for repeating and analysing the failure.
<G-vec00301-002-s037><correct.beheben><de> Das gilt für Programme ohne Einreichungs-Deadlines, bei Programmen mit solchen Deadlines sind die Mängel innerhalb von 10 Tagen nach Zustellung der Mängelinformation zu beheben.
<G-vec00301-002-s037><correct.beheben><en> This rule applies for programmes without specific submission deadlines; for programmes with specific submission deadlines, applicants must correct the errors in their applications within 10 days of being notified of the errors.
<G-vec00301-002-s259><rectify.beheben><de> Hier werden die Bereiche Incident Management mit dem Ziel der schnellstmöglichen Behebung von Störungen, um die Auswirkungen auf den Geschäftsbetrieb (der Kunden) zu minimieren, und Change-Management, zur Erstellung und Pflege eines standardisierten Verfahrens zur Bearbeitung und Dokumentation aller Veränderungen an den IT-Komponenten, vereint.
<G-vec00301-002-s259><rectify.beheben><en> The fields of Incident Management – which aims to rectify disruptions as soon as is possible to minimize repercussions on business operations (and the client) – and Change Management – which oversees the development and maintenance of a standardized method for the processing and documentation of all changes to IT components – are combined within this role.
<G-vec00301-002-s113><settle.beheben><de> Sie sollten nicht die exorbitante Kosten für verschreibungspflichtige Medikamente verhindern, dass Sie kaufen die Medikamente, die Sie benötigen, um Ihre Gesundheitsproblem zu beheben lassen.
<G-vec00301-002-s113><settle.beheben><en> You should not let the excessively high cost of Prescription medicines quit you from acquiring the medicines you have to settle your wellness problem.
<G-vec00301-002-s019><solve.beheben><de> Wenn dies der Fall ist, können Sie dieses Problem beheben, indem Sie diese Mobilgeräte aus dem Bereich entfernen oder die Sendefrequenz in den Router-Einstellungen ändern.
<G-vec00301-002-s019><solve.beheben><en> If that's the case removing these mobile devices from the area, or altering the broadcast frequency in the router settings can solve this issue.
<G-vec00301-002-s020><solve.beheben><de> Leute wurden mobilisiert und beheben ein Schlüsselzustandproblem".
<G-vec00301-002-s020><solve.beheben><en> People were mobilized and solve a key state problem".
<G-vec00301-002-s021><solve.beheben><de> Auf dieser Seite bieten wir Ihnen 2 Lösungstipps, um das Problem zu beheben.
<G-vec00301-002-s021><solve.beheben><en> Let us see some solutions to solve the issue.
<G-vec00301-002-s022><solve.beheben><de> Um diese Störung zu beheben, schalten Sie den Player aus und wieder ein.
<G-vec00301-002-s022><solve.beheben><en> To solve the problem, turn off the player and then turn it on again.
<G-vec00301-002-s023><solve.beheben><de> Falls sich das Problem mit diesen Schritten nicht beheben lässt, suchen Sie anhand der folgenden Liste nach einem spezifischen Problem.
<G-vec00301-002-s023><solve.beheben><en> If that doesn't solve the problem, look for a specific problem in the following list.
<G-vec00301-002-s024><solve.beheben><de> Lesen Sie häufig gestellte Fragen, informieren Sie sich über Extender, und beheben Sie Probleme.
<G-vec00301-002-s024><solve.beheben><en> Browse our Frequently Asked Questions, learn about extenders, and solve problems.
<G-vec00301-002-s025><solve.beheben><de> Unsere Website und unser technisches Team helfen Ihnen, die beste Lösung für Ihre Verbindung zu finden und Probleme zu beheben.
<G-vec00301-002-s025><solve.beheben><en> StarTech.com's user-friendly website and Tech Advisors will point you towards the best solution to solve your connectivity problem.
<G-vec00301-002-s026><solve.beheben><de> Diese Formel wird sicherlich helfen Sie Ihren Haarausfall Problem zu beheben.
<G-vec00301-002-s026><solve.beheben><en> This item will help you solve your hair loss issue.
<G-vec00301-002-s027><solve.beheben><de> Zum Beheben dieses Problems laden Sie die Zune-Software herunter, aktualisieren den Kompatibilitätsmodus des Computers und installieren die Zune-Software anschließend erneut.
<G-vec00301-002-s027><solve.beheben><en> To solve this problem, download the Zune software, update your computer's compatibility mode and then install the Zune software again.
<G-vec00301-002-s028><solve.beheben><de> Sie können den Fehler beheben, indem Sie sicherstellen, dass zwischen dem Übergang kein anderer Schuss kommt.
<G-vec00301-002-s028><solve.beheben><en> You can solve the mistake by ensuring that no other shot comes in between the transition.
<G-vec00301-002-s029><solve.beheben><de> Erfassen Sie das Kundenfeedback in Bezug auf den Support und beheben Sie alle aufgezeigten Probleme.
<G-vec00301-002-s029><solve.beheben><en> Track customer feedback in regards to support and solve any noted issues.
<G-vec00301-002-s030><solve.beheben><de> Wir werden unser bestes tun, um Ihr Problem so schnell wie möglich zu beheben.
<G-vec00301-002-s030><solve.beheben><en> We will do our best to solve your problem as quickly as possible.
<G-vec00301-002-s031><solve.beheben><de> Minimieren Sie kostspielige Ortstermine, indem Sie Desktops und Anwendungen online aufrufen und steuern, um Probleme zu ermitteln und zu beheben.
<G-vec00301-002-s031><solve.beheben><en> Minimise costly on-site service calls by viewing and controlling remote desktops and applications online to diagnose and solve problems.
<G-vec00301-002-s032><solve.beheben><de> Das ist ein Problem, das bei Greenfoot bekannt ist, jedoch schwierig zu beheben ist.
<G-vec00301-002-s032><solve.beheben><en> This is a problem that is known for Greenfoot but it is difficult to solve.
<G-vec00301-002-s033><solve.beheben><de> Um das zu beheben, lösche das BE Service Verzeichnis (normalerweise „C:\Program Files (x86)\Common Files\BattlEye”) und dann versuche das Spiel neu zu starten.
<G-vec00301-002-s033><solve.beheben><en> To solve this delete the BE Service directory (usually “C:\Program Files (x86)\Common Files\BattlEye”) and then try to launch your game again.
<G-vec00301-002-s034><solve.beheben><de> Manchmal benötigt unser Supportteam zusätzliche Informationen von Ihnen, um Ihnen beim Beheben des Problems helfen zu können.
<G-vec00301-002-s034><solve.beheben><en> Sometimes, our support team will need some extra information from you in order to help you solve your problem.
<G-vec00301-002-s035><solve.beheben><de> So können wir 90 Prozent der Probleme per Fernwartung beheben und Sie wertvolle Zeit sparen.
<G-vec00301-002-s035><solve.beheben><en> In this way, we can solve 90% of the problems remotely and this will save you precious time.
<G-vec00301-002-s036><solve.beheben><de> Merlin arbeitet mit seinen Systemintegratoren und Partnern zusammen, um IT-Komplettlösungen bereitzustellen, die komplexe und kritische Probleme beheben, während die Ziele von Behörden und Organisationen erreicht werden, die sich mit Zivildiensten, Verteidigung, Nachrichtendiensten, dem Gesundheitswesen und anderen Sektoren befassen.
<G-vec00301-002-s036><solve.beheben><en> Working alongside its system integrator and vendor partners, Merlin provides turn-key IT solutions that solve complex and critical problems while fulfilling mission objectives for federal government agencies and organizations involved in civilian services, defense, intelligence, health care and a variety of other areas.
<G-vec00301-002-s037><solve.beheben><de> Wenn Sie dieses Problem auf dem klassischen Wege lösen möchten, können Sie iTunes verwenden und es so beheben.
<G-vec00301-002-s037><solve.beheben><en> If you want to solve this issue in the old fashioned way then you can use iTunes and solve it.
<G-vec00322-002-s233><fix.beheben><de> Bei ABRT (Automatic Bug Reporting Tool) handelt es sich um ein Tool, das Benutzern bei der Erstellung von Bug Reports hilft und alle Informationen liefert, die der Betreiber für das Beheben eines Problems benötigt.
<G-vec00322-002-s233><fix.beheben><en> ABRT (Automatic Bug Reporting Tool) is a tool to help users to detect defects in applications and to create a bug report with all the information needed by a maintainer to fix it.
<G-vec00322-002-s234><fix.beheben><de> Gin würde das beheben.
<G-vec00322-002-s234><fix.beheben><en> Gin would fix that.
<G-vec00322-002-s235><fix.beheben><de> Snapheal ist die schnellste und einfachste Fotosoftware für Macs, die Fotografen das Entfernen unerwünschter Elemente in Fotos sowie das Beheben von Mängeln ermöglicht.
<G-vec00322-002-s235><fix.beheben><en> Selective enhancement Snapheal is the fastest and easiest photo software for Mac available to help photographers remove unwanted elements from photo and fix imperfections.
<G-vec00322-002-s236><fix.beheben><de> Hoffe ihr könnt das beheben, Großes danke im voraus.
<G-vec00322-002-s236><fix.beheben><en> Hope you can fix that, big thank you in advance.
<G-vec00322-002-s237><fix.beheben><de> Die Meeting-ID ist ungültig.Wenn Sie versuchen, an einer Sitzung teilzunehmen und Ihnen die Meldung "Die Meeting-ID ist ungültig" angezeigt wird, bedeutet dies Folgendes: Die von Ihnen eingegebene Meeting-ID stimmt nicht mit der Sitzung überein, an der Sie teilnehmen möchten, da die Meeting-ID nicht korrekt ist, falsch geschrieben wurde oder abgelaufen ist.Erfahren Sie, wie Sie das Problem beheben.
<G-vec00322-002-s237><fix.beheben><en> Learn more. The webinarID is invalid.If you are trying to join a session and encounter "The webinar ID is invalid" message, it means that the webinar ID you entered does not match with the session you are trying to join because it is incorrect, was mistyped, or the webinar ID has expired.Learn how to fix it.
<G-vec00322-002-s238><fix.beheben><de> Ihr habt im letzten Jahr viele Hotfixes gesehen für alles, was wir ohne das Herunterfahren der Server beheben konnten.
<G-vec00322-002-s238><fix.beheben><en> You’ve seen a lot of hot fixes over the past year for everything that we could fix without server downtime.
<G-vec00322-002-s239><fix.beheben><de> Die Hauptursache dafür liegt in der fehlenden Zeit, die für die Pflege und das Beheben der Fehler benötigt wird.
<G-vec00322-002-s239><fix.beheben><en> The main reason cited was the lack of time required to maintain these packages and fix bugs in them.
<G-vec00322-002-s240><fix.beheben><de> Das bedeutet, das ihr Probleme leichter beheben könnt.
<G-vec00322-002-s240><fix.beheben><en> Therefore, you can and fix the problems easier.
<G-vec00322-002-s241><fix.beheben><de> Um dir das bestmögliche Erlebnis zu bieten, beheben wir ab und zu Bugs in der App und verbessern ihre Performance.
<G-vec00322-002-s241><fix.beheben><en> In order to provide you with best possible experience we occasionally update the app to fix bugs and improve performance.
<G-vec00322-002-s242><fix.beheben><de> Wenn Sie Probleme beim Senden oder Empfangen von E-Mails haben, lesen Sie über das Beheben von E-Mail-Synchronisierungsproblemen in Outlook.com.
<G-vec00322-002-s242><fix.beheben><en> If you're having problems sending or receiving email, read how to Fix Outlook.com email sync issues.
<G-vec00322-002-s243><fix.beheben><de> Die 100 Oktan werden das beheben.
<G-vec00322-002-s243><fix.beheben><en> The 100 octane will fix that.
<G-vec00322-002-s244><fix.beheben><de> Halo remover ist ein Tool das genau dieses Problem bei einem traditionellen Alphachannel beheben soll.
<G-vec00322-002-s244><fix.beheben><en> Halo remover is a tool to fix that problem for the traditional alpha channel.
<G-vec00365-002-s124><eliminate.beheben><de> Unsere Servicemitarbeiter an den Terminals können schnell per Fernwartung analysieren und Fehler beheben.
<G-vec00365-002-s124><eliminate.beheben><en> Our service staff working at the terminals will quickly analyse and eliminate problems via remote maintenance.
<G-vec00365-002-s125><eliminate.beheben><de> Die Umstellung der Buchhaltung auf Fremdwährung bietet eine hervorragende Möglichkeit für die Gesellschaften in Ungarn, den Großteil der aus Wechselkursschwankungen resultierenden Probleme zu beheben.
<G-vec00365-002-s125><eliminate.beheben><en> Changing to accounting in a foreign currency is an excellent opportunity for companies to eliminate the majority of problems stemming from exchange-rate fluctuations.
<G-vec00365-002-s126><eliminate.beheben><de> Im Falle einer Schulterenge mit Schleimbeutelentzündung (Impingement) werden die entzündlichen Anteile entfernt und Teile des knöchernen Schulterdaches abgetragen, um die Schmerzen zu beheben und den Bewegungsumfang im Gelenk zu vergrößern.
<G-vec00365-002-s126><eliminate.beheben><en> In the event of shoulder tightness with bursitis (impingement), the inflammatory proportions are removed and parts of the osteal coracoacromial arch are cleared away in order to eliminate the pain and increase the range of motion within the joint.
<G-vec00365-002-s127><eliminate.beheben><de> Diese Updates beheben Probleme, oft aber auch potenzielle Sicherheitslücken.
<G-vec00365-002-s127><eliminate.beheben><en> These updates eliminate problems, but often also potential security gaps.
<G-vec00365-002-s128><eliminate.beheben><de> Der Gast ist verpflichtet, das ihm Zumutbare beizutragen, um die Störung zu beheben und einen möglichen Schaden gering zu halten.
<G-vec00365-002-s128><eliminate.beheben><en> The customer is obliged to do what is reasonable to eliminate the problem and to keep any possible damage as low as possible.
<G-vec00365-002-s129><eliminate.beheben><de> In der Chakrenarbeit wird versucht, diese Störungen/Blockaden des Energieflusses zu beheben und es findet wieder vermehrt ein Ausgleich aller Chakren statt.
<G-vec00365-002-s129><eliminate.beheben><en> In the chakra work, an attempt is made to eliminate these disturbances / blockages of the energy flow and there is again an increased compensation of all chakras.
<G-vec00365-002-s130><eliminate.beheben><de> Beruhigung/Schlaf › Haut Leichte vorübergehende Schlafstörungen können Sie oft durch eine verbesserte Schlafhygiene (s. Tipps für einen besseren Schlaf) beheben.
<G-vec00365-002-s130><eliminate.beheben><en> You can often eliminate minor, temporary sleep disturbances by improving your sleeping environment and habits (See tips for better sleep).
<G-vec00365-002-s131><eliminate.beheben><de> Um vereinfacht einheitliche Pläne zu generieren, war es erforderlich, zuerst einmal Daten aus unterschiedlichen Datenquellen, Formaten und Inspektionsvorgängen zu konvertieren und Fehler im Datenbestand zu beheben.
<G-vec00365-002-s131><eliminate.beheben><en> To simplify the generation of uniform plans, it was necessary first of all to convert data from different data sources, formats and inspection procedures, and to eliminate errors in the database.
<G-vec00365-002-s132><eliminate.beheben><de> Der Kunde ist verpflichtet, das ihm Zumutbare beizutragen, um die Störung zu beheben und einen möglichen Schaden gering zu halten.
<G-vec00365-002-s132><eliminate.beheben><en> The customer is committed to contribute to reasonable degree to eliminate the dysfunction and to keep possible damage at a minimum.
<G-vec00365-002-s133><eliminate.beheben><de> Die Augenbehandlungen mit Laser können den Grund der Altersweitsichtigkeit (Presbyopie) nicht beheben, aber ungeachtet dessen können auch die mit der Altersweitsichtigkeit kämpfenden Menschen die Vorteile der Laserbehandlungen genießen.
<G-vec00365-002-s133><eliminate.beheben><en> Laser treatments cannot eliminate the cause of presbyopia; even so, people struggling with this problem can also benefit from them.
<G-vec00365-002-s134><eliminate.beheben><de> SnoreLab hat bereits mehr als 50 Millionen Nächte lang den Schlaf überwacht und Millionen Menschen geholfen, ihre Schlafprobleme besser zu verstehen oder vielleicht sogar ganz zu beheben.
<G-vec00365-002-s134><eliminate.beheben><en> SnoreLab has monitored more than 50 million nights of sleep and has helped millions of people to better understand or even eliminate their snoring problem.
<G-vec00365-002-s135><eliminate.beheben><de> Das Ziel: bestehende und zukünftige Partner besser kennenlernen sowie mögliche Schwachstellen in der Lieferkette entdecken und beheben.
<G-vec00365-002-s135><eliminate.beheben><en> The goal is to get to know existing and future partners better as well as identify and eliminate weak points in the supply chain.
<G-vec00365-002-s136><eliminate.beheben><de> Support-Automatisierung hilft dabei, Probleme mit verbundenen Geräten präventiv zu diagnostizieren und beheben.
<G-vec00365-002-s136><eliminate.beheben><en> Support automation helps to diagnose and eliminate problems preventively with connected devices.
<G-vec00365-002-s137><eliminate.beheben><de> Die Logfile-Datensätze werten wir in anonymisierter Form aus, um unser Angebot auf www.eGym.de weiter zu verbessern und nutzerfreundlicher zu gestalten, Fehler schneller zu finden und zu beheben sowie Serverkapazitäten zu steuern.
<G-vec00365-002-s137><eliminate.beheben><en> We evaluate the log file datasets in anonymized form in order to improve our range of services on the Site even further and make it more user-friendly, to locate and eliminate errors more quickly and to control server capacities.
<G-vec00365-002-s138><eliminate.beheben><de> Ein Post-Editor muss neben diesen Kenntnissen und Fähigkeiten auch wissen, welche Probleme und Fehlerquellen für die jeweiligen MÜ-Systeme typisch sind, damit er diese beheben und durch sein Post-Editing eine qualitativ hochwertige Übersetzung sicherstellt.
<G-vec00365-002-s138><eliminate.beheben><en> In addition to these skills and knowledge, a post-editor must also know which problems and sources of errors are typical for the respective MT system so that they can eliminate them and ensure a high-quality translation through their post-editing.
<G-vec00365-002-s139><eliminate.beheben><de> Um diese Problem sanft zu beheben, haben die MAVALA Laboratorien eine spezielle Glättende Rubbelcreme für die Füße entwickelt.
<G-vec00365-002-s139><eliminate.beheben><en> To gently eliminate these problems, the MAVALA Laboratories have developed a special smoothing scrub cream for feet.
<G-vec00365-002-s140><eliminate.beheben><de> Mit anderen Worten: Gemeinsam können wir effektiv die Lücken im Markt beheben und Überschüsse nach üppigen Ernten oder aufgrund geringerer Absatzmengen bei Werbungen im LEH anderweitig verwerten.
<G-vec00365-002-s140><eliminate.beheben><en> That is to say: together we can supplement shortfalls in the market effectively and eliminate surpluses after abundant harvests or disappointing shop sales.
<G-vec00365-002-s141><eliminate.beheben><de> Optimal auch als Schraubensicherung oder um das Knirschen im Tretlager zu beheben.
<G-vec00365-002-s141><eliminate.beheben><en> It’s also great as threadlocker and to eliminate creaking in the bottom bracket area.
<G-vec00365-002-s142><eliminate.beheben><de> Während seiner Zeit bei BMW besuchte er ein sehr intensives Spezialseminar zur Fehlermöglichkeits– und Einflussanalyse (FMEA), das die Vorgehensweise vor einer Produkteinführung beschreibt, um Fehler im Vorfeld zu beheben und ein endgültiges Produkt reibungslos zu fertigen, das den deutschen Qualitätsnormen entspricht.
<G-vec00365-002-s142><eliminate.beheben><en> During his time at BMW, he attended a very intensive special seminar on Failure Mode and Effects Analysis (FMEA), which describes the procedure before a product launch in order to eliminate errors in advance and to smoothly manufacture a final product that meets German quality standards.
