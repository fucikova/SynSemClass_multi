<G-vec00555-002-s095><cut.ausschneiden><de> Die Dynamic Photo-Funktion, mit der ein sich bewegendes Motiv ausgeschnitten und auf ein anderes unbewegtes Hintergrundbild gesetzt werden kann, wurde erheblich verbessert.
<G-vec00555-002-s095><cut.ausschneiden><en> Great advancements have been achieved in the Dynamic Photo function, which enables users to cut out images of a moving subject and paste them on a different still image that acts as a background.
<G-vec00555-002-s096><cut.ausschneiden><de> Auf das weiße Papier habe ich den Spruch gestempelt und es dann per Hand "ausgeschnitten" bevor ich dann noch den zweiten Teil hinzugestempelt habe.
<G-vec00555-002-s096><cut.ausschneiden><en> On the latter I stamped the first part of the sentiment and then fussy cut it out before stamping the second part as well.
<G-vec00555-002-s097><cut.ausschneiden><de> Der ist einmal mit schwarzer Tinte und einmal golden embossed gestempelt, ausgeschnitten und auf braunen Cardstock geklebt.
<G-vec00555-002-s097><cut.ausschneiden><en> I stamped it once with black ink, once heat embossed it using golden embossing powder, then cut those out and put them on brown cardstock.
<G-vec00555-002-s098><cut.ausschneiden><de> Bei den großen Waben werden die Kurven an jedem Ende verjüngt und aus der Platte ausgeschnitten.
<G-vec00555-002-s098><cut.ausschneiden><en> With large honeycombs, the curves are cut out of the sheet and tapered at each end.
<G-vec00555-002-s099><cut.ausschneiden><de> Ich habe den Jungen und das Mädchen abgestempelt, coloriert und dann anschließend konturengenau ausgeschnitten.
<G-vec00555-002-s099><cut.ausschneiden><en> stamped the boy and girl images, colored them and then cut them out trimming closely.
<G-vec00555-002-s100><cut.ausschneiden><de> Die Blüten habe ich nochmal extra gestempelt, mit Distress Inks farbig gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s100><cut.ausschneiden><en> I stamped the flowers again, wiped them with Distress Inks in colour, cut them out and glued them on.
<G-vec00555-002-s101><cut.ausschneiden><de> Einige Kinder haben ihren Fußabdruck ausgeschnitten und etwas aus der Natur darauf gemalt, was für sie besonders schützenswert ist.
<G-vec00555-002-s101><cut.ausschneiden><en> Some children cut out their footprints and draw something on it that deserves protection for them.
<G-vec00555-002-s102><cut.ausschneiden><de> Wo bisher langwierig ausgeschnitten und angepasst werden musste, kann das Rohr jetzt spielend leicht in die vorbereitete Zulauföffnung eingesteckt und der Regenfangkasten direkt an der Wand montiert werden.
<G-vec00555-002-s102><cut.ausschneiden><en> Where it previously had to be tediously cut and adjusted, the pipe can now easily be inserted through the prepared inflow opening and the rainwater hopper mounted directly on the wall.
<G-vec00555-002-s103><cut.ausschneiden><de> Das Motiv ist mit Copics coloriert und ausgeschnitten.
<G-vec00555-002-s103><cut.ausschneiden><en> The image is colored with Copics and cut out by hand.
<G-vec00555-002-s104><cut.ausschneiden><de> Als flächiges Material sind zB textile Materialien wie Gewebe oder Gewirke, aber auch Folien denkbar, aus denen die Markierungen zB ausgestanzt oder ausgeschnitten sind.
<G-vec00555-002-s104><cut.ausschneiden><en> As a sheet material, for example textile materials such as woven or knitted fabrics, but also films are also conceivable, of which the markings are, for example punched or cut out.
<G-vec00555-002-s105><cut.ausschneiden><de> Den weißen Cardstock im Hintergrund, den ich schwarz gemattet und auf eine weiße Grundkarte geklebt habe, ist mit Distress Ink Tumbled Glass und verschiedenen "Flecken" aus dem Distressed ein Bär aus dem Joyful Heart Bears Set und noch ein Schweinchen aus dem Piggy Pebbles Set) ist hinter den Rahmen geklebt und die Motive so ausgeschnitten, dass die eigentlich vom Rahmen abgedeckten Teile der Tiere vorne über den Rahmen überstehen.
<G-vec00555-002-s105><cut.ausschneiden><en> Der Carstock mit den Motiven (eine Maus aus dem Mice Time to Celebrate Set, The paper with the stamped on images (a mouse from the Mice Time to Celebrate stamp set, one of the bears from the Joyful Heart Bears set and a piglet from the Piggy Pebbles set) ist glued behind the frame and the images were cut out so the pieces that would've been covered by the frame are on top of it.
<G-vec00555-002-s106><cut.ausschneiden><de> Die Elefanten habe ich mit grauer Farbe gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s106><cut.ausschneiden><en> I wiped the elephants with grey paint, cut them out and glued them on.
<G-vec00555-002-s107><cut.ausschneiden><de> Umfangreiche Editierfunktionen (Blöcke können ausgeschnitten, eingefügt, verschoben oder in andere Programmfenster kopiert werden, auch direkt in andere Fenster ohne den Umweg über das Clipboard).
<G-vec00555-002-s107><cut.ausschneiden><en> Comprehensive editing functions (e.g., block functions such as cut, copy, paste, move, even directly moving into other windows without using the clipboard).
<G-vec00555-002-s108><cut.ausschneiden><de> Aus dem dichten Karton werden zwei identische Figuren ausgeschnitten.
<G-vec00555-002-s108><cut.ausschneiden><en> From the dense cardboard, two identical figures are cut out.
<G-vec00555-002-s109><cut.ausschneiden><de> Einige werden dann ausgeschnitten und so kann man sie als eine Art Objekt an die Wand hängen.
<G-vec00555-002-s109><cut.ausschneiden><en> And some of them, being cut out, can come to be an object on the wall.
<G-vec00555-002-s110><cut.ausschneiden><de> Die Spannweite liegt bei 2 Metern und es wurden für die Federn der Flügel eigene Teile per Hand ausgeschnitten.
<G-vec00555-002-s110><cut.ausschneiden><en> The span is 2 meters and own parts were cut out by hand for the feathers of the wings.
<G-vec00555-002-s111><cut.ausschneiden><de> Um den gewünschten Qualitätsstandard gewährleisten zu können, müssen diese kleinen Öffnungen sehr passgenau ausgeschnitten werden.
<G-vec00555-002-s111><cut.ausschneiden><en> In order to ensure the desired quality standard, these small openings must be cut out precisely.
<G-vec00555-002-s112><cut.ausschneiden><de> Jedes Foto kann danach als Postkarte ausgeschnitten und weitergeschickt werden.
<G-vec00555-002-s112><cut.ausschneiden><en> Each photo can be cut out and send as a postcard.
<G-vec00555-002-s113><cut.ausschneiden><de> Erstelle eine Collage aus Bildern, die du aus Zeitschriften ausgeschnitten hast, indem du sie überlappend auf dem Karton anbringst.
<G-vec00555-002-s113><cut.ausschneiden><en> Make a collage of images you cut out from magazines by overlapping them on your cardstock.
<G-vec00555-002-s114><cut_off.ausschneiden><de> Sie brauchen eine Videobearbeitung durchzuführen: nicht nötige Teilen ausschneiden (sonst kann das Ganze langweilig werden; bei professionellen Filmen scheidet man ziemlich viel aus, manche Episoden werden später als Extras zur DVD hinzugefügt, sie erscheinen aber nicht im Film; es gibt auch einen Unterschied zwischen Kino- und DVD-Versionen), Übergänge zwischen Episoden hinzufügen, Untertitel und andere Beschriftungen hinzufügen, einige Momenten mit Zoom betonen und das ganze Bild in kleinerer Box zeigen (Bild im Bild) usw.
<G-vec00555-002-s114><cut_off.ausschneiden><en> You need to do some video editing: cut unnecessary parts out (otherwise the whole thing can easily become boring; the professional movie makers cut pretty much out, some episodes are later included as specials on the DVD, but they don't appear in the actual movie; there is also a difference between theatrical and DVD (extended) editions), add transitions between episodes to make the movie smooth, add titles or subtitles where needed, emphasize some moments by zooming in while showing the whole picture in a smaller box (picture in picture), and so on.
<G-vec00555-002-s115><cut_off.ausschneiden><de> + Trimmen, Ausschneiden und Beschneiden Ihrer Fotos.
<G-vec00555-002-s115><cut_off.ausschneiden><en> + Trim, cut and crop your photos and video clips.
<G-vec00555-002-s116><cut_off.ausschneiden><de> Bearbeitungsbefehle für den Zauberstab: Sie können jetzt die Bearbeitungsbefehle „Ausschneiden“, „Kopieren“, „Einfügen“ und „Duplizieren“ auf Zauberstab-Auswahlen anwenden, um Modelle in mehrere Teile zu unterteilen.
<G-vec00555-002-s116><cut_off.ausschneiden><en> Magic Wand Edit Commands: You can now use the cut, copy, paste, and duplicate edit commands on magic wand selections, allowing you to break models up into multiple pieces.
<G-vec00555-002-s117><cut_off.ausschneiden><de> Danach die Orange über der Schüssel halten und Orangenfilets aus der Frucht ausschneiden.
<G-vec00555-002-s117><cut_off.ausschneiden><en> Then hold the orange over the bowl and cut the orange fillets out of the fruit.
<G-vec00555-002-s118><cut_off.ausschneiden><de> Markieren Sie den Inhaltsrahmen und wählen Sie „Bearbeiten“ > „Ausschneiden“.
<G-vec00555-002-s118><cut_off.ausschneiden><en> Select the content frame, and choose Edit > Cut.
<G-vec00555-002-s119><cut_off.ausschneiden><de> Mit dem Messer aus diesm Kreis ein Loch ausschneiden.
<G-vec00555-002-s119><cut_off.ausschneiden><en> With a knife cut out a hole through the circle and the pie.
<G-vec00555-002-s120><cut_off.ausschneiden><de> In FX File Explorer findet man alle Funktionen die man auch vom Desktop-PC kennt: Kopieren, Einfügen, Ausschneiden, Erstellen, Löschen, Umbenennen.
<G-vec00555-002-s120><cut_off.ausschneiden><en> When you're working with your files in FX File Explorer, you'll find the classic options you'd expect from a the desktop computer: copy, paste, cut, create, delete, rename.
<G-vec00555-002-s121><cut_off.ausschneiden><de> Blumen ausschneiden -...
<G-vec00555-002-s121><cut_off.ausschneiden><en> Cut out flowers - cubic...
<G-vec00555-002-s122><cut_off.ausschneiden><de> Aus dem blauen Gaffer Tape 2 kleine Quadrate ausschneiden und als Augen auf den Kopf kleben.
<G-vec00555-002-s122><cut_off.ausschneiden><en> Cut 2 small squares out of the blue Gaffer tape and glue them to the head to make the eyes.
<G-vec00555-002-s123><cut_off.ausschneiden><de> Du kannst Dateien ausschneiden/kopieren/einfügen/bewegen /löschen/umbenennen.
<G-vec00555-002-s123><cut_off.ausschneiden><en> You can cut/copy/paste/move/delete/rename files using Tabbles.
<G-vec00555-002-s124><cut_off.ausschneiden><de> Wenn du eine lausige Handschrift hast und keine von/an Karten oder Sticker, kannst du ein Quadrat aus abgestimmtem Geschenkpapier ausschneiden, es zu einer "Karte" falten und es festkleben.
<G-vec00555-002-s124><cut_off.ausschneiden><en> If you have lousy handwriting, and no to/from cards or stickers, you can cut a square of coordinating wrapping paper, fold it into a "card", and tape it in place.
<G-vec00555-002-s125><cut_off.ausschneiden><de> Du kannst Fotos ausschneiden und den Bereich als Hintergrundbild einstellen, der dir am besten gefällt.
<G-vec00555-002-s125><cut_off.ausschneiden><en> You can cut out pictures and set the area as a background image, the one you like best.
<G-vec00555-002-s126><cut_off.ausschneiden><de> Klicken Sie in der Symbolleiste auf die Schaltfläche Ausschneiden, um den Ordner und seinen Inhalt in die Zwischenablage zu verschieben.
<G-vec00555-002-s126><cut_off.ausschneiden><en> Click the Cut button on the toolbar to move the folder and its contents to the clipboard.
<G-vec00555-002-s127><cut_off.ausschneiden><de> Wenn Sie nach unten scrollen, werden Sie sehen, dass Google Cloud eine webbasierte Benutzeroberfläche entwickelt hat, mit der Sie jeden beliebigen Text in die Seite ausschneiden und einfügen können.
<G-vec00555-002-s127><cut_off.ausschneiden><en> When you scroll down, you will see that Google Cloud has built a web-based interface that lets you cut and paste any text into the page.
<G-vec00555-002-s128><cut_off.ausschneiden><de> Wenn Sie eine ganze Zeile oder Spalte und „Bearbeiten“ > „Ausschneiden“ ausgewählt haben, wird die ganze Zeile oder Spalte (und nicht nur der Inhalt der Zellen) aus der Tabelle entfernt.
<G-vec00555-002-s128><cut_off.ausschneiden><en> If you selected an entire row or column and you select Edit > Cut, the entire row or column is removed from the table (not just the contents of the cells).
<G-vec00555-002-s129><cut_off.ausschneiden><de> Lasse das Kind, um den Schnabel für den Pinguin zu machen, ein kleines Dreieck aus dem orangen Bastelpapier ausschneiden.
<G-vec00555-002-s129><cut_off.ausschneiden><en> To make the beak for the penguin, have the child cut a small triangle out of the orange construction paper.
<G-vec00555-002-s130><cut_off.ausschneiden><de> Die Standard-Tastenkürzel Strg+C (Kopieren), Strg+X (Ausschneiden) und Strg+V (Einfügen) können für das Bearbeiten verwendet werden.
<G-vec00555-002-s130><cut_off.ausschneiden><en> The default shortcuts Ctrl+C (copy), Ctrl+X (cut) and Ctrl+V (paste) can be used for editing.
<G-vec00555-002-s131><cut_off.ausschneiden><de> D. Ausschneiden: Sie können die Option zum Ausschneiden verwenden, um eine Komponente von einer Position in der interaktiven Kommunikation an eine andere Position zu verschieben.
<G-vec00555-002-s131><cut_off.ausschneiden><en> C. Cut: You can use the cut option to move a component from one place to another in the adaptive form.
<G-vec00555-002-s042><expel.ausschneiden><de> Im Fall der Nichteinhaltung vertraglicher Beförderungsbedingungen, Anweisungen für Reisende und Anweisungen für Benutzer der Skistrecken, insbesondere beim Überholen und bei Fahrt außer markierten Abfahrtsstrecken, behält sich der Betreiber das Recht vor, solchen Teilnehmer aus Beförderung auszuscheiden.
<G-vec00555-002-s042><expel.ausschneiden><en> When not complying to the terms and conditions of transportation and/or when not respecting instructions for travellers on ski slopes, especially when cutting in line or skiing out of the designated ski areas, the ski-lift operator reserves the right to expel such a traveller from transportation!
<G-vec00555-002-s043><expel.ausschneiden><de> Sobald die Abfallprodukte in Richtung Rektum bewegt werden, signalisieren die Nerven des Rektums dem Körper, dass es Zeit ist, den Stuhl auszuscheiden.
<G-vec00555-002-s043><expel.ausschneiden><en> As these materials pass from the large intestine into the rectum, nerves in the rectum signal the body that it is time to expel the wastes.
<G-vec00555-002-s044><expel.ausschneiden><de> Bei einem Schlafentzug von 6 Stunden oder weniger zeigen Studien eine beschleunigte körperliche Erschöpfung; Milchsäure baut sich schneller auf, die Fähigkeit der Lunge, Kohlendioxid auszuscheiden und Sauerstoff aufzunehmen, wird verringert.
<G-vec00555-002-s044><expel.ausschneiden><en> With a sleep deprivation of 6 hours of sleep or less, studies show accelerated physical exhaustion; lactic acid builds up faster, the capacity of the lungs to expel carbon dioxide and to absorb oxygen is reduced.
<G-vec00555-002-s045><expel.ausschneiden><de> Es ist äußerst schmerzhaft sie auszuscheiden und manchmal kann eine Operation erforderlich sein, um sie zu entfernen.
<G-vec00555-002-s045><expel.ausschneiden><en> They are extremely painful to expel from the body, and can sometimes require surgery to remove.
