<G-vec00595-002-s143><detach.abmontieren><de> Bevor wir eine Uhr verschicken, montieren wir immer die beiden Zeiger ab, damit sie auf dem Transport keinen Schaden erleiden.
<G-vec00595-002-s143><detach.abmontieren><en> Before we send the clock we always detach both hands to avoid any damage in transport.
