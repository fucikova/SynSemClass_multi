<G-vec00321-002-s033><pull.abziehen><de> Entfernen sie die Treibstoffleitung und die Druckleitung, sie können diese einfach abziehen.
<G-vec00321-002-s033><pull.abziehen><en> Remove the fuel lines from the fuel tank, they will simply pull off.
<G-vec00321-002-s034><pull.abziehen><de> Spannen Sie den Nippel in den Schraubstock ein und spreizen Sie die einzelnen Drähte der Seele mit dem Schraubendreher auseinander, sodass sich der Nippel nicht mehr so leicht abziehen lässt – das macht die Lötstelle später stabil.
<G-vec00321-002-s034><pull.abziehen><en> Clamp the nipple in a vice and spread the individual wires of the core with the screwdriver so that the nipple is not as easy to pull off. This makes for a more robust soldering point later.
<G-vec00321-002-s035><pull.abziehen><de> Ein einfaches Handwerkzeug zur Unterstützung der Arbeiten an Steckverbindungen besteht aus einem Grundkörper mit einem offenen Kanal für die Aufnahme des Kabels, einer Buchse und einer Hülse zur Arretierung von Greifkrallen zum Abziehen von Kabelverbindungen.
<G-vec00321-002-s035><pull.abziehen><en> A simple hand tool for support of the connection and disconnection of plug couplings consists of an open channel in a base for the cable, a socket and a movable shell for the fixation of gripping claws to pull out a plug.
<G-vec00321-002-s036><pull.abziehen><de> 6) Die BLAUE Deckfolie am Klebestreifen anfassen und von der Schutzfolie abziehen.
<G-vec00321-002-s036><pull.abziehen><en> 6) Hold the BLUE cover film on the adhesive strips and pull off from the protective film.
<G-vec00321-002-s037><pull.abziehen><de> Per Knopfdruck lässt sich der Absatz/Mantel vom Kern abziehen.
<G-vec00321-002-s037><pull.abziehen><en> Via touch of a button you can pull of the heel/ coat from the core.
<G-vec00321-002-s038><pull.abziehen><de> MONTAGEANLEITUNGEN Achtung: Achtung: Vor der Durchführung irgendwelcher Arbeiten am motorisierten Sprühgerät immer erst den Motor ausschalten und den Kerzenstecker von der Zündkerze abziehen.
<G-vec00321-002-s038><pull.abziehen><en> ASSEMBLY INSTRUCTIONS CAUTION: Before performing any work on the power sprayer, always switch off the motor and pull the spark plug connectors off the spark plug.
<G-vec00321-002-s039><pull.abziehen><de> Die längere Schutzkappe abziehen.
<G-vec00321-002-s039><pull.abziehen><en> Pull off the longer protection cap.
<G-vec00321-002-s040><pull.abziehen><de> Durch die Verspannung werden jedoch die Klemmelemente so verklemmt, daß ein Abziehen der Teile des Implantates von der Halteeinrichtung stark erschwert oder gar unmöglich ist.
<G-vec00321-002-s040><pull.abziehen><en> However, the clamping elements are clamped due to the bracing such that it is very difficult or even impossible to pull off the parts of the implant from the holding means.
<G-vec00321-002-s041><pull.abziehen><de> Gegebenenfalls den unteren Sprüharm 23 nach oben abziehen.
<G-vec00321-002-s041><pull.abziehen><en> If necessary, pull the lower arm 23 upwards and lift it off.
<G-vec00321-002-s042><pull.abziehen><de> Schutzkappe abziehen.
<G-vec00321-002-s042><pull.abziehen><en> Pull off the cap.
<G-vec00321-002-s043><pull.abziehen><de> Es ist eine große Amp, abziehen können viele Töne.
<G-vec00321-002-s043><pull.abziehen><en> It's a great amp that can pull off many tones.
<G-vec00321-002-s044><pull.abziehen><de> Ich konnte einen von meiner Wange abziehen, aber er hinterließ kleine Rückstände.
<G-vec00321-002-s044><pull.abziehen><en> I was able to pull one off my cheek, but it left a little residue.
<G-vec00321-002-s045><pull.abziehen><de> Pads auf das geschlossene Augenlid legen, kurz einwirken lassen und nach unten abziehen.
<G-vec00321-002-s045><pull.abziehen><en> Place pad on closed eyelid, leave to work briefly and then pull downwards.
<G-vec00321-002-s046><pull.abziehen><de> Damit Sie in Zukunft Ihre Rollenware leicht und einfach abziehen können, bieten wir einen Bodenständer aus weiß lackier-tem Metall an.
<G-vec00321-002-s046><pull.abziehen><en> To let you easily pull off your rolls in future we offer a storage rack made of white painted metal.
<G-vec00321-002-s047><pull.abziehen><de> Das 24K Gold Augenpatch entfernen und die Maske von den äußeren Rändern her sanft abziehen.
<G-vec00321-002-s047><pull.abziehen><en> Remove the 24K gold eye patch and gently pull the mask off the outer edges.
<G-vec00321-002-s048><pull.abziehen><de> Ein weiterer Trick, den einige Casinos abziehen, ist es, die Vollendung der Bonus-Wettanforderungen auf bestimmte Spiele zu limitieren, und zwar in der Regel auf diejenigen, die einen sehr hohen Hausvorteil besitzen.
<G-vec00321-002-s048><pull.abziehen><en> Another trick some casinos pull is to limit the completion of bonus wagering requirements to certain games, typically those with a very high house edge.
<G-vec00321-002-s049><pull.abziehen><de> Service Rund um Ihren Extruder bieten wir Ihnen verschiedene Serviceleistungen an, wodurch Sie zum Beispiel frühzeitig den Verschleißzustand der Gehäuse erkennen, die Elemente schnell und sicher von den Kernwellen abziehen und Ihre Gehäuse effizient und kostengünstig reparieren lassen können.
<G-vec00321-002-s049><pull.abziehen><en> For all aspects of your extruder, we offer a variety of services that you can use, for example, to detect the level of wear on the housing at an early stage, pull off the elements quickly and safely from the shafts and have your housing repaired efficiently and cost-effectively.
<G-vec00321-002-s050><pull.abziehen><de> Zum Austausch einfach den Bürstenkopf abziehen und durch einen neuen ersetzen.
<G-vec00321-002-s050><pull.abziehen><en> To change, simply pull off used brush head and replace it with a new one.
<G-vec00321-002-s051><pull.abziehen><de> Der G2 ist völlig vielseitig und kann viele Looks und Styles abziehen.
<G-vec00321-002-s051><pull.abziehen><en> The G2 is completely versatile and can pull off many looks and styles.
<G-vec00321-002-s057><withdraw.abziehen><de> In Abunimahs Perspektive, dass die Bewegung für BDS durch „offen erklärte Apartheid“ Auftrieb erfährt, zeigt sich das Wesentliche von der Strategie dieser Bewegung, die versucht, Uni-Verwaltungen und amerikanische Unternehmen durch moralisches Zureden dazu zu bringen, Kapitalanlagen aus Israel abzuziehen, und gleichzeitig den Boykott von Aktivitäten israelischer Akademiker und Kulturschaffender zu organisieren.
<G-vec00321-002-s057><withdraw.abziehen><en> Abunimah’s perspective of seeing “openly declared apartheid” as a boost to BDS goes straight to the heart of that movement’s strategy, which seeks to employ moral suasion to pressure campus administrations and American corporations to withdraw investments from Israel, while organizing boycotts of Israeli academic and cultural activities.
<G-vec00321-002-s058><withdraw.abziehen><de> In einem zuvor stattgefundenen Telefonat zwischen Trump und dem türkischen Amtskollegen Recep Tayyip Erdogan fiel offenbar die Entscheidung des US-Präsidenten, die US-Einheiten aus Syrien abzuziehen.
<G-vec00321-002-s058><withdraw.abziehen><en> But with US President Donald Trump's decision in December to withdraw US forces from Syria, Turkey has repeatedly threatened to attack the YPG.
<G-vec00321-002-s059><withdraw.abziehen><de> In Neu-Delhi widersetzt Walter sich den Anweisungen seines Arztes und trifft sich mit dem indischen Außenminister, um diesen zu bitten, seine Truppen abzuziehen.
<G-vec00321-002-s059><withdraw.abziehen><en> Unrated CC In New Delhi, Walter defies doctor's orders and meets with the Indian Foreign Minister to urge him to withdraw his troops.
<G-vec00321-002-s060><withdraw.abziehen><de> Um die Sicherheit der Gruppe zu gewährleisten werden Kriegschefs ernannt: sie werden mit den Arbeiten der Vorbeugung der Gewaltrisiken beauftragt, und sie verfügen über die Streitkräfte, um die Verbrecher gefangenzunehmen, die Waffen der feindlichen Hände abzuziehen.
<G-vec00321-002-s060><withdraw.abziehen><en> To ensure the safety of the group, of the chiefs of war are named: they are in charge of work of prevention of the risks of violence and they have the force armed to capture the criminals, to withdraw the weapons of the enemy hands.
<G-vec00321-002-s061><withdraw.abziehen><de> Bei dem deutsch-französischem Krieg von 1870 war Frankreich gezwungen, seine Legion abzuziehen, die das Land für den Schutz des Papstes in Rom stationiert hatte.
<G-vec00321-002-s061><withdraw.abziehen><en> In the Franco-German War of 1870, France was forced to withdraw its legion, which had stationed the country for the protection of the pope in Rome.
<G-vec00321-002-s062><withdraw.abziehen><de> Er erhielt die Erlaubnis, mit seiner Garnison und einem Teil seiner Artillerie abzuziehen.
<G-vec00321-002-s062><withdraw.abziehen><en> He was allowed to withdraw with his garrison and part of his artillery.
<G-vec00321-002-s063><withdraw.abziehen><de> Anleger können etwas bewirken, weil sie die Macht haben, Kapital aus Unternehmen, die ihrer Umweltverantwortung nicht gerecht werden, abzuziehen oder erst gar nicht in solche zu investieren.
<G-vec00321-002-s063><withdraw.abziehen><en> Investors matter because they have the power to withhold or withdraw capital from businesses that fail to take their environmental responsibilities seriously.
<G-vec00321-002-s064><withdraw.abziehen><de> Die globalen Gewerkschaften übergaben dem Botschafter ein Schreiben mit der Aufforderung an China, seine Truppen aus der Umgebung abzuziehen, und an die Verwaltung von Hongkong, unverzüglich in einen Dialog mit der Demokratiebewegung einzutreten.
<G-vec00321-002-s064><withdraw.abziehen><en> The global unions delivered a letter to the Ambassador calling on China to withdraw its troops from the vicinity and the Hong Kong administration to immediately enter into dialogue with the democracy movement.
<G-vec00321-002-s065><withdraw.abziehen><de> »Mir blieb nichts übrig, als abzuziehen, so wenig ich dies Benehmen unseres Freundes begriff.
<G-vec00321-002-s065><withdraw.abziehen><en> "I could do nothing but withdraw, although I could not understand the behaviour of our friend.
<G-vec00321-002-s066><withdraw.abziehen><de> Zweitens bietet der Sekundärmarkt die Möglichkeit, Investitionen schneller zu beenden, wenn ein unerwarteter Bedarf besteht, das Geld aus diesen Investitionen abzuziehen.
<G-vec00321-002-s066><withdraw.abziehen><en> Second, the secondary market gives investors the opportunity to exit investments faster in case of an unexpected need to withdraw money from these kinds of investments.
<G-vec00321-002-s067><withdraw.abziehen><de> Frankreich erklärte sich bereit, seine Truppen aus dem industriellen Ruhrgebiet abzuziehen, um die deutsche Produktion dort wieder aufzunehmen und zu erholen.
<G-vec00321-002-s067><withdraw.abziehen><en> France agreed to withdraw its troops from the industrial Ruhr region, allowing German production there to recommence and recover.
<G-vec00555-002-s033><pull_off.abziehen><de> Entfernen sie die Treibstoffleitung und die Druckleitung, sie können diese einfach abziehen.
<G-vec00555-002-s033><pull_off.abziehen><en> Remove the fuel lines from the fuel tank, they will simply pull off.
<G-vec00555-002-s034><pull_off.abziehen><de> Spannen Sie den Nippel in den Schraubstock ein und spreizen Sie die einzelnen Drähte der Seele mit dem Schraubendreher auseinander, sodass sich der Nippel nicht mehr so leicht abziehen lässt – das macht die Lötstelle später stabil.
<G-vec00555-002-s034><pull_off.abziehen><en> Clamp the nipple in a vice and spread the individual wires of the core with the screwdriver so that the nipple is not as easy to pull off. This makes for a more robust soldering point later.
<G-vec00555-002-s035><pull_off.abziehen><de> Ein einfaches Handwerkzeug zur Unterstützung der Arbeiten an Steckverbindungen besteht aus einem Grundkörper mit einem offenen Kanal für die Aufnahme des Kabels, einer Buchse und einer Hülse zur Arretierung von Greifkrallen zum Abziehen von Kabelverbindungen.
<G-vec00555-002-s035><pull_off.abziehen><en> A simple hand tool for support of the connection and disconnection of plug couplings consists of an open channel in a base for the cable, a socket and a movable shell for the fixation of gripping claws to pull out a plug.
<G-vec00555-002-s036><pull_off.abziehen><de> 6) Die BLAUE Deckfolie am Klebestreifen anfassen und von der Schutzfolie abziehen.
<G-vec00555-002-s036><pull_off.abziehen><en> 6) Hold the BLUE cover film on the adhesive strips and pull off from the protective film.
<G-vec00555-002-s037><pull_off.abziehen><de> Per Knopfdruck lässt sich der Absatz/Mantel vom Kern abziehen.
<G-vec00555-002-s037><pull_off.abziehen><en> Via touch of a button you can pull of the heel/ coat from the core.
<G-vec00555-002-s038><pull_off.abziehen><de> MONTAGEANLEITUNGEN Achtung: Achtung: Vor der Durchführung irgendwelcher Arbeiten am motorisierten Sprühgerät immer erst den Motor ausschalten und den Kerzenstecker von der Zündkerze abziehen.
<G-vec00555-002-s038><pull_off.abziehen><en> ASSEMBLY INSTRUCTIONS CAUTION: Before performing any work on the power sprayer, always switch off the motor and pull the spark plug connectors off the spark plug.
<G-vec00555-002-s039><pull_off.abziehen><de> Die längere Schutzkappe abziehen.
<G-vec00555-002-s039><pull_off.abziehen><en> Pull off the longer protection cap.
<G-vec00555-002-s040><pull_off.abziehen><de> Durch die Verspannung werden jedoch die Klemmelemente so verklemmt, daß ein Abziehen der Teile des Implantates von der Halteeinrichtung stark erschwert oder gar unmöglich ist.
<G-vec00555-002-s040><pull_off.abziehen><en> However, the clamping elements are clamped due to the bracing such that it is very difficult or even impossible to pull off the parts of the implant from the holding means.
<G-vec00555-002-s041><pull_off.abziehen><de> Gegebenenfalls den unteren Sprüharm 23 nach oben abziehen.
<G-vec00555-002-s041><pull_off.abziehen><en> If necessary, pull the lower arm 23 upwards and lift it off.
<G-vec00555-002-s042><pull_off.abziehen><de> Schutzkappe abziehen.
<G-vec00555-002-s042><pull_off.abziehen><en> Pull off the cap.
<G-vec00555-002-s043><pull_off.abziehen><de> Es ist eine große Amp, abziehen können viele Töne.
<G-vec00555-002-s043><pull_off.abziehen><en> It's a great amp that can pull off many tones.
<G-vec00555-002-s044><pull_off.abziehen><de> Ich konnte einen von meiner Wange abziehen, aber er hinterließ kleine Rückstände.
<G-vec00555-002-s044><pull_off.abziehen><en> I was able to pull one off my cheek, but it left a little residue.
<G-vec00555-002-s045><pull_off.abziehen><de> Pads auf das geschlossene Augenlid legen, kurz einwirken lassen und nach unten abziehen.
<G-vec00555-002-s045><pull_off.abziehen><en> Place pad on closed eyelid, leave to work briefly and then pull downwards.
<G-vec00555-002-s046><pull_off.abziehen><de> Damit Sie in Zukunft Ihre Rollenware leicht und einfach abziehen können, bieten wir einen Bodenständer aus weiß lackier-tem Metall an.
<G-vec00555-002-s046><pull_off.abziehen><en> To let you easily pull off your rolls in future we offer a storage rack made of white painted metal.
<G-vec00555-002-s047><pull_off.abziehen><de> Das 24K Gold Augenpatch entfernen und die Maske von den äußeren Rändern her sanft abziehen.
<G-vec00555-002-s047><pull_off.abziehen><en> Remove the 24K gold eye patch and gently pull the mask off the outer edges.
<G-vec00555-002-s048><pull_off.abziehen><de> Ein weiterer Trick, den einige Casinos abziehen, ist es, die Vollendung der Bonus-Wettanforderungen auf bestimmte Spiele zu limitieren, und zwar in der Regel auf diejenigen, die einen sehr hohen Hausvorteil besitzen.
<G-vec00555-002-s048><pull_off.abziehen><en> Another trick some casinos pull is to limit the completion of bonus wagering requirements to certain games, typically those with a very high house edge.
<G-vec00555-002-s049><pull_off.abziehen><de> Service Rund um Ihren Extruder bieten wir Ihnen verschiedene Serviceleistungen an, wodurch Sie zum Beispiel frühzeitig den Verschleißzustand der Gehäuse erkennen, die Elemente schnell und sicher von den Kernwellen abziehen und Ihre Gehäuse effizient und kostengünstig reparieren lassen können.
<G-vec00555-002-s049><pull_off.abziehen><en> For all aspects of your extruder, we offer a variety of services that you can use, for example, to detect the level of wear on the housing at an early stage, pull off the elements quickly and safely from the shafts and have your housing repaired efficiently and cost-effectively.
<G-vec00555-002-s050><pull_off.abziehen><de> Zum Austausch einfach den Bürstenkopf abziehen und durch einen neuen ersetzen.
<G-vec00555-002-s050><pull_off.abziehen><en> To change, simply pull off used brush head and replace it with a new one.
<G-vec00555-002-s051><pull_off.abziehen><de> Der G2 ist völlig vielseitig und kann viele Looks und Styles abziehen.
<G-vec00555-002-s051><pull_off.abziehen><en> The G2 is completely versatile and can pull off many looks and styles.
<G-vec00595-002-s045><detach.abziehen><de> Komfortable Anfasslaschen ermöglichen dabei ein einfaches Handling der beiden Lagen und erleichtern auch das Abziehen der Teiletiketten, selbst mit Handschuhen.
<G-vec00595-002-s045><detach.abziehen><en> Convenient starter tabs simplify the handling of both layers and also make it easier to detach the label parts, even when wearing gloves.
