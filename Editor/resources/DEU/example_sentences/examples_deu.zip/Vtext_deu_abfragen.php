<G-vec00384-001-s021><poll.abfragen><de> Unabhängig davon, ob der Server erreichbar ist, wird eine weitere Abfrage basierend auf dem aktiven Abfrageintervall geplant.
<G-vec00384-001-s021><poll.abfragen><en> Whether the server can be reached or not, a subsequent poll is scheduled based on the active poll period interval.
<G-vec00384-001-s022><poll.abfragen><de> Easy2Sync für Outlook kann die E-Mail Abfrage Informationen von Outlook auch synchronisieren.
<G-vec00384-001-s022><poll.abfragen><en> To solve this, Easy2Sync for Outlook can sync the e-mail poll information.
<G-vec00384-001-s023><poll.abfragen><de> Client-Geräte, die während der Abfrage von IP-Bereichen gefunden wurden, werden im Ordner Domänen auf dem virtuellen Administrationsservers angezeigt.
<G-vec00384-001-s023><poll.abfragen><en> Managed devices detected during the IP ranges poll are displayed in the Domains folder of the virtual Administration Server.
<G-vec00384-001-s024><poll.abfragen><de> Die lageplanbasierte Videomanagement Software Video Center II zur Abfrage und Verwaltung von bis zu 10 MULTIEYE®-Systemen bietet die Möglichkeit, im Multiscreen bis zu vier Internet Webbrowser als Monitorfenster gleichzeitig zu öffnen und zu bedienen.
<G-vec00384-001-s024><poll.abfragen><en> "The site-plan based video management software ""Video Center II"" is designed to poll and administer up to 10 MULTIEYE systems at the same time. This makes it possible to simultaneously open and operate in a multiscreen up to four Internet web browsers as monitor windows."
<G-vec00384-001-s028><poll.abfragen><de> Wenn andere IP-Bereiche abgefragt werden müssen, fügen Sie sie manuell hinzu.
<G-vec00384-001-s028><poll.abfragen><en> If you want to poll other IP ranges, add them manually.
<G-vec00384-001-s029><poll.abfragen><de> Dabei wird standardmäßig ein Replikationspartner einmal in der Stunde automatisch auf neue Änderungen abgefragt.
<G-vec00384-001-s029><poll.abfragen><en> By default, they automatically poll a replication partner for new changes once every hour.
<G-vec00384-001-s030><poll.abfragen><de> Durch das Plugin werden keine Daten von den entsprechenden Seiten automatisch abgefragt, was dieses besonders Datenschutz freundlich macht.
<G-vec00384-001-s030><poll.abfragen><en> The plugin does not automatically poll the data from the corresponding pages, which makes this especially data protection friendly.
