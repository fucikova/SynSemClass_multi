<G-vec00384-001-s021><poll.abfragen><de> Unabhängig davon, ob der Server erreichbar ist, wird eine weitere Abfrage basierend auf dem aktiven Abfrageintervall geplant.
<G-vec00384-001-s021><poll.abfragen><en> Whether the server can be reached or not, a subsequent poll is scheduled based on the active poll period interval.
<G-vec00384-001-s022><poll.abfragen><de> Easy2Sync für Outlook kann die E-Mail Abfrage Informationen von Outlook auch synchronisieren.
<G-vec00384-001-s022><poll.abfragen><en> To solve this, Easy2Sync for Outlook can sync the e-mail poll information.
<G-vec00384-001-s023><poll.abfragen><de> Client-Geräte, die während der Abfrage von IP-Bereichen gefunden wurden, werden im Ordner Domänen auf dem virtuellen Administrationsservers angezeigt.
<G-vec00384-001-s023><poll.abfragen><en> Managed devices detected during the IP ranges poll are displayed in the Domains folder of the virtual Administration Server.
<G-vec00384-001-s024><poll.abfragen><de> Die lageplanbasierte Videomanagement Software Video Center II zur Abfrage und Verwaltung von bis zu 10 MULTIEYE®-Systemen bietet die Möglichkeit, im Multiscreen bis zu vier Internet Webbrowser als Monitorfenster gleichzeitig zu öffnen und zu bedienen.
<G-vec00384-001-s024><poll.abfragen><en> "The site-plan based video management software ""Video Center II"" is designed to poll and administer up to 10 MULTIEYE systems at the same time. This makes it possible to simultaneously open and operate in a multiscreen up to four Internet web browsers as monitor windows."
<G-vec00384-001-s028><poll.abfragen><de> Wenn andere IP-Bereiche abgefragt werden müssen, fügen Sie sie manuell hinzu.
<G-vec00384-001-s028><poll.abfragen><en> If you want to poll other IP ranges, add them manually.
<G-vec00384-001-s029><poll.abfragen><de> Dabei wird standardmäßig ein Replikationspartner einmal in der Stunde automatisch auf neue Änderungen abgefragt.
<G-vec00384-001-s029><poll.abfragen><en> By default, they automatically poll a replication partner for new changes once every hour.
<G-vec00384-001-s030><poll.abfragen><de> Durch das Plugin werden keine Daten von den entsprechenden Seiten automatisch abgefragt, was dieses besonders Datenschutz freundlich macht.
<G-vec00384-001-s030><poll.abfragen><en> The plugin does not automatically poll the data from the corresponding pages, which makes this especially data protection friendly.
<G-vec00361-002-s020><solicit.abfragen><de> Diese anderen Websites können ihre eigenen Cookies an Benutzer senden und Daten oder persönliche Informationen abfragen.
<G-vec00361-002-s020><solicit.abfragen><en> These other sites may send their own cookies to users, collect data, or solicit personal information.
<G-vec00384-002-s020><inquire.abfragen><de> DMA-Gerätetreiber müssen also zunächst abfragen, ob der DMA-Chip blockiert worden ist, und flock dann, wenn sie mit der Arbeit beginnen, selbst setzen.
<G-vec00384-002-s020><inquire.abfragen><en> So DMA device drivers must first inquire whether the DMA chip has been blocked and set flock themselves when they start work.
<G-vec00384-002-s022><poll.abfragen><de> Der Listener sollte die konsolidierte Datenbank abfragen, die Push-Benachrichtigung herunterladen und die Tabelle Dealer in der entfernten Datenbank aktualisieren.
<G-vec00384-002-s022><poll.abfragen><en> The Listener should poll the consolidated database, download the push notification, then update the Dealer table on the remote database.
<G-vec00384-002-s023><poll.abfragen><de> Mit diesem Plugin können Spieler andere Spieler melden und außerdem abfragen, ob gerade ein Admin Online ist.
<G-vec00384-002-s023><poll.abfragen><en> This Plugin enables players to report other players and in addition it is possible to poll a list of currently online admins
<G-vec00384-002-s025><poll.abfragen><de> Wenn Sie nach einer beschleunigten Option suchen, werden wir automatisch mehrere Versandunternehmen abfragen, um sicherzustellen, dass Sie basierend auf Ihrer Bestellung und Ihrem Standort den niedrigsten Preis haben.
<G-vec00384-002-s025><poll.abfragen><en> If you are looking for an expedited option, we will automatically poll multiple shipping carriers in order to ensure that you have the lowest price possible based on your order and location.
