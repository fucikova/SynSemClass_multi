<G-vec00213-002-s095><complete.absolvieren><de> Weiters sollen Studierende der Donau-Universität Krems und der Fachhochschule Krems die Möglichkeit erhalten, ein Doktoratsstudium an der University of Brighton zu absolvieren.
<G-vec00213-002-s095><complete.absolvieren><en> Furthermore, students at the Danube University Krems and the University of Applied Sciences Krems will now enjoy the opportunity to complete doctorate degree courses at the University of Brighton.
<G-vec00213-002-s096><complete.absolvieren><de> Sie absolvieren Ihr Bachelorstudium regulär an der RWTH Aachen.
<G-vec00213-002-s096><complete.absolvieren><en> You complete your Bachelor studies with a specialization in production technology at RWTH Aachen.
<G-vec00213-002-s097><complete.absolvieren><de> Trotz anfänglicher Schwierigkeiten schaffte er den Abschluss und konnte darauf aufbauend sogar noch ein Medizinstudium in Daressalam absolvieren.
<G-vec00213-002-s097><complete.absolvieren><en> In spite of initial difficulties, he successfully completed his degree and building on this, he was even able to complete a medical degree in Dar es Salaam.
<G-vec00213-002-s098><complete.absolvieren><de> Symbiose von Studium und Arbeitstätigkeit: Absolvieren Sie eine wissenschaftlich fundierte und zugleich praxisorientierte Fach- und Managementausbildung und gehen Sie nebenbei einer Arbeitstätigkeit von bis zu 70 Prozent nach.
<G-vec00213-002-s098><complete.absolvieren><en> A Symbiosis of Study and Work: Complete a program of professional and management training combining scientific knowledge and practical orientation while working part-time (70%) at your current job.
<G-vec00213-002-s099><complete.absolvieren><de> In 10 bis 15 Metern Höhe absolvieren Sie einen Parcours aus Tauen, Drahtseilen und Baumstämmen.
<G-vec00213-002-s099><complete.absolvieren><en> In 10 to 15 meters high above sea level, you will complete an obstacle course from ropes, wire ropes and tree trunks.
<G-vec00213-002-s100><complete.absolvieren><de> Die Absolventen der Internationalen Beziehungen müssen 40 Kurse (120 Punkte) absolvieren.
<G-vec00213-002-s100><complete.absolvieren><en> International Relations majors must complete 40 courses (120 credits).
<G-vec00213-002-s101><complete.absolvieren><de> Im Rahmen des SSI-Kurses „Cave Diving“ lernst du, Penetrationstauchgänge mit einer einzelnen Leine zu absolvieren.
<G-vec00213-002-s101><complete.absolvieren><en> As part of the SSI course “Cave Diving", you learn to complete penetration dives with a single line.
<G-vec00213-002-s102><complete.absolvieren><de> Schweißanfänger, aber auch Experten haben mit dem individuell einstellbaren Schweißsimulator die Möglichkeit, Trainingseinheiten zu absolvieren und so effektiv, risikolos und gleichzeitig ressourcenschonend das Schweißen zu erlernen und zu verbessern.
<G-vec00213-002-s102><complete.absolvieren><en> Using the customisable welding simulator, welding beginners and experts alike can complete training modules and learn how to weld or improve their skills effectively and safely while conserving resources.
<G-vec00213-002-s103><complete.absolvieren><de> Mitarbeitende einer Partnerhochschule haben die Möglichkeit, an der ZHAW zu unterrichten oder eine Weiterbildung zu absolvieren.
<G-vec00213-002-s103><complete.absolvieren><en> Staff from a European partner university can teach or complete a continuing education course at the ZHAW.
<G-vec00213-002-s104><complete.absolvieren><de> Nach dem Einweisungskurs, den jeder Besucher absolvieren muss, können Sie die Kletterparcours selbstständig mit eigenem Sicherheitsequipment durchklettern.
<G-vec00213-002-s104><complete.absolvieren><en> After the initial training course, which every visitor has to complete, you can tackle the climbing courses on your own with your own safety equipment.
<G-vec00213-002-s105><complete.absolvieren><de> Zu wissen, dass du einen Plan formuliert hast, um jeden Prüfungsabschnitt zu absolvieren, verleiht dir ebenfalls Selbstvertrauen.
<G-vec00213-002-s105><complete.absolvieren><en> Knowing that you have formulated a plan to complete each section of the exam will also instill confidence in you.
<G-vec00213-002-s106><complete.absolvieren><de> Bewerben können sich Medizinerinnen und Mediziner unter 35 Jahren, die nach mindestens zweijähriger wissenschaftlicher Arbeit im Ausland nach Deutschland zurückkehren, um hier zu forschen und gleichzeitig ihre klinische Facharztausbildung zu absolvieren.
<G-vec00213-002-s106><complete.absolvieren><en> The tender addresses medical specialists under 35 years of age who want to work at a German hospital after at least two years of scientific research work, preferably abroad, to intensify their research work and strive to complete their residency at the same time.
<G-vec00213-002-s107><complete.absolvieren><de> Etwas trainiert und ein Kardiotraining solltest du schon absolviert haben, um die langen Wanderrouten absolvieren zu können.
<G-vec00213-002-s107><complete.absolvieren><en> You should have done some training and cardio training in order to be able to complete the long hiking routes.
<G-vec00213-002-s108><complete.absolvieren><de> Sie können sich anmelden und den Kurs absolvieren, um ein teilbares Zertifikat zu erwerben, oder Sie können als Gast teilnehmen, um die Kursmaterialien gratis einzusehen.
<G-vec00213-002-s108><complete.absolvieren><en> You can enroll and complete the course to earn a shareable certificate, or you can audit it to view the course materials for free.
<G-vec00213-002-s109><complete.absolvieren><de> Studenten, die erfolgreich ein INTO Mason Graduate Pathway Programm in Geographic and Cartographic Sciences absolvieren, werden die Entwicklung zu einem Mason Graduate Degree-Programm nach Einreichung von zusätzlichen erforderlichen Bewerbungsunterlagen gesichert.
<G-vec00213-002-s109><complete.absolvieren><en> Students who successfully complete an INTO Mason Graduate Pathway program in Arts Management, are assured progression to a Mason graduate degree program upon submission of additional required application materials.
<G-vec00213-002-s110><complete.absolvieren><de> Als Gleisbauerin oder Gleisbauer haben Sie die Möglichkeit, die Berufsmatura zu absolvieren.
<G-vec00213-002-s110><complete.absolvieren><en> As a track layer, you have the opportunity to complete the vocational baccalaureate.
<G-vec00213-002-s111><complete.absolvieren><de> Dies ermöglicht es den Studierenden, sich für CIM-Qualifikationen zu qualifizieren, ohne alle Module absolvieren zu müssen.
<G-vec00213-002-s111><complete.absolvieren><en> This will enable students to study for CIM qualifications without needing to complete all of the modules.
<G-vec00213-002-s112><complete.absolvieren><de> Anfänger und Profis können mit der Multifunktion Hantelbank viele verschiedene effektive Fitnessübungen absolvieren.
<G-vec00213-002-s112><complete.absolvieren><en> Beginners and professionals can complete many different effective fitness exercises with the multifunction exercise bench.
<G-vec00213-002-s113><complete.absolvieren><de> Training: Mindestens drei Mitarbeitende absolvieren ein Sophora-Training mit Zertifizierung.
<G-vec00213-002-s113><complete.absolvieren><en> Training: A minimum of three employes complete a professional Sophora training.
<G-vec00379-002-s019><undergo.absolvieren><de> Das Bundesausbildungsförderungsgesetz (BAföG) ist ein Garant dafür, dass Jugendliche und junge Erwachsene eine Ausbildung absolvieren können, die ihrer Eignung und Neigung entspricht.
<G-vec00379-002-s019><undergo.absolvieren><en> The German Federal Training Assistance Act (BAföG) ensures that young people can undergo the kind of training that best suits their talent and inclination.
<G-vec00379-002-s020><undergo.absolvieren><de> In der Entwicklungs-Phase absolvieren die Versuchs-Traktoren umfangreiche Tests mit bis zu 10.000 Betriebsstunden bei härtesten Bedingungen, um die Langlebigkeit der Komponenten auf Herz und Nieren zu prüfen.
<G-vec00379-002-s020><undergo.absolvieren><en> In the development phase, the tractors undergo comprehensive testing, with up to 10,000 engine hours under the toughest conditions, to thoroughly test the durability of components.
<G-vec00379-002-s021><undergo.absolvieren><de> Für ausländische Arbeitskräfte ist es zudem sehr hilfreich, von Anfang an interne Fortbildungen zu absolvieren und auf diese Weise etwas in der Gruppe zu erlernen.
<G-vec00379-002-s021><undergo.absolvieren><en> It is also very helpful for foreign workers to undergo internal training right from the start and thus learn something in the group.
<G-vec00379-002-s022><undergo.absolvieren><de> Möglicherweise werden sie gebeten einen Fahrtest in Begleitung eines Avis-/Budget-Vertreters zu absolvieren.
<G-vec00379-002-s022><undergo.absolvieren><en> They may be required to undergo a driving assessment accompanied with an Avis / Budget representative.
<G-vec00379-002-s023><undergo.absolvieren><de> Im Team von ATT befinden sich ausschließlich interne Händler, welche alle eine strenge Ausbildung bei ATT-Trading mit einer Gesamtlaufzeit von mindestens zwei Jahren absolvieren mussten.
<G-vec00379-002-s023><undergo.absolvieren><en> The team of ATT consists exclusively of internal traders, all of whom had to undergo strict training with ATT trading with a total period of education of at least two years.
<G-vec00379-002-s024><undergo.absolvieren><de> Kern der Initiative ist der Gedanke „Ein Audit für einen ist ein Audit für alle“: Lieferanten müssen zukünftig nur ein Assessment beziehungsweise ein Audit absolvieren.
<G-vec00379-002-s024><undergo.absolvieren><en> At the heart of the Initiative is the idea “An audit for one is an audit for all.” In the future, suppliers will only have to undergo one assessment or one audit.
<G-vec00379-002-s025><undergo.absolvieren><de> Falls Sie auf den Aufenthalt am Sonntag anreisen, absolvieren Sie die ärztliche Eingangsuntersuchung am nächsten Arbeitstag vormittags.
<G-vec00379-002-s025><undergo.absolvieren><en> If you arrive on Sunday to stay, you will undergo the initial medical examination on next workday morning.
