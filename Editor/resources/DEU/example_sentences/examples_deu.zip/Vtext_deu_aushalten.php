<G-vec00197-001-s019><bear.aushalten><de> Der Prophet, der weder lesen noch schreiben konnte, antwortete: ´Ich kann nicht lesen.´ Der Engel hielt ihn dann gewaltsam fest und drückte seine Brust so fest, dass er es kaum aushalten konnte.
<G-vec00197-001-s019><bear.aushalten><en> The Prophet, who was unable to read or write, replied 'I do not know how to read'. The angel then held him forcibly and pressed his chest so hard that he could not bear the pressure.
<G-vec00197-001-s020><bear.aushalten><de> Ich denke an einem Punkt schrie ich und begann mich herumzuwälzen, da ich den Schmerz nicht aushalten konnte.
<G-vec00197-001-s020><bear.aushalten><en> I think I screamed at one point and started to thrash around, as I could not bear the pain.
<G-vec00197-001-s021><bear.aushalten><de> Die Realität muss man aushalten können.
<G-vec00197-001-s021><bear.aushalten><en> You have to be able to bear the truth.
<G-vec00197-001-s022><bear.aushalten><de> Für gewöhnlich konnte eine Person diese Folter nicht länger als drei Tage aushalten, doch Xu Daweis Gliedmassen wurden beim ersten Mal sieben Tage lang gezogen und später sogar noch länger.
<G-vec00197-001-s022><bear.aushalten><en> Usually a person could not bear it for more than three days, but Mr. Xu 's limbs were stretched like that for seven days the first time and then many more times thereafter.
<G-vec00197-001-s023><bear.aushalten><de> Wenn der Lehrer oder einer der Vorfahren auf dem Pfad weiß, dass du so weit bist, dass du es aushalten kannst, wirst du völlig aus dem Ego herausgeholt und zum wahren Zentrum und darüber hinaus gezogen.
<G-vec00197-001-s023><bear.aushalten><en> When the teacher or a superior on the path knows you are ready, that you are able to bear it, you are completely drawn out of the ego, pulled towards the real center and beyond.
<G-vec00197-001-s024><bear.aushalten><de> Die Liebe die aus ihnen herauskam, wusch in Wellen über mich und war so rein und stark, dass ich es nicht aushalten konnte.
<G-vec00197-001-s024><bear.aushalten><en> The love that came out from them washed over me in waves and was so pure and strong I could not bear it.
<G-vec00197-001-s025><bear.aushalten><de> Ich kann das nicht länger aushalten und frage die Frau, ob das von mir genommen werden könne.
<G-vec00197-001-s025><bear.aushalten><en> All this together causes me to weep. I can bear it no longer and ask the Lady whether it might pass.
<G-vec00197-001-s026><bear.aushalten><de> Es wurde mir klar gemacht, dass dieser Prozess unangenehm sein würde, aber ich könne es stoppen wenn ich den Schmerz nicht mehr aushalten würde.
<G-vec00197-001-s026><bear.aushalten><en> It was made plain to me that this process was going to be unpleasant, but I could stop it when it became too painful for me to bear.
<G-vec00197-001-s027><bear.aushalten><de> Unter drei Dingen erbebt die Erde, Und unter vieren kann sie es nicht aushalten: Unter einem Sklaven, wenn er König wird, Und einem Narren, wenn er Nahrung zur Genüge hat,Unter einer ungeliebten Frau, wenn sie geheiratet wird, Und einer Dienerin, wenn sie ihre Herrin aussticht (Spr 30:21-23).
<G-vec00197-001-s027><bear.aushalten><en> Under three things the earth quakes, And under four, it cannot bear up: Under a slave when he becomes king, And a fool when he is satisfied with food, Under an unloved woman when she gets a husband, And a maidservant when she supplants her mistress (Prov. 30:21-23).
<G-vec00197-001-s028><bear.aushalten><de> Versetzest du den Leib der Seele aber augenblicklich in einen großen Schmerz, so wird solches die Seele nicht lange aushalten, sondern sogleich einen gewaltigen Riss tun, und du kannst dann einen völlig toten Leib sieden und braten, und er wird nichts mehr fühlen von der Strafe.
<G-vec00197-001-s028><bear.aushalten><en> But were you to cause the soul‘s body great and sudden pain, then the soul shall not bear it for long and tear out, and you then can boil or roast a dead body and it shall feel no more punishment.
<G-vec00197-001-s029><bear.aushalten><de> Ich fiel, da ich soviel Macht und Schönheit nicht aushalten konnte.
<G-vec00197-001-s029><bear.aushalten><en> I fell because I could not bear such power and glory.
<G-vec00197-001-s030><bear.aushalten><de> Und es ist eigentlich ein schöner Zustand, nur aushalten musst du ihn.
<G-vec00197-001-s030><bear.aushalten><en> And it is actually a beautiful state, you just have to bear it.
<G-vec00197-001-s031><bear.aushalten><de> Beides müsse man aushalten können - auch als derjenige, der mit einem diese Momente teile.
<G-vec00197-001-s031><bear.aushalten><en> One must be able to bear both - also as those that divide these moments.
<G-vec00197-001-s032><bear.aushalten><de> Und wenn da Nähe war, dann war es immer ZU NAH, so dasss man es nicht aushalten konnte ein beklemmendes Gefühl wie eingeschlossen sein unter Wasser und langsam festfrieren.
<G-vec00197-001-s032><bear.aushalten><en> And if there was intimacy there it was TOO INTIMATE so that one couldn’t bear this uneasy feeling of being trapped under water and slowly freezing.
<G-vec00197-001-s033><bear.aushalten><de> Das bisherige Vorfeld hat schon einiges aushalten müssen: In den vergangenen fünf Jahrzehnten sind über sechs Millionen Flugzeuge mit einem Gesamtgewicht von mehr als 290 Millionen Tonnen über diese Flächen gerollt.
<G-vec00197-001-s033><bear.aushalten><en> The existing apron has had its load to bear. Over the past five decades, more than six million aircraft have taxied across its surface, with a total weight of over 290 million tonnes.
<G-vec00197-001-s034><bear.aushalten><de> Lu Hai konnte dies nicht mehr aushalten und so rief er seine Tante an, als er auf die Toilette ging.
<G-vec00197-001-s034><bear.aushalten><en> Lu Hai was unable to bear this and called his aunt when he went to use the toilet.
<G-vec00197-001-s035><bear.aushalten><de> Und der Alte tat das, und es ward ihm gleich so warm, daß er es am Ende vor lauter Wärme nicht mehr aushalten konnte und Mir dafür gar gewaltig zu danken anfing für solch eine Wohltat; aber da es ihm nun zu warm wäre, so möchte er nun sich etwas abkühlen; denn es sei ihm ein wenig zu warm.
<G-vec00197-001-s035><bear.aushalten><en> And the old man did so and he immediately became so hot that he could hardly bear the heat, thanking Me profusely for such favor, but because he is now too hot, he would like to cool down a little.
<G-vec00197-001-s036><bear.aushalten><de> Das Herz würde das Bewusstwerden einer so gigantischen Schlacht nicht aushalten.
<G-vec00197-001-s036><bear.aushalten><en> The heart could not bear the realization of so gigantic a battle.
<G-vec00197-001-s037><bear.aushalten><de> Er isst zu jeder Mahlzeit nur eine Schale Reis und eine Schale Suppe, lebt in einem einfachen Raum und erträgt Schwierigkeiten, die andere nicht aushalten können.
<G-vec00197-001-s037><bear.aushalten><en> He only eats one bowl of rice and one bowl of soup for each meal, lives in a simple room and bears hardships that others cannot bear.
<G-vec00241-001-s019><bear.aushalten><de> Der Prophet, der weder lesen noch schreiben konnte, antwortete: ´Ich kann nicht lesen.´ Der Engel hielt ihn dann gewaltsam fest und drückte seine Brust so fest, dass er es kaum aushalten konnte.
<G-vec00241-001-s019><bear.aushalten><en> The Prophet, who was unable to read or write, replied 'I do not know how to read'. The angel then held him forcibly and pressed his chest so hard that he could not bear the pressure.
<G-vec00241-001-s020><bear.aushalten><de> Ich denke an einem Punkt schrie ich und begann mich herumzuwälzen, da ich den Schmerz nicht aushalten konnte.
<G-vec00241-001-s020><bear.aushalten><en> I think I screamed at one point and started to thrash around, as I could not bear the pain.
<G-vec00241-001-s021><bear.aushalten><de> Die Realität muss man aushalten können.
<G-vec00241-001-s021><bear.aushalten><en> You have to be able to bear the truth.
<G-vec00241-001-s022><bear.aushalten><de> Für gewöhnlich konnte eine Person diese Folter nicht länger als drei Tage aushalten, doch Xu Daweis Gliedmassen wurden beim ersten Mal sieben Tage lang gezogen und später sogar noch länger.
<G-vec00241-001-s022><bear.aushalten><en> Usually a person could not bear it for more than three days, but Mr. Xu 's limbs were stretched like that for seven days the first time and then many more times thereafter.
<G-vec00241-001-s023><bear.aushalten><de> Wenn der Lehrer oder einer der Vorfahren auf dem Pfad weiß, dass du so weit bist, dass du es aushalten kannst, wirst du völlig aus dem Ego herausgeholt und zum wahren Zentrum und darüber hinaus gezogen.
<G-vec00241-001-s023><bear.aushalten><en> When the teacher or a superior on the path knows you are ready, that you are able to bear it, you are completely drawn out of the ego, pulled towards the real center and beyond.
<G-vec00241-001-s024><bear.aushalten><de> Die Liebe die aus ihnen herauskam, wusch in Wellen über mich und war so rein und stark, dass ich es nicht aushalten konnte.
<G-vec00241-001-s024><bear.aushalten><en> The love that came out from them washed over me in waves and was so pure and strong I could not bear it.
<G-vec00241-001-s025><bear.aushalten><de> Ich kann das nicht länger aushalten und frage die Frau, ob das von mir genommen werden könne.
<G-vec00241-001-s025><bear.aushalten><en> All this together causes me to weep. I can bear it no longer and ask the Lady whether it might pass.
<G-vec00241-001-s026><bear.aushalten><de> Es wurde mir klar gemacht, dass dieser Prozess unangenehm sein würde, aber ich könne es stoppen wenn ich den Schmerz nicht mehr aushalten würde.
<G-vec00241-001-s026><bear.aushalten><en> It was made plain to me that this process was going to be unpleasant, but I could stop it when it became too painful for me to bear.
<G-vec00241-001-s027><bear.aushalten><de> Unter drei Dingen erbebt die Erde, Und unter vieren kann sie es nicht aushalten: Unter einem Sklaven, wenn er König wird, Und einem Narren, wenn er Nahrung zur Genüge hat,Unter einer ungeliebten Frau, wenn sie geheiratet wird, Und einer Dienerin, wenn sie ihre Herrin aussticht (Spr 30:21-23).
<G-vec00241-001-s027><bear.aushalten><en> Under three things the earth quakes, And under four, it cannot bear up: Under a slave when he becomes king, And a fool when he is satisfied with food, Under an unloved woman when she gets a husband, And a maidservant when she supplants her mistress (Prov. 30:21-23).
<G-vec00241-001-s028><bear.aushalten><de> Versetzest du den Leib der Seele aber augenblicklich in einen großen Schmerz, so wird solches die Seele nicht lange aushalten, sondern sogleich einen gewaltigen Riss tun, und du kannst dann einen völlig toten Leib sieden und braten, und er wird nichts mehr fühlen von der Strafe.
<G-vec00241-001-s028><bear.aushalten><en> But were you to cause the soul‘s body great and sudden pain, then the soul shall not bear it for long and tear out, and you then can boil or roast a dead body and it shall feel no more punishment.
<G-vec00241-001-s029><bear.aushalten><de> Ich fiel, da ich soviel Macht und Schönheit nicht aushalten konnte.
<G-vec00241-001-s029><bear.aushalten><en> I fell because I could not bear such power and glory.
<G-vec00241-001-s030><bear.aushalten><de> Und es ist eigentlich ein schöner Zustand, nur aushalten musst du ihn.
<G-vec00241-001-s030><bear.aushalten><en> And it is actually a beautiful state, you just have to bear it.
<G-vec00241-001-s031><bear.aushalten><de> Beides müsse man aushalten können - auch als derjenige, der mit einem diese Momente teile.
<G-vec00241-001-s031><bear.aushalten><en> One must be able to bear both - also as those that divide these moments.
<G-vec00241-001-s032><bear.aushalten><de> Und wenn da Nähe war, dann war es immer ZU NAH, so dasss man es nicht aushalten konnte ein beklemmendes Gefühl wie eingeschlossen sein unter Wasser und langsam festfrieren.
<G-vec00241-001-s032><bear.aushalten><en> And if there was intimacy there it was TOO INTIMATE so that one couldn’t bear this uneasy feeling of being trapped under water and slowly freezing.
<G-vec00241-001-s033><bear.aushalten><de> Das bisherige Vorfeld hat schon einiges aushalten müssen: In den vergangenen fünf Jahrzehnten sind über sechs Millionen Flugzeuge mit einem Gesamtgewicht von mehr als 290 Millionen Tonnen über diese Flächen gerollt.
<G-vec00241-001-s033><bear.aushalten><en> The existing apron has had its load to bear. Over the past five decades, more than six million aircraft have taxied across its surface, with a total weight of over 290 million tonnes.
<G-vec00241-001-s034><bear.aushalten><de> Lu Hai konnte dies nicht mehr aushalten und so rief er seine Tante an, als er auf die Toilette ging.
<G-vec00241-001-s034><bear.aushalten><en> Lu Hai was unable to bear this and called his aunt when he went to use the toilet.
<G-vec00241-001-s035><bear.aushalten><de> Und der Alte tat das, und es ward ihm gleich so warm, daß er es am Ende vor lauter Wärme nicht mehr aushalten konnte und Mir dafür gar gewaltig zu danken anfing für solch eine Wohltat; aber da es ihm nun zu warm wäre, so möchte er nun sich etwas abkühlen; denn es sei ihm ein wenig zu warm.
<G-vec00241-001-s035><bear.aushalten><en> And the old man did so and he immediately became so hot that he could hardly bear the heat, thanking Me profusely for such favor, but because he is now too hot, he would like to cool down a little.
<G-vec00241-001-s036><bear.aushalten><de> Das Herz würde das Bewusstwerden einer so gigantischen Schlacht nicht aushalten.
<G-vec00241-001-s036><bear.aushalten><en> The heart could not bear the realization of so gigantic a battle.
<G-vec00241-001-s037><bear.aushalten><de> Er isst zu jeder Mahlzeit nur eine Schale Reis und eine Schale Suppe, lebt in einem einfachen Raum und erträgt Schwierigkeiten, die andere nicht aushalten können.
<G-vec00241-001-s037><bear.aushalten><en> He only eats one bowl of rice and one bowl of soup for each meal, lives in a simple room and bears hardships that others cannot bear.
<G-vec00442-001-s019><bear.aushalten><de> Der Prophet, der weder lesen noch schreiben konnte, antwortete: ´Ich kann nicht lesen.´ Der Engel hielt ihn dann gewaltsam fest und drückte seine Brust so fest, dass er es kaum aushalten konnte.
<G-vec00442-001-s019><bear.aushalten><en> The Prophet, who was unable to read or write, replied 'I do not know how to read'. The angel then held him forcibly and pressed his chest so hard that he could not bear the pressure.
<G-vec00442-001-s020><bear.aushalten><de> Ich denke an einem Punkt schrie ich und begann mich herumzuwälzen, da ich den Schmerz nicht aushalten konnte.
<G-vec00442-001-s020><bear.aushalten><en> I think I screamed at one point and started to thrash around, as I could not bear the pain.
<G-vec00442-001-s021><bear.aushalten><de> Die Realität muss man aushalten können.
<G-vec00442-001-s021><bear.aushalten><en> You have to be able to bear the truth.
<G-vec00442-001-s022><bear.aushalten><de> Für gewöhnlich konnte eine Person diese Folter nicht länger als drei Tage aushalten, doch Xu Daweis Gliedmassen wurden beim ersten Mal sieben Tage lang gezogen und später sogar noch länger.
<G-vec00442-001-s022><bear.aushalten><en> Usually a person could not bear it for more than three days, but Mr. Xu 's limbs were stretched like that for seven days the first time and then many more times thereafter.
<G-vec00442-001-s023><bear.aushalten><de> Wenn der Lehrer oder einer der Vorfahren auf dem Pfad weiß, dass du so weit bist, dass du es aushalten kannst, wirst du völlig aus dem Ego herausgeholt und zum wahren Zentrum und darüber hinaus gezogen.
<G-vec00442-001-s023><bear.aushalten><en> When the teacher or a superior on the path knows you are ready, that you are able to bear it, you are completely drawn out of the ego, pulled towards the real center and beyond.
<G-vec00442-001-s024><bear.aushalten><de> Die Liebe die aus ihnen herauskam, wusch in Wellen über mich und war so rein und stark, dass ich es nicht aushalten konnte.
<G-vec00442-001-s024><bear.aushalten><en> The love that came out from them washed over me in waves and was so pure and strong I could not bear it.
<G-vec00442-001-s025><bear.aushalten><de> Ich kann das nicht länger aushalten und frage die Frau, ob das von mir genommen werden könne.
<G-vec00442-001-s025><bear.aushalten><en> All this together causes me to weep. I can bear it no longer and ask the Lady whether it might pass.
<G-vec00442-001-s026><bear.aushalten><de> Es wurde mir klar gemacht, dass dieser Prozess unangenehm sein würde, aber ich könne es stoppen wenn ich den Schmerz nicht mehr aushalten würde.
<G-vec00442-001-s026><bear.aushalten><en> It was made plain to me that this process was going to be unpleasant, but I could stop it when it became too painful for me to bear.
<G-vec00442-001-s027><bear.aushalten><de> Unter drei Dingen erbebt die Erde, Und unter vieren kann sie es nicht aushalten: Unter einem Sklaven, wenn er König wird, Und einem Narren, wenn er Nahrung zur Genüge hat,Unter einer ungeliebten Frau, wenn sie geheiratet wird, Und einer Dienerin, wenn sie ihre Herrin aussticht (Spr 30:21-23).
<G-vec00442-001-s027><bear.aushalten><en> Under three things the earth quakes, And under four, it cannot bear up: Under a slave when he becomes king, And a fool when he is satisfied with food, Under an unloved woman when she gets a husband, And a maidservant when she supplants her mistress (Prov. 30:21-23).
<G-vec00442-001-s028><bear.aushalten><de> Versetzest du den Leib der Seele aber augenblicklich in einen großen Schmerz, so wird solches die Seele nicht lange aushalten, sondern sogleich einen gewaltigen Riss tun, und du kannst dann einen völlig toten Leib sieden und braten, und er wird nichts mehr fühlen von der Strafe.
<G-vec00442-001-s028><bear.aushalten><en> But were you to cause the soul‘s body great and sudden pain, then the soul shall not bear it for long and tear out, and you then can boil or roast a dead body and it shall feel no more punishment.
<G-vec00442-001-s029><bear.aushalten><de> Ich fiel, da ich soviel Macht und Schönheit nicht aushalten konnte.
<G-vec00442-001-s029><bear.aushalten><en> I fell because I could not bear such power and glory.
<G-vec00442-001-s030><bear.aushalten><de> Und es ist eigentlich ein schöner Zustand, nur aushalten musst du ihn.
<G-vec00442-001-s030><bear.aushalten><en> And it is actually a beautiful state, you just have to bear it.
<G-vec00442-001-s031><bear.aushalten><de> Beides müsse man aushalten können - auch als derjenige, der mit einem diese Momente teile.
<G-vec00442-001-s031><bear.aushalten><en> One must be able to bear both - also as those that divide these moments.
<G-vec00442-001-s032><bear.aushalten><de> Und wenn da Nähe war, dann war es immer ZU NAH, so dasss man es nicht aushalten konnte ein beklemmendes Gefühl wie eingeschlossen sein unter Wasser und langsam festfrieren.
<G-vec00442-001-s032><bear.aushalten><en> And if there was intimacy there it was TOO INTIMATE so that one couldn’t bear this uneasy feeling of being trapped under water and slowly freezing.
<G-vec00442-001-s033><bear.aushalten><de> Das bisherige Vorfeld hat schon einiges aushalten müssen: In den vergangenen fünf Jahrzehnten sind über sechs Millionen Flugzeuge mit einem Gesamtgewicht von mehr als 290 Millionen Tonnen über diese Flächen gerollt.
<G-vec00442-001-s033><bear.aushalten><en> The existing apron has had its load to bear. Over the past five decades, more than six million aircraft have taxied across its surface, with a total weight of over 290 million tonnes.
<G-vec00442-001-s034><bear.aushalten><de> Lu Hai konnte dies nicht mehr aushalten und so rief er seine Tante an, als er auf die Toilette ging.
<G-vec00442-001-s034><bear.aushalten><en> Lu Hai was unable to bear this and called his aunt when he went to use the toilet.
<G-vec00442-001-s035><bear.aushalten><de> Und der Alte tat das, und es ward ihm gleich so warm, daß er es am Ende vor lauter Wärme nicht mehr aushalten konnte und Mir dafür gar gewaltig zu danken anfing für solch eine Wohltat; aber da es ihm nun zu warm wäre, so möchte er nun sich etwas abkühlen; denn es sei ihm ein wenig zu warm.
<G-vec00442-001-s035><bear.aushalten><en> And the old man did so and he immediately became so hot that he could hardly bear the heat, thanking Me profusely for such favor, but because he is now too hot, he would like to cool down a little.
<G-vec00442-001-s036><bear.aushalten><de> Das Herz würde das Bewusstwerden einer so gigantischen Schlacht nicht aushalten.
<G-vec00442-001-s036><bear.aushalten><en> The heart could not bear the realization of so gigantic a battle.
<G-vec00442-001-s037><bear.aushalten><de> Er isst zu jeder Mahlzeit nur eine Schale Reis und eine Schale Suppe, lebt in einem einfachen Raum und erträgt Schwierigkeiten, die andere nicht aushalten können.
<G-vec00442-001-s037><bear.aushalten><en> He only eats one bowl of rice and one bowl of soup for each meal, lives in a simple room and bears hardships that others cannot bear.
