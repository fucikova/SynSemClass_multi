<G-vec00383-002-s019><die.absterben><de> Letztere sind nicht sofort sichtbar, können den Rasen aber absterben lassen.
<G-vec00383-002-s019><die.absterben><en> Fungi are not immediately visible but may cause the grass to die.
<G-vec00383-002-s020><die.absterben><de> Typisch für die Art sind die langen, dicken Wurzeln, die auch über Winter nicht absterben.
<G-vec00383-002-s020><die.absterben><en> Typical for this species are the thick and long roots, that do not die off over winter.
<G-vec00383-002-s021><die.absterben><de> Wenn Trastuzumab an HER2 bindet, kann es das Krebszellwachstum blockieren und zum Absterben der Krebszellen führen.
<G-vec00383-002-s021><die.absterben><en> When trastuzumab binds to HER2 it can stop the cancer cells growth and cause them to die.
<G-vec00383-002-s022><die.absterben><de> Wenn sie absterben, sinken sie zum Meeresboden, werden dabei im Laufe des Abstiegs zersetzt zu flockigen Klumpen.
<G-vec00383-002-s022><die.absterben><en> When they die, they sink to the bottom of the sea, decomposing into flaky lumps as they descend.
<G-vec00383-002-s023><die.absterben><de> Im Gegenteil: Sie schädigen Nervenzellen massiv und führen zu deren Absterben.
<G-vec00383-002-s023><die.absterben><en> On the contrary, they severely damage nerve cells and cause them to die.
<G-vec00383-002-s024><die.absterben><de> Dies geschieht normalerweise, wenn ein äußerer Faktor die Umgebung der Vagina verändert, wodurch andere Mikroorganismen absterben und Raum für Candida bleibt.
<G-vec00383-002-s024><die.absterben><en> This usually happens when an external factor changes the environment of the vagina, causing other microorganisms to die off, leaving space for candida to colonise.
<G-vec00383-002-s025><die.absterben><de> Daher sollte das Wasser zusätzlich belüftet werden, wenn Algen von alleine oder bei aktiver Bekämpfung absterben.
<G-vec00383-002-s025><die.absterben><en> Therefore the water needs to be aerated additionally when algae die! Why do algae sometimes grow so much?
<G-vec00383-002-s026><die.absterben><de> Auch wenn unsere Körper absterben, der Geist Gottes belebt, inspiriert und befähigt uns zum Sieg.
<G-vec00383-002-s026><die.absterben><en> Even though our bodies may die, the Spirit of God animates, inspires, and empowers us to victory.
<G-vec00383-002-s027><die.absterben><de> Diese Pflanzen sind einjährige Pflanzen, die im Winter absterben.
<G-vec00383-002-s027><die.absterben><en> These plants are annuals that will die off in the winter.
<G-vec00383-002-s028><die.absterben><de> Dieser Prozess ermöglicht es der Pflanze, so viel Energie wie möglich auf ein großartiges Produkt zu fokussieren, statt Energie für die Aufrechterhaltung der Blätter zu verschwenden, die sowieso absterben.
<G-vec00383-002-s028><die.absterben><en> This process allows the plant to focus as much energy as possible on making a great product, rather than wasting energy maintaining leaves that may die anyway.
<G-vec00383-002-s029><die.absterben><de> Sie entbehrt dem notwendigen Lebenssaft und wird absterben.
<G-vec00383-002-s029><die.absterben><en> It misses the necessary life sap and will die.
<G-vec00383-002-s030><die.absterben><de> Der Rosettenstrauch muss an der Oberfläche bleiben, da er sonst absterben kann.
<G-vec00383-002-s030><die.absterben><en> Rosette bush must remain on the surface, otherwise it may die.
<G-vec00383-002-s031><die.absterben><de> Der Wirkstoff induziert einen Prozess namens Lipolyse, bei dem die Fettzellen reißen und absterben.
<G-vec00383-002-s031><die.absterben><en> The active ingredient induces a process called lipolysis, where the fat cells rupture and die.
<G-vec00383-002-s032><die.absterben><de> Es bleiben somit noch gewisse Reste der Ungleichheit bestehen, die noch nicht absterben konnten.
<G-vec00383-002-s032><die.absterben><en> There remain, therefore still some remnants of inequality which could not yet die off.
<G-vec00383-002-s033><die.absterben><de> Dies bewirkt, dass sie absterben und die Infektion verschwindet.
<G-vec00383-002-s033><die.absterben><en> This causes them to die out, and then the infection goes away.
<G-vec00383-002-s034><die.absterben><de> Diejenigen, die diese Tiere auf dem Bauernhof haben, wissen, dass es eine gefährliche Kaninchenerkrankung gibt - die Myxomatose, bei der alle Tiere absterben, wenn Sie nicht die erforderlichen Maßnahmen ergreifen.
<G-vec00383-002-s034><die.absterben><en> Those who have these animals in the household know that there is a dangerous disease of rabbits - myxomatosis, from which all the livestock may die out if the necessary measures are not taken.
<G-vec00383-002-s035><die.absterben><de> Freie Radikale greifen die Körperzellen an, machen das Fett ranzig, schädigen Proteine und zerstören deren genetischen Code, bis die Funktion unserer Zellen so eingeschränkt ist, dass diese aufgeben und absterben.
<G-vec00383-002-s035><die.absterben><en> Free radicals attack our body's cells, damage our fat cells and proteins and destroy their genetic code until our cells' functions are so restricted that they give up and die.
<G-vec00383-002-s036><die.absterben><de> Das ist eine Herausforderung, da die Zellen bei Erwärmung absterben.
<G-vec00383-002-s036><die.absterben><en> Here the challenge is that the cells die if they thaw out.
<G-vec00383-002-s037><die.absterben><de> Komplikationen In den Stadien II und III kann das freie Knochenstück absterben, sich also nicht mit dem übrigen Sprungbein vereinigen.
<G-vec00383-002-s037><die.absterben><en> Complications In stages II and III, the free piece of bone can die, so it can not be united with the rest of the talus.
