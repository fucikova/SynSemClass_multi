<G-vec00001-001-s190><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre, und stelle mir hier bereit sieben Farren und sieben Widder.
<G-vec00001-001-s190><build.bauen><en> 1 And Balaam said to Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00001-001-s191><build.bauen><de> 3 Und Salomo sandte zu Huram, dem König von Tyrus, und ließ ihm sagen: So wie du meinem Vater David getan und ihm Zedern gesandt hast, daß er sich ein Haus baue, um darin zu wohnen, so tue auch mir.
<G-vec00001-001-s191><build.bauen><en> 3 And Solomon sent to Huram king of Tyre, saying, As thou didst deal with David my father, and didst send him cedars to build him a house to dwell therein so do for me.
<G-vec00001-001-s192><build.bauen><de> Baue ein Modell eines deutschen Raketenwerfers aus dem Zweiten Weltkrieg.
<G-vec00001-001-s192><build.bauen><en> Build a model of a German rocket launcher from World War II.
<G-vec00001-001-s193><build.bauen><de> füge diese Karten deinem Arsenal hinzu und baue dein perfektes Deck.
<G-vec00001-001-s193><build.bauen><en> add these cards to your arsenal and build your perfect deck.
<G-vec00001-001-s194><build.bauen><de> und baue dem HERRN, deinem Gott, oben auf der Höhe dieses Felsens einen Altar und rüste ihn zu und nimm den andern Farren und opfere ein Brandopfer mit dem Holz des Ascherabildes, das du abgehauen hast.
<G-vec00001-001-s194><build.bauen><en> And build an altar to the LORD your God upon the top of this rock, in an orderly manner, and take the second bullock, and offer it upon it as a burnt offering with the wood of the grove which you shall cut down.
<G-vec00001-001-s195><build.bauen><de> Baue deinen Turm höher und höher und pass auf dass er nicht einstürzt.
<G-vec00001-001-s195><build.bauen><en> Build your tower higher and higher and make sure it doesn't collapse.
<G-vec00001-001-s196><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre und schaffe mir her sieben junge Stiere und sieben Widder.
<G-vec00001-001-s196><build.bauen><en> 1 And Balaam said unto Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00001-001-s197><build.bauen><de> Baue die ökologischste Stadt der Welt.
<G-vec00001-001-s197><build.bauen><en> Build the most ecologic city in the world
<G-vec00001-001-s198><build.bauen><de> Ich habe von der Firma PESTAS, welche Holzdominosteine in Österreich herstellt, ein Musterpaket zugeschickt bekommen und vergleiche in diesem Video die Steine mit meinen Dominos und baue ein paar kleine Beispielprojekte.
<G-vec00001-001-s198><build.bauen><en> I received a sample package from the company PESTAS which produces wooden dominoes in Austria. In this video, I compare the dominoes to the ones I frequently use and build up some smaller testing projects.
<G-vec00001-001-s199><build.bauen><de> "Baue die Eisenbahn deiner Träume im Modus ""Train Table"", in dem deine Fantasie sich ohne Rücksicht auf finanziellen oder wertbewerblichen Druck frei entfalten kann."
<G-vec00001-001-s199><build.bauen><en> "Build the model railroad of your dreams in ""Train Table"" mode, where your imagination is free from the pressures of finance or competition."
<G-vec00001-001-s200><build.bauen><de> Baue Tina Goldstein, platziere sie auf dem LEGO Toypad und schicke sie in das Spiel, wo sie mit Aguamenti Rätsel lösen und sich mit Protego vor Gegnern schÃ1⁄4tzen kann.
<G-vec00001-001-s200><build.bauen><en> Build and place the Tina Goldstein minifigure on the LEGO Toy Pad to send her into the game where she can cast Aguamenti to help solve puzzles and Protego to keep her safe from enemies.
<G-vec00001-001-s201><build.bauen><de> Baue die Modelle und setze ihn auf Posten.
<G-vec00001-001-s201><build.bauen><en> Build the models and sit him in position.
<G-vec00001-001-s202><build.bauen><de> Dann baue ich neben der Serienfertigung ein paar ganz besondere Ukulelen mit.
<G-vec00001-001-s202><build.bauen><en> When that happens, I often decide to build some special models.
<G-vec00001-001-s203><build.bauen><de> Erstelle einen Remix von neuen Tracks und baue deine Song-Bibliothek auf, indem du “Burning Down The House” von Talking Heads kaufst.
<G-vec00001-001-s203><build.bauen><en> Remix new tracks and build your song library by purchasing “Burning Down The House” by Talking Heads.
<G-vec00001-001-s204><build.bauen><de> Für jede zehnte Flöte die ich baue pflanze ich hier einen kleinen Red Cedar Baum.
<G-vec00001-001-s204><build.bauen><en> For every tenth flute which I build I plant here a little Red Cedar tree.
<G-vec00001-001-s205><build.bauen><de> Baue deine eigenes Schloss und besiege andere Spieler in taktischen Kämpfen auf einer riesigen Weltkarte.
<G-vec00001-001-s205><build.bauen><en> Build your own castle and defeat other players in tactical fights on a giant world map.
<G-vec00001-001-s206><build.bauen><de> Baue deine Verteidigung und halte sie auf!Mächtige Krieger:Wähle Magier, Paladins oder Barbaren als deine Krieger und befehlige sie auf dem Schlachtfeld.
<G-vec00001-001-s206><build.bauen><en> Build your defense and stop them now! Mighty Warriors: You can choose wizard, paladin or barbarian as your warrior and deploy them to the battlefield.
<G-vec00001-001-s207><build.bauen><de> Baue ein Deck aus dem Standard-Kartenpool um eine bestimmte legendäre Kreatur oder einen Planeswalker herum auf und tritt in Duellen oder Multiplayer-Partien gegen einen oder mehrere Freunde an.
<G-vec00001-001-s207><build.bauen><en> Build a deck around a specific legendary creature or planeswalker from the Standard card pool, and battle against friends in one-on-one or multiplayer free-for-all games.
<G-vec00001-001-s208><build.bauen><de> Baue den Truck, schnall den Fahrer an und bezwinge jedes Hindernis mit den massiven Reifen und dem leistungsstarken Motor.
<G-vec00001-001-s208><build.bauen><en> Build the truck, Schnall to the driver and defeat any obstacle with the massive tires and powerful engine.
<G-vec00179-001-s190><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre, und stelle mir hier bereit sieben Farren und sieben Widder.
<G-vec00179-001-s190><build.bauen><en> 1 And Balaam said to Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00179-001-s191><build.bauen><de> 3 Und Salomo sandte zu Huram, dem König von Tyrus, und ließ ihm sagen: So wie du meinem Vater David getan und ihm Zedern gesandt hast, daß er sich ein Haus baue, um darin zu wohnen, so tue auch mir.
<G-vec00179-001-s191><build.bauen><en> 3 And Solomon sent to Huram king of Tyre, saying, As thou didst deal with David my father, and didst send him cedars to build him a house to dwell therein so do for me.
<G-vec00179-001-s192><build.bauen><de> Baue ein Modell eines deutschen Raketenwerfers aus dem Zweiten Weltkrieg.
<G-vec00179-001-s192><build.bauen><en> Build a model of a German rocket launcher from World War II.
<G-vec00179-001-s193><build.bauen><de> füge diese Karten deinem Arsenal hinzu und baue dein perfektes Deck.
<G-vec00179-001-s193><build.bauen><en> add these cards to your arsenal and build your perfect deck.
<G-vec00179-001-s194><build.bauen><de> und baue dem HERRN, deinem Gott, oben auf der Höhe dieses Felsens einen Altar und rüste ihn zu und nimm den andern Farren und opfere ein Brandopfer mit dem Holz des Ascherabildes, das du abgehauen hast.
<G-vec00179-001-s194><build.bauen><en> And build an altar to the LORD your God upon the top of this rock, in an orderly manner, and take the second bullock, and offer it upon it as a burnt offering with the wood of the grove which you shall cut down.
<G-vec00179-001-s195><build.bauen><de> Baue deinen Turm höher und höher und pass auf dass er nicht einstürzt.
<G-vec00179-001-s195><build.bauen><en> Build your tower higher and higher and make sure it doesn't collapse.
<G-vec00179-001-s196><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre und schaffe mir her sieben junge Stiere und sieben Widder.
<G-vec00179-001-s196><build.bauen><en> 1 And Balaam said unto Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00179-001-s197><build.bauen><de> Baue die ökologischste Stadt der Welt.
<G-vec00179-001-s197><build.bauen><en> Build the most ecologic city in the world
<G-vec00179-001-s198><build.bauen><de> Ich habe von der Firma PESTAS, welche Holzdominosteine in Österreich herstellt, ein Musterpaket zugeschickt bekommen und vergleiche in diesem Video die Steine mit meinen Dominos und baue ein paar kleine Beispielprojekte.
<G-vec00179-001-s198><build.bauen><en> I received a sample package from the company PESTAS which produces wooden dominoes in Austria. In this video, I compare the dominoes to the ones I frequently use and build up some smaller testing projects.
<G-vec00179-001-s199><build.bauen><de> "Baue die Eisenbahn deiner Träume im Modus ""Train Table"", in dem deine Fantasie sich ohne Rücksicht auf finanziellen oder wertbewerblichen Druck frei entfalten kann."
<G-vec00179-001-s199><build.bauen><en> "Build the model railroad of your dreams in ""Train Table"" mode, where your imagination is free from the pressures of finance or competition."
<G-vec00179-001-s200><build.bauen><de> Baue Tina Goldstein, platziere sie auf dem LEGO Toypad und schicke sie in das Spiel, wo sie mit Aguamenti Rätsel lösen und sich mit Protego vor Gegnern schÃ1⁄4tzen kann.
<G-vec00179-001-s200><build.bauen><en> Build and place the Tina Goldstein minifigure on the LEGO Toy Pad to send her into the game where she can cast Aguamenti to help solve puzzles and Protego to keep her safe from enemies.
<G-vec00179-001-s201><build.bauen><de> Baue die Modelle und setze ihn auf Posten.
<G-vec00179-001-s201><build.bauen><en> Build the models and sit him in position.
<G-vec00179-001-s202><build.bauen><de> Dann baue ich neben der Serienfertigung ein paar ganz besondere Ukulelen mit.
<G-vec00179-001-s202><build.bauen><en> When that happens, I often decide to build some special models.
<G-vec00179-001-s203><build.bauen><de> Erstelle einen Remix von neuen Tracks und baue deine Song-Bibliothek auf, indem du “Burning Down The House” von Talking Heads kaufst.
<G-vec00179-001-s203><build.bauen><en> Remix new tracks and build your song library by purchasing “Burning Down The House” by Talking Heads.
<G-vec00179-001-s204><build.bauen><de> Für jede zehnte Flöte die ich baue pflanze ich hier einen kleinen Red Cedar Baum.
<G-vec00179-001-s204><build.bauen><en> For every tenth flute which I build I plant here a little Red Cedar tree.
<G-vec00179-001-s205><build.bauen><de> Baue deine eigenes Schloss und besiege andere Spieler in taktischen Kämpfen auf einer riesigen Weltkarte.
<G-vec00179-001-s205><build.bauen><en> Build your own castle and defeat other players in tactical fights on a giant world map.
<G-vec00179-001-s206><build.bauen><de> Baue deine Verteidigung und halte sie auf!Mächtige Krieger:Wähle Magier, Paladins oder Barbaren als deine Krieger und befehlige sie auf dem Schlachtfeld.
<G-vec00179-001-s206><build.bauen><en> Build your defense and stop them now! Mighty Warriors: You can choose wizard, paladin or barbarian as your warrior and deploy them to the battlefield.
<G-vec00179-001-s207><build.bauen><de> Baue ein Deck aus dem Standard-Kartenpool um eine bestimmte legendäre Kreatur oder einen Planeswalker herum auf und tritt in Duellen oder Multiplayer-Partien gegen einen oder mehrere Freunde an.
<G-vec00179-001-s207><build.bauen><en> Build a deck around a specific legendary creature or planeswalker from the Standard card pool, and battle against friends in one-on-one or multiplayer free-for-all games.
<G-vec00179-001-s208><build.bauen><de> Baue den Truck, schnall den Fahrer an und bezwinge jedes Hindernis mit den massiven Reifen und dem leistungsstarken Motor.
<G-vec00179-001-s208><build.bauen><en> Build the truck, Schnall to the driver and defeat any obstacle with the massive tires and powerful engine.
<G-vec00001-001-s107><construct.bauen><de> Baue zuerst die wichtigsten Gebäude - Bauernhöfe, Bergwerke und Häuser, um genug Nahrung, Eisen und Gold zu erwirtschaften.
<G-vec00001-001-s107><construct.bauen><en> First of all construct necessary buildings – farms, mines and houses to receive enough food, iron and gold.
<G-vec00001-001-s108><construct.bauen><de> Baue in Dungeons II für PS4 ein Reich der Finsternis auf.
<G-vec00001-001-s108><construct.bauen><en> Construct a dark empire in Dungeons II on PS4.
<G-vec00001-001-s109><construct.bauen><de> Baue das weltbekannte Kolosseum und erfahre mehr über uralten Anekdoten in diesem schnellen Zeitmanagementspiel.
<G-vec00001-001-s109><construct.bauen><en> Construct the iconic Roman Colosseum and learn ancient anecdotes in this fast-paced Time Management game.
<G-vec00001-001-s110><construct.bauen><de> Baue ihn auf Felder, auf denen Vulkangold, der rote Rohstoff, zu finden ist.
<G-vec00001-001-s110><construct.bauen><en> Construct it on squares where vulcanic gold, the red ressource, is found.
<G-vec00001-001-s111><construct.bauen><de> Schalte über 300 einzigartige und coole Gebäude frei, baue und verbessere sie, halte deine Bürger bei Laune, schaffe Arbeitsplätze und sammle Geld von deinen Gebäuden.
<G-vec00001-001-s111><construct.bauen><en> Unlock over 300 unique and cool buildings, construct and upgrade them, keep your citizens happy, create jobs and collect cash from your buildings.
<G-vec00179-001-s107><construct.bauen><de> Baue zuerst die wichtigsten Gebäude - Bauernhöfe, Bergwerke und Häuser, um genug Nahrung, Eisen und Gold zu erwirtschaften.
<G-vec00179-001-s107><construct.bauen><en> First of all construct necessary buildings – farms, mines and houses to receive enough food, iron and gold.
<G-vec00179-001-s108><construct.bauen><de> Baue in Dungeons II für PS4 ein Reich der Finsternis auf.
<G-vec00179-001-s108><construct.bauen><en> Construct a dark empire in Dungeons II on PS4.
<G-vec00179-001-s109><construct.bauen><de> Baue das weltbekannte Kolosseum und erfahre mehr über uralten Anekdoten in diesem schnellen Zeitmanagementspiel.
<G-vec00179-001-s109><construct.bauen><en> Construct the iconic Roman Colosseum and learn ancient anecdotes in this fast-paced Time Management game.
<G-vec00179-001-s110><construct.bauen><de> Baue ihn auf Felder, auf denen Vulkangold, der rote Rohstoff, zu finden ist.
<G-vec00179-001-s110><construct.bauen><en> Construct it on squares where vulcanic gold, the red ressource, is found.
<G-vec00179-001-s111><construct.bauen><de> Schalte über 300 einzigartige und coole Gebäude frei, baue und verbessere sie, halte deine Bürger bei Laune, schaffe Arbeitsplätze und sammle Geld von deinen Gebäuden.
<G-vec00179-001-s111><construct.bauen><en> Unlock over 300 unique and cool buildings, construct and upgrade them, keep your citizens happy, create jobs and collect cash from your buildings.
<G-vec00001-001-s069><assemble.bauen><de> Informationen Format 230x230x100 / 160x160x100 / 160x300x100mm, Dieses Set ist einfach zusammen zu bauen.
<G-vec00001-001-s069><assemble.bauen><en> Information Format 230x230x100 / 160x160x100 / 160x300x100mm, This set is easy to assemble.
<G-vec00001-001-s070><assemble.bauen><de> Wir liefern die Rotationshacke als ein kompletter Satz, aus dem man vier Arbeitsbreiten der Hacke bauen kann - 16, 22, 32 und 38 cm; es geht eigentlich um die Breite der Abdeckung.
<G-vec00001-001-s070><assemble.bauen><en> RP-T2/S is delivered as a complete set, you can assemble four working width of the rotary hoe - 16, 22, 32 and 38 cm, which is in fact width of the cover.
<G-vec00001-001-s071><assemble.bauen><de> Die geniale Selbstbaulösung für Ihren Montagetisch: WEINMANN liefert die Technik, Sie bauen den Tisch (VarioTec).
<G-vec00001-001-s071><assemble.bauen><en> The ideal self assembly solution for your production: WEINMANN provides the technology - you assemble the table (VarioTec).
<G-vec00001-001-s072><assemble.bauen><de> Montagetisch als Selbstbaulösung: WEINMANN liefert die Technik, Sie bauen den Tisch (VarioTec).
<G-vec00001-001-s072><assemble.bauen><en> The ideal self assembly solution for your production: WEINMANN provides the technology - you assemble the table (VarioTec).
<G-vec00001-001-s073><assemble.bauen><de> Wir liefern RP-T2/S als ein kompletter Satz, aus dem man vier Arbeitsbreiten der Hacke bauen kann - 16, 22, 32 und 38 cm, es geht eigentlich um die Breite der Abdeckung.
<G-vec00001-001-s073><assemble.bauen><en> RP-T2/S is delivered as a complete set, you can assemble four working width of the rotary hoe - 16, 22, 32 and 38 cm, which is in fact width of the cover.
<G-vec00001-001-s074><assemble.bauen><de> Kuala Lumpur - DRB-HICOM Berhad und die Volkswagen AG, Europas größter Autobauer, werden gemeinsam 1 Milliarde Ringgit (etwa 250 MIllionen Euro) in den nächsten sechs Jahren investieren, um künftig VW Autos in Malaysia zu bauen.
<G-vec00001-001-s074><assemble.bauen><en> Kuala Lumpur - DRB-HICOM Bhd (1619)and Volkswagen AG, the largest carmaker in Europe, will collectively invest close to RM1 billion over the next five to six years mainly to set up the infrastructure to assemble VW vehicles in Malaysia.
<G-vec00001-001-s075><assemble.bauen><de> 'Wir besitzen nun ein neues Set an Bausteinen, aus denen wir viele verschiedene neue quasikristalline Strukturen bauen können', erklären die TUM Physiker.
<G-vec00001-001-s075><assemble.bauen><en> 'We now have a new set of building blocks that we can use to assemble many different new quasicrystalline structures.
<G-vec00001-001-s076><assemble.bauen><de> Guncrafter - es ist ein großer Designer für Android, die allen Fans von Minecraft ansprechen wird, sowie diejenigen, die zu erfinden und bauen ihre eigenen Produkte lieben.
<G-vec00001-001-s076><assemble.bauen><en> Guncrafter - it's a great designer for Android, which will appeal to all fans of Minecraft, as well as those who love to invent and assemble their own products.
<G-vec00001-001-s077><assemble.bauen><de> Werde zum ninja und lernt neue tricks des Spinjitzu-set Nya - Meister des Spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s077><assemble.bauen><en> Become a ninja and learn the new tricks of Spinjitzu with the set Nya - Master of Spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s078><assemble.bauen><de> Werde zum ninja und lernt neue tricks des Spinjitzu mit dem satz von zane-meister des spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s078><assemble.bauen><en> Become a ninja and learn the new tricks of Spinjitzu set, jay-master of spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s079><assemble.bauen><de> Das Unternehmen wird jede Stunde 30 Autos bauen, früher waren es 25 bis 27 Autos pro Stunde.
<G-vec00001-001-s079><assemble.bauen><en> Now the enterprise will assemble 30 cars every hour, whereas previously this figure was around 25-27 cars per hour.
<G-vec00001-001-s080><assemble.bauen><de> Bringen sie ihre technik Spinjitzu auf einer anderen ebene mit dem set von Kai - Meister des Spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s080><assemble.bauen><en> Bring your technical Spinjitzu on another level with the set of Kai - a Master of Spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s081><assemble.bauen><de> """Ich konstruiere komplette Fahrzeuge mit geringen Toleranzen von Grund auf selbst und wir bauen die Fahrzeuge mit einem vierköpfigen Team zusammen"", sagt Palatov."
<G-vec00001-001-s081><assemble.bauen><en> """I design complete cars, featuring tight tolerances, from scratch by myself, and we assemble the cars with a team of four,"" Palatov says."
<G-vec00001-001-s082><assemble.bauen><de> Das set enthält auch das auto des Skorpions mit zangen und schwanz möbel, mehr eine gasse mit einer mauer mit fenster und schiebedach, rampe mit doppeltem anschluss, großes spinnennetz aus draht, spinnennetz, flexibel und ein katapult bauen.
<G-vec00001-001-s082><assemble.bauen><en> The set also contains the cars of the Scorpion with pincers and a tail mobile, more an alley with a wall with window opening, ramp, dual-link, large spider web, thread of spider's web, is flexible and a catapult to assemble.
<G-vec00001-001-s083><assemble.bauen><de> Dennoch, wie Ziegelsteine gebraucht werden können, um viele unterschiedliche Strukturen zu bauen, sind die Tubulin-Untergruppen in den Mikrotubuli der Zellen untereinander identisch.
<G-vec00001-001-s083><assemble.bauen><en> Nevertheless, like bricks that can be used to assemble many different structures, the tubulin subunits in the cell's microtubules are identical to one another.
<G-vec00001-001-s209><build.bauen><de> Wir nutzen, wo es möglich ist, öffentliche Förderprogramme, um bezahlbare Wohnungen zu bauen.
<G-vec00001-001-s209><build.bauen><en> Wherever possible, we take advantage of public subsidy programs to build affordable housing.
<G-vec00001-001-s210><build.bauen><de> Ob Sie eine Offshore Plattform bauen oder an einem Raffinerie Shutdown arbeiten, sie kämpfen täglich damit die Ausfallzeiten zu reduzieren.
<G-vec00001-001-s210><build.bauen><en> Whether you build an offshore platform or you work on a refinery shutdown, you fight daily for reducing operational downtime.
<G-vec00001-001-s211><build.bauen><de> Tage später begann das Gerücht die Runde zu machen, dass der Hexer von Bargota, wie sie Juanes nannten, eines Nachts den Teufel angerufen habe und sich bösartiger Geister bedient habe, um in einer einzigen Nacht ein Haus zu bauen.
<G-vec00001-001-s211><build.bauen><en> A few days later rumours spread that the?Brujo de Bargota?, which was Juanes' nickname, had invoked the Devil one night and had made use of evil genies to build his house in just one night.
<G-vec00001-001-s212><build.bauen><de> Aus der Zusammenarbeit als Vorzugslieferant mit Volvo Construction Equipment ergeben sich die Möglichkeiten, die operativen Abläufe zu konsolidieren und eine neue Produktionsstätte in Edsberg in Sollentuna zu bauen.
<G-vec00001-001-s212><build.bauen><en> The Preferred Supplier Agreements with Volvo Construction Equipment creates conditions to consolidate operations and build a new production plant in Sollentuna, Sweden.
<G-vec00001-001-s213><build.bauen><de> Es ist geplant, ein weiteres Stockwerk (weitere 90 qm) zu bauen, dann ist die gesamte Wohnfläche würde der Fläche von 180 qm werden Es ist ein wunderbarer Blick aufs Meer vom Haus.
<G-vec00001-001-s213><build.bauen><en> It is planned to build one more storey (additional 90 sq m), then the total living area would be of the surface of 180 sq m. There is a marvellous sea-view from the property.
<G-vec00001-001-s214><build.bauen><de> Nur 2 km von der historischen Stadt Alcobaca und 10 km von den Stränden (Nazare und Sao Martinho do Porto) entfernt, hat dieses Grundstück eine Gesamtfläche von 1.077 m2, und es ist erlaubt, 60% der Gesamtgröße zu bauen.
<G-vec00001-001-s214><build.bauen><en> Only 2 kms from the historical town of Alcobaca and 10 kms from the beaches (Nazare and Sao Martinho do Porto) This plot of land has a total of 1.077m2, and it is allowed to build 60% of the total size.
<G-vec00001-001-s215><build.bauen><de> Wir mögen Fehler begehen, denn wir bauen eine Welt mit gebrochenen Strohhalmen.
<G-vec00001-001-s215><build.bauen><en> We may err, for we build a world with broken straws.
<G-vec00001-001-s216><build.bauen><de> Alles in allem werden die Habs benötigen, um ihre Ein Spiel gegen Calgary zu bringen, wenn sie sich auf letzten Samstag den Sieg über die Flyers bauen wollen.
<G-vec00001-001-s216><build.bauen><en> All in all, the Habs will need to bring their A game against Calgary if they want to build on last Saturday’s win over the Flyers.
<G-vec00001-001-s217><build.bauen><de> Genug Platz, um einen Pool zu bauen.
<G-vec00001-001-s217><build.bauen><en> Enough space to build a pool.
<G-vec00001-001-s218><build.bauen><de> Und das ist richtig – er ließ sie sogar nach Rothschilds Kolonien in Palästina auswandern,, ihr Geld mitnehmen und erlaubte ihnen, Waren aus Deutschland zu importieren, um die Kolonien zu bauen – und hatte einen VERTRAG MIT DEN ZIONISTEN DIESBEZÜGLICH: DAS HAAVARA TRANSFER AGREEMENT.
<G-vec00001-001-s218><build.bauen><en> And that ́s right – he even let them take their money with them and allowed them to import goods from Germany to build Rothschild ́s colonies in Palestine – and THE ZIONISTS HAD A TREATY WITH THE ZIONISTS ON THIS MATTER: THE HAAVARA TRANSFER AGREEMENT.
<G-vec00001-001-s219><build.bauen><de> Das BAS-Programm bietet Personen mit einem Abschluss oder eine gleichwertige Gelegenheit auf die grundlegenden Fähigkeiten, die durch durch die Vollendung der oberen Abteilung Kurs in Management- und Führungspraktiken ihre Associate-Studiengänge erreicht zu bauen.
<G-vec00001-001-s219><build.bauen><en> The BAS program provides individuals with an associate's degree or equivalent the opportunity to build upon the foundational skills attained through their associate's degree programs by completing upper-division coursework in management and leadership practices.
<G-vec00001-001-s220><build.bauen><de> Der New Baghdad-Tisch ist schwierig zu bauen, ein filigranes Puzzle in Form eines Stadtplans.
<G-vec00001-001-s220><build.bauen><en> The New Baghdad table is difficult to build, a delicate puzzle in the shape of the city map.
<G-vec00001-001-s221><build.bauen><de> Bauen Sie eine tiefere Bräune auf, indem Sie es täglich erneut auftragen, bis die gewünschte Farbtiefe erreicht ist.
<G-vec00001-001-s221><build.bauen><en> Build a deeper tan by reapplying daily until the desired depth is achieved.
<G-vec00001-001-s222><build.bauen><de> "Meister CVV sagte: ""Ich weiß, dass ihr diese Brücke nicht bauen könnt, weil ihr wie vom Denkvermögen eines Moskitos begrenzt werdet."
<G-vec00001-001-s222><build.bauen><en> "Master CVV said: ""I know that you cannot build this bridge, because you are confined as by the mind of a mosquito."
<G-vec00001-001-s223><build.bauen><de> Die Wahl hängt davon ab, was Sie vorhaben, ein Haus zu bauen: Telefonzentrale oder quadratisch Protokoll.
<G-vec00001-001-s223><build.bauen><en> Their choice depends on what you are going to build a house: switchboard or square log.
<G-vec00001-001-s224><build.bauen><de> Karl der Große gibt seinem Sohn Louis le Débonnaire den Auftrag, auf der Insel Antros einen Leuchtturm zu bauen.
<G-vec00001-001-s224><build.bauen><en> 9th C Charlemagne asks his son Louis le Débonnaire to build a first tower on the island of Antros.
<G-vec00001-001-s225><build.bauen><de> Als mir dann ein Freund von den abenteuerlichen Geschichten die sein Vater während des zweiten Weltkrieges mit dieser Maschine erlebt hat erzählte, stand für mich fest: Dieses Flugzeug mußt du bauen.
<G-vec00001-001-s225><build.bauen><en> When a friend told me about his father's adventures during World War II flying this aircraft I was hooked: I must build this machine.
<G-vec00001-001-s226><build.bauen><de> Um den Feind zu begegnen, wir brauchen, um zu bauen und sicher stärken Sie Ihre eigene Burg.
<G-vec00001-001-s226><build.bauen><en> To counter the enemy, we need to build and safely strengthen your own castle.
<G-vec00001-001-s227><build.bauen><de> Während der Kinderführung erkunden wir die Ausstellung und bauen anschließend unsere eigenen Stadtminiaturen.
<G-vec00001-001-s227><build.bauen><en> We will explore their ideas during the guided tour and build our own models afterwards.
<G-vec00179-001-s209><build.bauen><de> Wir nutzen, wo es möglich ist, öffentliche Förderprogramme, um bezahlbare Wohnungen zu bauen.
<G-vec00179-001-s209><build.bauen><en> Wherever possible, we take advantage of public subsidy programs to build affordable housing.
<G-vec00179-001-s210><build.bauen><de> Ob Sie eine Offshore Plattform bauen oder an einem Raffinerie Shutdown arbeiten, sie kämpfen täglich damit die Ausfallzeiten zu reduzieren.
<G-vec00179-001-s210><build.bauen><en> Whether you build an offshore platform or you work on a refinery shutdown, you fight daily for reducing operational downtime.
<G-vec00179-001-s211><build.bauen><de> Tage später begann das Gerücht die Runde zu machen, dass der Hexer von Bargota, wie sie Juanes nannten, eines Nachts den Teufel angerufen habe und sich bösartiger Geister bedient habe, um in einer einzigen Nacht ein Haus zu bauen.
<G-vec00179-001-s211><build.bauen><en> A few days later rumours spread that the?Brujo de Bargota?, which was Juanes' nickname, had invoked the Devil one night and had made use of evil genies to build his house in just one night.
<G-vec00179-001-s212><build.bauen><de> Aus der Zusammenarbeit als Vorzugslieferant mit Volvo Construction Equipment ergeben sich die Möglichkeiten, die operativen Abläufe zu konsolidieren und eine neue Produktionsstätte in Edsberg in Sollentuna zu bauen.
<G-vec00179-001-s212><build.bauen><en> The Preferred Supplier Agreements with Volvo Construction Equipment creates conditions to consolidate operations and build a new production plant in Sollentuna, Sweden.
<G-vec00179-001-s213><build.bauen><de> Es ist geplant, ein weiteres Stockwerk (weitere 90 qm) zu bauen, dann ist die gesamte Wohnfläche würde der Fläche von 180 qm werden Es ist ein wunderbarer Blick aufs Meer vom Haus.
<G-vec00179-001-s213><build.bauen><en> It is planned to build one more storey (additional 90 sq m), then the total living area would be of the surface of 180 sq m. There is a marvellous sea-view from the property.
<G-vec00179-001-s214><build.bauen><de> Nur 2 km von der historischen Stadt Alcobaca und 10 km von den Stränden (Nazare und Sao Martinho do Porto) entfernt, hat dieses Grundstück eine Gesamtfläche von 1.077 m2, und es ist erlaubt, 60% der Gesamtgröße zu bauen.
<G-vec00179-001-s214><build.bauen><en> Only 2 kms from the historical town of Alcobaca and 10 kms from the beaches (Nazare and Sao Martinho do Porto) This plot of land has a total of 1.077m2, and it is allowed to build 60% of the total size.
<G-vec00179-001-s215><build.bauen><de> Wir mögen Fehler begehen, denn wir bauen eine Welt mit gebrochenen Strohhalmen.
<G-vec00179-001-s215><build.bauen><en> We may err, for we build a world with broken straws.
<G-vec00179-001-s216><build.bauen><de> Alles in allem werden die Habs benötigen, um ihre Ein Spiel gegen Calgary zu bringen, wenn sie sich auf letzten Samstag den Sieg über die Flyers bauen wollen.
<G-vec00179-001-s216><build.bauen><en> All in all, the Habs will need to bring their A game against Calgary if they want to build on last Saturday’s win over the Flyers.
<G-vec00179-001-s217><build.bauen><de> Genug Platz, um einen Pool zu bauen.
<G-vec00179-001-s217><build.bauen><en> Enough space to build a pool.
<G-vec00179-001-s218><build.bauen><de> Und das ist richtig – er ließ sie sogar nach Rothschilds Kolonien in Palästina auswandern,, ihr Geld mitnehmen und erlaubte ihnen, Waren aus Deutschland zu importieren, um die Kolonien zu bauen – und hatte einen VERTRAG MIT DEN ZIONISTEN DIESBEZÜGLICH: DAS HAAVARA TRANSFER AGREEMENT.
<G-vec00179-001-s218><build.bauen><en> And that ́s right – he even let them take their money with them and allowed them to import goods from Germany to build Rothschild ́s colonies in Palestine – and THE ZIONISTS HAD A TREATY WITH THE ZIONISTS ON THIS MATTER: THE HAAVARA TRANSFER AGREEMENT.
<G-vec00179-001-s219><build.bauen><de> Das BAS-Programm bietet Personen mit einem Abschluss oder eine gleichwertige Gelegenheit auf die grundlegenden Fähigkeiten, die durch durch die Vollendung der oberen Abteilung Kurs in Management- und Führungspraktiken ihre Associate-Studiengänge erreicht zu bauen.
<G-vec00179-001-s219><build.bauen><en> The BAS program provides individuals with an associate's degree or equivalent the opportunity to build upon the foundational skills attained through their associate's degree programs by completing upper-division coursework in management and leadership practices.
<G-vec00179-001-s220><build.bauen><de> Der New Baghdad-Tisch ist schwierig zu bauen, ein filigranes Puzzle in Form eines Stadtplans.
<G-vec00179-001-s220><build.bauen><en> The New Baghdad table is difficult to build, a delicate puzzle in the shape of the city map.
<G-vec00179-001-s221><build.bauen><de> Bauen Sie eine tiefere Bräune auf, indem Sie es täglich erneut auftragen, bis die gewünschte Farbtiefe erreicht ist.
<G-vec00179-001-s221><build.bauen><en> Build a deeper tan by reapplying daily until the desired depth is achieved.
<G-vec00179-001-s222><build.bauen><de> "Meister CVV sagte: ""Ich weiß, dass ihr diese Brücke nicht bauen könnt, weil ihr wie vom Denkvermögen eines Moskitos begrenzt werdet."
<G-vec00179-001-s222><build.bauen><en> "Master CVV said: ""I know that you cannot build this bridge, because you are confined as by the mind of a mosquito."
<G-vec00179-001-s223><build.bauen><de> Die Wahl hängt davon ab, was Sie vorhaben, ein Haus zu bauen: Telefonzentrale oder quadratisch Protokoll.
<G-vec00179-001-s223><build.bauen><en> Their choice depends on what you are going to build a house: switchboard or square log.
<G-vec00179-001-s224><build.bauen><de> Karl der Große gibt seinem Sohn Louis le Débonnaire den Auftrag, auf der Insel Antros einen Leuchtturm zu bauen.
<G-vec00179-001-s224><build.bauen><en> 9th C Charlemagne asks his son Louis le Débonnaire to build a first tower on the island of Antros.
<G-vec00179-001-s225><build.bauen><de> Als mir dann ein Freund von den abenteuerlichen Geschichten die sein Vater während des zweiten Weltkrieges mit dieser Maschine erlebt hat erzählte, stand für mich fest: Dieses Flugzeug mußt du bauen.
<G-vec00179-001-s225><build.bauen><en> When a friend told me about his father's adventures during World War II flying this aircraft I was hooked: I must build this machine.
<G-vec00179-001-s226><build.bauen><de> Um den Feind zu begegnen, wir brauchen, um zu bauen und sicher stärken Sie Ihre eigene Burg.
<G-vec00179-001-s226><build.bauen><en> To counter the enemy, we need to build and safely strengthen your own castle.
<G-vec00179-001-s227><build.bauen><de> Während der Kinderführung erkunden wir die Ausstellung und bauen anschließend unsere eigenen Stadtminiaturen.
<G-vec00179-001-s227><build.bauen><en> We will explore their ideas during the guided tour and build our own models afterwards.
<G-vec00001-001-s112><construct.bauen><de> Es ist ideal für die gewerbliche Entwicklung, da es eine Bauerlaubnis für kommerzielles Gebäude gibt, mit dem Sie ein Hotel mit bis zu 2,600 m² bauen können.
<G-vec00001-001-s112><construct.bauen><en> It is ideal for professional development as there is a high commercial building ratio, which allows you to construct a hotel of up to 2,600 m².
<G-vec00001-001-s113><construct.bauen><de> Präzisiert, dass die Investition plan mittelfristig Brünett“ und dass die Schiffe Teil von eigener Business „Than Shipping 2013 sind, die erst PCTC macht, die die Gesellschaft entschieden hat, nach dem Konkurs von Lehman Brothers in 2008 zu bauen, hat NYK erklärt, dass eine Erhöhung von der Bewerbung von PCTC und dass die vier neuen Schiffe Post in der lage in den aus panama Kanal einmal zu durchreisen dass vorherwerden Einheit sein wird seine Erweiterung im Herbst von 2014 ergänzt sieht.
<G-vec00001-001-s113><construct.bauen><en> Specifying that the investment takes part of own in the mid term business plan “Blackberries Than Shipping 2013” and that the ships are the first PCTC that the company has decided to construct after the failure of Lehman Brothers in 2008, NYK has explained that it previews a rise of the question of PCTC employment and that the four new ships will be unit post-Panamax in a position to journeying once in the Panamanian channel that will be completed its increase in the autumn of 2014.
<G-vec00001-001-s114><construct.bauen><de> Mit TrySim Lite können Sie Anlagen beliebiger Größe bauen und steuern.
<G-vec00001-001-s114><construct.bauen><en> With TrySim Lite you can construct and control machines of any size.
<G-vec00001-001-s115><construct.bauen><de> Dies deutet darauf hin, dass Ihr Körper kann optimal funktioniert Fett zu schmelzen und Muskelgewebe aller Zeiten zu bauen, wenn Sie trainieren.
<G-vec00001-001-s115><construct.bauen><en> This indicates that your body can jobs optimum to shed fat and also construct muscle mass all time when you are exercising.
<G-vec00001-001-s116><construct.bauen><de> Die crocieristico amerikanische Gruppe Carnival hat Corporation ein Abkommen mit der Regierung von Bahamas von einem neuen Kai im Hafen von Half Moon Cay von der kleinen Insel von Little und gekennzeichnet San Salvador, um zwei neue hafen Infrastrukturen für die Kreuzfahrten zu bauen, das bahamense vor von der Inselgruppe abreist, Bahamainseln die die Durchführung von einer neuen Zwischenlandung im südlichen Teil von der Insel von Grand vorhersieht.
<G-vec00001-001-s116><construct.bauen><en> The crocieristico group American Carnival Corporation has signed an agreement with the government of Bahamas in order to construct two new harbour infrastructures for the cruises that the realization of a new port of call in the southern part of the island of Grand Bahamas previews and of a new dock in the port of Half Moon Cay of the small island of Little San Salvador that takes part of the archipelago bahamense.
<G-vec00001-001-s117><construct.bauen><de> "Die zu assoziieren Unternehmen sind deswegen sehr sehr viel machen, eine konkrete Gelegenheit sich eine Professionalität bauen"", dass sie und dies läuft zu der Suche von den technologisch vorbereitet Managern repräsentieren den erst Schritt von einem bestimmten gestaltungs Kurs sind zu einer optimalen Aufwendung zu gelangen."
<G-vec00001-001-s117><construct.bauen><en> "For this the companies associated are very many to MAKE that they technologically are on the lookout for prepared managers and these run represent the first step of a formative distance destined to land to an optimal employment, a concrete opportunity in order to construct a professionality""."
<G-vec00001-001-s118><construct.bauen><de> Diese Verbindungen sind feste gesunde Proteine, wenn sie verwendet werden, die Muskelmasse zu bauen.
<G-vec00001-001-s118><construct.bauen><en> These materials are strong healthy proteins when they are used to construct lean muscle mass.
<G-vec00001-001-s119><construct.bauen><de> Er beschloss tatsächlich, es in den Ruinen des alten Stadttheaters zu bauen, das im Bürgerkrieg zerstört worden war.
<G-vec00001-001-s119><construct.bauen><en> He actually decided to construct it inside the ruins of the old Municipal Theatre that had been destroyed in the Civil War.
<G-vec00001-001-s120><construct.bauen><de> "Dazu sagt Peter Jenelten, stellvertretender Group CEO und Leiter Marketing & Sales: „Stadler ist sehr stolz, nicht nur erstmals Züge nach Slowenien liefern zu dürfen, sondern in einer Beschaffung gleich eine aufeinander abgestimmte Reihe unterschiedlicher Fahrzeuge zu bauen: Eine Flotte wie aus einem Guss""."
<G-vec00001-001-s120><construct.bauen><en> "Peter Jenelten, Deputy Group CEO and Head of Marketing & Sales, comments, ""Stadler is very proud not only to be delivering trains to Slovenia for the first time, but also to be able to construct a complete series of different vehicles that have been coordinated with each other to form a uniform fleet."""
<G-vec00001-001-s121><construct.bauen><de> Möglichkeit, ein Schwimmbad zu bauen.
<G-vec00001-001-s121><construct.bauen><en> Possibility to construct a swimming pool.
<G-vec00001-001-s122><construct.bauen><de> „Wir kaufen alle Materialien vor Ort und bauen mit ortsansässigen Handwerkern und den Einwohnern gemeinsam“, erklärt Naeim, der bisher fast immer selbst alle Projekte geleitet hat.
<G-vec00001-001-s122><construct.bauen><en> “We buy all our materials on location and construct it employing local tradespeople and the residents together,” explains Naeim, who until now almost always led the projects personally.
<G-vec00001-001-s123><construct.bauen><de> Wir projektieren, bauen, liefern und installieren den elektromechanischen Maschinensatz für Ihre Wasserkraftanlage.
<G-vec00001-001-s123><construct.bauen><en> We project, construct, deliver and install the electromechanical unit for your hydropower plant.
<G-vec00001-001-s124><construct.bauen><de> Das wäre so, als ob wir ein Haus bauen wollten, ohne zuerst sein Fundament zu legen.
<G-vec00001-001-s124><construct.bauen><en> It will be as though we want to construct a house without laying down first its foundations.
<G-vec00001-001-s125><construct.bauen><de> Das hat der Trans Adriatic gemacht bekannt Rohrleitung, die von dem schweizerischen EGL, von und von teilnimmt Jointventure (42.5%), dem Norweger Statoil, der Deutschen E.ON Ruhrgas (42.5%) (15.0%, dass es) gebildet wird und zu bauen, um die Gasfernleitung zu entwerfen.
<G-vec00001-001-s125><construct.bauen><en> The Trans Adriatic has announced Pipeline, joint venture participated from Swiss EGL (42.5%), from the Norwegian Statoil (42.5%) and from German E.ON Ruhrgas (15.0%) that it is constituted in order to plan and to construct the gas pipeline.
<G-vec00001-001-s126><construct.bauen><de> Die Entscheidung, die Zimmer unter der Erde zu bauen, geht aus der Tatsache hervor, dass das Hofgut Majerija ein Kulturdenkmal ist, das wir mit der neuen Struktur nicht entwerten wollten, sowie aus der Tatsache, dass wir uns buchstäblich zwischen den Wein- und Obstgärten befinden und wir auf diese Weise keinesfalls die wunderschöne natürliche Landschaft beeinflussen.
<G-vec00001-001-s126><construct.bauen><en> They are placed under the herb garden, right by our 300 year old homestead. The decision to construct rooms under the surface of the earth stems from the fact, that Majerija is a cultural monument, whose value we did not wish to reduce with a new building, and due to the fact that we are located literally between vineyards and orchards and, in this way, we do not influence changes of the beautiful, natural landscape.
<G-vec00001-001-s127><construct.bauen><de> Costituire reist sechs Zollfreigebiete in den sardischen strategischen Häfen für see groß jedes Jahr die Herausforderung auf dem möglichen Luxus in Costa Smeralda zu bekräftigen neue Modalitäten von der Aufnahme zu bauen von jen 70% von der weltweiten Flotte von dem Megabyte ab mehrheitlich Yacht, um eine Quote zu wiedererlangen, der jedes Jahr Mittelmeer wie die operative bevorzugt Fläche auswählt.
<G-vec00001-001-s127><construct.bauen><en> Costituire six bonded areas in strategic the Sardinian ports for large the nautical one, to restate every year the challenge on the possible luxury in Costa Smeralda, to construct to new acceptance modality in order to recover a quota leave majority of those 70% of the world-wide fleet of mega yacht that chooses every year the Mediterranean like preferred operating area.
<G-vec00001-001-s128><construct.bauen><de> Hier klicken Blöcke Freisetzung und bauen einen Turm so hoch wie möglich ist.
<G-vec00001-001-s128><construct.bauen><en> Click to release blocks and construct a tower that is as tall as possible.
<G-vec00001-001-s129><construct.bauen><de> Anfang 2001 wurde den männlichen Häftlingen befohlen, in der Frauenabteilung ein Gebäude zu bauen.
<G-vec00001-001-s129><construct.bauen><en> In early 2001, the male detainees were ordered to construct a building in the women's division.
<G-vec00001-001-s130><construct.bauen><de> Im Oktober, nach dem Sturz Horthys und der Machtübernahme der faschistischen Pfeilkreuzler unter Ferenc Szalasi, wurden viele tausend Budapester Juden in Gewaltmärschen an die Grenzen des Reichs getrieben, um Schutzwälle gegen die sowjetischen Panzer zu bauen.
<G-vec00001-001-s130><construct.bauen><en> "After the downfall of the Horthy government in October 1944, and the assumption of power by Ferenc Szalasi and his ""fascist"" Arrow Cross movement, thousands of Budapest Jews were force-marched to the border of the Reich to construct ramparts against Soviet tanks."
<G-vec00179-001-s112><construct.bauen><de> Es ist ideal für die gewerbliche Entwicklung, da es eine Bauerlaubnis für kommerzielles Gebäude gibt, mit dem Sie ein Hotel mit bis zu 2,600 m² bauen können.
<G-vec00179-001-s112><construct.bauen><en> It is ideal for professional development as there is a high commercial building ratio, which allows you to construct a hotel of up to 2,600 m².
<G-vec00179-001-s113><construct.bauen><de> Präzisiert, dass die Investition plan mittelfristig Brünett“ und dass die Schiffe Teil von eigener Business „Than Shipping 2013 sind, die erst PCTC macht, die die Gesellschaft entschieden hat, nach dem Konkurs von Lehman Brothers in 2008 zu bauen, hat NYK erklärt, dass eine Erhöhung von der Bewerbung von PCTC und dass die vier neuen Schiffe Post in der lage in den aus panama Kanal einmal zu durchreisen dass vorherwerden Einheit sein wird seine Erweiterung im Herbst von 2014 ergänzt sieht.
<G-vec00179-001-s113><construct.bauen><en> Specifying that the investment takes part of own in the mid term business plan “Blackberries Than Shipping 2013” and that the ships are the first PCTC that the company has decided to construct after the failure of Lehman Brothers in 2008, NYK has explained that it previews a rise of the question of PCTC employment and that the four new ships will be unit post-Panamax in a position to journeying once in the Panamanian channel that will be completed its increase in the autumn of 2014.
<G-vec00179-001-s114><construct.bauen><de> Mit TrySim Lite können Sie Anlagen beliebiger Größe bauen und steuern.
<G-vec00179-001-s114><construct.bauen><en> With TrySim Lite you can construct and control machines of any size.
<G-vec00179-001-s115><construct.bauen><de> Dies deutet darauf hin, dass Ihr Körper kann optimal funktioniert Fett zu schmelzen und Muskelgewebe aller Zeiten zu bauen, wenn Sie trainieren.
<G-vec00179-001-s115><construct.bauen><en> This indicates that your body can jobs optimum to shed fat and also construct muscle mass all time when you are exercising.
<G-vec00179-001-s116><construct.bauen><de> Die crocieristico amerikanische Gruppe Carnival hat Corporation ein Abkommen mit der Regierung von Bahamas von einem neuen Kai im Hafen von Half Moon Cay von der kleinen Insel von Little und gekennzeichnet San Salvador, um zwei neue hafen Infrastrukturen für die Kreuzfahrten zu bauen, das bahamense vor von der Inselgruppe abreist, Bahamainseln die die Durchführung von einer neuen Zwischenlandung im südlichen Teil von der Insel von Grand vorhersieht.
<G-vec00179-001-s116><construct.bauen><en> The crocieristico group American Carnival Corporation has signed an agreement with the government of Bahamas in order to construct two new harbour infrastructures for the cruises that the realization of a new port of call in the southern part of the island of Grand Bahamas previews and of a new dock in the port of Half Moon Cay of the small island of Little San Salvador that takes part of the archipelago bahamense.
<G-vec00179-001-s117><construct.bauen><de> "Die zu assoziieren Unternehmen sind deswegen sehr sehr viel machen, eine konkrete Gelegenheit sich eine Professionalität bauen"", dass sie und dies läuft zu der Suche von den technologisch vorbereitet Managern repräsentieren den erst Schritt von einem bestimmten gestaltungs Kurs sind zu einer optimalen Aufwendung zu gelangen."
<G-vec00179-001-s117><construct.bauen><en> "For this the companies associated are very many to MAKE that they technologically are on the lookout for prepared managers and these run represent the first step of a formative distance destined to land to an optimal employment, a concrete opportunity in order to construct a professionality""."
<G-vec00179-001-s118><construct.bauen><de> Diese Verbindungen sind feste gesunde Proteine, wenn sie verwendet werden, die Muskelmasse zu bauen.
<G-vec00179-001-s118><construct.bauen><en> These materials are strong healthy proteins when they are used to construct lean muscle mass.
<G-vec00179-001-s119><construct.bauen><de> Er beschloss tatsächlich, es in den Ruinen des alten Stadttheaters zu bauen, das im Bürgerkrieg zerstört worden war.
<G-vec00179-001-s119><construct.bauen><en> He actually decided to construct it inside the ruins of the old Municipal Theatre that had been destroyed in the Civil War.
<G-vec00179-001-s120><construct.bauen><de> "Dazu sagt Peter Jenelten, stellvertretender Group CEO und Leiter Marketing & Sales: „Stadler ist sehr stolz, nicht nur erstmals Züge nach Slowenien liefern zu dürfen, sondern in einer Beschaffung gleich eine aufeinander abgestimmte Reihe unterschiedlicher Fahrzeuge zu bauen: Eine Flotte wie aus einem Guss""."
<G-vec00179-001-s120><construct.bauen><en> "Peter Jenelten, Deputy Group CEO and Head of Marketing & Sales, comments, ""Stadler is very proud not only to be delivering trains to Slovenia for the first time, but also to be able to construct a complete series of different vehicles that have been coordinated with each other to form a uniform fleet."""
<G-vec00179-001-s121><construct.bauen><de> Möglichkeit, ein Schwimmbad zu bauen.
<G-vec00179-001-s121><construct.bauen><en> Possibility to construct a swimming pool.
<G-vec00179-001-s122><construct.bauen><de> „Wir kaufen alle Materialien vor Ort und bauen mit ortsansässigen Handwerkern und den Einwohnern gemeinsam“, erklärt Naeim, der bisher fast immer selbst alle Projekte geleitet hat.
<G-vec00179-001-s122><construct.bauen><en> “We buy all our materials on location and construct it employing local tradespeople and the residents together,” explains Naeim, who until now almost always led the projects personally.
<G-vec00179-001-s123><construct.bauen><de> Wir projektieren, bauen, liefern und installieren den elektromechanischen Maschinensatz für Ihre Wasserkraftanlage.
<G-vec00179-001-s123><construct.bauen><en> We project, construct, deliver and install the electromechanical unit for your hydropower plant.
<G-vec00179-001-s124><construct.bauen><de> Das wäre so, als ob wir ein Haus bauen wollten, ohne zuerst sein Fundament zu legen.
<G-vec00179-001-s124><construct.bauen><en> It will be as though we want to construct a house without laying down first its foundations.
<G-vec00179-001-s125><construct.bauen><de> Das hat der Trans Adriatic gemacht bekannt Rohrleitung, die von dem schweizerischen EGL, von und von teilnimmt Jointventure (42.5%), dem Norweger Statoil, der Deutschen E.ON Ruhrgas (42.5%) (15.0%, dass es) gebildet wird und zu bauen, um die Gasfernleitung zu entwerfen.
<G-vec00179-001-s125><construct.bauen><en> The Trans Adriatic has announced Pipeline, joint venture participated from Swiss EGL (42.5%), from the Norwegian Statoil (42.5%) and from German E.ON Ruhrgas (15.0%) that it is constituted in order to plan and to construct the gas pipeline.
<G-vec00179-001-s126><construct.bauen><de> Die Entscheidung, die Zimmer unter der Erde zu bauen, geht aus der Tatsache hervor, dass das Hofgut Majerija ein Kulturdenkmal ist, das wir mit der neuen Struktur nicht entwerten wollten, sowie aus der Tatsache, dass wir uns buchstäblich zwischen den Wein- und Obstgärten befinden und wir auf diese Weise keinesfalls die wunderschöne natürliche Landschaft beeinflussen.
<G-vec00179-001-s126><construct.bauen><en> They are placed under the herb garden, right by our 300 year old homestead. The decision to construct rooms under the surface of the earth stems from the fact, that Majerija is a cultural monument, whose value we did not wish to reduce with a new building, and due to the fact that we are located literally between vineyards and orchards and, in this way, we do not influence changes of the beautiful, natural landscape.
<G-vec00179-001-s127><construct.bauen><de> Costituire reist sechs Zollfreigebiete in den sardischen strategischen Häfen für see groß jedes Jahr die Herausforderung auf dem möglichen Luxus in Costa Smeralda zu bekräftigen neue Modalitäten von der Aufnahme zu bauen von jen 70% von der weltweiten Flotte von dem Megabyte ab mehrheitlich Yacht, um eine Quote zu wiedererlangen, der jedes Jahr Mittelmeer wie die operative bevorzugt Fläche auswählt.
<G-vec00179-001-s127><construct.bauen><en> Costituire six bonded areas in strategic the Sardinian ports for large the nautical one, to restate every year the challenge on the possible luxury in Costa Smeralda, to construct to new acceptance modality in order to recover a quota leave majority of those 70% of the world-wide fleet of mega yacht that chooses every year the Mediterranean like preferred operating area.
<G-vec00179-001-s128><construct.bauen><de> Hier klicken Blöcke Freisetzung und bauen einen Turm so hoch wie möglich ist.
<G-vec00179-001-s128><construct.bauen><en> Click to release blocks and construct a tower that is as tall as possible.
<G-vec00179-001-s129><construct.bauen><de> Anfang 2001 wurde den männlichen Häftlingen befohlen, in der Frauenabteilung ein Gebäude zu bauen.
<G-vec00179-001-s129><construct.bauen><en> In early 2001, the male detainees were ordered to construct a building in the women's division.
<G-vec00179-001-s130><construct.bauen><de> Im Oktober, nach dem Sturz Horthys und der Machtübernahme der faschistischen Pfeilkreuzler unter Ferenc Szalasi, wurden viele tausend Budapester Juden in Gewaltmärschen an die Grenzen des Reichs getrieben, um Schutzwälle gegen die sowjetischen Panzer zu bauen.
<G-vec00179-001-s130><construct.bauen><en> "After the downfall of the Horthy government in October 1944, and the assumption of power by Ferenc Szalasi and his ""fascist"" Arrow Cross movement, thousands of Budapest Jews were force-marched to the border of the Reich to construct ramparts against Soviet tanks."
<G-vec00001-001-s119><erect.bauen><de> Aber ich finde den Wettlauf falsch, nach dem jede Stadt jetzt ihr Jüdisches Museum bauen muss.
<G-vec00001-001-s119><erect.bauen><en> Even so, I do not agree with the competition to erect a Jewish museum in every city.
<G-vec00001-001-s120><erect.bauen><de> Auch in diesem Geschäftsfeld wollen wir sowohl in der Ostsee als auch in der Nordsee nach dem Abschluss der Genehmigungsplanung der Projekte, diese Windparks finanzieren, bauen und anschließend betreiben.
<G-vec00001-001-s120><erect.bauen><en> In this business field as well, we intend to finance, erect and finally operate these windparks in the Baltic Sea as well as in the North Sea after closing of approval.
<G-vec00001-001-s121><erect.bauen><de> Sie sind gezwungen, von minderwertigem und oftmals schädlichem Material für die Herstellung ihrer Produkte Gebrauch machen, schäbige Wohnungen zu bauen, gesundheitsschädliche Lebensmittel zu konsumieren; unzählige Handlungen zu vollziehen, die dazu gedacht sind, den Konsumenten zu betrügen.
<G-vec00001-001-s121><erect.bauen><en> They are compelled to make use of inferior and often actually injurious materials in the fabrication of their products, to erect wretched dwellings, to put up spoiled foodstuffs and to perpetrate innumerable acts that are planned to cheat the consumer.
<G-vec00001-001-s122><erect.bauen><de> Und dann gibt es noch jene, die Bücher überhaupt nicht lesen, sondern sie nur benutzen, um Skulpturen zu bauen.
<G-vec00001-001-s122><erect.bauen><en> And then there are people who never read books at all, but merely use them to erect sculptures.
<G-vec00001-001-s123><erect.bauen><de> Mit anderen Worten, diese Bauwerke wären heutige Ingenieure NICHT in der Lage auf die Weise zu bauen, wie sie gebaut und aus den Materialien, die benutzt wurden.
<G-vec00001-001-s123><erect.bauen><en> In other words, even present engineers would NOT be able to erect these structures in the manner they were erected and from materials that were used in their construction.
<G-vec00001-001-s124><erect.bauen><de> In Roads of Rome müssen Sie der Hauptfigur in all seinen Missionen helfen: gehen Sie durch barbarische Länder, bauen Straßen, bauen Sie neue Städte auf, bauen Sie Häuser oder Gebäude und erweitern Sie Roms Macht und Einfluss.
<G-vec00001-001-s124><erect.bauen><en> In Roads of Rome you’ll have to help the main character in all his missions: go through barbarian lands, build roads, set up new cities, erect houses or buildings and expand Rome’s power and influence.
<G-vec00001-001-s125><erect.bauen><de> Er schlug vor, das Bauprojekt zu verbessern, sowie dort einen Platz zu bauen und das Denkmal des Volksdichters von Usbekistan und Karakalpakstan, des Helden Usbekistans, Ibroyim Yusupov, aufzustellen.
<G-vec00001-001-s125><erect.bauen><en> He instructed to improve the school project, design a square and erect there a monument to the memory of people's poet of Uzbekistan and Karakalpakstan, Hero of Uzbekistan I.Yusupov.
<G-vec00001-001-s126><erect.bauen><de> Hirth half der Familie Schneider mit Materialien aus verlassenen Häusern, damit sie sich in den Trümmerhaufen von Stuttgart eine Unterkunft bauen konnten.
<G-vec00001-001-s126><erect.bauen><en> Hirth helped the Schneiders to salvage some materials from derelict buildings and erect for themselves a shelter amid the rubble of Stuttgart.
<G-vec00001-001-s127><erect.bauen><de> Oder wir werden zu Isolationisten und bauen wie die USA zu Mexiko und Israel zu Palästina einen Stacheldraht-Wall.
<G-vec00001-001-s127><erect.bauen><en> Or we isolate ourselves and erect walls of barbed wire, as the US has done to Mexico and Israel to Palestine.
<G-vec00001-001-s128><erect.bauen><de> Aus großen Kalkplatten bauen wir uns deshalb einen Ofen, der nach oben und zu den Seiten abgeschlossen ist und lediglich nach vorne Licht und Wärme abstrahlt.
<G-vec00001-001-s128><erect.bauen><en> Out of large limestone plates we therefore erect an oven that is closed at the sides and on top and emits warmth and light only to front.
<G-vec00001-001-s114><establish.bauen><de> Wir entwickeln digitale Lösungen für die Gastronomie, bauen die Vertriebskanäle für unsere eigenen digitalen Lösungen und für die von Startups und betreuen unsere METRO Accelerator Programme.
<G-vec00001-001-s114><establish.bauen><en> We develop digital solutions for the food service industry and establish distribution channels both for our own digital solutions and those created by startups.
<G-vec00001-001-s115><establish.bauen><de> Bauen Sie Ihre Präsenz im Vereinigten Königreich (UK) mit .CO.UK auf - einer der beliebtesten Domainendungen der welt.
<G-vec00001-001-s115><establish.bauen><en> Establish your presence in the United Kingdom (UK) with .CO.UK, one of the most popular domain extension in the world.
<G-vec00001-001-s116><establish.bauen><de> Mit unserem Komplettlösungsangebot zur verfahrenstechnischen und funktionalen Sicherheit bauen Sie in Ihrem gesamten Unternehmen eine nachhaltige Sicherheitskultur auf.
<G-vec00001-001-s116><establish.bauen><en> We provide a comprehensive set of process and functional safety management capabilities to establish a sustainable safety culture.
<G-vec00001-001-s117><establish.bauen><de> Microsoft plant bis 2019, eigene Rechenzentren in der Schweiz zu bauen.
<G-vec00001-001-s117><establish.bauen><en> Microsoft is planning to establish new data centres in Switzerland by 2019.
<G-vec00001-001-s118><establish.bauen><de> 5.Looking schicken Ihre Untersuchung nach und hoffend bauen Sie geschäftliche Beziehungen mit Ihnen für eine lange Zeit auf.
<G-vec00001-001-s118><establish.bauen><en> 5.Looking forward your inquiry and hoping establish business relationship with you for a long time.
<G-vec00001-001-s119><establish.bauen><de> Das Karlsruher Institut für Technologie (KIT) und die SAP SE bauen eine strategische Partnerschaft auf.
<G-vec00001-001-s119><establish.bauen><en> Karlsruhe Institute of Technology (KIT) and SAP SE (NYSE: SAP) establish a strategic partnership.
<G-vec00001-001-s120><establish.bauen><de> Wir bauen und halten Kontakte mit den hervorragenden Organisationen und Personen, die gegen die Klimawendel kämpfen, mit ihrer Hilfe entwickeln wir uns dauernd, ihre Aufsicht macht unsere Arbeit ein Spruchband.
<G-vec00001-001-s120><establish.bauen><en> We establish and maintain close relationships with the most outstanding organizations and individuals that are fighting against Climate Change. With their help we are continuously advancing and their supervision makes our work transparent.
<G-vec00001-001-s121><establish.bauen><de> Auf diese Weise bauen Sie Kontakte zu Gatekeepern und Key Playern in Ihrem jeweiligen Feld auf.
<G-vec00001-001-s121><establish.bauen><en> In this way you establish contacts to gatekeepers and key players in your respective field.
<G-vec00001-001-s122><establish.bauen><de> Sobald die Nahrung gefunden wird, bauen sie ihr Revier auf und bleiben für einige Tage dort, bis die Nahrung knapp wird.
<G-vec00001-001-s122><establish.bauen><en> Once food is found they establish their territory and remain for several days there until it becomes scarce.
<G-vec00001-001-s123><establish.bauen><de> Durch das Zusammenleben auf der Farm bauen die Teilnehmer engen Kontakt zu den Mitarbeitern und der Farmerfamilie auf und lernen viel über die lokale Kultur und Lebensweise.
<G-vec00001-001-s123><establish.bauen><en> By living together on the farm, the participants establish close contact with the employees and the farmer's family and learn a lot about the local culture and way of life.
<G-vec00001-001-s124><establish.bauen><de> Wir bauen für Sie einen Besucherdienst auf, der intern oder auf Wunsch auch extern umgesetzt werden kann.
<G-vec00001-001-s124><establish.bauen><en> We establish a visitors service for you that can be implemented internally or - if requested - externally.
<G-vec00001-001-s125><establish.bauen><de> Sie bauen sich ein Netzwerk auf durch monatliche Jour Fixe, Vorträge und Social Events.
<G-vec00001-001-s125><establish.bauen><en> You will establish a network via monthly meetings, speeched and social events.
<G-vec00001-001-s126><establish.bauen><de> Bauen Sie Glaubwürdigkeit und Vertrauen in Ihr Unternehmen auf.
<G-vec00001-001-s126><establish.bauen><en> Establish credibility and trust for the business.
<G-vec00001-001-s127><establish.bauen><de> Wir bauen strategische Kommunikation auf, organisieren den Kommunikations-Mix und messen den Erfolg Ihrer Kommunikationsmaßnahmen.
<G-vec00001-001-s127><establish.bauen><en> We establish a strategic communication, organize the communications mix and measure the success of your communication measures.
<G-vec00001-001-s128><establish.bauen><de> Sie bauen Wechselwirkungen, Verbindungen zwischen Ursache und Wirkung auf.
<G-vec00001-001-s128><establish.bauen><en> They establish relationships of correspondence, of cause and effect.
<G-vec00001-001-s129><establish.bauen><de> In ausführlichen Gesprächen erstellen wir nicht nur eine Dokumentation und Analyse der bisherigen Behandlungsmaßnahmen, sondern bauen auch eine vertrauensvolle Arzt-Patienten-Beziehung auf, die für die Lösung komplexer medizinischer Probleme so wichtig ist.
<G-vec00001-001-s129><establish.bauen><en> In detailed discussions we not only compile documentation and an analysis of the previous treatment measures but also establish a trusting physician-patient relationship, which is so extremely important in solving complex medical problems.
<G-vec00001-001-s130><establish.bauen><de> Registrieren Sie die perfekte Domain aus der .UK-Familie und bauen Sie Ihre Online-Präsenz im Vereinigten Königreich auf.
<G-vec00001-001-s130><establish.bauen><en> Register the perfect domain from the .UK family and establish your online presence in the United Kingdom.
<G-vec00001-001-s131><establish.bauen><de> Helligkeitskontraste bauen Dramaturgie auf und rücken Wichtiges in den Vordergrund.
<G-vec00001-001-s131><establish.bauen><en> Contrasts in brightness establish drama and place important elements in the foreground.
<G-vec00001-001-s132><establish.bauen><de> La Königspalast von Caserta wurde aus dem 1752 von gemacht Luigi VanvitelliUnd später von seinem Sohn Carlo, im Auftrag von Karl von Bourbon, um es als Drehpunkt des neuen Königreiches von Neapel zu bauen.
<G-vec00001-001-s132><establish.bauen><en> La Palace of Caserta was made from the 1752 from Luigi Vanvitelli, and later by his son Carlo, at the behest of Charles of Bourbon in order to establish it as the fulcrum of the new kingdom of Naples.
<G-vec00001-001-s084><assemble.bauen><de> Bauen Sie ein Team von 4 Personen Bosse zu töten oder von feindlichen Wellen im Survival-Modus Bounce.
<G-vec00001-001-s084><assemble.bauen><en> Assemble a team of 4 people to kill bosses or Bounce from enemy waves in survival mode.
<G-vec00001-001-s085><assemble.bauen><de> Bauen Sie die kleinen Stücke von Glas in einen Leiterrahmen mit Rillen und dann verschweißen die großen Stücke des Rahmens zusammen mit einer Lipidschicht auf der Glasoberfläche die Verwitterung zu verhindern, und Befestigungs.
<G-vec00001-001-s085><assemble.bauen><en> Assemble the small pieces of glass into a lead frame with grooves and then weld the large pieces of the frame together with a lipid coat on the glass surface to prevent the weathering and fixing.
<G-vec00001-001-s086><assemble.bauen><de> Bauen Sie ein Team von Helden unbesiegbar im Spiel Ninja Turtles: Legends und gehen auf die Rettung der Ninja Turtles.
<G-vec00001-001-s086><assemble.bauen><en> Assemble a team of heroes invincible in the game Ninja Turtles: Legends and go to the rescue of the Ninja Turtles.
<G-vec00001-001-s087><assemble.bauen><de> Die Ausführung D wird in drei Teilen geliefert: l Schallwandler l Schallwandlerkabel l Elektronik für Wandmontage Bauen Sie diese Ausführung folgendermaßen zusammen: 1 Sechskantmutter (3) am Schallwandlerrohr lösen 2 Schallwandlerrohr von unten in die Montageöffnung G1 A ein-schieben 3 Sechskantmutter (3) festschrauben (SW 46) 4 Stecker aus Anschlusskopf unten herausziehen und in die Buchse des Schallwandlerrohrs stecken 5 Anschlusskopf auf das Schallwandlerrohr aufstecken.
<G-vec00001-001-s087><assemble.bauen><en> Version D is supplied in three parts: l Transducer l Transducer cable l electronics for wall mounting Assemble the version as follows: 1 Loosen the hexagon nut (3) on the transducer cable 2 Insert the transducer tube from below into the mounting opening G 1A 3 Fasten (SW 46) the hexagon nut (3) 4 Remove the plug from below out of the connection head and plug it into the socket of the transducer tube
<G-vec00001-001-s088><assemble.bauen><de> Bauen Sie diese Windturbine und erfahren Sie mehr über nachhaltige Konstruktionen.
<G-vec00001-001-s088><assemble.bauen><en> Assemble this wind turbine and learn about sustainable design.
<G-vec00001-001-s089><assemble.bauen><de> Bauen Sie ein Team von Helden und verschieben Sie sie entlang einer Grid-basierten Weg, um jede Mission erfolgreich abzuschließen.
<G-vec00001-001-s089><assemble.bauen><en> Assemble a team of heroes and move them along a grid-based path in order to complete each mission.
<G-vec00001-001-s090><assemble.bauen><de> Bauen Sie Ihr eigenes ..
<G-vec00001-001-s090><assemble.bauen><en> Assemble your own..
<G-vec00001-001-s091><assemble.bauen><de> Thrush Treatment - Bauen Sie ein Puzzle mit einem Bild von einem Hund.
<G-vec00001-001-s091><assemble.bauen><en> Thrush Treatment - Assemble a jigsaw puzzle with an image of a Dog.
<G-vec00001-001-s228><build.bauen><de> Johnny hat gelernt, wie man virtuelle Welten baut und diese Welt für Cleopatra und sich selbst erschaffen, damit sie so darin leben können, wie es hätte sein sollen.
<G-vec00001-001-s228><build.bauen><en> Johnny had learned how to build virtual worlds and had created this world for himself and Cleopatra to live in as it should have been.
<G-vec00001-001-s229><build.bauen><de> "Sollte das Windwerk CRABster Ihren Anforderungen nicht vollständig gerecht werden, dann baut DEMAN ein ""Custom Winch"" nach Maß."
<G-vec00001-001-s229><build.bauen><en> "If the CRABster does not completely conform to your needs, then DEMAN will build a ""custom winch "" for you."
<G-vec00001-001-s230><build.bauen><de> Das sind die Arten von Funktionen, die Tourismus-Management drool zu machen, und wie das Land erhebt mit seinen bestehenden Krise, ist es wahrscheinlich, dass nicht nur der Tourismus baut, sondern dass die Liste der Casinos von Mosambik wird wachsen mehr sicher.
<G-vec00001-001-s230><build.bauen><en> Those are the kinds of features that make tourism management drool, and as the country elevates out of its existing slump, it is likely that not only will tourism build, but that the list of Mozambique’s casinos will grow longer for sure.
<G-vec00001-001-s231><build.bauen><de> Dieses Projekt baut Vertrauen, Toleranz und Kollaborationen zwischen den Organisationen aus, die gemeinsam mit den Waldanreinergemeinschaften arbeiten.
<G-vec00001-001-s231><build.bauen><en> This project will enrich green cover and build confidence, tolerance and collaborations between organizations working among forest fringe communities to restore forests and build social mobility in the area.
<G-vec00001-001-s232><build.bauen><de> Auf der Basis dieser Fertigkeiten, deren Training ständig mit dem Gymnastizieren und damit dem Beweglichkeitstraining der Pferde einhergeht, baut dann das komplexe Wettkampftraining auf.
<G-vec00001-001-s232><build.bauen><en> These basic skills, always combined with gymnastics and mobility training, are required to build up the many and various specific competition training units.
<G-vec00001-001-s233><build.bauen><de> Das Museum of The Future, das Ende 2019 eröffnet wird, baut auf mehr als fünf Jahren temporärer immersiver Ausstellungen auf dem Weltregierungsgipfel in Dubai auf.
<G-vec00001-001-s233><build.bauen><en> The Museum of The Future, to be opened at the end of 2019, will build on more than five years of temporary immersive exhibitions at the world-government summit in Dubai.
<G-vec00001-001-s234><build.bauen><de> Das vorgeschlagene Joint Venture baut auf der Dynamik von Fuse™ Technologies, AGCOs zukunftsträchtigem Ansatz für die Präzisionslandwirtschaft und das Präzisionsmanagement von Maschinen.
<G-vec00001-001-s234><build.bauen><en> The proposed joint venture will build on the momentum of Fuse™ Technologies, AGCO’s next generation approach to precision agriculture and precision machine management.
<G-vec00001-001-s235><build.bauen><de> Jammern baut kein Netz.
<G-vec00001-001-s235><build.bauen><en> Moaning won't build a network.
<G-vec00001-001-s236><build.bauen><de> Springt ins kühle Wasser, übt euch im Schnorcheln oder baut Sandburgen, nur 15 Minuten vom Stadtzentrum entfernt.
<G-vec00001-001-s236><build.bauen><en> Take a dip, go snorkelling or build sand castles, all just 15 minutes away from the city centre.
<G-vec00001-001-s237><build.bauen><de> Bitte baut eine Brücke zwischen den Menschen und zwischen Ländern.
<G-vec00001-001-s237><build.bauen><en> Please build a bridge between people, among people and between countries.
<G-vec00001-001-s238><build.bauen><de> Baut bei euren Bemühungen zur Vorbereitung der Fünfhundertjahrfeier auf diesem soliden Fundament auf.
<G-vec00001-001-s238><build.bauen><en> In your efforts to prepare for the fifth centenary, build on this solid foundation.
<G-vec00001-001-s239><build.bauen><de> Es gibt einen Weg: Kämpft für die Mobilisierung der Macht von Arbeitern, Schwarzen und Einwanderern – Formiert Arbeiterverteidigungsgruppen – Brecht mit den Demokraten und baut eine Arbeiterpartei auf, um für internationale sozialistische Revolution zu kämpfen.
<G-vec00001-001-s239><build.bauen><en> There is a way: Fight to mobilize labor/black immigrant power – Build workers defense guards – Break with the Democrats and build a workers party to fight for international socialist revolution.
<G-vec00001-001-s240><build.bauen><de> Dazu konzipiert, baut und nimmt das IEFE, wenn nötig oder vom Kunden gewünscht, Prüfstände mit der passenden Messtechnik in Betrieb.
<G-vec00001-001-s240><build.bauen><en> Where necessary or requested by the client, IEFE will further design, build and commission test facilities with the related metrology.
<G-vec00001-001-s241><build.bauen><de> Ein nigerianisches Sprichwort sagt: In Krisenzeiten baut der Weise Brücken, der Törichte Wälle.
<G-vec00001-001-s241><build.bauen><en> A Nigerian proverb states that ‘in the moment of crisis, the wise build bridges and the foolish build dams’.
<G-vec00001-001-s242><build.bauen><de> Baut tolle LEGO Objekte, um neue Bereiche und Gegenstände zu entdecken.
<G-vec00001-001-s242><build.bauen><en> Build special LEGO objects to discover new areas and items.
<G-vec00001-001-s243><build.bauen><de> "Krone Easy Rider - Fünf Tonnen für alle Krone baut seine Kompetenz im Portfolio Reifen weiter aus und hat die Qualität seiner eigenen Baureihe ""Easy Rider"" einmal mehr verbessert."
<G-vec00001-001-s243><build.bauen><en> "Krone Easy Rider - Five tons across the range Krone continues to build its expertise in the tyre sector and has once more improved the quality of its own ""Easy Rider"" range."
<G-vec00001-001-s244><build.bauen><de> Der eine baut sein Haus auf einen Felsen; er richtet sein Leben also nach göttlichen Prinzipien und Maßstäben aus.
<G-vec00001-001-s244><build.bauen><en> Some build their houses upon a rock, meaning they live according to divine principles and standards.
<G-vec00001-001-s245><build.bauen><de> Was Schalamow anspricht, ist jedoch kaum dessen ausgefeilter Satzbau, sondern mehr Faulkners Fähigkeit, Buch für Buch eine vollkommen eigene Welt zu erschaffen, die durch eine gänzlich eigene Idiomatik (eine Sprache, die man nur in diesen Büchern spricht) zusammengehalten wird und in der jeder einzelne Text weiter an dem ihnen allen eigenen Symbol- und Motivkreis baut und ihn verstärkt.
<G-vec00001-001-s245><build.bauen><en> Faulkner’s baroque prose is of course light years away from Shalamov’s sternly purged and pared-down variety. It is hardly Faulkner’s elaborate sentence structure that appeals to Shalamov, however, but more his ability, in book after book, to conjure up a world that is completely and utterly itself, held together by an idiom of its own (a language only spoken in these books), where every single text continues to build on, and intensify, the set of symbols and motifs that run through them all.
<G-vec00001-001-s246><build.bauen><de> Die Gruppe um Heinz Billing baut in München und im italienischen Frascati die empfindlichsten Zylinderdetektoren weltweit.
<G-vec00001-001-s246><build.bauen><en> The group working with Heinz Billing build the world's most sensitive cylinder detectors in Munich and in Frascati, Italy.
<G-vec00179-001-s228><build.bauen><de> Johnny hat gelernt, wie man virtuelle Welten baut und diese Welt für Cleopatra und sich selbst erschaffen, damit sie so darin leben können, wie es hätte sein sollen.
<G-vec00179-001-s228><build.bauen><en> Johnny had learned how to build virtual worlds and had created this world for himself and Cleopatra to live in as it should have been.
<G-vec00179-001-s229><build.bauen><de> "Sollte das Windwerk CRABster Ihren Anforderungen nicht vollständig gerecht werden, dann baut DEMAN ein ""Custom Winch"" nach Maß."
<G-vec00179-001-s229><build.bauen><en> "If the CRABster does not completely conform to your needs, then DEMAN will build a ""custom winch "" for you."
<G-vec00179-001-s230><build.bauen><de> Das sind die Arten von Funktionen, die Tourismus-Management drool zu machen, und wie das Land erhebt mit seinen bestehenden Krise, ist es wahrscheinlich, dass nicht nur der Tourismus baut, sondern dass die Liste der Casinos von Mosambik wird wachsen mehr sicher.
<G-vec00179-001-s230><build.bauen><en> Those are the kinds of features that make tourism management drool, and as the country elevates out of its existing slump, it is likely that not only will tourism build, but that the list of Mozambique’s casinos will grow longer for sure.
<G-vec00179-001-s231><build.bauen><de> Dieses Projekt baut Vertrauen, Toleranz und Kollaborationen zwischen den Organisationen aus, die gemeinsam mit den Waldanreinergemeinschaften arbeiten.
<G-vec00179-001-s231><build.bauen><en> This project will enrich green cover and build confidence, tolerance and collaborations between organizations working among forest fringe communities to restore forests and build social mobility in the area.
<G-vec00179-001-s232><build.bauen><de> Auf der Basis dieser Fertigkeiten, deren Training ständig mit dem Gymnastizieren und damit dem Beweglichkeitstraining der Pferde einhergeht, baut dann das komplexe Wettkampftraining auf.
<G-vec00179-001-s232><build.bauen><en> These basic skills, always combined with gymnastics and mobility training, are required to build up the many and various specific competition training units.
<G-vec00179-001-s233><build.bauen><de> Das Museum of The Future, das Ende 2019 eröffnet wird, baut auf mehr als fünf Jahren temporärer immersiver Ausstellungen auf dem Weltregierungsgipfel in Dubai auf.
<G-vec00179-001-s233><build.bauen><en> The Museum of The Future, to be opened at the end of 2019, will build on more than five years of temporary immersive exhibitions at the world-government summit in Dubai.
<G-vec00179-001-s234><build.bauen><de> Das vorgeschlagene Joint Venture baut auf der Dynamik von Fuse™ Technologies, AGCOs zukunftsträchtigem Ansatz für die Präzisionslandwirtschaft und das Präzisionsmanagement von Maschinen.
<G-vec00179-001-s234><build.bauen><en> The proposed joint venture will build on the momentum of Fuse™ Technologies, AGCO’s next generation approach to precision agriculture and precision machine management.
<G-vec00179-001-s235><build.bauen><de> Jammern baut kein Netz.
<G-vec00179-001-s235><build.bauen><en> Moaning won't build a network.
<G-vec00179-001-s236><build.bauen><de> Springt ins kühle Wasser, übt euch im Schnorcheln oder baut Sandburgen, nur 15 Minuten vom Stadtzentrum entfernt.
<G-vec00179-001-s236><build.bauen><en> Take a dip, go snorkelling or build sand castles, all just 15 minutes away from the city centre.
<G-vec00179-001-s237><build.bauen><de> Bitte baut eine Brücke zwischen den Menschen und zwischen Ländern.
<G-vec00179-001-s237><build.bauen><en> Please build a bridge between people, among people and between countries.
<G-vec00179-001-s238><build.bauen><de> Baut bei euren Bemühungen zur Vorbereitung der Fünfhundertjahrfeier auf diesem soliden Fundament auf.
<G-vec00179-001-s238><build.bauen><en> In your efforts to prepare for the fifth centenary, build on this solid foundation.
<G-vec00179-001-s239><build.bauen><de> Es gibt einen Weg: Kämpft für die Mobilisierung der Macht von Arbeitern, Schwarzen und Einwanderern – Formiert Arbeiterverteidigungsgruppen – Brecht mit den Demokraten und baut eine Arbeiterpartei auf, um für internationale sozialistische Revolution zu kämpfen.
<G-vec00179-001-s239><build.bauen><en> There is a way: Fight to mobilize labor/black immigrant power – Build workers defense guards – Break with the Democrats and build a workers party to fight for international socialist revolution.
<G-vec00179-001-s240><build.bauen><de> Dazu konzipiert, baut und nimmt das IEFE, wenn nötig oder vom Kunden gewünscht, Prüfstände mit der passenden Messtechnik in Betrieb.
<G-vec00179-001-s240><build.bauen><en> Where necessary or requested by the client, IEFE will further design, build and commission test facilities with the related metrology.
<G-vec00179-001-s241><build.bauen><de> Ein nigerianisches Sprichwort sagt: In Krisenzeiten baut der Weise Brücken, der Törichte Wälle.
<G-vec00179-001-s241><build.bauen><en> A Nigerian proverb states that ‘in the moment of crisis, the wise build bridges and the foolish build dams’.
<G-vec00179-001-s242><build.bauen><de> Baut tolle LEGO Objekte, um neue Bereiche und Gegenstände zu entdecken.
<G-vec00179-001-s242><build.bauen><en> Build special LEGO objects to discover new areas and items.
<G-vec00179-001-s243><build.bauen><de> "Krone Easy Rider - Fünf Tonnen für alle Krone baut seine Kompetenz im Portfolio Reifen weiter aus und hat die Qualität seiner eigenen Baureihe ""Easy Rider"" einmal mehr verbessert."
<G-vec00179-001-s243><build.bauen><en> "Krone Easy Rider - Five tons across the range Krone continues to build its expertise in the tyre sector and has once more improved the quality of its own ""Easy Rider"" range."
<G-vec00179-001-s244><build.bauen><de> Der eine baut sein Haus auf einen Felsen; er richtet sein Leben also nach göttlichen Prinzipien und Maßstäben aus.
<G-vec00179-001-s244><build.bauen><en> Some build their houses upon a rock, meaning they live according to divine principles and standards.
<G-vec00179-001-s245><build.bauen><de> Was Schalamow anspricht, ist jedoch kaum dessen ausgefeilter Satzbau, sondern mehr Faulkners Fähigkeit, Buch für Buch eine vollkommen eigene Welt zu erschaffen, die durch eine gänzlich eigene Idiomatik (eine Sprache, die man nur in diesen Büchern spricht) zusammengehalten wird und in der jeder einzelne Text weiter an dem ihnen allen eigenen Symbol- und Motivkreis baut und ihn verstärkt.
<G-vec00179-001-s245><build.bauen><en> Faulkner’s baroque prose is of course light years away from Shalamov’s sternly purged and pared-down variety. It is hardly Faulkner’s elaborate sentence structure that appeals to Shalamov, however, but more his ability, in book after book, to conjure up a world that is completely and utterly itself, held together by an idiom of its own (a language only spoken in these books), where every single text continues to build on, and intensify, the set of symbols and motifs that run through them all.
<G-vec00179-001-s246><build.bauen><de> Die Gruppe um Heinz Billing baut in München und im italienischen Frascati die empfindlichsten Zylinderdetektoren weltweit.
<G-vec00179-001-s246><build.bauen><en> The group working with Heinz Billing build the world's most sensitive cylinder detectors in Munich and in Frascati, Italy.
<G-vec00001-001-s131><construct.bauen><de> Sie fragt beim ersten Start ab, in welchem Gewerk der Anwender tätig ist und baut anhand dieser Informationen das Menü mit allen relevanten Funktionen auf.
<G-vec00001-001-s131><construct.bauen><en> On initial start-up, the app asks in which trade the user works and uses this information to construct a menu containing all of the relevant functions.
<G-vec00001-001-s132><construct.bauen><de> Das Symbol funktioniet nach dem Prinzip der Selbstbegründung: es isoliert ein Fragment der Realität, gibt ihm zusätzliche Bedeutung, zusätzlichen Sinn, baut es bis zu einem selbständigen Ganzen aus, zur Norm des Einheitlichen.
<G-vec00001-001-s132><construct.bauen><en> Thus, the symbol functions by self-justification: by isolating a fragment of reality, it heightens its significance and meaning so as to construct it into an autonomous whole, into a norm of wholeness.
<G-vec00001-001-s133><construct.bauen><de> Aus allen diesen Informationen baut das Programm einen Befehl auf, wie und wohin sich zum Beispiel ein Greifarm bewegen soll und sendet ihn an die Gerätesteuerung.
<G-vec00001-001-s133><construct.bauen><en> The program uses all this information to construct a command, for example, as to how and where a gripper arm should move and sends it to the device control.
<G-vec00001-001-s134><construct.bauen><de> Zwar werden die Märkte immer internationaler, doch eines bleibt: ZARGES konstruiert und baut, ganz im Sinne des Gründers Walther Zarges, Alltagsprodukte aus Aluminium, die überall auf der Welt gebraucht werden.
<G-vec00001-001-s134><construct.bauen><en> Although the markets keep becoming more and more international, one thing remains the same: ZARGES continues to design and construct day-to-day aluminium products that are used everywhere in the world – much in the spirit of its founder.
<G-vec00001-001-s135><construct.bauen><de> Dies bedeutet, dass Sie liefern keine ausreichende Leistung für den menschlichen Körper Fett zu vergießen und Muskelgewebe baut in geeigneter Weise durch die Ausbildung.
<G-vec00001-001-s135><construct.bauen><en> This implies that you do not provide adequate power for the body to burn fat and construct muscle effectively through the training.
<G-vec00001-001-s136><construct.bauen><de> In seiner Freizeit baut er gerne Effektgeräte für seine Gitarre und handliche Verstärker in der Größe eines begehbaren Kleiderschranks.
<G-vec00001-001-s136><construct.bauen><en> In his spare time he likes to construct effect units for his guitar and handy boxes the size of walk-in closets.
<G-vec00001-001-s137><construct.bauen><de> Newpark Mats & Integrated Services führt nicht nur den Bau Ihrer Bohrstelle aus und wartet sie während des gesamten Bohrvorgangs, sondern baut, wartet und repariert auch Ihre Produktionsstätte, nachdem das Bohrloch fertiggestellt ist.
<G-vec00001-001-s137><construct.bauen><en> Newpark Mats & Integrated Services will not only complete the construction of your drilling location and maintain the location throughout the drilling process, but we will also construct, maintain and repair your production facility after the well has been completed.
<G-vec00001-001-s138><construct.bauen><de> Unser sonstiges F&E-Personal baut unter anderem in den Werkstätten Forschungsequipment oder arbeitet in der Verwaltung, zum Beispiel als Marktforscher oder Trendanalyst.
<G-vec00001-001-s138><construct.bauen><en> Our other R&D personnel construct research equipment in our workshops, or perform administrative functions in such fields as market research and trend analysis.
<G-vec00001-001-s139><construct.bauen><de> Als Generalunternehmer wurde die AE&E Inova, eine Tochter der VonRoll Inova AG, Schweiz, beauftragt, die unter der Gesamtkoordination der STEAG die schlüsselfertige Anlage plant und baut.
<G-vec00001-001-s139><construct.bauen><en> Prime engineering contractor is AE&E Inova, which is a subsidiary of VonRoll Inova AG, Switzerland, and will design and construct the turnkey plant under overall coordination by STEAG.
<G-vec00179-001-s131><construct.bauen><de> Sie fragt beim ersten Start ab, in welchem Gewerk der Anwender tätig ist und baut anhand dieser Informationen das Menü mit allen relevanten Funktionen auf.
<G-vec00179-001-s131><construct.bauen><en> On initial start-up, the app asks in which trade the user works and uses this information to construct a menu containing all of the relevant functions.
<G-vec00179-001-s132><construct.bauen><de> Das Symbol funktioniet nach dem Prinzip der Selbstbegründung: es isoliert ein Fragment der Realität, gibt ihm zusätzliche Bedeutung, zusätzlichen Sinn, baut es bis zu einem selbständigen Ganzen aus, zur Norm des Einheitlichen.
<G-vec00179-001-s132><construct.bauen><en> Thus, the symbol functions by self-justification: by isolating a fragment of reality, it heightens its significance and meaning so as to construct it into an autonomous whole, into a norm of wholeness.
<G-vec00179-001-s133><construct.bauen><de> Aus allen diesen Informationen baut das Programm einen Befehl auf, wie und wohin sich zum Beispiel ein Greifarm bewegen soll und sendet ihn an die Gerätesteuerung.
<G-vec00179-001-s133><construct.bauen><en> The program uses all this information to construct a command, for example, as to how and where a gripper arm should move and sends it to the device control.
<G-vec00179-001-s134><construct.bauen><de> Zwar werden die Märkte immer internationaler, doch eines bleibt: ZARGES konstruiert und baut, ganz im Sinne des Gründers Walther Zarges, Alltagsprodukte aus Aluminium, die überall auf der Welt gebraucht werden.
<G-vec00179-001-s134><construct.bauen><en> Although the markets keep becoming more and more international, one thing remains the same: ZARGES continues to design and construct day-to-day aluminium products that are used everywhere in the world – much in the spirit of its founder.
<G-vec00179-001-s135><construct.bauen><de> Dies bedeutet, dass Sie liefern keine ausreichende Leistung für den menschlichen Körper Fett zu vergießen und Muskelgewebe baut in geeigneter Weise durch die Ausbildung.
<G-vec00179-001-s135><construct.bauen><en> This implies that you do not provide adequate power for the body to burn fat and construct muscle effectively through the training.
<G-vec00179-001-s136><construct.bauen><de> In seiner Freizeit baut er gerne Effektgeräte für seine Gitarre und handliche Verstärker in der Größe eines begehbaren Kleiderschranks.
<G-vec00179-001-s136><construct.bauen><en> In his spare time he likes to construct effect units for his guitar and handy boxes the size of walk-in closets.
<G-vec00179-001-s137><construct.bauen><de> Newpark Mats & Integrated Services führt nicht nur den Bau Ihrer Bohrstelle aus und wartet sie während des gesamten Bohrvorgangs, sondern baut, wartet und repariert auch Ihre Produktionsstätte, nachdem das Bohrloch fertiggestellt ist.
<G-vec00179-001-s137><construct.bauen><en> Newpark Mats & Integrated Services will not only complete the construction of your drilling location and maintain the location throughout the drilling process, but we will also construct, maintain and repair your production facility after the well has been completed.
<G-vec00179-001-s138><construct.bauen><de> Unser sonstiges F&E-Personal baut unter anderem in den Werkstätten Forschungsequipment oder arbeitet in der Verwaltung, zum Beispiel als Marktforscher oder Trendanalyst.
<G-vec00179-001-s138><construct.bauen><en> Our other R&D personnel construct research equipment in our workshops, or perform administrative functions in such fields as market research and trend analysis.
<G-vec00179-001-s139><construct.bauen><de> Als Generalunternehmer wurde die AE&E Inova, eine Tochter der VonRoll Inova AG, Schweiz, beauftragt, die unter der Gesamtkoordination der STEAG die schlüsselfertige Anlage plant und baut.
<G-vec00179-001-s139><construct.bauen><en> Prime engineering contractor is AE&E Inova, which is a subsidiary of VonRoll Inova AG, Switzerland, and will design and construct the turnkey plant under overall coordination by STEAG.
<G-vec00001-001-s456><build.bauen><de> Der Gesamtkomplex Zeche Zollverein in Essen wurde Ende der 20er Jahre gebaut und im Jahre 1986 stillgelegt.
<G-vec00001-001-s456><build.bauen><en> The coal pit Zeche Zollverein in Essen was build at the end of the 1920s and was closed down in the year 1986.
<G-vec00001-001-s457><build.bauen><de> So wisse nun und merke: von der Zeit an, da ausgeht der Befehl, daß Jerusalem soll wieder gebaut werden, bis auf den Gesalbten, den Fürsten, sind sieben Wochen; und zweiundsechzig Wochen, so werden die Gassen und Mauern wieder gebaut werden, wiewohl in kümmerlicher Zeit.
<G-vec00001-001-s457><build.bauen><en> Know therefore and discern, that from the going forth of the commandment to restore and to build Jerusalem to the Anointed One, the prince, shall be seven weeks, and sixty-two weeks: it shall be built again, with street and moat, even in troubled times.
<G-vec00001-001-s458><build.bauen><de> Ein Haus ist eine alte Mühle im Jahre 1877 gebaut, restauriert, dient als Damm für Süßwassersee hinter dem Haus an der nördlichen Seite des Grundstücks, während auf der Südseite befindet sich im direkten Kontakt mit Meer.
<G-vec00001-001-s458><build.bauen><en> One house is an old mill build in 1877,restored,serves as a dam for fresh water lake behind the house on northern side of the property; while on the southern side is in the direct contact with sea.
<G-vec00001-001-s459><build.bauen><de> Die Teilnehmer und Teilnehmerinnen lernen, wie ein Roboter funktioniert und wie solch eine bewegliche „Kreatur“ selbst gebaut und gesteuert werden kann.
<G-vec00001-001-s459><build.bauen><en> The participants learn how a robot works and how you can build and control such a mobile “creature” yourself.
<G-vec00001-001-s460><build.bauen><de> Durch die Anwendung des OO-Design- Ansatzes kann ein System entworfen und getestet (oder korrekter: simuliert) werden, ohne dass es vorher gebaut werden muss.
<G-vec00001-001-s460><build.bauen><en> By using an OO approach to design a system can be designed and tested (or more correctly simulated) without having to actually build the system first.
<G-vec00001-001-s461><build.bauen><de> Eine beeindruckende mittelalterliche Burg, gebaut auf einem steilen Fels 112 Meter über der Wasserfläche des Arwa-Flusses.
<G-vec00001-001-s461><build.bauen><en> Stunning medieval castle build on a steep rock 112 m above river Orava.
<G-vec00001-001-s462><build.bauen><de> [2] Es wurde allerdings kein Prototyp gebaut.
<G-vec00001-001-s462><build.bauen><en> [2] But he didn't build a prototype.
<G-vec00001-001-s463><build.bauen><de> Das Haus ist in besonderer Weise gebaut.
<G-vec00001-001-s463><build.bauen><en> The house is build in a special way.
<G-vec00001-001-s464><build.bauen><de> GUIs werden als Baum von Fenstern (Rechtecken), mit ihren eigenen Eigenschaften gebaut.
<G-vec00001-001-s464><build.bauen><en> GUIs are build as a tree of windows (rectangle) with their own properties.
<G-vec00001-001-s465><build.bauen><de> Da alle Gebäude aus dem gleichen grauen Stein gebaut zu sein scheinen wirkt das Areal etwas trist.
<G-vec00001-001-s465><build.bauen><en> As most of the buildings seem to be build of the same grey stone the are gives a rather dull impression.
<G-vec00001-001-s466><build.bauen><de> Von 1930 bis 1937 wurden die Boote nach den Regeln der internationalen 'J'-Klasse gebaut (Yacht-Klassen wurde nach dem Alphabet durchnummeriert).
<G-vec00001-001-s466><build.bauen><en> From 1930 to 1937 the boats were build under the regulations of the international 'J' class (yacht classes were numbered by the alphabet).
<G-vec00001-001-s467><build.bauen><de> Dieses provenzalische Landhaus wurde gebaut vor 250 Jahren.
<G-vec00001-001-s467><build.bauen><en> This provencal country house was build 250 years ago.
<G-vec00001-001-s468><build.bauen><de> Der Handelsposten benötigt keine Garnisonsressourcen mehr, um gebaut oder ausgebaut zu werden.
<G-vec00001-001-s468><build.bauen><en> Trading Post no longer requires Garrison Resources to build or upgrade.
<G-vec00001-001-s469><build.bauen><de> Das Elemental-Team hat seit 2001 konsequent mit einfallsreichen, flexiblen und kostengünstigen architektonischen Lösungen Tausende Wohneinheiten in seinem Heimatland Chile gebaut.
<G-vec00001-001-s469><build.bauen><en> Since 2001 the Elemental team has continued to build thousands of housing units in his homeland of Chile, using inventive, flexible, and affordable solutions.
<G-vec00001-001-s470><build.bauen><de> In Songkhla muss ein neues Stadion gebaut werden.
<G-vec00001-001-s470><build.bauen><en> In Songkhla a new Arena must be build.
<G-vec00001-001-s471><build.bauen><de> 1 Im vierhundertundachtzigsten Jahr nach dem Auszug Israels aus Ägyptenland, im vierten Jahr der Herrschaft Salomos über Israel, im Monat Siw, das ist der zweite Monat, wurde das Haus dem HERRN gebaut.
<G-vec00001-001-s471><build.bauen><en> 1 And it came to pass in the four hundred and eightieth year after the children of Israel were come out of the land of Egypt, in the fourth year of Solomon 's reign over Israel, in the month Zif, which is the second month, that he began to build the house of the LORD.
<G-vec00001-001-s472><build.bauen><de> Turbo, gebaut 1912, gesunken, Zweiter Weltkrieg, am 04.04.1942 durch Torpedo, Abu Dias, Ras Banas, Ägypten, Rotes Meer, Afrika | Stern, Wreck, ship, tanker, S.S.
<G-vec00001-001-s472><build.bauen><en> Turbo, build 1912, sank, World War Two, WW II, 04.04.1942, torpedo hit, Abu Dias, Ras Bananas, Egypt, Red Sea, Africa | Heck, Wrack, Schiff, Tanker, S.S.
<G-vec00001-001-s473><build.bauen><de> "Nach Erreichen des Levels erhält das Oberhaupt den Auftrag Agden Gal-Tarks ""Werftbau"", in dem der Kapitän davon erzählt, dass für den Bau von Schiffen, die den Wandernden Archipel erreichen können, der Clan erst eine eigene Werft anlegen sollte, in der dann das Schiff gebaut wird."
<G-vec00001-001-s473><build.bauen><en> "After the required level is gained, the Clan Leader is summoned by captain Agden Gal-Tark and receives the ""Laying the Foundation"" Quest in which Gal-Tark explains that in order to reach the Roaming Archipelago, a Clan would need to construct a Dockyard and build a Ship."
<G-vec00001-001-s474><build.bauen><de> Während dieser Phase wird eine komplett neue Montagehalle gebaut.
<G-vec00001-001-s474><build.bauen><en> In this phase, a new assembly hall is being build.
<G-vec00179-001-s456><build.bauen><de> Der Gesamtkomplex Zeche Zollverein in Essen wurde Ende der 20er Jahre gebaut und im Jahre 1986 stillgelegt.
<G-vec00179-001-s456><build.bauen><en> The coal pit Zeche Zollverein in Essen was build at the end of the 1920s and was closed down in the year 1986.
<G-vec00179-001-s457><build.bauen><de> So wisse nun und merke: von der Zeit an, da ausgeht der Befehl, daß Jerusalem soll wieder gebaut werden, bis auf den Gesalbten, den Fürsten, sind sieben Wochen; und zweiundsechzig Wochen, so werden die Gassen und Mauern wieder gebaut werden, wiewohl in kümmerlicher Zeit.
<G-vec00179-001-s457><build.bauen><en> Know therefore and discern, that from the going forth of the commandment to restore and to build Jerusalem to the Anointed One, the prince, shall be seven weeks, and sixty-two weeks: it shall be built again, with street and moat, even in troubled times.
<G-vec00179-001-s458><build.bauen><de> Ein Haus ist eine alte Mühle im Jahre 1877 gebaut, restauriert, dient als Damm für Süßwassersee hinter dem Haus an der nördlichen Seite des Grundstücks, während auf der Südseite befindet sich im direkten Kontakt mit Meer.
<G-vec00179-001-s458><build.bauen><en> One house is an old mill build in 1877,restored,serves as a dam for fresh water lake behind the house on northern side of the property; while on the southern side is in the direct contact with sea.
<G-vec00179-001-s459><build.bauen><de> Die Teilnehmer und Teilnehmerinnen lernen, wie ein Roboter funktioniert und wie solch eine bewegliche „Kreatur“ selbst gebaut und gesteuert werden kann.
<G-vec00179-001-s459><build.bauen><en> The participants learn how a robot works and how you can build and control such a mobile “creature” yourself.
<G-vec00179-001-s460><build.bauen><de> Durch die Anwendung des OO-Design- Ansatzes kann ein System entworfen und getestet (oder korrekter: simuliert) werden, ohne dass es vorher gebaut werden muss.
<G-vec00179-001-s460><build.bauen><en> By using an OO approach to design a system can be designed and tested (or more correctly simulated) without having to actually build the system first.
<G-vec00179-001-s461><build.bauen><de> Eine beeindruckende mittelalterliche Burg, gebaut auf einem steilen Fels 112 Meter über der Wasserfläche des Arwa-Flusses.
<G-vec00179-001-s461><build.bauen><en> Stunning medieval castle build on a steep rock 112 m above river Orava.
<G-vec00179-001-s462><build.bauen><de> [2] Es wurde allerdings kein Prototyp gebaut.
<G-vec00179-001-s462><build.bauen><en> [2] But he didn't build a prototype.
<G-vec00179-001-s463><build.bauen><de> Das Haus ist in besonderer Weise gebaut.
<G-vec00179-001-s463><build.bauen><en> The house is build in a special way.
<G-vec00179-001-s464><build.bauen><de> GUIs werden als Baum von Fenstern (Rechtecken), mit ihren eigenen Eigenschaften gebaut.
<G-vec00179-001-s464><build.bauen><en> GUIs are build as a tree of windows (rectangle) with their own properties.
<G-vec00179-001-s465><build.bauen><de> Da alle Gebäude aus dem gleichen grauen Stein gebaut zu sein scheinen wirkt das Areal etwas trist.
<G-vec00179-001-s465><build.bauen><en> As most of the buildings seem to be build of the same grey stone the are gives a rather dull impression.
<G-vec00179-001-s466><build.bauen><de> Von 1930 bis 1937 wurden die Boote nach den Regeln der internationalen 'J'-Klasse gebaut (Yacht-Klassen wurde nach dem Alphabet durchnummeriert).
<G-vec00179-001-s466><build.bauen><en> From 1930 to 1937 the boats were build under the regulations of the international 'J' class (yacht classes were numbered by the alphabet).
<G-vec00179-001-s467><build.bauen><de> Dieses provenzalische Landhaus wurde gebaut vor 250 Jahren.
<G-vec00179-001-s467><build.bauen><en> This provencal country house was build 250 years ago.
<G-vec00179-001-s468><build.bauen><de> Der Handelsposten benötigt keine Garnisonsressourcen mehr, um gebaut oder ausgebaut zu werden.
<G-vec00179-001-s468><build.bauen><en> Trading Post no longer requires Garrison Resources to build or upgrade.
<G-vec00179-001-s469><build.bauen><de> Das Elemental-Team hat seit 2001 konsequent mit einfallsreichen, flexiblen und kostengünstigen architektonischen Lösungen Tausende Wohneinheiten in seinem Heimatland Chile gebaut.
<G-vec00179-001-s469><build.bauen><en> Since 2001 the Elemental team has continued to build thousands of housing units in his homeland of Chile, using inventive, flexible, and affordable solutions.
<G-vec00179-001-s470><build.bauen><de> In Songkhla muss ein neues Stadion gebaut werden.
<G-vec00179-001-s470><build.bauen><en> In Songkhla a new Arena must be build.
<G-vec00179-001-s471><build.bauen><de> 1 Im vierhundertundachtzigsten Jahr nach dem Auszug Israels aus Ägyptenland, im vierten Jahr der Herrschaft Salomos über Israel, im Monat Siw, das ist der zweite Monat, wurde das Haus dem HERRN gebaut.
<G-vec00179-001-s471><build.bauen><en> 1 And it came to pass in the four hundred and eightieth year after the children of Israel were come out of the land of Egypt, in the fourth year of Solomon 's reign over Israel, in the month Zif, which is the second month, that he began to build the house of the LORD.
<G-vec00179-001-s472><build.bauen><de> Turbo, gebaut 1912, gesunken, Zweiter Weltkrieg, am 04.04.1942 durch Torpedo, Abu Dias, Ras Banas, Ägypten, Rotes Meer, Afrika | Stern, Wreck, ship, tanker, S.S.
<G-vec00179-001-s472><build.bauen><en> Turbo, build 1912, sank, World War Two, WW II, 04.04.1942, torpedo hit, Abu Dias, Ras Bananas, Egypt, Red Sea, Africa | Heck, Wrack, Schiff, Tanker, S.S.
<G-vec00179-001-s473><build.bauen><de> "Nach Erreichen des Levels erhält das Oberhaupt den Auftrag Agden Gal-Tarks ""Werftbau"", in dem der Kapitän davon erzählt, dass für den Bau von Schiffen, die den Wandernden Archipel erreichen können, der Clan erst eine eigene Werft anlegen sollte, in der dann das Schiff gebaut wird."
<G-vec00179-001-s473><build.bauen><en> "After the required level is gained, the Clan Leader is summoned by captain Agden Gal-Tark and receives the ""Laying the Foundation"" Quest in which Gal-Tark explains that in order to reach the Roaming Archipelago, a Clan would need to construct a Dockyard and build a Ship."
<G-vec00179-001-s474><build.bauen><de> Während dieser Phase wird eine komplett neue Montagehalle gebaut.
<G-vec00179-001-s474><build.bauen><en> In this phase, a new assembly hall is being build.
<G-vec00001-001-s270><construct.bauen><de> In der Hafermühle profitierte man von der aufkommenden «Müesliwelle», sodass schon bald zusammen mit Bühler eine neue Hafermühle gebaut wurde, deren Leistung mittlerweile verdop-pelt wurde.
<G-vec00001-001-s270><construct.bauen><en> The oat mill benefited from the emerging “muesli” wave, which prompted the company to construct a new oat mill together with Bühler. Since then, its capacity has doubled.
<G-vec00001-001-s271><construct.bauen><de> Ausschlaggebend sind Deine Entscheidungen darüber, welche Technologien Du erforschen lässt, wohin Deine Armeen geschickt werden, wie Deine Wirtschaft verwaltet wird und welche Kampfeinheiten gebaut werden.
<G-vec00001-001-s271><construct.bauen><en> Deciding what technologies to research, where to send armies, how to manage your economy, and what units to construct are critical.
<G-vec00001-001-s272><construct.bauen><de> Deshalb wird dieser spezifisch für jeden einzelnen Kunden massgeschneidert und mit modernster technischer Infrastruktur in der Schweiz gebaut.
<G-vec00001-001-s272><construct.bauen><en> That’s why we customise them specifically to the needs of every individual customer and construct them in Switzerland using state-of-the-art technical infrastructure.
<G-vec00001-001-s273><construct.bauen><de> Fahrzeuge von 10 bis 150 Tonnen gebaut.
<G-vec00001-001-s273><construct.bauen><en> We construct to 150 vehicles from 10 Tn.
<G-vec00001-001-s274><construct.bauen><de> Pepsin abbaut Lebensmittel Proteine in Peptide, damit Ihr Körper alle verfeinern könnte, die gesunde Protein anlehnen werden Sie sicherlich in nehmen müssen, um jene massive neue Muskelmasse zu füttern Sie sicher gebaut werden wird.
<G-vec00001-001-s274><construct.bauen><en> Pepsin breaks down food healthy proteins right into peptides so your body can refine all that lean healthy protein you will certainly have to take in to feed those massive new muscle mass you will certainly be construct.
<G-vec00001-001-s275><construct.bauen><de> Die Bandbreite reichte von Gamedesign Ã1⁄4ber eine Virtual-Reality-Tour durch das Robotic Fabrication Labratory der ETH bis hin zu neuen Materialien, wie beispielsweise einem Â«kÃ1⁄4nstlichen Baum», der CO2 und Licht in Solarkraftstoff umwandet, leichte Fasern, die Stahlkabel ersetzen können oder ein neues Material, aus dem kÃ1⁄4nftig Computer gebaut werden können.
<G-vec00001-001-s275><construct.bauen><en> "The exhibition covered everything from game design and a virtual reality tour through ETH's Robotic Fabrication Laboratory to new materials, such as an ""artificial tree"" that converts CO2 and light into solar power, lightweight fibres that could replace steel cables, and a new material that could be used to construct computers in future."
<G-vec00179-001-s270><construct.bauen><de> In der Hafermühle profitierte man von der aufkommenden «Müesliwelle», sodass schon bald zusammen mit Bühler eine neue Hafermühle gebaut wurde, deren Leistung mittlerweile verdop-pelt wurde.
<G-vec00179-001-s270><construct.bauen><en> The oat mill benefited from the emerging “muesli” wave, which prompted the company to construct a new oat mill together with Bühler. Since then, its capacity has doubled.
<G-vec00179-001-s271><construct.bauen><de> Ausschlaggebend sind Deine Entscheidungen darüber, welche Technologien Du erforschen lässt, wohin Deine Armeen geschickt werden, wie Deine Wirtschaft verwaltet wird und welche Kampfeinheiten gebaut werden.
<G-vec00179-001-s271><construct.bauen><en> Deciding what technologies to research, where to send armies, how to manage your economy, and what units to construct are critical.
<G-vec00179-001-s272><construct.bauen><de> Deshalb wird dieser spezifisch für jeden einzelnen Kunden massgeschneidert und mit modernster technischer Infrastruktur in der Schweiz gebaut.
<G-vec00179-001-s272><construct.bauen><en> That’s why we customise them specifically to the needs of every individual customer and construct them in Switzerland using state-of-the-art technical infrastructure.
<G-vec00179-001-s273><construct.bauen><de> Fahrzeuge von 10 bis 150 Tonnen gebaut.
<G-vec00179-001-s273><construct.bauen><en> We construct to 150 vehicles from 10 Tn.
<G-vec00179-001-s274><construct.bauen><de> Pepsin abbaut Lebensmittel Proteine in Peptide, damit Ihr Körper alle verfeinern könnte, die gesunde Protein anlehnen werden Sie sicherlich in nehmen müssen, um jene massive neue Muskelmasse zu füttern Sie sicher gebaut werden wird.
<G-vec00179-001-s274><construct.bauen><en> Pepsin breaks down food healthy proteins right into peptides so your body can refine all that lean healthy protein you will certainly have to take in to feed those massive new muscle mass you will certainly be construct.
<G-vec00179-001-s275><construct.bauen><de> Die Bandbreite reichte von Gamedesign Ã1⁄4ber eine Virtual-Reality-Tour durch das Robotic Fabrication Labratory der ETH bis hin zu neuen Materialien, wie beispielsweise einem Â«kÃ1⁄4nstlichen Baum», der CO2 und Licht in Solarkraftstoff umwandet, leichte Fasern, die Stahlkabel ersetzen können oder ein neues Material, aus dem kÃ1⁄4nftig Computer gebaut werden können.
<G-vec00179-001-s275><construct.bauen><en> "The exhibition covered everything from game design and a virtual reality tour through ETH's Robotic Fabrication Laboratory to new materials, such as an ""artificial tree"" that converts CO2 and light into solar power, lightweight fibres that could replace steel cables, and a new material that could be used to construct computers in future."
<G-vec00179-001-s532><take.bauen><de> Im Büro der Initiative kann Ihr Material gleich reproduziert werden, so dass Sie es wieder mit zu sich nach Hause nehmen können.
<G-vec00179-001-s532><take.bauen><en> Your material can be copied straight away in the office so that you can take it home with you immediately.
<G-vec00179-001-s533><take.bauen><de> Allerdings ist es ratsam, dass schwangere Frauen nicht zu viel Vitamin A zu sich nehmen – frage deinen Arzt oder Apotheker um genauere Ratschläge über die Bedürfnisse deines Babys zu erhalten.
<G-vec00179-001-s533><take.bauen><en> By contrast, pregnant women are advised not to take too much vitamin A – consult your physician or ask at your pharmacy to be adequately guided about your baby's needs.
<G-vec00179-001-s534><take.bauen><de> Bei solchen Banken zählt es zur guten Tradition, sich Zeit zu nehmen für den Kunden, seine persönliche Situation zu analysieren, seine Kapitaldienstfähigkeit zu prüfen, die zu finanzierende Immobilie emotionslos zu bewerten und den Kunden über die lang fristigen Chancen und Risiken umfassend aufzuklären.
<G-vec00179-001-s534><take.bauen><en> Part of the fine tradition that prevails at these banks is to take time for the customer, analyse their personal situation, review their ability to service the loan, assess the property to be financed in a detached manner, and provide the customer with a comprehensive explanation of the long-term risks and opportunities.
<G-vec00179-001-s535><take.bauen><de> Aber sein größter Traum ist: Wenn das Gedankenkarussell volle Fahrt aufnimmt, will er es trotzdem hinkriegen, freundlich mit dem Maskenbildner zu sprechen, sich Zeit mit dem Stage-Manager nehmen, fokussiert auf die Menschen um ihn herum zu sein, ja, genau genommen, die Musik-Party, die der MGP in Wirklichkeit ist, zu genießen.
<G-vec00179-001-s535><take.bauen><en> But the biggest dream is this: If the racing mindset going at full speed, he will still manage to talk nicely with the make-up artist, take time with the stage manager, focus on thosearound him, yes, actually enjoy the musical party the MGP really is.
<G-vec00179-001-s536><take.bauen><de> Und sie hatten vergessen, Brot mit sich zu nehmen, und hatten nicht mehr mit sich im Schiff denn ein Brot.
<G-vec00179-001-s536><take.bauen><en> And they forgot to take bread; and they had not in the boat with them more than one loaf.
<G-vec00179-001-s537><take.bauen><de> Um mit Schlafstörungen oder vielen anderen Gesundheitsproblemen fertig zu werden, ist der grundlegende Schritt, ausreichend Nährstoffe für einen gesunden Körper zu sich zu nehmen.
<G-vec00179-001-s537><take.bauen><en> To cope with sleeping disorder or many other health problems, the fundamental step is to take enough nutrients for a healthy body.
<G-vec00179-001-s538><take.bauen><de> Hier sollte man sich etwas Zeit nehmen um nach kleinen Sachen zu suchen.
<G-vec00179-001-s538><take.bauen><en> You could take some time to look for the little stuff here.
<G-vec00179-001-s539><take.bauen><de> Denn wenn kein Krieg war, konnte er nicht kommandieren und die Verantwortung tragen, und es gab keine Beute, von der er sich den größten Teil nehmen konnte.
<G-vec00179-001-s539><take.bauen><en> Because if there was no war, he couldn't command and carry responsibility, and there wouldn't be any loot from which he could take the lion's share.
<G-vec00179-001-s540><take.bauen><de> Sie scheinen wie ein echter Macho Kerl, wenn man sich ins Bett nehmen.
<G-vec00179-001-s540><take.bauen><en> You seem like an actual manly man when you take her to bed.
<G-vec00179-001-s541><take.bauen><de> 2007-11-13 22:16:19 - Die Wahl eines Network-Marketing Gelegenheit - 5 roten Fahnen Obwohl die Network-Marketing bietet das Potenzial für langfristige Gewinne Restwert auf Ihrer ursprünglichen Bemühungen ist es wichtig, sich die Zeit nehmen, zunächst die Möglichkeit zu wählen, die am besten geeignet, um Ihre Interessen und Marketing-Fähigkeiten.
<G-vec00179-001-s541><take.bauen><en> 2007-11-13 22:16:19 - Choosing a network marketing opportunity - 5 red flags Although network marketing offers the potential for long term residual profits on your original efforts, it is important to take the time initially to choose the opportunity that is best suited to your interests and marketing skills.
<G-vec00179-001-s542><take.bauen><de> Wir wären Ihnen sehr dankbar, wenn Sie sich die Zeit nehmen würden, um für uns abzustimmen.
<G-vec00179-001-s542><take.bauen><en> We would be very grateful if you would take the time to cast your vote for us in your favourite category.
<G-vec00179-001-s543><take.bauen><de> Häufig kommen Leute zum Kloster und sagen, dass es für den Geist eine große Erleichterung ist, hier draußen zu sein und dass sie diesen Geisteszustand gerne mit sich nehmen würden, wenn sie zurückkehren.
<G-vec00179-001-s543><take.bauen><en> Many times people come to the monastery and say that it's such a relief for the mind to be out here and they'd like to take that state of mind with them when they go back.
<G-vec00179-001-s544><take.bauen><de> Wenn Nando de Colo, Weems, Jackson werden nicht im Angriff widerstehen, wird Teodosic zweifellos auf sich die Veranwortung auch in Creation nehmen.
<G-vec00179-001-s544><take.bauen><en> Now, in the event that players like De Colo, Weems, Jackson, the bigmen are not on a good day and are not accurate, then Teodosic has to and definitely can take over in execution as well.
<G-vec00179-001-s545><take.bauen><de> "Man kann sich für die Wanderung entweder Proviant mitnehmen oder man isst in den „Casoni"", im Wald gelegenen Raststätten, wo man Salami und Käse lokaler Produktion mit einem Aglianico-Wein zu sich nehmen kann."
<G-vec00179-001-s545><take.bauen><en> "To avoid carrying too much, it is best to take a packed lunch or eat in the ""casoni"", snack bars in the woods where you can eat a plate of excellent salami and local cheeses while sipping Aglianico wine."
<G-vec00179-001-s546><take.bauen><de> Das Hauptschlafzimmer, ruhig, und an der RÃ1⁄4ckseite der Wohnung bietet Ihnen Zugang auf den sonnigsten Balkon, breit genug ist, damit Sie sich einen Stuhl nehmen können und Ihre Ruhe genießen können.
<G-vec00179-001-s546><take.bauen><en> The master bedroom, quiet, at the back of the apartment gives you access to the sunniest balcony, wide enough for you to take a chair and have your moment.
<G-vec00179-001-s547><take.bauen><de> Die Straßen-Route ist landschaftlich sehr reizvoll und Sie werden wahrscheinlich länger brauchen als unbedingt erforderlich ist, und sich die Zeit nehmen um die schöne Landschaft zu genießen.
<G-vec00179-001-s547><take.bauen><en> The road route is very scenic and you will probably take longer than is strictly necessary to take your time enjoying the beautiful landscape.
<G-vec00179-001-s548><take.bauen><de> Ein Teilnehmer Hungerstreik gestorben war - 64-jährige Alex Nedelko weigerte sich, Nahrung zu sich nehmen aus Solidarität mit den hungernden Frau und sein schwaches Herz nicht am dritten Tag stehen.
<G-vec00179-001-s548><take.bauen><en> One participant hunger strike had died - 64-year-old Alex Nedelko refused to take food out of solidarity with the starving wife, and his weak heart could not stand on the third day.
<G-vec00179-001-s549><take.bauen><de> Fragen Sie Ihren Arzt, ob Capecitabin mit anderen Medikamenten, die Sie zu sich nehmen, interagieren könnte.
<G-vec00179-001-s549><take.bauen><en> Ask your health care provider if capecitabine may interact with other medicines that you take.
<G-vec00179-001-s550><take.bauen><de> Wie man sich aber ein rechtmässiges Weib zu nehmen hat, so ist solches nach der Ordnung aus den Himmeln schon durch Moses verordnet worden und hat fürder bis ans Weltende dabei zu verbleiben.
<G-vec00179-001-s550><take.bauen><en> But how one should take a legal wife, this has already been decreed by Moses according to the order from heaven, and must remain in the future until the end of the world.
