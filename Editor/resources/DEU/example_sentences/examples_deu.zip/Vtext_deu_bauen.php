<G-vec00001-001-s190><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre, und stelle mir hier bereit sieben Farren und sieben Widder.
<G-vec00001-001-s190><build.bauen><en> 1 And Balaam said to Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00001-001-s191><build.bauen><de> 3 Und Salomo sandte zu Huram, dem König von Tyrus, und ließ ihm sagen: So wie du meinem Vater David getan und ihm Zedern gesandt hast, daß er sich ein Haus baue, um darin zu wohnen, so tue auch mir.
<G-vec00001-001-s191><build.bauen><en> 3 And Solomon sent to Huram king of Tyre, saying, As thou didst deal with David my father, and didst send him cedars to build him a house to dwell therein so do for me.
<G-vec00001-001-s192><build.bauen><de> Baue ein Modell eines deutschen Raketenwerfers aus dem Zweiten Weltkrieg.
<G-vec00001-001-s192><build.bauen><en> Build a model of a German rocket launcher from World War II.
<G-vec00001-001-s193><build.bauen><de> füge diese Karten deinem Arsenal hinzu und baue dein perfektes Deck.
<G-vec00001-001-s193><build.bauen><en> add these cards to your arsenal and build your perfect deck.
<G-vec00001-001-s194><build.bauen><de> und baue dem HERRN, deinem Gott, oben auf der Höhe dieses Felsens einen Altar und rüste ihn zu und nimm den andern Farren und opfere ein Brandopfer mit dem Holz des Ascherabildes, das du abgehauen hast.
<G-vec00001-001-s194><build.bauen><en> And build an altar to the LORD your God upon the top of this rock, in an orderly manner, and take the second bullock, and offer it upon it as a burnt offering with the wood of the grove which you shall cut down.
<G-vec00001-001-s195><build.bauen><de> Baue deinen Turm höher und höher und pass auf dass er nicht einstürzt.
<G-vec00001-001-s195><build.bauen><en> Build your tower higher and higher and make sure it doesn't collapse.
<G-vec00001-001-s196><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre und schaffe mir her sieben junge Stiere und sieben Widder.
<G-vec00001-001-s196><build.bauen><en> 1 And Balaam said unto Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00001-001-s197><build.bauen><de> Baue die ökologischste Stadt der Welt.
<G-vec00001-001-s197><build.bauen><en> Build the most ecologic city in the world
<G-vec00001-001-s198><build.bauen><de> Ich habe von der Firma PESTAS, welche Holzdominosteine in Österreich herstellt, ein Musterpaket zugeschickt bekommen und vergleiche in diesem Video die Steine mit meinen Dominos und baue ein paar kleine Beispielprojekte.
<G-vec00001-001-s198><build.bauen><en> I received a sample package from the company PESTAS which produces wooden dominoes in Austria. In this video, I compare the dominoes to the ones I frequently use and build up some smaller testing projects.
<G-vec00001-001-s199><build.bauen><de> "Baue die Eisenbahn deiner Träume im Modus ""Train Table"", in dem deine Fantasie sich ohne Rücksicht auf finanziellen oder wertbewerblichen Druck frei entfalten kann."
<G-vec00001-001-s199><build.bauen><en> "Build the model railroad of your dreams in ""Train Table"" mode, where your imagination is free from the pressures of finance or competition."
<G-vec00001-001-s200><build.bauen><de> Baue Tina Goldstein, platziere sie auf dem LEGO Toypad und schicke sie in das Spiel, wo sie mit Aguamenti Rätsel lösen und sich mit Protego vor Gegnern schÃ1⁄4tzen kann.
<G-vec00001-001-s200><build.bauen><en> Build and place the Tina Goldstein minifigure on the LEGO Toy Pad to send her into the game where she can cast Aguamenti to help solve puzzles and Protego to keep her safe from enemies.
<G-vec00001-001-s201><build.bauen><de> Baue die Modelle und setze ihn auf Posten.
<G-vec00001-001-s201><build.bauen><en> Build the models and sit him in position.
<G-vec00001-001-s202><build.bauen><de> Dann baue ich neben der Serienfertigung ein paar ganz besondere Ukulelen mit.
<G-vec00001-001-s202><build.bauen><en> When that happens, I often decide to build some special models.
<G-vec00001-001-s203><build.bauen><de> Erstelle einen Remix von neuen Tracks und baue deine Song-Bibliothek auf, indem du “Burning Down The House” von Talking Heads kaufst.
<G-vec00001-001-s203><build.bauen><en> Remix new tracks and build your song library by purchasing “Burning Down The House” by Talking Heads.
<G-vec00001-001-s204><build.bauen><de> Für jede zehnte Flöte die ich baue pflanze ich hier einen kleinen Red Cedar Baum.
<G-vec00001-001-s204><build.bauen><en> For every tenth flute which I build I plant here a little Red Cedar tree.
<G-vec00001-001-s205><build.bauen><de> Baue deine eigenes Schloss und besiege andere Spieler in taktischen Kämpfen auf einer riesigen Weltkarte.
<G-vec00001-001-s205><build.bauen><en> Build your own castle and defeat other players in tactical fights on a giant world map.
<G-vec00001-001-s206><build.bauen><de> Baue deine Verteidigung und halte sie auf!Mächtige Krieger:Wähle Magier, Paladins oder Barbaren als deine Krieger und befehlige sie auf dem Schlachtfeld.
<G-vec00001-001-s206><build.bauen><en> Build your defense and stop them now! Mighty Warriors: You can choose wizard, paladin or barbarian as your warrior and deploy them to the battlefield.
<G-vec00001-001-s207><build.bauen><de> Baue ein Deck aus dem Standard-Kartenpool um eine bestimmte legendäre Kreatur oder einen Planeswalker herum auf und tritt in Duellen oder Multiplayer-Partien gegen einen oder mehrere Freunde an.
<G-vec00001-001-s207><build.bauen><en> Build a deck around a specific legendary creature or planeswalker from the Standard card pool, and battle against friends in one-on-one or multiplayer free-for-all games.
<G-vec00001-001-s208><build.bauen><de> Baue den Truck, schnall den Fahrer an und bezwinge jedes Hindernis mit den massiven Reifen und dem leistungsstarken Motor.
<G-vec00001-001-s208><build.bauen><en> Build the truck, Schnall to the driver and defeat any obstacle with the massive tires and powerful engine.
<G-vec00001-001-s107><construct.bauen><de> Baue zuerst die wichtigsten Gebäude - Bauernhöfe, Bergwerke und Häuser, um genug Nahrung, Eisen und Gold zu erwirtschaften.
<G-vec00001-001-s107><construct.bauen><en> First of all construct necessary buildings – farms, mines and houses to receive enough food, iron and gold.
<G-vec00001-001-s108><construct.bauen><de> Baue in Dungeons II für PS4 ein Reich der Finsternis auf.
<G-vec00001-001-s108><construct.bauen><en> Construct a dark empire in Dungeons II on PS4.
<G-vec00001-001-s109><construct.bauen><de> Baue das weltbekannte Kolosseum und erfahre mehr über uralten Anekdoten in diesem schnellen Zeitmanagementspiel.
<G-vec00001-001-s109><construct.bauen><en> Construct the iconic Roman Colosseum and learn ancient anecdotes in this fast-paced Time Management game.
<G-vec00001-001-s110><construct.bauen><de> Baue ihn auf Felder, auf denen Vulkangold, der rote Rohstoff, zu finden ist.
<G-vec00001-001-s110><construct.bauen><en> Construct it on squares where vulcanic gold, the red ressource, is found.
<G-vec00001-001-s111><construct.bauen><de> Schalte über 300 einzigartige und coole Gebäude frei, baue und verbessere sie, halte deine Bürger bei Laune, schaffe Arbeitsplätze und sammle Geld von deinen Gebäuden.
<G-vec00001-001-s111><construct.bauen><en> Unlock over 300 unique and cool buildings, construct and upgrade them, keep your citizens happy, create jobs and collect cash from your buildings.
<G-vec00001-001-s069><assemble.bauen><de> Informationen Format 230x230x100 / 160x160x100 / 160x300x100mm, Dieses Set ist einfach zusammen zu bauen.
<G-vec00001-001-s069><assemble.bauen><en> Information Format 230x230x100 / 160x160x100 / 160x300x100mm, This set is easy to assemble.
<G-vec00001-001-s070><assemble.bauen><de> Wir liefern die Rotationshacke als ein kompletter Satz, aus dem man vier Arbeitsbreiten der Hacke bauen kann - 16, 22, 32 und 38 cm; es geht eigentlich um die Breite der Abdeckung.
<G-vec00001-001-s070><assemble.bauen><en> RP-T2/S is delivered as a complete set, you can assemble four working width of the rotary hoe - 16, 22, 32 and 38 cm, which is in fact width of the cover.
<G-vec00001-001-s071><assemble.bauen><de> Die geniale Selbstbaulösung für Ihren Montagetisch: WEINMANN liefert die Technik, Sie bauen den Tisch (VarioTec).
<G-vec00001-001-s071><assemble.bauen><en> The ideal self assembly solution for your production: WEINMANN provides the technology - you assemble the table (VarioTec).
<G-vec00001-001-s072><assemble.bauen><de> Montagetisch als Selbstbaulösung: WEINMANN liefert die Technik, Sie bauen den Tisch (VarioTec).
<G-vec00001-001-s072><assemble.bauen><en> The ideal self assembly solution for your production: WEINMANN provides the technology - you assemble the table (VarioTec).
<G-vec00001-001-s073><assemble.bauen><de> Wir liefern RP-T2/S als ein kompletter Satz, aus dem man vier Arbeitsbreiten der Hacke bauen kann - 16, 22, 32 und 38 cm, es geht eigentlich um die Breite der Abdeckung.
<G-vec00001-001-s073><assemble.bauen><en> RP-T2/S is delivered as a complete set, you can assemble four working width of the rotary hoe - 16, 22, 32 and 38 cm, which is in fact width of the cover.
<G-vec00001-001-s074><assemble.bauen><de> Kuala Lumpur - DRB-HICOM Berhad und die Volkswagen AG, Europas größter Autobauer, werden gemeinsam 1 Milliarde Ringgit (etwa 250 MIllionen Euro) in den nächsten sechs Jahren investieren, um künftig VW Autos in Malaysia zu bauen.
<G-vec00001-001-s074><assemble.bauen><en> Kuala Lumpur - DRB-HICOM Bhd (1619)and Volkswagen AG, the largest carmaker in Europe, will collectively invest close to RM1 billion over the next five to six years mainly to set up the infrastructure to assemble VW vehicles in Malaysia.
<G-vec00001-001-s075><assemble.bauen><de> 'Wir besitzen nun ein neues Set an Bausteinen, aus denen wir viele verschiedene neue quasikristalline Strukturen bauen können', erklären die TUM Physiker.
<G-vec00001-001-s075><assemble.bauen><en> 'We now have a new set of building blocks that we can use to assemble many different new quasicrystalline structures.
<G-vec00001-001-s076><assemble.bauen><de> Guncrafter - es ist ein großer Designer für Android, die allen Fans von Minecraft ansprechen wird, sowie diejenigen, die zu erfinden und bauen ihre eigenen Produkte lieben.
<G-vec00001-001-s076><assemble.bauen><en> Guncrafter - it's a great designer for Android, which will appeal to all fans of Minecraft, as well as those who love to invent and assemble their own products.
<G-vec00001-001-s077><assemble.bauen><de> Werde zum ninja und lernt neue tricks des Spinjitzu-set Nya - Meister des Spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s077><assemble.bauen><en> Become a ninja and learn the new tricks of Spinjitzu with the set Nya - Master of Spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s078><assemble.bauen><de> Werde zum ninja und lernt neue tricks des Spinjitzu mit dem satz von zane-meister des spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s078><assemble.bauen><en> Become a ninja and learn the new tricks of Spinjitzu set, jay-master of spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s079><assemble.bauen><de> Das Unternehmen wird jede Stunde 30 Autos bauen, früher waren es 25 bis 27 Autos pro Stunde.
<G-vec00001-001-s079><assemble.bauen><en> Now the enterprise will assemble 30 cars every hour, whereas previously this figure was around 25-27 cars per hour.
<G-vec00001-001-s080><assemble.bauen><de> Bringen sie ihre technik Spinjitzu auf einer anderen ebene mit dem set von Kai - Meister des Spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s080><assemble.bauen><en> Bring your technical Spinjitzu on another level with the set of Kai - a Master of Spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s081><assemble.bauen><de> """Ich konstruiere komplette Fahrzeuge mit geringen Toleranzen von Grund auf selbst und wir bauen die Fahrzeuge mit einem vierköpfigen Team zusammen"", sagt Palatov."
<G-vec00001-001-s081><assemble.bauen><en> """I design complete cars, featuring tight tolerances, from scratch by myself, and we assemble the cars with a team of four,"" Palatov says."
<G-vec00001-001-s082><assemble.bauen><de> Das set enthält auch das auto des Skorpions mit zangen und schwanz möbel, mehr eine gasse mit einer mauer mit fenster und schiebedach, rampe mit doppeltem anschluss, großes spinnennetz aus draht, spinnennetz, flexibel und ein katapult bauen.
<G-vec00001-001-s082><assemble.bauen><en> The set also contains the cars of the Scorpion with pincers and a tail mobile, more an alley with a wall with window opening, ramp, dual-link, large spider web, thread of spider's web, is flexible and a catapult to assemble.
<G-vec00001-001-s083><assemble.bauen><de> Dennoch, wie Ziegelsteine gebraucht werden können, um viele unterschiedliche Strukturen zu bauen, sind die Tubulin-Untergruppen in den Mikrotubuli der Zellen untereinander identisch.
<G-vec00001-001-s083><assemble.bauen><en> Nevertheless, like bricks that can be used to assemble many different structures, the tubulin subunits in the cell's microtubules are identical to one another.
<G-vec00001-001-s209><build.bauen><de> Wir nutzen, wo es möglich ist, öffentliche Förderprogramme, um bezahlbare Wohnungen zu bauen.
<G-vec00001-001-s209><build.bauen><en> Wherever possible, we take advantage of public subsidy programs to build affordable housing.
<G-vec00001-001-s210><build.bauen><de> Ob Sie eine Offshore Plattform bauen oder an einem Raffinerie Shutdown arbeiten, sie kämpfen täglich damit die Ausfallzeiten zu reduzieren.
<G-vec00001-001-s210><build.bauen><en> Whether you build an offshore platform or you work on a refinery shutdown, you fight daily for reducing operational downtime.
<G-vec00001-001-s211><build.bauen><de> Tage später begann das Gerücht die Runde zu machen, dass der Hexer von Bargota, wie sie Juanes nannten, eines Nachts den Teufel angerufen habe und sich bösartiger Geister bedient habe, um in einer einzigen Nacht ein Haus zu bauen.
<G-vec00001-001-s211><build.bauen><en> A few days later rumours spread that the?Brujo de Bargota?, which was Juanes' nickname, had invoked the Devil one night and had made use of evil genies to build his house in just one night.
<G-vec00001-001-s212><build.bauen><de> Aus der Zusammenarbeit als Vorzugslieferant mit Volvo Construction Equipment ergeben sich die Möglichkeiten, die operativen Abläufe zu konsolidieren und eine neue Produktionsstätte in Edsberg in Sollentuna zu bauen.
<G-vec00001-001-s212><build.bauen><en> The Preferred Supplier Agreements with Volvo Construction Equipment creates conditions to consolidate operations and build a new production plant in Sollentuna, Sweden.
<G-vec00001-001-s213><build.bauen><de> Es ist geplant, ein weiteres Stockwerk (weitere 90 qm) zu bauen, dann ist die gesamte Wohnfläche würde der Fläche von 180 qm werden Es ist ein wunderbarer Blick aufs Meer vom Haus.
<G-vec00001-001-s213><build.bauen><en> It is planned to build one more storey (additional 90 sq m), then the total living area would be of the surface of 180 sq m. There is a marvellous sea-view from the property.
<G-vec00001-001-s214><build.bauen><de> Nur 2 km von der historischen Stadt Alcobaca und 10 km von den Stränden (Nazare und Sao Martinho do Porto) entfernt, hat dieses Grundstück eine Gesamtfläche von 1.077 m2, und es ist erlaubt, 60% der Gesamtgröße zu bauen.
<G-vec00001-001-s214><build.bauen><en> Only 2 kms from the historical town of Alcobaca and 10 kms from the beaches (Nazare and Sao Martinho do Porto) This plot of land has a total of 1.077m2, and it is allowed to build 60% of the total size.
<G-vec00001-001-s215><build.bauen><de> Wir mögen Fehler begehen, denn wir bauen eine Welt mit gebrochenen Strohhalmen.
<G-vec00001-001-s215><build.bauen><en> We may err, for we build a world with broken straws.
<G-vec00001-001-s216><build.bauen><de> Alles in allem werden die Habs benötigen, um ihre Ein Spiel gegen Calgary zu bringen, wenn sie sich auf letzten Samstag den Sieg über die Flyers bauen wollen.
<G-vec00001-001-s216><build.bauen><en> All in all, the Habs will need to bring their A game against Calgary if they want to build on last Saturday’s win over the Flyers.
<G-vec00001-001-s217><build.bauen><de> Genug Platz, um einen Pool zu bauen.
<G-vec00001-001-s217><build.bauen><en> Enough space to build a pool.
<G-vec00001-001-s218><build.bauen><de> Und das ist richtig – er ließ sie sogar nach Rothschilds Kolonien in Palästina auswandern,, ihr Geld mitnehmen und erlaubte ihnen, Waren aus Deutschland zu importieren, um die Kolonien zu bauen – und hatte einen VERTRAG MIT DEN ZIONISTEN DIESBEZÜGLICH: DAS HAAVARA TRANSFER AGREEMENT.
<G-vec00001-001-s218><build.bauen><en> And that ́s right – he even let them take their money with them and allowed them to import goods from Germany to build Rothschild ́s colonies in Palestine – and THE ZIONISTS HAD A TREATY WITH THE ZIONISTS ON THIS MATTER: THE HAAVARA TRANSFER AGREEMENT.
<G-vec00001-001-s219><build.bauen><de> Das BAS-Programm bietet Personen mit einem Abschluss oder eine gleichwertige Gelegenheit auf die grundlegenden Fähigkeiten, die durch durch die Vollendung der oberen Abteilung Kurs in Management- und Führungspraktiken ihre Associate-Studiengänge erreicht zu bauen.
<G-vec00001-001-s219><build.bauen><en> The BAS program provides individuals with an associate's degree or equivalent the opportunity to build upon the foundational skills attained through their associate's degree programs by completing upper-division coursework in management and leadership practices.
<G-vec00001-001-s220><build.bauen><de> Der New Baghdad-Tisch ist schwierig zu bauen, ein filigranes Puzzle in Form eines Stadtplans.
<G-vec00001-001-s220><build.bauen><en> The New Baghdad table is difficult to build, a delicate puzzle in the shape of the city map.
<G-vec00001-001-s221><build.bauen><de> Bauen Sie eine tiefere Bräune auf, indem Sie es täglich erneut auftragen, bis die gewünschte Farbtiefe erreicht ist.
<G-vec00001-001-s221><build.bauen><en> Build a deeper tan by reapplying daily until the desired depth is achieved.
<G-vec00001-001-s222><build.bauen><de> "Meister CVV sagte: ""Ich weiß, dass ihr diese Brücke nicht bauen könnt, weil ihr wie vom Denkvermögen eines Moskitos begrenzt werdet."
<G-vec00001-001-s222><build.bauen><en> "Master CVV said: ""I know that you cannot build this bridge, because you are confined as by the mind of a mosquito."
<G-vec00001-001-s223><build.bauen><de> Die Wahl hängt davon ab, was Sie vorhaben, ein Haus zu bauen: Telefonzentrale oder quadratisch Protokoll.
<G-vec00001-001-s223><build.bauen><en> Their choice depends on what you are going to build a house: switchboard or square log.
<G-vec00001-001-s224><build.bauen><de> Karl der Große gibt seinem Sohn Louis le Débonnaire den Auftrag, auf der Insel Antros einen Leuchtturm zu bauen.
<G-vec00001-001-s224><build.bauen><en> 9th C Charlemagne asks his son Louis le Débonnaire to build a first tower on the island of Antros.
<G-vec00001-001-s225><build.bauen><de> Als mir dann ein Freund von den abenteuerlichen Geschichten die sein Vater während des zweiten Weltkrieges mit dieser Maschine erlebt hat erzählte, stand für mich fest: Dieses Flugzeug mußt du bauen.
<G-vec00001-001-s225><build.bauen><en> When a friend told me about his father's adventures during World War II flying this aircraft I was hooked: I must build this machine.
<G-vec00001-001-s226><build.bauen><de> Um den Feind zu begegnen, wir brauchen, um zu bauen und sicher stärken Sie Ihre eigene Burg.
<G-vec00001-001-s226><build.bauen><en> To counter the enemy, we need to build and safely strengthen your own castle.
<G-vec00001-001-s227><build.bauen><de> Während der Kinderführung erkunden wir die Ausstellung und bauen anschließend unsere eigenen Stadtminiaturen.
<G-vec00001-001-s227><build.bauen><en> We will explore their ideas during the guided tour and build our own models afterwards.
<G-vec00001-001-s112><construct.bauen><de> Es ist ideal für die gewerbliche Entwicklung, da es eine Bauerlaubnis für kommerzielles Gebäude gibt, mit dem Sie ein Hotel mit bis zu 2,600 m² bauen können.
<G-vec00001-001-s112><construct.bauen><en> It is ideal for professional development as there is a high commercial building ratio, which allows you to construct a hotel of up to 2,600 m².
<G-vec00001-001-s113><construct.bauen><de> Präzisiert, dass die Investition plan mittelfristig Brünett“ und dass die Schiffe Teil von eigener Business „Than Shipping 2013 sind, die erst PCTC macht, die die Gesellschaft entschieden hat, nach dem Konkurs von Lehman Brothers in 2008 zu bauen, hat NYK erklärt, dass eine Erhöhung von der Bewerbung von PCTC und dass die vier neuen Schiffe Post in der lage in den aus panama Kanal einmal zu durchreisen dass vorherwerden Einheit sein wird seine Erweiterung im Herbst von 2014 ergänzt sieht.
<G-vec00001-001-s113><construct.bauen><en> Specifying that the investment takes part of own in the mid term business plan “Blackberries Than Shipping 2013” and that the ships are the first PCTC that the company has decided to construct after the failure of Lehman Brothers in 2008, NYK has explained that it previews a rise of the question of PCTC employment and that the four new ships will be unit post-Panamax in a position to journeying once in the Panamanian channel that will be completed its increase in the autumn of 2014.
<G-vec00001-001-s114><construct.bauen><de> Mit TrySim Lite können Sie Anlagen beliebiger Größe bauen und steuern.
<G-vec00001-001-s114><construct.bauen><en> With TrySim Lite you can construct and control machines of any size.
<G-vec00001-001-s115><construct.bauen><de> Dies deutet darauf hin, dass Ihr Körper kann optimal funktioniert Fett zu schmelzen und Muskelgewebe aller Zeiten zu bauen, wenn Sie trainieren.
<G-vec00001-001-s115><construct.bauen><en> This indicates that your body can jobs optimum to shed fat and also construct muscle mass all time when you are exercising.
<G-vec00001-001-s116><construct.bauen><de> Die crocieristico amerikanische Gruppe Carnival hat Corporation ein Abkommen mit der Regierung von Bahamas von einem neuen Kai im Hafen von Half Moon Cay von der kleinen Insel von Little und gekennzeichnet San Salvador, um zwei neue hafen Infrastrukturen für die Kreuzfahrten zu bauen, das bahamense vor von der Inselgruppe abreist, Bahamainseln die die Durchführung von einer neuen Zwischenlandung im südlichen Teil von der Insel von Grand vorhersieht.
<G-vec00001-001-s116><construct.bauen><en> The crocieristico group American Carnival Corporation has signed an agreement with the government of Bahamas in order to construct two new harbour infrastructures for the cruises that the realization of a new port of call in the southern part of the island of Grand Bahamas previews and of a new dock in the port of Half Moon Cay of the small island of Little San Salvador that takes part of the archipelago bahamense.
<G-vec00001-001-s117><construct.bauen><de> "Die zu assoziieren Unternehmen sind deswegen sehr sehr viel machen, eine konkrete Gelegenheit sich eine Professionalität bauen"", dass sie und dies läuft zu der Suche von den technologisch vorbereitet Managern repräsentieren den erst Schritt von einem bestimmten gestaltungs Kurs sind zu einer optimalen Aufwendung zu gelangen."
<G-vec00001-001-s117><construct.bauen><en> "For this the companies associated are very many to MAKE that they technologically are on the lookout for prepared managers and these run represent the first step of a formative distance destined to land to an optimal employment, a concrete opportunity in order to construct a professionality""."
<G-vec00001-001-s118><construct.bauen><de> Diese Verbindungen sind feste gesunde Proteine, wenn sie verwendet werden, die Muskelmasse zu bauen.
<G-vec00001-001-s118><construct.bauen><en> These materials are strong healthy proteins when they are used to construct lean muscle mass.
<G-vec00001-001-s119><construct.bauen><de> Er beschloss tatsächlich, es in den Ruinen des alten Stadttheaters zu bauen, das im Bürgerkrieg zerstört worden war.
<G-vec00001-001-s119><construct.bauen><en> He actually decided to construct it inside the ruins of the old Municipal Theatre that had been destroyed in the Civil War.
<G-vec00001-001-s120><construct.bauen><de> "Dazu sagt Peter Jenelten, stellvertretender Group CEO und Leiter Marketing & Sales: „Stadler ist sehr stolz, nicht nur erstmals Züge nach Slowenien liefern zu dürfen, sondern in einer Beschaffung gleich eine aufeinander abgestimmte Reihe unterschiedlicher Fahrzeuge zu bauen: Eine Flotte wie aus einem Guss""."
<G-vec00001-001-s120><construct.bauen><en> "Peter Jenelten, Deputy Group CEO and Head of Marketing & Sales, comments, ""Stadler is very proud not only to be delivering trains to Slovenia for the first time, but also to be able to construct a complete series of different vehicles that have been coordinated with each other to form a uniform fleet."""
<G-vec00001-001-s121><construct.bauen><de> Möglichkeit, ein Schwimmbad zu bauen.
<G-vec00001-001-s121><construct.bauen><en> Possibility to construct a swimming pool.
<G-vec00001-001-s122><construct.bauen><de> „Wir kaufen alle Materialien vor Ort und bauen mit ortsansässigen Handwerkern und den Einwohnern gemeinsam“, erklärt Naeim, der bisher fast immer selbst alle Projekte geleitet hat.
<G-vec00001-001-s122><construct.bauen><en> “We buy all our materials on location and construct it employing local tradespeople and the residents together,” explains Naeim, who until now almost always led the projects personally.
<G-vec00001-001-s123><construct.bauen><de> Wir projektieren, bauen, liefern und installieren den elektromechanischen Maschinensatz für Ihre Wasserkraftanlage.
<G-vec00001-001-s123><construct.bauen><en> We project, construct, deliver and install the electromechanical unit for your hydropower plant.
<G-vec00001-001-s124><construct.bauen><de> Das wäre so, als ob wir ein Haus bauen wollten, ohne zuerst sein Fundament zu legen.
<G-vec00001-001-s124><construct.bauen><en> It will be as though we want to construct a house without laying down first its foundations.
<G-vec00001-001-s125><construct.bauen><de> Das hat der Trans Adriatic gemacht bekannt Rohrleitung, die von dem schweizerischen EGL, von und von teilnimmt Jointventure (42.5%), dem Norweger Statoil, der Deutschen E.ON Ruhrgas (42.5%) (15.0%, dass es) gebildet wird und zu bauen, um die Gasfernleitung zu entwerfen.
<G-vec00001-001-s125><construct.bauen><en> The Trans Adriatic has announced Pipeline, joint venture participated from Swiss EGL (42.5%), from the Norwegian Statoil (42.5%) and from German E.ON Ruhrgas (15.0%) that it is constituted in order to plan and to construct the gas pipeline.
<G-vec00001-001-s126><construct.bauen><de> Die Entscheidung, die Zimmer unter der Erde zu bauen, geht aus der Tatsache hervor, dass das Hofgut Majerija ein Kulturdenkmal ist, das wir mit der neuen Struktur nicht entwerten wollten, sowie aus der Tatsache, dass wir uns buchstäblich zwischen den Wein- und Obstgärten befinden und wir auf diese Weise keinesfalls die wunderschöne natürliche Landschaft beeinflussen.
<G-vec00001-001-s126><construct.bauen><en> They are placed under the herb garden, right by our 300 year old homestead. The decision to construct rooms under the surface of the earth stems from the fact, that Majerija is a cultural monument, whose value we did not wish to reduce with a new building, and due to the fact that we are located literally between vineyards and orchards and, in this way, we do not influence changes of the beautiful, natural landscape.
<G-vec00001-001-s127><construct.bauen><de> Costituire reist sechs Zollfreigebiete in den sardischen strategischen Häfen für see groß jedes Jahr die Herausforderung auf dem möglichen Luxus in Costa Smeralda zu bekräftigen neue Modalitäten von der Aufnahme zu bauen von jen 70% von der weltweiten Flotte von dem Megabyte ab mehrheitlich Yacht, um eine Quote zu wiedererlangen, der jedes Jahr Mittelmeer wie die operative bevorzugt Fläche auswählt.
<G-vec00001-001-s127><construct.bauen><en> Costituire six bonded areas in strategic the Sardinian ports for large the nautical one, to restate every year the challenge on the possible luxury in Costa Smeralda, to construct to new acceptance modality in order to recover a quota leave majority of those 70% of the world-wide fleet of mega yacht that chooses every year the Mediterranean like preferred operating area.
<G-vec00001-001-s128><construct.bauen><de> Hier klicken Blöcke Freisetzung und bauen einen Turm so hoch wie möglich ist.
<G-vec00001-001-s128><construct.bauen><en> Click to release blocks and construct a tower that is as tall as possible.
<G-vec00001-001-s129><construct.bauen><de> Anfang 2001 wurde den männlichen Häftlingen befohlen, in der Frauenabteilung ein Gebäude zu bauen.
<G-vec00001-001-s129><construct.bauen><en> In early 2001, the male detainees were ordered to construct a building in the women's division.
<G-vec00001-001-s130><construct.bauen><de> Im Oktober, nach dem Sturz Horthys und der Machtübernahme der faschistischen Pfeilkreuzler unter Ferenc Szalasi, wurden viele tausend Budapester Juden in Gewaltmärschen an die Grenzen des Reichs getrieben, um Schutzwälle gegen die sowjetischen Panzer zu bauen.
<G-vec00001-001-s130><construct.bauen><en> "After the downfall of the Horthy government in October 1944, and the assumption of power by Ferenc Szalasi and his ""fascist"" Arrow Cross movement, thousands of Budapest Jews were force-marched to the border of the Reich to construct ramparts against Soviet tanks."
<G-vec00001-001-s119><erect.bauen><de> Aber ich finde den Wettlauf falsch, nach dem jede Stadt jetzt ihr Jüdisches Museum bauen muss.
<G-vec00001-001-s119><erect.bauen><en> Even so, I do not agree with the competition to erect a Jewish museum in every city.
<G-vec00001-001-s120><erect.bauen><de> Auch in diesem Geschäftsfeld wollen wir sowohl in der Ostsee als auch in der Nordsee nach dem Abschluss der Genehmigungsplanung der Projekte, diese Windparks finanzieren, bauen und anschließend betreiben.
<G-vec00001-001-s120><erect.bauen><en> In this business field as well, we intend to finance, erect and finally operate these windparks in the Baltic Sea as well as in the North Sea after closing of approval.
<G-vec00001-001-s121><erect.bauen><de> Sie sind gezwungen, von minderwertigem und oftmals schädlichem Material für die Herstellung ihrer Produkte Gebrauch machen, schäbige Wohnungen zu bauen, gesundheitsschädliche Lebensmittel zu konsumieren; unzählige Handlungen zu vollziehen, die dazu gedacht sind, den Konsumenten zu betrügen.
<G-vec00001-001-s121><erect.bauen><en> They are compelled to make use of inferior and often actually injurious materials in the fabrication of their products, to erect wretched dwellings, to put up spoiled foodstuffs and to perpetrate innumerable acts that are planned to cheat the consumer.
<G-vec00001-001-s122><erect.bauen><de> Und dann gibt es noch jene, die Bücher überhaupt nicht lesen, sondern sie nur benutzen, um Skulpturen zu bauen.
<G-vec00001-001-s122><erect.bauen><en> And then there are people who never read books at all, but merely use them to erect sculptures.
<G-vec00001-001-s123><erect.bauen><de> Mit anderen Worten, diese Bauwerke wären heutige Ingenieure NICHT in der Lage auf die Weise zu bauen, wie sie gebaut und aus den Materialien, die benutzt wurden.
<G-vec00001-001-s123><erect.bauen><en> In other words, even present engineers would NOT be able to erect these structures in the manner they were erected and from materials that were used in their construction.
<G-vec00001-001-s124><erect.bauen><de> In Roads of Rome müssen Sie der Hauptfigur in all seinen Missionen helfen: gehen Sie durch barbarische Länder, bauen Straßen, bauen Sie neue Städte auf, bauen Sie Häuser oder Gebäude und erweitern Sie Roms Macht und Einfluss.
<G-vec00001-001-s124><erect.bauen><en> In Roads of Rome you’ll have to help the main character in all his missions: go through barbarian lands, build roads, set up new cities, erect houses or buildings and expand Rome’s power and influence.
<G-vec00001-001-s125><erect.bauen><de> Er schlug vor, das Bauprojekt zu verbessern, sowie dort einen Platz zu bauen und das Denkmal des Volksdichters von Usbekistan und Karakalpakstan, des Helden Usbekistans, Ibroyim Yusupov, aufzustellen.
<G-vec00001-001-s125><erect.bauen><en> He instructed to improve the school project, design a square and erect there a monument to the memory of people's poet of Uzbekistan and Karakalpakstan, Hero of Uzbekistan I.Yusupov.
<G-vec00001-001-s126><erect.bauen><de> Hirth half der Familie Schneider mit Materialien aus verlassenen Häusern, damit sie sich in den Trümmerhaufen von Stuttgart eine Unterkunft bauen konnten.
<G-vec00001-001-s126><erect.bauen><en> Hirth helped the Schneiders to salvage some materials from derelict buildings and erect for themselves a shelter amid the rubble of Stuttgart.
<G-vec00001-001-s127><erect.bauen><de> Oder wir werden zu Isolationisten und bauen wie die USA zu Mexiko und Israel zu Palästina einen Stacheldraht-Wall.
<G-vec00001-001-s127><erect.bauen><en> Or we isolate ourselves and erect walls of barbed wire, as the US has done to Mexico and Israel to Palestine.
<G-vec00001-001-s128><erect.bauen><de> Aus großen Kalkplatten bauen wir uns deshalb einen Ofen, der nach oben und zu den Seiten abgeschlossen ist und lediglich nach vorne Licht und Wärme abstrahlt.
<G-vec00001-001-s128><erect.bauen><en> Out of large limestone plates we therefore erect an oven that is closed at the sides and on top and emits warmth and light only to front.
<G-vec00001-001-s114><establish.bauen><de> Wir entwickeln digitale Lösungen für die Gastronomie, bauen die Vertriebskanäle für unsere eigenen digitalen Lösungen und für die von Startups und betreuen unsere METRO Accelerator Programme.
<G-vec00001-001-s114><establish.bauen><en> We develop digital solutions for the food service industry and establish distribution channels both for our own digital solutions and those created by startups.
<G-vec00001-001-s115><establish.bauen><de> Bauen Sie Ihre Präsenz im Vereinigten Königreich (UK) mit .CO.UK auf - einer der beliebtesten Domainendungen der welt.
<G-vec00001-001-s115><establish.bauen><en> Establish your presence in the United Kingdom (UK) with .CO.UK, one of the most popular domain extension in the world.
<G-vec00001-001-s116><establish.bauen><de> Mit unserem Komplettlösungsangebot zur verfahrenstechnischen und funktionalen Sicherheit bauen Sie in Ihrem gesamten Unternehmen eine nachhaltige Sicherheitskultur auf.
<G-vec00001-001-s116><establish.bauen><en> We provide a comprehensive set of process and functional safety management capabilities to establish a sustainable safety culture.
<G-vec00001-001-s117><establish.bauen><de> Microsoft plant bis 2019, eigene Rechenzentren in der Schweiz zu bauen.
<G-vec00001-001-s117><establish.bauen><en> Microsoft is planning to establish new data centres in Switzerland by 2019.
<G-vec00001-001-s118><establish.bauen><de> 5.Looking schicken Ihre Untersuchung nach und hoffend bauen Sie geschäftliche Beziehungen mit Ihnen für eine lange Zeit auf.
<G-vec00001-001-s118><establish.bauen><en> 5.Looking forward your inquiry and hoping establish business relationship with you for a long time.
<G-vec00001-001-s119><establish.bauen><de> Das Karlsruher Institut für Technologie (KIT) und die SAP SE bauen eine strategische Partnerschaft auf.
<G-vec00001-001-s119><establish.bauen><en> Karlsruhe Institute of Technology (KIT) and SAP SE (NYSE: SAP) establish a strategic partnership.
<G-vec00001-001-s120><establish.bauen><de> Wir bauen und halten Kontakte mit den hervorragenden Organisationen und Personen, die gegen die Klimawendel kämpfen, mit ihrer Hilfe entwickeln wir uns dauernd, ihre Aufsicht macht unsere Arbeit ein Spruchband.
<G-vec00001-001-s120><establish.bauen><en> We establish and maintain close relationships with the most outstanding organizations and individuals that are fighting against Climate Change. With their help we are continuously advancing and their supervision makes our work transparent.
<G-vec00001-001-s121><establish.bauen><de> Auf diese Weise bauen Sie Kontakte zu Gatekeepern und Key Playern in Ihrem jeweiligen Feld auf.
<G-vec00001-001-s121><establish.bauen><en> In this way you establish contacts to gatekeepers and key players in your respective field.
<G-vec00001-001-s122><establish.bauen><de> Sobald die Nahrung gefunden wird, bauen sie ihr Revier auf und bleiben für einige Tage dort, bis die Nahrung knapp wird.
<G-vec00001-001-s122><establish.bauen><en> Once food is found they establish their territory and remain for several days there until it becomes scarce.
<G-vec00001-001-s123><establish.bauen><de> Durch das Zusammenleben auf der Farm bauen die Teilnehmer engen Kontakt zu den Mitarbeitern und der Farmerfamilie auf und lernen viel über die lokale Kultur und Lebensweise.
<G-vec00001-001-s123><establish.bauen><en> By living together on the farm, the participants establish close contact with the employees and the farmer's family and learn a lot about the local culture and way of life.
<G-vec00001-001-s124><establish.bauen><de> Wir bauen für Sie einen Besucherdienst auf, der intern oder auf Wunsch auch extern umgesetzt werden kann.
<G-vec00001-001-s124><establish.bauen><en> We establish a visitors service for you that can be implemented internally or - if requested - externally.
<G-vec00001-001-s125><establish.bauen><de> Sie bauen sich ein Netzwerk auf durch monatliche Jour Fixe, Vorträge und Social Events.
<G-vec00001-001-s125><establish.bauen><en> You will establish a network via monthly meetings, speeched and social events.
<G-vec00001-001-s126><establish.bauen><de> Bauen Sie Glaubwürdigkeit und Vertrauen in Ihr Unternehmen auf.
<G-vec00001-001-s126><establish.bauen><en> Establish credibility and trust for the business.
<G-vec00001-001-s127><establish.bauen><de> Wir bauen strategische Kommunikation auf, organisieren den Kommunikations-Mix und messen den Erfolg Ihrer Kommunikationsmaßnahmen.
<G-vec00001-001-s127><establish.bauen><en> We establish a strategic communication, organize the communications mix and measure the success of your communication measures.
<G-vec00001-001-s128><establish.bauen><de> Sie bauen Wechselwirkungen, Verbindungen zwischen Ursache und Wirkung auf.
<G-vec00001-001-s128><establish.bauen><en> They establish relationships of correspondence, of cause and effect.
<G-vec00001-001-s129><establish.bauen><de> In ausführlichen Gesprächen erstellen wir nicht nur eine Dokumentation und Analyse der bisherigen Behandlungsmaßnahmen, sondern bauen auch eine vertrauensvolle Arzt-Patienten-Beziehung auf, die für die Lösung komplexer medizinischer Probleme so wichtig ist.
<G-vec00001-001-s129><establish.bauen><en> In detailed discussions we not only compile documentation and an analysis of the previous treatment measures but also establish a trusting physician-patient relationship, which is so extremely important in solving complex medical problems.
<G-vec00001-001-s130><establish.bauen><de> Registrieren Sie die perfekte Domain aus der .UK-Familie und bauen Sie Ihre Online-Präsenz im Vereinigten Königreich auf.
<G-vec00001-001-s130><establish.bauen><en> Register the perfect domain from the .UK family and establish your online presence in the United Kingdom.
<G-vec00001-001-s131><establish.bauen><de> Helligkeitskontraste bauen Dramaturgie auf und rücken Wichtiges in den Vordergrund.
<G-vec00001-001-s131><establish.bauen><en> Contrasts in brightness establish drama and place important elements in the foreground.
<G-vec00001-001-s132><establish.bauen><de> La Königspalast von Caserta wurde aus dem 1752 von gemacht Luigi VanvitelliUnd später von seinem Sohn Carlo, im Auftrag von Karl von Bourbon, um es als Drehpunkt des neuen Königreiches von Neapel zu bauen.
<G-vec00001-001-s132><establish.bauen><en> La Palace of Caserta was made from the 1752 from Luigi Vanvitelli, and later by his son Carlo, at the behest of Charles of Bourbon in order to establish it as the fulcrum of the new kingdom of Naples.
<G-vec00001-001-s084><assemble.bauen><de> Bauen Sie ein Team von 4 Personen Bosse zu töten oder von feindlichen Wellen im Survival-Modus Bounce.
<G-vec00001-001-s084><assemble.bauen><en> Assemble a team of 4 people to kill bosses or Bounce from enemy waves in survival mode.
<G-vec00001-001-s085><assemble.bauen><de> Bauen Sie die kleinen Stücke von Glas in einen Leiterrahmen mit Rillen und dann verschweißen die großen Stücke des Rahmens zusammen mit einer Lipidschicht auf der Glasoberfläche die Verwitterung zu verhindern, und Befestigungs.
<G-vec00001-001-s085><assemble.bauen><en> Assemble the small pieces of glass into a lead frame with grooves and then weld the large pieces of the frame together with a lipid coat on the glass surface to prevent the weathering and fixing.
<G-vec00001-001-s086><assemble.bauen><de> Bauen Sie ein Team von Helden unbesiegbar im Spiel Ninja Turtles: Legends und gehen auf die Rettung der Ninja Turtles.
<G-vec00001-001-s086><assemble.bauen><en> Assemble a team of heroes invincible in the game Ninja Turtles: Legends and go to the rescue of the Ninja Turtles.
<G-vec00001-001-s087><assemble.bauen><de> Die Ausführung D wird in drei Teilen geliefert: l Schallwandler l Schallwandlerkabel l Elektronik für Wandmontage Bauen Sie diese Ausführung folgendermaßen zusammen: 1 Sechskantmutter (3) am Schallwandlerrohr lösen 2 Schallwandlerrohr von unten in die Montageöffnung G1 A ein-schieben 3 Sechskantmutter (3) festschrauben (SW 46) 4 Stecker aus Anschlusskopf unten herausziehen und in die Buchse des Schallwandlerrohrs stecken 5 Anschlusskopf auf das Schallwandlerrohr aufstecken.
<G-vec00001-001-s087><assemble.bauen><en> Version D is supplied in three parts: l Transducer l Transducer cable l electronics for wall mounting Assemble the version as follows: 1 Loosen the hexagon nut (3) on the transducer cable 2 Insert the transducer tube from below into the mounting opening G 1A 3 Fasten (SW 46) the hexagon nut (3) 4 Remove the plug from below out of the connection head and plug it into the socket of the transducer tube
<G-vec00001-001-s088><assemble.bauen><de> Bauen Sie diese Windturbine und erfahren Sie mehr über nachhaltige Konstruktionen.
<G-vec00001-001-s088><assemble.bauen><en> Assemble this wind turbine and learn about sustainable design.
<G-vec00001-001-s089><assemble.bauen><de> Bauen Sie ein Team von Helden und verschieben Sie sie entlang einer Grid-basierten Weg, um jede Mission erfolgreich abzuschließen.
<G-vec00001-001-s089><assemble.bauen><en> Assemble a team of heroes and move them along a grid-based path in order to complete each mission.
<G-vec00001-001-s090><assemble.bauen><de> Bauen Sie Ihr eigenes ..
<G-vec00001-001-s090><assemble.bauen><en> Assemble your own..
<G-vec00001-001-s091><assemble.bauen><de> Thrush Treatment - Bauen Sie ein Puzzle mit einem Bild von einem Hund.
<G-vec00001-001-s091><assemble.bauen><en> Thrush Treatment - Assemble a jigsaw puzzle with an image of a Dog.
<G-vec00001-001-s228><build.bauen><de> Johnny hat gelernt, wie man virtuelle Welten baut und diese Welt für Cleopatra und sich selbst erschaffen, damit sie so darin leben können, wie es hätte sein sollen.
<G-vec00001-001-s228><build.bauen><en> Johnny had learned how to build virtual worlds and had created this world for himself and Cleopatra to live in as it should have been.
<G-vec00001-001-s229><build.bauen><de> "Sollte das Windwerk CRABster Ihren Anforderungen nicht vollständig gerecht werden, dann baut DEMAN ein ""Custom Winch"" nach Maß."
<G-vec00001-001-s229><build.bauen><en> "If the CRABster does not completely conform to your needs, then DEMAN will build a ""custom winch "" for you."
<G-vec00001-001-s230><build.bauen><de> Das sind die Arten von Funktionen, die Tourismus-Management drool zu machen, und wie das Land erhebt mit seinen bestehenden Krise, ist es wahrscheinlich, dass nicht nur der Tourismus baut, sondern dass die Liste der Casinos von Mosambik wird wachsen mehr sicher.
<G-vec00001-001-s230><build.bauen><en> Those are the kinds of features that make tourism management drool, and as the country elevates out of its existing slump, it is likely that not only will tourism build, but that the list of Mozambique’s casinos will grow longer for sure.
<G-vec00001-001-s231><build.bauen><de> Dieses Projekt baut Vertrauen, Toleranz und Kollaborationen zwischen den Organisationen aus, die gemeinsam mit den Waldanreinergemeinschaften arbeiten.
<G-vec00001-001-s231><build.bauen><en> This project will enrich green cover and build confidence, tolerance and collaborations between organizations working among forest fringe communities to restore forests and build social mobility in the area.
<G-vec00001-001-s232><build.bauen><de> Auf der Basis dieser Fertigkeiten, deren Training ständig mit dem Gymnastizieren und damit dem Beweglichkeitstraining der Pferde einhergeht, baut dann das komplexe Wettkampftraining auf.
<G-vec00001-001-s232><build.bauen><en> These basic skills, always combined with gymnastics and mobility training, are required to build up the many and various specific competition training units.
<G-vec00001-001-s233><build.bauen><de> Das Museum of The Future, das Ende 2019 eröffnet wird, baut auf mehr als fünf Jahren temporärer immersiver Ausstellungen auf dem Weltregierungsgipfel in Dubai auf.
<G-vec00001-001-s233><build.bauen><en> The Museum of The Future, to be opened at the end of 2019, will build on more than five years of temporary immersive exhibitions at the world-government summit in Dubai.
<G-vec00001-001-s234><build.bauen><de> Das vorgeschlagene Joint Venture baut auf der Dynamik von Fuse™ Technologies, AGCOs zukunftsträchtigem Ansatz für die Präzisionslandwirtschaft und das Präzisionsmanagement von Maschinen.
<G-vec00001-001-s234><build.bauen><en> The proposed joint venture will build on the momentum of Fuse™ Technologies, AGCO’s next generation approach to precision agriculture and precision machine management.
<G-vec00001-001-s235><build.bauen><de> Jammern baut kein Netz.
<G-vec00001-001-s235><build.bauen><en> Moaning won't build a network.
<G-vec00001-001-s236><build.bauen><de> Springt ins kühle Wasser, übt euch im Schnorcheln oder baut Sandburgen, nur 15 Minuten vom Stadtzentrum entfernt.
<G-vec00001-001-s236><build.bauen><en> Take a dip, go snorkelling or build sand castles, all just 15 minutes away from the city centre.
<G-vec00001-001-s237><build.bauen><de> Bitte baut eine Brücke zwischen den Menschen und zwischen Ländern.
<G-vec00001-001-s237><build.bauen><en> Please build a bridge between people, among people and between countries.
<G-vec00001-001-s238><build.bauen><de> Baut bei euren Bemühungen zur Vorbereitung der Fünfhundertjahrfeier auf diesem soliden Fundament auf.
<G-vec00001-001-s238><build.bauen><en> In your efforts to prepare for the fifth centenary, build on this solid foundation.
<G-vec00001-001-s239><build.bauen><de> Es gibt einen Weg: Kämpft für die Mobilisierung der Macht von Arbeitern, Schwarzen und Einwanderern – Formiert Arbeiterverteidigungsgruppen – Brecht mit den Demokraten und baut eine Arbeiterpartei auf, um für internationale sozialistische Revolution zu kämpfen.
<G-vec00001-001-s239><build.bauen><en> There is a way: Fight to mobilize labor/black immigrant power – Build workers defense guards – Break with the Democrats and build a workers party to fight for international socialist revolution.
<G-vec00001-001-s240><build.bauen><de> Dazu konzipiert, baut und nimmt das IEFE, wenn nötig oder vom Kunden gewünscht, Prüfstände mit der passenden Messtechnik in Betrieb.
<G-vec00001-001-s240><build.bauen><en> Where necessary or requested by the client, IEFE will further design, build and commission test facilities with the related metrology.
<G-vec00001-001-s241><build.bauen><de> Ein nigerianisches Sprichwort sagt: In Krisenzeiten baut der Weise Brücken, der Törichte Wälle.
<G-vec00001-001-s241><build.bauen><en> A Nigerian proverb states that ‘in the moment of crisis, the wise build bridges and the foolish build dams’.
<G-vec00001-001-s242><build.bauen><de> Baut tolle LEGO Objekte, um neue Bereiche und Gegenstände zu entdecken.
<G-vec00001-001-s242><build.bauen><en> Build special LEGO objects to discover new areas and items.
<G-vec00001-001-s243><build.bauen><de> "Krone Easy Rider - Fünf Tonnen für alle Krone baut seine Kompetenz im Portfolio Reifen weiter aus und hat die Qualität seiner eigenen Baureihe ""Easy Rider"" einmal mehr verbessert."
<G-vec00001-001-s243><build.bauen><en> "Krone Easy Rider - Five tons across the range Krone continues to build its expertise in the tyre sector and has once more improved the quality of its own ""Easy Rider"" range."
<G-vec00001-001-s244><build.bauen><de> Der eine baut sein Haus auf einen Felsen; er richtet sein Leben also nach göttlichen Prinzipien und Maßstäben aus.
<G-vec00001-001-s244><build.bauen><en> Some build their houses upon a rock, meaning they live according to divine principles and standards.
<G-vec00001-001-s245><build.bauen><de> Was Schalamow anspricht, ist jedoch kaum dessen ausgefeilter Satzbau, sondern mehr Faulkners Fähigkeit, Buch für Buch eine vollkommen eigene Welt zu erschaffen, die durch eine gänzlich eigene Idiomatik (eine Sprache, die man nur in diesen Büchern spricht) zusammengehalten wird und in der jeder einzelne Text weiter an dem ihnen allen eigenen Symbol- und Motivkreis baut und ihn verstärkt.
<G-vec00001-001-s245><build.bauen><en> Faulkner’s baroque prose is of course light years away from Shalamov’s sternly purged and pared-down variety. It is hardly Faulkner’s elaborate sentence structure that appeals to Shalamov, however, but more his ability, in book after book, to conjure up a world that is completely and utterly itself, held together by an idiom of its own (a language only spoken in these books), where every single text continues to build on, and intensify, the set of symbols and motifs that run through them all.
<G-vec00001-001-s246><build.bauen><de> Die Gruppe um Heinz Billing baut in München und im italienischen Frascati die empfindlichsten Zylinderdetektoren weltweit.
<G-vec00001-001-s246><build.bauen><en> The group working with Heinz Billing build the world's most sensitive cylinder detectors in Munich and in Frascati, Italy.
<G-vec00001-001-s131><construct.bauen><de> Sie fragt beim ersten Start ab, in welchem Gewerk der Anwender tätig ist und baut anhand dieser Informationen das Menü mit allen relevanten Funktionen auf.
<G-vec00001-001-s131><construct.bauen><en> On initial start-up, the app asks in which trade the user works and uses this information to construct a menu containing all of the relevant functions.
<G-vec00001-001-s132><construct.bauen><de> Das Symbol funktioniet nach dem Prinzip der Selbstbegründung: es isoliert ein Fragment der Realität, gibt ihm zusätzliche Bedeutung, zusätzlichen Sinn, baut es bis zu einem selbständigen Ganzen aus, zur Norm des Einheitlichen.
<G-vec00001-001-s132><construct.bauen><en> Thus, the symbol functions by self-justification: by isolating a fragment of reality, it heightens its significance and meaning so as to construct it into an autonomous whole, into a norm of wholeness.
<G-vec00001-001-s133><construct.bauen><de> Aus allen diesen Informationen baut das Programm einen Befehl auf, wie und wohin sich zum Beispiel ein Greifarm bewegen soll und sendet ihn an die Gerätesteuerung.
<G-vec00001-001-s133><construct.bauen><en> The program uses all this information to construct a command, for example, as to how and where a gripper arm should move and sends it to the device control.
<G-vec00001-001-s134><construct.bauen><de> Zwar werden die Märkte immer internationaler, doch eines bleibt: ZARGES konstruiert und baut, ganz im Sinne des Gründers Walther Zarges, Alltagsprodukte aus Aluminium, die überall auf der Welt gebraucht werden.
<G-vec00001-001-s134><construct.bauen><en> Although the markets keep becoming more and more international, one thing remains the same: ZARGES continues to design and construct day-to-day aluminium products that are used everywhere in the world – much in the spirit of its founder.
<G-vec00001-001-s135><construct.bauen><de> Dies bedeutet, dass Sie liefern keine ausreichende Leistung für den menschlichen Körper Fett zu vergießen und Muskelgewebe baut in geeigneter Weise durch die Ausbildung.
<G-vec00001-001-s135><construct.bauen><en> This implies that you do not provide adequate power for the body to burn fat and construct muscle effectively through the training.
<G-vec00001-001-s136><construct.bauen><de> In seiner Freizeit baut er gerne Effektgeräte für seine Gitarre und handliche Verstärker in der Größe eines begehbaren Kleiderschranks.
<G-vec00001-001-s136><construct.bauen><en> In his spare time he likes to construct effect units for his guitar and handy boxes the size of walk-in closets.
<G-vec00001-001-s137><construct.bauen><de> Newpark Mats & Integrated Services führt nicht nur den Bau Ihrer Bohrstelle aus und wartet sie während des gesamten Bohrvorgangs, sondern baut, wartet und repariert auch Ihre Produktionsstätte, nachdem das Bohrloch fertiggestellt ist.
<G-vec00001-001-s137><construct.bauen><en> Newpark Mats & Integrated Services will not only complete the construction of your drilling location and maintain the location throughout the drilling process, but we will also construct, maintain and repair your production facility after the well has been completed.
<G-vec00001-001-s138><construct.bauen><de> Unser sonstiges F&E-Personal baut unter anderem in den Werkstätten Forschungsequipment oder arbeitet in der Verwaltung, zum Beispiel als Marktforscher oder Trendanalyst.
<G-vec00001-001-s138><construct.bauen><en> Our other R&D personnel construct research equipment in our workshops, or perform administrative functions in such fields as market research and trend analysis.
<G-vec00001-001-s139><construct.bauen><de> Als Generalunternehmer wurde die AE&E Inova, eine Tochter der VonRoll Inova AG, Schweiz, beauftragt, die unter der Gesamtkoordination der STEAG die schlüsselfertige Anlage plant und baut.
<G-vec00001-001-s139><construct.bauen><en> Prime engineering contractor is AE&E Inova, which is a subsidiary of VonRoll Inova AG, Switzerland, and will design and construct the turnkey plant under overall coordination by STEAG.
<G-vec00001-001-s456><build.bauen><de> Der Gesamtkomplex Zeche Zollverein in Essen wurde Ende der 20er Jahre gebaut und im Jahre 1986 stillgelegt.
<G-vec00001-001-s456><build.bauen><en> The coal pit Zeche Zollverein in Essen was build at the end of the 1920s and was closed down in the year 1986.
<G-vec00001-001-s457><build.bauen><de> So wisse nun und merke: von der Zeit an, da ausgeht der Befehl, daß Jerusalem soll wieder gebaut werden, bis auf den Gesalbten, den Fürsten, sind sieben Wochen; und zweiundsechzig Wochen, so werden die Gassen und Mauern wieder gebaut werden, wiewohl in kümmerlicher Zeit.
<G-vec00001-001-s457><build.bauen><en> Know therefore and discern, that from the going forth of the commandment to restore and to build Jerusalem to the Anointed One, the prince, shall be seven weeks, and sixty-two weeks: it shall be built again, with street and moat, even in troubled times.
<G-vec00001-001-s458><build.bauen><de> Ein Haus ist eine alte Mühle im Jahre 1877 gebaut, restauriert, dient als Damm für Süßwassersee hinter dem Haus an der nördlichen Seite des Grundstücks, während auf der Südseite befindet sich im direkten Kontakt mit Meer.
<G-vec00001-001-s458><build.bauen><en> One house is an old mill build in 1877,restored,serves as a dam for fresh water lake behind the house on northern side of the property; while on the southern side is in the direct contact with sea.
<G-vec00001-001-s459><build.bauen><de> Die Teilnehmer und Teilnehmerinnen lernen, wie ein Roboter funktioniert und wie solch eine bewegliche „Kreatur“ selbst gebaut und gesteuert werden kann.
<G-vec00001-001-s459><build.bauen><en> The participants learn how a robot works and how you can build and control such a mobile “creature” yourself.
<G-vec00001-001-s460><build.bauen><de> Durch die Anwendung des OO-Design- Ansatzes kann ein System entworfen und getestet (oder korrekter: simuliert) werden, ohne dass es vorher gebaut werden muss.
<G-vec00001-001-s460><build.bauen><en> By using an OO approach to design a system can be designed and tested (or more correctly simulated) without having to actually build the system first.
<G-vec00001-001-s461><build.bauen><de> Eine beeindruckende mittelalterliche Burg, gebaut auf einem steilen Fels 112 Meter über der Wasserfläche des Arwa-Flusses.
<G-vec00001-001-s461><build.bauen><en> Stunning medieval castle build on a steep rock 112 m above river Orava.
<G-vec00001-001-s462><build.bauen><de> [2] Es wurde allerdings kein Prototyp gebaut.
<G-vec00001-001-s462><build.bauen><en> [2] But he didn't build a prototype.
<G-vec00001-001-s463><build.bauen><de> Das Haus ist in besonderer Weise gebaut.
<G-vec00001-001-s463><build.bauen><en> The house is build in a special way.
<G-vec00001-001-s464><build.bauen><de> GUIs werden als Baum von Fenstern (Rechtecken), mit ihren eigenen Eigenschaften gebaut.
<G-vec00001-001-s464><build.bauen><en> GUIs are build as a tree of windows (rectangle) with their own properties.
<G-vec00001-001-s465><build.bauen><de> Da alle Gebäude aus dem gleichen grauen Stein gebaut zu sein scheinen wirkt das Areal etwas trist.
<G-vec00001-001-s465><build.bauen><en> As most of the buildings seem to be build of the same grey stone the are gives a rather dull impression.
<G-vec00001-001-s466><build.bauen><de> Von 1930 bis 1937 wurden die Boote nach den Regeln der internationalen 'J'-Klasse gebaut (Yacht-Klassen wurde nach dem Alphabet durchnummeriert).
<G-vec00001-001-s466><build.bauen><en> From 1930 to 1937 the boats were build under the regulations of the international 'J' class (yacht classes were numbered by the alphabet).
<G-vec00001-001-s467><build.bauen><de> Dieses provenzalische Landhaus wurde gebaut vor 250 Jahren.
<G-vec00001-001-s467><build.bauen><en> This provencal country house was build 250 years ago.
<G-vec00001-001-s468><build.bauen><de> Der Handelsposten benötigt keine Garnisonsressourcen mehr, um gebaut oder ausgebaut zu werden.
<G-vec00001-001-s468><build.bauen><en> Trading Post no longer requires Garrison Resources to build or upgrade.
<G-vec00001-001-s469><build.bauen><de> Das Elemental-Team hat seit 2001 konsequent mit einfallsreichen, flexiblen und kostengünstigen architektonischen Lösungen Tausende Wohneinheiten in seinem Heimatland Chile gebaut.
<G-vec00001-001-s469><build.bauen><en> Since 2001 the Elemental team has continued to build thousands of housing units in his homeland of Chile, using inventive, flexible, and affordable solutions.
<G-vec00001-001-s470><build.bauen><de> In Songkhla muss ein neues Stadion gebaut werden.
<G-vec00001-001-s470><build.bauen><en> In Songkhla a new Arena must be build.
<G-vec00001-001-s471><build.bauen><de> 1 Im vierhundertundachtzigsten Jahr nach dem Auszug Israels aus Ägyptenland, im vierten Jahr der Herrschaft Salomos über Israel, im Monat Siw, das ist der zweite Monat, wurde das Haus dem HERRN gebaut.
<G-vec00001-001-s471><build.bauen><en> 1 And it came to pass in the four hundred and eightieth year after the children of Israel were come out of the land of Egypt, in the fourth year of Solomon 's reign over Israel, in the month Zif, which is the second month, that he began to build the house of the LORD.
<G-vec00001-001-s472><build.bauen><de> Turbo, gebaut 1912, gesunken, Zweiter Weltkrieg, am 04.04.1942 durch Torpedo, Abu Dias, Ras Banas, Ägypten, Rotes Meer, Afrika | Stern, Wreck, ship, tanker, S.S.
<G-vec00001-001-s472><build.bauen><en> Turbo, build 1912, sank, World War Two, WW II, 04.04.1942, torpedo hit, Abu Dias, Ras Bananas, Egypt, Red Sea, Africa | Heck, Wrack, Schiff, Tanker, S.S.
<G-vec00001-001-s473><build.bauen><de> "Nach Erreichen des Levels erhält das Oberhaupt den Auftrag Agden Gal-Tarks ""Werftbau"", in dem der Kapitän davon erzählt, dass für den Bau von Schiffen, die den Wandernden Archipel erreichen können, der Clan erst eine eigene Werft anlegen sollte, in der dann das Schiff gebaut wird."
<G-vec00001-001-s473><build.bauen><en> "After the required level is gained, the Clan Leader is summoned by captain Agden Gal-Tark and receives the ""Laying the Foundation"" Quest in which Gal-Tark explains that in order to reach the Roaming Archipelago, a Clan would need to construct a Dockyard and build a Ship."
<G-vec00001-001-s474><build.bauen><de> Während dieser Phase wird eine komplett neue Montagehalle gebaut.
<G-vec00001-001-s474><build.bauen><en> In this phase, a new assembly hall is being build.
<G-vec00001-001-s270><construct.bauen><de> In der Hafermühle profitierte man von der aufkommenden «Müesliwelle», sodass schon bald zusammen mit Bühler eine neue Hafermühle gebaut wurde, deren Leistung mittlerweile verdop-pelt wurde.
<G-vec00001-001-s270><construct.bauen><en> The oat mill benefited from the emerging “muesli” wave, which prompted the company to construct a new oat mill together with Bühler. Since then, its capacity has doubled.
<G-vec00001-001-s271><construct.bauen><de> Ausschlaggebend sind Deine Entscheidungen darüber, welche Technologien Du erforschen lässt, wohin Deine Armeen geschickt werden, wie Deine Wirtschaft verwaltet wird und welche Kampfeinheiten gebaut werden.
<G-vec00001-001-s271><construct.bauen><en> Deciding what technologies to research, where to send armies, how to manage your economy, and what units to construct are critical.
<G-vec00001-001-s272><construct.bauen><de> Deshalb wird dieser spezifisch für jeden einzelnen Kunden massgeschneidert und mit modernster technischer Infrastruktur in der Schweiz gebaut.
<G-vec00001-001-s272><construct.bauen><en> That’s why we customise them specifically to the needs of every individual customer and construct them in Switzerland using state-of-the-art technical infrastructure.
<G-vec00001-001-s273><construct.bauen><de> Fahrzeuge von 10 bis 150 Tonnen gebaut.
<G-vec00001-001-s273><construct.bauen><en> We construct to 150 vehicles from 10 Tn.
<G-vec00001-001-s274><construct.bauen><de> Pepsin abbaut Lebensmittel Proteine in Peptide, damit Ihr Körper alle verfeinern könnte, die gesunde Protein anlehnen werden Sie sicherlich in nehmen müssen, um jene massive neue Muskelmasse zu füttern Sie sicher gebaut werden wird.
<G-vec00001-001-s274><construct.bauen><en> Pepsin breaks down food healthy proteins right into peptides so your body can refine all that lean healthy protein you will certainly have to take in to feed those massive new muscle mass you will certainly be construct.
<G-vec00001-001-s275><construct.bauen><de> Die Bandbreite reichte von Gamedesign Ã1⁄4ber eine Virtual-Reality-Tour durch das Robotic Fabrication Labratory der ETH bis hin zu neuen Materialien, wie beispielsweise einem Â«kÃ1⁄4nstlichen Baum», der CO2 und Licht in Solarkraftstoff umwandet, leichte Fasern, die Stahlkabel ersetzen können oder ein neues Material, aus dem kÃ1⁄4nftig Computer gebaut werden können.
<G-vec00001-001-s275><construct.bauen><en> "The exhibition covered everything from game design and a virtual reality tour through ETH's Robotic Fabrication Laboratory to new materials, such as an ""artificial tree"" that converts CO2 and light into solar power, lightweight fibres that could replace steel cables, and a new material that could be used to construct computers in future."
<G-vec00179-001-s532><take.bauen><de> Im Büro der Initiative kann Ihr Material gleich reproduziert werden, so dass Sie es wieder mit zu sich nach Hause nehmen können.
<G-vec00179-001-s532><take.bauen><en> Your material can be copied straight away in the office so that you can take it home with you immediately.
<G-vec00179-001-s533><take.bauen><de> Allerdings ist es ratsam, dass schwangere Frauen nicht zu viel Vitamin A zu sich nehmen – frage deinen Arzt oder Apotheker um genauere Ratschläge über die Bedürfnisse deines Babys zu erhalten.
<G-vec00179-001-s533><take.bauen><en> By contrast, pregnant women are advised not to take too much vitamin A – consult your physician or ask at your pharmacy to be adequately guided about your baby's needs.
<G-vec00179-001-s534><take.bauen><de> Bei solchen Banken zählt es zur guten Tradition, sich Zeit zu nehmen für den Kunden, seine persönliche Situation zu analysieren, seine Kapitaldienstfähigkeit zu prüfen, die zu finanzierende Immobilie emotionslos zu bewerten und den Kunden über die lang fristigen Chancen und Risiken umfassend aufzuklären.
<G-vec00179-001-s534><take.bauen><en> Part of the fine tradition that prevails at these banks is to take time for the customer, analyse their personal situation, review their ability to service the loan, assess the property to be financed in a detached manner, and provide the customer with a comprehensive explanation of the long-term risks and opportunities.
<G-vec00179-001-s535><take.bauen><de> Aber sein größter Traum ist: Wenn das Gedankenkarussell volle Fahrt aufnimmt, will er es trotzdem hinkriegen, freundlich mit dem Maskenbildner zu sprechen, sich Zeit mit dem Stage-Manager nehmen, fokussiert auf die Menschen um ihn herum zu sein, ja, genau genommen, die Musik-Party, die der MGP in Wirklichkeit ist, zu genießen.
<G-vec00179-001-s535><take.bauen><en> But the biggest dream is this: If the racing mindset going at full speed, he will still manage to talk nicely with the make-up artist, take time with the stage manager, focus on thosearound him, yes, actually enjoy the musical party the MGP really is.
<G-vec00179-001-s536><take.bauen><de> Und sie hatten vergessen, Brot mit sich zu nehmen, und hatten nicht mehr mit sich im Schiff denn ein Brot.
<G-vec00179-001-s536><take.bauen><en> And they forgot to take bread; and they had not in the boat with them more than one loaf.
<G-vec00179-001-s537><take.bauen><de> Um mit Schlafstörungen oder vielen anderen Gesundheitsproblemen fertig zu werden, ist der grundlegende Schritt, ausreichend Nährstoffe für einen gesunden Körper zu sich zu nehmen.
<G-vec00179-001-s537><take.bauen><en> To cope with sleeping disorder or many other health problems, the fundamental step is to take enough nutrients for a healthy body.
<G-vec00179-001-s538><take.bauen><de> Hier sollte man sich etwas Zeit nehmen um nach kleinen Sachen zu suchen.
<G-vec00179-001-s538><take.bauen><en> You could take some time to look for the little stuff here.
<G-vec00179-001-s539><take.bauen><de> Denn wenn kein Krieg war, konnte er nicht kommandieren und die Verantwortung tragen, und es gab keine Beute, von der er sich den größten Teil nehmen konnte.
<G-vec00179-001-s539><take.bauen><en> Because if there was no war, he couldn't command and carry responsibility, and there wouldn't be any loot from which he could take the lion's share.
<G-vec00179-001-s540><take.bauen><de> Sie scheinen wie ein echter Macho Kerl, wenn man sich ins Bett nehmen.
<G-vec00179-001-s540><take.bauen><en> You seem like an actual manly man when you take her to bed.
<G-vec00179-001-s541><take.bauen><de> 2007-11-13 22:16:19 - Die Wahl eines Network-Marketing Gelegenheit - 5 roten Fahnen Obwohl die Network-Marketing bietet das Potenzial für langfristige Gewinne Restwert auf Ihrer ursprünglichen Bemühungen ist es wichtig, sich die Zeit nehmen, zunächst die Möglichkeit zu wählen, die am besten geeignet, um Ihre Interessen und Marketing-Fähigkeiten.
<G-vec00179-001-s541><take.bauen><en> 2007-11-13 22:16:19 - Choosing a network marketing opportunity - 5 red flags Although network marketing offers the potential for long term residual profits on your original efforts, it is important to take the time initially to choose the opportunity that is best suited to your interests and marketing skills.
<G-vec00179-001-s542><take.bauen><de> Wir wären Ihnen sehr dankbar, wenn Sie sich die Zeit nehmen würden, um für uns abzustimmen.
<G-vec00179-001-s542><take.bauen><en> We would be very grateful if you would take the time to cast your vote for us in your favourite category.
<G-vec00179-001-s543><take.bauen><de> Häufig kommen Leute zum Kloster und sagen, dass es für den Geist eine große Erleichterung ist, hier draußen zu sein und dass sie diesen Geisteszustand gerne mit sich nehmen würden, wenn sie zurückkehren.
<G-vec00179-001-s543><take.bauen><en> Many times people come to the monastery and say that it's such a relief for the mind to be out here and they'd like to take that state of mind with them when they go back.
<G-vec00179-001-s544><take.bauen><de> Wenn Nando de Colo, Weems, Jackson werden nicht im Angriff widerstehen, wird Teodosic zweifellos auf sich die Veranwortung auch in Creation nehmen.
<G-vec00179-001-s544><take.bauen><en> Now, in the event that players like De Colo, Weems, Jackson, the bigmen are not on a good day and are not accurate, then Teodosic has to and definitely can take over in execution as well.
<G-vec00179-001-s545><take.bauen><de> "Man kann sich für die Wanderung entweder Proviant mitnehmen oder man isst in den „Casoni"", im Wald gelegenen Raststätten, wo man Salami und Käse lokaler Produktion mit einem Aglianico-Wein zu sich nehmen kann."
<G-vec00179-001-s545><take.bauen><en> "To avoid carrying too much, it is best to take a packed lunch or eat in the ""casoni"", snack bars in the woods where you can eat a plate of excellent salami and local cheeses while sipping Aglianico wine."
<G-vec00179-001-s546><take.bauen><de> Das Hauptschlafzimmer, ruhig, und an der RÃ1⁄4ckseite der Wohnung bietet Ihnen Zugang auf den sonnigsten Balkon, breit genug ist, damit Sie sich einen Stuhl nehmen können und Ihre Ruhe genießen können.
<G-vec00179-001-s546><take.bauen><en> The master bedroom, quiet, at the back of the apartment gives you access to the sunniest balcony, wide enough for you to take a chair and have your moment.
<G-vec00179-001-s547><take.bauen><de> Die Straßen-Route ist landschaftlich sehr reizvoll und Sie werden wahrscheinlich länger brauchen als unbedingt erforderlich ist, und sich die Zeit nehmen um die schöne Landschaft zu genießen.
<G-vec00179-001-s547><take.bauen><en> The road route is very scenic and you will probably take longer than is strictly necessary to take your time enjoying the beautiful landscape.
<G-vec00179-001-s548><take.bauen><de> Ein Teilnehmer Hungerstreik gestorben war - 64-jährige Alex Nedelko weigerte sich, Nahrung zu sich nehmen aus Solidarität mit den hungernden Frau und sein schwaches Herz nicht am dritten Tag stehen.
<G-vec00179-001-s548><take.bauen><en> One participant hunger strike had died - 64-year-old Alex Nedelko refused to take food out of solidarity with the starving wife, and his weak heart could not stand on the third day.
<G-vec00179-001-s549><take.bauen><de> Fragen Sie Ihren Arzt, ob Capecitabin mit anderen Medikamenten, die Sie zu sich nehmen, interagieren könnte.
<G-vec00179-001-s549><take.bauen><en> Ask your health care provider if capecitabine may interact with other medicines that you take.
<G-vec00179-001-s550><take.bauen><de> Wie man sich aber ein rechtmässiges Weib zu nehmen hat, so ist solches nach der Ordnung aus den Himmeln schon durch Moses verordnet worden und hat fürder bis ans Weltende dabei zu verbleiben.
<G-vec00179-001-s550><take.bauen><en> But how one should take a legal wife, this has already been decreed by Moses according to the order from heaven, and must remain in the future until the end of the world.
<G-vec00206-002-s069><count.bauen><de> Bauen Sie auf Performance und Produktivität in einem schlanken, vielseitigen 35,6 cm (14'')-Design mit erstklassigen Sicherheits- und Verwaltungsfunktionen.
<G-vec00206-002-s069><count.bauen><en> Starting at £499 Count on powerful productivity packed in a sleek, versatile 14" design with best-in-class security and manageability.
<G-vec00206-002-s070><count.bauen><de> Unser Versprechen für höchste Qualität bedeutet, dass wir auf das Vertrauen der wichtigsten Player in der Branche bauen.
<G-vec00206-002-s070><count.bauen><en> Our promise of excellence means that we can count on the trust of the main players in the sector.
<G-vec00206-002-s071><count.bauen><de> Bauen Sie auf Sicherheit, Zuverlässigkeit und Qualität.
<G-vec00206-002-s071><count.bauen><en> You can count on safety, reliability and quality when you buy from us.
<G-vec00206-002-s072><count.bauen><de> Sie bauen auf dich.
<G-vec00206-002-s072><count.bauen><en> They count on you.
<G-vec00206-002-s073><count.bauen><de> Wenn es um eine fundierte Marktpreiseinschätzung und das Wertpotenzial Ihrer Anlageimmobilie geht, sollten Sie auf die Kompetenz eines Experten bauen.
<G-vec00206-002-s073><count.bauen><en> If it comes to reliable and correct estimation of value and potential of your investment asset - you should count on the competence of our experts!
<G-vec00206-002-s074><count.bauen><de> Die Kunden der DOMUS Software AG, egal welcher Größenordnung, können auf die Kompetenz als Fachkraft bauen.
<G-vec00206-002-s074><count.bauen><en> The customers of the DOMUS Software AG no matter their size, can count on the expertise as specialist.
<G-vec00206-002-s075><count.bauen><de> Ganz besonders stolz bin ich als Oberbürgermeister darauf, dass unsere Stadt auf ein großes ehrenamtliches Engagement bauen kann.
<G-vec00206-002-s075><count.bauen><en> As mayor, I'm especially proud of the fact that our city can count on a huge voluntary commitment.
<G-vec00206-002-s076><count.bauen><de> Und oft genug konnten wir nicht auf die Unterstuetzung anderer bauen und mussten alleine da durch, mit unseren empfindlich eingeschraenkten Ressourcen und irgendwie arg mitgenommener innerer Staerke.
<G-vec00206-002-s076><count.bauen><en> And much of the time, we could not count on the support of others and had to go through it alone, using our own severely stretched resources and somewhat battered inner strength.
<G-vec00206-002-s077><count.bauen><de> In jedem Fall kann er - dank des USB-typischen Plug & Plays - auf eine einfache Integration und Handhabung bauen.
<G-vec00206-002-s077><count.bauen><en> Whatever their choice, they can count on easy integration and handling, thanks to the typical USB plug & play functionality.
<G-vec00206-002-s078><count.bauen><de> Diese Ausrichtung hat sich für unsere hauseigenen Produktenketten bewährt und so können wir auf einen stetig wachsenden und zufriedenen Kundenkreis bauen.
<G-vec00206-002-s078><count.bauen><en> This approach has been proven successful for our own product range during the last 20 years and we can count on a continually growing and satisfied customer base.
<G-vec00206-002-s079><count.bauen><de> Bauen Sie auf die hohe Leistung Ihres privaten Netzwerks und nutzen Sie eine Standard-Port-Hochgeschwindigkeit von 100 Mbit/s und die Option, auf 1 Gigabit/s pro Port upzugraden.
<G-vec00206-002-s079><count.bauen><en> Count on high performance from your private network with a fast standard port speed of 100 Mbit/s and the option to upgrade to as much as 1 Gigabit/s per port.
<G-vec00206-002-s080><count.bauen><de> Auf dieses Versprechen können sich unsere Auftraggeber verlassen und dabei stets auf unsere Termintreue bauen.
<G-vec00206-002-s080><count.bauen><en> This is a promise our clients can count on, just as they can always count on our adhering to deadlines.
<G-vec00206-002-s081><count.bauen><de> Die SMART ist eine Biegemaschine, auf die Sie Ihre Produktion bauen können.
<G-vec00206-002-s081><count.bauen><en> SMART is a bending machine you can count on to make your production.
<G-vec00206-002-s082><count.bauen><de> Kundenspezifische Lösungen von Kendrion Wir bauen auf Kompetenz im Magnetismus und bieten maßgeschneiderte Systemlösungen gepaart mit Innovationskraft und neuesten Fertigungstechnologien.
<G-vec00206-002-s082><count.bauen><en> from Kendrion We count on competence in magnetism and offer customized system solutions coupled with innovation force and the latest manufacturing technologies, creating products with an excellent market position.
<G-vec00298-002-s209><expand.bauen><de> Wir bauen unsere Marktposition durch Investitionen, Partnerschaften und Akquisitionen aus.
<G-vec00298-002-s209><expand.bauen><en> We expand our market position through investments, partnerships and acquisitions.
<G-vec00298-002-s210><expand.bauen><de> Nutzen Sie die Gemeinschaft unserer Vereinigung, bauen Sie Ihr Netzwerk aus und genießen Sie unsere zahlreichen gesellschaftlichen Veranstaltungen.
<G-vec00298-002-s210><expand.bauen><en> Take advantage of the association community, expand your network, and have fun at one of our many social events.
<G-vec00298-002-s211><expand.bauen><de> Fritz Joussen, Vorstandsvorsitzender der TUI Group: „Wir wachsen, investieren und bauen unsere Position als weltweit führender Touristikkonzern weiter Schritt für Schritt aus.
<G-vec00298-002-s211><expand.bauen><en> Fritz Joussen, CEO TUI Group commented: “Step by step, we continue to grow, invest and expand our position as the world’s number one tourism group.
<G-vec00298-002-s212><expand.bauen><de> Die Zusammenarbeit zwischen unseren Teams funktioniert hervorragend, und wir freuen uns, diese aufregende und innovative neue Schiffsklasse bauen zu können", so Bernard Meyer, geschäftsführender Gesellschafter der MEYER WERFT.
<G-vec00298-002-s212><expand.bauen><en> “We are thrilled that Norwegian Cruise Line has the continued confidence in MEYER WERFT to expand their fleet,” said Bernard Meyer, managing partner of MEYER WERFT.
<G-vec00298-002-s213><expand.bauen><de> Bauen Sie beim Networking den Kontakt zu den relevanten Zielgruppen auf und aus.
<G-vec00298-002-s213><expand.bauen><en> You will benefit from the networking opportunities to consolidate and expand your contact with your relevant target groups.
<G-vec00298-002-s214><expand.bauen><de> Sie bauen Ihr Expertenwissen aus, Sie knobeln und lösen Probleme und entwickeln sich zum angesehenen Fachexperten.
<G-vec00298-002-s214><expand.bauen><en> You will expand your expertise, contemplate and solve problems, and develop into an eminent expert in your field.
<G-vec00298-002-s215><expand.bauen><de> „Wir bauen unseren Handel mit Recycling–Anlagen in der MENA-Region weiter aus.
<G-vec00298-002-s215><expand.bauen><en> “We are continuing to expand the trading activities and services for recycling plants in the region.
<G-vec00298-002-s216><expand.bauen><de> Auch die Universitäten Bonn und zu Köln – Partner im Geoverbund – bauen ihre Afrika-Forschung aus.
<G-vec00298-002-s216><expand.bauen><en> The universities of Bonn and Cologne – partners of Geoverbund ABC/J – are also looking to expand their research in Africa.
<G-vec00298-002-s217><expand.bauen><de> Finanzvorstand Wolfgang Schäfer verwies darüber hinaus auf die finanzielle Stärke des DAX-Unternehmens: „Finanziell kerngesund investieren wir stark und bauen unser Geschäft weltweit weiter aus: Investitionen in Sachanlagen und Ausgaben für Forschung und Entwicklung von insgesamt fast 6 Milliarden Euro zeigen das ganz deutlich.
<G-vec00298-002-s217><expand.bauen><en> Chief Financial Officer Wolfgang Schaefer spoke about the DAX company’s financial strength: “Having finances that are in excellent shape allows us to invest heavily and continue to expand our business on a global scale. Our capital expenditure on property, plant and equipment, together with expenses for research and development, all of which came to nearly €6 billion, are testament to this.
<G-vec00298-002-s218><expand.bauen><de> Zusammen mit Ihnen bauen wir unsere Marktposition weiter aus.
<G-vec00298-002-s218><expand.bauen><en> Together with you, we will further expand our market position.
<G-vec00298-002-s219><expand.bauen><de> Vereinbaren Sie mit Matchmaking einen Termin zur Asia-Pacific Sourcing mit Geschäftspartnern und bauen Sie Ihr Business Networking aus.
<G-vec00298-002-s219><expand.bauen><en> Make an appointment with business partners at Asia-Pacific Sourcing with Matchmaking and expand your business networking.
<G-vec00298-002-s220><expand.bauen><de> Damit werden wir unserer Philosophie „closer to the customer“ gerecht und bauen damit das „Life Cycle Business“ weiter aus.
<G-vec00298-002-s220><expand.bauen><en> Thereby, we do justice to our philosophy „closer to the customer“ as well as continue to expand our „Life Cycle Business“.
<G-vec00298-002-s221><expand.bauen><de> Künftig wird der Schwerpunkt noch deutlicher auf innovativen Geschäftsmodellen liegen: Wir bündeln die bestehenden Innovationsaktivitäten und bauen sie weiter aus.
<G-vec00298-002-s221><expand.bauen><en> In the future, the focus will lie more heavily on innovative business models: for this purpose, we will pool existing innovation activities together and expand them further.
<G-vec00298-002-s222><expand.bauen><de> Sichern Sie den Bestand Ihres Unternehmens und bauen Sie Ihre Marktposition weiter aus.
<G-vec00298-002-s222><expand.bauen><en> Secure the existence of your company and further expand your market position.
<G-vec00298-002-s223><expand.bauen><de> Mit nur wenigen zusätzlichen Teilen bauen Sie dieses Zimmergerüst bis zu einer Arbeitshöhe von 5,50 m aus.
<G-vec00298-002-s223><expand.bauen><en> With only a few additional components you expand this folding tower to a working height of 5.50 metres.
<G-vec00298-002-s224><expand.bauen><de> Mit ausgeprägtem Willen und den notwendigen Fertigkeiten bauen Sie die Spitzenstellung des Unternehmens im hochpräzisen 3D-Druck mit den von Ihnen entwickelten disruptiven Softwarelösungen weiter aus.
<G-vec00298-002-s224><expand.bauen><en> With a strong will and the necessary skills, you will further expand the company’s leading position in high-precision 3D printing with the disruptive software solutions you have developed.
<G-vec00298-002-s225><expand.bauen><de> Mit unseren Branchenlösungen stehen Sie von Anfang an in der Pole Position und bauen Ihren Vorsprung mit jeder Runde aus.
<G-vec00298-002-s225><expand.bauen><en> With our solutions you will be in pole position right from the outset, and will expand your lead with each lap.
<G-vec00298-002-s226><expand.bauen><de> Ebenso bauen wir das Netz unserer Kontakte und Produktionspartner weiter aus, nicht nur im Inland sondern auch europaweit.
<G-vec00298-002-s226><expand.bauen><en> We continue to expand our network of partners and distributors not only in Poland, but also throughout the European Union.
<G-vec00298-002-s227><expand.bauen><de> In kurzen Gesprächen bauen Sie Ihre Stärken aus.
<G-vec00298-002-s227><expand.bauen><en> You expand your strength and demand potential during short conversations.
<G-vec00322-002-s146><establish.bauen><de> Wenn eine Webseite dieses Internetauftritts aufgerufen wird, die eine solche Schaltfläche enthält, baut der verwendete Browser eine direkte Verbindung mit den Servern von Twitter auf.
<G-vec00322-002-s146><establish.bauen><en> If a website of this online presence that contains such an interface is called up, the browser used will establish a direct connection with the Twitter servers.
<G-vec00322-002-s147><establish.bauen><de> Wenn ein Nutzer eine Seite dieses Internetauftritts aufruft, die eine solche Twitter-Schaltfläche enthält, baut sein Browser eine direkte Verbindung mit den Servern von Twitter auf.
<G-vec00322-002-s147><establish.bauen><en> When a user accesses a page of our website that contains such a Twitter button, his/her browser will establish a direct connection to the servers of Twitter.
<G-vec00322-002-s148><establish.bauen><de> Wenn Sie eine unserer Webseiten mit Tumblr-Button aufrufen, baut der Browser eine direkte Verbindung mit den Servern von Tumblr auf.
<G-vec00322-002-s148><establish.bauen><en> If you access one of our websites with the Tumblr button, the browser will establish a direct connection to the Tumblr servers.
<G-vec00322-002-s149><establish.bauen><de> Man baut auch eine persönliche Beziehung zu den Leuten dort auf und konzentriert sich auf die Promotion eines Sponsors.
<G-vec00322-002-s149><establish.bauen><en> You will also establish a personal relationship to these people and focus on promoting the sponsor.
<G-vec00322-002-s150><establish.bauen><de> Wenn ein Nutzer eine Webseite dieses Angebots aufruft, die ein solches Plugin enthält, baut sein Browser eine direkte Verbindung mit den Servern von Facebook auf.
<G-vec00322-002-s150><establish.bauen><en> If the user opens a page of this web site that contains one of these plugins the browser will establish a direct connection to the servers of facebook.
<G-vec00322-002-s151><establish.bauen><de> Wenn der Kunde mit diesem Plugin auf die Website von Engel & Völkers zugreift, baut die Suchmaschine des Kunden eine direkte Verbindung zu den Servern von Facebook auf.
<G-vec00322-002-s151><establish.bauen><en> If a client accesses the Engel & Völkers page that contains the plugin the client’s browser will establish a direct connection with Facebook’s servers.
<G-vec00322-002-s152><establish.bauen><de> Wenn der Kunde die Plattform nutzt, baut diese eine direkte Verbindung mit den Servern von Google auf.
<G-vec00322-002-s152><establish.bauen><en> When the customer uses the Platform, the latter will establish a direct connection to the servers of Google.
<G-vec00322-002-s153><establish.bauen><de> Der Server baut daraufhin von seinem Port 20 eine Verbindung zum gewünschten Port des Clients auf.
<G-vec00322-002-s153><establish.bauen><en> The server will establish as a result from its port 20 a connection to the desired port of the client.
<G-vec00322-002-s154><establish.bauen><de> Exo Terra Turtle Clean baut die richtige biologische Nutzflora auf, um sicherzustellen, dass organische Abfallstoffe erheblich abgebaut werden, wenn es in der empfohlenen wöchentlichen Dosis angewendet wird.
<G-vec00322-002-s154><establish.bauen><en> Exo Terra Turtle Clean will establish the right beneficial biological flora to ensure significant organic waste breakdown occurs, when used at the recommended weekly dose.
<G-vec00322-002-s155><establish.bauen><de> Dies bedeutet: wenn Sie eine Webseite unseres Internetauftritts mit entsprechendem Inhalt aufrufen, baut Ihr Browser eine direkte Verbindung mit den Servern des jeweiligen Anbieters auf.
<G-vec00322-002-s155><establish.bauen><en> This means that your browser will establish a direct connection to the servers of the respective provider when you call up a website from our internet presence with corresponding content.
<G-vec00322-002-s156><establish.bauen><de> Wenn ein Nutzer eine Webseite dieses Angebotes aufruft, die eine solche Schaltfläche enthält, baut der Browser eine direkte Verbindung mit den Servern von Google auf.
<G-vec00322-002-s156><establish.bauen><en> If you open any of our web pages that contain such a button, your browser will establish a direct connection with the servers of Google.
<G-vec00322-002-s157><establish.bauen><de> Wenn Sie eine Website unseres Internetauftritts aufrufen, die ein solches Plug-In enthält, baut Ihr Browser eine direkte Verbindung mit den Servern von Google auf.
<G-vec00322-002-s157><establish.bauen><en> If a website of this online presence that contains such an interface is called up, the browser used will establish a direct connection with the Google servers.
<G-vec00322-002-s158><establish.bauen><de> (dd) Aufgrund der eingesetzten Marketing-Tools baut Ihr Browser automatisch eine direkte Verbindung mit dem Server von Google auf.
<G-vec00322-002-s158><establish.bauen><en> The marketing tools used cause your browser to automatically establish a direct connection to Google's server.
<G-vec00322-002-s159><establish.bauen><de> Wenn Sie eine Webseite unseres Internetauftritts aufrufen, die eine solche Schaltfläche enthält, baut Ihr Browser eine direkte Verbindung mit den Servern von Google auf.
<G-vec00322-002-s159><establish.bauen><en> When calling a site of our internet presence containing this button, your browser will establish a direct connection to the Google server.
<G-vec00322-002-s162><establish.bauen><de> Wenn Sie eine Unterseite unserer Website aufrufen, die eine solche Schaltfläche enthält, baut Ihr Browser eine direkte Verbindung mit den Servern von Pinterest auf.
<G-vec00322-002-s162><establish.bauen><en> If you call up one of our web pages which contains such a button your browser will establish a direct link to the Pinterest servers.
<G-vec00322-002-s163><establish.bauen><de> Sobald Sie unsere Website aufrufen, baut Ihr Browser eine direkte Verbindung mit den Servern von Facebook auf.
<G-vec00322-002-s163><establish.bauen><en> Should you access our website, your browser will establish a direct connection to the servers of Facebook.
<G-vec00322-002-s164><establish.bauen><de> Wenn ein Nutzer eine Webseite dieses Internetauftritts aufruft, die einen solchen Button enthält, baut sein Browser eine direkte Verbindung mit den Servern von Twitter auf.
<G-vec00322-002-s164><establish.bauen><en> Whenever a user visits a web page in this program featuring such an icon, the browser will establish a direct link to the Twitter servers.
<G-vec00360-002-s114><develop.bauen><de> Bananen sind auch wunderbar, wenn Sie versuchen, Fett zu verbrennen und bauen Muskelmasse.
<G-vec00360-002-s114><develop.bauen><en> Bananas are also excellent when you are trying to burn fat and develop muscular tissue.
<G-vec00360-002-s115><develop.bauen><de> Ich kann nicht warten, um einen anderen Stapel zu erhalten, auch weiterhin zu sehen, diese Ergebnisse bauen und bauen.
<G-vec00360-002-s115><develop.bauen><en> I angle wait to obtain one more pile to continuously see these outcomes build as well as develop.
<G-vec00360-002-s116><develop.bauen><de> Mit unserem „Train the Trainer"-Konzept bauen Sie eigenes, spezielles Applikations-Know-how auf.
<G-vec00360-002-s116><develop.bauen><en> With our “train the trainer” concept, you develop your own special application expertise.
<G-vec00360-002-s117><develop.bauen><de> Bananen sind zudem hervorragend, wenn Sie versuchen, zu vergießen Fett und bauen Muskelmasse.
<G-vec00360-002-s117><develop.bauen><en> Bananas are additionally excellent when you are trying to burn fat and also develop muscle mass.
<G-vec00360-002-s118><develop.bauen><de> Bananen sind ebenfalls fantastisch, wenn Sie versuchen, Fett zu verbrennen und bauen Muskelgewebe.
<G-vec00360-002-s118><develop.bauen><en> Bananas are likewise terrific when you are attempting to burn fat and develop muscular tissue.
<G-vec00360-002-s119><develop.bauen><de> Wenn Sie Ihre 30er Jahre erreichen, beginnen Ihr Testosteronspiegel zu sinken, so dass Sie wirklich älter fühlen, entdecken Sie es schwieriger zu bauen und Sie erhalten schneller Fett.
<G-vec00360-002-s119><develop.bauen><en> When you reach your 30’s, Your Testosterone degree start to decline, so you really feel older, you discover it more challenging to develop and you get fat quicker.
<G-vec00360-002-s120><develop.bauen><de> Wir bauen die perfekte Organisationsstruktur für das Unternehmen auf und stellen die richtigen Mitarbeiter ein.
<G-vec00360-002-s120><develop.bauen><en> We develop the perfect organization for the venture and hire the right people. Scale
<G-vec00360-002-s121><develop.bauen><de> Bananen sind ebenfalls hervorragend, wenn Sie versuchen, Fett zu verlieren und bauen Muskelgewebe.
<G-vec00360-002-s121><develop.bauen><en> Bananas are also wonderful when you are trying to burn fat and also develop muscle.
<G-vec00360-002-s122><develop.bauen><de> Gleichzeitig bauen die Unternehmen jedoch weiterhin Ölfelder aus und kündigen täglich Zahlungsströme in Höhe von mehreren Millionen Kronen aus dem Ölgeschäft an.
<G-vec00360-002-s122><develop.bauen><en> However, at the same time they continue to develop oil fields and announce the flow of millions of kroner of oil per day.
<G-vec00360-002-s123><develop.bauen><de> Dies zeigt an, dass Sie keine geeignete Energie für den Körper liefern, Fett zu verbrennen und Muskelmasse effektiv über die Ausbildung zu bauen.
<G-vec00360-002-s123><develop.bauen><en> This implies that you do not provide adequate energy for the body to shed fat and also develop muscular tissue appropriately with the workout.
<G-vec00360-002-s124><develop.bauen><de> Bananen sind zudem hervorragend, wenn Sie versuchen, Fett zu verbrennen und bauen Muskelgewebe.
<G-vec00360-002-s124><develop.bauen><en> Bananas are also fantastic when you are attempting to burn fat as well as develop muscular tissue.
<G-vec00360-002-s125><develop.bauen><de> Es ist unsere nachhaltige Mission Anlagen zu bauen, welche die Luft und das Wasser sauber halten.
<G-vec00360-002-s125><develop.bauen><en> It is our mission to develop systems that keep air and water clean.
<G-vec00360-002-s126><develop.bauen><de> Die Hochwildpatrone .30 R ist jedoch mehr als eine .30-06 mit Rand: Die gesteigerte Leistung und die hohe Präzision lassen das neue Kaliber schnell so populär werden, dass bald auch andere Hersteller Waffen in diesem Kaliber bauen.
<G-vec00360-002-s126><develop.bauen><en> Blaser works together with RWS to develop the .30 R Blaser. This cartridge is more than a .30-06 with a rim: The increased performance along with high precision quickly made this caliber very popular.
<G-vec00360-002-s128><develop.bauen><de> Identifizieren: Bauen Sie einen funktionalen Wortschatz und ein Verständnis von alltäglichen Wörtern, Redewendungen und häufig verwendeten Sätzen auf.
<G-vec00360-002-s128><develop.bauen><en> Identification: develop a functional vocabulary and understanding of routine words, phrases, and sentences that are frequently used.
<G-vec00360-002-s129><develop.bauen><de> Wir bauen gemeinsam mit Ihnen Ihre datenbasierten Geschäftsmodelle auf und leiten die Anforderungen an Ihre Architektur und an Ihr Unternehmen ab, die Sie als Roadmap auf Ihren Weg in die Zukunft unterstützen.
<G-vec00360-002-s129><develop.bauen><en> We develop data-driven business models together with you and derive requirements for your architecture and company that can be used as a roadmap for your path into the future.
<G-vec00360-002-s130><develop.bauen><de> Fokussiert auf eine nachhaltige Profitabilität der Geschäftsbereiche, bauen wir gezielt Potenziale aus.
<G-vec00360-002-s130><develop.bauen><en> We develop potential in a targeted manner by focusing on sustainable profitability in the business units.
<G-vec00360-002-s131><develop.bauen><de> Bananen sind auch fantastisch, wenn Sie versuchen, zu vergießen Fett und bauen Muskeln.
<G-vec00360-002-s131><develop.bauen><en> Bananas are likewise great when you are trying to melt fat as well as develop muscle.
<G-vec00360-002-s132><develop.bauen><de> Gemeinsam mit uns bauen Sie Vertrauen zu ihren Stakeholdern auf und generieren so Zustimmung für den Umgang und die Bewältigung von komplexen und anspruchsvollen Aktivitäten und Projekten.
<G-vec00360-002-s132><develop.bauen><en> We develop committed relationships with your stakeholders that encourage approval for managing and implementing complex and ambitious projects.
<G-vec00443-002-s063><assemble.bauen><de> Wir bauen die bei uns gefertigten Einzelteile und auch die von Ihnen angelieferten Bauteile oder von uns beschafften Kaufteile zu Baugruppen zusammen und liefern diese nach Ihrem Wunsch einbaufertig an.
<G-vec00443-002-s063><assemble.bauen><en> We assemble the parts we produce or outsource and the components you supply into modules and deliver them ready to install as per your
<G-vec00443-002-s064><assemble.bauen><de> Das Kit enthält 30 Stücke, von denen es möglich ist, einen Salon für Haustiere zu bauen.
<G-vec00443-002-s064><assemble.bauen><en> The kit contains 30 pieces from which it is possible to assemble a pet salon .
<G-vec00443-002-s065><assemble.bauen><de> Bauen: Zusammenführen, verschmelzen.
<G-vec00443-002-s065><assemble.bauen><en> Assemble: Merge, merge.
<G-vec00443-002-s066><assemble.bauen><de> Wenn du überhaupt nicht in der Lage bist, dir einen Mysticum zu bauen, aber gerne einen haben möchtest, dann kontaktiere mich bitte.
<G-vec00443-002-s066><assemble.bauen><en> If you are not able at all to assemble your Mysticum on your own, but like to have one, please contact me!
<G-vec00443-002-s067><assemble.bauen><de> Außerdem gibt es weitere Trophäen für Piraten, die eine Vielzahl an Spielzeugen bauen.
<G-vec00443-002-s067><assemble.bauen><en> Not only that, but there are additional trophies available for pirates who diligently assemble a variety of toys.
<G-vec00443-002-s068><assemble.bauen><de> Unsere Monteure bauen Ihr Traumbike individuell auf Sie abgestimmt und nach Ihren Wünschen auf.
<G-vec00443-002-s068><assemble.bauen><en> Our mechanics assemble your dream bike according to your wishes.
<G-vec00443-002-s069><assemble.bauen><de> Um richtige Funktionalität sicherzustellen, bauen wir unser Tast in einer Klasse 100 veranschlagten staubfreie Anlage zusammen, und anstatt die Versammlung manuell zu tun, benutzen wir die völlig automatisierte Ausrüstung, die von unserem eigenen R&D-Team entworfen ist um 10.000 Einheiten jeden Tag zu produzieren.
<G-vec00443-002-s069><assemble.bauen><en> To ensure proper functionality, we assemble our tactile in a class 100-rated dust-free facility, and instead of doing the assembly manually, we use fully automated equipment designed by our own R&D team to produce 10,000 units each day.
<G-vec00443-002-s070><assemble.bauen><de> Dieser mehrteilige Kunststoffbausatz enthält alle Teile, die nötig sind, um Khârn the Betrayer zu bauen, ein Modell mit fester Pose, das mit einer Plasmapistole und seiner Kettenaxt Bluttrinker bewaffnet ist.
<G-vec00443-002-s070><assemble.bauen><en> This multi-part plastic kit contains the components necessary to assemble Khârn the Betrayer, a single-pose model armed with a plasma pistol and his chainaxe, Gorechild.
<G-vec00443-002-s071><assemble.bauen><de> Mit diesem Paket bauen Sie in rund drei Stunden ein transparentes Funktionsmodell des 2-Liter-6-Zylinder-Boxermotors aus dem Jahr 1966.
<G-vec00443-002-s071><assemble.bauen><en> With this kit, you can assemble a model of a 1966 2 litre flat-six engine in around three hours.
<G-vec00443-002-s072><assemble.bauen><de> Auf Wunsch konstruieren und bauen wir nach Ihren individuellen Aufgabenstellungen und Einsatzbereichen spezielle Sonderachsen.
<G-vec00443-002-s072><assemble.bauen><en> Upon request we design and assemble special axes according to your requirements and application areas.
<G-vec00443-002-s073><assemble.bauen><de> Unsere Maschinen sind modular aufgebaut – aus weitgehenden Standardkomponenten (die in Serien gefertigt werden) bauen wir ein Gerät, das genau auf Ihr Medium abgestimmt ist.
<G-vec00443-002-s073><assemble.bauen><en> Our machines are built up modular – mainly from the standard components (which are produced in series) we assemble a device which is tuned exactly to your medium.
<G-vec00443-002-s074><assemble.bauen><de> Dazu nutzen sie eine breite Palette an Teilen, um voll funktionsfähige Raumfahrzeuge zu bauen, die nach den Regeln realistischer Aerodynamik und Orbitalphysik durch das Weltall gleiten – oder eben nicht.
<G-vec00443-002-s074><assemble.bauen><en> You have access to an array of parts to assemble fully-functional spacecraft that flies (or doesn’t) based on realistic aerodynamic and orbital physics.
<G-vec00443-002-s075><assemble.bauen><de> Außerdem bauen wir andere elektronische und mechanische Systeme in unsere eigenen Elektronik- und Kunststoffentwicklungen ein und liefern dem Kunden das vollständige fertige System, einschließlich personalisierter Verpackung, mit Anleitung und absolut bereit für den Versand an den Endkunden.
<G-vec00443-002-s075><assemble.bauen><en> We also assemble other electronic and mechanical systems to our electronic and plastic components in order to supply a fully finished product to the client, even with the packaging personalized, with instructions and perfectly prepared to be sent to the end customer.
<G-vec00443-002-s076><assemble.bauen><de> Wir vertreiben Elektronikbausätze, die einfach zu bauen und lehrreich sind und Spaß machen.
<G-vec00443-002-s076><assemble.bauen><en> We sell electronic DIY kits that are fun, easy to assemble and instructive.
<G-vec00443-002-s077><assemble.bauen><de> Wählen Sie die Basispumpe aus, ergänzen Sie diese mit dem Zubehör Ihrer Wahl - wir bauen, testen und liefern ihnen ihre Pumpe.
<G-vec00443-002-s077><assemble.bauen><en> Choose your basic pump, select your accessories, and we will assemble, test and ship your pump.
<G-vec00443-002-s078><assemble.bauen><de> Wenn du überhaupt nicht in der Lage bist, dir einen Mysticum zu bauen, aber gerne einen haben möchtest, dann kontaktiere mich unter webmaster(at)miclangschach(dot)de.
<G-vec00443-002-s078><assemble.bauen><en> If you are not able at all to assemble your Mysticum on your own, but like to have one, contact me at webmaster(at)miclangschach(dot)de!
<G-vec00443-002-s079><assemble.bauen><de> Die Mitgliedstaaten müssen sicherstellen, dass die Unternehmen, die Explosivstoffe herstellen oder einführen oder Sprengzünder bauen, auf den Explosivstoffen eine eindeutige Kennzeichnung anbringen.
<G-vec00443-002-s079><assemble.bauen><en> Member States must ensure that companies which manufacture or import explosives, and those which assemble detonators mark these products with a unique identification.
<G-vec00443-002-s080><assemble.bauen><de> Journalisten, die den New Phantom bei diesem Medienevent zu den Luzerner Arbeitsräumen von ochs und junior lenken, werden einen Ewigen Kalender bauen.
<G-vec00443-002-s080><assemble.bauen><en> Journalists who drive the New Phantom to ochs und junior’s Lucerne workshop during the press launch will assemble a perpetual calendar.
<G-vec00510-002-s171><grow.bauen><de> Überwachen Sie Hunderte oder sogar Tausende von Geräten über IP-, Analog- und ALPR-Kameras, um Zugriff auf Controller und Türlesegeräte zu erhalten, und bauen Sie Ihr System auf eine beliebige Größe aus.
<G-vec00510-002-s171><grow.bauen><en> Monitor hundreds or thousands of devices from IP, analog and ALPR cameras to access controllers and door readers, and grow your system to any size.
<G-vec00510-002-s172><grow.bauen><de> Dort bauen heute circa 600 Bauern aus zehn Provinzen 14 verschiedene Produkte für Rapunzel an – darunter Feigen, Aprikosen, Sultaninen, Haselnüsse, Pinienkerne und Tomaten.
<G-vec00510-002-s172><grow.bauen><en> Today about 600 farmers from ten different Turkish provinces grow produce for 14 different Rapunzel products. These include figs, apricots, sultanas, hazelnuts, pine cones and tomatoes.
<G-vec00510-002-s173><grow.bauen><de> Gemüsegarten: Wir bauen eine Vielzahl von Obst und Gemüse in einem Genossenschaftsgarten in dem Dorf Nueva Mercedes.
<G-vec00510-002-s173><grow.bauen><en> Vegetable Garden: We grow a variety of fruit and vegetables in a cooperative garden in the village of Nueva Mercedes.
<G-vec00510-002-s174><grow.bauen><de> Das heißt, dass Kaffeefarmer ihre Bohnen verkaufen ohne gut davon leben zu können, also machen sie dicht oder bauen lieber Bananen oder auch Opium an.
<G-vec00510-002-s174><grow.bauen><en> Which means that farmer sell their beans without being able to make a living from it, so they close the farms or turn to grow bananas or opium.
<G-vec00510-002-s175><grow.bauen><de> Bauen Sie Ihren Kundenstamm mit SEO, SEM und Einblicken aus E-Mail-Kampagnen aus.
<G-vec00510-002-s175><grow.bauen><en> Grow your customer base with SEO, SEM, and email campaign insights.
<G-vec00510-002-s176><grow.bauen><de> California Dream feminisierte Samen sind eine kalifornische Hybride von Indica-Sativa, so bauen Sie diese draußen nur in tropischen Klimas an, aber das beste ist, es drinnen anzubauen.
<G-vec00510-002-s176><grow.bauen><en> California Dream feminized seeds are a Californian Indica-Sativa hybrid, so only grow this outdoors in tropical climates, but the best is just to grow indoors.
<G-vec00510-002-s177><grow.bauen><de> Erhöhen Sie das Engagement und die Produktivität Ihrer Mitarbeiter und bauen Sie Leadership-Pipelines auf, indem Sie potenzielle Positionen für bestimmte Mitarbeiter identifizieren.
<G-vec00510-002-s177><grow.bauen><en> Increase engagement, productivity and grow leadership pipelines by seeing positions in which specific employees are likely to succeed.
<G-vec00510-002-s178><grow.bauen><de> Da der Boden sehr jung und fruchtbar ist, bauen wir hauptsächlich Gemüse: Kohl, Möhren und außerdem Getreide an.
<G-vec00510-002-s178><grow.bauen><en> Since the soil is very young and fertile, we mainly grow vegetables: cabbage, carrots, and corn also on.
<G-vec00510-002-s179><grow.bauen><de> Auf der Farm bauen wir Obst und Gemüse an, und halten auch Tiere wie Ziegen, Schweine, Kühe und Geflügel.
<G-vec00510-002-s179><grow.bauen><en> On the farm we grow fruit and vegetables, and hold also animals like goats, pigs, cows and fowl.
<G-vec00510-002-s180><grow.bauen><de> Die Züchter und Forscher von KWS untersuchen solche Maispflanzen genau, sagt Peter: „Wir bauen sie zum Beispiel auf Feldern mit sehr wenig Stickstoff an und schauen, welche Maispflanzen unter diesen Bedingungen am besten zurechtkommen.“ Eine Ursache ist zum Beispiel, dass Pflanzen mit einem besonders weit verzweigten und dichten Wurzelwerk mehr Kontakt zum Erdreich haben und daher etwas mehr Stickstoff aufnehmen können, erklärt Presterl.
<G-vec00510-002-s180><grow.bauen><en> KWS breeders and researchers examine such corn plants. Peter explained, “For example, we grow them in fields with very little nitrogen and look to see which corn plants cope best under these conditions.” “One reason is, for example, that plants with a particularly widely branched and dense root system have more contact with the soil and therefore can absorb a little more nitrogen,” explained Presterl.
<G-vec00510-002-s181><grow.bauen><de> Einige bauen Mais und Soja an, manche Weizen, andere Reis.
<G-vec00510-002-s181><grow.bauen><en> Some grow corn and soy. Some grow wheat. Others grow rice.
<G-vec00510-002-s182><grow.bauen><de> Sparen Sie Zeit und Geld mit einer Wärmebildkamera TiR110, und bauen Sie Ihr Geschäft aus, indem Sie Ihren Kunden mehr Leistungen anbieten.
<G-vec00510-002-s182><grow.bauen><en> Save time & money with a TiR110 Infrared Camera & grow your business by offering customers more services.
<G-vec00510-002-s183><grow.bauen><de> Sie bauen ein wenig für den eigenen Bedarf an und haben eine Kuh und einen Bullen.
<G-vec00510-002-s183><grow.bauen><en> They grow a little food for their own consumption, and own one cow and one bull.
<G-vec00510-002-s184><grow.bauen><de> Sie bauen Kartoffeln, Radieschen, Karotten und anderes Gemüse an.
<G-vec00510-002-s184><grow.bauen><en> They grow potatoes, radishes, carrots and other vegetables.
<G-vec00510-002-s185><grow.bauen><de> Betriebe, deren Ziel es ist, einen stabilen Ertrag zu erzielen, der Pestizide, Herbizide, Nitrate und andere schädliche Substanzen im zulässigen Rahmen enthält, bauen Auberginen nur in geschützten Böden an.
<G-vec00510-002-s185><grow.bauen><en> Farms aimed at obtaining a good stable yield containing pesticides, herbicides, nitrates and other harmful substances in the allowable limits grow eggplants only in protected ground.
<G-vec00510-002-s186><grow.bauen><de> Mit großer Achtung vor dem Schutz der natürlichen Umwelt und vor der Gesundheit unserer Gäste, sowie unserer Angestellten bauen wir auf traditionelle Weise Obst und Gemüse an, das die Küchenchefs unserer Hotels täglich für die Zubereitung ihrer Menüs verwenden.
<G-vec00510-002-s186><grow.bauen><en> With total respect to the protection of the natural environment and the health of our guests and our staff we grow fruit and vegetables the traditional way which our chefs use daily in the dishes of our restaurants.
<G-vec00510-002-s187><grow.bauen><de> Nein, wir bauen nicht unser eigenes Getreide an.
<G-vec00510-002-s187><grow.bauen><en> No, we don't grow our own grain.
<G-vec00510-002-s188><grow.bauen><de> Insgesamt bauen sie auf einer Fläche von etwa 11,5 Hektaren zwischen 400 und 500 Tonnen der leckeren kleinen Kürbisgewächse an.
<G-vec00510-002-s188><grow.bauen><en> Together they grow between 400 and 500 tonnes of these prized cucurbits across a total surface area of 11.5 hectares.
<G-vec00510-002-s189><grow.bauen><de> Landwirte bauen bestimmte Pflanzen an und halten Tiere, um die Nachfrage der modernen Lebensmittelversorgungskette zu bedienen, wobei der kleine Biobauernhof ganz andere Produktionsmethoden einsetzt als die industrielle Landwirtschaft.
<G-vec00510-002-s189><grow.bauen><en> Farmers grow crops and raise animals to fulfil the demands of today’s food supply chain and production methods vary greatly from small organic farms to industrial agriculture.
<G-vec00520-002-s087><rely.bauen><de> Hunderte Unternehmen weltweit bauen auf die Lösungen von Teleopti, um optimale Effizienz zu erreichen und höchste Servicequalität zu bieten.
<G-vec00520-002-s087><rely.bauen><en> Hundreds of enterprises around the world rely on solutions from Teleopti to attain optimal operational efficiency and provide the highest levels of service.
<G-vec00520-002-s088><rely.bauen><de> Herausfinden, warum Kunden innen über 50 Ländern auf unsere Dienstleistungen bauen.
<G-vec00520-002-s088><rely.bauen><en> Find out why buyers in over 50 countries rely on our services.
<G-vec00520-002-s089><rely.bauen><de> Wir bestehen auf Strategie - „personenorientiert und bauen auf wissenschaftlichen und technologischen Fortschritt“ und haben die R&D-Mitte der spätesten Technologie, Präfekt und fortgeschrittenes ergänzendes Produktionsgerät und ausgezeichnete Managementtalente.
<G-vec00520-002-s089><rely.bauen><en> We insist on strategy - "People oriented and Rely on scientific and technological progress", having the R&D Center of the latest technology, prefect and advanced complementary production equipment, and excellent management talents.
<G-vec00520-002-s090><rely.bauen><de> Heute bauen hunderttausende kleine Geschäften in 31 Ländern weltweit auf SumUp und unseren Service.
<G-vec00520-002-s090><rely.bauen><en> Today, hundreds of thousands of small businesses in 31 countries around the world rely on SumUp to get paid.
<G-vec00520-002-s091><rely.bauen><de> Die Experten für sichere und moderne Cloud-Lösungen – BADEN CLOUD mit eigenem Rechenzentrum – bauen auf Regionalität, Nähe zum Kunden und praktikable Lösungen.
<G-vec00520-002-s091><rely.bauen><en> The experts in secure and modern cloud solutions – BADEN CLOUD with its own computing centre – rely on a regional orientation, their proximity to clients and practicable solutions.
<G-vec00520-002-s092><rely.bauen><de> Wenn du dich dennoch dafür entscheidest, ein Deck aus wenigen, dafür aber mächtigen Karten zu erschaffen, musst du auf gutes Glück und deine Fähigkeit bauen, diese Karten perfekt auszuspielen.
<G-vec00520-002-s092><rely.bauen><en> So if you opt for using a deck of few, but powerful cards, you will have to rely on good luck and your ability to perfectly play these cards.
<G-vec00520-002-s093><rely.bauen><de> Ein Klebespezialist, auf den Sie bauen können.
<G-vec00520-002-s093><rely.bauen><en> An adhesives specialist you can rely on
<G-vec00520-002-s094><rely.bauen><de> Dank solider Ausbildung von Jugendlichen in verschiedenen technischen und kaufmännischen Berufen sowie eines konsequenten Weiterbildungsprogramms kann MARTIN auf hochmotivierte und exzellent ausgebildete Mitarbeiter bauen – die Basis für stetige Innovation.
<G-vec00520-002-s094><rely.bauen><en> Thanks to the solid professional training of young people in a whole range of technical and administrative professions and external training programs for every employee, MARTIN can rely on 145 highly motivated and excellently educated staff.
<G-vec00520-002-s095><rely.bauen><de> Ich, nein WIR bauen auf EURE Unterstützung...
<G-vec00520-002-s095><rely.bauen><en> I, no we, rely on YOUR support…
<G-vec00520-002-s096><rely.bauen><de> Gewöhnlich ist ein Liquidität zweiten Grades von 1:1 oder höher gut und zeigt, dass eine Firma nicht auf den Verkauf des Warenbestands bauen muss, um die Rechnungen zu zahlen.
<G-vec00520-002-s096><rely.bauen><en> Typically, a Quick Ratio of 1:1 or higher is good, and indicates a company does not have to rely on the sale of inventory to pay the bills.
<G-vec00520-002-s097><rely.bauen><de> Wir begrüßen daher, dass Rumänien in der neuen EU-Förderperiode ab 2014 die Chance hat, beim Einsatz gegen Armut und für sozialen Zusammenhalt stärker auf die finanzielle Unterstützung der EU zu bauen.
<G-vec00520-002-s097><rely.bauen><en> We therefore welcome the fact that in the new EU funding period from 2014 Romania will have the opportunity to rely more strongly on financial support from the EU in its efforts to combat poverty and ensure social cohesion.
<G-vec00520-002-s098><rely.bauen><de> Wir bauen auf den christlichen Grundkonsens zwischen Eltern, Schülern und Kollegium und möchten jungen Menschen, die die Frage nach Gott und dem Sinn des Lebens stellen, eine Antwort vermitteln.
<G-vec00520-002-s098><rely.bauen><en> We rely on a Christian consensus between parents, students and members of staff and would like to provide young people with answers to their questions on God and the meaning of life.
<G-vec00520-002-s099><rely.bauen><de> Ich muss auf andere bauen, wenn ich eine meiner Spielwaren fallenlasse oder sogar überall in meinen Rollstuhl gehen.
<G-vec00520-002-s099><rely.bauen><en> I need to rely on others if I drop one of my toys or even to go anywhere in my wheelchair.
<G-vec00520-002-s100><rely.bauen><de> Der Grund für dieses ist viele Search Engines bauen auf Schlüsselwörter, mindestens teilweise, um zu helfen, den Rank Ihrer Webseite festzustellen, wenn bestimmte Schlüsselwörter nach gesucht werden.
<G-vec00520-002-s100><rely.bauen><en> The reason for this is many search engines rely on keywords, at least partially, to help determine the rank of your web page when certain keywords are searched for.
<G-vec00520-002-s101><rely.bauen><de> Bauherren, Architekten und Ingenieure bauen auf die Qualität und Termintreue von PFEIFER-Seilbau, sichern sich schon in der frühen Projektentwicklung unsere Unterstützung und vertrauen unserer Sorgfalt und jahrzehntelanger Erfahrung.
<G-vec00520-002-s101><rely.bauen><en> Clients, architects and engineers rely on the quality and adherence to delivery dates of PFEIFER Cable Structures, securing our technical support from the very outset of the project and putting their trust in our care and decades of experience.
<G-vec00520-002-s102><rely.bauen><de> Bei der Organisation Ihrer Veranstaltung können Sie auf unsere Erfahrungen und unser Know-how bauen.
<G-vec00520-002-s102><rely.bauen><en> When organizing your event, you can rely on our experience and know-how.
<G-vec00520-002-s103><rely.bauen><de> Wir können auf die schlichte Wahrheit bauen, dass er unser Vater ist und wir seine Kinder sind.
<G-vec00520-002-s103><rely.bauen><en> We can rely on the simple truth that He is our Father and we are His children.
<G-vec00520-002-s104><rely.bauen><de> Dank unserer Partnerschaft mit HEDRICH können wir auf Mitarbeiter in vielen unterschiedlichen Ländern bauen.
<G-vec00520-002-s104><rely.bauen><en> Thanks to our partnership with HEDRICH, we can rely on employees in many different countries.
<G-vec00520-002-s105><rely.bauen><de> Mit Produkten von GEA Farm Technologies bauen Sie auf Sicherheit und Stabilität.
<G-vec00520-002-s105><rely.bauen><en> With GEA Farm Technologies products you will rely on security and stability.
<G-vec00084-002-s083><assemble.bauen><de> Bauen Sie die SSD in den 2,5-Zoll-zu-3,5-Zoll-Einbaurahmen und dann den Einbaurahmen in ein leeres HDD-Fach ein.
<G-vec00084-002-s083><assemble.bauen><en> Assemble the SSD in a 2.5" to 3.5" bracket first and then mount the bracket in an empty HDD bay.
<G-vec00084-002-s084><assemble.bauen><de> Spülen und trocknen Sie die Stanzvorrichtung und den Getränkeauslauf und bauen Sie diese wieder zusammen, bevor Sie sie wieder in die Brühvorrichtung zurücksetzen.
<G-vec00084-002-s084><assemble.bauen><en> Rinse and dry the piercer and nozzle and then assemble back together before inserting back into the brewing unit.
<G-vec00084-002-s133><build.bauen><de> Grundstück in Erlaubnis zum Bau einer großen Villa mit Pool und Garten, in der Nähe von allen Annehmlichkeiten in Lagoa.
<G-vec00084-002-s133><build.bauen><en> Plot with permission to build a large villa with pool and garden, located close to all amenities with good access, between Estômbar and Lagoa.
<G-vec00084-002-s134><build.bauen><de> Die derzeit gültigen Baunormen erlauben auf jedem Grundstück den Bau eines Landhauses mit bis zu 500 m² Wohnfläche.
<G-vec00084-002-s134><build.bauen><en> The currently applicable building codes allow on each property to build a country house with up to 500 m² of living space.
<G-vec00084-002-s135><build.bauen><de> Geschichte Das B&B besteht seit Sommer 2008, aber die Geschichte dieses Hauses ist schon viel älter – sie beginnt in den frühen 60er Jahren, als Peppino Aiello und Lucia Puccio sich zum Bau des Hauses entschieden haben.
<G-vec00084-002-s135><build.bauen><en> History The Bed and Breakfast business in the Casa di Peppino e Lucia was started in the summer of 2008, but the history of this house began in the early 60’s when Peppino Aiello and Lucia Puccio decided to build it.
<G-vec00084-002-s136><build.bauen><de> Mit unseren Grundstücksangeboten auf Mallorca können Sie das perfekte Grundstück für Ihren Bau finden.
<G-vec00084-002-s136><build.bauen><en> With our listings of land for sale in Mallorca you can find that perfect plot to start your build.
<G-vec00084-002-s137><build.bauen><de> Den Großteil der Rohstoffe (wie Holz und Co.), die wir zum Bau unserer liebevollen Floors benötigen, beziehen wir aus der Region.
<G-vec00084-002-s137><build.bauen><en> The majority of the raw materials (such as wood and Co.), which we need to build our loving Floors, we source from the region.
<G-vec00084-002-s138><build.bauen><de> Im Jahr 2001 beschloss Sultan Qaboos durch ein königliches Dekret den Bau eines Opernhauses in Omans Haupt...
<G-vec00084-002-s138><build.bauen><en> In 2001, Sultan Qaboos decided by royal decree to build an opera house in Oman's capital, Muscat.
<G-vec00084-002-s139><build.bauen><de> Als sie nach Beendigung des Goldrausches nach Arbeit suchten, stellten die Farmer sie zum Bau von Dämmen an.
<G-vec00084-002-s139><build.bauen><en> When the rush finished, they were desperate for work, so the farmers had them build dams.
<G-vec00084-002-s140><build.bauen><de> Wer sich diesen Bausatz kauft, der sollte sich bewußt sein, daß er hier pure Science Fiction erwirbt oder eine schöne Grabelkiste mit Einzelteilen zum Bau verschiedener besserer Mistel Modelle.
<G-vec00084-002-s140><build.bauen><en> Who ever buys this kit should know that he buys pure Science Fiction or a nice spare parts box with parts to build several better Mistel Models .
<G-vec00084-002-s141><build.bauen><de> Das Innere der Kirche besteht aus verschiedenen, aber gut harmonierenden Materialien: der Boden ist aus Calitea mit weißen Marmor und einem grauen Kreuz aus Gramata Marmor – der gleiche Stein, der für den Bau der Kanzel benutzt wurde; die Fensterscheiben sind aus Onyx, die Balustraden und der Altar aus Marmor, die Tische gigantische Gramata Marmor Steinblöcke und die Stiftshütten sind aus Camiro Stein.
<G-vec00084-002-s141><build.bauen><en> The inside of the church is made of different but harmonious materials: the floor is of Kalithea white marble with a grey cross of Gramata marble – the same kind of stone was used to build the pulpit; the window panes are in onyx, the balustrades and the altars in marble, the tables are monolithic blocks of Gramata stone and the tabernacles are in Kamiros stone.
<G-vec00084-002-s142><build.bauen><de> Der Bau des XOno lohnt sich meiner Meinung nach auf jeden Fall und ist sicherlich ein Gewinn in fast jeder Audio Kette.
<G-vec00084-002-s142><build.bauen><en> To build the XOno is in my opinion a plus for most audio systems.
<G-vec00084-002-s143><build.bauen><de> Im Museum der Stadtgeschichte können Sie auch die Verwendung der Grabsteine zum Bau der Stadtmauer sehen.
<G-vec00084-002-s143><build.bauen><en> At the museum of the city's history you can see that the grave stones were used to build the city walls.
<G-vec00084-002-s144><build.bauen><de> Die geschätzte Projektwirtschaftlichkeit für den Bau und Betrieb einer Goldmine mit 750 Tagestonnen Kapazität bei New Polaris mittels Bio-Oxidation gefolgt von einem Laugungsverfahren zur Herstellung von 80.000 Unzen Gold pro Jahr in Form von Doré-Barren vor Ort durch Canarc ist vernünftigerweise erreichbar.
<G-vec00084-002-s144><build.bauen><en> The estimated project economics for Canarc to build and operate a 750 tonne per day gold mine at New Polaris using bio-oxidation followed by a leaching process to produce 80,000 ounces of gold per year in doré bars at site are reasonably achievable for this project.
<G-vec00084-002-s145><build.bauen><de> Die KfW ist zudem an einem Fonds beteiligt, der den Bau energieeffizienter Häuser für Menschen mit mittleren und niedrigen Einkommen finanziert.
<G-vec00084-002-s145><build.bauen><en> KfW is also contributing to a fund that provides finance to help people on moderate or low incomes to build energy-efficient houses.
<G-vec00084-002-s146><build.bauen><de> Schwerpunkt bleibt der Ausbau der erneuerbaren Energien und der Bau von hocheffizienten fossil befeuerten Kraftwerken.
<G-vec00084-002-s146><build.bauen><en> The focus remains to increase renewable capacity and to build highly efficient fossil-fuel-fired power stations.
<G-vec00084-002-s147><build.bauen><de> Die Vergabe dieses großen Vertrags über den Bau des Schutzbaus und der Hauptstruktur wird voraussichtlich gegen Ende des Jahres 2014 abgeschlossen sein.
<G-vec00084-002-s147><build.bauen><en> This big contract to build the dome and main structure is expected to be awarded towards the end of 2014.
<G-vec00084-002-s148><build.bauen><de> Es gibt mehr Möglichkeiten für Bau, Eroberung und Inspiration als je zuvor.
<G-vec00084-002-s148><build.bauen><en> There are more ways than ever before to build, conquer, and inspire.
<G-vec00084-002-s149><build.bauen><de> Bau dir dein eigenes RePricing für ebay.
<G-vec00084-002-s149><build.bauen><en> Build yourself your own RePricing for eBay.
<G-vec00084-002-s150><build.bauen><de> „Ich bin ein Nachkomme von Sir Sobha Singh, einem engen Mitarbeiter von Sir Edwin Lutyens bei Planung und Bau der Stadt Neu Delhi.
<G-vec00084-002-s150><build.bauen><en> Call "I am the descendant of Sir Sobha Singh who worked closely with Sir Edwin Lutyens to construct and build the city of New Delhi.
<G-vec00084-002-s151><build.bauen><de> 8 So zerstreute der Herr die Menschen über die ganze Erde; den Bau der Stadt mussten sie abbrechen.
<G-vec00084-002-s151><build.bauen><en> So the LORD scattered them abroad from thence upon the face of all the earth: and they left off to build the city.
<G-vec00084-002-s152><build.bauen><de> Baue ein Kartenhaus mit dem höchstmöglichen Wert.
<G-vec00084-002-s152><build.bauen><en> Build a house from cards with the highest value.
<G-vec00084-002-s153><build.bauen><de> Baue eine Farm.
<G-vec00084-002-s153><build.bauen><en> Build a Farm.
<G-vec00084-002-s154><build.bauen><de> Baue 100 Raketen-Türme.
<G-vec00084-002-s154><build.bauen><en> Build 100 Missile towers.
<G-vec00084-002-s155><build.bauen><de> Mit Live und Push hat sich das komplett geändert eigentlich, weil ich fang entweder mit einer Melodie oder einem Drum-Loop an, den ich mir zusammenbaue und baue dann darauf auf und das Lied entsteht so währenddessen.
<G-vec00084-002-s155><build.bauen><en> With Live and Push this has completely changed actually, because I either start with a melody or a drum loop that I construct myself and then build on it and the song is created along the way.
<G-vec00084-002-s156><build.bauen><de> 3 Wer irgend unter euch aus seinem Volke ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem, das in Juda ist, und baue das Haus Jahwes, des Gottes Israels (er ist Gott), in Jerusalem.
<G-vec00084-002-s156><build.bauen><en> Ezra 1:3 - Who is there among you of all his people? his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of the LORD God of Israel, (he is the God,) which is in Jerusalem.
<G-vec00084-002-s157><build.bauen><de> Baue Schulter- und Nackenmuskulatur auf, indem du seitliche Hantelübungen für mehr Kraft ausführst.
<G-vec00084-002-s157><build.bauen><en> Build shoulder muscles by lifting dumbbells out from your sides for resistance.
<G-vec00084-002-s158><build.bauen><de> Baue Holzlager, um für stetigen Nachschub an Rohmaterial zu sorgen und verbessere sie, um deine Produktion zu steigern.
<G-vec00084-002-s158><build.bauen><en> Build Lumber Yards to secure a steady supply of raw materials and Upgrade them to increase production.
<G-vec00084-002-s159><build.bauen><de> Baue deinen Biokostladen, ein gemütliches Kino, einen altmodischen Imbiss, ein entspannendes Kurbad, eine klassische Pension, ein verträumtes Strandcafé und mehr.
<G-vec00084-002-s159><build.bauen><en> Build your organic grocery store, cozy movie theater, vintage diner, relaxing spa, classic Bed & Breakfast, dreamy beach cafe and more.
<G-vec00084-002-s160><build.bauen><de> Gegründet 1947 von Edwin J. Montalvo Sr. gilt bei der Montalvo Corporation nach wie vor ihr Grundprinzip, auf dem es aufgebaut wurde: baue ein Produkt bereits beim ersten Mal richtig und unterstütze es mit einem erstklassigen Service und Support.
<G-vec00084-002-s160><build.bauen><en> Founded in 1947 by Edwin J. Montalvo Sr. the Montalvo Corporation continues the core principle it was built on: build a product right the first time and back it up with the highest quality service and support.
<G-vec00084-002-s161><build.bauen><de> Traumteam zusammenstellen - Verpflichte die besten Fußballstars aller Zeiten und baue in FIFA Ultimate Team eine Mannschaft auf, die dir jede Menge Ruhm einbringt.
<G-vec00084-002-s161><build.bauen><en> Build your dream team - Choose from among the best football stars of all time and build a team to take home the glory in FIFA Ultimate Team.
<G-vec00084-002-s162><build.bauen><de> Baue, verbaue und verkaufe Häuser.
<G-vec00084-002-s162><build.bauen><en> Build, buy and sell houses.
<G-vec00084-002-s163><build.bauen><de> Erlebe die dunkle Welt der dunklen Seelen, baue deinen Charakter Schritt nach Schritt auf, entdecke erschreckende Orte und sammle und meistere eine umfangreiche Sammlung von Waffen, Ausrüstung und Zaubersprüchen, um ein wirklich einzigartiges Spielerlebnis zu erschaffen.
<G-vec00084-002-s163><build.bauen><en> Let yourself be engulfed by the rich world of the Dark Souls. Gradually build your character, discover scary locations, and collect and master an extensive range of weapons, equipment and magic spells to create a truly unique gaming experience.
<G-vec00084-002-s164><build.bauen><de> 3Wer nun unter euch von seinem Volk ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem in Juda und baue das Haus des HERRN, des Gottes Israels; das ist der Gott, der zu Jerusalem ist.
<G-vec00084-002-s164><build.bauen><en> His God is with him, and he doth go up to Jerusalem, that [is] in Judah, and build the house of Jehovah, God of Israel -- He [is] God -- that [is] in Jerusalem.
<G-vec00084-002-s165><build.bauen><de> Baue dein Anliegen mit logischen Argumenten und Fakten auf und setze dann einen emotionalen Bestandteil ein.
<G-vec00084-002-s165><build.bauen><en> Build your case with logical reasoning and fact while adding in an emotional element.
<G-vec00084-002-s166><build.bauen><de> Baue deine Fremdsprachkenntnisse und dein Selbstvertrauen durch interaktiven Online-Unterricht auf.
<G-vec00084-002-s166><build.bauen><en> Build fluency and confidence through interactive Danish classes that are effective and fun.
<G-vec00084-002-s167><build.bauen><de> Baue dein eigenes Monster Vehikel, mit Deinen bevorzugten Waffen.
<G-vec00084-002-s167><build.bauen><en> Build your own monster vehicle with weapons to take part in crazy racing tracks.
<G-vec00084-002-s168><build.bauen><de> Baue eine Gruppe aus berühmten Kriegern und epischen Monstern aus...
<G-vec00084-002-s168><build.bauen><en> Build a party of famous warriors and epic monsters from Dragon...
<G-vec00084-002-s169><build.bauen><de> Wenn ich für einen Zoo ein Elefantenhaus baue, muss ich mich mit Elefanten beschäftigen.
<G-vec00084-002-s169><build.bauen><en> If I build an elephant house for a zoo, I have to deal with elephants.
<G-vec00084-002-s170><build.bauen><de> Ich baue zwei neue Motorräder auf.
<G-vec00084-002-s170><build.bauen><en> I build two new bikes.
<G-vec00084-002-s171><build.bauen><de> 3:2 Und er fing an zu bauen im zweiten Monat, am zweiten [Tag] im vierten Jahr seiner Regierung.
<G-vec00084-002-s171><build.bauen><en> 3:2 He began to build in the second [day] of the second month, in the fourth year of his reign.
<G-vec00084-002-s172><build.bauen><de> Bauen Sie ein schönes Paar Pandora Ohrring mit diesen 14K Gold und Onyx Tropfen Reize.
<G-vec00084-002-s172><build.bauen><en> Build a beautiful pair of Pandora earring with these 14K gold and Onyx Drop charms.
<G-vec00084-002-s173><build.bauen><de> In einem der wenigen Orte auf der Welt, wo man am Morgen surfen und am Nachmittag Skifahren kann, hat sich Nick vorgenommen, ein Fahrzeug zu bauen, das mit den klimatischen Extremen seines "Stadtabendteuers" umgehen konnte.
<G-vec00084-002-s173><build.bauen><en> In one of the few places in the world where you can surf in the morning and ski in the afternoon, Nick set out to build a vehicle that could deal with the climatic extremes of his “Urban Adventures”.
<G-vec00084-002-s174><build.bauen><de> 10Siehe, ich bestelle dich an diesem Tage über die Nationen und über die Königreiche, um auszurotten und niederzureißen und zu zerstören und abzubrechen, um zu bauen und um zu pflanzen.
<G-vec00084-002-s174><build.bauen><en> 10See, today I appoint you over nations and kingdoms to uproot and tear down, to destroy and overthrow, to build and to plant.’
<G-vec00084-002-s175><build.bauen><de> Bemusterungszentrum Hartenfels „Die Entscheidung ein Haus zu bauen ist elementar und langfristig.
<G-vec00084-002-s175><build.bauen><en> "The decision to build a house is elementary and a long-term decision.
<G-vec00084-002-s176><build.bauen><de> Wir sind zuversichtlich, dass wir ein System erschaffen können, welches sich fest an unsere Bedingungen anpasst und dabei einfach zu entwerfen, bauen und einzusetzen ist.
<G-vec00084-002-s176><build.bauen><en> We are confident that we can create a system that is tightly scoped to our needs that will not be complex to design, build and deploy.
<G-vec00084-002-s177><build.bauen><de> Bauen Sie ganz einfach Ihre eigene maßgeschneiderte App auf, um den speziellen – und sich verändernden – Anforderungen Ihres Unternehmens gerecht zu werden.
<G-vec00084-002-s177><build.bauen><en> Easily build your own custom app to meet the unique – and changing – needs of your business.
<G-vec00084-002-s178><build.bauen><de> 3 Du weißt, daß David, mein Vater, nicht vermochte, ein Haus zu bauen dem Namen Jehova's, seines Gottes, wegen des Krieges, womit sie ihn umgaben, bis sie Jehova unter seine Fußsohlen legte.
<G-vec00084-002-s178><build.bauen><en> 3 You know how that David my father could not build an house to the name of the LORD his God for the wars which were about him on every side, until the LORD put them under the soles of his feet.
<G-vec00084-002-s179><build.bauen><de> Seitdem ist es sein Anspruch, das bestmögliche Werkzeug überhaupt zu bauen.
<G-vec00084-002-s179><build.bauen><en> Since then it has been his claim to build the best possible tools ever.
<G-vec00084-002-s180><build.bauen><de> Mira Die öffentlich bekannt gegebene Tatsache, dass einige Geschäftsmänner große Hotelkomplexe auf verschiedenen naturgeschützten Geländen zu bauen beabsichtigen, wobei sie gültige Gesetze missachten, provozierte die zivile Öffentlichkeit, womit diese ursprünglich ökologisch motivierten Proteste zu einem zivilen, viele Studenten und Jugendliche anziehenden Widerstand wurden.
<G-vec00084-002-s180><build.bauen><en> The announced fact that some businessmen are planing to build big hotel complexes on different nature protected areas abusing all existing laws provokes civic attention and in fact this ecological in its beginning protests grown into civil ones, attracting a lot of students and young people.
<G-vec00084-002-s181><build.bauen><de> Hier genießt man Ruhe, hat eine gute Anbindung, eine schöne Umgebung und Platz, um eine große Villa mit Pool und Terrassen zu bauen.
<G-vec00084-002-s181><build.bauen><en> This lovely plot is tranquill, has good connections, beautiful surroundings and ample space to build a large villa with pool and terraces.
<G-vec00084-002-s182><build.bauen><de> Mit Drupal 8 können Sie so gut wie jeden integrierten Web-Auftritt bauen, den Sie sich vorstellen können.
<G-vec00084-002-s182><build.bauen><en> With Drupal 8, you can build almost any integrated experience you can imagine.
<G-vec00084-002-s183><build.bauen><de> Wir bauen auf die Erfahrung, Motivation und Qualifikation unserer Mitarbeitenden, um selbst die anspruchsvollsten Kundenanforderungen kompetent und mit persönlichem Einsatz zu erfüllen.
<G-vec00084-002-s183><build.bauen><en> We build on the experience, motivation and qualifications of our employees to fulfill the most sophisticated customer requirements with excellence and dedication.
<G-vec00084-002-s184><build.bauen><de> Bauen Sie mit LemonChili viele Seiten und Getränkekarte, wie Sie wollen.
<G-vec00084-002-s184><build.bauen><en> Build with LemonChili many pages and beverage menu, as you want.
<G-vec00084-002-s185><build.bauen><de> «Immer mehr Istanbuler erwerben außerdem Land in der Um- gebung, um Villen und Ferienhäuser zu bauen – dieses Land geht der Landwirt- schaft verloren.
<G-vec00084-002-s185><build.bauen><en> “More and more Is- tanbulites are buying land in the area to build villas and holiday homes, thus taking land away from agriculture.
<G-vec00084-002-s186><build.bauen><de> Helfen Sie Jane die heikelste Kunden glücklich zu machen: Wählen Sie raffinierte Möbel, einen Golfplatz zu bauen und bitte Sie Ihre Kunden mit exquisiten Drinks und gutes Essen.
<G-vec00084-002-s186><build.bauen><en> Help Jane to make the pickiest customers happy: choose refined furniture, build a golf course and please your customers with exquisite drinks and good meals.
<G-vec00084-002-s187><build.bauen><de> Unser Ziel ist es, leichtgewichtige, effiziente Geländeräder zu bauen, die das Gleichgewichthalten, die Koordination und das Selbstvertrauen von Kindern fördern.
<G-vec00084-002-s187><build.bauen><en> Our mission is to build lightweight, efficient, all-terrain bikes that build two-wheeled balance, coordination, and confidence in children.
<G-vec00084-002-s188><build.bauen><de> Unser Ziel ist es, Immobilien und deren Umfeld zu bauen und zu betreiben, so dass mit einem Minimum an Ressourcen (Ökologie, Ökonomie, Personalaufwand) ein Maximum an Nutzerzufriedenheit, Produktivität und Effizienz erreicht werden kann.
<G-vec00084-002-s188><build.bauen><en> It is our aim to build and operate properties with their setting, with the result to achieve a maximum of user satisfaction, productivity and efficiency by using a minimum of resources (ecology, economy, personal expenditure).
<G-vec00084-002-s189><build.bauen><de> Wir planen, konstruieren, bauen und installieren manuelle und automatische Anlagen für die Nahtabdichtungen, Kosmetiksealer, Unterbodenschutzauftrag, Schweller-Beschichtungssysteme sowie für spritzbare Schalldämmmassen.
<G-vec00084-002-s189><build.bauen><en> Print Bodyshop We engineer, design, build and install manual as well as automatic systems for hemflange adhesive application as well as for cosmetic sealing, untiflutter and sounddeadener.
<G-vec00084-002-s190><build.bauen><de> Schützen Sie die Geräte, auf die Kunden angewiesen sind, und bauen Sie das Vertrauen in Ihre Marke auf.
<G-vec00084-002-s190><build.bauen><en> Protect the devices customers depend on and build trust in your brand.
<G-vec00084-002-s191><build.bauen><de> Multiplayer: Bauen Sie zum ersten Mal mit Freunden eine ganze Region auf.
<G-vec00084-002-s191><build.bauen><en> Multiplayer— Build a region with friends for the first time!
<G-vec00084-002-s192><build.bauen><de> Bauen Sie engere Kundenbeziehungen und ein personalisiertes digitales Erlebnis mit KI auf, während die Kosten sinken und der Return-on-Investment steigt.
<G-vec00084-002-s192><build.bauen><en> Build deeper customer relationships and personalized digital experiences with AI, while lowering operating costs and boosting return on investment.
<G-vec00084-002-s193><build.bauen><de> Bauen Sie mit einer Schritt-für-Schritt-Methode auf Ihrer bestehenden IT-Infrastruktur auf und nutzen Sie dabei Technologien, die eigens in Hinblick auf eine Optimierung Ihrer künftigen Infrastruktur entwickelt wurden.
<G-vec00084-002-s193><build.bauen><en> Build upon your existing IT infrastructure with a step-by-step approach featuring technologies engineered to optimize your future infrastructure. Learn more Events
<G-vec00084-002-s194><build.bauen><de> Bauen Sie mithilfe des Punktestands einzelner Kunden personalisierte Automatisierungsworkflows.
<G-vec00084-002-s194><build.bauen><en> Use individual customer scores to build personalized automation workflows.
<G-vec00084-002-s195><build.bauen><de> - Harte Beschichtung, vermeiden Sie die Lichtverschmutzung und bauen Sie eine gute ökologische Umgebung.
<G-vec00084-002-s195><build.bauen><en> - Hard coating, avoid the light pollution and build good ecological environment.
<G-vec00084-002-s196><build.bauen><de> Bauen Sie die Webseite und alle Dokumente.
<G-vec00084-002-s196><build.bauen><en> Build the web site and all documents.
<G-vec00084-002-s197><build.bauen><de> Bauen Sie die richtigen Geschäftsbeziehungen auf, die die Grundlage für ExxonMobils fortwährende Führungsrolle innerhalb der Branche schaffen.
<G-vec00084-002-s197><build.bauen><en> Build the essential relationships that set the foundation for ExxonMobil’s continued industry leadership.
<G-vec00084-002-s198><build.bauen><de> Bauen Sie Auftrag-kritische Anwendungen auf und nutzen Sie offene Rahmen, Anwendungen der offenen Quelle und verschiedene Entwicklungssprachen.
<G-vec00084-002-s198><build.bauen><en> Build mission-critical applications and take advantage of open frameworks, open source applications, and various development languages.
<G-vec00084-002-s199><build.bauen><de> Bauen Sie ein zuverlässiges Netzwerk für geschäftskritische Unternehmensanwendungen.
<G-vec00084-002-s199><build.bauen><en> Build a rock-solid network for mission-critical business applications.
<G-vec00084-002-s200><build.bauen><de> Bauen Sie mit uns – so verbinden Sie ein Vergnügen mit gutem Geschäft.
<G-vec00084-002-s200><build.bauen><en> Build with us – it’s pleasure combined with good business
<G-vec00084-002-s201><build.bauen><de> Bauen Sie großartige Benutzererfahrung auf.
<G-vec00084-002-s201><build.bauen><en> Build great user experience
<G-vec00084-002-s202><build.bauen><de> Werden Sie unser Partner und bauen Sie sich Ihre perfekte Produktionsstätte nach Ihren Geschäftsvorstellungen.
<G-vec00084-002-s202><build.bauen><en> Partner with us to build the perfect production facility to meet your business needs.
<G-vec00084-002-s203><build.bauen><de> Bauen Sie sich heute Ihre Zukunft auf.
<G-vec00084-002-s203><build.bauen><en> Build your tomorrow, today.
<G-vec00084-002-s204><build.bauen><de> Bauen Sie über 60 Basiseinrichtungen und gewaltige Geheimprojekte, um Ihren Machtbereich auszuweiten.
<G-vec00084-002-s204><build.bauen><en> Build over 60 base upgrades and large scale secret projects for your empire.
<G-vec00084-002-s205><build.bauen><de> Errichten Sie die Stadt aus der Siedlung, bauen Sie Häuser und ihre Ausstattung, dekorieren Sie Straßen.
<G-vec00084-002-s205><build.bauen><en> Description Build your city township - build houses, decorations, decorate the streets.
<G-vec00084-002-s206><build.bauen><de> Verlieren Sie an Gewicht, bauen Sie schlanke Muskeln auf und steigern Sie mit diesem 20-Minuten-Programm Ihre Kraft.
<G-vec00084-002-s206><build.bauen><en> Lose weight, build lean muscle and increase energy with this 20-minute workout.
<G-vec00084-002-s207><build.bauen><de> Bauen Sie für Ihren IoT-Erfolg auf das technologische Fundament von über 100 Jahren Erfahrung in der Entwicklung operativer Technologien und mehr als 50 Jahren von IT-Innovationen und -Lösungen.
<G-vec00084-002-s207><build.bauen><en> Build your IoT success on our foundation of 100+ years developing operational technologies and 50+ years creating IT innovation and solutions. Improve Efficiency
<G-vec00084-002-s208><build.bauen><de> Bauen Sie auf Ihren Geschmack im Spiel.
<G-vec00084-002-s208><build.bauen><en> Build on your taste in the game.
<G-vec00084-002-s209><build.bauen><de> Legt ein Unternehmens-Wiki an, baut eine Wissensdatenbank für die Mitarbeiter auf und bringt neue Kollegen schnell und effektiv auf Stand.
<G-vec00084-002-s209><build.bauen><en> Structure a company wiki, build a self-service knowledge base, and onboard new hires simply and effectively.
<G-vec00084-002-s210><build.bauen><de> Wer jetzt kein Haus hat, baut sich keines mehr.
<G-vec00084-002-s210><build.bauen><en> Whoever has no house will never build one now.
<G-vec00084-002-s211><build.bauen><de> Tatsächlich ist zu gewissen Zeiten der Herr selbst einer, der „entwurzelt“, „herunterreißt“, „zerstört“ und „übergibt“, bevor er „baut“ und „pflanzt“.
<G-vec00084-002-s211><build.bauen><en> In fact, at times the Lord himself is one who ”uproots”, ”tears down”, ”destroys” and ”overthrows” in order to ”build” and to ”plant”.
<G-vec00084-002-s212><build.bauen><de> Veränderungen in Ihrem Körper braucht Zeit, aber wenn Sie seit ein paar Monaten hart gearbeitet haben und immer noch keine Ergebnisse sehen, ist es ein Zeichen, dass Sie lernen müssen, wie man Muskeln schneller baut.
<G-vec00084-002-s212><build.bauen><en> Making changes in your body takes time but if you have been working hard for a few months and still do not see results, it's a sign that you need to learn how to build muscles faster.
<G-vec00084-002-s213><build.bauen><de> Verner Panton ist nicht auf vordergründige Effekte aus, er baut vielmehr auf die funktionale Überzeugungskraft einer Idee.
<G-vec00084-002-s213><build.bauen><en> Verner Panton is not about superficial effects, he is more inclined to build upon the functional persuasiveness of an idea.
<G-vec00084-002-s214><build.bauen><de> Nur wer gar nicht baut, verbraucht weder Energie noch Ressourcen.
<G-vec00084-002-s214><build.bauen><en> They argue that the only way to avoid using energy or resources is to not build at all.
<G-vec00084-002-s215><build.bauen><de> Das hilft dir, deine Form zu verbessern und baut die Kraft in den Schultern und Armen auf, die du zum Radschlagen brauchst.
<G-vec00084-002-s215><build.bauen><en> This will help improve your form, and build up the arm and shoulder strength needed for one-handed cartwheels.
<G-vec00084-002-s216><build.bauen><de> Baut den Heiligen Raum, Ihr Lieben, mit den Steinen eurer eigenen gefallenen Mauern, vermischt mit dem Mörtel der Liebe von Zuhause.
<G-vec00084-002-s216><build.bauen><en> Build the sacred room, dear ones, with the stones of your own walls mixed with the mortar of the love of Home.
<G-vec00084-002-s217><build.bauen><de> Es handelt sich dabei nicht um ein einzelnes Produkt, sondern der Begriff bezieht sich auf eine Kultur oder „Software-Entwicklungsdisziplin, wo man Software auf eine Weise baut, dass sie jederzeit für die Produktion freigegeben werden kann“, erklärt Martin Fowler.
<G-vec00084-002-s217><build.bauen><en> Far from being a single product, the term refers to a culture or “software development discipline, where you build software in such a way that [it] can be released to production at any time,” explains Martin Fowler.
<G-vec00084-002-s218><build.bauen><de> Man baut tiefgehende Verbindungen zu seinen Kommilitonen auf und dieser Zusammenhalt ist ein richtig, richtig starkes Asset der HHL.
<G-vec00084-002-s218><build.bauen><en> You build deep connections to your fellow students and this cohesion is a really, really strong asset of HHL.
<G-vec00084-002-s219><build.bauen><de> Dadurch baut sich ein Bremsdruck auf, der die Häckseltrommel stoppt.
<G-vec00084-002-s219><build.bauen><en> This causes a brake pressure to build up, which stops the cutterhead.
<G-vec00084-002-s220><build.bauen><de> Der Kurs baut auf dem auf, was du bereits gelernt hast und erweitert deine Kenntnisse.
<G-vec00084-002-s220><build.bauen><en> Your confidence in the water will grow and you’ll build on what you’ve already learned.
<G-vec00084-002-s221><build.bauen><de> Jeremia sandte zu dieser Zeit einen Brief an die Verbannten mit dem Rat sie sollten sich in Babylonien organisieren: “Baut Häuser und wohnt darin… Nehmt euch Frauen und zeugt Söhne und Töchter… Bemüht euch um das Wohl der Stadt, aus der ich euch weggeführt habe, und betet für sie zum Herrn… Denn so spricht der Herr: Wenn siebzig Jahre für Babel vorüber sind, dann werde ich euch an diesen Ort zurückführen” (Jeremia 29,4-10).
<G-vec00084-002-s221><build.bauen><en> Therefore, Jeremiah sent a letter to the exiled recommending to organize themselves in Babylon, to “build houses, settle down… marry and have sons and daughters… work for the good of the city to which I have exiled you; pray to Yahweh on its behalf. For Yahweh says this: “When the seventy years granted to Babylon are over… I will bring you back to this place” (Jeremiah 29,4-10).
<G-vec00084-002-s222><build.bauen><de> Castle Wars 2 ist die Fortsetzung von Castle Wars 1 und ein sehr fesselndes Kartenspiel, in dem es Dein Ziel ist, die feindliche Burg zu vernichten oder der Erste zu sein, der eine Burg mit 100 Stockwerken baut.
<G-vec00084-002-s222><build.bauen><en> Castle Wars 2 is the sequel to Castle wars, and is a very addictive card game where your goal is to crush your enemy's castle or be the first to build a 100 storey castle.
<G-vec00084-002-s223><build.bauen><de> Weil du so viel Blut vor mir vergossen hast, sollst du es nicht sein, der ein Haus zu Ehren meines Namens baut.
<G-vec00084-002-s223><build.bauen><en> You have fought many wars. You are not the one who will build a house for my Name.
<G-vec00084-002-s224><build.bauen><de> Der konsekutiv angelegte Masterstudiengang Germanistik baut auf den im Bachelorstudium erworbenen wissenschaftlichen Fähigkeiten auf und ist dezidiert forschungsbezogen gestaltet.
<G-vec00084-002-s224><build.bauen><en> The Master's degree in German Studies is designed to follow and build on the academic skills acquired during the Bachelor's degree and is substantially research-based.
<G-vec00084-002-s225><build.bauen><de> Wenn man ein großes Kirchengebäude baut, kann es weggenommen werden, das ist auch in Zentralasien passiert.
<G-vec00084-002-s225><build.bauen><en> If you build a big church, it can be taken away, as has happened in Central Asia.
<G-vec00084-002-s226><build.bauen><de> VK baut ein Netzwerk von Agenten in den baltischen Staaten und in Polen auf.
<G-vec00084-002-s226><build.bauen><en> VK started to build an agent network in the Baltic countries and Poland.
<G-vec00084-002-s418><build.bauen><de> Erhöhen Sie die Anzahl der Clanmitglieder und öffnen Sie neue Zonen, in denen zusätzliche Strukturen gebaut werden können.
<G-vec00084-002-s418><build.bauen><en> Increase the number of clan members and open new Zones, which allow you to build additional structures.
<G-vec00084-002-s419><build.bauen><de> Dieses Objektiv ist etwas kompakter gebaut.
<G-vec00084-002-s419><build.bauen><en> This lens is build more compact as its neighbor.
<G-vec00084-002-s420><build.bauen><de> Dadurch ist es für Sie einfacher zu kontrollieren und zu navigieren, da es kleiner und leichter gebaut ist.
<G-vec00084-002-s420><build.bauen><en> Thus making it easier for you to control and navigate, as it is smaller and with a lighter build.
<G-vec00084-002-s421><build.bauen><de> Die Kliniken, mit denen wir kooperieren sind ein leuchtendes Beispiel dafür, wie ein Team von Experten gebaut wird, die sich von anderen Unternehmen auf dem Markt auszeichnen.
<G-vec00084-002-s421><build.bauen><en> The clinics that we cooperate with are a bright example of how to build a team of experts who excel beyond other companies on the market.
<G-vec00084-002-s422><build.bauen><de> Außerdem hat die GIZ in Zusammenarbeit mit UNICEF sieben Schulen gebaut und ausgestattet.
<G-vec00084-002-s422><build.bauen><en> GIZ has also worked with UNICEF to build seven schools and provide equipment for them.
<G-vec00084-002-s423><build.bauen><de> Es ist ideal für diejenigen, die ein besonderes und einzigartiges Grundstück kaufen wollen, wo ein großes Haus gebaut werden kann, mit atemberaubender Aussicht und absolute Privatsphäre.
<G-vec00084-002-s423><build.bauen><en> It is ideal for those who want buy a special and unique plot where to build a large housing dimensions, with stunning views and total privacy.
<G-vec00084-002-s424><build.bauen><de> Gut gebaut, keine gesundheitlichen Probleme.
<G-vec00084-002-s424><build.bauen><en> Well build, no health issues.
<G-vec00084-002-s425><build.bauen><de> Top Haus gebaut auf 2 Etagen.
<G-vec00084-002-s425><build.bauen><en> Top House is build on 2 floors.
<G-vec00084-002-s426><build.bauen><de> Am Morgen besuchen Sie Lingyin Tempel, der im Jahr 326 am Fuß des Linyin Berges gebaut wurde.
<G-vec00084-002-s426><build.bauen><en> In the morning, visit Lingyin Buddhist Temple, one of the best known Buddhist monasteries in China, Which was build in 326 at the foot of Linyin Mountain.
<G-vec00084-002-s427><build.bauen><de> Seit meine Homepage im Netz ist habe ich viele Anfragen von Leuten bekommen, die noch nie selbst Lautsprecher gebaut haben.
<G-vec00084-002-s427><build.bauen><en> Since my homepage in online I've got many requests of people who have never build a loudspeaker system their own.
<G-vec00084-002-s428><build.bauen><de> Das gesamte Anwesen ist um einen angenehmen Innenhof herum gebaut.
<G-vec00084-002-s428><build.bauen><en> The whole property is build around a pleasant interior courtyard.
<G-vec00084-002-s429><build.bauen><de> Zu diesem Zeitpunkt sind die Tragflächen bis auf die Hauptbeplankung der Unterseite fertig, also müssen erstmal die Querruder und Klappen gebaut werden.
<G-vec00084-002-s429><build.bauen><en> Ailerons At this time the wings are finsihed except the bottom main skins, so it was time to build the elevators and flaps.
<G-vec00084-002-s431><build.bauen><de> Diese Mikrocontroller basierte Stromversorgung ist nicht die einfachste Schaltung, aber ich kann dir versichern, dass du es nicht bereuen wirst, diese Schaltung gebaut zu haben.
<G-vec00084-002-s431><build.bauen><en> This Microcontroller bases DC power supply is not the simplest circuit but I can assure you that you will not regret the time needed to build it.
<G-vec00084-002-s432><build.bauen><de> Er zeigte, wie ein automatischer Swell gebaut wird, wie man ein Proeset für die Akustische Gitarre anlegt, wie man nervende Frequenzen mit Hilfe des Equalizers eindämmt, und mehr.
<G-vec00084-002-s432><build.bauen><en> He showed how to create automatic swells, to build a preset for an acoustic guitar, to fight annoying frequencies by using peak EQ-ing and more.
<G-vec00084-002-s433><build.bauen><de> Um Mose anzuweisen, wie das Heiligtum gebaut werden sollte, zeigte ihm Gott ein schon existierendes Vorbild.
<G-vec00084-002-s433><build.bauen><en> To instruct Moses in how to build the sanctuary, God showed him a pattern already existing.
<G-vec00084-002-s434><build.bauen><de> Luftig und transparent - so wird heute gebaut.
<G-vec00084-002-s434><build.bauen><en> Venetian blind motor Airy and transparent – is how we build today.
<G-vec00084-002-s435><build.bauen><de> Mit dem richtigen Set-Up wussten wir, was wir zu tun hatten und dann haben wir ziemlich schnell den ersten Motor gebaut.
<G-vec00084-002-s435><build.bauen><en> With the right set-up we knew what to do and were quickly able to build up the first engine.
<G-vec00084-002-s436><build.bauen><de> Außerdem hatten einige Jungs der Gruppe einen Toilettensitz gebaut.
<G-vec00084-002-s436><build.bauen><en> There was also a new toilet seat beeing build by a few boys.
<G-vec00084-002-s133><build_up.bauen><de> Grundstück in Erlaubnis zum Bau einer großen Villa mit Pool und Garten, in der Nähe von allen Annehmlichkeiten in Lagoa.
<G-vec00084-002-s133><build_up.bauen><en> Plot with permission to build a large villa with pool and garden, located close to all amenities with good access, between Estômbar and Lagoa.
<G-vec00084-002-s134><build_up.bauen><de> Die derzeit gültigen Baunormen erlauben auf jedem Grundstück den Bau eines Landhauses mit bis zu 500 m² Wohnfläche.
<G-vec00084-002-s134><build_up.bauen><en> The currently applicable building codes allow on each property to build a country house with up to 500 m² of living space.
<G-vec00084-002-s135><build_up.bauen><de> Geschichte Das B&B besteht seit Sommer 2008, aber die Geschichte dieses Hauses ist schon viel älter – sie beginnt in den frühen 60er Jahren, als Peppino Aiello und Lucia Puccio sich zum Bau des Hauses entschieden haben.
<G-vec00084-002-s135><build_up.bauen><en> History The Bed and Breakfast business in the Casa di Peppino e Lucia was started in the summer of 2008, but the history of this house began in the early 60’s when Peppino Aiello and Lucia Puccio decided to build it.
<G-vec00084-002-s136><build_up.bauen><de> Mit unseren Grundstücksangeboten auf Mallorca können Sie das perfekte Grundstück für Ihren Bau finden.
<G-vec00084-002-s136><build_up.bauen><en> With our listings of land for sale in Mallorca you can find that perfect plot to start your build.
<G-vec00084-002-s137><build_up.bauen><de> Den Großteil der Rohstoffe (wie Holz und Co.), die wir zum Bau unserer liebevollen Floors benötigen, beziehen wir aus der Region.
<G-vec00084-002-s137><build_up.bauen><en> The majority of the raw materials (such as wood and Co.), which we need to build our loving Floors, we source from the region.
<G-vec00084-002-s138><build_up.bauen><de> Im Jahr 2001 beschloss Sultan Qaboos durch ein königliches Dekret den Bau eines Opernhauses in Omans Haupt...
<G-vec00084-002-s138><build_up.bauen><en> In 2001, Sultan Qaboos decided by royal decree to build an opera house in Oman's capital, Muscat.
<G-vec00084-002-s139><build_up.bauen><de> Als sie nach Beendigung des Goldrausches nach Arbeit suchten, stellten die Farmer sie zum Bau von Dämmen an.
<G-vec00084-002-s139><build_up.bauen><en> When the rush finished, they were desperate for work, so the farmers had them build dams.
<G-vec00084-002-s140><build_up.bauen><de> Wer sich diesen Bausatz kauft, der sollte sich bewußt sein, daß er hier pure Science Fiction erwirbt oder eine schöne Grabelkiste mit Einzelteilen zum Bau verschiedener besserer Mistel Modelle.
<G-vec00084-002-s140><build_up.bauen><en> Who ever buys this kit should know that he buys pure Science Fiction or a nice spare parts box with parts to build several better Mistel Models .
<G-vec00084-002-s141><build_up.bauen><de> Das Innere der Kirche besteht aus verschiedenen, aber gut harmonierenden Materialien: der Boden ist aus Calitea mit weißen Marmor und einem grauen Kreuz aus Gramata Marmor – der gleiche Stein, der für den Bau der Kanzel benutzt wurde; die Fensterscheiben sind aus Onyx, die Balustraden und der Altar aus Marmor, die Tische gigantische Gramata Marmor Steinblöcke und die Stiftshütten sind aus Camiro Stein.
<G-vec00084-002-s141><build_up.bauen><en> The inside of the church is made of different but harmonious materials: the floor is of Kalithea white marble with a grey cross of Gramata marble – the same kind of stone was used to build the pulpit; the window panes are in onyx, the balustrades and the altars in marble, the tables are monolithic blocks of Gramata stone and the tabernacles are in Kamiros stone.
<G-vec00084-002-s142><build_up.bauen><de> Der Bau des XOno lohnt sich meiner Meinung nach auf jeden Fall und ist sicherlich ein Gewinn in fast jeder Audio Kette.
<G-vec00084-002-s142><build_up.bauen><en> To build the XOno is in my opinion a plus for most audio systems.
<G-vec00084-002-s143><build_up.bauen><de> Im Museum der Stadtgeschichte können Sie auch die Verwendung der Grabsteine zum Bau der Stadtmauer sehen.
<G-vec00084-002-s143><build_up.bauen><en> At the museum of the city's history you can see that the grave stones were used to build the city walls.
<G-vec00084-002-s144><build_up.bauen><de> Die geschätzte Projektwirtschaftlichkeit für den Bau und Betrieb einer Goldmine mit 750 Tagestonnen Kapazität bei New Polaris mittels Bio-Oxidation gefolgt von einem Laugungsverfahren zur Herstellung von 80.000 Unzen Gold pro Jahr in Form von Doré-Barren vor Ort durch Canarc ist vernünftigerweise erreichbar.
<G-vec00084-002-s144><build_up.bauen><en> The estimated project economics for Canarc to build and operate a 750 tonne per day gold mine at New Polaris using bio-oxidation followed by a leaching process to produce 80,000 ounces of gold per year in doré bars at site are reasonably achievable for this project.
<G-vec00084-002-s145><build_up.bauen><de> Die KfW ist zudem an einem Fonds beteiligt, der den Bau energieeffizienter Häuser für Menschen mit mittleren und niedrigen Einkommen finanziert.
<G-vec00084-002-s145><build_up.bauen><en> KfW is also contributing to a fund that provides finance to help people on moderate or low incomes to build energy-efficient houses.
<G-vec00084-002-s146><build_up.bauen><de> Schwerpunkt bleibt der Ausbau der erneuerbaren Energien und der Bau von hocheffizienten fossil befeuerten Kraftwerken.
<G-vec00084-002-s146><build_up.bauen><en> The focus remains to increase renewable capacity and to build highly efficient fossil-fuel-fired power stations.
<G-vec00084-002-s147><build_up.bauen><de> Die Vergabe dieses großen Vertrags über den Bau des Schutzbaus und der Hauptstruktur wird voraussichtlich gegen Ende des Jahres 2014 abgeschlossen sein.
<G-vec00084-002-s147><build_up.bauen><en> This big contract to build the dome and main structure is expected to be awarded towards the end of 2014.
<G-vec00084-002-s148><build_up.bauen><de> Es gibt mehr Möglichkeiten für Bau, Eroberung und Inspiration als je zuvor.
<G-vec00084-002-s148><build_up.bauen><en> There are more ways than ever before to build, conquer, and inspire.
<G-vec00084-002-s149><build_up.bauen><de> Bau dir dein eigenes RePricing für ebay.
<G-vec00084-002-s149><build_up.bauen><en> Build yourself your own RePricing for eBay.
<G-vec00084-002-s150><build_up.bauen><de> „Ich bin ein Nachkomme von Sir Sobha Singh, einem engen Mitarbeiter von Sir Edwin Lutyens bei Planung und Bau der Stadt Neu Delhi.
<G-vec00084-002-s150><build_up.bauen><en> Call "I am the descendant of Sir Sobha Singh who worked closely with Sir Edwin Lutyens to construct and build the city of New Delhi.
<G-vec00084-002-s151><build_up.bauen><de> 8 So zerstreute der Herr die Menschen über die ganze Erde; den Bau der Stadt mussten sie abbrechen.
<G-vec00084-002-s151><build_up.bauen><en> So the LORD scattered them abroad from thence upon the face of all the earth: and they left off to build the city.
<G-vec00084-002-s152><build_up.bauen><de> Baue ein Kartenhaus mit dem höchstmöglichen Wert.
<G-vec00084-002-s152><build_up.bauen><en> Build a house from cards with the highest value.
<G-vec00084-002-s153><build_up.bauen><de> Baue eine Farm.
<G-vec00084-002-s153><build_up.bauen><en> Build a Farm.
<G-vec00084-002-s154><build_up.bauen><de> Baue 100 Raketen-Türme.
<G-vec00084-002-s154><build_up.bauen><en> Build 100 Missile towers.
<G-vec00084-002-s155><build_up.bauen><de> Mit Live und Push hat sich das komplett geändert eigentlich, weil ich fang entweder mit einer Melodie oder einem Drum-Loop an, den ich mir zusammenbaue und baue dann darauf auf und das Lied entsteht so währenddessen.
<G-vec00084-002-s155><build_up.bauen><en> With Live and Push this has completely changed actually, because I either start with a melody or a drum loop that I construct myself and then build on it and the song is created along the way.
<G-vec00084-002-s156><build_up.bauen><de> 3 Wer irgend unter euch aus seinem Volke ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem, das in Juda ist, und baue das Haus Jahwes, des Gottes Israels (er ist Gott), in Jerusalem.
<G-vec00084-002-s156><build_up.bauen><en> Ezra 1:3 - Who is there among you of all his people? his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of the LORD God of Israel, (he is the God,) which is in Jerusalem.
<G-vec00084-002-s157><build_up.bauen><de> Baue Schulter- und Nackenmuskulatur auf, indem du seitliche Hantelübungen für mehr Kraft ausführst.
<G-vec00084-002-s157><build_up.bauen><en> Build shoulder muscles by lifting dumbbells out from your sides for resistance.
<G-vec00084-002-s158><build_up.bauen><de> Baue Holzlager, um für stetigen Nachschub an Rohmaterial zu sorgen und verbessere sie, um deine Produktion zu steigern.
<G-vec00084-002-s158><build_up.bauen><en> Build Lumber Yards to secure a steady supply of raw materials and Upgrade them to increase production.
<G-vec00084-002-s159><build_up.bauen><de> Baue deinen Biokostladen, ein gemütliches Kino, einen altmodischen Imbiss, ein entspannendes Kurbad, eine klassische Pension, ein verträumtes Strandcafé und mehr.
<G-vec00084-002-s159><build_up.bauen><en> Build your organic grocery store, cozy movie theater, vintage diner, relaxing spa, classic Bed & Breakfast, dreamy beach cafe and more.
<G-vec00084-002-s160><build_up.bauen><de> Gegründet 1947 von Edwin J. Montalvo Sr. gilt bei der Montalvo Corporation nach wie vor ihr Grundprinzip, auf dem es aufgebaut wurde: baue ein Produkt bereits beim ersten Mal richtig und unterstütze es mit einem erstklassigen Service und Support.
<G-vec00084-002-s160><build_up.bauen><en> Founded in 1947 by Edwin J. Montalvo Sr. the Montalvo Corporation continues the core principle it was built on: build a product right the first time and back it up with the highest quality service and support.
<G-vec00084-002-s161><build_up.bauen><de> Traumteam zusammenstellen - Verpflichte die besten Fußballstars aller Zeiten und baue in FIFA Ultimate Team eine Mannschaft auf, die dir jede Menge Ruhm einbringt.
<G-vec00084-002-s161><build_up.bauen><en> Build your dream team - Choose from among the best football stars of all time and build a team to take home the glory in FIFA Ultimate Team.
<G-vec00084-002-s162><build_up.bauen><de> Baue, verbaue und verkaufe Häuser.
<G-vec00084-002-s162><build_up.bauen><en> Build, buy and sell houses.
<G-vec00084-002-s163><build_up.bauen><de> Erlebe die dunkle Welt der dunklen Seelen, baue deinen Charakter Schritt nach Schritt auf, entdecke erschreckende Orte und sammle und meistere eine umfangreiche Sammlung von Waffen, Ausrüstung und Zaubersprüchen, um ein wirklich einzigartiges Spielerlebnis zu erschaffen.
<G-vec00084-002-s163><build_up.bauen><en> Let yourself be engulfed by the rich world of the Dark Souls. Gradually build your character, discover scary locations, and collect and master an extensive range of weapons, equipment and magic spells to create a truly unique gaming experience.
<G-vec00084-002-s164><build_up.bauen><de> 3Wer nun unter euch von seinem Volk ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem in Juda und baue das Haus des HERRN, des Gottes Israels; das ist der Gott, der zu Jerusalem ist.
<G-vec00084-002-s164><build_up.bauen><en> His God is with him, and he doth go up to Jerusalem, that [is] in Judah, and build the house of Jehovah, God of Israel -- He [is] God -- that [is] in Jerusalem.
<G-vec00084-002-s165><build_up.bauen><de> Baue dein Anliegen mit logischen Argumenten und Fakten auf und setze dann einen emotionalen Bestandteil ein.
<G-vec00084-002-s165><build_up.bauen><en> Build your case with logical reasoning and fact while adding in an emotional element.
<G-vec00084-002-s166><build_up.bauen><de> Baue deine Fremdsprachkenntnisse und dein Selbstvertrauen durch interaktiven Online-Unterricht auf.
<G-vec00084-002-s166><build_up.bauen><en> Build fluency and confidence through interactive Danish classes that are effective and fun.
<G-vec00084-002-s167><build_up.bauen><de> Baue dein eigenes Monster Vehikel, mit Deinen bevorzugten Waffen.
<G-vec00084-002-s167><build_up.bauen><en> Build your own monster vehicle with weapons to take part in crazy racing tracks.
<G-vec00084-002-s168><build_up.bauen><de> Baue eine Gruppe aus berühmten Kriegern und epischen Monstern aus...
<G-vec00084-002-s168><build_up.bauen><en> Build a party of famous warriors and epic monsters from Dragon...
<G-vec00084-002-s169><build_up.bauen><de> Wenn ich für einen Zoo ein Elefantenhaus baue, muss ich mich mit Elefanten beschäftigen.
<G-vec00084-002-s169><build_up.bauen><en> If I build an elephant house for a zoo, I have to deal with elephants.
<G-vec00084-002-s170><build_up.bauen><de> Ich baue zwei neue Motorräder auf.
<G-vec00084-002-s170><build_up.bauen><en> I build two new bikes.
<G-vec00084-002-s171><build_up.bauen><de> 3:2 Und er fing an zu bauen im zweiten Monat, am zweiten [Tag] im vierten Jahr seiner Regierung.
<G-vec00084-002-s171><build_up.bauen><en> 3:2 He began to build in the second [day] of the second month, in the fourth year of his reign.
<G-vec00084-002-s172><build_up.bauen><de> Bauen Sie ein schönes Paar Pandora Ohrring mit diesen 14K Gold und Onyx Tropfen Reize.
<G-vec00084-002-s172><build_up.bauen><en> Build a beautiful pair of Pandora earring with these 14K gold and Onyx Drop charms.
<G-vec00084-002-s173><build_up.bauen><de> In einem der wenigen Orte auf der Welt, wo man am Morgen surfen und am Nachmittag Skifahren kann, hat sich Nick vorgenommen, ein Fahrzeug zu bauen, das mit den klimatischen Extremen seines "Stadtabendteuers" umgehen konnte.
<G-vec00084-002-s173><build_up.bauen><en> In one of the few places in the world where you can surf in the morning and ski in the afternoon, Nick set out to build a vehicle that could deal with the climatic extremes of his “Urban Adventures”.
<G-vec00084-002-s174><build_up.bauen><de> 10Siehe, ich bestelle dich an diesem Tage über die Nationen und über die Königreiche, um auszurotten und niederzureißen und zu zerstören und abzubrechen, um zu bauen und um zu pflanzen.
<G-vec00084-002-s174><build_up.bauen><en> 10See, today I appoint you over nations and kingdoms to uproot and tear down, to destroy and overthrow, to build and to plant.’
<G-vec00084-002-s175><build_up.bauen><de> Bemusterungszentrum Hartenfels „Die Entscheidung ein Haus zu bauen ist elementar und langfristig.
<G-vec00084-002-s175><build_up.bauen><en> "The decision to build a house is elementary and a long-term decision.
<G-vec00084-002-s176><build_up.bauen><de> Wir sind zuversichtlich, dass wir ein System erschaffen können, welches sich fest an unsere Bedingungen anpasst und dabei einfach zu entwerfen, bauen und einzusetzen ist.
<G-vec00084-002-s176><build_up.bauen><en> We are confident that we can create a system that is tightly scoped to our needs that will not be complex to design, build and deploy.
<G-vec00084-002-s177><build_up.bauen><de> Bauen Sie ganz einfach Ihre eigene maßgeschneiderte App auf, um den speziellen – und sich verändernden – Anforderungen Ihres Unternehmens gerecht zu werden.
<G-vec00084-002-s177><build_up.bauen><en> Easily build your own custom app to meet the unique – and changing – needs of your business.
<G-vec00084-002-s178><build_up.bauen><de> 3 Du weißt, daß David, mein Vater, nicht vermochte, ein Haus zu bauen dem Namen Jehova's, seines Gottes, wegen des Krieges, womit sie ihn umgaben, bis sie Jehova unter seine Fußsohlen legte.
<G-vec00084-002-s178><build_up.bauen><en> 3 You know how that David my father could not build an house to the name of the LORD his God for the wars which were about him on every side, until the LORD put them under the soles of his feet.
<G-vec00084-002-s179><build_up.bauen><de> Seitdem ist es sein Anspruch, das bestmögliche Werkzeug überhaupt zu bauen.
<G-vec00084-002-s179><build_up.bauen><en> Since then it has been his claim to build the best possible tools ever.
<G-vec00084-002-s180><build_up.bauen><de> Mira Die öffentlich bekannt gegebene Tatsache, dass einige Geschäftsmänner große Hotelkomplexe auf verschiedenen naturgeschützten Geländen zu bauen beabsichtigen, wobei sie gültige Gesetze missachten, provozierte die zivile Öffentlichkeit, womit diese ursprünglich ökologisch motivierten Proteste zu einem zivilen, viele Studenten und Jugendliche anziehenden Widerstand wurden.
<G-vec00084-002-s180><build_up.bauen><en> The announced fact that some businessmen are planing to build big hotel complexes on different nature protected areas abusing all existing laws provokes civic attention and in fact this ecological in its beginning protests grown into civil ones, attracting a lot of students and young people.
<G-vec00084-002-s181><build_up.bauen><de> Hier genießt man Ruhe, hat eine gute Anbindung, eine schöne Umgebung und Platz, um eine große Villa mit Pool und Terrassen zu bauen.
<G-vec00084-002-s181><build_up.bauen><en> This lovely plot is tranquill, has good connections, beautiful surroundings and ample space to build a large villa with pool and terraces.
<G-vec00084-002-s182><build_up.bauen><de> Mit Drupal 8 können Sie so gut wie jeden integrierten Web-Auftritt bauen, den Sie sich vorstellen können.
<G-vec00084-002-s182><build_up.bauen><en> With Drupal 8, you can build almost any integrated experience you can imagine.
<G-vec00084-002-s183><build_up.bauen><de> Wir bauen auf die Erfahrung, Motivation und Qualifikation unserer Mitarbeitenden, um selbst die anspruchsvollsten Kundenanforderungen kompetent und mit persönlichem Einsatz zu erfüllen.
<G-vec00084-002-s183><build_up.bauen><en> We build on the experience, motivation and qualifications of our employees to fulfill the most sophisticated customer requirements with excellence and dedication.
<G-vec00084-002-s184><build_up.bauen><de> Bauen Sie mit LemonChili viele Seiten und Getränkekarte, wie Sie wollen.
<G-vec00084-002-s184><build_up.bauen><en> Build with LemonChili many pages and beverage menu, as you want.
<G-vec00084-002-s185><build_up.bauen><de> «Immer mehr Istanbuler erwerben außerdem Land in der Um- gebung, um Villen und Ferienhäuser zu bauen – dieses Land geht der Landwirt- schaft verloren.
<G-vec00084-002-s185><build_up.bauen><en> “More and more Is- tanbulites are buying land in the area to build villas and holiday homes, thus taking land away from agriculture.
<G-vec00084-002-s186><build_up.bauen><de> Helfen Sie Jane die heikelste Kunden glücklich zu machen: Wählen Sie raffinierte Möbel, einen Golfplatz zu bauen und bitte Sie Ihre Kunden mit exquisiten Drinks und gutes Essen.
<G-vec00084-002-s186><build_up.bauen><en> Help Jane to make the pickiest customers happy: choose refined furniture, build a golf course and please your customers with exquisite drinks and good meals.
<G-vec00084-002-s187><build_up.bauen><de> Unser Ziel ist es, leichtgewichtige, effiziente Geländeräder zu bauen, die das Gleichgewichthalten, die Koordination und das Selbstvertrauen von Kindern fördern.
<G-vec00084-002-s187><build_up.bauen><en> Our mission is to build lightweight, efficient, all-terrain bikes that build two-wheeled balance, coordination, and confidence in children.
<G-vec00084-002-s188><build_up.bauen><de> Unser Ziel ist es, Immobilien und deren Umfeld zu bauen und zu betreiben, so dass mit einem Minimum an Ressourcen (Ökologie, Ökonomie, Personalaufwand) ein Maximum an Nutzerzufriedenheit, Produktivität und Effizienz erreicht werden kann.
<G-vec00084-002-s188><build_up.bauen><en> It is our aim to build and operate properties with their setting, with the result to achieve a maximum of user satisfaction, productivity and efficiency by using a minimum of resources (ecology, economy, personal expenditure).
<G-vec00084-002-s189><build_up.bauen><de> Wir planen, konstruieren, bauen und installieren manuelle und automatische Anlagen für die Nahtabdichtungen, Kosmetiksealer, Unterbodenschutzauftrag, Schweller-Beschichtungssysteme sowie für spritzbare Schalldämmmassen.
<G-vec00084-002-s189><build_up.bauen><en> Print Bodyshop We engineer, design, build and install manual as well as automatic systems for hemflange adhesive application as well as for cosmetic sealing, untiflutter and sounddeadener.
<G-vec00084-002-s190><build_up.bauen><de> Schützen Sie die Geräte, auf die Kunden angewiesen sind, und bauen Sie das Vertrauen in Ihre Marke auf.
<G-vec00084-002-s190><build_up.bauen><en> Protect the devices customers depend on and build trust in your brand.
<G-vec00084-002-s191><build_up.bauen><de> Multiplayer: Bauen Sie zum ersten Mal mit Freunden eine ganze Region auf.
<G-vec00084-002-s191><build_up.bauen><en> Multiplayer— Build a region with friends for the first time!
<G-vec00084-002-s192><build_up.bauen><de> Bauen Sie engere Kundenbeziehungen und ein personalisiertes digitales Erlebnis mit KI auf, während die Kosten sinken und der Return-on-Investment steigt.
<G-vec00084-002-s192><build_up.bauen><en> Build deeper customer relationships and personalized digital experiences with AI, while lowering operating costs and boosting return on investment.
<G-vec00084-002-s193><build_up.bauen><de> Bauen Sie mit einer Schritt-für-Schritt-Methode auf Ihrer bestehenden IT-Infrastruktur auf und nutzen Sie dabei Technologien, die eigens in Hinblick auf eine Optimierung Ihrer künftigen Infrastruktur entwickelt wurden.
<G-vec00084-002-s193><build_up.bauen><en> Build upon your existing IT infrastructure with a step-by-step approach featuring technologies engineered to optimize your future infrastructure. Learn more Events
<G-vec00084-002-s194><build_up.bauen><de> Bauen Sie mithilfe des Punktestands einzelner Kunden personalisierte Automatisierungsworkflows.
<G-vec00084-002-s194><build_up.bauen><en> Use individual customer scores to build personalized automation workflows.
<G-vec00084-002-s195><build_up.bauen><de> - Harte Beschichtung, vermeiden Sie die Lichtverschmutzung und bauen Sie eine gute ökologische Umgebung.
<G-vec00084-002-s195><build_up.bauen><en> - Hard coating, avoid the light pollution and build good ecological environment.
<G-vec00084-002-s196><build_up.bauen><de> Bauen Sie die Webseite und alle Dokumente.
<G-vec00084-002-s196><build_up.bauen><en> Build the web site and all documents.
<G-vec00084-002-s197><build_up.bauen><de> Bauen Sie die richtigen Geschäftsbeziehungen auf, die die Grundlage für ExxonMobils fortwährende Führungsrolle innerhalb der Branche schaffen.
<G-vec00084-002-s197><build_up.bauen><en> Build the essential relationships that set the foundation for ExxonMobil’s continued industry leadership.
<G-vec00084-002-s198><build_up.bauen><de> Bauen Sie Auftrag-kritische Anwendungen auf und nutzen Sie offene Rahmen, Anwendungen der offenen Quelle und verschiedene Entwicklungssprachen.
<G-vec00084-002-s198><build_up.bauen><en> Build mission-critical applications and take advantage of open frameworks, open source applications, and various development languages.
<G-vec00084-002-s199><build_up.bauen><de> Bauen Sie ein zuverlässiges Netzwerk für geschäftskritische Unternehmensanwendungen.
<G-vec00084-002-s199><build_up.bauen><en> Build a rock-solid network for mission-critical business applications.
<G-vec00084-002-s200><build_up.bauen><de> Bauen Sie mit uns – so verbinden Sie ein Vergnügen mit gutem Geschäft.
<G-vec00084-002-s200><build_up.bauen><en> Build with us – it’s pleasure combined with good business
<G-vec00084-002-s201><build_up.bauen><de> Bauen Sie großartige Benutzererfahrung auf.
<G-vec00084-002-s201><build_up.bauen><en> Build great user experience
<G-vec00084-002-s202><build_up.bauen><de> Werden Sie unser Partner und bauen Sie sich Ihre perfekte Produktionsstätte nach Ihren Geschäftsvorstellungen.
<G-vec00084-002-s202><build_up.bauen><en> Partner with us to build the perfect production facility to meet your business needs.
<G-vec00084-002-s203><build_up.bauen><de> Bauen Sie sich heute Ihre Zukunft auf.
<G-vec00084-002-s203><build_up.bauen><en> Build your tomorrow, today.
<G-vec00084-002-s204><build_up.bauen><de> Bauen Sie über 60 Basiseinrichtungen und gewaltige Geheimprojekte, um Ihren Machtbereich auszuweiten.
<G-vec00084-002-s204><build_up.bauen><en> Build over 60 base upgrades and large scale secret projects for your empire.
<G-vec00084-002-s205><build_up.bauen><de> Errichten Sie die Stadt aus der Siedlung, bauen Sie Häuser und ihre Ausstattung, dekorieren Sie Straßen.
<G-vec00084-002-s205><build_up.bauen><en> Description Build your city township - build houses, decorations, decorate the streets.
<G-vec00084-002-s206><build_up.bauen><de> Verlieren Sie an Gewicht, bauen Sie schlanke Muskeln auf und steigern Sie mit diesem 20-Minuten-Programm Ihre Kraft.
<G-vec00084-002-s206><build_up.bauen><en> Lose weight, build lean muscle and increase energy with this 20-minute workout.
<G-vec00084-002-s207><build_up.bauen><de> Bauen Sie für Ihren IoT-Erfolg auf das technologische Fundament von über 100 Jahren Erfahrung in der Entwicklung operativer Technologien und mehr als 50 Jahren von IT-Innovationen und -Lösungen.
<G-vec00084-002-s207><build_up.bauen><en> Build your IoT success on our foundation of 100+ years developing operational technologies and 50+ years creating IT innovation and solutions. Improve Efficiency
<G-vec00084-002-s208><build_up.bauen><de> Bauen Sie auf Ihren Geschmack im Spiel.
<G-vec00084-002-s208><build_up.bauen><en> Build on your taste in the game.
<G-vec00084-002-s209><build_up.bauen><de> Legt ein Unternehmens-Wiki an, baut eine Wissensdatenbank für die Mitarbeiter auf und bringt neue Kollegen schnell und effektiv auf Stand.
<G-vec00084-002-s209><build_up.bauen><en> Structure a company wiki, build a self-service knowledge base, and onboard new hires simply and effectively.
<G-vec00084-002-s210><build_up.bauen><de> Wer jetzt kein Haus hat, baut sich keines mehr.
<G-vec00084-002-s210><build_up.bauen><en> Whoever has no house will never build one now.
<G-vec00084-002-s211><build_up.bauen><de> Tatsächlich ist zu gewissen Zeiten der Herr selbst einer, der „entwurzelt“, „herunterreißt“, „zerstört“ und „übergibt“, bevor er „baut“ und „pflanzt“.
<G-vec00084-002-s211><build_up.bauen><en> In fact, at times the Lord himself is one who ”uproots”, ”tears down”, ”destroys” and ”overthrows” in order to ”build” and to ”plant”.
<G-vec00084-002-s212><build_up.bauen><de> Veränderungen in Ihrem Körper braucht Zeit, aber wenn Sie seit ein paar Monaten hart gearbeitet haben und immer noch keine Ergebnisse sehen, ist es ein Zeichen, dass Sie lernen müssen, wie man Muskeln schneller baut.
<G-vec00084-002-s212><build_up.bauen><en> Making changes in your body takes time but if you have been working hard for a few months and still do not see results, it's a sign that you need to learn how to build muscles faster.
<G-vec00084-002-s213><build_up.bauen><de> Verner Panton ist nicht auf vordergründige Effekte aus, er baut vielmehr auf die funktionale Überzeugungskraft einer Idee.
<G-vec00084-002-s213><build_up.bauen><en> Verner Panton is not about superficial effects, he is more inclined to build upon the functional persuasiveness of an idea.
<G-vec00084-002-s214><build_up.bauen><de> Nur wer gar nicht baut, verbraucht weder Energie noch Ressourcen.
<G-vec00084-002-s214><build_up.bauen><en> They argue that the only way to avoid using energy or resources is to not build at all.
<G-vec00084-002-s215><build_up.bauen><de> Das hilft dir, deine Form zu verbessern und baut die Kraft in den Schultern und Armen auf, die du zum Radschlagen brauchst.
<G-vec00084-002-s215><build_up.bauen><en> This will help improve your form, and build up the arm and shoulder strength needed for one-handed cartwheels.
<G-vec00084-002-s216><build_up.bauen><de> Baut den Heiligen Raum, Ihr Lieben, mit den Steinen eurer eigenen gefallenen Mauern, vermischt mit dem Mörtel der Liebe von Zuhause.
<G-vec00084-002-s216><build_up.bauen><en> Build the sacred room, dear ones, with the stones of your own walls mixed with the mortar of the love of Home.
<G-vec00084-002-s217><build_up.bauen><de> Es handelt sich dabei nicht um ein einzelnes Produkt, sondern der Begriff bezieht sich auf eine Kultur oder „Software-Entwicklungsdisziplin, wo man Software auf eine Weise baut, dass sie jederzeit für die Produktion freigegeben werden kann“, erklärt Martin Fowler.
<G-vec00084-002-s217><build_up.bauen><en> Far from being a single product, the term refers to a culture or “software development discipline, where you build software in such a way that [it] can be released to production at any time,” explains Martin Fowler.
<G-vec00084-002-s218><build_up.bauen><de> Man baut tiefgehende Verbindungen zu seinen Kommilitonen auf und dieser Zusammenhalt ist ein richtig, richtig starkes Asset der HHL.
<G-vec00084-002-s218><build_up.bauen><en> You build deep connections to your fellow students and this cohesion is a really, really strong asset of HHL.
<G-vec00084-002-s219><build_up.bauen><de> Dadurch baut sich ein Bremsdruck auf, der die Häckseltrommel stoppt.
<G-vec00084-002-s219><build_up.bauen><en> This causes a brake pressure to build up, which stops the cutterhead.
<G-vec00084-002-s220><build_up.bauen><de> Der Kurs baut auf dem auf, was du bereits gelernt hast und erweitert deine Kenntnisse.
<G-vec00084-002-s220><build_up.bauen><en> Your confidence in the water will grow and you’ll build on what you’ve already learned.
<G-vec00084-002-s221><build_up.bauen><de> Jeremia sandte zu dieser Zeit einen Brief an die Verbannten mit dem Rat sie sollten sich in Babylonien organisieren: “Baut Häuser und wohnt darin… Nehmt euch Frauen und zeugt Söhne und Töchter… Bemüht euch um das Wohl der Stadt, aus der ich euch weggeführt habe, und betet für sie zum Herrn… Denn so spricht der Herr: Wenn siebzig Jahre für Babel vorüber sind, dann werde ich euch an diesen Ort zurückführen” (Jeremia 29,4-10).
<G-vec00084-002-s221><build_up.bauen><en> Therefore, Jeremiah sent a letter to the exiled recommending to organize themselves in Babylon, to “build houses, settle down… marry and have sons and daughters… work for the good of the city to which I have exiled you; pray to Yahweh on its behalf. For Yahweh says this: “When the seventy years granted to Babylon are over… I will bring you back to this place” (Jeremiah 29,4-10).
<G-vec00084-002-s222><build_up.bauen><de> Castle Wars 2 ist die Fortsetzung von Castle Wars 1 und ein sehr fesselndes Kartenspiel, in dem es Dein Ziel ist, die feindliche Burg zu vernichten oder der Erste zu sein, der eine Burg mit 100 Stockwerken baut.
<G-vec00084-002-s222><build_up.bauen><en> Castle Wars 2 is the sequel to Castle wars, and is a very addictive card game where your goal is to crush your enemy's castle or be the first to build a 100 storey castle.
<G-vec00084-002-s223><build_up.bauen><de> Weil du so viel Blut vor mir vergossen hast, sollst du es nicht sein, der ein Haus zu Ehren meines Namens baut.
<G-vec00084-002-s223><build_up.bauen><en> You have fought many wars. You are not the one who will build a house for my Name.
<G-vec00084-002-s224><build_up.bauen><de> Der konsekutiv angelegte Masterstudiengang Germanistik baut auf den im Bachelorstudium erworbenen wissenschaftlichen Fähigkeiten auf und ist dezidiert forschungsbezogen gestaltet.
<G-vec00084-002-s224><build_up.bauen><en> The Master's degree in German Studies is designed to follow and build on the academic skills acquired during the Bachelor's degree and is substantially research-based.
<G-vec00084-002-s225><build_up.bauen><de> Wenn man ein großes Kirchengebäude baut, kann es weggenommen werden, das ist auch in Zentralasien passiert.
<G-vec00084-002-s225><build_up.bauen><en> If you build a big church, it can be taken away, as has happened in Central Asia.
<G-vec00084-002-s226><build_up.bauen><de> VK baut ein Netzwerk von Agenten in den baltischen Staaten und in Polen auf.
<G-vec00084-002-s226><build_up.bauen><en> VK started to build an agent network in the Baltic countries and Poland.
<G-vec00084-002-s227><build_up.bauen><de> Bitte baut eine Brücke zwischen den Menschen und zwischen Ländern.
<G-vec00084-002-s227><build_up.bauen><en> Please build a bridge between people, among people and between countries.
<G-vec00084-002-s418><build_up.bauen><de> Erhöhen Sie die Anzahl der Clanmitglieder und öffnen Sie neue Zonen, in denen zusätzliche Strukturen gebaut werden können.
<G-vec00084-002-s418><build_up.bauen><en> Increase the number of clan members and open new Zones, which allow you to build additional structures.
<G-vec00084-002-s419><build_up.bauen><de> Dieses Objektiv ist etwas kompakter gebaut.
<G-vec00084-002-s419><build_up.bauen><en> This lens is build more compact as its neighbor.
<G-vec00084-002-s420><build_up.bauen><de> Dadurch ist es für Sie einfacher zu kontrollieren und zu navigieren, da es kleiner und leichter gebaut ist.
<G-vec00084-002-s420><build_up.bauen><en> Thus making it easier for you to control and navigate, as it is smaller and with a lighter build.
<G-vec00084-002-s421><build_up.bauen><de> Die Kliniken, mit denen wir kooperieren sind ein leuchtendes Beispiel dafür, wie ein Team von Experten gebaut wird, die sich von anderen Unternehmen auf dem Markt auszeichnen.
<G-vec00084-002-s421><build_up.bauen><en> The clinics that we cooperate with are a bright example of how to build a team of experts who excel beyond other companies on the market.
<G-vec00084-002-s422><build_up.bauen><de> Außerdem hat die GIZ in Zusammenarbeit mit UNICEF sieben Schulen gebaut und ausgestattet.
<G-vec00084-002-s422><build_up.bauen><en> GIZ has also worked with UNICEF to build seven schools and provide equipment for them.
<G-vec00084-002-s423><build_up.bauen><de> Es ist ideal für diejenigen, die ein besonderes und einzigartiges Grundstück kaufen wollen, wo ein großes Haus gebaut werden kann, mit atemberaubender Aussicht und absolute Privatsphäre.
<G-vec00084-002-s423><build_up.bauen><en> It is ideal for those who want buy a special and unique plot where to build a large housing dimensions, with stunning views and total privacy.
<G-vec00084-002-s424><build_up.bauen><de> Gut gebaut, keine gesundheitlichen Probleme.
<G-vec00084-002-s424><build_up.bauen><en> Well build, no health issues.
<G-vec00084-002-s425><build_up.bauen><de> Top Haus gebaut auf 2 Etagen.
<G-vec00084-002-s425><build_up.bauen><en> Top House is build on 2 floors.
<G-vec00084-002-s426><build_up.bauen><de> Am Morgen besuchen Sie Lingyin Tempel, der im Jahr 326 am Fuß des Linyin Berges gebaut wurde.
<G-vec00084-002-s426><build_up.bauen><en> In the morning, visit Lingyin Buddhist Temple, one of the best known Buddhist monasteries in China, Which was build in 326 at the foot of Linyin Mountain.
<G-vec00084-002-s427><build_up.bauen><de> Seit meine Homepage im Netz ist habe ich viele Anfragen von Leuten bekommen, die noch nie selbst Lautsprecher gebaut haben.
<G-vec00084-002-s427><build_up.bauen><en> Since my homepage in online I've got many requests of people who have never build a loudspeaker system their own.
<G-vec00084-002-s428><build_up.bauen><de> Das gesamte Anwesen ist um einen angenehmen Innenhof herum gebaut.
<G-vec00084-002-s428><build_up.bauen><en> The whole property is build around a pleasant interior courtyard.
<G-vec00084-002-s429><build_up.bauen><de> Zu diesem Zeitpunkt sind die Tragflächen bis auf die Hauptbeplankung der Unterseite fertig, also müssen erstmal die Querruder und Klappen gebaut werden.
<G-vec00084-002-s429><build_up.bauen><en> Ailerons At this time the wings are finsihed except the bottom main skins, so it was time to build the elevators and flaps.
<G-vec00084-002-s430><build_up.bauen><de> Der Gesamtkomplex Zeche Zollverein in Essen wurde Ende der 20er Jahre gebaut und im Jahre 1986 stillgelegt.
<G-vec00084-002-s430><build_up.bauen><en> The coal pit Zeche Zollverein in Essen was build at the end of the 1920s and was closed down in the year 1986.
<G-vec00084-002-s431><build_up.bauen><de> Diese Mikrocontroller basierte Stromversorgung ist nicht die einfachste Schaltung, aber ich kann dir versichern, dass du es nicht bereuen wirst, diese Schaltung gebaut zu haben.
<G-vec00084-002-s431><build_up.bauen><en> This Microcontroller bases DC power supply is not the simplest circuit but I can assure you that you will not regret the time needed to build it.
<G-vec00084-002-s432><build_up.bauen><de> Er zeigte, wie ein automatischer Swell gebaut wird, wie man ein Proeset für die Akustische Gitarre anlegt, wie man nervende Frequenzen mit Hilfe des Equalizers eindämmt, und mehr.
<G-vec00084-002-s432><build_up.bauen><en> He showed how to create automatic swells, to build a preset for an acoustic guitar, to fight annoying frequencies by using peak EQ-ing and more.
<G-vec00084-002-s433><build_up.bauen><de> Um Mose anzuweisen, wie das Heiligtum gebaut werden sollte, zeigte ihm Gott ein schon existierendes Vorbild.
<G-vec00084-002-s433><build_up.bauen><en> To instruct Moses in how to build the sanctuary, God showed him a pattern already existing.
<G-vec00084-002-s434><build_up.bauen><de> Luftig und transparent - so wird heute gebaut.
<G-vec00084-002-s434><build_up.bauen><en> Venetian blind motor Airy and transparent – is how we build today.
<G-vec00084-002-s435><build_up.bauen><de> Mit dem richtigen Set-Up wussten wir, was wir zu tun hatten und dann haben wir ziemlich schnell den ersten Motor gebaut.
<G-vec00084-002-s435><build_up.bauen><en> With the right set-up we knew what to do and were quickly able to build up the first engine.
<G-vec00084-002-s436><build_up.bauen><de> Außerdem hatten einige Jungs der Gruppe einen Toilettensitz gebaut.
<G-vec00084-002-s436><build_up.bauen><en> There was also a new toilet seat beeing build by a few boys.
<G-vec00084-002-s098><construct.bauen><de> 40/al-Mu'min-36: Und der Pharao sagte: «O Haman Baue mir einen hohen Turm.
<G-vec00084-002-s098><construct.bauen><en> And Pharaoh said, "O Haman, construct for me a tower that I might reach the ways -
<G-vec00084-002-s099><construct.bauen><de> Baue Sesselbahnen, Gondellifte, Sprungschanzen und Rampen, um deine Passagiere sicher durch über 100 lebensgefährliche Level zu bringen – ob sie dabei den Tod riskieren, liegt ganz in deiner Hand.
<G-vec00084-002-s099><construct.bauen><en> OVER 100 CHALLENGING LEVELS Construct various facilities and infrastructures such as chairlifts, gondolas, jumps, bridges and ramps to guide the riders across over 100 hazardous levels.
<G-vec00084-002-s100><construct.bauen><de> Baue auf der Grundlage dieser Fragen und Antworten mehrere Gesprächsverläufe.
<G-vec00084-002-s100><construct.bauen><en> Construct various conversation sequences based on these questions and answers.
<G-vec00084-002-s102><construct.bauen><de> Baue eine Brücke aus verschiedenen Materialien, teste sie mit Autos und Trucks und schalte die nächste herausfordernde Spielwelt frei.
<G-vec00084-002-s102><construct.bauen><en> Construct a bridge with different materials, put it to the test using cars and trucks, and unlock the next brain-teasing level!
<G-vec00084-002-s103><construct.bauen><de> Baue Schubladen mit einer Hartfaserplatte als Boden und Kiefernleisten (2,5 cm X 5 cm) als Seitenteile.
<G-vec00084-002-s103><construct.bauen><en> Construct drawers with a hardboard base and pine sides (1x2in or 2.5 by 5 cm).
<G-vec00084-002-s104><construct.bauen><de> [19] Tipps Wenn du im Freien anbaust, dann baue einen kleinen Hühnerzaun um deine Plantage herum, um Hasen und Rehe abzuhalten.
<G-vec00084-002-s104><construct.bauen><en> If you are planting away from home, construct a little fence of chicken wire around your growing area to deter rabbits and deer.
<G-vec00084-002-s105><construct.bauen><de> Baue Fischerhütten, Bauernhöfe und Bäckereien und etabliere einen funktionierenden Wirtschaftskreislauf.
<G-vec00084-002-s105><construct.bauen><en> Construct buildings, like fisher huts, farms, forges or bakeries to sustain a solid economic cycle.
<G-vec00084-002-s106><construct.bauen><de> Baue Hochbeete in deinem Treibhaus.
<G-vec00084-002-s106><construct.bauen><en> Construct raised beds inside your greenhouse.
<G-vec00084-002-s107><construct.bauen><de> Ich kann die Quest "Baue ein Schlachtschiff" nicht einlösen, obwohl ich ein Schlachtschiff habe.
<G-vec00084-002-s107><construct.bauen><en> I can't complete the quest "Construct a Battleship” even though I have a Battleship.
<G-vec00084-002-s108><construct.bauen><de> Und wenn wir für Sie beispielsweise eine Eisbar bauen, vergessen wir natürlich nicht, Ihr Firmenlogo auf die Front zu modellieren.
<G-vec00084-002-s108><construct.bauen><en> And when we construct a ice bar for example, we do not forget to embed your company logo in the front.
<G-vec00084-002-s109><construct.bauen><de> Möglich zu bauen ein Haus auf 3 Etagen; ca 300 qm.
<G-vec00084-002-s109><construct.bauen><en> Possible for construct a house on 3 floors; cca 300 sq m.
<G-vec00084-002-s110><construct.bauen><de> Er ließ die Internatskinder Sterne aus verschiedenen geometrischen Formen bauen und diese schmückten später damit Ihre Internatsstuben.
<G-vec00084-002-s110><construct.bauen><en> He let the children at the boarding school construct stars of various geometrical shapes and these stars later adorned the schoolrooms.
<G-vec00084-002-s111><construct.bauen><de> Wir planen, bauen und sanieren Pumpendruck-, Transport- und Versorgungsleitungen.
<G-vec00084-002-s111><construct.bauen><en> We design, construct and renovate pump pressure, transportation and supply lines.
<G-vec00084-002-s112><construct.bauen><de> Die Herausforderung: selbst einen Rennwagen entwickeln und bauen.
<G-vec00084-002-s112><construct.bauen><en> The challenge: to develop and construct your own race car.
<G-vec00084-002-s113><construct.bauen><de> Um Muskelmasse zu gewinnen und Ihren Körper zu bauen, müssen Sie Ihre körperliche Stärke und Kraft verbessern.
<G-vec00084-002-s113><construct.bauen><en> In order to acquire lean muscle mass and construct your body, you have to enhance your physical strength and power.
<G-vec00084-002-s114><construct.bauen><de> (5) Ein Vertragsstaat darf keine neue Einrichtung zur Herstellung chemischer Waffen bauen und keine vorhandene Einrichtung für den Zweck der Herstellung chemischer Waffen oder für eine andere nach diesem Übereinkommen verbotene Tätigkeit verändern.
<G-vec00084-002-s114><construct.bauen><en> 5. No State Party shall construct any new chemical weapons production facilities or modify any existing facilities for the purpose of chemical weapons production or for any other activity prohibited under this Convention.
<G-vec00084-002-s115><construct.bauen><de> Wir kennen solche Anlagen gut – denn wir bauen sie.
<G-vec00084-002-s115><construct.bauen><en> We know these installations well – we construct them.
<G-vec00084-002-s116><construct.bauen><de> Bananen sind zusätzlich hervorragende, wenn Sie versuchen, Fett zu verlieren und bauen Muskelmasse.
<G-vec00084-002-s116><construct.bauen><en> Bananas are also wonderful when you are trying to melt fat and construct muscle.
<G-vec00084-002-s117><construct.bauen><de> Aber Violinen bauen, das macht nur er.
<G-vec00084-002-s117><construct.bauen><en> But to construct violins, in that he is alone.
<G-vec00084-002-s118><construct.bauen><de> Dies deutet darauf hin, dass Sie nicht genügend Energie beliefern für den menschlichen Körper, Fett zu verbrennen und Muskeln in geeigneter Weise über die Ausbildung bauen.
<G-vec00084-002-s118><construct.bauen><en> This means that you do not provide adequate energy for the human body to burn fat and also construct muscular tissue correctly with the workout.
<G-vec00084-002-s119><construct.bauen><de> Wir verteilen Hygieneartikel, bauen Latrinen und Brunnen und kümmern uns um die Trinkwasseraufbereitung.
<G-vec00084-002-s119><construct.bauen><en> We distribute hygiene supplies, construct latrines and wells, and treat the water to make it drinkable.
<G-vec00084-002-s120><construct.bauen><de> Heute planen und bauen wir auch komplette Anlagen für unsere Kunden und überzeugen dabei immer wieder durch unsere Flexibilität und Termingenauigkeit.
<G-vec00084-002-s120><construct.bauen><en> Today we also plan and construct complete plants for our customers, invariably with convincing flexibility and punctual delivery.
<G-vec00084-002-s121><construct.bauen><de> Um herauszufinden, welches das richtige ist, bauen Schüler*innen einen Simulator, der mithilfe des Calliope mini und externer Sensoren die Bedürfnisse eines Haustiers nachahmt.
<G-vec00084-002-s121><construct.bauen><en> To find out which one is the best, the students will construct a simulator that is controlled by the Calliope mini and uses external sensors to imitate the needs of a pet.
<G-vec00084-002-s122><construct.bauen><de> Berichten zufolge plant Saudi-Arabien, in den nächsten 20-25 Jahren zwei große Kernkraftwerke mit geschätzten Kosten von 80 Milliarden US-Dollar zu bauen.
<G-vec00084-002-s122><construct.bauen><en> The kingdom says it wants to construct 16 nuclear power reactors over the next 20 to 25 years at a cost of more than $80 billion.
<G-vec00084-002-s123><construct.bauen><de> D-Bal MAX produziert die höchste anabole Einstellung für Ihren Körper schnell Muskelmasse und Ausdauer zu bauen und Ihre Leistung zu verbessern.
<G-vec00084-002-s123><construct.bauen><en> D-Bal MAX develops the supreme anabolic setting for your body to promptly construct muscular tissue as well as toughness and also to improve your efficiency.
<G-vec00084-002-s124><construct.bauen><de> Sawai Jai Singh hatte die Wahl, entweder auf der Sternwarte mit Instrumenten aus Metall oder Mauerwerk Instrumente zu bauen.
<G-vec00084-002-s124><construct.bauen><en> Sawai Jai Singh had the choice either to construct the observatory with metal instruments or masonry instruments.
<G-vec00084-002-s125><construct.bauen><de> Man sollte in Ausstellungen mehr versuchen, radikalere Beziehungsgeflechte zu bauen und vorzuschlagen.
<G-vec00084-002-s125><construct.bauen><en> In exhibitions one should try to construct and suggest more radical interrelationships.
<G-vec00084-002-s126><construct.bauen><de> 1629 ließ er in Huseby ein Eisenwerk bauen, welches der Startpunkt für eine 301-jährige Eisenproduktion wurde.
<G-vec00084-002-s126><construct.bauen><en> In 1629, he let construct an ironworks at Huseby, which became the starting point for 301 years of iron production.
<G-vec00084-002-s127><construct.bauen><de> Baut alle folgenden Waffen mit Raketenchef Doppeldecker.
<G-vec00084-002-s127><construct.bauen><en> Construct each of the following weapons with Careers About
<G-vec00084-002-s128><construct.bauen><de> Sein Spiel mit Fakten und Fiktionen, sein oft mehr verstecktes als offenes Referenzieren auf künstlerische Vorbilder, sozialpolitische Ereignisse oder autobiographische Tatsachen baut ein dichtes Beziehungsgeflecht von Verweisen auf, verknüpft es mit subjektiven Erfahrungen und Fragestellungen, um es in den unterschiedlichsten Medien – Malerei, Fotografie, Skulptur oder Video – auf seine allgemeine Gültigkeit oder Relevanz zu überprüfen.
<G-vec00084-002-s128><construct.bauen><en> His play with facts and fiction, references to artistic forebears, often more concealed than open, social-political events, or autobiographical facts construct a thick web, linking it to subjective experiences and questions to then examine it using the most various media—painting, photography, sculpture, or video—in terms of its general validity or relevance.
<G-vec00084-002-s129><construct.bauen><de> Die KA Holzbau AG im schweizerischen Grindelwald fertigt etwa 6 -10 Wohnhäuser im Jahr, baut außerdem je nach Auftragslage Scheunen und Dachstühle.
<G-vec00084-002-s129><construct.bauen><en> KA Holzbau AG in Grindelwald, Switzerland build around 6–10 houses each year, and also construct barns and roof trusses depending on the order volume.
<G-vec00084-002-s130><construct.bauen><de> Im Tausch gegen Materialien und Geld baut sie dir neue Gebäude auf deiner Farm.
<G-vec00084-002-s130><construct.bauen><en> In exchange for raw materials and money, she'll construct new buidlings on your farm.
<G-vec00084-002-s132><construct.bauen><de> Um seine Unterstützung sicherzustellen, baut NTT Communications weiterhin sein Backbone mit Seekabeln mit hoher Kapazität und geringer Latenz aus.
<G-vec00084-002-s132><construct.bauen><en> To ensure its support, NTT Communications is continuing to construct backbone high-capacity, low latency submarine cables, providing quality network and data center services at the forefront of major markets, and support its customers worldwide.
<G-vec00084-002-s272><construct.bauen><de> Um gegen die im Naturschutzgebiet „Arctic National Wildlife Refuge“ vorgesehenen Erdölbohrungen zu protestieren, haben wir mit unserer Eissorte „Fossil Fuel“ ein 900 Pfund schweres Omelett Surprise (auf englisch „Baked Alaska“) gebaut, es auf dem Rasen der Hauptstadt abgeladen und mit der Unterstützung von Greenpeace und der Alaska Wilderness League serviert.
<G-vec00084-002-s272><construct.bauen><en> To protest proposed oil drilling in the Arctic National Wildlife Refuge, we construct a 900-pound Baked Alaska with our Fossil Fuel ice cream, shoulder it onto the US Capital lawn and serve it up with the help of Greenpeace and the Alaska Wilderness League.
<G-vec00084-002-s273><construct.bauen><de> Eine E-Tankstelle ist einfach gebaut; zumindest für dich, denn Beratung, Standortanalyse, Stromzufuhr, Hardware und die organisatorische Abwicklung übernehmen wir von Greenstorm.
<G-vec00084-002-s273><construct.bauen><en> An electric charging station is simple to construct, at least it would be for you, because we at Greenstorm would take care of the consulting, site analysis, power supply and organisation.
<G-vec00084-002-s274><construct.bauen><de> Es ist das größte Fahrwerk, das die Firma jemals entwickelt und gebaut hat.
<G-vec00084-002-s274><construct.bauen><en> This is the largest landing gear that the company has ever had to develop and construct.
<G-vec00084-002-s275><construct.bauen><de> Es gibt nicht mehr viele Grundstücke von ausreichender Grösse mit Meerblick, auf denen große Häuser gebaut werden können.
<G-vec00084-002-s275><construct.bauen><en> Few such stunning plots remain of sufficient size to construct an imposing country house with sea views.
<G-vec00084-002-s276><construct.bauen><de> Doch schon bald wirst du Stunden warten müssen, bis ein Gebäude gebaut oder geupgradet ist.
<G-vec00084-002-s276><construct.bauen><en> But soon, you will have to wait for hours to construct or upgrade even a single building.
<G-vec00084-002-s277><construct.bauen><de> Die Vorteile des Flugzeugs liegen vor allem in seiner aerodynamischen Form: Dadurch, dass nahezu das gesamte Flugzeug auch Flügel ist, verbessert sich der Auftrieb - die Triebwerke müssen weniger leisten, das Flugzeug kann leichter gebaut werden.
<G-vec00084-002-s277><construct.bauen><en> The advantages of this aircraft lie primarily in its aerodynamic design. Since almost the entire aircraft is an aerofoil, lift is improved, the engines have less work to do and it is easier to construct.
<G-vec00084-002-s278><construct.bauen><de> Es musste schnell ein neuer Ofen mit einer geeigneten Wärmequelle gebaut werden.
<G-vec00084-002-s278><construct.bauen><en> It was necessary to quickly construct a new oven with a suitable heat source.
