<G-vec00307-002-s093><encounter.auftreffen><de> Die NIH sponsern die meisten Dokumente auf diesem Server; aber es kann sein, dass Sie auf Dokumente treffen, die zusammen mit privaten Unternehmen und anderen Organisationen gefördert wurden.
<G-vec00307-002-s093><encounter.auftreffen><en> The NIH sponsors most documents on this server; however, you may encounter documents sponsored along with private companies and other organizations.
<G-vec00307-002-s094><encounter.auftreffen><de> Es ist unwahrscheinlich, dass Eltern einmal auf einen schlechten Appetit treffen.
<G-vec00307-002-s094><encounter.auftreffen><en> Parents are unlikely to once encounter a bad appetite.
<G-vec00307-002-s095><encounter.auftreffen><de> Zudem sind die meisten Normen, auf die wir im Bereich der Schutzbrillen treffen, solche für militärische Schutzbrillen.
<G-vec00307-002-s095><encounter.auftreffen><en> In addition, most of the standards that we encounter in the field of safety spectacles are those for military safety spectacles.
<G-vec00307-002-s096><encounter.auftreffen><de> Während die Spieler die äußersten Gebiete des Weltraums erkunden und auf verschiedene, machthungrige Fraktionen treffen, entscheiden sie mit dem von ihnen entwickelten Charakter über den Verlauf der spielergetriebenen Handlung.
<G-vec00307-002-s096><encounter.auftreffen><en> “As you explore the furthest reaches of space and encounter various factions, all vying for power, the character you decide to become will determine how this player-driven story unfolds.
<G-vec00307-002-s097><encounter.auftreffen><de> Wenn Sie auf jene treffen, welche die richtige geistige Kraft besitzen, so können diese Sie zu einem gewissen Maß belehren.
<G-vec00307-002-s097><encounter.auftreffen><en> If you encounter those with the right mental powers, they can teach you to some extent.
<G-vec00307-002-s098><encounter.auftreffen><de> Im folgenden Abschnitt erfahren Sie, auf welche Cookies von Drittanbietern Sie durch diese Website treffen können.
<G-vec00307-002-s098><encounter.auftreffen><en> The following section details which third party cookies you might encounter through this site.
<G-vec00307-002-s099><encounter.auftreffen><de> Wenn sie auf den Widerstand der Konzerne und des kapitalistischen Staates treffen, werden die Werktätigen die Notwendigkeit einer revolutionären Umgestaltung der Gesellschaft immer klarer erkennen.
<G-vec00307-002-s099><encounter.auftreffen><en> As they encounter the resistance of corporations and the capitalist state to their legitimate demands, working people will see ever more clearly the need for the revolutionary transformation of society.
<G-vec00307-002-s100><encounter.auftreffen><de> Fünen wird auch „Garten von Dänemark“ genannt – wenn Sie einen Ausflug in die Umgebung unternehmen, werden Sie auf einige der zahlreichen Bauernhofläden und Stände am Straßenrand treffen.
<G-vec00307-002-s100><encounter.auftreffen><en> Funen is also called the garden of Denmark, and if you explore the surrounding area, you will inevitably encounter some of the island’s many farm shops and roadside stalls.
<G-vec00307-002-s101><encounter.auftreffen><de> Das Spiel ist extrem süchtig machend und während Sie im Spiel fortschreiten, werden Sie auf Herausforderungen treffen, die Ihre Fähigkeiten in vollen Zügen testen.
<G-vec00307-002-s101><encounter.auftreffen><en> The game is highly addictive and as you progress you will encounter challenges that will test your abilities to the fullest.
<G-vec00307-002-s102><encounter.auftreffen><de> Während die Truppen auf heftigen Widerstand von IS-Kämpfern treffen, fliehen Tausende von Zivilisten aus der umkämpften Stadt.
<G-vec00307-002-s102><encounter.auftreffen><en> As government troops encounter stiff resistance from IS fighters, thousands of civilians are fleeing the fighting.
<G-vec00307-002-s103><encounter.auftreffen><de> Bestimmte T-Lymphozyten merken sich eine solche spezifische Abwehrreaktion und lösen, wenn sie zu einem späteren Zeitpunkt wieder auf denselben Fremdstoff treffen, eine schnelle und sehr wirkungsvolle Immunreaktion aus.
<G-vec00307-002-s103><encounter.auftreffen><en> Certain T lymphocytes remember such a specific immune response and when they encounter the same foreign substance at a later time, they trigger a rapid and effective immune response.
<G-vec00307-002-s104><encounter.auftreffen><de> Damit sollen möglichst viele Bodenbedingungen untersucht werden, auf die das Marsgefährt Exomars auf dem Mars treffen könnte.
<G-vec00307-002-s104><encounter.auftreffen><en> With this, the rover will tested with as many different types of soil conditions as it could possibly encounter on Mars.
<G-vec00307-002-s105><encounter.auftreffen><de> Dieser trägt den Titel Dragon Ball Super: Broly und handelt von Goku und Vegeta, die auf Broly treffen, eine Saiyajin-Kriegerin, wie sie sie noch nie gesehen hat.
<G-vec00307-002-s105><encounter.auftreffen><en> . PLAY In HD Plot: Goku and Vegeta encounter Broly, a Saiyan warrior unlike any fighter they've faced before.
<G-vec00307-002-s106><encounter.auftreffen><de> Forscher beschuldigen die Vertrautheit: Wenn Menschen auf etwas Unerwartetes treffen, wie fremde Farben oder Gewichte, wird unser Gehirn zu einer unangenehmen Erfahrung.
<G-vec00307-002-s106><encounter.auftreffen><en> Researchers blame the familiarity: when people encounter something unexpected, such as strange colors or weights, our brains turn it into an unpleasant experience.
<G-vec00307-002-s107><encounter.auftreffen><de> Sehr wahrscheinlich ist allerdings, dass Sie – wie auf der Brücke eines Schiffes – zwischen Monitoren und Telefonen auf die Entscheider treffen.
<G-vec00307-002-s107><encounter.auftreffen><en> However, it is very likely that you will—just like on the bridge of a ship—encounter the decision-makers between monitors and phones.
<G-vec00307-002-s108><encounter.auftreffen><de> Du wirst auf wundervolle Kirchen sehr antiken Ursprungs treffen.
<G-vec00307-002-s108><encounter.auftreffen><en> You will encounter beautiful churches with ancient origins.
<G-vec00307-002-s109><encounter.auftreffen><de> Ja, Sie können auf viele Situationen treffen, in denen Sie Ihre Daten verlieren.
<G-vec00307-002-s109><encounter.auftreffen><en> Yes, you can encounter many situations where you lose your data.
<G-vec00307-002-s110><encounter.auftreffen><de> Ihre Exporte würden an Wettbewerbsfähigkeit verlieren, und sie würden auf ihren Heimatmärkten auf starke Konkurrenz aus der Rumpf-Euro-Zone treffen.
<G-vec00307-002-s110><encounter.auftreffen><en> Their exports would become less competitive and they would encounter heavy competition from the rump euro zone area in their home markets.
<G-vec00307-002-s111><encounter.auftreffen><de> Es gilt also die grundsätzliche Regel, dass du in limped Pots nicht auf Floats treffen wirst.
<G-vec00307-002-s111><encounter.auftreffen><en> As a general rule, you don’t encounter floats in limped pots.
<G-vec00307-002-s038><meet.auftreffen><de> Wir können überall in Estland auf ihn treffen.
<G-vec00307-002-s038><meet.auftreffen><en> We can meet it all over Estonia.
<G-vec00307-002-s039><meet.auftreffen><de> Saint-Tropez: der legendäre Ort an der Côte d'Azur, wo Meer, die Tradition der Provence und Kunst auf Luxus, Unterhaltung und Exzesse der High Society treffen.
<G-vec00307-002-s039><meet.auftreffen><en> Saint-Tropez: a legendary place on the Cote d'Azur where sea, Provençal tradition and art meet the luxury, fun and excesses of high society. Destinations in French Riviera
<G-vec00307-002-s041><meet.auftreffen><de> Kontaktieren Sie uns gerne, falls Sie auf einer Messe ausstellen und uns treffen möchten.
<G-vec00307-002-s041><meet.auftreffen><en> Please contact us if you attend an event and like to meet us.
<G-vec00307-002-s042><meet.auftreffen><de> Die Seehäfen sind die sogenannten Verkehrsknotenpunkte, an denen die Landverkehrsträger auf die Schiffe treffen.
<G-vec00307-002-s042><meet.auftreffen><en> The seaports are the so-called transport hubs where the land transport carriers meet the ships.
<G-vec00307-002-s043><meet.auftreffen><de> Zum Beispiel können in Innenräumen die Stellen, wo die Winkel der Wände und der Decke auf den Bildrand treffen, für die Komposition sehr wichtig sein.
<G-vec00307-002-s043><meet.auftreffen><en> For example, in an interior, where the angles of the walls and ceiling meet the edges of the image can be very important for the composition.
<G-vec00307-002-s044><meet.auftreffen><de> Wenn Sie Port Grimaud besuchen, werden Sie nicht nur auf bemerkenswerte Gebäude voller interessanter Geschichten treffen.
<G-vec00307-002-s044><meet.auftreffen><en> When you visit Port Grimaud, you will not only meet remarkable buildings full of interesting stories.
<G-vec00307-002-s045><meet.auftreffen><de> Wo rohe, raue Materialien auf unverwechselbares, feines Design treffen.
<G-vec00307-002-s045><meet.auftreffen><en> Where raw, rough materials meet distinctive, delicate design.
<G-vec00307-002-s046><meet.auftreffen><de> Der Antares R3 Versus Evo verfügt über eine Carbon-verstärkte Nylon-Verbundschale - mit Wing Flex-Technologie, die Flexibilität bietet, wenn Ihre Oberschenkel auf den Sattel treffen - und ein leichtes, robustes, korrosionsbeständiges K: ium-Sattelgestell.
<G-vec00307-002-s046><meet.auftreffen><en> Antares R3 Versus Evo features a composite Carbon-reinforced nylon shell – with Wing Flex technology which enables flexibility where your thighs meet the saddle – and a light, strong, corrosion-resistant K:ium rail.
<G-vec00307-002-s047><meet.auftreffen><de> Die Suche nach ihm entwickelt sich zu einer turbulenten Odyssee, bei der Simpel und Ben auf die Medizinstudentin Aria (Emilia Schüle) und ihren Kumpel, den Sanitäter Enzo (Axel Stein) treffen.
<G-vec00307-002-s047><meet.auftreffen><en> The search for their father develops into a turbulent odyssey in which Simpel and Ben meet the medical student Aria (Emilia Schüle) and her mate, the paramedic Enzo (Axel Stein).
<G-vec00307-002-s048><meet.auftreffen><de> TAG 1: Nach dem Frühstück um 8.00 Uhr verlassen Sie Arusha und fahren zum Momella Gate, wo Sie auf den Führer und die Mannschaft treffen.
<G-vec00307-002-s048><meet.auftreffen><en> Eastern Ascend DAY 1: After breakfast leave Arusha at 8.00 a.m. and drive to the Momella Gate where you meet your guide and crew.
<G-vec00307-002-s049><meet.auftreffen><de> Herzlich willkommen im Hotel Palatina – wo starke regionale Wurzeln und Pfälzer Gastlichkeit auf modernen Komfort und weltoffenen Charme treffen und so für eine elegante Wohlfühlatmosphäre sorgen.
<G-vec00307-002-s049><meet.auftreffen><en> Welcome to the hotel Palatina – a place where strong regional roots and Palatinate hospitality meet modern comfort and cosmopolitan charm creating an elegant feel-good atmosphere.
<G-vec00307-002-s050><meet.auftreffen><de> Die Zuzügler erreichen Estland von Süden, wir können auf die Imagos aufgrund ihrer ziehenden Lebensweise an unerwarteten Stellen treffen und sie kommen üblicherweise im Mai oder Juni.
<G-vec00307-002-s050><meet.auftreffen><en> The migrants arrive in Estonia from the South, we can meet the imagos in unexpected places due to their migrant mode of life and they usually arrive in May or June.
<G-vec00307-002-s051><meet.auftreffen><de> Kinder zwischen acht und 18 Monaten haben häufig Angst, wenn sie auf unbekannte Menschen treffen oder unbekannte Orte besuchen.
<G-vec00307-002-s051><meet.auftreffen><en> Children who are 8 to 18 months old often become frightened when they meet new people or visit new places.
<G-vec00307-002-s052><meet.auftreffen><de> De Wallen liegt im mittelalterlichen Stadtzentrum und strahlt sanft mit dekadenter Beleuchtung und hohen Fensterfronten – ein Ort, an dem historische Geheimnisse auf den modernen Nervenkitzel treffen.
<G-vec00307-002-s052><meet.auftreffen><en> Located in the medieval city centre, De Wallen glows softly with decadent rouged lighting and risque window displays – a place where historical secrets meet modern thrills.
<G-vec00307-002-s053><meet.auftreffen><de> Im Achtelfinale würde er bei einem Sieg gegen Mektic auf den Russen Konstantin Kravchuk (2011 im Halbfinale) oder Jan Mertl aus Tschechien treffen.
<G-vec00307-002-s053><meet.auftreffen><en> In the event of a win against Mektic he would meet the Russian Konstantin Kravchuk (semifinals in 2011) or Jan Mertl from the Czech Republic in the second round.
<G-vec00307-002-s054><meet.auftreffen><de> Aus diesem Grund ist die international verständliche .hospital-Domainendung auch für Informationsseiten und Diskussionsforen geeignet, in denen Laien auf geschulte Fachleute treffen, Termine vereinbaren oder Krankenakte abrufen können.
<G-vec00307-002-s054><meet.auftreffen><en> Because of that, the internationally understandable .hospital domain translation is also suitable for information pages and discussion forums in which laymen can meet trained experts, schedule appointments, or call up health records.
<G-vec00307-002-s055><meet.auftreffen><de> Teil einer besonderen Kooperation, bei der beliebte Disney-Figuren auf legendäres Coach Design treffen: Dieses neu interpretierte Must-have ist aus Neopren gefertigt und bietet so eine strukturierte Optik und ein weiches, gepolstertes Tragegefühl.
<G-vec00307-002-s055><meet.auftreffen><en> full price €95 €47,50 optic white with bambi Part of a special collaboration where beloved Disney characters meet iconic Coach design, this soft cotton T-shirt features a shadowy graphic from a classic animated tale.
<G-vec00307-002-s056><meet.auftreffen><de> Die Hansestadt ist gleichzeitig Heimat vielfältiger Veranstaltungen, auf denen Gründer auf andere Startups, Investoren sowie potenzielle Partner oder Kunden treffen.
<G-vec00307-002-s056><meet.auftreffen><en> Hamburg is also home to a variety of events, where founders can meet and connect with other start-ups, investors and potential partners or clients.
<G-vec00307-003-s038><meet_up.auftreffen><de> Wir können überall in Estland auf ihn treffen.
<G-vec00307-003-s038><meet_up.auftreffen><en> We can meet it all over Estonia.
<G-vec00307-003-s039><meet_up.auftreffen><de> Saint-Tropez: der legendäre Ort an der Côte d'Azur, wo Meer, die Tradition der Provence und Kunst auf Luxus, Unterhaltung und Exzesse der High Society treffen.
<G-vec00307-003-s039><meet_up.auftreffen><en> Saint-Tropez: a legendary place on the Cote d'Azur where sea, Provençal tradition and art meet the luxury, fun and excesses of high society. Destinations in French Riviera
<G-vec00307-003-s041><meet_up.auftreffen><de> Kontaktieren Sie uns gerne, falls Sie auf einer Messe ausstellen und uns treffen möchten.
<G-vec00307-003-s041><meet_up.auftreffen><en> Please contact us if you attend an event and like to meet us.
<G-vec00307-003-s042><meet_up.auftreffen><de> Die Seehäfen sind die sogenannten Verkehrsknotenpunkte, an denen die Landverkehrsträger auf die Schiffe treffen.
<G-vec00307-003-s042><meet_up.auftreffen><en> The seaports are the so-called transport hubs where the land transport carriers meet the ships.
<G-vec00307-003-s043><meet_up.auftreffen><de> Zum Beispiel können in Innenräumen die Stellen, wo die Winkel der Wände und der Decke auf den Bildrand treffen, für die Komposition sehr wichtig sein.
<G-vec00307-003-s043><meet_up.auftreffen><en> For example, in an interior, where the angles of the walls and ceiling meet the edges of the image can be very important for the composition.
<G-vec00307-003-s044><meet_up.auftreffen><de> Wenn Sie Port Grimaud besuchen, werden Sie nicht nur auf bemerkenswerte Gebäude voller interessanter Geschichten treffen.
<G-vec00307-003-s044><meet_up.auftreffen><en> When you visit Port Grimaud, you will not only meet remarkable buildings full of interesting stories.
<G-vec00307-003-s045><meet_up.auftreffen><de> Wo rohe, raue Materialien auf unverwechselbares, feines Design treffen.
<G-vec00307-003-s045><meet_up.auftreffen><en> Where raw, rough materials meet distinctive, delicate design.
<G-vec00307-003-s046><meet_up.auftreffen><de> Der Antares R3 Versus Evo verfügt über eine Carbon-verstärkte Nylon-Verbundschale - mit Wing Flex-Technologie, die Flexibilität bietet, wenn Ihre Oberschenkel auf den Sattel treffen - und ein leichtes, robustes, korrosionsbeständiges K: ium-Sattelgestell.
<G-vec00307-003-s046><meet_up.auftreffen><en> Antares R3 Versus Evo features a composite Carbon-reinforced nylon shell – with Wing Flex technology which enables flexibility where your thighs meet the saddle – and a light, strong, corrosion-resistant K:ium rail.
<G-vec00307-003-s047><meet_up.auftreffen><de> Die Suche nach ihm entwickelt sich zu einer turbulenten Odyssee, bei der Simpel und Ben auf die Medizinstudentin Aria (Emilia Schüle) und ihren Kumpel, den Sanitäter Enzo (Axel Stein) treffen.
<G-vec00307-003-s047><meet_up.auftreffen><en> The search for their father develops into a turbulent odyssey in which Simpel and Ben meet the medical student Aria (Emilia Schüle) and her mate, the paramedic Enzo (Axel Stein).
<G-vec00307-003-s048><meet_up.auftreffen><de> TAG 1: Nach dem Frühstück um 8.00 Uhr verlassen Sie Arusha und fahren zum Momella Gate, wo Sie auf den Führer und die Mannschaft treffen.
<G-vec00307-003-s048><meet_up.auftreffen><en> Eastern Ascend DAY 1: After breakfast leave Arusha at 8.00 a.m. and drive to the Momella Gate where you meet your guide and crew.
<G-vec00307-003-s049><meet_up.auftreffen><de> Herzlich willkommen im Hotel Palatina – wo starke regionale Wurzeln und Pfälzer Gastlichkeit auf modernen Komfort und weltoffenen Charme treffen und so für eine elegante Wohlfühlatmosphäre sorgen.
<G-vec00307-003-s049><meet_up.auftreffen><en> Welcome to the hotel Palatina – a place where strong regional roots and Palatinate hospitality meet modern comfort and cosmopolitan charm creating an elegant feel-good atmosphere.
<G-vec00307-003-s050><meet_up.auftreffen><de> Die Zuzügler erreichen Estland von Süden, wir können auf die Imagos aufgrund ihrer ziehenden Lebensweise an unerwarteten Stellen treffen und sie kommen üblicherweise im Mai oder Juni.
<G-vec00307-003-s050><meet_up.auftreffen><en> The migrants arrive in Estonia from the South, we can meet the imagos in unexpected places due to their migrant mode of life and they usually arrive in May or June.
<G-vec00307-003-s051><meet_up.auftreffen><de> Kinder zwischen acht und 18 Monaten haben häufig Angst, wenn sie auf unbekannte Menschen treffen oder unbekannte Orte besuchen.
<G-vec00307-003-s051><meet_up.auftreffen><en> Children who are 8 to 18 months old often become frightened when they meet new people or visit new places.
<G-vec00307-003-s052><meet_up.auftreffen><de> De Wallen liegt im mittelalterlichen Stadtzentrum und strahlt sanft mit dekadenter Beleuchtung und hohen Fensterfronten – ein Ort, an dem historische Geheimnisse auf den modernen Nervenkitzel treffen.
<G-vec00307-003-s052><meet_up.auftreffen><en> Located in the medieval city centre, De Wallen glows softly with decadent rouged lighting and risque window displays – a place where historical secrets meet modern thrills.
<G-vec00307-003-s053><meet_up.auftreffen><de> Im Achtelfinale würde er bei einem Sieg gegen Mektic auf den Russen Konstantin Kravchuk (2011 im Halbfinale) oder Jan Mertl aus Tschechien treffen.
<G-vec00307-003-s053><meet_up.auftreffen><en> In the event of a win against Mektic he would meet the Russian Konstantin Kravchuk (semifinals in 2011) or Jan Mertl from the Czech Republic in the second round.
<G-vec00307-003-s054><meet_up.auftreffen><de> Aus diesem Grund ist die international verständliche .hospital-Domainendung auch für Informationsseiten und Diskussionsforen geeignet, in denen Laien auf geschulte Fachleute treffen, Termine vereinbaren oder Krankenakte abrufen können.
<G-vec00307-003-s054><meet_up.auftreffen><en> Because of that, the internationally understandable .hospital domain translation is also suitable for information pages and discussion forums in which laymen can meet trained experts, schedule appointments, or call up health records.
<G-vec00307-003-s055><meet_up.auftreffen><de> Teil einer besonderen Kooperation, bei der beliebte Disney-Figuren auf legendäres Coach Design treffen: Dieses neu interpretierte Must-have ist aus Neopren gefertigt und bietet so eine strukturierte Optik und ein weiches, gepolstertes Tragegefühl.
<G-vec00307-003-s055><meet_up.auftreffen><en> full price €95 €47,50 optic white with bambi Part of a special collaboration where beloved Disney characters meet iconic Coach design, this soft cotton T-shirt features a shadowy graphic from a classic animated tale.
<G-vec00307-003-s056><meet_up.auftreffen><de> Die Hansestadt ist gleichzeitig Heimat vielfältiger Veranstaltungen, auf denen Gründer auf andere Startups, Investoren sowie potenzielle Partner oder Kunden treffen.
<G-vec00307-003-s056><meet_up.auftreffen><en> Hamburg is also home to a variety of events, where founders can meet and connect with other start-ups, investors and potential partners or clients.
