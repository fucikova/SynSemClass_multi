<G-vec00522-002-s160><tighten.anspannen><de> Sage "Ahh" und spanne die Muskeln an der Hinterseite deines Halses an.
<G-vec00522-002-s160><tighten.anspannen><en> Go "Ahh," and tighten the muscles in the back of your throat.
<G-vec00522-002-s161><tighten.anspannen><de> Spanne deine Bauchmuskeln an und drücke dich vom Boden ab, indem du deine Hüften und deinen Po so weit nach oben hebst bis deine Knie, Hüften und Schultern eine Linie bilden.
<G-vec00522-002-s161><tighten.anspannen><en> Tighten your abs and push yourself up from the floor, lifting your hips and butt until your knees, hips, and shoulders are all in line.
