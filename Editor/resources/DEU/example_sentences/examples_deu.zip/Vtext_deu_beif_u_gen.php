<G-vec00407-001-s321><attach.beifügen><de> Sie können sich jederzeit über einen Link, den wir jeder E-Mail beifügen, oder durch eine Nachricht an die oben angegebenen Kontaktdaten abmelden.
<G-vec00407-001-s321><attach.beifügen><en> You can unsubscribe at any time by following a link which we attach to all e-mails or by sending a message to the contact details set out above.
<G-vec00407-001-s322><attach.beifügen><de> Sitzungsdatum Wenn der TOP in einer bestimmten Rektoratssitzung behandelt werden soll, bitte Erläuterung/Begründung beifügen.
<G-vec00407-001-s322><attach.beifügen><en> If the TOP is to be dealt with in a particular Rectorate meeting, please attach an explanation/reason.
<G-vec00407-001-s323><attach.beifügen><de> Als Berechtigungsnachweise müssen die Erben Kopien sämtlicher Dokumente beifügen, die ihre Anspruchsberechtigung nachweisen.
<G-vec00407-001-s323><attach.beifügen><en> As evidence of their entitlement, the heirs must attach copies of all documents which are liable to prove their entitlements.
<G-vec00407-001-s324><attach.beifügen><de> Hier haben Sie die Möglichkeit ihrer Bewerbung eine Datei beifügen.
<G-vec00407-001-s324><attach.beifügen><en> Here you have the possibility to attach a file to your application.
<G-vec00407-001-s325><attach.beifügen><de> Meinen Beleg beifügen (Rechnung...).
<G-vec00407-001-s325><attach.beifügen><en> Attach my proof (invoice...).
<G-vec00407-001-s326><attach.beifügen><de> Es kommt zu Änderungen in der Aufzählung der Pflichtanlagen – die Firmen zum Beispiel werden nicht mehr den Auszug aus dem Handelsregister oder einem anderen ähnlichen Register beifügen müssen, in dem sie eingetragen sind, sofern die in diesen Registern enthaltenen Angaben durch Fernzugriff ermittelbar sind.
<G-vec00407-001-s326><attach.beifügen><en> The list of mandatory schedules has changed – for instance, corporations are no longer required to attach an extract from the Commercial Register, or similar register, if the information is available on a remote access basis.
<G-vec00407-001-s327><attach.beifügen><de> Ich werde einige meiner Brautfotos beifügen.
<G-vec00407-001-s327><attach.beifügen><en> I will attach some of my bridal photos.
<G-vec00407-001-s328><attach.beifügen><de> Schicke das Smile Foto per Email (Attachment im Kontakt-Formular) oder via Facebook (Message schicken und Bild beifügen).
<G-vec00407-001-s328><attach.beifügen><en> Send us a picture of your smile by Email (Attachment on Contact Form) or via Facebook (send a message and attach your smile).
<G-vec00407-001-s329><attach.beifügen><de> "Wenn Sie eine Anlage beifügen wollen, melden Sie sich mit Ihrem DigiD über ""Meine SVB"" an."
<G-vec00407-001-s329><attach.beifügen><en> If you wish to attach a document to your email message, log in to My SVB with your DigiD code.
<G-vec00407-001-s330><attach.beifügen><de> Gerne können Sie Grafiken, Bilder oder schematische Darstellungen beifügen.
<G-vec00407-001-s330><attach.beifügen><en> You are welcome to attach graphics, pictures or schematic representations.
<G-vec00407-001-s331><attach.beifügen><de> Wenn Sie Waren zurückschicken, können Sie eine Kopie der Rechnung beifügen und schreiben, ob Sie das Geld zurückgeben oder die Waren mit einem anderen Produkt austauschen möchten.
<G-vec00407-001-s331><attach.beifügen><en> When you return goods, you can attach a copy of the invoice and write whether you want the money back or the goods exchanged with another product.
<G-vec00407-001-s332><attach.beifügen><de> Sie können als Wiedergabe bis zu zehn Fotos oder sonstige grafische Darstellungen des Designs beifügen, insbesondere um das Design aus verschiedenen Perspektiven zu zeigen.
<G-vec00407-001-s332><attach.beifügen><en> You can attach up to ten photographic or other graphic reproductions as representation of the design, particularly, to show the design from different angles.
<G-vec00407-001-s333><attach.beifügen><de> Grundsätzlich müssen Sie alle Bildungsnachweise beifügen, die Ihre im Antragsformular angegebenen Qualifikationen belegen.
<G-vec00407-001-s333><attach.beifügen><en> When applying for admission through uni-assist, you always have to attach all certificates documenting your qualifications stated in the application form.
<G-vec00407-001-s334><attach.beifügen><de> Antragstellende, die sich auf unvermeidbare Verzögerungen im wissenschaftlichen Werdegang berufen möchten, müssen daher im Antrag, im Anschreiben und im Lebenslauf ausdrücklich auf den jeweiligen Umstand hinweisen und gegebenenfalls (sofern dieser Umstand nicht selbsterklärend ist) eine kurze Erläuterung beifügen.
<G-vec00407-001-s334><attach.beifügen><en> Applicants who wish to explain unavoidable delays in their career development must therefore explicitly state the relevant circumstances in the proposal, covering letter and curriculum vitae and if necessary (if the circumstance is not self-explanatory) attach a short explanation.
<G-vec00407-001-s335><attach.beifügen><de> Wenn Sie Fotos von Antiquitäten oder der Kunst, dass Sie eines unserer Einkaufsangebot gerne einreichen möchten, können Sie die Formulare, die unten aufgeführt sind (Sie können alle gewünschten Fotos beifügen).
<G-vec00407-001-s335><attach.beifügen><en> If you would like to submit photos of antiques or art that you would like one of our purchase quote, you can use the forms that are listed below (you can attach all photos you want).
<G-vec00407-001-s336><attach.beifügen><de> Für den Fall, daß diese Texte nicht in einer der fünf Sprachen geschrieben worden sind (deutsch, englisch, spanisch, italienisch, französisch), eine kurze Zusammenfassung in einer dieser Sprachen beifügen.
<G-vec00407-001-s336><attach.beifügen><en> if the texts are not written in one of the five languages of publication (German, English, Spanish, Italian, French), please attach a brief summary in one of these languages.
<G-vec00407-001-s097><append.beifügen><de> Vergessen Sie bitte nicht, diese Ihren Verträgen beizufügen.
<G-vec00407-001-s097><append.beifügen><en> Please do not forget to append them to your contracts.
