<G-vec00057-001-s133><meet.decken><de> Die Robocademy trägt somit dazu bei, den hohen Bedarf an jungen Fachkräften zu decken, der so dringend auf dem wachsenden Feld der Unterwassersysteme und -robotik benötigt wird.
<G-vec00057-001-s133><meet.decken><en> Thus Robocademy will foster the formation of young professionals that are able to meet the urgent demand for highly qualified researchers and engineers in the growing field of underwater systems and robotics.
<G-vec00057-001-s134><meet.decken><de> Sugar Creek ist der Beginn, den amerikanischen Bundesstaat Illinois zum Windenergie-Zentrum zu machen und den wachsenden Bedarf an sauberer kostengünstiger Produktion erneuerbarer Energie zu decken.
<G-vec00057-001-s134><meet.decken><en> Sugar Creek is the first step to transform the American state of Illinois into a wind energy hub to meet the region´s growing demand for clean, cost effective renewable energy.
<G-vec00057-001-s135><meet.decken><de> Nelson Produkte bauen auf über 50 Jahre Erfahrung in der Konzeption und Lieferung von Lösungen, die den Bedarf jedes Kunden und jeder Anwendung bestens decken, sei es die Verhütung von Brandausbreitung in engen Bereichen oder das Halten der Rohrtemperatur in rauem Klima.
<G-vec00057-001-s135><meet.decken><en> Nelson products are backed by more than 50 years' experience designing and delivering solutions to best meet the needs of each customer and application, whether it be preventing the spread of fire in close quarters, or maintaining pipe temperature in harsh climates.
<G-vec00057-001-s136><meet.decken><de> Auf diese Weise kann es nicht nur den Bedarf der Kulturpflanzen an verschiedenen Nährstoffen decken, sondern auch eine Rolle bei der Unterstützung von Düngemitteln spielen.
<G-vec00057-001-s136><meet.decken><en> In this way, it can not only meet the needs of crops for various nutrients, but also play a role in assisting between fertilizers.
<G-vec00057-001-s137><meet.decken><de> und wie das Geld fließt, um diesen Bedarf zu decken.
<G-vec00057-001-s137><meet.decken><en> and how the money's flowing to meet those demands.
<G-vec00057-001-s138><meet.decken><de> Den weiteren Bedarf an Saatgut und Rohöl decken wir auf den internationalen Rohstoffmärkten im Einklang mit unserer Responsible Sourcing Policy ab.
<G-vec00057-001-s138><meet.decken><en> We meet our remaining requirement for seeds and crude oil on the international raw materials markets in harmony with our Responsible Sourcing Policy.
<G-vec00057-001-s139><meet.decken><de> Während der vergangenen zwei Jahre hatten alle teilnehmenden Mannschaften ein nachhaltiges Wohnhaus für zwei Personen entwickelt, das seinen Energiebedarf in der Jahresbilanz rein solar decken kann.
<G-vec00057-001-s139><meet.decken><en> During the previous two years, all teams taking part developed a sustainable house for two people that can meet its annual energy requirements purely by solar means.
<G-vec00057-001-s140><meet.decken><de> Ein Großteil der Schwerlastflotte ist veraltet und kann den steigenden Bedarf der brasilianischen Wirtschaft nicht decken.
<G-vec00057-001-s140><meet.decken><en> A large part of the country's heavy-goods fleet is obsolescent and can no longer meet the growing needs of Brazil's economy.
<G-vec00057-001-s141><meet.decken><de> Das globale Ölangebot war bisher ausreichend, um die Nachfrage zu decken.
<G-vec00057-001-s141><meet.decken><en> So far, the global oil supply has been sufficient to meet the demand.
<G-vec00057-001-s142><meet.decken><de> Ein wachsender Anteil der ländlichen Haushalte hat nicht mehr genügend Land, um den Jahresbedarf der Familie an Weizenmehl zu decken.
<G-vec00057-001-s142><meet.decken><en> A growing proportion of rural households no longer have enough land to meet the family's need for wheat flour for the year.
<G-vec00057-001-s143><meet.decken><de> """China ist nicht in der Lage, den welt­weiten Bedarf an Seltenen Erden zu decken"", meint er."
<G-vec00057-001-s143><meet.decken><en> """China may not be able to meet worldwide demand for RE products,"" he said."
<G-vec00057-001-s144><meet.decken><de> Das Angebot an schlachtreifen Schweinen fällt nach wie vor ausgesprochen gering aus, so dass Vermarkter alle Mühe haben, den Bedarf der Schlachtunternehmen zu decken.
<G-vec00057-001-s144><meet.decken><en> The quantities of pigs for slaughter on offer still are particularly low. So, the marketers will certainly find it difficult to meet the slaughter companies’ need.
<G-vec00057-001-s145><meet.decken><de> "„Um den steigenden Gasimportbedarf zu decken, haben unsere Anteilseigner in ein Infrastrukturprojekt investiert, das für mindestens 50 Jahre eine direkte Verbindung zwischen den europäischen Märkten und den großen russischen Gasreserven schafft"", fügt Warnig hinzu."
<G-vec00057-001-s145><meet.decken><en> “To help meet this long-term increase in demand for gas imports, our shareholders have committed to this long-term solution, creating a fixed link for at least 50 years between European markets and Russia’s massive gas reserves,” Mr Warnig added.
<G-vec00057-001-s146><meet.decken><de> Gleichzeitig soll das Projekt einen Beitrag zur Einkommenssicherung für die Dorfbewohner leisten, sodass diese einerseits ihren Bedarf an Gras, Brennholz und anderen Ressourcen decken und andererseits die Wälder nachhaltig bewirtschaften können.
<G-vec00057-001-s146><meet.decken><en> At the same time it is working to secure incomes for the villagers, and to meet their requirements for grass, firewood and other resources, while also promoting sustainable forestry.
<G-vec00057-001-s147><meet.decken><de> Diese Energien werden unseren Bedarf weitgehend decken.
<G-vec00057-001-s147><meet.decken><en> Renewable energies will meet our requirements to a large extent.
<G-vec00057-001-s148><meet.decken><de> In den USA, wo Online-Shopping drastisch zugenommen hat, setzen Lieferfirmen mittelschwere Elektro-Lkws und Elektro-Kleintransporter ein, um die Nachfrage nachhaltig zu decken.
<G-vec00057-001-s148><meet.decken><en> In the U.S., where online shopping has skyrocketed, delivery companies deploy electric medium-duty trucks and vans to meet the demand more sustainably.
<G-vec00057-001-s149><meet.decken><de> Wir stellen uns vor, die Grundbedürfnisse des Körpers wie Essen und Schlafen zu decken: Wir können eine bessere Disposition haben, um uns den Bedürfnissen des Geistes zu widmen.
<G-vec00057-001-s149><meet.decken><en> When we cover the basic needs of the body like eating and sleeping, we can enjoy a better disposition to devote ourselves to meet the needs of the spirit.
<G-vec00057-001-s150><meet.decken><de> Heute, wo die Durchschnittsernte nicht einmal die Hälfte beträgt, muss der Staat Milliarden aufbringen, nur um die Defizite zu decken.
<G-vec00057-001-s150><meet.decken><en> At present, when the average harvest is less than half of that, the state is compelled to disburse billions to meet the deficit.
<G-vec00057-001-s151><meet.decken><de> Um hier noch weitere Verbesserungen zu erzielen, hat die Triodos Bank eine Solaranlage installieren lassen, die voraussichtlich 10 % des Strombedarfs der Niederlassung (gemessen am Bedarf im bisherigen Gebäude) decken wird.
<G-vec00057-001-s151><meet.decken><en> To improve it further Triodos Bank has installed solar panels, which are expected to meet 10% of the branch's electricity needs (when compared to its usage in its previous building).
