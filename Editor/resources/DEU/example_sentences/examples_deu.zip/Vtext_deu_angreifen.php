<G-vec00441-001-s057><attack.angreifen><de> Aber das geht sowieso erst nach der Ernte, weil die Felder jetzt noch grün sind, und falls wir nicht angegriffen werden, denn in den nächsten Monaten könnten wir nur unreife Maiskolben verschicken, und daraus werden keine guten Tamales, also warten wir besser damit bis November oder Dezember, je nachdem.
<G-vec00441-001-s057><attack.angreifen><en> And that will happen when the harvest comes in, which is turning green right now in the fields, and if they don’t attack us, because if we were to send it during these next few months, it would be nothing but corncobs, and they don’t turn out well even in tamales, better in November or December, it depends.
<G-vec00441-001-s058><attack.angreifen><de> In Japan wurden Autos, mit denen Mitglieder der Kaiserlichen Familie transportiert wurden, in den letzten Tagen bei verschiedenen Gelegenheiten angegriffen, berichten Quellen des Rechten Flügels, die der Kaiserfamilie nahestehen.
<G-vec00441-001-s058><attack.angreifen><en> The other thing going on in Japan is that cars carrying members of the Japanese royal family have come under attack in several incidents in recent days, according to right wing sources close to the imperial family.
<G-vec00441-001-s059><attack.angreifen><de> Die Behandlung der Katze mit Tropfen sollte während des gesamten Zeitraums mehrmals buchstäblich erfolgen, um sie vor einer Infektion zu schützen und sie von Parasiten zu befreien, die sie bereits angegriffen haben.
<G-vec00441-001-s059><attack.angreifen><en> Processing the cat with drops here should be done literally several times over the entire period in order to protect it from infection and rid it of those parasites that have already managed to attack it.
<G-vec00441-001-s060><attack.angreifen><de> Heute, in einer Welt, in der die klassischen Künste oft ums Überleben kämpfen und neue und bizarre Kunstformen oft schwer verdaulich sind, ist die Idee einer göttlichen Kultur von klarer Schönheit, die vom Schöpfer geschaffen wurde, und jetzt angegriffen wird, was das chinesische kommunistische Regime buchstäblich auch so macht, vielleicht die größte Geschichte unserer Zeit.
<G-vec00441-001-s060><attack.angreifen><en> Today, in a world where classical arts often struggle to survive and new and bizarre art forms are often difficult to digest, the idea of a divine culture of clear beauty made by the Creator that is now under attack, as it quite literally is by the Chinese communist regime, is perhaps the greatest story of our time.
<G-vec00441-001-s061><attack.angreifen><de> Paulus hat das römische Sklavenrecht nicht angegriffen, aber es im Raum der Gemeinde mit Liebe überwunden.
<G-vec00441-001-s061><attack.angreifen><en> Paul did not attack Roman system of slavery, but overcame it with love in the realm of the church.
<G-vec00441-001-s062><attack.angreifen><de> Wenn nach dem Plan etwas schiefgelaufen ist und die Wespen angegriffen haben, müssen Sie sofort in den Raum laufen und die Tür hinter sich schließen.
<G-vec00441-001-s062><attack.angreifen><en> If something went wrong according to the plan, and the wasps began to attack, you need to immediately run into the room and close the door behind you.
<G-vec00441-001-s063><attack.angreifen><de> Wir haben niemanden angegriffen, keine anderen Länder besetzt.
<G-vec00441-001-s063><attack.angreifen><en> We did not attack anyone, nor did we occupy other countries.
<G-vec00441-001-s064><attack.angreifen><de> Wir werden angegriffen.
<G-vec00441-001-s064><attack.angreifen><en> We are under attack and
<G-vec00441-001-s065><attack.angreifen><de> Der Lebensraum von Mensch und Tier wird massiv angegriffen, wenn die Posaunen erschallen.
<G-vec00441-001-s065><attack.angreifen><en> Living space for man and animal will come under massive attack when the trumpets are sounded.
<G-vec00441-001-s066><attack.angreifen><de> Eine wichtige Information für alle europäischen Jäger und Waffenbesitzer: in Europa werden wieder die Waffenrechte angegriffen.
<G-vec00441-001-s066><attack.angreifen><en> An important information for all European hunters and gun-owners: once again, gun rights are under attack in Europe.
<G-vec00441-001-s067><attack.angreifen><de> Nur so können neutrale Länder angegriffen werden.
<G-vec00441-001-s067><attack.angreifen><en> Only in this way you can attack neutral countries.
<G-vec00441-001-s068><attack.angreifen><de> Wir wurden von amerikanischen Soldaten angegriffen.
<G-vec00441-001-s068><attack.angreifen><en> We were under attack by US Soldiers.
<G-vec00441-001-s069><attack.angreifen><de> Doch in den folgenden Jahren wurde die revolutionäre Orientierung des PCI wiederholt aus den eigenen Reihen heraus angegriffen.
<G-vec00441-001-s069><attack.angreifen><en> In subsequent years, however, the revolutionary orientation of the PCI came under repeated attack from elements inside its own ranks.
<G-vec00441-001-s070><attack.angreifen><de> Das bedeutet, dass dieses Land an zwei Fronten angegriffen wird (Jemen und Syrien) und seine „Bewährung“ bewirkt, dass es noch nicht in der Lage ist, seine Interessen und die seiner Verbündeten zu verteidigen.
<G-vec00441-001-s070><attack.angreifen><en> That said, this country is under attack on two fronts (the Yemen and Syria) and its “parole” means that it doesn’t always have a free hand to defend its interests and those of its allies.
<G-vec00441-001-s071><attack.angreifen><de> "Als Empire City von einer mysteriösen Kreatur angegriffen wird, die als ""die Bestie"" bekannt ist, können nicht mal die elektrischen Superkräfte von Cole MacGrath die Stadt vor der völligen Zerstörung retten."
<G-vec00441-001-s071><attack.angreifen><en> "When Empire City comes under attack from a mysterious creature known only as ""The Beast"", not even the electric super powers of Cole MacGrath can save the town from complete destruction."
<G-vec00441-001-s072><attack.angreifen><de> Gleichzeitig kann mit langen Noppen aber auch sehr effektiv und druckvoll durch Druckschupf und Liften angegriffen werden.
<G-vec00441-001-s072><attack.angreifen><en> At the same time you can attack dynamically and effectively with long pimples through aggressive pushing and lifting.
<G-vec00441-001-s073><attack.angreifen><de> Marco Jepulrecia, ein Bewohner von Flushing, sagte, er habe gesehen, dass die Komplizen der KPCh die Falun Gong-Praktizierenden in den Straßen von Flushing angegriffen hätten, und er habe deren beleidigende Worte gehört.
<G-vec00441-001-s073><attack.angreifen><en> Flushing resident Marco Jepulrecia, who passed by the rally venue, said that he had seen the CCP's accomplices attack Falun Gong practitioners on the streets of Flushing, and heard those insulting words.
<G-vec00441-001-s074><attack.angreifen><de> Während der Kościuszko-Insurrektion im November 1794 wurde Warschau durch russische Truppen unter dem Kommando von General Suworow im Osten angegriffen.
<G-vec00441-001-s074><attack.angreifen><en> In November 1794, during Kosciuszko Insurrection, Warsaw was attacked from east by Russian forces, under commandment of general Suvorov. Praga district, was an eastern boundary of Warsaw, therefore it suffered from really heavy Russian attack.
<G-vec00441-001-s075><attack.angreifen><de> Renegades können nur von Einzelspieler Planeten mit der Flugmission Renegade Angriff angegriffen werden.
<G-vec00441-001-s075><attack.angreifen><en> You can attack renegades only from Single planet on flight Attack Renegade.
<G-vec00441-001-s005><assail.angreifen><de> Wenn in der Kirche Modern jemand ist jedoch überzeugt, dass vor einem Körper von einem verheerenden degenerativen Diabetes zu kämpfen, die Gangrän im FuÃ verursacht, ist stattdessen sehr gnädig nicht amputieren, weil es nicht gut ist, einen Menschen von einem Schenkel zu entziehen, in einem solchen Fall ist offensichtlich: Wir bereiten die unvermeidliche Folge der Gangrän, die von dort bald alle anderen Glieder des Körpers angreifen.
<G-vec00441-001-s005><assail.angreifen><en> If within the Church Contemporary someone is convinced, however, that before a body beset by a devastating degenerative diabetes that caused gangrene in the foot, is instead very merciful not amputate, because it is not good to deprive a human being of a limb, in such a case is obvious: We prepare the inevitable consequence of gangrene that from there soon assail all the other limbs of the body.
<G-vec00441-001-s006><assail.angreifen><de> Catchers immer verwendet uns von Alpträumen zu schützen, die uns in der Nacht angreifen.
<G-vec00441-001-s006><assail.angreifen><en> Catchers have always been used to protect us from nightmares that assail us at night.
<G-vec00441-001-s076><attack.angreifen><de> Im Fall der Mücke ist das Merkwürdige, wie sie es fertig bringt, den Geruch eines Menschen, den sie angreifen kann, aus derartiger Entfernung zu riechen.
<G-vec00441-001-s076><attack.angreifen><en> As regards the mosquito the miracle is how it manages to register the smell of a human to attack from such a distance.
<G-vec00441-001-s077><attack.angreifen><de> Frage gestellt von: Guilherme Coelho • Die meisten Tiere meiden Menschen, aber sie können angreifen, wenn sie sich bedroht fühlen oder ihr Territorium schützen, wenn sie verletzt oder krank sind.
<G-vec00441-001-s077><attack.angreifen><en> Question asked by: Guilherme Coelho • Most animals avoid people, but they may attack if they feel threatened or protecting their territory, or if they are injured or ill.
<G-vec00441-001-s078><attack.angreifen><de> Wir organisieren die Weltrevolution, dessen Bestandteil auch die Revolution in Türkei – Nord Kurdistan ist, in dem wir die Schwachstellen des Imperialismus angreifen.
<G-vec00441-001-s078><attack.angreifen><en> We organize the world revolution, which also includes the revolution in Turkey-Northern Kurdistan, where we attack the weak points of imperialism.
<G-vec00441-001-s079><attack.angreifen><de> USAs Council on Foreign Relations erwartet, dass Israel den Iran angreifen werde - und billigt es schweigend.
<G-vec00441-001-s079><attack.angreifen><en> USAs Council on Foreign Relations expects Israel to attack Iran – and silently approves of it.
<G-vec00441-001-s080><attack.angreifen><de> Nun, deshalb ist es so, dass sie glauben, Herr Verhofstadt darf uns angreifen, und wir werden dann auf eine ebenso laue Weise reagieren, wie das in der Demokratie in Westeuropa gang und gäbe ist.
<G-vec00441-001-s080><attack.angreifen><en> This is why over there they think that Mr. Verhofstadt can attack us, and we'll just respond in the lukewarm way that is customary in Western European democracy.
<G-vec00441-001-s081><attack.angreifen><de> Oder eine andere Geschichte, die ihren eigenen Vorteil har det sagt komponieren (Sie wollen es einfach, Sie können sich aber nicht angreifen, und Sie werden es nicht so lange, wie Sie es gesehen haben).
<G-vec00441-001-s081><attack.angreifen><en> Or another story that compose its own advantage har sagt det (you just want it, but you can not attack yourself, and you will not have it as long as you've seen it).
<G-vec00441-001-s082><attack.angreifen><de> Es wurde ein paar Tage später in Camp David von Präsident Bush erlassen: die Vereinigten Staaten sollten Afghanistan, den Irak, Libyen und via dem Libanon Syrien, den Sudan, Somalia und schließlich den Iran angreifen.
<G-vec00441-001-s082><attack.angreifen><en> It was officially enacted by President Bush a few days later at Camp David: the United States were to attack Afghanistan, Iraq, Libya and Syria via Lebanon, Sudan and Somalia, and finally Iran.
<G-vec00441-001-s083><attack.angreifen><de> Nicht seine verrückten Ideen angreifen.
<G-vec00441-001-s083><attack.angreifen><en> Don’t attack his crazy ideas.
<G-vec00441-001-s084><attack.angreifen><de> Anzahl der Runden, wo wir die Möglichkeit haben, angreifen oder eine Karte für die Verteidigung aktivieren sind Sets.
<G-vec00441-001-s084><attack.angreifen><en> number of rounds where we will have the opportunity to attack or activate a card for the defense are set.
<G-vec00441-001-s085><attack.angreifen><de> Wahrscheinlich möchte niemand regelmäßig Spielzeuge angreifen, die im Raum verteilt sind.
<G-vec00441-001-s085><attack.angreifen><en> Probably no one wants to regularly attack toys scattered around the room.
<G-vec00441-001-s086><attack.angreifen><de> Ihre Hoffnung: Ist die atomare Struktur der bakteriellen Injektionsnadel bekannt, so lassen sich Medikamente entwickeln, welche dort optimal angreifen können.
<G-vec00441-001-s086><attack.angreifen><en> They hope that once the atomic structure of the bacterial injection needle is known, it will enable the development of medications that can optimally attack the pathogens at this location.
<G-vec00441-001-s087><attack.angreifen><de> In Pi-Softs SpoonFTP existiert eine Sicherheitslücke, durch die ein Angreifer eine Verbindung über einen anfälligen FTP Server umleiten und einen dritter Rechner angreifen kann.
<G-vec00441-001-s087><attack.angreifen><en> A vulnerability exists in Pi-Soft's SpoonFTP that can result in an attacker being able to bounce a connection through the vulnerable server and attack a third-party host.
<G-vec00441-001-s088><attack.angreifen><de> Der Killer Clowns sind bösartig und wird Sie mit Wut angreifen aber Sie müssen sich zu wehren mit einer größeren Rache.
<G-vec00441-001-s088><attack.angreifen><en> The killer clowns are vicious and will attack you with fury but you will have to fight back with a greater vengeance.
<G-vec00441-001-s089><attack.angreifen><de> Diese Wanzen sind aggressive Raubtiere, die oft Kaulquappen und kleine Fische angreifen.
<G-vec00441-001-s089><attack.angreifen><en> These bugs are aggressive predators and often attack tadpoles and small fish.
<G-vec00441-001-s090><attack.angreifen><de> Allerdings entscheidet Niflheim offen, das Reich Lucis angreifen.
<G-vec00441-001-s090><attack.angreifen><en> However, Niflheim decides openly attack the Kingdom of Lucis .
<G-vec00441-001-s091><attack.angreifen><de> Ransomware-Tool Ihr Computersystem mit Schlauheit und auch Finesse angreifen.
<G-vec00441-001-s091><attack.angreifen><en> Ransomware tool attack your computer system using slyness and also finesse.
<G-vec00441-001-s092><attack.angreifen><de> Wenn Sie plötzlich Hypothermie unterziehen oder eine ungeschickte Bewegung nehmen, einen schweren Gegenstand heben, sollten Sie wieder angreifen entstehen.
<G-vec00441-001-s092><attack.angreifen><en> If suddenly you undergo hypothermia or make some awkward movement, pick up a heavy object, the attack again will necessarily arise.
<G-vec00441-001-s093><attack.angreifen><de> SunriseBrowse ist der Name eines anderen prekären Adware, die auf dem infizierten Windows-System über Social Engineering und andere Techniken angreifen.
<G-vec00441-001-s093><attack.angreifen><en> SunriseBrowse is name of another precarious adware that attack to the compromised windows system via social engineering and other techniques.
<G-vec00441-001-s094><attack.angreifen><de> Frage gestellt von: Liv Hauge • Die meisten Tiere meiden Menschen, aber sie können angreifen, wenn sie sich bedroht fühlen oder ihr Territorium schützen, wenn sie verletzt oder krank sind.
<G-vec00441-001-s094><attack.angreifen><en> Question asked by: Liv Hauge • Most animals avoid people, but they may attack if they feel threatened or protecting their territory, or if they are injured or ill.
<G-vec00441-001-s095><attack.angreifen><de> Und dann Instruktionen über die Position der Wachposten und Abschussbögen ('firing arcs') – Entscheidungen über das Schussfeld für jeden, falls die Polizei angreift.
<G-vec00441-001-s095><attack.angreifen><en> And then instructions about sentry positions and ‘firing arcs’—decisions about who will cover which area in the event of a police attack.
<G-vec00441-001-s096><attack.angreifen><de> """Wer Christen entführt und friedliche kurdische Dörfer angreift, in denen tausende Flüchtlinge Schutz gesucht haben, darf weder Waffen noch andere Rüstungsgüter von westlichen Staaten erhalten"", erklärte die Menschenrechtsorganisation anlässlich der Beratungen der EU-Außenminister in Brüssel über eine zusätzliche Unterstützung der Aufständischen."
<G-vec00441-001-s096><attack.angreifen><en> """The western countries should not deliver any weapons or other military equipment to those who abduct Christians and attack peaceful Kurdish villages where thousands of refugees have sought protection,"" stated the human rights organization on occasion of the meeting of the EU's foreign ministers in Brussels to discuss support for the insurgents."
<G-vec00441-001-s097><attack.angreifen><de> Wenn ein Monster deines Gegners angreift, kannst du 1 Monster vom Typ Insekt in deinem Friedhof aus dem Spiel entfernen, um den Angriff zu annullieren.
<G-vec00441-001-s097><attack.angreifen><en> When your opponent's monster declares an attack, you can remove from play 1 Insect-Type monster from your Graveyard to negate the attack.
<G-vec00441-001-s098><attack.angreifen><de> Er hat gerade erst die Wahrheit über seinen Vater herausgefunden und nun liegt dieser im Koma, während die fremde Alienrasse weiterhin alles und jeden angreift und sogar einige der ‘bekannten’ Rassen insgeheim gegen ihn zu arbeiten scheinen.
<G-vec00441-001-s098><attack.angreifen><en> He has only just found out about his father and now he is in a coma, the universe is under attack from an alien race, and some of the ‘known’ race species seem to be working against him.
<G-vec00441-001-s099><attack.angreifen><de> Der Gegner bestimmt, welchen Krieger er angreift.
<G-vec00441-001-s099><attack.angreifen><en> The Defender chooses which warrior to attack.
<G-vec00441-001-s100><attack.angreifen><de> Ihr feuert manchmal eine explosive Höllenfeuerkugel ab, wenn Ihr angreift.
<G-vec00441-001-s100><attack.angreifen><en> Chance to launch an explosive ball of Hellfire when you attack.
<G-vec00441-001-s101><attack.angreifen><de> Creature Focus: Beschwört eine kurzlebige, fliegende Kreatur genannt Soul-Cluster, das Feinde in der Nähe angreift.
<G-vec00441-001-s101><attack.angreifen><en> Creature Focus: Summons a short-lived flying creature called a Soul Cluster that will attack nearby enemies.
<G-vec00441-001-s102><attack.angreifen><de> National wird sie ein neues Objekt im Business Segment anbieten, mit dem sie „Der Unternehmer“ direkt angreift.
<G-vec00441-001-s102><attack.angreifen><en> Nationally it will offer a new item in the business segment to directly attack “The entrepreneur”.
<G-vec00441-001-s103><attack.angreifen><de> Erschafft nach einer kurzen Verzögerung bei jedem gegnerischen Helden eine spektrale Nemesis, die diesen angreift.
<G-vec00441-001-s103><attack.angreifen><en> Creates a spectral nemesis to attack each enemy hero after a short delay.
<G-vec00441-001-s104><attack.angreifen><de> Wenn ihr jemanden angreift oder euch zur Wehr setzt, entbrennt ein schonungsloser Kampf und der Sieger erhält die Beute.
<G-vec00441-001-s104><attack.angreifen><en> If you attack someone and they fight back, full-on combat ensues and to the winner go the spoils.
<G-vec00441-001-s105><attack.angreifen><de> In der Vergangenheit haben einige Befürworter behauptet, dass Apfelessig, der Beta-Carotin enthält, die freien Radikale angreift, die das Immunsystem schädigen.
<G-vec00441-001-s105><attack.angreifen><en> In the past, some proponents have claimed that apple cider vinegar, which contains beta carotene, can attack the free radicals that damage the immune system.
<G-vec00441-001-s106><attack.angreifen><de> Ein Bot ist ein Computerprogramm, das sich automatisch bei Pinterest einschleicht oder die Webseite angreift.
<G-vec00441-001-s106><attack.angreifen><en> A bot is a computer program made to automatically scrape, crawl, or attack Pinterest.
<G-vec00441-001-s107><attack.angreifen><de> Die Technologie sorgt für eine kontinuierliche Migration von Silberionen an die Kontaktoberflächen des Produkts, von wo aus das Polygiene-Material dann Bakterien und Viren angreift.
<G-vec00441-001-s107><attack.angreifen><en> The technology provides for a continuous migration of silver ions to a product’s contact surface from where they attack all bacteria and viruses.
<G-vec00441-001-s108><attack.angreifen><de> Wenn wir denken jemand nicht angreift, Im Hintergrund ist, dass jemand seinen eigenen inneren Kampf kämpft.
<G-vec00441-001-s108><attack.angreifen><en> When we think someone does not attack, in the background can that someone is fighting his own internal battle.
<G-vec00441-001-s109><attack.angreifen><de> Krebsvorstufe – Dies ist eine Änderung in den Zellen eines bestimmten Organs, zum Beispiel die Lunge, in der es nach richtigem Krebs aussieht, aber er nicht den Körper angreift, wie richtiger Krebs.
<G-vec00441-001-s109><attack.angreifen><en> PRE-CANCER – This is a change in the cells of a particular organ, for example the lungs, which looks like true cancer but do not attack the body as true cancer does.
<G-vec00441-001-s110><attack.angreifen><de> Bei einem sogenannten Man-in-the-Middle-Angriff handelt es sich um eine spezielle Angriffsmethode, bei der ein Angreifer die Kommunikation zwischen zwei Parteien angreift, indem er sich zwischen den Parteien befindet und volle Kontrolle über den Datenverkehr ausüben kann.
<G-vec00441-001-s110><attack.angreifen><en> In a so-called man-in-the-middle attack, a special method of attack is used in which an attacker compromises the communication between two parties by locating himself between the parties and exercising full control of data traffic.
<G-vec00441-001-s111><attack.angreifen><de> Wenn Sie über die potenzielle Gefahr einer gewöhnlichen Hornisse streiten, sollten Sie sich daran erinnern, dass dieses Insekt niemals ohne triftigen Grund angreift.
<G-vec00441-001-s111><attack.angreifen><en> Therefore, arguing about the potential danger of an ordinary hornet, it is worth remembering - this insect will never attack first without good reason.
<G-vec00441-001-s112><attack.angreifen><de> Trap Card Aktiviere diese Karte nur, wenn ein Monster deines Gegners direkt angreift, solange du 3000 oder weniger Life Points hast.
<G-vec00441-001-s112><attack.angreifen><en> Trap Card Activate only when your opponent's monster declares a direct attack while you have 3000 or less Life Points.
<G-vec00441-001-s113><attack.angreifen><de> Aktiviere diese Karte nur, wenn ein Monster deines Gegners angreift.
<G-vec00441-001-s113><attack.angreifen><en> Activate only when an opponent's monster declares an attack.
<G-vec00441-001-s152><attack.angreifen><de> Die Sozialdemokratische Fraktion im Europäischen Parlament bekräftigte heute ihr Bekenntnis zur Verteidigung des Streikrechts, das derzeit an zahlreichen Fronten in Europa und weltweit Angriffen...
<G-vec00441-001-s152><attack.angreifen><en> S&D Euro MPs today reiterated their commitment to defending the right to strike, which is currently under attack on many fronts in Europe and around the world.
<G-vec00441-001-s153><attack.angreifen><de> Seen versucht, ihr Dorf von Monstern Angriffen zu schützen.
<G-vec00441-001-s153><attack.angreifen><en> Seen trying to protect her village from monsters attack.
<G-vec00441-001-s154><attack.angreifen><de> Es war in einer blutigen Schlacht, in der mich Kapitäne angriffen, die 40 Level höher als ich waren.
<G-vec00441-001-s154><attack.angreifen><en> It was a bloody battle that saw a Cap'n 40 levels higher than me wage an attack. Hark!
<G-vec00441-001-s155><attack.angreifen><de> Daher müssen Wege zur Analyse, Entdeckung und Antizipation von Gefahren und Angriffen und gegebenenfalls auch für die rechtzeitige Einleitung von Gegenmaßnahmen bei Angriffen (Intrusion Response) gefunden werden.
<G-vec00441-001-s155><attack.angreifen><en> Therefore ways have to be found to analyze, detect and anticipate dangers and attacks. Finally the reaction to an attack also has to be specified. (Intrusion Response).
<G-vec00441-001-s156><attack.angreifen><de> Wie Sie wissen, sollten bei der Auswahl geeigneter Sicherheitsmaßnahmen für Netzwerk-Kameras die Vorteile eines erfolgreich verhinderten Angriffs den Kosten für den Schutz vor Angriffen dieser Art gegenübergestellt werden.
<G-vec00441-001-s156><attack.angreifen><en> As you know, taking appropriate security measures around network cameras is a matter of weighing the benefits of preventing a successful attack against the costs of protecting against such an attack.
<G-vec00441-001-s157><attack.angreifen><de> Zwischen der VRS und den Vertretern der bosnischen Muslime der Enklave Zepa fanden drei verschiedene Verhandlungsrunden statt, bei denen die Vertreter der VRS, unter Androhung von militärischen Angriffen, versuchten, die Bevölkerung von Zepa zum Verlassen der Enklave zu bewegen.
<G-vec00441-001-s157><attack.angreifen><en> Three different negotiations took place between the VRS and representatives of the Bosnian Muslims from the Zepa enclave. During these negotiations, the representatives of the VRS tried to force the population out of the enclave, by threatening a military attack.
<G-vec00441-001-s158><attack.angreifen><de> In Fällen, in denen der Proteinanteil einer Knochenprobe nicht gut erhalten ist und sich aufgrund von warmen Bedingungen oder Angriffen durch Pilze oder Bakterien abgebaut hat, datieren AMS Datierungslaboratorien verschiedene Aminosäuren um zu überprüfen, ob einige von ihnen dasselbe Radiokohlenstoff Alter ergeben.
<G-vec00441-001-s158><attack.angreifen><en> In cases when the protein portion of the bone sample is not well preserved and have already degraded due to warm conditions and fungal or bacterial attack, AMS dating labs carbon date individual amino acids to check if several of them give the same radiocarbon age.
<G-vec00441-001-s159><attack.angreifen><de> Bei der Cisco Unity Connection ist der Schutz gegenüber Cross-Site Request Forgery (CSRF) Angriffen bei der Seite CUCReports nicht ausreichend.
<G-vec00441-001-s159><attack.angreifen><en> A vulnerability in the CUCReports page of Cisco Unity Connection could allow an unauthenticated, remote attacker to perform a Cross-Site Request Forgery (CSRF) attack against the CUCReports web interface.
<G-vec00441-001-s160><attack.angreifen><de> Reed ist weniger chemischen Angriffen ausgesetzt, was einerseits gut ist, andererseits aber auch unerwünschte Verunreinigungen verursachen kann.
<G-vec00441-001-s160><attack.angreifen><en> Reed is exposed to less chemical attack, which, on the one hand, is good, but on the other hand it can give undesirable impurities.
<G-vec00441-001-s161><attack.angreifen><de> Von den klassischen Angriffen setzt nur die Koinzidenzanalyse eine Längenkongruenz zwischen Klartext und Chiffretext voraus.
<G-vec00441-001-s161><attack.angreifen><en> The only known traditional attack requiring a congruence of length between plaintext and ciphertext is analysis of coincidence.
<G-vec00441-001-s162><attack.angreifen><de> "Für den Kernbereich der eigentlichen ""Cybersecurity"" ist es wichtig, dass Systeme über alle notwendigen ""IT-Security""-Funktionen verfügen, von gehärteten Betriebssystemen über Möglichkeiten zur Trennung der Netze bis hin zu Verschlüsselungstechniken und Möglichkeiten zur Entdeckung von Angriffen."
<G-vec00441-001-s162><attack.angreifen><en> "For the actual core function ""cybersecurity"", it is important that systems are equipped with all the requisite ""IT security"" functions, from hardened operating systems to capabilities for separating networks and up to and including encryption technologies and attack detection capabilities."
<G-vec00441-001-s163><attack.angreifen><de> Bei seinen Angriffen auf Falun Gong geht er rücksichtslos vor.
<G-vec00441-001-s163><attack.angreifen><en> He is ruthless in his attack on Falun Gong.
<G-vec00441-001-s164><attack.angreifen><de> US-Präsident George W. Bush hat in der Folge den grenzenlosen »Krieg gegen den Terror« erklärt und im Oktober 2001 mit Angriffen auf Afghanistan begonnen.
<G-vec00441-001-s164><attack.angreifen><en> "In the aftermath of 9/11, U.S. President George W. Bush declared an endless ""War against terror"" and began it in October with an attack on Afghanistan."
<G-vec00441-001-s165><attack.angreifen><de> Die IP-Adresse wird nur bei Angriffen auf die Netzinfrastruktur des DIE ausgewertet.
<G-vec00441-001-s165><attack.angreifen><en> The IP address will only be analysed in the event of an attack on DIE's network infrastructure.
<G-vec00441-001-s166><attack.angreifen><de> Über umfangreiche Sicherheitsfunktionen (802.11i, WPA, WPA2) kann der Funkverkehr der Geräte ohne Performanceverlust sicher vor Angriffen geschützt werden.
<G-vec00441-001-s166><attack.angreifen><en> A wide range of security functions (802.11i, WPA, WPA2) ensure that transmissions from these devices are safe from attack without any loss in performance.
<G-vec00441-001-s167><attack.angreifen><de> Um nur zwei Beispiele frauenfeindlicher Bigotterie zu nennen, so ist in den Vereinigten Staaten das Recht auf Abtreibung zunehmenden Angriffen ausgesetzt, während anständige Kinderbetreuung rar ist und für die meisten arbeitenden Frauen nicht erschwinglich.
<G-vec00441-001-s167><attack.angreifen><en> In the United States, to name just two instances of anti-woman bigotry, abortion rights are under increasing attack and quality childcare is scarce and too costly for most working women.
<G-vec00441-001-s168><attack.angreifen><de> Die Absicht hinter diesen Angriffen der mächtigeren Geister ist, SSRF-Gottsuchende bei ihrer Suche nach Wissen und bei der Verbreitung der Spiritualität zu behindern.
<G-vec00441-001-s168><attack.angreifen><en> The main reasons for the attack from more powerful ghosts are to oppose the SSRF seeker's quest for knowledge and spread of Spirituality.
<G-vec00441-001-s169><attack.angreifen><de> Unabhängig davon, ob Sie eine SaaS-Lösung wie Microsoft Office 365 einsetzen oder Ihre E-Mail-Anwendung über eine IaaS-Plattform bereitstellen, sind Sie dafür verantwortlich, Ihre Daten vor versehentlicher Löschung, Ausfällen oder böswilligen Angriffen zu schützen.
<G-vec00441-001-s169><attack.angreifen><en> Whether you're using a SaaS solution, such as Microsoft Office 365, or hosting your email application on IaaS, it is critical to have protection against accidental deletions, outages, or a malicious attack.
<G-vec00441-001-s170><attack.angreifen><de> Im Internet sind neue Versionen von Stacheldraht und Trinity zur Durchführung von Distributed Denial-of-Service Angriffen (DDoS) aufgetaucht.
<G-vec00441-001-s170><attack.angreifen><en> New versions of Stacheldraht and Trinity distributed denial of service (DDoS) attack tools have been found in the wild.
<G-vec00441-001-s007><assail.angreifen><de> Nicht nur, um die internationalen Sanktionen aufzuheben, die dem Land ernsthaft schaden, sondern vor allem, weil die Vereinigten Staaten bereit sind, das Land zu destabilisieren falls die Verhandlungen versagen: mehr als 80 westliche TV-Sender in Farsi-Sprache sind bereit das Land anzugreifen, während die Terroristen der Mudschahiddin des Volkes ihre Selbstmordattentäter bereitstellen.
<G-vec00441-001-s007><assail.angreifen><en> Not only in order to obtain the lifting of the international sanctions that are severely harming his country, but mainly because the United States is poised to destabilize Iran if the plan falls through. More than 80 Western TV channels in Farsi are ready to assail the country, while the terrorist organization, the People’s Mojahedin of Iran, are lining up their suicide bombers.
<G-vec00441-001-s285><attack.angreifen><de> Anulliere den Angriff eines Monsters deines Gegners und wähle 1 anderes offenes Monster deines Gegners und zwinge es anzugreifen.
<G-vec00441-001-s285><attack.angreifen><en> Negate the attack of 1 monster and select another 1 of your opponent's face-up monster and have it attack.
<G-vec00441-001-s286><attack.angreifen><de> Am Anfang des Jahres betrachtete die israelische Führung es immer noch als eine vernünftige Möglichkeit, dass Bush sich dazu entscheiden würde, vor dem Ende seiner Amtszeit Iran anzugreifen.
<G-vec00441-001-s286><attack.angreifen><en> At the beginning of the year, the Israeli leadership still considered it a reasonable possibility that Bush would decide to attack Iran before the end of his term.
<G-vec00441-001-s287><attack.angreifen><de> Anstatt sich auf einen Rüstungswettlauf einzulassen hat Putin außerdem Überschallraketen entwickelt, welche die frühere Fähigkeit der US-Verteidigungssysteme sowie Flugzeugträger, andere Nationen ohne Befürchtung von Konsequenzen anzugreifen, obsolet machten.
<G-vec00441-001-s287><attack.angreifen><en> Also, rather than getting into an arms race, Putin has developed hypersonic missiles which have made the former ability of US defense systems and aircraft carriers to attack other nations with impunity moot.
<G-vec00441-001-s288><attack.angreifen><de> "Es klingt wahrscheinlich grotesk, dass die KPCh die Bezeichnung ""der Abschaum der feudalen Gesellschaft"" benutzt, um Religion und spirituellen Glauben anzugreifen."
<G-vec00441-001-s288><attack.angreifen><en> "It may sound bizarre that the CCP has used the label of ""the dregs of feudal society"" to attack religion and spiritual beliefs."
<G-vec00441-001-s289><attack.angreifen><de> Klicke auf den gegnerischen Bienenstock um anzugreifen.
<G-vec00441-001-s289><attack.angreifen><en> Click on opponents hive to attack.
<G-vec00441-001-s290><attack.angreifen><de> Ein kann mutig und ein rassischer Moderate sein, der es ablehnt, andere Leute als anzugreifen Mittel des Voranbringens.
<G-vec00441-001-s290><attack.angreifen><en> One can be both courageous and a racial moderate who declines to attack other people as a means of advancing oneself.
<G-vec00441-001-s291><attack.angreifen><de> "In vielen Bereichen hat somit eine technische Neuzusammensetzung stattgefunden: Vor allem im Bankbereich ermöglichte die neue Arbeitsorganisation ""Call Center"" die bisherige Position der Angestellten anzugreifen."
<G-vec00441-001-s291><attack.angreifen><en> In many sectors a 'technical recomposition' has taken place: especially in the banking sector the new work organisation of a call centre made it possible to attack the white collar employees' position.
<G-vec00441-001-s292><attack.angreifen><de> Die Menge wich vor Saljin zurück, trotz der Enge, und keiner machte Anstalten, sie körperlich anzugreifen.
<G-vec00441-001-s292><attack.angreifen><en> The crowd parted in front of Saljin, despite the confinement, and nofurry tried to attack her.
<G-vec00441-001-s293><attack.angreifen><de> "Das Bomberkommando wurde angewiesen, die erwarteten Ziele anzugreifen, um nach ihren eigenen Worten ""Verwirrung bei der Evakuierung aus dem Osten zu stiften"", wobei es sich nicht um zurückziehende Truppen, sondern um diese zivilen Flüchtlinge handelte (und erst in zweiter Linie um ""die Bewegung von Truppen aus dem Westen zu behindern"")."
<G-vec00441-001-s293><attack.angreifen><en> "Bomber Command was ordered to attack their anticipated destinations in order to, in their own words, ""cause confusion in the evacuation from the east,"" referring not to retreating troops, but to these civilian refugees (only secondarily, to ""hamper the movements of troops from the west"")."
<G-vec00441-001-s294><attack.angreifen><de> Wir fahren fort, die Flanken des Monsters anzugreifen, und lassen den Kopf der Biests Tag für Tag an der Macht.
<G-vec00441-001-s294><attack.angreifen><en> We continue to attack the limbs of the monster, and let the heart beat more powerful day after day.
<G-vec00441-001-s295><attack.angreifen><de> Früher bestimmte unsere Untersuchung fast die Zahl und die Ausrüstung der Hitlerangehörigen eines Strafkommandos, versuchend fehlerfrei, uns anzugreifen.
<G-vec00441-001-s295><attack.angreifen><en> Before our investigation almost unmistakably defined quantity and arms of the Hitlerite chasteners trying to attack us.
<G-vec00441-001-s296><attack.angreifen><de> Er sieht sich selbst an der Spitze einer riesigen Armee, Senden Soldaten anzugreifen.
<G-vec00441-001-s296><attack.angreifen><en> He sees himself at the head of a huge army, sending soldiers to attack.
<G-vec00441-001-s297><attack.angreifen><de> """Ich benötige einige Mitglieder der Armee, um sie anzugreifen."
<G-vec00441-001-s297><attack.angreifen><en> """I'll need some members of the army to attack her."
<G-vec00441-001-s298><attack.angreifen><de> Irrtümer zu widerlegen bedeutet nicht, Leute anzugreifen, die von solchen Irrtümern getäuscht wurden, sondern dient dazu, ihnen zu helfen.
<G-vec00441-001-s298><attack.angreifen><en> To refute error is not to attack people who have been deceived by that error, but is for their help.
<G-vec00441-001-s299><attack.angreifen><de> Relativ einfach anzugreifen.
<G-vec00441-001-s299><attack.angreifen><en> Relatively easy to attack.
<G-vec00441-001-s300><attack.angreifen><de> Das Generalkommando der Volksverteidigungseinheiten (YPG) der PYD hat am selben Tag in einer Erklärung angedroht, im Wiederholungsfall die Hubschrauber anzugreifen.
<G-vec00441-001-s300><attack.angreifen><en> In a statement that same day, the General Command of the PYD's People's Defense Units (YPG) threatened to attack the helicopters should this happen again.
<G-vec00441-001-s301><attack.angreifen><de> Dann gingen wir zum Friedhof, um aus der Ferne anzugreifen, auch dort konnten wir nichts tun.
<G-vec00441-001-s301><attack.angreifen><en> Then we went to the cemetery to attack from a distance, we could not do anything there either.
<G-vec00441-001-s302><attack.angreifen><de> Um Orc Ambush spielen, Sie verwenden W,A,S,D-Tasten zu bewegen, Leertaste, um zu springen und klicken Sie links Maustaste, um mit dem Schwert anzugreifen.
<G-vec00441-001-s302><attack.angreifen><en> To play Orc Ambush, you will use W,A,S,D keys to move, SPACE bar to jump and left click mouse button to attack with sword.
<G-vec00441-001-s303><attack.angreifen><de> Dass, die Verfolgung von Falun Gong sogar über China hinaus geht, um weltweit systematisch Gewissen und Gewissensfreiheit der Menschen anzugreifen.
<G-vec00441-001-s303><attack.angreifen><en> Whereas, the persecution of Falun Gong even extends beyond China proper to systematically attack the conscience and moral choice of people around the world.
<G-vec00441-001-s010><assail.angreifen><de> Meine Augenbrauen werden nicht weg rasiert, und kein schlechter Defekt greift mich an.
<G-vec00441-001-s010><assail.angreifen><en> My eyebrows shall not be shaved away, and no evil defect shall assail me.
<G-vec00251-002-s085><deter.angreifen><de> Die entsandten Soldaten müssten in die Lage versetzt werden, den Angriffen bewaffneter Gruppen wirksamer zu begegnen.
<G-vec00251-002-s085><deter.angreifen><en> Deployed soldiers must be enabled to overwhelm and deter armed groups more effectively.
<G-vec00441-002-s037><ambush.angreifen><de> In den Tunneln wird man von Soldaten der Enklave angegriffen, die auf scheinbar unerreichbaren Stegen laufen.
<G-vec00441-002-s037><ambush.angreifen><en> Notes Edit In the tunnels, Enclave soldiers will ambush the player character from apparently inaccessible catwalks.
<G-vec00441-002-s002><assail.angreifen><de> Bis Meine letzte Stunde da ist, wird niemand wagen, Mich anzugreifen, niemand kann den Plan des Allmächtigen vereiteln.
<G-vec00441-002-s002><assail.angreifen><en> Until My last hour is at hand, none dare assail Me, none can frustrate the plan of the Almighty. And when
<G-vec00441-002-s095><attack.angreifen><de> Aktiviere nur, wenn ein Monster, das du kontrollierst, deinen Gegner direkt angreift.
<G-vec00441-002-s095><attack.angreifen><en> Activate only when a monster you control inflicts Battle Damage to your opponent by a direct attack.
<G-vec00441-002-s096><attack.angreifen><de> Falle / Normal Aktiviere diese Karte nur, wenn ein Monster deines Gegners direkt angreift, solange du 5 oder mehr "Schwarzflügel"-Monster in deinem Friedhof hast.
<G-vec00441-002-s096><attack.angreifen><en> Trap / Normal Activate only when your opponent's monster declares a direct attack while you have 5 or more "Blackwing" monsters in your Graveyard.
<G-vec00441-002-s097><attack.angreifen><de> Ziehe eine Einheit auf ein Geländefeld, damit sie sich fortbewegt und angreift.
<G-vec00441-002-s097><attack.angreifen><en> Dragging a unit to a tile will move and attack.
<G-vec00441-002-s098><attack.angreifen><de> Es ist notwendig, daß wir wissen, wie man den modernen bürgerlichen Staat angreift, der sich im bewaffneten Kampf noch wirksamer verteidigt, als sich die zaristische Autokratie zu verteidigen wußte, der sich aber außerdem noch verteidigt mit Hilfe der ideologischen Mobilisierung und defätistischen Erziehung der Arbeiterklasse durch die Bourgeoisie.
<G-vec00441-002-s098><attack.angreifen><en> For us it is essential to know how to attack a modern, democratic bourgeois State which on the one hand has all the resources to corrupt and mislead the proletariat and which on the other hand is even more efficient on the field of armed struggle than the Tsarist autocracy.
<G-vec00441-002-s099><attack.angreifen><de> Warum der Körper seine eigenen Acetylcholinrezeptoren angreift – eine Autoimmunreaktion –, weiß man nicht.
<G-vec00441-002-s099><attack.angreifen><en> What causes the body to attack its own acetylcholine receptors—an autoimmune reaction—is unknown.
<G-vec00441-002-s101><attack.angreifen><de> „Wer so absolut dämlich ist und sie angreift, greift das Haus Malfoy an!“, hauchte er samtig und blicke drohend in die ungläubige Menge.
<G-vec00441-002-s101><attack.angreifen><en> "If anyone is so absolutely stupid to attack her, they will attack the house of Malfoy!" he breathed velvety and looked threateningly into the disbelieving crowd.
<G-vec00441-002-s102><attack.angreifen><de> Es wird berichtet, dass es angreift, indem es einen Teil des Nackens am Schädel zerbricht oder das Opfer stranguliert.
<G-vec00441-002-s102><attack.angreifen><en> Object is reported to attack by snapping the neck at the base of the skull, or by strangulation.
<G-vec00441-002-s103><attack.angreifen><de> Mobbing ist eine Strategie gegen Prädatoren, die durch ein oder mehrere Angehörige einer Beuteart initiiert wird, mit dem Ziel, einen Prädator zu vertreiben, der selbst nicht angreift.
<G-vec00441-002-s103><attack.angreifen><en> Abstract Mobbing is an anti-predator strategy initiated by one or more members of prey species aiming at driving away a predator that is not undertaking an attack.
<G-vec00441-002-s104><attack.angreifen><de> Ein Nachteil ist, dass dieser Truppen innerhalb von 4 Kacheln von sich selbst aus (oder Lufttruppen überhaupt) nicht angreift - so sollte dieser in der Mitte des Dorfes mit ausreichendem Schutz vor Luftverteidigungen platziert werden.
<G-vec00441-002-s104><attack.angreifen><en> A downside is that it can't attack troops within four tiles of itself (or air troops at all) - so it should be placed in the center of your village with adequate protection from Air Defenses.
<G-vec00441-002-s105><attack.angreifen><de> Während wir das Immunsystem in der Onkologie unterstützen wollen, damit es Tumoren angreift, muss es bei immunologischen Erkrankungen gedrosselt werden, weil es fälschlicherweise Schäden in gesundem Gewebe verursacht.
<G-vec00441-002-s105><attack.angreifen><en> In oncology, we want to turn up the immune system to attack tumours, while for immunological diseases, we want to turn it down because it’s doing damage by attacking normal tissue inappropriately.
<G-vec00441-002-s106><attack.angreifen><de> Elite-Vargo: Speersoldat - Ein Vargodämon, der genau auf die gleiche Art angreift, wie Erzvargo-Palastwache.
<G-vec00441-002-s106><attack.angreifen><en> Lesser Glitter Guard - A Glitter demon that will attack in the exact same way as Glitter Guard.
<G-vec00441-002-s107><attack.angreifen><de> KP80 Anziehung Falls das Verteidigende Pokémon während des nächsten Zuges deines Gegners angreift, wirft dein Gegner 1 Münze.
<G-vec00441-002-s107><attack.angreifen><en> Choose 1 of the Defending Pokémon's attacks. That Pokémon can't use that attack during your opponent's next turn.
<G-vec00441-002-s108><attack.angreifen><de> Wenn ein Mob den Spieler angreift, wird der Wolf reagieren und seinen Besitzer verteidigen, indem er den Mob angreift, selbst wenn ihm gesagt worden ist, sich hinzusetzen.
<G-vec00441-002-s108><attack.angreifen><en> If a hostile mob (besides a creeper) attacks a player, the wolf will react and attack the mob to defend the player, even if the wolf was told to sit.
<G-vec00441-002-s109><attack.angreifen><de> Die folgenden Artikel bringen starken Verdacht zum Ausdruck, warum der ISIS Israel nicht angreift – wir wissen schon warum.
<G-vec00441-002-s109><attack.angreifen><en> The following articles have strong suspicions why ISIS does not attack Israel – we already know why.
<G-vec00441-002-s110><attack.angreifen><de> Antiker Golem-Beschützer - Ein antiker Roboter, der genau auf die gleiche Art angreift, wie Lyrischer Nasodwächter.
<G-vec00441-002-s110><attack.angreifen><en> Ancient Golem Guardian - An ancient robot that will attack in the exact same way as Ancient Nasod Sentinel.
<G-vec00441-002-s111><attack.angreifen><de> Sie mussten verstehen – und gerade aus bitterer Erfahrung lernt die revolutionäre Klasse das zu verstehen – daß der Sieg unmöglich ist, wenn man nicht gelernt hat, wie man richtig angreift und zurückzieht.
<G-vec00441-002-s111><attack.angreifen><en> They had to realise – and it is from bitter experience that the revolutionary class learns to realise this – that victory is impossible unless one has learned how to attack and retreat properly.
<G-vec00441-002-s112><attack.angreifen><de> Pendeleffekt (Blau 1/Rot 1): Falls ein Pendelmonster, das du kontrollierst, angreift oder angegriffen wird, kann dein Gegner bis zum Ende des Damage Steps keine Zauberkarten aktivieren.
<G-vec00441-002-s112><attack.angreifen><en> Pendulum Effect (Red 1/Blue 1): If a Pendulum Monster you control attack or is attacked, your opponent cannot activate Spell Cards until the end of the Damage Step.
<G-vec00441-002-s113><attack.angreifen><de> Die Wirkung von Grapefruit Samenextrakt ist primär darauf zurückführbar, dass es die Zellwände von Bakterien und Pilzen angreift und diese so zerstört und abtötet.
<G-vec00441-002-s113><attack.angreifen><en> The effects of grapefruit seed extract are due to the fact that it can attack the cell walls of bacteria and fungi and thus destroy and kill them.
<G-vec00595-002-s022><liberate.angreifen><de> Wer sich erfolgreich verändern und weiterentwickeln will, muss bereit sein, Konventionen anzugreifen und Altbewährtes über Bord zu werfen.
<G-vec00595-002-s022><liberate.angreifen><en> Enterprises that want to change and develop successfully need to be willing to liberate themselves from conventions and to discard solutions that have ceased to be effective.
