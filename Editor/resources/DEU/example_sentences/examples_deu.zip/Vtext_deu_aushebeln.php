<G-vec00389-002-s023><thwart.aushebeln><de> All dies hilft, die derzeit weitverbreitete Verschwendung zu verlangsamen oder auszuhebeln.
<G-vec00389-002-s023><thwart.aushebeln><en> All this scaled up helps to slow down or thwart the current widespread waste.
