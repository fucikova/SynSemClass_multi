<G-vec00389-002-s023><thwart.aushebeln><de> All dies hilft, die derzeit weitverbreitete Verschwendung zu verlangsamen oder auszuhebeln.
<G-vec00389-002-s023><thwart.aushebeln><en> All this scaled up helps to slow down or thwart the current widespread waste.
<G-vec00785-002-s021><undermine.aushebeln><de> Seid immer vorbereitet, physisch und materiell, allein schon deswegen weil ihr nicht wisst, wann Mutter Natur abgesehen von jeglichen anderen Umständen eure bequemen Leben aushebeln wird.
<G-vec00785-002-s021><undermine.aushebeln><en> Be prepared always, physically and materially, just for these reasons alone, you do not know when Mother Nature, let alone any other circumstances will undermine your comfortable lives.
<G-vec00785-002-s028><undermine.aushebeln><de> Mit der Reform des Stabilitätspakts ist es deutlich schwieriger geworden, die Defizitregeln auszuhebeln.
<G-vec00785-002-s028><undermine.aushebeln><en> The reform of the Stability and Growth Pact has made it much harder to undermine the deficit rules.
