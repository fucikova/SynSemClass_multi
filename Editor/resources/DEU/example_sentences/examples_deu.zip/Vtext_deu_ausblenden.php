<G-vec00279-003-s020><drown_out.ausblenden><de> Diese Lichtschaustellungen sind sichtbar für den Menschen, wo der Glanz des Sonnenlichtes sie nicht ausblendet, da das Auge die überwältigende Teilchennatur der Lichtflut bemerkt, die unwesentliche Teilchen ablegt, die bei so viel Verzerrung anwesend sein könnten.
<G-vec00279-003-s020><drown_out.ausblenden><en> These light displays are visible to humans where the glare of sunlight does not drown them out, as the eye registers the overwhelming particle nature of the light flood, discarding minor particles that might be present as so much noise.
<G-vec00460-002-s030><disregard.ausblenden><de> Sie eignet sich für Anleger, die einen langfristigen Horizont von mehr als fünf Jahren haben und bereit sind, kurzfristige Marktschwankungen auszublenden.
<G-vec00460-002-s030><disregard.ausblenden><en> It is suitable for investors with a long investment horizon, exceeding five years, and a willingness to disregard short-term market fluctuations.
<G-vec00514-002-s115><hide.ausblenden><de> Zusätzlich ist es nun möglich Produkte ein- und auszublenden.
<G-vec00514-002-s115><hide.ausblenden><en> In addition, it is now possible to show and hide products.
<G-vec00514-002-s116><hide.ausblenden><de> Um die Bedienoberfläche des Effekt Plug-ins ein- und auszublenden, klicken Sie auf den Namen des Effekts in der Audio-Insert-Effekte Leiste.
<G-vec00514-002-s116><hide.ausblenden><en> To show or hide the effect plug-in's GUI, click on its name in the Audio Inserts rack once.
<G-vec00514-002-s117><hide.ausblenden><de> Klicken Sie auf Gitternetzlinien anzeigen, um die Gitterlinien der Tabelle ein- oder auszublenden.
<G-vec00514-002-s117><hide.ausblenden><en> Click Show Grid Lines to show or hide table grid lines.
<G-vec00514-002-s118><hide.ausblenden><de> Um den Bereich manuell ein- oder auszublenden, klicken Sie in der Aufgabenleiste auf das Symbol „Fotobereich“.
<G-vec00514-002-s118><hide.ausblenden><en> To manually show or hide the bin, click the Photo Bin taskbar icon.
<G-vec00514-002-s119><hide.ausblenden><de> Klicken Sie auf das Erweiterungssymbol (>) auf der linken Seite, um die Inhaltsebenen ein- oder auszublenden.
<G-vec00514-002-s119><hide.ausblenden><en> Click the expander icon (>) on the left side to show or hide the content levels as needed.
<G-vec00514-002-s120><hide.ausblenden><de> Lassen Sie das Feld leer, um alle Kategorien ein- oder auszublenden.
<G-vec00514-002-s120><hide.ausblenden><en> Leave blank to show or hide all categories. Remarks
<G-vec00514-002-s121><hide.ausblenden><de> Klicken Sie auf die Erweitern/Reduzieren-Symbole links von der Klasse, um Eigenschaften und Operationen ein- oder auszublenden.
<G-vec00514-002-s121><hide.ausblenden><en> Click the collapse/expand icons to the left of the class to show or hide properties and operations.
<G-vec00514-002-s122><hide.ausblenden><de> „Schrift“ > „Alter Text“ > „Kopien einblenden“ oder „Kopien ausblenden“, um die kopierten Textobjekte ein- oder auszublenden.
<G-vec00514-002-s122><hide.ausblenden><en> Type > Legacy Text > Show Copies or Hide Copies to show or hide the copied text objects.
<G-vec00514-002-s123><hide.ausblenden><de> Verwenden Sie zum Ändern der in Ihrem Diagramm angezeigten Daten Diagrammfilter, um Datenreihen ein- oder auszublenden.
<G-vec00514-002-s123><hide.ausblenden><en> To change the data that’s shown in your chart, use chart filters to show or hide data series.
<G-vec00514-002-s124><hide.ausblenden><de> Der Befehl Raster gibt Ihnen die Möglichkeit, die Rasterlinien ein- und auszublenden.
<G-vec00514-002-s124><hide.ausblenden><en> The Grid command allows you to show or hide the grid.
<G-vec00514-002-s125><hide.ausblenden><de> Bitte folgen Sie den Anweisungen unten, um die Liste der Moderatoren unten auf der Seite einer Kategorie ein- oder auszublenden.
<G-vec00514-002-s125><hide.ausblenden><en> Please follow the directions mentioned below to show or hide the list of moderators at the bottom of a category's page.
<G-vec00514-002-s126><hide.ausblenden><de> Um eine Symbolleiste ein- oder auszublenden, wählen Sie Ansicht > Symbolleisten aus, und aktivieren oder deaktivieren Sie dann die betreffende Symbolleiste.
<G-vec00514-002-s126><hide.ausblenden><en> To show or hide a toolbar, choose View > Toolbars, then select or deselect the toolbar.
<G-vec00514-002-s127><hide.ausblenden><de> Regionen können erweitert und reduziert werden, um Teile von SQL Skripts ein- oder auszublenden.
<G-vec00514-002-s127><hide.ausblenden><en> Regions can be collapsed and expanded to display or hide parts of SQL scripts.
<G-vec00514-002-s128><hide.ausblenden><de> Klicken Sie im Menü Ansicht auf Lineale, um die Lineale ein- oder auszublenden.
<G-vec00514-002-s128><hide.ausblenden><en> On the View menu, click Rulers to show or hide the rulers.
<G-vec00555-002-s060><dismiss.ausblenden><de> Die Mitteilungen werden für einen kurzen Moment oben rechts auf dem Bildschirm eingeblendet oder sie bleiben dort, bis du sie ausblendest.
<G-vec00555-002-s060><dismiss.ausblenden><en> Notifications appear briefly in the top-right corner of the screen or stay there until you dismiss them.
<G-vec00597-002-s025><collapse.ausblenden><de> Tipp: Auf dem Desktop kannst du jedes Bild ausblenden, indem du auf den Abwärtspfeil neben dem Bildtitel klickst oder den Slash-Befehl /collapse eingibst, damit alle Medien in einem Channel ausgeblendet werden.
<G-vec00597-002-s025><collapse.ausblenden><en> Tip: On desktop, you can collapse any image by clicking the down arrow next to the image title, or type the /collapse slash command to collapse all media in a channel. Awesome!
<G-vec00597-002-s026><collapse.ausblenden><de> Sie können jetzt Code ausblenden, indem Sie mit der Maus auf die Zeilennummer zeigen und auf das angezeigte Dreieck klicken.
<G-vec00597-002-s026><collapse.ausblenden><en> You can now collapse code by hovering your mouse over the line number and clicking the triangle that appears.
<G-vec00597-002-s027><collapse.ausblenden><de> Benutzer können Kategorien mit vielen Unterkategorien nach Bedarf ein- und ausblenden.
<G-vec00597-002-s027><collapse.ausblenden><en> Users can also expand and collapse categories which contain many subcategories.
<G-vec00597-002-s028><collapse.ausblenden><de> Zum Ausblenden aller Profilgruppen im Profil-Browser klicken Sie mit der rechten Maustaste (Windows) oder bei gedrückter Ctrl-Taste (Mac) auf eine beliebige Profilgruppe und wählen Sie Alle minimieren im Menü aus.
<G-vec00597-002-s028><collapse.ausblenden><en> To collapse all the profile groups in Profile Browser, right-click (Win) / Control-click (Mac) any profile group and choose Collapse All from the menu.
<G-vec00597-002-s029><collapse.ausblenden><de> Wenn Sie den Timer ausblenden, sehen Sie die Farbänderung nicht.
<G-vec00597-002-s029><collapse.ausblenden><en> If you collapse the timer, you won't see the color changes.
