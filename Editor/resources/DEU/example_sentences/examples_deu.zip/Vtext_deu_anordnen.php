<G-vec00178-001-s019><arrange.anordnen><de> Als Vermittler für das anordnen einer Heirat, einer Affäre oder einem Treffen zwischen einem Mann und einer nicht verheirateten Frau, zu handeln, ist ein Saṅghādisesa-Vergehen.
<G-vec00178-001-s019><arrange.anordnen><en> Acting as a go-between to arrange a marriage, an affair, or a date between a man and a woman not married to each other is a saṅghādisesa offense.
<G-vec00178-001-s020><arrange.anordnen><de> Siehe Contextual Tab „Entwurf“ und „Anordnen“ in „Formularentwurftools“ wenn ein Formular in der Entwurfsansicht geöffnet wurde.
<G-vec00178-001-s020><arrange.anordnen><en> See Contextual Tab “Design” and “Arrange” in “Form Design Tools” when opening a form in design mode.
<G-vec00178-001-s021><arrange.anordnen><de> Schicht Zement-Sand-Estrich anordnen müsseneine Dicke von nicht weniger als 45 mm.
<G-vec00178-001-s021><arrange.anordnen><en> Layer Arrange cement-sand screed musthave a thickness of not less than 45 mm.
<G-vec00178-001-s022><arrange.anordnen><de> Sie können Aufträge so anordnen, dass sie nach dem Drucken möglichst wenig gerade horizontal oder vertikal geschnitten werden können.
<G-vec00178-001-s022><arrange.anordnen><en> You can arrange jobs so that, after printing, they can be cut out using as few straight horizontal or vertical cuts as possible.
<G-vec00178-001-s023><arrange.anordnen><de> Die Konzentration auf den Eigentümer der Immobilie, Sie können gegen Kaution auf zwei Arten anordnen.
<G-vec00178-001-s023><arrange.anordnen><en> Focusing on the owner of the property, You can arrange bail in two ways.
<G-vec00178-001-s024><arrange.anordnen><de> Das Serviettenmotiv auf dem jeweiligen Stein anordnen und mit Serviettenlack fixieren.
<G-vec00178-001-s024><arrange.anordnen><en> Arrange the chosen napkin motif onto the respective rock and affix it with napkin varnish.
<G-vec00178-001-s025><arrange.anordnen><de> Service-Website eine berufliche Tätigkeit anordnen können, auch während Ihrer Pensionierung mit Ihren Fähigkeiten und bisherigen Erfahrungen der Arbeitgeber überall um dich herum.
<G-vec00178-001-s025><arrange.anordnen><en> Service Web site can arrange an occupation, even during your retirement offering your skills and previous experience employers everywhere around you.
<G-vec00178-001-s026><arrange.anordnen><de> Dank der speziellen Separatoren von Ikea, auch die einfache Box Sie so wie Sie es brauchen anordnen können.
<G-vec00178-001-s026><arrange.anordnen><en> Thanks to special separators from Ikea, even the most simple box you can arrange just as you need it.
<G-vec00178-001-s027><arrange.anordnen><de> "Das Testen kann ebenso mit folgender Technik einfacher gestaltet werden: Man zeigt der Person ""ich würde die Farben in dieser Reihenfolge anordnen"" und platziert die Steine, einen nach dem anderen, in der richtigen Reihenfolge."
<G-vec00178-001-s027><arrange.anordnen><en> Testing can also be made easier by using the following technique: Show the person that 'I would arrange these colours in this order' and place the caps one after the other in the correct order.
<G-vec00178-001-s028><arrange.anordnen><de> Instrumente und Dokumente werden in das Verfahren eingeführt werden, indem sie an den Generalsekretär übertragen, wer soll das Original für die Dateien des Zentrums behalten und für eine angemessene Verteilung von Kopien anordnen.
<G-vec00178-001-s028><arrange.anordnen><en> Instruments and documents shall be introduced into the proceeding by transmitting them to the Secretary-General, who shall retain the original for the files of the Centre and arrange for appropriate distribution of copies.
<G-vec00178-001-s029><arrange.anordnen><de> Zum Aktivieren, Anordnen oder Schließen von Fenstern im Arbeitsbereich dienen die Befehle im Untermenü Fenster.
<G-vec00178-001-s029><arrange.anordnen><en> The commands in the Windows submenu serve to activate, arrange or close windows in the working area.
<G-vec00178-001-s030><arrange.anordnen><de> "Ein Objekt auswählen, das mit anderen Objekten gruppiert ist: Klicken Sie zweimal langsam auf das Objekt oder heben Sie zuerst die Gruppierung der Objekte auf (wählen Sie ""Anordnen"" > ""Gruppierung aufheben"")."
<G-vec00178-001-s030><arrange.anordnen><en> This does not select inline objects. Select an object that's grouped with other objects: Click the object twice slowly, or first ungroup the objects (choose Arrange > Ungroup).
<G-vec00178-001-s031><arrange.anordnen><de> Um mehrere Arbeitsblätter gleichzeitig anzuzeigen, müssen Sie dieses Arbeitsblatt in neuen Arbeitsmappen öffnen und sie dann nach Bedarf anordnen.
<G-vec00178-001-s031><arrange.anordnen><en> To view more worksheets at the same time, you need to open theses worksheet in new workbooks, and then arrange them as you need.
<G-vec00178-001-s032><arrange.anordnen><de> Auf einem Servierteller anordnen und servieren.
<G-vec00178-001-s032><arrange.anordnen><en> Arrange on a serving dish and serve.
<G-vec00178-001-s033><arrange.anordnen><de> Dank eines komplett überarbeiteten Tool Flows mit noch intuitiverer Benutzeroberfläche lassen sich mithilfe von parallelen Strängen und Schaltflächen Werkzeuge und Elemente einfach anordnen und handhaben.
<G-vec00178-001-s033><arrange.anordnen><en> Thanks to a completely redesigned tool flow with an even more intuitive user interface, users can easily arrange and handle tools and elements with the aid of parallel strands and buttons.
<G-vec00178-001-s034><arrange.anordnen><de> Vor ungefähr 50 Jahren fand der theoretische Physiker Tony Skyrme zu seiner Überraschung in quantenmechanischen Feldtheorien stabile und lokalisierte Konfigurationen, die miteinander wechselwirken und sich wie Atome auf einem Gitter anordnen können.
<G-vec00178-001-s034><arrange.anordnen><en> About 50 years ago the theoretical physicist, Tony Skyrme, studied quantum mechanical field theories and to his surprise found stabile and localized configurations that interact with each other and can arrange themselves in a lattice in the same way as atoms.
<G-vec00178-001-s035><arrange.anordnen><de> Eglint Thema macht es wirklich einfach, Ihre Widgets in Reihen der Spalten anordnen.
<G-vec00178-001-s035><arrange.anordnen><en> Eglint Theme makes it really easy to arrange your widgets in rows of columns.
<G-vec00178-001-s036><arrange.anordnen><de> Linie einfach, robust, geeignet für den Wohnbereich für die Küche, sie in verschiedenen Ausführungen anordnen.
<G-vec00178-001-s036><arrange.anordnen><en> line simple, robust, suitable for the living room area for the kitchen, Arrange them in various finishes.
<G-vec00178-001-s037><arrange.anordnen><de> Spring Vibrationsbehälter Feeder Diese Feder Vibrationsschüssel Feeder automatisch anordnen, wählen Sie die Richtung durch Vibrationsschüssel, es ist anwendbar, um eine große Anzahl von kleinen Spiralfedern, die miteinander verwickelt werden, zu trennen und durch Zentrifugalvibration, Trennrate über 95% getrennt...
<G-vec00178-001-s037><arrange.anordnen><en> Spring Vibratory Bowl Feeder This Spring Vibratory Bowl Feeder automatically arrange select direction through vibratory bowl it is applicable to separate a large number of small spiral springs which will be entangled together and are separated by centrifugal vibration separation rate over 95 1 Machine Parameters...
<G-vec00178-001-s051><arrange.anordnen><de> Das Programm unterstützt Bilder, Texte in RTF, sowie Kreistexte und bietet Euch die Möglichkeit Objekte anzuordnen und die ihre Größe, Winkel und Transparenz anzupassen.
<G-vec00178-001-s051><arrange.anordnen><en> It supports images, RTF texts, circled texts and shapes allowing you to arrange, change size, angle and transparency of objects.
<G-vec00178-001-s052><arrange.anordnen><de> Außerdem, wenn die Abmessungen Nische ermöglichen, dann ist es möglich, den Tank anzuordnen.
<G-vec00178-001-s052><arrange.anordnen><en> Moreover, if the dimensions allow niche, then it is possible to arrange the tank.
<G-vec00178-001-s053><arrange.anordnen><de> Oberhalb der Brennkammer ist eine Rauchkammer anzuordnen, Kammer Leiste zwischen dem Rauch und Feuerungen zu feuern.
<G-vec00178-001-s053><arrange.anordnen><en> Above the combustion chamber is to arrange a smoke chamber, firing chamber between the flue and firebox ledge.
<G-vec00178-001-s054><arrange.anordnen><de> In diesem Fall ist es nicht nur notwendig, Arbeiten auf der entsprechenden Ebene durchzuführen, sondern es ist besser, alles auf höchster Ebene anzuordnen.
<G-vec00178-001-s054><arrange.anordnen><en> In this case, it is necessary not just to perform work at the appropriate level, and it is better to arrange everything at the highest level.
<G-vec00178-001-s055><arrange.anordnen><de> "Auf diesen Bildschirmen wird – technisch bedingt – Information in Pixeln dargestellt: in Form von guten Nachrichten, schlechten Nachrichten, unnützen Nachrichten, usw.... Pixel nun aus diesem Kontext zu ""befreien"", in beliebigen Motiven anzuordnen und in ein neues Umfeld (Ihre Wohnzimmerwand) zu verfrachten, wo sie ""neutral"" sind, also völlig Ihrer Funktion (der Information) beraubt, lässt uns beim Betrachten dieser jetzt ""Sinn-losen"" Pixel den Umgang mit unseren Medien kritisch überdenken."
<G-vec00178-001-s055><arrange.anordnen><en> Information is presented on these screens in pixels – in the form of good news, bads news, useless news etc.... to 'liberate' pixels from within this context and arrange them in popular motifs in a new surrounding (your living room wall) where they are 'neutral', completely robbed of their function of conveying information, allows us to view this now 'Sense-less' pixel .
<G-vec00178-001-s056><arrange.anordnen><de> Jetzt ist sie verlässt sich auf Sie, um alle Möbel in der richtigen Reihenfolge anzuordnen.
<G-vec00178-001-s056><arrange.anordnen><en> Now she relies on you to arrange all the furniture items in the right order.
<G-vec00178-001-s057><arrange.anordnen><de> Es ist möglich, sie automatisch anzuordnen über den Befehl Global Spread and Place aus dem Kontextmenü (rechte Maustaste; nur verfügbar wenn Mode footprint in der Hauptwerkzeugleiste aktiviert wurde).
<G-vec00178-001-s057><arrange.anordnen><en> It is possible to arrange them automatically (using the command Global Spread and Place accessed via the right mouse button).
<G-vec00178-001-s058><arrange.anordnen><de> Die Upanischaden, so mächtig sie sind, streben nur danach, mit dem höchsten Namen des Brahman das ewige Wissen, das in den Veden als Heiligtum bewahrt ist, zu krönen, es hervorzubringen und philosophisch in der Sprache des späteren Denkens anzuordnen.
<G-vec00178-001-s058><arrange.anordnen><en> The Upanishads, mighty as they are, only aspire to bring out, arrange philosophically in the language of later thinking and crown with the supreme name of Brahman the eternal knowledge enshrined in the Vedas.
<G-vec00178-001-s059><arrange.anordnen><de> Viele freie Radikale sind hoch reaktiv, d. h. sie haben die starke Tendenz, sich paarweise anzuordnen und somit aus dem labilen ungepaarten Zustand herauszukommen.
<G-vec00178-001-s059><arrange.anordnen><en> Many free radicals are highly reactive, meaning that they have a strong tendency to arrange in pairs and, thus, escape the instable unpaired condition.
<G-vec00178-001-s060><arrange.anordnen><de> Da sich alle diese Dinge meistens nur nach Voraussetzungen bestimmen lassen, die nicht alle zutreffen, eine Menge anderer, mehr ins einzelne gehender Bestimmungen sich aber gar nicht vorher geben lassen, so folgt von selbst, daß die Strategie mit ins Feld ziehen muss, um das Einzelne an Ort und Stelle anzuordnen und für das Ganze die Modifikationen zu treffen, die unaufhörlich erforderlich werden.
<G-vec00178-001-s060><arrange.anordnen><en> As these are all things which to a great extent can only be determined on conjectures, some of which turn out incorrect, while a number of other arrangements pertaining to details cannot be made at all beforehand, it follows, as a matter of course, that strategy must go with the army to the field in order to arrange particulars on the spot, and to make the modifications in the general plan which incessantly become necessary in war.
<G-vec00178-001-s061><arrange.anordnen><de> Baustufe im Interesse kurzer Verbindungswege kompakt und in zentraler Lage zwischen en Start- und Landebahnen anzuordnen.
<G-vec00178-001-s061><arrange.anordnen><en> Stage in the interest of short routes of connecting compact and is centrally located between en start- and runways to arrange.
<G-vec00178-001-s062><arrange.anordnen><de> In Fällen, in denen es erforderlich ist, einen kontinuierlichen Kreislauf anzuordnen, ist der Schraubenkompressor zu wählen, bevorzugt.
<G-vec00178-001-s062><arrange.anordnen><en> In cases where it is necessary to arrange a continuous cycle, the screw compressor is preferable to choose.
<G-vec00178-001-s063><arrange.anordnen><de> Es gibt verschiedene Optionen für die Anzeige der verlorene fotos wiederherstellen mac in einem bestimmten Format zur Verfügung gestellt; Datenansicht und Dateityp Ansicht sind die beliebtesten mit deren Hilfe der Benutzer die Dateien in einer entsprechenden Reihenfolge anzuordnen.
<G-vec00178-001-s063><arrange.anordnen><en> There are different options provided for viewing the restored photos in a particular format; Data View and File Type View are the most popular ones using which the user can arrange the files in a respective order.
<G-vec00178-001-s064><arrange.anordnen><de> Es ist notwendig, die Einheiten so anzuordnen, dass sie effektiv mit anderen nicht stören funktionieren kann, für die Wartung zugänglich zu sein, und sind so nahe wie möglich beieinander angeordnet.
<G-vec00178-001-s064><arrange.anordnen><en> It is necessary to arrange the units so that they can function effectively not interfere with others, to be accessible for maintenance and are located as close as possible to each other.
<G-vec00178-001-s065><arrange.anordnen><de> Das Ziel dieser Miniclip ist sehr einfach: Sie müssen die Tiere so anzuordnen, dass drei Tiere der gleichen Art neben einigen anderen positioniert werden.
<G-vec00178-001-s065><arrange.anordnen><en> The aim of this miniclip is extremely simple: you must arrange the animals so that 3 animals of the same kind to be positioned next to some others.
<G-vec00178-001-s066><arrange.anordnen><de> Ist ein Filter an der Stelle ein Graben ist, kann das Ablaufrohr, um es geroutet werden, und es besteht keine Notwendigkeit, den Vorratsbehälter anzuordnen.
<G-vec00178-001-s066><arrange.anordnen><en> If there is a filter at the site a ditch, the drain pipe can be routed to it, and there is no need to arrange the storage tank.
<G-vec00178-001-s067><arrange.anordnen><de> Wir verbrachten daher noch eine gute Stunde auf dem Wege bis zur Herberge, und so hatten die Besitzer derselben Zeit, bis zu unserer Ankunft das Nötigste anzuordnen und vorzubereiten.
<G-vec00178-001-s067><arrange.anordnen><en> Therefore, we still were largely 1 hour on our way to the inn so that their owners had enough time to arrange and prepare the most necessary things for our arrival.
<G-vec00178-001-s068><arrange.anordnen><de> Layoutblöcke werden typischerweise verwendet, um verschiedene Teile einer Zeichnung auf einem Blatt Papier zum Drucken anzuordnen.
<G-vec00178-001-s068><arrange.anordnen><en> Layout blocks are typically used to arrange different parts of a drawing on a sheet of paper for printing.
<G-vec00178-001-s069><arrange.anordnen><de> WICHTIG: Sie haben die Möglichkeit, jedes Element des Aufklebers so anzuordnen, wie Sie möchten.
<G-vec00178-001-s069><arrange.anordnen><en> IMPORTANT: You have the option to arrange each element of the sticker the way you want.
<G-vec00502-002-s038><arrange.anordnen><de> Sie können dich anordnen, oder wir können helfen anzuordnen.
<G-vec00502-002-s038><arrange.anordnen><en> You can arrange yourself or we can help to arrange.
<G-vec00502-002-s039><arrange.anordnen><de> Verwenden Sie PowerPoint Online mit Ihrer Tastatur und der in Windows integrierten Sprachausgabe, um Folien zu Ihren Präsentationen hinzuzufügen, daraus zu löschen und darin anzuordnen.
<G-vec00502-002-s039><arrange.anordnen><en> Use PowerPoint Online with your keyboard and Narrator, the built-in Windows screen reader, to add, delete, and arrange your slides in your presentations.
<G-vec00502-002-s040><arrange.anordnen><de> Es ist möglich, solche Winkel mit Hilfsleuchten, die separat eingeschaltet sind, anzuordnen.
<G-vec00502-002-s040><arrange.anordnen><en> It is possible to arrange such angles with auxiliary illuminators, which are switched on separately.
<G-vec00502-002-s041><arrange.anordnen><de> In der gleichen Reihe mit einem schneeweißen Hintergrund ist es möglich, helle Fototapeten oder Bilder anzuordnen.
<G-vec00502-002-s041><arrange.anordnen><en> In the same row with a snow-white background, it is possible to arrange bright photo wallpapers or pictures.
<G-vec00502-002-s042><arrange.anordnen><de> Wählen Sie diese Option aus, um Shapes in Zeilen und Spalten auf der Seite anzuordnen, die in der Liste über wachte Zeichenblätter ausgewählt ist.
<G-vec00502-002-s042><arrange.anordnen><en> Select to arrange shapes in rows and columns on the page selected in the Monitored drawing pages list.
<G-vec00502-002-s043><arrange.anordnen><de> Sie lassen den Raum viel geräumiger erscheinen als er tatsächlich ist, und gleichzeitig ist es bequem, eine große Anzahl von Objekten anzuordnen.
<G-vec00502-002-s043><arrange.anordnen><en> They make the room look much more spacious than it actually is, and at the same time it is convenient to arrange a large number of objects.
<G-vec00502-002-s044><arrange.anordnen><de> Manche Grower bevorzugen es, ihre Pflanzen in gestaffelten Reihen um eine zentrale Lichtquelle anzuordnen.
<G-vec00502-002-s044><arrange.anordnen><en> Some growers prefer to arrange plants in tiered rows around a central light source.
<G-vec00502-002-s045><arrange.anordnen><de> Bei einer weiteren vorteilhaften Ausgestaltung der Erfindung sind die thermischen Pfade senkrecht zu den Schichten der LED-Leiterplatte Insbesondere ist es bevorzugt das Wärmeleitelement unterhalb der LEDs anzuordnen, um auf dem kürzesten Weg, also senkrecht nach unten zur Unterseite der LED-Leiterplatte, die Wärme ableiten zu können.
<G-vec00502-002-s045><arrange.anordnen><en> This enables a simple production of the LED circuit board. In particular, it is preferable to arrange the heat conducting element below the LEDs to the shortest route, that is straight down to the bottom of the LED circuit board, to be able to dissipate the heat.
<G-vec00502-002-s046><arrange.anordnen><de> Wenn Sie wirklich daran gedacht haben, Ihr Grundstück radikal zu verändern und nicht ein oder zwei Betten anzuordnen, müssen Sie mit einem durchdachten Plan beginnen.
<G-vec00502-002-s046><arrange.anordnen><en> If you really conceived to radically change your plot, and not to arrange one or two beds, then you need to start with a well-thought-out plan.
<G-vec00502-002-s047><arrange.anordnen><de> Der Eckkamin befindet sich nicht weniger als der Platz, aber seine Anordnung erlaubt, ihn in ziemlich bescheidenen Voraussetzungen anzuordnen.
<G-vec00502-002-s047><arrange.anordnen><en> The corner fireplace occupies not less than the square, but its arrangement allows to arrange it in rather modest premises.
<G-vec00502-002-s048><arrange.anordnen><de> Um die besten Ergebnisse zu erzielen, ist die Speise in runder Form anzuordnen.
<G-vec00502-002-s048><arrange.anordnen><en> Measure the amount of food in order to determine the time needed to reheat. Arrange the food in a circular pattern for best results.
<G-vec00502-002-s049><arrange.anordnen><de> Ich bin dann auf die Idee gekommen, nahe der Türe Klingen anzuordnen, die so eine Leine im Notfall einfach durchschneiden und damit den Hund retten.
<G-vec00502-002-s049><arrange.anordnen><en> At some point I had the idea to arrange a cutting knife close to the door to easily cut the leash and save the dog in an emergency.
<G-vec00502-002-s050><arrange.anordnen><de> Drücken Sie zuerst auf die Größe des Rahmens, um die Leiste zu drücken, die Löcher anzuordnen und die Augen zu stanzen.
<G-vec00502-002-s050><arrange.anordnen><en> First, press the size of the frame to press the bar, arrange the holes, and punch the eyes.
<G-vec00502-002-s051><arrange.anordnen><de> Es ist sinnvoll, das passende Zubehör nach Stil im Raum anzuordnen.
<G-vec00502-002-s051><arrange.anordnen><en> It's reasonable to arrange the appropriate accessories according to style in the room.
<G-vec00502-002-s052><arrange.anordnen><de> Sie können Marken verwenden, um bestimmte wichtige Zeitpunkte zu kennzeichnen oder Clips zu positionieren und anzuordnen.
<G-vec00502-002-s052><arrange.anordnen><en> Markers indicate important points in time and help you position and arrange clips.
<G-vec00502-002-s053><arrange.anordnen><de> Um den Schatten von Petunien zu sehen, können Sie eine Blume auf jeder Pflanze lassen - dies hilft, das Blumenbeet richtig anzuordnen.
<G-vec00502-002-s053><arrange.anordnen><en> To see the shade of petunias, you can leave one flower on each plant - this will help to arrange the flower bed correctly.
<G-vec00502-002-s054><arrange.anordnen><de> Es ist wünschenswert, sie zu markieren, um die Dekorelemente richtig anzuordnen.
<G-vec00502-002-s054><arrange.anordnen><en> It is desirable to mark it in order to properly arrange the decor elements.
<G-vec00502-002-s055><arrange.anordnen><de> Die Hauseigentümer sind Gastronomen, so gibt es die Möglichkeit, mit ihnen Frühstück und Abendessen auf Wunsch anzuordnen.
<G-vec00502-002-s055><arrange.anordnen><en> The House owners are restaurateurs, so there's a possibility to arrange with them Breakfast and Diner at request.
<G-vec00502-002-s056><arrange.anordnen><de> Die Erfindung beruht auf dem allgemeinen Gedanken, im Gehäuse der Abgasbehandlungseinrichtung zusätzlich ein Mischgehäuse anzuordnen, das eine Mischkammer enthält sowie einen Einlass und einen Auslass aufweist, die jeweils mit der Mischkammer kommunizieren.
<G-vec00502-002-s056><arrange.anordnen><en> The invention is based on the general idea to additionally arrange a mixing housing in the housing of the exhaust gas treatment device containing a mixing chamber and having an inlet and an outlet, each communicating with the mixing chamber.
