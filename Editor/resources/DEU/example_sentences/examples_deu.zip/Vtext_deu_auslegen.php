<G-vec00380-002-s080><dispense.auslegen><de> Die Kühlzellen erfordert daher eine sorgfältige Analyse der verschiedenen Konstruktionsparameter, um den geeigneten Verdampfer gemäß den unterschiedlichen Betriebsbedingungen auszulegen: hierbei sind Temperatur, Leistung, Umschlag, Luftmenge und deren Verteilung, Lagerart und Feuchtigkeit relevante Parameter, die Voraussetzung für eine gute Haltbarkeit der Lebensmittel sind.
<G-vec00380-002-s080><dispense.auslegen><en> The cold storage therefore requires a careful analysis of the various design parameters to select a suitable unit cooler appropriate for the different operating conditions: how to dispense the cold, the quantities and recirculation of air, the distribution and the method of storage, the temperature and humidity required for a good preservation of the food.
<G-vec00402-002-s019><interpret.auslegen><de> 14:13 Darum, welcher mit Zungen redet, der bete also, daß er's auch auslege.
<G-vec00402-002-s019><interpret.auslegen><en> 14:13 wherefore he who is speaking in an [unknown] tongue -- let him pray that he may interpret;
<G-vec00402-002-s020><interpret.auslegen><de> 1.Korinther 14/13 Darum, wer in einer Sprache redet, bete, auf daß er es auslege.
<G-vec00402-002-s020><interpret.auslegen><en> 1Corinthians 14/13 Wherefore let him that speaketh in an unknown tongue pray that he may interpret.
<G-vec00402-002-s021><interpret.auslegen><de> 13 Darum, wer in einer Sprache redet, bete, auf daß er es auslege.
<G-vec00402-002-s021><interpret.auslegen><en> 13 Therefore let him that speaks in an unknown tongue pray that he may interpret.
<G-vec00502-002-s046><lay.auslegen><de> Wir haben unser eigenes professionelles Designerteam, das jeden Monat viele neue Designs auslegen kann.
<G-vec00502-002-s046><lay.auslegen><en> We have our own professional designer team who can lay out many new designs every month.
<G-vec00502-002-s047><lay.auslegen><de> Aus den Reihen der Rohre einen neuen Streifen auslegen und sich vom vorherigen entfernen.
<G-vec00502-002-s047><lay.auslegen><en> Lay out a new strip from the rows of tubes, moving away from the previous strip.
<G-vec00502-002-s048><lay.auslegen><de> - Privater Flohmarkt: Wer Teile loswerden möchte, kann das im Forum ankündigen und die Teile dann einfach beim Auto auslegen.
<G-vec00502-002-s048><lay.auslegen><en> - Private flea market: Simply lay down all the stuff s you want to sell in front of your car and maybe list them on the bulletin board (at the entrance)
<G-vec00502-002-s049><lay.auslegen><de> Auf dem vorgewärmten Öl den Rettich, das Fleisch und die Karotten auslegen, alle 5 Minuten braten.
<G-vec00502-002-s049><lay.auslegen><en> On the preheated oil lay out the radish, meat and carrots, fry all 5 minutes.
<G-vec00502-002-s050><lay.auslegen><de> Wir haben ein eigenes professionelles Designer-Team, das viele attraktive Teppich-Designs mit den beliebten Farben auslegen kann.
<G-vec00502-002-s050><lay.auslegen><en> We have our own professional designer team who can lay out many attractive design with the popular colors.
<G-vec00502-002-s051><lay.auslegen><de> Auf den Teig auslegen, glätten Sie es, und die Form in den Ofen vorgewärmt, auf 180-200 Grad senden.
<G-vec00502-002-s051><lay.auslegen><en> On top lay out the dough, flatten it, and send the form in the oven, preheated to 180-200 degrees.
<G-vec00502-002-s052><lay.auslegen><de> Zur Not kannst du mehrere Schichten Handtücher auf dem Boden oder einem Tisch auslegen.
<G-vec00502-002-s052><lay.auslegen><en> You can lay out several layers of towels on the floor or table to iron on in a pinch.
<G-vec00502-002-s053><lay.auslegen><de> Den Skisack zwischen den Vordersitzen auslegen und beladen.
<G-vec00502-002-s053><lay.auslegen><en> Release the strap, lay out the transport bag between the front seats and load it.
<G-vec00502-002-s054><lay.auslegen><de> Ihr könnt während des Stickens ein Muster entwickeln oder, wenn Euch mehr nach Planen ist, im voraus ein Muster auf dem Tisch auslegen.
<G-vec00502-002-s054><lay.auslegen><en> You can create a pattern on the fly, or, if you feel more like planning, lay out a pattern on the tabletop in advance.
<G-vec00502-002-s055><lay.auslegen><de> Lassen Sie uns hier das wesentliche für Ihren schnellen Diätplan zur Gewichtsreduktion auslegen.
<G-vec00502-002-s055><lay.auslegen><en> Let us lay come out the essentials for you weight loss fast diet plan Here.
<G-vec00502-002-s056><lay.auslegen><de> Wir besitzen professionelles Designerteam, das viele neue Artikel mit neuartigen Designs und schönen Farbkombinationen auslegen kann.
<G-vec00502-002-s056><lay.auslegen><en> We own professional designer team who can lay out many new items with novel designs&nice color combinations.
<G-vec00502-002-s057><lay.auslegen><de> Die Alufolienbahnen auslegen.
<G-vec00502-002-s057><lay.auslegen><en> Lay out the aluminium foil sheets.
<G-vec00502-002-s058><lay.auslegen><de> Sobald die Arbeiten in der jeweiligen Tischhälfte beendet sind, kann der Tapeleger, nachdem die geschnittenen CFK-Teile abgenommen sind, auf dem freien Tischbereich wieder neu das Laminat auslegen, während die Schneidbrücke auf den Tischbereich mit dem soeben fertig gelegten Laminat wechselt und dort mit dem Schneiden beginnt..
<G-vec00502-002-s058><lay.auslegen><en> As soon as the work is finished in the respective half and the cut CFRP parts are removed, the tape layer can lay out the laminate on the free zone of the table, whereas the cutting gantry moves over to the table zone with the laid out laminate in order to cut out components.
<G-vec00502-002-s059><lay.auslegen><de> Die Meinungen derer, die es bereits geschafft haben, in kleinen Wohnungen eine gemütliche Atmosphäre zu schaffen, gehen in einem zusammen: Sie müssen die Steinstreifen horizontal oder vertikal auslegen.
<G-vec00502-002-s059><lay.auslegen><en> The opinions of those people who have already managed to create a cozy atmosphere in small apartments, converge in one: you need to lay out the stone stripes, horizontal or vertical.
<G-vec00502-002-s060><lay.auslegen><de> In einer gefetteten Auflaufform die Zucchini–Mischung auslegen.
<G-vec00502-002-s060><lay.auslegen><en> On a lined baking dish lay out the mixture.
<G-vec00502-002-s061><lay.auslegen><de> Anwendung: zum Wischen, auf der Arbeitsfläche und präventiv zum Auslegen um Maschinen und Fahrzeuge.
<G-vec00502-002-s061><lay.auslegen><en> Usage: for wiping, on the working surface and to lay out preventively around machines or vehicles.
<G-vec00502-002-s062><lay.auslegen><de> Mit einem Mosaik können Sie eine Tafel in Form eines Delfins auslegen.
<G-vec00502-002-s062><lay.auslegen><en> Using a mosaic, you can lay out a panel in the form of a dolphin.
<G-vec00502-002-s063><lay.auslegen><de> Diese unerwartete Lösung ermöglichte es, ohne die Räumlichkeiten zu überfluten, einen Kinderschreibtisch für Unterricht und Arbeit am Computer bereitzustellen und auch genügend freien Platz für Spiele zu lassen, so dass der kleine Besitzer ruhig Spielzeug auslegen und Designer sammeln konnte.
<G-vec00502-002-s063><lay.auslegen><en> This unexpected solution allowed, without cluttering the premises, to provide a children's desk for classes and work on the computer, and also leave enough free space for games, allowing the small owner to calmly lay out toys and collect designers.
<G-vec00502-002-s064><lay.auslegen><de> Einzeln laminiert kann man sie auf dem Boden auslegen und die Teilnehmer eine Karte ziehen lassen, die ihrer Stimmung am nächsten kommt.
<G-vec00502-002-s064><lay.auslegen><en> As they are individually laminated you can lay them on the floor and let the participants choose a card that corresponds closest to their current mood.
<G-vec00555-002-s046><lay_off.auslegen><de> Wir haben unser eigenes professionelles Designerteam, das jeden Monat viele neue Designs auslegen kann.
<G-vec00555-002-s046><lay_off.auslegen><en> We have our own professional designer team who can lay out many new designs every month.
<G-vec00555-002-s047><lay_off.auslegen><de> Aus den Reihen der Rohre einen neuen Streifen auslegen und sich vom vorherigen entfernen.
<G-vec00555-002-s047><lay_off.auslegen><en> Lay out a new strip from the rows of tubes, moving away from the previous strip.
<G-vec00555-002-s048><lay_off.auslegen><de> - Privater Flohmarkt: Wer Teile loswerden möchte, kann das im Forum ankündigen und die Teile dann einfach beim Auto auslegen.
<G-vec00555-002-s048><lay_off.auslegen><en> - Private flea market: Simply lay down all the stuff s you want to sell in front of your car and maybe list them on the bulletin board (at the entrance)
<G-vec00555-002-s049><lay_off.auslegen><de> Auf dem vorgewärmten Öl den Rettich, das Fleisch und die Karotten auslegen, alle 5 Minuten braten.
<G-vec00555-002-s049><lay_off.auslegen><en> On the preheated oil lay out the radish, meat and carrots, fry all 5 minutes.
<G-vec00555-002-s050><lay_off.auslegen><de> Wir haben ein eigenes professionelles Designer-Team, das viele attraktive Teppich-Designs mit den beliebten Farben auslegen kann.
<G-vec00555-002-s050><lay_off.auslegen><en> We have our own professional designer team who can lay out many attractive design with the popular colors.
<G-vec00555-002-s051><lay_off.auslegen><de> Auf den Teig auslegen, glätten Sie es, und die Form in den Ofen vorgewärmt, auf 180-200 Grad senden.
<G-vec00555-002-s051><lay_off.auslegen><en> On top lay out the dough, flatten it, and send the form in the oven, preheated to 180-200 degrees.
<G-vec00555-002-s052><lay_off.auslegen><de> Zur Not kannst du mehrere Schichten Handtücher auf dem Boden oder einem Tisch auslegen.
<G-vec00555-002-s052><lay_off.auslegen><en> You can lay out several layers of towels on the floor or table to iron on in a pinch.
<G-vec00555-002-s053><lay_off.auslegen><de> Den Skisack zwischen den Vordersitzen auslegen und beladen.
<G-vec00555-002-s053><lay_off.auslegen><en> Release the strap, lay out the transport bag between the front seats and load it.
<G-vec00555-002-s054><lay_off.auslegen><de> Ihr könnt während des Stickens ein Muster entwickeln oder, wenn Euch mehr nach Planen ist, im voraus ein Muster auf dem Tisch auslegen.
<G-vec00555-002-s054><lay_off.auslegen><en> You can create a pattern on the fly, or, if you feel more like planning, lay out a pattern on the tabletop in advance.
<G-vec00555-002-s055><lay_off.auslegen><de> Lassen Sie uns hier das wesentliche für Ihren schnellen Diätplan zur Gewichtsreduktion auslegen.
<G-vec00555-002-s055><lay_off.auslegen><en> Let us lay come out the essentials for you weight loss fast diet plan Here.
<G-vec00555-002-s056><lay_off.auslegen><de> Wir besitzen professionelles Designerteam, das viele neue Artikel mit neuartigen Designs und schönen Farbkombinationen auslegen kann.
<G-vec00555-002-s056><lay_off.auslegen><en> We own professional designer team who can lay out many new items with novel designs&nice color combinations.
<G-vec00555-002-s057><lay_off.auslegen><de> Die Alufolienbahnen auslegen.
<G-vec00555-002-s057><lay_off.auslegen><en> Lay out the aluminium foil sheets.
<G-vec00555-002-s058><lay_off.auslegen><de> Sobald die Arbeiten in der jeweiligen Tischhälfte beendet sind, kann der Tapeleger, nachdem die geschnittenen CFK-Teile abgenommen sind, auf dem freien Tischbereich wieder neu das Laminat auslegen, während die Schneidbrücke auf den Tischbereich mit dem soeben fertig gelegten Laminat wechselt und dort mit dem Schneiden beginnt..
<G-vec00555-002-s058><lay_off.auslegen><en> As soon as the work is finished in the respective half and the cut CFRP parts are removed, the tape layer can lay out the laminate on the free zone of the table, whereas the cutting gantry moves over to the table zone with the laid out laminate in order to cut out components.
<G-vec00555-002-s059><lay_off.auslegen><de> Die Meinungen derer, die es bereits geschafft haben, in kleinen Wohnungen eine gemütliche Atmosphäre zu schaffen, gehen in einem zusammen: Sie müssen die Steinstreifen horizontal oder vertikal auslegen.
<G-vec00555-002-s059><lay_off.auslegen><en> The opinions of those people who have already managed to create a cozy atmosphere in small apartments, converge in one: you need to lay out the stone stripes, horizontal or vertical.
<G-vec00555-002-s060><lay_off.auslegen><de> In einer gefetteten Auflaufform die Zucchini–Mischung auslegen.
<G-vec00555-002-s060><lay_off.auslegen><en> On a lined baking dish lay out the mixture.
<G-vec00555-002-s061><lay_off.auslegen><de> Anwendung: zum Wischen, auf der Arbeitsfläche und präventiv zum Auslegen um Maschinen und Fahrzeuge.
<G-vec00555-002-s061><lay_off.auslegen><en> Usage: for wiping, on the working surface and to lay out preventively around machines or vehicles.
<G-vec00555-002-s062><lay_off.auslegen><de> Mit einem Mosaik können Sie eine Tafel in Form eines Delfins auslegen.
<G-vec00555-002-s062><lay_off.auslegen><en> Using a mosaic, you can lay out a panel in the form of a dolphin.
<G-vec00555-002-s063><lay_off.auslegen><de> Diese unerwartete Lösung ermöglichte es, ohne die Räumlichkeiten zu überfluten, einen Kinderschreibtisch für Unterricht und Arbeit am Computer bereitzustellen und auch genügend freien Platz für Spiele zu lassen, so dass der kleine Besitzer ruhig Spielzeug auslegen und Designer sammeln konnte.
<G-vec00555-002-s063><lay_off.auslegen><en> This unexpected solution allowed, without cluttering the premises, to provide a children's desk for classes and work on the computer, and also leave enough free space for games, allowing the small owner to calmly lay out toys and collect designers.
<G-vec00555-002-s064><lay_off.auslegen><de> Einzeln laminiert kann man sie auf dem Boden auslegen und die Teilnehmer eine Karte ziehen lassen, die ihrer Stimmung am nächsten kommt.
<G-vec00555-002-s064><lay_off.auslegen><en> As they are individually laminated you can lay them on the floor and let the participants choose a card that corresponds closest to their current mood.
<G-vec00557-002-s003><misinterpret.auslegen><de> Und so dürft ihr die Bibel nicht falsch auslegen.
<G-vec00557-002-s003><misinterpret.auslegen><en> So you must not misinterpret the Bible.
