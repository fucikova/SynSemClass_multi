<G-vec00301-002-s025><rectify.abstellen><de> Die Autoren erklären physiologische Erkenntnisse als Grundlagen für die Reitlehre und erläutern wichtige Anhaltspunkte für die Ausbildung des Pferdes, das Erkennen und Abstellen von Ausbildungsproblemen.
<G-vec00301-002-s025><rectify.abstellen><en> The authors explain the physiological facts which are the foundation of the teaching of riding and discuss important factors in the training of the horse and how to recognise and rectify training...more...
<G-vec00380-002-s028><unload.abstellen><de> In dem Moment, in dem der Staplerfahrer die Palette hier abstellen will, drückt er eine Schaltfläche auf dem Display des beheizbaren Terminals.
<G-vec00380-002-s028><unload.abstellen><en> As soon as the driver is ready to unload the pallet there, he simply presses a button on the heated terminal display.
<G-vec00376-003-s038><shut_down.abstellen><de> Im Rahmen des General-Turnarounds der Raffinerie Schwechat wurden die Prozessanlagen im Petrochemie-Bereich abgestellt.
<G-vec00376-003-s038><shut_down.abstellen><en> In the course of the general turnaround at the Schwechat refinery, the processing facilities in the petrochemical division were shut down.
<G-vec00376-003-s039><shut_down.abstellen><de> Ist kein ausreichender Schornsteinzug vorhanden, wird die Gaszufuhr abgestellt und ein Austreten von Gas vermieden.
<G-vec00376-003-s039><shut_down.abstellen><en> If there is not sufficient chimney flue then the gas supply is shut off and a gas leak is prevented.
<G-vec00376-003-s040><shut_down.abstellen><de> Ist das Fahrzeug mit einem Automatikgetriebe ausgestattet, muss es bis zum Stillstand (0 km/h) gebremst werden, bevor der Motor abgestellt wird.
<G-vec00376-003-s040><shut_down.abstellen><en> In the case of automatic transmissions, the engine is not shut down until the vehicle comes to a standstill (0 km/h).
<G-vec00376-003-s041><shut_down.abstellen><de> In diesem Fall wird der Antrieb sicher abgestellt.
<G-vec00376-003-s041><shut_down.abstellen><en> In this case the drive is shut down safely.
<G-vec00376-003-s042><shut_down.abstellen><de> Das Wasser war der Familie bereits vorher abgestellt worden und das Haus wurde komplett zerstört.
<G-vec00376-003-s042><shut_down.abstellen><en> The water mains to the house had been shut off prior to the attack and the house was completely destroyed.
<G-vec00376-003-s043><shut_down.abstellen><de> Sobald die Kälteanlage angehalten wird, wird der Kühlwasserdurchfluss automatisch abgestellt.
<G-vec00376-003-s043><shut_down.abstellen><en> When the refrigeration plant is stopped, the cooling water flow is shut off automatically. Water valves
<G-vec00376-003-s044><shut_down.abstellen><de> Home Es war am 23.06.2008 als die letzte betriebsfähige Dresdner Dampflokomotive 89 6009, Baujahr 1902, abgestellt wurde.
<G-vec00376-003-s044><shut_down.abstellen><en> On 23rd of June, 2008 the last working steam engine of Dresden 89 6009, built in 1902, was shut down.
<G-vec00514-002-s038><shut_up.abstellen><de> Im Rahmen des General-Turnarounds der Raffinerie Schwechat wurden die Prozessanlagen im Petrochemie-Bereich abgestellt.
<G-vec00514-002-s038><shut_up.abstellen><en> In the course of the general turnaround at the Schwechat refinery, the processing facilities in the petrochemical division were shut down.
<G-vec00514-002-s039><shut_up.abstellen><de> Ist kein ausreichender Schornsteinzug vorhanden, wird die Gaszufuhr abgestellt und ein Austreten von Gas vermieden.
<G-vec00514-002-s039><shut_up.abstellen><en> If there is not sufficient chimney flue then the gas supply is shut off and a gas leak is prevented.
<G-vec00514-002-s040><shut_up.abstellen><de> Ist das Fahrzeug mit einem Automatikgetriebe ausgestattet, muss es bis zum Stillstand (0 km/h) gebremst werden, bevor der Motor abgestellt wird.
<G-vec00514-002-s040><shut_up.abstellen><en> In the case of automatic transmissions, the engine is not shut down until the vehicle comes to a standstill (0 km/h).
<G-vec00514-002-s041><shut_up.abstellen><de> In diesem Fall wird der Antrieb sicher abgestellt.
<G-vec00514-002-s041><shut_up.abstellen><en> In this case the drive is shut down safely.
<G-vec00514-002-s042><shut_up.abstellen><de> Das Wasser war der Familie bereits vorher abgestellt worden und das Haus wurde komplett zerstört.
<G-vec00514-002-s042><shut_up.abstellen><en> The water mains to the house had been shut off prior to the attack and the house was completely destroyed.
<G-vec00514-002-s043><shut_up.abstellen><de> Sobald die Kälteanlage angehalten wird, wird der Kühlwasserdurchfluss automatisch abgestellt.
<G-vec00514-002-s043><shut_up.abstellen><en> When the refrigeration plant is stopped, the cooling water flow is shut off automatically. Water valves
<G-vec00514-002-s044><shut_up.abstellen><de> Home Es war am 23.06.2008 als die letzte betriebsfähige Dresdner Dampflokomotive 89 6009, Baujahr 1902, abgestellt wurde.
<G-vec00514-002-s044><shut_up.abstellen><en> On 23rd of June, 2008 the last working steam engine of Dresden 89 6009, built in 1902, was shut down.
