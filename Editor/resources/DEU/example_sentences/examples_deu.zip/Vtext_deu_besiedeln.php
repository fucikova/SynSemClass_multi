<G-vec00301-001-s204><settle.besiedeln><de> Krankheitserreger besiedeln die Zahnfleischtasche und wandern dann immer tiefer hinein.
<G-vec00301-001-s204><settle.besiedeln><en> Germs settle in the gingival pockets and move deeper and deeper inside.
<G-vec00301-001-s205><settle.besiedeln><de> Das Feuer wärmt, mit ihm kann der Mensch Gegenden besiedeln, die sonst zu unwirtlich wären.
<G-vec00301-001-s205><settle.besiedeln><en> Fire warms, with it man can settle areas that otherwise would be too harsh.
<G-vec00301-001-s206><settle.besiedeln><de> Sie braucht Modelle für eine neue Zivilisation, damit wir anfangen können, unseren Planeten auf eine neue, mit den Gesetzen des Lebens übereinstimmende Weise zu besiedeln.
<G-vec00301-001-s206><settle.besiedeln><en> It needs models for a new civilisation so that we can start to settle our planet in a new manner which is coherent with the laws of life.
<G-vec00301-001-s207><settle.besiedeln><de> Du kannst eventuell zwei oder drei Dörfer von einem ‚Ursprungs‘-Dorf aus besiedeln, aber jede weitere Expansion muss dann von einem der neugegründeten Dörfer aus erfolgen.
<G-vec00301-001-s207><settle.besiedeln><en> You may be able to settle two or three villages from one “village of origin”, but any further expansion must then be performed from one of the “second-generation” villages.
<G-vec00301-001-s208><settle.besiedeln><de> Das im Westen freiliegende Grundgebirge, überwiegend aus metamorphen Gesteinen und Graniten aufgebaut, war trotz seiner Steilheit leichter zu besiedeln und erscheint heute mit seinen vielgestaltigen Wiesentälern offen und freundlicher.
<G-vec00301-001-s208><settle.besiedeln><en> The exposed basement in the west, predominantly made up of metamorphic rocks and granites, was, despite its rugged topography, easier to settle and appears much more open and inviting today with its varied meadow valleys.
<G-vec00301-001-s209><settle.besiedeln><de> Das starke Bevölkerungswachstum in den Städten und die Zuwanderung aus ländlichen Gebieten zwingen vor allem Randgruppen dazu, Gegenden zu besiedeln, die aufgrund ihrer Lage und örtlichen Bedingungen dafür ungeeignet sind.
<G-vec00301-001-s209><settle.besiedeln><en> Strong population growth in cities and rural to urban migration force marginal groups in particular to settle in areas that are unsuitable on account of their location and the specific local conditions.
<G-vec00301-001-s210><settle.besiedeln><de> Die Protagonisten Isak und Inger besiedeln ein Stück Land, ihr Leben besteht nur aus Schwerstarbeit in der Natur.
<G-vec00301-001-s210><settle.besiedeln><en> In the novel, the protagonists Isak and Inger settle on a piece of land and their lives consist solely of extremely hard work.
