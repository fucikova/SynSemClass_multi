<G-vec00280-002-s105><overtake.abhängen><de> Sie ist einfacher zu handhaben, besser verträglich und mit der nächsten Technologie-Iteration wird MR durchaus das Zeug haben, VR auf breiter Ebene abzuhängen.
<G-vec00280-002-s105><overtake.abhängen><en> It's easier to handle, more compatible, and with the next iteration of the technology, MR will certainly be able to overtake VR on a broader level.
<G-vec00520-002-s044><depend.abhängen><de> Denn die Mineralwasser haben verschiedene Geschmäcke, die abhängen von der im Wasser enthaltenen Mineralisierung.
<G-vec00520-002-s044><depend.abhängen><en> Yes, mineral waters have different tastes, which depend on the minerals specialities
<G-vec00520-002-s045><depend.abhängen><de> Drehende Tabellen können in der Runde, Quadrat, sogar Achtkiefer sein, abhängen von den verschiedenen Anforderungen der Schweißensaufgabe.
<G-vec00520-002-s045><depend.abhängen><en> Rotating Tables can be in round, square, even eight-jaws, depend on various requirements of welding task.
<G-vec00520-002-s046><depend.abhängen><de> Wenn sich dieser Ort im zweisprachigen Gebiet Brüssel-Hauptstadt befindet, wird diese Zuständigkeit von der Sprache abhängen, die im Antrag verwendet wurde oder von der Sprache, die vom Beklagten gewählt wurde.
<G-vec00520-002-s046><depend.abhängen><en> If this place is located in the bilingual Brussels Capital Region, this competence will depend on the language that is used in the application or the language chosen by the defendant.
<G-vec00520-002-s047><depend.abhängen><de> Wie ein Mensch handelt, wird also abhängen von der Art, wie sein Intuitionsvermögen einer bestimmten Situation gegenüber wirkt.
<G-vec00520-002-s047><depend.abhängen><en> How I act will therefore depend on how my capacity for intuition works in relation to a particular situation.
<G-vec00520-002-s048><depend.abhängen><de> Die Mengen, in denen proteolytische Enzyme in Bezug auf tierisches Protein verwendet werden, wird abhängen von der Substratkonzentration, dem Enzymtiter, der Reaktionstemperatur und der Reaktionszeit, wobei sie im typischen Fall im Bereich von 100 bis 10.000 Einheiten der Enzymaktivität pro 1 g Protein, die in der Dispersion oder Lösung des tierischen Proteins enthalten sind.
<G-vec00520-002-s048><depend.abhängen><en> The amounts in which proteolytic enzymes are used versus the animal protein will depend on substrate concentration, enzyme titer, reaction temperature, and reaction time, but typically range from about 100 to 10,000 units of activity per 1 g of protein contained in the animal protein dispersion or solution.
<G-vec00520-002-s049><depend.abhängen><de> Nicht nur hängen wir von unseren Autos ab, um uns zu erhalten, wo wir gehen möchten, wir abhängen auch von ihnen, um uns ohne Unannehmlichkeit dort zu erhalten.
<G-vec00520-002-s049><depend.abhängen><en> Not only do we depend on our cars to get us where we want to go, we also depend on them to get us there without discomfort.
<G-vec00520-002-s050><depend.abhängen><de> Ob diese Expropriation mit oder ohne Entschädigung erfolgt, wird großenteils nicht von uns abhängen, sondern von den Umständen, unter denen wir in den Besitz der Macht kommen, und namentlich auch von der Haltung der Herren Großgrundbesitzer selbst.
<G-vec00520-002-s050><depend.abhängen><en> Whether this expropriation is to be compensated for or not will, to a great extent, depend not upon us but the circumstances under which we obtain power, and particularly upon the attitude adopted by these gentry, the big landowners, themselves.
<G-vec00551-002-s019><hang.abhängen><de> Die BBC News möchte eben nicht mit Ihnen abhängen.
<G-vec00551-002-s019><hang.abhängen><en> The BBC News might not want to hang around with you.
<G-vec00551-002-s020><hang.abhängen><de> Nach Verwendung kann die Tischplatte abgeklappt werden, so dass Sie bequem an dem Tisch vorbei gehen können ohne diese abhängen zu müssen.
<G-vec00551-002-s020><hang.abhängen><en> After use, the table top can be folded down so that you can comfortably walk past the table without having to hang it.
<G-vec00551-002-s021><hang.abhängen><de> Es ist auf jeden Fall ein Ort, wo die Einheimischen Abhängen.
<G-vec00551-002-s021><hang.abhängen><en> It is definitely a place where locals hang out.
<G-vec00551-002-s022><hang.abhängen><de> Das Brisbane Hotel ist ein traditioneller Pub in der Stadt, ein entspannter unkomplizierter Ort zum abhängen.
<G-vec00551-002-s022><hang.abhängen><en> The Brisbane Hotel is a traditional corner pub in town, kicked back and an easygoing place to hang.
<G-vec00551-002-s023><hang.abhängen><de> Von dort aus können Sie die Insel zu einer idealen Kleinstadt mit gutem Willen und guter Stimmung ausbauen, in der Sie mit Ihren freundlichen Inselbewohnern (jeder hat seine Persönlichkeit) und echten Freunden abhängen können.
<G-vec00551-002-s023><hang.abhängen><en> From there, you can build the island up into an ideal small town with goodwill and good vibes where you can hang out with your friendly islanders (each has their personalities) and real-world friends.
<G-vec00551-002-s024><hang.abhängen><de> Und zwar vorwiegend mit Interessierten, Wütenden und der Nachbarschaft, nicht in erster Linie mit denen, die in der Szenekneipe abhängen.
<G-vec00551-002-s024><hang.abhängen><en> This was done mainly with interested people, angry people and the neighbourhood, not so much with those who hang out at the scene pub.
<G-vec00551-002-s025><hang.abhängen><de> Das fing mit Briefen an, ging über Telefongespräche und gemeinsamen Ausflügen bis hin zum Abhängen in Chucks Haus.
<G-vec00551-002-s025><hang.abhängen><en> It went from letters, to phone conversations to eventually taking roadtrips up to Chuck's house to hang out.
<G-vec00551-002-s026><hang.abhängen><de> Außerdem betreibt Jab einen Blog, ein Forum und du kannst auch mit anderen Mitgliedern, sowie Jab und seinem Team in einem Chatroom abhängen.
<G-vec00551-002-s026><hang.abhängen><en> Also Jab is running an active blog, a forum and you can even hang out with other members, Jab and his team on a chat room.
<G-vec00551-002-s027><hang.abhängen><de> Es ist ein fantastischer Ort zum Abhängen.
<G-vec00551-002-s027><hang.abhängen><en> It's a fantastic place to hang out.
<G-vec00551-002-s028><hang.abhängen><de> Das Boutique-Apartment ist der ideale Ort zum Abhängen und Spaß haben für die charmante und begehrenswerte Schickeria von PlayStation®Home.
<G-vec00551-002-s028><hang.abhängen><en> The Boutique Apartment is the perfect place for the suave and sexy socialites of PlayStation Home to hang out and have fun.
<G-vec00551-002-s029><hang.abhängen><de> Hotelgarten In unserem Abenteuer-Kletterwald direkt neben dem kreativen Outdoor-Spielplatz „Murmels Wasserwelt“ könnt ihr Euch so richtig austoben, oder einfach in der Hängematte oder auf den Schaukeln abhängen.
<G-vec00551-002-s029><hang.abhängen><en> Children can let off steam on our adventure ropes cours*e next to the creative outdoor play area *‘Murmel’s Water World’ or simply hang out in the hammock or on the swings.
<G-vec00551-002-s030><hang.abhängen><de> Es ist der perfekte Ort für die Vogelbeobachtung und Reiche zeigte mir auch die Eulen in der Nacht, die in ihrem Hinterhof in der Eulenkasten Abhängen.
<G-vec00551-002-s030><hang.abhängen><en> It's the perfect place for bird-watching and Rich even showed me the owls at night that hang out in the owl box in their backyard.
<G-vec00551-002-s031><hang.abhängen><de> Und abhängen und chillen ist angesagter, als durch den Park zu joggen.
<G-vec00551-002-s031><hang.abhängen><en> To hang out and chill is much more in trend than jogging through the park.
<G-vec00551-002-s032><hang.abhängen><de> Selten hatten wir so viel Abwechslung im Urlaub mit Städtebesichtigung, Fattorien-Besuchen, Reiten und Wanderungen oder einfach nur abhängen.
<G-vec00551-002-s032><hang.abhängen><en> We rarely had so much variety on holiday with tour cities, Fattorias visits, horseback riding and hiking, or just hang out.
<G-vec00551-002-s033><hang.abhängen><de> Es war toll, unsere kleine Behausung zu haben, um nach einem langen Tag zu kommen, und einen gemütlichen Ort zum Abhängen in, wenn es (zum Glück nur sehr wenig) geregnet.
<G-vec00551-002-s033><hang.abhängen><en> It was great to have our little abode to come back to after a long day, and a cosy place to hang out in when it rained (luckily very little).
<G-vec00551-002-s034><hang.abhängen><de> Da konnte ich sie tatsächlich abhängen und mit meinem Zeltplatznachbar flogen wir über die Trails ins Fanestal hinein.
<G-vec00551-002-s034><hang.abhängen><en> Since I could literally hang out and with my campsite neighbor we flew over the trails into the Fanestal.
<G-vec00551-002-s035><hang.abhängen><de> - Yard Terrasse auf dem Grundstück - große offene Fläche zum Abhängen mit Freunden.
<G-vec00551-002-s035><hang.abhängen><en> - Yard terrace inside the property - great open area to hang out with friends.
<G-vec00551-002-s036><hang.abhängen><de> Als Alternative kann man auch einfach außerhalb des Parks wandern oder am Strand abhängen.
<G-vec00551-002-s036><hang.abhängen><en> Alternatively just stay outside the park and go for a hike in the area or hang at the beach
<G-vec00551-002-s037><hang.abhängen><de> An der Hotelbar können Sie zwischendurch Getränke und Snacks bestellen (nicht in der Verwöhnpension enthalten) und einfach mal „abhängen“.
<G-vec00551-002-s037><hang.abhängen><en> At the hotel bar, you can order drinks and snacks in between meals (not included in the pampering pension) and simply "hang out."
<G-vec00595-002-s022><detach.abhängen><de> Einmal pro Spielzug: Du kannst ein Xyz-Material von dieser Karte abhängen und dann ein offenes Monster wählen, das dein Gegner kontrolliert; zerstöre es, es sei denn, dein Gegner zahlt 1000 Life Points, um diesen Effekt zu annullieren.
<G-vec00595-002-s022><detach.abhängen><en> Once per turn: You can detach 1 Xyz Material from this card, then target 1 face-up monster your opponent controls; destroy it, unless your opponent pays 1000 Life Points to negate this effect.
<G-vec00180-002-s025><depend.abhängen><de> Je nachdem, wer Sie entlehnt - die Bank oder bei Verwandten und wird über weitere Maßnahmen abhängen.
<G-vec00180-002-s025><depend.abhängen><en> Depending on who you borrowed - the bank or with relatives, and will depend on further actions.
<G-vec00180-002-s026><depend.abhängen><de> Ihr werdet zwar erst dann darüber sprechen können, wenn die ersten Vorgänge stattgefunden haben, denn zuvor wird kein Mensch eure Rede anhören wollen - ihr werdet erst dann offene Ohren und Herzen finden, wenn eine Erschütterung vorangegangen ist, die die Menschen fragen lässet, und dann erst sollet ihr reden, und von der Willigkeit der Menschen wird es abhängen, welchen Nutzen er/sie aus jenen Geschehen ziehen.
<G-vec00180-002-s026><depend.abhängen><en> You will in fact only then be able to speak about it when the first events have taken place because beforehand no man wants to listen to your talk – you will only then find open ears and hearts when one tremor has preceded it, which lets men ask, and only then you are to speak, and it will depend on the willingness of men which benefit he/she is reaping from those happenings.
<G-vec00180-002-s027><depend.abhängen><de> Die Modelle werden in alphabetischer Reihenfolge importiert, also müssen die Dateien, von denen andere Module abhängen, zuerst geladen werden.
<G-vec00180-002-s027><depend.abhängen><en> The Models are imported in alphabetical order, so we load the files which other modules depend on 1st, hence naming them appropriately:
<G-vec00180-002-s028><depend.abhängen><de> Das wirtschaftliche Wachstum der Städte wird mehr und mehr von der globalen Wirtschaftslage, dem technologischem Fortschritt und der Infrastruktur abhängen.
<G-vec00180-002-s028><depend.abhängen><en> The economic growth of cities will come to depend more and more on the global economic situation, technological progress and infrastructure.
<G-vec00180-002-s029><depend.abhängen><de> Die meisten Computer beginnen bei langer Nutzung unter Stabilitätsproblemen und anderen Systemproblemen zu leiden, wenn auch in unterschiedlichem Maße, was von verschiedenen Faktoren abhängen kann.
<G-vec00180-002-s029><depend.abhängen><en> Most computers begin to suffer stability problems with continued use, although to a different degree that may depend on different factors.
<G-vec00180-002-s030><depend.abhängen><de> Wir verstehen „Universität“ als Expertenorganisation: Typisch dafür ist, dass Veränderungen und Entwicklungen vor allem von der intrinsischen Motivation der an den Kern- und Managementprozessen beteiligten Personen abhängen.
<G-vec00180-002-s030><depend.abhängen><en> We understand "university" as an expert organisation: It is typical for this approach that the changes and developments depend above all on the intrinsic motivation of the persons participating in the core and management processes.
<G-vec00180-002-s031><depend.abhängen><de> In all diesen Fällen kommt es zu einer akuten Vergiftung, deren Schweregrad und deren Folgen von der Art des Arzneimittels, dem Gesundheitszustand des Opfers, der Dosis und der Zeit der Körperbelastung abhängen.
<G-vec00180-002-s031><depend.abhängen><en> In all these cases, acute intoxication occurs, the severity and consequences of which depend on the type of medicine, the state of health of the victim, the dose taken and the time of exposure to the body.
<G-vec00180-002-s032><depend.abhängen><de> Eine Mitarbeiterbefragung ist der beste Ansatzpunkt, jedoch wird die Qualität Ihrer Ergebnisse stark von Ihren Fragen abhängen.
<G-vec00180-002-s032><depend.abhängen><en> An employee engagement survey is the best place to start, however the quality of your results will depend heavily on the questions that you ask, and how you ask them.
<G-vec00180-002-s033><depend.abhängen><de> Alles wird auf Ihre Bemühungen abhängen.
<G-vec00180-002-s033><depend.abhängen><en> Everything will depend on your efforts.
<G-vec00180-002-s034><depend.abhängen><de> Wenn Sie mit den öffentlichen Verkehrsmitteln abhängen müssen Sie gute Informationen bekommen.
<G-vec00180-002-s034><depend.abhängen><en> If you depend on public transport you must get good information.
<G-vec00180-002-s035><depend.abhängen><de> Tarif für Neuseeland – Malta kann auch von der Fluggesellschaft abhängen.
<G-vec00180-002-s035><depend.abhängen><en> The fare New Zealand – Malta may depend not only the departure/arrival date and time, but also on the carrier.
<G-vec00180-002-s036><depend.abhängen><de> Obwohl die Ausführungsbeispiele im Hinblick auf ER in dem sichtbaren Spektrum beschrieben sind, würde die Wellenlänge der ER, die verwendet wird, von der Empfindlichkeit des Bilderzeugers gegenüber dieser Wellenlänge und der Fähigkeit der Filter abhängen, die ER auf die Pixel zu reduzieren.
<G-vec00180-002-s036><depend.abhängen><en> Although the embodiments are described in terms of ER in the visible spectrum, the wavelength of ER used would depend on the sensitivity of the imager to that wavelength and the ability of the filters to reduce the ER on the pixels.
<G-vec00180-002-s037><depend.abhängen><de> Aus diesem Grund kann man behaupten, daß von der Gesundheit und Qualität der familiären Beziehungen die Gesundheit und Qualität der gesellschaftlichen Beziehungen abhängen.
<G-vec00180-002-s037><depend.abhängen><en> It can rightly be said that the health and quality of social relations depend on the health and quality of family relationships.
<G-vec00180-002-s038><depend.abhängen><de> Grundsätzlich wird bis zum Abzug der Gäste keine Bedrohung drohen, sondern die Hauptposition des Turniers wird genau von der Konfrontation mit Monaco abhängen, so dass in Zukunft die geschätzte Zahl 30 in der Punktegrafik vor den Stationen von Vahid Khalilhodzhich ragt.
<G-vec00180-002-s038><depend.abhängen><en> In principle, until the departure of the guests no threat threatens, but the main position of the tournament will depend exactly on the confrontation with Monaco, so that in the future, the estimated number 30 in the score chart towers in front of the stations of Vahid Khalilhodzhich.
<G-vec00180-002-s039><depend.abhängen><de> Bitte beachten Sie, dass wir Preise für Medaillen und Münzen nicht generell angeben können, da die Preise stark von Stückzahlen, Werkzeugkosten sowie Material, zum Beispiel Messing oder Edelmetallen, abhängen.
<G-vec00180-002-s039><depend.abhängen><en> Please note that we can not state prices for medals and mints in general, as prices heavily depend on the number of pieces, tooling costs as well as material, i.e., brass or precious metals.
<G-vec00180-002-s040><depend.abhängen><de> Tarif für Turkei – Benin kann auch von der Fluggesellschaft abhängen.
<G-vec00180-002-s040><depend.abhängen><en> The fare Turkey – Benin may depend not only the departure/arrival date and time, but also on the carrier.
<G-vec00180-002-s041><depend.abhängen><de> Es liest eine Datei namens makefile, welche ihm sagt, wie unterschiedliche Dateien voneinander abhängen, und berechnet, welche Dateien neu kompiliert werden müssen und welche nicht.
<G-vec00180-002-s041><depend.abhängen><en> It reads in a file, called a makefile, that tells it how different files depend on each other, and works out which files need to be re-compiled and which ones do not.
<G-vec00180-002-s042><depend.abhängen><de> Die Wettbewerbsfähigkeit von Unternehmen wird zukünftig noch sehr viel stärker von der Fähigkeit abhängen, leistungsstarke Mitarbeiter zu gewinnen, zu halten und zu fördern.
<G-vec00180-002-s042><depend.abhängen><en> The competitiveness of companies will, in the future, depend even much more on the ability to attract, keep and promote high-performing employees.
<G-vec00180-002-s043><depend.abhängen><de> Nachdem beim typischen Spiel die Punkte, die der Spieler gewinnt, von der Schnelligkeit seiner Reaktion abhängen, und da das bewusste Denken sehr langsam ist, wird der Spieler gezwungen, ohne zu denken reagieren.
<G-vec00180-002-s043><depend.abhängen><en> In a typical game, the points that the player wins depend on the speed of his reaction. As conscious thinking is very slow, the player has to react without thinking.
<G-vec00180-002-s133><depend.abhängen><de> Sie wissen, dass das variable Vergütungssystem des Unternehmens von ihrer Strenge abhängt (und bei einer Überprüfung gibt es immer auch Grauzonen).
<G-vec00180-002-s133><depend.abhängen><en> They will know that the organization’s variable compensation system will depend on how strict they are (and an audit is never fully black and white).
<G-vec00180-002-s134><depend.abhängen><de> Dabei verfolgen wir die These, dass die Zukunftsfähigkeit des Faches Psychologie wesentlich von ihrer gesellschaftlichen Nützlichkeit abhängt, und dass wiederum diese gesellschaftliche Nützlichkeit eine befriedigende Ausgestaltung des Verhältnisses von Wissenschaft und Praxis und in engem Zusammenhang damit die Verwirklichung methodologischer Pluralität erfordert.
<G-vec00180-002-s134><depend.abhängen><en> We assume in this respect that the future prospects for the psychology profession depend essentially on its social usefulness and that this social usefulness in turn requires a satisfactory organisation of the relationship between science and practice and, closely connected with this, the introduction of methodological plurality.
<G-vec00180-002-s135><depend.abhängen><de> Diese Platten haben viele Poren, deren Anzahl und Größe von den Rohstoffen und der Qualität der Aktivierung abhängt.
<G-vec00180-002-s135><depend.abhängen><en> This is made up of microcrystalline graphite layers with numerous pores, the number and size of which depend on the raw material and quality of activation.
<G-vec00180-002-s136><depend.abhängen><de> Die Entwicklung einer Laktoseintoleranz ist ziemlich häufig, da sie von der Menge der im Dünndarm vorhandenen Laktase abhängt.
<G-vec00180-002-s136><depend.abhängen><en> Symptoms vary from person to person and depend on the amount of lactose eaten.
<G-vec00180-002-s137><depend.abhängen><de> Wenn die MISRA Regeln befolgt werden, dann können Entwickler sicher sein, dass sie die strengsten Softwarecodierrichtlinien verwenden um die Risiken für Softwareanwendungen abzumildern, von denen menschliches Leben abhängt.
<G-vec00180-002-s137><depend.abhängen><en> By following MISRA rules, developers can be assured that they are using the most stringent software coding guidelines to mitigate liability and risk in software applications on which human lives depend.
<G-vec00180-002-s138><depend.abhängen><de> Es darf nicht außer Acht gelassen werden, dass der Ruf des EPA nicht nur von der Qualität, sondern auch von der Schnelligkeit der Arbeit abhängt.
<G-vec00180-002-s138><depend.abhängen><en> It should not be forgotten that the reputation of the EPO will depend not only on quality but also on the speed with which it deals with its work.
<G-vec00180-002-s139><depend.abhängen><de> Ursächlich hierfür ist, dass die strukturelle Integrität des geschmiedeten Bauteils, von der die mechanischen Eigenschaften abhängt, aus dem rohgeschmiedeten Zustand resultiert und intakt bleibt.
<G-vec00180-002-s139><depend.abhängen><en> The reason for this is that the structural integrity of the forged component, on which the mechanical properties depend, results from the as-forged condition and remains intact.
<G-vec00180-002-s140><depend.abhängen><de> Blütenhonig wird von Honigbienen erzeugt, der Geschmack ist einzigartig und abwechslungsreich, sowie deren Eigenschaften, der auf die Blume oder Blumen abhängt.
<G-vec00180-002-s140><depend.abhängen><en> Blossom honey is produced by honey bees, the taste is unique and varied, as well as its properties, which depend on the flowers to which it belongs.
<G-vec00180-002-s141><depend.abhängen><de> Und weil die überwiegende Mehrheit der Bürger der Stadt für Privatunternehmen arbeitet, kann China sie nicht so leicht unter Kontrolle bringen wie die Bürger vom Festland, deren Lebenserwerb vom Staat abhängt.
<G-vec00180-002-s141><depend.abhängen><en> And because the vast majority of Hong Kong’s residents are employed by private businesses, China cannot control them as easily as mainlanders who depend on the state for their livelihoods.
<G-vec00180-002-s142><depend.abhängen><de> Es klingt vielleicht wie eine tröstende Doktrin zu sagen, dass Gott alle liebt und keine hasst, aber in der Wirklichkeit verursacht diese Lehre, dass die Liebe Gottes auf den wankelmütigen und sündhaften Willen des Menschen abhängt.
<G-vec00180-002-s142><depend.abhängen><en> It may sound like a comforting doctrine to say that God loves everyone and hates no one, but in reality it makes the love of God depend upon the fickle and sinful will of man.
<G-vec00180-002-s143><depend.abhängen><de> Die Auswechslung der Beamten wird auch dazu beitragen, den Korpsgeist des Beamtentums zu zerstören und sie der Regierung zugetan machen, von der ihr Schicksal abhängt.
<G-vec00180-002-s143><depend.abhängen><en> This method of shuffling the staff will serve also to explode any collective solidarity of those in the same service and will bind all to the interests of the government upon which their fate will depend.
<G-vec00180-002-s144><depend.abhängen><de> Daher sei es dringend, dass die Regierungspolitik die Familie unterstütze, von der "die Zukunft und der Fortschritt der Staaten abhängt" und ohne die künftige Herausforderungen nicht bewältigt werden könnten.
<G-vec00180-002-s144><depend.abhängen><en> Therefore, it is urgent, he continued, that government policies support the family, on which “the future and the development of states depend,” and without which future challenges cannot be met.
<G-vec00180-002-s145><depend.abhängen><de> Es ist klar, dass die Wahl des Ringes und die Wahl des Diamanten, von Ihrem Budget abhängt.
<G-vec00180-002-s145><depend.abhängen><en> Obviously the choice of the ring and the choice of the diamond depend on your budget.
<G-vec00180-002-s146><depend.abhängen><de> Bei Themen wie diesem steht nicht irgendein sonderlicher Aspekt der Kultur auf dem Spiel, sondern ein Komplex von Werten, Forschungen und Verhaltensweisen, von dem viel abhängt für die Zukunft der Menschheit und der Zivilisation.
<G-vec00180-002-s146><depend.abhängen><en> In issues such as these, it is not just some peculiar aspect of culture that is at stake, but a complex set of values, research and behaviour on which the future of mankind and civilization greatly depend.
<G-vec00180-002-s148><depend.abhängen><de> Die persönlichen Informationen, die wir von Ihnen erfassen, über die Umstände der Sammlung und der Art der Dienstleistung abhängt, die Sie anfordern.
<G-vec00180-002-s148><depend.abhängen><en> The personal information we collect from you will depend on the circumstances of collection and service, we ask you to depend on the type.
<G-vec00180-002-s149><depend.abhängen><de> Sie geben auf privatrechtlicher Basis Gelder, deren Verzinsung und Rückzahlung von den Absichten und der finanziellen Situation des Kapitalempfängers abhängt.
<G-vec00180-002-s149><depend.abhängen><en> They are providing funds under private law; interest paid on the capital and the repayment of the capital as such depend on the intentions and financial circumstances of the capital recipient.
<G-vec00180-002-s150><depend.abhängen><de> Den Schüler/innen erklären, dass die Stärke des roten, grünen und gelben Lichts von der Menge der mRNA in der jeweiligen Zelle abhängt.
<G-vec00180-002-s150><depend.abhängen><en> Explain to the students that the red, green and yellow signals of the real microarray depend on the amount of mRNA from those two cells.
<G-vec00180-002-s151><depend.abhängen><de> Im Vertrieb ist es üblich, dass das Einkommen der Vertriebsmitarbeiter stark von der Verkaufsprovision abhängt.
<G-vec00180-002-s151><depend.abhängen><en> In sales it’s common for the income of the sales employees to depend heavily on the sales commission.
<G-vec00180-002-s237><depend.abhängen><de> Es wird nun ganz davon abhängen, wie Boas Ruts Charakter einschätzt: sieht er hier ein unverblümtes Angebot für sexuelle Beziehungen oder etwas Feinsinniges und Tiefgreifendes.
<G-vec00180-002-s237><depend.abhängen><en> Now whether Boaz takes this to be an offer of outright sexual relations or something more subtle and profound will depend on his estimate of Ruth's character.
<G-vec00180-002-s238><depend.abhängen><de> Zudem sind die einzelstaatlichen Vorschriften in Europa sehr unterschiedlich, so dass die Chancen für die Opfer, Schadensersatz zu erlangen, in hohem Maße davon abhängen, in welchem Mitgliedstaat sie wohnen.
<G-vec00180-002-s238><depend.abhängen><en> Moreover, national rules are widely diverging across Europe and, as a result, the chances of victims to obtain compensation greatly depend on which Member State they happen to live in.
<G-vec00180-002-s239><depend.abhängen><de> Davon, so Hayek, könne nicht weniger als das Überleben der Zivilisation abhängen.
<G-vec00180-002-s239><depend.abhängen><en> The survival of civilization, no less, could depend on it, Hayek claimed.
<G-vec00180-002-s240><depend.abhängen><de> Das zwingt mich, einzugestehen, dass das, was ich will, nicht immer durch harte Arbeit erreichbar ist und immer noch davon abhängen muss, ob es von Gott erlaubt ist und ob der Weg, den ich gehe, von Gott vorherbestimmt worden ist.
<G-vec00180-002-s240><depend.abhängen><en> This forced me to admit that what I want is not always achievable through hard work, and must still depend on whether it is allowed by God, and whether the path I walk is the one that has been predestined by God.
<G-vec00180-002-s241><depend.abhängen><de> Regierungen beobachten mit großem Interesse die Aktivitäten der Unternehmen, weil wirtschaftlicher Wohlstand, Beschäftigung, Familieneinkommen, Steuern und soziale Aspekte davon abhängen.
<G-vec00180-002-s241><depend.abhängen><en> Governments are deeply concerned with activity of businesses because economic prosperity, employment, family income, tax revenue and social aspects of a region depend on businesses.
<G-vec00180-002-s242><depend.abhängen><de> Trendige Farben von Frühling - Sommer 2016 Kleidung ist eine ganze Welt der magischen Farben, sondern nur auf Sie, Ihren Geschmack und das Bewusstsein für Mode, wird davon abhängen, wie stilvoll und organisch wiederum das ausgewählte Bild.
<G-vec00180-002-s242><depend.abhängen><en> Trendy colors of spring - summer 2016 clothing is a whole world of magical colors, but only on you, your taste and awareness of fashion, will depend on how stylish and organic turn the selected image.
<G-vec00180-002-s243><depend.abhängen><de> Wenn ein Fehler erfaßt wird, wird dann bestimmt, ob der Fehler korrigierbar ist, und zwar in Schritt 1370, was davon abhängen wird, wie viele Bits beeinflußt sind.
<G-vec00180-002-s243><depend.abhängen><en> If an error is detected it is then determined whether the error is correctable at stage 1370, which will depend on how many bits are affected.
<G-vec00180-002-s244><depend.abhängen><de> Mittelfristig werden die Kosten für den Umbau hin zu Open Access stark davon abhängen, ob es gelingt, national und international gemeinsame Verhandlungspositionen gegenüber den großen Verlagshäusern aufzubauen.
<G-vec00180-002-s244><depend.abhängen><en> In the medium term, the costs of restructuring towards Open Access will depend heavily on whether joint negotiating positions vis-à-vis the major publishing houses can be established nationally and internationally.
<G-vec00180-002-s245><depend.abhängen><de> Ihre Wahl soll davon abhängen, was für Berechnungen Sie zu machen planen.
<G-vec00180-002-s245><depend.abhängen><en> Your choice should depend on what you are using a calculator for, and what kind of calculations you plan on doing.
<G-vec00180-002-s246><depend.abhängen><de> Wenn Sie sich fragen, ob Sie von der ersten Generation AMD Ryzen upgraden sollten, wird dies wahrscheinlich davon abhängen, wie teuer Sie Ihre aktuelle CPU werden verkaufen können.
<G-vec00180-002-s246><depend.abhängen><en> If you are wondering whether you should upgrade from AMD Ryzen's first generation, I think it will depend on how much your existing CPU is selling for.
<G-vec00180-002-s247><depend.abhängen><de> Es kann sein, dass ein Grund (neben der chemischen Sucht), dass Zigarettenrauchen trotz seiner bewährten Bedrohung für die Gesundheit populär geblieben ist, dass Millionen von Menschen davon abhängen für emotionale Stabilität; Seine Rhythmen des atmenden Rauches sind in die Gewohnheit eingebettet.
<G-vec00180-002-s247><depend.abhängen><en> It may be that one reason (besides the chemical addiction) that cigarette smoking has remained popular despite its proven threat to health is that millions of people depend on it for emotional stability; its rhythms of breathing smoke have become embedded in habit.
<G-vec00180-002-s248><depend.abhängen><de> Verarbeitung, Transport, Kühlung, Erhitzung, Zubereitung und Entsorgung von Lebensmitteln hinzugerechnet, die der IPCC in anderen Sektoren verbucht, ergibt, dass über 40% aller Emissionen davon abhängen, wie wir uns ernähren und Landwirtschaft betreiben.
<G-vec00180-002-s248><depend.abhängen><en> If the processing of food, its transport, storage, cooling and disposal are added, which the IPCC ascribes to other sectors, more than 40% of all emissions depend on the way we farm and eat.
<G-vec00180-002-s249><depend.abhängen><de> Der potentielle klinische Nutzen der Fettsäureszintigraphie wird erheblich davon abhängen, inwieweit es gelingt, unterschiedliche Fettsäure-Verwertungsmuster mit der individuellen Prognose eines Patienten zu korrelieren.
<G-vec00180-002-s249><depend.abhängen><en> The potential clinical benefit of fatty acid scintigraphy will largely depend on the definition of different fatty acid utilization patterns and the correlation of these utilization patterns with the prognosis of individual patients.
<G-vec00180-002-s250><depend.abhängen><de> Es ist meine feste Überzeugung, dass der Erfolg dieser Reform am Ende maßgeblich davon abhängen wird, dass auch der Sicherheitsrat reformiert wird.
<G-vec00180-002-s250><depend.abhängen><en> I am firmly convinced that the ultimate success of these reforms will largely depend on the reform of the Security Council.
<G-vec00180-002-s251><depend.abhängen><de> Wie dieser Mechanismus auch heißen mag, sei es Ehe für Alle, Eingetragene Lebensgemeinschaft or etwas anderes, wird davon abhängen, was unsere Revolutionäre vorschlagen und von unserer Fähigkeit, Hindernisse zu überwinden, die sich uns in den Weg stellen.
<G-vec00180-002-s251><depend.abhängen><en> What this mechanism is called, whether it's same-sex marriage, consensual union, or something else, will depend on what our revolutionaries suggest and our ability to overcome the obstacles in our way.
<G-vec00180-002-s252><depend.abhängen><de> Insbesondere stellen wir fest, dass die zunehmende Nutzung dieser Technologie davon abhängen wird, ob Verbraucher den neuen digitalen Informationsquellen vertrauen oder nicht.
<G-vec00180-002-s252><depend.abhängen><en> In particular, we observe that any increase in the use of this technology will depend on whether or not consumers trust these new digital sources of information.
<G-vec00180-002-s253><depend.abhängen><de> Scheinbar witzig, aber gar nicht komisch, wenn das Asyl und damit das Leben davon abhängen kann.
<G-vec00180-002-s253><depend.abhängen><en> This may sound funny, but it's not at all funny, when asylum and therewith one's life can depend on it.
<G-vec00180-002-s254><depend.abhängen><de> Auch sollte die Bilanzierung nicht davon abhängen, welches Konzernunternehmen einen Geschäftsvorfall mit einem ausländischen Teilbetrieb eingeht [IAS 21.15A].
<G-vec00180-002-s254><depend.abhängen><en> [IAS 21.33] Also, the accounting should not depend on which entity within the group conducts a transaction with the foreign operation.
<G-vec00180-002-s255><depend.abhängen><de> Wichtig hierbei ist vor allem das weiterreichen der Fackel, das Bestehen des Projekts wird davon abhängen wie viele Spieler wir letztlich an unserem Tiefpunkt auf das Projekt einschwören können und nicht wie viele wir zu unseren größten Stoßzeiten sind.
<G-vec00180-002-s255><depend.abhängen><en> It is important above all to pass on the torch, the existence of the project will depend on how many players we can einschwören at our lowest point on the project ultimately and not how many we are one of our biggest peak hours.
<G-vec00180-002-s267><depend.abhängen><de> Das heißt, dass die Höhe des Gewichts, das Sie zunehmen sollten, davon abhängt, wie viel Sie gewogen haben, bevor Sie schwanger wurden.
<G-vec00180-002-s267><depend.abhängen><en> The amount of weight you should gain will depend on how heavy you were before you became pregnant.
<G-vec00180-002-s268><depend.abhängen><de> Wir verstärken unsere Offenheit anderen gegenüber, die Ausdruck bedingungsloser, konstanter Zuneigung ist, die nicht davon abhängt, was wir zurückbekommen.
<G-vec00180-002-s268><depend.abhängen><en> We become more open to others as an expression of constant, unconditional affection which does not depend on what we get in return.
<G-vec00180-002-s269><depend.abhängen><de> Beim Abrutschen auf sie kann sie so viel Pollen und Honig wie möglich sammeln, denn der Erfolg ihrer Missionen davon abhängt.
<G-vec00180-002-s269><depend.abhängen><en> What's more, sliding down them you will be able to gather pollen and honey, because the success of its missions depend on them.
<G-vec00180-002-s270><depend.abhängen><de> Die möglichst gleichmäßige Chlorung ist für die Reduktion Eine ausreichende Filterbettausdehnung ist für die Reinigung unbedingt erforderlich, da das Ausspülen von geflockten Substanzen und grob-dispersen Stoffen davon abhängt.
<G-vec00180-002-s270><depend.abhängen><en> The WAPOTEC solution: WAPOTEC®Consulting Sufficient filter bed expansion is imperative for cleaning because the rinsing of flocked substances and coarsely dispersed substances depend on it.
<G-vec00180-002-s271><depend.abhängen><de> Denke daran auch, dass sehr viel davon abhängt, welche Klasse Du hast – Umso kleiner der Preis, desto höher die Wahrscheinlichkeit, dass Du ausschließlich ein Handgepäck mitnehmen darfst, das für gewöhnlich nur ein nicht großer Koffer ist, dessen Breite, Länge und Höhe sich zu 115 cm summieren.
<G-vec00180-002-s271><depend.abhängen><en> Don't forget that a lot depend on the class – the cheaper it is, the higher the probability that you can carry with you only carry-on luggage, which usually turns out to be a small suitcase with the size adding up to 115 cm.
<G-vec00180-002-s272><depend.abhängen><de> Dies ist die allgemeine Atmosphäre der Familie, die notwendigerweise davon abhängt, wer neben Ihrem Kind ist.
<G-vec00180-002-s272><depend.abhängen><en> This is the general atmosphere of the family, which will necessarily depend on who is next to your child.
<G-vec00180-002-s273><depend.abhängen><de> Surfer müssen super fit sein, weil ihr Leben davon abhängt die Riesenwellen zu überleben, die sie immer wieder von ihrem Board fegen.
<G-vec00180-002-s273><depend.abhängen><en> Surfers have to be super fit because their lives depend on being able to survive giant waves crashing them off their boards.
<G-vec00180-002-s274><depend.abhängen><de> Es ist praktisch unmöglich, für Server-Installationen generelle Speicher- oder Festplattenplatzanforderungen anzugeben, da dies sehr davon abhängt, wozu der Server verwendet wird.
<G-vec00180-002-s274><depend.abhängen><en> It is practically impossible to give general memory or disk space requirements for server installations as those very much depend on what the server is to be used for.
<G-vec00180-002-s275><depend.abhängen><de> Die Reformen sind ein unbestreitbares Element der Veränderungen, und zwar eines, das nicht davon abhängt, wer mit der Leitung der Organisation betraut ist.
<G-vec00180-002-s275><depend.abhängen><en> The reforms are an undeniable element of change – and one that doesn’t depend on who’s in charge of the organisation.
<G-vec00180-002-s276><depend.abhängen><de> Es hängt von der Qualität der Muttermilch ab, dass die Gesundheit des Babys davon abhängt, also sollten Sie darauf achten, dass die Kalorien im Essen nicht nur für die Mutter, sondern auch für das Baby ausreichen.
<G-vec00180-002-s276><depend.abhängen><en> It is on the quality of breast milk that the health of the baby will depend, so you should take care that the calories in the food are enough not only for mom, but for the baby.
<G-vec00180-002-s293><depend.abhängen><de> Die individuellen Holons oder Spielsteine der Ebene 1 (das beige Meme) hängen in ihrer Existenz von den Beziehungsnetzwerken mit allen anderen beigen Spielsteinen ihrer Umgebung ab, das heißt von den Netzwerken ihrer eigenen sozialen Holons (die Co-Evolution von micro und macro).
<G-vec00180-002-s293><depend.abhängen><en> Now, the individual holons or checkers on level 1 (the beige meme) depend for their existence on intricate networks of interrelationships with all the other beige checkers in their environment—depend, that is, on networks of their own social holons (the co evolution of micro and macro).
<G-vec00180-002-s294><depend.abhängen><de> Da gibt es diese kleinen Dinge...Gegenstände...im Alltag, die unser Leben begleiten...still und leise...hängen wir an ihnen...sie geben uns ein Stück Beständigkeit in den Turbulenzen des Alltags.
<G-vec00180-002-s294><depend.abhängen><en> There are these little things... objects that accompany us into our life... quietly... we depend on them... they give us a bit of stability in the turmoil of everyday life.
<G-vec00180-002-s295><depend.abhängen><de> Die Schönheit und gesundes Aussehen hängen nicht nur von der richtigen Pflege für sich selbst, sondern auch von der Qualität der verwendeten Kosmetik.
<G-vec00180-002-s295><depend.abhängen><en> Beauty and healthy appearance depend not only on the correct care of themselves, but also on the quality use of cosmetics.
<G-vec00180-002-s296><depend.abhängen><de> Diese Ressourcen hängen stark mit Erfahrungen der Anerkennung zusammen, die zum Teil im primären (d.h. familiären und peers-) Umfeld erlebt wurden.
<G-vec00180-002-s296><depend.abhängen><en> These resources strongly depend on experiences with recognition, which have partially been made by these individuals in the primary environment, such as in the family or amongst peers.
<G-vec00180-002-s297><depend.abhängen><de> Zahlreiche Arbeitsplätze hängen daran“.
<G-vec00180-002-s297><depend.abhängen><en> Many jobs depend on it".
<G-vec00180-002-s298><depend.abhängen><de> Die Leerlaufspannung und der Füllfaktor der hergestellten Solarzellen hängen stark von der Passivierung der Waferoberlfäche ab, wobei beide Hellkennlinienparameter durch eine optimierte Hot-wire Wasserstoffbehandlung des Substrats vor der Emitterdeposition hohe stabile Werte erreichen.
<G-vec00180-002-s298><depend.abhängen><en> The open circuit voltage as well as the fillfactor of the solar cells depend strongly on the surface passivation of the substrate and by using appropriate Hot-wire hydrogen treatment prior emitter deposition both parematers reach reproducible high values.
<G-vec00180-002-s299><depend.abhängen><de> Zusätzlich zu ihrer Kamera hängen Hochzeitsfotografen auf unterstützende Ausrüstung einschließlich Stative, Objektive, Blitzgeräte, Beleuchtung und Filter, um eine beabsichtigte Wirkung zu sammeln.
<G-vec00180-002-s299><depend.abhängen><en> In addition to their camera, wedding photographers depend on supportive equipment including tripods, lenses, flashes, lighting and filters to garner an intended effect.
<G-vec00180-002-s300><depend.abhängen><de> [Knochenbrüche hängen auch von der Blutgruppe ab: Die Blutgruppen A und AB haben mehr, die Blutgruppe 0 an wenigsten Knochenbrüche, siehe Blutgruppenmedizin von Dr. D'Adamo].
<G-vec00180-002-s300><depend.abhängen><en> [Bone fractures depend also from the blood groups: Blood groups A and AB have more, blood group 0 have least of all bone fractures, look blood group medicine from Dr. D'Adamo].
<G-vec00180-002-s301><depend.abhängen><de> Denn Tugend und Laster hängen nicht an dieser oder jener Art des Menschen zu sein, sind nicht mit dieser oder jener Charakterseite nothwendig verbunden; sondern es kommt in Rücksicht auf sie weit mehr auf die Harmonie oder Disharmonie der verschiedenen Charakterzüge, auf das Verhältniss der Kraft zu der Summe der Neigungen u. s. f. an.
<G-vec00180-002-s301><depend.abhängen><en> For virtue and vice do not depend on any particular form of being, nor are necessarily connected with any particular aspect of character; in regard to these, much more depends on the harmony or discordancy of all the different features of a man’s character—on the proportion that exists between power and the sum of inclinations, etc.
<G-vec00180-002-s302><depend.abhängen><de> Fast alle Unternehmen in der Metropolitanregion Basel hängen direkt oder indirekt von der Fortsetzung der metrobasler Erfolgsgeschichte in Life Sciences ab.
<G-vec00180-002-s302><depend.abhängen><en> Nearly all the businesses in the Basel metropolitan region depend directly or indirectly on the continuation of the metrobasel life-sciences success story.
<G-vec00180-002-s303><depend.abhängen><de> Die AP1 Pedale Receiver bietet Rezeption, Sie können immer hängen und ist konzipiert für den Einsatz mit kompakten Effektpedale.
<G-vec00180-002-s303><depend.abhängen><en> The AP1 pedal receiver provides reception you can always depend on and is designed for use with compact effect pedals.
<G-vec00180-002-s304><depend.abhängen><de> Im TV bleibe ich, während der Vorbereitung auf den Eingriff auf einem Sportkanal hängen, kurz darauf kommt David erneut in den Raum, und ist fassungslos, eine Frau, die sich ernsthaft für Fußball interessiert und sich auch noch auskennt.
<G-vec00180-002-s304><depend.abhängen><en> On TV I stay, during the preparation depend on the intervention to a sports channel, shortly after David comes back into the room, and is stunned, a woman who is seriously interested in football and also familiar.
<G-vec00180-002-s305><depend.abhängen><de> Das heißt, viele Jury-Entscheidungen, insbesondere von FIS Chief-Racedirektor Markus Waldner und HKR-Rennleiter Axel Naglich, hängen direkt oder indirekt mit den Vorhersagen zusammen.
<G-vec00180-002-s305><depend.abhängen><en> Jury decisions, especially those made by FIS Chief Race Director Markus Waldner and HKR Race Director Axel Naglich depend both indirectly and directly on the weather prognosis.
<G-vec00180-002-s306><depend.abhängen><de> An ihnen hängen eine Million Arbeitsplätze.
<G-vec00180-002-s306><depend.abhängen><en> A million jobs depend on them.
<G-vec00180-002-s307><depend.abhängen><de> Technische Daten hängen bei Lackdrähten sehr oft vom Durchmesser des Drahtes (Dimension) ab.
<G-vec00180-002-s307><depend.abhängen><en> Technical values of magnet wires often depend on the diameter of the wire.
<G-vec00180-002-s308><depend.abhängen><de> Die Bedingungen, unter denen ein Tier an das Tierheim geliefert wird, hängen wesentlich von dem Zustand ab, in dem es sich befindet.
<G-vec00180-002-s308><depend.abhängen><en> The conditions in which an animal is delivered to the shelter depend substantially on the state in which it is located.
<G-vec00180-002-s309><depend.abhängen><de> Die meisten Leute in Büros hängen stark von Outlook-Profil 2007 ab, um E-Mails zu senden, Aufgaben zu organisieren, Notizen zu machen und andere Aktivitäten zu verwalten.
<G-vec00180-002-s309><depend.abhängen><en> Most people in offices depend heavily on Outlook profile 2007 to send emails, organize task, make notes, and manage other activities.
<G-vec00180-002-s310><depend.abhängen><de> Die Prämien hängen ja nicht nur von der Versicherungssumme, also vom Wert des Objekts ab, sondern vor allem auch von den Sicherheitsstandards, die der Besitzer im Gebäude und dessen Umgebung schafft.
<G-vec00180-002-s310><depend.abhängen><en> The premiums depend of course not just on the amount insured – in other words, the value of the object – but also, and primarily, on the security standards that the owner establishes in the building and its environs.
<G-vec00180-002-s311><depend.abhängen><de> Der Kraftstoffverbrauch und die CO2-Emissionen eines Fahrzeugs hängen nicht nur von der effizienten Ausnutzung des Kraftstoffs durch das Fahrzeug ab, sondern werden auch vom Fahrverhalten und anderen nicht technischen Faktoren beeinflusst.
<G-vec00180-002-s311><depend.abhängen><en> The fuel consumption and CO2 emissions of a vehicle not only depend on the efficient utilization of the fuel by the vehicle, but are also influenced by driving style and other non-technical factors.
<G-vec00180-002-s312><depend.abhängen><de> Diese hängen teilweise vom Status des bereits in Deutschland lebenden Familienmitglieds ab.
<G-vec00180-002-s312><depend.abhängen><en> These will depend in part on the status of the family member already living in Germany.
<G-vec00180-002-s313><depend.abhängen><de> Auf Zeitskalen von einigen Jahren bis zu mehreren Jahrzehnten, hängen Klima und Wetter nicht nur vom anthropogenen Anstieg der Treibhausgaskonzentrationen ab, sondern auch von der natürlichen Klimavariabilität.
<G-vec00180-002-s313><depend.abhängen><en> On timescales of several years to several decades, weather and climate patterns depend not only on the anthropogenic rise of greenhouse gas concentrations in the atmosphere, but also on natural climate variability.
<G-vec00180-002-s314><depend.abhängen><de> Die Plätze werden von den Oberkellnern zugewiesen; sie hängen nicht von der Zeit Ihres Eintreffens ab.
<G-vec00180-002-s314><depend.abhängen><en> Seats are allocated by the maîtres d’hôtels; they do not depend on the time at which you arrive.
<G-vec00180-002-s315><depend.abhängen><de> Vor allem sind sie von ähnlichen Rezeptoren betroffen, und sie hängen stark voneinander ab.
<G-vec00180-002-s315><depend.abhängen><en> First of all, they are affected by similar receptors, and they strongly depend on each other.
<G-vec00180-002-s316><depend.abhängen><de> Kommunikation und Zusammenarbeit hängen stark vom gesprochenen Wort ab, daher war Raumakustik und Sprachverständlichkeit an jedem Platz ein zentrales Anliegen.
<G-vec00180-002-s316><depend.abhängen><en> Communication and collaboration depend heavily on the spoken word, so a key concern was room acoustics and speech intelligibility at each seat.
<G-vec00180-002-s317><depend.abhängen><de> Die Lieferzei bei internationalen Paket- und Palettensendungen hängen stark von der Sendung und dem gewünschten Versanddienst ab.
<G-vec00180-002-s317><depend.abhängen><en> As the delivery time for international shippings depend on the services, we cannot inform you about usual delivery times.
<G-vec00180-002-s318><depend.abhängen><de> Die vorherrschenden Meinungen der Bevölkerung zum Thema Zuwanderung sind selten eindeutig und hängen von demographischen Faktoren, Milieus, Zeitpunkten, Kontexten und Orten ab.
<G-vec00180-002-s318><depend.abhängen><en> The population’s dominant views on immigration are rarely clear and depend on a variety of demographic factors, environments, times, contexts, and locations.
<G-vec00180-002-s319><depend.abhängen><de> Die Anzahl der Administratoren und die Granularität der Berechtigungen hängen im Allgemeinen von der Größe und Komplexität der Bereitstellung ab.
<G-vec00180-002-s319><depend.abhängen><en> The number of administrators and the granularity of their permissions generally depend on the size and complexity of the deployment.
<G-vec00180-002-s320><depend.abhängen><de> Typischerweise hängen Größen wie die Wärmeleitfähigkeit und die Umwandlungswärme bei Phasenübergängen nicht nur von der Temperatur sondern auch von der jeweiligen Phase ab.
<G-vec00180-002-s320><depend.abhängen><en> Typically, quantities like heat conductivity or the latent heat released or consumed during phase transitions do not only depend on temperature but also on the respective phase.
<G-vec00180-002-s321><depend.abhängen><de> «Der Erfolg und die Verbreitung einer App hängen nicht zuletzt von der Verfügbarkeit verschiedener Zahlungsmethoden ab.
<G-vec00180-002-s321><depend.abhängen><en> “An app’s success and popularity partly depend on the availability of different payment methods.
<G-vec00180-002-s322><depend.abhängen><de> Die für Sie möglichen Behandlungsarten hängen teilweise von den spezifischen Eigenschaften Ihres Gebärmutterhalskrebses ab.
<G-vec00180-002-s322><depend.abhängen><en> The treatments available to you will depend, in part, on the specific characteristics of your cervical cancer.
<G-vec00180-002-s323><depend.abhängen><de> In dieser Situation hängen die Ergebnisse der Cursor-Aktionen von der Cursor-Sensitivität ab.
<G-vec00180-002-s323><depend.abhängen><en> The results of the cursor actions in this situation depend on the cursor sensitivity:
<G-vec00180-002-s324><depend.abhängen><de> Datenrettungsergebnisse von Ext3/Ext4 Systemen hängen außerordentlich von der Zeitschriftengröße und die Zeit ab, für die das System nach der Dateilöschung gearbeitet hat.
<G-vec00180-002-s324><depend.abhängen><en> Data recovery results from Ext3/Ext4 systems depend greatly on the journal size and the time the system worked after file deletion for.
<G-vec00180-002-s325><depend.abhängen><de> Der Spritverbrauch und damit die CO2-Emissionen hängen im „echten Leben“ von vielen Faktoren ab.
<G-vec00180-002-s325><depend.abhängen><en> “In real life” fuel consumption, and with it CO2 emissions, depend on many factors.
<G-vec00180-002-s326><depend.abhängen><de> Auch jetzt in dieser fortgeschrittenen Zeit viele Menschen hängen von der Eingabeaufforderung, um bestimmte Aufgaben zu erfüllen.
<G-vec00180-002-s326><depend.abhängen><en> Even now in this advanced era many people depend upon command prompt to accomplish certain tasks.
<G-vec00180-002-s327><depend.abhängen><de> Unsere Beratungspreise hängen auch von Arbeitsumfang und Größe Ihres Unternehmens.
<G-vec00180-002-s327><depend.abhängen><en> Our consulting prices also depend on the scope of work and size of your business.
<G-vec00180-002-s328><depend.abhängen><de> Preise hängen auch von der Motorleistung des Fahrzeugs.
<G-vec00180-002-s328><depend.abhängen><en> Rates also depend on the engine power of the vehicle.
<G-vec00180-002-s329><depend.abhängen><de> Die Vorteile hängen von wer ist der Arbeitgeber (öffentlich oder privat) und das Niveau der Vereinbarung.
<G-vec00180-002-s329><depend.abhängen><en> The benefits depend on who is the employer (public or private) and level of appointment.
<G-vec00180-002-s330><depend.abhängen><de> Erfolgreiche Implementation des Informationssystems, wie auch erwartete Effekte, hängen vor allem von den qualitativen und präzis definierten Ansprüchen.
<G-vec00180-002-s330><depend.abhängen><en> A successful implementation of an information system, as well as the expected effects, first of foremost depend on accurately and well-defined requirements.
<G-vec00180-002-s331><depend.abhängen><de> Diese Werte hängen von der Natur des Gegenstands oder Produkts, das parfümiert werden soll, und der hierfür gesuchten Geruchswirkung sowie der Natur der Co-Bestandteile in einer gegebenen Zusammensetzung, wenn die Verbindungen im Gemisch mit Duftcobestandteilen, Lösemitteln oder Ajuvantien, die derzeit einschlägig verwendet werden, verwendet werden, ab.
<G-vec00180-002-s331><depend.abhängen><en> These values depend on the nature of the article or product that one desires to perfume and the odor effect searched for, as well as on the nature of the co-ingredients in a given composition when the compounds are used in admixture with perfuming co-ingredients, solvents or adjuvants of current use in the art.
<G-vec00180-002-s332><depend.abhängen><de> (9) Die Emissionen und der Abbau von Treibhausgasen im Zusammenhang mit Waldflächen hängen von einer Reihe natürlicher Umstände, der Altersklassenstruktur sowie der früheren und gegenwärtigen Bewirtschaftungspraxis ab, die sich von Mitgliedstaat zu Mitgliedstaat erheblich unterscheidet.
<G-vec00180-002-s332><depend.abhängen><en> (9) Emissions and removals from forest land depend on a number of natural circumstances, age-class structure, as well as past and present management practices that differ substantially between the Member States.
<G-vec00180-002-s333><depend.abhängen><de> Die Preise hängen von der Zeit des Jahres, haben einen tieferen Blick auf den Kalender, in dem Sie die verschiedenen Preiskategorien sehen können.
<G-vec00180-002-s333><depend.abhängen><en> The prices depend on the time of the year, have a deeper look on the calendar, where you can see the different price categories.
<G-vec00180-002-s334><depend.abhängen><de> «Zeitpunkt, Umfang und Struktur einer Finanzierung hängen von der Verfassung der Finanzmärkte und dem Investoreninteresse ab», sagte CFO Welten.
<G-vec00180-002-s334><depend.abhängen><en> "The timing, final amount and structure of the fund raising will depend on market conditions and investors' demand," said Harry Welten, Chief Financial Officer.
<G-vec00180-002-s335><depend.abhängen><de> Die Kosten hängen von der Größe und dem Gewicht der gesamten Bestellung.
<G-vec00180-002-s335><depend.abhängen><en> The costs depend on the size and weight of the total order.
<G-vec00180-002-s336><depend.abhängen><de> (3) Externe Strategien hängen von der gleichen Kontextvariable ab: Wenn regulative Initiativen als Chance wahrgenommen werden, wird Konsens-orientierten Strategien wie Information, konstruktive Verhandlung und Partnerschaft eine größere Bedeutung beigemessen.
<G-vec00180-002-s336><depend.abhängen><en> (3) Externally directed responses depend on the same contextual variable: If regulatory initiatives are perceived as an opportunity, consensus-oriented strategies of information, negotiation, and partnering dominate.
<G-vec00180-002-s337><depend.abhängen><de> Häufige Nebenwirkungen von Chemotherapie hängen von der Art des verwendeten Arzneimittels, Dosierung und Dauer der Behandlung .
<G-vec00180-002-s337><depend.abhängen><en> Side effects of chemotherapy depend on the type of drug used, dosage, and length of treatment.
<G-vec00180-002-s338><depend.abhängen><de> Ihre Arbeitsstunden (heures de travail) hängen von Ihrem Arbeitgeber, Ihrem Job und Ihrer Branche ab.
<G-vec00180-002-s338><depend.abhängen><en> Your working hours (Arbeitsstunden - horaire de travail) depend on your employer, your job and the industry you work in.
<G-vec00180-002-s339><depend.abhängen><de> Die gezeigten Zahlen sind Annäherungen und hängen von der Kategorie und dem Verkehrstyp ab.
<G-vec00180-002-s339><depend.abhängen><en> The demonstrated numbers shown are approximate and depend on the category and type of traffic.
<G-vec00180-002-s340><depend.abhängen><de> Anwendungen hängen von der Organisation.
<G-vec00180-002-s340><depend.abhängen><en> Applications depend on the organization.
<G-vec00180-002-s341><depend.abhängen><de> Programmkosten hängen von der jeweiligen Institution und Faktoren wie Geographie.
<G-vec00180-002-s341><depend.abhängen><en> Program costs depend on the particular institution and factors such as geography.
<G-vec00180-002-s342><depend.abhängen><de> Ja, Versand- und Bearbeitungsgebühren hängen von der gewählten Versandart ab.
<G-vec00180-002-s342><depend.abhängen><en> Yes, shipping and handling charges depend upon the shipping preference.
<G-vec00180-002-s343><depend.abhängen><de> Diese Leseanforderungen hängen von dem Volume Snapshot.
<G-vec00180-002-s343><depend.abhängen><en> These read requests depend on the snapshot volume.
<G-vec00180-002-s344><depend.abhängen><de> Mehrere Räuber der Tundra hängen von dominanten Lemming.
<G-vec00180-002-s344><depend.abhängen><en> Several predators of tundra depend on dominative lemming.
<G-vec00180-002-s345><depend.abhängen><de> Rund 30% des Karriereerfolgs hängt jedoch von der Positionierung und damit vom Selbstmarketing ab, so die Expertin Sylvia Nickel.
<G-vec00180-002-s345><depend.abhängen><en> Approximately 30% of career success depend however on the positioning and thus on self marketing, so the Expertin Sylvia nickel.
<G-vec00180-002-s346><depend.abhängen><de> Daneben hängt der Effekt aber auch noch mit anderen Gewebeeigenschaften zusammen, etwa mit der Dicke der Nervenfasern und der umhüllenden Myelinscheide, wie die Forscher mithilfe von Simulationen am ehemaligen Jülicher Supercomputer JUQUEEN zeigen konnten.
<G-vec00180-002-s346><depend.abhängen><en> Using simulations on the former Jülich supercomputer JUQUEEN, the researchers could show that the observed effects also depend on other tissue properties like the diameter of the fibres or the thickness of the myelin sheaths.
<G-vec00180-002-s347><depend.abhängen><de> Die Wahl hängt ganz von Ihren Vorlieben und Fähigkeiten.
<G-vec00180-002-s347><depend.abhängen><en> The choice will depend entirely on your preferences and capabilities.
<G-vec00180-002-s348><depend.abhängen><de> Ob Mehrweg Glas oder Mehrweg PET umweltfreundlicher ist, hängt mit den Transportwegen zusammen: Je länger die Wege, die die Flasche zurücklegt, desto mehr spielt das Gewicht der Flasche eine große Rolle für den Energieverbrauch.
<G-vec00180-002-s348><depend.abhängen><en> Whether returnable glass or returnable PET is eco-friendlier will depend on the transportation routes involved: the longer the distances the bottle has to travel, the more significant the weight of the bottle will become for the energy consumption.
<G-vec00180-002-s349><depend.abhängen><de> 40 An diesen zwei Geboten hängt das ganze Gesetz und die Propheten.
<G-vec00180-002-s349><depend.abhängen><en> 40 All the Law and the Prophets depend on these two commandments."
<G-vec00180-002-s350><depend.abhängen><de> Die Länge und die Dicke der Stränge hängt nur von der Vision des Endergebnisses.
<G-vec00180-002-s350><depend.abhängen><en> The length and thickness of strands will depend only on the vision of the end result.
<G-vec00180-002-s351><depend.abhängen><de> "Ach, an was für kleinen Dingen das Glück hängt.
<G-vec00180-002-s351><depend.abhängen><en> “Ah, on what little things does happiness depend!
<G-vec00180-002-s352><depend.abhängen><de> Mithilfe der drei integrierten ACPI- Funktionstasten kann man schnell veranlassen, dass sich das System an dem die Tastatur hängt, in einen Schlafmodus (=Energiesparmodus) begibt, herunterfährt oder wieder aufgeweckt werden kann.
<G-vec00180-002-s352><depend.abhängen><en> Use of the three integrated ACPI function keys you can cause fastly that the system on which the keyboard will depend, goes to a sleep mode (= power save mode), goes down or can be awakened again.
<G-vec00180-002-s353><depend.abhängen><de> Die beiden Gebote, an denen »das ganze Gesetz hängt samt den Propheten« (Mt 22, 40), sind zutiefst miteinander verbunden und durchdringen sich gegenseitig.
<G-vec00180-002-s353><depend.abhängen><en> These two commandments, on which "depend all the Law and the Prophets" (Mt 22:40), are profoundly connected and mutually related.
<G-vec00180-002-s355><depend.abhängen><de> Wissmann betonte: „Ein großer Teil der insgesamt rund 800.000 Arbeitsplätze der Automobilindustrie am Standort Deutschland hängt am Diesel – gerade auch bei Zulieferern.
<G-vec00180-002-s355><depend.abhängen><en> Wissmann stressed: “A large proportion of the total of around 800,000 jobs in the automotive industry in Germany depend on diesels – and especially at the suppliers.
<G-vec00180-002-s356><depend.abhängen><de> Die Entscheidung, die eine oder andere Prothese zu implantieren, hängt grundsätzlich von den finanziellen Möglichkeiten des Patienten ab.
<G-vec00180-002-s356><depend.abhängen><en> The decision to implant one prosthesis or another will basically depend on the economic possibilities of the patient
<G-vec00180-002-s357><depend.abhängen><de> Die Breite eines solchen Rahmens hängt direkt von der Größe des Raumes ab.
<G-vec00180-002-s357><depend.abhängen><en> The width of such a frame will depend directly on the size of the room.
<G-vec00180-002-s358><depend.abhängen><de> Die Höhe der Entlohnung hängt nicht nur von der Menge der geleisteten Arbeit ab, sondern ebenfalls von der Bewertung, die wir von unseren Kunden erhalten.
<G-vec00180-002-s358><depend.abhängen><en> The amount of employee compensation does not depend only on the amount of work but also on the evaluation we receive from our clients.
<G-vec00180-002-s359><depend.abhängen><de> “Unsere gesamte natürliche Umgebung hängt praktisch von der Interaktion zwischen Bestäubern und Pflanzen ab.
<G-vec00180-002-s359><depend.abhängen><en> “All our natural environments virtually depend on the interaction between pollinators and plants.
<G-vec00180-002-s360><depend.abhängen><de> Jedoch hängt die tatsächliche Farbe, die Sie sehen, von Ihren Computereinstellungen ab, und wir können nicht garantieren, dass Ihr Computer unsere Farben genau wiedergibt.
<G-vec00180-002-s360><depend.abhängen><en> However, the actual color you see will depend on your computer settings and we cannot guarantee that your computer will accurately display our colors.
<G-vec00180-002-s361><depend.abhängen><de> Der Preis hängt von Textart und Schwierigkeitsgrad ab.
<G-vec00180-002-s361><depend.abhängen><en> Prices depend on type of text and level of difficulty.
<G-vec00180-002-s362><depend.abhängen><de> Die Veranstalter beschlossen, diese jungen Menschen zu Wort kommen zu lassen, denn von ihrem Engagement und ihrer Arbeit hängt die Zukunft der polnischen Medizin ab.
<G-vec00180-002-s362><depend.abhängen><en> Event coordinators decided to let their voices be heard, since the future of Polish medicine will depend on their involvement and effort.
<G-vec00180-002-s363><depend.abhängen><de> Der Erfolg Ihrer Video-Optimierung hängt stark von der Art der App ab, die Sie gewählt haben.
<G-vec00180-002-s363><depend.abhängen><en> The success of your video enhancement mission will depend a lot on the type of app you have chosen.
<G-vec00180-002-s364><depend.abhängen><de> Die Qualität und Leistung dieser Teile hängt stark von ihrem mechanischen Verhalten ab.
<G-vec00180-002-s364><depend.abhängen><en> The quality and performance of these parts depend highly on their mechanical behaviour.
<G-vec00180-002-s365><depend.abhängen><de> Und es zeigte sich, daß dies eine Hoffnung gegen die Freiheit ist, denn der Zustand der menschlichen Dinge hängt in jeder Generation neu von der freien Entscheidung dieser Menschen ab.
<G-vec00180-002-s365><depend.abhängen><en> It has also become clear that this hope is opposed to freedom, since human affairs depend in each generation on the free decisions of those concerned.
<G-vec00180-002-s366><depend.abhängen><de> Ob sich Software bezahlt macht, hängt nicht nur von ihren Features ab.
<G-vec00180-002-s366><depend.abhängen><en> Whether software pays for itself does not depend solely on its features.
<G-vec00180-002-s367><depend.abhängen><de> Von der Rasse hängt ihre Anzahl in keiner Weise ab.
<G-vec00180-002-s367><depend.abhängen><en> From the breed, their number does not depend in any way.
<G-vec00180-002-s368><depend.abhängen><de> 0 Schönheit und Sport Haarausfall, Schuppen, Spliss und 5 weitere Probleme mit dem Haar während der Schwangerschaft Von dem, was wir uns im Spiegel sehen, hängt unsere Stimmung und unser Wohlbefinden weitgehend ab.
<G-vec00180-002-s368><depend.abhängen><en> 0 Beauty and sports Hair loss, dandruff, split ends and 5 more problems with hair during pregnancy From what we see ourselves in the mirror, our mood and well-being largely depend.
<G-vec00180-002-s369><depend.abhängen><de> Was die Tiefe betrifft, überschreitet sie normalerweise 0,5 - 0,6 m nicht, aber wenn das eingebaute Modell die Türen zur Umkleidekabine öffnet, hängt seine Dimension von den Möglichkeiten der Räumlichkeiten und den Wünschen der Eigentümer ab.
<G-vec00180-002-s369><depend.abhängen><en> As for the depth, it usually does not exceed 0,5-, 0,6 m. But if the built-in model opens the doors to the dressing room, its dimensions depend on the possibilities of the premises and the wishes of the owners.
<G-vec00180-002-s370><depend.abhängen><de> Von der Rasse hängt nicht von der Hingabe der Hunde ab.
<G-vec00180-002-s370><depend.abhängen><en> From the breed does not depend on the devotion of dogs.
<G-vec00180-002-s371><depend.abhängen><de> Die Wirkung von Kanna hängt weitgehend von Set (geistiger Zustand) und Setting (körperliche und soziale Umgebung) der anwendenden Person ab.
<G-vec00180-002-s371><depend.abhängen><en> The effects of kanna largely depend on the set (mental state) and setting (physical and social environment) of the user.
<G-vec00180-002-s372><depend.abhängen><de> Schätzungsweise hat alle fünf Minuten eine Person einen Schlaganfall und ihr Weg zur Genesung hängt nicht nur vom Patienten selbst ab, sondern auch auf die Mittel, die ihm zur Verfügung stehen.
<G-vec00180-002-s372><depend.abhängen><en> It is estimated that every five minutes one person will have a stroke and the road to recovery will depend not only on the patient themselves, but on the resources and interventions available to them.
<G-vec00180-002-s373><depend.abhängen><de> Die Wahrheit zu erkennen, hängt nicht von einem großen oder kleinen Intellekt ab.
<G-vec00180-002-s373><depend.abhängen><en> To see the Truth does not depend on a big intellect or a small intellect.
<G-vec00180-002-s374><depend.abhängen><de> Insbesondere der Vertrieb von Neufahrzeugen hängt in hohem Maß von der konjunkturellen Entwicklung ab.
<G-vec00180-002-s374><depend.abhängen><en> In particular, sales of new trucks depend to a large degree on economic growth.
<G-vec00180-002-s375><depend.abhängen><de> Zusätzliche Informationen: der Preis hängt von der Art des Appartements ab, der Preis ist terminabhängig.
<G-vec00180-002-s375><depend.abhängen><en> Ustroń Additional information: prices depend on the type of an apartment, prices depend on season.
<G-vec00180-002-s376><depend.abhängen><de> Zusätzliche Informationen: der Preis hängt von der Länge des Aufenthaltes ab, der Preis ist terminabhängig.
<G-vec00180-002-s376><depend.abhängen><en> Krynica-Zdrój Additional information: prices depend on length of stay, prices depend on season.
<G-vec00180-002-s377><depend.abhängen><de> Zusätzliche Informationen: der Preis hängt von Personenzahl ab, der Preis hängt von der Länge des Aufenthaltes ab.
<G-vec00180-002-s377><depend.abhängen><en> Additional information: prices depend on number of persons, prices depend on length of stay.
<G-vec00180-002-s378><depend.abhängen><de> Zusätzliche Informationen: der Preis hängt von einem Termin und von der Länge des Aufenthaltes ab, der Preis hängt von Personenzahl ab.
<G-vec00180-002-s378><depend.abhängen><en> Additional information: prices depend on the standard of a room, prices depend on number of persons, prices depend on season, prices are negotiable for groups.
<G-vec00180-002-s379><depend.abhängen><de> Der empfohlene Wert hängt von der Geschwindigkeit und der Auslastung des Netzwerks und der Cluster-Knoten ab.
<G-vec00180-002-s379><depend.abhängen><en> The "correct" value will depend on the speed and load of your network and cluster nodes.
<G-vec00180-002-s381><depend.abhängen><de> Zusätzliche Informationen: die Preise hängen von der Art des Bungalows ab, der Preis hängt von Personenzahl ab, der Preis hängt von der Länge des Aufenthaltes ab.
<G-vec00180-002-s381><depend.abhängen><en> Additional information: prices depend on the type of a bungalow, prices depend on number of persons, prices depend on length of stay.
<G-vec00180-002-s382><depend.abhängen><de> Die Häufigkeit der Reinigung hängt von Ihrer Umgebung, Ihrem Lebensstil und der Menge an Schweiß ab.
<G-vec00180-002-s382><depend.abhängen><en> Frequency of cleaning will depend on your environment, lifestyle and amount of perspiration.
<G-vec00180-002-s384><depend.abhängen><de> Die Härtungszeit hängt von der Konsistenz der Mischung; desto dichter, schneller austrocknen.
<G-vec00180-002-s384><depend.abhängen><en> The curing time depend on the consistency of the mixture; the denser, faster dry up.
<G-vec00180-002-s386><depend.abhängen><de> Die Schwere der Krankheit hängt von der Art von Pilzen und deren Lokalisierung.
<G-vec00180-002-s386><depend.abhängen><en> The Severity of the disease will depend on mushroom species and their localization.
<G-vec00180-002-s387><depend.abhängen><de> Welche personenbezogenen Daten verarbeitet werden, hängt von den vom Nutzer in den Nachrichten erteilten Informationen und den eingesetzten Kommunikationsmethoden (z.
<G-vec00180-002-s387><depend.abhängen><en> The Personal Data processed depend on the information provided by the User in the messages and the means used for communication (e.g.
<G-vec00180-002-s388><depend.abhängen><de> Die Anzahl der Schichten hängt von der Last und der Spannweite des Dachs und beträgt zwischen zwei und acht.
<G-vec00180-002-s388><depend.abhängen><en> The number of layers depend on the load and span of the roof – between 2 to 8 layers.
<G-vec00180-002-s389><depend.abhängen><de> 1 Sind mehrere Emissionsquellen vorhanden und hängt die Anforderung an die Emissionsbegrenzung von der Grösse einer Anlage (z.
<G-vec00180-002-s389><depend.abhängen><en> 1 If there is more than one emission source and if emission limitation requirements depend on the size of an installation (e.g.
<G-vec00180-002-s390><depend.abhängen><de> Auch die Audio-Qualität, die Sie benötigen, hängt von der Zweck des Films.
<G-vec00180-002-s390><depend.abhängen><en> Similarly, the audio quality you need will depend on the purpose of the movie.
<G-vec00180-002-s391><depend.abhängen><de> Die Batterielaufzeit hängt von den Geräteeinstellungen, der Verwendung und vielen weiteren Faktoren ab.
<G-vec00180-002-s391><depend.abhängen><en> All battery claims depend on network configuration and many other factors; actual results will vary.
<G-vec00180-002-s393><depend.abhängen><de> Die Abmessungen und die Größe der Kupferspulen hängt von den Anforderungen der Kunden.
<G-vec00180-002-s393><depend.abhängen><en> The dimensions and the size of the Copper Coils depend upon the requirements of the clients.
<G-vec00180-002-s653><depend.abhängen><de> Es wurden die folgenden Hypothesen getestet: i) Die Zusammensetzung und ii) die Bioverfügbarkeit von DOM ändert sich systematisch entlang des Wasserweges durch unterschiedliche Schichten des Waldes, über Bestandsniederschlag und Stammabfluss, durch die Streuschicht hin durch mineralischen Ober- und Unterboden, wobei nicht nur die Qualität, sondern auch die Richtung und das Ausmaß der Änderung vom Waldmanagement abhängen.
<G-vec00180-002-s653><depend.abhängen><en> I hypothesized that (i) the composition and (ii) the biodegradability of DOM changes systematically along the water flow path through different compartments (throughfall, stemflow, litter leachate, mineral topsoil and subsoil solution), whereby DOM quality as well as the direction and magnitude of its changes depend on forest management practice.
<G-vec00180-002-s654><depend.abhängen><de> Wenn die heilbringende Gnade Christi alle Menschen erreichen soll, wird dies vom Charakter der Gemeinde abhängen.
<G-vec00180-002-s654><depend.abhängen><en> If the saving grace of Christ is to reach all men, it's going to depend on the character of the church.
<G-vec00180-002-s655><depend.abhängen><de> So wie es in der Literatur über die Sezession getan wird, könnte hier über eine „plebiszitäre Theorie“ des Rechts zu entscheiden gesprochen werden, nach der das Recht zu entscheiden eine grundsätzliche demokratische Forderung wäre, ohne nationalistischen Anhängsel und Komplikationen, da es nicht vom nationalen Charakter der Gemeinschaft abhängen würde, sondern der Wille einer territorial lokalisierten Gruppe von Bürgern dazu genügen würde.
<G-vec00180-002-s655><depend.abhängen><en> As usual in the literature on secession, one could speak here of a “plebiscitary theory” of the right to decide, according to which this right would be an elementary democratic requirement, without nationalistic complications, since it would not depend on the national character of the community, but rather on the will of a set of citizens territorially located.
<G-vec00180-002-s656><depend.abhängen><de> Obwohl wir nicht garantieren können, dass keine Steuern berechnet werden, die vom Recht Ihres Landes abhängen,In den meisten Fällen ist Ihre Bestellung steuerfrei.
<G-vec00180-002-s656><depend.abhängen><en> Though we can not guaranty no taxes charged which depend on the law of your country,in most cases, your order will be tax free.
<G-vec00180-002-s657><depend.abhängen><de> Es basiert auf der Überzeugung, dass der wirtschaftliche Wohlstand und das Wohlergehen der Bürger Europas vom Zustand des Naturkapitals abhängen.
<G-vec00180-002-s657><depend.abhängen><en> It is built on the understanding that the economic prosperity and well-being of Europeans depend on the state of health of its natural capital.
<G-vec00180-002-s658><depend.abhängen><de> Es gibt bestimmte Arten von Mauerwerk, die vom verwendeten Material abhängen.
<G-vec00180-002-s658><depend.abhängen><en> There are certain types of masonry that depend on the material used.
<G-vec00180-002-s659><depend.abhängen><de> Diese Frage ist nicht ganz neu, hat viele Facetten und erfordert differenzierte Antworten, die vom politischen und kulturellen Klima einer Gesellschaft abhängen.
<G-vec00180-002-s659><depend.abhängen><en> This question is not really new, it has many facets, requires differentiated answers which depend and mirror the political and cultural climate of a society.
<G-vec00180-002-s660><depend.abhängen><de> Zweifellos wird diese Beschleunigung vom Vermögen der Mitgliedstaaten abhängen, einige der Maßnahmen in Gang zu setzen.
<G-vec00180-002-s660><depend.abhängen><en> There is no doubt that this speeding up will depend on the Member States ' ability to implement certain measures.
<G-vec00180-002-s661><depend.abhängen><de> Das sind oberflächliche Dinge, und ob man sie mag oder nicht wird einfach nur vom persönlichen Geschmack abhängen.
<G-vec00180-002-s661><depend.abhängen><en> These things are merely superficial, shallow - and whether you like them or not will solely depend on your personal taste.
<G-vec00180-002-s662><depend.abhängen><de> Wenn Sie das Verzeichnis verschieben, werden Sie wahrscheinlich nicht mehr in der Lage sein, alte Versionen korrekt wiederherzustellen, da diese möglicherweise vom Namen des Verzeichnisses abhängen.
<G-vec00180-002-s662><depend.abhängen><en> If you move the directory you are unlikely to be able to retrieve old releases correctly, since they probably depend on the name of the directories.
<G-vec00180-002-s663><depend.abhängen><de> Die Gefahr der Deflation bleibt hoch und hat schon starke Auswirkungen auf die Wirtschaften der Dritten Welt, die vom Rohstoffexport abhängen.
<G-vec00180-002-s663><depend.abhängen><en> The danger of deflation remains high, and already has a strong impact on the Third World economies that depend on exports of raw materials.
<G-vec00180-002-s664><depend.abhängen><de> Ein weiterer Verlauf dieses unguten Szenarios wird vom Zustand des Immunsystems sowie einer Reihe weiterer Faktoren, wie beispielsweise dem Grad der nervlichen Belastung abhängen, was daraufhin den Mechanismus Krebs im Organismus zu starten, auslösen kann.
<G-vec00180-002-s664><depend.abhängen><en> A further development of this unfavorable scenario will depend on the state of one's immune system as well as a number of other factors, such as the level of nervous stress, which may then trigger the mechanism of starting cancer within the organism.
<G-vec00180-002-s665><depend.abhängen><de> Dies richtet sich nach den behördlichen Auflagen, die wiederum vom Arbeitsfluid abhängen.
<G-vec00180-002-s665><depend.abhängen><en> This depends on the authority’s requirements, which in turn depend on the working fluid.
<G-vec00180-002-s666><depend.abhängen><de> Das Spiel kann in einigen Situationen, die vom Emulator und der geografischen Position des Benutzers abhängen, die folgende Meldung anzeigen.
<G-vec00180-002-s666><depend.abhängen><en> The game may display the following message in some situations that depend on the emulator and the geographical location of the user.
<G-vec00180-002-s667><depend.abhängen><de> Er fügt hinzu, dass ein Teil des Agrarprodukts möglicherweise mit Einheitszügen nach St. Louis fährt, um den Mississippi für den Export herunterzufahren, oder zu Terminals unterhalb der LaGrange-Schleuse, aber vieles wird vom Preis für Agrarrohstoffe abhängen.
<G-vec00180-002-s667><depend.abhängen><en> He adds that some of the agriculture product may go on unit trains to St. Louis to ship down the Mississippi River for export or go to terminals below the LaGrange Lock, but much will depend on the price for agriculture commodities.
<G-vec00180-002-s668><depend.abhängen><de> Wie lange wird dieser Prozess vom Wetter abhängen.
<G-vec00180-002-s668><depend.abhängen><en> How long will this process will depend on the weather.
<G-vec00180-002-s669><depend.abhängen><de> Der Gerichtshof befand daher, dass die Wahrung des allgemeinen Grundsatzes der Gleichbehandlung, insbesondere im Hinblick auf das Alter, als solche nicht vom Ablauf der Frist abhängen kann, die den Mitgliedstaaten zur Umsetzung einer Richtlinie eingeräumt worden ist, die die Schaffung eines allgemeinen Rahmens zur Bekämpfung der Diskriminierung wegen des Alters bezweckt(32).
<G-vec00180-002-s669><depend.abhängen><en> (31) Consequently, the Court considered that observance of the general principle of equal treatment, in particular in respect of age, could not as such depend on the expiry of the period allowed the Member States for the transposition of a directive intended to lay down a general framework for combating discrimination on the grounds of age. (32)
<G-vec00180-002-s670><depend.abhängen><de> Auswirkung der Problemumgehung: Wenn der Computerbrowserdienst deaktiviert ist, wird für alle Dienste, die explizit vom Computerbrowserdienst abhängen, eine Fehlermeldung im Systemereignisprotokoll aufgezeichnet.
<G-vec00180-002-s670><depend.abhängen><en> Impact of Workaround. If the Computer Browser service is disabled, any services that explicitly depend on the Computer Browser service may log an error message in the system event log.
<G-vec00180-002-s671><depend.abhängen><de> Je mehr wir vom Digitalen abhängen, desto weniger können wir es uns leisten, dass es versagt.
<G-vec00180-002-s671><depend.abhängen><en> The more we depend on digital, the more we can't afford for digital to fail.
<G-vec00180-002-s687><depend.abhängen><de> Entgelt, das nach der jeweils gültigen Preisliste vom Umsatz des Kunden auf dem Amazon Marketplace abhängt, wird von der Plattform automatisch auf der Grundlage des Umsatzes des vorangegangenen Beobachtungszeitraums, in der Regel der letzten zwei Monate vor dem Abrechnungszeitraum, ermittelt und angepasst.
<G-vec00180-002-s687><depend.abhängen><en> Fees which according to the applicable price list depend on the Customer’s revenue on the Amazon Marketplace will be automatically determined and adjusted by the Platform based on the revenue in the previous observation period, usually the last two months prior to the accounting period.
<G-vec00180-002-s688><depend.abhängen><de> Beachten Sie, dass die Scan-Zeit vom ausgewählten Profil, der allgemeinen Computerleistung und der Menge von Dateien abhängt, die durchsucht werden sollen.
<G-vec00180-002-s688><depend.abhängen><en> Note that the scan time will depend on the selected profile, on general computer performance and the amount of files to be scanned.
<G-vec00180-002-s689><depend.abhängen><de> Es ist immer gut, sich im Klaren zu sein, das die Wirkung der Kunst nicht vom Verständnis von Kunst abhängt.
<G-vec00180-002-s689><depend.abhängen><en> It is always good to be aware that the effect of art does not depend on the understanding of art.
<G-vec00180-002-s690><depend.abhängen><de> Dabei spielt die Bezeichnung oder Form des Schriftstücks, das angeblich eine Entscheidung ist, keine Rolle, da der rechtliche Status des Schriftstücks eindeutig vom Inhalt und nicht von seiner bloßen Form oder Bezeichnung abhängt.
<G-vec00180-002-s690><depend.abhängen><en> This conclusion applies regardless of the title or form of the document that purports to be a decision, for clearly the legal status of that document must depend on its substance, rather than its mere form or title.
<G-vec00180-002-s691><depend.abhängen><de> „Unser Wunsch ist, dass alle den Herrn kennenlernen und niemand vom Zeugnis anderer abhängt“, sagte Elder Christofferson bei der Pfahlkonferenz des Pfahls Arraiján in Panama.
<G-vec00180-002-s691><depend.abhängen><en> Gallery “Our desire is that all will come to know the Lord and that they will not depend on others for a testimony,” Elder Christofferson said at the Arraiján Panama Stake conference.
<G-vec00180-002-s692><depend.abhängen><de> Einige Länder üben eine Form fast ausschließlich, während in anderen sie möglicherweise vom einzelnen Kirchhof abhängt.
<G-vec00180-002-s692><depend.abhängen><en> Some countries practice one form almost exclusively, whereas in others it may depend on the individual cemetery.
<G-vec00180-002-s693><depend.abhängen><de> Somas Erwiederung ist eine kraftvolle Erinnerung, daß Erleuchtung nicht vom Geschlecht abhängt, sondern von der Geistesfähigkeit in Konzentration und Weisheit, Eigenschaften, die von jedem menschlichen Wesen erreichbar sind, das ernsthaft danach strebt, die Wahrheit druchdringen zu wollen.
<G-vec00180-002-s693><depend.abhängen><en> Soma's rejoinder is a forceful reminder that enlightenment does not depend on gender but on the mind's capacity for concentration and wisdom, qualities accessible to any human being who earnestly seeks to penetrate the truth.
<G-vec00180-002-s694><depend.abhängen><de> Kennen Sie den Unterschied zwischen der Zeit und den Umständen der Zeit, der nicht vom Test abhängt.
<G-vec00180-002-s694><depend.abhängen><en> Know the breakdown time and attitudes of situations that do not depend on the test.
<G-vec00180-002-s695><depend.abhängen><de> Die zweite Änderung ist, dass nach dem Update der Energievorrat der Waffe vom Ziel abhängt.
<G-vec00180-002-s695><depend.abhängen><en> The second change is that after the update, the rate at which Isida’s energy bar is consumed, will depend on its target.
<G-vec00180-002-s696><depend.abhängen><de> Sein transaktionales Stressmodell postuliert, dass eine Stresssituation nicht allein vom Stressreiz selbst, sondern auch von der Person, welche dem Stressreiz ausgesetzt ist, abhängt.
<G-vec00180-002-s696><depend.abhängen><en> His transactional stress model postulates that a stress situation does not only depend on the stress stimulus itself, but also on the person who is exposed to the stress stimulus.
<G-vec00180-002-s728><depend.abhängen><de> Vieles wird von der Hilfe von den Förderern abhängen“.
<G-vec00180-002-s728><depend.abhängen><en> A lot will depend on the assistance of the sponsors as well.”
<G-vec00180-002-s729><depend.abhängen><de> Vergeßt nicht, daß die Früchte des Apostolats von der Tiefe des geistlichen Lebens, der Intensität des Gebets, von einer ständigen Weiterbildung und einer aufrichtigen Befolgung der Weisungen der Kirche abhängen.
<G-vec00180-002-s729><depend.abhängen><en> Do not forget that the fruits of the apostolate depend on the depth of spiritual life, on the intensity of prayer, on continual formation and on sincere adherence to the Church's directives.
<G-vec00180-002-s730><depend.abhängen><de> Die Agentur haftet nicht, wenn Aktivitäten und Einrichtungen, die von Wetter und Naturereignissen abhängen, nicht im Einklang mit dem Reiseprogramm oder den Erwartungen des Reisenden durchgeführt werden können.
<G-vec00180-002-s730><depend.abhängen><en> The Agency shall not be held liable if any activities and facilities that depend on weather and natural occurrences may not be carried out in accordance with the Travel Program or the Traveler’s expectations.
<G-vec00180-002-s731><depend.abhängen><de> Bis zum Jahr 2020 wird der Erfolg von 50 % aller weltweiten Global-2000-Unternehmen von ihrer Fähigkeit abhängen, digital unterstützte Produkte, Services und Erlebnisse anzubieten.1 Große Unternehmen erwarten eine Steigerung des digitalen Umsatzes um 80 %2 – basierend auf technischen Weiterentwicklungen und dadurch begünstigten Nutzungsmodellen.
<G-vec00180-002-s731><depend.abhängen><en> By 2020, the success of half of the world’s Global 2000 companies will depend on their abilities to create digitally enhanced products, services, and experiences,1 and large organizations expect to see an 80 percent increase in their digital revenues,2 all driven by advancements in technology and usage models they enable.
<G-vec00180-002-s732><depend.abhängen><de> AUTO ADMIN MAPPING in der Datenbank hat keine Auswirkung auf die Remoteverbindung (obwohl dies auch von der Konfiguration des Netzwerks abhängen kann).
<G-vec00180-002-s732><depend.abhängen><en> AUTO ADMIN MAPPING in the database has no effect when connecting remotely (though this may also depend on the configuration of the network).
<G-vec00180-002-s733><depend.abhängen><de> Die Ergebnisse variieren nicht zuletzt, weil sie von vielen verschiedenen Faktoren abhängen, einschließlich der geografischen Lage.
<G-vec00180-002-s733><depend.abhängen><en> The results vary wildly not least because they depend on many different factors, including geographical location.
<G-vec00180-002-s734><depend.abhängen><de> Die Geschwindigkeit der Involution kann von einer Anzahl von Gründen abhängen: der allgemeine Zustand, das Alter der Frau, die Merkmale des Verlaufs der Schwangerschaft und der Geburt, Stillzeit, etc.
<G-vec00180-002-s734><depend.abhängen><en> The speed of the involution may depend on a number of reasons: the general condition, the age of the woman, the characteristics of the course of pregnancy and childbirth, breast-feeding, etc.
<G-vec00180-002-s735><depend.abhängen><de> Wir wissen, dass heute zentrale Geschäftsprozesse und wichtige Unternehmensfunktionen von komplexen IT-Diensten abhängen.
<G-vec00180-002-s735><depend.abhängen><en> We are aware that today key business processes and critical corporate functions depend on complex IT services.
<G-vec00180-002-s736><depend.abhängen><de> Sie sind daher typischerweise lichtdurchlässig, obwohl dies auch von ihrer Zusammensetzung abhängen kann.
<G-vec00180-002-s736><depend.abhängen><en> So they are typically transparent to light, although this can also depend on their composition.
<G-vec00180-002-s737><depend.abhängen><de> Für Masse 3-10 Tage, die von der Quantität des Kundenauftrages abhängen.
<G-vec00180-002-s737><depend.abhängen><en> For bulk 3-10 days which depend on the quantity of customer order.
<G-vec00180-002-s738><depend.abhängen><de> Die Fruchtbarkeit ihrer zukünftigen Sendung wird sehr von ihrer tiefen Christusverbundenheit abhängen, von der Qualität des Gebetslebens und des innerlichen Lebens, von den menschlichen, geistlichen und moralischen Werten, die sie sich während der Ausbildung angeeignet haben.
<G-vec00180-002-s738><depend.abhängen><en> The fruitfulness of their future mission will greatly depend on their profound union with Christ, on the quality of their life of prayer and their interior life, and on the human, spiritual and moral values assimilated during their time of formation.
<G-vec00180-002-s739><depend.abhängen><de> Im Allgemeinen gibt es dort, wo man sich umdrehen kann, und die Anordnung wird bereits von der Vorstellungskraft und den Vorlieben der Eigentümer selbst abhängen.
<G-vec00180-002-s739><depend.abhängen><en> In general, there is where to turn around, and the arrangement will already depend on the imagination and preferences of the owners themselves.
<G-vec00180-002-s740><depend.abhängen><de> Wie schnell eine Verbesserung eintritt, kann von Art und Schweregrad der Symptome abhängen.
<G-vec00180-002-s740><depend.abhängen><en> How quickly things start to improve can depend on the kind of symptoms you have and how severe they are.
<G-vec00180-002-s741><depend.abhängen><de> Viel wird von den Gemeinwesen abhängen, die die Einwohner gründen.
<G-vec00180-002-s741><depend.abhängen><en> Much will depend on the communities that the residents create.
<G-vec00180-002-s742><depend.abhängen><de> Auch gebe es regulatorische Herausforderungen, welche von nationalen Gesetzen abhängen und die Entwicklung und den Marktzugang für Speichersysteme in einigen Ländern einschränken können.
<G-vec00180-002-s742><depend.abhängen><en> There are also regulatory challenges which depend on national laws and may restrict the development and market access of storage systems in some countries.
<G-vec00180-002-s743><depend.abhängen><de> Spieler werden hier in der Rolle eines arroganten und glücklichen Anfängers sein, der unter der schwarzen Flagge arbeitet und die Zukunft der gesamten Crew wird von ihnen abhängen.
<G-vec00180-002-s743><depend.abhängen><en> Gamers will be here in the role of arrogant and lucky beginner working under the black flag and the future of the entire crew will depend on them.
<G-vec00180-002-s744><depend.abhängen><de> (15) Um ein ernsthaftes Risiko einer Umgehung der Vorschriften zu vermeiden, sollte der Schutz natürlicher Personen technologieneutral sein und nicht von den verwendeten Techniken abhängen.
<G-vec00180-002-s744><depend.abhängen><en> (14) | È opportuno In order to prevent creating a serious risk of circumvention, the protection of natural persons should be technologically neutral and should not depend on the techniques used.
<G-vec00180-002-s745><depend.abhängen><de> Wenn Sie gewohnt haben, ihre Zeit zu verwalten und wollen von den öffentlichen Verkehrsmitteln oder Taxi nicht abhängen, denken Sie an den Mietwagen.
<G-vec00180-002-s745><depend.abhängen><en> If you are used to controlling your time and do not want to depend on public transport or taxi, think about hiring a car.
<G-vec00180-002-s746><depend.abhängen><de> Ich werde die geöffneten Türen in zwei Kategorien einteilen: Die von uns geöffneten Türen d.h. die Türen, die von uns abhängen, und wofür wir die Hauptverantwortungen tragen, und die anderen geöffneten Türen, diejenigen, über die wir selbst fast keine Kontrolle haben.
<G-vec00180-002-s746><depend.abhängen><en> I will regroup the open doors into two categories: Doors opened by us, that is, those that depend on us and that we are entirely responsible for, and the other open doors, those over which we hardly have control. Doors opened by us
<G-vec00180-002-s766><depend.abhängen><de> Danach beinhaltet Chancengerechtigkeit, dass die Möglichkeit zur Einkommenserzielung nicht von Faktoren abhängt, die sich dem persönlichen Einfluss entziehen.
<G-vec00180-002-s766><depend.abhängen><en> Equal opportunity means that the ability to earn a living does not depend on factors that are beyond personal influence.
<G-vec00180-002-s767><depend.abhängen><de> Der Geschäftsführer der CTBTO Zerbo erklärte auf der Abrüstungskonferenz, dass CTBT eine „tiefhängende Frucht“ sei und „der Erfolg aller weiteren Aktionen, um die Arbeit am Atomwaffensperrvertrag und der Abrüstung vorwärtszubringen, von der Entschlossenheit und dem politischen Willen der internationalen Gemeinschaft abhängt, zu beenden, was sie begonnen hat“.
<G-vec00180-002-s767><depend.abhängen><en> CTBTO Executive Secretary Zerbo told the Conference on Disarmament that the CTBT is a "low hanging fruit" and that "the success of any further actions taken to advance work on nuclear non-proliferation and disarmament will depend on the international community's resolve and political will to 'finish what it starts'."
<G-vec00180-002-s768><depend.abhängen><de> Es ist wichtig, sich daran zu erinnern, dass die Zuverlässigkeit der Installation des Winkelprofils von der Zuverlässigkeit der gesamten Struktur abhängt.
<G-vec00180-002-s768><depend.abhängen><en> It is important to remember that reliability of the installation of the angular profile will depend on the reliability of the entire structure.
<G-vec00180-002-s769><depend.abhängen><de> Das Bundesministerium für Gesundheit erklärte in einer Stellungnahme an den Petitionsausschuss, dass die Kostenübernahme für Dronabinol von einer entsprechenden Empfehlung des Gemeinsamen Bundesausschusses von Ärzten und Krankenkassen abhängt.
<G-vec00180-002-s769><depend.abhängen><en> The Federal Health Ministry said in a statement to the Petition Committee that meeting of the costs of dronabinol would depend on a recommendation by the Joint Federal Committee of Physicians and Health Insurances.
<G-vec00180-002-s770><depend.abhängen><de> Der Unterschied zum naturgegebenen Kulturaustausch besteht darin, dass sich diese Art Kulturaustausch an die kulturelle Elite, an die Praxis und deren Künstler wendet und von einer gewissen Spiritualität abhängt, die über Wirtschaftlichkeit, Politik und Lebensstil hinausgeht.
<G-vec00180-002-s770><depend.abhängen><en> Different from the natural-nature cultural exchanges, this kind of cultural exchanges are called upon by cultural elites, practitioners and art workers and depend on certain spirituality beyond economy, politics and lifestyles.
<G-vec00180-002-s771><depend.abhängen><de> Die Astronomen untersuchten wie die Bewegung von Sternen senkrecht zur galaktischen Scheibe von ihrem Alter abhängt.
<G-vec00180-002-s771><depend.abhängen><en> The astronomers studied how the vertical motions of stars - in the direction perpendicular to the galactic disc - depend on their ages.
<G-vec00180-002-s772><depend.abhängen><de> Einige debhelper-Befehle können dazu führen, dass das erstellte Paket von einigen zusätzlichen Paketen abhängt.
<G-vec00180-002-s772><depend.abhängen><en> Some debhelper commands may cause the generated package to depend on some additional packages.
<G-vec00180-002-s773><depend.abhängen><de> Als Funktion des Elementabstands zeigte diese einen hyperbolischen Verlauf, dessen Exponent von der Größe der einzelnen Nanostrukturen abhängt.
<G-vec00180-002-s773><depend.abhängen><en> A hyperbolic dependence of the switching field distribution on the spacing of the array elements was observed. Its exponent was found to depend on the size of the single elements.
<G-vec00180-002-s774><depend.abhängen><de> Sicherlich reichen die Lehren Buddhas über Glück über dieses hinaus, zu einem Glück, Nirvana, welches nicht von Handlungen und Absichten abhängt, doch gerade so viel hier, sollte genug sein, um viele neue Wege der Erkundungen für positive Psychologie zu unterbreiten.
<G-vec00180-002-s774><depend.abhängen><en> Of course, the Buddha’s teachings on happiness go beyond this, to a happiness—nirvana—that doesn’t depend on actions or intentions, but just this much should be enough to suggest many new avenues of inquiry for positive psychology.
<G-vec00180-002-s775><depend.abhängen><de> Die ADA stellt fest, dass Nahrungsmittel mit Stärke (Kohlenhydrate) den Blutzuckerwert ansteigen lassen, der Anstieg von der Konzentration und dem Grad der Verarbeitung der Stärke in dem Nahrungsmittel abhängt, was wiederum von vielen Faktoren beeinflusst wird.
<G-vec00180-002-s775><depend.abhängen><en> For example, the ADA states starchy (carbohydrate) foods will raise the blood glucose concentration and the increase will depend on the rate and completeness of digestion of the starch in a food, which is influenced by many factors.
<G-vec00180-002-s776><depend.abhängen><de> Und jemand glaubt, dass das Geschlecht des Kindes von der Zeit des Geschlechtsverkehrs abhängt.
<G-vec00180-002-s776><depend.abhängen><en> And someone believes that the sex of the child will depend on the time of sexual intercourse.
<G-vec00180-002-s777><depend.abhängen><de> Im zweiten Fall müssen Sie den Systembenutzer entweder preinst oder postinst erstellen und dafür sorgen, dass das Paket von adduser (>= 3.11) abhängt.
<G-vec00180-002-s777><depend.abhängen><en> In the second case, you need to create the system user either in the preinst or in the postinst and make the package depend on adduser (>= 3.11).
<G-vec00180-002-s778><depend.abhängen><de> Das Sportlerteam von The North Face® gibt uns konstantes Feedback zu der Bekleidung und Ausrüstung, von denen ihr Erfolg und Überleben auf ihren Abenteuern abhängt.
<G-vec00180-002-s778><depend.abhängen><en> The North Face® Athlete Team gives us constant feedback on the clothing and equipment they depend on for success and survival in their adventures.
<G-vec00180-002-s779><depend.abhängen><de> Der Flammpunkt ist bei der Selbstentzündungstemperatur nicht verwechselt, so dass der Flammpunkt nicht von der Temperatur abhängt.
<G-vec00180-002-s779><depend.abhängen><en> The Flash point is not confused at auto ignition temperature thus the Flash point is not depend on the temperature.
<G-vec00180-002-s780><depend.abhängen><de> Auf dem Erlös können Sie zusätzliches Material für das Haus kaufen, das von Ihren Bedürfnissen abhängt.
<G-vec00180-002-s780><depend.abhängen><en> On the proceeds you can buy additional material for the house, which will depend on your needs.
<G-vec00180-002-s781><depend.abhängen><de> Etwas, das sicherlich Ihre Aufmerksamkeit erregen wird, ist das "Moralische Wertsystem", das von Ihrem Benehmen gegenüber anderen Spielern abhängt.
<G-vec00180-002-s781><depend.abhängen><en> Something that will surely attract your attention is the “Moral Value” system that will depend on your attitude towards other players.
<G-vec00180-002-s782><depend.abhängen><de> Unterverzeichnisse von 32-Bit-Verzeichnissen namens /lib, deren Dateninhalt nicht von der Wortgröße abhängt, werden nicht verschoben.
<G-vec00180-002-s782><depend.abhängen><en> Subdirectories of 32-bit /lib directories which contain data content that does not depend on the word size are not moved.
<G-vec00180-002-s783><depend.abhängen><de> Da das wahrgenommene Sicherheitsgefühl von den Lichtverhältnissen abhängt, können Nutzer dieses zweimal täglich teilen: am Tag und in der Nacht.
<G-vec00180-002-s783><depend.abhängen><en> Since the perceived sense of safety may depend upon the light conditions, users are able to rate twice a day: at daytime and nighttime.
<G-vec00180-002-s784><depend.abhängen><de> Es ist also notwendig, dass uns schwachseelischen Weissen wenigstens von jenem Organismus unseres Leibes eine richtige Kenntnis verschafft wird, von dessen gerechter Ausbildung des Menschen Lebenswohl oder -übel sozusagen nahezu ganz allein abhängt.
<G-vec00180-002-s784><depend.abhängen><en> It is therefore necessary that our weak white souls at least have a basic knowledge of this organism in our body as our good fortune or otherwise in life seems to depend almost entirely on the brain’s correct development.
<G-vec00180-002-s019><hinge.abhängen><de> Verhaltener Optimismus Nach unserem Dafürhalten werden die langfristigen Aussichten für China stark davon abhängen, wie das Land mit seinen Herausforderungen umgeht.
<G-vec00180-002-s019><hinge.abhängen><en> Cautious Optimism We think China’s longer-term prospects will hinge greatly on how well it handles its challenges.
<G-vec00180-002-s020><hinge.abhängen><de> Und wir dürfen nicht ruhen, bis diese Benachteiligungen beseitigt sind, bis Zukunftschancen nicht mehr vom Leben in Ost oder West abhängen.
<G-vec00180-002-s020><hinge.abhängen><en> We cannot rest until these handicaps have been done away with, until a person’s prospects no longer hinge on whether they lived in the east or the west.
<G-vec00180-002-s021><hinge.abhängen><de> Ob ein Paar vor der Geburt eines Kindes heiratet, kann von unterschiedlichen Faktoren abhängen: Es könnte ökonomisch sinnvoll sein, weil die Familienpolitik die Ehe belohnt und ein weniger oder gar nicht arbeitender Partner besser abgesichert ist.
<G-vec00180-002-s021><hinge.abhängen><en> A couple’s decision whether to marry before having a child can hinge on different factors: To tie the knot would make sense economically because family policies provide incentives for married couples, and a partner who works less hours or not at all would have greater financial security.
<G-vec00180-002-s022><hinge.abhängen><de> „Die Zukunft des ukrainischen Reformprojekts wird nun noch mehr von den Entscheidungen des Präsidenten abhängen.
<G-vec00180-002-s022><hinge.abhängen><en> “The future of Ukraine’s reform project will therefore hinge even more on the choices of the president.
<G-vec00180-002-s023><hinge.abhängen><de> Durch die extrem hohe Kapitalintensität der chinesischen Wirtschaft (Bruttoanlageinvestitionen über 40% des BIP) wird das zukünftige Wachstum von einer höheren Neigung der chinesischen Bevölkerung zum Konsum abhängen.
<G-vec00180-002-s023><hinge.abhängen><en> Due to the extremely high capital intensity of the Chinese economy (gross fixed capital formation > 40% of GDP) future growth will hinge on a higher propensity to consume of the Chinese population.
<G-vec00180-002-s024><hinge.abhängen><de> Die Aufstellung von Plänen für schwere Hebe- und Transportarbeiten kann von einer Reihe von Faktoren abhängen, die berücksichtigt werden müssen, damit die Komponenten sicher und rechtzeitig zu ihrem neuen Standort gelangen.
<G-vec00180-002-s024><hinge.abhängen><en> Heavy lifting and transport plans installation can hinge on a number of factors that need to be considered in order to get components delivered to their new location safely and on time.
