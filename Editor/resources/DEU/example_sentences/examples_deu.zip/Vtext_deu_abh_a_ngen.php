<G-vec00280-002-s105><overtake.abhängen><de> Sie ist einfacher zu handhaben, besser verträglich und mit der nächsten Technologie-Iteration wird MR durchaus das Zeug haben, VR auf breiter Ebene abzuhängen.
<G-vec00280-002-s105><overtake.abhängen><en> It's easier to handle, more compatible, and with the next iteration of the technology, MR will certainly be able to overtake VR on a broader level.
<G-vec00520-002-s044><depend.abhängen><de> Denn die Mineralwasser haben verschiedene Geschmäcke, die abhängen von der im Wasser enthaltenen Mineralisierung.
<G-vec00520-002-s044><depend.abhängen><en> Yes, mineral waters have different tastes, which depend on the minerals specialities
<G-vec00520-002-s045><depend.abhängen><de> Drehende Tabellen können in der Runde, Quadrat, sogar Achtkiefer sein, abhängen von den verschiedenen Anforderungen der Schweißensaufgabe.
<G-vec00520-002-s045><depend.abhängen><en> Rotating Tables can be in round, square, even eight-jaws, depend on various requirements of welding task.
<G-vec00520-002-s046><depend.abhängen><de> Wenn sich dieser Ort im zweisprachigen Gebiet Brüssel-Hauptstadt befindet, wird diese Zuständigkeit von der Sprache abhängen, die im Antrag verwendet wurde oder von der Sprache, die vom Beklagten gewählt wurde.
<G-vec00520-002-s046><depend.abhängen><en> If this place is located in the bilingual Brussels Capital Region, this competence will depend on the language that is used in the application or the language chosen by the defendant.
<G-vec00520-002-s047><depend.abhängen><de> Wie ein Mensch handelt, wird also abhängen von der Art, wie sein Intuitionsvermögen einer bestimmten Situation gegenüber wirkt.
<G-vec00520-002-s047><depend.abhängen><en> How I act will therefore depend on how my capacity for intuition works in relation to a particular situation.
<G-vec00520-002-s048><depend.abhängen><de> Die Mengen, in denen proteolytische Enzyme in Bezug auf tierisches Protein verwendet werden, wird abhängen von der Substratkonzentration, dem Enzymtiter, der Reaktionstemperatur und der Reaktionszeit, wobei sie im typischen Fall im Bereich von 100 bis 10.000 Einheiten der Enzymaktivität pro 1 g Protein, die in der Dispersion oder Lösung des tierischen Proteins enthalten sind.
<G-vec00520-002-s048><depend.abhängen><en> The amounts in which proteolytic enzymes are used versus the animal protein will depend on substrate concentration, enzyme titer, reaction temperature, and reaction time, but typically range from about 100 to 10,000 units of activity per 1 g of protein contained in the animal protein dispersion or solution.
<G-vec00520-002-s049><depend.abhängen><de> Nicht nur hängen wir von unseren Autos ab, um uns zu erhalten, wo wir gehen möchten, wir abhängen auch von ihnen, um uns ohne Unannehmlichkeit dort zu erhalten.
<G-vec00520-002-s049><depend.abhängen><en> Not only do we depend on our cars to get us where we want to go, we also depend on them to get us there without discomfort.
<G-vec00520-002-s050><depend.abhängen><de> Ob diese Expropriation mit oder ohne Entschädigung erfolgt, wird großenteils nicht von uns abhängen, sondern von den Umständen, unter denen wir in den Besitz der Macht kommen, und namentlich auch von der Haltung der Herren Großgrundbesitzer selbst.
<G-vec00520-002-s050><depend.abhängen><en> Whether this expropriation is to be compensated for or not will, to a great extent, depend not upon us but the circumstances under which we obtain power, and particularly upon the attitude adopted by these gentry, the big landowners, themselves.
<G-vec00551-002-s019><hang.abhängen><de> Die BBC News möchte eben nicht mit Ihnen abhängen.
<G-vec00551-002-s019><hang.abhängen><en> The BBC News might not want to hang around with you.
<G-vec00551-002-s020><hang.abhängen><de> Nach Verwendung kann die Tischplatte abgeklappt werden, so dass Sie bequem an dem Tisch vorbei gehen können ohne diese abhängen zu müssen.
<G-vec00551-002-s020><hang.abhängen><en> After use, the table top can be folded down so that you can comfortably walk past the table without having to hang it.
<G-vec00551-002-s021><hang.abhängen><de> Es ist auf jeden Fall ein Ort, wo die Einheimischen Abhängen.
<G-vec00551-002-s021><hang.abhängen><en> It is definitely a place where locals hang out.
<G-vec00551-002-s022><hang.abhängen><de> Das Brisbane Hotel ist ein traditioneller Pub in der Stadt, ein entspannter unkomplizierter Ort zum abhängen.
<G-vec00551-002-s022><hang.abhängen><en> The Brisbane Hotel is a traditional corner pub in town, kicked back and an easygoing place to hang.
<G-vec00551-002-s023><hang.abhängen><de> Von dort aus können Sie die Insel zu einer idealen Kleinstadt mit gutem Willen und guter Stimmung ausbauen, in der Sie mit Ihren freundlichen Inselbewohnern (jeder hat seine Persönlichkeit) und echten Freunden abhängen können.
<G-vec00551-002-s023><hang.abhängen><en> From there, you can build the island up into an ideal small town with goodwill and good vibes where you can hang out with your friendly islanders (each has their personalities) and real-world friends.
<G-vec00551-002-s024><hang.abhängen><de> Und zwar vorwiegend mit Interessierten, Wütenden und der Nachbarschaft, nicht in erster Linie mit denen, die in der Szenekneipe abhängen.
<G-vec00551-002-s024><hang.abhängen><en> This was done mainly with interested people, angry people and the neighbourhood, not so much with those who hang out at the scene pub.
<G-vec00551-002-s025><hang.abhängen><de> Das fing mit Briefen an, ging über Telefongespräche und gemeinsamen Ausflügen bis hin zum Abhängen in Chucks Haus.
<G-vec00551-002-s025><hang.abhängen><en> It went from letters, to phone conversations to eventually taking roadtrips up to Chuck's house to hang out.
<G-vec00551-002-s026><hang.abhängen><de> Außerdem betreibt Jab einen Blog, ein Forum und du kannst auch mit anderen Mitgliedern, sowie Jab und seinem Team in einem Chatroom abhängen.
<G-vec00551-002-s026><hang.abhängen><en> Also Jab is running an active blog, a forum and you can even hang out with other members, Jab and his team on a chat room.
<G-vec00551-002-s027><hang.abhängen><de> Es ist ein fantastischer Ort zum Abhängen.
<G-vec00551-002-s027><hang.abhängen><en> It's a fantastic place to hang out.
<G-vec00551-002-s028><hang.abhängen><de> Das Boutique-Apartment ist der ideale Ort zum Abhängen und Spaß haben für die charmante und begehrenswerte Schickeria von PlayStation®Home.
<G-vec00551-002-s028><hang.abhängen><en> The Boutique Apartment is the perfect place for the suave and sexy socialites of PlayStation Home to hang out and have fun.
<G-vec00551-002-s029><hang.abhängen><de> Hotelgarten In unserem Abenteuer-Kletterwald direkt neben dem kreativen Outdoor-Spielplatz „Murmels Wasserwelt“ könnt ihr Euch so richtig austoben, oder einfach in der Hängematte oder auf den Schaukeln abhängen.
<G-vec00551-002-s029><hang.abhängen><en> Children can let off steam on our adventure ropes cours*e next to the creative outdoor play area *‘Murmel’s Water World’ or simply hang out in the hammock or on the swings.
<G-vec00551-002-s030><hang.abhängen><de> Es ist der perfekte Ort für die Vogelbeobachtung und Reiche zeigte mir auch die Eulen in der Nacht, die in ihrem Hinterhof in der Eulenkasten Abhängen.
<G-vec00551-002-s030><hang.abhängen><en> It's the perfect place for bird-watching and Rich even showed me the owls at night that hang out in the owl box in their backyard.
<G-vec00551-002-s031><hang.abhängen><de> Und abhängen und chillen ist angesagter, als durch den Park zu joggen.
<G-vec00551-002-s031><hang.abhängen><en> To hang out and chill is much more in trend than jogging through the park.
<G-vec00551-002-s032><hang.abhängen><de> Selten hatten wir so viel Abwechslung im Urlaub mit Städtebesichtigung, Fattorien-Besuchen, Reiten und Wanderungen oder einfach nur abhängen.
<G-vec00551-002-s032><hang.abhängen><en> We rarely had so much variety on holiday with tour cities, Fattorias visits, horseback riding and hiking, or just hang out.
<G-vec00551-002-s033><hang.abhängen><de> Es war toll, unsere kleine Behausung zu haben, um nach einem langen Tag zu kommen, und einen gemütlichen Ort zum Abhängen in, wenn es (zum Glück nur sehr wenig) geregnet.
<G-vec00551-002-s033><hang.abhängen><en> It was great to have our little abode to come back to after a long day, and a cosy place to hang out in when it rained (luckily very little).
<G-vec00551-002-s034><hang.abhängen><de> Da konnte ich sie tatsächlich abhängen und mit meinem Zeltplatznachbar flogen wir über die Trails ins Fanestal hinein.
<G-vec00551-002-s034><hang.abhängen><en> Since I could literally hang out and with my campsite neighbor we flew over the trails into the Fanestal.
<G-vec00551-002-s035><hang.abhängen><de> - Yard Terrasse auf dem Grundstück - große offene Fläche zum Abhängen mit Freunden.
<G-vec00551-002-s035><hang.abhängen><en> - Yard terrace inside the property - great open area to hang out with friends.
<G-vec00551-002-s036><hang.abhängen><de> Als Alternative kann man auch einfach außerhalb des Parks wandern oder am Strand abhängen.
<G-vec00551-002-s036><hang.abhängen><en> Alternatively just stay outside the park and go for a hike in the area or hang at the beach
<G-vec00551-002-s037><hang.abhängen><de> An der Hotelbar können Sie zwischendurch Getränke und Snacks bestellen (nicht in der Verwöhnpension enthalten) und einfach mal „abhängen“.
<G-vec00551-002-s037><hang.abhängen><en> At the hotel bar, you can order drinks and snacks in between meals (not included in the pampering pension) and simply "hang out."
<G-vec00595-002-s022><detach.abhängen><de> Einmal pro Spielzug: Du kannst ein Xyz-Material von dieser Karte abhängen und dann ein offenes Monster wählen, das dein Gegner kontrolliert; zerstöre es, es sei denn, dein Gegner zahlt 1000 Life Points, um diesen Effekt zu annullieren.
<G-vec00595-002-s022><detach.abhängen><en> Once per turn: You can detach 1 Xyz Material from this card, then target 1 face-up monster your opponent controls; destroy it, unless your opponent pays 1000 Life Points to negate this effect.
