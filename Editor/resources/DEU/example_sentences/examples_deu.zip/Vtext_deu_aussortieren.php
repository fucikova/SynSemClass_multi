<G-vec00296-002-s091><sort.aussortieren><de> In diesem Fall können Sie dem Kind anbieten, Pasta auszusortieren oder etwas aus Ton zu formen.
<G-vec00296-002-s091><sort.aussortieren><en> In this case, you can offer the chad to sort out pasta or something to sculpt from clay.
<G-vec00296-002-s092><sort.aussortieren><de> Diese Kristalle auszusortieren würde einen sehr sehr hohen Ausschuss bedeuten, welchen wir, aber auch unsere geistige Führung, als nicht zweckmäßig erachten.
<G-vec00296-002-s092><sort.aussortieren><en> To sort out these crystals would lead to a very, very high waste, which neither we nor our spiritual guides consider appropriate.
<G-vec00296-002-s093><sort.aussortieren><de> Wenn Sie sich zwingen, regelmäßig auszusortieren, befreien Sie sich ganz natürlich von dem, was Ihnen nicht mehr gefällt oder nicht mehr nützt.
<G-vec00296-002-s093><sort.aussortieren><en> By forcing yourself to sort out storage units, you’ll naturally get rid of what you don’t like or don’t use anymore. Learn more
<G-vec00296-002-s094><sort.aussortieren><de> Produktsorte Diese Möglichkeit erlaubt es Ihren Kunden die benötigten Produkte viel schneller auszusortieren.
<G-vec00296-002-s094><sort.aussortieren><en> This feature lets your users to sort out the products they need, much faster.
<G-vec00296-002-s095><sort.aussortieren><de> Doch all die Technikalitäten der Telepathie oder Hypnose oder Suggestionen sind recht interessant und wichtig zu kennen, doch wirklich wichtig ist es zu wissen, daß es unsere Aufgabe ist, zwischen all diesen verschiedenen Bombardierungen mit Gedanken zu unterscheiden und sie auszusortieren und die guten von den schlechten zu trennen.
<G-vec00296-002-s095><sort.aussortieren><en> But all the technicalities of telepathy or hypnosis or suggestion are quite interesting and important to know but really important to know is that it is our job to differentiate between all these different bombardments with thoughts and sort them out and separate the good ones from the bad ones.
<G-vec00296-002-s096><sort.aussortieren><de> Jedoch fiel es Shinji weiterhin schwer, Dinge auszusortieren und wegzuschmeißen, für die sie keinen Nutzen hatten, aber vielleicht mal von besonderer Bedeutung für die eigentlichen Besitzer gewesen war.
<G-vec00296-002-s096><sort.aussortieren><en> Though Shinji still felt more uneasy about having to sort out and throw away things that they had no use for, but might have had a special meaning to the righteous owners.
<G-vec00296-002-s097><sort.aussortieren><de> Zudem besteht, wie die Beschwerdeführerin auch einräumt, ein hervorstechendes Merkmal der Erfindung darin, daß im Falle mehrerer Bieter, die denselben "Wunschpreis" angegeben haben, der Auktionspreis angehoben wird, um die niedrigeren Angebote auszusortieren.
<G-vec00296-002-s097><sort.aussortieren><en> Furthermore, as acknowledged by the appellant, a prominent feature of the invention is that when more than one bidder offers a certain "desired price" the auction price is increased to sort out the lower bids.
<G-vec00296-002-s098><sort.aussortieren><de> Versuche zunächst, zehn Dinge auszusortieren und in den nächsten Tagen nur das zu tragen, was im Schrank geblieben ist.
<G-vec00296-002-s098><sort.aussortieren><en> First try to sort out ten things and in the next few days only wear what has remained in the wardrobe.
<G-vec00296-002-s099><sort.aussortieren><de> Jede private oder öffentliche Institution ist verpflichtet ihre Abfälle auszusortieren.
<G-vec00296-002-s099><sort.aussortieren><en> Any private or public institution is compelled to sort their waste.
<G-vec00296-002-s100><sort.aussortieren><de> Deshalb wage ich es, die Inhalte des Texts auszusortieren und zu ergänzen, fast all die feinsinnigen Worte und tieferen Bedeutungen habe ich jedoch so niedergeschrieben wie ich sie zuvor gehört habe.
<G-vec00296-002-s100><sort.aussortieren><en> Therefore, I dare to sort out and supplement the contents of the text, but almost all the finer words and deeper meanings I wrote the way I heard them before.
<G-vec00296-002-s101><sort.aussortieren><de> Es wird Zeit, sommerliche Kleider, kurze Hosen und Tops auszusortieren.
<G-vec00296-002-s101><sort.aussortieren><en> It is about time to sort out summer dresses, shorts and tops.
