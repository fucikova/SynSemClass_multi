<G-vec00407-001-s057><fold.aufgeben><de> """Blaze"" ist eine garantierte, schnelle Aktion beim Online Poker, da Sie sofort an einem neuen Tisch platziert werden, sobald Sie die Hand, die Sie gerade gespielt haben, aufgeben oder vervollständigen."
<G-vec00407-001-s057><fold.aufgeben><en> """Blaze"" is guaranteed to be high speed online poker action, as you will be instantly moved to a new table as soon as you fold/complete the hand you have just played."
<G-vec00407-001-s058><fold.aufgeben><de> Klicken Sie entweder “Aufgeben” oder “Zeigen” .
<G-vec00407-001-s058><fold.aufgeben><en> Click on either Fold or Call button.
<G-vec00407-001-s059><fold.aufgeben><de> Wenn Sie werfen(klicken Sie den Aufgeben Knopf), verlieren Sie Ihren Einsatz und diese Spielrunde ist für Sie beendet.
<G-vec00407-001-s059><fold.aufgeben><en> If you fold (click on Fold button), you will lose your ante and this game round is over for you.
<G-vec00407-001-s060><fold.aufgeben><de> Ein Spieler, der zögert, bleibt im Spiel: es ist für ihn zum Aufgeben zu spät.
<G-vec00407-001-s060><fold.aufgeben><en> A player who hesitates has stayed in: it is too late for her to fold.
<G-vec00407-001-s061><fold.aufgeben><de> Wenn die anderen aufgeben, hat man nichts verloren, und jeder, der im Spiel bleibt, verliert einen Extrapunkt.
<G-vec00407-001-s061><fold.aufgeben><en> If the others fold you have lost nothing, and if anyone stays in it costs them an extra point.
<G-vec00407-001-s062><fold.aufgeben><de> Wenn Sie Aufgeben, verlieren Sie auch Ihre Paar Plus Wette, falls Sie eine gesetzt haben.
<G-vec00407-001-s062><fold.aufgeben><en> If you fold, you also lose your Pair Plus Bet, if one was made.
<G-vec00499-001-s019><give.aufgeben><de> Wir werden jetzt nicht aufgeben.
<G-vec00499-001-s019><give.aufgeben><en> We will not give up on this.
<G-vec00499-001-s020><give.aufgeben><de> "Sicher wird Arizona nicht, die leicht aufgeben., und es ist nicht ausgeschlossen, dass sie bekommen, spielen die Karte ""Sie sollten dort in meinem Sitz im Flugzeug, die abgestürzt gewesen sind""."
<G-vec00499-001-s020><give.aufgeben><en> "Arizona certainly will not give up so easily, and it is not excluded that they get to play the card of ""you had to be there in my seat on the plane that crashed""."
<G-vec00499-001-s021><give.aufgeben><de> Der Künstler mag krank werden oder seine Arbeit aufgeben.
<G-vec00499-001-s021><give.aufgeben><en> The artist may become ill or give up his work.
<G-vec00499-001-s022><give.aufgeben><de> Der wichtigste Faktor, warum Sie diese EaseQut Bewertung lesen ist, dass Sie wissen möchten, ob es Sie mit dem Rauchen oder anderweitig aufgeben zu unterstützen führt.
<G-vec00499-001-s022><give.aufgeben><en> The main factor why you read this EaseQut Review is that you would like to know if it performs to assist you give up smoking or otherwise.
<G-vec00499-001-s023><give.aufgeben><de> Wenn wir diesem Warnlicht nicht gefolgt sind und doch das Negative ausgesprochen haben, sollten wir daraufhin nicht aufgeben.
<G-vec00499-001-s023><give.aufgeben><en> And when we did not follow this warning signal and still said the wrong words, we should not give up.
<G-vec00499-001-s024><give.aufgeben><de> Aber mehrfach musste ich aufgeben.
<G-vec00499-001-s024><give.aufgeben><en> But I had to give up several times.
<G-vec00499-001-s025><give.aufgeben><de> Je länger diese Richtung dauert, je entschiedener sie wird, um so schwieriger wird die Wendung, um so mehr nähert sich der Augenblick, wo er die Schlacht aufgeben muss.
<G-vec00499-001-s025><give.aufgeben><en> The longer this direction continues, the more decided it becomes, so much the more difficult will be the turning, so much the nearer the moment when he must give up the battle.
<G-vec00499-001-s026><give.aufgeben><de> Wenn bereits eine Nissan GT-R eine große Maschine in der Lage Gesicht zu konkurrieren gegen den besten supercars Markt zu Angesicht, Stellen Sie sich vor, wenn wir aufgeben 2.000 CV Macht und legte es auf Vollgas.
<G-vec00499-001-s026><give.aufgeben><en> If already a Nissan GT-R is a great machine able to compete face to face against the best supercars market, Imagine if we give up 2.000 CV's power and put it to full throttle.
<G-vec00499-001-s027><give.aufgeben><de> Wir sind die ideale Lösung für diejenigen, die das Meer lieben und nicht die Ruhe und die Farben der sizilianischen Landschaft aufgeben wollen.
<G-vec00499-001-s027><give.aufgeben><en> We are the ideal solution for those who love the sea and do not want to give up the tranquility and colors of the Sicilian countryside.
<G-vec00499-001-s028><give.aufgeben><de> In jenem Jahr arbeitete Herbert Cohen noch gegen geringe Bezahlung als Mitgliedswerber beim Jüdischen Hilfswerk, doch auch diese Tätigkeit musste er im November 1938 aufgeben.
<G-vec00499-001-s028><give.aufgeben><en> In that year Herbert was earning a small income soliciting memberships for the Jewish Relief Agency, but he had to give up this job in November 1938.
<G-vec00499-001-s029><give.aufgeben><de> In seiner Filmtrilogie von 2014 breitet Magdy seine Geschichten weiter aus:The Dent (Die Delle) erzählt vom Fortschrittsglauben der Bewohner einer Kleinstadt, die im Wettbewerb um die Ausrichtung der Olympischen Spiele jeden Maßstab verlieren, sich auf irrationale und maßlose Weise präsentieren und schlussendlich aufgeben müssen.
<G-vec00499-001-s029><give.aufgeben><en> In his film trilogy from 2014, the artist extends his stories.The Dent tells of the belief in progress of the residents of a small city who seem to have lost all sense of proportion in a competition to host the Olympic Games and present themselves in an irrational and excessive way, and ultimately have to give up.
<G-vec00499-001-s030><give.aufgeben><de> Stündlich fragte die Polizistin Ko Na, ob sie den Widerstand aufgeben würden, aber die Praktizierenden weigerten sich.
<G-vec00499-001-s030><give.aufgeben><en> Policewoman Ko Na checked to see if they would give up every hour, but the practitioners refused.
<G-vec00499-001-s031><give.aufgeben><de> Ich will das Vergnügen, mit dir intime Gespräche zu führen nicht aufgeben, nur weil du einen Gatten hast.
<G-vec00499-001-s031><give.aufgeben><en> I do not want to give up the joy of intimate talks with you simply because you have a husband.
<G-vec00499-001-s032><give.aufgeben><de> Aber das Wichtigste, was in diesem Fall würde das sein, was die schrecklichsten Gedanken oder Sie besuchen, keine Panik und aufgeben.
<G-vec00499-001-s032><give.aufgeben><en> But the most important thing in this case, no matter what the worst thoughts or visit you do not need to panic and give up.
<G-vec00499-001-s033><give.aufgeben><de> Das Leben ist für diese Individuen irgendwann einfach unerträglich schwer und mühsam geworden und alles gute Zureden hilft nichts, um diesen Fakt zu ändern, sodass man irgendwann auch als Zuschauer gewillt ist, Byeong-woo zu verzeihen, sollte er aufgeben.
<G-vec00499-001-s033><give.aufgeben><en> Life has simply become unbearable and extremely tiresome for those individuals at some point and all the well-intented talking doesn't change anything about that fact, so that eventually even the viewer would be willing to forgive Byeong-woo should he decide to give up.
<G-vec00499-001-s034><give.aufgeben><de> Das Timeline Layout selbst scheint in einer Realitäts- freien Zone entworfen zu sein, wo alle mobile Geräte 851 Pixel Bilder anzeigen können, währen offensichtlich die Tatsache ignoriert wurden das die meisten Smartphone Benutzer gezwungen werden, horizontal hin und her zu blättern, bis Sie es aufgeben und frustriert die Seite verlassen.
<G-vec00499-001-s034><give.aufgeben><en> The Timeline layout itself seems to have been designed in a reality-free zone where all mobile devices can display 851 pixel images while blatantly ignoring the fact that most smartphone users will be forced to horizontally scroll back and forth until they give up and leave in frustration.
<G-vec00499-001-s035><give.aufgeben><de> Menschen, die in harten Zeiten nicht einfach aufgeben, sich kümmern um die Familie und das Gemeinwesen, die glauben, die Hoffnung und Trost suchen und manchmal bei Freunden, manchmal im Whiskey finden.
<G-vec00499-001-s035><give.aufgeben><en> People who do not simply give up in hard times, take care of the family and the community, who believe, search for hope and consolation and sometimes find them with friends and sometimes with whiskey.
<G-vec00499-001-s036><give.aufgeben><de> Es wäre verrückt, es zu versuchen, ich würde aufgeben.
<G-vec00499-001-s036><give.aufgeben><en> It would be crazy to do it then, I would give up.
<G-vec00499-001-s037><give.aufgeben><de> Sie vermittelt den Eindruck, dass wir alles aufgeben und in einer Höhle leben sollten.
<G-vec00499-001-s037><give.aufgeben><en> It tends to give the impression that we should give up everything and go live in a cave.
<G-vec00499-001-s038><give.aufgeben><de> Sofort setzte ihn Lai Baohua, der Leiter der Abteilung, unter Druck, Falun Gong aufzugeben.
<G-vec00499-001-s038><give.aufgeben><en> Right away, Lai Baohua, chief of the division, pressured him to give up Falun Gong.
<G-vec00499-001-s039><give.aufgeben><de> Das andere Extrem ist, wenn Leute dich dazu anhalten, jede Erwartung der Kontrolle gegenüber allem aufzugeben.
<G-vec00499-001-s039><give.aufgeben><en> The other extreme is when other people encourage you to give up exerting any control over anything at all.
<G-vec00499-001-s040><give.aufgeben><de> Im Jahr 2014 schienen sie ihr Ziel aufzugeben und unterstützten anarchistische Gruppen um zu randalieren und das Land zu destabilisieren, das sind die Guarimbas[4].
<G-vec00499-001-s040><give.aufgeben><en> In 2014, they seemed to give up their goal and supported anarchist groups to vandalize and destabilize the country, it is the Guarimba[4].
<G-vec00499-001-s041><give.aufgeben><de> Um mich zu zwingen, das Praktizieren von Falun Gong aufzugeben, beauftragten Polizisten Gefangene, mich zu überwachen.
<G-vec00499-001-s041><give.aufgeben><en> To force me to give up practising Falun Gong, officers ordered convicts to monitor me.
<G-vec00499-001-s042><give.aufgeben><de> Vermutlich ist ein großer Teil des Vitals unfähig, seine Haltung zu ändern und seine Launen aufzugeben oder seine Art und Weise, etwas zu empfangen; sonst könnten diese Depressionen nicht so akut sein.
<G-vec00499-001-s042><give.aufgeben><en> There must be a large part of it unable to change its position and give up its moods or its way of receiving things; otherwise these depressions could not be so acute.
<G-vec00499-001-s043><give.aufgeben><de> Wichtiger noch ist die angebliche Weigerung jener Fremden, sich der französischen Kultur vollständig zu assimilieren (was auch den Gesinnungswandel mit sich bringen würde, soupe au cochon zu essen), mit anderen Worten, ihre Weigerung, einen Teil ihrer Identität aufzugeben, um im Gegenzug in die französische Gesellschaft integriert oder ihr assimiliert (also von ihr absorbiert) zu werden.
<G-vec00499-001-s043><give.aufgeben><en> Even more crucial is the alleged refusal of those foreigners to fully assimilate into French culture (this would also entail conversion to the eating of soupe au cochon), in other words, to give up a part of their identity in return for becoming integrated or assimilated (namely absorbed) within French society.
<G-vec00499-001-s044><give.aufgeben><de> Das Gefängnis hält seit August 2010 intensive Gehirnwäsche-Sitzungen ab, um die Kontrolle über die Falun Gong-Praktizierenden zu intensivieren und zu versuchen, sie zu zwingen, ihren Glauben an Faluln Gong aufzugeben.
<G-vec00499-001-s044><give.aufgeben><en> The prison has been holding brainwashing sessions since August 2010 to intensify control over the Falun Gong practitioners and to try to force them to give up their belief.
<G-vec00499-001-s045><give.aufgeben><de> es gibt zuerst die Wette, die durch die kommunistische Partei unternommen wurde, den Werten der Vergangenheit treu zu bleiben, und die es nicht schafft, sich wieder in Frage zu stellen, das heißt die Priorität aufzugeben, die der gemeinsamen Eigenschaft eingeräumt wurde, um zu wagen, die gemeinsame Eigenschaft zu restaurieren und der lokalen Demokratie eine Stelle zu gewähren, die so den Mythos der Diktatur der Partei und den Zentralismus des Staates beendet.
<G-vec00499-001-s045><give.aufgeben><en> there is initially the bet undertaken by the Communist Party to remain faithful to the values of last and which is not able to be called into question, i.e. to give up the priority granted to the collective ownership to dare to restore the common property and to grant a place to the local democracy, putting thus fine at the myth dictatorship of the party and the centralism of the state.
<G-vec00499-001-s046><give.aufgeben><de> Als ihre 89 Jahre alte Mutter starb, durfte sie sie nicht ein letztes Mal besuchen, weil sie sich weigerte, ihren Glauben aufzugeben.
<G-vec00499-001-s046><give.aufgeben><en> When her 89-year old mother was dying, she was not allowed to visit her for the last time because she refused to give up her belief.
<G-vec00499-001-s047><give.aufgeben><de> Frau Jin und Herr Liu wurden wiederholt verfolgt, weil sie sich weigerten, ihren Glauben an Falun Gong aufzugeben.
<G-vec00499-001-s047><give.aufgeben><en> Ms. Jin and Mr. Liu have been repeatedly persecuted because they refuse to give up their belief in Falun Gong.
<G-vec00499-001-s048><give.aufgeben><de> Im Zwangsarbeitslager erlitt Zhao Ming oft Misshandlungen einschließlich Folter, Misshandlungen mit Elektroschockgeräten, harte Zwangsarbeit usw.. Außerdem erlitt er auch verschiedene Arten von geistiger Misshandlungen, wie die Versuche ihn durch Gehirnwäsche dazu zu zwingen, seinen Glauben an Falun Gong aufzugeben.
<G-vec00499-001-s048><give.aufgeben><en> In the labour camp, Ming frequently suffered maltreatment, including cruel torture, abuse with electric batons, forced hard labour and so on. At the same time, he also endured different kinds of spiritual abuse, such as the brainwashing attempts to force him to give up his belief in Falun Dafa.
<G-vec00499-001-s049><give.aufgeben><de> Wang Yaling wurde Zeugin, wie eine andere Praktizierende, Yang Chunfang aus der Stadt Jinzhou, bis zur Behinderung zusammen geschlagen wurde, weil sie sich weigerte, ihren Glauben aufzugeben.
<G-vec00499-001-s049><give.aufgeben><en> She witnessed another practitioner, Yang Chunfang from Jinzhou City, who was beaten to disability for refusing to give up her belief.
<G-vec00499-001-s050><give.aufgeben><de> Und um auf den Zweiten Weltkrieg zurückzukommen, genau damit haben sich die Denker und Schriftsteller damals eigentlich auseinandergesetzt – mit dieser Unterscheidung zwischen einem kulturellen System des metaphorischen Austauschs auf der einen Seite, also einem hyperrealen, kapitalistischen Raum, in dem alles gegen Geld ausgetauscht werden kann, das wiederum gegen alles andere ausgetauscht werden kann; und auf der anderen Seite einem Raum, in dem Menschen mobilisiert und motiviert werden, sich für den Krieg zu opfern, ihr Geld, ihre Zeit, sogar ihr Leben aufzugeben.
<G-vec00499-001-s050><give.aufgeben><en> And actually, to go back to WWII, thinkers and writers then were grappling with this, too – this distinction between, on the one hand, a cultural system of metaphoric exchange, a hyperreal, capitalist space where anything can be exchanged for money, which can be exchanged for anything else; and, on the other hand, a space that was being mobilized to motivate people to sacrifice for war, to give up money, time, even their lives.
<G-vec00499-001-s051><give.aufgeben><de> Während seiner Reise in die Türkei verkündete der russische Präsident Wladimir Putin die Entscheidung das South-Stream-Pipeline Projekt aufzugeben, zu Gunsten einer neuen, in die Türkei umgeleiteten Route.
<G-vec00499-001-s051><give.aufgeben><en> During his trip to Turkey Russian President Vladimir Putin announced the decision to give up the South Stream pipeline project in favor of a new route redirected to Turkey.
<G-vec00499-001-s052><give.aufgeben><de> Was seid ihr bereit aufzugeben für Mein Königreich und für die tiefe, innere Freude, die ihr fühlen werdet in Meinem Willen, mit Mir zu arbeiten und Seelen zu erretten.
<G-vec00499-001-s052><give.aufgeben><en> What are you willing to give up for the sake of My Kingdom and the deep inner joy you will feel in My will, working with Me to save souls.
<G-vec00499-001-s053><give.aufgeben><de> Es war einfach aufzugeben.
<G-vec00499-001-s053><give.aufgeben><en> It was easy to give it away.
<G-vec00499-001-s054><give.aufgeben><de> Nachdem wir bereits eine Veranstaltung geplant für den Sonntagmorgen, die mich von den Scheck halten bei 10, eher als einen guten Service gehalten, zog ich, nicht aufzugeben.
<G-vec00499-001-s054><give.aufgeben><en> Having already planned an event for the Sunday morning that kept me from keeping the check out at 10, rather than give a good service, I preferred not to give up.
<G-vec00499-001-s055><give.aufgeben><de> Weil sie sich weigerte, das Praktizieren von Falun Gong aufzugeben, wurde sie bis März 2005 nicht entlassen.
<G-vec00499-001-s055><give.aufgeben><en> Because Ms. Liang refused to give up her practice of Falun Gong, she was not released until March 2005.
<G-vec00499-001-s056><give.aufgeben><de> Das Wichtigste ist es, nicht aufzugeben und mit euren Nachbarn (Königen und Statthaltern) zu sprechen, um euch bei der Entscheidung zu helfen, welchem Königreich ihr angehören möchtet.
<G-vec00499-001-s056><give.aufgeben><en> The most important thing is don’t give up, but talk to your neighbors (kings and governors) to help you decide what kingdom you would like to join.
<G-vec00376-002-s042><discontinue.aufgeben><de> Hieraus ergeben sich die folgenden Konsequenzen: Unternehmen, die eine Hauptniederlassung in Großbritannien haben, können nicht mehr über den Europäischen Pass tätig werden, müssen die Aktivität also entweder aufgeben (Fall 1), ihre Tätigkeit als Zweigstelle eines Drittstaats fortsetzen (Fall 2) oder eine erlaubnistragende Tochtergesellschaft in einem Mitgliedstaat (Fall 3) nutzen.
<G-vec00376-002-s042><discontinue.aufgeben><en> This will have the following consequences: Companies having their principal establishment in the UK will no longer be able to operate via the European passport and thus will have to either discontinue the activity (case 1), continue their activity as a branch of a third country (case 2), or use a subsidiary in a Member State holding the required authorisation (case 3).
<G-vec00376-002-s043><discontinue.aufgeben><de> FANUC kann die Website in beliebigen Punkten – einschließlich der Verfügbarkeit von Funktionen der Website – jederzeit einstellen, ändern, aussetzen oder aufgeben.
<G-vec00376-002-s043><discontinue.aufgeben><en> FANUC may terminate, change, suspend or discontinue any aspect of the Website, including the availability of any features of the Website, at any time.
<G-vec00382-002-s038><give.aufgeben><de> Die Wärter im Zwangsarbeitslager folterten sie, entzogen ihr den Schlaf, sperrten sie in Einzelhaft und verweigerten ihr die Toilettenbenutzung, um sie zu zwingen, Falun Gong aufzugeben.
<G-vec00382-002-s038><give.aufgeben><en> Guards at the forced labour camp have tortured her to try to get her to give up Falun Gong, subjecting her to sleep deprivation, solitary confinement, and denying her use of the toilet.
<G-vec00382-002-s039><give.aufgeben><de> In der Zeit als ich mit Melina trainieren konnte habe ich gelernt auch nach einem Misserfolg nicht aufzugeben.
<G-vec00382-002-s039><give.aufgeben><en> In the time when I trained with Melina I learned to never give up even after a failure.
<G-vec00382-002-s040><give.aufgeben><de> Daher erscheint es in einer Zeit, in der eine größtmögliche Effizienz angestrebt wird, nicht sinnvoll, die Bienenzucht aufzugeben, wenn der Kosten-Nutzen-Faktor beweist, wie unklug eine solche Entscheidung ist.
<G-vec00382-002-s040><give.aufgeben><en> Therefore, at a time when all kinds of efficiency are being sought, it does not appear to make sense to give up the activity when the cost/benefit ratio shows how foolish such a decision is.
<G-vec00382-002-s041><give.aufgeben><de> Der Zweck der Folter war, sie und andere Praktizierende zu zwingen, ihren Glauben an Falun Dafa aufzugeben.
<G-vec00382-002-s041><give.aufgeben><en> The purpose of the torture was to coerce her and other practitioners to give up their Falun Gong practice.
<G-vec00382-002-s042><give.aufgeben><de> Der unwiderstehliche optimistische Schwung, mit dem Kinder ihre imaginären Spielräume erbauen und verwandeln, entspricht der Vitalität der universellen Botschaft, die dieses Märchen zum Ausdruck bringt: Der Wille niemals aufzugeben ist es, mit dem Hänsel und Gretel das gute Ende ihrer Geschichte selbst herbeiführen.
<G-vec00382-002-s042><give.aufgeben><en> The children’s optimistic verve while constructing and transforming imaginary spaces proves to be similar to the vitality of the fairy tale’s universal message: The will never to give up always leads to an happy end. The result is a poetic spectacle which will capture the hearts – not only of children.
<G-vec00382-002-s043><give.aufgeben><de> Der Film erzählt die Geschichte einer Gruppe Fabrikarbeiter, die ihre Jobs verlieren aber sich weigern aufzugeben.
<G-vec00382-002-s043><give.aufgeben><en> The film tells the story of a group of Portuguese factory workers who are losing their jobs but don't give in.
<G-vec00382-002-s044><give.aufgeben><de> Und dazu müssen sie lernen, sich selbst Ziele zu setzen, Verantwortung zu übernehmen und auch bei Rückschlägen nicht aufzugeben.
<G-vec00382-002-s044><give.aufgeben><en> Therefore they have to learn to set goals for themselves, take over responsibility and to not give up while they experience a rebound.
<G-vec00382-002-s045><give.aufgeben><de> Sie hielten an, um sich die Stelltafeln durchzulesen, welche die Foltermethoden darstellen, die verwendet werden, um die Falun Gong Praktizierenden dazu zu zwingen, ihren Glauben aufzugeben.
<G-vec00382-002-s045><give.aufgeben><en> Passers-by stopped to read the display boards exposing the methods of torture in cruel attempts to force Falun Gong practitioners to give up their beliefs.
<G-vec00382-002-s046><give.aufgeben><de> Sie sind nicht bereit, ihr sündiges Leben aufzugeben.
<G-vec00382-002-s046><give.aufgeben><en> They are not ready to give up their lives of sin, so they forget.
<G-vec00382-002-s047><give.aufgeben><de> Manchmal, wenn wir überall um uns Mühen, Schwierigkeiten und Unrecht sehen, sind wir versucht aufzugeben.
<G-vec00382-002-s047><give.aufgeben><en> Sometimes, when we see the troubles, difficulties and wrongs all around us, we are tempted to give up.
<G-vec00382-002-s048><give.aufgeben><de> Doch stellte ich fest, dass zu dem Zeitpunkt, da ich das Ende des vierten Kapitels erreichte, dass es nötig wurde, die Sache aufzugeben.
<G-vec00382-002-s048><give.aufgeben><en> But I found that by the time I reached the end of the fourth chapter, it was necessary to give it up.
<G-vec00382-002-s049><give.aufgeben><de> Wenn man manchmal seine Ziele nicht sofort erreicht, ist es wichtig dran zu bleiben und nicht aufzugeben.
<G-vec00382-002-s049><give.aufgeben><en> Sometimes when you do not reach your goals right away, it’s important to stay tuned and not give up.
<G-vec00382-002-s050><give.aufgeben><de> Sie wusste, dass sie auserwählt war, ihren Sohn eines Tages aufzugeben, um die Menschheit zu erlösen.
<G-vec00382-002-s050><give.aufgeben><en> She knew she was chosen to give her Son up someday to redeem mankind.
<G-vec00382-002-s051><give.aufgeben><de> Bilals Herr ließ ihn auf dem brennenden Sand liegen und ließ große Felsenplatten auf seine Brust legen, aber er weigerte sich, seinen neuen Glauben aufzugeben.
<G-vec00382-002-s051><give.aufgeben><en> Bilal’s master would make him lie on burning sand and have large slabs of rock placed on his chest, but he refused to give up his new faith.
<G-vec00382-002-s052><give.aufgeben><de> Diese Motivation, nie aufzugeben und Grenzen zu verschieben, möchte Denise Schindler weitergeben.
<G-vec00382-002-s052><give.aufgeben><en> Her motivation to never give up and push the limits is something she would like to pass on to others.
<G-vec00382-002-s053><give.aufgeben><de> In den Komitees und Zirkeln kann man Leute antreffen, die sich sogar in das Spezialstudium irgendeines Zweiges der Eisenproduktion vertiefen, aber man kann fast keine Beispiele anführen, daß Mitglieder der Organisationen (die, wie es oft der Fall ist, gezwungen sind, aus diesem oder jenem Grunde die praktische Arbeit aufzugeben) sich speziell mit dem Sammeln von Material über irgendeine aktuelle Frage unseres sozialen und politischen Lebens befaßten, die zu einer sozialdemokratischen Arbeit in anderen Schichten der Bevölkerung Anlaß geben könnte.
<G-vec00382-002-s053><give.aufgeben><en> In the committees and study circles, one can meet people who are immersed in the study even of some special branch of the metal industry; but one can hardly ever find members of organisations (obliged, as often happens, for some reason or other to give up practical work) who are especially engaged in gathering material on some pressing question of social and political life in our country which could serve as a means for conducting Social-Democratic work among other strata of the population.
<G-vec00382-002-s054><give.aufgeben><de> Bereitschaft, Widerstände aufzugeben und sich auf den Fluss des Lebens einzustimmen.
<G-vec00382-002-s054><give.aufgeben><en> being willing to give up resistance and to attune with the flow of life
<G-vec00382-002-s055><give.aufgeben><de> Die Menschen heutzutage neigen dazu, diesen großartigen Kultivierungsweg angesichts der grausamen Verfolgung aufzugeben, noch bevor sie durch das Praktizieren körperlich und geistig profitiert haben, weil sie nicht standhaft an diese aufrichtige Kultivierungspraxis glauben.
<G-vec00382-002-s055><give.aufgeben><en> Before really benefiting from the cultivation practice physically and spiritually, without having steadfast belief in the righteous cultivation practice, people nowadays tend to give up this great cultivation way in the face of material benefits and the cruel persecution.
<G-vec00382-002-s056><give.aufgeben><de> Jetzt ist nicht die Zeit, um aufzugeben.
<G-vec00382-002-s056><give.aufgeben><en> This is not the time to give up.
<G-vec00497-002-s038><give_up.aufgeben><de> Die Wärter im Zwangsarbeitslager folterten sie, entzogen ihr den Schlaf, sperrten sie in Einzelhaft und verweigerten ihr die Toilettenbenutzung, um sie zu zwingen, Falun Gong aufzugeben.
<G-vec00497-002-s038><give_up.aufgeben><en> Guards at the forced labour camp have tortured her to try to get her to give up Falun Gong, subjecting her to sleep deprivation, solitary confinement, and denying her use of the toilet.
<G-vec00497-002-s039><give_up.aufgeben><de> In der Zeit als ich mit Melina trainieren konnte habe ich gelernt auch nach einem Misserfolg nicht aufzugeben.
<G-vec00497-002-s039><give_up.aufgeben><en> In the time when I trained with Melina I learned to never give up even after a failure.
<G-vec00497-002-s040><give_up.aufgeben><de> Daher erscheint es in einer Zeit, in der eine größtmögliche Effizienz angestrebt wird, nicht sinnvoll, die Bienenzucht aufzugeben, wenn der Kosten-Nutzen-Faktor beweist, wie unklug eine solche Entscheidung ist.
<G-vec00497-002-s040><give_up.aufgeben><en> Therefore, at a time when all kinds of efficiency are being sought, it does not appear to make sense to give up the activity when the cost/benefit ratio shows how foolish such a decision is.
<G-vec00497-002-s041><give_up.aufgeben><de> Der Zweck der Folter war, sie und andere Praktizierende zu zwingen, ihren Glauben an Falun Dafa aufzugeben.
<G-vec00497-002-s041><give_up.aufgeben><en> The purpose of the torture was to coerce her and other practitioners to give up their Falun Gong practice.
<G-vec00497-002-s042><give_up.aufgeben><de> Der unwiderstehliche optimistische Schwung, mit dem Kinder ihre imaginären Spielräume erbauen und verwandeln, entspricht der Vitalität der universellen Botschaft, die dieses Märchen zum Ausdruck bringt: Der Wille niemals aufzugeben ist es, mit dem Hänsel und Gretel das gute Ende ihrer Geschichte selbst herbeiführen.
<G-vec00497-002-s042><give_up.aufgeben><en> The children’s optimistic verve while constructing and transforming imaginary spaces proves to be similar to the vitality of the fairy tale’s universal message: The will never to give up always leads to an happy end. The result is a poetic spectacle which will capture the hearts – not only of children.
<G-vec00497-002-s043><give_up.aufgeben><de> Der Film erzählt die Geschichte einer Gruppe Fabrikarbeiter, die ihre Jobs verlieren aber sich weigern aufzugeben.
<G-vec00497-002-s043><give_up.aufgeben><en> The film tells the story of a group of Portuguese factory workers who are losing their jobs but don't give in.
<G-vec00497-002-s044><give_up.aufgeben><de> Und dazu müssen sie lernen, sich selbst Ziele zu setzen, Verantwortung zu übernehmen und auch bei Rückschlägen nicht aufzugeben.
<G-vec00497-002-s044><give_up.aufgeben><en> Therefore they have to learn to set goals for themselves, take over responsibility and to not give up while they experience a rebound.
<G-vec00497-002-s045><give_up.aufgeben><de> Sie hielten an, um sich die Stelltafeln durchzulesen, welche die Foltermethoden darstellen, die verwendet werden, um die Falun Gong Praktizierenden dazu zu zwingen, ihren Glauben aufzugeben.
<G-vec00497-002-s045><give_up.aufgeben><en> Passers-by stopped to read the display boards exposing the methods of torture in cruel attempts to force Falun Gong practitioners to give up their beliefs.
<G-vec00497-002-s046><give_up.aufgeben><de> Sie sind nicht bereit, ihr sündiges Leben aufzugeben.
<G-vec00497-002-s046><give_up.aufgeben><en> They are not ready to give up their lives of sin, so they forget.
<G-vec00497-002-s047><give_up.aufgeben><de> Manchmal, wenn wir überall um uns Mühen, Schwierigkeiten und Unrecht sehen, sind wir versucht aufzugeben.
<G-vec00497-002-s047><give_up.aufgeben><en> Sometimes, when we see the troubles, difficulties and wrongs all around us, we are tempted to give up.
<G-vec00497-002-s048><give_up.aufgeben><de> Doch stellte ich fest, dass zu dem Zeitpunkt, da ich das Ende des vierten Kapitels erreichte, dass es nötig wurde, die Sache aufzugeben.
<G-vec00497-002-s048><give_up.aufgeben><en> But I found that by the time I reached the end of the fourth chapter, it was necessary to give it up.
<G-vec00497-002-s049><give_up.aufgeben><de> Wenn man manchmal seine Ziele nicht sofort erreicht, ist es wichtig dran zu bleiben und nicht aufzugeben.
<G-vec00497-002-s049><give_up.aufgeben><en> Sometimes when you do not reach your goals right away, it’s important to stay tuned and not give up.
<G-vec00497-002-s050><give_up.aufgeben><de> Sie wusste, dass sie auserwählt war, ihren Sohn eines Tages aufzugeben, um die Menschheit zu erlösen.
<G-vec00497-002-s050><give_up.aufgeben><en> She knew she was chosen to give her Son up someday to redeem mankind.
<G-vec00497-002-s051><give_up.aufgeben><de> Bilals Herr ließ ihn auf dem brennenden Sand liegen und ließ große Felsenplatten auf seine Brust legen, aber er weigerte sich, seinen neuen Glauben aufzugeben.
<G-vec00497-002-s051><give_up.aufgeben><en> Bilal’s master would make him lie on burning sand and have large slabs of rock placed on his chest, but he refused to give up his new faith.
<G-vec00497-002-s052><give_up.aufgeben><de> Diese Motivation, nie aufzugeben und Grenzen zu verschieben, möchte Denise Schindler weitergeben.
<G-vec00497-002-s052><give_up.aufgeben><en> Her motivation to never give up and push the limits is something she would like to pass on to others.
<G-vec00497-002-s053><give_up.aufgeben><de> In den Komitees und Zirkeln kann man Leute antreffen, die sich sogar in das Spezialstudium irgendeines Zweiges der Eisenproduktion vertiefen, aber man kann fast keine Beispiele anführen, daß Mitglieder der Organisationen (die, wie es oft der Fall ist, gezwungen sind, aus diesem oder jenem Grunde die praktische Arbeit aufzugeben) sich speziell mit dem Sammeln von Material über irgendeine aktuelle Frage unseres sozialen und politischen Lebens befaßten, die zu einer sozialdemokratischen Arbeit in anderen Schichten der Bevölkerung Anlaß geben könnte.
<G-vec00497-002-s053><give_up.aufgeben><en> In the committees and study circles, one can meet people who are immersed in the study even of some special branch of the metal industry; but one can hardly ever find members of organisations (obliged, as often happens, for some reason or other to give up practical work) who are especially engaged in gathering material on some pressing question of social and political life in our country which could serve as a means for conducting Social-Democratic work among other strata of the population.
<G-vec00497-002-s054><give_up.aufgeben><de> Bereitschaft, Widerstände aufzugeben und sich auf den Fluss des Lebens einzustimmen.
<G-vec00497-002-s054><give_up.aufgeben><en> being willing to give up resistance and to attune with the flow of life
<G-vec00497-002-s055><give_up.aufgeben><de> Die Menschen heutzutage neigen dazu, diesen großartigen Kultivierungsweg angesichts der grausamen Verfolgung aufzugeben, noch bevor sie durch das Praktizieren körperlich und geistig profitiert haben, weil sie nicht standhaft an diese aufrichtige Kultivierungspraxis glauben.
<G-vec00497-002-s055><give_up.aufgeben><en> Before really benefiting from the cultivation practice physically and spiritually, without having steadfast belief in the righteous cultivation practice, people nowadays tend to give up this great cultivation way in the face of material benefits and the cruel persecution.
<G-vec00497-002-s056><give_up.aufgeben><de> Jetzt ist nicht die Zeit, um aufzugeben.
<G-vec00497-002-s056><give_up.aufgeben><en> This is not the time to give up.
<G-vec00519-002-s028><peg.aufgeben><de> Als die SNB die Bindung aufgab, gab es keinen Markt bis unter 0,88, und der Broker konnte die Stop-Loss-Aufträge nicht ausführen.
<G-vec00519-002-s028><peg.aufgeben><en> When the SNB dropped the peg, there was no market to be found all the way to below 0.88, and the broker could not execute the stop loss orders.
<G-vec00739-002-s050><surrender.aufgeben><de> Giddianhi, der Gadiantonführer, verlangt, daß Lachoneus und die Nephiten sich und ihre Länder aufgeben—Lachoneus bestimmt Gidgiddoni zum obersten Hauptmann der Heere—Die Nephiten sammeln sich im Land Zarahemla und Überfluß, um sich zu verteidigen.
<G-vec00739-002-s050><surrender.aufgeben><en> Giddianhi, the Gadianton leader, demands that Lachoneus and the Nephites surrender themselves and their lands—Lachoneus appoints Gidgiddoni as chief captain of the armies—The Nephites assemble in Zarahemla and Bountiful to defend themselves. About A.D. 16–18.
<G-vec00739-002-s051><surrender.aufgeben><de> Es erscheint ein Button auf dem Bildschirm mit der Aufschrift AUFGEBEN.
<G-vec00739-002-s051><surrender.aufgeben><en> There will be a button on the screen which says SURRENDER.
<G-vec00739-002-s052><surrender.aufgeben><de> Das bedeutet, du kannst das Ego nicht aufgeben, wenn du unbewusst bist und du kannst es nicht aufgeben, wenn du bewusst bist.
<G-vec00739-002-s052><surrender.aufgeben><en> So you cannot surrender when you are unaware and you cannot surrender when you are aware.
<G-vec00739-002-s053><surrender.aufgeben><de> Bei harten Summen wie 12, 13 oder 14 sollte man niemals aufgeben.
<G-vec00739-002-s053><surrender.aufgeben><en> You should never surrender hard totals of 12, 13, or 14.
<G-vec00739-002-s054><surrender.aufgeben><de> Währenddessen greift Mako Ming-Hua an, die ihre Wasserpeischen verliert, doch sie will nicht aufgeben und springt in ein unterirdisches Wasserbecken, in welches Mako ihr aber folgt.
<G-vec00739-002-s054><surrender.aufgeben><en> Having caught her without water at last, Mako urges the waterbender to give up; unwilling to surrender, Ming-Hua jumps into a hole in the earth beneath them.
<G-vec00739-002-s055><surrender.aufgeben><de> Wenn der Händler eine 10 oder ein Ass hält und Sie haben insgesamt 15 oder 16 mit 10 oder 9, sollten Sie aufgeben.
<G-vec00739-002-s055><surrender.aufgeben><en> If the dealer is holding a 10 or an ace and you have a total of 15 or 16 with a 10 or 9, you should surrender.
<G-vec00739-002-s056><surrender.aufgeben><de> Der Ministerpräsident Arsenij Jacenjuk fiel mit Drohungen über die Donezker und Lugansker Aufständischen her und forderte ihr sofortiges Aufgeben, wobei er auf die Genfer Vereinbarung verwies, in deren Rahmen „Russland gezwungen war, den Extremismus zu verurteilen“.
<G-vec00739-002-s056><surrender.aufgeben><en> Premier Arseny Yatsenyuk heaped threats onto the Donetsk and Lugansk rebels, demanding their immediate surrender and referring to the Geneva agreement, in the framework of which “Russia was forced to condemn extremism.”
<G-vec00739-002-s057><surrender.aufgeben><de> * Spätes Aufgeben – Sie können erst aufgeben, nachdem der Dealer geprüft hat, ob er ein Blackjack hat und nur, wenn er kein Blackjack hat.
<G-vec00739-002-s057><surrender.aufgeben><en> Late Surrender: Surrender allowed after the dealer has checked for blackjack, if he does not have blackjack the player loses half his/her bet.
<G-vec00739-002-s058><surrender.aufgeben><de> Wenn Sie aufgeben, verlieren Sie die Hälfte des Wetteinsatzes, was bedeutet, dass Sie immerhin die andere Hälfte behalten können.
<G-vec00739-002-s058><surrender.aufgeben><en> When you surrender, you lose half the bet, which means you still get to keep half of it.
<G-vec00739-002-s059><surrender.aufgeben><de> Dann verringert sich auch ihr Widerstand gegen die Hilfe, die ihr im jenseitigen Reich immer wieder geboten wird, und Aufgeben des Widerstandes ist schon beginnender Aufstieg, denn jeder Regung einer solchen Seele wird Rechnung getragen und ihr ein kleines Licht geschenkt, das sie beglückt und ihr Verlangen danach vergrößert.
<G-vec00739-002-s059><surrender.aufgeben><en> This is also decreasing its rejection of accepting the help which it is repeatedly offered in the realm of the beyond, and its surrender of opposition is the beginning of progress, for every inclination of such a soul is taken into account and it is bestowed with a small light, which makes it happy and increases its desire for it.
<G-vec00739-002-s060><surrender.aufgeben><de> Ist man der Meinung, der Croupier hat das bessere Blatt, kann man aussteigen, indem man auf den „Aussteigen“- oder „Aufgeben“-Button auf dem Bildschirm klickt.
<G-vec00739-002-s060><surrender.aufgeben><en> If you think your hand is worse than the dealer's, you can fold by clicking on the 'Fold' or 'Surrender' button on your screen.
<G-vec00739-002-s061><surrender.aufgeben><de> Hat der Dealer eine Blackjack-Hand, so ist das Aufgeben nicht mehr möglich.
<G-vec00739-002-s061><surrender.aufgeben><en> If the dealer has a blackjack hand, then surrender is not available.
<G-vec00739-002-s062><surrender.aufgeben><de> It 's so ermüdend und so deprimierend, aber Sie don ' t aufgeben wollen.
<G-vec00739-002-s062><surrender.aufgeben><en> It is so tiring and so depressing, but you do not want to surrender.
<G-vec00739-002-s063><surrender.aufgeben><de> Man kann sich nur vorstellen, wie brutal dieses Terrain sein muss, wenn ein fünfmaliger Guinness-Weltrekordhalter, der zweimal den Atlantik überquerte und Ausdauer-Herausforderungen wie das Durchfahren der Gobi Wüste absolvierte, in der frühen Phase der Wanderung aufgeben musste.
<G-vec00739-002-s063><surrender.aufgeben><en> It can only be imagined how brutal this terrain must be, when a 5 times Guinness World Record holder who rowed across the Atlantic twice and completed endurance challenges such as running through Gobi desert, had to surrender in the early stage of the trek.
<G-vec00739-002-s064><surrender.aufgeben><de> Von Mäusen und Menschen war weder eine Themenausstellung, noch eine Ausstellung mit These, sondern stellte Fragen über Geburt und Verlust, Sterben und Aufgeben, Trauer und Nostalgie.
<G-vec00739-002-s064><surrender.aufgeben><en> Of Mice and Men was neither a thematic exhibition nor an exhibition that followed a certain thesis but rather posed larger questions about Birth and Loss, Death and Surrender, Sorrow and Nostalgia.
<G-vec00739-002-s065><surrender.aufgeben><de> [Aufgeben zählt nicht].
<G-vec00739-002-s065><surrender.aufgeben><en> [Surrender doesn't count].
<G-vec00739-002-s066><surrender.aufgeben><de> Am Ende der 60 Sekunden, wenn 70% des Teams dem Aufgeben nicht zugestimmt haben, scheitert das Votum und kann für drei Minuten nicht mehr initiiert werden.
<G-vec00739-002-s066><surrender.aufgeben><en> At the end of the 60 seconds, if 70% of the team has not agreed to surrender, the vote fails and cannot be initiated again for three minutes.
<G-vec00739-002-s067><surrender.aufgeben><de> Aufgeben: Wenn Ihre Gesamtpunkte genannt werden, können Sie das Spiel für den Rest der Runde einstellen und die Hälfte Ihres Einsatzes aufgeben.
<G-vec00739-002-s067><surrender.aufgeben><en> Surrender As your point total is announced, you can choose to discontinue play of your hand for that round and surrender half of your bet amount.
<G-vec00739-002-s068><surrender.aufgeben><de> Sie können bei Vegas Single Deck Blackjack Gold jedoch nicht aufgeben.
<G-vec00739-002-s068><surrender.aufgeben><en> However, you can’t surrender in Vegas Single Deck Blackjack Gold.
<G-vec00739-002-s069><surrender.aufgeben><de> Deshalb nicht die Hände bewegen, wenn du aufgeben willst.
<G-vec00739-002-s069><surrender.aufgeben><en> Therefore, do not move your hands if you intend to surrender.
<G-vec00739-002-s070><surrender.aufgeben><de> Stelle in einem Live-Casino immer sicher, dass du Augenkontakt mit dem Dealer herstellst und laut und deutlich sprichst, wann immer du aufgeben willst.
<G-vec00739-002-s070><surrender.aufgeben><en> In live casino play, always make sure you make eye contact with the dealer and speak in a loud, clear voice whenever you surrender.
<G-vec00739-002-s071><surrender.aufgeben><de> Die Sklaverei war für Amerika zu profitabel, um aufgegeben zu werden.
<G-vec00739-002-s071><surrender.aufgeben><en> Slavery was just too profitable for it to surrender.
<G-vec00739-002-s072><surrender.aufgeben><de> Wenn Schlüsselpunkte in Port Battles im realen Leben erreicht wurden, haben die Türme und Forts schlussendlich aufgegeben.
<G-vec00739-002-s072><surrender.aufgeben><en> Removed - Tower requirements. If you controlled key points in real world port battle towers and forts would eventually surrender.
<G-vec00739-002-s073><surrender.aufgeben><de> Dennoch, wie Benjamin Franklin es einmal sagte, “wer die Freiheit für die Sicherheit aufgibt, wird weder das Eine verdienen, noch das Andere haben”.
<G-vec00739-002-s073><surrender.aufgeben><en> Yet, as Benjamin Franklin once said, “those who surrender freedom for security will not have, nor do they deserve, either one.”
<G-vec00739-002-s074><surrender.aufgeben><de> Man gewinnt indem man entweder die letzte Stadt seines Kontrahenten erobert, oder indem dieser aufgibt.
<G-vec00739-002-s074><surrender.aufgeben><en> You either win by capturing the enemy’s last city or they surrender.
<G-vec00739-002-s075><surrender.aufgeben><de> Der Machtkampf bei Volkswagen eskalierte über das Wochenende, als ein Riss zwischen den Familien Porsche und Piëch auftauchte, die den Carmaker und seinen Chef kontrollierten, dass er nicht beabsichtige, seine Position aufzugeben.
<G-vec00739-002-s075><surrender.aufgeben><en> The power struggle at Volkswagen escalated over the weekend, as a rift emerged between the Porsche and Piëch families that control the carmaker and its chief executive signalled he does not intend to surrender his position.
<G-vec00739-002-s076><surrender.aufgeben><de> So wurde wieder mit den USA verhandelt – sehr zum Ärger der dänischen Nationalisten, die es verwerflich fanden, dieses letzte Zeugnis der einstigen dänischen Großmacht auch noch aufzugeben.
<G-vec00739-002-s076><surrender.aufgeben><en> Negotiations with the USA were resumed – much to the disgust of the Danish nationalists who thought it reprehensible to surrender this last testimony to the former Danish major power.
<G-vec00739-002-s077><surrender.aufgeben><de> Wahrscheinlich gibt es auch einen Widerstreit zwischen Kontrollbedürfnis und der Sehnsucht danach, die Kontrolle aufzugeben.
<G-vec00739-002-s077><surrender.aufgeben><en> There is also likely to be a struggle to find a balance between needing to be in control and longing to surrender control.
<G-vec00739-002-s078><surrender.aufgeben><de> Es war ihre absolute Weigerung aufzugeben, die ihn besiegt hat.
<G-vec00739-002-s078><surrender.aufgeben><en> "It was your absolute refusal to surrender which defeated him.
<G-vec00739-002-s079><surrender.aufgeben><de> Sie werden sich schämen, vor Ablauf der Frist aufzugeben.
<G-vec00739-002-s079><surrender.aufgeben><en> You will be ashamed to surrender before the deadline.
<G-vec00739-002-s080><surrender.aufgeben><de> Wir verpflichten uns, die uns nach den vorstehenden Bestimmungen zustehenden Sicherheiten nach Wahl des Kunden aufzugeben, soweit sie die ausstehenden Forderungen um 20% übersteigen.
<G-vec00739-002-s080><surrender.aufgeben><en> We commit ourselves to surrender the securities granted us under the above provisions at the customer’s request if they exceed the outstanding claims by 20%.
<G-vec00739-002-s081><surrender.aufgeben><de> Aufzugeben und die Hälfte des Einsatzes zu verlieren (der Surrender Knopf).
<G-vec00739-002-s081><surrender.aufgeben><en> surrender, ending the game and losing one half of the bet (the "Surrender" button)
