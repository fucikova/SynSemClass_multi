<G-vec00367-001-s025><forbid.behüten><de> Sie sind sehr duldsam gegen alle Ideen, falls diese ihre traditionelle Autorität nicht untergraben und – Gott behüte – ihr persönliches Wohlergehen nicht bedrohen.
<G-vec00367-001-s025><forbid.behüten><en> They tolerate all ideas, provided they do not undermine their traditional authority, and do not threaten – God forbid I – their personal comfort.
