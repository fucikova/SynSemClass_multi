<G-vec00097-001-s152><appear.auftreten><de> Gerichtsstand für Rechtsstreitigkeiten, die im Zusammenhang mit der Nutzung dieser Website auftreten ist Kreuzlingen, Schweiz.
<G-vec00097-001-s152><appear.auftreten><en> Legal venue for civil disputes, in connection with the use of this website appear is Kreuzlingen, Switzerland.
<G-vec00097-001-s153><appear.auftreten><de> Ich finde: Fabelwesen, und der Kontext in dem sie auftreten, einfach interessant.
<G-vec00097-001-s153><appear.auftreten><en> I think: Such Creatures, and the context, in which they appear, are simply fascinating.
<G-vec00097-001-s154><appear.auftreten><de> Er sagte - das Medikament ist mikroverkapselt, Insekten können bis zu einem Monat auftreten.
<G-vec00097-001-s154><appear.auftreten><en> He said - the drug is microencapsulated, insects can appear up to a month.
<G-vec00097-001-s155><appear.auftreten><de> Daher wird ein auffälliges Ergebnis nur dann auftreten, wenn der Verlust nicht durch Störungen im Körper verursacht wird.
<G-vec00097-001-s155><appear.auftreten><en> Therefore, a noticeable result will appear only if the loss is not caused by disturbances in the body.
<G-vec00097-001-s156><appear.auftreten><de> Dermatitis atopica ist die am weitesten verbreitete Art und wird als infantile Ekzem bezeichnet, weil ihre Zeichen in der Kindheit oder der Kindheit auftreten.
<G-vec00097-001-s156><appear.auftreten><en> Dermatitis atopica is the most widespread type and is referred to as infantile dermatitis because its signs appear during childhood or infancy.
<G-vec00097-001-s157><appear.auftreten><de> Damit hielt sie aber die Bewegung an, schaffte die Möglichkeit ab, auf neue Horizonte zu reagieren, die, ob wir nun wollen oder nicht, sowohl im lebenden künstlerischen Verkehr, als auch jenseits der scheinbaren Grenzen der Kunst auftreten.
<G-vec00097-001-s157><appear.auftreten><en> That satisfaction led to less exercise of freedom and eliminated the possibility of responding to new horizons that, whether we want them to or not, appear both within the current bounds of art and beyond its (apparent) borders.
<G-vec00097-001-s158><appear.auftreten><de> Auch wenn Sie ein langfristiges Volkswagen Transporter-Auto in Buzau mieten möchten, kümmert sich Promotor Rent a Car um Revisionen, regelmäßige technische Inspektionen und mögliche technische Ausfälle, die während der Vertragslaufzeit auftreten können.
<G-vec00097-001-s158><appear.auftreten><en> Also, if you want to rent a Volkswagen Transporter car on a long term in Buzau, Promotor Rent a Car will take care of the revisions, the periodic technical inspection and any other technical malfunctions that can appear during the contract's period.
<G-vec00097-001-s159><appear.auftreten><de> "Niederfrequente Artefakte, die manchmal sehr störend sind und auftreten, wenn das System signifikante Signalenergie oberhalb der Nyquist-Frequenz (von sogenannten ""Alias-Frequenzen"") erhält."
<G-vec00097-001-s159><appear.auftreten><en> Low frequency artifacts, sometimes quite disturbing, that appear when the system receives significant signal energy above the Nyquist frequency (from so-called alias frequencies).
<G-vec00097-001-s160><appear.auftreten><de> in der zwangsläufig dogmatische Formen (Gravitation, Elektron) auftreten.
<G-vec00097-001-s160><appear.auftreten><en> in which inevitably dogmatic forms (gravity, electron) appear.
<G-vec00097-001-s161><appear.auftreten><de> Es möchte einfach jeder in Ystad auftreten.
<G-vec00097-001-s161><appear.auftreten><en> """Everyone"" wants to appear in Ystad!"
<G-vec00097-001-s162><appear.auftreten><de> Wenn Sie nicht daran gewöhnt sind, dies so aufzufassen, so liegt das daran, daß diese Energien hier in Oktaven auftreten, die vom Erdenmenschen im Allgemeinen nicht als Bewußtseinsenergie erlebt werden können, sondern vielmehr als Stoff oder Materie.
<G-vec00097-001-s162><appear.auftreten><en> The reason you do not usually perceive it in this way is because here these energies appear in octaves that terrestrial human beings cannot normally experience as energies of consciousness; they rather experience them as substance or matter.
<G-vec00097-001-s163><appear.auftreten><de> Es würde bedeuten, dass kurzfristige Ereignisse auftreten, die Große Depression und dem Zweiten Weltkrieg wurden die Muster der Verbraucherpreise über Entwicklungen in Bezug auf Stunden und die Produktivität zu beeinflussen.
<G-vec00097-001-s163><appear.auftreten><en> It would appear that short-term events, the Great Depression and World War II, were influencing the pattern of consumer prices more than developments related to hours and productivity. Figures 8-6, 8-7, and 8-8 bring the analysis up to date through 1979.
<G-vec00097-001-s164><appear.auftreten><de> Es können dabei beispielsweise Windlasten und Lasten aus einer Absturzsicherung auftreten.
<G-vec00097-001-s164><appear.auftreten><en> For example, wind loads and loads due to fall protection may appear.
<G-vec00097-001-s165><appear.auftreten><de> Muttermale können überall auf der Haut auftreten, entweder einzeln oder gruppiert.
<G-vec00097-001-s165><appear.auftreten><en> Moles can appear anywhere on the skin, either individually or grouped.
<G-vec00097-001-s166><appear.auftreten><de> Wir sind nicht gleich und können nicht gemeinsam auftreten.
<G-vec00097-001-s166><appear.auftreten><en> We are not of the same kind and cannot appear together.
<G-vec00097-001-s167><appear.auftreten><de> Entfernung einer Talgzyste Die Beseitigung von Talgzysten oder von Lipomen ist ein einfaches Verfahren, mit Hilfe dessen Wulste oder Geschwulste beseitigt werden, die gelegentlich im Genitalbereich auftreten.
<G-vec00097-001-s167><appear.auftreten><en> Removal of sebaceous cysts Removing sebaceous cysts or a lipoma is a simple procedure which removes protrusions or lumps which sometimes appear around the genital area.
<G-vec00097-001-s168><appear.auftreten><de> Es ist eigentlich ein Muss für jeden Reiter, der einen sicheren und zuverlässigen Partner Pferd haben möchte, mit dem er auf jeder Messe, auf jeder Straße, auf jedem Turnier und in jedem Gelände sicher auftreten kann.
<G-vec00097-001-s168><appear.auftreten><en> Actually, this training is a must for any rider who wants a reliable and dependable horse as a partner with which he can safely appear at a horse show, ride the streets or roads, compete in a tournament or ride in any terrain.
<G-vec00097-001-s169><appear.auftreten><de> "Deutschland muss gar nicht mehr selbst in den sogenannten ""Angleichungsprozessen"" auftreten, um die Übernahme seiner institutionellen Praktiken gewährleistet zu sehen."
<G-vec00097-001-s169><appear.auftreten><en> "Germany itself does not have to appear in the so called ""adjustment process"" anymore to see the adoption of its institutional practices ensured."
<G-vec00097-001-s170><appear.auftreten><de> Kontakt Ekzeme können plötzlich auftreten.
<G-vec00097-001-s170><appear.auftreten><en> Contact eczema can appear suddenly.
<G-vec00097-001-s081><emerge.auftreten><de> Die Beispiele werden sich weniger mit „Einflüssen“ beschäftigen sondern mit der Definition von bestimmten gemeinsamen Strukturen, die auftreten wenn wir uns anschauen wie visuelle Intuition Problemlösung betreibt.
<G-vec00097-001-s081><emerge.auftreten><en> The examples will be less concerned with ‘influence’ than in the defining of certain shared structures that emerge when we look at how visual intuition operates in problem-solving.
<G-vec00097-001-s082><emerge.auftreten><de> Er müsste auch erläutern, warum diese Erfahrungen in der modernen Bevölkerung unter so unterschiedlichen Bedingungen auftreten, wie in Sitzungen mit verschiedenen psychedelischen Substanzen, während erfahrungsorientierter Psychotherapien, bei systematisch angewandter spiritueller Praxis, bei Nahtod-Erfahrungen und im Laufe spontaner Episoden psychospiritueller Krisen.
<G-vec00097-001-s082><emerge.auftreten><en> He or she would also have to account for the fact that these experiences continue to emerge in modern populations under such diverse circumstances as sessions with various psychedelic substances, during experiential psychotherapy, in meditation of people involved in systematic spiritual practice, in near-death experiences, and in the course of spontaneous episodes of psychospiritual crisis.
<G-vec00097-001-s083><emerge.auftreten><de> ANTWORT: Wenn die menschliche Persönlichkeit im Suchen nach dem LICHT nicht versagen würde, würde sie ihr Selbstbewusstsein nie verlieren, und nicht als Persönlichkeit auftreten, die nach dem LICHT sucht.
<G-vec00097-001-s083><emerge.auftreten><en> Answer: If human personality did not fail in its search for the Light, it would never lose its self-consciousness, and would not emerge as a personality fit to find the Light.
<G-vec00097-001-s084><emerge.auftreten><de> „Wir befürchteten gleich bei der Gründung der V.K.P.D., dass in dieser Partei zentristische Strömungen auftreten würden.
<G-vec00097-001-s084><emerge.auftreten><en> “Already at the founding of the VKPD, we feared that centrist currents would emerge in this party.
<G-vec00097-001-s085><emerge.auftreten><de> Patienten (und deren Betreuer) sollte geraten werden, ärztlichen Rat einzuholen, wenn Anzeichen von Depression und/oder Suizidgedanken oder suizidales Verhalten auftreten.
<G-vec00097-001-s085><emerge.auftreten><en> Patients (and caregivers of patients) should be advised to seek medical advice should signs of depression and/or suicidal ideation or behaviour emerge.
<G-vec00097-001-s086><emerge.auftreten><de> Wir unterstützen Sie aber nicht nur bei der Suche und Evaluierung des richtigen Partners, sondern auch bei konkreten Verhandlungen, bei der Qualitätskontrolle sowie auch bei der konkreten längerfristigen Umsetzung des Projektes, wenn beispielsweise Probleme auftreten.
<G-vec00097-001-s086><emerge.auftreten><en> We will help you not only in your search for and assessment of the right partner, but also in specific negotiations, in quality control, and in concrete implementation of the project in the long term, and if and when any problems emerge.
<G-vec00097-001-s087><emerge.auftreten><de> Das Arbeitsschutzmessgerät verfügt über eine Lebensdauer von 2 Jahren und ist für alle Umgebungsbedingungen, die in der Industrie auftreten, gewappnet.
<G-vec00097-001-s087><emerge.auftreten><en> The Gas Leak DetectorÂ has a lifespan of 2 years and is prepared for every condition that could possibly emerge in the industry.
<G-vec00097-001-s088><emerge.auftreten><de> Andere Sicherheitsprodukte verfügen möglicherweise nicht über die notwendigen Ressourcen, um mit neuen Bedrohungen Schritt zu halten, wenn sie auftreten.
<G-vec00097-001-s088><emerge.auftreten><en> Other security products just don't have the resources to keep up with new threats as they emerge.
<G-vec00097-001-s089><emerge.auftreten><de> „Es dauert im Schnitt nur zwei Jahre, bis erste Resistenzen gegen ein neues Antibiotikum auftreten“, sagt Jens Rolff.
<G-vec00097-001-s089><emerge.auftreten><en> “On average, it only takes two years for the first resistance to a new antibiotic to emerge,” Rolff says.
<G-vec00097-001-s090><emerge.auftreten><de> Verspannungen und Schmerzen können jederzeit im Alltag auftreten.
<G-vec00097-001-s090><emerge.auftreten><en> Tensions and pains can always emerge in daily life.
<G-vec00097-001-s091><emerge.auftreten><de> Mit diesem Schritt ist nun potentiell wieder der erste Schritt eines neuen Fünfschrittes erreicht: Keimformen können auftreten, das dann alte Neue gerät in die Krise usw.
<G-vec00097-001-s091><emerge.auftreten><en> With this step potentially the first step of a new five step cycle is reached: germ forms can emerge, the old gets into crisis and so on.
<G-vec00097-001-s092><emerge.auftreten><de> Nicht nur die wichtige Frage, die überall schon das Kampfobjekt der Richtungen bildet, ob und wie das Proletariat auftreten kann, das Ende des Krieges zu beschleunigen und die Gestaltung des Friedens zu beeinflussen.
<G-vec00097-001-s092><emerge.auftreten><en> Not merely the important question, which everywhere is the kernel of the object of struggle, whether and how the proletariat can emerge, hasten the end of the war and influence the terms of peace.
<G-vec00097-001-s093><emerge.auftreten><de> Wir besprechen all dies mit den Vereinigten Staaten, aber vor allem besprechen wir zwei Probleme, die auftreten.
<G-vec00097-001-s093><emerge.auftreten><en> Now, we're discussing all of this with the United States, but especially two problems that emerge.
<G-vec00097-001-s094><emerge.auftreten><de> Sobald Oxidationsprodukte im Gefäß auftreten, steigt die Leitfähigkeit an.
<G-vec00097-001-s094><emerge.auftreten><en> Conductivity increases in this vessel once oxidation products emerge.
<G-vec00097-001-s038><happen.auftreten><de> Außerdem können Sie Gerätefehler schnell erkennen und zu beheben beginnen, wenn sie auftreten.
<G-vec00097-001-s038><happen.auftreten><en> Plus, you can quickly identify, and begin to address, unit malfunctions when they happen.
<G-vec00097-001-s039><happen.auftreten><de> Dies verhindert viele Fehler, bevor sie auftreten, und macht das System zuverlässiger, was wiederum zu besserer Verfügbarkeit, mehr Produktivität und niedrigeren Kosten führt.
<G-vec00097-001-s039><happen.auftreten><en> This prevents many errors before they happen and makes the system more reliable, which in turn delivers more uptime, more productivity, and lower costs.
<G-vec00097-001-s040><happen.auftreten><de> Die Sozialdemokratische Fraktion hebt hervor, dass die Leugner des Klimawandels jetzt mit wissenschaftlichen Beweisen und Warnungen über die negativen Auswirkungen konfrontiert sind, die bereits zu spüren sind oder in der Zukunft auftreten können.
<G-vec00097-001-s040><happen.auftreten><en> S&D also highlight that climate change deniers are now faced with scientific evidence and warning against negative effects that are already happening or could happen in the future.
<G-vec00097-001-s041><happen.auftreten><de> Die Dauer der Behandlung wird verlassen sich auf die Reaktion des Patienten und ob ungünstige Reaktionen auftreten, Therapie sollte getan werden, um einen Zeitplan für die Intervalle verwendet und nicht konsistent.
<G-vec00097-001-s041><happen.auftreten><en> Duration of treatment will rely on the response of the patient and whether any adverse responses happen, treatment must be done using a schedule of periods and not consistent.
<G-vec00097-001-s042><happen.auftreten><de> Hinweis: Abgesehen von Mobiltelefonen werden Computer auch zu einem Risiko, an dem unangemessene Online-Verhaltensweisen auftreten.
<G-vec00097-001-s042><happen.auftreten><en> Notice: Apart from cell phones, computers also becomes a high-risk place where inappropriate online behaviors happen.
<G-vec00097-001-s043><happen.auftreten><de> Dieser Effekt kann nur einmal alle 30 Sekunden auftreten.
<G-vec00097-001-s043><happen.auftreten><en> This effect cannot happen more than once every 30 seconds.
<G-vec00097-001-s044><happen.auftreten><de> Dies könnte auftreten, wenn Bewusstsein einen bestimmten Grad an Komplexität des Nervensystems voraussetzt, was nicht unplausibel ist.
<G-vec00097-001-s044><happen.auftreten><en> This could happen if consciousness requires a certain degree of nervous complexity, which may well be the case.
<G-vec00097-001-s045><happen.auftreten><de> Lange Zeit gab es für Astronomen, die besonders detailreiche Bilder von Himmelsobjekten benötigten, nur zwei Möglichkeiten: Entweder die Nutzung von Weltraumteleskopen, oder aber das Warten auf außergewöhnlich vorteilhafte atmosphärische Bedingungen, wie sie in jedem Jahr an bevorzugten Beobachtungsorten auf der Erde höchstens ein paar Mal auftreten – wenn überhaupt.
<G-vec00097-001-s045><happen.auftreten><en> That is why, before adaptive optics, astronomers were forced to use space telescopes or else to wait for exceptionally good atmospheric conditions – which happen only a few times, if at all, in any given year – to obtain sharp images of celestial objects.
<G-vec00097-001-s046><happen.auftreten><de> Speziell wenn Synchronizitäten regelmäßig auftreten könnte ein Mensch sich über die traumartige Natur der Realität erinnert fühlen und dadurch kann das Universum zunehmend zu einem synchronistischen Universum werden, in dem wir auf unsere innere Führung hören.
<G-vec00097-001-s046><happen.auftreten><en> Especially when synchronicities happen on a regular basis in a persons life the experience might remind this person of the dream-like nature of reality and that the universe can become a synchronistic universe, when we begin to listen to our inner guidance.
<G-vec00097-001-s047><happen.auftreten><de> Der Schmerz kann vor, während oder nach dem Eisprung auftreten, und es gibt keinen einfachen Weg zu wissen, ob der Schmerz mit dem Eisprung zusammenhängt.
<G-vec00097-001-s047><happen.auftreten><en> The pain might happen before, during, or after ovulation, and there is no easy way to know how the pain you experience correlates to ovulation.
<G-vec00097-001-s048><happen.auftreten><de> Es hat sich für Frauen Profisportler sehr beliebt zu sein aufgrund seiner geringen Gefahr der Verursachung virilization Anzeichen und Symptome auftreten.
<G-vec00097-001-s048><happen.auftreten><en> It has come to be popular for women athletes as a result of its low threat of causing virilization signs to happen.
<G-vec00097-001-s049><happen.auftreten><de> Im Hinblick auf machen Verwendung durch Frauen, zwar gibt es ein typischer glauben, dass Oxandrolone ist minimal virilizing für Frauen, als eine Frage der Tatsache Virilisierung nicht ungewöhnlich, auf 20 mg/Tag ist und bei deutlich geringeren Dosierungen als die auftreten könnten.
<G-vec00097-001-s049><happen.auftreten><en> With regard to utilize by ladies, while there is a usual belief that oxandrolone is minimally virilizing to female, in fact virilization is not uncommon at 20 mg/day and could happen at considerably lesser amounts compared to that.
<G-vec00097-001-s050><happen.auftreten><de> Ein seltsames Phänomen ist das 'Riesenwachstum', das auftreten kann, wenn die Schnecke von einem parasitierenden Wurm kastriert wird.
<G-vec00097-001-s050><happen.auftreten><en> Giant growth A strange phenomenon is 'giant growth', which can happen if a snail is castrated by a parasite.
<G-vec00097-001-s051><happen.auftreten><de> Der Zähler im Casino ins Spiel bringt diese Möglichkeiten, indem größere Einsätze, wie und wann sie auftreten.
<G-vec00097-001-s051><happen.auftreten><en> The counter in the casino uses these opportunities by placing bigger wagers, as and when they happen.
<G-vec00097-001-s052><happen.auftreten><de> Hinsichtlich von Damen zu nutzen, während es eine gemeinsame Idee ist, dass oxandrolone minimal ist weiblich virilizing, als eine Tatsache, virilization bei 20 mg / Tag nicht ungewöhnlich ist, und bei wesentlich geringeren Dosen im Vergleich auftreten kann.
<G-vec00097-001-s052><happen.auftreten><en> With regard to use by females, while there is a usual belief that oxandrolone is minimally virilizing to female, in fact virilization is not unusual at 20 mg/day and can happen at significantly reduced doses compared to that.
<G-vec00097-001-s053><happen.auftreten><de> "Der Punkt ist, der Gedanke, dass Sie die Warm-up überspringen können ""nur dieses eine Mal "" wird Ihnen auftreten."
<G-vec00097-001-s053><happen.auftreten><en> "In fact, think that you can skip the warm-up ""only once"" to happen to you."
<G-vec00097-001-s054><happen.auftreten><de> Im Falle von Anavar haben wir unter den mehr Reduzierungen angenehme Hormone könnten wir jemals vor dem Gebrauch und während es eine gewisse Unterdrückung ist freundlich auftreten.
<G-vec00097-001-s054><happen.auftreten><en> In the case of Anavar we have among the even more reductions friendly hormones we can ever before utilize and also while it gets along some suppression will happen.
<G-vec00097-001-s055><happen.auftreten><de> Die Karte Zähler in der Spielhalle nutzt diese Möglichkeiten, Indem Größere Einsätze, wie und wann sie auftreten.
<G-vec00097-001-s055><happen.auftreten><en> The card counter in the gambling hall uses such opportunities by laying larger wagers, as and when they happen.
<G-vec00097-001-s056><happen.auftreten><de> Eingewachsene Haare können auftreten, wenn der Schaft des geschnittenen Haares sehr kurz ist und er sich zurück in dasselbe Haarfollikel dreht, aus dem es wächst.
<G-vec00097-001-s056><happen.auftreten><en> Ingrown hairs happen when the end of the hair shaft is shaved very low, curling back into the same hair follicle as it grows.
<G-vec00097-001-s076><occur.auftreten><de> Beachten Sie dabei, dass ein Screenproof nicht farbecht ist und Abweichungen zum späteren Druckbild auftreten können.
<G-vec00097-001-s076><occur.auftreten><en> Please note that a screen proof is not a true-colour reproduction and deviations from the printed image can occur.
<G-vec00097-001-s077><occur.auftreten><de> Bei dynamisch belasteten Dichtungen können Leckagen auftreten: Wenn zwischen Elastomerdichtung und Welle kein Schmierfilm aufgebaut werden kann oder dieser reißt, kann es durch Reibung zwischen den Reibungspartnern zu einer überhöhten Temperatur und zum Versagen des Dichtungsmaterials und zu erhöhtem Verschleiß (Welleneinlauf) kommen.
<G-vec00097-001-s077><occur.auftreten><en> Wherever seals operate under dynamic load, leakage of the medium may occur. If a lubricant film fails to form between the elastomer seal and the shaft, or if an existing lubricant film ruptures, friction between the moving components may lead to a sharp rise in temperature and consequently failure of the sealing materials and increased wear (shaft under-cut).
<G-vec00097-001-s078><occur.auftreten><de> Nicht geeignet dort, wo fühlbare Temperaturunterschiede auftreten.
<G-vec00097-001-s078><occur.auftreten><en> Not suitable where noticeable temperature differences occur.
<G-vec00097-001-s079><occur.auftreten><de> Ich habe gesehen, dies auftreten.
<G-vec00097-001-s079><occur.auftreten><en> I have seen this occur.
<G-vec00097-001-s080><occur.auftreten><de> Die Furcht oder die Angst mÃ1⁄4ssen in zwei der fÃ1⁄4nf Situationen auftreten, um die aktuellen Kriterien fÃ1⁄4r Agoraphobie zu erfÃ1⁄4llen.
<G-vec00097-001-s080><occur.auftreten><en> The fear or anxiety must occur in two of the five situations to meet the current criteria for agoraphobia.
<G-vec00097-001-s081><occur.auftreten><de> Wie oben erwähnt, gibt es MilchMischung von Geburt an, dass nicht nur das Bedürfnis des Kindes nach Nährstoffen erfüllen, sondern auch einige gesundheitlichen Probleme zu lösen helfen, die manchmal bei Kindern auftreten.
<G-vec00097-001-s081><occur.auftreten><en> As mentioned above, there are dairymixture from birth, that not only meet the child's need for nutrients, but also help to solve some health problems that sometimes occur in children.
<G-vec00097-001-s082><occur.auftreten><de> Obwohl wir uns bemühen, die Verfügbarkeit der gebuchten Leistungen abzusichern, können gelegentlich Fehler auftreten.
<G-vec00097-001-s082><occur.auftreten><en> Although we strive to guarantee the availability of reserved services, on occasion, errors may occur.
<G-vec00097-001-s083><occur.auftreten><de> (2) Verhindert Dellen an der Zahnspitze, die beim Versand auftreten könnten.
<G-vec00097-001-s083><occur.auftreten><en> (2) Prevents dents at the tooth tip that tend to occur when shipping.
<G-vec00097-001-s084><occur.auftreten><de> Sein Vorteil liegt in der Unsichtbarkeit geringfügigen Mängeln, die während des Betriebs auftreten können.
<G-vec00097-001-s084><occur.auftreten><en> Its advantage lies in the invisibility of minor defects that may occur during operation.
<G-vec00097-001-s085><occur.auftreten><de> Zum Beispiel können Sie herausfinden, ob bestimmte Behandlungen überdurchschnittlich häufig zwischen 0 und 60 Laktationstagen auftreten.
<G-vec00097-001-s085><occur.auftreten><en> For example, you can identify whether certain treatments occur more frequently than the average between zero and sixty days of lactation.
<G-vec00097-001-s086><occur.auftreten><de> Der Allgemeinzustand verschlechtert sich zudem stetig, Müdigkeit, Appetitlosigkeit, Übelkeit und Unwohlsein können auftreten.
<G-vec00097-001-s086><occur.auftreten><en> The patient's general condition also steadily worsens, and fatigue, loss of appetite, nausea and discomfort can occur.
<G-vec00097-001-s087><occur.auftreten><de> Dieser Polder soll das Umland vor Überflutungen durch Binnenhochwasser schützen, die nach lang anhaltenden Regenfällen auftreten.
<G-vec00097-001-s087><occur.auftreten><en> This polder will protect the surrounding area from flooding by high inland waters that occur as a result of sustained rainfall.
<G-vec00097-001-s088><occur.auftreten><de> Es ist sehr üblich, Flare ups haben, wenn Sie grillen, so dass Sie dies nicht wünschen einen Überhang haben dass möglicherweise Feuer fangen, wenn Ihr Flare ups auftreten.
<G-vec00097-001-s088><occur.auftreten><en> It's very common to have flare ups when you grill so you don't want to have an overhang that could potentially catch on fire when your flare ups occur.
<G-vec00097-001-s089><occur.auftreten><de> Bei der Risikoanalyse handelt es sich um die systematische Verwendung von verfügbaren Informationen, um herauszufinden, wie oft bestimmte Ereignisse auftreten könnten und wie stark sich das auf die Ergebnisse auswirken würde.
<G-vec00097-001-s089><occur.auftreten><en> Risk analysis is systematic use of available information to determine how often specified events may occur and the magnitude of their consequences.
<G-vec00097-001-s090><occur.auftreten><de> Sollte eine Datenschutzverletzung mit nachteiligen Folgen für personenbezogene Daten auftreten, wird der Kunde unter den gesetzlich vorgesehenen Umständen persönlich informiert.
<G-vec00097-001-s090><occur.auftreten><en> If a data breach should occur with adverse consequences for personal data, the customer is personally notified under the conditions provided for by law.
<G-vec00097-001-s091><occur.auftreten><de> Jede negative Reaktion auf Medikamente einnehmen, sollten den verschreibenden Arzt gemeldet werden, um für eine angemessene Untersuchung nicht nur für den einzelnen Patienten, sondern für andere Patienten auftreten, die möglicherweise die Medikamente in der Zukunft verschrieben werden.
<G-vec00097-001-s091><occur.auftreten><en> Any adverse reaction to medication should be reported to the prescribing doctor in order for appropriate investigation to occur not only for the individual patient but for other patients who may be prescribed the medication in the future.
<G-vec00097-001-s092><occur.auftreten><de> Auch wenn die komplexesten Computerprobleme am Arbeitsplatz oft vom IT-Support-Team gelöst werden können, gibt es viele andere kleine, aber häufige Probleme, die häufig auf einem PC auftreten.
<G-vec00097-001-s092><occur.auftreten><en> Even though the most complex computer issues at work place can often be solved by the business IT support team, there are many other small, but common, problems that occur quite often on a personal computer.
<G-vec00097-001-s093><occur.auftreten><de> Autoimmunkrankheiten wie Phemphigus, Uveitis, Lupus, VKH, PRA, Schilddrüsenerkrankungen, Anämie und Thrombozytenanomalie dann Willebrand Disease, Sebadenitis, Ehlers-Danlos-Syndrom, HD sind leider Krankheiten/ Beschwerden die beim Akita auftreten können.
<G-vec00097-001-s093><occur.auftreten><en> Autoimmune diseases like Pemphigus, Uveitis, Lupus, VKH,PRA, Hypothyyroidism, thrombocytopenia and Hemolytic Anemia, Sebaceous Adenits, Hyp Dysplasia are unfortunately diseases/troubles that can occur with Akitas.
<G-vec00097-001-s094><occur.auftreten><de> Es wird jedoch nicht garantiert, dass aufgrund von standortspezifischen Faktoren keine Störungen auftreten.
<G-vec00097-001-s094><occur.auftreten><en> There is, however, no guarantee that interference will not occur in any particular installation due to site-specific factors.
<G-vec00097-001-s095><occur.auftreten><de> Kreative Menschen zeichnen sich seiner Meinung nach also nicht durch besondere, bei anderen Menschen gar nicht auftretende Persönlichkeitsmerkmale aus, sondern durch eine Komplexität von persönlichen Eigenschaften, in der jeweils widersprüchliche Extreme vereinigt sind.
<G-vec00097-001-s095><occur.auftreten><en> Thus he defines creative people not by specific personality traits which do not occur in other people, but by the complexity of personality traits, with opposing extremes being integrated.
<G-vec00097-001-s096><occur.auftreten><de> Jeder während eines Ge­ schäftsjahres auftretende Negativsaldo sollte im Folgejahr von den Ratingagenturen zurückgefordert werden.
<G-vec00097-001-s096><occur.auftreten><en> Any deficit that may occur during 1 financial year should be recovered from credit rating agencies in the following year.
<G-vec00097-001-s097><occur.auftreten><de> In der Praxis erwies sich dies als mühsam und ineffizient.Automatische statt manueller Datensicherung Basierend auf der von ISRA PARSYTEC gesammelten Erfahrung von über 300 installierten Inspektionssystemen für Bahnwaren ist ein neues Event Capturing (EC) System entstanden, welches die Möglichkeit bietet, auftretende Ereignisse automatisch zu überwachen und entsprechend gesetzter Voreinstellungen Alarmsignale zu generieren.
<G-vec00097-001-s097><occur.auftreten><en> Automatic backups instead of manual backups Based on the experience gained by ISRA PARSYTEC in the more than 300 inspection systems installed for web material, a new event capturing (EC) system was developed, which allows any events that might occur to be inspected and which then generates alarm signals accordingly based on pre-set parameters defined in advance.
<G-vec00097-001-s098><occur.auftreten><de> Informationen Die Zwergammer ist die kleinste Ammer Europas und die am häufigsten in Mitteleuropa auftretende Ammer der Taiga.
<G-vec00097-001-s098><occur.auftreten><en> Information The Little Bunting is the smallest European bunting and the most abundant bunting of the taiga to occur in Central Europe.
<G-vec00097-001-s099><occur.auftreten><de> Wenn Informationen basierend auf vorausschauenden Einblicken und aussagekräftigen Daten zur Verfügung stehen, können Wartungsverfahren auf einen proaktiveren Ansatz umgestellt werden, bei dem sich das Personal auf die Verfolgung des Zustands der Ausrüstung und Maßnahmen zur Vermeidung von Betriebsstörungen konzentriert, anstatt nur auf auftretende Störungen zu reagieren.
<G-vec00097-001-s099><occur.auftreten><en> Informed by these predictive insights and actionable data, maintenance practices can shift to a more proactive mode, where workers track the health of equipment and act to prevent breakdowns, rather than responding to them as they occur.
<G-vec00097-001-s100><occur.auftreten><de> Auftretende Störungen werden mit Art des Fehlers, sämtlichen aktuellen Parametern, sowie Datum und Uhrzeit der Entstehung/Wegfall der Störung gespeichert.
<G-vec00097-001-s100><occur.auftreten><en> Any malfunctions which occur are stored with the type of malfunction, all of the parameters which existed at the time and the date and time the malfunction occurred/was solved.
<G-vec00097-001-s101><occur.auftreten><de> C-Klausel – gemäß welcher der Verkäufer die Beförderung bestellt, ohne daß er den Risiko für Verlust oder Beschädigung der Ware, oder die zusätzlichen Kosten, verursacht von auftretende Ereignisse nach dem Versand der Ware, zu übernehmen.
<G-vec00097-001-s101><occur.auftreten><en> Clauses of type C – according to which the seller hires transportation without taking responsibility for the lost or damage of the goods or for the extra costs caused by events that occur after dispatch)
<G-vec00097-001-s102><occur.auftreten><de> Umgang mit Interessenkonflikten Alle Mitglieder unseres Aufsichtsrates sind verpflichtet, auftretende Interessenkonflikte unverzüglich offenzulegen.
<G-vec00097-001-s102><occur.auftreten><en> Dealing with conflicts of interest All members of the Supervisory Board are obliged to disclose conflicts of interest as soon as they occur.
<G-vec00097-001-s103><occur.auftreten><de> Der Volontär ist verpflichtet, auftretende Mängel unverzüglich den Mitarbeitern von “United Friends of India” und zusätzlich der Organisation schriftlich per E-Mail mitzuteilen.
<G-vec00097-001-s103><occur.auftreten><en> The volunteer is obligated to inform the employees of “United Friends of India” as well as the organization (through mail), if any damages occur during their stay.
<G-vec00097-001-s104><occur.auftreten><de> Die Lyme-Borreliose, die häufigste durch Zecken übertragene Infektionskrankheit in Europa, wird zu Recht gefürchtet: Sie bringt vielschichtige, belastende und über Jahre auftretende Symptome mit sich und bedarf einer langen und intensiven Behandlung.
<G-vec00097-001-s104><occur.auftreten><en> Lyme disease, the most common infectious disease transmitted by ticks in Europe, is feared for good reason: it brings with it multi-layered, stressful symptoms that occur over years and requires long, intensive treatment.
<G-vec00097-001-s105><occur.auftreten><de> Und in der Geographie sollen sie statistische Tabellen interpretieren oder global auftretende Naturphänomene erklären, statt dass man sie mit der Vielfalt von Landschaften und der in ihnen lebenden Menschen durch Bilder, durch Erzählungen oder – wenn es möglich ist – durch Ausflüge oder Reisen vertraut macht.
<G-vec00097-001-s105><occur.auftreten><en> And they are supposed to interpret statistical tables in Geography, or explain natural phenomena that occur globally, instead of making the acquaintance of the variety of landscapes and the people who live there – through pictures, travellers' accounts, or if possible, by going to these places.
<G-vec00097-001-s106><occur.auftreten><de> Auftretende Fliehkräfte bei der Bearbeitung werden durch eine passgenaue Schwalbenschwanzführung kompensiert.
<G-vec00097-001-s106><occur.auftreten><en> Centrifugal forces which occur during machining are compensated for by a precision dovetail guide.
<G-vec00097-001-s107><occur.auftreten><de> Außerdem kann der Reiseleiter eventuell unterwegs auftretende Probleme mit den Fahrrädern beheben.
<G-vec00097-001-s107><occur.auftreten><en> The guide will also try to solve any problems with the bikes that may occur along the way.
<G-vec00097-001-s108><occur.auftreten><de> Schnell hintereinander auftretende Sensorsignale werden so zuverlässig von der Steuerung verarbeitet und Prozessabläufe sichergestellt.
<G-vec00097-001-s108><occur.auftreten><en> Sensor signals that occur in rapid succession are reliably processed by the control system and process sequences ensured.
<G-vec00097-001-s109><occur.auftreten><de> Eventuell in der Anwendung auftretende Radialkräfte sollten über zusätzliche Linearführungen aufgenommen werden.
<G-vec00097-001-s109><occur.auftreten><en> Any radial forces that may occur in the application should be absorbed by additional linear guides.
<G-vec00097-001-s110><occur.auftreten><de> Ich/wir stellen den Cadillac Club of Switzerland und/oder seine Organisatoren von jeglicher Haftung für eventuell auftretende Schäden frei.
<G-vec00097-001-s110><occur.auftreten><en> I/we understand that in no case the Cadillac Club of Switzerland and/or its organising staff shall be held liable for any damages that may occur.
<G-vec00097-001-s111><occur.auftreten><de> Auch laute oder plötzlich auftretende Geräusche, wie das Klappern von Besteck oder das Rascheln einer Zeitung in unmittelbarer Nähe, werdenvom Amadé BBisoliert und ohne Beeinträchtigung der Sprachsignale reduziert.
<G-vec00097-001-s111><occur.auftreten><en> Even when loud or unexpected sounds occur, such as cutlery clattering against plates or the rustling of newspaper,the Amadé isolates sudden noises and reduces them without interfering with speech signals.
<G-vec00097-001-s112><occur.auftreten><de> So kann zum Beispiel die bei großen Messrohrtiefen auftretende Messrohrverdrehung mit einer speziellen Sonde gemessen und in der Auswertung mittels Transformation berücksichtigt werden.
<G-vec00097-001-s112><occur.auftreten><en> Thus, for example, the twisting of the measuring tube that can occur at great depths of tube can be measured using a special probe and taken into account in the evaluation by means of a transformation.
<G-vec00097-001-s113><occur.auftreten><de> Wenn ein solcher Fall eintritt, werden wir eventuell auftretende Probleme mit Nachsicht behandeln.
<G-vec00097-001-s113><occur.auftreten><en> We will endeavour, if this situation arises, to be sympathetic with any problems that may occur.
<G-vec00097-001-s114><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen AT-SPBD40-14 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen AT-SPBD40-14 zu Tage tritt.
<G-vec00097-001-s114><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible AT-SPBD40-14 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible AT-SPBD40-14 for a time.
<G-vec00097-001-s115><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen 3CGBIC93A oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen 3CGBIC93A zu Tage tritt.
<G-vec00097-001-s115><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible 3CGBIC93A or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible 3CGBIC93A for a time.
<G-vec00097-001-s116><occur.auftreten><de> Durch das breite Spektrum von Symptomen und der geringen Anzahl an auftretenden Fällen ist es gut möglich das Menschen nach dem Kontakt mit Wasser, dass sehr viele Bakterien enthält, krank geworden sind.
<G-vec00097-001-s116><occur.auftreten><en> Due to the wide variety of symptoms and few cases that may occur, it is possible that people have become ill after coming in contact with water containing high bacteria levels.
<G-vec00097-001-s117><occur.auftreten><de> Eine Finsternis kann alle auftretenden Wechsel und Vernderungen durch Krisen undauch Schmerz in seiner ganzenExtremitt anzeigen, Es kann keine wirkliche Heilung ohne Heilung der Krise, kein richtiges Erwachen ohne ein ernsthaftes und eindringliches bewut werden und die Umkehr von ablehnenden Mustern geschehen.
<G-vec00097-001-s117><occur.auftreten><en> An eclipse symbolizes change and transformation that can occur, in its extremes, through crises and even pain. No real healing can happen without a healing crisis, no real awakening can happen without a sincere and penetrating realization and a severe reversal of denial patterns.
<G-vec00097-001-s118><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen S26361-F3873-L208 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen S26361-F3873-L208 zu Tage tritt.
<G-vec00097-001-s118><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible S26361-F3873-L208 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible S26361-F3873-L208 for a time.
<G-vec00097-001-s119><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen OPT-0025-00 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen OPT-0025-00 zu Tage tritt.
<G-vec00097-001-s119><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible OPT-0025-00 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible OPT-0025-00 for a time.
<G-vec00097-001-s120><occur.auftreten><de> Im Falle von Torsion können die auftretenden Kräfte aber vom Kabel nicht vollständig kompensiert werden, die Messkabel verschleißen daher früher.
<G-vec00097-001-s120><occur.auftreten><en> In the case of torsion, however, the forces which occur cannot be completely compensated for which means the measuring cables wear out sooner.
<G-vec00097-001-s121><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen CBL-QSFP-40GE-7M-F10 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen CBL-QSFP-40GE-7M-F10 zu Tage tritt.
<G-vec00097-001-s121><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible CBL-QSFP-40GE-7M-F10 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible CBL-QSFP-40GE-7M-F10 for a time.
<G-vec00097-001-s122><occur.auftreten><de> Der Roboter verfügt über eine integrierte Sensorik, mit der er die auftretenden Kräfte beim Betätigen der Schalter misst.
<G-vec00097-001-s122><occur.auftreten><en> The robot has integrated sensors to measure the forces that occur when switches are activated.
<G-vec00097-001-s123><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen FG-TRAN-QSFP-4XSFP-1M oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen FG-TRAN-QSFP-4XSFP-1M zu Tage tritt.
<G-vec00097-001-s123><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible FG-TRAN-QSFP-4XSFP-1M or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible FG-TRAN-QSFP-4XSFP-1M for a time.
<G-vec00097-001-s124><occur.auftreten><de> Sogar Kuhmilchallergien und andere sonst nur bei Kuhmilch auftretenden Probleme durch Muttermilch sind möglich, wenn die stillende Mutter Milch trinkt.
<G-vec00097-001-s124><occur.auftreten><en> Even cow's milk allergy and other problems which occur only with cow's milk are possible through breast milk if the nursing mother is drinking milk.
<G-vec00097-001-s125><occur.auftreten><de> Die beim Zusammenführen von digitaler und analoger Lagekomponente üblicherweise auftretenden Quadrantenfehler werden zuverlässig erkannt und kompensiert.
<G-vec00097-001-s125><occur.auftreten><en> The quadrant errors, which usually occur when digital and analog position components are combined to form a single position information are reliably detected and compensated.
<G-vec00097-001-s126><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen SC353502J7M28 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen SC353502J7M28 zu Tage tritt.
<G-vec00097-001-s126><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible SC353502J7M28 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible SC353502J7M28 for a time.
<G-vec00097-001-s127><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen CFP-100G-ER4 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen CFP-100G-ER4 zu Tage tritt.
<G-vec00097-001-s127><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible CFP-100G-ER4 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible CFP-100G-ER4 for a time.
<G-vec00097-001-s128><occur.auftreten><de> Durch die eigene langjährige Erfahrung auf dem Gebiet der Trockenmörte-Technologie kennen unsere Spezialisten die in der Produktion auftretenden Probleme aus erster Hand und wissen, dass das primäre Ziel sein muss, mit einem möglichst geringen Prüfaufwand eine maximal zuverlässige Überwachung der Rohstoff- und Produktqualitäten sicherzustellen.
<G-vec00097-001-s128><occur.auftreten><en> Thanks to their many years of experience in the area of dry mortar technology, our specialists are familiar with the problems that can occur during production and know that the primary goal must be to ensure the most reliable monitoring of raw material and product quality possible, while still keeping testing to a minimum.
<G-vec00097-001-s129><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen MFELX1 oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen MFELX1 zu Tage tritt.
<G-vec00097-001-s129><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible MFELX1 or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible MFELX1 for a time.
<G-vec00097-001-s130><occur.auftreten><de> Bei auftretenden Mängeln leistet Psytest Psychologische Testsysteme auf Verlangen des Auftraggebers Nacherfüllung nach seiner Wahl durch Beseitigung des Mangels (Nachbesserung) oder durch Lieferung einer mangelfreien Sache (Neulieferung).
<G-vec00097-001-s130><occur.auftreten><en> When defects occur, Psytest Psychological Test Systems shall provide on request of the client rectification of their choice through elimination of the defect (rectification) or through delivery of goods free of defects (replacement).
<G-vec00097-001-s131><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen 10GB-ZR-SFPP-ES oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen 10GB-ZR-SFPP-ES zu Tage tritt.
<G-vec00097-001-s131><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible 10GB-ZR-SFPP-ES or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible 10GB-ZR-SFPP-ES for a time.
<G-vec00097-001-s132><occur.auftreten><de> Aus diesem Grund ist Vorsicht geboten bei zu gÃ1⁄4nstigen Angeboten von kompatiblen 02310MUP oder Anbietern die Dinge versprechen, welche nachher nicht eingehalten werden können, was dann spätestens bei auftretenden Problemen mit dem kompatiblen 02310MUP zu Tage tritt.
<G-vec00097-001-s132><occur.auftreten><en> For this reason, caution should be exercised in the case of cheap offers from compatible 02310MUP or vendors that say things they cannot comply with afterwards, what will be revealed firstly when problems occur while using the compatible 02310MUP for a time.
<G-vec00097-001-s133><occur.auftreten><de> Wenn dies auftritt, suchen Sie nach Produkten, die in ihnen nicht so viel Peroxid haben.
<G-vec00097-001-s133><occur.auftreten><en> If this does occur, look for products that do not have as much peroxide in them.
<G-vec00097-001-s134><occur.auftreten><de> Denken Sie daran, Anavar Kapseln nicht tun aromatisieren so schädliche Wirkungen wie Gynäkomastie; die Förderung der männlichen Büste in der Regel nicht auftritt.
<G-vec00097-001-s134><occur.auftreten><en> Remember Anavar pills do not aromatize so adverse effects like Gynecomastia; the development of male bust usually does not occur.
<G-vec00097-001-s135><occur.auftreten><de> Zone 22: ist ein Bereich, in dem im Normal betrieb eine gefährliche explosions fähige Atmosphäre in Form einer Wolke aus in der Luft enthaltenem brenn baren Staub normaler weise nicht auftritt, und wenn doch, dann nur selten und für kurzeZeit.
<G-vec00097-001-s135><occur.auftreten><en> Zone 22: is an area in which a hazardous, potentially explosive atmosphere in the form of a cloud of dust contained in the air does not normally occur in normal operation, and if it does, then only rarely and for a short time.
<G-vec00097-001-s136><occur.auftreten><de> Es gibt einige Ursachen dieser Anzeichen, aber schlecht gehandhabtes Asthma ist der fÃ1⁄4hrende Grund, damit dieses, mit bis zu einem Viertel aller Athleten auftritt, die Zeichen des Asthmas aufweisen.
<G-vec00097-001-s136><occur.auftreten><en> There are several causes of these symptoms, but poorly managed asthma is the leading reason for this to occur, with up to a quarter of all athletes exhibiting signs of asthma.
<G-vec00097-001-s137><occur.auftreten><de> Das Praktizieren der traditionellen Reihenfolge der vier Geisteshaltungen hilft dabei, das Greifen nach den ausgerichteten Formen dieser Geisteshaltungen zu verringern, das möglicherweise auftritt.
<G-vec00097-001-s137><occur.auftreten><en> Practicing like this with the traditional order of the four attitudes helps to lessen any clinging to the aimed forms of them that might occur.
<G-vec00097-001-s138><occur.auftreten><de> Ein Vergleich mit realen Verletzungen hat gezeigt, dass bei diesem Grenzwert eine nach AIS-Stufe3 (Abbreviated Injury Scale) einzuordnende Verletzung mit einer Wahrscheinlichkeit von 0,5 (50%) auftritt.
<G-vec00097-001-s138><occur.auftreten><en> A comparison with actual injuries showed that at this threshold value an injury graded 3 on the Abbreviated Injury Scale (AIS) will occur with a 0.5 (50%) probability.
<G-vec00097-001-s139><occur.auftreten><de> Obwohl viele Menschen anders denken, Fahrzeugmaximalbrems nicht auftritt, wenn die Räder blockieren, Denn die Reibung zwischen dem Reifen und der Straße nicht zwischen den Bremsklötzen und Scheiben.
<G-vec00097-001-s139><occur.auftreten><en> Although many people think otherwise, maximum vehicle braking does not occur when the wheels lock, is because the friction between the tire and the road not between the brake pads and disc.
<G-vec00097-001-s140><occur.auftreten><de> Es war sehr viel wie die alten Adapter, aber nicht mit den neuesten auftritt.
<G-vec00097-001-s140><occur.auftreten><en> It was a lot like the old adapters, but does not occur with the newest.
<G-vec00097-001-s141><occur.auftreten><de> Die Macht der Arbeit kann nur in dem Maß verwirklicht werden, wie sich das revolutionäre politische Bewusstsein der fortschrittlichen Schichten der Arbeiterklasse entwickelt — was nicht als Nebenprodukt des Aktivismus einfacher Mitglieder am Arbeitsplatz auftritt.
<G-vec00097-001-s141><occur.auftreten><en> The power of labor can only be realized to the extent that revolutionary political consciousness develops within the advanced layers of the working class—something that does not occur as a byproduct of simple rank-and-file activism in the workplace.
<G-vec00097-001-s142><occur.auftreten><de> Zuerst einmal ist zu berücksichtigen, dass der Tag des Neumonds nicht jeden Monat genau zur gleichen Zeit auftritt.
<G-vec00097-001-s142><occur.auftreten><en> Firstly, the exact new moon does not occur at precisely the same time of day each month.
<G-vec00097-001-s143><occur.auftreten><de> Aspermatismus ist ein Zustand, bei dem die Ejakulation während des Geschlechtsverkehrs nicht auftritt.
<G-vec00097-001-s143><occur.auftreten><en> Aspermatism is a condition in which ejaculation does not occur during sexual intercourse.
<G-vec00097-001-s144><occur.auftreten><de> Ob dieses Problem ein Einzelfall bei diesem einen Server war oder auch auf anderen Systemen mit diesem Mainboard auftritt, kann nicht mit Sicherheit gesagt werden.
<G-vec00097-001-s144><occur.auftreten><en> Whether this problem an individual case for this one server was or will also occur on other systems with the main board, could not be determined with certainty.
<G-vec00097-001-s145><occur.auftreten><de> Obwohl eine Stentthrombose vergleichsweise selten auftritt, ist sie eine gefährliche Komplikation, die sich entwickeln kann, nachdem in die Herzkranzgefäße des Patienten der Stent eingesetzt wurde, um das Gefäß offen zu halten.
<G-vec00097-001-s145><occur.auftreten><en> Although stent thrombosis is rare, it is a catastrophic complication that can occur after a stent has been inserted into a patient's coronary artery to keep the vessel open.
<G-vec00097-001-s146><occur.auftreten><de> So typisch normaler Menstruations Ovulation (Ei Ausgang aus dem Follikel) tritt nicht auf, und daher Menstruation nicht auftritt.
<G-vec00097-001-s146><occur.auftreten><en> Thus, the characteristic of the normal menstruation ovulation (release of an egg from the follicle) does not occur, and thus, menstruation does not occur.
<G-vec00097-001-s147><occur.auftreten><de> Der Zeitpunkt, an dem das Hochwasser auftritt, hat also mit dem Klima viel unmittelbarer zu tun als die absolute Höhe des Hochwasserereignisses.
<G-vec00097-001-s147><occur.auftreten><en> The timing at which floods occur is thus much more directly related to the climate, in contrast with the absolute magnitude of the flood event.
<G-vec00097-001-s148><occur.auftreten><de> Erhöhen Sie die Sicherheit am Arbeitsplatz, indem Sie genau erkennen, wann genau in einem Prozess menschliches Versagen auftritt und welche Faktoren dem zugrunde liegen.
<G-vec00097-001-s148><occur.auftreten><en> Improve safety in your workplace by knowing exactly at which stage of the process human errors occur and their underlying factors.
<G-vec00097-001-s149><occur.auftreten><de> Von Wundern gibt es zwei Arten: diejenigen, die auf Wunsch der Menschen auftreten, die ein Zeichen für die Glaubwürdigkeit des Propheten verlangen, der zu ihnen gesandt wurde, und die zweite Art, die auftritt, ohne verlangt worden zu sein.
<G-vec00097-001-s149><occur.auftreten><en> Miracles can be of two types; those that occur at the request of the people, who want a sign of the veracity of the Prophet who was sent to them and the second type, occur without being requested.
<G-vec00097-001-s150><occur.auftreten><de> In der südlichen Hemisphäre, wird die Drehung der Schwingungsebene in der Richtung entgegengesetzt zu derjenigen in der nördlichen Hemisphäre beobachtet auftritt.
<G-vec00097-001-s150><occur.auftreten><en> "In the southern hemisphere the rotation of the plane of oscillation will occur in the direction opposite to that observed in the Northern Hemisphere. """
<G-vec00097-001-s151><occur.auftreten><de> Obwohl eine Stentthrombose vergleichsweise selten auftritt, bleibt sie eine gefährliche Komplikation, die sich entwickeln kann, nachdem in die Herzkranzgefäße des Patienten der Stent eingesetzt wurde, um das Gefäß offen zu halten.
<G-vec00097-001-s151><occur.auftreten><en> Although stent thrombosis is rare, it remains a dangerous complication that may occur after a stent has been inserted into a patient's coronary artery to keep the passageway open.
<G-vec00097-001-s684><occur.auftreten><de> Werden die Parameter des Falleneinschlusses schneller als die Schallgeschwindigkeit im Kristall verändert, so treten topologische Defekte auf (Abb.
<G-vec00097-001-s684><occur.auftreten><en> If the parameters of the trap enclosure are varied faster than the speed of sound in the crystal, then topological defects occur (Fig.
<G-vec00097-001-s685><occur.auftreten><de> Solche gravierenden Ausschläge treten bei Kindern öfter als bei Erwachsenen auf.
<G-vec00097-001-s685><occur.auftreten><en> Serious rashes occur more often in children than adults taking this medicine.
<G-vec00097-001-s686><occur.auftreten><de> Die enthaltenen Lastfälle 1 und 2 treten in allen Lastkombinationen gemeinsam auf.
<G-vec00097-001-s686><occur.auftreten><en> The contained load cases 1 and 2 occur together in all load combinations.
<G-vec00097-001-s687><occur.auftreten><de> Sehr selten jedoch treten Exemplare mit komplett dunklen Flügeln auf.
<G-vec00097-001-s687><occur.auftreten><en> Very rarely however specimens with completely dark wings occur.
<G-vec00097-001-s688><occur.auftreten><de> Zöliakie und Diabetes Typ 1 treten oft gemeinsam auf.
<G-vec00097-001-s688><occur.auftreten><en> Celiac disease and type 1 diabetes often occur together.
<G-vec00097-001-s689><occur.auftreten><de> Wegen der extremen Empfindlichkeit der gesamten Anlage gegen Erschütterungen treten Effekte auf, die normalerweise keine Rolle spielen.
<G-vec00097-001-s689><occur.auftreten><en> The extreme sensitivity of the whole installation to vibrations means effects occur which are normally not important.
<G-vec00097-001-s690><occur.auftreten><de> Kontaktströme treten auf, wenn eine Person leitfähige Oberflächen mit unterschiedlichen Potentialen berührt und einen Kreis schließt, durch den der elektrische Strom durch den Körper fließt.
<G-vec00097-001-s690><occur.auftreten><en> Contact currents occur when a person touches conductive surfaces at different potentials and completes a path through which electric current flows within the body.
<G-vec00097-001-s691><occur.auftreten><de> Wie bei jedem Arzneimittel, das eine Vielzahl von Inhaltsstoffen enthält, treten Nebenwirkungen auf, so dass Tabletten Losartan nicht mit jedem Organismus kompatibel sind.
<G-vec00097-001-s691><occur.auftreten><en> As with any medicinal product, which contains a large number of ingredients, side effects occur, and Losartan tablets are not compatible with every organism.
<G-vec00097-001-s692><occur.auftreten><de> Obwohl die Proteine, die durch BRCA1 und BRCA2 kodiert werden, Ã1⁄4ber eine geläufige Bahn des genomischen Schutzes und der Reparatur arbeiten, treten ihre Rollen in verschiedenen Stadien des DNS-Reparatursystems auf.
<G-vec00097-001-s692><occur.auftreten><en> Though proteins encoded by BRCA1 and BRCA2 work via a common pathway of genomic protection and repair, their roles occur at different stages of the DNA repair mechanism.
<G-vec00097-001-s693><occur.auftreten><de> Dabei treten zwei Quanteneffekte auf.
<G-vec00097-001-s693><occur.auftreten><en> Two quantum effects then occur.
<G-vec00097-001-s694><occur.auftreten><de> Leistungsprobleme treten auf, wenn ein Netzteil weiterhin funktioniert, jedoch außerhalb seiner Leistungsspezifikationen.
<G-vec00097-001-s694><occur.auftreten><en> Performance issues occur when a power supply continues to operate, but outside of its performance specs.
<G-vec00097-001-s695><occur.auftreten><de> Bei einer Entzündung von Magen und Darm treten meist Übelkeit, Erbrechen und Durchfall auf, begleitet von Fieber und Bauchschmerzen.
<G-vec00097-001-s695><occur.auftreten><en> In the case of an inflammation of the stomach and intestines, nausea, vomiting and diarrhoea occur, accompanied by fever and stomach pains.
<G-vec00097-001-s696><occur.auftreten><de> Wie bei jedem Arzneimittel, das viele Inhaltsstoffe enthält, treten Nebenwirkungen auf, und Losartan-Tabletten sind nicht mit jedem Organismus kompatibel.
<G-vec00097-001-s696><occur.auftreten><en> As with any medicinal product, which contains a large number of ingredients, side effects occur, and Losartan tablets are not compatible with every organism.
<G-vec00097-001-s697><occur.auftreten><de> """Solche ungewöhnlichen Muster treten typischerweise auf, wenn ein Skelett ungleichmäßig bewachsen und damit geschützt wurde"", erklärt Heijne."
<G-vec00097-001-s697><occur.auftreten><en> """Such unusual patterns typically occur when a skeleton is unevenly colonized and thus protected,"" Heijne explains."
<G-vec00097-001-s698><occur.auftreten><de> Während schwerwiegende intraoperative Komplikationen relativ selten sind, treten dauerhafte Funktionsstörungen unterschiedlichen Ausmaßes häufiger auf.
<G-vec00097-001-s698><occur.auftreten><en> Severe intraoperative complications are rare but persisting impairments of various degrees can occur.
<G-vec00097-001-s699><occur.auftreten><de> Die Sichtungen der Zweiten Sonne treten auf bei Morgendämmerung oder Abenddämmerung, wenn die Biegung der Erde begünstigt, dass das sich biegende rote Licht dominant wird.
<G-vec00097-001-s699><occur.auftreten><en> The Second Sun sightings occur at dawn or dusk, when the curve of the Earth facilitates the bending red light to become dominant.
<G-vec00097-001-s700><occur.auftreten><de> Die Blutgerinnungsprobleme treten auf, da Betroffene einen Mangel an Proteinen aufweisen, die für eine normale Blutgerinnung benötigt werden.
<G-vec00097-001-s700><occur.auftreten><en> The blood clotting problems occur because people with hemophilia have a lack of the proteins needed for normal blood clotting to take place.
<G-vec00097-001-s701><occur.auftreten><de> Damit treten trotz der Kühlung des Körpers keine nennenswerten Veränderungen in den Atmungs- und Herzsystemen auf.
<G-vec00097-001-s701><occur.auftreten><en> With it, despite the cooling of the body, no significant changes occur in the respiratory and cardiac systems.
<G-vec00097-001-s702><occur.auftreten><de> Sexuelle Störungen treten bei der Hälfte der Männer mit Diabetes auf.
<G-vec00097-001-s702><occur.auftreten><en> Sexual disorders occur in half of men with diabetes.
<G-vec00225-002-s114><act.auftreten><de> Ihr zuständiges Booking.com-Büro: Um die Nutzung der Booking.com-Services zu unterstützen, können Ihre Daten mit Tochterunternehmen der Booking.com-Unternehmensgruppe geteilt werden, die als Dienstleister für Booking.com auftreten, einschließlich in Bezug auf Kundenservice-Leistungen.
<G-vec00225-002-s114><act.auftreten><en> Your local Booking.com office: In order to support the use of the Booking.com services, your details may be shared with subsidiaries of the Booking.com corporate family which act as service providers for Booking.com, including in relation to customer support services.
<G-vec00225-002-s115><act.auftreten><de> Im Zusammenspiel von Fach- und Coaching-Modulen entwickeln die Teilnehmenden der Weiterbildung ein vertieftes Verständnis von den vielfältigen Aufgaben einer professionellen Begleitung im Bereich der UK und erwerben die hierfür notwendigen Kompetenzen um letztlich als professionelle Berater (Coaches) auftreten zu können.
<G-vec00225-002-s115><act.auftreten><en> Through the interplay of subject and coaching modules, the participants of the further education develop a deepened Understanding of the manifold tasks of a professional escort in the area of the UK and acquire the necessary competencies to finally be able to act as professional consultants (coaches).
<G-vec00225-002-s116><act.auftreten><de> Als zentraler Auftraggeber kann dabei nur ein öffentlicher Auftraggeber auftreten, während der „vertretene“ Auftraggeber auch ein sektoraler Auftraggeber sein kann.
<G-vec00225-002-s116><act.auftreten><en> Only a public orderer can act as a central orderer, and a sector orderer can be an orderer which lets itself to be “represented”.
<G-vec00225-002-s117><act.auftreten><de> 2.1 Für die Zwecke dieses DVN kann Eventbrite als Verantwortlicher auftreten oder als Auftragsverarbeiter für einen seiner Kunden.
<G-vec00225-002-s117><act.auftreten><en> 2.1 For purposes of this DPA, Eventbrite may act as a Controller, or it may act as a Processor of one of its customers.
<G-vec00225-002-s118><act.auftreten><de> Bitte beachte jedoch, dass du durch die Zugehörigkeit zu unserem Musikverlagsdienst keinen eigenen Musikverlag besitzen musst, da TuneCore in deinem Auftrag mit einem unserer Tochterunternehmen als dein Verleger auftreten wird: TuneCore Digital Music (BMI), TuneCore Publishing (ASCAP) oder TuneCore Songs (SESAC).
<G-vec00225-002-s118><act.auftreten><en> However, please be advised that by joining our Publishing Administration Service you do not need to have your own publishing entity because TuneCore will act on your behalf as your publisher with one of our affiliated companies: TuneCore Digital Music (BMI), TuneCore Publishing (ASCAP), or TuneCore Songs (SESAC).
<G-vec00225-002-s119><act.auftreten><de> Schließlich wurde der Mann so krank, dass sein ehemaliger Schatten ihm einen Ausflug zu einem Kurort auf seine Kosten vorschlug, allerdings unter der Bedingung, dass der ehemalige Schatten selbst als Herr auftreten dürfte, während der Schriftsteller so tun musste, als wäre er der Schatten.
<G-vec00225-002-s119><act.auftreten><en> Finally he had become so ill that his former shadow proposed a trip to a health resort offering to foot the bill as well, but on condition that he could act as the master now, and the writer would pretend to be his shadow.
<G-vec00225-002-s120><act.auftreten><de> "Wie jede andere Frau auch, möchte ich mich wohl fühlen, souverän auftreten, attraktiv sein, kompetent wirken – in jeder Situation und meiner Stimmung entsprechend.
<G-vec00225-002-s120><act.auftreten><en> "Like every other woman as well, I want to feel comfortable, act sovereign, be attractive, and appear competent – in every situation and according to my mood.
<G-vec00225-002-s121><act.auftreten><de> Die Auftragnehmerin kann auch als Subunternehmen für Dritte auftreten.
<G-vec00225-002-s121><act.auftreten><en> The Contractor may also act as a subcontractor for third parties.
<G-vec00225-002-s122><act.auftreten><de> Die haben den Vorteil, daß sie dann später auch gleich als "neutrale" Zeugen gegen Sie auftreten können.
<G-vec00225-002-s122><act.auftreten><en> These ones have the advantage that they can act later as "neutral" witnesses against us.
<G-vec00225-002-s123><act.auftreten><de> Als sogenanntes Zahlungsinstitut kann aber nicht jedes Unternehmen auftreten.
<G-vec00225-002-s123><act.auftreten><en> However, not every company can act as a payment institution.
<G-vec00225-002-s124><act.auftreten><de> Bitte beachte, dass wir keine Sofortverkäufe anbieten, sondern als Dienstleister auftreten, der Dich mit den lokalen Agenten in Kontakt bringt.
<G-vec00225-002-s124><act.auftreten><en> Please note that we don’t offer any immediate sales but rather act as a service provider who puts you in touch with the local agents.
<G-vec00225-002-s125><act.auftreten><de> Eine Bank würde dabei Mitglied der Libra Association werden oder im Namen eines bestehenden Mitglieds als autorisierter Wiederverkäufer auftreten.
<G-vec00225-002-s125><act.auftreten><en> A bank would become a member of the Libra Association or act as an authorised reseller on behalf of an existing member.
<G-vec00225-002-s126><act.auftreten><de> Zu diesem Zweck wird SES eng mit der OHB System AG aus Bremen zusammenarbeiten, die als Hauptauftragnehmer von SES auftreten wird.
<G-vec00225-002-s126><act.auftreten><en> To this end, SES will work in close cooperation with OHB System AG of Bremen, who will act as the prime contractor to SES.
<G-vec00225-002-s127><act.auftreten><de> Ich werde zu jeder Zeit als euer Verteidiger auftreten.
<G-vec00225-002-s127><act.auftreten><en> I'll act as your defender at all times.
<G-vec00225-002-s128><act.auftreten><de> Wir freuen uns auf Ihre Teilnahme an der Veranstaltung, bei der auch Sie als Mitglied (Geschäftspartner) oder Sponsor der Veranstaltung auftreten können.
<G-vec00225-002-s128><act.auftreten><en> We look forward to your participation on the event where you can also act as our member (business partner) or sponsor of the event.
<G-vec00225-002-s129><act.auftreten><de> Nur wenn wir in diesem Geiste auftreten werden, wenn wir in unserer ganzen Massenarbeit überzeugend beweisen werden, daß wir sowohl vom nationalen Nihilismus als auch vom bürgerlichen Nationalismus gleichermaßen frei sind, nur in diesem Falle werden wir einen wirklich erfolgreichen Kampf gegen die chauvinistische Demagogie der Faschisten führen können.
<G-vec00225-002-s129><act.auftreten><en> If we act in this spirit, if in all our mass work we prove convincingly that we are free of both national nihilism and bourgeois nationalism, then and only then shall we be able to wage a really successful struggle against the jingo demagogy of the fascists.
<G-vec00225-002-s130><act.auftreten><de> Die Kommission steht auf dem Standpunkt, dass es daher im Wesentlichen Aufgabe der Mitgliedstaaten ist, entsprechende Aktionen auszuwählen und durchzuführen, weil sie am besten in der Lage sind, Instrumente und Produkte für die Informationskampagnen zu gestalten und darauf hinzuwirken, dass Gebietskörperschaften, Erbringer öffentlicher Dienstleistungen und sonstige Einrichtungen der Bürgergesellschaft als Informationsstellen auftreten.
<G-vec00225-002-s130><act.auftreten><en> Member States The EU communication strategy will be targeted at Member States' citizens and economic operators. The Member States are therefore best placed to create information tools and products and to encourage the regional and local authorities, public interest services and networks of civil society organisations to act as information relays.
<G-vec00225-002-s131><act.auftreten><de> In speziellen Seminaren und Fortbildungen werden private Dozenten ausgebildet, die dann als Vermittler auftreten und in den lokalen Gemeinden ihre liberalen Islamvorstellungen an Studenten und Lehrer weitergeben.
<G-vec00225-002-s131><act.auftreten><en> At special seminars and training sessions, private lecturers are trained to act as mediators, communicating their liberal conceptions of Islam to students and teachers in the local communities.
<G-vec00225-002-s132><act.auftreten><de> Es ist sehr wichtig, dass alle in der Gesellschaft den Verhaltenskodex beachten, auch diejenigen, die in ihrem Namen auftreten.
<G-vec00225-002-s132><act.auftreten><en> It is very important, that everyone in the company follows the Code of Ethics and the same goes also for those who act on the company’s behalf.
<G-vec00243-002-s185><trouble.auftreten><de> Wenn immer noch Probleme auftreten, kontaktieren Sie bitte unser Support-Team und geben Sie in Ihrer Nachricht die Seriennummer Ihres Produktes an (diese finden Sie auf dem Benutzerhandbuch oder auf der Rückseite der Steuereinheit).
<G-vec00243-002-s185><trouble.auftreten><en> If you are still having trouble, please contact our support team and include the serial number in your message (located on the welcome pamphlet or on the back of the controller).
<G-vec00243-002-s186><trouble.auftreten><de> Sollten Probleme auftreten, lesen Sie den Abschnitt Hilfe beim Ändern der E-Mail-Adresse.
<G-vec00243-002-s186><trouble.auftreten><en> If you're having trouble, get help changing your email address.
<G-vec00243-002-s187><trouble.auftreten><de> Wenn Probleme beim Verbindungsaufbau mit Google Earth auftreten und auf Ihrem Computer eine Firewall-Software installiert ist, kann Google Earth möglicherweise nicht auf das Internet zugreifen.
<G-vec00243-002-s187><trouble.auftreten><en> If you're having trouble connecting to Google Earth and your machine has a software firewall, Google Earth might not be able to access the internet.
<G-vec00243-002-s188><trouble.auftreten><de> Wenn beim Abspielen von zuvor von Xbox Live heruntergeladenen Inhalten auf der Xbox 360 Probleme auftreten, finden Sie hier mögliche Lösungen.
<G-vec00243-002-s188><trouble.auftreten><en> If you are having trouble playing content on your Xbox 360 that you previously downloaded from Xbox Live, find out possible solutions.
<G-vec00243-002-s189><trouble.auftreten><de> Wenden Sie sich an den Xbox Support, wenn bei der Kündigung Ihrer Mitgliedschaft über das Internet Probleme auftreten.
<G-vec00243-002-s189><trouble.auftreten><en> If you have trouble cancelling your membership online, contact Xbox Support.
<G-vec00243-002-s190><trouble.auftreten><de> Wenn weiterhin Probleme auftreten, überprüfen Sie Ihren Browser auf etwaige Fehler.
<G-vec00243-002-s190><trouble.auftreten><en> If you're still having trouble, check for issues related to your browser.
<G-vec00243-002-s191><trouble.auftreten><de> Wenn dabei Probleme auftreten oder Sie Fragen haben sollten, konsultieren Sie Ihren Optiker oder Augenarzt.
<G-vec00243-002-s191><trouble.auftreten><en> If you have any trouble or questions arise, call your optician for advice.
<G-vec00243-002-s192><trouble.auftreten><de> Wenn du Dateien nicht öffnen kannst oder sonstige Probleme auftreten, dann wende dich bitte an den Dozenten oder den Udemy-Support.
<G-vec00243-002-s192><trouble.auftreten><en> If you're having trouble accessing the file, or if something doesn't look right, please contact the instructor or Udemy support.
<G-vec00243-002-s193><trouble.auftreten><de> Wenn weiterhin Probleme auftreten, nehmen Sie Kontakt mit uns auf.
<G-vec00243-002-s193><trouble.auftreten><en> If you’re still having trouble, contact us.
<G-vec00243-002-s194><trouble.auftreten><de> Wenn weiterhin Probleme auftreten, wenden Sie sich an den Apple Support.
<G-vec00243-002-s194><trouble.auftreten><en> If you’re still having trouble, contact Apple Support.
<G-vec00243-002-s195><trouble.auftreten><de> Falls beim Empfangen oder Senden von Workspace-E-Mails mit Apple Mail auf dem Mac Probleme auftreten, finden Sie weiter unten nützliche Schritte zur Problembehebung.
<G-vec00243-002-s195><trouble.auftreten><en> If you’re having trouble with receiving or sending your Workspace email, using Apple Mail on Mac, see below for some helpful troubleshooting steps.
<G-vec00243-002-s196><trouble.auftreten><de> Wenn sich der Kinect Sensor ohne Fehler einschalten lässt und dennoch Probleme damit auftreten, finden Sie unter Beheben von Problemen mit dem Xbox One Kinect Sensor weitere Informationen.
<G-vec00243-002-s196><trouble.auftreten><en> If your Kinect sensor turns on without any errors, but you’re still having trouble with it, see Troubleshoot issues with the Xbox One Kinect Sensor.
<G-vec00243-002-s197><trouble.auftreten><de> Wenn weiterhin Probleme auftreten, findest du in der Google Play-Hilfe Tipps zur Fehlersuche bei Download-Problemen.
<G-vec00243-002-s197><trouble.auftreten><en> If you’re still having trouble, check the Google Play Help Center for tips to troubleshoot download issues.
<G-vec00243-002-s198><trouble.auftreten><de> Sollten Probleme auftreten, wählen Sie „I had problems with at least one computer” (Ich hatte Probleme mit mindestens einem Computer) und klicken Sie auf „Next” (Weiter).
<G-vec00243-002-s198><trouble.auftreten><en> If you are having trouble, select “I had problem with at least one computer” and click “Next”.
<G-vec00245-002-s133><appear.auftreten><de> Als Grund dafür wird gerne angeführt, daß die Schabrackentapire nachts über die Maisfelder herfallen und großen Schaden anrichteten, was aber sicherlich sehr übertrieben sein dürfte, da sich Tapire gegenseitig meiden und deshalb niemals in großen Gruppen auftreten.
<G-vec00245-002-s133><appear.auftreten><en> It is specified reasons for it gladly that the Schabrackentapire attack the cornfields at night and prepared big damage, which should be, however, very exaggerated surely, since tapirs avoid themselves mutually and therefore never appear in large groups.
<G-vec00245-002-s134><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Samsung Galaxy Camera 2 EKGC200ZWAXA Digitalkamera erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s134><appear.auftreten><en> It often happens that the first problems with the device Samsung Galaxy Camera 2 EKGC200ZWAXA Digital Camera appear only after a few weeks or months after its purchase.
<G-vec00245-002-s135><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät JVC GM-H40L2 Flachfernseher erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s135><appear.auftreten><en> It often happens that the first problems with the device JVC GM-H40L2 Flat Panel Television appear only after a few weeks or months after its purchase.
<G-vec00245-002-s136><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Ericsson Distribution Receivers RX8330 Heimkinoset erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s136><appear.auftreten><en> It often happens that the first problems with the device Ericsson Distribution Receivers RX8330 Home Theater System appear only after a few weeks or months after its purchase.
<G-vec00245-002-s137><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Haier Compact s HSP04WNA Kühlschrank erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s137><appear.auftreten><en> It often happens that the first problems with the device Haier HL42T Flat Panel Television appear only after a few weeks or months after its purchase.
<G-vec00245-002-s138><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Bosch Appliances TCA 4101 UC Kaffeemaschine erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s138><appear.auftreten><en> It often happens that the first problems with the device Bosch Appliances AUTOMATIC COFFEE CENTRE TCA 6301 UC Coffeemaker appear only after a few weeks or months after its purchase.
<G-vec00245-002-s139><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Canon IXUS55 Digitalkamera erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s139><appear.auftreten><en> It often happens that the first problems with the device Canon IXUS55 Digital Camera appear only after a few weeks or months after its purchase.
<G-vec00245-002-s140><appear.auftreten><de> Der Behälter zur Aufbewahrung von Samen muss sauber sein, damit sich keine Krankheiten entwickeln und Schädlinge auftreten.
<G-vec00245-002-s140><appear.auftreten><en> The container for storing seeds must be clean, so that diseases do not develop and pests appear.
<G-vec00245-002-s141><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät HP (Hewlett-Packard) HP LaserJet 4345mfp Multifunktionsgerät erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s141><appear.auftreten><en> It often happens that the first problems with the device HP (Hewlett-Packard) HP LaserJet 4345mfp All in One Printer appear only after a few weeks or months after its purchase.
<G-vec00245-002-s142><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Samsung UN32C6500VF Flachfernseher erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s142><appear.auftreten><en> It often happens that the first problems with the device Samsung UN32C6500VF Flat Panel Television appear only after a few weeks or months after its purchase.
<G-vec00245-002-s143><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Fujitsu Computer Monitor A19-1 DVI Monitor erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s143><appear.auftreten><en> It often happens that the first problems with the device Advantech FPM-3150G Computer Monitor appear only after a few weeks or months after its purchase.
<G-vec00245-002-s144><appear.auftreten><de> Roger McGuinn hatte eine Grippe und konnte nicht mit der Band auftreten.
<G-vec00245-002-s144><appear.auftreten><en> Even though Roger McGuinn had got the flu and was unable to appear the group did not want to cancel the date.
<G-vec00245-002-s145><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Sony PCG-GR170 Laptop erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s145><appear.auftreten><en> It often happens that the first problems with the device Sony PCG-GR170 Laptop appear only after a few weeks or months after its purchase.
<G-vec00245-002-s146><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Pentax 16811 Digitalkamera erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s146><appear.auftreten><en> It often happens that the first problems with the device Pentax OPTIO 750Z Digital Camera appear only after a few weeks or months after its purchase.
<G-vec00245-002-s147><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät HTC NM8LIBR100 Handy erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s147><appear.auftreten><en> It often happens that the first problems with the device HTC NM8LIBR100 Cell Phone appear only after a few weeks or months after its purchase.
<G-vec00245-002-s148><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät Broan 350BK Dachtraufe erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s148><appear.auftreten><en> It often happens that the first problems with the device Broan 350BK Ventilation Hood appear only after a few weeks or months after its purchase.
<G-vec00245-002-s149><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät HTC DREAM DREA160 Handy erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s149><appear.auftreten><en> It often happens that the first problems with the device HTC DREAM DREA160 Cell Phone appear only after a few weeks or months after its purchase.
<G-vec00245-002-s150><appear.auftreten><de> Über zwei Dutzend visuelle Effekte zwischen Bildern auftreten können.
<G-vec00245-002-s150><appear.auftreten><en> Over two dozen visual effects can appear between images.
<G-vec00245-002-s151><appear.auftreten><de> Es kommt oft vor, dass die ersten Probleme mit dem Gerät American Audio V1500 Stereoverstärker erst nach einigen Wochen oder Monaten seines Kaufs auftreten.
<G-vec00245-002-s151><appear.auftreten><en> It often happens that the first problems with the device American Audio M1224FX Music Mixer appear only after a few weeks or months after its purchase.
<G-vec00245-002-s417><emerge.auftreten><de> Aufgrund der Knappheit von Information entstehen jedoch Mängel im Prozess des Wirtschaftens: Koordinationsprobleme treten auf, wenn Akteure nicht wissen, welche Aufgabe ihnen zukommt; Motivationsprobleme resultieren aus abweichenden Zielvorstellungen von Akteuren, die möglicherweise die ihnen übertragende Aufgabe nicht ausführen wollen.
<G-vec00245-002-s417><emerge.auftreten><en> However, as a result of scarcity of information deficiencies in the process of economic operations arise: co-ordination problems emerge if agents do not know which task they are assigned to; motivation problems result from differing objectives of the agents who are possibly not willing to carry out their part of the task.
<G-vec00245-002-s418><emerge.auftreten><de> Jahr für Jahr treten fast 300.000 Neuerkrankungen auf.
<G-vec00245-002-s418><emerge.auftreten><en> Every year almost 300,000 new cases emerge.
<G-vec00245-002-s419><emerge.auftreten><de> Bei Männern warnt man vor einer "pharmakologischen Kastration"; bei Frauen treten irreversible Virilisierungserscheinungen auf; bei Jugendlichen besteht die Gefahr eines Wachstumsstillstands.
<G-vec00245-002-s419><emerge.auftreten><en> By men one warns of a "pharmacological castration"; by women irreversible appearances of virility will emerge; by young people there is danger of a growth stop.
<G-vec00245-002-s420><emerge.auftreten><de> Die sind durchaus nicht immer da, aber vor allem am Schluss, wenn er sich von Zwängen befreit hat und geht, ohne zu wissen, wohin es ihn treiben wird, treten diese Begleiter wieder auf.
<G-vec00245-002-s420><emerge.auftreten><en> They are absolutely not always there, but particularly at the end, when he has freed himself from obligations and goes without knowing where he will be driven to, these companions emerge again.
<G-vec00245-002-s421><emerge.auftreten><de> Bei der niedrigeren Konzentration c=1/1000 treten dagegen etwas größere Exponenten auf (n=1.1 bis 1.2).
<G-vec00245-002-s421><emerge.auftreten><en> At the lower concentration c=1/1000 somewhat higher exponents emerge (n=1.1 to 1.2).
<G-vec00245-002-s380><occur.auftreten><de> Gelangen diese sowie deren Bestandteile in die Atemluft, sind die Nutzer solcher mikrobiell belasteten Anlagen gefährdet und es können erhebliche Gesundheitsschäden auftreten.
<G-vec00245-002-s380><occur.auftreten><en> In case they and their components get into the breathing air, the users of such microbiologically contaminated devices are endangered, and severe health damage may occur.
<G-vec00245-002-s381><occur.auftreten><de> Es ist bekannt, dass sie bei bestimmten Erkrankungen wie Tuberkulose, aber auch im Zuge einer Fremdkörperreaktion an Implantaten wie Hüftgelenken auftreten.
<G-vec00245-002-s381><occur.auftreten><en> The cells occur in certain chronic inflammatory diseases, such as tuberculosis, but also during the foreign body reaction to implants, such as an artificial hip.
<G-vec00245-002-s382><occur.auftreten><de> Es konnte ein Fehler beim Löschen von Smartcard-Berichten auftreten.
<G-vec00245-002-s382><occur.auftreten><en> An error could occur while deleting smartcard reports.
<G-vec00245-002-s383><occur.auftreten><de> Es können Fehler auftreten, wenn der Integrationsprozess auf ein Problem stößt, das er nicht selbst lösen kann.
<G-vec00245-002-s383><occur.auftreten><en> Errors could occur when the integration process encounters an issue where it is unable to resolve it on its own.
<G-vec00245-002-s384><occur.auftreten><de> Es wird ein leichtes Kribbeln auftreten.
<G-vec00245-002-s384><occur.auftreten><en> Light tingling will occur.
<G-vec00245-002-s385><occur.auftreten><de> Wird der Organismus durch negative Schwingungen belastet, ist das Immunsystem geschwächt und es können Fehlfunktionen auftreten.
<G-vec00245-002-s385><occur.auftreten><en> If the organism is burdened by negative vibrations, the immune system is weakened and malfunctions can occur.
<G-vec00245-002-s386><occur.auftreten><de> Danach ist der Stein gut durchtränkt mit Brennflüssigkeit und es wird eine gleichmässige Verdampfung auftreten.
<G-vec00245-002-s386><occur.auftreten><en> After several uses the ceramic core will be thoroughly saturated with the liquid fuel and a steady combustion will occur.
<G-vec00245-002-s387><occur.auftreten><de> Es können daher geringe Abweichungen in Form und Farbe von der gezeigten Abbildung auftreten.
<G-vec00245-002-s387><occur.auftreten><en> Therefore minor deviations can occur in shape and color of the displayed figure.
<G-vec00245-002-s388><occur.auftreten><de> Es können nur seltene allergische Reaktionen auftreten, die von einzelnen Wirkstoffen abhängen.
<G-vec00245-002-s388><occur.auftreten><en> Only rare allergic reactions may occur, which depend on individual active ingredients.
<G-vec00245-002-s389><occur.auftreten><de> Diese Liste der Nebenwirkungen ist nicht vollständig und es können andere auftreten.
<G-vec00245-002-s389><occur.auftreten><en> This is not a complete list of all side effects that may occur.
<G-vec00245-002-s390><occur.auftreten><de> Es können vorübergehend Apathie und Fieber (über 39,5 °C) auftreten.
<G-vec00245-002-s390><occur.auftreten><en> Transient apathy and fever (above 39.5 °C) may occur.
<G-vec00245-002-s391><occur.auftreten><de> Es können auch andere Nebenwirkungen auftreten, die hier nicht aufgelistet sind.
<G-vec00245-002-s391><occur.auftreten><en> Side effects other than those listed here may also occur.
<G-vec00245-002-s392><occur.auftreten><de> Es können jedoch einige Änderungen auftreten.
<G-vec00245-002-s392><occur.auftreten><en> However, some changes may occur.
<G-vec00245-002-s393><occur.auftreten><de> Es können weitere Probleme auftreten, wenn Sie Laufwerk "M" mit einem Dateiscanner überprüfen.
<G-vec00245-002-s393><occur.auftreten><en> More problems may occur if you scan drive M with file-level scanner software.
<G-vec00245-002-s394><occur.auftreten><de> Zusätzlich zu dem hohen Kaloriengehalt von Weißbrot (260-300 kcal pro 100 g) verschlechtert sich die Arbeit des Gastrointestinaltrakts, wenn solche Backwaren, insbesondere frische, verwendet werden, und es kann Verstopfung auftreten.
<G-vec00245-002-s394><occur.auftreten><en> In addition to the high caloric content of white bread (260-300 kcal per 100 g), when using such baked goods, especially fresh, the work of the gastrointestinal tract worsens and constipation may occur.
<G-vec00245-002-s395><occur.auftreten><de> Wie bei der Brustverkleinerung kann die Stillfähigkeit nach der Operation eingeschränkt sein und es können Gefühls- oder Durchblutungsstörungen der Brustwarze auftreten.
<G-vec00245-002-s395><occur.auftreten><en> As with breast reduction, ability to breastfeed may be limited after surgery, and sensory or perfusion deficits of the nipples can occur.
<G-vec00245-002-s396><occur.auftreten><de> Es kann ein Fehler der Heizelemente der Sitzheizung auftreten.
<G-vec00245-002-s396><occur.auftreten><en> A fault of the heating elements in the seat heating can occur.
<G-vec00245-002-s397><occur.auftreten><de> Premium Touch: Es konnt ein Fehler beim Löschen von Artikeln auftreten.
<G-vec00245-002-s397><occur.auftreten><en> Premium Touch: an error could occur while deleting articles.
<G-vec00245-002-s398><occur.auftreten><de> Es kann eine Entzündung des Fettgewebes auftreten, die zu einer schweren Fettleber führt.
<G-vec00245-002-s398><occur.auftreten><en> Inflammation of adipose tissue, resulting in severe fatty liver may occur.
<G-vec00258-002-s675><arise.auftreten><de> Manchmal treten auch private, finanzielle oder studienbezogene Schwierigkeiten auf.
<G-vec00258-002-s675><arise.auftreten><en> Sometimes private, financial or study-related difficulties arise.
<G-vec00258-002-s676><arise.auftreten><de> Bei der Herstellung eines solchen Klebstoffs treten normalerweise keine Schwierigkeiten auf.
<G-vec00258-002-s676><arise.auftreten><en> In the process of making such an adhesive, no difficulties usually arise.
<G-vec00258-002-s677><arise.auftreten><de> Überraschenderweise treten diese Schwingungen nicht unabhängig voneinander auf, sondern synchron.
<G-vec00258-002-s677><arise.auftreten><en> Surprisingly, these oscillations did not arise independently, but were synchronous.
<G-vec00258-002-s678><arise.auftreten><de> Treten Probleme auf, informiert die Solarpraxis AG den Auftraggeber und unterbreitet Änderungsvorschläge, die dem Auftraggeber zur Freigabe vorgelegt werden.
<G-vec00258-002-s678><arise.auftreten><en> Should problems arise, Solarpraxis AG shall inform the Client of this and make suggestions for alterations which shall be presented to the Client for approval.
<G-vec00258-002-s679><arise.auftreten><de> Probleme treten allerdings auf, weil die Software in der Lage ist, eine große Informationsmenge zu tracken, die nicht unbedingt nützlich für die Entwickler der Webseite ist und weil Drittparteien Zugriff auf diese Information haben.
<G-vec00258-002-s679><arise.auftreten><en> Problems arise, however, because the software is capable of tracking a great deal of information that isn’t necessarily useful for website developers, and because third parties have access to that information.
<G-vec00258-002-s680><arise.auftreten><de> 2018 Konflikte bei Jugendlichen treten nicht nur mit Erwachsenen auf, sondern auch untereinander.
<G-vec00258-002-s680><arise.auftreten><en> 2018 Conflicts in adolescents arise not only with adults, but also among themselves.
<G-vec00258-002-s681><arise.auftreten><de> Während der Projektlaufzeit treten häufig Fragen in Bezug auf die Abrechnung der verschiedenen Kostenarten auf.
<G-vec00258-002-s681><arise.auftreten><en> During the project duration, questions concerning the calculation of various costs frequently arise.
<G-vec00258-002-s682><arise.auftreten><de> Wenn man für seine Lieben Geschenke aussuchen soll, treten viele Zweifel auf; unabhängig davon, ob es nun die Verlobte, Mutter, Herzensfreundin, Kollegin, der kleine Enkel oder der Ehemann zu beschenken ist: jeder hat seine urpersönlichen Wünsche und Träume.
<G-vec00258-002-s682><arise.auftreten><en> When you have to select a gift for someone dear to you, many doubts arise. Your girlfriend, mother, friend, colleague, young niece or nephew or husband --- they all represent a small world of desires and dreams that need to be met.
<G-vec00258-002-s683><arise.auftreten><de> Hier treten die meisten Hörprobleme auf.
<G-vec00258-002-s683><arise.auftreten><en> This is where most hearing issues arise.
<G-vec00258-002-s684><arise.auftreten><de> Treten – neben dem turnusmäßigen Reporting der wesentlichen Risiken – unerwartete Risiken auf, so werden diese unmittelbar gemeldet.
<G-vec00258-002-s684><arise.auftreten><en> If any unforeseen risks arise outside regular reporting of key risks, they are reported ad hoc.
<G-vec00258-002-s685><arise.auftreten><de> Auch wenn jede Branche ihre eigenen Vorgaben und Marketingvorlieben mit sich bringt, treten doch in vielen Bereichen ähnliche Schwierigkeiten auf.
<G-vec00258-002-s685><arise.auftreten><en> Even though each industry has its own specifications and marketing preferences, similar difficulties arise in many areas.
<G-vec00258-002-s686><arise.auftreten><de> Da nur bis zur zweiten Schicht der Oberhaut gearbeitet wird, treten keine Schwellungen oder Nebenwirkungen auf.
<G-vec00258-002-s686><arise.auftreten><en> Since only placed until the second layer of the epidermis, no swelling or side effects arise.
<G-vec00258-002-s687><arise.auftreten><de> Bei der Anerkennung der Fahrerausbildung aus einem anderen Mitgliedstaat treten Schwierigkeiten auf.
<G-vec00258-002-s687><arise.auftreten><en> Difficulties arise in the recognition of driver training from a different Member State
<G-vec00258-002-s688><arise.auftreten><de> In diesem Stadium treten oft Probleme auf, weil Kinder mit jeweils einem Spielzeug spielen wollen.
<G-vec00258-002-s688><arise.auftreten><en> At this stage, problems often arise because children want to play with one toy at a time.
<G-vec00258-002-s689><arise.auftreten><de> Am häufigsten treten Probleme auf, wenn von 5-10 Hühnern ein Stamm von 50-100 Tieren gehalten wird.
<G-vec00258-002-s689><arise.auftreten><en> Problems most often arise when from 5-10 chickens go to keeping a tribe of 50-100 heads.
<G-vec00261-002-s055><persist.auftreten><de> Falls Probleme auftreten, dann wende Dich bitte an den Administrator dieser Website.
<G-vec00261-002-s055><persist.auftreten><en> Home Page If difficulties persist please contact the system administrator of this site
<G-vec00261-002-s057><persist.auftreten><de> Falls Probleme auftreten, dann wenden Sie sich bitte an den Administrator dieser Website.
<G-vec00261-002-s057><persist.auftreten><en> If difficulties persist, please contact the system administrator.
<G-vec00307-002-s122><encounter.auftreten><de> Beim Hinzufügen von Benutzergruppen kann ein Fehler auftreten.
<G-vec00307-002-s122><encounter.auftreten><en> You may encounter an error when adding user groups.
<G-vec00307-002-s123><encounter.auftreten><de> Wir stehen Ihnen jederzeit gerne zur Hilfe bereit und Sie können sich darauf verlassen, dass wir alles tun, um sämtliche Probleme zu lösen, die eventuell bei Ihnen auftreten.
<G-vec00307-002-s123><encounter.auftreten><en> We are always happy to help and you can count on us doing our best to solve all problems you might encounter.
<G-vec00307-002-s124><encounter.auftreten><de> Die Schaumstoff-Kissen bieten optimalen Komfort sowie störende Hintergrundgeräusche, die auftreten können, zu isolieren.
<G-vec00307-002-s124><encounter.auftreten><en> The foam cushions provide optimal comfort as well as isolating any background noise you may encounter.
<G-vec00307-002-s125><encounter.auftreten><de> In einigen Fällen jedoch können Sie Probleme mit Bildschirmfreigabe auftreten.
<G-vec00307-002-s125><encounter.auftreten><en> However, sometimes you can encounter problems with screen sharing.
<G-vec00307-002-s126><encounter.auftreten><de> Speziell der Party Frame kann unter Umständen Lags/Ruckler verursachen (abrufen, zusammenführen, sortieren, filtern und anzeigen der Buffs und Debuffs von 5 Partymembers ist eine Menge Arbeit - Also wäre dieser Frame der erste den man deaktivieren sollte, falls Probleme auftreten).
<G-vec00307-002-s126><encounter.auftreten><en> Especially the party frame can cause some lags (retrieving, merging, sorting, filtering and displaying the buffs and debuffs of 5 party members is a lot of work to do - so this would be the first one to disable if you encounter any problems).
<G-vec00307-002-s127><encounter.auftreten><de> Wie bei jeder Systemaktualisierung empfehlen wir dringend, dass Sie vor und nach der Aktualisierung eine Sicherung für den Fall vornehmen, dass Probleme auftreten und Sie zu einem früheren Zustand zurückkehren müssen.
<G-vec00307-002-s127><encounter.auftreten><en> As with every system update, we strongly recommend that you perform a backup before and after the upgrade, in case you encounter issues and need to roll back.
<G-vec00307-002-s128><encounter.auftreten><de> Verwenden Sie dieses Handbuch, wenn Probleme oder Fragen auftreten.
<G-vec00307-002-s128><encounter.auftreten><en> Use this manual if you encounter any problems, or have any questions.
<G-vec00307-002-s129><encounter.auftreten><de> Diese Programme werden erstellt, um zu entfernen .Lurk file virus und ähnlich schädliche Infektionen, so sollten Sie keine Probleme auftreten.
<G-vec00307-002-s129><encounter.auftreten><en> Those programs are created to remove .Lurk file virus and similarly harmful infections, thus you shouldn’t encounter issues.
<G-vec00307-002-s130><encounter.auftreten><de> Falls bei der Installation Probleme mit dem ERA Agenten auftreten, überprüfen Sie das Status-Log auf dem Client, um sicherzustellen, dass der ERA Agent korrekt ausgeführt wird.
<G-vec00307-002-s130><encounter.auftreten><en> If you encounter issues with the ERA Agent during installation, check the status log on the client machine to make sure ERA Agent is working properly.
<G-vec00307-002-s131><encounter.auftreten><de> Wenn Sie keine virtuellen Betrügereien auftreten möchten, sollten Sie weg von Werbung bleiben, bis Sie Walasearch.com kündigen.
<G-vec00307-002-s131><encounter.auftreten><en> If you do not want to encounter any virtual scams, you should stay away from adverts until you terminate Walasearch.com.
<G-vec00307-002-s132><encounter.auftreten><de> Dieser Fehler kann auftreten, wenn Tableau Server für die vertrauenswürdige Authentifizierung konfiguriert worden ist.
<G-vec00307-002-s132><encounter.auftreten><en> You may encounter this error if you’ve configured Tableau Server for trusted authentication.
<G-vec00307-002-s133><encounter.auftreten><de> Wenn Sie ein Event mit der Chrome-Erweiterung für Events erstellen, kann die folgende Fehlermeldung auftreten: Dieser Selektor ist länger als 280 Zeichen.
<G-vec00307-002-s133><encounter.auftreten><en> When you create an event using the event Chrome extension, you may encounter the following error message: This selector is longer than 280 characters.
<G-vec00307-002-s134><encounter.auftreten><de> Wenn Cyber-kriminelle auftreten, stehen die Chancen, dass Sie mit Malware infiziert werden.
<G-vec00307-002-s134><encounter.auftreten><en> If you encounter cyber criminals, chances are that you will get infected with malware.
<G-vec00307-002-s135><encounter.auftreten><de> Wenn weiterhin Probleme auftreten, Support kontaktieren.
<G-vec00307-002-s135><encounter.auftreten><en> If you still encounter issues, please contact support.
<G-vec00307-002-s136><encounter.auftreten><de> “Dies sind einige der Situationen, die bei Ihren Datendateien auftreten können.
<G-vec00307-002-s136><encounter.auftreten><en> These are some of the situations that you may encounter with your data files.
<G-vec00307-002-s137><encounter.auftreten><de> • Organisationen, bei denen Datenschutzverletzungen auftreten, unterliegen strengen finanziellen Sanktionen als Folge ihres Versagens, die Daten zu schützen.
<G-vec00307-002-s137><encounter.auftreten><en> • Organisations that encounter data breaches will be subject to severe financial penalties as a result of their failure to protect the data.
<G-vec00307-002-s138><encounter.auftreten><de> 86 Fehlerbehebung In diesem Kapitel werden Probleme aufgelistet, die bei der Verwendung des T elef ons auftreten können.
<G-vec00307-002-s138><encounter.auftreten><en> 81 This chapter lists some problems you might encounter when using your phone.
<G-vec00307-002-s139><encounter.auftreten><de> Wenn Sie diese Fehlermeldung auftreten beim Öffnen / Zugriff auf Outlook-PST-Datei, dann ist es sehr empfehlenswert, um Outlook-PST-Datei zu reparieren.
<G-vec00307-002-s139><encounter.auftreten><en> When you encounter this error message while opening / accessing Outlook PST file, then it is highly recommended to repair Outlook PST file.
<G-vec00307-002-s140><encounter.auftreten><de> Qualitätstest Alle Wed'ze-Produkte werden unter realistischen Bedingungen getestet - bei Schnee, Kälte und allen anderen Bedingungen, die beim Skifahren auftreten können.
<G-vec00307-002-s140><encounter.auftreten><en> Test Product All Wed'ze products are tested under the real conditions of use for which they were designed: in the snow, in the cold, and all the conditions you might encounter when skiing.
<G-vec00373-002-s057><perform.auftreten><de> Im Sommer, verwandelt sich das Zentrum 1 Woche lang in einen prächtigen Konzertsaal, in dem internationale Künstler aus der ganzen Welt auftreten.
<G-vec00373-002-s057><perform.auftreten><en> In summer the plant is turned into a magnificent concert hall for a week, where international artists from all over the world perform.
<G-vec00373-002-s058><perform.auftreten><de> AUS DER INSIDER-PERSPEKTIVE: der bekannteste Unterhaltungstempel von New York, wo die größten Namen im Showgeschäft auftreten.
<G-vec00373-002-s058><perform.auftreten><en> GET AN INSIDERS VIEW of New York’s premier entertainment venue, where the biggest names in show business perform.
<G-vec00373-002-s059><perform.auftreten><de> Ihre Tanzkompanie wird bald in London auftreten, auf der Bühne der Royal Albert Hall.
<G-vec00373-002-s059><perform.auftreten><en> Her company will soon perform in London, on the boards of the Royal Albert Hall.
<G-vec00373-002-s060><perform.auftreten><de> Verpasst ein Musiker mehr als zwei Proben für das nächste Konzert, wird er oder sie unter Umständen bei diesem Konzert nicht auftreten dürfen.
<G-vec00373-002-s060><perform.auftreten><en> A musician who misses more than two rehearsals for the next concert may not be permitted to perform at that concert.
<G-vec00373-002-s061><perform.auftreten><de> Solisten aus den Reihen dieses Chores bilden auch kleine Ensembles, die im Rahmen der Sängerknabenkonzerte, manchmal auch als eigenständige Gruppe auftreten.
<G-vec00373-002-s061><perform.auftreten><en> Soloists who are members of the Men’s Choir also form small ensembles, which perform mostly in concerts by the Boys’ Choir and sometimes also as groups in their own right.
<G-vec00373-002-s062><perform.auftreten><de> Außerdem darf er sich nicht vor den Künstlerinnen des steirischen Theaterkollektivs fürchten, die grundsätzlich in einer Formation auftreten, die eigenen Angaben zufolge einem Geschwader nicht unähnlich ist.
<G-vec00373-002-s062><perform.auftreten><en> Besides, this person ought not to be scared of the artists of the Styrian theatre collective, who, as a matter of principle, claim to perform in a formation that bears resemblance to a squadron.
<G-vec00373-002-s063><perform.auftreten><de> Dass diese Typen erst in ihren Zwanzigern sind und zudem sehr rege live auftreten, lässt auf eine lange und glorreiche Zukunft hoffen.
<G-vec00373-002-s063><perform.auftreten><en> The fact that these guys are only in their twenties and also perform live gives hope for a long and glorious future.
<G-vec00373-002-s064><perform.auftreten><de> Solch eine Chance, bei solch einem Event und das in Bahrain, auftreten zu dürfen, bekommt man vielleicht nur ein Mal im Leben.
<G-vec00373-002-s064><perform.auftreten><en> We know, this is a great possibility and perhaps a once in a lifetime chance to perform at such a great event at such a great location.
<G-vec00373-002-s065><perform.auftreten><de> Als Mitglied dieses Ensembles wirst du mit talentierten jungen Instrumentalisten von überall auf der Welt proben und auftreten und in die faszinierende Welt des Verbier Festivals eintauchen.
<G-vec00373-002-s065><perform.auftreten><en> As a member of this ensemble, you will rehearse and perform alongside talented young instrumentalists from all over the world and plunge into the fascinating Verbier Festival experience.
<G-vec00373-002-s066><perform.auftreten><de> Trotzdem können wir stolz auf uns sein, denn es gibt nicht viele Teams, die hier ein Unentschieden holen und gegen die beste Mannschaft der Welt so auftreten, wie wir es heute getan haben.
<G-vec00373-002-s066><perform.auftreten><en> Honestly, I think that we can be proud because there are few teams who get a draw here and to perform like we did tonight is impressive, against the best team in the world.
<G-vec00373-002-s067><perform.auftreten><de> Ich werde natürlich nicht alleine auftreten, sondern mit meinem langjährigen Musikpartner Aaron McDonald, der ein äußerst vielseitiger Musiker ist.
<G-vec00373-002-s067><perform.auftreten><en> I will of course not perform alone but with my long-time musical companion Aaron MacDonald who is a very versatile musician.
<G-vec00373-002-s068><perform.auftreten><de> Dies ist das einzige Konzert in Polen, während dessen die Freunde der Stiftung auf der Bühne auftreten.
<G-vec00373-002-s068><perform.auftreten><en> This is the only concert in Poland during which the Friends of the Foundation perform on stage.
<G-vec00373-002-s069><perform.auftreten><de> Wenn man sich einmal vor Augen hält, wie zersplittert unsere täglichen Lebensumstände sind, in wie viel tausend Einzelfunktionen wir auftreten; jetzt hier im Moment vor dem Mikrofon, vorher als Trambahnfahrer oder als Geschäftspartner, oder als Familienvater oder Steuerzahler; alles Einzelfunktionen, von denen aus man nie zur eigentlichen Mitte und zum Zentrum und zum eigentlichen Wesen seiner Existenz kommen kann.
<G-vec00373-002-s069><perform.auftreten><en> If you consider the fragmentation of our daily life, the thousands of individual functions we have to perform: now here for the moment in front of the microphone, just before as a tramway passenger or as a business partner, or as the father of a family, or as a taxpayer; all of them different functions, which prevent you from getting to the real center, to the essence of ones existence.
<G-vec00373-002-s070><perform.auftreten><de> Berühmte Menschen werden von vielen gesehen, aber nur zu bestimmten Anlässen, wenn diese Berühmtheiten vor Publikum auftreten.
<G-vec00373-002-s070><perform.auftreten><en> Famous people are seen by many, but only on certain occasions when the celebrities perform in front of audiences.
<G-vec00373-002-s071><perform.auftreten><de> Auf diesen Partys kontaktiert sie nicht nur die vielen Dichter, die auftreten, sondern stellt auch ihre eigene Poesie und Spoken Word vor.
<G-vec00373-002-s071><perform.auftreten><en> At these parties she not only contacts the many poets that perform but performs her own poetry and spoken word as well.
<G-vec00373-002-s072><perform.auftreten><de> Das Schlimmste war, dass sie in engen Anzügen auftreten mussten.
<G-vec00373-002-s072><perform.auftreten><en> The worst thing was that they had to perform in tight-fitting suits.
<G-vec00373-002-s073><perform.auftreten><de> Wir können mit all unseren Berufen nur draußen auftreten.
<G-vec00373-002-s073><perform.auftreten><en> We can just perform outside with all our occupations.
<G-vec00373-002-s074><perform.auftreten><de> Für die Zukunft ist eine Erweiterung des Portfolios um den Bereich Antriebstechnik geplant, um am Markt auch als Systemanbieter auftreten zu können.
<G-vec00373-002-s074><perform.auftreten><en> In future it is planned to extend the portfolio by the field of drive technology to able to perform as system provider.
<G-vec00373-002-s075><perform.auftreten><de> Und Eltern, Kinder und Lehrer warten mit Zittern und Angst auf die Schulferien, an denen die Kinder auftreten.
<G-vec00373-002-s075><perform.auftreten><en> And parents, children, and teachers are waiting with trembling and anxiety for the holidays in the school, at which children will perform.
<G-vec00382-002-s107><underscore.auftreten><de> Eine professionell gestaltete Visitenkarte unterstreicht das seriöse Auftreten einer Firma oder Privatperson gegenüber Kunden, Lieferanten oder möglichen Geschäftspartnern.
<G-vec00382-002-s107><underscore.auftreten><en> Professionally designed business cards underscore the professionalism of a company or private person to their customers, suppliers and future partners.
<G-vec00459-002-s044><recur.auftreten><de> Merkmal des Schmerzsyndroms bei einer solchen Verletzung ist die Tatsache, dass der Schmerz innerhalb von 2-3 Stunden nachlässt und dann wieder auftritt und stärker wird.
<G-vec00459-002-s044><recur.auftreten><en> Feature of the pain syndrome when such injury is the fact that the pain within 2-3 hours, may subside and then recur and become stronger.
<G-vec00006-002-s019><happen.auftreten><de> Kontaminationen können auf verschiedene Arten auftreten, wie durch Husten, Niesen oder Kontakt mit Nasensekret.
<G-vec00006-002-s019><happen.auftreten><en> Contamination can happen in various ways, such as coughing, sneezing or any contact with nasal secretions.
<G-vec00006-002-s020><happen.auftreten><de> Lieferverzögerungen, die während der Beförderung auf dem Postweg von uns zu Ihnen auftreten, befinden sich außerhalb unseres Einflussbereiches, und wir lehnen jede Haftung dafür ab.
<G-vec00006-002-s020><happen.auftreten><en> Delivery delays that happen during the transport by mail are outside of our sphere of influence and we can therefore not be held liable for it.
<G-vec00006-002-s021><happen.auftreten><de> Migräneanfälle können auch auftreten, wenn du mehr als gewohnt schläfst, sich deine Arbeitszeiten ändern oder du einen Jetlag hast.
<G-vec00006-002-s021><happen.auftreten><en> Migraines may also happen when you get more sleep than usual, change your working shifts, or suffer from jet lag.
<G-vec00006-002-s022><happen.auftreten><de> Und all dies muss in bestimmten Phasen in der gewünschten Reihenfolge auftreten.
<G-vec00006-002-s022><happen.auftreten><en> And all this should happen at certain stages and in the necessary sequence.
<G-vec00006-002-s023><happen.auftreten><de> Wenn wir Kunden kontaktieren, versuchen wir, ihre tatsächlichen Bedürfnisse zu kennen und herauszufinden, dass Probleme im Produktionsverfahren auftreten können, damit wir mechanische Anforderungen erfüllen oder sogar die Erwartungen der Kunden übertreffen können.
<G-vec00006-002-s023><happen.auftreten><en> When we contact customers, we try to know their real needs and find out problems may happen in production procedure so that we can achieve mechanical needs or even exceed customers’ expectations.
<G-vec00006-002-s024><happen.auftreten><de> Heisse Füße entstehen, wenn die Hitze im Schuh gestaut wird, was bei unbeweglich Schuhen und schlechtem Schuhmaterial, das nicht atmet, auftreten kann.
<G-vec00006-002-s024><happen.auftreten><en> Hot feet arise when heat accumulates within the shoe, which can happen with immobile shoes of poor material that does not breathe.
<G-vec00006-002-s025><happen.auftreten><de> (3) Hautausschlag: In der Regel können innerhalb von 72 Stunden nach der Impfung leichte Hautausschläge auftreten.
<G-vec00006-002-s025><happen.auftreten><en> (3) Rash: usually within 72 hours after vaccination, minor rashes may happen, in which case
<G-vec00006-002-s026><happen.auftreten><de> Sie helfen auch dabei, die gefürchteten Steckerschäden zu vermeiden, die bei einem HDMI-Stecker auftreten können, wenn das Kabel plötzlich gezogen oder geknickt wird.
<G-vec00006-002-s026><happen.auftreten><en> They also help to prevent the dreaded connector damage that can happen to an HDMI connector when the cable is yanked or bent suddenly.
<G-vec00006-002-s028><happen.auftreten><de> Außerdem können Sie Gerätefehler schnell erkennen und beheben, wenn sie auftreten.
<G-vec00006-002-s028><happen.auftreten><en> Plus, you can quickly identify, and begin to address, unit malfunctions when they happen.
<G-vec00006-002-s029><happen.auftreten><de> Mit den aktuellen Daten in der Hand können Sie aktiv werden und umgehend Probleme in der Fertigung erkennen, ehe diese auftreten.
<G-vec00006-002-s029><happen.auftreten><en> With information in your hands "right now" you become proactive, so you anticipate and solve production problems before they happen.
<G-vec00006-002-s031><happen.auftreten><de> Mischen Sie den Saft von Schöllkraut und Vaseline in einem Verhältnis von 1:2, dieser Mischung reiben Sie die Hände oder die Beine, wo die Krämpfe auftreten.
<G-vec00006-002-s031><happen.auftreten><en> Mix the juice of celandine and vaseline in the ratio 1:2, this mixture to RUB the hands or the feet where the spasms happen.
<G-vec00006-002-s032><happen.auftreten><de> Daher müssen Schrägstellungen und Stöße des Behälters auf dem Weg zum Patienten vermieden werden, die meist bei der Abwicklung am Flughafen auftreten.
<G-vec00006-002-s032><happen.auftreten><en> Therefore, care must be taken to avoid the container being tilted or jolted on the way to the patient, as may usually happen during handling at airports.
<G-vec00006-002-s033><happen.auftreten><de> Was die Datensicherheit angeht, können jederzeit, in jeder Abteilung, bei jedem Datensatz Sicherheitslücken auftreten.
<G-vec00006-002-s033><happen.auftreten><en> And when data security is breached, that breach can happen anytime, to any department, to any set of data.
<G-vec00006-002-s034><happen.auftreten><de> Dieser Geruch kann auftreten, wenn die Teile vor dem Einsetzen in den Philips Avent Sterilisator nicht richtig gereinigt werden.
<G-vec00006-002-s034><happen.auftreten><en> This can happen when the parts are not well cleaned before placing them in the Philips Avent steriliser.
<G-vec00006-002-s035><happen.auftreten><de> Dieses Problem kann auftreten, wenn das Serverauthentifizierungszertifikat auf dem Routing- und RAS-Server abgelaufen ist.
<G-vec00006-002-s035><happen.auftreten><en> Trouble-shooting steps: This can happen if the server authentication certificate is expired.
<G-vec00006-002-s036><happen.auftreten><de> Datenverlust kann aus verschiedenen Gründen auftreten.
<G-vec00006-002-s036><happen.auftreten><en> Data loss can happen due to various reasons.
<G-vec00006-002-s037><happen.auftreten><de> Oberflächenschimmel kann immer noch auftreten, aber er wird nie bis zur Diele selbst durchdringen.
<G-vec00006-002-s037><happen.auftreten><en> Surface mold can still happen, however, it will never penetrate the board itself.
<G-vec00097-002-s043><flare_up.auftreten><de> Vorsatz: Wenn heute bei der Arbeit oder zuhause Widerstände auftreten, werde ich nicht vor Verzweiflung klagen.
<G-vec00097-002-s043><flare_up.auftreten><en> Resolution: Today when contradictions flare up at the workplace or at home, I will not sigh in despair.
<G-vec00097-002-s044><flare_up.auftreten><de> Falls die empfindliche Balance Ihrer Kopfhaut gestört wird, können alle möglichen Probleme auftreten, unter anderem juckende oder trockene Kopfhaut, Schuppen und sogar dünner werdendes Haar.
<G-vec00097-002-s044><flare_up.auftreten><en> Indeed, if the delicate balance of your scalp gets disturbed, it can cause all manner of flare ups from itchy scalp, to flaking dry skin, full blown dandruff and even thinning hair.
<G-vec00097-002-s045><flare_up.auftreten><de> Durch die Verwendung des dreidimensionalen Modells werden Konflikte zwischen den Gewerken oder auch der Ausstattung absehbar, bevor sie bei der Umsetzung auftreten.
<G-vec00097-002-s045><flare_up.auftreten><en> Use of the three-dimensional model makes conflicts between the trades or facilities foreseeable, before they flare up in the realization.
<G-vec00153-002-s627><perform.auftreten><de> Auf diesem Festival treten Schulkinder auf.
<G-vec00153-002-s627><perform.auftreten><en> School children perform at these events.
<G-vec00153-002-s628><perform.auftreten><de> Hier treten regelmäßig nationale und internationale Künstler auf, und es kann zu Jazz, Blues und lateinamerikanische Musik getanzt werden.
<G-vec00153-002-s628><perform.auftreten><en> National and international artists perform here regularly, and you can dance to jazz, blues and latin music.
<G-vec00153-002-s629><perform.auftreten><de> Die Gewinnerinnen und Gewinner erhalten von der Dr. Josef und Brigitte Pauli Stiftung je 1.000 Euro und treten gemeinsam mit dem Orchester der Folkwang Universität der Künste auf.
<G-vec00153-002-s629><perform.auftreten><en> The winners each receive 1,000 Euros from the Dr. Josef and Brigitte Pauli Foundation and perform together with the Folkwang University of the Arts Orchestra.
<G-vec00153-002-s630><perform.auftreten><de> Traditionelle irische Musiker treten in vielen bekannten Bars und Pubs der Stadt auf.
<G-vec00153-002-s630><perform.auftreten><en> Traditional Irish musicians perform in many of the well known bars in the city.
<G-vec00153-002-s631><perform.auftreten><de> In der Lanxess Arena und auf anderen Bühnen treten internationale Stars aus Musik und Sport auf.
<G-vec00153-002-s631><perform.auftreten><en> International music and sports stars perform at the Lanxess Arena and on other stages.
<G-vec00153-002-s632><perform.auftreten><de> Es treten täglich Musiker ab 22 Uhr auf.
<G-vec00153-002-s632><perform.auftreten><en> Every day musicians perform from 10 p.m.
<G-vec00153-002-s633><perform.auftreten><de> Die Musiker der Wiener Philharmoniker treten in jeder Saison circa 300 Mal in ihrer Eigenschaft als Orchester der Wiener Staatsoper im Haus am Ring auf.
<G-vec00153-002-s633><perform.auftreten><en> Every year the musicians of the Vienna Philharmonic perform here on nearly 300 evenings in their capacity as the Vienna State Opera Orchestra.
<G-vec00153-002-s634><perform.auftreten><de> Die Funland Serenaders haben hier ihre Heimat gefunden, aber auch andere Bands aus der ganzen Welt, natürlich auch aus Trinidad, treten hier in regelmäßigen Abständen auf.
<G-vec00153-002-s634><perform.auftreten><en> The Funland Serenaders are the house band, but also other bands from the whole world, including Trinidad, perform here in regular intervals.
<G-vec00153-002-s635><perform.auftreten><de> Wir treten 30 mal auf, liegen zuerst rechts, dann links.
<G-vec00153-002-s635><perform.auftreten><en> We perform 30 times, lying first on the right, then on the left side.
<G-vec00153-002-s636><perform.auftreten><de> Namhafte Künstler - Sänger, Tänzer und Musiker - treten hier in regelmäßig wechselnden Shows auf.
<G-vec00153-002-s636><perform.auftreten><en> The show changes about every 2-3 months, well-known artists - singers, dancers and musicians - perform here.
<G-vec00153-002-s637><perform.auftreten><de> Häufig treten bei „Rose Kennedy“ zudem Live-Acts auf.
<G-vec00153-002-s637><perform.auftreten><en> Live acts often also perform at the Rose Kennedy.
<G-vec00153-002-s638><perform.auftreten><de> Wir treten auf bei Firmen, auf Messen, bei Festen...
<G-vec00153-002-s638><perform.auftreten><en> We perform for companies, on fairs, at parties...
<G-vec00153-002-s639><perform.auftreten><de> Diese treten in Frankreich, der Schweiz und Israel auf und werden bald in Griechenland und Kroatien uraufgeführt.
<G-vec00153-002-s639><perform.auftreten><en> These perform in France, Switzerland, Israel, and soon premiering in Greece and Croatia.
<G-vec00153-002-s640><perform.auftreten><de> Alle Teilnehmenden treten in der ersten Wettbewerbswoche zweimal auf.
<G-vec00153-002-s640><perform.auftreten><en> During the first week of competition, all participants perform twice.
<G-vec00153-002-s641><perform.auftreten><de> Während der Sommermonate treten sie häufig in der Innenstadt auf und präsentieren den Bürgern und Gästen so die traditionelle Folklore und andere ethnografische Inhalte.
<G-vec00153-002-s641><perform.auftreten><en> In summer, these cultural and artistic associations often perform in the town centre and thus offer a display of customary lore to both locals and guests.
<G-vec00153-002-s642><perform.auftreten><de> In diesem Konzert treten sie nacheinander auf.
<G-vec00153-002-s642><perform.auftreten><en> In this concert, they will perform back-to-back.
<G-vec00153-002-s643><perform.auftreten><de> Sie treten in Gesprächssituationen auf, wie zum Beispiel bei Führungen, Messebesuchen, Verhandlungen oder bei der Bestätigung von Dokumenten.
<G-vec00153-002-s643><perform.auftreten><en> They perform their services in situations in which conversations are necessary, such as tours, trade show visits, negotiations or the execution of deeds.
<G-vec00153-002-s644><perform.auftreten><de> Seit der Gründung im Millenniums-Jahr 2000 und danach regelmäßig ab 2002 treten an einem Wochenende im Juli auf einem der prachtvollsten Plätze Europas zwei Top-Orchester Münchens mit weltberühmten Klassikkünstlern auf.
<G-vec00153-002-s644><perform.auftreten><en> Since its foundation in the millennium year 2000 and since 2002 in regular terms, two of Munich's star orchestras perform together with internationally renowned classical music artists at one of the most beautiful sites in Europe one weekend in July.
<G-vec00153-002-s645><perform.auftreten><de> Über hundert Vertreter diverser Musikrichtungen – Bluegrass, Blues, Rock, Country, Dixieland, Zydeco – treten auf bis zu sieben Bühnen gleichzeitig auf.
<G-vec00153-002-s645><perform.auftreten><en> More than 100 artists from assorted genres—bluegrass, blues, rock, country, Dixieland, zydeco—perform on up to six stages simultaneously.
<G-vec00785-002-s063><aggravate.auftreten><de> Zur Verschlimmerung der Situation kann manchmal eine gewöhnliche Erkältung auftreten.
<G-vec00785-002-s063><aggravate.auftreten><en> To aggravate the situation can sometimes an ordinary cold.
