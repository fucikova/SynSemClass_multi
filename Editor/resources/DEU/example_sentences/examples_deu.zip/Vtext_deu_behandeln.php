<G-vec00301-001-s342><address.behandeln><de> Deshalb wird hinter der Konsultation an den Arzt besser sofort behandeln.
<G-vec00301-001-s342><address.behandeln><en> Therefore better at once will address for consultation to the doctor.
<G-vec00301-001-s343><address.behandeln><de> Kostet auch, viel zu oft zu behandeln am Arzt nicht.
<G-vec00301-001-s343><address.behandeln><en> Is not necessary also, too often to address to the doctor.
<G-vec00301-001-s344><address.behandeln><de> Deshalb muss man zu behandeln an der Fachkraft nicht fürchten, die Sie zu schätzen lehren wird und, sich gern zu haben, von den eigenen Träumen zu leben und, die harmonischen Beziehungen zu schaffen, in die jeder Partner ebensoviel bekommt, gibt wieviel zurück.
<G-vec00301-001-s344><address.behandeln><en> Therefore it is not necessary to be afraid to address to the expert who will teach you to appreciate and to love itself, to live own dreams and to create the harmonious relations in which each partner receives as much, how many gives.
<G-vec00301-001-s345><address.behandeln><de> Mit der Unterstützung dieser Experten sind wir dann in der Lage, dieses wichtige Thema zu behandeln und Lieferanten, Arbeiter und Gemeinden über die Wichtigkeit der Bildung für Kinder aufzuklären.
<G-vec00301-001-s345><address.behandeln><en> With their support we are able to address this important issue and educate suppliers, workers and communities on the importance of education for children.
<G-vec00301-001-s346><address.behandeln><de> Und wenn der Bräutigam und die Braut wirkungsvoll wünschen werden, neben dem Standesamt auf der Limousine zu erscheinen, so muss man im Voraus in den Dienst des Verleihs behandeln und, Bestellung machen, vorläufig es bezahlt und alle Details vereinbart.
<G-vec00301-001-s346><address.behandeln><en> And if the groom and the bride wish to appear effectively near the REGISTRY OFFICE on a limousine, it is necessary to address to service of hire in advance and to make the order, previously having paid it and having coordinated all details.
<G-vec00301-001-s347><address.behandeln><de> Die Werke der Ausstellung behandeln Exil, Migration und das neue Europa.
<G-vec00301-001-s347><address.behandeln><en> The works of the exhibition address refugee status, immigration and the new Europe.
<G-vec00301-001-s348><address.behandeln><de> Sie gibt einen Überblick über die REACH- und CLP-Verfahren, die besorgniserregende Stoffe behandeln und ihre Auswirkungen auf nachgeschaltete Anwender.
<G-vec00301-001-s348><address.behandeln><en> It gives an overview of the REACH and CLP regulatory processes that address substances of concern and of their impacts on downstream users.
<G-vec00301-001-s349><address.behandeln><de> So müssen die Bürger von GUS nur in territorial UFMS nach der Stelle der Arbeitsbeschaffung behandeln, in andere Migrationsorgane behandeln es muss nicht.
<G-vec00301-001-s349><address.behandeln><en> So, citizens of the CIS need to address only in territorial the Office of the Federal Migration Service in an employment place, it is not necessary to address to other migratory bodies.
<G-vec00301-001-s351><address.behandeln><de> Wir behandeln an jene Menschen, die geschaffen haben, die hellen sowjetischen Traditionen der Neujahrsfeiertage aufzusparen, haben die Baumschmucke der Urgroßmütter nicht hinausgeworfen, mögen «die Ironie des Schicksals», die lebendigen Tannen und essen oliwje und den Hering unter dem Pelz gern.
<G-vec00301-001-s351><address.behandeln><en> "We address to those people who managed to keep light Soviet traditions of New Year's holidays, did not throw out Christmas-tree decorations of the great-grandmothers, love ""Twist of fate"", live fir-trees and with pleasure eat Russian salad and herring under a fur coat."
<G-vec00301-001-s352><address.behandeln><de> Die vier Arbeiten von Farocki behandeln Trainingsmethoden des US Militärs und den computerunterstützten Umgang mit posttraumatischen Belastungsstörungen.
<G-vec00301-001-s352><address.behandeln><en> The four works by Farocki address training methods by the U.S. military and computer-based support of soldiers affected by post-traumatic stress disorder.
<G-vec00301-001-s353><address.behandeln><de> Daraus erarbeitete Vladimir mit den 34 Teilnehmenden aus sechs europäischen Staaten Lehransätze, die verschiedene kulturelle Hintergründe berücksichtigen und behandeln.
<G-vec00301-001-s353><address.behandeln><en> During these workshops, Vladimir and the 34 participants from six European states developed approaches to teaching that take account of and address a variety of cultural backgrounds.
<G-vec00301-001-s354><address.behandeln><de> Wenn die Luftphobie nicht zurücktritt, kann man mit der Fachkraft behandeln.
<G-vec00301-001-s354><address.behandeln><en> If the aero phobia does not recede, it is possible to address with the expert.
<G-vec00301-001-s355><address.behandeln><de> Bei dem Entstehen dieser Erkrankung ist empfohlen, an den Arzt zu behandeln, der für Sie die Diät individuell auswählen kann.
<G-vec00301-001-s355><address.behandeln><en> When developing this disease we recommend to address to the doctor who will be able individually to pick up for you a diet.
<G-vec00301-001-s356><address.behandeln><de> In diesem Fall messen Sie dem Hund Fieber auch als es nach schneller möglich ist behandeln an den Tierarzt.
<G-vec00301-001-s356><address.behandeln><en> In this case take a dog temperature and as it is possible after rather address to the veterinarian.
<G-vec00301-001-s357><address.behandeln><de> Leider können wir nicht alle Einzelheiten und Besonderheiten des New Yorker Immobilienmarktes auf einer einzigen Seite behandeln; wir kümmern uns aber gerne um Ihre individuellen Bedürfnisse, beantworten all Ihre Fragen bezüglich Vermietung, An- und Verkauf von Immobilienobjekten in New York und bieten Ihnen unseren umfassenden professionellen Beistand an, wenn es um die Abwicklung Ihrer Immobilientransaktion geht.
<G-vec00301-001-s357><address.behandeln><en> Unfortunately, we cannot address all the nuances and peculiarities of the New York real estate market in one page; however we will be happy to address your individual needs, answer any questions about renting, buying or selling a property in New York and offer our professional guidance through the entire process.
<G-vec00301-001-s358><address.behandeln><de> Das formalisierte und strukturierte System der Ziele habend, kann man an die Lieferanten der Lösungen mit den vollkommen konkreten Fragen behandeln.
<G-vec00301-001-s358><address.behandeln><en> Having the formalized and structured system of the purposes, it is possible to address to suppliers workflow decisions with quite concrete questions.
<G-vec00301-001-s359><address.behandeln><de> Sofort beginnen Sie die Abkühlung vom kalten Wasser im Laufe von 10-15 Minuten, und unbedingt behandeln an den Arzt.
<G-vec00301-001-s359><address.behandeln><en> At once begin cooling by cold water within 10-15 minutes, and necessarily address to the doctor.
<G-vec00301-001-s360><address.behandeln><de> Behandeln an den Arzt, der jene Medikamente unbedingt ausschreiben wird, die zu Ihrem Inhalationsapparat herankommen werden.
<G-vec00301-001-s360><address.behandeln><en> Address to the doctor who will surely write out those drugs which will approach your inhaler.
<G-vec00301-001-s133><deal.behandeln><de> Diese bemerkenswerte Hydropumpe ist für eine Vielzahl von Funktionen für Männer, die mit erektiler Dysfunktion behandeln.
<G-vec00301-001-s133><deal.behandeln><en> This remarkable hydro pump is designed for numerous functions for men who deal with erectile dysfunction.
<G-vec00301-001-s134><deal.behandeln><de> Components-Center.com ist verantwortlich für technische Unterstützung stellen Sie sicher, dass die Website in der Arbeit Ordnung, Versuchen Sie, Service-Unterbrechung zu vermeiden, oder Interrupt Zeitlimit in der kürzesten Zeit, stellen Sie sicher, dass Benutzer auf Internet reibungslos zu behandeln.
<G-vec00301-001-s134><deal.behandeln><en> Components-Center.com is accountable to offer technical support make sure the website in working order, Try to avoid service interruption, or Interrupt time limit in the shortest time, make sure user can deal on internet smoothly.
<G-vec00301-001-s135><deal.behandeln><de> Außerdem, Sie haben mit Tausenden von Fragen im Zusammenhang mit Versand im Zusammenhang zu behandeln, Lieferung, Produktrücknahme-, Kundenanfragen, Produkt Streitigkeiten, und so weiter und so fort.
<G-vec00301-001-s135><deal.behandeln><en> Besides, you have to deal with thousands of issues related to shipping, delivery, product return, customer queries, product disputes, so on and so forth.
<G-vec00301-001-s136><deal.behandeln><de> Die Anavar ist ein populärer Name von Steroiden mit der Schwächung der Knochen zu behandeln.
<G-vec00301-001-s136><deal.behandeln><en> The Anavar is a preferred name of steroids to deal with the weakening of bones.
<G-vec00301-001-s137><deal.behandeln><de> Obwohl für das anhängige Beschwerdeverfahren nur festgestellt werden muss, welcher Standard bei der Prüfung dieses Typs richtigerweise anzuwenden ist, hält die Große Beschwerdekammer es für angebracht, in der vorliegenden Entscheidung alle Typen von nicht offenbarten Disclaimern zu behandeln und insbesondere den oder die Standards für deren Prüfung klarzustellen.
<G-vec00301-001-s137><deal.behandeln><en> Although for the appeal proceedings before the referring board only the proper standard for examining this type needs to be determined, the Enlarged Board considers it appropriate, in the present decision, to deal with, and in particular to clarify the standard(s) for examining, all types of undisclosed disclaimers.
<G-vec00301-001-s138><deal.behandeln><de> So, Kamagra Jelly ist ein echter trostlos für Männer gewesen zu behandeln mit der schwierigen Nacht Stunden.
<G-vec00301-001-s138><deal.behandeln><en> So, Kamagra jelly has been a real bleak for men to deal with the difficult overnight hours.
<G-vec00301-001-s139><deal.behandeln><de> Herbert Spohn erhält die Medaille für seine Leistungen in der statistischen Physik, die den Übergang von mikroskopischen zu makroskopischen Phänomenen behandeln.
<G-vec00301-001-s139><deal.behandeln><en> Herbert Spohn receives the medal for his achievements in statistical physics, which deal with the transition from microscopic to macroscopic phenomena.
<G-vec00301-001-s140><deal.behandeln><de> Diese Kündigungskommission muss innerhalb von 30 Tage nach Empfang einer Beantragung diese Voraussetzungen behandeln.
<G-vec00301-001-s140><deal.behandeln><en> The Discharge Committee has to deal with the requirements within 30 days of receiving the request.
<G-vec00301-001-s141><deal.behandeln><de> Diese Dinge sind alle wunderbar in einer echten Klemme oder als hin und wieder behandeln, aber Sie werden in der Lage zu wohnen to't aus ihnen sein.
<G-vec00301-001-s141><deal.behandeln><en> These things are all wonderful in a real pinch or as a now and again deal with, however you'll be able to't dwell off them.
<G-vec00301-001-s142><deal.behandeln><de> Der nächste EU-Bericht zum Sozialschutz und zur sozialen Eingliederung, der unter der österreichischen Präsidentschaft erstellt werden soll, wird diesen wichtigen Bereich jedoch bereits ebenfalls behandeln.
<G-vec00301-001-s142><deal.behandeln><en> The next EU report on social protection and social inclusion, which is to be tabled under the Austrian Presidency, will also deal with this important area.
<G-vec00301-001-s143><deal.behandeln><de> Mit Bischof Müller ist man der Ansicht, die Stellungnahme erwecke den Eindruck, der Gesprächskreis könne mit kirchlicher Verbindlichkeit ein theologisches Thema behandeln, dessen Klärung dem kirchlichen Lehramt vorbehalten ist.
<G-vec00301-001-s143><deal.behandeln><en> With Bishop Müller one is of the opinion the statement gave the impression that the discussion group was able in an obligatory way to deal with a theological topic the clarifying of which is reserved to the teaching authority of the church.
<G-vec00301-001-s144><deal.behandeln><de> Die Anavar ist ein bevorzugter Name von Steroiden mit der Osteoporose zu behandeln.
<G-vec00301-001-s144><deal.behandeln><en> The Anavar is a preferred name of steroids to deal with the weakening of bones.
<G-vec00301-001-s145><deal.behandeln><de> 6.Ebenso ist es ihre Aufgabe, die Fragen zur Auflösung von Ehen zugunsten des Glaubens (Privilegium fidei) rechtlich und sachlich zu behandeln.
<G-vec00301-001-s145><deal.behandeln><en> 6. Likewise it is its duty to deal legally or in fact with questions regarding the privilege of faith.
<G-vec00301-001-s146><deal.behandeln><de> Dies ist ein Produkt mit natürlichen Zutaten, die Sie behandeln und korrekte Brust-Vergrößerung in männlichen bekannt als Gynäkomastie helfen.
<G-vec00301-001-s146><deal.behandeln><en> This is an item developed with natural active ingredients to assist you deal with and fix bust augmentation in male known as Gynecomastia.
<G-vec00301-001-s147><deal.behandeln><de> Unsere Vorschläge haben drei Hauptziele: die Energieeffizienz als oberste Priorität zu behandeln, die weltweite Führung im Bereich der erneuerbaren Energien zu übernehmen und ein faires Angebot für die Verbraucher bereitzustellen.
<G-vec00301-001-s147><deal.behandeln><en> Today's proposals have three main goals: putting energy efficiency first, achieving global leadership in renewable energies and providing a fair deal for consumers.
<G-vec00301-001-s148><deal.behandeln><de> Nachdem die gesamte Stil festgelegt haben, gibt es viele Details zu behandeln, die wir sorgfältig prüfen müssen, nicht sagen, ein wenig Zeit, zurückzukommen und her mehr Mühe, weil das Design ist in der Regel eine Menge Leute, zur gleichen Zeit zu entwerfen.
<G-vec00301-001-s148><deal.behandeln><en> After the overall style set, there are many details to deal with, which requires us to carefully review, do not say a little time to come back and forth more trouble, because the design is usually a lot of people to design at the same time.
<G-vec00301-001-s149><deal.behandeln><de> Die Verwendung von 100% natürlichen Wirkstoffen hilft bei den ungünstigen Nebenwirkungen zu behandeln, die durch synthetische Formen der anabolen Anabolika wie Lebertoxizität oder überschüssiges Östrogen verursacht werden.
<G-vec00301-001-s149><deal.behandeln><en> The use of 100% natural active ingredients helps to deal with the unfavorable side effects that are caused by synthetic forms of the anabolic Anabolic Steroids like liver toxicity or excess estrogen.
<G-vec00301-001-s150><deal.behandeln><de> Sittlich verantwortete Güterabwägung, Menschen können eigentlich immer nur drei Gedanken parallel behandeln.
<G-vec00301-001-s150><deal.behandeln><en> Basically, humans can only deal with three ideas at one time.
<G-vec00301-001-s151><deal.behandeln><de> Das morgige zweite Treffen der NATO-Ukraine-Kommission auf Verteidigungsministerebene wird umfassende Vorschlge der Ukraine zur weiteren Umsetzung der NATO-Ukraine-Charta behandeln.
<G-vec00301-001-s151><deal.behandeln><en> The second meeting of the NATO-Ukraine Commission at the level of Defence Ministers tomorrow will deal with substantial Ukrainian proposals for the further implementation of the NATO-Ukraine Charter.
<G-vec00057-001-s038><discuss.behandeln><de> Seine Arbeiten zur Antike gelten als innovativ, sie behandeln Themen wie Wut und Zorn bei Homer, umfassen Neueditionen griechischer Philosophen oder stellen in seiner Disziplin beachtete methodische Reflektionen an.
<G-vec00057-001-s038><discuss.behandeln><en> His studies on Antiquity are innovative, they discuss subjects like anger and furor in Homer, cover new editions of Greek philosophers or consider methodological reflections within his field.
<G-vec00057-001-s039><discuss.behandeln><de> In diesem Artikel behandeln wir die 12 Phasen eines Burn-Outs, sowie der Psychologe Herbert Freudenberger beschreibt.
<G-vec00057-001-s039><discuss.behandeln><en> In this article, we will discuss the 12 phases of a burnout, as described by psychologist Herbert Freudenberger.
<G-vec00057-001-s040><discuss.behandeln><de> Denn der Vater hat seinen Sitz im rechten Herzen, und wenn das Prinzip der Vaterschaft gestört ist, wenn es ein Problem mit dem Prinzip der Vaterschaft gibt, bekommt man dieses Problem und noch viele weitere, die Ich jetzt nicht ausführlich behandeln will.
<G-vec00057-001-s040><discuss.behandeln><en> Because father resides in the Right Heart, and the principle of fatherhood, if it is spoilt, if there is a problem with the principle of fatherhood, then you get this problem and many other problems ah which I do not want to discuss now at length.
<G-vec00057-001-s041><discuss.behandeln><de> Da adrenaler Krebs verhältnismäßig selten ist, kann es lohnend sein, mit anderen endokrinen Spezialisten zusammenzuarbeiten, um die besten Behandlungsmöglichkeiten fÃ1⁄4r den besonderen Fall zu behandeln.
<G-vec00057-001-s041><discuss.behandeln><en> As adrenal cancer is relatively rare, it can be worthwhile to collaborate with other endocrine specialists to discuss the best treatment options for the particular case.
<G-vec00057-001-s042><discuss.behandeln><de> Tritt zwischen dem Parteikomitee und der Fraktion eine wesentliche Meinungsverschiedenheit über eine Frage auf, die in die Zuständigkeit der Fraktion gehört, so ist das Komitee verpflichtet, diese Frage ein zweites Mal mit den Vertretern der Fraktion zu behandeln und einen endgültigen Beschluß zu fassen, den die Fraktion unverzüglich durchzuführen hat.
<G-vec00057-001-s042><discuss.behandeln><en> In case there is an essential disagreement between the party committee and the fraction concerning some question which is within the jurisdiction of the latter, the committee is obliged to discuss the question of a second time with the representatives of the fraction and to adopt a final decision which must be carried out at once by the fraction.
<G-vec00057-001-s043><discuss.behandeln><de> Weil es auf die Person ankommt, die uns belehrt, behandeln die Texte die Qualifikation solch einer Person.
<G-vec00057-001-s043><discuss.behandeln><en> Because the person who teaches us is important, the texts discuss such a person's qualifications.
<G-vec00057-001-s044><discuss.behandeln><de> Wir haben bei Europäische Geschichte Online gesagt, um von Transfergeschichte oder transferts culturels zu sprechen, müssen alle Beiträge Akteure behandeln, Mittler und Agenten.
<G-vec00057-001-s044><discuss.behandeln><en> In European History Online, we said that in order to speak of transfer history or transferts culturels all of the articles must discuss the historical actors, the intermediaries and the agents of transfer.
<G-vec00057-001-s045><discuss.behandeln><de> Die folgenden Abschnitte behandeln ausführlich die Bedienung der angesprochenen Anwendungen.
<G-vec00057-001-s045><discuss.behandeln><en> The following sections discuss in detail the operation of the applications mentioned above.
<G-vec00057-001-s046><discuss.behandeln><de> Wir planen, diese Projekte in naher Zukunft zu behandeln.
<G-vec00057-001-s046><discuss.behandeln><en> We plan to discuss these projects in the near future.
<G-vec00057-001-s047><discuss.behandeln><de> "Das zweite Projekt, das ich eingehender behandeln möchte, ist ""Droit de cité"" (ein französisches Wortspiel, das sowohl das Recht, jemanden zu zitieren, als auch ""Bürgerrecht"" bedeutet)."
<G-vec00057-001-s047><discuss.behandeln><en> "The second project I would like to discuss is ""Droit de cité"" (a play on words in French meaning both ""right of quotation"" and ""right of citizenship"")."
<G-vec00057-001-s048><discuss.behandeln><de> Die folgenden Bcher behandeln verschiedene Themen der Wiederherstellung nach Katastrophen und sind eine gute Ressource fr Red Hat Enterprise Linux-Systemadministratoren.
<G-vec00057-001-s048><discuss.behandeln><en> The following books discuss various issues related to disaster recovery, and are good resources for Red Hat Enterprise Linux system administrators:
<G-vec00057-001-s049><discuss.behandeln><de> Daher werde ich beide WM gleichzeitig behandeln um ihre Gemeinsamkeiten aufzuzeigen.
<G-vec00057-001-s049><discuss.behandeln><en> So I will discuss both window managers to see their similarities.
<G-vec00057-001-s050><discuss.behandeln><de> Red Hat Linux Security and Optimization von Mohammed J. Kabir; Red Hat Press — Ungefhr die ersten 150 Seiten dieses Buches behandeln leistungsbezogene Themen.
<G-vec00057-001-s050><discuss.behandeln><en> Red Hat Linux Security and Optimization by Mohammed J. Kabir; Red Hat Press — Approximately the first 150 pages of this book discuss performance-related issues.
<G-vec00057-001-s051><discuss.behandeln><de> Deshalb ist es mein erster Vorschlag an diejenigen, die schreiben und Themen behandeln: Laßt uns unabhängig (darin) sein, wie wir Freiheit verstehen.
<G-vec00057-001-s051><discuss.behandeln><en> Accordingly my first suggestion to those who write and discuss issues is that, let us be independent in our understanding of freedom.
<G-vec00057-001-s052><discuss.behandeln><de> Auch das Abendmahl werden wir kurz behandeln.
<G-vec00057-001-s052><discuss.behandeln><en> We will also briefly discuss the Lord's Supper.
<G-vec00057-001-s053><discuss.behandeln><de> Sonderthema: In jeder Ausgabe behandeln wir ein aktuelles Sonderthema welches tagesaktuelle Entwicklungen oder Entscheidungen reflektiert.
<G-vec00057-001-s053><discuss.behandeln><en> Special issue: In each issue we discuss a topic that is highly relevant given current market developments and policy.
<G-vec00057-001-s054><discuss.behandeln><de> Ein neues Gesetz im US-Bundesstaat Tennessee erlaubt es Lehrern, neben der Evolutionstheorie auch den Kreationismus im Schulunterricht zu behandeln, schreibt Casey Selwyn.
<G-vec00057-001-s054><discuss.behandeln><en> YouTube (9) Teaching creationism in US schools A new Tennessee law will permit teachers to discuss creationism alongside theories of evolution, writes Casey Selwyn.
<G-vec00057-001-s055><discuss.behandeln><de> Die ursprünglichen Zeitungsartikel und das vorliegende Buch haben nur das gemein, daß beide den gleichen Stoff behandeln.
<G-vec00057-001-s055><discuss.behandeln><en> The only point in common between the original newspaper articles and this book is that both discuss the same subject.
<G-vec00057-001-s056><discuss.behandeln><de> Zu einem späteren Zeitpunkt in diesem Artikel werden wir Links der neuen Generation behandeln.
<G-vec00057-001-s056><discuss.behandeln><en> Later in this article, we discuss the generation of new links.
<G-vec00301-001-s046><discuss.behandeln><de> Wir planen, diese Projekte in naher Zukunft zu behandeln.
<G-vec00301-001-s046><discuss.behandeln><en> We plan to discuss these projects in the near future.
<G-vec00301-001-s133><handle.behandeln><de> Ich appelliere an alle Regierungsebenen und Kader, meinen Fall zu behandeln.
<G-vec00301-001-s133><handle.behandeln><en> I ask all levels of governments and all levels of cadres to handle my case.
<G-vec00301-001-s134><handle.behandeln><de> Zu diesem Zeitpunkt werden wir sehen, wie die Gefangenen gelingt, ihre Gefühle von Wut und mit seinem Leben hinter Gittern zu bewältigen versucht zu behandeln.
<G-vec00301-001-s134><handle.behandeln><en> At this time we will see how the prisoners manage to handle their feelings of anger and trying to cope with his life behind bars.
<G-vec00301-001-s135><handle.behandeln><de> Die Kombination für 11 Schüsse der Canadiens '34 Schüsse, die die drei Stürmer bewies viel zu schwer, für einen Verein, der sich in erster Linie auf ihre Gegner einzuschüchtern mit ihrer Größe und Körperlichkeit ist stolz zu behandeln.
<G-vec00301-001-s135><handle.behandeln><en> Combining for 11 shots of the Canadiens’ 34 shots, containing the three forwards proved far too hard to handle for a club that prides itself primarily on intimidating their opponents with their size and physicality.
<G-vec00301-001-s136><handle.behandeln><de> Um den Server mitzuteilen, wie er eingehende und abzuschickende News zu behandeln hat, muss man die Datei neewsfeeds konfigurieren.
<G-vec00301-001-s136><handle.behandeln><en> To teach the server how it could handle incoming and outgoing news you have to configure the file newsfeeds.
<G-vec00301-001-s137><handle.behandeln><de> Die meisten großen Cloud-Services integriert werden, sodass keine Rolle, wie Sie Ihren Workflow ausgelegt ist, kann Quickoffice es in Kauf zu behandeln.
<G-vec00301-001-s137><handle.behandeln><en> Most major cloud services are integrated, so not matter how your workflow is designed, Quickoffice can handle it in stride.
<G-vec00301-001-s138><handle.behandeln><de> Sofort machte sich der Kellner daran, Delamarche zu untersuchen, der ihm schwieriger zu behandeln schien, als Robinson, den er Karl überließ.
<G-vec00301-001-s138><handle.behandeln><en> Right away the waiter got to examining Delamarche, who seemed harder to handle than Robinson, whom he left over for Karl.
<G-vec00301-001-s139><handle.behandeln><de> Wir behandeln ihre buchhaltung und finanzen, organisieren und steuern alle finanziellen informationen, schätzt aller steuern, rtn, isv, ihss lohn, sozialleistungen usw.
<G-vec00301-001-s139><handle.behandeln><en> We handle your business accounting and finance, organize and control all financial information, estimates of all taxes, rtn, isv, ihss payroll, benefits etc.
<G-vec00301-001-s140><handle.behandeln><de> Im Gegensatz zu Winterstecklinge ist Sommer Stecklinge sind nicht in Ruhe, aber weiterhin zu schwitzen und aktiv sein, wenn sie von der Mutterpflanze geschnitten, wodurch es ein wenig schwieriger, sie zu behandeln.
<G-vec00301-001-s140><handle.behandeln><en> Unlike winter cuttings is summer cuttings are not in resting, but continues to perspire and be active when they have cut off the mother plant, which makes it a little trickier to handle them.
<G-vec00301-001-s141><handle.behandeln><de> Unser klassische Leistung V-Ausschnitt hat wesentliche Technologien zu behandeln, was auch immer Ihr nächster Angelausflug auf dich werfen.
<G-vec00301-001-s141><handle.behandeln><en> Our classic performance tee has essential technologies to handle whatever your next fishing trip throw at you.
<G-vec00301-001-s142><handle.behandeln><de> "Hier muss man Austern wie in einem Grafikprogramm mit verschiedenen Werkzeugen behandeln, während eine Stimme ständig ""We are going to the Opera"" singt."
<G-vec00301-001-s142><handle.behandeln><en> "Here, one has to handle oysters with various tools, like in a graphics program, while a voice continually sings ""We are going to the Opera""."
<G-vec00301-001-s143><handle.behandeln><de> Sie haben ein Problem vorzeitige Ejakulation, weil Ihr Körper hat nicht gelernt, wie man hohe sexuelle Erregung, ohne reagiert mit einer Ejakulation zu behandeln.
<G-vec00301-001-s143><handle.behandeln><en> You have a premature ejaculation problem because your body has not learned how to handle high sexual arousal without responding with an ejaculation.
<G-vec00301-001-s144><handle.behandeln><de> """Wir behandeln Fehlverhalten, Sünde und Übertretung"", sagt er."
<G-vec00301-001-s144><handle.behandeln><en> """We handle wrongdoing, sin, and transgression,"" he says."
<G-vec00301-001-s145><handle.behandeln><de> Meine aktuellen Kunden sind besser im Vergleich zu immer mit meiner Arbeit, und ich habe eigentlich auch einmal in der Lage gewesen brandneue Kunden ohne zusätzlichen Stress und Angst zu behandeln.
<G-vec00301-001-s145><handle.behandeln><en> My current clients are better compared to ever with my work, and I have actually also even been able to handle brand-new clients without any added stress and anxiety.
<G-vec00301-001-s146><handle.behandeln><de> Behandeln Sie Ihr Gerät, Akku, Ladegerät und Zubehör mit Sorgfalt.
<G-vec00301-001-s146><handle.behandeln><en> Handle your device, battery, charger and accessories with care.
<G-vec00301-001-s147><handle.behandeln><de> Der Körper geht durch eine Anzahl von natürlichen Stadien, um externe Angriffe als Teil des Immunprozesses zu behandeln.
<G-vec00301-001-s147><handle.behandeln><en> The body goes through a number of natural stages to handle external attacks as part of the immune process.
<G-vec00301-001-s148><handle.behandeln><de> Da diese Medizinen bereitwillig durch die Haut absorbiert werden, sollten Frauen, die sind oder möglicherweise sollten sie nicht behandeln schwanger werden und wenn sie in Kontakt mit undichten Kapseln kommen, das Kontaktgebiet sofort im Seifenwasser gewaschen werden.
<G-vec00301-001-s148><handle.behandeln><en> Since these medications are readily absorbed through the skin, women who are or may become pregnant should not handle them and if they come into contact with leaking capsules, the contact area should be washed immediately in soapy water.
<G-vec00301-001-s149><handle.behandeln><de> So behandeln Sie ähnliches Bild Verlust Situationen, benötigen Sie eine robuste wiederherzustellung Werkzeug zu haben, wie Remo bilder wiederherstellen software das dient als Komplettlösung für alle Ihre Medien-Datei wiederherzustellung-Anforderungen.
<G-vec00301-001-s149><handle.behandeln><en> To handle similar photo loss situations, you need to have a robust recovery tool like Remo Photo Recovery software which acts as a complete solution to all your media file recovery needs.
<G-vec00301-001-s150><handle.behandeln><de> Mein Laden ist immer voll von Kunden und wie Sie sich vorstellen können, sind sie Bräute, die schwer zu behandeln sind.
<G-vec00301-001-s150><handle.behandeln><en> My store is always full of customers and as you can guess they are brides who are tough to handle.
<G-vec00301-001-s151><handle.behandeln><de> Und selbst wenn einige von uns behandeln zu pflegen werde, ist das Gewicht Schuppen meist Wasser Gewicht, das wir schnell zu erwerben zurück.
<G-vec00301-001-s151><handle.behandeln><en> And even if a few of us do handle to maintain going, the weight lost is mostly water weight which we gain back swiftly.
<G-vec00301-001-s152><handle.behandeln><de> "Der Leiter der Gruppe für diesen speziellen Fall sagte: ""Behandelt He Xuejian als unmündigen Straftäter""."
<G-vec00301-001-s152><handle.behandeln><en> "The head of the Special Case Group said, """"Handle He Xuejian as a minor offender."""
<G-vec00301-001-s153><handle.behandeln><de> Dafür ist aber ein externer Mechanismus erforderlich, welcher Failover und Lastverteilung für die Client-Seite (den Browser) transparent behandelt.
<G-vec00301-001-s153><handle.behandeln><en> For this, an external mechanism is required to handle failover and load balancing transparent to the client side, the browser.
<G-vec00301-001-s154><handle.behandeln><de> Spezielle Services ANA behandelt Ihr Haustier mit größter Sorgfalt, sodass die Reise so komfortabel wie möglich verläuft.
<G-vec00301-001-s154><handle.behandeln><en> ANA will handle your pet with the utmost care so that it can travel as comfortably as possible.
<G-vec00301-001-s155><handle.behandeln><de> Sie behandelt die Argumente, die der Anwender an den Kernel-Teil weiterleiten will.
<G-vec00301-001-s155><handle.behandeln><en> It will handle the arguments the user want the kernel-part to take in consideration.
<G-vec00301-001-s156><handle.behandeln><de> Google Maps ist langsam, aber nutzbar zu, während des Browser wie der Guardian behandelt Websites nur über kann.
<G-vec00301-001-s156><handle.behandeln><en> Google Maps is slow but usable too, while the browser can just about handle sites like the Guardian.
<G-vec00301-001-s157><handle.behandeln><de> Sie diskutierten dabei über folgende Themen: „Warum praktiziere ich Falun Gong?“, „Was ist Kultivierung?“, „Wie bringe ich die Kultivierung mit dem Studium in Einklang?“, „Wie behandelt man die Beziehung zwischen Mann und Frau?“, und „Wie informiere ich über die Verfolgung?“ und so weiter.
<G-vec00301-001-s157><handle.behandeln><en> "The discussion topics include: ""Why do I practise Falun Gong?"" ""What is cultivation?"" ""How to balance the relationship between cultivation and school work;"" ""How to handle the relationship between man and woman;"" ""How to clarify the truth,"" and so on."
<G-vec00301-001-s158><handle.behandeln><de> In diesem Fall können Fehler dennoch mittels geschützter Blocks behandelt werden (siehe Behandlung von Fehlern in Schritten).
<G-vec00301-001-s158><handle.behandeln><en> In this case, you can still handle errors by means of protected blocks (see Handling Step Errors). •
<G-vec00301-001-s159><handle.behandeln><de> Mit dem Parameter Mehrfachhosts wird angegeben, dass der Netzwerkdatenverkehr der zugeordneten Portregel von Mehrfachhosts in einem Cluster behandelt wird.
<G-vec00301-001-s159><handle.behandeln><en> The Multiple hosts parameter specifies that multiple hosts in the cluster will handle network traffic for the associated port rule.
<G-vec00301-001-s160><handle.behandeln><de> Der Eigentümer behandelt alle Daten und Fakten über die Nutzer vertraulich und verwendet ausschließlich zur Verbesserung seiner Dienste und zur Erstellung eigener Statistiken.
<G-vec00301-001-s160><handle.behandeln><en> The Owner shall handle all data and facts about the Users confidentially and use them solely for the purpose of improving its services and preparing their own statistics.
<G-vec00301-001-s161><handle.behandeln><de> Alle Reklamationen werden ordentlich und sachkundig behandelt.
<G-vec00301-001-s161><handle.behandeln><en> We undertake to handle all complaints fairly and competently.
<G-vec00301-001-s162><handle.behandeln><de> Unter seiner neuen Rolle, Leone behandelt sowohl die Brasilianische und regionale Operationen.
<G-vec00301-001-s162><handle.behandeln><en> Under his new role, Leone will handle both the Brazilian and regional operations.
<G-vec00301-001-s163><handle.behandeln><de> Weiterhin hat die Mitgliederversammlung im März 2011 beschlossen, dass in Zukunft zwei Mitgliederversammlungen pro Jahr stattfinden sollen: Im März eines jeden Jahres sollen Anträge behandelt und beschlossen werden, und im November dann eine ausführliche Diskussion und ein Beschluss des Wirtschaftsplans sowie die Wahl des Präsidiums im Mittelpunkt der zweiten Klausur stehen.
<G-vec00301-001-s163><handle.behandeln><en> Furthermore, the general assembly decided in March 2011 that there will be two general assemblies per year in the future: in March of each year to handle proposals and then in November there will be a focus on having a detailed discussion, coming to a decision concerning the budget and holding the election of the oversight board.
<G-vec00301-001-s164><handle.behandeln><de> Dieses steht im Gegensatz zu dem Verfahren der jungen europäischen Komponisten, wo Rhythmus und Dynamik getrennt behandelt werden.
<G-vec00301-001-s164><handle.behandeln><en> This stands in opposition to the process of young European composers who handle rhythm and dynamic separately.
<G-vec00301-001-s165><handle.behandeln><de> Unser technisches Support-Team zeigt Ihnen, wie bestimmte Fälle behandelt und gelöst werden.
<G-vec00301-001-s165><handle.behandeln><en> Our technical support team will teach you how to handle and solve different cases.
<G-vec00301-001-s167><handle.behandeln><de> Buchhaltungsdienstleistungen, die entworfen sind, um eine echte administrative Unterstützung darstellen, auf dem der Geschäftsmann oder Händler kann deutlich ihre Produktionstätigkeit zu realisieren, mit dem Vertrauen, dass eine Mehr... Fachfirma, die Buchhaltung Aufgaben behandelt hat rechtzeitige und im Rahmen der bestehenden gesetzlichen Bestimmungen.
<G-vec00301-001-s167><handle.behandeln><en> Accounting services that are designed to constitute a true administrative support, on which the businessman or trader can clearly realize their productive activity, with the confidence that has a More... specialist company that will handle accounting tasks make timely and within the existing legal provisions .
<G-vec00301-001-s168><handle.behandeln><de> 4.1 Familien Mitglieder von Haji Munshi Moharram Ali sind automatisch Mitglied aber sie werden behandelt wie normale Mitglieder.
<G-vec00301-001-s168><handle.behandeln><en> 4.1 The family member of Haji Munshi Moharram Ali gets membership automatically but they will handle like normal Stiftung/Foundation member.
<G-vec00301-001-s169><handle.behandeln><de> Buchhaltungsdienstleistungen, die entworfen sind, um eine echte administrative Unterstützung darstellen, auf dem der Geschäftsmann oder Händler kann deutlich ihre Produktionstätigkeit zu realisieren, mit dem Vertrauen, dass eine Fachfirma, die Buchhaltung Aufgaben behandelt hat rechtzeitige und im Rahmen der bestehenden gesetzlichen Bestimmungen.
<G-vec00301-001-s169><handle.behandeln><en> Accounting services that are designed to constitute a true administrative support, on which the businessman or trader can clearly realize their productive activity, with the confidence that has a specialist company that will handle accounting tasks make timely and within the existing legal provisions .
<G-vec00301-001-s170><handle.behandeln><de> Ferienwohnungen mit vollem Management: Unsere Reservierungsabteilung behandelt den gesamten Prozess mit vollständiger Freiheit, um den Kalender stets vorteilhaft für den Eigentümer zu aktualisieren.
<G-vec00301-001-s170><handle.behandeln><en> Apartments with full management: Our reservations department handle the whole process with complete freedom to update the calendar, making sure it is always beneficial to the owner.
<G-vec00211-002-s059><oversee.behandeln><de> Die Menge der zu behandelnden Produkte muss realistisch und beherrschbar sein.
<G-vec00211-002-s059><oversee.behandeln><en> The number of products that staff need to oversee must be realistic and manageable.
<G-vec00272-002-s071><beg.behandeln><de> Ich möchte aber nicht unzählige Sprachen mit nur wenigen Namen behandeln; daher bitte ich für eine neue Sprache um Namen für wenigstens zwanzig Pflanzen.
<G-vec00272-002-s071><beg.behandeln><en> I do not want to have dozens of languages with only a few names in each of them, so I beg that you provide names for at least 20 herbs and spices for a new language, the more the better.
<G-vec00301-002-s133><deal.behandeln><de> Ihr Kommentar muss nicht das Werk als Ganzes behandeln, sondern darf gern fragmenthaften Charakter haben und nur einzelne Kapitel oder Aspekte einer Publikation beleuchten.
<G-vec00301-002-s133><deal.behandeln><en> Your comment does not have to deal with a publication as a whole, but can rather highlight individual chapters or aspects.
<G-vec00301-002-s134><deal.behandeln><de> Ich werde bezahlt, um Sie zu behandeln, aber nicht, um Sie zu unterhalten.
<G-vec00301-002-s134><deal.behandeln><en> Example Sentences: paid to deal with you but not to entertain you.
<G-vec00301-002-s135><deal.behandeln><de> Geänderter Text (20a) Damit die AS-Stellen effizient arbeiten, muss durch Vorschriften dafür gesorgt werden, dass sie nur relevante Fälle behandeln.
<G-vec00301-002-s135><deal.behandeln><en> (20a) In order to ensure their efficiency, it is necessary to lay down provisions to ensure that ADR entities deal with relevant cases only.
<G-vec00301-002-s136><deal.behandeln><de> Sie beruhen auf grober Täuschung und man kann sie relativ leicht behandeln.
<G-vec00301-002-s136><deal.behandeln><en> They're based on gross delusion and they're relatively easy to deal with.
<G-vec00301-002-s137><deal.behandeln><de> Andere SR-Kodizes und Standards leiden unter dem gleichen Mangel: sie behandeln auch nur einige Elemente des multidimensionalen SR-Systems.
<G-vec00301-002-s137><deal.behandeln><en> Other existing SR codes and standards suffer in the same way. They also deal only with some elements of the multidimensional SR system.
<G-vec00301-002-s138><deal.behandeln><de> Die Lesenden haben dadurch die Möglichkeit, schnell zu erfassen, welche Fragestellung die betreffenden Autorinnen und Autoren behandeln und zu welchem Ergebnis sie kommen.
<G-vec00301-002-s138><deal.behandeln><en> This gives readers to opportunity to find out briefly what questions the authors deal with and what their findings are.
<G-vec00301-002-s139><deal.behandeln><de> Die Anavar ist ein populärer Name von Steroiden mit der Osteoporose zu behandeln.
<G-vec00301-002-s139><deal.behandeln><en> The Anavar is a popular name of steroids to deal with the osteoporosis.
<G-vec00301-002-s140><deal.behandeln><de> - Howitzer Shells behandeln jetzt nur das Fahrzeug, das sie treffen, ohne die nahe gelegenen Einheiten zu beeinflussen.
<G-vec00301-002-s140><deal.behandeln><en> - Howitzers' shells now deal damage only to the vehicle they hit without affecting nearby vehicles.
<G-vec00301-002-s141><deal.behandeln><de> Sechs wissenschaftliche Hauptsitzungen und zahlreiche Präsentationen behandeln diesen wichtigen Aspekt der Schlaganfallforschung.
<G-vec00301-002-s141><deal.behandeln><en> Six major scientific sessions and numerous poster presentations deal with this important aspect of international stroke research.
<G-vec00301-002-s142><deal.behandeln><de> Sie behandeln Themen wie Wut, Verrat oder Eifersucht.
<G-vec00301-002-s142><deal.behandeln><en> They deal with themes such as anger, treason or jealeousy,...
<G-vec00301-002-s143><deal.behandeln><de> Politische Szenarien der Gegenwart behandeln nur wenige Spiele, doch zwei Entwicklungsteams haben den Schritt gewagt.
<G-vec00301-002-s143><deal.behandeln><en> Very few games deal with political scenarios from the present day, though two development teams have dared to take the leap.
<G-vec00301-002-s144><deal.behandeln><de> Ferner behandeln diese Schulen auch SELF DEFENSE.
<G-vec00301-002-s144><deal.behandeln><en> Furthermore, these schools also deal with SELF-DEFENCE.
<G-vec00301-002-s145><deal.behandeln><de> Machen Sie einen Termin für eine Versammlung, legen Sie Ihre Auffassungen dar, behandeln Sie die Punkte der Tagesordnung und machen Sie, was Sie machen müssen.
<G-vec00301-002-s145><deal.behandeln><en> Schedule the meeting, share your ideas, deal with the points on the agenda and go off to do what you need to.
<G-vec00301-002-s146><deal.behandeln><de> Zum Glück, jetzt gibt es Ergänzungen angeboten, die mit männlichen Brüste ohne Operation behandeln können.
<G-vec00301-002-s146><deal.behandeln><en> Fortunately, now there are supplements offered that can deal with guy boobs without surgery.
<G-vec00301-002-s147><deal.behandeln><de> Mit zehn maximal engagierten jungen Frauen, die spannende Green-Themen auf ihren Blogs behandeln.
<G-vec00301-002-s147><deal.behandeln><en> With ten maximally committed young women, who deal with exciting green topics on their blogs.
<G-vec00301-002-s148><deal.behandeln><de> Die Besitzer sind sehr hilfsbereit, freundlich und leicht zu behandeln.
<G-vec00301-002-s148><deal.behandeln><en> The owners are very helpful, friendly and easy to deal with.
<G-vec00301-002-s149><deal.behandeln><de> 11.8 Ungeachtet von Klausel 11.3 behält sich das Unternehmen das Recht vor, Garantieansprüche gemäß Klausel 11.2 im eigenen Ermessen zu behandeln, falls der Käufer dem Unternehmen noch vertragsgemäß fällige Beträge schuldet.
<G-vec00301-002-s149><deal.behandeln><en> 11.8 Notwithstanding condition 11.3 the Company reserves the right to deal with a warranty claim under condition 11.2 as it sees fit in the event that the Buyer has failed to pay to the Company any sums due pursuant to the Contract.
<G-vec00301-002-s150><deal.behandeln><de> Die meisten ihrer Songs behandeln ernste Themen, die häufig in Zusammenhang mit den Problemen der modernen afrikanischen Gesellschaft stehen, und doch ist ihre Musik, darunter auch das neue Album „Wait For Me“, lebensbejahend und packend.
<G-vec00301-002-s150><deal.behandeln><en> Most of their songs deal with serious issues often relating to the problems of modern African society, yet the music, including their latest album “Wait For Me” is uplifting and captivating.
<G-vec00301-002-s151><deal.behandeln><de> Die Beiträge sind absolut professionell gestaltet und behandeln hauptsächlich das Thema Homecomputer.
<G-vec00301-002-s151><deal.behandeln><en> The contributions are absolutely professional and mainly deal with home computers.
<G-vec00301-002-s133><handle.behandeln><de> (2) Solange das Eigentum noch nicht auf ihn übergegangen ist, hat der Käufer die Ware pfleglich zu behandeln und die Verkäuferin unverzüglich schriftlich zu benachrichtigen, wenn die Kaufsache gepfändet oder sonstigen Eingriffen Dritter ausgesetzt ist.
<G-vec00301-002-s133><handle.behandeln><en> (2) As long as title has still not passed over to him, the Buyer shall have to handle the goods with care and notify the Seller without undue delay in writing, if the purchased thing has been pledged or is vulnerable to third party interference.
<G-vec00301-002-s134><handle.behandeln><de> Die erarbeiteten und hier wiedergegebenen Beiträge behandeln, langfristig und zukunftsorientiert ausgerichtet, die regionalspezifischen Probleme Nordostdeutschlands im Umbauprozess, die bisher ergriffenen politischen und planerischen Maßnahmen zur Gestaltung dieses Prozesses und ihre langfristigen Wirkungen sowie in Szenarienform und konkreten Fallanalysen nachhaltige Strategien und Handlungskonzepte zur Bewältigung der Folgen des demographischen Wandels.
<G-vec00301-002-s134><handle.behandeln><en> The contributions which have been worked out and reproduced here handle, in long-term and future-orientated alignment, the region-specific problems of North-Eastern Germany in the process of reconstruction, the political and planning measures which have been taken up to now to structure this process and their long-term effects and, in scenario form and concrete case analyses, lasting strategies and action concepts to deal with the consequences of demographic change.
<G-vec00301-002-s135><handle.behandeln><de> Die Hexies wurden von Hand zusammengenäht und einige Nähte sind fragil, bitte vorsichtig behandeln.
<G-vec00301-002-s135><handle.behandeln><en> The sewing together of the hexies was done by hand, some seams are fragile, please handle with care.
<G-vec00301-002-s136><handle.behandeln><de> Darüber hinaus gibt es bei den Aggregationen noch weitere Verbesserungen: Histogramm-Aggregationen unterstützen jetzt gestückelte Buckets und behandeln die Rundung negativer Buckets korrekt.
<G-vec00301-002-s136><handle.behandeln><en> Besides this, aggregations have seen more improvements: histogram aggregations now support fractional buckets and handle the rounding of negative buckets correctly, terms aggregations are calculated more efficiently to reduce the risk of combinatorial explosion, and aggregations are now supported by the Profile API.
<G-vec00301-002-s137><handle.behandeln><de> Die Unternehmen müssen sorgfältig abwägen, wie sie die breiteren Beziehungen zu den Interessenträgern, einschließlich der Beziehungen zu Verbrauchern, Mitarbeitern, Lieferanten und lokalen Gemeinschaften, behandeln.
<G-vec00301-002-s137><handle.behandeln><en> Companies need to consider carefully how they handle broader stakeholder relationships, including those with consumers, employees, suppliers and local communities.
<G-vec00301-002-s138><handle.behandeln><de> Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend der gesetzlichen Datenschutzvorschriften sowie dieser Datenschutzerklärung.
<G-vec00301-002-s138><handle.behandeln><en> We handle your personal data confidentially and in accordance with data protection legislation and with this privacy statement.
<G-vec00301-002-s139><handle.behandeln><de> Die Anfragen können vollautomatisiert in Echtzeit bearbeitet werden, oder sie erfordern menschliches Urteilsvermögen – Teams mit richtigen Kompetenzen, Verfügbarkeit und Befugnissen, um bestimmte Arten von Anfragen zu behandeln.
<G-vec00301-002-s139><handle.behandeln><en> These requests can be handled in real time as an automated action or may require human judgment – employees who have the right skills, availability and authority to handle specific types of requests.
<G-vec00301-002-s140><handle.behandeln><de> Fragte Kaiser Kinmei ein Wahrsagerin zur Orientierung, um das Problem zu behandeln.
<G-vec00301-002-s140><handle.behandeln><en> Emperor Kinmei asked a fortune teller for guidance to handle the problem.
<G-vec00301-002-s141><handle.behandeln><de> Wir können nicht garantieren, dass diese Websites Ihre personenbezogenen Daten zuverlässig und sicher behandeln.
<G-vec00301-002-s141><handle.behandeln><en> We cannot guarantee that these websites will handle your personal data in a reliable or safe manner.
<G-vec00301-002-s142><handle.behandeln><de> Sämtliche Dienstleister sind auf Grundlage eines Auftragsverarbeitungsvertrages dazu verpflichtet, Ihre Daten vertraulich zu behandeln.
<G-vec00301-002-s142><handle.behandeln><en> All service providers are obliged to handle your data confidentially pursuant to a commissioned processing contract.
<G-vec00301-002-s143><handle.behandeln><de> Für die Kinder und deren Eltern ist schwer zu fassen, welchen Wert die Instrumente haben und dass man sie sorgfältig behandeln muss.
<G-vec00301-002-s143><handle.behandeln><en> For the children and their parents, it is hard to grasp the full value of all those instruments and they sometimes can´t understand why one should handle them with care.
<G-vec00301-002-s144><handle.behandeln><de> Genauso solltest du jeden so zu Hause behandeln, als wäre er Glas.
<G-vec00301-002-s144><handle.behandeln><en> Likewise, you should handle everyone at home as if you are handling glass.
<G-vec00301-002-s145><handle.behandeln><de> Der erste Schritt ist auf die Größe des Sumpfes zu planen, damit Sie sicher sein können, dass Ihr Sumpf im Falle eines Stromausfalls, kann die Menge an Wasser behandeln, die in sie abgelassen werden.
<G-vec00301-002-s145><handle.behandeln><en> The first step is to plan on the size of your sump so you can be sure that in case of a power outage, your sump can handle the amount of water that will be drained into it.
<G-vec00301-002-s146><handle.behandeln><de> Datenschutz-Richtlinien Uns bei Rebel Walls ist Transparenz wichtig, sowohl in unserer Arbeit, als auch in der Art, wie wir die Informationen über unsere Besucher behandeln.
<G-vec00301-002-s146><handle.behandeln><en> Panel, For Rebel Walls, transparency is key. Both in how we work but also how we handle the information we gather about our visitors.
<G-vec00301-002-s147><handle.behandeln><de> Mineralkortikoide behandeln die Regulierung von Wasser und Salz im Kцrper, Kortikosteroide berwachen, wie der Kцrper auf Krankheit reagiert, und Androgene sind die Sexualhormone bei Mдnnern gefunden.
<G-vec00301-002-s147><handle.behandeln><en> Mineralocorticoids handle the regulation of water and salt in the body, corticosteroids monitor how the body reacts to illness, and androgens are the sex hormones found in males.
<G-vec00301-002-s148><handle.behandeln><de> Schließlich möchten wir, dass Sie wissen, dass wir Ihre privaten Dokumente so behandeln, wie wir möchten, dass unsere privaten Dokumente behandelt werden.
<G-vec00301-002-s148><handle.behandeln><en> Lastly we want you to know that we handle your private documents the way we want our private documents to be handled.
<G-vec00301-002-s149><handle.behandeln><de> Wenn du eine Beschwerde darüber hast, wie wir ihre Daten behandeln würden wir diese gerne hören, aber du hast auch das Recht diese an die Aufsichtsbehörde (der Datenschutzbehörde) zu richten.
<G-vec00301-002-s149><handle.behandeln><en> If you have a complaint about how we handle your data, we would like to hear from you. 10 Enabling/disabling and deleting cookies
<G-vec00301-002-s150><handle.behandeln><de> Hier werden wir auch mehrere Praxisfälle behandeln, sodass noch deutlicher wird, wie die Anwendung eingesetzt werden kann.
<G-vec00301-002-s150><handle.behandeln><en> We will also handle more practical cases to provide more clarity about how the application can be used.
<G-vec00301-002-s151><handle.behandeln><de> Das Unterscheiden dieser Kategorien ist von großem Nutzen für Erzieher, um im Stande zu sein, zu bestimmen welche Typen von Konflikten wir durch eine erzieherische Intervention behandeln können und welche eine professionelle psychologische oder psychiatrische Aufmerksamkeit benötigen und welche unsere Rolle und Möglichkeiten überschreiten.
<G-vec00301-002-s151><handle.behandeln><en> Differentiating these categories is of great use for educators, to be able to determine what types of conflicts we can handle through an educational intervention, and which deserve professional psychological or psychiatric attention, and that exceed our role and possibilities.
<G-vec00301-002-s212><tackle.behandeln><de> Um einen Mentalitätswandel herbeizuführen, behandeln unsere lokalen Teams das heikle Thema der sexuellen und reproduktiven Gesundheit und Rechte in einer Art und Weise, die die lokale Kultur respektiert.
<G-vec00301-002-s212><tackle.behandeln><en> In order to change attitudes, our local teams tackle the sensitive subject of health and sexual and reproductive rights in a manner that respects the local culture.
<G-vec00301-002-s213><tackle.behandeln><de> Wir können dieses Thema auf verschieden Ebenen behandeln: zum Beispiel während der Shiatsu-Sitzung (Yin-Aspekt) oder beim winterlichen Schwimmen in der Limmat (Yang-Aspekt).
<G-vec00301-002-s213><tackle.behandeln><en> We can tackle this topic on different levels, for example: during the Shiatsu session (on a Yin level), or by swimming in Limmat even during the winter (on a Yang level).
<G-vec00301-002-s214><tackle.behandeln><de> Threat-Modelling ist ein strukturierter Ansatz, die Sicherheitsbedrohungen gegenüber einer Software zu dokumentieren und zu behandeln.
<G-vec00301-002-s214><tackle.behandeln><en> Threat modeling is a structured approach to document and tackle security threats in software development.
<G-vec00301-002-s215><tackle.behandeln><de> Sie behandeln Brennpunktthemen des Globalen Wandels und werden meist zu wichtigen Konferenzen erstellt.
<G-vec00301-002-s215><tackle.behandeln><en> They tackle urgent aspects of global change and are usually produced in preparation for key conferences.
<G-vec00301-002-s216><tackle.behandeln><de> Wenn es sinnvoll ist, erstellen wir einen Artikel, um die Frage ausführlich zu behandeln.
<G-vec00301-002-s216><tackle.behandeln><en> When it makes sense we create an article to tackle a question in-depth.
<G-vec00366-002-s247><cover.behandeln><de> Nicht-wissenschaftliche Trainings behandeln zum Beispiel die Themen Selbstpräsentation, wissenschaftliches Schreiben, Führungskräfteentwicklung, Karriereplanung, Zeit- oder Konfliktmanagement und vieles mehr.
<G-vec00366-002-s247><cover.behandeln><en> Non-scientific trainings cover topics such as presentation skills, scientific writing, leadership skills, career planning, time management, conflict management and many more.
<G-vec00366-002-s248><cover.behandeln><de> Hier soll nur kurz erwähnt werden, dass es die Sprache “Brasilianisch” nicht gibt und zwischen Europäischem und Brasilianischem Portugiesisch unterschieden wird (wir behandeln nur das Brasilianische Portugiesisch).
<G-vec00366-002-s248><cover.behandeln><en> We just want to mention that a language called “Brazilian” doesn’t exist and that there is a distinction between European and Brazilian Portuguese (we only cover Brazilian Portuguese).
<G-vec00366-002-s249><cover.behandeln><de> Die jährlich wechselnden Module behandeln Themen, die in enger Abstimmung mit den Nutzern der Untersuchung festgelegt werden.
<G-vec00366-002-s249><cover.behandeln><en> The modules cover currently important subjects which are selected annually in co-operation with the partners of the survey.
<G-vec00366-002-s250><cover.behandeln><de> Unsere Mitarbeiter arbeiten mit Ihrem Team zusammen, um maßgeschneiderte Lösungen zu erstellen, die alle Aspekte ihres täglichen Bedarfs behandeln.
<G-vec00366-002-s250><cover.behandeln><en> Our team works closely together with your staff to cover all aspects of your customized solution.
<G-vec00366-002-s251><cover.behandeln><de> Alle Kurse behandeln spezifische Themen, können jedoch auch auf Ihre Bedürfnisse zugeschnitten werden.
<G-vec00366-002-s251><cover.behandeln><en> All courses cover specific topics, but may also be tailored to your needs.
<G-vec00366-002-s252><cover.behandeln><de> Das Kursprogramm ist allerdings sehr flexibel und kann auch traditionelle Fleischgerichte und andere italienische Spezialitäten wie Pizza und italienische Brote behandeln.
<G-vec00366-002-s252><cover.behandeln><en> Still, this cooking courses program gives a great flexibility and can cover also traditional meat dishes as well as pizza and bread making.
<G-vec00366-002-s253><cover.behandeln><de> Behandeln Sie Themen wie Innenpolitik, Außenpolitik, Interpretation der Verfassung, Kritik und Ansichten von Befürwortern und Gegnern.
<G-vec00366-002-s253><cover.behandeln><en> Cover subjects like domestic policy, foreign policy, interpretation of the constitution, criticisms, and proponents’ and opponents’ viewpoints.
<G-vec00366-002-s254><cover.behandeln><de> Eine ebenfalls grafische Anzeige aller Dokumente, die ein ähnliches Thema behandeln, und die so perfekt funktioniert, dass Sie die Volltextsuche nur zum Einstieg in das Wissensnetz benötigen.
<G-vec00366-002-s254><cover.behandeln><en> It displays, once again in graphical form, all documents that cover a similar topic, so perfectly that full-text searching is only needed to enter the knowledge map.
<G-vec00366-002-s255><cover.behandeln><de> Wir behandeln Themen von Nachrichten Unterhaltung, Sport und Wirtschaft.
<G-vec00366-002-s255><cover.behandeln><en> We cover topics from News Entertainment, Sports and Business.
<G-vec00366-002-s256><cover.behandeln><de> Wir werden dies später behandeln.
<G-vec00366-002-s256><cover.behandeln><en> We will cover this later.
<G-vec00366-002-s257><cover.behandeln><de> Wir behandeln detailliert die Probleme und die Politik, sehen aber auch Musik, Kunst und Sport aus.
<G-vec00366-002-s257><cover.behandeln><en> We cover the troubles and politics in detail but we also look music, art, and sport.
<G-vec00366-002-s258><cover.behandeln><de> In dieser Lektion werden wir behandeln: die verschiedenen Begriffe, die in einer Bäckerei verwendet werden, die Messung von Zutaten, allgemeine Substantive, Eigennamen und Übungen.
<G-vec00366-002-s258><cover.behandeln><en> In this lesson, we will cover: the different terms used in a bakery, measurement of ingredients, common nouns, proper nouns and exercises.
<G-vec00366-002-s259><cover.behandeln><de> Die theoretischen Module werden in der Berufsschule absolviert und behandeln Themen wie Vertrieb und Marketing, Betriebswirtschaft und Soziales, Handel und Rechnungswesen sowie Geschäftsprozesse im Handel.
<G-vec00366-002-s259><cover.behandeln><en> The theoretical modules will take place in the vocational college (Berufsfachschule) and cover topics such as sales & marketing, business & social studies, retailing & accounting, and business processes in Retail.
<G-vec00366-002-s260><cover.behandeln><de> Die Unterrichtseinheiten behandeln grundlegende Alltagsaufgaben vom Verfassen von E-Mails bis hin zu spezielleren Texten wie Pressemitteilungen oder Protokollen von Meetings.
<G-vec00366-002-s260><cover.behandeln><en> The units are designed to cover basic day-to-day tasks such as writing e-mails, to more specific tasks such as press releases and minutes of meetings.
<G-vec00366-002-s261><cover.behandeln><de> Das letzte Thema, das wir behandeln werden, ist die Auswirkung von Freizeitdrogenkonsum bei gestörtem Schlaf.
<G-vec00366-002-s261><cover.behandeln><en> The final topic we will cover is the implication of recreational drug use in disrupted sleep.
<G-vec00366-002-s262><cover.behandeln><de> Wir behandeln zuerst 1.c4 c5 und alles, was nicht zu den 1.Sf3-Varianten überleitet.
<G-vec00366-002-s262><cover.behandeln><en> We will first cover 1.c4 c5, and everything which does not transition to the Nf3 lines.
<G-vec00366-002-s263><cover.behandeln><de> Weitere Themen behandeln ein weites Feld allgemein interessanter Aspekte von der russischen Küche bis hin zur Geschichte.
<G-vec00366-002-s263><cover.behandeln><en> Other topics cover a wide range of general interest subjects ranging from Russian cuisine to history.
<G-vec00366-002-s264><cover.behandeln><de> Die Auswahl und Konfigurierung des Servers werden wir in Kapitel 6, Konfiguration des Servers behandeln; jedoch möchten wir an dieser Stelle kurz darauf hinweisen, dass die Antworten auf einige der anderen Fragen zur Folge haben, dass Sie bei der Entscheidung über den Speicherort für das Projektarchiv keine freie Wahl mehr haben.
<G-vec00366-002-s264><cover.behandeln><en> We cover server choice and configuration in Chapter 6, Server Configuration, but the point we'd like to briefly make here is simply that the answers to some of these other questions might have implications that force your hand when deciding where your repository will live.
<G-vec00366-002-s265><cover.behandeln><de> Daher behandeln bibliothekspädagogische Kurse im Teil "Informationen verarbeiten" auch den Abschnitt "Verantwortungsbewusst mit Informationen umgehen: Plagiate vermeiden".
<G-vec00366-002-s265><cover.behandeln><en> Therefore, library education courses cover "responsibly deal with information: avoid plagiarism" within the environment of the standard "effective use of information".
