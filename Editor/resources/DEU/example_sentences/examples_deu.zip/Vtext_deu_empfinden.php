<G-vec00381-001-s190><feel.empfinden><de> Und das wird sich nicht mehr ändern; ich empfinde jetzt in allem so sicher.
<G-vec00381-001-s190><feel.empfinden><en> And that will change no more; I feel so sure in everything now.
<G-vec00381-001-s191><feel.empfinden><de> „Als Ministerin für Europäische und Internationale Angelegenheiten Österreichs empfinde ich ganz tief die Wichtigkeit des kulturellen Austauschs zwischen unterschiedlichen Nationalitäten.
<G-vec00381-001-s191><feel.empfinden><en> “As a Minister of European and International Affairs of Austria, I feel profoundly the importance of cultural exchanges among various nationalities.
<G-vec00381-001-s192><feel.empfinden><de> Aber ich empfinde es nicht so.
<G-vec00381-001-s192><feel.empfinden><en> But that's not the way I feel it.
<G-vec00381-001-s193><feel.empfinden><de> Dieses Spiel beinhaltet das Thema Folter, wenn Sie also nicht zu sich selbst zu, dass aussetzen, diesmal nicht für dich empfinde.
<G-vec00381-001-s193><feel.empfinden><en> This game involves the topic of torture, so if you feel you do not want to expose yourself to that, this one is not for you.
<G-vec00381-001-s194><feel.empfinden><de> Herzensgebet ist auch sich ganz einfach vor Jesus hinstellen, auch wenn ich nichts empfinde, auf daß Er bete und in mir wirke.
<G-vec00381-001-s194><feel.empfinden><en> To pray with the heart is to place our-selves before Him even when we feel nothing, so He can pray and work in us.
<G-vec00381-001-s195><feel.empfinden><de> "Je nach Raumakkustik und Spielsituation empfinde ich persönlich den Ton dann manchmal als etwas ""knurrig"", was mitunter etwas stört, auch wenn man sich nach einer Weile dran gewöhnt."
<G-vec00381-001-s195><feel.empfinden><en> "Dependent upon the actual acoustic and playing surroundings, I feel personally, that sometimes the tone is a little too ""growling"" although one gets used to quickly."
<G-vec00381-001-s196><feel.empfinden><de> Und wenn ich dies richtig interpretiere, was ich empfinde und sehe, ist da jetzt ein siebenfältiges Erschüttern von einer größeren Stärke am kommen, das enorme und vielleicht katastrophale Spaltungen wirtschaftlich, politisch, geophysikalisch, atmosphärisch und auf den geistlichen Ebenen produziert.
<G-vec00381-001-s196><feel.empfinden><en> And, if I am interpreting correctly what I feel and see, there is yet a seven-fold shaking of greater magnitude coming that will produce enormous and perhaps catastrophic disruptions on economic, political, geophysical, atmospheric, and spiritual levels.
<G-vec00381-001-s197><feel.empfinden><de> Ich drehe und wende sie im Kopf herum und empfinde eine leichte Irritation, eine Reizung von Hirn und Lachmuskeln.
<G-vec00381-001-s197><feel.empfinden><en> I turn them round and use them in my head, and feel a slight irritation, a stimulation of the brain and the laughter muscles.
<G-vec00381-001-s198><feel.empfinden><de> Es ist nicht nur Pflichtgefühl, das ich empfinde.
<G-vec00381-001-s198><feel.empfinden><en> It's not just a sense of duty that I feel.
<G-vec00381-001-s199><feel.empfinden><de> Ob ich an einer bestimmten Vorstellung oder einem Begriff Freude oder Schmerz empfinde, davon wird es abhängen, ob ich sie zum Motiv meines Handelns machen will oder nicht.
<G-vec00381-001-s199><feel.empfinden><en> Whether I feel pleasure or pain with respect to a definite mental picture or concept, upon this will depend whether I want to make it a motive for my action or not.
<G-vec00381-001-s200><feel.empfinden><de> Ich bin seit vielen Tagen aufgrund der Sorge und Wut, die ich angesichts meiner Situation empfinde, nicht mehr in der Lage zu schlafen.
<G-vec00381-001-s200><feel.empfinden><en> I have not been able to sleep for many days because of the anxiety and anger I feel about my situation.
<G-vec00381-001-s201><feel.empfinden><de> "Vielleicht empfinde ich Neuperlach als ""nicht schön"", die Menschen, die dort leben, verknüpfen diesen Ort jedoch mit ihren eigenen Wünschen, Träumen und Erinnerungen."
<G-vec00381-001-s201><feel.empfinden><en> "I might feel that Neuperlach is ""not beautiful"", but the people living there associate it with their own wishes, dreams and memories."
<G-vec00381-001-s202><feel.empfinden><de> Ich empfinde sehr stark dass Gott ein Ziel hatte als er mich zurückschickte, und dass ein Teil des Zwecks der ist, den Menschen von Ihm und seinem freien Geschenk des ewigen Lebens zu erzählen.
<G-vec00381-001-s202><feel.empfinden><en> I strongly feel that God has a purpose in sending me back, and that part of the purpose is to tell people about Him and his free gift of eternal life.
<G-vec00381-001-s203><feel.empfinden><de> "Weil ich so empfinde"", antwortete sie zögerlich."
<G-vec00381-001-s203><feel.empfinden><en> """Why—I feel so,"" said she hesitatingly."
<G-vec00381-001-s204><feel.empfinden><de> Wenn ich Ungerechtigkeiten sehe, empfinde ich Mitleid mit den armen Individuen und ich schimpfe auf die unfaire Gesellschaft und dabei bleibt es.
<G-vec00381-001-s204><feel.empfinden><en> When I see injustice, I feel pity for the poor individuals and curse the unfair society, and that is all.
<G-vec00381-001-s205><feel.empfinden><de> "Ich kannte kein ""ECO DI MARIA"", habe in einem Augenblick der geistigen Mutlosigkeit per Zufall - doch möchte ich es nicht ""Zufall"" nennen - die Juli/August- Ausgabe gefunden, las die erste Seite und weinte, weinte, denn es schien alles wie für mich geschrieben, auf meinen Fall zuge- schnitten und auf das, was ich empfand und noch jetzt empfinde."
<G-vec00381-001-s205><feel.empfinden><en> "found it by chance during a moment of spi-ritual dejection - but I wouldn't call it ""by chance"" - I came across the July-August edition and upon reading the fi rst page I cri- ed because it was as though it was addres- sed to me and to the sensations that I felt and that I still feel now."
<G-vec00381-001-s206><feel.empfinden><de> Die Rede, die ich vor den Priestern gehalten habe, enthält das, was ich hinsichtlich dieses Falls am tiefsten empfinde.
<G-vec00381-001-s206><feel.empfinden><en> What I said to the priests is what I feel most deeply about the matter.
<G-vec00381-001-s207><feel.empfinden><de> Und das, empfinde ich, kann ein nachhaltiger Weg in die Zukunft für unsere Kinder sein.
<G-vec00381-001-s207><feel.empfinden><en> And this, I feel, may be a more sustainable path into the future for our children.
<G-vec00381-001-s208><feel.empfinden><de> """Ich versuche, für das, was ich erlebe und empfinde, eine Parabel zu finden."
<G-vec00381-001-s208><feel.empfinden><en> """I try to find a parable for what I experience and feel."
<G-vec00381-001-s209><feel.empfinden><de> Das ist schlimm, wenn eine Kirche, wenn eine Gemeinschaft sich auf eine Weise verhält, dass die jungen Menschen denken: „Diese sagen mir nichts, was ich für mein Leben brauche.“ Ganz im Gegenteil, manche wollen ausdrücklich in Ruhe gelassen werden, denn sie empfinden die Präsenz der Kirche als lästig, ja unangenehm.
<G-vec00381-001-s209><feel.empfinden><en> It is bad, when a Church, a community, behaves in such a way that young people think: “These ones have nothing to say to me that will be useful in my life”. In fact, some of them expressly ask us to leave them alone, because they feel the Church’s presence as bothersome or even irritating.
<G-vec00381-001-s210><feel.empfinden><de> Heute könnt ihr Mich bereits in eurem Geiste empfinden, ebenso wie im Innersten eures Herzens.
<G-vec00381-001-s210><feel.empfinden><en> Now you can feel Me within your spirit as well as deep inside your heart.
<G-vec00381-001-s211><feel.empfinden><de> "Nun scheint es so, dass wir zu der letzten Schicht gekommen sind, wenn wir hören: ""Wenn es in der Tat Menschen gibt, die verfolgt werden, werde ich Mitgefühl empfinden""."
<G-vec00381-001-s211><feel.empfinden><en> "So, now it seems that we have come to the last layer when we hear: ""If there are indeed people who are being persecuted, I will feel sympathetic."""
<G-vec00381-001-s212><feel.empfinden><de> Im allgemeinen verhält es sich so: Der Herr ist überall, Seine Schwingung ist überall, nur die Fähigkeit, Ihn zu empfinden oder sich Seiner bewußt zu sein, ist neu.
<G-vec00381-001-s212><feel.empfinden><en> In a general way, that's how it works: the Lord is everywhere, His vibration is everywhere, but what's new is the capacity to feel Him or be conscious of Him.
<G-vec00381-001-s213><feel.empfinden><de> Seine Seele wird sich nicht zufriedengeben damit, was die Welt ihr bieten kann.... sie wird erst wahre Seligkeit empfinden können, wenn ihr Güter aus dem geistigen Reich geboten werden.
<G-vec00381-001-s213><feel.empfinden><en> His soul will not content itself with what the world can offer.... It will only be able to feel truly happy when it is offered possessions from the spiritual kingdom.
<G-vec00381-001-s214><feel.empfinden><de> Sie werden die Gem?tlichkeit empfinden und den professionellen Service von qualifizierten Fachkr?ften erfahren.
<G-vec00381-001-s214><feel.empfinden><en> You'll feel a cosiness and the professional services of the qualified specialists.
<G-vec00381-001-s215><feel.empfinden><de> Die Verantwortlichen, die Freiwilligen und alle, die in die Mensa kommen, mögen die Schönheit dieser Liebe erfahren können; mögen sie die Tiefe der Freude empfinden können, die aus ihr erwächst, eine Freude, die sich gewiß unterscheidet von jener trügerischen Freude, die die Werbung anpreist.
<G-vec00381-001-s215><feel.empfinden><en> May those in charge, the volunteers and all who come to the Soup Kitchen experience the beauty of this love; may they feel the depth of the joy that springs from it, a joy that is certainly different from that deceptive illusory one publicized by advertisements.
<G-vec00381-001-s216><feel.empfinden><de> Auf diese Weise können wir die Gaben ohne eine Spur von Geiz darbringen, und daher werden wir viel mehr Freude dabei empfinden, die Gaben darzubringen.
<G-vec00381-001-s216><feel.empfinden><en> In this way, we are able to make the offerings without any stinginess and because of that, we feel much more pleasure at giving the offerings.
<G-vec00381-001-s217><feel.empfinden><de> "Zur ""Ruhe"" bringen bedeutet nicht, dass wir dann gar nichts mehr empfinden."
<G-vec00381-001-s217><feel.empfinden><en> """Quiet"" down doesn't mean that we don't feel anything."
<G-vec00381-001-s218><feel.empfinden><de> Dennoch versuchen wir zu empfinden, dass keine soliden Trennwände zwischen uns stehen, die eine herzliche Kommunikation verhindern würden.
<G-vec00381-001-s218><feel.empfinden><en> Yet, we try to feel that no solid walls stand between us, preventing heartfelt communication.
<G-vec00381-001-s219><feel.empfinden><de> Der oft zur Entschuldigung politischer Feigheit herangezogenen erfreulichen gesellschaftlichen Breite von Attac ist es dann auch geschuldet, dass mit dem konservativen Heiner Geisler zumindest ein prominenter Attacie in der Süddeutschen erklärte, dass es für manche schwer sei „die strukturelle Gewalt zu empfinden und dennoch friedlich zu bleiben“.
<G-vec00381-001-s219><feel.empfinden><en> Due to the pleasing scope of society Attac comes from, that has often been used to excuse political cowardice, at least one prominent Attacie – conservative Heiner Geißler – told the Süddeutsche Zeitung that it is hard for some “to feel the structural violence and still remain peaceful”.
<G-vec00381-001-s220><feel.empfinden><de> Sie empfinden Ärger und würden am liebsten sofort losschreien und sich die Person vorknöpfen.
<G-vec00381-001-s220><feel.empfinden><en> They feel anger and would like to scream at once and get the person in front of them.
<G-vec00381-001-s221><feel.empfinden><de> Jeder gute, in Mitleid ihnen zugewandte Gedanke wirkt sich erleichternd für die Seelen aus, sie empfinden dies und bleiben dann stets in eurer Nähe, sie bitten euch, indem sie sich euch in die Gedanken drängen, um von euch mit einer liebenden Fürbitte bedacht zu werden.
<G-vec00381-001-s221><feel.empfinden><en> Every good thought given to them in sympathy has a relieving effect on the souls; they feel this and then always remain near you; they ask you by them pushing themselves into your thoughts to be given by you a loving intercession.
<G-vec00381-001-s222><feel.empfinden><de> Er fragt sich, wie man überhaupt nur anders denken, anders empfinden kann.
<G-vec00381-001-s222><feel.empfinden><en> It wonders how one can think otherwise, feel otherwise?
<G-vec00381-001-s223><feel.empfinden><de> Wir empfinden Anahata und Vishudha.
<G-vec00381-001-s223><feel.empfinden><en> Feel anahata and vishuddha.
<G-vec00381-001-s224><feel.empfinden><de> Kurt und Barbara Brunner empfinden, dass Gott sie ruft weiter zu gehen, in einen neuen Lebensabschnitt.
<G-vec00381-001-s224><feel.empfinden><en> Kurt and Barbara Brunner feel that the Lord is calling them to move on, into a new season of their life.
<G-vec00381-001-s225><feel.empfinden><de> Ihr werdet die Dringlichkeit dieser Botschaft empfinden.
<G-vec00381-001-s225><feel.empfinden><en> You will feel the urgency of this message.
<G-vec00381-001-s226><feel.empfinden><de> Dazu kommt, daß sie selbst vermögen zu sehen und zu empfinden als Lichtwesen.... was dir jetzt noch nicht verständlich ist.... daß sie in der Verbindung mit dem Heiland vermögen, sich in dieser Lichtfülle aufzuhalten, und es ihnen Glücksempfinden ohne Maßen bereitet.
<G-vec00381-001-s226><feel.empfinden><en> Moreover, they are able to see and to feel as beings of light.... which is not comprehensible to you as yet.... so that, in union with the Saviour, they are able to stay in this abundance of light which gives them a feeling of immeasurable happiness.
<G-vec00381-001-s227><feel.empfinden><de> Angst ist etwas, das wir Menschen häufig empfinden und erleben.
<G-vec00381-001-s227><feel.empfinden><en> Being a human, “fear” is something that we commonly feel and experience.
<G-vec00204-002-s171><feel.empfinden><de> D.h., es muss der Mensch sich helfen lassen wollen, er muss seine Not empfinden und herauszukommen trachten, er muss also den Geisteszustand als mangelhaft empfinden und Verlangen tragen nach Hebung dessen, dann sind die geistigen Führer bereit und auch von Gott aus berechtigt, ihm beizustehen.
<G-vec00204-002-s171><feel.empfinden><en> I.e., man must want to be helped; he must feel his trouble and strive to get out of it; he must feel the spiritual state as inadequate and carry desire to remedy it, then the spiritual guides are ready and also entitled by God to assist him.
<G-vec00204-002-s173><feel.empfinden><de> Aber ich glaube, es steht für das, was viele Menschen in meinem Land, in Europa, in den USA – von dort kommt das Magazin – empfinden, wenn Sie in die Zukunft blicken: Faszination auf der einen Seite, aber zugleich: Angst.
<G-vec00204-002-s173><feel.empfinden><en> But I think it is emblematic of what many people in my country, Europe and the United States – where the magazine is from – feel when they look towards the future. They are fascinated, on the one hand – but at the same time, they feel fear.
<G-vec00204-002-s174><feel.empfinden><de> Das war das erste Mal in fünf Jahren, dass ich Wärme empfinden konnte.
<G-vec00204-002-s174><feel.empfinden><en> It was the first time in five years that I could feel warmth.
<G-vec00204-002-s175><feel.empfinden><de> Was Sie empfinden, wenn Sie feststellen, dass Soldaten der Israelischen Armee auf Ihren Matratzen geschlafen und Ihre Decken benutzt haben, um sich warm zu halten.
<G-vec00204-002-s175><feel.empfinden><en> How you would feel when you understood that IDF soldiers had slept on your mattresses and used your blankets to keep warm.
<G-vec00204-002-s176><feel.empfinden><de> Schon 1915 hatte Trotzki geschrieben: „Das Proletariat, das durch die Schule des Krieges gegangen ist, wird beim ersten ernsten Hindernis innerhalb des eigenen Landes das Bedürfnis empfinden, die Sprache der Gewalt zu brauchen.“ [7] Lenin war bei der Antikriegspolitik der Bolschewiki davon ausgegangen, dass die Widersprüche des imperialistischen Weltsystems, die den Krieg hervorgerufen hatten, auch zur sozialistischen Revolution führen würden.
<G-vec00204-002-s176><feel.empfinden><en> As early as 1915, Trotsky had written: “A working class that has been through the school of war will feel the need of using the language of force as soon as the first serious obstacle faces them within their own country.” Lenin had based the anti-war policy of the Bolsheviks upon the conviction that the contradictions of imperialism as a world system, which had led to war, would also lead to socialist revolution.
<G-vec00204-002-s177><feel.empfinden><de> Es hilft uns auch, Mitleid und Hoffnung für diejenigen zu empfinden, die sich noch in der „Wüste auf dem Weg zum Schilfmeer“ befinden - diejenigen, die noch auf dem Weg aus der Sklaverei in die Freiheit sind.
<G-vec00204-002-s177><feel.empfinden><en> It also helps us to feel compassion and hope for those who are still in “the wilderness of the Red Sea” – those who are still on the journey from slavery to freedom.
<G-vec00204-002-s178><feel.empfinden><de> Wie zahlreiche Personen, werdet Ihr Unwohlsein in eurem Körper empfinden oder werdet ihn anders empfinden, als ob Ihr immer mehr Mühe hättet, ihn zu führen.
<G-vec00204-002-s178><feel.empfinden><en> As with many people, you will feel these disturbances in your body or you will feel different, as if you were having more and more difficulty managing it.
<G-vec00204-002-s180><feel.empfinden><de> Wir sind der Meinung, dass unsere Besteckeinsätze ihr Geld wert sind und hoffen, dass Sie das gleiche empfinden werden, wenn Sie Ihre Schublade aufziehen.
<G-vec00204-002-s180><feel.empfinden><en> We believe that our cutlery inserts are worth their money and hope that you will feel the same, when you will open your drawer.
<G-vec00204-002-s181><feel.empfinden><de> Wie schön ist es, die Schule, die Klassenzimmer wie ein zweites Zuhause zu empfinden.
<G-vec00204-002-s181><feel.empfinden><en> How nice it is to feel that our school, or the places where we gather, are a second home.
<G-vec00204-002-s182><feel.empfinden><de> Manche empfinden es ziemlich störend und wenden daher das Verzögerungsspray nicht an.
<G-vec00204-002-s182><feel.empfinden><en> Some people feel it quite annoying and therefore don’t use the delay spray.
<G-vec00204-002-s183><feel.empfinden><de> Bitten Sie sie, darüber zu sprechen, was sie empfinden, wenn sie durch diese Taufen zur Errettung anderer beitragen können.
<G-vec00204-002-s183><feel.empfinden><en> Ask them to tell how they feel knowing that through baptisms for the dead they can help others receive salvation.
<G-vec00204-002-s184><feel.empfinden><de> Wenn wir uns nicht mehr der Verbindung mit dem ozeanischen Bewusstsein erinnern, empfinden wir ‚Ich Bin’, und unter dem Einfluss von Kali sind wir in der Illusion, dass wir eine separate Existenz haben.
<G-vec00204-002-s184><feel.empfinden><en> When we do not recollect the connection with the oceanic consciousness, we feel ‘I AM’, and under the influence of Kali we are in the illusion that we have a separate existence.
<G-vec00204-002-s185><feel.empfinden><de> Hier müssen wir auf den gewissen Widerstand, auf eine Reaktion stoßen, um wenigstens etwas zu empfinden.
<G-vec00204-002-s185><feel.empfinden><en> Here we have to encounter some resistance, some reaction, in order to feel something.
<G-vec00204-002-s186><feel.empfinden><de> Die Emotionen, die wir in jedem Moment empfinden, wenn wir uns als Konsumenten ein Produkt (oder auch eine Webseite) zu Gemüte führen, bestimmen die jeweilige darauf folgende Art und Weise der Handlung.
<G-vec00204-002-s186><feel.empfinden><en> The emotions that we feel every moment when we as a consumer lead to mind a product (or even a website), determine the respective subsequent manner of action.
<G-vec00204-002-s187><feel.empfinden><de> Dadurch können die Partner ihre erogenen Zonen entdecken und sinnliche Freude empfinden, ohne unter Handlungszwang zu stehen.
<G-vec00204-002-s187><feel.empfinden><en> This allows the couple to discover their erogenous zones and to feel sensual pleasure without any pressure to perform.
<G-vec00204-002-s188><feel.empfinden><de> Letzten Endes müssen wir Muslime dem qur’ânischen Vers 2:256 folgen, der die ungefähre Bedeutung hat: „Es gibt keinen Zwang im Glauben…“ In Widerspruch zu diesem Vers empfinden einige Angehörige anderer Religionen, dass es ihre Pflicht sei, zu versuchen, uns ihre Feiern aufzuzwingen.
<G-vec00204-002-s188><feel.empfinden><en> After all, we must follow the Quranic verse 2:256 (which means): "There shall be no compulsion in [acceptance of] the religion…" Yet, some feel that it is their duty to try to force their celebrations on us.
<G-vec00204-002-s189><feel.empfinden><de> Ein naheliegender Punkt: Zahlreiche Studien konnten zeigen, dass enge Beziehungen zu Freunden und Familie ausschlaggebend für das Empfinden von Glück sind.
<G-vec00204-002-s189><feel.empfinden><en> An obvious one to start with; numerous studies have shown that close relationships with friends or family are a major factor in how happy we feel.
<G-vec00341-002-s023><perceive.empfinden><de> Jüngste Befunde legen nahe, dass Paare, die ihre Hausarbeitsteilung als gerecht empfinden, häufiger Geschlechtsverkehr haben und zufriedener sind mit ihrem Sexualleben.
<G-vec00341-002-s023><perceive.empfinden><en> Recent findings suggest that couples who perceive their housework distribution to be fair have more frequent sexual encounters and are more satisfied with their sex life.
<G-vec00341-002-s024><perceive.empfinden><de> Die vorliegende empirische Arbeit zeigt vor dem Hintergrund von Fairness- und Beziehungstheorien, dass deutsche Konsumenten differentielle Kundenbehandlung im Allgemeinen als unfairer empfinden als US-Konsumenten.
<G-vec00341-002-s024><perceive.empfinden><en> Based on fairness and relationship theories, the present empirical dissertation shows that German consumers perceive differential customer treatment as more unfair than US consumers.
<G-vec00341-002-s025><perceive.empfinden><de> Ich bin mit Irvine Welsh aufgewachsen, und was er getan hat, um den Kanon dessen, was wir als Literatur empfinden, zu durchbrechen, ist ein Bruch, der in der Mainstream-Literatur heutzutage nicht angenommen wird, und wir sind dafür umso ärmer.
<G-vec00341-002-s025><perceive.empfinden><en> I grew up DJing with Irvine Welsh, and what he did to disrupt the canon of what we perceive to be literature is a break that wouldn’t arrive in mainstream literature right now, and we are the worse for it.
<G-vec00341-002-s026><perceive.empfinden><de> Das hat Konsequenzen für unser Verständnis der Welt und unsere Wahrnehmungsfähigkeit: Was wir als wirklich empfinden, sei nichts als das, was uns unsere Sinne vorgeben.
<G-vec00341-002-s026><perceive.empfinden><en> That has consequences for our understanding of the world and our ability of perception: What we really perceive is nothing but that what our senses give us.
<G-vec00341-002-s027><perceive.empfinden><de> Nur weil die Lufttemperatur in einem Zimmer 22 °C beträgt, muss ein Mensch das Zimmer nicht als 22 °C warm empfinden.
<G-vec00341-002-s027><perceive.empfinden><en> A human may not perceive the temperature in a room to be 22 degrees just because the air temperature in the room is 22 degrees.
<G-vec00381-002-s176><feel.empfinden><de> Schon 1915 hatte Trotzki geschrieben: „Das Proletariat, das durch die Schule des Krieges gegangen ist, wird beim ersten ernsten Hindernis innerhalb des eigenen Landes das Bedürfnis empfinden, die Sprache der Gewalt zu brauchen.“ [7] Lenin war bei der Antikriegspolitik der Bolschewiki davon ausgegangen, dass die Widersprüche des imperialistischen Weltsystems, die den Krieg hervorgerufen hatten, auch zur sozialistischen Revolution führen würden.
<G-vec00381-002-s176><feel.empfinden><en> As early as 1915, Trotsky had written: “A working class that has been through the school of war will feel the need of using the language of force as soon as the first serious obstacle faces them within their own country.” Lenin had based the anti-war policy of the Bolsheviks upon the conviction that the contradictions of imperialism as a world system, which had led to war, would also lead to socialist revolution.
