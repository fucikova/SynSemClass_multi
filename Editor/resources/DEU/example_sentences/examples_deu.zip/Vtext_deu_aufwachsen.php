<G-vec00510-002-s114><grow.aufwachsen><de> Jedes Kind verdient es, in einer friedlichen Umgebung aufzuwachsen.
<G-vec00510-002-s114><grow.aufwachsen><en> Every child deserves to grow up in a peaceful environment.
<G-vec00510-002-s115><grow.aufwachsen><de> Bröckchen für Kätzchen und Welpen sind zum Beispiel kleiner, aber ebenfalls reich an wichtigen Nährstoffen, die junge Tiere brauchen, um stark und gesund aufzuwachsen.
<G-vec00510-002-s115><grow.aufwachsen><en> But it is also extra rich in nutrients that are especially important for young animals in order to grow up strong and healthy.
<G-vec00510-002-s116><grow.aufwachsen><de> Dort erhalten sie die notwendige Zuwendung und Fürsorge, um aufzuwachsen und wieder Freude am Leben zu finden.
<G-vec00510-002-s116><grow.aufwachsen><en> There they receive the attention and care they need to grow and to learn to smile again.
<G-vec00510-002-s117><grow.aufwachsen><de> Denn sie war davon überzeugt, daß die Kinder, um sicher und gut aufzuwachsen, eine gesunde und geeinte, großmütige und festgefügte Familie brauchen.
<G-vec00510-002-s117><grow.aufwachsen><en> She was convinced that in order for children to grow up sure of themselves and strong, they needed a family that was healthy and united, generous and stable.
<G-vec00510-002-s118><grow.aufwachsen><de> Die Zukunft ist allerdings gerade ein großes Fragezeichen: Ich überlege oft, ob ich es besser gefunden hätte in Italien oder in London aufzuwachsen und was besser für Alice ist.
<G-vec00510-002-s118><grow.aufwachsen><en> The future is a big question mark: I often wonder whether I would have preferred to grow up in Italy or London and what would be better for her.
<G-vec00510-002-s119><grow.aufwachsen><de> Kinder brauchen beide Elternteile, um sich gesund zu entwickeln und aufzuwachsen.
<G-vec00510-002-s119><grow.aufwachsen><en> Children need both parents to evolve and grow in a healthy way.
<G-vec00510-002-s120><grow.aufwachsen><de> Ich erinnere mich, zu denken, wie ich nicht warten könnte, um aufzuwachsen.
<G-vec00510-002-s120><grow.aufwachsen><en> I remember thinking how I couldn't wait to grow up.
<G-vec00510-002-s121><grow.aufwachsen><de> Schwangeren Frauen oder Frauen mit Kindern unter 3 Jahren wird deshalb beim Eintritt in das Gefängnis gesagt, dass es für das Kind nicht gut ist, hinter Gittern aufzuwachsen, und ihnen wird die Möglichkeit angeboten, das Kind an Familienmitglieder abzugeben.
<G-vec00510-002-s121><grow.aufwachsen><en> Thus, pregnant women or women with children under 3 are told upon entry to the prison that it isn't good for the child to grow up behind bars, and options are given for them to send the child off to family members.
<G-vec00510-002-s122><grow.aufwachsen><de> Dies erfordert tägliche Arbeit an sich selbst, aber es ist notwendig, wenn wir dem Kind helfen wollen, als unabhängige, glückliche, autarke Person aufzuwachsen.
<G-vec00510-002-s122><grow.aufwachsen><en> This requires daily work on yourself, but it is necessary if we want to help the child grow up as an independent, happy, self-sufficient person.
<G-vec00510-002-s123><grow.aufwachsen><de> Biete eine große Anzahl von Verstecken an, wie hohe Vegetation, damit einige der Brut in der Lage sind, aufzuwachsen.
<G-vec00510-002-s123><grow.aufwachsen><en> Provide a lot of hidden places, like high vegetation so some fry will be able to grow.
<G-vec00510-002-s124><grow.aufwachsen><de> Das Traumkind schläft nur auf besten und weichsten Materialien, um gesund und ausgeruht in einer sauberen Welt aufzuwachsen, die auch noch schön und sauber für nächste Generationen ist.
<G-vec00510-002-s124><grow.aufwachsen><en> The dreamgirl sleeps only on the best and softest materials to grow healthy and relaxed in a clean world that is also beautiful and well-groomed for next generations.
<G-vec00510-002-s125><grow.aufwachsen><de> Jedoch weist Razz darauf hin, dass es nicht der beste Platz ist, aufzuwachsen, anzeigend, dass die RNK noch viel Arbeit zu tun hat, wahrscheinlich rund um Supermutanten, Ghulen, plündernden Banden und der großen Mengen der Strahlung.
<G-vec00510-002-s125><grow.aufwachsen><en> However, dialogue with Razz from Fallout: New Vegas suggests it is not the best place to grow up, indicating the NCR still has some work to do, likely revolving around super mutants, ghouls, and raiding gangs.
<G-vec00510-002-s126><grow.aufwachsen><de> Nachdem ich keuchte und 'nein' sagte begann ich langsam zurück zu gehen und die ganze Zeit sagte ich, nein ich kann jetzt noch nicht gehen, ich möchte meinen Kindern helfen aufzuwachsen.
<G-vec00510-002-s126><grow.aufwachsen><en> After I gasped and said 'no' I started slowly going back the whole time I was saying, No, I can't leave yet, I want to help my kids grow up.
<G-vec00510-002-s127><grow.aufwachsen><de> Ein Leben, wo das Kind darauf hoffen kann, aufzuwachsen, eine Ausbildung zu erhalten und ein aktives Mitglied der Gesellschaft zu werden.
<G-vec00510-002-s127><grow.aufwachsen><en> One where the child can hope to grow up, get an education and become a contributing member to society.
<G-vec00510-002-s128><grow.aufwachsen><de> Es war nie gut für mich, getrennt von meinen Eltern aufzuwachsen.
<G-vec00510-002-s128><grow.aufwachsen><en> It was never good for me to grow up apart from my family.
<G-vec00510-002-s129><grow.aufwachsen><de> Kinder, die gezwungen waren, ohne ihre Mutter oder ihren Vater aufzuwachsen.
<G-vec00510-002-s129><grow.aufwachsen><en> Children who were forced to grow up without their mother or their father.
<G-vec00510-002-s130><grow.aufwachsen><de> Auch nach 40 Jahren fühlen wir uns dem Dienst an der Waldorfpädagogik verpflichtet und werden, solange es die Aufgaben als notwendig erscheinen lassen, weiter dafür arbeiten, dass Kindern eine reelle Chance gegeben wird, in Achtung ihres Menschseins aufzuwachsen.
<G-vec00510-002-s130><grow.aufwachsen><en> Even after 40 years, the Friends are committed to the serve Waldorf education. As long as it is necessary the association will continue to work to ensure that children will be given a real chance to education and grow up in conditions that value their dignity.
<G-vec00510-002-s131><grow.aufwachsen><de> Obwohl es einen großen Unterschied machte, in einer Stadt oder am Lande aufzuwachsen, war doch vieles gleich.
<G-vec00510-002-s131><grow.aufwachsen><en> To grow up in the city or in a small village means to be worlds apart. But some things were the same.
<G-vec00510-002-s132><grow.aufwachsen><de> Er wandert hinüber zum Jenseits und realisiert jedoch, daß es die Gelegenheit bekommen hat nach Gottes Plan weiterzuleben und aufzuwachsen, anstatt vielleicht nicht an Gott zu glauben und vom rechten Weg abzukommen.
<G-vec00510-002-s132><grow.aufwachsen><en> However, when he passes to the afterlife and realises that had he been granted the opportunity to live on and grow up, he may have decided not to believe in God Almighty or to stray from His Path.
<G-vec00167-002-s095><grow_up.aufwachsen><de> Denn, wie Thomas Jefferson 1787 sagte: “Wenn das amerikanische Volk jemals privaten Banken erlaubt, die Kontrolle über ihre Währung zu übernehmen, werden die Banken und Konzerne, die um sie herum aufwachsen, zuerst durch Inflation, dann durch Deflation, den Menschen ihr Eigentum nehmen, bis ihre Kinder obdachlos auf dem Kontinent, das ihre Väter eroberten, aufwachen.
<G-vec00167-002-s095><grow_up.aufwachsen><en> For, as Thomas Jefferson had said in 1787: ” “If the American people ever allow private banks to control the issue of their currency, first by inflation, then by deflation, the banks and the corporations which grow up around them will deprive the people of all property until their children wake up homeless on the continent their fathers conquered.”
<G-vec00167-002-s096><grow_up.aufwachsen><de> Wenn die Kinder so aufwachsen und es als normal betrachten, ihren Müll einfach fallenzulassen, werden die Strände und Meere weiterhin vergiftet und die Flora und Fauna zerstört.
<G-vec00167-002-s096><grow_up.aufwachsen><en> If the children grow up like this and consider it normal to just drop their trash, the beaches and oceans will continue to be poisoned and the flora and fauna destroyed.
<G-vec00167-002-s097><grow_up.aufwachsen><de> Das Wichtigste vorweg: Ihr Kind ist in Ordnung so, wie es ist, und es kann so glücklich aufwachsen wie andere auch.
<G-vec00167-002-s097><grow_up.aufwachsen><en> Let’s start with the most important part: Your child is fine just the way he/she is and can grow up to be happy just like other kids.
<G-vec00167-002-s098><grow_up.aufwachsen><de> Sie dürfen nicht zum „Streitobjekt“ werden; stattdessen gilt es, die besten Wege zu finden, damit sie das Trauma der familiären Spaltung überwinden und möglichst unbeschwert aufwachsen können.
<G-vec00167-002-s098><grow_up.aufwachsen><en> Children must not become an "object" of contention. Instead, every suitable means ought to be sought to ensure that they can overcome the trauma of a family break-up and grow as serenely as possible.
<G-vec00167-002-s099><grow_up.aufwachsen><de> Mit seinen Babykost-Produkten leistet Holle einen entscheidenden Beitrag, dass Babys von Anfang an nachhaltig aufwachsen können.
<G-vec00167-002-s099><grow_up.aufwachsen><en> Holle baby food products play an important role in ensuring babies can grow up sustainably, from the beginning.
<G-vec00167-002-s100><grow_up.aufwachsen><de> Im Augenblick ist mein Herz mit so viel Dankbarkeit gefüllt, da mich all diese nackten Wände und leeren Räume daran erinnert haben, wie viel Glück ich hatte, dass ich dort aufwachsen konnte.
<G-vec00167-002-s100><grow_up.aufwachsen><en> Nach because seeing all these naked walls and empty rooms reminded me of how lucky I was that I could grow up there.
<G-vec00167-002-s101><grow_up.aufwachsen><de> Für die Familie, in der die Kinder aufwachsen, ist dies der wichtigste Raum.
<G-vec00167-002-s101><grow_up.aufwachsen><en> For the family, in which the children grow up, this is the most important room.
<G-vec00167-002-s102><grow_up.aufwachsen><de> Peg aufwachsen würde gemeinsam mit Ihnen.
<G-vec00167-002-s102><grow_up.aufwachsen><en> PEG would grow up together with you .
<G-vec00167-002-s103><grow_up.aufwachsen><de> Da unsere Bengalen innerhalb unseres Hauses, mit unseren zwei Teenagern und ihren Freunden aufwachsen, lernen sie von früh auf sich an andere Menschen zu gewöhnen.
<G-vec00167-002-s103><grow_up.aufwachsen><en> The Bengal babies grow up within our home with our two teenagers and their visiting friends.
<G-vec00167-002-s104><grow_up.aufwachsen><de> Unsere Kinder würden dann in einem Land der Wunder aufwachsen.
<G-vec00167-002-s104><grow_up.aufwachsen><en> In fact, our children will grow up in a Nation of miracles.
<G-vec00167-002-s105><grow_up.aufwachsen><de> Stanglwirt-Kinder aufwachsen sehen.
<G-vec00167-002-s105><grow_up.aufwachsen><en> the Stanglwirt children grow up.
<G-vec00167-002-s106><grow_up.aufwachsen><de> Mütter haben ihre Kinder verloren und Kinder müssen jetzt ohne ihre Eltern aufwachsen.
<G-vec00167-002-s106><grow_up.aufwachsen><en> Mothers have lost their children and children now have to grow up without their parents.
<G-vec00167-002-s107><grow_up.aufwachsen><de> Dass ich Dich niemals aufwachsen sehe.
<G-vec00167-002-s107><grow_up.aufwachsen><en> That I will never see you grow.
<G-vec00167-002-s108><grow_up.aufwachsen><de> Ich möchte meine Nichte und meinen Neffen aufwachsen sehen und am Wochenende zu meinen Eltern zum Mittagessen fahren.
<G-vec00167-002-s108><grow_up.aufwachsen><en> I want to see my niece and nephew grow up and have lunch with my parents.
<G-vec00167-002-s109><grow_up.aufwachsen><de> Sammeln Sie die Äpfel und aufwachsen Ihr Wurm.
<G-vec00167-002-s109><grow_up.aufwachsen><en> Collect the apples and grow up your worm.
<G-vec00167-002-s110><grow_up.aufwachsen><de> Besonders "nach Geschmack" sind sie warme, feuchte und dunkle Räume, in denen sie aufwachsen und winzige Sporen in die Luft "werfen".
<G-vec00167-002-s110><grow_up.aufwachsen><en> Especially "to taste" they are warm, wet and dark rooms, where they grow up and "throw" into the air tiny spores.
<G-vec00167-002-s111><grow_up.aufwachsen><de> Sie entscheiden darüber, in was for einer Art von Welt wir aufwachsen werden.
<G-vec00167-002-s111><grow_up.aufwachsen><en> You are deciding what kind of world we will grow up in.
<G-vec00167-002-s112><grow_up.aufwachsen><de> Ihr seid diejenigen, die jetzt aufwachsen von dem kleinen Kind, das die geistige Familie unseres himmlischen Vaters erkennt.
<G-vec00167-002-s112><grow_up.aufwachsen><en> You are the ones who now grow up from the infant child, who realize the spiritual family of our heavenly Father.
<G-vec00167-002-s113><grow_up.aufwachsen><de> Aber dann wuchs ich auf und das Problem ist jetzt, daß alot der Männer nicht aufwachsen.
<G-vec00167-002-s113><grow_up.aufwachsen><en> But then I grew up and the problem now is that alot of men don't grow up.
<G-vec00167-002-s114><grow_up.aufwachsen><de> Jedes Kind verdient es, in einer friedlichen Umgebung aufzuwachsen.
<G-vec00167-002-s114><grow_up.aufwachsen><en> Every child deserves to grow up in a peaceful environment.
<G-vec00167-002-s115><grow_up.aufwachsen><de> Bröckchen für Kätzchen und Welpen sind zum Beispiel kleiner, aber ebenfalls reich an wichtigen Nährstoffen, die junge Tiere brauchen, um stark und gesund aufzuwachsen.
<G-vec00167-002-s115><grow_up.aufwachsen><en> But it is also extra rich in nutrients that are especially important for young animals in order to grow up strong and healthy.
<G-vec00167-002-s116><grow_up.aufwachsen><de> Dort erhalten sie die notwendige Zuwendung und Fürsorge, um aufzuwachsen und wieder Freude am Leben zu finden.
<G-vec00167-002-s116><grow_up.aufwachsen><en> There they receive the attention and care they need to grow and to learn to smile again.
<G-vec00167-002-s117><grow_up.aufwachsen><de> Denn sie war davon überzeugt, daß die Kinder, um sicher und gut aufzuwachsen, eine gesunde und geeinte, großmütige und festgefügte Familie brauchen.
<G-vec00167-002-s117><grow_up.aufwachsen><en> She was convinced that in order for children to grow up sure of themselves and strong, they needed a family that was healthy and united, generous and stable.
<G-vec00167-002-s118><grow_up.aufwachsen><de> Die Zukunft ist allerdings gerade ein großes Fragezeichen: Ich überlege oft, ob ich es besser gefunden hätte in Italien oder in London aufzuwachsen und was besser für Alice ist.
<G-vec00167-002-s118><grow_up.aufwachsen><en> The future is a big question mark: I often wonder whether I would have preferred to grow up in Italy or London and what would be better for her.
<G-vec00167-002-s119><grow_up.aufwachsen><de> Kinder brauchen beide Elternteile, um sich gesund zu entwickeln und aufzuwachsen.
<G-vec00167-002-s119><grow_up.aufwachsen><en> Children need both parents to evolve and grow in a healthy way.
<G-vec00167-002-s120><grow_up.aufwachsen><de> Ich erinnere mich, zu denken, wie ich nicht warten könnte, um aufzuwachsen.
<G-vec00167-002-s120><grow_up.aufwachsen><en> I remember thinking how I couldn't wait to grow up.
<G-vec00167-002-s121><grow_up.aufwachsen><de> Schwangeren Frauen oder Frauen mit Kindern unter 3 Jahren wird deshalb beim Eintritt in das Gefängnis gesagt, dass es für das Kind nicht gut ist, hinter Gittern aufzuwachsen, und ihnen wird die Möglichkeit angeboten, das Kind an Familienmitglieder abzugeben.
<G-vec00167-002-s121><grow_up.aufwachsen><en> Thus, pregnant women or women with children under 3 are told upon entry to the prison that it isn't good for the child to grow up behind bars, and options are given for them to send the child off to family members.
<G-vec00167-002-s122><grow_up.aufwachsen><de> Dies erfordert tägliche Arbeit an sich selbst, aber es ist notwendig, wenn wir dem Kind helfen wollen, als unabhängige, glückliche, autarke Person aufzuwachsen.
<G-vec00167-002-s122><grow_up.aufwachsen><en> This requires daily work on yourself, but it is necessary if we want to help the child grow up as an independent, happy, self-sufficient person.
<G-vec00167-002-s123><grow_up.aufwachsen><de> Biete eine große Anzahl von Verstecken an, wie hohe Vegetation, damit einige der Brut in der Lage sind, aufzuwachsen.
<G-vec00167-002-s123><grow_up.aufwachsen><en> Provide a lot of hidden places, like high vegetation so some fry will be able to grow.
<G-vec00167-002-s124><grow_up.aufwachsen><de> Das Traumkind schläft nur auf besten und weichsten Materialien, um gesund und ausgeruht in einer sauberen Welt aufzuwachsen, die auch noch schön und sauber für nächste Generationen ist.
<G-vec00167-002-s124><grow_up.aufwachsen><en> The dreamgirl sleeps only on the best and softest materials to grow healthy and relaxed in a clean world that is also beautiful and well-groomed for next generations.
<G-vec00167-002-s125><grow_up.aufwachsen><de> Jedoch weist Razz darauf hin, dass es nicht der beste Platz ist, aufzuwachsen, anzeigend, dass die RNK noch viel Arbeit zu tun hat, wahrscheinlich rund um Supermutanten, Ghulen, plündernden Banden und der großen Mengen der Strahlung.
<G-vec00167-002-s125><grow_up.aufwachsen><en> However, dialogue with Razz from Fallout: New Vegas suggests it is not the best place to grow up, indicating the NCR still has some work to do, likely revolving around super mutants, ghouls, and raiding gangs.
<G-vec00167-002-s126><grow_up.aufwachsen><de> Nachdem ich keuchte und 'nein' sagte begann ich langsam zurück zu gehen und die ganze Zeit sagte ich, nein ich kann jetzt noch nicht gehen, ich möchte meinen Kindern helfen aufzuwachsen.
<G-vec00167-002-s126><grow_up.aufwachsen><en> After I gasped and said 'no' I started slowly going back the whole time I was saying, No, I can't leave yet, I want to help my kids grow up.
<G-vec00167-002-s127><grow_up.aufwachsen><de> Ein Leben, wo das Kind darauf hoffen kann, aufzuwachsen, eine Ausbildung zu erhalten und ein aktives Mitglied der Gesellschaft zu werden.
<G-vec00167-002-s127><grow_up.aufwachsen><en> One where the child can hope to grow up, get an education and become a contributing member to society.
<G-vec00167-002-s128><grow_up.aufwachsen><de> Es war nie gut für mich, getrennt von meinen Eltern aufzuwachsen.
<G-vec00167-002-s128><grow_up.aufwachsen><en> It was never good for me to grow up apart from my family.
<G-vec00167-002-s129><grow_up.aufwachsen><de> Kinder, die gezwungen waren, ohne ihre Mutter oder ihren Vater aufzuwachsen.
<G-vec00167-002-s129><grow_up.aufwachsen><en> Children who were forced to grow up without their mother or their father.
<G-vec00167-002-s130><grow_up.aufwachsen><de> Auch nach 40 Jahren fühlen wir uns dem Dienst an der Waldorfpädagogik verpflichtet und werden, solange es die Aufgaben als notwendig erscheinen lassen, weiter dafür arbeiten, dass Kindern eine reelle Chance gegeben wird, in Achtung ihres Menschseins aufzuwachsen.
<G-vec00167-002-s130><grow_up.aufwachsen><en> Even after 40 years, the Friends are committed to the serve Waldorf education. As long as it is necessary the association will continue to work to ensure that children will be given a real chance to education and grow up in conditions that value their dignity.
<G-vec00167-002-s131><grow_up.aufwachsen><de> Obwohl es einen großen Unterschied machte, in einer Stadt oder am Lande aufzuwachsen, war doch vieles gleich.
<G-vec00167-002-s131><grow_up.aufwachsen><en> To grow up in the city or in a small village means to be worlds apart. But some things were the same.
<G-vec00167-002-s132><grow_up.aufwachsen><de> Er wandert hinüber zum Jenseits und realisiert jedoch, daß es die Gelegenheit bekommen hat nach Gottes Plan weiterzuleben und aufzuwachsen, anstatt vielleicht nicht an Gott zu glauben und vom rechten Weg abzukommen.
<G-vec00167-002-s132><grow_up.aufwachsen><en> However, when he passes to the afterlife and realises that had he been granted the opportunity to live on and grow up, he may have decided not to believe in God Almighty or to stray from His Path.
<G-vec00167-002-s551><grow_up.aufwachsen><de> Wenn aber Ihre Pflanzen kräftig wachsen, bekommen die Algen Nahrungsmangel und können nicht richtig wachsen.
<G-vec00167-002-s551><grow_up.aufwachsen><en> But once your plants start growing strong, the algae begin to starve and can’t grow properly!
<G-vec00167-002-s552><grow_up.aufwachsen><de> Nach drei Monaten beginnen die Haare erneut zu wachsen.
<G-vec00167-002-s552><grow_up.aufwachsen><en> After three months, the hairs begin to grow again.
<G-vec00167-002-s553><grow_up.aufwachsen><de> Aber sie hat nur den Sinn dafür, wie weit es darum geht zu existieren, wie weit es darum geht sich selbst zu ernähren, auf einer sehr materiellen Ebene, die dem Baum gestattet, zu wachsen.
<G-vec00167-002-s553><grow_up.aufwachsen><en> But it has only the sense how far to go to exist, how far to go to nourish yourself, on a very material plane how to allow the tree to grow.
<G-vec00167-002-s554><grow_up.aufwachsen><de> Nein, ich habe stets gefuehlt, dass Gott immer gegenwaertig ist und dass dieses Leben ein Geschenk für unsere Seelen ist, um zu wachsen und anderen zu helfen, um zu wachsen.
<G-vec00167-002-s554><grow_up.aufwachsen><en> No I have always felt God is always present and that this life is a gift for our souls to grow and help others grow.
<G-vec00167-002-s556><grow_up.aufwachsen><de> Da traditionelle Unternehmen mit dem Aufkommen neuer Technologien wie Mobile Banking, Blockchain und disruptiven Fintech-Geschäftsmodellen wachsen, bedeutet Zukunftssicherheit für Ihre Mitarbeiter, dass jeder Mitarbeiter nun ein technischer Mitarbeiter werden muss.
<G-vec00167-002-s556><grow_up.aufwachsen><en> As traditional firms grow to meet the emergence of new technologies like mobile banking, blockchain, and disruptive fintech business models, future-proofing your workforce means that every employee now needs to become a technical employee. Knowledge Sharing
<G-vec00167-002-s557><grow_up.aufwachsen><de> Es sieht daher nicht so aus, als würde der Welthandel in den nächsten Jahren wieder wie früher mit nahezu der doppelten Rate des globalen BIP wachsen.
<G-vec00167-002-s557><grow_up.aufwachsen><en> It therefore does not look as if global trade will again grow at nearly twice the speed of global GDP in the next few years, as was the case in the past.
<G-vec00167-002-s558><grow_up.aufwachsen><de> Seine Energie ist genug, um Ihre gesamte Seite zu graben, so dass das Territorium des Hundes irgendwie geschützt werden muss, oder er wird Ihre Lieblingsblumen nicht alleine lassen und wird kein Gemüse wachsen lassen.
<G-vec00167-002-s558><grow_up.aufwachsen><en> His energy is enough to dig up your entire site, so the dog must somehow be protected, or he will not leave your favorite flowers alone and will not let grow vegetables.
<G-vec00167-002-s559><grow_up.aufwachsen><de> Wager muss weiter wachsen.
<G-vec00167-002-s559><grow_up.aufwachsen><en> Wager needs continue to grow.
<G-vec00167-002-s560><grow_up.aufwachsen><de> 27Und der König machte, daß das Silber zu Jerusalem an Menge den Steinen gleichkam, und die Cedern den Maulbeerfeigenbäumen, die in der Niederung wachsen.
<G-vec00167-002-s560><grow_up.aufwachsen><en> And the king made silver in Ierusalem as plenteous as stones, and Cedar trees as plenteous as the mulberry trees that grow in the valleys.
<G-vec00167-002-s561><grow_up.aufwachsen><de> Wir gehen davon aus, auf Marktniveau zu wachsen.
<G-vec00167-002-s561><grow_up.aufwachsen><en> We expect to grow in line with the market.
<G-vec00167-002-s562><grow_up.aufwachsen><de> Das EV Sales Blog berichtet, dass der Großteil der Lithium-Ionen-Batterien bereits in Asien hergestellt wird und dass Chinas Lithiumsverbrauch im Einklang mit dem Ausbau der Produktion von Batterien für diese Fahrzeuge wachsen wird.
<G-vec00167-002-s562><grow_up.aufwachsen><en> The EV Sales Blog reports that most lithium ion batteries are currently made in Asia and China’s lithium consumption will grow in line with stepped up production of batteries for these vehicles.
<G-vec00167-002-s563><grow_up.aufwachsen><de> Das Leben ist nicht linear, wir wachsen und verbinden uns, wir erkunden neue Wege, es ist ein konstantes Ausprobieren, Ausgreifen und Zurückziehen.
<G-vec00167-002-s563><grow_up.aufwachsen><en> Life is not linear, we grow and we connect, we explore new paths, it is a constant trial and error, a constant reaching out and retrieving.
<G-vec00167-002-s564><grow_up.aufwachsen><de> Auch im nicht sehr fruchtbaren Boden wachsen und entwickeln sich Himbeeren.
<G-vec00167-002-s564><grow_up.aufwachsen><en> Even in the not very fertile soil raspberries will grow and develop.
<G-vec00167-002-s565><grow_up.aufwachsen><de> Der größte Teil der Sumpfes von Toftåsa besteht aus Torfmoor und an anderen Stellen wachsen Laubbäume.
<G-vec00167-002-s565><grow_up.aufwachsen><en> The largest part of the swamp of Toftåsa consists of peat bog and in other places grow deciduous trees.
<G-vec00167-002-s566><grow_up.aufwachsen><de> Das große Problem sind Tumoren, die unbemerkt tief in den Organen wachsen und Metastasen bilden, die schwer zu entdecken und zu behandeln sind.
<G-vec00167-002-s566><grow_up.aufwachsen><en> Major problems are caused by tumours that grow deep inside body organs and therefore cannot be seen during an examination, forming metastases that are difficult to detect and treat.
<G-vec00167-002-s567><grow_up.aufwachsen><de> TRIA ist ein laufend weiterentwickeltes modulfähiges System, das nach den Wünschen des Kunden wachsen und geändert werden kann.
<G-vec00167-002-s567><grow_up.aufwachsen><en> TRIA is a module system that has evolved continuously and can grow and alter depending on the client's needs.
<G-vec00167-002-s568><grow_up.aufwachsen><de> iFixit Pro ist ein neues und ambitioniertes Open Source Projekt welches Reparaturunternehmen überall unterstützen soll zu wachsen.
<G-vec00167-002-s568><grow_up.aufwachsen><en> iFixit Pro is a new and ambitious open source project designed to support and grow repair businesses everywhere.
<G-vec00167-002-s569><grow_up.aufwachsen><de> Wenn wir eine Katze, einen Baum oder einen Vogel beobachten, erwarten wir, dass sie sich entsprechen, gleich, ob sie in Estland oder Russland, in China oder Mexiko, im Kongo oder in Brasilien wachsen.
<G-vec00167-002-s569><grow_up.aufwachsen><en> If we observe a cat, a tree or a bird we assume that they are still the same, no matter if they grow in Estonia or Russia, in China or Mexico, in Congo or Brazil.
<G-vec00167-002-s684><grow_up.aufwachsen><de> Dank der liebevollen Pflege seiner Gastmutter und ihrer Familie verschwanden die Infektionen sehr schnell und das Fell wuchs wieder nach.
<G-vec00167-002-s684><grow_up.aufwachsen><en> With the loving care of his foster mum and their family, his infections quickly cleared up and his hair started to grow back.
<G-vec00167-002-s685><grow_up.aufwachsen><de> Sie fing langsam an und sie hatte sogar Jahre, in denen ihr Geschäft überhaupt nicht wuchs.
<G-vec00167-002-s685><grow_up.aufwachsen><en> She started out slowly, and she even had years where her business didn’t grow at all.
<G-vec00167-002-s686><grow_up.aufwachsen><de> • In Zentral- und Osteuropa wuchs Russland weiter stark, während die gegenwärtige Instabilität und Unsicherheit den Rest der Region beeinträchtigten.
<G-vec00167-002-s686><grow_up.aufwachsen><en> In Central and Eastern Europe while Russia continued to grow strongly the current instability and uncertainties affected the rest of the region.
<G-vec00167-002-s687><grow_up.aufwachsen><de> Zwar wuchs auch unter seinem Nachfolger Abt Ignaz Speckle (1795-1806) der Bücherbestand noch, aber das Zeitalter der barocken Klöster und ihrer Bibliotheken war abgelaufen.
<G-vec00167-002-s687><grow_up.aufwachsen><en> Although the collection continued to grow under his successor Abbot Ignaz Speckle (1795–1806), the era of the Baroque abbey and its libraries was over.
<G-vec00167-002-s688><grow_up.aufwachsen><de> Die Infrastruktur wuchs nicht mit der gestiegenen Nachfrage nach Transportleistungen.
<G-vec00167-002-s688><grow_up.aufwachsen><en> Infrastructure did not grow along the increased demand for transportation.
<G-vec00167-002-s689><grow_up.aufwachsen><de> Das, kombiniert mit dem schnellen Wuchs, macht sie zu einer tollen Wahl für kommerzielle Züchter.
<G-vec00167-002-s689><grow_up.aufwachsen><en> This combined with the fast grow times makes it a great commercially viable choice.
<G-vec00167-002-s690><grow_up.aufwachsen><de> Mit einem Umsatzanstieg von 9 % wuchs der Markt Kommunikation weiterhin erfreulich.
<G-vec00167-002-s690><grow_up.aufwachsen><en> With a net sales increase of 9 %, the Communication market continued to grow pleasantly.
<G-vec00167-002-s691><grow_up.aufwachsen><de> Von da an gab es keinen Halt mehr, immer mehr Bestellungen kamen an, und die Firma wuchs schnell.
<G-vec00167-002-s691><grow_up.aufwachsen><en> From this time there was no pause, they received more and more orders that made the company grow fast.
<G-vec00167-002-s692><grow_up.aufwachsen><de> Die Opposition gegen Diem im eigenen Land wuchs jedoch weiter.
<G-vec00167-002-s692><grow_up.aufwachsen><en> Opposition to Diem in his own country continued to grow, however.
<G-vec00167-002-s693><grow_up.aufwachsen><de> Obwohl die Gao Brüder aufgrund eines 1989 von Chinesischen Behörden ausgesprochenen Ausreiseverbots China 14 Jahre nicht verlassen konnten, wuchs ihr Ansehen im Ausland trotzdem kontinuierlich.
<G-vec00167-002-s693><grow_up.aufwachsen><en> Blacklisted in 1989, the brothers were not allowed to leave China for 14 years but nevertheless their reputation outside China continued to grow.
<G-vec00167-002-s694><grow_up.aufwachsen><de> Die Kirchengemeinde in Jerusalem wuchs weiter, als die Apostel Wunder vollbrachten und mit großer Macht lehrten.
<G-vec00167-002-s694><grow_up.aufwachsen><en> The Jerusalem church continued to grow as the apostles performed miracles and taught with great power.
<G-vec00167-002-s695><grow_up.aufwachsen><de> Über die Jahre wuchs diese Siedlung und wurde zu einer bedeutenden Diözese.
<G-vec00167-002-s695><grow_up.aufwachsen><en> As time passed, this settlement continued to grow and became a very important diocese.
<G-vec00167-002-s696><grow_up.aufwachsen><de> Im Laufe der Jahre wuchs der Park weiter und bietet neue Attraktionen mit dem Thema der europäischen Länder: der Abstieg der Tiroler Stromschnellen, die italienische Renaissance - Architektur, die Welt der Trolle, ein Schweizer Dorf, die Azulejos von Sevilla, die Russische Raumstation Mir, die weißen Häuser von Mykonos, aber auch drei weitere Bezirke, die spezifische Atmosphären reproduzieren: das Universum des Abenteuers (afrikanische Atmosphäre, Dschungel und Paddelboote), der Zauberwald von Grimm (die Figuren und Kulissen der Gebrüder Grimm) berühmte Märchen) und das Königreich der Minimoys, in Anlehnung an Luc Bessons Film.
<G-vec00167-002-s696><grow_up.aufwachsen><en> Over the years, the park has continued to grow and offer new attractions, with the theme of the European countries: the descent of the Tyrolean rapids, the Italian Renaissance architecture, the world of trolls, a Swiss village, the azulejos of Seville, the Russian space station Mir, the white houses of Mykonos, but also three other districts that reproduce specific atmospheres: the universe of adventure (African atmosphere, jungle and paddle boats), the Enchanted Forest of Grimm (the characters and scenery of the Grimm brothers' famous tales) and the Kingdom of the Minimoys, in reference to Luc Besson's film.
<G-vec00167-002-s697><grow_up.aufwachsen><de> Ein weiteres Mal können wir den unbehinderten Wuchs des Dschungels sehen.
<G-vec00167-002-s697><grow_up.aufwachsen><en> Once again we can watch the jungle grow unhindered.
<G-vec00167-002-s698><grow_up.aufwachsen><de> Wesentlicher Treiber hierfür waren zum einen weitere Erfolge bei der Monetarisierung des steigenden Datenkonsums, der dank innovativer Produkte weiter wuchs.
<G-vec00167-002-s698><grow_up.aufwachsen><en> One important factor driving this development was further gains in the monetisation of increasing data use, which continued to grow thanks to innovative products.
<G-vec00167-002-s699><grow_up.aufwachsen><de> 12:24 Das Wort Gottes aber wuchs und mehrete sich.
<G-vec00167-002-s699><grow_up.aufwachsen><en> 12:24 And the word of God did grow and did multiply,
<G-vec00167-002-s700><grow_up.aufwachsen><de> In diesem wuchs daraufhin das Gewürz Basilikum äußerst erfolgreich heran.
<G-vec00167-002-s700><grow_up.aufwachsen><en> This was used to grow basil very successfully.
<G-vec00167-002-s701><grow_up.aufwachsen><de> Die Pflanze ist 5-10 cm tiefer zu pflanzen, als sie bis jetzt wuchs.
<G-vec00167-002-s701><grow_up.aufwachsen><en> A plant should be put to the ground 5-10 cm deeper than it used to grow, with the root ball in the center.
<G-vec00167-002-s702><grow_up.aufwachsen><de> Frankfurt wandelte sich in kürzester Zeit zu einer modernen Industriestadt und wuchs beständig.
<G-vec00167-002-s702><grow_up.aufwachsen><en> Frankfurt became a modern industrial city within a very short period of time and continued to grow steadily.
<G-vec00167-002-s703><grow_up.aufwachsen><de> Im kommenden Jahr wächst die Messe weiter und wird mit einer neuen Hallenbelegung noch stärker strukturiert.
<G-vec00167-002-s703><grow_up.aufwachsen><en> In the coming year the trade fair will continue to grow, and a new hall allocation will give it an improved structure.
<G-vec00167-002-s704><grow_up.aufwachsen><de> Kurzbeschreibung "Der Niedriglohnsektor gewinnt in Deutschland zunehmend an Bedeutung und wächst immer weiter.
<G-vec00167-002-s704><grow_up.aufwachsen><en> "The low wage sector is becoming increasingly important in Germany and is continuing to grow.
<G-vec00167-002-s705><grow_up.aufwachsen><de> Annähernd verbreitet ist die Art nur auf Åland, wo man 30 Standorte kennt, die Vorkommen in Varsinais-Suomi liegen bei Inkoo und Korppoo, auf dem Festland wächst die Art wohl nicht mehr.
<G-vec00167-002-s705><grow_up.aufwachsen><en> It is quite common only on the Åland Islands where there are 30 known areas that it grows in: on the mainland it can only be found around Inkoo and Korppoo, but apart from that it doesn’t seem to grow on the mainland.
<G-vec00167-002-s706><grow_up.aufwachsen><de> Nach der Übernahme durch das eigene Management und die capiton AG wächst BORSIG wieder.
<G-vec00167-002-s706><grow_up.aufwachsen><en> After the takeover by its own management and capiton AG, BORSIG started to grow again.
<G-vec00167-002-s707><grow_up.aufwachsen><de> Er führte die politische Notwendigkeit der Regionalpolitik auf den sich schon seit vorgeschichtlicher Zeit entfaltenden Siedlungsdruck in Städte zurück: Städte und Agglomerationen bieten Menschen zusätzlichen Nutzen, der mit ihrer Größe grundsätzlich wächst und zusätzliche Menschen anzieht.
<G-vec00167-002-s707><grow_up.aufwachsen><en> He traced back the political necessity of regional policy to the urbanisation, a trend existing since prehistoric times: cities and agglomerations offer people additional benefits, which basically grow with their size and attract additional people.
<G-vec00167-002-s708><grow_up.aufwachsen><de> Wie in der Kirche als Ganzes erfüllen sich die Worte des Evangeliums: „Mit dem Reich Gottes ist es so, wie wenn ein Mann Samen auf seinen Acker sät; dann schläft er und steht wieder auf, es wird Nacht und wird Tag, der Samen keimt und wächst, und der Mann weiß nicht, wie.
<G-vec00167-002-s708><grow_up.aufwachsen><en> As in the whole Church, the words of the Gospel become a reality: “The kingdom of God is as if a man should scatter seed upon the ground, and should sleep and rise night and day, and the seed should sprout and grow, he knows not how.
<G-vec00167-002-s709><grow_up.aufwachsen><de> Mit Jennifer Schöne wächst unser Team um eine weitere Mitarbeiterin.
<G-vec00167-002-s709><grow_up.aufwachsen><en> With Jennifer Schöne the Weyermann® team continues to grow.
<G-vec00167-002-s710><grow_up.aufwachsen><de> Aufgrund der demografischen Entwicklung gehen wir davon aus, dass der Markt für Gesundheitsprodukte weiter wächst.
<G-vec00167-002-s710><grow_up.aufwachsen><en> Demographic developments lead us to believe that the market for health products will continue to grow.
<G-vec00167-002-s711><grow_up.aufwachsen><de> Benchmark Email verfolgt Ihre Anmeldungen und Sie können sich hinsetzen und sehen wie Ihre Liste wächst.
<G-vec00167-002-s711><grow_up.aufwachsen><en> Benchmark Email will keep track of your signups and you will be able to sit back and watch your list grow.
<G-vec00167-002-s712><grow_up.aufwachsen><de> Genießen Sie den fantastischen Blick von der Dachterrasse und beobachten Sie, wie die Stadt weiter wächst.
<G-vec00167-002-s712><grow_up.aufwachsen><en> Enjoy the fantastic view from the roof terrace and watch the city continue to grow.
<G-vec00167-002-s713><grow_up.aufwachsen><de> Ich rufe euch auf, meinen Sohn anzubeten, damit eure Seele wächst und wahre Spiritualität erreicht.
<G-vec00167-002-s713><grow_up.aufwachsen><en> I am calling you to adore my Son so that your soul may grow and reach true spirituality.
<G-vec00167-002-s714><grow_up.aufwachsen><de> VR wächst schnell im Jahre 2018, weil die Technologie in einem Zustand ist, in dem sie Verbraucherpreis erreicht.
<G-vec00167-002-s714><grow_up.aufwachsen><en> VR will grow rapidly in 2018, because the technology is in a state where it reaches consumer price.
<G-vec00167-002-s715><grow_up.aufwachsen><de> Unternehmen, die aufkommende Technologien kommerziell nutzen wollen, gehören zum „Ökosystem“ eines sich entwickelnden Geschäfts, und je stärker sie die Netzwerke des Ökosystems nutzen können, desto schneller wächst der Markt für ihre Produkte.
<G-vec00167-002-s715><grow_up.aufwachsen><en> Businesses looking to commercialise emerging technologies are part of a developing business ‘ecosystem’, and the stronger they can exploit the networks within the ecosystem, the faster the market for their products will grow.
<G-vec00167-002-s716><grow_up.aufwachsen><de> PPP Feminisiert wächst während der Blütephase überdurchschnittlich stark.
<G-vec00167-002-s716><grow_up.aufwachsen><en> PPP Feminized will grow substantially during the flowering phase.
<G-vec00167-002-s717><grow_up.aufwachsen><de> Seegras wächst in vielen flachen, sandigen Küstengewässern der Erde - an der Küste des Südchinesischen Meeres oder der USA und im Wattenmeer an der Nordsee.
<G-vec00167-002-s717><grow_up.aufwachsen><en> Seagrasses grow in many shallow and sandy coastal waters around the globe – in the South China Sea, the USA, and the Wadden Sea, part of the North Sea.
<G-vec00167-002-s718><grow_up.aufwachsen><de> Es wächst nicht nur hässlich, es schmeckt auch absolut erfolglos.
<G-vec00167-002-s718><grow_up.aufwachsen><en> Not only does it grow ugly, it also tastes absolutely unsuccessful.
<G-vec00167-002-s719><grow_up.aufwachsen><de> Wenn dieses Regime nicht eingehalten wird, werden die Sämlinge träge und schwach - es ist unwahrscheinlich, dass ein fruchtbarer Strauch daraus wächst.
<G-vec00167-002-s719><grow_up.aufwachsen><en> If this regime is not respected, the seedlings will become lethargic and weak - it is unlikely that a fertile shrub will grow out of it.
<G-vec00167-002-s720><grow_up.aufwachsen><de> Baumwolle wächst nicht an einem Baum, sondern an Pflanzen auf großen Flächen.
<G-vec00167-002-s720><grow_up.aufwachsen><en> Cotton does not grow on a tree, but on plants on large surfaces.
<G-vec00167-002-s721><grow_up.aufwachsen><de> Dazwischen laufen gut gepflegte Kühe umher, die das bisschen Rasen, das hier wächst, kurz halten.
<G-vec00167-002-s721><grow_up.aufwachsen><en> In between, well-groomed cows walk around, keeping the little lawn short that grow here.
