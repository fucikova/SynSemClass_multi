<G-vec00510-002-s114><grow.aufwachsen><de> Jedes Kind verdient es, in einer friedlichen Umgebung aufzuwachsen.
<G-vec00510-002-s114><grow.aufwachsen><en> Every child deserves to grow up in a peaceful environment.
<G-vec00510-002-s115><grow.aufwachsen><de> Bröckchen für Kätzchen und Welpen sind zum Beispiel kleiner, aber ebenfalls reich an wichtigen Nährstoffen, die junge Tiere brauchen, um stark und gesund aufzuwachsen.
<G-vec00510-002-s115><grow.aufwachsen><en> But it is also extra rich in nutrients that are especially important for young animals in order to grow up strong and healthy.
<G-vec00510-002-s116><grow.aufwachsen><de> Dort erhalten sie die notwendige Zuwendung und Fürsorge, um aufzuwachsen und wieder Freude am Leben zu finden.
<G-vec00510-002-s116><grow.aufwachsen><en> There they receive the attention and care they need to grow and to learn to smile again.
<G-vec00510-002-s117><grow.aufwachsen><de> Denn sie war davon überzeugt, daß die Kinder, um sicher und gut aufzuwachsen, eine gesunde und geeinte, großmütige und festgefügte Familie brauchen.
<G-vec00510-002-s117><grow.aufwachsen><en> She was convinced that in order for children to grow up sure of themselves and strong, they needed a family that was healthy and united, generous and stable.
<G-vec00510-002-s118><grow.aufwachsen><de> Die Zukunft ist allerdings gerade ein großes Fragezeichen: Ich überlege oft, ob ich es besser gefunden hätte in Italien oder in London aufzuwachsen und was besser für Alice ist.
<G-vec00510-002-s118><grow.aufwachsen><en> The future is a big question mark: I often wonder whether I would have preferred to grow up in Italy or London and what would be better for her.
<G-vec00510-002-s119><grow.aufwachsen><de> Kinder brauchen beide Elternteile, um sich gesund zu entwickeln und aufzuwachsen.
<G-vec00510-002-s119><grow.aufwachsen><en> Children need both parents to evolve and grow in a healthy way.
<G-vec00510-002-s120><grow.aufwachsen><de> Ich erinnere mich, zu denken, wie ich nicht warten könnte, um aufzuwachsen.
<G-vec00510-002-s120><grow.aufwachsen><en> I remember thinking how I couldn't wait to grow up.
<G-vec00510-002-s121><grow.aufwachsen><de> Schwangeren Frauen oder Frauen mit Kindern unter 3 Jahren wird deshalb beim Eintritt in das Gefängnis gesagt, dass es für das Kind nicht gut ist, hinter Gittern aufzuwachsen, und ihnen wird die Möglichkeit angeboten, das Kind an Familienmitglieder abzugeben.
<G-vec00510-002-s121><grow.aufwachsen><en> Thus, pregnant women or women with children under 3 are told upon entry to the prison that it isn't good for the child to grow up behind bars, and options are given for them to send the child off to family members.
<G-vec00510-002-s122><grow.aufwachsen><de> Dies erfordert tägliche Arbeit an sich selbst, aber es ist notwendig, wenn wir dem Kind helfen wollen, als unabhängige, glückliche, autarke Person aufzuwachsen.
<G-vec00510-002-s122><grow.aufwachsen><en> This requires daily work on yourself, but it is necessary if we want to help the child grow up as an independent, happy, self-sufficient person.
<G-vec00510-002-s123><grow.aufwachsen><de> Biete eine große Anzahl von Verstecken an, wie hohe Vegetation, damit einige der Brut in der Lage sind, aufzuwachsen.
<G-vec00510-002-s123><grow.aufwachsen><en> Provide a lot of hidden places, like high vegetation so some fry will be able to grow.
<G-vec00510-002-s124><grow.aufwachsen><de> Das Traumkind schläft nur auf besten und weichsten Materialien, um gesund und ausgeruht in einer sauberen Welt aufzuwachsen, die auch noch schön und sauber für nächste Generationen ist.
<G-vec00510-002-s124><grow.aufwachsen><en> The dreamgirl sleeps only on the best and softest materials to grow healthy and relaxed in a clean world that is also beautiful and well-groomed for next generations.
<G-vec00510-002-s125><grow.aufwachsen><de> Jedoch weist Razz darauf hin, dass es nicht der beste Platz ist, aufzuwachsen, anzeigend, dass die RNK noch viel Arbeit zu tun hat, wahrscheinlich rund um Supermutanten, Ghulen, plündernden Banden und der großen Mengen der Strahlung.
<G-vec00510-002-s125><grow.aufwachsen><en> However, dialogue with Razz from Fallout: New Vegas suggests it is not the best place to grow up, indicating the NCR still has some work to do, likely revolving around super mutants, ghouls, and raiding gangs.
<G-vec00510-002-s126><grow.aufwachsen><de> Nachdem ich keuchte und 'nein' sagte begann ich langsam zurück zu gehen und die ganze Zeit sagte ich, nein ich kann jetzt noch nicht gehen, ich möchte meinen Kindern helfen aufzuwachsen.
<G-vec00510-002-s126><grow.aufwachsen><en> After I gasped and said 'no' I started slowly going back the whole time I was saying, No, I can't leave yet, I want to help my kids grow up.
<G-vec00510-002-s127><grow.aufwachsen><de> Ein Leben, wo das Kind darauf hoffen kann, aufzuwachsen, eine Ausbildung zu erhalten und ein aktives Mitglied der Gesellschaft zu werden.
<G-vec00510-002-s127><grow.aufwachsen><en> One where the child can hope to grow up, get an education and become a contributing member to society.
<G-vec00510-002-s128><grow.aufwachsen><de> Es war nie gut für mich, getrennt von meinen Eltern aufzuwachsen.
<G-vec00510-002-s128><grow.aufwachsen><en> It was never good for me to grow up apart from my family.
<G-vec00510-002-s129><grow.aufwachsen><de> Kinder, die gezwungen waren, ohne ihre Mutter oder ihren Vater aufzuwachsen.
<G-vec00510-002-s129><grow.aufwachsen><en> Children who were forced to grow up without their mother or their father.
<G-vec00510-002-s130><grow.aufwachsen><de> Auch nach 40 Jahren fühlen wir uns dem Dienst an der Waldorfpädagogik verpflichtet und werden, solange es die Aufgaben als notwendig erscheinen lassen, weiter dafür arbeiten, dass Kindern eine reelle Chance gegeben wird, in Achtung ihres Menschseins aufzuwachsen.
<G-vec00510-002-s130><grow.aufwachsen><en> Even after 40 years, the Friends are committed to the serve Waldorf education. As long as it is necessary the association will continue to work to ensure that children will be given a real chance to education and grow up in conditions that value their dignity.
<G-vec00510-002-s131><grow.aufwachsen><de> Obwohl es einen großen Unterschied machte, in einer Stadt oder am Lande aufzuwachsen, war doch vieles gleich.
<G-vec00510-002-s131><grow.aufwachsen><en> To grow up in the city or in a small village means to be worlds apart. But some things were the same.
<G-vec00510-002-s132><grow.aufwachsen><de> Er wandert hinüber zum Jenseits und realisiert jedoch, daß es die Gelegenheit bekommen hat nach Gottes Plan weiterzuleben und aufzuwachsen, anstatt vielleicht nicht an Gott zu glauben und vom rechten Weg abzukommen.
<G-vec00510-002-s132><grow.aufwachsen><en> However, when he passes to the afterlife and realises that had he been granted the opportunity to live on and grow up, he may have decided not to believe in God Almighty or to stray from His Path.
