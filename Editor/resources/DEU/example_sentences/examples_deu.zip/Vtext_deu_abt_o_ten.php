<G-vec00365-002-s060><kill.abtöten><de> Weitere Umgebungsbedingungen wie Sonneneinstrahlung, also UV-Licht, das Viren bekanntermaßen abtötet, oder Luftfeuchtigkeit wurden nicht berücksichtigt.
<G-vec00365-002-s060><kill.abtöten><en> Other environmental conditions, such as sunlight (i.e. UV light which is known to kill viruses) or humidity were not taken into account.
<G-vec00365-002-s061><kill.abtöten><de> Im Winter muss man nur auf Frost achten, der die Pflanze abtötet.
<G-vec00365-002-s061><kill.abtöten><en> In winter you only have to watch out for frost, which will kill the plant.
<G-vec00365-002-s062><kill.abtöten><de> Kürzlich haben wir unsere Innovationskraft auf Ölquellen ausgeweitet und eine Methode für den Einsatz von Peressigsäure entwickelt, die bei minimalen Auswirkungen auf die Umwelt Bakterien abtötet und die Wasserqualität verbessert.
<G-vec00365-002-s062><kill.abtöten><en> Recently, we’ve expanded our innovation to oil wells – where we found a way to use peracetic acid to kill bacteria and improve water quality, with minimal impact to the environment.
<G-vec00365-002-s063><kill.abtöten><de> Es wurde kürzlich nachgewiesen, dass UVC sogar COVID-19-Viren abtötet.
<G-vec00365-002-s063><kill.abtöten><en> UVC has recently been proven to kill even COVID-19 viruses.
<G-vec00365-002-s064><kill.abtöten><de> Es könnte daran liegen, dass die hohe Salzkonzentration Bakterien abtötet, oder vielleicht versorgt das Seesalz die Haut mit Mineralien, die ihre Heilung positiv beeinflussen.
<G-vec00365-002-s064><kill.abtöten><en> It may be that the high salt concentration helps kill off bacteria on your face, or that the sea salt replenishes minerals that help heal the skin.
<G-vec00365-002-s065><kill.abtöten><de> Die Wirkung von Grapefruit Samenextrakt ist primär darauf zurückführbar, dass es die Zellwände von Bakterien und Pilzen angreift und diese so zerstört und abtötet.
<G-vec00365-002-s065><kill.abtöten><en> The effects of grapefruit seed extract are due to the fact that it can attack the cell walls of bacteria and fungi and thus destroy and kill them.
<G-vec00365-002-s066><kill.abtöten><de> Auch wenn die Hitze wahrscheinlich die meisten Verunreinigungen auf der Schale abtötet, ist es immer hygienischer, mit sauberen Nüssen anzufangen.
<G-vec00365-002-s066><kill.abtöten><en> Even though the heat will likely kill off most of the contaminants on the walnut shell, starting off with clean walnuts is always more sanitary.
<G-vec00365-002-s067><kill.abtöten><de> Dies bedeutet, dass es Parasiten wie Flöhe abtötet, die auf der Haut oder im Fell von Tieren leben.
<G-vec00365-002-s067><kill.abtöten><en> This means that it will kill parasites that live on the skin or in the fur of animals, such as fleas.
<G-vec00365-002-s068><kill.abtöten><de> Unsere Lösung heißt LAVA™, dabei handelt es sich um eine Antigeruchsbehandlung, die kein Biozidpro-dukt darstellt und daher auch keine lebenden Organismen abtötet.
<G-vec00365-002-s068><kill.abtöten><en> Our solution is called LAVA™, an anti-odor treatment that is not a biocidal product, and therefore, does not kill any living organisms.
<G-vec00486-002-s021><inhibit.abtöten><de> Keine reizenden Inhaltsstoffe, die die Poren verstopfen, die 89% natürliche Formel nutzt Präbiotika, um die Flora der Haut zu unterstützen, pflanzliche Wirkstoffe, wie Aloe Vero und Sonnenblumen, um die Haut zu glätten und Alum, um Bakterien abzutöten.
<G-vec00486-002-s021><inhibit.abtöten><en> Free from pore clogging and irritating ingredients, the 89% organic formula utilises Prebiotics to support the skin's good flora, plant actives such as Aloe Vera and Sunflower to soothe skin, and Alum to inhibit bacterial growth.
