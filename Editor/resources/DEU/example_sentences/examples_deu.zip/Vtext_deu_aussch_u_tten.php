<G-vec00147-002-s069><pour.ausschütten><de> 31 Ausschütten will ich also meinen Zorn über sie, aufreiben sie mit meines grimmes Feuer, ihr Betragen auf ihren Kopf hinlegen, spricht der Herr Jehova.
<G-vec00147-002-s069><pour.ausschütten><en> 31 So I will pour out my wrath on them and consume them with my fiery anger, bringing down on their own heads all they have done, declares the Sovereign Lord.”
<G-vec00147-002-s070><pour.ausschütten><de> Wie zahlreich sind die Seelen in Kummer, Angst oder Einsamkeit, die nur das eine nötig haben, nämlich ein Wesen zu finden, vor dem sie ihre Empfindungen ausschütten können, ohne daß die Welt sie hört.
<G-vec00147-002-s070><pour.ausschütten><en> How many are the souls, in distress, anxiety or loneliness, whose one need is to find a being to whom they can pour out their feelings unheard by the world?
<G-vec00147-002-s071><pour.ausschütten><de> 26 Aber dies ist nicht alles; ihr müßt eure Seele in euren aKammern und an euren verborgenen Plätzen und in eurer Wildnis ausschütten.
<G-vec00147-002-s071><pour.ausschütten><en> “But this is not all; ye must pour out your souls in your closets, and your secret places, and in your wilderness.
<G-vec00147-002-s072><pour.ausschütten><de> Wichtig!In dieser Situation ist es nicht notwendig, ein Zisternenwasser zum Testen Abfall zu verwenden.Wenn Sie den Griff ziehen - Strom wird nicht aufhören, und wenn die verstopfte Toilette - was vergessen Sie, Schlammströme werden auf dem Boden ausschütten, so dass der Geruch nicht violett.
<G-vec00147-002-s072><pour.ausschütten><en> Important!In this situation it is not necessary to use a cistern for testing waste water.If you pull the handle - torrent will not stop, and if the clogged toilet - what do you forget, mud flows will pour out on the floor, making the smell does not violet.
<G-vec00147-002-s073><pour.ausschütten><de> In Abwesenheit eines Partners möchten Sie manchmal die Seele Ihres Kindes ausschütten, die Unterstützung und das Mitgefühl Ihres Nächsten spüren.
<G-vec00147-002-s073><pour.ausschütten><en> In the absence of a partner, sometimes you really want to pour out your child's soul, feel the support and compassion of your neighbor.
<G-vec00147-002-s074><pour.ausschütten><de> 10 Die Fürsten Judas sind denen gleich, welche die Grenze verrücken; über sie will ich meinen Grimm ausschütten wie Wasser.
<G-vec00147-002-s074><pour.ausschütten><en> 5:10 The princes of Judah were like them that k remove the bound: [therefore] I will pour out my wrath upon them like water.
<G-vec00147-002-s075><pour.ausschütten><de> Wenn andere Fitnessstudenten ihren siebten Schweiß ausschütten, aber immer noch nicht die gewünschte Silhouette erreichen können, wird immer eine Gruppe von Einheiten aufgedeckt, die die gewünschten Ergebnisse viel schneller erhalten.
<G-vec00147-002-s075><pour.ausschütten><en> When other gym goers pour out their seventh sweat, but still can not reach the desired silhouette, a group of units will always be revealed, which receives the desired results much faster.
<G-vec00147-002-s076><pour.ausschütten><de> Sucht mich und ich werde Meinen Geist über euch ausschütten.
<G-vec00147-002-s076><pour.ausschütten><en> Seek Me, and I will pour out My Spirit upon you.
<G-vec00147-002-s077><pour.ausschütten><de> Wenn andere Fitnessstudenten ihren siebten Schweiß ausschütten, aber trotzdem nicht die gewünschte Konstruktion erhalten können, wird es immer eine Gruppe von Menschen geben, die viel schneller positive Ergebnisse erhalten.
<G-vec00147-002-s077><pour.ausschütten><en> When other gym goers pour out their seventh sweat, but despite that they can not continue to receive the desired construction, there will always be a group of people who receive positive results much faster.
<G-vec00147-002-s078><pour.ausschütten><de> 10 Die Oberen von Juda sind denen gleich, die die Grenze verrücken; darum will ich meinen Zorn über sie ausschütten wie Wasser.
<G-vec00147-002-s078><pour.ausschütten><en> 10 The rulers of Judah act like men who move the boundary stone; I shall pour my wrath out on them like a flood.
<G-vec00147-002-s079><pour.ausschütten><de> 5 Daran will ich denken, und meine Seele in mir ausschütten, wie ich dahinzog im Gedränge, mit ihnen feierlich dahinschritt zum Haus Gottes unter lautem Jubel und Lobgesang, in der feiernden Menge.
<G-vec00147-002-s079><pour.ausschütten><en> 4 When I remember these things, I pour out my soul in me: for I had gone with the multitude, I went with them to the house of God, with the voice of joy and praise, with a multitude that kept holyday.
<G-vec00147-002-s080><pour.ausschütten><de> 19 Oder so ich Pestilenz in das Land schicken und meinen Grimm über dasselbe ausschütten würde mit Blutvergießen, also daß ich Menschen und Vieh ausrottete, 20 und Noah, Daniel und Hiob wären darin: so wahr ich lebe, spricht der HERR HERR, würden sie weder Söhne noch Töchter, sondern allein ihre eigene Seele durch ihre Gerechtigkeit erretten.
<G-vec00147-002-s080><pour.ausschütten><en> 19 Or [if] I send a pestilence into that land, and pour out my fury upon it in blood, to cut off from it man and beast, 20 and Noah, Daniel, and Job should be in it, [as] I live, saith the Lord Jehovah, they should deliver neither son nor daughter: they should [but] deliver their own souls by their righteousness.
<G-vec00147-002-s461><pour.ausschütten><de> 6 Schütte deinen Grimm auf die Völker, die dich nicht kennen, und auf die Königreiche, die deinen Namen nicht anrufen.
<G-vec00147-002-s461><pour.ausschütten><en> 6 Pour out thy wrath upon the nations that have not known thee: and upon the kingdoms that have not called upon thy name.
<G-vec00147-002-s462><pour.ausschütten><de> Schütte das Wasser und den Zucker in die Pfanne und rühre beides unter die restlichen Zutaten.
<G-vec00147-002-s462><pour.ausschütten><en> Pour the Merlot, balsamic vinegar, and Worcestershire sauce into the saucepan.
<G-vec00147-002-s463><pour.ausschütten><de> 3und nimm den Ölkrug und schütte es auf sein Haupt und sprich: So sagt der HERR: Ich habe dich zum König über Israel gesalbt.
<G-vec00147-002-s463><pour.ausschütten><en> And take the box of oil and pour it on his head and say, thus sayeth the LORD: I have anointed thee to be king over Israel.
<G-vec00147-002-s464><pour.ausschütten><de> 3 und nimm den Ölkrug und schütte es auf sein Haupt und sprich: So sagt der HERRHERR: Ich habe dich zum KönigKönig über Israel gesalbt.
<G-vec00147-002-s464><pour.ausschütten><en> 3 Then take the box of oiloil, and pour it on his headhead, and saysay, Thus saithsaith the LORDthe LORD, I have anointedanointed thee king over Israel.
<G-vec00147-002-s465><pour.ausschütten><de> Schütte die drei Tassen Wasser in einen mittelgroßen Topf, gib die Kartoffelstücken hinzu und bringe es zum kochen.
<G-vec00147-002-s465><pour.ausschütten><en> Pour the 3 cups water into a medium-sized pot and add the potato cubes. Bring to boil.
<G-vec00147-002-s466><pour.ausschütten><de> Vertraue auf ihn allezeit, o Volk, schütte dein Herz vor ihm aus.
<G-vec00147-002-s466><pour.ausschütten><en> Trust in him at all times, ye people; Pour out your heart before him: God is a refuge for us.
<G-vec00147-002-s467><pour.ausschütten><de> Lasse das Wasser nun auf kleiner Flamme köcheln, rühre es im Kreis um und schütte das Ei in die Mitte des Strudels.
<G-vec00147-002-s467><pour.ausschütten><en> Bring the water to a simmer and carefully pour the egg into the water.
<G-vec00147-002-s468><pour.ausschütten><de> Schütte die Creme in den Topf mit dem Blumenkohl und den Kartoffeln und streue den geschnittenen Schnittlauch über (ich verwende hierfür eine Schere) und mische es vorsichtig miteinander.
<G-vec00147-002-s468><pour.ausschütten><en> Pour the cream into the pot with the cauli and potatoes, add the chopped chives (I use scissors to do the job) and gently mix everything.
<G-vec00147-002-s469><pour.ausschütten><de> Schütte den dunkelsten Braunton in ein Tablett oder eine seichte Schüssel.
<G-vec00147-002-s469><pour.ausschütten><en> Pour the darkest shade of brown you have into a tray or shallow dish.
<G-vec00147-002-s470><pour.ausschütten><de> Wenn du Flammen oben am Anzündkamin erkennst, schütte die Briketts vorsichtig in die Holzkohlekammer und verteile sie gleichmäßig.
<G-vec00147-002-s470><pour.ausschütten><en> When you see flames at the top of the Chimney Starter, pour the briquettes carefully from the Chimney Starter into the charcoal chamber and spread coals around evenly.
<G-vec00147-002-s471><pour.ausschütten><de> Schütte die gemischte Farbe in das Innere der Flasche oder Vase.
<G-vec00147-002-s471><pour.ausschütten><en> Pour the mixed paint into the interior of the bottle or vase.
<G-vec00147-002-s472><pour.ausschütten><de> Mach eine Vertiefung in der Mitte der trockenen Zutaten und schütte ein Drittel der Eimischung hinein.
<G-vec00147-002-s472><pour.ausschütten><en> Form a well in the middle of the dry ingredients and pour one-third of the egg yolk mixture in the center.
<G-vec00147-002-s473><pour.ausschütten><de> Schütte sie in den Tontopf und rühre sie mit einem langstieligen Löffel ein.
<G-vec00147-002-s473><pour.ausschütten><en> Pour it into the crock and stir it into the mixture with a long-handled spoon.
<G-vec00147-002-s474><pour.ausschütten><de> Anschließend schütte den Essig hinzu, die Miesmuscheln, 3 Löffel Flüssigkeit, um die Miesmuscheln zu öffnen und lasse sie für mindestens 5 Minuten auf niedriger Stufe kochen.
<G-vec00147-002-s474><pour.ausschütten><en> Then pour the vinegar, add the mussels and to boil at least 5 minutes over low heat. Add the salt.
<G-vec00147-002-s475><pour.ausschütten><de> Leg ein feinmaschiges Sieb über eine Schüssel oder einen Messbecher aus Glas und schütte den Inhalt des Mixers durch das Sieb.
<G-vec00147-002-s475><pour.ausschütten><en> Place a fine mesh sieve over a bowl or a glass measuring cup. Pour the contents of the blender through the sieve.
<G-vec00147-002-s476><pour.ausschütten><de> Schütte genug Kohlen oder Briketts aus, um eine gleichmäßige Lage auf dem Boden deines Grills hinzubekommen.
<G-vec00147-002-s476><pour.ausschütten><en> Pour out enough charcoal or briquettes to form an even layer on the bottom of your grill.
<G-vec00147-002-s477><pour.ausschütten><de> 6 Schütte deinen Grimm auf die Heiden, die dich nicht kennen, und auf die Königreiche, die deinen Namen nicht anrufen.
<G-vec00147-002-s477><pour.ausschütten><en> 6 Pour out your wrath on the nations that don't know you; on the kingdoms that don't call on your name;
<G-vec00147-002-s478><pour.ausschütten><de> Spritze oder schütte den Apfelweinessig auf dein Haar, nachdem du es gewaschen hast, und lasse ihn für etwa 10 Minuten einwirken.
<G-vec00147-002-s478><pour.ausschütten><en> Spritz or pour the apple cider vinegar onto into your hair after you wash it and allow it to sit for about 10 minutes.
<G-vec00147-002-s479><pour.ausschütten><de> 3 und nimm den Ölkrug und schütte es auf sein Haupt und sprich: So sagt der HERR: Ich habe dich zum König über Israel gesalbt.
<G-vec00147-002-s479><pour.ausschütten><en> 3 Then take the flask and pour the oil on his head and declare, ‘This is what the LORD says: I anoint you king over Israel.’
<G-vec00147-002-s499><pour.ausschütten><de> Rezeptur: Schütten Sie vier Esslöffel Blüten in einen Liter kochendes Wasser.
<G-vec00147-002-s499><pour.ausschütten><en> Recipe:Pour four tablespoons of flowers in one liter of boiling water.
<G-vec00147-002-s500><pour.ausschütten><de> Filtrieren Sie das Gemisch mit dem Filterpapier und schütten Sie das Filtrat in Petrischalen.
<G-vec00147-002-s500><pour.ausschütten><en> Filter using filter paper and pour the filtrate into Petri dishes.
<G-vec00147-002-s501><pour.ausschütten><de> Schütten Sie die Lösung in die Flasche zurück - Sie können die Lösung mehrmals verwenden.
<G-vec00147-002-s501><pour.ausschütten><en> Pour the solution back into the bottle - you can use it many times.
<G-vec00147-002-s502><pour.ausschütten><de> Unterbrechen Sie den Garvorgang, und verwenden Sie eine Handvoll Küchenpapier, um das Öl vom Boden der Pfanne aufzusaugen, oder schütten Sie überschüssiges Öl weg.
<G-vec00147-002-s502><pour.ausschütten><en> Please stop cooking and use a whole handful of kitchen paper to soak up the oil on the bottom of the pan or pour off any excess oil.
<G-vec00147-002-s503><pour.ausschütten><de> Schütten Sie falls erforderlich Weichspüler in das Fach .
<G-vec00147-002-s503><pour.ausschütten><en> Pour fabric softener into the compartment if necessary .
<G-vec00147-002-s504><pour.ausschütten><de> Schütten Sie die Tomatensoße in eine große feuerfeste Form.
<G-vec00147-002-s504><pour.ausschütten><en> Take out a large baking tray or dish and pour in the tomato sauce.
