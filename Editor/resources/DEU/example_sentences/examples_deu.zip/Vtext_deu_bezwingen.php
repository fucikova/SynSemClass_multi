<G-vec00169-001-s042><reclaim.bezwingen><de> Kämpfen Sie sich durch Ihre persönliche Liedersammlung, entdecken Sie Gegenstände, passen Sie Ihr Schiff an und bezwingen Sie Boss-Gegner, um die Symphony of Souls zu befreien und Ihre Musik...
<G-vec00169-001-s042><reclaim.bezwingen><en> You must battle through your own song collection, discover items, customize your ship and fight boss enemies to liberate the Symphony of Souls and reclaim your music!
<G-vec00279-002-s100><defeat.bezwingen><de> Bezwingen Sie den zweitgrößten Fluss Österreichs, die Mur, und kämpfen Sie gemeinsam mit dem Paddel gegen Stromschnellen und das wilde Wasser.
<G-vec00279-002-s100><defeat.bezwingen><en> Defeat Austria’s second biggest river, the Mur, and fight with your paddle against the rapids and the white water.
<G-vec00279-002-s101><defeat.bezwingen><de> Beim anschließenden Turnier in Peking schied sie in der dritten Runde gegen Peng Shuai aus, nachdem sie zuvor Asaranka in einem längeren Match hatte bezwingen können.
<G-vec00279-002-s101><defeat.bezwingen><en> Following that, she went on to defeat Lucie Šafářová in the second round (marking her first back-to-back victory in 2013) before falling to Victoria Azarenka in the third round.[citation needed]
<G-vec00279-002-s102><defeat.bezwingen><de> Du brauchst also nicht online zu sein, um die Schatten zu bezwingen.
<G-vec00279-002-s102><defeat.bezwingen><en> No need to be online to defeat the shadows.
<G-vec00279-002-s103><defeat.bezwingen><de> Mein Ziel ist es, das Schiff zu zerstören, nicht einen Menschling im Zweikampf zu bezwingen.
<G-vec00279-002-s103><defeat.bezwingen><en> My goal is to destroy this ship, not defeat one human in combat.
<G-vec00279-002-s104><defeat.bezwingen><de> Drachen bevölkern den Himmel über der angestammten Heimat der Khajiit, und ihr werdet alles geben müssen, um sie zu bezwingen.
<G-vec00279-002-s104><defeat.bezwingen><en> Dragons roam the skies above the ancestral home of the Khajiit, and it’ll take everything you’ve got to defeat them.
<G-vec00279-002-s105><defeat.bezwingen><de> Er wurde in tragischer Weise zu einem Instrument der Geißel, genau dem Übel, das er einst zu bezwingen geschworen hatte.
<G-vec00279-002-s105><defeat.bezwingen><en> He was tragically reforged into an instrument of the Scourge, the evil he had once sworn to defeat.
<G-vec00279-002-s106><defeat.bezwingen><de> Setze deine strategischen Fähigkeiten ein, um Raumschiffe und Konstruktionen zu platzieren, damit du deine Gegner bezwingen kannst.
<G-vec00279-002-s106><defeat.bezwingen><en> Use your strategic skills to place your starships and space constructions and defeat your enemy.
<G-vec00279-002-s107><defeat.bezwingen><de> Dennoch äußert Tóta die Hoffnung, dass die in der politischen Mitte angesiedelten Gegner Orbáns nach Gewinn einer Mehrheit im Europäischen Parlament ihre Macht dazu nutzen würden, den ungarischen Ministerpräsidenten zu bezwingen und zu schwächen.
<G-vec00279-002-s107><defeat.bezwingen><en> Nonetheless, Tóta hopes that after securing a majority in the European Parliament, his centrist adversaries will use their power to defeat and weaken the Hungarian Prime Minister.
<G-vec00279-002-s108><defeat.bezwingen><de> Wenn du es bezwingen kannst, gilt die Prüfung als bestanden.
<G-vec00279-002-s108><defeat.bezwingen><en> If you defeat it, you’ll complete the trial.
<G-vec00279-002-s109><defeat.bezwingen><de> Nachdem es nach drei Dritteln 6:6 stand, konnte Tahiti Italien im Neunmeterschießen mit 3:1 bezwingen und den Finaleinzug bei der FIFA Beach-Soccer-Weltmeisterschaft Portugal 2015 feiern.
<G-vec00279-002-s109><defeat.bezwingen><en> Tahiti earned their first victory at the FIFA Beach Soccer World Cup Bahamas 2017 in dramatic fashion, surviving a late fightback to defeat Japan 4-3 in their second Group D encounter.
<G-vec00279-002-s110><defeat.bezwingen><de> Um die Gegner am Ende zu bezwingen, muss man zwischen linker und rechter Seite hin und herlaufen.
<G-vec00279-002-s110><defeat.bezwingen><en> To defeat the enemies at the end you have to walk between the left and right side two and fro.
<G-vec00279-002-s111><defeat.bezwingen><de> Hilf ihm, eine Armee aufzustellen und zu führen, um 7 Könige und Königinnen zu bezwingen, die das Land regieren.
<G-vec00279-002-s111><defeat.bezwingen><en> Your goal is to help Arthur create and command an army to defeat 7 kings and queens who rule the land.
<G-vec00279-002-s112><defeat.bezwingen><de> Polizei und Armee können den Roboter nicht bezwingen.
<G-vec00279-002-s112><defeat.bezwingen><en> Police and army cannot defeat the robot.
<G-vec00279-002-s113><defeat.bezwingen><de> Selbstverständlich müsst Ihr dafür zuerst den gegnerischen Abenteurer bezwingen.
<G-vec00279-002-s113><defeat.bezwingen><en> That’s of course, IF you are able to defeat the adventurer.
<G-vec00279-002-s114><defeat.bezwingen><de> Die Kräfte des Kapitals nutzen noch immer dieselben Taktiken, um uns zu bezwingen: Sie versuchen uns auseinanderzubringen, uns nach den alten national-staatlichen Grenzen und nach den neuen inneren Grenzen, die durch die jüngste Migrationswellen entstanden sind, zu trennen.
<G-vec00279-002-s114><defeat.bezwingen><en> In order to defeat us, the forces of Capital are still using the same tactics, trying to divide us across old nation-state borders, and the new internal borders caused by the latest wave of migration.
<G-vec00279-002-s115><defeat.bezwingen><de> Würde es ein Gegner sein, ich würde ihn auch mit bloßen Händen bezwingen, dessen war ich mir sicher.
<G-vec00279-002-s115><defeat.bezwingen><en> If it was an enemy i would defeat him with my bare hands, i was sure of this.
<G-vec00279-002-s116><defeat.bezwingen><de> Seitdem gibt es nichts und niemanden, was ein Volk wie das unsere bezwingen könnte.
<G-vec00279-002-s116><defeat.bezwingen><en> Since then, nothing and no one has been able or ever will be able to defeat our people.
<G-vec00279-002-s117><defeat.bezwingen><de> Der Spieler schlüpft in die Rolle des Joey, ein einsamer Überlebender, der gegen eine Horde modriger, unerbittlicher Zombies antreten muss – um die untoten Massen zu bezwingen müssen die Spieler ihre Finger einsetzen, um sie zu schlenzen und zu zerschmettern, bis sie un-untot sind.
<G-vec00279-002-s117><defeat.bezwingen><en> The game casts players as Joey, a lone survivor pit against a herd of writhing, unrelenting zombies - to defeat the undead masses, players must use their fingers to flick and smash them until they're un-undead.
<G-vec00279-002-s118><defeat.bezwingen><de> Verwende dein Gold, um Soldaten zu trainieren und Gegner zu bezwingen.
<G-vec00279-002-s118><defeat.bezwingen><en> Use the gold to train warriors and defeat your enemy.
<G-vec00279-002-s014><outlast.bezwingen><de> Ein entfesselter Glaubenskrieger kann jede Waffe sowie seine Stärke und Willenskraft einsetzen, um Feinde mit Macht und Magie zu bezwingen.
<G-vec00279-002-s014><outlast.bezwingen><en> An unfettered Crusader can use any weapon as well as Strength and Willpower to outlast their enemy with magic and might.
<G-vec00279-002-s145><overcome.bezwingen><de> Doch der Affe hat seinen Meister gefunden und kann die göttlichen Kräfte Buddhas nicht bezwingen.
<G-vec00279-002-s145><overcome.bezwingen><en> But the Monkey had met his match and could not overcome the Buddha’s divine powers.
<G-vec00279-002-s146><overcome.bezwingen><de> Europa braucht eine große Anpassungs-Fähigkeit um die jetzigen Herausforderungen zu bezwingen.
<G-vec00279-002-s146><overcome.bezwingen><en> Europe needs to be at its best in terms of ability to adapt, in order to overcome its present challenges.
<G-vec00279-002-s147><overcome.bezwingen><de> Doch als ein neuer Schurke auf den Plan tritt, können die Unglaublichen ihn nur gemeinsam bezwingen.
<G-vec00279-002-s147><overcome.bezwingen><en> But when a new villain hatches a dangerous plot, only the Incredibles can overcome it together.
<G-vec00279-002-s148><overcome.bezwingen><de> Neben seiner Begeisterung und seinem Charme zeichnet Cole auch sein unerschütterlicher Glaube daran aus, alles und jeden bezwingen zu können, egal wie schlecht die Chancen stehen.
<G-vec00279-002-s148><overcome.bezwingen><en> Along with his enthusiasm and charm, Cole is supremely confident in his ability to overcome anything, regardless of the odds, and he hasn't been proven wrong yet.
<G-vec00279-002-s149><overcome.bezwingen><de> Bezwingen Sie jedes Terrain mit einer Enduro, die in ihrer praktischen Ausstattung keine Wünsche offen lässt.
<G-vec00279-002-s149><overcome.bezwingen><en> Overcome every type of terrain with an enduro bike whose practical equipment features leave nothing to be desired.
<G-vec00279-002-s150><overcome.bezwingen><de> Spiegelungen sind unvermeidbar, die Farben wirken ausgewaschen, da der Bildschirm auch an schattigen Tagen nicht das Umgebungslicht bezwingen kann.
<G-vec00279-002-s150><overcome.bezwingen><en> Glare is unavoidable and colors appear washed out as the display cannot overcome ambient light on even an overcast day.
<G-vec00279-002-s151><overcome.bezwingen><de> Diesen 'geistigen' Widerstand gilt es zu bezwingen.
<G-vec00279-002-s151><overcome.bezwingen><en> This subconscious ‘learned’ resistance I wish to overcome.
<G-vec00279-002-s152><overcome.bezwingen><de> Der Mentalcoach und Bergsteiger lebt den Traum vieler Bergsteiger, die sieben höchsten Berge der Erde zu bezwingen.
<G-vec00279-002-s152><overcome.bezwingen><en> The mental coach and mountaineer is living the dream of many climbers, to overcome the seven highest peaks of the earth.
<G-vec00279-002-s153><overcome.bezwingen><de> 19 Sie werden wohl gegen dich kämpfen, trotzdem werden sie dich nicht bezwingen.
<G-vec00279-002-s153><overcome.bezwingen><en> 19 They will fight against you. But they will not overcome you.
<G-vec00279-002-s154><overcome.bezwingen><de> Niemand ist fähig sie zu bezwingen.
<G-vec00279-002-s154><overcome.bezwingen><en> No one can overcome it or overpower it.
<G-vec00279-002-s155><overcome.bezwingen><de> Nach einem vernichtenden Angriff auf die Erde müssen Sie als Captain Reyes, einem Stufe 1-Spezialeinsatz-Piloten, die verbliebenen Koalitionstruppen gegen einen grausamen Feind anführen, während Sie versuchen, die tödlichen, extremen Umstände des Weltraums zu bezwingen.
<G-vec00279-002-s155><overcome.bezwingen><en> After a devastating attack on earth, as Captain Reyes, a Tier 1 Special Operations pilot, you must lead the remaining coalition forces against a relentless enemy, while trying to overcome the deadly, extreme environments of space.
<G-vec00279-002-s156><overcome.bezwingen><de> Und kein Körper konnte die Realität je bezwingen.
<G-vec00279-002-s156><overcome.bezwingen><en> And no body could ever overcome reality.
<G-vec00279-002-s157><overcome.bezwingen><de> Als Spieler musst du dich deinen Gegnern strategisch nähern, ihre Stärken und Schwächen abschätzen und deine Jedi-Ausbildung geschickt einsetzen, um sie zu bezwingen und die Geheimnisse zu lüften, auf die du im Laufe deiner Reise stößt.
<G-vec00279-002-s157><overcome.bezwingen><en> Players will need to approach enemies strategically, sizing up strengths and weaknesses while cleverly utilizing your Jedi training to overcome your opponents and solve the mysteries that lay in your path.
<G-vec00279-002-s158><overcome.bezwingen><de> Deshalb wird der Teufel alles tun um die Seelen, die Gott geweiht sind, zu bezwingen, denn auf diese Art wird es dem Teufel gelingen, das die treuen Seelen von ihren Fuehrern verlassen werden, und darum wird er sie um so einfacher erobern.
<G-vec00279-002-s158><overcome.bezwingen><en> Thus the devil does everything to overcome souls consecrated to God, because in this way the devil will succeed in leaving the souls of the faithful abandoned by their leaders, thereby the more easily to seize them.
<G-vec00279-002-s159><overcome.bezwingen><de> Es dauert sehr lange, diesen Gegner zu bezwingen.
<G-vec00279-002-s159><overcome.bezwingen><en> It takes a very long time to overcome this opponent.
<G-vec00279-002-s160><overcome.bezwingen><de> Wer dabei Höhenangst hatte, wurde von der gesamten Gruppe unterstützt und ermutigt, die eigene Angst zu bezwingen.
<G-vec00279-002-s160><overcome.bezwingen><en> Those who suffered from a fear of heights were supported and encouraged to overcome their fears by the entire group.
<G-vec00279-002-s161><overcome.bezwingen><de> Um ihren Gegner zu bezwingen, müssen die zwei Mercedes-Benz Stars Können, Präzision und eine Leidenschaft für Perfektion zeigen.
<G-vec00279-002-s161><overcome.bezwingen><en> The two Mercedes-Benz stars will need to demonstrate skill, precision and a passion for perfection to overcome their opponent.
<G-vec00279-002-s162><overcome.bezwingen><de> Die beiden berührten sich, als der Niederländer die Türe zumachte und trotz einer tollen Ausfahrt aus der letzten Schikane konnte Rea einen tapferen van der Mark nicht bezwingen, der sein damals bestes Ergebnis der Saison erzielte.
<G-vec00279-002-s162><overcome.bezwingen><en> The two touched as the Dutchman closed the door and despite having a great exit of the final chicane, Rea couldn’t overcome a valiant van der Mark, who took his then-best result of the season.
