<G-vec00308-002-s075><locate.ausfinden><de> Sie können einfach mit der Eingabe des Makronamens beginnen, um potenzielle Übereinstimmungen zu finden, die Liste nach Kategorien oder Berechtigungen filtern oder das gewünschte Makro manuell ausfindig machen.
<G-vec00308-002-s075><locate.ausfinden><en> To select macros, you can begin typing the name of the macro to locate potential matches, filter the list by Categories or Permissions, or you can scroll through the list to locate the macro you need.
<G-vec00308-002-s076><locate.ausfinden><de> Es geht nicht nur darum, die talentiertesten Mitarbeiter ausfindig zu machen, sondern auch darum, Teams um sie herum zu bilden und dabei sicherzustellen, dass die Kompetenzen, die der CFO zur Steigerung der Produktivität in seiner Abteilung benötigt, verfügbar sind.
<G-vec00308-002-s076><locate.ausfinden><en> The battle is not only to locate the best talent, it is to build teams around it, and to ensure the competencies the CFO needs to drive better productivity in their department are available.
<G-vec00308-002-s077><locate.ausfinden><de> Benutzen Sie die Funktion Standortübersicht (Site Survey) Ihres Dienstprogramms für WLAN-Netzwerke, um andere WLANNetzwerke ausfindig zu machen, und stellen Sie Ihren WLAN-Router (oder Access Point) und Ihre Computer auf einen Kanal ein, der soweit wie möglich von den anderen Netzwerken entfernt ist.
<G-vec00308-002-s077><locate.ausfinden><en> Use the Site Survey capabilities of your Belkin Wireless Networking Utility to locate any other wireless networks, and move your wireless router (or access point) and computers to a channel as far away from other networks as possible.
<G-vec00308-002-s078><locate.ausfinden><de> DMT bietet die Planung und Überwachung geologischer, geophysikalischer und seismischer Exploration, um potenziell nutzbare Erdwärmequellen ausfindig zu machen und zu analysieren, die mit verschiedenen Techniken erfasst werden können.
<G-vec00308-002-s078><locate.ausfinden><en> DMT provides planning and supervision of geological, geophysical and seismic exploration in order to locate and analyse potentially exploitable geothermal sources capable of being captured by various techniques.
<G-vec00308-002-s079><locate.ausfinden><de> Sind sie in Freiheit gesetzt, und man glaubt, sie haben ein neues Verbrechen begangen, so zeigt man das Porträt allen Polizeiagenten, die ihren Mann dann bald ausfindig machen.
<G-vec00308-002-s079><locate.ausfinden><en> If, after a criminal has been released, he is suspected of committing a new crime, his portrait is shown to all police agents, who soon locate their suspect" .
<G-vec00308-002-s080><locate.ausfinden><de> Die Polizei von Sanhe versuchte, ihn ausfindig zu machen und ihn festzunehmen.
<G-vec00308-002-s080><locate.ausfinden><en> Sanhe Police Station officers tried to locate him and arrest him.
<G-vec00308-002-s081><locate.ausfinden><de> In der Entwicklung der Serioxyl Pflegelinie werden zunächst verschiedene Haartypen bestimmt, um so die Ursachen für Haarausfall und dünner werdendes Haar ausfindig zu machen.
<G-vec00308-002-s081><locate.ausfinden><en> During developing the products, initially different hair types are determined, so as to locate the causes of hair loss and thinning hair.
<G-vec00308-002-s082><locate.ausfinden><de> Ich benutze zur Motivausrichtung eine Smartphone-App, die es mir erlaubt, die Sternbilder ausfindig zu machen.
<G-vec00308-002-s082><locate.ausfinden><en> I use a smartphone app that helps me locate stellar constellations.
<G-vec00308-002-s083><locate.ausfinden><de> Der Golden Section Finder von Areaware hilft Ihnen dabei, perfekte Proportionen in der Umgebung ausfindig zu machen.
<G-vec00308-002-s083><locate.ausfinden><en> The Golden Section Finder by areaware helps you to locate the perfect proportions in the environment.
<G-vec00308-002-s084><locate.ausfinden><de> Tippen und halten Sie, um den Cursor ausfindig zu machen.
<G-vec00308-002-s084><locate.ausfinden><en> Tap and hold to locate the cursor.
<G-vec00308-002-s085><locate.ausfinden><de> Wenn der Regner, den Sie entfernen möchten, der letzte auf der Versorgungsleitung ist, müssen Sie den nächst „höheren“ Regner ausfindig machen (von dem Regner, den Sie entfernen möchten, aus gesehen der nächste Regner in Richtung der Wasserquelle).
<G-vec00308-002-s085><locate.ausfinden><en> If the sprinkler you want to remove is the last one on the pipe, you will need to locate the sprinkler that is "upstream" (closer to the source of water from the sprinkler you want to remove) and cut and cap the pipe there.
<G-vec00308-002-s086><locate.ausfinden><de> Du kannst Elemente, die dir gehören, auch im Xbox LIVE-Marktplatz ausfindig machen und auf die Schaltfläche Auf Xbox 360 herunterladen klicken, um die Elemente zu deiner Download-Warteschlange hinzuzufügen.
<G-vec00308-002-s086><locate.ausfinden><en> You can also locate items you own in Xbox Live Marketplace and click the Download to Xbox 360 button to add the item to your Download Queue.
<G-vec00308-002-s087><locate.ausfinden><de> Also heißt es, selbst Hand anzulegen und fehlerhafte IP-Adressen zu prüfen, veraltete Treiber zu aktualisieren und versteckte Störsignale ausfindig zu machen.
<G-vec00308-002-s087><locate.ausfinden><en> So it is, and check for incorrect IP addresses, to update outdated drivers and hidden make false signals, to locate.
<G-vec00308-002-s088><locate.ausfinden><de> Und dabei sind sie nicht allein: Selbst langjährige Online-Spieler fühlen sich immer wieder vom Überangebot erschlagen, können sie doch nahezu täglich einen neuen Anbieter ausfindig machen, der mit möglicherweise noch besseren Umsetzungen, Promotionen und Gewinnchancen punktet.
<G-vec00308-002-s088><locate.ausfinden><en> And they are not alone: Even long-time online players feel repeatedly hit by oversupply, they can make almost daily a new provider locate the scores with possibly even better conversions, promotions and prizes.
<G-vec00308-002-s089><locate.ausfinden><de> Somit kann der Mitarbeiter der Telefonzentrale ohne viele Umwege schnell den richtigen Ansprechpartner ausfindig machen.
<G-vec00308-002-s089><locate.ausfinden><en> This allows the telephone operator to locate the suitable contact person without many detours.
<G-vec00308-002-s090><locate.ausfinden><de> Dummerweise gibt es diesen Laden aber dort nicht mehr, weshalb wir den nächsten Laden in weiteren zwei Kilometern ausfindig machen müssen.
<G-vec00308-002-s090><locate.ausfinden><en> Unfortunately, there is no longer this store there, so we have to locate the next store in another two kilometers.
<G-vec00308-002-s091><locate.ausfinden><de> In LEVIY Analytics kann es schwierig sein, die Dashboards ausfindig zu machen.
<G-vec00308-002-s091><locate.ausfinden><en> It can be difficult to locate your dashboards in LEVIY Analytics.
<G-vec00308-002-s092><locate.ausfinden><de> Die bei weitem einfachste Methode, um deinen gelöschten Verlauf ausfindig zu machen, ist über deinen Google-Account.
<G-vec00308-002-s092><locate.ausfinden><en> By far the simplest method to locate your deleted history is through your Google Account.
<G-vec00308-002-s093><locate.ausfinden><de> Falls die gewünschte Partition nicht gelistet ist, klicken Sie auf „Deep Scan“ um es ausfindig zu machen.
<G-vec00308-002-s093><locate.ausfinden><en> If the desired partition is not listed, click on “Deep Scan” to locate it.
