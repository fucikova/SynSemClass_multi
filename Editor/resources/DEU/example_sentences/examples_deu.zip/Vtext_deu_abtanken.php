<G-vec00380-002-s091><unload.abtanken><de> Das Sammeln der Milch auf den Höfen und das Abtanken der Milch in der Molkerei sind weitere meiner Aufgaben.
<G-vec00380-002-s091><unload.abtanken><en> My job is also to collect the milk at the farms and unload the milk at the dairy.
