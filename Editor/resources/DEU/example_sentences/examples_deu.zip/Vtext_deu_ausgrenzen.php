<G-vec00367-001-s085><preclude.ausgrenzen><de> Die Klänge von Worten, Ausdrücken, Präfixe oder Suffixe grenzen andere Klänge von Worten aus.
<G-vec00367-001-s085><preclude.ausgrenzen><en> The sounds of words, phrases, prefixes, or suffixes preclude other sounds of words.
