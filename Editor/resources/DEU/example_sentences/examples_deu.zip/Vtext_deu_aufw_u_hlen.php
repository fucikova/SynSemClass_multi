<G-vec00547-002-s063><upset.aufwühlen><de> In der zweiten Erfahrung erinnere ich mich daran dass ich meinen Mann ganz aufgewühlt sah und er betete dass ich nicht sterben solle.
<G-vec00547-002-s063><upset.aufwühlen><en> In the second experience I remember seeing my husband all upset and praying that I would not die.
<G-vec00547-002-s064><upset.aufwühlen><de> Aufgewühlt durch den Krieg in Jugoslawien, sitzt sie an vier Tagen jeweils sechs Stunden auf einem Berg blutiger Rinderknochen, singt klagende Lieder und schrubbt die Fleischfetzen vom Gebein.
<G-vec00547-002-s064><upset.aufwühlen><en> Upset by the war in Yugoslavia she sat for six hours a day for four days on a mountain of bloody cow-bones, sang mournful songs and rubbed the last shreds of flesh from the bones.
<G-vec00547-002-s065><upset.aufwühlen><de> Bin erschüttert und fassungslos, aufgewühlt und ruhig, demütig und unendlich dankbar.
<G-vec00547-002-s065><upset.aufwühlen><en> I am shocked and stunned, upset and quiet, humbled and endlessly grateful.
