<G-vec00345-001-s021><reckon.befinden><de> "Allergene Duftkomponenten, die bereits unter der Bezeichnung ""Parfum"" subsumiert sind, werden am Ende der INCI-Liste nochmals einzeln aufgeführt.Bei umfangreichen INCI-Listen ist es schwierig abzuschätzen, wo sich die 1% Grenze befindet."
<G-vec00345-001-s021><reckon.befinden><en> "Allergenic fragrance components that already are subsumed under the term ""perfume"", are once more listed with their individual terms at the end of the INCI list. The 1% margin; however, is rather difficult to reckon in the case of comprehensive INCI lists."
<G-vec00001-001-s038><found.befinden><de> Ich war auf der höchsten Ebene von Bewusstheit und Wachheit als ich mich selbst in der Ecke der Decke über meiner Dusche befand.
<G-vec00001-001-s038><found.befinden><en> I was at my highest level of consciousness and alertness when I found myself in the corner of the ceiling above my shower.
<G-vec00001-001-s039><found.befinden><de> Die Kammer befand, daß die Erfindung technischen Charakter hat, weil zu ihrer Ausführung technische Überlegungen erforderlich waren.
<G-vec00001-001-s039><found.befinden><en> The board in that case found that the invention had technical character because it implied a need for technical considerations when carrying out that invention.
<G-vec00001-001-s040><found.befinden><de> Dort, seltsamerweise, inmitten von Nirgendwo, befand ich mich im Zentrum eines Sternensaals.
<G-vec00001-001-s040><found.befinden><en> There, oddly, in the middle of nowhere, I found myself in the center of a starred room.
<G-vec00001-001-s041><found.befinden><de> Ich befand mich inmitten eines grau-weißen Dunstes und ich bemerkte drei Wesen die in Weiß gekleidet waren wie Engel, links von mir eine Frau, einen Mann vor mir und einen anderen Mann rechts von mir.
<G-vec00001-001-s041><found.befinden><en> I found myself in the middle of a grayish white mist and I noticed three beings dressed in white like angels, a woman to my left, a man in front of me and another man to my right.
<G-vec00001-001-s042><found.befinden><de> Ruble Geschenk (Gericht befand 1000 Rubel.
<G-vec00001-001-s042><found.befinden><en> Ruble gift (court found 1000 rub.
<G-vec00001-001-s043><found.befinden><de> Die Richterin befand ihn für schuldig für das Verschwinden der Angestellten der Cafeteria des Justizpalastes und der Guerillakämpferin Irma Franco, welche den Ermittlungen nach alle den Justizpalast lebend verlassen hatten und wenig später Verschwanden und in Richtung Casa del Florero gebracht wurden.
<G-vec00001-001-s043><found.befinden><en> He was found guilty of causing the disappearances of employees from the palace’s cafeteria and of causing the disappearances of a member of the guerrilla movement, Irma Franco. According to the investigations, they were seen alive leaving the palace, then, shortly after being taken to the House of the Vase, they disappeared.
<G-vec00001-001-s044><found.befinden><de> Dann befand ich mich in einem Tunnel.
<G-vec00001-001-s044><found.befinden><en> Then, I found myself in a tunnel.
<G-vec00001-001-s045><found.befinden><de> In der Frage, ob die Wahlen für eine konstituierende Versammlung (im Dezember 1917) durchgeführt oder verschoben werden sollten, befand sich Lenin in einer Minderheit im Zentralkomitee, und die Wahlen wurden gegen seinen Willen durchgeführt.
<G-vec00001-001-s045><found.befinden><en> Again, on the question of holding or postponing the elections to the Constituent Assembly (in December 1917), Lenin found himself in a minority in the Central Committee, and the elections were held against his advice.
<G-vec00001-001-s046><found.befinden><de> Wenn manchmal die Klarheit fehlte, widerspiegelte das sogar das Stadium, in dem sich die Massenbewegung befand.
<G-vec00001-001-s046><found.befinden><en> If there was sometimes a lack of clarity, even this reflected the stage in which the mass movement found itself.
<G-vec00001-001-s047><found.befinden><de> Doch Koh Tao übte seinen Zauber auf mich aus und innerhalb einer Woche befand ich mich auf einem Boot, auf dem man mich in eine Tauchjacke schnallte, in welcher ich daraufhin einen PADI Discover Scuba Dive absolvierte.
<G-vec00001-001-s047><found.befinden><en> But Koh Tao worked it's magic and within a week I found myself on a boat, getting strapped into a BCD to try a PADI Discover Scuba Dive. First dive, terrifying.
<G-vec00001-001-s048><found.befinden><de> Ja Ich ging eines Nachts aus meinem Körper heraus und befand mich im Schlafzimmer meiner Tochter.
<G-vec00001-001-s048><found.befinden><en> Yes I went out of my body one night and I found myself in my daughter's bedroom.
<G-vec00001-001-s049><found.befinden><de> "Das war das schreckliche Dilemma, in dem sich unser Freund befand, als er jene ""außergewöhnliche Erfahrung"" hatte, die aus ihm, wie schon gesagt, einen freien Menschen machte."
<G-vec00001-001-s049><found.befinden><en> THERE IS A SOLUTION - Page 28 Here was the terrible dilemma in which our friend found himself when he had the extraordinary experience, which as we have already told you, made him a free man.
<G-vec00001-001-s050><found.befinden><de> GESCHICHTE DES MUSEUMS Gegen Ende des Ersten Weltkrieges, als sich Antalya unter italienischer Besatzung befand, begannen einige italienische Archäologen unter dem Vorwand der Arbeit fÃ1⁄4r die Kultur verschiedenste Ruinenstätte in und um Antalya zu plÃ1⁄4ndern und der italienischen Botschaft auszuhändigen.
<G-vec00001-001-s050><found.befinden><en> A SHORT HISTORY OF THE MUSEUM At the end of the First World War, during the time when Antalya was under the Italian military occupation, Italian archeologists started to remove the archeological treasures that had been found in the the center or the surroundings to the Italian Embassy, which they claimed to do in the name of civilization.
<G-vec00001-001-s051><found.befinden><de> Es gab keine Zeit in dieser Welt und ich befand mich nur im Raum.
<G-vec00001-001-s051><found.befinden><en> There was no time in this world and I found myself only in space.
<G-vec00001-001-s052><found.befinden><de> In jenem Moment, empfand ich dass ich rückwärts in einen Tunnel ging und ich befand mich wieder in meinem Körper.
<G-vec00001-001-s052><found.befinden><en> In that moment, I sensed I was going backward into a tunnel and I found myself back in my body.
<G-vec00001-001-s053><found.befinden><de> Aus dem Nichts und ohne Vorwarnung befand ich mich an einem dunklen Ort.
<G-vec00001-001-s053><found.befinden><en> Out of the blue and without warning, I found myself in a dark place.
<G-vec00001-001-s054><found.befinden><de> Wie Jackson Pollock, Richard Long und Hamish Fulton befand sie sich damit selbst auf dem Schauplatz ihrer Kunst, war direkter Teil von ihr.
<G-vec00001-001-s054><found.befinden><en> No less than Jackson Pollock, Richard Long and Hamish Fulton, she found herself in the arena of her work, actually part of it.
<G-vec00001-001-s055><found.befinden><de> Das Gericht befand ferner, dass AFFCO Nichtgewerkschaftsmitglieder dadurch begünstigt habe, dass ihnen längere Verträge angeboten wurden als Gewerkschaftsmitgliedern und dass dies diskriminierend sei.
<G-vec00001-001-s055><found.befinden><en> The Judge found that AFFCO had favoured non-union workers in offering them longer contracts than unionised workers and that this practice was discriminatory.
<G-vec00001-001-s056><found.befinden><de> Nein, es war einfach, als wäre ich in dieser anderen Welt gewesen, hätte dann einen Schritt zurückgetan und befand mich wieder hier.
<G-vec00001-001-s056><found.befinden><en> No, it was simply as though I were in this other world, then I took a step backwards and found myself here again.
<G-vec00001-001-s057><found.befinden><de> Die anderen weißen Pferde befinden sich in Alton Barnes, Broad Town, Cherhill, Hackpen, Marlborough und Pewsey.
<G-vec00001-001-s057><found.befinden><en> The other White Horses can be found at Alton Barnes, Broad Town, Cherhill, Hackpen, Marlborough and Pewsey.
<G-vec00001-001-s058><found.befinden><de> Das Dekanat der Fakultät 8 sowie der überwiegende Teil der Institute befinden sich im Gebäude Pfaffenwaldring 57, in den Stockwerken zwei bis acht.
<G-vec00001-001-s058><found.befinden><en> The Office of the Dean of Faculty 8 as well as the majority of the institutes can be found in the building at Pfaffenwaldring 57, on floors two to eight.
<G-vec00001-001-s059><found.befinden><de> Burgkeller - in der Burg befinden sich weitläufige Kellerräume auf mehreren Ebenen.
<G-vec00001-001-s059><found.befinden><en> Castle vaults - in the castle large vaults in several tiers can be found.
<G-vec00001-001-s060><found.befinden><de> Lazarus Dokumentations-Seite Die für die Lazarus IDE (inklusive der Free Pascal-Compiler-Handbücher) verfügbare Dokumentation und die Tutorials befinden sich auf der Lazarus Dokumentations-Seite .
<G-vec00001-001-s060><found.befinden><en> Lazarus Documentation All the available documentation and tutorials for the Lazarus IDE (including the Free Pascal Compiler manuals) can be found on the Lazarus Documentation page.
<G-vec00001-001-s061><found.befinden><de> Weitere Information über die Verwendung des Flash-Speichers für die FPGA-Konfiguration befinden sich auf der ZTEX Wiki.
<G-vec00001-001-s061><found.befinden><en> More information about using the Flash for FPGA configuration can be found on the ZTEX Wiki.
<G-vec00001-001-s062><found.befinden><de> Die Suchfelder befinden sich jeweils oben rechts auf unseren Webseiten.
<G-vec00001-001-s062><found.befinden><en> The Search boxes can be found at the top right of each of our web pages.
<G-vec00001-001-s063><found.befinden><de> § 20 Datenschutz Datenschutz: Informationen über Art, Umfang, Ort und Zweck der Erhebung, Verarbeitung und Nutzung der für die Ausführung von Bestellungen sowie für den Newsletterversand / Werbezwecke per E-Mail erforderlichen personenbezogenen Daten durch Slanted Publishers sowie das Auskunftsrecht des Teilnehmers und das Recht zur Berichtigung, Sperrung, Widerruf und Löschung befinden sich in der Datenschutzerklärung.
<G-vec00001-001-s063><found.befinden><en> Protection of privacy: All information about the nature, scope, location and purpose of the collation, processing and use of the personal data for the rendering of services such as fulfilling orders or for commercial use such as for the purpose of newsletters or advertisements via email by Slanted Publishers as well as the participants right of disclosure and the right to the disclosure, correction, blocking or deletion of data, and revocation of consents granted, can be found in the Privacy Statement.
<G-vec00001-001-s064><found.befinden><de> In unmittelbarer Nähe des Agape Aparthotels befinden sich zahlreiche Restaurants und Geschäfte sowie das Jüdische Museum.
<G-vec00001-001-s064><found.befinden><en> Many restaurants and shops, as well as the Jewish Museum can be found in the immediate vicinity of the Agape Aparthotel.
<G-vec00001-001-s065><found.befinden><de> Viele schöne Geschäfte, Cafés und Restaurants befinden sich in der Nähe des Apartments.
<G-vec00001-001-s065><found.befinden><en> Many nice shops, cafés and restaurants can be found near the apartment.
<G-vec00001-001-s066><found.befinden><de> Darüber hinaus befinden sich Montmartre und Sacre Coeur in unmittelbarer Umgebung.
<G-vec00001-001-s066><found.befinden><en> Montmartre and the Sacre Coeur can also both be found close to the hotel.
<G-vec00001-001-s067><found.befinden><de> Selbst Städte können sich dort befinden.
<G-vec00001-001-s067><found.befinden><en> Even cities may be found there.
<G-vec00001-001-s068><found.befinden><de> So sehen wir, daß sich in Rom beide Teile der Kirche befinden: die judenchristliche und die heidenchristliche, vereint, Ausdruck der Universalkirche.
<G-vec00001-001-s068><found.befinden><en> Thus we see that in Rome both parts of the Church were to be found: the Judaeo-Christian and the pagan-Christian, united, an expression of the universal Church.
<G-vec00001-001-s069><found.befinden><de> 2 Restaurants, ein Skiraum im Keller mit beheizter Skischuhablage, eine Waschmaschine und ein Trockner (münzbetrieben) sowie ein Kinderspielzimmer befinden sich im selben Gebäude.
<G-vec00001-001-s069><found.befinden><en> 2 restaurants, a ski storage room in the basement with a heated boot rack, a coin-operated washing machine and dryer, and a children's playroom can be found in the same building.
<G-vec00001-001-s070><found.befinden><de> In einem Umkreis von 100 m befinden sich ein Lebensmittelgeschäft, eine Bar und ein Restaurant.
<G-vec00001-001-s070><found.befinden><en> A grocery shop, a bar and a dining establishment can be found within a 100-metre radius.
<G-vec00001-001-s071><found.befinden><de> Geeignete WC- Anlagen für Rollstuhlfahrer befinden sich in den Nachbargebäuden.
<G-vec00001-001-s071><found.befinden><en> Suitable toilet facilities for wheelchair users can be found in the neighbouring buildings.
<G-vec00001-001-s072><found.befinden><de> Hier, wo bei immer noch aktiver Auffaltung der Anden die pazifische Nazcaplatte unter die Südamerikaplatte geschoben wird, befinden sich zahlreiche geologische Störungen und Bruchlinien.
<G-vec00001-001-s072><found.befinden><en> Here, were the Nasca Plate is pushed under the South America Plate, while the folding of the Andes still continues, many geological disturbances and break lines can be found.
<G-vec00001-001-s073><found.befinden><de> Hier befinden sich das größte Rehabilitationszentrum auf dem Balkan als auch mehrere moderne Wellness-Hotels, die mit einer unglaublichen Vielfalt an Anwendungen locken, wonach man sich wie neu geboren fühlt.
<G-vec00001-001-s073><found.befinden><en> It is here that the most modern wellness center on the Balkans can be found, along with several spa hotels, offering an incredible array of procedures that make you feel like a newborn.
<G-vec00001-001-s074><found.befinden><de> Kategorie: Appartement Lage: Innenstadt Die Zimmer und Appartements von Club Appartement befinden sich im Herz von Innenstadt, in einer stillen Umgebung.
<G-vec00001-001-s074><found.befinden><en> Category: Apartment Location: City center The rooms and apartments of the Club Apartman can be found in the heart of the city, but still in a tranquil environment.
<G-vec00001-001-s075><found.befinden><de> Ein Tennisplatz, ein Kinderspielplatz und eine Minigolfanlage befinden sich 200 m vom Hotel entfernt.
<G-vec00001-001-s075><found.befinden><en> A tennis court, children's playground and mini golf can be found 200 metres away.
<G-vec00001-001-s076><found.befinden><de> Es befindet sich zwischen St. Johann im Ahrntal und Steinhaus entlang der Ahrntaler Straße, Parkmöglichkeiten sind vorhanden.
<G-vec00001-001-s076><found.befinden><en> It can be found between the villages of San Giovanni (St. Johann) and Cadipietra (Steinhaus), parking spaces are available.
<G-vec00001-001-s077><found.befinden><de> Ökologisches Paradies – Riviera Rogoznica - befindet sich im Herzen von Dalmatien.
<G-vec00001-001-s077><found.befinden><en> The environmental paradise that is the Rogoznica Riviera can be found in the very heart of Dalmatia.
<G-vec00001-001-s078><found.befinden><de> Gegenüber auf der anderen Mainseite befindet sich bis heute das Stammwerk der Koenig & Bauer AG (KBA).
<G-vec00001-001-s078><found.befinden><en> Today Koenig & Bauer’s (KBA) main production facility can be found on the opposite side of the river Main.
<G-vec00001-001-s079><found.befinden><de> Die Stadtbrauerei ist 1 km entfernt und die Innenstadt befindet sich in 750 m Entfernung.
<G-vec00001-001-s079><found.befinden><en> The city brewery is 1 km away and the city centre can be found within 750 metres.
<G-vec00001-001-s080><found.befinden><de> Dabei wird deutlich, dass das Opec Öl-Kartell, das an sich geschaffen wurde, um die Erdölproduzenten selbst zu schützen, sich wegen all dieser Geschichten in einer sehr schwierigen Lage befindet.
<G-vec00001-001-s080><found.befinden><en> And it is becoming obvious that the oil cartel OPEC, that, incidentally, has been created to protect the oil producers themselves, found itself in a very difficult position because of all that.
<G-vec00001-001-s081><found.befinden><de> Eagle ' s Wings ist eine 5 Haspel, 25 payline video-slot befindet sich unter dem Microgaming Software.
<G-vec00001-001-s081><found.befinden><en> Eagle's Wings is a 5 reel, 25 payline video slot found under the Microgaming software.
<G-vec00001-001-s082><found.befinden><de> Dieses bezaubernde Hotel befindet sich in Matalascañas.
<G-vec00001-001-s082><found.befinden><en> This lovely hotel can be found in Matalascañas.
<G-vec00001-001-s083><found.befinden><de> Dieses komfortable Hotel befindet sich in Siracusa.
<G-vec00001-001-s083><found.befinden><en> This lovely hotel can be found in Siracusa.
<G-vec00001-001-s084><found.befinden><de> Dieses charmante Hotel befindet sich in Boppard am Rhein.
<G-vec00001-001-s084><found.befinden><en> This comfortable Hotel can be found in Boppard am Rhein.
<G-vec00001-001-s085><found.befinden><de> "Hier befindet sich auch die berühmte ""Frauenregatta auf dem Canale Grande"" sowie die ""Karnevalsfeier am Gründonnerstag""."
<G-vec00001-001-s085><found.befinden><en> "Further paintings to be found here include ""Women's regatta on the Canale Grande"" and the ""Carnival celebration on Holy Thursday""."
<G-vec00001-001-s086><found.befinden><de> Dieses charmante Hotel befindet sich in Paderborn.
<G-vec00001-001-s086><found.befinden><en> This comfortable hotel can be found in Paderborn.
<G-vec00001-001-s087><found.befinden><de> Dieses komfortable Hotel befindet sich in Haddington.
<G-vec00001-001-s087><found.befinden><en> This lovely hotel can be found in Haddington.
<G-vec00001-001-s088><found.befinden><de> Eine Auswahl an Restaurants, Bars, Pubs und Geschäften befindet sich in der Umgebung.
<G-vec00001-001-s088><found.befinden><en> A variety of restaurants, bars, pubs and shops can be found in the surrounding area.
<G-vec00001-001-s089><found.befinden><de> Dieses charmante Hotel befindet sich in Calcutta.
<G-vec00001-001-s089><found.befinden><en> This charming hotel can be found in Calcutta.
<G-vec00001-001-s090><found.befinden><de> Typus: Privatunterkunft Weitere Informationen: Das Haus befindet sich in der Hauptstadt des Balaton, in Keszthely, im Stadtzentrum, grüner Lage neben dem Scloss Festetics.
<G-vec00001-001-s090><found.befinden><en> type: private accommodation More information about the house: The house can be found in the capital of Lake Balaton, in Keszthely, in the city centre, in leafy area.
<G-vec00001-001-s091><found.befinden><de> Eine Auswahl befindet sich im Online Gutschein Shop .
<G-vec00001-001-s091><found.befinden><en> A selection can be found in the online voucher shop.
<G-vec00001-001-s092><found.befinden><de> Das 3 Sterne Hotel Fortuna befindet sich von Innenstadt 10 Minuten und vom Ferihegy Flughafen 15 Minuten mit Auto.
<G-vec00001-001-s092><found.befinden><en> The three star Hotel Fortuna can be found a 10 minutes from the center of the city and a 15 minutes drive from the airport.
<G-vec00001-001-s093><found.befinden><de> "Die ""Wall Of Fame"" befindet sich auf dem Gelände des Olympiastadion Berlin neben dem Schwimmbad."
<G-vec00001-001-s093><found.befinden><en> "The ""Wall of Fame"" can be found next to the Olympic pool on the premises of the Olympiastadion Berlin."
<G-vec00001-001-s094><found.befinden><de> Einer der größten Parks in Bushwick befindet sich nur 4 Blocks entfernt von der Wohnung: Der Irving Square Park besitzt einige schöne Birnbäume, einen Spielplatz, eine zentral angelegte Rasenfläche und historische Tore.
<G-vec00001-001-s094><found.befinden><en> One of Bushwick’s main parks can be found at just four blocks from the apartment: Irving Square Park features some beautiful pear trees, a playground, a central lawn and historic gates.
<G-vec00345-001-s027><reckon.befinden><de> In der schwierigen wirtschaftlichen Lage, in der sich auch die Gemeinschaft von San Marino befindet, im italienischen und im internationalen Kontext, soll mein Wort auch der Ermutigung dienen.
<G-vec00345-001-s027><reckon.befinden><en> In the difficult economic situation that the Community of San Marino must also reckon with in the Italian and international context, I would like to give you a word of encouragement.
