<G-vec00345-001-s021><reckon.befinden><de> "Allergene Duftkomponenten, die bereits unter der Bezeichnung ""Parfum"" subsumiert sind, werden am Ende der INCI-Liste nochmals einzeln aufgeführt.Bei umfangreichen INCI-Listen ist es schwierig abzuschätzen, wo sich die 1% Grenze befindet."
<G-vec00345-001-s021><reckon.befinden><en> "Allergenic fragrance components that already are subsumed under the term ""perfume"", are once more listed with their individual terms at the end of the INCI list. The 1% margin; however, is rather difficult to reckon in the case of comprehensive INCI lists."
<G-vec00001-001-s038><found.befinden><de> Ich war auf der höchsten Ebene von Bewusstheit und Wachheit als ich mich selbst in der Ecke der Decke über meiner Dusche befand.
<G-vec00001-001-s038><found.befinden><en> I was at my highest level of consciousness and alertness when I found myself in the corner of the ceiling above my shower.
<G-vec00001-001-s039><found.befinden><de> Die Kammer befand, daß die Erfindung technischen Charakter hat, weil zu ihrer Ausführung technische Überlegungen erforderlich waren.
<G-vec00001-001-s039><found.befinden><en> The board in that case found that the invention had technical character because it implied a need for technical considerations when carrying out that invention.
<G-vec00001-001-s040><found.befinden><de> Dort, seltsamerweise, inmitten von Nirgendwo, befand ich mich im Zentrum eines Sternensaals.
<G-vec00001-001-s040><found.befinden><en> There, oddly, in the middle of nowhere, I found myself in the center of a starred room.
<G-vec00001-001-s041><found.befinden><de> Ich befand mich inmitten eines grau-weißen Dunstes und ich bemerkte drei Wesen die in Weiß gekleidet waren wie Engel, links von mir eine Frau, einen Mann vor mir und einen anderen Mann rechts von mir.
<G-vec00001-001-s041><found.befinden><en> I found myself in the middle of a grayish white mist and I noticed three beings dressed in white like angels, a woman to my left, a man in front of me and another man to my right.
<G-vec00001-001-s042><found.befinden><de> Ruble Geschenk (Gericht befand 1000 Rubel.
<G-vec00001-001-s042><found.befinden><en> Ruble gift (court found 1000 rub.
<G-vec00001-001-s043><found.befinden><de> Die Richterin befand ihn für schuldig für das Verschwinden der Angestellten der Cafeteria des Justizpalastes und der Guerillakämpferin Irma Franco, welche den Ermittlungen nach alle den Justizpalast lebend verlassen hatten und wenig später Verschwanden und in Richtung Casa del Florero gebracht wurden.
<G-vec00001-001-s043><found.befinden><en> He was found guilty of causing the disappearances of employees from the palace’s cafeteria and of causing the disappearances of a member of the guerrilla movement, Irma Franco. According to the investigations, they were seen alive leaving the palace, then, shortly after being taken to the House of the Vase, they disappeared.
<G-vec00001-001-s044><found.befinden><de> Dann befand ich mich in einem Tunnel.
<G-vec00001-001-s044><found.befinden><en> Then, I found myself in a tunnel.
<G-vec00001-001-s045><found.befinden><de> In der Frage, ob die Wahlen für eine konstituierende Versammlung (im Dezember 1917) durchgeführt oder verschoben werden sollten, befand sich Lenin in einer Minderheit im Zentralkomitee, und die Wahlen wurden gegen seinen Willen durchgeführt.
<G-vec00001-001-s045><found.befinden><en> Again, on the question of holding or postponing the elections to the Constituent Assembly (in December 1917), Lenin found himself in a minority in the Central Committee, and the elections were held against his advice.
<G-vec00001-001-s046><found.befinden><de> Wenn manchmal die Klarheit fehlte, widerspiegelte das sogar das Stadium, in dem sich die Massenbewegung befand.
<G-vec00001-001-s046><found.befinden><en> If there was sometimes a lack of clarity, even this reflected the stage in which the mass movement found itself.
<G-vec00001-001-s047><found.befinden><de> Doch Koh Tao übte seinen Zauber auf mich aus und innerhalb einer Woche befand ich mich auf einem Boot, auf dem man mich in eine Tauchjacke schnallte, in welcher ich daraufhin einen PADI Discover Scuba Dive absolvierte.
<G-vec00001-001-s047><found.befinden><en> But Koh Tao worked it's magic and within a week I found myself on a boat, getting strapped into a BCD to try a PADI Discover Scuba Dive. First dive, terrifying.
<G-vec00001-001-s048><found.befinden><de> Ja Ich ging eines Nachts aus meinem Körper heraus und befand mich im Schlafzimmer meiner Tochter.
<G-vec00001-001-s048><found.befinden><en> Yes I went out of my body one night and I found myself in my daughter's bedroom.
<G-vec00001-001-s049><found.befinden><de> "Das war das schreckliche Dilemma, in dem sich unser Freund befand, als er jene ""außergewöhnliche Erfahrung"" hatte, die aus ihm, wie schon gesagt, einen freien Menschen machte."
<G-vec00001-001-s049><found.befinden><en> THERE IS A SOLUTION - Page 28 Here was the terrible dilemma in which our friend found himself when he had the extraordinary experience, which as we have already told you, made him a free man.
<G-vec00001-001-s050><found.befinden><de> GESCHICHTE DES MUSEUMS Gegen Ende des Ersten Weltkrieges, als sich Antalya unter italienischer Besatzung befand, begannen einige italienische Archäologen unter dem Vorwand der Arbeit fÃ1⁄4r die Kultur verschiedenste Ruinenstätte in und um Antalya zu plÃ1⁄4ndern und der italienischen Botschaft auszuhändigen.
<G-vec00001-001-s050><found.befinden><en> A SHORT HISTORY OF THE MUSEUM At the end of the First World War, during the time when Antalya was under the Italian military occupation, Italian archeologists started to remove the archeological treasures that had been found in the the center or the surroundings to the Italian Embassy, which they claimed to do in the name of civilization.
<G-vec00001-001-s051><found.befinden><de> Es gab keine Zeit in dieser Welt und ich befand mich nur im Raum.
<G-vec00001-001-s051><found.befinden><en> There was no time in this world and I found myself only in space.
<G-vec00001-001-s052><found.befinden><de> In jenem Moment, empfand ich dass ich rückwärts in einen Tunnel ging und ich befand mich wieder in meinem Körper.
<G-vec00001-001-s052><found.befinden><en> In that moment, I sensed I was going backward into a tunnel and I found myself back in my body.
<G-vec00001-001-s053><found.befinden><de> Aus dem Nichts und ohne Vorwarnung befand ich mich an einem dunklen Ort.
<G-vec00001-001-s053><found.befinden><en> Out of the blue and without warning, I found myself in a dark place.
<G-vec00001-001-s054><found.befinden><de> Wie Jackson Pollock, Richard Long und Hamish Fulton befand sie sich damit selbst auf dem Schauplatz ihrer Kunst, war direkter Teil von ihr.
<G-vec00001-001-s054><found.befinden><en> No less than Jackson Pollock, Richard Long and Hamish Fulton, she found herself in the arena of her work, actually part of it.
<G-vec00001-001-s055><found.befinden><de> Das Gericht befand ferner, dass AFFCO Nichtgewerkschaftsmitglieder dadurch begünstigt habe, dass ihnen längere Verträge angeboten wurden als Gewerkschaftsmitgliedern und dass dies diskriminierend sei.
<G-vec00001-001-s055><found.befinden><en> The Judge found that AFFCO had favoured non-union workers in offering them longer contracts than unionised workers and that this practice was discriminatory.
<G-vec00001-001-s056><found.befinden><de> Nein, es war einfach, als wäre ich in dieser anderen Welt gewesen, hätte dann einen Schritt zurückgetan und befand mich wieder hier.
<G-vec00001-001-s056><found.befinden><en> No, it was simply as though I were in this other world, then I took a step backwards and found myself here again.
<G-vec00001-001-s057><found.befinden><de> Die anderen weißen Pferde befinden sich in Alton Barnes, Broad Town, Cherhill, Hackpen, Marlborough und Pewsey.
<G-vec00001-001-s057><found.befinden><en> The other White Horses can be found at Alton Barnes, Broad Town, Cherhill, Hackpen, Marlborough and Pewsey.
<G-vec00001-001-s058><found.befinden><de> Das Dekanat der Fakultät 8 sowie der überwiegende Teil der Institute befinden sich im Gebäude Pfaffenwaldring 57, in den Stockwerken zwei bis acht.
<G-vec00001-001-s058><found.befinden><en> The Office of the Dean of Faculty 8 as well as the majority of the institutes can be found in the building at Pfaffenwaldring 57, on floors two to eight.
<G-vec00001-001-s059><found.befinden><de> Burgkeller - in der Burg befinden sich weitläufige Kellerräume auf mehreren Ebenen.
<G-vec00001-001-s059><found.befinden><en> Castle vaults - in the castle large vaults in several tiers can be found.
<G-vec00001-001-s060><found.befinden><de> Lazarus Dokumentations-Seite Die für die Lazarus IDE (inklusive der Free Pascal-Compiler-Handbücher) verfügbare Dokumentation und die Tutorials befinden sich auf der Lazarus Dokumentations-Seite .
<G-vec00001-001-s060><found.befinden><en> Lazarus Documentation All the available documentation and tutorials for the Lazarus IDE (including the Free Pascal Compiler manuals) can be found on the Lazarus Documentation page.
<G-vec00001-001-s061><found.befinden><de> Weitere Information über die Verwendung des Flash-Speichers für die FPGA-Konfiguration befinden sich auf der ZTEX Wiki.
<G-vec00001-001-s061><found.befinden><en> More information about using the Flash for FPGA configuration can be found on the ZTEX Wiki.
<G-vec00001-001-s062><found.befinden><de> Die Suchfelder befinden sich jeweils oben rechts auf unseren Webseiten.
<G-vec00001-001-s062><found.befinden><en> The Search boxes can be found at the top right of each of our web pages.
<G-vec00001-001-s063><found.befinden><de> § 20 Datenschutz Datenschutz: Informationen über Art, Umfang, Ort und Zweck der Erhebung, Verarbeitung und Nutzung der für die Ausführung von Bestellungen sowie für den Newsletterversand / Werbezwecke per E-Mail erforderlichen personenbezogenen Daten durch Slanted Publishers sowie das Auskunftsrecht des Teilnehmers und das Recht zur Berichtigung, Sperrung, Widerruf und Löschung befinden sich in der Datenschutzerklärung.
<G-vec00001-001-s063><found.befinden><en> Protection of privacy: All information about the nature, scope, location and purpose of the collation, processing and use of the personal data for the rendering of services such as fulfilling orders or for commercial use such as for the purpose of newsletters or advertisements via email by Slanted Publishers as well as the participants right of disclosure and the right to the disclosure, correction, blocking or deletion of data, and revocation of consents granted, can be found in the Privacy Statement.
<G-vec00001-001-s064><found.befinden><de> In unmittelbarer Nähe des Agape Aparthotels befinden sich zahlreiche Restaurants und Geschäfte sowie das Jüdische Museum.
<G-vec00001-001-s064><found.befinden><en> Many restaurants and shops, as well as the Jewish Museum can be found in the immediate vicinity of the Agape Aparthotel.
<G-vec00001-001-s065><found.befinden><de> Viele schöne Geschäfte, Cafés und Restaurants befinden sich in der Nähe des Apartments.
<G-vec00001-001-s065><found.befinden><en> Many nice shops, cafés and restaurants can be found near the apartment.
<G-vec00001-001-s066><found.befinden><de> Darüber hinaus befinden sich Montmartre und Sacre Coeur in unmittelbarer Umgebung.
<G-vec00001-001-s066><found.befinden><en> Montmartre and the Sacre Coeur can also both be found close to the hotel.
<G-vec00001-001-s067><found.befinden><de> Selbst Städte können sich dort befinden.
<G-vec00001-001-s067><found.befinden><en> Even cities may be found there.
<G-vec00001-001-s068><found.befinden><de> So sehen wir, daß sich in Rom beide Teile der Kirche befinden: die judenchristliche und die heidenchristliche, vereint, Ausdruck der Universalkirche.
<G-vec00001-001-s068><found.befinden><en> Thus we see that in Rome both parts of the Church were to be found: the Judaeo-Christian and the pagan-Christian, united, an expression of the universal Church.
<G-vec00001-001-s069><found.befinden><de> 2 Restaurants, ein Skiraum im Keller mit beheizter Skischuhablage, eine Waschmaschine und ein Trockner (münzbetrieben) sowie ein Kinderspielzimmer befinden sich im selben Gebäude.
<G-vec00001-001-s069><found.befinden><en> 2 restaurants, a ski storage room in the basement with a heated boot rack, a coin-operated washing machine and dryer, and a children's playroom can be found in the same building.
<G-vec00001-001-s070><found.befinden><de> In einem Umkreis von 100 m befinden sich ein Lebensmittelgeschäft, eine Bar und ein Restaurant.
<G-vec00001-001-s070><found.befinden><en> A grocery shop, a bar and a dining establishment can be found within a 100-metre radius.
<G-vec00001-001-s071><found.befinden><de> Geeignete WC- Anlagen für Rollstuhlfahrer befinden sich in den Nachbargebäuden.
<G-vec00001-001-s071><found.befinden><en> Suitable toilet facilities for wheelchair users can be found in the neighbouring buildings.
<G-vec00001-001-s072><found.befinden><de> Hier, wo bei immer noch aktiver Auffaltung der Anden die pazifische Nazcaplatte unter die Südamerikaplatte geschoben wird, befinden sich zahlreiche geologische Störungen und Bruchlinien.
<G-vec00001-001-s072><found.befinden><en> Here, were the Nasca Plate is pushed under the South America Plate, while the folding of the Andes still continues, many geological disturbances and break lines can be found.
<G-vec00001-001-s073><found.befinden><de> Hier befinden sich das größte Rehabilitationszentrum auf dem Balkan als auch mehrere moderne Wellness-Hotels, die mit einer unglaublichen Vielfalt an Anwendungen locken, wonach man sich wie neu geboren fühlt.
<G-vec00001-001-s073><found.befinden><en> It is here that the most modern wellness center on the Balkans can be found, along with several spa hotels, offering an incredible array of procedures that make you feel like a newborn.
<G-vec00001-001-s074><found.befinden><de> Kategorie: Appartement Lage: Innenstadt Die Zimmer und Appartements von Club Appartement befinden sich im Herz von Innenstadt, in einer stillen Umgebung.
<G-vec00001-001-s074><found.befinden><en> Category: Apartment Location: City center The rooms and apartments of the Club Apartman can be found in the heart of the city, but still in a tranquil environment.
<G-vec00001-001-s075><found.befinden><de> Ein Tennisplatz, ein Kinderspielplatz und eine Minigolfanlage befinden sich 200 m vom Hotel entfernt.
<G-vec00001-001-s075><found.befinden><en> A tennis court, children's playground and mini golf can be found 200 metres away.
<G-vec00001-001-s076><found.befinden><de> Es befindet sich zwischen St. Johann im Ahrntal und Steinhaus entlang der Ahrntaler Straße, Parkmöglichkeiten sind vorhanden.
<G-vec00001-001-s076><found.befinden><en> It can be found between the villages of San Giovanni (St. Johann) and Cadipietra (Steinhaus), parking spaces are available.
<G-vec00001-001-s077><found.befinden><de> Ökologisches Paradies – Riviera Rogoznica - befindet sich im Herzen von Dalmatien.
<G-vec00001-001-s077><found.befinden><en> The environmental paradise that is the Rogoznica Riviera can be found in the very heart of Dalmatia.
<G-vec00001-001-s078><found.befinden><de> Gegenüber auf der anderen Mainseite befindet sich bis heute das Stammwerk der Koenig & Bauer AG (KBA).
<G-vec00001-001-s078><found.befinden><en> Today Koenig & Bauer’s (KBA) main production facility can be found on the opposite side of the river Main.
<G-vec00001-001-s079><found.befinden><de> Die Stadtbrauerei ist 1 km entfernt und die Innenstadt befindet sich in 750 m Entfernung.
<G-vec00001-001-s079><found.befinden><en> The city brewery is 1 km away and the city centre can be found within 750 metres.
<G-vec00001-001-s080><found.befinden><de> Dabei wird deutlich, dass das Opec Öl-Kartell, das an sich geschaffen wurde, um die Erdölproduzenten selbst zu schützen, sich wegen all dieser Geschichten in einer sehr schwierigen Lage befindet.
<G-vec00001-001-s080><found.befinden><en> And it is becoming obvious that the oil cartel OPEC, that, incidentally, has been created to protect the oil producers themselves, found itself in a very difficult position because of all that.
<G-vec00001-001-s081><found.befinden><de> Eagle ' s Wings ist eine 5 Haspel, 25 payline video-slot befindet sich unter dem Microgaming Software.
<G-vec00001-001-s081><found.befinden><en> Eagle's Wings is a 5 reel, 25 payline video slot found under the Microgaming software.
<G-vec00001-001-s082><found.befinden><de> Dieses bezaubernde Hotel befindet sich in Matalascañas.
<G-vec00001-001-s082><found.befinden><en> This lovely hotel can be found in Matalascañas.
<G-vec00001-001-s083><found.befinden><de> Dieses komfortable Hotel befindet sich in Siracusa.
<G-vec00001-001-s083><found.befinden><en> This lovely hotel can be found in Siracusa.
<G-vec00001-001-s084><found.befinden><de> Dieses charmante Hotel befindet sich in Boppard am Rhein.
<G-vec00001-001-s084><found.befinden><en> This comfortable Hotel can be found in Boppard am Rhein.
<G-vec00001-001-s085><found.befinden><de> "Hier befindet sich auch die berühmte ""Frauenregatta auf dem Canale Grande"" sowie die ""Karnevalsfeier am Gründonnerstag""."
<G-vec00001-001-s085><found.befinden><en> "Further paintings to be found here include ""Women's regatta on the Canale Grande"" and the ""Carnival celebration on Holy Thursday""."
<G-vec00001-001-s086><found.befinden><de> Dieses charmante Hotel befindet sich in Paderborn.
<G-vec00001-001-s086><found.befinden><en> This comfortable hotel can be found in Paderborn.
<G-vec00001-001-s087><found.befinden><de> Dieses komfortable Hotel befindet sich in Haddington.
<G-vec00001-001-s087><found.befinden><en> This lovely hotel can be found in Haddington.
<G-vec00001-001-s088><found.befinden><de> Eine Auswahl an Restaurants, Bars, Pubs und Geschäften befindet sich in der Umgebung.
<G-vec00001-001-s088><found.befinden><en> A variety of restaurants, bars, pubs and shops can be found in the surrounding area.
<G-vec00001-001-s089><found.befinden><de> Dieses charmante Hotel befindet sich in Calcutta.
<G-vec00001-001-s089><found.befinden><en> This charming hotel can be found in Calcutta.
<G-vec00001-001-s090><found.befinden><de> Typus: Privatunterkunft Weitere Informationen: Das Haus befindet sich in der Hauptstadt des Balaton, in Keszthely, im Stadtzentrum, grüner Lage neben dem Scloss Festetics.
<G-vec00001-001-s090><found.befinden><en> type: private accommodation More information about the house: The house can be found in the capital of Lake Balaton, in Keszthely, in the city centre, in leafy area.
<G-vec00001-001-s091><found.befinden><de> Eine Auswahl befindet sich im Online Gutschein Shop .
<G-vec00001-001-s091><found.befinden><en> A selection can be found in the online voucher shop.
<G-vec00001-001-s092><found.befinden><de> Das 3 Sterne Hotel Fortuna befindet sich von Innenstadt 10 Minuten und vom Ferihegy Flughafen 15 Minuten mit Auto.
<G-vec00001-001-s092><found.befinden><en> The three star Hotel Fortuna can be found a 10 minutes from the center of the city and a 15 minutes drive from the airport.
<G-vec00001-001-s093><found.befinden><de> "Die ""Wall Of Fame"" befindet sich auf dem Gelände des Olympiastadion Berlin neben dem Schwimmbad."
<G-vec00001-001-s093><found.befinden><en> "The ""Wall of Fame"" can be found next to the Olympic pool on the premises of the Olympiastadion Berlin."
<G-vec00001-001-s094><found.befinden><de> Einer der größten Parks in Bushwick befindet sich nur 4 Blocks entfernt von der Wohnung: Der Irving Square Park besitzt einige schöne Birnbäume, einen Spielplatz, eine zentral angelegte Rasenfläche und historische Tore.
<G-vec00001-001-s094><found.befinden><en> One of Bushwick’s main parks can be found at just four blocks from the apartment: Irving Square Park features some beautiful pear trees, a playground, a central lawn and historic gates.
<G-vec00345-001-s027><reckon.befinden><de> In der schwierigen wirtschaftlichen Lage, in der sich auch die Gemeinschaft von San Marino befindet, im italienischen und im internationalen Kontext, soll mein Wort auch der Ermutigung dienen.
<G-vec00345-001-s027><reckon.befinden><en> In the difficult economic situation that the Community of San Marino must also reckon with in the Italian and international context, I would like to give you a word of encouragement.
<G-vec00213-002-s247><stop.befinden><de> Das Skigebiet erreichen Sie in etwa 250 m und die Skibushaltestelle befindet sich in nur 50 m Entfernung.
<G-vec00213-002-s247><stop.befinden><en> You can reach the ski area within approx. 250 m and the ski bus stop can be found in only approx.
<G-vec00213-002-s248><stop.befinden><de> An der Unterkunft stehen Ihnen kostenfreie Parkplätze zur Verfügung und eine Bushaltestelle befindet sich 50 m entfernt.
<G-vec00213-002-s248><stop.befinden><en> Free parking spaces are available on site and a bus stop is 50 metres away.
<G-vec00213-002-s249><stop.befinden><de> Von der Margareteninsel trennen Sie indes 3,5 km, während sich direkt vor dem Haus die nächstegelegene Bushaltestelle der Linie 237 befindet.
<G-vec00213-002-s249><stop.befinden><en> The Margaret Island is 3.5 km away and the nearest bus stop, line 237, is right in front of the building.
<G-vec00213-002-s250><stop.befinden><de> Eine Bushaltestelle mit lokalen Verbindungen befindet sich neben dem Hotel Palma und das nächste Lebensmittelgeschäft ist 20 m entfernt.
<G-vec00213-002-s250><stop.befinden><en> A local bus stop is next to the Hotel Palma, while the nearest grocery store is 50 feet away.
<G-vec00213-002-s251><stop.befinden><de> Am gegenüberliegenden Ufer von Luang Prabang, eine etwa 15-minütige Bootsfahrt entfernt, befindet sich der 2016 eröffnete Botanische Garten Pha Tad Ke.
<G-vec00213-002-s251><stop.befinden><en> Pak Beng - a small town on the Mekong, a stop over place for the slow boat to and from Luang Prabang
<G-vec00213-002-s252><stop.befinden><de> Tipp: Die Skibushaltestelle befindet sich direkt beim Haus – somit kann man das Auto während der gesamten Urlaubszeit stehen lassen.
<G-vec00213-002-s252><stop.befinden><en> Tip: There is a ski bus stop right in front of the accommodation, so you can get through the whole of your holiday without having to use your car.
<G-vec00213-002-s253><stop.befinden><de> Eine Bushaltestelle befindet sich in nur 50 m Entfernung.
<G-vec00213-002-s253><stop.befinden><en> There is a bus stop just 50 metres away.
<G-vec00213-002-s254><stop.befinden><de> Autofrei in Kitzbühel: Die möblierte Maisonette „HORN“ befindet sich in idealer, ruhiger und zentraler Lage von Kitzbühel, Zentrum und Skilifte sind in 5-10 Minuten fußläufig erreichbar.
<G-vec00213-002-s254><stop.befinden><en> Town centre and ski lifts are within 5 – 10 minutes‘ walking distance and ski bus stop, supermarket, sports shop, drugstore etc. just around the corner.
<G-vec00213-002-s255><stop.befinden><de> Die Skibushaltestelle befindet sich nur wenige Gehminuten vom Haus entfernt.
<G-vec00213-002-s255><stop.befinden><en> 2.5 km outside the village center. The ski bus stop is approx.
<G-vec00213-002-s256><stop.befinden><de> Direkt vor dem Hotel Stadt Freiburg befindet sich eine Bushaltestelle.
<G-vec00213-002-s256><stop.befinden><en> There is a bus stop directly in front of the Hotel Stadt Freiburg.
<G-vec00213-002-s257><stop.befinden><de> Im Hotel befindet sich ein Ski- und Fahrradraum mit Skischuhtrockner.
<G-vec00213-002-s257><stop.befinden><en> A ski rental shop and a ski bus stop are both just 200 metres away.
<G-vec00213-002-s258><stop.befinden><de> Eine Bushaltestelle befindet sich direkt vor der Tür.
<G-vec00213-002-s258><stop.befinden><en> There is a bus stop right outside.
<G-vec00213-002-s259><stop.befinden><de> Zudem ermöglicht diese Technologie die simultane Überwachung der Maschinenkorrekturen in vertikaler und horizontaler Ebene, unabhängig davon, an welcher Winkelposition sich der Sensor auf der Welle befindet.
<G-vec00213-002-s259><stop.befinden><en> The technology also allows the simultaneous monitoring of machine corrections in vertical and horizontal directions, starting from any angular position where the sensor comes to stop.
<G-vec00213-002-s260><stop.befinden><de> Gäste können den Flughafen San Francisco International schnell erreichen, der sich etwa 10 Autominuten entfernt befindet.
<G-vec00213-002-s260><stop.befinden><en> The nearest bus stop is 100 meters away. Bob Hope airport can be reached within 10 minutes' drive.
<G-vec00213-002-s261><stop.befinden><de> Das Sunny Apartment bietet einen Flughafentransfer auf Anfrage und eine Bushaltestelle befindet sich direkt neben dem Gebäude.
<G-vec00213-002-s261><stop.befinden><en> Sunny Apartment offers airport shuttle services on request. A bus stop can be found right next to the building.
<G-vec00213-002-s262><stop.befinden><de> Das Hyatt Regency Newport befindet sich weiter geradeaus.
<G-vec00213-002-s262><stop.befinden><en> At the stop sign, proceed over the causeway to Hyatt Regency Newport.
<G-vec00213-002-s263><stop.befinden><de> Eine Bushaltestelle befindet sich 50 m vom Apartment entfernt.
<G-vec00213-002-s263><stop.befinden><en> 200 meters to bus stop with bus every 20 minutes.
<G-vec00213-002-s264><stop.befinden><de> Eine Bushaltestelle befindet sich direkt vor dem Motel.
<G-vec00213-002-s264><stop.befinden><en> There is a bus stop directly outside the motel.
<G-vec00213-002-s265><stop.befinden><de> Eine Bushaltestelle befindet sich direkt vor dem Hotel Forum.
<G-vec00213-002-s265><stop.befinden><en> There is a bus stop right in front of the Hotel Forum.
<G-vec00233-002-s019><find.befinden><de> Ihr Ziel ist es, den Schülern zu ermöglichen, von konzentriertem Wissen zu profitieren und sich in einer großen Gemeinschaft mit gleichen Interessen zu befinden.
<G-vec00233-002-s019><find.befinden><en> Their aim is to enable students to benefit from concentrated knowledge and to find themselves in a large community sharing the same interests.
<G-vec00233-002-s020><find.befinden><de> Es sollte gleichermaßen jedoch klar, dass dieses Weltbild ist ein Teil des kulturellen Milieu, in dem moderne Christen sich befinden.
<G-vec00233-002-s020><find.befinden><en> It should be equally clear, however, that this world view is a part of the cultural milieu in which modern Christians find themselves.
<G-vec00233-002-s021><find.befinden><de> Im Erdgeschoss befinden sich: eine große Küche mit Kamin, der Wohnbereich, ein geräumiger Saal mit Kamin, zwei Bäder, eines davon behindertgerecht, und eine überdachte Terrasse (circa 45 m²).
<G-vec00233-002-s021><find.befinden><en> On the ground floor we find: large kitchen with fireplace, living room, large room with fireplace, two bathrooms of which one is suitable for disabled guests and a large porch (about 45 m²).
<G-vec00233-002-s022><find.befinden><de> So befinden sich mehrere U- Bahn- sowie Bushaltestellen in unmittelbarer Nähe.
<G-vec00233-002-s022><find.befinden><en> You can find several underground railway stations as well as bus stops in immediate proximity of the building.
<G-vec00233-002-s023><find.befinden><de> Zudem befinden sich in den stilvollen Räumlichkeiten Minibar/Kühlschrank, zentral geregelte Klimaanlage und Zentralheizung.
<G-vec00233-002-s023><find.befinden><en> Guests will also find a minibar and centrally regulated air conditioning and heating in all rooms as standard.
<G-vec00233-002-s024><find.befinden><de> Im Außenbereich befinden sich die Busbahnsteige der Le Bus Direct Shuttles.
<G-vec00233-002-s024><find.befinden><en> Outside you will find the Bus Direct platforms.
<G-vec00233-002-s025><find.befinden><de> In der Nähe des Hotels befinden sich zahlreiche Restaurants und Geschäfte sowie ein Zentrum für Thalassotherapie.
<G-vec00233-002-s025><find.befinden><en> Near the hotel you will find numerous restaurants and shops as well as a Thalassotherapy centre.
<G-vec00233-002-s026><find.befinden><de> Google und seine Nutzer befinden sich inzwischen in einer Feedback-Schleife: Das System reagiert fein abgestimmt auf unsere Bedürfnisse, die es im Vorfeld mit definiert hat, und wir antworten brav.
<G-vec00233-002-s026><find.befinden><en> In the meantime, Google and its users find themselves in a feedback loop: The system reacts finely-tuned to our needs, which it has defined in the run-up, and which we dutifully respond to.
<G-vec00233-002-s027><find.befinden><de> Auf der unteren Etage befinden sich ein Büro und ein Fitnessraum mit zusätzlichem Badezimmer.
<G-vec00233-002-s027><find.befinden><en> On the ground floor you can find an office and a gym with bathroom.
<G-vec00233-002-s028><find.befinden><de> Darunter befinden sich die beiden SIM-Slots und der Steckplatz für die MicroSD-Karte.
<G-vec00233-002-s028><find.befinden><en> Beneath, the user will find both SIM slots and the slot for the MicroSD card.
<G-vec00233-002-s029><find.befinden><de> Unternehmen, die im heutigen Umfeld Identity Governance betreiben, befinden sich in einer ähnlichen Situation.
<G-vec00233-002-s029><find.befinden><en> Businesses undertaking identity governance in today’s environment find themselves in a similar situation.
<G-vec00233-002-s030><find.befinden><de> Wir befinden uns auf unbekanntem Terrain, denn COVID-19 hat alles in Frage gestellt, was wir derzeit wissen und glauben.
<G-vec00233-002-s030><find.befinden><en> We find ourselves in uncharted territory, as COVID-19 has put in question everything that we currently know and believe.
<G-vec00233-002-s031><find.befinden><de> Der Meeresboden ist hauptsächlich sandig und in der Umgebung befinden sich einige Bereiche mit Felsen und Meeresvegetation.
<G-vec00233-002-s031><find.befinden><en> Its seabed is mainly sandy and in the surroundings we find some areas with rocks and marine vegetation.
<G-vec00233-002-s032><find.befinden><de> Daher befindet sich das Fürstentum im Kampf gegen das Königtum, der Bürokrat im Kampf gegen den Adel, der Bourgeois im Kampf gegen sie alle, während der Proletarier schon beginnt, sich im Kampf gegen die Bourgeois zu befinden.
<G-vec00233-002-s032><find.befinden><en> Hence, the higher nobility is struggling against the monarchy, the bureaucrat against the nobility, and the bourgeois against them all, while the proletariat is already beginning to find itself struggling against the bourgeoisie.
<G-vec00233-002-s033><find.befinden><de> Die arabischen Mauern befinden sich gegenüber der Cathedral de la Almudena.
<G-vec00233-002-s033><find.befinden><en> The Arab Wall faces the Cathedral de la Almudena, so head back up Cuesta de Vega and turn left to find the main entrance.
<G-vec00233-002-s034><find.befinden><de> Verschiedene Restaurants befinden sich im 5 Fahrminuten entfernten Arrieta.
<G-vec00233-002-s034><find.befinden><en> You will find a selection of restaurants in Arrieta, 5 minutes´ by car.
<G-vec00233-002-s035><find.befinden><de> In der Abteilung PRODUKTE befinden sich Geräte auf dem Gebiet der Klimatisierung, Lüftung, Kühltechnik, Heizung, Befeuchtung und Automatisierung.
<G-vec00233-002-s035><find.befinden><en> In the PRODUCTS section you will find devices related to air conditioning, ventilation, refrigeration, heating, humidification and automation.
<G-vec00233-002-s036><find.befinden><de> Scrolle nach unten zur „Diskussionen“-Box, wo sich die Kommentaroptionen für diesen Beitrag befinden.
<G-vec00233-002-s036><find.befinden><en> Scroll down to the “Discussion” box, where you will find the comment options for that post.
<G-vec00233-002-s037><find.befinden><de> Nur wenige Augenblicke vom Hampton Inn and Suites Denver Tech Center entfernt befinden sich die Büros von IBM, Pepsi und McDonalds.
<G-vec00233-002-s037><find.befinden><en> Only moments from the Hampton Inn and Suites Denver Tech Center, guests can find the offices of IBM, Pepsi and McDonald's.
<G-vec00308-002-s057><reside.befinden><de> Klicken Sie auf den Pfeil neben einem Duplikat-Datei, die verschiedenen Ordner zu sehen, wo sich die Dateien befinden.
<G-vec00308-002-s057><reside.befinden><en> Click the arrow next to any duplicate file to see the different folders where the files reside.
<G-vec00308-002-s058><reside.befinden><de> Diese Keno-Automaten gibt es überall, und die Orte, die diese Geräte befinden, sind mit dem Namen "Spielhöllen".
<G-vec00308-002-s058><reside.befinden><en> These keno equipments are everywhere, and the places that these equipments reside are called "gambling establishments".
<G-vec00308-002-s059><reside.befinden><de> Das Ziel dieser Untersuchung ist es, Ihnen mit einer Liste von bösartigen Programmen zu präsentieren, die angeblich in Ihrem System im Moment befinden.
<G-vec00308-002-s059><reside.befinden><en> The goal of this scan is to present you with a list of malicious programs which supposedly reside in your system at the moment.
<G-vec00308-002-s060><reside.befinden><de> SteelConnect ist ein SD-WAN-Komplettsystem, um Benutzer und Unternehmen mit ihren jeweils benötigten Anwendungen zu verbinden, wo auch immer sich diese befinden – in einem Remote-LAN, in einem Rechenzentrum oder in der Cloud.
<G-vec00308-002-s060><reside.befinden><en> Riverbed SteelConnect is a complete SD-WAN system for securely connecting users and business to the applications they need, wherever they reside—on a remote LAN, in a data center, or in the cloud.
<G-vec00308-002-s061><reside.befinden><de> Dies ist hilfreich, wenn sich die Active Directory-Domänendienst-Benutzerkonten (AD DS) der Administratoren, die Exchange verwalten sollen, nicht in derselben Gesamtstruktur befinden wie Exchange.
<G-vec00308-002-s061><reside.befinden><en> This is useful when the Active Directory Domain Services (AD DS) user accounts of the administrators you want to administer Exchange don't reside in the same resource forest as Exchange.
<G-vec00308-002-s063><reside.befinden><de> Beachten Sie, dass sich Ihre Buckets im selben Projekt befinden müssen wie Cloud Functions.
<G-vec00308-002-s063><reside.befinden><en> Note that your bucket must reside in the same project as Cloud Functions.
<G-vec00308-002-s064><reside.befinden><de> Bei virtuellen Festplatten mit systemeigenem Start dürfen sich die übergeordnete virtuelle Festplatte und der differenzierende Datenträger nicht auf unterschiedlichen Volumes befinden, auch wenn sich diese auf demselben lokalen Datenträger befinden.
<G-vec00308-002-s064><reside.befinden><en> For native-boot VHDs, the parent VHD and the differencing disk cannot reside on different volumes, even if they reside on the same local disk.
<G-vec00308-002-s065><reside.befinden><de> Klicken Sie auf Allgemeine Einstellungen und klicken Sie dann auf Durchsuchen, um zum neuen Speicherort im Dateisystem zu wechseln, an dem sich der Vibe-Ordner befinden soll.
<G-vec00308-002-s065><reside.befinden><en> Click Vibe Desktop Folder, then click Browse to browse to the new location on the file system where you want the Vibe folder to reside.
<G-vec00308-002-s066><reside.befinden><de> Die CAS-Server akzeptiert Inhalte von einem IP-Netzwerk an einem seiner Netzwerkschnittstellen, verschlüsselt sie und sendet über eine weitere Schnittstelle zu einem IP-Netz, wo die IPTV Verbraucher befinden.
<G-vec00308-002-s066><reside.befinden><en> The CAS server accepts content from an IP network to one of its network interfaces, encrypts it, and sends via another interface into an IP network where the IPTV consumers reside.
<G-vec00308-002-s067><reside.befinden><de> Die Existenz des versteckten Volumes (und des versteckten Betriebssystems) bleibt geheim.\n\n Das dritte Passwort (für das äußere Volume) kann ebenfalls an jede Person ausgegeben werden, die Sie zwingt Ihr Passwort für die erste Partition hinter der Systempartition zu verraten, in dem sich sowohl das äußere Volume als auch das versteckte Volume (mit dem versteckten Betriebssystem) befinden.
<G-vec00308-002-s067><reside.befinden><en> The existence of the hidden volume (and of the hidden operating system) will remain secret.\n\n The third password (for the outer volume) can be disclosed to anyone forcing you to reveal the password for the first partition behind the system partition, where both the outer volume and the hidden volume (containing the hidden operating system) reside.
<G-vec00308-002-s068><reside.befinden><de> Und wir wissen, dass wir uns immer ZUR RICHTIGEN ZEIT – AM RICHTIGEN ORT befinden, selbst wenn es anders aussehen mag.
<G-vec00308-002-s068><reside.befinden><en> And we know that we always reside in RIGHT TIME - RIGHT PLACE, even when it appears as if we aren't.
<G-vec00308-002-s069><reside.befinden><de> Platzieren Sie Komponenten und Objekt Instanzen innerhalb einer Knoteninstanz, um anzugeben, dass die Komponenten und Objekte auf den Knoten befinden.
<G-vec00308-002-s069><reside.befinden><en> Place components and object instances within a node instance to indicate that the components and objects reside on the node.
<G-vec00308-002-s070><reside.befinden><de> Ermöglicht ist auch eine Infrastrukturverwaltungsmethodik – eine Lösung zum Verwalten einer unbegrenzten Anzahl hochgradig virtualisierter Ressourcen, die sich an mehreren Standorten befinden können, wodurch sie als eine große Ressource erscheinen, von der aus Dienste bereitgestellt werden können.
<G-vec00308-002-s070><reside.befinden><en> Cloudcomputing is also an infrastructure management methodology – a solution to manage an infinite number of highly virtualized resources that can reside in multiple locations, making them appear as one large resource from which to deliver services.
<G-vec00308-002-s072><reside.befinden><de> Öffnen Sie den Ordner, in dem sich die Datenbank und die Protokolldateien befinden, und geben Sie an der Eingabeaufforderung Folgendes ein.
<G-vec00308-002-s072><reside.befinden><en> Open the folder where the database and log files reside, and then type the following at a command prompt.
<G-vec00308-002-s073><reside.befinden><de> Die europäische Grundverordnung findet Anwendung auf die Verarbeitung personenbezogener Daten von Personen, die sich in der EU befinden, durch einen nicht in der EU niedergelassenen Verantwortlichen oder Auftragsbearbeiter, wenn die Datenverarbeitung im Zusammenhang mit dem Angebot von Waren oder Dienstleistungen an diese Personen steht (unabhängig davon, ob dafür bezahlt werden muss oder nicht) oder mit dem Verhalten dieser Personen in der EU.
<G-vec00308-002-s073><reside.befinden><en> The European regulation foresees that the processing of personal data of European residents by a processing manager or a subcontractor who does not reside in the Union can be applied, when the processing activities are linked to the offer of goods or services to these people (whether a payment is required or not) or to the monitoring of these people’s behaviour in the Union.
<G-vec00317-002-s019><lie.befinden><de> Es ist ohne weiteres klar, daß der Schlüssel zum Heiligtum unter solchen Umständen sich in unseren Händen befinden und niemand außer uns die Gesetzgebung leiten wird.
<G-vec00317-002-s019><lie.befinden><en> It is easy to understand that in these conditions the key of the shrine will lie in our hands, and no one outside ourselves will any longer direct the force of legislation.
<G-vec00317-002-s020><lie.befinden><de> Zwar befinden sich Wohn- und Arbeitsräume noch unter einem Dach.
<G-vec00317-002-s020><lie.befinden><en> Ateliers and living space are still under one roof but lie on opposing sides of a well-lit corridor.
<G-vec00317-002-s021><lie.befinden><de> Bekanntermaßen befinden sich die Plätze, an denen die Hauptgefechte ausgetragen wurden (in Damascus und Jerusalem), in einem ausgedehnten Flusstal, einem tiefliegenden Land, das Great Rift Valley (Große Riftebene) genannt wird.
<G-vec00317-002-s021><lie.befinden><en> Significantly, the places where the main battles took place (in Damascus and Jerusalem) lie in a vast area of low-lying land called the Great Rift Valley.
<G-vec00317-002-s022><lie.befinden><de> Die Explorationskosten für das Grundstück werden voraussichtlich niedriger als gewöhnlich im Athabasca Becken ausfallen, da sich alle drei Konzessionen innerhalb eines Kilometers von bestehenden Straßen befinden.
<G-vec00317-002-s022><lie.befinden><en> Exploration costs on the Wheeler River property are expected to be lower than is common in the Athabasca Basin because all three dispositions lie within one kilometre of existing roads.
<G-vec00317-002-s023><lie.befinden><de> Nördlich der Elbe befinden sich das Stadtzentrum sowie ein Großteil des Stadtgebietes.
<G-vec00317-002-s023><lie.befinden><en> Hamburg’s city centre and most of the rest of the city lie north of the River Elbe.
<G-vec00317-002-s024><lie.befinden><de> Eine äußerst kosteneffiziente Lösung, da sich die Rohre bei der Reinigung mit unseren Spezialbürsten mehrere hundert Meter unter der Meeresoberfläche befinden können.
<G-vec00317-002-s024><lie.befinden><en> This is very cost-effective as the pipes can lie several hundred meters / yards under the surface during the operation.
<G-vec00317-002-s025><lie.befinden><de> Unter Einsatz modernster Techniken, wie der Massenspektrometrie mit induktiv gekoppeltem Plasma, erfahren Sie durch unsere Low-Level-Analyse auf Schwermetalle und die Speziation, an welchen Stellen auf Ihrem Gelände sich die Problembereiche befinden.
<G-vec00317-002-s025><lie.befinden><en> Our low-level metal analysis and speciation will tell you where the problem areas lie on your site, using state-of-the art techniques such as inductive coupled plasma – high-resolution mass spectrometry.
<G-vec00317-002-s026><lie.befinden><de> Neben Eisteilchen aus den Hauptringen, deren Umlaufbahnen sich zumeist noch näher am Saturn befinden als die Bahnen der inneren Monde, lagern sich auf den hellen Oberflächen auch eisige Partikel und Wasserdampf an, die vom außerhalb der Hauptringe kreisenden größeren Mond Enceladus ausgestoßen werden (Abb.
<G-vec00317-002-s026><lie.befinden><en> In addition to ice grains from the main rings that lie for the most part inside their orbits, the bright surfaces are also accumulating icy particles and water vapor ejected by the larger moon Enceladus from outside the main ring system (Fig.
<G-vec00317-002-s027><lie.befinden><de> Stellen Sie sicher, dass sich alle Unschärfen oder unbestimmten Bereiche des Objekts innerhalb dieser zwei Masken befinden.
<G-vec00317-002-s027><lie.befinden><en> Make sure that any fuzzy or uncertain areas of the object lie within these two masks.
<G-vec00317-002-s028><lie.befinden><de> Beobachten Sie außerdem auch die Konkurrenz, um zu erfahren, wo sich ihre Stärken und Schwachstellen befinden.
<G-vec00317-002-s028><lie.befinden><en> Also monitor your competition to see where your strengths and weaknesses lie.
<G-vec00366-002-s057><contain.befinden><de> Sollten sich auf den verlinkten Webseiten rechtswidrige oder sonst gegen die guten Sitten verstoßende Inhalte befinden, so distanziert sich Lyoness ausdrücklich davon.
<G-vec00366-002-s057><contain.befinden><en> Should these linked websites contain content that is illegal or that otherwise violates good moral standards, Lyoness shall expressly distance itself from said content.
<G-vec00366-002-s058><contain.befinden><de> Ausstattung: In diesen beiden Häusern, Vidal 1 und Vidal 2, befinden sich Apartments von verschiedener Größe.
<G-vec00366-002-s058><contain.befinden><en> Apartamentos Casa Appointments: These two houses, Vidal 1 and Vidal 2, contain apartments of different sizes.
<G-vec00366-002-s059><contain.befinden><de> Wenn der Arzt das Gerät – auf dem sich unter Umständen auch sensible Daten befinden können – versehentlich mit nach Hause nimmt, ist der Datenschutz schon nicht mehr gewährleistet.
<G-vec00366-002-s059><contain.befinden><en> If the doctor accidentally takes home the device, which may also contain sensitive data, patient data protection is no longer guaranteed.
<G-vec00366-002-s060><contain.befinden><de> In allen Räumen, in denen sich Kochfelder mit Brennern befinden - die den Räumlichkeiten, in denen sie installiert sind Luft entziehen - müssen Belüftungsöffnungen vorgesehen sein.
<G-vec00366-002-s060><contain.befinden><en> All rooms that contain hobs with burners – that use up air in the room they are installed in – require airing ducts.
<G-vec00366-002-s061><contain.befinden><de> Stellen Sie sicher, dass sich in dem Verzeichnis, in dem die erforderlichen Updatedateien gespeichert werden, keine zuvor heruntergeladenen Dateien befinden.
<G-vec00366-002-s061><contain.befinden><en> Ensure that the directory used to store prerequisite update files does not contain previously downloaded files.
<G-vec00366-002-s062><contain.befinden><de> Der Komplex besteht aus mehreren, maximal zweistöckigen Gebäuden, in denen sich die Zimmer und Suiten befinden.
<G-vec00366-002-s062><contain.befinden><en> The complex consists of several buildings no higher than two stories, which contain rooms and suites.
<G-vec00366-002-s063><contain.befinden><de> Ist der Schaukasten abschließbar, befinden sich häufig wertvolle Informationen oder Materialien darin.
<G-vec00366-002-s063><contain.befinden><en> If the display case can be locked up, then it will often contain valuable information or materials.
<G-vec00366-002-s064><contain.befinden><de> Hier befinden sich üblicherweise alle Informationen zur Größe Ihrer Reifen sowie der geeignete Reifendruck.
<G-vec00366-002-s064><contain.befinden><en> Usually those elements contain all the information relating to your tyre size and specifications, as well as the appropriate tyre pressure.
<G-vec00366-002-s065><contain.befinden><de> In dem Öko-Hundefutter befinden sich keinerlei künstlichen Farb-, Aroma- und Konservierungsstoffe.
<G-vec00366-002-s065><contain.befinden><en> The eco dog food does not contain any artificial colouring agents, flavourings or preservatives.
<G-vec00366-002-s066><contain.befinden><de> Auf der Website der Wipf AG können sich Links auf die Seiten anderer Betreiber befinden.
<G-vec00366-002-s066><contain.befinden><en> The Wipf AG website may contain links to the websites of other providers.
<G-vec00366-002-s067><contain.befinden><de> In ihnen befinden sich rund 45.000 Quadratmeter Wandmalereien und mehr als 2.000 bemalte Skulpturen.
<G-vec00366-002-s067><contain.befinden><en> They contain around 45,000 square meters of murals and more than 2,000 painted sculptures.
<G-vec00366-002-s068><contain.befinden><de> In den Obergeschossen befinden sich die Bürobereiche mit Blickbezügen sowohl in die Stadt, als auch in den Innenhof.
<G-vec00366-002-s068><contain.befinden><en> The upper floors contain the office areas with views across the city and into the inner courtyard.
<G-vec00366-002-s069><contain.befinden><de> Im Archiv des Zentralkomitees befinden sich Berichte unserer besten Ärzte über den Gesundheitszustand L.D.s.
<G-vec00366-002-s069><contain.befinden><en> The archives of the Central Committee contain reports by our best physicians on the state of L.D.’s health.
<G-vec00366-002-s070><contain.befinden><de> Auf der Rückseite befinden sich Informationen über die Tierarten, wie sie geschützt werden und welche Arbeit WWF dabei leistet.
<G-vec00366-002-s070><contain.befinden><en> The reverse sides of the stamps contain information on the species and their protection and the protection work done by WWF.
<G-vec00366-002-s071><contain.befinden><de> Auf den Labels befinden sich dann Barcodes mit eindeutigen IDs, die vom ERP System eindeutig zugeordnet werden können und somit Warehouse- und Produktionsprozesse unterstützen.
<G-vec00366-002-s071><contain.befinden><en> These labels contain barcodes with unique IDs, which can be clearly assigned by the ERP system, supporting warehouse/production processes.
<G-vec00366-002-s072><contain.befinden><de> Als Belles ältester Bruder ihr vornehmes Kleid sieht, nimmt er an, dass sich noch mehr Reichtümer im Schloss befinden.
<G-vec00366-002-s072><contain.befinden><en> Belle's eldest brother, Maxime (Nicolas Gob) finds a jewel on her clothing, positing that the castle may contain further treasures.
<G-vec00366-002-s073><contain.befinden><de> Das betrifft vor allem die Inselstaaten im Südwestpazifik, in deren Hoheitsgebieten sich die ergiebigsten Krusten befinden.
<G-vec00366-002-s073><contain.befinden><en> This applies particularly to the island nations in the southwest Pacific, whose territorial waters contain the richest crusts.
<G-vec00366-002-s074><contain.befinden><de> In den Portfolios von UNIQA, insbesondere in Österreich, befinden sich große Bestände von Risikoversicherungen mit Prämienanpassungsklauseln.
<G-vec00366-002-s074><contain.befinden><en> UNIQA’s portfolios contain large quantities of risk insurance policies with a premium adjustment clause, particularly in Austria.
<G-vec00366-002-s075><contain.befinden><de> Aus diesem Grund sollten unter Quarantäne stehende Domänen Endknotendomänen sein, ihnen untergeordnete Domänen sollten nur als Ressourcendomänen ohne Benutzerkonten dienen, oder die unter Quarantäne stehende Domäne sollte sich in einer separaten Gesamtstruktur befinden.
<G-vec00366-002-s075><contain.befinden><en> For this reason, quarantined domains should be leaf domains, their child domains should be only resource domains that contain no user accounts, or the quarantined domain should be in a separate forest.
<G-vec00233-003-s019><find_out.befinden><de> Ihr Ziel ist es, den Schülern zu ermöglichen, von konzentriertem Wissen zu profitieren und sich in einer großen Gemeinschaft mit gleichen Interessen zu befinden.
<G-vec00233-003-s019><find_out.befinden><en> Their aim is to enable students to benefit from concentrated knowledge and to find themselves in a large community sharing the same interests.
<G-vec00233-003-s020><find_out.befinden><de> Es sollte gleichermaßen jedoch klar, dass dieses Weltbild ist ein Teil des kulturellen Milieu, in dem moderne Christen sich befinden.
<G-vec00233-003-s020><find_out.befinden><en> It should be equally clear, however, that this world view is a part of the cultural milieu in which modern Christians find themselves.
<G-vec00233-003-s021><find_out.befinden><de> Im Erdgeschoss befinden sich: eine große Küche mit Kamin, der Wohnbereich, ein geräumiger Saal mit Kamin, zwei Bäder, eines davon behindertgerecht, und eine überdachte Terrasse (circa 45 m²).
<G-vec00233-003-s021><find_out.befinden><en> On the ground floor we find: large kitchen with fireplace, living room, large room with fireplace, two bathrooms of which one is suitable for disabled guests and a large porch (about 45 m²).
<G-vec00233-003-s022><find_out.befinden><de> So befinden sich mehrere U- Bahn- sowie Bushaltestellen in unmittelbarer Nähe.
<G-vec00233-003-s022><find_out.befinden><en> You can find several underground railway stations as well as bus stops in immediate proximity of the building.
<G-vec00233-003-s023><find_out.befinden><de> Zudem befinden sich in den stilvollen Räumlichkeiten Minibar/Kühlschrank, zentral geregelte Klimaanlage und Zentralheizung.
<G-vec00233-003-s023><find_out.befinden><en> Guests will also find a minibar and centrally regulated air conditioning and heating in all rooms as standard.
<G-vec00233-003-s024><find_out.befinden><de> Im Außenbereich befinden sich die Busbahnsteige der Le Bus Direct Shuttles.
<G-vec00233-003-s024><find_out.befinden><en> Outside you will find the Bus Direct platforms.
<G-vec00233-003-s025><find_out.befinden><de> In der Nähe des Hotels befinden sich zahlreiche Restaurants und Geschäfte sowie ein Zentrum für Thalassotherapie.
<G-vec00233-003-s025><find_out.befinden><en> Near the hotel you will find numerous restaurants and shops as well as a Thalassotherapy centre.
<G-vec00233-003-s026><find_out.befinden><de> Google und seine Nutzer befinden sich inzwischen in einer Feedback-Schleife: Das System reagiert fein abgestimmt auf unsere Bedürfnisse, die es im Vorfeld mit definiert hat, und wir antworten brav.
<G-vec00233-003-s026><find_out.befinden><en> In the meantime, Google and its users find themselves in a feedback loop: The system reacts finely-tuned to our needs, which it has defined in the run-up, and which we dutifully respond to.
<G-vec00233-003-s027><find_out.befinden><de> Auf der unteren Etage befinden sich ein Büro und ein Fitnessraum mit zusätzlichem Badezimmer.
<G-vec00233-003-s027><find_out.befinden><en> On the ground floor you can find an office and a gym with bathroom.
<G-vec00233-003-s028><find_out.befinden><de> Darunter befinden sich die beiden SIM-Slots und der Steckplatz für die MicroSD-Karte.
<G-vec00233-003-s028><find_out.befinden><en> Beneath, the user will find both SIM slots and the slot for the MicroSD card.
<G-vec00233-003-s029><find_out.befinden><de> Unternehmen, die im heutigen Umfeld Identity Governance betreiben, befinden sich in einer ähnlichen Situation.
<G-vec00233-003-s029><find_out.befinden><en> Businesses undertaking identity governance in today’s environment find themselves in a similar situation.
<G-vec00233-003-s030><find_out.befinden><de> Wir befinden uns auf unbekanntem Terrain, denn COVID-19 hat alles in Frage gestellt, was wir derzeit wissen und glauben.
<G-vec00233-003-s030><find_out.befinden><en> We find ourselves in uncharted territory, as COVID-19 has put in question everything that we currently know and believe.
<G-vec00233-003-s031><find_out.befinden><de> Der Meeresboden ist hauptsächlich sandig und in der Umgebung befinden sich einige Bereiche mit Felsen und Meeresvegetation.
<G-vec00233-003-s031><find_out.befinden><en> Its seabed is mainly sandy and in the surroundings we find some areas with rocks and marine vegetation.
<G-vec00233-003-s032><find_out.befinden><de> Daher befindet sich das Fürstentum im Kampf gegen das Königtum, der Bürokrat im Kampf gegen den Adel, der Bourgeois im Kampf gegen sie alle, während der Proletarier schon beginnt, sich im Kampf gegen die Bourgeois zu befinden.
<G-vec00233-003-s032><find_out.befinden><en> Hence, the higher nobility is struggling against the monarchy, the bureaucrat against the nobility, and the bourgeois against them all, while the proletariat is already beginning to find itself struggling against the bourgeoisie.
<G-vec00233-003-s033><find_out.befinden><de> Die arabischen Mauern befinden sich gegenüber der Cathedral de la Almudena.
<G-vec00233-003-s033><find_out.befinden><en> The Arab Wall faces the Cathedral de la Almudena, so head back up Cuesta de Vega and turn left to find the main entrance.
<G-vec00233-003-s034><find_out.befinden><de> Verschiedene Restaurants befinden sich im 5 Fahrminuten entfernten Arrieta.
<G-vec00233-003-s034><find_out.befinden><en> You will find a selection of restaurants in Arrieta, 5 minutes´ by car.
<G-vec00233-003-s035><find_out.befinden><de> In der Abteilung PRODUKTE befinden sich Geräte auf dem Gebiet der Klimatisierung, Lüftung, Kühltechnik, Heizung, Befeuchtung und Automatisierung.
<G-vec00233-003-s035><find_out.befinden><en> In the PRODUCTS section you will find devices related to air conditioning, ventilation, refrigeration, heating, humidification and automation.
<G-vec00233-003-s036><find_out.befinden><de> Scrolle nach unten zur „Diskussionen“-Box, wo sich die Kommentaroptionen für diesen Beitrag befinden.
<G-vec00233-003-s036><find_out.befinden><en> Scroll down to the “Discussion” box, where you will find the comment options for that post.
<G-vec00233-003-s037><find_out.befinden><de> Nur wenige Augenblicke vom Hampton Inn and Suites Denver Tech Center entfernt befinden sich die Büros von IBM, Pepsi und McDonalds.
<G-vec00233-003-s037><find_out.befinden><en> Only moments from the Hampton Inn and Suites Denver Tech Center, guests can find the offices of IBM, Pepsi and McDonald's.
