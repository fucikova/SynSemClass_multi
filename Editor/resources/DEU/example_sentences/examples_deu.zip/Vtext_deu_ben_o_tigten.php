<G-vec00092-001-s133><need.benötigten><de> HDDs und CD-ROMs benötigten externe SCSI-Adapter, Maus und Tastatur den PS/2-Anschluss.
<G-vec00092-001-s133><need.benötigten><en> HDDs and CD-ROMs were in need of external SCSI adapters, mouse and keypad called for the PS/2 connector.
<G-vec00092-001-s134><need.benötigten><de> Viele Anbieter verkauften (zumindest am Anfang) Unternehmensbereiche mit der Idee, dass sie keine IT-Abteilung benötigten – sie konnten schnelle Entscheidungen treffen, einen Prozess praktisch ohne Aufwand automatisieren und schnelle Ergebnisse erzielen.
<G-vec00092-001-s134><need.benötigten><en> Many providers (at least in the early days) sold business units on the idea that they didn't need the IT department – they could make quick decisions, automate a process with next to no overhead, and get quick results.
<G-vec00092-001-s135><need.benötigten><de> Von zentraler Bedeutung ist dabei die vom Nutzer wahrgenommene Verfügbarkeit und Performance der benötigten Anwendungen.
<G-vec00092-001-s135><need.benötigten><en> Users’ perceptions of the availability and performance of the applications they need is extremely important.
<G-vec00092-001-s136><need.benötigten><de> Weil wir in den vergangenen 95 Jahren glaubten: Wenn die Menschen Probleme oder Sorgen hätten, wenn sie eine Dienstleistung benötigten, dann werden bestimmte Institutionen die nötigen Schritte unternehmen und die diesbezüglichen Aufgaben auf sich nehmen.
<G-vec00092-001-s136><need.benötigten><en> This is because in the past 95 years we were convinced that should people encounter problems or need services of some kind, there will be also an institution to take care of these.
<G-vec00092-001-s137><need.benötigten><de> Durch diese Technologie erhalten Sie ein klares Produktdesign und können trotzdem alle benötigten Informationen auf Ihrem Produkt unterzubringen.
<G-vec00092-001-s137><need.benötigten><en> This technology gives you a clear product design while still providing all the information you need on your product.
<G-vec00092-001-s138><need.benötigten><de> Die Bestellbestätigung, die Sie per E-Mail erhalten, enthält alle benötigten Rücksendeanleitungen, einschließlich der Rücksendeadresse.
<G-vec00092-001-s138><need.benötigten><en> The order confirmation you get by email has all the return instructions you need, including the return shipping address.
<G-vec00092-001-s139><need.benötigten><de> Je nach Anforderungen, wie Übertragungseffizienz oder Datenschutz, können Sie sich für den benötigten Cache-Modus entscheiden.
<G-vec00092-001-s139><need.benötigten><en> According to your demand such as the efficiency of transmission or data protection, you can decide which cache mode you need.
<G-vec00092-001-s140><need.benötigten><de> Das Spezielle war ja, dass die Leuchte die Hauptlichtquelle darstellte, wodurch wir für das Shooting keine zusätzliche Lichtquelle benötigten.
<G-vec00092-001-s140><need.benötigten><en> The special thing was that the luminaire was the main light source, so we didn't need an additional light source for the shooting.
<G-vec00092-001-s141><need.benötigten><de> Stellen Sie sich Ihre benötigten Anwendungen selbst zusammen und behalten Ihre Fertigung - unabhängig von Zeit und Ort - im Blick.
<G-vec00092-001-s141><need.benötigten><en> Assemble the applications you need on your own, and keep an eye on your production – regardless of time or place.
<G-vec00092-001-s142><need.benötigten><de> "Wheel Pros ""Das Portals hilft unserem Vertriebsteam und unseren Partnern, alle für die Erstellung von Marketingkampagnen benötigten Ressourcen an einem Ort zu finden."
<G-vec00092-001-s142><need.benötigten><en> "Wheel Pros ""The purpose of this portal is to help our Sales team and customer partners go to one place to get all of the assets they need to create marketing campaigns."
<G-vec00092-001-s143><need.benötigten><de> Um den Wissenschaftlern einen schnelleren und flexibleren Zugang zu den benötigten Rechenressourcen zu ermöglichen, entschied sich das GMI für die Implementierung von SUSE OpenStack Cloud, einer unternehmensgerechten Private-Cloud-Plattform.
<G-vec00092-001-s143><need.benötigten><en> To give scientists a faster and more flexible way to access the computing resources they need, the GMI decided to deploy SUSE OpenStack Cloud, an enterprise-ready private cloud platform.
<G-vec00092-001-s144><need.benötigten><de> Wir haben die Maschine so installiert, dass wir sie umgehen konnten, wenn wir sie nicht benötigten.
<G-vec00092-001-s144><need.benötigten><en> We installed the machine in a way that we could bypass it when we would not need it.
<G-vec00092-001-s145><need.benötigten><de> Auf Ihrem iPhone, iPad oder iPod touch können Sie Dateien von all Ihren Geräten finden und diese durchsuchen, um nur die benötigten zu laden.
<G-vec00092-001-s145><need.benötigten><en> On your iPhone, iPad, or iPod touch, you can search and browse files from all of your devices and download them only as you need them.
<G-vec00092-001-s146><need.benötigten><de> Dieser Bildschirm wird mit einem Kit mit allen benötigten Werkzeugen geliefert, damit Sie Ihr Smartphone unter besseren Bedingungen und ohne die Hilfe eines Fachmanns selbst reparieren können.
<G-vec00092-001-s146><need.benötigten><en> This screen is provided with a kit with all the tools you need so you can repair your smartphone yourself in better conditions and without the need for the help of a professional.
<G-vec00092-001-s147><need.benötigten><de> Unsere Marke macht deutlich, dass wir bei DLL alle dieselben Werte teilen und denselben Zweck haben: Unternehmen die Möglichkeit zu geben, die von ihnen benötigten Vermögenswerte zu nutzen, um auf wirtschaftlich und sozial sinnvolle Weise einen Beitrag für die Welt zu leisten.
<G-vec00092-001-s147><need.benötigten><en> Brand Hub Our brand emphasizes that at DLL we all share the same values and have the same purpose - to enable businesses to use the assets they need to contribute meaningfully to the world, both economically and socially.
<G-vec00092-001-s148><need.benötigten><de> Über die Zeit hinweg erhalten sie die benötigten Informationen um effektiv zu planen.
<G-vec00092-001-s148><need.benötigten><en> Over time, they receive the information they need to plan effectively.
<G-vec00092-001-s149><need.benötigten><de> Mit der zugrundeliegenden Infrastruktur kommen sie nicht in Kontakt: Die PaaS-Umgebung stellt die benötigten Ressourcen automatisch und sofort bereit.
<G-vec00092-001-s149><need.benötigten><en> They have no contact with the underlying infrastructure – the PaaS environment provides the resources they need automatically and immediately.
<G-vec00092-001-s150><need.benötigten><de> Mit den neuen IXMO Sets genießen Sie nun bereits zusammengestellte Komplettpakte, die Ihnen das Zusammensuchen aller benötigten Artikel erspart.
<G-vec00092-001-s150><need.benötigten><en> With the new Keuco IXMO sets, you can now enjoy already assembled complete shower sets, which helps you to avoid the selection of all the items you need.
<G-vec00092-001-s151><need.benötigten><de> Sie benötigten einen frostfreien Raum, wo keine nasskalte Witterung hineindringen kann.
<G-vec00092-001-s151><need.benötigten><en> They need a frost free room, where no wet and cold weather can enter.
