<G-vec00261-002-s019><persist.andauern><de> Wenn die Nebenwirkungen andauern oder wieder entstehen, nach der Dosisverminderung, oder wird der Fortschritt der Krankheit beobachtet, dann sollte die medikamentöse Behandlung unterbrochen werden.
<G-vec00261-002-s019><persist.andauern><en> If the side effects persist or arise again after the dose reduction, or the progression of the disease is observed, then the drug treatment should be discontinued.
<G-vec00261-002-s020><persist.andauern><de> Wenn ihr physisches Leiden erfahrt und euch darüber Sorgen macht, besonders, wenn sie andauern, möchte ich vorschlagen, dass ihr einen Mediziner aufsucht, damit er jegliche medizinische Ursache ausschließen kann.
<G-vec00261-002-s020><persist.andauern><en> If you are experiencing physical ailments and are concerned about them, especially if they persist, I would suggest that you see your health practitioner to rule out any medical reasons.
<G-vec00261-002-s021><persist.andauern><de> Solange die Beschwerden nach der Stimulusentfernung nicht andauern, ist die Pulpa wahrscheinlich gesund genug, um aufrechterhalten zu werden.
<G-vec00261-002-s021><persist.andauern><en> As long as the discomfort does not persist after the stimulus is removed, the pulp is likely healthy enough to be maintained.
<G-vec00261-002-s022><persist.andauern><de> Die Bewaffnete Propaganda, die von der Landguerilla geführt wird, muss auch, während in den Städten gekämpft wird, weiter andauern.
<G-vec00261-002-s022><persist.andauern><en> The armed propaganda, which is led of the rural guerrilla, must also persist, while in the cities one fights, further.
<G-vec00261-002-s023><persist.andauern><de> Wenn Sie „Remember Me“ wählen, wird Ihr Login zwei Wochen andauern.
<G-vec00261-002-s023><persist.andauern><en> If you select "Remember Me", your login will persist for two weeks.
<G-vec00261-002-s024><persist.andauern><de> Sollten diese jedoch längere Zeit andauern oder sollten Sie gar innerhalb der Antibiotikabehandlung bereits Schmerzen verspüren kontaktieren Sie so rasch als möglich Ihren Arzt oder Apotheker.
<G-vec00261-002-s024><persist.andauern><en> If they do, in fact, persist over a longer period of time, or if you experience pain even during antibiotic treatment, contact your doctor or pharmacist as quickly as possible.
<G-vec00261-002-s025><persist.andauern><de> Unter diesen Voraussetzungen wird die hohe Arbeitslosigkeit andauern, was eine Belebung des Konsums noch schwieriger macht.
<G-vec00261-002-s025><persist.andauern><en> Under these conditions, high unemployment is set to persist, making recovery through the consumption channel more difficult.
<G-vec00261-002-s026><persist.andauern><de> Wenn die Fertigungskapazität im nächsten Jahr nicht irgendwie erweitert werden kann, müssen andere Länder auf einen Impfstoff warten und die Pandemie wird in Entwicklungsländern wahrscheinlich andauern.
<G-vec00261-002-s026><persist.andauern><en> Unless manufacturing capacity can somehow be expanded next year, other countries will have to wait for a vaccine, and the pandemic will likely persist in developing countries.
<G-vec00261-002-s028><persist.andauern><de> Die aktuellen Prognosen weisen darauf hin, dass die Ragweed-Saison in den meisten Teilen Europas von Mitte September bis Mitte Oktober andauern wird.
<G-vec00261-002-s028><persist.andauern><en> The projections suggest that ragweed pollen will persist from mid-September to mid-October across most of Europe.
<G-vec00261-002-s029><persist.andauern><de> Bei einigen Menschen halten die Symptome lediglich einige Tage an, während sie bei anderen Wochen oder Monate andauern können.
<G-vec00261-002-s029><persist.andauern><en> Some people may find their symptoms only last a number of days, others may find their symptoms persist for weeks or months.
<G-vec00261-002-s030><persist.andauern><de> Viele Jahre haben sie in Angst gelebt und Verluste erlitten, deren Folgen auch nach der Flucht aus ihren Heimatländern andauern.
<G-vec00261-002-s030><persist.andauern><en> For many years, people have lived in fear and suffered losses, the effects of which persist even after they have fled their home country.
<G-vec00261-002-s031><persist.andauern><de> Die Verletzung (Verletzung) kann seit drei bis sechs Wochen ohne Behandlung andauern.
<G-vec00261-002-s031><persist.andauern><en> The lesion may persist for three to six weeks without treatment.
<G-vec00261-002-s032><persist.andauern><de> Nach der Behandlung kann Gewebeschwellung für 3-7 Tage andauern.
<G-vec00261-002-s032><persist.andauern><en> After treatment, tissue swelling may persist for 3-7 days.
<G-vec00261-002-s033><persist.andauern><de> 5Sie werden nicht andauern, denn sie sind lediglich Symbole für die wahre Wahrnehmung, haben aber mit Erkenntnis nichts zu tun.
<G-vec00261-002-s033><persist.andauern><en> 5They will not persist, because they merely symbolize true perception, and they are not related to knowledge.
