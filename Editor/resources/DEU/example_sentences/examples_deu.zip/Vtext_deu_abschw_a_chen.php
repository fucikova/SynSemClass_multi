<G-vec00463-002-s165><weaken.abschwächen><de> Wenn du weiter diskutierst, dich streitest oder herumfeilschst, schwächst du wahrscheinlich die Wirkung des bereits Gesagten ab.
<G-vec00463-002-s165><weaken.abschwächen><en> Continuing to discuss, argue, or toss points around will likely weaken the impact of what you've said.
<G-vec00536-002-s060><relieve.abschwächen><de> Er verlangte, daß eine zweite europäische Front geschaffen werden müsse, um den Druck auf Stalin abzuschwächen.
<G-vec00536-002-s060><relieve.abschwächen><en> He held that a second European front must be opened to relieve the burden on Stalin.
<G-vec00536-002-s061><relieve.abschwächen><de> Wir mögen einigen Gemeindeleitern der frühen 1980er Jahre vorwerfen, die neue Theologie eingeführt zu haben, doch es war der einzige Ausweg, den sie sahen, um den Druck des leistungsbasierten Zugangs zu Gott abzuschwächen.
<G-vec00536-002-s061><relieve.abschwächen><en> We may accuse some of the church leaders in the early 1980’s for bringing in New Theology but this was the only way they could see to relieve the pressure of performance access to God.
<G-vec00536-002-s062><relieve.abschwächen><de> Grundgedanke des Ukemi ist es, die Wucht des Aufpralls von UKE auf der Tatami auf eine möglichst große Fläche zu verteilen und so den Aufprall abzuschwächen.
<G-vec00536-002-s062><relieve.abschwächen><en> The basic idea of ukemi is: The force of the impact of UKE must be spread on the largest possible area of the tatami, and so relieve the impact.
