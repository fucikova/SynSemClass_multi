<G-vec00547-001-s057><upset.aufregen><de> Die Littles waren sehr aufgeregt, um zu finden, dass Stuart gegangen war.
<G-vec00547-001-s057><upset.aufregen><en> The Littles were very upset to find that Stuart had left.
<G-vec00547-001-s058><upset.aufregen><de> Guten Abend Frau Bigu leid, dass sie es aufgeregt ist, aber ich habe ein reines Gewissen, bekam ich einen Rabatt von 5,00 € und ich gab ihr einen unserer Marmelade, und dann denke ich, dass Dinge, die gut gegessen haben.
<G-vec00547-001-s058><upset.aufregen><en> Good evening Madam Bigu sorry that she is upset there, however I have a clear conscience, I got a discount of € 5.00 and I gave her one of our jam, and then I think that matters that have eaten well.
<G-vec00547-001-s059><upset.aufregen><de> Dann können wir unsere Betrachtungsweise der Situation ändern und mit einer Einstellung, die daran Anteil nimmt, wie alle anderen mit der Verspätung umgehen, können wir die Gelegenheit ergreifen, ein Gespräch mit einem Mitreisenden zu beginnen, und dadurch, dass wir nicht aufgeregt sind, sondern uns nett unterhalten, diesen Menschen helfen, sich zu beruhigen und nicht aus der Fassung zu geraten.
<G-vec00547-001-s059><upset.aufregen><en> We can then change the way we regard the situation and, with an attitude now concerned with how everyone else is dealing with the delay, we can see it as an opportunity to strike up a conversation with a fellow passenger and, by being pleasant and not upset, help the person to calm down and not be distraught.
<G-vec00547-001-s060><upset.aufregen><de> Ich war am Boden zerstört, wie aufgeregt sie aussah und es war als könnte ich fühlen wie sie sich fühlte.
<G-vec00547-001-s060><upset.aufregen><en> I was devastated at how upset she looked and it was as if I could feel how she felt.
<G-vec00547-001-s061><upset.aufregen><de> Ich bin dadurch aufgeregt und besorgt geworden, denn es ist für mich eine Frage meiner Existenz.
<G-vec00547-001-s061><upset.aufregen><en> It upset me and made me worried as for me it is a question of my existence.
<G-vec00547-001-s062><upset.aufregen><de> Maleficent glaubt, dass die Mädchen jetzt sehr aufgeregt sein müssen, aber die Prinzessinnen sind entschlossen, Maleficent zu zeigen, dass sie ihren Weihnachtsgeist nicht verderben kann.
<G-vec00547-001-s062><upset.aufregen><en> Maleficent thinks the girls must be very upset now, but the princesses are determined to show Maleficent that she can't spoil their Christmas spirit.
<G-vec00547-001-s063><upset.aufregen><de> In der gleichen Nacht zogen sich die Verletzungen dezimiert Red Wings aus einer monumentalen aufgeregt durch das Besiegen der Verteidigung Meister 5-4 in einer Schießerei.
<G-vec00547-001-s063><upset.aufregen><en> On the same night, the injury-decimated Red Wings pulled off a monumental upset by defeating the defending Cup champions 5-4 in a shootout.
<G-vec00547-001-s064><upset.aufregen><de> Mai war sehr aufgeregt über das, was passiert ist, aber sie gab nicht auf und anstatt aufzugeben, so dass sie eine Beschwerde, die die meisten Menschen in der Gemeinde nicht getan hat.
<G-vec00547-001-s064><upset.aufregen><en> Mai was very upset about what happened but she did not give up and instead of giving up so she made a complaint, which most people in the village did not.
<G-vec00547-001-s065><upset.aufregen><de> Später jedoch erwähnte er mit höhnischem Lächeln, daß sich einer seiner Kollegen geradezu aufgeregt habe, als er Vrba unerwarteterweise in Lanzmanns Film sah.
<G-vec00547-001-s065><upset.aufregen><en> Later, however, he mentioned, sardonically smiling, that one of his colleagues had been upset when he unexpectedly had seen Vrba in Lanzmann's film.
<G-vec00547-001-s066><upset.aufregen><de> Ich wurde aufgeregt, zornig und verlor das Bewußtsein.
<G-vec00547-001-s066><upset.aufregen><en> I was getting upset, angry, and lost consciousness.
<G-vec00547-001-s067><upset.aufregen><de> Es ist nicht schwer zu erkennen, warum dieselben Schauspieler erzählen von Szenen emotional sehr aufgeregt gewesen, macht es schwierig, den Satz vergessen einmal zu Hause in den Abendstunden.
<G-vec00547-001-s067><upset.aufregen><en> It's not hard to see why the same actors tell of having been emotionally very upset by scenes, making it difficult to forget the set once at home in the evenings.
<G-vec00547-001-s068><upset.aufregen><de> 2Ki 6:11 Darüber ward der König von Aram aufgeregt.
<G-vec00547-001-s068><upset.aufregen><en> 11 This made the king of Syria upset.
<G-vec00547-001-s069><upset.aufregen><de> Alkohol wirkt beruhigend, wenn du also bereits wütend, aufgeregt oder einfach nur traurig bist, ist es sehr wahrscheinlich, dass du dich schlechter fühlen wirst.
<G-vec00547-001-s069><upset.aufregen><en> Alcohol is a depressant, so if you're already feeling angry, upset, or just unstable, it is very likely to make you feel worse.
<G-vec00547-001-s070><upset.aufregen><de> Mama Bellini ist sehr aufgeregt, denkt, sie werden jetzt ruiniert sein, das alles für Chester verantwortlich machen und Mario erzählt, dass er gehen muss.
<G-vec00547-001-s070><upset.aufregen><en> Mama Bellini is very upset, blames this all on Chester, and tells Mario that he has to go. Chester Cricket sings his sadness.
<G-vec00547-001-s071><upset.aufregen><de> Man muss ruhig und gleichmütig sein, darf nicht aufgeregt oder unzufrieden werden, wenn das Essen nicht schmackhaft oder sehr reichlich ist, sondern man hat eine bestimmte notwendige Menge zu essen, nicht weniger und nicht mehr.
<G-vec00547-001-s071><upset.aufregen><en> One must be calm and equal, not getting upset or dissatisfied when the food is not tasty or not in abundance — eating the fixed amount that is necessary, not less or more.
<G-vec00547-001-s072><upset.aufregen><de> Diese sind nur schwer aus der Kleidung entfernen und kann bedeuten, daß eine lustige Tag endet in klagenden Eltern und Kinder aufgeregt.
<G-vec00547-001-s072><upset.aufregen><en> These are difficult to remove from clothes and can mean that a fun day ends in complaining parents and upset kids.
<G-vec00547-001-s073><upset.aufregen><de> Die Mutter ist die einzige wirklich traurig für den Verlust seines Sohnes, alle anderen, wie aufgeregt den Vorfall, Sie müssen denken, ist nur gut.
<G-vec00547-001-s073><upset.aufregen><en> The mother is the only truly sad for the loss of son, all the others, Although upset by the incident, they must think that it is only good.
<G-vec00547-001-s074><upset.aufregen><de> Bei jedem Kontakt zu empfindlich und aufgeregt zu sein, ist übertrieben; aber zu viele Kontakte zu haben und sich immer zu zerstreuen, ist ein Hemmnis für das Wachsen der Sadhana und die Festigung des inneren Wesens, da man ständig in das äußere, gewöhnliche Bewusstsein hinausgezogen wird.
<G-vec00547-001-s074><upset.aufregen><en> To be too sensitive and upset by any contact is excessive; but to have too many contacts and be always dispersing oneself prevents the sadhana from growing and solidifying in the inner being, since one is always being pulled out into the ordinary outer consciousness.
<G-vec00547-001-s075><upset.aufregen><de> Als für das Abendessen sind sie noch mehr aufgeregt, weil sie in der Regel erhalten gute Kritiken, und ich wollte Sie zu Herzen zu erfüllen.
<G-vec00547-001-s075><upset.aufregen><en> As for the dinner they are even more upset because they usually receive great reviews, and I wanted to meet you too heart.
<G-vec00547-001-s083><upset.aufregen><de> Ich würde versuchen, zu ändern, aber ich würde genau das gleiche Ende, aufregen und allein.
<G-vec00547-001-s083><upset.aufregen><en> I'd try to change, but I'd just end up the same, upset and alone.
<G-vec00547-001-s084><upset.aufregen><de> Wenn ich mich aufregen, sind Sie serene.When Ich bin im Fr...
<G-vec00547-001-s084><upset.aufregen><en> When I am upset, you are serene.Whe...
<G-vec00547-001-s085><upset.aufregen><de> Sie wurden gewarnt, dass in Zukunft ihre extreme Nähe zu ernsthaften Problemen führen kann, vor allem, wenn eine davon beschließt, zu heiraten und bewegen Weg von, oder wenn einer von ihnen stirbt, die Zwillinge fühlten sie sich aufregen.
<G-vec00547-001-s085><upset.aufregen><en> They were warned that their extreme proximity can lead to serious problems in the future, especially if one of them decides to marry and move away from, or if one of them dies, the twins they felt upset.
<G-vec00547-001-s086><upset.aufregen><de> Es ist wünschenswert, nicht versuchen, im Tantra ohne Partner zu engagieren, aber nicht aufregen, Wenn Sie nur auf sich selbst verlassen musste, Wenn die Verbrecher an der macht die Umgebung der institutionalisierten Ketten Steuern.
<G-vec00547-001-s086><upset.aufregen><en> It is desirable to try not to engage in Tantra without partners, but don't get upset, If you had to count only on yourself, When the criminals in power control the environment of institutionalized chains.
<G-vec00547-001-s087><upset.aufregen><de> Aber du musst nicht mehr aufregen, es ist ein phantastisches System, das dauerhafte Ergebnisse bietet-es ist Gynexin Alpha Formula.
<G-vec00547-001-s087><upset.aufregen><en> You don't have to be upset any longer, there is a great system that supplies long-term results-- it is Gynexin Alpha Formula.
<G-vec00547-001-s088><upset.aufregen><de> Sie unterscheiden nicht die EV berechnet Glücksspiel sie an einem Pokertisch aus ihrem normalen Leben, und sie am Ende macht dumm Fehler, und noch schlimmer, nicht zu sehen, warum andere Menschen mit ihren Entscheidungen aufregen könnte.
<G-vec00547-001-s088><upset.aufregen><en> They don't differentiate the EV calculated gambling they do at a poker table from their regular life, and they end up making foolish mistakes, and even worse, not seeing why other people might be upset with their decisions.
<G-vec00547-001-s089><upset.aufregen><de> Das sind einfache Fakten, über die die polnischen Eliten sich aufregen können, so viel sie wollen.
<G-vec00547-001-s089><upset.aufregen><en> Those are simple facts over which the Polish elites can get as upset as they like.
<G-vec00547-001-s090><upset.aufregen><de> Wenn Kinder nicht sofort vernünftige Antworten geben können, sollte man sich nicht aufregen und schimpfen.
<G-vec00547-001-s090><upset.aufregen><en> If children can not immediately give sensible answers, one should not get upset and scold them.
<G-vec00547-001-s091><upset.aufregen><de> Tatsächlich, mit seiner jüngsten Kritik an der Neckerei auf die Ethik der Kardinal Carlo Caffarra und St. Giovanni Paolo II gedreht umarmt, Grillo zeigt deutlich, dass er bereit war, die wirkliche Zahl aufregen, wenn es wahr ist, wie er behauptet, Franziskus hat das Konzept der Ehe des seligen Pius IX revolutionierte, Pius XI und St. Giovanni Paolo II [Siehe vorherigen Artikel, Wer, Wer, Wer, Wer, Wer].
<G-vec00547-001-s091><upset.aufregen><en> Indeed, with his recent criticism hugging the teasing turned to the ethics of Cardinal Carlo Caffarra and St. Giovanni Paolo II, Grillo clearly shows that he was ready to upset the real figure, if it's true, as he claims, Pope Francis has revolutionized the concept of marriage of Blessed Pius IX, Pius XI and St. Giovanni Paolo II [See previous articles, WHO, WHO, WHO, WHO, WHO].
<G-vec00547-001-s092><upset.aufregen><de> Er sagte kein Wort über das Zwangsarbeitslager, weil er mich nicht aufregen wollte.
<G-vec00547-001-s092><upset.aufregen><en> He didn't say anything about the forced labour camp because he didn't want to upset me.
<G-vec00547-001-s093><upset.aufregen><de> Zunächst gibt es keine Notwendigkeit, sich aufregen, wie die gesamten Daten werden auf der Server-Seite OST-Datei vorhanden sein und somit durch Umwandlung in entsprechende PST-Datei Sie ihre Daten zugreifen können.
<G-vec00547-001-s093><upset.aufregen><en> First there is no need to get upset as the entire data will be present at the server sides OST file and hence by converting it to respective PST file you can access its data.
<G-vec00547-001-s094><upset.aufregen><de> Einige dieser Symptome sind Magen durch Entgiftung ausgelöst aufregen; Fettstühle, leichte Kopfschmerzen und Schwindel, Übelkeit usw.
<G-vec00547-001-s094><upset.aufregen><en> Some of those symptoms include stomach upset triggered by detoxification; fatty stools, mild headache and dizziness, nausea etc.
<G-vec00547-001-s095><upset.aufregen><de> Laut ihm, manchmal Ihre vertrauten Familienmitglieder oder Freunde können bestimmtes Manko sehen, dass Sie nicht bewusst sind, aber sie nicht sagen, weil sie nicht wollen Sie darüber aufregen sehen.
<G-vec00547-001-s095><upset.aufregen><en> According to him, sometimes your trusted family members or friends can see certain shortcoming that you are unaware of but they don't tell you because they don't want to see you upset about it.
<G-vec00547-001-s096><upset.aufregen><de> Statt sich aufregen, fragte sie die Filialleiterin und konnte zu finden und zu kaufen.
<G-vec00547-001-s096><upset.aufregen><en> Instead of getting upset, she asked the store employee and was able to locate and purchase some.
<G-vec00547-001-s097><upset.aufregen><de> Mamas Appetit verändert, als sie im Alter und die großen Portionen, die serviert wurden aufregen.
<G-vec00547-001-s097><upset.aufregen><en> Mom’s appetite changed as she aged and the large portions that were served upset her.
<G-vec00547-001-s098><upset.aufregen><de> Der flüchtige Widder wird aufregen Ihr Nerven Natur, den Schluss zu sein unseligen und sicherlich nicht von Dauer.
<G-vec00547-001-s098><upset.aufregen><en> The volatile Aries will upset your nervous nature, the conclusion being ill-fated and certainly not lasting.
<G-vec00547-001-s099><upset.aufregen><de> Tun Sie alles, damit sie sich nicht beleidigen, aufregen und weinen müssen, aber im Gegenteil, sie strahlen vor Glück und Freude.
<G-vec00547-001-s099><upset.aufregen><en> Do everything so that they do not have to take offense, get upset and cry, but on the contrary, they would shine with happiness and joy.
<G-vec00547-001-s100><upset.aufregen><de> Höchstwahrscheinlich wird die Heuchelei des Auserwählten Sie in naher Zukunft aufregen.
<G-vec00547-001-s100><upset.aufregen><en> Most likely, the hypocrisy of the chosen one will upset you in the near future.
<G-vec00547-001-s101><upset.aufregen><de> Jährigen Jungen nicht aufregen - er der wichtigste Mann im Haus war.
<G-vec00547-001-s101><upset.aufregen><en> Eight-year boy did not upset - he was the main man in the house.
<G-vec00547-001-s102><upset.aufregen><de> Bevor sich jedoch jemand aufregt, weil er glaubt, diese Tests wären ein Mißbrauch gegenüber dem Lamm oder den Welpen, lassen Sie mich erklären, daß die Tests, die ich hier beschreibe, mit dem Alter und der Größe angemessenen Lämmern mit dicker Wolle durchgeführt werden.
<G-vec00547-001-s102><upset.aufregen><en> However, before anyone gets upset thinking that these tests are abusive to the lambs or to the puppies let me say that the tests I am describing are done with age-appropriate and size-appropriate lambs with thick wool.
<G-vec00547-001-s103><upset.aufregen><de> Und auch wenn die andere Person sich über unsere Ehrlichkeit aufregt - auf einer tieferen Ebene wird sie es letztendlich verstehen.
<G-vec00547-001-s103><upset.aufregen><en> And even when the other person gets upset at our honesty -- on a deeper level they will finally understand.
<G-vec00547-001-s104><upset.aufregen><de> F: (L) Also missinterpretiere ich Franks fehlende Rücksicht auf meine Gefühle, wenn er mich aussaugt und mich aufregt... Es ist in Wirklichkeit eine Aktivität des Diensts am Anderen, und es ist nur meine Subjektivität, die mich aufregt; folglich sollte ich als einen Dienst an ihn meine Subjektivität eliminieren, damit er weiterhin Negativität ausspeien kann, und mich das dann einfach nicht mehr berührt.
<G-vec00547-001-s104><upset.aufregen><en> Q: (L) So, I misinterpret Frank's lack of regard for my feelings because he spouts off and upsets me … that's really a service-to-others activity and it is only my subjectivity that makes me get upset, therefore, I should eliminate my subjectivity as a service to him so that he can continue to spew off and therefore not upset me, is that what we are getting at here?
<G-vec00547-001-s105><upset.aufregen><de> Der Punkt ist jedoch der, dass Frank genau wusste, dass von allen privaten Dingen, die ich ihm jemals anvertraute, dieser mich am meisten verletzt und aufregt.
<G-vec00547-001-s105><upset.aufregen><en> But the point was that, of all the private things I had ever confided to Frank, this was the one thing that he knew would hurt and upset me the most.
<G-vec00547-001-s106><upset.aufregen><de> Twi > Ich dachte halt, dass es dich aufregt, dass die Katholiken anderen das Feiern verbieten.
<G-vec00547-001-s106><upset.aufregen><en> Twi > I just thought it might upset you that the catholics don’t let others celebrate their holidays.
<G-vec00547-001-s107><upset.aufregen><de> Aus der Erkenntnis einiger Zeichen folgern wir, dass sich die Person aufregt.
<G-vec00547-001-s107><upset.aufregen><en> Based on recognizing certain signs, we conclude that the person is upset.
<G-vec00547-001-s115><upset.aufregen><de> Ihr braucht euch über nichts aufzuregen, es sind alles nur Prüfungen, die das Gute in euch hervorbringen werden und Früchte tragen werden.
<G-vec00547-001-s115><upset.aufregen><en> There is nothing to be upset; these are all different tests which will work out the goodness in you and we’ll get the results.
<G-vec00547-001-s116><upset.aufregen><de> Wenn etwas unglücklich mit dir passiert dann statt sich aufzuregen, nutzen verlor Photo Recovery Software und Wiederherstellung Ihrer Bilder zurück, da es nach wie vor.
<G-vec00547-001-s116><upset.aufregen><en> If something miserable happens to you then instead of getting upset, make use of lost photo recovery software and restore your pictures back as it is as before.
<G-vec00547-001-s117><upset.aufregen><de> Er sagt: Wenn wir ein Leiden, eine schwierige Situation durchmachen, und es gibt etwas, das wir dagegen tun können, tun wir es einfach – ohne ärgerlich zu werden oder uns aufzuregen, denn das wird nichts nützen.
<G-vec00547-001-s117><upset.aufregen><en> Shantideva speaks quite a bit about this, and he says if we have suffering, a difficult situation, if there's something we can do about it, just do it – without getting angry or upset, because that's not going to help.
<G-vec00547-001-s118><upset.aufregen><de> Unsere Absicht ist nicht euch zu schockieren oder aufzuregen.
<G-vec00547-001-s118><upset.aufregen><en> Our intent is not to shock or upset you.
<G-vec00547-001-s119><upset.aufregen><de> Aber es ist nicht eure Sache, euch darüber aufzuregen, denn wenn ihr einmal das Ufer der Freude erreicht habt, dann solltet ihr das nicht leichtfertig aufgeben.
<G-vec00547-001-s119><upset.aufregen><en> But there’s – it is not for you to be upset about it. Because once you have reached the shores of joy then you should not give it up for anything.
<G-vec00547-001-s120><upset.aufregen><de> Sie sind besorgt über Mediendateien, die von der Speicherkarte, um Mac Computer immer übertragen beschädigte bilder von SD karte wiederherstellen Mac Es besteht keine Notwendigkeit, sich aufzuregen dies sagt Ihnen, wie zurückMedienDateien von unzugänglichen Speicherkarte unter Mac OS zu bekommen.
<G-vec00547-001-s120><upset.aufregen><en> You are worried about media files that were getting transferred from memory card to Mac computer. There is no need to get upset this tells you how to get back media files from inaccessible memory card on Mac OS.
<G-vec00547-001-s121><upset.aufregen><de> Wenn Sie, dass Sie kein Talent haben zu denken, nichts überstürzen, sich aufzuregen, nehmen Sie nur einen Stift und ein Stück Papier und die Anwendung auszuführen.
<G-vec00547-001-s121><upset.aufregen><en> If you think that you have no talent, do not rush to get upset, just take a pencil and a piece of paper and run the application.
<G-vec00547-001-s122><upset.aufregen><de> Dann keine Notwendigkeit, sich aufzuregen, können Sie ganz einfach mit leistungsstarken Datei Recovery-Software wie Yodot File Wiederherstellungs abrufen komprimierte NTFS-Dateien.
<G-vec00547-001-s122><upset.aufregen><en> Then no need to get upset, you can easily retrieve compressed NTFS files using powerful file recovery software like Yodot File Recovery.
<G-vec00547-001-s123><upset.aufregen><de> Es besteht keine Notwendigkeit, sich aufzuregen!Dateien verloren gehen oder von Samsung externe Festplatte gelöscht werden, indem wirksame externe Festplatte Recovery-Tool wieder hergestellt werden.
<G-vec00547-001-s123><upset.aufregen><en> There is no need to get upset! Files lost or deleted from Samsung external hard drive can be restored by using effective external drive recovery tool.
<G-vec00547-001-s264><upset.aufregen><de> """Ich rege mich selten auf, wenn ein Experiment scheinbar misslingt"", sagt Schüth, ""denn oft bringt erst der Misserfolg eine neue Erkenntnis."
<G-vec00547-001-s264><upset.aufregen><en> """I rarely get upset when an experiment apparently fails,"" says SchÃ1⁄4th, ""because it is often failure itself that brings new knowledge."
<G-vec00547-001-s265><upset.aufregen><de> """Ich rege mich nicht auf."
<G-vec00547-001-s265><upset.aufregen><en> """I never get upset."
<G-vec00547-001-s266><upset.aufregen><de> „Ich rege mich selten auf, wenn ein Experiment scheinbar misslingt“, sagt Schüth, „denn oft bringt erst der Misserfolg eine neue Erkenntnis.
<G-vec00547-001-s266><upset.aufregen><en> “I rarely get upset when an experiment apparently fails,” says Schüth, “because it is often failure itself that brings new knowledge.
<G-vec00243-002-s032><fret.aufregen><de> In den letzten Tagen fragte ich mich, warum der Körper so sehr in die Schwierigkeiten der Transformation vertieft war, und ich bekam keine Antwort, außer geduldig und ruhig zu sein und mich nicht aufzuregen – wie immer.
<G-vec00243-002-s032><fret.aufregen><en> These last few days too, I wondered why the body is so absorbed in the difficulties of the transformation, and I received no answer, except to be patient and tranquil and not to fret – as always.
