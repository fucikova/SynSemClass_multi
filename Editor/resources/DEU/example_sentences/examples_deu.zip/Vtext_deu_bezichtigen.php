<G-vec00347-001-s090><accuse.bezichtigen><de> Manchmal fühlst du dich wirklich gut, jemand wird dich dann vielleicht der Eitelkeit bezichtigen, aber dann ist der nur eifersüchtig.
<G-vec00347-001-s090><accuse.bezichtigen><en> Often if you´re feeling good about yourself, someone may accuse you of being vain, but that´s just them being jealous of you.
<G-vec00347-001-s091><accuse.bezichtigen><de> Er wäre sehr empört wenn man ihn einer Tötung bezichtigen würde.
<G-vec00347-001-s091><accuse.bezichtigen><en> He would be highly upset if someone would accuse him of killing a person.
<G-vec00347-001-s092><accuse.bezichtigen><de> Israel benutzte dies als Vorwand, die Palästinenser des Terrorismus zu bezichtigen, und konnte damit das wahre Wesen des Konfliktes verfälschen, ihn als einen israelischen Krieg gegen den Terrorismus darstellen und nicht als israelische Besetzung, die auf legitimen palästinensischen Widerstand zu ihrer Beendigung stößt.
<G-vec00347-001-s092><accuse.bezichtigen><en> Israel used this as a pretext to accuse the Palestinians of being terrorists and was able to distort the real nature of the conflict, presenting it as an Israeli war against terror, rather than an Israeli occupation faced by Palestinian legal resistance aiming at ending it.
<G-vec00347-001-s093><accuse.bezichtigen><de> Die Verfasser dieser Artikel benutzten einseitige, widerspr ü chliche Argumente und zogen voreingenommen Schlussfolgerungen, um Hizb-ut-Tahrir angeblicher terroristischer Aktivit ä ten zu bezichtigen.
<G-vec00347-001-s093><accuse.bezichtigen><en> The writers of these articles have made one sided, contradictory arguments and made biased conclusion in an effort to accuse Hizb ut Tahrir of alleged terrorist activities.
<G-vec00347-001-s094><accuse.bezichtigen><de> Wenn Trump den chinesischen Präsidenten Xi Jinping trifft, wird Friedman ihn der Mitwisserschaft nicht nur mit dem russischen, sondern auch mit dem chinesischen Feind bezichtigen.
<G-vec00347-001-s094><accuse.bezichtigen><en> When Trump meets the Chinese president Xi Jinping, Friedman will accuse him of connivance not only with the Russian but also with the Chinese enemy.
<G-vec00347-001-s095><accuse.bezichtigen><de> Es muss jedoch bemerkt werden, daß es ungerecht wäre, Junius der Gleichgültigkeit den nationalen Bewegungen gegenüber zu bezichtigen.
<G-vec00347-001-s095><accuse.bezichtigen><en> We must state, however, that it would be unfair to accuse Junius of being indifferent to national movements.
<G-vec00347-001-s096><accuse.bezichtigen><de> Aber die Spione brauchten nicht lange auf eine Gelegenheit zu warten, Jesus und seine Gefährten des Sabbatbruchs zu bezichtigen.
<G-vec00347-001-s096><accuse.bezichtigen><en> But the spies did not have long to wait for their opportunity to accuse Jesus and his associates of Sabbath breaking.
<G-vec00347-001-s097><accuse.bezichtigen><de> Ihr lästert Gott, indem ihr betont, es gäbe drei Götter und einer von ihnen sei gekreuzigt worden.“ Juden und Muslime bezichtigen die Christen ununterbrochener Gotteslästerung und des Götzendienstes, weil sie an die Heilige Dreieinigkeit glauben.
<G-vec00347-001-s097><accuse.bezichtigen><en> You blaspheme God by claiming that there are three gods, and that one of them died on the cross.“ Jews and Muslims accuse Christians of blasphemy because they believe in the unity of the holy Trinity.
<G-vec00347-001-s098><accuse.bezichtigen><de> Er betont, dass die Römischen Katholiken die Griechisch Orthodoxen bezichtigen, den Text der heiligen Schriften durch Zusätze und Auslassungen sowohl mit guten als auch mit schlechten Absichten abgewandelt zu haben.
<G-vec00347-001-s098><accuse.bezichtigen><en> He points out that the Roman Catholics accuse the Greek Orthodox Church of remodeling the text of the holy scriptures by additions and omissions with both good as well as evil intentions.
<G-vec00347-001-s099><accuse.bezichtigen><de> Sie wollen was finden, mit dem sie uns dann bezichtigen können, sie wollen was gegen uns aufspüren.
<G-vec00347-001-s099><accuse.bezichtigen><en> But what is really going on: they are looking for a reason to accuse you, to find something against you.
<G-vec00347-001-s100><accuse.bezichtigen><de> Nun bezichtigt jeder jeden des Diebstahls.
<G-vec00347-001-s100><accuse.bezichtigen><en> clef and now the families accuse each other of
<G-vec00347-001-s101><accuse.bezichtigen><de> Er entdeckte gleichzeitig mit Galilei die Jupitermonde, veröffentlichte aber erst nach diesem, woraufhin ihn Galilei des Plagiats bezichtigte.
<G-vec00347-001-s101><accuse.bezichtigen><en> Simultaneously with Galileo, he discovered the four largest of the Iovian moons, but published his findings four years later than Galileo, prompting the latter to accuse him of plagiarism.
<G-vec00347-001-s102><accuse.bezichtigen><de> Er bezichtigte mich immer wieder, ich würde lügen und nur im Sinn haben, ihn zu zerstören und ihm seine Freunde zu nehmen.
<G-vec00347-001-s102><accuse.bezichtigen><en> He continued to accuse me of lying and of wanting only to destroy him and take his friends from him.
<G-vec00347-001-s156><accuse.bezichtigen><de> Sie, Herr Jakobs, haben gerade auf die aktuellen Tweets des Präsidenten verwiesen, der pauschal die Medien der Lüge bezichtigt, von Fake News spricht, der sich weigert von bestimmten Journalistinnen und Journalisten Fragen entgegen zu nehmen.
<G-vec00347-001-s156><accuse.bezichtigen><en> You, Mr Jacobs, have just referred to the President's current tweets, which accuse the media of lying, of fake news, which refuses to take questions from certain journalists.
<G-vec00347-002-s078><accuse.bezichtigen><de> Die Plakate bezichtigen mit Bildern und Texten die polnische Bevölkerung grausamer Unrechtstaten.
<G-vec00347-002-s078><accuse.bezichtigen><en> The posters which include pictures accuse the Polish people of terrible crimes against Germans.
