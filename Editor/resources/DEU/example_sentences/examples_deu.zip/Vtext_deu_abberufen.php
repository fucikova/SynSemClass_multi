<G-vec00555-002-s108><dismiss.abberufen><de> (11) Nach vorheriger Zustimmung der Regulierungsbehörde kann das Aufsichtsorgan den Gleichbehandlungsbeauftragten abberufen.
<G-vec00555-002-s108><dismiss.abberufen><en> 12. After prior approval by the regulatory authority, the Supervisory Body may dismiss the compliance officer.
<G-vec00555-002-s053><recall.abberufen><de> In diesen Fällen hat der Entsendestaat die betreffende Person entweder abzuberufen oder ihre dienstliche Tätigkeit beim konsularischen Posten zu beenden.
<G-vec00555-002-s053><recall.abberufen><en> In that event, the sending State shall, as the case may be, either recall the person concerned or terminate his functions with the consular post.
<G-vec00555-002-s054><recall.abberufen><de> Der Sprecher der Zanu-PF für die Region Midlands, Cornelius Mupereri, sagte dem staatlichen Fernsehsender ZBC, seine Provinz habe sich "einstimmig" dafür ausgesprochen, den 93-jährigen Staatschef abzuberufen.
<G-vec00555-002-s054><recall.abberufen><en> "The province resolved unanimously to recall the president... from being the president of the party and the government," said Cornelius Mupereri, a spokesman for the party's Midlands region.
<G-vec00555-002-s055><recall.abberufen><de> In diesen Fällen hat der Entsendestaat die betreffende Person entweder abzuberufen oder ihre dienstliche Tätigkeit bei der konsularischen Vertretung zu beenden.
<G-vec00555-002-s055><recall.abberufen><en> In that event, the sending State shall, as the case may be, either recall the person concerned or terminate his functions with the consular post.
