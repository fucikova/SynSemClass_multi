<G-vec00092-001-s152><need.brauchen><de> Ich brauche einen Fußball und ein Schachspiel.
<G-vec00092-001-s152><need.brauchen><en> I need a football and a chess board.
<G-vec00092-001-s153><need.brauchen><de> Preis ist für Renovierung, ich brauche ihre alte Tacho, Lieferzeit 2-3 Wochen.
<G-vec00092-001-s153><need.brauchen><en> Price is for renovation, I need your old speedometer,delivery date2-3 Weeks.
<G-vec00092-001-s154><need.brauchen><de> Aber euch macht es nichts aus, irgendetwas zu essen, das ist eine gute Eigenschaft von euch, aber eure Wünsche sind andere, ein wenig unterschiedlich, was ihr sehr wohl wisst, Ich brauche es euch nicht zu erzählen.
<G-vec00092-001-s154><need.brauchen><en> But you don't mind eating any food whatsoever, that's a good thing about you, but your desires are another, little different, which you know very well, I need not tell you.
<G-vec00092-001-s155><need.brauchen><de> """Ich sollte zur Universität gehen, doch mein Vater sagte zu mir: hör mal, Giorgio, ich brauche dich, komme in die Firma."
<G-vec00092-001-s155><need.brauchen><en> """I was about to go to university, when my father said to me: Look, Giorgio, I need you, come join the company."
<G-vec00092-001-s156><need.brauchen><de> Hinweis 9 füllt dieses Manko mit seiner extrem schnellen Kamera, mit der ich nie die Aufnahme verpasse, die ich brauche, normalerweise eine sehr ausgewogene Belichtung, viel Liebe zum Detail und eine ordentliche Kamera-App.
<G-vec00092-001-s156><need.brauchen><en> Note 9 fills this shortcoming with its extremely fast camera, with which I never miss the shot I need, usually a very balanced exposure, a lot of attention to detail and a neat camera app.
<G-vec00092-001-s157><need.brauchen><de> Ich führe auch Prozess in Bezug auf die Zeit, die ich verschwendet habe, die ich damit hätte verbringen können, in meinem Geschäft zu arbeiten, anstatt Jesus zu ehren, von dem Ihre Kirche sagt, ich brauche für mein Heil nicht an ihn zu glauben.
<G-vec00092-001-s157><need.brauchen><en> I am litigating as well over the time that I wasted that I could have spent working in my business, instead of squandering it worshipping a Jesus that your Church now says I don't need to believe in for my salvation.
<G-vec00092-001-s158><need.brauchen><de> Bitte brauche ich Hilfe.
<G-vec00092-001-s158><need.brauchen><en> Please I need help.
<G-vec00092-001-s159><need.brauchen><de> Ich bin ein Typ und ich brauche Personal bitte.
<G-vec00092-001-s159><need.brauchen><en> I'm one guy and I need staff please.
<G-vec00092-001-s160><need.brauchen><de> Ich brauche Apostel mit reinem Herzen.
<G-vec00092-001-s160><need.brauchen><en> I need apostles with a pure heart.
<G-vec00092-001-s161><need.brauchen><de> Wenn Christen dieses falsche Denkschema übernehmen, dann kommen sie zu dem Schluß, daß es wohl kaum notwendig sei, bei der Darlegung des christlichen Glaubens die objektive Wahrheit hervorzuheben: man brauche nur seinem Gewissen zu folgen und eine Gemeinschaft zu wählen, die dem eigenen Geschmack am besten entspricht.
<G-vec00092-001-s161><need.brauchen><en> For Christians to accept this faulty line of reasoning would lead to the notion that there is little need to emphasize objective truth in the presentation of the Christian faith, for one need but follow his or her own conscience and choose a community that best suits his or her individual tastes.
<G-vec00092-001-s162><need.brauchen><de> Ich brauche den Freischaltcode für meine TigerStop .
<G-vec00092-001-s162><need.brauchen><en> I need the enable code for my TigerStop.
<G-vec00092-001-s163><need.brauchen><de> Ihr könnt gehen, ich brauche euch nicht mehr.
<G-vec00092-001-s163><need.brauchen><en> You are free to go, I no longer need you.
<G-vec00092-001-s164><need.brauchen><de> Ich brauche nicht auf eine konkrete so entfernen, Ich mehr brauchen, um es zu schneiden.
<G-vec00092-001-s164><need.brauchen><en> I don’t need to remove any concrete like that, I more need to cut it.
<G-vec00092-001-s165><need.brauchen><de> Am Auto angekommen brauche ich erst einmal etwas zum Trinken.
<G-vec00092-001-s165><need.brauchen><en> Back at my car I need something to drink first.
<G-vec00092-001-s166><need.brauchen><de> Ich brauche Sie, die Kinder brauchen Sie, Little Smile braucht Sie, ein besseres Sri Lanka braucht Sie.
<G-vec00092-001-s166><need.brauchen><en> I need you, the children need you, Little Smile needs you, a better Sri Lanka needs you.
<G-vec00092-001-s167><need.brauchen><de> Ich werde schneller fertig und brauche weniger Kraft.
<G-vec00092-001-s167><need.brauchen><en> I get quicker and need less energy.
<G-vec00092-001-s168><need.brauchen><de> Befindet er sich bereits auf der Mauer, brauche nicht befürchtet zu werden, daß der Getroffene auf der rückwärtigen Seite der Mauer niederfällt, weil man gegen die Schußrichtung fällt.
<G-vec00092-001-s168><need.brauchen><en> In case he has climbed the wall already, there's no need to fear that he could fall down at the other side of the wall, for one usually falls to the opposite direction of fire.
<G-vec00092-001-s169><need.brauchen><de> Offenbarung 3:17-19 17 Ihr sagt, 'Ich bin reich und ich bin reich geworden und brauche nichts' und ihr wisst nicht, dass ihr elend, bemitleidenswert, arm, blind und bloß seid.
<G-vec00092-001-s169><need.brauchen><en> Revelation 3:17-19 17 Because you say, 'Rich I am, and I am made rich, and need none at all,' and do not know that you are wretched, and pitiable, and poor, and blind, and naked.
<G-vec00092-001-s170><need.brauchen><de> Um mir alle Dinge zur Verfügung zu stellen, die ich brauche.
<G-vec00092-001-s170><need.brauchen><en> To provide me all the things that I need.
<G-vec00092-001-s171><need.brauchen><de> Sofern Sie 're ein Ausdauersportler, brauchen Sie nur eine Portion von unverarbeiteten Kohlenhydrate wie grünes Pulver pro Mahlzeit.
<G-vec00092-001-s171><need.brauchen><en> If you are not a professional athlete, you need only one serving of unprocessed carbohydrates like green powder eating.
<G-vec00092-001-s172><need.brauchen><de> Haben Sie fragen oder brauchen Sie weitere Informationen hören wir gern von Sie auf Telefon +45 86 966 566 oder bitte füllen Sie die nachstehenden Feldern aus, dann werden wir schon zuückmelden.
<G-vec00092-001-s172><need.brauchen><en> If your need further information please don't hesitate to call us at +45 86 966 566 or fill in the form below: Thank you. Firm: *
<G-vec00092-001-s173><need.brauchen><de> Wer abnehmen möchte, sollte also als erstes seine körpereignen Schlankheitshormone mit den Nährstoffen zu versorgen, die Sie brauchen, um arbeiten zu können.
<G-vec00092-001-s173><need.brauchen><en> If you want to lose weight, you must therefore first supply your body's slimming hormones with the nutrients that they need in order to function.
<G-vec00092-001-s174><need.brauchen><de> Wir brauchen außerdem viel bessere Metriken, um finanzielle Risiken im Zusammenhang mit dem Klimawandel und deren Auswirkungen auf unsere Anlageportfolios besser beurteilen zu können.
<G-vec00092-001-s174><need.brauchen><en> We also need much better metrics to assess climate-related financial risks and their impact in investment portfolios
<G-vec00092-001-s175><need.brauchen><de> mist -air wird das Raingunsystem installieren, um absolute Abdeckung sicherzustellen, wann und wo Sie es brauchen.
<G-vec00092-001-s175><need.brauchen><en> mist -air will install the Rain Gun System to give you total coverage - whenever and wherever you need it.
<G-vec00092-001-s176><need.brauchen><de> Hätten Sie einen ruhigen Tag und fühlen sich Sie mehr Übung brauchen, wird Ihnen eine flottes Schwimmen gegen den Strom in unserem Widerstand-Pool, dass dringend benötigte Training geben.
<G-vec00092-001-s176><need.brauchen><en> If you had a quiet day and feel you need more exercise, a brisk swim against the current in our resistance pool will give you that much needed workout.
<G-vec00092-001-s177><need.brauchen><de> Vielen Dank für Ihren Besuch auf Paradoxion Spiel Seite, hoffentlich finden Sie alle Informationen, die Sie brauchen etwa Paradoxion und mag dieses Spiel.
<G-vec00092-001-s177><need.brauchen><en> Thanks for visiting Paradoxion game page, hopefully you found all the information you need about Paradoxion and like this game.
<G-vec00092-001-s178><need.brauchen><de> Gletscher brauchen Wasser und so muss man für die tollen Eindrücke meistens einiges an Regen und Kälte in Kauf nehmen.
<G-vec00092-001-s178><need.brauchen><en> Glaciers need water, so you mostly have to accept a good deal of rain and cold in exchange for the great impressions.
<G-vec00092-001-s179><need.brauchen><de> """Menschen brauchen Menschen"", nach diesem Zitat handelt Angel Delgadillo und widmet diesen Appell an an seine Mitbürger in Seligman, es genauso zu tun."
<G-vec00092-001-s179><need.brauchen><en> """People need people""; this is a guideline for Angel Delgadillo in devoting himself to the visitors and with the advice for his fellow citizens in Seligman to do so also."
<G-vec00092-001-s180><need.brauchen><de> Für eine schöne Frau zu Datum, das Sie und wollen auch weiterhin Dating Sie dann brauchen Sie, um sich von all den anderen Männern versucht, sie zu gewinnen.
<G-vec00092-001-s180><need.brauchen><en> For a beautiful woman to date you and want to continue dating you then you need to stand out from all the other men trying to win her over. 2.
<G-vec00092-001-s181><need.brauchen><de> Die Studenten brauchen die Codes sowohl auf der Hardware- wie auf der Softwareebene, um den Blick zu befreien.
<G-vec00092-001-s181><need.brauchen><en> Students need the codes on both the hardware and software levels in order to give them the freedom they need.
<G-vec00092-001-s182><need.brauchen><de> Wenn Sie aus eine der Ländern von der Liste kommen und beabsichtigen bis 90 Tage im Land zu verbringen, alles was Sie brauchen ist ein gültiger Reisepass.
<G-vec00092-001-s182><need.brauchen><en> If you are arriving from one of the countries on the list below and you intend to stay up to 90 days, a valid passport is all you need.
<G-vec00092-001-s183><need.brauchen><de> Olivenbäume brauchen Jahrzehnte und Jahrhunderte, um zu wachsen, und so viele Tausend davon waren einfach aus dem Boden gerissen worden.
<G-vec00092-001-s183><need.brauchen><en> Olive trees need decades and centuries to grow and so many thousands of them were pulled out of the ground.
<G-vec00092-001-s184><need.brauchen><de> Außerdem brauchen Sie einen Computer der den EMS Data Generator for PostgreSQL System Anforderungen entspricht.
<G-vec00092-001-s184><need.brauchen><en> Besides you need your computer to satisfy the system requirements of EMS Data Generator for PostgreSQL.
<G-vec00092-001-s185><need.brauchen><de> Wenn Sie medizinischen Rat für Kinder bis zu zwölf Jahren brauchen, wählen Sie die 1.
<G-vec00092-001-s185><need.brauchen><en> If you need medical advice for children up to twelve years old, press 1.
<G-vec00092-001-s186><need.brauchen><de> Die brauchen uns, um das zu tun, was sie tun.
<G-vec00092-001-s186><need.brauchen><en> They need us to do what they're doing.
<G-vec00092-001-s187><need.brauchen><de> Ein ungewöhnlich redseliger Joutsen betont immer wieder, wie alt sie doch sind und das sie immer wieder kleine Pausen brauchen, um sich zu erholen.
<G-vec00092-001-s187><need.brauchen><en> An exceptionally talkative Joutsen keeps mentioning how old they are and therefore need some breaks to recover.
<G-vec00092-001-s188><need.brauchen><de> Um sich mit Kollegen auf Englisch unterhalten zu können, brauchen Sie deshalb ein spezielles Vokabular.
<G-vec00092-001-s188><need.brauchen><en> In order to speak with other colleagues effectively you need a special vocabulary.
<G-vec00092-001-s189><need.brauchen><de> Adresse: Via Degli Oleandri, 37 - 56018 Tirrenia (Pisa) Es gibt einen Ort, wo Sie kein Wort brauchen, um verstanden zu werden, keinen Vergleich, um sich gut zu fühlen, keine starke Empfindungen, um sich aufzuregen.
<G-vec00092-001-s189><need.brauchen><en> Address: Via Degli Oleandri, 37 - 56018 Tirrenia (Pisa) There's a place, where you don't need of words to make yourself understood, of comparisons to feel that you are well, of strong sensations to get excited.
<G-vec00092-001-s152><require.brauchen><de> Frauen brauchen im Schnitt 17 Sekunden und 1,62 Lenkbewegungen für den Parkvorgang.
<G-vec00092-001-s152><require.brauchen><en> Women require an average of 17 seconds and 1.62 steering movements in order to park.
<G-vec00092-001-s153><require.brauchen><de> Solarmodule liefern 100 % saubere Energie, brauchen aber Platz.
<G-vec00092-001-s153><require.brauchen><en> Solar panels provide 100% clean energy, but they do require space.
<G-vec00092-001-s154><require.brauchen><de> Die mit der Flasche aufgezogenen Kälber sind zum Beispiel arbeitsintensiver und brauchen mehr Pflege als ein säugendes Kalb.
<G-vec00092-001-s154><require.brauchen><en> Bottle calves tend to be more labour intensive thus require more care than weaned steer or heifer calves, for instance.
<G-vec00092-001-s155><require.brauchen><de> Geschäftliche Partnerschaften brauchen gelegentlich die Pflege in einem gesellschaftlichen Rahmen und der Sport gehört nun einmal heute in diesen Rahmen.
<G-vec00092-001-s155><require.brauchen><en> Business partnerships occasionally require some nurturing in a social framework and sport is part of this framework.
<G-vec00092-001-s156><require.brauchen><de> Bedenklich stimmt, dass eine alternde Bevölkerung durch den Rückschnitt des privaten Rentensystems immer mehr staatliche Unterstützung brauchen und verlangen wird.
<G-vec00092-001-s156><require.brauchen><en> The worry is that by scaling back private pension systems, in the future, an aging population will require and demand larger and larger government support.
<G-vec00092-001-s157><require.brauchen><de> Bürger der folgenden Länder brauchen ein Visum und sollten sich in Kontakt mit dem Ecuadorianischen Konsulat ihres Landes setzten (die Liste ist Änderungen unterworfen): Algerien, Bangladesh, Costa Rica, Kuba, Salvador, Guatemala, Indien, Iran, Irak, Jordanien, Libanon, Libyen, Nicaragua, Nigeria, Nordkorea, Pakistan, Israel, Panama,Volksrepublik China, Sri Lanka, Syrien, Tunesien und Vietnam.
<G-vec00092-001-s157><require.brauchen><en> Nationals of the following countries require a visa and should approach the Consulate of Ecuador of their residence (list may change without notice): Algeria, Bangladesh, Costa Rica, Cuba, El Salvador, Guatemala, India, Iran, Iraq, Jordan, Lebanon, Libya, Nicaragua, Nigeria, North Korea, Pakistan, Palestine Authority, Panama, People's Republic of China, Sri Lanka, Syria, Tunisia and Vietnam.
<G-vec00092-001-s158><require.brauchen><de> Sie zahlen nur die Serviceleistung, die Sie auch wirklich brauchen, um Ihre Anlage optimal zu warten.
<G-vec00092-001-s158><require.brauchen><en> You only pay for the service you actually require to maintain optimum operation of your process.
<G-vec00092-001-s159><require.brauchen><de> Maschinen und Geräte, welche im In- oder Outdoorbereich regelmäßig Schmutz, Staub und Flüssigkeiten ausgesetzt sind, brauchen robuste D-Sub Steckverbinder.
<G-vec00092-001-s159><require.brauchen><en> Machines and equipment, operating in- and outdoor and exposed to dirt, dust and liquid, require rugged D-Sub connector solutions.
<G-vec00092-001-s160><require.brauchen><de> Alle brauchen sie Sauerstoff um zu wachsen, und oftmals kann man sie riechen.
<G-vec00092-001-s160><require.brauchen><en> They all require oxygen in order to grow, and quite often you can smell their presence.
<G-vec00092-001-s161><require.brauchen><de> Hier in der internationalen Unternehmenszentrale des Südtiroler Herstellers für spezielle Lebensmittel wird geforscht, entwickelt, geprüft, produziert und vermarktet was Konsumenten mit besonderen Ernährungsbedürfnissen weltweit brauchen.
<G-vec00092-001-s161><require.brauchen><en> Here at the international headquarters of the South Tyrolean manufacturer of special foods, the company researches, develops, tests, produces and markets what consumers worldwide with special nutritional needs require.
<G-vec00092-001-s162><require.brauchen><de> Die 150 Millionen Einwohner der südostchinesischen Küstenregion brauchen für die Kühlung ihrer Wohnungen mit Klimaanlagen jährlich immense Energiemengen.6 Jeder Haushalt verfügt über zwei bis fünf Klimaanlagen und Bürogebäude werden ebenfalls ausschließlich über Klimaaggregate gekühlt – denn ein behagliches Raumklima ist in den Arbeitsplatz-Richtlinien vorgeschrieben.
<G-vec00092-001-s162><require.brauchen><en> The 150 million residents of the southeastern coastal area of China require immense amounts of energy each year to cool their homes through air-conditioning.6 Each household boasts two to five air conditioners, and office buildings are likewise solely cooled with temperature-control units – for a comfortable indoor climate is stipulated in workplace guidelines.
<G-vec00092-001-s163><require.brauchen><de> Selbst Atomuhren, die genauesten Uhren der Welt, brauchen Hilfe, um Drift zu verhindern, nicht weil die Uhren selbst driften - Atomuhren können für 100 Millionen Jahre genau eine Sekunde genau sein, aber die Rotation der Erde verlangsamt sich.
<G-vec00092-001-s163><require.brauchen><en> Even atomic clocks, the world’s most accurate clocks, require help in preventing drift, not because the clocks themselves drift—atomic clocks can remain accurate to a second for 100 million years, but the Earth’s rotation is slowing.
<G-vec00092-001-s164><require.brauchen><de> Hunde brauchen keine Line und keinen Maulkorb, wenn sie in einem Käfig sind.
<G-vec00092-001-s164><require.brauchen><en> Dogs do not require a leash nor a muzzle if they are inside a cage.
<G-vec00092-001-s165><require.brauchen><de> Als eine sehr starke und leistungsfähige Droge, die es nur von Menschen in Minnesota Deutschland verwendet werden soll, die Hilfe brauchen Abbau Pfund, aber konnten nicht finden Erfolg mit regelmäßiger Diät und Übung.
<G-vec00092-001-s165><require.brauchen><en> As a really powerful and powerful medication it should just be utilized by individuals in Minnesota Germany that require help shedding pounds however have not been able to discover success with routine diet programs and physical exercise.
<G-vec00092-001-s166><require.brauchen><de> Natürlich können Sie Steroide legal erwerben, sprechen mit Ihren Ärzten, diesen empfohlenen, zu erwerben, wenn Sie diese Medikamente wirklich brauchen.
<G-vec00092-001-s166><require.brauchen><en> Naturally, you can acquire steroids lawfully, consulting with your physicians, obtaining these recommended, if you actually require these drugs.
<G-vec00092-001-s167><require.brauchen><de> Zwar gibt es einige Kritiken von den Ursprung, die PhenQ behaupten, dass sie nicht mehr brauchen Arbeit aus, da es ebenfalls effektiv genug sein, zu kaufen, Ärzte raten immer noch, dass eine Übung mit geeigneten Diät-Plan durchgeführt eingebaut werden während der Einnahme dieses Ergänzungsmittel für gesicherte Ergebnisse .
<G-vec00092-001-s167><require.brauchen><en> Though there are some testimonials originating from those that acquire PhenQ saying that it does not require any more exercising considering that it can additionally be effective on its own, physicians still advise that a workout be done integrated with proper diet plan while taking this supplement for assured outcomes.
<G-vec00092-001-s168><require.brauchen><de> Nur wenige der derzeit erhältlichen Geräte brauchen die Leistung, die mit PoE+ erzielt wird, aber das wird sich in Zukunft wahrscheinlich ändern.
<G-vec00092-001-s168><require.brauchen><en> Only a few current devices require the level of power offered by PoE+, but that's likely to change.
<G-vec00092-001-s169><require.brauchen><de> Da meinet ihr, dass sie die gleiche Behandlung brauchen, und sie würden umgetauscht auch wachsen.
<G-vec00092-001-s169><require.brauchen><en> You might think that they both require the same treatment and that they would also grow if they changed places.
<G-vec00092-001-s170><require.brauchen><de> Gleich, ob es nur um einige wesentliche Komponenten geht oder eine größere Nachrüstung der Bahnspannungsregelung, Montalvo liefert Ihnen die Leistungssteigerungen, die Sie in den kommenden Jahren brauchen.
<G-vec00092-001-s170><require.brauchen><en> Whether it's just a few key component upgrades or a larger tension control retrofit, Montalvo gives you the performance enhancements you require for years to come.
<G-vec00272-001-s152><require.brauchen><de> Frauen brauchen im Schnitt 17 Sekunden und 1,62 Lenkbewegungen für den Parkvorgang.
<G-vec00272-001-s152><require.brauchen><en> Women require an average of 17 seconds and 1.62 steering movements in order to park.
<G-vec00272-001-s153><require.brauchen><de> Solarmodule liefern 100 % saubere Energie, brauchen aber Platz.
<G-vec00272-001-s153><require.brauchen><en> Solar panels provide 100% clean energy, but they do require space.
<G-vec00272-001-s154><require.brauchen><de> Die mit der Flasche aufgezogenen Kälber sind zum Beispiel arbeitsintensiver und brauchen mehr Pflege als ein säugendes Kalb.
<G-vec00272-001-s154><require.brauchen><en> Bottle calves tend to be more labour intensive thus require more care than weaned steer or heifer calves, for instance.
<G-vec00272-001-s155><require.brauchen><de> Geschäftliche Partnerschaften brauchen gelegentlich die Pflege in einem gesellschaftlichen Rahmen und der Sport gehört nun einmal heute in diesen Rahmen.
<G-vec00272-001-s155><require.brauchen><en> Business partnerships occasionally require some nurturing in a social framework and sport is part of this framework.
<G-vec00272-001-s156><require.brauchen><de> Bedenklich stimmt, dass eine alternde Bevölkerung durch den Rückschnitt des privaten Rentensystems immer mehr staatliche Unterstützung brauchen und verlangen wird.
<G-vec00272-001-s156><require.brauchen><en> The worry is that by scaling back private pension systems, in the future, an aging population will require and demand larger and larger government support.
<G-vec00272-001-s157><require.brauchen><de> Bürger der folgenden Länder brauchen ein Visum und sollten sich in Kontakt mit dem Ecuadorianischen Konsulat ihres Landes setzten (die Liste ist Änderungen unterworfen): Algerien, Bangladesh, Costa Rica, Kuba, Salvador, Guatemala, Indien, Iran, Irak, Jordanien, Libanon, Libyen, Nicaragua, Nigeria, Nordkorea, Pakistan, Israel, Panama,Volksrepublik China, Sri Lanka, Syrien, Tunesien und Vietnam.
<G-vec00272-001-s157><require.brauchen><en> Nationals of the following countries require a visa and should approach the Consulate of Ecuador of their residence (list may change without notice): Algeria, Bangladesh, Costa Rica, Cuba, El Salvador, Guatemala, India, Iran, Iraq, Jordan, Lebanon, Libya, Nicaragua, Nigeria, North Korea, Pakistan, Palestine Authority, Panama, People's Republic of China, Sri Lanka, Syria, Tunisia and Vietnam.
<G-vec00272-001-s158><require.brauchen><de> Sie zahlen nur die Serviceleistung, die Sie auch wirklich brauchen, um Ihre Anlage optimal zu warten.
<G-vec00272-001-s158><require.brauchen><en> You only pay for the service you actually require to maintain optimum operation of your process.
<G-vec00272-001-s159><require.brauchen><de> Maschinen und Geräte, welche im In- oder Outdoorbereich regelmäßig Schmutz, Staub und Flüssigkeiten ausgesetzt sind, brauchen robuste D-Sub Steckverbinder.
<G-vec00272-001-s159><require.brauchen><en> Machines and equipment, operating in- and outdoor and exposed to dirt, dust and liquid, require rugged D-Sub connector solutions.
<G-vec00272-001-s160><require.brauchen><de> Alle brauchen sie Sauerstoff um zu wachsen, und oftmals kann man sie riechen.
<G-vec00272-001-s160><require.brauchen><en> They all require oxygen in order to grow, and quite often you can smell their presence.
<G-vec00272-001-s161><require.brauchen><de> Hier in der internationalen Unternehmenszentrale des Südtiroler Herstellers für spezielle Lebensmittel wird geforscht, entwickelt, geprüft, produziert und vermarktet was Konsumenten mit besonderen Ernährungsbedürfnissen weltweit brauchen.
<G-vec00272-001-s161><require.brauchen><en> Here at the international headquarters of the South Tyrolean manufacturer of special foods, the company researches, develops, tests, produces and markets what consumers worldwide with special nutritional needs require.
<G-vec00272-001-s162><require.brauchen><de> Die 150 Millionen Einwohner der südostchinesischen Küstenregion brauchen für die Kühlung ihrer Wohnungen mit Klimaanlagen jährlich immense Energiemengen.6 Jeder Haushalt verfügt über zwei bis fünf Klimaanlagen und Bürogebäude werden ebenfalls ausschließlich über Klimaaggregate gekühlt – denn ein behagliches Raumklima ist in den Arbeitsplatz-Richtlinien vorgeschrieben.
<G-vec00272-001-s162><require.brauchen><en> The 150 million residents of the southeastern coastal area of China require immense amounts of energy each year to cool their homes through air-conditioning.6 Each household boasts two to five air conditioners, and office buildings are likewise solely cooled with temperature-control units – for a comfortable indoor climate is stipulated in workplace guidelines.
<G-vec00272-001-s163><require.brauchen><de> Selbst Atomuhren, die genauesten Uhren der Welt, brauchen Hilfe, um Drift zu verhindern, nicht weil die Uhren selbst driften - Atomuhren können für 100 Millionen Jahre genau eine Sekunde genau sein, aber die Rotation der Erde verlangsamt sich.
<G-vec00272-001-s163><require.brauchen><en> Even atomic clocks, the world’s most accurate clocks, require help in preventing drift, not because the clocks themselves drift—atomic clocks can remain accurate to a second for 100 million years, but the Earth’s rotation is slowing.
<G-vec00272-001-s164><require.brauchen><de> Hunde brauchen keine Line und keinen Maulkorb, wenn sie in einem Käfig sind.
<G-vec00272-001-s164><require.brauchen><en> Dogs do not require a leash nor a muzzle if they are inside a cage.
<G-vec00272-001-s165><require.brauchen><de> Als eine sehr starke und leistungsfähige Droge, die es nur von Menschen in Minnesota Deutschland verwendet werden soll, die Hilfe brauchen Abbau Pfund, aber konnten nicht finden Erfolg mit regelmäßiger Diät und Übung.
<G-vec00272-001-s165><require.brauchen><en> As a really powerful and powerful medication it should just be utilized by individuals in Minnesota Germany that require help shedding pounds however have not been able to discover success with routine diet programs and physical exercise.
<G-vec00272-001-s166><require.brauchen><de> Natürlich können Sie Steroide legal erwerben, sprechen mit Ihren Ärzten, diesen empfohlenen, zu erwerben, wenn Sie diese Medikamente wirklich brauchen.
<G-vec00272-001-s166><require.brauchen><en> Naturally, you can acquire steroids lawfully, consulting with your physicians, obtaining these recommended, if you actually require these drugs.
<G-vec00272-001-s167><require.brauchen><de> Zwar gibt es einige Kritiken von den Ursprung, die PhenQ behaupten, dass sie nicht mehr brauchen Arbeit aus, da es ebenfalls effektiv genug sein, zu kaufen, Ärzte raten immer noch, dass eine Übung mit geeigneten Diät-Plan durchgeführt eingebaut werden während der Einnahme dieses Ergänzungsmittel für gesicherte Ergebnisse .
<G-vec00272-001-s167><require.brauchen><en> Though there are some testimonials originating from those that acquire PhenQ saying that it does not require any more exercising considering that it can additionally be effective on its own, physicians still advise that a workout be done integrated with proper diet plan while taking this supplement for assured outcomes.
<G-vec00272-001-s168><require.brauchen><de> Nur wenige der derzeit erhältlichen Geräte brauchen die Leistung, die mit PoE+ erzielt wird, aber das wird sich in Zukunft wahrscheinlich ändern.
<G-vec00272-001-s168><require.brauchen><en> Only a few current devices require the level of power offered by PoE+, but that's likely to change.
<G-vec00272-001-s169><require.brauchen><de> Da meinet ihr, dass sie die gleiche Behandlung brauchen, und sie würden umgetauscht auch wachsen.
<G-vec00272-001-s169><require.brauchen><en> You might think that they both require the same treatment and that they would also grow if they changed places.
<G-vec00272-001-s170><require.brauchen><de> Gleich, ob es nur um einige wesentliche Komponenten geht oder eine größere Nachrüstung der Bahnspannungsregelung, Montalvo liefert Ihnen die Leistungssteigerungen, die Sie in den kommenden Jahren brauchen.
<G-vec00272-001-s170><require.brauchen><en> Whether it's just a few key component upgrades or a larger tension control retrofit, Montalvo gives you the performance enhancements you require for years to come.
<G-vec00092-001-s190><need.brauchen><de> Für uns bist du mehr als ein Tourist und wir sind immer da, wenn du uns brauchst.
<G-vec00092-001-s190><need.brauchen><en> For us you are more than a tourist and we are always there if you need us.
<G-vec00092-001-s191><need.brauchen><de> Password: 6ZaxN2Vzm9NUJT2y Der Code, den du brauchst, um dich als dieser Benutzer einzuloggen, ist: INSERT INTO `secure_login` .
<G-vec00092-001-s191><need.brauchen><en> The code you need in order to be able to log in as this user is: INSERT INTO `secure_login` .
<G-vec00092-001-s192><need.brauchen><de> Um aufnehmen zu können, brauchst du einen PC und ein Aufnahmegerät, das entweder ein Mikrofon sein kann, das an den PC angeschlossen wird, oder ein unabhängiges digitales Aufnahmegerät.
<G-vec00092-001-s192><need.brauchen><en> In order to record, you will need a computer and a recording device, which can either be a microphone that plugs into your computer or a digital recorder.
<G-vec00092-001-s193><need.brauchen><de> "Ich habe ihm gesagt: ""Du hast verstanden, du brauchst keine Träume und keine Visionen, um zu wissen, dass es der verkörperte Satan ist, der mit dir spricht""."
<G-vec00092-001-s193><need.brauchen><en> "I told him: ""you have understood, you don't need dreams and visions to know that the person talking to you is satan incarnate""."
<G-vec00092-001-s194><need.brauchen><de> Auch für einen neuen Lippenstift in Trendfarbe brauchst du nicht sofort Geld ausgeben.
<G-vec00092-001-s194><need.brauchen><en> A lipstick in a trendy color? You don't need to pay for it immediately.
<G-vec00092-001-s195><need.brauchen><de> Auf diese Weise wird dein Outfit gespeichert und du kannst es das nächste Mal, wenn du es brauchst einfach in der Liste mit deinen Outfits finden und anklicken.
<G-vec00092-001-s195><need.brauchen><en> This way your outfit will be saved and you could easily find it again when you need it by choosing it from the list with your outfits.
<G-vec00092-001-s196><need.brauchen><de> BuzzStream bietet alle Funktionen, die Du brauchst, um eine erfolgreiche Influencer-Marketing-Kampagne durchzuführen.
<G-vec00092-001-s196><need.brauchen><en> BuzzStream has all of the features that you need to run a successful influencer marketing campaign.
<G-vec00092-001-s197><need.brauchen><de> Es scheint vielleicht zu einfach um wahr zu sein, aber regelmäßiges Seilspringen kräftigt die Muskulatur, die du für einen vertikalen Sprung brauchst.
<G-vec00092-001-s197><need.brauchen><en> It might seem too obvious to be true, but jumping rope regularly will strengthen the muscles you need to execute a vertical leap.
<G-vec00092-001-s198><need.brauchen><de> Es spart Zeit, hilft Dir dabei, Dich zu konzentrieren und versorgt Dich mit den Informationen, die Du brauchst, um die Citations Deiner Wettbewerber zu finden.
<G-vec00092-001-s198><need.brauchen><en> It saves you time, helps you narrow your focus and gives you the information that you need to reverse engineer your competition's citations.
<G-vec00092-001-s199><need.brauchen><de> Dickies weiß, was du brauchst.
<G-vec00092-001-s199><need.brauchen><en> Dickies knows what you need.
<G-vec00092-001-s200><need.brauchen><de> Du brauchst einen Businessplan, um Zugang zu den Funktionen des Online-Shops zu erhalten, aber die erschwinglichen Preise machen das nicht zu einem großen Hindernis.
<G-vec00092-001-s200><need.brauchen><en> You’ll need a Business plan to get access to the online store features, but the affordable pricing doesn’t make that a big obstacle.
<G-vec00092-001-s201><need.brauchen><de> MACHE AUFNAHMEN WIE EIN PROFI: Wenn du eine Mavic Pro Platinum Combo hast, brauchst du kein Filmteam.
<G-vec00092-001-s201><need.brauchen><en> TAKE RECORDINGS LIKE A PROFESSIONAL: If you have a Mavic Pro Platinum Combo, you don't need a film team.
<G-vec00092-001-s202><need.brauchen><de> Damit deine Fans auch wissen wobei du Unterstützung brauchst, ist es wichtig vorher ein verständliches und vor allem realistisches Kampagnenziel festzulegen.
<G-vec00092-001-s202><need.brauchen><en> For your fans to know where you need support, it is important to first set up an understandable and above all, realistic campaign goal .
<G-vec00092-001-s203><need.brauchen><de> Wenn du zum Beispiel Abstand von emotionalem Stress auf der Arbeit brauchst, nimm dir ein paar Minuten, um zu meditieren oder dich zu entspannen, sobald du zuhause bist.
<G-vec00092-001-s203><need.brauchen><en> Explain to your partner that you need to focus on yourself for a while, if you are asked.
<G-vec00092-001-s204><need.brauchen><de> Hier findest Du alles, was Du für die Planung und Durchführung Deines Trips in der jeweiligen Region brauchst: von Unterkünften über Mietwagen, Shops, Shaper, Schulen und Verleihstationen bis hin zu Insidertipps, wenn es um Essen oder Nightlife geht.
<G-vec00092-001-s204><need.brauchen><en> In any particular region you’ll find everything you need for the planning and execution of your trip: from accommodation and rental cars to shops, shapers, schools and gear rental as well as insider tips on eating out and nightlife.
<G-vec00092-001-s205><need.brauchen><de> Irgendwann in deinem elenden Leben brauchst du etwas Besonderes, um deine Erregung zu erhöhen.
<G-vec00092-001-s205><need.brauchen><en> At some point in your miserable life, you need something special to heighten your arousal.
<G-vec00092-001-s206><need.brauchen><de> Wenn du die Sachen auf das reduziert, was du wirklich BRAUCHST, wirst du merken, dass das eigentlich ziemlich wenig ist.
<G-vec00092-001-s206><need.brauchen><en> When you strip items back to what you actually NEED, you'll find it's really very little.
<G-vec00092-001-s207><need.brauchen><de> Was du brauchst: Ein paar Kartoffelscheiben.
<G-vec00092-001-s207><need.brauchen><en> What You Need: Few potato slices.
<G-vec00092-001-s208><need.brauchen><de> Wenn Du die Informationen, die Du brauchst, auf unserer Internetseite nicht finden kannst, oder Du uns einfach nur Feedback geben möchtest, wende Dich bitte direkt telefonisch oder per E-Mail an uns.
<G-vec00092-001-s208><need.brauchen><en> Contact us If you can't find the information you need on our site, or if you just want to give us feedback, please contact us directly by phone or e-mail.
<G-vec00272-001-s171><require.brauchen><de> Dafür braucht es gerade einmal drei Sekunden.
<G-vec00272-001-s171><require.brauchen><en> This will require a mere three seconds.
<G-vec00272-001-s172><require.brauchen><de> Zwar gibt es einige Kritiken von Personen, die PhenQ besagt, dass es braucht nicht mehr ausüben auf die Tatsache zurückzuführen, dass es auch wirksam für sich sein Ursprung erhalten, empfehlen medizinische Fachleute immer noch, dass eine Übung mit der richtigen Diät-Plan, während fertig eingebaut werden Einnahme dieses Ergänzungsmittel für gesicherte Ergebnisse.
<G-vec00272-001-s172><require.brauchen><en> Though there are some evaluations coming from those who buy PhenQ claiming that it does not require any more working out considering that it could likewise be effective on its own, medical professionals still recommend that an exercise be executed incorporated with appropriate diet while taking this supplement for guaranteed results.
<G-vec00272-001-s173><require.brauchen><de> Dank seines Designs aus CyberSkin H2O Material hat dieser Masturbator nicht nur einen hautähnlichen Griff, er braucht auch kein Gleitmittel, um Ihnen ähnlich Empfindungen wie bei einer Analpenetration.
<G-vec00272-001-s173><require.brauchen><en> Thanks to its use of CyberSkin H2O material, this masturbator not only feels similar to human skin, but does not require any lubricant to offer you sensations similar to those felt during anal penetration.
<G-vec00272-001-s174><require.brauchen><de> Da die Perlen organischen Ursprungs ist,braucht sie auch spezielle Pflege.
<G-vec00272-001-s174><require.brauchen><en> As pearls come from organic origins they require special care .
<G-vec00272-001-s175><require.brauchen><de> Aber im Vergleich zum systemeigenen Drahtlosbetrieb braucht jedes Blitzgerät einen Empfänger, und dieser zusätzliche Batterien.
<G-vec00272-001-s175><require.brauchen><en> "But compared to the ""native"" wireless mode, each slave flash unit will require a receiver with additional batteries."
<G-vec00272-001-s176><require.brauchen><de> Ist das Unternehmen eine Personengesellschaft, braucht jeder geschäftsführende Gesellschafter und jede geschäftsführende Gesellschafterin eine Erlaubnis.
<G-vec00272-001-s176><require.brauchen><en> If the company is a partnership, each executive partner will require his or her own licence.
<G-vec00272-001-s177><require.brauchen><de> „Unsere Methode funktioniert ohne historische Daten und braucht auch keine detaillierten Kenntnisse darüber, wie das Erbgut eines Organismus seine Fitness beeinflusst.
<G-vec00272-001-s177><require.brauchen><en> “Our method works without historical data and does not require detailed knowledge of how an organism’s genome influences its fitness.
<G-vec00272-001-s178><require.brauchen><de> Danach geht es ihm wieder gut, und er braucht keinen neuen Behandlungstermin.
<G-vec00272-001-s178><require.brauchen><en> After that he feels good again, and does not require a new consultation.
<G-vec00272-001-s179><require.brauchen><de> Die Pflanze selbst wird nicht wirklich groß in Bezug auf Höhe, produziert aber massive Knospen und braucht nicht viel Pflege.
<G-vec00272-001-s179><require.brauchen><en> The plant itself doesn't grow big in terms of size, but produces massive buds and don't require much care.
<G-vec00272-001-s180><require.brauchen><de> Er braucht weder Batterien noch anderweitig Strom.
<G-vec00272-001-s180><require.brauchen><en> It does not require batteries or electricity.
<G-vec00272-001-s181><require.brauchen><de> Außerdem braucht die Steuerelektronik mehr Platz, weshalb LG nicht auf das breite Kinn unterhalb des Bildschirms verzichten kann.
<G-vec00272-001-s181><require.brauchen><en> In addition, the control electronics require more space, which is why LG cannot do without the wide chin below the screen.
<G-vec00272-001-s182><require.brauchen><de> Dennoch beharrt sie auf ihrem Bedürfnis, sich an die Macht zu klammern und euch den Wandel zu verweigern, den ihr so verzweifelt braucht.
<G-vec00272-001-s182><require.brauchen><en> Yet it persists in its need to cling to power and to deny you the changes that you so desperately require.
<G-vec00272-001-s183><require.brauchen><de> Uzwil, 15.06.2016 Um erfolgreich zu sein braucht es einen stabilen Fertigungsprozess mit abgestimmten Abläufen.
<G-vec00272-001-s183><require.brauchen><en> Uzwil, 15.06.2016 To be successful you require a stable manufacturing process with carefully matched operations.
<G-vec00272-001-s184><require.brauchen><de> Die Manx braucht keine spezielle Pflege.
<G-vec00272-001-s184><require.brauchen><en> The Manx does not require special grooming.
<G-vec00272-001-s185><require.brauchen><de> Wer als Anbieter von PBX- und IP Centrex-Lösungen an diesen Marktentwicklungen teilhaben will, braucht ein stabiles, hochperformantes und flexibles Business Support System (BSS) wie Taifun.
<G-vec00272-001-s185><require.brauchen><en> Providers of PBX and IP Centrex solutions who want to be part of these market developments, will require a stable, high performance and flexible business support system (BSS) such as Taifun.
<G-vec00272-001-s186><require.brauchen><de> Dafür braucht es politischen Willen auf beiden Seiten des Atlantik und eine möglichst breite Allianz von Unterstützern.
<G-vec00272-001-s186><require.brauchen><en> This will require political will from both shores of the Atlantic, and it will take the broadest possible alliance of supporters.
<G-vec00272-001-s187><require.brauchen><de> Die meisten Hütten sind geöffnet, für die anderen braucht man den DNT-Schlüssel, um hinein zu kommen.
<G-vec00272-001-s187><require.brauchen><en> Most of the cabins are open, the rest require a DNT key to enter.
<G-vec00272-001-s188><require.brauchen><de> Für Aufnahme, Backup und Archivierung braucht es gerade bei knappen Budgets zuverlässige Lösungen.
<G-vec00272-001-s188><require.brauchen><en> Recording, backup and archiving require reliable solutions, especially when budgets are tight.
<G-vec00272-001-s189><require.brauchen><de> Dafür braucht es ein gewisses Volumen im Zahlungsverkehr, damit sich der operative Aufwand lohnt.
<G-vec00272-001-s189><require.brauchen><en> It would require a certain payment traffic volume in order to make the operative costs worthwhile.
