<G-vec00298-002-s076><lift.auftreiben><de> Bei zu großer Steigerung des Aufschlagschubs wird aber der insgesamt direkt erzeugte Auftrieb zu klein und man gelangt zu einem Vorwärtsflug nur mit dem Schub.
<G-vec00298-002-s076><lift.auftreiben><en> But the total of the directly generated lift becomes too small when strongly increasing the upstroke thrust and that leads to a forward flight only with thrust.
<G-vec00298-002-s077><lift.auftreiben><de> Hier testeten wir die generelle Hypothese, dass die Schalenmorphologie von Schnecken eine Adaptation gegen Dislokation durch Auftrieb statt durch Widerstandskräfte ist, was das kontraintuitive Vorkommen von breiteren Schalen in lotischen Habitaten erklären würde.
<G-vec00298-002-s077><lift.auftreiben><en> Here, we tested the overall hypothesis that shell morphology in gastropods is an adaptation against dislodgement through lift rather than drag forces, which would explain the counterintuitive presence of wider shells with shorter spires in lotic environments.
<G-vec00298-002-s078><lift.auftreiben><de> Es hält über einen großen Bereich an Anstellwinkeln ein konstantes Maß an Auftrieb und innerem Druck aufrecht, und ist über den gesamten Geschwindigkeitsbereich hinweg außerordentlich stabil.
<G-vec00298-002-s078><lift.auftreiben><en> It maintains a constant level of lift and internal pressure over a wide range of angles of attack, giving exceptional levels of stability throughout the speed range.
<G-vec00298-002-s079><lift.auftreiben><de> Der CHAM 107 aus der Freeride-Serie Cham ist ein breiter Ski für sehr gute Skifahrer, die einen Freeride-Ski mit ultra-breiter Taillierung für außergewöhnlichen Auftrieb und optimales Gleitverhalten suchen.
<G-vec00298-002-s079><lift.auftreiben><en> Belonging to the Cham freeride range, the CHAM 107 is a fat ski intended for the very good skier looking for a freeride ski with ultra-wide sidelines for exceptional lift and flotation.
<G-vec00298-002-s080><lift.auftreiben><de> Bei der Autorotation dreht sich der Rotor eines Hubschraubers ohne Antrieb und erhält nur durch den Luftstrom Auftrieb.
<G-vec00298-002-s080><lift.auftreiben><en> In this condition, the rotor turns without being driven and derives lift only from the flow of air.
<G-vec00298-002-s081><lift.auftreiben><de> Wie bei einer Boje (englisch buoy) sorgt dieser Körper für Auftrieb.
<G-vec00298-002-s081><lift.auftreiben><en> This hull provides lift like a buoy.
<G-vec00298-002-s082><lift.auftreiben><de> Je größer die Fläche des Frontflügels, desto größer ist sein Auftrieb (leichter Start und Stabilisierung), aber desto geringer seine Geschwindigkeit und Wendigkeit.
<G-vec00298-002-s082><lift.auftreiben><en> The bigger the size of the wing is, the stronger is its lift (take-off and stabilization are easier) but the lower its speed and maniability are.
<G-vec00298-002-s083><lift.auftreiben><de> Mein Gewicht Auftrieb erhöht sich um 50%, es ist eine erstaunliche Ausdauer.
<G-vec00298-002-s083><lift.auftreiben><en> My weight lift elevates by 50%, it is a fantastic strength.
<G-vec00298-002-s084><lift.auftreiben><de> Mit steigender Geschwindigkeit produziert die Form des Rumpfes immer mehr Auftrieb, der den Rumpf über die Wasseroberfläche hebt und das verdrängte Wasservolumen radikal reduziert.
<G-vec00298-002-s084><lift.auftreiben><en> But as the speed increases, the hull’s shape, assisted by its chines and spray rails, creates increasingly powerful hydrodynamic lift, elevating the hull and radically reducing the displaced volume.
<G-vec00298-002-s085><lift.auftreiben><de> Zieht man die Bar nach unten, wölbt sich das Profil und der Auftrieb nimmt enorm zu.
<G-vec00298-002-s085><lift.auftreiben><en> By pulling the bar down, the profiles bends and an enormous lift increase is created.
<G-vec00298-002-s086><lift.auftreiben><de> Der Unterboden ist fast vollständig verkleidet, im Bereich der Hinterachse verringert ein kleiner Spoiler den Auftrieb.
<G-vec00298-002-s086><lift.auftreiben><en> The underbody is nearly completely lined; a small spoiler in the area of the rear axle reduces lift.
<G-vec00298-002-s087><lift.auftreiben><de> Er lässt wenig Luft hindurch, was den Auftrieb für die Vögel erhöht, und verankert dennoch die Federn miteinander.
<G-vec00298-002-s087><lift.auftreiben><en> It allows little air through, which increases the lift for the birds, and yet anchors the feathers together.
<G-vec00298-002-s088><lift.auftreiben><de> Auftrieb und Widerstand werden erfasst und digital angezeigt.
<G-vec00298-002-s088><lift.auftreiben><en> Lift and drag are detected and displayed digitally.
<G-vec00298-002-s089><lift.auftreiben><de> Gib dir zum Beispiel Auftrieb, indem du von deinem Lieblings-Urlaubsort tagträumst.
<G-vec00298-002-s089><lift.auftreiben><en> For example, give yourself a lift by daydreaming about your favorite vacation spot.
<G-vec00298-002-s090><lift.auftreiben><de> Nachdem der äußere Flügelabschnitt an seinem Lager hängend hochgezogen wurde, erfolgt auch seine Drehung in die obere Schlagendlage nur mit dem Auftrieb.
<G-vec00298-002-s090><lift.auftreiben><en> After the outboard wing section was pulled up hanging on its hinge, also its turning in the upper stroke position occurs only with the lift.
<G-vec00298-002-s091><lift.auftreiben><de> Die starke Depower wird durch das Einbeulen der Vorderkante welche den Auftrieb reduziert maßgeblich unterstützt.
<G-vec00298-002-s091><lift.auftreiben><en> The excellent depower is significantly supported by the flattening of the leading edge which reduces lift.
<G-vec00298-002-s092><lift.auftreiben><de> Diese zwei gegenläufigen Wirbel erzeugen keinen Auftrieb, benötigen jedoch Energie, dies wird als induzierter Luftwiderstand bezeichnet.
<G-vec00298-002-s092><lift.auftreiben><en> These two counter-rotating swirls do not generate lift, but do require energy, this is called induced air resistance.
<G-vec00298-002-s093><lift.auftreiben><de> Auf diese Weise erhält man die Gesamtgröße von Auftrieb und Vortrieb des Schlagflügels zu einem bestimmten Zeitpunkt der Schlagperiode.
<G-vec00298-002-s093><lift.auftreiben><en> This way, you get the total forces of lift and propulsion of the flapping wing at a fixed moment of time of the flapping cycle.
<G-vec00298-002-s094><lift.auftreiben><de> Die Optimierung des Unterbodens und des Heckdiffusors konnten gleichzeitig eine starke Einbindung in das Heckdesign und ein Unterdruck am Unterboden erreichen, der sehr viel höher als der von der Oberseite der Karosserie erzeugte Auftrieb ist.
<G-vec00298-002-s094><lift.auftreiben><en> Thanks to the optimisation of the car ‘s flat underbody and the rear diffuser, the aerodynamic rear blends in beautifully with the rest of the design and the suction created under the car is now far superior to the lift generated by the upper part of the bodywork.
<G-vec00251-003-s080><scare_away.auftreiben><de> Aber man sollte doch meinen, sie könnte zumindest einen Bruder oder Sohn auftreiben, oder wenigstens einen Neffen.
<G-vec00251-003-s080><scare_away.auftreiben><en> "I suppose she can't help the lack of a husband, but you'd think she could scare up a brother or son or at least a nephew.
<G-vec00251-003-s080><scare_off.auftreiben><de> Aber man sollte doch meinen, sie könnte zumindest einen Bruder oder Sohn auftreiben, oder wenigstens einen Neffen.
<G-vec00251-003-s080><scare_off.auftreiben><en> "I suppose she can't help the lack of a husband, but you'd think she could scare up a brother or son or at least a nephew.
