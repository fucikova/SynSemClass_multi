<G-vec00078-001-s019><vote.abstimmen><de> Bis Ende März werden 13 weitere Ausschüsse ihre Inputs geben, Mitte April wird das Paper diskutiert und Anfang Mai im Handelsausschuss abgestimmt werden.
<G-vec00078-001-s019><vote.abstimmen><en> 13 other committees will provide their inputs before the end of March; the paper will be discussed mid-April and the Trade Committee will vote on it at the beginning of May.
<G-vec00078-001-s020><vote.abstimmen><de> Der Richtlinienvorschlag zur Konzessionsvergabe wird in den nächsten Tagen im Ausschuss für Binnenmarkt und Verbraucherschutz (IMCO) des Europäischen Parlaments abgestimmt.
<G-vec00078-001-s020><vote.abstimmen><en> The Internal Market and Consumer Protection Committee (IMCO) of the European Parliament will vote on the proposal for a Directive on the award of concession contracts within the next few days.
<G-vec00078-001-s021><vote.abstimmen><de> Das Protokoll eines Treffen des Audit-und Risiko-Komitees, das einen Interessenkonflikt aufzeigt, soll diesen widerspiegeln und aufzeigen, dass die betroffene Person nicht anwesend bei Besprechungen war und nicht über die Angelegenheit mit abgestimmt hat.
<G-vec00078-001-s021><vote.abstimmen><en> The minutes of any Audit and Risk Committee meeting where a conflict of interest has been disclosed shall reflect that the conflict of interest was disclosed and that the interested person was not present for deliberations and did not vote on the matter.
<G-vec00078-001-s022><vote.abstimmen><de> In diesem Fall wurde ein Text präsentiert als etwas, was er nie war, der in einer einzigen Ratssitzung in aller Kürze besprochen und danach auf zweifelhafte Weise abgestimmt wurde [14].
<G-vec00078-001-s022><vote.abstimmen><en> In this case, some parliaments and governments have expressed their disagreement with the text, which was presented as something it was not, was agreed upon in the fly, by a dubious vote[14] in a single Meeting of Ministers.
<G-vec00078-001-s023><vote.abstimmen><de> Nach der Sommerpause soll über den Bericht und Änderungsvorschläge im Ausschuss abgestimmt werden.
<G-vec00078-001-s023><vote.abstimmen><en> The Committee will vote on the Report and any Amendment Proposals after the summer recess.
<G-vec00078-001-s024><vote.abstimmen><de> Laut jetziger Zeitplanung soll im Oktober im Ausschuss über den Parlamentsbericht abgestimmt werden, das Votum im Plenum ist für Dezember 2012 geplant.
<G-vec00078-001-s024><vote.abstimmen><en> According to the current time schedule, the Committee will vote on the Parliamentary report in October; the vote in the plenum has been scheduled for December 2012.
<G-vec00078-001-s025><vote.abstimmen><de> Nach guter benediktinischer Tradition wurde nicht sofort abgestimmt.
<G-vec00078-001-s025><vote.abstimmen><en> But in good Benedictine tradition, the vote was not taken immediately.
<G-vec00078-001-s026><vote.abstimmen><de> Also wurde wieder abgestimmt, wie es in solchen Fällen in Children's World immer wieder geschieht.
<G-vec00078-001-s026><vote.abstimmen><en> So again we put the issue to a vote, as we used to do before in such cases in Children's World.
<G-vec00078-001-s027><vote.abstimmen><de> Zuerst die Einordnung, über was in dem Referendum abgestimmt wird.
<G-vec00078-001-s027><vote.abstimmen><en> First, the classification on which proposal the referendum's participants vote.
<G-vec00078-001-s028><vote.abstimmen><de> Mittels einer Befragung unter der Bevölkerung derjenigen Gemeinden, in denen über das Projekt abgestimmt wurde, wurden die Wahrnehmungen, Einstellungen und potenziellen Determinanten der Akzeptanz respektive Ablehnung der direkt betroffenen Bevölkerung im Hinblick auf das Projekt Parc Adula quantitativ untersucht.
<G-vec00078-001-s028><vote.abstimmen><en> By means of a survey among the population of the municipalities in which the project was subject to a vote; the perceptions, attitudes and potential determinants of acceptance or rejection of the directly affected population were quantitatively examined regarding the project Parc Adula.
<G-vec00078-001-s029><vote.abstimmen><de> Es wird schriftlich abgestimmt, wenn es die Versammlung so beschliesst.
<G-vec00078-001-s029><vote.abstimmen><en> Upon the decision of the General Meeting voting are by written vote.
<G-vec00078-001-s030><vote.abstimmen><de> Nachdem der Wähler abgestimmt hat, sendet ihm das System einen so genannten Verifikations-Code zurück.
<G-vec00078-001-s030><vote.abstimmen><en> Once the voter has cast his or her vote, the system sends back what is called a verification code.
<G-vec00078-001-s031><vote.abstimmen><de> Über alle anderen Fragen hat der Board nicht abgestimmt, da sie einer weiteren Erörterung bedürfen.
<G-vec00078-001-s031><vote.abstimmen><en> The Board did not vote on any other questions on grounds that they need further discussion.
<G-vec00078-001-s032><vote.abstimmen><de> Demnächst wird über die Verabschiedung der Gesetzesvorlage selbst abgestimmt.
<G-vec00078-001-s032><vote.abstimmen><en> Thus, in the near future a vote will be taken on the adoption of the bill itself.
<G-vec00078-001-s033><vote.abstimmen><de> Bereits im Dezember soll über die Änderungsvorschläge zu den Dienstleistungskonzessionen und zur öffentlichen Vergabe in den federführenden Ausschüssen abgestimmt werden.
<G-vec00078-001-s033><vote.abstimmen><en> The competent committees will vote on the amendment proposals for service concessions and public procurement as early as December.
<G-vec00078-001-s034><vote.abstimmen><de> Es wird durch Handzeichen abgestimmt.
<G-vec00078-001-s034><vote.abstimmen><en> A vote was taken by show of hands.
<G-vec00078-001-s035><vote.abstimmen><de> Wenn ihr zur Umfrage kommt und die Seite euch sagt, dass bereits jemand abgestimmt hat, war jemand mit eurer IP-Adresse schon vor euch auf der Seite.
<G-vec00078-001-s035><vote.abstimmen><en> When you visit the poll, if the page indicates a vote has already been made, then someone else at your IP address has visited the page before you.
<G-vec00078-001-s036><vote.abstimmen><de> Es kann jeden Tag einmal abgestimmt werden.
<G-vec00078-001-s036><vote.abstimmen><en> You can vote once every day.
<G-vec00078-001-s037><vote.abstimmen><de> Wenn noch niemand abgestimmt hat, können Nutzer (die die Umfrage erstellt haben) ihre Umfrage bearbeiten oder löschen.
<G-vec00078-001-s037><vote.abstimmen><en> If no one has cast a vote then users can delete the poll or edit any poll option.
<G-vec00078-001-s038><vote.abstimmen><de> So hatten zum Beispiel während des Referendums im März die meisten Ägypter keine Ahnung, was genau ihre Stimme bei der Abstimmung bewirken würde, beziehungsweise, über welche Änderungen der Verfassung sie nun zu welchem Zweck abstimmen sollten.
<G-vec00078-001-s038><vote.abstimmen><en> Take the March referendum for instance: most Egyptians had no clue what their vote would do or for what changes in the Constitution they should vote and why.
<G-vec00078-001-s039><vote.abstimmen><de> Gerade heute werden griechische Abgeordnete über dieses Thema abstimmen.
<G-vec00078-001-s039><vote.abstimmen><en> Just today, Greek MPs will vote on this issue.
<G-vec00078-001-s040><vote.abstimmen><de> Deine potenziellen und bereits bestehenden Kunden können dann für ihr Lieblingsprodukt abstimmen.
<G-vec00078-001-s040><vote.abstimmen><en> Your potential and existing customers get to vote for their favorite among a few different products.
<G-vec00078-001-s041><vote.abstimmen><de> Zu diesem Zweck, Aktionäre bei den jährlichen Hauptversammlungen abstimmen dürfen oder sogar gewählt als Direktor innerhalb des Unternehmens zu dienen, aber eine Obligationsinhaber kann nicht beides tun.
<G-vec00078-001-s041><vote.abstimmen><en> To this end, shareholders are permitted to vote at annual AGMs or even elected to serve as director within the company, but a debenture-holder cannot do both.
<G-vec00078-001-s042><vote.abstimmen><de> Sie können abstimmen, bis 17 oktober.
<G-vec00078-001-s042><vote.abstimmen><en> You can vote until 17 October.
<G-vec00078-001-s043><vote.abstimmen><de> Im September werden die MdEP ein weiteres Mal abstimmen, um entweder 1. das Mandat auf Basis des Gesetzentwurfs des Rechtsausschusses zu erteilen, 2. den Gesetzesvorschlag abzuändern oder 3. den Vorschlag vollständig zu verwerfen.
<G-vec00078-001-s043><vote.abstimmen><en> In September, MEPs will once again vote in plenary to either 1) confirm the mandate as proposed by the committee, 2) amend it, or 3) reject it entirely.
<G-vec00078-001-s044><vote.abstimmen><de> Wenn du dann voten kannst gibt es drei wesentliche Dinge zu beachten: Du kannst nur einmal am Tag für die gleiche Lady abstimmen, du kannst nicht für deine Lady selbst abstimmen und wenn eine Lady schon alle Preise in einem Wettbewerb gewonnen hat kannst du dort nicht mehr abstimmen bei dieser Lady.
<G-vec00078-001-s044><vote.abstimmen><en> When you are already able to vote, there are three main things you should remember – you can’t vote for one and the same lady more than once in a day, you can’t vote for yourself, and once a lady wins all the rewards in one of the contests, you won’t be able to vote for her for this contest.
<G-vec00078-001-s047><vote.abstimmen><de> Schon als großer Fan, sehe ich Raum in seinem Spiel zu wachsen und letztlich Ich denke, das ist, warum viele für Suter abstimmen wird.
<G-vec00078-001-s047><vote.abstimmen><en> Even as a huge fan, I see room to grow in his game and ultimately I think this is why many will vote for Suter.
<G-vec00078-001-s048><vote.abstimmen><de> Es soll nun über einen Vorschlag der Gläubiger abstimmen, der nicht mehr zur Debatte steht, weil es die Tsipras-Regierung versäumt hat ernsthafte Verhandlungen zu führen.
<G-vec00078-001-s048><vote.abstimmen><en> It is taking the Greek people hostage as it demands for a vote on a text that does not even exist, because it was unable to conclude negotiations correctly with its creditors.
<G-vec00078-001-s049><vote.abstimmen><de> Einfach wählen Sie Inhaltstyp Abstimmung x-mal zu entsperren und legen Sie dann total Nein Stimmen zu entsperren, das Bild oder die Url und die Einschränkung für einen Benutzer, die nicht, nach XX Minuten Stimmen wie derselbe Benutzer kann nicht noch einmal abstimmen, bis es die Beschränkung der Abstimmung erreicht.
<G-vec00078-001-s049><vote.abstimmen><en> Simple select content type vote x times to unlock and then set total no of votes to unlock the image or url and set the restriction for a user who cannot vote after XX minute like same user cannot vote again until it reaches the restriction limit of vote.
<G-vec00078-001-s050><vote.abstimmen><de> Nur anwesende Mitglieder können in Sitzungen der Generalversammlung abstimmen.
<G-vec00078-001-s050><vote.abstimmen><en> Only delegates attending the meeting of the General Assembly can vote.
<G-vec00078-001-s051><vote.abstimmen><de> Du kannst sie über diese Seite hören und abstimmen welche du am liebsten magst.
<G-vec00078-001-s051><vote.abstimmen><en> You can listem them from this page, and vote on them, to show us which of them is the best.
<G-vec00078-001-s052><vote.abstimmen><de> Auf der begleitenden Mitgliederversammlung, werden die Mitglieder über zwei Resolutionen abstimmen, die den Weg zu einem nachhaltigerem Europa weisen.
<G-vec00078-001-s052><vote.abstimmen><en> At the accompanying general assembly, members will vote on two key resolutions pointing the way toward a more sustainable Europe.
<G-vec00078-001-s053><vote.abstimmen><de> Wahlen finden regelmäßig statt, und die BÃ1⁄4rger Ã1⁄4ber 18 Jahren abstimmen.
<G-vec00078-001-s053><vote.abstimmen><en> Elections are regularly held, and citizens over 18 years of age may vote.
<G-vec00078-001-s054><vote.abstimmen><de> "Sehen Sie die aktuellen Ergebnisse einer Umfrage vor, die Sie abstimmen, indem Sie auf ""Ergebnisse Anzeigen"" - link."
<G-vec00078-001-s054><vote.abstimmen><en> You can see the current results for a poll before you vote by clicking the 'View Results' link.
<G-vec00078-001-s055><vote.abstimmen><de> Abstimmen heißt auswählen.
<G-vec00078-001-s055><vote.abstimmen><en> To vote is to choose.
<G-vec00078-001-s056><vote.abstimmen><de> Sie können für die beste Video-Präsentation auf der offiziellen Website der MITT Ausstellung abstimmen.
<G-vec00078-001-s056><vote.abstimmen><en> You can vote for the best video presentation on the official website of the MITT exhibition.
<G-vec00078-001-s090><vote.abstimmen><de> Neben den Lesern der AUTO ZEITUNG in Deutschland, Ã sterreich und in der Schweiz waren in den vergangenen Wochen auch die Leser der Bauer-Automotive-Titel in UK, Australien, Polen, Niederlande, Spanien, USA und Südafrika dazu aufgerufen, über die weltweit besten Autos aller Klassen in 15 Kategorien abzustimmen.
<G-vec00078-001-s090><vote.abstimmen><en> Aside from the readers of AUTO ZEITUNG in Germany, Austria and Switzerland, in recent weeks the readers of Bauer automotive magazines in the UK, Australia, Poland, the Netherlands, Spain, the USA and South Africa were also called upon to vote on the world's best automobiles of all classes in 15 categories.
<G-vec00078-001-s091><vote.abstimmen><de> Wir wären Ihnen sehr dankbar, wenn Sie sich die Zeit nehmen würden, um für uns abzustimmen.
<G-vec00078-001-s091><vote.abstimmen><en> We would be very grateful if you would take the time to cast your vote for us in your favourite category.
<G-vec00078-001-s092><vote.abstimmen><de> Einfach und ortsungebunden Befragungen durchführen Die Mobile Response-Mobile-App ermöglicht es, einfach und ortsungebunden über Entscheidungsvorschläge abzustimmen oder das Meinungsbild einer größeren Gruppe in sehr kurzer Zeit in Erfahrung zu bringen und unmittelbar graphisch darzustellen.
<G-vec00078-001-s092><vote.abstimmen><en> The Mobile Response App makes it possible to vote about proposals easily and without reference to location, or to gauge the opinion of a large group in a very short time and portray this directly in graphic form.Â
<G-vec00078-001-s093><vote.abstimmen><de> Wir leben in der Schweiz, wir haben das Recht für alles Mögliche abzustimmen, nutze diese Möglichkeit.
<G-vec00078-001-s093><vote.abstimmen><en> We live in Switzerland, we have the right to vote on all sorts of things, so use that possibility.
<G-vec00078-001-s094><vote.abstimmen><de> Nun, wir können beginnen, indem wir die Organisation von Volksentscheiden auf allen Ebenen der Gesellschaft unterstützen, sodass alle Menschen ihr Recht ausüben können, über globale, nationale, bundesstaatliche und lokale Anliegen abzustimmen.
<G-vec00078-001-s094><vote.abstimmen><en> Well, we can start by promoting the organization of people’s referendums at all levels of society, so all people can exercise their right to vote on world, national, state and local matters.
<G-vec00078-001-s095><vote.abstimmen><de> Die Hauptaufgabe der Abgeordnetenkammer besteht darin, über Gesetzentwürfe der Regierung oder eigene Gesetzesvorlagen abzustimmen .
<G-vec00078-001-s095><vote.abstimmen><en> The main function of the Chamber is to vote on government and parliament bills .
<G-vec00078-001-s096><vote.abstimmen><de> PK wahrscheinlich zu viele Schlagzeilen in dieser Saison aus anderen Gründen als sein Spiel auf dem Eis, die immer wirkt mit den Schriftstellern, die für diese Auszeichnungen abzustimmen.
<G-vec00078-001-s096><vote.abstimmen><en> PK probably made too many headlines this season for reasons other than his play on the ice, which always has an effect with the writers who vote for these awards.
<G-vec00078-001-s097><vote.abstimmen><de> """Die Leute in der Schweiz tendieren dazu, nicht einfach aus Wut oder zu ihrem eigenen Vorteil abzustimmen, sondern sind offener, ein Argument für das Gemeinwohl in Betracht zu ziehen."
<G-vec00078-001-s097><vote.abstimmen><en> """Swiss people tend not to only vote out of anger or just for their own benefit, but are more open to consider an argument regarding the common good,"" he said."
<G-vec00078-001-s098><vote.abstimmen><de> Beide großen Blöcke im irakischen Parlament verurteilten den Besuch und forderten eine Dringlichkeitssitzung, um sich über die Ausweisung von US-Truppen aus dem Land abzustimmen.
<G-vec00078-001-s098><vote.abstimmen><en> The two major blocs in the Iraqi parliament denounced the visit and called for an emergency session to vote on expelling US troops from the country.
<G-vec00078-001-s099><vote.abstimmen><de> "Um teilzunehmen und abzustimmen, es ist wirklich einfach: Finden Sie Ihre bevorzugte Plätze mit der Suchmaschine und sobald Sie es auf ""Vote"" klicken: Ihre ausgewählten Orten wird eine zusätzliche Stimme erhalten und Sie werden die Wahrscheinlichkeit von ihnen ist in dieser Seite aufgeführten erhöhen der Top zehn Hotels in [COMMUNITY]."
<G-vec00078-001-s099><vote.abstimmen><en> "To participate and vote, it's really simple: find your preferred places by using the search engine and once you find it click on ""Vote"": Your selected places will receive one additional vote and you will increase the likelihood of them being listed in this page of the Top ten Hotels in [COMMUNITY]."
<G-vec00078-001-s100><vote.abstimmen><de> Für die Möglichkeit, über etwas abzustimmen und ähnliches.
<G-vec00078-001-s100><vote.abstimmen><en> For the possibility to vote on something and the like.
<G-vec00078-001-s101><vote.abstimmen><de> Sie haben aber ein Verteidigungsmittel: bei den Gemeindewahlen abzustimmen; sie machen jedoch keinen Gebrauch davon, zur großen Erleichterung der jüdischen Extremisten.
<G-vec00078-001-s101><vote.abstimmen><en> They have a means of defence: to vote in the municipal elections; but they do not use it, to great relief of the Jewish extremists.
<G-vec00078-001-s102><vote.abstimmen><de> """Flüchtlinge, die in den Südsudan zurückkehren könnten sich dazu gezwungen sehen, bei einer zukünftigen Volksabstimmung über die umstrittenen Regionen zugunsten der Zentralregierung abzustimmen""."
<G-vec00078-001-s102><vote.abstimmen><en> """Refugees returning south could be convinced to vote for the government in a possible referendum on disputed border regions"" local source told Fides"
<G-vec00078-001-s103><vote.abstimmen><de> Der Vorsitzende schlug vor, zuerst einmal über die Frage wie im Papier gestellt abzustimmen.
<G-vec00078-001-s103><vote.abstimmen><en> The Chairman suggested, as a first instance, to vote on the question as posed in the paper.
<G-vec00078-001-s104><vote.abstimmen><de> Der Nactus Award 2007 wäre nicht so ein großer Erfolg gewesen, wenn diese tausenden von Menschen sich nicht die Zeit genommen hätten, um die Exo Terra Website zu besuchen und für ihr Lieblingsfoto abzustimmen.
<G-vec00078-001-s104><vote.abstimmen><en> The 2007 Nactus Award would not have been the huge success it was if it weren't for the thousands of people who took the time to visit the Exo Terra web site to view, and vote for, their favourite nominee.
<G-vec00078-001-s105><vote.abstimmen><de> Bisher konzentrierten wir unsere Initiative auf die Forderung, dass alle Bürger umgehend die Möglichkeit erhalten sollten, in einem Referendum über den Vertrag von Lissabon abzustimmen.
<G-vec00078-001-s105><vote.abstimmen><en> Previously, our headline campaign demanded that all citizens should immediately be given the opportunity to vote in referendums on the Lisbon Treaty.
<G-vec00078-001-s106><vote.abstimmen><de> Fast 90% glauben, dass die Politiker von der Korruption einen Nutzen haben und 18% sagen, ihnen sei Geld angeboten, um bei den Wahlen 2012 abzustimmen.
<G-vec00078-001-s106><vote.abstimmen><en> About 90% of citizens believe that politicians benefit from corruption, and 18% of respondents said that they were offered bribes to vote in elections held in May 2012.
<G-vec00078-001-s107><vote.abstimmen><de> Inzwischen jetzt meine Schwester aufgeregt, dass ich gehen kann und für ihre Schule das Budget abzustimmen, damit ihre Klasse ein Eis sozialen (lacht) gewinnen können.
<G-vec00078-001-s107><vote.abstimmen><en> Meanwhile, now my sister is excited I can go and vote for her school's budget so her class can win an ice cream social (laughs).
<G-vec00078-001-s108><vote.abstimmen><de> Danach werden wir schon sehr bald die Gelegenheit haben, darüber im Plenum abzustimmen.
<G-vec00078-001-s108><vote.abstimmen><en> After that, we will very soon have the chance to vote it in the plenary.
<G-vec00078-001-s229><vote.abstimmen><de> Über die Hälfte der libanesischen Bevölkerung lebt in Beirut, doch weniger als ein Viertel der Wahlberechtigten durften ihre Stimme in BeirutÂ abgeben.
<G-vec00078-001-s229><vote.abstimmen><en> Thus in Beirut, home of more than half the population, less than a fourth of eligible voters could vote without returning to their usually remote districts of origin.
<G-vec00078-001-s230><vote.abstimmen><de> – Ich habe nicht einmal eine Stimme abgeben.
<G-vec00078-001-s230><vote.abstimmen><en> – I did not vote even once.
<G-vec00078-001-s231><vote.abstimmen><de> Bitte beachten Sie, dass Sie nur eine Stimme abgeben können.
<G-vec00078-001-s231><vote.abstimmen><en> Please note that you may only vote once.
<G-vec00078-001-s232><vote.abstimmen><de> "„Wir wollen den Bürgern verständlich machen, dass sie vor den Herausforderungen nicht fliehen sondern sich ihnen mutig stellen sollen und zwar auf konkrete Weise durch eine auf Informationen basierende Stimmabgabe: wir müssen die Kandidaten und deren Parteien und Wahlprogramme kennen … und unsere Stimme verantwortungsvoll abgeben"", so Bischof Lira Rugarcía."
<G-vec00078-001-s232><vote.abstimmen><en> """The idea is to invite all to understand that we have to face challenges with courage, without escaping, but by participating, and doing it in a very concrete way: we need to know the candidates, parties, what they propose, in order to reflect and communicate well with the community, and then give a free and responsible vote"", said Mgr. Lira Rugarcía."
<G-vec00078-001-s233><vote.abstimmen><de> Die Einhaltung dieser Formalien soll dafür Sorge tragen, dass nur Wahlberechtigte wählen und dass diese auch nur einmal ihre Stimme abgeben können.
<G-vec00078-001-s233><vote.abstimmen><en> Compliance with these formalities should ensure, that select only eligible voters and that this also can vote only once.
<G-vec00078-001-s234><vote.abstimmen><de> Sie können für diese CDs hier Ihre Stimme abgeben.
<G-vec00078-001-s234><vote.abstimmen><en> To help these discs win, please cast your vote here.
<G-vec00078-001-s235><vote.abstimmen><de> Eure geschätzte Stimme könnt ihr nach wie vor hier abgeben.
<G-vec00078-001-s235><vote.abstimmen><en> Your much appreciated vote can still be given here.
<G-vec00078-001-s236><vote.abstimmen><de> Im Jahre 2001 kam der MuVi-Publikumspreis hinzu: Per Streaming kann man sich die nominierten Videos einen Monat lang ansehen und seine Stimme abgeben.
<G-vec00078-001-s236><vote.abstimmen><en> In 2001, a new MuVi Audience Prize was added. Each year, the nominated videos can be viewed for one month and users can vote for the best clip.
<G-vec00078-001-s237><vote.abstimmen><de> In diesem Fall enthält die Bescheinigung auf Grund der Erklärung des Stimmberechtigten die Ortschaft, in der er seine Stimme abgeben will.
<G-vec00078-001-s237><vote.abstimmen><en> In this case, the certificate contains on the grounds of the voter’s statement the settlement where he/she intends to vote.
<G-vec00078-001-s238><vote.abstimmen><de> Die an dieser Tapas-Route teilnehmt, kann für die besten Tapa stimmen und ihre Stimme abgeben in 31 teilnehmende Bars und Restaurants.
<G-vec00078-001-s238><vote.abstimmen><en> The public participating in this Tapas Route, will be able to vote for the best tapa stamping their vote in 31 of the participating bars and restaurants.
<G-vec00078-001-s239><vote.abstimmen><de> Jeder Mitarbeiter konnte pro Kategorie für jeweils eine Idee aus den fünf nominierten Ideen seine Stimme abgeben.
<G-vec00078-001-s239><vote.abstimmen><en> Each employee could vote for one idea per category from the five on each short list.
<G-vec00078-001-s240><vote.abstimmen><de> Vermutlich können sie eine intelligentere Stimme abgeben, wenn sie häufig Nachrichten Artikel über allgemeine Beamte oder die Ausgaben, die in politische Kampagnen angehoben werden lesen.
<G-vec00078-001-s240><vote.abstimmen><en> Presumably, they can cast a more intelligent vote if they often read news articles about public officials or issues raised in political campaigns.
<G-vec00078-001-s241><vote.abstimmen><de> Wir werden sehen, was in Zukunft passieren wird, denn die Zweifelnden werden auch dieses Mal ihre Stimme abgeben.
<G-vec00078-001-s241><vote.abstimmen><en> Let us see, what will happen in the future, because the fearful will vote again.
<G-vec00078-001-s242><vote.abstimmen><de> Mit diesem Infobrief möchten wir auch eine Stimme abgeben - vielleicht im Kontrast, dennoch nicht im Gegensatz zu dem, was im letzten Infobrief geschrieben wurde.
<G-vec00078-001-s242><vote.abstimmen><en> With this information letter we also want to give a vote – perhaps in contrast to, but not contrary to what has been written in the last letter. We now want to call for a campaign.
<G-vec00078-001-s243><vote.abstimmen><de> Es ist entscheidend, dass sich die Bürgerinnen und Bürger der Europäischen Union (EU) am demokratischen Prozess beteiligen und am Wahltag ihre Stimme abgeben.
<G-vec00078-001-s243><vote.abstimmen><en> It is essential that EU citizens participate in the democratic process through casting their vote on polling day.
<G-vec00078-001-s244><vote.abstimmen><de> 3 Millionen junge Menschen dürfen erstmals bei der Bundestagswahl ihre Stimme abgeben.
<G-vec00078-001-s244><vote.abstimmen><en> 3 million young people are entitled to vote for the first time in the Bundestag election.
<G-vec00078-001-s245><vote.abstimmen><de> Im Falle einer Stimmengleichheit wird der Tagungsleiter die entscheidende zusätzliche Stimme abgeben.
<G-vec00078-001-s245><vote.abstimmen><en> In case of a tie the person chairing the meeting will cast the deciding additional vote.
<G-vec00078-001-s246><vote.abstimmen><de> Bei der zweiten Abstimmung, wo es über die Abschaffung der Radio- und Fernsehgebühren ging, war ich in Bern und sehr froh, dass ich meine Stimme abgeben konnte.
<G-vec00078-001-s246><vote.abstimmen><en> For the second vote, which was on the abolition of the licence fee for public broadcasting, I was in Bern and I was very happy to be able to cast my vote.
<G-vec00078-001-s247><vote.abstimmen><de> Abwesende Mitglieder des Prüfungsausschusses können an der Beschlussfassung teilnehmen, indem sie eine schriftliche Stimmabgabe durch ein anderes Mitglied des Prüfungsausschusses überreichen lassen oder ihre Stimme fernmündlich oder mit Hilfe sonstiger Mittel der Telekommunikation abgeben.
<G-vec00078-001-s247><vote.abstimmen><en> Absent members of the Audit Committee may participate in a decision by submitting a written vote via another member of the Audit Committee or by casting a vote by telephone or other means of telecommunication.
<G-vec00250-002-s019><match.abstimmen><de> Die Venture Boxen sind zudem abgestimmt auf den Einsatz mit unserer neuen Horizon Mischpult-Serie.
<G-vec00250-002-s019><match.abstimmen><en> As a premium range product, the Venture cabs are a perfect system match for our new Horizon mixer range.
<G-vec00250-002-s020><match.abstimmen><de> Mit unseren In-Text-Links entdecken unsere User Produktangebote, die optimal auf Ihren Content abgestimmt sind.
<G-vec00250-002-s020><match.abstimmen><en> Our in-text links will help your readers discover the best product offers that match your content.
<G-vec00250-002-s021><match.abstimmen><de> Auf dieser Grundlage entwickeln wir Design und Layout der Website und verbessern ihren Content, damit das Angebot kontinuierlich besser auf die Interessen unserer Website-Benutzer abgestimmt wird.
<G-vec00250-002-s021><match.abstimmen><en> We monitor customer traffic patterns and site usage to help us develop the design and layout of the site, and to improve the content of our website to better match the interests of our website users.
<G-vec00250-002-s022><match.abstimmen><de> Astar Tintenpatronen sind auf die Anforderungen der jeweiligen Printer perfekt abgestimmt.
<G-vec00250-002-s022><match.abstimmen><en> Astar ink cartridges perfectly match the requirements of any printer.
<G-vec00250-002-s023><match.abstimmen><de> In die neuen Kits – farblich abgestimmt auf die SWISS Kabinenumgebung – integrierten die Designer Teile von Flugzeug-Sitzgurten.
<G-vec00250-002-s023><match.abstimmen><en> For the new SWISS amenity kits, which are coloured to match the cabin décor, the designers have also incorporated elements of the inflight seat belt.
<G-vec00250-002-s024><match.abstimmen><de> Vom schlichten, natürlichen Aussehen bis hin zu verblüffenden Spiegel- und Linseneffekten: Wir verfügen über ein ganzes Arsenal an Etikettendrucktechniken, die auf Ihre Marke und Ziele abgestimmt sind.
<G-vec00250-002-s024><match.abstimmen><en> From simply natural looks to stunning mirror and lense effects, we have a full arsenal of label printing techniques to match your brand and your goals.
<G-vec00250-002-s025><match.abstimmen><de> • Kindgerechte Proportionen abgestimmt auf die motorischen Fähigkeiten der empfohlenen Altersklasse.
<G-vec00250-002-s025><match.abstimmen><en> • An appropriate size to match the level of motor skills of a child in the recommended age range.
<G-vec00250-002-s026><match.abstimmen><de> Glatter, bequemer Kragen, der auf die Konturen des Halses abgestimmt ist.
<G-vec00250-002-s026><match.abstimmen><en> Smooth, comfortable collar designed to match the contours of the neck and provide a great seal and feel.
<G-vec00250-002-s027><match.abstimmen><de> Diese Schlüsselhülle aus hochwertigem weissen Leder ist exklusiv auf die Innenausstattung Ihres Volvo abgestimmt.
<G-vec00250-002-s027><match.abstimmen><en> This key fob shell in high-quality white leather is exclusively designed to match the interior of your Volvo.
<G-vec00250-002-s028><match.abstimmen><de> Für ein perfektes Arrangement sollten auch die grünen Protagonisten aufeinander abgestimmt sein.
<G-vec00250-002-s028><match.abstimmen><en> For a perfect arrangement, the herbs should also match each other.
<G-vec00250-002-s029><match.abstimmen><de> Durch Edge-Blending und Skalierung werden die Projektionen perfekt in Helligkeit und Farbe aufeinander abgestimmt, ohne sichtbare Übergänge zu erzeugen.
<G-vec00250-002-s029><match.abstimmen><en> Edge blending and scaling perfectly match each image in terms of brightness and colour, with no visible joins.
<G-vec00250-002-s030><match.abstimmen><de> Erstellen Sie schnell faire und zuverlässige Dienstpläne, die auf Ihre Geschäftsabläufe abgestimmt sind.
<G-vec00250-002-s030><match.abstimmen><en> Quickly create fair, reliable and intelligent schedules optimized to match your business practices.
<G-vec00250-002-s031><match.abstimmen><de> Dieses Sweatshirt mit Rundhalsausschnitt präsentiert sich in einem edlen Gemisch aus Baumwolle, Seide und Kaschmir und verfügt über einen kontrastfarbenen Kragen und farbige Akzente im Rippenbereich, die auf die emblematische Louis Vuitton Stickerei abgestimmt sind.
<G-vec00250-002-s031><match.abstimmen><en> Writing Books this crew neck sweater features a contrasting collar and highlights on the ribs that match Louis Vuitton's emblematic embroidery.
<G-vec00250-002-s032><match.abstimmen><de> Unsere durchdachten und bewährten Organisationsstrukturen mit Projektleitern und eingespielten Arbeitsgruppen erlauben uns eine flexible Ressourcenplanung, die genau auf das jeweilige Bauvorhaben abgestimmt ist.
<G-vec00250-002-s032><match.abstimmen><en> Our carefully thought-out and proven organisational structure with project managers and well-coordinated work groups enables us to plan resources flexibly and match them perfectly with the construction project in question.
<G-vec00250-002-s033><match.abstimmen><de> Die Einstiegsversionen sind preislich auf die Kosten von ein oder zwei Gesangsstunden abgestimmt und sind für Gesangs- und Instrumentalübungen gedacht.
<G-vec00250-002-s033><match.abstimmen><en> The entry-level editions are priced to match the cost of one or two voice lessons and are intended for vocal and instrumental practice.
<G-vec00250-002-s034><match.abstimmen><de> Es wird perfekt mit Trikots in der gleichen Farbe abgestimmt.
<G-vec00250-002-s034><match.abstimmen><en> It will perfectly match with the leotards in the same color.
<G-vec00250-002-s035><match.abstimmen><de> Die Treppenstufen sind in Farbton und Struktur auf unsere Naturholzböden abgestimmt und ergeben ein harmonisches Erscheinungsbild.
<G-vec00250-002-s035><match.abstimmen><en> The stairs match our natural wood floors in terms of both colour and structure to create a harmonious visual appearance.
<G-vec00250-002-s036><match.abstimmen><de> Das gesis® IP+ System ist genau auf diese rauen Anforderungen abgestimmt.
<G-vec00250-002-s036><match.abstimmen><en> The gesis® IP+ system is the perfect match to these rugged
<G-vec00250-002-s037><match.abstimmen><de> Ob Sie nun bereits ein iGrafx-Kunde sind, oder einfach nur von unserer prämierten Software gehört haben und gerne wissen möchten, wie Sie diese nutzen könnten, unsere Berater erarbeiten Lösungen für Sie, die auf Ihre Projekte und Ziele abgestimmt sind und die Sie in Ihrem Unternehmen nachgestalten und nutzen können.
<G-vec00250-002-s037><match.abstimmen><en> Whether you are an existing iGrafx customer or have heard about our award- winning software and would like to see how it can improve what you do, our consultants match your projects and goals to solutions you can re-create and deploy throughout your company. Custom Modeling Assistance Custom Solutions
<G-vec00260-002-s023><insure.abstimmen><de> Wir achten hierbei darauf, dass die Komponenten optimal aufeinander abgestimmt sind, um bestmögliche Ergebnisse zu erzielen.
<G-vec00260-002-s023><insure.abstimmen><en> We make sure that all equipment fits together in order to insure best possible results.
<G-vec00318-002-s019><align.abstimmen><de> Genau so wichtig sind Datenschutzstandards, die auf die Unternehmensziele und Kundenerwartungen abgestimmt sind.
<G-vec00318-002-s019><align.abstimmen><en> Then they need to develop privacy standards that align with their business goals and customer expectations.
<G-vec00318-002-s020><align.abstimmen><de> Dadurch wird die Performance der Gebotsanpassungen von Anzeigenzeitplänen erhöht, da sie besser auf den Zeitpunkt des Klicks abgestimmt werden können, anstatt den Abschluss zugrunde zu legen.
<G-vec00318-002-s020><align.abstimmen><en> This will improve the performance of ad schedule bid modifiers, as they align better to the time of the click, instead of the conversion.
<G-vec00318-002-s021><align.abstimmen><de> Mit den Vorschriften von IFRS 17 «Versicherungsverträge» wird die Darstellung von Erlösen auf jene anderer Branchen abgestimmt.
<G-vec00318-002-s021><align.abstimmen><en> Requirements in IFRS 17 Insurance Contracts align the presentation of revenue with other industries.
<G-vec00318-002-s022><align.abstimmen><de> Passen Sie die Farben mit der Benutzer-LUT (Lookup-Tabelle) an, abrufbar über die Dell UltraSharp Farbkalibrierungssoftware, für hoch präzise Farbdarstellung, die perfekt auf den Dell UltraSharp 32 Monitor abgestimmt ist.
<G-vec00318-002-s022><align.abstimmen><en> Customize colors with the user LUT (look-up table), accessible via the Dell UltraSharp Color Calibration Solution software, for precise colors that align perfectly on the Dell UltraSharp 32 Monitor.
<G-vec00250-003-s019><match_up.abstimmen><de> Die Venture Boxen sind zudem abgestimmt auf den Einsatz mit unserer neuen Horizon Mischpult-Serie.
<G-vec00250-003-s019><match_up.abstimmen><en> As a premium range product, the Venture cabs are a perfect system match for our new Horizon mixer range.
<G-vec00250-003-s020><match_up.abstimmen><de> Mit unseren In-Text-Links entdecken unsere User Produktangebote, die optimal auf Ihren Content abgestimmt sind.
<G-vec00250-003-s020><match_up.abstimmen><en> Our in-text links will help your readers discover the best product offers that match your content.
<G-vec00250-003-s021><match_up.abstimmen><de> Auf dieser Grundlage entwickeln wir Design und Layout der Website und verbessern ihren Content, damit das Angebot kontinuierlich besser auf die Interessen unserer Website-Benutzer abgestimmt wird.
<G-vec00250-003-s021><match_up.abstimmen><en> We monitor customer traffic patterns and site usage to help us develop the design and layout of the site, and to improve the content of our website to better match the interests of our website users.
<G-vec00250-003-s022><match_up.abstimmen><de> Astar Tintenpatronen sind auf die Anforderungen der jeweiligen Printer perfekt abgestimmt.
<G-vec00250-003-s022><match_up.abstimmen><en> Astar ink cartridges perfectly match the requirements of any printer.
<G-vec00250-003-s023><match_up.abstimmen><de> In die neuen Kits – farblich abgestimmt auf die SWISS Kabinenumgebung – integrierten die Designer Teile von Flugzeug-Sitzgurten.
<G-vec00250-003-s023><match_up.abstimmen><en> For the new SWISS amenity kits, which are coloured to match the cabin décor, the designers have also incorporated elements of the inflight seat belt.
<G-vec00250-003-s024><match_up.abstimmen><de> Vom schlichten, natürlichen Aussehen bis hin zu verblüffenden Spiegel- und Linseneffekten: Wir verfügen über ein ganzes Arsenal an Etikettendrucktechniken, die auf Ihre Marke und Ziele abgestimmt sind.
<G-vec00250-003-s024><match_up.abstimmen><en> From simply natural looks to stunning mirror and lense effects, we have a full arsenal of label printing techniques to match your brand and your goals.
<G-vec00250-003-s025><match_up.abstimmen><de> • Kindgerechte Proportionen abgestimmt auf die motorischen Fähigkeiten der empfohlenen Altersklasse.
<G-vec00250-003-s025><match_up.abstimmen><en> • An appropriate size to match the level of motor skills of a child in the recommended age range.
<G-vec00250-003-s026><match_up.abstimmen><de> Glatter, bequemer Kragen, der auf die Konturen des Halses abgestimmt ist.
<G-vec00250-003-s026><match_up.abstimmen><en> Smooth, comfortable collar designed to match the contours of the neck and provide a great seal and feel.
<G-vec00250-003-s027><match_up.abstimmen><de> Diese Schlüsselhülle aus hochwertigem weissen Leder ist exklusiv auf die Innenausstattung Ihres Volvo abgestimmt.
<G-vec00250-003-s027><match_up.abstimmen><en> This key fob shell in high-quality white leather is exclusively designed to match the interior of your Volvo.
<G-vec00250-003-s028><match_up.abstimmen><de> Für ein perfektes Arrangement sollten auch die grünen Protagonisten aufeinander abgestimmt sein.
<G-vec00250-003-s028><match_up.abstimmen><en> For a perfect arrangement, the herbs should also match each other.
<G-vec00250-003-s029><match_up.abstimmen><de> Durch Edge-Blending und Skalierung werden die Projektionen perfekt in Helligkeit und Farbe aufeinander abgestimmt, ohne sichtbare Übergänge zu erzeugen.
<G-vec00250-003-s029><match_up.abstimmen><en> Edge blending and scaling perfectly match each image in terms of brightness and colour, with no visible joins.
<G-vec00250-003-s030><match_up.abstimmen><de> Erstellen Sie schnell faire und zuverlässige Dienstpläne, die auf Ihre Geschäftsabläufe abgestimmt sind.
<G-vec00250-003-s030><match_up.abstimmen><en> Quickly create fair, reliable and intelligent schedules optimized to match your business practices.
<G-vec00250-003-s031><match_up.abstimmen><de> Dieses Sweatshirt mit Rundhalsausschnitt präsentiert sich in einem edlen Gemisch aus Baumwolle, Seide und Kaschmir und verfügt über einen kontrastfarbenen Kragen und farbige Akzente im Rippenbereich, die auf die emblematische Louis Vuitton Stickerei abgestimmt sind.
<G-vec00250-003-s031><match_up.abstimmen><en> Writing Books this crew neck sweater features a contrasting collar and highlights on the ribs that match Louis Vuitton's emblematic embroidery.
<G-vec00250-003-s032><match_up.abstimmen><de> Unsere durchdachten und bewährten Organisationsstrukturen mit Projektleitern und eingespielten Arbeitsgruppen erlauben uns eine flexible Ressourcenplanung, die genau auf das jeweilige Bauvorhaben abgestimmt ist.
<G-vec00250-003-s032><match_up.abstimmen><en> Our carefully thought-out and proven organisational structure with project managers and well-coordinated work groups enables us to plan resources flexibly and match them perfectly with the construction project in question.
<G-vec00250-003-s033><match_up.abstimmen><de> Die Einstiegsversionen sind preislich auf die Kosten von ein oder zwei Gesangsstunden abgestimmt und sind für Gesangs- und Instrumentalübungen gedacht.
<G-vec00250-003-s033><match_up.abstimmen><en> The entry-level editions are priced to match the cost of one or two voice lessons and are intended for vocal and instrumental practice.
<G-vec00250-003-s034><match_up.abstimmen><de> Es wird perfekt mit Trikots in der gleichen Farbe abgestimmt.
<G-vec00250-003-s034><match_up.abstimmen><en> It will perfectly match with the leotards in the same color.
<G-vec00250-003-s035><match_up.abstimmen><de> Die Treppenstufen sind in Farbton und Struktur auf unsere Naturholzböden abgestimmt und ergeben ein harmonisches Erscheinungsbild.
<G-vec00250-003-s035><match_up.abstimmen><en> The stairs match our natural wood floors in terms of both colour and structure to create a harmonious visual appearance.
<G-vec00250-003-s036><match_up.abstimmen><de> Das gesis® IP+ System ist genau auf diese rauen Anforderungen abgestimmt.
<G-vec00250-003-s036><match_up.abstimmen><en> The gesis® IP+ system is the perfect match to these rugged
<G-vec00250-003-s037><match_up.abstimmen><de> Ob Sie nun bereits ein iGrafx-Kunde sind, oder einfach nur von unserer prämierten Software gehört haben und gerne wissen möchten, wie Sie diese nutzen könnten, unsere Berater erarbeiten Lösungen für Sie, die auf Ihre Projekte und Ziele abgestimmt sind und die Sie in Ihrem Unternehmen nachgestalten und nutzen können.
<G-vec00250-003-s037><match_up.abstimmen><en> Whether you are an existing iGrafx customer or have heard about our award- winning software and would like to see how it can improve what you do, our consultants match your projects and goals to solutions you can re-create and deploy throughout your company. Custom Modeling Assistance Custom Solutions
