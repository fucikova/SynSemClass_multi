<G-vec00164-002-s361><look.ausschauen><de> Schau nicht nach unten.
<G-vec00164-002-s361><look.ausschauen><en> Do not look down.
<G-vec00164-002-s362><look.ausschauen><de> 1 Schau sie direkt an.
<G-vec00164-002-s362><look.ausschauen><en> 1 Look directly at her.
<G-vec00164-002-s363><look.ausschauen><de> Schau auf und glaub an Gott, Und segne Grab und Tod.
<G-vec00164-002-s363><look.ausschauen><en> Look up and believe in God, And bless the grave and death.
<G-vec00164-002-s364><look.ausschauen><de> Schau für ein Geschäft in deiner Nähe auf der Übersicht unserer Verkaufsstellen nach.
<G-vec00164-002-s364><look.ausschauen><en> Look for a store near your home in the overview of our retail outlets.
<G-vec00164-002-s365><look.ausschauen><de> Und schau ihm freudig nach.
<G-vec00164-002-s365><look.ausschauen><en> and look towards him with joy.
<G-vec00164-002-s366><look.ausschauen><de> Achtung: bitte schau zuerst in unsere FAQ.
<G-vec00164-002-s366><look.ausschauen><en> Attention: Please first have a look at our FAQ!
<G-vec00164-002-s367><look.ausschauen><de> Die Arbeiter und Anna Charles entgegneten Swamiji: „Schau doch mal, da sind doch nur 10-15 Personen.“ Trotzdem bauten sie eine Plattform, die viel größer war als für 10-15 Gäste.
<G-vec00164-002-s367><look.ausschauen><en> The workers and Anna Charles complained to Swamiji, „Look there are only 10-15 people here.“ Swamiji got the Pond Platform built by them, much bigger than the 10-15 people/guests.
<G-vec00164-002-s368><look.ausschauen><de> Ich erinnere mich gut, wie er einer befreundeten Person anvertraute: „Schau, ich kann mich ja kaum mehr bewegen.
<G-vec00164-002-s368><look.ausschauen><en> I remember well how he confided to a friend, “Look, I can barely even move.
<G-vec00164-002-s369><look.ausschauen><de> Dann habe ich irgendwann angefangen John auf Twitter anzuschreiben:“Hey ich hab hier ein vielversprechendes Projekt, schau es dir doch mal an.“ AZHOS war zu der Zeit noch ein Konzept.
<G-vec00164-002-s369><look.ausschauen><en> Then at some point, I started writing to John on Twitter: “Hey, I have a promising project here, look at it.” AZHOS was still a concept at that time.
<G-vec00164-002-s370><look.ausschauen><de> Schau den Grundriss an der rechten Seite an, mit fünf Zimmer und insgesamt sechzehn Türen.
<G-vec00164-002-s370><look.ausschauen><en> Have a look at the house plan below, with five rooms and sixteen doors in total.
<G-vec00164-002-s371><look.ausschauen><de> Schau, du hörst von mir Dinge, die du zweifellos nicht selbst nachrecherchieren wirst, sondern die du als wahr unterstellst, weil du mir glaubst.
<G-vec00164-002-s371><look.ausschauen><en> Look, you are hearing things from me that you will doubtlessly not double-check yourself, but you will presume they are true, because you believe me.
<G-vec00164-002-s372><look.ausschauen><de> Schau, Ana ist erwachsen.
<G-vec00164-002-s372><look.ausschauen><en> Look Ana is a grown up.
<G-vec00164-002-s373><look.ausschauen><de> Schau genau hin und verlier dich in dieser Welt.
<G-vec00164-002-s373><look.ausschauen><en> Look closer, look deeper, and lose yourself.
<G-vec00164-002-s374><look.ausschauen><de> Schau uns an, immer noch du und ich.
<G-vec00164-002-s374><look.ausschauen><en> Look at us now, still you and me
<G-vec00164-002-s375><look.ausschauen><de> Wenn du Zweifel über die Identität des Busches hast, dann schau die Rinde an: die Rindes des Faulbaumes sieht aus, als ob kleine Striche oder Punkte darauf gemalt wurden.
<G-vec00164-002-s375><look.ausschauen><en> If you have doubts about the identity of the bush, then look at the bark: the bark of the alder buckthorn look as if little white dashes or dots had been drawn on it.
<G-vec00164-002-s376><look.ausschauen><de> Schau rein und mache Deinen ganz persönlichen Frühlingsbeginn zu etwas Besonderem.
<G-vec00164-002-s376><look.ausschauen><en> Look inside and make your very own spring start something special.
<G-vec00164-002-s377><look.ausschauen><de> Schau dir unsere günstigen Hostels in Croydon an oder suche einfach mit Hilfe des obigen Formulars, um den richtigen Ort für deinen Aufenthalt zu finden und zu buchen, dank zuverlässiger Kundenbewertungen, detaillierten Beschreibungen, Fotogalerien und dynamischen Karten der Unterkünfte.
<G-vec00164-002-s377><look.ausschauen><en> You can take a look at our cheap hostels in Kilkenny or simply search using the form above to find and book online the right place to stay, thanks to reliable customers reviews, fully detailed descriptions, photo galleries and dynamic hostel maps.
<G-vec00164-002-s378><look.ausschauen><de> Schau Dir ein paar andere Produktbilder an, die auftauchen, wenn Du nach einem Schlüsselwort suchst, das mit Deinem Produkt zu tun hat.
<G-vec00164-002-s378><look.ausschauen><en> Take a look at some of the other product images that appear when searching a keyword related to your product.
<G-vec00164-002-s379><look.ausschauen><de> Lauf einfach um dein Leben, schau nicht zurück.
<G-vec00164-002-s379><look.ausschauen><en> Just run for your life, do not look back.
<G-vec00164-002-s399><look.ausschauen><de> Schaue ständig auf die Uhr.
<G-vec00164-002-s399><look.ausschauen><en> Look at the clock constantly.
<G-vec00164-002-s400><look.ausschauen><de> Schaue im Russisch-Deutsch Wörterbuch von bab.la vorbei.
<G-vec00164-002-s400><look.ausschauen><en> Have a look at the English-Polish dictionary by bab.la.
<G-vec00164-002-s401><look.ausschauen><de> Und am Hauptbahnhof sowieso: wenn ich dort auf der großen Anzeigetafel schaue, dann steht bei jedem Zug „Verspätung“ auf dem Display.
<G-vec00164-002-s401><look.ausschauen><en> At the main station, if I look there on the large display board, then each train is „late“ on the display.
<G-vec00164-002-s402><look.ausschauen><de> Ich schaue ihn etwas mitleidig an.
<G-vec00164-002-s402><look.ausschauen><en> I look at him somewhat sympathetically.
<G-vec00164-002-s403><look.ausschauen><de> Wenn ich auf mein Leben schaue, dann sehe ich zersplittertes Glas, das unter den Absätzen zerrieben wurde, bis es feiner Sand war.
<G-vec00164-002-s403><look.ausschauen><en> When I look at my life, I see shattered glass that has been ground underneath the heels until it is fine sand.
<G-vec00164-002-s404><look.ausschauen><de> Bevor der Versuch startet, müssen die Blickkameras kalibriert werden – ab diesem Zeitpunkt wird unentwegt aufgezeichnet, wohin ich gerade schaue.
<G-vec00164-002-s404><look.ausschauen><en> Before the experiment starts, the viewing cameras have to be calibrated – from this moment on, wherever I look will be constantly recorded.
<G-vec00164-002-s405><look.ausschauen><de> Man senke die Lider der beiden Augen und schaue nach Innen und reinige das Herz, wasche das Denken, unterbreche die Lüste und wahre den Samen.
<G-vec00164-002-s405><look.ausschauen><en> Let the lids of both eyes be lowered; then look within and purify the heart, wash the thoughts, stop pleasures, and conserve the seed.
<G-vec00164-002-s406><look.ausschauen><de> Einer der Teilnehmer teilt uns seine Erfahrungen mit: „Ich schaue die Straße hinunter, auf dem Boden sitzend, mit tränenden Augen und Brennen im Hals [vom Tränengas], hinter mir hört man Schlagstöcke und Stiefel.
<G-vec00164-002-s406><look.ausschauen><en> One of the participants shared their testimony: "I stop to look down the street, sitting on the pavement with my eyes full of tears and my throat burning [from the teargas], and behind me I can hear sticks and boots.
<G-vec00164-002-s407><look.ausschauen><de> Bitte öffne deine Antiviren- oder Malwareschutzsoftware und schaue in den Einstellungen nach einer Option für eine "Whitelist" oder so was ähnliches.
<G-vec00164-002-s407><look.ausschauen><en> Please open your antivirus or malware protection software and look in the settings for a "whitelist" or something similar.
<G-vec00164-002-s408><look.ausschauen><de> Ich besuche ein paar Freunde auf ihrer Dropzone und schaue mir alles gany genau an.
<G-vec00164-002-s408><look.ausschauen><en> I visit some friends on their Dropzone and look at everything exactly.
<G-vec00164-002-s409><look.ausschauen><de> Ich schaue Dich gerne an und ich liebe es Deine Stimme zu hören.
<G-vec00164-002-s409><look.ausschauen><en> I like to look at you and I love to hear your voice.
<G-vec00164-002-s410><look.ausschauen><de> Ich schaue runter und sehe, wie mein fünfjähriger Sohn mich frech angrinst.
<G-vec00164-002-s410><look.ausschauen><en> I look down and see my five-year-old son grinning at me cheekily.
<G-vec00164-002-s411><look.ausschauen><de> Wenn du zwei Spieler mit gleicher Stärke hast, schaue immer auf ihre Form, da ein Spieler mit guter Form sein Potenzial besser nutzen wird während eines Spiels.
<G-vec00164-002-s411><look.ausschauen><en> If you have two players of similar strength, always have a look at their form, since a player with better form will play closer to his potential during a match.
<G-vec00164-002-s412><look.ausschauen><de> Ich schaue auf die sich dunkler verfärbenden Blätter der Kastanie vor meinem Fenster, leises akustisches Zeug aus meinen Lautsprechern klimpernd.
<G-vec00164-002-s412><look.ausschauen><en> I look outside at the darkening leaves of the chestnut trees while acoustic stuff is coming out of my speakers.
<G-vec00164-002-s413><look.ausschauen><de> Und deshalb schaue nach der Gesundheit des Universums.
<G-vec00164-002-s413><look.ausschauen><en> And so, look to the health of the universe.
<G-vec00164-002-s414><look.ausschauen><de> Als Nächstes schaue ich mir die Termine, die ich außerhalb der Besprechungen, habe und ordne diese nach ihrer Wichtigkeit und danach, ob sie in der verfügbaren Zeit wahrgenommen werden können.
<G-vec00164-002-s414><look.ausschauen><en> Next, I’ll look at the time I have outside of meetings and slot in projects based on how important they are and whether they’ll fit into the time available.
<G-vec00164-002-s415><look.ausschauen><de> Natürlich schaue Ich hinter die Oberfläche.
<G-vec00164-002-s415><look.ausschauen><en> Of course, I look beyond the surface.
<G-vec00164-002-s416><look.ausschauen><de> Dann zeigt ein Klick mit der rechten Maustaste ein Kontextmenü mit den immer gleichen drei animierten Icons: Hand (benutze), Auge (schaue) und Mund (spreche).
<G-vec00164-002-s416><look.ausschauen><en> Then a click with the right mouse button shows a context menu with always the same three animated icons: Hand (use), eye (look) and mouth (speak).
<G-vec00164-002-s417><look.ausschauen><de> Wenn ich schaue, sehe ich warum.
<G-vec00164-002-s417><look.ausschauen><en> Then when I look, I see why.
<G-vec00164-002-s456><look.ausschauen><de> Highlights, wohin man schaut.
<G-vec00164-002-s456><look.ausschauen><en> Highlights wherever you look.
<G-vec00164-002-s457><look.ausschauen><de> JOHN WYNGATE: In einer Situation wie dieser schaut man nach jemandes Reue und all den Eigenschaften, die mit der Bitte zusammenhängen, wieder in die Christenversammlung zurückkommen zu dürfen.
<G-vec00164-002-s457><look.ausschauen><en> JOHN WYNGATE: In a situation like that, you look for a person's remorse, and all of these qualities that go along with a request to be able to be allowed back into the Christian congregation.
<G-vec00164-002-s458><look.ausschauen><de> Sayid schaut zu Desmond, der immer noch auf das Foto starrt.
<G-vec00164-002-s458><look.ausschauen><en> [Sayid turns to look at Desmond, who is still looking at the photograph.]
<G-vec00164-002-s459><look.ausschauen><de> Wer beim Wandern in der Holsteinischen Schweiz in den Himmel schaut, hat gute Chancen, die Königsklasse der Raubvögel zu beobachten.
<G-vec00164-002-s459><look.ausschauen><en> If you look up towards the sky while hiking in Holstein Switzerland, you have a good chance of catching a glimpse of the most majestic bird of prey.
<G-vec00164-002-s460><look.ausschauen><de> 16 Wenn ihr fastet, so schaut nicht finster drein wie die Heuchler; denn diese entstellen ihr Antlitz, damit die Menschen sehen, daß sie fasten.
<G-vec00164-002-s460><look.ausschauen><en> 16 “When you fast, do not look drab as the hypocrites do, for they disfigure their faces to show others they are fasting.
<G-vec00164-002-s461><look.ausschauen><de> Schaut ihm in die Augen und streckt mit seiner Zunge verschiedene lustige Geräusche.
<G-vec00164-002-s461><look.ausschauen><en> Look into his eyes and, sticking out his tongue, make different funny sounds.
<G-vec00164-002-s462><look.ausschauen><de> Dann schaut ihr zu uns herauf und fragt: „ Was ist der Sinn des Lebens?“ und wir geben die Frage an euch nach unten zurück, “was ist der Sinn des Lebens?“, denn ihr seid es, nicht wir, die diese Antworten haben.
<G-vec00164-002-s462><look.ausschauen><en> Then you look up to us and ask, “What is the meaning of life?” and we echo down to you, “What is the meaning of life?” because it is you who hold those answers, not us.
<G-vec00164-002-s463><look.ausschauen><de> Schaut, ohne Ablenkung, in die Essenz der Dumpfheit.
<G-vec00164-002-s463><look.ausschauen><en> Without distraction, look into the essence of dullness.
<G-vec00164-002-s464><look.ausschauen><de> Vom kleinen Balkon schaut man direkt auf die Verkaufsstände der Gemüse- und Fischhändler.
<G-vec00164-002-s464><look.ausschauen><en> From the balcony we could look at the daily food market of Palermo, we enjoyed it very much.
<G-vec00164-002-s465><look.ausschauen><de> Schaut euch die Welt an, auch abseits von der Eiger-Nordwand.
<G-vec00164-002-s465><look.ausschauen><en> Look at the world around you – but look beyond the North Face of the Eiger.
<G-vec00164-002-s466><look.ausschauen><de> Schaut genau hin und ihr werdet den Unterschied in der Familiendynamik zwischen damals und heute erkennen.
<G-vec00164-002-s466><look.ausschauen><en> Look closely and you’ll see the difference in family dynamics between then and today, even in seemingly mundane clips like a child’s birthday party.
<G-vec00164-002-s467><look.ausschauen><de> Die neue Version ist viel einfacher zu bedienen und schaut hübsch aus.
<G-vec00164-002-s467><look.ausschauen><en> The new versions are much easier to use and look great too.
<G-vec00164-002-s468><look.ausschauen><de> Wenn Information gesucht wird, überscrollt man solche Webdesigner-Sünden schnell und schaut ob weiter unten noch etwas Brauchbares folgt.
<G-vec00164-002-s468><look.ausschauen><en> When you are looking for information, you scroll through such web designer signs quickly and look for whether something is usable below.
<G-vec00164-002-s469><look.ausschauen><de> Schaut einfach umher.
<G-vec00164-002-s469><look.ausschauen><en> Just look around.
<G-vec00164-002-s470><look.ausschauen><de> Es war, als sage Jesus: „Schaut, ihr müsst aus dieser kasuistischen Logik herauskommen und in eine andere Richtung blicken“, in die Richtung des „Prinzips“.
<G-vec00164-002-s470><look.ausschauen><en> It is as if Jesus is saying “Look, you’ve got to get out of this casuistic logic and look in another direction altogether, you’ve got to look at how it was ‘in the beginning’.
<G-vec00164-002-s471><look.ausschauen><de> In Spanien neigt sich die Urlaubssaison allmählich dem Ende zu, so dass man dort wieder mehr auf die Exportmärkte schaut, was mit deutlichen Preisrückgängen einhergeht.
<G-vec00164-002-s471><look.ausschauen><en> The Spanish holiday season draws to a close gradually, so that export markets are being taken a closer look at in Spain again. Clear price reductions are coming along with it.
<G-vec00164-002-s472><look.ausschauen><de> Es scheint, dass ein Mann auf die Person schaut, mit der Sie ihm empfehlen, ein Beispiel zu nehmen, und dann sofort beginnen, auf gleicher Höhe mit ihm zu sein, um nicht schlechter in Ihren Augen zu schauen.
<G-vec00164-002-s472><look.ausschauen><en> It seems that a man will look at the person with whom you recommend him to take an example, and then immediately begin to level with him, to look no worse in your eyes.
<G-vec00164-002-s473><look.ausschauen><de> "Hey, schaut, die Hälfte der Rezensionen von TSWCE zählen nicht mehr.
<G-vec00164-002-s473><look.ausschauen><en> Hey look, half the reviews of TSWCE no longer count.
<G-vec00164-002-s474><look.ausschauen><de> Man schaut um sich und kann sehen dass das, was man vor Monaten (in unserem Fall Jahren) begonnen hat zu zeichnen nun zum Leben erwacht ist.
<G-vec00164-002-s474><look.ausschauen><en> You have a look around and you see that what you have started drawing months (in our case years) ago has come to life.
