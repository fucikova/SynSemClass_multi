<G-vec00060-001-s029><convey.ausdrücken><de> Genome Editing (Crispr) Genschere, molekulares Skalpell – solche und andere Umschreibungen aus der Alltagssprache sollen ausdrücken, was die neue Methode mit dem unaussprechlichen Namen CRISPR/Cas9 kann: schneiden – genauer, das Erbgutmolekül DNA durchtrennen, und das präzise an einer bestimmten Stelle.
<G-vec00060-001-s029><convey.ausdrücken><en> Genome Editing Genome Editing (Crispr) Gene scissors, molecular scalpel – these descriptive terms are intended to convey what the new method of gene editing with rather unwieldy name of CRISPR/Cas9 can do.
<G-vec00060-001-s030><convey.ausdrücken><de> Diese zwei Worte sind so klein, sie können nicht ausdrücken wie tief der Schmerz in meinem Herzen war.
<G-vec00060-001-s030><convey.ausdrücken><en> Those two words are so small they cannot convey to you how deeply in my heart I hurt.
<G-vec00060-001-s031><convey.ausdrücken><de> In ekstatischen Zuständen, erreicht in der Ausübung strenger Disziplin, geraten Sufi-Derwische in Resonanz mit den Seelen von Wesen dieser Ebene, die etwas von der Natur der Inspiration ausdrücken, die sie belebt.
<G-vec00060-001-s031><convey.ausdrücken><en> In their ecstasy aroused in the exercise of austere disciplines, the Sufi dervishes are tuned in resonance with the souls of beings at this level who convey something of the nature of the inspiration that animates them.
<G-vec00060-001-s032><convey.ausdrücken><de> Hier finden Sie ein elegantes Setting mit sanfter Hintergrundmusik und Symbolen, die allesamt die feineren Dinge des Lebens ausdrücken.
<G-vec00060-001-s032><convey.ausdrücken><en> Here, you'll see an elegant setting with soft music playing in the background and symbols that all convey the finer things in life.
<G-vec00060-001-s033><convey.ausdrücken><de> So weißt du sicher, dass ihre Bedeutung mit dem übereinstimmt, was du der Außenwelt gegenüber ausdrücken möchtest.
<G-vec00060-001-s033><convey.ausdrücken><en> In this way, you can be sure that the meaning corresponds to what you want to convey to the outside world.
<G-vec00060-001-s034><convey.ausdrücken><de> Das größte Problem entsteht, wenn die Botschaft, die wir verkünden, dann mit diesen zweitrangigen Aspekten gleichgesetzt wird, die, obwohl sie relevant sind, für sich allein nicht das Eigentliche der Botschaft Jesu Christi ausdrücken.
<G-vec00060-001-s034><convey.ausdrücken><en> The biggest problem is when the message we preach then seems identified with those secondary aspects which, important as they are, do not in and of themselves convey the heart of Christ’s message.
<G-vec00060-001-s035><convey.ausdrücken><de> Es ist unglaublic zu sehen, wie Tony so viel Gefühl ausdrücken kann.
<G-vec00060-001-s035><convey.ausdrücken><en> It ́s amazing to see how Tony can convey so much emotion .
<G-vec00060-001-s036><convey.ausdrücken><de> Damit wollen wir ausdrücken, daß dieses Dokument etwas von der Autorität, dem Ausmaß und Verständnis eines hochrangigen Dokuments besitzt, während es gleichzeitig aber nachrangige Einzelheiten aufweist.
<G-vec00060-001-s036><convey.ausdrücken><en> By this we mean to convey the idea that it is a document that carries with it some of the authority, scope, and comprehension of a high level document but at the same time provides some low-level detail.
<G-vec00060-001-s037><convey.ausdrücken><de> "Er sieht alles in ""Zahlen"" und ""Buchstaben"", kann aber ""Wörter"" oder ""Sätze"" noch nicht ""lesen"" und kann deshalb nicht zu dem Wissen kommen, das diese ""Wörter"" und ""Sätze"" ausdrücken."
<G-vec00060-001-s037><convey.ausdrücken><en> "He sees everything as ""numbers"" and ""letters"", but he cannot yet ""read"" ""words"" or ""sentences"", and cannot therefore arrive at the knowledge that these ""words"" and ""sentences"" convey."
<G-vec00081-001-s038><put.ausdrücken><de> Einfach ausgedrückt, halten Fosagro bis vor kurzem versucht, mich und die Pflanze, und das Geld für sie zu verlassen.
<G-vec00081-001-s038><put.ausdrücken><en> Simply put, holding Fosagro until recently tried to leave myself and the plant, and the money for it.
<G-vec00081-001-s039><put.ausdrücken><de> Einfach ausgedrückt, von der Interviewer Sie mochte oder nicht, hängt ab, ob Sie angestellt werden.
<G-vec00081-001-s039><put.ausdrücken><en> Simply put, on the interviewer liked you or not depends on whether you will be hired.
<G-vec00081-001-s040><put.ausdrücken><de> Der Weg, der aus dem Leiden herausführt, ist Meditation selbst oder anders ausgedrückt: Wir müssen achtsam sein.
<G-vec00081-001-s040><put.ausdrücken><en> To put it simply, we must be mindful. Mindfulness is knowing, or presence of mind.
<G-vec00081-001-s041><put.ausdrücken><de> "Vereinfacht ausgedrückt: Je kürzer Telomere im Lauf der Zeit werden, desto ""älter"" sind die Zellen."
<G-vec00081-001-s041><put.ausdrücken><en> "Put simply: the shorter the telomeres become over time, the ""older"" the cells."
<G-vec00081-001-s042><put.ausdrücken><de> Oder anders ausgedrückt: Das Atmen ist fünfzig Mal gefährlicher als die Summe der Strahlung, die wir normalerweise aus allen Quellen erhalten.
<G-vec00081-001-s042><put.ausdrücken><en> Or to put it another way, breathing is fifty times more dangerous than the sum total of radiation we normally receive from all sources.
<G-vec00081-001-s043><put.ausdrücken><de> Das bedeutet andersherum ausgedrückt: Viele Batterieanbieter müssen bei einer Auslegung auf 20 Jahre eine hohe Kapazität wählen, um bei einer geringen Entladetiefe (DoD) eine passable Nettokapazität zu erreichen.
<G-vec00081-001-s043><put.ausdrücken><en> Put another way, this means that a number of battery suppliers must ensure a high capacity level with a 20-year design to achieve an acceptable net capacity with a lower depth of discharge (DoD).
<G-vec00081-001-s044><put.ausdrücken><de> Einfach ausgedrückt: Autofahren wird in den kommenden Jahren noch sicherer und noch komfortabler.
<G-vec00081-001-s044><put.ausdrücken><en> To put it simply, in the coming years driving a car will become even safer and more comfortable.
<G-vec00081-001-s045><put.ausdrücken><de> Abschließend möchte ich noch sagen, daß jeder, der all diesem gegenüber einen logischen und analytischen Blickwinkel hat, sich alle schriftlichen Werke der Menschheit ansehen kann, alle Bücher, und keinen finden wird, der so klar und vollständig ausgedrückt hat, wie die Dynamiken überleben können.
<G-vec00081-001-s045><put.ausdrücken><en> And to finish off, I just want to say, anyone who has a logical and analytical viewpoint of all this can look through all the written works of man, all the written books, and they will never find anyone who has put it so clearly, and so fully there on how the dynamics can survive.
<G-vec00081-001-s046><put.ausdrücken><de> Einfach ausgedrückt, können Sie einfach mit einer Ferse auf den Boden klopfen, während Sie fernsehen oder am Computer arbeiten.
<G-vec00081-001-s046><put.ausdrücken><en> Simply put, you can just knock on the floor with a heel while watching TV or working on a computer.
<G-vec00081-001-s047><put.ausdrücken><de> Anavar ist noch 17 alpha alkyliert, modifiziert, die einfach ausgedrückt, legt nahe, dass es die Leber vor Abbau vermeidet die energetischen Komponenten, und es ist das, was eine Belastung für die Leber erzeugt, wenn in teuren einer Dosierung verwendet und auch für zu lang.
<G-vec00081-001-s047><put.ausdrücken><en> Anavar is still customized 17 alpha alkylated, which simply put, suggests that it avoids the liver from breaking down the energetic components, and it is THAT which causes a pressure to the liver if made use of in expensive a dosage as well as for too long.
<G-vec00081-001-s048><put.ausdrücken><de> Gleichmut bezieht sich hier, ganz einfach ausgedrückt, darauf, dass es zur Natur von Samsara gehört, dass es immer auf und ab geht.
<G-vec00081-001-s048><put.ausdrücken><en> Equanimity here, to put it in simple language, means that the nature of samsara is that it goes up and down.
<G-vec00081-001-s049><put.ausdrücken><de> Einfach ausgedrückt ist es der Wunsch, andere Menschen mögen glücklich sein.
<G-vec00081-001-s049><put.ausdrücken><en> Put simply, it's the wish that other people may be happy.
<G-vec00081-001-s050><put.ausdrücken><de> Die Forschung hat gezeigt, dass ältere wächst zu einem Anstieg der hyperplastischen Pathologien verbunden ist, oder, einfach ausgedrückt, ein Anstieg der Rate, mit der Ihre Zellen zu reproduzieren, eine Vorstufe zu Problemen wie Krebs.
<G-vec00081-001-s050><put.ausdrücken><en> Research has shown that growing older is linked to a rise in hyperplastic pathologies, or, simply put, a rise in the rate at which your cells reproduce, a precursor to problems like cancer.
<G-vec00081-001-s051><put.ausdrücken><de> Ganz einfach ausgedrückt ist Hingabe eine geschickte und praktische Art, uns empfänglicher für die Wahrheit der Lehren der Übertragungslinie zu machen, wie sie vom Lehrer verkörpert und übertragen werden.
<G-vec00081-001-s051><put.ausdrücken><en> Put most simply, devotion is a skilful and practical way of making us more receptive to the truth of the teachings of the lineage, as embodied and transmitted by the teacher.
<G-vec00081-001-s052><put.ausdrücken><de> Einfach ausgedrückt: sie können in den höheren Schwingungs-Ebenen nicht überleben, die lediglich für Seelen vorgesehen sind, die sich über die Notwendigkeit hinaus-entwickelt haben, die niedere Ebene noch weiter erfahren zu müssen.
<G-vec00081-001-s052><put.ausdrücken><en> Simply put, they cannot survive in the higher vibrations that are for souls who have moved past the need for further experience at that level.
<G-vec00081-001-s053><put.ausdrücken><de> Einfach ausgedrückt, gibt es keinen Grund, dass jemand mit Schizophrenie in einem Job nicht erfolgreich sein kann, wenn er die richtige Behandlung erhält.
<G-vec00081-001-s053><put.ausdrücken><en> Simply put, there’s no reason someone with schizophrenia can’t thrive in a job so long as they’re receiving the right treatment.
<G-vec00081-001-s054><put.ausdrücken><de> Oder anders ausgedrückt: Damit eine innovative Geschäftseinheit nicht vom Monolithen platt gemacht wird.
<G-vec00081-001-s054><put.ausdrücken><en> Or, to put it another way: so that an innovative business unit would not be squashed by monoliths.
<G-vec00081-001-s055><put.ausdrücken><de> Einfach ausgedrückt bedeutet dies, dass alle der Jahre Beiträge in die Rentensysteme der qualifizierten Länder berücksichtigt werden können, zu entscheiden, ob eine Person durch eine Rente oder nicht.
<G-vec00081-001-s055><put.ausdrücken><en> Put simply, this means that all of the years' contributions paid into the pension systems of qualifying countries can be taken into consideration to decide if an individual is due a pension or not.
<G-vec00081-001-s056><put.ausdrücken><de> Oder anders ausgedrückt verfallen die Preise für Technische Kunststoffe seit August 2015 (1310 €/t) bis Dezember 2015 (1227 €/t) schrittweise.
<G-vec00081-001-s056><put.ausdrücken><en> Or to put it differently: technical plastics prices have fallen by increments from August 2015 (1310 €/t) to December 2015 (1231 €/t).
<G-vec00354-002-s095><express.ausdrücken><de> Diese Art der Unterstützung ist eine große Ehre für das Museum, gerne möchten wir unsere Dankbarkeit und Anerkennung schon zu Lebzeiten ausdrücken.
<G-vec00354-002-s095><express.ausdrücken><en> The museum is highly honoured by this form of support, and it is a pleasure for us to have the opportunity to express our gratitude and recognition within the donor’s lifetime.
<G-vec00354-002-s096><express.ausdrücken><de> Zahlreiche Studien haben bewiesen, dass die Art und Weise, wie sich die Gene in unserem Körper ausdrücken, nicht von unserer DNA vorherbestimmt ist, sondern von der Wahl unseres Lebensstils und der Wahrnehmung der Welt, die uns umgibt.
<G-vec00354-002-s096><express.ausdrücken><en> Mounting evidence has proven that the way genes express themselves in our bodies is not predetermined by our DNA, but is in fact controlled and modified by our lifestyle choices and by our perception of the world around us.
<G-vec00354-002-s097><express.ausdrücken><de> Doch auch unter jenen, welche nicht so weit gingen, gab es ein beständiges Gefühl, dass, solange die Kämpfe an den Arbeitsplatz gebunden blieben, sie sich nur als Verteidigung der Bedingung der Arbeiterklasse ausdrücken könnten.
<G-vec00354-002-s097><express.ausdrücken><en> Yet even among those who didn't go as far, there was an abiding sense that as long as struggles remained attached to the workplace they could only express themselves as a defence of the condition of the working class.
<G-vec00354-002-s098><express.ausdrücken><de> Das Tragen eines Hijab bedeutet nicht, dass du dich nicht ausdrücken kannst.
<G-vec00354-002-s098><express.ausdrücken><en> Wearing a hijab does not mean you cannot express yourself.
<G-vec00354-002-s099><express.ausdrücken><de> Es konnte aber auch die Ankunft der Gottheit im Tempel ausdrücken.
<G-vec00354-002-s099><express.ausdrücken><en> It could also express the coming of the god in the temple.
<G-vec00354-002-s100><express.ausdrücken><de> Jede Prinzessin will ihr Schließfach mit den am besten aussehenden Stücken dekorieren und ihr ursprüngliches Selbst ausdrücken.
<G-vec00354-002-s100><express.ausdrücken><en> Each princess wants to decorate her locker with the best looking pieces and express her original self.
<G-vec00354-002-s102><express.ausdrücken><de> Wenn die Influencer Ihnen den Eindruck von "bezahlter Arbeit" vermitteln, wenn Sie Ihre Marke auf einmal ausdrücken, wird eine authentischere Sharing-Umgebung geboten, denn sie transferieren ihre eigenen Erfahrungen, wenn Sie Ihre Marke langfristig und in Intervallen vertreten, so dass das Vertrauen in Ihr Marken-Zielgruppe-Influencer-Dreieck solide ist.
<G-vec00354-002-s102><express.ausdrücken><en> When the influencers give you the impression of "paid work" when you express your brand in one go, a more authentic sharing environment is provided because they transfer their own experiences when you represent your brand in the long run and at intervals, so that the trust in your brand - target group - influencer triangle is built on solid basis.
<G-vec00354-002-s103><express.ausdrücken><de> Wir würden die freien Ersatzteile während des Garantiedatums ausdrücken.
<G-vec00354-002-s103><express.ausdrücken><en> We would express the free replacement parts during the warranty date.
<G-vec00354-002-s104><express.ausdrücken><de> - sich spontan und fließend ausdrücken, ohne öfter deutlich erkennbar nach Worten suchen zu müssen.
<G-vec00354-002-s104><express.ausdrücken><en> - express themselves fluently and spontaneously on a range of subjects without visibly having to search for words.
<G-vec00354-002-s105><express.ausdrücken><de> Ich möchte Wissen teilen, mich selbst ausdrücken und meine Redefreiheit ausleben.
<G-vec00354-002-s105><express.ausdrücken><en> The motivations are to share knowledge, to express myself, and to exercise my freedom of expression.
<G-vec00354-002-s106><express.ausdrücken><de> Daher musste EIN SEIN es hinnehmen, dass sich sein gewaltiges Potenzial an Licht und Liebe, sein Geist und Sein nicht ausdrücken konnte, dass seine ganze Weisheit und Macht am Ende zu nichts nütze sein würden.
<G-vec00354-002-s106><express.ausdrücken><en> And so, ONE BEING had to accept that nothing changed, that it could not express its huge potential of love and light, that its wisdom and power was no use at all.
<G-vec00354-002-s107><express.ausdrücken><de> Wenn Sie eine sehr gute Aufmerksamkeit durch das Team von Ärzten von Intermedical Hospital of Sc erhalten haben und Sie möchten Ihre Dankbarkeit ausdrücken, hinterlassen Sie einen Kommentar in ihrer Datei.
<G-vec00354-002-s107><express.ausdrücken><en> If you have received a very good attention by the team of doctors of St Luke's Hospitaal Malawi and you want to express your gratitude, leave a comment in their file.
<G-vec00354-002-s108><express.ausdrücken><de> Ich möchte mich selbst verwirklichen können, mich ausdrücken, die Welt verstehen und Missstände ändern, Gleichgesinnte finden, das Leben entdecken und vor allem unabhängig Sein.
<G-vec00354-002-s108><express.ausdrücken><en> I want to be able to completely fulfill myself, to express myself, to find like-minded people, to discover life and in particular I wish to be independent.
<G-vec00354-002-s109><express.ausdrücken><de> Ein Traum, der sich in Gesten zeigt, die Eleganz ausdrücken und perfekte Konturen formen.
<G-vec00354-002-s109><express.ausdrücken><en> A dream that continues through gestures that express elegance and shape perfect forms.
<G-vec00354-002-s110><express.ausdrücken><de> Das räumen auch Sie ein, wie mir scheint, auch wenn Sie es mit anderen Worten ausdrücken.
<G-vec00354-002-s110><express.ausdrücken><en> I think you too recognise this, although you express it differently.
<G-vec00354-002-s111><express.ausdrücken><de> Die Seele möchte immer Liebe ausdrücken und erschaffen, denn dies ist unsere wahre Natur, unsere göttliche Natur.
<G-vec00354-002-s111><express.ausdrücken><en> The soul always wants to express and create love, as this is our true nature, our Divine Nature.
<G-vec00354-002-s112><express.ausdrücken><de> An erster Stelle steht und grundlegend ist die Initiative Gottes, die wir theologisch im Begriff ‚Geschenk’ ausdrücken werden.
<G-vec00354-002-s112><express.ausdrücken><en> Logically, morality is secondary to God’s founding initiative, which we express theologically in terms of gift.
<G-vec00354-002-s113><express.ausdrücken><de> Diese Hinweise, einmal identifiziert, können dann anerkannt und integriert werden und sich schließlich ganz durch unser Leben ausdrücken.
<G-vec00354-002-s113><express.ausdrücken><en> By identifying and acknowledging these indications we will be able to integrate and finally express them through our lives.
<G-vec00369-002-s038><put.ausdrücken><de> Einfach ausgedrückt bedeutet dies, dass Trader nicht mehr als 1% ihres GESAMTEN Guthabens bei einer Trade-Idee riskieren sollten.
<G-vec00369-002-s038><put.ausdrücken><en> Simply put, this means traders should risk no more than 1% of their TOTAL balance on any one trade idea.
<G-vec00369-002-s039><put.ausdrücken><de> Einfach ausgedrückt, große Ressourcen sind im östlichen Eurasien vorhanden.
<G-vec00369-002-s039><put.ausdrücken><en> Simply put, large resources are in eastern Eurasia.
<G-vec00369-002-s040><put.ausdrücken><de> Oder anders ausgedrückt die Kunststoffproduktion hat sich in etwa auf dem Niveau des Vorjahres behauptet.
<G-vec00369-002-s040><put.ausdrücken><en> Or to put it differently, plastics production has more or less held its own at the previous year's level.
<G-vec00369-002-s041><put.ausdrücken><de> Einfach ausgedrückt handelt es sich um eine Art von Oberflächenmontagekomponenten ohne Kabel oder kurzes Kabel (abgekürzt als SMC / SMD) auf der Oberfläche der Leiterplatte (Leiterplatte, Leiterplatte) oder einer anderen Substratoberfläche durch Reflow-Löten oder Tauchlöten und andere Methoden zum Schweißen und Zusammenbau der Schaltungstechnik.
<G-vec00369-002-s041><put.ausdrücken><en> Simply put, it is a type of surface mounting components without lead or short lead (abbreviated as SMC/SMD) on the surface of the printed circuit board (Printed Circuit Board, PCB) or other substrate surface, through reflow soldering Or dip soldering and other methods for welding and assembly of circuit assembly technology.
<G-vec00369-002-s042><put.ausdrücken><de> QuestBack bietet professionelle Umfragesoftware sowie komplette Feedbacklösungen, mit denen unsere Kunden Erkenntnisse über ihre Kunden und Mitarbeiter gewinnen und so Treue, Wachstum und Rentabilität steigern können Einfach ausgedrückt: Wir geben Ihnen die Antworten, die Sie für den entscheidenden Vorsprung brauchen.
<G-vec00369-002-s042><put.ausdrücken><en> QuestBack delivers mobile-first surveys as well as full service feedback solutions enabling our clients to collect customer and employee insight – and convert it into loyalty, growth and profitability. Put simply, we give you the answers you need to get ahead.
<G-vec00369-002-s043><put.ausdrücken><de> Ganz einfach ausgedrückt solltest du wissen, gegen wen du antrittst.
<G-vec00369-002-s043><put.ausdrücken><en> Simply put, you need to know what you’re up against.
<G-vec00369-002-s044><put.ausdrücken><de> Einfach ausgedrückt, es wird elektronisch ein Sklave und niemand .
<G-vec00369-002-s044><put.ausdrücken><en> Simply put, it will be electronic slave and a nobody .
<G-vec00369-002-s045><put.ausdrücken><de> Einfach ausgedrückt: Der Kauf von echten YouTube-Aufrufen stellt nicht bloß eine vorübergehende Investition dar.
<G-vec00369-002-s045><put.ausdrücken><en> Simply put, buying real YouTube views in not just a temporarily investment.
<G-vec00369-002-s046><put.ausdrücken><de> Einfach ausgedrückt: Eine Prozessüberwachung achtet auf die Güte des Bearbeitungsprozesses, die Maschinenüberwachung dient dem Schutz der Maschine und ihrer Komponenten.
<G-vec00369-002-s046><put.ausdrücken><en> To put it simple: process monitoring looks after the quality of the machining process, machine monitoring protects the machine and its components
<G-vec00369-002-s047><put.ausdrücken><de> Einfach ausgedrückt, dieses neue Layout der Website-Inhalte in Suchmaschine Yandex.
<G-vec00369-002-s047><put.ausdrücken><en> Simply put, this new layout of website content in search engine Yandex.
<G-vec00369-002-s048><put.ausdrücken><de> Die 100 Euro Europäische Währungsunion Goldmünzen haben das Standard-Gewicht von 1/2 Unze Gold oder anders ausgedrückt, wiegt diese Gedenk-Goldmünze 15,55 Gramm.
<G-vec00369-002-s048><put.ausdrücken><en> The 100 Euro European Monetary Union gold coins come in the standard weight of 1/2 troy ounces of gold or otherwise put, this commemorative gold coin weighs 15.55 grams.
<G-vec00369-002-s049><put.ausdrücken><de> Die Göttin schaut tatsächlich um die Ecke oder nüchtern ausgedrückt: Sie hat das erste adaptive Kurvenlicht der Automobilgeschichte und untermauerte damit in den 1960er-Jahren Citroens Ruf als innovativer Autobauer mit Sinn für ausgefallene Details.
<G-vec00369-002-s049><put.ausdrücken><en> The goddess can actually look around corners, or to put it simply: she has the first adaptive headlights in automotive history. In the 1960s, this confirmed Citroen's reputation as an innovative car manufacturer with a sense for unusual details.
<G-vec00369-002-s050><put.ausdrücken><de> Einfach ausgedrückt, es gibt keine hundertprozentige Möglichkeit, dass ein Mensch mit einer garantierten Strategie für das Schlagen eines Spielautomaten aufwarten könnte.
<G-vec00369-002-s050><put.ausdrücken><en> Simply put, there is absolutely 100% no way a human can possibly come up with a guaranteed strategy to beating a slot machine.
<G-vec00369-002-s051><put.ausdrücken><de> Einfach ausgedrückt, eine Folge von zwei oder drei orangefarbenen Boxen zu höheren (niedrigeren) Preisen deutet darauf hin, dass die Dynamik zunimmt.
<G-vec00369-002-s051><put.ausdrücken><en> Simply put, a succession of two or three orange blocks at higher (lower) prices indicate momentum is building.
<G-vec00369-002-s052><put.ausdrücken><de> Einfach ausgedrückt, mit einer massgeschneiderten Lösung von MobyDick erhalten Sie die Reifenwaschanlagen, die Sie benötigen.
<G-vec00369-002-s052><put.ausdrücken><en> Simply put, with a bespoke solution from MobyDick, you get the wheel washing units you need.
<G-vec00369-002-s053><put.ausdrücken><de> Einfach ausgedrückt, ist Typografie die Kunst und Technik der Anordnung von Schrift, um geschriebene Worte lesbar und ästhetisch ansprechend zu machen.
<G-vec00369-002-s053><put.ausdrücken><en> Simply put, typography is the art and technique of arranging type to make written words legible and aesthetically pleasing.
<G-vec00369-002-s054><put.ausdrücken><de> Einfach ausgedrückt, ist Interroll ein echter Wachstums- und Optimierungsfaktor in der Welt des Einzelhandels und des E-Commerce.
<G-vec00369-002-s054><put.ausdrücken><en> Simply put, Interroll is a true enabler of growth and optimization in the world of retails and e-commerce.
<G-vec00369-002-s055><put.ausdrücken><de> Einfach ausgedrückt bieten funktionale Kräftigungsübungen uns genau die Art der Kraft, die uns vor Verletzungen schützt.
<G-vec00369-002-s055><put.ausdrücken><en> So, put simply, functional strength exercises give us the type of strength that stops us from getting injured.
<G-vec00369-002-s056><put.ausdrücken><de> Einfach ausgedrückt, es sind dies Käufe von Unternehmen, oft solchen, auf die Tausende Menschen angewiesen sind.
<G-vec00369-002-s056><put.ausdrücken><en> Simply put, this is about purchasing business enterprises, oftentimes ones upon which thousands of people rely for their livelihoods.
<G-vec00417-002-s028><portray.ausdrücken><de> Und mit dem klassischen chinesischen Tanz kann man so ziemlich alles ausdrücken, ob Glück, Schönheit, Mitgefühl oder Frieden – denselben Frieden, für den sich die Kampfkunst letzten Endes einsetzt.
<G-vec00417-002-s028><portray.ausdrücken><en> And with classical Chinese dance, you can portray almost anything, whether it be happiness, beauty, compassion, or peace—the same peace that martial arts are ultimately for.
<G-vec00486-002-s038><put_off.ausdrücken><de> Einfach ausgedrückt bedeutet dies, dass Trader nicht mehr als 1% ihres GESAMTEN Guthabens bei einer Trade-Idee riskieren sollten.
<G-vec00486-002-s038><put_off.ausdrücken><en> Simply put, this means traders should risk no more than 1% of their TOTAL balance on any one trade idea.
<G-vec00486-002-s039><put_off.ausdrücken><de> Einfach ausgedrückt, große Ressourcen sind im östlichen Eurasien vorhanden.
<G-vec00486-002-s039><put_off.ausdrücken><en> Simply put, large resources are in eastern Eurasia.
<G-vec00486-002-s040><put_off.ausdrücken><de> Oder anders ausgedrückt die Kunststoffproduktion hat sich in etwa auf dem Niveau des Vorjahres behauptet.
<G-vec00486-002-s040><put_off.ausdrücken><en> Or to put it differently, plastics production has more or less held its own at the previous year's level.
<G-vec00486-002-s041><put_off.ausdrücken><de> Einfach ausgedrückt handelt es sich um eine Art von Oberflächenmontagekomponenten ohne Kabel oder kurzes Kabel (abgekürzt als SMC / SMD) auf der Oberfläche der Leiterplatte (Leiterplatte, Leiterplatte) oder einer anderen Substratoberfläche durch Reflow-Löten oder Tauchlöten und andere Methoden zum Schweißen und Zusammenbau der Schaltungstechnik.
<G-vec00486-002-s041><put_off.ausdrücken><en> Simply put, it is a type of surface mounting components without lead or short lead (abbreviated as SMC/SMD) on the surface of the printed circuit board (Printed Circuit Board, PCB) or other substrate surface, through reflow soldering Or dip soldering and other methods for welding and assembly of circuit assembly technology.
<G-vec00486-002-s042><put_off.ausdrücken><de> QuestBack bietet professionelle Umfragesoftware sowie komplette Feedbacklösungen, mit denen unsere Kunden Erkenntnisse über ihre Kunden und Mitarbeiter gewinnen und so Treue, Wachstum und Rentabilität steigern können Einfach ausgedrückt: Wir geben Ihnen die Antworten, die Sie für den entscheidenden Vorsprung brauchen.
<G-vec00486-002-s042><put_off.ausdrücken><en> QuestBack delivers mobile-first surveys as well as full service feedback solutions enabling our clients to collect customer and employee insight – and convert it into loyalty, growth and profitability. Put simply, we give you the answers you need to get ahead.
<G-vec00486-002-s043><put_off.ausdrücken><de> Ganz einfach ausgedrückt solltest du wissen, gegen wen du antrittst.
<G-vec00486-002-s043><put_off.ausdrücken><en> Simply put, you need to know what you’re up against.
<G-vec00486-002-s044><put_off.ausdrücken><de> Einfach ausgedrückt, es wird elektronisch ein Sklave und niemand .
<G-vec00486-002-s044><put_off.ausdrücken><en> Simply put, it will be electronic slave and a nobody .
<G-vec00486-002-s045><put_off.ausdrücken><de> Einfach ausgedrückt: Der Kauf von echten YouTube-Aufrufen stellt nicht bloß eine vorübergehende Investition dar.
<G-vec00486-002-s045><put_off.ausdrücken><en> Simply put, buying real YouTube views in not just a temporarily investment.
<G-vec00486-002-s046><put_off.ausdrücken><de> Einfach ausgedrückt: Eine Prozessüberwachung achtet auf die Güte des Bearbeitungsprozesses, die Maschinenüberwachung dient dem Schutz der Maschine und ihrer Komponenten.
<G-vec00486-002-s046><put_off.ausdrücken><en> To put it simple: process monitoring looks after the quality of the machining process, machine monitoring protects the machine and its components
<G-vec00486-002-s047><put_off.ausdrücken><de> Einfach ausgedrückt, dieses neue Layout der Website-Inhalte in Suchmaschine Yandex.
<G-vec00486-002-s047><put_off.ausdrücken><en> Simply put, this new layout of website content in search engine Yandex.
<G-vec00486-002-s048><put_off.ausdrücken><de> Die 100 Euro Europäische Währungsunion Goldmünzen haben das Standard-Gewicht von 1/2 Unze Gold oder anders ausgedrückt, wiegt diese Gedenk-Goldmünze 15,55 Gramm.
<G-vec00486-002-s048><put_off.ausdrücken><en> The 100 Euro European Monetary Union gold coins come in the standard weight of 1/2 troy ounces of gold or otherwise put, this commemorative gold coin weighs 15.55 grams.
<G-vec00486-002-s049><put_off.ausdrücken><de> Die Göttin schaut tatsächlich um die Ecke oder nüchtern ausgedrückt: Sie hat das erste adaptive Kurvenlicht der Automobilgeschichte und untermauerte damit in den 1960er-Jahren Citroens Ruf als innovativer Autobauer mit Sinn für ausgefallene Details.
<G-vec00486-002-s049><put_off.ausdrücken><en> The goddess can actually look around corners, or to put it simply: she has the first adaptive headlights in automotive history. In the 1960s, this confirmed Citroen's reputation as an innovative car manufacturer with a sense for unusual details.
<G-vec00486-002-s050><put_off.ausdrücken><de> Einfach ausgedrückt, es gibt keine hundertprozentige Möglichkeit, dass ein Mensch mit einer garantierten Strategie für das Schlagen eines Spielautomaten aufwarten könnte.
<G-vec00486-002-s050><put_off.ausdrücken><en> Simply put, there is absolutely 100% no way a human can possibly come up with a guaranteed strategy to beating a slot machine.
<G-vec00486-002-s051><put_off.ausdrücken><de> Einfach ausgedrückt, eine Folge von zwei oder drei orangefarbenen Boxen zu höheren (niedrigeren) Preisen deutet darauf hin, dass die Dynamik zunimmt.
<G-vec00486-002-s051><put_off.ausdrücken><en> Simply put, a succession of two or three orange blocks at higher (lower) prices indicate momentum is building.
<G-vec00486-002-s052><put_off.ausdrücken><de> Einfach ausgedrückt, mit einer massgeschneiderten Lösung von MobyDick erhalten Sie die Reifenwaschanlagen, die Sie benötigen.
<G-vec00486-002-s052><put_off.ausdrücken><en> Simply put, with a bespoke solution from MobyDick, you get the wheel washing units you need.
<G-vec00486-002-s053><put_off.ausdrücken><de> Einfach ausgedrückt, ist Typografie die Kunst und Technik der Anordnung von Schrift, um geschriebene Worte lesbar und ästhetisch ansprechend zu machen.
<G-vec00486-002-s053><put_off.ausdrücken><en> Simply put, typography is the art and technique of arranging type to make written words legible and aesthetically pleasing.
<G-vec00486-002-s054><put_off.ausdrücken><de> Einfach ausgedrückt, ist Interroll ein echter Wachstums- und Optimierungsfaktor in der Welt des Einzelhandels und des E-Commerce.
<G-vec00486-002-s054><put_off.ausdrücken><en> Simply put, Interroll is a true enabler of growth and optimization in the world of retails and e-commerce.
<G-vec00486-002-s055><put_off.ausdrücken><de> Einfach ausgedrückt bieten funktionale Kräftigungsübungen uns genau die Art der Kraft, die uns vor Verletzungen schützt.
<G-vec00486-002-s055><put_off.ausdrücken><en> So, put simply, functional strength exercises give us the type of strength that stops us from getting injured.
<G-vec00486-002-s056><put_off.ausdrücken><de> Einfach ausgedrückt, es sind dies Käufe von Unternehmen, oft solchen, auf die Tausende Menschen angewiesen sind.
<G-vec00486-002-s056><put_off.ausdrücken><en> Simply put, this is about purchasing business enterprises, oftentimes ones upon which thousands of people rely for their livelihoods.
<G-vec00555-002-s155><squeeze_out.ausdrücken><de> Abtropfen lassen, gut ausdrücken und fein hacken.
<G-vec00555-002-s155><squeeze_out.ausdrücken><en> Drain, squeeze dry and chop finely.
<G-vec00555-002-s156><squeeze_out.ausdrücken><de> Die Estragonblätter blanchieren, in kaltem Wasser abschrecken und mit einem Geschirrtuch gut ausdrücken.
<G-vec00555-002-s156><squeeze_out.ausdrücken><en> Blanch the tarragon leaves, dip in cold water and squeeze it with a dish towel.
<G-vec00557-002-s040><spell_out.ausdrücken><de> Ich finde das aufgrund der jüngsten Entwicklungen gut und richtig; nicht nur, weil wir unsere Sorgen ausdrücken wollen –über Entlassungswellen, Inhaftierungen und Repressalien-, sondern weil wir auch über Konsequenzen in unserem Handeln nachdenken müssen.
<G-vec00557-002-s040><spell_out.ausdrücken><en> In view of recent developments, I consider this to be right and proper, and not only because we want to spell out our concerns – about waves of dismissals, arrests and repressive measures – but also because we must consider the consequences that they have for our actions.
<G-vec00557-002-s041><spell_out.ausdrücken><de> Unten sind unsere Nutzungsbedingungen aufgeführt, die ausdrücken, was Sie von uns erwarten können und was wir von Ihnen erwarten.
<G-vec00557-002-s041><spell_out.ausdrücken><en> Below are our Terms of Use which spell out what you can expect from us and what we expect from you.
<G-vec00557-002-s042><spell_out.ausdrücken><de> Der klassische chinesische Tanz mit seinem reichhaltigen Vokabular kann durch Körpersprache (eine universelle Sprache) jedes Gefühl ausdrücken.
<G-vec00557-002-s042><spell_out.ausdrücken><en> With its rich vocabulary, classical Chinese dance can spell out any emotion through body language (a universal language).
<G-vec00557-002-s043><spell_out.ausdrücken><de> Viele Menschen werden die Absurdität dieses Arguments erkennen, insbesondere wenn Sie es so offen ausdrücken.
<G-vec00557-002-s043><spell_out.ausdrücken><en> Many people will see through the absurdity of this argument, particularly if you spell it out as plainly as that.
<G-vec00611-002-s029><portray.ausdrücken><de> Die Eigentümer haben versucht Ihre Begeisterung für die Jazzmusik auszudrücken, indem Sie die zwei Häuser mit den Namen Cool Jazz und Hot Jazz entworfen haben.
<G-vec00611-002-s029><portray.ausdrücken><en> The owners have tried to portray their fascination with jazz and so they developed 2 sets of apartments that are called Cool Jazz and Hot Jazz.
<G-vec00648-002-s023><squeeze.ausdrücken><de> Um den Trockenvorgang abzukürzen, können sie die Matte mit einem Handtuch aufrollen und das überflüssige Wasser ausdrücken.
<G-vec00648-002-s023><squeeze.ausdrücken><en> You can roll your mat up with a towl and squeeze excess water out to speed up the drying process.
<G-vec00648-002-s024><squeeze.ausdrücken><de> Nach dem Waschen kannst du deine Yogamatte fest in ein großes Handtuch rollen und alles überschüssige Wasser ausdrücken.
<G-vec00648-002-s024><squeeze.ausdrücken><en> After washing you can roll your yoga mat tightly into a large towel, and squeeze out all excess water.
<G-vec00648-002-s025><squeeze.ausdrücken><de> Sojagranulat in einem Sieb abgießen und Flüssigkeit so gut wie möglich ausdrücken.
<G-vec00648-002-s025><squeeze.ausdrücken><en> Pour soy granules in a colander and squeeze out liquid as far as possible.
<G-vec00648-002-s026><squeeze.ausdrücken><de> Einfach in Aquariumwasser (oder Teichwasser) ein paar mal ausdrücken und schon sind diese wieder wie neu.
<G-vec00648-002-s026><squeeze.ausdrücken><en> Just squeeze them out in aquarium water a few times and they look like new.
<G-vec00648-002-s027><squeeze.ausdrücken><de> Den Gewürzbeutel vorsichtig ausdrücken und entfernen.
<G-vec00648-002-s027><squeeze.ausdrücken><en> Squeeze the spice bag carefully and discard.
<G-vec00648-002-s028><squeeze.ausdrücken><de> Das Brot nach ein paar Minuten vorsichtig ausdrücken und zerstückelt in eine Salatschüssel geben.
<G-vec00648-002-s028><squeeze.ausdrücken><en> After a few minutes gently squeeze the bread and brake into pieces into a bowl.
<G-vec00648-002-s029><squeeze.ausdrücken><de> Bevor ihr das Sauerkraut ebenso in die Schüssel gebt, diesen in einem Sieb gründlich abspülen, fein hacken und danach in einem frischen Geschirrtuch gut ausdrücken.
<G-vec00648-002-s029><squeeze.ausdrücken><en> Before you also put the sauerkraut in the bowl, rinse it thoroughly in a sieve, finely chop and then squeeze well in a fresh dishcloth.
<G-vec00648-002-s030><squeeze.ausdrücken><de> Anschließend den Stockfisch aus dem Wasser nehmen und überschüssiges Wasser vorsichtig mit den Händen ausdrücken.
<G-vec00648-002-s030><squeeze.ausdrücken><en> Once the process is complete, remove the cod from the water and squeeze gently with your hands to eliminate the excess.
<G-vec00648-002-s031><squeeze.ausdrücken><de> Ricotta in einem Küchentuch gut ausdrücken und in eine Schale geben.
<G-vec00648-002-s031><squeeze.ausdrücken><en> Thoroughly squeeze out the ricotta in a paper towel and place it in a bowl.
<G-vec00648-002-s155><squeeze.ausdrücken><de> Abtropfen lassen, gut ausdrücken und fein hacken.
<G-vec00648-002-s155><squeeze.ausdrücken><en> Drain, squeeze dry and chop finely.
<G-vec00648-002-s156><squeeze.ausdrücken><de> Die Estragonblätter blanchieren, in kaltem Wasser abschrecken und mit einem Geschirrtuch gut ausdrücken.
<G-vec00648-002-s156><squeeze.ausdrücken><en> Blanch the tarragon leaves, dip in cold water and squeeze it with a dish towel.
