<G-vec00588-002-s019><shorten.abkürzen><de> In Summe sind es 8 andere Motorradfahrer die den Zug zum Abkürzen ihrer Etappen nutzen.
<G-vec00588-002-s019><shorten.abkürzen><en> In total there are 8 other motorcyclists who use the train to shorten their stages.
<G-vec00588-002-s020><shorten.abkürzen><de> Die gesamte Strecke wird im Gegenverkehr geführt, so dass man abkürzen und wenden kann, wann immer man will.
<G-vec00588-002-s020><shorten.abkürzen><en> The entire stretch has traffic running in the opposite direction so you can shorten your trip and turn around whenever you want.
<G-vec00588-002-s021><shorten.abkürzen><de> Zusätzlich zum persönlichen Beitrag des Einzelnen zum medizinischen Fortschritt ist einer der wichtigsten Beweggründe für die Teilnahme an einer klinischen Studie zugleich auch der mögliche individuelle Nutzen: Die Patienten haben Zugang zu einer Behandlung, die am Markt noch nicht verfügbar ist – einer Behandlung, die den Verlauf ihrer Erkrankung abkürzen, ihr Leben verlängern oder ihre Lebensqualität verbessern kann.
<G-vec00588-002-s021><shorten.abkürzen><en> In addition to making a personal contribution to medical progress, one of the central motivating factors for participating in a clinical study is at the same time its most valuable potential benefit: patients have access to a medication that is not yet available on the market, a medication which may be able to shorten the course of their disease, prolong their lives or improve their quality of life.
<G-vec00588-002-s022><shorten.abkürzen><de> Haltet ihnen immer wieder diese Gnade vor, und suchet sie zu bestimmen, sich eurem Willen anzuschließen und gleich eurer Seele auszureifen, auf daß sie selbst ihren Entwicklungsgang abkürzen können, wenn sie eure Ratschläge beherzigen.
<G-vec00588-002-s022><shorten.abkürzen><en> Keep reminding them of this blessing and try to persuade them to accept your will and to mature like your soul, so that they can shorten their process of development if they take your advice to heart.
<G-vec00588-002-s023><shorten.abkürzen><de> Den Weg zu Station 3 kann man mittels öffentlicher Verkehrsmittel über den Ring etwas abkürzen.
<G-vec00588-002-s023><shorten.abkürzen><en> You can shorten your way to Stage 3 a bit by using some public transport along the Ring.
<G-vec00588-002-s024><shorten.abkürzen><de> Computer können leicht Wörter abkürzen, aber nicht andersherum (St. könnte Street oder Saint heißen).
<G-vec00588-002-s024><shorten.abkürzen><en> Computers can easily shorten words, but not the other way (St. could be Street or Saint).
<G-vec00588-002-s025><shorten.abkürzen><de> Sie können die Etappe mit Schiff oder Bahn abkürzen.
<G-vec00588-002-s025><shorten.abkürzen><en> You can shorten today's stage by ship or by train.
<G-vec00588-002-s026><shorten.abkürzen><de> An dieser Stelle wird Ultra Pure natürlich den Weg abkürzen.
<G-vec00588-002-s026><shorten.abkürzen><en> At this point Ultra Pure naturally shorten the way.
