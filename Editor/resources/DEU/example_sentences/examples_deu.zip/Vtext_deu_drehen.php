<G-vec00057-001-s228><turn.drehen><de> Drehe deinen Körper vom Türrahmen oder der Wand weg, bis du ein Ziehen direkt unter dem Schlüsselbein spüren kannst.
<G-vec00057-001-s228><turn.drehen><en> Turn your body out from the doorway or wall until you can feel the stretch just below your collar bone.
<G-vec00057-001-s229><turn.drehen><de> ich drehe bald durch, hänge seid einer Woche im Vulkanlevel Stage 5 fast.
<G-vec00057-001-s229><turn.drehen><en> I turn now by, depends are one week in the volcano Stage Level 5 set.
<G-vec00057-001-s230><turn.drehen><de> Wenn du mit einer Seite des Nackens fertig bist, drehe seinen Kopf sanft auf die andere Seite und bearbeite diese.
<G-vec00057-001-s230><turn.drehen><en> When you’ve finished working one side of the neck, gently turn his head the other way and work the other side.
<G-vec00057-001-s231><turn.drehen><de> title: Additions- und Subtraktions-Gedächtnisspiel gegen Tux description: Drehe die Karten um, so dass du zwei Zahlen findest, die die gleiche Summe oder Differenz ergeben, bis alle Karten verschwunden sind.
<G-vec00057-001-s231><turn.drehen><en> title: Addition and subtraction memory game against Tux description: Turn the cards over to find two numbers which add or subtract the same, until all the cards are gone.
<G-vec00057-001-s232><turn.drehen><de> Mein Verhaltung dieser Art von Menschen gegenüber: Zuerst versuche ich es mit Freundlichkeit, Wenn ich damit keinen Erfolg habe, drehe ich mich um und mache unter die Beziehung, so eine besteht, einen Schlussstrich.
<G-vec00057-001-s232><turn.drehen><en> It takes years that their arrogant demeanor settles down. My behavior towards this kind of arrogant people: First I try it with friendliness, If I do not succeed, I turn around and end the relationship, if one exists.
<G-vec00057-001-s233><turn.drehen><de> Wähle und drehe die ISO Skala damit sie mit dem ISO -Wert des Films, den du benutzt, übereinstimmt.
<G-vec00057-001-s233><turn.drehen><en> Select and turn the ISO Dial so that it matches the ISO of the film you are using.
<G-vec00057-001-s234><turn.drehen><de> Heute Abend, ein Windstoß rund verdickt; Ich drehe, niemand in der Nähe, SOLA e mi Basto mentre viluppo...
<G-vec00057-001-s234><turn.drehen><en> Tonight, a gust of wind thickened around; I turn, no one around, SOLA e mi Basto mentre viluppo…
<G-vec00057-001-s235><turn.drehen><de> Drehe die Zurück und Vorderseite RS out.
<G-vec00057-001-s235><turn.drehen><en> Turn the Back and Front RS out.
<G-vec00057-001-s236><turn.drehen><de> Drehe den Pfeil auf der Wählscheibe deines Herzens auf 'Unbekannt', und von dort ist es nicht mehr weit bis zu dem Ort, wo Freund geschrieben steht.
<G-vec00057-001-s236><turn.drehen><en> You put those signs up. Turn the arrow on the dial of your heart to unknown and from there it is not a far cry to the space where friend is written.
<G-vec00057-001-s237><turn.drehen><de> Ich drehe mich um, sehe zwei junge Frauen.
<G-vec00057-001-s237><turn.drehen><en> I turn round, see two young women.
<G-vec00057-001-s238><turn.drehen><de> Drehe die Karten um passende Paare von Safari Tiere zu finden.
<G-vec00057-001-s238><turn.drehen><en> Turn the cards to find matching pairs of safari animals.
<G-vec00057-001-s239><turn.drehen><de> Drehe die Anlage nicht lauter, wenn du dir zum Beispiel deine Lieblingsnummer anhörst.
<G-vec00057-001-s239><turn.drehen><en> Do not turn your headphones up too loud when, for example, listening to your favourite number.
<G-vec00057-001-s240><turn.drehen><de> Schlussendlich drehe ich den Wasserstrahl ab und rubble mich mit einem weichen Handtuch trocken.
<G-vec00057-001-s240><turn.drehen><en> Eventually, I turn off the spray and towel myself dry.
<G-vec00057-001-s241><turn.drehen><de> Ich wische mir die Tinte aus den Augen, drehe den Zündschlüssel und lasse meine quadratische Tomate in ein Grummeln verfallen.
<G-vec00057-001-s241><turn.drehen><en> I brush the ink from my eyes, turn the contact and put my square tomato to a growl.
<G-vec00057-001-s242><turn.drehen><de> "Drehe den vorderen/ersten Regler auf ""hoch/high"" und warte zwei bis drei Sekunden, damit sich das Gas in der Zündkammer sammeln kann."
<G-vec00057-001-s242><turn.drehen><en> Turn the front/first controller to ‘high’ and wait two to three seconds for the gas to accumulate in the ignition chamber.
<G-vec00057-001-s243><turn.drehen><de> Aufhellung ein Zimmer mit Kunst, können Blumen und andere persönliche Gegenstände ein guter Weg, um eine langweilige Bereich in einem schönen Raum, wo Sie verbringen am liebsten alle Ihre freie Zeit drehe sein.
<G-vec00057-001-s243><turn.drehen><en> Brightening up a room with art, flowers and other personal artifacts can be a great way to turn a boring area into a beautiful chamber where you’ll love spending all of your free time.
<G-vec00057-001-s244><turn.drehen><de> Drehe das Papier um und drehe nochmal eine Lasche nach rechts.
<G-vec00057-001-s244><turn.drehen><en> Flip the paper over and turn a flap over to the right again.
<G-vec00057-001-s245><turn.drehen><de> Drehe dein Gesicht zur Seite, um die Schatten zu optimieren, damit du dramatischer aussiehst.
<G-vec00057-001-s245><turn.drehen><en> Turn your face to the side to optimize on shadows to create a more dramatic look.
<G-vec00057-001-s246><turn.drehen><de> Drücke fest auf die Schrauben und drehe sie langsam.
<G-vec00057-001-s246><turn.drehen><en> Push hard and start to turn the screws slowly.
<G-vec00057-001-s247><turn.drehen><de> * R / C Double Side Speed Auto kann 360 ° Spins, umkippen und Flip zurück auf Land nur durch drehen und drehen Sie die rechte Seite des Controllers.
<G-vec00057-001-s247><turn.drehen><en> *R/C Double side speed car can 360°spins, flip over and flip back on land just by turn up and turn down the right side of controller.
<G-vec00057-001-s248><turn.drehen><de> Zu der Stein Plattform links drehen.
<G-vec00057-001-s248><turn.drehen><en> Turn towards the stone platform on the left.
<G-vec00057-001-s249><turn.drehen><de> """Wir werden um den Kanal zu wechseln und die Seite drehen."
<G-vec00057-001-s249><turn.drehen><en> “We’re going to change the channel and turn the page.
<G-vec00057-001-s250><turn.drehen><de> So drehen, dass man in dem Raum schauen kann, wenn nötig die Umsehen-Taste drücken.
<G-vec00057-001-s250><turn.drehen><en> Turn to face into the room so you are able to see the blades. Press the look button if necessary.
<G-vec00057-001-s251><turn.drehen><de> "Du kannst die Klinge deiner Tischkreissäge drehen, sodass sie in die ""falsche"" Richtung schneidet."
<G-vec00057-001-s251><turn.drehen><en> "You can also turn the blade around on your table or circular saw so that it is cutting in the ""wrong"" direction."
<G-vec00057-001-s252><turn.drehen><de> Manche haben argumentiert, dass die Gesetzgebung eher schädlich als hilfreich ist jedoch, mit dem Potenzial, gute Absichten in die Stolpersteine â â für diese Protokolle bereits in Ort, um mit Lyme-Borreliose sowohl auf Landes-und Bundesebene beschäftigen drehen .
<G-vec00057-001-s252><turn.drehen><en> Some have argued that the legislation is harmful rather than helpful however, with the potential to turn good intentions into stumbling blocks for those protocols already in place to deal with Lyme disease at both state and federal level.
<G-vec00057-001-s253><turn.drehen><de> Oft konnte ich den Kopf nicht drehen und hatte starke Schmerzen im Hinterkopf und in der rechten Schulter.
<G-vec00057-001-s253><turn.drehen><en> Often I was not able to turn my head and suffered from intense pain at the back of it and in my right shoulder.
<G-vec00057-001-s254><turn.drehen><de> Sie werden hellbraun drehen und in der Größe zu reduzieren.
<G-vec00057-001-s254><turn.drehen><en> They will turn light brown and reduce in size.
<G-vec00057-001-s255><turn.drehen><de> Zum Reinigen des Systems zunächst die integrierte Reinigungsschublade um 180° drehen und anschließend die Plattenmagnete mittels der montierten Schnellspanner entriegeln und abschwenken.
<G-vec00057-001-s255><turn.drehen><en> First turn to clean the system, the integrated cleaning drawer by 180 ° and then unlock the plate magnets mounted by means of the quick release and swiveled.
<G-vec00057-001-s256><turn.drehen><de> Abkühlen lassen, sanft die Kornkörbe drehen und füllen sie mit Oktopus-Salat und Kartoffeln.
<G-vec00057-001-s256><turn.drehen><en> Let cool, gently turn the grain baskets and fill them with octopus salad and potatoes.
<G-vec00057-001-s257><turn.drehen><de> "Weiter zu drehen, Muster verändern sich ständig, so genannte "" Kaleidoskop ."
<G-vec00057-001-s257><turn.drehen><en> "Continue to turn, patterns are constantly changing, so called "" Kaleidoscope . """
<G-vec00057-001-s258><turn.drehen><de> Wenn das auch nicht überzeugen, Sie könnte die Tatsache, dass Tencent betrachten, der Besitzer der chinesischen Nachrichtenmammut, WeChat, und die fünftgrößte Internet-Unternehmen der Welt nach Umsatz, investiert $50 Million in Kik in 2015 als Beweis für ihre Überzeugung, dass Kik die Ladung in der westlichen Welt der Einführung des WeChat Modells führen würde: wo ein Ökosystem von mobilen Anwendungen jedes Smartphone in eine Nabe drehen kann, die Befugnisse der modernen, digitale Wirtschaft.
<G-vec00057-001-s258><turn.drehen><en> If that doesn’t convince you, you might consider the fact that Tencent, the owner of China’s messaging mammoth, WeChat, and the world’s fifth-largest internet company by revenue,invested $50 millioninto Kik in 2015 as evidence of their belief that Kik would lead the charge in the western world’s adoption of the WeChat model: where an ecosystem of mobile apps can turn every smartphone into a hub that powers the modern, digital economy.
<G-vec00057-001-s259><turn.drehen><de> Um die Einbaulage der zwei Flanschen (OP-Flansche und Befestigungsflansche RINV-OP) zu ändern, die zwei Schrauben entfernen, die Flansche in die gewünschte Position drehen und die Schrauben wieder befestigen.
<G-vec00057-001-s259><turn.drehen><en> To change the mounting position of the two flanges (flange OP and fixing flange RINV-OP), screw-off the two fixing screws, turn the flange in desired position, and fix the two screws.
<G-vec00057-001-s260><turn.drehen><de> Reparieren Sie Benzschlüsselausfall, dem stoßweise oder dauerhaft nicht drehen kann Zündung auf, einschließlich die geregelte Schlüsseltorsion, das Schlüsseldatencodehopfen, Fernbedienung kann nicht verwendet werden, das Zündschloss (UVB) kann nicht und so weiter bestimmen.
<G-vec00057-001-s260><turn.drehen><en> RepairBenz key failure that intermittently or permanently can not turn ignition on, including the key twist fixed, the key data code hopping, remote control can not be used, the ignition lock (EIS) can not diagnose and so on.
<G-vec00057-001-s261><turn.drehen><de> Die nicht halbnumerierten Ziegel drehen von der abgespalteten Seite ins Mauerwerk um.
<G-vec00057-001-s261><turn.drehen><en> Not half-number bricks turn the broken away party in a laying.
<G-vec00057-001-s262><turn.drehen><de> Wenn Sie die Position, die Sie einfach entsperren die Rückenlehne durch Drehen am Handrad ändern wollen, wenn Sie ausgewählt haben, die gewünschte Winkel muss das Handrad in die entgegengesetzte Richtung zu drehen, um die Rückenlehne in der neuen Position zu verriegeln.
<G-vec00057-001-s262><turn.drehen><en> When you want to change the position you simply unlock the seat back by turning the handwheel, once you have selected the desired angle must turn the handwheel in the opposite direction to lock the backrest in the new location.
<G-vec00057-001-s263><turn.drehen><de> Wenn Sie nicht am Morgen aufstehen und brauchen einen Wecker jeden Tag aufwachen, dann können Sie das alte Gerät in die genaue Sache drehen Sie wollen.
<G-vec00057-001-s263><turn.drehen><en> If you cannot get up in the morning and need an alarm clock to wake you up every day, then you can turn the old device into the exact thing you want.
<G-vec00057-001-s264><turn.drehen><de> Aber wir sind am nächsten Wochenende (03.12.2005) herzlich zum Tag der offenen Tür eingeladen und werden dann mal ein paar Runden drehen.
<G-vec00057-001-s264><turn.drehen><en> However, we are next weekend (03.12.2005) cordially to the day of the open door invited and a few rounds will turn then once.
<G-vec00057-001-s265><turn.drehen><de> Das Kugelgelenk ermöglicht stufenloses Drehen und Neigen in alle Richtungen.
<G-vec00057-001-s265><turn.drehen><en> The ball-joint makes it possible to turn and tilt the lamp in all directions.
<G-vec00057-001-s267><turn.drehen><de> Drehen Sie den Steuerungsknopf auf Verbindungen und drücken Sie den Steuerungsknopf.
<G-vec00057-001-s267><turn.drehen><en> Turn the rotary pushbutton to Connections and press the rotary pushbutton.
<G-vec00057-001-s268><turn.drehen><de> so, Abschnitt Tudela (Navarra) die AN-Gruppe ist für einen Teil des Geschäfts verantwortlich, die spezialisiert, der Binnenmarkt für Produkte der Saison -in Süß-, und integrieren drehen Sie den Katalog und Produkte Unica Gruppe.
<G-vec00057-001-s268><turn.drehen><en> Thus, section Tudela (Navarra) the AN Group is responsible for part of the business which specializes, the internal market for seasonal produce -in fresh-, and will incorporate turn the catalog and products Unica Group.
<G-vec00057-001-s269><turn.drehen><de> Um die Statusanzeige des Kopiervorgangs im MMI-Display auszublenden, drehen Sie den Steuerungsknopf auf Kopiervorgang im Hintergrund und drücken Sie den Steuerungsknopf.
<G-vec00057-001-s269><turn.drehen><en> If you would like to hide the display of the copying progress, turn the rotary pushbutton to Copying in background and press to confirm.
<G-vec00057-001-s270><turn.drehen><de> Um die Teletext-Seite zu wechseln, drehen Sie den Steuerungsknopf.
<G-vec00057-001-s270><turn.drehen><en> Turn the rotary pushbutton to change the teletext page.
<G-vec00057-001-s271><turn.drehen><de> Drehen sie das Rad bei Position 6.
<G-vec00057-001-s271><turn.drehen><en> Turn the wheel at location 6.
<G-vec00057-001-s272><turn.drehen><de> PhenQ ist eine innovative Formel, die zusammen mit 5 leistungsfähige Enzyme Booster, die sicherlich dominieren Hunger helfen als auch drehen Sie Ihren Körper in einem 24-Stunden Fettverbrennung Gerät, indem Sie Ihren Stoffwechsel in Verbindung.
<G-vec00057-001-s272><turn.drehen><en> PhenQ is an innovative formula that combined together with 5 powerful enzymes boosters that will assist dominate appetite pains and also turn your physical body right into a 1 Day fat burning device by boosting your metabolism.
<G-vec00057-001-s273><turn.drehen><de> Unsere Kunden können durch die Schlacke zu navigieren, drehen Sie die richtigen Autos, die Sie kaufen möchten.
<G-vec00057-001-s273><turn.drehen><en> Our buyers can navigate through the dross to turn up the proper cars you want to buy.
<G-vec00057-001-s274><turn.drehen><de> Drehen Sie das Modell in den schönsten und elegantesten Braut.
<G-vec00057-001-s274><turn.drehen><en> Turn the model into the prettiest and most elegant bride.
<G-vec00057-001-s275><turn.drehen><de> "Danach das Werkstück drehen und laufen Sie die Klappe ""Tal""."
<G-vec00057-001-s275><turn.drehen><en> "After this, the workpiece to turn and run the fold ""valley""."
<G-vec00057-001-s276><turn.drehen><de> Drehen Sie örtskiktet regelmäßig und nutzen Biomasse als Mulch um Bäume und Sträucher.
<G-vec00057-001-s276><turn.drehen><en> Turn örtskiktet regularly and use biomass as mulch around trees and shrubs.
<G-vec00057-001-s277><turn.drehen><de> So ist es Zeit zu gehen, um den Raum, drehen Sie die Kamera und entspannen Sie sich mit der Frau, die Sie am meisten genießen.
<G-vec00057-001-s277><turn.drehen><en> So there is the time to go to the room, turn to the camera and relax with the woman you enjoy most.
<G-vec00057-001-s278><turn.drehen><de> Wenn das Erbrechen beginnt, drehen Sie den ganzen Körper auf die Seite.
<G-vec00057-001-s278><turn.drehen><en> When vomiting begins, turn the whole body on its side.
<G-vec00057-001-s279><turn.drehen><de> Um die Fahrertür zu entriegeln, drehen Sie den Schlüssel in Öffnungsstellung -A- Abb.
<G-vec00057-001-s279><turn.drehen><en> To unlock the driver s door, turn the key to the unlock position -A- Fig.
<G-vec00057-001-s280><turn.drehen><de> Drehen Sie dann die Entfernungsskala so, dass die Schärfentiefenmarke für die weitere Entfernung für diesen Blendenwert an der Mitte des Unendlich-Symbols ausgerichtet ist.
<G-vec00057-001-s280><turn.drehen><en> Then turn the distance scale so that the farther depth of field mark for this aperture is aligned with the center of the infinity symbol.
<G-vec00057-001-s281><turn.drehen><de> InstantStorm - Drehen Sie Adobe Flash (SWF) -Dateien in Windows -Bildschirmschoner mit vielen Anpassungsmöglichkeiten.
<G-vec00057-001-s281><turn.drehen><en> InstantStorm - Turn Adobe Flash (SWF) files into Windows screensavers with many customization options. Contacts
<G-vec00057-001-s282><turn.drehen><de> Der Stecker und drehen Sie benötigen ein Loch zu bohren, in die ein Stift überspringen und Mutter Design sperren.
<G-vec00057-001-s282><turn.drehen><en> The plug and turn need to drill a hole into which a pin skip and lock nut design.
<G-vec00057-001-s283><turn.drehen><de> Lenco L82 | Drehen Sie Discs Lenco L82, eine Seite gewidmet dieser Plattenspieler hat Riemenantrieb Lenco.
<G-vec00057-001-s283><turn.drehen><en> Lenco L82 | Turn discs Lenco L82, a page dedicated to this record player has belt drive Lenco.
<G-vec00057-001-s284><turn.drehen><de> Um nach einem Kontakt auf der SD-Karte oder dem USB-Massenspeicher zu suchen, drehen Sie den Steuerungsknopf auf Kontakt suchen .
<G-vec00057-001-s284><turn.drehen><en> To search for a contact on an SD card or a USB mass storage device, turn the rotary pushbutton to Find contact .
<G-vec00057-001-s285><turn.drehen><de> """Beim Twist dreht man das etwas zurückgekippte Becken in einem Halbkreis über vorne hin und her."
<G-vec00057-001-s285><turn.drehen><en> """When dancing the Twist you turn the pelvis bent somewhat back in a semicircle to and fro."
<G-vec00057-001-s286><turn.drehen><de> Die Operation kann dünne, dreht, erweitern, verkürzen oder verlängern, und im Wesentlichen die Form der Nase.
<G-vec00057-001-s286><turn.drehen><en> The surgery can thin, turn up, augment, shorten or lengthen, and essentially change the shape of the nose.
<G-vec00057-001-s287><turn.drehen><de> Dreht man das Material um 180° erscheint die grüne Fläche plötzlich in purpur.
<G-vec00057-001-s287><turn.drehen><en> If you turn the material 180 degrees, the green colour suddenly glows in violet.
<G-vec00057-001-s288><turn.drehen><de> Auch K und P ähneln den entsprechenden Lautbild-Buchstaben, wenn man diesmal die senkrechten Striche entfernt und den Rest um 90 Grad dreht.
<G-vec00057-001-s288><turn.drehen><en> Also Latin K and P resemble the corresponding letters of our picture-writing, if you now remove the vertical lines and turn the result by 90 degrees.
<G-vec00057-001-s289><turn.drehen><de> Jetzt macht das gleiche mit der Statue nebenan: dreht sie, bis der Speer mit der Markierung übereinstimmt.
<G-vec00057-001-s289><turn.drehen><en> Now go over to the statue and turn it until its spear lines up with the marking on the floor.
<G-vec00057-001-s290><turn.drehen><de> Da dreht man durch wenn man in so einer Gegend unterwegs ist.
<G-vec00057-001-s290><turn.drehen><en> As you turn through if you are traveling in such an area.
<G-vec00057-001-s291><turn.drehen><de> Also dann, schenkt Euch ein Glas Tennessee Whiskey ein und dreht die Regler auf.
<G-vec00057-001-s291><turn.drehen><en> Grab yourself some Tennessee whiskey, pour a shot and turn up your stereo!
<G-vec00057-001-s292><turn.drehen><de> Wie wir bereits gesehen haben, dreht er, anstelle uns einfach zu sagen, mit dem Nähren an den Ansammlungen zu stoppen, diese in den Pfad: das gesunde Essen, daß Kraft für den Geist bis zu einem Punkt gibt, wo er nicht länger genährt werden muss.
<G-vec00057-001-s292><turn.drehen><en> As we've already seen, instead of telling you simply to stop feeding on the aggregates, he has you turn them into a path: the health food that gives strength to the mind to the point where it no longer needs to feed.
<G-vec00057-001-s293><turn.drehen><de> Dreht den Stamm in die gewünschte Position.
<G-vec00057-001-s293><turn.drehen><en> They turn the log into the desired position.
<G-vec00057-001-s294><turn.drehen><de> Wenn ihr ein Schlüssel seid, hängt von euch ab, ob jemand ein Verbrechen machen wird oder nicht.Wenn ihr euch dreht und ihm leuchtet, wird er die Möglichkeit haben, klar zu sehen und wird das Verbrechen begehen, wenn ihr euch nicht dreht, wird er nichts in der Dunkelheit sehen, und das Verbrechen ist verhindert.Die guten Leute sind Schlüssel.
<G-vec00057-001-s294><turn.drehen><en> If you are a key, it depends on you whether somebody commits a crime or not. If you turn around and bring light to him, he will have the opportunity to see clearly and he will commit the crime; if you do not turn around, he won't be able to see anything in the darkness and the crime will be avoided.
<G-vec00057-001-s295><turn.drehen><de> 3.The Anzeigelampe ist rot, wenn die Batterie nicht völlig aufgeladen wird; sie dreht Grün, nach völlig aufgeladen.
<G-vec00057-001-s295><turn.drehen><en> 3.The indicator light is red if the battery is not fully charged; it will turn green after fully charged.
<G-vec00057-001-s296><turn.drehen><de> 035 Es dreht sich nicht durch Wind, aber durch Wasser: Ein Wasserrad auf einem Dorfkanal.
<G-vec00057-001-s296><turn.drehen><en> 035 It doesn't turn in the wind but due to water: A water wheel at a village channel.
<G-vec00057-001-s297><turn.drehen><de> Für diejenigen, die es noch nie gemacht haben: Man nimmt die Krabbe und dreht mit Daumen und Zeigefinger die beiden Enden gegeneinander, bis die Schale an einem der „Gelenke“ durchtrennt ist.
<G-vec00057-001-s297><turn.drehen><en> For those who have never done it: Take the crab and turn the two ends together with your thumb and forefinger until the shell breaks at one of the joints.
<G-vec00057-001-s298><turn.drehen><de> Wenn die Kamera jedoch erlaubt, die ISO-Einstellung in einem bestimmten Bereich zu ändern, ist dies natürlich DIE Schraube, an der man zunächst dreht (bei DSLR- und Systemkameras kann man natürlich auch erst einmal das Objektiv wechseln, sofern ein lichtstarkes Objektiv zur Verfügung steht).
<G-vec00057-001-s298><turn.drehen><en> If the camera, however, allowed you to change the ISO setting in a particular mode, this is, of course, THE screw to turn first (with a DSLR or system camera, you can, of course, also change the lens first, if a fast one is available).
<G-vec00057-001-s299><turn.drehen><de> Auch mit Starthilfe dreht der Anlasser nur kurz.
<G-vec00057-001-s299><turn.drehen><en> With starting aid, the starter would only turn shortly.
<G-vec00057-001-s300><turn.drehen><de> Der Motor dreht sich nicht, wenn beide GPIOs eingeschaltet oder beide GPIOs ausgeschaltet sind.
<G-vec00057-001-s300><turn.drehen><en> "The motor doesn't turn whenever both GPIOs are turned ""on"" or both are turned ""off""."
<G-vec00057-001-s301><turn.drehen><de> Dieses Werk stellt die Intuition gegen den Intellekt infrage, da es immer diesen ersten Moment gibt, in dem wir uns in die Situation vertiefen und der uns zu der Frage bringt, warum unser Bildnis sich - nicht - dreht.
<G-vec00057-001-s301><turn.drehen><en> This work is tempting the intuition versus the intellect, since there is always this first moment of engagement, which makes you wonder why your image does - not - turn.
<G-vec00057-001-s302><turn.drehen><de> Noch einmal in Kürze: Tritt rechts: Schulter (Lenker) dreht rechts (zur Innenseite) - Hüfte (Sattel) dreht links (zur Außenseite).
<G-vec00057-001-s302><turn.drehen><en> In short: Push on right pedal – shoulder (handlebar) turns right – hips (saddle) turn left (and vice versa).
<G-vec00057-001-s303><turn.drehen><de> Wenn Sie sehr gut nicht mit Ihrem Geschäft tun und Sie sich ehrlich in die Bemühung setzen, lassen Sie mich erklären Ihnen, wie man Sachen herum dreht!Zuerst müssen Sie überprüfen, ob Sie das rechte Produkt haben....
<G-vec00057-001-s303><turn.drehen><en> If you're not doing VERY well with your business, and you're honestly putting in the effort, let me explain to you how to turn things around!First of all, you need to make sure that you have the right product.
<G-vec00245-003-s266><turn_up.drehen><de> Drehe die Zeit mit Titeln wie "Super Mario Land" und "Alleyway" von Nintendo und unabhängigen Entwicklern, die du sofort auf dein System herunterladen kannst.
<G-vec00245-003-s266><turn_up.drehen><en> Turn back the clock with titles like Super Mario Land and Alleyway! Nintendo DSiWare Your Nintendo 2DS system also plays Nintendo DSiWare games: exciting and innovative games and applications from Nintendo and independent developers that can be downloaded to your system in an instant.
<G-vec00245-003-s267><turn_up.drehen><de> Ich drehe Alla auf den Rücken, jetzt schwebt sie auf dem Rücken.
<G-vec00245-003-s267><turn_up.drehen><en> I turn Alla on her back, now she sails on her back.
<G-vec00245-003-s268><turn_up.drehen><de> Drehe den Bohrer weiter, um die Erde zu verdrängen.
<G-vec00245-003-s268><turn_up.drehen><en> Continue to turn the auger to displace the earth.
<G-vec00245-003-s269><turn_up.drehen><de> Drehe das Ei mit der Außenseite nach innen, setze es in das Huhn und nähe die beiden Teile an der Unterkante zusammen.
<G-vec00245-003-s269><turn_up.drehen><en> Turn the egg so the outside is inside, and put it inside the chicken. Sew together the bottom edges.
<G-vec00245-003-s270><turn_up.drehen><de> Ich drehe mich um, sehe zwei junge Frauen.
<G-vec00245-003-s270><turn_up.drehen><en> I turn round, see two young women.
<G-vec00245-003-s271><turn_up.drehen><de> Drehe deinen vorderen Fuß nach innen und rutsche mit einer rollenden Bewegung am Board nach oben.
<G-vec00245-003-s271><turn_up.drehen><en> Turn your front foot inward and slide up the front of the board in a rolling motion.
<G-vec00245-003-s272><turn_up.drehen><de> Ich halte an und drehe mich um.
<G-vec00245-003-s272><turn_up.drehen><en> I stop and turn around.
<G-vec00245-003-s273><turn_up.drehen><de> 1 Drehe deine Jeans vollständig auf links.
<G-vec00245-003-s273><turn_up.drehen><en> 1 Turn your jeans inside-out.
<G-vec00245-003-s274><turn_up.drehen><de> Drehe dein Snowboard so, dass Du senkrecht zum Hang des Berges bist.
<G-vec00245-003-s274><turn_up.drehen><en> Turn your snowboard so that you're perpendicular to the slope of the mountain.
<G-vec00245-003-s275><turn_up.drehen><de> Navigiere den Hubschrauber über den Container, um die Wasser-Elemente abzuwerfen, und drehe das Containerdach-Element, um das Feuer zu löschen.
<G-vec00245-003-s275><turn_up.drehen><en> Fly the helicopter over the container to release the water elements and turn the container roof element, putting out the fire.
<G-vec00245-003-s276><turn_up.drehen><de> Wenn das Eisgerät dann platziert ist, drehe ich die Hand wieder nach innen (Handrücken und Unterarm in einer Linie), um mich möglichst kraftsparend am Eisgerät festzuhalten.
<G-vec00245-003-s276><turn_up.drehen><en> If the ice tool is in place I turn the hand inside (the back of the hand is in line with the upper arm) in order to hold the tool more effective.
<G-vec00245-003-s277><turn_up.drehen><de> Drehe das "Sandwich" vertikal.
<G-vec00245-003-s277><turn_up.drehen><en> Turn the "sandwich" vertically.
<G-vec00245-003-s278><turn_up.drehen><de> Bruno Coudoin & Timothee Giet Beschreibung: Drehe die Karten um, so dass die Zahl mit dem passenden Wort übereinstimmt.
<G-vec00245-003-s278><turn_up.drehen><en> Bruno Coudoin & Timothee Giet Turn the cards over to match the number with the word matching it.
<G-vec00245-003-s279><turn_up.drehen><de> Drücke das Tuch oder den Wattebausch zur einfacheren Anwendung gegen die Öffnung der Flasche und drehe sie auf den Kopf, so dass ein kompakter Kreis durchtränkt wird, der ideal zum Schrubben ist.
<G-vec00245-003-s279><turn_up.drehen><en> For ease of application, press the cloth or cotton swab to the mouth of the alcohol bottle and turn it upside down, soaking a compact circle perfect for scrubbing.
<G-vec00245-003-s280><turn_up.drehen><de> Ich drehe und wende sie im Kopf herum und empfinde eine leichte Irritation, eine Reizung von Hirn und Lachmuskeln.
<G-vec00245-003-s280><turn_up.drehen><en> I turn them round and use them in my head, and feel a slight irritation, a stimulation of the brain and the laughter muscles.
<G-vec00245-003-s281><turn_up.drehen><de> Drehe den Beutel alle paar Stunden um, damit die Marinade gleichmäßig verteilt wird.
<G-vec00245-003-s281><turn_up.drehen><en> Massage and turn the bag over several times to ensure the meat is coated.
<G-vec00245-003-s282><turn_up.drehen><de> JB BUTET & Timothee Giet Beschreibung: Drehe die Karten um, so dass du zwei Karten findest, die die gleiche Summe ergeben, bis alle Karten verschwunden sind.
<G-vec00245-003-s282><turn_up.drehen><en> JB BUTET & Timothee Giet Description: Turn the cards over to find two numbers which add up the same, until all the cards are gone.
<G-vec00245-003-s283><turn_up.drehen><de> Drehe die Scheibe anschließend auf Schritt 2, 3 und 4.
<G-vec00245-003-s283><turn_up.drehen><en> Then turn the disc to steps 2, 3 and 4.
<G-vec00245-003-s284><turn_up.drehen><de> Ich stelle mich unter den Duschkopf, drehe das Wasser auf und befinde mich unter einem eiskalten Strahl, der einfach nicht wärmer werden will: Irgendetwas stimmt mit dem Durchlauferhitzer nicht.
<G-vec00245-003-s284><turn_up.drehen><en> I stand under the showerhead, turn on the tap, and – bam! – I’m hit by a stream of ice-cold water, which simply will not get any warmer.
<G-vec00283-003-s129><roll_over.drehen><de> Betrachten Sie 3D-Modelle aus verschiedenen Blickrichtungen oder drehen Sie sie interaktiv im dreidimensionalen Raum.
<G-vec00283-003-s129><roll_over.drehen><en> View 3D models from multiple viewpoints or roll them in 3D space interactively.
<G-vec00283-003-s130><roll_over.drehen><de> Eine Möglichkeit ist, eine Barrikade aus zusätzlichen Kissen um dich herum zu errichten, damit du dich nicht drehen kannst.
<G-vec00283-003-s130><roll_over.drehen><en> One option is to create a barricade around yourself with extra pillows so that you can't roll over.
<G-vec00283-003-s131><roll_over.drehen><de> •Wenn das Papier nicht gespannt ist, drehen Sie das Papier geringfügig zurück, um es zu spannen.
<G-vec00283-003-s131><roll_over.drehen><en> •If the paper is slack, roll back the paper slightly to remove the slack.
<G-vec00283-003-s132><roll_over.drehen><de> Denn in dieser Sekunde könnte es sich drehen und vom Tisch hinunterfallen.
<G-vec00283-003-s132><roll_over.drehen><en> Don't leave the child for even a second, because in that second they could roll off of the table.
<G-vec00283-003-s133><roll_over.drehen><de> In einem letzten Schritt die Platte nun durch die Clay-Maschine drehen.
<G-vec00283-003-s133><roll_over.drehen><en> The last step is to roll the sheet through the clay machine.
<G-vec00283-003-s134><roll_over.drehen><de> Wenn in einem Frame mehrere Bedienfelder vorhanden sind, positionieren Sie den Mauszeiger auf einer Registerkarte und drehen Sie das Mausrad vorwärts oder rückwärts, um das aktive Fenster zu wechseln.
<G-vec00283-003-s134><roll_over.drehen><en> If a frame contains multiple panels, place the pointer over a tab and roll the mouse scroll wheel forward or backward to change which panel is active.
<G-vec00283-003-s135><roll_over.drehen><de> Sie halten das Spiel am Laufen und geben die Karten, drehen das Rad und tun, was sonst für andere Spiele zu erwarten ist.
<G-vec00283-003-s135><roll_over.drehen><en> You keep the game going and deal cards, roll the wheels and everything there is to the different games.
<G-vec00283-003-s136><roll_over.drehen><de> Die kleine Aufschüttung sollte breiter als der Filter sein, da sie beim Drehen zusammengepresst wird.
<G-vec00283-003-s136><roll_over.drehen><en> The little mound should be broader than the filter because it will be compressed as you roll.
<G-vec00283-003-s137><roll_over.drehen><de> Je nach Geschmack kannst du eine dünnere oder dickere Zigarette drehen.
<G-vec00283-003-s137><roll_over.drehen><en> You can roll your cigarette thicker or thinner to taste.
<G-vec00283-003-s138><roll_over.drehen><de> Es wird versucht sich auf den Rücken zu drehen.
<G-vec00283-003-s138><roll_over.drehen><en> Trying to roll over on the back
<G-vec00283-003-s139><roll_over.drehen><de> Alle Rauch-Accessoires, die Du zum Drehen oder Anzünden brauchst, von King-Size-Blättern und Filter zu Grinders, Pfeifen, Brenner-Feuerzeuge und professionelles Aufbewahrungszubehör für ein sicheres Verstecken.
<G-vec00283-003-s139><roll_over.drehen><en> All the smoking accessories you need to roll or light up, from smoking papers and filter tips to grinders, pipes, lighters and so much more!
<G-vec00283-003-s140><roll_over.drehen><de> AXIS Q3617-VE bietet eine einzigartige Lösung: unsere neue PTRZ-Funktion (Schwenken/Neigen/Drehen/Zoomen).
<G-vec00283-003-s140><roll_over.drehen><en> AXIS Q3617-VE offers a unique solution: our new remote PTRZ pan/tilt/roll/zoom feature.
<G-vec00283-003-s141><roll_over.drehen><de> Dieses einfache arbeitssparende Gerät macht es viel leichter, Joints und Zigaretten zu drehen, wenn du nicht geschickt genug bist, um es von Hand zu machen.
<G-vec00283-003-s141><roll_over.drehen><en> This simple labor-saving device makes it much easier to roll joints and cigarettes if you don't have the dexterity to do it by hand.
<G-vec00283-003-s142><roll_over.drehen><de> Unsere Matratzen mit schützender Stützfunktion sind ideal für Babys geeignet, die auf dem Rücken schlafen und sich im Schlaf nicht drehen.
<G-vec00283-003-s142><roll_over.drehen><en> Our anti-rollover mattresses are ideal for ensuring that your baby sleeps on their back and does not roll over.
<G-vec00283-003-s143><roll_over.drehen><de> Dieses Taschenzubehör ist einfach genial, weil es alle Werkzeuge vereint, die die Kings benötigen, um ihre Joints zu drehen.
<G-vec00283-003-s143><roll_over.drehen><en> This pocket accessory is simply brilliant because it combines all the tools Kings need to roll their joints on the go.
<G-vec00283-003-s144><roll_over.drehen><de> Sei vorsichtig, wie viel Tabak (oder anderes Produkt) Du in die Mulde gibst, denn er KANN zu fest drehen.
<G-vec00283-003-s144><roll_over.drehen><en> Be wary of how much tobacco (or other product) you put in the trough as it CAN roll too tight.
<G-vec00309-003-s266><turn_out.drehen><de> Drehe die Zeit mit Titeln wie "Super Mario Land" und "Alleyway" von Nintendo und unabhängigen Entwicklern, die du sofort auf dein System herunterladen kannst.
<G-vec00309-003-s266><turn_out.drehen><en> Turn back the clock with titles like Super Mario Land and Alleyway! Nintendo DSiWare Your Nintendo 2DS system also plays Nintendo DSiWare games: exciting and innovative games and applications from Nintendo and independent developers that can be downloaded to your system in an instant.
<G-vec00309-003-s267><turn_out.drehen><de> Ich drehe Alla auf den Rücken, jetzt schwebt sie auf dem Rücken.
<G-vec00309-003-s267><turn_out.drehen><en> I turn Alla on her back, now she sails on her back.
<G-vec00309-003-s268><turn_out.drehen><de> Drehe den Bohrer weiter, um die Erde zu verdrängen.
<G-vec00309-003-s268><turn_out.drehen><en> Continue to turn the auger to displace the earth.
<G-vec00309-003-s269><turn_out.drehen><de> Drehe das Ei mit der Außenseite nach innen, setze es in das Huhn und nähe die beiden Teile an der Unterkante zusammen.
<G-vec00309-003-s269><turn_out.drehen><en> Turn the egg so the outside is inside, and put it inside the chicken. Sew together the bottom edges.
<G-vec00309-003-s270><turn_out.drehen><de> Ich drehe mich um, sehe zwei junge Frauen.
<G-vec00309-003-s270><turn_out.drehen><en> I turn round, see two young women.
<G-vec00309-003-s271><turn_out.drehen><de> Drehe deinen vorderen Fuß nach innen und rutsche mit einer rollenden Bewegung am Board nach oben.
<G-vec00309-003-s271><turn_out.drehen><en> Turn your front foot inward and slide up the front of the board in a rolling motion.
<G-vec00309-003-s272><turn_out.drehen><de> Ich halte an und drehe mich um.
<G-vec00309-003-s272><turn_out.drehen><en> I stop and turn around.
<G-vec00309-003-s273><turn_out.drehen><de> 1 Drehe deine Jeans vollständig auf links.
<G-vec00309-003-s273><turn_out.drehen><en> 1 Turn your jeans inside-out.
<G-vec00309-003-s274><turn_out.drehen><de> Drehe dein Snowboard so, dass Du senkrecht zum Hang des Berges bist.
<G-vec00309-003-s274><turn_out.drehen><en> Turn your snowboard so that you're perpendicular to the slope of the mountain.
<G-vec00309-003-s275><turn_out.drehen><de> Navigiere den Hubschrauber über den Container, um die Wasser-Elemente abzuwerfen, und drehe das Containerdach-Element, um das Feuer zu löschen.
<G-vec00309-003-s275><turn_out.drehen><en> Fly the helicopter over the container to release the water elements and turn the container roof element, putting out the fire.
<G-vec00309-003-s276><turn_out.drehen><de> Wenn das Eisgerät dann platziert ist, drehe ich die Hand wieder nach innen (Handrücken und Unterarm in einer Linie), um mich möglichst kraftsparend am Eisgerät festzuhalten.
<G-vec00309-003-s276><turn_out.drehen><en> If the ice tool is in place I turn the hand inside (the back of the hand is in line with the upper arm) in order to hold the tool more effective.
<G-vec00309-003-s277><turn_out.drehen><de> Drehe das "Sandwich" vertikal.
<G-vec00309-003-s277><turn_out.drehen><en> Turn the "sandwich" vertically.
<G-vec00309-003-s278><turn_out.drehen><de> Bruno Coudoin & Timothee Giet Beschreibung: Drehe die Karten um, so dass die Zahl mit dem passenden Wort übereinstimmt.
<G-vec00309-003-s278><turn_out.drehen><en> Bruno Coudoin & Timothee Giet Turn the cards over to match the number with the word matching it.
<G-vec00309-003-s279><turn_out.drehen><de> Drücke das Tuch oder den Wattebausch zur einfacheren Anwendung gegen die Öffnung der Flasche und drehe sie auf den Kopf, so dass ein kompakter Kreis durchtränkt wird, der ideal zum Schrubben ist.
<G-vec00309-003-s279><turn_out.drehen><en> For ease of application, press the cloth or cotton swab to the mouth of the alcohol bottle and turn it upside down, soaking a compact circle perfect for scrubbing.
<G-vec00309-003-s280><turn_out.drehen><de> Ich drehe und wende sie im Kopf herum und empfinde eine leichte Irritation, eine Reizung von Hirn und Lachmuskeln.
<G-vec00309-003-s280><turn_out.drehen><en> I turn them round and use them in my head, and feel a slight irritation, a stimulation of the brain and the laughter muscles.
<G-vec00309-003-s281><turn_out.drehen><de> Drehe den Beutel alle paar Stunden um, damit die Marinade gleichmäßig verteilt wird.
<G-vec00309-003-s281><turn_out.drehen><en> Massage and turn the bag over several times to ensure the meat is coated.
<G-vec00309-003-s282><turn_out.drehen><de> JB BUTET & Timothee Giet Beschreibung: Drehe die Karten um, so dass du zwei Karten findest, die die gleiche Summe ergeben, bis alle Karten verschwunden sind.
<G-vec00309-003-s282><turn_out.drehen><en> JB BUTET & Timothee Giet Description: Turn the cards over to find two numbers which add up the same, until all the cards are gone.
<G-vec00309-003-s283><turn_out.drehen><de> Drehe die Scheibe anschließend auf Schritt 2, 3 und 4.
<G-vec00309-003-s283><turn_out.drehen><en> Then turn the disc to steps 2, 3 and 4.
<G-vec00309-003-s284><turn_out.drehen><de> Ich stelle mich unter den Duschkopf, drehe das Wasser auf und befinde mich unter einem eiskalten Strahl, der einfach nicht wärmer werden will: Irgendetwas stimmt mit dem Durchlauferhitzer nicht.
<G-vec00309-003-s284><turn_out.drehen><en> I stand under the showerhead, turn on the tap, and – bam! – I’m hit by a stream of ice-cold water, which simply will not get any warmer.
<G-vec00331-003-s304><turn_out.drehen><de> Barhocker Drehen Sie den Tresen am Morgen in einen Esstisch und einen Frühstücksbereich, und entspannen Sie sich abends mit Getränken.
<G-vec00331-003-s304><turn_out.drehen><en> Bar chairs turn the counter into a dining table and a breakfast area in the morning, rest with drinks in the evening.
<G-vec00331-003-s305><turn_out.drehen><de> Drehen Sie einfach den Knopf, um den Flaschenwärmer einzuschalten, und wählen Sie die Aufwärmeinstellung.
<G-vec00331-003-s305><turn_out.drehen><en> Simply turn the knob to switch the baby bottle warmer on and select your warming setting.
<G-vec00331-003-s306><turn_out.drehen><de> 5.1 Ein- und Ausschalten des Geräts Drehen Sie den Backofen-Einstellknopf auf die gewünschte Funktion.
<G-vec00331-003-s306><turn_out.drehen><en> Turn the oven functions control knob to the desired function. 2.
<G-vec00331-003-s307><turn_out.drehen><de> Drehen Sie das Lenkrad bei stehendem Fahrzeug bis zum Anschlag nach links.
<G-vec00331-003-s307><turn_out.drehen><en> When the Audi Q5 is stationary turn the steering wheel to the left as far as it will go.
<G-vec00331-003-s308><turn_out.drehen><de> Drehen Sie den Steuerungsknopf auf Zeitformat und drücken Sie den Steuerungsknopf Abb.1.
<G-vec00331-003-s308><turn_out.drehen><en> Turn the rotary pushbutton to Time format and press the rotary pushbutton Fig. 1.
<G-vec00331-003-s309><turn_out.drehen><de> Drehen Sie den Wahlschalter, bis der Zeiger auf der Position zu stehen kommt.
<G-vec00331-003-s309><turn_out.drehen><en> Defrosting Turn the switch to the position .
<G-vec00331-003-s310><turn_out.drehen><de> Wenn einer der folgenden Zustände auftritt, nachdem die Fehlerursache beseitigt wurde, drehen Sie den schlüsselbetriebenen Netzschalter einmal auf [POWER ON] oder [OFF] und dann drehen Sie ihn wieder auf [LASER ON], um den Betrieb wieder aufzunehmen.
<G-vec00331-003-s310><turn_out.drehen><en> If one of the following states occurs, after removing the cause of the error, turn the key-operated power switch back to [POWER ON] or [OFF] once, and then turn it to [LASER ON] again to recover operations.
<G-vec00331-003-s312><turn_out.drehen><de> Um ein Album zu wählen, drehen Sie den Steuerungsknopf auf das gewünschte Album-Cover und drücken Sie den Steuerungsknopf.
<G-vec00331-003-s312><turn_out.drehen><en> To select an album, turn the rotary pushbutton to mark the desired album cover and press the rotary pushbutton.
<G-vec00331-003-s313><turn_out.drehen><de> 7 Drehen Sie den SELECT-Knopf, drücken Sie die CURSOR F- oder G-Taste, um die Parametereinstellungen vorzunehmen.
<G-vec00331-003-s313><turn_out.drehen><en> 7 8 Turn the SELECT knob, and press the CURSOR F or G button to adjust the parameter settings.
<G-vec00331-003-s314><turn_out.drehen><de> Beschreibung: Drehen Sie gescannte Dokumente in editierbaren Text.
<G-vec00331-003-s314><turn_out.drehen><en> Beschreibung: Turn screenshots into editable documents.
<G-vec00331-003-s315><turn_out.drehen><de> Drehen Sie Ihren empfindlichen OLED-Bildschirm je nach Blickwinkel in die perfekte Position, gleichmäßig und ruckfrei.
<G-vec00331-003-s315><turn_out.drehen><en> Smoothly turn your fragile OLED screen to the perfect viewing angle.
<G-vec00331-003-s316><turn_out.drehen><de> Drücken Sie Control+T und mit der Taste Shift drehen Sie sich ergebend auf 45 Grad um.
<G-vec00331-003-s316><turn_out.drehen><en> Press Control+T and with key Shift turn turned out on 45 degrees.
<G-vec00331-003-s317><turn_out.drehen><de> Drehen Sie den Wahlschalter im Uhrzeigersinn oder entgegen, um das gewünschte Trockenprogramm auszuwählen.
<G-vec00331-003-s317><turn_out.drehen><en> Turn the selector clockwise or anti-clockwise to select the required drying program.
<G-vec00331-003-s318><turn_out.drehen><de> Drehen Sie den Regler 6 auf „OFF“, um das System auszuschalten.
<G-vec00331-003-s318><turn_out.drehen><en> Turn the control 6 to “OFF” to stop the system.
<G-vec00331-003-s319><turn_out.drehen><de> Zum Ausschalten des Geräts drehen Sie die Schalter für die Ofenfunktionen und die Temperatur auf Aus.
<G-vec00331-003-s319><turn_out.drehen><en> To turn the oven off, turn the oven functions dial and the temperature selector to the Off position.
<G-vec00331-003-s320><turn_out.drehen><de> Um die Kindersicherung einzuschalten, drehen Sie den Notschlüssel in Pfeilrichtung Abb.
<G-vec00331-003-s320><turn_out.drehen><en> To activate the child-proof catch, turn the emergency key in the direction of the arrow Fig.
<G-vec00331-003-s321><turn_out.drehen><de> Drehen Sie den Drehteller, während Sie den Arretierhebel niederdrücken.
<G-vec00331-003-s321><turn_out.drehen><en> Turn the turn base while pressing down the latch spring.
<G-vec00331-003-s322><turn_out.drehen><de> Drehen Sie den Verstärker auf maximale Leistung, und reduzieren Sie sie dann je nach Bedarf.
<G-vec00331-003-s322><turn_out.drehen><en> Turn the amplifier up to the max position and then reduce as needed.
<G-vec00342-003-s129><roll_out.drehen><de> Betrachten Sie 3D-Modelle aus verschiedenen Blickrichtungen oder drehen Sie sie interaktiv im dreidimensionalen Raum.
<G-vec00342-003-s129><roll_out.drehen><en> View 3D models from multiple viewpoints or roll them in 3D space interactively.
<G-vec00342-003-s130><roll_out.drehen><de> Eine Möglichkeit ist, eine Barrikade aus zusätzlichen Kissen um dich herum zu errichten, damit du dich nicht drehen kannst.
<G-vec00342-003-s130><roll_out.drehen><en> One option is to create a barricade around yourself with extra pillows so that you can't roll over.
<G-vec00342-003-s131><roll_out.drehen><de> •Wenn das Papier nicht gespannt ist, drehen Sie das Papier geringfügig zurück, um es zu spannen.
<G-vec00342-003-s131><roll_out.drehen><en> •If the paper is slack, roll back the paper slightly to remove the slack.
<G-vec00342-003-s132><roll_out.drehen><de> Denn in dieser Sekunde könnte es sich drehen und vom Tisch hinunterfallen.
<G-vec00342-003-s132><roll_out.drehen><en> Don't leave the child for even a second, because in that second they could roll off of the table.
<G-vec00342-003-s133><roll_out.drehen><de> In einem letzten Schritt die Platte nun durch die Clay-Maschine drehen.
<G-vec00342-003-s133><roll_out.drehen><en> The last step is to roll the sheet through the clay machine.
<G-vec00342-003-s134><roll_out.drehen><de> Wenn in einem Frame mehrere Bedienfelder vorhanden sind, positionieren Sie den Mauszeiger auf einer Registerkarte und drehen Sie das Mausrad vorwärts oder rückwärts, um das aktive Fenster zu wechseln.
<G-vec00342-003-s134><roll_out.drehen><en> If a frame contains multiple panels, place the pointer over a tab and roll the mouse scroll wheel forward or backward to change which panel is active.
<G-vec00342-003-s135><roll_out.drehen><de> Sie halten das Spiel am Laufen und geben die Karten, drehen das Rad und tun, was sonst für andere Spiele zu erwarten ist.
<G-vec00342-003-s135><roll_out.drehen><en> You keep the game going and deal cards, roll the wheels and everything there is to the different games.
<G-vec00342-003-s136><roll_out.drehen><de> Die kleine Aufschüttung sollte breiter als der Filter sein, da sie beim Drehen zusammengepresst wird.
<G-vec00342-003-s136><roll_out.drehen><en> The little mound should be broader than the filter because it will be compressed as you roll.
<G-vec00342-003-s137><roll_out.drehen><de> Je nach Geschmack kannst du eine dünnere oder dickere Zigarette drehen.
<G-vec00342-003-s137><roll_out.drehen><en> You can roll your cigarette thicker or thinner to taste.
<G-vec00342-003-s138><roll_out.drehen><de> Es wird versucht sich auf den Rücken zu drehen.
<G-vec00342-003-s138><roll_out.drehen><en> Trying to roll over on the back
<G-vec00342-003-s139><roll_out.drehen><de> Alle Rauch-Accessoires, die Du zum Drehen oder Anzünden brauchst, von King-Size-Blättern und Filter zu Grinders, Pfeifen, Brenner-Feuerzeuge und professionelles Aufbewahrungszubehör für ein sicheres Verstecken.
<G-vec00342-003-s139><roll_out.drehen><en> All the smoking accessories you need to roll or light up, from smoking papers and filter tips to grinders, pipes, lighters and so much more!
<G-vec00342-003-s140><roll_out.drehen><de> AXIS Q3617-VE bietet eine einzigartige Lösung: unsere neue PTRZ-Funktion (Schwenken/Neigen/Drehen/Zoomen).
<G-vec00342-003-s140><roll_out.drehen><en> AXIS Q3617-VE offers a unique solution: our new remote PTRZ pan/tilt/roll/zoom feature.
<G-vec00342-003-s141><roll_out.drehen><de> Dieses einfache arbeitssparende Gerät macht es viel leichter, Joints und Zigaretten zu drehen, wenn du nicht geschickt genug bist, um es von Hand zu machen.
<G-vec00342-003-s141><roll_out.drehen><en> This simple labor-saving device makes it much easier to roll joints and cigarettes if you don't have the dexterity to do it by hand.
<G-vec00342-003-s142><roll_out.drehen><de> Unsere Matratzen mit schützender Stützfunktion sind ideal für Babys geeignet, die auf dem Rücken schlafen und sich im Schlaf nicht drehen.
<G-vec00342-003-s142><roll_out.drehen><en> Our anti-rollover mattresses are ideal for ensuring that your baby sleeps on their back and does not roll over.
<G-vec00342-003-s143><roll_out.drehen><de> Dieses Taschenzubehör ist einfach genial, weil es alle Werkzeuge vereint, die die Kings benötigen, um ihre Joints zu drehen.
<G-vec00342-003-s143><roll_out.drehen><en> This pocket accessory is simply brilliant because it combines all the tools Kings need to roll their joints on the go.
<G-vec00342-003-s144><roll_out.drehen><de> Sei vorsichtig, wie viel Tabak (oder anderes Produkt) Du in die Mulde gibst, denn er KANN zu fest drehen.
<G-vec00342-003-s144><roll_out.drehen><en> Be wary of how much tobacco (or other product) you put in the trough as it CAN roll too tight.
