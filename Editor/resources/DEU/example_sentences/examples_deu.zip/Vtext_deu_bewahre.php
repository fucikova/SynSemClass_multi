<G-vec00367-001-s029><forbid.bewahre><de> "Dank dieser Vorkehrung wird die Arbeit nicht wiederholen müssen oder ""Gott bewahre"" ein Stück Mauerwerk zu ersetzen."
<G-vec00367-001-s029><forbid.bewahre><en> "Thanks to this precaution will not have to redo the work or ""God forbid"" to replace a piece of masonry."
<G-vec00367-001-s030><forbid.bewahre><de> Und Gott bewahre, Komplimente sind nur ein Standardsatz von Standardphrasen...
<G-vec00367-001-s030><forbid.bewahre><en> And God forbid, compliments will be just a standard set of stock phrases...
<G-vec00367-001-s031><forbid.bewahre><de> Jeder Krieg, und - Gott bewahre - vielleicht gar ein Atomkrieg, setzt eine Kette unvorhersehbarer Ereignisse in Gang.
<G-vec00367-001-s031><forbid.bewahre><en> Any war, and - god forbid - perhaps even a nuclear war will set in motion an unpredictable chain of events.
<G-vec00367-001-s032><forbid.bewahre><de> Heilern fühlen, ihre Hände, gibt es Heiler, und Gott bewahre, dass Sie einen hätten, aber es ist nicht professionell.
<G-vec00367-001-s032><forbid.bewahre><en> Healers feel their hands, there are healers, and God forbid that you had one, but it’s not professional.
<G-vec00367-001-s033><forbid.bewahre><de> Die Anhaftung der Amerikaner an die Fiktion einer repräsentierenden Regierung, oder – Gott bewahre, einer Demokratie –, hat ihre Fähigkeit vernebelt, die Gesellschaft als das zu sehen, was sie ist: eine Oligarchie, die die Formen der Demokratie ausnutzt, um der Öffentlichkeit zu gefallen und sie abzulenken.
<G-vec00367-001-s033><forbid.bewahre><en> The attachment of Americans to the fiction of a representative government, or — God forbid — a democracy, has clouded their ability to see their society for what it is: an oligarchy that uses the forms of democracy to appease and distract the public.
<G-vec00367-001-s034><forbid.bewahre><de> Gott bewahre, wird die Infektion, und andere...
<G-vec00367-001-s034><forbid.bewahre><en> God forbid, will get the infection, and others...
<G-vec00367-001-s035><forbid.bewahre><de> Gott bewahre, in 3-4 Monaten wird es passieren, und dann ist es schwer zu glauben.
<G-vec00367-001-s035><forbid.bewahre><en> God forbid, in 3-4 months it will happen, and then it's hard to believe.
<G-vec00367-001-s036><forbid.bewahre><de> Jibril: Ja, ich gebe zu, dass ich stolz bin, und ich bat Gott, alle diese, aber ich tat es nicht Ohrdah, Gott bewahre, ist derjenige, der sagt etwas zu sein!.
<G-vec00367-001-s036><forbid.bewahre><en> Gabriel: Yes, I admit that I am proud and I asked God to all of these, but I did not Ohrdah, God forbid, is the one who says something to Be!.
<G-vec00367-001-s037><forbid.bewahre><de> Nach dem Unfall begann mein Mann mich als Satanist zu brandmarken, etwas was ich nicht bin -Gott bewahre, da ich an Gott glaube und ihn verehre.
<G-vec00367-001-s037><forbid.bewahre><en> After the accident my husband started to brand me as Satanist, something I am not - heaven forbid for I believe and worship God.
<G-vec00367-001-s038><forbid.bewahre><de> Gott bewahre, schwingt Arm oder ein Bein aus dem Bett in der Nacht, bedeutet dies den sicheren Tod.
<G-vec00367-001-s038><forbid.bewahre><en> God forbid, swinging arm or a leg out of bed at night, it means certain death.
<G-vec00367-001-s039><forbid.bewahre><de> Nicht, dass ich euch 'splitternackt' herumlaufen sehe... Gott bewahre!...
<G-vec00367-001-s039><forbid.bewahre><en> Not that I see you going around 'starkers'... heaven forbid!...
<G-vec00367-001-s040><forbid.bewahre><de> "In einem Text über die 70er Jahre bemerkt Lucy Lippard: ""Wenn jemand zu einem sagte, 'Du malst wie ein Mann', so sollte man darüber glücklich sein, und man war es auch, denn man wusste, dass man wenigstens neutrale Kunst machte, anstatt - Gott bewahre - feminine Kunst."
<G-vec00367-001-s040><forbid.bewahre><en> "Writing about the '70s, Lucy Lippard noted: ""When somebody said 'You paint like a man,' you were supposed to be happy, and you were happy, because you knew you were at least making neutral art instead of feminine art - god forbid."""
<G-vec00367-001-s041><forbid.bewahre><de> "Gott bewahre, dass der Preis für eine Zinn-Medaille bezahlt hat auf der Haut der Märtyrer und die verfolgten Katholiken in China bezahlt worden, zu denen unter anderem, wenn Sie nicht nehmen, ernsthaft die Anfälligkeit der kommunistischen Regierung reizen und Atheisten, Sie können sie sich nicht einmal als ""Märtyrer"" und ""verfolgt"", Gerade weil würde es die Verfolger grob beleidigend sein, mit denen man eine Vereinbarung und Verfolgung werden zunehmend."
<G-vec00367-001-s041><forbid.bewahre><en> "God forbid that the price paid for a tin medal has been paid on the skin of the martyrs and the persecuted Catholics in China, to which inter alia, if you do not take seriously irritate the susceptibility of the Communist government and an atheist, you can not even turn to them as ""martyrs"" and ""persecuted"", precisely because it would be grossly offensive to the persecutors with whom you made an agreement and persecution are increasingly being."
<G-vec00367-001-s042><forbid.bewahre><de> Jetzt ist es möglich, dass sie härter Akt ist, Gott bewahre - ist grausam, besonders wenn ein Teil der Besatzung der erbeuteten Schiffe werden die Russen sein.
<G-vec00367-001-s042><forbid.bewahre><en> Now it is possible that they will act more harshly, God forbid - is cruel, especially if part of the crew of the captured ships will be the Russians.
<G-vec00367-001-s043><forbid.bewahre><de> Jibril: Ich bitte um Vergebung von Gott, der Allmächtige, Gott bewahre.
<G-vec00367-001-s043><forbid.bewahre><en> Gabriel: I ask forgiveness from God Almighty, God forbid.
<G-vec00367-001-s044><forbid.bewahre><de> Gott bewahre, dass die Gläubigen in der katholischen Kirche das Gefühl etwas.
<G-vec00367-001-s044><forbid.bewahre><en> God forbid that the faithful in the Church feel something Catholic.
<G-vec00367-001-s045><forbid.bewahre><de> Nein, Gott bewahre.
<G-vec00367-001-s045><forbid.bewahre><en> No, God forbid!
