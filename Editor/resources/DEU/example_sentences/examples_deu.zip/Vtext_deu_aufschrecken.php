<G-vec00251-003-s079><scare_away.aufschrecken><de> Sofern nicht anders angegeben, müssen Hunde jedoch immer angeleint sein, da freilaufende Hunde die Wildtiere aufschrecken könnten.
<G-vec00251-003-s079><scare_away.aufschrecken><en> Unless otherwise indicated, the dog must be kept on a leash as stray dogs can scare the wildlife.
<G-vec00251-003-s079><scare_off.aufschrecken><de> Sofern nicht anders angegeben, müssen Hunde jedoch immer angeleint sein, da freilaufende Hunde die Wildtiere aufschrecken könnten.
<G-vec00251-003-s079><scare_off.aufschrecken><en> Unless otherwise indicated, the dog must be kept on a leash as stray dogs can scare the wildlife.
<G-vec00761-002-s079><scare.aufschrecken><de> Sofern nicht anders angegeben, müssen Hunde jedoch immer angeleint sein, da freilaufende Hunde die Wildtiere aufschrecken könnten.
<G-vec00761-002-s079><scare.aufschrecken><en> Unless otherwise indicated, the dog must be kept on a leash as stray dogs can scare the wildlife.
