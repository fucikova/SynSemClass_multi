<G-vec00092-001-s019><insist.bestehen><de> "Als [ehrliches Geschäft, Qualität zuerst ""ist der Grundsatz, auf den wir bestehen."
<G-vec00092-001-s019><insist.bestehen><en> "As [Honest business, quality first"" is the tenet we insist."
<G-vec00092-001-s020><insist.bestehen><de> Männliche Leser werden eine Theorie finden, die Männern nicht auf simplifizierende Weise die Schuld zuschiebt, die allerdings auch nicht davor zurückschreckt, das Patriarchat zu entblößen und auf individuelle moralische Verantwortlichkeit wie auf systematische Veränderung zu bestehen.
<G-vec00092-001-s020><insist.bestehen><en> Male readers will find a theory that doesn't blame men simplistically yet doesn't flinch to dissect patriarchy and insist on individual moral responsibility as well as on systemic change.
<G-vec00092-001-s021><insist.bestehen><de> Lufttrocknung: Das Armband nimmt seine selbstklebende Oberfläche wieder auf und besteht auf wiederholter Trocknung.
<G-vec00092-001-s021><insist.bestehen><en> Air drying: Wrist Band will resume its self adhesive surface and insist on repeated drying.
<G-vec00092-001-s022><insist.bestehen><de> "Die Durchsetzung der meisten Gesetze ist mehr oder weniger willkürlich und die Entschlossenheit, mit der ein/e ""GesetzesbrecherIn"" verfolgt wird oder nicht, hängt von der Größe des Eigentums ab, das er/sie auf die Seite geschafft hat oder davon, wie sehr er/sie auf der Politisierung der eigenen Handlung besteht."
<G-vec00092-001-s022><insist.bestehen><en> "Enforcement of most laws is more or less discretionary and the determination of whether or not a ""violator"" will be prosecuted turns on the amount of property they are diverting, or how much they insist on politicizing their own actions."
<G-vec00092-001-s023><insist.bestehen><de> Es ist ausschlaggebend, dass die EU auf die Erfüllung dieser und anderer Bedingungen besteht, die in dieser Unterlage aufgezeigt sind.
<G-vec00092-001-s023><insist.bestehen><en> It is vital that the EU insist that Israel fulfil these, and the other obligations, that are set out in this submission.
<G-vec00206-001-s038><comprise.bestehen><de> Jede Einheit wird aus einer Stammaktie und einem halben Stammaktien-Kaufwarrant bestehen .
<G-vec00206-001-s038><comprise.bestehen><en> Each unit will comprise one common share and one-half common share purchase warrant.
<G-vec00206-001-s039><comprise.bestehen><de> Künftig werden jährlich bis zu 24 Mitarbeiter aus chinesischen und europäischen Organisationen an diesem Programm teilnehmen, das weiterhin aus den beiden ursprünglichen inhaltlichen Säulen bestehen wird.
<G-vec00206-001-s039><comprise.bestehen><en> In future, up to 24 employees from Chinese and European organizations will take part in this programme each year, which will continue to comprise its two original constituent parts.
<G-vec00206-001-s040><comprise.bestehen><de> Nun, wenn etwas in Enigma verlängert oder verkürzt werden sollte, dann musste es aus mehreren Teilen bestehen, so wie Puzzle-Stücke.
<G-vec00206-001-s040><comprise.bestehen><en> Well, when something in Enigma was to be lengthend or shortened, then it has to comprise of multiple parts, like puzzle stones.
<G-vec00206-001-s041><comprise.bestehen><de> Seine Antworten sollten aus Material aus dem Internet bestehen.
<G-vec00206-001-s041><comprise.bestehen><en> Its answers would comprise material drawn from the Internet.
<G-vec00206-001-s042><comprise.bestehen><de> Die Lose können aus einem oder mehreren Gegenständen bestehen.
<G-vec00206-001-s042><comprise.bestehen><en> The philatelic lots may comprise of one or more items.
<G-vec00206-001-s043><comprise.bestehen><de> Die Gruppe soll aus Experten bestehen, die zur Implementierung von Bildungsprojekten für die Integration von kamerunischen Studierenden und Fachkräften in Deutschland (VKII-Academy) engagieren werden .
<G-vec00206-001-s043><comprise.bestehen><en> This team will comprise of experts, who will be responsible for the implementation of projects to boost the integration of Cameroonian students and specialized personnel in Germany.
<G-vec00206-001-s044><comprise.bestehen><de> Es kann aus Dateien verschiedener Dateitypen einschließlich Videos bestehen.
<G-vec00206-001-s044><comprise.bestehen><en> It can comprise of files of various file types including videos.
<G-vec00206-001-s045><comprise.bestehen><de> Ein Gutachten muss aus einer schriftlichen Stellungnahme bestehen, wobei die GutachterInnen gebeten werden, auf vorgegebene Fragen zu antworten.
<G-vec00206-001-s045><comprise.bestehen><en> A review must comprise a written statement in which the reviewers are asked to address specific questions in relation to the proposal.
<G-vec00206-001-s046><comprise.bestehen><de> Die teilnehmenden Forschungsgruppen müssen aus mindestens vier Gesuchstelleenden aus vier verschiedenen HERA-Partnerländern bestehen.
<G-vec00206-001-s046><comprise.bestehen><en> Each consortium must comprise at least four applicants from four different HERA partner countries.
<G-vec00206-001-s047><comprise.bestehen><de> Die Konstellation wird aus 24 in drei Ebenen angeordneten operativen Satelliten plus Reservesatelliten bestehen.
<G-vec00206-001-s047><comprise.bestehen><en> The entire constellation will comprise 24 operational satellites plus spares in three orbital planes.
<G-vec00206-001-s048><comprise.bestehen><de> Immunglobuline sind Polypeptide, die aus fünf Hauptklassen bestehen: Immunglobulin G (IgG), IgA, IgM, IgD und IgE.
<G-vec00206-001-s048><comprise.bestehen><en> Immunoglobulins are polypeptides and comprise five major classes; immunoglobulin G (IgG), IgA, IgM, IgD and IgE.
<G-vec00206-001-s049><comprise.bestehen><de> Das Audionetz wird aus einem NEXUS STAR und 16 sternförmig angeschlossenen NEXUS-Basisgeräten bestehen.
<G-vec00206-001-s049><comprise.bestehen><en> The audio network will comprise a NEXUS STAR plus 16 NEXUS Base Devices connected in a star topology.
<G-vec00206-001-s050><comprise.bestehen><de> Die Struktur des auf diese Weise entstandenen Lochs in der Zellmembran ähnelt dabei einer Krone, deren Zacken aus 40 Untereinheiten der beiden zusammenarbeitenden Partner bestehen.
<G-vec00206-001-s050><comprise.bestehen><en> The structure of the resulting hole in the cell membrane resembles a crown, whose teeth comprise 40 subunits of the two interacting partners.
<G-vec00206-001-s051><comprise.bestehen><de> 1989 wurde eine private Stiftung gegrÃ1⁄4ndet, deren Mitglieder aus dem Kanton Tessin, dem Gemeinderat von Ascona und der ETH bestehen.
<G-vec00206-001-s051><comprise.bestehen><en> In 1989 a private foundation (Monte VeritÃ Foundation) was established whose members comprise the Canton Ticino, the Town Council of Ascona and the Swiss Federal Institute of Technology.
<G-vec00206-001-s052><comprise.bestehen><de> "Das Partnerinstitut soll aus drei Abteilungen und mehreren Nachwuchsgruppen bestehen und rechtlich wie administrativ in den Campus der ""Shanghai Institutes of Biological Sciences"" (SIBS) der Chinesischen Akademie der Wissenschaften (CAS) integriert werden."
<G-vec00206-001-s052><comprise.bestehen><en> The Partner Institute will comprise three departments and several junior research groups, and will be legally and administratively integrated into the campus of the Shanghai Institutes for Biological Sciences (SIBS) of the Chinese Academy of Sciences (CAS).
<G-vec00206-001-s053><comprise.bestehen><de> "Die Touristen bewohnen vorwiegend Anlagen, ""Urbanisationen"" genannt, die typisch für Costa del Silencio sind und aus zwischen 100 und 400 Appartements bestehen."
<G-vec00206-001-s053><comprise.bestehen><en> "The tourists inhabit predominantly, called ""Urbanisations"", which are typical for Costa del Silencio and comprise a toal of 100 to 400 apartments."
<G-vec00206-001-s054><comprise.bestehen><de> Es wird in der Endphase aus mehr als hundert über Holland, Deutschland und weitere europäische Länder verteilte Antennenfelder bestehen.
<G-vec00206-001-s054><comprise.bestehen><en> In the final stage it will comprise more than hundred antenna field distributed over Netherlands, Germany and further European countries.
<G-vec00206-001-s056><comprise.bestehen><de> "Jede Einheit wird aus einer Stammaktie und einem Aktien- Warrant (ein ""Warrant"") bestehen ."
<G-vec00206-001-s056><comprise.bestehen><en> "Each unit will comprise of one common share and one share purchase warrant (a ""Warrant"")."
<G-vec00206-001-s057><comprise.bestehen><de> Im Detail muss man da sicher manchmal nachfragen, ob nur Namen ausgetauscht wurden, aber für viele Leute sind Türen geöffnet worden, sodass andere Arbeiten möglich geworden sind und heute eingesehen wird, dass der Geist nicht nur aus Geist besteht.
<G-vec00206-001-s057><comprise.bestehen><en> Looking more closely, you sometimes have to ask whether just the names have been switched, but for many people, doors have opened to make other work possible. Today it can be seen that the humanities comprise more than just spirit.
<G-vec00206-001-s058><comprise.bestehen><de> Denn das Italicum gilt nur für die Abgeordnetenkammer, da es in der Annahme verabschiedet wurde, dass der Senat künftig aus regionalen und lokalen Vertretern besteht.
<G-vec00206-001-s058><comprise.bestehen><en> The Italicum applies only to the Chamber of Deputies as it was passed on the assumption that the Senate would in future comprise regional and local representatives.
<G-vec00206-001-s059><comprise.bestehen><de> Wenn ihr Wasser kocht, beschleunigen sich die Moleküle aus, denen das Wasser besteht (die durch die Bindung von atomaren Wasserstoff und Sauerstoff aufgebaut sind).
<G-vec00206-001-s059><comprise.bestehen><en> When you boil water, the molecules that comprise the water (which are made from the bonding of atomic hydrogen and oxygen) speed up.
<G-vec00206-001-s060><comprise.bestehen><de> Die Gemeinschaften, aus denen die Gemeinde besteht, müssen nicht homogen sein, aber in ihnen erfahren die Männer und die Frauen, die Fremden und die Einheimischen, die Lohnempfänger und die Arbeitslosen, was Versöhnung bedeutet.
<G-vec00206-001-s060><comprise.bestehen><en> The church will comprise communities which are not homogeneous but in which men and women, foreigners and nationals, waged and unwaged, old and young experience something of what reconciliation means.
<G-vec00206-001-s061><comprise.bestehen><de> Kants grundlegende Einsicht besagt, dass die Revolution nicht aus den Taten der Revolutionäre besteht.
<G-vec00206-001-s061><comprise.bestehen><en> Kant’s fundamental insight implies that the actions of the revolutionaries do not comprise a revolution.
<G-vec00206-001-s062><comprise.bestehen><de> Vinaya Die klösterliche Disziplin, deren Regeln und Tradition aus sechs Bänden gedrucktem Text besteht.
<G-vec00206-001-s062><comprise.bestehen><en> Vinaya The monastic discipline, whose rules and traditions comprise six volumes in printed text.
<G-vec00206-001-s063><comprise.bestehen><de> • Quarz ist ein Material, das aus Mineralien und Harz besteht und das Aussehen von Stein nachahmt, nur weitaus robuster.
<G-vec00206-001-s063><comprise.bestehen><en> • Quartz is a material comprise of minerals and resin and mimics the look of stone, only far more robust.
<G-vec00092-001-s066><insist.bestehen><de> Wenn sich unter verschiedenen Umständen eine Intervention zu diesem Thema - wobei man auch den Wert der Einsichten des Doctor Angelicus bekräftigte und auf der Aneignung seines Denkens bestand - als notwendig erwies, so hatte das seinen Grund darin, daß die Weisungen des Lehramtes nicht immer mit der erwünschten Bereitschaft befolgt worden sind.
<G-vec00092-001-s066><insist.bestehen><en> If it has been necessary from time to time to intervene on this question, to reiterate the value of the Angelic Doctor's insights and insist on the study of his thought, this has been because the Magisterium's directives have not always been followed with the readiness one would wish.
<G-vec00092-001-s067><insist.bestehen><de> Wenn sich unter verschiedenen Umständen eine Intervention zu diesem Thema — wobei man auch den Wert der Einsichten des Doctor Angelicus bekräftigte und auf der Aneignung seines Denkens bestand — als notwendig erwies, so hatte das seinen Grund darin, daß die Weisungen des Lehramtes nicht immer mit der erwünschten Bereitschaft befolgt worden sind.
<G-vec00092-001-s067><insist.bestehen><en> If it has been necessary from time to time to intervene on this question, to reiterate the value of the Angelic Doctor's insights and insist on the study of his thought, this has been because the Magisterium's directives have not always been followed with the readiness one would wish.
<G-vec00092-001-s068><insist.bestehen><de> Damals bestand Sokolnikow nicht auf seinem Vorschlag.
<G-vec00092-001-s068><insist.bestehen><en> At that time Sokolnikov did not insist on his proposal.
<G-vec00092-001-s069><insist.bestehen><de> Und ich bestand nicht.
<G-vec00092-001-s069><insist.bestehen><en> And I also did not insist.
<G-vec00092-001-s070><insist.bestehen><de> "In der offiziellen Sprachregelung bestand die bisherige Regierung aber weiterhin darauf, dass es sich bei den Verhafteten um ""terroristische Einzeltäter"", aber keineswegs um ""islamische militante Gewalttäter"" handele."
<G-vec00092-001-s070><insist.bestehen><en> "In the official instruction as to the wording to be used the previous government continued however to insist that the persons under arrest were individual ""terrorist culprits"", but by no means ""Islamist militant criminals""."
<G-vec00092-001-s071><insist.bestehen><de> Sie bestand darauf, den Buddhismus zu praktizieren, um in die Religion einzutreten.
<G-vec00092-001-s071><insist.bestehen><en> She insist to practice Buddhism to enter religion.
<G-vec00092-001-s072><insist.bestehen><de> Foucault bestand darauf, dass seine Kritik an den Institutionen keine paralysierende sei, und dass sie auf keinen wesentlichen Raum der Freiheit verweist, denn die Einübung in die Freiheit und das Experimentieren durch die Konstruktion seiner selbst läßt sich nur innerhalb der gegebenen Machtbeziehungen erproben.
<G-vec00092-001-s072><insist.bestehen><en> Foucault would insist that his critique of institutions should not have a paralysing effect, and that it didn't refer to an idea of essential freedom, because attempts at constructing freedom and the enjoyment of freedom itself could only take place inside given power relations.
<G-vec00092-001-s073><insist.bestehen><de> Doch obwohl der Bhikkhu Sāti, der Sohn eines Fischers, auf diese Weise von jenen Bhikkhus gedrängt, befragt und ins Kreuzverhör genommen wurde, blieb er stur bei jener schädlichen Ansicht und bestand weiterhin darauf.
<G-vec00092-001-s073><insist.bestehen><en> Yet although pressed and questioned and cross-questioned by those bhikkhus in this way, the bhikkhu Sāti, son of a fisherman, still obstinately adhered to that pernicious view and continued to insist upon it.
<G-vec00092-001-s074><insist.bestehen><de> "Er behauptete: „Die Geschichte wird von Menschen gemacht“, ging aber dann weiter und bestand darauf: „Die durchschnittliche Achse der intellektuellen Entwicklung der Menschheit“ läuft „parallel zu der der wirtschaftlichen Entwicklung"", so daß letzten Endes alles, was wirklich zählt, die wirtschaftliche Entwicklung ist."
<G-vec00092-001-s074><insist.bestehen><en> He would assert that ‘history is made by men’, but then go on to insist that ‘the average axis of mankind’s intellectual development’ runs ‘parallel to that of its economic development’, so that in the end all that really matters is the economic development.
<G-vec00092-001-s075><insist.bestehen><de> Wenn es Unterschiede in unseren Verständnissen der Prinzipien von Falun Gong gab, bestand ich immer darauf, dass andere meiner Sichtweise zustimmten.
<G-vec00092-001-s075><insist.bestehen><en> Whenever there were differences in our understandings of the principles taught in Falun Gong, I would always insist others agree with my viewpoint.
<G-vec00092-001-s076><insist.bestehen><de> Im Jahr 2002, während meiner verlängerten Haftzeit in der Strafanstalt, bestand mein Mann darauf, dass die Verwaltung einen rechtlichen Beweis für meine Inhaftierung vorlegen sollte.
<G-vec00092-001-s076><insist.bestehen><en> In 2002, during my extended period in the detention centre, my husband went to insist that the authorities produce legal evidence for detaining me.
<G-vec00092-001-s077><insist.bestehen><de> Aber er bestand darauf, dass Religion die ausschließliche Beschäftigung der Zwölf zu sein hatte.
<G-vec00092-001-s077><insist.bestehen><en> But he did insist that religion was the exclusive business of the twelve.
<G-vec00078-001-s057><pass.bestehen><de> Gilead hat diesen Test nicht bestanden.
<G-vec00078-001-s057><pass.bestehen><en> Gilead did not pass this test.
<G-vec00078-001-s058><pass.bestehen><de> "Im Jahr 2011 hat die spanische Regierung eine ""Tod mit Würde Gesetz"", die nicht bestanden haben."
<G-vec00078-001-s058><pass.bestehen><en> "In 2011, the Spanish government introduced a ""death with dignity law"" which did not pass."
<G-vec00078-001-s059><pass.bestehen><de> Einige der Mädchen hängen deprimiert in einer Ecke des Schulhofs ab, da sie die Prüfungen für die Universitätszulassung nicht bestanden haben.
<G-vec00078-001-s059><pass.bestehen><en> Several girls are hanging around depressed in a corner of the schoolyard because they didn't pass the admission tests to university.
<G-vec00078-001-s060><pass.bestehen><de> "Unter Berücksichtigung der Neubewertung in Bezug auf die Aussage10.4 erhöhte sich die Gesamtpunktzahl von 68 auf 70 Punkte und es wurde die Note ""bestanden"" vergeben."
<G-vec00078-001-s060><pass.bestehen><en> "Taking into account the correction with respect to statement 10.4, the total marks rose from 68 to 70 and the ""pass"" grade was therefore awarded."
<G-vec00078-001-s061><pass.bestehen><de> Der schriftliche Teil gilt als bestanden, wenn mindestens 80 Prozent der möglichen Punkte erreicht sind.
<G-vec00078-001-s061><pass.bestehen><en> A pass grade is obtained in the written part when the candidate reaches at least 80 percent of the total points.
<G-vec00078-001-s062><pass.bestehen><de> Das WinTATS wird mithilfe eines einfachen Pull-Down-Menüs programmiert, und der Bediener wird aufgefordert, Testparameter und Bestanden/Durchgefallen-Toleranzen für jeden Test einzugeben.
<G-vec00078-001-s062><pass.bestehen><en> The Baker WinTATS is programmed using a simple pull down menu and the operator is prompted to input test parameters and pass/fail tolerances for each test.
<G-vec00078-001-s063><pass.bestehen><de> Mit ihrem reichhaltigen Erfahrung und Fachkenntnisse auf Spielzeug und Kunsthandwerk, werden wir Ihnen guten Vorschlag geben, die Ihre Produkte sicherer zu machen, alle erforderlichen Tests bestanden und haben gute Verkäufe auf dem Markt.
<G-vec00078-001-s063><pass.bestehen><en> With rich experience and professional knowledge on toys & crafts, we will give you good suggestion, which make your products safer to pass all the necessary tests and have good sales in the market.
<G-vec00078-001-s064><pass.bestehen><de> File Checksums: Violations: Dieser NVT zeigt die Dateien, die die Prüfung der Prüfsummen nicht bestanden haben (falsche Prüfsummen).
<G-vec00078-001-s064><pass.bestehen><en> File Checksums: Violations: This NVT shows the files which did not pass the checksum check (wrong checksum).
<G-vec00078-001-s065><pass.bestehen><de> Bestanden experimentellen Nachweis der Messung, die mechanische Struktur ist gut gestaltet, zuverlässig, schleppen, mobile Arbeitskraft, kann effektiv vor Kollision zu verhindern.
<G-vec00078-001-s065><pass.bestehen><en> Pass experimental verification of measurement, the mechanical structure is well designed, reliable, hauling, mobile work force, can be prevent from collision effectively.
<G-vec00078-001-s066><pass.bestehen><de> Um eine Einladung für RED zu bekommen muss unser Interview bestanden werden.
<G-vec00078-001-s066><pass.bestehen><en> In order to receive an invite to RED, you must pass our interview.
<G-vec00078-001-s067><pass.bestehen><de> Dieser Plan beruht dann auf mehreren Testläufen aller Tasks, und wenn sie ihre Tests bestanden haben, ist es möglich zu garantieren, daß kein Task seine Ausführungszeit verpassen wird.
<G-vec00078-001-s067><pass.bestehen><en> The schedulability test consists on applying a number of tests to the whole set of tasks, and if they pass the tests then it will be possible to warranty that no task will loose its deadline.
<G-vec00078-001-s068><pass.bestehen><de> Die folgenden Bestanden/Nicht-bestanden-Kriterien dieses Dokuments sind eine Interpretation des Webstandards in Section 508, angewandt auf eine Gallery-Website, die mit der Vorlage Marquee erstellt wurde.
<G-vec00078-001-s068><pass.bestehen><en> The following pass/fail criteria in this document represent an interpretation of Section 508 web standards as applied to a Gallery site built using the Marquee template.
<G-vec00078-001-s069><pass.bestehen><de> Wie können wir unsere Kinder behandeln, um ihre Bildschirmzeit zu verkürzen, wenn sie ihre Hausaufgaben nicht rechtzeitig erledigen oder sie ihr Lieblingsgerät kaufen, wenn sie die Prüfung mit Bravour bestanden haben, aber die meiste Zeit sind sie nur manipulative Taktiken, Zeit.
<G-vec00078-001-s069><pass.bestehen><en> Like we may treat our children to cut down their screen time if they do not complete their homework on time or buy them their favorite gadget if they pass the exam with flying colors, but most of the time they are just manipulative tactics employed to pass the time.
<G-vec00078-001-s070><pass.bestehen><de> Einige Bemerkungen bezüglich Einsendung von Wettbewerbsvideos: 1) Falls Dein Video den Tech-Check nicht bestanden hat, macht es keinen Sinn technische Probleme mit dem Moderator, der für den Check verantwortlich ist, zu lösen.
<G-vec00078-001-s070><pass.bestehen><en> Some remarks concerning the submission of contest videos: 1) If your video did not pass the tech check, there is no point trying to solve technical issues with the moderator responsible for checking.
<G-vec00078-001-s071><pass.bestehen><de> Belegen Sie eine niedrigere Punktzahl, haben Sie das CAE nicht bestanden.
<G-vec00078-001-s071><pass.bestehen><en> If you score any lower, however, you do not pass the CAE.
<G-vec00078-001-s072><pass.bestehen><de> Tatsächlich aber hatte ich den Test meiner Xinxing mit meiner Mutter nicht bestanden, ich lief einfach davor weg.
<G-vec00078-001-s072><pass.bestehen><en> Actually, I did not pass the xinxing test with my mom, I simply ran away from it.
<G-vec00078-001-s073><pass.bestehen><de> Verschmiert, 20 Minuten nicht bestanden, rannte zum Waschen.
<G-vec00078-001-s073><pass.bestehen><en> Smeared, 20 minutes did not pass, ran to wash.
<G-vec00078-001-s074><pass.bestehen><de> Wenn Sie mindestens 17 Fragen richtig beantworten, haben Sie den Test bestanden.
<G-vec00078-001-s074><pass.bestehen><en> If you answer a minimum of 17 questions correctly, you will pass the test.
<G-vec00078-001-s075><pass.bestehen><de> Wenn Sie über Plug-ins verfügen, die den Validierungstest nicht bestanden haben, prüfen Sie auf der Website des Herstellers, ob es aktualisierte Versionen gibt.
<G-vec00078-001-s075><pass.bestehen><en> If you have any plug-ins that do not pass the validation test, check the manufacturer website for updated versions.
<G-vec00092-001-s078><insist.bestehen><de> Sie bestanden allerdings weiterhin darauf, den Nicht-Russen gleiche Bürgerrechte wie den Russen zu gewähren, was sie zu ideologischen und politischen Gegnern der Nationalisten machte.
<G-vec00092-001-s078><insist.bestehen><en> But they continued to insist on granting the non-Russians equal civil rights with the Russians, and this made them ideological and political opponents of the nationalists.
<G-vec00092-001-s079><insist.bestehen><de> Ihre Söhne wollten sie ins Krankenhaus einweisen, doch ihre Antwortete lautete: „Mit mir ist alles in Ordnung, der Meister wird sich um mich kümmern.“ Die Söhne wussten, dass sie Falun Gong praktizierte und bestanden auch nicht weiter darauf.
<G-vec00092-001-s079><insist.bestehen><en> "Her sons wanted to send her to the hospital but she said: ""I am OK, Master1 will take care of me."" Her sons knew that she practises Falun Dafa and didn't insist further."
<G-vec00092-001-s080><insist.bestehen><de> Die Angehörigen bestanden darauf, dass die Ursache von Zhous Tod untersucht werde, doch nach wiederholten Drohungen durch die Polizei gaben sie auf.
<G-vec00092-001-s080><insist.bestehen><en> The family tried to insist that the cause of Ms. Zhou’s death be determined, but they gave in after repeated threats from the police.
<G-vec00092-001-s081><insist.bestehen><de> Die Mauren bestanden keineswegs darauf, dass die besiegten Christen und die jüdische Bevölkerung ihren Glauben aufgab; sie erwarteten nur, dass ihre Herrschaft anerkannt wurde.
<G-vec00092-001-s081><insist.bestehen><en> The Moors did not insist at all that the Christians and the Jewish population gave up their belief; they only expected them to recognize their dominance.
<G-vec00092-001-s082><insist.bestehen><de> Die serbischen Bürger bestanden darauf, dass die EULEX bis zu den Administrativgrenzposten ausschließlich von der KFOR begleitet werden sollte, was bis heute auch übliche Praxis war.
<G-vec00092-001-s082><insist.bestehen><en> The Serb citizens have gathered in large numbers to insist on EULEX only going to the administrative crossings accompanied by KFOR, which has been a regular practice.
<G-vec00092-001-s083><insist.bestehen><de> "Doch, wie gesagt, ich bestehe durchaus nicht auf dem Versuche der Bereicherung oder ""Belehrung"" des Wiener Geschmacks."
<G-vec00092-001-s083><insist.bestehen><en> But as I said I do not in any way insist on trying to enrich or 'educate' the taste of the Viennese.
<G-vec00092-001-s084><insist.bestehen><de> Aber vielleicht sollte ich doch noch deutlicher formulieren, warum ich so auf den Ortsbezug der ästhetischen Wahrnehmung bestehe.
<G-vec00092-001-s084><insist.bestehen><en> But perhaps I ought to state more clearly why I insist to focus on the place with regard to the aesthetical perception.
<G-vec00092-001-s085><insist.bestehen><de> Bestehe auf deinen Taxameter.
<G-vec00092-001-s085><insist.bestehen><en> Insist on your meter.
<G-vec00092-001-s086><insist.bestehen><de> Ich bestehe auf einer sofortigen Antwort.
<G-vec00092-001-s086><insist.bestehen><en> I insist on an immediate reply.
<G-vec00092-001-s087><insist.bestehen><de> Ich bestehe auf die Tatsache, dass wir hier gegen kein Gesetz verstoßen, gegen keines, und wir bitten unsere Partner, genauso zu handeln.
<G-vec00092-001-s087><insist.bestehen><en> I insist on the fact that we here violate no law and I ask our partners to act in the same fashion.
<G-vec00092-001-s088><insist.bestehen><de> Auf dieser Schlußfolgerung bestehe ich mit aller Entschiedenheit.
<G-vec00092-001-s088><insist.bestehen><en> ‘I insist upon this conclusion, most emphatically.
<G-vec00092-001-s089><insist.bestehen><de> Das ist, worauf ich bestehe.
<G-vec00092-001-s089><insist.bestehen><en> That’s what I insist on.
<G-vec00092-001-s090><insist.bestehen><de> Ich bestehe auf diese Dimension.
<G-vec00092-001-s090><insist.bestehen><en> I insist on this aspect.
<G-vec00092-001-s091><insist.bestehen><de> Aber ich bestehe darauf, dass Holocaust wie Zweiter Weltkrieg als historisches Ereignis behandelt werden und nicht als religiöser Mythos.
<G-vec00092-001-s091><insist.bestehen><en> But I just insist that both the Holocaust and World War II should be treated as an historical event rather than as a religious myth.
<G-vec00092-001-s092><insist.bestehen><de> In meinem Buch Der Pfad der die volle Aufmerksamkeit Ich bestehe darauf viel in dreifachen Disziplin, Warnung, dass wenn es das gleiche von seinen drei Links fehlt, ist das vollkommen unzureichend, es ist und nicht sagen, wenn zwei fehlt und wird nur von der Konzentration verwendet.
<G-vec00092-001-s092><insist.bestehen><en> In my book The path of the full attention I insist much in triple discipline, warning that if it is missing the same one of its three links, this it is completely insufficient, and not say if missing two and is used only on the concentration.
<G-vec00092-001-s093><insist.bestehen><de> """Genau deshalb bestehe ich darauf."
<G-vec00092-001-s093><insist.bestehen><en> — That is exactly why I insist upon that.
<G-vec00092-001-s094><insist.bestehen><de> Ich bestehe darauf, dass die KPCh die Verfolgung von Falun Gong stoppt.
<G-vec00092-001-s094><insist.bestehen><en> I insist that the CCP stop the persecution of Falun Gong.
<G-vec00092-001-s095><insist.bestehen><de> Als Generalsekretär bestehe ich darauf, dass das Wohlergehen aller Opfer sexueller Gewalt an oberster Stelle unseres Handelns stehen muss.
<G-vec00092-001-s095><insist.bestehen><en> As Secretary-General, I insist that the welfare of all victims of sexual violence in conflict must be at the forefront of our activities.
<G-vec00092-001-s096><insist.bestehen><de> Ich bestehe nicht darauf, daß jeder Arzt ein Hypnotiseur sein sollte, aber er muss die geistige Welt des Patienten verstehen, um über die Hauptsache in bezug auf den Krankheitsfall reden zu können.
<G-vec00092-001-s096><insist.bestehen><en> I do not insist that each physician be a hypnotist, but he must understand the spiritual world of the patient in order to be able to speak about the main thing in the case.
<G-vec00092-001-s097><insist.bestehen><de> Ich persönlich bestehe nicht darauf, dass die Ausbeutung etwas Schlechtes ist, ich denke, dass sie in einer Gesellschaft unvermeidlich ist, aber alles in seinen richtigen Dimensionen, nicht übertrieben.
<G-vec00092-001-s097><insist.bestehen><en> I personally don't insist that the exploitation is something bad, I think it is unavoidable in a society, but everything in its proper dimensions, not overdone.
<G-vec00092-001-s098><insist.bestehen><de> Wenn Sie nicht zufrieden sind-Variante in Form einer Anzahlung von dem ich schrieb, ich bitte und auch bestehe darauf, dass Sie nicht zu verbringen weder seine noch meine Zeit.
<G-vec00092-001-s098><insist.bestehen><en> If You are not satisfied with the option of a Deposit which I wrote I ask and even insist that You would not spend neither your nor my time.
<G-vec00092-001-s099><insist.bestehen><de> Aber ich werde nie müde vom Reisen und bestehe immer darauf, in der Pause nach jeder Saison meine eigenen Reisen zu unternehmen.
<G-vec00092-001-s099><insist.bestehen><en> But I never get tired of traveling, and always insist on doing my own travels during break after each season’s tour.
<G-vec00092-001-s100><insist.bestehen><de> Sri Aurobindo sagte es, und es gibt Leute, die sich daran erinnern, die es wiederholen, wozu ich nicht nein sage (weil es nicht nein ist – es kann nicht nein sein: es ist wahr), aber ich bestehe nicht darauf, ich sage es nicht... Ich sage es dir, weil wir zusammen arbeiten und eben auch, weil du für einige Zeit nach Frankreich gehst und es für dich während dieser Zeit das eigentliche Mittel sein wird, diesen Fortschritt zu erzielen, nämlich dich zu verbinden und dann standzuhalten und dich dauernd in diese Kraft zu hüllen.
<G-vec00092-001-s100><insist.bestehen><en> Sri Aurobindo said it and some people remember, they repeat it and I don't say no (because it isn't no – it cannot be no: it's true), but I don't insist on it, I never say it.... I am saying it to you because we work together, and also, in fact, because you'll be going to France for some time and during that time it will truly be the way for you to make this progress: to fasten yourself, stand firm and be constantly wrapped in the Force.
<G-vec00092-001-s101><insist.bestehen><de> Und ich bestehe nach wie vor darauf, daß man mit der Herstellung dieser tatsächlichen Verbindung nur beginnen kann auf der Grundlage einer gemeinsamen Zeitung, als des einzigen regelmäßigen gesamtrussischen Unternehmens, das die Ergebnisse der verschiedensten Arten der Tätigkeit summiert und dadurch die Leute anspornt, unermüdlich auf all den zahlreichen Wegen vorwärtszuschreiten, die zur Revolution führen, so, wie alle Wege nach Rom führen.
<G-vec00092-001-s101><insist.bestehen><en> I continue to insist that we can start establishing real contacts only with the aid of a common newspaper, as the only regular, all-Russia enterprise, one which will summarise the results of the most diverse forms of activity and thereby stimulate people to march forward untiringly along all the innumerable paths leading to revolution, in the same way as all roads lead to Rome.
<G-vec00092-001-s102><insist.bestehen><de> Sind wir genervt oder angespannt angesichts eines verpassten Trainings oder bestehen auf Sport trotz Verletzungen, so ist es vielleicht an der Zeit, einen Gang herunterzuschalten und darüber nachzudenken, ob nicht eine gesunde Veränderung notwendig ist.
<G-vec00092-001-s102><insist.bestehen><en> If we become agitated and anxious over the thought of skipping an exercise routine or insist on working out while injured, it may be time to step back and assess if a healthy change is needed.
<G-vec00092-001-s103><insist.bestehen><de> Wer auf der Gleichsetzung jeweils einer Karte mit einem bestimmten Planeten oder Zeichen bestehen wollte, müsste auch erklären, wie mit weiteren zu entdeckenden Planeten umgegangen werden soll, denn man kann ja nicht einfach Karten dazuerfinden.
<G-vec00092-001-s103><insist.bestehen><en> Those who insist on assigning one particular card to a particular planet or sign, should also be able to explain how to deal with planets which may still be discovered, because we can't just invent a few new cards.
<G-vec00092-001-s104><insist.bestehen><de> Genau wie das Leben, es ist, wenn alles, was könnte möglicherweise schief gehen, als ein Spieler, Sie bestehen auf der Notwendigkeit, dass es absolut ein Vertreter zur Verfügung, um Ihr Problem effizient und emu Casino sind sehr effizient auf diese.
<G-vec00092-001-s104><insist.bestehen><en> Just like life, it is when anything could possibly go wrong that, as a player, you insist on the need that there is absolutely a representative available to address your issue efficiently and emu Casino are very efficient at this.
<G-vec00092-001-s105><insist.bestehen><de> Früher konnten Sie kaprisnitschat oder auf den bestehen.
<G-vec00092-001-s105><insist.bestehen><en> Earlier you could be capricious or insist on the.
<G-vec00092-001-s106><insist.bestehen><de> Unter ihnen bemerkenswert, zusätzlich zur Vollendung des Marisabella gefüllt, jetzt kurz vor der Eröffnung der Werft, die Verdoppelung der Kreuzfahrt-Terminal, die neue Anlegestelle Erweiterung des Hafenbeckens in den westlichen Hafen von Bari, die Erweiterung der Pier Tramontana Barletta und die Sanierung von Pier Tramontana Wurzel Monopoly und eine allgemeine Werbekampagne Unterhaltungsbaggerungen, damit die volle Ausnutzung der Ports.Der Topf auch das Problem der Integration zwischen Hafen und Territorium unter Hinweis auf die wirtschaftlichen Auswirkungen von Häfen haben bereits großes Gebiet, in dem sie bestehen.
<G-vec00092-001-s106><insist.bestehen><en> Among them worthy of note, in addition to the completion of Marisabella filled, now the eve of the opening of the shipyard, the doubling of the cruise terminal, the new wharf extension of the dock in the western port of Bari, the extension of Pier Tramontana Barletta and the redevelopment of Pier Tramontana root of Monopoly and a generalized campaign of maintenance dredging to ensure the full utilization of ports.The pot also addresses the issue of integration between port and territory noting the economic impact of ports already have extensive area in which they insist.
<G-vec00092-001-s107><insist.bestehen><de> Wir bestehen immer auf der Management-Lehre der „Quality First ist, Technologie ist Basis, Ehrlichkeit und Innovation“ .Wir ist in der Lage, neue Produkte zu entwickeln, kontinuierlich auf ein höheres Niveau unterschiedliche Bedürfnisse der Kunden zu befriedigen.
<G-vec00092-001-s107><insist.bestehen><en> "We always insist on the management tenet of ""Quality is First, Technology is Basis, Honesty and Innovation"".We are able to develop new products continuously to a higher level to satisfy different needs of customers."
<G-vec00092-001-s108><insist.bestehen><de> Wir bestehen auf dem Grundsatz des Kunden zuerst, mit der schnellsten Versorgungsmaterial-Geschwindigkeit und Zeit, perfektes zitierendes System und schnelle Anlieferungsmethode, unsere Firma kann das Problem in kürzester Zeit regeln, um die Kosten für Klienten zu verringern.
<G-vec00092-001-s108><insist.bestehen><en> We insist on the principle of customer first, with the quickest supply speed and time, perfect quoting system and rapid delivery method, our company can settle the problem in shortest time to reduce the cost for client.
<G-vec00092-001-s109><insist.bestehen><de> In hartem Wettbewerb bestehen wir auf unserem Traum.
<G-vec00092-001-s109><insist.bestehen><en> In fierce competition,we will insist on our dream.
<G-vec00092-001-s110><insist.bestehen><de> A: Die syrische Revolution wird ihren friedlichen Ausdruck behalten und auf ihren legitimen Forderungen bestehen.
<G-vec00092-001-s110><insist.bestehen><en> The Syrian revolution will keep its peaceful manner and insist on its rightful demands.
<G-vec00092-001-s111><insist.bestehen><de> “Diese Zahlen müssen die Unternehmen ermutigen, weiterhin auf den Linien der Arbeit zu bestehen, die es ihnen ermöglichen, wettbewerbsfähiger werden, zu wachsen und Arbeitsplätze schaffen: die Konsolidierung des Auslandsmarkt erreichen, während Ziele Schwellen, und die Erhöhung der Mehrwert ihrer Produkte durch R & D, Design und Differenzierung” Er fügte hinzu, Tortosa Lopez, Unter Hinweis auf die Schritte, die von der Branche getroffen werden, von der Junta de Andalucía unterstützt, para conseguir la Indicación Geográfica Protegida para el mármol de Macael.
<G-vec00092-001-s111><insist.bestehen><en> “These figures have to encourage companies to continue to insist on the lines of work that will allow them to be more competitive, grow and create jobs: the consolidation of the international market reach while emerging destinations, and increasing the added value of their products through R & D, design and differentiation” Lopez added Tortosa, remembering the steps being taken by the industry, supported by the Junta de Andalucía, para conseguir la Indicación Geográfica Protegida para el mármol de Macael.
<G-vec00092-001-s112><insist.bestehen><de> (2) Handelt es sich um einen leicht behebbaren Mangel, kann der Käufer nicht auf einer Neulieferung bestehen.
<G-vec00092-001-s112><insist.bestehen><en> (2) If it is an easily remediable defect, the buyer can not insist on a replacement.
<G-vec00092-001-s113><insist.bestehen><de> Was die höheren Kräfte anbelangt (zum Beispiel die des Obermentals), so sind sie zwar dynamisch und versuchen stets, Bewusstsein wirksam zu machen, sie bestehen aber auf Bewusstsein, während die feindlichen sich darum nicht kümmern; je unbewusster und je mehr du ihr automatisches Werkzeug bist, desto zufriedener sind sie, denn es ist die Unbewusstheit, die ihnen eine Chance gibt.
<G-vec00092-001-s113><insist.bestehen><en> As for the greater Forces (e.g. overmind) they are dynamic and try always to make consciousness effective, but they insist on consciousness, while the hostiles care nothing for that – the more unconscious you are and their automatic tool, the better they are pleased – for it is unconsciousness that gives them their chance.
<G-vec00092-001-s114><insist.bestehen><de> Sie haben ihre Stellungnahmen abgegeben und deutlich gemacht, dass sie auf einer vollen und effektiven Beteiligung an jeglichem Nachfolgeprozess nach dem Tunis-Gipfel bestehen.
<G-vec00092-001-s114><insist.bestehen><en> They submitted their statements and made clear that they insist on a full and effective participation in any process following the Tunis summit.
<G-vec00092-001-s115><insist.bestehen><de> Er war jetzt nicht in einer Position, auf einer ethischen Norm zu bestehen und den Fehler beim Bruder zu sehen, der doch auf das Erstgeburtsrecht gar keinen Wert gelegt hatte.
<G-vec00092-001-s115><insist.bestehen><en> He was in no position to insist on ethical principles; he could not just go on imputing the fault to his brother, who had never attached great importance to his right of primogeniture.
<G-vec00092-001-s116><insist.bestehen><de> Genau wie das Leben, es ist, wenn alles, was könnte möglicherweise schief gehen, dass, als Spieler, Sie bestehen auf der Notwendigkeit, dass es absolut ein Vertreter zur Verfügung, um Ihr Problem schnell und Kingbit Casino sind sehr effizient auf diese.
<G-vec00092-001-s116><insist.bestehen><en> Just like life, it is when anything could possibly go awry that, as a player, you insist on the need that there is absolutely a representative available to deal with your issue quickly and Kingbit Casino are very efficient at this.
<G-vec00092-001-s117><insist.bestehen><de> Das ist eine wichtige Gelegenheit für die Britische Regierung sowie für Menschenrechtsaktivisten, auf dem Ende der Inhaftierungen, Folterungen und Hinrichtungen in China zu bestehen.
<G-vec00092-001-s117><insist.bestehen><en> This provides an important opportunity for the British government and human rights campaigners to insist on an end to detentions, tortures and executions in China.
<G-vec00092-001-s118><insist.bestehen><de> Der ANAKIS 3 richtet sich an alle Piloten, die auf Sicherheit und genussvolles Fliegen bestehen.
<G-vec00092-001-s118><insist.bestehen><en> The ANAKIS 3 relates to all pilots who insist on safety and pleasurable flying.
<G-vec00092-001-s119><insist.bestehen><de> Johanniskraut, Eukalyptus, Ringelblume in der Menge von 10 Gramm.mit jeweils nur einem siedenden Wasser in einer Menge von 250-300 ml gefüllt und bestehen nicht mehr als eine Stunde.Bewerben 2 Teelöffel Tinktur für jedes Einatmen.
<G-vec00092-001-s119><insist.bestehen><en> St. John's wort, eucalyptus, calendula in the amount of 10 grams.each filled with just a boiling water in an amount of 250-300 ml and insist no more than an hour.Apply 2 teaspoons of tincture for each inhalation.
<G-vec00092-001-s120><insist.bestehen><de> Wir bestehen auf unserer Freiheit zu Leben und Menschenwürde, Respekt der Privatsphäre und der Familie, Bewegungsfreiheit, volle medizinische Versorgung, freie Meinungsäußerung und Versammlungsfreiheit, Erziehung, Freizeit und Erholung, Aufenthalt und normale Wohnung wie auch Arbeit um unsere Leben selbst zu finanzieren [weiter fortzuführen...] genießen zu können, ohne Ausnahmen gemäß der Grundwerte von Freiheit und Recht.
<G-vec00092-001-s120><insist.bestehen><en> We insist on our freedom to live and to enjoy with human dignity and respect for privacy and family, free movement, full medical care, to free speech and association, education, holiday and recreation, residence and normal housing as well as to work to earn our living [to be lined up...] without exceptions to values of equal freedom and justice.
<G-vec00078-001-s076><pass.bestehen><de> Ein starker Glaube läßt sich nicht mehr erschüttern, und dann hat der Mensch sein Ziel erreicht auf Erden.... Solange er aber noch wankend wird in Fällen der Not, ist er noch nicht stark genug, und er benötigt Prüfungen, er benötigt Glaubensproben, die er im Vertrauen auf Mich auch bestehen kann.
<G-vec00078-001-s076><pass.bestehen><en> A strong faith no longer allows itself to become disturbed, and then the human being will have achieved his goal on earth.... But as long as he is still uncertain in times of hardship he is not yet strong enough and needs testing, he requires tests of faith, which he will be able to pass with confidence in Me. Anyone who wants to acquire a profoundly unwavering faith will reach his goal since I will look after him especially kindly.
<G-vec00078-001-s077><pass.bestehen><de> Angesichts dieser fundamentalen Sache, habe ich das Gefühl, dass der Lehrer mir eine Menge Hinweise gab, welche mir halfen, die Prüfung auf Leben und Tod ganz problemlos zu bestehen.
<G-vec00078-001-s077><pass.bestehen><en> On this fundamental issue I feel that Teacher gave me a lot of hints which helped me to pass the test of life and death fairly smoothly.
<G-vec00078-001-s078><pass.bestehen><de> "Der dritte Teil des Spiels ""Farm Frenzy"" - ein 90 Ebenen, die Sie mit großem Interesse bestehen wird, in jedem Level von neuen Arbeitsplätzen und einer Vielzahl von Optionen für die Erreichung des Hauptziel des Spiels."
<G-vec00078-001-s078><pass.bestehen><en> "The third part of the game ""Farm Frenzy"" - a ninety levels that you will pass with great interest, in each level of new jobs and a variety of options for achieving the main goal of the game."
<G-vec00078-001-s079><pass.bestehen><de> Diesen Test musste ich bestehen, bevor mir ermöglicht wurde, diese Botschaft an die Intellektuellen auf Erden zu senden.
<G-vec00078-001-s079><pass.bestehen><en> I had to pass that test before I came to send this message to intellectuals on Earth.
<G-vec00078-001-s080><pass.bestehen><de> In der Regel muss ein Kandidat, wenn es sich um ein voraussetzungsfähiges Modul handelt, diese vor der Aufnahme höherer Module bestehen.
<G-vec00078-001-s080><pass.bestehen><en> Normally, where a prerequisite module is involved, a candidate shall be required to pass it before taking higher modules.
<G-vec00078-001-s081><pass.bestehen><de> Allah löscht aus, was Er will, und läßt bestehen; und bei Ihm ist der Kern des Buches.
<G-vec00078-001-s081><pass.bestehen><en> Allah makes to pass away and establishes what He pleases, and with Him is the basis of the Book.
<G-vec00078-001-s082><pass.bestehen><de> Aber auch alle geeigneten Lieferanten müssen erst eine Vorauswahl bestehen und dann einen weiteren Audit durchlaufen – so kann EUROPART seinen Kunden beste Qualität garantieren.
<G-vec00078-001-s082><pass.bestehen><en> But also all suitable suppliers must pass a pre-selection and then undergo a further audit. – so that EUROPART can guarantee best quality to its customers.
<G-vec00078-001-s083><pass.bestehen><de> Vorausgesetzt du hast deine Hausaufgaben für das Gespräch und die Bitte gemacht, solltest du diesen Test mit links bestehen.
<G-vec00078-001-s083><pass.bestehen><en> Provided you've done your homework for both the interview and this request, you should pass this test with flying colors.
<G-vec00078-001-s084><pass.bestehen><de> Mutanten die eine Test nicht bestehen, werden hier zu Futter für die anderen Mutanten verarbeitet.
<G-vec00078-001-s084><pass.bestehen><en> Mutants that do not pass the test are turned into food for the next lot of mutants.
<G-vec00078-001-s085><pass.bestehen><de> Die ersten Krones Maschinen bestehen das enviro Prüfverfahren.
<G-vec00078-001-s085><pass.bestehen><en> The first Krones machines pass the enviro test procedure.
<G-vec00078-001-s086><pass.bestehen><de> So musste das Modell aufgrund seiner außergewöhnlichen Form sogar Windkanaltests bestehen.
<G-vec00078-001-s086><pass.bestehen><en> The model even had to pass wind tunnel tests due to its unusual shape.
<G-vec00078-001-s087><pass.bestehen><de> Es ist ein schwerer Kampf, den ihr noch zu bestehen habt, doch er wird nicht zu schwer sein für euch, weil Ich euch ständig nahe bin und euch Unterstützung gewähre jederzeit.
<G-vec00078-001-s087><pass.bestehen><en> It is a difficult fight, which you still have to pass, but it will not be too difficult for you, because I am constantly close to you and grant you support at any time.
<G-vec00078-001-s088><pass.bestehen><de> Sie müssen zwei Module bestehen, Mastering Metrics (Obligatorisch), sowie ein Wahlmodul, um das L6-Diplom in Professional Marketing (*) zu erhalten.
<G-vec00078-001-s088><pass.bestehen><en> They will be required to pass two modules, Mastering Metrics (Mandatory) plus one elective module to obtain the L6 Diploma in Professional Marketing (*).
<G-vec00078-001-s089><pass.bestehen><de> Darüber hinaus bestehen diese Kabel die Kaltbiegeprüfung nach UL Standard 1581 bei 40°C und sind kompatibel mit RJ 45 und Neutrik Ethercon.
<G-vec00078-001-s089><pass.bestehen><en> These cables also pass the UL 1581 -40˚C cold bend test and are RJ 45 and Neutrik Ethercon compatible.
<G-vec00078-001-s090><pass.bestehen><de> Dank unserer Kurse, die von erfahrenen und spezialisierten Lehrern unterrichtet werden, bestehen fast alle unsere Schüler die Pr&uum...
<G-vec00078-001-s090><pass.bestehen><en> Thanks to our courses taught by experienced and specialized teachers, almost all of our students pass the examination.
<G-vec00078-001-s091><pass.bestehen><de> Außerdem dürfen die Behälter keinen Grat, scharfe Kanten oder Splitter aufweisen, wenn sie die Prüfung bestehen sollen.
<G-vec00078-001-s091><pass.bestehen><en> The container, then, must be free of burrs, chips, or sharp edges if it is to pass inspection.
<G-vec00078-001-s092><pass.bestehen><de> Die beste Art, einen Drogentest zu bestehen ist natürlich, lange Zeit vor dem Test keine Drogen zu konsumieren.
<G-vec00078-001-s092><pass.bestehen><en> The best way to pass a drug test is, of course, simply to quit using drugs long before the hiring process.
<G-vec00078-001-s093><pass.bestehen><de> Jeder könnte mich einem Lügendetektortest unterziehen und ich würde ihn bestehen.
<G-vec00078-001-s093><pass.bestehen><en> Anyone could give me a lie detector test and I would pass.
<G-vec00078-001-s094><pass.bestehen><de> Miteinander - Türkische Ausgabe orientiert sich dabei speziell an den zum Bestehen der Prüfung notwendigen Fertigkeiten (Leseverständnis, Schreibfertigkeit, Hörverständnis, Sprechfertigkeit).
<G-vec00078-001-s094><pass.bestehen><en> The Turkish edition of Miteinander concentrates specifically on the skills necessary to pass the exam (reading, writing, listening, and speaking).
<G-vec00092-001-s121><insist.bestehen><de> Aus 100 g Wurzeln pro 1 Liter (wir bestehen auf 4 Stunden) können Sie eine Tinktur zum Waschen von trockenen, hart heilenden Wunden herstellen.
<G-vec00092-001-s121><insist.bestehen><en> From 100 g of roots per 1 liter (we insist 4 hours), you can make a tincture for washing dry, hard healing wounds.
<G-vec00092-001-s122><insist.bestehen><de> Ansonsten gilt für Nevis: Wenn Sie Zeuge von Tiermisshandlungen werden, suchen Sie sofort andere Zeugen in Ihrer Nähe (keine Einheimischen), machen Sie Fotos aus sicherer Entfernung, rufen Sie die Polizei, bestehen Sie auf der Aufnahme einer Anzeige und lassen Sie sich vor Zeugen eine Kopie der Anzeige aushändigen.
<G-vec00092-001-s122><insist.bestehen><en> Otherwise applies to Nevis: If you observe animal abuse seek other witnesses immediately (not locals), take photos from a safe distance, call the police, insist that the police take down your complaint and hand you a copy.
<G-vec00092-001-s123><insist.bestehen><de> Bestehen Sie auf Rinde sollte für 2-3 Wochen an einem dunklen Ort sein.
<G-vec00092-001-s123><insist.bestehen><en> Insist bark should be for 2-3 weeks in a dark place.
<G-vec00092-001-s124><insist.bestehen><de> Wir bestehen nur auf vernünftigen Gewinnen.
<G-vec00092-001-s124><insist.bestehen><en> We just insist resonable profits.
<G-vec00092-001-s125><insist.bestehen><de> "Wir bestehen auf ""Kundenorientierung, ehrlich in der Wirtschaft, treu in Dienstleistungen, vertrauenswürdig in der Werbung"", Versuchen Sie, die marktführenden Produkte zu machen und zuverlässige Hersteller von Kunden zu sein."
<G-vec00092-001-s125><insist.bestehen><en> "We insist ""customer focus, honest in business, faithful in services, trusty in advertisement"", Try to make the market leading products and to be reliable manufacturers by customers."
<G-vec00092-001-s126><insist.bestehen><de> Bestehen Sie auf den Tag und dann belasten Sie.
<G-vec00092-001-s126><insist.bestehen><en> Insist the day, and then strain.
<G-vec00206-001-s102><comprise.bestehen><de> Die bisher dünnsten Fasern bestehen aus nur noch fünf Doppelhelix-Strängen und sind nur wenige Nanometer dick.
<G-vec00206-001-s102><comprise.bestehen><en> The thinnest fibers to date comprise only five double helix strands and are only a few nanometers thick.
<G-vec00206-001-s103><comprise.bestehen><de> Die Nkambe und Ndu Resident Mums bestehen aus drei verschiedenen Clans, Warr, Tang und Wiya, die aus der östlichen Tikari-Hauptstadt Kimi auswanderten.
<G-vec00206-001-s103><comprise.bestehen><en> The Nkambe and Ndu resident Mums comprise three distinct clans, Warr, Tang and Wiya, who migrated from the eastern Tikari capital of Kimi.
<G-vec00206-001-s104><comprise.bestehen><de> Die Kugelhähne der Serie 6E bestehen aus Kugelhähnen der Serie 6A und unserem elektrischen Schwenkantrieb (STANDARD).
<G-vec00206-001-s104><comprise.bestehen><en> The Series 6E ball valves comprise Series 6A ball valves and our electrical part-turn actuator (STANDARD).
<G-vec00206-001-s105><comprise.bestehen><de> Die ethischen Leitlinien und Geschäftsgrundsätze bestehen aus den Positiv- und Ausschlusskriterien und bilden die Grundlage der Geschäftsanbahnung innerhalb der gesamten HYPO NOE.
<G-vec00206-001-s105><comprise.bestehen><en> Ethical business principles Our ethical and business principles comprise inclusion and exclusion criteria, which form the basis for initiating business contacts.
<G-vec00206-001-s106><comprise.bestehen><de> Die Dokumentationen bestehen jeweils aus einer gehefteten A4 Broschüre mit 12 Seiten Kerntext auf 80g Papier SW zur Projekteinführung.
<G-vec00206-001-s106><comprise.bestehen><en> Each documentation comprise a stitched A4 brochure with at least 12 pages text on 80g paper BW to the project implementation.
<G-vec00206-001-s107><comprise.bestehen><de> Die Modelle reichen von traditionell bis futuristisch und bestehen aus verschiedenen Materialien und Formen – ob klassisch, eckig oder asymmetrisch.
<G-vec00206-001-s107><comprise.bestehen><en> The models range from traditional to futuristic designs and comprise of different materials and shapes – be it classical, angular or asymmetrical.
<G-vec00206-001-s108><comprise.bestehen><de> Die Suiten bestehen aus einem Doppelzimmer (65 m2) mit Wohnbereich (Sofa und zwei Sessel) und Terrasse, Ankleidezimmer, 2x2 m Doppelbett mit Betthimmel, Komplettbad mit Hydromassagedusche und großer Badewanne, Haartrockner, Bademantel, Hausschuhen, Schminkspiegel, ausgewählten Amenitiy-Artikeln und Kopfkissen-Menü, individuell regulierbare Klimaanlage, Flachbildschirmfernseher mit Satellitenprogramm und interaktiver TV-Anlage mit Musikkanälen, Telefon, Internetanschluss, Minibar und kostenloser Safe.
<G-vec00206-001-s108><comprise.bestehen><en> Deutsch The Junior Suites comprise a 65m2 double room with lounge area (furnished with sofa and two armchairs) and terrace, separate dressing room, four-poster 2x2 double bed, full bathroom with hydromassage shower and large bath, hairdryer, bathrobes, slippers, magnifying mirror, a selection of high quality complimentary items, pillow menu for personalised comfort, individually controlled air conditioning, interactive satellite TV with music channels and flat screen, telephone, Internet connection, minibar and free safe deposit box.
<G-vec00206-001-s109><comprise.bestehen><de> Die Vorwärmstationen bestehen aus einem Gestell mit zwei geregelten Heizplatten.
<G-vec00206-001-s109><comprise.bestehen><en> The pre-heating stations comprise a frame with two controlled heating platens.
<G-vec00206-001-s110><comprise.bestehen><de> Die Multiport-Kugelhähne der Serie 6Y mit elektrischem Schwenkantrieb (STANDARD) bestehen aus zwei Mehrwegkugelhähnen, die in kompakter Bauweise in einem Gehäuse in 2 Ebenen übereinander angeordnet sind.
<G-vec00206-001-s110><comprise.bestehen><en> The Series 6Y multiport ball valves with electrical actuator (STANDARD) comprise two multi-way ball valves that are arranged one on top of the other in a housing with 2 levels.
<G-vec00206-001-s111><comprise.bestehen><de> Schuldinstrumente: Schuldinstrumente der Ebene 2 gemäß Fair-Value-Hierarchie bestehen aus Staats-, überstaatlichen und Unternehmensanleihen, deren Preise nur unregelmässig oder mit starker zeitlicher Verzögerung verfügbar sind.
<G-vec00206-001-s111><comprise.bestehen><en> Debt instruments: Debt instruments categorised as level 2 of the fair value hierarchy comprise government, supranational and corporate bonds for which prices are only available on an irregular basis or with a significant time lag.
<G-vec00206-001-s112><comprise.bestehen><de> Im Gegenteil – alte Rollladenkästen bestehen meist aus einem Hohlraum im Mauerwerk, vom Raum lediglich durch dünne Span- oder Sperrholzplatten getrennt.
<G-vec00206-001-s112><comprise.bestehen><en> On the other hand, old roller shutter casings comprise of a cavity in the brickwork that is merely separated from the room by thin plywood or particle board.
<G-vec00206-001-s113><comprise.bestehen><de> Die Kugelhähne der Serie 6D bestehen aus Kugelhähnen der Serie 6L und unserem pneumatischen Schwenkantrieb (STANDARD).
<G-vec00206-001-s113><comprise.bestehen><en> The Series 6D ball valves comprise Series 6L ball valves and our pneumatic part-turn actuator (STANDARD).
<G-vec00206-001-s114><comprise.bestehen><de> „Tilger bestehen aus einer Masse, meist Stahl, die gegenphasig zur störenden Anregung schwingt.
<G-vec00206-001-s114><comprise.bestehen><en> """Absorbers comprise a mass, usually made of steel, which vibrates in antiphase to the annoying vibrations."
<G-vec00206-001-s115><comprise.bestehen><de> Sie bestehen aus einem Wohnbereich, einer Einbauküche, 3 Schlafzimmern, 2 Bädern, einem Keller und einem optionalen Solarium mit herrlicher Aussicht.
<G-vec00206-001-s115><comprise.bestehen><en> They comprise of a living area, fitted kitchen, 3 bedrooms, 2 bathrooms, basement and optional solarium with amazing views.
<G-vec00206-001-s116><comprise.bestehen><de> Moderne IT Plattformen bestehen aus diversen hochkomplexen Schichten und Produkten.
<G-vec00206-001-s116><comprise.bestehen><en> State-of-the-art IT platforms comprise a wide variety of highly complex layers and products.
<G-vec00206-001-s117><comprise.bestehen><de> Und Baupläne bestehen aus spezifischen Gruppen von spezialisierten Organen.
<G-vec00206-001-s117><comprise.bestehen><en> And body plans comprise specific arrangements of specialized organs.
<G-vec00206-001-s118><comprise.bestehen><de> Der Marshall-Inseln-Registrierung rangiert wie Registrierung der drittgrößte in der Welt zu öffnen und privaten/kommerziellen Yachten bestehen aus 24 % der Marshall-Inseln-Flotte in Bezug auf Schiff zählen.
<G-vec00206-001-s118><comprise.bestehen><en> The Marshall Islands Registry is ranked as the third largest open registry in the world and private/commercial yachts comprise 24% of the Marshall Islands fleet in terms of vessel count.
<G-vec00206-001-s119><comprise.bestehen><de> Sie bestehen praktisch nur aus html Code-Seiten, jgp Grafiken, .avi Animationen und wenigen animierten .gif Grafiken.
<G-vec00206-001-s119><comprise.bestehen><en> In practice they comprise html code pages, ten, .jgp graphic files, .avi animations and a few animated .gif files.
<G-vec00206-001-s120><comprise.bestehen><de> Die unerwünschten Sedimente bestehen meist aus Sand und Schlamm.
<G-vec00206-001-s120><comprise.bestehen><en> These undesirable sediments comprise mainly sand and slime.
<G-vec00092-001-s127><insist.bestehen><de> Unsere Partner bestehen darauf, daß Griechenland in der Eurozone bleibt, weil sie Angst haben, daß der Grexit eine gefährliche Dominowirkung hätte.
<G-vec00092-001-s127><insist.bestehen><en> Our partners insist on keeping Greece inside the Eurozone, because they are afraid of the dangerous domino effect of the ``Grexit.''
<G-vec00092-001-s128><insist.bestehen><de> Einige Hersteller bestehen darauf, dass ihre Zulieferer Röntgeninspektionssysteme installieren, um das Risiko fremdkörperhaltiger Rohstoffe vor der Auslieferung und eine Anlieferung an ihre Produktionsanlage zu verringern.Wird das Risiko von Fremdkörpern so früh wie möglich im Produktionsprozess ausgeschlossen, werden auch Produktausschuss und Gesamtproduktionskosten gesenkt.
<G-vec00092-001-s128><insist.bestehen><en> Some manufacturers will insist that their suppliers have x-ray inspection equipment installed before the goods are dispatched to reduce the risk of contaminated products entering their production facility. Eliminating the risk of contaminants as early as possible in the production process will minimise product waste and overall production costs.
<G-vec00092-001-s129><insist.bestehen><de> Einige muslimische Mädchen wollen in der Schule nicht am Sportunterricht teilnehmen, Frauen bestehen darauf, daß Schwimmbäder zu bestimmten Zeiten für Männer geschlossen werden.
<G-vec00092-001-s129><insist.bestehen><en> Some Muslims girls refuse to participate in sport lessons at school, Muslims women insist that during special hours swimming pools have to be closed for men.
<G-vec00092-001-s130><insist.bestehen><de> Aber die US-Herren bestehen darauf, dass sie den Irak erobert haben und der Raub ihnen allein gehört.
<G-vec00092-001-s130><insist.bestehen><en> But the U.S. masters insist that they fought for and stole Iraq for themselves.
<G-vec00092-001-s131><insist.bestehen><de> Inhalt: SG-1 kehrt von einer Mission zurück, doch bei der Besprechung bestehen sie darauf, dass Selmak noch am Leben ist.
<G-vec00092-001-s131><insist.bestehen><en> Synopsis: SG-1 returns from a mission but in the debriefing they insist that Selmak is still alive.
<G-vec00092-001-s132><insist.bestehen><de> Meine einheimischen Begleiter bestehen darauf, dass es dort Löwen und Leoparden geben soll.
<G-vec00092-001-s132><insist.bestehen><en> My local guides insist on the fact that leopards and lions live down there....
<G-vec00092-001-s134><insist.bestehen><de> Bestehen Sie darauf, zwei Monate vor den Mahlzeiten ein paar Löffel zu trinken.
<G-vec00092-001-s134><insist.bestehen><en> Insist drink two months for a few spoons before meals. 3.
<G-vec00092-001-s135><insist.bestehen><de> Bestehen Sie nicht darauf, trotzdem zu fahren, da Sie sonst mit einer Geldstrafe belegt werden.
<G-vec00092-001-s135><insist.bestehen><en> Do not insist on remaining on the area, or you may get fined.
<G-vec00092-001-s136><insist.bestehen><de> Dennoch bestehen sowohl er als auch Waygood darauf, dass es überwältigende Belege dafür gibt, dass ESG-Daten Investoren wertvolle Einsichten darüber vermitteln können, wie gut ein Unternehmen geführt wird, wo die wesentlichen Risiken liegen und wie nachhaltig das Geschäftsmodell und die Geschäftspraktiken tatsächlich sind.
<G-vec00092-001-s136><insist.bestehen><en> Nonetheless, both he and Waygood insist there is overwhelming evidence ESG data can give investors valuable insight into how well a business is run, where its material risks lie and how sustainable its business model and practices really are.
<G-vec00092-001-s137><insist.bestehen><de> Viele Projekte bestehen darauf, dass der potentielle Committer einen gewissen Grad an technischen Kentnissen und Ausdauer vorweist, indem er eine gewisse Anzahl nicht trivialer Patches einreicht – diese Projekte wollen also nicht nur wissen, dass die Person keinen Schaden anrichten wird, sondern auch das er sich wahrscheinlich im gesamten Quellcode bewähren wird.
<G-vec00092-001-s137><insist.bestehen><en> Many projects insist that the potential committer demonstrate a certain level of technical expertise and persistence, by submitting some number of nontrivial patches—that is, not only do these projects want to know that the person will do no harm, they want to know that she is likely to do good across the code base.
<G-vec00092-001-s138><insist.bestehen><de> In den Verhandlungen mit den Bolschewiki bestehen die Linken Sozialrevolutionäre darauf, die Kontrolle über wichtige Kommissariate zu erhalten.
<G-vec00092-001-s138><insist.bestehen><en> In the negotiations with the Bolsheviks, the Left SRs insist on gaining control over key Commissariats.
<G-vec00092-001-s139><insist.bestehen><de> Wärmer bestehen jedoch darauf, dass die Bodentemperaturen (oberflächennah) korrigiert werden, um die Auswirkungen der städtischen Wärmeinsel zu korrigieren.
<G-vec00092-001-s139><insist.bestehen><en> Warmers insist, nevertheless, that the ground (near-surface) temperatures are present corrected for urban heat island effects.
<G-vec00092-001-s140><insist.bestehen><de> Wir bestehen aber nicht darauf, wenn die menschliche Natur sich ihr widersetzt.
<G-vec00092-001-s140><insist.bestehen><en> But we do not insist on it when the nature is not willing.
<G-vec00092-001-s141><insist.bestehen><de> Während Zionisten darauf bestehen, dass die Juden einer anderen Rasse angehören als europäische Christen, bestehen die Palästinenser darauf, dass europäische Juden nichts weiter sind als Europäer, und mit Palästina, seinem Volk oder seiner Kultur nichts zu tun haben.
<G-vec00092-001-s141><insist.bestehen><en> Whereas Zionism insists that Jews are a race separate from European Christians, the Palestinians insist that European Jews are nothing if not European and have nothing to do with Palestine, its people, or its culture.
<G-vec00092-001-s142><insist.bestehen><de> Manche Länder bestehen darauf.
<G-vec00092-001-s142><insist.bestehen><en> Some countries insist on these.
<G-vec00092-001-s143><insist.bestehen><de> Wurzeln Sie Klette, gießen Sie Wasser, bestehen Sie darauf und trinken Sie dreimal am Tag.
<G-vec00092-001-s143><insist.bestehen><en> Take roots burdock, pour water, insist and drink three times a day.
<G-vec00092-001-s144><insist.bestehen><de> Bandbreitenbeschränkungen – Abgesehen von Einschränkungen bei der Verbindung und Dateitypeinschränkungen bestehen einige VPNs darauf, die Bandbreite zu drosseln, nachdem ein bestimmter Übertragungsbetrag erreicht wurde.
<G-vec00092-001-s144><insist.bestehen><en> Bandwidth limitations – Apart from connection limitations and file type restrictions, a few VPNs insist on throttling bandwidth after a certain transfer amount has been met.
<G-vec00092-001-s145><insist.bestehen><de> Wir bestehen darauf, den Kunden die beste Qualität und den besten Service zu bieten.
<G-vec00092-001-s145><insist.bestehen><en> We insist to supply clients with the best quality and service.
<G-vec00092-001-s146><insist.bestehen><de> VPX Zero Carb SRO 2000g Wenn Sie ein Protein wollen, das keine fett- und fettfördernden Kohlenhydrate oder Fette enthält, bestehen Sie auf Zero Carb Protein!Zero-Carb-Protein: Einer der konsequentesten und effektivsten Wege, um Gewicht und unerwünschte Körperfett zu verlieren, ist durch den Verzehr einer proteinreichen / kohlenhydratarmen Diät (mit moderater...
<G-vec00092-001-s146><insist.bestehen><en> VPX Zero Carb SRO 2000g If you want a protein that contains no bodyfat- promoting carbohydrates or fats, insist on Zero Carb Protein!Zero Carb Protein: One of the most consistent and effective ways to lose weight and unwanted bodyfat is by consuming a high protein/low carbohydrate diet (with moderate dietary fat intake). This is primarily due to the fact that protein has a...
<G-vec00092-001-s147><insist.bestehen><de> Kipjatite 5 Minuten, dann nehmen Sie vom Feuer ab und bestehen Sie noch 1 Stunde.
<G-vec00092-001-s147><insist.bestehen><en> Boil 5 min., then remove from fire and insist 1 more hour.
<G-vec00092-001-s148><insist.bestehen><de> Bestehen Sie auf 100% Cross-Flow Quadrafiltration Whey Protein Isolat, das mit Whey Peptide Isolaten angereichert ist.
<G-vec00092-001-s148><insist.bestehen><en> Insist on 100% Cross-Flow Quadrafiltration Whey Protein Isolate enhanced with Whey Peptide Isolates.
<G-vec00092-001-s149><insist.bestehen><de> Man kann stattdessen mjatnyj den Tee trinken — überfluten Sie den Dessertlöffel der frischen Blätter der Minze mit dem Glas des kochenden Wassers, bestehen Sie 10-15 Minuten und trinken Sie nach dem Glas des Tees dreimal im Tag nach dem Essen.
<G-vec00092-001-s149><insist.bestehen><en> It is possible to drink instead mint tea — fill in a dessertspoon of fresh leaves of mint with a glass of boiled water, insist 10-15 minutes and drink on a glass of tea three times a day after food.
<G-vec00092-001-s150><insist.bestehen><de> Brauen Sie und bestehen Sie für eine lange Zeit (5-7 Stunden).
<G-vec00092-001-s150><insist.bestehen><en> Brew and insist for a long time (5-7 hours).
<G-vec00092-001-s151><insist.bestehen><de> Bestehen Sie bei Verwendung eines Proxy-Servers auf vollständige Verschlüsselung, vor allem wenn Sie auf sensible Websites wie die zu Ihrem Bankkonto zugreifen.
<G-vec00092-001-s151><insist.bestehen><en> Whenever using a proxy service, insist on full encryption, especially when accessing sensitive sites like your bank account.
<G-vec00092-001-s152><insist.bestehen><de> VPX Zero Carb SRO 2000g Wenn Sie ein Protein wollen, das keine fett- und fettfördernden Kohlenhydrate oder Fette enthält, bestehen Sie auf Zero Carb Protein!Zero-Carb-Protein: Einer der konsequentesten und effektivsten Wege, um Gewicht und unerwünschte Körperfett zu verlieren, ist durch den Verzehr einer proteinreichen / kohlenhydratarmen Diät (mit...
<G-vec00092-001-s152><insist.bestehen><en> VPX Zero Carb SRO 2000g If you want a protein that contains no bodyfat- promoting carbohydrates or fats, insist on Zero Carb Protein!Zero Carb Protein: One of the most consistent and effective ways to lose weight and unwanted bodyfat is by consuming a high protein/low carbohydrate diet (with moderate dietary fat intake). This is primarily due to the fact...
<G-vec00092-001-s153><insist.bestehen><de> Sei fest und bestehen Sie auf Ihre Rechte.
<G-vec00092-001-s153><insist.bestehen><en> Be firm and insist on your rights .
<G-vec00092-001-s154><insist.bestehen><de> Um dies zu tun, sollte die Hälfte der Wurzel von Ara ein Glas Wodka und ein Glas Wasser gegossen werden, bestehen Sie für 10 Tage.
<G-vec00092-001-s154><insist.bestehen><en> To do this, half of the root of ara should be poured a glass of vodka and a glass of water, insist for 10 days.
<G-vec00092-001-s155><insist.bestehen><de> Überfluten Sie das Gras zu Wasser und bestehen Sie nicht weniger als Stunde.
<G-vec00092-001-s155><insist.bestehen><en> Fill in a grass with water and insist not less than an hour.
<G-vec00092-001-s156><insist.bestehen><de> Mischen Sie einen Esslöffel Kamille, Johanniskraut und Ringelblume, gießen Sie zwei Tassen kochendes Wasser und bestehen Sie für eine Stunde.
<G-vec00092-001-s156><insist.bestehen><en> Mix one tablespoon of chamomile, St. John's wort and marigold, pour two cups of boiling water and insist for one hour.
<G-vec00092-001-s157><insist.bestehen><de> Bedecken Sie die Dose vom Mull und bestehen Sie 2 Tage auf dem Licht bei der Zimmertemperatur.
<G-vec00092-001-s157><insist.bestehen><en> Cover to bank with a gauze and insist 2 days on light at the room temperature.
<G-vec00092-001-s158><insist.bestehen><de> Zeile 17: Die Zahl nach dem / Zeichen, gibt die Anzahl der Bits der Adresse an, auf die ppp besteht.
<G-vec00092-001-s158><insist.bestehen><en> Line 17: The number after the / character is the number of bits of the address that ppp will insist on.
<G-vec00092-001-s159><insist.bestehen><de> Fleisch besteht mindestens sechs Stunden in Salzlake.
<G-vec00092-001-s159><insist.bestehen><en> Meat insist at least six hours in brine.
<G-vec00092-001-s160><insist.bestehen><de> Nolte besteht nicht nur auf der innigen Verbindung zwischen Heideggers Philosophie und seiner Unterstützung für den Nationalsozialismus, sondern er verteidigt auch den Nationalsozialismus als notwendige Reaktion auf die innere und äußere Bedrohung durch die russische Revolution.
<G-vec00092-001-s160><insist.bestehen><en> Not only does Nolte insist on the intimate connection between Heidegger's philosophy and his Nazism, but he also defends Nazism as a necessary response to the internal and external threat posed by the Russian Revolution.
<G-vec00092-001-s161><insist.bestehen><de> Odinga besteht stattdessen weiterhin auf der Tatsache, dass er sagte, die Wahl sei ein Betrug.
<G-vec00092-001-s161><insist.bestehen><en> "Odinga instead continues to insist on the fact that he said the election was a fraud"", he concludes."
<G-vec00092-001-s162><insist.bestehen><de> Eine Gruppe deutscher Forscher des Instituts für molekulare Virologie an der Universität Münster besteht auf einer Tasse Tee anstatt des zweiten oder dritten Bechers Kaffee.
<G-vec00092-001-s162><insist.bestehen><en> A group of German researchers from the Institute of Molecular Virology, at the University of Münster in Germany, insist on a cup of tea instead of pouring that second or third cup of coffee.
<G-vec00092-001-s163><insist.bestehen><de> Nicht einmal Franz von Sales besteht auf ihrer allgemeinen Notwendigkeit.
<G-vec00092-001-s163><insist.bestehen><en> Even St. Francis de Sales does not insist on its universal necessity.
<G-vec00092-001-s164><insist.bestehen><de> Ein Esslöffel wird mit 250 ml kochendem Wasser übergossen, 15 Minuten lang im Feuer gehalten und besteht bis zu einer halben Stunde.
<G-vec00092-001-s164><insist.bestehen><en> One tablespoon is poured 250 ml of boiling water, kept on the fire for 15 minutes and insist up to half an hour.
<G-vec00092-001-s165><insist.bestehen><de> Der Besteller hat auf unser Verlangen innerhalb einer angemessenen Frist zu erklären, ob er wegen eines Sachmangels vom Vertrag zurücktritt oder weiter auf Lieferung besteht.
<G-vec00092-001-s165><insist.bestehen><en> The purchaser shall declare upon our request within a reasonable period of time, whether he rescinds the contract because of a material defect of quality or continues to insist on delivery .
<G-vec00092-001-s166><insist.bestehen><de> Eine wachsende Anzahl Ihrer Kunden besteht auf einer unabhängigen, externen Zertifizierung des Elektronik-Recyclings, um zu überprüfen, ob Ihr Recycling-Managementsystem den höchsten Anforderungen gerecht wird.
<G-vec00092-001-s166><insist.bestehen><en> An increasing number of your customers will insist on independent, third party electronic recycling certification to verify compliance of your recycling management system with a highest requirements.
<G-vec00092-001-s167><insist.bestehen><de> Nichts ist positiv, alles nur negativ: Der Zoll besteht auf einer Kaution von US$4000, das Transportministerium will uns kein temporäres Nummernschild erteilen und offensichtlich ist man – übrigens wie in Japan – vom Gesetz her gezwungen, ein lokales Kennzeichen anzubringen.
<G-vec00092-001-s167><insist.bestehen><en> Nothing is positive, everything is negative: The Customs continues to insist on a bond of US$4'000, the Ministry of Transport is not willing to give us a temporary local license plate, and apparently having a local license plate is enforced by law – as it was the case also in Japan .
<G-vec00092-001-s168><insist.bestehen><de> Für Hunde besteht aus Sicherheitsgründen Maulkorb- und Leinenpflicht.
<G-vec00092-001-s168><insist.bestehen><en> For security reasons we insist on dogs being muzzled and leashed.
<G-vec00092-001-s169><insist.bestehen><de> 5.8 Der Kunde ist verpflichtet, auf Verlangen von IPOQUE innerhalb einer angemessenen Frist zu erklären, ob er wegen Verzugs der Lieferungen und/oder Leistungen vom Vertrag zurücktritt und/oder Schadensersatz statt der Leistung oder Schadenser- satz neben der Leistung verlangt oder auf der Lieferung und/oder Leistung besteht.
<G-vec00092-001-s169><insist.bestehen><en> 5.8 At the request of IPOQUE, the Customer shall state within a reasonable period whether it will withdraw from the contract due to delayed Deliveries and/or Services and/or whether it will claim damages in lieu of performance or damages in addition to per- formance or will insist on the Delivery and/or Service.
<G-vec00092-001-s170><insist.bestehen><de> Jianke besteht auf dem Ziel „verfolgen ausgezeichnete Produkte, globalen Markt zu bedienen“.
<G-vec00092-001-s170><insist.bestehen><en> "JIANKE insist on the goal of ""pursue excellent products, serve global market""."
<G-vec00092-001-s171><insist.bestehen><de> Wenn Ihr selbst Lehrer werdet, besteht auf der sofortigen Ausführung eines Befehles.
<G-vec00092-001-s171><insist.bestehen><en> When you yourselves become teachers, insist on the immediate fulfilling of your instructions.
<G-vec00035-001-s037><redeem.bestehen><de> Unter den schützenden Flügeln Malagas groß geworden, hat es Torremolinos in letzter Zeit verstanden sich loszulösen, indem es sich mit einem kompletten touristischen Angebot (heute sind in dieser Stadt 40% der Hotelstrukturen der Costa del Sol konzentriert) präsentiert, das aus Sport, Infrastrukturen und einer beneidenswerten Promenade am Meer besteht.
<G-vec00035-001-s037><redeem.bestehen><en> Growing up under the protective wing of Malaga, Torremolinos has recently been able to redeem itself, posing with a complete tourist offer (the 40% of the hotels of the Costa del Sol are concentrated here), made up of sports, infrastructures, and an enviable seafront promenade.
<G-vec00035-001-s038><redeem.bestehen><de> Die Pfarrei muss eine große Gemeinschaft sein, die aus kleinen Gemeinschaften und gemeinschaftlichen Erlebnissen besteht, innerhalb derer es möglich ist, den personalisierenden Wert dieser Begegnung zu erlangen.
<G-vec00035-001-s038><redeem.bestehen><en> The parish must articulate itself as a great community of small communities and communal experiences in which it becomes possible to redeem the personalizing value of the meeting.
<G-vec00206-001-s121><comprise.bestehen><de> » (1) Der Vorstand besteht aus wenigstens zwei Mitgliedern.
<G-vec00206-001-s121><comprise.bestehen><en> """(1) The Board of Management shall comprise at least two members."
<G-vec00206-001-s122><comprise.bestehen><de> Jede dieser Villen in Kemer besteht aus einem großen Wohnzimmer, offener Küche und einem Badezimmer mit Dusche und 2 schönen Terrassen im Erdgeschoss.
<G-vec00206-001-s122><comprise.bestehen><en> Each of these villas in Kemer comprise of a large living room area, open plan kitchen and a bathroom with a shower and 2 nice terraces on the ground floor.
<G-vec00206-001-s123><comprise.bestehen><de> Die Arbeitsgruppe besteht aus Vertretern der WHO, der italienischen Ministerien für Gesundheit, Inneres und internationale Zusammenarbeit, des italienischen Instituts für Gesundheit, Migration und Armut (NIHMP) und des Italienischen Roten Kreuzes.
<G-vec00206-001-s123><comprise.bestehen><en> Its members comprise representatives of WHO; the Italian ministries of health, interior and cooperation; the Sicilian health authorities; the National Institute for Health, Migration and Poverty (NIHMP); and the Italian Red Cross.
<G-vec00206-001-s124><comprise.bestehen><de> "Die Apartments mit Extra-Service haben in der Regel eine 24 Stunden-Rezeption – der ""Apartment Manager"" besteht aus einem kleinen Team, welches das ganze Gebäude betreut."
<G-vec00206-001-s124><comprise.bestehen><en> "In the case of serviced apartments which have 24 hour reception - the ""apartment manager"" may comprise the small team of people who run the building."
<G-vec00206-001-s125><comprise.bestehen><de> Der Komplex besteht aus 2 und 3 Schlafzimmer Wohnungen im Erdgeschoss, im ersten Stock sowie dúplex Penthouses viele von denen genießen einen herrlichen Meerblick.
<G-vec00206-001-s125><comprise.bestehen><en> The complex comprise 2 and 3 bedroom apartments on ground floor, first floor as well as dúplex penthouses many of which enjoy magnificent sea views.
<G-vec00206-001-s126><comprise.bestehen><de> Der komplett neugestaltete Luxusbungalow Castello Deluxe Bungalow besteht aus einem großen Schlafzimmer mit Schlafsofa, auf Wunsch auch direkt mit einem dritten Bett.
<G-vec00206-001-s126><comprise.bestehen><en> Now fully refurbished, the opulent Castello Deluxe Bungalows comprise a spacious double bedroom with sofa bed or a third bed on request.
<G-vec00206-001-s127><comprise.bestehen><de> Das Gelände besteht aus einer Ausstellung zur ehemaligen All Saints Church, dem Observatorium Stjerneborg, dem nachgebauten Renaissance Garten, einem gestaffelten Weg, der einem die Entfernung der Planeten verdeutlichten soll und einem Spielplatz, auf welchem die Kinder an historischen Spielen Spaß haben und gleichzeitig etwas dazu lernen können.
<G-vec00206-001-s127><comprise.bestehen><en> The premises comprise of an exhibition on the former All Saints Church, the observatory Stjerneborg, the observatory Stjerneborg, the recreated Renaissance garden, a phased path that shall symbolize the distance between the planets and a playground where children can enjoy historical games and, simultaneously, learn something.
<G-vec00206-001-s128><comprise.bestehen><de> Das Team von Affinity besteht aus 1.100 Experten mit Zentrale in Barcelona und weiteren Niederlassungen in Paris, Mailand und Sao Paolo.
<G-vec00206-001-s128><comprise.bestehen><en> More than 1.100 professionals comprise Affinity and conduct their work and passion from our headquarters in Barcelona, and in our offices in Paris, Milan or Sao Paolo.
<G-vec00206-001-s129><comprise.bestehen><de> (16) Das Internationale Überwachungssystem besteht aus Einrichtungen für seismologische Überwachung, Radionuklid-Überwachung einschließlich anerkannter Laboratorien, hydroakustische Überwachung, Infraschall-Überwachung und den entsprechenden Kommunikationsmitteln und wird vom Internationalen Datenzentrum des Technischen Sekretariats unterstützt.
<G-vec00206-001-s129><comprise.bestehen><en> The International Monitoring System shall comprise facilities for seismological monitoring, radionuclide monitoring including certified laboratories, hydroacoustic monitoring, infrasound monitoring, and respective means of communication, and shall be supported by the International Data Centre of the Technical Secretariat.
<G-vec00206-001-s130><comprise.bestehen><de> "Die organische und gedruckte Elektronik: Sie wird auch ""Elektronik der Kunststoffe"" genannt und besteht aus organischen Halbleitern, flexiblen Unterlagen, alle in dünnen Schichten gedruckt."
<G-vec00206-001-s130><comprise.bestehen><en> Organic and printed electronics: Printed electronics and organic or plastic electronics comprise organic semiconductors and flexible substrates, all printed in very thin layers.
<G-vec00206-001-s131><comprise.bestehen><de> Unser Vorstand besteht aus Managing Partner Lars Lokdam sowie den PartnernRené Lykke Wethelundund Stefan Reinel.
<G-vec00206-001-s131><comprise.bestehen><en> Our board of directors comprise of Managing Partner Lars Lokdam, Partner René Lykke Wethelund and Partner Stefan Reinel.
<G-vec00206-001-s132><comprise.bestehen><de> (49) Das Technische Sekretariat besteht aus einem Generaldirektor, der dessen Leiter und höchster Verwaltungsbeamter ist, sowie aus dem benötigten wissenschaftlichen, technischen und sonstigen Personal.
<G-vec00206-001-s132><comprise.bestehen><en> 49. The Technical Secretariat shall comprise a Director-General, who shall be its head and chief administrative officer, and such scientific, technical and other personnel as may be required.
<G-vec00206-001-s133><comprise.bestehen><de> Jede Einheit besteht aus einer Stammaktie des Unternehmens und einem halben Warrant auf den Kauf einer weiteren Stammaktie des Unternehmens.
<G-vec00206-001-s133><comprise.bestehen><en> Each unit will comprise one common share of the company and one-half of one common share purchase warrant of the company.
<G-vec00206-001-s134><comprise.bestehen><de> Die Freilaufführanlage besteht aus mehreren Treibgittern, die durch Arme an der Motorkonsole befestigt sind.
<G-vec00206-001-s134><comprise.bestehen><en> The horse exercisers comprise a number of drift fences, which are attached to the motor console by means of arms.
<G-vec00206-001-s135><comprise.bestehen><de> Die Übungsanlage besteht aus einem Putting Green, einer Pitching- und Chipping-Anlage sowie einer Driving Range.
<G-vec00206-001-s135><comprise.bestehen><en> The practice facilities comprise a putting green, a pitching and chipping area and a driving range.
<G-vec00206-001-s136><comprise.bestehen><de> Jedes Bauvorhaben oder jede Entwicklung besteht in der Regel aus mehreren Phasen.
<G-vec00206-001-s136><comprise.bestehen><en> Any construction project or development will generally comprise of several stages.
<G-vec00206-001-s137><comprise.bestehen><de> Dieser Fonds besteht aus Zuschüssen von einheimischen und Ausländern, Förderungen von der Regierung Sri Lankas und Einkünften aus den Besitzen der Assoziation und anderen Finanzierungsmodellen.
<G-vec00206-001-s137><comprise.bestehen><en> This Fund shall comprise of aid granted by locals and foreigners, grants from the Government of Sri Lanka, and income derived from the properties belonging to the Association and various other sources of income.
<G-vec00206-001-s138><comprise.bestehen><de> Die Vergütung besteht nach wie vor aus fixen und variablen, kurz- und langfristigen Komponenten.
<G-vec00206-001-s138><comprise.bestehen><en> The compensation continues to comprise fixed, variable, short-term and long-term components.
<G-vec00206-001-s139><comprise.bestehen><de> Knuthenlunds landwirtschaftliche Betrieb besteht aus insgesamt 650 Hektar, auf denen unter anderem Futtermittel für Tiere und Öland-Weizen, Spelz, Weichweizen, Roggen, Hafer, Gerste, Weißklee, grüne Erbsen auf Ardo/Frigodan, Winterbohnen und Ölrettich für Samen angebaut werden.
<G-vec00206-001-s139><comprise.bestehen><en> Knuthenlund's fields comprise a total of 650 hectares, planted with animal feed and Öland wheat, spelt, common wheat, rye, oats, barley, white clover, green peas for Ardo/Frigodan A/S, winter broad beans and oilseed radishes for the seed.
<G-vec00092-001-s172><insist.bestehen><de> Wenn ein Bruder, eure Eltern oder eure Kinder krank sind, so bittet für sie, aber besteht nicht darauf, dass sie in diesem Leben verbleiben, wenn dies nicht das ist, was der Geist benötigt.
<G-vec00092-001-s172><insist.bestehen><en> If your brother or sister, your parents, or your children are ill, pray for them, but do not insist that they stay in this life if that is not what the spirit needs.
<G-vec00092-001-s173><insist.bestehen><de> Die Polizei besteht jedoch immer noch darauf, dass er im Gefängnis bleiben soll.
<G-vec00092-001-s173><insist.bestehen><en> The police still insist that he remain in prison.
<G-vec00092-001-s174><insist.bestehen><de> Aber er besteht weiterhin darauf, dass er in der Lage war, auf seiner Familie Hilfe rufen.
<G-vec00092-001-s174><insist.bestehen><en> But he continued to insist that he was able to call on his family’s help.
<G-vec00092-001-s175><insist.bestehen><de> Die Halacha verweigert dem durch einen Suizid gestorbenen die Ehre einer Grabrede, weiterhin das Übergeben der Kleidung durch die Verwandten oder Zeugen des Toten und sie besteht (gemäß Maimonides) darauf, dass die Verwandten nicht die gewöhnliche Trauerzeit für den Suizidierten beachten müssen.
<G-vec00092-001-s175><insist.bestehen><en> The Halakhah denies to the suicide the honor of a eulogy, the rending of the garments by relatives or witnesses to the death, and (according to Maimonides) insist that the relatives are not to observe the usual mourning period for the suicide.
<G-vec00092-001-s176><insist.bestehen><de> Der Anti-Atom-Lobby dagegen besteht darauf, dass die Reaktoren in den kommenden Jahren keinen Nettogewinn erzielen werden, weil die Kosten der Unterhaltung der veralteten Reaktoren steigen ständig.
<G-vec00092-001-s176><insist.bestehen><en> The anti-nuclear lobby, on the other hand, insist that the reactors will not make any net income in coming years, given that the costs for maintenance of the ageing reactors are increasing rapidly.
<G-vec00092-001-s177><insist.bestehen><de> Auch wenn das Foto der des Lachses eher einer Forelle ähnelt, die gerade aus dem Wasser schnellt, besteht Microgaming darauf, dass dies ein Lachs ist.
<G-vec00092-001-s177><insist.bestehen><en> When also look keenly, there is a trout that normally pops out of water but some still insist that it’s a salmon.
<G-vec00092-001-s178><insist.bestehen><de> Sie besteht darauf dass mein Gehirn die gesamte Erfahrung erschaffen hatte, dass alle Nah-Tod-Erfahrungen Aktivitäten des Gehirns sind, nichts weiter.
<G-vec00092-001-s178><insist.bestehen><en> She would like to insist that my brain was creating the entire experience, that all near death experiences are the brain's activity, nothing more.
<G-vec00092-001-s215><insist.bestehen><de> Er war kein telepathischer Gesprächspartner, außer, dass er darauf bestand, dass ich ihm gehorchen sollte, ein Befehl, den er mehrmals wiederholte.
<G-vec00092-001-s215><insist.bestehen><en> He was not a telepathic conversationalist except to insist that I was to obey him, a command he repeated several times.
<G-vec00092-001-s216><insist.bestehen><de> Ab 1933 rief Trotzki zur politischen Revolution auf, um die stalinistische Bürokratie zu stürzen, während er weiterhin darauf bestand, dass es die Aufgabe des Proletariats international ist, den ersten Arbeiterstaat der Welt gegen Versuche einer internen und externen kapitalistischen Restauration militärisch zu verteidigen.
<G-vec00092-001-s216><insist.bestehen><en> In 1933, Trotsky called for a political revolution to oust the bureaucracy, while continuing to insist that it was the duty of the proletariat internationally to militarily defend the world's first workers state from internal or external attempts at capitalist restoration.
<G-vec00092-001-s217><insist.bestehen><de> Eine Woche vor ihrem Tod hatte der zuständige Sozialarbeiter nicht darauf bestanden, das Kind zu sehen.
<G-vec00092-001-s217><insist.bestehen><en> A week before her death the social worker assigned to her case did not insist on seeing the child.
<G-vec00092-001-s218><insist.bestehen><de> Wir antworteten, dass wir im Prinzip darauf bestanden, das ganze Gesetz zu annullieren, würden aber das Streichen dieser Worte begrüßen.
<G-vec00092-001-s218><insist.bestehen><en> We answered that in principle we insist on annulling the entire law, but would welcome the striking out of these words.
<G-vec00092-001-s219><insist.bestehen><de> Aber Zikode hat oft darauf bestanden, dass „unsere hausgemachte Politik“ derart beschaffen sein muss, dass „jede alte gogo (Großmutter) sie verstehen kann“.
<G-vec00092-001-s219><insist.bestehen><en> But Zikode has often taken care to insist that ‘our homemade politics’ must be ‘made by everyone together so that every old gogo (grandmother) can understand it’.
<G-vec00092-001-s220><insist.bestehen><de> ... das jüdische Volk hat sie (die dreifache Unterteilung des Gesetzes) nicht anerkannt oder hat wenigstens nicht darauf bestanden.
<G-vec00092-001-s220><insist.bestehen><en> """…the Jewish people either did not acknowledge it (the three-fold division) or at least did not insist on it."
<G-vec00092-001-s221><insist.bestehen><de> Es ist so viele fabriken von hölzernen tee box in shenzhen, aber wir haben darauf bestanden, dass kunden zuerst, zuerst service und qualität zuerst.
<G-vec00092-001-s221><insist.bestehen><en> It's so many factories of wooden tea box in shenzhen,but, we have insist that customers first, service first, and quality first.
<G-vec00092-001-s222><insist.bestehen><de> Es ist nicht so, dass Ich darauf bestehe, auf Meine eigene Weise einzutreten.
<G-vec00092-001-s222><insist.bestehen><en> It is not that I insist upon entering in My own way.
<G-vec00092-001-s223><insist.bestehen><de> Es ist ziemlich dasselbe mit dieser Sache, ungeachtet dessen ob es astrale Projektion, Visionen, hellseherische und manchmal wiederkehrende Nacht- oder Tagträume, NTEs sind oder, wie ich darauf bestehe was meine war, eine FPTE ist.
<G-vec00092-001-s223><insist.bestehen><en> It's much the same with this topic albeit, astral projection, visions, precognitive and sometimes recurring night or day dreams, NDE's or, as I insist mine was, NPDE's.
<G-vec00092-001-s224><insist.bestehen><de> Die Israelis, darauf bestehe ich.
<G-vec00092-001-s224><insist.bestehen><en> "The Israelis, I insist. ""No way."
<G-vec00092-001-s226><insist.bestehen><de> "Da die Republikaner darauf bestehen, ein Spiel zu spielen, das sie und die weißen Amerikaner nur verlieren können, hat die Verächtlichmachung der Alten Rechten als ""Kuckservative"" einen Nerv getroffen und hat sich wie ein Lauffeuer verbreitet."
<G-vec00092-001-s226><insist.bestehen><en> "Because Republicans insist on playing a game that they, and white Americans, can only lose, the alt-Right slur ""cuckservative"" has struck a chord and gone viral."
<G-vec00092-001-s227><insist.bestehen><de> Europäische Regierungen sollten daher darauf bestehen, dass eindeutige Beweise dafür erbracht werden, dass die syrische Regierung selber für diese Untaten, sofern es sie denn überhaupt gegeben hat, verantwortlich ist.
<G-vec00092-001-s227><insist.bestehen><en> European governments should insist that clear evidence is provided that the Syrian government is ever responsible for these crimes itself, unless they have taken place at all.
<G-vec00092-001-s228><insist.bestehen><de> Jeder, der feststellt, dass er sich offensichtlich in Nichtexistenz, Belastung oder schlimmer befindet, sollte sich schnellstens darum bemühen, die Kommunikationslinien zu finden, die zu seiner Tätigkeit und zu seinem Posten gehören, und er sollte darauf bestehen, dass er auf diese Linien gesetzt wird.
<G-vec00092-001-s228><insist.bestehen><en> Anyone who finds himself in apparent Non-Existence or worse, should rush around and find the communication lines that apply to his activity and post and insist that he be put on those lines.
<G-vec00092-001-s229><insist.bestehen><de> Wie dumm war ich nicht darauf bestehen, dass ein Bericht geschrieben werden.
<G-vec00092-001-s229><insist.bestehen><en> How foolish was I not to insist that a report be written.
<G-vec00092-001-s230><insist.bestehen><de> Gleichzeitig müssen wir jedoch darauf bestehen, dass Verstaatlichungen Hand in Hand mit einer echten ArbeiterInnenkontrolle und –verwaltung gehen müssen.
<G-vec00092-001-s230><insist.bestehen><en> At the same however, we must insist that nationalisation must go hand in hand with genuine democratic workers' control and management.
<G-vec00092-001-s231><insist.bestehen><de> So lautet nämlich die Anschuldigung denjenigen gegenüber, die darauf bestehen, dass die Lehren der Schrift sich nicht widersprechen können.
<G-vec00092-001-s231><insist.bestehen><en> This is the charge made against those who insist that the teachings of God's Word cannot contradict each other.
<G-vec00092-001-s232><insist.bestehen><de> All dies wurde vГ¶llig unerwartet für die Verwaltung von ABC, die weiterhin darauf bestehen, dass B«Wir sind Nachbarn!B» - Das ist eine positive Vision.
<G-vec00092-001-s232><insist.bestehen><en> All this was totally unexpected for the management of ABC, which continues to insist that «We will be neighbors!» - this is a positive vision.
<G-vec00092-001-s233><insist.bestehen><de> Diejenigen, die darauf bestehen, Israel zu unterstützen, müssen wissen, dass sie ein hemmungsloses Apartheidregime unterstützen.
<G-vec00092-001-s233><insist.bestehen><en> Those who insist on supporting Israel must know that they are supporting an unabashed Apartheid regime.
<G-vec00092-001-s234><insist.bestehen><de> Beide Handlungen sind eindeutig zu hart von den großen Medien-Industrie, die zu denken, dass Online-Piraterie ist, warum sie Probleme haben, und tatsächlich, die darauf bestehen, dass sie mit allen Arten von Ärger und sie sind sofort andernfalls scheinen geschoben wenn etwas-doesnt, wenn die Gesetzgebung nicht bestanden wird sofort, sie werden alle untergehen, das ist nicht wahr.
<G-vec00092-001-s234><insist.bestehen><en> Both of these acts are clearly being pushed hard by the big media industries, who seem to think that online piracy is why they’re having trouble, and actually, who insist that they’re having all kinds of trouble and they’re failing immediately if something doesn’t—if legislation isn’t passed immediately, they’re going to all go under, which is not true.
<G-vec00092-001-s235><insist.bestehen><de> Das Problem, nach Wilson, ist, dass die aktuellen Tests nicht erfassen kann die neue Stämme von Bakterien, die entstanden sind in den letzten Jahren, Verlassen Patienten, die grassierende Infektion länger darauf bestehen, während die Ärzte, dass ihre Symptome nicht geheimnisvoll sind ein Beweis für Lyme-Borreliose.
<G-vec00092-001-s235><insist.bestehen><en> The problem, according to Wilson, is that the current tests are not capable of detecting the novel strains of the bacteria that have arisen in recent years, leaving patients exposed to rampant infection for longer while doctors insist that their mysterious symptoms are not evidence of Lyme disease.
<G-vec00092-001-s236><insist.bestehen><de> Wenn Sie also darauf bestehen, mit diesem Sakrileg fortzufahren, sind wir bereit, eine Nachtwache einzurichten und alles erforderliche zu tun...um sie daran zu hindern.
<G-vec00092-001-s236><insist.bestehen><en> So if you insist on going through with this, we are prepared to maintain a vigil and do whatever it takes to stop you.
<G-vec00092-001-s237><insist.bestehen><de> Und darüber hinaus pflegen Theoretiker von Kierkegaard bis Schelling bis Hegel darauf zu bestehen, dass jene sozialen Praktiken bloß innerhalb und wegen der weiteren Kontexte des Geistes existieren.
<G-vec00092-001-s237><insist.bestehen><en> And further yet, theorists from Kierkegaard to Schelling to Hegel would insist that those social practices only exist in and because of the larger contexts of Spirit.
<G-vec00092-001-s238><insist.bestehen><de> Während die Welle der spirituellen Entwicklung sich beschleunigt, werden es jene, die darauf bestehen in den alten Paradigmen zu bleiben, zunehmend schwieriger finden.
<G-vec00092-001-s238><insist.bestehen><en> As the wave of spiritual evolution accelerates, those who insist upon living in the old paradigms will find it increasingly difficult.
<G-vec00092-001-s239><insist.bestehen><de> Obwohl einige Vermieter in Rumänien informelle mündliche Vereinbarungen bevorzugen, um die Zahlung von Einkommenssteuern zu vermeiden, sollten Sie darauf bestehen, dass ein formeller Vertrag unterzeichnet wird, um sich als Mieter zu schützen.
<G-vec00092-001-s239><insist.bestehen><en> Even though some landlords in Romania prefer informal verbal agreements in order to avoid paying income taxes, you should insist that a formal contract be signed, in order to protect yourself as a tenant.
<G-vec00092-001-s240><insist.bestehen><de> Die Brühe aus der Hüfte zu nehmen mehr Nährstoffe — erste Hagebutte Kochen in einem geschlossenen Behälter, dann darauf bestehen, 12 Stunden.
<G-vec00092-001-s240><insist.bestehen><en> The broth from the hips take more nutrients — first rosehip boil in a sealed container, then insist 12 hours.
<G-vec00092-001-s241><insist.bestehen><de> Es war eine gute politische Bewegung, darauf zu bestehen, dass die Kurse waren lehrte dort in der niederländischen Sprache.
<G-vec00092-001-s241><insist.bestehen><en> It was a good political move to insist that the courses were taught there in the Dutch language.
<G-vec00092-001-s242><insist.bestehen><de> 2.APEX darauf bestehen Qualität kommt zuerst.
<G-vec00092-001-s242><insist.bestehen><en> 2.APEX insist quality comes first.
<G-vec00092-001-s243><insist.bestehen><de> Als ich meinen Kaplan schickte, um darauf zu bestehen, dass sie und meine Töchter [Lucrezia und Eleonore] die Messe hörten, weigerte sie sich, meinen Anweisungen zu gehorchen, und schickte den Priester weg, ohne ihm erlaubt zu haben, die besagte Messe zu zelebrieren....
<G-vec00092-001-s243><insist.bestehen><en> When I sent my chaplain to insist that she and my daughters [Lucrezia and Eleonora] should hear the mass, she declined to obey my commands and sent away the priest without permitting him to celebrate the said mass...
<G-vec00092-001-s244><insist.bestehen><de> Sie wissen, kann mich von meinem Signale Service oder von anderen Produkten, und wenn Sie das tun- Sie wissen, dass ich den Hintergrund jeder Strategie gründlich auf das Verständnis vor dem Handel immer darauf bestehen,.
<G-vec00092-001-s244><insist.bestehen><en> You may know me from my signals service or from other products, and if you do- you know that I always insist on understanding the background of every strategy thoroughly before trading.
<G-vec00092-001-s245><insist.bestehen><de> Was auch immer in den nächsten Monaten in San Salvador Atenco passieren wird - ob die Gefangene befreit werden oder nicht, ob Marcos wie versprochen in Atenco bleibt, bis der letzte freigekommen ist oder nicht, ob es Amtsenthebungen geben wird oder nicht, ob die Regierung weiterhin darauf besteht, dass die EZLN die Waffen niederlegt - die Präsidentschaftswahlen werden wie vorgesehen stattfinden.
<G-vec00092-001-s245><insist.bestehen><en> Whatever occurs in the next months in San Salvador Atenco - whether or not the prisoners are freed, whether or not Marcos remains in Atenco, as he promised, until the last one is released, whether there are impeachments or not, whether the government continues to insist that the EZLN disarm - the presidential elections will go on as scheduled.
<G-vec00092-001-s246><insist.bestehen><de> "Die dortigen Aufseher sagen zu ihnen: ""Wir wissen, dass ihr alle gute Menschen seid, aber wenn ihr darauf besteht, Falun Gong zu praktizieren, werdet ihr im Gefängnis bleiben, eure Familien werden leiden, auch wir kommen in Schwierigkeiten und die beobachtenden Gefangenen bekommen keine Haftverkürzung."
<G-vec00092-001-s246><insist.bestehen><en> "Guards in the prison tell practitioners, ""I know you are all good people but if you insist on practising Falun Gong, you will stay in prison, your family will suffer, we will be in trouble, and the prisoners monitoring you won't get reduced sentences."
<G-vec00092-001-s247><insist.bestehen><de> Ihr seid nicht diese sündige Person mit schwachem Fleisch, wie ihr darauf besteht es zu sein.
<G-vec00092-001-s247><insist.bestehen><en> You are not this weak-blooded erring person that you insist you are.
<G-vec00092-001-s248><insist.bestehen><de> Alter: 40 und etwas...okay,..44 wenn Ihr darauf besteht.
<G-vec00092-001-s248><insist.bestehen><en> Age: 40 something...oh well,..44 if you insist.
<G-vec00092-001-s249><insist.bestehen><de> Die Vorstellung, daß eine Unendlichkeit von aufeinanderfolgenden Zuständen logisch unmöglich sei, stimmt nur, wenn man darauf besteht, sie sollte beendet werden, d.h. sie hätte einen Anfang haben müssen, was genau der Streitpunkt.
<G-vec00092-001-s249><insist.bestehen><en> The notion that an infinity of successive states is logically impossible is true only if we insist that it must be completed, that is, that it must have had a beginning, which is the very point at issue.
<G-vec00092-001-s250><insist.bestehen><de> Es könnte auch sein, dass die französische Bank, an der Sie interessiert sind, darauf besteht, dass Sie eine Anschrift in Frankreich angeben können.
<G-vec00092-001-s250><insist.bestehen><en> Or the French bank you are interested in may insist that you have a local address.
<G-vec00092-001-s251><insist.bestehen><de> Bitte gebt Euren vollständigen Namen (oder wenn Ihr unbedingt darauf besteht Euer Pseudonym) an, so daß wir Euer Gedicht oder Eure Geschichte richtig zuordnen.
<G-vec00092-001-s251><insist.bestehen><en> Please provide your full name (or, if you absolutely insist, your pseudonym), so we can attribute your poem correctly.
<G-vec00092-001-s252><insist.bestehen><de> "Das heißt, zwischen 23 Stunden: 30 - 07: 00 kann nicht angerufen werden und kann nur Nachrichten von Personen in der ""Favoriten""Oder wenn derjenige, der mich anrufen will, darauf besteht und das zweite Mal klingt."
<G-vec00092-001-s252><insist.bestehen><en> "That is, between 23 hours: 30 - 07: 00 can not be called and can receive messages only from people in the ""Favorites""Or if the one who wants to call me insist and sound the second time."
<G-vec00092-001-s253><insist.bestehen><de> Paulus sagt in Galater 6,1-8, dass man in Demut jemanden zurück bringen soll, der in Sünde verfangen ist, aber wenn er/sie darauf besteht seinen/ihren eigenen Weg zu gehen, dann lass sie einfach weiter darin wandeln, denn Gott lässt sich nicht täuschen und er gibt jeden was er/sie gesät hat.
<G-vec00092-001-s253><insist.bestehen><en> Paul said in Galatians 6:1-8 to restore with meekness someone caught in sin, but if they insist on going their own way just let them walk it out, for God is not mocked, He gives to each of us what we have sown.
<G-vec00092-001-s277><insist.bestehen><de> Wie auch immer, es ist wichtig auf Grundlegendem zu bestehen.
<G-vec00092-001-s277><insist.bestehen><en> However, it's important to insist on the basics.
<G-vec00092-001-s278><insist.bestehen><de> Wie dem auch sei, es scheint infantil und anmaßend, immer auf vollständiger Zufriedenheit zu bestehen.
<G-vec00092-001-s278><insist.bestehen><en> At any rate, it seems childish and insolent to insist at all times on total gratification.
<G-vec00092-001-s326><insist.bestehen><de> 6.6 Der Kunde wird auf Anforderung innerhalb einer angemessenen Frist erklären, ob er wegen der Verzögerung der Lieferung vom Vertrag zurücktritt oder auf der Lieferung besteht.
<G-vec00092-001-s326><insist.bestehen><en> 6.6 The Customer shall upon request within a reasonable time limit state whether it shall withdraw from the Contract due to the Delivery being delayed or insist upon a Delivery.
<G-vec00092-001-s327><insist.bestehen><de> Der Besteller ist verpflichtet, auf Verlangen des Lieferers innerhalb einer angemessenen Frist zu erklären, ob er wegen der Verzögerung der Lieferung vom Vertrag zurücktritt oder auf der Lieferung besteht.
<G-vec00092-001-s327><insist.bestehen><en> The purchaser shall be obliged, at the supplier's request, to declare within a reasonable period whether or not he will withdraw from the contract due to the delay in delivery or insist on the delivery.
<G-vec00257-002-s330><fail.bestehen><de> Wir behalten uns das Recht vor, den Zugriff auf unsere Website und/oder unsere App zu entziehen und/oder Bestellungen zu stornieren, falls Sie eine Bonitätsprüfung oder eine Prüfung zur Betrugsbekämpfung nicht bestehen, oder falls wir nach vernünftigem Ermessen einen Verdacht haben auf Betrug oder Geldwäsche durch Sie oder jemanden, der Ihr Konto nutzt.
<G-vec00257-002-s330><fail.bestehen><en> We specifically reserve the right to withdraw access to our Website and/or our App and/or cancel any order in the event that you fail any credit or fraud prevention check or where we reasonably suspect fraud or money laundering by you or someone using your account.
<G-vec00257-002-s331><fail.bestehen><de> Wenn Sie eine Bewertung nicht bestehen, werden Sie auf den Inhalt des Kurses verwiesen, in dem diese Konzepte behandelt wurden.
<G-vec00257-002-s331><fail.bestehen><en> If you fail an assessment, you will be referred to the course content where those concepts were covered.
<G-vec00257-002-s332><fail.bestehen><de> Tatsächlich würden viele Unternehmen heute ein FDA-Audit hinsichtlich der Art und Weise, wie Terminologie erstellt, überprüft, übersetzt und genehmigt wird, nicht bestehen.
<G-vec00257-002-s332><fail.bestehen><en> Indeed, many companies would fail an FDA audit today should they be audited on how terminology is created, reviewed, translated, and approved.
<G-vec00257-002-s333><fail.bestehen><de> Bitte bedenken Sie, dass Sie von Ihrem Studium auch gesperrt werden, wenn Sie eine Wahllehrveranstaltung viermal nicht bestehen.
<G-vec00257-002-s333><fail.bestehen><en> Please bear in mind that you will also be excluded from your degree programme if you fail an elective subject four times.
<G-vec00257-002-s334><fail.bestehen><de> Das ist so ziemlich die einzige meiner vier Abschlussprüfungen, wo ich Angst habe nicht zu bestehen.
<G-vec00257-002-s334><fail.bestehen><en> That really is the only one of my four exams, where I am afraid I could fail.
<G-vec00257-002-s335><fail.bestehen><de> Ihr seid nicht unfehlbar, das Leben jedoch könnt ihr nicht nicht bestehen.
<G-vec00257-002-s335><fail.bestehen><en> You're not infallible, yet you cannot fail life.
<G-vec00257-002-s336><fail.bestehen><de> Ein Student, der mehr als ein Sprachmodul versagt, wird das Jahr nicht bestehen .
<G-vec00257-002-s336><fail.bestehen><en> A student who fails more than one language course will fail the year.
<G-vec00257-002-s337><fail.bestehen><de> Wenn Sie nicht bestehen, gehen Sie die Dokumentation zu Verarbeitungsregeln durch.
<G-vec00257-002-s337><fail.bestehen><en> If you fail, review the Processing Rules documentation.
<G-vec00257-002-s338><fail.bestehen><de> Wenn Bewerber nur Abschnitt 6 nicht bestehen oder nicht absolvieren, wird die Musterberechtigung ohne CAT II- oder CAT III-Rechte erteilt.
<G-vec00257-002-s338><fail.bestehen><en> If applicants only fail or do not take Section 6, the type rating will be issued without CAT II or CAT III privileges.
<G-vec00257-002-s339><fail.bestehen><de> Nun ist Gott allwissend, und ihm war von Anfang an klar, daß der Mensch schon die allererste Prüfung nicht bestehen und Opfer von Satans bösem Plan werden würde.
<G-vec00257-002-s339><fail.bestehen><en> Because God is all knowing, He realized that man would fail the initial test and fall prey to Satan's evil scheme.
<G-vec00257-002-s340><fail.bestehen><de> Wenn Sie das dritte Mal nicht bestehen, haben Sie den MA nicht bestanden und können den Abschluss nicht erlangen.
<G-vec00257-002-s340><fail.bestehen><en> If you fail the third time, you completely failed the MA and you cannot get the degree.
<G-vec00257-002-s030><succeed.bestehen><de> Um unter den besonderen Bedingungen im Weltraum zu bestehen, musste die Menschheit kreativ werden – und hat dabei bemerkenswerte Ingenieursleistungen vollbracht.
<G-vec00257-002-s030><succeed.bestehen><en> To succeed under the special circumstances in space, humanity had to get creative – and performed marvelous feats of engineering while doing so.
<G-vec00257-002-s031><succeed.bestehen><de> Um bei der westeuropäsichen Konkurrenz zu bestehen, entwickelten wir im Jahre 2006 in Zusammenarbeit mit unseren dänischen und irischen Handelspartnern eine neue Kesselreihe, die für ihren Gang die Lenkungseinheit mit der Lambda-Sonde benutzen.
<G-vec00257-002-s031><succeed.bestehen><en> In order to succeed amongst western European competition, in 2006 we developed with the cooperation with our Danish partners, a new boiler line using the control unit with the lambda sensor for its operation.
<G-vec00257-002-s032><succeed.bestehen><de> Der Einsatz von effektiver Regelungstechnologie trägt dazu bei, die Qualität und Quantität der Produktion zu steigern und im globalen Wettbewerb zu bestehen.
<G-vec00257-002-s032><succeed.bestehen><en> The use of effective control technology helps to increase the quality and quantity of production and to succeed in global competition.
<G-vec00257-002-s033><succeed.bestehen><de> Das Voltaire-Projekt zielt darauf ab, Ihnen alle Karten zur Verfügung zu stellen, um den mythischen Wettbewerb zu bestehen.
<G-vec00257-002-s033><succeed.bestehen><en> The Voltaire Project aims to give you all the cards in hand to succeed the mythical competition.
<G-vec00257-002-s034><succeed.bestehen><de> Wie schon erwähnt gibt es in diesem Level eine Menge an Fallen zu bestehen, Fallen von gängiger oder ungewöhnlicher Art, Fallen für sich selbst oder solche, die mit anderen Herausforderungen kombiniert sind wie Zeitrennen oder Feinden.
<G-vec00257-002-s034><succeed.bestehen><en> As mentioned yet, there are a lot of traps to succeed in this level, traps of normal and unusual kinds, traps for themselves and such combined with other challenges too, as timeruns or enemies.
<G-vec00258-002-s230><arise.bestehen><de> Trotz der Erörterung dieses Themas in der Öffentlichkeit bestehen nicht selten große Schwierigkeiten, das konkrete Wissen über die Verschiedenheit von Mann und Frau in der eigenen Beziehung umzusetzen.
<G-vec00258-002-s230><arise.bestehen><en> Although this subject has been dealt with publicly great difficulties arise not infrequently in relating known facts about the difference between man and woman to one's own relationship.
<G-vec00258-002-s231><arise.bestehen><de> Sollte ausnahmsweise doch ein Widerrufsrecht bestehen, gilt für Verbraucher im Sinne des § 13 BGB folgendes: Sie haben das Recht, binnen vierzehn Tagen ohne Angabe von Gründen diesen Vertrag zu widerrufen.
<G-vec00258-002-s231><arise.bestehen><en> If, however, the right of cancellation should arise in exceptional circumstances, the following applies to consumers within the meaning set out at § 13 of the German Civil Code: You have the right, within fourteen days, to cancel this contract without specifying any reason.
<G-vec00258-002-s232><arise.bestehen><de> Schadensersatzansprüche gegen die team steffenhagen consulting GmbH, gleich aus welchem Rechtsgrund, bestehen nur, soweit ihr Vorsatz oder grobe Fahrlässigkeit zur Last fallen.
<G-vec00258-002-s232><arise.bestehen><en> Claims for damages against team steffenhagen consulting GmbH, irrespective of their legal grounds, only arise insofar as the latter is culpable of wilful intent or gross negligence.
<G-vec00258-002-s233><arise.bestehen><de> Werden vom Besteller oder Dritten unsachgemäß Instandsetzungsarbeiten oder Änderungen vorgenommen, so bestehen für diese und die daraus entstehenden Folgen ebenfalls keine Mängelansprüche.
<G-vec00258-002-s233><arise.bestehen><en> Moreover, if the Purchaser or third parties make changes or carry out repairs or maintenance work inappropriately, no warranty claims shall arise therefrom for the latter and any consequences arising therefrom.
<G-vec00258-002-s234><arise.bestehen><de> Bei direkten oder indirekten Verlinkungen auf die Webseiten Dritter, die außerhalb unseres Verantwortungsbereichs liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall nur bestehen, wenn wir von den Inhalten Kenntnis erlangen und es uns technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00258-002-s234><arise.bestehen><en> In the case of direct or indirect links to the websites of third parties which lie outside our area of responsibility, liability would only arise in the event that we become aware of the content and it would be technically possible and reasonable for us to prevent use in the event of illegal content.
<G-vec00258-002-s235><arise.bestehen><de> So stellen Sie mit PRTG fest, wo Performance-Engpässe bestehen, an welchen Punkten Anwendungen in die Knie gehen und wo die Ursachen zu finden sind, ob im Netzwerk, bei der Anwendung selbst oder hardwareseitig.
<G-vec00258-002-s235><arise.bestehen><en> You can use PRTG to determine where bottlenecks arise, when applications crash, and where the causes of problems are to be found - in the network, hardware, or application itself.
<G-vec00258-002-s236><arise.bestehen><de> Sollte aufgrund konkreter Anhaltspunkte der berechtigte Verdacht einer rechtswidrigen Nutzung bestehen, werden die Protokolldaten nachträglich überprüft.
<G-vec00258-002-s236><arise.bestehen><en> Should justified suspicion of illegal use arise on the basis of concrete indicators, the log data shall be subsequently verified.
<G-vec00258-002-s237><arise.bestehen><de> Soweit im Zusammenhang mit Lieferungen – aus welchem Rechtsgrund auch immer – Ansprüche bestehen, so sind diese der Höhe nach auf den Wert der von uns gelieferten Ware begrenzt.
<G-vec00258-002-s237><arise.bestehen><en> As far as claims arise in connection with deliveries, for whatever legal reason, they are limited to the value of our delivery.
<G-vec00258-002-s238><arise.bestehen><de> In der Serie beschäftigt sich der Künstler mit dem Material Wachs und untersucht die verschiedenen Bezüge, die dazu bestehen.
<G-vec00258-002-s238><arise.bestehen><en> With this series, the artist explores the use of wax as a material, dealing with a variety of associations that arise in the process.
<G-vec00258-002-s239><arise.bestehen><de> Weitere Risiken für die Weltwirtschaft bestehen in einer Eskalation geopolitischer Konflikte und in einer Verstärkung protektionistischer Tendenzen.
<G-vec00258-002-s239><arise.bestehen><en> Further risks to the global economy arise from an escalation of geopolitical conflicts and an increased tendency toward protectionism.
<G-vec00258-002-s240><arise.bestehen><de> Sofern keine erforderlichen Gründe im Zusammenhang mit einer Geschäftsabwicklung bestehen, können Sie jederzeit die zuvor erteilte Genehmigung Ihrer persönlichen Datenspeicherung mit sofortiger Wirkung widerrufen.
<G-vec00258-002-s240><arise.bestehen><en> Insofar that no necessary reasons arise in correlation with a business transaction, you can cancel your prior consent to store your personal data effective immediately at any time.
<G-vec00258-002-s241><arise.bestehen><de> Früher galt die Regel, dass ein perfektes Linkprofil sowohl aus Seiten mit einem hohen als auch niedrigen Google Pagerank bestehen sollte.
<G-vec00258-002-s241><arise.bestehen><en> In the past the rule was that a perfect link profile should arise from sites with high as well as low Google page ranking.
<G-vec00258-002-s242><arise.bestehen><de> Dabei gehen wir von einem Sys-tem von Kognitionen aus, zwischen denen jeweils konsonante oder dissonante Beziehungen bestehen können.
<G-vec00258-002-s242><arise.bestehen><en> In examining these we are assuming a system of cognitions between which either consonant or dissonant relationships can arise.
<G-vec00261-002-s072><persist.bestehen><de> Internationale Verwerfungslinien werden über Kopenhagen hinaus Bestand haben.
<G-vec00261-002-s072><persist.bestehen><en> International fault lines will persist beyond Copenhagen.
<G-vec00261-002-s073><persist.bestehen><de> Derzeit ist schwer abzuschätzen, wie lange diese Zunahme des Angebots Bestand haben wird.
<G-vec00261-002-s073><persist.bestehen><en> At this stage it is hard to know how long this increase in supply will persist for.
<G-vec00261-002-s038><prevail.bestehen><de> Sicherheitsmaßnahmen im Bereich der Informationstechnologien können, für sich alleine gestellt, nicht bestehen.
<G-vec00261-002-s038><prevail.bestehen><en> ProCess With regard to information technologies, security measures alone cannot prevail.
<G-vec00261-002-s039><prevail.bestehen><de> Werden vom Käufer oder von Dritten unsachgemäße Änderungen oder Instandsetzungsarbeiten vorgenommen, so bestehen für diese und die daraus entstehenden Folgen ebenfalls keine Mängelansprüche.
<G-vec00261-002-s039><prevail.bestehen><en> If the Purchaser or any third party carries out improper modifications or repair work, no complaints based on defects shall likewise prevail for these or any consequences arising therefrom.
<G-vec00261-002-s040><prevail.bestehen><de> Wir können an allen Rädchen drehen, gezielt agieren, schnell reagieren und immer besser werden, um am globalen, sich ständig verändernden Markt zu bestehen.
<G-vec00261-002-s040><prevail.bestehen><en> We can act well-targeted, react quickly and get better constantly, in order to prevail in a continuously evolving global market.
<G-vec00261-002-s041><prevail.bestehen><de> Dich kann weder die Macht der Mächtigen behindern noch können die Herrscher mit ihrer Machtfülle gegen Dich bestehen.
<G-vec00261-002-s041><prevail.bestehen><en> Neither can the power of the powerful frustrate Thee, nor the ascendancy of the rulers prevail against Thee.
<G-vec00280-002-s057><pass.bestehen><de> 2011 hat er als einer der ersten Entwickler die Prüfung zum Magento Certified Developer bestanden.
<G-vec00280-002-s057><pass.bestehen><en> In 2011, he was one of the very first developers to pass the Magento Certified Developer examination.
<G-vec00280-002-s058><pass.bestehen><de> Sie müssen Ihr erstes Jahr bestanden haben, um zum zweiten Jahr überzugehen.
<G-vec00280-002-s058><pass.bestehen><en> You must pass your first year assessments in order to proceed to the second year.
<G-vec00280-002-s059><pass.bestehen><de> b) Er hat für mindestens zwei Prüfungsaufgaben die Note BESTANDEN erhalten.
<G-vec00280-002-s059><pass.bestehen><en> (b) he has been awarded a PASS grade in at least two papers, and
<G-vec00280-002-s060><pass.bestehen><de> Nachdem die Schüler einen praktischen Rettungstest und einen Theorietest erfolgreich bestanden haben, werden sie als SDI-Retter zertifiziert.
<G-vec00280-002-s060><pass.bestehen><en> After the students successfully pass a practical rescue test and a theory test, they will be certified as SDI rescuers.
<G-vec00280-002-s061><pass.bestehen><de> Die Befragten, die die Screening-Frage (n) nicht bestanden haben und sich nicht zu einer Umfrage qualifiziert haben, erreichen die Bildschirmseite und werden in die allgemeine IR des Projekts einbezogen.
<G-vec00280-002-s061><pass.bestehen><en> The respondents who didn't pass the screening question(s) and didn't qualify into a survey, reach the screen out page and are calculate into the overall IR of the project.
<G-vec00280-002-s062><pass.bestehen><de> Bestanden: Wenn Sie die Klausur bestanden haben (4,0 oder besser) können Sie die Note und die entsprechenden ECTS auf MeinCampus einsehen.
<G-vec00280-002-s062><pass.bestehen><en> Pass: if you get a passing grade (4.0 or better), you can see the grade and ECTS gained on MeinCampus.
<G-vec00280-002-s063><pass.bestehen><de> Wenn Sie alle Lektionen beendet und die Tests vom Kurs bestanden haben, erhalten Sie ein Abschlusszertifikat.
<G-vec00280-002-s063><pass.bestehen><en> You receive a Certificate of Completion when you finish all the lessons and pass all the tests in a course.
<G-vec00280-002-s064><pass.bestehen><de> Die Prüfung ist bestanden, wenn innerhalb von 2,5 Stunden (150 Minuten) mindestens 44 der insgesamt 80 Punkte (55%) erzielt wurden.
<G-vec00280-002-s064><pass.bestehen><en> Participants must gain a minimum of 38 out of 68 available marks (55%) to successfully pass the exam.
<G-vec00280-002-s065><pass.bestehen><de> SCHOTT ist das erste Unternehmen weltweit, das seine Verglasungen einer Prüfung der gleichzeitigen Mehrfachbelastung unterzogen und erfolgreich bestanden hat.
<G-vec00280-002-s065><pass.bestehen><en> SCHOTT is the first company in the world to subject its glazings to a test that includes multiple stresses and successfully pass it.
<G-vec00280-002-s066><pass.bestehen><de> Für beide Prozessstufen bestanden die Aachener Forscher die strengen Prüfungen der Aufsichts- und Genehmigungsbehörden.
<G-vec00280-002-s066><pass.bestehen><en> The researchers in Aachen must pass the stringent tests of the supervisory and regulatory authorities for both of these stages.
<G-vec00280-002-s067><pass.bestehen><de> In einer anderen Testgruppe, die nicht mit dieser Technologie ausgebildet worden war, haben nur 27% die gleiche Prüfung bestanden.
<G-vec00280-002-s067><pass.bestehen><en> A control group, not so trained, had a 27 percent pass rate on the same test. Next
<G-vec00280-002-s068><pass.bestehen><de> Herausforderungen sind hier oftmals spezielle Akkuformen, die extrem schlank und dennoch so formstabil sein müssen, dass die Belastungstests der notwendigen Zertifizierungen bestanden werden.
<G-vec00280-002-s068><pass.bestehen><en> The challenge often lies in the special battery shapes that must be extremely slim and yet stable enough to pass the stress tests of the required certifications.
<G-vec00280-002-s069><pass.bestehen><de> Wenn ein Produkt die optische Überprüfung bestanden hat, können wir dessen 100%-ig fehlerfreie Funktion durch einen Funktionstest garantieren.
<G-vec00280-002-s069><pass.bestehen><en> When the products pass the optical inspection, functional testing is made to guarantee that they are 100 % reliable.
<G-vec00280-002-s070><pass.bestehen><de> Für die Bachelorstudiengänge im Fach Sport (außer Human Movements in Sports and Exercise) und für die Bachelorstudiengänge im Fach Musik (außer Musikwissenschaft) muss (zusätzlich) vor der Bewerbung eine Eignungsprüfung bestanden werden.
<G-vec00280-002-s070><pass.bestehen><en> Those who apply for admission to bachelor's programmes in Sport and Physical Education (not including Human Movement in Sports and Exercise) and bachelor's programmes in Music (not including Musicology) are also required to pass an aptitude test.
<G-vec00280-002-s071><pass.bestehen><de> Durch diesen Prozess habe ich erkannt: Wenn ich nicht so hart gearbeitet und nicht mein Bestes gegeben hätte, dann hätte ich das Examen nicht bestanden.
<G-vec00280-002-s071><pass.bestehen><en> From my studies and exam preparation I realized that, if I did not work very hard, did not try my best, I would not pass the exam.
<G-vec00280-002-s072><pass.bestehen><de> Somit ist die Antwort - ja, wir haben die Prüfung bestanden.
<G-vec00280-002-s072><pass.bestehen><en> So the answer is yes, we did pass the inspection.
<G-vec00280-002-s073><pass.bestehen><de> Weiterhin entscheidet das Testkompetenzzentrum, ob das geprüfte Testobjekt die Tests bestanden hat oder nicht.
<G-vec00280-002-s073><pass.bestehen><en> Furthermore the test center decides whether to pass or fail the evaluated test object.
<G-vec00280-002-s074><pass.bestehen><de> Optional - Mach dir keine Sorgen, falls du eine Warnung erhälst, dass der TAP Driver den Driver Signing Test (bei Microsoft) nicht bestanden hat.
<G-vec00280-002-s074><pass.bestehen><en> Optional - If you receive a warning that the TAP driver didn't pass the driver signing check by Microsoft - this is nothing to worry about.
<G-vec00280-002-s075><pass.bestehen><de> Die Bestanden/Versagen-Kette ist eine binäre Datenkette.
<G-vec00280-002-s075><pass.bestehen><en> The pass/fail string is a binary data string.
<G-vec00317-002-s217><consist.bestehen><de> Deshalb konnte Christus auch über seine Verfolger und Henker sagen: „Vater vergib ihnen, denn sie wissen nicht, was sie tun.“ Die „Erlösung“ der Welt besteht nicht darin, die Menschen durch eine göttliche „Gnade“ von den Wirkungen ihrer falschen Handlungsweise zu befreien.
<G-vec00317-002-s217><consist.bestehen><en> Christ could therefore say of his persecutors and his executioners: "Father, forgive them, for they know not what they do". The "redemption" of the world does not consist of freeing people from the effect of their faulty way of being through divine "grace".
<G-vec00317-002-s218><consist.bestehen><de> Ein großer Teil deiner Tätigkeit besteht darin, Beziehungen zu anderen Menschen zu knöpfen und von deren Kultur zu lernen.
<G-vec00317-002-s218><consist.bestehen><en> A big part of your work will consist in establishing relationships to other humans and to learn from their culture.
<G-vec00317-002-s219><consist.bestehen><de> Liebe besteht nicht darin, dass man einander anschaut, sondern dass man gemeinsam in dieselbe Richtung blickt.
<G-vec00317-002-s219><consist.bestehen><en> Love does not consist in gazing at each other that, but in looking together in the same direction.
<G-vec00317-002-s220><consist.bestehen><de> Die Gesundheitsvorsorge der meisten Menschen besteht darin, sich einmal im Jahr durchchecken zu lassen und nur sporadisch zum Arzt zu gehen – nämlich dann wenn sie krank werden.
<G-vec00317-002-s220><consist.bestehen><en> Most people’s healthcare activities consist of getting a general checkup once a year and only seeing a doctor if they happen to fall ill.
<G-vec00317-002-s221><consist.bestehen><de> Das besteht darin, Schließfächer zu installieren, Wickeltische aufzustellen, wenn du Säuglinge oder Kleinkinder betreust, Rauchmelder zu installieren und Steckdosenabdeckungen anzubringen.
<G-vec00317-002-s221><consist.bestehen><en> This should consist of tasks like installing cabinet locks, setting up changing tables if you are servicing infants and/or toddlers, putting up smoke detectors, and inserting electrical outlet covers.
<G-vec00317-002-s222><consist.bestehen><de> Seine Aufgabe besteht nicht nur darin, Nahrung zu verdauen und als Nährstoffe, Mineralien und Spurenelemente in die Blutbahn abzugeben.
<G-vec00317-002-s222><consist.bestehen><en> Its task does not only consist of digesting food and passing it as nutrients, minerals and trace elements to the organism.
<G-vec00317-002-s223><consist.bestehen><de> Die Versicherung besteht darin, dass der Beteiligte unter Wiederholung der behaupteten Tatsachen erklärt: "Ich versichere an Eides statt, dass ich nach bestem Wissen die reine Wahrheit gesagt und nichts verschwiegen habe".
<G-vec00317-002-s223><consist.bestehen><en> The sworn statement shall consist in the participant’s repeating the facts previously stated by him and making the following declaration: “I do solemnly affirm that to the best of my knowledge I have told nothing but the truth and have concealed nothing.”
<G-vec00317-002-s224><consist.bestehen><de> Es ist, als eklärte jemand: "Spielen besteht darin, daß man Dinge, gesissen Regeln gemäß, auf einer Fläche verscheibt .
<G-vec00317-002-s224><consist.bestehen><en> It is as if someone explained thus: "Games consist in moving objects about on a surface according to known rules .
<G-vec00317-002-s225><consist.bestehen><de> Der Spaß besteht darin, die verzauberte Welt vom Verborgenen Land mit einem Zauberstab in der Hand zu besuchen und seine Bewohner kennenzulernen.
<G-vec00317-002-s225><consist.bestehen><en> The fun consist in visiting the enchanted world of the Hidden Land with a wand in the hand and getting to know its inhabitants.
<G-vec00317-002-s226><consist.bestehen><de> Die technische Umsetzung einer SOA Architektur, besteht darin, die fachlichen Gegebenheiten richtig in Dienste aufzuteilen.
<G-vec00317-002-s226><consist.bestehen><en> The cornerstone of the realization of a SOA architecture, consist of the correct distribution of the business activities into services.
<G-vec00317-002-s227><consist.bestehen><de> Ihre Verbreitung besteht nicht nur darin, daß Gleiches mit Gleichem zusammengeht; und ihre Verwirklichung ist nicht nur eine gegensatzlose Ausdehnung.
<G-vec00317-002-s227><consist.bestehen><en> Its expansion does not only consist in like combining with like; and its realization is not merely an unresisted expansion.
<G-vec00323-002-s076><stand.bestehen><de> Hier wird es für den Maestro wesentlich, die von den verschiedenen Intervallen ausgelösten Gefühle im Inneren zu erfassen, das heißt die Beziehungen, die zwischen den Farben bestehen je nachdem, wie sie im Farbenkreis Goethes untereinander in Beziehung stehen nach Tangenten, Sehnen oder ob sie entgegengesetzt sind.
<G-vec00323-002-s076><stand.bestehen><en> Here, the Master felt, it is essential to grasp intimately the sentiments set free by the different intervals, that is of the relations that cross between the colours according to where they stand in relation to one another through tangents and chords, or are diametrically opposed in Goethe’s circle.
<G-vec00323-002-s077><stand.bestehen><de> Und der, welcher gegen ihn gekommen ist, wird nach seinem Gutdünken handeln, und niemand wird vor ihm bestehen; und er wird seinen Stand nehmen im Lande der Zierde, und Vertilgung wird in seiner Hand sein.
<G-vec00323-002-s077><stand.bestehen><en> 16 But he that comes against him shall do according to his own will, and none shall stand before him: and he shall stand in the glorious land, which by his hand shall be consumed.
<G-vec00323-002-s078><stand.bestehen><de> 12Und die Kinder Israel werden vor ihren Feinden nicht zu bestehen vermögen; sie werden vor ihren Feinden den Rücken kehren, denn sie sind zum Banne geworden.
<G-vec00323-002-s078><stand.bestehen><en> 12“And the sons of Yisra’ĕl shall not be able to stand before their enemies. They are going to turn their backs before their enemies, for they have become accursed.
<G-vec00323-002-s079><stand.bestehen><de> 25 Jesus kannte aber ihre Gedanken und sprach zu ihnen: Jedes Reich, das mit sich selbst uneins ist, wird verwüstet; und jede Stadt oder jedes Haus, das mit sich selbst uneins ist, wird nicht bestehen.
<G-vec00323-002-s079><stand.bestehen><en> 25And Jesus, knowing their thoughts, said to them, `Every kingdom having been divided against itself is desolated, and no city or house having been divided against itself, doth stand,
<G-vec00323-002-s080><stand.bestehen><de> Falls die Entscheidung vertagt wird, wird eine sofortige Abstimmung abgehalten, um zu bestimmen, ob die Entscheidung solange bestehen bleibt, bis die vollständige Abstimmung über die Entscheidung durchgeführt wurde, oder ob die Erfüllung der ursprünglichen Entscheidung bis dahin verzögert wird.
<G-vec00323-002-s080><stand.bestehen><en> If the decision is put on hold, an immediate vote is held to determine whether the decision will stand until the full vote on the decision is made or whether the implementation of the original decision will be be delayed until then.
<G-vec00323-002-s081><stand.bestehen><de> Das ist der Ort, an dem Lincoln seine berühmten Worte sprach: „Jedes Haus, das in sich uneins ist, wird nicht bestehen.“ Beide Orte sind nicht nur schön, sondern auch unglaublich interessant und unterhaltsam für Besucher aller Altersgruppen.
<G-vec00323-002-s081><stand.bestehen><en> This is where Lincoln spoke his famous words: “A house divided against itself cannot stand.” Not only are both places beautiful, but they’re incredibly interesting and fun for people of all ages.
<G-vec00323-002-s082><stand.bestehen><de> 18Und euer Bund mit dem Tode wird zunichte werden, und euer Vertrag mit dem Scheol nicht bestehen: Wenn die überflutende Geißel hindurchfährt, so werdet ihr von derselben zertreten werden.
<G-vec00323-002-s082><stand.bestehen><en> 18And your covenant with death shall be disannulled, and your agreement with hell#28.15,18 hell, Hebrew Sheol. shall not stand; when the overflowing scourge shall pass through, then ye shall be trodden down by it.
<G-vec00323-002-s083><stand.bestehen><de> Er sagt: „Mein eigener Beschluss wird bestehen, und alles, was mir gefällt, werde ich tun“ (Jesaja 46:10).
<G-vec00323-002-s083><stand.bestehen><en> I say, ‘My decision will stand, and I will do whatever I please.’”
<G-vec00323-002-s084><stand.bestehen><de> 7,12 Darum kann Israel nicht bestehen vor seinen Feinden, sondern sie müssen ihren Feinden den Rücken kehren; denn sie sind dem Bann verfallen.
<G-vec00323-002-s084><stand.bestehen><en> "Therefore the (I)sons of Israel cannot stand before their enemies; they
<G-vec00323-002-s085><stand.bestehen><de> Und niemand konnte vor ihnen bestehen, denn die Furcht vor ihnen war auf alle Völker gefallen.
<G-vec00323-002-s085><stand.bestehen><en> No one was able to stand before them, for dread of them fell on all the peoples.
<G-vec00323-002-s086><stand.bestehen><de> Und wenn ein Haus mit sich selbst entzweit ist, kann dieses Haus nicht bestehen.
<G-vec00323-002-s086><stand.bestehen><en> And if a house be divided against itself, that house cannot stand.
<G-vec00323-002-s087><stand.bestehen><de> Zieht die ganze Waffenrüstung Gottes an, damit ihr gegen die Listen des Teufels bestehen könnt.
<G-vec00323-002-s087><stand.bestehen><en> Put on all of God's armor so that you will be able to stand firm against all strategies and tricks of the Devil.
<G-vec00323-002-s088><stand.bestehen><de> In den Beitrittsländern sind noch erhebliche Anstrengungen notwendig, um die Landwirt-schaft und besonders die Verarbeitungsindustrie in ihrer Wettbewerbskraft zu stärken, damit sie gegen die erhöhte Konkurrenz in einer erweiterten EU bestehen können.
<G-vec00323-002-s088><stand.bestehen><en> In the acceding countries, great efforts are still required to strengthen the competitiveness of agriculture and food processors so that they are able to stand up to the strong competition prevailing in the EU.
<G-vec00323-002-s089><stand.bestehen><de> 24 Und er wird ihre Könige in deine Hand geben, und du wirst ihre Namen vernichten unter dem Himmel hinweg; kein Mensch wird vor dir bestehen, bis du sie vertilgt hast.
<G-vec00323-002-s089><stand.bestehen><en> 24 And he shall deliver their kings into your hands, and ye shall destroy their name from that place; none shall stand up in opposition before thee, until thou shalt have utterly destroyed them.
<G-vec00323-002-s090><stand.bestehen><de> Das ZIEL, deine Statistik vollständig "grün" einzufärben, ruhig in die Prüfung zu gehen und AUF ANHIEB BESTEHEN.
<G-vec00323-002-s090><stand.bestehen><en> The OBJECTIVE to color your stats completely "green", to calmly go into the exam and to STAND ON AN OPPORTUNITY.
<G-vec00323-002-s091><stand.bestehen><de> Sie bestehen aus weichem und zugleich widerstandsfähigem Pinselhaar und werden von einem schwarzen Etui geschützt, damit sie ihre Eleganz lang behalten.
<G-vec00323-002-s091><stand.bestehen><en> With a selection of soft yet resilient bristles, protected in a black holder, they stand the test of time in complete elegance.
<G-vec00323-002-s092><stand.bestehen><de> 119:91 Nach deinen Ordnungen bestehen sie bis heute, denn alles ist dir dienstbar.
<G-vec00323-002-s092><stand.bestehen><en> 119:91 They stand this day according to Thine ordinances; for all things are Thy servants.
<G-vec00323-002-s093><stand.bestehen><de> Dann wird der König des Südens sich aufmachen zum Kampf mit einem großen, mächtigen Heer, aber er wird nicht bestehen; denn es werden Pläne gegen ihn geschmiedet.
<G-vec00323-002-s093><stand.bestehen><en> 25And he shall stir up his power and his courage against the king of the south with a great army; and the king of the south shall be stirred up to battle with a very great and mighty army; but he shall not stand: for they shall forecast devices against him.
<G-vec00323-002-s094><stand.bestehen><de> 5 Darum bestehen die Gottlosen nicht im Gericht noch die Sünder in der Gemeinde der Gerechten.
<G-vec00323-002-s094><stand.bestehen><en> 5 the wicked will not stand firm at the Judgement nor sinners in the gathering of the upright.
<G-vec00326-002-s208><insist.bestehen><de> Sofern wir nicht auf der strikten Erfüllung der Vereinbarung bestehen oder diese nicht vollstrecken, stellt dies keinen Verzicht auf eines unserer Rechte dar.
<G-vec00326-002-s208><insist.bestehen><en> Our failure to insist upon or enforce your strict compliance with this Agreement will not constitute a waiver of any of our rights.
<G-vec00328-002-s023><pertain.bestehen><de> Aber diese Wahl wird in einer heiligen Ökonomie nicht mehr bestehen.
<G-vec00328-002-s023><pertain.bestehen><en> But this choice will no longer pertain in a sacred economy.
<G-vec00366-002-s071><comprise.bestehen><de> Ohne vorherige schriftliche Genehmigung ist jegliche Verwendung oder Vervielfältigung, ganz oder teilweise, der Website, der Elemente, aus denen sie besteht, oder der darin enthaltenen Informationen durch irgendein Verfahren, gesetzlich verboten.
<G-vec00366-002-s071><comprise.bestehen><en> Without prior written permission, any use or reproduction, in whole or in part, of the Site, the elements that comprise it, or the information contained therein by any means, is prohibited by law.
<G-vec00366-002-s072><comprise.bestehen><de> Wir können uns verschiedene Dinge ansehen, aus denen das Meisterwerk besteht, aber das Meisterwerk selbst überschreitet diese Anmerkungen bei Weitem.
<G-vec00366-002-s072><comprise.bestehen><en> We can discuss the various things that comprise a masterpiece, yet the masterpiece goes beyond any of these descriptions.
<G-vec00366-002-s073><comprise.bestehen><de> Die Spielregeln sind nicht schwer: es geht darum, wer das beste Blatt hält, das aus 5 Karten besteht.
<G-vec00366-002-s073><comprise.bestehen><en> The game features a 52-card deck and all of the players use five cards to comprise the best possible hand.
<G-vec00366-002-s074><comprise.bestehen><de> Von Chat-Anwendungen über HD-Videostreaming (High Definition) bis hin zu Datenübertragungen von Sensoren in Geräten und sogar Fahrzeugen, aus denen das Internet of Things (IoT) besteht, funktioniert der typische „verbundene“ Campus mit Drahtlosverbindungen.
<G-vec00366-002-s074><comprise.bestehen><en> From chatty applications, to high definition (HD) video streaming, to transmitting data from sensors located in devices and even vehicles that comprise the Internet of Things (IoT), the typical “connected” campus runs on wireless.
<G-vec00366-002-s075><comprise.bestehen><de> Die Seite ist mit insgesamt mehr als 1.000 Spielen ausgestattet, von denen der größte Teil aus Spielautomaten besteht.
<G-vec00366-002-s075><comprise.bestehen><en> The site is stocked with more than 1,000 games in total, most of which comprise video slots of some shape or form.
<G-vec00366-002-s114><contain.bestehen><de> Ihr Futter sollte zu mindestens 45% aus Protein bestehen, treiben und klein genug sein, dass es in ihre Mäuler passt.
<G-vec00366-002-s114><contain.bestehen><en> Their food should contain at least 45% protein, float, and be small enough to fit in the betta's mouth.
<G-vec00366-002-s115><contain.bestehen><de> Dieses Groß-Israel wird aus einer arabischen Mehrheit und einer schwindenden jüdischen Minderheit bestehen und wird unvermeidbar zu einem Apartsheidsstaat, der von einem ständigem Bürgerkrieg geplagt wird und den die Welt meidet.
<G-vec00366-002-s115><contain.bestehen><en> This Greater Israel will contain an Arab majority and a shrinking Jewish minority, turning it inevitably into an apartheid state, plagued by a permanent civil war and shunned by the world.
<G-vec00366-002-s116><contain.bestehen><de> Solche Öle, die man als Vollspektrumprodukte bezeichnet, bestehen nicht nur aus CBD, sondern auch aus verschiedenen anderen Pflanzenmolekülen.
<G-vec00366-002-s116><contain.bestehen><en> Full spectrum CBD refers to products that contain more than CBD, such as other plant molecules like THC and healthy fatty acids.
<G-vec00366-002-s117><contain.bestehen><de> Jeder Smoothie sollte aus Gemüse und Obst bestehen: Sowohl Heidelbeeren als auch Grünkohl sind extrem nährstoffreich, dafür aber kalorienarm.
<G-vec00366-002-s117><contain.bestehen><en> | 05.12.2017 Every smoothie should contain both fruits and vegetables: blueberries and kale are extremely nutritious yet low in calories.
<G-vec00366-002-s118><contain.bestehen><de> Die dort produzierten Verteilerschränke bestehen von nun an aus 33% wiederverwertetem Polystyrol.
<G-vec00366-002-s118><contain.bestehen><en> Our distribution boards now contain 33% recycled plastic.
<G-vec00366-002-s119><contain.bestehen><de> Für dieses Event werden 500 Punkte Teams benötigt, die aus mindestens 5 Figuren bestehen müssen.
<G-vec00366-002-s119><contain.bestehen><en> This event requires 500 pts teams, which have to contain at least 5 figures.
<G-vec00366-002-s120><contain.bestehen><de> Das Passwort muss mindestens 8 Zeichen lang sein und aus Buchstaben und Ziffern bestehen.
<G-vec00366-002-s120><contain.bestehen><en> The password must be at least 8 characters long and contain a mix of letters and numbers.
<G-vec00366-002-s121><contain.bestehen><de> Im Portal können bestimmte exklusive Dienstleistungen für unsere Kunden oder für angemeldete Benutzer bestehen, so dass der Zugang zu diesen eingeschränkt sein könnte.
<G-vec00366-002-s121><contain.bestehen><en> The Portal may contain certain exclusive services aimed at our customers and registered users, in which case access will be restricted.
<G-vec00366-002-s122><contain.bestehen><de> Die Kartons für Produkte, die nach Europa versendet werden, bestehen zu 80 % aus gebrauchten Fasern, die vollständig wiederverwertbar sind.
<G-vec00366-002-s122><contain.bestehen><en> CU boxes for products shipped to Europe contain 80% post-consumer fibre and are fully recyclable.
<G-vec00366-002-s123><contain.bestehen><de> Sandvik übernimmt keine Verantwortung für die Datenschutzpraxis oder für den Inhalt externer Webseiten, zu denen Links bestehen.
<G-vec00366-002-s123><contain.bestehen><en> Sandvik does not assume any responsibility for the privacy practices or the contents of external websites to which the Site contain links.
<G-vec00366-002-s124><contain.bestehen><de> Das Label des GRS darf bei Endprodukten wie Kleidungsstücken oder Heimtextilien verwendet werden, wenn diese zu mindestens 20 Prozent aus recycelten Materialien bestehen.
<G-vec00366-002-s124><contain.bestehen><en> The GRS label may be used with final products, such as clothing or household textiles, if they contain a minimum of 20% recycled materials.
<G-vec00366-002-s125><contain.bestehen><de> Passwort: Das Passwort muss aus mindestens acht Zeichen, mindestens einem Groß- und einem Kleinbuchstaben, sowie einem Sonderzeichen und/oder einer Ziffer bestehen.
<G-vec00366-002-s125><contain.bestehen><en> Password: Password has to be at least 8 characters long and has to contain at least one capital letter, one lower document Article Description Model Usage
<G-vec00366-002-s126><contain.bestehen><de> Alle Paßwörter, die Sie jetzt und in Zukunft vergeben, sollten aus 6 bis 8 Zeichen bestehen und neben großen und kleinen Buchstaben auch Satzzeichen oder Zahlen enthalten.
<G-vec00366-002-s126><contain.bestehen><en> All of the passwords you create should contain from 6 to 8 characters, and should contain both upper and lower-case characters, as well as punctuation characters.
<G-vec00366-002-s127><contain.bestehen><de> Ihre Produktion kann aus einer Kombination von Video und Fotos bestehen.
<G-vec00366-002-s127><contain.bestehen><en> Your production can contain a mixture of video and photos.
<G-vec00366-002-s128><contain.bestehen><de> Und dank seiner hohen Sensibilität erlaubt es auch die Identifizierung von Mosaik-Embryonen, d.h. Embryonen, die aus einer Mischung aus normalen und anormalen Zellen bestehen.
<G-vec00366-002-s128><contain.bestehen><en> Thanks to its elevated degree of sensitivity, it also facilitates identification of mosaic embryos. In other words, embryos that contain a mix of normal and abnormal cells.
<G-vec00366-002-s129><contain.bestehen><de> Daunenprodukte, die aus 91 einzeln geschnittenen Teilen bestehen, haben die ultimative Anpassungsform – mehr Isolierung für den Oberkörper und die Füße, volle Isolierung am Kopf und der Stirn.
<G-vec00366-002-s129><contain.bestehen><en> Down products that contain as many as 91 individually cut pieces deliver the ultimate fit – more insulation around the torso and foot box, and full insulation around the head and forehead.
<G-vec00366-002-s130><contain.bestehen><de> Videos sollten nicht aus Fotografien bestehen, sondern unmittelbare Videoaufnahme der Teilnehmer enthalten.
<G-vec00366-002-s130><contain.bestehen><en> The video should not contain photos, but must contain video of participants directly.
<G-vec00366-002-s131><contain.bestehen><de> Die Namen Lincon und Kennedy bestehen beide aus 7 Buchstaben.
<G-vec00366-002-s131><contain.bestehen><en> The names Lincoln and Kennedy each contain seven letters.
<G-vec00366-002-s132><contain.bestehen><de> Sie haben eine Form der Ausbuchtung nach innen der Schleimhaut und bestehen aus arteriovenösen Verbindungen.
<G-vec00366-002-s132><contain.bestehen><en> They are in the form of bulges from mucous membrane directed to the inside, and contain numerous arteriovenous communications.
<G-vec00394-002-s076><remain.bestehen><de> Um im Wettbewerb zu bestehen, müssen sich Unternehmen neues Wissen aneignen, aber auch vorhandenes Know-how bewahren und im Unternehmen zugänglich machen.
<G-vec00394-002-s076><remain.bestehen><en> To remain competitive and successful, companies need to acquire new knowledge – but they also need to maintain existing know-how and make it accessible within the company.
<G-vec00394-002-s077><remain.bestehen><de> Die Zahlungspflicht sowie die Geltendmachung weiterer Ansprüche wegen Zahlungsverzuges bestehen fort.
<G-vec00394-002-s077><remain.bestehen><en> The duty of payment as well as assertion of further entitlement concerning delayed payment remain unchanged.
<G-vec00394-002-s078><remain.bestehen><de> Grosse Unsicherheiten bestehen jedoch bezüglich der jeweiligen Anteile terrestrischer gegenüber aquatischer Quellen an den Gesamt-Lachgasemissionen sowie der biogeochemischen Mechanismen welche die N2O Produktion in aquatischen Systemen steuern.
<G-vec00394-002-s078><remain.bestehen><en> However, large uncertainties remain in the relative contributions of terrestrial versus aquatic environments and with regards to the underlying biogeochemical controls on microbial N2O production.
<G-vec00394-002-s079><remain.bestehen><de> Die wesentlichen Trends, die das Geschäft von Clyde Bergemann treiben, bestehen weiter: Eine wachsende Nachfrage nach Strom, die zu einem großen Teil aus Kohlekraftwerken gedeckt wird.
<G-vec00394-002-s079><remain.bestehen><en> The key trends fuelling the company’s business remain on the agenda: the growing demand for electrical power, generated to a major degree by coal-fired power plants.
<G-vec00394-002-s080><remain.bestehen><de> Die erste deutsche Geschichte Nepals des bekannten Südasien-Experten Axel Michaels handelt von der Entwicklung der kulturellen, gesellschaftlichen und politischen Vielfalt Nepals und erzählt daher nicht eine, sondern viele Geschichten: die Geschichte des Wassers, der Elefanten oder der Schamanentrommel, die Geschichte von Dynastien, Traditionen, Ritualen, Festen, Handwerken oder Künsten, die bis heute weitgehend unverändert bestehen, denn in Nepal scheint tatsächlich die Zeit (und damit die Geschichte) bisweilen stehengeblieben zu sein.
<G-vec00394-002-s080><remain.bestehen><en> The volume gives an insight into the development of the cultural, social and political diversity of Nepal and does not tell one, but many stories: the history of the water, of the elephants or the shaman drum, the history of dynasties, traditions, rituals, festivals, and of arts and crafts, which remain largely unchanged until today, because in Nepal, time – and therefore history – sometimes seem to have stood still.
<G-vec00394-002-s081><remain.bestehen><de> Obwohl die deutsche Wiedervereinigung mehr als 25 Jahre zurückliegt, bestehen bis heute Unterschiede zwischen Ost- und Westdeutschland.
<G-vec00394-002-s081><remain.bestehen><en> Although German reunification took place 25 years ago, differences between East and West Germany still remain.
<G-vec00394-002-s082><remain.bestehen><de> Man kann also erkennen, dass einige Aspekte unserer utopischen Hoffnungen weiter bestehen.
<G-vec00394-002-s082><remain.bestehen><en> So we can see that certain aspects of these utopian precedents remain relevant today.
<G-vec00394-002-s083><remain.bestehen><de> – Draigo macht Paladine zu Standard Auswahlen aber diese müssen aus mindestens 4 Modellen bestehen.
<G-vec00394-002-s083><remain.bestehen><en> Draigo makes paladins troops, but they have to be 4 or more models or else remain elites.
<G-vec00394-002-s084><remain.bestehen><de> Garantieansprüche bestehen unbeschadet der gesetzlichen Ansprüche/Rechte.
<G-vec00394-002-s084><remain.bestehen><en> Warranty claims remain valid irrespective of the statutory claims/rights.
<G-vec00394-002-s085><remain.bestehen><de> Um im Wettbewerb zu bestehen, muss man sich Informationsvorteile beschaffen.
<G-vec00394-002-s085><remain.bestehen><en> In order to remain a strong contender, you will have to secure information advantages.
<G-vec00394-002-s086><remain.bestehen><de> (3) Im Fall der Unwirksamkeit einer oder mehrerer Bestimmungen aus diesem Vertrag bleibt der Vertrag im Übrigen bestehen.
<G-vec00394-002-s086><remain.bestehen><en> (3) In the event that one or more provisions of this contract shall become invalid, all other provisions of the contract shall remain in effect.
<G-vec00394-002-s087><remain.bestehen><de> Das Instrument für private Finanzierungen im Bereich Energieeffizienz muss so lange bestehen, wie die zugrunde liegenden Darlehen ausstehen, die von der Fazilität mit Risikoteilung gedeckt werden.
<G-vec00394-002-s087><remain.bestehen><en> The PF4EE needs to be operational for as long as underlying loans covered by the RS Facility remain outstanding.
<G-vec00394-002-s088><remain.bestehen><de> Dazu erwirbt Hornschuch im Zuge der Beteiligung SWG-eigene Anteile, die Anteile der anderen Gesellschafter bestehen unverändert fort.
<G-vec00394-002-s088><remain.bestehen><en> For this purpose, Hornschuch will acquire SWG shares within the scope of the investment. The shares of the other shareholders remain unchanged.
<G-vec00394-002-s089><remain.bestehen><de> 6.1 Die Lizenznehmerin erklärt sich damit einverstanden, dass der Rechtsanspruch an sämtlichen gewerblichen Schutz- und Urheberrechten, die vor oder nach dem Datum dieses Vertrags an oder in Verbindung mit der Software, dem Quellcode, der Dokumentation und – vorbehaltlich anderslautender schriftlicher Vereinbarungen zwischen den Parteien – allen Änderungen geschaffen, entwickelt oder benutzt werden oder bestehen, das alleinige Eigentum der Lizenzgeberin ist und diese ein unverfallbares Recht daran hat.
<G-vec00394-002-s089><remain.bestehen><en> 6.1 The Licensee agrees and acknowledges that title to all the Intellectual Property Rights created, developed, subsisting or used prior to or after the date of this Agreement in or in connection with the Software, the Source Code, the Documentation and, unless agreed otherwise between the parties in writing, all the Modifications, will be the absolute property of and will vest and remain vested in the Licensor.
<G-vec00394-002-s090><remain.bestehen><de> Das sind 10 Monate nach der Behandlung her und die von uns angemerkten Besserungen bestehen wie bisher.
<G-vec00394-002-s090><remain.bestehen><en> Ten months post stem cells and the improvements we have seen still remain.
<G-vec00394-002-s091><remain.bestehen><de> •Wenn nach wie vor Spaltungen bestehen, scheinen sie jedoch überwiegend entlang der Generationengrenzen zu liegen.
<G-vec00394-002-s091><remain.bestehen><en> •Still, if lingering divisions remain, they appear to be predominantly along generational lines.
<G-vec00394-002-s092><remain.bestehen><de> Tritt der Gast von der Buchung zurück oder nimmt er die gebuchte Leistung nicht in Anspruch, so bleibt die Verpflichtung des Gastes zur Entrichtung der Buchungssumme grundsätzlich bestehen.
<G-vec00394-002-s092><remain.bestehen><en> If the guest withdraws from the booking or does not claim the booked service, the guest's obligation to pay the booking total shall generally remain in effect.
<G-vec00394-002-s093><remain.bestehen><de> Gleichzeitig bestehen noch mannigfaltige wohnrechtliche Barrieren, die erst ansatzweise in der legistischen Debatte erkannt sind.
<G-vec00394-002-s093><remain.bestehen><en> At the same time, especially in the area of housing legislation, there remain issues that need resolving and are not yet addressed in the discussions.
<G-vec00394-002-s094><remain.bestehen><de> Also muss es verstanden sein: Wenn der Leib des Königs vergeht, wird er in reiner Ekstase in alle Ewigkeit bestehen.
<G-vec00394-002-s094><remain.bestehen><en> Now let it be understood: If the body of the King dissolve, he shall remain in pure ecstasy for ever.
<G-vec00205-003-s076><stand_up.bestehen><de> Hier wird es für den Maestro wesentlich, die von den verschiedenen Intervallen ausgelösten Gefühle im Inneren zu erfassen, das heißt die Beziehungen, die zwischen den Farben bestehen je nachdem, wie sie im Farbenkreis Goethes untereinander in Beziehung stehen nach Tangenten, Sehnen oder ob sie entgegengesetzt sind.
<G-vec00205-003-s076><stand_up.bestehen><en> Here, the Master felt, it is essential to grasp intimately the sentiments set free by the different intervals, that is of the relations that cross between the colours according to where they stand in relation to one another through tangents and chords, or are diametrically opposed in Goethe’s circle.
<G-vec00205-003-s077><stand_up.bestehen><de> Und der, welcher gegen ihn gekommen ist, wird nach seinem Gutdünken handeln, und niemand wird vor ihm bestehen; und er wird seinen Stand nehmen im Lande der Zierde, und Vertilgung wird in seiner Hand sein.
<G-vec00205-003-s077><stand_up.bestehen><en> 16 But he that comes against him shall do according to his own will, and none shall stand before him: and he shall stand in the glorious land, which by his hand shall be consumed.
<G-vec00205-003-s078><stand_up.bestehen><de> 12Und die Kinder Israel werden vor ihren Feinden nicht zu bestehen vermögen; sie werden vor ihren Feinden den Rücken kehren, denn sie sind zum Banne geworden.
<G-vec00205-003-s078><stand_up.bestehen><en> 12“And the sons of Yisra’ĕl shall not be able to stand before their enemies. They are going to turn their backs before their enemies, for they have become accursed.
<G-vec00205-003-s079><stand_up.bestehen><de> 25 Jesus kannte aber ihre Gedanken und sprach zu ihnen: Jedes Reich, das mit sich selbst uneins ist, wird verwüstet; und jede Stadt oder jedes Haus, das mit sich selbst uneins ist, wird nicht bestehen.
<G-vec00205-003-s079><stand_up.bestehen><en> 25And Jesus, knowing their thoughts, said to them, `Every kingdom having been divided against itself is desolated, and no city or house having been divided against itself, doth stand,
<G-vec00205-003-s080><stand_up.bestehen><de> Falls die Entscheidung vertagt wird, wird eine sofortige Abstimmung abgehalten, um zu bestimmen, ob die Entscheidung solange bestehen bleibt, bis die vollständige Abstimmung über die Entscheidung durchgeführt wurde, oder ob die Erfüllung der ursprünglichen Entscheidung bis dahin verzögert wird.
<G-vec00205-003-s080><stand_up.bestehen><en> If the decision is put on hold, an immediate vote is held to determine whether the decision will stand until the full vote on the decision is made or whether the implementation of the original decision will be be delayed until then.
<G-vec00205-003-s081><stand_up.bestehen><de> Das ist der Ort, an dem Lincoln seine berühmten Worte sprach: „Jedes Haus, das in sich uneins ist, wird nicht bestehen.“ Beide Orte sind nicht nur schön, sondern auch unglaublich interessant und unterhaltsam für Besucher aller Altersgruppen.
<G-vec00205-003-s081><stand_up.bestehen><en> This is where Lincoln spoke his famous words: “A house divided against itself cannot stand.” Not only are both places beautiful, but they’re incredibly interesting and fun for people of all ages.
<G-vec00205-003-s082><stand_up.bestehen><de> 18Und euer Bund mit dem Tode wird zunichte werden, und euer Vertrag mit dem Scheol nicht bestehen: Wenn die überflutende Geißel hindurchfährt, so werdet ihr von derselben zertreten werden.
<G-vec00205-003-s082><stand_up.bestehen><en> 18And your covenant with death shall be disannulled, and your agreement with hell#28.15,18 hell, Hebrew Sheol. shall not stand; when the overflowing scourge shall pass through, then ye shall be trodden down by it.
<G-vec00205-003-s083><stand_up.bestehen><de> Er sagt: „Mein eigener Beschluss wird bestehen, und alles, was mir gefällt, werde ich tun“ (Jesaja 46:10).
<G-vec00205-003-s083><stand_up.bestehen><en> I say, ‘My decision will stand, and I will do whatever I please.’”
<G-vec00205-003-s084><stand_up.bestehen><de> 7,12 Darum kann Israel nicht bestehen vor seinen Feinden, sondern sie müssen ihren Feinden den Rücken kehren; denn sie sind dem Bann verfallen.
<G-vec00205-003-s084><stand_up.bestehen><en> "Therefore the (I)sons of Israel cannot stand before their enemies; they
<G-vec00205-003-s085><stand_up.bestehen><de> Und niemand konnte vor ihnen bestehen, denn die Furcht vor ihnen war auf alle Völker gefallen.
<G-vec00205-003-s085><stand_up.bestehen><en> No one was able to stand before them, for dread of them fell on all the peoples.
<G-vec00205-003-s086><stand_up.bestehen><de> Und wenn ein Haus mit sich selbst entzweit ist, kann dieses Haus nicht bestehen.
<G-vec00205-003-s086><stand_up.bestehen><en> And if a house be divided against itself, that house cannot stand.
<G-vec00205-003-s087><stand_up.bestehen><de> Zieht die ganze Waffenrüstung Gottes an, damit ihr gegen die Listen des Teufels bestehen könnt.
<G-vec00205-003-s087><stand_up.bestehen><en> Put on all of God's armor so that you will be able to stand firm against all strategies and tricks of the Devil.
<G-vec00205-003-s088><stand_up.bestehen><de> In den Beitrittsländern sind noch erhebliche Anstrengungen notwendig, um die Landwirt-schaft und besonders die Verarbeitungsindustrie in ihrer Wettbewerbskraft zu stärken, damit sie gegen die erhöhte Konkurrenz in einer erweiterten EU bestehen können.
<G-vec00205-003-s088><stand_up.bestehen><en> In the acceding countries, great efforts are still required to strengthen the competitiveness of agriculture and food processors so that they are able to stand up to the strong competition prevailing in the EU.
<G-vec00205-003-s089><stand_up.bestehen><de> 24 Und er wird ihre Könige in deine Hand geben, und du wirst ihre Namen vernichten unter dem Himmel hinweg; kein Mensch wird vor dir bestehen, bis du sie vertilgt hast.
<G-vec00205-003-s089><stand_up.bestehen><en> 24 And he shall deliver their kings into your hands, and ye shall destroy their name from that place; none shall stand up in opposition before thee, until thou shalt have utterly destroyed them.
<G-vec00205-003-s090><stand_up.bestehen><de> Das ZIEL, deine Statistik vollständig "grün" einzufärben, ruhig in die Prüfung zu gehen und AUF ANHIEB BESTEHEN.
<G-vec00205-003-s090><stand_up.bestehen><en> The OBJECTIVE to color your stats completely "green", to calmly go into the exam and to STAND ON AN OPPORTUNITY.
<G-vec00205-003-s091><stand_up.bestehen><de> Sie bestehen aus weichem und zugleich widerstandsfähigem Pinselhaar und werden von einem schwarzen Etui geschützt, damit sie ihre Eleganz lang behalten.
<G-vec00205-003-s091><stand_up.bestehen><en> With a selection of soft yet resilient bristles, protected in a black holder, they stand the test of time in complete elegance.
<G-vec00205-003-s092><stand_up.bestehen><de> 119:91 Nach deinen Ordnungen bestehen sie bis heute, denn alles ist dir dienstbar.
<G-vec00205-003-s092><stand_up.bestehen><en> 119:91 They stand this day according to Thine ordinances; for all things are Thy servants.
<G-vec00205-003-s093><stand_up.bestehen><de> Dann wird der König des Südens sich aufmachen zum Kampf mit einem großen, mächtigen Heer, aber er wird nicht bestehen; denn es werden Pläne gegen ihn geschmiedet.
<G-vec00205-003-s093><stand_up.bestehen><en> 25And he shall stir up his power and his courage against the king of the south with a great army; and the king of the south shall be stirred up to battle with a very great and mighty army; but he shall not stand: for they shall forecast devices against him.
<G-vec00205-003-s094><stand_up.bestehen><de> 5 Darum bestehen die Gottlosen nicht im Gericht noch die Sünder in der Gemeinde der Gerechten.
<G-vec00205-003-s094><stand_up.bestehen><en> 5 the wicked will not stand firm at the Judgement nor sinners in the gathering of the upright.
<G-vec00209-003-s057><pass_out.bestehen><de> 2011 hat er als einer der ersten Entwickler die Prüfung zum Magento Certified Developer bestanden.
<G-vec00209-003-s057><pass_out.bestehen><en> In 2011, he was one of the very first developers to pass the Magento Certified Developer examination.
<G-vec00209-003-s058><pass_out.bestehen><de> Sie müssen Ihr erstes Jahr bestanden haben, um zum zweiten Jahr überzugehen.
<G-vec00209-003-s058><pass_out.bestehen><en> You must pass your first year assessments in order to proceed to the second year.
<G-vec00209-003-s059><pass_out.bestehen><de> b) Er hat für mindestens zwei Prüfungsaufgaben die Note BESTANDEN erhalten.
<G-vec00209-003-s059><pass_out.bestehen><en> (b) he has been awarded a PASS grade in at least two papers, and
<G-vec00209-003-s060><pass_out.bestehen><de> Nachdem die Schüler einen praktischen Rettungstest und einen Theorietest erfolgreich bestanden haben, werden sie als SDI-Retter zertifiziert.
<G-vec00209-003-s060><pass_out.bestehen><en> After the students successfully pass a practical rescue test and a theory test, they will be certified as SDI rescuers.
<G-vec00209-003-s061><pass_out.bestehen><de> Die Befragten, die die Screening-Frage (n) nicht bestanden haben und sich nicht zu einer Umfrage qualifiziert haben, erreichen die Bildschirmseite und werden in die allgemeine IR des Projekts einbezogen.
<G-vec00209-003-s061><pass_out.bestehen><en> The respondents who didn't pass the screening question(s) and didn't qualify into a survey, reach the screen out page and are calculate into the overall IR of the project.
<G-vec00209-003-s062><pass_out.bestehen><de> Bestanden: Wenn Sie die Klausur bestanden haben (4,0 oder besser) können Sie die Note und die entsprechenden ECTS auf MeinCampus einsehen.
<G-vec00209-003-s062><pass_out.bestehen><en> Pass: if you get a passing grade (4.0 or better), you can see the grade and ECTS gained on MeinCampus.
<G-vec00209-003-s063><pass_out.bestehen><de> Wenn Sie alle Lektionen beendet und die Tests vom Kurs bestanden haben, erhalten Sie ein Abschlusszertifikat.
<G-vec00209-003-s063><pass_out.bestehen><en> You receive a Certificate of Completion when you finish all the lessons and pass all the tests in a course.
<G-vec00209-003-s064><pass_out.bestehen><de> Die Prüfung ist bestanden, wenn innerhalb von 2,5 Stunden (150 Minuten) mindestens 44 der insgesamt 80 Punkte (55%) erzielt wurden.
<G-vec00209-003-s064><pass_out.bestehen><en> Participants must gain a minimum of 38 out of 68 available marks (55%) to successfully pass the exam.
<G-vec00209-003-s065><pass_out.bestehen><de> SCHOTT ist das erste Unternehmen weltweit, das seine Verglasungen einer Prüfung der gleichzeitigen Mehrfachbelastung unterzogen und erfolgreich bestanden hat.
<G-vec00209-003-s065><pass_out.bestehen><en> SCHOTT is the first company in the world to subject its glazings to a test that includes multiple stresses and successfully pass it.
<G-vec00209-003-s066><pass_out.bestehen><de> Für beide Prozessstufen bestanden die Aachener Forscher die strengen Prüfungen der Aufsichts- und Genehmigungsbehörden.
<G-vec00209-003-s066><pass_out.bestehen><en> The researchers in Aachen must pass the stringent tests of the supervisory and regulatory authorities for both of these stages.
<G-vec00209-003-s067><pass_out.bestehen><de> In einer anderen Testgruppe, die nicht mit dieser Technologie ausgebildet worden war, haben nur 27% die gleiche Prüfung bestanden.
<G-vec00209-003-s067><pass_out.bestehen><en> A control group, not so trained, had a 27 percent pass rate on the same test. Next
<G-vec00209-003-s068><pass_out.bestehen><de> Herausforderungen sind hier oftmals spezielle Akkuformen, die extrem schlank und dennoch so formstabil sein müssen, dass die Belastungstests der notwendigen Zertifizierungen bestanden werden.
<G-vec00209-003-s068><pass_out.bestehen><en> The challenge often lies in the special battery shapes that must be extremely slim and yet stable enough to pass the stress tests of the required certifications.
<G-vec00209-003-s069><pass_out.bestehen><de> Wenn ein Produkt die optische Überprüfung bestanden hat, können wir dessen 100%-ig fehlerfreie Funktion durch einen Funktionstest garantieren.
<G-vec00209-003-s069><pass_out.bestehen><en> When the products pass the optical inspection, functional testing is made to guarantee that they are 100 % reliable.
<G-vec00209-003-s070><pass_out.bestehen><de> Für die Bachelorstudiengänge im Fach Sport (außer Human Movements in Sports and Exercise) und für die Bachelorstudiengänge im Fach Musik (außer Musikwissenschaft) muss (zusätzlich) vor der Bewerbung eine Eignungsprüfung bestanden werden.
<G-vec00209-003-s070><pass_out.bestehen><en> Those who apply for admission to bachelor's programmes in Sport and Physical Education (not including Human Movement in Sports and Exercise) and bachelor's programmes in Music (not including Musicology) are also required to pass an aptitude test.
<G-vec00209-003-s071><pass_out.bestehen><de> Durch diesen Prozess habe ich erkannt: Wenn ich nicht so hart gearbeitet und nicht mein Bestes gegeben hätte, dann hätte ich das Examen nicht bestanden.
<G-vec00209-003-s071><pass_out.bestehen><en> From my studies and exam preparation I realized that, if I did not work very hard, did not try my best, I would not pass the exam.
<G-vec00209-003-s072><pass_out.bestehen><de> Somit ist die Antwort - ja, wir haben die Prüfung bestanden.
<G-vec00209-003-s072><pass_out.bestehen><en> So the answer is yes, we did pass the inspection.
<G-vec00209-003-s073><pass_out.bestehen><de> Weiterhin entscheidet das Testkompetenzzentrum, ob das geprüfte Testobjekt die Tests bestanden hat oder nicht.
<G-vec00209-003-s073><pass_out.bestehen><en> Furthermore the test center decides whether to pass or fail the evaluated test object.
<G-vec00209-003-s074><pass_out.bestehen><de> Optional - Mach dir keine Sorgen, falls du eine Warnung erhälst, dass der TAP Driver den Driver Signing Test (bei Microsoft) nicht bestanden hat.
<G-vec00209-003-s074><pass_out.bestehen><en> Optional - If you receive a warning that the TAP driver didn't pass the driver signing check by Microsoft - this is nothing to worry about.
<G-vec00209-003-s075><pass_out.bestehen><de> Die Bestanden/Versagen-Kette ist eine binäre Datenkette.
<G-vec00209-003-s075><pass_out.bestehen><en> The pass/fail string is a binary data string.
<G-vec00283-003-s057><pass_on.bestehen><de> 2011 hat er als einer der ersten Entwickler die Prüfung zum Magento Certified Developer bestanden.
<G-vec00283-003-s057><pass_on.bestehen><en> In 2011, he was one of the very first developers to pass the Magento Certified Developer examination.
<G-vec00283-003-s058><pass_on.bestehen><de> Sie müssen Ihr erstes Jahr bestanden haben, um zum zweiten Jahr überzugehen.
<G-vec00283-003-s058><pass_on.bestehen><en> You must pass your first year assessments in order to proceed to the second year.
<G-vec00283-003-s059><pass_on.bestehen><de> b) Er hat für mindestens zwei Prüfungsaufgaben die Note BESTANDEN erhalten.
<G-vec00283-003-s059><pass_on.bestehen><en> (b) he has been awarded a PASS grade in at least two papers, and
<G-vec00283-003-s060><pass_on.bestehen><de> Nachdem die Schüler einen praktischen Rettungstest und einen Theorietest erfolgreich bestanden haben, werden sie als SDI-Retter zertifiziert.
<G-vec00283-003-s060><pass_on.bestehen><en> After the students successfully pass a practical rescue test and a theory test, they will be certified as SDI rescuers.
<G-vec00283-003-s061><pass_on.bestehen><de> Die Befragten, die die Screening-Frage (n) nicht bestanden haben und sich nicht zu einer Umfrage qualifiziert haben, erreichen die Bildschirmseite und werden in die allgemeine IR des Projekts einbezogen.
<G-vec00283-003-s061><pass_on.bestehen><en> The respondents who didn't pass the screening question(s) and didn't qualify into a survey, reach the screen out page and are calculate into the overall IR of the project.
<G-vec00283-003-s062><pass_on.bestehen><de> Bestanden: Wenn Sie die Klausur bestanden haben (4,0 oder besser) können Sie die Note und die entsprechenden ECTS auf MeinCampus einsehen.
<G-vec00283-003-s062><pass_on.bestehen><en> Pass: if you get a passing grade (4.0 or better), you can see the grade and ECTS gained on MeinCampus.
<G-vec00283-003-s063><pass_on.bestehen><de> Wenn Sie alle Lektionen beendet und die Tests vom Kurs bestanden haben, erhalten Sie ein Abschlusszertifikat.
<G-vec00283-003-s063><pass_on.bestehen><en> You receive a Certificate of Completion when you finish all the lessons and pass all the tests in a course.
<G-vec00283-003-s064><pass_on.bestehen><de> Die Prüfung ist bestanden, wenn innerhalb von 2,5 Stunden (150 Minuten) mindestens 44 der insgesamt 80 Punkte (55%) erzielt wurden.
<G-vec00283-003-s064><pass_on.bestehen><en> Participants must gain a minimum of 38 out of 68 available marks (55%) to successfully pass the exam.
<G-vec00283-003-s065><pass_on.bestehen><de> SCHOTT ist das erste Unternehmen weltweit, das seine Verglasungen einer Prüfung der gleichzeitigen Mehrfachbelastung unterzogen und erfolgreich bestanden hat.
<G-vec00283-003-s065><pass_on.bestehen><en> SCHOTT is the first company in the world to subject its glazings to a test that includes multiple stresses and successfully pass it.
<G-vec00283-003-s066><pass_on.bestehen><de> Für beide Prozessstufen bestanden die Aachener Forscher die strengen Prüfungen der Aufsichts- und Genehmigungsbehörden.
<G-vec00283-003-s066><pass_on.bestehen><en> The researchers in Aachen must pass the stringent tests of the supervisory and regulatory authorities for both of these stages.
<G-vec00283-003-s067><pass_on.bestehen><de> In einer anderen Testgruppe, die nicht mit dieser Technologie ausgebildet worden war, haben nur 27% die gleiche Prüfung bestanden.
<G-vec00283-003-s067><pass_on.bestehen><en> A control group, not so trained, had a 27 percent pass rate on the same test. Next
<G-vec00283-003-s068><pass_on.bestehen><de> Herausforderungen sind hier oftmals spezielle Akkuformen, die extrem schlank und dennoch so formstabil sein müssen, dass die Belastungstests der notwendigen Zertifizierungen bestanden werden.
<G-vec00283-003-s068><pass_on.bestehen><en> The challenge often lies in the special battery shapes that must be extremely slim and yet stable enough to pass the stress tests of the required certifications.
<G-vec00283-003-s069><pass_on.bestehen><de> Wenn ein Produkt die optische Überprüfung bestanden hat, können wir dessen 100%-ig fehlerfreie Funktion durch einen Funktionstest garantieren.
<G-vec00283-003-s069><pass_on.bestehen><en> When the products pass the optical inspection, functional testing is made to guarantee that they are 100 % reliable.
<G-vec00283-003-s070><pass_on.bestehen><de> Für die Bachelorstudiengänge im Fach Sport (außer Human Movements in Sports and Exercise) und für die Bachelorstudiengänge im Fach Musik (außer Musikwissenschaft) muss (zusätzlich) vor der Bewerbung eine Eignungsprüfung bestanden werden.
<G-vec00283-003-s070><pass_on.bestehen><en> Those who apply for admission to bachelor's programmes in Sport and Physical Education (not including Human Movement in Sports and Exercise) and bachelor's programmes in Music (not including Musicology) are also required to pass an aptitude test.
<G-vec00283-003-s071><pass_on.bestehen><de> Durch diesen Prozess habe ich erkannt: Wenn ich nicht so hart gearbeitet und nicht mein Bestes gegeben hätte, dann hätte ich das Examen nicht bestanden.
<G-vec00283-003-s071><pass_on.bestehen><en> From my studies and exam preparation I realized that, if I did not work very hard, did not try my best, I would not pass the exam.
<G-vec00283-003-s072><pass_on.bestehen><de> Somit ist die Antwort - ja, wir haben die Prüfung bestanden.
<G-vec00283-003-s072><pass_on.bestehen><en> So the answer is yes, we did pass the inspection.
<G-vec00283-003-s073><pass_on.bestehen><de> Weiterhin entscheidet das Testkompetenzzentrum, ob das geprüfte Testobjekt die Tests bestanden hat oder nicht.
<G-vec00283-003-s073><pass_on.bestehen><en> Furthermore the test center decides whether to pass or fail the evaluated test object.
<G-vec00283-003-s074><pass_on.bestehen><de> Optional - Mach dir keine Sorgen, falls du eine Warnung erhälst, dass der TAP Driver den Driver Signing Test (bei Microsoft) nicht bestanden hat.
<G-vec00283-003-s074><pass_on.bestehen><en> Optional - If you receive a warning that the TAP driver didn't pass the driver signing check by Microsoft - this is nothing to worry about.
<G-vec00283-003-s075><pass_on.bestehen><de> Die Bestanden/Versagen-Kette ist eine binäre Datenkette.
<G-vec00283-003-s075><pass_on.bestehen><en> The pass/fail string is a binary data string.
