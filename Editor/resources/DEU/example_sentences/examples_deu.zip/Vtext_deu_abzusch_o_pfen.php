<G-vec00169-001-s018><siphon.abzuschöpfen><de> Es gibt in den Installationen immer die Möglichkeit, eindeutige Informationen und Bilder abzuschöpfen.
<G-vec00169-001-s018><siphon.abzuschöpfen><en> In his installations, there is always an opportunity to siphon off unequivocal information and images.
