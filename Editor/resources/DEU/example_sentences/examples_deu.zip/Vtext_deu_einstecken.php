<G-vec00276-001-s061><plug.einstecken><de> So lassen diese sich sehr einfach entnehmen und auch wieder einstecken.
<G-vec00276-001-s061><plug.einstecken><en> So they are very easy to remove and plug in again.
<G-vec00276-001-s062><plug.einstecken><de> Eigentlich so wie wenn wir einen Fön kaufen und den zuhause einstecken.
<G-vec00276-001-s062><plug.einstecken><en> Actually, it's like the hair drier we buy and just plug in at home.
<G-vec00276-001-s063><plug.einstecken><de> SUCOFLEX 500: Einstecken, testen, lächeln.
<G-vec00276-001-s063><plug.einstecken><en> SUCOFLEX 500: Plug, test, smile.
<G-vec00276-001-s064><plug.einstecken><de> Durch den Kopfhörereingang ist es kein Problem, früh am Morgen oder spät in der Nacht zu üben – einfach einstecken und los geht's, ohne die Nachbarn zu stören.
<G-vec00276-001-s064><plug.einstecken><en> The headphone input means that it's no problem to practice early in the morning or late at night - just plug in and away you go without disturbing the neighbours.
<G-vec00276-001-s065><plug.einstecken><de> Der Schraubverschluss hält den Schlauch fest, aber es schadet auch nicht, das Schlauchende vor dem Einstecken zuerst kurz mit einem Feuerzeug zu erwärmen, damit es sich beim Abkühlen fest um das Winkelstück zieht.
<G-vec00276-001-s065><plug.einstecken><en> The screw plug holds tight to the hose, but it helps to warm up the hose with a lighter before sticking it onto the angle .
<G-vec00276-001-s066><plug.einstecken><de> Es verfügt über 16 Modelle eines akustischen Instruments, sodass die Antwort entsprechen und verbessern die Art der Gitarre, die Sie einstecken.
<G-vec00276-001-s066><plug.einstecken><en> It features 16 models of acoustic instrument so that the response will match and enhance the type of guitar you plug in.
<G-vec00276-001-s067><plug.einstecken><de> "Rückseite der Loudbox Mini hat den Wechselstrom Eingang, Netzschalter, Aux-Eingang 1/4"" und 1/8"" wo können Sie einstecken line Level stereo-audio-Quellen können Sie mitspielen, mit Ihrer Lieblingsmusik von CD oder MPs Spieler."
<G-vec00276-001-s067><plug.einstecken><en> "The Loudbox Mini's rear panel has the AC Power input, power switch, Aux Input 1/4"" and 1/8"" where you can plug in line level stereo audio sources allowing you to play along with your favourite tracks from CD or MPs players."
<G-vec00276-001-s068><plug.einstecken><de> Auf beiden Seiten einstecken – und fertig zur Installation, Inbetriebnahme oder Anlageninfo.
<G-vec00276-001-s068><plug.einstecken><en> Plug it in at both ends – and you are ready for installation, commissioning or plant information.
<G-vec00276-001-s069><plug.einstecken><de> Der Zigarettenanzünder zum automatischen Einstecken, der für das automatische Feuerzeugladesystem verwendet wird.
<G-vec00276-001-s069><plug.einstecken><en> The cigarette plug to auto plug, Which used for auto lighter charging system.
<G-vec00276-001-s070><plug.einstecken><de> Mehr, beim Einstecken einer Speicherkarte oder einem USB-Speichergerät, Chrome OS automatisch öffnet sich ein Fenster mit dem Inhalt, so dass Sie zu öffnen oder mit den Dateien arbeiten.
<G-vec00276-001-s070><plug.einstecken><en> Plus, when you plug in a memory card or USB storage device, Chrome OS automatically pops up a window with its contents, allowing you to open or work with the files.
<G-vec00276-001-s071><plug.einstecken><de> Bei der Umrüstung ist darauf zu achten das die Blinkerfassungen gegen (nicht im Lieferumfang enthalten) 3polige US-Model Blinkerfassungen mit passenden Leuchtmitteln zu tauschen sind (originale lassen sich nicht einstecken)und die Verkabelung zur Standlichtbeleuchtung extra vor zunehmen ist.
<G-vec00276-001-s071><plug.einstecken><en> When the conversion to ensure that the flashers versions against (not included) 3-pin US-model turn signal sockets are to swap with matching lamps (original can not plug in) and the wiring for lighting parking is extra increase before.
<G-vec00276-001-s072><plug.einstecken><de> Einstecken und wegfliegen.
<G-vec00276-001-s072><plug.einstecken><en> Plug in and fly away.
<G-vec00276-001-s073><plug.einstecken><de> Die Batterieprozentsatz auf iPhones gezeigt ist eine großartige Möglichkeit zu beurteilen, ob oder nicht müssen Sie einstecken und aufladen.
<G-vec00276-001-s073><plug.einstecken><en> The battery percentage shown on iPhones is a great way to gauge whether or not you need to plug it in and charge it.
<G-vec00276-001-s074><plug.einstecken><de> Glasmundstück einfach zum Einstecken in den Silikonschlauch.
<G-vec00276-001-s074><plug.einstecken><en> Glass mouthpiece to simply plug into the silicone hose.
<G-vec00276-001-s075><plug.einstecken><de> Ist für Produktionen Originalton vom Standort erforderlich, können Sie das eingebaute Mikrofon benutzen oder über die XLR-Buchsen der Kamera professionelle externe Mikrofone – sogar phantomgespeiste – einstecken.
<G-vec00276-001-s075><plug.einstecken><en> For productions that require live location sound, you can use the built in stereo microphone or plug in professional external microphones, even with phantom power, into the camera’s XLR connectors!
<G-vec00276-001-s076><plug.einstecken><de> Einfach einstecken und loslegen!Sogar bis zu einer Auflösung von Full HD 1080p.
<G-vec00276-001-s076><plug.einstecken><en> Just plug and play! Even up to a resolution of Full HD 1080p.
<G-vec00276-001-s077><plug.einstecken><de> Die gut aussehend Empire-Tabelle ist ein perfekter Ort zum Einstecken und melden Sie sich an Ihre e-Mails oder im Internet surfen.
<G-vec00276-001-s077><plug.einstecken><en> The handsome Empire table is a perfect place to plug in and log on to check your e-mail, or surf the web.
<G-vec00276-001-s078><plug.einstecken><de> SJ-ODB-SQ12 Kunststoff FTTX Indoor / Outdoor Glasfaser Termination Boxes 8SC Verteilerkasten Schubladen-Typ und Plug & Play PLC-Spipper-Kassette wird in der Box verwendet und es ist sehr praktisch für den Betrieb durch einfaches Einstecken und ziehen Sie den Container-Kassetten-Splitter.
<G-vec00276-001-s078><plug.einstecken><en> SJ ODB SQ12 Plastic FTTX Indoor Outdoor Fibre Optic Termination Boxes 8SC Distribution Box Drawer type and plug play PLC spliiter cassette is used in the box and it give very convenient for operating by just plug in and draw out the containerized cassette splitter The box inner space is divided into 2 parts the base... Contact Now
<G-vec00276-001-s079><plug.einstecken><de> "In dieses Etui können Sie in Variante 1 das kleine tablet (Ipad mini) und bei Variante 2 das Ipad oder ein tablet von 10 "" einfach einstecken."
<G-vec00276-001-s079><plug.einstecken><en> "In this case you can use in variant 1 the small tablet (Ipad mini) or in variant 2 the Ipad or a tablet in size 10"" just plug in ."
<G-vec00272-002-s209><beg.einstecken><de> Deshalb haben sie Brillen mit Materialarten entwickelt, die ordentlich einstecken können.
<G-vec00272-002-s209><beg.einstecken><en> That’s why they engineered eyewear with materials that beg for abuse.
<G-vec00276-002-s098><plug.einstecken><de> Dank dieser portablen Version kann man ihn auf jedem Computer benutzen, man muss nur den USB-Stick einstecken und schon kann man ihn verwenden.
<G-vec00276-002-s098><plug.einstecken><en> Thanks to this new portable release you will have it in any computer you use, because you only have to plug your USB key and it will be ready to be used.
<G-vec00276-002-s099><plug.einstecken><de> Zumindest nicht, bis man die Musik einstecken und die Welt ausblenden möchte.
<G-vec00276-002-s099><plug.einstecken><en> That is, until you want to plug into the music and unplug from the world.
<G-vec00276-002-s100><plug.einstecken><de> FUNKTIONSWEISE Das Gerat einstecken und auf die Hitze unempfindliche Aufbewahrungstasche legen.
<G-vec00276-002-s100><plug.einstecken><en> OPERATION Plug in the appliance and place on the heat-resistance storage bag.
<G-vec00276-002-s101><plug.einstecken><de> Wenn Sie den Stecker mit Gewalt einstecken, wird der Anschluss beschädigt und es kann zu einer Fehlfunktion des Camcorders kommen.
<G-vec00276-002-s101><plug.einstecken><en> If you are unable to insert the plug fully into the outlet, try reversing the plug.
<G-vec00276-002-s102><plug.einstecken><de> Eine Ladestelle ist also in Wirklichkeit kein Ladegerät, sondern eine intelligente Steckdose zum Einstecken deines Ladekabels.
<G-vec00276-002-s102><plug.einstecken><en> So a charge point is not actually a charger but an intelligent socket to plug in your charge cable.
<G-vec00276-002-s103><plug.einstecken><de> Sie müssen Ihr Gerät einstecken, darauf achten, dass Ihr Mac es erkennt, und dann diese Seagate-Datenwiederherstellung in Ihrem Mac (macOS High Sierra unterstützt) ausführen, um den Seagate-Festplattenwiederherstellungsprozess zu starten.
<G-vec00276-002-s103><plug.einstecken><en> You will need to plug your device, make sure your mac recognizes it and then launch this Seagate data recovery installed in your Mac (macOS High Sierra supported) to begin the Seagate hard drive recovery process.
<G-vec00276-002-s104><plug.einstecken><de> Den USB-Empfänger entfernen und das Ladekabel einstecken zum Aufladen von Spotlight für 1 Minute.
<G-vec00276-002-s104><plug.einstecken><en> Remove the USB receiver and plug in the charging cable to charge your Spotlight for 1 minute.
<G-vec00276-002-s105><plug.einstecken><de> Jetzt nur noch den Decoder einstecken – Einbau abgeschlossen.
<G-vec00276-002-s105><plug.einstecken><en> Then just plug in the decoder - the installation is ready.
<G-vec00276-002-s106><plug.einstecken><de> Es gibt eine Stereoanlage mit Außenlautsprechern am Pool und einen Essbereich im Freien, wo Sie auch Ihr Handy oder Tablet in die Stereoanlage einstecken und Ihre Lieblingscharts spielen können.
<G-vec00276-002-s106><plug.einstecken><en> There is a HI-FI sound system with loud speakers outdoors by the pool and outdoor dining area where you can also plug your mobile phone or tablet into the stereo and play your favorite charts.
<G-vec00276-002-s107><plug.einstecken><de> Niedervolt-Halogenlampen, die eine noch höhere Lichtausbeute und Lebensdauer haben, ähneln den Lampen mit G9-Sockel (Sockelbezeichnungen G4, 5 oder 6 – im Unterschied zum G9-Sockel mit rundgebogenen Metallverbindungen haben die Niedervoltsockel gerade Stifte zum Einstecken).
<G-vec00276-002-s107><plug.einstecken><en> Low-voltage halogen bulbs, which have an even higher luminous efficiency and lifetime, are similar to those with a G9 socket (socket G4, 5 or 6 - unlike the G9 socket with round-bent metal connections, the low-volt socket has straight pins to plug in).
<G-vec00276-002-s108><plug.einstecken><de> Einfach nur die Einheit an das Modell anbringen und den1S Akku (separat erhältlich) einstecken.
<G-vec00276-002-s108><plug.einstecken><en> You simply attach it to your model and plug in a 1S battery (sold separately).
<G-vec00276-002-s109><plug.einstecken><de> Einfach einstecken und loopen.
<G-vec00276-002-s109><plug.einstecken><en> Just plug in and loop.
<G-vec00276-002-s110><plug.einstecken><de> Wie auf dem Bildschirm angewiesen, sollten Sie das Laplink Ethernetkabel zu diesem Zeitpunkt nur in Ihren ALTEN PC einstecken.
<G-vec00276-002-s110><plug.einstecken><en> Note: As instructed on this screen, you should ONLY plug the Laplink Ethernet cable into your old PC.
<G-vec00276-002-s111><plug.einstecken><de> Einfach einstecken und den Schritten des Handbuches folgen und schon kann es losgehen.
<G-vec00276-002-s111><plug.einstecken><en> Just plug it in and, follow the steps of the manual and you will be ready to go.
<G-vec00276-002-s112><plug.einstecken><de> Manche Tastaturen haben auch selbst einen USB Port, in den du deine Maus einstecken kannst.
<G-vec00276-002-s112><plug.einstecken><en> Some keyboards have USB ports as well that you can plug your mouse into.
<G-vec00276-002-s113><plug.einstecken><de> Die mitgelieferte Kopfhörer-ID erkennt Kopfhörer, die an die Steckerleisten neben einem Bett angeschlossen sind, so dass Gäste einfach den Kopfhörer einstecken und TV-Beiträge anhören können, ohne dabei andere Personen im Raum zu stören.
<G-vec00276-002-s113><plug.einstecken><en> The included Headphone ID detects headphones connected to the extension sockets next to a bed where your guests can simply plug headphones to listen to the TV without disturbing others in the room.
<G-vec00276-002-s114><plug.einstecken><de> Da ich nicht genug Bares einstecken hatte, musste ich ausnahmsweise Mal mit der Karte zahlen.
<G-vec00276-002-s114><plug.einstecken><en> Since I did not have enough plug in cash, I had to pay for once with the card.
<G-vec00276-002-s115><plug.einstecken><de> Und dank intelligenter Software gibt es auch kein kompliziertes Einrichten: Das Laufwerk einfach einstecken und sofort loslegen.
<G-vec00276-002-s115><plug.einstecken><en> Plus, with smart software there’s no complicated setup: just plug in and start using your drive straight away.
<G-vec00276-002-s116><plug.einstecken><de> Sobald das getan wurde, muss man den USB-Stick einstecken und den PC neustarten, dann wird die Linux-Distribution erkannt und gestartet.
<G-vec00276-002-s116><plug.einstecken><en> Once we have created it, we will only have to plug in our USB device before the computer will restart and the Linux distribution will be run automatically.
