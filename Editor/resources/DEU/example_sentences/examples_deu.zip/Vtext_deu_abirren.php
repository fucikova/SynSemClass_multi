<G-vec00227-002-s019><wander.abirren><de> Ich suche dich von ganzem Herzen; laß mich nicht abirren von deinen Geboten.
<G-vec00227-002-s019><wander.abirren><en> With my whole heart have I sought thee: O let me not wander from thy commandments.
<G-vec00227-002-s020><wander.abirren><de> 119:21 Gescholten hast du die Übermütigen, die Verfluchten, welche abirren von deinen Geboten.
<G-vec00227-002-s020><wander.abirren><en> 119:21 Thou hast rebuked the proud that are cursed, That do wander from thy commandments.
