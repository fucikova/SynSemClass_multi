<G-vec00380-002-s002><abdicate.abdanken><de> Aber Miguel begann ein Terrorregime, bis er 1834 abdanken musste.
<G-vec00380-002-s002><abdicate.abdanken><en> But Miguel began a reign of terror that lasted until he was forced to abdicate in 1834.
<G-vec00380-002-s003><abdicate.abdanken><de> Polizeipräfekt Delavau und Polizeichef Duplessis mussten in seiner Abwesenheit zurücktreten und Karl X. während der Julirevolution 1830 abdanken.
<G-vec00380-002-s003><abdicate.abdanken><en> In the short time while he was away from Paris, both Delavau and Duplessis had to resign their posts, and the July Revolution of 1830 forced Charles X to abdicate.
<G-vec00380-002-s004><abdicate.abdanken><de> Im März 1814 wurde Paris besetzt und Napoleon wurde zum Abdanken gezwungen.
<G-vec00380-002-s004><abdicate.abdanken><en> In March 1814 Paris was occupied and Napoleon was forced to abdicate.
<G-vec00380-002-s005><abdicate.abdanken><de> Sun Yatsen wurde der erste Präsident Chinas, nachdem der Kaiser 1912 abdanken musste.
<G-vec00380-002-s005><abdicate.abdanken><en> Sun Yatsen became the first president of China after the emperor had to abdicate in 1912.
