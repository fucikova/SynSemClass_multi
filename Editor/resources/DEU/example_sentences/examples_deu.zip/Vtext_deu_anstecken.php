<G-vec00635-002-s020><infect.anstecken><de> Es ist dem Büro immer gelungen, begeisterungsfähige Menschen zu gewinnen, die sich gegenseitig mit der Neugier auf spannende Projekte anstecken.
<G-vec00635-002-s020><infect.anstecken><en> The company has always succeeded in attracting enthusiastic members of staff, who infect one another with curiosity about exciting projects.
<G-vec00635-002-s021><infect.anstecken><de> Mütter, die an Genitalherpes leiden, können Ihr Baby bei der Geburt mit dieser Krankheit anstecken, weshalb so viele Ärzte einen Kaiserschnitt empfehlen, um das Ansteckungsrisiko für das Neugeborene zu verringern.
<G-vec00635-002-s021><infect.anstecken><en> Mothers suffering from genital herpes can infect their baby with this disease at birth, which is why so many doctors opt for caesarean section to reduce the risk of infecting the newborn.
<G-vec00635-002-s022><infect.anstecken><de> Auch Menschen, die keine Symptome spüren, können andere anstecken.
<G-vec00635-002-s022><infect.anstecken><en> People with no symptoms can still infect others. Reden
<G-vec00635-002-s023><infect.anstecken><de> Wenn jemand hustet, redet, niest, können Keime in die Luft gelangen, die andere in der Nähe anstecken können.
<G-vec00635-002-s023><infect.anstecken><en> When someone coughs, talks, sneezes they could release germs into the air that may infect others nearby.
<G-vec00635-002-s024><infect.anstecken><de> Sie liebt es, Touristen mit den bemerkenswerten Eigenschaften ihrer Heimat vertraut zu machen und sie mit ihrer Liebe zu Armenien zu anstecken.
<G-vec00635-002-s024><infect.anstecken><en> She loves to acquaint tourists with the remarkable features of her homeland and infect them with her love to Armenia.
<G-vec00635-002-s025><infect.anstecken><de> Ist das Lachen echt, wird es automatisch das ganze #Team über die #Spiegelhormone anstecken.
<G-vec00635-002-s025><infect.anstecken><en> If the laughter is real, it will automatically infect the whole #team via the #mirror hormones.
<G-vec00635-002-s026><infect.anstecken><de> Ich werde dich mit meiner positiven Stimmung anstecken, lächeln und meine sinnliche Berührung wird dich verrückt machen.
<G-vec00635-002-s026><infect.anstecken><en> I will infect you with my positive mood, smile, and my sensual touch will drive you crazy.
<G-vec00635-002-s027><infect.anstecken><de> Es funktioniert, indem es Aknebakterien tötet, die Hautporen anstecken.
<G-vec00635-002-s027><infect.anstecken><en> It works by killing acne bacteria that infect skin pores.
<G-vec00635-002-s028><infect.anstecken><de> Außerdem sollte ein Regisseur seine künstlerischen Mitstreiter, aber auch Intendanten und Kulturpolitiker mit seinen Ideen anstecken können.
<G-vec00635-002-s028><infect.anstecken><en> In addition, a director should have the ability to infect not only his artistic colleagues but also general directors and cultural decision-makers with his ideas.
<G-vec00635-002-s029><infect.anstecken><de> Bei manchen Betroffenen zeigen sich gar keine Symptome, sie tragen den Virus aber in sich und können so andere anstecken.
<G-vec00635-002-s029><infect.anstecken><en> Some people have no symptoms but still carry the virus, so they can infect others.
<G-vec00635-002-s030><infect.anstecken><de> Gehe so schnell wie möglich in die nächste Bar und lasse dich von ihrer Leidenschaft anstecken, auch wenn dir Fußball nicht gefällt; die Atmosphäre wird dir gefallen, und wenn das Spiel gut endet, wird erneut der Jubel zu spüren sein und die Party kann bis in die frühen Morgenstunden dauern.
<G-vec00635-002-s030><infect.anstecken><en> Hurry to a bar and allow their passion to infect you; even if you do not like football, you will love the atmosphere that you will experience, and if the match ends well, joy will erupt once more and the party could go on well into the early hours.
<G-vec00635-002-s031><infect.anstecken><de> Lassen Sie sich von der Lebenslust dieser atemberaubenden Dame anstecken und verführen, den Linda weiß wie sie einen Mann befriedigen und ihm das Gefühl geben kann etwas ganz Besonderes zu sein.
<G-vec00635-002-s031><infect.anstecken><en> Let the lust for life of this breathtaking lady infect and seduce you, whom Linda knows how to satisfy a man and give him the feeling to be something very special.
<G-vec00635-002-s032><infect.anstecken><de> Aber sowohl Personen, die leichte Symptome haben sowie solche, die asymptomatisch sind, können andere anstecken.
<G-vec00635-002-s032><infect.anstecken><en> But both those who have mild symptoms or are asymptomatic can infect others.
<G-vec00635-002-s033><infect.anstecken><de> Das Gesetz der Natur ist so perfekt, dass ihr leiden müsst, wenn ihr euch mit irgendeiner Krankheit oder Verunreinigung ansteckt.
<G-vec00635-002-s033><infect.anstecken><en> The nature's law is so perfect that if you infect something, some disease, some contamination, then you must suffer.
<G-vec00635-002-s034><infect.anstecken><de> Diese Lektion war offenbar unzureichend, da sie jetzt die Grenzen ihrer verfluchten Domäne verlassen haben, um den Rest des Festlandes mit ihren Ketzereien anzustecken.
<G-vec00635-002-s034><infect.anstecken><en> That lesson was apparently insufficient, for they have now left the boundaries of their cursed domain, and seek to infect the rest of the mainland with their heresies.
<G-vec00635-002-s035><infect.anstecken><de> Diese Art der Ausbildung kann euch junge Studenten in diese Richtung lenken und euch begleiten, und sie kann es tun mit der Frische der Aktualität und Kühnheit des Evangeliums, um neue Verkünder des Evangeliums heranzubilden, die bereit sind, die ganze Welt mit der Freude Christi anzustecken.
<G-vec00635-002-s035><infect.anstecken><en> The educational process can accompany and guide you, young students, in this direction, and it can do so with the freshness of current events and the boldness of the Gospel, to form new evangelizers ready to infect the world with the joy of Christ to the very ends of the earth.
<G-vec00635-002-s036><infect.anstecken><de> Gerade diese Fähigkeit von Klangphänomenen, partizipatorische Momente zu initiieren und Raum für Austausch zu schaffen, sowie ihre Fähigkeit andere anzustecken macht sie zu einem so besonders geeigneten Medium für die Weitergabe von Geschichte/n jenseits von Worten.
<G-vec00635-002-s036><infect.anstecken><en> It is this ability for auditory phenomena to instigate participatory moments and create spaces of exchange, and their ability to infect others, that makes the medium especially appropriate for transmitting histories beyond words.
<G-vec00635-002-s037><infect.anstecken><de> Und BVB-Trainer Lucien Favre konnte nur aus der Ferne coachen, weil er sich wegen seiner starken Erkältung auf Anraten der Vereinsärzte von seinen Spielern fernhalten sollte, um sie nicht anzustecken.
<G-vec00635-002-s037><infect.anstecken><en> And the BVB coach Lucien Favre was only able to coach from afar, because he should not hold himself due to his bad cold, on the advice of the club doctors of his players remote to infect them.
<G-vec00635-002-s061><infect.anstecken><de> Auch wir Großen freuen uns auf ein paar unbeschwerte Momente mit der ganzen Familie und lassen uns von der Euphorie unserer Kinder anstecken.
<G-vec00635-002-s061><infect.anstecken><en> We grown-ups also look forward to a few pleasant moments spent with the whole family and let the children's delight infect us.
