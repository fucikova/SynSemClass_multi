<G-vec00476-001-s009><eat_up.aufessen><de> Das ist so, als hätten sie etwas Essbares ausgespuckt, und wir würden es aufheben und aufessen.
<G-vec00476-001-s009><eat_up.aufessen><en> It's as if they spit out some food and we pick it up and eat it.
<G-vec00476-001-s010><eat_up.aufessen><de> Entsprechend, Sie werden größer aufessen, weil das Gefühl des Hungers nicht weggeht.
<G-vec00476-001-s010><eat_up.aufessen><en> Respectively, you will eat more because the feeling of hunger does not leave.
<G-vec00476-001-s011><eat_up.aufessen><de> Die Gefängniswachen sagten, dass sie das ganze beschlagnahmte Essen nicht aufessen konnten.
<G-vec00476-001-s011><eat_up.aufessen><en> The prison guards claimed publicly that they could not eat all the food they confiscated.
<G-vec00476-001-s012><eat_up.aufessen><de> "Einige ihnen sagen, dass Sie eine bestimmte Nahrung oder das Getränk aufessen können, weil sie von Ihrem Körper ""ignoriert"" sind."
<G-vec00476-001-s012><eat_up.aufessen><en> "Some of them say you can eat a certain food or beverage because they are ""ignored"" by your body."
<G-vec00476-001-s013><eat_up.aufessen><de> "Dabei berücksichtigen Sie, dass rejetschnyje die Hängedecken von 4 bis zu 7 cm der Höhe, und in einigen Fällen bis zu 12 ""aufessen""."
<G-vec00476-001-s013><eat_up.aufessen><en> "Thus consider that reechnye false ceilings ""eat"" from 4 to 7 sm of height, and in certain cases to 12."
<G-vec00476-001-s014><eat_up.aufessen><de> .. die Würste hat man bald aufessen müssen, weil sie waren nicht lange haltbar.
<G-vec00476-001-s014><eat_up.aufessen><en> And we had to eat the sausages soon because they didn't keep well...
<G-vec00476-001-s015><eat_up.aufessen><de> Der Dummling verlangte abermals seine Braut, der König aber ärgerte sich, daß ein schlechter Bursch, den jedermann einen Dummling nannte, seine Tochter davontragen sollte, und machte neue Bedingungen: Er müßte erst einen Mann schaffen, der einen Berg voll Brot aufessen könnte.
<G-vec00476-001-s015><eat_up.aufessen><en> The Simpleton again asked for his bride, but the king was annoyed that a wretched fellow, called the Simpleton by everybody, should carry off his daughter, and so he made new conditions. He was to produce a man who could eat up a mountain of bread.
<G-vec00476-001-s016><eat_up.aufessen><de> Des Nagetieres oder des Nestlings ist nötig es skarmliwat dem Vogel sofort nach der Abschlachtung, es muss dabei nicht, tuschki bearbeiten: der Vogel soll sowohl die Wolle, als auch die Federn, und des Knochens des Opfers unbedingt aufessen.
<G-vec00476-001-s016><eat_up.aufessen><en> The rodent or a baby bird should be fed to a bird at once after a face, thus it is not necessary to undress carcasses: the bird surely has to eat both wool, and feathers, and bones of the victim.
<G-vec00476-001-s017><eat_up.aufessen><de> Hin und wieder führte das zum Erbrechen, und das unglückliche Kind musste das aufessen.
<G-vec00476-001-s017><eat_up.aufessen><en> On occasion, this led to vomiting, which the unfortunate child was then forced to eat.
