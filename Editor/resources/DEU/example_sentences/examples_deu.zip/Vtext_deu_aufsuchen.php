<G-vec00057-001-s065><consult.aufsuchen><de> In diesem Fall müssen Sie einen Arzt aufsuchen.
<G-vec00057-001-s065><consult.aufsuchen><en> In this case, you must consult a doctor.
<G-vec00057-001-s066><consult.aufsuchen><de> Diese Nebenwirkungen sind sehr selten, aber wenn Sie eine Unverträglichkeit gegenüber einem Medikament vermuten, sollten Sie sofort einen Arzt aufsuchen.
<G-vec00057-001-s066><consult.aufsuchen><en> These side effects are very rare, but if you suspect a drug intolerance, you should immediately consult a doctor.
<G-vec00057-001-s067><consult.aufsuchen><de> In jedem Fall, um eine genaue Diagnose zu stellen, sollten Sie sofort einen Arzt aufsuchen.
<G-vec00057-001-s067><consult.aufsuchen><en> In any case, to establish an accurate diagnosis, you should immediately consult a doctor.
<G-vec00057-001-s068><consult.aufsuchen><de> Erst im Juli 1940 konnte ich wieder einen Augenarzt in Eger aufsuchen, der mir erklärte, es sei nichts mehr zu machen.
<G-vec00057-001-s068><consult.aufsuchen><en> It was not until July 1940 that I was again able to consult an ophthalmologist in Eger, who told me that there was nothing left to be done for me.
<G-vec00057-001-s069><consult.aufsuchen><de> Bei anhaltenden Symptomen einen Arzt aufsuchen.
<G-vec00057-001-s069><consult.aufsuchen><en> Consult a doctor if symptoms persist.
<G-vec00057-001-s070><consult.aufsuchen><de> Wenn der Schmerz anhält, einen Arzt aufsuchen.
<G-vec00057-001-s070><consult.aufsuchen><en> If pain persists, consult a doctor.
<G-vec00057-001-s071><consult.aufsuchen><de> Im Zweifelsfall oder bei anhaltenden Problemen einen Tierarzt aufsuchen.
<G-vec00057-001-s071><consult.aufsuchen><en> In case of doubt or persistent problems consult a veterinarian.
<G-vec00057-001-s072><consult.aufsuchen><de> In jedem Fall müssen Sie vor der Einnahme eines Medikaments einen Arzt aufsuchen und die Anmerkung lesen.
<G-vec00057-001-s072><consult.aufsuchen><en> In any case, before using any medication, you need to consult a doctor and read the annotation.
<G-vec00057-001-s073><consult.aufsuchen><de> Sollte eine dieser Nebenwirkungen fortbestehen oder sich verschlimmern, sollten Sie Ihren Arzt sofort aufsuchen.
<G-vec00057-001-s073><consult.aufsuchen><en> Should any of these side effects persist or worsen, you should consult your physician immediately.
<G-vec00057-001-s074><consult.aufsuchen><de> Daher dringend einen Arzt aufsuchen, um keine ernsteren Konsequenzen zu provozieren.
<G-vec00057-001-s074><consult.aufsuchen><en> Therefore, urgently consult a doctor in order not to provoke more serious consequences.
<G-vec00057-001-s075><consult.aufsuchen><de> Denken Sie daran: Je früher Sie einen Arzt aufsuchen mit einem Nabelbruch, desto leichter behandelt werden.
<G-vec00057-001-s075><consult.aufsuchen><en> Remember: the earlier you consult a doctor with an umbilical hernia,the easier it will be treated.
<G-vec00057-001-s076><consult.aufsuchen><de> Bei anhaltender Augenreizung einen Facharzt aufsuchen.
<G-vec00057-001-s076><consult.aufsuchen><en> If eye irritation persists, consult a specialist.
<G-vec00057-001-s077><consult.aufsuchen><de> Wenn einer dieser Fälle passieren dann sollte man den Lauf abbrechen und einen Arzt sofort aufsuchen.
<G-vec00057-001-s077><consult.aufsuchen><en> If any of these happen then one should discontinue the course and consult a medical professional immediately.
<G-vec00057-001-s078><consult.aufsuchen><de> Wenn dies nicht der Fall ist, sollten Sie unbedingt einen Arzt aufsuchen.
<G-vec00057-001-s078><consult.aufsuchen><en> If this does not happen, you should definitely consult a doctor.
<G-vec00057-001-s079><consult.aufsuchen><de> Aber Sie sollten zuerst einen Arzt aufsuchen.
<G-vec00057-001-s079><consult.aufsuchen><en> But you should first consult a doctor.
<G-vec00057-001-s080><consult.aufsuchen><de> Dieses Medikament kann mit anderen Medikamenten kombiniert werden, aber vorher sollten Sie einen Arzt aufsuchen, der sie ernannt hat.
<G-vec00057-001-s080><consult.aufsuchen><en> This medication can be combined with other medications, but before that you should consult a doctor who appointed them.
<G-vec00057-001-s081><consult.aufsuchen><de> Crusting Patienten, die Nebenwirkungen bemerken, wenn diese Creme verwenden, sollten ihren Arzt sofort aufsuchen.
<G-vec00057-001-s081><consult.aufsuchen><en> Burning sensation Crusting Patients who notice side effects when using this cream should consult their physician immediately.
<G-vec00057-001-s082><consult.aufsuchen><de> Wenn Sie Gewichtsverlust Pillen oder Operationen benutzen wollen, sollten Sie Ihren Arzt aufsuchen, und untersuchen die potenziellen Risiken.
<G-vec00057-001-s082><consult.aufsuchen><en> If you decide to use weight-loss pills or surgery, you should consult your doctor, and investigate the potential risks.
<G-vec00057-001-s083><consult.aufsuchen><de> Treten unter Carnosin Beschwerden auf, sollten Sie einen Arzt aufsuchen und ihn über die Einnahme informieren.
<G-vec00057-001-s083><consult.aufsuchen><en> If you experience any symptoms while taking carnosine you should consult a doctor and inform him / her of the intake.
<G-vec00272-001-s075><seek.aufsuchen><de> Sondern ihr sollt die Stätte aufsuchen, die der HERR, euer Gott, aus all euren Stämmen erwählen wird, um seinen Namen dort niederzulegen, daß er [dort] wohne, und dahin sollst du kommen.
<G-vec00272-001-s075><seek.aufsuchen><en> ¶ But to the place which the LORD your God shall choose out of all your tribes to put his name there, his habitation shall you seek, and thither you shall go;
<G-vec00272-001-s076><seek.aufsuchen><de> Bewohner in Küstengebieten sollten hohes Land aufsuchen, in den Bergen in Reichweite vor dem Polsprung.
<G-vec00272-001-s076><seek.aufsuchen><en> Residents in coastal areas should seek high land, in the mountains within reach, prior to the shift.
<G-vec00272-001-s077><seek.aufsuchen><de> Wenn Sie eine der Fragen mit JA beantworten, müssen Sie einen Arzt spezialisiert auf Tauchmedizin aufsuchen, um eine professionelle ärztliche Unbedenklichkeitsbescheinigung zum Tauchen zu bekommen.
<G-vec00272-001-s077><seek.aufsuchen><en> If you answer YES to any of the questions, you must seek the expert advice of a doctor specialising in dive medicine to obtain professional medical clearance to dive.
<G-vec00272-001-s078><seek.aufsuchen><de> Wenn beispielsweise Großeltern mit ihren Enkeln gemeinsam einen Geräteparcours aufsuchen, dann beschränkt sich die Tätigkeit der Erwachsenen zumeist auf die Unterstützung der Kinder und auf das Vorzeigen der intendierten Nutzungsart.
<G-vec00272-001-s078><seek.aufsuchen><en> If, for example, grandparents seek out a fitness trail together with their grandchildren, then the activity of the adults is mostly limited to supporting the children and showing them how to use it.
<G-vec00272-001-s079><seek.aufsuchen><de> Sondern ihr sollt die Stätte aufsuchen, die der HERR, euer Gott, aus all euren Stämmen erwählen wird, um seinen Namen dort niederzulegen, daß er [dort] wohne, und dahin sollst du kommen.
<G-vec00272-001-s079><seek.aufsuchen><en> But to the place which Yahweh your God shall choose out of all your tribes, to put his name there, even to his habitation you shall seek, and there you shall come;
<G-vec00272-001-s080><seek.aufsuchen><de> 12:5 sondern den Ort sollt ihr aufsuchen, welchen Jehova, euer Gott, aus allen euren Stämmen erwählen wird, um seinen Namen dahin zu setzen, daß er dort wohne, und dahin sollst du kommen.
<G-vec00272-001-s080><seek.aufsuchen><en> 12:5 but unto the place which Jehovah your God will choose out of all your tribes to set his name there, his habitation shall ye seek, and thither thou shalt come;
<G-vec00272-001-s081><seek.aufsuchen><de> Ich sage euch, Jünger: Wenn die Menschen darangehen, mein Werk zu studieren, und sie euch aufsuchen und befragen, so geratet nicht in Versuchung, indem ihr euch wegen des Wissens, das ihr von Mir empfangen habt, für überlegen haltet.
<G-vec00272-001-s081><seek.aufsuchen><en> I tell you, disciples: when men arise to study My Work, and seek you out and question you, do not fall into the temptation of believing yourselves superior due to the knowledge you have received from Me.
<G-vec00272-001-s082><seek.aufsuchen><de> Es gibt auch Betroffene, die wissen, dass sie schwerhörig sind, die aber keine Behandlung aufsuchen.
<G-vec00272-001-s082><seek.aufsuchen><en> Still others know that they have a hearing loss, but for some reason do not seek treatment.
<G-vec00272-001-s083><seek.aufsuchen><de> Die Ursachen eines verunglückten Feldzuges aufsuchen, heißt noch nicht, eine Kritik desselben machen; nur wenn man beweist, daß diese Ursachen nicht hätten übersehen oder unbeachtet bleiben sollen, macht man die Kritik und erhebt sich über den Feldherrn.
<G-vec00272-001-s083><seek.aufsuchen><en> To seek out the causes of the failure of a campaign, is not going the length of making a criticism upon it; it is only if we show that these causes should neither have been overlooked nor disregarded that we make a criticism and place ourselves above the General.
<G-vec00272-001-s084><seek.aufsuchen><de> In einigen Ländern ist die Behandlung vielleicht nicht zufriedenstellend, sodass die Menschen keine Hilfe aufsuchen, wie sie es beispielsweise im Falle einer körperlichen Erkrankung tun würden.
<G-vec00272-001-s084><seek.aufsuchen><en> In some countries the treatment can be unsatisfactory, and people do not make any effort to seek help, as they would do in case of a physical disease.
<G-vec00272-001-s085><seek.aufsuchen><de> Die beiden ersten veranlassen das Aufsuchen kultivierter Landstriche und großer Städte und Straßen.
<G-vec00272-001-s085><seek.aufsuchen><en> The first two lead us to seek out cultivated districts, and great towns and roads.
<G-vec00272-001-s086><seek.aufsuchen><de> Susan Hefunas Photographien, Skulpturen, und Zeichnungen verleihen dieser mentalen Struktur sichtbaren Ausdruck: Die Muster, Raster und Gitter, die wir konstruieren, um uns in der inneren und äußeren Welten zurechtzufinden, die Räume, die wir aufsuchen und die Orte, die wir herrichten, um anderen und uns selbst zu begegnen.
<G-vec00272-001-s086><seek.aufsuchen><en> Susan Hefuna's photographs, sculptures and drawings offer a physical analogue to this mental structure: an experience of the patterns and grids we construct to navigate our inner and outer worlds, of the spaces we seek and the places we make to be able to face others, and ourselves.
<G-vec00272-001-s087><seek.aufsuchen><de> Dt 12:5 - sondern den Ort sollt ihr aufsuchen, welchen Jehova, euer Gott, aus allen euren Stämmen erwählen wird, um seinen Namen dahin zu setzen, daß er dort wohne, und dahin sollst du kommen.
<G-vec00272-001-s087><seek.aufsuchen><en> Dt 12:5 - But unto the place which the LORD your God shall choose out of all your tribes to put his name there, even unto his habitation shall all of you seek, and thither you shall come:
<G-vec00272-001-s088><seek.aufsuchen><de> Es gibt immer jemanden, der fragt sich, was der Zweck ist, warum so viele Menschen begeistert, die Lautstärke Ihres mp3s erhöhen aufsuchen.
<G-vec00272-001-s088><seek.aufsuchen><en> There is always someone who is wondering what is the purpose why so many people seek eagerly increase the volume of your mp3s.
<G-vec00272-001-s089><seek.aufsuchen><de> "Saul konnte weinen, er konnte Propheten aufsuchen, er konnte um Träume beten -- aber der Herr antwortete: ""Nein, Saul."
<G-vec00272-001-s089><seek.aufsuchen><en> "Saul could weep, he could seek out prophets, he could pray for dreams -- but the Lord answered, ""No, Saul."
<G-vec00272-001-s090><seek.aufsuchen><de> 5 Sondern ihr sollt die Stätte aufsuchen, die der HERR, euer Gott, aus all euren Stämmen erwählen wird, um seinen Namen dort niederzulegen, daß er dort wohne, und dahin sollst du kommen.
<G-vec00272-001-s090><seek.aufsuchen><en> "5 ""But you shall seek the Lord at the place which the LORD your God shall choose from all your tribes, to establish His name there for His dwelling, and there you shall come."
<G-vec00272-001-s091><seek.aufsuchen><de> Du kannst das Märchen-Königreich und die innere Erde aufsuchen.
<G-vec00272-001-s091><seek.aufsuchen><en> You can seek the fairy kingdom and the inner earth.
<G-vec00272-001-s092><seek.aufsuchen><de> Simeon sollte Richard II., Herzog der Normandie, aufsuchen, der sich schon früher als großzügiger Spender erwiesen hatte.
<G-vec00272-001-s092><seek.aufsuchen><en> Simeon was to seek out Richard II, Duke of Normandy, who had proven to be a generous benefactor in the past.
<G-vec00272-001-s093><seek.aufsuchen><de> Weiterhin sollte der Patient in Zukunft beim Auftreten einer schweren Infektionskrankheit den Hausarzt aufsuchen und diesen auf die Tatsache aufmerksam machen, dass er oder sie keine Milz mehr hat.
<G-vec00272-001-s093><seek.aufsuchen><en> In addition, the patient should always seek medical help if he contracts a serious infection, and tell the doctor that he or she no longer has a spleen.
<G-vec00057-001-s084><consult.aufsuchen><de> Reisenden, die westafrikanische Länder besuchen wollen, wird empfohlen, keine erkrankten Personen anzufassen und beim geringsten Zweifel einen Arzt aufzusuchen.
<G-vec00057-001-s084><consult.aufsuchen><en> Travellers wishing to visit West Africa are advised not to touch persons who are ill and to consult a doctor if they have the slightest doubt.
<G-vec00057-001-s085><consult.aufsuchen><de> In jedem Fall wird empfohlen, vor der Einnahme von Body Slim Capsules einen Arzt aufzusuchen.
<G-vec00057-001-s085><consult.aufsuchen><en> In any case, before taking Body Slim Capsules it is recommended to consult a doctor for detailed advice.
<G-vec00057-001-s086><consult.aufsuchen><de> Falls Sie über die zeitlich begrenzten Herausforderungen, von denen die Hathoren hier sprechen, hinausgehende starke Defizite in Ihren kognitiven Fähigkeiten oder Ihrer Gedächtnisleistung erleben, die Ihre Fähigkeit, im Alltag normal zu funktionieren, negativ beeinflussen, dann halte ich es für ratsam, einen Arzt aufzusuchen.
<G-vec00057-001-s086><consult.aufsuchen><en> If you are experiencing dramatic deficits in your cognitive abilities and memory that negatively affect your ability to function normally in your day-to-day life—beyond the temporary challenges that the Hathors are talking about—I would think it wise to consult with a medical professional.
<G-vec00057-001-s087><consult.aufsuchen><de> Patienten wird geraten, sofort einen Arzt aufzusuchen, wenn sie andere schwerwiegende Nebenwirkungen bemerken, wie Schmerzen in der Brust, schweres Sodbrennen, Schmerzen in den Oberschenkeln oder Schmerzen in Hüfte oder Kiefer.
<G-vec00057-001-s087><consult.aufsuchen><en> Patients are advised to consult their physician immediately if they notice other more serious side effects, such as pain in the chest, severe heartburn, pain in the thighs or hip or jaw pain.
<G-vec00057-001-s088><consult.aufsuchen><de> Vor dem Start dieses Medikaments wird empfohlen, einen Arzt aufzusuchen.
<G-vec00057-001-s088><consult.aufsuchen><en> Before starting this medication, it is recommended to consult a doctor.
<G-vec00057-001-s089><consult.aufsuchen><de> Wir empfehlen Ihnen, einen Augenspezialisten aufzusuchen, der Ihnen erklären kann, wie man eine Linse richtig benutzt, und mit Ihnen üben kann.
<G-vec00057-001-s089><consult.aufsuchen><en> We recommend that you consult an eye specialist who can explain how to use a lens properly and practice with you.
<G-vec00057-001-s090><consult.aufsuchen><de> Den Patienten wird empfohlen, sofort einen Arzt aufzusuchen, wenn eine dieser Nebenwirkungen anhält oder sich verschlimmert oder wenn andere schwerwiegendere Nebenwirkungen wie Halluzinationen, ungewöhnliches Verhalten oder Verwirrtheitsgefühle auftreten.
<G-vec00057-001-s090><consult.aufsuchen><en> Patients are advised to consult their physician immediately if any of these side effects persist or worsen, or if other more serious side effects occur such as hallucinations, unusual behavior or feelings of confusion.
<G-vec00057-001-s091><consult.aufsuchen><de> Bei Hautveränderungen, Juckreiz oder Brennen im Genitalbereich wird empfohlen, einen Arzt aufzusuchen.
<G-vec00057-001-s091><consult.aufsuchen><en> In case of skin changes, itching or burning in the genital area, it is recommended to consult a doctor.
<G-vec00057-001-s092><consult.aufsuchen><de> Sie verpflichten sich, bei Krankheit erst einen festen Hausarzt aufzusuchen.
<G-vec00057-001-s092><consult.aufsuchen><en> You agree to first consult a fixed family doctor in the event of illness.
<G-vec00057-001-s093><consult.aufsuchen><de> In jedem Fall ist erhöhter Unterdruck ein Grund, einen Arzt aufzusuchen.
<G-vec00057-001-s093><consult.aufsuchen><en> In any case, increased lower pressure is a reason to consult a doctor.
<G-vec00057-001-s094><consult.aufsuchen><de> Hoher Druck und hohe Temperatur bei einem Erwachsenen werden selten gleichzeitig beobachtet, jedoch ist es im Fall einer Kombination dieser Symptome notwendig, sofort einen Arzt aufzusuchen.
<G-vec00057-001-s094><consult.aufsuchen><en> High pressure and high temperature in an adult are rarely observed at the same time, however, in case of a combination of these symptoms, it is necessary to immediately consult a doctor.
<G-vec00057-001-s095><consult.aufsuchen><de> Als Gustav Mahlers Ehe 1910 nach Almas Begegnung mit Walter Gropius in eine schwere Krise stürzte, wurde ihm empfohlen, Sigmund Freud aufzusuchen, der sich auch bereit erklärte, ihn im niederländischen Kurbad Leyden zu empfangen.
<G-vec00057-001-s095><consult.aufsuchen><en> When, in 1910, following Alma´s encounter with Walter Gropius, Gustav Mahler´s marriage fell into severe crisis, he was recommended to consult Sigmund Freud, who declared himself willing to meet with him in the Dutch spa resort of Leiden.
<G-vec00057-001-s096><consult.aufsuchen><de> All diese Symptome - ein Grund, einen Arzt aufzusuchen.
<G-vec00057-001-s096><consult.aufsuchen><en> All these symptoms - an occasion to consult a doctor.
<G-vec00272-001-s094><seek.aufsuchen><de> Eine Möglichkeit diese Haltung aufzubrechen ist, ungewöhnliche Spielorte aufzusuchen, eine andere, Themen aus der regionalen Geschichte aufzugreifen und in zeitgemäße theatralische Formen zu setzen.
<G-vec00272-001-s094><seek.aufsuchen><en> One possibility of changing this attitude is to seek out unusual locations for productions, and another is to utilize themes from the regional history by setting them in contemporary theatrical forms.
<G-vec00272-001-s095><seek.aufsuchen><de> Weil er in der Selbstanschauung das Ideelle in unmittelbarer Gestalt sieht, gewinnt er die Kraft und Fähigkeit, dieses Ideelle auch in aller äußeren Erscheinung, in der ganzen Natur aufzusuchen und anzuerkennen.
<G-vec00272-001-s095><seek.aufsuchen><en> Because in self-perception he sees what is ideal in its direct form, he gains the strength and ability to seek out and recognize this ideal element also in all outer phenomena, in the whole of nature.
<G-vec00272-001-s096><seek.aufsuchen><de> Seine 'Referenzen' zu besuchen oder die Orte aufzusuchen, an denen er diese Form der Betrachtung entwickelt hat, war für mich sehr interessant, aber es bedeutete auch irgendwie, den Weg anderes herum zu beschreiten.
<G-vec00272-001-s096><seek.aufsuchen><en> It was very interesting for me to visit his 'references' or seek out the places where he developed this form of observation, but somehow it also meant treading the path the other way around.
<G-vec00272-001-s097><seek.aufsuchen><de> Wenn der veränderte Zustand allerdings länger als wenige Tage andauert, kann es empfehlenswert sein, einen Psychiater aufzusuchen, da dies auf das Vorliegen einer bestehenden Erkrankung hinweisen kann.
<G-vec00272-001-s097><seek.aufsuchen><en> If your altered state continues to persist beyond a few days, it may be advantageous to seek psychiatric help, as it may point to the existence of an underlying condition.
<G-vec00272-001-s098><seek.aufsuchen><de> Schwindende Fischbestände als Folge jahrzehntelanger Überfischung zwingen selbständige Fischer heute dazu, in neue Fischereimethoden zu investieren oder neue Fischgründe aufzusuchen.
<G-vec00272-001-s098><seek.aufsuchen><en> Dwindling fish stocks as a result of decades of overfishing often force independent fishing communities to invest in new fishing methods or to seek new fishing ground.
<G-vec00272-001-s099><seek.aufsuchen><de> 11:25 Barnabas aber zog nach Tarsus, um Saulus aufzusuchen.
<G-vec00272-001-s099><seek.aufsuchen><en> 11:25 Then departed Barnabas to Tarsus, for to seek Saul:
<G-vec00272-001-s100><seek.aufsuchen><de> Viele derartige Probleme werden aber gar nicht aufgedeckt und alte Menschen zögern oft, Hilfseinrichtungen aufzusuchen.
<G-vec00272-001-s100><seek.aufsuchen><en> Many such problems go undetected, and older people are often reluctant to seek help.
<G-vec00272-001-s101><seek.aufsuchen><de> Goethe wird durch die Empfindung, daß «die hohen Kunstwerke von Menschen nach wahren und natürlichen Gesetzen hervorgebracht» sind, fortwährend angeregt, diese wahren und natürlichen Gesetze des künstlerischen Schaffens aufzusuchen.
<G-vec00272-001-s101><seek.aufsuchen><en> "The feeling that ""men's great works of art are brought forth according to true and natural laws"" continuously moved Goethe to seek out these true and natural laws of artistic creation."
<G-vec00272-001-s102><seek.aufsuchen><de> Sie sollte Patienten, die auf Chemikalien und Gerüche mit hyperreaktiven Atemwegsbeschwerden reagieren und deswegen vom Allergologen einen Hinweis auf das mögliche Vorliegen einer psychischer Erkrankung erhielten, den Impuls geben, sich damit nicht zufrieden zu geben und vielleicht zusätzlich einen erfahrenen Umweltmediziner aufzusuchen.
<G-vec00272-001-s102><seek.aufsuchen><en> Those patients who respond to chemicals and odors with hyperreactive respiratory symptoms should perhaps seek an experienced environmental medicine professional if their allergist makes a reference to the possibility of a mental illness.
<G-vec00272-001-s103><seek.aufsuchen><de> Abdullah Ateeq Sohn und fünf anderen Muslimen ging zum Propheten (salla Allahu alihi wa salam) und fragte, ob es erlaubt war für sie, ihn aufzusuchen und zu töten ihn wegen des enormen Schaden, den er verursacht hatte.
<G-vec00272-001-s103><seek.aufsuchen><en> Abdullah Ateeq’s son and five other Muslims went to the Prophet (salla Allahu alihi wa sallam) and asked if it was permitted for them to seek him out and kill him on account of the tremendous harm he had caused.
<G-vec00272-001-s104><seek.aufsuchen><de> Seine ‚Referenzen’ zu besuchen oder die Orte aufzusuchen, an denen er diese Form der Betrachtung entwickelt hat, war für mich sehr interessant, aber es bedeutete auch irgendwie, den Weg anderes herum zu beschreiten.
<G-vec00272-001-s104><seek.aufsuchen><en> It was very interesting for me to visit his ‘references’ or seek out the places where he developed this form of observation, but somehow it also meant treading the path the other way around.
<G-vec00272-001-s105><seek.aufsuchen><de> Nichtsdestoweniger zögern sie nicht unsere technische Unterstützung aufzusuchen, falls sie irgendwelche Probleme haben oder Fragen beim Anschauen von Rybka-Aquarium.
<G-vec00272-001-s105><seek.aufsuchen><en> Nevertheless, don't hesitate to seek technical support in case you have any problems or questions regarding Rybka Aquarium.
<G-vec00272-001-s106><seek.aufsuchen><de> Die Mücken hatten Gesternabend eine Festmahlzeit, es bleibt uns nichts anderes übrig als die nächste Apotheke aufzusuchen um einen anästhesierenden Stift zu kaufen.
<G-vec00272-001-s106><seek.aufsuchen><en> The mosquitoes had a fixed meal last night, we are left with no choice but to seek the nearest Pharmacy to buy an anesthetic pin
<G-vec00272-001-s107><seek.aufsuchen><de> Fehlende Parkmöglichkeiten sowie terminliche und organisatorische Probleme machen es für Berufskraftfahrer äußerst schwierig, unterwegs einen Arzt aufzusuchen.
<G-vec00272-001-s107><seek.aufsuchen><en> A lack of parking opportunities as well as scheduling and organizational difficulties can make it very difficult for professional drivers to seek out a doctor when on the road.
<G-vec00272-001-s108><seek.aufsuchen><de> Und dieser Prozess wird sich nur dann vollziehen, wenn Menschen wie du und ich bereit sind, das Projekt zu lieben und uns nicht um das Durcheinander in der Dienststelle zu kümmern; wenn wir großzügig sind und den Kontaktpersonen Zeit geben, all ihren Mut zusammenzunehmen, uns aufzusuchen und uns als Mitarbeiter anzusprechen.
<G-vec00272-001-s108><seek.aufsuchen><en> And it will only happen if people like you and me are prepared to love the project and not mind the turmoil in the agency, if we are generous in giving the handlers time to summon up the bravery to seek us out and talk to us as co-workers.
<G-vec00272-001-s109><seek.aufsuchen><de> Sie bei sich selber aufzusuchen, auf ihrem eigenen Gelände, um sich mit ihnen zu schlagen, scheint mir...
<G-vec00272-001-s109><seek.aufsuchen><en> To go and seek them out in their own place, on their own ground, and fight them seems to me...
<G-vec00272-001-s110><seek.aufsuchen><de> Es lohnt sich den Touristenhotspot Amalfi zu verlassen und die höher und abseitsgelegenen Orte aufzusuchen.
<G-vec00272-001-s110><seek.aufsuchen><en> It is worth leaving the tourist hotspot Amalfi and seek the higher and outlying villages.
<G-vec00272-001-s111><seek.aufsuchen><de> Zusätzlich wird die geschwollene Haut macht es schwieriger für die Stoppeln wieder aufzusuchen seine Weise.
<G-vec00272-001-s111><seek.aufsuchen><en> Additionally the swollen skin makes it harder for the stubble to seek out its manner again out.
<G-vec00272-001-s112><seek.aufsuchen><de> Tief in der Welt Urwälder und verbotene Ödland erwarten furchterregende Kreaturen der Mythen und Legenden, die verrückt genug, um sie aufzusuchen.
<G-vec00272-001-s112><seek.aufsuchen><en> Deep in the world’s jungles and forbidden wastelands, terrifying creatures of myth and legend await those insane enough to seek them out.
