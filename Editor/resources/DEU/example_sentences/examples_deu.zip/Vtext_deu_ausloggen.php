<G-vec00507-002-s076><log.ausloggen><de> Falls mehrere Personen die App auf dem selben Gerät nutzen ist auch die Funktion zum ausloggen des Accounts wichtig.
<G-vec00507-002-s076><log.ausloggen><en> If more than one person uses the Tipico app on the same device you have to be able to log out of one’s account as well.
<G-vec00507-002-s077><log.ausloggen><de> Wenn Ihr die Zuordnung mit Eurem Profil bei Google nicht wünscht, müsst Ihr Euch vor Aktivierung des Buttons ausloggen.
<G-vec00507-002-s077><log.ausloggen><en> We recommend that you regularly log out after using a social network, in particular before activating the button, since this prevents assignment to your profile with the plug-in provider.
<G-vec00507-002-s078><log.ausloggen><de> Ausloggen Menü Buchen Sie Ihre Anfahrt zum Flughafen im Voraus.
<G-vec00507-002-s078><log.ausloggen><en> Log out Menu Pre-book your travel to the airport.
<G-vec00507-002-s079><log.ausloggen><de> Wenn Sie die Zuordnung mit Ihrem Profil bei Google und/oder YouTube nicht wünschen, müssen Sie sich vor Aktivierung ausloggen.
<G-vec00507-002-s079><log.ausloggen><en> If you are mapping with your profile on Google and / or YouTube does not need to log out before activation.
<G-vec00507-002-s080><log.ausloggen><de> Wenn Sie Mitglied in diesen sozialen Netzwerken sind und nicht möchten, dass bei Ihrem Besuch meiner Homepage von Facebook, Twitter oder XING Daten über Sie gesammelt und mit Ihren gespeicherten Profilen verknüpft werden, müssen Sie sich vor Ihrem Besuch meiner Website bei Facebook, Twitter und XING ausloggen.
<G-vec00507-002-s080><log.ausloggen><en> If you are member in these social networks and did not like the fact that with your attendance of my homepage von Facebook, Twitter or XING data are collected over you and linked with your stored profiles must you itself before your attendance of my Website with Facebook, Twitter and XING out-log.
<G-vec00507-002-s081><log.ausloggen><de> Hierzu muss der Nutzer sich über die Website XING ausloggen.
<G-vec00507-002-s081><log.ausloggen><en> To prevent this, the user must log out via the XING website.
<G-vec00507-002-s082><log.ausloggen><de> Bitte beachten Sie auch, dass ein fehlerhaftes Skript das Ausloggen aus SiteKiosk unmöglich machen kann.
<G-vec00507-002-s082><log.ausloggen><en> Please note that a defective script can make it impossible for users to log out of SiteKiosk.
<G-vec00507-002-s083><log.ausloggen><de> Daraufhin erscheint eine Auswahlliste, in der Sie auf Ausloggen klicken.
<G-vec00507-002-s083><log.ausloggen><en> A drop-down menu will appear where you will find the Log out button.
<G-vec00507-002-s084><log.ausloggen><de> Wenn Sie nicht möchten, dass Facebook Daten über Ihren Besuch auf unserer Website speichert, sollten Sie sich bei Facebook ausloggen und dann die Cookies in dem zu verwenden Browser löschen.
<G-vec00507-002-s084><log.ausloggen><en> If you do not want that Facebook stores any data on your visit of our website, you should log out with Facebook and then delete the cookies in the browser to be used.
<G-vec00507-002-s085><log.ausloggen><de> Wenn Sie ein Geschäftskonto haben, klicken Sie auf das Symbol "Mein Profil" und wählen Sie im Dropdown-Menü den Punkt "Auf allen Geräten ausloggen".
<G-vec00507-002-s085><log.ausloggen><en> Business account users can deactivate by clicking the Profile icon and selecting “Log out of all devices” from the drop down menu.
<G-vec00507-002-s086><log.ausloggen><de> Um eine Zuordnung zu Ihrem Youtube-Nutzerkonto zu verhindern, müssen Sie sich bei YouTube ausloggen.
<G-vec00507-002-s086><log.ausloggen><en> To prevent assignment to your YouTube user account, you must first log out of YouTube.
<G-vec00507-002-s087><log.ausloggen><de> Wenn die Zuordnung zum Nutzerkonto nicht gewünscht ist, muss der Nutzer sich vor Aktivierung des Abspiel-Buttons für das Video ausloggen.
<G-vec00507-002-s087><log.ausloggen><en> If association with the user account is not desired, the user must log out before clicking on the PLAY button for the video.
<G-vec00507-002-s088><log.ausloggen><de> Die Wirkung wird beim Ausloggen aufgehoben.
<G-vec00507-002-s088><log.ausloggen><en> The effect will expire when you log out.
<G-vec00507-002-s089><log.ausloggen><de> Hierzu muss der Nutzer sich über die Website Twitter ausloggen.
<G-vec00507-002-s089><log.ausloggen><en> To do this, the user must log out via the Twitter website.
<G-vec00507-002-s090><log.ausloggen><de> Wenn ein Nutzer Facebookmitglied ist und nicht möchte, dass Facebook über dieses Onlineangebot Daten über ihn sammelt und mit seinen bei Facebook gespeicherten Mitgliedsdaten verknüpft, muss er sich vor der Nutzung unseres Onlineangebotes bei Facebook ausloggen und seine Cookies löschen.
<G-vec00507-002-s090><log.ausloggen><en> If a user is on Facebook and does not want Facebook to collect data on him/her via this online presence and link them with his/her account data stored by Facebook, he/she must log out of Facebook and clear his/her cookies before using our online presence.
<G-vec00507-002-s091><log.ausloggen><de> Wenn ein Nutzer Facebookmitglied ist und nicht möchte, dass Facebook über dieses Angebot Daten über ihn sammelt und mit seinen bei Facebook gespeicherten Mitgliedsdaten verknüpft, muss er sich vor dem Besuch des Internetauftritts bei Facebook ausloggen.
<G-vec00507-002-s091><log.ausloggen><en> If you are a Facebook member and do not want Facebook about this website collects information about you and linked to your member data already stored by Facebook, please log off before you visit this website on Facebook.
<G-vec00507-002-s092><log.ausloggen><de> Wenn ein Nutzer Facebookmitglied ist und nicht möchte, dass Facebook über Justlo.de Daten über ihn sammelt und mit seinen bei Facebook gespeicherten Mitgliedsdaten verknüpft, muss er sich vor dem Besuch des Internetauftritts bei Facebook ausloggen.
<G-vec00507-002-s092><log.ausloggen><en> If you are a Facebook member and do not want Facebook to connect the data concerning your visit to our website with your member data already stored by Facebook, please log off Facebook before entering our website and delete your cookies.
<G-vec00507-002-s093><log.ausloggen><de> Wenn du ein neues Spiel beginnen möchtest, ohne es neu zu installieren, gehe bitte zum Menü und tippe neben dem Facebook-Symbol "Ausloggen" an.
<G-vec00507-002-s093><log.ausloggen><en> If you want to start a new game without reinstalling it, please go to the Menu and tap “Log out” next to the Facebook icon.
<G-vec00507-002-s094><log.ausloggen><de> Tippe auf Ausloggen.
<G-vec00507-002-s094><log.ausloggen><en> Tap Log out.
