<G-vec00365-003-s028><wipe_out.abreiben><de> Den pH-Sensor nach jeder Messung mit VE-Wasser spülen, aber keinesfalls mit einem Papiertuch abreiben.
<G-vec00365-003-s028><wipe_out.abreiben><en> To clean the probe, rinse it with deionized water after each measurement but never wipe it with a tissue.
<G-vec00365-003-s029><wipe_out.abreiben><de> Einige Minuten einziehen lassen sowie anschließend mit einem sauberen Tuch die überschüssige Ledermilch abreiben oder bei Bedarf nachpolieren.
<G-vec00365-003-s029><wipe_out.abreiben><en> Leave to absorb for a few minutes and then wipe off the excess Leather Milk with a clean cloth or polish it if necessary.
<G-vec00365-003-s030><wipe_out.abreiben><de> Du kannst einen Lappen mit warmen Wasser anfeuchten und deinen Kissenbezug damit abreiben.
<G-vec00365-003-s030><wipe_out.abreiben><en> You can wet a cleaning rag with warm water and add a cap of dish detergent to it, then wipe your cushion clean.
<G-vec00365-003-s031><wipe_out.abreiben><de> Lauwarmes Wasser mit etwas Feinwaschmittel mit einem weißen Tuch auftragen und den Fleck abreiben.
<G-vec00365-003-s031><wipe_out.abreiben><en> Soak a soft cloth in a mild detergent and in lukewarm water and wipe the stain.
<G-vec00365-003-s032><wipe_out.abreiben><de> Bronzepolitur – einfach nur ein wenig Öl auf ein Baumwolltuch geben und damit die Bronze abreiben.
<G-vec00365-003-s032><wipe_out.abreiben><en> Polishing Bronze – all you have to do is rub a little oil into a cotton towel and then wipe down the statue.
<G-vec00365-003-s033><wipe_out.abreiben><de> Nach 60 bis 80 Sekunden die Oberfläche abreiben, bis sie makellos und streifenfrei ist.
<G-vec00365-003-s033><wipe_out.abreiben><en> After 60 to 80 seconds wipe the surface well until it is spotless and streak-free.
