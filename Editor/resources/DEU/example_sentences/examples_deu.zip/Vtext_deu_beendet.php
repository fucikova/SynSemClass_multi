<G-vec00081-001-s137><cease.beendet><de> Daher werden Stabilisierungsmaßnahmen nicht notwendigerweise ergriffen und können jeder Zeit beendet werden.
<G-vec00081-001-s137><cease.beendet><en> Therefore, stabilization may not necessarily occur and may cease at any time.
<G-vec00081-001-s138><cease.beendet><de> Die Kriegsrhetorik muss beendet werden.
<G-vec00081-001-s138><cease.beendet><en> The bellicose rhetoric must cease.
<G-vec00081-001-s139><cease.beendet><de> Das Projekt „Vorsichtige Rehabilitierung und wirtschaftliche Wiederbelebung der historischen Stadtviertel in Timiºoara“ wird zum 30.06.2009 beendet.
<G-vec00081-001-s139><cease.beendet><en> The project “The Judicious Rehabilitation and the Economic Revitalization of the Historical Districts of Timisoara” shall cease on the 30th of June 2009.
<G-vec00081-001-s140><cease.beendet><de> Die Gewalt muss sofort beendet werden.
<G-vec00081-001-s140><cease.beendet><en> The violence must cease immediately.
<G-vec00081-001-s141><cease.beendet><de> Der Präsident der Rußländischen Föderation beendet die Ausübung seiner Amtsbefugnisse vorzeitig im Fall seines Rücktritts, im Fall, daß er die ihm zukommenden Befugnisse aus Gesundheitsgründen nicht wahrnehmen kann, oder durch Amtsenthebung.
<G-vec00081-001-s141><cease.beendet><en> The President of the Russian Federation shall cease to exercise his powers short of the term in case of his resignation, stable inability because of health reasons to exercise the powers vested in him or in case of impeachment.
<G-vec00081-001-s142><cease.beendet><de> Von der Beendigung von Geburt, sodann Alter und Tod, Kummer, Klage, Schmerz, Bedrängnis und Verzweiflung, alles beendet.
<G-vec00081-001-s142><cease.beendet><en> From the cessation of birth, then old age & death, sorrow, lamentation, pain, distress, & despair all cease.
<G-vec00081-001-s143><cease.beendet><de> Wenn Sie ein Pad anschla-gen, wird der Klang der vorherigen Pads beendet, so dass nur das neue Pad wiedergegeben wird.
<G-vec00081-001-s143><cease.beendet><en> When you hit a pad, the sound of the immediately preceding pad will cease and only the sound of the new pad is heard.
<G-vec00081-001-s144><cease.beendet><de> Die Rolle, die sie auf der Weltbühne spielen, muss beendet werden.
<G-vec00081-001-s144><cease.beendet><en> The role that they play on the world stage must cease.
