<G-vec00060-001-s019><convey.bringen><de> Die im OTCQX-Markt notierten Unternehmen zeichnen sich durch die Integrität ihrer Betriebsführung und durch die Sorgfalt, mit der sie ihre Qualifikationen zum Ausdruck bringen, aus.
<G-vec00060-001-s019><convey.bringen><en> The companies found on OTCQX are distinguished by the integrity of their operations and diligence with which they convey their qualifications.
<G-vec00060-001-s020><convey.bringen><de> Mit der Public Domain Mark können Sie ein Werk markieren, für das keine bekannten urheberrechtlichen Beschränkungen bestehen, und diesen Status deutlich zum Ausdruck bringen.
<G-vec00060-001-s020><convey.bringen><en> Using the Public Domain Mark, you can mark a work that is free of known copyright restrictions and clearly convey that status.
<G-vec00060-001-s021><convey.bringen><de> Auch die Fotografien, im klassischen Sinn Porträts, sind der Versuch, die Persönlichkeit der Betreffenden einzufangen, zum Ausdruck zu bringen.
<G-vec00060-001-s021><convey.bringen><en> Meanwhile, the photographs, true portraits in the classical sense, are an attempt to capture and convey the personalities of their subjects.
<G-vec00060-001-s022><convey.bringen><de> Haustiere möchten immer gefallen, deshalb müssen sie davon überzeugt sein, was ihre Familie ihnen zum Ausdruck zu bringen versucht.
<G-vec00060-001-s022><convey.bringen><en> Pets always want to please, therefore they must be confident in what their family is trying to convey.
<G-vec00060-001-s023><convey.bringen><de> Es ist ein außergewöhnlich kostengünstiges Produktionspaket für DVD- oder Blu-ray-Inhalte, das flexibel genug ist, um Ihre kreativen Ideen zum Ausdruck zu bringen und die Anforderungen Ihrer Kunden zu erfüllen.
<G-vec00060-001-s023><convey.bringen><en> The DVD or blu-ray software bundle is extremely cost efficient to convey your creative ideas to fulfil customer requirements.
<G-vec00060-001-s024><convey.bringen><de> Dafür gibt es eine zweifache Weise der Erwartung: in der Freude den Herrn erwarten, der da kommt, uns zu erlösen, wie es die eindringlichen Bilder des Gesangs und des Blühens der Steppe zum Ausdruck bringen (V. 1-4).
<G-vec00060-001-s024><convey.bringen><en> For this reason we find a twofold way of waiting: the joyful waiting for the Lord who is coming to save us, as the incessant images of singing and blooming of the wasteland convey to us (v. 1-4).
<G-vec00060-001-s025><convey.bringen><de> """Wir gehen ganz bewusst einen anderen Weg und möchten mit unseren Bildern zum Ausdruck bringen, wofür die Marke steht, für Kraft, Energie und den ""magic moment"", den wir mit unseren Produkterlebnissen in Verbindung bringen"", so Dr. Sandra Wolf, Geschäftsführerin von Riese & Müller."
<G-vec00060-001-s025><convey.bringen><en> “We are consciously moving in a different direction and would like our images to convey what the brand represents – power, energy and the “magic moments” that we endeavour to combine with our product experiences,” comments Dr. Sandra Wolf, CEO of Riese & Müller.
<G-vec00060-001-s026><convey.bringen><de> Im Namen der Präsidentschaft der Europäischen Union und in meinem eigenen Namen möchte ich mein tiefes Beileid seiner Familie, den provisorischen Selbstverwaltungsstrukturen des Kosovo und den Menschen des Kosovo zum Ausdruck bringen.
<G-vec00060-001-s026><convey.bringen><en> In the name of the Presidency of the European Union and in my own name I would like to convey my condolences to his family, to the Provisional Institutions of Self-Government of Kosovo and to the entire population of Kosovo.
<G-vec00060-001-s027><convey.bringen><de> Bunt und fröhlich gibt sich das Logo, soll es doch zum Ausdruck bringen was beim Fußball gefühlt wird: Freue, Emotionen, Heiterkeit.
<G-vec00060-001-s027><convey.bringen><en> It seems colourful and cheerful, because it's supposed to convey what football is all about: fun, emotions and happiness.
<G-vec00060-001-s028><convey.bringen><de> Der pakistanische Botschafter wurde heute in das Auswärtige Amt einbestellt, um ihm die tiefe Besorgnis der Bundesregierung angesichts der jüngsten Hinrichtungen in Pakistan zum Ausdruck zu bringen.
<G-vec00060-001-s028><convey.bringen><en> Today Pakistan’s Ambassador was summoned to the Federal Foreign Office in order to convey to him the German Government’s is deep concern about the latest executions carried out in Pakistan.
<G-vec00169-001-s023><capitalize.bringen><de> Montalvo revolutionierte die Tänzerregelung, als wir den einzigen Regler auf den Markt brachten, der die Vorteile von sowohl Kraftmessdosen als auch Tänzern ausnutzen konnte.
<G-vec00169-001-s023><capitalize.bringen><en> Montalvo pioneered dancer tension control when we introduced the only controller on the market to capitalize on the benefits of both load cells and dancers within one highquality tension controller.
<G-vec00442-001-s095><bear.bringen><de> “Diese Kooperation wird für beide Seiten einen Gewinn bringen.
<G-vec00442-001-s095><bear.bringen><en> “Our cooperation will bear fruit for both parties.
<G-vec00442-001-s096><bear.bringen><de> Will man jene Worte Christi und Petri sinnbildlich nehmen, so sind sie doch nicht auf Das, was meine Gegner sagen, zu beziehen, sondern auf die Bedeutung jenes Schwertes, von welchem Matthäus schreibt: Glaubet nicht, daß ich in die Welt gekommen bin, den Frieden zu bringen: nicht bin ich gekommen, den Frieden zu bringen, sondern das Schwert.
<G-vec00442-001-s096><bear.bringen><en> "For if those words of Christ and Peter are to be understood figuratively, they are not to be made to bear the meaning those people claim, but they are to be related to the meaning of that sword of which Matthew writes in this way: ""Think not that I am come to send peace on earth: I came not to send peace, but a sword."
<G-vec00442-001-s097><bear.bringen><de> Die »Salus Populi Romani« ist die Mutter, die uns das Wohlergehen im Wachstum schenkt, sie schenkt uns das Wohl beim Angehen und Überwinden der Probleme, sie schenkt uns Wohlergehen, indem sie uns frei macht für endgültige Entscheidungen; die Mutter lehrt uns, fruchtbar zu sein, für das Leben offen zu sein und immer Früchte des Guten zu bringen, Früchte der Freude, Früchte der Hoffnung, niemals die Hoffnung zu verlieren, den anderen das Leben zu schenken, physisch und geistlich.
<G-vec00442-001-s097><bear.bringen><en> The Salus Populi Romani is the mother that gives us health in growth, she gives us health in facing and overcoming problems, she gives us the health to make us free to make definitive choices. The mother teaches us how to be fruitful, to be open to life and to always bear good fruit, joyful fruit, hopeful fruit, and never to lose hope, to give life to others, physical and spiritual life.
<G-vec00442-001-s098><bear.bringen><de> Teenager: Falsche Bewegungen bei Spiel und Sport bringen oft einen größeren Schock, als die Wirbelsäule tolerieren kann.
<G-vec00442-001-s098><bear.bringen><en> Teenagers: Wrong movements while playing or doing sport often exert a more powerful shock to the spine than it can bear.
<G-vec00442-001-s099><bear.bringen><de> 15 Das in der guten Erde aber sind die, welche in einem redlichen und guten Herzen das Wort, nachdem sie es gehört haben, bewahren und Frucht bringen mit Ausharren.
<G-vec00442-001-s099><bear.bringen><en> "15 ""But the ones that fell on the good ground are those who, having heard the word with a noble and good heart, keep it and bear fruit with patience."
<G-vec00442-001-s100><bear.bringen><de> Wenn Sie einen Provider nicht mehr wollen, können Sie später immer wechseln, obgleich dieser Wechsel auch eine Änderung Ihrer E-Mail Adresse mit sich bringen wird.
<G-vec00442-001-s100><bear.bringen><en> If you don't like one provider, you can always change later, though bear in mind that this may well change your email address too.
<G-vec00442-001-s101><bear.bringen><de> »Wenn die Frucht, die wir bringen sollen, die Liebe ist, so ist ihre Voraussetzung eben dieses ›Bleiben‹, das ganz tief mit dem Glauben zu tun hat, der den Herrn nicht losläßt« (Jesus von Nazareth, Freiburg-Basel-Wien 2007, S. 307).
<G-vec00442-001-s101><bear.bringen><en> “If the fruit we are to bear is love, its prerequisite is this ‘remaining’, which is profoundly connected with the kind of faith that holds on to the Lord and does not let go” (Jesus of Nazareth, Doubleday, New York 2007, p. 262).
<G-vec00442-001-s102><bear.bringen><de> Dennoch wird der Ökumenismus keine dauerhaften Früchte bringen, wenn er nicht von konkreten Gesten der Umkehr begleitet ist, die das Gewissen berühren und die Heilung der Erinnerungen und der Beziehungen fördern.
<G-vec00442-001-s102><bear.bringen><en> Yet, ecumenism will not bear lasting fruit unless it is accompanied by concrete actions of conversion that move our consciences and foster the healing of memory and of relationships.
<G-vec00442-001-s103><bear.bringen><de> Nur durch das Gebet allein können wir an Ihrem Plan teilhaben und Frucht bringen.
<G-vec00442-001-s103><bear.bringen><en> It is only through prayer that we can be part of Her plan and thus bear fruit.
<G-vec00442-001-s104><bear.bringen><de> Die Jünger werden beauftragt, hinzugehen und Frucht zu bringen; und sie bekommen ein gesetzmäßiges Recht, den Namen Jesu zu benutzen und dieselbe Autorität zu haben, wie sie Jesus in Seinem irdischen Wandel ausübte: JOHANNES 16:23-24,26 .
<G-vec00442-001-s104><bear.bringen><en> The disciples are commissioned to go and bear fruit; and they are given a legal right to use the Name of Jesus and to have the same authority that Jesus exercised in His earthly walk: JOHNÂ 16:23-24,26 .
<G-vec00442-001-s105><bear.bringen><de> Nun sind wir heute hier am Grab des ersten Apostels um unseren Glauben an Petrus und an den Petrusnachfolger, den Christus mit seinem Amt betraut, hat zum Ausdruck zu bringen.
<G-vec00442-001-s105><bear.bringen><en> Today we are here at the tomb of the first of the Apostles to bear witness to love for Peter and the Successor of Peter.
<G-vec00442-001-s106><bear.bringen><de> Außerdem ist die Kirche Braut Christi – und damit beende ich das Thema der Ordensschwestern – und die Schwestern sind Bräute Christi, und daraus nehmen sie all ihre Kraft, vor dem Tabernakel, vor dem Herrn, im Gebet mit ihrem Bräutigam, um seine Botschaft zu bringen.
<G-vec00442-001-s106><bear.bringen><en> Moreover, the Church is the Bride of Jesus Christ — I shall stop talking about the nuns — and nuns are the brides of Jesus Christ, and they draw all their strength from there, before the Tabernacle, before the Lord, in prayer with their Spouse, to bear his message.
<G-vec00442-001-s107><bear.bringen><de> Jeder von uns ist eine Rebe des einzigen Weinstocks; und alle zusammen sind wir berufen, die Früchte dieser gemeinsamen Zugehörigkeit zu Christus und der Kirche zu bringen.
<G-vec00442-001-s107><bear.bringen><en> Each one of us is a branch of the one vine; and all of us together are called to bear the fruits of this common membership in Christ and in the Church.
<G-vec00442-001-s108><bear.bringen><de> Wir können keine ewige Frucht bringen, bis wir willig sind, als ein Same in den Boden zu fallen und zu sterben.
<G-vec00442-001-s108><bear.bringen><en> We cannot bear eternal fruit unless we are willing, as a seed, to fall into the ground and die.
<G-vec00442-001-s109><bear.bringen><de> Das volle Potenzial in der Industrieautomation oder im Bereich Automotive werden – auch in wirtschaftlicher Hinsicht – erst die 5G-Netze mit ihren deutlich niedrigeren Signallaufzeiten bringen.
<G-vec00442-001-s109><bear.bringen><en> The full potential in industrial automation or in the automotive industry – in economic terms, too – will first be brought to bear by 5G networks, and their significantly lower signal propagation delays.
<G-vec00442-001-s110><bear.bringen><de> Für die jüngeren Elchkühe ist es üblich nur ein Kalb auf die Welt zu bringen.
<G-vec00442-001-s110><bear.bringen><en> For the younger elk cows it is common to bear only one calf.
<G-vec00442-001-s111><bear.bringen><de> Die Kinder Gottes sind die, die Frucht bringen.
<G-vec00442-001-s111><bear.bringen><en> The sons of God are those who bear fruit.
<G-vec00442-001-s112><bear.bringen><de> "Die zweiten drei hingegen, haben eine ""intakte"" Umwelt und bringen auch Früchte."
<G-vec00442-001-s112><bear.bringen><en> "The second three, on the other hand, have an ""intact"" environment and also bear fruits."
<G-vec00442-001-s113><bear.bringen><de> Die Begrünung des Dachs Wenn Sie sich entschieden haben, sich mit der Begrünung des Dachs zu beschäftigen, seien Sie überzeugt – wird dieses Werk Ihnen die Früchte bringen.
<G-vec00442-001-s113><bear.bringen><en> Gardening of a roof If you decided to be engaged in gardening of a roof, be sure – this work will bear to you fruit.
<G-vec00169-001-s095><draw.bringen><de> Wenn diese Schattenseite unterdrückt und in die Unterwelt des Unbewussten verwiesen wird, kommt sie hinter Ihrem freundlichen Äusseren zum Vorschein und zeigt dann eine diktatorischere und arrogantere Persönlichkeit, als Sie anderen Leuten zeigen möchten, und sie wird Sie zwanghaft in Komplikationen bringen, wo Sie auf Ihre eigenen Ressourcen zurückgreifen müssen.
<G-vec00169-001-s095><draw.bringen><en> Repressed and relegated to the netherworld of the unconscious, this shadow-side will peep out from behind your equable exterior, revealing a more dictatorial and arrogant personality than you wish others to see; and it will draw you compulsively into entanglements where you are thrown back on your own resources.
<G-vec00169-001-s096><draw.bringen><de> Sie möge für uns alle Fürsprache halten und uns näher zu Christus, ihrem Sohn, bringen.
<G-vec00169-001-s096><draw.bringen><en> May she intercede for us all, and draw us closer to Christ her Son.
<G-vec00169-001-s097><draw.bringen><de> 6) Die vereinten legislativen und exekutiven Kräfte des revolutionären proletarischen Staates werden ihr äusserstes tun, um den Verwaltungsapparat näher zu den Massen zu bringen, diesen mit ihnen zu verschmelzen und die Teilnahme der Werktätigen an allen verwaltungsmässigen Belangen sicher zu stellen.
<G-vec00169-001-s097><draw.bringen><en> 6) Combining the legislative and the executive powers, the revolutionary state power of the proletariat shall do its utmost to draw the administrative apparatus nearer to the masses and merge it with them and to ensure the participation of all toilers to the conduct of administrative affairs.
<G-vec00169-001-s098><draw.bringen><de> Doch was man jetzt zu Papier bringen will, ist eine Präambel ohne Verfassung.
<G-vec00169-001-s098><draw.bringen><en> But today what is being suggested is to draw up a preamble without a constitution.
<G-vec00169-001-s099><draw.bringen><de> Das wird uns sicherlich einige Erkenntnisse mehr bringen als das letzte Wochenende.
<G-vec00169-001-s099><draw.bringen><en> This will surely enable us to draw better conclusions.
<G-vec00169-001-s100><draw.bringen><de> Es ist ohne Zweifel schwierig, die eigene Freude - den Tanz der eigenen Seele - hoch zu halten, wenn man mit streitsüchtigen, unfreundlichen, herrischen oder manipulativen Menschen zu tun hat, oder auch Menschen, die das Muster an den Tag legen, einen in Konflikt zu bringen.
<G-vec00169-001-s100><draw.bringen><en> It is admittedly difficult to keep one's joy - the dance of one's soul - high when dealing with a cantankerous person, or an unkind person or a domineering or manipulative person, or a person who exhibits a pattern of trying to draw one into a conflict.
<G-vec00169-001-s101><draw.bringen><de> Während die Klimaverhandlungen in Paris in den internationalen Medien im Mittelpunkt stehen, ist es höchste Zeit, das Thema Militär auf den Tisch zu bringen und zu fordern, dass die Anpassung an den Klimawandel von Menschenrechtsprinzipien und Solidarität geleitet wird, statt von Militarismus und Konzernprofiten.
<G-vec00169-001-s101><draw.bringen><en> As the Paris climate talks take the global stage, it's time to draw attention to the military elephant in the room and demand that adaptation to climate change is led by principles of human rights and solidarity, rather than militarism and corporate profits.
<G-vec00169-001-s102><draw.bringen><de> Man muss die Veröffentlichungen dieser Informationen eher als Möglichkeit sehen, die eigenen Geschäftsinteressen sich ins Gespräch zu bringen und nicht so sehr als brauchbare Bewertung von Marken.
<G-vec00169-001-s102><draw.bringen><en> One has to see the publication of this information more as an opportunity to draw attention to one’s own business interests and oneself and not so much as a useful evaluation of brands.
<G-vec00169-001-s103><draw.bringen><de> Auf Wunsch kommt nach dem Weckruf ein Butler des St. Regis, um die Vorhänge aufzuziehen, Ihnen Kaffee oder Tee sowie die Tageszeitung zu bringen und um Ihnen die Wettervorhersage mitzuteilen.
<G-vec00169-001-s103><draw.bringen><en> If you wish, a St. Regis Butler will arrive after your morning wake-up call to draw your shades, deliver your coffee or tea, and provide the day's newspaper and weather forecast.
<G-vec00169-001-s104><draw.bringen><de> Die WM 2009 Berlin sollte schon weit im Vorfeld auch die Jugend für die Leichtathletik begeistern und wieder in die Vereine bringen.
<G-vec00169-001-s104><draw.bringen><en> The 2009 Championships in Berlin are supposed to enthuse the youth for athletics and draw them back to the clubs long before the event.
<G-vec00169-001-s105><draw.bringen><de> Unsere Systeme bringen alle Funktionen in eine einheitliche Gestaltung.
<G-vec00169-001-s105><draw.bringen><en> Our systems draw all these functions together under a uniform design concept.
<G-vec00169-001-s106><draw.bringen><de> Die in den Leib und das Blut Christi verwandelten Gestalten von Brot und Wein ziehen uns hinein in die Dynamik einer kontinuierlichen Umgestaltung und bringen uns dem Ziel näher, nach dem wir uns sehnen– der endgültigen Verwandlung von allem in der Communio mit Christus und untereinander: „Wir alle... werden so in sein eigenes Bild verwandelt, von Herrlichkeit zu Herrlichkeit, durch den Geist des Herrn.“ (2Kor 3,18).
<G-vec00169-001-s106><draw.bringen><en> Changed into the body and blood of Christ, the bread and wine insert us into a principle of gradual transfiguration that will draw us towards the goal we long for – the definitive transformation of all in communion with Christ and with one another: ‘And all of us…are being transformed into the same image from one degree of glory to another; for this comes from the Lord, the Spirit’ (2 Cor 3:18).
<G-vec00169-001-s107><draw.bringen><de> Wie trockene und staubige Bereiche bringen auch nasse und feuchte Stellen das Risiko von Schimmelpilzallergie in Ihr zu Hause.
<G-vec00169-001-s107><draw.bringen><en> As well as dry, dusty areas—wet, moist areas draw the risk of mold allergens into your home sweet home.
<G-vec00169-001-s108><draw.bringen><de> Sie bringen Wirtschafsexperten, Vertreter von Konzernen und sozialen Unternehmen zusammen, um auf lokaler und regionaler Ebene Netzwerke aufzubauen, in denen bewährte Praktiken ausgetauscht und Bewusstsein und Unterstützung für neue ethisch orientierte Unternehmen verbreitet werden können.
<G-vec00169-001-s108><draw.bringen><en> They draw together business experts, corporate delegates and social enterprises to build local and regional networks for sharing good practices and to disseminate awareness and support for new ethical enterprises.
<G-vec00169-001-s109><draw.bringen><de> Ich möchte euch von neuem meinem Unbefleckten Herzen näher bringen, wo ihr Zuflucht und Frieden finden werdet.
<G-vec00169-001-s109><draw.bringen><en> Again I desire to draw you closer to my Immaculate Heart, where you will find refuge and peace.
<G-vec00169-001-s110><draw.bringen><de> Auf diesem Weg wollen sie nicht nur sicherstellen, dass die EU innerhalb des amerikanischen globalen Systems bleibt, sondern sie auch näher an ihre aggressive Haltung im Nahen Osten bringen.
<G-vec00169-001-s110><draw.bringen><en> In this way they not only want to secure that the EU remains within the American global system but also draw them closer to their aggressive approach to the Middle East.
<G-vec00169-001-s111><draw.bringen><de> Das Jazzfestival, zahlreiche lokale Sportveranstaltungen und selbstverständlich die berühmten Attraktionen bringen Gäste ebenfalls in unser Hotel.
<G-vec00169-001-s111><draw.bringen><en> The Jazz Festival, numerous local sporting events, and of course famous attractions also draw guests to our hotel.
<G-vec00169-001-s112><draw.bringen><de> Während in den positiven Bereichen der (Modus) darin liegt, die sich entwickelnde Seele in Situationen zu bringen, wo sie sich tiefgehend INS Licht erweitern kann, besteht das Ziel in den korrespondierenden negativen Bereich darin,... die Entwicklung von passenden mechanischen Geist/Körper Funktionen zu erreichen, damit die Lichtenergie vom gierigen Loch oder der naturgegebenen Leere des Fehlens von Emotionen mehr Licht verschlungen werden kann, einschließlich des negativen Zustandes des Ego-Seele Komplexes.
<G-vec00169-001-s112><draw.bringen><en> Yet whereas in the positive realms the [mode] is to draw the developing soul toward deep degrees of expansion into light, in the corresponding negative realms the object is, rather, a … development of appropriate mind/body mechanical means of devouring more light, stuffing the light-energy into the voracious hole or constitutional void of emotional lack comprising the negative state of the ego-soul altogether.
<G-vec00169-001-s113><draw.bringen><de> Das kreatives Projekt mit Ziel die Schöpfungskraft und die Gefühle in dem technischen Glas zu bringen.
<G-vec00169-001-s113><draw.bringen><en> Creative project with an aim to draw creativity and emotions to technical glass.
<G-vec00169-001-s068><fetch.bringen><de> Ein Haus zu kaufen oder in eine Immobilie zu investieren wird Ihnen sicherlich lukrative Erträge bringen.
<G-vec00169-001-s068><fetch.bringen><en> Buying a home or investing in a property here will certainly fetch you lucrative returns.
<G-vec00169-001-s069><fetch.bringen><de> Durch Vermehren der landwirtschaftlichen Fläche, um den steigenden Verbrauch durch zunehmendes Bevölkerungswachstum abzufangen; Nutzbarmachung der Wüste, um sie zum Gedeihen und Blühen zu bringen, und dabei die riesigen Bodenschätze, die in ihr lagern, herauszuholen und zu verwerten; Ausnützung des Überschusses des Nilwassers und des riesigen Grundwasservorrates unter der Wüste, um ein Gebiet mit gesundem Klima für die Entwicklung von Tierzucht zu schaffen.
<G-vec00169-001-s069><fetch.bringen><en> Increasing the agricultural surface, in order to intercept rising consumption by the vast population growth; Utilization of the desert, in order to make her prosper and flower and to fetch and use the enormous natural resources resting within her; Utilization of the surplus of Nile water and the enormous groundwater supply under the desert to create an area with healthily climate for development of animal breeding.
<G-vec00169-001-s070><fetch.bringen><de> In unserer Ateliergemeinschaft arbeiten wir auch mit der Thermischen Vakuum-Verformung wobei wir geschweißte Motiv-Stahlformen in Stahlblechhohlkörper einbetten und das Stahlblech durch Vakuum mit Bleihämmern über die Form bringen.
<G-vec00169-001-s070><fetch.bringen><en> In our studio community laboring we also with the thermic vacuum-deformation whereby we welded motive-steel moulds in steel sheet hollow body embedding and the steel sheet through vacuum with lead hammers over the form fetch.
<G-vec00169-001-s071><fetch.bringen><de> Man soll euch ein wenig Wasser bringen und eure Füße waschen, und lehnt euch unter den Baum.
<G-vec00169-001-s071><fetch.bringen><en> But I will fetch a little water, and wash ye your feet, and rest ye under the tree.
<G-vec00169-001-s072><fetch.bringen><de> Er scherzte herum, dass wir es ganz schnell dazu bringen sollten, dass es Apportiert und nachdem wir seine Methoden beobachtet haben, denke ich, er könnte vielleicht Recht haben.
<G-vec00169-001-s072><fetch.bringen><en> He joked that we should have it trained to fetch in no time, and after observing his methods I think he might be right.
<G-vec00169-001-s073><fetch.bringen><de> Diese bringen den Städtchen Tomar, Batalha und Alcobaça eine Menge Touristen ein.
<G-vec00169-001-s073><fetch.bringen><en> These fetch a lot of tourists to the towns of Tomar, Batalha and Alcobaça.
<G-vec00035-001-s095><get.bringen><de> "Sie bringen die Songs ihres neuen Albums ""Spiritual Hallucination"" super gut herüber."
<G-vec00035-001-s095><get.bringen><en> "They get across the songs from their new album ""Spiritual Hallucination"" brilliantly."
<G-vec00035-001-s096><get.bringen><de> Polenz betonte zum Abschluss erneut, dass es doch im Interesse der iranischen Regierung sei, die IAEA auf ihre Seite zu bringen.
<G-vec00035-001-s096><get.bringen><en> Concluding, Polenz again stressed that it was in the interest of the Iranian government to get the IAEA on its side.
<G-vec00035-001-s097><get.bringen><de> Sie bringen Ihr Gut auf den Weg, und wir empfangen Ihre Sendung in Deutschland im Hafen oder am Flugplatz.
<G-vec00035-001-s097><get.bringen><en> They get your goods underway, and we receive your consignment in Germany at the harbour or at the airport.
<G-vec00035-001-s098><get.bringen><de> Er macht sehr viel Spaß, er kann mich sehr schnell aus der Ruhe bringen oder ich kann die Dinge so lange ausdehnen, wie ich will und die Orgasmen, die er abliefert, scheinen ewig zu dauern.
<G-vec00035-001-s098><get.bringen><en> He is a lot of fun to use, he can get me off very quickly or I can stretch things out as long as I want and the orgasms that he delivers seem to go on for ages.
<G-vec00035-001-s099><get.bringen><de> „Wenn sie sinnvoll sein soll, müssen wir alle Länder mit ins Boot bringen“.
<G-vec00035-001-s099><get.bringen><en> """We need to get all countries on board for it to be meaningful""."
<G-vec00035-001-s100><get.bringen><de> Es war nur wenig Nachhilfe erforderlich, um das gesamte Team dazu zu bringen, Evernote regelmäßig zu verwenden.
<G-vec00035-001-s100><get.bringen><en> There was minimal coaching involved to get the entire team using Evernote regularly.
<G-vec00035-001-s101><get.bringen><de> Das Prinzip ist einfach: Bringen Sie jeder dasselbe temporäre Tattoo an, um Ihre neue Freundschaft zu besiegeln.
<G-vec00035-001-s101><get.bringen><en> The concept is simple: you can each get matching temporary tattoos to signify your new friendship.
<G-vec00035-001-s102><get.bringen><de> Weil sie ihn aber wegen der vielen Leute nicht bis zu Jesus bringen konnten, deckten sie dort, wo Jesus war, das Dach ab, schlugen (die Decke) durch und ließen den Gelähmten auf seiner Tragbahre durch die Öffnung hinab.
<G-vec00035-001-s102><get.bringen><en> Since they could not get him to Jesus because of the crowd, they made an opening in the roof above Jesus and, after digging through it, lowered the mat the paralysed man was lying on.
<G-vec00035-001-s103><get.bringen><de> In der Woche, seit wir Brandon geschlagen hatten und uns selbst zu Göttern und den Beschützern der Vereinigten Staaten und der Welt erklärt hatten, hatten Mary und ich unzählige Interviews gegeben und Telefonate geführt, um so viele Menschen wie möglich unter unsere Kontrolle zu bringen.
<G-vec00035-001-s103><get.bringen><en> In the week since we defeated Brandon and declared ourselves Gods and Protectors of the United States and the World, Mary and I had been busy. Giving interviews, making phone calls, trying to get as many people in power as possible under our control.
<G-vec00035-001-s104><get.bringen><de> Die APS (Animated Polymer System) Bushings garantieren geradlinige und vorhersehbare Turns, gepaart mit einer ordentlichen Portion Rebound, um deine Achsen nach schnellen Turns wieder in die Ausgangsposition zu bringen.
<G-vec00035-001-s104><get.bringen><en> The APS (Animated Polymer System) compound type bushing offers a very linear and predictable turn with a solid rebound, to get your trucks back to the center after quick turns.
<G-vec00035-001-s105><get.bringen><de> Fragen wie diese können Gebäudemanager jetzt präzise beantworten –und ihre Modernisierungsinvestitionen dort ansetzen, wo sie wirklich am meisten bringen.
<G-vec00035-001-s105><get.bringen><en> Building managers can now get precise answers to questions like these – and can then make modernisation investments precisely where they are needed the most.
<G-vec00035-001-s106><get.bringen><de> Sie können für Deinen Beitrag den Stein ins Rollen bringen.
<G-vec00035-001-s106><get.bringen><en> They can get the ball rolling for your article.
<G-vec00035-001-s107><get.bringen><de> Ergänzt wird die Arbeit durch Qualifizierungsmaßnahmen, um in enger Kooperation mit dem jemenitischen Privatsektor junge Menschen schnell in Beschäftigung zu bringen, sowie durch Maßnahmen zur Stärkung der Ressourcen und Leistungsfähigkeit der Partner.
<G-vec00035-001-s107><get.bringen><en> These activities are being supplemented with training measures that enable the project to work closely with the Yemeni private sector to get young people into employment rapidly, and with initiatives to strengthen the partners' resources and capacity.
<G-vec00035-001-s108><get.bringen><de> Die aktive Teilnahme an Diskussionsforen, Blog-Communities, Facebook Gruppen, LinkedIn Gruppenund spezialisierte Foren, werden mehr Wirkung bringen.
<G-vec00035-001-s108><get.bringen><en> Active participation on discussion boards, blog communities, social media channels, Facebook groups, LinkedIn groups and specialized forums will get you more exposure.
<G-vec00035-001-s109><get.bringen><de> Das ist ein guter Weg, um das Gespräch ins Rollen zu bringen.
<G-vec00035-001-s109><get.bringen><en> That’s a good way to get the conversation rolling.
<G-vec00035-001-s110><get.bringen><de> Alle Produkt- und Dienstleistungsangebote der HWA AG stehen unter dem Motto ENGINEERING SPEED: Anspruch des Unternehmens ist es, die jeweils besten und hochwertigsten Lösungen zu entwickeln, um seine Partner und Kunden noch schneller an ihre Ziele zu bringen.
<G-vec00035-001-s110><get.bringen><en> HWA AG offers all its products and services under the corporate slogan ENGINEERING SPEED: The company's objective is to develop the best possible high-quality solutions, in order to get its partners and customers to their destination quicker.
<G-vec00035-001-s111><get.bringen><de> Ich dachte nicht dass es so unmöglich sei jemand dazu zu bringen, besonders diejenigen die mich kannten, mir zu glauben was ich versuchte ihnen zu erzählen.
<G-vec00035-001-s111><get.bringen><en> I didn't think it would be so impossible to get anyone, especially those who knew me, to believe what I was trying to tell them.
<G-vec00035-001-s112><get.bringen><de> """Die Agentur ist so gut vernetzt mit all unseren wichtigen Medien, dass sie auch uns als neuen Player in Szene setzen und ins Gespräch bringen kann."
<G-vec00035-001-s112><get.bringen><en> """The agency has such good connections with all the media that are important to us that it can generate exposure and get people engaging with us even as a new player in this space."
<G-vec00035-001-s113><get.bringen><de> Lassen Sie sich von AAA Limo wissen, wann Sie abgeholt werden, und wir bringen Sie in Dallas in Luxus, mit Stretchlimousine, klassischer Limousine oder High-End-SUV.
<G-vec00035-001-s113><get.bringen><en> Just let AAA Limo know when to pick you up, and we will get you around Dallas in luxury, with stretch limo, classy sedan, or high-end SUV.
<G-vec00499-001-s095><give.bringen><de> Verschiedene Tests bringen verschiedene Ergebnisse, selbst wenn du den gleichen Test zwei Mal machst.
<G-vec00499-001-s095><give.bringen><en> Different tests will give you different results, even if you take the same test twice.
<G-vec00499-001-s096><give.bringen><de> Dieses Mal musste ich ohne Wagenheber auskommen, aber die vier Meter lange Planke würde mir eine starke Hebelkraft bringen, wenn ich sie richtig einsetzte.
<G-vec00499-001-s096><give.bringen><en> This time I had to do without the jack, but the four meter long plank would give me a lot of lifting power if I used it right.
<G-vec00499-001-s097><give.bringen><de> Umfassende Marktübersichten und Schwerpunktberichte bringen den Durchblick in allen wichtigen Bereichen der Elektronik.
<G-vec00499-001-s097><give.bringen><en> Extensive surveys and focused reports give a reliable overview of all the important fields in electronics.
<G-vec00499-001-s098><give.bringen><de> Diese warme Lidschatten-Palette bietet 18 hervorragende und warme Farbtöne, die Dir DEN sexy Look bringen werden.
<G-vec00499-001-s098><give.bringen><en> This warm eye shadow palette offers 18 excellent and warm shades that will give you THE sexy look.
<G-vec00499-001-s099><give.bringen><de> Unsere intelligenten Lagerlösungen bringen auch Ihnen Wettbewerbsvorteile.
<G-vec00499-001-s099><give.bringen><en> Our intelligent warehousing solutions also give you competitive advantages.
<G-vec00499-001-s100><give.bringen><de> "Seine ""Rezepte"" bringen auch heute noch das Porzellan zum Glanz."
<G-vec00499-001-s100><give.bringen><en> "His ""recipes"" still today give the brilliance to the porcelain."
<G-vec00499-001-s101><give.bringen><de> Pets des Elements Feuer bringen einen Bonus auf das Attribut Glück.
<G-vec00499-001-s101><give.bringen><en> Pets of the element Fire give a bonus on attribute Luck.
<G-vec00499-001-s102><give.bringen><de> Mit einer originellen und frischen Design, ist dieser Beistelltisch perfekt, um einen Hauch von Moderne in Ihr Wohnzimmer zu bringen.
<G-vec00499-001-s102><give.bringen><en> With an original and fresh design, this side table is perfect to give a touch of modernity to your living room.
<G-vec00499-001-s103><give.bringen><de> Die Liebhaber der Spiele wissen die Hauptregeln der Durchführung der Ziehung sicher, aber dafür, wer nur beginnt, den Erfolg zu erproben, wir werden die Hauptregeln bringen.
<G-vec00499-001-s103><give.bringen><en> Fans of games for certain know the basic rules of carrying out draw, but for those who only starts testing good luck, we will give the basic rules.
<G-vec00499-001-s104><give.bringen><de> "Solch eine ""Verteidigung"" kann nicht sofort wunderbare Ergebnisse bringen."
<G-vec00499-001-s104><give.bringen><en> "Such a ""defense"" cannot give immediate miraculous results."
<G-vec00499-001-s105><give.bringen><de> Auch die verschiedenen Gewinnmöglichkeiten bringen viel fun.
<G-vec00499-001-s105><give.bringen><en> also the different wining possibilities give you many fun.
<G-vec00499-001-s106><give.bringen><de> Wecken Sie Kindheitserinnerungen und bringen Passanten mit diesem Display zum staunen.
<G-vec00499-001-s106><give.bringen><en> Invoke childhood memories and give your customers a display to marvel at.
<G-vec00499-001-s107><give.bringen><de> Nur – der Mindestlohn wird uns das aber genau nicht bringen, sondern vor allem mehr Bürokratie, Verordnungen, Kontrollen, Bußgelder … Und noch mehr Ungerechtigkeit.
<G-vec00499-001-s107><give.bringen><en> Except – this is exactly what the concept minimum wages will not give us. Instead, it will give us even more bureaucracy, rules, control, penalties… And even more injustice.
<G-vec00499-001-s108><give.bringen><de> Die damit verbundenen neuen Betriebsweisen bringen auch veränderte mechanische Beanspruchungen der elektromechanischen Komponenten und veränderte Einwirkungen auf die Gewässerökosysteme mit sich.
<G-vec00499-001-s108><give.bringen><en> The associated methods of operation also give rise to changed physical loads on electromechanical components, as well as different influence son water ecosystems.
<G-vec00499-001-s109><give.bringen><de> """Wir haben verschiedene Methoden für soziale Innovation entwickelt"", so Fernandez Toro weiter, ""und dies wird für junge Menschen entscheidend sein, um kreative und spezifische Projekte zugunsten der Gemeinden auf den Weg zu bringen, in denen sie aktiv werden wollen""."
<G-vec00499-001-s109><give.bringen><en> """We have developed different methodologies on social innovation - continues the coordinator - and this will be fundamental so that young people can give life to creative and specific projects for the benefit of the communities in which they want to provide their service""."
<G-vec00499-001-s110><give.bringen><de> Dies kann dir einen Vorteil bringen.
<G-vec00499-001-s110><give.bringen><en> This can give you an advantage.
<G-vec00499-001-s111><give.bringen><de> Als der Vater meines Mannes im Januar dorthin ging, um ihm einige warme Kleider wegen des kalten Winters zu bringen, erlaubten sie ihm nicht, seine Familienmitglieder zu sehen.
<G-vec00499-001-s111><give.bringen><en> When my husband's father went to give him some warm clothes for the cold winter in January, they didn't allow him to see his family members.
<G-vec00499-001-s112><give.bringen><de> Dies wird den Fortschritt in der nachhaltigen Landwirtschaft behindern und der Pflanzenzüchtung in Europa einen Wettbewerbsnachteil bringen.
<G-vec00499-001-s112><give.bringen><en> This will hinder progress in sustainable agriculture and will give a competitive disadvantage to plant breeding industries in Europe.
<G-vec00499-001-s113><give.bringen><de> Nicht nur unser Chor, sondern auch unsere Gesangssolistinnen Lydia Klein und Emilie Schwan sowie die beiden Musikanten Stefan Klötzel (Balalaika) und Waldemar Hergert (Akkordeon) ernteten reichlich Applaus und mussten des öfteren Zugaben bringen.
<G-vec00499-001-s113><give.bringen><en> Not only our choir but also our soloists, Lydia Klein and Emilie Schwan, as well as the two musicians, Stefan Klötzel and Waldemar Hergert (accordion) met with great approval and had to give encores.
<G-vec00272-001-s038><push.bringen><de> Ein imposanter Bulle, welcher auch in der Rahmenentwicklung die gesamte Population nach vorne bringen wird.
<G-vec00272-001-s038><push.bringen><en> Impressive sire that will push the whole population towards bigger frames.
<G-vec00272-001-s039><push.bringen><de> Es gibt drei Möglichkeiten, das Training auf das nächste Level bringen.
<G-vec00272-001-s039><push.bringen><en> There are three ways to push the training to the next level.
<G-vec00272-001-s040><push.bringen><de> Sie können die Grenzen bringen und auch die Grenzen zwischen Erfolg und Misserfolg hinausgehen.
<G-vec00272-001-s040><push.bringen><en> You can push the limits and also transcend the boundaries in between success as well as failure.
<G-vec00272-001-s041><push.bringen><de> In der dritten Kerze der Formation übernehmen die Verkäufer die Kontrolle und bringen den Kurs mindestens auf die halbe Höhe des ersten Candlesticks.
<G-vec00272-001-s041><push.bringen><en> In the third candle of the formation, sellers take control and push prices at least half-way below the body of the first candle.
<G-vec00272-001-s042><push.bringen><de> Stéphane Lambiel wollte schon immer Teamgeist als treibende Kraft seiner Schule haben, um jeden dazu zu bringen, seinen Traum zu verwirklichen.
<G-vec00272-001-s042><push.bringen><en> Stéphane Lambiel has always wanted the team to be the main driver of his school in order to push everyone to realize their dream.
<G-vec00272-001-s043><push.bringen><de> Es könnte tausende Ukrainer dazu bringen, die lange und durchlässige Grenze des Landes zu Polen, Rumänien, Ungarn und der Slowakei zu überqueren.
<G-vec00272-001-s043><push.bringen><en> It could also push thousands of Ukrainians to migrate across the country's long and porous borders with Poland, Romania, Hungary and Slovakia.
<G-vec00272-001-s044><push.bringen><de> Jedes Mal, wenn die Europäer sich ihrer Politik gegenüber Russland in den Weg stellen, behauptet Deutschland, dass die utopischen Pläne von Europa nicht machbar seien und Russland dazu führen könnte, sein Gas in Asien zu verkaufen, und die europäische Energiesicherheit damit in Gefahr bringen könnte.
<G-vec00272-001-s044><push.bringen><en> Every time Europeans oppose Germany and its policy regarding Russia, Berlin asserts that the Europe’s Utopian plans are unenforceable and may push Russia to sell its gas in Asia.
<G-vec00272-001-s045><push.bringen><de> Zusätzlich zu unseren eigenen Erfahrungen unterhalten wir eine Partnerschaft mit dem Joint Doctor, um Pionierarbeit bei neuen Genetiklinien und Zuchttechniken zu leisten, um die Wirkungsstärke, den Ertrag und die Leistung auf neue Ebenen zu bringen.
<G-vec00272-001-s045><push.bringen><en> In addition to our own experience we have also partnered with the Joint Doctor to pioneer new genetic lines and breeding techniques to push potency, yield and performance to new levels.
<G-vec00272-001-s046><push.bringen><de> Der Sieg beim Eurovision Song Contest blieb ihrem Schüler Erener vorbehalten und somit schaffte er den Traum Aksus zu verwirklichen, ihre musikalischen Visionen nach Europa zu bringen.
<G-vec00272-001-s046><push.bringen><en> It was to be left to her pupil Erener to win the Eurovision and realise Aksu's dream to push her musical vision further into Europe.
<G-vec00272-001-s047><push.bringen><de> """Ich versuche immer, alles herauszuholen und die Musik irgendwohin zu bringen, wo sie noch nie zuvor gewesen ist."
<G-vec00272-001-s047><push.bringen><en> """I am always trying to push the envelope and take the music somewhere it hasn't been before."
<G-vec00272-001-s048><push.bringen><de> Es ist möglich, dass sie eure Eigensinne verstärken und euch an den Rand von Gefahr bringen, um ihr entsetzliches Ziel zu erreichen, Kultivierende zu vernichten.
<G-vec00272-001-s048><push.bringen><en> It is possible that they may amplify your attachments and push you close to the brink of danger to attain their terrifying goal of destroying cultivators.
<G-vec00272-001-s049><push.bringen><de> Um jederzeit aktuell zu bleiben, müssen wir laufend Lösungen suchen und finden, die uns immer wieder in neue Richtungen bringen.
<G-vec00272-001-s049><push.bringen><en> To stay relevant, we must constantly seek out and find solutions that can push us in slightly different directions.
<G-vec00272-001-s050><push.bringen><de> Dieses Paket wird euch mit speziellen Herausforderungen im Überleben- und Zerstörung-Modus an eure Grenzen bringen.
<G-vec00272-001-s050><push.bringen><en> This pack will push you to the limits with specific challenges across Survival and Destruction mode.
<G-vec00272-001-s051><push.bringen><de> Unten: Dave versucht Tich dazu zu bringen die Gitarre runterzudrücken...
<G-vec00272-001-s051><push.bringen><en> Below: Dave trying to get Tich to push his guitar down...
<G-vec00272-001-s052><push.bringen><de> River Drive«) und 9th Wonder („The Bigger Picture“) das Album mit ihren Produktionen zu wahren Höhepunkten bringen.
<G-vec00272-001-s052><push.bringen><en> River Drive«) and 9th Wonder‘s („The Bigger Picture“) productions push the album to its actual climax.
<G-vec00272-001-s053><push.bringen><de> QIoT Suite nutzt Freeboard als IoT Dashboard-Anzeige, das über API geteilt werden kann um die gesammelten Gerätedaten, auf andere Dashboards wie Microsoft® Power BI zur weiteren Datenanalyse, zum Teilen oder für den Import/Export zu bringen.
<G-vec00272-001-s053><push.bringen><en> QIoT Suite uses Freeboard as its IoT dashboard display, which can be shared via API to push the collected device data stored on QNAP NAS to other dashboards such as Microsoft® Power BI for further data analysis, sharing, or import/export.
<G-vec00272-001-s054><push.bringen><de> Es gibt mehr technische Systeme zu überwachen und zu bedienen, doch unsre Teamstärke wird nicht ansteigen.Ich liebe es, gigantische und teure Titel wie Battlefield oder GTA zu spielen, diese bringen die Spielequalität auf immer höhere Levels, daher ist es absolut großartig, dass es große Publisher gibt, die diese Budgets tatsächlich zur Verfügung stellen.
<G-vec00272-001-s054><push.bringen><en> More technical systems need to be maintained and controlled but our manpower will not increase.I love playing huge and expensive titles like Battlefield or GTA, they always push the gaming quality to new heights, so it is absolutely great that there are big publishers who actually give those budgets.
<G-vec00272-001-s055><push.bringen><de> Diese werden für Investitionen in die Zukunft auch notwendig sein, um das Unternehmen weiter nach vorne zu bringen.
<G-vec00272-001-s055><push.bringen><en> These will be necessary for investments in the future to push the company forward.
<G-vec00272-001-s056><push.bringen><de> Obwohl ich herausfand, dass der Kurs über den Islam sehr voreingenommen war, schien er mich näher zu ihm zu bringen.
<G-vec00272-001-s056><push.bringen><en> Though I found the course prejudicial to Islam, it seemed to push me closer to it.
<G-vec00169-001-s313><raise.bringen><de> Ethik ist das Hilfsmittel, mit dessen Hilfe man sich selbst auf einen höheren Zustand bringen und sein Überleben verbessern kann.
<G-vec00169-001-s313><raise.bringen><en> Ethics is the means by which he can raise himself to a higher condition and improve his survival.
<G-vec00169-001-s314><raise.bringen><de> Jedoch online suchen keine Ergebnisse über Vertreter bringen Sitz in Botswana oder spezialisierte Firma für diese Versorgung verfügbar.
<G-vec00169-001-s314><raise.bringen><en> However on the internet searches do not raise any outcomes concerning distributors based in Botswana or specialist firm available for this supply.
<G-vec00169-001-s315><raise.bringen><de> Altern und demographischer Wandel bringen neben medizinisch-naturwissenschaftlichen Fragestellungen grundlegende ethische, rechtliche, ökonomische, human- und sozialwissenschaftliche Herausforderungen mit sich, die nur in der Zusammenarbeit verschiedener Disziplinen analysiert und bewältigt werden können.
<G-vec00169-001-s315><raise.bringen><en> Aging and demographic change raise not only medical and scientific issues, they also pose fundamental challenges in ethics, law, economics, the humanities, and the social sciences.
<G-vec00169-001-s316><raise.bringen><de> 3 Und sie haben sich außer Ihm Götter genommen, die nichts erschaffen, während sie (selbst) erschaffen werden, und die sich selbst weder Schaden noch Nutzen zu bringen vermögen und die weder über Tod noch über Leben noch über Auferstehung verfugen.
<G-vec00169-001-s316><raise.bringen><en> 3 Yet they choose beside Him other gods who create naught but are themselves created, and possess not hurt nor profit for themselves, and possess not death nor life, nor power to raise the dead.
<G-vec00169-001-s317><raise.bringen><de> """Unser Flaggschiff-Event für mehr als 12.000 Teilnehmer umfasst ein Gala-Dinner für eintausend Gäste, eine komplette Tagesveranstaltung mit Bühnenvorträgen unserer Unternehmenssprecher, ein riesiges interaktives Experimentier-Areal und eine gigantische Party, bei der 4.000 Besucher das Dach der Messe Stuttgart zum Beben bringen."
<G-vec00169-001-s317><raise.bringen><en> """Our flagship event for over 12,000 participants comprising a Gala dinner for 1000+, a full day event of company speakers on stage, a vast interactive experiential area and a huge party where 4,000 people raise the roof of Messe Stuttgart, requires the focus of a very special team."
<G-vec00169-001-s318><raise.bringen><de> Vor dem Konzert machen wir normalerweise “Image Training”, um uns in Stimmung zu bringen.
<G-vec00169-001-s318><raise.bringen><en> Before the show, we usually do “image training” to raise our spirits.
<G-vec00169-001-s319><raise.bringen><de> Ohne verantwortungsvolle Prozesse kann die Herstellung des Öls jedoch ökologische und soziale Herausforderungen mit sich bringen.
<G-vec00169-001-s319><raise.bringen><en> However, the production of palm oil can raise environmental and social challenges if not conducted responsibly.
<G-vec00169-001-s320><raise.bringen><de> Doch nur die Parole einer umfassenden und planmäßigen Zusammenarbeit mit der Sowjetunion kann diesen Kampf auf die Höhe der revolutionären Aufgaben bringen.
<G-vec00169-001-s320><raise.bringen><en> But only the slogan of an extensive, planned collaboration with the Soviet Union can raise this struggle to the height of the revolutionary tasks.
<G-vec00169-001-s321><raise.bringen><de> Jedoch online sucht keine Art von Ergebnissen über Händler mit Sitz in Komoren oder spezialisierte Unternehmen leicht zugänglich für diese Versorgung bringen.
<G-vec00169-001-s321><raise.bringen><en> Nevertheless on-line searches do not raise any outcomes about suppliers based in Comoros or specialized firm available for this supply.
<G-vec00169-001-s322><raise.bringen><de> Eine Vielfalt von Sport- und Freizeitinhalten wird Ihren Urlaub auf eine höhere Ebene bringen.
<G-vec00169-001-s322><raise.bringen><en> A wealth of sports and entertainment facilities will raise your holiday to a higher level.
<G-vec00169-001-s323><raise.bringen><de> Jedoch im Internet sucht keine Art von Ergebnissen bezüglich Händler bringen mit Sitz in Guatemala oder spezialisierte Firma, die für diese Versorgung angeboten.
<G-vec00169-001-s323><raise.bringen><en> Nevertheless on-line searches do not raise any kind of results about distributors based in Guatemala or specialized firm available for this supply.
<G-vec00169-001-s324><raise.bringen><de> Jedoch im Internet Recherchen Ergebnisse über Händler mit Sitz in Mosambik oder spezialisierte Firma für diese Versorgung bringen nicht.
<G-vec00169-001-s324><raise.bringen><en> Nonetheless on-line searches do not raise any type of results concerning representatives based in Mozambique or specialized firm readily available for this supply.
<G-vec00169-001-s325><raise.bringen><de> Sie tragen zum Verständnis von Architektur bei und bringen diesem Berufsbild hoffentlich auch eine Wertschätzung entgegen.
<G-vec00169-001-s325><raise.bringen><en> They contribute to a general understanding of architecture and will, hopefully, raise the profile of the profession.
<G-vec00169-001-s326><raise.bringen><de> Dennoch im Internet bringen Recherchen Ergebnisse bezüglich Vertreter mit Sitz in South Georgia And The South Sandwich Islands oder spezialisierte Firma leicht zugänglich für diese Versorgung nicht.
<G-vec00169-001-s326><raise.bringen><en> Nonetheless on the internet searches do not raise any type of results about suppliers based in South Georgia And The South Sandwich Islands or specialized business readily available for this supply.
<G-vec00169-001-s327><raise.bringen><de> Dennoch im Internet bringen Suche Ergebnisse hinsichtlich Lieferanten mit Sitz in Paraguay oder spezialisierte Unternehmen leicht zugänglich für diese Versorgung nicht.
<G-vec00169-001-s327><raise.bringen><en> Nevertheless on-line searches do not raise any outcomes regarding suppliers based in Paraguay or specialist business offered for this supply.
<G-vec00169-001-s328><raise.bringen><de> "Auf der diesjährigen Welcomeparty wird Euch das Multitalent Maral mit ""The Best of Arabic Pop musikalisch verwöhnen und Eure Tanzbeine so richtig zum kochen und tanzen bringen."
<G-vec00169-001-s328><raise.bringen><en> "Multi-talent Maral will indulge you at this year's Welcome Party with ""the Best of Arabic Pop"" and really raise the heat on the dance floor!"
<G-vec00169-001-s329><raise.bringen><de> Wir sind froh, dass die Regierung den Besuch des Premierministers Zhu Rongji genutzt hat, um den Fall Ming zur Sprache zu bringen und die Bedenken Irlands bezüglich der Menschenrechtsverletzungen in China zu äußern.
<G-vec00169-001-s329><raise.bringen><en> We are glad that the Government used the opportunity of Premier Zhu Rongji's s visit to raise Ming's case and discuss Irish concerns about human rights violations in China.
<G-vec00169-001-s330><raise.bringen><de> Aber manchmal bringen internationale Kreditkarten-Unternehmen technische Hindernisse auf, wenn es darum geht Einzahlungen in Online Gaming Räumen vorzunehmen.
<G-vec00169-001-s330><raise.bringen><en> But sometimes, international credit card companies raise technical barriers to making deposits at online gaming rooms.
<G-vec00169-001-s331><raise.bringen><de> Aber trotz allem müssen wir die Durchführung dieser Reform in der nächsten Zeit gewährleisten, wenn wir tatsächlich das Land auf eine höhere Kulturstufe bringen wollen.
<G-vec00169-001-s331><raise.bringen><en> But we must, in spite of everything, carry out this reform in the very near future if we really intend to raise the country to a higher cultural level.
<G-vec00503-001-s177><reveal.bringen><de> Plenum II - MO-FR: Geleitete Großgruppe Täglich gruppenanalytisch orientierte Gross-Gruppe unter der Leitung von Catharina Mela/Griechenland und Ivan Urlic/Kroatien mit dem Ziel, die in den unterschiedlichen Gruppen gewonnenen Erfahrungen zu vergleichen, zu vertiefen und mit der Dimension aktueller sozialer und kollektiver Prozesse in Verbindung zu bringen.
<G-vec00503-001-s177><reveal.bringen><en> Each day an group analytic large group with Catharine Mela from Greece and Ivan Urlic from Croatia offering a space to deepen the experiences and results of the daily small and medium groups and to develop them further on to reveal its social and collective meaning for the world of today.
<G-vec00503-001-s178><reveal.bringen><de> Der aktuelle Wirbel um WikiLeaks bestätigt die Notwendigkeit, das Recht aller Medien zu verteidigen, die Wahrheit an die Öffentlichkeit zu bringen.
<G-vec00503-001-s178><reveal.bringen><en> The swirling storm around WikiLeaks today reinforces the need to defend the right of all media to reveal the truth.
<G-vec00503-001-s179><reveal.bringen><de> Die Polizei wollte ihn durch Folterungen dazu bringen, preiszugeben woher er das Material bekommen hätte.
<G-vec00503-001-s179><reveal.bringen><en> The police tried to make him reveal the source of his materials by torturing him.
<G-vec00503-001-s180><reveal.bringen><de> "Aber Krankheit und Kapital – als Imperialismus – bringen als Antagonismen jeder für sich den irren Rest bürgerlicher Innerlichkeit zum Vorschein, dessen ""Regulativ"" das haltlose Umschlagen der Gegensätze ineinander ist."
<G-vec00503-001-s180><reveal.bringen><en> "But illness and Capital – as Imperialism – reveal each by itself as antagonisms the mad residual of bourgeois interiority, whose ""regulator"" is the untenable turning of the opposites into one another."
<G-vec00503-001-s181><reveal.bringen><de> Meine Tiere bringen diese Leiden vor die menschlichen Augen.
<G-vec00503-001-s181><reveal.bringen><en> My animals reveal this suffering in front of human eyes.
<G-vec00503-001-s182><reveal.bringen><de> Auch weitere Nach- forschungen bringen keine zusätzlichen Erkenntnisse zu Tage, da sich niemand sonst in der Produktion an größere Ausfälle erinnern kann.
<G-vec00503-001-s182><reveal.bringen><en> Further enquiries do not reveal any additional information because no-one else in the Production Department can remember any significant interruptions to production.
<G-vec00503-001-s183><reveal.bringen><de> Da haben sie die Rechnung aber ohne Rebus' Hartnäckigkeit gemacht, der, unterstützt von seiner unersetzlichen Assistentin Siobhan Clarke,bis zum Schluss alles in seiner Macht Stehende tun wird, um die Wahrheit ans Licht zu bringen.
<G-vec00503-001-s183><reveal.bringen><en> But they should have known that this cop was tenacious: with the help of his dear colleague Shioban Clarke, he is going to do his utmost to reveal the truth.
<G-vec00503-001-s184><reveal.bringen><de> Man geht davon aus, dass GRAVITY, das bereits jetzt Hochpräzisionsmessungen des galaktischen Zentrums durchführt, nicht nur die Effekte der Allgemeinen Relativitätstheorie klar nachweisen wird, sondern auch, dass die Messungen es Astronomen ermöglichen werden, nach Abweichungen von der Allgemeinen Relativitätstheorie zu suchen, die eine gänzlich neue Physik zu Tage bringen könnten.
<G-vec00503-001-s184><reveal.bringen><en> Not only is GRAVITY, which is already making high-precision measurements of the Galactic Centre, expected to reveal the general relativistic effects very clearly, but also it will allow astronomers to look for deviations from general relativity that might reveal new physics. Notes
<G-vec00503-001-s185><reveal.bringen><de> "Um diese Eigenschaften ans Licht zu bringen und festzuhalten bedient sich Sylvie Blocher seit rund zehn Jahren der Videokunst, einer Technik, die ihr erlaubt, ""die Bilder in Bewegung zu setzen, um ihnen so das Wort zu geben""."
<G-vec00503-001-s185><reveal.bringen><en> "In order to reveal and fix these features, for the past ten years Sylvie Blocher, has been relying on video as a means to ""confer motion to the images and give them back the word""."
<G-vec00503-001-s186><reveal.bringen><de> In seine Wille die Eigenheit von den großen Böden und elsässische Grand Cru Weine an den Tag zu bringen, das Haus ist Stammmitglied des Vereins Alsace Crus et Terrois (ACT).
<G-vec00503-001-s186><reveal.bringen><en> In its will to reveal the peculiarity of famous soils and of Alsatian grand cru wines the house is permanent member of the Alsace Crus et Terroirs association (ACT).
<G-vec00503-001-s187><reveal.bringen><de> Falun Gong Praktizierende in Österreich gaben sich noch mehr Mühe, die Verfolgung der KPC von Falun Gong Praktizierenden den Vertretern verschiedener europäischer Länder zur Kenntnis zu bringen, um die Verfolgung so bald wie möglich zu beenden.
<G-vec00503-001-s187><reveal.bringen><en> Falun Gong practitioners in Austria made more efforts to reveal the CCP's persecution of Falun Gong practitioners to the representatives and people in Austria in order to stop the persecution as soon as possible.
<G-vec00503-001-s188><reveal.bringen><de> Sie steigen in das Labyrinth der Gänge und bringen schließlich einen einzigartigen Schatz ans Tageslicht...
<G-vec00503-001-s188><reveal.bringen><en> They climb into its labyrinth and finally reveal a unique treasure...
<G-vec00442-001-s114><bear.bringen><de> Im blauen Shirt mit Aufdruck der Stadt-Silhouette bringt der 28 cm große Teddybär Urlaubsgefühle aus Düsseldorf mit nach Hause.
<G-vec00442-001-s114><bear.bringen><en> Take holiday feelings home with you with the 28 cm tall Teddy bear wearing a blue shirt printed with the city skyline.
<G-vec00442-001-s115><bear.bringen><de> Leicht gefüttert und gepolstert, die jacke von kind Sailor Lowell verfügt über zwei große fronttaschen mit reißverschluss.Praktisch und funktionell, nicht eng, nicht band und bringt jegliche art von beschwerden an den träger, so dass die absolute bewegungsfreiheit.Vergossen und beständig, ist eine echte garantie für qualität und ist perfekt allen gelegenheiten des täglichen lebens.
<G-vec00442-001-s115><bear.bringen><en> Lightly lined and padded jacket, baby Sailor Lowell has two roomy front pockets with zip closure.Practical and functional, not tightening, not a band and does not bear any kind of discomfort to the wearer, allowing you to maintain complete freedom of movement.Resined and durable, is a real guarantee of quality and it is perfect in many occasions of everyday life.
<G-vec00442-001-s116><bear.bringen><de> 8 Bringt nun der Buße würdige Früchte; und beginnt nicht, bei euch selbst zu sagen: Wir haben Abraham zum Vater.
<G-vec00442-001-s116><bear.bringen><en> 8 Therefore bear fruits worthy of repentance, and do not begin to say to yourselves, 'We have Abraham as our father.'
<G-vec00442-001-s117><bear.bringen><de> Ein jeglicher Baum, der nicht gute Früchte bringt, wird abgehauen und ins Feuer geworfen.
<G-vec00442-001-s117><bear.bringen><en> Any tree which does not bear good fruits will be cut down and cast into the fire.
<G-vec00442-001-s118><bear.bringen><de> Sehen Sie, wenn wir einen Apfelkern aussäen, dann bekommen wir einen Apfelbaum; und dieser Apfelbaum bringt nach einiger Zeit Früchte, also Äpfel, für uns hervor.
<G-vec00442-001-s118><bear.bringen><en> You see, if we sow an apple seed, we will get an apple tree and from that apple tree, after a while it will bear apple fruits for us.
<G-vec00442-001-s119><bear.bringen><de> Hierin wird mein Vater verherrlicht, daß ihr viel Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s119><bear.bringen><en> In this is my Father glorified, that you bear much fruit; and so you will be my disciples.
<G-vec00442-001-s120><bear.bringen><de> Volk Gottes ist jenes Volk, das seine Früchte bringt - seit zweitausend Jahren.
<G-vec00442-001-s120><bear.bringen><en> God's people are those people who bear fruit – for all of the last two thousand years.
<G-vec00442-001-s121><bear.bringen><de> Wir beten, dass der ausgestreute Samen des Wortes Gottes bald Frucht bringt und nicht erstickt.
<G-vec00442-001-s121><bear.bringen><en> We pray that the Word that is being sowed will bear fruit soon and not die away.
<G-vec00442-001-s122><bear.bringen><de> Dagegen, so fuhr der Papst fort, indem er »das Gegenteil« davon hervorhob, sei »der Mann gesegnet, der auf den Herrn sich verlässt«, denn, wie in der Heiligen Schrift geschrieben stehe, »er ist wie ein Baum, der am Wasser gepflanzt ist und am Bach seine Wurzeln ausstreckt; Er hat nichts zu fürchten, wenn Hitze kommt; seine Blätter bleiben grün; auch in einem trockenen Jahr ist er ohne Sorge, unablässig bringt er seine Früchte«.
<G-vec00442-001-s122><bear.bringen><en> """But blessed is the man who trusts in the Lord"", the Pope continued. The prophet says of him: ""he is like a tree planted by water, that sends out its roots by the stream, and does not fear when heat comes, for its leaves remain green, and is not anxious in the year of drought, for it does not cease to bear fruit""."
<G-vec00442-001-s123><bear.bringen><de> Es ist aber keineswegs die freie Entscheidung einer solchen Gesellschaft, ob man es als sozial ebenbürtiges Prinzip erklärt, daß zum Beispiel zwei Männer sich eine Frau als Leihmutter nehmen, die dann für sie ein Kind zur Welt bringt, oder ob von zwei Frauen sich eine von einem Mann einen Samen einpflanzen läßt, damit die beiden Frauen dann auch ein Kind haben.
<G-vec00442-001-s123><bear.bringen><en> But it is not the free choice of such a society, if you explain it as a social principle of equal rank, for example, that two men take a woman to be a surrogate mother who will then bear a child for them, or whether one of two women gets planted in a seed from a man, so that the two women have a child.
<G-vec00442-001-s124><bear.bringen><de> Eine Feier kann vom äußerlichen Gesichtspunkt her einwandfrei, wunderschön sein, aber wenn sie uns nicht zur Begegnung mit Jesus Christus führt, dann besteht die Gefahr, dass sie unserem Herzen und unserem Leben keinerlei Nahrung bringt.
<G-vec00442-001-s124><bear.bringen><en> A celebration may be flawless on the exterior, very beautiful, but if it does not lead us to encounter Jesus Christ, it is unlikely to bear any kind of nourishment to our heart and our life.
<G-vec00442-001-s125><bear.bringen><de> Das tank-top von frau Lynette Deha nicht eng, nicht band und bringt jegliche art von beschwerden an den träger, so dass die erhaltung der bewegungsfreiheit .
<G-vec00442-001-s125><bear.bringen><en> The tank-top woman Dubbed Deha does not mark, does not end and does not bear any type of discomfort to the wearer, allowing you to preserve the maximum freedom of movement .
<G-vec00442-001-s126><bear.bringen><de> Hierin wird mein Vater verherrlicht, daÃ ihr viel Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s126><bear.bringen><en> Herein is my Father glorified, that ye bear much fruit; so shall ye be my disciples.
<G-vec00442-001-s127><bear.bringen><de> Der Text sagt dann weiter: »Ich habe euch dazu bestimmt, daß ihr euch aufmacht und Frucht bringt und daß eure Frucht bleibt.« Damit kehren wir zum Anfang zurück, zum Bild, zum Gleichnis des Weinstocks: er ist geschaffen, um Frucht zu bringen.
<G-vec00442-001-s127><bear.bringen><en> "Then, continuing, the text says: ""I chose you and appointed you that you should go and bear fruit and that your fruit should abide"". With this we return to the beginning, to the image, to the Parable of the Vine: it is created to bear fruit."
<G-vec00442-001-s128><bear.bringen><de> Wer in mir bleibt und in wem ich bleibe, der bringt reiche Frucht; denn getrennt von mir könnt ihr nichts vollbringen.
<G-vec00442-001-s128><bear.bringen><en> If a man remains in me and I in him, he will bear much fruit; apart from me you can do nothing.
<G-vec00442-001-s129><bear.bringen><de> 8 Hierin wird mein Vater verherrlicht, daß ihr viel Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s129><bear.bringen><en> 8 My Father is honored by this, that you bear much fruit and show that you are my disciples.
<G-vec00442-001-s130><bear.bringen><de> Wer in mir bleibt und ich in ihm, der bringt viel Frucht, denn getrennt von mir könnt ihr nichts tun.
<G-vec00442-001-s130><bear.bringen><en> If a man remains in me and I in him, he will bear much fruit; apart from me you can do nothing.
<G-vec00442-001-s131><bear.bringen><de> Da eine kurzzeitige Colistin-Inhalation keinerlei Risiken mit sich bringt, würde ich Sie darin bestärken, Ihre Tochter bei einem vorher geplanten Schwimmbadbesuch 24 Stunden vorher und für 48 Stunden nach dem Besuch mit Colistin inhalieren zu lassen.
<G-vec00442-001-s131><bear.bringen><en> As a short-term inhalation with colistin does not bear any risks, I would encourage you to have your daughter inhale colistin 24 hourse before and for 48 hours after visiting a swimming pool.
<G-vec00442-001-s132><bear.bringen><de> Mein Vater wird dadurch verherrlicht, dass ihr reiche Frucht bringt und meine Jünger werdet.
<G-vec00442-001-s132><bear.bringen><en> This is to my Father's glory, that you bear much fruit, showing yourselves to be my disciples.
<G-vec00060-001-s238><assert.bringen><de> Der Herrscher sprach Recht, traf sich mit den lokalen Herren und demonstrierte durch seinen Besuch den Willen, seine Herrschaft auch vor Ort zur Geltung zu bringen.
<G-vec00060-001-s238><assert.bringen><en> The ruler spoke the law, met with local lords and demonstrated through his visit the will to assert his leadership locally.
<G-vec00060-001-s239><assert.bringen><de> Die Nationalen Konsultation ist auch aus diesem Grund wichtig, nicht nur, damit ein Fragebogen ausgefüllt wird und sie diesen zurückschicken, sondern damit sie sich darüber unterhalten, damit sie eine Meinung darüber haben, und wir, Ungarn, alle schön langsam auf einen Nenner gelangen, und wenn wir auf einen Nenner gelangt sind, dann unsere Interessen zur Geltung bringen können.
<G-vec00060-001-s239><assert.bringen><en> This is another reason why the National Consultation is important: not only for people to complete a questionnaire and send it back, but that they talk about it, and form an opinion about it. This is for all us Hungarians to slowly but surely find a common denominator; and once we've found a common denominator, we can assert our interests.
<G-vec00060-001-s240><assert.bringen><de> Sie trägt Verantwortung für die Schöpfung und muss diese Verantwortung auch öffentlich zur Geltung bringen.
<G-vec00060-001-s240><assert.bringen><en> She has a responsibility towards creation, and must also publicly assert this responsibility.
<G-vec00060-001-s241><assert.bringen><de> Ich werde die Macht Meiner Lehren jenen mit beschränktem Denkvermögen zur Geltung bringen.
<G-vec00060-001-s241><assert.bringen><en> I shall assert the might of My Teachings upon those of limited mind.
<G-vec00179-001-s323><launch.bringen><de> In diesem Bereich liegt unsere Stärke in einem durchgängigen Ansatz, in kurzen Kommunikationswegen und in einer lockeren, offenen Umgebung, die es Apollo VredesteinÂ B.V. erlaubt, regelmäßig neue Produkte auf den Markt zu bringen.
<G-vec00179-001-s323><launch.bringen><en> Our strength in this regard lies in an integrated approach, short communication lines and an informal open culture that allows Apollo Vredestein B.V. to launch new products on a regular basis.
<G-vec00179-001-s324><launch.bringen><de> Mittlerweile scheint es so gut wie sicher, dass Samsung das Galaxy S10 im kommenden Jahr in mehr als nur zwei Versionen auf den Markt bringen wird.
<G-vec00179-001-s324><launch.bringen><en> Meanwhile, it seems almost certain that Samsung will launch more than two versions of the Galaxy S10 next year.
<G-vec00179-001-s325><launch.bringen><de> Im Laufe dieses Monats wird Bosch das Z-Wave Home Control Gateway auf den Markt bringen.
<G-vec00179-001-s325><launch.bringen><en> Later this month, Bosch will launch the Z-Wave Home Control Gateway.
<G-vec00179-001-s326><launch.bringen><de> Infolgedessen wird das Unternehmen keinen Nachfolger für Pixel Slate auf den Markt bringen.
<G-vec00179-001-s326><launch.bringen><en> Consequently, the company will not launch a successor for Pixel Slate.
<G-vec00179-001-s327><launch.bringen><de> „Ihr Ziel ist es nicht, als Erster einen Chatbot auf den Markt zu bringen, sondern einen Mehrwert für den Kunden zu bieten.
<G-vec00179-001-s327><launch.bringen><en> “Your goal is not to be the first to launch a chatbot, but to add value for your customer.
<G-vec00179-001-s328><launch.bringen><de> High 5 Casino wird auch in den kommenden Monaten neue Spiele für Facebook und mobile Plattformen auf den Markt bringen.
<G-vec00179-001-s328><launch.bringen><en> High 5 Casino will continue to launch new games on Facebook and mobile platforms in the months ahead.
<G-vec00179-001-s329><launch.bringen><de> Als Unternehmensstrategie ermöglicht es weltweit operierenden Unternehmen, als Team Produkte zu entwickeln, zu produzieren oder auf den Markt zu bringen, während gleichzeitig die Best Practices und die gewonnenen Erfahrungen erfasst werden.
<G-vec00179-001-s329><launch.bringen><en> As a corporate strategy, it allows globally operating companies to develop, manufacture, and launch products as a team, while ensuring that best practices and every bit of new knowledge gained are identified and documented.
<G-vec00179-001-s330><launch.bringen><de> Nach der Installation von in|FOCUS Bingo können Lotteriegesellschaften selbstständig eigene Bingo-Spiele entwerfen, konfigurieren und auf den Markt bringen.
<G-vec00179-001-s330><launch.bringen><en> Having installed in|FOCUS Bingo, lottery companies can configure, design and launch Bingo games completely on their own.
<G-vec00179-001-s331><launch.bringen><de> Außerdem werden seine chinesischen Konkurrenten wie Huawei und Xiaomi neue Flaggschiffe auf den Markt bringen (oder bereits aufgelegt), die günstiger sind als die aktuellen Angebote von Apple.
<G-vec00179-001-s331><launch.bringen><en> In addition, its Chinese competitors, such as Huawei and Xiaomi, will launch (or in the case of the latter, have already launched) new flagships, which are cheaper than the current Apple offers.
<G-vec00179-001-s332><launch.bringen><de> Hersteller haben somit die Möglichkeit, bereits während der Produktentwicklung Tests durchzuführen und ihr Mobiltelefon als Bestandteil der ITU-Whitelist auf den Markt zu bringen.
<G-vec00179-001-s332><launch.bringen><en> Thus, manufacturers have the possibility to conduct tests during the product development and to launch their mobile phones as listed in the ITU whitelist.
<G-vec00179-001-s333><launch.bringen><de> Nebst einer Ausweitung der Malzprodukte entstand ein Laboratorium und in der Folge eine pharmazeutische Abteilung, welche bald ebenfalls erfolgreiche Produkte auf den Markt bringen konnte.
<G-vec00179-001-s333><launch.bringen><en> Alongside an expansion of the malt product, a laboratory was built and in due course followed a pharmaceutical department that was soon also able to launch successful products.
<G-vec00179-001-s334><launch.bringen><de> In diesem Report geben PAC Analysten einen detaillierten Einblick in die Ergebnisse einer Mehrmandaten-Umfrage zum Thema Strategien in der Automobilbranche um Technologien und Services für das „vernetzte Auto (connected car)“ zu entwickeln und auf den Markt zu bringen (Februar 2015).
<G-vec00179-001-s334><launch.bringen><en> In this report, PAC analysts details the results of a multi-client survey looking at strategies of the automotive industry to develop and launch connected car technologies and services (February 2015).
<G-vec00179-001-s335><launch.bringen><de> Diese Kampagne ist ein notwenider Schritt für mich, damit ich die Vision dieses online-Programms schneller manifestieren und in ein paar Monaten auf den Markt bringen kann.
<G-vec00179-001-s335><launch.bringen><en> This campaign is a necessary step for me to manifest my vision of the online program and to launch it in a few months.
<G-vec00179-001-s336><launch.bringen><de> Im Jahr 2015 entschied sich LG, ein Smartphone aus dem Phablet-Sortiment als Alternative zum Flaggschiff G4 auf den Markt zu bringen, das unter denjenigen, die ein größeres Display bevorzugen, Erfolg hat.
<G-vec00179-001-s336><launch.bringen><en> In 2015, LG decided to launch a smartphone from the phablet range as an alternative to the flagship G4, which has enjoyed success among those who prefer a larger display.
<G-vec00179-001-s337><launch.bringen><de> Unser umfangreiches Wissen gründet sich auf mehr als zehn Jahren Erfahrung in SAR-Prüfungen und trägt nicht nur dazu bei, dass unsere Kunden Produkte mit Funktechnologie schnell und effizient auf den Markt bringen können, sondern vermeidet auch Produktrückrufe.
<G-vec00179-001-s337><launch.bringen><en> Our comprehensive expertise, based on more than 10 years of experience in SAR testing, not only helps our customers launch RF products quickly and efficiently, but also helps to eliminate the possibility of recalls.
<G-vec00179-001-s338><launch.bringen><de> Das Ergebnis dieser Umfrage zeigt, dass 66% der Kleinunternehmer ihre Geschäftsaussichten für die nächsten sechs Monate positiv bewerten, 35% von ihnen planen, ein neues Produkt auf den Markt zu bringen und 32% planen, neues Personal einzustellen.
<G-vec00179-001-s338><launch.bringen><en> The research revealed that 66% of small business owners feel more confident about their business prospects in the next six months, with 35% planning to launch a new product and 32% planning to hire more staff.
<G-vec00179-001-s339><launch.bringen><de> Ich verstärke Capital Games als Lead Producer, mit dem Fokus darauf, eng mit dem Team zusammenzuarbeiten, um ein neues Mobilspiel zu konzipieren, zu entwickeln und auf den Markt zu bringen.
<G-vec00179-001-s339><launch.bringen><en> I have joined Capital Games as Lead Producer with a focus on working closely with the team to identify, develop, and launch a new mobile game.
<G-vec00179-001-s340><launch.bringen><de> Während der südkoreanische Gigant Anfang dieses Jahres sein Galaxy S10 Premium-Sortiment auf den Markt brachte, ist Samsung bereit, heute Abend auf seiner Unpacked-Veranstaltung sein Galaxy Note-Flaggschiff-Smartphone der nächsten Generation, das Samsung Galaxy Note 10, auf den Markt zu bringen.
<G-vec00179-001-s340><launch.bringen><en> While the South Korean giant launched its Galaxy S10 premium lineup earlier this year, Samsung is ready to launch its next-generation Galaxy Note flagship smartphone, the Samsung Galaxy Note 10, at its Unpacked event tonight.
<G-vec00179-001-s341><launch.bringen><de> AMD wird voraussichtlich Anfang 4000 die Ryzen 2020 APU-Produktreihe für beide Gaming-Laptops sowie den günstigen Desktop-Bereich auf den Markt bringen.
<G-vec00179-001-s341><launch.bringen><en> AMD is expected to launch it’s Ryzen 4000 APU lineup for both gaming laptops as well as the budget desktop space in early 2020.
<G-vec00208-002-s043><confer.bringen><de> Probiotika sind als lebende Mikroorganismen definiert, die, wenn in angemessenen Mengen verabreicht, einen gesundheitlichen Nutzen bringen können.
<G-vec00208-002-s043><confer.bringen><en> Probiotics are defined as live microorganisms, which, when administered in adequate amounts, may confer a health benefit.
<G-vec00208-002-s044><confer.bringen><de> Einige Probiotika (lebende Mikroorganismen) können Patienten bei Verabreichung in ausreichender Menge einen gesundheitlichen Nutzen bringen.
<G-vec00208-002-s044><confer.bringen><en> Some probiotics (live micro-organisms) can confer a health benefit to the patient when administered in adequate amounts.
<G-vec00212-002-s095><make.bringen><de> Jetzt liegt es an Shrek, zusammen mit Fiona, Esel und dem Gestiefelten Kater seinen Fehler wiedergutzumachen, um seine Freunde zu retten, seine Welt wieder in Ordnung zu bringen und seine wahre Liebe wiederzufinden.
<G-vec00212-002-s095><make.bringen><en> Now it’s up to Shrek to get together with Fiona, Donkey and Puss in Boots in order to make up for his mistake, save his friends, put the world back the way it was and find his true love once more.
<G-vec00212-002-s096><make.bringen><de> Erklären Sie ihnen, dass das Ziel der OKRs ist, sie dazu zu bringen, sich nicht gut zu fühlen, wenn sie sich ehrgeizige Objectives setzen und diese verfehlen (solange sie Fortschritte machen).
<G-vec00212-002-s096><make.bringen><en> Explain to them that the purpose of the OKR is to also make them feel uncomfortable when they set ambitious goals and miss it (as long as they are making some progress).
<G-vec00212-002-s097><make.bringen><de> Sie können mindestens eine beliebte neue Maschine pro Jahr entwickeln und auf den Markt bringen.
<G-vec00212-002-s097><make.bringen><en> They can develop at lease one popular new machine in a year, and make it to the market.
<G-vec00212-002-s098><make.bringen><de> Deshalb sage ich euch: Solange es einen Agenten der Finsternis unter dem Volk Gottes gibt, wird er andere dazu bringen, ihre erste Liebe zu verlieren.
<G-vec00212-002-s098><make.bringen><en> That is why I am telling you that as long as there will be a single agent of darkness among the people of God, he is going to make others lose their first love.
<G-vec00212-002-s099><make.bringen><de> Die ausbleibende Übermittlung der personenbezogenen Daten kann jedoch die Unmöglichkeit der Abwicklung der Anfragen des Nutzers mit sich bringen.
<G-vec00212-002-s099><make.bringen><en> However, failure to provide personal data may make it impossible to fulfil the user's requests.
<G-vec00212-002-s100><make.bringen><de> Mitarbeiter mit 4 Pfoten: Balou Hunde sind gut fürs Betriebsklima, halten uns in Bewegung, fördern die Kommunikation und bringen uns zum Lachen.
<G-vec00212-002-s100><make.bringen><en> Employees with 4 paws: Charlie Dogs are good for the working environment; they keep us moving, promote communication and make us laugh.
<G-vec00212-002-s101><make.bringen><de> Das Ziel von Huntingtin-Verminderungsmedikamenten ist es, das mutierte Huntington-Gen davon abzuhalten, Zellen dazu zu bringen, ein schädliches Huntingtin-Eiweiß zu produzieren.
<G-vec00212-002-s101><make.bringen><en> The goal of huntingtin lowering therapies is to stop the HD mutation - found in the HD gene - from being used by cells to make the huntingtin protein
<G-vec00212-002-s102><make.bringen><de> Ehe du deine politische Kampagne planst, sollt du private und finanzielle Angelegenheiten in Ordnung bringen.
<G-vec00212-002-s102><make.bringen><en> Before you start to make preparations for your campaign, you should make sure that you have your other affairs all in line.
<G-vec00212-002-s103><make.bringen><de> Technisch reicht unser Ehrgeiz noch weiter: Wir wollen den Autopiloten auf die Straße bringen.
<G-vec00212-002-s103><make.bringen><en> Technologically, we want to go even further, and aim to make the autopilot ready for the road.
<G-vec00212-002-s104><make.bringen><de> Er benötigt dazu entsprechende Kompetenzen, um, wie in diesem Fall, das Angebot seiner Produkte zu bündeln, um es sehr schnell via Internet auf einen breiten Radar der Branche zu bringen.
<G-vec00212-002-s104><make.bringen><en> To do this the optician requires the relevant competences in order to, as in this case, bundle together the range of their products and to quickly make it available as broadly as possible to the industry.
<G-vec00212-002-s105><make.bringen><de> Er bekommt seinen Erguß und ein Saṅghādisesa obendrein, was zeigt, daß jemand anderen dazu zu bringen, die Anstrengung zu unternehmen, den Faktor der Anstrengung hier erfüllt.
<G-vec00212-002-s105><make.bringen><en> He gets his emission and a saṅghādisesa to boot, which shows that getting someone else to make the effort for one fulfills the factor of effort here.
<G-vec00212-002-s106><make.bringen><de> » Hier werden Konzepte präsentiert, die öffentlichen Räumen eine Seele geben, sie zum Sprechen bringen können.
<G-vec00212-002-s106><make.bringen><en> » Here concepts are presented which give a soul to public spaces and which can make them talk.
<G-vec00212-002-s107><make.bringen><de> Ich möchte daher jetzt Meine Anhänger bitten, jeden Tag ein Opfer zu bringen, das mit Leiden vergleichbar ist, um Mir zu helfen, Seelen, die sich zum Zeitpunkt ihres Todes während der Warnung in der Todsünde befinden, zu retten.
<G-vec00212-002-s107><make.bringen><en> I now want to ask My followers to make one sacrifice a day akin to suffering to help me save souls in mortal sin at the point of death during The Warning.
<G-vec00212-002-s108><make.bringen><de> Ich möchte Sie aufrütteln und zum Nachdenken bringen.
<G-vec00212-002-s108><make.bringen><en> think about your thoughts I want to make you think.
<G-vec00212-002-s109><make.bringen><de> Du bettest mit einer schlechteren Hand, um eine bessere Hand zum Folden zu bringen.
<G-vec00212-002-s109><make.bringen><en> You bet with a worse hand to make a better hand fold.
<G-vec00212-002-s110><make.bringen><de> Dabei ist es das Ziel, komplexe Systeme einfacher darzustellen und den Nutzer so schnell und effizient wie möglich an das Ziel seiner Wünsche zu bringen.
<G-vec00212-002-s110><make.bringen><en> The goal is to make complex systems easier to understand and to get the user to their destination as quickly and efficiently as possible.
<G-vec00212-002-s111><make.bringen><de> Saul aber gedachte, David durch die Hand der Philister zu Fall zu bringen.
<G-vec00212-002-s111><make.bringen><en> For Saul thought to make David fall by the hand of the Philistines.
<G-vec00212-002-s112><make.bringen><de> Erfreulicherweise kannst du die Schmerzen daheim unter Kontrolle bringen und das durch den Hernie verursachte Unbehagen durch Veränderungen deines Lebensstil lindern.
<G-vec00212-002-s112><make.bringen><en> Fortunately, you can manage the pain at home and make lifestyle changes to relieve some hernia discomfort. Steps
<G-vec00212-002-s113><make.bringen><de> Und Sie können die Stadt zum vibrieren bringen.
<G-vec00212-002-s113><make.bringen><en> And you can make it that the city vibrates.
<G-vec00218-002-s095><get.bringen><de> Die Bundeskanzlerin darf sich nicht von der ukrainischen Regierung vereinnahmen lassen, warnt die linksliberale Berliner Zeitung: "Sonst würde sie Deutschlands Rolle als wichtigster Vermittler in dieser Krise aufs Spiel setzen, der sowohl in Kiew als auch in Moskau Gehör findet und derzeit offenbar allein in der Lage ist, die Kontrahenten noch an einen Tisch zu bringen.
<G-vec00218-002-s095><get.bringen><en> The German chancellor must not be taken in by the Ukrainian government's manoeuvring, the left-liberal daily Berliner Zeitung warns: "Otherwise she would jeopardise Germany's role as the most important mediator in this crisis, listened to in both Kiev and Moscow and currently able to get the opposing sides to sit down at a table.
<G-vec00218-002-s096><get.bringen><de> Wenn Spammer genügend Personen dazu bringen, auf ihre Falschmeldungen zu klicken und ihre Seiten zu besuchen, nehmen sie über die dort angezeigten Werbeanzeigen Geld ein.
<G-vec00218-002-s096><get.bringen><en> If spammers can get enough people to click on fake stories and visit their sites, they’ll make money off the ads they show.
<G-vec00218-002-s097><get.bringen><de> Hier sind unsere Tipps, um das Gesicht in wenigen Minuten wieder zum Strahlen zu bringen.
<G-vec00218-002-s097><get.bringen><en> Here are our tips on how to get back your glow in a flash.
<G-vec00218-002-s098><get.bringen><de> Jedes Zimmer hat einen eigenen Holzofen, aber keinen Strom, um Sie so weit wie möglich wieder in die Natur zu bringen:-) Es gibt eine Gemeinschaftsküche und eine Lounge, die über Strom verfügen.
<G-vec00218-002-s098><get.bringen><en> Each room has its own wood-burning stove but no electricity, to get you back to nature as much as possible:-) There is a shared kitchen and lounge which do have electricity.
<G-vec00218-002-s099><get.bringen><de> Euro-Staaten verlieren einen Anreiz, ihre Haushalte in Ordnung zu bringen.
<G-vec00218-002-s099><get.bringen><en> Euro states are losing an incentive to get their budgets in order.
<G-vec00218-002-s100><get.bringen><de> Er wollte sie in ein Kloster in Nepal bringen.
<G-vec00218-002-s100><get.bringen><en> He wanted them to get to a monastery in Nepal.
<G-vec00218-002-s101><get.bringen><de> Nach einer Woche habe er sich dazu entschieden zu fliehen und seine Familie in Sicherheit zu bringen.
<G-vec00218-002-s101><get.bringen><en> After a week he decided to try and leave and get his family out.
<G-vec00218-002-s102><get.bringen><de> Bei einer Notfall-Reparatur, zum Beispiel weil die Umreifungsmaschine im Produktionsablauf eine entscheidende Rolle spielt, reagiert TITAN sofort und mit höchster Priorität, um Ihre Maschine wieder zum Laufen zu bringen.
<G-vec00218-002-s102><get.bringen><en> If an emergency repair is required, because e.g. a strapping machine is essential for the production, TITAN gives instant and highest priority help to get your machine up and running again.
<G-vec00218-002-s103><get.bringen><de> Seine Klassenkameraden an der Tamo Landwirtschaftsschule bringen ihn schließlich dazu, sein Zimmer zu verlassen und wieder am Unterricht teilzunehmen, doch zur Verwunderung aller kommt Kusakabe Yuka mit ihrem bürgerlichen Namen Kinoshita Ringo als neue Schülerin in ihre Klasse.
<G-vec00218-002-s103><get.bringen><en> His classmates at the Tamo Agriculture School finally are able to get him to leave his room and attend his class, but to everyone's amazement, Kusakabe Yuka (her stage name) comes into the class under the name Kinoshita Ringo as a transfer student.
<G-vec00218-002-s104><get.bringen><de> Jetzt war mein einziges Problem, ihr das Geld zu bringen ohne ihr Wissen wo und von dem es kam.
<G-vec00218-002-s104><get.bringen><en> Now my only problem was to get the money to her without her knowing where and who it came from.
<G-vec00218-002-s105><get.bringen><de> NEUHEITEN & DEMNÄCHST Die aktuellen Styles und Neuheiten, um Sie nach draußen zu bringen.
<G-vec00218-002-s105><get.bringen><en> The latest styles and new arrivals to inspire you to get outdoors.
<G-vec00218-002-s106><get.bringen><de> Selbstredend hat der Nerd die Seite der Textildrucker mit seinem WordPress SEO im Ranking danach auch nach oben bringen können.
<G-vec00218-002-s106><get.bringen><en> Self-evidently the nerd could get the site of the textile printers in the top ranking with this WordPress.
<G-vec00218-002-s107><get.bringen><de> Sie schmecken zwar super und sind perfekt geeignet um eine Party in Schwung zu bringen, stecken jedoch häufig voller Zucker und Kalorien.
<G-vec00218-002-s107><get.bringen><en> While tasty and a great way to get a party going, they have a tendency to be brimming with sugars and calories.
<G-vec00218-002-s108><get.bringen><de> Ganz gleich, welches Problem Sie erleben – Speicherlecks durch ineffektive Algorithmen, Fragen mit Performance oder Datenlokalisierung oder etwas anderes – wir bringen Ihre Spark-Anwendung wieder auf die Schiene.
<G-vec00218-002-s108><get.bringen><en> No matter what problem you experience – memory leaks due to ineffective algorithms, performance or data locality issues or something else – we’ll get your Spark application back on the rails.
<G-vec00218-002-s109><get.bringen><de> Kurz vor der Abfahrt werden die Sardinen mit einem Sonarsystem lokalisiert und es wird diskutiert, welche Faktoren wichtig sind, damit die Männer einen guten Fang nach Hause bringen können.
<G-vec00218-002-s109><get.bringen><en> Shortly in advance the schools of sardines get located using a sonar system and any conditions that might tribute to the catch of the day are being checked out.
<G-vec00218-002-s110><get.bringen><de> Den Wagon ins Rollen zu bringen ist aber mit Kraft verbunden.
<G-vec00218-002-s110><get.bringen><en> To get the wagon rolling is however connected with force.
<G-vec00218-002-s111><get.bringen><de> Wir werden Ihnen jedoch keine Verbindung herstellen, da wir in Frage stellen, dass diese Pillen Ihnen die gewünschten Ergebnisse bringen.
<G-vec00218-002-s111><get.bringen><en> But, we aren’t going to give you the link because we just don’t think these pills can get you the results you want.
<G-vec00218-002-s112><get.bringen><de> Die Reise auf der hohen See kann gefährlich sein, sie kann sich aber auch lohnen – im Spiel stehen eine große Anzahl verschiedener Schiffe mit einzigartigen Eigenschaften, Stärken und Schwächen zur Verfügung, um dich aufs Meer zu bringen.
<G-vec00218-002-s112><get.bringen><en> Travel on the high seas can be both dangerous and rewarding, and the game provides a range of ships with unique features – as well as strengths and weaknesses – to get you out on the water. Rowboat
<G-vec00218-002-s113><get.bringen><de> Eine komplett erneuerte Innenausstattung aus Leder, versehen mit modernster Elektronik, und ein Fuel-Injected 4.0 Liter V6-Motor, gekoppelt mit einer manuellen 5-Gangschaltung, bringen die Dinge ins Rollen.
<G-vec00218-002-s113><get.bringen><en> A new leather interior with modern electronics and a fuel-injected 4.0-liter V6 mated to a 5speed manual get it moving.
<G-vec00227-002-s193><stride.bringen><de> Karussell fahren, tagelang: Der Uhrenbeweger simuliert Alltagsstrapazen – NOMOS-Uhren müssen hier beweisen, dass sie sich von Rotationen nicht aus dem Tritt bringen lassen.
<G-vec00227-002-s193><stride.bringen><en> This carousel goes round and round, and then round again: The watch spinner simulates the strains of everyday life—NOMOS watches have to prove that the revolutions do not knock them off their stride.
<G-vec00241-002-s129><bear.bringen><de> Wer in mir bleibt und ich in ihm, der bringt viel Frucht; denn getrennt von mir könnt ihr nichts tun.
<G-vec00241-002-s129><bear.bringen><en> If a man remains in me and I in him, he will bear much fruit; apart from me you can do nothing.
<G-vec00241-002-s130><bear.bringen><de> Sie müssen bedenken, dass der Kauf von Weihnachtsdekoration über Internet eine andere Geschäftserfahrung mit sich bringt, als der Kauf in einem physischen Laden.
<G-vec00241-002-s130><bear.bringen><en> You should bear in mind that buying Christmas ornaments over the internet provides a different shopping experience to buying in-store.
<G-vec00241-002-s131><bear.bringen><de> Im Sutra „Tune of Brahma“ finden sich zehn Punkte, die erklären, welche karmischen Vorteile eine solche Handlung mit sich bringt.
<G-vec00241-002-s131><bear.bringen><en> In the sutra ‚Tune of Brahma’ one finds ten points, which describe the karmic advantages that such actions bear.
<G-vec00241-002-s132><bear.bringen><de> Bekannt sind die Gefahrenpotentiale von hochenergetischer und gebündelter Strahlung bei Laserprodukten, doch auch moderne LED-Beleuchtung bringt Gefahren für den menschlichen Körper mit sich.
<G-vec00241-002-s132><bear.bringen><en> The potential dangers of high-powered and bundled laser radiation are well known. But even modern LED lighting can bear dangers for the human body.
<G-vec00241-002-s133><bear.bringen><de> 2 Jede Rebe an mir, die keine Frucht bringt, schneidet er ab und jede Rebe, die Frucht bringt, reinigt er, damit sie mehr Frucht bringt.
<G-vec00241-002-s133><bear.bringen><en> 2 Every branch in me that does not bear fruit he takes away, and every one that bears fruit he cleanses, that it may bear more fruit.
<G-vec00241-002-s134><bear.bringen><de> 8 Hierin wird5 mein VaterVater verherrlicht, dass ihr viel Frucht bringt, und ihr werdet meine6 JüngerJünger werden.
<G-vec00241-002-s134><bear.bringen><en> John 15:8: Herein is my Father glorified, that ye bear much fruit; so shall ye be my disciples.
<G-vec00241-002-s136><bear.bringen><de> Wer in mir bleibt und ich in ihm, der bringt viel Frucht; denn ohne mich könnt ihr nichts tun.
<G-vec00241-002-s136><bear.bringen><en> If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing.
<G-vec00241-002-s137><bear.bringen><de> Der Glaube ist aber ein Geschenk, das uns gegeben wird, damit wir es teilen; er ist ein Talent, das wir empfangen haben, damit es Frucht bringt; er ist ein Licht, das nicht verborgen bleiben darf, sondern das ganze Haus erleuchten soll.
<G-vec00241-002-s137><bear.bringen><en> However, faith is a gift that is given to us to be shared; it is a talent received so that it may bear fruit; it is a light that must never be hidden, but must illuminate the whole house.
<G-vec00241-002-s138><bear.bringen><de> 18 Es ist nicht möglich, dass ein guter Baum schlechte Früchte bringt und auch nicht, dass ein schlechter Baum gute Früchte bringt.
<G-vec00241-002-s138><bear.bringen><en> A good tree cannot bear bad fruit, and a bad tree cannot bear good fruit.
<G-vec00241-002-s140><bear.bringen><de> 8Wenn ihr viel Frucht bringt und euch so als meine Jünger erweist, wird die Herrlichkeit meines Vaters sichtbar.
<G-vec00241-002-s140><bear.bringen><en> 8My Father is glorified by this, that you bear much fruit, and so prove to be My disciples.
<G-vec00241-002-s142><bear.bringen><de> Jede Rebe an mir, die keine Frucht bringt, nimmt er weg; jede aber, die Frucht bringt, reinigt er, damit sie mehr Frucht bringt.
<G-vec00241-002-s142><bear.bringen><en> Every branch in Me that does not bear fruit, He takes away; and every branch that bears fruit, He cleanses it so that it may bear more fruit.
<G-vec00241-002-s145><bear.bringen><de> Wandern und die Natur von ihrer schönsten Seite erleben: Ideal für Jung und Alt ist das Naturparkhaus Fanes-Sennes-Prags, ein Museum das die Entstehung der Dolomiten oder Spannendes über den Höhlenbären von Conturines näher bringt.
<G-vec00241-002-s145><bear.bringen><en> The Fanes-Sennes-Braies Nature Park hut is ideal for all ages: a museum which recounts the rise of the Dolomites and the exciting story of the Ursus ladinicus, an ancient indigenous cave bear species.
<G-vec00241-002-s147><bear.bringen><de> 2 Eine jeglich Rebe an mir, die nicht Frucht bringt, wird er wegnehmen; und eine jegliche, die da Frucht bringt, wird er reinigen, daß sie mehr Frucht bringe.
<G-vec00241-002-s147><bear.bringen><en> 2 He takes away every branch in me that doesn’t bear fruit, and He prunes every branch that bears fruit, so that it may bear more fruit.
<G-vec00241-002-s152><carry.bringen><de> Mit einer gewissen Befriedigung dachte ich daran, daß genug Gin im Hause versteckt war, um mich durch die Nacht und über den nächsten Tag zu bringen.
<G-vec00241-002-s152><carry.bringen><en> With a certain satisfaction I reflected there was enough gin concealed about the house to carry me through that night and the next day.
<G-vec00241-002-s153><carry.bringen><de> Die niederländischsprachigen Medien bringen die Nachrichten im Radio und Fernsehen, in Zeitungen und Zeitschriften auf Niederländisch.
<G-vec00241-002-s153><carry.bringen><en> The Dutch-language media carry news broadcasts in Dutch on radio and TV, in newspapers and magazines.
<G-vec00241-002-s154><carry.bringen><de> Als die Arbeiter des GM-Werkes in Indianapolis gegen einen Tarifvertrag stimmten, durch den die Löhne gekürzt worden wären, und die UAW-Funktionäre dafür kritisierten, ihn akzeptiert zu haben, organisierte die SEP ein Basiskomitee, um die Rebellion vorwärts zu bringen.
<G-vec00241-002-s154><carry.bringen><en> When workers at the Indianapolis GM plant voted down a wage-cutting deal and denounced UAW officials for accepting it, the SEP organized a rank-and-file committee to carry forward the rebellion.
<G-vec00241-002-s155><carry.bringen><de> 8 Lifte bringen die Teilnehmer zwischen den Abfahrten immer wieder auf die Berge, nur in Richtung Tal kann wichtige Zeit gutgeschrieben werden.
<G-vec00241-002-s155><carry.bringen><en> Eight lifts will carry them back up into the mountains between the descents, and time can only be credited on the valley runs.
<G-vec00241-002-s156><carry.bringen><de> Überblick Die hochkomplexe technische Ausstattung von Data Centern und anderen IT-Bereichen und die dort eingesetzten Materialien bringen ein besonders hohes Brandrisiko mit sich.
<G-vec00241-002-s156><carry.bringen><en> Overview The highly complex technical equipment of data centers and other IT areas, as well as the materials used there, carry a particularly high risk of fire.
<G-vec00241-002-s157><carry.bringen><de> 23:19 Das Erstling von der ersten Frucht auf deinem Felde sollst du bringen in das Haus des HERRN, deines Gottes.
<G-vec00241-002-s157><carry.bringen><en> 23:19 Thou shalt carry the firstfruits of the corn of thy ground to the house of the Lord thy God.
<G-vec00241-002-s158><carry.bringen><de> 3Wenn ich aber gekommen bin, will ich die, die ihr für bewährt haltet, mit Briefen senden, damit sie eure Gabe nach Jerusalem bringen.
<G-vec00241-002-s158><carry.bringen><en> 3 When I arrive, I will send whoever you approve with letters to carry your gracious gift to Jerusalem.
<G-vec00241-002-s159><carry.bringen><de> Wir möchten darauf hinweisen, dass wir in unserem Haus keinen Lift haben - aber selbstverständlich helfen wir Ihnen sehr gerne Ihr Gepäck in Ihr Zimmer oder Apartment zu bringen.
<G-vec00241-002-s159><carry.bringen><en> We want to inform, that we don't have an elevator - but of course we can help to carry your luggage into your room.
<G-vec00241-002-s160><carry.bringen><de> Der erste Hafen dient Fähren, die Passagiere auf die Inseln bringen.
<G-vec00241-002-s160><carry.bringen><en> The first port is for the ferry boats that carry passengers to the islands.
<G-vec00241-002-s161><carry.bringen><de> Bitte ihn ganz süß und ruhig darum, deine Bücher oder deinen Rucksack in das nächste Unterrichtszimmer zu bringen.
<G-vec00241-002-s161><carry.bringen><en> Calmly and sweetly ask him to carry your books or your backpack for you to the next class.
<G-vec00241-002-s162><carry.bringen><de> Es ist den Passagieren verboten, in jeglicher Art und Weise Waffen jeder Art und gefährliche Substanzen, wie Sprengstoffe, Gas, Treibstoffe oder andere entzündbare Substanzen, an Bord zu bringen.
<G-vec00241-002-s162><carry.bringen><en> It is strictly forbidden to carry any kind of weapon or dangerous materials like explosives, gas, gasoline or other inflammable substances.
<G-vec00241-002-s163><carry.bringen><de> Beide Wahlen bringen Konsequenzen mit sich, über die Sie Bescheid wissen sollten.
<G-vec00241-002-s163><carry.bringen><en> Both choices carry their own set of consequences that you will need to know about.
<G-vec00241-002-s164><carry.bringen><de> Meister rühren nicht an äußeren Kennzeichen, wenn sie kommen, Die äußeren Kennzeichen bringen ihre eigenen Bräuche, ihre eigene Art zu leben mit sich, je nach den klimatischen Einflüssen.
<G-vec00241-002-s164><carry.bringen><en> So Masters do not touch the outer labels when they come. The outer labels carry with them their own customs, their own ways of living and climatic influences.
<G-vec00241-002-s165><carry.bringen><de> Risikohinweis CFDs und Forex sind Produkte mit Hebelwirkung, die ein hohes Risiko für Ihr Kapital mit sich bringen, so dass Sie möglicherweise mehr als Ihre ursprüngliche Investition verlieren können.
<G-vec00241-002-s165><carry.bringen><en> CFDs and Forex are leveraged products and carry a high degree of risk to your capital and it is possible to lose more than your initial investment.
<G-vec00241-002-s166><carry.bringen><de> Wenn nun unsere Pflanze durch diesen Process der bestän-digen Erhaltung oder der natürlichen Auswahl immer gesuchtererBlüthen für die Insecten sehr anziehend geworden ist, so wer-den diese, ihrerseits ganz unabsichtlich, regelmäßig Pollen vonBlüthe zu Blüthe bringen: und dass sie dies sehr wirksamzu thun vermögen, konnte ich durch viele auffallende Beispielebelegen.
<G-vec00241-002-s166><carry.bringen><en> When our plant, by this process of the continued preservation or natural selection of more and more attractive flowers, had been rendered highly attractive to insects, they would, unintentionally on their part, regularly carry pollen from flower to flower; and that they can most effectually do this, I could easily show by many striking instances.
<G-vec00241-002-s167><carry.bringen><de> Dabei fängt die Scheibe recht viel versprechend an: Human Being Human und Warmonger bringen eine gute Energie mit sich, die sich teilweise in den räudigen Entombed Gefilden aufhält.
<G-vec00241-002-s167><carry.bringen><en> By the way, Untrue starts very promising: Human Being Human and Warmonger carry a satisfying energy that stays near to Entombed’s mangy sound.
<G-vec00241-002-s168><carry.bringen><de> Schwungvoll aufgetragene Farben und Linien, die die Gemälde durchziehen, bringen Spannung in die nicht gegenständliche Kunst.
<G-vec00241-002-s168><carry.bringen><en> Sweepingly applied colors and lines that run throughout the paintings, carry the tension to non-representational art.
<G-vec00241-002-s169><carry.bringen><de> Von high-tech Fischereifahrzeugen bis hin zu kleinen Booten aus dem Familienbetrieb bringen alle frischen Fisch in den Hafen.
<G-vec00241-002-s169><carry.bringen><en> Everything from high tech fishing vessels to small family boats carry fresh fish into the harbour.
<G-vec00241-002-s170><carry.bringen><de> Leider bringen die Gezeiten nicht nur gute Dinge in das Wattenmeer.
<G-vec00241-002-s170><carry.bringen><en> Unfortunately, the tides don’t carry only good things for the wadden region.
<G-vec00243-002-s339><trouble.bringen><de> Dass ich mich mit anderen anfreunden sollte, die mich nicht in Schwierigkeiten bringen.
<G-vec00243-002-s339><trouble.bringen><en> That I should make other friends that won’t get me into trouble.
<G-vec00243-002-s340><trouble.bringen><de> Wie mein Freund Heinz Kabutz sehr schön in seinem Newsletter (Issue 255) aufgezeigt hat, kann es uns in Schwierigkeiten bringen, wenn wir Methoden einer bestimmten Implementierung auf einer Referenzvariable eines abgeleiteten Typs aufrufen.
<G-vec00243-002-s340><trouble.bringen><en> As my friend Heinz Kabutz pointed out in issue 255 of his newsletter, it may get us into trouble when we call methods of a certain implementation on a reference variable of an inferred type.
<G-vec00243-002-s341><trouble.bringen><de> Dies kann Sie in ernsthafte Schwierigkeiten bringen.
<G-vec00243-002-s341><trouble.bringen><en> This can land you in serious trouble.
<G-vec00243-002-s342><trouble.bringen><de> Meine Vergangenheit blitzte vor mir auf, außerhalb meiner Kontrolle Ich lernte keine dummen Sachen zu tun, die dich in Schwierigkeiten bringen, und dein Leben auf den Kopf stellen.
<G-vec00243-002-s342><trouble.bringen><en> My past flashed before me, out of my control I learned to not do stupid things that get you in trouble and screw up your life.
<G-vec00243-002-s343><trouble.bringen><de> Um meinen Mann nicht in Schwierigkeiten zu bringen, stimmte ich der Scheidung zu und schrieb, dass er unser Eigentum haben könne.
<G-vec00243-002-s343><trouble.bringen><en> In order to not get him into trouble, I agreed to the divorce and said that our property belonged to him.
<G-vec00243-002-s344><trouble.bringen><de> Begehen Sie keinen groben Fehler, der uns beide in Schwierigkeiten bringen könnte.
<G-vec00243-002-s344><trouble.bringen><en> Don’t commit any blunder that might land us both into trouble.
<G-vec00243-002-s345><trouble.bringen><de> Diese Karten könnten möglicherweise eine Straße oder ein Flush bilden, sie können Sie aber auch in Schwierigkeiten bringen.
<G-vec00243-002-s345><trouble.bringen><en> These have the potential to make both straights and flushes, but can get you into trouble.
<G-vec00243-002-s346><trouble.bringen><de> In bestimmten Ländern können Blog Posts, die die Regierung kritisieren oder anderweitig "beleidigend" sind, dich in Schwierigkeiten bringen.
<G-vec00243-002-s346><trouble.bringen><en> Also, in certain countries, blog posts that are critical of the government or otherwise "offensive" could get you into serious trouble.
<G-vec00243-002-s347><trouble.bringen><de> Diese Art mentaler Sprünge werden dich in Schwierigkeiten bringen und dafür sorgen, dass du erklären kannst, wie die Welt funktioniert, indem du sie einfach anschaust und deine eigenen Schlüsse ziehst.
<G-vec00243-002-s347><trouble.bringen><en> That kind of mental leap will land you in trouble and cause you to think that you can confirm how the world works simply by looking at it and relying on your own assumptions.
<G-vec00243-002-s348><trouble.bringen><de> Legen Sie ein eindeutiges Kennwort fest, damit Ihre Kinder keinen Zugriff auf die „Hauptsteuerung“ der App haben, um die vorhandenen Einschränkungen zu umgehen, wobei sie sich in Schwierigkeiten bringen und auf anstößige Inhalte stoßen könnten.
<G-vec00243-002-s348><trouble.bringen><en> Set a unique a password so that your children cannot have access to the "master controls" of the app to bypass the restrictions you have in place and put themselves into trouble and access inappropriate content.
<G-vec00243-002-s349><trouble.bringen><de> Es wird von vielen angenommen, dass Michelangelo Brutus verwendete, als eine Möglichkeit seine Unzufriedenheit mit den herrschenden Mächten des Florenz jener Zeit auszudrücken, aber ohne dabei so offenkundig zu sein, um sich selbst nicht in Schwierigkeiten zu bringen.
<G-vec00243-002-s349><trouble.bringen><en> It is believed by many that Michelangelo used Brutus as a way of indicating his displeasure with the ruling powers of Florence at the time, but without being so blatant as to get himself into trouble.
<G-vec00243-002-s350><trouble.bringen><de> Die Online-Präsenz von Teenagern kann sie wirklich in Schwierigkeiten bringen.
<G-vec00243-002-s350><trouble.bringen><en> The online presence of teens really can put them into real trouble.
<G-vec00243-002-s351><trouble.bringen><de> Das Hacken deiner PSP könnte dein System beschädigen oder dich in Schwierigkeiten bringen.
<G-vec00243-002-s351><trouble.bringen><en> Hacking your PSP could damage your system or get you into trouble.
<G-vec00243-002-s352><trouble.bringen><de> Aber betatsche ihn nicht aufdringlich, das könnte er falsch auffassen, und es könnte dich in Schwierigkeiten bringen.
<G-vec00243-002-s352><trouble.bringen><en> Be sure not touch him in inappropriate ways, this could definitely send the wrong message, and it possibly will get you in deep trouble.
<G-vec00243-002-s353><trouble.bringen><de> Es war so schwer für uns, blutende Menschen zurückzulassen und wegzuziehen, aber wir konnten uns auch nicht in Schwierigkeiten bringen.
<G-vec00243-002-s353><trouble.bringen><en> It was so hard for us to leave bleeding people and move away but also we couldn’t put ourselves into trouble.
<G-vec00246-002-s258><raise.bringen><de> Bahnbrechende Funktionen, die das Erlebnis mit der Serie 7000 Pro auf eine neue Ebene bringen.
<G-vec00246-002-s258><raise.bringen><en> Revolutionary features that raise the 7000 Pro series experience to the next level.
<G-vec00246-002-s259><raise.bringen><de> Die Erfahrung zeigt, dass Alarme von Videoanlagen, die häufige Falschalarme bringen, irgendwann nicht mehr vom Personal einer Videosicherheitszentrale beachtet werden.
<G-vec00246-002-s259><raise.bringen><en> Experience shows that the security staff of video monitoring centres will eventually no longer respond to alarms raised by video systems that frequently raise false alarms.
<G-vec00246-002-s260><raise.bringen><de> Sie vermitteln in Konflikten, bringen Anliegen benachteiligter Menschen an die Öffentlichkeit, begleiten ehemalige Soldaten auf ihrem Weg ins zivile Leben, arbeiten mit traumatisierten Opfern von Gewalt oder ermöglichen die konfliktsensible Reintegration von Flüchtlingen.
<G-vec00246-002-s260><raise.bringen><en> Its specially trained experts mediate in conflicts, raise public awareness of the concerns of disadvantaged groups, help ease former combatants back into civilian life, work with traumatised victims of violence, and enable refugees to return to their homes.
<G-vec00246-002-s261><raise.bringen><de> Schon der Abriss des Technischen Rathauses in Frankfurt wird späteren Generationen vielleicht noch die Erkenntnis bringen, wie richtungslos und öde die Entwürfe sind, die uns anstelle des brutalistischen Gebäudekomplexes erwarten.
<G-vec00246-002-s261><raise.bringen><en> Perhaps the demolition of the Technical Town Hall in Frankfurt will still help to raise awareness among future generations of how tedious and aimless these designs, just waiting to replace these Brutalist building complexes, truly are.
<G-vec00246-002-s262><raise.bringen><de> # Russian Helicopters Trotz der Krise der Hubschrauberindustrie, die in den 90er Jahren entstand, gelang es der Staatskorporation Rostec nicht nur diese Linie der Produktion zu beleben, sondern auch sie in eine führende Position zu bringen.
<G-vec00246-002-s262><raise.bringen><en> Despite a crisis in the helicopter-building industry, which first developed in the 1990s, the state corporation Rostec has managed not only to revive its production, but also to raise it to a leading position.
<G-vec00246-002-s264><raise.bringen><de> Mit vier Höheneinstellungen kannst du dein Display auf eine individuelle ergonomische Sichthöhe bringen, um noch komfortabler zu arbeiten.
<G-vec00246-002-s264><raise.bringen><en> Four height settings mean you can raise your display to a customized ergonomic viewing height for added comfort while you work.
<G-vec00246-002-s265><raise.bringen><de> Die Stipendiaten vermitteln mit ihren innovativen Projekten ein aktuelles Deutschlandbild und bringen Menschen deutsche Kultur näher.
<G-vec00246-002-s265><raise.bringen><en> The fellows convey an image of contemporary Germany in the host country through innovative projects and raise the interest of the local population in German culture.
<G-vec00246-002-s266><raise.bringen><de> Kiwanis-Mitglieder veranstalten nahezu 150.000 Serviceprojekte, leisten mehr als sechs Millionen Servicestunden und bringen jährlich fast 107 Millionen USD für Gemeinden, Familien und Projekte auf.
<G-vec00246-002-s266><raise.bringen><en> Members stage nearly 150,000 service projects and raise nearly US$100 million every year for communities, families and projects.
<G-vec00246-002-s267><raise.bringen><de> Richten Sie die Arme aus, um in die Ausgangsposition zurückzukehren, und bringen Sie Ihr linkes Knie zum linken Ellenbogen, während Sie sich durch den Kern quetschen.
<G-vec00246-002-s267><raise.bringen><en> Maintain a backwards-pelvic tilt and raise shoulder blades off the ball, return to the starting position, and repeat. NECK FLEXION
<G-vec00246-002-s268><raise.bringen><de> Ab und an lässt sich auch Superstar Paul von Dyk blicken, um das Hochhaus zum Beben zu bringen.
<G-vec00246-002-s268><raise.bringen><en> Every now and then, superstar Paul von Dyk also puts in an appearance to really raise the roof.
<G-vec00246-002-s269><raise.bringen><de> In Gesprächen mit Entscheidungsträger*innen aus Politik und Gesellschaft bringen wir auf den Tisch, was der jungen Generation auf den Nägeln brennt.
<G-vec00246-002-s269><raise.bringen><en> In talks with decision-makers in politics and civil society, we raise the burning issues that the young generation faces.
<G-vec00246-002-s271><raise.bringen><de> Zweck meines Besuchs in Deutschland ist, diese Beziehungen auf höheres Niveau zu bringen sowie neue Maßnahmen für ihre Erweiterung und Vertiefung zu unternehmen.
<G-vec00246-002-s271><raise.bringen><en> My goal in visiting Germany is to raise these contacts to much a higher level, deepen and expand them, and take new steps for their development.
<G-vec00246-002-s272><raise.bringen><de> Bringen Sie Ihre Kenntnisse über HP Converged Infrastructure auf ein neues Niveau.
<G-vec00246-002-s272><raise.bringen><en> Raise your understanding of HP Converged Infrastructure to a new level.
<G-vec00246-002-s273><raise.bringen><de> Wir möchten nur zeigen, dass der Islam viele Elemente umfasst, die Moslems in Konflikt mit den Normen der belgischen Gesellschaft bringen können.
<G-vec00246-002-s273><raise.bringen><en> By our actions, we wish merely to demonstrate that Islam entails a host of elements that may well raise conflicts between Muslims and the norms governing Belgian society.
<G-vec00246-002-s274><raise.bringen><de> Außerdem zeige ich, welche neuen Probleme domänenspezifische Modellierungssprachen für das Modellmanagement mit sich bringen, und wie mit diesen verfahren wird.
<G-vec00246-002-s274><raise.bringen><en> On the counter side we look at what new problems Domain-Specific Modeling Languages raise for model management, and how to address them.
<G-vec00246-002-s275><raise.bringen><de> Diese bringen das Material in kürzester Zeit auf die gewünschte Umformtemperatur.
<G-vec00246-002-s275><raise.bringen><en> These raise the temperature of the material to the right forming temperature in a very short time.
<G-vec00246-002-s276><raise.bringen><de> Mit ihren Vasallen des Völkerbundes und ihren japanischen und amerikanischen Bundesgenossen wird die weltbeherrschende englische Bourgeoisie, von innen und außen angegriffen, durch koloniale Aufstände und Befreiungskriege in ihrer Weltmacht bedroht, durch Streik und Bürgerkrieg im Innern gelähmt, alle Kräfte anstrengen müssen und Söldnerheere gegen beide Feinde auf die Beine bringen müssen.
<G-vec00246-002-s276><raise.bringen><en> With its vassals in the League of Nations and its American and Japanese allies, the world-ruling English bourgeoisie, assaulted from within and without, its world power threatened by colonial rebellions and wars of liberation, paralysed internally by strikes and civil war, will have to exert all its strength and raise mercenary armies against both enemies.
<G-vec00252-002-s037><endanger.bringen><de> Hilfemaßnahmen für unterwegs Schmerzhafte Blasen, Schürf- und Schnittwunden an Armen und Beinen bringen den Verletzten zunächst nicht in unmittelbare Gefahr, können einem jedoch das Vergnügen in der Natur gründlich vermiesen; außerdem vergrößert sich durch die verletzte Hautoberschicht das Risiko einer Infektion, die von einer Entzündung bis hin zu einer Blutvergiftung reichen kann.
<G-vec00252-002-s037><endanger.bringen><en> First-aid measures when on the road Painful blisters, grazes and cuts on arms and legs won’t endanger the injured straight away but might not get them a good night’s sleep. Also, it increases the risk of infection, which can either be a simple inflammation but also turn into toxaemia.
<G-vec00252-002-s038><endanger.bringen><de> In erster Linie bringen Sie ihre eigene Sicherheit und die anderer in Gefahr.
<G-vec00252-002-s038><endanger.bringen><en> First of all, you endanger your own safety and that of others.
<G-vec00252-002-s022><jeopardize.bringen><de> Diese integrierte Überwachung ist Teil eines "Europäischen Semesters" und ist mit einem erweiterten Sanktionsarsenal ausgestattet, um Fehlentwicklungen zu verhindern oder zu korrigieren, die die Finanzstabilität der EU und der Eurozone in Gefahr bringen könnten.
<G-vec00252-002-s022><jeopardize.bringen><en> Enhanced surveillance will be based on a "European semester" and comes with an array of sanctions to prevent or correct the excesses that could jeopardize the financial stability of the EU and the euro area.
<G-vec00254-002-s068><manipulate.bringen><de> Lege dann die zerknüllten Seidenpapierstücke mit den Fingern über jede Hälfte, um dann das Papier in die gewünschte Struktur zu bringen.
<G-vec00254-002-s068><manipulate.bringen><en> Place pieces of crumbled up tissue paper over each half using your fingers to manipulate the paper to your desired dimension or texture.
<G-vec00254-002-s069><manipulate.bringen><de> Denke immer daran, dass der Hauptgrund für die Durchführung von Keyword-Recherche nicht darin liegt, Suchmaschinen dazu zu bringen, Deine Webseite zu ranken.
<G-vec00254-002-s069><manipulate.bringen><en> Always remember that the main reason to conduct keyword research isn’t to manipulate search engines into ranking your web page.
<G-vec00254-002-s070><manipulate.bringen><de> Der Tierarzt wird dann wahrscheinlich versuchen, die Babys in eine Position zu bringen, in der die Mutter sie gebären kann.
<G-vec00254-002-s070><manipulate.bringen><en> The vet may try to manipulate the piglet into a position where the mother can pass it.
<G-vec00276-002-s033><hype.bringen><de> Bringen Sie mit diesem wunderbaren Eierbecher aus Olivenholz für Wachteleier das besondere, kleine Ei ganz groß heraus.
<G-vec00276-002-s033><hype.bringen><en> Hype up the special, small egg in this wonderful egg cup made of olive wood for quail’s eggs.
<G-vec00283-002-s038><transfer.bringen><de> Wenn der Frühling kommt, können Sie Ihren "Garten" auf den Balkon übertragen und den Überschuss auf das Land bringen.
<G-vec00283-002-s038><transfer.bringen><en> When spring comes, you can transfer your "garden" to the balcony, and transfer the surplus to the country site.
<G-vec00283-002-s039><transfer.bringen><de> Ebenfalls am Hafen von La Graciosa gibt es einige Shuttle-Services, die Sie an die verschiedenen Strände bringen.
<G-vec00283-002-s039><transfer.bringen><en> In La Graciosa’s port you can also hire a transfer service to take you to the different beaches.
<G-vec00283-002-s040><transfer.bringen><de> Alternativ holen wir Sie am Bahnhof Stirling ab und bringen Sie zu Ihrem Camper in Fintry für £ 20 pro Strecke für bis zu 4 Passagiere.
<G-vec00283-002-s040><transfer.bringen><en> Alternatively, we can collect you at Stirling Train Station and transfer you to your camper in Fintry for £20 each-way for up to 4 passengers.
<G-vec00283-002-s041><transfer.bringen><de> Der Helikopter und die Limousine werden Sie wieder zurück ins Hotel bringen, wo ein köstliches 4-Gänge Gourmet-Dinner in unserem Restaurant auf Sie wartet.
<G-vec00283-002-s041><transfer.bringen><en> Later at the hotel, that you will reach with the helicopter flight and transfer, you will enjoy a delicious four-course gourmet dinner in the restaurant.
<G-vec00283-002-s042><transfer.bringen><de> Stellen Sie Ihr Auto auf unserem Hotelparkplatz ab und lassen Sie sich von unserem Flughafentransfer direkt zu Ihrem Terminal bringen.
<G-vec00283-002-s042><transfer.bringen><en> Leave your car in our hotel car park and transfer to the airport terminals in comfort with our shuttle bus.
<G-vec00283-002-s043><transfer.bringen><de> Kostenlose Testausgabe Bringen Sie Akten von iPod, iPhone und iPad zu iTunes und Computer.
<G-vec00283-002-s043><transfer.bringen><en> Transfer files from iPod, iPhone, and iPad to iTunes and com...
<G-vec00283-002-s044><transfer.bringen><de> Nur Busse und die Straßenbahn bringen den Pendler in die City.
<G-vec00283-002-s044><transfer.bringen><en> Merely busses and the tram transfer commuters to the city.
<G-vec00283-002-s045><transfer.bringen><de> Während eines Fernsehinterviews sprach Matteo über den Wendepunkt in ihrer Entwicklung: Er verbrachte die letzten Stunden vor dem Schließen des Transferfensters mit einem italienischen Sportchef und erlebte die letzten entscheidenden Minuten, um Geschäfte zum Abschluss zu bringen.
<G-vec00283-002-s045><transfer.bringen><en> During a TV interview, Matteo identified the turning point of their trip: he was with an Italian Sporting Director a few hours before the end of the transfer window, right during the last key minutes to close the deals.
<G-vec00283-002-s046><transfer.bringen><de> Verschwenden Sie Ihre Chance nicht und bringen Sie Ihr Geschäft ins Internet.
<G-vec00283-002-s046><transfer.bringen><en> Do not waste your chance and transfer your business online.
<G-vec00283-002-s047><transfer.bringen><de> Frage ihn, ob er dir einen USB Stick leihen kann, um deine Schulaufgaben von dem Schulcomputer auf deinen Heim-PC zu bringen.
<G-vec00283-002-s047><transfer.bringen><en> Ask to borrow a USB drive from him to transfer a file from a school/work computer to your personal computer.
<G-vec00283-002-s048><transfer.bringen><de> Wir kommen nachts an und bringen Sie zu unserem Hotel.
<G-vec00283-002-s048><transfer.bringen><en> We arrive in Shiraz at night and transfer to our hotel.
<G-vec00283-002-s049><transfer.bringen><de> Wenn die Beamten keinen Erfolg hatten, die Praktizierenden dazu zu bringen, Falun Gong nicht mehr zu praktizieren, brachten sie sie in andere Abteilungen des Gefängnisses.
<G-vec00283-002-s049><transfer.bringen><en> If officials didn't succeed in stopping practitioners from practising Falun Gong, they would transfer practitioners to other prison sections.
<G-vec00283-002-s050><transfer.bringen><de> Jederzeit verfügbare Messaging Services wie Fax, Benachrichtigungen, sichere E-Mail- und Dateitransferlösungen erweitern das Trading Grid und bringen Handelspartner jeder Größenordnung in Reichweite Ihres Unternehmens.
<G-vec00283-002-s050><transfer.bringen><en> On-demand messaging services, including fax, notifications, secure email and file transfer solutions extend the reach of the Trading Grid to trading partners of all sizes.
<G-vec00283-002-s051><transfer.bringen><de> Wir sind Ihr Full-Service-Dienstleister für das Digital Enterprise und bringen Ihre Inhalte mit FirstSpirit ins Web.
<G-vec00283-002-s051><transfer.bringen><en> We are your full service provider for the digital enterprise and transfer your content into the web using FirstSpirit.
<G-vec00283-002-s052><transfer.bringen><de> Sie sagen uns Bescheid, wann wir Sie im Hotel abholen sollen, um Sie zum Flughafen oder Busbahnhof zu bringen.
<G-vec00283-002-s052><transfer.bringen><en> Breakfast at the hotel. When you tell us, we will transfer from the hotel to the airport or bus station in Catamarca.
<G-vec00283-002-s053><transfer.bringen><de> An Ihrer Ankunft wird Ihr Reiseleiter Sie zu Ihrem Hotel für den Check-in bringen.
<G-vec00283-002-s053><transfer.bringen><en> Upon your arrival arrive at Yangon airport, your guide will meet and transfer you to your hotel for check in.
<G-vec00283-002-s054><transfer.bringen><de> 4Videosoft iPad 2 to Computer Transfer - Bringen iPad 2 Dateien auf den Computer.
<G-vec00283-002-s054><transfer.bringen><en> 4Videosoft iPad 2 to Computer Transfer - Transfer iPad 2 files to computer.
<G-vec00283-002-s055><transfer.bringen><de> Die Direktion des Auffanglagers hat versprochen sich für sie einzusetzen, sie aufs spanische Festland zu bringen.
<G-vec00283-002-s055><transfer.bringen><en> The head of the reception centre had promised to do what he could for them, to transfer them to the Spanish mainland.
<G-vec00283-002-s056><transfer.bringen><de> Dann bringen wir Sie zu Ihrem Hotel am Roten Meer.
<G-vec00283-002-s056><transfer.bringen><en> Finally we will transfer you to your hotel at the Red Sea where you will have dinner.
<G-vec00286-002-s046><entice.bringen><de> Wir haben auch einige von Menschen gemachte Nistkästen erhalten, um mehr Barking Owls dazu zu bringen, hier zu brüten.
<G-vec00286-002-s046><entice.bringen><en> We have also obtained some man made nesting boxes to entice more Barking Owls to breed here.
<G-vec00286-002-s047><entice.bringen><de> Online-Casinos verschenken Prämien, um neue Kunden dazu zu bringen, auf ihrer Website zu spielen.
<G-vec00286-002-s047><entice.bringen><en> casinos give away bonuses to entice new customers to play on their website.
<G-vec00286-002-s031><tempt.bringen><de> 195 brennende Fragen, prickelnde Aufgaben, ungewöhnliche Positionen und spannende Rollenspiele, um die Sinne zum Glühen zu bringen.
<G-vec00286-002-s031><tempt.bringen><en> 195 burning questions, titillating tasks, provocative positions and racy roleplays to tempt the senses.
<G-vec00298-002-s019><heighten.bringen><de> Egal ob Sie allein oder mit Ihrem Partner spielen, diese Nippelsauger ermöglichen ein freihändiges Vergnügen, so dass Sie sich auf andere erogene Zonen konzentrieren können, um Ihr Lusterlebnis auf den Höhepunkt zu bringen.
<G-vec00298-002-s019><heighten.bringen><en> Whether you choose to play alone or with a partner, these nipple suckers leave your hands free to focus on other erogenous zones to heighten your erotic playtime.
<G-vec00302-002-s038><lead.bringen><de> Wir Originalvölker der Binizzá, Ikoot, Chontal, Zoque, Nahua y Popoluca, die wir im Isthmus von Tehuantepec in den Bundesstaaten von Oaxaca und Veracruz leben sagen NEIN zu den Megaprojekten des Todes, wir verweigern die Zerstörung, die sie in unsere Territorien bringen wollen und die unsere Mutter Erde massakriert.
<G-vec00302-002-s038><lead.bringen><en> The Binizzá, Ikoot, Chontal, Zoque, Nahua and Popoluca originary peoples who inhabit the Isthmus of Tehuantepec in the states of Oaxaca and Veracruz have already made clear our “NO” to these megaprojects of death, which will lead to the destruction of our territories and the death of our mother earth.
<G-vec00302-002-s039><lead.bringen><de> Ich versuche zu allererst meine Hintermänner in Sicherheit zu bringen, hoffe dass mein Gegner mich nicht schlagen kann, mit dem Ziel meinen Pip-Vorsprung aus den großen Würfeln vom Anfang ins Ziel zu retten.
<G-vec00302-002-s039><lead.bringen><en> I try to save my back men first, hope I don´t get hit and keep running with the purpose of using my pip lead from start to win the game.
<G-vec00302-002-s040><lead.bringen><de> Der überflüssige salzige Konsum kann zur Wasserfestnahme, dem hohen Blutdruck und anderen Komplikationen bringen.
<G-vec00302-002-s040><lead.bringen><en> Excess salt consumption can lead to water retention, high blood pressure and other complications.
<G-vec00302-002-s041><lead.bringen><de> Da Cloud-Anbieter ihre Hardware typischerweise alle zwei Jahre erneuern, verglichen mit den 4-7 Jahren in vielen Unternehmen, kann eine Cloud-Lösung erhebliche leistungssteigernde Vorteile bringen.
<G-vec00302-002-s041><lead.bringen><en> As cloud vendors typically refresh their hardware every 2 years, compared with between 4 and 7 years for many large enterprises, this can lead to a 20% performance improvement.
<G-vec00302-002-s042><lead.bringen><de> Beide Werke haben die gleiche Materialquelle, bringen jedoch jeweils einen anderen dramaturgischen Ausdruck.
<G-vec00302-002-s042><lead.bringen><en> Both pieces derive from the same musical material, but lead to a different dramaturgical expression.
<G-vec00302-002-s043><lead.bringen><de> Hier hatte ich einen See auf den Karten von Inge entdeckt und habe sie angewiesen uns dort hin zu bringen.
<G-vec00302-002-s043><lead.bringen><en> I found a lake on Inges maps and told her to lead us to this point.
<G-vec00302-002-s044><lead.bringen><de> Eure Werke bringen euch den Schmerz und den Tod und ihr versteht es nicht, Mich zu suchen, um im Guten stark zu werden.
<G-vec00302-002-s044><lead.bringen><en> Your deeds lead you toward pain and death and you are unable to seek Me so that I may strengthen you in righteousness.
<G-vec00302-002-s045><lead.bringen><de> Das Georg Forster-Programm trägt dem Rechnung und stärkt Entwicklungsländer bei der Schaffung und beim Ausbau von Hochschul- und Wissenschaftssystemen, die zu Kristallisationszentren weiterer Entwicklung werden, etwa, indem sie Unternehmen anziehen und hoch qualifiziertes Personal ausbilden oder indem sie zu gefragten Partnern für internationale Kooperationen werden, die weitere Wissens- und Entwicklungsgewinne bringen.
<G-vec00302-002-s045><lead.bringen><en> The Georg Forster Programme recognises this fact and strengthens developing countries in the creation and development of university and science systems which become crystallisation centres for further development. This may take the form of attracting companies and training highly-qualified personnel or becoming sought-after partners for international collaborations which themselves lead to further gains in knowledge and development.
<G-vec00302-002-s046><lead.bringen><de> Die überarbeiteten Aufträge dieses Unternehmens bringen die zweite Kampagne an einen Punkt, den wir als final und hinsichtlich der Komplexität gut balanciert betrachten.
<G-vec00302-002-s046><lead.bringen><en> Reworking this operation’s missions will lead the Second Front to a state that we consider final and well-balanced in terms of complexity.
<G-vec00302-002-s047><lead.bringen><de> [Buchtipp von Beat Mazenauer] Turbulente Zeiten bringen turbulente Leben hervor - und eine Literatur, die solche Turbulenzen einzufangen versucht.
<G-vec00302-002-s047><lead.bringen><en> [book tip by Beat Mazenauer] Turbulent times lead to turbulent lives – and literature, which attempts to capture this turbulence.
<G-vec00302-002-s048><lead.bringen><de> 8Wenn der Ewige Gefallen an uns hat, so wird er uns in dieses Land bringen und uns solches geben, ein Land, in dem Milch und Honig fließt.
<G-vec00302-002-s048><lead.bringen><en> 8 If the Lord is pleased with us, he will lead us into that land, a land flowing with milk and honey, and will give it to us.
<G-vec00302-002-s049><lead.bringen><de> François Longchamp erwähnte ebenfalls die Verwaltung des Luftraums und des Verkehrsflusses, wobei er allerdings unterstrich, dass diese Bestrebungen "keine unerträglichen Beeinträchtigungen für die Anwohner mit sich bringen".
<G-vec00302-002-s049><lead.bringen><en> Mr. Longchamp also talked about airspace and traffic flow management, while stressing that those ambitions "must not lead to unbearable harmful consequences for nearby residents".
<G-vec00302-002-s050><lead.bringen><de> Im Gegenteil, um uns Mut bringen, missionarisch zu sein, zu erkennen wie wir die Schönheit des Glaubens an Christus und des kirchlichen Lebens anbieten können.“ So beschrieb es der neue Synodalsenior Daniel Ženatý.
<G-vec00302-002-s050><lead.bringen><en> On the contrary – let this lead us to a missionary courage, to finding how to offer the beauty of faith in Christ and the life of the Church,” explained the new Synodal Senior Daniel Ženatý.
<G-vec00302-002-s051><lead.bringen><de> Ein Deal, um die 70.000 Minenarbeiter wieder zum Arbeiten im Platin-Minengürtel des Landes zu bewegen, der für ungefähr 70 Prozent des globalen Angebots verantwortlich ist, würde wohl die Ängste einer Unterbrechung der Produktion beruhigen und das Edelmetall zum sinken bringen.
<G-vec00302-002-s051><lead.bringen><en> A deal to put the 70,000 striking miners back to work in the country’s platinum mining belt, which accounts for roughly 70 percent of global supply, would likely alleviate fears over production disruptions and could lead the precious metal lower.
<G-vec00302-002-s052><lead.bringen><de> Obwohl die Bremsen für viele Fälle eben wirksam sind, kann jedoch das Bremsen die Räder aussondern und, zum Verlust der Kontrolle über die Lenkung bringen, unmöglich machend, für die Vermeidung des Zusammenstoßes abzuschweifen.
<G-vec00302-002-s052><lead.bringen><en> Though brakes also are effective in many cases, however braking can block wheels and lead to loss of the control over a steering, doing impossible to turn aside for collision avoidance.
<G-vec00302-002-s053><lead.bringen><de> „Sie haben mir die Augen geöffnet: Jetzt weiß ich, was es braucht, um Prozesse erfolgreich in Gang zu bringen.
<G-vec00302-002-s053><lead.bringen><en> Contact “My eyes have opened for what is takes to successfully lead a process.
<G-vec00302-002-s054><lead.bringen><de> Perspektivwechsel bringen neue An – und Einsichten und sind als solche ein wichtiges methodisches Element von Forschung und Innovation.
<G-vec00302-002-s054><lead.bringen><en> Changes of perspective often lead to new views and insights and as such are an important methodological element of research and innovation.
<G-vec00302-002-s055><lead.bringen><de> Nicht in die Forschungsarbeiten einbezogen wird ein möglicher Rückgang der expliziten Handelskosten (Maklerprovisionen oder Börsengebühren), der bei erhöhtem Wettbewerb zwischen Intermediären und Börsen zu erwarten ist und für Bürger und Unternehmen in der EU weiteren wirtschaftlichen Nutzen mit sich bringen dürfte.
<G-vec00302-002-s055><lead.bringen><en> The research does not consider potential reductions in explicit trading costs (brokerage commissions or exchange fees) that can be expected to accompany increased competition between intermediaries and exchanges and lead to further economic benefits for EU citizens and business.
<G-vec00302-002-s056><lead.bringen><de> In einem RCT sollte überprüft werden, ob die Verwendung eines Pflegeprotokolls Verbesserungen für Patienten und Pflegekräfte bringen kann.
<G-vec00302-002-s056><lead.bringen><en> A randomised, controlled clinical trial tried to demonstrate whether the use of a nursing care protocol can lead to improvements for patients and nurses.
<G-vec00307-002-s026><convene.bringen><de> Die Kolloquien bringen Wissenschaftler, Forscher, Wirtschaftsführer und Politiker in IBM Forschungslaboren rund um die Welt zusammen.
<G-vec00307-002-s026><convene.bringen><en> The colloquia will convene scientists, academics, business and government leaders at IBM Research laboratories around the world to discuss how emerging trends will impact business and society.
<G-vec00318-002-s254><align.bringen><de> Die Behandlungen und Rituale im Kayumanis Spa zielen darauf ab Körper, Geist und Seele in Einklang zu bringen.
<G-vec00318-002-s254><align.bringen><en> The treatments and rituals in the Kayumanis Spa seek to align body, mind and soul.
<G-vec00318-002-s255><align.bringen><de> Mit Hilfe von DBS entwickeln wir Strategien, konzentrieren uns auf das Wesentliche, bringen die richtigen Leute zusammen, um mehr Nutzen für unsere Kunden und Anteilseigner zu schaffen.
<G-vec00318-002-s255><align.bringen><en> Here you’ll learn how DBS is used to shape strategy, focus execution, align our people, and create value for customers and shareholders.
<G-vec00318-002-s256><align.bringen><de> Artikel 2.1.c des Pariser Klimaabkommens verlangt, Finanz- und Kapitalmärkte in Einklang mit dem Klimaabkommen zu bringen.
<G-vec00318-002-s256><align.bringen><en> Article 2.1.c of the Paris Climate Agreement asks all member states to align all financial flows with the goals of the agreement.
<G-vec00318-002-s257><align.bringen><de> Die Flut von Carbon-Rahmen hatten die TOUR-Tester schon auf den Messen des Herbstes 2003 mit Argwohn beäugt; die Erfahrungen mit den inflationär angebotenen Monocoques der späten achtziger Jahre lehrt, dass die Hersteller schon damals große Probleme damit hatten, Anforderungen des Materials und hohe Stückzahlen zur Deckung zu bringen.
<G-vec00318-002-s257><align.bringen><en> The TOUR-testers had already doubtfully eyed the flood of carbon-frames at the autumn fairs 2003; experience with the inflationary offered monocoques of the late 80's shows that manufacturers already back then had problems to align the material's demands and large quantities.
<G-vec00318-002-s258><align.bringen><de> Wenn wir uns alle bewusst als EINES in Übereinklang bringen, und wir alle beispielsweise die Sternenprozession und die 11:11-Mudras machen, dann verstärkt das alles, was wir tun.
<G-vec00318-002-s258><align.bringen><en> If we all consciously align as ONE and if we all do the Starry Processional Dance and the 11:11 Mudras, for example, it makes everything we do even stronger.
<G-vec00318-002-s402><associate.bringen><de> Erdem Faszinierend an Erdems Kleidern und Roben ist, wie sie, so außergewöhnlich und auffällig sie auch erscheinen mögen, doch nie mit Anspielungen wie 'prunkvoll' oder gar 'kitschig' in Verbindung gebracht werden könnten.
<G-vec00318-002-s402><associate.bringen><en> The elegant simplicity of Fascinating about Erdems dresses and gowns is, how, even though they seem so extraordinary and striking, one could never associate them with terms as pompous or overloaded.
<G-vec00318-002-s403><associate.bringen><de> Es wird in keinem Fall die IP-Adresse mit anderen den Nutzer betreffenden Daten in Verbindung gebracht.
<G-vec00318-002-s403><associate.bringen><en> Google will in no event associate your IP address with other data.
<G-vec00318-002-s404><associate.bringen><de> Der Charakter auf dem Bildschirm sollte von einem Kind nicht mit real existierenden Wesen in Verbindung gebracht werden können, sondern in allen Aspekten ein Fantasiewesen sein.
<G-vec00318-002-s404><associate.bringen><en> A child should not be able to associate the character on the screen with real life characters, they should be distinctly fantasy.
<G-vec00318-002-s405><associate.bringen><de> Es wird mit dem Guten, mit Ehrlichkeit, dem Anfang, Unschuld und Perfektion in Verbindung gebracht.
<G-vec00318-002-s405><associate.bringen><en> We associate the white Flower of Life with goodness, sincerity, beginning and perfection.
<G-vec00318-002-s406><associate.bringen><de> Hiermit wären wir auch schon bei dem Aspekt, der wie kein anderer mit der bayerischen Sommerkultur in Verbindung gebracht wird: Neben jenem am Chinesischen Turm gibt es eine ganze Menge weiterer Biergärten in München.
<G-vec00318-002-s406><associate.bringen><en> If there is anything people tend to associate with sunny weather and Bavaria it is surely enjoying a beer in the sun. And along with the one by the aforementioned Chinese Tower, there is any number of other beer gardens in Munich.
<G-vec00318-002-s407><associate.bringen><de> Keinesfalls wird aber Ihre IP-Adresse durch Google mit anderen Daten von Google in Verbindung gebracht.
<G-vec00318-002-s407><associate.bringen><en> Google will never associate your IP address with other data held by Google.
<G-vec00321-002-s132><drop.bringen><de> Um Ihr Kind für die Nachmittagsbetreuung anzumelden, füllen Sie bitte das Anmeldeformular aus und senden es an admin@kilians.com oder bringen es im Administrationsbüro vorbei.
<G-vec00321-002-s132><drop.bringen><en> To register your child for aftercare/supervised study please complete the registration form and send it to admin@kilians.com or drop it into the Administration Office.
<G-vec00321-002-s133><drop.bringen><de> Wenn Ihre Zeit in Kiel sich dem Ende zuneigt, können wir Sie gerne direkt zum Hauptbahnhof bringen, damit Sie Ihren Zug erwischen.
<G-vec00321-002-s133><drop.bringen><en> If your trip in Kiel is shortly coming to end then we'll drop you straight outside Hauptbahnhof train station so that you can jump straight onto your train!
<G-vec00321-002-s134><drop.bringen><de> Nach unserem Ausflug bringen wir Sie zum Portland Spirit, wo Sie eine Bootsfahrt mit Abendessen auf dem Willamette River machen.
<G-vec00321-002-s134><drop.bringen><en> After our Gorge excursion, we will drop you at the Portland Spirit where you will take an evening dinner cruise on the Willamette River.
<G-vec00321-002-s135><drop.bringen><de> Folge den Anweisungen zum Parkplatz und schaue, ob du dieses riesige Fahrzeug mit der gleichen Leichtigkeit sicher auf den Parkplatz bringen kannst.
<G-vec00321-002-s135><drop.bringen><en> Follow the directions to the parking bay, and see if you can safely drop this huge vehicle off in the parking lot with the same ease.
<G-vec00321-002-s136><drop.bringen><de> Wir holen Sie ab und bringen Sie in Ihre Unterkunft in Kuta, Seminyak, Nusa Dua, Jimbaran, Sanur oder Ubud.
<G-vec00321-002-s136><drop.bringen><en> We will pick you up and drop you off in your accommodation in Kuta, Seminyak, Nusa Dua, Jimbaran, Sanur or Ubud.
<G-vec00321-002-s137><drop.bringen><de> Wir bringen Sie zu Ihrem Strandcampingplatz.
<G-vec00321-002-s137><drop.bringen><en> We drop you off at your beach campsite for a relaxing evening under the stars.
<G-vec00321-002-s138><drop.bringen><de> Wir holen Ihr Kind vom Hotel, der Firma oder einer anderen Wunschadresse ab, übernehmen die Gestaltung dieses Tages und bringen es zum vereinbarten Zeitpunkt wieder zurück.
<G-vec00321-002-s138><drop.bringen><en> We pick up your child from your hotel, your office or any other place. We spend the day with your child offering an individually arranged programme and drop them off at the agreed time and place.
<G-vec00321-002-s139><drop.bringen><de> Konzerte und Feste, ob auf dem Cannstatter Wasen oder in der Porsche-Arena / Hanns-Martin-Schleyerhalle: Die S-Bahnen S1, S2 und S3 bringen Sie direkt von Haustür zu Haustür.
<G-vec00321-002-s139><drop.bringen><en> Concerts and festivities, whether at the Cannstatter Wasen or at the Porsche Arena/Hanns-Martin-Schleyer Event-Hall are all accessible via subway: Please note that S1, S2 and S3 will drop you off right at the front door.
<G-vec00321-002-s140><drop.bringen><de> Wir holen Sie ab und bringen Sie zu Ihrer Unterkunft in Bagan.
<G-vec00321-002-s140><drop.bringen><en> We will pick you up and drop you off in your accommodation in Bagan.
<G-vec00321-002-s141><drop.bringen><de> Sie können Ihr Auto auch bei einer der Taxi-Transferfirmen (wie Taxi / Parking Christophe) parken, die Sie dann mit dem Auto zur Taxi Haltestelle Urania in Zermatt bringen.
<G-vec00321-002-s141><drop.bringen><en> You can also park your car with one of the Taxi transfer companies (like Taxi / Parking Christophe) who will then transfer you by car up to Zermatt Urania Taxi drop off point.
<G-vec00321-002-s142><drop.bringen><de> Tag 13: Fahren Sie nach Brisbane und bringen Sie Ihren Mietwagen zum Brisbane City Depot.
<G-vec00321-002-s142><drop.bringen><en> Day 13: Drive to Brisbane and drop off your rental car at Brisbane City depot.
<G-vec00321-002-s143><drop.bringen><de> Alternativ kannst du auch das öffentliche Verkehrssystem nutzen oder einen Freund oder Verwandten fragen, dich abzuholen und nach Hause zu bringen.
<G-vec00321-002-s143><drop.bringen><en> Alternately, use public transport or ask a friend/relative to drop you home.
<G-vec00321-002-s144><drop.bringen><de> Wir holen Sie ab und bringen Sie zum Flughafen von Kathmandu.
<G-vec00321-002-s144><drop.bringen><en> We will pick you up and drop you off at the airport of Kathmandu.
<G-vec00321-002-s145><drop.bringen><de> Begeben Sie sich an Tag 12 auf die Rückreise nach Johannesburg und bringen Sie Ihren Mietwagen zurück zur Autovermietung.
<G-vec00321-002-s145><drop.bringen><en> Return to Johannesburg on day 12 and drop off your hire car at the car rental station.
<G-vec00321-002-s146><drop.bringen><de> Wir holen Sie ab und bringen Sie an der Rezeption Ihres Hotels ab.
<G-vec00321-002-s146><drop.bringen><en> We will pick you up and drop you off at the reception of your hotel.
<G-vec00321-002-s147><drop.bringen><de> Und wenn Du in einem Hotel übernachtest, dann bringen wir dir das Auto dorthin und holen es dort auch wieder ab, damit Du keine Extrafahrten machen musst.
<G-vec00321-002-s147><drop.bringen><en> Also, if you stay in a hotel, we can drop off the car there and then pick it up again so you do not have to lift a finger.
<G-vec00321-002-s148><drop.bringen><de> Die Möglichkeit direkt vor unserem Geschäft zu parken macht es einfach Geräte zu bringen oder abzuholen.
<G-vec00321-002-s148><drop.bringen><en> With parking right outside the door, it's easy to drop off and pick up repairs or purchases.
<G-vec00321-002-s149><drop.bringen><de> Bringen Sie einfach Ihr Fahrzeug zu uns und wir bieten Ihnen einen stressfreien Transfer zum Flughafen Charleroi.
<G-vec00321-002-s149><drop.bringen><en> Just drop off your car and they will ensure your smooth transfer to Charleroi airport.
<G-vec00321-002-s150><drop.bringen><de> Wir holen Sie ab und bringen Sie zu Ihrer Unterkunft in Mandalay.
<G-vec00321-002-s150><drop.bringen><en> We will pick you up and drop you off in your accommodation in Mandalay.
<G-vec00321-002-s113><pull.bringen><de> Die Box mit dem Daumen in der Grifföffnung in Form bringen.
<G-vec00321-002-s113><pull.bringen><en> Pull the box into shape with the thumbs in the index.
<G-vec00321-002-s114><pull.bringen><de> In dieser Etappe realisierten wir welch riesiges Projekt wir vor uns hatten und wir fragten uns, ob wir fähig sind es zum Abschluss zu bringen.
<G-vec00321-002-s114><pull.bringen><en> At this stage we realised what a huge project we had ahead of us and wondered whether we would be able to pull it off.
<G-vec00321-002-s115><pull.bringen><de> Und nur, um das alles auf einen Nenner zu bringen, haben sie ein Schlagwort gefunden, um das zu definieren, was die Bewegung der Emerging Church definiert; es ist das Wort „Konversation“ oder „Gespräch“.
<G-vec00321-002-s115><pull.bringen><en> And just to pull it all down, they have found a buzzword to define what marks the movement of the emerging church, it’s the word “conversation.”
<G-vec00321-002-s116><pull.bringen><de> Wo Planet X, in der Sichtlinie, normalerweise hinter dem Kreis ist, der die Sonne blockiert, sind die Stereosatelliten zu jeder Seite der Erde positioniert und bringen andere Ansichten zustande von dem, was hinter der Sonne ist, genauso wie verschiedene Ansichten von dem, was an der Seite und vor der Sonne ist, wie das Cor-Überlappungsbild zeigt.
<G-vec00321-002-s116><pull.bringen><en> Where Planet X, in line of view, is normally behind the Sun blocking circle, the stereo satellites are positioned to either side of Earth and thus pull in different views of what is behind the Sun as well as different views of what is to the side and in front of the Sun, as the Cor Overlap image shows.
<G-vec00321-002-s117><pull.bringen><de> Lautsprecher von Polk wurden entwickelt, um das ultimative Surround-Sound-Erlebnis zu schaffen und Sie so in den Mittelpunkt des Geschehens zu bringen – egal, was Sie sich gerade anschauen.
<G-vec00321-002-s117><pull.bringen><en> Polk speakers are built to pull you right into the action of whatever you're watching, and engineered to provide the ultimate surround sound experience.
<G-vec00321-002-s118><pull.bringen><de> Meiner Meinung nach hat die Fed beschlossen, ihre Zinsen unverändert zu belassen, da sie äußerst zuversichtlich ist, dass sie bei einem Anstieg der Inflation in der Lage sein wird, diese schnell wieder unter Kontrolle zu bringen.
<G-vec00321-002-s118><pull.bringen><en> In my view, the Fed has decided to keep interest rates on hold because it feels highly confident that once inflation starts to rise, it will be able to quickly pull it back under control.
<G-vec00321-002-s119><pull.bringen><de> Den brauche ich für das ganze Gewicht den Berg hoch zu bringen.
<G-vec00321-002-s119><pull.bringen><en> I need it for to pull all the weight up to the mountain.
<G-vec00321-002-s120><pull.bringen><de> Die griffigen HB Rover Reifen sorgen für zusätzlichen Griff und bringen den Crawler King durch nahezu jedes Gelände.
<G-vec00321-002-s120><pull.bringen><en> This gives the HB Rover tires at all four corners the grip and traction needed to pull the Crawler King up impossibly steep angles.
<G-vec00321-002-s121><pull.bringen><de> Und das Know-how zur Umsetzung bringen wir gleich mit: Unsere erfahrenen M&A-Berater unterstützen unsere Kunden in allen Phasen von Kauf- und Verkaufsprozessen.
<G-vec00321-002-s121><pull.bringen><en> And we have what it takes to pull off the transaction: Our experienced M&A consultants support our clients throughout the whole process with comprehensive buy-side and sell-side advisory.
<G-vec00321-002-s122><pull.bringen><de> Es hat aber auch eine neue Verfassung geschrieben und verabschiedet, die die Teilung und Ausgewogenheit der Gewalten fördert und es scheint auf Kurs, einen erfolgreichen Regierungswechsel zuwege zu bringen.
<G-vec00321-002-s122><pull.bringen><en> But it has also written and adopted a new constitution structured to encourage the separation and balance of powers, and it seems on track to pull off a successful change in government.
<G-vec00321-002-s123><pull.bringen><de> Das bietet eine echte Chance für das Land, aus der Abwärtsspirale herauszukommen und ein zukunftsweisendes Investition-, Infrastruktur- und Innovationsprojekt in Gang zu bringen: Die immense Importrechnung für Öl und Gas wird reduziert und die Erneuerbaren Energien schaffen Arbeitsplätze und Wertschöpfung im Inland.
<G-vec00321-002-s123><pull.bringen><en> This offers the country a real opportunity to pull out of the downward spiral and start a forward-looking investment, infrastructure and innovation project, in which the huge import bill for oil and gas is reduced and renewable sources of energy create jobs and added value for the country.
<G-vec00321-002-s124><pull.bringen><de> Bringen Sie kleinen Kindern bei, die Katze nicht zu verfolgen.
<G-vec00321-002-s124><pull.bringen><en> Not to chase the cat or pull her tail!
<G-vec00321-002-s125><pull.bringen><de> Außerdem mag ich an ihm, dass er es bringen kann ein Black Sabbath T-Shirt für den Großteil des Filmes zu tragen.
<G-vec00321-002-s125><pull.bringen><en> I also like the fact that he can pull off wearing a Black Sabbath T-shirt for the better part of the film!
<G-vec00322-002-s041><pinpoint.bringen><de> Schnell wird klar, wohin die Reise geht, der Sound wird dreckiger und die immer persönlicheren Texte bringen die Stimmung der beziehungsunfähigen, politisch brüchigen Generation auf den Punkt.
<G-vec00322-002-s041><pinpoint.bringen><en> Quickly, it becomes very clear, where the journey is going, the sound is getting rougher and the ever more personal lyrics pinpoint the mood of a generation, incapable of relationships and politically fragile.
<G-vec00330-002-s132><reveal.bringen><de> Vier Künstler warten auf die Besucher: Die Musiker und Schauspieler der Compagnie Gorgomar erwecken während Ihres gesamten Besuchs Räume und Gegenstände zum Leben und bringen ihre verborgene Magie und ihre Geheimnisse ans Licht.
<G-vec00330-002-s132><reveal.bringen><en> Four artists await the visitors – musicians and actors from the Gorgomar Company – who will bring the rooms and items on display to life during your visit and reveal their hidden magic and their secrets.
<G-vec00330-002-s134><reveal.bringen><de> ● c Verhaltensrang: Um Zuschauer und Kommunikatoren zu ermutigen, die qualitativ hochwertige Inhalte zum Ausdruck bringen, gilt: Je schneller die Nutzer Inhalte extrahieren (teilen, kommentieren und mögen), desto mehr Anreiz besteht darin, die Inhalte zu ermitteln, die sie erhalten.
<G-vec00330-002-s134><reveal.bringen><en> c Behavior Rank: In order to encourage the viewers and communicators who reveal high-quality content, the sooner the users mine content (sharing, commenting, and liking), the more content mining incentives they will receive.
<G-vec00330-002-s136><reveal.bringen><de> Er soll dann das an die Öffentlichkeit bringen dürfen, was er herausfand – es ist anzunehmen, diese Erkenntnisse werden nicht frei von Änderungen sein.
<G-vec00330-002-s136><reveal.bringen><en> He will publicly reveal anything he discovers. It is to be assumed that these findings will not be exempt from modifications.
<G-vec00330-002-s137><reveal.bringen><de> Bringen Sie mit dem Bourjois Radiance Reveal Concealer, 7,8 ml, Ihren Teint zu strahlender Geltung.
<G-vec00330-002-s137><reveal.bringen><en> Reveal your radiant complexion with the Bourjois Radiance Reveal Concealer 7.8ml.
<G-vec00330-002-s138><reveal.bringen><de> Flashbacks bringen mehr von Roberts Vergangenheit ans Licht; über seine tote Frau und Tochter, und die wahre Identität von ‚Vera‘.
<G-vec00330-002-s138><reveal.bringen><en> Flashbacks reveal more of Robert’s past, his dead wife and daughter, and the true identity of ‘Vera’.
<G-vec00340-002-s095><take.bringen><de> Ein kostenloser Shuttlebus bringt Sie zum Strand.
<G-vec00340-002-s095><take.bringen><en> A free shuttle will take you to the beach.
<G-vec00340-002-s096><take.bringen><de> Wir realisieren, was Sie in die Zukunft bringt.
<G-vec00340-002-s096><take.bringen><en> We implement the measures that take you into the future.
<G-vec00340-002-s097><take.bringen><de> Die kombinierte Stadtrundfahrt in Palma de Mallorca mit dem Hop-on Hop-off Bus und einer Hafenrundfahrt bringt Sie zu allen Hightlights der vielseitigen Inselhauptstadt.
<G-vec00340-002-s097><take.bringen><en> The combined city tour in Palma de Mallorca with the hop-on hop-off bus and a harbor tour by boat will take you to all the highlights of this worth seeing island capital.
<G-vec00340-002-s098><take.bringen><de> Ein 5-minütiger Fußmarsch bringt Sie zur U-Bahn Station Florida.
<G-vec00340-002-s098><take.bringen><en> A 5-minute walk will take you to L. N. Alem subway station.
<G-vec00340-002-s099><take.bringen><de> Bis Juni 2018 werden die Belegungsdaten ausgewertet und überprüft, ob die Echtzeitinformation tatsächlich mehr Autofahrer in Busse und Bahnen bringt.
<G-vec00340-002-s099><take.bringen><en> The occupancy data will be evaluated and assessed for whether this real-time information actually convinces more drivers to take buses and trains by June 2018.
<G-vec00340-002-s100><take.bringen><de> Der Rückweg erfolgt auf dem Waldpfad, der später mit dem Hinweg zusammenläuft und uns zum Panider Sattel zurück bringt.
<G-vec00340-002-s100><take.bringen><en> For the way back we take the forest trail that joins the path on which we came, taking us back to the starting point.
<G-vec00340-002-s101><take.bringen><de> Bedeckt ihre Augen und bringt sie dorthin, legt sie neben die toten Körper.
<G-vec00340-002-s101><take.bringen><en> Cover their eyes and take them there, lay them down next to the dead bodies.
<G-vec00340-002-s102><take.bringen><de> Zwischen März und Oktober ist ein Flussboot auf der Seine unterwegs und bringt Sie zu acht verschiedenen Schauplätzen, worunter auch die Notre Dame.
<G-vec00340-002-s102><take.bringen><en> Between March and October, there is a river boat that will take you to eight top locations, including the Notre Dame.
<G-vec00340-002-s103><take.bringen><de> Nach Ihrer Rückkehr zur Quad-Station bringt Sie der Transfer wieder zurück zum Hotel.
<G-vec00340-002-s103><take.bringen><en> After your return to the quad station, the transfer will take you back to the hotel.
<G-vec00340-002-s104><take.bringen><de> Das Creative Cloud-Abo für Fotografie bringt die Fotografie auf eine neue Ebene.
<G-vec00340-002-s104><take.bringen><en> Take your photography further with the Creative Cloud Photography plan.
<G-vec00340-002-s105><take.bringen><de> Bringt das zu Sersine.
<G-vec00340-002-s105><take.bringen><en> Take this to Sersine.
<G-vec00340-002-s106><take.bringen><de> Desweiteren bringt diese neue Klasse neue Fahrzeuge und Gegenstände in das Spiel, was den Spielern erlaubt, Industrien zu entwickeln, die Wirtschaft zu stärken und neue Ressourcen zu verwerten.
<G-vec00340-002-s106><take.bringen><en> NEW CONTENT SUPPORTING A DEEPER EXPERIENCEDive underwater and take advantage of over 80 brand new items to develop your industries, strengthen your economy, and exploit new energetic resources.
<G-vec00340-002-s107><take.bringen><de> Dort angekommen, steigst du zunächst in die Einschienenbahn, die dich zu den Toren des Parks bringt.
<G-vec00340-002-s107><take.bringen><en> Once there, take the monorail and you’ll find yourself near the front gates of the park.
<G-vec00340-002-s108><take.bringen><de> In nur 20 Minuten bringt Sie die längste Umlaufseilbahn Deutschlands von der Talstation auf 1.220 Meter Höhe.
<G-vec00340-002-s108><take.bringen><en> Germany's longest circulating cable car will take you up 1,220 meters from the valley station in just 20 minutes.
<G-vec00340-002-s109><take.bringen><de> Das El U-Bahnsystem bringt Sie glücklicherweise überall hin und ist auch die beste Transportverbindung zu den beiden Flughäfen von Chicago, Midway und O'Hare.
<G-vec00340-002-s109><take.bringen><en> Luckily, the El subway system can take you just about anywhere you need to go and is the most convenient form of transportation to Chicago's two international airport systems: Midway and O'Hare.
<G-vec00340-002-s110><take.bringen><de> Unser Fahrer wartet auf Sie am Hafen von Hurghada und bringt Sie zurück in Ihr Hotel.
<G-vec00340-002-s110><take.bringen><en> Our driver will wait for you at Hurghada Port to take you back to your hotel.
<G-vec00340-002-s111><take.bringen><de> Ein Kurztrip bringt Sie zurück zum zweitgrößten See Südamerikas, dem General Carrera.
<G-vec00340-002-s111><take.bringen><en> A short drive will take you back to the second largest lake in South America, General Carrera Lake.
<G-vec00340-002-s112><take.bringen><de> Bringt mich wundernd durch diese Straßen..
<G-vec00340-002-s112><take.bringen><en> Take me wondering through these streets
<G-vec00340-002-s113><take.bringen><de> Eine zweite Kabine bringt Sie noch höher hinauf: Bei Sonnenschein finden Sie dort oben noch offenere, äußerst faszinierende Pisten.
<G-vec00340-002-s113><take.bringen><en> A second cable car will then take you even higher: up there, when the sun shines, you can take delight in more open and exhilarating pistes.
<G-vec00342-002-s034><introduce.bringen><de> Sie werden eine Brauerei in Berlin eröffnen und ihre amerikanische Braukunst nach Deutschland bringen.
<G-vec00342-002-s034><introduce.bringen><en> Now, they are about to open a brewery in Berlin and introduce the American brewing arts to Germany.
<G-vec00342-002-s035><introduce.bringen><de> Wir bringen bei jedem Projekt unsere ganzheitliche Perspektive mit ein, damit auch Synergien zwischen Arbeitsweisen, Funktionen oder Abläufen effektiv genutzt werden können.
<G-vec00342-002-s035><introduce.bringen><en> We introduce our holistic perspective into every project, so that synergies between operations, functions, or processes can also be used effectively.
<G-vec00342-002-s036><introduce.bringen><de> Ich persönlich denke, man sollte mehr Sand in die Grüns bringen, um den Wasserabfluss zu verbessern.
<G-vec00342-002-s036><introduce.bringen><en> Personally I think they need to introduce more sand into the greens to improve the drainage.
<G-vec00342-002-s037><introduce.bringen><de> Aber nicht nur der tschechische Gesetzgeber, sondern auch tschechische Gerichte und Behörden können Änderungen für Unternehmer bringen.
<G-vec00342-002-s037><introduce.bringen><en> Changes for entrepreneurs can introduce not only the new Czech laws, but also the Czech courts and administrative authorities.
<G-vec00342-002-s038><introduce.bringen><de> Innofreight sieht seine Aufgabe darin kundenspezifische Technologien auf den Markt zu bringen und den Schienengüterverkehr im Energiebereich zu optimieren.
<G-vec00342-002-s038><introduce.bringen><en> One of Innofreight’s missions is to introduce to the market customer-specific technology and to optimise rail freight transport in the energy field.
<G-vec00342-002-s039><introduce.bringen><de> Wir bringen die privaten und kommerziellen Immobilienverkäufer Teneriffas mit internationalen Käufern zusammen...
<G-vec00342-002-s039><introduce.bringen><en> We introduce both private and professionell vendors to international property buyers...
<G-vec00342-002-s040><introduce.bringen><de> Diese Regeln bringen normalerweise eine limitierte oder geringe Einschränkung für die Nutzung eines speziellen Teilaspekts des Spieles mit sich, erzeugen aber kein Umfeld, welches den Missbrauch des Punkte und Awardsystems erlaubt.
<G-vec00342-002-s040><introduce.bringen><en> These rules typically introduce minor or limited restrictions on how a certain aspect of the game can be used, but do not create or promote an environment that would allow abuse of the scoring/award system.
<G-vec00342-002-s041><introduce.bringen><de> So zeigen wir unseren Auftraggebern Wege zu einem zukunftssicheren technischen Gebäudestandard auf und bringen alternative Lösungsvorschläge ein.
<G-vec00342-002-s041><introduce.bringen><en> As a result, we are able to show our customers methods to achieve sustainable technical building standards and introduce alternative solution proposals.
<G-vec00342-002-s042><introduce.bringen><de> Die Revision der Wiener und der Paris-Brüssel-Konvention bringen eine Anzahl Verbesserungen mit sich.
<G-vec00342-002-s042><introduce.bringen><en> The revisions to the Vienna and Paris/Brussels Conventions do introduce a number of improvements.
<G-vec00342-002-s043><introduce.bringen><de> Mit dem Know-How und der Erfahrung aus über 20 Jahren im weltweiten Containerverkauf, Containervermietung und aus der Schifffahrtsbranche, entstand durch den Firmengründer Olaf Gayko die Überzeugung, einen effizienten und effektiven globalen Container Trader an den Markt zu bringen.
<G-vec00342-002-s043><introduce.bringen><en> With the know-how and the experience of more than 20 years in global container sales, container rentals and in the shipping industry, Olaf Gayko, founder of the company is convinced to introduce an efficient and effective global container trader in the market .
<G-vec00342-002-s044><introduce.bringen><de> Wenn Sie schon etwas in die Schublade stecken, dann wenigstens mit System: Mit unserem Schubladenzubehör bringen Sie schnell Ordnung und Organisation in die Schubladeninhalte.
<G-vec00342-002-s044><introduce.bringen><en> And if you're going to pigeonhole things, then at least be systematic about it: our drawer accessories will quickly introduce order and organisation to the contents of your drawers.
<G-vec00342-002-s045><introduce.bringen><de> Bringen Sie Struktur in Ihre Datenbestände und überlassen Sie es nicht den einzelnen Mitarbeitern oder Abteilungen, wie sie die Medien auf den Servern ablegen: Eine fest definierte und einheitliche Benennung aller Ordner und Unterordner erleichtert das Ablegen und Wiederfinden von Medien – unternehmensweit.
<G-vec00342-002-s045><introduce.bringen><en> Introduce more structure to your database and don’t just leave it to an individual employee or department as they put media on servers: a clearly defined and consistent naming of all folders and subfolders facilitates the storing and retrieval of media – company wide.
<G-vec00342-002-s046><introduce.bringen><de> Und mit der Sängerin TRIXIE WHITLEY bringen wir eine Künstlerin nach Bezau, die seit ihrem neuen Album »Porta Bohemica« bald nicht nur mehr in Insiderkreisen als Superstar gilt.
<G-vec00342-002-s046><introduce.bringen><en> And with singer TRIXIE WHITLEY on stage we introduce an artist to Bezau, who is since her success album »Porta Bohemica« no longer a superstar just in the inner circle.
<G-vec00342-002-s047><introduce.bringen><de> Die in 1957 gegründete Karnevalsgesellschaft Narrhalla 58 bemüht sich diese deutschen Gebräuche zu erhalten und den Club den Hamiltonern näher zu bringen.
<G-vec00342-002-s047><introduce.bringen><en> Founded in 1957 the Mardi Gras Society Narrhalla 58 Hamilton is striving to maintain these German customs and to introduce the club to Hamilton.
<G-vec00342-002-s048><introduce.bringen><de> BERLIN/BEIJING (Eigener Bericht) - Gegen Chinas "Neue Seidenstraße" will sich die EU beim Asien-Europa-Treffen in dieser Woche in Brüssel mit einer neuen "Konnektivitätsstrategie" in Stellung bringen.
<G-vec00342-002-s048><introduce.bringen><en> BERLIN/BEIJING (Own report) - At this week's Asia-Europe Meeting in Brussels, the EU will introduce a new "connectivity strategy" to counter China's "New Silk Road."
<G-vec00342-002-s049><introduce.bringen><de> "Durch die hohen Investitionen in unsere Räumlichkeiten und Personal sind wir in der Lage, weitere neue Produkte auf den Markt zu bringen und unseren Kunden die hohe Servicequalität zu bieten, die sie von der Marke Meech erwarten", erklärt Adam.
<G-vec00342-002-s049><introduce.bringen><en> “By investing heavily in our premises and personnel, we are able to introduce more new products to the market while also providing the high level of service our clients have come to expect from the Meech brand,” explains Adam.
<G-vec00342-002-s050><introduce.bringen><de> Yasmeen Youssef spricht fließend Englisch und Arabisch und erhielt die Möglichkeit, in den Nahen Osten zu reisen, um Orientierungsprogramme ins Leben zu rufen und neuen Mitarbeitern unsere Fairmont-Kultur näher zu bringen.
<G-vec00342-002-s050><introduce.bringen><en> Fluent in both English and Arabic, Yasmeen has had the opportunity to travel to the Middle East to facilitate orientation programs and introduce our Fairmont culture to new employees.
<G-vec00342-002-s051><introduce.bringen><de> Bringen Sie mit der Sammlung kostenloser Symbole von Spark Post eine neue kreative Form der Bildsprache in Ihr Design ein.
<G-vec00342-002-s051><introduce.bringen><en> Introduce a new creative form of imagery to your design with Spark Post’s collection of free icons.
<G-vec00342-002-s052><introduce.bringen><de> Die SP nutzte die Medienaufmerksamkeit, um drei Initiativgesetze zur Verbesserung der Altenpflege durchs Parlament zu bringen.
<G-vec00342-002-s052><introduce.bringen><en> The SP, for its part, used the ensuing media storm to introduce three parliamentary initiatives to improve elderly care.
<G-vec00354-002-s057><express.bringen><de> Als die britische Regierung (1968) den Austritt aus dem Persischen Golf ankündigte, spielte der Sport eine wichtige Rolle, um die nationale Autonomie unter den Protektoraten zum Ausdruck zu bringen.
<G-vec00354-002-s057><express.bringen><en> When the British government announced its departure from the Persian Gulf region (1968), sport played an important role to express national autonomy among the protectorates.
<G-vec00354-002-s058><express.bringen><de> Anfänglich wollten wir nur zum Ausdruck bringen, wo wir herkommen, was unsere Heimat ist.
<G-vec00354-002-s058><express.bringen><en> Initially, we only wanted to express where we come from, to tell people where our home is.
<G-vec00354-002-s059><express.bringen><de> Wir brauchen einen Träger um der Menschheit eine Botschaft der Hoffnung anzubieten, ein Hilfsmittel, damit wir lautstark zum Ausdruck bringen, dass wir lernen wollen, besser miteinander zusammenzuleben,um allen Menschen hier und überall in der Welt eine bessere Zukunft zu sichern.
<G-vec00354-002-s059><express.bringen><en> One needs a vehicle to propose a message of hope to humanity, a tool allowing one to express loud and clear this desire to learn to live better together, to ensure a better future for everyone here and around the world.
<G-vec00354-002-s060><express.bringen><de> Deshalb möchte ich meine Anerkennung für das Engagement dieses Landes zum Ausdruck bringen, die freie Ausübung der Religion zu tolerieren und zu garantieren sowie Extremismus und Hass zu bekämpfen.
<G-vec00354-002-s060><express.bringen><en> I wish to express appreciation for the commitment of this nation to tolerating and guaranteeing freedom of worship, to confronting extremism and hatred.
<G-vec00354-002-s061><express.bringen><de> Die beiden B’s wurden schließlich übereinander gelagert, um die Einheit der Galerie genau durch ihre Unterschiede zum Ausdruck zu bringen.
<G-vec00354-002-s061><express.bringen><en> The two B’s were eventually superimposed to express the gallery’s unity even through its differences.
<G-vec00354-002-s062><express.bringen><de> Astana (Agenzia Fides) – „Man kann versuchen, eine allgemein gültige Regel aufzustellen, die in vielen historischen Perioden und in vielen sprachlichen Situationen gilt: Je mehr die Schöpfer eines neuen Alphabets flexibel und intelligent vorgehen, desto mehr können sie alle Töne des alten Alphabets zum Ausdruck bringen vielleicht sogar deren Aussagefähigkeit verbessern", so Professor Alberto Caplani, der an der Katholischen Universität Mailand als Dozent für Neutestamentliche Linguistik und Exegese unterrichtet, der versucht zu erklären, weshalb die in Kasachstan erwartete Änderung des Alphabets sich als ziemlich schwierig erweist.
<G-vec00354-002-s062><express.bringen><en> Astana (Agenzia Fides) - "You can try to declare a general rule, which applies in many historical periods and in many linguistic situations: the more the creators of a new alphabet are flexible and intelligent, the more they are able to express all the sounds of the old alphabet and perhaps also to improve the expressive abilities": this is what Alberto Camplani, professor of the New Testament philology and exegesis in the Catholic University of Milan, to Agenzia Fides, explaining why the change of alphabet expected in Kazakhstan is proving to be rather problematic.
<G-vec00354-002-s063><express.bringen><de> Erlauben Sie mir schließlich, meine Wertschätzung für die zahlreichen Initiativen zum Ausdruck zu bringen, die zum Wohl der gesamten irakischen Gemeinschaft unternommen worden sind.
<G-vec00354-002-s063><express.bringen><en> Allow me finally to express my appreciation for the many initiatives undertaken for the benefit of the whole Iraqi community.
<G-vec00354-002-s064><express.bringen><de> SALLY möchte Kinder dazu anregen und auffordern, sich eine eigene Meinung zu bilden und diese auf respektvolle Weise zum Ausdruck zu bringen.
<G-vec00354-002-s064><express.bringen><en> SALLY aims to inspire and challenge children to form their own opinion and express it in a respectful manner.
<G-vec00354-002-s065><express.bringen><de> Wenn wir gleich die Straße entlanggehen werden, wollen wir uns verbinden mit unseren vielen Brüdern und Schwestern, die nicht die Freiheit haben, ihren Glauben an Jesus, den Herrn, zum Ausdruck zu bringen.
<G-vec00354-002-s065><express.bringen><en> Soon, while we walk along the street, we will feel we are in communion with so many of our brothers and sisters who do not have the freedom to express their faith in the Lord Jesus.
<G-vec00354-002-s066><express.bringen><de> Mit diesem konkreten Vorgehen können wir die einheimische Natur unterstützen und unsere Verantwortlichkeit für das Gemeingut zum Ausdruck bringen.
<G-vec00354-002-s066><express.bringen><en> By implementing out these measures we can help the local environment and express our responsibility for the common good.
<G-vec00354-002-s067><express.bringen><de> Bereits seit 60 Jahren stellt die Marke ASTOR kosmetische Produkte her, die den Frauen helfen sollen, ihren eigenen persönlichen Stil zum Ausdruck zu bringen und das Schönste, was in ihnen ist zu wecken und zu unterstreichen.
<G-vec00354-002-s067><express.bringen><en> For 60 years, ASTOR has made high-quality cosmetics and helped women to express their personal style and awaken and emphasise their inner beauty.
<G-vec00354-002-s068><express.bringen><de> Das berührt die zentrale Fragestellung, die Gefahr und das Risiko auf die man stößt, wenn man Schritt halten will, ganz nah an der essentiellen Einzigartigkeit einer jeden Tafel, es ganz zum Ausdruck zu bringen, aber nur mit hineinzunehmen, was absolut notwendig ist.
<G-vec00354-002-s068><express.bringen><en> This touches the central issue, the danger, the risk encountered in the effort to keep time, close to the essential identity of each panel, to express it fully but to include only what is absolute necessary.
<G-vec00354-002-s069><express.bringen><de> Mit der Erinnerung an die antike Glanzzeit des christlichen Afrika möchten wir unsere tiefe Achtung gegenüber den Kirchen zum Ausdruck bringen, mit denen wir nicht in voller Gemeinschaft stehen: der griechischen Kirche des Patriarchats von Alexandrien, der koptischen Kirche Ägyptens und der äthiopischen Kirche, die den Ursprung und das lehrmäßige und spirituelle Erbe der groben Kirchenväter und Heiligen nicht nur ihres Landes, sondern der ganzen alten Kirche mit der katholischen Kirche gemeinsam haben.
<G-vec00354-002-s069><express.bringen><en> In recalling the ancient glories of Christian Africa, we wish to express our profound respect for the Churches with which we are not in full communion: the Greek Church of the Patriarchate of Alexandria, the Coptic Church of Egypt and the Church of Ethiopia, which share with the Catholic Church a common origin and the doctrinal and spiritual heritage of the great Fathers and Saints, not only of their own land, but of all the early Church.
<G-vec00354-002-s070><express.bringen><de> Deine Kundin liebt es, ihre Persönlichkeit zum Ausdruck zu bringen und ihre verschiedenen Facetten zu zeigen.
<G-vec00354-002-s070><express.bringen><en> Your client loves to express herself and shows the different facets of her personality.
<G-vec00354-002-s071><express.bringen><de> Im Sinne des Unternehmensauftrages "for a safer world" sieht es Frequentis als seine gesellschaftliche Verantwortung und Verpflichtung, einen Beitrag zur Linderung bei Katastrophen zu leisten und damit auch die Solidarität mit den Notleidenden zum Ausdruck zu bringen.
<G-vec00354-002-s071><express.bringen><en> In accordance with the company’s mission statement “for a safer world”, Frequentis considers that it has a social responsibility and obligation to make a contribution to disaster relief and, in this way, to express solidarity with those in need.
<G-vec00354-002-s072><express.bringen><de> Er schreibt, um seinen Besuch anzukündigen und seinen Wunsch zum Ausdruck zu bringen, Rom zu besuchen, und er kündigt die wesentlichen Inhalte seines Kerygmas an; so bereitet er die Stadt auf seinen Besuch vor.
<G-vec00354-002-s072><express.bringen><en> He writes to announce his visit and express his desire to visit Rome, and he announces in advance the essential content of his kerygma; in this way he prepares the City for his visit.
<G-vec00354-002-s073><express.bringen><de> Um die Einzigartigkeit in Bezug auf höchste Qualität und das Streben nach Perfektion zum Ausdruck zu bringen, wurde der neue Markenname „WINAICO“ geschaffen, der von vornherein mit diesen Werten verbunden ist.
<G-vec00354-002-s073><express.bringen><en> In order to express the uniqueness of our commitment to the highest quality and the striving toward perfection, a new brand name, “WINAICO” was created and from early on, tied to these corporate values.
<G-vec00354-002-s074><express.bringen><de> Man hat eine gewisse Vorstellung dessen, was man gern zum Ausdruck bringen möchte und diese Vorstellung fußt im Grunde fast immer auf dem Fundament eines Erfahrungshorizontes aus diversen Klassikern oder deren Abwandlungen.
<G-vec00354-002-s074><express.bringen><en> You have a certain idea of what you would like to express but this idea is almost always based on the foundation of your personal experiences with various classics or their modifications.
<G-vec00354-002-s075><express.bringen><de> Es ist eine Geste, die zu Beginn der Feier vom Leiden und Sterben Christi, am Karfreitag, wiederholt wird, ebenso wie in der monastischen Profeß und in der Diakon-, Priester- und Bischofsweihe, um im Gebet die eigene Ganzhingabe an Gott, das Vertrauen auf ihn auch körperlich zum Ausdruck zu bringen.
<G-vec00354-002-s075><express.bringen><en> This gesture is repeated at the beginning of the celebration of the Passion, on Good Friday, as well as in monastic profession and in the ordination of deacons, priests and bishops in order to express, in prayer, corporally too, complete entrustment to God, trust in him.
<G-vec00355-002-s304><bring.bringen><de> Es besteht keine Fahrmöglichkeit für Sie zum Haus, allerdings wird das Gepäck von uns mit Ihnen hoch gebracht.
<G-vec00355-002-s304><bring.bringen><en> Visitors are not allowed to drive directly to the house, but we will bring your baggage there for you .
<G-vec00355-002-s305><bring.bringen><de> Er spielte auf seiner akustischen Gitarre, während sie an der Tür stand und darauf wartete, dass sie vom Tourmanager zur Band gebracht wurde.
<G-vec00355-002-s305><bring.bringen><en> He was playing his acoustic guitar while she was standing at the doors, waiting for the tour manager to bring her to the band.
<G-vec00355-002-s306><bring.bringen><de> Leider ist es mir ein wenig groß und so wird dieses Kleid mein erstes Stück sein, welches ich jemals zum Schneider gebracht habe.
<G-vec00355-002-s306><bring.bringen><en> Unfortunately the dress a tad too big and therefore it will be my first piece of clothing, ever that I will bring to the tailor.
<G-vec00355-002-s307><bring.bringen><de> Die Anschlussdichte im Festnetz erreichte einen Höchststand von etwa 32 % und ging als Reaktion auf die jüngsten Tarifänderungen, mit denen die Tarife entsprechend den Vorgaben des Besitzstands in größere Übereinstimmung mit den echten Kosten gebracht werden sollen, leicht zurück.
<G-vec00355-002-s307><bring.bringen><en> Fixed network penetration peaked at around 32%, falling back slightly in response to recent price changes designed to bring prices more closely into line with costs as required by the acquis.
<G-vec00355-002-s308><bring.bringen><de> 7:52 Er bat darum, für eine Nacht nach Hause gebracht zu werden.
<G-vec00355-002-s308><bring.bringen><en> 7:52, He asked to bring him to his home for one night.
<G-vec00355-002-s309><bring.bringen><de> Mit meiner täglichen Arbeit an Land hat das aber natürlich wenig zu tun und dieser Anreiz allein hat mich auch nicht zur Tiefsee-Taxonomie gebracht.
<G-vec00355-002-s309><bring.bringen><en> But that has nearly nothing to do with my work on land and that did not bring me to deep-sea taxonomy.
<G-vec00355-002-s310><bring.bringen><de> Der Darlehensnehmer hat es jedoch weder gebracht noch eingezahlt, da er gekommen ist, um Geld zu holen, das er nicht besaß.
<G-vec00355-002-s310><bring.bringen><en> But the borrower did not bring nor did he deposit any money, since he came to the bank to get money he did not have.
<G-vec00355-002-s311><bring.bringen><de> Wir haben auch in der zweiten Saisonhälfte technische Neu- und Weiterentwicklungen gebracht, sie haben aber leider nicht den erwarteten Zuwachs an Performance gebracht.
<G-vec00355-002-s311><bring.bringen><en> We continued to bring new and further stages of technical developments into the car in the second half of the season, but unfortunately they didn’t produce the performance gains we expected.
<G-vec00355-002-s312><bring.bringen><de> Daher mussten zunächst die unterschiedlichen Laufstärke der einzelnen Werke auf ein einheitliches Niveau gebracht werden, da man im Flugzeug natürlich nicht ständig lauter und leiser drehen kann.
<G-vec00355-002-s312><bring.bringen><en> For this reason, it was first necessary to bring the different volumes of individual works to a unified level, as the volume can’t constantly be turned up and down on an aircraft, of course.
<G-vec00355-002-s313><bring.bringen><de> Nach dem Motto: „Heute oder morgens gebracht, morgen oder schon abends gemacht“ bietet W. Klinger einen bei den Kunden gefragten Fullservice.
<G-vec00355-002-s313><bring.bringen><en> Under the slogan “Bring it today, best in the morning, collect it tomorrow or already this evening”, W. Klinger is able to promise customers a highly appreciated full service.
<G-vec00355-002-s314><bring.bringen><de> 3 Als er mich dorthin gebracht hatte, erschien plötzlich ein Mann, der glänzend wie Erz aussah.
<G-vec00355-002-s314><bring.bringen><en> 3 And he proceeded to bring me there, and, look! there was a man.
<G-vec00355-002-s315><bring.bringen><de> 11 Deine Tore sollen stets offen stehen und weder Tag noch Nacht zugeschlossen werden, dass der Reichtum der Völker zu dir gebracht und ihre Könige herzugeführt werden.
<G-vec00355-002-s315><bring.bringen><en> 11 Your gates shall be open continually; day and night they shall not be shut, that people may bring to you the wealth of the nations, with their kings led in procession.
<G-vec00355-002-s316><bring.bringen><de> Auf allen Schiffen steht ein Rollstuhl zur Verfügung, den die Passagiere ausschließlich dafür nutzen können, in die Kabine gebracht zu werden.
<G-vec00355-002-s316><bring.bringen><en> There is a wheelchair available on all ships to use exclusively to bring the passenger into the cabin.
<G-vec00355-002-s317><bring.bringen><de> Er hat keine wirkliche Sozialreform zuwege gebracht, obwohl er für die ganze Welt zu einer mächtigen Bedrohung und einer Herausforderung geworden ist.
<G-vec00355-002-s317><bring.bringen><en> It did not bring about a real social reform, although it became for the whole world a powerful threat and a challenge.
<G-vec00355-002-s318><bring.bringen><de> Für das Auge meist unsichtbar unter der Produktoberfläche verborgen, müssen elektronische Systeme mit höchster Komplexität in extrem kurzer Zeit zu einem akzeptablen Preis entworfen, hergestellt und auf den Markt gebracht werden und absolut zuverlässig sowie energieeffizient funktionieren.
<G-vec00355-002-s318><bring.bringen><en> Hidden from view beneath the product surface of all highly complicated electronic systems is the pressure to develop at an acceptable price, manufacture and bring onto the market an utterly reliable as well as energy efficient product.
<G-vec00355-002-s319><bring.bringen><de> Das Ändern der Seitenreihenfolge innerhalb einer PDF und das anschließende Speichern hat nicht den gewünschten Effekt gebracht.
<G-vec00355-002-s319><bring.bringen><en> Changing the page order within a PDF and then saving did not bring the desired effect.
<G-vec00355-002-s320><bring.bringen><de> Meine sämtlichen Bücher habe ich gerettet und mit nach Deutschland gebracht.
<G-vec00355-002-s320><bring.bringen><en> I could rescue all my books and bring them back to Germany.
<G-vec00355-002-s321><bring.bringen><de> Schließlich möchte jeder, dass dieses einzigartige Stück nach Hause gebracht wird.
<G-vec00355-002-s321><bring.bringen><en> Afterall, everyone wants that unique piece to bring back home.
<G-vec00355-002-s322><bring.bringen><de> Wir hoffen das diese Seiten, die ständig auf den neusten Stand gebracht werden, ihnen helfen werden ihren Aufenthalt so angenehm wie möglich im Voraus zu gestalten.
<G-vec00355-002-s322><bring.bringen><en> We hope that these pages, which are constantly updated in order to bring you the very latest on our holiday menu, will help you plan your stay in advance.
<G-vec00355-002-s082><fetch.bringen><de> Mit der gut entwickelten MLM Lead Capture Page bringen Sie Ihr MLM-Geschäft auf den Höhepunkt.
<G-vec00355-002-s082><fetch.bringen><en> Keep the thoughts of your business transparent so that it will fetch you the good MLM Lead Capture Page.
<G-vec00355-002-s083><fetch.bringen><de> 4 Man soll euch ein wenig Wasser bringen und eure Füße waschen, und lehnt euch unter den Baum.
<G-vec00355-002-s083><fetch.bringen><en> But I will fetch a little water, and wash ye your feet, and rest ye under the tree.
<G-vec00355-002-s085><fetch.bringen><de> Diese Knochen bringen Millionen von Dollar ein und die Branche wächst und wächst.
<G-vec00355-002-s085><fetch.bringen><en> These bones fetch millions of dollars and the industry is growing. 2.
<G-vec00355-002-s086><fetch.bringen><de> Daher verwendete er eine noch mächtigere Formel und der Teufel musste die richtige Urkunde bringen.
<G-vec00355-002-s086><fetch.bringen><en> So he used an even more powerful magic formula and the devil had to fetch the right paper.
<G-vec00355-002-s057><yield.bringen><de> Alle wirksamen Formen der Zusammenarbeit, die ein bestimmtes Ergebnis bringen, sind willkommen.
<G-vec00355-002-s057><yield.bringen><en> Any effective forms of cooperation that yield concrete results are welcome.
<G-vec00355-002-s058><yield.bringen><de> Generell kann man sagen, dass Anreize bessere Ergebnisse bringen als Zwang.
<G-vec00355-002-s058><yield.bringen><en> Generally, one could say that incentives yield better results than coercion.
<G-vec00355-002-s059><yield.bringen><de> Laß die Berge den Frieden bringen unter das Volk und die Hügel die Gerechtigkeit.
<G-vec00355-002-s059><yield.bringen><en> 3 That the mountains may yield their bounty for the people,
<G-vec00355-002-s060><yield.bringen><de> Die gut strukturierten Skripte von materialo® INTEGRATE sind einfach zu verstehen und bringen durch ihre unkomplizierte Integration schnell Erfolge.
<G-vec00355-002-s060><yield.bringen><en> The well-structured materialo® Integrate scripts are easy to understand and yield rapid success thanks to their uncomplicated integration.
<G-vec00355-002-s061><yield.bringen><de> Er bleibe risikoavers, suche aber dennoch nach solchen Investitionen, welche den höchsten Return on Investment bringen.
<G-vec00355-002-s061><yield.bringen><en> He stays risk averse, yet searches for those investments that will yield the highest return.
<G-vec00355-002-s062><yield.bringen><de> Man kann natürlich Yoga auch wie einen Turnier-Sport betreiben, aber nur schon die regelmäßige Ausübung von einfachen Posen und Sequenzen, wird viele Nutzen mit sich bringen.
<G-vec00355-002-s062><yield.bringen><en> One can of course practice yoga like any competitive sport, but even doing some simple postures regularly, will yield many benefits.
<G-vec00355-002-s063><yield.bringen><de> Obwohl die Entlastung der Breitband-Datendienste in der Regel den größten Einfluss hat, kann die Verlagerung des Sprachverkehrs auf WLAN einen bedeutenden Vorteil bringen.
<G-vec00355-002-s063><yield.bringen><en> While offloading broadband data services typically has the most impact, moving voice traffic to Wi-Fi can yield a significant benefit. Mitel Mobile Products
<G-vec00355-002-s064><yield.bringen><de> Die Besetzung wird nicht nur keine Zahlungen bringen, sondern auch die Zahlung von Reparationen unmöglich machen.
<G-vec00355-002-s064><yield.bringen><en> The occupation will not only yield no payments but will render the payment of reparations impossible.
<G-vec00355-002-s065><yield.bringen><de> Ungünstige internationale Entwicklungen führen zu einer erheblichen Ausweitung der Renditeunterschiede und bringen bedeutende Verluste mit sich.
<G-vec00355-002-s065><yield.bringen><en> Negative international developments lead to a sharp widening of yield spreads translating into significant losses.
<G-vec00355-002-s066><yield.bringen><de> 22 Fürchtet euch nicht, ihr Tiere auf dem Felde; denn die Auen in der Steppe grünen, und die Bäume bringen ihre Früchte, und die Feigenbäume und Weinstöcke tragen reichlich.
<G-vec00355-002-s066><yield.bringen><en> 2:22: Don't be afraid, you animals of the field; For the pastures of the wilderness spring up, For the tree bears its fruit. The fig tree and the vine yield their strength.
<G-vec00355-002-s067><yield.bringen><de> Du bist die Waffe: Es ist am Besten, sich für eine Waffe zu entscheiden und dessen Feinheiten zu erlernen – wie weit sie reicht, wie lang es benötigt sie zu schwingen, welche Knöpfe bringen die besten Attacken.
<G-vec00355-002-s067><yield.bringen><en> You are the weapon: It’s best to stick with one weapon and learn its intricacies — how far it reaches, how long it takes to swing, which buttons yield the best attacks.
<G-vec00355-002-s068><yield.bringen><de> Ob man daher hört, chantet, sich erinnert oder verehrt - all diese Tätigkeiten werden das gleiche Ergebnis bringen.
<G-vec00355-002-s068><yield.bringen><en> Therefore whether one hears, chants, remembers or worships, his activities will yield the same result.
<G-vec00355-002-s069><yield.bringen><de> Deshalb bringen solche Begegnungen gewißlich grenzenloses Glück und Frieden hervor.
<G-vec00355-002-s069><yield.bringen><en> Thus it is certain that such reunions will yield boundless happiness and peace.
<G-vec00355-002-s070><yield.bringen><de> In der Begründung der Organisatoren heißt es: Der Laser sei ein perfektes Beispiel dafür, wie eine wissenschaftliche Entdeckung der Gesellschaft revolutionäre Vorteile bringen kann, etwa in den Bereichen Kommunikation, Gesundheitswesen und vielen anderen.
<G-vec00355-002-s070><yield.bringen><en> In the organizers´ statement it says the laser was a perfect example of how a scientific discovery can yield revolutionary benefits to society, such as in communication, healthcare and much more. Related News
<G-vec00355-002-s071><yield.bringen><de> Sogar die kleinste Veränderung kann spürbare Erfolge bringen.
<G-vec00355-002-s071><yield.bringen><en> Even the smallest changes can yield significant results.
<G-vec00355-002-s072><yield.bringen><de> 16 Ephraim ist geschlagen; ihre Wurzel ist verdorrt, daß sie keine Frucht mehr bringen können.
<G-vec00355-002-s072><yield.bringen><en> 16 Ephraim will be struck down - their root will be dried up; they will not yield any fruit.
<G-vec00355-002-s073><yield.bringen><de> Wenn das nicht der Fall wäre, würde sich der Verbraucher für das entscheiden, was ihm den größten Gewinn bringen würde.
<G-vec00355-002-s073><yield.bringen><en> If this wasn’t the case, the consumer would go for what would yield them the most profit.
<G-vec00355-002-s074><yield.bringen><de> 29 Und Gott sprach: Sehet da, ich habe euch gegeben alle Pflanzen, die Samen bringen, auf der ganzen Erde, und alle Bäume mit Früchten, die Samen bringen, zu eurer Speise.
<G-vec00355-002-s074><yield.bringen><en> Take charge of the fish of the sea, the birds in the sky, and everything crawling on the ground.” 29 Then God said, “I now give to you all the plants on the earth that yield seeds and all the trees whose fruit produces its seeds within it.
<G-vec00355-002-s075><yield.bringen><de> Daneben gibt es noch sechs weitere Bingos, die fast ebenso viele Punkte bringen.
<G-vec00355-002-s075><yield.bringen><en> Besides, there are six further bingos which yield almost as many points.
<G-vec00359-002-s047><lead.bringen><de> [Buchtipp von Beat Mazenauer] Turbulente Zeiten bringen turbulente Leben hervor - und eine Literatur, die solche Turbulenzen einzufangen versucht.
<G-vec00359-002-s047><lead.bringen><en> [book tip by Beat Mazenauer] Turbulent times lead to turbulent lives – and literature, which attempts to capture this turbulence.
<G-vec00366-002-s156><incorporate.bringen><de> Zusätzlich bringen sie Elemente aus folkloristischen Tänzen wie Flamenco und dem türkischen Zeybek mit ein und zitieren immer wieder das klassische Ballett; nicht zuletzt sind das einzige Bühnenbild drei Ballettstangen, die in erstaunlichen Variationen eingesetzt werden.
<G-vec00366-002-s156><incorporate.bringen><en> Additionally, they incorporate elements of folkloristic dances like flamenco and Turkish Zeybek, time and again citing classical ballet; not the least part being the stage decoration, consisting of three barres which come into use in startling variations.
<G-vec00366-002-s157><incorporate.bringen><de> Ziel von Audi ist es, die Sitzbezüge so komplett in den Recycling-Kreislauf zu bringen.
<G-vec00366-002-s157><incorporate.bringen><en> The goal at Audi is to fully incorporate the car seat covers into the recycling loop.
<G-vec00366-002-s158><incorporate.bringen><de> Lehrende aus der Praxis und Forschungs- und Entwicklungsprojekte am Studiengang bringen aktuelle Themen in den Unterricht ein.
<G-vec00366-002-s158><incorporate.bringen><en> Lecturers who work in the field and research and development projects during the degree programme will incorporate current issues into the tuition.
<G-vec00366-002-s159><incorporate.bringen><de> Wir bringen unsere gesammelte Erfahrung aus verschiedenen Industrien und Branchen in die Beratung mit ein.
<G-vec00366-002-s159><incorporate.bringen><en> We incorporate our accumulated experience from different industries and areas into the consultation.
<G-vec00369-002-s154><engage.bringen><de> Um die Jugend in der Côte d’Ivoire von der Thematik zu überzeugen und sie dazu zu bringen, sich gegen Mangelernährung einzusetzen, werden Blogs, soziale Netzwerke wie Facebook und Twitter genutzt.
<G-vec00369-002-s154><engage.bringen><en> In order to convince the youth in Côte d’Ivoire of the subject and to encourage them to engage themselves in the fight against malnutrition, blogs, social networks such as Facebook and Twitter are used.
<G-vec00369-002-s155><engage.bringen><de> Ziel ist es dabei, über das Thema des Welttheaters auf den ersten Blick kaum vereinbar scheinende Werke in einen fruchtbaren Dialog zu bringen, damit sie sich in einem Wechselspiel untereinander zu einer großen, assoziativen Erzählung verbinden.
<G-vec00369-002-s155><engage.bringen><en> The objective is to engage what at first sight seem like scarcely compatible works in a fruitful dialogue by the use of the 'Theatre of the World' theme so that their interplay links them into a large associative narrative.
<G-vec00369-002-s156><engage.bringen><de> Die Kreaturen, die die Wahrheit suchen, um daraus Energie und Macht zu entziehen aber in ihr Inneres keine Umwandlungsarbeit zustande bringen, werden, ohne es zu bemerken, ununterbrochen durch den Trennungs-Geist der Finsternis beraubt, und ihr innerer Tempel bleibt erloschen und leer; indem das Wort sich im Gejammer verliert.
<G-vec00369-002-s156><engage.bringen><en> The created beings who search the Truth to derive energy and power from the Truth itself but do not engage in a work of inner transformation of their being, without noticing it, are incessantly robbed from the spirit of separation of darkness and their spiritual temple remain dark and empty, whereas the word dissipates itself in lamentation.
<G-vec00369-002-s157><engage.bringen><de> Langfristige Strategien sind insofern innovativ, als sie Regierungen eine Plattform bieten, um die Bürger dazu zu bringen, über die Zukunft nachzudenken, die sie wollen, und sich selbst zu organisieren, um diese zu erreichen.
<G-vec00369-002-s157><engage.bringen><en> Long-term strategies are innovative in that they provide a platform for governments to engage citizens to think about the future they want, and to get themselves organized to deliver it.
<G-vec00369-002-s158><engage.bringen><de> Mit einfallsreichen Features und lebendigen Inhalten übersetzen wir die neuesten Trends für unsere Kunden und bringen ihnen unser Angebot durch eine detaillierte Produktdarstellung, persönliche Empfehlungen oder smarte Suchmöglichkeiten auf neuen Wegen näher.
<G-vec00369-002-s158><engage.bringen><en> Using creative features and lively content, Zalando translates the latest trends for our customers and engage them in new ways through detailed product presentations, personal recommendations and smart search functions.
<G-vec00369-002-s159><engage.bringen><de> Es ist daher notwendig, die apostolische Arbeit als eine echte Mission innerhalb der Herde, die die katholische Kirche in Brasilien bildet, dadurch in Gang zu bringen, daß man eine methodische und intensive Evangelisierung mit Blick auf ein persönliches und gemeinschaftliches Festhalten an Christus fördert.
<G-vec00369-002-s159><engage.bringen><en> Consequently, there is a need to engage in apostolic activity as a true mission in the midst of the flock that is constituted by the Catholic Church in Brazil, and to promote on every level a methodical evangelization aimed at personal and communal fidelity to Christ.
<G-vec00369-002-s160><engage.bringen><de> Treibende Kraft bei der Sammlungsgründung war der Gedanke, die Kunst in einen Dialog zu den Mitarbeitern innerhalb des Unternehmens zu bringen.
<G-vec00369-002-s160><engage.bringen><en> The notion of getting employees within the company to engage in a dialog with art was a key objective when the collection was first started.
<G-vec00369-002-s161><engage.bringen><de> Zentrales Interesse der Bundesregierung und ihrer Partner in der Internationalen Gemeinschaft ist es, eine weitere Eskalation der Gewalt in Burundi zu verhindern und die Konfliktparteien zu einem politischen Dialog an einen Tisch zu bringen.
<G-vec00369-002-s161><engage.bringen><en> The chief concern of the Federal Government and its partners within the international community is to avoid a further escalation of the violence in Burundi and get the conflict parties to the table to engage in political dialogue.
<G-vec00369-002-s190><put.bringen><de> Deshalb sage ich, schon die einfache Tatsache, dass die Frage eines Fünfjahrplans der volkswirtschaftlichen Entwicklung vor den Parteitag gebracht wird, schon diese Tatsache ist ein Zeichen für die qualitative Besserung unserer leitenden Planarbeit.
<G-vec00369-002-s190><put.bringen><en> That is why I say that even the mere fact that the question of a five-year plan of development of the national economy has been put on the congress agenda, even this fact is a sign of the qualitatively higher level of our leadership in planning.
<G-vec00369-002-s191><put.bringen><de> Wird ein Los abgelehnt, so ergreift die notifizierte Stelle oder die zuständige Behörde geeignete Maßnahmen, um zu verhindern, dass das Los in Verkehr gebracht wird.
<G-vec00369-002-s191><put.bringen><en> If a lot is rejected, the notified body or the competent authority must take appropriate measures to prevent that lot's being put on the market.
<G-vec00369-002-s192><put.bringen><de> Die Verfolgung der letzten Jahre hat mir und meiner Familie große Schwierigkeiten gebracht.
<G-vec00369-002-s192><put.bringen><en> "The persecution over the past several years has put me and my family in great difficulty.
<G-vec00369-002-s193><put.bringen><de> Somit ist in Ordnung gebracht, was das Priester/Kobra Team angerichtet hat und es verbleibt keine Schuld, im Sinne von „noch etwas zu erledigen“.
<G-vec00369-002-s193><put.bringen><en> Like that I put back in order what the priest/cobra has caused and no guilt remains in the sense of the feeling “there is still something to be taken care of”.
<G-vec00369-002-s194><put.bringen><de> Sie hat aber auch schon komplett choreografierte Shows für 16 Tänzerinnen auf die Bühne gebracht.
<G-vec00369-002-s194><put.bringen><en> But she has also put fully choreographed shows for sixteen dancers on stage before.
<G-vec00369-002-s195><put.bringen><de> Hintergrund der Schaffung der Kommission ist, dass Stoffe, die bislang vorwiegend oder ausschließlich in Arzneimitteln verwendet wurden, vermehrt als Lebensmittel oder Lebensmittelzutat in Verkehr gebracht werden.
<G-vec00369-002-s195><put.bringen><en> The main reason for creating the new commission is that substances, which until recently were mainly or only used in drugs, are increasingly put into circulation as foodstuffs or foodstuff ingredients. .
<G-vec00369-002-s196><put.bringen><de> Wie auch immer, das Karma, das mich dorthin gebracht hätte, war irgendwie nicht mit mir verbunden, aber ich stand nicht über dem Karma.
<G-vec00369-002-s196><put.bringen><en> However, the karma that would have put me there was somehow not connected to me but I was not beyond karma.
<G-vec00369-002-s197><put.bringen><de> Sechs Milliarden Kunststofftragetaschen wurden im Jahr 2012 in Deutschland in Verkehr gebracht.
<G-vec00369-002-s197><put.bringen><en> In 2012, six billion plastic carrier bags were put in circulation in Germany.
<G-vec00369-002-s198><put.bringen><de> Immerhin war das ein großes Ereignis was ich da hinter mich gebracht habe.
<G-vec00369-002-s198><put.bringen><en> After all, this was a big event which I have since put behind me.
<G-vec00369-002-s199><put.bringen><de> Diese Angelegenheit hat beklagenswerterweise an Übersimplifizierung gelitten, und sie hat viele Leute dazu gebracht, sich in eine falsche Position zu begeben.
<G-vec00369-002-s199><put.bringen><en> This matter has suffered lamentably from over-simplification, and has resulted in many people being put into a false position.
<G-vec00369-002-s200><put.bringen><de> Als Ergebnis dieses Arbeitsvorgangs werden die Steine unter jene Schicht aus feinem, lebenswichtigem Boden gebracht.
<G-vec00369-002-s200><put.bringen><en> As a result of this operation the stones will be put under the layer of fine, vital soil.
<G-vec00369-002-s201><put.bringen><de> Daraufhin wurde Nicole auf eine Bühne gebracht, die extra dafür neben dem Hauptaltar errichtet wurde.
<G-vec00369-002-s201><put.bringen><en> Nicole was then put on a stage which was erected especially for the occasion next to the main altar.
<G-vec00369-002-s202><put.bringen><de> «Wir können jetzt sicher sein, dass die Entscheidungen, die wir getroffen haben, den Planeten auf den Weg der Heilung gebracht haben», sagt Susan Solomon, Hauptautorin der Studie.
<G-vec00369-002-s202><put.bringen><en> Professor Solomon said, “We can now be confident that the things we’ve done have put the planet on a path to heal.
<G-vec00369-002-s203><put.bringen><de> 27 Hättest du mein Geld wenigstens auf die Bank gebracht, dann hätte ich es bei meiner Rückkehr mit Zinsen zurückerhalten.
<G-vec00369-002-s203><put.bringen><en> 27 Then you ought to have put my money [d]in the bank, and on my arrival I would have received my money back with interest.
<G-vec00369-002-s204><put.bringen><de> Jede der in den Abschnitten B und C genannten Behandlungen muss in dem Begleitdokument gemäß Artikel 185c verzeichnet werden, mit dem die entsprechend behandelten Erzeugnisse in den Verkehr gebracht werden.
<G-vec00369-002-s204><put.bringen><en> Each of the processes referred to in points B and C shall be recorded on the accompanying document, as provided for in Article 185c, under cover of which the products having undergone the processes are put into circulation.
<G-vec00369-002-s205><put.bringen><de> Nachdem Sie Ihren Körper im Trab gebracht haben, können Sie sich bei einem Abstecher in den Water Park abkühlen - und auf den Wasserrutschen zeigen, wer der Boss ist.
<G-vec00369-002-s205><put.bringen><en> So after you've put your body through a dizzying amount of G-force at Sunway Lagoon's awesome Amusement Park, you can cool off with a trip to the Water Park - and show those waterslides who's boss.
<G-vec00369-002-s206><put.bringen><de> Das Dendrobium nobilé wird wie alle anderen Pflanzen nicht auf die Spur gebracht.
<G-vec00369-002-s206><put.bringen><en> The dendrobium nobilé, just like all other plants, will not be put on the trail.
<G-vec00369-002-s207><put.bringen><de> Salvestrol™ wurde von Prof. Dan Burke in Leicester GB in Zusammenarbeit mit Nature's Defence Research Ltd., Leicester GB auf den Markt gebracht.
<G-vec00369-002-s207><put.bringen><en> Salvestrol™ was launched by prof. Dan Burke in Leicester GB in collaboration with Nature's Defence Research Ltd., Leicester GB and put on the market.
<G-vec00369-002-s208><put.bringen><de> Ich denke auch oft an schöne Rollenspiele und dabei möchte ich Situationen erleben, in denen ich fast um den Verstand gebracht werde.
<G-vec00369-002-s208><put.bringen><en> I also often think of nice roll-up games, and I would like to experience situations in which I am almost put to the brains.
<G-vec00372-002-s101><disrupt.bringen><de> Fällt eine Lok aus, kann dies unseren Sonderzugfahrplan beeinflussen oder gar bis zum Ausfall von Leistungen komplett durcheinander bringen.
<G-vec00372-002-s101><disrupt.bringen><en> If a locomotive breaks down, this can influence our special train timetable or even completely disrupt it until services fail.
<G-vec00372-002-s125><weigh.bringen><de> Die Langners sind eine vierköpfige Familie mit einem ziemlich großen Problem: Gemeinsam bringen sie fast 500 Kilo auf die Waage.
<G-vec00372-002-s125><weigh.bringen><en> The Langners are a family of four sharing a rather big problem: together they weigh almost 500 Kilos on the scales.
<G-vec00372-002-s126><weigh.bringen><de> Beide besitzen die nahezu gleichen Abmessungen von etwa 51 x 30 x 4 Millimetern und bringen lediglich knapp 8 Gramm Masse auf die Waage.
<G-vec00372-002-s126><weigh.bringen><en> Both have nearly the same size of about 51 x 30 x 4 mm (~2.01 x 1.18 x 0.16 inches) and only weigh just under 8 g (~0.3 ounces).
<G-vec00372-002-s127><weigh.bringen><de> Erwähnenswert ist noch der Mobilitätsfaktor: Das Toshiba und das Asus bringen für diese Klasse typische 2,3 kg auf die Waage, das V3 kommt auf schwere 3,2 kg.
<G-vec00372-002-s127><weigh.bringen><en> Both the Toshiba and the Asus weigh 2.3 kg (~5.1), which is typical in this category, but the V3 is heavy at 3.2 kg (~7.1) on the scales.
<G-vec00372-002-s128><weigh.bringen><de> Die Fahrgestelle bringen zwischen 7,5 t und max.
<G-vec00372-002-s128><weigh.bringen><en> The chassis weigh between 7.5 t and max.
<G-vec00372-002-s129><weigh.bringen><de> Denn ein Nachbau in ausgewachsener Grösse würde es etwa auf 100 Kilogramm bringen, das bedeutet mehr Belastung, höherer Energieaufwand und langsamere Bewegungen.
<G-vec00372-002-s129><weigh.bringen><en> A replica with the size of an adult would weigh approximately 100 kg which means a higher load, higher energy requirements and slower movements.
<G-vec00380-002-s108><shed.bringen><de> Schnapp dir deinen DUALSHOCK 3 Wireless-Controller, um Aarus unglaubliche Zustoß- und Teleportationsfähigkeiten erstrahlen zu lassen und Licht ins Dunkel der teuflischen Rätsel zu bringen, die dich erwarten.
<G-vec00380-002-s108><shed.bringen><en> Grab your DUALSHOCK 3 wireless controller to illuminate Aaru’s amazing charging and teleportation abilities, and shed some light on the fiendish puzzles that await you.
<G-vec00380-002-s109><shed.bringen><de> Ich hoffe, dieses Album wird ein wenig Licht in dieses schwarze Loch des Blues-Universums bringen.
<G-vec00380-002-s109><shed.bringen><en> I hope this album will shed some light on what has been a black hole in the blues universe.
<G-vec00380-002-s110><shed.bringen><de> Gert Krell versucht Licht in das Dickicht von Ursachen, Folgen und Verantwortung zu bringen.
<G-vec00380-002-s110><shed.bringen><en> Gert Krell tries to shed light on this conglomeration of causes, consequences and responsibilities.
<G-vec00380-002-s111><shed.bringen><de> Das Hash Marihuana & Hemp Museum und Cannabis News Network haben sich zusammengetan, um Licht in die Geschichte von Cannabis und Hanf zu bringen und zu illustrieren, was die Pflanze wirklich kann.
<G-vec00380-002-s111><shed.bringen><en> The Hash Marihuana & Hemp Museum and Cannabis News Network have joining forces to shed a light on the rich history of cannabis and hemp and illustrate what this plant was and is really capable of.
<G-vec00380-002-s112><shed.bringen><de> "Unsere Ergebnisse bringen mehr Licht in den Alterungsprozess und beweisen, dass die Mitochondrien eine zentrale Rolle für das Altern spielen.
<G-vec00380-002-s112><shed.bringen><en> Our findings can shed more light on the ageing process and prove that the mitochondria play a key part in ageing.
<G-vec00380-002-s113><shed.bringen><de> 22Und Ruben sprach zu ihnen: Vergießet nicht Blut; werfet ihn in diese Grube, die in der Wüste ist, und leget nicht Hand an ihn auf daß er ihn aus ihrer Hand errettete, um ihn wieder zu seinem Vater zu bringen.
<G-vec00380-002-s113><shed.bringen><en> 22And Reuben said to them, "Shed no blood; throw him into this pit here in the wilderness, but do not lay a hand on him"—that he might rescue him out of their hand to restore him to his father.
<G-vec00380-002-s114><shed.bringen><de> Die Ausstellungsstücke bringen auch Licht in das Wirrwarr der Nachkriegsjahre 1945 – 1949 und wie es im Anschluss zur Teilung Deutschlands kam.
<G-vec00380-002-s114><shed.bringen><en> The museum’s exhibits help to shed light on the post-war years 1945 – 1949, as well as the resulting age of divided Germany.
<G-vec00380-002-s115><shed.bringen><de> Das soll nun neues Licht in das komplizierte Gebiet der Vielteilchen-Quantenphysik bringen.
<G-vec00380-002-s115><shed.bringen><en> This should now shed new light on the complicated field of many-body quantum physics.
<G-vec00380-002-s116><shed.bringen><de> Auch in Zukunft stehen wir für Sie bereit, um Licht ins Dunkle zu bringen oder komplexe Sachverhalte kompetent und verständlch aufzulösen.
<G-vec00380-002-s116><shed.bringen><en> We are ready for you also in future to shed light on the dark or resolve complex facts competently and clearly.
<G-vec00380-002-s117><shed.bringen><de> Prof. Dr. Christoph Cremer wird mit hochauflösender Mikroskopie Licht in die Nanostrukturen von Zellen bringen.
<G-vec00380-002-s117><shed.bringen><en> With the aid of high-resolution microscopy, Professor Christoph Cremer is striving to shed light on the nano-structure of cells.
<G-vec00380-002-s118><shed.bringen><de> Wenn die Titanic immer noch torpediert wurde, kann man nur hoffen, dass Forscher eines Tages an diesen Teil des Schiffes gelangen, dessen Studie dazu beitragen wird, Licht in diese Version zu bringen.
<G-vec00380-002-s118><shed.bringen><en> If the Titanic was still torpedoed, one can only hope that someday researchers will get to that part of the ship, the study of which will help to shed light on this version.
<G-vec00380-002-s119><shed.bringen><de> Mit unserer kleinen Brexit-Versand-Newsreihe möchten wir Ihnen helfen, Licht ins Brexit-Dunkel zu bringen.
<G-vec00380-002-s119><shed.bringen><en> With our small Brexit news series, we would like to help you shed some light on the Brexit dark.
<G-vec00380-002-s120><shed.bringen><de> Ziel der im G. Henle Verlag erscheinenden neuen Gesamtausgabe ist es, mittels eines kritischen Apparates die Vielschichtigkeit der Textüberlieferung zu dokumentieren und Transparenz in das oft komplizierte Geflecht von Quellen zu bringen.
<G-vec00380-002-s120><shed.bringen><en> The aim of the new complete edition, published by G. Henle Verlag, is to document the complexity of the sources and their interdependence in a critical apparatus and to shed light on the different editions of the work in question.
<G-vec00380-002-s121><shed.bringen><de> Um also etwas Licht in dieses Thema zu bringen, möchten wir Ihnen jene Maßnahmen vorstellen, die bei 16, die vor fast zehn Jahren installierten, Modulen durchgeführt wurden.
<G-vec00380-002-s121><shed.bringen><en> So in order to shed some lights on this topic, we would like to share with you the analysis realized on 16 modules installed almost ten years ago.
<G-vec00380-002-s122><shed.bringen><de> Sommer cable versucht hierbei Licht ins Dunkel zu bringen: Diese unterschiedlichen Meinungen kommen daher, dass Silber durch die natürliche Oxydation „lebt“.
<G-vec00380-002-s122><shed.bringen><en> Here Sommer cable tries to shed a light into the darkness: those different opinions are because silver is “alive“ due to the natural oxidation.
<G-vec00380-002-s123><shed.bringen><de> Um nun Licht in Wong-Mau’s Genetik zu bringen, beschwor Dr. Thompsen drei seiner Züchter- und Genetikfreunde (C. Cobb, E. Keeler und M. Dmytryk) mit ihm einige Zuchtexperimente zu starten.
<G-vec00380-002-s123><shed.bringen><en> Hoping to shed some light on Wong Mau’s genetic make-up, Dr. Thompson persuaded three of his breeder and geneticist friends (Virginia Cobb, Clyde Keeler and Madeleine Dmytryk) to co-operate with him in a series of breeding experiments.
<G-vec00380-002-s124><shed.bringen><de> Ich danke Frau Professor Margaret Archer für ihre freundlichen Begrüßungsworte und spreche Ihnen allen meine aufrichtige Anerkennung aus für Ihren Einsatz in Forschung, Dialog und Lehre, damit das Evangelium Jesu Christi auch weiterhin Licht bringen möge in die komplexen Situationen einer Welt, die einem raschen Wandel unterworfen ist.
<G-vec00380-002-s124><shed.bringen><en> I thank Professor Margaret Archer for her kind words of greeting, and I express my sincere appreciation to all of you for your commitment to research, dialogue and teaching, so that the Gospel of Jesus Christ may continue to shed light on the complex situations arising in a rapidly changing world.
<G-vec00380-002-s125><shed.bringen><de> In dem abgedunkelten Raum sind Besucher dazu aufgefordert, mithilfe von Taschenlampen selbst „Licht ins Dunkel“ zu bringen.
<G-vec00380-002-s125><shed.bringen><en> In the dark room, visitors have to shed light in the darkness themselves with torches.
<G-vec00380-002-s126><shed.bringen><de> Sie will sein Kriegstrauma verstehen und Licht in die Vergangenheit der Familie bringen.
<G-vec00380-002-s126><shed.bringen><en> She wants to understand his war trauma and shed light on her family’s past.
<G-vec00380-002-s009><topple.bringen><de> Das Schicksal hat jedoch einen niederträchtigen Sinn für Humor: Die Begegnung mit der hitzigen Lula bringt ihre Beziehung ins Wanken – eine Woge von Emotionen bahnt sich in Wim Vandekeybus erschütternden Spielfilmdebüt ihren Weg.
<G-vec00380-002-s009><topple.bringen><en> Yet destiny has a wicked sense of humour; an encounter with the explosive Lula will topple their relationship forever in this harrowing debut drama from Wim Vandekeybus.
<G-vec00382-002-s114><give.bringen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00382-002-s114><give.bringen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00382-002-s115><give.bringen><de> Seit daher hilft sie uns unterstützend dabei, unsere Botschaft ans breite Publikum zu bringen und Kindern und Jugendlichen weltweit durch Spiel und Sport eine bessere Zukunft zu ermöglichen.
<G-vec00382-002-s115><give.bringen><en> Since then she has been helping us to get our message across to the general public and to give children and young people around the world a better future through play and sport.
<G-vec00382-002-s116><give.bringen><de> Jeden Tag bringen tausende Frauen rund um den Globus neue Menschen auf die Welt.
<G-vec00382-002-s116><give.bringen><en> What are the reasons that women today day, thousands of women worldwide give birth to new human life.
<G-vec00382-002-s117><give.bringen><de> Das Trinken von kalter Milch, Eistee und Eiswasser kann vorübergehend Erleichterung bringen.
<G-vec00382-002-s117><give.bringen><en> Sipping cold milk, iced tea and ice water may give temporary relief.
<G-vec00382-002-s118><give.bringen><de> Backlinks von dieser Website werden Ihnen kaum Link Juice bringen.
<G-vec00382-002-s118><give.bringen><en> Backlinks from this site will not give you too much link juice.
<G-vec00382-002-s119><give.bringen><de> Die Weibchen bringen nach einer Tragzeit von 10 bis 13 Monaten 1 bis 6 Junghaie zur Welt.
<G-vec00382-002-s119><give.bringen><en> After a gestation period lasting around 1 year, the females give birth to around 1-15 pups.
<G-vec00382-002-s120><give.bringen><de> Wir bringen den Tod, wir werden ihn ertragen.
<G-vec00382-002-s120><give.bringen><en> We give death, and we know how to endure it.
<G-vec00382-002-s121><give.bringen><de> Dort wurde sie zu Gehirnwäschesitzungen gezwungen, mit dem Ziel, sie dazu zu bringen ihren Glauben an Falun Gong aufzugeben.
<G-vec00382-002-s121><give.bringen><en> There she was forced to go through brainwashing sessions aimed at getting her to give up her belief in Falun Gong.
<G-vec00382-002-s122><give.bringen><de> Oft bringen mir die Leute das Material, oder ich finde es irgendwo.
<G-vec00382-002-s122><give.bringen><en> People often give me material, or I'll find it somewhere.
<G-vec00382-002-s123><give.bringen><de> Mit seinem vierstöckigen Themenpavillon zielte Mexiko darauf ab, den Menschen den Umgang mit der Natur und der Nahrungsproduktion wieder näher zu bringen – inspiriert vom Symbol der traditionellen mexikanischen Küche, dem Mais.
<G-vec00382-002-s123><give.bringen><en> With its four-story theme pavilion, Mexico aimed to give people an understanding of commerce and food production inspired by the symbol of traditional Mexican cuisine, corn.
<G-vec00382-002-s124><give.bringen><de> Rote Fülle - Tomaten, die bei richtiger Pflege eine gute Ernte bringen können.
<G-vec00382-002-s124><give.bringen><en> Red abundance - tomatoes, able to give a good harvest with proper care.
<G-vec00382-002-s126><give.bringen><de> Meine lieben Brüder und Schwestern, Jesus kam in diese Welt, um Hoffnung zu bringen.
<G-vec00382-002-s126><give.bringen><en> My dear loving brothers and sisters, Jesus came in this world to give new hope.
<G-vec00382-002-s127><give.bringen><de> Wenn du es auf diese Schiene bringen willst, kann ich nur sagen, daß wir uns unser kleines Ländle nicht mit Waffengewalt wegnehmen lassen.
<G-vec00382-002-s127><give.bringen><en> If you try to give it this way, I can only say, that we will not let somebody take away this small land from us by force of arms...
<G-vec00382-002-s128><give.bringen><de> Das Personal aus dem örtlichen Büro 610 spielte Videos ab, die Falun Gong verleumdeten und bedrohten die Praktizierenden, um sie dazu zu bringen, ihren Glauben aufzugeben.
<G-vec00382-002-s128><give.bringen><en> The guards there were very cruel to Falun Gong practitioners and forced them to give up their belief by brainwashing and torturing them.
<G-vec00382-002-s129><give.bringen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00382-002-s129><give.bringen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00382-002-s130><give.bringen><de> 18,12 Alles Beste vom Öl und alles Beste vom Wein und Korn, die Erstlingsgabe, die sie dem HERRN bringen, habe ich dir gegeben.
<G-vec00382-002-s130><give.bringen><en> Lev 10:14; 12 All the best of the oil and all the best of the wine and of the grain, the firstfruits of what they give to the LORD, I give to you.
<G-vec00382-002-s131><give.bringen><de> Außerdem hoffe ich, dass wir den Menschen auf der ganzen Welt unser schönes Land etwas näher bringen können.
<G-vec00382-002-s131><give.bringen><en> Aside from that, I hope that we’ll be able to give people a better understanding of our beautiful country.
<G-vec00382-002-s132><give.bringen><de> 12Alles Beste vom Öl und alles Beste vom Wein und Korn, die Erstlingsgabe, die sie dem HERRN bringen, habe ich dir gegeben.
<G-vec00382-002-s132><give.bringen><en> 12 All the best of the oil, and all the best of the vintage, and of the grain, the first-fruits of them which they give unto Jehovah, to thee have I given them.
<G-vec00382-002-s057><put.bringen><de> 30:13 So spricht der Herr, HERR: Ja, ich werde die Götzen zugrunderichten und die Götzen aus Nof wegschaffen, und der Fürst aus dem Land Ägypten wird [bald] nicht mehr sein; und ich werde Furcht in das Land Ägypten bringen.
<G-vec00382-002-s057><put.bringen><en> 30:13 Thus saith the Lord GOD: I will also destroy the idols, and I will cause the things of nought to cease from Noph; and there shall be no more a prince out of the land of Egypt; and I will put a fear in the land of Egypt.
<G-vec00382-002-s058><put.bringen><de> Wichtig ist es auch, möglichst selbst das letzte Geld in den Pot zu bringen, solange dies noch Foldequity erzeugt.
<G-vec00382-002-s058><put.bringen><en> It is also important to put even the last bit of money into the pot as long as this might create more fold equity.
<G-vec00382-002-s059><put.bringen><de> Wir bringen diese Geschichten zusammen zu einem ästhetischen, individuellen, passenden Ganzen in der Gegenwart.
<G-vec00382-002-s059><put.bringen><en> We put these two stories together to create an aesthetic, individual, matching whole in the present.
<G-vec00382-002-s060><put.bringen><de> Die treibende Kraft hinter unseren CSR-Aktivitäten ist unser Wunsch, all jene zum Lächeln zu bringen, die mit Nintendo in Berührung kommen.
<G-vec00382-002-s060><put.bringen><en> To put smiles on the faces of everyone Nintendo touches – this is the driving principle behind our CSR activities.
<G-vec00382-002-s061><put.bringen><de> Bedenken Sie, wie anders Amerika wäre, wenn jeder Amerikaner wüsste, dass es schon das fünfte Mal ist, dass westliche Armeen nach Afghanistan gehen, um dessen Angelegenheiten in Ordnung zu bringen, und wenn sie wüssten, was genau bei den vorherigen Malen passiert ist.
<G-vec00382-002-s061><put.bringen><en> Think how different America would be if every American knew that this is the fifth time Western armies have gone to Afghanistan to put its house in order, and if they had some idea of exactly what had happened on those four previous occasions.
<G-vec00382-002-s062><put.bringen><de> Hat der Ball die Torlinie oder Torbande überschritten, nachdem er zuletzt von einem Angreifer berührt worden war, darf ihn nur der Torwart durch Werfen, Rollen oder durch Abstoß wieder ins Spiel bringen.
<G-vec00382-002-s062><put.bringen><en> When the ball has wholly crossed the goal line after being last touched by a player from the attacking team, it is put back into play by a kick from the goal area by the defending team.
<G-vec00382-002-s063><put.bringen><de> Umso mehr Du einen Charakter in eine Situation voller intensiver Emotionen bringen und die selben Emotionen beim Zuschauer auslösen kannst, wirst Du die wahrgenommene Zeit verlangsamen.
<G-vec00382-002-s063><put.bringen><en> The more you can put your character into a situation of intense emotions, and create those same emotions in the viewer, you will in effect slow down perceived time.
<G-vec00382-002-s064><put.bringen><de> Helfen Sie der unglücklichen Ziege, aus der Grube zu kommen, und verwenden Sie die herabfallenden Kästen, die das unachtsame Tier in eine unangenehme Lage bringen.
<G-vec00382-002-s064><put.bringen><en> Help the unfortunate goat to get out of the pit, using the falling boxes, which are eager to put the careless animal in an awkward position.
<G-vec00382-002-s065><put.bringen><de> Die Masturbation bis zum Orgasmus bevor du die Massage beginnst wird ihr helfen sich in Stimmung zu bringen, und sie wird besser auf weitere sexualle Stimulation eingehen können.
<G-vec00382-002-s065><put.bringen><en> Her masturbating to orgasm before you begin the massage helps to put her in the mood and makes her more responsive to additional sexual stimulation.
<G-vec00382-002-s066><put.bringen><de> Aber wir müssen den Kerl nicht vergessen, zuerst wird es notwendig sein, einen Haarschnitt zu bekommen, eine Maniküre (oder zumindest sich selbst, um die Hände in Ordnung zu bringen).
<G-vec00382-002-s066><put.bringen><en> But still we must not forget about that guy first it will be necessary to get a haircut, a manicure (or at least yourself to put in order the hands).
<G-vec00382-002-s067><put.bringen><de> Wenn sich die erste Begeisterung gelegt hat und die Neubekehrten wieder viele Stunden arbeiten müssen, bloß um Brot auf den Tisch zu bringen, dann brauchen sie Hilfe von anderen Menschen, die ihre Freude am Evangelium teilen.
<G-vec00382-002-s067><put.bringen><en> When the initial excitement subsides and the new converts continue facing the need to work long hours just to put bread on the table, they need others to help them who share the joy of the gospel.
<G-vec00382-002-s068><put.bringen><de> Die Minister werden sich in einer Erklärung dazu verpflichten, die EU im Hochleistungsrechnen an die Weltspitze zu bringen und das vernetzte Fahren grenzüberschreitend zu erproben.
<G-vec00382-002-s068><put.bringen><en> Ministers will sign declarations to put the EU at the forefront of global high-performance computing and to carry out cross-border trials in connected driving.
<G-vec00382-002-s069><put.bringen><de> Allerdings kann ein Mitgliedstaat unter keinen Umständen die Gesamtzahl der Zertifikate, die er in Verkehr bringen möchte, erhöhen.
<G-vec00382-002-s069><put.bringen><en> A Member State may, however, under no circumstance increase the total number of allowances it intends to put into circulation.
<G-vec00382-002-s070><put.bringen><de> Wenn ich den Rücken lang machen will, kann ich die Füße nicht bis auf die Matte bringen.
<G-vec00382-002-s070><put.bringen><en> If I want to keep the back long, then I can’t put my feet flat on the mat.
<G-vec00382-002-s071><put.bringen><de> Zusammen mit einer ausgebildeten Mediatorin und Studierenden arbeiten Streib und Schäfer an neuen Methoden einer entsprechenden Ausbildung für künftige Religionslehrer um das Schlichtungspotential des Christentums auf der Mikro-Ebene Schule zur Anwendung zu bringen.
<G-vec00382-002-s071><put.bringen><en> Streib and Schäfer are working with students and a trained mediator (M.Stockmeier) to develop new training methods for future religion teachers in order to put Christianity’s potential for mediation into practice on this micro level.
<G-vec00382-002-s072><put.bringen><de> Erhöhe die Spannung, indem du das Band verkürzt, bevor du versuchst, mehr Druck auf den Ankerpunkt zu bringen.
<G-vec00382-002-s072><put.bringen><en> Increase tension by shortening up the band before trying to put more pressure on your anchor knot.
<G-vec00382-002-s073><put.bringen><de> Der Wärmetauscher von Recair wird anschließend als unverwechselbare Komponente in Lüftungssysteme eingebaut, die Drittanbieter auf den Markt bringen.
<G-vec00382-002-s073><put.bringen><en> The Recair heat exchanger is then added to ventilation systems put on the market by third parties as a strongly distinguishing component.
<G-vec00382-002-s074><put.bringen><de> Kostbar, von hoher Qualität und mit unverwechselbarem Design: Ringe von Nomination können die Augen aller beschenkten Frauen zum Leuchten bringen.
<G-vec00382-002-s074><put.bringen><en> Precious, high quality, and distinctly unique design: Nomination rings make women’s eyes sparkle with delight when they put them on.
<G-vec00382-002-s075><put.bringen><de> Wer es im Familienalltag gerne etwas strukturierter mag und einigermassen feste Abläufe braucht, für den ist ein Mehrzimmer-Apartment nach unserer Erfahrung eine sinnvolle Wahl: Hier kann man, wie zuhause, in Ruhe für sich und das Kind Essen zubereiten und hat am Abend die Möglichkeit, das Baby ins Bett zu bringen, während man im anderen Zimmer noch ein wenig Zeit für sich hat.
<G-vec00382-002-s075><put.bringen><en> If you like your everyday family life to have more of a structure and need some fixed routines, in our experience a multi-room apartment is sensible choice: here you can, as at home, prepare food for you and the child in peace, and in the evening you can put the baby to bed and have a bit of time to yourselves in another room.
<G-vec00389-002-s027><thwart.bringen><de> Wenn Sie in Spanien sind, müssen Sie sich der Straßenverbrechen bewusst sein, die hauptsächlich den Diebstahl Ihrer Wertsachen wie Geld und Reisepass umfassen, die Sie in eine schreckliche Situation bringen können.
<G-vec00389-002-s027><thwart.bringen><en> When in Spain you must be aware of the street crimes that mainly include stealing of your valuables like money and passport which can thwart you into a dreadful situation.
<G-vec00206-003-s095><make_up.bringen><de> Jetzt liegt es an Shrek, zusammen mit Fiona, Esel und dem Gestiefelten Kater seinen Fehler wiedergutzumachen, um seine Freunde zu retten, seine Welt wieder in Ordnung zu bringen und seine wahre Liebe wiederzufinden.
<G-vec00206-003-s095><make_up.bringen><en> Now it’s up to Shrek to get together with Fiona, Donkey and Puss in Boots in order to make up for his mistake, save his friends, put the world back the way it was and find his true love once more.
<G-vec00206-003-s096><make_up.bringen><de> Erklären Sie ihnen, dass das Ziel der OKRs ist, sie dazu zu bringen, sich nicht gut zu fühlen, wenn sie sich ehrgeizige Objectives setzen und diese verfehlen (solange sie Fortschritte machen).
<G-vec00206-003-s096><make_up.bringen><en> Explain to them that the purpose of the OKR is to also make them feel uncomfortable when they set ambitious goals and miss it (as long as they are making some progress).
<G-vec00206-003-s097><make_up.bringen><de> Sie können mindestens eine beliebte neue Maschine pro Jahr entwickeln und auf den Markt bringen.
<G-vec00206-003-s097><make_up.bringen><en> They can develop at lease one popular new machine in a year, and make it to the market.
<G-vec00206-003-s098><make_up.bringen><de> Deshalb sage ich euch: Solange es einen Agenten der Finsternis unter dem Volk Gottes gibt, wird er andere dazu bringen, ihre erste Liebe zu verlieren.
<G-vec00206-003-s098><make_up.bringen><en> That is why I am telling you that as long as there will be a single agent of darkness among the people of God, he is going to make others lose their first love.
<G-vec00206-003-s099><make_up.bringen><de> Die ausbleibende Übermittlung der personenbezogenen Daten kann jedoch die Unmöglichkeit der Abwicklung der Anfragen des Nutzers mit sich bringen.
<G-vec00206-003-s099><make_up.bringen><en> However, failure to provide personal data may make it impossible to fulfil the user's requests.
<G-vec00206-003-s100><make_up.bringen><de> Mitarbeiter mit 4 Pfoten: Balou Hunde sind gut fürs Betriebsklima, halten uns in Bewegung, fördern die Kommunikation und bringen uns zum Lachen.
<G-vec00206-003-s100><make_up.bringen><en> Employees with 4 paws: Charlie Dogs are good for the working environment; they keep us moving, promote communication and make us laugh.
<G-vec00206-003-s101><make_up.bringen><de> Das Ziel von Huntingtin-Verminderungsmedikamenten ist es, das mutierte Huntington-Gen davon abzuhalten, Zellen dazu zu bringen, ein schädliches Huntingtin-Eiweiß zu produzieren.
<G-vec00206-003-s101><make_up.bringen><en> The goal of huntingtin lowering therapies is to stop the HD mutation - found in the HD gene - from being used by cells to make the huntingtin protein
<G-vec00206-003-s102><make_up.bringen><de> Ehe du deine politische Kampagne planst, sollt du private und finanzielle Angelegenheiten in Ordnung bringen.
<G-vec00206-003-s102><make_up.bringen><en> Before you start to make preparations for your campaign, you should make sure that you have your other affairs all in line.
<G-vec00206-003-s103><make_up.bringen><de> Technisch reicht unser Ehrgeiz noch weiter: Wir wollen den Autopiloten auf die Straße bringen.
<G-vec00206-003-s103><make_up.bringen><en> Technologically, we want to go even further, and aim to make the autopilot ready for the road.
<G-vec00206-003-s104><make_up.bringen><de> Er benötigt dazu entsprechende Kompetenzen, um, wie in diesem Fall, das Angebot seiner Produkte zu bündeln, um es sehr schnell via Internet auf einen breiten Radar der Branche zu bringen.
<G-vec00206-003-s104><make_up.bringen><en> To do this the optician requires the relevant competences in order to, as in this case, bundle together the range of their products and to quickly make it available as broadly as possible to the industry.
<G-vec00206-003-s105><make_up.bringen><de> Er bekommt seinen Erguß und ein Saṅghādisesa obendrein, was zeigt, daß jemand anderen dazu zu bringen, die Anstrengung zu unternehmen, den Faktor der Anstrengung hier erfüllt.
<G-vec00206-003-s105><make_up.bringen><en> He gets his emission and a saṅghādisesa to boot, which shows that getting someone else to make the effort for one fulfills the factor of effort here.
<G-vec00206-003-s106><make_up.bringen><de> » Hier werden Konzepte präsentiert, die öffentlichen Räumen eine Seele geben, sie zum Sprechen bringen können.
<G-vec00206-003-s106><make_up.bringen><en> » Here concepts are presented which give a soul to public spaces and which can make them talk.
<G-vec00206-003-s107><make_up.bringen><de> Ich möchte daher jetzt Meine Anhänger bitten, jeden Tag ein Opfer zu bringen, das mit Leiden vergleichbar ist, um Mir zu helfen, Seelen, die sich zum Zeitpunkt ihres Todes während der Warnung in der Todsünde befinden, zu retten.
<G-vec00206-003-s107><make_up.bringen><en> I now want to ask My followers to make one sacrifice a day akin to suffering to help me save souls in mortal sin at the point of death during The Warning.
<G-vec00206-003-s108><make_up.bringen><de> Ich möchte Sie aufrütteln und zum Nachdenken bringen.
<G-vec00206-003-s108><make_up.bringen><en> think about your thoughts I want to make you think.
<G-vec00206-003-s109><make_up.bringen><de> Du bettest mit einer schlechteren Hand, um eine bessere Hand zum Folden zu bringen.
<G-vec00206-003-s109><make_up.bringen><en> You bet with a worse hand to make a better hand fold.
<G-vec00206-003-s110><make_up.bringen><de> Dabei ist es das Ziel, komplexe Systeme einfacher darzustellen und den Nutzer so schnell und effizient wie möglich an das Ziel seiner Wünsche zu bringen.
<G-vec00206-003-s110><make_up.bringen><en> The goal is to make complex systems easier to understand and to get the user to their destination as quickly and efficiently as possible.
<G-vec00206-003-s111><make_up.bringen><de> Saul aber gedachte, David durch die Hand der Philister zu Fall zu bringen.
<G-vec00206-003-s111><make_up.bringen><en> For Saul thought to make David fall by the hand of the Philistines.
<G-vec00206-003-s112><make_up.bringen><de> Erfreulicherweise kannst du die Schmerzen daheim unter Kontrolle bringen und das durch den Hernie verursachte Unbehagen durch Veränderungen deines Lebensstil lindern.
<G-vec00206-003-s112><make_up.bringen><en> Fortunately, you can manage the pain at home and make lifestyle changes to relieve some hernia discomfort. Steps
<G-vec00206-003-s113><make_up.bringen><de> Und Sie können die Stadt zum vibrieren bringen.
<G-vec00206-003-s113><make_up.bringen><en> And you can make it that the city vibrates.
<G-vec00218-003-s190><move_in.bringen><de> Wir bringen die Luft zum atmen, wir bringen voran und dabei wehen wir dem einen oder anderen auch mal ins Gesicht.
<G-vec00218-003-s190><move_in.bringen><en> We let the air breathe, we move forward and from time to time we will blow into someone’s face.
<G-vec00218-003-s191><move_in.bringen><de> In einer Branche, in der Stillstandzeiten bis zu 2.500 US-Dollar pro Minute kosten können, hilft Flexco der Paketlogistik, Sendungen schnell und sicher von der Sortierung zur Auslieferung zu bringen.
<G-vec00218-003-s191><move_in.bringen><en> In an industry where downtime can cost as much as $2,500 per minute, Flexco helps Parcel Handlers move packages quickly and safely from sortation to delivery.
<G-vec00218-003-s192><move_in.bringen><de> Wir bringen Sie voran.
<G-vec00218-003-s192><move_in.bringen><en> We help you move forward.
<G-vec00218-003-s193><move_in.bringen><de> Sie halten ohne zusätzliche Hilfsmechanismen Türen offen oder geschlossen und bringen Abdeckplatten sicher in Position.
<G-vec00218-003-s193><move_in.bringen><en> Hold doors opened or closed and move panels securely into position without secondary supports.
<G-vec00218-003-s194><move_in.bringen><de> Sie eröffnet Perspektiven und Potenziale, die uns alle weiter nach vorne bringen.
<G-vec00218-003-s194><move_in.bringen><en> It opens up opportunities and potentials that move us all forward.
<G-vec00218-003-s195><move_in.bringen><de> Dann sendet die SPS einen Befehl, um den Roboter für die nächste Prüfung in Position zu bringen.
<G-vec00218-003-s195><move_in.bringen><en> Next, the PLC sends a command to move the robot into position for the next inspection.
<G-vec00218-003-s196><move_in.bringen><de> Alle Wetten mit einem Einsatz von mindestens 0.20€ bringen dich im Abenteuer weiter.
<G-vec00218-003-s196><move_in.bringen><en> Any bets with at least €0.20 in stake will move you forward in the adventure.
<G-vec00218-003-s197><move_in.bringen><de> Dies geschah durch die Hinzufügung des Querschiffs und die Veränderung der Apsis, um den Hochaltar weiter hinten zu bringen und so mehr Platz im Hauptschiff zu gewinnen.
<G-vec00218-003-s197><move_in.bringen><en> This happened through the addition of the transept and the modification of the apse in order to allow to move the altar further backwards and get more space in the main nave.
<G-vec00218-003-s198><move_in.bringen><de> Unsere Tickets bringen jeden voran.
<G-vec00218-003-s198><move_in.bringen><en> Our tickets move you forward.
<G-vec00218-003-s199><move_in.bringen><de> Falls dein Kind nicht aufhören kann zu toben, dann kannst du es an einen stillen, ruhigen Ort bringen und es bitten, eine Minute still zu sein.
<G-vec00218-003-s199><move_in.bringen><en> If your child doesn’t seem to be able to stop, then you can move the child to a quiet calm space and tell the child to be quiet for one minute.
<G-vec00218-003-s200><move_in.bringen><de> Sie unterstrich außerdem, dass alle Sitzungen „Live“ seien, was bedeutet, dass geplante Sitzungen, für die keine Pressekonferenz ansteht, trotzdem eine Zinsanhebung durch das Komitee bringen könnten.
<G-vec00218-003-s200><move_in.bringen><en> She also noted that all meetings are ‘live,’ meaning that planned meetings that didn’t come with a scheduled press conference could still see the Committee move rates.
<G-vec00218-003-s201><move_in.bringen><de> Eine biozentrische Anschauung lehnt die menschliche Gesellschaft nicht ab, will sie aber vom Thron ihres Überlegenheitsstatus stürzen und wieder ins Gleichgewicht mit den anderen Kräften des Lebens bringen.
<G-vec00218-003-s201><move_in.bringen><en> A biocentric view does not reject human society, but does move it out of the status of superiority and puts it into balance with all other life forces.
<G-vec00218-003-s202><move_in.bringen><de> Los Cayos bewegen sich zu einem anderen Tempo und bringen einen fast unmerklich dazu, mit ihnen einzustimmen.
<G-vec00218-003-s202><move_in.bringen><en> Los Cayos move at a different pace, and almost without you noticing they will take you by the hand to move with them.
<G-vec00218-003-s203><move_in.bringen><de> Die Episode zeigt Severide die Entscheidung treffend, Mills auf die Überholspur zu bringen, von Truck zu Squad umzusteigen.
<G-vec00218-003-s203><move_in.bringen><en> The episode will see Severide’s (Taylor Kinney) making a decision to put Mills (Charlie Barnett) on the fast track to move from Truck to Squad.
<G-vec00218-003-s204><move_in.bringen><de> Jede Person, die mindestens einmal sein Hab und Gut an einen anderen Ort bringen musste, weiß genau, wie wichtig eine gute Organisation ist.
<G-vec00218-003-s204><move_in.bringen><en> Anyone, who had at least once to move their belongings from one place to another knows how important good organisation is.
<G-vec00218-003-s205><move_in.bringen><de> Du wirst schon geschickt mit den Pfeil- oder WASD-Tasten umgehen müssen, um den noch lächelnden gelben Ball bis ans Ende zu bringen.
<G-vec00218-003-s205><move_in.bringen><en> You'll have to deal skillfully with the arrow or WASD keys to move the still smiling yellow ball to the end.
<G-vec00218-003-s206><move_in.bringen><de> Praktika bringen auch Unternehmen weiter, weil sie immer wieder motivierte Jungspunde in die Firma spülen, die neue Ideen und einen – zumindest am Anfang – unverklärten Blick aufs Unternehmen mitbringen.
<G-vec00218-003-s206><move_in.bringen><en> Traineeships also move companies forward as they have a constant injection of motivated youngsters into the business who have new ideas and – at least at the beginning – see the company without preconceived views.
<G-vec00218-003-s207><move_in.bringen><de> Damit die Fangemeinde weiterhin Zugriff auf die Geschichten hat, hat die Moderatorin des Projektes, Kylie Lee, beschlossen, das Archiv über das Projekt Open Doors (Offene Türen) ins AO3 zu bringen.
<G-vec00218-003-s207><move_in.bringen><en> Thus, to keep the stories available to the fan community, the fic archive moderator, Kylie Lee, has decided to move the archive to the AO3 via the Open Doors project, which seeks to archive and preserve fan artworks.
<G-vec00218-003-s208><move_in.bringen><de> Dies hat zur Folge, dass sie wertvolle Leads entwickeln und die Verkaufschancen durch den Verkaufstrichter zum Abschluss bringen.
<G-vec00218-003-s208><move_in.bringen><en> As a result, they’ll generate valuable leads and move sales opportunities through the funnel.
<G-vec00261-003-s152><carry_on.bringen><de> Mit einer gewissen Befriedigung dachte ich daran, daß genug Gin im Hause versteckt war, um mich durch die Nacht und über den nächsten Tag zu bringen.
<G-vec00261-003-s152><carry_on.bringen><en> With a certain satisfaction I reflected there was enough gin concealed about the house to carry me through that night and the next day.
<G-vec00261-003-s153><carry_on.bringen><de> Die niederländischsprachigen Medien bringen die Nachrichten im Radio und Fernsehen, in Zeitungen und Zeitschriften auf Niederländisch.
<G-vec00261-003-s153><carry_on.bringen><en> The Dutch-language media carry news broadcasts in Dutch on radio and TV, in newspapers and magazines.
<G-vec00261-003-s154><carry_on.bringen><de> Als die Arbeiter des GM-Werkes in Indianapolis gegen einen Tarifvertrag stimmten, durch den die Löhne gekürzt worden wären, und die UAW-Funktionäre dafür kritisierten, ihn akzeptiert zu haben, organisierte die SEP ein Basiskomitee, um die Rebellion vorwärts zu bringen.
<G-vec00261-003-s154><carry_on.bringen><en> When workers at the Indianapolis GM plant voted down a wage-cutting deal and denounced UAW officials for accepting it, the SEP organized a rank-and-file committee to carry forward the rebellion.
<G-vec00261-003-s155><carry_on.bringen><de> 8 Lifte bringen die Teilnehmer zwischen den Abfahrten immer wieder auf die Berge, nur in Richtung Tal kann wichtige Zeit gutgeschrieben werden.
<G-vec00261-003-s155><carry_on.bringen><en> Eight lifts will carry them back up into the mountains between the descents, and time can only be credited on the valley runs.
<G-vec00261-003-s156><carry_on.bringen><de> Überblick Die hochkomplexe technische Ausstattung von Data Centern und anderen IT-Bereichen und die dort eingesetzten Materialien bringen ein besonders hohes Brandrisiko mit sich.
<G-vec00261-003-s156><carry_on.bringen><en> Overview The highly complex technical equipment of data centers and other IT areas, as well as the materials used there, carry a particularly high risk of fire.
<G-vec00261-003-s157><carry_on.bringen><de> 23:19 Das Erstling von der ersten Frucht auf deinem Felde sollst du bringen in das Haus des HERRN, deines Gottes.
<G-vec00261-003-s157><carry_on.bringen><en> 23:19 Thou shalt carry the firstfruits of the corn of thy ground to the house of the Lord thy God.
<G-vec00261-003-s158><carry_on.bringen><de> 3Wenn ich aber gekommen bin, will ich die, die ihr für bewährt haltet, mit Briefen senden, damit sie eure Gabe nach Jerusalem bringen.
<G-vec00261-003-s158><carry_on.bringen><en> 3 When I arrive, I will send whoever you approve with letters to carry your gracious gift to Jerusalem.
<G-vec00261-003-s159><carry_on.bringen><de> Wir möchten darauf hinweisen, dass wir in unserem Haus keinen Lift haben - aber selbstverständlich helfen wir Ihnen sehr gerne Ihr Gepäck in Ihr Zimmer oder Apartment zu bringen.
<G-vec00261-003-s159><carry_on.bringen><en> We want to inform, that we don't have an elevator - but of course we can help to carry your luggage into your room.
<G-vec00261-003-s160><carry_on.bringen><de> Der erste Hafen dient Fähren, die Passagiere auf die Inseln bringen.
<G-vec00261-003-s160><carry_on.bringen><en> The first port is for the ferry boats that carry passengers to the islands.
<G-vec00261-003-s161><carry_on.bringen><de> Bitte ihn ganz süß und ruhig darum, deine Bücher oder deinen Rucksack in das nächste Unterrichtszimmer zu bringen.
<G-vec00261-003-s161><carry_on.bringen><en> Calmly and sweetly ask him to carry your books or your backpack for you to the next class.
<G-vec00261-003-s162><carry_on.bringen><de> Es ist den Passagieren verboten, in jeglicher Art und Weise Waffen jeder Art und gefährliche Substanzen, wie Sprengstoffe, Gas, Treibstoffe oder andere entzündbare Substanzen, an Bord zu bringen.
<G-vec00261-003-s162><carry_on.bringen><en> It is strictly forbidden to carry any kind of weapon or dangerous materials like explosives, gas, gasoline or other inflammable substances.
<G-vec00261-003-s163><carry_on.bringen><de> Beide Wahlen bringen Konsequenzen mit sich, über die Sie Bescheid wissen sollten.
<G-vec00261-003-s163><carry_on.bringen><en> Both choices carry their own set of consequences that you will need to know about.
<G-vec00261-003-s164><carry_on.bringen><de> Meister rühren nicht an äußeren Kennzeichen, wenn sie kommen, Die äußeren Kennzeichen bringen ihre eigenen Bräuche, ihre eigene Art zu leben mit sich, je nach den klimatischen Einflüssen.
<G-vec00261-003-s164><carry_on.bringen><en> So Masters do not touch the outer labels when they come. The outer labels carry with them their own customs, their own ways of living and climatic influences.
<G-vec00261-003-s165><carry_on.bringen><de> Risikohinweis CFDs und Forex sind Produkte mit Hebelwirkung, die ein hohes Risiko für Ihr Kapital mit sich bringen, so dass Sie möglicherweise mehr als Ihre ursprüngliche Investition verlieren können.
<G-vec00261-003-s165><carry_on.bringen><en> CFDs and Forex are leveraged products and carry a high degree of risk to your capital and it is possible to lose more than your initial investment.
<G-vec00261-003-s166><carry_on.bringen><de> Wenn nun unsere Pflanze durch diesen Process der bestän-digen Erhaltung oder der natürlichen Auswahl immer gesuchtererBlüthen für die Insecten sehr anziehend geworden ist, so wer-den diese, ihrerseits ganz unabsichtlich, regelmäßig Pollen vonBlüthe zu Blüthe bringen: und dass sie dies sehr wirksamzu thun vermögen, konnte ich durch viele auffallende Beispielebelegen.
<G-vec00261-003-s166><carry_on.bringen><en> When our plant, by this process of the continued preservation or natural selection of more and more attractive flowers, had been rendered highly attractive to insects, they would, unintentionally on their part, regularly carry pollen from flower to flower; and that they can most effectually do this, I could easily show by many striking instances.
<G-vec00261-003-s167><carry_on.bringen><de> Dabei fängt die Scheibe recht viel versprechend an: Human Being Human und Warmonger bringen eine gute Energie mit sich, die sich teilweise in den räudigen Entombed Gefilden aufhält.
<G-vec00261-003-s167><carry_on.bringen><en> By the way, Untrue starts very promising: Human Being Human and Warmonger carry a satisfying energy that stays near to Entombed’s mangy sound.
<G-vec00261-003-s168><carry_on.bringen><de> Schwungvoll aufgetragene Farben und Linien, die die Gemälde durchziehen, bringen Spannung in die nicht gegenständliche Kunst.
<G-vec00261-003-s168><carry_on.bringen><en> Sweepingly applied colors and lines that run throughout the paintings, carry the tension to non-representational art.
<G-vec00261-003-s169><carry_on.bringen><de> Von high-tech Fischereifahrzeugen bis hin zu kleinen Booten aus dem Familienbetrieb bringen alle frischen Fisch in den Hafen.
<G-vec00261-003-s169><carry_on.bringen><en> Everything from high tech fishing vessels to small family boats carry fresh fish into the harbour.
<G-vec00261-003-s170><carry_on.bringen><de> Leider bringen die Gezeiten nicht nur gute Dinge in das Wattenmeer.
<G-vec00261-003-s170><carry_on.bringen><en> Unfortunately, the tides don’t carry only good things for the wadden region.
<G-vec00316-003-s152><carry_out.bringen><de> Mit einer gewissen Befriedigung dachte ich daran, daß genug Gin im Hause versteckt war, um mich durch die Nacht und über den nächsten Tag zu bringen.
<G-vec00316-003-s152><carry_out.bringen><en> With a certain satisfaction I reflected there was enough gin concealed about the house to carry me through that night and the next day.
<G-vec00316-003-s153><carry_out.bringen><de> Die niederländischsprachigen Medien bringen die Nachrichten im Radio und Fernsehen, in Zeitungen und Zeitschriften auf Niederländisch.
<G-vec00316-003-s153><carry_out.bringen><en> The Dutch-language media carry news broadcasts in Dutch on radio and TV, in newspapers and magazines.
<G-vec00316-003-s154><carry_out.bringen><de> Als die Arbeiter des GM-Werkes in Indianapolis gegen einen Tarifvertrag stimmten, durch den die Löhne gekürzt worden wären, und die UAW-Funktionäre dafür kritisierten, ihn akzeptiert zu haben, organisierte die SEP ein Basiskomitee, um die Rebellion vorwärts zu bringen.
<G-vec00316-003-s154><carry_out.bringen><en> When workers at the Indianapolis GM plant voted down a wage-cutting deal and denounced UAW officials for accepting it, the SEP organized a rank-and-file committee to carry forward the rebellion.
<G-vec00316-003-s155><carry_out.bringen><de> 8 Lifte bringen die Teilnehmer zwischen den Abfahrten immer wieder auf die Berge, nur in Richtung Tal kann wichtige Zeit gutgeschrieben werden.
<G-vec00316-003-s155><carry_out.bringen><en> Eight lifts will carry them back up into the mountains between the descents, and time can only be credited on the valley runs.
<G-vec00316-003-s156><carry_out.bringen><de> Überblick Die hochkomplexe technische Ausstattung von Data Centern und anderen IT-Bereichen und die dort eingesetzten Materialien bringen ein besonders hohes Brandrisiko mit sich.
<G-vec00316-003-s156><carry_out.bringen><en> Overview The highly complex technical equipment of data centers and other IT areas, as well as the materials used there, carry a particularly high risk of fire.
<G-vec00316-003-s157><carry_out.bringen><de> 23:19 Das Erstling von der ersten Frucht auf deinem Felde sollst du bringen in das Haus des HERRN, deines Gottes.
<G-vec00316-003-s157><carry_out.bringen><en> 23:19 Thou shalt carry the firstfruits of the corn of thy ground to the house of the Lord thy God.
<G-vec00316-003-s158><carry_out.bringen><de> 3Wenn ich aber gekommen bin, will ich die, die ihr für bewährt haltet, mit Briefen senden, damit sie eure Gabe nach Jerusalem bringen.
<G-vec00316-003-s158><carry_out.bringen><en> 3 When I arrive, I will send whoever you approve with letters to carry your gracious gift to Jerusalem.
<G-vec00316-003-s159><carry_out.bringen><de> Wir möchten darauf hinweisen, dass wir in unserem Haus keinen Lift haben - aber selbstverständlich helfen wir Ihnen sehr gerne Ihr Gepäck in Ihr Zimmer oder Apartment zu bringen.
<G-vec00316-003-s159><carry_out.bringen><en> We want to inform, that we don't have an elevator - but of course we can help to carry your luggage into your room.
<G-vec00316-003-s160><carry_out.bringen><de> Der erste Hafen dient Fähren, die Passagiere auf die Inseln bringen.
<G-vec00316-003-s160><carry_out.bringen><en> The first port is for the ferry boats that carry passengers to the islands.
<G-vec00316-003-s161><carry_out.bringen><de> Bitte ihn ganz süß und ruhig darum, deine Bücher oder deinen Rucksack in das nächste Unterrichtszimmer zu bringen.
<G-vec00316-003-s161><carry_out.bringen><en> Calmly and sweetly ask him to carry your books or your backpack for you to the next class.
<G-vec00316-003-s162><carry_out.bringen><de> Es ist den Passagieren verboten, in jeglicher Art und Weise Waffen jeder Art und gefährliche Substanzen, wie Sprengstoffe, Gas, Treibstoffe oder andere entzündbare Substanzen, an Bord zu bringen.
<G-vec00316-003-s162><carry_out.bringen><en> It is strictly forbidden to carry any kind of weapon or dangerous materials like explosives, gas, gasoline or other inflammable substances.
<G-vec00316-003-s163><carry_out.bringen><de> Beide Wahlen bringen Konsequenzen mit sich, über die Sie Bescheid wissen sollten.
<G-vec00316-003-s163><carry_out.bringen><en> Both choices carry their own set of consequences that you will need to know about.
<G-vec00316-003-s164><carry_out.bringen><de> Meister rühren nicht an äußeren Kennzeichen, wenn sie kommen, Die äußeren Kennzeichen bringen ihre eigenen Bräuche, ihre eigene Art zu leben mit sich, je nach den klimatischen Einflüssen.
<G-vec00316-003-s164><carry_out.bringen><en> So Masters do not touch the outer labels when they come. The outer labels carry with them their own customs, their own ways of living and climatic influences.
<G-vec00316-003-s165><carry_out.bringen><de> Risikohinweis CFDs und Forex sind Produkte mit Hebelwirkung, die ein hohes Risiko für Ihr Kapital mit sich bringen, so dass Sie möglicherweise mehr als Ihre ursprüngliche Investition verlieren können.
<G-vec00316-003-s165><carry_out.bringen><en> CFDs and Forex are leveraged products and carry a high degree of risk to your capital and it is possible to lose more than your initial investment.
<G-vec00316-003-s166><carry_out.bringen><de> Wenn nun unsere Pflanze durch diesen Process der bestän-digen Erhaltung oder der natürlichen Auswahl immer gesuchtererBlüthen für die Insecten sehr anziehend geworden ist, so wer-den diese, ihrerseits ganz unabsichtlich, regelmäßig Pollen vonBlüthe zu Blüthe bringen: und dass sie dies sehr wirksamzu thun vermögen, konnte ich durch viele auffallende Beispielebelegen.
<G-vec00316-003-s166><carry_out.bringen><en> When our plant, by this process of the continued preservation or natural selection of more and more attractive flowers, had been rendered highly attractive to insects, they would, unintentionally on their part, regularly carry pollen from flower to flower; and that they can most effectually do this, I could easily show by many striking instances.
<G-vec00316-003-s167><carry_out.bringen><de> Dabei fängt die Scheibe recht viel versprechend an: Human Being Human und Warmonger bringen eine gute Energie mit sich, die sich teilweise in den räudigen Entombed Gefilden aufhält.
<G-vec00316-003-s167><carry_out.bringen><en> By the way, Untrue starts very promising: Human Being Human and Warmonger carry a satisfying energy that stays near to Entombed’s mangy sound.
<G-vec00316-003-s168><carry_out.bringen><de> Schwungvoll aufgetragene Farben und Linien, die die Gemälde durchziehen, bringen Spannung in die nicht gegenständliche Kunst.
<G-vec00316-003-s168><carry_out.bringen><en> Sweepingly applied colors and lines that run throughout the paintings, carry the tension to non-representational art.
<G-vec00316-003-s169><carry_out.bringen><de> Von high-tech Fischereifahrzeugen bis hin zu kleinen Booten aus dem Familienbetrieb bringen alle frischen Fisch in den Hafen.
<G-vec00316-003-s169><carry_out.bringen><en> Everything from high tech fishing vessels to small family boats carry fresh fish into the harbour.
<G-vec00316-003-s170><carry_out.bringen><de> Leider bringen die Gezeiten nicht nur gute Dinge in das Wattenmeer.
<G-vec00316-003-s170><carry_out.bringen><en> Unfortunately, the tides don’t carry only good things for the wadden region.
<G-vec00318-003-s095><get_together.bringen><de> Die Bundeskanzlerin darf sich nicht von der ukrainischen Regierung vereinnahmen lassen, warnt die linksliberale Berliner Zeitung: "Sonst würde sie Deutschlands Rolle als wichtigster Vermittler in dieser Krise aufs Spiel setzen, der sowohl in Kiew als auch in Moskau Gehör findet und derzeit offenbar allein in der Lage ist, die Kontrahenten noch an einen Tisch zu bringen.
<G-vec00318-003-s095><get_together.bringen><en> The German chancellor must not be taken in by the Ukrainian government's manoeuvring, the left-liberal daily Berliner Zeitung warns: "Otherwise she would jeopardise Germany's role as the most important mediator in this crisis, listened to in both Kiev and Moscow and currently able to get the opposing sides to sit down at a table.
<G-vec00318-003-s096><get_together.bringen><de> Wenn Spammer genügend Personen dazu bringen, auf ihre Falschmeldungen zu klicken und ihre Seiten zu besuchen, nehmen sie über die dort angezeigten Werbeanzeigen Geld ein.
<G-vec00318-003-s096><get_together.bringen><en> If spammers can get enough people to click on fake stories and visit their sites, they’ll make money off the ads they show.
<G-vec00318-003-s097><get_together.bringen><de> Hier sind unsere Tipps, um das Gesicht in wenigen Minuten wieder zum Strahlen zu bringen.
<G-vec00318-003-s097><get_together.bringen><en> Here are our tips on how to get back your glow in a flash.
<G-vec00318-003-s098><get_together.bringen><de> Jedes Zimmer hat einen eigenen Holzofen, aber keinen Strom, um Sie so weit wie möglich wieder in die Natur zu bringen:-) Es gibt eine Gemeinschaftsküche und eine Lounge, die über Strom verfügen.
<G-vec00318-003-s098><get_together.bringen><en> Each room has its own wood-burning stove but no electricity, to get you back to nature as much as possible:-) There is a shared kitchen and lounge which do have electricity.
<G-vec00318-003-s099><get_together.bringen><de> Euro-Staaten verlieren einen Anreiz, ihre Haushalte in Ordnung zu bringen.
<G-vec00318-003-s099><get_together.bringen><en> Euro states are losing an incentive to get their budgets in order.
<G-vec00318-003-s100><get_together.bringen><de> Er wollte sie in ein Kloster in Nepal bringen.
<G-vec00318-003-s100><get_together.bringen><en> He wanted them to get to a monastery in Nepal.
<G-vec00318-003-s101><get_together.bringen><de> Nach einer Woche habe er sich dazu entschieden zu fliehen und seine Familie in Sicherheit zu bringen.
<G-vec00318-003-s101><get_together.bringen><en> After a week he decided to try and leave and get his family out.
<G-vec00318-003-s102><get_together.bringen><de> Bei einer Notfall-Reparatur, zum Beispiel weil die Umreifungsmaschine im Produktionsablauf eine entscheidende Rolle spielt, reagiert TITAN sofort und mit höchster Priorität, um Ihre Maschine wieder zum Laufen zu bringen.
<G-vec00318-003-s102><get_together.bringen><en> If an emergency repair is required, because e.g. a strapping machine is essential for the production, TITAN gives instant and highest priority help to get your machine up and running again.
<G-vec00318-003-s103><get_together.bringen><de> Seine Klassenkameraden an der Tamo Landwirtschaftsschule bringen ihn schließlich dazu, sein Zimmer zu verlassen und wieder am Unterricht teilzunehmen, doch zur Verwunderung aller kommt Kusakabe Yuka mit ihrem bürgerlichen Namen Kinoshita Ringo als neue Schülerin in ihre Klasse.
<G-vec00318-003-s103><get_together.bringen><en> His classmates at the Tamo Agriculture School finally are able to get him to leave his room and attend his class, but to everyone's amazement, Kusakabe Yuka (her stage name) comes into the class under the name Kinoshita Ringo as a transfer student.
<G-vec00318-003-s104><get_together.bringen><de> Jetzt war mein einziges Problem, ihr das Geld zu bringen ohne ihr Wissen wo und von dem es kam.
<G-vec00318-003-s104><get_together.bringen><en> Now my only problem was to get the money to her without her knowing where and who it came from.
<G-vec00318-003-s105><get_together.bringen><de> NEUHEITEN & DEMNÄCHST Die aktuellen Styles und Neuheiten, um Sie nach draußen zu bringen.
<G-vec00318-003-s105><get_together.bringen><en> The latest styles and new arrivals to inspire you to get outdoors.
<G-vec00318-003-s106><get_together.bringen><de> Selbstredend hat der Nerd die Seite der Textildrucker mit seinem WordPress SEO im Ranking danach auch nach oben bringen können.
<G-vec00318-003-s106><get_together.bringen><en> Self-evidently the nerd could get the site of the textile printers in the top ranking with this WordPress.
<G-vec00318-003-s107><get_together.bringen><de> Sie schmecken zwar super und sind perfekt geeignet um eine Party in Schwung zu bringen, stecken jedoch häufig voller Zucker und Kalorien.
<G-vec00318-003-s107><get_together.bringen><en> While tasty and a great way to get a party going, they have a tendency to be brimming with sugars and calories.
<G-vec00318-003-s108><get_together.bringen><de> Ganz gleich, welches Problem Sie erleben – Speicherlecks durch ineffektive Algorithmen, Fragen mit Performance oder Datenlokalisierung oder etwas anderes – wir bringen Ihre Spark-Anwendung wieder auf die Schiene.
<G-vec00318-003-s108><get_together.bringen><en> No matter what problem you experience – memory leaks due to ineffective algorithms, performance or data locality issues or something else – we’ll get your Spark application back on the rails.
<G-vec00318-003-s109><get_together.bringen><de> Kurz vor der Abfahrt werden die Sardinen mit einem Sonarsystem lokalisiert und es wird diskutiert, welche Faktoren wichtig sind, damit die Männer einen guten Fang nach Hause bringen können.
<G-vec00318-003-s109><get_together.bringen><en> Shortly in advance the schools of sardines get located using a sonar system and any conditions that might tribute to the catch of the day are being checked out.
<G-vec00318-003-s110><get_together.bringen><de> Den Wagon ins Rollen zu bringen ist aber mit Kraft verbunden.
<G-vec00318-003-s110><get_together.bringen><en> To get the wagon rolling is however connected with force.
<G-vec00318-003-s111><get_together.bringen><de> Wir werden Ihnen jedoch keine Verbindung herstellen, da wir in Frage stellen, dass diese Pillen Ihnen die gewünschten Ergebnisse bringen.
<G-vec00318-003-s111><get_together.bringen><en> But, we aren’t going to give you the link because we just don’t think these pills can get you the results you want.
<G-vec00318-003-s112><get_together.bringen><de> Die Reise auf der hohen See kann gefährlich sein, sie kann sich aber auch lohnen – im Spiel stehen eine große Anzahl verschiedener Schiffe mit einzigartigen Eigenschaften, Stärken und Schwächen zur Verfügung, um dich aufs Meer zu bringen.
<G-vec00318-003-s112><get_together.bringen><en> Travel on the high seas can be both dangerous and rewarding, and the game provides a range of ships with unique features – as well as strengths and weaknesses – to get you out on the water. Rowboat
<G-vec00318-003-s113><get_together.bringen><de> Eine komplett erneuerte Innenausstattung aus Leder, versehen mit modernster Elektronik, und ein Fuel-Injected 4.0 Liter V6-Motor, gekoppelt mit einer manuellen 5-Gangschaltung, bringen die Dinge ins Rollen.
<G-vec00318-003-s113><get_together.bringen><en> A new leather interior with modern electronics and a fuel-injected 4.0-liter V6 mated to a 5speed manual get it moving.
<G-vec00359-003-s038><lead_up.bringen><de> Wir Originalvölker der Binizzá, Ikoot, Chontal, Zoque, Nahua y Popoluca, die wir im Isthmus von Tehuantepec in den Bundesstaaten von Oaxaca und Veracruz leben sagen NEIN zu den Megaprojekten des Todes, wir verweigern die Zerstörung, die sie in unsere Territorien bringen wollen und die unsere Mutter Erde massakriert.
<G-vec00359-003-s038><lead_up.bringen><en> The Binizzá, Ikoot, Chontal, Zoque, Nahua and Popoluca originary peoples who inhabit the Isthmus of Tehuantepec in the states of Oaxaca and Veracruz have already made clear our “NO” to these megaprojects of death, which will lead to the destruction of our territories and the death of our mother earth.
<G-vec00359-003-s039><lead_up.bringen><de> Ich versuche zu allererst meine Hintermänner in Sicherheit zu bringen, hoffe dass mein Gegner mich nicht schlagen kann, mit dem Ziel meinen Pip-Vorsprung aus den großen Würfeln vom Anfang ins Ziel zu retten.
<G-vec00359-003-s039><lead_up.bringen><en> I try to save my back men first, hope I don´t get hit and keep running with the purpose of using my pip lead from start to win the game.
<G-vec00359-003-s040><lead_up.bringen><de> Der überflüssige salzige Konsum kann zur Wasserfestnahme, dem hohen Blutdruck und anderen Komplikationen bringen.
<G-vec00359-003-s040><lead_up.bringen><en> Excess salt consumption can lead to water retention, high blood pressure and other complications.
<G-vec00359-003-s041><lead_up.bringen><de> Da Cloud-Anbieter ihre Hardware typischerweise alle zwei Jahre erneuern, verglichen mit den 4-7 Jahren in vielen Unternehmen, kann eine Cloud-Lösung erhebliche leistungssteigernde Vorteile bringen.
<G-vec00359-003-s041><lead_up.bringen><en> As cloud vendors typically refresh their hardware every 2 years, compared with between 4 and 7 years for many large enterprises, this can lead to a 20% performance improvement.
<G-vec00359-003-s042><lead_up.bringen><de> Beide Werke haben die gleiche Materialquelle, bringen jedoch jeweils einen anderen dramaturgischen Ausdruck.
<G-vec00359-003-s042><lead_up.bringen><en> Both pieces derive from the same musical material, but lead to a different dramaturgical expression.
<G-vec00359-003-s043><lead_up.bringen><de> Hier hatte ich einen See auf den Karten von Inge entdeckt und habe sie angewiesen uns dort hin zu bringen.
<G-vec00359-003-s043><lead_up.bringen><en> I found a lake on Inges maps and told her to lead us to this point.
<G-vec00359-003-s044><lead_up.bringen><de> Eure Werke bringen euch den Schmerz und den Tod und ihr versteht es nicht, Mich zu suchen, um im Guten stark zu werden.
<G-vec00359-003-s044><lead_up.bringen><en> Your deeds lead you toward pain and death and you are unable to seek Me so that I may strengthen you in righteousness.
<G-vec00359-003-s045><lead_up.bringen><de> Das Georg Forster-Programm trägt dem Rechnung und stärkt Entwicklungsländer bei der Schaffung und beim Ausbau von Hochschul- und Wissenschaftssystemen, die zu Kristallisationszentren weiterer Entwicklung werden, etwa, indem sie Unternehmen anziehen und hoch qualifiziertes Personal ausbilden oder indem sie zu gefragten Partnern für internationale Kooperationen werden, die weitere Wissens- und Entwicklungsgewinne bringen.
<G-vec00359-003-s045><lead_up.bringen><en> The Georg Forster Programme recognises this fact and strengthens developing countries in the creation and development of university and science systems which become crystallisation centres for further development. This may take the form of attracting companies and training highly-qualified personnel or becoming sought-after partners for international collaborations which themselves lead to further gains in knowledge and development.
<G-vec00359-003-s046><lead_up.bringen><de> Die überarbeiteten Aufträge dieses Unternehmens bringen die zweite Kampagne an einen Punkt, den wir als final und hinsichtlich der Komplexität gut balanciert betrachten.
<G-vec00359-003-s046><lead_up.bringen><en> Reworking this operation’s missions will lead the Second Front to a state that we consider final and well-balanced in terms of complexity.
<G-vec00359-003-s047><lead_up.bringen><de> [Buchtipp von Beat Mazenauer] Turbulente Zeiten bringen turbulente Leben hervor - und eine Literatur, die solche Turbulenzen einzufangen versucht.
<G-vec00359-003-s047><lead_up.bringen><en> [book tip by Beat Mazenauer] Turbulent times lead to turbulent lives – and literature, which attempts to capture this turbulence.
<G-vec00359-003-s048><lead_up.bringen><de> 8Wenn der Ewige Gefallen an uns hat, so wird er uns in dieses Land bringen und uns solches geben, ein Land, in dem Milch und Honig fließt.
<G-vec00359-003-s048><lead_up.bringen><en> 8 If the Lord is pleased with us, he will lead us into that land, a land flowing with milk and honey, and will give it to us.
<G-vec00359-003-s049><lead_up.bringen><de> François Longchamp erwähnte ebenfalls die Verwaltung des Luftraums und des Verkehrsflusses, wobei er allerdings unterstrich, dass diese Bestrebungen "keine unerträglichen Beeinträchtigungen für die Anwohner mit sich bringen".
<G-vec00359-003-s049><lead_up.bringen><en> Mr. Longchamp also talked about airspace and traffic flow management, while stressing that those ambitions "must not lead to unbearable harmful consequences for nearby residents".
<G-vec00359-003-s050><lead_up.bringen><de> Im Gegenteil, um uns Mut bringen, missionarisch zu sein, zu erkennen wie wir die Schönheit des Glaubens an Christus und des kirchlichen Lebens anbieten können.“ So beschrieb es der neue Synodalsenior Daniel Ženatý.
<G-vec00359-003-s050><lead_up.bringen><en> On the contrary – let this lead us to a missionary courage, to finding how to offer the beauty of faith in Christ and the life of the Church,” explained the new Synodal Senior Daniel Ženatý.
<G-vec00359-003-s051><lead_up.bringen><de> Ein Deal, um die 70.000 Minenarbeiter wieder zum Arbeiten im Platin-Minengürtel des Landes zu bewegen, der für ungefähr 70 Prozent des globalen Angebots verantwortlich ist, würde wohl die Ängste einer Unterbrechung der Produktion beruhigen und das Edelmetall zum sinken bringen.
<G-vec00359-003-s051><lead_up.bringen><en> A deal to put the 70,000 striking miners back to work in the country’s platinum mining belt, which accounts for roughly 70 percent of global supply, would likely alleviate fears over production disruptions and could lead the precious metal lower.
<G-vec00359-003-s052><lead_up.bringen><de> Obwohl die Bremsen für viele Fälle eben wirksam sind, kann jedoch das Bremsen die Räder aussondern und, zum Verlust der Kontrolle über die Lenkung bringen, unmöglich machend, für die Vermeidung des Zusammenstoßes abzuschweifen.
<G-vec00359-003-s052><lead_up.bringen><en> Though brakes also are effective in many cases, however braking can block wheels and lead to loss of the control over a steering, doing impossible to turn aside for collision avoidance.
<G-vec00359-003-s053><lead_up.bringen><de> „Sie haben mir die Augen geöffnet: Jetzt weiß ich, was es braucht, um Prozesse erfolgreich in Gang zu bringen.
<G-vec00359-003-s053><lead_up.bringen><en> Contact “My eyes have opened for what is takes to successfully lead a process.
<G-vec00359-003-s054><lead_up.bringen><de> Perspektivwechsel bringen neue An – und Einsichten und sind als solche ein wichtiges methodisches Element von Forschung und Innovation.
<G-vec00359-003-s054><lead_up.bringen><en> Changes of perspective often lead to new views and insights and as such are an important methodological element of research and innovation.
<G-vec00359-003-s055><lead_up.bringen><de> Nicht in die Forschungsarbeiten einbezogen wird ein möglicher Rückgang der expliziten Handelskosten (Maklerprovisionen oder Börsengebühren), der bei erhöhtem Wettbewerb zwischen Intermediären und Börsen zu erwarten ist und für Bürger und Unternehmen in der EU weiteren wirtschaftlichen Nutzen mit sich bringen dürfte.
<G-vec00359-003-s055><lead_up.bringen><en> The research does not consider potential reductions in explicit trading costs (brokerage commissions or exchange fees) that can be expected to accompany increased competition between intermediaries and exchanges and lead to further economic benefits for EU citizens and business.
<G-vec00359-003-s056><lead_up.bringen><de> In einem RCT sollte überprüft werden, ob die Verwendung eines Pflegeprotokolls Verbesserungen für Patienten und Pflegekräfte bringen kann.
<G-vec00359-003-s056><lead_up.bringen><en> A randomised, controlled clinical trial tried to demonstrate whether the use of a nursing care protocol can lead to improvements for patients and nurses.
