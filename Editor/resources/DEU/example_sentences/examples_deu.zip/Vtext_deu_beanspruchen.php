<G-vec00060-001-s209><claim.beanspruchen><de> Die jeweiligen Urheber der auf Scuderia Ferrari Online Store veröffentlichten Werke sind jederzeit berechtigt, die Urheberschaft ihrer Werke zu beanspruchen und jeder Veränderung oder sonstigen Abänderung der Werke, einschließlich jeglicher Beschädigungen ihrer Werke, die ihre Ehre oder ihren Ruf verletzen könnte, zu widersprechen.
<G-vec00060-001-s209><claim.beanspruchen><en> The individual authors of works published on Scuderia Ferrari Online Store are entitled at any time to claim the authorship of their work and to object to any distortion or any other modification of the works, including any damage to the works which may harm their honour or reputation.
<G-vec00060-001-s210><claim.beanspruchen><de> September Einleger können auch eine zusätzliche 25 $ Freebie mit dem Bonus-Code unten aufgeführt beanspruchen.
<G-vec00060-001-s210><claim.beanspruchen><en> September depositors may also claim an extra $25 freebie with the bonus code listed below.
<G-vec00060-001-s211><claim.beanspruchen><de> Durch den Beitritt bei Unibet Sportwetten online, ist der Wetter berechtigt, einen £ 20 Bonus zu beanspruchen.
<G-vec00060-001-s211><claim.beanspruchen><en> By joining Unibet Sportbook online sportbook punters are entitled to claim a £20 bonus.
<G-vec00060-001-s212><claim.beanspruchen><de> Während Gaborn's Königreich Mystarria in Trümmern liegt, marschieren vier mächtige Könige auf, um die Kriegsbeute für sich zu beanspruchen, selbst als eine riesige Reaver-Armee aus der Unterwelt herausstürmt, um der Menschheit ihr Ende zu bereiten.
<G-vec00060-001-s212><claim.beanspruchen><en> With Gaborn's kingdom of Mystarria in ruins, four powerful kings march to claim its spoils, even as a vast army of reavers sallies forth from the underworld, intending to put an end to mankind.
<G-vec00060-001-s213><claim.beanspruchen><de> Es sind Menschen, die entweder in Devon gestorben sind oder ursprünglich aus der Grafschaft stammten, aber ohne Angehörige verstorben sind, die ihren Besitz oder ihr Eigentum beanspruchen.
<G-vec00060-001-s213><claim.beanspruchen><en> They are people who either died in Devon or were originally from the county but passed away without any next of kin laying claim to their belongings or property.
<G-vec00060-001-s214><claim.beanspruchen><de> Diesen Titel, des offiziellen Elvis-Photographen, kann nur Ed Bonja für sich beanspruchen, dessen Motive nicht nur in einem Buch veröffentlicht, sondern den Fans schon in den 70'er Jahren bekannt gemacht wurden durch die Entscheidung des Colonels, Bonja's Bilder als Plattencover zu benutzen.
<G-vec00060-001-s214><claim.beanspruchen><en> This title, official Elvis-photographer, can only Ed Bonja claim for himself, whose images were not only released in a book, but they were published for the fans already in the 70s due to the decision of the Colonel, to use Bonja's pictures for a LP cover.
<G-vec00060-001-s215><claim.beanspruchen><de> Sobald eine Person gekündigt wird, und verliert ihren Job, den sie tun müssen mehrere Dinge, Leistungen zu beanspruchen.
<G-vec00060-001-s215><claim.beanspruchen><en> As soon as a person is given notice and loses their job they must do several things to claim benefits.
<G-vec00060-001-s216><claim.beanspruchen><de> Bevor Sie ein Casino-Angebot beanspruchen, sollten Sie sich mit den Umsatzanforderungen vertraut machen.
<G-vec00060-001-s216><claim.beanspruchen><en> Before you claim a casino offer, you should have a look at the wagering requirements.
<G-vec00060-001-s217><claim.beanspruchen><de> Da islamische Vereinigungen nicht das ganze Spektrum muslimischer Eltern und Schüler abdecken, können sie kein Monopol beanspruchen.
<G-vec00060-001-s217><claim.beanspruchen><en> Since Islamic associations do not cover the whole spectrum of Muslim parents and pupils they cannot claim a monopoly.
<G-vec00060-001-s218><claim.beanspruchen><de> Die Net Operator beanspruchen in den meisten Fällen zwischen 40 und 50 Prozent der Umsätze für sich.
<G-vec00060-001-s218><claim.beanspruchen><en> In most cases, net operators claim between 40 and 50 percent of the sales volume for themselves.
<G-vec00060-001-s219><claim.beanspruchen><de> "Ich habe gemeint, dass beide, obwohl einander radikal entgegengesetzt und tatsächlich inkompatibel, die Darstellungslogik der Universalität, oder besser ausgedrückt, der ""Universalisierung"", beanspruchen könnten."
<G-vec00060-001-s219><claim.beanspruchen><en> "And I argued that, albeit radically opposed and in fact incompatible, they could both claim to illustrate the logic of universality, perhaps better expressed as ""universalization""."
<G-vec00060-001-s220><claim.beanspruchen><de> Nur ein paar Haarwachstum Element, das die Verwendung von natürlicher Formulierung und auch zusätzlich beanspruchen könnte weniger, dass das gleiche Ergebnis bietet als Har Vokse .
<G-vec00060-001-s220><claim.beanspruchen><en> Just a couple of hair growth item that could claim the usage of natural formulation and also in addition less that can offer the very same outcome as Har Vokse.
<G-vec00060-001-s221><claim.beanspruchen><de> Standardorganisationen, die alle Empfehlungen berücksichtigt haben, können ohne Übertreibung für sich beanspruchen, dass ihre zertifizierten Organisationen größten Wert auf den Schutz der biologischen Vielfalt legen.
<G-vec00060-001-s221><claim.beanspruchen><en> Standard organizations which have integrated all these criteria can without exaggeration claim for themselves that their certified organizations primary concern is the protection of biodiversity.
<G-vec00060-001-s222><claim.beanspruchen><de> (Beifall) Und das einzige, auf das wir bis jetzt gewartet haben, ist für uns, diese Macht als souveräne Menschen zu beanspruchen.
<G-vec00060-001-s222><claim.beanspruchen><en> (Applause) And the only thing you've been waiting for now is for us to claim that power as sovereign human beings.
<G-vec00060-001-s223><claim.beanspruchen><de> Und einige dieser ausgekochten Typen beanspruchen für sich selbst Göttlichkeit.
<G-vec00060-001-s223><claim.beanspruchen><en> Some of these crafty critters claim divinity.
<G-vec00060-001-s224><claim.beanspruchen><de> Beanspruchen Sie Ihre n Ersteinzahlungsbonus.
<G-vec00060-001-s224><claim.beanspruchen><en> Claim your first deposit bonus.
<G-vec00060-001-s225><claim.beanspruchen><de> "Hinter dieses drei ""Profis"" kam Christian Sailer ins Ziel, der somit den Titel des internen Fanclub-Champs für sich beanspruchen konnte."
<G-vec00060-001-s225><claim.beanspruchen><en> "After these ""professionals"", Christian Sailer crossed the finish line and could consequently claim the title of the intern fan club champ."
<G-vec00060-001-s226><claim.beanspruchen><de> Wir beanspruchen spirituellen Fortschritt eher als spirituelle Perfektion.
<G-vec00060-001-s226><claim.beanspruchen><en> We claim spiritual progress rather than spiritual perfection.
<G-vec00060-001-s227><claim.beanspruchen><de> Niemand sollte daher für sich beanspruchen, die alleinige und unumschränkt gültige Wahrheit zu besitzen.
<G-vec00060-001-s227><claim.beanspruchen><en> Therefore, nobody should claim to possess the absolute truth.
<G-vec00169-001-s209><claim.beanspruchen><de> Die jeweiligen Urheber der auf Scuderia Ferrari Online Store veröffentlichten Werke sind jederzeit berechtigt, die Urheberschaft ihrer Werke zu beanspruchen und jeder Veränderung oder sonstigen Abänderung der Werke, einschließlich jeglicher Beschädigungen ihrer Werke, die ihre Ehre oder ihren Ruf verletzen könnte, zu widersprechen.
<G-vec00169-001-s209><claim.beanspruchen><en> The individual authors of works published on Scuderia Ferrari Online Store are entitled at any time to claim the authorship of their work and to object to any distortion or any other modification of the works, including any damage to the works which may harm their honour or reputation.
<G-vec00169-001-s210><claim.beanspruchen><de> September Einleger können auch eine zusätzliche 25 $ Freebie mit dem Bonus-Code unten aufgeführt beanspruchen.
<G-vec00169-001-s210><claim.beanspruchen><en> September depositors may also claim an extra $25 freebie with the bonus code listed below.
<G-vec00169-001-s211><claim.beanspruchen><de> Durch den Beitritt bei Unibet Sportwetten online, ist der Wetter berechtigt, einen £ 20 Bonus zu beanspruchen.
<G-vec00169-001-s211><claim.beanspruchen><en> By joining Unibet Sportbook online sportbook punters are entitled to claim a £20 bonus.
<G-vec00169-001-s212><claim.beanspruchen><de> Während Gaborn's Königreich Mystarria in Trümmern liegt, marschieren vier mächtige Könige auf, um die Kriegsbeute für sich zu beanspruchen, selbst als eine riesige Reaver-Armee aus der Unterwelt herausstürmt, um der Menschheit ihr Ende zu bereiten.
<G-vec00169-001-s212><claim.beanspruchen><en> With Gaborn's kingdom of Mystarria in ruins, four powerful kings march to claim its spoils, even as a vast army of reavers sallies forth from the underworld, intending to put an end to mankind.
<G-vec00169-001-s213><claim.beanspruchen><de> Es sind Menschen, die entweder in Devon gestorben sind oder ursprünglich aus der Grafschaft stammten, aber ohne Angehörige verstorben sind, die ihren Besitz oder ihr Eigentum beanspruchen.
<G-vec00169-001-s213><claim.beanspruchen><en> They are people who either died in Devon or were originally from the county but passed away without any next of kin laying claim to their belongings or property.
<G-vec00169-001-s214><claim.beanspruchen><de> Diesen Titel, des offiziellen Elvis-Photographen, kann nur Ed Bonja für sich beanspruchen, dessen Motive nicht nur in einem Buch veröffentlicht, sondern den Fans schon in den 70'er Jahren bekannt gemacht wurden durch die Entscheidung des Colonels, Bonja's Bilder als Plattencover zu benutzen.
<G-vec00169-001-s214><claim.beanspruchen><en> This title, official Elvis-photographer, can only Ed Bonja claim for himself, whose images were not only released in a book, but they were published for the fans already in the 70s due to the decision of the Colonel, to use Bonja's pictures for a LP cover.
<G-vec00169-001-s215><claim.beanspruchen><de> Sobald eine Person gekündigt wird, und verliert ihren Job, den sie tun müssen mehrere Dinge, Leistungen zu beanspruchen.
<G-vec00169-001-s215><claim.beanspruchen><en> As soon as a person is given notice and loses their job they must do several things to claim benefits.
<G-vec00169-001-s216><claim.beanspruchen><de> Bevor Sie ein Casino-Angebot beanspruchen, sollten Sie sich mit den Umsatzanforderungen vertraut machen.
<G-vec00169-001-s216><claim.beanspruchen><en> Before you claim a casino offer, you should have a look at the wagering requirements.
<G-vec00169-001-s217><claim.beanspruchen><de> Da islamische Vereinigungen nicht das ganze Spektrum muslimischer Eltern und Schüler abdecken, können sie kein Monopol beanspruchen.
<G-vec00169-001-s217><claim.beanspruchen><en> Since Islamic associations do not cover the whole spectrum of Muslim parents and pupils they cannot claim a monopoly.
<G-vec00169-001-s218><claim.beanspruchen><de> Die Net Operator beanspruchen in den meisten Fällen zwischen 40 und 50 Prozent der Umsätze für sich.
<G-vec00169-001-s218><claim.beanspruchen><en> In most cases, net operators claim between 40 and 50 percent of the sales volume for themselves.
<G-vec00169-001-s219><claim.beanspruchen><de> "Ich habe gemeint, dass beide, obwohl einander radikal entgegengesetzt und tatsächlich inkompatibel, die Darstellungslogik der Universalität, oder besser ausgedrückt, der ""Universalisierung"", beanspruchen könnten."
<G-vec00169-001-s219><claim.beanspruchen><en> "And I argued that, albeit radically opposed and in fact incompatible, they could both claim to illustrate the logic of universality, perhaps better expressed as ""universalization""."
<G-vec00169-001-s220><claim.beanspruchen><de> Nur ein paar Haarwachstum Element, das die Verwendung von natürlicher Formulierung und auch zusätzlich beanspruchen könnte weniger, dass das gleiche Ergebnis bietet als Har Vokse .
<G-vec00169-001-s220><claim.beanspruchen><en> Just a couple of hair growth item that could claim the usage of natural formulation and also in addition less that can offer the very same outcome as Har Vokse.
<G-vec00169-001-s221><claim.beanspruchen><de> Standardorganisationen, die alle Empfehlungen berücksichtigt haben, können ohne Übertreibung für sich beanspruchen, dass ihre zertifizierten Organisationen größten Wert auf den Schutz der biologischen Vielfalt legen.
<G-vec00169-001-s221><claim.beanspruchen><en> Standard organizations which have integrated all these criteria can without exaggeration claim for themselves that their certified organizations primary concern is the protection of biodiversity.
<G-vec00169-001-s222><claim.beanspruchen><de> (Beifall) Und das einzige, auf das wir bis jetzt gewartet haben, ist für uns, diese Macht als souveräne Menschen zu beanspruchen.
<G-vec00169-001-s222><claim.beanspruchen><en> (Applause) And the only thing you've been waiting for now is for us to claim that power as sovereign human beings.
<G-vec00169-001-s223><claim.beanspruchen><de> Und einige dieser ausgekochten Typen beanspruchen für sich selbst Göttlichkeit.
<G-vec00169-001-s223><claim.beanspruchen><en> Some of these crafty critters claim divinity.
<G-vec00169-001-s224><claim.beanspruchen><de> Beanspruchen Sie Ihre n Ersteinzahlungsbonus.
<G-vec00169-001-s224><claim.beanspruchen><en> Claim your first deposit bonus.
<G-vec00169-001-s225><claim.beanspruchen><de> "Hinter dieses drei ""Profis"" kam Christian Sailer ins Ziel, der somit den Titel des internen Fanclub-Champs für sich beanspruchen konnte."
<G-vec00169-001-s225><claim.beanspruchen><en> "After these ""professionals"", Christian Sailer crossed the finish line and could consequently claim the title of the intern fan club champ."
<G-vec00169-001-s226><claim.beanspruchen><de> Wir beanspruchen spirituellen Fortschritt eher als spirituelle Perfektion.
<G-vec00169-001-s226><claim.beanspruchen><en> We claim spiritual progress rather than spiritual perfection.
<G-vec00169-001-s227><claim.beanspruchen><de> Niemand sollte daher für sich beanspruchen, die alleinige und unumschränkt gültige Wahrheit zu besitzen.
<G-vec00169-001-s227><claim.beanspruchen><en> Therefore, nobody should claim to possess the absolute truth.
<G-vec00060-001-s228><claim.beanspruchen><de> Beste Voraussetzungen schafft zudem das namhafte pannonische Klima, das mit seiner milden Bestimmtheit einen nicht unerheblichen Anteil an der außergewöhnlichen Qualität der burgenländischen Weine für sich beansprucht.
<G-vec00060-001-s228><claim.beanspruchen><en> The famous Pannonian climate furthermore creates the ideal conditions; a climate which, with its mild qualities, lays claim for a significant proportion of the exceptional quality of the Burgenland wines.
<G-vec00060-001-s229><claim.beanspruchen><de> Galten für eine Person nacheinander oder abwechselnd Rechtsvorschriften von zwei oder mehr Vertragsstaaten, so erhalten diese Person oder ihre Hinterbliebenen selbst dann Leistungen nach diesem Kapitel, wenn ohne dessen Anwendung nach den Rechtsvorschriften eines oder mehrerer Vertragsstaaten Leistungen beansprucht werden könnten.
<G-vec00060-001-s229><claim.beanspruchen><en> Where a person has been subject successively or alternatively to the legislation of two or more Contracting Parties, the said person or his survivors shall be entitled to benefits in accordance with the provisions of this chapter, even if such persons would be entitled to claim benefits under the legislation of one or more Contracting Parties without these provisions being applied.
<G-vec00060-001-s230><claim.beanspruchen><de> Die FSFE, Urheberschaft und Projekt-Administration Wenn sich die FSFE dafür entscheidet, Treuhänder für ein Freies Software- Projekt zu werden, beansprucht sie keine Urheberschaft oder Kontrolle über das Projekt.
<G-vec00060-001-s230><claim.beanspruchen><en> FSFE, authorship and project administration When FSFE accepts to become the fiduciary for a Free Software project, it does not claim authorship or control over the project.
<G-vec00060-001-s231><claim.beanspruchen><de> Geometrische Formen dynamisieren sich, der Akt des Schreibens und Zeichnens beansprucht den Tanz für sich, und der Sound treibt das Geschehen mit an – mal ins Unheimliche, mal ins Komische kippend.
<G-vec00060-001-s231><claim.beanspruchen><en> Geometric shapes become dynamic, the acts of writing and drawing claim the act of dancing for themselves, and the sound drives the action forward – at times drifting towards eeriness, at other times towards the comical.
<G-vec00060-001-s232><claim.beanspruchen><de> 54 (2), wenn die Priorität von P nicht wirksam beansprucht werden kann.
<G-vec00060-001-s232><claim.beanspruchen><en> 54(2) if the priority claim of P is not valid.
<G-vec00060-001-s233><claim.beanspruchen><de> Wenn ein Unternehmen eine Farbe für sich beansprucht, kann dies die Spielregeln für eine Marke verändern.
<G-vec00060-001-s233><claim.beanspruchen><en> Laying claim to a color can be a game changer for a corporate brand.
<G-vec00060-001-s234><claim.beanspruchen><de> Ein Konfliktakteur heißt indirekt beteiligter oder indirekter Akteur, wenn er den Konfliktgegenstand nicht für sich selbst beansprucht oder erstrebt, aber über ihn kommuniziert oder auf ihn bezogen handelt.
<G-vec00060-001-s234><claim.beanspruchen><en> A conflict actor who does not claim the conflict item for itself but communicates and acts with regard to the item is called an indirectly involved or indirect actor .
<G-vec00060-001-s235><claim.beanspruchen><de> "Nachdem unsere Verteidigungen platziert sind, sollten wir diese Insel jetzt offiziell zu der unsrigen machen Beansprucht die Insel, indem Ihr innerhalb des Koloniemenüs die Option ""Kolonie beanspruchen"" anklickt."
<G-vec00060-001-s235><claim.beanspruchen><en> "Now that we've put our defenses in place, we should make this island officially ours Claim the island by pressing the ""Claim Colony"" button in the Colony menu."
<G-vec00060-001-s236><claim.beanspruchen><de> Auch der Beschwerdeführer beansprucht für sich nicht, Rechtsanwalt zu sein.
<G-vec00060-001-s236><claim.beanspruchen><en> The appellant does not claim to be a Rechtsanwalt.
<G-vec00060-001-s237><claim.beanspruchen><de> Wenn irgend jemand beansprucht, den 'wahren' Islam zu repräsentieren, dann sind es gewiss diese Stammesangehörigen.
<G-vec00060-001-s237><claim.beanspruchen><en> If anyone could claim to represent the 'true' Islam surely it is these tribesmen?
<G-vec00060-001-s238><claim.beanspruchen><de> Ob Mandela für seinen Namen auch in Europa Markenschutz beansprucht, bleibt abzuwarten.
<G-vec00060-001-s238><claim.beanspruchen><en> Whether Mandela also lays claim to protection for his name in Europe, remains to be seen.
<G-vec00060-001-s239><claim.beanspruchen><de> Vorbehaltlich weiterer Tests beansprucht SSC eine Umwandlungseffizienz (die Menge an Licht, die auf die Fassade trifft und dann in Energie umgewandelt wird) von 10% für Biogas und 38% für Wärme – zusammen fast 50%.
<G-vec00060-001-s239><claim.beanspruchen><en> Subject to further tests, SSC claim a conversion efficiency (the amount of light hitting the façade converted to energy) of 10% for biogas and 38% for heat – almost 50% in total.
<G-vec00060-001-s240><claim.beanspruchen><de> Suunto beansprucht keine Inhaberschaft an Ihrem Material.
<G-vec00060-001-s240><claim.beanspruchen><en> Suunto does not claim ownership in your Material.
<G-vec00060-001-s241><claim.beanspruchen><de> Aber denken Sie daran: Alles, was hier geschrieben wird, ist nur die Meinung des Autors, der nicht die Wahrheit beansprucht, sondern nur seine Meinung und seine Sicht der Situation zum Ausdruck bringt.
<G-vec00060-001-s241><claim.beanspruchen><en> But remember: all that is written here is only the opinion of the author, who does not claim the truth, but only expresses his opinion and vision of the situation.
<G-vec00060-001-s242><claim.beanspruchen><de> "C-VI, 9.6: ""In der Stammanmeldung und den Teilanmeldungen darf nicht der gleiche Gegenstand beansprucht werden (siehe IV, 6.4)."
<G-vec00060-001-s242><claim.beanspruchen><en> "C-VI, 9.6: ""The parent and divisional applications may not claim the same subject-matter (see IV, 6.4)."
<G-vec00060-001-s243><claim.beanspruchen><de> Ihr beansprucht durch dieses Studium einen hohen Status.
<G-vec00060-001-s243><claim.beanspruchen><en> You claim a high status through this study.
<G-vec00060-001-s244><claim.beanspruchen><de> Hirschberg hat keinerlei Priorität beansprucht: er erwähnt, dass Mc Keown in Belfast 1874 die Sklera eröffnet hatte, um einen Fremdkörper mittels Permanentmagnet zu extrahieren, dass schon vor 1875 der Berliner Augenarzt Paul Heinrich Brecht einen elektrischen Handmagneten konstruiert hatte, dass Mc Hardy in London einen elektrischen Handmagneten benutzt hatte, um einen Fremdkörper von der Linsenvorderfläche in die Vorderkammer zu ziehen und dann zu entfernen.
<G-vec00060-001-s244><claim.beanspruchen><en> Hirschberg made no claim to be the first. He mentions that McKeown in Belfast had opened the sclera to extract a foreign body using an permanent magnet in 1874, and that the Berlin ophthalmologist Paul Heinrich Brecht had constructed an electric hand-held magnet prior to 1875, that Mc Hardy in London had used an electric hand magnet to pull a foreign body from the anterior surface of the lens into the anterior chamber before removing it.
<G-vec00060-001-s245><claim.beanspruchen><de> In der Stammanmeldung und den Teilanmeldungen darf nicht der gleiche Gegenstand beansprucht werden, auch wenn dies mit anderen Worten geschieht (weitere Einzelheiten sieheG‑IV, 5.4).
<G-vec00060-001-s245><claim.beanspruchen><en> The parent and divisional applications may not claim the same subject-matter, even in different words (for further information, seeG‑IV, 5.4).
<G-vec00060-001-s246><claim.beanspruchen><de> Sie beansprucht auch nicht den Titel erschöpfender Vollständigkeit.
<G-vec00060-001-s246><claim.beanspruchen><en> Nor does it claim to be exhaustive.
<G-vec00169-001-s056><reclaim.beanspruchen><de> Es kostet nur 20 US-Dollar pro 1.000 Meilen und Sie können bis zu 50.000 Skywards-Meilen pro Jahr erneut beanspruchen.
<G-vec00169-001-s056><reclaim.beanspruchen><en> It costs just USD 20 per 1,000 Miles and you can reclaim up to 50,000 Skywards Miles in a year.
<G-vec00169-001-s192><reclaim.beanspruchen><de> Ihr beginnt viele latente Fähigkeiten zu zeigen und zu benutzen, die in Reserve geblieben sind, bis Ihr bereit seid, sie wieder zu beanspruchen.
<G-vec00169-001-s192><reclaim.beanspruchen><en> You are beginning to demonstrate and use many latent abilities that have been kept in reserve until you were ready to reclaim them.
