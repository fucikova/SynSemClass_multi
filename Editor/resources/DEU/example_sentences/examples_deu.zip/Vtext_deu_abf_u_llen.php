<G-vec00380-002-s093><unload.abfüllen><de> “Wir sollten aufhören, Werte zu dokumentieren und einige Öle durften wir nicht mehr in Tanks abfüllen.
<G-vec00380-002-s093><unload.abfüllen><en> “We were asked to stop noting down certain oils’ values and we were not allowed to unload certain oils in the tanks.
