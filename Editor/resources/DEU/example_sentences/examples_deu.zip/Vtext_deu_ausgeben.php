<G-vec00325-002-s057><spend.ausgeben><de> Die Convergence und Rivermine Software verarbeitet bereits mehr als 600 Million US-Dollar internationaler Ausgaben für Telekommunikationen.
<G-vec00325-002-s057><spend.ausgeben><en> Convergence and Rivermine software already processes more than $ 600 million in international telecom spend.
<G-vec00325-002-s058><spend.ausgeben><de> Von der Definition geeigneter Einkaufsstrategien und Einkaufsprozesse über die Optimierung der Lieferantenportfolios bis hin zur Performance-Messung von Beratungsdienstleistungen und Optimierung der Ausgaben für externe Beratung.
<G-vec00325-002-s058><spend.ausgeben><en> From procurement strategies and processes, supplier management & preferred supplier strategies to measurement of the performance of engaged consultants and consulting spend management.
<G-vec00325-002-s059><spend.ausgeben><de> Das Unternehmen erfüllt nun sein Ziel, mehr als 80% der Ausgaben zu verwalten.
<G-vec00325-002-s059><spend.ausgeben><en> The company is on target to have over 80% of spend under management.
<G-vec00325-002-s060><spend.ausgeben><de> Zum Jahreswechsel verzeichnete das Unternehmen eine Steigerung des ROAS um 28 %, einen Anstieg der Verkäufe um 4 % sowie 18 % weniger Ausgaben.
<G-vec00325-002-s060><spend.ausgeben><en> As they headed into the new year, they continued to see a 28% increase in ROAS with a 4% boost in sales at 18% less spend.
<G-vec00325-002-s061><spend.ausgeben><de> Um Ihre Ausgaben zu überwachen, loggen Sie sich in Ihr Konto ein, öffnen Sie die Lobby und klicken Sie auf „Mein Konto“.
<G-vec00325-002-s061><spend.ausgeben><en> To keep track of your spend, log into your account and head over to the “lobby” and then click on “My Account.”
<G-vec00325-002-s062><spend.ausgeben><de> Dieser wahrhaft ganzheitliche Einblick hilft dabei, die Stellen in Ihrer Lieferkette mit den größten Risiken hervorzuheben, um angemessene Entscheidungen über Bestandsnutzung und Ausgaben treffen zu können.
<G-vec00325-002-s062><spend.ausgeben><en> This SQM solution takes a truly holistic view on supplier quality, highlighting areas of greatest risk in your supply chain and allowing you to make appropriate supply usage and spend decisions.
<G-vec00325-002-s063><spend.ausgeben><de> Die Software kann alle in deinem Unternehmen verwendeten SaaS-Produkte abbilden, ihre Ausgaben verfolgen und den Benutzerzugriff auf Software verwalten.
<G-vec00325-002-s063><spend.ausgeben><en> Our software is able to map all SaaS products used in your organization, track their spend, and manage user access to software.
<G-vec00325-002-s064><spend.ausgeben><de> Dennoch sind die Ausgaben der Mitgliedstaaten für die Si-cherheit im Straßenverkehr weit geringer als der Verlust, der den Volkswirtschaften durch Verkehrsunfälle entsteht.
<G-vec00325-002-s064><spend.ausgeben><en> Yet the amount that countries spend on safety is far less than the economic loss incurred by road crashes.
<G-vec00325-002-s065><spend.ausgeben><de> Dokumentieren Sie die finanziellen Transaktionen in Ihrem System, um tatsächliche Ausgaben und entstandene Kosten so genau wie möglich abzubilden.
<G-vec00325-002-s065><spend.ausgeben><en> Record the financial transaction in your system to reflect actual spend and cost incurred as accurately as possible.
<G-vec00325-002-s066><spend.ausgeben><de> Der Konzern hatte geplant, die Erfahrung von Kunden mit einer globalen Sicht auf ihre HP-Erlebnisse zu verbessern und gleichzeitig die Ausgaben zu optimieren.
<G-vec00325-002-s066><spend.ausgeben><en> The organization wanted to uplevel the customer experience by providing customers with a 360-degree view of their HP experience, while optimizing spend.
<G-vec00325-002-s067><spend.ausgeben><de> Wichtig: Die meisten unserer Ausgaben, Impressions und Klicks resultieren aus direkten Beziehungen, bei denen unser Publisher Development Team direkt mit dem Sales und Operation Team beim Publisher zusammenarbeitet.
<G-vec00325-002-s067><spend.ausgeben><en> Critically, most of our spend, impressions and clicks comes from direct relationships, where our publisher development team is working directly with the sales and operations team at a publisher.
<G-vec00325-002-s068><spend.ausgeben><de> Wir haben Verbesserungen bei der Reichweite, den CTRs und den Ausgaben festgestellt.
<G-vec00325-002-s068><spend.ausgeben><en> We’ve seen improvements in reach as well as CTRs and spend.
<G-vec00325-002-s069><spend.ausgeben><de> Allein zwischen 2012 und 2014 erhöhten Millennials ihre Ausgaben für Möbel und Bettwaren um 142%.
<G-vec00325-002-s069><spend.ausgeben><en> Between 2012 and 2014 millennials increased their spend on furniture and bedding by 142%.
<G-vec00325-002-s070><spend.ausgeben><de> Mit unseren strategischen Dienstleistungen und unserer Plattform die Ihnen einzigartige Einblicke in die Costumer Journey gibt, können wir Ihre Ausgaben verwalten und auf allen digitalen Marketing Kanälen optimieren.
<G-vec00325-002-s070><spend.ausgeben><en> With strategic services, our proprietary consumer journey insights platform and a single services team, we manage and optimize your spend across all digital channels.
<G-vec00325-002-s071><spend.ausgeben><de> Maximieren Sie Einsparmöglichkeiten, sorgen Sie für mehr Transparenz bei Ausgaben und Aktivitäten von Meetings und erzielen Sie beeindruckende Ergebnisse durch umfassenden, nahtlosen Service.
<G-vec00325-002-s071><spend.ausgeben><en> Maximize savings opportunities, gain greater transparency into meetings spend and activity, and achieve results through comprehensive end-to-end servicing.
<G-vec00325-002-s072><spend.ausgeben><de> Außerdem können Travel Manager schnell Berichte erstellen, um die Ausgaben zu kontrollieren und ihrer Sorgfaltspflicht nachzukommen.
<G-vec00325-002-s072><spend.ausgeben><en> What’s more, travel managers can quickly pull reports to control spend and provide duty of care.
<G-vec00325-002-s073><spend.ausgeben><de> Die Ausgaben pro Region und pro Kategorie sind nachstehend abgebildet.
<G-vec00325-002-s073><spend.ausgeben><en> Spend by region and by category is shown below.
<G-vec00325-002-s074><spend.ausgeben><de> Ein Mitarbeiter in einer Geschäftsreise-/Veranstaltungsagentur ist eine Einzelperson, die von einer Geschäftsreise-/Veranstaltungsagentur beschäftigt ist, welche über eine IATA-Nummer verfügt und anrechnungsfähige Ausgaben in teilnehmenden Hotels für und im Auftrag ihrer Kunden zu Geschäftszwecken tätigt, und die weder direkt noch über ein Agenturkonsortium an eine Zentralvereinbarung mit einem IHG Unternehmen gebunden ist.
<G-vec00325-002-s074><spend.ausgeben><en> A business travel/meetings agent is an individual who is employed by a travel/meetings agency, books Qualifying Spend at Participating Hotels for and on behalf of his or her clients for business purposes and who does not have a central agreement with any IHG company either directly or through being a member of an agency consortia group.
<G-vec00325-002-s075><spend.ausgeben><de> Schätze ab was du möglicherweise in diesem Jahr in diesem Bereich für Ausgaben haben könntest, dividiere diesen Betrag durch 12 und du hast dein monatliches Budget.
<G-vec00325-002-s075><spend.ausgeben><en> Estimate what you might have to spend on these in a year and divide by 12 for your monthly budget.
<G-vec00380-002-s076><dispense.ausgeben><de> Jedoch erforderte dies das Vorsehen einer Dampfquelle, was die Kosten und die Komplexität der zur Ausgabe des Getränks verwendeten Maschine erhöht.
<G-vec00380-002-s076><dispense.ausgeben><en> However this necessitates the provision of a steam supply which increases the cost and complexity of the machine used to dispense the beverage.
<G-vec00555-002-s028><eject.ausgeben><de> Drücken Sie auf Auswahl und halten Sie die Taste gedrückt, damit der All-In-One das gestaute Papier automatisch ausgibt.
<G-vec00555-002-s028><eject.ausgeben><en> Have the All-In-One automatically eject the jammed paper by pressing and holding Select.
