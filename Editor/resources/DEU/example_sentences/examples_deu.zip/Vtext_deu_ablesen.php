<G-vec00207-002-s038><read.ablesen><de> Anhand der Figuren und ihrer Konflikte lassen sich allgemeingültige Prinzipien menschlichen Verhaltens ablesen.
<G-vec00207-002-s038><read.ablesen><en> Based on the figures and their conflicts, it is possible to read general principles of human behavior.
<G-vec00207-002-s039><read.ablesen><de> Ein eisblaues Display hebt die Einstellungen und die Uhr leuchtend hervor, damit sie einfach zum Ablesen und Einstellen sind.
<G-vec00207-002-s039><read.ablesen><en> An ice blue display brightly illuminates the settings and clock, making them easier to read and operate.
<G-vec00207-002-s040><read.ablesen><de> Die Herzfrequenz lässt sich über die integrierten Handpulssensoren ablesen.
<G-vec00207-002-s040><read.ablesen><en> Heart rate can be read and monitored by means of integrated hand pulse sensors throughout every training session.
<G-vec00207-002-s041><read.ablesen><de> Hier kann man die Entwicklung der ganzen Balkanhalbinsel an den Bauten ablesen.
<G-vec00207-002-s041><read.ablesen><en> Here, in the buildings, you can read the development of the whole Balkan Peninsula.
<G-vec00207-002-s042><read.ablesen><de> Die Messwerte können Sie auf der großen Anzeige bequem ablesen und eventuell notwendige Schritte für die Isolierung oder Anlagenwartung in die Wege leiten.
<G-vec00207-002-s042><read.ablesen><en> You can easily read off the measuring values on the large display and initiate any steps that may be necessary in terms of insulation or system maintenance.
<G-vec00207-002-s043><read.ablesen><de> Da sah er, wie die 24 Ältesten anzuordnen waren und wie man die Jahreszahlen ablesen kann, auf die die vier Außensterne des Orion zeigten.
<G-vec00207-002-s043><read.ablesen><en> Then he saw how the 24 elders were arranged and how to read the year numbers which the four outer stars of Orion indicated.
<G-vec00207-002-s044><read.ablesen><de> Es ist gut, alles Notwendige auswendig zu lernen, bevor du anfängst, aber du kannst es auch direkt aus deinem Buch ablesen.
<G-vec00207-002-s044><read.ablesen><en> It's good to memorize everything necessary before starting, but you may also read directly from your book.
<G-vec00207-002-s045><read.ablesen><de> Dank der Skalierung am Teleskop lässt sich die Eintauchtiefe einfach ablesen.
<G-vec00207-002-s045><read.ablesen><en> The immersion depth is easy to read off thanks to the scaling on the telescope.
<G-vec00207-002-s046><read.ablesen><de> Gleichzeitig lässt sich an diesem Phänomen auch ablesen, dass psychische Krankheiten individualisiert und privatisiert wurden.
<G-vec00207-002-s046><read.ablesen><en> At the same time one can read from this phenomenon that psychological illnesses have become individualized and privatized.
<G-vec00207-002-s047><read.ablesen><de> Die Bedieneinheit speichert die letzte Betriebseinstellung, und Sie können Verbrauchsdaten direkt vom Display ablesen.
<G-vec00207-002-s047><read.ablesen><en> The control panel stores the last settings and you can read consumption data directly from the display.
<G-vec00207-002-s048><read.ablesen><de> Das 4-Zoll-Farbdisplay lässt sich leicht ablesen und bietet frei konfigurierbare Anzeigen.
<G-vec00207-002-s048><read.ablesen><en> 4" colour display The 4" full-colour display is easy to read with custom screens.
<G-vec00207-002-s049><read.ablesen><de> Darüber hinaus ist es möglich, die Zugriffskontrolle einzuschalten, die selbst dem SAP HR Administrator das Ablesen von Daten unmöglich macht.
<G-vec00207-002-s049><read.ablesen><en> Additionally, it is possible to activate an access control system preventing the data being read even by a SAP HR system administrator.
<G-vec00207-002-s050><read.ablesen><de> Die Güte eines Prädiktors lässt sich aus dem Unterschied der Studienerfolgswahrscheinlichkeit bei guten und schlechten Ausprägungen ablesen.
<G-vec00207-002-s050><read.ablesen><en> The quality of a predictor can be read from the difference between study success probability of good and bad manifestations.
<G-vec00207-002-s051><read.ablesen><de> Sie werden alle Infos vom Notfall-Keyboard ablesen können, ohne das Tablet entsperren zu müssen.
<G-vec00207-002-s051><read.ablesen><en> They will be able to read all the info you have fill in the emergency keyboard, without unlocking the tablet.
<G-vec00207-002-s052><read.ablesen><de> Daher ist es wichtig, die Temperatur genau und schnell ablesen zu können.
<G-vec00207-002-s052><read.ablesen><en> Thus, it is important to be able to read the temperature precisely and quickly.
<G-vec00207-002-s053><read.ablesen><de> Über die Vor-Ort-Anzeige lässt sich der Druck bezogen auf 20 °C direkt am Gerät ablesen.
<G-vec00207-002-s053><read.ablesen><en> Via the on-site display, the pressure based on 20 °C can be read directly on the instrument.
<G-vec00207-002-s054><read.ablesen><de> Um die Werte in jeder Situation und bei jeder Neigung einfach ablesen zu können, dreht sich das Farbdisplay automatisch mit – wie bei einem Smartphone.
<G-vec00207-002-s054><read.ablesen><en> The color display rotates automatically (as with smartphones), allowing the user to easily read off values in any situation and at any incline.
<G-vec00207-002-s055><read.ablesen><de> Wenn Sie die Anfangsbuchstaben der gewünschten Stadt über dem gelben Pfeil platzieren, können Sie durch die Stunden -und Minutenanzeige, die sich direkt unterhalb des gelben Pfeils befindet, sofort die Zeit an jedem beliebigen Ort der Welt ablesen.
<G-vec00207-002-s055><read.ablesen><en> By aligning the initials of the desired city above the yellow arrow, you can instantly see the time anywhere in the world while the minutes can be read underneath the yellow arrow indicating the hour in the reference city.
<G-vec00207-002-s056><read.ablesen><de> Wenn Sie schon einen Ring haben, der gut passt, können Sie eine Ringstange nutzen, über die Sie den Ring schieben können und die Ringgröße einfach ablesen können.
<G-vec00207-002-s056><read.ablesen><en> If you already have a ring that fits well, you can use a ring stick where you slide the ring on and simply read the ring size.
