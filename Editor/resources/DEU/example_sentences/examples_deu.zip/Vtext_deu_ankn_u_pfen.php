<G-vec00364-002-s022><relive.anknüpfen><de> Im Laufe der Zeit konnte sich die Stadt aber wieder erholen und an alte Erfolge anknüpfen.
<G-vec00364-002-s022><relive.anknüpfen><en> Over the course of time, however, the city was able to recover and relive its previous success.
