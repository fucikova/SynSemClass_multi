<G-vec00380-003-s049><shake_off.aufrütteln><de> Mit seinen Werken möchte Coombs in der Tradition Richard Avedons aufrütteln und verstören und den Betrachter so zum Fühlen und Denken anregen.
<G-vec00380-003-s049><shake_off.aufrütteln><en> Coombs’ work attempts to shake up and unsettle the viewer in the fashion of Richard Avedon, encouraging them to feel and think.
<G-vec00380-003-s050><shake_off.aufrütteln><de> Ich wollte aufrütteln.
<G-vec00380-003-s050><shake_off.aufrütteln><en> I want to shake my viewer.
<G-vec00380-003-s051><shake_off.aufrütteln><de> Patch 1.11 brachte zahlreiche Stabilitätsänderungen und die Zugabe von Skye, einem frischen Mittel zum Aufrütteln des Metas.
<G-vec00380-003-s051><shake_off.aufrütteln><en> Patch 1.11 brought numerous stability changes and the addition of Skye, a fresh agent to shake up the meta.
<G-vec00380-003-s052><shake_off.aufrütteln><de> Er will Ihr verschlafenes Leben aufrütteln.
<G-vec00380-003-s052><shake_off.aufrütteln><en> It wants to shake up your sleepy life.
<G-vec00380-003-s053><shake_off.aufrütteln><de> Das Verbot im Sommer 2017, zu verstehen als staatlichen Racheakt für den Kontrollverlust beim G20 Gipfel, sollte selbst diejenigen aufrütteln, die noch Erwartungen an den bürgerlichen Rechtsstaat und seine vermeintliche Pressefreiheit haben.
<G-vec00380-003-s053><shake_off.aufrütteln><en> In the summer of 2017, the ban, to be understood as an act of state revenge for the loss of control at the G20 summit, was supposed to shake up even those who still have expectations of the bourgeois constitutional state and its supposed freedom of the press.
<G-vec00380-003-s054><shake_off.aufrütteln><de> Der gerade aufgedeckte Hackerangriff auf Politiker und Prominente in Deutschland sollte auch dich aufrütteln.
<G-vec00380-003-s054><shake_off.aufrütteln><en> The newly discovered hacker attack on politicians and celebrities in Germany should also shake you up.
<G-vec00380-003-s055><shake_off.aufrütteln><de> Die Not wird an alle Menschen herantreten, wenn auch in verschiedener Weise, denn Ich will alle Menschen aufrütteln aus ihrem Untätigkeitszustand, Ich will, daß sie erwachen aus ihrem Todesschlafe und erkennen, was ihnen bevorsteht.
<G-vec00380-003-s055><shake_off.aufrütteln><en> Trouble will approach all men, even so in different ways, for I want to shake up all men from their state of inactivity; I want that they wake up from their sleep of death and recognize, what is in store for them.
<G-vec00380-003-s056><shake_off.aufrütteln><de> Wenn Sie die Dinge aufrütteln wollen, rufen Sie Shakey an.
<G-vec00380-003-s056><shake_off.aufrütteln><en> When You Want To Shake Things Up, Call Shakey
