<G-vec00555-002-s064><eject.auswerfen><de> Nach Abschluss der Übertragung können Sie auf das Auswurfsymbol in der Taskleiste klicken, um den Player anzuhalten und auszuwerfen.
<G-vec00555-002-s064><eject.auswerfen><en> Once the recovery process is complete, you may click on the removal icon on the task tray to stop and eject the player.
