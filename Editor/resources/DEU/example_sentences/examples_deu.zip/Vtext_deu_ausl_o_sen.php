<G-vec00547-001-s057><alarm.auslösen><de> Die Funktion sollte ein Bedarfsdetektor sein, um rechtzeitig einen Alarm auszulösen, wenn der Behälter leer ist und mehr Material eingefüllt werden sollte.
<G-vec00547-001-s057><alarm.auslösen><en> The function should be a demand detector to set an alarm in time if the hopper gets empty and more material should be filled in.
<G-vec00547-001-s058><alarm.auslösen><de> Aber selbst wenn es sich in der Nähe des Uterusbodens befindet, haben Ärzte keine Eile, den Alarm auszulösen, da sie mit dem Verlauf der Schwangerschaft ansteigen können.
<G-vec00547-001-s058><alarm.auslösen><en> But even if it is located close to the bottom of the uterus, doctors are not in a hurry to sound the alarm, as with the course of pregnancy it can rise.
<G-vec00547-001-s059><alarm.auslösen><de> Zögern Sie nicht, einen Alarm auszulösen, auch wenn die Lage noch nicht so kritisch erscheint.
<G-vec00547-001-s059><alarm.auslösen><en> Don't hesitate to release an alarm, even if the situation seems not that critical.
<G-vec00547-001-s060><alarm.auslösen><de> Wenn es jedoch keine Versiegelungen in der Brustdrüse und keinen Ausfluss aus den Brustwarzen gibt, sollten Sie sich darüber keine Sorgen machen: Tatsache ist, dass der Schmerz für die letzten Stadien der Tumorentwicklung charakteristisch ist, aber wenn vorher keine Beschwerden aufgetreten sind Es ist nicht nötig, den Alarm auszulösen.
<G-vec00547-001-s060><alarm.auslösen><en> However, if there are no seals in the mammary gland and no discharge from the nipples, you should not worry about it: the fact is that pain is characteristic of the last stages of tumor development, but if there were no complaints before, then there is no need to sound the alarm .
<G-vec00547-001-s061><alarm.auslösen><de> In fünf Stationen gibt es Abfallsammelboxen für Kartenausstanzungen, bei denen Sensoren erkannt werden, um Alarm auszulösen, wenn er voll ist.
<G-vec00547-001-s061><alarm.auslösen><en> There are waste material collecting boxes in five stations sim card punching equipment, with detecting sensors to make alarm if it will be full.
<G-vec00547-001-s062><alarm.auslösen><de> All diese Angriffe durch die innere und äußere Reaktion hätten genügt, um Alarm auszulösen und hätten Allende wachrütteln müssen.
<G-vec00547-001-s062><alarm.auslösen><en> These attacks by internal and external reaction would have been sufficient to sound the alarm and make Allende reflect.
<G-vec00547-001-s063><alarm.auslösen><de> Wenn jedoch die Markierung auf der Waage aus irgendeinem unbekannten Grund hartnäckig nach oben kriecht, lohnt es sich, den Alarm auszulösen.
<G-vec00547-001-s063><alarm.auslösen><en> But if the mark on the scales for some unknown reason, stubbornly creeps up, then it is worth sounding the alarm.
<G-vec00547-001-s064><alarm.auslösen><de> Scheuen Sie sich nicht, einen Alarm auszulösen - selbst wenn aus Ihrer Sicht die Situation noch nicht sehr kritisch erscheint.
<G-vec00547-001-s064><alarm.auslösen><en> Don't hesitate to release an alarm - even if the situation seems not that critical to you.
<G-vec00547-001-s065><alarm.auslösen><de> Wenn jedoch die Markierung auf der Waage aus einem unbekannten Grund hartnäckig auftaucht, lohnt es sich, den Alarm auszulösen.
<G-vec00547-001-s065><alarm.auslösen><en> But if the mark on the scales, for some unknown reason, stubbornly creeps upwards, then it is worth sounding the alarm.
<G-vec00547-001-s066><alarm.auslösen><de> Der ST340 Sauerstoffmangeldetektor wurde speziell dafür konzipiert, einen Alarm auszulösen, wenn die Sauerstoffwerte vom Umgebungswert von 20,9 % abweichen.
<G-vec00547-001-s066><alarm.auslösen><en> TheST341 (O2) Deficiency Detector is designed specifically to alarm when oxygen levels deviate from the ambient value of 20.9%.
<G-vec00547-001-s067><alarm.auslösen><de> Bei einem einmaligen Blutdruckabfall auf 90 bis 80 ist es nicht erforderlich, einen Alarm auszulösen und eine Diagnose zu stellen.
<G-vec00547-001-s067><alarm.auslösen><en> With a one-time decrease in blood pressure to the level of 90 to 80, it is not necessary to sound the alarm and set yourself a diagnosis.
<G-vec00547-001-s068><alarm.auslösen><de> Die Lösungen von Siemens sind darauf ausgelegt, Brände so früh wie möglich zu erkennen, Alarm auszulösen und die vorprogrammierten Steuerfunktionen zu aktivieren.
<G-vec00547-001-s068><alarm.auslösen><en> Solutions from Siemens are built to detect fires as early as possible, to alarm and activate the preprogrammed control functions.
<G-vec00179-001-s079><trigger.auslösen><de> In Vertriebsbelegen, durch die keine Lagerbuchungen in der Materialwirtschaft ausgelöst werden, wird in der Positionsinformation zu einer Teileposition der Einstandspreis angezeigt.
<G-vec00179-001-s079><trigger.auslösen><en> In sales documents which do not trigger inventory postings in materials management, the cost price is displayed in the line information for a part line.
<G-vec00179-001-s080><trigger.auslösen><de> Mit ihnen werden die HGÜ-Umrichtermodule innerhalb von Millisekunden ausgelöst....
<G-vec00179-001-s080><trigger.auslösen><en> They trigger the HVDC conversion modules within milliseconds....
<G-vec00179-001-s081><trigger.auslösen><de> Sobald die Einführungsphase abgeschlossen ist, wird F&F mit Hilfe der RFID-Technologie kontinuierlich überprüfen können, ob der Systembestand exakt den tatsächlichen Bestand wiedergibt, so dass Nachbestellungen an der richtigen Stelle ausgelöst und Regallücken vermieden werden können.
<G-vec00179-001-s081><trigger.auslösen><en> Once the roll-out is complete, F&F will use RFID technology to continually keep the system stock accurately reflecting the physical stock, in order to trigger repeat orders at the right point and avoid out of stocks.
<G-vec00179-001-s082><trigger.auslösen><de> Dadurch wird ein Alarm ausgelöst und ein Wachmann kommt in die Zelle gestürmt.
<G-vec00179-001-s082><trigger.auslösen><en> This will trigger an alert and a guard will come rushing into the room.
<G-vec00179-001-s083><trigger.auslösen><de> Joker-Neu-Drehs ausgelöst, wenn der joker Hut-Symbol erscheint auf dem 2Nd, 3Rd Und 4Th Rollen.
<G-vec00179-001-s083><trigger.auslösen><en> Joker Re-spins will trigger when the joker hat icon appears on the 2nd, 3rd and 4th reels.
<G-vec00179-001-s084><trigger.auslösen><de> "Die Phasen ""Hold"" und ""Decay"" des AHDSR-Envelopes von Alchemy werden nun einheitlich mit kurzen Werten ausgelöst."
<G-vec00179-001-s084><trigger.auslösen><en> Alchemy AHDSR envelope Hold and Decay stages now trigger consistently with short values.
<G-vec00179-001-s085><trigger.auslösen><de> Wenn du in einem oder beiden deiner Handgelenke Schmerzen bemerkt, solltest du eine Pause einlegen und das Handgelenk, je nachdem was sie ausgelöst hat, für ein paar Minuten, Stunden oder sogar Tage ausruhen, indem du auf verschlimmernde Aktivitäten verzichtest.
<G-vec00179-001-s085><trigger.auslösen><en> If you notice pain in one or both of your wrists, take a break from the aggravating activity and rest for a few minutes, hours or even days depending on the trigger of the pain.
<G-vec00179-001-s086><trigger.auslösen><de> Wird nicht in PvP-Bereichen ausgelöst.
<G-vec00179-001-s086><trigger.auslösen><en> It will not trigger inside of PvP areas.
<G-vec00179-001-s087><trigger.auslösen><de> Sebastian Thomas Philipp erfahren, dass durch Meditation Lernprozesse ausgelöst werden können.
<G-vec00179-001-s087><trigger.auslösen><en> Sebastian Thomas Philipp and learn how meditating can trigger learning processes in the brain.
<G-vec00179-001-s088><trigger.auslösen><de> """Wir haben das System so eingerichtet, dass bei kritischen Vorfällen auf den Mobiltelefonen des Sicherheitsteams automatisch Alarm ausgelöst wird."
<G-vec00179-001-s088><trigger.auslösen><en> """We have set the system to automatically trigger alerts to the security team's mobile phones should there be an incident that requires our attention."
<G-vec00179-001-s089><trigger.auslösen><de> Legen Sie Logtyp, logischen Operator und Filterkriterien fest, für die der Task ausgelöst werden soll.
<G-vec00179-001-s089><trigger.auslösen><en> Define the log type, logical operator and filtering criteria that will trigger the task.
<G-vec00179-001-s090><trigger.auslösen><de> Beim Ändern von Mehrwegpackmitteln und Mehrwegpackmittelzubehör in Transportbelegen können in der Packmittelverwaltung Packmittelbuchungen ausgelöst werden.
<G-vec00179-001-s090><trigger.auslösen><en> When returnable packaging and returnable packaging accessories are changed in transport documents, this can trigger packaging postings in packaging management.
<G-vec00179-001-s091><trigger.auslösen><de> Achten Sie auf die bonusrunden im Spiel Reel King, die zufällig im Laufe des Spiels ausgelöst wird.
<G-vec00179-001-s091><trigger.auslösen><en> Look out for the Reel King bonus feature to trigger at random intervals throughout play.
<G-vec00179-001-s092><trigger.auslösen><de> Beachten Sie, daß wenn Sie eine Datei aus dem Laufwerk heraus verschieben dieselbe Aktion ausgelöst wird, denn ein solches Verschieben ist identisch mit Kopieren gefolgt von Löschen.
<G-vec00179-001-s092><trigger.auslösen><en> Note that if you manually move a file off the volume to some other drive letter this will trigger the same action, because that kind of moving is identical to copying followed by deletion.
<G-vec00179-001-s093><trigger.auslösen><de> Es wird angenommen, eine Art der Immunantwort zu entwickeln, scheitert, die Haare und dass diese Reaktion kann verschiedene Faktoren ausgelöst werden – so.
<G-vec00179-001-s093><trigger.auslösen><en> It is believed to develop a type of immune response fails, the hairs and that this reaction can trigger different factors – so.
<G-vec00179-001-s094><trigger.auslösen><de> Die Chance, dass 'Gabe der Schlange' ausgelöst wird, wurde für diverse Nebelwirkerzauber signifikant erhöht und der Effekt verwendet einen höheren Prozentzsatz des Maximalwertes.
<G-vec00179-001-s094><trigger.auslösen><en> Gift of the Serpent chance to trigger has increased significantly for various Mistweaver spells, conferring a larger percentage of the maximum value.
<G-vec00179-001-s095><trigger.auslösen><de> Die Cue wird durch ein 'go' ausgelöst.
<G-vec00179-001-s095><trigger.auslösen><en> This will make the cue trigger by a 'go'.
<G-vec00179-001-s096><trigger.auslösen><de> Über 3 frei konfigurierbare Schwellen können Alarme ausgelöst oder Funktionen gesteuert werden.
<G-vec00179-001-s096><trigger.auslösen><en> 3 adjustable thresholds can trigger alarms or other processes.
<G-vec00179-001-s097><trigger.auslösen><de> Diese Stufe sollte erst ausgelöst werden, wenn dem ersten Satz von zwei Starthilfsraketen der Treibstoff ausgeht.
<G-vec00179-001-s097><trigger.auslösen><en> Trigger this stage only after the first set of two boosters are out of fuel
<G-vec00179-001-s098><trigger.auslösen><de> Dieser neue Bereinigungsvorgang kann auch manuell durch Erstellen der Datei ACLFIX.SEM im Verzeichnis \App\ ausgelöst werden.
<G-vec00179-001-s098><trigger.auslösen><en> Also you can create ACLFIX.SEM in the \App\ folder to trigger just this cleanup routine.
<G-vec00179-001-s099><trigger.auslösen><de> So können interne Wertkorrekturen für die Bestandteile ausgelöst werden.
<G-vec00179-001-s099><trigger.auslösen><en> This can trigger internal value corrections for the components.
<G-vec00179-001-s100><trigger.auslösen><de> Diese Sonderereignisse benötigen die Spezialität oder den Skill von zwei Spielern um ausgelöst zu werden.
<G-vec00179-001-s100><trigger.auslösen><en> These Special Events need the speciality or skill of two players to trigger
<G-vec00179-001-s101><trigger.auslösen><de> Einige Kosmologen behaupten, dass durch einen kurzen Sturm von Elementarteilchen Irregularitäten der Materie ausgelöst werden können.
<G-vec00179-001-s101><trigger.auslösen><en> Some cosmologists claim that a brief storm of fundamental particles can trigger irregularities in matter.
<G-vec00179-001-s102><trigger.auslösen><de> Dadurch können deutlichere Stoffwechselverbesserungen ausgelöst werden, als es mit zuvor bekannten medikamentösen Ansätzen möglich schien.Dreifachhormon senkt Körpergewicht und verbessert Insulinsensitivität Aktuell präsentierte das interdisziplinäre Wissenschaftlerteam, unter Führung von Tschöp und DiMarchi, ein Dreifachhormon, das im Tiermodell nicht nur Blutzuckerspiegel, Appetit und Körperfett drastisch senkt, sondern auch Leberverfettung, Cholesterinwerte und Kalorienverbrennung verbessert – und zwar noch effektiver als es mit bisher verfügbaren mono-aktiven oder dual wirksamen Molekülen möglich war.
<G-vec00179-001-s102><trigger.auslösen><en> They can consequently trigger more significant metabolic improvements than was previously possible with known medicinal approaches.Triple hormone reduces body weight and improves insulin sensitivity The interdisciplinary team led by Tschöp and DiMarchi is now presenting a triple hormone that dramatically reduces blood glucose, appetite, and body fat in animal models while also improving fat content in the liver, cholesterol levels and calorie burning even more effectively than with previously available single action or dual action molecules.
<G-vec00179-001-s103><trigger.auslösen><de> Dieser Effekt kann nicht mit dem nächsten Einsatz von 'Erneuernder Nebel' oder 'Tritt der aufgehenden Sonne' ausgelöst werden.
<G-vec00179-001-s103><trigger.auslösen><en> This effect cannot trigger on the next Renewing Mist or Rising Sun Kick.
<G-vec00179-001-s104><trigger.auslösen><de> Die 3D-Grafik ist großartig und wird Sie mit einer großen Auswahl an Bonus belohnt jedes Mal, wenn Sie eine Funktion oder großen Gewinn ausgelöst werden.
<G-vec00179-001-s104><trigger.auslösen><en> The 3D graphics are great and will provide you with a massive selection of bonus rewards each time you trigger a feature or big win.
<G-vec00179-001-s105><trigger.auslösen><de> Unter diese außergewöhnlichen Materialien Gewebe Fortschritt ausgelöst werden, während Flüssigkeit zu halten Gewinne in der Zähigkeit produziert und bringt mehr Muskelmasse.
<G-vec00179-001-s105><trigger.auslösen><en> Taking these exceptional substances trigger tissue development while retaining liquid causes gains in strength and leads to a lot more muscular tissue mass.
<G-vec00179-001-s106><trigger.auslösen><de> ...Teilepositionen, durch die keine Lagerbuchungen in der Materialwirtschaft ausgelöst werden.
<G-vec00179-001-s106><trigger.auslösen><en> ...part lines which do not trigger any inventory postings in materials management.
<G-vec00179-001-s107><trigger.auslösen><de> Wenn Range-Trader verkaufen, können Sie Order platzieren, die dann ausgelöst werden, wenn der Kurs den Widerstand übersteigt und der RSI wieder auf einen Wert von unter 70 sinkt.
<G-vec00179-001-s107><trigger.auslösen><en> To sell range traders can trigger orders when price moves off resistance and RSI crosses back below a reading of 70.
<G-vec00179-001-s108><trigger.auslösen><de> Ziel der Zusammenkunft der neun Bankenchefs und der Festlegung auf die Teilnahme am Rettungsplan war es zu verhindern, dass eine Bank, die die staatliche Beteiligung annimmt, stigmatisiert würde und ein Wettlauf gegen sie ausgelöst werden könnte.
<G-vec00179-001-s108><trigger.auslösen><en> The aim of bringing together the nine executives and making them all participate in the plan, is to avoid stigmatizing a bank that accepts state participation, which could trigger a run against it.
<G-vec00179-001-s109><trigger.auslösen><de> Tür-Überprüfungs-Fahrt (TÜF) durch Aufzugswärter Vom Fahrkorb aus kann per Schlüsselschalter die Tür-Überprüfungsfahrt ausgelöst werden.
<G-vec00179-001-s109><trigger.auslösen><en> Door checking drive (TÜF) by lift attendant A key switch in the car can trigger the door checking drive.
<G-vec00179-001-s110><trigger.auslösen><de> In dieser Realität spielt die Bevölkerung eine sehr wichtige Rolle, denn ohne ein wirkliches Bewusstsein für das Umweltproblem, was auf der Insel existiert und deren schwerwiegenden Folgen, die ausgelöst werden können, tragen sie mit ihren Alltagsaktivitäten zur Verschärfung des Problems bei.
<G-vec00179-001-s110><trigger.auslösen><en> The population plays an important role in this reality since the lack of real awareness about the environmental problem existing in the isle and about the serious consequences that it can trigger, contribute in their daily practices by worsening the problem.
<G-vec00169-001-s259><raise.auslösen><de> Jedoch im Internet Suche keine Ergebnisse bezüglich Vertreter mit Sitz in Vietnam oder spezialisierte Unternehmen leicht zugänglich für diese Versorgung auslösen.
<G-vec00169-001-s259><raise.auslösen><en> However on-line searches do not raise any sort of outcomes regarding suppliers based in Vietnam or specialized company available for this supply.
<G-vec00169-001-s260><raise.auslösen><de> Wissenschaftler sagen, dass Himbeer Ketone Ihre Körpertemperatur auslösen können, die wiederum mehr Fette freigesetzt, die bereits gespeichert sind und sie bricht.
<G-vec00169-001-s260><raise.auslösen><en> Scientists mention that raspberry ketones can raise your body temperature level, which in turn launches a lot more fats that are currently held and damages them down.
<G-vec00169-001-s261><raise.auslösen><de> Dennoch keine online-Durchsuchungen Ergebnisse über Lieferanten auslösen in Dhekelia oder spezialisierte Geschäft für dieses Angebot zur Verfügung.
<G-vec00169-001-s261><raise.auslösen><en> Nevertheless on the internet searches do not raise any sort of results regarding distributors based in Dhekelia or specialised company readily available for this supply.
<G-vec00169-001-s262><raise.auslösen><de> Dennoch auslösen Online sucht keine beliebige Ergebnisse über Händler mit Sitz in Botswana oder spezialisierte Firma für diese Versorgung verfügbar.
<G-vec00169-001-s262><raise.auslösen><en> Nonetheless on the internet searches do not raise any kind of results about distributors based in Botswana or specialist company offered for this supply.
<G-vec00169-001-s264><raise.auslösen><de> Jedoch online Recherchen keine Ergebnisse hinsichtlich Lieferanten mit Sitz in Guernsey auslösen oder spezialisiertes Unternehmen für diese Versorgung angeboten.
<G-vec00169-001-s264><raise.auslösen><en> Nevertheless online searches do not raise any sort of results about representatives based in Guernsey or specialised firm readily available for this supply.
<G-vec00169-001-s267><raise.auslösen><de> Aber im Internet keine sucht jede Art von Resultaten über Händler mit Sitz in Mali auslösen oder spezialisierte Firma für diese Versorgung angeboten.
<G-vec00169-001-s267><raise.auslösen><en> Nevertheless on the internet searches do not raise any sort of outcomes about distributors based in Mali or specialised company readily available for this supply.
<G-vec00169-001-s268><raise.auslösen><de> Jedoch online Suche keine Ergebnisse über Lieferanten mit Sitz in St. Helena oder Spezialgeschäft für diese Versorgung verfügbar auslösen.
<G-vec00169-001-s268><raise.auslösen><en> Nevertheless on the internet searches do not raise any type of results concerning suppliers based in Saint Helena or specialized company offered for this supply.
<G-vec00169-001-s269><raise.auslösen><de> Dennoch im Internet sucht jede Art von Ergebnissen bezüglich Vertreter mit Sitz in der Slowakei keine auslösen oder spezialisierten Unternehmen für diese Versorgung angeboten.
<G-vec00169-001-s269><raise.auslösen><en> However on the internet searches do not raise any sort of results about distributors based in Slovakia or specialised company available for this supply.
<G-vec00169-001-s270><raise.auslösen><de> Trotzdem im Internet sucht jede Art von Ergebnissen bezüglich Lieferanten in Polen keine auslösen oder spezialisiertes Unternehmen für diese Versorgung angeboten.
<G-vec00169-001-s270><raise.auslösen><en> Nonetheless online searches do not raise any kind of results concerning distributors based in Poland or specialist firm readily available for this supply.
<G-vec00169-001-s271><raise.auslösen><de> Trotzdem im Internet sucht jede Art von Ergebnissen über die Lieferanten mit Sitz in Moldawien keine auslösen oder Spezialunternehmen für diese Versorgung angeboten.
<G-vec00169-001-s271><raise.auslösen><en> Nevertheless on-line searches do not raise any type of outcomes about suppliers based in Moldova or specialist firm readily available for this supply.
<G-vec00169-001-s272><raise.auslösen><de> Jedoch Online Suche keine Ergebnisse über Distributoren auslösen mit Sitz in Timor Leste oder spezialisierte Geschäft für dieses Angebot zur Verfügung.
<G-vec00169-001-s272><raise.auslösen><en> However online searches do not raise any type of outcomes regarding distributors based in Timor Leste or specialised company readily available for this supply.
<G-vec00169-001-s275><raise.auslösen><de> Die Ergebnisse werden Erstaunen auslösen.
<G-vec00169-001-s275><raise.auslösen><en> The results will raise eyebrows.
<G-vec00169-001-s276><raise.auslösen><de> Dennoch im Internet sucht jede Art von Ergebnissen bezüglich Händler mit Sitz in Kroatien keine auslösen oder Spezialunternehmen für diese Versorgung angeboten.
<G-vec00169-001-s276><raise.auslösen><en> Nevertheless online searches do not raise any outcomes regarding suppliers based in Croatia or specialized company offered for this supply.
<G-vec00169-001-s277><raise.auslösen><de> Dennoch im Internet suchen jede Art von Ergebnissen über Lieferanten mit Sitz in Guernsey keine auslösen oder spezialisierte Unternehmen angeboten für dieses Angebot.
<G-vec00169-001-s277><raise.auslösen><en> Nonetheless on-line searches do not raise any results concerning distributors based in Guernsey or specialised business readily available for this supply.
<G-vec00035-001-s021><redeem.auslösen><de> 13 Will es aber jemand unbedingt wieder auslösen, so soll er den fünften Teil deiner Schätzung dazugeben.
<G-vec00035-001-s021><redeem.auslösen><en> 13 'But if he should ever wish to redeem it, then he shall add one-fifth of it to your valuation.
<G-vec00035-001-s022><redeem.auslösen><de> Aber das Erstgeborene vom Rind oder das Erstgeborene von den Schafen oder das Erstgeborene von den Ziegen sollst du nicht auslösen; sie sind heilig.
<G-vec00035-001-s022><redeem.auslösen><en> But you shall not redeem the firstborn of a cow, or the firstborn of a sheep, or the firstborn of a goat. They are holy.
<G-vec00035-001-s023><redeem.auslösen><de> Alle Erstgeburt deiner Söhne sollst du auslösen.
<G-vec00035-001-s023><redeem.auslösen><en> All the firstborn of thy sons thou shalt redeem.
<G-vec00035-001-s024><redeem.auslösen><de> Wir werden für eine Kautionshinterlegung in Form von Getreide, Geld auszahlen und wenn der Landwirt die Möglichkeit findet, das Getreide selbst zu verkaufen und es auslösen möchte, zahlt er uns das Geld zurück“ sagte Vladimir Putin in Stavropol auf einem Treffen mit Landwirten.
<G-vec00035-001-s024><redeem.auslösen><en> We will pay money for grain deposits and if farmers find a way of selling the grain themselves and want to redeem their deposit, they can simply pay the money back,’ said Vladimir Putin in Stavropol at a meeting with farmers.
<G-vec00035-001-s026><redeem.auslösen><de> Unsere Sehnsucht danach, wie die Dinge wären, wenn wir so würden, wie wir sein könnten, wird uns aus der Vergangenheit auslösen, indem wir unsere Wahl treffen für unseren nächsten Schachzug.
<G-vec00035-001-s026><redeem.auslösen><en> "Our nostalgia for ""the way things would be"" if we became ""how we could be"" will redeem us from our past by opting for our next move on the chess board."
<G-vec00035-001-s027><redeem.auslösen><de> 16 Und die zu Lösenden unter ihnen sollst du im Alter von einem Monat auslösen, nach deiner Einschätzung mit fünf Schekel Silber nach dem Schekel des Heiligtums, der zwanzig Gera beträgt.
<G-vec00035-001-s027><redeem.auslösen><en> "16 ""And as to their redemption price, from a month old you shall redeem them, by your valuation, five shekels in silver, according to the shekel of the sanctuary, which is twenty gerahs."
<G-vec00035-001-s028><redeem.auslösen><de> 49 oder sein Onkel oder der Sohn seines Onkels darf ihn auslösen, oder sonst sein nächster Blutsverwandter aus seiner Familie kann ihn auslösen; oder wenn seine Hand so viel erwirbt, so soll er sich selbst auslösen.
<G-vec00035-001-s028><redeem.auslösen><en> 49 or his uncle or his cousin may redeem him, or a close relative from his clan may redeem him. Or if he grows rich he may redeem himself.
<G-vec00035-001-s030><redeem.auslösen><de> Alles, was [zuerst] den Mutterschoß durchbricht, von allem Fleisch, das sie dem HERRN darbringen an Menschen und an Vieh, soll dir gehören; nur sollst du unbedingt den Erstgeborenen vom Menschen auslösen, und [auch] das Erstgeborene vom unreinen Vieh sollst du auslösen.
<G-vec00035-001-s030><redeem.auslösen><en> Everything that opens the womb, of all flesh which they offer to Yahweh, both of man and animal shall be your: nevertheless the firstborn of man shall you surely redeem, and the firstborn of unclean animals shall you redeem.
<G-vec00179-001-s111><trigger.auslösen><de> "Weiters fordert der Mediziner eine bessere Aufklärung von Angehörigen älterer Patient/-innen: ""Viele Medikamente, die wir im Alltag benutzen, können in Kombination mit anderen Verwirrtheitszustände auslösen"", so der Neurologe."
<G-vec00179-001-s111><trigger.auslösen><en> "Furthermore, the doctor calls for a better information of the family members of elderly patients: ""Many medications which we use in every day life can trigger confusion syndromes in combination with other drugs,"" explains the neurologist."
<G-vec00179-001-s112><trigger.auslösen><de> Aber eigentlich konnte zahlreiche natürliche Produkte, die Sie erhebliche und gefährliche Rebounds Ergebnisse auslösen, wenn die Qualität der Komponenten ist nicht groß.
<G-vec00179-001-s112><trigger.auslösen><en> But actually, numerous natural products could trigger you substantial and dangerous rebounding results, if the quality of the components is not great.
<G-vec00179-001-s113><trigger.auslösen><de> Und er hätte die alten Ängste vieler Israelis ansprechen können, dass ein Friedensabkommen mit den Palästinensern einen Zustrom billiger palästinensischer Arbeitskräfte auslösen und die Arbeitslosigkeit in den jüdischen Randgebieten vergrößern würde.
<G-vec00179-001-s113><trigger.auslösen><en> He also could have addressed persistent fears that a peace agreement will trigger an influx of cheap Palestinian labor and increase unemployment in peripheral Jewish areas.
<G-vec00179-001-s114><trigger.auslösen><de> Anzahlungsrechnungen (Vertrieb) können in der Finanzbuchhaltung Buchungen auf Personenkonten auslösen.
<G-vec00179-001-s114><trigger.auslösen><en> Partial payment invoices (sales) can trigger postings to subsidiary accounts in financial accounting.
<G-vec00179-001-s115><trigger.auslösen><de> Verfahren der Haarentfernung, zB Rasieren, Zupfen, Zupfen, oder sogar in der Nähe Enthaarung kann durchweg sehr schädlich für die Hautfarbe auslösen und führt zu roten Schwimmer, in der Regel mit der gereizten Fläche zit zusammen mit Juckreiz.
<G-vec00179-001-s115><trigger.auslösen><en> Procedures of hair removing, for example shaving, plucking, tweezing, or even close depilation consistently may trigger very harmful for skin color and leads to red floater, typically with the irritated surface area zit along with itching.
<G-vec00179-001-s116><trigger.auslösen><de> "Mit der App ""FUJIFILM Camera Remote"" können Sie über Ihr Smartphone oder Tablet fokussieren und auslösen."
<G-vec00179-001-s116><trigger.auslösen><en> "With the new dedicated ""FUJIFILM Camera Remote"" application, you can focus and trigger the camera release from your smartphone or tablet."
<G-vec00179-001-s117><trigger.auslösen><de> Wenn Sie Dokumente automatisiert in PDF umwandeln möchten, also ohne dass ein Mensch das Dokument öffnen und den Druckvorgang auslösen müsste, dann bietet Ihnen die Version „PostScope AutoConvert“ auch dafür eine einfache Möglichkeit.
<G-vec00179-001-s117><trigger.auslösen><en> If you desire to convert documents into PDF automatedly, that means without a human being having to open the document and to trigger the print process, then version „PostScope AutoConvert“ offers you an easy-to-use facility for this purpose.
<G-vec00179-001-s118><trigger.auslösen><de> Die Entkopplung der Direktzahlungen von der Produktion ermöglicht Wohlfahrtsgewinne und steigende Einkommen, wird aber auch einen verstärkten Strukturwandel auslösen.
<G-vec00179-001-s118><trigger.auslösen><en> The decoupling of direct payments from production enables welfare gains and increasing incomes, but it will also trigger intensified structural changes.
<G-vec00179-001-s119><trigger.auslösen><de> "Da sie jedoch das Schicksal des Wesens auslösen, haben wir sie ""Schicksalsbogen"" genannt."
<G-vec00179-001-s119><trigger.auslösen><en> "Since they trigger the being's fate we have termed them ""arcs of fate""."
<G-vec00179-001-s120><trigger.auslösen><de> Also wenn du diese Art der Stoffwechselprozesse auslösen kannst werden Sie in der Lage zu verlieren Gewicht ohne großen Lebensstil oder Ernährung Änderungen.
<G-vec00179-001-s120><trigger.auslösen><en> So if you‘re able to trigger these type of metabolic procedures you’ll manage to lose weight without major lifestyle or diet regimen changes.
<G-vec00179-001-s121><trigger.auslösen><de> Wenn Oxandrolone selbst keine fantastische Muskelgewebe Entwicklung auslösen, kann es sicherlich verbessert die Muskelschaffende Effekte integriert, wenn sie mit einem anderen Steroid wie Deca, Clenbuterol oder Testosteron.
<G-vec00179-001-s121><trigger.auslösen><en> When Oxandrolone itself will not trigger a fantastic muscular tissue development, it can certainly improve the muscle creating effects if integrated with another steroid such as Deca, Clenbuterol or Testosterone.
<G-vec00179-001-s122><trigger.auslösen><de> Das Fehlen von Serotonin Hormone wird sicherlich auslösen Depression und Angst, die die Nahrungsmittelsehnsüchte erzeugen kann.
<G-vec00179-001-s122><trigger.auslösen><en> The lack of serotonin hormone will certainly trigger depression and stress and anxiety which can cause the food yearnings.
<G-vec00179-001-s123><trigger.auslösen><de> Mündliche Hefe-Infektion bei Männern würde wahrscheinlich ebenfalls auslösen Dermis Skalierung.
<G-vec00179-001-s123><trigger.auslösen><en> Oral yeast infection in guys would likely likewise trigger dermis scaling.
<G-vec00179-001-s124><trigger.auslösen><de> Wenn es injiziert wird, kann es eine geringen Bluthochdruck auslösen.
<G-vec00179-001-s124><trigger.auslösen><en> When it is injected, it might trigger low high blood pressure.
<G-vec00179-001-s125><trigger.auslösen><de> Wie jede Art von typischen oder traditionellen Arzneimittel / Nahrungsergänzungsmittel kann unter Dianabol negative Körperreaktionen und auch mehr Menschen erlebt haben verschiedene negative Effekte auslösen.
<G-vec00179-001-s125><trigger.auslösen><en> Like any standard or typical medicines/supplements, taking dianabol can trigger unfavorable body reactions and even more individuals have suffered from various side effects.
<G-vec00179-001-s126><trigger.auslösen><de> "Leid entsteht nicht durch Wünsche, sondern durch ""Sollvorstellungen"", durch die man andere oder sich selbst zu Opfern machen kann: Die Angst, dem, was verlangt wird (den ""Sollvorstellungen"") nicht gewachsen zu sein, kann viele negative Gefühle und Konflikte, ja sogar Haß, auslösen und sich als Bitterkeit im Charakter festsetzen und damit genau das verhindern, was doch das ursprüngliche Ziel war - das nämlich, was wir mit Spiritualität meinen: Erwachen, Freiheit, Freude, Ekstase, Meisterschaft, Großmut; eine schöne Welt mit schönen Menschen schaffen."
<G-vec00179-001-s126><trigger.auslösen><en> The fear of being overstressed by feeling unequal to what is expected of one can trigger off a resentment which may degenerate into conflict, even hatred, and manifest as bitterness in one's character. This would forfeit what the original objective was - namely, what we mean by spirituality: awakening, freedom, joy, ecstasy, mastery, magnanimity, and building a beautiful world of beautiful people.
<G-vec00179-001-s127><trigger.auslösen><de> "Ist der/die Patient/-in jünger, müsse auch immer an Drogen gedacht werden, ""denn auch diese können einen Zustand akuter Verwirrtheit auslösen""."
<G-vec00179-001-s127><trigger.auslösen><en> """If the patient is younger, illicit drugs always have to be taken into account, because they can also trigger a condition of acute confusion."""
<G-vec00179-001-s128><trigger.auslösen><de> Eines der beliebtesten Beispiele ist die Einstellung der Windows-Registrierung – Anpassungen Saiten durch das Betriebssystem verbunden sind, können erhebliche Effizienz Störungen auslösen und den Fehler auch Windows-Dienste zugreifen.
<G-vec00179-001-s128><trigger.auslösen><en> One of the popular examples is the adjustment of the Windows Registry – adjustments strings associated by the operating system can trigger significant efficiency disturbances and also the failure to access Windows services.
<G-vec00179-001-s129><trigger.auslösen><de> Ein Event kann die Sendung eines Auto-Responders auslösen.
<G-vec00179-001-s129><trigger.auslösen><en> An event will trigger an autoresponder to send.
<G-vec00179-001-s149><trigger.auslösen><de> """Diese Ergebnisse sind deshalb so interessant, da sie zeigen wie ein einfacher Stimulus ein komplexes Verhaltensmuster auslöst."
<G-vec00179-001-s149><trigger.auslösen><en> These findings are interesting, as they show how one stimulus can trigger such complex behaviour.
<G-vec00179-001-s150><trigger.auslösen><de> Daher besitzt es genau die gleichen schmerzlindernden Eigenschaften wie Ibuprofen jedoch nicht Lebertoxizität auslöst.
<G-vec00179-001-s150><trigger.auslösen><en> Hence, it possesses the exact same pain-relieving properties as ibuprofen however it does not trigger liver toxicity.
<G-vec00179-001-s151><trigger.auslösen><de> Es erwarten Sie drei Abende voller Musik, die trotz ihrer Komplexität aufs Wesentliche reduziert ist und nach wie vor Diskussionen auslöst.
<G-vec00179-001-s151><trigger.auslösen><en> Audiences can look forward to three evenings full of music that, despite its complexity, is reduced to the essential and is sure to trigger fascinating discussions.
<G-vec00179-001-s152><trigger.auslösen><de> Laut einigen Berichten Zenerx Kritik, ist das Element einfach sicher, weil es ist wirklich aus natürlichen Zutaten hergestellt und hat keine Zusatzstoffe, die Nebenwirkungen bei einigen männlichen Enhancer verknüpft auslöst.
<G-vec00179-001-s152><trigger.auslösen><en> According to some Zenerx review reports, the item is secure simply because it really is made from natural ingredients and has no additives that will trigger side-effects linked with some male enhancers.
<G-vec00179-001-s153><trigger.auslösen><de> So nimmt es nicht Wunder, wenn die erfolgreich überlebende Natur als Anregung dient, dass eine große Zahl der bionischen Entwicklungen auch militärische Assoziationen auslöst.
<G-vec00179-001-s153><trigger.auslösen><en> Therefore, it is not surprising when successfully surviving nature helps us understand why numerous bionic developments trigger military associations.
<G-vec00179-001-s154><trigger.auslösen><de> Nur so entsteht Architektur, die Frequenz auslöst.
<G-vec00179-001-s154><trigger.auslösen><en> Only then does architecture trigger frequency.
<G-vec00179-001-s155><trigger.auslösen><de> Auf allen Walzen befindet sich auch ein WILD-Symbol sowie ein Streusymbol, welches Freispiele auslöst.
<G-vec00179-001-s155><trigger.auslösen><en> There is a WILD that is stacked on all reels, and another scatter symbol to trigger free games.
<G-vec00179-001-s156><trigger.auslösen><de> Marketingspezialisten gehen zu den endlosen Extremen, um die perfekte Nachricht zu erstellen, die diese Mechanismen nicht auslöst.
<G-vec00179-001-s156><trigger.auslösen><en> Marketers go to endless extremes to create the perfect messages that won’t trigger these mechanisms.
<G-vec00179-001-s157><trigger.auslösen><de> Wenn das Wasser direkt aus der Wolke in reinster Form auf den Sensor fällt und diesen nicht auslöst, dann genügt es, wenn er über ein kleines Brett oder von einem Vordach aus auf den Sensor läuft.
<G-vec00179-001-s157><trigger.auslösen><en> If the water falls directly from the cloud on the sensor in its purest form and does not trigger it, it will be sufficient if it runs over a small board or from a porch roof on the sensor.
<G-vec00179-001-s158><trigger.auslösen><de> Die Zahl der Schatzkisten, die die Bonusrunde auslöst, bestimmt die Zahl der Wahlmöglichkeiten, die Sie erhalten, wenn Sie auf den Meeresgrund gebracht werden.
<G-vec00179-001-s158><trigger.auslösen><en> The number of Chests that trigger the bonus will determine the number of picks you will get when you’re transported to the bottom of the sea.
<G-vec00179-001-s159><trigger.auslösen><de> Das Symbol mit einer Goldmedaille fungiert hierbei als Wild-Symbol, während das Symbol mit Ananas und Fly-By das Bonusspiel auslöst.
<G-vec00179-001-s159><trigger.auslösen><en> The symbol of gold medal is the wild here, while the symbol of pineapple and Fly-By will trigger bonus features.
<G-vec00179-001-s160><trigger.auslösen><de> Das Team um Mikael Simons, Professor für Molekulare Neurobiologie an der TUM, hat nun herausgefunden, dass nach der Zerstörung der Myelinscheide kristallines Cholesterin - ähnlich wie bei der Arteriosklerose – eine anhaltende Entzündung auslöst, die eine Regeneration verhindert.
<G-vec00179-001-s160><trigger.auslösen><en> A team led by TUM Molecular Neurobiology professor Mikael Simons has now discovered that after the destruction of myelin crystalline cholesterol can trigger persistent inflammation which prevents regeneration, similar as in arteriosclerosis.
<G-vec00179-001-s161><trigger.auslösen><de> Ein Gerät mit Sensoren, ein Netzwerk, das Daten überträgt, sowie ein System, das diese verarbeitet und Aktionen auslöst.
<G-vec00179-001-s161><trigger.auslösen><en> A device with sensors, a network for transmitting data, and a system that can process this to trigger actions.
<G-vec00179-001-s162><trigger.auslösen><de> Du könntest auch eine Lebensmittelallergie oder -Überempfindlichkeit haben, welche Kopfschmerzen auslöst.
<G-vec00179-001-s162><trigger.auslösen><en> You might also have a food allergy or sensitivity, which can trigger headaches.
<G-vec00179-001-s163><trigger.auslösen><de> Netzwerk-Proxies und andere Enterprise-Netzwerk-Sicherheitsfunktionen können verhindern, dass die Malware ihre Killswitch-Domäne kontaktiert und damit versehentlich die Verschlüsselung auslöst.
<G-vec00179-001-s163><trigger.auslösen><en> Network proxies and other enterprise network security features may prevent the malware from contacting its killswitch domain and inadvertently trigger encryption.
<G-vec00179-001-s164><trigger.auslösen><de> Eine schnelle Lieferung gehört auf dieser Seite zum guten Ton, so wie der Kauf auf Rechnung oder die ungebundene Ratenzahlung dir ein Zahlungsziel einräumt, wo du erst die Sendung von uns in deinen Händen hältst, bevor du eine Zahlung auslöst.
<G-vec00179-001-s164><trigger.auslösen><en> A fast delivery belongs to the good tone on this side, just as the purchase on account or the unbound installment payment grants you a payment target, where you hold the shipment in your hands before you trigger a payment.
<G-vec00179-001-s165><trigger.auslösen><de> Das bedeutet, jeder Teil des Körpers, von den Schultern, um Ihre Wadenknochen, wird sicherlich haben schlanke, verringert Muskel, der die Dankbarkeit der alle, die Fitness zu schätzen auslöst.
<G-vec00179-001-s165><trigger.auslösen><en> This suggests every part of your physical body, from your shoulders to your calf bones, will have lean, reduced muscle that will certainly trigger the gratitude of people who appreciates physical conditioning.
<G-vec00179-001-s166><trigger.auslösen><de> Wenn Sie kleine Energiemengen messen und das Gerät nicht auslöst, setzen Sie den Schwellenwert auf LOW (gering).
<G-vec00179-001-s166><trigger.auslösen><en> If you are measuring small energies and the unit does not trigger, set the threshold for LOW.
<G-vec00179-001-s167><trigger.auslösen><de> Dieses wird dann ausgelöst, wenn 3, 4 oder 5 Symbole das Crystal Helm Bonusspiel mit 5 Stufen auslöst.
<G-vec00179-001-s167><trigger.auslösen><en> The game is triggered when 3, 4 or 5 symbols trigger the Crystal Helm bonus game which has 5 levels.
<G-vec00179-001-s187><trigger.auslösen><de> Sie ist allerdings eine schwierig zu messende Größe, da jeweils zu definieren wäre, in welcher Hautschicht der Wirkstoff ankommen muss, um die gewünschten Effekte auszulösen.
<G-vec00179-001-s187><trigger.auslösen><en> Nevertheless, this particular factor is difficult to measure as also the individual skin layer would have to be determined in which the active agent is supposed to arrive in order to trigger the desired effects.
<G-vec00179-001-s188><trigger.auslösen><de> Dies ist die energetische Komponente in Garcinia cambogia, und wurde in einer Reihe von Untersuchungen effektiven Gewichtsverlust gezeigt auszulösen.
<G-vec00179-001-s188><trigger.auslösen><en> This is the energetic component in Garcinia Cambogia, and has been shown to trigger effective weight loss in a number of researches. Garcinia Cambogia extract is currently the globe’s most prominent weight-loss supplement.
<G-vec00179-001-s189><trigger.auslösen><de> Alle verfolgten Kometen haben keine genügende Masse, um eine starke Abstoßungskraft bei den Planeten, die sie passieren, oder bei der Sonne auszulösen, und somit nehmen die menschlichen Ephimeriden als die einzigen zu betrachtenden Elemente den Pfad und die Geschwindigkeit an.
<G-vec00179-001-s189><trigger.auslösen><en> All comets tracked do not have a mass sufficient to trigger a strong repulsion force in the planets they pass or the Sun, and thus the humans ephemeris assume the only elements to consider are the path and the speed.
<G-vec00179-001-s190><trigger.auslösen><de> Die Zerstörung Libyens durch die NATO war nicht der erste erfolgreiche Versuch von BHL, einen Krieg auszulösen.
<G-vec00179-001-s190><trigger.auslösen><en> The destruction of Libya by NATO was not BHL's first successful attempt to trigger a war.
<G-vec00179-001-s191><trigger.auslösen><de> Einmal in der Luft aufgewirbelt besteht bei ihnen beim Einatmen die Gefahr, bis in die Alveolen der Lungen vorzudringen, und dort die Wirkungen auszulösen, wie man sie von nicht abbaubaren Feststoffen wie Asbest, Glasfaser, Kohlenstaub, Dieselruß kennt.
<G-vec00179-001-s191><trigger.auslösen><en> Once blown up in the air they can be a safety hazard due to the fact that they may infiltrate into the alveoles of the lungs when breathing and then trigger the well-known effects of non degradable solid matters like asbestos, glass fiber, carbon dust and diesel exhaust particles.
<G-vec00179-001-s192><trigger.auslösen><de> Ein dreijähriges Forschungsprojekt des MuscleMeds Forschungs- und Produktentwicklungsteams hat die 19 kritischen Aminosäuren aufgedeckt, die benötigt werden, um hochintensive Workouts zu unterstützen und maximale anabole und antikatabole Effekte auszulösen.
<G-vec00179-001-s192><trigger.auslösen><en> A three-year research project by the MuscleMeds Research and Product Development Team has uncovered the 19 critical aminos needed to support high intensity workouts and trigger maximum anabolic and anti-catabolic effects.
<G-vec00179-001-s193><trigger.auslösen><de> Um die zweite auszulösen müsst ihr kurz den Gang betreten, dann aber schnell wieder in Sicherheit.
<G-vec00179-001-s193><trigger.auslösen><en> To trigger a second one, you need to step into the passage briefly but then quickly get out again.
<G-vec00179-001-s194><trigger.auslösen><de> E-Mail-Auslöser: Das ermöglicht es den Benutzern, Kampagnen basierend auf bestimmte Zeiten und Termine, Formulareinreichungen, API-Aufrufe, Attributwertänderungen und Aktionen für zuvor gesendete E-Mails auszulösen.
<G-vec00179-001-s194><trigger.auslösen><en> Email Triggers: It allows users to trigger campaigns based on specified times and dates, form submissions, API calls, attribute value changes, and actions on previously sent emails.
<G-vec00179-001-s195><trigger.auslösen><de> Hinweis: Sie können WLAuthorizationManager.obtainAccessToken aufrufen, um eine verfügbare direkte Aktualisierung auszulösen.
<G-vec00179-001-s195><trigger.auslösen><en> Note: You can call WLAuthorizationManager.obtainAccessToken to trigger a direct update if one is available.
<G-vec00179-001-s196><trigger.auslösen><de> Dies dient dem Nachweis der möglichen Gefährlichkeit der Keime und ihrer Fähigkeit, beim Menschen über die Aufnahme von Lebensmitteln Erkrankungen auszulösen.
<G-vec00179-001-s196><trigger.auslösen><en> The objective is to determine the possible harmfulness of the germs and their ability to trigger disease in humans via dietary uptake.
<G-vec00179-001-s197><trigger.auslösen><de> Das S-Symbol ist das Scatter-Symbol und hat die Fähigkeit die Bonusrunde auszulösen.
<G-vec00179-001-s197><trigger.auslösen><en> S is the scatter symbol and has ability to trigger bonus round.
<G-vec00179-001-s198><trigger.auslösen><de> Auf dieser Basis ist es möglich, Events in Ihren Backend-Systemen auszulösen – sei es bei der Anfragenbearbeitung oder bei der Weiterverarbeitung von Kundenanfragen.
<G-vec00179-001-s198><trigger.auslösen><en> On this basis, it is possible to trigger events in your backend systems, whether it is for request processing or further processing customer requests.
<G-vec00179-001-s199><trigger.auslösen><de> "Nur nahe am absoluten Temperaturnullpunkt bei -273,15 Grad Celsius herrschen die richtigen Bedingungen, um einen quantenphysikalischen Tsunami auszulösen - ein sogenanntes Bose-Einstein-Kondensat (BEC)"", erklärt CAL-Projektleiter im Raumfahrtmanagement Dr. Rainer Forke."
<G-vec00179-001-s199><trigger.auslösen><en> "Only at close to absolute zero, at –273.15 degrees Celsius, do we have the right conditions to trigger a quantum tsunami, known as a Bose–Einstein condensate (BEC),"" explains Rainer Forke, CAL Project Leader at the Space Administration."
<G-vec00179-001-s200><trigger.auslösen><de> Die technischen Daten auf der Rettungskarte geben Auskunft darüber, wo beispielsweise an der Karosserie Stahlscheren anzusetzen sind oder welche Vorsichtsmaßnahmen nötig sind, um Airbags nicht auszulösen.
<G-vec00179-001-s200><trigger.auslösen><en> The technical data on the rescue card provide information on where, for example, steel scissors are to be attached to the bodywork or what precautions are necessary in order not to trigger airbags.
<G-vec00179-001-s201><trigger.auslösen><de> Die Überwachung von Kommunikation und Daten bietet die Möglichkeit, Gefahren frühestmöglich zu erkennen und entsprechende Alarmierungen auszulösen.
<G-vec00179-001-s201><trigger.auslösen><en> The monitoring of communication and data provides the opportunity to detect dangers at the earliest possible stage and to trigger respective alerts.
<G-vec00179-001-s202><trigger.auslösen><de> Auch das feine Abstimmen der Öffnungen der Drachen darf die Vorrichtung genau regulieren, damit nur Erdbeben über einer spezifischen Schwellenenergie in der LageSIND, die angeforderte Warnung auszulösen.
<G-vec00179-001-s202><trigger.auslösen><en> Also the tuning leavers of the dragons' mouths allows to regulate the device exactly, so that only earthquakes above a specific threshold power are able to trigger the required alarm.
<G-vec00179-001-s203><trigger.auslösen><de> Gelegentlich sammelt sich auf der Oberfläche des Weißen Zwerges genügend Material an, um eine thermonukleare Nova -Explosion auszulösen, ein gewaltiges Ereignis, das eine große Menge an Material in den Weltraum wirft.
<G-vec00179-001-s203><trigger.auslösen><en> Occasionally, enough material collects on the surface of the white dwarf to trigger a thermonuclear nova explosion, a titanic event which throws a vast amount of material into space.
<G-vec00179-001-s204><trigger.auslösen><de> "Wenn du zu den ""glücklichen"" mit einer solchen Freundin gehörst, solltest du einfach versuchen, bei ihr so viele Orgasmen wie möglich auszulösen."
<G-vec00179-001-s204><trigger.auslösen><en> "If you are the ""lucky"" with a friend, it's logical that you should just try to trigger as many orgasms as possible."
<G-vec00179-001-s205><trigger.auslösen><de> Zahlreiche Tests kann getan werden, um sicherzustellen, dass Virility Pillen für Männer würden nie irgendwelche Probleme auszulösen.
<G-vec00179-001-s205><trigger.auslösen><en> Numerous tests may be done to guarantee that Virility pills for males would never trigger any problems.
<G-vec00179-001-s309><trigger.auslösen><de> Diese lösen durch den Einsatz eines elektronischen Ticketsystems bestimmte Ereignisse aus oder schränken den Zutritt auf ein festgelegtes Zeitfenster ein.
<G-vec00179-001-s309><trigger.auslösen><en> They trigger specific events or restrict entry to a defined time slot by using an electronic ticket system.
<G-vec00179-001-s310><trigger.auslösen><de> Schon seit meiner Kindheit lösen Situationen, Sätze oder Begebenheiten Assoziationen in meinem Kopf aus, über die ich lachen oder schmunzeln muss.
<G-vec00179-001-s310><trigger.auslösen><en> Ever since my childhood, some situations, sentences, or events trigger associations in my head which make me laugh or smile to myself.
<G-vec00179-001-s311><trigger.auslösen><de> Terroranschläge, Naturkatastrophen oder Unfälle lösen bei vielen Menschen noch Jahre später Angstzustände und Panikattacken aus.
<G-vec00179-001-s311><trigger.auslösen><en> Years after their occurrence, terrorist attacks, natural disasters and accidents continue to trigger anxiety and panic attacks in many people.
<G-vec00179-001-s312><trigger.auslösen><de> Die Scatter-Symbole lösen den Bonus aus.
<G-vec00179-001-s312><trigger.auslösen><en> The scatters will trigger the bonus.
<G-vec00179-001-s313><trigger.auslösen><de> Derzeit lösen nur Kreditkarten und PayPal diese Einschränkung aus.
<G-vec00179-001-s313><trigger.auslösen><en> Only credit cards and PayPal currently trigger this restriction.
<G-vec00179-001-s314><trigger.auslösen><de> Bestimmte T-Lymphozyten merken sich eine solche spezifische Abwehrreaktion und lösen, wenn sie zu einem späteren Zeitpunkt wieder auf denselben Fremdstoff treffen, eine schnelle und sehr wirkungsvolle Immunreaktion aus.
<G-vec00179-001-s314><trigger.auslösen><en> Certain T lymphocytes remember such a specific immune response and when they encounter the same foreign substance at a later time, they trigger a rapid and effective immune response.
<G-vec00179-001-s315><trigger.auslösen><de> Malte Spohr schreibt: Die unterschiedlichen Erscheinungsformen des Lichts, seine Energie, faszinieren mich, lösen in mir etwas aus, das schwer fassbar und zu beschreiben ist.
<G-vec00179-001-s315><trigger.auslösen><en> Malte Spohr: The various manifestations of light and its energy fascinate me, trigger something that is difficult to grasp or describe.
<G-vec00179-001-s316><trigger.auslösen><de> Bei einem Unfall mit Airbag lösen Crash-Sensoren im Fahrzeug automatisch einen Notruf aus.
<G-vec00179-001-s316><trigger.auslösen><en> When an airbag is deployed in an accident, crash sensors in the vehicle trigger an emergency call automatically.
<G-vec00179-001-s317><trigger.auslösen><de> Diese Mechanismen lösen bei Belastung der Muskulatur eine deutliche Symptomatik aus, welche sich je nach Schweregrad des Anfalls unterscheidet.
<G-vec00179-001-s317><trigger.auslösen><en> These mechanisms trigger a marked symptom when the muscles are stressed, which differs depending on the severity of the condition.
<G-vec00179-001-s318><trigger.auslösen><de> Lösen Sie ununterbrochen das Selbstmobile für über 30mal aus, als die Energie voll ist.
<G-vec00179-001-s318><trigger.auslösen><en> Continuously trigger the auto mobile for over 30 times when the power is full.
<G-vec00179-001-s319><trigger.auslösen><de> Im Falle einer Störung lösen die überwachten Komponenten Alarm und damit automatisch ein Trouble Ticket aus.
<G-vec00179-001-s319><trigger.auslösen><en> In the event of a malfunction, the monitored components raise the alarm and trigger a Trouble Ticket automatically.
<G-vec00179-001-s511><trigger.auslösen><de> – Erscheinen irgendwo 3 oder mehr Gratis-Spin Symbole, werden 3 Personal-Charaktere ausgelöst: der Koch, der Butler und das Dienstmädchen.
<G-vec00179-001-s511><trigger.auslösen><en> 3 or more Free Spin symbols landing anywhere trigger 3 servant characters: The Chef, the Butler and the Maid.
<G-vec00179-001-s512><trigger.auslösen><de> Wäre diese Information nicht bekannt, wüssten Sie bei der Ablaufverfolgung von Anzeigenanforderungen nicht, dass ein Video zwei Minuten lang angesehen werden muss, damit die Anzeigenanforderung ausgelöst wird, und Sie verlieren unter Umständen wertvolle Zeit.
<G-vec00179-001-s512><trigger.auslösen><en> If you did not know this information when tracing ad requests for troubleshooting, you wouldn't know to keep watching for a video for two minutes to trigger the ad request and you might lose valuable time.
<G-vec00179-001-s513><trigger.auslösen><de> – Erscheinen 3, 4 oder 5 Eisenfaust-Scatter, werden 10, 15 oder 20 Gratis-Spins ausgelöst.
<G-vec00179-001-s513><trigger.auslösen><en> – Land 3, 4 or 5 Iron Fist scatters to trigger 10, 15 or 20 free spins.
<G-vec00179-001-s514><trigger.auslösen><de> Durch Geschäftsvorgänge im Einkauf werden in der Materialwirtschaft unterschiedliche Lagerbuchungen ausgelöst, die anhand von Buchungsschlüsseln identifiziert werden.
<G-vec00179-001-s514><trigger.auslösen><en> Business activities in purchasing trigger various inventory postings in materials management, which can be identified by posting codes.
<G-vec00179-001-s515><trigger.auslösen><de> – Erscheinen 3 Scatter auf den Walzen 1, 3 und 5, werden 10 Gratis-Spins ausgelöst.
<G-vec00179-001-s515><trigger.auslösen><en> – Land 3 scatters on reels 1, 3 and 5 to trigger 10 free spins.
<G-vec00179-001-s516><trigger.auslösen><de> Durch Umbuchungen werden in der Materialwirtschaft Lagerzugangsbuchungen für die Teile ausgelöst, die in den Teilepositionen der Wareneingangsbelege erfasst sind.
<G-vec00179-001-s516><trigger.auslösen><en> Transfer postings trigger warehouse in postings in materials management for those parts that have been entered in the part lines of the stock receipt documents.
<G-vec00179-001-s517><trigger.auslösen><de> – Erscheinen 3 oder 4 Sidewinder-Scatters auf den Walzen 2, 4 und auf den horitontalen Walzen, werden 6 oder 10 Gratis-Spins ausgelöst.
<G-vec00179-001-s517><trigger.auslösen><en> – Land 3 or 4 Sidewinder scatters on reels 2,4 and the horizontal reels to trigger 6 or 10 free spins.
<G-vec00179-001-s518><trigger.auslösen><de> – Erscheinen 3, 4 oder 5 Scatter, werden 9, 12 oder 18 Gratis-Spins ausgelöst.
<G-vec00179-001-s518><trigger.auslösen><en> – Land 3, 4 or 5 scatters to trigger 9, 12 or 18 free spins.
<G-vec00179-001-s519><trigger.auslösen><de> – Durch 3, 4 oder 5 Edelsteine werden 10, 20 oder 30 Gratis-Spins ausgelöst.
<G-vec00179-001-s519><trigger.auslösen><en> – Land 3, 4 or 5 gems to trigger 10, 20 or 30 free spins.
<G-vec00179-001-s520><trigger.auslösen><de> – Erscheinen 3 oder mehr Goldene Falken-Wilds, werden 10 Gratis-Spins ausgelöst.
<G-vec00179-001-s520><trigger.auslösen><en> – Land 3 or more golden falcon wilds to trigger 10 free spins.
<G-vec00179-001-s535><trigger.auslösen><de> – Erscheinen 3 oder mehr Blatthornkäfer irgendwo auf den Walzen, wird das Feature ausgelöst.
<G-vec00179-001-s535><trigger.auslösen><en> – Land 3 or more Scarabs anywhere on the reels to trigger the feature.
<G-vec00179-001-s536><trigger.auslösen><de> – Erscheinen 2 oder mehr Drachen-Scatter, wird das Feature ausgelöst.
<G-vec00179-001-s536><trigger.auslösen><en> – Land 2 or more Dragon scatters to trigger the feature.
<G-vec00179-001-s537><trigger.auslösen><de> – Erscheinen 3 oder mehr Scatter irgendwo auf den Walzen, wird das Feature ausgelöst.
<G-vec00179-001-s537><trigger.auslösen><en> – Land 3 or more scatters anywhere on the reels to trigger the feature.
<G-vec00179-001-s538><trigger.auslösen><de> – Erscheinen 3 Blitze auf den 3 mittleren Walzen, wird das Feature ausgelöst.
<G-vec00179-001-s538><trigger.auslösen><en> – Land 3 lightning bolts on the 3 middle reels to trigger the feature.
<G-vec00179-001-s539><trigger.auslösen><de> – Erscheint das Kreigsflaggen Scatter auf den Walzen 1, 3 und 5, wird das Feature ausgelöst.
<G-vec00179-001-s539><trigger.auslösen><en> – Land the War Flag scatter on reels 1, 3 and 5 to trigger the feature.
<G-vec00179-001-s540><trigger.auslösen><de> Beim Durchbruch eines Widerstands wird ein Kaufsignal ausgelöst.
<G-vec00179-001-s540><trigger.auslösen><en> Breaks through resistance trigger buy signals.
<G-vec00179-001-s541><trigger.auslösen><de> – Erscheinen 1 oder 2 Wilds auf einer Walze, wird das Feature ausgelöst.
<G-vec00179-001-s541><trigger.auslösen><en> – Land 1 or 2 Wilds on a reel to trigger the feature.
<G-vec00179-001-s542><trigger.auslösen><de> – Erscheinen 3 Manager-Symbole, wird das Feature ausgelöst.
<G-vec00179-001-s542><trigger.auslösen><en> – Land 3 Manager symbols to trigger the feature.
<G-vec00179-001-s543><trigger.auslösen><de> Erscheinen drei oder mehr Scattersymbole, irgendwo auf den Walzen, wird der Gratis-Spins Bonus ausgelöst.
<G-vec00179-001-s543><trigger.auslösen><en> Three or more scatter symbols appearing anywhere on the reels trigger the free spins bonus round.
<G-vec00337-002-s051><precipitate.auslösen><de> Zu den schädlichen Wirkungen von Marihuana gehört die Tatsache, dass es bei anfälligen Menschen Psychosen (Paranoia) auslösen kann.
<G-vec00337-002-s051><precipitate.auslösen><en> Among harmful effects of marijuana is that cannabis use can precipitate psychosis (paranoia) in vulnerable people.
<G-vec00376-002-s019><shutter.auslösen><de> Die Kamera ist innerhalb von 1,5 Sekunden startklar und danach muss nur noch ausgelöst werden.
<G-vec00376-002-s019><shutter.auslösen><en> The camera is ready to shoot in 1.5 second, and after that it's only a matter of pressing the shutter release.
<G-vec00376-002-s020><shutter.auslösen><de> Auf dem Smartphone/Tablet wird das Live-View-Bild der Kamera angezeigt, und es können per Wi-Fi verschiedene Einstellungen wie Schärfe, Belichtungskorrektur, ISO, WB oder Fotostil vorgenommen und auch ausgelöst werden.
<G-vec00376-002-s020><shutter.auslösen><en> What the camera is seeing is displayed live smoothly on the smartphone / tablet and it is possible to set various controls including focus setting, exposure compensation, ISO, WB and Photo Style in addition to shutter release via live view using Wi-Fi®.
<G-vec00547-002-s009><unsettle.auslösen><de> Motivationsmeme lösen positive Entwicklungen bei Einzelpersonen und Gruppen aus.
<G-vec00547-002-s009><unsettle.auslösen><en> Motivation memes unsettle positive developments amongst individuals and groups.
