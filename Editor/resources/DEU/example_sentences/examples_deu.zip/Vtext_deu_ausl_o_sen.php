<G-vec00547-001-s057><alarm.auslösen><de> Die Funktion sollte ein Bedarfsdetektor sein, um rechtzeitig einen Alarm auszulösen, wenn der Behälter leer ist und mehr Material eingefüllt werden sollte.
<G-vec00547-001-s057><alarm.auslösen><en> The function should be a demand detector to set an alarm in time if the hopper gets empty and more material should be filled in.
<G-vec00547-001-s058><alarm.auslösen><de> Aber selbst wenn es sich in der Nähe des Uterusbodens befindet, haben Ärzte keine Eile, den Alarm auszulösen, da sie mit dem Verlauf der Schwangerschaft ansteigen können.
<G-vec00547-001-s058><alarm.auslösen><en> But even if it is located close to the bottom of the uterus, doctors are not in a hurry to sound the alarm, as with the course of pregnancy it can rise.
<G-vec00547-001-s059><alarm.auslösen><de> Zögern Sie nicht, einen Alarm auszulösen, auch wenn die Lage noch nicht so kritisch erscheint.
<G-vec00547-001-s059><alarm.auslösen><en> Don't hesitate to release an alarm, even if the situation seems not that critical.
<G-vec00547-001-s060><alarm.auslösen><de> Wenn es jedoch keine Versiegelungen in der Brustdrüse und keinen Ausfluss aus den Brustwarzen gibt, sollten Sie sich darüber keine Sorgen machen: Tatsache ist, dass der Schmerz für die letzten Stadien der Tumorentwicklung charakteristisch ist, aber wenn vorher keine Beschwerden aufgetreten sind Es ist nicht nötig, den Alarm auszulösen.
<G-vec00547-001-s060><alarm.auslösen><en> However, if there are no seals in the mammary gland and no discharge from the nipples, you should not worry about it: the fact is that pain is characteristic of the last stages of tumor development, but if there were no complaints before, then there is no need to sound the alarm .
<G-vec00547-001-s061><alarm.auslösen><de> In fünf Stationen gibt es Abfallsammelboxen für Kartenausstanzungen, bei denen Sensoren erkannt werden, um Alarm auszulösen, wenn er voll ist.
<G-vec00547-001-s061><alarm.auslösen><en> There are waste material collecting boxes in five stations sim card punching equipment, with detecting sensors to make alarm if it will be full.
<G-vec00547-001-s062><alarm.auslösen><de> All diese Angriffe durch die innere und äußere Reaktion hätten genügt, um Alarm auszulösen und hätten Allende wachrütteln müssen.
<G-vec00547-001-s062><alarm.auslösen><en> These attacks by internal and external reaction would have been sufficient to sound the alarm and make Allende reflect.
<G-vec00547-001-s063><alarm.auslösen><de> Wenn jedoch die Markierung auf der Waage aus irgendeinem unbekannten Grund hartnäckig nach oben kriecht, lohnt es sich, den Alarm auszulösen.
<G-vec00547-001-s063><alarm.auslösen><en> But if the mark on the scales for some unknown reason, stubbornly creeps up, then it is worth sounding the alarm.
<G-vec00547-001-s064><alarm.auslösen><de> Scheuen Sie sich nicht, einen Alarm auszulösen - selbst wenn aus Ihrer Sicht die Situation noch nicht sehr kritisch erscheint.
<G-vec00547-001-s064><alarm.auslösen><en> Don't hesitate to release an alarm - even if the situation seems not that critical to you.
<G-vec00547-001-s065><alarm.auslösen><de> Wenn jedoch die Markierung auf der Waage aus einem unbekannten Grund hartnäckig auftaucht, lohnt es sich, den Alarm auszulösen.
<G-vec00547-001-s065><alarm.auslösen><en> But if the mark on the scales, for some unknown reason, stubbornly creeps upwards, then it is worth sounding the alarm.
<G-vec00547-001-s066><alarm.auslösen><de> Der ST340 Sauerstoffmangeldetektor wurde speziell dafür konzipiert, einen Alarm auszulösen, wenn die Sauerstoffwerte vom Umgebungswert von 20,9 % abweichen.
<G-vec00547-001-s066><alarm.auslösen><en> TheST341 (O2) Deficiency Detector is designed specifically to alarm when oxygen levels deviate from the ambient value of 20.9%.
<G-vec00547-001-s067><alarm.auslösen><de> Bei einem einmaligen Blutdruckabfall auf 90 bis 80 ist es nicht erforderlich, einen Alarm auszulösen und eine Diagnose zu stellen.
<G-vec00547-001-s067><alarm.auslösen><en> With a one-time decrease in blood pressure to the level of 90 to 80, it is not necessary to sound the alarm and set yourself a diagnosis.
<G-vec00547-001-s068><alarm.auslösen><de> Die Lösungen von Siemens sind darauf ausgelegt, Brände so früh wie möglich zu erkennen, Alarm auszulösen und die vorprogrammierten Steuerfunktionen zu aktivieren.
<G-vec00547-001-s068><alarm.auslösen><en> Solutions from Siemens are built to detect fires as early as possible, to alarm and activate the preprogrammed control functions.
<G-vec00179-001-s079><trigger.auslösen><de> In Vertriebsbelegen, durch die keine Lagerbuchungen in der Materialwirtschaft ausgelöst werden, wird in der Positionsinformation zu einer Teileposition der Einstandspreis angezeigt.
<G-vec00179-001-s079><trigger.auslösen><en> In sales documents which do not trigger inventory postings in materials management, the cost price is displayed in the line information for a part line.
<G-vec00179-001-s080><trigger.auslösen><de> Mit ihnen werden die HGÜ-Umrichtermodule innerhalb von Millisekunden ausgelöst....
<G-vec00179-001-s080><trigger.auslösen><en> They trigger the HVDC conversion modules within milliseconds....
<G-vec00179-001-s081><trigger.auslösen><de> Sobald die Einführungsphase abgeschlossen ist, wird F&F mit Hilfe der RFID-Technologie kontinuierlich überprüfen können, ob der Systembestand exakt den tatsächlichen Bestand wiedergibt, so dass Nachbestellungen an der richtigen Stelle ausgelöst und Regallücken vermieden werden können.
<G-vec00179-001-s081><trigger.auslösen><en> Once the roll-out is complete, F&F will use RFID technology to continually keep the system stock accurately reflecting the physical stock, in order to trigger repeat orders at the right point and avoid out of stocks.
<G-vec00179-001-s082><trigger.auslösen><de> Dadurch wird ein Alarm ausgelöst und ein Wachmann kommt in die Zelle gestürmt.
<G-vec00179-001-s082><trigger.auslösen><en> This will trigger an alert and a guard will come rushing into the room.
<G-vec00179-001-s083><trigger.auslösen><de> Joker-Neu-Drehs ausgelöst, wenn der joker Hut-Symbol erscheint auf dem 2Nd, 3Rd Und 4Th Rollen.
<G-vec00179-001-s083><trigger.auslösen><en> Joker Re-spins will trigger when the joker hat icon appears on the 2nd, 3rd and 4th reels.
<G-vec00179-001-s084><trigger.auslösen><de> "Die Phasen ""Hold"" und ""Decay"" des AHDSR-Envelopes von Alchemy werden nun einheitlich mit kurzen Werten ausgelöst."
<G-vec00179-001-s084><trigger.auslösen><en> Alchemy AHDSR envelope Hold and Decay stages now trigger consistently with short values.
<G-vec00179-001-s085><trigger.auslösen><de> Wenn du in einem oder beiden deiner Handgelenke Schmerzen bemerkt, solltest du eine Pause einlegen und das Handgelenk, je nachdem was sie ausgelöst hat, für ein paar Minuten, Stunden oder sogar Tage ausruhen, indem du auf verschlimmernde Aktivitäten verzichtest.
<G-vec00179-001-s085><trigger.auslösen><en> If you notice pain in one or both of your wrists, take a break from the aggravating activity and rest for a few minutes, hours or even days depending on the trigger of the pain.
<G-vec00179-001-s086><trigger.auslösen><de> Wird nicht in PvP-Bereichen ausgelöst.
<G-vec00179-001-s086><trigger.auslösen><en> It will not trigger inside of PvP areas.
<G-vec00179-001-s087><trigger.auslösen><de> Sebastian Thomas Philipp erfahren, dass durch Meditation Lernprozesse ausgelöst werden können.
<G-vec00179-001-s087><trigger.auslösen><en> Sebastian Thomas Philipp and learn how meditating can trigger learning processes in the brain.
<G-vec00179-001-s088><trigger.auslösen><de> """Wir haben das System so eingerichtet, dass bei kritischen Vorfällen auf den Mobiltelefonen des Sicherheitsteams automatisch Alarm ausgelöst wird."
<G-vec00179-001-s088><trigger.auslösen><en> """We have set the system to automatically trigger alerts to the security team's mobile phones should there be an incident that requires our attention."
<G-vec00179-001-s089><trigger.auslösen><de> Legen Sie Logtyp, logischen Operator und Filterkriterien fest, für die der Task ausgelöst werden soll.
<G-vec00179-001-s089><trigger.auslösen><en> Define the log type, logical operator and filtering criteria that will trigger the task.
<G-vec00179-001-s090><trigger.auslösen><de> Beim Ändern von Mehrwegpackmitteln und Mehrwegpackmittelzubehör in Transportbelegen können in der Packmittelverwaltung Packmittelbuchungen ausgelöst werden.
<G-vec00179-001-s090><trigger.auslösen><en> When returnable packaging and returnable packaging accessories are changed in transport documents, this can trigger packaging postings in packaging management.
<G-vec00179-001-s091><trigger.auslösen><de> Achten Sie auf die bonusrunden im Spiel Reel King, die zufällig im Laufe des Spiels ausgelöst wird.
<G-vec00179-001-s091><trigger.auslösen><en> Look out for the Reel King bonus feature to trigger at random intervals throughout play.
<G-vec00179-001-s092><trigger.auslösen><de> Beachten Sie, daß wenn Sie eine Datei aus dem Laufwerk heraus verschieben dieselbe Aktion ausgelöst wird, denn ein solches Verschieben ist identisch mit Kopieren gefolgt von Löschen.
<G-vec00179-001-s092><trigger.auslösen><en> Note that if you manually move a file off the volume to some other drive letter this will trigger the same action, because that kind of moving is identical to copying followed by deletion.
<G-vec00179-001-s093><trigger.auslösen><de> Es wird angenommen, eine Art der Immunantwort zu entwickeln, scheitert, die Haare und dass diese Reaktion kann verschiedene Faktoren ausgelöst werden – so.
<G-vec00179-001-s093><trigger.auslösen><en> It is believed to develop a type of immune response fails, the hairs and that this reaction can trigger different factors – so.
<G-vec00179-001-s094><trigger.auslösen><de> Die Chance, dass 'Gabe der Schlange' ausgelöst wird, wurde für diverse Nebelwirkerzauber signifikant erhöht und der Effekt verwendet einen höheren Prozentzsatz des Maximalwertes.
<G-vec00179-001-s094><trigger.auslösen><en> Gift of the Serpent chance to trigger has increased significantly for various Mistweaver spells, conferring a larger percentage of the maximum value.
<G-vec00179-001-s095><trigger.auslösen><de> Die Cue wird durch ein 'go' ausgelöst.
<G-vec00179-001-s095><trigger.auslösen><en> This will make the cue trigger by a 'go'.
<G-vec00179-001-s096><trigger.auslösen><de> Über 3 frei konfigurierbare Schwellen können Alarme ausgelöst oder Funktionen gesteuert werden.
<G-vec00179-001-s096><trigger.auslösen><en> 3 adjustable thresholds can trigger alarms or other processes.
<G-vec00179-001-s097><trigger.auslösen><de> Diese Stufe sollte erst ausgelöst werden, wenn dem ersten Satz von zwei Starthilfsraketen der Treibstoff ausgeht.
<G-vec00179-001-s097><trigger.auslösen><en> Trigger this stage only after the first set of two boosters are out of fuel
<G-vec00179-001-s098><trigger.auslösen><de> Dieser neue Bereinigungsvorgang kann auch manuell durch Erstellen der Datei ACLFIX.SEM im Verzeichnis \App\ ausgelöst werden.
<G-vec00179-001-s098><trigger.auslösen><en> Also you can create ACLFIX.SEM in the \App\ folder to trigger just this cleanup routine.
<G-vec00179-001-s099><trigger.auslösen><de> So können interne Wertkorrekturen für die Bestandteile ausgelöst werden.
<G-vec00179-001-s099><trigger.auslösen><en> This can trigger internal value corrections for the components.
<G-vec00179-001-s100><trigger.auslösen><de> Diese Sonderereignisse benötigen die Spezialität oder den Skill von zwei Spielern um ausgelöst zu werden.
<G-vec00179-001-s100><trigger.auslösen><en> These Special Events need the speciality or skill of two players to trigger
<G-vec00179-001-s101><trigger.auslösen><de> Einige Kosmologen behaupten, dass durch einen kurzen Sturm von Elementarteilchen Irregularitäten der Materie ausgelöst werden können.
<G-vec00179-001-s101><trigger.auslösen><en> Some cosmologists claim that a brief storm of fundamental particles can trigger irregularities in matter.
<G-vec00179-001-s102><trigger.auslösen><de> Dadurch können deutlichere Stoffwechselverbesserungen ausgelöst werden, als es mit zuvor bekannten medikamentösen Ansätzen möglich schien.Dreifachhormon senkt Körpergewicht und verbessert Insulinsensitivität Aktuell präsentierte das interdisziplinäre Wissenschaftlerteam, unter Führung von Tschöp und DiMarchi, ein Dreifachhormon, das im Tiermodell nicht nur Blutzuckerspiegel, Appetit und Körperfett drastisch senkt, sondern auch Leberverfettung, Cholesterinwerte und Kalorienverbrennung verbessert – und zwar noch effektiver als es mit bisher verfügbaren mono-aktiven oder dual wirksamen Molekülen möglich war.
<G-vec00179-001-s102><trigger.auslösen><en> They can consequently trigger more significant metabolic improvements than was previously possible with known medicinal approaches.Triple hormone reduces body weight and improves insulin sensitivity The interdisciplinary team led by Tschöp and DiMarchi is now presenting a triple hormone that dramatically reduces blood glucose, appetite, and body fat in animal models while also improving fat content in the liver, cholesterol levels and calorie burning even more effectively than with previously available single action or dual action molecules.
<G-vec00179-001-s103><trigger.auslösen><de> Dieser Effekt kann nicht mit dem nächsten Einsatz von 'Erneuernder Nebel' oder 'Tritt der aufgehenden Sonne' ausgelöst werden.
<G-vec00179-001-s103><trigger.auslösen><en> This effect cannot trigger on the next Renewing Mist or Rising Sun Kick.
<G-vec00179-001-s104><trigger.auslösen><de> Die 3D-Grafik ist großartig und wird Sie mit einer großen Auswahl an Bonus belohnt jedes Mal, wenn Sie eine Funktion oder großen Gewinn ausgelöst werden.
<G-vec00179-001-s104><trigger.auslösen><en> The 3D graphics are great and will provide you with a massive selection of bonus rewards each time you trigger a feature or big win.
<G-vec00179-001-s105><trigger.auslösen><de> Unter diese außergewöhnlichen Materialien Gewebe Fortschritt ausgelöst werden, während Flüssigkeit zu halten Gewinne in der Zähigkeit produziert und bringt mehr Muskelmasse.
<G-vec00179-001-s105><trigger.auslösen><en> Taking these exceptional substances trigger tissue development while retaining liquid causes gains in strength and leads to a lot more muscular tissue mass.
<G-vec00179-001-s106><trigger.auslösen><de> ...Teilepositionen, durch die keine Lagerbuchungen in der Materialwirtschaft ausgelöst werden.
<G-vec00179-001-s106><trigger.auslösen><en> ...part lines which do not trigger any inventory postings in materials management.
<G-vec00179-001-s107><trigger.auslösen><de> Wenn Range-Trader verkaufen, können Sie Order platzieren, die dann ausgelöst werden, wenn der Kurs den Widerstand übersteigt und der RSI wieder auf einen Wert von unter 70 sinkt.
<G-vec00179-001-s107><trigger.auslösen><en> To sell range traders can trigger orders when price moves off resistance and RSI crosses back below a reading of 70.
<G-vec00179-001-s108><trigger.auslösen><de> Ziel der Zusammenkunft der neun Bankenchefs und der Festlegung auf die Teilnahme am Rettungsplan war es zu verhindern, dass eine Bank, die die staatliche Beteiligung annimmt, stigmatisiert würde und ein Wettlauf gegen sie ausgelöst werden könnte.
<G-vec00179-001-s108><trigger.auslösen><en> The aim of bringing together the nine executives and making them all participate in the plan, is to avoid stigmatizing a bank that accepts state participation, which could trigger a run against it.
<G-vec00179-001-s109><trigger.auslösen><de> Tür-Überprüfungs-Fahrt (TÜF) durch Aufzugswärter Vom Fahrkorb aus kann per Schlüsselschalter die Tür-Überprüfungsfahrt ausgelöst werden.
<G-vec00179-001-s109><trigger.auslösen><en> Door checking drive (TÜF) by lift attendant A key switch in the car can trigger the door checking drive.
<G-vec00179-001-s110><trigger.auslösen><de> In dieser Realität spielt die Bevölkerung eine sehr wichtige Rolle, denn ohne ein wirkliches Bewusstsein für das Umweltproblem, was auf der Insel existiert und deren schwerwiegenden Folgen, die ausgelöst werden können, tragen sie mit ihren Alltagsaktivitäten zur Verschärfung des Problems bei.
<G-vec00179-001-s110><trigger.auslösen><en> The population plays an important role in this reality since the lack of real awareness about the environmental problem existing in the isle and about the serious consequences that it can trigger, contribute in their daily practices by worsening the problem.
<G-vec00169-001-s259><raise.auslösen><de> Jedoch im Internet Suche keine Ergebnisse bezüglich Vertreter mit Sitz in Vietnam oder spezialisierte Unternehmen leicht zugänglich für diese Versorgung auslösen.
<G-vec00169-001-s259><raise.auslösen><en> However on-line searches do not raise any sort of outcomes regarding suppliers based in Vietnam or specialized company available for this supply.
<G-vec00169-001-s260><raise.auslösen><de> Wissenschaftler sagen, dass Himbeer Ketone Ihre Körpertemperatur auslösen können, die wiederum mehr Fette freigesetzt, die bereits gespeichert sind und sie bricht.
<G-vec00169-001-s260><raise.auslösen><en> Scientists mention that raspberry ketones can raise your body temperature level, which in turn launches a lot more fats that are currently held and damages them down.
<G-vec00169-001-s261><raise.auslösen><de> Dennoch keine online-Durchsuchungen Ergebnisse über Lieferanten auslösen in Dhekelia oder spezialisierte Geschäft für dieses Angebot zur Verfügung.
<G-vec00169-001-s261><raise.auslösen><en> Nevertheless on the internet searches do not raise any sort of results regarding distributors based in Dhekelia or specialised company readily available for this supply.
<G-vec00169-001-s262><raise.auslösen><de> Dennoch auslösen Online sucht keine beliebige Ergebnisse über Händler mit Sitz in Botswana oder spezialisierte Firma für diese Versorgung verfügbar.
<G-vec00169-001-s262><raise.auslösen><en> Nonetheless on the internet searches do not raise any kind of results about distributors based in Botswana or specialist company offered for this supply.
<G-vec00169-001-s264><raise.auslösen><de> Jedoch online Recherchen keine Ergebnisse hinsichtlich Lieferanten mit Sitz in Guernsey auslösen oder spezialisiertes Unternehmen für diese Versorgung angeboten.
<G-vec00169-001-s264><raise.auslösen><en> Nevertheless online searches do not raise any sort of results about representatives based in Guernsey or specialised firm readily available for this supply.
<G-vec00169-001-s267><raise.auslösen><de> Aber im Internet keine sucht jede Art von Resultaten über Händler mit Sitz in Mali auslösen oder spezialisierte Firma für diese Versorgung angeboten.
<G-vec00169-001-s267><raise.auslösen><en> Nevertheless on the internet searches do not raise any sort of outcomes about distributors based in Mali or specialised company readily available for this supply.
<G-vec00169-001-s268><raise.auslösen><de> Jedoch online Suche keine Ergebnisse über Lieferanten mit Sitz in St. Helena oder Spezialgeschäft für diese Versorgung verfügbar auslösen.
<G-vec00169-001-s268><raise.auslösen><en> Nevertheless on the internet searches do not raise any type of results concerning suppliers based in Saint Helena or specialized company offered for this supply.
<G-vec00169-001-s269><raise.auslösen><de> Dennoch im Internet sucht jede Art von Ergebnissen bezüglich Vertreter mit Sitz in der Slowakei keine auslösen oder spezialisierten Unternehmen für diese Versorgung angeboten.
<G-vec00169-001-s269><raise.auslösen><en> However on the internet searches do not raise any sort of results about distributors based in Slovakia or specialised company available for this supply.
<G-vec00169-001-s270><raise.auslösen><de> Trotzdem im Internet sucht jede Art von Ergebnissen bezüglich Lieferanten in Polen keine auslösen oder spezialisiertes Unternehmen für diese Versorgung angeboten.
<G-vec00169-001-s270><raise.auslösen><en> Nonetheless online searches do not raise any kind of results concerning distributors based in Poland or specialist firm readily available for this supply.
<G-vec00169-001-s271><raise.auslösen><de> Trotzdem im Internet sucht jede Art von Ergebnissen über die Lieferanten mit Sitz in Moldawien keine auslösen oder Spezialunternehmen für diese Versorgung angeboten.
<G-vec00169-001-s271><raise.auslösen><en> Nevertheless on-line searches do not raise any type of outcomes about suppliers based in Moldova or specialist firm readily available for this supply.
<G-vec00169-001-s272><raise.auslösen><de> Jedoch Online Suche keine Ergebnisse über Distributoren auslösen mit Sitz in Timor Leste oder spezialisierte Geschäft für dieses Angebot zur Verfügung.
<G-vec00169-001-s272><raise.auslösen><en> However online searches do not raise any type of outcomes regarding distributors based in Timor Leste or specialised company readily available for this supply.
<G-vec00169-001-s275><raise.auslösen><de> Die Ergebnisse werden Erstaunen auslösen.
<G-vec00169-001-s275><raise.auslösen><en> The results will raise eyebrows.
<G-vec00169-001-s276><raise.auslösen><de> Dennoch im Internet sucht jede Art von Ergebnissen bezüglich Händler mit Sitz in Kroatien keine auslösen oder Spezialunternehmen für diese Versorgung angeboten.
<G-vec00169-001-s276><raise.auslösen><en> Nevertheless online searches do not raise any outcomes regarding suppliers based in Croatia or specialized company offered for this supply.
<G-vec00169-001-s277><raise.auslösen><de> Dennoch im Internet suchen jede Art von Ergebnissen über Lieferanten mit Sitz in Guernsey keine auslösen oder spezialisierte Unternehmen angeboten für dieses Angebot.
<G-vec00169-001-s277><raise.auslösen><en> Nonetheless on-line searches do not raise any results concerning distributors based in Guernsey or specialised business readily available for this supply.
<G-vec00035-001-s021><redeem.auslösen><de> 13 Will es aber jemand unbedingt wieder auslösen, so soll er den fünften Teil deiner Schätzung dazugeben.
<G-vec00035-001-s021><redeem.auslösen><en> 13 'But if he should ever wish to redeem it, then he shall add one-fifth of it to your valuation.
<G-vec00035-001-s022><redeem.auslösen><de> Aber das Erstgeborene vom Rind oder das Erstgeborene von den Schafen oder das Erstgeborene von den Ziegen sollst du nicht auslösen; sie sind heilig.
<G-vec00035-001-s022><redeem.auslösen><en> But you shall not redeem the firstborn of a cow, or the firstborn of a sheep, or the firstborn of a goat. They are holy.
<G-vec00035-001-s023><redeem.auslösen><de> Alle Erstgeburt deiner Söhne sollst du auslösen.
<G-vec00035-001-s023><redeem.auslösen><en> All the firstborn of thy sons thou shalt redeem.
<G-vec00035-001-s024><redeem.auslösen><de> Wir werden für eine Kautionshinterlegung in Form von Getreide, Geld auszahlen und wenn der Landwirt die Möglichkeit findet, das Getreide selbst zu verkaufen und es auslösen möchte, zahlt er uns das Geld zurück“ sagte Vladimir Putin in Stavropol auf einem Treffen mit Landwirten.
<G-vec00035-001-s024><redeem.auslösen><en> We will pay money for grain deposits and if farmers find a way of selling the grain themselves and want to redeem their deposit, they can simply pay the money back,’ said Vladimir Putin in Stavropol at a meeting with farmers.
<G-vec00035-001-s026><redeem.auslösen><de> Unsere Sehnsucht danach, wie die Dinge wären, wenn wir so würden, wie wir sein könnten, wird uns aus der Vergangenheit auslösen, indem wir unsere Wahl treffen für unseren nächsten Schachzug.
<G-vec00035-001-s026><redeem.auslösen><en> "Our nostalgia for ""the way things would be"" if we became ""how we could be"" will redeem us from our past by opting for our next move on the chess board."
<G-vec00035-001-s027><redeem.auslösen><de> 16 Und die zu Lösenden unter ihnen sollst du im Alter von einem Monat auslösen, nach deiner Einschätzung mit fünf Schekel Silber nach dem Schekel des Heiligtums, der zwanzig Gera beträgt.
<G-vec00035-001-s027><redeem.auslösen><en> "16 ""And as to their redemption price, from a month old you shall redeem them, by your valuation, five shekels in silver, according to the shekel of the sanctuary, which is twenty gerahs."
<G-vec00035-001-s028><redeem.auslösen><de> 49 oder sein Onkel oder der Sohn seines Onkels darf ihn auslösen, oder sonst sein nächster Blutsverwandter aus seiner Familie kann ihn auslösen; oder wenn seine Hand so viel erwirbt, so soll er sich selbst auslösen.
<G-vec00035-001-s028><redeem.auslösen><en> 49 or his uncle or his cousin may redeem him, or a close relative from his clan may redeem him. Or if he grows rich he may redeem himself.
<G-vec00035-001-s030><redeem.auslösen><de> Alles, was [zuerst] den Mutterschoß durchbricht, von allem Fleisch, das sie dem HERRN darbringen an Menschen und an Vieh, soll dir gehören; nur sollst du unbedingt den Erstgeborenen vom Menschen auslösen, und [auch] das Erstgeborene vom unreinen Vieh sollst du auslösen.
<G-vec00035-001-s030><redeem.auslösen><en> Everything that opens the womb, of all flesh which they offer to Yahweh, both of man and animal shall be your: nevertheless the firstborn of man shall you surely redeem, and the firstborn of unclean animals shall you redeem.
<G-vec00179-001-s111><trigger.auslösen><de> "Weiters fordert der Mediziner eine bessere Aufklärung von Angehörigen älterer Patient/-innen: ""Viele Medikamente, die wir im Alltag benutzen, können in Kombination mit anderen Verwirrtheitszustände auslösen"", so der Neurologe."
<G-vec00179-001-s111><trigger.auslösen><en> "Furthermore, the doctor calls for a better information of the family members of elderly patients: ""Many medications which we use in every day life can trigger confusion syndromes in combination with other drugs,"" explains the neurologist."
<G-vec00179-001-s112><trigger.auslösen><de> Aber eigentlich konnte zahlreiche natürliche Produkte, die Sie erhebliche und gefährliche Rebounds Ergebnisse auslösen, wenn die Qualität der Komponenten ist nicht groß.
<G-vec00179-001-s112><trigger.auslösen><en> But actually, numerous natural products could trigger you substantial and dangerous rebounding results, if the quality of the components is not great.
<G-vec00179-001-s113><trigger.auslösen><de> Und er hätte die alten Ängste vieler Israelis ansprechen können, dass ein Friedensabkommen mit den Palästinensern einen Zustrom billiger palästinensischer Arbeitskräfte auslösen und die Arbeitslosigkeit in den jüdischen Randgebieten vergrößern würde.
<G-vec00179-001-s113><trigger.auslösen><en> He also could have addressed persistent fears that a peace agreement will trigger an influx of cheap Palestinian labor and increase unemployment in peripheral Jewish areas.
<G-vec00179-001-s114><trigger.auslösen><de> Anzahlungsrechnungen (Vertrieb) können in der Finanzbuchhaltung Buchungen auf Personenkonten auslösen.
<G-vec00179-001-s114><trigger.auslösen><en> Partial payment invoices (sales) can trigger postings to subsidiary accounts in financial accounting.
<G-vec00179-001-s115><trigger.auslösen><de> Verfahren der Haarentfernung, zB Rasieren, Zupfen, Zupfen, oder sogar in der Nähe Enthaarung kann durchweg sehr schädlich für die Hautfarbe auslösen und führt zu roten Schwimmer, in der Regel mit der gereizten Fläche zit zusammen mit Juckreiz.
<G-vec00179-001-s115><trigger.auslösen><en> Procedures of hair removing, for example shaving, plucking, tweezing, or even close depilation consistently may trigger very harmful for skin color and leads to red floater, typically with the irritated surface area zit along with itching.
<G-vec00179-001-s116><trigger.auslösen><de> "Mit der App ""FUJIFILM Camera Remote"" können Sie über Ihr Smartphone oder Tablet fokussieren und auslösen."
<G-vec00179-001-s116><trigger.auslösen><en> "With the new dedicated ""FUJIFILM Camera Remote"" application, you can focus and trigger the camera release from your smartphone or tablet."
<G-vec00179-001-s117><trigger.auslösen><de> Wenn Sie Dokumente automatisiert in PDF umwandeln möchten, also ohne dass ein Mensch das Dokument öffnen und den Druckvorgang auslösen müsste, dann bietet Ihnen die Version „PostScope AutoConvert“ auch dafür eine einfache Möglichkeit.
<G-vec00179-001-s117><trigger.auslösen><en> If you desire to convert documents into PDF automatedly, that means without a human being having to open the document and to trigger the print process, then version „PostScope AutoConvert“ offers you an easy-to-use facility for this purpose.
<G-vec00179-001-s118><trigger.auslösen><de> Die Entkopplung der Direktzahlungen von der Produktion ermöglicht Wohlfahrtsgewinne und steigende Einkommen, wird aber auch einen verstärkten Strukturwandel auslösen.
<G-vec00179-001-s118><trigger.auslösen><en> The decoupling of direct payments from production enables welfare gains and increasing incomes, but it will also trigger intensified structural changes.
<G-vec00179-001-s119><trigger.auslösen><de> "Da sie jedoch das Schicksal des Wesens auslösen, haben wir sie ""Schicksalsbogen"" genannt."
<G-vec00179-001-s119><trigger.auslösen><en> "Since they trigger the being's fate we have termed them ""arcs of fate""."
<G-vec00179-001-s120><trigger.auslösen><de> Also wenn du diese Art der Stoffwechselprozesse auslösen kannst werden Sie in der Lage zu verlieren Gewicht ohne großen Lebensstil oder Ernährung Änderungen.
<G-vec00179-001-s120><trigger.auslösen><en> So if you‘re able to trigger these type of metabolic procedures you’ll manage to lose weight without major lifestyle or diet regimen changes.
<G-vec00179-001-s121><trigger.auslösen><de> Wenn Oxandrolone selbst keine fantastische Muskelgewebe Entwicklung auslösen, kann es sicherlich verbessert die Muskelschaffende Effekte integriert, wenn sie mit einem anderen Steroid wie Deca, Clenbuterol oder Testosteron.
<G-vec00179-001-s121><trigger.auslösen><en> When Oxandrolone itself will not trigger a fantastic muscular tissue development, it can certainly improve the muscle creating effects if integrated with another steroid such as Deca, Clenbuterol or Testosterone.
<G-vec00179-001-s122><trigger.auslösen><de> Das Fehlen von Serotonin Hormone wird sicherlich auslösen Depression und Angst, die die Nahrungsmittelsehnsüchte erzeugen kann.
<G-vec00179-001-s122><trigger.auslösen><en> The lack of serotonin hormone will certainly trigger depression and stress and anxiety which can cause the food yearnings.
<G-vec00179-001-s123><trigger.auslösen><de> Mündliche Hefe-Infektion bei Männern würde wahrscheinlich ebenfalls auslösen Dermis Skalierung.
<G-vec00179-001-s123><trigger.auslösen><en> Oral yeast infection in guys would likely likewise trigger dermis scaling.
<G-vec00179-001-s124><trigger.auslösen><de> Wenn es injiziert wird, kann es eine geringen Bluthochdruck auslösen.
<G-vec00179-001-s124><trigger.auslösen><en> When it is injected, it might trigger low high blood pressure.
<G-vec00179-001-s125><trigger.auslösen><de> Wie jede Art von typischen oder traditionellen Arzneimittel / Nahrungsergänzungsmittel kann unter Dianabol negative Körperreaktionen und auch mehr Menschen erlebt haben verschiedene negative Effekte auslösen.
<G-vec00179-001-s125><trigger.auslösen><en> Like any standard or typical medicines/supplements, taking dianabol can trigger unfavorable body reactions and even more individuals have suffered from various side effects.
<G-vec00179-001-s126><trigger.auslösen><de> "Leid entsteht nicht durch Wünsche, sondern durch ""Sollvorstellungen"", durch die man andere oder sich selbst zu Opfern machen kann: Die Angst, dem, was verlangt wird (den ""Sollvorstellungen"") nicht gewachsen zu sein, kann viele negative Gefühle und Konflikte, ja sogar Haß, auslösen und sich als Bitterkeit im Charakter festsetzen und damit genau das verhindern, was doch das ursprüngliche Ziel war - das nämlich, was wir mit Spiritualität meinen: Erwachen, Freiheit, Freude, Ekstase, Meisterschaft, Großmut; eine schöne Welt mit schönen Menschen schaffen."
<G-vec00179-001-s126><trigger.auslösen><en> The fear of being overstressed by feeling unequal to what is expected of one can trigger off a resentment which may degenerate into conflict, even hatred, and manifest as bitterness in one's character. This would forfeit what the original objective was - namely, what we mean by spirituality: awakening, freedom, joy, ecstasy, mastery, magnanimity, and building a beautiful world of beautiful people.
<G-vec00179-001-s127><trigger.auslösen><de> "Ist der/die Patient/-in jünger, müsse auch immer an Drogen gedacht werden, ""denn auch diese können einen Zustand akuter Verwirrtheit auslösen""."
<G-vec00179-001-s127><trigger.auslösen><en> """If the patient is younger, illicit drugs always have to be taken into account, because they can also trigger a condition of acute confusion."""
<G-vec00179-001-s128><trigger.auslösen><de> Eines der beliebtesten Beispiele ist die Einstellung der Windows-Registrierung – Anpassungen Saiten durch das Betriebssystem verbunden sind, können erhebliche Effizienz Störungen auslösen und den Fehler auch Windows-Dienste zugreifen.
<G-vec00179-001-s128><trigger.auslösen><en> One of the popular examples is the adjustment of the Windows Registry – adjustments strings associated by the operating system can trigger significant efficiency disturbances and also the failure to access Windows services.
<G-vec00179-001-s129><trigger.auslösen><de> Ein Event kann die Sendung eines Auto-Responders auslösen.
<G-vec00179-001-s129><trigger.auslösen><en> An event will trigger an autoresponder to send.
<G-vec00179-001-s149><trigger.auslösen><de> """Diese Ergebnisse sind deshalb so interessant, da sie zeigen wie ein einfacher Stimulus ein komplexes Verhaltensmuster auslöst."
<G-vec00179-001-s149><trigger.auslösen><en> These findings are interesting, as they show how one stimulus can trigger such complex behaviour.
<G-vec00179-001-s150><trigger.auslösen><de> Daher besitzt es genau die gleichen schmerzlindernden Eigenschaften wie Ibuprofen jedoch nicht Lebertoxizität auslöst.
<G-vec00179-001-s150><trigger.auslösen><en> Hence, it possesses the exact same pain-relieving properties as ibuprofen however it does not trigger liver toxicity.
<G-vec00179-001-s151><trigger.auslösen><de> Es erwarten Sie drei Abende voller Musik, die trotz ihrer Komplexität aufs Wesentliche reduziert ist und nach wie vor Diskussionen auslöst.
<G-vec00179-001-s151><trigger.auslösen><en> Audiences can look forward to three evenings full of music that, despite its complexity, is reduced to the essential and is sure to trigger fascinating discussions.
<G-vec00179-001-s152><trigger.auslösen><de> Laut einigen Berichten Zenerx Kritik, ist das Element einfach sicher, weil es ist wirklich aus natürlichen Zutaten hergestellt und hat keine Zusatzstoffe, die Nebenwirkungen bei einigen männlichen Enhancer verknüpft auslöst.
<G-vec00179-001-s152><trigger.auslösen><en> According to some Zenerx review reports, the item is secure simply because it really is made from natural ingredients and has no additives that will trigger side-effects linked with some male enhancers.
<G-vec00179-001-s153><trigger.auslösen><de> So nimmt es nicht Wunder, wenn die erfolgreich überlebende Natur als Anregung dient, dass eine große Zahl der bionischen Entwicklungen auch militärische Assoziationen auslöst.
<G-vec00179-001-s153><trigger.auslösen><en> Therefore, it is not surprising when successfully surviving nature helps us understand why numerous bionic developments trigger military associations.
<G-vec00179-001-s154><trigger.auslösen><de> Nur so entsteht Architektur, die Frequenz auslöst.
<G-vec00179-001-s154><trigger.auslösen><en> Only then does architecture trigger frequency.
<G-vec00179-001-s155><trigger.auslösen><de> Auf allen Walzen befindet sich auch ein WILD-Symbol sowie ein Streusymbol, welches Freispiele auslöst.
<G-vec00179-001-s155><trigger.auslösen><en> There is a WILD that is stacked on all reels, and another scatter symbol to trigger free games.
<G-vec00179-001-s156><trigger.auslösen><de> Marketingspezialisten gehen zu den endlosen Extremen, um die perfekte Nachricht zu erstellen, die diese Mechanismen nicht auslöst.
<G-vec00179-001-s156><trigger.auslösen><en> Marketers go to endless extremes to create the perfect messages that won’t trigger these mechanisms.
<G-vec00179-001-s157><trigger.auslösen><de> Wenn das Wasser direkt aus der Wolke in reinster Form auf den Sensor fällt und diesen nicht auslöst, dann genügt es, wenn er über ein kleines Brett oder von einem Vordach aus auf den Sensor läuft.
<G-vec00179-001-s157><trigger.auslösen><en> If the water falls directly from the cloud on the sensor in its purest form and does not trigger it, it will be sufficient if it runs over a small board or from a porch roof on the sensor.
<G-vec00179-001-s158><trigger.auslösen><de> Die Zahl der Schatzkisten, die die Bonusrunde auslöst, bestimmt die Zahl der Wahlmöglichkeiten, die Sie erhalten, wenn Sie auf den Meeresgrund gebracht werden.
<G-vec00179-001-s158><trigger.auslösen><en> The number of Chests that trigger the bonus will determine the number of picks you will get when you’re transported to the bottom of the sea.
<G-vec00179-001-s159><trigger.auslösen><de> Das Symbol mit einer Goldmedaille fungiert hierbei als Wild-Symbol, während das Symbol mit Ananas und Fly-By das Bonusspiel auslöst.
<G-vec00179-001-s159><trigger.auslösen><en> The symbol of gold medal is the wild here, while the symbol of pineapple and Fly-By will trigger bonus features.
<G-vec00179-001-s160><trigger.auslösen><de> Das Team um Mikael Simons, Professor für Molekulare Neurobiologie an der TUM, hat nun herausgefunden, dass nach der Zerstörung der Myelinscheide kristallines Cholesterin - ähnlich wie bei der Arteriosklerose – eine anhaltende Entzündung auslöst, die eine Regeneration verhindert.
<G-vec00179-001-s160><trigger.auslösen><en> A team led by TUM Molecular Neurobiology professor Mikael Simons has now discovered that after the destruction of myelin crystalline cholesterol can trigger persistent inflammation which prevents regeneration, similar as in arteriosclerosis.
<G-vec00179-001-s161><trigger.auslösen><de> Ein Gerät mit Sensoren, ein Netzwerk, das Daten überträgt, sowie ein System, das diese verarbeitet und Aktionen auslöst.
<G-vec00179-001-s161><trigger.auslösen><en> A device with sensors, a network for transmitting data, and a system that can process this to trigger actions.
<G-vec00179-001-s162><trigger.auslösen><de> Du könntest auch eine Lebensmittelallergie oder -Überempfindlichkeit haben, welche Kopfschmerzen auslöst.
<G-vec00179-001-s162><trigger.auslösen><en> You might also have a food allergy or sensitivity, which can trigger headaches.
<G-vec00179-001-s163><trigger.auslösen><de> Netzwerk-Proxies und andere Enterprise-Netzwerk-Sicherheitsfunktionen können verhindern, dass die Malware ihre Killswitch-Domäne kontaktiert und damit versehentlich die Verschlüsselung auslöst.
<G-vec00179-001-s163><trigger.auslösen><en> Network proxies and other enterprise network security features may prevent the malware from contacting its killswitch domain and inadvertently trigger encryption.
<G-vec00179-001-s164><trigger.auslösen><de> Eine schnelle Lieferung gehört auf dieser Seite zum guten Ton, so wie der Kauf auf Rechnung oder die ungebundene Ratenzahlung dir ein Zahlungsziel einräumt, wo du erst die Sendung von uns in deinen Händen hältst, bevor du eine Zahlung auslöst.
<G-vec00179-001-s164><trigger.auslösen><en> A fast delivery belongs to the good tone on this side, just as the purchase on account or the unbound installment payment grants you a payment target, where you hold the shipment in your hands before you trigger a payment.
<G-vec00179-001-s165><trigger.auslösen><de> Das bedeutet, jeder Teil des Körpers, von den Schultern, um Ihre Wadenknochen, wird sicherlich haben schlanke, verringert Muskel, der die Dankbarkeit der alle, die Fitness zu schätzen auslöst.
<G-vec00179-001-s165><trigger.auslösen><en> This suggests every part of your physical body, from your shoulders to your calf bones, will have lean, reduced muscle that will certainly trigger the gratitude of people who appreciates physical conditioning.
<G-vec00179-001-s166><trigger.auslösen><de> Wenn Sie kleine Energiemengen messen und das Gerät nicht auslöst, setzen Sie den Schwellenwert auf LOW (gering).
<G-vec00179-001-s166><trigger.auslösen><en> If you are measuring small energies and the unit does not trigger, set the threshold for LOW.
<G-vec00179-001-s167><trigger.auslösen><de> Dieses wird dann ausgelöst, wenn 3, 4 oder 5 Symbole das Crystal Helm Bonusspiel mit 5 Stufen auslöst.
<G-vec00179-001-s167><trigger.auslösen><en> The game is triggered when 3, 4 or 5 symbols trigger the Crystal Helm bonus game which has 5 levels.
<G-vec00179-001-s187><trigger.auslösen><de> Sie ist allerdings eine schwierig zu messende Größe, da jeweils zu definieren wäre, in welcher Hautschicht der Wirkstoff ankommen muss, um die gewünschten Effekte auszulösen.
<G-vec00179-001-s187><trigger.auslösen><en> Nevertheless, this particular factor is difficult to measure as also the individual skin layer would have to be determined in which the active agent is supposed to arrive in order to trigger the desired effects.
<G-vec00179-001-s188><trigger.auslösen><de> Dies ist die energetische Komponente in Garcinia cambogia, und wurde in einer Reihe von Untersuchungen effektiven Gewichtsverlust gezeigt auszulösen.
<G-vec00179-001-s188><trigger.auslösen><en> This is the energetic component in Garcinia Cambogia, and has been shown to trigger effective weight loss in a number of researches. Garcinia Cambogia extract is currently the globe’s most prominent weight-loss supplement.
<G-vec00179-001-s189><trigger.auslösen><de> Alle verfolgten Kometen haben keine genügende Masse, um eine starke Abstoßungskraft bei den Planeten, die sie passieren, oder bei der Sonne auszulösen, und somit nehmen die menschlichen Ephimeriden als die einzigen zu betrachtenden Elemente den Pfad und die Geschwindigkeit an.
<G-vec00179-001-s189><trigger.auslösen><en> All comets tracked do not have a mass sufficient to trigger a strong repulsion force in the planets they pass or the Sun, and thus the humans ephemeris assume the only elements to consider are the path and the speed.
<G-vec00179-001-s190><trigger.auslösen><de> Die Zerstörung Libyens durch die NATO war nicht der erste erfolgreiche Versuch von BHL, einen Krieg auszulösen.
<G-vec00179-001-s190><trigger.auslösen><en> The destruction of Libya by NATO was not BHL's first successful attempt to trigger a war.
<G-vec00179-001-s191><trigger.auslösen><de> Einmal in der Luft aufgewirbelt besteht bei ihnen beim Einatmen die Gefahr, bis in die Alveolen der Lungen vorzudringen, und dort die Wirkungen auszulösen, wie man sie von nicht abbaubaren Feststoffen wie Asbest, Glasfaser, Kohlenstaub, Dieselruß kennt.
<G-vec00179-001-s191><trigger.auslösen><en> Once blown up in the air they can be a safety hazard due to the fact that they may infiltrate into the alveoles of the lungs when breathing and then trigger the well-known effects of non degradable solid matters like asbestos, glass fiber, carbon dust and diesel exhaust particles.
<G-vec00179-001-s192><trigger.auslösen><de> Ein dreijähriges Forschungsprojekt des MuscleMeds Forschungs- und Produktentwicklungsteams hat die 19 kritischen Aminosäuren aufgedeckt, die benötigt werden, um hochintensive Workouts zu unterstützen und maximale anabole und antikatabole Effekte auszulösen.
<G-vec00179-001-s192><trigger.auslösen><en> A three-year research project by the MuscleMeds Research and Product Development Team has uncovered the 19 critical aminos needed to support high intensity workouts and trigger maximum anabolic and anti-catabolic effects.
<G-vec00179-001-s193><trigger.auslösen><de> Um die zweite auszulösen müsst ihr kurz den Gang betreten, dann aber schnell wieder in Sicherheit.
<G-vec00179-001-s193><trigger.auslösen><en> To trigger a second one, you need to step into the passage briefly but then quickly get out again.
<G-vec00179-001-s194><trigger.auslösen><de> E-Mail-Auslöser: Das ermöglicht es den Benutzern, Kampagnen basierend auf bestimmte Zeiten und Termine, Formulareinreichungen, API-Aufrufe, Attributwertänderungen und Aktionen für zuvor gesendete E-Mails auszulösen.
<G-vec00179-001-s194><trigger.auslösen><en> Email Triggers: It allows users to trigger campaigns based on specified times and dates, form submissions, API calls, attribute value changes, and actions on previously sent emails.
<G-vec00179-001-s195><trigger.auslösen><de> Hinweis: Sie können WLAuthorizationManager.obtainAccessToken aufrufen, um eine verfügbare direkte Aktualisierung auszulösen.
<G-vec00179-001-s195><trigger.auslösen><en> Note: You can call WLAuthorizationManager.obtainAccessToken to trigger a direct update if one is available.
<G-vec00179-001-s196><trigger.auslösen><de> Dies dient dem Nachweis der möglichen Gefährlichkeit der Keime und ihrer Fähigkeit, beim Menschen über die Aufnahme von Lebensmitteln Erkrankungen auszulösen.
<G-vec00179-001-s196><trigger.auslösen><en> The objective is to determine the possible harmfulness of the germs and their ability to trigger disease in humans via dietary uptake.
<G-vec00179-001-s197><trigger.auslösen><de> Das S-Symbol ist das Scatter-Symbol und hat die Fähigkeit die Bonusrunde auszulösen.
<G-vec00179-001-s197><trigger.auslösen><en> S is the scatter symbol and has ability to trigger bonus round.
<G-vec00179-001-s198><trigger.auslösen><de> Auf dieser Basis ist es möglich, Events in Ihren Backend-Systemen auszulösen – sei es bei der Anfragenbearbeitung oder bei der Weiterverarbeitung von Kundenanfragen.
<G-vec00179-001-s198><trigger.auslösen><en> On this basis, it is possible to trigger events in your backend systems, whether it is for request processing or further processing customer requests.
<G-vec00179-001-s199><trigger.auslösen><de> "Nur nahe am absoluten Temperaturnullpunkt bei -273,15 Grad Celsius herrschen die richtigen Bedingungen, um einen quantenphysikalischen Tsunami auszulösen - ein sogenanntes Bose-Einstein-Kondensat (BEC)"", erklärt CAL-Projektleiter im Raumfahrtmanagement Dr. Rainer Forke."
<G-vec00179-001-s199><trigger.auslösen><en> "Only at close to absolute zero, at –273.15 degrees Celsius, do we have the right conditions to trigger a quantum tsunami, known as a Bose–Einstein condensate (BEC),"" explains Rainer Forke, CAL Project Leader at the Space Administration."
<G-vec00179-001-s200><trigger.auslösen><de> Die technischen Daten auf der Rettungskarte geben Auskunft darüber, wo beispielsweise an der Karosserie Stahlscheren anzusetzen sind oder welche Vorsichtsmaßnahmen nötig sind, um Airbags nicht auszulösen.
<G-vec00179-001-s200><trigger.auslösen><en> The technical data on the rescue card provide information on where, for example, steel scissors are to be attached to the bodywork or what precautions are necessary in order not to trigger airbags.
<G-vec00179-001-s201><trigger.auslösen><de> Die Überwachung von Kommunikation und Daten bietet die Möglichkeit, Gefahren frühestmöglich zu erkennen und entsprechende Alarmierungen auszulösen.
<G-vec00179-001-s201><trigger.auslösen><en> The monitoring of communication and data provides the opportunity to detect dangers at the earliest possible stage and to trigger respective alerts.
<G-vec00179-001-s202><trigger.auslösen><de> Auch das feine Abstimmen der Öffnungen der Drachen darf die Vorrichtung genau regulieren, damit nur Erdbeben über einer spezifischen Schwellenenergie in der LageSIND, die angeforderte Warnung auszulösen.
<G-vec00179-001-s202><trigger.auslösen><en> Also the tuning leavers of the dragons' mouths allows to regulate the device exactly, so that only earthquakes above a specific threshold power are able to trigger the required alarm.
<G-vec00179-001-s203><trigger.auslösen><de> Gelegentlich sammelt sich auf der Oberfläche des Weißen Zwerges genügend Material an, um eine thermonukleare Nova -Explosion auszulösen, ein gewaltiges Ereignis, das eine große Menge an Material in den Weltraum wirft.
<G-vec00179-001-s203><trigger.auslösen><en> Occasionally, enough material collects on the surface of the white dwarf to trigger a thermonuclear nova explosion, a titanic event which throws a vast amount of material into space.
<G-vec00179-001-s204><trigger.auslösen><de> "Wenn du zu den ""glücklichen"" mit einer solchen Freundin gehörst, solltest du einfach versuchen, bei ihr so viele Orgasmen wie möglich auszulösen."
<G-vec00179-001-s204><trigger.auslösen><en> "If you are the ""lucky"" with a friend, it's logical that you should just try to trigger as many orgasms as possible."
<G-vec00179-001-s205><trigger.auslösen><de> Zahlreiche Tests kann getan werden, um sicherzustellen, dass Virility Pillen für Männer würden nie irgendwelche Probleme auszulösen.
<G-vec00179-001-s205><trigger.auslösen><en> Numerous tests may be done to guarantee that Virility pills for males would never trigger any problems.
<G-vec00179-001-s309><trigger.auslösen><de> Diese lösen durch den Einsatz eines elektronischen Ticketsystems bestimmte Ereignisse aus oder schränken den Zutritt auf ein festgelegtes Zeitfenster ein.
<G-vec00179-001-s309><trigger.auslösen><en> They trigger specific events or restrict entry to a defined time slot by using an electronic ticket system.
<G-vec00179-001-s310><trigger.auslösen><de> Schon seit meiner Kindheit lösen Situationen, Sätze oder Begebenheiten Assoziationen in meinem Kopf aus, über die ich lachen oder schmunzeln muss.
<G-vec00179-001-s310><trigger.auslösen><en> Ever since my childhood, some situations, sentences, or events trigger associations in my head which make me laugh or smile to myself.
<G-vec00179-001-s311><trigger.auslösen><de> Terroranschläge, Naturkatastrophen oder Unfälle lösen bei vielen Menschen noch Jahre später Angstzustände und Panikattacken aus.
<G-vec00179-001-s311><trigger.auslösen><en> Years after their occurrence, terrorist attacks, natural disasters and accidents continue to trigger anxiety and panic attacks in many people.
<G-vec00179-001-s312><trigger.auslösen><de> Die Scatter-Symbole lösen den Bonus aus.
<G-vec00179-001-s312><trigger.auslösen><en> The scatters will trigger the bonus.
<G-vec00179-001-s313><trigger.auslösen><de> Derzeit lösen nur Kreditkarten und PayPal diese Einschränkung aus.
<G-vec00179-001-s313><trigger.auslösen><en> Only credit cards and PayPal currently trigger this restriction.
<G-vec00179-001-s314><trigger.auslösen><de> Bestimmte T-Lymphozyten merken sich eine solche spezifische Abwehrreaktion und lösen, wenn sie zu einem späteren Zeitpunkt wieder auf denselben Fremdstoff treffen, eine schnelle und sehr wirkungsvolle Immunreaktion aus.
<G-vec00179-001-s314><trigger.auslösen><en> Certain T lymphocytes remember such a specific immune response and when they encounter the same foreign substance at a later time, they trigger a rapid and effective immune response.
<G-vec00179-001-s315><trigger.auslösen><de> Malte Spohr schreibt: Die unterschiedlichen Erscheinungsformen des Lichts, seine Energie, faszinieren mich, lösen in mir etwas aus, das schwer fassbar und zu beschreiben ist.
<G-vec00179-001-s315><trigger.auslösen><en> Malte Spohr: The various manifestations of light and its energy fascinate me, trigger something that is difficult to grasp or describe.
<G-vec00179-001-s316><trigger.auslösen><de> Bei einem Unfall mit Airbag lösen Crash-Sensoren im Fahrzeug automatisch einen Notruf aus.
<G-vec00179-001-s316><trigger.auslösen><en> When an airbag is deployed in an accident, crash sensors in the vehicle trigger an emergency call automatically.
<G-vec00179-001-s317><trigger.auslösen><de> Diese Mechanismen lösen bei Belastung der Muskulatur eine deutliche Symptomatik aus, welche sich je nach Schweregrad des Anfalls unterscheidet.
<G-vec00179-001-s317><trigger.auslösen><en> These mechanisms trigger a marked symptom when the muscles are stressed, which differs depending on the severity of the condition.
<G-vec00179-001-s318><trigger.auslösen><de> Lösen Sie ununterbrochen das Selbstmobile für über 30mal aus, als die Energie voll ist.
<G-vec00179-001-s318><trigger.auslösen><en> Continuously trigger the auto mobile for over 30 times when the power is full.
<G-vec00179-001-s319><trigger.auslösen><de> Im Falle einer Störung lösen die überwachten Komponenten Alarm und damit automatisch ein Trouble Ticket aus.
<G-vec00179-001-s319><trigger.auslösen><en> In the event of a malfunction, the monitored components raise the alarm and trigger a Trouble Ticket automatically.
<G-vec00179-001-s511><trigger.auslösen><de> – Erscheinen irgendwo 3 oder mehr Gratis-Spin Symbole, werden 3 Personal-Charaktere ausgelöst: der Koch, der Butler und das Dienstmädchen.
<G-vec00179-001-s511><trigger.auslösen><en> 3 or more Free Spin symbols landing anywhere trigger 3 servant characters: The Chef, the Butler and the Maid.
<G-vec00179-001-s512><trigger.auslösen><de> Wäre diese Information nicht bekannt, wüssten Sie bei der Ablaufverfolgung von Anzeigenanforderungen nicht, dass ein Video zwei Minuten lang angesehen werden muss, damit die Anzeigenanforderung ausgelöst wird, und Sie verlieren unter Umständen wertvolle Zeit.
<G-vec00179-001-s512><trigger.auslösen><en> If you did not know this information when tracing ad requests for troubleshooting, you wouldn't know to keep watching for a video for two minutes to trigger the ad request and you might lose valuable time.
<G-vec00179-001-s513><trigger.auslösen><de> – Erscheinen 3, 4 oder 5 Eisenfaust-Scatter, werden 10, 15 oder 20 Gratis-Spins ausgelöst.
<G-vec00179-001-s513><trigger.auslösen><en> – Land 3, 4 or 5 Iron Fist scatters to trigger 10, 15 or 20 free spins.
<G-vec00179-001-s514><trigger.auslösen><de> Durch Geschäftsvorgänge im Einkauf werden in der Materialwirtschaft unterschiedliche Lagerbuchungen ausgelöst, die anhand von Buchungsschlüsseln identifiziert werden.
<G-vec00179-001-s514><trigger.auslösen><en> Business activities in purchasing trigger various inventory postings in materials management, which can be identified by posting codes.
<G-vec00179-001-s515><trigger.auslösen><de> – Erscheinen 3 Scatter auf den Walzen 1, 3 und 5, werden 10 Gratis-Spins ausgelöst.
<G-vec00179-001-s515><trigger.auslösen><en> – Land 3 scatters on reels 1, 3 and 5 to trigger 10 free spins.
<G-vec00179-001-s516><trigger.auslösen><de> Durch Umbuchungen werden in der Materialwirtschaft Lagerzugangsbuchungen für die Teile ausgelöst, die in den Teilepositionen der Wareneingangsbelege erfasst sind.
<G-vec00179-001-s516><trigger.auslösen><en> Transfer postings trigger warehouse in postings in materials management for those parts that have been entered in the part lines of the stock receipt documents.
<G-vec00179-001-s517><trigger.auslösen><de> – Erscheinen 3 oder 4 Sidewinder-Scatters auf den Walzen 2, 4 und auf den horitontalen Walzen, werden 6 oder 10 Gratis-Spins ausgelöst.
<G-vec00179-001-s517><trigger.auslösen><en> – Land 3 or 4 Sidewinder scatters on reels 2,4 and the horizontal reels to trigger 6 or 10 free spins.
<G-vec00179-001-s518><trigger.auslösen><de> – Erscheinen 3, 4 oder 5 Scatter, werden 9, 12 oder 18 Gratis-Spins ausgelöst.
<G-vec00179-001-s518><trigger.auslösen><en> – Land 3, 4 or 5 scatters to trigger 9, 12 or 18 free spins.
<G-vec00179-001-s519><trigger.auslösen><de> – Durch 3, 4 oder 5 Edelsteine werden 10, 20 oder 30 Gratis-Spins ausgelöst.
<G-vec00179-001-s519><trigger.auslösen><en> – Land 3, 4 or 5 gems to trigger 10, 20 or 30 free spins.
<G-vec00179-001-s520><trigger.auslösen><de> – Erscheinen 3 oder mehr Goldene Falken-Wilds, werden 10 Gratis-Spins ausgelöst.
<G-vec00179-001-s520><trigger.auslösen><en> – Land 3 or more golden falcon wilds to trigger 10 free spins.
<G-vec00179-001-s535><trigger.auslösen><de> – Erscheinen 3 oder mehr Blatthornkäfer irgendwo auf den Walzen, wird das Feature ausgelöst.
<G-vec00179-001-s535><trigger.auslösen><en> – Land 3 or more Scarabs anywhere on the reels to trigger the feature.
<G-vec00179-001-s536><trigger.auslösen><de> – Erscheinen 2 oder mehr Drachen-Scatter, wird das Feature ausgelöst.
<G-vec00179-001-s536><trigger.auslösen><en> – Land 2 or more Dragon scatters to trigger the feature.
<G-vec00179-001-s537><trigger.auslösen><de> – Erscheinen 3 oder mehr Scatter irgendwo auf den Walzen, wird das Feature ausgelöst.
<G-vec00179-001-s537><trigger.auslösen><en> – Land 3 or more scatters anywhere on the reels to trigger the feature.
<G-vec00179-001-s538><trigger.auslösen><de> – Erscheinen 3 Blitze auf den 3 mittleren Walzen, wird das Feature ausgelöst.
<G-vec00179-001-s538><trigger.auslösen><en> – Land 3 lightning bolts on the 3 middle reels to trigger the feature.
<G-vec00179-001-s539><trigger.auslösen><de> – Erscheint das Kreigsflaggen Scatter auf den Walzen 1, 3 und 5, wird das Feature ausgelöst.
<G-vec00179-001-s539><trigger.auslösen><en> – Land the War Flag scatter on reels 1, 3 and 5 to trigger the feature.
<G-vec00179-001-s540><trigger.auslösen><de> Beim Durchbruch eines Widerstands wird ein Kaufsignal ausgelöst.
<G-vec00179-001-s540><trigger.auslösen><en> Breaks through resistance trigger buy signals.
<G-vec00179-001-s541><trigger.auslösen><de> – Erscheinen 1 oder 2 Wilds auf einer Walze, wird das Feature ausgelöst.
<G-vec00179-001-s541><trigger.auslösen><en> – Land 1 or 2 Wilds on a reel to trigger the feature.
<G-vec00179-001-s542><trigger.auslösen><de> – Erscheinen 3 Manager-Symbole, wird das Feature ausgelöst.
<G-vec00179-001-s542><trigger.auslösen><en> – Land 3 Manager symbols to trigger the feature.
<G-vec00179-001-s543><trigger.auslösen><de> Erscheinen drei oder mehr Scattersymbole, irgendwo auf den Walzen, wird der Gratis-Spins Bonus ausgelöst.
<G-vec00179-001-s543><trigger.auslösen><en> Three or more scatter symbols appearing anywhere on the reels trigger the free spins bonus round.
<G-vec00337-002-s051><precipitate.auslösen><de> Zu den schädlichen Wirkungen von Marihuana gehört die Tatsache, dass es bei anfälligen Menschen Psychosen (Paranoia) auslösen kann.
<G-vec00337-002-s051><precipitate.auslösen><en> Among harmful effects of marijuana is that cannabis use can precipitate psychosis (paranoia) in vulnerable people.
<G-vec00376-002-s019><shutter.auslösen><de> Die Kamera ist innerhalb von 1,5 Sekunden startklar und danach muss nur noch ausgelöst werden.
<G-vec00376-002-s019><shutter.auslösen><en> The camera is ready to shoot in 1.5 second, and after that it's only a matter of pressing the shutter release.
<G-vec00376-002-s020><shutter.auslösen><de> Auf dem Smartphone/Tablet wird das Live-View-Bild der Kamera angezeigt, und es können per Wi-Fi verschiedene Einstellungen wie Schärfe, Belichtungskorrektur, ISO, WB oder Fotostil vorgenommen und auch ausgelöst werden.
<G-vec00376-002-s020><shutter.auslösen><en> What the camera is seeing is displayed live smoothly on the smartphone / tablet and it is possible to set various controls including focus setting, exposure compensation, ISO, WB and Photo Style in addition to shutter release via live view using Wi-Fi®.
<G-vec00547-002-s009><unsettle.auslösen><de> Motivationsmeme lösen positive Entwicklungen bei Einzelpersonen und Gruppen aus.
<G-vec00547-002-s009><unsettle.auslösen><en> Motivation memes unsettle positive developments amongst individuals and groups.
<G-vec00016-002-s057><evoke.auslösen><de> Wir werden dem Film ja nicht gerecht, wenn wir ihn in Bezug auf Schnitt, Kameraführung, Rhythmus, klassische Atmosphäre, Struktur, Ideengehalt auseinander nehmen (denn die Klischeehaftigkeit dieses exotischen Engels lässt den Film seine wichtigste Regel vergessen – nämlich dass Technik allein genauso Assoziationen auslösen kann wie es Poesie tut).
<G-vec00016-002-s057><evoke.auslösen><en> Es war We don't have to do injustice to the film of cutting, camera movement, rhythm, classical feeling, structured, thought loaded (for there's the moldiness of the foreign darling, that it disobeys its own most central rule - that technique by itself can evoke as does poetry).
<G-vec00016-002-s062><evoke.auslösen><de> Wenn Sie diese Worte ernsthaft bei sich denken, entdecken Sie vielleicht, dass in der Befriedigung, die sie auslösen, etwas zutiefst Kindliches liegt.
<G-vec00016-002-s062><evoke.auslösen><en> If you think these words to yourself in earnest, you might find that there is something deeply childish about the gratification that they evoke.
<G-vec00016-002-s063><evoke.auslösen><de> Formschöne, multifunktionale Lösungen, die nicht solche Gefühle auslösen, gibt es nicht viele.
<G-vec00016-002-s063><evoke.auslösen><en> There are not many elegant and multifunctional solutions that do not evoke such feelings.
<G-vec00016-002-s064><evoke.auslösen><de> 19.12.2016 Bei Menschen, die an Nervenverletzungen oder Erkrankungen wie der diabetischen Neuropathie leiden, kann die leichteste Berührung heftigen Schmerz auslösen.
<G-vec00016-002-s064><evoke.auslösen><en> The slightest touch can evoke intense pain in patients suffering from nerve injuries or conditions such as diabetic neuropathy.
<G-vec00016-002-s065><evoke.auslösen><de> Dies sind zwei sehr wichtige Ministerien, die viele Emotionen auslösen, denn sie die Erziehung unserer Jugend betreffen — hat Präsident Andrzej Duda bei der Übergabe der Ernennungsurkunde an Przemysław Czarnek gesagt.
<G-vec00016-002-s065><evoke.auslösen><en> These two extremely important ministries evoke a lot of emotions, because each of them concerns the education of our youth – said Polish President Andrzej Duda, during the appointment of Przemysław Czarnek.
<G-vec00016-002-s066><evoke.auslösen><de> Ursache ist, dass wir alle in gewisser Weise farbenblind sind: sehr verschiedene Spektren können gleich aussehen (man nennt sie dann “Metamere”), wenn sie nur dasselbe Aktivierungstripel in den 3 Zapfentypen auslösen.
<G-vec00016-002-s066><evoke.auslösen><en> This is due to the fact that we all are, to a degree, colour blind: widely different spectra look alike (they are called “metamers”), as long as they evoke the same activation triplet in the 3 receptor types.
<G-vec00016-002-s305><evoke.auslösen><de> Während die oben genannten Lieder für Stimmung ohne Ende sorgen und nur positive Emotionen auslösen, gibt es andere Wiesn-Hits, die polarisieren.
<G-vec00016-002-s305><evoke.auslösen><en> While the above mentioned songs create an endless atmosphere and only evoke positive emotions, there are other Wiesn hits that polarize the listeners.
<G-vec00038-002-s030><ignite.auslösen><de> Es ist traurig, dass eine Frau sterben musste, um eine Debatte in Pakistan zur Sicherheit von Frauen im Internet auszulösen.
<G-vec00038-002-s030><ignite.auslösen><en> It’s really unfortunate that a woman had to die to ignite a debate about women’s safety on the internet in Pakistan.
<G-vec00038-002-s031><ignite.auslösen><de> Nokia: Bestes Beispiel für misslungene Transformation Eine massive Krise sei die einzige Art, eine große Veränderung auszulösen, behaupten einige Change Management Profis.
<G-vec00038-002-s031><ignite.auslösen><en> Change management professionals say that the only way to ignite a major change is to create a crisis, to make the present state intolerable.
<G-vec00038-002-s032><ignite.auslösen><de> Ungefähr dreißig Meter entfernt gab es eine Explosion, einen ungeheuren Schlag, als die Rakete vor ihnen im Wasser auftraf und die Oberfläche mit einer Geschwindigkeit durchstieß, die ausreichte, um die Federzünder auszulösen.
<G-vec00038-002-s032><ignite.auslösen><en> There was an explosion about thirty meters out, a tremendous blast as the rocket hit the sea in front of them and struck the surface at a velocity sufficient for spring-loaded detonators to ignite.
<G-vec00038-002-s007><inflame.auslösen><de> Sie hat keinen Effekt auf Sommersprossen und Altersflecken und kann auf der Haut Irritationen auslösen.
<G-vec00038-002-s007><inflame.auslösen><en> It has little to no effect on freckles and age spots, and can irritate and inflame skin.
<G-vec00038-002-s075><initiate.auslösen><de> Die Nutzer müssen die Kontaktaufnahme übrigens selbst auslösen und können Unternehmen zudem wieder blocken oder im Fall der Fälle auch als Spam melden.
<G-vec00038-002-s075><initiate.auslösen><en> Incidentally, users must initiate contact themselves and can also block companies again or report them as spam if the worst comes to the worst.
<G-vec00038-002-s076><initiate.auslösen><de> Unsere Extra Volume (EVOL)-Luftkammer reduziert die zum Auslösen des Einfederns erforderliche Kraft erheblich, was den Fahrkomfort verbessert und für besseres Ansprechen bei kleineren Unebenheiten sorgt.
<G-vec00038-002-s076><initiate.auslösen><en> Our Extra Volume (EVOL) air sleeve significantly reduces the force to initiate travel, providing added sensitivity and better small bump compliance.
<G-vec00038-002-s077><initiate.auslösen><de> Zum Auslösen der Lieferung von Beistellteilen an Lieferanten können Sie für die betreffenden Bestellungen oder Bestellungen mit Lieferplan einen Lieferschein an Lager generieren.
<G-vec00038-002-s077><initiate.auslösen><en> In order to initiate the shipping of provided parts to suppliers, you can generate a shipping document to warehouse for the corresponding purchase orders or purchase orders with delivery plan.
<G-vec00038-002-s078><initiate.auslösen><de> Beide werden durch die Anhäufung abnormaler Proteine ausgelöst, die eine Kaskade oxidativer Ereignisse auslösen, die zum Tod von Gehirnzellen führen.
<G-vec00038-002-s078><initiate.auslösen><en> Both are triggered by accumulation of abnormal proteins that initiate a cascade of oxidative events resulting in brain cell death.
<G-vec00038-002-s079><initiate.auslösen><de> Das globale Wachstum müsste diese Bewegung auslösen.
<G-vec00038-002-s079><initiate.auslösen><en> Global growth would need to be the spark to initiate this movement.
<G-vec00038-002-s080><initiate.auslösen><de> Auf Erweiterungs-DNs kann direkt durch ein Telefon zugegriffen werden, und sie können abgehende Anrufe auslösen.
<G-vec00038-002-s080><initiate.auslösen><en> Extension DNs can be accessed directly by a telephone and can initiate outgoing calls.
<G-vec00038-002-s081><initiate.auslösen><de> Sobald Sie Ihre Bestellung auslösen, ob persönlich, per E-Mail oder Telefon, entsteht ein rechtlich verbindlicher Kaufvertrag.
<G-vec00038-002-s081><initiate.auslösen><en> Contract Once you initiate your order, whether in person, by email or phone, a legally binding purchase contract is created.
<G-vec00038-002-s082><initiate.auslösen><de> Von diesem Dialogfeld aus können Sie die Vorgänge zum Erstellen einer neuen Site, zum Bearbeiten vorhandener Sites und zum Importieren und Exportieren der Site-Einstellungen auslösen.
<G-vec00038-002-s082><initiate.auslösen><en> From this dialog box, you can initiate the process for creating a new site, editing an existing site, duplicating a site, removing a site, or importing or exporting a site’s settings.
<G-vec00038-002-s083><initiate.auslösen><de> Bei bestimmten Patienten wirkt sich Östrogen positiv auf den Stoffwechsel aus, es kann aber auch Krebs auslösen.
<G-vec00038-002-s083><initiate.auslösen><en> Oestrogen has a positive effect on the metabolic processes of certain patients, although it can also initiate cancer.
<G-vec00038-002-s084><initiate.auslösen><de> Außerdem können Trader auch weitere Richtungstrades auslösen, wenn ein Breakout beim S4 Pivot stattfindet.
<G-vec00038-002-s084><initiate.auslösen><en> Also, traders can look to initiate another directional trade upon a breakout of the S4 pivot.
<G-vec00038-002-s085><initiate.auslösen><de> Unser kurzfristiges Ziel ist es, mit der Logistics Box eine Plattform bereitzustellen, auf die beliebig viele Kunden und Transporteure zugreifen und auf der sie geschäftliche Transaktionen auslösen können.
<G-vec00038-002-s085><initiate.auslösen><en> Our short-term goal with the Logistics Box is to provide a platform that any number of customers and carriers can access to initiate business transactions.
<G-vec00038-002-s086><initiate.auslösen><de> Sie erzeugen elektrische Impulse, welche die Herzschläge auslösen.
<G-vec00038-002-s086><initiate.auslösen><en> They generate electrical impulses that initiate each heartbeat.
<G-vec00038-002-s087><initiate.auslösen><de> Ohne die Vorbedingung wird das Ereignis bei jedem Auftreten eine Aktion auslösen.
<G-vec00038-002-s087><initiate.auslösen><en> Without the precondition, the event will initiate an action every time it occurs.
<G-vec00038-002-s088><initiate.auslösen><de> Wir werden einen AUD Sell-Korb-Trade auf der Mirror Plattform auslösen.
<G-vec00038-002-s088><initiate.auslösen><en> We will initiate an AUD Sell Basket trade through the Mirror.
<G-vec00038-002-s089><initiate.auslösen><de> In Kissing und Wien ist hierfür das Monitoring-Tool IXI-Inspector installiert: Das Monitoring-Tool sorgt für die Überwachung der relevanten Dienste und Prozesse im Verzeichnis und in den Dateien, kann Dienste neu starten, Prozesse beenden oder eine Benachrichtigung des Administrators per E-Mail auslösen.
<G-vec00038-002-s089><initiate.auslösen><en> In Kissing and in Vienna, the monitoring tool IXI-Inspector is installed for cases like that: The monitoring tool handles the control of the relevant services and processes in the directory and in the files that restart the services, stop processes or initiate a notification of the administrator by e-mail.
<G-vec00038-002-s090><initiate.auslösen><de> Sie können so viele Server und Verzeichnispfade eintragen wie Sie brauchen und verschiedene Ladevorgänge zur selben Zeit auslösen.
<G-vec00038-002-s090><initiate.auslösen><en> You can create as many servers as you need with different paths and initiate several uploads at the same time.
<G-vec00038-002-s091><initiate.auslösen><de> Mit einem 4 Zoll IPS-Display ausgestattet bietet das ARCHOS SafeT touch zuverlässigen Service rund um Kryptowährungen: Auslösen und Empfang von Transaktionen, Abfrage von Kontoständen und Währungskursen sowie Übertragung von Krypto-Vermögen.
<G-vec00038-002-s091><initiate.auslösen><en> With its 4” IPS touch screen, the ARCHOS SafeT touch provides a complete ecosystem enabling a full range of services: initiate and receive transactions, check balances and currencies’ evolutions and also exchange crypto-assets.
<G-vec00038-002-s092><initiate.auslösen><de> Auch Schnitte an den Blättern und anderen Teilen des Pflanzenschildes werden vermieden, da dies die Besiedlung von Pilzen auslösen kann.
<G-vec00038-002-s092><initiate.auslösen><en> Also, cuts on the leaves and other parts of the plant shield are avoided because it can initiate fungi colonization.
<G-vec00038-002-s093><initiate.auslösen><de> Hat er seine benötigte Spezifikation gefunden, muss er nur noch den Bestellvorgang im Webshop auslösen und auf die Bestätigung durch seinen Ansprechpartner im Vertrieb warten.
<G-vec00038-002-s093><initiate.auslösen><en> Once the customers have found their required specification, they only need to initiate the ordering process in the online shop and wait for a confirmation by their sales contact.
<G-vec00038-002-s094><initiate.auslösen><de> Sie signalisiert dem Körper Anweisungen mittels winziger Chemie die viel zu klein ist um eine Reaktion auszulösen, trotzdem erkennt sie euer Körper sofort.
<G-vec00038-002-s094><initiate.auslösen><en> It signals instructions to the body with tiny chemistry that is far too small to initiate a reaction, yet your body sees it instantly.
<G-vec00038-002-s095><initiate.auslösen><de> Mehrere Stimuli können gleichzeitig oder sequentiell gesendet werden, um eine bestimmte Reaktion auszulösen.
<G-vec00038-002-s095><initiate.auslösen><en> Several stimuli may be sent simultaneously or sequentially to initiate a certain reaction.
<G-vec00038-002-s096><initiate.auslösen><de> Ihr Versuch, eine deutsche Revolution auszulösen, wird innerhalb von fünf Tagen niedergeschlagen.
<G-vec00038-002-s096><initiate.auslösen><en> Their attempt to initiate a German revolution is crushed within five days.
<G-vec00038-002-s097><initiate.auslösen><de> In beiden Breakout-Fällen würde die heutige Range widerlegt und Trader können beginnen, neue Positionen aufgrund der neuen Marktrichtung auszulösen.
<G-vec00038-002-s097><initiate.auslösen><en> In either breakout scenario, today's range would be considered invalidated and traders can then begin to initiate new positions based off of the markets chosen direction.
<G-vec00038-002-s098><initiate.auslösen><de> Ultraschall ist ein alternativer Mechanismus für Temperatur, Druck, Licht oder Elektrizität, um chemische Reaktionen auszulösen.
<G-vec00038-002-s098><initiate.auslösen><en> Ultrasonication is an alternative mechanism to heat, pressure, light or electricity to initiate chemical reactions.
<G-vec00038-002-s099><initiate.auslösen><de> Es ist möglich, dass der Kurs ab den aktuellen Levels wieder ansteigt, aber das Sentiment ist zu stark, um Long-Positionen auszulösen.
<G-vec00038-002-s099><initiate.auslösen><en> It is possible that prices could turn higher from current levels, but sentiment is too strong to initiate long positions.
<G-vec00038-002-s025><spark.auslösen><de> Der israelische Ministerpräsident Benjamin Netanjahu ging in seiner Rede vor dem US-Kongress Anfang März noch weiter und behauptete, dass selbst die Billigung eines iranischen Programms zur Urananreicherung "ein nukleares Wettrüsten in der gefährlichsten Region dieses Planeten" auslösen würde.
<G-vec00038-002-s025><spark.auslösen><en> Israeli Prime Minister Benjamin Netanyahu went further when he addressed the United States Congress in early March, asserting that even allowing Iran a uranium-enrichment programme would "spark a nuclear arms race in the most dangerous part of the planet".
<G-vec00038-002-s026><spark.auslösen><de> "Ich denke, genauso wie Diablo und Diablo II diese religiöse Diskussion darüber gestartet haben, ob es sich da nun um RPGs handelt oder nicht, genauso wird auch Hellgate debaten darüber auslösen, ob es nun ein MMO ist, oder nicht", meinte Roper, der noch hinzufügte, dass Hellgate vom ersten Tag an als MMO geplant war.
<G-vec00038-002-s026><spark.auslösen><en> "I think that just as Diablo and Diablo II started this religious argument over whether they're RPGs or not, I think that Hellgate will spark that same debate over whether it's an MMO or not," commented Roper, who added that the game has been designed as an MMO from day one.
<G-vec00038-002-s027><spark.auslösen><de> Mit anderen Worten, die drohende Finanzkrise wird wahrscheinlich eine Massenbewegung der Arbeiterklasse gegen soziale Ungleichheit auslösen.
<G-vec00038-002-s027><spark.auslösen><en> In other words, the looming financial crisis will likely spark a mass movement of the working class against social inequality.
<G-vec00038-002-s028><spark.auslösen><de> Von traditionellen ethnischen Restaurants bis zu kulinarischen Hotspots, die nationale Trends im Bereich der Küche auslösen, zeigt Ihnen Ihr Guide, wo Sie wie ein Einheimischer essen können.
<G-vec00038-002-s028><spark.auslösen><en> From traditional ethnic eateries to culinary hotspots that spark national dining trends, your guide will show you where to eat like a local.
<G-vec00038-002-s029><spark.auslösen><de> Um Worte, die beschwören, versprechen, Liebe erklären oder sie vergiften, die vielleicht sogar Kriege auslösen und tödlich sein können.
<G-vec00038-002-s029><spark.auslösen><en> Words that invoke, promise, declare or poison love, that may even spark off wars and be deadly.
<G-vec00038-002-s030><spark.auslösen><de> Es könnte sogar etwas in dir auslösen und eine Flamme entzünden, und bevor du merkst, dass etwas passiert ist, hat sich etwas grundlegend verändert und du würdest nicht wieder zu dem zurückkehren wollen, wie es früher war.
<G-vec00038-002-s030><spark.auslösen><en> It might even light something within you and spark a flame and before you realize that anything has happened, something has changed and you would never want to go back to the way it was before.
<G-vec00038-002-s031><spark.auslösen><de> Das hätte eine Kreditkrise mit weitreichenden Folgen, vielleicht sogar für die gesamte Weltwirtschaft, auslösen können.
<G-vec00038-002-s031><spark.auslösen><en> That would then spark a credit crisis with far-reaching consequences, perhaps even for the global economy.
<G-vec00038-002-s032><spark.auslösen><de> Notizen können ein revolutionäres Konzept auslösen, sie können Gefühle und Emotionen hervorrufen, und sie inspirieren Kreativität und produktives Verhalten.
<G-vec00038-002-s032><spark.auslösen><en> Notes can spark a revolutionary concept, they can surface feelings and emotions, and they inspire creativity and productive behaviour.
<G-vec00038-002-s033><spark.auslösen><de> Apulien ist bekannt für seine weißen Straßen, historischen Gebäude und eine gemütliche italienische Atmosphäre, die zweifellos Urlaubsgefühl auslösen wird.
<G-vec00038-002-s033><spark.auslösen><en> Puglia is known for its white streets, historical buildings and a cozy Italian atmosphere that will spark a holiday feeling without a doubt.
<G-vec00038-002-s034><spark.auslösen><de> Zweitens in gewissen Ritualen des kollektiven Gedenkens, in denen eine soziale Gruppe sich vergegenwärtigt, was ohne rituelle Rahmung Verlegenheit oder andere Formen des Meidungsverhaltens auslösen würde.
<G-vec00038-002-s034><spark.auslösen><en> In the second place, we have certain rituals of collective remembrance through which a social group brings something to mind that without the ritual frame would spark embarrassment or other types of avoidance behavior.
<G-vec00038-002-s035><spark.auslösen><de> „Ich muss mich sehr mit einer Platte verbunden fühlen und der Song muss etwas in mir auslösen.
<G-vec00038-002-s035><spark.auslösen><en> I have to feel connected before I record and the song has to spark something inside me.
<G-vec00038-002-s036><spark.auslösen><de> Unsere Westin Family Programme sollen Erstaunen auslösen und Neugierde wecken, und die Westin Family Kids Clubs bieten dabei ein fantasievolles Umfeld, in dem Kinder nach Herzenslust spielen können.
<G-vec00038-002-s036><spark.auslösen><en> Our Westin Family programs were designed to ignite wonder and spark curiosity, and our Westin Family Kids Clubs provide imaginative spaces for kids to play.
<G-vec00038-002-s077><trigger.auslösen><de> Wenn Superman auf der ersten Walze und Lex Luthor zeitgleich auf der fünften Walze erscheinen, wird das Bonusspiel ausgelöst.
<G-vec00038-002-s077><trigger.auslösen><en> Superman on the 1st reel and Lex Luthor on the 5th reel displayed at the same time will trigger this feature.
<G-vec00038-002-s078><trigger.auslösen><de> * Falls eine oder mehrere Kreaturen, die ein Gegner kontrolliert, gleichzeitig mit dem Sangumagier auf den Friedhof gelegt werden, wird die erste Fähigkeit des Sangumagiers entsprechend oft ausgelöst.
<G-vec00038-002-s078><trigger.auslösen><en> * If one or more creatures an opponent controls are put into the graveyard at the same time as Sangromancer, Sangromancer's first ability will trigger that many times.
<G-vec00038-002-s079><trigger.auslösen><de> Erleidet das Ziel durch eine von LeBlancs Fähigkeiten Schaden, wird das Siegel ausgelöst und lässt es Schaden erleiden und verstummen.
<G-vec00038-002-s079><trigger.auslösen><en> If the target takes damage from one of Leblanc's abilities, the mark will trigger, dealing damage and silencing the target.
<G-vec00038-002-s080><trigger.auslösen><de> Darauf aufbauend werden vier Benutzerstudien vorgestellt, in welchen spezifische Erwartungshaltungen ausgelöst wurden und es wird auf methodische Herausforderungen hingewiesen.
<G-vec00038-002-s080><trigger.auslösen><en> Based on that, four empirical user studies are discussed which show how to trigger quality-related expectations in a laboratory setup and which methodological aspects need to be considered.
<G-vec00038-002-s081><trigger.auslösen><de> Bei Diebstahl kann mit „Asset Tracking“ frühzeitig Alarm ausgelöst und die Aufklärung beschleunigt werden.
<G-vec00038-002-s081><trigger.auslösen><en> In case of theft, Asset Tracking can trigger an alert quickly and expedite the resolution of the case.
<G-vec00038-002-s082><trigger.auslösen><de> Durch Wareneingangsbelege werden unterschiedliche Mengen- und Werteflüsse ausgelöst.
<G-vec00038-002-s082><trigger.auslösen><en> Stock receipt documents trigger different quantity and value flows.
<G-vec00038-002-s083><trigger.auslösen><de> Gegebenenfalls können nach dem Start eines YouTube-Videos weitere Datenverarbeitungsvorgänge ausgelöst werden, auf die wir keinen Einfluss haben.
<G-vec00038-002-s083><trigger.auslösen><en> As the case may be, starting a YouTube video may trigger further data processing operations, an event which we have no influence in.
<G-vec00038-002-s084><trigger.auslösen><de> Haltepedal-Events werden auf wiederholten MIDI-Regionen nun ordnungsgemäß ausgelöst.
<G-vec00038-002-s084><trigger.auslösen><en> Sustain pedal events now trigger properly on looped MIDI regions.
<G-vec00038-002-s085><trigger.auslösen><de> Wenn gbak auf alle Zeilen in den zu sichernden Tabellen zugreift, wird auch die Speicherbereinigung ausgelöst und kann bei einer großen Anzahl von Aktualisierungen die Sicherung verlangsamen.
<G-vec00038-002-s085><trigger.auslösen><en> As gbak accesses all the rows in the tables being backed up, it too will trigger the garbage collection and, if there have been a large number of updates, can slow down the backup.
<G-vec00038-002-s086><trigger.auslösen><de> A: Sie wird zweimal ausgelöst.
<G-vec00038-002-s086><trigger.auslösen><en> A: It will trigger twice.
<G-vec00038-002-s087><trigger.auslösen><de> Sie sind eine Minderheit, aber verantwortlich für ein großes Chaos – und leider müssen wir feststellen, dass nach Jahren, in denen wir hofften, dieses Phänomen durch die Durchsetzung der Gesetze und Verhandlungen in den Griff zu bekommen, in Nigeria inzwischen eine Kettenreaktion ausgelöst worden ist.
<G-vec00038-002-s087><trigger.auslösen><en> They are a minority, but are causing great trouble and we think unfortunately that the moment has come when it will trigger a chain reaction in Nigeria, after years in which we hoped and wished that this phenomenon could be reabsorbed, just by applying the law and negotiating.
<G-vec00038-002-s088><trigger.auslösen><de> Du kontrollierst Maralens ausgelöste Fähigkeit, obwohl sie für einen Gegner ausgelöst wurde, also kontrollierst du die Fähigkeit die ihn suchen lässt.
<G-vec00038-002-s088><trigger.auslösen><en> You control Maralen's trigger, even if it's triggering for an opponent, so you control the triggered ability that would let them search.
<G-vec00038-002-s089><trigger.auslösen><de> Die programmierbare G-Taste schaltet standardmäßig durch die Einstellungen für die Farbhelligkeit oder kann über G HUB so programmiert werden, dass Anwendungen ausgelöst oder In-Game-Makros ausgeführt werden.
<G-vec00038-002-s089><trigger.auslösen><en> Programmable G-key cycles through color brightness by default, or can be programmed to trigger applications or execute in-game macros via G HUB.
<G-vec00038-002-s090><trigger.auslösen><de> Freispiele werden mit derselben Linienanzahl und demselben Einsatzbetrag gespielt, mit dem das Freispiel ausgelöst wurde.
<G-vec00038-002-s090><trigger.auslösen><en> Free games are played using the number of line and the bet amount you selected in the trigger game.
<G-vec00038-002-s091><trigger.auslösen><de> 'Jagdfieber' hat jetzt pro 10 verbrauchten Fokuspunkten eine Chance von 6 %, ausgelöst zu werden (vorher eine feste Chance von 30 %).
<G-vec00038-002-s091><trigger.auslösen><en> Thrill of the Hunt now has a 6% chance to trigger for every 10 Focus spent (instead of a flat 30% chance).
<G-vec00038-002-s092><trigger.auslösen><de> Bei jeglichem Versagen des Gewichtsausgleiches wird diese federbelastete Exzenterbremse ausgelöst.
<G-vec00038-002-s092><trigger.auslösen><en> If any damage should occur to prevent the counterweight working correctly, this spring-loaded eccentric brake system will trigger.
<G-vec00038-002-s093><trigger.auslösen><de> Es ist sicherlich akzeptabel, eine Transistion ohne Wächter zu haben - die Transition wird immer genommen, wenn das Signal ausgelöst wird.
<G-vec00038-002-s093><trigger.auslösen><en> It is perfectly acceptable to have a transition without a guard—the transition is always taken when the trigger is invoked.
<G-vec00038-002-s094><trigger.auslösen><de> Durch eine bestimmte Anordnung der Einstellungen, soll beim Betrachter eine Assoziation ausgelöst werden, die eigentliche Aussage wird jedoch nicht gezeigt.
<G-vec00038-002-s094><trigger.auslösen><en> Shots are strung together in a certain order to trigger associations in the mind of the viewer, but the actual message is not shown.
<G-vec00038-002-s095><trigger.auslösen><de> Die Korrekturen werden ausgeführt, sobald Visio feststellt, dass die Autokorrektur ausgelöst wurde.
<G-vec00038-002-s095><trigger.auslösen><en> The corrections are performed when Visio detects the AutoCorrect trigger.
<G-vec00038-002-s096><trigger.auslösen><de> Langsamer Fall: Dieser Zauber kann jetzt Schmuckstücke aktivieren, die dadurch ausgelöst werden können, dass ein hilfreicher Zauber gewirkt wird.
<G-vec00038-002-s096><trigger.auslösen><en> Slow Fall: This spell can now activate trinkets that can trigger from casting a helpful spell.
<G-vec00038-002-s097><trigger.auslösen><de> Wenn eine 3D-DWF- oder DWFx-Datei zweimal hintereinander gedruckt wird, kann ein Kundenfehlerbericht (Customer Error Report – CER) ausgelöst werden und dazu führen, dass Design Review während des zweiten Druckauftrags plötzlich geschlossen wird.
<G-vec00038-002-s097><trigger.auslösen><en> Printing a 3D DWF or DWFx file two times successively may trigger a Customer Error Report (CER) and cause Design Review to close unexpectedly during the second print job.
<G-vec00038-002-s098><trigger.auslösen><de> Jeder Kämpfer hat bestimmte angeborene Fertigkeiten, die unter bestimmten Bedingungen ausgelöst werden können.
<G-vec00038-002-s098><trigger.auslösen><en> Each Fighter has certain innate skills that can trigger under certain conditions.
<G-vec00038-002-s099><trigger.auslösen><de> Schattentechnik kann nur einmal alle 4,5 Sekunden ausgelöst werden und verursacht deutlich mehr Schaden.
<G-vec00038-002-s099><trigger.auslösen><en> Shadow Technique can now only trigger once every 4.5 seconds and deals significantly more damage.
<G-vec00038-002-s100><trigger.auslösen><de> Da das MSRT keine Viren oder Würmer enthält, sollte Ihr Antivirenprogramm durch das Tool nicht ausgelöst werden.
<G-vec00038-002-s100><trigger.auslösen><en> Because the MSRT does not contain a virus or a worm, the removal tool alone should not trigger your antivirus program.
<G-vec00038-002-s101><trigger.auslösen><de> Im Zimmer herrscht Ruhe, um Störungen zu vermeiden, durch die Muskelkrämpfe ausgelöst werden könnten.
<G-vec00038-002-s101><trigger.auslösen><en> The room is kept quiet to prevent disturbances that could trigger muscle spasms.
<G-vec00038-002-s102><trigger.auslösen><de> Das bedeutet, dass durch das Licht chemische Reaktionen im Auge ausgelöst werden und dadurch das Gewebe geschädigt wird.
<G-vec00038-002-s102><trigger.auslösen><en> That means that light can trigger chemical reactions in the eye, resulting in damage to the tissue.
<G-vec00038-002-s103><trigger.auslösen><de> Sie stecken nicht nur in den Wörtern, sondern auch in der Satzmelodie, im Rhythmus, und in den Assoziationen, die beim Leser ausgelöst werden.
<G-vec00038-002-s103><trigger.auslösen><en> They’re not just in the words; they’re also in the melody of the sentences, in the rhythm and in the associations they trigger in the mind of the reader.
<G-vec00038-002-s105><trigger.auslösen><de> Automatische Einladungen können von einer regelbasierten Engine nach bestimmten Kriterien wie Besucherverhalten, Käufertyp und besuchten Seiten ausgelöst werden.
<G-vec00038-002-s105><trigger.auslösen><en> The rules-based engine can trigger invitations based on criteria such as predefined visitor behavior, types of buyers, and pages visited.
<G-vec00038-002-s106><trigger.auslösen><de> Achte auf: 1 von 4 Funktionen, die zufällig ausgelöst werden können, und die Landung von 3 Bonussymbolen verleiht den Bogenschießen-Bonus, bei dem du Pfeile auf Preise schießt.
<G-vec00038-002-s106><trigger.auslösen><en> Look out for: 1 of 4 features that can trigger randomly, and landing 3 bonus symbols anywhere on the reels awards the Archery bonus where you shoot arrows at prizes.
<G-vec00038-002-s107><trigger.auslösen><de> Dies wird verwendet, wenn bestimmt wird, ob ein Popup ausgelöst werden soll.
<G-vec00038-002-s107><trigger.auslösen><en> This is used when determining whether to trigger a pop-up.
<G-vec00038-002-s108><trigger.auslösen><de> Die Belohnungen im Spiel können leicht ausgelöst werden und bieten einen maximalen jackpot von 5.000 Münzen.
<G-vec00038-002-s108><trigger.auslösen><en> Players can trigger the jackpot in 5 different ways, which can provide up to 5,000 coins.
<G-vec00038-002-s109><trigger.auslösen><de> Da AFS-Einladungen durch E-Mails (und nicht durch eine API) ausgelöst werden, ist diese Methode mit den meisten Plattformen kompatibel.
<G-vec00038-002-s109><trigger.auslösen><en> Because emails (and not an API) trigger AFS, it's compatible with most platforms.
<G-vec00038-002-s110><trigger.auslösen><de> Dieses Problem kann ausgelöst werden, wenn ein Computer in einem Ordner mit einem langen Dateinamen synchronisiert.
<G-vec00038-002-s110><trigger.auslösen><en> It's possible to trigger this issue when a computer synchronizes in a folder with a long file name.
<G-vec00038-002-s111><trigger.auslösen><de> Da Prostaglandine Stoffe sind, die Entzündungen, Schmerzen, Exudation (Flüssigkeitsabsonderungen aus den Blutgefäßen bei einer Entzündung) und Fieber auslösen, vermindert Meloxicam diese Symptome.
<G-vec00038-002-s111><trigger.auslösen><en> As prostaglandins are substances that trigger inflammation, pain, exudation (fluid that leaks out of blood vessels during an inflammation) and fever, meloxicam reduces these signs of disease.
<G-vec00038-002-s112><trigger.auslösen><de> Diese Zutaten dann wiederum auslösen oder stimulieren die Produktion von Wachstumshormon in unsere Hypophyse.
<G-vec00038-002-s112><trigger.auslösen><en> These active ingredients then in turn trigger or promote the manufacturing of growth hormone in our pituitary gland.
<G-vec00038-002-s113><trigger.auslösen><de> Sie hoffen, dass, wenn sie gleichzeitig viele Flugzeuge und Drohnen in den iranischen Luftraum schicken und dann schnell flüchten, sie ein massives Starten der iranischen Luftwaffe auslösen, damit amerikanische Schiffe glauben, diese wären verantwortlich für das Bombardieren ihrer Flotte.
<G-vec00038-002-s113><trigger.auslösen><en> By departing quickly after sending many airplanes and drones into Iranian air space at the same time, they hope to trigger a massive launch of the Iranian air force. U.S. ship personnel will believe that launch to be responsible for bombing their flotilla.
<G-vec00038-002-s114><trigger.auslösen><de> Wenn die Mutter viel Kuhmilch trinkt, kann das Kind eine erhöhte Empfindlichkeit dafür haben, was in der Zukunft eine allergische Reaktion auf dieses Produkt auslösen wird.
<G-vec00038-002-s114><trigger.auslösen><en> If the mother drinks a lot of cow's milk, the child may have increased sensitivity to it, which in the future will trigger an allergic reaction to this product.
<G-vec00038-002-s115><trigger.auslösen><de> Episerver Reach - Personalisieren und Auslösen von Trigger-Mails, basierend auf dem Verhalten Ihrer Besucher.
<G-vec00038-002-s115><trigger.auslösen><en> Episerver Reach - Personalize and trigger emails based on behavioral data.
<G-vec00038-002-s116><trigger.auslösen><de> Werden IP-Kameras mit dem KNX System verknüpft, sind weitere Lösungen realisierbar, bei denen Melder, Sensoren und IP-Kameras zusammenarbeiten und verschiedene Aktionen auslösen.
<G-vec00038-002-s116><trigger.auslösen><en> If IP cameras are linked to the KNX system, additional solutions in which detectors, sensors and IP cameras work together and trigger various actions can be implemented.
<G-vec00038-002-s117><trigger.auslösen><de> Die Möglichkeit eine Warnung an Benutzer zu richten, die einen Filter auslösen.
<G-vec00038-002-s117><trigger.auslösen><en> The ability to provide a warning to users who trigger a filter.
<G-vec00038-002-s118><trigger.auslösen><de> Sollte etwas schief gehen: Chaos/Bürgerkrieg auslösen, denn das Endziel ist der Abriss der alten Ordnung, um die Neue auf den Ruinen aufzubauen – mit reduzierter Sklavenbevölkerung.
<G-vec00038-002-s118><trigger.auslösen><en> If something goes wrong: Trigger chaos / civil war, because the end goal is the demolition of the old order to build the new on the ruins – with reduced slaves population.
<G-vec00038-002-s119><trigger.auslösen><de> Wenn mindestens zwei nicht gewinnende Cluster in einer Position auf den Walzen erscheinen, kann dies die Sticky Re-Spin-Funktion auslösen.
<G-vec00038-002-s119><trigger.auslösen><en> When a minimum of two non-winning clusters appears in any position on the reels, this can trigger the Sticky Re-Spin feature.
<G-vec00038-002-s120><trigger.auslösen><de> Sie müssen möglicherweise klicken auf mehrere Objekte, um bestimmte Aktionen auslösen.
<G-vec00038-002-s120><trigger.auslösen><en> You may need to click on multiple objects to trigger some actions.
<G-vec00038-002-s121><trigger.auslösen><de> Einige Infektionen können die Sklerodermie auslösen, doch die Erkrankung selbst ist nicht ansteckend und die betroffenen Kinder müssen nicht von den anderen Kindern isoliert werden.
<G-vec00038-002-s121><trigger.auslösen><en> Some infections may trigger the disease process but the condition itself is not infectious and affected children do not need to be isolated from others. 2.
<G-vec00038-002-s122><trigger.auslösen><de> Wir warten einfach darauf, dass die Scatter auftauchen und das Bonusspiel oder die Freispiele auslösen.
<G-vec00038-002-s122><trigger.auslösen><en> We just wait for the scatters to show up and trigger the bonus game or free spins.
<G-vec00038-002-s123><trigger.auslösen><de> Problemhaut Das Sonnenlicht kann neben dem Sonnenbrand auch unangenehme Lichtdermatosen auslösen.
<G-vec00038-002-s123><trigger.auslösen><en> Besides the well-known sun burns, sunlight also can trigger very annoying light dermatoses.
<G-vec00038-002-s124><trigger.auslösen><de> In einigen Fällen kann die Verletzung von EU-Recht eine Vielzahl einzelner Klagen auslösen.
<G-vec00038-002-s124><trigger.auslösen><en> In some cases, the violation of EU law may trigger multiple individual lawsuits.
<G-vec00038-002-s125><trigger.auslösen><de> Auch Menschen können ohne eine spezielle Zusatzausrüstung beim Kontakt mit dem Bauteil eine ESD auslösen.
<G-vec00038-002-s125><trigger.auslösen><en> If employees are not using special equipment, they themselves can trigger an ESD when they come into contact with a part.
<G-vec00038-002-s126><trigger.auslösen><de> Diese Resultate der Analyse könnten in Echtzeit Alarmierungen auslösen.
<G-vec00038-002-s126><trigger.auslösen><en> These results of the analysis could trigger alarms in real time.
<G-vec00038-002-s127><trigger.auslösen><de> So sehen die Administratoren alle noch ungelösten Probleme, die eine E-Mail-Warnung auslösen würden, auf einen Blick und an einem Ort, und können entsprechende Maßnahmen ergreifen.
<G-vec00038-002-s127><trigger.auslösen><en> This allows admins to quickly see, in one place, every outstanding issue that would trigger an email alert so they can take action to correct those behaviors.
<G-vec00038-002-s128><trigger.auslösen><de> Wird ein Benutzer dazu verleitet, eine Webseite mit einem in böser Absicht erstellten Java-Applet zu besuchen, so kann ein Angreifer das Problem auslösen, was zur Ausführung willkürlichen Codes führen kann.
<G-vec00038-002-s128><trigger.auslösen><en> By enticing a user to visit a web page containing a maliciously crafted Java applet, an attacker can trigger the issue which may lead to the disclosure of sensitive information.
<G-vec00038-002-s129><trigger.auslösen><de> Auch wenn Gedanken leicht Emotionen auslösen können, indem sie die Amygdala aktivieren, ist es sehr schwierig, absichtlich diese Emotionen wieder abzuschalten.
<G-vec00038-002-s129><trigger.auslösen><en> Even though thoughts can readily trigger emotions by activating the amygdala, it is very difficult to willfully turn off emotions.
<G-vec00038-002-s149><trigger.auslösen><de> Die Wirtschaft des vereinigten Königsreiches, das Zyperns größte Quelle an einreisenden Touristen darstellt, soll im nächsten Jahr um 1,1 Prozent expandieren, wenn das Land Artikel 50 des EU Vertrages zum Austritt aus der europäischen Union auslöst, so der IMF.
<G-vec00038-002-s149><trigger.auslösen><en> The economy of the UK, Cyprus’s largest source of incoming tourism is expected to expand 1.1 per cent next year, when the country is expected to trigger article 50 of the European Treaty in order to exit the European Union, the IMF said.
<G-vec00038-002-s150><trigger.auslösen><de> Der Spieler schaltet neue Zusatzspiele frei, sobald er weitere Zusatzrunden auslöst, und kann letztendlich aus vier Zusatzrunden wählen - siehe unten.
<G-vec00038-002-s150><trigger.auslösen><en> Players unlock new features as they trigger more feature rounds and can ultimately choose one of four feature rounds, detailed below.
<G-vec00038-002-s151><trigger.auslösen><de> Trotz dieser Kontroversen, die dieser Park auslöst, wurde er gerne benutzt, auch aus Mangel an Alternativen in dieser Gegend von Barcelona.
<G-vec00038-002-s151><trigger.auslösen><en> Despite these controversies which trigger the park, the people like to use it, also because of no alternatives in this area of Barcelona.
<G-vec00038-002-s152><trigger.auslösen><de> Achte auf: The Sand Princess vollständig auf Walze 3, die 1 aus 4 Modifikatoren auslöst, und 3 Scatter Symbole, die du aus 4 verschiedenen Freispielmodis auswählst und startest.
<G-vec00038-002-s152><trigger.auslösen><en> Look out for: The Sand Princess landing in full on reel 3 that will trigger 1 of 4 modifiers, and landing 3 scatters awards you a pick from 4 different free spin modes.
<G-vec00038-002-s153><trigger.auslösen><de> Zum anderen können lösliches IL-6 und löslicher IL-6 Rezeptor einen Komplex bilden, der in bestimmten Zielzellen ein Signal auslösen kann („Trans-Signaling“).Korn und Waisman fanden heraus, dass IL-6 weder auf die eine noch auf die andere Weise die entscheidende Veränderung in den T-Zellen auslöst.
<G-vec00038-002-s153><trigger.auslösen><en> Second, in a process known as trans-signaling, soluble IL-6 and the soluble IL-6 receptor can form a complex that can trigger a signal in certain responder cells. Korn and Waisman have discovered that IL-6 does not trigger the decisive change in the T cells in either of those cases.
<G-vec00038-002-s154><trigger.auslösen><de> Wenn Ihr Körper also zum zweiten Mal auf ein bestimmtes Allergen trifft, werden innerhalb weniger Minuten Ihre Mastzellen aktiviert und setzen einen starken Cocktail aus Histamin, Leukotrienen und Prostaglandinen frei, der die gesamte Kaskade von Symptomen auslöst, die Sie mit Allergien in Verbindung bringen: Niesen, laufende Nase, Halsschmerzen, Husten, Juckreiz, rote Augen etc.
<G-vec00038-002-s154><trigger.auslösen><en> So, the second time your body encounters a particular allergen, within a few minutes, your mast cells become activated and release a powerful cocktail of histamine, leukotrienes, and prostaglandins, which trigger the entire cascade of symptoms you associate with allergies: sneezing, runny nose, sore throat, hacking cough, itchy eyes, etc.
<G-vec00038-002-s155><trigger.auslösen><de> In wissenschaftlichen Studien wurde gezeigt, dass blaues Licht eine wichtige Gehirnfunktion auslöst, die Wachheit und Aufmerksamkeit fördert.
<G-vec00038-002-s155><trigger.auslösen><en> In academic studies, blue light has also been shown to trigger an important brain function that helps to facilitate alertness and enhance attention.
<G-vec00038-002-s156><trigger.auslösen><de> Allerdings kommen die vielen Zusatzfunktionen manchmal in die Quere, etwa wenn man aus versehen den Bereich der Scrollleiste berührt und der Mauszeiger einfach stehen bleibt, oder man versehentlich eine Geste auslöst.
<G-vec00038-002-s156><trigger.auslösen><en> However, the multiple additional functions sometimes get in the way, for instance if you accidentally touch the scroll bar area and the mouse cursor simply freezes or if you unintentionally trigger a gesture.
<G-vec00038-002-s157><trigger.auslösen><de> Die Herausforderung, der unsere Wissenschaftler gegenüberstehen, besteht darin, Impfstoffe zu entwickeln, die den passenden Erreger oder einen Bestandteil dieses Erregers beinhalten, der eine Reaktion im körpereigenen Immunsystem auslöst und so einen Schutz bewirkt.
<G-vec00038-002-s157><trigger.auslösen><en> The challenge faced by our scientists is to develop vaccines that incorporate the appropriate pathogen or component of the pathogen which will trigger our own immunity and provide protection.
<G-vec00038-002-s158><trigger.auslösen><de> Jetzt ist alles richtig konfiguriert, es ist an der Zeit, eine Reihe von Tests durchzuführen, um sicherzustellen, dass Heartbeat tatsächlich eine Übertragung vom aktiven Server zum passiven Server auslöst, wenn der aktive Server in irgendeiner Weise ausfällt.
<G-vec00038-002-s158><trigger.auslösen><en> Now, everything is configured properly, it's time to perform a series of tests to verify that heartbeat will actually trigger a transfer from the active server to the passive server when the active server fails in some way.
<G-vec00038-002-s159><trigger.auslösen><de> Über Analysejobs können Log-Dateien von Vorgängerjobs auf beliebige Zeichenfolgen hin untersucht werden, was ergebnisabhängig Folgeschritte auslöst oder unterbindet.
<G-vec00038-002-s159><trigger.auslösen><en> Parser jobs (or analysis jobs) can be used to search log files from previous jobs for any given string of characters, which may trigger or prevent follow-up steps, depending on the results.
<G-vec00038-002-s160><trigger.auslösen><de> Wenn dieses Material sich stromabwärts bewegt, kann es schwere Komplikationen verursachen, Zum Beispiel kann loses, embolisches Material, Thrombosemittel, das innerhalb der aufsteigenden Aorta, des Aortenbogens oder der Halsschlagadern freigesetzt wird, stromabwärts zum Hirn wandern, wo es möglicherweise einen Schlaganfall auslöst, der zu dauerhaften Verletzungen oder sogar Thrombosemittel Tod des Patienten führen kann.
<G-vec00038-002-s160><trigger.auslösen><en> If this material moves downstream, Thrombosemittel, it can cause serious complications, Thrombosemittel. For example, loose embolic material released within the ascending Thrombosemittel, the aortic arch or the carotid arteries, migrate downstream to the brain, where it may trigger a stroke that can lead to permanent injury or even death of the patient.
<G-vec00038-002-s161><trigger.auslösen><de> Er enthält nur einen sehr geringen Nickelanteil, der beim Tragen nicht abgegeben wird und so keine Nickelallergien auslöst.
<G-vec00038-002-s161><trigger.auslösen><en> It contains only a very small proportion of nickel, which is not released when worn and therefore does not trigger any nickel allergies.
<G-vec00038-002-s162><trigger.auslösen><de> In diesem Beispiel nutzt der Trader einen einfachen MACD, der seine Orders auslöst.
<G-vec00038-002-s162><trigger.auslösen><en> In this example the trader uses a simple MACD to trigger his orders.
<G-vec00038-002-s163><trigger.auslösen><de> Der plötzliche Austausch zwischen einem Computer innerhalb eines Unternehmensnetzwerks und einem unbekannten externen Gerät ist ein Weckruf, der im Normalfall eine Reaktion des IS-Teams auslöst – aus diesem Grund versuchen Cyberkriminelle diese Kommunikation auf Biegen und Brechen zu verbergen.
<G-vec00038-002-s163><trigger.auslösen><en> Sudden exchanges between a computer from inside a corporate network with an unknown external machine are a wakeup call, certain to trigger a response from the IS team — which is exactly why cybercriminals are dead set on concealing these communications.
<G-vec00038-002-s166><trigger.auslösen><de> Falls der Dialog mit ihr nicht automatisch auslöst, wenn wir die Peitsche an uns nehmen (vorausgesetzt, ihr habt Octavia überhaupt dabei), geht mit Octavia in der Gruppe zur Karte „Einsames Haus“.
<G-vec00038-002-s166><trigger.auslösen><en> If the dialogue with her doesn’t trigger automatically when we pick up the whip (assuming you have Octavia in your party), go with Octavia to the map “Lone House”.
<G-vec00038-002-s167><trigger.auslösen><de> Es gibt viele Variablen, die diese Fehlfunktion in Ihrem Personal Computer auslöst.
<G-vec00038-002-s167><trigger.auslösen><en> There are lots of variables that will trigger this malfunction in your Personal Computer.
<G-vec00038-002-s187><trigger.auslösen><de> Wir senden einen HTTP-Push-Request an SIGNL4, um einen Alarm auszulösen.
<G-vec00038-002-s187><trigger.auslösen><en> We send an HTTP Push request to SIGNL4 in order to trigger an alert.
<G-vec00038-002-s188><trigger.auslösen><de> Der Ansatz besteht daher darin, unterschiedliche Bereiche Ihrer vorhandenen Website aufzurufen, auf denen die Schnellansicht implementiert ist, die Schnellansicht auszulösen und die Ajax-URL zu erfassen, die durch die Webseite zum Laden der Schnellansichtsdaten oder -inhalte gesendet wurde.
<G-vec00038-002-s188><trigger.auslösen><en> The approach, therefore, is to visit different areas of your existing website where Quick View is implemented, trigger the Quick View, and capture the Ajax URL sent by the web page for loading the Quick View data or content.
<G-vec00038-002-s189><trigger.auslösen><de> Der Benutzer muss dann weitere Impulse über den Sensor setzen, um einen Befehl auszulösen.
<G-vec00038-002-s189><trigger.auslösen><en> Therefore the user has to give further input via the sensor to trigger a command.
<G-vec00038-002-s190><trigger.auslösen><de> Das geschah, um das Gleichgewicht zwischen den Ländern zu destabilisieren und eine Kette nahezu unvermeidlicher Ereignisse auszulösen, alle Teil desselben Planes.
<G-vec00038-002-s190><trigger.auslösen><en> This event was plotted to destabilize the equilibrium in all Countries and trigger a chain of events almost unavoidable
<G-vec00038-002-s191><trigger.auslösen><de> Geht dann zwei Schritte nach vorne um die Kugel rechts auszulösen.
<G-vec00038-002-s191><trigger.auslösen><en> Then take two steps forwards to trigger the boulder on the right.
<G-vec00038-002-s192><trigger.auslösen><de> Einzahlungen sind erforderlich, um die meisten Boni auszulösen, und deshalb ist es wichtig, dass dieser Prozess schnell und unkompliziert abläuft, um Sie wieder in Ihr Spiel zu bringen.
<G-vec00038-002-s192><trigger.auslösen><en> Deposits are required to trigger most bonuses, and so it is crucial that this process is fast and straightforward to get you back to your game.
<G-vec00038-002-s193><trigger.auslösen><de> Verwenden Sie eines der folgenden Verfahren, um eine manuelle Überprüfung auszulösen.
<G-vec00038-002-s193><trigger.auslösen><en> To trigger a scan manually, use one of the following procedures.
<G-vec00038-002-s194><trigger.auslösen><de> Demzufolge kommt der Schleimteppich zum Stehen und die Krankheitskeime haben viel Zeit, um in die darunterliegenden Körperzellen einzudringen und eine Infektion auszulösen.
<G-vec00038-002-s194><trigger.auslösen><en> The mucus layer therefore stops moving, and germs have plenty of time to make their way into neighboring cells and trigger an infection.
<G-vec00038-002-s195><trigger.auslösen><de> Die Farbpsychologie kann und muss dazu verwendet werden, bei Konsumenten die richtigen Reaktionen auszulösen, wenn du sicherstellen willst, dass deine Werbe- und Marketingmaterialien die Wirkung haben, die du dir vorstellst.
<G-vec00038-002-s195><trigger.auslösen><en> The psychology of color can and must be used to trigger the right responses from consumers if you want to ensure that your advertising and marketing materials will have the impact you want.
<G-vec00038-002-s196><trigger.auslösen><de> Konfigurieren Sie die Aktivität Ende oder den API-Aufruf, um die Parameter zu definieren und den Workflow Externes Signal auszulösen.
<G-vec00038-002-s196><trigger.auslösen><en> Configure the End activity or the API call to define the parameters and trigger the workflow External signal activity.
<G-vec00038-002-s197><trigger.auslösen><de> Klicke irgendwo neben einer Blase, um eine Explosion auszulösen und eine Kettenreaktion hervorzurufen.
<G-vec00038-002-s197><trigger.auslösen><en> Instructions Click anywhere near the bubble to trigger an explosion and create chain reaction.
<G-vec00038-002-s198><trigger.auslösen><de> e) Wild-Respins: Man muss 2 der Slot-Logo-Scatter-Symbole haben, um das Wild-Respin-Feature auszulösen, bei dem die Streuung in ein Wild-Symbol übergeht und sich mit jedem Respin-Effekt um eine Zeile darunter bewegt.
<G-vec00038-002-s198><trigger.auslösen><en> Wild Respins. One needs to have 2 of the slot logo scatter symbols to trigger the wild respin feature where the scatter turns into a wild and move one row below with every respin.
<G-vec00038-002-s199><trigger.auslösen><de> Ein Allergen ist ein köperfremder Stoff, der in der Lage ist, eine Immunantwort in Form einer Allergie auszulösen.
<G-vec00038-002-s199><trigger.auslösen><en> An allergen is a substance foreign to the body that is able to trigger an immune response in the form of an allergy.
<G-vec00038-002-s200><trigger.auslösen><de> Die Mindesteinzahlung bei Slot Hunter Spielbank beträgt € 20, um den Willkommensbonus auszulösen.
<G-vec00038-002-s200><trigger.auslösen><en> The minimum deposit at Slot Hunter Casino is $/€20 to trigger the Welcome Bonus.
<G-vec00038-002-s201><trigger.auslösen><de> Stoppe entweder in 2 nebeneinander liegenden Scattern oder 1 Scatter und einem angrenzenden Wild, um das Bonusspiel auszulösen.
<G-vec00038-002-s201><trigger.auslösen><en> Stop in either 2 adjacent scatters or 1 scatter and an adjacent wild to trigger the bonus game.
<G-vec00038-002-s202><trigger.auslösen><de> Lass die Milch in den Rachen fließen, um den Schluckreflex auszulösen.
<G-vec00038-002-s202><trigger.auslösen><en> Allow it to trickle back and trigger her swallowing reflex.
<G-vec00038-002-s203><trigger.auslösen><de> Die Steuereinheit kann beispielsweise von der erfindungsgemäßen Vorrichtung zum Ermitteln der aktuellen Position umfasst sein und beispielsweise aufgrund einer detektierten Bewegung (Ereignissteuerung) eine Ermittlung der aktuellen Position auszulösen.
<G-vec00038-002-s203><trigger.auslösen><en> The control unit may be included, for example, by the inventive apparatus for determining the current position, and for example due to a detected movement (event control) to trigger a determination of the current position. [0065]
<G-vec00038-002-s204><trigger.auslösen><de> Alle Sensorwerte können mit der dSS-App Zustände (benutzerdefinierte Zustände) oder mit P44-DSB Evaluator-Devices ausgewertet werden, um bei Schwellwerten Aktivitäten im dSS auszulösen.
<G-vec00038-002-s204><trigger.auslösen><en> All sensor values can be processed via dSS App States (user defined states) or using P44-DSB Evaluator Devices to trigger activities in the dSS when reaching threshold values.
<G-vec00038-002-s330><trigger.auslösen><de> Beschreibung Aktionssteuerungen lösen Aktionen aus, wenn sich der Status von Rocrail-Objekten ändert.
<G-vec00038-002-s330><trigger.auslösen><en> Description Action controls trigger actions when the states of Rocrail objects change.
<G-vec00038-002-s331><trigger.auslösen><de> Wenn Sie drei Truhen erhalten, lösen Sie eine zusätzliche Drehung aus.
<G-vec00038-002-s331><trigger.auslösen><en> When you get three chests you'll trigger a Rapids re-spins.
<G-vec00038-002-s332><trigger.auslösen><de> Drei Bonus-Scattersymbole auf den Walzen lösen das Nordlicht-Bonusspiel aus.
<G-vec00038-002-s332><trigger.auslösen><en> Three bonus scatter symbols on the reels trigger the Northern Lights Bonus Game.
<G-vec00038-002-s334><trigger.auslösen><de> Beim Hochklappen des Unterfahrschutzes sowie durch das Anheben des Trailers und die Verladung in den Taschenwagen lösen die schwenkenden Achsen eine Automatik aus, welche die Achsanschläge per Druckluft in die richtige Position bringt.
<G-vec00038-002-s334><trigger.auslösen><en> When folding up the underride guard as well by raising the trailer and loading onto the pocket wagon, the swivel axles trigger automation which uses compressed air to move the axle stops to the right position.
<G-vec00038-002-s335><trigger.auslösen><de> Denn auch wenn die Anzahl der Spammer im Vergleich zur Gesamtzahl der Nutzer vergleichsweise klein ist: Lösen diese überproportional viele Aktionen aus, kann das einen erheblichen, negativen Einfluss auf die verbleibenden Nutzer haben.
<G-vec00038-002-s335><trigger.auslösen><en> They can trigger a disproportionately high number of actions which negatively impact our users, even if the general number of spammers in the app amounts to just 0.2%.
<G-vec00038-002-s337><trigger.auslösen><de> Wir lösen durch Kommunikation Innovation im Unternehmen aus.
<G-vec00038-002-s337><trigger.auslösen><en> Through communication, we trigger innovation in the company.
<G-vec00038-002-s339><trigger.auslösen><de> Antikörper des Spenders lösen eine Immunreaktion gegen Leukozyten des Empfängers aus.
<G-vec00038-002-s339><trigger.auslösen><en> Antibodies of the donor trigger an immune reaction against leukocytes of the recipient.
<G-vec00038-002-s340><trigger.auslösen><de> Flashbacks gehören leider auch heute noch hin und wieder zu meinem Alltag und kleinste Anlässe lösen Panikattacken bei mir aus.
<G-vec00038-002-s340><trigger.auslösen><en> Unfortunately, flashbacks are still part of my everyday life now and again, and even the smallest events can trigger my panic attacks.
<G-vec00038-002-s341><trigger.auslösen><de> Erkennen Sie potenzielle Gefahren für die Kundenzufriedenheit und lösen Sie Botschaften aus oder benachrichtigen Sie den Kundenservice, um proaktiv zu reagieren.
<G-vec00038-002-s341><trigger.auslösen><en> Identify potential customer dissatisfaction and trigger messages or notify customer service representatives so they can proactively respond.
<G-vec00038-002-s342><trigger.auslösen><de> Sie lösen starken Juckreiz aus und sind nicht immer einfach zu behandeln.
<G-vec00038-002-s342><trigger.auslösen><en> They trigger severe itching and are not always easy to deal with.
<G-vec00038-002-s343><trigger.auslösen><de> Gleichzeitig lösen sie nicht nur Fettverbrennungsprozesse aus, sondern wirken sich auch positiv auf die inneren Organe aus.
<G-vec00038-002-s343><trigger.auslösen><en> At the same time, they trigger not only fat burning processes, but also positively affect internal organs.
<G-vec00038-002-s344><trigger.auslösen><de> Lösen Sie benutzerdefinierte Workflows in Zoho CRM aus, um neue Kontakte automatisch in Ihren Vertriebsprozess zu integrieren.
<G-vec00038-002-s344><trigger.auslösen><en> Trigger custom workflows in Zoho CRM to automatically incorporate new contacts into your sales process.
<G-vec00038-002-s345><trigger.auslösen><de> Bei dem Versuch, den Q2 zu „taggen“, lösen Bewegungsmelder und Sicherheitskameras einen Alarm aus und hindern so die Gäste daran.
<G-vec00038-002-s345><trigger.auslösen><en> If any attempt is made to “tag” the Q2, motion sensors and security cameras trigger an alarm and keep visitors back.
<G-vec00038-002-s346><trigger.auslösen><de> Beim ersten Anzeichen einer Gefahr lösen die zuverlässigen Brandmeldesysteme einen koordinierten Alarm aus.
<G-vec00038-002-s346><trigger.auslösen><en> At the first sign of danger, our reliable fire protection systems trigger a coordinated alarm and extinguishing systems are activated.
<G-vec00038-002-s347><trigger.auslösen><de> Starke Skorpion Aspekte lösen intensive Energien aus.
<G-vec00038-002-s347><trigger.auslösen><en> Strong scorpion aspects trigger intense energies.
<G-vec00038-002-s029><unleash.auslösen><de> Bewaffnete Konflikte, Naturkatastrophen oder technologische Katastrophen können innerhalb kurzer Zeit humanitäre Krisen auslösen und das Leben von tausenden Menschen gefährden.
<G-vec00038-002-s029><unleash.auslösen><en> © HOPE´87 Armed conflicts and natural or technological disasters can unleash humanitarian crises in a short time and endanger the life of thousands of people.
<G-vec00038-002-s030><unleash.auslösen><de> In Butterfly Bash ist es deine Aufgabe mittels eines Klicks eine Veränderung zu bewirken, sodass du durch die Raupen eine Kettenreaktion auslösen kannst und dadurch Extrapunkte bekommst.
<G-vec00038-002-s030><unleash.auslösen><en> In Butterfly Bash, you need to click to see the change happen, and you can take advantage of different crawlers to unleash chain reactions that will deliver extra points.
<G-vec00038-002-s031><unleash.auslösen><de> Eine Gesellschaft der Zukunft muss begreifen, dass der Flügelschlag eines Schmetterlings Orkane auslösen kann; muss aber auch begreifen, dass Gewalt am anderen Ende der Welt, ebenso Orkane im eigenen Umfeld entstehen lassen kann.
<G-vec00038-002-s031><unleash.auslösen><en> The society of the future must realize that the beat of a butterfly’s wing can unleash hurricanes; but it must also realize that violence at the other end of the world can equally give rise to hurricanes in our own back yard.
<G-vec00038-002-s032><unleash.auslösen><de> Noch weitgehend unklar ist, welche neuen Technologien über die nächsten 3-10 Jahre Erfolg haben oder gar eine weitere technologische Revolution auslösen werden.
<G-vec00038-002-s032><unleash.auslösen><en> At this time, it is not clear at all which new technologies will be successful in the next 3-10 years or even unleash a technological revolution.
<G-vec00038-002-s033><unleash.auslösen><de> Mit eigenständigen Makro-Tasten auf dem OMEN 17 Notebook kannst du in Sekundenschnelle Makros auslösen und hast so einen entscheidenden strategischen Vorteil.
<G-vec00038-002-s033><unleash.auslösen><en> With Independent macro keys on the OMEN X Laptop, you can unleash macros in seconds for a fierce strategic advantage.
<G-vec00038-002-s034><unleash.auslösen><de> „Ein einziger eingeschleppter Samen kann Katastrophen auslösen“, sagt Walter Bustos, langjähriger Direktor des Nationalparks Galapagos, der gemeinsam mit der ABG, der Agentur für Kontroll- und Quarantänemaßnahmen auf den Inseln, die verschiedenen Aktivitäten des FEIG ausführt.
<G-vec00038-002-s034><unleash.auslösen><en> "A single imported seed can unleash a disaster," says Walter Bustos, long-time director of Galapagos National Park, who, together with ABG, the Agency for Control and Quarantine Measures on the islands, is responsible for the various activities of the FEIG.
<G-vec00038-002-s035><unleash.auslösen><de> Die verlängerte Agonie der Gesellschaft des Kapitals wird eine undenkbare Serie des Entsetzen und der Lüge auslösen, mehr als die jenige des ersten und zweiten Weltkrieges.
<G-vec00038-002-s035><unleash.auslösen><en> The prolonged agony of capitalist society will unleash an unimaginable series of horrors and lies, even beyond those of the First and Second World Wars.
<G-vec00038-002-s036><unleash.auslösen><de> Naturgeräusche können Empfindungen auslösen, die unseren Pulsschlag senken sowie Körper und Geist nachhaltig entspannen.
<G-vec00038-002-s036><unleash.auslösen><en> Natural sounds can unleash sensations that lower our pulse rates and provide lasting relaxation to our bodies and spirits.
<G-vec00038-002-s038><unleash.auslösen><de> Aber Kopenhagen ist auch eine historische Gelegenheit, den Fahrplan für eine weltweite kohlenstoffarme Gesellschaft festzulegen und damit eine Welle von Innovationen auszulösen, die unseren Volkswirtschaften durch die Schaffung neuer, nachhaltiger Wachstumssektoren und neuer „grüner“ Arbeitsplätze neue Impulse geben können.
<G-vec00038-002-s038><unleash.auslösen><en> But Copenhagen is also an historic opportunity to draw the roadmap to a global low-carbon society, and in so doing unleash a wave of innovation that can revitalise our economies through the creation of new, sustainable growth sectors and "green collar" jobs.
<G-vec00038-002-s046><unleash.auslösen><de> Nach ihrem waghalsigen Plan haben sie vor, große Mengen legal gedruckter Banknoten in Umlauf zu bringen und so eine Inflation auszulösen, die die Bevölkerung gegen die Regierung aufwiegeln soll.
<G-vec00038-002-s046><unleash.auslösen><en> They are coming up with the daring plan of emitting large quantities of legally printed banknotes in order to unleash an inflation, which might in turn upset the population against the government.
<G-vec00098-002-s019><induce.auslösen><de> • Im Falle der versehentlichen Aufnahme, Pflanzenöl schlucken lassen (1 bis 3 Esslöffel), und, wenn möglich, Brechreiz auslösen.
<G-vec00098-002-s019><induce.auslösen><en> • In the event of accidental swallowing ingest vegetable oil (1 to 3 tablespoons), do not induce vomiting.
<G-vec00098-002-s020><induce.auslösen><de> Wenn ein Fiberskop durch die Nasenhöhle eines schlafenden Patienten eingeführt wird, um den Pharynx auf Obstruktionen zu untersuchen, kann dies bei einem hohen Prozentsatz der Patienten mit entsprechender Vorgeschichte das Schnarchen auslösen.
<G-vec00098-002-s020><induce.auslösen><en> The passing a fiberoptic endoscope through a sleeping patient's nasal cavity to assess pharyngeal structures for evidence of obstruction may induce the preexisting snoring in a high percentage of patients.
<G-vec00098-002-s021><induce.auslösen><de> Thrombozyten können also eine proinflammatorische Reaktion von Endothelzellen auslösen.
<G-vec00098-002-s021><induce.auslösen><en> Platelets are thus able to induce a proinflammatory reaction of endothelial cells.
<G-vec00098-002-s022><induce.auslösen><de> Antwort: Übermässiger Alkoholkonsum kann einen Anfall von Gicht auslösen.
<G-vec00098-002-s022><induce.auslösen><en> Answer: Excessive alcohol consumption can induce an attack of gout.
<G-vec00098-002-s023><induce.auslösen><de> Die ganz legale Kontamination könnte in Frankreich Zehntausende, im schlimmsten Fall vielleicht Hunderttausende Krebsfälle auslösen (nicht gerechnet andere, nicht krebsartige Erkrankungen und übertragene Schädigungen des Erbmaterials).
<G-vec00098-002-s023><induce.auslösen><en> As regard to the French territory proper this legal contamination could induce tens of thousands of cancers possibly hundreds of thousands in the worst situation (without taking into account others non cancerous pathologies and transmitted genetic damages).
<G-vec00098-002-s024><induce.auslösen><de> Laut von Gizmodo gesammelten Berichten enger Freunde waren „Drogen, die bei Frauen sexuelles Verhalten auslösen“ so etwas wie sein Heiliger Gral.
<G-vec00098-002-s024><induce.auslösen><en> His holy grail, according to reports from close friends reported by Gizmodo, was "drugs that induce sexual behaviour in women".
<G-vec00098-002-s025><induce.auslösen><de> Kriminelle, verleumderische und gewalttätige Handlungen auslösen oder anstacheln oder generell gegen das Gesetz, allgemein anerkannte moralische und ethische Standards und die öffentliche Ordnung verstoßen.
<G-vec00098-002-s025><induce.auslösen><en> – Induce, incite or encourage criminal, slanderous and violent acts or, in general, that are against the Law, generally accepted moral and ethical standards, and public order.
<G-vec00098-002-s026><induce.auslösen><de> Natriumglutamat kann manchmal Kopfschmerzen auslösen.
<G-vec00098-002-s026><induce.auslösen><en> MSG can sometimes induce headaches.
<G-vec00098-002-s027><induce.auslösen><de> Pestizide sind giftige Substanzen, zumindest vier oder fünf davon Krebs auslösen.
<G-vec00098-002-s027><induce.auslösen><en> Pesticides are toxic substances, at least, four or five of them induce cancer.
<G-vec00098-002-s028><induce.auslösen><de> Mit seinem mächtigen Schrei kann er in anderen Kreaturen Angst auslösen.
<G-vec00098-002-s028><induce.auslösen><en> With its mighty roar, it can induce fear in opposing creatures.
<G-vec00098-002-s029><induce.auslösen><de> Rechne damit das komplette Amnesia-Paket verpasst zu bekommen, bestehend aus einer starken, psychotropen Wirkung, die einen euphorischen Ansturm auslöst.
<G-vec00098-002-s029><induce.auslösen><en> Expect to get the complete Amnesia package consisting of strong, psychoactive effects that will induce a euphoric rush.
<G-vec00098-002-s030><induce.auslösen><de> Für unerfahrene Züchter wird es hilfreich sein zu lernen, wie man mit Salz Erbrechen auslöst.
<G-vec00098-002-s030><induce.auslösen><en> It will be useful for inexperienced breeders to learn how to induce vomiting with salt.
<G-vec00098-002-s031><induce.auslösen><de> Traditionell wird von der Wurzel gesagt, daß sie lebendige und manchmal klare Träume auslöst, an die man sich nach dem Aufwachen erinnert.
<G-vec00098-002-s031><induce.auslösen><en> Traditionally, the root is reputed to induce vivid and sometimes lucid dreams that are remembered upon waking.
<G-vec00098-002-s032><induce.auslösen><de> Es besteht jedoch kein Risiko, dass das Virus sich vermehrt, im Körper ausbreitet oder eine dauerhafte Infektion auslöst.
<G-vec00098-002-s032><induce.auslösen><en> At the same time, there is no risk that the virus will replicate, spread throughout the body or induce a persistent infection.
<G-vec00098-002-s033><induce.auslösen><de> Weiterhin sollte untersucht werden, ob CF und die isolierten Proteine in der Lage sind, in den Tumorzellen Apoptose auszulösen.
<G-vec00098-002-s033><induce.auslösen><en> In addition we focused on the question, if CF and the isolated proteins are able to induce apoptosis in the tumor cells.
<G-vec00098-002-s034><induce.auslösen><de> Dann werden sie (Dunkle System) versuchen, diese Horrorbilder in eurem Gehirn zu reaktivieren, um eine "schrecklich lähmende Angst" auszulösen, um euch in eurer Tätigkeit aufzuhalten.
<G-vec00098-002-s034><induce.auslösen><en> It is then that they will try to activate these horror images in your brain to induce a "horrible paralyzing fear" in order to stop you.
<G-vec00098-002-s035><induce.auslösen><de> Die Hauptwirkung der afrikanischen Traumwurzel ist es, lebendige und luzide Träume auszulösen, sowie die Qualität des Schlafes zu verbessern.
<G-vec00098-002-s035><induce.auslösen><en> The main effect of African dream root is to induce vivid and lucid dreams, as well as enhancing the quality of sleep.
<G-vec00196-002-s057><cause.auslösen><de> Aufgrund der kleinen Größe dringen die Partikel bis in die Blutbahnen vor und können schwerheilbare Krankheiten auslösen.
<G-vec00196-002-s057><cause.auslösen><en> Due to their small sizes, the particles penetrate deeply into the bloodstream and can cause serious diseases.
<G-vec00196-002-s058><cause.auslösen><de> Im Vorfeld dieser Auseinandersetzung sollten wir daran erinnern, dass Frankreich ein Land ist, wo die Frauen nicht schuldig gesprochen werden für das Begehren, das sie auslösen; ein Land, in dem Individuen leben und nicht «Gemeinschaften»; ein Land, wo man, aus Respekt vor Andersdenkenden und um den inneren Frieden aufrechtzuerhalten, seinen Glauben nicht wie ein Banner vor sich her trägt.
<G-vec00196-002-s058><cause.auslösen><en> In the run-up to this debate, we should recall that France is a country where women are not blamed for the desire they cause; a country where individuals live and not “communities”; a country where, out of reference to dissenters and for the purpose of preserving inner peace, one does not carry one’s faith as a banner in front of oneself.
<G-vec00196-002-s059><cause.auslösen><de> Sturmwind über 75km/h: Kann Schäden an stehenden Objekten im Freien auslösen.
<G-vec00196-002-s059><cause.auslösen><en> Storm winds over 75km/h: Can cause damage to objects standing outdoors.
<G-vec00196-002-s060><cause.auslösen><de> Psychischer Stress: Wissenschaftler vermuten, das Stress Krebs auslösen kann.
<G-vec00196-002-s060><cause.auslösen><en> Psychological stress: Scientists suspect that stress can cause cancer.
<G-vec00196-002-s061><cause.auslösen><de> Die folgende Tabelle beschreibt, wann Datenüberprüfungsfehler das Überspringen eines Datensatzes oder eines Felds auslösen.
<G-vec00196-002-s061><cause.auslösen><en> The following table describes when data validation failures cause a record or a field to be skipped.
<G-vec00196-002-s062><cause.auslösen><de> Durch Fixierung des Handgelenks werden Stellungen vermieden, welche das Taubheitsgefühl (hauptsächlich nachts) auslösen.
<G-vec00196-002-s062><cause.auslösen><en> By immobilizing the wrist, movements of the hand will be avoided, which cause the numb feeling (mainly at night).
<G-vec00196-002-s063><cause.auslösen><de> Wahre Freude konnten wir wie immer auch bei Video- und Filmproduzenten auslösen, vor allem bei denjenigen, die ihre Videos in mehreren Sprachen anbieten.
<G-vec00196-002-s063><cause.auslösen><en> We could also cause real excitement by video and movie producers, especially those who offer their videos in several languages.
<G-vec00196-002-s064><cause.auslösen><de> Zur Schmerzlinderung werden oft Opioide eingesetzt, die jedoch Nebenwirkungen wie Verstopfung auslösen können, die ebenfalls einer Behandlung bedürfen.
<G-vec00196-002-s064><cause.auslösen><en> Opioids are often used to relieve pain but can cause side effects, such as constipation, that also require treatment.
<G-vec00196-002-s065><cause.auslösen><de> Und das, obwohl es im Falle besonderer Sensibilität anderen Fremdstoffen gegenüber sogar lebensbedrohliche Reaktionen auslösen kann.
<G-vec00196-002-s065><cause.auslösen><en> And this happens, despite the fact that it can even cause life-threatening reactions in those cases where there is a particular sensitivity towards other foreign substances.
<G-vec00196-002-s066><cause.auslösen><de> Nickel kann Allergien und Hautirritationen auslösen.
<G-vec00196-002-s066><cause.auslösen><en> Nickel can cause allergies and skin irritation.
<G-vec00196-002-s067><cause.auslösen><de> Wir können dabei helfen, Prozessschwächen zu identifizieren und zu priorisieren, damit Sie sich denjenigen Faktoren widmen können, welche die Problematiken auslösen.
<G-vec00196-002-s067><cause.auslösen><en> We can help to identify process weaknesses and prioritize them so you focus on the parameters most likely to cause problems.
<G-vec00196-002-s068><cause.auslösen><de> Es gibt eine Vielzahl krankmachende wie auch nicht krankmachende Bakterien, die vom Tier auf den Menschen übertragen werden und schwere Krankheiten auslösen können.
<G-vec00196-002-s068><cause.auslösen><en> Some pathogenic species are zoonosis pathogens, ie bacteria which are transmitted from animals to humans and can cause serious diseases.
<G-vec00196-002-s069><cause.auslösen><de> Kurze, gelockte Frisuren zu kreieren muss keinen Druck auslösen, stelle einfach sicher, dass Du die richtigen Tools zur Hand hast.
<G-vec00196-002-s069><cause.auslösen><en> Getting short curly hairstyles doesn’t have to cause hassle, just make sure you’ve got the right tools to hand.
<G-vec00196-002-s070><cause.auslösen><de> Epidemiologische Untersuchungen zeigen, dass Campylobacter- und Salmonella-Bakterien durch den Verzehr kontaminierter tierischer Nahrungsmittel Erkrankungen auslösen können.
<G-vec00196-002-s070><cause.auslösen><en> Epidemiological studies show that campylobacter and salmonella bacteria can cause diseases following consumption of contaminated animal-based foods.
<G-vec00196-002-s071><cause.auslösen><de> Steroide, die sehr Androgene wie Dianabol oder Testosteron sind auslösen mehr unerwünschte Wirkungen.
<G-vec00196-002-s071><cause.auslösen><en> Steroids that are very Androgenic such as Dianabol or Testosterone cause more adverse effects.
<G-vec00196-002-s072><cause.auslösen><de> Um abzuschätzen, ob sie eine Epidemie oder sogar Pandemie auslösen könnten, versuchen die Wissenschaftler herauszufinden, ob sie von einer Person zu einer anderen übertragen werden können.
<G-vec00196-002-s072><cause.auslösen><en> To determine whether it might cause an epidemic or even a pandemic, the researchers try to find out if it can be passed from one person to another.
<G-vec00196-002-s073><cause.auslösen><de> Die Möglichkeiten für einen wirklichen Zusammenbruch der Ökonomie, für einen unvorhergesehenen militärischen Konflikt, innenpolitisches Chaos oder Kriegsrecht sind real; jedes von dem könnte einen globalen Zusammenbruch auslösen, wenn es in geeigneter Weise positioniert würde.
<G-vec00196-002-s073><cause.auslösen><en> The possibility is real for economic collapse, unprecedented military conflict, internal political chaos, or martial law—any one of which could cause global disruption if positioned appropriately.
<G-vec00196-002-s074><cause.auslösen><de> Milben selbst sind zwar weder gefährlich noch übertragen sie Krankheiten, wohl aber können ihre Ausscheidungen allergische Reaktionen auslösen.
<G-vec00196-002-s074><cause.auslösen><en> Although mites themselves are not dangerous or transmit diseases, their excretions can cause allergic reactions.
<G-vec00196-002-s075><cause.auslösen><de> Als Ingenieur wurde May vor allem dafür bekannt, dass er die Ursache des „Alpha-Partikel-Problems“ identifiziert hatte, das die Zuverlässigkeit integrierter Schaltungen beeinträchtigte, da die Gerätemerkmale eine kritische Größe erreichten, bei der ein einzelnes Alphateilchen den Zustand eines gespeicherten Wertes ändern und ein Single Event Upset auslösen konnte.
<G-vec00196-002-s075><cause.auslösen><en> As an engineer, May was most noted for having identified the cause of the "alpha particle problem", which was affecting the reliability of integrated circuits as device features reached a critical size where a single alpha particle could change the state of a stored value and cause a single event upset.
<G-vec00196-002-s204><induce.auslösen><de> Die Wirkung von Shiva Shanti löst einen Zustand tiefer körperlicher Entspannung aus, was ein stressfreies Raucherlebnis ermöglicht.
<G-vec00196-002-s204><induce.auslösen><en> The effects of Shiva Shanti induce a state of deep physical relaxation allowing a stress-free smoking experience.
<G-vec00196-002-s205><induce.auslösen><de> Die einmalige Genetik der Sorte löst ein beruhigendes und sedierendes High aus, dass Dich jedoch nicht an die Couch fesselt.
<G-vec00196-002-s205><induce.auslösen><en> This strain’s unique genetics induce a high that is calming and sedating, but will not lock you to the couch.
<G-vec00196-002-s206><induce.auslösen><de> Zwar löst dieses Kraut nicht direkt Schlaf aus, aber es hilft auf jeden Fall, den Körper zu entspannen, während Angst verringert und geistige Klarheit geschaffen wird.
<G-vec00196-002-s206><induce.auslösen><en> While this herb does not directly induce sleep, it certainly does help the body relax while reducing anxiety and increasing mental clarity.
<G-vec00196-002-s021><instigate.auslösen><de> Jesus begann… “Clare, dies sind Zeiten großer Gefahren, wo eine einzige falsche Bewegung einen Bürgerkrieg auslösen könnte.
<G-vec00196-002-s021><instigate.auslösen><en> Amen Jesus began… “Clare, these are times of great peril, where one wrong move could instigate a civil war.
<G-vec00196-002-s040><instigate.auslösen><de> Wenn Sie Ihren Mitarbeitern das Wissen vermitteln, diese Anzeichen von Phishing zu erkennen, werden sie seltener auf die schädlichen Anhänge oder Links klicken, die den Ransomware-Downloadprozess auslösen.
<G-vec00196-002-s040><instigate.auslösen><en> By teaching your employees to spot these signs of phishing, they are less likely to click the malicious attachments or links that instigate the ransomware download process.
<G-vec00196-002-s024><provoke.auslösen><de> Studien des britischen Biologen und Medienforschers David Kirby belegen, dass Spielfilme mit MINT-Themen im Zentrum selbst Wissenschaftler zu Forschungs- und Entwicklungsprojekten inspirieren, wissenschaftliche Kontroversen auslösen und die Bereitschaft zu politischem Engagement fördern können.
<G-vec00196-002-s024><provoke.auslösen><en> Studies by British biologist and media scholar David Kirby attest to the fact that movies with STEM subjects at their core can even inspire scientists to embark on research and development projects, provoke scientific controversies and foster a willingness for political involvement.
<G-vec00196-002-s025><provoke.auslösen><de> Dieses Werk offenbart die Freude, wenn man sein Parfum auf der Haut riecht, und das einmalige Gefühl, das ein Duft auslösen kann.
<G-vec00196-002-s025><provoke.auslösen><en> This opus is a declaration of pleasure, like the sensation of perfume on the skin or the singular emotion a scent can provoke.
<G-vec00196-002-s026><provoke.auslösen><de> In diesem Fall können pathogene Bakterien in ihn eindringen und einen Entzündungsprozess auslösen - Endometritis.
<G-vec00196-002-s026><provoke.auslösen><en> In this case, pathogenic bacteria can get into it and provoke an inflammatory process - endometritis.
<G-vec00196-002-s027><provoke.auslösen><de> Stets wird die Finsternis die Wesen bedrücken, und stets wird Licht in ihnen ein Wohlbehagen auslösen; doch immer muss das Licht begehrt werden.
<G-vec00196-002-s027><provoke.auslösen><en> Darkness will always depress the beings, and light will always provoke a sense of well-being in them; but the light must always be desired.
<G-vec00196-002-s028><provoke.auslösen><de> „Eine Störung des autonomen Nervensystems aufgrund von Stress kann Migräneanfälle auslösen”, sagt Alexander Olsen von der Norwegischen Universität für Wissenschaft und Technik (NTNU).
<G-vec00196-002-s028><provoke.auslösen><en> “Disruption of the autonomous nervous system as a result of stress can provoke migraine attacks,” says Alexander Olsen of the Norwegian University of Science and Technology (NTNU).
<G-vec00196-002-s029><provoke.auslösen><de> Deshalb bin ich mir nicht so sicher, ob wir aus dieser Identitätskrise, die ein Austritt Großbritanniens auslösen würde, gestärkt hervorgehen würden.
<G-vec00196-002-s029><provoke.auslösen><en> That’s why I’m not so sure that we would emerge strengthened from the identity crisis Britain’s exit would provoke.
<G-vec00196-002-s030><provoke.auslösen><de> Es wurde angenommen, dass ihre Brühe in fast 100% der Fälle früh eine Fehlgeburt auslösen könnte.
<G-vec00196-002-s030><provoke.auslösen><en> It was believed that her broth could provoke miscarriage early in almost 100% of cases.
<G-vec00196-002-s031><provoke.auslösen><de> Medikamente in flüssiger Form oder in Form von Tabletten können eine Allergie auslösen.
<G-vec00196-002-s031><provoke.auslösen><en> Medication in liquid form or in the form of tablets can provoke an allergy.
<G-vec00196-002-s032><provoke.auslösen><de> Eine versehentliche Selbstinjektion kann die klinischen Anzeichen einer Hypoglykämie und in seltenen Fällen allergische Reaktionen bei sensibilisierten Personen auslösen.
<G-vec00196-002-s032><provoke.auslösen><en> Accidental self-injection can provoke clinical signs of hypoglycaemia and there is a low possibility of an allergic reaction in sensitised individuals.
<G-vec00196-002-s033><provoke.auslösen><de> Glutenprotein, das in der Kruppe enthalten ist, kann sich direkt auf den Verlauf der Schwangerschaft negativ auswirken, nämlich - es kann Schwellungen verursachen und eine Toxikose auslösen.
<G-vec00196-002-s033><provoke.auslösen><en> Gluten protein, contained in the croup, can have a negative effect directly on the very course of pregnancy, namely - it can cause swelling and provoke a toxicosis.
<G-vec00196-002-s034><provoke.auslösen><de> Separatistische Bewegungen können somit durchaus Kettenreaktionen auslösen und immer kleinere Einheiten umfassen, die künftig selbstständig agieren wollen.
<G-vec00196-002-s034><provoke.auslösen><en> Separatist movements can thus easily provoke chain reactions and comprise smaller and smaller entities, which want to become independent in the near future.
<G-vec00196-002-s035><provoke.auslösen><de> Theoretisch könnte Russland den Schmuggel vom Militärgut nach Syrien mithilfe der zivilen Schiffe einrichten, aber bereits die erste Frachtkontrolle könnte einen internationalen Skandal auslösen, darum wurde für die Seekonvois die Marine eingesetzt, und nicht nur die Schwarzmeerflotte, sondern auch die Flotte „anderer Seen“.
<G-vec00196-002-s035><provoke.auslösen><en> Theoretically, Russia could have established the military smuggling to Syria with the help of civil ships, but the first freight inspection would provoke an international scandal – that is why the Navy’s warships are used for the convoys.
<G-vec00196-002-s036><provoke.auslösen><de> Die vergangenen, aber auch die aktuellen Erfahrungen in Polen beweisen, daß eine solche Politik gewalttätige soziale Explosionen auslösen kann, die die Durchsetzung solch einer Politik gefährden.
<G-vec00196-002-s036><provoke.auslösen><en> The past (and even present) experience of Poland is proof that this kind of policy can provoke violent social explosions that threaten its application.
<G-vec00196-002-s037><provoke.auslösen><de> Wenn Sie überzeugt sind, dass keine Erfahrungen gesammelt wurden oder dass keine Situation das Auftreten von Blutegeln im Schlaf hätte auslösen können, bedeutet dies, dass Sie diesem Zeichen mehr Aufmerksamkeit schenken sollten.
<G-vec00196-002-s037><provoke.auslösen><en> If you are convinced that no experience has been gained or that no situation could provoke the appearance of leeches in your sleep, it means that you should pay more attention to this sign.
<G-vec00196-002-s038><provoke.auslösen><de> Aufgrund ihrer Widerhaken verbleiben diese Getreideähren im Körper des Tieres und können unter Umständen in die Blutbahn des Tieres gelangen und schwerwiegende Symptome auslösen.
<G-vec00196-002-s038><provoke.auslösen><en> Due to their barbed hooks these heads of crops remain in the body of the animal and may possibly reach the bloodstream of the animal and provoke grave symptoms.
<G-vec00196-002-s039><provoke.auslösen><de> Es konnte gezeigt werden, dass eine Sauerstoffsättigung von 15 30 % über den Zeitraum von vier Stunden sowie die Histamin und Endotoxin von E. coli Veränderungen in den Perfusionsparametern und in der Gewebestruktur auslösen.
<G-vec00196-002-s039><provoke.auslösen><en> It was possible to show that an oxygen deficiency between 15 30 % for 4 hours and agents like histamine and E. coli endotoxin provoke changes in perfusion parameters and alterations in tissue structure.
<G-vec00196-002-s040><provoke.auslösen><de> Um zu verstehen, wie E-Mail in Zendesk Support funktioniert, werfen Sie einen genaueren Blick auf E-Mail-Benachrichtigungen, weil sie die für den Kundenservice notwendigen Informationen vermitteln und die damit verbundenen Aktionen auslösen.
<G-vec00196-002-s040><provoke.auslösen><en> It’s helpful to begin understanding how email works in Zendesk Support by focusing on email notifications because they communicate the information and provoke the actions involved in a customer service interaction.
<G-vec00196-002-s041><provoke.auslösen><de> Es ist ratsam, ein heißes Bad in den ersten zwei Tagen nach der Impfung zu vermeiden: Wenn zu diesem Zeitpunkt das Baby beginnt, die mit der Impfung verbundene Temperatur zu erhöhen, und Sie es nicht bemerkt haben, kann ein heißes Bad Fieber auslösen.
<G-vec00196-002-s041><provoke.auslösen><en> It is advisable to avoid a hot bath in the first two days after the vaccination: if at this point the baby starts to raise the temperature associated with the vaccination, and you have not noticed, a hot bath can provoke fever.
<G-vec00196-002-s042><provoke.auslösen><de> Gleichzeitig wurden bei der Datenanalyse andere Faktoren berücksichtigt, die eine Depression auslösen könnten.
<G-vec00196-002-s042><provoke.auslösen><en> At the same time, other factors that could provoke depression were taken into account in the data analysis.
<G-vec00196-002-s043><provoke.auslösen><de> Nachhaltigkeit scheint eine starke Reaktion auszulösen.
<G-vec00196-002-s043><provoke.auslösen><en> Sustainability seems to provoke a strong reaction.
<G-vec00196-002-s044><provoke.auslösen><de> Ein QT-Intervall kann mithilfe eines Elektrokardiogramms (EKG) gemessen und als (unvollkommener) Biomarker verwendet werden, um das Risiko eines Arzneimittels, Arrhythmie auszulösen, zu bewerten.
<G-vec00196-002-s044><provoke.auslösen><en> A QT interval can be measured using an electrocardiogram (ECG) and can be used as an (imperfect) biomarker to assess the risk that a medicine may provoke arrhythmia.
<G-vec00196-002-s045><provoke.auslösen><de> Diese Präzisierung ist umso wichtiger, als es das offensichtliche taktische Ziel einer solchen »Partei« ist, zum Zerfall der großen Koalition beizutragen, die derzeit die politische Mitbestimmung im neoliberalen Europa ausübt, also einen Konflikt innerhalb der sozialdemokratischen Tradition auszulösen (was »von innen« möglich ist, wie der Aufstieg von Jeremy Corbyn in der britischen Labour Party zeigt).
<G-vec00196-002-s045><provoke.auslösen><en> This point is all the more important that the clear tactical objective of such a ‘party’ is to contribute to the breaking up of the grand coalition that at present is politically co-managing neoliberal Europe and thus to provoke conflict at the heart of the social democratic tradition (if possible ‘inside it’, as in the rise of Jeremy Corbyn within Britain’s Labour Party).
<G-vec00196-002-s046><provoke.auslösen><de> Vielleicht kann jemanden interessieren, wie sich dabei diese Römblein, Parallelogramme, Dreiecke und andere rein geometrische Bilderchen ändern oder drehen, aber all diese Empfehlungen zur pseudowissenschaftlichen Rettung der SRT an die hoffärtige INSTRUKTION "Wie das rechte Ohr von der linken Ferse, das Bein zweimal um den Hals gewickelt, zu kratzen ist und wie dieselben Empfindungen (sie soll man bloß im Voraus klären) auch beim normalen Mensch auszulösen sind" (der sein Bedürfnis auf natürliche Weise befriedigt).
<G-vec00196-002-s046><provoke.auslösen><en> Possible, someone could be interested how pure geometric drawings (a rhombus, a parallelogram, a triangle etc.) can be turned or transformed to pseudo-scientifically rescue the SRT. But these recommendations resemble the proud INSTRUCTIONS "how one can scratch the right-hand ear with the left-hand heel, when this leg is twice wound round the neck, and can provoke the same sensations (they must be elucidated beforehand!) as the normal man (which satisfies his requirements in more natural manner).
<G-vec00196-002-s047><provoke.auslösen><de> Damals wurde dieses Mittel im Zusammenhang mit Vong-Biotechnologie verwendet, um abnormen Pflanzenwuchs auszulösen.
<G-vec00196-002-s047><provoke.auslösen><en> At that time, the substance had been used in conjunction with Vong biotechnology to provoke abnormal plant growth.
<G-vec00196-002-s048><provoke.auslösen><de> In manchen Fällen benötigt es nicht mehr als 60 Gramm Erdnüsse oder Schokolade, um einen Herpesausbruch auszulösen.
<G-vec00196-002-s048><provoke.auslösen><en> Sometimes, not more than 60 g. of peanuts or chocolate or just a minimal amount of gelatine are required in order to provoke an outbreak of herpes.
<G-vec00196-002-s115><provoke.auslösen><de> Auch lösen sie – im Gegensatz zu embryonalen Zellen – keine ethischen Kontroversen aus«, sagt Dr. Julia Neubauer, Biologin am Fraunhofer IBMT.
<G-vec00196-002-s115><provoke.auslösen><en> Unlike embryonic stem cells, they don’t provoke any ethical controversies either,” says Dr. Julia Neubauer, biologist at Fraunhofer IBMT.
<G-vec00196-002-s116><provoke.auslösen><de> Die von uns entwickelten Nanoteilchen besitzen eine Reihe von Vorteilen als Arzneimittelträger; sie lösen keine toxische Wirkung aus, sie sind hochstabil, sie setzen das Arzneimittel über eine längere Zeitspanne hinweg frei und sie können zelluläre Schranken überwinden.
<G-vec00196-002-s116><provoke.auslösen><en> The nanoparticles we have developed have a number of advantages as drug carriers; they do not provoke a toxic effect, they are highly stable, they release the drug over a sustained period, and they can overcome cellular barriers.
<G-vec00196-002-s117><provoke.auslösen><de> In diesem Fall lösen die Graphiken ein Neuzeichnen aus.
<G-vec00196-002-s117><provoke.auslösen><en> In this case, the graphics provoke redrawing.
