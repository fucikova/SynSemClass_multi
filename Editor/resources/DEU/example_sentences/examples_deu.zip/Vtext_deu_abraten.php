<G-vec00251-002-s025><discourage.abraten><de> Sie hatten auch ein paar schlecht begründeten Folien, die ihren Kunden von DITA Implementierungen abraten sollten, mit auf einer Rundreise durch Europa genommen hatten.
<G-vec00251-002-s025><discourage.abraten><en> They also took some poorly founded slides meant to discourage DITA implementations on a roadshow through Europe.
<G-vec00251-002-s011><dissuade.abraten><de> Der Deutsche ist alles-mächtig, und nichts kann es abraten, sein Deportationsunternehmen weiterzuführen, das sich auf Millionen europäische Juden bezieht.
<G-vec00251-002-s011><dissuade.abraten><en> The German is all-powerful and nothing can dissuade it to continue its company of deportation which relates to million Jews of Europe.
