<G-vec00003-001-s019><wait.abwarten><de> Mit dem MACH4, wirst du es nicht mehr abwarten können, endlich ins Wasser zu kommen.
<G-vec00003-001-s019><wait.abwarten><en> With the MACH4, you won’t be able to wait to get into the water!
<G-vec00003-001-s020><wait.abwarten><de> Wenn du in unserem beispielhaften Kombi-Tipp zwei Spiele versicherst und bereits die erste Partie richtig getippt wurde, eine aber schon falsch ausgegangen ist, musst du nicht mehr das dritte Match abwarten.
<G-vec00003-001-s020><wait.abwarten><en> If you protect two games in our exemplary multi bet and already the first batch was typed correctly, but one is assumed wrong, you don't have to wait for the third match.
<G-vec00003-001-s021><wait.abwarten><de> "Ich kann es nicht abwarten"", sagte er auf ESPN."
<G-vec00003-001-s021><wait.abwarten><en> "I can't wait,"" he said, quoted on ESPN."
<G-vec00003-001-s022><wait.abwarten><de> mit dem linksseits zurückgesetzten Zelt der fürstlichen Jagdgesellschaft, unterhalb derer die zurückgehaltene Meute, deren nur fünf das Signal zum großen Fressen unmittelbar am Ort der Begierde abwarten dürfen.
<G-vec00003-001-s022><wait.abwarten><en> with the tent of the princely hunting party in short distance on the left, in-between the pack held back of which only five are allowed to wait for the signal for the great feed directly on the place of desire.
<G-vec00003-001-s023><wait.abwarten><de> Wir können es kaum abwarten, eure Reaktionen zu Episode 2: Out of Time zu sehen.
<G-vec00003-001-s023><wait.abwarten><en> We can't wait to see your reactions to Episode 2: Out of Time.
<G-vec00003-001-s024><wait.abwarten><de> Nach meinem ersten Drop-In war für mich klar, dass ich da etwas gefunden hatte, was mir unglaublich viel Spaß macht, und ich konnte es kaum abwarten das nächste mal wieder Vert zu fahren.
<G-vec00003-001-s024><wait.abwarten><en> After my first drop in I knew this was something I had a lot of fun doing and I could not wait to ride vert again.
<G-vec00003-001-s025><wait.abwarten><de> Obwohl wir bereits in China investieren, lautet unsere Strategie, abwarten bis die Kurse so attraktiv sind, dass sich die Suche nach weiteren langfristigen Anlagegelegenheiten lohnt.
<G-vec00003-001-s025><wait.abwarten><en> While we are already investing in China, our strategy is to wait until prices are so attractive that it’s time to look for further long-term opportunities.
<G-vec00003-001-s026><wait.abwarten><de> Ich konnte es gar nicht abwarten, Mark von Alice zu erzählen.
<G-vec00003-001-s026><wait.abwarten><en> I couldn't wait to tell Mark about Alice.
<G-vec00003-001-s027><wait.abwarten><de> Man muss abwarten bis der richtige Moment kommt, und sich dann inspirieren lassen.
<G-vec00003-001-s027><wait.abwarten><en> You must wait until the right moment comes, and to be able write it you need to be inspired.
<G-vec00003-001-s028><wait.abwarten><de> """Du meinst wohl, dass du es gar nicht abwarten kannst, meine Schwestern zu ficken"", sagte Mary mit einem verdorbenen Lächeln."
<G-vec00003-001-s028><wait.abwarten><en> """You mean you can't wait to see me fuck my sisters,"" Mary said with a naughty smile."
<G-vec00003-001-s029><wait.abwarten><de> Ich kann es nicht abwarten, wieder in den Wein oder Olivenernte.
<G-vec00003-001-s029><wait.abwarten><en> I can't wait to go back during the wine or olive harvests.
<G-vec00003-001-s030><wait.abwarten><de> """Wir arbeiten mit einigen der PRG Alliance-Mitglieder schon seit ein paar Jahren eng zusammen, aber jetzt, da wir offiziell ein der Teil der Gruppe sind, können wir es nicht abwarten, um zusammen mit den anderen Mitgliedern internationale Veranstaltungen in Marokko willkommen zu heißen."
<G-vec00003-001-s030><wait.abwarten><en> """We have been in close collaboration with some of the PRG Alliance members already for a few years but now that we are officially in the group we can't wait to partner with all the members and welcome international events in Morocco, as well as getting the support for our clients abroad."""
<G-vec00003-001-s031><wait.abwarten><de> Wir haben eine tolle Fangemeinde und wenn es nach ihnen ginge, dann wären wir jetzt schon wieder mit den Dreharbeiten beschäftigt, aber leider spielen Dinge wie Einschaltquoten, Sendeplätze, Budget, etc eine große Rolle... daher müssen wir momentan abwarten, was passiert... Ich hoffe allerdings das Beste.
<G-vec00003-001-s031><wait.abwarten><en> We have a great fan base and if it was up to them, we'd be shooting now, but unfortunately, ratings, time slots, budget, etc… things like that factor in…so for now we just have to wait and see what happens…I am hoping for the best though. 13.
<G-vec00003-001-s032><wait.abwarten><de> Während wir eine kurze Windpause abwarten um um die Felsnase herumzufahren steigen die beiden Holländer ab und schieben.
<G-vec00003-001-s032><wait.abwarten><en> While we a short wind break wait around around the rock nose to travel around both Dutchmen descend and push.
<G-vec00003-001-s033><wait.abwarten><de> Sobald Du Deinen Tag erstellt und installiert hast, musst Du nur abwarten, bis er aktiv ist.
<G-vec00003-001-s033><wait.abwarten><en> Once you've set up and installed your tag, you then need to wait for it to become active.
<G-vec00003-001-s034><wait.abwarten><de> Denn meiner Ansicht nach müssen wir demokratisch abwarten, dass die Menschen im Rahmen der europäischen Wahl, deren Hauptfrage nichts anderes sein kann als die Einwanderung – denn das ist gegenwärtig die brennendste Frage in Europa –, die Richtung festlegen.
<G-vec00003-001-s034><wait.abwarten><en> I don't support this because, in my view, they should democratically wait for the people to determine the direction for the main issue in the European elections, which can only be immigration – the most burning issue in Europe.
<G-vec00003-001-s035><wait.abwarten><de> Gegen 7:30 aufgestanden, es regnet ein wenig, es niesselt, abwarten, Zelt etwas nass zusammenpacken, Trinken tanken, Abfahrt.
<G-vec00003-001-s035><wait.abwarten><en> "Around 7:30 up, it rains a little, it ""niesselt"", wait a little, wet pack up, tent, drinking refuel, departure."
<G-vec00003-001-s036><wait.abwarten><de> "Sie sagte, ""Wir sollten angesichts dieser Verfolgung nicht abwarten."
<G-vec00003-001-s036><wait.abwarten><en> "She said, ""We should not wait while facing this kind of persecution."
<G-vec00003-001-s037><wait.abwarten><de> Aber nun ist die Serie wieder großartig und ich kann es nicht abwarten, das Staffelfinale und die vierte Staffel zu sehen.
<G-vec00003-001-s037><wait.abwarten><en> But now the show is great again, and I can't wait to see the finale and the fourth season.
<G-vec00003-001-s038><wait.abwarten><de> Er hatte sich vorgenommen, die Reform nicht anders als auf Grund genauester Angaben über die Bodenverhältnisse und allerhand anderer Statistiken durchzuführen, und redete deshalb den Bauern mit süßester Stimme zu, das Ende seiner Exerzitien abzuwarten.
<G-vec00003-001-s038><wait.abwarten><en> He intended to introduce the reform no otherwise than on the basis of the most accurate agricultural data and statistics of all possible kinds, and therefore kept urging the peasants with the sweetest of voices to wait until his exercises were finished.
<G-vec00003-001-s039><wait.abwarten><de> Sie haben nun die Möglichkeit, entweder die sicheren EUR 18 anzunehmen oder das Spielende abzuwarten in der Hoffnung, dass Spanien dann noch immer führt.
<G-vec00003-001-s039><wait.abwarten><en> You have the option to either take a sure EUR 18 or wait until the end of the game, hoping Spain will still be in the lead then.
<G-vec00003-001-s040><wait.abwarten><de> Alle Abfragen sind mit verschiedenen Ausführungssträngen gerichtet, auf solche Weise bleiben alle SQLite Maestro Möglichkeiten vorhanden und es besteht keine Notwendigkeit abzuwarten, bis Ihre komplexe Abfrage vollendet wird.
<G-vec00003-001-s040><wait.abwarten><en> Each query is executed in a separate thread, so all AnySQL Maestro opportunities remain available and there is no need to wait for your complex query to be completed.
<G-vec00003-001-s041><wait.abwarten><de> Full Tilt Poker andererseits hat sich entschlossen, erst einmal abzuwarten und zu sehen, welche Ausmaße der neue Gesetzentwurf annimmt.
<G-vec00003-001-s041><wait.abwarten><en> "Full Tilt Poker, on the other hand, has issued a release with a reassuring ""wait and see"" demeanor."
<G-vec00003-001-s042><wait.abwarten><de> Die Bande - jetzt reich - zieht sich ein ein armes mexikanisches Dorf zurück um abzuwarten bis sich die Lage beruhigt hat.
<G-vec00003-001-s042><wait.abwarten><en> Being rich now, the entire gang withdraws to a lonely mexican town to wait till things calm down.
<G-vec00003-001-s043><wait.abwarten><de> Nach Ablauf dieser Frist sind wir berechtigt, die Ware ohne weiteres zur Auslieferung zu bringen, ohne einen Abruf abzuwarten.
<G-vec00003-001-s043><wait.abwarten><en> When such a period expires, we are entitled to deliver the goods disregarding any restriction, without having to wait for a release order.
<G-vec00003-001-s044><wait.abwarten><de> Des Weiteren ist es ratsam, wenn die Mutter stillt, das Abstillen des Kindes abzuwarten.
<G-vec00003-001-s044><wait.abwarten><en> Moreover, if you decide to breastfeed it is better to wait for the baby to be weaned.
<G-vec00003-001-s045><wait.abwarten><de> Wir beschlossen, den Sturm abzuwarten.
<G-vec00003-001-s045><wait.abwarten><en> We decided to wait out the storm.
<G-vec00003-001-s046><wait.abwarten><de> Es gibt nichts schlimmeres, als wenn dein Schicksal über deinen Kopf hinweg entschieden wird und du nichts anderes tun kannst, als abzuwarten.
<G-vec00003-001-s046><wait.abwarten><en> There is nothing worse than having your fate decided for you but there is nothing you can do but wait.
<G-vec00003-001-s047><wait.abwarten><de> Wir bringen die nötige Geduld auf, abzuwarten, bis der Markt den wahren Wert eines Unternehmens erkennt.
<G-vec00003-001-s047><wait.abwarten><en> We are patient enough to wait for the market to potentially recognize the true value of a company.
<G-vec00003-001-s048><wait.abwarten><de> Den Sturm abzuwarten und auszusitzen, wenn die Kräfte der Natur Überhand gewinnen, ist hier die Devise.
<G-vec00003-001-s048><wait.abwarten><en> The rule is to wait for the storm, sitting it out while the forces of nature hold sway.
<G-vec00003-001-s049><wait.abwarten><de> Nach einer Internet Video Konferenz wurde von beiden Seiten beschlossen, das Ende der Blockade Nepals abzuwarten, um den Bau zu beginnen.
<G-vec00003-001-s049><wait.abwarten><en> After an internet video conference both sides decided to wait until the end of the blockade of Nepal before starting the construction work.
<G-vec00003-001-s050><wait.abwarten><de> Doch es steht uns nicht zu, untätig die endliche Erfüllung von Shoghi Effendis Vision abzuwarten.
<G-vec00003-001-s050><wait.abwarten><en> However, it is not for us to wait passively for the ultimate fulfilment of Shoghi Effendi's vision.
<G-vec00003-001-s051><wait.abwarten><de> Das heißt, daß wir es uns nicht leisten können, im Falle eines ernsthaften Risikos einer Umweltschädigung hochkarätige wissenschaftliche Beweise abzuwarten, bevor wir handeln, um Schäden vorzubeugen.
<G-vec00003-001-s051><wait.abwarten><en> This means that where there is a serious risk of harm to the environment we cannot afford to wait for a high degree of scientific proof before acting to prevent damage.
<G-vec00003-001-s052><wait.abwarten><de> Die Ergebnisse der verschiedenen Experimente sind abzuwarten.
<G-vec00003-001-s052><wait.abwarten><en> We will have to wait for the results of the various experiments.
<G-vec00003-001-s053><wait.abwarten><de> Die Ströme können derart gespannt sein, dass es unumgänglich ist, eine Änderung abzuwarten, um die Übertragung durchzuführen.
<G-vec00003-001-s053><wait.abwarten><en> Currents can be so intensified that it may be necessary to wait for a change so that the transmission can be accomplished.
<G-vec00003-001-s054><wait.abwarten><de> Ich öffnete den Mund, um etwas zu erwidern, aber der Blödmann war bereits im Wohnzimmer verschwunden, ohne meine Reaktion abzuwarten.
<G-vec00003-001-s054><wait.abwarten><en> I opened my mouth to reply but the jerk was already in the living room, not bothering to wait for my response.
<G-vec00003-001-s055><wait.abwarten><de> Oft sind die Kriege nicht viel mehr wie eine bewaffnete Neutralität oder eine drohende Stellung zur Unterstützung der Unterhandlungen oder ein mäßiger Versuch, sich in einen kleinen Vorteil zu setzen und dann die Sache abzuwarten, oder eine unangenehme Bundespflicht, die man so karg als möglich erfüllt.
<G-vec00003-001-s055><wait.abwarten><en> A war is often nothing more than an armed neutrality, or a menacing attitude to support negotiations or an attempt to gain some small advantage by small exertions, and then to wait the tide of circumstances, or a disagreeable treaty obligation, which is fulfilled in the most niggardly way possible.
<G-vec00003-001-s056><wait.abwarten><de> Daher ist abzuwarten, was die Untersuchungen über die Scottish Fold im Feline Genome Project von Dr. Lyons ergeben.
<G-vec00003-001-s056><wait.abwarten><en> Therefore one has to wait, which results the research about the Scottish Fold in the Feline Genome Project of Dr. Lyons will show.
