<G-vec00003-001-s019><wait.abwarten><de> Mit dem MACH4, wirst du es nicht mehr abwarten können, endlich ins Wasser zu kommen.
<G-vec00003-001-s019><wait.abwarten><en> With the MACH4, you won’t be able to wait to get into the water!
<G-vec00003-001-s020><wait.abwarten><de> Wenn du in unserem beispielhaften Kombi-Tipp zwei Spiele versicherst und bereits die erste Partie richtig getippt wurde, eine aber schon falsch ausgegangen ist, musst du nicht mehr das dritte Match abwarten.
<G-vec00003-001-s020><wait.abwarten><en> If you protect two games in our exemplary multi bet and already the first batch was typed correctly, but one is assumed wrong, you don't have to wait for the third match.
<G-vec00003-001-s021><wait.abwarten><de> "Ich kann es nicht abwarten"", sagte er auf ESPN."
<G-vec00003-001-s021><wait.abwarten><en> "I can't wait,"" he said, quoted on ESPN."
<G-vec00003-001-s022><wait.abwarten><de> mit dem linksseits zurückgesetzten Zelt der fürstlichen Jagdgesellschaft, unterhalb derer die zurückgehaltene Meute, deren nur fünf das Signal zum großen Fressen unmittelbar am Ort der Begierde abwarten dürfen.
<G-vec00003-001-s022><wait.abwarten><en> with the tent of the princely hunting party in short distance on the left, in-between the pack held back of which only five are allowed to wait for the signal for the great feed directly on the place of desire.
<G-vec00003-001-s023><wait.abwarten><de> Wir können es kaum abwarten, eure Reaktionen zu Episode 2: Out of Time zu sehen.
<G-vec00003-001-s023><wait.abwarten><en> We can't wait to see your reactions to Episode 2: Out of Time.
<G-vec00003-001-s024><wait.abwarten><de> Nach meinem ersten Drop-In war für mich klar, dass ich da etwas gefunden hatte, was mir unglaublich viel Spaß macht, und ich konnte es kaum abwarten das nächste mal wieder Vert zu fahren.
<G-vec00003-001-s024><wait.abwarten><en> After my first drop in I knew this was something I had a lot of fun doing and I could not wait to ride vert again.
<G-vec00003-001-s025><wait.abwarten><de> Obwohl wir bereits in China investieren, lautet unsere Strategie, abwarten bis die Kurse so attraktiv sind, dass sich die Suche nach weiteren langfristigen Anlagegelegenheiten lohnt.
<G-vec00003-001-s025><wait.abwarten><en> While we are already investing in China, our strategy is to wait until prices are so attractive that it’s time to look for further long-term opportunities.
<G-vec00003-001-s026><wait.abwarten><de> Ich konnte es gar nicht abwarten, Mark von Alice zu erzählen.
<G-vec00003-001-s026><wait.abwarten><en> I couldn't wait to tell Mark about Alice.
<G-vec00003-001-s027><wait.abwarten><de> Man muss abwarten bis der richtige Moment kommt, und sich dann inspirieren lassen.
<G-vec00003-001-s027><wait.abwarten><en> You must wait until the right moment comes, and to be able write it you need to be inspired.
<G-vec00003-001-s028><wait.abwarten><de> """Du meinst wohl, dass du es gar nicht abwarten kannst, meine Schwestern zu ficken"", sagte Mary mit einem verdorbenen Lächeln."
<G-vec00003-001-s028><wait.abwarten><en> """You mean you can't wait to see me fuck my sisters,"" Mary said with a naughty smile."
<G-vec00003-001-s029><wait.abwarten><de> Ich kann es nicht abwarten, wieder in den Wein oder Olivenernte.
<G-vec00003-001-s029><wait.abwarten><en> I can't wait to go back during the wine or olive harvests.
<G-vec00003-001-s030><wait.abwarten><de> """Wir arbeiten mit einigen der PRG Alliance-Mitglieder schon seit ein paar Jahren eng zusammen, aber jetzt, da wir offiziell ein der Teil der Gruppe sind, können wir es nicht abwarten, um zusammen mit den anderen Mitgliedern internationale Veranstaltungen in Marokko willkommen zu heißen."
<G-vec00003-001-s030><wait.abwarten><en> """We have been in close collaboration with some of the PRG Alliance members already for a few years but now that we are officially in the group we can't wait to partner with all the members and welcome international events in Morocco, as well as getting the support for our clients abroad."""
<G-vec00003-001-s031><wait.abwarten><de> Wir haben eine tolle Fangemeinde und wenn es nach ihnen ginge, dann wären wir jetzt schon wieder mit den Dreharbeiten beschäftigt, aber leider spielen Dinge wie Einschaltquoten, Sendeplätze, Budget, etc eine große Rolle... daher müssen wir momentan abwarten, was passiert... Ich hoffe allerdings das Beste.
<G-vec00003-001-s031><wait.abwarten><en> We have a great fan base and if it was up to them, we'd be shooting now, but unfortunately, ratings, time slots, budget, etc… things like that factor in…so for now we just have to wait and see what happens…I am hoping for the best though. 13.
<G-vec00003-001-s032><wait.abwarten><de> Während wir eine kurze Windpause abwarten um um die Felsnase herumzufahren steigen die beiden Holländer ab und schieben.
<G-vec00003-001-s032><wait.abwarten><en> While we a short wind break wait around around the rock nose to travel around both Dutchmen descend and push.
<G-vec00003-001-s033><wait.abwarten><de> Sobald Du Deinen Tag erstellt und installiert hast, musst Du nur abwarten, bis er aktiv ist.
<G-vec00003-001-s033><wait.abwarten><en> Once you've set up and installed your tag, you then need to wait for it to become active.
<G-vec00003-001-s034><wait.abwarten><de> Denn meiner Ansicht nach müssen wir demokratisch abwarten, dass die Menschen im Rahmen der europäischen Wahl, deren Hauptfrage nichts anderes sein kann als die Einwanderung – denn das ist gegenwärtig die brennendste Frage in Europa –, die Richtung festlegen.
<G-vec00003-001-s034><wait.abwarten><en> I don't support this because, in my view, they should democratically wait for the people to determine the direction for the main issue in the European elections, which can only be immigration – the most burning issue in Europe.
<G-vec00003-001-s035><wait.abwarten><de> Gegen 7:30 aufgestanden, es regnet ein wenig, es niesselt, abwarten, Zelt etwas nass zusammenpacken, Trinken tanken, Abfahrt.
<G-vec00003-001-s035><wait.abwarten><en> "Around 7:30 up, it rains a little, it ""niesselt"", wait a little, wet pack up, tent, drinking refuel, departure."
<G-vec00003-001-s036><wait.abwarten><de> "Sie sagte, ""Wir sollten angesichts dieser Verfolgung nicht abwarten."
<G-vec00003-001-s036><wait.abwarten><en> "She said, ""We should not wait while facing this kind of persecution."
<G-vec00003-001-s037><wait.abwarten><de> Aber nun ist die Serie wieder großartig und ich kann es nicht abwarten, das Staffelfinale und die vierte Staffel zu sehen.
<G-vec00003-001-s037><wait.abwarten><en> But now the show is great again, and I can't wait to see the finale and the fourth season.
<G-vec00003-001-s038><wait.abwarten><de> Er hatte sich vorgenommen, die Reform nicht anders als auf Grund genauester Angaben über die Bodenverhältnisse und allerhand anderer Statistiken durchzuführen, und redete deshalb den Bauern mit süßester Stimme zu, das Ende seiner Exerzitien abzuwarten.
<G-vec00003-001-s038><wait.abwarten><en> He intended to introduce the reform no otherwise than on the basis of the most accurate agricultural data and statistics of all possible kinds, and therefore kept urging the peasants with the sweetest of voices to wait until his exercises were finished.
<G-vec00003-001-s039><wait.abwarten><de> Sie haben nun die Möglichkeit, entweder die sicheren EUR 18 anzunehmen oder das Spielende abzuwarten in der Hoffnung, dass Spanien dann noch immer führt.
<G-vec00003-001-s039><wait.abwarten><en> You have the option to either take a sure EUR 18 or wait until the end of the game, hoping Spain will still be in the lead then.
<G-vec00003-001-s040><wait.abwarten><de> Alle Abfragen sind mit verschiedenen Ausführungssträngen gerichtet, auf solche Weise bleiben alle SQLite Maestro Möglichkeiten vorhanden und es besteht keine Notwendigkeit abzuwarten, bis Ihre komplexe Abfrage vollendet wird.
<G-vec00003-001-s040><wait.abwarten><en> Each query is executed in a separate thread, so all AnySQL Maestro opportunities remain available and there is no need to wait for your complex query to be completed.
<G-vec00003-001-s041><wait.abwarten><de> Full Tilt Poker andererseits hat sich entschlossen, erst einmal abzuwarten und zu sehen, welche Ausmaße der neue Gesetzentwurf annimmt.
<G-vec00003-001-s041><wait.abwarten><en> "Full Tilt Poker, on the other hand, has issued a release with a reassuring ""wait and see"" demeanor."
<G-vec00003-001-s042><wait.abwarten><de> Die Bande - jetzt reich - zieht sich ein ein armes mexikanisches Dorf zurück um abzuwarten bis sich die Lage beruhigt hat.
<G-vec00003-001-s042><wait.abwarten><en> Being rich now, the entire gang withdraws to a lonely mexican town to wait till things calm down.
<G-vec00003-001-s043><wait.abwarten><de> Nach Ablauf dieser Frist sind wir berechtigt, die Ware ohne weiteres zur Auslieferung zu bringen, ohne einen Abruf abzuwarten.
<G-vec00003-001-s043><wait.abwarten><en> When such a period expires, we are entitled to deliver the goods disregarding any restriction, without having to wait for a release order.
<G-vec00003-001-s044><wait.abwarten><de> Des Weiteren ist es ratsam, wenn die Mutter stillt, das Abstillen des Kindes abzuwarten.
<G-vec00003-001-s044><wait.abwarten><en> Moreover, if you decide to breastfeed it is better to wait for the baby to be weaned.
<G-vec00003-001-s045><wait.abwarten><de> Wir beschlossen, den Sturm abzuwarten.
<G-vec00003-001-s045><wait.abwarten><en> We decided to wait out the storm.
<G-vec00003-001-s046><wait.abwarten><de> Es gibt nichts schlimmeres, als wenn dein Schicksal über deinen Kopf hinweg entschieden wird und du nichts anderes tun kannst, als abzuwarten.
<G-vec00003-001-s046><wait.abwarten><en> There is nothing worse than having your fate decided for you but there is nothing you can do but wait.
<G-vec00003-001-s047><wait.abwarten><de> Wir bringen die nötige Geduld auf, abzuwarten, bis der Markt den wahren Wert eines Unternehmens erkennt.
<G-vec00003-001-s047><wait.abwarten><en> We are patient enough to wait for the market to potentially recognize the true value of a company.
<G-vec00003-001-s048><wait.abwarten><de> Den Sturm abzuwarten und auszusitzen, wenn die Kräfte der Natur Überhand gewinnen, ist hier die Devise.
<G-vec00003-001-s048><wait.abwarten><en> The rule is to wait for the storm, sitting it out while the forces of nature hold sway.
<G-vec00003-001-s049><wait.abwarten><de> Nach einer Internet Video Konferenz wurde von beiden Seiten beschlossen, das Ende der Blockade Nepals abzuwarten, um den Bau zu beginnen.
<G-vec00003-001-s049><wait.abwarten><en> After an internet video conference both sides decided to wait until the end of the blockade of Nepal before starting the construction work.
<G-vec00003-001-s050><wait.abwarten><de> Doch es steht uns nicht zu, untätig die endliche Erfüllung von Shoghi Effendis Vision abzuwarten.
<G-vec00003-001-s050><wait.abwarten><en> However, it is not for us to wait passively for the ultimate fulfilment of Shoghi Effendi's vision.
<G-vec00003-001-s051><wait.abwarten><de> Das heißt, daß wir es uns nicht leisten können, im Falle eines ernsthaften Risikos einer Umweltschädigung hochkarätige wissenschaftliche Beweise abzuwarten, bevor wir handeln, um Schäden vorzubeugen.
<G-vec00003-001-s051><wait.abwarten><en> This means that where there is a serious risk of harm to the environment we cannot afford to wait for a high degree of scientific proof before acting to prevent damage.
<G-vec00003-001-s052><wait.abwarten><de> Die Ergebnisse der verschiedenen Experimente sind abzuwarten.
<G-vec00003-001-s052><wait.abwarten><en> We will have to wait for the results of the various experiments.
<G-vec00003-001-s053><wait.abwarten><de> Die Ströme können derart gespannt sein, dass es unumgänglich ist, eine Änderung abzuwarten, um die Übertragung durchzuführen.
<G-vec00003-001-s053><wait.abwarten><en> Currents can be so intensified that it may be necessary to wait for a change so that the transmission can be accomplished.
<G-vec00003-001-s054><wait.abwarten><de> Ich öffnete den Mund, um etwas zu erwidern, aber der Blödmann war bereits im Wohnzimmer verschwunden, ohne meine Reaktion abzuwarten.
<G-vec00003-001-s054><wait.abwarten><en> I opened my mouth to reply but the jerk was already in the living room, not bothering to wait for my response.
<G-vec00003-001-s055><wait.abwarten><de> Oft sind die Kriege nicht viel mehr wie eine bewaffnete Neutralität oder eine drohende Stellung zur Unterstützung der Unterhandlungen oder ein mäßiger Versuch, sich in einen kleinen Vorteil zu setzen und dann die Sache abzuwarten, oder eine unangenehme Bundespflicht, die man so karg als möglich erfüllt.
<G-vec00003-001-s055><wait.abwarten><en> A war is often nothing more than an armed neutrality, or a menacing attitude to support negotiations or an attempt to gain some small advantage by small exertions, and then to wait the tide of circumstances, or a disagreeable treaty obligation, which is fulfilled in the most niggardly way possible.
<G-vec00003-001-s056><wait.abwarten><de> Daher ist abzuwarten, was die Untersuchungen über die Scottish Fold im Feline Genome Project von Dr. Lyons ergeben.
<G-vec00003-001-s056><wait.abwarten><en> Therefore one has to wait, which results the research about the Scottish Fold in the Feline Genome Project of Dr. Lyons will show.
<G-vec00491-002-s537><wait_out.abwarten><de> Sie warten dafür nur günstige Ereignisse ab — einen Augenblick, gleich dem von 1848, in dem sie sich auf die Zertrümmerung der bestehenden Regierung stürzen können — mit der Hoffnung, von einer internationalen Bewegung unterstützt zu werden.
<G-vec00491-002-s537><wait_out.abwarten><en> They but wait for a favorable opportunity — a chance, such as presented itself in 1848, when they will be able to start the destruction of the present economic system, with the hope of being supported by an International movement.
<G-vec00491-002-s538><wait_out.abwarten><de> Warten Sie lieber ab und sehen Sie aus sicherer Entfernung zu, wie sich ein neuer Malt entwickelt.
<G-vec00491-002-s538><wait_out.abwarten><en> You should rather wait and watch from a safe distance how a new malt develops.
<G-vec00491-002-s539><wait_out.abwarten><de> Wir mussten etwas warten, aber dann war er ab, die Nabelschnur.
<G-vec00491-002-s539><wait_out.abwarten><en> We had to wait a little longer, but finally the umbilical cord was gone.
<G-vec00491-002-s540><wait_out.abwarten><de> Schuldner stellen sich auf diese Systematik ein und warten dann häufig die letzte mögliche Frist ab.
<G-vec00491-002-s540><wait_out.abwarten><en> Debtors adapt to this systematic approach and then often wait until the last possible deadline.
<G-vec00491-002-s541><wait_out.abwarten><de> Falls das Bedienungspersonal aus arbeitsbedingten Gründen nicht bei der gegenständlichen Kasse anwesend ist, warten Sie bitte die Rückkehr dieses Mitarbeiters ab (oder kontaktieren Sie diesen gegebenenfalls telefonisch unter der angeführten Nummer).
<G-vec00491-002-s541><wait_out.abwarten><en> If the service personnel is not present at the service counter for other work-related reasons, you must wait for this employee to return (or contact him/her using a specified telephone number, if applicable).
<G-vec00491-002-s542><wait_out.abwarten><de> Ich würde sogar soweit gehen zu sagen, dass er einer der mutigsten und inspiriertesten Designer seit Alexander McQueen sein könnte, aber warten wir einmal ab, welche fantastischen Dinge sich Leandro Cano als nächstes ausdenkt.
<G-vec00491-002-s542><wait_out.abwarten><en> I might even go as far as to call him one of the the most daring and inspired designers since Alexander McQueen, but let's wait and see what amazing things Leandro Cano comes up with next.
<G-vec00491-002-s543><wait_out.abwarten><de> Vielleicht warten Sie auch prinzipiell immer den letzten Moment ab, um zu reservieren.
<G-vec00491-002-s543><wait_out.abwarten><en> Or perhaps you just prefer to wait until the last minute to reserve.
<G-vec00491-002-s544><wait_out.abwarten><de> "Nun, warten Sie's nur ab, was Sie hier in den Ställen zu sehen kriegen.
<G-vec00491-002-s544><wait_out.abwarten><en> "Well," said Dawson, "you just wait till you've seen what's in the stables.
<G-vec00491-002-s545><wait_out.abwarten><de> Bei persönlicher Abholung warten Sie bitte unsere SMS-Nachricht ab, dass die Ware zur Abholung bereit liegt.
<G-vec00491-002-s545><wait_out.abwarten><en> If you chose in-person pickup, please wait for the text message we will send you as soon as your order is ready.
<G-vec00491-002-s546><wait_out.abwarten><de> So wartet nur ab, wir warten mit euch ab.
<G-vec00491-002-s546><wait_out.abwarten><en> So wait (expectant); we too will wait with you."
<G-vec00491-002-s547><wait_out.abwarten><de> Heute bleiben wir hier und warten ab, bis sich das Sturmtief weiter nach Norden verzogen hat.
<G-vec00491-002-s547><wait_out.abwarten><en> Today we keep hiding in this bay and wait until the nasty depression moves away to the north.
<G-vec00491-002-s548><wait_out.abwarten><de> Warten Sie bitte ab, bis auf Ihrem Konto neue Bewegungen (Gutschriften, Belastungen) stattgefunden haben und versuchen Sie es auf dem darauf folgendem Tag.
<G-vec00491-002-s548><wait_out.abwarten><en> Please wait until there are new transactions on your account (credits, debits) and try to reconcile the transactions again after that.
<G-vec00491-002-s549><wait_out.abwarten><de> Ich frage mich - warten wir die Haltung der Kommission ab -, ob wir die Schlussabstimmung nicht vertagen sollten.
<G-vec00491-002-s549><wait_out.abwarten><en> wonder - but we shall wait for the Commission - if we need to postpone the final vote.
<G-vec00491-002-s550><wait_out.abwarten><de> Warten wir mal ab, wann es Realität wird.
<G-vec00491-002-s550><wait_out.abwarten><en> Let's wait and see when this becomes reality.
<G-vec00491-002-s551><wait_out.abwarten><de> Wir sollten nicht sagen, wir machen Demonstrationen oder wir warten ab, bis jemand verhaftet wird.
<G-vec00491-002-s551><wait_out.abwarten><en> We should not just say “Oh, we will make a demonstration!” or we will wait until somebody gets arrested.
<G-vec00491-002-s552><wait_out.abwarten><de> Aber warten wir die offizielle Ankündigung ab.
<G-vec00491-002-s552><wait_out.abwarten><en> But we stay and wait for the official announcement.
<G-vec00491-002-s553><wait_out.abwarten><de> Picard: Warten wir ab wie lange "Solitaire" die Funktionalitaet der Borg einschraenken kann.
<G-vec00491-002-s553><wait_out.abwarten><en> Picard:Lets wait and see how long this Solitaire can reduce their functionality.
<G-vec00555-002-s012><sideline.abwarten><de> Beim AUD/USD-Chart oben könnten Sie entweder abwarten oder den AUD/USD nicht kaufen, weil Sie keine Bestätigung erhielten, die sich positiv auf Ihren Kontostand auswirken würde.
<G-vec00555-002-s012><sideline.abwarten><en> On the AUDUSD chart above, you could have either stayed on the sideline or not bought the AUDUSD because you did not receive confirmation which would have been kind to your account equity.
<G-vec00003-002-s019><await.abwarten><de> Er konnte Khirays natürliches Ende abwarten.
<G-vec00003-002-s019><await.abwarten><en> He could await Khiray's natural end.
<G-vec00003-002-s020><await.abwarten><de> „Die Tyrannei wird sich nicht bis zum Ende aller Zeiten halten und als Präsident werde ich nicht passiv den Tag abwarten, an dem das kubanische Volk die Freude der Freiheit und Demokratie genießen kann.
<G-vec00003-002-s020><await.abwarten><en> “Yet tyranny will not forever endure, and as President, I will not passively await the day when the Cuban people enjoy the blessings of freedom and democracy. I will not wait…”
<G-vec00003-002-s021><await.abwarten><de> Der venezolanische Präsident Maduro erklärte derweil, seine Regierung werde „die Reaktion der Welt“ abwarten, bevor sie über den Asylantrag entscheide.
<G-vec00003-002-s021><await.abwarten><en> Venezuela’s President Maduro, meanwhile, announced that his government would await “the reaction of the world” before deciding on the asylum request.
<G-vec00003-002-s022><await.abwarten><de> Diejenigen, die es nicht vermögen, werden neue Zeiten abwarten müssen, damit ihr Geist seine Augen dem Lichte meiner Offenbarungen öffnet.
<G-vec00003-002-s022><await.abwarten><en> Those who do not succeed in doing so will have to await new times for their spirits to open their eyes to the light of My revelations.
<G-vec00003-002-s023><await.abwarten><de> Die CSU will ihre Regierungsbildung mit den Freien Wählern in Bayern und die Wahl des EP-Spitzenkandidaten abwarten, um dann über weitere Konsequenzen zu diskutieren.
<G-vec00003-002-s023><await.abwarten><en> Before discussing any further consequences, the CSU wants to form a state government with the Free Voters in Bavaria and await the election of their frontrunner for the upcoming EP elections.
<G-vec00003-002-s024><await.abwarten><de> Sie erwarteten jeden Augenblick das Kommen des Meisters, aber sie waren im Zwiespalt, ob sie sich setzen oder sein Kommen abwarten und es ihm überlassen sollten, ihnen ihre Plätze zuzuweisen.
<G-vec00003-002-s024><await.abwarten><en> They expected the Master to arrive any moment, but they were in a quandary as to whether they should seat themselves or await his coming and depend on him to assign them their places.
<G-vec00003-002-s025><await.abwarten><de> Ich konnte es nicht mehr abwarten und hatte schon mal mit der Qualitätskontrolle Ich wollte natürlich den Geburtstagskuchen mit La Donna essen, ich bin ein Gentleman, aber das wisst Ihr ja.
<G-vec00003-002-s025><await.abwarten><en> Of course I couldn’t await it so so I did some quality control first. had wanted to share my cake with La Donna, as I am a Gentleman, which you know.
<G-vec00003-002-s026><await.abwarten><de> 80 In einem derartigen Fall ist das nationale Gericht gehalten, eine diskriminierende nationale Bestimmung außer Anwendung zu lassen, ohne dass es ihre vorherige Beseitigung durch den Gesetzgeber beantragen oder abwarten müsste, und auf die Mitglieder der benachteiligten Gruppe eben die Regelung anzuwenden, die für die Mitglieder der anderen Gruppe gilt.
<G-vec00003-002-s026><await.abwarten><en> 80 In such a situation, a national court must set aside any discriminatory provision of national law, without having to request or await its prior removal by the legislature, and must apply to members of the disadvantaged group the same arrangements as those enjoyed by the persons in the other category.
<G-vec00003-002-s027><await.abwarten><de> Dann den Apparat zu verlassen und den Gang hinab zu gehen, wo sie umdrehen und sich wieder in die Wartestation begeben, um den nächsten Test abzuwarten.
<G-vec00003-002-s027><await.abwarten><en> Then to walk away from the apparatus, halfway down the length of the stable breezeway, where they turn around, and walk back into the station to await the next trial.
<G-vec00003-002-s028><await.abwarten><de> Dazu mussten sie sich aber Körper erschaffen, welche dem Leben auf der Erde angepasst wären, um bis dahin zu überdauern und abzuwarten.
<G-vec00003-002-s028><await.abwarten><en> Therefore however they had to build up bodies which were adjusted to life on earth to outlast and await time until then.
<G-vec00003-002-s029><await.abwarten><de> Viele, darunter Cassius und Brutus, verließen Rom, um abzuwarten, was die Zukunft bringen würde.
<G-vec00003-002-s029><await.abwarten><en> Many, among them Cassius and Brutus, left Rome to await future developments.
<G-vec00003-002-s030><await.abwarten><de> Sie nahmen entsprechend gefärbte Kleidung und Kokarden an, wo sie konnten, und einige marschierten auf das Hôtel de Ville, um Anweisungen abzuwarten.
<G-vec00003-002-s030><await.abwarten><en> They adopted suitably coloured clothing and cockades, where they could, and some marched on the Hôtel de Ville to await instructions.
<G-vec00003-002-s031><await.abwarten><de> Für Elster sank die Abschreibung pro BOE auf 19,5 USD (bisher 22 USD/Barrel), für Cub Creek wurde sie zunächst bei 26 USD je Barrel belassen, um die Ergebnisse der weiteren Überarbeitungen abzuwarten.
<G-vec00003-002-s031><await.abwarten><en> For Elster, depreciation per BOE fell to USD 19.5 (previously USD 22 per barrel), for Cub Creek it was left at USD 26 per barrel to await the results of further revisions.
<G-vec00003-002-s032><await.abwarten><de> Die Verbände fordern, zumindest den Ausgang dieser Klage abzuwarten, bevor eine „derart weitreichende Registrierung des Verhaltens der Menschen in Deutschland“ beschlossen wird.
<G-vec00003-002-s032><await.abwarten><en> The organisations call for the government to at least await the outcome of this action before ordering "a recording of the German people’s behaviour as far-reaching as that".
<G-vec00003-002-s019><wait.abwarten><de> Sie können abwarten, bis das nächste Update auf Ihrem Gerät installiert wird (Updates für Windows 10 Mobile werden normalerweise einmal im Monat veröffentlicht).
<G-vec00003-002-s019><wait.abwarten><en> You can wait until the next update is installed on your device (updates for Windows 10 Mobile are usually released once a month), which should automatically fix this problem.
<G-vec00003-002-s020><wait.abwarten><de> Sowohl im Bundeslandwirtschafts-Ministerium als auch in Österreich will man den Entwurf abwarten, bevor man über inhaltliche Änderungen sprechen könne.
<G-vec00003-002-s020><wait.abwarten><en> Both the German and Austrian Federal Ministries of Agriculture want to wait for the draft before they would talk about substantive changes.
<G-vec00003-002-s021><wait.abwarten><de> Wenn wir in der Östlichen Partnerschaft aber ein Format sehen, mit deren Hilfe wir unseren Kontinent zu einem lebenswerteren Ort gestalten können, sollte sich unsere Haltung von “sehen und abwarten” in „aufstehen und handeln“ ändern.
<G-vec00003-002-s021><wait.abwarten><en> But if we see the Eastern Partnerships as a format to make our continent a better place to live in, our approach should turn from ‘wait and see’ to ‘step-up and do”.
<G-vec00003-002-s022><wait.abwarten><de> Ein weiterer roter Flagge von der Website wäre die Haftungsbeschränkungen darüber, wie lange die Nutzer erwarten können, bevor Sie erste Ergebnisse abwarten.
<G-vec00003-002-s022><wait.abwarten><en> Other red flag with the web site will be reservations about how long users can expect to wait before seeing results.
<G-vec00003-002-s023><wait.abwarten><de> Wir sind dem Naturereignis machtlos ausgesetzt und können nur abwarten (siehe Video).
<G-vec00003-002-s023><wait.abwarten><en> We are exposed to natural phenomenon – powerless with the only option to wait (see video).
<G-vec00003-002-s024><wait.abwarten><de> «Sie müssen [mit dem anderen Mann] Sex haben und sich von ihm scheiden lassen, [und] drei Monatsblutungen abwarten”, berichtete ein Zeuge der mündlichen Verhandlung.
<G-vec00003-002-s024><wait.abwarten><en> ‘She will need to have sex first [with the other man], divorce him, [and] wait three menstrual periods,’ reports a witness to the hearing.
<G-vec00003-002-s025><wait.abwarten><de> Ich glaube, man muss abwarten, ob wirklich alles vernetzt sein muss.
<G-vec00003-002-s025><wait.abwarten><en> I think we should wait and see whether everything really needs to be networked.
<G-vec00003-002-s026><wait.abwarten><de> Sie hoffen, das Kriegsende ohne weitere Kampfhandlungen abwarten zu können.
<G-vec00003-002-s026><wait.abwarten><en> They hope to be able to wait for the end of the war without having to encounter any combat operations.
<G-vec00003-002-s027><wait.abwarten><de> Wer hier glaubt, es kann nicht mehr besser werden, sollte abwarten... Nach dem steilen Anstieg zur Alp Trela gelangt ihr zum Passo di Val Trela, wo euch zum Abschluss des Tages ein ganz großes, unbeschreibliches Abfahrtserlebnis erwartet.
<G-vec00003-002-s027><wait.abwarten><en> Who thinks it can’t get better than that should wait..After the steep uphill to the Alp Trela we get to the Passo di Val Trela where a great downhill adventure awaits us at the end of the day.
<G-vec00003-002-s028><wait.abwarten><de> Ihr Fahrer wird Sie bei der gewünschten Zeit abwarten und Sie direkt zu Navis zurückgeben.
<G-vec00003-002-s028><wait.abwarten><en> Your driver will wait you at the requested time and transfer you straight to Stuben.
<G-vec00003-002-s029><wait.abwarten><de> Wer in der Hurrikanzone bleibt, sollte sich möglichst einen Raum ohne Fenster als Schutzraum suchen und dort abwarten, bis der Hurrikan vorbeigezogen ist.
<G-vec00003-002-s029><wait.abwarten><en> Who stays in the hurricane zone should look for a room without windows as shelter and wait there until the hurricane has passed. 4.
<G-vec00003-002-s030><wait.abwarten><de> Bislang haben die Leute extrem positiv auf die erste Single "Sex is The Word" reagiert und wir müssen abwarten und sehen, wie sie auf das Album reagieren werden.
<G-vec00003-002-s030><wait.abwarten><en> So far people have reacted extremely positively to the first single “Sex is The Word” and we’ll just have to wait and see how they react to the album. 3.
<G-vec00003-002-s031><wait.abwarten><de> Mensch, ich bin total von den Socken - ich kann es gar nicht abwarten für diesen Hersteller zu arbeiten.
<G-vec00003-002-s031><wait.abwarten><en> Man, I am totally gobsmacked here - I can't wait to get started with them.
<G-vec00003-002-s032><wait.abwarten><de> In diesem Fall muss der Mieter die Nebenkostenabrechnung abwarten, bevor ihm die Mietkaution erstattet wird.
<G-vec00003-002-s032><wait.abwarten><en> In this case, the tenant must wait until the annual breakdown of the additional costs is established before claiming the return of the rental deposit.
<G-vec00003-002-s033><wait.abwarten><de> (Achtung: Während des Uploads gibt es keine Rückmeldung vom Server, d.h., den Upload einstarten, den Browser nicht schließen und dann abwarten.
<G-vec00003-002-s033><wait.abwarten><en> (Attention: During the upload there is no feedback from the server, i.e. start the upload, do not close the browser and then wait.
<G-vec00003-002-s034><wait.abwarten><de> Bisher bekommen wir Ware aus China per Schiff, oder in eiligen Fällen, wenn wir es nicht abwarten können, allenfalls per Flugzeug.
<G-vec00003-002-s034><wait.abwarten><en> Until now, we received our goods from China by ship, or sometimes, if we were in a hurry or could just not wait, by plane.
<G-vec00003-002-s035><wait.abwarten><de> So lass uns sitzen und abwarten, wundern wir uns dann aber nicht, wenn eines Tages ein neuer Erlöser vorbeikommt und uns erobert.
<G-vec00003-002-s035><wait.abwarten><en> So let´s sit and wait, but we shouldn´t be surprised then if someday a new redeemer comes along and takes control of us.
<G-vec00003-002-s036><wait.abwarten><de> Unsere Untertanen müssen einfach nur abwarten.
<G-vec00003-002-s036><wait.abwarten><en> Our subjects will just have to wait and see.
<G-vec00003-002-s037><wait.abwarten><de> Sofern der Unternehmer nicht anbietet, das Produkt selbst abzuholen, kann er die Rückzahlung abwarten, bis er das Produkt erhalten hat oder bis die Verbraucher nachweist, dass er das Produkt zurückgegeben hat, je nachdem, welches der frühere Zeitpunkt ist.
<G-vec00003-002-s037><wait.abwarten><en> Unless the entrepreneur offers to collect the product himself, he may wait to repay until he has received the product or until the consumer demonstrates that he has returned the product, whichever is earlier.
<G-vec00003-002-s038><wait.abwarten><de> Eine Möglichkeit besteht darin, eine voreingestellte Zeit abzuwarten, beispielsweise mindestens zwei Sekunden.
<G-vec00003-002-s038><wait.abwarten><en> One option is to wait a preset time, for example at least two seconds.
<G-vec00003-002-s039><wait.abwarten><de> Bleibt abzuwarten, ob der Service auch nach der Lieferung so bleibt.
<G-vec00003-002-s039><wait.abwarten><en> Just need to wait to see if the service remains the same after the delivery.
<G-vec00003-002-s040><wait.abwarten><de> Um TachoReader Mobile II im Rechner installiert zu haben ist ausreichend, die Vorrichtung an den USB-Anschluß anzuschließen und abzuwarten, bis Windows die Installation selbsttätig ausführt.
<G-vec00003-002-s040><wait.abwarten><en> Installation procedure: 1. Plug TachoReader Mobile into a free USB port and wait until it is automatically detected and installed by Windows.
<G-vec00003-002-s041><wait.abwarten><de> Deshalb ist es wichtig, den Bericht der Troika abzuwarten, bevor entschieden wird.
<G-vec00003-002-s041><wait.abwarten><en> That’s why it’s important to wait for the troika report before making a decision.
<G-vec00003-002-s042><wait.abwarten><de> Es ist besser, seinen Brief abzuwarten.
<G-vec00003-002-s042><wait.abwarten><en> It's better to wait for his letter.
<G-vec00003-002-s043><wait.abwarten><de> So furchtbar war der Blick des Königs, den er auf den zitternden Geiseln während dieser Erzählung ruhen ließ, daß zwei derselben das Ende abzuwarten nicht ertrugen, sondern sich sofort an den harten Felswällen die Köpfe einrannten.
<G-vec00003-002-s043><wait.abwarten><en> The King fastened such a terrible look upon the trembling hostages, as they listened to this news, that two of them could not endure to wait till the end, but then and there killed themselves by dashing their heads against the stony walls which surrounded them.
<G-vec00003-002-s044><wait.abwarten><de> Auf meinen naiven Vorschlag, nach Hause zu gehen und abzuwarten, bis die Wehen wieder voll sind, nahm mich der Arzt mit in den Empfangsraum, um mich zu registrieren.
<G-vec00003-002-s044><wait.abwarten><en> On my naive suggestion to go home and wait until the contractions go to full strength, the doctor took me to the reception room to register.
<G-vec00003-002-s045><wait.abwarten><de> Daland beschließt, das Ende des Sturms hier abzuwarten und schickt die Mannschaft zur Ruhe.
<G-vec00003-002-s045><wait.abwarten><en> Daland decides to wait for the storm to abate and sends the crew to get some rest.
<G-vec00003-002-s046><wait.abwarten><de> Wir haben uns dann für eine Stunde in eine Café gesetzt, um abzuwarten, bis die Wohnung geputzt war und dann konnten wir rein.
<G-vec00003-002-s046><wait.abwarten><en> We then set for one hour in a cafe to wait until the apartment was cleaned and then we were able to clean.
<G-vec00003-002-s047><wait.abwarten><de> Auf dieser Grundlage erhielt der Kunde eine detaillierte Analyse, mit welchen Möglichkeiten dieses komplexe Migrationsprojekt möglichst klug umgesetzt werden kann – inklusive präziser und sauber begründeter Empfehlungen, wo Komponenten im Serienzustand belassen werden sollten, wo individuelle Anpassungen Sinn machen und wann es am Klügsten ist, die nächste herstellerseitige Weiterentwicklung abzuwarten.
<G-vec00003-002-s047><wait.abwarten><en> On this basis, the customer received an extensive analysis detailing the various options for how such a complex migration project could be implemented as smartly as possible – including specific and well-founded recommendations where components should be left in their standard versions, where individual customizations would make sense, and when it would be best to wait for further development by the manufacturer.
<G-vec00003-002-s048><wait.abwarten><de> Er wird nicht müde, auf uns zu warten, er entfernt sich nicht von uns, sondern er hat die Geduld, den günstigen Moment für die Begegnung mit einem jeden von uns abzuwarten.
<G-vec00003-002-s048><wait.abwarten><en> He never tires of waiting for us, he is never far from us, but he has the patience to wait for the best moment to meet each one of us.
<G-vec00003-002-s049><wait.abwarten><de> Die Zelte dieser Serie verwenden Materialien und Strukturen, die es Ihnen ermöglichen, eine warme Sommernacht bequem zu verbringen oder das strenge Wetter bei starkem Wind und Niederschlag abzuwarten.
<G-vec00003-002-s049><wait.abwarten><en> The tents of this series use materials and structures that allow you to comfortably spend a warm summer night or wait out the severe weather with strong wind and precipitation.
<G-vec00003-002-s050><wait.abwarten><de> Sollten Sie Ihren Wohnsitz in einem EU-Mitgliedsstaat haben, für das uns keine Bonitätsprüfung möglich ist, behalten wir uns vor, den Eingang Ihrer Zahlung oder die Bestätigung der Anweisung Ihrer Zahlung abzuwarten, ehe wir die Ware an Sie versenden.
<G-vec00003-002-s050><wait.abwarten><en> Should you be resident of an EU Member State for which we cannot carry out a credit check, we reserve the right to wait for the receipt of your payment or confirmation of the order of your payment before sending the goods to you.
<G-vec00003-002-s051><wait.abwarten><de> Nach ein paar Klicks braucht er nur abzuwarten, bis ihm von der Organisation bald ein passender Kandidat vorgestellt wird.
<G-vec00003-002-s051><wait.abwarten><en> After a few clicks, he just has to wait until IAESTE makes a proposal for a suitable candidate to him.
<G-vec00003-002-s052><wait.abwarten><de> Auf eine neue Version warten: Der beste Weg zum Lösen dieses Problems besteht darin, abzuwarten.
<G-vec00003-002-s052><wait.abwarten><en> Wait for a new version: The best way to overcome this problem is to wait.
<G-vec00003-002-s053><wait.abwarten><de> Er siegelte, schrieb die Adresse, ging dann mit leichten Schritten hinunter, lief bis zu dem weißen, kleinen Kasten an der Ecke der Gutsmauer, und nachdem er das Papier, das in seiner Hand zitterte, hineingeworfen, kehrte er schnell zurück, schloß die Riegel der großen Thür, und stieg hinauf in seinen Turm, um das Vorübergehen des Briefträgers abzuwarten, der sein Todesurteil mitnehmen sollte.
<G-vec00003-002-s053><wait.abwarten><en> Then he descended with light steps, hurried toward the little white box fastened to the outside wall in the corner of the farmhouse, and when he had thrown into it this letter, which made his hand tremble, he came back quickly, drew the bolts of the great door and climbed up to his tower to wait for the passing of the postman, who was to bear away his death sentence.
<G-vec00003-002-s054><wait.abwarten><de> Meistens wird ihr empfohlen, einen quälenden Kampf abzuwarten, der auf ihrer Seite auf dem Bett liegt.
<G-vec00003-002-s054><wait.abwarten><en> Most often, she is recommended to wait out an excruciating fight, lying on her side on the bed.
<G-vec00003-002-s055><wait.abwarten><de> Englisch, Essen & Trinken, Food, Fotografie, Herbst, Rezepte, regnet es wie aus Eimern, es ist kalt und im Schwarzwald liegt schon der erste Schnee – Zeit, den Backofen anzuwerfen, leckeres Teegebäck zu backen und bei einer Tasse Tee abzuwarten, bis es wieder besser wird.
<G-vec00003-002-s055><wait.abwarten><en> Serve with roast potatoes. Outside it is raining cats and dogs, it’s cold and in the Black Forest they have the first snow this fall – time to heat the oven and bake biscuits and wait on the sofa with a cup of tea until things are getting better.
<G-vec00003-002-s056><wait.abwarten><de> Wir freuen uns über Menschen, die die Zukunft für sich selbst gestalten möchten, anstatt abzuwarten, was die Zukunft bereithält.
<G-vec00003-002-s056><wait.abwarten><en> We welcome people who prefer to shape the future for themselves rather than wait and see what the future holds.
<G-vec00003-002-s257><wait.abwarten><de> Ich kann es kaum abwarten, die Stimmung im Olympischen Dorf zu genießen, wo alle Athleten gemeinsam wohnen werden, technisch gesehen sogar unter einem einzigen Dach, dem des Vortex-Gebäudes, das nach den Spielen als Studentenunterkunft dienen wird.
<G-vec00003-002-s257><wait.abwarten><en> I can’t wait to enjoy the atmosphere in the Youth Olympic Village where all the athletes will live together technically all under one roof in a newly built Vortex (which will serve as a student housing after the Games will be over).
<G-vec00003-002-s258><wait.abwarten><de> Hat man ein Stück von ihm zu Ende gehört, kann man es kaum abwarten, es gleich noch einmal zu hören.
<G-vec00003-002-s258><wait.abwarten><en> You listen to it, and when you’re finished you can’t wait to listen to it again.
<G-vec00003-002-s259><wait.abwarten><de> Es war Robert’s Idee gewesen, in die Kunstgalerie zu gehen (zu Neil’s und meiner Überraschung – Robert ist normalerweise nicht unbedingt der kunstbegeisterte Mensch), aber er war es auch, der mich förmlich durch das Museum schleifte, da er es kaum abwarten konnte, wieder rauszukommen (es war zugegebenermaßen auch wirklich heiß und stickig).
<G-vec00003-002-s259><wait.abwarten><en> It had been Robert’s idea to visit the gallery in the first place (to Neil’s and my mild surprise – Robert is usually not the most art-interested person), but it was him who literally dragged me through the museum as he couldn’t wait to get out again (mind you, it was really rather hot and sticky inside).
<G-vec00003-002-s260><wait.abwarten><de> Wirklich ein cooler Mix – ich kann es kaum abwarten, bis ich das wieder draußen tragen kann, ohne eine dicke Winterjacke darüber ziehen zu müssen.
<G-vec00003-002-s260><wait.abwarten><en> Quite a fun mix – can’t wait until I can wear this outfit without a winter jacket on top again!
<G-vec00003-002-s261><wait.abwarten><de> Ich kann es kaum abwarten, die anderen beiden Teile zu bekommen.
<G-vec00003-002-s261><wait.abwarten><en> I can’t wait to get the other two parts.
<G-vec00003-002-s262><wait.abwarten><de> Wir erforschen neue und bekannte Wege, um mit unserer Community zusammenzuarbeiten und können es kaum abwarten, unsere Pläne mit Euch zu teilen.
<G-vec00003-002-s262><wait.abwarten><en> We are exploring new and familiar ways to engage our community in 2019 and can’t wait to share our plans with you.”
<G-vec00003-002-s263><wait.abwarten><de> Ich denke er kann es kaum abwarten draußen zu spielen mit seinem neuem Fußball.
<G-vec00003-002-s263><wait.abwarten><en> I think he can't wait to play outside with his new soccer ball.
<G-vec00003-002-s264><wait.abwarten><de> Dank Zimt und Kardamom hat meine Küche so schön nach Weihnachten geduftet und ich konnte es kaum abwarten, es zu probieren.
<G-vec00003-002-s264><wait.abwarten><en> Tankst cinnamon and cardamom, my kitchen smelled like Christmas and I couldn’t wait to try it.
<G-vec00003-002-s265><wait.abwarten><de> Wir wussten, dass es schwer sein würde, aber mit der Vielfalt und anderen Lebensmitteln, die wir erhielten wir konnten es kaum abwarten, um loszulegen.
<G-vec00003-002-s265><wait.abwarten><en> We knew that it would be difficult, but with a variety of other foods that we received, we could not wait to start.
<G-vec00003-002-s266><wait.abwarten><de> Wir freuen uns sehr auf dieses Erweiterungspack und können es kaum abwarten, zu sehen, welche tollen Kreationen ihr erschaffen und welche wundervollen Geschichten ihr erzählen werdet.
<G-vec00003-002-s266><wait.abwarten><en> We’re really excited about this expansion, and can’t wait to see the amazing creations you’re going to make, and the wonderful stories you’re going to tell.
<G-vec00003-002-s267><wait.abwarten><de> New York fühlt sich mittlerweile wie mein zweites Zuhause an und ich kann es kaum abwarten, so schnell wie möglich wieder in meine Lieblingsstadt zu reisen.
<G-vec00003-002-s267><wait.abwarten><en> It somehow became my second home and I can’t wait to go back as soon as possible.
<G-vec00003-002-s268><wait.abwarten><de> Wir können kaum abwarten zu sehen, wie es funktioniert.
<G-vec00003-002-s268><wait.abwarten><en> We can’t wait to see how it performs.
<G-vec00003-002-s269><wait.abwarten><de> Ich bin absolut begeistert und kann es kaum abwarten ab September dort zu leben hihi.... obwohl ich schon ein bisschen nervös bin ganz allein in eine neue Stadt zu ziehen und eine Fernbeziehung führen zu müssen...
<G-vec00003-002-s269><wait.abwarten><en> I'm absolutely in love with it and can't wait to live there hihi... still I'm also a bit nervous to move to distant city... I will also be forced to survive a long-distance relationship...
<G-vec00003-002-s270><wait.abwarten><de> Wie im Fieber malte er meist, konnte kaum abwarten, das Bild, das sich seinem entladenen Blick bot, einzufangen, diesem entladenen, von denen Winden der Wanderungen rein geblasenen Blick, der mehr sieht als der andere taube Blick der anderen Menschen, der heller ist als der Blick der anderen... Hell seherisch...
<G-vec00003-002-s270><wait.abwarten><en> He painted as if in a fever, could not wait to capture the picture that presented itself to his discharging view, this discharging view that was blown inside by the winds of wanderings, that sees more than the dull gaze of other people, that was brighter than the gaze of others... prescient...
<G-vec00003-002-s271><wait.abwarten><de> Und schließlich denke ich, dass die Athleten, deren Wettkämpfe in St. Moritz stattfinden werden, eine einzigartige und unvergessliche olympische Erfahrung erleben werden und ich kann es kaum abwarten, sie zu besuchen.
<G-vec00003-002-s271><wait.abwarten><en> Lastly, I believe the athletes competing in St. Moritz will have a unique and unforgettable Olympic experience there and I can’t wait to visit them.
<G-vec00003-002-s272><wait.abwarten><de> Ich kann kaum abwarten wieder da zu sein, das wird ziemlich wahrscheinlich diesen Dezember sein... aber bis dahin möchte ich euch erst die ganzen Outfits zeigen, die ich jetzt im letzten Monat in Mexiko geshootet habe.
<G-vec00003-002-s272><wait.abwarten><en> I miss being in Mexico and I can't wait for the next time I go back, which will be this December... but until then, I still have a lot of outfits to show you which I shouted in Mexico:)
<G-vec00003-002-s273><wait.abwarten><de> Wir können kaum abwarten zu sehen, was sich Designer einfallen lassen und welche Möglichkeiten sie ausreizen werden.
<G-vec00003-002-s273><wait.abwarten><en> We can’t wait to see what designers are going to come up with and how they’re going to push the limits.
<G-vec00003-002-s274><wait.abwarten><de> Ich kann es kaum abwarten, diese neuen Gesteinsgänge in Streichrichtung zu untersuchen.
<G-vec00003-002-s274><wait.abwarten><en> I can’t wait to follow the new dykes along strike.
<G-vec00003-002-s275><wait.abwarten><de> Wir können es kaum abwarten, zu sehen, wie ihr damit umgeht, damit arbeitet, und wie ihr in der Welt, die euch umgibt, Magie erschafft.
<G-vec00003-002-s275><wait.abwarten><en> We can’t wait to watch to see how you deal with this, how you work with it, and how you create the magic in the world around you.
<G-vec00003-002-s445><wait.abwarten><de> Warte zehn Minuten lang ab und schau dann nach, ob sich der Sofastoff irgendwie verändert oder verfärbt hat.
<G-vec00003-002-s445><wait.abwarten><en> Wait 10 minutes and check to see if there has been any discoloration on the sofa fabric.
<G-vec00003-002-s446><wait.abwarten><de> Irgendwann sage ich mir, ich warte noch 3 Auto ab, dann gehe ich runter auf den Highway und versuche verbotenerweise dort mein Glück.
<G-vec00003-002-s446><wait.abwarten><en> At one point in time I tell myself to wait for another three cars before I try my luck directly on the highway.
<G-vec00003-002-s447><wait.abwarten><de> Warnungen Wenn du glaubst, ein Blutgerinnsel zu haben, warte nicht ab.
<G-vec00003-002-s447><wait.abwarten><en> Warnings If you think you have a blood clot, do not wait.
<G-vec00003-002-s448><wait.abwarten><de> Lege sie auf deine Augen und warte ab.
<G-vec00003-002-s448><wait.abwarten><en> Put them on your eyes, and wait.
<G-vec00003-002-s449><wait.abwarten><de> Warte bitte mindestens zwei Minuten lang ab, bevor du versuchst, dich noch einmal anzumelden.
<G-vec00003-002-s449><wait.abwarten><en> Please wait at least two minutes before trying to sign in again.
<G-vec00003-002-s450><wait.abwarten><de> Warte bis zum richtigen Moment und feuere den Ball dann ab.
<G-vec00003-002-s450><wait.abwarten><en> Wait until the right moment and then launch the ball.
<G-vec00003-002-s451><wait.abwarten><de> Solange er quicklebendig wirkt und frisst, warte ab und wiege ihn am nächsten Tag noch einmal.
<G-vec00003-002-s451><wait.abwarten><en> As long as the puppy is lively and feeding, wait and weigh him again the next day.
<G-vec00003-002-s452><wait.abwarten><de> Dann warte ich ab.
<G-vec00003-002-s452><wait.abwarten><en> Then I wait.
<G-vec00003-002-s453><wait.abwarten><de> Die roten Briefmarken werden getauscht, und ich warte ihren Empfang in einigen Tagen ab.
<G-vec00003-002-s453><wait.abwarten><en> The red stamps are being exchanged and I wait their reception in a few days.
<G-vec00003-002-s454><wait.abwarten><de> Teste die Kaffeemischung daher auf der Innenseite deines Handgelenkes oder deines Ellenbogens vor und warte 24 Stunden ab.
<G-vec00003-002-s454><wait.abwarten><en> Do a spot test with the coffee mixture on the inside of your wrist or elbow, and wait 24 hours.
<G-vec00003-002-s455><wait.abwarten><de> Warte zwischendurch ein bisschen ab, um den Würmern Zeit zu geben, sich im Rest des Kompost-Häufleins zu vergraben.
<G-vec00003-002-s455><wait.abwarten><en> Wait a while giving the worms time to burrow into the center of the mound.
<G-vec00003-002-s456><wait.abwarten><de> Ich warte wieder eine Feuerpause ab und renne, was das Zeug hält.
<G-vec00003-002-s456><wait.abwarten><en> I wait for another fire pause and run like hell.
<G-vec00003-002-s457><wait.abwarten><de> Warte mindestens 3 Stunden nach dem Essen ab, bevor du baden gehst.
<G-vec00003-002-s457><wait.abwarten><en> Wait at least three hours after a meal before going for a swim.
<G-vec00003-002-s458><wait.abwarten><de> Dann warte einfach ab.
<G-vec00003-002-s458><wait.abwarten><en> Then just wait.
<G-vec00003-002-s459><wait.abwarten><de> Aber im Moment musste sie den nervigen Floskeln Piccolos und Gohans zuhören… „Geduld, warte einfach ab“, predigten sie ihr vor, aber damit machten sie sie nur noch aufgekratzter.
<G-vec00003-002-s459><wait.abwarten><en> But for the moment, she’d have to listen to the sickening words of Gohan and Piccolo... “Patience, just wait a little bit,” they instructed, only succeeding in making her even more furious.
<G-vec00003-002-s460><wait.abwarten><de> Solltest du jemals das Gefühl haben, einen Rollstuhl bewegen zu müssen, bitte um Erlaubnis und warte die Antwort ab.
<G-vec00003-002-s460><wait.abwarten><en> If you ever feel the need to move someone’s wheelchair, you should ask permission first, and wait for their response.
<G-vec00003-002-s461><wait.abwarten><de> Warte die auf der Packung empfohlene Zeit ab.
<G-vec00003-002-s461><wait.abwarten><en> Wait for the time recommended on the package.
<G-vec00003-002-s462><wait.abwarten><de> Warte ab, bis du an die Reihe kommst.
<G-vec00003-002-s462><wait.abwarten><en> Wait until it's your turn.
<G-vec00003-002-s537><wait.abwarten><de> Sie warten dafür nur günstige Ereignisse ab — einen Augenblick, gleich dem von 1848, in dem sie sich auf die Zertrümmerung der bestehenden Regierung stürzen können — mit der Hoffnung, von einer internationalen Bewegung unterstützt zu werden.
<G-vec00003-002-s537><wait.abwarten><en> They but wait for a favorable opportunity — a chance, such as presented itself in 1848, when they will be able to start the destruction of the present economic system, with the hope of being supported by an International movement.
<G-vec00003-002-s538><wait.abwarten><de> Warten Sie lieber ab und sehen Sie aus sicherer Entfernung zu, wie sich ein neuer Malt entwickelt.
<G-vec00003-002-s538><wait.abwarten><en> You should rather wait and watch from a safe distance how a new malt develops.
<G-vec00003-002-s539><wait.abwarten><de> Wir mussten etwas warten, aber dann war er ab, die Nabelschnur.
<G-vec00003-002-s539><wait.abwarten><en> We had to wait a little longer, but finally the umbilical cord was gone.
<G-vec00003-002-s540><wait.abwarten><de> Schuldner stellen sich auf diese Systematik ein und warten dann häufig die letzte mögliche Frist ab.
<G-vec00003-002-s540><wait.abwarten><en> Debtors adapt to this systematic approach and then often wait until the last possible deadline.
<G-vec00003-002-s541><wait.abwarten><de> Falls das Bedienungspersonal aus arbeitsbedingten Gründen nicht bei der gegenständlichen Kasse anwesend ist, warten Sie bitte die Rückkehr dieses Mitarbeiters ab (oder kontaktieren Sie diesen gegebenenfalls telefonisch unter der angeführten Nummer).
<G-vec00003-002-s541><wait.abwarten><en> If the service personnel is not present at the service counter for other work-related reasons, you must wait for this employee to return (or contact him/her using a specified telephone number, if applicable).
<G-vec00003-002-s542><wait.abwarten><de> Ich würde sogar soweit gehen zu sagen, dass er einer der mutigsten und inspiriertesten Designer seit Alexander McQueen sein könnte, aber warten wir einmal ab, welche fantastischen Dinge sich Leandro Cano als nächstes ausdenkt.
<G-vec00003-002-s542><wait.abwarten><en> I might even go as far as to call him one of the the most daring and inspired designers since Alexander McQueen, but let's wait and see what amazing things Leandro Cano comes up with next.
<G-vec00003-002-s543><wait.abwarten><de> Vielleicht warten Sie auch prinzipiell immer den letzten Moment ab, um zu reservieren.
<G-vec00003-002-s543><wait.abwarten><en> Or perhaps you just prefer to wait until the last minute to reserve.
<G-vec00003-002-s544><wait.abwarten><de> "Nun, warten Sie's nur ab, was Sie hier in den Ställen zu sehen kriegen.
<G-vec00003-002-s544><wait.abwarten><en> "Well," said Dawson, "you just wait till you've seen what's in the stables.
<G-vec00003-002-s545><wait.abwarten><de> Bei persönlicher Abholung warten Sie bitte unsere SMS-Nachricht ab, dass die Ware zur Abholung bereit liegt.
<G-vec00003-002-s545><wait.abwarten><en> If you chose in-person pickup, please wait for the text message we will send you as soon as your order is ready.
<G-vec00003-002-s546><wait.abwarten><de> So wartet nur ab, wir warten mit euch ab.
<G-vec00003-002-s546><wait.abwarten><en> So wait (expectant); we too will wait with you."
<G-vec00003-002-s547><wait.abwarten><de> Heute bleiben wir hier und warten ab, bis sich das Sturmtief weiter nach Norden verzogen hat.
<G-vec00003-002-s547><wait.abwarten><en> Today we keep hiding in this bay and wait until the nasty depression moves away to the north.
<G-vec00003-002-s548><wait.abwarten><de> Warten Sie bitte ab, bis auf Ihrem Konto neue Bewegungen (Gutschriften, Belastungen) stattgefunden haben und versuchen Sie es auf dem darauf folgendem Tag.
<G-vec00003-002-s548><wait.abwarten><en> Please wait until there are new transactions on your account (credits, debits) and try to reconcile the transactions again after that.
<G-vec00003-002-s549><wait.abwarten><de> Ich frage mich - warten wir die Haltung der Kommission ab -, ob wir die Schlussabstimmung nicht vertagen sollten.
<G-vec00003-002-s549><wait.abwarten><en> wonder - but we shall wait for the Commission - if we need to postpone the final vote.
<G-vec00003-002-s550><wait.abwarten><de> Warten wir mal ab, wann es Realität wird.
<G-vec00003-002-s550><wait.abwarten><en> Let's wait and see when this becomes reality.
<G-vec00003-002-s551><wait.abwarten><de> Wir sollten nicht sagen, wir machen Demonstrationen oder wir warten ab, bis jemand verhaftet wird.
<G-vec00003-002-s551><wait.abwarten><en> We should not just say “Oh, we will make a demonstration!” or we will wait until somebody gets arrested.
<G-vec00003-002-s552><wait.abwarten><de> Aber warten wir die offizielle Ankündigung ab.
<G-vec00003-002-s552><wait.abwarten><en> But we stay and wait for the official announcement.
<G-vec00003-002-s553><wait.abwarten><de> Picard: Warten wir ab wie lange "Solitaire" die Funktionalitaet der Borg einschraenken kann.
<G-vec00003-002-s553><wait.abwarten><en> Picard:Lets wait and see how long this Solitaire can reduce their functionality.
