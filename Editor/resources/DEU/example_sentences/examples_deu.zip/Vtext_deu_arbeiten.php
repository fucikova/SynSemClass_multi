<G-vec00301-001-s019><work_out.arbeiten><de> Mit diesen Empfindungen vertraue ich eure Arbeit dem Schutz Mariens an und erteile euch allen den Apostolischen Segen.
<G-vec00301-001-s019><work_out.arbeiten><en> With these sentiments, as I entrust your work to Mary's protection, I impart the Apostolic Blessing to you all.
<G-vec00301-001-s020><work_out.arbeiten><de> Zwar gibt es einige Zeugnisse von Personen, die PhenQ behaupten, dass sie nicht mehr benötigen erarbeiten aufgrund der Tatsache, dass sie zusätzlich auf seine eigene Arbeit zu erwerben Ursprung, medizinische Fachleute empfehlen, immer noch, dass ein Training mit der richtigen Diät-Schema fertig eingebaut werden während der Einnahme diese Ergänzung für garantierte Ergebnisse.
<G-vec00301-001-s020><work_out.arbeiten><en> Though there are some evaluations coming from those that purchase PhenQ stating that it doesn't need anymore exercising due to the fact that it could likewise work on its own, physicians still advise that a workout be performed combined with proper diet plan while taking this supplement for ensured outcomes.
<G-vec00301-001-s021><work_out.arbeiten><de> In der Schule wird der Unterricht von einem rhythmischen Wechsel der Grundformen des Gesprächs, des Spiels, der Arbeit und der Feier bestimmt.
<G-vec00301-001-s021><work_out.arbeiten><en> In the school teaching and learning are shaped by a rhythmic alternation of the basic-activities dialogue, play, work and celebration.
<G-vec00301-001-s022><work_out.arbeiten><de> Die Aufrechterhaltung der 100 % Spendenweiterleitung bedeutet für die Freunde der Erziehungskunst, dass ihre Arbeit, d.h. die Spendenverwaltung, -weiterleitung, die Projektbegleitung und Öffentlichkeitsarbeit nicht automatisch gesichert sind.
<G-vec00301-001-s022><work_out.arbeiten><en> Adhering to the principle of forwarding 100% of donations means that the budget for our work, e.g. administration of the donation process, consulting of projects, and public relations is not automatically ensured.
<G-vec00301-001-s023><work_out.arbeiten><de> Viele Menschen, die bereits meine Arbeit durch Etsy können sich jetzt mit Leichtigkeit Shop, mit der indischen Währung.
<G-vec00301-001-s023><work_out.arbeiten><en> Many people who are already following my work through Etsy can now shop with ease, using the Indian currency.
<G-vec00301-001-s024><work_out.arbeiten><de> In diesem Fall sollte man sich mit dem weiteren Teil unseres Artikels bekannt machen, wo wir Lösungen für die meisten Probleme darstellen, die bei dem Versuch der Arbeit mit einer neuen Extension auftauchen können, zu welcher FOB gehört.
<G-vec00301-001-s024><work_out.arbeiten><en> In such a case, refer to the next part of our article, where we present solutions to most problems that may occur when you try to work with the new file extension, which is the FOB.
<G-vec00301-001-s025><work_out.arbeiten><de> Andererseits, die Kritiker bemerken die schöne Arbeit an der Auslese der Schauspieler.
<G-vec00301-001-s025><work_out.arbeiten><en> On the other hand, critics note fine work on casting.
<G-vec00301-001-s026><work_out.arbeiten><de> Gustav Deutschs Arbeit kann als Reminiszenz und Hommage an die Geschichte(n) des Films und des Kinos verstanden werden – unter besonderer Berücksichtigung des Landes mit der weltweit größten Filmproduktion.
<G-vec00301-001-s026><work_out.arbeiten><en> Gustav Deutsch's work can be understood as a reminiscence of and homage to the history of film and cinema – under special consideration of the country with the world's largest film production.
<G-vec00301-001-s027><work_out.arbeiten><de> Bevor ich genau erkläre, wie ich GoogleCash für freies erhielt, müssen Sie verstehen den Hintergrund von, was diese scharfsinnige Erwerb Strategie Arbeit bildet.
<G-vec00301-001-s027><work_out.arbeiten><en> Before I explain exactly how I got GoogleCash for free, you need to understand the background of what makes this ingenious purchase strategy work.
<G-vec00301-001-s028><work_out.arbeiten><de> Wir haben ihn bei der Arbeit im Stall gefilmt.
<G-vec00301-001-s028><work_out.arbeiten><en> We filmed him during work in the cowshed.
<G-vec00301-001-s029><work_out.arbeiten><de> Ausgangspunkt ihrer Arbeit ist oft das stumme Vermächtnis der Architektur historischer Orte und Mahnmale.
<G-vec00301-001-s029><work_out.arbeiten><en> The starting point of her work is often the silent legacy of the architecture of historical locations and monuments.
<G-vec00301-001-s030><work_out.arbeiten><de> Dies führte ihn zur Arbeit über die Verbindung bewteen Sylvester 's Formeln auf die Polynome die sich bei der Anwendung der Sturm's Theorem und der Theorie der Fraktionen fortgesetzt.
<G-vec00301-001-s030><work_out.arbeiten><en> This led him to work on the connection between Sylvester 's formulas on the polynomials arising in the application of Sturm's theorem and the theory of continued fractions.
<G-vec00301-001-s031><work_out.arbeiten><de> In dieser Arbeit gilt Kantorowitsch Optimierung Techniken zu einer breiten Palette von Problemen in der Wirtschaft.
<G-vec00301-001-s031><work_out.arbeiten><en> In this work Kantorovich applies optimisation techniques to a wide range of problems in economics.
<G-vec00301-001-s032><work_out.arbeiten><de> Nach dem Bearbeiten herauf das Problem, im Fall des Elektrikers sollten Änderungen in der normalen Arbeit Periode geringe Wirkung auf seiner Fähigkeit haben, die notwendige Reparatur durchzuführen, da sie ihm nur fünf oder 10 Minuten dauern sollte, um diese Arbeit durchzuführen.
<G-vec00301-001-s032><work_out.arbeiten><en> In the electrician's case, changes in the normal work period should have little effect on his ability to make the necessary repair since it should take him only five or ten minutes to complete this work after sizing up the problem.
<G-vec00301-001-s034><work_out.arbeiten><de> National Space Centre unternimmt diese Arbeit im Auftrag der Handelspartner.
<G-vec00301-001-s034><work_out.arbeiten><en> National Space Centre is undertaking this work on behalf of a commercial partner.
<G-vec00301-001-s035><work_out.arbeiten><de> Ich stamme aus den Vogesen, einer von harter Arbeit geprägten Region, und liebe Rigorosität und Präzision.
<G-vec00301-001-s035><work_out.arbeiten><en> I am from the Vosges, a region known for its work ethic and I like rigour and precision.
<G-vec00301-001-s036><work_out.arbeiten><de> Subversion ist nicht schlau genug, um diese Arbeit für Sie zu übernehmen[10], so dass Sie Ihre Änderungen manuell übertragen müssen.
<G-vec00301-001-s036><work_out.arbeiten><en> Subversion isn't smart enough to do this work for you[10], so you need to migrate your changes manually.
<G-vec00301-001-s037><work_out.arbeiten><de> Und es könnte keine Befriedigung geben, wenn man Männern, die aus einem anderen Grund als ihrer Kenntnis des Themas ausgewählt wurden, Arbeit anvertrauen.
<G-vec00301-001-s037><work_out.arbeiten><en> And there could be no satisfaction in entrusting work to men who were chosen for any other reason than their knowledge of the subject.
<G-vec00301-001-s038><work_out.arbeiten><de> Arbeite besser und schneller dank dieses leistungsstarken Multifunktionswerkzeugs.
<G-vec00301-001-s038><work_out.arbeiten><en> Work better and faster with this high-performance Multi-Tool.
<G-vec00301-001-s039><work_out.arbeiten><de> Er arbeite aber weiterhin als Priester in einer Gemeinde, der viele junge Nonnen angehörten.
<G-vec00301-001-s039><work_out.arbeiten><en> But he continues to work as a priest in a parish that has many young nuns as members.
<G-vec00301-001-s040><work_out.arbeiten><de> Detail: die eine habe ich hat nur einen 16 MHz Kristall, Während die anderen ich habe und arbeite haben einen 16 MHz-Kristall auf dem Arduino und anderen 12 MHz Kristall auf die Mitteilung der auf dem chip.
<G-vec00301-001-s040><work_out.arbeiten><en> Detail: the one I have has only a 16 MHz crystal, While the other I have and work have a 16 MHz crystal to the arduino and other 12 MHz crystal to the on-chip communication.
<G-vec00301-001-s041><work_out.arbeiten><de> Ich wohne und arbeite dort.
<G-vec00301-001-s041><work_out.arbeiten><en> I live and work directly there.
<G-vec00301-001-s042><work_out.arbeiten><de> Ich selbst benutze die Armlehne vor oder hinter mir, wenn ich mit den Patienten rede, und als Seitenstütze, wenn ich im Mund des Patienten arbeite.
<G-vec00301-001-s042><work_out.arbeiten><en> I myself use the armrest in front of or behind me when I talk to the patients and as a side support when I work in the patient's mouth.
<G-vec00301-001-s043><work_out.arbeiten><de> Ich zum Beispiel arbeite in unserem Gesundheitszentrum, mache dort Massagen und Hydrotherapie.
<G-vec00301-001-s043><work_out.arbeiten><en> I work in our health center and do massages and hydrotherapy.
<G-vec00301-001-s044><work_out.arbeiten><de> Ich bin sehr dankbar, dass ich mit einem wirklich internationalen Team von Leuten arbeite, die begeistert von Sprachen und vom Reisen sind und die Ihr Bestes geben, um unseren Nutzern im Lernprozess zu helfen.
<G-vec00301-001-s044><work_out.arbeiten><en> I'm really thankful to work alongside a truly international team of people who are passionate about languages and travel, and who are dedicated to helping our users through the learning process.
<G-vec00301-001-s045><work_out.arbeiten><de> Und daher meditiere ich hier und arbeite auf der Ebene des moralischen Charaktersdaran, mich selbst zu verbessern – es ist Teil dessen, was wir täglich tun.
<G-vec00301-001-s045><work_out.arbeiten><en> And so here, I meditate and work on improving myself at the level of moral character—it’s part of what we do daily.
<G-vec00301-001-s046><work_out.arbeiten><de> Ich lebe und arbeite seit 36 Jahren mit meiner Partnerin, Sabine Lichtenfels, zusammen.
<G-vec00301-001-s046><work_out.arbeiten><en> I live and work with my partner, Sabine Lichtenfels, for 36 years.
<G-vec00301-001-s047><work_out.arbeiten><de> Beide Lampen arbeite bei 127V oder 220V.
<G-vec00301-001-s047><work_out.arbeiten><en> Both lamps work at 127V or 220V.
<G-vec00301-001-s048><work_out.arbeiten><de> Da ich zu Hause arbeite, kann es vorkommen, dass ich einen Tag frei nehme, um etwas anderes zu erledigen (es ist oftmals besser, Dinge unter der Woche zu erledigen); aber ich versuche, dies am Wochenende wieder nachzuholen.
<G-vec00301-001-s048><work_out.arbeiten><en> As I work at home, it could happen than I take a day off to do something else (often better to do stuffs during the week), but I try to get it back on the week-end.
<G-vec00301-001-s049><work_out.arbeiten><de> Ich arbeite als Freiwilliger für medizinische Transportdienste und Katastrophenschutzdienste beim Italienischen Roten Kreuz.
<G-vec00301-001-s049><work_out.arbeiten><en> I work as a volunteer for medical transportation services, and Civil Protection services in the Italian Red Cross.
<G-vec00301-001-s050><work_out.arbeiten><de> »Pater, müssen wir dafür denn kein Dokument unterzeichnen?« – »Lass dich vom Heiligen Geist vorantreiben, bete, arbeite, liebe, dann wird der Geist das Übrige tun!« Dieser Gnadenstrom durchzieht alle christlichen Konfessionen, erreicht alle, die an Christus glauben.
<G-vec00301-001-s050><work_out.arbeiten><en> To go together towards unity. “But Father, do we have to sign a document for this?” — “Let yourself be carried forward by the Holy Spirit: pray, work, love and then the Spirit will do the rest!”.
<G-vec00301-001-s051><work_out.arbeiten><de> Deshalb arbeite ich weiter, auch wenn es für eine Klobürste ist.
<G-vec00301-001-s051><work_out.arbeiten><en> That's why I continue to work, even if it's for toilet brush.
<G-vec00301-001-s052><work_out.arbeiten><de> Ich arbeite bei der Firma Anton Paar, wo mich meine Kollegen fÃ1⁄4r meine kunden- und lösungsorientierte Herangehensweise bei der Konzipierung und Umsetzung von modernen Vertriebsstrategien schätzen.
<G-vec00301-001-s052><work_out.arbeiten><en> I work for the Austrian company Anton Paar where my colleagues appreciate my customer-oriented and pragmatic approach to the conception and implementation of modern sales strategies.
<G-vec00301-001-s053><work_out.arbeiten><de> "Trotz allem blieb sie an der Hochschule – und fand ihre Nische in der ""Strafkolonie"" der Filmakademie, dem Fachbereich Wirtschafts- und Gesellschaftsfilm, ""wo keiner hin wollte außer mir und meiner Kommilitonin Felicia Zeller, mit der ich die Zeit in Ludwigsburg gemeinsam überstanden habe und bis heute zusammen arbeite – und verwechselt werde"", wie Pfaus lachend erzählt."
<G-vec00301-001-s053><work_out.arbeiten><en> "Despite everything, she remained at the academy and found her niche in its ""penal colony"", the department of business and social film, ""which nobody wanted to be part of except me and my fellow student Felicia Zeller, with whom I survived my time in Ludwigsburg, and who I still work with – and am often mistaken for – today"", Pfaus explains with a laugh."
<G-vec00301-001-s054><work_out.arbeiten><de> Ich arbeite meistens mit VIP und versuche, so nützlich für unsere Kunden wie möglich zu sein.
<G-vec00301-001-s054><work_out.arbeiten><en> I work mostly with VIP and try to be as useful to our customers as possible.
<G-vec00301-001-s055><work_out.arbeiten><de> Ich schnappe mir nur kurz meinen NFC -Mantel aus der mobilen Robotergarderobe hier im Cyberterror-Abwehrzentrum, wo ich arbeite, und dann fahren wir auch schon los.
<G-vec00301-001-s055><work_out.arbeiten><en> Let me just get my NFC coat from the mobile robotic coat check here at the Cyberterror Defense Center, where I work, and then we'll be on our way.
<G-vec00301-001-s056><work_out.arbeiten><de> Jetzt arbeite ich die ganze Nacht im Garten und es gefällt mir gut.
<G-vec00301-001-s056><work_out.arbeiten><en> Now, I work the whole night in the garden and I like it.
<G-vec00057-001-s027><volunteer.arbeiten><de> Du wirst in einem öffentlichen Kindergarten mit Kindern zwischen 3 und 5 Jahren arbeiten.
<G-vec00057-001-s027><volunteer.arbeiten><en> You will volunteer in a public kindergarten with children from 3 to 5 years old.
<G-vec00057-001-s028><volunteer.arbeiten><de> Wenn Sie 5 Tage oder weniger arbeiten möchten, gibt es keine Platzierungsgebühr: Nur eine Spende von $10 pro Tag (Studenten) oder $30 pro Tag (Nicht-Studenten).
<G-vec00057-001-s028><volunteer.arbeiten><en> The only exception to these fees is when you volunteer for 5 days or less in which case there is no placement fee: only a $10 USD per day (students) or $30 USD per day (non students) fee.
<G-vec00057-001-s029><volunteer.arbeiten><de> Das Budget von 14,7 Milliarden Euro bietet jungen Generationen die Möglichkeit, zu studieren, zu trainieren, Erfahrungen zu sammeln und im Ausland zu arbeiten.
<G-vec00057-001-s029><volunteer.arbeiten><en> Its budget of €14.7 billion will provide opportunities for young generations to study, train, gain experience, and volunteer abroad.
<G-vec00057-001-s030><volunteer.arbeiten><de> Das gilt für vorhandene Strukturen (Häuser für alleinstehende Mütter, Krankenhäuser und Altenheime, Hilfs- und Beratungsstellen); für die Förderung von Vereinigungen und Bewegungen, die für das Leben arbeiten; es gilt für die Bedeutung des Freiwilligendienstes, für die Notwendigkeit eines verstärkten Einsatzes im Erziehungs- und Bildungswesen und in der Verkündigung der Lehre der Kirche, auch durch Bekämpfung der Propaganda der sozialen Kommunikationsmittel; es gilt, Einfluß im kulturellen, wirtschaftlichen und politischen Bereich zu gewinnen auch durch das direkte und verantwortliche Engagement der Christen in diesem Umfeld.
<G-vec00057-001-s030><volunteer.arbeiten><en> In this regard, the measures and initiatives planned and those partly realised are significant, for example: establishing organised structures (houses for single mothers; houses for the sick and elderly; centres of assistance and counsel); promoting associations and movements on behalf of human life; fostering volunteer programs; emphasising the necessity of a major commitment to educating and preaching on the teachings of the Church and to counteracting the negative effects of the means of social communications; and highlighting the importance of finding ways to have greater influence on behalf of human life–through the direct activity of Christians–in the cultural, economic and political spheres.
<G-vec00057-001-s031><volunteer.arbeiten><de> Kontaktiere die Organisation, um als Coach zu arbeiten und mit den Kindern zu arbeiten.
<G-vec00057-001-s031><volunteer.arbeiten><en> Contact the organization to volunteer as a coach and work with the children.
<G-vec00057-001-s032><volunteer.arbeiten><de> Bitte geben Sie bei der Anmeldung an, in welchem Bereich Sie arbeiten möchten.
<G-vec00057-001-s032><volunteer.arbeiten><en> When registering, please include which area you want to volunteer in.
<G-vec00057-001-s033><volunteer.arbeiten><de> Verztec ist stolz auf seine engagierten Mitarbeiter, die sich seit Januar 2013 die Zeit genommen haben, zusammen mit Vertretern der LCSS und anderen Freiwilligen in einem Organisationskomitee zur Planung und Durchführung des Spendenlaufs zu arbeiten.
<G-vec00057-001-s033><volunteer.arbeiten><en> Verztec is proud to have various passionate team members who have taken time to volunteer on personal basis as part of the event organising committee, alongside representatives from LCSS and many other like-minded volunteers in planning and organising for the event since early January 2013.
<G-vec00301-001-s057><work_out.arbeiten><de> Obwohl JCO auf japanische Unternehmen spezialisiert ist, arbeiten wir ebenfalls viel mit öffentlichen Stellen und nicht-japanischen Firmen zusammen, die mit Japan Handel treiben und/oder mit japanischen Kunden, Zulieferern oder Partnern zu tun haben.
<G-vec00301-001-s057><work_out.arbeiten><en> While we specialize in working with Japanese companies, we also work with non-Japanese companies doing business with Japan, Japanese clients, suppliers or partners.
<G-vec00301-001-s058><work_out.arbeiten><de> Die praktischen Arbeiten wurden auf der Expedition mit dem chinesischen Forschungsschiff FENDOU-5 im September 2009 und der SONNE SO219 im Dezember 2011 durchgeführt.
<G-vec00301-001-s058><work_out.arbeiten><en> The field work took place during two expeditions with Chinese (FENDOU5 in September 2009) and German (SONNE SO219 in December 2011) vessels.
<G-vec00301-001-s059><work_out.arbeiten><de> Inoffiziell habe ich erfahren, daß eine ausführliche Abhandlung mit Einzelheiten über diese Arbeiten von Harrer oder der WRG herausgebracht werden soll.
<G-vec00301-001-s059><work_out.arbeiten><en> Informally, I have learned that a larger paper may be published by Harrer, or by the Reich Society, detailing this same work.
<G-vec00301-001-s060><work_out.arbeiten><de> Wenn statt des Vaters nun Vater, Mutter und zwei Kinder arbeiten, so ist der Gesammtlohn in den meisten Fällen höher, als früher der Lohn des Vaters allein.
<G-vec00301-001-s060><work_out.arbeiten><en> When, instead of the father, the father, mother, and two children work, the total wage is in most cases higher than the previous wage of the father alone.
<G-vec00301-001-s061><work_out.arbeiten><de> Die Times Square Furcht ist eine außer Kontrollereaktion durch Plakatwandcoderegler, die nicht völlig verstehen, wie LED-Digitale-Plakatwände arbeiten, da gemerktes Frietas, „Digitale-Plakatwände wirklich kein unterschiedliches als ihre Druckgegenstücke sind, ausgenommen sie sich mehrmals hintereinander durch verschiedene Werbungs-Nachrichten drehen.
<G-vec00301-001-s061><work_out.arbeiten><en> The Times Square fear is an out of hand reaction by sign code regulators who don’t fully understand how electronic LED billboards work as Frietas noted, “electronic billboards are really no different than their print counterparts except they successively rotate through different advertising messages.
<G-vec00301-001-s062><work_out.arbeiten><de> Eine Schale in der Schale ist eine besondere Herausforderung an den Drechsler, da er sehr genau arbeiten muss und der Deckel, in den die zweite Schale hineinkommt, entsprechend dünn sein muss.
<G-vec00301-001-s062><work_out.arbeiten><en> A special challenge for a turner is a bowl within a bowl. He needs to work highly exact and the lid, holding the second bowl, should be relatively delicate.
<G-vec00301-001-s063><work_out.arbeiten><de> Lasst uns gemeinsam vieles Neues ausprobieren und fleißig an unseren Qualitäten arbeiten.
<G-vec00301-001-s063><work_out.arbeiten><en> Let us together try many new things and diligently work on our qualities.
<G-vec00301-001-s064><work_out.arbeiten><de> Dieses anspruchslose Tier wird von seinem Herrn angetrieben, sehr schwer zu arbeiten.
<G-vec00301-001-s064><work_out.arbeiten><en> This humble beast is made to work very hard by his master.
<G-vec00301-001-s065><work_out.arbeiten><de> EFI™ Großformatdrucker sind die perfekten Lösungen, um einen eigenen Geschäftsbereich für großformatige Anwendungen aufzubauen, neue Märkte und neue Einnahmequellen zu erschließen oder ausgelagerte Arbeiten zurückzuholen.Sowohl die Hybriddrucker – Flachbettdrucker mit Rollenoption – eignen sich ideal für Drucke in Über- und Sondergrößen und tragen dank schnellem Kundenservice und hoher Bildqualität zur Steigerung der allgemeinen Kundenzufriedenheit und der Rentabilität bei.
<G-vec00301-001-s065><work_out.arbeiten><en> EFI™ Wide Format UV printers are a great way to enter into the wide-format display graphics printing business, for tapping into new markets and new revenue streams, and reclaiming outsourced work. Our hybrid flatbed/roll-to-roll printers are ideal for overflow and specialty printing, and for print businesses looking to increase customer satisfaction and profitability with quick service and high image quality.
<G-vec00301-001-s066><work_out.arbeiten><de> Abstrakte Gemälde und farbgewaltige Landschaftsmalerei läuten bei der „Kunst am Isartor“ mit den Arbeiten von Barbara Bernrieder den Frühling ein.
<G-vec00301-001-s066><work_out.arbeiten><en> Abstract paintings and vibrantly colourful landscapes herald springtime at Kunst am Isartor (Art at the Isartor) with the work of Barbara Bernrieder.
<G-vec00301-001-s067><work_out.arbeiten><de> PhenQ ist auf der offiziellen Website bestätigt, um als Fettheizung, Stoffwechsel-Booster und einem Heißhunger suppressant arbeiten.
<G-vec00301-001-s067><work_out.arbeiten><en> PhenQ is declared on the main website to work as a fat heater, metabolic rate booster and a cravings suppressant.
<G-vec00301-001-s068><work_out.arbeiten><de> Er zwingt die Häftlinge, als Sklaven zu arbeiten, die sich ständig über das Erreichen ihrer Quoten sorgen.
<G-vec00301-001-s068><work_out.arbeiten><en> He forces detainees to work as slaves, who worry constantly about finishing their quotas.
<G-vec00301-001-s069><work_out.arbeiten><de> Wir arbeiten ausschließlich mit Qualitätsherstellern mit ADW-Zulassung zusammen, die in den Vd-TÜV Blättern gelisted sind.
<G-vec00301-001-s069><work_out.arbeiten><en> We work exclusively with quality ADW-approved manufacturers which are listed in the Vd-TÜV datasheets.
<G-vec00301-001-s070><work_out.arbeiten><de> All diese Bausteine sind Teil unseres umfassenden Systemangebots, mit dem wir Handwerkern effizientes Arbeiten ermöglichen.
<G-vec00301-001-s070><work_out.arbeiten><en> All of these modules are part of our comprehensive system offer, with which we enable professional tradespeople to work efficiently.
<G-vec00301-001-s071><work_out.arbeiten><de> Neben einem festangestellten Team, das wir weiter ausbauen möchten, arbeiten wir bei Bedarf auch mit Partnern zusammen.
<G-vec00301-001-s071><work_out.arbeiten><en> Beneath our own staff, which we want to enlarge, we pleasantly work together with partners.
<G-vec00301-001-s072><work_out.arbeiten><de> Sie arbeiten in einem unserer Projektteams und vertiefen ihre Erfahrung.
<G-vec00301-001-s072><work_out.arbeiten><en> They work in one of our project teams and deepen their experience.
<G-vec00301-001-s073><work_out.arbeiten><de> Das gelingt uns einerseits, indem wir unser Wissen über Prozesse und Werkstoffe stetig an die nachfolgende Generation weitergeben und andererseits aktiv an unseren Stärken arbeiten.
<G-vec00301-001-s073><work_out.arbeiten><en> In this way we can not only pass on our knowledge about processes and materials to the following generation but also actively work in improving our skills.
<G-vec00301-001-s074><work_out.arbeiten><de> Das Studium befähigt die Studierenden dazu, im Bereich des Sportmanagements an forschungs- oder anwendungsorientierten Projekten zu arbeiten sowie spezifische Forschungs- und Entwicklungsfragestellungen an dieser Schnittstelle zu entwickeln und zu bearbeiten.
<G-vec00301-001-s074><work_out.arbeiten><en> The program enables the students to work on research or application-oriented projects in the field of sports management and to develop and work on specific research and development problems at this interface.
<G-vec00301-001-s075><work_out.arbeiten><de> Ob Sie eine Offshore Plattform bauen oder an einem Raffinerie Shutdown arbeiten, sie kämpfen täglich damit die Ausfallzeiten zu reduzieren.
<G-vec00301-001-s075><work_out.arbeiten><en> Whether you build an offshore platform or you work on a refinery shutdown, you fight daily for reducing operational downtime.
<G-vec00301-001-s076><work_out.arbeiten><de> Verpflanzendes Moos normalerweise arbeitet, nicht sogar in den idealen Bedingungen.
<G-vec00301-001-s076><work_out.arbeiten><en> Transplanting moss usually doesn't work, even in ideal conditions.
<G-vec00301-001-s077><work_out.arbeiten><de> Wenn man ein paar Wochen intensiv damit arbeitet, sind die Buchstaben ganz leicht zu lesen.
<G-vec00301-001-s077><work_out.arbeiten><en> If you work with it intensively for a few weeks it becomes really easy to read.
<G-vec00301-001-s078><work_out.arbeiten><de> In dem Tages-Camp in den Sommerferien arbeitet ein Team von 14 bis 16 Betreuern vier Wochen lang mit 20 Kindern, die zwischen sieben und zehn Jahren alt sind, an den Problemen der ADHS-Kernsymptomatik Aufmerksamkeitsdefizit, Hyperaktivität und Impulsivität.
<G-vec00301-001-s078><work_out.arbeiten><en> In the four-week day camp during the summer break, a team of 14 to 16 counsellors work with 20 children between the ages of 7 and 10 on the problems associated with the core ADHD symptoms: attention deficit, hyperactivity and impulsivity.
<G-vec00301-001-s079><work_out.arbeiten><de> Zusätzlich lässt sie Sie Dateien aufteilen, um sie leichter zu übertragen und arbeitet mit mehr Sicherheit mit Antiviren-Programmen.
<G-vec00301-001-s079><work_out.arbeiten><en> In additional, it lets you split files to transfer them more easily and to work with antivirus programs with greater security.
<G-vec00301-001-s080><work_out.arbeiten><de> Kraftwerk Erde Unser Planet arbeitet: Die Sonne treibt Wind, Wellen und den Wasserkreislauf an.
<G-vec00301-001-s080><work_out.arbeiten><en> Our planet is at work: The sun drives the wind, the waves and the water cycle.
<G-vec00301-001-s081><work_out.arbeiten><de> Die Quanten-Physik jagt nach Sub-Elementarteilchen, arbeitet mit rein fiktiven Begriffen und ist ´stolz´ darauf, dass sie mit ´normaler´ Anschauung nicht mehr zu verstehen sei.
<G-vec00301-001-s081><work_out.arbeiten><en> Quant-physicists hunt for sub-elementary-particles, work with pure fictive terms and are ´proud´ these ideas are not to be grasped by ´normal´ understanding.
<G-vec00301-001-s082><work_out.arbeiten><de> "Sogar wenn man Vishnu auf seiner Seite hat, Mahadeva auf seiner Seite ist, trotzdem sitzt Shri Ganesha dort und er sagt:"" Nein, nicht bei ihm aufsteigen"", es arbeitet nicht aus, es ist sehr schwierig."
<G-vec00301-001-s082><work_out.arbeiten><en> "Even if you have Vishnu on your side, Mahadeva on your side, but if Shri Ganesha is there sitting and He says ""no, not his ascent"", it doesn ́t work out, it ́s very difficult."
<G-vec00301-001-s083><work_out.arbeiten><de> Unser Gott arbeitet nicht mit den Hochmütigen zusammen.
<G-vec00301-001-s083><work_out.arbeiten><en> Our God does not work with the haughty.
<G-vec00301-001-s084><work_out.arbeiten><de> Er arbeitet mit drei Kollegen zusammen.
<G-vec00301-001-s084><work_out.arbeiten><en> “I work with three colleagues.
<G-vec00301-001-s085><work_out.arbeiten><de> Zur Bestätigung einer hohen Qualität unserer Erzeugnisse arbeitet Granpol eng mit dem Industriellen Lederindustrieinstitut in £ód¼ sowie mit dem Institut für Erdöl und Gas sowie Institut der Erdölindustrie Krakow zusammen.
<G-vec00301-001-s085><work_out.arbeiten><en> To maintain high quality of our products we work closely with the Institute of Leather Industry in £odz, Central Laboratory of Footwear Industry in Kraków and with the Institute of Oil Industry in Krakow.
<G-vec00301-001-s086><work_out.arbeiten><de> Im Rahmen dieser Schwerpunkte arbeitet die Creative Industries Styria nach außen – in die Betriebe – und nach innen – in die kreative Szene –, mit dem Ziel, die Faktoren für eine schnellere Entwicklung der Unternehmen aus beiden Sektoren zu optimieren.
<G-vec00301-001-s086><work_out.arbeiten><en> Within these focal points, Creative Industries Styria work externally for the companies and internally for the creative scene, with the goal of optimizing the factors fostering a faster development of the enterprises coming from both sectors.
<G-vec00301-001-s087><work_out.arbeiten><de> Ebenso, wenn Sie sich finden, mehr als Sie aufzuwenden Ausgabe Furcht, Groll und Jagen sein zu wünschen, nachdem das Geld nicht normalerweise arbeitet.
<G-vec00301-001-s087><work_out.arbeiten><en> Likewise when you find yourself spending more than you want to be spending fear, resentment and chasing after the money does not usually work.
<G-vec00301-001-s088><work_out.arbeiten><de> """Semenax wirklich arbeitet, mein ejackulation ist viel erfreulicher, nun da ich soviel mehr schießen kann seimen häufig."
<G-vec00301-001-s088><work_out.arbeiten><en> """Semenax really does work, my ejackulation is much more enjoyable now that I can shoot so much more seimen more often."
<G-vec00301-001-s089><work_out.arbeiten><de> Es wird eine schnelle Entwicklung der Wirtschaft und Kultur geben, weil das erste Mal in der Geschichte der Menschheit, die Mehrheit der Menschen wirklich für sich selbst arbeitet.
<G-vec00301-001-s089><work_out.arbeiten><en> Socialism will be accompanied by a rapid development of the economy and culture because, for the first time in the history of humanity, the majority of the people will really work for themselves.
<G-vec00301-001-s090><work_out.arbeiten><de> Dann arbeitet ihr von dieser Position der Stärke aus weiter.
<G-vec00301-001-s090><work_out.arbeiten><en> Then you work from that position of strength.
<G-vec00301-001-s091><work_out.arbeiten><de> Geht und arbeitet.
<G-vec00301-001-s091><work_out.arbeiten><en> Go and work.
<G-vec00301-001-s092><work_out.arbeiten><de> "Sollten Sie keinen Zugriff auf Ihren Rechner haben, weil Sie den Login-Mode ""Nur Fingerabdruck"" gewählt haben und deshalb der Passwort-Mode nicht arbeitet, starten Sie den PC im Abgesicherten Modus und benutzen Sie das Passwort für die Standard-Windows-Anmeldung um dann die Datei ~ArchProp.arp zu löschen."
<G-vec00301-001-s092><work_out.arbeiten><en> "If you have set the login mode to ""fingerprint only"" so that the password option does not work, start the PC in safe mode and use the password for the standard Windows login before deleting ~ArchProp.arp."
<G-vec00301-001-s093><work_out.arbeiten><de> Im Oberflächlichen, wenn ihr arbeitet um Geld zu verdienen, werdet ihr der MAYA begegnen.
<G-vec00301-001-s093><work_out.arbeiten><en> In the mundane, when you work to earn money, you will encounter the maya.
<G-vec00301-001-s094><work_out.arbeiten><de> High Five: skurrile Wohnideen aus Europa Mitten im Grünen - eine Familie hat sich in einem Gewächshaus eingepflanzt Familie Till lebt dort, wo sie auch arbeitet.
<G-vec00301-001-s094><work_out.arbeiten><en> High Five: 5 unusual ways of living in Europe Their own backyard: they planted themselves in a greenhouse The Till family lives where they work.
<G-vec00057-001-s181><volunteer.arbeiten><de> Wenn Sie mit Ihrer Familie freiwillig arbeiten möchten, schicken Sie bitte Ihr Freiwilligeninterview.
<G-vec00057-001-s181><volunteer.arbeiten><en> If you would like your family to volunteer, please submit your volunteering interview.
<G-vec00057-001-s182><volunteer.arbeiten><de> Der Erasmus+OLS wurde dafür entworfen, um Erasmus+ Teilnehmer dabei zu begleiten, ihre Kenntnisse der Sprache, in der sie arbeiten, studieren oder freiwillig arbeiten werden, vor oder während ihres Auslandsaufenthalts zu verbessern, um eine bessere Qualität der Lernmobilität zu gewährleisten.
<G-vec00057-001-s182><volunteer.arbeiten><en> TheErasmus+OLS has been designed to assist Erasmus+ participants in improving their knowledge of the language in which they will work, study or volunteer, before and during their stay abroad, to ensure a better quality of learning mobility.
<G-vec00057-001-s183><volunteer.arbeiten><de> Sollte Jean Todt tatsächlich freiwillig arbeiten und Malaysias Tourismusbranche unentgeltlich unterstützen, können sich die Malaysier glücklich schätzen, denn Herr Todt ist ein internationaler VIP.
<G-vec00057-001-s183><volunteer.arbeiten><en> If Jean Todt really is a volunteer and will support Malaysia’s tourism industry for free, the Malaysians can consider themselves lucky, because Mr Todt is an international VIP.
<G-vec00057-001-s184><volunteer.arbeiten><de> Du kannst überall freiwillig arbeiten, von der Suppenküche bis hin zum Altersheim, und dabei auf direktem Wege neue Leute kennenlernen.
<G-vec00057-001-s184><volunteer.arbeiten><en> You can volunteer everywhere from soup kitchens to hospice services and directly meet people who you help.
<G-vec00057-001-s185><volunteer.arbeiten><de> Obwohl die meisten Mitwirkenden freiwillig arbeiten, ist ein Projekt wie Piwigo nicht kostenlos: Webserver, Domainnamen, Entwicklungszeit oder Webseitenverwaltung.
<G-vec00057-001-s185><volunteer.arbeiten><en> Although animated by a largely volunteer community of contributors, a project like Piwigo is not free to run: web servers, domain names, development time or website management.
<G-vec00221-002-s057><function.arbeiten><de> Jeder Roboter trägt Motoren, die für die verschiedenen Bewegungen koordiniert arbeiten müssen.
<G-vec00221-002-s057><function.arbeiten><en> Each robot carries motors that must function in coordination to carry out the various movements.
<G-vec00221-002-s058><function.arbeiten><de> Die Stütz Ergänzung in Frage ist eine Ergänzung, die die Fähigkeit zu arbeiten, gerade in dem Hauptkern des Bodybuilding hat, vor allem: Das Hormon Testosteron.
<G-vec00221-002-s058><function.arbeiten><en> The supporting supplement in question is a supplement that has the ability to function specifically generally core of bodybuilding, specifically: The hormone Testosterone.
<G-vec00221-002-s059><function.arbeiten><de> Registerreinigungsmittel helfen Ihrem PC, richtig zu arbeiten und Registerreinigungsmittel ermitteln Störungen und löschen und/oder regeln sie.
<G-vec00221-002-s059><function.arbeiten><en> Registry cleaners help your PC function properly and registry cleaners detect errors, and deletes and/or fixes them.
<G-vec00221-002-s060><function.arbeiten><de> Das (menschlicher Körper-Temperatur-Schirm-Gesichtsanerkennung) messende Gewehr der traditionellen Infrarottemperatur erfordert eine Person, an geschlossener Strecke zu arbeiten.
<G-vec00221-002-s060><function.arbeiten><en> The(Human Body Temperature Screen Facial Recognition) traditional infrared temperature measuring gun requires a person to function at shut range.
<G-vec00221-002-s061><function.arbeiten><de> Gäste mit Auslastungen von unter 100% sollten mit dieser Konfiguration effektiv arbeiten können.
<G-vec00221-002-s061><function.arbeiten><en> Guests with less than 100% loads should function effectively in this setup. Important
<G-vec00221-002-s062><function.arbeiten><de> Explosionsgeschützte GreenTech EC-Ventilatoren mit integrierter Elektronik arbeiten in Gefahrenzonen mit hoher Effizienz.
<G-vec00221-002-s062><function.arbeiten><en> Explosion-proof GreenTech EC fans with integrated electronics function at high efficiency in hazardous zones.
<G-vec00221-002-s063><function.arbeiten><de> Um schnell und effizient zu arbeiten, versucht Hiprolean XS, alle Gewichtsverlust Probleme sofort zu bekämpfen.
<G-vec00221-002-s063><function.arbeiten><en> In order to function quick and successfully, Hiprolean X-S attempts to battle all weight loss problems at once.
<G-vec00221-002-s064><function.arbeiten><de> Fluoxymesterone arbeitet, indem er viele Körpersysteme beeinflußt, damit der Körper normalerweise sich entwickeln und arbeiten kann.
<G-vec00221-002-s064><function.arbeiten><en> Fluoxymesterone works by affecting many body systems so that the body can develop and function normally.
<G-vec00221-002-s065><function.arbeiten><de> Nur sehr erfahrene Karte Zähler sind in der Lage, diese Wette sich arbeiten zu lassen, und selbst dann ist es noch ein Trottel Wette.
<G-vec00221-002-s065><function.arbeiten><en> Only extremely experienced card counters are able to make this bet function for them, and more often than not then it remains a sucker bet.
<G-vec00221-002-s066><function.arbeiten><de> In Mehrpunktanlagen (MPI) arbeiten oft beide zusammen.
<G-vec00221-002-s066><function.arbeiten><en> In Multipoint systems (MPI) the two often function together.
<G-vec00221-002-s067><function.arbeiten><de> Alle diätetische Erzeugnisse auf dem Markt in Tessin Schweiz verspricht gute Ergebnisse, aber nicht alle von ihnen arbeiten und viele haben sogar schwerwiegende Nebenwirkungen.
<G-vec00221-002-s067><function.arbeiten><en> All nutritional items out there in Kriens Switzerland promising fantastic results, but not all of them function and several also have serious side effects.
<G-vec00221-002-s068><function.arbeiten><de> Mit allen drei Geräten kann man gleich schnell und sicher arbeiten.
<G-vec00221-002-s068><function.arbeiten><en> All three beacons, without exception, have the ability to function quickly and safely.
<G-vec00221-002-s069><function.arbeiten><de> Alle diätetische Erzeugnisse auf dem Markt in Fribourg Schweiz verspricht gute Ergebnisse, aber nicht alle von ihnen arbeiten und viele haben sogar schwerwiegende Nebenwirkungen.
<G-vec00221-002-s069><function.arbeiten><en> All diet products available in Frauenfeld Switzerland appealing terrific outcomes, but not all of them function and many even have significant side effects.
<G-vec00221-002-s070><function.arbeiten><de> Die von uns geförderten Trinkwasseraufbereitungs-Anlagen sind solarbetrieben und arbeiten ganz ohne extern zugeführte Energie und zugesetzte Chemikalien.
<G-vec00221-002-s070><function.arbeiten><en> The water treatment plans that we fund are solar powered and function without any external power or added chemicals.
<G-vec00221-002-s071><function.arbeiten><de> Mit iWork for iCloud können mehrere Benutzer als ein kollektives Team arbeiten und als ein einziges arbeiten.
<G-vec00221-002-s071><function.arbeiten><en> With iWork for iCloud multiple users can function as a collective team and work as one.
<G-vec00221-002-s072><function.arbeiten><de> Eine Fettpresse kommt zur Rettung, wenn es erforderlich ist, mit Ölzusammensetzungen von komplexen Anordnungen und Strukturelementen der Aggregate zu arbeiten, die im Modus des erhöhten Verschleißes arbeiten.
<G-vec00221-002-s072><function.arbeiten><en> A grease gun comes to the rescue when it is necessary to treat with oil compositions of complex assemblies and structural elements of the aggregates that function in the mode of increased wear.
<G-vec00221-002-s073><function.arbeiten><de> Das Unternehmen bietet auch 60 Tage Geld-zurück – Garantie, wenn diese Tablette nicht für Sie arbeiten.
<G-vec00221-002-s073><function.arbeiten><en> The company likewise provides 60 days money-back service warranty if this supplement does not function for you.
<G-vec00221-002-s074><function.arbeiten><de> Sie arbeiten in sieben Gruppen, deren jede eng mit den dienenden Engeln des Seraphischen Korps der Vollendung verbunden ist.
<G-vec00221-002-s074><function.arbeiten><en> They function in seven groups, each of which is closely associated with the Son-Spirit Ministers.
<G-vec00221-002-s075><function.arbeiten><de> FIPA Vakuumstationen mit zwei- oder drei Vakuumpumpen arbeiten als redundante Vakuumsysteme und ermöglichen durch ein Bypass-System die Wartung während des Betriebs.
<G-vec00221-002-s075><function.arbeiten><en> FIPA vacuum stations with two or three vacuum pumps function as redundant vacuum systems and use a bypass system to enable maintenance while operating.
<G-vec00221-002-s095><operate.arbeiten><de> Nenndurchfluss: 50L / MIN-Kopf Entlastung: 6,0 m Saughöhe: 7.5m Solid Größe: 35mm Motor Größe: 0,75 kW Ungefähre Verdrängung pro Hub: 1,5 l Gewicht: 42 kg Maximale Außenabmessungen: 400mm x 335mm x 410mm (LxBxH) Saughöhen bis 7,5 m Schnelle selbstansaugende Wird ohne Schaden trocken laufen Wird auf schnarchen arbeitet abrasiven Flüssigkeiten handhaben werden Feststoffe bis zu 80% der Anschlussgröße Schwerlast-, kompakte Bauweise TEFC Elektromotoren passieren als Standard für spezielle Elektromotor-Remko .
<G-vec00221-002-s095><operate.arbeiten><en> Aluminium/Buna construction Pump Specifications: Nominal Flow Rate: 50L/MIN Discharge Head: 6.0m Suction Lift: 7.5m Solid Size: 35mm Motor Size: 0.75kw Approximate Displacement Per Stroke: 1.5L Weight: 42kg Maximum outside dimensions: 400mm x 335mm x 410mm (LxWxH) Suction lifts to 7.5m Rapid self priming Will run dry without damage Will operate on snore Will handle abrasive liquids Will pass solids up to 80% of port size Heavy duty, compact construction TEFC electric motors fitted as standard Special electric motor enclosures as an option
<G-vec00221-002-s096><operate.arbeiten><de> Der Miele Solo-Dampfgarer arbeitet ohne Druck im Temperaturbereich von 40-100°C.
<G-vec00221-002-s096><operate.arbeiten><en> Miele steam ovens operate without pressure in a temperature range of 40 – 100°C.
<G-vec00221-002-s097><operate.arbeiten><de> Auch unser Kundendienst arbeitet in einem gesicherten privaten Netz.
<G-vec00221-002-s097><operate.arbeiten><en> Our customer service center and stores also operate over a private, secure network.
<G-vec00221-002-s098><operate.arbeiten><de> Diese Mehrwertdienste sorgen dafür, dass Ihre HANA-Datenbank noch jahrelang einwandfrei arbeitet.
<G-vec00221-002-s098><operate.arbeiten><en> These value-added services ensure your HANA Database will operate smoothly for years to come.
<G-vec00221-002-s099><operate.arbeiten><de> Falls ein Lüfter ausfällt oder die Temperatur steigt, erhöhen die temperaturgesteuerten Lüfter entsprechend ihre Drehzahl, damit das Gerät unterbrechungsfrei arbeitet.
<G-vec00221-002-s099><operate.arbeiten><en> If a fan fails or the temperature rises, the smart fans will increase their speed accordingly to ensure the device continues to operate without downtime.
<G-vec00221-002-s100><operate.arbeiten><de> TerraSAR-X arbeitet unabhängig von Wetterbedingungen, Wolkenbedeckung und Tageslicht und ist in der Lage, Radardaten mit einer Auflösung von bis zu einem Meter zu liefern.
<G-vec00221-002-s100><operate.arbeiten><en> TerraSAR-X will operate independent of weather conditions, cloud coverage or lighting and will supply radar data at a Communications and Radar Optics
<G-vec00221-002-s101><operate.arbeiten><de> Dieser Parameter bewirkt, dass der Mikroprozessor immer mit höchstmöglicher Leistung arbeitet.
<G-vec00221-002-s101><operate.arbeiten><en> none - Causes the microprocessor to operate at the highest performance state at all times
<G-vec00221-002-s102><operate.arbeiten><de> › Gigaset TP-LINK arbeitet im deutschen Markt ab sofort mit Gigaset zusammen.
<G-vec00221-002-s102><operate.arbeiten><en> With immediate effect TP-LINK will operate in the German market with Gigaset.
<G-vec00221-002-s103><operate.arbeiten><de> Zwar werden keine Daten an die Monitoring-Software übertragen, aber die Anlage arbeitet dennoch normal weiter.
<G-vec00221-002-s103><operate.arbeiten><en> Although no data is transferred to the monitoring software, the asset continues to operate normally.
<G-vec00221-002-s104><operate.arbeiten><de> Die Prozesssteuerung ist so ausgelegt, dass sie zyklisch arbeitet, um das definierte Rezept wiederholt auszuführen, wobei jede Ausführung weiterhin als Zyklus bezeichnet wird.
<G-vec00221-002-s104><operate.arbeiten><en> The process control is designed to operate in a cyclic manner, to repetitively execute the defined recipe, each execution further denoted as cycle.
<G-vec00221-002-s105><operate.arbeiten><de> In Kühlräumen arbeitet eine gute Beleuchtung zuverlässig und stellt trotz tiefer Umgebungstemperaturen innerhalb kurzer Zeit die volle Lichtstärke zur Verfügung.
<G-vec00221-002-s105><operate.arbeiten><en> In cold rooms, a good lighting system should operate reliably and provide full luminous intensity within only a short time despite low ambient temperatures.
<G-vec00221-002-s106><operate.arbeiten><de> Dafür versammelte er internationales Expertenteam, das die Aufgabe hatte, einen Turboverdichter zu entwickeln, der bei hoher variabler Drehzahl arbeitet, extrem effizient ist, kein Öl benötigt, leicht, leise und kosteneffizient ist.
<G-vec00221-002-s106><operate.arbeiten><en> He assembled a world-class international team of experts with a mission to develop a centrifugal compressor that would operate at high variable speeds, be extremely efficient, oil free, lightweight, quiet and cost competitive.
<G-vec00221-002-s107><operate.arbeiten><de> 16 Ist das Gerät eingeschaltet und sind sowohl das zeitgesteuerte Ein- als auch das zeitgesteuerte Ausschalten eingestellt, arbeitet das System der ausgewählten Betriebsart entsprechend.
<G-vec00221-002-s107><operate.arbeiten><en> When the unit is on and Timer On and Timer Off are both set, the system will operate according to the set state.
<G-vec00221-002-s108><operate.arbeiten><de> Wenn es zu Kondensatbildung gekommen ist, arbeitet das Gerät nicht mehr ordnungsgemäß, und Wiedergabe ist nicht möglich.
<G-vec00221-002-s108><operate.arbeiten><en> When condensation is present, this unit will not operate properly and playback is not possible.
<G-vec00221-002-s109><operate.arbeiten><de> Nicht alle importierten Gassäulen sind daran angepasst.Viele Modelle versagen, wenn Überspannungen (was für uns nicht ungewöhnlich ist), um den Druck des Wassers empfindlich sind, Gasdruckminderer konfiguriert "falsch" und dergleichen.Es ist notwendig, sofort zu bestimmen, welchen Wert der Druck des "blauen" Kraftstoff in der Leitung Einheit stabil arbeitet.
<G-vec00221-002-s109><operate.arbeiten><en> Not all imported gas columns are adapted to them.Many models fail when surges (which is not uncommon for us), are sensitive to the pressure of water, gas reducer configured "wrong" and the like.It is necessary to immediately determine at what value the pressure of the "blue" fuel in the line unit will operate stably.
<G-vec00221-002-s110><operate.arbeiten><de> Aktivitäten bei der Beendigung des Modus der Erneuerung des Kältemittels: Die Inneneinheit arbeitet in Übereinstimmung mit der letzten Einstellung von der Fernbedienung.
<G-vec00221-002-s110><operate.arbeiten><en> Action of exit refrigerant recovery mode: the indoor fan will operate according to the last remote control setting. 15.
<G-vec00221-002-s111><operate.arbeiten><de> Die höchste Umgebungstemperatur, bei der erwartet wird, dass die Komponente sicher arbeitet.
<G-vec00221-002-s111><operate.arbeiten><en> The highest ambient temperature at which the component is expected to operate safely.
<G-vec00221-002-s112><operate.arbeiten><de> Fortan arbeitet das Unternehmen als IBC SOLAR AG.
<G-vec00221-002-s112><operate.arbeiten><en> The company will operate as IBC SOLAR AG from now on.
<G-vec00221-002-s113><operate.arbeiten><de> Wenn sich die Xbox 360 Konsole im Standbymodus befindet oder nicht mit dem Netzteil verbunden ist, arbeitet der Lüfter nicht.
<G-vec00221-002-s113><operate.arbeiten><en> When your Xbox 360 console is in standby mode or when the console is disconnected from the PSU, the fan does not operate.
<G-vec00273-002-s035><toil.arbeiten><de> In einem Land wie Indien, in dem die Mehrzahl in ländlichen Gebieten lebt und arbeitet muss das Bankwesen "personenorientiert" und nicht "profitorientiert" sein.
<G-vec00273-002-s035><toil.arbeiten><en> In a country like India, where the majority live and toil in rural areas, banking must be ‘people oriented not profit oriented’.
<G-vec00273-002-s209><work.arbeiten><de> Die im Eigenschafteneditor angezeigten Werte gehören zum aktiven Objekt des aktiven Dokuments (Vorsicht ist geboten, welches Dokument gerade aktiv ist, wenn mit mehreren Dokumenten gearbeitet wird).
<G-vec00273-002-s209><work.arbeiten><en> The values shown in the Property Editor belong to the active object of your active document (be careful of which document is really active if you work on multiple documents).
<G-vec00273-002-s210><work.arbeiten><de> Die Konferenz hat gezeigt, dass an den Schnittstellen zwischen Richtlinien, Projekten und allgemeinen Verfahrensweisen noch gearbeitet werden muss – zwischen diesen Bereichen müssen Durchgänge geschaffen werden und zwar im Rahmen einer breiteren nationalen Strategie.
<G-vec00273-002-s210><work.arbeiten><en> The conference showed that there is a need to further work on the interface between policy, projects and mainstream practice - gateways between these strands should be created; and this should happen in the context of a broader national strategy.
<G-vec00273-002-s211><work.arbeiten><de> Beurteilung jeder Person, um heraus zu finden, auf welchem Level er/sie sich befindet und woran gearbeitet werden muss.
<G-vec00273-002-s211><work.arbeiten><en> Evaluation of each surfer to know exactly which level he or she has and which points to work on.
<G-vec00273-002-s212><work.arbeiten><de> Mit Blick auf jüngere Generationen sollten herkömmliche Bürokonzepte jedoch überdacht werden, denn heute wird von diesen mehr projektbezogen und in Teams gearbeitet.
<G-vec00273-002-s212><work.arbeiten><en> Looking at younger generations, however, traditional office concepts should be reviewed, because they tend to work more on individual projects and in teams.
<G-vec00273-002-s213><work.arbeiten><de> Als Schüler hatte Knoefel hier gearbeitet, und es war gewiß in seiner Erinnerung ein Platz, an dem hart gearbeitet wurde.
<G-vec00273-002-s213><work.arbeiten><en> When he was at school, Knoefel used to work here, and he is likely to remember it as a place where people worked hard.
<G-vec00273-002-s214><work.arbeiten><de> Scherz: Beim osteuropäischen Markt besteht der Vorteil, dass in diesen Märkten auch von österreichischen Standorten aus gearbeitet werden kann.
<G-vec00273-002-s214><work.arbeiten><en> Scherz: The advantage of the Eastern European market is that it is also possible to work from Austrian locations in these markets.
<G-vec00273-002-s215><work.arbeiten><de> In den Anzeigentexten wird mit der dynamischen Keyword-Insertion und Ad-Parametern gearbeitet.
<G-vec00273-002-s215><work.arbeiten><en> In the ad text we will use and work with the dynamic keyword insertion and ad parameters.
<G-vec00273-002-s216><work.arbeiten><de> Feuerwehrleute, Rennsport-Piloten und Arbeiter aus Industrien, in denen mit Gas, Öl oder Chemie gearbeitet wird, sehen sich stets akuter Brandgefahr ausgesetzt.
<G-vec00273-002-s216><work.arbeiten><en> Firefighters, motorsports people and workers in industries such as gas, oil or chemical work in environments where there is a risk of garment ignition.
<G-vec00273-002-s217><work.arbeiten><de> So wird nicht nur an der Senkung der durch den Luftverkehr verursachten Emissionen gearbeitet, sondern auch am hochautomatisierten Fahren für die Mobilität der Zukunft, kostengünstigen Energiespeichern und der Umweltüberwachung zum Schutz der Atmosphäre.
<G-vec00273-002-s217><work.arbeiten><en> The work includes not only the reduction of emissions caused by air transport, but also highly automated travel for the mobility of the future, cost-effective energy storage solutions and environmental monitoring for the protection of the atmosphere.
<G-vec00273-002-s218><work.arbeiten><de> An jedem Teil wird einzeln gearbeitet.
<G-vec00273-002-s218><work.arbeiten><en> We'll work on each part separately.
<G-vec00273-002-s219><work.arbeiten><de> Es wird viel praktisch gearbeitet und man kommt recht bald über die normalen Anwendungen mit dem eigenen Rechners hinaus.
<G-vec00273-002-s219><work.arbeiten><en> There is a lot of practical work to be done and one soon goes beyond the normal applications with one's own computer.
<G-vec00273-002-s220><work.arbeiten><de> Genauso gut kann auch anders herum gearbeitet werden, damit die Ergebnisse variieren.
<G-vec00273-002-s220><work.arbeiten><en> However, to add variety to your artwork, you can just as well work the other way around.
<G-vec00273-002-s221><work.arbeiten><de> Hier kann gegessen, geredet, gefeiert und gearbeitet werden, hier kann man sich aber auch zurückziehen und hier begegnen sich Ästhetik und Geschmack.
<G-vec00273-002-s221><work.arbeiten><en> Here – where aesthetics meet taste – one can eat, talk, celebrate, and work, but also find peace and quiet.
<G-vec00273-002-s222><work.arbeiten><de> Er wäre ein guter Radiomoderator, dachte ich mir dabei im Verlaufe des Abends noch und fand heraus, dass er tatsächlich mal beim Radio gearbeitet hatte.
<G-vec00273-002-s222><work.arbeiten><en> He would be a good radio host, I thought during this evening, and found out that he actually used to work on the radio before.
<G-vec00273-002-s223><work.arbeiten><de> Dadurch wird effizienter gearbeitet, was sich positiv auf die Durchlaufzeit auswirkt.
<G-vec00273-002-s223><work.arbeiten><en> Because of this, the work process is very efficiently, which has a positive effect on the processing time.
<G-vec00273-002-s224><work.arbeiten><de> Zuerst hatten sie nebeneinander gearbeitet, aber dann war Jerry der Ansicht gewesen, dass sie sich aufteilen und auf unterschiedlichen Abschnitten des Felds suchen sollten.
<G-vec00273-002-s224><work.arbeiten><en> They’d started off walking side by side but then Jerry said they should split up and work different sections of the field.
<G-vec00273-002-s225><work.arbeiten><de> 3 Und die Ältesten der Stadt, die am nächsten bei dem Erschlagenen liegt, sollen eine junge Kuh nehmen, mit der noch nicht gearbeitet wurde [und] die noch an keinem Joch gezogen hat.
<G-vec00273-002-s225><work.arbeiten><en> 3 And the elders of the city which is nearest to the slain man shall take a heifer which has never been used for work nor has pulled in the yoke,
<G-vec00273-002-s226><work.arbeiten><de> Es wird dann aufgeschlagen, wenn mit den Bildern, Texten, Dialogen, Übungen und anderen Aktivitäten gearbeitet wird.
<G-vec00273-002-s226><work.arbeiten><en> It is only consulted when they work with the pictures, texts, dialogs, exercises and other activities it contains.
<G-vec00273-002-s227><work.arbeiten><de> Eines ist sicher – wir haben weiterhin P2P-Investitionen als sicheres und bewährtes Instrument für alternative Finanzierungen etabliert und daran gearbeitet, die Bequemlichkeit unserer Plattform zu verbessern.
<G-vec00273-002-s227><work.arbeiten><en> One thing is certain – we continued to establish P2P investment as a safe and proven tool for alternative funding and to work on improving the convenience of our platform.
<G-vec00319-002-s033><collaborate.arbeiten><de> Sie arbeiten mit dem Unternehmen zusammen, um die IT-Anforderungen zu erfüllen und Projekte abzustimmen, und arbeiten mit anderen Führungskräften zusammen, um eine breitere Roadmap und Strategie zu definieren.
<G-vec00319-002-s033><collaborate.arbeiten><en> You work with the business to meet IT requirements and align projects and collaborate with other leaders to define the broader roadmap and strategy.
<G-vec00319-002-s034><collaborate.arbeiten><de> Nach dieser Erfahrung arbeiten die Kinder jedes Jahr an der Erstellung eines Berichts mit, der jährlich an das Umweltministerium geschickt wird, um den Zustand des Meeresökosystems in einem solchen neuralgischen Gebiet des Mittelmeers zu überwachen, das viel über die Gesundheit dieses Meeres zu sagen hat .
<G-vec00319-002-s034><collaborate.arbeiten><en> Every year after this experience, the children collaborate in the production of a report that is sent annually to the Ministry of the Environment, so as to monitor the state of the marine ecosystem of such a neuralgic area of the Mediterranean that has much to say about the health of this sea.
<G-vec00319-002-s035><collaborate.arbeiten><de> Sie tourten mit dem Dichter Robert Pinsky durch 14 Städte, arbeiten regelmäßig mit der ungarischen Folkloregruppe Muzsikas zusammen, und 2010 arbeiteten sie mit dem Colorado Shakespeare Festival und David Lawrence Morse an einem Theaterprojekt, das die Komposition von Beethovens letzten Quartetten untersuchte.
<G-vec00319-002-s035><collaborate.arbeiten><en> They have toured 14 cities with the poet Robert Pinsky, collaborate regularly with the Hungarian Folk group Muzsikas, and in 2010 they collaborated with the Colorado Shakespeare Festival and David Lawrence Morse on a drama project that explored the composition of Beethoven's last quartets.
<G-vec00319-002-s036><collaborate.arbeiten><de> Aus diesem Grund arbeiten wir mit dem Verein Torrecat zusammen, der sich dem Schutz und der Kontrolle der Kolonien von frei lebenden Katzen im Gebiet von Torredembarra widmet.
<G-vec00319-002-s036><collaborate.arbeiten><en> To do this, we collaborate with Torrecat, an association dedicated to protecting and controlling the colony of stray cats in the […] Where we are
<G-vec00319-002-s037><collaborate.arbeiten><de> Jeden Monat arbeiten wir mit verschiedenen Wohltätigkeitsorganisationen zusammen, um Schulen zu bauen, Mahlzeiten anzubieten oder die Umwelt zu schützen.
<G-vec00319-002-s037><collaborate.arbeiten><en> Every month we collaborate with different charities, to build schools, provide meals or to protect the environment.
<G-vec00319-002-s038><collaborate.arbeiten><de> Das Resultat begeisterte die Battles dermaßen, das man sich gegenseitig einlud, miteinander zu arbeiten.
<G-vec00319-002-s038><collaborate.arbeiten><en> The Battles were so impressed with the result that they and Punkt decided to collaborate.
<G-vec00319-002-s039><collaborate.arbeiten><de> Sie arbeiten eng mit Kolleginnen und Kollegen im In- und Ausland zusammen und entwickeln sich mit unserer Hilfe zu Experten in Ihrem Bereich.
<G-vec00319-002-s039><collaborate.arbeiten><en> You will collaborate closely with colleagues in Germany as well as abroad and will develop into experts in your field of activity with our assistance.
<G-vec00319-002-s040><collaborate.arbeiten><de> Der Text des Chorals gehörte zu einem nie vollendeten Weihnachtsoratorium, an dem Britten und Auden gemeinsam hatten arbeiten wollen.
<G-vec00319-002-s040><collaborate.arbeiten><en> The Chorale’s text was part of an unachieved Christmas Oratorio on which Britten and Auden intended to collaborate.
<G-vec00319-002-s041><collaborate.arbeiten><de> Gemeinsames Arbeiten in Meisterplan wird jetzt sehr viel einfacher – dank erweiterter Benutzerrechte.
<G-vec00319-002-s041><collaborate.arbeiten><en> With our new extended user rights, it is now much easier to collaborate with others in Meisterplan.
<G-vec00319-002-s042><collaborate.arbeiten><de> Unser Ideal wäre aber, mit wenigstens der doppelten Anzahl Versuchspersonen arbeiten zu können.
<G-vec00319-002-s042><collaborate.arbeiten><en> However, it is our ideal to be able to collaborate with at least twice as many test subjects, to gather a sample that is more representative.
<G-vec00319-002-s043><collaborate.arbeiten><de> Die Jugendlichen arbeiten aktiv und verantwortlich in allen an Bord und an Land vorkommenden Aufgabenbereichen mit.
<G-vec00319-002-s043><collaborate.arbeiten><en> The young people collaborate actively and responsively in every field of activity aboard and ashore.
<G-vec00319-002-s044><collaborate.arbeiten><de> Energieeinkäufer arbeiten mit CSR-Abteilungen zusammen, um sicherzustellen, dass die richtige Menge und Qualität erneuerbarer Energie eingekauft wird, angefangen von nationalen Grünstromtarifen bis hin zu Power Purchase Agreements (PPAs) für große eigene Produktionsanlagen und Herkunftsnachweisen (Renewable Energy Certificates, RECs) für den Stromverbrauch von Niederlassungen und Einzelhandelsgeschäften mit geringem Energieverbrauch, die ihren Stromanbieter nicht direkt auswählen können.
<G-vec00319-002-s044><collaborate.arbeiten><en> Energy buyers collaborate with CSR departments to ensure the right quantities and quality of renewable energy is purchased, ranging from national green tariffs to Power Purchase Agreements (PPAs) for major own production facilities, to Renewable Energy Certificates (RECs) for offices and retail outlets with low electricity consumption and no option to choose the utility directly.
<G-vec00319-002-s045><collaborate.arbeiten><de> Wir lernen zusammen, zu diskutieren und zu arbeiten.
<G-vec00319-002-s045><collaborate.arbeiten><en> We learn together, discuss and collaborate.
<G-vec00319-002-s046><collaborate.arbeiten><de> Mehrere Mitarbeiter können gleichzeitig an einer Präsentation arbeiten.
<G-vec00319-002-s046><collaborate.arbeiten><en> Multiple team members can contribute to or collaborate on a presentation.
<G-vec00319-002-s047><collaborate.arbeiten><de> Dabei arbeiten sie eng mit lokalen, nationalen und internationalen Kooperationspartnern zusammen, darunter 290 Hochschulen im Ausland.
<G-vec00319-002-s047><collaborate.arbeiten><en> At the same time, they closely collaborate with local, national and international cooperation partners, including 290 international institutions of higher education.
<G-vec00319-002-s048><collaborate.arbeiten><de> Tom Schönherr wird in Zukunft als eigenständiger Berater für ausgewählte Unternehmen arbeiten.
<G-vec00319-002-s048><collaborate.arbeiten><en> Tom Schönherr will collaborate with selected companies as an independent design-consultant.
<G-vec00319-002-s049><collaborate.arbeiten><de> Im Markt der salzigen Snacks arbeiten wir mit italienischen Unternehmen wie Panealba, San Lucio und Roberto zusammen, die jeweils in ihrem Heimatmarkt eine dominierende Marktposition einnehmen.
<G-vec00319-002-s049><collaborate.arbeiten><en> In the savoury snacks market, we collaborate with Italian companies such as Panealba, San Lucio and Roberto, all of whom enjoy dominant market positions in their home market.
<G-vec00319-002-s050><collaborate.arbeiten><de> In der Diagnostik von Gedächtnis- und Konzentrationsstörungen arbeiten wir mit einer Neuropsychiologin zusammen.
<G-vec00319-002-s050><collaborate.arbeiten><en> For the diagnosis of memory disorders and concentration problems we collaborate with a neuropsychologist.
<G-vec00319-002-s051><collaborate.arbeiten><de> Aber auch, wie attraktiv es mittlerweile geworden ist, miteinander statt gegeneinander zu arbeiten – auch um den eigenen Einfluss zu stärken.
<G-vec00319-002-s051><collaborate.arbeiten><en> It also underscores how attractive it has become to collaborate instead of compete, while still strengthening individual brand influence.
<G-vec00319-002-s063><cooperate.arbeiten><de> Das neue Innovationszentrum arbeitet eng mit den als F&E-Satelliten verbundenen Standorten Gendorf bei München, Lamotte / Frankreich und Suzano / Brasilien sowie rund 40 anwendungstechnischen Zentren weltweit zusammen.
<G-vec00319-002-s063><cooperate.arbeiten><en> The new innovation center will closely cooperate with all of the R&D satellite sites in Gendorf (near Munich, Germany), Lamotte (France) and Suzano (Brazil) as well as 40 application centers around the globe.
<G-vec00319-002-s064><cooperate.arbeiten><de> SD-TECHNOLOGIES arbeitet für regionale sowie überregionale Unternehmen und Organisationen jeder Größenordnung, die eine professionelle IT-Kompetenz benötigen.
<G-vec00319-002-s064><cooperate.arbeiten><en> SD-TECHNOLOGIES cooperate with local as well as national companies and organizations of any size requiring a professional IT competence.
<G-vec00319-002-s065><cooperate.arbeiten><de> Die U-Boot-Crew durchquert eiskalte Meere voller seltsamer Kreaturen, erkundet Alien-Ruinen und arbeitet mit den Kameraden zusammen, um auf der beschwerlichen Reise verschiedene Missionen zu erfüllen.
<G-vec00319-002-s065><cooperate.arbeiten><en> Navigate a chilling ocean filled with strange creatures, explore alien ruins, and cooperate with your crewmates to accomplish missions on your voyage.
<G-vec00319-002-s066><cooperate.arbeiten><de> Angesichts der großen wirtschaftlichen und ernährungsphysiologischen Bedeutung dieses Handels arbeitet die Industrie mit lokalen und internationalen Unternehmen innerhalb der Plattform an der Förderung einer umweltgerechten Palmölproduktion.
<G-vec00319-002-s066><cooperate.arbeiten><en> In view of the high economic and dietary importance of this trade, the industry seeks to cooperate with local and international parties in a Round Table on sustainable palm oil.
<G-vec00319-002-s067><cooperate.arbeiten><de> (2b) Unbeschadet der besonderen Anforderungen, die in den in Artikel 1 Absatz 2 genannten Gesetzgebungsakten aufgeführt sind, und vorbehaltlich der in Absatz 1 Satz 2 genannten Bedingungen arbeitet die Behörde soweit möglich mit den jeweils zuständigen Behörden von Drittländern zusammen, deren Regulierungs- und Aufsichtsrahmen als gleichwertig anerkannt worden ist.
<G-vec00319-002-s067><cooperate.arbeiten><en> 2b. Without prejudice to specific requirements set out in the legislative acts referred to in Article 1(2) and subject to the conditions set out in the second sentence of paragraph 1, the Authority shall cooperate where possible with the relevant competent authorities, of third countries whose regulatory and supervisory regimes have been recognised as equivalent.
<G-vec00319-002-s068><cooperate.arbeiten><de> BEHAARTE-FOTZEN.COM duldet keine Kinderpornografie und arbeitet mit allen Regierungsbehörden zusammen, welche Personen verfolgen, die Kinderpornografie produzieren.
<G-vec00319-002-s068><cooperate.arbeiten><en> Pornowunder shall not condone child pornography and will cooperate with all governmental agencies that seek those who produce child pornography.
<G-vec00319-002-s069><cooperate.arbeiten><de> (2) Jeder Vertragsstaat arbeitet mit anderen Vertragsstaaten zusammen und gewährt in geeigneter Form rechtliche Hilfe, um die Erfüllung der Verpflichtungen nach Absatz 1 zu erleichtern.
<G-vec00319-002-s069><cooperate.arbeiten><en> 2. Each State Party shall cooperate with other States Parties and afford the appropriate form of legal assistance to facilitate the implementation of the obligations under paragraph 1.
<G-vec00319-002-s076><work.arbeiten><de> Nicht nur die Software selbst arbeitet schneller – die neuen Funktionen von Artec Studio 12 ermöglichen außerdem eine intuitivere und schnellere Navigation.
<G-vec00319-002-s076><work.arbeiten><en> Not only does the software itself work quicker, new features have made Artec Studio 12 more intuitive and faster to navigate.
<G-vec00319-002-s077><work.arbeiten><de> „In diesem Jahr der Missionarischen Strömung möchte ich mit meinen Übersetzungen meinen Landsleuten zeigen, wie man in Schönstatt arbeitet und wie viel.
<G-vec00319-002-s077><work.arbeiten><en> “During the Year of the Missionary Current through my translations, I try to show my compatriots how, and how much work is done in Schoenstatt.
<G-vec00319-002-s078><work.arbeiten><de> Unser Team arbeitet dezentral, das bedeutet, dass wir nicht jeden Tag bei Euch im Office sitzen werden, denn unser Office ist Slack, Hangouts und Co.
<G-vec00319-002-s078><work.arbeiten><en> The people in our team work decentralized, which means we won't sit in your office on a daily basis. Our office is Slack, Hangouts etc.
<G-vec00319-002-s079><work.arbeiten><de> Wer direkt mit Menschen arbeitet, sei es als Therapeut, im sozialen Dienst oder als Lehrer, kennt die endlose Aufgabe des „Loslassens“ der täglichen Erlebnisse.
<G-vec00319-002-s079><work.arbeiten><en> Those who work directly with people, whether as a therapist, social service, or a teacher who knows the endless task de ' letting go ' of everyday experiences.
<G-vec00319-002-s080><work.arbeiten><de> So sorget euch nicht, denn Ich sorge für euch.... arbeitet nur immer an euch selbst, daß ihr allen Versuchungen widersteht, daß ihr nicht in Lieblosigkeit verfallet und euren Reifegrad gefährdet, und immer werdet ihr dann auch Meine Liebe erfahren dürfen in einem Maß, daß ihr Meine Gegenwart spüret und selig seid....
<G-vec00319-002-s080><work.arbeiten><en> So, don't worry, for I will take care of you.... always just work at improving yourselves, so that you will resist all temptations, that you will not become heartless and put your degree of maturity at risk, and then you will also always be allowed to feel My love to an extent that you will feel My presence and be happy....
<G-vec00319-002-s081><work.arbeiten><de> Acht davon schläft man, acht davon hat man frei und acht davon arbeitet man.
<G-vec00319-002-s081><work.arbeiten><en> Eight of those hours are spent asleep, eight are time off and eight are spent at work.
<G-vec00319-002-s082><work.arbeiten><de> Durch unser Entwicklungs- und Produktionsteam, welches mit modernen Technologien in der Konstruktion und Produktion arbeitet, gibt es für uns keine Einschränkungen bei der Umsetzung Ihrer Vorgaben.
<G-vec00319-002-s082><work.arbeiten><en> Our production and development experts work with the latest technologies in the construction and production area, which means that there are no restrictions that could hinder us in the realization of your ideas and wishes.
<G-vec00319-002-s083><work.arbeiten><de> Seine Ehefrau arbeitet nicht und seine beiden Töchter gehen auf die Hochschule.
<G-vec00319-002-s083><work.arbeiten><en> Mr. Cai's wife does not work and his two daughters are in high school.
<G-vec00319-002-s084><work.arbeiten><de> Ein Team arbeitet nur mit Herzblut und Engagement, wenn jeder Einzelne als vollwertiger Mitarbeiter betrachtet wird.
<G-vec00319-002-s084><work.arbeiten><en> A team will only work with passion and involvement if each person is considered a fully-fledged staff member.
<G-vec00319-002-s085><work.arbeiten><de> Die beschädigte Stelle ist durch Befühlen kränklich, und der Muskel arbeitet mit der vollen Belastung nicht.
<G-vec00319-002-s085><work.arbeiten><en> The damaged place is painful to the touch, and the muscle does not work with full loading.
<G-vec00319-002-s086><work.arbeiten><de> Content Wir sind davon überzeugt, dass man glücklicher, effizienter und erfolgreicher ist, wenn man für ein Unternehmen arbeitet, dass zu einem passt.
<G-vec00319-002-s086><work.arbeiten><en> We believe that you are happier, perform better and achieve more when you work for an organization that suits you well.
<G-vec00319-002-s087><work.arbeiten><de> Anhand eines Beispiels zeigen wir außerdem, wie man Modelle schnell und einfach anlegt und mit ihnen arbeitet.
<G-vec00319-002-s087><work.arbeiten><en> Using an example, we will also show how to create and work with models quickly and easily.
<G-vec00319-002-s088><work.arbeiten><de> Das entspricht in der Tat einem der Projektziele der Vereinigung pro Terra Sancta (ATS) und des Terra Sancta Museums: die gleichzeitige Aufwertung der Vergangenheit, der heiligen Stätten und der örtlichen Bevölkerung, die hier lebt und arbeitet.
<G-vec00319-002-s088><work.arbeiten><en> This is in fact one of the aims of the projects of ATS pro Terra Sancta and the Terra Sancta Museum: to simultaneously enhance the past, the Holy Places and the local population who live and work in these places.
<G-vec00319-002-s089><work.arbeiten><de> Obwohl er mit jeder Musikrichtung gerne arbeitet, ist er vor allem bekannt für gute Punk und Metal-Produktionen.
<G-vec00319-002-s089><work.arbeiten><en> He likes to work with all styles of music, but he is famous for good punk and metal productions.
<G-vec00319-002-s090><work.arbeiten><de> Der Sohn einer Irin und eines Franzosen lebt seit 2001 in Paris und arbeitet seitdem in der Eventindustrie.
<G-vec00319-002-s090><work.arbeiten><en> Born and raised in Ireland, Cormac moved to France in 2001 to work in the events industry.
<G-vec00319-002-s091><work.arbeiten><de> Neben den Lehrpersonen arbeitet die Schulsozialarbeit eng mit Schulleitungen, Behörden und Fachstellen zusammen.
<G-vec00319-002-s091><work.arbeiten><en> The school social work is conducted in close cooperation with not only the teachers, but also with school administrations, authorities and special departments.
<G-vec00319-002-s092><work.arbeiten><de> Die Kunst Kollektion habe ich für euch entwickelt, die ihr gerne künstlerisch und frei mit Stickereien arbeitet aber dennoch ein bisschen Führung haben möchtet.
<G-vec00319-002-s092><work.arbeiten><en> The Art Collection was developed for all of you who like to work more artistically and freely with embroidery, but still want a little bit of guidance and framework they can follow.
<G-vec00319-002-s093><work.arbeiten><de> Das Team von Fachleuten, das für unser Unternehmen arbeitet, sowie unsere anspruchsvollen Kunden ermutigen uns, offen für neue Ideen zu sein, flexibel auf Marktschwankungen zu reagieren und vor allem uns ständig zu verbessern.
<G-vec00319-002-s093><work.arbeiten><en> The team of professionals who work for our Company, as well as our demanding clients, encourage us to be open to new ideas, to react flexibly to market fluctuations and, above all, to constantly improve.
<G-vec00319-002-s094><work.arbeiten><de> Es besteht die Möglichkeit, dass es nicht mit allen Vorlagen korrekt arbeitet.
<G-vec00319-002-s094><work.arbeiten><en> It is possible it will not work correctly with all templates.
<G-vec00369-002-s066><employ.arbeiten><de> Wir arbeiten mit vielen verschiedenen Techniken um die Sicherheit dieser Daten zu gewährleisten und sie vor unbefugtem Zugriff von Mitgliedern innerhalb und außerhalb des Unternehmens zu schützen.
<G-vec00369-002-s066><employ.arbeiten><en> We employ many different security techniques to protect such data from unauthorized access by members inside and outside the company.
<G-vec00369-002-s067><employ.arbeiten><de> Ob breit gestreute Ransomware, die durch die Verschlüsselung der Unternehmensdaten den Geschäftsablauf innerhalb kürzester Zeit völlig lahmlegen können, oder gezielte Attacken auf ein Unternehmen, die meist über einen langen Zeitraum unentdeckt und unerkannt Geschäftsgeheimnisse abgreifen – die Angreifer arbeiten mit unterschiedlichsten Methoden und Techniken um ihr Ziel zu erreichen.
<G-vec00369-002-s067><employ.arbeiten><en> No matter whether it’s a sweeping ransomware attack which encrypts the company’s data and can bring the business to its knees in a very short time, or targeted attacks on a company over a long period which mostly go undiscovered and which snatch business secrets – attackers employ a wide variety of methods and techniques to achieve their aims.
<G-vec00369-002-s068><employ.arbeiten><de> Viele Entwicklungsteams arbeiten mit agilen Methoden.
<G-vec00369-002-s068><employ.arbeiten><en> Many software engineering teams successfully employ agile methods.
<G-vec00369-002-s069><employ.arbeiten><de> Wir arbeiten mit Experten verschiedener Fachrichtungen zusammen und sind daher in der Lage, Ihnen die Entwicklung spezifischer Lösungen anzubieten, die genau auf Ihr Geschäftsfeld und auf Ihr IT-Umfeld abgestimmt sind, unabhängig davon, welche Technologien und Infrastrukturen erforderlich sind.
<G-vec00369-002-s069><employ.arbeiten><en> As we employ multi-skilled experts, we are able to provide a bespoke software development service which is a perfect fit with your specialization and your IT environment, no matter what technologies and infrastructures are required.
<G-vec00369-002-s070><employ.arbeiten><de> Gerade wegen der hohen Erfolgsquote arbeiten mit uns Kunden aus allen Kreisen der Tschechischen Republik und Slowakei zusammen.
<G-vec00369-002-s070><employ.arbeiten><en> It is our high success rate that encourages clients from all regions of the Czech Republic and Slovakia to employ our services.
<G-vec00369-002-s071><employ.arbeiten><de> Darüber hinaus arbeiten wir mit zuverlässiger Datenverschlüsselung und Sicherheits-Richtlinien, um Ihre persönlichen Daten und Benutzerkonto-Informationen zu schützen.
<G-vec00369-002-s071><employ.arbeiten><en> Furthermore, we employ the strictest data encryption and security measures to protect your personal and account information.
<G-vec00369-002-s072><employ.arbeiten><de> Sexarbeiter und Sexarbeiterinnen, Stripper und Stripperinnen und andere, die "nicht jugendfreie" Unterhaltung bieten, arbeiten mit Glamour - über Kleidung, Kosmetik, Schönheitsoperationen, Glitzerlicht und Musik -, um "Freier" dazu zu bringen, kurzzeitig an einem glamourösen Lebensstil zu partizipieren.
<G-vec00369-002-s072><employ.arbeiten><en> Sex workers, strippers and other "adult entertainers" employ glamour - via clothing, cosmetics, plastic surgery, glittering lights, and music - to dupe "tricks" into momentarily participating in a glamorous lifestyle.
<G-vec00373-002-s019><perform.arbeiten><de> Gebiete Diese Liste zeigt definierte Gebiete an, in denen Du arbeiten kannst.
<G-vec00373-002-s019><perform.arbeiten><en> This list is of the various defined areas of which can perform edits.
<G-vec00373-002-s020><perform.arbeiten><de> Pumpen mit mechanischer Dichtung arbeiten effizienter und im Allgemeinen zuverlässiger für längere Zeit.
<G-vec00373-002-s020><perform.arbeiten><en> Pump with mechanical seal perform more efficiently and generally perform more reliably for extended periods of time.
<G-vec00373-002-s021><perform.arbeiten><de> Diese Kurse fokussieren sich auf die beruflichen Kommunikationskompetenzen im Englischen, die Sie benötigen, um in einem internationalen Umfeld erfolgreich arbeiten zu können.
<G-vec00373-002-s021><perform.arbeiten><en> These courses focus on the Professional Communication Skills you require to perform successfully in an international environment.
<G-vec00373-002-s022><perform.arbeiten><de> Die enVision Plotter arbeiten auch ohne Beaufsichtigung mit einer solchen Zuverlässigkeit, dass Sie lange Texte und Grafiken auch am Ende des Arbeitstages schneiden und so Ihre Produktivität steigern können.
<G-vec00373-002-s022><perform.arbeiten><en> EnVision plotters perform so reliably unattended, you can run lengthy text or graphics after-hours and increase your productivity. Just set up and walk away!
<G-vec00373-002-s023><perform.arbeiten><de> In allen unseren Filialen und Zentralverwaltungsstandorten bemühen wir uns um den Aufbau positiver, engagierter Teams, die nach unseren hohen Standards arbeiten.
<G-vec00373-002-s023><perform.arbeiten><en> At all our stores and head office locations we aim to build positive and enthusiastic teams who will perform to our high standards.
<G-vec00373-002-s024><perform.arbeiten><de> Wir arbeiten mit unserer eigenen Ausrüstung aus den Systemen OCTANORM, NEWLINE, MAXIMA und MAXIMA LIGHT.
<G-vec00373-002-s024><perform.arbeiten><en> We may perform events, exhibitions and conferences with our own equipment from systems like OCTANORM, NEWLINE, MAXIMA and MAXIMA LIGHT.
<G-vec00373-002-s025><perform.arbeiten><de> Beide EAs arbeiten genau gleich.
<G-vec00373-002-s025><perform.arbeiten><en> Both EAs perform exactly the same.
<G-vec00373-002-s026><perform.arbeiten><de> Sie arbeiten zuverlässig im Bereich von -30 °C bis + 60 °C.
<G-vec00373-002-s026><perform.arbeiten><en> They perform reliably in an environment within the range of -30° C and + 60° C.
<G-vec00373-002-s027><perform.arbeiten><de> Wenn unsere Produkte zuverlässig arbeiten und unsere Mitarbeiter ehrenhaft handeln, profitieren wir alle.
<G-vec00373-002-s027><perform.arbeiten><en> When our products and our people perform with integrity, we all benefit.
<G-vec00373-002-s028><perform.arbeiten><de> Wir könnten nicht stolzer oder aufgeregter sein, ein grundlegender Partner zu sein und die Art und Weise, wie Gamer einen Controller verwenden, weiter zu verbessern, um ihnen zu helfen, auf höchstem Niveau zu arbeiten ", sagte Duncan Ironmonger, CEO und Gründer von SCUF Gaming.
<G-vec00373-002-s028><perform.arbeiten><en> We couldn’t be prouder or more excited to be a foundational partner and to continue innovating the way gamers use a controller to help them perform at the highest level,” said Duncan Ironmonger, CEO & Founder of SCUF Gaming.
<G-vec00373-002-s029><perform.arbeiten><de> Universell einsetzbar arbeiten sie unabhängig von Farbe und Oberflächenbeschaffenheit.
<G-vec00373-002-s029><perform.arbeiten><en> Regardless of the colour, transparency, and surface texture, they always perform really well.
<G-vec00373-002-s030><perform.arbeiten><de> Unsere Website bietet umfangreiche Live-Demos und Flash®-Filme, die Ihnen helfen sollen zu verstehen, wie unsere Produkte arbeiten.
<G-vec00373-002-s030><perform.arbeiten><en> Our website features comprehensive live demos and Flash® movies to help you understand how our products perform.
<G-vec00373-002-s031><perform.arbeiten><de> AUGMENTAIO bemüht sich, innerhalb der vereinbarten Fristen zu arbeiten.
<G-vec00373-002-s031><perform.arbeiten><en> AUGMENTAIO shall make every effort to perform within the deadlines agreed.
<G-vec00373-002-s032><perform.arbeiten><de> Zudem erteilen Sie hiermit jedem Nutzer (einschließlich Medien Dritter) der Website und/oder des Services eine nicht-exklusive Lizenz, um über die Website und den Service auf Ihre Nutzereingaben zuzugreifen sowie diese im Rahmen ihrer eigenen Nutzung der Website und des Services sowie in Verbindung mit Medien Dritter zu benutzen, zu bearbeiten, zu verändern, wiederzugeben, zu verbreiten, von ihnen abgeleitete Arbeiten zu erstellen, sie anzuzeigen und vorzuführen.
<G-vec00373-002-s032><perform.arbeiten><en> You also hereby grant each user of the Service a non-exclusive license to access your Content through the Service, and to use, reproduce, distribute, display and perform such Content as permitted through the functionality of the Service and under these Terms (collectively, the “Advertising License”); and
<G-vec00373-002-s033><perform.arbeiten><de> Chirurgische Behandlungen und Kryotherapie arbeiten viel schneller, aber haben Nebenwirkungen gegeben.
<G-vec00373-002-s033><perform.arbeiten><en> Surgical treatments and cryotherapy perform a lot quicker however have actually included side-effects.
<G-vec00373-002-s034><perform.arbeiten><de> Wenn Sie Speichergeschwindigkeiten mischen, wird das System mit der geringeren Speichergeschwindigkeit arbeiten.
<G-vec00373-002-s034><perform.arbeiten><en> If you mix memory speeds, the system will perform at the lower memory speed.
<G-vec00373-002-s035><perform.arbeiten><de> Der Hydro-Block kann das Eindringen von Wasser und Fremdstoffen verhindern, um sicherzustellen, dass die Bremsscheiben immer auf optimalem Niveau arbeiten.
<G-vec00373-002-s035><perform.arbeiten><en> The hydro block can block water and foreign materials from entering system ensure the drag washers always perform at optimal levels.
<G-vec00373-002-s036><perform.arbeiten><de> Kühlsysteme, bei welchen Salzlösungen als Kühlmittel eingesetzt werden, arbeiten in diesem Temperaturbereich höchst effizient.
<G-vec00373-002-s036><perform.arbeiten><en> Low-Temperature Refrigeration Secondary cooling systems which use salt solutions as the refrigerant perform very efficiently in this temperature range.
<G-vec00373-002-s037><perform.arbeiten><de> Der Verdampfer V80 wurde entwickelt, um effektiv in einem breiten Spektrum an Anwendungen zu arbeiten.
<G-vec00373-002-s037><perform.arbeiten><en> The V80 evaporator has been developed to perform effectively in a wide range of applications.
<G-vec00373-002-s225><work.arbeiten><de> 3 Und die Ältesten der Stadt, die am nächsten bei dem Erschlagenen liegt, sollen eine junge Kuh nehmen, mit der noch nicht gearbeitet wurde [und] die noch an keinem Joch gezogen hat.
<G-vec00373-002-s225><work.arbeiten><en> 3 And the elders of the city which is nearest to the slain man shall take a heifer which has never been used for work nor has pulled in the yoke,
