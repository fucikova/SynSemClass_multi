<G-vec00169-001-s114><collect.einsammeln><de> Der Hauptunterschied ist, dass wir die Mittelsmänner umgehen, sie verdienen kein Geld an uns, sodass alles Geld, das wir einsammeln, seinen Weg zurück zum Hersteller nimmt.
<G-vec00169-001-s114><collect.einsammeln><en> The main difference is that we bypass the middlemen; they do not earn any money with us, so all of the money we collect makes its way back to the producer.
<G-vec00169-001-s115><collect.einsammeln><de> Hinein kriechen und die goldene Rose einsammeln.
<G-vec00169-001-s115><collect.einsammeln><en> Crawl in and collect the golden rose .
<G-vec00169-001-s116><collect.einsammeln><de> Wir gehen mit euch vorwärts, indem wir in dieser Rückschau ALLES einsammeln, was ihr liegengelassen, vergessen und von euch geschleudert habt.
<G-vec00169-001-s116><collect.einsammeln><en> We go forwards with you by using this review to COLLECT everything which you left behind, forgot or flung away.
<G-vec00169-001-s117><collect.einsammeln><de> Darüber hinaus muss der Roboter Teile einer Rakete einsammeln und zu einer Abschussrampe transportieren und in der farbigen Reihenfolge der Russischen Flagge sortieren und aufstellen.
<G-vec00169-001-s117><collect.einsammeln><en> In addition the robot has to collect parts of a rocket, transport them to a launch pad and sort and align them in the color sequence of the Russian flag.
<G-vec00169-001-s118><collect.einsammeln><de> Diese Operation nimmt aus zweierlei Gründen längere Zeit in Anspruch: Erstens mussten wir heimlich die enormen Mengen an Geld einsammeln, die von den Dunkelkräften gestohlen worden waren.
<G-vec00169-001-s118><collect.einsammeln><en> This operation is taking longer for two reasons. First, we needed to collect, surreptitiously, the enormous amounts of money stolen by the dark.
<G-vec00169-001-s119><collect.einsammeln><de> Draußen in der Nische gegenüber die Granaten einsammeln.
<G-vec00169-001-s119><collect.einsammeln><en> Crawl out and collect the grenades in the alcove opposite.
<G-vec00169-001-s120><collect.einsammeln><de> Faultiere, Nilpferde, Löwen, Pandas... Alle liegen nur faul da und warten darauf, sich von den Spielern einsammeln zu lassen.
<G-vec00169-001-s120><collect.einsammeln><en> Sloths, hippos, L & ouml; wen, pandas... All are just as lazy and waiting to can collect from the players .
<G-vec00169-001-s121><collect.einsammeln><de> [Hinweis] Wenn man ins Wasser fällt, kann man die Gegenstände später noch mal einsammeln, man muss sowieso noch mal hier hin.
<G-vec00169-001-s121><collect.einsammeln><en> (If you drop into the water you can collect the goodies later on, you have to return here anyway.
<G-vec00169-001-s122><collect.einsammeln><de> Das Venus Symbol einsammeln.
<G-vec00169-001-s122><collect.einsammeln><en> Collect the Venus Symbol .
<G-vec00169-001-s123><collect.einsammeln><de> Wahlweise kann der Binopterus mit zwei Windflügeln (Windkollektoren) ausgestattet werden, die den Wind „einsammeln“ und ermöglichen somit einen Betrieb selbst in windschwachen Gebieten.
<G-vec00169-001-s123><collect.einsammeln><en> Optionally the Binopterus can be equipped with two wind wings „windcollector“, which “collect” the wind and allow the start of the wind turbine even in very low wind speed regions.
<G-vec00169-001-s124><collect.einsammeln><de> Den Iris Labor Zugang den er verliert einsammeln.
<G-vec00169-001-s124><collect.einsammeln><en> Collect the Iris Lab Access he loses.
<G-vec00169-001-s125><collect.einsammeln><de> Helfen Sie kleiner Orange die Schwerkraft übertölpeln und alle Zitronen einsammeln.
<G-vec00169-001-s125><collect.einsammeln><en> Help small orange to dupe the gravity and to collect all the lemons.
<G-vec00169-001-s126><collect.einsammeln><de> In der Zwischenzeit, während die Erdveränderungen weiter voran schreiten und die reiche Klasse verängstigen, wird er Ihr Geld einsammeln.
<G-vec00169-001-s126><collect.einsammeln><en> Meanwhile, as the Earth changes progress, scaring the wealthy class, he will collect their funds.
<G-vec00169-001-s127><collect.einsammeln><de> Der Climate Talk beleuchtete Fragen, welche Rolle bestehende Institutionen bei der Mittelverwendung haben können, oder ob neue Institutionen geschaffen werden sollen, die die Mittel einsammeln und verteilen.
<G-vec00169-001-s127><collect.einsammeln><en> The Climate Talk highlighted questions on the role of existing institutions regarding the allocation of sources and whether new institutions should be created to collect and distribute the funds.
<G-vec00169-001-s128><collect.einsammeln><de> Die goldene Rose einsammeln und wieder nach draußen klettern.
<G-vec00169-001-s128><collect.einsammeln><en> Collect the golden rose and climb back out.
<G-vec00169-001-s129><collect.einsammeln><de> Abgefallene Blätter sollte man immer einsammeln.
<G-vec00169-001-s129><collect.einsammeln><en> You should collect fallen leaves.
<G-vec00169-001-s130><collect.einsammeln><de> "Wie im Beispiel 3 schon ergänzt, sollte man also eher die Ausgabe der einzelnen ""partial incremental backups"" einsammeln und zum Ende des Skriptes auswerten, beispielsweise nach Fehlern suchen oder die ""Summaries"" zusammenfassen."
<G-vec00169-001-s130><collect.einsammeln><en> "As already added in example 3, one should rather collect the output of the individual ""partial incremental backups"" and evaluate them at the end of the script, e.g. search for errors or summarize the ""summaries"" ."
<G-vec00169-001-s131><collect.einsammeln><de> Den Kristall einsammeln.
<G-vec00169-001-s131><collect.einsammeln><en> Collect the crystal .
<G-vec00169-001-s132><collect.einsammeln><de> Um die Mission zu erfüllen, kannst du Extras und Power-Ups einsammeln.
<G-vec00169-001-s132><collect.einsammeln><en> In order to accomplish your task, you can collect extras and power-ups.
<G-vec00443-001-s054><collect.einsammeln><de> Der Hauptunterschied ist, dass wir die Mittelsmänner umgehen, sie verdienen kein Geld an uns, sodass alles Geld, das wir einsammeln, seinen Weg zurück zum Hersteller nimmt.
<G-vec00443-001-s054><collect.einsammeln><en> The main difference is that we bypass the middlemen; they do not earn any money with us, so all of the money we collect makes its way back to the producer.
<G-vec00443-001-s055><collect.einsammeln><de> Hinein kriechen und die goldene Rose einsammeln.
<G-vec00443-001-s055><collect.einsammeln><en> Crawl in and collect the golden rose .
<G-vec00443-001-s056><collect.einsammeln><de> Wir gehen mit euch vorwärts, indem wir in dieser Rückschau ALLES einsammeln, was ihr liegengelassen, vergessen und von euch geschleudert habt.
<G-vec00443-001-s056><collect.einsammeln><en> We go forwards with you by using this review to COLLECT everything which you left behind, forgot or flung away.
<G-vec00443-001-s057><collect.einsammeln><de> Darüber hinaus muss der Roboter Teile einer Rakete einsammeln und zu einer Abschussrampe transportieren und in der farbigen Reihenfolge der Russischen Flagge sortieren und aufstellen.
<G-vec00443-001-s057><collect.einsammeln><en> In addition the robot has to collect parts of a rocket, transport them to a launch pad and sort and align them in the color sequence of the Russian flag.
<G-vec00443-001-s058><collect.einsammeln><de> Diese Operation nimmt aus zweierlei Gründen längere Zeit in Anspruch: Erstens mussten wir heimlich die enormen Mengen an Geld einsammeln, die von den Dunkelkräften gestohlen worden waren.
<G-vec00443-001-s058><collect.einsammeln><en> This operation is taking longer for two reasons. First, we needed to collect, surreptitiously, the enormous amounts of money stolen by the dark.
<G-vec00443-001-s059><collect.einsammeln><de> Draußen in der Nische gegenüber die Granaten einsammeln.
<G-vec00443-001-s059><collect.einsammeln><en> Crawl out and collect the grenades in the alcove opposite.
<G-vec00443-001-s060><collect.einsammeln><de> Faultiere, Nilpferde, Löwen, Pandas... Alle liegen nur faul da und warten darauf, sich von den Spielern einsammeln zu lassen.
<G-vec00443-001-s060><collect.einsammeln><en> Sloths, hippos, L & ouml; wen, pandas... All are just as lazy and waiting to can collect from the players .
<G-vec00443-001-s061><collect.einsammeln><de> [Hinweis] Wenn man ins Wasser fällt, kann man die Gegenstände später noch mal einsammeln, man muss sowieso noch mal hier hin.
<G-vec00443-001-s061><collect.einsammeln><en> (If you drop into the water you can collect the goodies later on, you have to return here anyway.
<G-vec00443-001-s062><collect.einsammeln><de> Das Venus Symbol einsammeln.
<G-vec00443-001-s062><collect.einsammeln><en> Collect the Venus Symbol .
<G-vec00178-001-s029><garner.einsammeln><de> Ich bepflanzte ihn für euch vor langer Zeit, sodass ihr seine große Weisheit einsammeln könnt.
<G-vec00178-001-s029><garner.einsammeln><en> I planted it for you long ago so that today you may garner its great wisdom.
<G-vec00443-001-s019><garner.einsammeln><de> Ich bepflanzte ihn für euch vor langer Zeit, sodass ihr seine große Weisheit einsammeln könnt.
<G-vec00443-001-s019><garner.einsammeln><en> I planted it for you long ago so that today you may garner its great wisdom.
<G-vec00443-001-s018><gather.einsammeln><de> Hilf Bauarbeiter Lloyd Andrews beim Einsammeln der Rohstoffe, die ihr für den Bau des Gefängnisses benötigt.
<G-vec00443-001-s018><gather.einsammeln><en> Help contractor Lloyd Andrews gather the resources needed to complete work on the prison.
<G-vec00443-001-s019><gather.einsammeln><de> Dann, am Ende des Berichts, als alle satt waren, sagte Jesus zu den Jüngern, dass sie die übriggebliebenen Brocken einsammeln sollten, damit nichts verderbe.
<G-vec00443-001-s019><gather.einsammeln><en> Then at the end of the story, Jesus, when everyone had eaten their fill, Jesus told the disciples to gather up the leftovers so that nothing would be wasted.
<G-vec00443-001-s020><gather.einsammeln><de> 25:3 Sechs Jahre sollst du dein Feld besäen und sechs Jahre deinen Weinberg beschneiden und den Ertrag des Landes einsammeln.
<G-vec00443-001-s020><gather.einsammeln><en> 25:3 Six years you shall sow your field, and six years you shall prune your vineyard, and gather in its fruits;
<G-vec00443-001-s021><gather.einsammeln><de> Die dann noch lebenden Gläubigen, welche mit ihnen gemeinsam entrückt werden, sind die Auserwählten, welche die Engel des Herrn einsammeln.
<G-vec00443-001-s021><gather.einsammeln><en> The at that time still living faithful, who are caught up into heaven together with them, are the elect who the angels of the Lord gather together.
<G-vec00443-001-s022><gather.einsammeln><de> Sechs Jahre sollst du dein Land besäen und seine Früchte einsammeln.
<G-vec00443-001-s022><gather.einsammeln><en> ¶ For six years you shall sow your land and shall gather in the crops thereof:
<G-vec00443-001-s023><gather.einsammeln><de> 39 (ELB) Weinberge wirst du pflanzen und bauen; aber Wein wirst du weder trinken noch einsammeln, denn der Wurm wird sie fressen.
<G-vec00443-001-s023><gather.einsammeln><en> 39 (CPDV) You will dig and plant a vineyard, but you will not drink the wine, nor gather anything at all from it.
<G-vec00443-001-s024><gather.einsammeln><de> 39 Dt 28, 39 Weinberge wirst du pflanzen und bauen; aber Wein wirst du weder trinken noch einsammeln, denn der Wurm wird sie fressen.
<G-vec00443-001-s024><gather.einsammeln><en> 39 Dt 28, 39 You will dig and plant a vineyard, but you will not drink the wine, nor gather anything at all from it.
<G-vec00443-001-s025><gather.einsammeln><de> Sechs Jahre sollst du dein Land besäen und seinen Ertrag einsammeln.
<G-vec00443-001-s025><gather.einsammeln><en> ¶ For six years you shall sow your land and shall gather in the crops thereof:
<G-vec00443-001-s026><gather.einsammeln><de> Und ein reiner Mann soll die Asche der jungen Kuh einsammeln und sie außerhalb des Lagers an einen reinen Ort schütten, und sie soll für die Gemeinde der Söhne Israel aufbewahrt werden für das Wasser der Reinigung; es ist eine Entsündigung.
<G-vec00443-001-s026><gather.einsammeln><en> 'Then a man who is clean shall gather up the ashes of the heifer, and store them outside the camp in a clean place; and they shall be kept for the congregation of the children of Israel for the water of purification; it is for purifying from sin.
<G-vec00586-001-s029><gather.einsammeln><de> Hilf Bauarbeiter Lloyd Andrews beim Einsammeln der Rohstoffe, die ihr für den Bau des Gefängnisses benötigt.
<G-vec00586-001-s029><gather.einsammeln><en> Help contractor Lloyd Andrews gather the resources needed to complete work on the prison.
<G-vec00586-001-s030><gather.einsammeln><de> Dann, am Ende des Berichts, als alle satt waren, sagte Jesus zu den Jüngern, dass sie die übriggebliebenen Brocken einsammeln sollten, damit nichts verderbe.
<G-vec00586-001-s030><gather.einsammeln><en> Then at the end of the story, Jesus, when everyone had eaten their fill, Jesus told the disciples to gather up the leftovers so that nothing would be wasted.
<G-vec00586-001-s031><gather.einsammeln><de> 25:3 Sechs Jahre sollst du dein Feld besäen und sechs Jahre deinen Weinberg beschneiden und den Ertrag des Landes einsammeln.
<G-vec00586-001-s031><gather.einsammeln><en> 25:3 Six years you shall sow your field, and six years you shall prune your vineyard, and gather in its fruits;
<G-vec00586-001-s032><gather.einsammeln><de> Die dann noch lebenden Gläubigen, welche mit ihnen gemeinsam entrückt werden, sind die Auserwählten, welche die Engel des Herrn einsammeln.
<G-vec00586-001-s032><gather.einsammeln><en> The at that time still living faithful, who are caught up into heaven together with them, are the elect who the angels of the Lord gather together.
<G-vec00586-001-s033><gather.einsammeln><de> Sechs Jahre sollst du dein Land besäen und seine Früchte einsammeln.
<G-vec00586-001-s033><gather.einsammeln><en> ¶ For six years you shall sow your land and shall gather in the crops thereof:
<G-vec00586-001-s034><gather.einsammeln><de> 39 (ELB) Weinberge wirst du pflanzen und bauen; aber Wein wirst du weder trinken noch einsammeln, denn der Wurm wird sie fressen.
<G-vec00586-001-s034><gather.einsammeln><en> 39 (CPDV) You will dig and plant a vineyard, but you will not drink the wine, nor gather anything at all from it.
<G-vec00586-001-s035><gather.einsammeln><de> 39 Dt 28, 39 Weinberge wirst du pflanzen und bauen; aber Wein wirst du weder trinken noch einsammeln, denn der Wurm wird sie fressen.
<G-vec00586-001-s035><gather.einsammeln><en> 39 Dt 28, 39 You will dig and plant a vineyard, but you will not drink the wine, nor gather anything at all from it.
<G-vec00586-001-s036><gather.einsammeln><de> Sechs Jahre sollst du dein Land besäen und seinen Ertrag einsammeln.
<G-vec00586-001-s036><gather.einsammeln><en> ¶ For six years you shall sow your land and shall gather in the crops thereof:
<G-vec00586-001-s037><gather.einsammeln><de> Und ein reiner Mann soll die Asche der jungen Kuh einsammeln und sie außerhalb des Lagers an einen reinen Ort schütten, und sie soll für die Gemeinde der Söhne Israel aufbewahrt werden für das Wasser der Reinigung; es ist eine Entsündigung.
<G-vec00586-001-s037><gather.einsammeln><en> 'Then a man who is clean shall gather up the ashes of the heifer, and store them outside the camp in a clean place; and they shall be kept for the congregation of the children of Israel for the water of purification; it is for purifying from sin.
<G-vec00586-001-s038><gather.einsammeln><de> Weinberge wirst du pflanzen und bearbeiten; aber Wein wirst du weder trinken noch einsammeln, denn der Wurm wird ihn abfressen.
<G-vec00586-001-s038><gather.einsammeln><en> You shall plant a vineyard and dress it, but you shall neither drink of the wine nor gather the grapes, because the worms shall eat it.
<G-vec00586-001-s039><gather.einsammeln><de> 38 Du wirst viel Samens ausführen auf das Feld und wenig einsammeln; denn die Heuschrecken werden's abfressen.
<G-vec00586-001-s039><gather.einsammeln><en> 38 Thou shalt carry much seed out into the field, and shalt gather little in; for the locust shall devour it.
<G-vec00586-001-s040><gather.einsammeln><de> 14 so will ich den Regen für euer Land geben zu seiner Zeit, Frühregen und Spätregen, dass du dein Korn, deinen Most und dein Öl einsammeln kannst.
<G-vec00586-001-s040><gather.einsammeln><en> 14 'then I will give you the rain for your land in its season, the early rain and the latter rain, that you may gather in your grain, your new wine, and your oil.
<G-vec00586-001-s041><gather.einsammeln><de> 10 Sechs Jahre sollst du dein Land besäen und seine Früchte einsammeln.
<G-vec00586-001-s041><gather.einsammeln><en> 10 Six years thou shalt sow thy ground, and shalt gather the corn thereof.
<G-vec00586-001-s042><gather.einsammeln><de> 28:39 Weinberge wirst du pflanzen und bauen; aber Wein wirst du weder trinken noch einsammeln, denn der Wurm wird sie fressen.
<G-vec00586-001-s042><gather.einsammeln><en> 28:39 Thou shalt plant and till vineyards, but shalt drink no wine, nor gather [the fruit]; for the worms shall eat it.
<G-vec00586-001-s043><gather.einsammeln><de> 9 Und ein reiner Mann soll die Asche der jungen Kuh einsammeln und sie außerhalb des Lagers an einen reinen Ort schütten, und sie soll für die Gemeinde der Söhne Israel aufbewahrt werden für das Wasser der Reinigung; es ist eine Entsündigung.
<G-vec00586-001-s043><gather.einsammeln><en> 9 And a man who is clean shall gather up the ashes of the heifer and deposit them outside the camp in a clean place. And they shall be kept for the water for impurity for the congregation of the people of Israel; it is a sin offering.
<G-vec00586-001-s044><gather.einsammeln><de> Laß die Kirche diese reiche Ernte einsammeln, es wird die Nationen mit Meiner Wahrheit und der Lehre der Katholischen Kirche versorgen.
<G-vec00586-001-s044><gather.einsammeln><en> Let the Church gather in this rich harvest that will feed the nations with My Truth and the teachings of the Catholic Church.
<G-vec00586-001-s045><gather.einsammeln><de> 24 Christi Engel seine Auserwählten einsammeln und die Toten auferwecken werden (darunter viele gute Christen, die aber (noch) keine Heiligen sein werden.
<G-vec00586-001-s045><gather.einsammeln><en> 24 Christ ́s angels shall gather his selected ones and raise the dead (among many good Christians, who will however not (yet) be saints.
<G-vec00586-001-s046><gather.einsammeln><de> Und sie sollen alle Nahrungsmittel dieser kommenden guten Jahre einsammeln und unter der Obhut des Pharao Getreide aufspeichern als Nahrungsmittel in den Städten und [es dort] aufbewahren.
<G-vec00586-001-s046><gather.einsammeln><en> """And let them gather all the food of those good years that are coming, and store up grain under the authority of Pharaoh, and let them keep food in the cities."
<G-vec00586-001-s047><gather.einsammeln><de> 10 Sechs Jahre sollst du dein Land besäen und seine Früchte einsammeln.
<G-vec00586-001-s047><gather.einsammeln><en> 10 And six years thou shalt sow thy land, and shalt gather in the increase thereof:
<G-vec00169-001-s171><collect.einsammeln><de> Besser gesagt, Skipper Gek gibt dir das Boot, bevor du beginnst, seine Fracht einzusammeln.
<G-vec00169-001-s171><collect.einsammeln><en> Well, Skipper Gek gives you the boat before starting to collect his cargo.
<G-vec00169-001-s172><collect.einsammeln><de> Begebe dich in ein lustiges Abenteuer und hilf dem Pinguin dabei, alle seine Kinder zu finden und einzusammeln.
<G-vec00169-001-s172><collect.einsammeln><en> Go on a fun platform adventure and help the penguin find and collect all her children.
<G-vec00169-001-s173><collect.einsammeln><de> Bei der Ankunft der Hive in Clint City hat die Königinmutter Aegis auf Aufklärungsmission geschickt, um nutzbare Energiequellen in der Stadt zu finden und einzusammeln.
<G-vec00169-001-s173><collect.einsammeln><en> Storyline When the Hive arrived in Clint City, the queen mother sent Aegis undercover to try and locate and collect the energy sources used in the town.
<G-vec00169-001-s174><collect.einsammeln><de> Ziele mit dem Strahl und versuche, die grünen Punkte einzusammeln.
<G-vec00169-001-s174><collect.einsammeln><en> Aim the beam and try to collect green dots.
<G-vec00169-001-s175><collect.einsammeln><de> Ihr Ziel besteht darin, alle Edelsteine einzusammeln, ohne auf eine Mine zu treffen.
<G-vec00169-001-s175><collect.einsammeln><en> Your aim is to collect all the gems without running into any mines.
<G-vec00169-001-s176><collect.einsammeln><de> Land, das einfach ohne Eigentümerschaft dasitzt, Banken geben den Geist auf, da sie unfähig werden, Hypotheken durchzudrücken und einzusammeln, oder Eigentum einzusammeln und es wieder zu verkaufen.
<G-vec00169-001-s176><collect.einsammeln><en> Land just sitting there with no ownership, banks belly-up unable to carry though and collect mortgages or collect properties and re-sell them.
<G-vec00169-001-s177><collect.einsammeln><de> "Ich denke dass es sinnvoller ist, diese ganze Energie zu verwenden, um die Flaschen ""vor Ort"" - oder in der Region - einzusammeln und wieder zu verwerten."
<G-vec00169-001-s177><collect.einsammeln><en> I think it is preferable to use all this energy to collect the bottles locally, for recycling.
<G-vec00169-001-s178><collect.einsammeln><de> Die Yang Energie ruft mich gewöhnlich dazu auf, meine Stärke einzusammeln und mich auf etwas zu konzentrieren... eine Art zentraler Idee, und meine Energien zu entzünden und mit Kraft und Entschiedenheit zu handeln.
<G-vec00169-001-s178><collect.einsammeln><en> Yang energy is usually calling on me to collect my strength and focus on something...some kind of central idea, and to ignite my energy and act with power and decision.
<G-vec00169-001-s179><collect.einsammeln><de> Damit all das wirklich hinhauen wird, hoffen die Devs auf Fans entsprechender Titel und damit auf eine große Community: Zum Finalisieren des Spiels bietet man den Titel auf Kickstarter an und plant, in den nächsten 29 Tagen 100.000 britische Pfund einzusammeln.
<G-vec00169-001-s179><collect.einsammeln><en> For all this to work out, the Devs are hoping for fans of appropriate titles, and thus a large community: To finalize the game, they offer the title on Kickstarter and plans to collect over the next 29 days 100,000 British pounds.
<G-vec00169-001-s180><collect.einsammeln><de> Der Spieler bewegt sich durch seine Provinzen, um sein Gold einzusammeln und um seine Legionen umzuplatzieren.
<G-vec00169-001-s180><collect.einsammeln><en> The player moves through his provinces to collect gold and to relocate his legions.
<G-vec00169-001-s181><collect.einsammeln><de> OOTMQ_10_2.zip Beachte: Nachdem du die 3 heiligen Steine hast, könntest du sofort hingehen und erwachsen werden, aber ich ziehe es vor, vorher noch ein paar Dinge einzusammeln, die vorher unerreichbar waren.
<G-vec00169-001-s181><collect.einsammeln><en> Note: After you have the 3 spiritual stones, you could go and become an adult right away, but I prefer to collect a few things first, which weren´t reachable before.
<G-vec00169-001-s182><collect.einsammeln><de> Wenn die Hall of Plenty-Funktion bei diesem Casino-Spielautomaten ausgelöst wird, dann müssen Sie eine der sechs Türen öffnen, um die Gewinne einzusammeln.
<G-vec00169-001-s182><collect.einsammeln><en> If the Hall of Plenty feature is triggered in this slot casino game, you need to open one of the six doors to collect treasure.
<G-vec00169-001-s183><collect.einsammeln><de> Während Schnorchler bei ihren Ausflügen dazu angehalten werden, alte Angelnetze oder Plastikmüll einzusammeln, werden Taucher förmlich zu Unterwassergärtnern.
<G-vec00169-001-s183><collect.einsammeln><en> While snorkelers are encouraged to collect old fishing nets or plastic waste during their tours, divers turn into underwater gardeners.
<G-vec00169-001-s184><collect.einsammeln><de> Sie haben oft Titel der Predigte schon auf den Umschlägen, Bleistiften, und anderen Spielereien vorgedruckt,... um das Geld einzusammeln.
<G-vec00169-001-s184><collect.einsammeln><en> They often have the titles of their messages already printed on envelopes, pencils, and other gadgets... to collect money.
<G-vec00169-001-s185><collect.einsammeln><de> Also sie wurden dafür bezahlt es von den Restaurants einzusammeln.
<G-vec00169-001-s185><collect.einsammeln><en> So they were paid to collect it from the restaurants.
<G-vec00169-001-s186><collect.einsammeln><de> Jetzt musst du Paul dabei helfen, die Puzzleteile wieder einzusammeln, damit er sein Bild zusammensetzen kann.
<G-vec00169-001-s186><collect.einsammeln><en> Now you must help Paul collect all puzzle pieces to rebuild his house.
<G-vec00169-001-s187><collect.einsammeln><de> Sind Wochen gewesen, und keiner kam, um sie einzusammeln.
<G-vec00169-001-s187><collect.einsammeln><en> Been weeks, and no one came to collect them.
<G-vec00169-001-s188><collect.einsammeln><de> KURDWATCH, 6.September2014 – Am 26.und 27.August2014 haben Mitarbeiter des Asayiş, des Sicherheitsdienstes der Partei der Demokratischen Union(PYD), in ʿAmuda und Umgebung versucht Familienbücher einzusammeln um auf dieser Basis Namenslisten zur Rekrutierung von Personen zwischen achtzehn und dreißig Jahren zu erstellen.
<G-vec00169-001-s188><collect.einsammeln><en> KURDWATCH, September6,2014—On August and August272014 in ʿAmuda and the surrounding area employees of the Asayiş, the security service of the Democratic Union Party(PYD), tried to collect family registers in order to use to them as a basis to compile recruitment lists for persons between eighteen and thirty years of age.
<G-vec00169-001-s189><collect.einsammeln><de> Du benötigst Kolonisten, um die Steuern der Eingeborenen einzusammeln.
<G-vec00169-001-s189><collect.einsammeln><en> You need colonists to collect the native taxes.
<G-vec00443-001-s081><collect.einsammeln><de> Besser gesagt, Skipper Gek gibt dir das Boot, bevor du beginnst, seine Fracht einzusammeln.
<G-vec00443-001-s081><collect.einsammeln><en> Well, Skipper Gek gives you the boat before starting to collect his cargo.
<G-vec00443-001-s082><collect.einsammeln><de> Begebe dich in ein lustiges Abenteuer und hilf dem Pinguin dabei, alle seine Kinder zu finden und einzusammeln.
<G-vec00443-001-s082><collect.einsammeln><en> Go on a fun platform adventure and help the penguin find and collect all her children.
<G-vec00443-001-s083><collect.einsammeln><de> Bei der Ankunft der Hive in Clint City hat die Königinmutter Aegis auf Aufklärungsmission geschickt, um nutzbare Energiequellen in der Stadt zu finden und einzusammeln.
<G-vec00443-001-s083><collect.einsammeln><en> Storyline When the Hive arrived in Clint City, the queen mother sent Aegis undercover to try and locate and collect the energy sources used in the town.
<G-vec00443-001-s084><collect.einsammeln><de> Ziele mit dem Strahl und versuche, die grünen Punkte einzusammeln.
<G-vec00443-001-s084><collect.einsammeln><en> Aim the beam and try to collect green dots.
<G-vec00443-001-s085><collect.einsammeln><de> Ihr Ziel besteht darin, alle Edelsteine einzusammeln, ohne auf eine Mine zu treffen.
<G-vec00443-001-s085><collect.einsammeln><en> Your aim is to collect all the gems without running into any mines.
<G-vec00443-001-s086><collect.einsammeln><de> Land, das einfach ohne Eigentümerschaft dasitzt, Banken geben den Geist auf, da sie unfähig werden, Hypotheken durchzudrücken und einzusammeln, oder Eigentum einzusammeln und es wieder zu verkaufen.
<G-vec00443-001-s086><collect.einsammeln><en> Land just sitting there with no ownership, banks belly-up unable to carry though and collect mortgages or collect properties and re-sell them.
<G-vec00443-001-s087><collect.einsammeln><de> "Ich denke dass es sinnvoller ist, diese ganze Energie zu verwenden, um die Flaschen ""vor Ort"" - oder in der Region - einzusammeln und wieder zu verwerten."
<G-vec00443-001-s087><collect.einsammeln><en> I think it is preferable to use all this energy to collect the bottles locally, for recycling.
<G-vec00443-001-s088><collect.einsammeln><de> Die Yang Energie ruft mich gewöhnlich dazu auf, meine Stärke einzusammeln und mich auf etwas zu konzentrieren... eine Art zentraler Idee, und meine Energien zu entzünden und mit Kraft und Entschiedenheit zu handeln.
<G-vec00443-001-s088><collect.einsammeln><en> Yang energy is usually calling on me to collect my strength and focus on something...some kind of central idea, and to ignite my energy and act with power and decision.
<G-vec00443-001-s089><collect.einsammeln><de> Damit all das wirklich hinhauen wird, hoffen die Devs auf Fans entsprechender Titel und damit auf eine große Community: Zum Finalisieren des Spiels bietet man den Titel auf Kickstarter an und plant, in den nächsten 29 Tagen 100.000 britische Pfund einzusammeln.
<G-vec00443-001-s089><collect.einsammeln><en> For all this to work out, the Devs are hoping for fans of appropriate titles, and thus a large community: To finalize the game, they offer the title on Kickstarter and plans to collect over the next 29 days 100,000 British pounds.
