<G-vec00337-001-s034><spur.anstoßen><de> Mit dem mit 25.000 Euro dotierten Förderpreis will der DÃ1⁄4sseldorfer Professor mit seinem Team die Entwicklung von Medikamenten anstoßen.
<G-vec00337-001-s034><spur.anstoßen><en> With the award, which is endowed with 25,000 euros, the DÃ1⁄4sseldorf professor wants to spur drug development together with his team.
<G-vec00337-001-s035><spur.anstoßen><de> Mit dem mit 25.000 Euro dotierten Förderpreis will der Düsseldorfer Professor mit seinem Team die Entwicklung von Medikamenten anstoßen.
<G-vec00337-001-s035><spur.anstoßen><en> With the award, which is endowed with 25,000 euros, the Düsseldorf professor wants to spur drug development together with his team.
<G-vec00337-001-s036><spur.anstoßen><de> Wir müssen uns vereinigen, wenn wir können, aber wir sollten auch die Debatte anstoßen und konfrontativ sein, wenn es um Positionen geht, die wir nicht teilen.
<G-vec00337-001-s036><spur.anstoßen><en> We need to unite when we can but we should also spur the debate and be confrontational when it comes to positions that we don't agree on.
<G-vec00337-001-s050><spur.anstoßen><de> Die Zusammenarbeit zwischen Privatsektor, Wissenschaft und staatlichen Einrichtungen ist zu wenig entwickelt, um Investitionen in innovative Technologien anzustoßen.
<G-vec00337-001-s050><spur.anstoßen><en> Furthermore, cooperation between the private sector, science and research, and state institutions is still underdeveloped and unable to spur investment in innovative technologies.
<G-vec00337-001-s051><spur.anstoßen><de> "Drittens: ""Koalitionen der Willigen"" sind wichtige Vehikel, um auf internationaler Ebene Veränderungen anzustoßen."
<G-vec00337-001-s051><spur.anstoßen><en> "Thirdly: ""Coalitions of the willing"" are key vehicles to spur changes at international level."
<G-vec00337-001-s022><exacerbate.anstoßen><de> Diese Flüchtlingsströme aus dem Nahen und Mittleren Osten und aus Afrika geben ihrerseits einen Anstoß zum Ausbrechen der Revolution in Europa.
<G-vec00337-001-s022><exacerbate.anstoßen><en> These refugees from the Near and Middle East and Africa exacerbate class contradictions in Europe and accelerate the outbreak of the socialist world revolution.
<G-vec00196-002-s056><instigate.anstoßen><de> Durch die Kurzfilmtage wurden viele politische und ästhetische Entwicklungen angestoßen, etwa durch das Oberhausener Manifest, das vielleicht wichtigste Gruppendokument des deutschen Films.
<G-vec00196-002-s056><instigate.anstoßen><en> Oberhausen has managed to instigate various political and aesthetical developments, for instance through the Oberhausen Manifesto, perhaps the most important group document in the history of German film.
<G-vec00663-002-s028><toast.anstoßen><de> Es wurde gelacht, gefeiert und auf unseren neuen Store angestoßen.
<G-vec00663-002-s028><toast.anstoßen><en> A toast was made to our new store with much laughter and celebrations.
<G-vec00663-002-s029><toast.anstoßen><de> Gefeiert wurde dabei im großen Stil: Die Gäste auf dem Deck der OCEANDIVA Futura wurden mit einer Flyboard-Show auf dem Wasser überrascht, für das leibliche Wohl sorgte ein Walking Dinner und natürlich wurde auf das 100-jährige Jubiläum angestoßen.
<G-vec00663-002-s029><toast.anstoßen><en> On the deck of the OCEANDIVA Futura, for instance, guests were surprised with a flyboard show on the water, after which they were treated to a walking dinner and of course a toast was made in tribute to their 100th anniversary.
<G-vec00663-002-s030><toast.anstoßen><de> Hier wird mit Begeisterung gegrillt, nach Herzenslust gegessen und mit einem Schnapserl angestoßen.
<G-vec00663-002-s030><toast.anstoßen><en> Enjoy a barbecue, eat to your heart's content and toast each other with a glass of schnapps.
<G-vec00663-002-s038><toast.anstoßen><de> Der Mann lachte, zog eine Flasche Wodka und zwei Pfirsiche aus seiner Tasche und wollte mit uns anstoßen: „Auf die Freundschaft“, sagte er.
<G-vec00663-002-s038><toast.anstoßen><en> The man then laughed, pulled a bottle of vodka and two peaches from his pocket, and proposed a toast: to friendship, he said.
<G-vec00663-002-s039><toast.anstoßen><de> Ideal zum Plaudern und Kontakteknüpfen, Tanzen, Essen und zum Anstoßen auf eine sehr erfolgreiche Veranstaltung.
<G-vec00663-002-s039><toast.anstoßen><en> Everything is on hand for mingling and networking, dancing and dining, and raising a toast to a thoroughly successful event.
<G-vec00663-002-s040><toast.anstoßen><de> Ein leckeres Essen, ein guter Wein und Freunde zum Anstoßen...
<G-vec00663-002-s040><toast.anstoßen><en> A delicious meal, a good wine and nice friends to toast with...
<G-vec00663-002-s041><toast.anstoßen><de> Die heurige Ausgabe der Marmomac in Verona wird eine besondere für uns werden: wir wollen nicht nur an dem Erfolg unseres neuen Standkonzepts vom Vorjahr anknüpfen, sondern auch zusammen mit Ihnen auf unser 70-jähriges Firmenjubiläum anstoßen.
<G-vec00663-002-s041><toast.anstoßen><en> This year’s edition of the Marmomac Fair in Verona will be special for us: not only we want to continue our success of our new stand concept from last year, but also toast together with you on our 70th anniversary.
<G-vec00663-002-s042><toast.anstoßen><de> Wenn Sie mit Wein zu viel anstoßen, können Sie Ihren Körper einen Tag später reinigen, Sie können zu unserem Wellness im Sauna Center Hotel Bau Maribor (oder vielleicht sogar mit Freunden oder Partnern) kommen und in Ruhe entspannen.
<G-vec00663-002-s042><toast.anstoßen><en> If you are going to toast with wine too much you might want to purify your body a day after, you can come to our wellness at the Sauna Center Hotel Bau Maribor (or maybe even with friends or partner) and relax in peace.
<G-vec00663-002-s043><toast.anstoßen><de> Am Vorabend zum ganztägigen Meeting treffen wir uns ab 16 Uhr ganz locker zum gemeinsamen Grillen, Feiern und Anstoßen.
<G-vec00663-002-s043><toast.anstoßen><en> On the evening before the all-day meeting, we meet at 4 pm for a relaxed barbecue, to celebrate and raise our glasses in a toast.
<G-vec00663-002-s044><toast.anstoßen><de> Auf Sie warten coole Stand- und Messepartys, sportliche Stimmung und immer ein kühles Getränk zum Anstoßen.
<G-vec00663-002-s044><toast.anstoßen><en> There are lots of cool stand and show parties, a sporty and relaxed atmosphere and always a cold drink somewhere on offer so you can make a toast.
<G-vec00663-002-s045><toast.anstoßen><de> Nach getaner Arbeit kann man mit den Partnern an der Bar auf erfolgreiche Geschäfte anstoßen.
<G-vec00663-002-s045><toast.anstoßen><en> After work is done, you can toast to successful business with your partners at the bar.
<G-vec00663-002-s046><toast.anstoßen><de> Gleich während der einleitenden Worte entstand eine sehr angenehme und freundschaftliche Atmosphäre, welche durch das feierliche Anstoßen mit 15 Jahre altem Sekt nur noch besser wurde.
<G-vec00663-002-s046><toast.anstoßen><en> It was already during the opening speech that a pleasant, friendly atmosphere filled the room and was even further intensified with a ceremonial toast of 15-year-old sparkling wine.
<G-vec00663-002-s047><toast.anstoßen><de> Ihr Zimmer ist liebevoll mit Schokoladeherzen dekoriert und es wartet bereits eine gekühlte Flasche Südtiroler Sekt und frische Erdbeeren zum Anstoßen auf Sie.
<G-vec00663-002-s047><toast.anstoßen><en> On your arrival your room is decorated with great care with chocolate hearts and a bottle of South Tyrolean sparkling wine and fresh strawberries are waiting for you for a first toast.
<G-vec00663-002-s048><toast.anstoßen><de> Lassen Sie uns anstoßen auf 30 Jahre alessandro.
<G-vec00663-002-s048><toast.anstoßen><en> Let’s drink a toast to 30 years of alessandro.
<G-vec00663-002-s049><toast.anstoßen><de> Unterschiedliche Kameraeinstellungen in der Vorschau und der Szene selbst: Als Lance und Kathryn auf ihre kommende Reise nach Afrika anstoßen, sieht man in der Vorschau (vor dem Vorspann) eine Weitwinkeleinstellung (linkes Bild), während die Szene selbst Nahaufnahmen liefert.
<G-vec00663-002-s049><toast.anstoßen><en> Different camera angles in the sneak preview and the scene itself: When Lance and Kathryn toast to their upcoming trip to Africa at The Max, the sneak preview shows a wide angle shot (left screen grab), but the scene itself features close-ups.
<G-vec00663-002-s050><toast.anstoßen><de> Genießen Sie die unbeschwerte und doch einzigartige Atmosphäre unserer Bar: während Sie mit einem Glas Champagner Ruinart Blanc de Blancs anstoßen, die Piano-Musik im Hintergrund lauschen, können Sie die Ereignisse des gemeinsam verbrachten Tages nochmals im Gedanken durchleben und dabei unseren Picasso bestaunen.
<G-vec00663-002-s050><toast.anstoßen><en> Enjoy the carefree and yet unique atmosphere of our bar. While you raise a toast with a glass of Ruinart Blanc de Blancs champagne, listen to the piano music playing in the background, you can reflect on the day’s events you spent together by reliving them in your thoughts while admiring our Picasso.
<G-vec00663-002-s051><toast.anstoßen><de> Feiern Sie Erfolge und ehren Sie Leistungen - sowohl von ganzen Teams, aber auch einzelnen Team-Mitgliedern - indem Sie sie unternehmensweit verkünden, eine Runde Applaus spendieren und vielleicht sogar einen Drink zum Anstoßen.
<G-vec00663-002-s051><toast.anstoßen><en> Celebrate successes and honor achievements - both of entire teams and individual team member - by announcing them company-wide, giving them a round of applause and maybe even buying everyone a drink to toast with.
<G-vec00663-002-s052><toast.anstoßen><de> Wenn Sie auf andere anstoßen möchten, halten Sie mit der rechten Hand den linken Finger und halten Sie ihn vorsichtig an der Unterseite des Bechers, um Respekt zu zeigen.
<G-vec00663-002-s052><toast.anstoßen><en> If you want to toast to others, use your right hand to hold the left hand finger and gently hold it on the bottom of the cup to show respect.
<G-vec00663-002-s053><toast.anstoßen><de> Typischerweise enden diese Ausflüge feuchtfröhlich in der Weinestube, wo Sie auf Ihre Naturliebe anstoßen können.
<G-vec00663-002-s053><toast.anstoßen><en> Happily, the strolls typically end at a tasting room, where you can toast your enhanced appreciation of the great outdoors.
<G-vec00663-002-s054><toast.anstoßen><de> Mit einem kleinen Snack von unserem bevorzugten Lieferanten und etwas zum Anstoßen feierten wir in einem kleinen Rahmen dieses schöne Ereignis.
<G-vec00663-002-s054><toast.anstoßen><en> With a little snack from our preferred supplier and something to toast with we celebrated in a small setting this nice event.
<G-vec00663-002-s057><toast.anstoßen><de> Es ist doch immer wieder schön, in der gemütlichen Adventszeit zusammen zu sitzen und gemeinsam auf ein erfolgreiches Jahr anzustoßen.
<G-vec00663-002-s057><toast.anstoßen><en> It is always so nice to sit down together during the cosy Advent season to drink a toast to a successful New Year.
<G-vec00663-002-s058><toast.anstoßen><de> Die Tradition des Jakobsweges besagt, dass die Pilger hier anhalten müssen, um auf das Glück anzustoßen.
<G-vec00663-002-s058><toast.anstoßen><en> According to the tradition on the Camino de Santiago, pilgrims must stop at it to toast happiness. Linking to other Caminos
<G-vec00663-002-s059><toast.anstoßen><de> Am hinteren Ende des Zuges versammeln sich die Passagiere in einem Waggon mit gewölbtem Glasdach, um auf eine gute Reise anzustoßen.
<G-vec00663-002-s059><toast.anstoßen><en> At the rear of the train, in the domed Park Car, passengers are gathering for a champagne “bon voyage” toast.
<G-vec00663-002-s060><toast.anstoßen><de> In unseren herrlichen Räumen oder im Sommer am Brunnen im wunderschönen Innenhof haben Sie anschließend die Möglichkeit, mit einen Glas Burgundersekt auf Ihr gemeinsames Leben anzustoßen.
<G-vec00663-002-s060><toast.anstoßen><en> This includes our magnificent interior spaces or perhaps a summer event in the fantastic inner courtyard around the old well, with a flute of fine sparkling Pinot to toast your new lives together.
<G-vec00663-002-s061><toast.anstoßen><de> Rund 40 urgemütliche Hütten laden schon tagsüber dazu ein, auf einen perfekten Skitag anzustoßen und ziehen Après-Ski-Fans an.
<G-vec00663-002-s061><toast.anstoßen><en> Already during the day, around 40 rustically cosy huts invite you in to toast to a perfect day's skiing, and are the magnet of apres ski.
<G-vec00663-002-s062><toast.anstoßen><de> Künstler wie Francesca Michielin, Maneskin und Max Gazzè waren Teil der Besetzung und brachten eine große Menschenmenge zusammen, um auf 100 Jahre Freude mit Aperol anzustoßen.
<G-vec00663-002-s062><toast.anstoßen><en> Artists such as Francesca Michielin, Maneskin, and Max Gazzè were part of the lineup and united a large crowd together to toast to 100 years of Joy with Aperol.
<G-vec00663-002-s063><toast.anstoßen><de> Der B52 Shot ist ideal, um eine Runde mit den besten Freunden zu trinken und auf einen netten Abend anzustoßen.
<G-vec00663-002-s063><toast.anstoßen><en> The B52 is the ideal drink to enjoy in a round with the best friends and toast to a lovely evening.
<G-vec00663-002-s064><toast.anstoßen><de> Das ist die perfekte Art, auf das Ende einer weiteren Spring Championship of Online Poker (SCOOP) anzustoßen.
<G-vec00663-002-s064><toast.anstoßen><en> It’s the perfect way to toast the end of another fantastic Spring Championship of Online Poker (SCOOP).
<G-vec00663-002-s080><toast.anstoßen><de> So sehr ich mich auf 2014 freue, und bevor wir alle in die Partykleider hüpfen, muss ich schnell noch auf meinen Lieblingskauf des letzten Jahres anstoßen.
<G-vec00663-002-s080><toast.anstoßen><en> As much as I look forward to 2014, and before we all put on our party dresses, I thought I'd toast my favourite buy of the past year.
<G-vec00663-002-s081><toast.anstoßen><de> Zum Beispiel: “Lasst uns nun auf das Glück von Kathi und Hannes anstoßen.
<G-vec00663-002-s081><toast.anstoßen><en> For example: "Let us now toast the happiness of Jill and Jack.
