<G-vec00337-001-s034><spur.anstoßen><de> Mit dem mit 25.000 Euro dotierten Förderpreis will der DÃ1⁄4sseldorfer Professor mit seinem Team die Entwicklung von Medikamenten anstoßen.
<G-vec00337-001-s034><spur.anstoßen><en> With the award, which is endowed with 25,000 euros, the DÃ1⁄4sseldorf professor wants to spur drug development together with his team.
<G-vec00337-001-s035><spur.anstoßen><de> Mit dem mit 25.000 Euro dotierten Förderpreis will der Düsseldorfer Professor mit seinem Team die Entwicklung von Medikamenten anstoßen.
<G-vec00337-001-s035><spur.anstoßen><en> With the award, which is endowed with 25,000 euros, the Düsseldorf professor wants to spur drug development together with his team.
<G-vec00337-001-s036><spur.anstoßen><de> Wir müssen uns vereinigen, wenn wir können, aber wir sollten auch die Debatte anstoßen und konfrontativ sein, wenn es um Positionen geht, die wir nicht teilen.
<G-vec00337-001-s036><spur.anstoßen><en> We need to unite when we can but we should also spur the debate and be confrontational when it comes to positions that we don't agree on.
<G-vec00337-001-s050><spur.anstoßen><de> Die Zusammenarbeit zwischen Privatsektor, Wissenschaft und staatlichen Einrichtungen ist zu wenig entwickelt, um Investitionen in innovative Technologien anzustoßen.
<G-vec00337-001-s050><spur.anstoßen><en> Furthermore, cooperation between the private sector, science and research, and state institutions is still underdeveloped and unable to spur investment in innovative technologies.
<G-vec00337-001-s051><spur.anstoßen><de> "Drittens: ""Koalitionen der Willigen"" sind wichtige Vehikel, um auf internationaler Ebene Veränderungen anzustoßen."
<G-vec00337-001-s051><spur.anstoßen><en> "Thirdly: ""Coalitions of the willing"" are key vehicles to spur changes at international level."
<G-vec00337-001-s022><exacerbate.anstoßen><de> Diese Flüchtlingsströme aus dem Nahen und Mittleren Osten und aus Afrika geben ihrerseits einen Anstoß zum Ausbrechen der Revolution in Europa.
<G-vec00337-001-s022><exacerbate.anstoßen><en> These refugees from the Near and Middle East and Africa exacerbate class contradictions in Europe and accelerate the outbreak of the socialist world revolution.
<G-vec00196-002-s056><instigate.anstoßen><de> Durch die Kurzfilmtage wurden viele politische und ästhetische Entwicklungen angestoßen, etwa durch das Oberhausener Manifest, das vielleicht wichtigste Gruppendokument des deutschen Films.
<G-vec00196-002-s056><instigate.anstoßen><en> Oberhausen has managed to instigate various political and aesthetical developments, for instance through the Oberhausen Manifesto, perhaps the most important group document in the history of German film.
