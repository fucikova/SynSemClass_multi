<G-vec00057-001-s114><turn.biegen><de> Hier biegen Sie im ersten Kreisverkehr rechts ab, Richtung Clenze und gleich wieder rechts über Satemin nach Jabel.
<G-vec00057-001-s114><turn.biegen><en> Here you turn right at the first roundabout, direction Clenze and right again over Satemin to Jabel.
<G-vec00057-001-s115><turn.biegen><de> Nun, wenn Sie biegen in eine VIP hier bei WebcamsFetish.com genießen Sie die begehrten Vergünstigungen, die haben andere Männer vor Neid erblassen.
<G-vec00057-001-s115><turn.biegen><en> Now if you turn into a VIP here at WebcamsFetish.com, you'll enjoy coveted perks which will have other men are green with envy.
<G-vec00057-001-s116><turn.biegen><de> Nach nur einem Häuserblock biegen Sie erneut am Stoppschild rechts ab.
<G-vec00057-001-s116><turn.biegen><en> Just 1 block down at the stop sign make another right turn.
<G-vec00057-001-s117><turn.biegen><de> Gewidmet dem Verkauf und Installation von Biogasanlagen für Abwasser tratamineto und biegen sie in Biogas.
<G-vec00057-001-s117><turn.biegen><en> On sale dedicated and installation of biodigestores for the tratamineto of you excrete and to turn them into biogas.
<G-vec00057-001-s118><turn.biegen><de> Gehen Sie die Grand Rue für 400 m und biegen dann rechts in Montée des Capucins, am oberen Ende der Treppe.
<G-vec00057-001-s118><turn.biegen><en> Walk up Grand Rue for 400 m and then turn right at Montée des Capucins, at the top of the stairs.
<G-vec00057-001-s119><turn.biegen><de> Folgen Sie dem Boulevard de la République und biegen Sie links in die Rue Gabriel Péri.
<G-vec00057-001-s119><turn.biegen><en> Continue along the boulevard de la Répub lique and turn left on rue Gabriel Péri.
<G-vec00057-001-s120><turn.biegen><de> Mehr erfahren Gehen Sie zurück zur Einkaufsstraße und biegen Sie rechts ab, wo kurz danach links die Kunsteinrichtung Heden zu finden ist.
<G-vec00057-001-s120><turn.biegen><en> Walk back to the shopping street and turn right, where you will find art institute Heden almost immediately on your left.
<G-vec00057-001-s121><turn.biegen><de> Nehmen Sie immer die roten und weißen Taxi vor der Bushaltestelle.Mit dem Bus: Wenn Sie auf der lokalen Intercity Busbahnhof ankommen, gehen Sie geradeaus bis zur Ausfahrt Türen, biegen rechts ab und gehen etwa fünf Minuten bis zum zentralen Busbahnhof vorbei zum Parkplatz.
<G-vec00057-001-s121><turn.biegen><en> Always take the red and white taxi in front of bus station.By bus: When you arrive at the local Intercity Bus Station, walk straight ahead to the exit doors, turn right and walk about five minutes to the central bus Terminal, passing the parking lot.
<G-vec00057-001-s122><turn.biegen><de> In Künzelsau folgen Sie kurz der Komburgstraße und biegen links bei erster Gelegenheit in die Hauptstraße.
<G-vec00057-001-s122><turn.biegen><en> In Künzelsau, you have to follow the Komburgstraße and turn to the left onto the Hauptstraße at the first possibility.
<G-vec00057-001-s123><turn.biegen><de> Zugang: In Bozen, am Kreisverkehr auf die Via Meran, weiter vorbei an der Station und der Kreuzung über Drusen in Krankenhaus-Management folgen mit Via San Maurizio, nachdem es Parkplätze auf der rechten Seite, von hier fahren die Straße entlang und biegen via S. Maurizio, unmittelbar nachdem es ein Körper und links, der Eingang zu der Klippe.
<G-vec00057-001-s123><turn.biegen><en> Access: In Bolzano, follow via Druso in the direction of the hospital, at the roundabout take via Merano, continue past the petrol station and the intersection with via S. Maurizio, immediately after there is a parking lot on the right, from here skirt the road and turn by S. Maurizio, immediately after there is a body and on the left, the entrance to the cliff.
<G-vec00057-001-s124><turn.biegen><de> Rüsten Sie Ihren LKW schneller fahren, biegen schärfer, Spray weiter und führen mehr Wasser.
<G-vec00057-001-s124><turn.biegen><en> Upgrade your truck to drive faster, turn sharper, spray further, and carry more water.
<G-vec00057-001-s125><turn.biegen><de> Katzen sind mit geraden Ohren geboren und um bis zu zehn Tagen zu biegen beginnen.
<G-vec00057-001-s125><turn.biegen><en> Cats are born with straight ears and will begin to turn the ten days.
<G-vec00057-001-s126><turn.biegen><de> Wir fahren vorbei an Mozelj bis nach Rajndol und biegen links nach Knežja Lipa ab.
<G-vec00057-001-s126><turn.biegen><en> We will cycle past Mozelj to Rajndol, and then turn left towards Knežja Lipa.
<G-vec00057-001-s127><turn.biegen><de> Aus Frankfurt fahren Sie auf der A66 bis zur Abfahrt Wallau, dort biegen Sie rechts ab und fahren in Richtung Wallau Industriegebiet.
<G-vec00057-001-s127><turn.biegen><en> From Frankfurt you take the A66 until the exit 'Wallau', from there you turn to the right and drive towards 'Wallau Industriegebiet'.
<G-vec00057-001-s128><turn.biegen><de> Aus Richtung Jena (B7) kommend, folgen Sie der Jenaer Straße bis zur zweiten Ampelkreuzung und biegen dort nach links in die Hans-Wahl-Straße, fahren dann rechts über die Kegelbrücke, anschließend zwei mal links in Richtung Burgplatz und Ackerwand (Einfahrt Tiefgarage = Parkhaus am Goethehaus).
<G-vec00057-001-s128><turn.biegen><en> Follow B7, Jenaer Straße, turn left at the second traffic light. Turn right and cross the river Ilm, after the bridge turn left, cross Burgplatz and Platz der Demokratie, at the end turn right into Ackerwand. Turn left into the parking (am Goethehaus & Dorint) or to the main entrance of the hotel. Please follow the hotelroute red.
<G-vec00057-001-s129><turn.biegen><de> Barrenechea und biegen rechts in die Calle 32.
<G-vec00057-001-s129><turn.biegen><en> Barrenechea and turn right on Calle 32.
<G-vec00057-001-s130><turn.biegen><de> Vor dem Hotel Luggi (Pyramide) biegen Sie links ein und fahren die Seitenstraße weiter bis Sie auf der rechten Straßenseite das Appart Irmgard sehen.
<G-vec00057-001-s130><turn.biegen><en> You have to turn left before Hotel Luggi. drive until you see our house on the right side Book now Photos
<G-vec00057-001-s131><turn.biegen><de> Vor der Stadt Ribnica biegen wir rechts in Richtung der Dörfer Goriča und Nemška vas.
<G-vec00057-001-s131><turn.biegen><en> We will turn right towards the villages of Goriča vas and Nemška vas before the town of Ribnica.
<G-vec00057-001-s132><turn.biegen><de> Überqueren Sie die Straße und biegen Sie links ab.3.
<G-vec00057-001-s132><turn.biegen><en> Cross the street and turn left.3.
<G-vec00057-001-s152><turn.biegen><de> Autobahn A18 Messina - Catania, Ausfahrt Fiumefreddo;Biegen Sie links ab in Richtung Linguaglossa und Lingfield.
<G-vec00057-001-s152><turn.biegen><en> Highway A18 Messina - Catania, exit Fiumefreddo;Turn left in the direction of Piedimonte Etneo and Lingfield.
<G-vec00057-001-s153><turn.biegen><de> Biegen Sie links ab und gehen Sie am Waldrand entlang.
<G-vec00057-001-s153><turn.biegen><en> At the wood, turn left to walk along this wood.
<G-vec00057-001-s154><turn.biegen><de> Abbiegen Richtung Ockelbo Straße 303. dann Richtung Zentrum und dann an der Kirche vorbei und biegen Sie die erste Straße rechts auf Åmotvägen gegen Rönnåsen.
<G-vec00057-001-s154><turn.biegen><en> Turn towards Ockelbo road 303rd Drive then towards the center and then past the church and turn first right on Åmotvägen against Rönnåsen.
<G-vec00057-001-s155><turn.biegen><de> Auf einer bemehlten Fläche Ausrollen Tortillas mit einer Back und her Bewegung, drehen die tortilla 1/4 Biegen Sie nach jeder Rolle.
<G-vec00057-001-s155><turn.biegen><en> On a floured surface roll out tortillas using a back and forth motion, turning the tortilla 1/4 turn after each roll.
<G-vec00057-001-s156><turn.biegen><de> Anfahrt Aus dem Bahnhof, biegen Sie links ab bis Manchia St für 200 m biegen Sie dann links bis Mohammed Farid St für 200m.
<G-vec00057-001-s156><turn.biegen><en> Directions Coming out of the train station, turn left up Manchia St for 200m then turn left up Mohammed Farid St for 200m.
<G-vec00057-001-s158><turn.biegen><de> "Folgen Sie dieser Straße etwa 1,7 km und biegen Sie nach links ab entsprechend dem Wegweiser ""Hotel Humaina""."
<G-vec00057-001-s158><turn.biegen><en> Follow this road for 1.7 km and turn left by the sign for Hotel Humaina.
<G-vec00057-001-s159><turn.biegen><de> Nach 2 km Fahrt biegen Sie rechts ab (Schild-Postolowo 8 km) und gehen stright die Entfernung 8,2 km zu Czastkowo.
<G-vec00057-001-s159><turn.biegen><en> After 2 km drive turn right (sign-post: Postolowo 8 km) and go stright the distance 8,2 km to Czastkowo.
<G-vec00057-001-s160><turn.biegen><de> Von hier immer in Richtung Tropea, weiter nach Nicotera, Joppolo, Coccorino e Panaia dann biegen Sie links ab, um Ricadi zu erreichen e S.Nicolò Von hier aus müssen Sie nach unseren braunen Touristenschildern in Richtung Tropea weiterfahren.
<G-vec00057-001-s160><turn.biegen><en> From here, always in the direction of Tropea, continue to Nicotera, Joppolo, Coccorino and Panaja and then turn left to reach Ricadi and S. Nicolò from where you must then continue, according to our brown tourist signs, towards Tropea .
<G-vec00057-001-s161><turn.biegen><de> - An der zweiten Ampel biegen Sie links ab Richtung Radeberg/ Pillnitz/ Bergbahn.
<G-vec00057-001-s161><turn.biegen><en> - Turn left at the 2nd set of traffic lights towards Radeberg/ Pillnitz/Bergbahn.
<G-vec00057-001-s162><turn.biegen><de> Biegen Sie in Ebhausen rechts ab, fahren Sie durch Ebershardt und weiter in Richtung Wart.
<G-vec00057-001-s162><turn.biegen><en> In Ebhausen turn right to go through Ebershardt and then use directions to Wart.
<G-vec00057-001-s163><turn.biegen><de> Biegen Sie links im Margaretengürtel ein, folgen dem Margaretengürtel in Richtung Gürtel West bis Sie die Ottakringer Straße erreichen.
<G-vec00057-001-s163><turn.biegen><en> Turn left into Margaretengürtel, follow the Margaretengürtel in direction Gürtel West until the Ottakringer Straße .
<G-vec00057-001-s164><turn.biegen><de> Biegen Sie an der T-Kreuzung nach rechts in Richtung Norra Mellbystrand ab.
<G-vec00057-001-s164><turn.biegen><en> Turn right at the T-junction towards Norra Mellbystrand.
<G-vec00057-001-s165><turn.biegen><de> Verlassen Sie die ST 2045 und biegen Sie links in die Äußere Moosburger Straße ein (vor der Tankstelle PAF PETROL).
<G-vec00057-001-s165><turn.biegen><en> Leave the ST 2045 and turn left onto Äußere Moosburger Straße (before the PAF PETROL filling station).
<G-vec00057-001-s166><turn.biegen><de> Spaziergang entlang Newski-Allee in Richtung Newa bewundern Kirche am vergossenen Blutes, Kasaner Kathedrale und andere Sehenswürdigkeiten, über die Grüne Brücke und biegen Sie rechts in die erste Straße (Bolschaja Morskaja).
<G-vec00057-001-s166><turn.biegen><en> Walk along Nevsky avenue in the direction of Neva river admiring Church on Spilled Blood, Kazan Cathedral and other attractions, cross the Green Bridge and turn right on the first street (Bolshaya Morskaya).
<G-vec00057-001-s167><turn.biegen><de> Dann biegen Sie links ab und nach 500 m biegen Sie rechts in Richtung Cropigny ab und überqueren diesen Ort.
<G-vec00057-001-s167><turn.biegen><en> Then turn left on it and 500 m turn right towards Cropigny and cross this locality.
<G-vec00057-001-s169><turn.biegen><de> "An der Kreuzung ""Einde Were - Nieuwewandeling"" biegen Sie rechts in Richtung ""Centrum - Gevangenis"" ab."
<G-vec00057-001-s169><turn.biegen><en> "At intersection ""Einde Were - Nieuwewandeling"" turn right, at the traffic lights (direction Centrum-Gevangenis)."
<G-vec00057-001-s170><turn.biegen><de> *Biegen Sie in die zweite Möglichkeit, das ist, was mich betrifft, ist wirklich, dass der Schauspieler ist die Organisation des Islamischen Staates (ISIS).
<G-vec00057-001-s170><turn.biegen><en> *Turn to the second possibility which is what really concerns me is that the actor is the organization of the Islamic State (ISIS).
<G-vec00245-003-s114><turn_up.biegen><de> Danach biegen wir in die palmenbewachsene und geschäftige Strandpromenade des Canteras Strandes ein.
<G-vec00245-003-s114><turn_up.biegen><en> Afterwards we turn into the busy, palm-lined promenade.
<G-vec00245-003-s115><turn_up.biegen><de> Verlassen Sie die „Mügelner Straße“ und biegen rechts in die Straße „Moränenende“ ein.
<G-vec00245-003-s115><turn_up.biegen><en> Please leave the road “Mügelner Straße” and turn right into the road “Moränenende”.
<G-vec00245-003-s116><turn_up.biegen><de> Dort biegen Sie rechts in den Teuffenbachweg ein und folgen diesem bis zur Pension Sulzauhof.
<G-vec00245-003-s116><turn_up.biegen><en> There you turn right on the Teuffenbachweg and follow it to the Pension Sulzauhof.
<G-vec00245-003-s117><turn_up.biegen><de> Biegen Sie an der nächsten Möglichkeit links auf das ehemalige Praktiker/Max Bahr Gelände.
<G-vec00245-003-s117><turn_up.biegen><en> At the next intersection please turn left onto the area which was formerly owned by the hardware stores Praktiker/Max Bahr.
<G-vec00245-003-s118><turn_up.biegen><de> Am Sägewerk biegen wir in Via dei Lach ein und wir fahren am kleinen Fußballplatz vorbei.
<G-vec00245-003-s118><turn_up.biegen><en> At the sawmill we turn into Via dei Lach and we go past the small football pitch.
<G-vec00245-003-s119><turn_up.biegen><de> Nach etwa 300 Metern biegen Sie unmittelbar nach dem Supermarkt rechts ab, dann noch zwei Rechtskurven und noch einmal links (Achtung der Beschilderung).
<G-vec00245-003-s119><turn_up.biegen><en> After about 300 meters, you take a right turn immediately after the supermarket, then two more right turns, and another left turn (watch out for the signs).
<G-vec00245-003-s120><turn_up.biegen><de> Auf der B15 biegen Sie in Buchhausen links Richtung Schierling ab.
<G-vec00245-003-s120><turn_up.biegen><en> You turn left on the B15 in Buchhausen in the direction of Schierling.
<G-vec00245-003-s121><turn_up.biegen><de> An der Kreuzung mit der Straße biegen wir nach links zum Dorf Čezsoča ab und fahren von hier nach rechts über die Brücke des Sočaflusses.
<G-vec00245-003-s121><turn_up.biegen><en> At the junction with the asphalt road, turn left to Čezsoča and from there right and across the bridge over the Soča River.
<G-vec00245-003-s122><turn_up.biegen><de> Biegen an der Jerrabomberra Avenue an der Ampelkreuzung rechts ab.
<G-vec00245-003-s122><turn_up.biegen><en> Turn right at the traffic lights at the intersection of Jerrabomberra Avenue.
<G-vec00245-003-s123><turn_up.biegen><de> Dort biegen wir rechts in die Mozartstraße ein und steuern direkt auf die Theresienwiese, dem berühmten Schauplatz des Oktoberfests, zu.
<G-vec00245-003-s123><turn_up.biegen><en> At the square, turn right into “Mozartstraße” and head directly towards “Theresienwiese”, the famous setting for Munich’s annual Oktoberfest.
<G-vec00245-003-s124><turn_up.biegen><de> Durch Rohrendorf fahren Sie geradeaus bis fast zum Ortsende, dort nehmen Sie die letzte Abbiegemöglichkeit nach links und biegen in die Lenz Moser Straße.
<G-vec00245-003-s124><turn_up.biegen><en> Drive straight ahead till nearly the end of the town, there take the last possibility to turn left. Now Krems / Austria
<G-vec00245-003-s125><turn_up.biegen><de> • Nach ±2 Km kommen Sie erneut an einen Kreisel, hier biegen Sie linksab.
<G-vec00245-003-s125><turn_up.biegen><en> • After ±2 km you get to another roundabout, here you must turn left.
<G-vec00245-003-s126><turn_up.biegen><de> Aus Richtung Norden (Berlin) und aus Richtung Süden (Chemnitz, Nürnberg, Stuttgart): Fahren Sie auf der A4 bis zum Dreieck Dresden West und biegen dann auf die A17 Richtung Prag/ Dresden Gorbitz ab.
<G-vec00245-003-s126><turn_up.biegen><en> From the north (Berlin) and the south (Chemnitz, Nuremberg, Stuttgart): Take the A4 motorway to the Dresden West interchange, then turn off onto the A17 towards Prague/ Dresden Gorbitz.
<G-vec00245-003-s127><turn_up.biegen><de> Nun kommen Sie wieder zu einer Weggabelung, dort laufen Sie hinunter und biegen dann rechts Richtung Hartkaiser hinauf.
<G-vec00245-003-s127><turn_up.biegen><en> Then you come to another fork where you run downhill and then turn right heading towards Hartkaiser.
<G-vec00245-003-s128><turn_up.biegen><de> Folgen Sie nun geradeaus der Via XX Settembre und biegen dann einmal links, in die Via Pastrengo (sofort nach dem Schatzministerium), und dann nochmals links in die Via Cernaia ein.
<G-vec00245-003-s128><turn_up.biegen><en> Go straight on Via XX Settembre and turn left into Via Pastrengo (immediately after the Depatment of the Treasury) and turn left again into Via Cernia.
<G-vec00245-003-s129><turn_up.biegen><de> Wir fahren vorbei an Mozelj bis nach Rajndol und biegen links nach Knežja Lipa ab.
<G-vec00245-003-s129><turn_up.biegen><en> We will cycle past Mozelj to Rajndol, and then turn left towards Knežja Lipa.
<G-vec00245-003-s130><turn_up.biegen><de> In der Peripherie der Stadt biegen wir rechts in Richtung Pietralunga und sofort anschließend links ab und folgen den Hinweisschildern zum Krankenhaus, wodurch wir den Stadtverkehr von Città di Castello vermeiden.
<G-vec00245-003-s130><turn_up.biegen><en> When you get to the outskirts of the town, turn right towards Pietralunga, and then straight afterwards, bear left at the junction and follow the signs for the hospital.
<G-vec00245-003-s131><turn_up.biegen><de> Mit dem Wagen fahren wir von Jičín in Richtung Lomnice und hinter Valdice in der Ortschaft Těšín biegen wir nach Soběraz ab, weiter in die Wälder von Bradlec über Kumburský Újezd zur Gaststätte Na Klepandě.
<G-vec00245-003-s131><turn_up.biegen><en> If you set out by car from Jičín,go towards Lomnice, and after Valdice, near the village of Těšín, turn to Soběraz, to the forests of Bradlec via Kumburský Újezd to the restaurant named Na Klepandě.
<G-vec00245-003-s132><turn_up.biegen><de> Wir fahren von der E 28 auf der Höhe des Zentrums Matarnia ab (auf der rechten Seite zu sehen), biegen links ab und richten uns nach der Straβe 472 zum Flughafen.
<G-vec00245-003-s132><turn_up.biegen><en> you drive the ring road towards Gdansk. On your left airport control tower will appear. By Matarnia Shopping Center (visible on the right) you turn left into road 472.
<G-vec00309-003-s114><turn_out.biegen><de> Danach biegen wir in die palmenbewachsene und geschäftige Strandpromenade des Canteras Strandes ein.
<G-vec00309-003-s114><turn_out.biegen><en> Afterwards we turn into the busy, palm-lined promenade.
<G-vec00309-003-s115><turn_out.biegen><de> Verlassen Sie die „Mügelner Straße“ und biegen rechts in die Straße „Moränenende“ ein.
<G-vec00309-003-s115><turn_out.biegen><en> Please leave the road “Mügelner Straße” and turn right into the road “Moränenende”.
<G-vec00309-003-s116><turn_out.biegen><de> Dort biegen Sie rechts in den Teuffenbachweg ein und folgen diesem bis zur Pension Sulzauhof.
<G-vec00309-003-s116><turn_out.biegen><en> There you turn right on the Teuffenbachweg and follow it to the Pension Sulzauhof.
<G-vec00309-003-s117><turn_out.biegen><de> Biegen Sie an der nächsten Möglichkeit links auf das ehemalige Praktiker/Max Bahr Gelände.
<G-vec00309-003-s117><turn_out.biegen><en> At the next intersection please turn left onto the area which was formerly owned by the hardware stores Praktiker/Max Bahr.
<G-vec00309-003-s118><turn_out.biegen><de> Am Sägewerk biegen wir in Via dei Lach ein und wir fahren am kleinen Fußballplatz vorbei.
<G-vec00309-003-s118><turn_out.biegen><en> At the sawmill we turn into Via dei Lach and we go past the small football pitch.
<G-vec00309-003-s119><turn_out.biegen><de> Nach etwa 300 Metern biegen Sie unmittelbar nach dem Supermarkt rechts ab, dann noch zwei Rechtskurven und noch einmal links (Achtung der Beschilderung).
<G-vec00309-003-s119><turn_out.biegen><en> After about 300 meters, you take a right turn immediately after the supermarket, then two more right turns, and another left turn (watch out for the signs).
<G-vec00309-003-s120><turn_out.biegen><de> Auf der B15 biegen Sie in Buchhausen links Richtung Schierling ab.
<G-vec00309-003-s120><turn_out.biegen><en> You turn left on the B15 in Buchhausen in the direction of Schierling.
<G-vec00309-003-s121><turn_out.biegen><de> An der Kreuzung mit der Straße biegen wir nach links zum Dorf Čezsoča ab und fahren von hier nach rechts über die Brücke des Sočaflusses.
<G-vec00309-003-s121><turn_out.biegen><en> At the junction with the asphalt road, turn left to Čezsoča and from there right and across the bridge over the Soča River.
<G-vec00309-003-s122><turn_out.biegen><de> Biegen an der Jerrabomberra Avenue an der Ampelkreuzung rechts ab.
<G-vec00309-003-s122><turn_out.biegen><en> Turn right at the traffic lights at the intersection of Jerrabomberra Avenue.
<G-vec00309-003-s123><turn_out.biegen><de> Dort biegen wir rechts in die Mozartstraße ein und steuern direkt auf die Theresienwiese, dem berühmten Schauplatz des Oktoberfests, zu.
<G-vec00309-003-s123><turn_out.biegen><en> At the square, turn right into “Mozartstraße” and head directly towards “Theresienwiese”, the famous setting for Munich’s annual Oktoberfest.
<G-vec00309-003-s124><turn_out.biegen><de> Durch Rohrendorf fahren Sie geradeaus bis fast zum Ortsende, dort nehmen Sie die letzte Abbiegemöglichkeit nach links und biegen in die Lenz Moser Straße.
<G-vec00309-003-s124><turn_out.biegen><en> Drive straight ahead till nearly the end of the town, there take the last possibility to turn left. Now Krems / Austria
<G-vec00309-003-s125><turn_out.biegen><de> • Nach ±2 Km kommen Sie erneut an einen Kreisel, hier biegen Sie linksab.
<G-vec00309-003-s125><turn_out.biegen><en> • After ±2 km you get to another roundabout, here you must turn left.
<G-vec00309-003-s126><turn_out.biegen><de> Aus Richtung Norden (Berlin) und aus Richtung Süden (Chemnitz, Nürnberg, Stuttgart): Fahren Sie auf der A4 bis zum Dreieck Dresden West und biegen dann auf die A17 Richtung Prag/ Dresden Gorbitz ab.
<G-vec00309-003-s126><turn_out.biegen><en> From the north (Berlin) and the south (Chemnitz, Nuremberg, Stuttgart): Take the A4 motorway to the Dresden West interchange, then turn off onto the A17 towards Prague/ Dresden Gorbitz.
<G-vec00309-003-s127><turn_out.biegen><de> Nun kommen Sie wieder zu einer Weggabelung, dort laufen Sie hinunter und biegen dann rechts Richtung Hartkaiser hinauf.
<G-vec00309-003-s127><turn_out.biegen><en> Then you come to another fork where you run downhill and then turn right heading towards Hartkaiser.
<G-vec00309-003-s128><turn_out.biegen><de> Folgen Sie nun geradeaus der Via XX Settembre und biegen dann einmal links, in die Via Pastrengo (sofort nach dem Schatzministerium), und dann nochmals links in die Via Cernaia ein.
<G-vec00309-003-s128><turn_out.biegen><en> Go straight on Via XX Settembre and turn left into Via Pastrengo (immediately after the Depatment of the Treasury) and turn left again into Via Cernia.
<G-vec00309-003-s129><turn_out.biegen><de> Wir fahren vorbei an Mozelj bis nach Rajndol und biegen links nach Knežja Lipa ab.
<G-vec00309-003-s129><turn_out.biegen><en> We will cycle past Mozelj to Rajndol, and then turn left towards Knežja Lipa.
<G-vec00309-003-s130><turn_out.biegen><de> In der Peripherie der Stadt biegen wir rechts in Richtung Pietralunga und sofort anschließend links ab und folgen den Hinweisschildern zum Krankenhaus, wodurch wir den Stadtverkehr von Città di Castello vermeiden.
<G-vec00309-003-s130><turn_out.biegen><en> When you get to the outskirts of the town, turn right towards Pietralunga, and then straight afterwards, bear left at the junction and follow the signs for the hospital.
<G-vec00309-003-s131><turn_out.biegen><de> Mit dem Wagen fahren wir von Jičín in Richtung Lomnice und hinter Valdice in der Ortschaft Těšín biegen wir nach Soběraz ab, weiter in die Wälder von Bradlec über Kumburský Újezd zur Gaststätte Na Klepandě.
<G-vec00309-003-s131><turn_out.biegen><en> If you set out by car from Jičín,go towards Lomnice, and after Valdice, near the village of Těšín, turn to Soběraz, to the forests of Bradlec via Kumburský Újezd to the restaurant named Na Klepandě.
<G-vec00309-003-s132><turn_out.biegen><de> Wir fahren von der E 28 auf der Höhe des Zentrums Matarnia ab (auf der rechten Seite zu sehen), biegen links ab und richten uns nach der Straβe 472 zum Flughafen.
<G-vec00309-003-s132><turn_out.biegen><en> you drive the ring road towards Gdansk. On your left airport control tower will appear. By Matarnia Shopping Center (visible on the right) you turn left into road 472.
