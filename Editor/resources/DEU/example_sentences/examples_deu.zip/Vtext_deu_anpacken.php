<G-vec00301-001-s091><tackle.anpacken><de> """Der MBA Manager kann komplizierte Forschung Bemühungen auch anpacken, spezifische Lösungen zu holen der Firma."
<G-vec00301-001-s091><tackle.anpacken><en> """The MBA manager can also tackle complex research endeavours to bring specific solutions to the company."
<G-vec00301-001-s092><tackle.anpacken><de> Dafür hat man als Bewerber danach aber bereits den Sport-Stallgeruch und kann anpacken – was auch bei den Herstellern, Vereinen, Verbänden und Agenturen geschätzt wird.
<G-vec00301-001-s092><tackle.anpacken><en> But afterwards, as a job applicant you already have the sports background and can tackle problems – something that's also appreciated by manufacturers, clubs, associations, and agencies.
<G-vec00301-001-s093><tackle.anpacken><de> Als unsere Bewegung begann, wusste niemand von uns, dass Abahlali so stark wachsen würde, und so stark würde, dass es Punkte von nationalem Interesse anpacken könnte.
<G-vec00301-001-s093><tackle.anpacken><en> When our movement was started none of us knew that Abahlali would continue to grow and to become strong enough to be able to tackle issues of national interest.
<G-vec00301-001-s094><tackle.anpacken><de> Es hat einen sehr bauchigen Kopf, den Sie beim Einsetzen zuerst anpacken müssen.
<G-vec00301-001-s094><tackle.anpacken><en> It has a very bulbous head which you have to tackle first when inserting it.
<G-vec00301-001-s095><tackle.anpacken><de> 2007-11-13 22:16:19 - Die Werkzeuge Rose des Im Garten arbeitens Wie jeder möglicher Job, den Sie, es anpacken, ist immer einfacher, wenn Sie die rechten Werkzeuge haben.
<G-vec00301-001-s095><tackle.anpacken><en> 2007-11-13 22:16:19 - The tools of rose gardening Like any job you tackle, it's always easier if you have the right tools.
<G-vec00301-001-s096><tackle.anpacken><de> "Science Margaret Chan erklärt im Interview mit Kai Kupferschmidt, warum die Weltgesundheitsorganisation viele Probleme und Vorhaben nicht adäquat anpacken kann und was sie an ihren ""Bossen"", den 194 Mitgliedsstaaten am meisten stört."
<G-vec00301-001-s096><tackle.anpacken><en> "Science Margaret Chan explaines in an interview with Kai Kupferschmidt why the World Health Organisation can not tackle many problems and projects adequately and why her ""bosses"" the 194 member countries bothers her."
<G-vec00301-001-s097><tackle.anpacken><de> Dieses Thema sollten wir in der Branche gemeinsam anpacken.
<G-vec00301-001-s097><tackle.anpacken><en> Together, we should tackle this issue in the industry.
<G-vec00301-001-s098><tackle.anpacken><de> In Absprache mit unseren europäischen Partnern werden wir jene Themen in besonderer Weise anpacken, die den Österreichern und Europäern im Alltag wichtig sind: Arbeitsplätze und Wachstum, die Sicherung und Weiterentwicklung des spezifischen europäischen Lebensmodells und die Stärkung des Vertrauens der Bürger in das europäische Projekt.
<G-vec00301-001-s098><tackle.anpacken><en> In consultation with our European partners, we will tackle in particular the issues that concern citizens in Austria and the rest of Europe: jobs and growth, securing and developing the European social model and boosting people’s confidence in the European project.
<G-vec00301-001-s099><tackle.anpacken><de> Udo Gommel, der Leiter des zuständigen Geschäftsfeldes »Elektronik und Mikrosystemtechnik«, rechnete sich keine großen Chancen aus, diese anspruchsvolle Aufgabe anpacken zu können.
<G-vec00301-001-s099><tackle.anpacken><en> Udo Gommel, head of the business unit »Electronics and Microsystem Technology«, didn't see much of a chance of being given the opportunity to tackle this challenging task.
<G-vec00301-001-s100><tackle.anpacken><de> Diese Menschen kommen in ein anderes Land, dann müssen Sie sich den Gegebenheiten dieses neuen Landes anpassen, anpacken und arbeiten, oder eben nicht kommen.
<G-vec00301-001-s100><tackle.anpacken><en> These people come to another country, then you have to adapt to the realities of that new country, tackle and work, or not come.
<G-vec00301-001-s101><tackle.anpacken><de> Dabei zählen wir auf Mitarbeiter mit Leidenschaft für Technologie, welche im Team herausfordernde Projekte anpacken.
<G-vec00301-001-s101><tackle.anpacken><en> To meet these challenges, we depend on employees with a passion for technology who will tackle challenging projects in a team.
<G-vec00301-001-s102><tackle.anpacken><de> Wenn Sie Spaß daran haben, Projekte von der Kalkulation bis zur Übergabe an den Kunden zu betreuen, dann lassen Sie uns dies gemeinsam anpacken.
<G-vec00301-001-s102><tackle.anpacken><en> If you take pleasure in supporting projects from the calculation phase right through to handover to the customer then let's tackle this together.
<G-vec00301-001-s103><tackle.anpacken><de> Und die klare Botschaft, dass wir die vor uns liegenden Aufgaben gemeinsam anpacken und lösen wollen.
<G-vec00301-001-s103><tackle.anpacken><en> And the clear message that we want to together tackle and solve the tasks that lie ahead.
<G-vec00301-001-s104><tackle.anpacken><de> Wenn Sie Spaß daran haben, auf Basis ihres technischen Know-hows Projekte in die richtige Richtung zu pushen, dann lassen Sie uns dies gemeinsam anpacken.
<G-vec00301-001-s104><tackle.anpacken><en> If you take pleasure in pushing projects in the right direction on the basis of your technical know-how then let's tackle this together.
<G-vec00301-001-s105><tackle.anpacken><de> «Ich freue mich auf die herausfordernden zusätzlichen Aufgaben, die ich gemeinsam mit Hans Hess sowie dem gesamten Verwaltungsrat anpacken werde.
<G-vec00301-001-s105><tackle.anpacken><en> """I look forward to my challenging new tasks, which I will tackle together with Hans Hess and the entire Board of Directors."
<G-vec00301-001-s106><tackle.anpacken><de> Dosisanpassung: wenn Patienten die Diarrhöe- oder Hautnegativen reaktionen nicht zulassen können, können Sie diese Frage durch kurzfristige Suspendierung (bis 14 Tage) der Behandlung anpacken und die Dosis von mg 250 dann pro Tag wieder herstellen.
<G-vec00301-001-s106><tackle.anpacken><en> Dose adjustment: when patients can't tolerate the diarrhea or skin adverse reactions, you can tackle this issue through short-term suspension (up to 14 days) of the treatment and then restore the dose of 250 mg per day.
<G-vec00301-001-s107><tackle.anpacken><de> Aktuell ist die Investitionsbereitschaft hoch wie nie: Nach neuesten Untersuchungen wollen bis zu 95 Prozent der deutschen Einzelhändler innerhalb der nächsten ein bis zwei Jahre einzelne energetische Projekte anpacken.
<G-vec00301-001-s107><tackle.anpacken><en> Now, the willingness to invest is higher than ever: according to the latest research, up to 95 percent of German retailers want to tackle several energy projects within the next one to two years.
<G-vec00301-001-s108><tackle.anpacken><de> Du wirst in der Lage sein, durch Dinge zu segeln, die du zuvor nicht einmal anpacken konntest.
<G-vec00301-001-s108><tackle.anpacken><en> You will be able to sail through things that you couldn't even tackle before.
<G-vec00301-001-s109><tackle.anpacken><de> Mit den falschen Fliegen oder dich anpacken findet, daß es nicht der Spaß ist, der jeder sonst Verriegelung Fische schaut.
<G-vec00301-001-s109><tackle.anpacken><en> With the wrong flies or tackle you will find that it is not fun looking everyone else catch fish.
<G-vec00301-001-s129><tackle.anpacken><de> Man darf sich nicht gegeneinander ausspielen lassen, sondern man muss versuchen, die Probleme gemeinsam anzupacken.
<G-vec00301-001-s129><tackle.anpacken><en> One must not be played off against each other, but we must try to tackle the problems together.
<G-vec00301-001-s130><tackle.anpacken><de> Einer der einfachsten Jobs anzupacken ist die Beleuchtung.
<G-vec00301-001-s130><tackle.anpacken><en> One of the easiest jobs to tackle is the lighting.
<G-vec00301-001-s131><tackle.anpacken><de> Wie dieses den Menschen ermöglicht, gemeinsam Herausforderungen in den Alpen anzupacken, zeigt ihr Jahresbericht.
<G-vec00301-001-s131><tackle.anpacken><en> Its annual report shows how this permits people to tackle the challenges facing the Alps together.
<G-vec00301-001-s132><tackle.anpacken><de> Journalisten sehen Obrador durchaus in der Lage, Mexikos Probleme anzupacken - und es mit seinem mächtigen Nachbarn aufzunehmen.
<G-vec00301-001-s132><tackle.anpacken><en> Journalists believe López Obrador may have what it takes to tackle Mexico's problems - and hold his own against the country's powerful neighbour.
<G-vec00301-001-s133><tackle.anpacken><de> Siegmund, Stolzing, Parsifal, Tannhäuser – Lohengrin ist bei weitem nicht die einzige Wagnerpartie Vogts und er weiß ganz genau, wann es an der Zeit ist, eine neue Rolle anzupacken.
<G-vec00301-001-s133><tackle.anpacken><en> Siegmund, Stolzing, Parsifal, Tannhäuser – Lohengrin is far from being Vogt's only Wagner role and he knows exactly when it's time to tackle the next one.
<G-vec00301-001-s134><tackle.anpacken><de> MANNA hilft den Gemeinden, die Nöte im eigenen Umfeld anzupacken.
<G-vec00301-001-s134><tackle.anpacken><en> MANNA helps the churches to tackle the needs in their own environment.
<G-vec00301-001-s135><tackle.anpacken><de> Ob Sie sich nun ganz oben auf einer Bergauffahrt befinden, die Sie nie den Mut hatten anzupacken, oder auf der obersten Stufe des Podiums in einem Marathon oder in Paris im begehrten Gelben Trikot, Campagnolo setzt sich für die Entwicklung von Produkten ein, die Sie in allen Situationen begleiten und mit ihren maßgebenden technischen Vorteilen unterstützen.
<G-vec00301-001-s135><tackle.anpacken><en> Be it to the top of a climb the likes of which you never dared to tackle, the top step of the podium in your local Granfondo or the top of the podium in Paris while wearing the coveted yellow jersey, Campagnolo is dedicated to making products that will accompany you there and give you significant technical advantages while doing so.
<G-vec00301-001-s136><tackle.anpacken><de> Mit meiner Rede möchte ich das Publikum und vor allem diejenigen, die eine großartige Idee haben und sie noch nicht mit Leben erfüllt haben, ermutigen, mutige Ziele anzupacken.
<G-vec00301-001-s136><tackle.anpacken><en> With my speech, I would like to encourage the audience, and especially those who have a great idea and are reluctant to bring it to life, to tackle bold goals.
<G-vec00301-001-s137><tackle.anpacken><de> Aufgrund dessen ist es fast unmöglich, die vielen Aufgaben vor uns in einer logischen, linearen Reihenfolge anzupacken.
<G-vec00301-001-s137><tackle.anpacken><en> Because of this, it is nearly impossible to tackle the many tasks in front of us in a logical, linear manner.
<G-vec00301-001-s138><tackle.anpacken><de> Mögliche Deutung: Wenn Sie beide heiraten, wird das neuen, frischen Wind, neue Leidenschaft in die Beziehung bringen und den Willen, Dinge anzupacken, die bisher liegengelassen wurden.
<G-vec00301-001-s138><tackle.anpacken><en> Potential Reading: If you marry, this will bring new fire, new passion into the relationship as well as the readiness to tackle things that you had neglected before.
<G-vec00301-001-s139><tackle.anpacken><de> Der ArbeiterInnenstaat muss reicher werden, um in der Lage zu sein, ernsthaft die öffentliche Erziehung der Kinder und die Entlastung der Familie von der Last der Küche und der Wäscherei anzupacken.
<G-vec00301-001-s139><tackle.anpacken><en> The workers' state must become wealthier in order that it may be possible seriously to tackle the public education of children and the releasing of the family from the burden of the kitchen and laundry.
<G-vec00301-001-s140><tackle.anpacken><de> "Alessandro Perseo von Polartec: ""Uns ist es ein Anliegen, Probleme bereits an ihrer Wurzel anzupacken und Lösungen zu finden, wo es bisher noch keine gab."
<G-vec00301-001-s140><tackle.anpacken><en> "Alessandro Perseo of Polartec: ""We intend to tackle problems at their roots, and to find solutions where there have been no problems so far."
<G-vec00301-001-s141><tackle.anpacken><de> Der ArbeiterInnenstaat muss reicher werden, um in der Lage zu sein, ernsthaft die öffentliche Erziehung der Kinder und die Entlastung der Familie von der Last der Küche und der Wäscherei anzupacken.
<G-vec00301-001-s141><tackle.anpacken><en> The workers’ state must become wealthier in order that it may be possible seriously to tackle the public education of children and the releasing of the family from the burden of the kitchen and the laundry.
<G-vec00301-001-s142><tackle.anpacken><de> Echte strukturelle Reformen hätten ernsthafte Versuche eingeschlossen, die Steuerflucht anzupacken.
<G-vec00301-001-s142><tackle.anpacken><en> Genuine structural reforms would have included serious attempts to tackle tax evasion.
<G-vec00301-001-s143><tackle.anpacken><de> Es wurde weit vorweggenommen, dass der französische Präsident würde ausnutzen seinen Besuch nach Frankfurt, um über die Zukunft von Europa zu sprechen, nachdem er im September seinen Empfang für Europa unter Montagepopulismus dargestellt hatte und genauere Bindungen fordern würde, um gemeinsame Verteidigungskraft, allgemeine Finanzpolitik und beigeordnete Bemühungen aufzubauen, Migrationskrise und -Klimawandel anzupacken.
<G-vec00301-001-s143><tackle.anpacken><en> It was widely anticipated that the French president would make use of his visit to Frankfurt to speak about the future of Europe, after he had presented in September his receipt for Europe amid mounting populism, calling for closer ties to build joint defense force, common fiscal policy and coordinate efforts to tackle migration crisis and climate change.
<G-vec00301-001-s144><tackle.anpacken><de> Jedoch wenn Sie wissen, welches suchendes youre, youll Gefühl viel vorbereitet, diesen ersten Hauptschritt anzupacken.
<G-vec00301-001-s144><tackle.anpacken><en> However, when you know what youre looking for, youll feel much more prepared to tackle this first major step.
<G-vec00301-001-s145><tackle.anpacken><de> ist eine klare Botschaft: Jede Krise bietet die Chance, Reformen anzupacken, und das Beste aus einer Situation zu machen.
<G-vec00301-001-s145><tackle.anpacken><en> carries a clear message: Every crisis offers the chance to tackle reforms and make the best of a situation.
<G-vec00301-001-s146><tackle.anpacken><de> (c) Maxim – Rückspiegel Selbstverwirklichung heißt ab einem gewissen Punkt, Dinge nicht mehr nur anzupacken.
<G-vec00301-001-s146><tackle.anpacken><en> (c) Maxim - rearview mirror Self-realization, from a certain point of view, is not just to tackle things.
<G-vec00301-001-s147><tackle.anpacken><de> Wirtschaft und Politik sind laut Leuthard gleichermassen gefordert, diese Herausforderung unter anderem mit Bildung und Weiterbildung anzupacken, um Arbeitnehmerinnen und Arbeitnehmer für die digitalisierte Arbeitswelt fit zu machen.
<G-vec00301-001-s147><tackle.anpacken><en> Leuthard reminded her audience that business and politics were equally called upon to tackle this challenge, among other things with basic and advanced education and training, in order to make employees fit for the digitised world of work.
