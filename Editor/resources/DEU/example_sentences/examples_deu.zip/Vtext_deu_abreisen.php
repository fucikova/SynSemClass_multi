<G-vec00497-002-s038><leave.abreisen><de> 1837 reiste Wagner nach Riga um am dortigen Theater tätig zu sein, seine Frau Minna folgte ihm nach; sie mussten wegen Geldschulden hastig abreisen.
<G-vec00497-002-s038><leave.abreisen><en> In 1837 Wagner travelled to Riga to work at the theatre there; his wife Minna followed after. Debts subsequently compelled them to leave Riga in a hurry.
<G-vec00497-002-s039><leave.abreisen><de> Natürlich können Sie auch ganz nach Ihren Wünschen vor 10 Uhr abreisen und nach 16 Uhr anreisen.
<G-vec00497-002-s039><leave.abreisen><en> Of course, you can also leave according to your wishes earlier than 10 a.m. and arrive after 4 p.m.
<G-vec00497-002-s040><leave.abreisen><de> Sollte auf Ihrem Stellplatz keine Anreise am gleichen Tag stattfinden, so können Sie gerne auch am Nachmittag abreisen.
<G-vec00497-002-s040><leave.abreisen><en> If your pitch is not going to be taken on the same day of your departure, you are welcome to leave in the afternoon.
<G-vec00497-002-s041><leave.abreisen><de> - Eine Reservierung stornieren oder vorzeitig abreisen zu müssen, ist sowohl für Sie als auch für uns immer willkommen.
<G-vec00497-002-s041><leave.abreisen><en> - Having to cancel a reservation or leave early is always a little welcome, both for you and for us.
<G-vec00497-002-s042><leave.abreisen><de> Und dann hinuntergehen und in den Strom jener erwerbs- und mittellosen Existenzen eintauchen, den Duft des frischen Fisches und des gegrillten Fleisches eines improvisierten Marktes entführen, mit einem gezuckerten Kaffee und einem Schluck Wasser aufwachen und abreisen, um dann nur wiederzukommen.
<G-vec00497-002-s042><leave.abreisen><en> And then descend, plunge themselves into the river of all those lives which held no particular distinction, take the stench of the fresh fish and the grilled meat in the pop-up market, wake themselves up with a sugared coffee and a sip of water, and then leave, only to return later.
<G-vec00497-002-s043><leave.abreisen><de> Die Fachbesucher-Tage auf der ITB sind von Mittwoch bis Freitag – danach kann man davon ausgehen, dass wichtige Manager abreisen.
<G-vec00497-002-s043><leave.abreisen><en> The trade visitor days at the ITB are from Wednesday to Friday – after that, it is very likely that important managers leave.
<G-vec00497-002-s044><leave.abreisen><de> Unsere Kurse stellen sicher, dass Absolventen mit den Kenntnissen, Fähigkeiten und Qualifikationen, die Arbeitgeber suchen, abreisen.
<G-vec00497-002-s044><leave.abreisen><en> Our courses ensure that graduates leave with the knowledge, skills and qualifications that employers are looking for.
<G-vec00497-002-s045><leave.abreisen><de> Wir wissen, dass Sie nicht abreisen möchten.
<G-vec00497-002-s045><leave.abreisen><en> We know that you’ll be reluctant to leave.
<G-vec00497-002-s046><leave.abreisen><de> Rudolf Kahns werden auch bald abreisen.
<G-vec00497-002-s046><leave.abreisen><en> Rudolf Kahn’s family is also going to leave soon.
<G-vec00497-002-s047><leave.abreisen><de> Sie werden gar nicht mehr abreisen wollen.
<G-vec00497-002-s047><leave.abreisen><en> You'll never want to leave
<G-vec00497-002-s048><leave.abreisen><de> Natürlich können Sie Ihr Gepäck in unseren Gepäckraum aufbewahren, wenn Sie früher anreisen oder später abreisen.
<G-vec00497-002-s048><leave.abreisen><en> Baggage can be left at the hotel in the event you arrive earlier or leave later.
<G-vec00497-002-s049><leave.abreisen><de> Falls Sie mehrere Wochen bleiben, ist es am Günstigsten, ein Fahrrad aus zweiter Hand zu kaufen und dann wenn Sie abreisen wieder zu verkaufen.
<G-vec00497-002-s049><leave.abreisen><en> If you stay for a couple of weeks the most economical option is buying a second hand bike and selling it again when you leave.
<G-vec00497-002-s050><leave.abreisen><de> Außerhalb der Saison ist die Rezeption am Sonntag geschlossen, aber Sie können einfach ankommen und abreisen.
<G-vec00497-002-s050><leave.abreisen><en> During the off-season, the reception is closed on Sundays, but you can arrive and leave by consent
<G-vec00497-002-s051><leave.abreisen><de> Informieren Sie uns, wenn Sie gerne früher anreisen oder später abreisen möchten.
<G-vec00497-002-s051><leave.abreisen><en> Please inform us, if you like to arrive earlier or leave later.
<G-vec00497-002-s052><leave.abreisen><de> Negativ:: Dass Ich schon so früh abreisen musste.
<G-vec00497-002-s052><leave.abreisen><en> Cons: I had to leave so soon.
<G-vec00497-002-s053><leave.abreisen><de> Wenn Sie früher abreisen möchten, informieren Sie bitte am Abend zuvor die Rezeption.
<G-vec00497-002-s053><leave.abreisen><en> Please inform the reception the day before if you wish to leave earlier.
<G-vec00497-002-s054><leave.abreisen><de> Jedes Mal wenn ich in Paris bin, verbindet mich immer ein vertrautes Gefühl mit der Stadt und ich bin jedes mal traurig, wenn ich wieder abreisen muss.
<G-vec00497-002-s054><leave.abreisen><en> Every time, I love coming back and I am always a little sad when I have to leave again.
<G-vec00497-002-s055><leave.abreisen><de> Zu guter Letzt können Sie nicht abreisen, bevor Sie nicht in Marbella oder in dem Jachthafen Puerto Banus einkaufen gegangen sind.
<G-vec00497-002-s055><leave.abreisen><en> Finally, you can’t leave until you’ve done some shopping in Marbella or its sister city Puerto Banus.
<G-vec00497-002-s056><leave.abreisen><de> Aber bald musste ich nach dem Kontinent abreisen.
<G-vec00497-002-s056><leave.abreisen><en> Soon, however, I had to leave for the continent.
