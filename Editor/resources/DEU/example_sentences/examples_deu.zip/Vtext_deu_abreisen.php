<G-vec00497-002-s038><leave.abreisen><de> 1837 reiste Wagner nach Riga um am dortigen Theater tätig zu sein, seine Frau Minna folgte ihm nach; sie mussten wegen Geldschulden hastig abreisen.
<G-vec00497-002-s038><leave.abreisen><en> In 1837 Wagner travelled to Riga to work at the theatre there; his wife Minna followed after. Debts subsequently compelled them to leave Riga in a hurry.
<G-vec00497-002-s039><leave.abreisen><de> Natürlich können Sie auch ganz nach Ihren Wünschen vor 10 Uhr abreisen und nach 16 Uhr anreisen.
<G-vec00497-002-s039><leave.abreisen><en> Of course, you can also leave according to your wishes earlier than 10 a.m. and arrive after 4 p.m.
<G-vec00497-002-s040><leave.abreisen><de> Sollte auf Ihrem Stellplatz keine Anreise am gleichen Tag stattfinden, so können Sie gerne auch am Nachmittag abreisen.
<G-vec00497-002-s040><leave.abreisen><en> If your pitch is not going to be taken on the same day of your departure, you are welcome to leave in the afternoon.
<G-vec00497-002-s041><leave.abreisen><de> - Eine Reservierung stornieren oder vorzeitig abreisen zu müssen, ist sowohl für Sie als auch für uns immer willkommen.
<G-vec00497-002-s041><leave.abreisen><en> - Having to cancel a reservation or leave early is always a little welcome, both for you and for us.
<G-vec00497-002-s042><leave.abreisen><de> Und dann hinuntergehen und in den Strom jener erwerbs- und mittellosen Existenzen eintauchen, den Duft des frischen Fisches und des gegrillten Fleisches eines improvisierten Marktes entführen, mit einem gezuckerten Kaffee und einem Schluck Wasser aufwachen und abreisen, um dann nur wiederzukommen.
<G-vec00497-002-s042><leave.abreisen><en> And then descend, plunge themselves into the river of all those lives which held no particular distinction, take the stench of the fresh fish and the grilled meat in the pop-up market, wake themselves up with a sugared coffee and a sip of water, and then leave, only to return later.
<G-vec00497-002-s043><leave.abreisen><de> Die Fachbesucher-Tage auf der ITB sind von Mittwoch bis Freitag – danach kann man davon ausgehen, dass wichtige Manager abreisen.
<G-vec00497-002-s043><leave.abreisen><en> The trade visitor days at the ITB are from Wednesday to Friday – after that, it is very likely that important managers leave.
<G-vec00497-002-s044><leave.abreisen><de> Unsere Kurse stellen sicher, dass Absolventen mit den Kenntnissen, Fähigkeiten und Qualifikationen, die Arbeitgeber suchen, abreisen.
<G-vec00497-002-s044><leave.abreisen><en> Our courses ensure that graduates leave with the knowledge, skills and qualifications that employers are looking for.
<G-vec00497-002-s045><leave.abreisen><de> Wir wissen, dass Sie nicht abreisen möchten.
<G-vec00497-002-s045><leave.abreisen><en> We know that you’ll be reluctant to leave.
<G-vec00497-002-s046><leave.abreisen><de> Rudolf Kahns werden auch bald abreisen.
<G-vec00497-002-s046><leave.abreisen><en> Rudolf Kahn’s family is also going to leave soon.
<G-vec00497-002-s047><leave.abreisen><de> Sie werden gar nicht mehr abreisen wollen.
<G-vec00497-002-s047><leave.abreisen><en> You'll never want to leave
<G-vec00497-002-s048><leave.abreisen><de> Natürlich können Sie Ihr Gepäck in unseren Gepäckraum aufbewahren, wenn Sie früher anreisen oder später abreisen.
<G-vec00497-002-s048><leave.abreisen><en> Baggage can be left at the hotel in the event you arrive earlier or leave later.
<G-vec00497-002-s049><leave.abreisen><de> Falls Sie mehrere Wochen bleiben, ist es am Günstigsten, ein Fahrrad aus zweiter Hand zu kaufen und dann wenn Sie abreisen wieder zu verkaufen.
<G-vec00497-002-s049><leave.abreisen><en> If you stay for a couple of weeks the most economical option is buying a second hand bike and selling it again when you leave.
<G-vec00497-002-s050><leave.abreisen><de> Außerhalb der Saison ist die Rezeption am Sonntag geschlossen, aber Sie können einfach ankommen und abreisen.
<G-vec00497-002-s050><leave.abreisen><en> During the off-season, the reception is closed on Sundays, but you can arrive and leave by consent
<G-vec00497-002-s051><leave.abreisen><de> Informieren Sie uns, wenn Sie gerne früher anreisen oder später abreisen möchten.
<G-vec00497-002-s051><leave.abreisen><en> Please inform us, if you like to arrive earlier or leave later.
<G-vec00497-002-s052><leave.abreisen><de> Negativ:: Dass Ich schon so früh abreisen musste.
<G-vec00497-002-s052><leave.abreisen><en> Cons: I had to leave so soon.
<G-vec00497-002-s053><leave.abreisen><de> Wenn Sie früher abreisen möchten, informieren Sie bitte am Abend zuvor die Rezeption.
<G-vec00497-002-s053><leave.abreisen><en> Please inform the reception the day before if you wish to leave earlier.
<G-vec00497-002-s054><leave.abreisen><de> Jedes Mal wenn ich in Paris bin, verbindet mich immer ein vertrautes Gefühl mit der Stadt und ich bin jedes mal traurig, wenn ich wieder abreisen muss.
<G-vec00497-002-s054><leave.abreisen><en> Every time, I love coming back and I am always a little sad when I have to leave again.
<G-vec00497-002-s055><leave.abreisen><de> Zu guter Letzt können Sie nicht abreisen, bevor Sie nicht in Marbella oder in dem Jachthafen Puerto Banus einkaufen gegangen sind.
<G-vec00497-002-s055><leave.abreisen><en> Finally, you can’t leave until you’ve done some shopping in Marbella or its sister city Puerto Banus.
<G-vec00497-002-s056><leave.abreisen><de> Aber bald musste ich nach dem Kontinent abreisen.
<G-vec00497-002-s056><leave.abreisen><en> Soon, however, I had to leave for the continent.
<G-vec00048-002-s118><depart.abreisen><de> 2Kreuzfahrtpassagiere werden als diejenigen definiert, die im selben Kreuzfahrtschiff (d.h. „cruise-in-cruise-out“) ankommen und abreisen.
<G-vec00048-002-s118><depart.abreisen><en> 2Cruise Passengers are defined as those who both arrive and depart on the same cruise vessel (i.e. “cruise-in-cruise-out passengers”).
<G-vec00048-002-s119><depart.abreisen><de> Die Immobilie wird gereinigt vor Ihrer Ankunft und wir respektvoll bitten, Sie zu verlassen die Wohnung in einem sauberen und ordentlichen Zustand, wenn Sie abreisen.
<G-vec00048-002-s119><depart.abreisen><en> The property will be cleaned before your arrival and we respectfully ask you to leave the property in a clean and tidy state when you depart.
<G-vec00048-002-s120><depart.abreisen><de> Deine lieben hochgehenden Zeilen= OJ 14/45, [66] hätten wirklich verdient, sofort aufs schönste bedankt zu werden, unmöglich aber war es, mich zu einer würdigen Antwort zu sammlen, da ich Bogenkorrekturen zu machen, Stunden vorzugeben hatte u. förmlich Schüler auf Schüler propfte (um am 25. abreisen zu können), an den letzten Besorgungen teilnehmen usw.
<G-vec00048-002-s120><depart.abreisen><en> Your kind, effusive lines= OJ 14/45, [66] truly deserved an immediate expression of thanks, in the most beautiful possible way. It was impossible, however, for me to summon myself to a worthy reply, as I had to correct page-proofs and give lessons, to squeeze in one pupil after another (so that we could depart on the 25th), and to run final errands.
<G-vec00048-002-s121><depart.abreisen><de> Das Treffen wird in Göttingen sein und von Samstag, 14°° bis Sonntag 14°° dauern, damit alle mit Wochenendtickets an- und abreisen können und wir auch Zeit haben uns kennen zu lernen.
<G-vec00048-002-s121><depart.abreisen><en> The meeting will take place in Göttingen from Saturday,14h to Sunday 14h, so everyone can arrive and depart with weekend tickets, and we also have time to get to know each other.
<G-vec00048-002-s122><depart.abreisen><de> Als das Treffen zu Ende ist und die Offiziere abreisen, schlägt Harold vor, den Soldaten Fleisch zu servieren, was die anderen billigen.
<G-vec00048-002-s122><depart.abreisen><en> As the meeting concludes and the officers depart, Harold suggests serving red meat to the soldiers, which the others approve.
<G-vec00048-002-s123><depart.abreisen><de> Ferrocarril Haltestelle: Befindet sich an der "Granada-Station", wo Züge mit An- und Abreisen in verschiedene Teile Spaniens verkehren.
<G-vec00048-002-s123><depart.abreisen><en> Ferrocarril Station: It connects to “Granada Station,” where trains that arrive and depart to different parts of Spain transit, including a high speed train line.
<G-vec00048-002-s124><depart.abreisen><de> Sie können aus den obigen Optionen wählen, ob Sie einen Tag früher anreisen oder einen Tag später abreisen wollen, um Ihren Urlaub zu verlängern.
<G-vec00048-002-s124><depart.abreisen><en> You may choose from the above options to arrive 1 day earlier or depart 1 day later to extend your holiday.
<G-vec00048-002-s125><depart.abreisen><de> Natürlich darf sie nicht zu locker sein und abreisen sollte sie auch nicht.
<G-vec00048-002-s125><depart.abreisen><en> Of course they should not be too loose and to depart it should not.
<G-vec00048-002-s126><depart.abreisen><de> 7Am ersten Tage der Woche aber, als wir versammelt waren, um Brot zu brechen, unterredete sich Paulus mit ihnen, indem er am folgenden Tage abreisen wollte; und er verzog das Wort bis Mitternacht.
<G-vec00048-002-s126><depart.abreisen><en> 10:16to break bread, Paul, ready to depart the next day, spoke to them and continued his message until midnight.
<G-vec00048-002-s127><depart.abreisen><de> Seien Sie sicher, dass Sie wissen, Ihre persönliche Identifikationsnummer (PIN) und Ihre tägliche Bezugslimite bevor Sie abreisen.
<G-vec00048-002-s127><depart.abreisen><en> Be sure you know your personal identification number (PIN) and your daily withdrawal limit before you depart.
<G-vec00048-002-s128><depart.abreisen><de> Nach Peking durch Air China-Fluglinien abreisen.
<G-vec00048-002-s128><depart.abreisen><en> Depart to Beijing by Air China airlines.
<G-vec00048-002-s129><depart.abreisen><de> Das liegt einerseits an den Schiffen, die hier ankommen und abreisen und einen von der großen weiten Welt träumen lassen, andererseits aber auch am Ambiente, das zwar industriell geprägt ist, aber über einen besonderen Charme verfügt.
<G-vec00048-002-s129><depart.abreisen><en> This is partly because of the ships that arrive and depart here and set you thinking about the big wide world, but also because of the port’s industrial ambience, which has a special charm of its own.
<G-vec00048-002-s130><depart.abreisen><de> Sollten Sie bereits früher anreisen oder später abreisen, können Sie Ihr Gepäck gerne sicher bei uns deponieren.
<G-vec00048-002-s130><depart.abreisen><en> If you arrive earlier or depart later, you are welcome to leave your luggage safe with us.
<G-vec00048-002-s131><depart.abreisen><de> Im Falle, dass Sie später anreisen oder früher abreisen als von Ihnen in der Reservierung angegeben, behält die Direktion sich vor, den Stellplatz ohne jegliche Rückvergütung weiter zu vermieten.
<G-vec00048-002-s131><depart.abreisen><en> In case you arrive later or depart earlier than confirmed in your reservation, the management reserves the right to rent the pitch to other guests, without the possibility of a refund of any kind.
<G-vec00048-002-s132><depart.abreisen><de> 4 Und laßt sie im nächsten Frühjahr abreisen und sich über die großen Wasser begeben und dort mein Evangelium verbreiten, ja, seine Fülle, und von meinem Namen Zeugnis geben.
<G-vec00048-002-s132><depart.abreisen><en> 4 And next spring let them depart to go over the great waters, and there promulgate my gospel, the fulness thereof, and bear record of my name.
<G-vec00048-002-s133><depart.abreisen><de> Wendet man sich in die östliche Richtung, gelangt man direkt an die Kieler Förde zum Schwedenkai, an dem die Autofähren nach Schweden an- und abreisen.
<G-vec00048-002-s133><depart.abreisen><en> When you turn to the east, you come directly to the Kiel Firth Schwedenkai, where ferries depart on and off for Sweden.
<G-vec00048-002-s134><depart.abreisen><de> Wir haben flexible An-und Abreisetage, so können Sie selbst entscheiden, an welchem Tag Sie ankommen oder abreisen möchten.
<G-vec00048-002-s134><depart.abreisen><en> We use flexible arrival and departure days, so you can decide which day you wish to arrive or depart.
<G-vec00048-002-s135><depart.abreisen><de> Wenn Sie früher kommen oder Sie später abreisen müssen, können Sie sich an unsere Mitarbeiter wenden.
<G-vec00048-002-s135><depart.abreisen><en> If you are coming earlier or you need to depart later you may contact our reception staff.
<G-vec00048-002-s136><depart.abreisen><de> Wenn Sie also in den frühen Morgenstunden abreisen oder ankommen, denken Sie an diese Zeiten.
<G-vec00048-002-s136><depart.abreisen><en> Therefore, if you depart or arrive during the early hours of the morning, remember these hours.
