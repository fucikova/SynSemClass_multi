<G-vec00443-001-s018><accumulate.addieren><de> Wenn Sie herausfinden, dass 10mg Tablet-Computer jeweils $ 2 bis $ 5 kosten könnte, kann das sicherlich addieren.
<G-vec00443-001-s018><accumulate.addieren><en> When you figure that 10mg tablets could set you back $2 to $5 apiece, that can absolutely accumulate.
<G-vec00443-001-s019><accumulate.addieren><de> Wenn Sie herausfinden, dass 10mg Tablet-Computer jeweils $ 2 bis $ 5 kosten könnte, kann das sicherlich addieren.
<G-vec00443-001-s019><accumulate.addieren><en> When you figure that 10mg tablets can cost $2 to $5 each, that could absolutely accumulate.
<G-vec00060-001-s038><add.addieren><de> Es wird verwendet, um Inhalt eines Tagebuchs oder Nachrichten zu addieren vom Inhaber (blogger).
<G-vec00060-001-s038><add.addieren><en> It's used to add contents of a diary or news by the owner (blogger).
<G-vec00060-001-s039><add.addieren><de> Ob es ein Frühstücksbar für dienende Nahrung oder zusätzlichen Vorbereitungsraum für das Kochen ist, addieren reichliche Küchenarbeitsplatten enormen Wert; eine Eigenschaft, die Sie in allen Häusern Deepblue SmartHouse sehen.
<G-vec00060-001-s039><add.addieren><en> Whether it’s a breakfast bar for serving food or additional prep space for cooking, ample kitchen counters add huge value; a feature you will see in all Deepblue SmartHouse homes.
<G-vec00060-001-s040><add.addieren><de> Addieren von Zahlen, bevor die Zeit abläuft.
<G-vec00060-001-s040><add.addieren><en> Add up numbers before the time runs out.
<G-vec00060-001-s041><add.addieren><de> Nehmen Sie sich aber die nötige Zeit, um herauszufinden, ob man addieren oder subtrahieren muss, wenn man mit der Stundenanzeige des guten Stücks die wahre Sonnenzeit ausrechnen will.
<G-vec00060-001-s041><add.addieren><en> But take a good, long moment to check whether you need to add it to or subtract it from the time given by your precious timepiece to ascertain the true solar time.
<G-vec00060-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00060-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00060-001-s043><add.addieren><de> Wir können hölzerne Rahmenaußenseite auch addieren wie Kundenantrag.
<G-vec00060-001-s043><add.addieren><en> We also can add wood frame outside as clients request.
<G-vec00060-001-s044><add.addieren><de> Jetzt können wir den Geschwindigkeitswert in Zelle C3 zu diesem Wert addieren.
<G-vec00060-001-s044><add.addieren><en> Now we can add the velocity change in cell C3 to this value.
<G-vec00060-001-s045><add.addieren><de> 9, Wahl: äußeres Leitblech addieren die Landeklappenfunktion, die die Papporientierung genauer machte, vermeiden, um zu vergeuden.
<G-vec00060-001-s045><add.addieren><en> 9, Option: outside baffle add the flap function, which made the cardboard orientation more exact, avoid to
<G-vec00060-001-s046><add.addieren><de> Wir dürfen nie addieren, subtrahieren oder die Lehre von Christus oder zu denen er Vollmacht gab, seine geschriebene Wort aufzunehmen.
<G-vec00060-001-s046><add.addieren><en> We must never add, subtract or change the doctrine of Christ or to whom He gave authority to record His written word.
<G-vec00060-001-s047><add.addieren><de> 1 Aufgrund von Rundungen ist es möglich, dass sich einzelne Zahlen in dieser Pressemitteilung nicht genau zur angegebenen Summe addieren lassen und sich die Neunmonatszahlen nicht aus der Aufsummierung der einzelnen Quartalszahlen ergeben.
<G-vec00060-001-s047><add.addieren><en> 1 Due to rounding it is possible that individual figures presented in this press release may not add up exactly to the totals shown and that the nine-month figures listed may not follow from adding up the individual quarterly figures.
<G-vec00060-001-s048><add.addieren><de> "Bitte geben Sie diese Formel ein = SUMIF (A2: A6 ""TEC * *"" B2: B6) in eine leere Zelle und drücken Sie Weiter Schlüssel, dann addieren sich alle Zahlen in Spalte B, wo die entsprechende Zelle in Spalte A den Text ""KTE"" enthält."
<G-vec00060-001-s048><add.addieren><en> "Please enter this formula =SUMIF(A2:A6,""*KTE*"",B2:B6) into a blank cell, and press Enter key, then all the numbers in column B where the corresponding cell in column A contains text “KTE” will add up."
<G-vec00060-001-s049><add.addieren><de> Am Freitag muss ich 3 Tage addieren, um auf den kommenden Montag zu kommen, am Samstag 2 Tage und an allen anderen Tagen ist der nächste Tag auch der nächste Arbeitstag.
<G-vec00060-001-s049><add.addieren><en> On friday we must add 3 days to get next monday, on saturday 2 days are to be added and for all other weekdays the next day is the next working day.
<G-vec00060-001-s050><add.addieren><de> Wir bieten 5 Doppelzimmer, von denen jeder die Möglichkeit, 5 Einzelbetten zu addieren hat.
<G-vec00060-001-s050><add.addieren><en> We offer 5 double bedrooms, each of which has the possibility to add up to 2 single beds.
<G-vec00060-001-s051><add.addieren><de> Die Vergeudung wird erzeugt, wenn Leute in einer zu großen Hast sind, zum von von mehr Aufstellungsorten zu errichten, von von mehr Produkten zu addieren und mehr Verkehrs an Aufstellungsorte zu gelangen, die manchmal 1000% umwandeln können, das BESSER ist, als sie jetzt.
<G-vec00060-001-s051><add.addieren><en> The waste is generated when people are in too big a hurry to build more sites, add more products, and get more traffic to sites that can convert sometimes 1000% BETTER than they do now.
<G-vec00060-001-s052><add.addieren><de> • Zeileneinsatz: Klicken Sie auf diesen Button, um Ihren Einsatz pro aktivierter Gewinnlinie zu addieren oder abzuziehen.
<G-vec00060-001-s052><add.addieren><en> • Bet per Line: Click this button to add or subtract from your wager per activated payline.
<G-vec00060-001-s053><add.addieren><de> Sie addieren sich automatisch um 0,3 mm pro Jahr in dieser Region, nicht weil das Meer steigt, sondern um einen angeblichen isostatischen Anstieg des Landes auszugleichen.
<G-vec00060-001-s053><add.addieren><en> They automatically add 0.3 mm per year to this region, not because the sea is rising, but to compensate for an alleged isostatic increase in land.
<G-vec00060-001-s054><add.addieren><de> Viele Mal möchte ein Inhaber eines unabhängigen einzeln aufführengeschäftes jene Einzelteile addieren, die he/she glaubt, dass ihre Kunden wünschen.
<G-vec00060-001-s054><add.addieren><en> Many times an owner of an independent Detailing Shop will wish to add those items he/she believes their customers want.
<G-vec00060-001-s055><add.addieren><de> Leider tun wir ein wenig vom Feiern während dieser Zeit des Jahres und addieren oben Extragepäck, wenn das neue Jahr erscheint.
<G-vec00060-001-s055><add.addieren><en> Unfortunately, we do a little bit of celebrating during this time of year and add up extra baggage when the New Year appears.
<G-vec00060-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00060-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
<G-vec00407-001-s038><add.addieren><de> Es wird verwendet, um Inhalt eines Tagebuchs oder Nachrichten zu addieren vom Inhaber (blogger).
<G-vec00407-001-s038><add.addieren><en> It's used to add contents of a diary or news by the owner (blogger).
<G-vec00407-001-s039><add.addieren><de> Ob es ein Frühstücksbar für dienende Nahrung oder zusätzlichen Vorbereitungsraum für das Kochen ist, addieren reichliche Küchenarbeitsplatten enormen Wert; eine Eigenschaft, die Sie in allen Häusern Deepblue SmartHouse sehen.
<G-vec00407-001-s039><add.addieren><en> Whether it’s a breakfast bar for serving food or additional prep space for cooking, ample kitchen counters add huge value; a feature you will see in all Deepblue SmartHouse homes.
<G-vec00407-001-s040><add.addieren><de> Addieren von Zahlen, bevor die Zeit abläuft.
<G-vec00407-001-s040><add.addieren><en> Add up numbers before the time runs out.
<G-vec00407-001-s041><add.addieren><de> Nehmen Sie sich aber die nötige Zeit, um herauszufinden, ob man addieren oder subtrahieren muss, wenn man mit der Stundenanzeige des guten Stücks die wahre Sonnenzeit ausrechnen will.
<G-vec00407-001-s041><add.addieren><en> But take a good, long moment to check whether you need to add it to or subtract it from the time given by your precious timepiece to ascertain the true solar time.
<G-vec00407-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00407-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00407-001-s043><add.addieren><de> Wir können hölzerne Rahmenaußenseite auch addieren wie Kundenantrag.
<G-vec00407-001-s043><add.addieren><en> We also can add wood frame outside as clients request.
<G-vec00407-001-s044><add.addieren><de> Jetzt können wir den Geschwindigkeitswert in Zelle C3 zu diesem Wert addieren.
<G-vec00407-001-s044><add.addieren><en> Now we can add the velocity change in cell C3 to this value.
<G-vec00407-001-s045><add.addieren><de> 9, Wahl: äußeres Leitblech addieren die Landeklappenfunktion, die die Papporientierung genauer machte, vermeiden, um zu vergeuden.
<G-vec00407-001-s045><add.addieren><en> 9, Option: outside baffle add the flap function, which made the cardboard orientation more exact, avoid to
<G-vec00407-001-s046><add.addieren><de> Wir dürfen nie addieren, subtrahieren oder die Lehre von Christus oder zu denen er Vollmacht gab, seine geschriebene Wort aufzunehmen.
<G-vec00407-001-s046><add.addieren><en> We must never add, subtract or change the doctrine of Christ or to whom He gave authority to record His written word.
<G-vec00407-001-s047><add.addieren><de> 1 Aufgrund von Rundungen ist es möglich, dass sich einzelne Zahlen in dieser Pressemitteilung nicht genau zur angegebenen Summe addieren lassen und sich die Neunmonatszahlen nicht aus der Aufsummierung der einzelnen Quartalszahlen ergeben.
<G-vec00407-001-s047><add.addieren><en> 1 Due to rounding it is possible that individual figures presented in this press release may not add up exactly to the totals shown and that the nine-month figures listed may not follow from adding up the individual quarterly figures.
<G-vec00407-001-s048><add.addieren><de> "Bitte geben Sie diese Formel ein = SUMIF (A2: A6 ""TEC * *"" B2: B6) in eine leere Zelle und drücken Sie Weiter Schlüssel, dann addieren sich alle Zahlen in Spalte B, wo die entsprechende Zelle in Spalte A den Text ""KTE"" enthält."
<G-vec00407-001-s048><add.addieren><en> "Please enter this formula =SUMIF(A2:A6,""*KTE*"",B2:B6) into a blank cell, and press Enter key, then all the numbers in column B where the corresponding cell in column A contains text “KTE” will add up."
<G-vec00407-001-s049><add.addieren><de> Am Freitag muss ich 3 Tage addieren, um auf den kommenden Montag zu kommen, am Samstag 2 Tage und an allen anderen Tagen ist der nächste Tag auch der nächste Arbeitstag.
<G-vec00407-001-s049><add.addieren><en> On friday we must add 3 days to get next monday, on saturday 2 days are to be added and for all other weekdays the next day is the next working day.
<G-vec00407-001-s050><add.addieren><de> Wir bieten 5 Doppelzimmer, von denen jeder die Möglichkeit, 5 Einzelbetten zu addieren hat.
<G-vec00407-001-s050><add.addieren><en> We offer 5 double bedrooms, each of which has the possibility to add up to 2 single beds.
<G-vec00407-001-s051><add.addieren><de> Die Vergeudung wird erzeugt, wenn Leute in einer zu großen Hast sind, zum von von mehr Aufstellungsorten zu errichten, von von mehr Produkten zu addieren und mehr Verkehrs an Aufstellungsorte zu gelangen, die manchmal 1000% umwandeln können, das BESSER ist, als sie jetzt.
<G-vec00407-001-s051><add.addieren><en> The waste is generated when people are in too big a hurry to build more sites, add more products, and get more traffic to sites that can convert sometimes 1000% BETTER than they do now.
<G-vec00407-001-s052><add.addieren><de> • Zeileneinsatz: Klicken Sie auf diesen Button, um Ihren Einsatz pro aktivierter Gewinnlinie zu addieren oder abzuziehen.
<G-vec00407-001-s052><add.addieren><en> • Bet per Line: Click this button to add or subtract from your wager per activated payline.
<G-vec00407-001-s053><add.addieren><de> Sie addieren sich automatisch um 0,3 mm pro Jahr in dieser Region, nicht weil das Meer steigt, sondern um einen angeblichen isostatischen Anstieg des Landes auszugleichen.
<G-vec00407-001-s053><add.addieren><en> They automatically add 0.3 mm per year to this region, not because the sea is rising, but to compensate for an alleged isostatic increase in land.
<G-vec00407-001-s054><add.addieren><de> Viele Mal möchte ein Inhaber eines unabhängigen einzeln aufführengeschäftes jene Einzelteile addieren, die he/she glaubt, dass ihre Kunden wünschen.
<G-vec00407-001-s054><add.addieren><en> Many times an owner of an independent Detailing Shop will wish to add those items he/she believes their customers want.
<G-vec00407-001-s055><add.addieren><de> Leider tun wir ein wenig vom Feiern während dieser Zeit des Jahres und addieren oben Extragepäck, wenn das neue Jahr erscheint.
<G-vec00407-001-s055><add.addieren><en> Unfortunately, we do a little bit of celebrating during this time of year and add up extra baggage when the New Year appears.
<G-vec00407-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00407-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
<G-vec00499-001-s038><add.addieren><de> Es wird verwendet, um Inhalt eines Tagebuchs oder Nachrichten zu addieren vom Inhaber (blogger).
<G-vec00499-001-s038><add.addieren><en> It's used to add contents of a diary or news by the owner (blogger).
<G-vec00499-001-s039><add.addieren><de> Ob es ein Frühstücksbar für dienende Nahrung oder zusätzlichen Vorbereitungsraum für das Kochen ist, addieren reichliche Küchenarbeitsplatten enormen Wert; eine Eigenschaft, die Sie in allen Häusern Deepblue SmartHouse sehen.
<G-vec00499-001-s039><add.addieren><en> Whether it’s a breakfast bar for serving food or additional prep space for cooking, ample kitchen counters add huge value; a feature you will see in all Deepblue SmartHouse homes.
<G-vec00499-001-s040><add.addieren><de> Addieren von Zahlen, bevor die Zeit abläuft.
<G-vec00499-001-s040><add.addieren><en> Add up numbers before the time runs out.
<G-vec00499-001-s041><add.addieren><de> Nehmen Sie sich aber die nötige Zeit, um herauszufinden, ob man addieren oder subtrahieren muss, wenn man mit der Stundenanzeige des guten Stücks die wahre Sonnenzeit ausrechnen will.
<G-vec00499-001-s041><add.addieren><en> But take a good, long moment to check whether you need to add it to or subtract it from the time given by your precious timepiece to ascertain the true solar time.
<G-vec00499-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00499-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00499-001-s043><add.addieren><de> Wir können hölzerne Rahmenaußenseite auch addieren wie Kundenantrag.
<G-vec00499-001-s043><add.addieren><en> We also can add wood frame outside as clients request.
<G-vec00499-001-s044><add.addieren><de> Jetzt können wir den Geschwindigkeitswert in Zelle C3 zu diesem Wert addieren.
<G-vec00499-001-s044><add.addieren><en> Now we can add the velocity change in cell C3 to this value.
<G-vec00499-001-s045><add.addieren><de> 9, Wahl: äußeres Leitblech addieren die Landeklappenfunktion, die die Papporientierung genauer machte, vermeiden, um zu vergeuden.
<G-vec00499-001-s045><add.addieren><en> 9, Option: outside baffle add the flap function, which made the cardboard orientation more exact, avoid to
<G-vec00499-001-s046><add.addieren><de> Wir dürfen nie addieren, subtrahieren oder die Lehre von Christus oder zu denen er Vollmacht gab, seine geschriebene Wort aufzunehmen.
<G-vec00499-001-s046><add.addieren><en> We must never add, subtract or change the doctrine of Christ or to whom He gave authority to record His written word.
<G-vec00499-001-s047><add.addieren><de> 1 Aufgrund von Rundungen ist es möglich, dass sich einzelne Zahlen in dieser Pressemitteilung nicht genau zur angegebenen Summe addieren lassen und sich die Neunmonatszahlen nicht aus der Aufsummierung der einzelnen Quartalszahlen ergeben.
<G-vec00499-001-s047><add.addieren><en> 1 Due to rounding it is possible that individual figures presented in this press release may not add up exactly to the totals shown and that the nine-month figures listed may not follow from adding up the individual quarterly figures.
<G-vec00499-001-s048><add.addieren><de> "Bitte geben Sie diese Formel ein = SUMIF (A2: A6 ""TEC * *"" B2: B6) in eine leere Zelle und drücken Sie Weiter Schlüssel, dann addieren sich alle Zahlen in Spalte B, wo die entsprechende Zelle in Spalte A den Text ""KTE"" enthält."
<G-vec00499-001-s048><add.addieren><en> "Please enter this formula =SUMIF(A2:A6,""*KTE*"",B2:B6) into a blank cell, and press Enter key, then all the numbers in column B where the corresponding cell in column A contains text “KTE” will add up."
<G-vec00499-001-s049><add.addieren><de> Am Freitag muss ich 3 Tage addieren, um auf den kommenden Montag zu kommen, am Samstag 2 Tage und an allen anderen Tagen ist der nächste Tag auch der nächste Arbeitstag.
<G-vec00499-001-s049><add.addieren><en> On friday we must add 3 days to get next monday, on saturday 2 days are to be added and for all other weekdays the next day is the next working day.
<G-vec00499-001-s050><add.addieren><de> Wir bieten 5 Doppelzimmer, von denen jeder die Möglichkeit, 5 Einzelbetten zu addieren hat.
<G-vec00499-001-s050><add.addieren><en> We offer 5 double bedrooms, each of which has the possibility to add up to 2 single beds.
<G-vec00499-001-s051><add.addieren><de> Die Vergeudung wird erzeugt, wenn Leute in einer zu großen Hast sind, zum von von mehr Aufstellungsorten zu errichten, von von mehr Produkten zu addieren und mehr Verkehrs an Aufstellungsorte zu gelangen, die manchmal 1000% umwandeln können, das BESSER ist, als sie jetzt.
<G-vec00499-001-s051><add.addieren><en> The waste is generated when people are in too big a hurry to build more sites, add more products, and get more traffic to sites that can convert sometimes 1000% BETTER than they do now.
<G-vec00499-001-s052><add.addieren><de> • Zeileneinsatz: Klicken Sie auf diesen Button, um Ihren Einsatz pro aktivierter Gewinnlinie zu addieren oder abzuziehen.
<G-vec00499-001-s052><add.addieren><en> • Bet per Line: Click this button to add or subtract from your wager per activated payline.
<G-vec00499-001-s053><add.addieren><de> Sie addieren sich automatisch um 0,3 mm pro Jahr in dieser Region, nicht weil das Meer steigt, sondern um einen angeblichen isostatischen Anstieg des Landes auszugleichen.
<G-vec00499-001-s053><add.addieren><en> They automatically add 0.3 mm per year to this region, not because the sea is rising, but to compensate for an alleged isostatic increase in land.
<G-vec00499-001-s054><add.addieren><de> Viele Mal möchte ein Inhaber eines unabhängigen einzeln aufführengeschäftes jene Einzelteile addieren, die he/she glaubt, dass ihre Kunden wünschen.
<G-vec00499-001-s054><add.addieren><en> Many times an owner of an independent Detailing Shop will wish to add those items he/she believes their customers want.
<G-vec00499-001-s055><add.addieren><de> Leider tun wir ein wenig vom Feiern während dieser Zeit des Jahres und addieren oben Extragepäck, wenn das neue Jahr erscheint.
<G-vec00499-001-s055><add.addieren><en> Unfortunately, we do a little bit of celebrating during this time of year and add up extra baggage when the New Year appears.
<G-vec00499-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00499-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
