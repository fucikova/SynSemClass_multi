<G-vec00272-001-s105><invite.einladen><de> Customer Alliance ermöglicht es Ihnen, Gäste dazu einzuladen, Ihre Bewertungen in 19 verschiedenen Sprachen abzugeben.
<G-vec00272-001-s105><invite.einladen><en> Customer Alliance allows you to invite your guests to leave a review in 19 different languages.
<G-vec00272-001-s106><invite.einladen><de> Eines der Ziele von Taktil ist es, interessierte und talentierte Frauen mit Migrationshintergrund dazu einzuladen, ihre handwerklichen und gestalterischen Fertigkeiten weiterzuentwickeln.
<G-vec00272-001-s106><invite.einladen><en> One of the goals of Taktil is to invite interested and talented women with a migration background to continue developing their manual and design skills.
<G-vec00272-001-s107><invite.einladen><de> Ein Riesenland, flächenmäßig das größte der Welt, das ganz andere Potenzen besitzt und Fähigkeiten entwickeln könnte als gelegentlich mal internationale Konzerne wie Siemens oder auch die Deutsche Bank dazu einzuladen, sich an der Ausbeutung der eigenen Bevölkerung zu beteiligen.
<G-vec00272-001-s107><invite.einladen><en> A huge country, in terms of area, the largest in the world to have very different potencies and develop skills rather than occasionally to invite some international companies like Siemens and the German bank to participate in the exploitation of its own people.
<G-vec00272-001-s108><invite.einladen><de> Die raffinierte Anordnung der sie umgebenden Buchstaben sollte ihren anonymen Auftraggeber dazu einzuladen, die sorgfältige Kombination von Gold und Farben im Detail zu würdigen.
<G-vec00272-001-s108><invite.einladen><en> The subtle arrangement of the surrounding letters should invite the anonymous patron to appreciate the meticulous combination of gold and colors in detail.
<G-vec00272-001-s109><invite.einladen><de> Klick auf “Mehr dazu”, um noch mehr Freunde einzuladen.
<G-vec00272-001-s109><invite.einladen><en> Click “See More” to invite even more of your friends.
<G-vec00272-001-s110><invite.einladen><de> "Wie der Compañero vom Nationalen Indigenen Kongress sagte: ""Wir sind gekommen um Sie dazu einzuladen, die Regierung nicht zu bitten, sondern sie loszuwerden""."
<G-vec00272-001-s110><invite.einladen><en> "As the National Indigenous Congress compañero said: ""we came to invite you, not to ask the government, but to get rid of it."""
<G-vec00272-001-s111><invite.einladen><de> Diese Tatsachen haben unseren CEO Peter Linke dazu inspiriert, unsere Partner und Freunde zu einer großen Party einzuladen.
<G-vec00272-001-s111><invite.einladen><en> This fact inspired our CEO – Peter Linke to invite our partners and friends to a great party.
<G-vec00272-001-s112><invite.einladen><de> "Klick auf ""Mehr dazu"", um noch mehr Freunde einzuladen."
<G-vec00272-001-s112><invite.einladen><en> "Click ""See More"" to invite even more of your friends."
<G-vec00272-001-s113><invite.einladen><de> Ihr Abonnement, das für ein Jahr ab Kaufdatum gültig ist, entspricht einem Guthaben, das Sie frei verwenden können, um Ihre Produkte oder Behandlungen zu erwerben, und sogar die Person Ihrer Wahl dazu einzuladen, Sie zu begleiten.
<G-vec00272-001-s113><invite.einladen><en> Your membership, valid for one year following the date of purchase, is credit you can use freely to buy products or treatments, and even invite the person of your choice to accompany you.
<G-vec00272-001-s114><invite.einladen><de> Die Allianz für die Freiheit der Frau ist wirklich geehrt jeden dazu einzuladen, diese Kunstausstellung zu besuchen.
<G-vec00272-001-s114><invite.einladen><en> The Alliance for Women's Freedom is truly honoured to invite everyone to attend this art exhibition.
<G-vec00272-001-s115><invite.einladen><de> Und dann dazu einzuladen, ja zu Ihm zu sagen und Ihm nachzufolgen.
<G-vec00272-001-s115><invite.einladen><en> And then then to invite to conform to Him and follow Him.
<G-vec00272-001-s116><invite.einladen><de> Um mit der Web-App von Memopal verbundene Kollegen und Freunde dazu einzuladen, zusammen einen synchronisierten Ordner zu bearbeiten, vergewissern Sie sich, dass Sie in Sync sind, wählen Sie den Ordner, den Sie teilen möchten, und klicken Sie mit der rechten Maustaste auf „Geteilte Optionen”.
<G-vec00272-001-s116><invite.einladen><en> To invite colleagues and friends to cooperate in a synchronized folder, connected to the Memopal web app, be sure to be in Sync, select the folder you want to share and right-click “Sharing Options”.
<G-vec00272-001-s117><invite.einladen><de> Man hatte uns im Mai von Taizé aus nach Lettland geschickt, um die Jugendlichen über dieses baltische Treffen zu informieren und dazu einzuladen.
<G-vec00272-001-s117><invite.einladen><en> As volunteers from Taizé we were in Latvia in May to inform and invite young people to this Baltic Meeting.
<G-vec00272-001-s118><invite.einladen><de> Um Sie dazu einzuladen, auf der Website von Vogel's eine Produktbewertung Ã1⁄4ber ein Vogel's-Produkt zu schreiben.
<G-vec00272-001-s118><invite.einladen><en> To invite you to write a product review of a Vogel's product on the Vogel's website.
<G-vec00272-001-s138><invite.einladen><de> Der Wagen hielt mitten in der Stadt vor einer Bierhalle (lokale Kneipe) und ich hielt es für einen netten Zug der Offiziellen uns nach dem Essen auf ein paar Drinks einzuladen.
<G-vec00272-001-s138><invite.einladen><en> The car stopped downtown in fornt of a beerhall (local bar). I found it a nice gesture of the officials to invite us for a drink after lunch.
<G-vec00272-001-s139><invite.einladen><de> Sechs Milliarden Menschen leben auf unserem Planeten und wir laden alle ein, sie einzuladen.
<G-vec00272-001-s139><invite.einladen><en> Six billion people live on our planet, and we invite everyone to invite them.
<G-vec00272-001-s140><invite.einladen><de> "Hinweis: Um ein Model zu einem absolut privaten Chat einzuladen, klicken Sie einfach auf den “Privat-Chat” Button direkt über dem Webcam-Video des Models, wählen ""Absolut privater Chat"" aus und klicken Start."
<G-vec00272-001-s140><invite.einladen><en> Note: To invite a model into a Full Private Chat simply click on the “Private Chat” button just above model's webcam video, select “Full Private Chat” and click start.
<G-vec00272-001-s141><invite.einladen><de> Ein Großteil der Früchte über die Praxis der Körperhaltungen und Bewegungen von Yoga ist, diese Art von Auflösung einzuladen.
<G-vec00272-001-s141><invite.einladen><en> Much of the fruit of the practice of postures and movements of Yoga is to invite this type of resolution.
<G-vec00272-001-s142><invite.einladen><de> Ein Blick auf die Geschichte zeigt, dass die Tibeter, um Lehrer nach Tibet einzuladen, nicht nur zu Fuß nach Indien reisen mussten, sondern auch alle vielerlei Mittel beschaffen mussten, um die Reisekosten zu bestreiten und angemessene Gaben darbringen zu können.
<G-vec00272-001-s142><invite.einladen><en> Historically, in order to invite teachers to Tibet, not only did the Tibetans need to walk to India to invite them, but they also had to gather all sorts of resources for the journey and as offerings.
<G-vec00272-001-s143><invite.einladen><de> Ein Adliger aus der Licchavi-Dynastie namens Mahali aus Vesali hörte vom Buddha und schlug dem König Bimbisara vor, ihn nach Magadha einzuladen.
<G-vec00272-001-s143><invite.einladen><en> The Licchavi nobleman Mahali from Vesali heard of the Buddha and suggested to King Bimbisara that he invite him to Magadha.
<G-vec00272-001-s144><invite.einladen><de> Es war uns ein großes Anliegen, seine Eminenz, das Oberhaupt der Kirche in Südafrika, zu uns einzuladen damit er mit eigenen Augen sehen und erleben konnte, was wir als Teil seiner Herde tun.
<G-vec00272-001-s144><invite.einladen><en> We felt strongly that we should invite his Eminence, as the head of the Church in South Africa, to visit us to see with his own eyes and experience what we are doing as part of his flock.
<G-vec00272-001-s145><invite.einladen><de> "Geben Sie Titel und Ort ein und wählen Sie ""Weitere Details hinzufügen"", um zusätzliche Personen einzuladen oder Erinnerungen hinzuzufügen."
<G-vec00272-001-s145><invite.einladen><en> Add the event title and location, and select 'Add more details' to see options to invite people to the event or to add an alert reminder.
<G-vec00272-001-s146><invite.einladen><de> Jede Veranstaltung von It all depends wird zum Anlass genommen, ein bis zwei unabhängige AutorInnen aus dem thematischen Umfeld des Projekts einzuladen, eine Rezension zu verfassen.
<G-vec00272-001-s146><invite.einladen><en> Each edition of It all depends is taken as an opportunity to invite one or two independent authors from the thematic field of the project to write a review.
<G-vec00272-001-s147><invite.einladen><de> "Alles, was du tun musst, um ein Model auf einen privaten Chat einzuladen, ist den Button ""Privat Chat"" anzuklicken, dann ""Privater Chat"" aus der Liste wählen und schließlich auf den ""Start"" Button klicken."
<G-vec00272-001-s147><invite.einladen><en> All you need to do to invite a model to a private chat is click the Private Chat button, choose PRIVATE CHAT from the list, and click START.
<G-vec00272-001-s148><invite.einladen><de> Tatsächlich, zu wissen, stromaufwärts, wie ich in einer solchen Situation gehandelt hätte, Ich kann garantieren, dass kein Bischof hat nie fiel mir ein, mich einzuladen, die Rolle der Trainer in einem dieser Seminare zu spielen hatte ich mehrmals die Öffentlichkeit an den Pranger stellen, wie die oben pretifici; weil sie sehr gut, dass bestimmte Seminare kennen, schon halb leer, Ich hätte sie fast vollständig entleert.
<G-vec00272-001-s148><invite.einladen><en> Indeed, knowing upstream as I would have acted in such situations, I can guarantee that no bishop has never crossed my mind to invite me to play the role of trainer in one of those seminars I held up several times the public pillory as the pretifici; because they know very well that certain seminars, already half-empty, I would have emptied them almost entirely.
<G-vec00272-001-s149><invite.einladen><de> Den Rahmen für „curated by_vienna“ bildet ein spannendes und unkonventionelles Konzept, welches ausgewählten Wiener Galerien die Möglichkeit bietet, international arbeitende Kuratorinnen und Kuratoren für die Zusammenstellung je einer Ausstellung einzuladen.
<G-vec00272-001-s149><invite.einladen><en> The exciting and unusual conceptual framework for the festival gives selected Viennese galleries the chance to invite internationally active curators to put together exhibitions.
<G-vec00272-001-s169><invite.einladen><de> Nicht jeder Mensch, auch mit brennendem Wunsch,wagen, eine Frau zu sich selbst oder zu einem abgelegenen Ort einladen.
<G-vec00272-001-s169><invite.einladen><en> Not every man, even burning with desire,dare invite a woman to itself or to some secluded spot.
<G-vec00272-001-s170><invite.einladen><de> Wenn Sie ein Team erstellen, können Sie während des Bezahlvorgangs mehrere Benutzerkonten vorab kaufen und dann Personen einladen, Ihrem Team beizutreten und diese Plätze zu belegen.
<G-vec00272-001-s170><invite.einladen><en> When you create a team, you can pay for multiple user accounts upfront during checkout, and then invite people to join your team and fill those seats.
<G-vec00272-001-s171><invite.einladen><de> Wenn Sie möchten, liefern die spezifischen gleichen Airbnb Reduzierung Ihrer Familie und Freunden, gehen Sie auf Freunde Einladen in die Airbnb-Menü, und erhalten Sie Ihren persönlichen Empfehlungs-link, den Sie bereit sind zu senden, um jemand.
<G-vec00272-001-s171><invite.einladen><en> If you would like to supply the specific same Airbnb reduction to your family and friends, go to Invite Friends in the Airbnb menu, and you’ll receive your own personal referral link that you are ready to send to anybody.
<G-vec00272-001-s172><invite.einladen><de> Au Pair Einladungschreiben Liebe (r), Wir, Familie _______________________ möchten Dich als Au Pair gemäß des europäischen Abkommens über die Au Pair Beschäftigung einladen.
<G-vec00272-001-s172><invite.einladen><en> Au Pair invitation letter Dear ________, We are the _________ family and we would like to invite you as our au pair in accordance with the European Agreement on Au Pair Placement.
<G-vec00272-001-s173><invite.einladen><de> Vor Beginn der Fastenzeit, in der uns der Herr Jesus Christus in besonderer Weise zur Umkehr ruft, möchte ich mich an jeden einzelnen von Euch wenden und Euch einladen, über diese Wahrheit nachzudenken und konkrete Taten zu vollbringen, die die Reinheit des Herzens beweisen.
<G-vec00272-001-s173><invite.einladen><en> Yes, as Lent draws near, when our Lord Jesus Christ calls us in a particular way to conversion, I wish to address each one of you and invite you to think about this truth and to do good deeds which will show your sincerity of heart.
<G-vec00272-001-s174><invite.einladen><de> """Damit ihr all diese Schätze der Christen der Ostkirche kennenlernen könnt, würde ich euch am liebsten einladen, am Sonntag nicht nach Hause zu fahren, sondern noch bis Dienstag zu bleiben, um mit uns zusammen den Patriarchen von Konstantinopel zu empfangen."
<G-vec00272-001-s174><invite.einladen><en> So that you may discover something of all these treasures of the Christians of the East, I would like to invite you: instead of going home on Sunday, stay on until Tuesday to welcome with us the Patriarch of Constantinople.
<G-vec00272-001-s175><invite.einladen><de> Ab September werden wir mit neuem Schwung in die Vorbereitung starten, kräftig wirbeln und viele uns mittlerweile gut bekannte Menschen und Institutionen einladen.
<G-vec00272-001-s175><invite.einladen><en> Starting in September, our preparations will gain new momentum. We will do some massive advertising and invite many people and institutions we know well by now.
<G-vec00272-001-s176><invite.einladen><de> Er wollte den Praktizierenden einladen, eine Rede über Falun Gong zu halten.
<G-vec00272-001-s176><invite.einladen><en> He would like to invite the practitioner to give a speech about Falun Gong.
<G-vec00272-001-s177><invite.einladen><de> In Travian könnt ihr über eure Botschaft einen Geheimbund gründen und andere Spieler einladen, diesem beizutreten.
<G-vec00272-001-s177><invite.einladen><en> In Travian, you can found a Secret Society in your Embassy and invite other players to join.
<G-vec00272-001-s178><invite.einladen><de> Anlässlich unseres kleinen Jubiläums möchten wir all unseren musikliebenden Freunden Gelegenheit einladen, sich mit uns zu verbinden und unsere zukünftige Arbeit zu unterstützen.
<G-vec00272-001-s178><invite.einladen><en> To celebrate our small jubilee we would like to invite all our music-loving friends to connect with us and support our future projects.
<G-vec00272-001-s179><invite.einladen><de> Genießen Sie seine praktische Seite, auf der Sie bequem sitzen, oder Ihre Gäste einladen können.Er steht unauffällig in einer Ecke Ihres Wohnzimmers oder vor Ihrem Schreibtisch und Sie werden froh sein, dass Sie diesen Kauf getätigt haben.
<G-vec00272-001-s179><invite.einladen><en> You will also enjoy its practical side that allows you to be seated comfortably or to invite your guests to do the same. As it sits discreetly in a corner of your living room or in front of your desk, you'll be glad you made this purchase.
<G-vec00272-001-s180><invite.einladen><de> Sie können auch Ihre Freunde einladen - Spaß zusammen zu spielen.
<G-vec00272-001-s180><invite.einladen><en> You can also invite your friends - play with more fun.
<G-vec00272-001-s181><invite.einladen><de> Das ist der Spirit des chic&basic Velvet, in das wir Dich einladen auf eine Reise in das leichtlebige Barcelona der Vergangenheit... unser Hotel sowohl für private als auch geschäftliche Aufenthalte.
<G-vec00272-001-s181><invite.einladen><en> This is the spirit of the chic&basic Velvet Hotel where we invite you to experience the most bohemian side of Barcelona, whether you are travelling for pleasure or for business.
<G-vec00272-001-s182><invite.einladen><de> Alle Themeninseln beinhalten interaktive und multimediale Inhalte, die zum Mitmachen einladen.
<G-vec00272-001-s182><invite.einladen><en> All themed exhibits have interactive and multimedia contents that invite visitors to join in.
<G-vec00272-001-s183><invite.einladen><de> Seitdem dürfen die Behörden den orthodoxen und den katholischen Bischof nicht mehr gemeinsam einladen.
<G-vec00272-001-s183><invite.einladen><en> Since then the authorities may no longer invite the Orthodox and the Catholic bishop together.
<G-vec00272-001-s184><invite.einladen><de> Sie sind zur Teilnahme am b'friends-Programm berechtigt und können Ihre Freunde und Bekannten einladen, ein Konto auf dieser Plattform zu eröffnen.
<G-vec00272-001-s184><invite.einladen><en> You are entitled to participate in the b'friends program and invite Your friends and acquaintances to open an Account on this platform.
<G-vec00272-001-s185><invite.einladen><de> Am Ende des Rundgangs dürfen wir Sie zu einem Gläschen Sekt einladen und freuen uns, wenn die Inspiration des Ausstellungsrundgangs veranlasst, dass sich das ein oder andere Paar finden wird.
<G-vec00272-001-s185><invite.einladen><en> At the end of the tour we would like to invite you to a glass of sparkling wine and would be pleased if the inspiration of the tour through the exhibition would lead to find one or the other couple.Â
<G-vec00272-001-s186><invite.einladen><de> 1 Nach Inkrafttreten dieses Rahmenübereinkommens und nach Konsultation der Vertragsstaaten kann das Ministerkomitee des Europarats durch einen mit der in Artikel 20 Buchstabe d der Satzung des Europarats vorgesehenen Mehrheit gefaßten Beschluß jeden Nichtmitgliedstaat des Europarats, der nach Artikel 27 eingeladen wurde, zu unterzeichnen, dies aber noch nicht getan hat, und jeden anderen Nichtmitgliedstaat einladen, dem Übereinkommen beizutreten.
<G-vec00272-001-s186><invite.einladen><en> 1 After the entry into force of this framework Convention and after consulting the Contracting States, the Committee of Ministers of the Council of Europe may invite to accede to the Convention, by a decision taken by the majority provided for in Article 20.d of the Statute of the Council of Europe, any non-member State of the Council of Europe which, invited to sign in accordance with the provisions of Article 27, has not yet done so, and any other non-member State.
<G-vec00272-001-s187><invite.einladen><de> Die Technik bietet sich beispielsweise an, wenn Auto- oder Flugzeughersteller ihre Kunden zur Besichtigung neuer Modelle einladen wollen, obwohl die Maschine noch gar nicht gebaut wurde.
<G-vec00272-001-s187><invite.einladen><en> The technology can be used, for example, when car or aircraft manufacturers want to invite their customers to visit new models even though the engine has not yet been built.
<G-vec00272-001-s207><invite.einladen><de> Dem Besucher mag das System, das dem Arrangement zu Grunde liegt, nicht sofort auffallen, aber die räumlichen Relationen üben eine gewisse Anziehungskraft aus, welche einlädt nicht nur die Ordnung hinter dem Arrangement zu entdecken, sondern auch spielerische und ironische Details und Anspielungen, die Dabernig in den Raum eingeführt hat.
<G-vec00272-001-s207><invite.einladen><en> A visitor might not be immediately aware of the underlying system, but there is a certain attraction in the spatial relations that invite him/her to discover not only the order of arrangement, but also the playful and ironic details and references that Dabernig has introduced to the space.
<G-vec00272-001-s208><invite.einladen><de> Das Grab: Ich möchte gerne, dass es wirklich in der Erde ist, versehen mit einem schlichten Zeichen, das den Ort bezeichnet und zu christlicher Andacht einlädt.
<G-vec00272-001-s208><invite.einladen><en> As regards my tomb: I would like to be buried in the earth with a simple stone to indicate the place and invite a prayer of Christian piety.
<G-vec00272-001-s209><invite.einladen><de> Es ist leider einmal mehr ein Song, der nicht wirklich zum aktiven Hören einlädt, er rauscht an einem vorbei, ohne dass man großartig die Übergänge zu den Vorgänger- und Nachfolger-Liedern hören kann.
<G-vec00272-001-s209><invite.einladen><en> Unfortunately, it´s once again a song that does not invite you to actively listen to it; it is just playing in the back and you cannot really hear the transitions from one song to the next.
<G-vec00272-001-s210><invite.einladen><de> So wird sichergestellt, dass sich die Speisekarte regelmäßig ändert und das Restaurant Sie weiterhin zu einem Geschmackserlebnis einlädt.
<G-vec00272-001-s210><invite.einladen><en> This ensures that the menu changes regularly, so that the restaurant continues to invite you to come back for a taste sensation.
<G-vec00272-001-s211><invite.einladen><de> Seit dem Studienjahr 1999/2000 besteht eine Kooperation mit der Austrian Fulbright Commission, die amerikanische WissenschaftlerInnen zu einem einsemestrigen Forschungsaufenthalt in Wien einlädt, der mit einer Lehrtätigkeit an einer Universität verknüpft ist.
<G-vec00272-001-s211><invite.einladen><en> Since 1999, the Sigmund Freud Foundation and the Austrian Fulbright Commission invite american scientists for a study visit which is combined with a visiting professorship on a university in Vienna.
<G-vec00272-001-s212><invite.einladen><de> Von einem Graduiertenkolleg (GRK) wird erwartet, dass es enge Kontakte ins Ausland pflegt, Gastwissenschaftlerinnen und Gastwissenschaftler aus dem Ausland einlädt, Promovierende international rekrutiert und ihnen Auslandsaufenthalte und Besuche von internationalen Konferenzen ermöglicht.
<G-vec00272-001-s212><invite.einladen><en> A Research Training Group (RTG) is expected to maintain close contacts with researchers in other countries, invite visiting researchers from abroad, recruit doctoral researchers internationally and allow them to spend time working abroad and attend international conferences.
<G-vec00272-001-s213><invite.einladen><de> Zur Abschlussveranstaltung des Kongresses 2014 wurde die ITA-Flagge an den kroatischen Verband übergeben, der 2015 nach Dubrovnik einlädt; der WTC 2016 wird in San Franzisko stattfinden.
<G-vec00272-001-s213><invite.einladen><en> At the Closing Session of the 2014 Congress the ITA flag was passed on to ITA Croatia, that will invite the international tunnelling community to Dubrovnik in 2016. The WTC 2015 will take place in San Francisco.
<G-vec00272-001-s214><invite.einladen><de> Als kurz geht wegnorden, Wellen einlädt Sie, Ihr Surfen zu prüfen.
<G-vec00272-001-s214><invite.einladen><en> As short walk away north, waves will invite you to test your surfing.
<G-vec00272-001-s215><invite.einladen><de> Wir touren gerade durch's nördliche Europa, Deutschland und Holland; aber wir werden den Süden bald nachholen und spielen überall, wohin man uns einlädt.
<G-vec00272-001-s215><invite.einladen><en> We travel through Europe for the moment, more in the north, Germany and Holland but we're gonna do the south soon and everywhere they invite us.
<G-vec00272-001-s216><invite.einladen><de> Wir touren gerade durch’s nördliche Europa, Deutschland und Holland; aber wir werden den Süden bald nachholen und spielen überall, wohin man uns einlädt.
<G-vec00272-001-s216><invite.einladen><en> We travel through Europe for the moment, more in the north, Germany and Holland but we’re gonna do the south soon and everywhere they invite us.
<G-vec00272-001-s217><invite.einladen><de> Mit seiner Werkgruppe der Panoramen, die 2000/2001 entstand, setzte sich Brandl schon einmal mit dem langgestreckten Format auseinander, das das gesamte Gesichtsfeld des Betrachters einnimmt und zum physischen Eintreten und Verweilen in dieser „Landschaft“ einlädt.
<G-vec00272-001-s217><invite.einladen><en> "With his series of panoramas, created in 2000 and 2001, Herbert Brandl once before dealt with the landscape format, that occupies the observer's entire visual field and seems to invite us to physically enter and rest in this ""landscape"" before us."
<G-vec00272-001-s218><invite.einladen><de> "Das ""House"" ist der Ort, der verbindet, an dem man selbst sein darf und die Familie zusammenkommt, und wohin man als Gastgeber seine Freunde und Gäste einlädt."
<G-vec00272-001-s218><invite.einladen><en> """House"" is a place that unites, where you can be yourself, where the family comes together, and where you invite friends and guests as a host."
<G-vec00272-001-s219><invite.einladen><de> Schlendern Sie gemütlich durch die historische Altstadt, die mit romantischen Gassen und gemütlichen Straßencafés zum Verweilen einlädt.
<G-vec00272-001-s219><invite.einladen><en> Amble through the historic old town where the romantic alleys and friendly street cafés invite you to stay a while.
<G-vec00272-001-s220><invite.einladen><de> Weil es aber nicht einlädt um zu bleiben und auch zu heiß ist tagsüber, ist man gezwungen, jeden Tag mit dem Auto weg zu fahren.
<G-vec00272-001-s220><invite.einladen><en> But because it does not invite you to stay and too hot during the day, you are forced to drive away every day.
<G-vec00272-001-s221><invite.einladen><de> (siehe also Videoclips) Zwischendurch dürfen sich die beiden Leadstimmen, wovon die eine eben Inga Scharf gehört und die andere zu Philip Dennis „Sly“ Schunke, etwas ausruhen, während der Rest der Truppe zu einer kleinen akustischen Einlage einlädt.
<G-vec00272-001-s221><invite.einladen><en> (see also Videoclips) meanwhile both lead voices, Inga Scharf and the other Philip Dennis „Sly“ Schunke, can rest a little while the other's invite us to a little acoustic performance.
<G-vec00272-001-s222><invite.einladen><de> Auch wenn dieser Bereich eher zum Umkehren einlädt als zum Weiterfahren, sollte man den Ehrgeiz behalten und weitermachen, denn danach kommt bis zum Nordkap ein super Waldweg.
<G-vec00272-001-s222><invite.einladen><en> Even if this section might invite you to turn back rather than to ride on, you should keep the ambition to carry on, because afterwards an excellent forest track leads you to Cape North.
<G-vec00272-001-s223><invite.einladen><de> Das Burgdorf beherrscht den Golf von Baratti, der mit seinem ruhigem Wasser, auch wenn es sehr windig ist, und seinem goldene Sandstrand zum erholsamen Baden einlädt.
<G-vec00272-001-s223><invite.einladen><en> Situated on top of the Gulf of Baratti, whose waters stay calm also during very windy days and whose golden beaches seem to invite you to relax after a good bath.
<G-vec00272-001-s224><invite.einladen><de> Diese genießt man in einem gastlichen Rahmen, dessen dezenter Charme die sanfte Schönheit der Natur einer Region zur Geltung bringt, die zu jeder Saison zur Entdeckung einlädt, mit der Familie, als Paar, mit Freunden oder in der Gruppe.
<G-vec00272-001-s224><invite.einladen><en> The discreet charm only enhances the enjoyable natural environment of a region that we invite you to discover alone, with family, as a couple, with friends or in a group at each new season.
<G-vec00272-001-s225><invite.einladen><de> Wenn Véronique zuhause ist, haben Sie nur Zugang zum Wohnzimmer, wenn sie Ihnen das Frühstück serviert und/oder Sie dorthin einlädt.
<G-vec00272-001-s225><invite.einladen><en> When Véronique is at home, you have an access to the living room only when she serves breakfast and/or invite you to share some time with her.
<G-vec00272-001-s226><invite.einladen><de> Im folgenden, wenn das Portal erstellt sein wird, einzuladen, an der Arbeit und andere Firmen teilzunehmen.
<G-vec00272-001-s226><invite.einladen><en> Further, when the portal will be created, to invite to take part in work and other firms.
<G-vec00272-001-s227><invite.einladen><de> Es wurde beschlossen, in der zweiten Jahreshälfte 2011 ein Symposium zu organisieren mit dem Ziel, das ICCJ Berlin-Dokument Â 'A time for Recommitment' zu diskutieren undÂ sich gegenseitig Â einzuladen, Â gemeinsam Chanukka und Weihnachten zu feiern.
<G-vec00272-001-s227><invite.einladen><en> It was decided to organize in the second half of 2011 a symposium to discuss the ICCJ Berlin document 'A time for Recommitment'Â and to invite mutually to celebrate together Chanukah and Christmas. Â
<G-vec00272-001-s228><invite.einladen><de> Als Ewald von Kleist 1963 zum ersten Mal nach München zur Konferenz bat, lag ihr der Gedanke zugrunde, unseren wichtigsten Verbündeten zu einer Diskussion über die großen strategischen Fragen der damaligen Zeit einzuladen.
<G-vec00272-001-s228><invite.einladen><en> In 1963, when Ewald von Kleist invited participants to Munich for the first conference, which Americans fondly call the “Wehrkunde” to this day, the motivating idea was to invite our most important allies to a discussion about the major strategic issues directly affecting Germany and NATO.
<G-vec00272-001-s229><invite.einladen><de> Zwei einfache Wege, Leute zu Ihrer Umfrage einzuladen: E-Mail-Einladung: Eine vorgeschriebene, einfach zu bearbeitende E-Mail-Einladung ist Teil des Umfrageservices von Benchmark Email.
<G-vec00272-001-s229><invite.einladen><en> Survey Email Invitations Two simple ways to invite people to take your survey: Email invitation: A pre-written, easy-to-edit email invitation is part of Benchmark Email Survey.
<G-vec00272-001-s230><invite.einladen><de> Die Rücknahme der Exkommunikation dient dem gleichen Ziel wie die Strafe selbst: noch einmal die vier Bischöfe zur Rückkehr einzuladen.
<G-vec00272-001-s230><invite.einladen><en> The withdrawal of the excommunication serves the same purpose as the punishment itself: once more to invite the four bishops to return.
<G-vec00272-001-s231><invite.einladen><de> Durch die Unterstützung des Prozesses jedes Eco-Teams, persönliche Freunde und Nachbarn zur Bildung von zwei weiteren Eco Teams, einzuladen, tritt eine Verdoppelung der Anzahl der Öko-Teams mit minimalem Aufwand alle sechs Monate auf .
<G-vec00272-001-s231><invite.einladen><en> By supporting each Eco Team's process to personally invite friends and neighbors to develop two other Eco Teams, a doubling of the number of Eco Teams occurs with minimal effort every six months .
<G-vec00272-001-s232><invite.einladen><de> Das EPA wird einzuladen, auf der Grundlage der ersten Bewertung der Angebote, die ranghöchste besten 3 bis zu 5 Bieter, 5 Dokumente ins Englische zu übersetzen, eines in jeder Sprache, um die Fähigkeit, die Übersetzungen in der geforderten Zeit und Qualität durchzuführen, zu testen.
<G-vec00272-001-s232><invite.einladen><en> Based on the initial evaluation of the bids, the EPO will invite the highest ranking 3 up to 5 bidders to translate 5 documents in English, one in each language, this in order to test the ability to perform the translations in the required time and quality.
<G-vec00272-001-s233><invite.einladen><de> Es würde nett sein, Vati zur Dusche einzuladen.
<G-vec00272-001-s233><invite.einladen><en> It would be nice to invite dad to the shower.
<G-vec00272-001-s234><invite.einladen><de> Erinnert euch an die Macht der Dankbarkeit eures Herzens zu heilen, erwecken und neues Gewahrsein einzuladen.
<G-vec00272-001-s234><invite.einladen><en> Remember the power of your heart's gratitude to heal, awaken and invite new awareness.
<G-vec00272-001-s235><invite.einladen><de> Als die Prozession der Praktizierenden am Zielort der Parade angekommen war, versuchte er, alle Praktizierenden der Parade zum Essen einzuladen.
<G-vec00272-001-s235><invite.einladen><en> When the practitioners' procession reached the destination of the parade, he attempted to invite all the practitioners in the parade to lunch.
<G-vec00272-001-s236><invite.einladen><de> Ziel ist es, die Menschen in der Öffentlichkeit einzuladen, darüber nachzudenken, wie diese Texte zu ihren eigenen Ansichten über das Glück in ihrem täglichen Leben beitragen können.
<G-vec00272-001-s236><invite.einladen><en> Her aim is to invite the people in the audience to think about how these texts can contribute to their own views on happiness within their everyday lives.
<G-vec00272-001-s237><invite.einladen><de> Die Quality Austria freut sich als einzige in Österreich akkreditierte IFS Zertifizierungsstelle alle Kunden in Österreich und insbesondere auch in Südtirol zu dieser wichtigen Informationsveranstaltung einzuladen.
<G-vec00272-001-s237><invite.einladen><en> Quality Austria, which is the only Austrian organization to be accredited as an IFS Certification Body, is pleased to invite all the customers in Austria and, above all, also in South Tyrol to invite to this important information event.
<G-vec00272-001-s238><invite.einladen><de> Wenn oft solche logischen Spiele zu spielen, können Sie erheblich verbessern Sie Ihren Wortschatz, Spaß haben pauken.Achten Sie darauf, Ihre Freunde einzuladen, führen dieses großartige Spiel und beginnen, den Prozess zu genießen, denn die Vielfalt der Auswahl an Spielen wird Ihnen erlauben, mehr und mehr schwierig Ebenen des Spiels.
<G-vec00272-001-s238><invite.einladen><en> If often such logical games to play, you can greatly improve your vocabulary, have fun cramming.Be sure to invite your friends, run this great game and start to enjoy the process, because the variety of choice of games will allow you to more and more difficult levels of the game.
<G-vec00272-001-s239><invite.einladen><de> Ernst Löschner dankte ihm für seine Verbundenheit zu APC und erinnerte daran, dass es ohne ihn niemals möglich gewesen wäre, so viele Zeitzeugen in Israel zu finden und zu APC 2007 einzuladen.
<G-vec00272-001-s239><invite.einladen><en> Ernst Löschner thanked him for his closeness to APC and reminded everyone that without him, it would never have been possible to find as many contemporary witnesses and invite them to come to APC 2007 from Israel.
<G-vec00272-001-s240><invite.einladen><de> Unser Kameramann drängte sie, ihn ebenfalls einzuladen, aber er war nicht so glücklich wie der Dildo.
<G-vec00272-001-s240><invite.einladen><en> Our cameraman was pushing her to invite him as well, but he wasn’t as happy as the dildo.
<G-vec00272-001-s241><invite.einladen><de> jedoch, in Ausnahmefällen, der Präsident des Gerichts kann andere Personen einzuladen.
<G-vec00272-001-s241><invite.einladen><en> However, in exceptional circumstances, the President of the Court may invite other persons to attend.
<G-vec00272-001-s242><invite.einladen><de> Mit die schönste Art, Menschen Wertschätzung zu zeigen, ist es, sie an die heimische Tafel einzuladen.
<G-vec00272-001-s242><invite.einladen><en> One of the nicest ways to show you appreciate someone is to invite them for a meal in your home.
<G-vec00272-001-s243><invite.einladen><de> Für den Anschluss ist es wünschenswert, ein Fachunternehmen einzuladen.
<G-vec00272-001-s243><invite.einladen><en> To connect, it is desirable to invite a specialist company.
<G-vec00272-001-s244><invite.einladen><de> "Masken sind Kontakte mit der Geisterwelt, um den Geist einzuladen, den zu ""besitzen"", der die Maske trägt."
<G-vec00272-001-s244><invite.einladen><en> "Masks are contacts to the spirit world to invite the spirit to ""possess"" the wearer."
<G-vec00272-001-s309><invite.einladen><de> In der Rubrik Termine berichten wir über die kommende Axis Roadshow, zu der wir Sie herzlich einladen.
<G-vec00272-001-s309><invite.einladen><en> In addition we report about the coming Axis Roadshow to which we would like to invite you.
<G-vec00272-001-s310><invite.einladen><de> Wir möchten Euch alle herzlich einladen an diesem Match teilzunehmen und einen Abend voller Luftkämpfe mit der Jasta 99 und der RoF Gemeinschaft zu verbringen.
<G-vec00272-001-s310><invite.einladen><en> We would like to invite all of you to participate in this event and spend an evening of flying and fighting together with Jasta 99 and the RoF community.
<G-vec00272-001-s311><invite.einladen><de> Nun möchten wir Sie herzlich zu einer Besichtigung einladen.
<G-vec00272-001-s311><invite.einladen><en> We hereby want to invite you to a personal inspection.
<G-vec00272-001-s312><invite.einladen><de> Dann möchten wir Sie herzlich einladen, sich über unser Kontaktformular mit unseren Einkäufern in Verbindung zu setzen.
<G-vec00272-001-s312><invite.einladen><en> Then we would like to invite you to get in touch with our purchasers via the contact form.
<G-vec00272-001-s313><invite.einladen><de> Zur Berichterstattung über die Verleihung des Karlspreises möchte ich Sie hiermit herzlich einladen.
<G-vec00272-001-s313><invite.einladen><en> I would like to invite you to report about the conferring of the Charlemagne Prize.
<G-vec00272-001-s314><invite.einladen><de> "Ich möchte Sie herzlich einladen, über die Betrachtungen von Janusz Waluski zum Thema ""Deutsche Panzer während des Warschauer Aufstands im Jahre 1944"" zu lesen."
<G-vec00272-001-s314><invite.einladen><en> I would like to invite you to read the reflections of Mr. Janusz Wa³kuski on the subject of German armored weaponry used during the Warsaw Uprising of 1944.
<G-vec00272-001-s315><invite.einladen><de> wir möchten Sie herzlich zum Besuch unseren Kiosk auf Internationaler Handelsmesse von korrosionsbeständiger Stähle STAINLESS 2015 einladen.
<G-vec00272-001-s315><invite.einladen><en> let us kindly invite you to visit our stand at the International Fair of stainless steel STAINLESS 2015.
<G-vec00272-001-s316><invite.einladen><de> Wir möchten Sie herzlich zu unserem Welttag 2014 in Wien einladen.
<G-vec00272-001-s316><invite.einladen><en> We would like to invite you to the International Tourist Guide Day 2014 in Vienna.
<G-vec00272-001-s317><invite.einladen><de> Ich darf Sie recht herzlich zu einem Rundgang durch die Anlage der Fürstlichen Abtei und einen Einblick in unsere Familiengeschichte einladen.
<G-vec00272-001-s317><invite.einladen><en> May I invite you to a little visit of the property of the Princely Abbey and also to a short insight into our ancestral history.
<G-vec00272-001-s318><invite.einladen><de> Wir sind eine Interessengemeinschaft von Fans dieses Fahrzeugs der Borgward-Gruppe und möchten Sie herzlich einladen, sich von unserer Begeisterung anstecken zu lassen.
<G-vec00272-001-s318><invite.einladen><en> We are a community of interested fans of the vehicle, the Borgward group and would like to invite you to get infected by our enthusiasm.
<G-vec00272-001-s319><invite.einladen><de> Es ist die größte internationale Messe für Maschinen, Anlagen, Verfahren und Rohstoffe für die Keramikindustrie und die Pulvermetallurgie zu der wir Sie herzlich zu einem Besuch auf unserem Stand 100 in der Halle A2 einladen möchten.
<G-vec00272-001-s319><invite.einladen><en> It is the largest international exhibition for machinery, equipment, plants, processes and raw materials for the ceramic industry and powder metallurgy. We would like to invite you to visit us at our booth in hall A2, stand 100.
<G-vec00272-001-s320><invite.einladen><de> Wir möchten Sie recht herzlich einladen, die herrlichen Farben der Natur mit uns zusammen zu genießen.
<G-vec00272-001-s320><invite.einladen><en> We would kindly invite you to enjoy with us the wonderful colors of the nature.
<G-vec00272-001-s321><invite.einladen><de> Wir möchten Sie sehr herzlich zur Eröffnung der ersten Einzelausstellung der österreichischen Künstlerin Carola Dertnig in unserer Galerie in Berlin-Charlottenburg einladen.
<G-vec00272-001-s321><invite.einladen><en> We are very pleased to be able to invite you to the opening of the first solo exhibition in our gallery in Berlin-Charlottenburg of the […]
<G-vec00272-001-s322><invite.einladen><de> Die beste Nachricht ist, dass unser neues Restaurant nicht nur für unsere Hotelgästegeöffnet ist, sondern wir auch Gäste von außerhalb ganz herzlich einladen möchten.
<G-vec00272-001-s322><invite.einladen><en> The best news is that “Jardín del Eden” is not only opened for our hotel guests but also for clients from outside, so we want to invite everybody who likes to pay us a visit.
<G-vec00272-001-s323><invite.einladen><de> Landkarte Wir möchten Sie in unserem Gastfamielienhaus und den Programms in der Nähe herzlich einladen, wo Sie...
<G-vec00272-001-s323><invite.einladen><en> Map We would like to invite you to our guest house and programs around where you and your family can feel...
<G-vec00272-001-s362><invite.einladen><de> Next Generation Zombie Plage einen netten Counter Strike Zombie Pest Server, wo du viel Spaß haben wirst, lade deine Freunde ein, coole Preise zu erhalten.
<G-vec00272-001-s362><invite.einladen><en> Next Generation Zombie Plague a nice counter strike zombie plague server where you will have alots of fun,invite your friends to receive cool awards.
<G-vec00272-001-s363><invite.einladen><de> Ich lade Sie herzlich ein, die Professur Sportgerätetechnik durch einen persönlichen Besuch und über die Informationen auf diesen Seiten näher kennen zu lernen.
<G-vec00272-001-s363><invite.einladen><en> I sincerely invite you to become acquainted with the professorship Sports Engineering by a personal visit or the provided information on this homepage.
<G-vec00272-001-s364><invite.einladen><de> Lade Freunde aus der ganzen Welt auf ein paar Löcher Everybody's Golf ein und vergewissere dich, dass sie die PlayStation Plus-Anforderungen erfüllen.
<G-vec00272-001-s364><invite.einladen><en> Invite friends around the globe to a few holes of Everybody’s Golf and make sure they’re up to par with PlayStation Plus.
<G-vec00272-001-s365><invite.einladen><de> Mit den Worten des heiligen Bernhard lade ich einen jeden ein, vor Maria so vertrauensvoll „Kind“ zu werden, wie Gottes Sohn selbst es getan hat.
<G-vec00272-001-s365><invite.einladen><en> In the words of Saint Bernard, I invite everyone to become a trusting child before Mary, even as the Son of God did.
<G-vec00272-001-s366><invite.einladen><de> """Liebe Kinder, ich lade euch zum Gebet mit dem Herzen ein."
<G-vec00272-001-s366><invite.einladen><en> Dear Children, I invite you to prayer with the heart.
<G-vec00272-001-s367><invite.einladen><de> Ich lade deshalb eure Kongregation ein, mit den anderen Dikasterien der Römischen Kurie, die für die Ausbildung der Seminaristen und des Klerus zuständig sind, zusammenzuarbeiten, damit die notwendigen Maßnahmen ergriffen werden, um sicherzustellen, daß die Kleriker in der Weise leben, die ihrer Berufung und ihrer Verpflichtung zur vollkommenen und dauernden Keuschheit für das Reich Gottes entspricht.
<G-vec00272-001-s367><invite.einladen><en> I therefore invite your Congregation to collaborate with the other Dicasteries of the Roman Curia qualified to form seminarians and the clergy, so that they may adopt the necessary measures to ensure that seminarians live a life in accordance with their vocation and their commitment to perfect and perpetual chastity for the Kingdom of God.
<G-vec00272-001-s368><invite.einladen><de> Ich lade euch heute ein, meine lieben Kinder, Gott für alles, was Er euch gibt, zu danken.
<G-vec00272-001-s368><invite.einladen><en> Today I invite you, little children, to thank God for all that He gives you.
<G-vec00272-001-s369><invite.einladen><de> Lade sie in unsere speziellen privaten Räume ein.
<G-vec00272-001-s369><invite.einladen><en> Invite them to our special private rooms.
<G-vec00272-001-s370><invite.einladen><de> Ich lade dich ein für einen Moment an eine Situation zu denken, in der du über jemanden verärgert, verletzt, traurig oder enttäuscht warst.
<G-vec00272-001-s370><invite.einladen><en> I invite you to contemplate for a moment a situation where you were angry, hurt, sad, or disappointed in someone.
<G-vec00272-001-s371><invite.einladen><de> "Jetzt lade ich jemand ein Gespräch mit den Spezialisten des Krankenhauses zu haben, die die San Gallicano, denn es wird ihr Eifer sein, wie Jugendliche beider Geschlechter in der Altersgruppe zwischen erklären 14 und 16 Jahre kommen mit schweren Infektionen für angenehmen kleinen Dinge zu üben, dass, als bekannt und allgemein bekannt, Es ist nur... ""typisch"" der ""frühen Jugend"", beispielsweise die sogenannte Analverkehr, die so genannte oral sex, die so genannte Beziehungen Gruppe, in der nur einer infizierten Person, die Infektion auf alle zu übertragen, oder der Kontakt des Mundes und der Zunge mit der Scheide und der Analöffnung und so weiter......"
<G-vec00272-001-s371><invite.einladen><en> "Now I invite anyone to chat to the specialists of this hospital, which is the San Gallicano, because it will be their eagerness to explain how teenagers of both sexes in the age group between 14 and the 16 years come with serious infections for practicing pleasant little things that, as known and known,... it is just ""typical"" of the ""early adolescence"", for example the so-called anal intercourse, the so-called oral reports, the so-called relations group where only one person is infected to transmit the infection to all, or the contact of the mouth and tongue with the vagina and the anal orifice and so on......"
<G-vec00272-001-s372><invite.einladen><de> "Gerade das ist der wahre und tiefe Inhalt der Aufrufe Mariens in Medjugorje, der goldene Schlüssel, der uns in die Schätze der Gnade und der himmlischen Freude einführt, die im Herzen des Vaters wohnen, die für die Kinder dieser Zeit vorbereitet sind: ""Auch ich lade euch zum Leben mit Gott und die totale Hingabe an Ihn ein..."
<G-vec00272-001-s372><invite.einladen><en> "This is precisely what Mary's call at Medjugorje is all about. It is the golden key which lets us into the treasures of heavenly grace and joy enclosed in the Father's heart, ready for the children of this time: ""I invite you to a life with God, and to complete surrender to Him..."
<G-vec00272-001-s373><invite.einladen><de> Informiere sie über den Club und lade sie ein.
<G-vec00272-001-s373><invite.einladen><en> Tell them about the club and invite them to it.
<G-vec00272-001-s374><invite.einladen><de> Exzellenz, ich lade Sie ein, die bereitwillige Mitarbeit der Abteilungen der Römischen Kurie zu nutzen, und ich wünsche Ihnen ein gutes Gelingen Ihrer Mission, die herzlichen Beziehungen zwischen dem Sudan und dem Heiligen Stuhl fortzusetzen.
<G-vec00272-001-s374><invite.einladen><en> Your Excellency, I invite you to avail yourself of the willing cooperation of the Departments of the Roman Curia as I wish you every success in your mission to further the cordial relations existing between the Sudan and the Holy See.
<G-vec00272-001-s375><invite.einladen><de> Daher, und zu eurer Belustigung, lade ich euch herzlich ein, die Fragen (sie könnten nicht dümmer sein) zu den Antworten zu erfinden.
<G-vec00272-001-s375><invite.einladen><en> Therefore, and for your amusement, I cordially invite you to invent the questions (they can't be any sillier), to the answers.
<G-vec00272-001-s376><invite.einladen><de> ich lade lieber freunde und familie in mein restaurant ein.
<G-vec00272-001-s376><invite.einladen><en> therefore, i rather invite friends and family to the restaurant.
<G-vec00272-001-s377><invite.einladen><de> Euch alle lade ich ein, seine Größe zu bewundern und zu betrachten, seine Pracht und seine Herrlichkeit.
<G-vec00272-001-s377><invite.einladen><en> I invite you all to marvel at and consider his greatness, his magnificence and glory».
<G-vec00272-001-s378><invite.einladen><de> Lade sie ganz einfach über Whatsapp, Messenger oder SMS ein.
<G-vec00272-001-s378><invite.einladen><en> Invite them easily via WhatsApp, Messenger or SMS.
<G-vec00272-001-s379><invite.einladen><de> Lade Anhänger per Email oder über soziale Medien ein, damit diese deine Live-Daten bei Garmin Connect anzeigen können.
<G-vec00272-001-s379><invite.einladen><en> Invite followers using email or social media, which lets them view your live data on Garmin Connect.
<G-vec00272-001-s380><invite.einladen><de> """Liebe Kinder, heute lade ich euch ein, das Gebet und Fasten mit noch größerer Begeisterung zu erneuern, bis euch das Gebet zur Freude wird."
<G-vec00272-001-s380><invite.einladen><en> Dear Children, Today I invite you to renew prayer and fasting with even more enthusiasm, until prayer becomes joy for you.
<G-vec00272-001-s400><invite.einladen><de> a VIP Tel-Avivian couple: du erhältest ein Doppelticket für eine Aufführung in Tel-Aviv + wir laden dich ein für ein Drink mit uns nach dem Show.
<G-vec00272-001-s400><invite.einladen><en> a VIP Tel-Avivian couple: you will receive a double ticket for the show in Tel-Aviv + we invite you for a drink with us after the show.
<G-vec00272-001-s401><invite.einladen><de> Im Auftrag der Messe Essen GmbH laden wir ausländische Besucher und Aussteller zur Messe Essen ein.
<G-vec00272-001-s401><invite.einladen><en> On behalf of Messe Essen GmbH we invite foreign visitors to Messe Essen.
<G-vec00272-001-s402><invite.einladen><de> Freunde, Kollegen oder größere Gesellschaft laden Sie in die separaten Lounges ein.
<G-vec00272-001-s402><invite.einladen><en> To invite friends, colleagues or larger companies serve separate lounges .
<G-vec00272-001-s403><invite.einladen><de> """Wir laden Sie ein, sich gemeinsam mit uns auf eine unvergessliche Reise zu Ihrer A."
<G-vec00272-001-s403><invite.einladen><en> """We invite you to join us on an unforgettable journey to your personal A. Lange & Söhne watch."
<G-vec00272-001-s404><invite.einladen><de> Weißer Sand und türkisfarbenes Meer laden nicht nur zum Sonnenbaden und Schwimmen, sondern auch zum Träumen ein.
<G-vec00272-001-s404><invite.einladen><en> White sand and turquoise sea invite not only for sunbathing and swimming, but also for dreaming.
<G-vec00272-001-s405><invite.einladen><de> Wir verlängern unsere wärmsten Grüße und laden Sie ein, am Robertson Quay Hotel zu bleiben.
<G-vec00272-001-s405><invite.einladen><en> We extend our warmest greetings and invite you to stay at Robertson Quay Hotel.
<G-vec00272-001-s406><invite.einladen><de> Laden Sie dann Ihre neuen Freunde ein, die Ihnen beibringen so wunderbar zu kochen wie ihre eigenen französischen Großmütter.
<G-vec00272-001-s406><invite.einladen><en> Then invite your new friends over to teach you how to cook as well as their native like their awesome French grandmas.
<G-vec00272-001-s407><invite.einladen><de> Wir laden Sie herzlich ein, sich bei uns am Stand B-280, auf Lateinamerikas größter Industriemesse für Werkzeugmaschinen und Automation, zu informieren.
<G-vec00272-001-s407><invite.einladen><en> We would like to invite you to come and find out more at our booth B-280 at Latin America’s biggest industrial trade show for machine tools and automation.
<G-vec00272-001-s408><invite.einladen><de> Die alten Ägypter laden uns in ein Universum ein, das ganz anders, rätselhafter ist als unsere Welt heute, tief religiös, mit anderen Ordnungen und Regeln, wo es keinen Platz gibt für Persönlichkeit.
<G-vec00272-001-s408><invite.einladen><en> The ancients invite us into a very different and enigmatic universe to our world today. This place is highly religious where other rules and ways applied and these rules and ways did not include personality.
<G-vec00272-001-s409><invite.einladen><de> Zahlreiche Wege schlängeln sich durch die Wälder und Wiesen und laden zu Wanderungen oder Mountainbiketouren ein - zum Beispiel der Sentiero della Pace, der sich im Park auf dem Colle Ossario di S. Stefano befindet.
<G-vec00272-001-s409><invite.einladen><en> Numerous paths meander through the woods and meadows and invite you to hikes or mountain bike tours - for example, the Sentiero della Pace, which is located in the park on the Colle Ossario di S. Stefano.
<G-vec00272-001-s410><invite.einladen><de> Ausgedehnte Nadelwälder und Viehweiden prägen die Landschaft und laden zu kurzen oder ausgedehnten Spaziergängen ein.
<G-vec00272-001-s410><invite.einladen><en> Large pine forests and pastures invite you to go on short or extended hikes.
<G-vec00272-001-s411><invite.einladen><de> In unmittelbarer Nähe laden Skigebiet, Wald, Fluss und See zum skifahren, spielen, wandern und baden ein.
<G-vec00272-001-s411><invite.einladen><en> In immediate proximity, forest, lake and river invite you to come playing, walking and swimming.
<G-vec00272-001-s412><invite.einladen><de> Gemütliche Radwege und teils anspruchsvolle Mountainbike-Routen, in allen Schwierigkeitsgraden und Höhenlagen, laden ein, Natur und Landschaft zu „erfahren“, prickelnde Trails zu meistern, den Körper zu fordern oder einfach nur zu genießen.
<G-vec00272-001-s412><invite.einladen><en> "Comfortable bike paths and sometimes demanding mountain bike trails, at all levels of difficulty and altitudes, invite you to ""experience"" nature and landscape, to master tingling trails, to challenge the body or just to peddle and enjoy."
<G-vec00272-001-s413><invite.einladen><de> Die nahe gelegenen Skigebiete laden zum perfekten Skitag ein.
<G-vec00272-001-s413><invite.einladen><en> The nearby skiing areas invite you to the perfect skiing day.
<G-vec00272-001-s414><invite.einladen><de> Die Wasserfälle des Ötztales, die Ötztaler Ache und der Inn laden ein zum sportlichen Spiel mit dem Wasser.
<G-vec00272-001-s414><invite.einladen><en> The waterfalls of the Ötztal valley, the Ötztal river and the Inn invite you to a sporting game with the water.
<G-vec00272-001-s415><invite.einladen><de> Zehn nordhessische Golfplätze laden ambitionierte Golfer und Golfanfänger ein zu märchenhaftem Golfvergnügen für jeden Anspruch.
<G-vec00272-001-s415><invite.einladen><en> Ten golf courses in northern Hessen invite ambitious and beginner golfers to play against magical backdrops at every level.
<G-vec00272-001-s416><invite.einladen><de> Unzählige Vereine laden zum Breitensport ein, und im Leistungssport gehört die Hauptstadt in vielen Sportarten zur Spitze.
<G-vec00272-001-s416><invite.einladen><en> Countless clubs invite one for recreational sports, and in many types of competitive sports, the capital city belongs to the top.
<G-vec00272-001-s417><invite.einladen><de> Unsere bequemen Loungesessel und Casinobarhocker laden neben der ansprechenden Optik auch zum Verweilen und Ausruhen ein.
<G-vec00272-001-s417><invite.einladen><en> Next to the appealing optics of our comfortable lounge chair and casino bar stools they also invite to linger and relax.
<G-vec00272-001-s418><invite.einladen><de> Wir laden Sie aber in die idyllische Saunalandschaft im Rahmen des alpinen Restaurants Alpska perla oben auf dem Skizentrum Cerkno ein.
<G-vec00272-001-s418><invite.einladen><en> For a special experience we also would like to kindly invite you to our idyllic saunas at the alpine hut Alpska perla at the top of the Skiing centre Cerkno.
<G-vec00272-001-s438><invite.einladen><de> So geht nun hin, und so viele immer ihr finden werdet, ladet zur Hochzeit ein.
<G-vec00272-001-s438><invite.einladen><en> Go therefore, and as many as you find there, invite to the wedding feast.
<G-vec00272-001-s439><invite.einladen><de> Ladet spirituelle Gruppen ein, sich uns anzuschliessen.
<G-vec00272-001-s439><invite.einladen><en> Invite spiritual groups to join us.
<G-vec00272-001-s440><invite.einladen><de> Eingebettet in saftiges Grün, zwischen felsigen Landschaften und tiefen Schluchten bis hin zur Mont Blanc-Kette, ladet Sie die Ardèche ein zur Entdeckung ihrer Gastronomie, ihres Kulturerbes und den atemberaubenden Landschaften.
<G-vec00272-001-s440><invite.einladen><en> In a truly lush green setting, between rocky landscapes and gorges to the foot of the Mont-Blanc range, the Ardèche, the Cevennes and Geneva Lake region invite you to discover gastronomy, heritage and breathtaking scenery.
<G-vec00272-001-s441><invite.einladen><de> Jedes Mal wenn ihr ein Ereignis bezeugt, dass einen Aspekt von Dysfunktionalität ausdrückt, ruft diese himmlischen Energien an und ladet sie ein das was passiert anzuheben und zu transmutieren.
<G-vec00272-001-s441><invite.einladen><en> Each time you witness an event that expresses some aspect of dysfunction, call upon and invite these celestial energies to uplift and transmute what is occurring.
<G-vec00272-001-s442><invite.einladen><de> Sag ihnen eure Einschreibegebühren sind am Kreuz völlig bezahlt worden und ladet sie ein um sich der Eucharistischen Universität der göttlichen Liebe anzuschließen.
<G-vec00272-001-s442><invite.einladen><en> Tell them your enrolment fees have been paid in full on the Cross and invite them to join you at the Eucharistic University of Divine Love.
<G-vec00272-001-s443><invite.einladen><de> Ladet auch weitere Organisationen der Bergleute, ihrer Familien und der Bevölkerung aus den Bergbauregionen ein: Frauenorganisationen, Umweltorganisationen etc.
<G-vec00272-001-s443><invite.einladen><en> Invite more organizations of the miners, their families and from the population in the mining regions: women's organizations, environmental organizations, etc.
<G-vec00272-001-s444><invite.einladen><de> Seid der Einladende dieser göttlichen Präsenz und ladet den göttlichen Spirit in all seiner Großartigkeit ein, sich mit euch in dem Transformieren und Heilen von allem was vor euch ist zu verbinden.
<G-vec00272-001-s444><invite.einladen><en> Be the inviter of this divine presence and invite divine spirit in all its magnificence to join you in the transformation and healing of all that is before you.
<G-vec00272-001-s445><invite.einladen><de> Ladet sie ein, darüber nachzudenken, ob dies ihre Berufung sein mag.
<G-vec00272-001-s445><invite.einladen><en> Invite them to consider whether this may be their vocation.
<G-vec00272-001-s446><invite.einladen><de> Es ist die nächste Stufe von euch, die eine neue Zukunft erschafft, also ladet euch selbst ein jenen zu vergeben, die in der Vergangenheit Schmerz, Scham, Zorn oder Schuld in euch ausgelöst haben.
<G-vec00272-001-s446><invite.einladen><en> It is the next stage of you creating a new future so invite yourself to forgive those who in the past triggered pain, shame, anger or blame in you.
<G-vec00272-001-s447><invite.einladen><de> Ladet dieses Wort ein euch zu umhüllen und euch in einer Decke von Licht einzuwickeln, sicher in euch selbst und all den kleinen Stellen eures Körpers.
<G-vec00272-001-s447><invite.einladen><en> Invite this word to envelop you and wrap you in a blanket of light, secure in yourselves and all the little places of your body.
<G-vec00272-001-s448><invite.einladen><de> Jeder Interessierte ist willkommen, also ladet auch eure Freunde und Business-Kontakte zum gemeinsamen Networking ein.
<G-vec00272-001-s448><invite.einladen><en> Everyone is welcome, so invite your friends and business contacts to network together.
<G-vec00272-001-s449><invite.einladen><de> Ladet Freunde ein, um mit euch an der ruhigen Küste zu entspannen oder begleicht mit euren Feinden offene Rechnungen, wenn ihr in ausgewiesenen Kampfbereichen eure eigenen Frei-für-Alle-PvP-Kämpfe veranstaltet.
<G-vec00272-001-s449><invite.einladen><en> Invite friends to relax with you along the serene coastline or settle scores with opponents as you host your own Free-For-All PvP face-offs in designated battle areas.
<G-vec00272-001-s450><invite.einladen><de> Ruft im Geiste die Meister an und ladet sie ein, in eine tiefere persönliche Beziehung einzutreten.
<G-vec00272-001-s450><invite.einladen><en> Mentally call on the Masters and invite them to join into a deeper personal relationship.
<G-vec00272-001-s451><invite.einladen><de> Außerdem ladet ihr zu allen Veranstaltungen auch Gäste ein, die nicht aus dem Kunstbetrieb stammen.
<G-vec00272-001-s451><invite.einladen><en> Also, you invite guests to all of your events who are not from the art trade.
<G-vec00272-001-s452><invite.einladen><de> Ladet mich ein, euch mit Energie zu erfüllen, und ich werde antworten.
<G-vec00272-001-s452><invite.einladen><en> Invite me to infuse you with energy and I will respond.
<G-vec00272-001-s453><invite.einladen><de> So geht nun hin auf die Kreuzwege der Landstraßen, und so viele immer ihr finden werdet, ladet zur Hochzeit ein.
<G-vec00272-001-s453><invite.einladen><en> Go therefore to the main highways, and as many as you find there, invite to the wedding feast.
<G-vec00272-001-s454><invite.einladen><de> Ladet einen Freund für Multiplayer ein.
<G-vec00272-001-s454><invite.einladen><en> Invite a friend to play with you.
<G-vec00272-001-s455><invite.einladen><de> Geht an die Wegkreuzungen, die Straßenkreuzungen und ladet alle ein, die Guten und die Schlechten.
<G-vec00272-001-s455><invite.einladen><en> No! He says to go to the byways and invite all people, good and bad alike.
<G-vec00272-001-s475><invite.einladen><de> Mit beheiztem Pool mit Canyon, Wasserfall, Sauna, Solarium und ruhigen Behandlungsräumen, die im asiatischen Stil eingerichtet sind, lädt er zum Entspannen und Verweilen ein.
<G-vec00272-001-s475><invite.einladen><en> A heated pool with canyon, waterfall, sauna, solarium and quiet rooms of treatment furnished in the Asian style invite for staying and relaxing.
<G-vec00272-001-s476><invite.einladen><de> Die wunderschöne Umgebung lädt Sie zu schönen Wanderungen oder anderen Aktivitäten in der schönen Natur ein.
<G-vec00272-001-s476><invite.einladen><en> The gorgeous area invite you to enjoy beautiful hikes or to be otherwise active in the beautiful natural surroundings.
<G-vec00272-001-s477><invite.einladen><de> "Hinter dem Namen Selwyn verbirgt sich House selbst; offenbar konnte er der Versuchung nicht widerstehen, dem Leser einen Hinweis auf seine Identität zu vermitteln, denn ""Selwyn"" lädt den Mann, den er zum Marionettenpräsidenten auserkoren hat, ein, ""in meinen Gemächern im Mandell House zu Abend zu essen""."
<G-vec00272-001-s477><invite.einladen><en> "Apparently he could not resist the temptation to give a clue to his identity, and he caused ""Selwyn"" to invite the man he selected as his puppet-president (""Selwyn seeks a Candidate"") to ""dine with me in my rooms at the Mandell House ."""
<G-vec00272-001-s478><invite.einladen><de> Er lädt sie ein, mit ihm zu spielen und eskortiert sie danach zurück zum Tor, wünscht ihnen einen guten Tag und kommt in würdiger Einsamkeit zurück.
<G-vec00272-001-s478><invite.einladen><en> He will invite them in to play with him, when he has had enough he will escort them to the gate, wish them a very good day and stroll off in dignified solitude.
<G-vec00272-001-s479><invite.einladen><de> Die grüne Umgebung lädt zu ausgedehnten Spaziergängen ein.
<G-vec00272-001-s479><invite.einladen><en> The green surroundings invite you to take long walks.
<G-vec00272-001-s480><invite.einladen><de> Am Abend lädt Sie Ihr Reiseleiter zu einem geführten Spaziergang durch Paleochora ein, bevor Sie den Abend mit einem individuellen Abendessen in einer lokalen Taverne ausklingen lassen können.
<G-vec00272-001-s480><invite.einladen><en> In the evening our tour guide will invite us to join a guided tour through Paleochora before we end our evening with dinner at a local tavern.
<G-vec00272-001-s481><invite.einladen><de> Die Treppe vor dem Geschäft lädt zu einer Verschnaufpause ein.
<G-vec00272-001-s481><invite.einladen><en> The stairs in front of the shop invite you to take some respite.
<G-vec00272-001-s482><invite.einladen><de> Das Quartier-Zukunft-Mobil in den Straßen und auf den Plätzen der Oststadt entdecken: Das Quartier Zukunft Team lädt bei Kaffee und Tee zum Austausch über die nachhaltige Entwicklung der Oststadt ein.
<G-vec00272-001-s482><invite.einladen><en> The Sustainable Quarter van can be found in the streets and squares of the Karlsruhe East End: The Sustainable Quarter Team, over a cup of coffee or tea, invite people to exchange ideas about the sustainable development of the Karlsruhe East End.
<G-vec00272-001-s483><invite.einladen><de> Das Hotel Bremon, bei 19 Zimmer, lädt Sie ein, um die Uhr zu stoppen und Frieden leben, Gelassenheit und Gastfreundschaft, die verstecken sich hinter ihren alten Mauern.
<G-vec00272-001-s483><invite.einladen><en> The Bremon Hotel, offers 19 rooms, which invite you to stop the clock to breathe in peace and serenity, Its hospitality is hidden behind its old walls of the hotel.
<G-vec00272-001-s484><invite.einladen><de> Im Gegenteil: Die geschmackvolle Ausstattung mit Klimaanlage, TV und Bordbibliothek lädt zum entspannten Verweilen ein.
<G-vec00272-001-s484><invite.einladen><en> On the contrary, the tasteful decor with air conditioning, TV and a library on board will truly invite you to relax and enjoy your leisure time.
<G-vec00272-001-s485><invite.einladen><de> Die wunderschöne Umgebung lädt Sie zum joggen, radfahren und andere Sportarten ein.
<G-vec00272-001-s485><invite.einladen><en> The surroundings are beautiful and invite you to practice different kinds of sports like cycling, or jogging.
<G-vec00272-001-s486><invite.einladen><de> Es ist eine emotionale Angelegenheit: Bei sonnigem Wetter lädt man Freunde zu einer leckeren Mahlzeit ein.
<G-vec00272-001-s486><invite.einladen><en> """It is an emotional event: when it's sunny weather, people invite friends over for a tasty meal."
<G-vec00272-001-s487><invite.einladen><de> Mit Fotos hat FleuraMetz der Blume des Monats einen eigenen Twist gegeben und lädt Sie ein, das gleiche in Kreationen zu machen.
<G-vec00272-001-s487><invite.einladen><en> These photos are FleuraMetz’ take on the Flower of the Month campaign and we invite you to do same with your personal designs.
<G-vec00272-001-s488><invite.einladen><de> PLASMAIT baut derzeit einen Plasma-Glühanlage für Edelstahllitzen und –kabel von einem Gesamtdurchmesserbereich von 0.1 mm – 3.5 mm und lädt sie ein, diese Linie bei sich in März 2014 zu besichtigen (bitte finden Sie anbei das entsprechende Linielayout).
<G-vec00272-001-s488><invite.einladen><en> PLASMAIT is currently building one PlasmaANNEALER for stainless steel strands and ropes with total diameter range 0.1 mm – 3.5 mm and will be very pleased to invite you to see this line at its facility in March 2014 (please find attached the layout of the line).
<G-vec00272-001-s489><invite.einladen><de> Der Besitzer des Weinbergs lädt die Arbeiter ein auf seinem Weinberg zu arbeiten.
<G-vec00272-001-s489><invite.einladen><en> T he ownerof the vineyard invite for the workers for the working in his vineyard .
<G-vec00272-001-s490><invite.einladen><de> Auf einer Gesamtfläche von 45.000 m2 lädt das Einkaufszentrum mit 130 Läden zum Shoppen und Verweilen ein.
<G-vec00272-001-s490><invite.einladen><en> The 130 shops spread across a total area of 45,000 mÂ2 invite you to do some shopping and browsing.
<G-vec00272-001-s491><invite.einladen><de> Mit dem Dekor Casale Blu lädt Villeroy & Boch auf eine Reise in das historische Italien ein.
<G-vec00272-001-s491><invite.einladen><en> Decorations of the Villeroy & Boch collection Casale Blu invite to take a fascinating trip to historic Italy.
<G-vec00272-001-s492><invite.einladen><de> Das ist ungewöhnlich, bietet aber auch Chancen: Unser modulares Konzept „Auf der Flucht: Wieso, woher, was nun?“ lädt mit seinen sieben Bausteinen die Teilnehmenden ein nachzufragen, Ideen zu entwickeln und zu diskutieren.
<G-vec00272-001-s492><invite.einladen><en> An unusual situation, albeit one that offers opportunities: our project „On the run – why, where from, now what?“ is made up of seven modules designed to invite participants to ask questions, develop ideas and engage in discussions.
<G-vec00272-001-s493><invite.einladen><de> Die TUM lädt jedes Jahr zwei Schüler aus Singapur nach Deutschland ein.
<G-vec00272-001-s493><invite.einladen><en> Each year, TUM will invite two schoolchildren from Singapore to Germany.
<G-vec00272-001-s532><invite.einladen><de> Als kommerzielles Zentrum für das umliegende Tal und das Hinterland zur Sierra Madre Occidental (Anbau von Bohnen, Äpfeln, Quitten sowie Aufzucht von Rindern und Pferden) bietet die Stadt auch viele kleine Läden und Manufakturen, die zum Besuch und auch zu einem Einkauf einladen.
<G-vec00272-001-s532><invite.einladen><en> Since Jerez is a commercial center for the surrounding valley and the hinterland in the Sierra Madre Occidental (cultivation of beans, apples and quinces, and elevation of cattle and horses), the small town also offers many small shops and factories, which invite the visitor to shop or just look around.
<G-vec00272-001-s533><invite.einladen><de> Sobald ihr alle angelernten Informationen, die in euch hinein gestopft sind, los lassen könnt, sobald ihr den eingetretenen inneren Dialog, der in eurem Kopf herum flitzt, zum Verstummen bringen könnt, könnt ihr euer Herz und euren Körper einladen, zu reden, und dann beginnt ihr, auf das zu hören, was sie euch sagen, und dann werdet ihr euch in die Höhe schwingen.
<G-vec00272-001-s533><invite.einladen><en> When you can let go of all the learned information stuffed into you, when you can silence the memorized interior dialog that whisks around in your head, then you can invite your heart and body to speak, and then you can begin to listen to what they tell you, and then you will soar.
<G-vec00272-001-s534><invite.einladen><de> Einem entspannten Aufenthalt, in frisch renovierten Zimmern abgerundet mit den kulinarischen Highlights, die zum Verwöhnen einladen, steht nichts mehr im Wege.
<G-vec00272-001-s534><invite.einladen><en> Nothing to stop a relaxed stay in freshly-renovated rooms and culinary highlights which invite you to spoil yourself.
<G-vec00272-001-s535><invite.einladen><de> Auch hier mag dein Pferd dich vielleicht zum Schwimmen im Meer in der Abendsonne einladen.
<G-vec00272-001-s535><invite.einladen><en> Also here the horse might invite you for a sunset swim.
<G-vec00272-001-s536><invite.einladen><de> Interessant gestaltete Kletterstrukturen, unter Berücksichtigung der Altersstruktur, können sowohl zur Bewegung animieren, als auch zum Verweilen auf hochgelegenen Plattformen einladen.
<G-vec00272-001-s536><invite.einladen><en> Interestingly-designed climbing structures, in consideration of the age structure, can encourage both exercise, and also invite rest on the higher platforms.
<G-vec00272-001-s537><invite.einladen><de> Die historische Mädler-Passage beherbergt ihn und darüber hinaus zahllose Geschäfte und Boutiquen, die zum Weihnachtsbummel einladen.
<G-vec00272-001-s537><invite.einladen><en> The historic Mädler Arcade is home to it and countless other shops and boutiques that invite you to stroll around at Christmas.
<G-vec00272-001-s538><invite.einladen><de> Unsere Ausmalbilder zum Thema „Mode Model Fashion“ unterstützen dieses Hobby, indem wir den Kindern Malvorlagen an die Hand geben, die zum Selbstgestalten einladen.
<G-vec00272-001-s538><invite.einladen><en> "Our coloring pages on ""Fashion Model Fashion"" support this hobby by giving children coloring pages that invite them to make their own designs."
<G-vec00272-001-s539><invite.einladen><de> Der Wagen ist mit den geläufigen Noppen versehen, die zum Bau mit Bausteinen einladen.
<G-vec00272-001-s539><invite.einladen><en> The car is provided with common pegs that invite building with building blocks.
<G-vec00272-001-s540><invite.einladen><de> Zwei Beine, die strampeln, zwei Räder, die rollen – und ein einzigartig schönes Land, dessen stille Wege durch Wälder und Felder, Dörfer und Städte führen, wo sie zum Entdecken und Verweilen einladen.
<G-vec00272-001-s540><invite.einladen><en> Two legs pushing, two wheels rolling – and a uniquely beautiful land whose peaceful paths lead through forests and fields, through villages and towns, which invite cyclists to linger a while and explore.
<G-vec00272-001-s541><invite.einladen><de> Kursteilnehmer zum Lernen einladen.
<G-vec00272-001-s541><invite.einladen><en> Invite course participants.
<G-vec00272-001-s542><invite.einladen><de> Menja Stevenson hat im Rahmen eines Workshops mit den Mitarbeitern und Mitarbeiterinnen des SG Stern handgeformte Klettergriffe entwickelt, die nun, in farbiger Keramik gegossen, zum sportlichen Erklimmen der Bürowand einladen.
<G-vec00272-001-s542><invite.einladen><en> Menja Stevenson has developed hand-molded climbing holds in a workshop with the staff of the SG Stern, which now, cast in colored ceramics, invite them to climb the office wall in a sporty way.
<G-vec00272-001-s543><invite.einladen><de> Während die Causeways und Pop-up Stools zum gemeinsamen Brainstormen und Pausieren einladen, kann man sich in den akustisch etwas abgeschotteten Wing Chairs in aller Stille zurückziehen.
<G-vec00272-001-s543><invite.einladen><en> The Causeways and Pop-up stools invite group brainstorming sessions or breaks, while the Wing Chairs offer peace and quiet with acoustic privacy.
<G-vec00272-001-s544><invite.einladen><de> Wer eine kleine Pause braucht findet im Skigebiet St. Johann im Pongau - Alpendorf zahlreiche Hütten und Restaurants welche zum gemütlichen Einkehrschwung einladen.
<G-vec00272-001-s544><invite.einladen><en> If you need a little break, you will find lots of huts and restaurants in the ski resort St. Johann im Pongau - Alpendorf, which invite you for a stopover.
<G-vec00272-001-s545><invite.einladen><de> Der Dialog sollte auch Menschen zum interreligiösen Gespräch einladen, die sich nicht zu einer Offenbarung bekennen.
<G-vec00272-001-s545><invite.einladen><en> Interreligious dialogue should also invite people who do not profess their faith in revelation.
<G-vec00272-001-s546><invite.einladen><de> 35 Unternehmen, darunter die Berliner Wasserbetriebe, die Naturschutzjugend Brandenburg, WWF Deutschland, die GrÃ1⁄4ne Liga, das Ökowerk Berlin und der Deutsche Wetterdienst bieten Kindern, Jugendlichen und Erwachsenen interaktive Angebote, die zum Mitmachen, Informieren und Engagieren einladen.
<G-vec00272-001-s546><invite.einladen><en> 35 companies, including Berliner Wasserbetriebe, Naturschutzjugend Brandenburg, WWF Deutschland, GrÃ1⁄4ne Liga, Ökowerk Berlin and Deutsche Wetterdienst will be offering children, young people and adults interactive events which invite them to take part, find out more and get involved. Press contacts:
<G-vec00272-001-s547><invite.einladen><de> Während die Causeways und Pop-up Stools zum gemeinsamen Brainstormen und Pausieren einladen, kann man sich in den akustisch etwas abgeschotteten Wing Chairs in aller Stille zurückziehen.
<G-vec00272-001-s547><invite.einladen><en> While the Causeways and Pop-up Stools invite collaborative brainstorming and breaks in the day, people can also retreat into the peacefulness of the Wing Chairs with their acoustic and visual privacy.
<G-vec00272-001-s548><invite.einladen><de> Zum Parteitag kann das Zentralkomitee Gastdelegierte ohne Stimmrecht einladen.
<G-vec00272-001-s548><invite.einladen><en> The CC can invite guest delegates who do not have the right to vote.
<G-vec00272-001-s549><invite.einladen><de> Auch in entgegen gesetzter Richtung gibt es Strandabschnitte, die nicht nur zum Baden in der Neuen Donau einladen, wie wir wenig später sehen sollten, denn erste Besucher betätigten sich sportlich aktiv in einer Wasserskiliftanlage.
<G-vec00272-001-s549><invite.einladen><en> Also in the opposite direction there are beach sections, which not only invite you to bathe in the New Danube, as we should see a little later, because first visitors were active in a water skiing facility.
<G-vec00272-001-s550><invite.einladen><de> 49 Unternehmen, darunter die Berliner Wasserbetriebe, die Naturschutzjugend Brandenburg, Greenpeace Deutschland, die Grüne Liga, das Ökowerk Berlin und der Deutsche Wetterdienst bieten Kindern, Jugendlichen und Erwachsenen interaktive Angebote, die zum Mitmachen, Informieren und Engagieren einladen.
<G-vec00272-001-s550><invite.einladen><en> 49 companies, including Berliner Wasserbetriebe, Naturschutzjugend Brandenburg, Greenpeace Germany, Grüne Liga, Ökowerk Berlin and Deutsche Wetterdienst will be offering children, young people and adults interactive events which invite them to take part, find out more and get involved.
