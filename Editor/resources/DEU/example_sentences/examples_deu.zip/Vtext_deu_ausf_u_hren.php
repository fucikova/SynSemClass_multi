<G-vec00179-001-s019><run.ausführen><de> Eine kostenlose 30-Tage Testversion von Office 2010 kann innerhalb von 180 Tagen verwendet werden, wenn die Datei ausführen aus einem Ordner ospprearm.exe Common Files.
<G-vec00179-001-s019><run.ausführen><en> A free 30-day trial version of Office 2010 can be used within 180 days if run the file from a folder ospprearm.exe Common Files.
<G-vec00179-001-s020><run.ausführen><de> Zum Ausführen Ihres Prozesses benötigen Sie mehr als eine Pumpe und ein Abgasmanagementgerät.
<G-vec00179-001-s020><run.ausführen><en> With just a pump and a gas abatement device, you still are not ready to run your process.
<G-vec00179-001-s021><run.ausführen><de> Wenn Sie benutzerdefinierte Befehle ausführen müssen, um den PC in den Bereitschafsmodus zu versetzen oder daraus aufzuwecken, sollten Sie ihre Skripte in /etc/pm/sleep.d platzieren.
<G-vec00179-001-s021><run.ausführen><en> If you need to run custom commands when suspending/resuming, you should place your custom scripts to /etc/pm/sleep.d.
<G-vec00179-001-s022><run.ausführen><de> Diese Standardaktion wird nach einer geplanten Sicherung ausgeführt oder wenn Sie eine Sicherung manuell aus dem Aufgabenbereich ausführen.
<G-vec00179-001-s022><run.ausführen><en> This default action is executed after a scheduled backup or if you run a backup manually from the task pane.
<G-vec00179-001-s023><run.ausführen><de> Öffnen Sie zum Ausführen von ipconfig die Eingabeaufforderung, und geben Sie dann ipconfig ein .
<G-vec00179-001-s023><run.ausführen><en> To run ipconfig, open the command prompt, and then type ipconfig .
<G-vec00179-001-s024><run.ausführen><de> Klicken Sie zum Öffnen von Ldp auf Start, klicken Sie auf Ausführen, geben Sie ldp ein, und klicken Sie dann auf OK.
<G-vec00179-001-s024><run.ausführen><en> To open Ldp, click Start, click Run, type ldp, and then click OK.
<G-vec00179-001-s025><run.ausführen><de> Der Ordner args enthält Konfigurationsdateien mit den Argumenten, die zum Ausführen der Scripts erforderlich sind.
<G-vec00179-001-s025><run.ausführen><en> The args folder contains a set of configuration files which contain the arguments that are required to run the scripts.
<G-vec00179-001-s026><run.ausführen><de> Öffnen Sie die Microsoft Management Console, indem Sie in der Ausführen -Konsole den Befehl mmc eingeben und auf OK klicken.
<G-vec00179-001-s026><run.ausführen><en> "Open Microsoft Management Console by opening the Run console and typing the "" mmc "" into the field and clicking OK ."
<G-vec00179-001-s027><run.ausführen><de> Werden Sie sicher, dass, wenn Sie eine freie Casino Bonus code von Drake casino, wie Sie wissen, mit Pfeile Edge und Bet Soft casinos ausführen, müssen Sie der post eine Einzahlung zwischen free-casino-Promotionen.
<G-vec00179-001-s027><run.ausführen><en> Be sure when you use a free Casino Bonus code from Drake casino as you know with Arrows Edge and Bet Soft run casinos, you have to post a deposit between free casino promotions.
<G-vec00179-001-s028><run.ausführen><de> « Zurück Tool finden und ausführen...
<G-vec00179-001-s028><run.ausführen><en> « Previous Find and run a utility...
<G-vec00179-001-s029><run.ausführen><de> Werden Sie sicher, dass, wenn Sie eine Ohne Einzahlung Casino bonus-code von Noxwin wie bei den meisten Net Entertainment, Microgaming, IGT und 1X2 Gaming casinos ausführen, müssen Sie die post eine Einzahlung zwischen free-casino-Promotionen.
<G-vec00179-001-s029><run.ausführen><en> Be sure when you use a No Deposit Casino bonus code from Noxwin as with most Net Entertainment, Microgaming, IGT and 1X2 Gaming run casinos, you must post a deposit between free casino promotions.
<G-vec00179-001-s030><run.ausführen><de> Sie müssen Nfsadmin.exe an einer Eingabeaufforderung mit erhöhten Rechten ausführen, um Konfigurationseinstellungen von Client für NFS zu ändern.
<G-vec00179-001-s030><run.ausführen><en> You must run Nfsadmin.exe from an elevated privilege command prompt to change Client for NFS configuration settings.
<G-vec00179-001-s031><run.ausführen><de> Wurde in den Active Directory Einstellungen die Option LDAP Suche direkt ausführen gewählt, so wird bei der Suche keine Baumstruktur angezeigt.
<G-vec00179-001-s031><run.ausführen><en> If the option Run LDAP search directly is enabled in the Active Directory Settings, the tree structure won´t be displayed.
<G-vec00179-001-s032><run.ausführen><de> Sie müssen über genügend Arbeitsspeicher zum Ausführen des 64-Bit-Hostbetriebssystems verfügen sowie über den zusätzlich erforderlichen Arbeitsspeicher für jedes Gastbetriebssystem und für Anwendungen auf Host- und Gastsystem.
<G-vec00179-001-s032><run.ausführen><en> You must have enough memory to run the 64-bit host operating system, plus the memory required for each guest operating system and for applications on the host and guest.
<G-vec00179-001-s033><run.ausführen><de> • Mit Verzeichnisserver synchronisieren - Sie können den Task Synchronisierung statischer Gruppen ausführen.
<G-vec00179-001-s033><run.ausführen><en> • Synchronize via directory server - You can run Static Group Synchronization task.
<G-vec00179-001-s034><run.ausführen><de> "-Im ""D-Fend Reloaded"" Hauptfenster das Profil GP2 rechtsklicken und ""Setup ausführen"" klicken."
<G-vec00179-001-s034><run.ausführen><en> "-In the ""D-Fend Reloaded"" main window, right-click on the GP2 profile and click ""Run Setup"""
<G-vec00179-001-s035><run.ausführen><de> Mini Sports Challenge Online-Spiel Ausführen, schweben, schwimmen und paddeln in 4 anderen Wettbewerben in diesem amüsanten Sport Erholung.
<G-vec00179-001-s035><run.ausführen><en> Mini Sports Challenge online game Run, soar, swim and paddle in 4 other competitions in this amusing sports activities recreation.
<G-vec00179-001-s036><run.ausführen><de> "Wählen Sie einfach eine Webseite oder Liste, klicken Sie auf die Schaltfläche ""Ausführen"", und Sie haben alle Berechtigungen auf einer Seite aufgelistet."
<G-vec00179-001-s036><run.ausführen><en> Just select a site or list, click the “Run” button and you have all the permissions listed on one page.
<G-vec00179-001-s037><run.ausführen><de> Während Sie früher den Antivirusscan manuell ausführen mussten, können Sie bei den meisten heutigen Antivirenprogrammen automatische Scans aktivieren und einen für Sie optimalen Scan-Zeitplan einrichten.
<G-vec00179-001-s037><run.ausführen><en> Whereas once you had to run antivirus scans manually, most of today’s antivirus programs allow you to enable automatic scans and set up a scan schedule that best works for you.
<G-vec00179-001-s057><run.ausführen><de> Die einzige Voraussetzung ist, dass die LPAR, in der installiert (oder z/VM ausgeführt) werden soll, auf die Bandeinheit zugreifen darf.
<G-vec00179-001-s057><run.ausführen><en> The only prerequisite is that the LPAR in which to install (or allowing z/VM to run) is allowed to access the tape unit.
<G-vec00179-001-s058><run.ausführen><de> Es wird ausgeführt und betrieben von Störchen.
<G-vec00179-001-s058><run.ausführen><en> It is run and operated by storks.
<G-vec00179-001-s059><run.ausführen><de> Jedoch bei der Installation Wincheck auf dem System führt es bestimmte Änderungen, mit denen es automatisch ausgeführt, wenn Sie Ihren Computer einschalten.
<G-vec00179-001-s059><run.ausführen><en> However, when you install Wincheck on the system, it performs particular changes that allow it to run automatically whenever you turn on your computer.
<G-vec00179-001-s060><run.ausführen><de> Skripte und Apps werden schneller als bei anderen von mir getesteten Hosting-Anbietern ausgeführt.
<G-vec00179-001-s060><run.ausführen><en> Scripts and apps run faster than other hosting services that I have used.
<G-vec00179-001-s061><run.ausführen><de> Es hat einen guten Teil, Da die Spiele in geringer Auflösung und Geschwindigkeit der apps besser ausgeführt werden, werden besser sein..
<G-vec00179-001-s061><run.ausführen><en> It has a good part, because the games will run better in low resolution and speed of the apps will be better.
<G-vec00179-001-s062><run.ausführen><de> PPP und Rechte Der Befehl ppp muss normalerweise als root ausgeführt werden.
<G-vec00179-001-s062><run.ausführen><en> The ppp command must normally be run as the root user.
<G-vec00179-001-s063><run.ausführen><de> Ich habe auch ein paar Tests von virtuellen Maschinen auf diesem System, aber sie sind nicht so konfiguriert, dass beim Booten ausgeführt.
<G-vec00179-001-s063><run.ausführen><en> I also have a few testing Virtual Machines on this system, but they are not configured to run at boot.
<G-vec00179-001-s064><run.ausführen><de> Betway kann auf den Samsung Galaxy S-Serien, Galaxy J3 und J5, Galaxy A3 und Galaxy Note ab Version 6 ausgeführt werden.
<G-vec00179-001-s064><run.ausführen><en> Betway can run on Samsung's Galaxy S series, Galaxy J3 and J5, Galaxy A3, and Galaxy Note from 6 and so on.
<G-vec00179-001-s065><run.ausführen><de> Die Netzwerk-Performance ist wichtig für geschäftskritische Anwendungen und Unified Communications – besonders, wenn Anwendungen in der Cloud ausgeführt werden.
<G-vec00179-001-s065><run.ausführen><en> Network performance is important for business-critical applications and unified communications–especially when applications run in the cloud.
<G-vec00179-001-s066><run.ausführen><de> Alle Anwendungen auf dem Server Windows 2000/2003 Server ausgeführt werden (manchmal ist es verwendet Windows XP), mit seinem Speicher und Prozessor.
<G-vec00179-001-s066><run.ausführen><en> All applications run on the server Windows 2000/2003 Server (sometimes it uses Windows XP), using its memory and processor.
<G-vec00179-001-s067><run.ausführen><de> Einsatzfaktoren können die Materialien, Personen, Maschinen, IT Systeme, Informationen oder irgendetwas anderes umfassen, das für den Prozess ausgeführt wird.
<G-vec00179-001-s067><run.ausführen><en> Inputs can include materials, people, machines, IT systems, information, or anything else that is necessary for the process to run.
<G-vec00179-001-s068><run.ausführen><de> SUSE Linux Enterprise unterstützt eine Reihe von Hardware-Architekturen, mit denen Sie Ihre eigenen Anwendungen anpassen können, die auf SUSE Linux Enterprise ausgeführt werden sollen.
<G-vec00179-001-s068><run.ausführen><en> SUSE Linux Enterprise supports a number of hardware architectures and you can use this to adapt your own applications to run on SUSE Linux Enterprise.
<G-vec00179-001-s069><run.ausführen><de> Es gibt mehrere verschiedene Möglichkeiten, in denen Sie einen Winstrol Zyklus ausgeführt werden können, können Sie entweder verwenden Winstrol allein oder mit anderen Steroid-Stacks als Stapel Pillen integriert.
<G-vec00179-001-s069><run.ausführen><en> There are several various ways in which you can run a Winstrol cycle, you could either use Winstrol alone or integrated with other steroid stacks as stacking pills.
<G-vec00179-001-s070><run.ausführen><de> • Baldmöglichst - Der Task wird baldmöglichst ausgeführt, d. h. wenn die Aktionen, die seine Ausführung ursprünglich behinderten, nicht länger gegeben sind.
<G-vec00179-001-s070><run.ausführen><en> • As soon as possible - The task will run as soon as possible, when the actions that prevent the task from executing are no longer valid.
<G-vec00179-001-s071><run.ausführen><de> verdienen money.today empfehlen die kostenlose Anwendung MetaTrader, die bei den meisten Systemen ausgeführt.
<G-vec00179-001-s071><run.ausführen><en> earn-money.today recommend the free application MetaTrader, which run at most systems.
<G-vec00179-001-s072><run.ausführen><de> Jacket ist eine GPU-Engine für MATLAB, der Code, um von Matlab NVidia GPU unterstützt CUDA ausgeführt werden können.
<G-vec00179-001-s072><run.ausführen><en> Jacket is a GPU Engine for MATLAB, which allows the code to run Matlab from NVidia GPUs that support CUDA.
<G-vec00179-001-s073><run.ausführen><de> Unter Admin > Client-Tasks können Sie den Status ausgeführter Tasks abrufen und überprüfen, ob Ihre Tasks erfolgreich ausgeführt wurden.
<G-vec00179-001-s073><run.ausführen><en> To see the status of executed tasks, it is important that you navigate to Admin > Client Tasks and observe whether tasks has been run successfully.
<G-vec00179-001-s074><run.ausführen><de> Bei dem Befehl wird der Befehl mithilfe des AsJob-Parameters als Hintergrundauftrag ausgeführt.
<G-vec00179-001-s074><run.ausführen><en> The command uses the AsJob parameter to run the command as a background job.
<G-vec00179-001-s075><run.ausführen><de> Dies bedeutet auch, dass SDS sowohl auf dem Standardbetriebssystem des Servers als auch in einem virtueller Rechner (VM) ausgeführt werden kann.
<G-vec00179-001-s075><run.ausführen><en> This also means SDS can run both on the server's standard operating system and in a virtual machine (VM).
<G-vec00179-001-s076><run.ausführen><de> Klicken Sie Um den Code auszuführen, wird ein Dialogfeld geöffnet, in dem Sie einen Bereich auswählen können, in den Sie die positiven Werte in negative Werte umwandeln möchten.
<G-vec00179-001-s076><run.ausführen><en> Click button to run the code, a dialog is popped out for you to select a range that you want to convert the posItive values to negative.
<G-vec00179-001-s077><run.ausführen><de> Um in der UNIX-basierten Korn-Shell-Umgebung eine Anwendung auszuführen, die Administratorrechte erfordert, führen Sie die folgenden Schritte durch.
<G-vec00179-001-s077><run.ausführen><en> To run an application in the UNIX-based Korn shell environment that requires administrative privileges, perform the following steps.
<G-vec00179-001-s078><run.ausführen><de> Sie kann von Angreifern ausgenutzt werden, um auf anfälligen Systemen beliebigen Code auszuführen.
<G-vec00179-001-s078><run.ausführen><en> Exploiting it allows remote attackers to run arbitrary code on vulnerable systems.
<G-vec00179-001-s079><run.ausführen><de> Dann, die .KLOPE Ra nsomware Virus kann auch den Run-Registrierungsschlüssel ändert die ausführbare Datei auszuführen(mit) in% AppData% Verzeichnis.
<G-vec00179-001-s079><run.ausführen><en> Then, the .KLOPE Ransomware virus may also modify the Run registry key to run the executable file(s) in the %AppData% directory.
<G-vec00179-001-s080><run.ausführen><de> Drücken Sie F5 Um den Code auszuführen, wird ein Dialogfeld geöffnet, in dem Sie die Anzahl der ausgeblendeten Arbeitsblätter und die Anzahl der sichtbaren Arbeitsblätter angeben können.
<G-vec00179-001-s080><run.ausführen><en> Press F5 key to run the code, and a dialog pops out to tell you the number of hidden worksheets and the number of visible worksheets.
<G-vec00179-001-s081><run.ausführen><de> In manchen Situationen kann es sinnvoll oder notwendig sein, ein opsi-winst/opsi-script Skript als lokal eingeloggter Benutzer auszuführen anstatt wie üblich im Kontext eines Systemdienstes.
<G-vec00179-001-s081><run.ausführen><en> Sometimes it is necessary to run an installation script as an ordinary local user and not in the context of the opsi service.
<G-vec00179-001-s082><run.ausführen><de> Einmal getan, Sie müssen diese Anwendung auszuführen.
<G-vec00179-001-s082><run.ausführen><en> Once done, you need to run this application.
<G-vec00179-001-s083><run.ausführen><de> Sie müssen über Vollzugriff auf eine Anwendungsverzeichnispartition in einer AD LDS-Instanz verfügen, um diesen Befehl auszuführen.
<G-vec00179-001-s083><run.ausführen><en> You must have full control of an application directory partition on an AD LDS instance to run this command.
<G-vec00179-001-s084><run.ausführen><de> Dann, das .boston Virus kann auch den Run-Registrierungsschlüssel ändert die ausführbare Datei auszuführen(mit) in% AppData% Verzeichnis.
<G-vec00179-001-s084><run.ausführen><en> Then, the .boston virus may also modify the Run registry key to run the executable file(s) in the %AppData% directory.
<G-vec00179-001-s085><run.ausführen><de> Dann, die MegaLocker Virus Virus kann auch den Run-Registrierungsschlüssel ändert die ausführbare Datei auszuführen(mit) in% AppData% Verzeichnis.
<G-vec00179-001-s085><run.ausführen><en> Then, the MegaLocker Virus virus may also modify the Run registry key to run the executable file(s) in the %AppData% directory.
<G-vec00179-001-s086><run.ausführen><de> In der Regel wird eine PSSession erstellt, um eine Reihe verwandter Befehle auf einem Remotecomputer auszuführen.
<G-vec00179-001-s086><run.ausführen><en> Typically, you create a PSSession to run a series of related commands on a remote computer.
<G-vec00179-001-s087><run.ausführen><de> Die einfachste Art, lilypond-Skripte auszuführen ist es, eigene „Hilfsskripte“ zu erstellen.
<G-vec00179-001-s087><run.ausführen><en> The most convenient way to run lilypond scripts is by setting up “helper” scripts of your own.
<G-vec00179-001-s088><run.ausführen><de> Um in der Windows-Benutzeroberfläche eine Anwendung auszuführen, die Administratorrechte erfordert, führen Sie die folgenden Schritte durch.
<G-vec00179-001-s088><run.ausführen><en> To run an application in the Windows user interface that requires administrative privileges, perform the following steps.
<G-vec00179-001-s089><run.ausführen><de> Dann, die .codnat Ransomware Virus kann auch den Run-Registrierungsschlüssel ändert die ausführbare Datei auszuführen(mit) in% AppData% Verzeichnis.
<G-vec00179-001-s089><run.ausführen><en> Then, the .codnat Ransomware virus may also modify the Run registry key to run the executable file(s) in the %AppData% directory.
<G-vec00179-001-s090><run.ausführen><de> Schritt 3: Dann drücken F5 Schlüssel, um diesen Code auszuführen, und ein Eingabeaufforderungsfeld wird eingeblendet, um Ihnen zu sagen, dass Sie einen Bereich auswählen sollen, in dem Sie die Datenzellen auswählen möchten.
<G-vec00179-001-s090><run.ausführen><en> Step 3: Then press F5 key to run this code, and a prompt box will pop out to tell you to select a range that you want to select the data cells.
<G-vec00179-001-s091><run.ausführen><de> Im Juli, Drupal, fragte Benutzer, um den patch eine remote-code-execution-Schwachstelle erlaubt Angreifern komplett übernehmen Sie eine website mit speziell gestaltete Anforderungen, beliebigen code auszuführen, und möglicherweise hijack Server.
<G-vec00179-001-s091><run.ausführen><en> In July, Drupal asked users to patch a remote code execution flaw which allowed attackers to completely take over a website using specially crafted requests, run arbitrary code, and potentially hijack servers.
<G-vec00179-001-s092><run.ausführen><de> 16.06.2015 Neu Ein neuer Job Scheduler erleichtert es, Wartungsaufgaben wie Datensicherung, Datenintegritätsprüfung und Index-Neuaufbau regelmäßig auszuführen.
<G-vec00179-001-s092><run.ausführen><en> New A new job scheduler makes it easy to run maintenance tasks such as backup, data integrity check and index rebuild on a regular basis.
<G-vec00179-001-s093><run.ausführen><de> Es ist wichtig, dass niemand wird Ihnen nur ein Teil der benötigten Menge und nicht versetzen Sie in eine unangenehme Lage, wenn es notwendig, mehr Geld zu suchen, um das Projekt auszuführen, und die Anleger auszuzahlen ist.
<G-vec00179-001-s093><run.ausführen><en> It is important that no one will give you only part of the required amount and do not put you in an awkward position when it is necessary to seek more money to run the project and pay off investors.
<G-vec00179-001-s094><run.ausführen><de> Dann, die Kaninchen Ransomware Virus kann auch den Run-Registrierungsschlüssel ändert die ausführbare Datei auszuführen(mit) in% AppData% Verzeichnis.
<G-vec00179-001-s094><run.ausführen><en> Then, the Rabbit Ransomware virus may also modify the Run registry key to run the executable file(s) in the %AppData% directory.
<G-vec00221-002-s076><run.ausführen><de> Dies bedeutet, dass Programme, die mit Tools, wie Embedded Visual C++ oder Visual Studio 2005Appearance, für standardmäßige PC-Betriebssysteme entwickelt wurden, auch ohne großen Portierungsaufwand auf dem IA261-I-T/IA262-I-T ausgeführt werden können.
<G-vec00221-002-s076><run.ausführen><en> This means that programs developed for standard PC operating systems with tools such Embedded Visual C++ or Visual Studio 2005 can run on the IA261/262 without much porting effort.
<G-vec00221-002-s077><run.ausführen><de> Die Anzahl der Ports orientiert sich an der Anzahl der virtuellen Maschinen, die auf dem Host ausgeführt werden können.
<G-vec00221-002-s077><run.ausführen><en> The number of ports is based on the number of virtual machines that the host can run.
<G-vec00221-002-s078><run.ausführen><de> Die Datensicherungs- und Synchronisierungsvorgänge werden jedoch besonders praktisch, wenn Sie das Programm so einstellen, dass sie regelmäßig ausgeführt werden, ohne dass Sie darauf achten oder eingreifen müssen.
<G-vec00221-002-s078><run.ausführen><en> But much of the convenience of backup and synchronization operations is in setting them to run periodically, without your intervention or attention.
<G-vec00221-002-s079><run.ausführen><de> Anwendungen setzen sich üblicherweise aus einzeln in Containern enthaltenen Komponenten (sogenannten Microservices) zusammen, die auf Netzwerkebene organisiert werden müssen, damit die Anwendung in der gewünschten Weise ausgeführt werden kann.
<G-vec00221-002-s079><run.ausführen><en> Applications are typically made up of individually containerised components (often called microservices) that must be organised at the networking level in order for the application to run as intended.
<G-vec00221-002-s080><run.ausführen><de> Container können im Vergleich zu VMs auf einem erheblich kleineren Hostbetriebssystem ausgeführt werden, weil mehr direkt in die Anwendung gepackt wird.
<G-vec00221-002-s080><run.ausführen><en> Containers are meant to run on a much smaller host OS than for a VM, as more is packaged into the application directly.
<G-vec00221-002-s081><run.ausführen><de> Die zweistellige Zahl, die dem »K« oder dem »S« folgt, bestimmt die Reihenfolge, in welcher die Skripte ausgeführt werden.
<G-vec00221-002-s081><run.ausführen><en> The two-digit number following the 'K' or 'S' indicates the order in which the script is run.
<G-vec00221-002-s082><run.ausführen><de> ODBC-Anwendungen können mit jeder Datenquelle ausgeführt werden, die einen ODBC-Treiber bereitstellt.
<G-vec00221-002-s082><run.ausführen><en> ODBC applications can run against any data source that provides an ODBC driver.
<G-vec00221-002-s083><run.ausführen><de> Standardmäßig können installierte und registrierte Add-Ins ohne Benutzereingriff oder Warnung ausgeführt werden.
<G-vec00221-002-s083><run.ausführen><en> By default, installed and registered add-ins can run without requiring user intervention or warning.
<G-vec00221-002-s084><run.ausführen><de> OS-Version (Maximum): Geben Sie optional die neueste Betriebssystemversion ein, unter der die App ausgeführt werden kann.
<G-vec00221-002-s084><run.ausführen><en> Maximum OS version: Optionally, type the most recent operating system that the device must run to use the app.
<G-vec00221-002-s085><run.ausführen><de> Die Apps kann so nicht ausgeführt werden, jedoch kann Windows die App unmittelbar fortsetzen, wenn der Benutzer zu ihr zurückkehrt.
<G-vec00221-002-s085><run.ausführen><en> It can’t run in this state, but Windows can instantly resume it when the user returns to it.
<G-vec00221-002-s086><run.ausführen><de> Die Clock ist eine eigenständige App und kann ohne Datenverbindung ausgeführt werden.
<G-vec00221-002-s086><run.ausführen><en> The Clock is a standalone App and doesn't need a data connection for you to run it.
<G-vec00221-002-s087><run.ausführen><de> Da Anwendungen für Adobe AIR auf Ihrem Desktop-Computer ausgeführt werden, ohne einen Webbrowser, bieten sie den Komfort einer Desktop-Anwendung.
<G-vec00221-002-s087><run.ausführen><en> Since applications built for Adobe AIR run on your desktop computer without a web browser, they pro... Sponsored Links
<G-vec00221-002-s088><run.ausführen><de> Wenn das ausgewählte Programm auf einem Client nicht ausgeführt werden kann, wird die Tasksequenz nicht ausgeführt.
<G-vec00221-002-s088><run.ausführen><en> If the selected program fails to run on a client, the task sequence is not run.
<G-vec00221-002-s089><run.ausführen><de> VMware und Google erweitern ihre Partnerschaft, damit Windows-basierte Anwendungen und Desktops auf Google Chromebooks ausgeführt werden können.
<G-vec00221-002-s089><run.ausführen><en> VMware and Google expand their partnership to enable Windows-based applications and desktops to run on Google Chromebooks.
<G-vec00221-002-s090><run.ausführen><de> Da Container in sich geschlossen sind, können mehrere Container, die von verschiedenen Cloud-Kunden erstellt wurden, auf einem einzigen Host-Rechner ausgeführt werden.
<G-vec00221-002-s090><run.ausführen><en> Because containers are self-contained, multiple containers created by different cloud customers can run on a single host machine.
<G-vec00221-002-s091><run.ausführen><de> Damit Clients auch während eines LicenseServer Shutdown weiter ausgeführt werden können, konfigurieren Sie einen Failover LicenseServer.
<G-vec00221-002-s091><run.ausführen><en> To enable clients to run during a LicenseServer shutdown, configure a Failover LicenseServer.
<G-vec00221-002-s092><run.ausführen><de> Es können beide Etikettenapplikatoren gleichzeitig verwendet oder einzeln ausgeführt werden.
<G-vec00221-002-s092><run.ausführen><en> It can use both label applicators simultaneously or run individually.
<G-vec00221-002-s093><run.ausführen><de> Windows® Virtual PC ist eine optionale Komponente des Windows 7-Betriebssystems, mit deren Hilfe mehr als ein Betriebssystem gleichzeitig auf einem Computer ausgeführt werden kann.
<G-vec00221-002-s093><run.ausführen><en> Windows® Virtual PC is an optional component of the Windows 7 operating system that lets you run more than one operating system at the same time on one computer.
<G-vec00221-002-s094><run.ausführen><de> Zugleich können auch Berechnungen ausgeführt werden, zum Beispiel eine Erhöhung sämtlicher Werte um einen bestimmten Prozentsatz.
<G-vec00221-002-s094><run.ausführen><en> You can also run calculations as well, for example, to increase all of the values by a certain percentage.
<G-vec00241-002-s038><carry.ausführen><de> Wissenschafter von Universitäten, technischen Hochschulen und Forschungsinstituten der Mitgliedländer, und bei Nachfrage auch von anderen Staaten, können in den von der Stiftung zur Verfügung gestellten Infrastrukturen nach dem Gästeprinzip Forschungsprojekte ausführen.
<G-vec00241-002-s038><carry.ausführen><en> Scientists from universities, schools of technology, and research institutes of the member countries, and exceptionally from other countries, can carry out research in the laboratories and observatories provided by the Foundation.
<G-vec00241-002-s039><carry.ausführen><de> Wie in jeder Gangsterbande gibt es immer diejenigen, die das Verbrechen, die Tat befehlen, und diejenigen, die sie ausführen.
<G-vec00241-002-s039><carry.ausführen><en> As in any band of gangsters, there are always those who order the crime, and those who carry it out.
<G-vec00241-002-s040><carry.ausführen><de> Die Q5 bietet also den Vorteil, dass man neben dem traditionellen Stanzen und Nibbeln mehrere sekundäre Bearbeitungen auf ein und derselben Maschine ausführen kann.
<G-vec00241-002-s040><carry.ausführen><en> The Q5 allows you to carry out many of the secondary processes, alongside the more traditional punching and nibbling, on the same machine.
<G-vec00241-002-s041><carry.ausführen><de> Zum ergonomischen Konzept des kompakten SBZ 137 gehört, dass sich alle Reinigungs- und Wartungsarbeiten einfach ausführen lassen.
<G-vec00241-002-s041><carry.ausführen><en> Another advantage of the SBZ 137‘s ergonomic design is that all cleaning and maintenance tasks are very simple to carry out.
<G-vec00241-002-s042><carry.ausführen><de> Da wir in unseren Produktionsländern eigene Niederlassungen haben, lassen sich Qualitätskontrollen in jedem Produktionsstadium schnell und einfach ausführen.
<G-vec00241-002-s042><carry.ausführen><en> The fact that we have our own offices in our production countries makes it easy for us to carry out these checks at various stages of production.
<G-vec00241-002-s043><carry.ausführen><de> Es wird einfacher, effektiver und billiger für nordische Unternehmen Patentbearbeitungen ausführen zu lassen.
<G-vec00241-002-s043><carry.ausführen><en> ‘It will be simpler, more effective and cheaper to carry out patent processing for Nordic companies.
<G-vec00241-002-s044><carry.ausführen><de> Pusherism.com mag in der Tat irritierend sein, kann aber nicht mit einer der bösartigen Aktionen in Verbindung gebracht werden, die Viren oder Malware wie Trojaner oder Ransomware ausführen könnten.
<G-vec00241-002-s044><carry.ausführen><en> Apsr.xyz may indeed be irritating, but can’t be related to any of the vicious actions that viruses or malware like Trojan Horses or Ransomware could carry out.
<G-vec00241-002-s045><carry.ausführen><de> Nach den Bestimmungen des Handelsgesetzbuches (HGB) versteht man unter einer Spedition ein Unternehmen, das den Transport eines Gutes organisiert, diesen jedoch nicht selber ausführen muss.
<G-vec00241-002-s045><carry.ausführen><en> A forwarder is a company that organizes the transport of a good but does not carry the shipment itself.
<G-vec00241-002-s046><carry.ausführen><de> Die Erfindung in Anspruch 1 der früheren US-Anmeldung war also nicht so ausreichend offenbart, dass der Fachmann sie ausführen kann.
<G-vec00241-002-s046><carry.ausführen><en> In sum, the earlier US application did not provide a disclosure sufficient for the skilled person to carry out the invention in claim 1.
<G-vec00241-002-s047><carry.ausführen><de> Mit Hilfe des Ausgangssignals eines Kodierers kann eine damit ausgerüstete Antriebseinheit reproduzierbare Bewegungen ausführen und – im Falle eines Absolutwertgebers – auch nach Abschaltung der Maschine wieder genau in die Ausgangsposition (Referenzposition) fahren.
<G-vec00241-002-s047><carry.ausführen><en> With the help of the output signal of an encoder, a drive unit equipped with it can carry out reproducible movements and – in the case of an absolute encoder – move back exactly to the starting position (reference position) even after the machine has been switched off.
<G-vec00241-002-s048><carry.ausführen><de> Die unbedingte Annahme der Disziplin und der Zentralisation kann im äußersten Fall dazu führen, dass Wenige oder nur ein Einzelner das Sagen haben, während die anderen trotz Mangel an Überzeugung oder Entschlossenheit gehorchen und ausführen.
<G-vec00241-002-s048><carry.ausführen><en> Total acceptance of discipline and centralisation can result in the extreme case, where few, or only one, speak and take decisions, while others not completely convinced or resolute, obey and carry out the orders.
<G-vec00241-002-s049><carry.ausführen><de> Um die Operation ausführen zu können, müssen erst andere offene Dateien oder Programme beendet werden.
<G-vec00241-002-s049><carry.ausführen><en> In order to carry out the operation, you need to close other open files or programs.
<G-vec00241-002-s050><carry.ausführen><de> Den exakten Zeitpunkt, ab dem Ihre Figur wieder einen Angriff ausführen kann, gibt der Computer durch einen glockenähnlichen Ton wieder.
<G-vec00241-002-s050><carry.ausführen><en> The exact point of time, when your character is ready can carry our another attack, is marked by the computer through a bell-like sound.
<G-vec00241-002-s051><carry.ausführen><de> Alles, was den Menschen daher als Evangelium nahegebracht werden soll, darf nur die Veredelung des Menschen, ein Umgestalten zur Liebe bezwecken, dann ist es eine rechte Weinbergsarbeit, die Meine Knechte auf Erden ausführen.
<G-vec00241-002-s051><carry.ausführen><en> Everything, what is therefore to be made accessible to men as Gospel, is only allowed to aim to achieve the ennobling of men, a transformation to love, then it is a right vineyard work, which my servants on earth carry out.
<G-vec00241-002-s052><carry.ausführen><de> In diesem Konto kann der Kunde dann Domainnamen und Postfächer hinzufügen, die Inhalte der Website bearbeiten und andere Aufgaben zur Hosting-Verwaltung ausführen.
<G-vec00241-002-s052><carry.ausführen><en> Under this account, the customer can add domain names and mailboxes, edit website content, and carry out other hosting management routines.
<G-vec00241-002-s053><carry.ausführen><de> Wenn wir uns wirklich bemühen, können wir die Zirbeldrüse in einem gewissen Rahmen wieder zur Funktion bringen, und dann wird sich dieses Organ langsam, sehr langsam, doch sukzessive wieder vergrößern und seine Funktionen dementsprechend kraftvoller ausführen können.
<G-vec00241-002-s053><carry.ausführen><en> Im If we truly go to a lot of effort, we can, to a certain extent, make the pineal gland function again, and then slowly, very slowly yet successively, this organ will enlarge again and, accordingly, be able to carry out its function more powerfully.
<G-vec00241-002-s054><carry.ausführen><de> Schaffen Sie Orientierung durch klare Handlungsvorgaben – damit jeder Mitarbeiter weiß, wie er seine Tätigkeiten ausführen soll.
<G-vec00241-002-s054><carry.ausführen><en> Create direction through a clear course of action so that each employee knows how to carry out their tasks.
<G-vec00241-002-s055><carry.ausführen><de> Nach dem Ablegen der Hufschmiedeprüfung kann er selbstständig Huf- und Beschlagschmiedearbeiten ausführen.
<G-vec00241-002-s055><carry.ausführen><en> After passing the farrier's exam they can carry out this work independently.
<G-vec00241-002-s056><carry.ausführen><de> Hinweis: Nach Ausführen dieses Vorgangs werden alle persönlichen Konfigurationsparameter im Mobile WiFi gelöscht.
<G-vec00241-002-s056><carry.ausführen><en> After you carry out this operation, the Mobile WiFi's personal configuration parameters will all be deleted.
<G-vec00316-002-s019><accomplish.ausführen><de> Genau so ist das Erbe der Gottlosen… Verzehr des Fleisches, der Seele und des Geistes, in der Gegenwart des Gerechten, der es ausführen wird… Dann werden Alle wissen, dass der Vater und der Sohn EINS sind.
<G-vec00316-002-s019><accomplish.ausführen><en> For thus is the inheritance of the wicked… Consumption of flesh, body and spirit, in the presence Of The Righteous One who shall accomplish it… Then all shall know, The Father and The Son are ONE!
<G-vec00316-002-s020><accomplish.ausführen><de> Erste Schritte Bevor Sie mit der Installation beginnen, müssen Sie zuerst sicherstellen, dass Sie über die notwendigen Berechtigungen zum Ausführen der erforderlichen Aufgaben verfügen.
<G-vec00316-002-s020><accomplish.ausführen><en> The first step, prior to installation, is to make sure you have the needed permissions to accomplish the required tasks.
<G-vec00316-002-s021><accomplish.ausführen><de> Daß Ich ihn ansprechen kann, stempelt ihn auch zu einem Diener in Meinem Weinberg, und dann wird er auch alle Aufträge gewissenhaft ausführen, die Ich ihm nun zuweise....
<G-vec00316-002-s021><accomplish.ausführen><en> The fact that I can speak to him will also signify him as a servant in My vineyard, for then he will conscientiously accomplish all tasks which I assign to him....
<G-vec00316-002-s022><accomplish.ausführen><de> Mit einem zusätzlich ausklappbaren Ausleger ausgestattet, können Sie an der NOHrD Sprossenwand Wallbar Nussbaum noch mehr unterschiedliche Übungen ausführen.
<G-vec00316-002-s022><accomplish.ausführen><en> Being equipped with an additionally foldable arm, you can accomplish even more different exercises with the NOHrD Wallbar walnut.
<G-vec00316-002-s030><fulfil.ausführen><de> Wir bearbeiten Ihre personenbezogenen Daten, um mit Ihnen zu kommunizieren, Ihre Kaufaufträge auszuführen, Ihre Fragen zu beantworten und Sie über Nestlé und unsere Produkte zu informieren.
<G-vec00316-002-s030><fulfil.ausführen><en> We process your Personal Data, including any sensitive personal data that you have provided to us with your consent, to communicate with you, fulfil your purchase orders, answer your queries and provide you with communications about Nestlé and our products.
<G-vec00316-002-s031><fulfil.ausführen><de> Wir verwenden die Bestellinformationen, die wir im Allgemeinen sammeln, um alle über die Webseite aufgegebenen Bestellungen auszuführen (einschließlich der Verarbeitung Ihrer Zahlungsinformationen, des Versands und der Bereitstellung von Rechnungen und/oder Auftragsbestätigungen).
<G-vec00316-002-s031><fulfil.ausführen><en> We use the Order Information that we collect generally to fulfil any orders placed through the Site (including processing your payment information, arranging for shipping, and providing you with invoices and/or order confirmations).
<G-vec00316-002-s032><fulfil.ausführen><de> Die Gogetdo-App verbindet Nutzer mit Menschen in ihrer Umgebung, die ihnen helfen, ihre Aufgaben auszuführen.
<G-vec00316-002-s032><fulfil.ausführen><en> The Gogetdo app connects users with people in their area to help fulfil their tasks.
<G-vec00316-002-s034><fulfil.ausführen><de> Um alle von Ihnen angemeldeten Abonnements zu bearbeiten und auszuführen, einschließlich der ASUS-EDMs oder Newsletter, um Sie über die neuesten ASUS-Nachrichten, Promotion-Aktionen und bevorstehenden Veranstaltungen auf dem Laufenden zu halten.
<G-vec00316-002-s034><fulfil.ausführen><en> v.To process and fulfil any subscriptions you have signed up for, including ASUS eDMs or newsletters to keep you up to date with the latest ASUS news, promotions and upcoming events.
<G-vec00316-002-s035><fulfil.ausführen><de> Und dann, ausgerüstet von Gott, diesen Vorsatz auszuführen – DAS ist die Salbung.
<G-vec00316-002-s035><fulfil.ausführen><en> And then, equipped by God to fulfil that purpose - THAT is the anointing.
<G-vec00316-002-s036><fulfil.ausführen><de> Seien Sie versichert, dass wir uns sehr bemühen werden, die fehlenden Artikel zu finden und Ihre Bestellung so schnell wie möglich auszuführen.
<G-vec00316-002-s036><fulfil.ausführen><en> Rest assured that we will work extremely hard to locate the missing items and fulfil your order as soon as possible.
<G-vec00316-002-s037><fulfil.ausführen><de> Die Mitglieder verpflichten sich, die in Übereinstimmung mit der Satzung getroffenen Entscheidungen auszuführen und die mehrheitlich gefassten Beschlüsse zu respektieren.
<G-vec00316-002-s037><fulfil.ausführen><en> Members commit themselves to fulfil obligations which conform to the statutes and to respect consensus decisions made by the members.
<G-vec00316-002-s038><fulfil.ausführen><de> Sibelius mochte das nicht, aber beschloss dennoch den Auftrag auszuführen, obwohl die Arbeit vermutlich umfassender war, als er sich vorgestellt hatte: nicht nur ein paar Tanznummern, sondern eine durchkomponierte Pantomime.
<G-vec00316-002-s038><fulfil.ausführen><en> Sibelius was not happy about this, but he decided to fulfil the contract, although the work was more extensive than he had imagined: music for a complete pantomime instead of just a few dance pieces.
<G-vec00316-002-s029><fulfill.ausführen><de> Wenn wir entscheiden, dass der korrekte Preis höher ist als der angegebene Preis, sind wir nicht verpflichtet, die Bestellung zum angegebenen Preis auszuführen.
<G-vec00316-002-s029><fulfill.ausführen><en> If we determine that the correct price is higher than the stated price, we are not obligated to fulfill your order at the stated price.
<G-vec00316-002-s030><fulfill.ausführen><de> Zwischenfazit: Die KI ist hier nicht einmal fähig die simpelste aller Aufgaben auszuführen.
<G-vec00316-002-s030><fulfill.ausführen><en> Interim Conclusion: The AI isn't even able to fulfill the simplest of all orders.
<G-vec00316-002-s031><fulfill.ausführen><de> Wir können Ihre Daten verwenden, um Ihre Bestellungen, Zahlungen, Rücksendungen und den Produktaustausch über die Websites auszuführen und zu verwalten.
<G-vec00316-002-s031><fulfill.ausführen><en> We may use your information to fulfill and manage your orders, payments, returns, and exchanges made through the Sites.
<G-vec00316-002-s032><fulfill.ausführen><de> Diese Informationen werden verwendet, um Ihre Bestellung auszuführen und mit Ihnen über Ihre Bestellung oder Spende zu kommunizieren.
<G-vec00316-002-s032><fulfill.ausführen><en> This information is used to fulfill your order and communicate with you about your order or donation.
<G-vec00316-002-s033><fulfill.ausführen><de> Leider haben wir nicht genügend „Pauw“ vorrätig, um deine Bestellung auszuführen (22 verfügbar).
<G-vec00316-002-s033><fulfill.ausführen><en> Sorry, we do not have enough "Schoon" in stock to fulfill your order (1 available).
<G-vec00316-002-s034><fulfill.ausführen><de> Für Office 365 gibt es eine Vorschau, Anforderungen in Bezug auf die Korrektur, Änderung, Löschung oder den Export personenbezogener Daten von Einzelpersonen, die den Kern der DSGVO-Compliance ausmachen, schnell und problemlos auszuführen.
<G-vec00316-002-s034><fulfill.ausführen><en> Office 365 now previewing the ability to quickly and easily fulfill requests to correct, amend, delete, or export the personal data of individuals that are at the core of GDPR compliance.
<G-vec00316-002-s035><fulfill.ausführen><de> Leider haben wir nicht genügend „Der Pfau“ vorrätig, um deine Bestellung auszuführen (22 verfügbar).
<G-vec00316-002-s035><fulfill.ausführen><en> Sorry, we do not have enough "Pauw" in stock to fulfill your order (22 available).
<G-vec00316-002-s036><fulfill.ausführen><de> Bei erfolgreichem Abschluss der Zahlungstransaktion wird dein Kauf so schnell wie möglich abgeschlossen - wir werden uns bemühen, deinen Auftrag unmittelbar nach deinem Kauf auszuführen.
<G-vec00316-002-s036><fulfill.ausführen><en> Upon the completion of a successful payment transaction then your purchase will be fulfilled to you as soon as possible - we will endeavor to fulfill your order immediately at the point of purchase.
<G-vec00316-002-s037><fulfill.ausführen><de> · Das Detektivunternehmen verpflichtet sich, den erteilten Auftrag nach bestem Wissen und Fähigkeiten mit gebotener Sorgfalt auszuführen.
<G-vec00316-002-s037><fulfill.ausführen><en> Our detective agency commits itself to fulfill the commissioned order according to the best knowledge and skills with due diligence.
<G-vec00316-002-s038><fulfill.ausführen><de> Das große Fachwissen und die Flexibilität unserer Mitarbeiter erlauben es uns, auf Ihre Wünsche schnell zu reagieren und Ihre Aufträge termingerecht und in hoher Präzision auszuführen.
<G-vec00316-002-s038><fulfill.ausführen><en> The expert know-how and flexibility of our employees allow us to respond quickly to your needs and fulfill your orders not only with the highest precision, but on schedule.
<G-vec00316-002-s039><fulfill.ausführen><de> 15 Jahre später kehrt Orestes nach Mykene zurück, um den Mord auszuführen.
<G-vec00316-002-s039><fulfill.ausführen><en> Fifteen years later, Orestes returns to fulfill his murderous destiny…
<G-vec00316-002-s040><fulfill.ausführen><de> Wir haben nur auszuführen, was wir uns selbst als Norm unseres Handelns vorschreiben.
<G-vec00316-002-s040><fulfill.ausführen><en> We have to fulfill only what we ourselves lay down as our standard of conduct.
<G-vec00316-002-s041><fulfill.ausführen><de> Wenn ihr diesen Geist nicht ablehnt — auch wenn es die Ewigkeit erfordern sollte, um den Auftrag auszuführen — „wird er euch in alle Wahrheit führen“.
<G-vec00316-002-s041><fulfill.ausführen><en> If you do not reject this spirit, even though eternity may be required to fulfill the commission, “he will guide you into all truth.”
<G-vec00316-002-s042><fulfill.ausführen><de> Leider haben wir nicht genügend „Schoon“ vorrätig, um deine Bestellung auszuführen (1 verfügbar).
<G-vec00316-002-s042><fulfill.ausführen><en> Sorry, we do not have enough "Pauw" in stock to fulfill your order (22 available).
<G-vec00316-002-s043><fulfill.ausführen><de> Wir glauben daran, dass die Kommunikationstechnologien von heute ein Geschenk Gottes an Seine Kinder sind, um den großen Missionsbefehl in unserer Generation auszuführen.
<G-vec00316-002-s043><fulfill.ausführen><en> We believe that today’s communication technologies are a gift from God to His children in order to enable them to fulfill the Great Commission in our generation.
<G-vec00337-002-s020><expedite.ausführen><de> 2.12 Das Unternehmen hat das Recht, einen Zahlungsdienstleister zu bestimmen, welcher Einzahlungen empfängt, Gelder hält und verwaltet, und/oder Abhebungen im Namen vom Unternehmen ausführt.
<G-vec00337-002-s020><expedite.ausführen><en> 2.12 The Company may appoint a payment solution provider to act, receive deposits, hold and manage funds, and/or expedite withdrawals on behalf of the Company.
<G-vec00365-002-s363><execute.ausführen><de> Ist $i gleich 1, führt PHP die letzten beiden echo Anweisungen aus.
<G-vec00365-002-s363><execute.ausführen><en> If $i is equal to 1, PHP would execute the last two echo statements.
<G-vec00365-002-s364><execute.ausführen><de> Führt eine allein stehende Operation aus.
<G-vec00365-002-s364><execute.ausführen><en> Execute a stand-alone operation.
<G-vec00365-002-s365><execute.ausführen><de> Führt eine asynchrone Abfrage durch diese Funktionen aus.
<G-vec00365-002-s365><execute.ausführen><en> Execute query by these asynchronous query by these functions.
<G-vec00365-002-s366><execute.ausführen><de> Sobald ein lukratives Handels-Setup entdeckt wurde, führt die Software den Handel automatisch in Ihrem Handelskonto aus.
<G-vec00365-002-s366><execute.ausführen><en> Once a lucrative trade setup is spotted, the software will automatically execute the trade within your trading account.
<G-vec00365-002-s367><execute.ausführen><de> Falls das SUT in einen stark fehlerhaften Zustand versetzt wurde, führt er weitere Aufräumarbeiten aus bevor er die Vorbedingungen für den nächsten Testfall herstellen kann.
<G-vec00365-002-s367><execute.ausführen><en> Next he would check that the SUT still meets all preconditions required by the next test case and if not execute the necessary steps.
<G-vec00365-002-s368><execute.ausführen><de> Zeichen: Manchmal verhält sich Outlook unregelmäßig und führt beim Starten der App nicht automatisch die Sende- / Empfangsfunktion aus, um E-Mails vom Mailserver abzurufen.
<G-vec00365-002-s368><execute.ausführen><en> Sometimes, Outlook behaves erratically and when you start the app, it does not automatically execute send/receive functionality to fetch emails from the mail server.
<G-vec00365-002-s369><execute.ausführen><de> Nach dem Doppelklick auf das Bild führt die RTF-Datei die eingebettete Datei, nämlich eine bösartige CPL-Datei, aus.
<G-vec00365-002-s369><execute.ausführen><en> Once the user clicks the image, the RTF file will execute the embedded file.
<G-vec00373-002-s133><perform.ausführen><de> Diese Tasks können auch dann ausgeführt werden, wenn Computer das Betriebssystem nicht geladen haben, die Festplatte nicht funktioniert oder das Betriebssystem nicht reagiert.
<G-vec00373-002-s133><perform.ausführen><en> You can perform these tasks even if computers have not loaded the operating system, the hard disk is not functioning, or the operating system is not responding.
<G-vec00373-002-s134><perform.ausführen><de> Zahlreiche Funktionen wie die Batch-Verarbeitung und Analyse werden jetzt bis zu fünf Mal schneller ausgeführt.
<G-vec00373-002-s134><perform.ausführen><en> Many functions such as batch processing and analysis now perform up to five times faster.
<G-vec00373-002-s135><perform.ausführen><de> Um eine hohe Qualität der Bohrung und lange Haltbarkeit der Bohrkrone sicherzustellen, muss eine geeignete Bohrdrehzahl verwendet und während des Bohrens eine leichte orbitale Bewegung ausgeführt werden; nach Abschluss der Bohrung ist der Bohrstaub aus dem Inneren der Bohrkrone zu entfernen.
<G-vec00373-002-s135><perform.ausführen><en> For a better finish and durability of the bit, it is important to observe the suitable rotation speed and perform a slight orbital movement while drilling, as well as to ensure that once the hole is finished off there is no waste drilled material inside the drill bit. Features
<G-vec00373-002-s136><perform.ausführen><de> Wiederholende Back-ups werden in Zyklen ausgeführt.
<G-vec00373-002-s136><perform.ausführen><en> The program can perform a one-time backup job or backup data in cycles.
<G-vec00373-002-s137><perform.ausführen><de> Wenn Sie im Dropdownfeld "Bestätigen" auswählen, werden die Benutzer gefragt, ob Zwischenablagenoperationen ausgeführt werden dürfen.
<G-vec00373-002-s137><perform.ausführen><en> If you select Prompt in the drop-down box, users are queried as to whether to perform clipboard operations.
<G-vec00373-002-s138><perform.ausführen><de> Diese Aktion kann von jedem ausgeführt werden.
<G-vec00373-002-s138><perform.ausführen><en> Anyone can perform this action.
<G-vec00373-002-s139><perform.ausführen><de> Bei einer Serverrolle handelt es sich um eine Gruppe von Softwareprogrammen, mit deren Hilfe - wenn sie installiert und richtig konfiguriert sind - von einem Computer eine bestimmte Funktion für mehrere Benutzer oder für andere Computer in einem Netzwerk ausgeführt werden kann.
<G-vec00373-002-s139><perform.ausführen><en> Roles A server role is a set of software programs that, when they are installed and properly configured, lets a computer perform a specific function for multiple users or other computers within a network.
<G-vec00373-002-s140><perform.ausführen><de> Darüber hinaus können Massenupdates einfacher und effizienter ausgeführt werden, wenn Sie gute Grundlagen des Datenbankentwurfs verwenden.
<G-vec00373-002-s140><perform.ausführen><en> Furthermore, bulk updates are easier and more efficient to perform when you use good principles of database design.
<G-vec00373-002-s141><perform.ausführen><de> Wenn du sie allerdings nicht ausgeführt hast, empfehlen wir dir die unten stehenden Schritte, um sicherzustellen, dass dein Konto wieder sicher ist.
<G-vec00373-002-s141><perform.ausführen><en> If you did not perform these activities, we recommend to take steps to ensure your account is secure.
<G-vec00373-002-s142><perform.ausführen><de> %1 kann nicht für %2 ausgeführt werden, da der Eintrag bereits vorhanden ist.
<G-vec00373-002-s142><perform.ausführen><en> Cannot perform %1 on %2 as entry already exists.
<G-vec00373-002-s143><perform.ausführen><de> Zweitens werden damit Berechnungen anstelle von Aktionen ausgeführt.
<G-vec00373-002-s143><perform.ausführen><en> Second, they perform calculations instead of taking actions.
<G-vec00373-002-s144><perform.ausführen><de> (4) Die notifizierende Behörde darf weder Tätigkeiten, die von notifizierten Stellen ausgeführt werden, noch Beratungsdienstleistungen auf einer gewerblichen oder wettbewerblichen Basis anbieten oder erbringen.
<G-vec00373-002-s144><perform.ausführen><en> 4. The notifying authority shall not offer or provide any activities that notified bodies perform, or consultancy services on a commercial or competitive basis.
<G-vec00373-002-s145><perform.ausführen><de> Calls werden über tcACCESS JDBC aus den Java Anwendungen ausgeführt und somit werden bestehende CICS-Programme in die neuen Anwendungen integriert.
<G-vec00373-002-s145><perform.ausführen><en> The Java applications perform calls via the tcACCESS JDBC component to call existing CICS programs, hence integrating proven business logic into the new applications.
<G-vec00373-002-s146><perform.ausführen><de> Für Installationen die durch den technischen Support ausgeführt werden sollen, muss der Kunde einen Auftrag über das Support Center einleiten.
<G-vec00373-002-s146><perform.ausführen><en> On request the technical support can perform the installation after a request via Support Center.
<G-vec00373-002-s147><perform.ausführen><de> Außerdem können Sie die Tasten so anpassen, dass über sie Aktionen ausgeführt werden, die auf Ihre Anforderungen zugeschnitten sind.
<G-vec00373-002-s147><perform.ausführen><en> Also, you can customize the buttons to perform actions that suit your needs.
<G-vec00373-002-s148><perform.ausführen><de> Preis inkl.MwSt./Anwender Es handelt sich um eine vollwertige Lizenz, mit der alle beschriebenen Aufgaben ohne Einschränkungen ausgeführt werden können.
<G-vec00373-002-s148><perform.ausführen><en> This is a fully-fledged license (one-time price), which allows you to perform all the tasks described without restrictions.
<G-vec00373-002-s149><perform.ausführen><de> Hardwarebeschleunigte Texte, Videos und Grafiken führen dazu, dass Ihre Websites wie die auf Ihrem Computer installierten Programme ausgeführt werden.
<G-vec00373-002-s149><perform.ausführen><en> Hardware-accelerated text, video, and graphics mean your websites perform like the programs that are installed on your computer.
<G-vec00373-002-s150><perform.ausführen><de> Morgens kann das gewohnte Pflegeritual ausgeführt werden.
<G-vec00373-002-s150><perform.ausführen><en> In the morning you can perform your usual cleansing routine.
<G-vec00373-002-s151><perform.ausführen><de> In den meisten Fällen wird diese Aufgabe von Websiteadministratoren oder Personen, die bestimmte Listen oder Bibliotheken verwalten, ausgeführt.
<G-vec00373-002-s151><perform.ausführen><en> In most cases, site administrators or individuals who manage specific lists or libraries perform this task.
<G-vec00261-003-s038><carry_on.ausführen><de> Wissenschafter von Universitäten, technischen Hochschulen und Forschungsinstituten der Mitgliedländer, und bei Nachfrage auch von anderen Staaten, können in den von der Stiftung zur Verfügung gestellten Infrastrukturen nach dem Gästeprinzip Forschungsprojekte ausführen.
<G-vec00261-003-s038><carry_on.ausführen><en> Scientists from universities, schools of technology, and research institutes of the member countries, and exceptionally from other countries, can carry out research in the laboratories and observatories provided by the Foundation.
<G-vec00261-003-s039><carry_on.ausführen><de> Wie in jeder Gangsterbande gibt es immer diejenigen, die das Verbrechen, die Tat befehlen, und diejenigen, die sie ausführen.
<G-vec00261-003-s039><carry_on.ausführen><en> As in any band of gangsters, there are always those who order the crime, and those who carry it out.
<G-vec00261-003-s040><carry_on.ausführen><de> Die Q5 bietet also den Vorteil, dass man neben dem traditionellen Stanzen und Nibbeln mehrere sekundäre Bearbeitungen auf ein und derselben Maschine ausführen kann.
<G-vec00261-003-s040><carry_on.ausführen><en> The Q5 allows you to carry out many of the secondary processes, alongside the more traditional punching and nibbling, on the same machine.
<G-vec00261-003-s041><carry_on.ausführen><de> Zum ergonomischen Konzept des kompakten SBZ 137 gehört, dass sich alle Reinigungs- und Wartungsarbeiten einfach ausführen lassen.
<G-vec00261-003-s041><carry_on.ausführen><en> Another advantage of the SBZ 137‘s ergonomic design is that all cleaning and maintenance tasks are very simple to carry out.
<G-vec00261-003-s042><carry_on.ausführen><de> Da wir in unseren Produktionsländern eigene Niederlassungen haben, lassen sich Qualitätskontrollen in jedem Produktionsstadium schnell und einfach ausführen.
<G-vec00261-003-s042><carry_on.ausführen><en> The fact that we have our own offices in our production countries makes it easy for us to carry out these checks at various stages of production.
<G-vec00261-003-s043><carry_on.ausführen><de> Es wird einfacher, effektiver und billiger für nordische Unternehmen Patentbearbeitungen ausführen zu lassen.
<G-vec00261-003-s043><carry_on.ausführen><en> ‘It will be simpler, more effective and cheaper to carry out patent processing for Nordic companies.
<G-vec00261-003-s044><carry_on.ausführen><de> Pusherism.com mag in der Tat irritierend sein, kann aber nicht mit einer der bösartigen Aktionen in Verbindung gebracht werden, die Viren oder Malware wie Trojaner oder Ransomware ausführen könnten.
<G-vec00261-003-s044><carry_on.ausführen><en> Apsr.xyz may indeed be irritating, but can’t be related to any of the vicious actions that viruses or malware like Trojan Horses or Ransomware could carry out.
<G-vec00261-003-s045><carry_on.ausführen><de> Nach den Bestimmungen des Handelsgesetzbuches (HGB) versteht man unter einer Spedition ein Unternehmen, das den Transport eines Gutes organisiert, diesen jedoch nicht selber ausführen muss.
<G-vec00261-003-s045><carry_on.ausführen><en> A forwarder is a company that organizes the transport of a good but does not carry the shipment itself.
<G-vec00261-003-s046><carry_on.ausführen><de> Die Erfindung in Anspruch 1 der früheren US-Anmeldung war also nicht so ausreichend offenbart, dass der Fachmann sie ausführen kann.
<G-vec00261-003-s046><carry_on.ausführen><en> In sum, the earlier US application did not provide a disclosure sufficient for the skilled person to carry out the invention in claim 1.
<G-vec00261-003-s047><carry_on.ausführen><de> Mit Hilfe des Ausgangssignals eines Kodierers kann eine damit ausgerüstete Antriebseinheit reproduzierbare Bewegungen ausführen und – im Falle eines Absolutwertgebers – auch nach Abschaltung der Maschine wieder genau in die Ausgangsposition (Referenzposition) fahren.
<G-vec00261-003-s047><carry_on.ausführen><en> With the help of the output signal of an encoder, a drive unit equipped with it can carry out reproducible movements and – in the case of an absolute encoder – move back exactly to the starting position (reference position) even after the machine has been switched off.
<G-vec00261-003-s048><carry_on.ausführen><de> Die unbedingte Annahme der Disziplin und der Zentralisation kann im äußersten Fall dazu führen, dass Wenige oder nur ein Einzelner das Sagen haben, während die anderen trotz Mangel an Überzeugung oder Entschlossenheit gehorchen und ausführen.
<G-vec00261-003-s048><carry_on.ausführen><en> Total acceptance of discipline and centralisation can result in the extreme case, where few, or only one, speak and take decisions, while others not completely convinced or resolute, obey and carry out the orders.
<G-vec00261-003-s049><carry_on.ausführen><de> Um die Operation ausführen zu können, müssen erst andere offene Dateien oder Programme beendet werden.
<G-vec00261-003-s049><carry_on.ausführen><en> In order to carry out the operation, you need to close other open files or programs.
<G-vec00261-003-s050><carry_on.ausführen><de> Den exakten Zeitpunkt, ab dem Ihre Figur wieder einen Angriff ausführen kann, gibt der Computer durch einen glockenähnlichen Ton wieder.
<G-vec00261-003-s050><carry_on.ausführen><en> The exact point of time, when your character is ready can carry our another attack, is marked by the computer through a bell-like sound.
<G-vec00261-003-s051><carry_on.ausführen><de> Alles, was den Menschen daher als Evangelium nahegebracht werden soll, darf nur die Veredelung des Menschen, ein Umgestalten zur Liebe bezwecken, dann ist es eine rechte Weinbergsarbeit, die Meine Knechte auf Erden ausführen.
<G-vec00261-003-s051><carry_on.ausführen><en> Everything, what is therefore to be made accessible to men as Gospel, is only allowed to aim to achieve the ennobling of men, a transformation to love, then it is a right vineyard work, which my servants on earth carry out.
<G-vec00261-003-s052><carry_on.ausführen><de> In diesem Konto kann der Kunde dann Domainnamen und Postfächer hinzufügen, die Inhalte der Website bearbeiten und andere Aufgaben zur Hosting-Verwaltung ausführen.
<G-vec00261-003-s052><carry_on.ausführen><en> Under this account, the customer can add domain names and mailboxes, edit website content, and carry out other hosting management routines.
<G-vec00261-003-s053><carry_on.ausführen><de> Wenn wir uns wirklich bemühen, können wir die Zirbeldrüse in einem gewissen Rahmen wieder zur Funktion bringen, und dann wird sich dieses Organ langsam, sehr langsam, doch sukzessive wieder vergrößern und seine Funktionen dementsprechend kraftvoller ausführen können.
<G-vec00261-003-s053><carry_on.ausführen><en> Im If we truly go to a lot of effort, we can, to a certain extent, make the pineal gland function again, and then slowly, very slowly yet successively, this organ will enlarge again and, accordingly, be able to carry out its function more powerfully.
<G-vec00261-003-s054><carry_on.ausführen><de> Schaffen Sie Orientierung durch klare Handlungsvorgaben – damit jeder Mitarbeiter weiß, wie er seine Tätigkeiten ausführen soll.
<G-vec00261-003-s054><carry_on.ausführen><en> Create direction through a clear course of action so that each employee knows how to carry out their tasks.
<G-vec00261-003-s055><carry_on.ausführen><de> Nach dem Ablegen der Hufschmiedeprüfung kann er selbstständig Huf- und Beschlagschmiedearbeiten ausführen.
<G-vec00261-003-s055><carry_on.ausführen><en> After passing the farrier's exam they can carry out this work independently.
<G-vec00261-003-s056><carry_on.ausführen><de> Hinweis: Nach Ausführen dieses Vorgangs werden alle persönlichen Konfigurationsparameter im Mobile WiFi gelöscht.
<G-vec00261-003-s056><carry_on.ausführen><en> After you carry out this operation, the Mobile WiFi's personal configuration parameters will all be deleted.
<G-vec00316-003-s038><carry_out.ausführen><de> Wissenschafter von Universitäten, technischen Hochschulen und Forschungsinstituten der Mitgliedländer, und bei Nachfrage auch von anderen Staaten, können in den von der Stiftung zur Verfügung gestellten Infrastrukturen nach dem Gästeprinzip Forschungsprojekte ausführen.
<G-vec00316-003-s038><carry_out.ausführen><en> Scientists from universities, schools of technology, and research institutes of the member countries, and exceptionally from other countries, can carry out research in the laboratories and observatories provided by the Foundation.
<G-vec00316-003-s039><carry_out.ausführen><de> Wie in jeder Gangsterbande gibt es immer diejenigen, die das Verbrechen, die Tat befehlen, und diejenigen, die sie ausführen.
<G-vec00316-003-s039><carry_out.ausführen><en> As in any band of gangsters, there are always those who order the crime, and those who carry it out.
<G-vec00316-003-s040><carry_out.ausführen><de> Die Q5 bietet also den Vorteil, dass man neben dem traditionellen Stanzen und Nibbeln mehrere sekundäre Bearbeitungen auf ein und derselben Maschine ausführen kann.
<G-vec00316-003-s040><carry_out.ausführen><en> The Q5 allows you to carry out many of the secondary processes, alongside the more traditional punching and nibbling, on the same machine.
<G-vec00316-003-s041><carry_out.ausführen><de> Zum ergonomischen Konzept des kompakten SBZ 137 gehört, dass sich alle Reinigungs- und Wartungsarbeiten einfach ausführen lassen.
<G-vec00316-003-s041><carry_out.ausführen><en> Another advantage of the SBZ 137‘s ergonomic design is that all cleaning and maintenance tasks are very simple to carry out.
<G-vec00316-003-s042><carry_out.ausführen><de> Da wir in unseren Produktionsländern eigene Niederlassungen haben, lassen sich Qualitätskontrollen in jedem Produktionsstadium schnell und einfach ausführen.
<G-vec00316-003-s042><carry_out.ausführen><en> The fact that we have our own offices in our production countries makes it easy for us to carry out these checks at various stages of production.
<G-vec00316-003-s043><carry_out.ausführen><de> Es wird einfacher, effektiver und billiger für nordische Unternehmen Patentbearbeitungen ausführen zu lassen.
<G-vec00316-003-s043><carry_out.ausführen><en> ‘It will be simpler, more effective and cheaper to carry out patent processing for Nordic companies.
<G-vec00316-003-s044><carry_out.ausführen><de> Pusherism.com mag in der Tat irritierend sein, kann aber nicht mit einer der bösartigen Aktionen in Verbindung gebracht werden, die Viren oder Malware wie Trojaner oder Ransomware ausführen könnten.
<G-vec00316-003-s044><carry_out.ausführen><en> Apsr.xyz may indeed be irritating, but can’t be related to any of the vicious actions that viruses or malware like Trojan Horses or Ransomware could carry out.
<G-vec00316-003-s045><carry_out.ausführen><de> Nach den Bestimmungen des Handelsgesetzbuches (HGB) versteht man unter einer Spedition ein Unternehmen, das den Transport eines Gutes organisiert, diesen jedoch nicht selber ausführen muss.
<G-vec00316-003-s045><carry_out.ausführen><en> A forwarder is a company that organizes the transport of a good but does not carry the shipment itself.
<G-vec00316-003-s046><carry_out.ausführen><de> Die Erfindung in Anspruch 1 der früheren US-Anmeldung war also nicht so ausreichend offenbart, dass der Fachmann sie ausführen kann.
<G-vec00316-003-s046><carry_out.ausführen><en> In sum, the earlier US application did not provide a disclosure sufficient for the skilled person to carry out the invention in claim 1.
<G-vec00316-003-s047><carry_out.ausführen><de> Mit Hilfe des Ausgangssignals eines Kodierers kann eine damit ausgerüstete Antriebseinheit reproduzierbare Bewegungen ausführen und – im Falle eines Absolutwertgebers – auch nach Abschaltung der Maschine wieder genau in die Ausgangsposition (Referenzposition) fahren.
<G-vec00316-003-s047><carry_out.ausführen><en> With the help of the output signal of an encoder, a drive unit equipped with it can carry out reproducible movements and – in the case of an absolute encoder – move back exactly to the starting position (reference position) even after the machine has been switched off.
<G-vec00316-003-s048><carry_out.ausführen><de> Die unbedingte Annahme der Disziplin und der Zentralisation kann im äußersten Fall dazu führen, dass Wenige oder nur ein Einzelner das Sagen haben, während die anderen trotz Mangel an Überzeugung oder Entschlossenheit gehorchen und ausführen.
<G-vec00316-003-s048><carry_out.ausführen><en> Total acceptance of discipline and centralisation can result in the extreme case, where few, or only one, speak and take decisions, while others not completely convinced or resolute, obey and carry out the orders.
<G-vec00316-003-s049><carry_out.ausführen><de> Um die Operation ausführen zu können, müssen erst andere offene Dateien oder Programme beendet werden.
<G-vec00316-003-s049><carry_out.ausführen><en> In order to carry out the operation, you need to close other open files or programs.
<G-vec00316-003-s050><carry_out.ausführen><de> Den exakten Zeitpunkt, ab dem Ihre Figur wieder einen Angriff ausführen kann, gibt der Computer durch einen glockenähnlichen Ton wieder.
<G-vec00316-003-s050><carry_out.ausführen><en> The exact point of time, when your character is ready can carry our another attack, is marked by the computer through a bell-like sound.
<G-vec00316-003-s051><carry_out.ausführen><de> Alles, was den Menschen daher als Evangelium nahegebracht werden soll, darf nur die Veredelung des Menschen, ein Umgestalten zur Liebe bezwecken, dann ist es eine rechte Weinbergsarbeit, die Meine Knechte auf Erden ausführen.
<G-vec00316-003-s051><carry_out.ausführen><en> Everything, what is therefore to be made accessible to men as Gospel, is only allowed to aim to achieve the ennobling of men, a transformation to love, then it is a right vineyard work, which my servants on earth carry out.
<G-vec00316-003-s052><carry_out.ausführen><de> In diesem Konto kann der Kunde dann Domainnamen und Postfächer hinzufügen, die Inhalte der Website bearbeiten und andere Aufgaben zur Hosting-Verwaltung ausführen.
<G-vec00316-003-s052><carry_out.ausführen><en> Under this account, the customer can add domain names and mailboxes, edit website content, and carry out other hosting management routines.
<G-vec00316-003-s053><carry_out.ausführen><de> Wenn wir uns wirklich bemühen, können wir die Zirbeldrüse in einem gewissen Rahmen wieder zur Funktion bringen, und dann wird sich dieses Organ langsam, sehr langsam, doch sukzessive wieder vergrößern und seine Funktionen dementsprechend kraftvoller ausführen können.
<G-vec00316-003-s053><carry_out.ausführen><en> Im If we truly go to a lot of effort, we can, to a certain extent, make the pineal gland function again, and then slowly, very slowly yet successively, this organ will enlarge again and, accordingly, be able to carry out its function more powerfully.
<G-vec00316-003-s054><carry_out.ausführen><de> Schaffen Sie Orientierung durch klare Handlungsvorgaben – damit jeder Mitarbeiter weiß, wie er seine Tätigkeiten ausführen soll.
<G-vec00316-003-s054><carry_out.ausführen><en> Create direction through a clear course of action so that each employee knows how to carry out their tasks.
<G-vec00316-003-s055><carry_out.ausführen><de> Nach dem Ablegen der Hufschmiedeprüfung kann er selbstständig Huf- und Beschlagschmiedearbeiten ausführen.
<G-vec00316-003-s055><carry_out.ausführen><en> After passing the farrier's exam they can carry out this work independently.
<G-vec00316-003-s056><carry_out.ausführen><de> Hinweis: Nach Ausführen dieses Vorgangs werden alle persönlichen Konfigurationsparameter im Mobile WiFi gelöscht.
<G-vec00316-003-s056><carry_out.ausführen><en> After you carry out this operation, the Mobile WiFi's personal configuration parameters will all be deleted.
<G-vec00503-002-s023><plead.ausführen><de> Darum spricht der HERR also: Siehe, ich will dir deine Sache ausführen und dich rächen; ich will ihr Meer austrocknen und ihre Brunnen versiegen lassen.
<G-vec00503-002-s023><plead.ausführen><en> Therefore thus saith Jehovah: Behold, I will plead thy cause, and take vengeance for thee; and I will dry up her sea, and make her fountain dry.
<G-vec00519-002-s117><peg.ausführen><de> Der Schlitten wird mit einem Elektromotor über eine Schubstange, eine Exzenterscheibe und ein geeignetes Getriebe so angetrieben, dass das Porzellanplättchen unter dem Porzellanstift eine einmalige Hin- und Rückbewegung von 10 mm Länge ausführt.
<G-vec00519-002-s117><peg.ausführen><en> The carriage is connected to an electric motor via a connecting rod, an eccentric cam and suitable gearing such that the porcelain plate is moved, once only, back and forth beneath the porcelain peg for a distance of 10 mm.
