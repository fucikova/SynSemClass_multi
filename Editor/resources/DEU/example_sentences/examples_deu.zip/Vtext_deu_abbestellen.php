<G-vec00297-002-s019><opt.abbestellen><de> Da diese Informationen wichtig für deine Nutzung der Sites sein können, kannst du diese Mitteilungen nicht abbestellen.
<G-vec00297-002-s019><opt.abbestellen><en> Because this information may be material to your use of the Sites, you may not opt out of receiving such communications.
<G-vec00297-002-s020><opt.abbestellen><de> Wir dürfen Ihre persönlichen Daten für Werbe- und Marketing-Zwecke nutzen, bis Sie den Empfang solcher Informationen abbestellen.
<G-vec00297-002-s020><opt.abbestellen><en> We may use your personal information for promotional and marketing purposes until you request to opt out of receiving such information.
<G-vec00297-002-s021><opt.abbestellen><de> Beachten Sie, dass Sie möglicherweise wichtige Informationen verpassen, wenn Sie einen Newsletter abbestellen, der mit einer bestimmten Aktivität verknüpft ist, für die Sie sich registriert haben.
<G-vec00297-002-s021><opt.abbestellen><en> Realize that when you opt out of a newsletter linked to a specific activity for which you have registered, you may miss important information.
<G-vec00297-002-s022><opt.abbestellen><de> 3.1.4(vorausgesetzt, dass Sie diese Möglichkeit nicht abbestellen) Sie über künftige Veranstaltungen, Angebote und Promos des Betreibers auf dem Laufenden zu halten.
<G-vec00297-002-s022><opt.abbestellen><en> 3.1.4(provided that You do not “opt out” from this option), to keep You informed of future events, offers and promotions from the Operator.
<G-vec00297-002-s023><opt.abbestellen><de> Sie können das Newsletter-Abonnement jederzeit auf „Meine Seite“ abbestellen.
<G-vec00297-002-s023><opt.abbestellen><en> You can you opt out of receiving the newsletter at any time via My Page.
<G-vec00297-002-s024><opt.abbestellen><de> Den Bezug von E-Mails können Sie jederzeit abbestellen, indem Sie den am Ende eines jeden Newsletters eingefügten Link anklicken.
<G-vec00297-002-s024><opt.abbestellen><en> You can opt out of receiving e-mails at any time by clicking on the link at the end of any newsletter.
<G-vec00297-002-s025><opt.abbestellen><de> Du kannst unseren Newsletter jederzeit wieder abbestellen.
<G-vec00297-002-s025><opt.abbestellen><en> You can opt out of our newsletters at any time.
<G-vec00297-002-s026><opt.abbestellen><de> Nutzen Sie unsere Apps, so können wir Ihnen auch Push-Benachrichtigungen zusenden, die Sie über die App-Einstellungen auch wieder abbestellen können.
<G-vec00297-002-s026><opt.abbestellen><en> If you are using our apps we may also send you push notifications which you can opt out of receiving using the app settings.
<G-vec00297-002-s027><opt.abbestellen><de> Obwohl wir sicherstellen, dass Anzahl und Häufigkeit der von uns versandten Newsletter im Rahmen bleiben, kannst du diese selbstverständlich jederzeit abbestellen – oder abonnieren (wir sind trotzdem traurig, wenn du sie abbestellst).
<G-vec00297-002-s027><opt.abbestellen><en> Updated Follow Although we make sure to limit the number and frequency of our newsletters, you can of course opt in or out of them anytime (we’ll still be sad to see you go).
<G-vec00297-002-s028><opt.abbestellen><de> Die Benachrichtigungen können Sie jederzeit abbestellen, indem Sie auf den in der E-Mail enthaltenen Link klicken.
<G-vec00297-002-s028><opt.abbestellen><en> You can opt out anytime by clicking the link contained in the email.
<G-vec00297-002-s029><opt.abbestellen><de> Wenn Sie Werbe-E-Mails mit Empfehlungen oder anderen Informationen, die Sie unserer Meinung nach interessieren könnten, abbestellen, können wir Ihnen weiterhin E-Mails zu Ihrem Konto oder anderen Dienstleistungen, die Sie von uns angefordert oder erhalten haben, schicken.
<G-vec00297-002-s029><opt.abbestellen><en> If You opt out of receiving emails about recommendations or other information We think may interest You, We may still send You e-mails about your account or any services You have requested or received from us. SECURITY
<G-vec00198-002-s038><cancel.abbestellen><de> Den Newsletter können Sie auch im eingeloggten Zustand unter MEIN BENUTZERKONTO „Allgemeines Abonnement“ abbestellen.
<G-vec00198-002-s038><cancel.abbestellen><en> You can also cancel the newsletter when you are logged in under MY USER ACCOUNT “General subscription”.
<G-vec00198-002-s039><cancel.abbestellen><de> Sie können den Aboservice jederzeit wieder abbestellen.
<G-vec00198-002-s039><cancel.abbestellen><en> Of course, you can cancel your subscription at any time.
<G-vec00198-002-s040><cancel.abbestellen><de> Des Weiteren können Sie den Newsletter auch direkt auf der Website abbestellen.
<G-vec00198-002-s040><cancel.abbestellen><en> Furthermore, you can also cancel the newsletter directly on the website.
<G-vec00198-002-s041><cancel.abbestellen><de> Sie können den Newsletter jederzeit über den dafür vorgesehenen Link im Newsletter oder durch entsprechende Nachricht an den eingangs genannten Verantwortlichen abbestellen.
<G-vec00198-002-s041><cancel.abbestellen><en> You can cancel the newsletter at any time by clicking the link included in every newsletter, or by sending an email to the data controller named above.
<G-vec00198-002-s042><cancel.abbestellen><de> Sie können den Newsletter jederzeit kostenlos abbestellen.
<G-vec00198-002-s042><cancel.abbestellen><en> You can cancel the newsletter anytime free of charge.
<G-vec00198-002-s043><cancel.abbestellen><de> Darin werden Sie Hinweise finden, wie Sie das Kommentarabonnement jederzeit wieder abbestellen können.
<G-vec00198-002-s043><cancel.abbestellen><en> There you will find information on how you can cancel your comment subscription at any time.
<G-vec00198-002-s044><cancel.abbestellen><de> Die Benachrichtigungen können Sie jederzeit abbestellen, indem Sie auf den in der E-Mail enthaltenen Link klicken.
<G-vec00198-002-s044><cancel.abbestellen><en> You can cancel the notifications at any time by clicking on the link in the email.
<G-vec00198-002-s045><cancel.abbestellen><de> Nutzer können laufende Kommentarabonnements jederzeit abbestellen.
<G-vec00198-002-s045><cancel.abbestellen><en> Users may cancel comment subscriptions at any time.
<G-vec00198-002-s046><cancel.abbestellen><de> Kursteilnehmern, die eine bestätigte Reservierung weniger als zehn Werktage vor dem Kurs abbestellen und keine Austauschperson zum Füllen des Kurses haben, werden 100 Prozent der vollen Kursgebühr in Rechnung gestellt.
<G-vec00198-002-s046><cancel.abbestellen><en> Attendees who cancel a confirmed enrollment less than ten business days before the class and fail to provide a qualified replacement to fill the enrollment will be billed for one hundred percent of the full tuition fee.
<G-vec00198-002-s047><cancel.abbestellen><de> Diesen Dienst können Sie jederzeit über den Newsletter wieder abbestellen.
<G-vec00198-002-s047><cancel.abbestellen><en> You can cancel this service again via the newsletter at any time you want.
<G-vec00198-002-s048><cancel.abbestellen><de> Alle Pläne sind Monatspläne, die Sie jederzeit abbestellen können wenn Sie es wünschen.
<G-vec00198-002-s048><cancel.abbestellen><en> All plans are monthly plans and you can cancel anytime if you do not wish to continue.
<G-vec00198-002-s049><cancel.abbestellen><de> Wenn Sie den abonnierten Newsletter abbestellen möchten, so können Sie uns entweder eine E-Mail zusenden oder über einen Link am Ende des Newsletters eine Stornierung vornehmen oder hier klicken.
<G-vec00198-002-s049><cancel.abbestellen><en> If you wish to cancel your subscription to the newsletter, you can either send us an e-mail, or carry out cancellation by using the respective link at the end of the newsletter or by clicking here.
<G-vec00198-002-s050><cancel.abbestellen><de> Sofern Sie bestätigen, nutzen wir Ihre E-Mail-Adresse so lange zum Mailversand, bis Sie den Mail Service abbestellen.
<G-vec00198-002-s050><cancel.abbestellen><en> If you confirm, we will use your e-mail address to automatically send you e-mails until you cancel the e-mail service.
<G-vec00198-002-s051><cancel.abbestellen><de> Ihre Einwilligung in die Übersendung eines Newsletters können Sie jederzeit widerrufen und das jeweilige Abonnement abbestellen.
<G-vec00198-002-s051><cancel.abbestellen><en> You can revoke your consent regarding the transmission of a newsletter at any time and cancel to the respective subscription.
<G-vec00198-002-s052><cancel.abbestellen><de> Abbestellung / Änderungen Der Mieter kann bis spätestens 45 Tage vor Ankunft abbestellen oder seinen Aufenthalt ändern.
<G-vec00198-002-s052><cancel.abbestellen><en> The tenant may cancel or alter his/her agreement 45 days before arrival at the latest.
<G-vec00198-002-s053><cancel.abbestellen><de> Den Newsletter können Sie jederzeit kostenfrei über den im Newsletter angegebenen Link abbestellen.
<G-vec00198-002-s053><cancel.abbestellen><en> You can cancel the Newsletter free of charge at any time via the link provided.
<G-vec00198-002-s054><cancel.abbestellen><de> Sie können ein Abonnement jederzeit abbestellen.
<G-vec00198-002-s054><cancel.abbestellen><en> You can cancel a subscription at any time.
<G-vec00198-002-s055><cancel.abbestellen><de> (5) Ihre Einwilligung in die Übersendung des Newsletters können Sie jederzeit widerrufen und den Newsletter abbestellen.
<G-vec00198-002-s055><cancel.abbestellen><en> (5) You may withdraw your consent to receive the newsletter and cancel the newsletter at any time.
<G-vec00198-002-s056><cancel.abbestellen><de> Zum Abmelden brauchen Sie nur noch Ihren Namen in das entsprechende Feld eingeben und auf die "Abbestellen"-Schaltfläche klicken.
<G-vec00198-002-s056><cancel.abbestellen><en> Then you just have to write your name into the correspondenting field and press the "Cancel"-Button to cancel receiving our Newsletter.
