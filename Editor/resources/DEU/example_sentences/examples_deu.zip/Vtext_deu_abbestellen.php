<G-vec00297-002-s019><opt.abbestellen><de> Da diese Informationen wichtig für deine Nutzung der Sites sein können, kannst du diese Mitteilungen nicht abbestellen.
<G-vec00297-002-s019><opt.abbestellen><en> Because this information may be material to your use of the Sites, you may not opt out of receiving such communications.
<G-vec00297-002-s020><opt.abbestellen><de> Wir dürfen Ihre persönlichen Daten für Werbe- und Marketing-Zwecke nutzen, bis Sie den Empfang solcher Informationen abbestellen.
<G-vec00297-002-s020><opt.abbestellen><en> We may use your personal information for promotional and marketing purposes until you request to opt out of receiving such information.
<G-vec00297-002-s021><opt.abbestellen><de> Beachten Sie, dass Sie möglicherweise wichtige Informationen verpassen, wenn Sie einen Newsletter abbestellen, der mit einer bestimmten Aktivität verknüpft ist, für die Sie sich registriert haben.
<G-vec00297-002-s021><opt.abbestellen><en> Realize that when you opt out of a newsletter linked to a specific activity for which you have registered, you may miss important information.
<G-vec00297-002-s022><opt.abbestellen><de> 3.1.4(vorausgesetzt, dass Sie diese Möglichkeit nicht abbestellen) Sie über künftige Veranstaltungen, Angebote und Promos des Betreibers auf dem Laufenden zu halten.
<G-vec00297-002-s022><opt.abbestellen><en> 3.1.4(provided that You do not “opt out” from this option), to keep You informed of future events, offers and promotions from the Operator.
<G-vec00297-002-s023><opt.abbestellen><de> Sie können das Newsletter-Abonnement jederzeit auf „Meine Seite“ abbestellen.
<G-vec00297-002-s023><opt.abbestellen><en> You can you opt out of receiving the newsletter at any time via My Page.
<G-vec00297-002-s024><opt.abbestellen><de> Den Bezug von E-Mails können Sie jederzeit abbestellen, indem Sie den am Ende eines jeden Newsletters eingefügten Link anklicken.
<G-vec00297-002-s024><opt.abbestellen><en> You can opt out of receiving e-mails at any time by clicking on the link at the end of any newsletter.
<G-vec00297-002-s025><opt.abbestellen><de> Du kannst unseren Newsletter jederzeit wieder abbestellen.
<G-vec00297-002-s025><opt.abbestellen><en> You can opt out of our newsletters at any time.
<G-vec00297-002-s026><opt.abbestellen><de> Nutzen Sie unsere Apps, so können wir Ihnen auch Push-Benachrichtigungen zusenden, die Sie über die App-Einstellungen auch wieder abbestellen können.
<G-vec00297-002-s026><opt.abbestellen><en> If you are using our apps we may also send you push notifications which you can opt out of receiving using the app settings.
<G-vec00297-002-s027><opt.abbestellen><de> Obwohl wir sicherstellen, dass Anzahl und Häufigkeit der von uns versandten Newsletter im Rahmen bleiben, kannst du diese selbstverständlich jederzeit abbestellen – oder abonnieren (wir sind trotzdem traurig, wenn du sie abbestellst).
<G-vec00297-002-s027><opt.abbestellen><en> Updated Follow Although we make sure to limit the number and frequency of our newsletters, you can of course opt in or out of them anytime (we’ll still be sad to see you go).
<G-vec00297-002-s028><opt.abbestellen><de> Die Benachrichtigungen können Sie jederzeit abbestellen, indem Sie auf den in der E-Mail enthaltenen Link klicken.
<G-vec00297-002-s028><opt.abbestellen><en> You can opt out anytime by clicking the link contained in the email.
<G-vec00297-002-s029><opt.abbestellen><de> Wenn Sie Werbe-E-Mails mit Empfehlungen oder anderen Informationen, die Sie unserer Meinung nach interessieren könnten, abbestellen, können wir Ihnen weiterhin E-Mails zu Ihrem Konto oder anderen Dienstleistungen, die Sie von uns angefordert oder erhalten haben, schicken.
<G-vec00297-002-s029><opt.abbestellen><en> If You opt out of receiving emails about recommendations or other information We think may interest You, We may still send You e-mails about your account or any services You have requested or received from us. SECURITY
