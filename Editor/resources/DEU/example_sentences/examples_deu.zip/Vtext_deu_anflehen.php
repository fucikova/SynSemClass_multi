<G-vec00272-001-s008><implore.anflehen><de> 16Rufe ich meinen Knecht, so antwortet er mir nicht, ich muss ihn mit meinem Munde anflehen.
<G-vec00272-001-s008><implore.anflehen><en> "16 ""I call to my servant, but he does not answer; I have to implore him with my mouth."
<G-vec00272-001-s009><implore.anflehen><de> Das Fernsehen zeigt Interviews mit Kiewer Ministern und Abgeordneten, die mit Tränen in den Augen Europa anflehen, ihr Land vor dem grimmigen Bären zu retten.
<G-vec00272-001-s009><implore.anflehen><en> The television shows interviews with Kiev ministers and deputies who tearfully implore Europe to save their country from the enraged bear.
<G-vec00503-001-s019><plead.anflehen><de> Während sie nach ihren Brüsten greift, benutzt Tia Full Nelsons, Körperklammern und mehr, um Rachel zu unterwerfen – die Tia nur anflehen kann, nicht so brutal zu sein.
<G-vec00503-001-s019><plead.anflehen><en> While reaching for her breasts, Tia uses full nelsons, body scissors and pins to subdue Rachel – who can only plead with Tia to stop being so rough.
<G-vec00272-001-s010><implore.anflehen><de> Ich bitte Sie, Gott für uns anzuflehen.
<G-vec00272-001-s010><implore.anflehen><en> I pray you to implore God for us.
<G-vec00272-001-s011><implore.anflehen><de> "3 Nachdem Mutter gesagt hatte: ""alles ist, wie es sein soll... das Göttliche ist, was Es ist, und genau so, wie Es sein will"", sollte es eigentlich nicht nötig sein, Ihn ""anzuflehen"", seine Vollkommenheit zu manifestieren."
<G-vec00272-001-s011><implore.anflehen><en> 3 As Mother had previously said that “all is as it should be... the Divine is what He is and exactly as He wants to be,” one shouldn't need to “implore” Him to manifest his Perfection.
<G-vec00272-001-s015><implore.anflehen><de> Und wenn die Kirche es verfehlt, die weiter reichende, kosmische Dimension vom Wort Gottes zu erkennen und sich nur um rein geistliche Fragen sorgt, dann leugnet sie ihre Sendung, die darin besteht, Gott anzuflehen für den Wandel des gesamten, verseuchten Kosmos - immer und überall, “an allen Orten seiner Herrschaft”.
<G-vec00272-001-s015><implore.anflehen><en> "And when the church fails to recognize the broader, cosmic dimensions of God’s Word, narrowing its concerns to purely spiritual matters, then it neglects its mission to implore God for the transformation - always and everywhere, ""in all places of His dominion"" - of the whole polluted cosmos."
<G-vec00272-001-s178><beg.anflehen><de> Tschechische Ärzte lehnen es ab, Geschlechtskrankheiten zu behandeln, welche die Folgen von Vergewaltigungen sind, obwohl sie von den deutschen Frauen darum angefleht werden.
<G-vec00272-001-s178><beg.anflehen><en> Czech doctors refuse to treat sexually transmitted diseases resulting from rape even though the German women beg them for help.
<G-vec00272-001-s073><implore.anflehen><de> Seine Erzählung über Lenins Krankheit schloß Bucharin damit, daß er sich über mein Bett warf, mich in der Decke umarmte und zu wimmern begann: „Seien Sie nicht krank, ich flehe Sie an, seien Sie nicht krank..., es gibt zwei Menschen, an deren Tod ich stets mit Entsetzen denke... das sind Iljitsch und Sie.“ Ich redete ihm freundschaftlich zu, um sein Gleichgewicht wiederherzustellen.
<G-vec00272-001-s073><implore.anflehen><en> He finished his account of Lenin’s illness by dropping down on my bed and muttering, as he pressed his arms about me over the blanket: “Don’t you get sick, I implore you, don’t get sick... There are two men of whose death I always think with horror... Lenin and you.” I raffled [?] him in a friendly way to restore his poise.
<G-vec00272-001-s074><implore.anflehen><de> Ich flehe Dich an, o Du König der Könige, Du Erbarmer der Unterdrückten, bestimme ihnen das Gute dieser und der zukünftigen Welt.
<G-vec00272-001-s074><implore.anflehen><en> I implore Thee, O Thou the King of kings and the Pitier of the downtrodden, to ordain for them the good of this world and of the world to come.
<G-vec00272-001-s244><beg.anflehen><de> 16 Rufe ich meinen Knecht, so antwortet er mir nicht, ich muss ihn mit meinem Munde anflehen.
<G-vec00272-001-s244><beg.anflehen><en> 16 I call my servant, but he gives no answer; I beg him with my mouth.
<G-vec00272-001-s245><beg.anflehen><de> Meinen Knecht rufe ich, und er antwortet nicht; mit meinem Mund muss ich ihn anflehen.
<G-vec00272-001-s245><beg.anflehen><en> I call to my servant, and he gives me no answer. I beg him with my mouth.
<G-vec00272-001-s099><implore.anflehen><de> In diesem Geist bitten wir die Führer der Welt davon Kenntnis zu nehmen, daß wir Gott demütig um Frieden anflehen.
<G-vec00272-001-s099><implore.anflehen><en> In that spirit, we invite the leaders of the world to know that we humbly implore God for peace.
<G-vec00272-001-s100><implore.anflehen><de> ich erlaube mir, Ihnen, Eminenz, mein Herz zu öffnen mit jenem Vertrauen, das mir Ihre Güte einflößt, und Sie um Ihre Unterstützung anzuflehen in einer schweren Sache, die möglicherweise Bedauern auslösen mag, die aber, wie Sie gleich sehen werden, für mich unerlässlich ist.
<G-vec00272-001-s100><implore.anflehen><en> Allow me to open my mind to Your Eminence with the trust that your goodness inspires in me and to implore your backing in a matter of great difficulty, which may perhaps displease you, but which you must recognize as indispensable for me.
<G-vec00272-002-s032><beg.anflehen><de> London wird wohl vergeblich darauf warten, dass die Deutschen sie anflehen zu bleiben.
<G-vec00272-002-s032><beg.anflehen><en> London will no doubt expect Germany to beg Britain to stay – but probably in vain.
<G-vec00361-002-s023><solicit.anflehen><de> Viertens sagen einige, dass die Innewohnung des Heiligen Geistes gegeben werden kann, wenn wir Gott aufrichtig anflehen, uns den Segen zu geben.
<G-vec00361-002-s023><solicit.anflehen><en> Fourthly, some say that the indwelling of the Holy Spirit can be given when we earnestly solicit God to give us the blessing.
<G-vec00503-002-s019><plead.anflehen><de> Gott und Markt können wir nicht steuern, nur gnädig stimmen, vielleicht anflehen, manchmal austricksen, aber niemals unter Kontrolle bekommen.
<G-vec00503-002-s019><plead.anflehen><en> The attitude was: „We cannot regulate god or the market, we can only attempt to secure their goodwill, perhaps plead or at times outwit them, but we can never get them under control.”
