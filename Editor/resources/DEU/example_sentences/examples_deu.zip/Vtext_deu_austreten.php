<G-vec00245-002-s097><emerge.austreten><de> Wird nun im Betrieb ein Gasfluß über den Anschlußstutzen 12 und den oder die Förderkanäle 13, 14 zur Austrittsöffnung 15 freigegeben, so werden die beiden Gewebeklebstoff-Komponenten, die durch Drücken der Spritzenkolben den Komponenten-Förderkanälen 8, 9 zugeführt werden, und die an den Austrittsöffnungen 10, 11 austreten, vom an der Austrittsöffnung 15 austretenden Gasstrom erfaßt und in io einem homogenen Sprühkegel unter guter Durchmischung zerstäubt.
<G-vec00245-002-s097><emerge.austreten><en> Is now in operation, a gas flow through the connection piece 12 and the or the conveying channels 13, 14 to the outlet opening 15 is released, the two tissue adhesive components, which are fed by pressing the syringe plunger the component conveying channels 8, 9, and to the outlet openings 10, 11 emerge, detected by the discharged at the outlet opening 15 the gas stream and atomized into io a homogeneous spray cone with thorough mixing.
<G-vec00245-002-s098><emerge.austreten><de> Da die obere Schicht sehr dünn ist, kann der Lichtblitz aus dem Material austreten.
<G-vec00245-002-s098><emerge.austreten><en> Since the upper layer is very thin, the light flash can emerge from the material.
<G-vec00245-002-s099><emerge.austreten><de> Die Konstruktion stellt eine Anzahl von Vorteilen dar, die von einer solchen Antriebsanordnung austreten.
<G-vec00245-002-s099><emerge.austreten><en> The design illustrates a number of advantages that emerge from such a propulsion arrangement.
<G-vec00321-002-s134><withdraw.austreten><de> Sie rief ihren Onkel an und bat ihn, ihrem Mann, ihrer Tochter und ihr selbst zu helfen, aus der Partei auszutreten.
<G-vec00321-002-s134><withdraw.austreten><en> She phoned her uncle and asked him to help her husband, her daughter and herself withdraw from the Party.
<G-vec00321-002-s135><withdraw.austreten><de> Der junge Mann glaubte, dass Falun Dafa gut und die Verfolgung schlecht ist und entschied sich, aus dem Kommunistischen Jugendverband der Partei auszutreten.
<G-vec00321-002-s135><withdraw.austreten><en> Believing that Falun Dafa is good and the persecution of Dafa is wrong, the young man chose to withdraw from the Communist Party Youth League.
<G-vec00321-002-s136><withdraw.austreten><de> Die Bestimmung spricht von der „Absicht“, auszutreten, und nicht vom Austritt selbst, der nur nach einem Abkommen oder ohne ein solches nach Ablauf der Zweijahresfrist erfolgen kann.
<G-vec00321-002-s136><withdraw.austreten><en> The provision refers to the notification of the ‘intention’ to withdraw, and not to withdrawal itself, because withdrawal may only occur after the agreement is reached or, in the absence of an agreement, after two years have elapsed.
<G-vec00321-002-s137><withdraw.austreten><de> Als ich mich einige Zeit darauf konzentrierte, die Wahrheit zu erklären und Menschen zu überzeugen, aus der Kommunistischen Partei Chinas (KPCh) und deren angegliederten Organisationen auszutreten, erkannte ich allmählich etwas: Ich sollte es am Arbeitsplatz besser machen, um alltäglichen Menschen ein Beispiel zu geben und die mächtige Tugend eines Dafa-Jüngers zu etablieren.
<G-vec00321-002-s137><withdraw.austreten><en> After devoting myself to truth clarification and convincing people to withdraw from the Chinese Communist Party (CCP) and its affiliated associations for some time, I gradually realized that I should do better at work to set an example for everyday people and establish the mighty virtue of a Dafa disciple.
<G-vec00321-002-s138><withdraw.austreten><de> Weil mein Herz noch nicht ganz dazu bereit war, lehnte der erste Fußgänger es ab, aus der KPCh auszutreten.
<G-vec00321-002-s138><withdraw.austreten><en> Because my heart was not fully ready, the first pedestrian refused to withdraw from the Communist Party.
<G-vec00321-002-s139><withdraw.austreten><de> (1) Jeder Mitgliedstaat kann im Einklang mit seinen verfassungsrechtlichen Vorschriften beschließen, aus der Union auszutreten.
<G-vec00321-002-s139><withdraw.austreten><en> 1. Any Member State may decide to withdraw from the (European) Union in accordance with its own constitutional requirements.
<G-vec00321-002-s140><withdraw.austreten><de> Sie hat Menschen dazu überredet, aus der Kommunistischen Partei Chinas (KPCh) und ihren angegliederten Organisationen auszutreten und macht fleißig die drei Dinge, um Lebewesen zu erretten.
<G-vec00321-002-s140><withdraw.austreten><en> She has been persuading people to withdraw from the Chinese Communist Party (CCP) and its youth organizations and is diligently doing the three things to save sentient beings.
<G-vec00321-002-s141><withdraw.austreten><de> So entschied er sich tatsächlich, aus der KPCh und ihren angegliederten Organisationen auszutreten.
<G-vec00321-002-s141><withdraw.austreten><en> As a matter of fact, he decided on his own to withdraw from the CCP and its affiliated organisations.
<G-vec00321-002-s142><withdraw.austreten><de> Durch das Sortieren der Pakete in separate Warteschlangen für unterschiedliche COS-Klassen wird es Paketen mit höherer Priorität erlaubt, vor Paketen mit niedrigerer Priorität auszutreten, selbst wenn die Pakete mit der niedrigeren Priorität zuerst angekommen sind.
<G-vec00321-002-s142><withdraw.austreten><en> By sorting the packets into separate queues for different COS classes is allowed packets higher priority to withdraw before packets with lower priority, even if the packets have arrived with the lower priority first.
<G-vec00321-002-s143><withdraw.austreten><de> Die Entscheidung des Vereinigten Königreichs, aus der Europäischen Union auszutreten, ist beispiellos und wirft eine eine Reihe von politischen und rechtlichen Fragen auf.
<G-vec00321-002-s143><withdraw.austreten><en> The decision by the United Kingdom to withdraw from the European Union is unprecedented and has created a whole set of political and legal questions.
<G-vec00351-002-s056><leak.austreten><de> In Produktionspausen bilden das Fängerrohr und die Düse einen luftdichten Kreislauf: Keine Tinte kann aus dem Kreislauf austreten und keine Luft eintreten.
<G-vec00351-002-s056><leak.austreten><en> When production stops, the gutter and the nozzle form an airtight circuit: No ink may leak from the circulation and no air can come in.
<G-vec00351-002-s057><leak.austreten><de> Bei der Modellreihe Natura darf die Ladung unter keinen Umständen austreten.
<G-vec00351-002-s057><leak.austreten><en> In the Natura range it is essential that the cargo does not leak under any circumstances
<G-vec00351-002-s058><leak.austreten><de> Glas kann, wenn nicht gut geschützt, einfach brechen und Wasser kann natürlich in die (Hosen-)Tasche austreten.
<G-vec00351-002-s058><leak.austreten><en> Being glass they can break if not well protected and having water inside means that they can leak whilst in you pocket or bag.
<G-vec00351-002-s059><leak.austreten><de> Wenn Sie die Gerätekappe nicht richtig verschließen, kann die Flüssigkeit aus der Düsenspitze austreten.
<G-vec00351-002-s059><leak.austreten><en> If you don’t close the device cap correctly, the liquid may leak from the nozzle tip.
<G-vec00351-002-s060><leak.austreten><de> Ein Austreten in die Ostsee hätte zerstörerische Folgen für die Umwelt im gesamten Ostseeraum.
<G-vec00351-002-s060><leak.austreten><en> Any leak into the Baltic would have devastating repercussions for the environment in the entire Baltic Sea region.
<G-vec00351-002-s061><leak.austreten><de> Weich werdende Fette können aus dem Lager austreten.
<G-vec00351-002-s061><leak.austreten><en> Greases that soften may leak from the bearing cavity.
<G-vec00351-002-s062><leak.austreten><de> Ist kein ausreichender Schornsteinzug vorhanden, wird die Gaszufuhr abgestellt und ein Austreten von Gas vermieden.
<G-vec00351-002-s062><leak.austreten><en> If there is not sufficient chimney flue then the gas supply is shut off and a gas leak is prevented.
<G-vec00351-002-s063><leak.austreten><de> Der Knoten kann gegen eine Vene drücken, die den Druck in dieser Vene erhöhen kann, was zu Flüssigkeiten führen kann, die in das umgebende Gewebe austreten.
<G-vec00351-002-s063><leak.austreten><en> The lump can press against a vein which can increase the pressure in that vein, which can result in fluids that leak into the surrounding tissue.
<G-vec00351-002-s064><leak.austreten><de> Wenn der Beutel nicht richtig platziert ist, kann Geruch austreten.
<G-vec00351-002-s064><leak.austreten><en> If the bag is not placed in the right way odour can leak out.
<G-vec00351-002-s065><leak.austreten><de> Wie man sich bei einem Brand oder beim Austreten von giftigen Substanzen verhält, lernen die Astronauten im ISS-Modell der amerikanischen Raumfahrtbehörde NASA in Houston.
<G-vec00351-002-s065><leak.austreten><en> Google+ Training for emergencies Astronauts learn the actions to take during a fire or a toxic leak in the ISS mock-up at NASA Houston.
<G-vec00351-002-s066><leak.austreten><de> Dies verzögert die Dampffunktion und führt zum Austreten von Wasser.
<G-vec00351-002-s066><leak.austreten><en> This delays the steaming function, causing water to leak.
<G-vec00351-002-s067><leak.austreten><de> Nach dem Tauchen muss das Wasser austreten.
<G-vec00351-002-s067><leak.austreten><en> After dipping, the water must leak out.
<G-vec00351-002-s068><leak.austreten><de> Alle Wasserbetten haben eine Sicherheitsfolie um die Matratze, die bei einer eventuellen Perforation das austretende Wasser auffängt und dafür sorgt, daß kein Wasser aus Ihrem Bett austreten kann.
<G-vec00351-002-s068><leak.austreten><en> All waterbeds are fitted with a safety liner that ensures that in the event of a leak, no water can run out of your bed. 23.
<G-vec00380-002-s147><dispense.austreten><de> Zuerst den Siebträger entfernen, die Taste für die Kaffeeausgabe drücken und etwas Wasser aus der Gruppe austreten lassen.
<G-vec00380-002-s147><dispense.austreten><en> To begin, remove the brew basket and press the coffee dispense switch thus allowing some water to come out of the group.
