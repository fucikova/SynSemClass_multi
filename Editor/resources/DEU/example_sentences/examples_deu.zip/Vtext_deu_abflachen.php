<G-vec00463-002-s028><flatten.abflachen><de> Aber wenn man nur auf diesen negativen Geschichten beharrt, wird damit meine Erfahrung abgeflacht und viele andere Geschichten, die mich formten werden übersehen.
<G-vec00463-002-s028><flatten.abflachen><en> But to insist on only these negative stories is to flatten my experience and to overlook the many other stories that formed me.
