<G-vec00078-001-s025><affirm.affirmieren><de> Wir affirmieren sie laut, in unseren Tagebüchern, unseren Freuden gegenüber.
<G-vec00078-001-s025><affirm.affirmieren><en> We affirm them out loud, in our journals, to our friends.
<G-vec00078-001-s026><affirm.affirmieren><de> Diese Abgrenzung der Maschine von etwas, das den Menschen einfach verlängert oder ersetzt, beschreibt nicht nur die Verweigerung von Deleuze und Guattari, die gängige Figur der Herrschaft der Maschine über den Menschen zu affirmieren.
<G-vec00078-001-s026><affirm.affirmieren><en> By distinguishing the machine from something that simply extends or replaces the human being Deleuze and Guattari not only refuse to affirm the conventional figure of the machine's domination over the human being.
<G-vec00078-001-s027><affirm.affirmieren><de> 5 Ziele affirmieren und visualisieren Sie richten Ihre Intention auf diese Ziele und stellen sich vor, dass sie schon realisiert sind.
<G-vec00078-001-s027><affirm.affirmieren><en> 5 Identify, affirm and visualize goals You focus your attention on these goals and imagine that they have been realized
<G-vec00078-001-s028><affirm.affirmieren><de> Den zweiten Tag nützen wir dafür, deine Ziele abzustecken und wirkungsvoll zu visualisieren und zu affirmieren.
<G-vec00078-001-s028><affirm.affirmieren><en> We use the second day to define your objectives and to effectively visualize and affirm them.
<G-vec00078-001-s030><affirm.affirmieren><de> Nun, jetzt gib mir keine Liste von Ausnahmen, weil du dann deine Liste affirmierst.
<G-vec00078-001-s030><affirm.affirmieren><en> Now, now, don't give Me a list of exceptions, for then you affirm your list.
