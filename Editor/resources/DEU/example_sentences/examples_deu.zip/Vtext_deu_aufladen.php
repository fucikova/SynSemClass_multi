<G-vec00272-001-s057><charge.aufladen><de> Die Telekommunikationsfirmen möchten schwere Benutzer mehr aufladen.
<G-vec00272-001-s057><charge.aufladen><en> The wireless companies want to charge heavy users more.
<G-vec00272-001-s058><charge.aufladen><de> Die Batterien liefern mit 550 kWh genug Energie für eine Reichweite bis zu 400 km (250 Meilen) und lassen sich innerhalb von 90 Minuten auf rund 80 Prozent aufladen – um weitere 320 km (200 Meilen) zurückzulegen.
<G-vec00272-001-s058><charge.aufladen><en> The batteries provide 550Â kWh usable capacity, a range of up to 250 miles and have the ability to charge up to 80Â percent (providing a range of 200 miles) in about 90 minutes.
<G-vec00272-001-s059><charge.aufladen><de> Obwohl viele so gute Rate als eine Kreditkarte bieten würde, es ist daran zu erinnern, dass der Kurs am Tag Sie die Karte aufladen genommen wird, anstatt den Tag, den Sie Geld dafür ausgeben.
<G-vec00272-001-s059><charge.aufladen><en> Although many offer as good a rate as a credit card would, it’s worth remembering that the rate is taken at the date you charge the card up rather than the day you spend money on it.
<G-vec00272-001-s060><charge.aufladen><de> Wenn verlor danach müssten wir aufladen, um einen neuen Motor Karte neu zu laden.
<G-vec00272-001-s060><charge.aufladen><en> If lost after that we would have to charge to reload a new engine map.
<G-vec00272-001-s061><charge.aufladen><de> Möglich wird die lange Flugdauer durch die Verwendung von Karbonfasern, eine neue Batterietechnik sowie ultraleichte Solarzellen, welche die Akkus tagsüber so weit aufladen, dass die Drohne über Nacht einsatzfähig bleibt.
<G-vec00272-001-s061><charge.aufladen><en> The long flight time is possible thanks to the use of carbon fibers, a new battery technology, and ultra-light solar cells, which charge the batteries through the day sufficiently to allow it to remain in operation overnight.
<G-vec00272-001-s062><charge.aufladen><de> Sibenik wird ab nächster Woche ist die Funktion einer Solarbaum auf dem die Bürger in der Lage sein Handy aufladen, Laptops und andere Geräte.
<G-vec00272-001-s062><charge.aufladen><en> Sibenik will from next week is the function of a solar tree on which citizens will be able to charge mobile phones, laptops and other gadgets.
<G-vec00272-001-s063><charge.aufladen><de> Schießt Blitze, kann sich aufladen und kann Einheiten aufnehmen und dadurch seine Intensität erhöhen.
<G-vec00272-001-s063><charge.aufladen><en> Emits lightning and may charge and shelter units in order to increase its intensity.
<G-vec00272-001-s064><charge.aufladen><de> Ein 7500 mAh-Akku bietet eine Reichweite von bis zu 20 km, einen maximalen Steigwinkel von bis zu 25 ° und eine Höchstgeschwindigkeit von 20 km / h und nur 2,5 Stunden zum vollständigen Aufladen.
<G-vec00272-001-s064><charge.aufladen><en> A 7500 mAh battery offers up to 20 km range, a maximum climb angle of up to 25 ° and a maximum speed of 20 km / h, and only 2.5 hours to fully charge.
<G-vec00272-001-s065><charge.aufladen><de> Die Möglichkeit des Zahlens von Tausenden Dollar nie beiseite setzen, wenn Kaufen von einem Händler oder von einer spezifischen Autofirma, in der im Ende, sie dich mehr für das Interesse aufladen, dem Jahre zu auszahlen dauert.
<G-vec00272-001-s065><charge.aufladen><en> Never set aside the possibility of paying thousands of dollars when buying from a dealer or a specific car company, where in the end, they charge you more for the interest which takes years to pay off.
<G-vec00272-001-s066><charge.aufladen><de> Über die zwei frontal ausgerichteten USB-3.0-Anschlüsse lassen sich Ihre Controller und Mobilgeräte ganz einfach aufladen.
<G-vec00272-001-s066><charge.aufladen><en> Two front-facing USB 3.0 ports make it super convenient to charge your controllers and mobile devices.
<G-vec00272-001-s067><charge.aufladen><de> Die Batterie vor dem ersten Gebrauch zunächst aufladen, um gleich die beste Leistung zu erzielen.
<G-vec00272-001-s067><charge.aufladen><en> For best initial performance, charge battery before first use.
<G-vec00272-001-s068><charge.aufladen><de> Airwheel E3 smart e-Bike hat einen Hochleistungs-USB-Anschluss, der das Handy jederzeit und überall aufladen kann.
<G-vec00272-001-s068><charge.aufladen><en> Airwheel E3 smart electric bike has a high-efficiency USB connector that can charge the phone anytime and anywhere.
<G-vec00272-001-s069><charge.aufladen><de> Das START/STOP wurde speziell für 12V-EFB- (Enhanced Flooded Battery) und AGM-Batterien optimiert, kann aber auch herkömmliche 12V-Bleibatterien aufladen.
<G-vec00272-001-s069><charge.aufladen><en> START/STOP is optimized for use with 12 V EFB (Enhanced Flooded Battery) and AGM batteries, but it can charge ordinary 12 V lead-acid batteries as well.
<G-vec00272-001-s070><charge.aufladen><de> Jetzt bin ich ohne Telefon, und AT&T wird mich aufladen $500 zur Kündigung des Vertrags + neues Handy + neue 2 Jahres-Vertrag.
<G-vec00272-001-s070><charge.aufladen><en> Now I’m without a phone, and AT&T is going to charge me $500 for termination of contract + new phone + new 2 year contract.
<G-vec00272-001-s071><charge.aufladen><de> 1) 2,5 * 0,7 (Außendurchmesser * Innendurchmesser, ähnlich im Folgenden), kurz DC2507, vor allem für kleine elektronische Produkte, wie Panel-Computer, der aufgrund der Volumenbeschränkungen, derzeit bekannten Marke Panel Computer fast MicroUSB-Anschlüsse verwenden aufladen.
<G-vec00272-001-s071><charge.aufladen><en> 1) 2.5*0.7(outside diameter*inside diameter, similarly hereinafter), for short DC2507, mostly used for small size electronic products, such as panel computer that is due to volume limitations, at present, famous brand panel computer almost adopt MicroUSB connectors to charge.
<G-vec00272-001-s072><charge.aufladen><de> Wenn Sie beispielsweise Ihr iPhone nachts aufladen, wird es in der ersten Phase ungefähr aufgeladen 80% (genug, dass Sie das iPhone vom Aufladen entfernen können), gefolgt vom Rest bis zu 100% Das Laden ist sehr langsam.
<G-vec00272-001-s072><charge.aufladen><en> For example, if you charge your iPhone at night, in the first stage it will charge up to approximately 80% (enough that you can remove iPhone from charging), followed by the rest up to 100% its loading is very slow.
<G-vec00272-001-s073><charge.aufladen><de> Mit einer voll aufgeladenen PowerBar in Ihrer Tasche können Sie sicher sein, dass Sie Ihre Geräte immer und überall aufladen können - ohne dass Sie dabei von einer Steckdose abhängig sind.
<G-vec00272-001-s073><charge.aufladen><en> With a fully charged PowerBar in your bags, you can ensure that you will always be able to charge your devices anywhere anytime without having to depend on a power socket.
<G-vec00272-001-s074><charge.aufladen><de> Wenn Sie schlafen können sie ihren Electrisches Fahrrad kostenloss aufladen.
<G-vec00272-001-s074><charge.aufladen><en> During your sleep you can charge your electric bike for free.
<G-vec00272-001-s075><charge.aufladen><de> Aufladen angebot und den verkauf von feuerlöschern aller art,.
<G-vec00272-001-s075><charge.aufladen><en> We offer charge and hydrostatic sale.
