<G-vec00272-001-s057><charge.aufladen><de> Die Telekommunikationsfirmen möchten schwere Benutzer mehr aufladen.
<G-vec00272-001-s057><charge.aufladen><en> The wireless companies want to charge heavy users more.
<G-vec00272-001-s058><charge.aufladen><de> Die Batterien liefern mit 550 kWh genug Energie für eine Reichweite bis zu 400 km (250 Meilen) und lassen sich innerhalb von 90 Minuten auf rund 80 Prozent aufladen – um weitere 320 km (200 Meilen) zurückzulegen.
<G-vec00272-001-s058><charge.aufladen><en> The batteries provide 550Â kWh usable capacity, a range of up to 250 miles and have the ability to charge up to 80Â percent (providing a range of 200 miles) in about 90 minutes.
<G-vec00272-001-s059><charge.aufladen><de> Obwohl viele so gute Rate als eine Kreditkarte bieten würde, es ist daran zu erinnern, dass der Kurs am Tag Sie die Karte aufladen genommen wird, anstatt den Tag, den Sie Geld dafür ausgeben.
<G-vec00272-001-s059><charge.aufladen><en> Although many offer as good a rate as a credit card would, it’s worth remembering that the rate is taken at the date you charge the card up rather than the day you spend money on it.
<G-vec00272-001-s060><charge.aufladen><de> Wenn verlor danach müssten wir aufladen, um einen neuen Motor Karte neu zu laden.
<G-vec00272-001-s060><charge.aufladen><en> If lost after that we would have to charge to reload a new engine map.
<G-vec00272-001-s061><charge.aufladen><de> Möglich wird die lange Flugdauer durch die Verwendung von Karbonfasern, eine neue Batterietechnik sowie ultraleichte Solarzellen, welche die Akkus tagsüber so weit aufladen, dass die Drohne über Nacht einsatzfähig bleibt.
<G-vec00272-001-s061><charge.aufladen><en> The long flight time is possible thanks to the use of carbon fibers, a new battery technology, and ultra-light solar cells, which charge the batteries through the day sufficiently to allow it to remain in operation overnight.
<G-vec00272-001-s062><charge.aufladen><de> Sibenik wird ab nächster Woche ist die Funktion einer Solarbaum auf dem die Bürger in der Lage sein Handy aufladen, Laptops und andere Geräte.
<G-vec00272-001-s062><charge.aufladen><en> Sibenik will from next week is the function of a solar tree on which citizens will be able to charge mobile phones, laptops and other gadgets.
<G-vec00272-001-s063><charge.aufladen><de> Schießt Blitze, kann sich aufladen und kann Einheiten aufnehmen und dadurch seine Intensität erhöhen.
<G-vec00272-001-s063><charge.aufladen><en> Emits lightning and may charge and shelter units in order to increase its intensity.
<G-vec00272-001-s064><charge.aufladen><de> Ein 7500 mAh-Akku bietet eine Reichweite von bis zu 20 km, einen maximalen Steigwinkel von bis zu 25 ° und eine Höchstgeschwindigkeit von 20 km / h und nur 2,5 Stunden zum vollständigen Aufladen.
<G-vec00272-001-s064><charge.aufladen><en> A 7500 mAh battery offers up to 20 km range, a maximum climb angle of up to 25 ° and a maximum speed of 20 km / h, and only 2.5 hours to fully charge.
<G-vec00272-001-s065><charge.aufladen><de> Die Möglichkeit des Zahlens von Tausenden Dollar nie beiseite setzen, wenn Kaufen von einem Händler oder von einer spezifischen Autofirma, in der im Ende, sie dich mehr für das Interesse aufladen, dem Jahre zu auszahlen dauert.
<G-vec00272-001-s065><charge.aufladen><en> Never set aside the possibility of paying thousands of dollars when buying from a dealer or a specific car company, where in the end, they charge you more for the interest which takes years to pay off.
<G-vec00272-001-s066><charge.aufladen><de> Über die zwei frontal ausgerichteten USB-3.0-Anschlüsse lassen sich Ihre Controller und Mobilgeräte ganz einfach aufladen.
<G-vec00272-001-s066><charge.aufladen><en> Two front-facing USB 3.0 ports make it super convenient to charge your controllers and mobile devices.
<G-vec00272-001-s067><charge.aufladen><de> Die Batterie vor dem ersten Gebrauch zunächst aufladen, um gleich die beste Leistung zu erzielen.
<G-vec00272-001-s067><charge.aufladen><en> For best initial performance, charge battery before first use.
<G-vec00272-001-s068><charge.aufladen><de> Airwheel E3 smart e-Bike hat einen Hochleistungs-USB-Anschluss, der das Handy jederzeit und überall aufladen kann.
<G-vec00272-001-s068><charge.aufladen><en> Airwheel E3 smart electric bike has a high-efficiency USB connector that can charge the phone anytime and anywhere.
<G-vec00272-001-s069><charge.aufladen><de> Das START/STOP wurde speziell für 12V-EFB- (Enhanced Flooded Battery) und AGM-Batterien optimiert, kann aber auch herkömmliche 12V-Bleibatterien aufladen.
<G-vec00272-001-s069><charge.aufladen><en> START/STOP is optimized for use with 12 V EFB (Enhanced Flooded Battery) and AGM batteries, but it can charge ordinary 12 V lead-acid batteries as well.
<G-vec00272-001-s070><charge.aufladen><de> Jetzt bin ich ohne Telefon, und AT&T wird mich aufladen $500 zur Kündigung des Vertrags + neues Handy + neue 2 Jahres-Vertrag.
<G-vec00272-001-s070><charge.aufladen><en> Now I’m without a phone, and AT&T is going to charge me $500 for termination of contract + new phone + new 2 year contract.
<G-vec00272-001-s071><charge.aufladen><de> 1) 2,5 * 0,7 (Außendurchmesser * Innendurchmesser, ähnlich im Folgenden), kurz DC2507, vor allem für kleine elektronische Produkte, wie Panel-Computer, der aufgrund der Volumenbeschränkungen, derzeit bekannten Marke Panel Computer fast MicroUSB-Anschlüsse verwenden aufladen.
<G-vec00272-001-s071><charge.aufladen><en> 1) 2.5*0.7(outside diameter*inside diameter, similarly hereinafter), for short DC2507, mostly used for small size electronic products, such as panel computer that is due to volume limitations, at present, famous brand panel computer almost adopt MicroUSB connectors to charge.
<G-vec00272-001-s072><charge.aufladen><de> Wenn Sie beispielsweise Ihr iPhone nachts aufladen, wird es in der ersten Phase ungefähr aufgeladen 80% (genug, dass Sie das iPhone vom Aufladen entfernen können), gefolgt vom Rest bis zu 100% Das Laden ist sehr langsam.
<G-vec00272-001-s072><charge.aufladen><en> For example, if you charge your iPhone at night, in the first stage it will charge up to approximately 80% (enough that you can remove iPhone from charging), followed by the rest up to 100% its loading is very slow.
<G-vec00272-001-s073><charge.aufladen><de> Mit einer voll aufgeladenen PowerBar in Ihrer Tasche können Sie sicher sein, dass Sie Ihre Geräte immer und überall aufladen können - ohne dass Sie dabei von einer Steckdose abhängig sind.
<G-vec00272-001-s073><charge.aufladen><en> With a fully charged PowerBar in your bags, you can ensure that you will always be able to charge your devices anywhere anytime without having to depend on a power socket.
<G-vec00272-001-s074><charge.aufladen><de> Wenn Sie schlafen können sie ihren Electrisches Fahrrad kostenloss aufladen.
<G-vec00272-001-s074><charge.aufladen><en> During your sleep you can charge your electric bike for free.
<G-vec00272-001-s075><charge.aufladen><de> Aufladen angebot und den verkauf von feuerlöschern aller art,.
<G-vec00272-001-s075><charge.aufladen><en> We offer charge and hydrostatic sale.
<G-vec00230-002-s095><charge.aufladen><de> Diese neue App ermöglicht das Überwachen des Ladestands des eigenen Smartphones und zeigt an, wann es nötig ist, das Gerät rechtzeitig wieder aufzuladen, um die automatische Abschaltung zu verhindern.
<G-vec00230-002-s095><charge.aufladen><en> The new application allows you to monitor the battery level of your smartphone by indicating when to put the device on to charge in good time to prevent it from shutting down automatically.
<G-vec00230-002-s096><charge.aufladen><de> Mikro-USB: Schließen Sie an einen Wechselstrom-Adapter an, um die Batterie aufzuladen.
<G-vec00230-002-s096><charge.aufladen><en> Micro USB: Connect to an AC adapter to charge the battery.
<G-vec00230-002-s097><charge.aufladen><de> • Vermeiden Sie eine Verwendung des Geräts während des Ladevorgangs, um es schneller aufzuladen.
<G-vec00230-002-s097><charge.aufladen><en> • Avoid using your device while it's charging to help it charge faster.
<G-vec00230-002-s098><charge.aufladen><de> Um den Akku aufzuladen, öffnen Sie einfach den Reißverschluss seitlich am Kissen, um das Kabel des Ladegerätes an die USB-Buchse im Kissen anzuschließen.
<G-vec00230-002-s098><charge.aufladen><en> To charge the battery, simply open the zipper on the side of the pillow to connect the charger cable to the USB port in the pillow.
<G-vec00230-002-s099><charge.aufladen><de> Dank der Qi-Technologie brauchen Sie kein Ladekabel, um Ihr mobiles Gerät aufzuladen.
<G-vec00230-002-s099><charge.aufladen><en> With this technology you do not need a charging cable anymore to charge your mobile device.
<G-vec00230-002-s100><charge.aufladen><de> Diese Ladestation ermöglicht es Ihnen, Ihr Galaxy Note 8 über einen USB-C-Anschluss an die Ladestation anzuschließen und über einen USB-Anschluss an einem Computer oder Laptop Ihr Gerät aufzuladen sowie Ihre Daten zu synchronisieren.
<G-vec00230-002-s100><charge.aufladen><en> Utilising innovative pass-through technology, this charging dock allows you to connect your Galaxy S8 to the cradle via a USB-C connection and use a USB port on a computer or laptop to charge your device as well as synchronise your data.
<G-vec00230-002-s101><charge.aufladen><de> 10.000 mAh sind eine häufig gewählte Kapazität, da dies ausreicht, um ein Smartphone mehrmals aufzuladen.
<G-vec00230-002-s101><charge.aufladen><en> 10,000 mAh is a much chosen capacity because it is sufficient to charge a smartphone several times.
<G-vec00230-002-s102><charge.aufladen><de> WANDSTECKDOSE mindestens 24 Stunden in die Basisstation, um den Akku vollständig aufzuladen.
<G-vec00230-002-s102><charge.aufladen><en> 50 Place the handset on the base to charge for at least 24 hours.
<G-vec00230-002-s103><charge.aufladen><de> San Martino di Castrozza, Passo Rolle, Primiero und Vanoi geben Ihnen die Möglichkeit, Ihr Auto kostenlos aufzuladen.
<G-vec00230-002-s103><charge.aufladen><en> San Martino di Castrozza, Passo Rolle, Primiero and Vanoi have chosen to reward you, offering the possibility to charge your car for free...
<G-vec00230-002-s104><charge.aufladen><de> Mit einer Akkulaufzeit von bis zu 32 Stunden und der Möglichkeit während der Aufzeichnung per Powerbank aufzuladen bietet er genug Laufzeit sogar fü die längsten Ausfahrten.
<G-vec00230-002-s104><charge.aufladen><en> It provides up to 32 hours of battery life and allows you to charge via power bank while recording. TrainingPeaks Workout
<G-vec00230-002-s105><charge.aufladen><de> Zudem verfügt der Lautsprecher über den Qi-Standard zum induktiven Laden, sodass Sie Ihr Qi-kompatibles Gerät nur auf den Lautsprecher zu legen brauchen, um es kabellos aufzuladen.
<G-vec00230-002-s105><charge.aufladen><en> Also designed with Qi Inductive Charging capabilities, the speaker allows you to simply place your Qi compatible device on the speaker system for a wireless charge.
<G-vec00230-002-s106><charge.aufladen><de> Unterstützen Sie schnelles Aufladen, schnell, um Ihr Telefon aufzuladen.
<G-vec00230-002-s106><charge.aufladen><en> Support fast charging, quick to charge your phone.
<G-vec00230-002-s107><charge.aufladen><de> Wir empfehlen die Batterie mit der Standardanzahl von Ah (in den Batterie-Daten zu finden) aufzuladen.
<G-vec00230-002-s107><charge.aufladen><en> It is recommended to charge the battery with the standard number of Ah as shown in the Battery Data.
<G-vec00230-002-s108><charge.aufladen><de> Mit diesem Qualitätskabel können Sie Ihr Oppo RX17 Pro an Ihren Laptop oder Desktop anschließen, um Ihr Telefon aufzuladen und gleichzeitig Daten auszutauschen / zu synchronisieren.
<G-vec00230-002-s108><charge.aufladen><en> This quality cable allows you to connect your Sony Xperia XZ2 to your laptop or desktop, in order to charge your phone and exchange / sync data simultaneously.
<G-vec00230-002-s109><charge.aufladen><de> Externe USB- Business-Laptop-Tasche Schnittstelle mit integriertem Ladekabel: einfach für Sie, um Ihr Handy, Tablet und andere Geräte aufzuladen, ohne den Rucksack zu öffnen.
<G-vec00230-002-s109><charge.aufladen><en> External USB Business Laptop Bag interface with built - in charging cable:easy for you to charge your cell phone, tablet and other devices without opening up the backpack.
<G-vec00230-002-s110><charge.aufladen><de> Forscher haben einen Weg gefunden, Kaffee natürlich "aufzuladen" und seinen gesunden Polyphenolgehalt bedeutend zu erhöhen.12 Dies bedeutet, dass Menschen mehr von den einzigartigen vorteilhaften Verbindungen des Kaffees erhalten können, während sie weniger Kaffee trinken.
<G-vec00230-002-s110><charge.aufladen><en> Researchers have found a way to naturally "super charge" coffee and dramatically increase its healthy polyphenol content.12 This means people can obtain more of coffee's unique beneficial compounds while drinking less coffee.
<G-vec00230-002-s111><charge.aufladen><de> Nur 45 Minuten Aufladen über die USB - Ladestation reichen aus um das Produkt vollständig aufzuladen.
<G-vec00230-002-s111><charge.aufladen><en> Only 45 minutes of charging via USB dock is enough to fully charge the product.
<G-vec00230-002-s112><charge.aufladen><de> Schließe das Dock über das im Lieferumfang des iPad enthaltene USB-Kabel an deinen Computer an, um das iPad zu synchronisieren und seinen Akku aufzuladen.
<G-vec00230-002-s112><charge.aufladen><en> Connect the dock to your computer with the USB cable included with your iPad to sync iPad and charge its battery.
<G-vec00230-002-s113><charge.aufladen><de> Die Auto-Zigarette powered Dual-USB-Adapter ist sehr nützlich und bequem, um Ihre Geräte im Auto aufzuladen.
<G-vec00230-002-s113><charge.aufladen><en> The car cigarette powered dual USB adapter is very useful and convenient to charge your devices in the car.
<G-vec00407-002-s037><replenish.aufladen><de> So können Spieler Bankkarten verwenden oder ihr Guthaben direkt von einem Mobiltelefon aus aufladen, indem sie die entsprechende SMS senden.
<G-vec00407-002-s037><replenish.aufladen><en> So, gamblers will be able to use bank cards or replenish their balance directly from a mobile phone by sending the appropriate SMS.
<G-vec00407-002-s038><replenish.aufladen><de> Sie können das Guthaben auf eine der Arten aufladen.
<G-vec00407-002-s038><replenish.aufladen><en> You can replenish the balance in one of the ways.
<G-vec00778-002-s038><charge.aufladen><de> Dieses USB-Netzteil mit seinen vier USB-Anschlüssen, über die Sie vier Geräte gleichzeitig aufladen können, ist die perfekte Lösung, um Steckdosenplatz zu sparen, etwa wenn Familien viele Geräte aufzuladen haben oder Sie auf Reisen all Ihre Mobilgeräte gleichzeitig aufladen möchten.
<G-vec00778-002-s038><charge.aufladen><en> With its four USB ports that let you charge four devices at the same time, this USB AC adaptor is the perfect solution to save outlet space for families who have many devices to recharge, or to charge all your mobile devices simultaneously when travelling.
<G-vec00778-002-s039><charge.aufladen><de> Noch ein Highlight: Du kannst sie weltweit per USB 3.0 problemlos aufladen – besonders unterwegs ein praktisches Feature.
<G-vec00778-002-s039><charge.aufladen><en> Another highlight: You can charge it worldwide via USB 3.0 without any problems - a practical feature especially on the road.
<G-vec00778-002-s040><charge.aufladen><de> Unabhängig vom Anschluss Ihres Geräts können Sie Ihr Gerät aufladen.
<G-vec00778-002-s040><charge.aufladen><en> Regardless of the connector on your device, you can charge your device.
<G-vec00778-002-s041><charge.aufladen><de> Ab einem Ladestand von 20 Prozent leuchtet er rot, damit du weißt, dass du die Pill bald aufladen musst.
<G-vec00778-002-s041><charge.aufladen><en> When you’re at 20 percent battery life, it will glow red—so you will need to charge it soon after.
<G-vec00778-002-s042><charge.aufladen><de> Es kann die Akkulaufzeit Ihres 15 "Macbook Pro um 8 Stunden verlängern oder das iPhone XS sieben Mal aufladen.
<G-vec00778-002-s042><charge.aufladen><en> It can extend your 15" Macbook Pro battery life for 8 hours or charge your iPhone XS seven times.
<G-vec00778-002-s043><charge.aufladen><de> Sie können es überallhin mitnehmen, an Ihrem Schreibtisch aufbewahren oder damit ein verloren gegangenes Kabel ersetzen, sodass Sie immer eine Verbindung herstellen oder Ihr Gerät bei Bedarf aufladen können.
<G-vec00778-002-s043><charge.aufladen><en> Carry it with you, keep it at your desk, or replace the one you lost so you're always able to connect and charge when you need to.
<G-vec00778-002-s044><charge.aufladen><de> Wenn die Spiele auf deinem Handy die meisten Batterien essen und du musst es viele Male am Tag aufladen; Wenn Sie einen bequemeren Weg zum Spielen oder Verwenden von Apps wünschen, Wenn Sie mehr atemberaubende Funktionen erleben möchten, zögern Sie nicht, den Nox App Player zu benutzen.
<G-vec00778-002-s044><charge.aufladen><en> If the games on your phone is eating up most of the battery and you have to charge it many times a day; If you want a more convenient way to play games or use apps; If you want to experience more stunning functions; don't hesitate to use Nox App Player.
<G-vec00778-002-s045><charge.aufladen><de> Dieses Produkt enthält auch ein USB-C Ladekabel, so können Sie Ihre BlackBerry KEYone mit Leichtigkeit aufladen.
<G-vec00778-002-s045><charge.aufladen><en> This product also includes a USB-C charging cable, so you can charge your BlackBerry KEYone with ease.
<G-vec00778-002-s046><charge.aufladen><de> Über den zusätzlichen USB-Anschluss können Sie mit Ihrem Kabel gleichzeitig ein zweites Gerät aufladen.
<G-vec00778-002-s046><charge.aufladen><en> The additional USB port allows you to charge a second device at the same time using your cable.
<G-vec00778-002-s047><charge.aufladen><de> Ja, der Stand-By Modus deaktiviert die primären Funktionen der PS4 um den Energieverbrauch zu senken, auch wenn es in diesem Zustand immer noch den DUALSHOCK 4-Controller aufladen und System-Updates herunterladen kann.
<G-vec00778-002-s047><charge.aufladen><en> Yes, the PS4 system’s stand-by mode deactivates its primary functions to reduce energy usage, though it is still able to charge DUALSHOCK 4 wireless controllers and download system updates in this power-saving mode.
<G-vec00778-002-s048><charge.aufladen><de> Solange Sie dieses handliche und tragbare Ladegerät mitnehmen, können Sie den Akku Ihrer Kamera bequem aufladen.
<G-vec00778-002-s048><charge.aufladen><en> As long as you take along with this handy and portable charger, you can conveniently charge your camera battery.
<G-vec00778-002-s049><charge.aufladen><de> Gleichzeitig können Sie auch Ihre Geräte aufladen, so dass Ihnen die Batterie bei einem laufenden Spiel nie ausgeht.
<G-vec00778-002-s049><charge.aufladen><en> You can simultaneously charge your mobile device so you never run out of power half way. Manual download:
<G-vec00778-002-s050><charge.aufladen><de> Unternehmen können evway als eine Werbemöglichkeit für ihr jeweiliges Geschäft nutzen und damit die wachsende Gemeinschaft von Menschen erreichen, die mit E-Autos unterwegs sind und nach Ladestationen suchen, an denen sie zum Aufladen anhalten und gleichzeitig die nähere Umgebung erkunden können.
<G-vec00778-002-s050><charge.aufladen><en> Additionally, companies can use evway as a means for promoting their business in a given area, reaching the ever-growing community of people who drive electric vehicles and are always on the lookout for charging stations where they can charge their vehicle and also explore the surrounding area.
<G-vec00778-002-s051><charge.aufladen><de> Wir behalten uns das Recht vor, eine Bearbeitungsgebühr auf alle zurückgegebenen Produkte aufladen.
<G-vec00778-002-s051><charge.aufladen><en> We reserve the right to charge a handling fee on all returned products.
<G-vec00778-002-s052><charge.aufladen><de> So können Sie Ihren Trimmer rechtzeitig und vollständig aufladen, damit Sie der Akku während der Verwendung nicht im Stich lässt.
<G-vec00778-002-s052><charge.aufladen><en> This way, you can charge your trimmer on time and fully, so you won’t end up with an empty battery in the middle of your trim.
<G-vec00778-002-s053><charge.aufladen><de> Mit 12 Watt Leistung und zwei Anschlüssen, USB-A und USB-C, können Sie zwei Geräte effizient gleichzeitig aufladen.
<G-vec00778-002-s053><charge.aufladen><en> With 12W powering the dual USB-A and USB-C ports, you can efficiently charge two devices at the same time.
<G-vec00778-002-s054><charge.aufladen><de> Außerdem ist der neue Akku wasser- und staubdicht, enthält 6000 mAh Strom und kann Smartphones und Tablets mit über 2 A aufladen.
<G-vec00778-002-s054><charge.aufladen><en> What's more, the new battery is water- and dustproof, contains 6000 mAh of power and can charge smartphones and tablets with over 2A.
<G-vec00778-002-s055><charge.aufladen><de> Deine Galaxy-Geräte lassen sich jetzt effizient aufladen, indem du sie einfach auf die Rückseite des Galaxy S10 drauflegst.
<G-vec00778-002-s055><charge.aufladen><en> Now, you can charge your Galaxy devices wirelessly right on the back of your S10.
<G-vec00778-002-s056><charge.aufladen><de> Vor dem Anschließen müssen Sie bei kabellosen Kopfhörern oder Lautsprechern, die wiederaufladbare Akkus verwenden, diese vollständig gemäß den mit Ihren Kopfhörern oder Lautsprechern gelieferten Anweisungen aufladen.
<G-vec00778-002-s056><charge.aufladen><en> Before connecting, if the wireless headphones or speakers use rechargeable batteries, make sure to fully charge the batteries according to the instructions that came supplied with your headphones or speakers.
