<G-vec00078-001-s303><adopt.einnehmen><de> Denn bis heute gilt aus Erfahrung die Regel, dass ein tragfähiger Kompromiss innerhalb der EU immer dann am wahrscheinlichsten ist, wenn Deutschland und Frankreich eine gemeinsame Position einnehmen.
<G-vec00078-001-s303><adopt.einnehmen><en> In fact, experience has shown that a workable compromise within the EU is always most likely when Germany and France adopt a common position.
<G-vec00078-001-s304><adopt.einnehmen><de> Da zudem auch in unserer pluralen Gesellschaft keine Religion oder Überzeugung die Position einer selbstverständlich dominierenden Haltung einnehmen kann, gewinnt eine Respekt-Toleranz mehr und mehr an Bedeutung.
<G-vec00078-001-s304><adopt.einnehmen><en> In our pluralist society no religion or belief can adopt the position of a naturally dominant attitude, and therefore the concept of respectful tolerance is gaining more and more importance.
<G-vec00078-001-s305><adopt.einnehmen><de> Die Menschen müssen sich auf den Kopf stellen und eine neue Perspektive einnehmen.
<G-vec00078-001-s305><adopt.einnehmen><en> People have to turn things upside down and adopt a new perspective.
<G-vec00078-001-s306><adopt.einnehmen><de> Mögliche Deutung: Sie könnten versuchen, in Zukunft mit den Provokationen Ihres Sohnes so umzugehen, dass Sie eine Haltung der Offenheit einnehmen - es werden sich Ihnen dann vielleicht völlig neue Möglichkeiten eröffnen, mit der Situation umzugehen.
<G-vec00078-001-s306><adopt.einnehmen><en> Potential Reading: You could try to henceforth deal with the situation in the way that you adopt an attitude of openness. This might well make completely new approaches possible which you didn't even dream of before.
<G-vec00078-001-s307><adopt.einnehmen><de> Mitarbeiter müssen sich im Unternehmen und bei Kunden frei fühlen, um eine offene Haltung einnehmen zu können.
<G-vec00078-001-s307><adopt.einnehmen><en> People have to feel free within the company and with customers to adopt a vulnerable attitude.
<G-vec00078-001-s308><adopt.einnehmen><de> Ihr Meister sagte ihr, sie solle sich umdrehen und die 'Position' einnehmen, mit anderen Worten, Kopf runter, Arsch rauf.
<G-vec00078-001-s308><adopt.einnehmen><en> Her Master told her to turn round and to adopt the 'position', in other words, head down, ass up.
<G-vec00078-001-s309><adopt.einnehmen><de> Wenn Sie diese Perspektive einnehmen, ist es seltsam zu sagen, dass Europa auf dem empfangenden Ende eines massiven Flüchtlingsstrom.
<G-vec00078-001-s309><adopt.einnehmen><en> If you adopt this perspective, it is odd to say that Europe is on the receiving end of a massive refugee flow.
<G-vec00078-001-s310><adopt.einnehmen><de> So unterschiedlich unsere Geschäftseinheiten auch sind: Wir haben eine Geschichte, die uns verbindet, eine gemeinsame Haltung, die wir einnehmen, und eine einheitliche Strategie, die wir verfolgen – als ein Team.
<G-vec00078-001-s310><adopt.einnehmen><en> As varied as our business units may be, we have a history that unites us, a common attitude we adopt, and a uniform strategy we pursue – as a team.
<G-vec00078-001-s311><adopt.einnehmen><de> Zum Thema Finanztransaktionssteuer werde die zukünftige Regierung dieselbe Position einnehmen wie die derzeitige Regierung, betonte Xavier Bettel.
<G-vec00078-001-s311><adopt.einnehmen><en> Regarding the tax on financial transactions, the next government would adopt the same position as the current government, underlined Xavier Bettel.
<G-vec00078-001-s312><adopt.einnehmen><de> Dabei will AWD eine aktive Rolle auch bei der Marktkonsolidierung einnehmen und seine Marktposition im wichtigsten Kernmarkt Deutschland weiter stärken.
<G-vec00078-001-s312><adopt.einnehmen><en> AWD also intends to adopt an active role with the market’s consolidation and the Group’s market position in Germany, the most important core market.
<G-vec00078-001-s313><adopt.einnehmen><de> Andere sind skeptisch und setzen auf die EU als Vermittlerin, zumal Russland diese Rolle nicht einnehmen werde.
<G-vec00078-001-s313><adopt.einnehmen><en> Others are sceptical and call on the EU to mediate, particularly since they don't expect Russia to adopt this role.
<G-vec00078-001-s314><adopt.einnehmen><de> Wenn Du Deinen Shop mit YouTube vermarkten willst, solltest Du schon im Vorfeld die richtige Einstellung gegenüber Deiner Content-Marketing-Strategie einnehmen.
<G-vec00078-001-s314><adopt.einnehmen><en> So, if you want to market your store using YouTube, it might be a good idea to adopt a content marketing strategy mindset.
<G-vec00078-001-s315><adopt.einnehmen><de> - wenn wir diese Haltung einnehmen, wird der Heilige Geist nichts tun.
<G-vec00078-001-s315><adopt.einnehmen><en> - if we adopt that kind of attitude, the Holy Spirit will not do anything.
<G-vec00078-001-s316><adopt.einnehmen><de> Ein hohes protestantisches Arbeitsethos gepaart mit einer gewaltigen Arbeitskraft und stupendem Wissen ließen Harnack sowohl im Kaiserreich als auch der Weimarer Republik eine exzeptionelle Stellung im Wissenschaftsbetrieb einnehmen.
<G-vec00078-001-s316><adopt.einnehmen><en> A strong Protestant work ethic coupled with huge working capacity and stupendous knowledge enabled Harnack to adopt an exceptional position in academic life, both in the Kaiser's empire and in the Weimar Republic.
<G-vec00078-001-s317><adopt.einnehmen><de> Mögliche Deutung: Sie könnten versuchen, in Zukunft mit den Provokationen Ihres Sohnes so umzugehen, dass Sie eine Haltung der Liebe einnehmen, egal was er tut.
<G-vec00078-001-s317><adopt.einnehmen><en> Potential Reading: You could try to henceforth deal with the situation in the way that you adopt an attitude of love, no matter what your son does.
<G-vec00078-001-s318><adopt.einnehmen><de> Andere Perspektiven einnehmen führt häufig zum Öffnen neuer Wege.
<G-vec00078-001-s318><adopt.einnehmen><en> To adopt a different perspective often opens up new possibilities.
<G-vec00078-001-s319><adopt.einnehmen><de> Zu jenem Zeitpunkt war jedoch noch nicht klar, welche Haltung das Tribunal einnehmen würde.
<G-vec00078-001-s319><adopt.einnehmen><en> However, at that point in time, it had not yet been agreed what approach the Tribunal would adopt.
<G-vec00078-001-s320><adopt.einnehmen><de> Wie unser Glaube und unsere Einstellung und unsere Auffassungen und Ansichten sich ändern, so erschaffen wir unsere Vergangenheit neu; wenn wir ganz allgemein eine vergebende Einstellung einnehmen, verändern wir unsere Einstellung der Vergangenheit.
<G-vec00078-001-s320><adopt.einnehmen><en> As our beliefs and attitudes and approaches and outlooks change, we recreate the past; as we generally adopt a forgiving attitude, we change our attitude of the past.
<G-vec00078-001-s321><adopt.einnehmen><de> Um Erfolg zu haben, müssen die Fluggesellschaften den Blickwinkel ihrer Kunden kennen und einnehmen.
<G-vec00078-001-s321><adopt.einnehmen><en> In order to succeed, the airlines must know and adopt their customer's point of view.
<G-vec00169-001-s294><assume.einnehmen><de> Die Position, die wir in einer Beziehung einnehmen, und das Gefühl der Zugehörigkeit zu einer Gruppe kennzeichnen die jeweilige Stufe in der Entwicklung zum Du.
<G-vec00169-001-s294><assume.einnehmen><en> The position that we assume within a relationship and the feeling of belonging to a group, characterise the respective level in the development with regard to the other person.
<G-vec00169-001-s295><assume.einnehmen><de> Der bewußte Wille scheint einen entscheidenden Platz einnehmen zu wollen.
<G-vec00169-001-s295><assume.einnehmen><en> The conscious will seems to want to assume a larger role.
<G-vec00169-001-s296><assume.einnehmen><de> Ein Qubit ist das quantenmechanische Pendant zum Bit des klassischen Computers, kann aber nicht nur die Null und die Eins codieren, sondern auch alle möglichen Zustände dazwischen einnehmen.
<G-vec00169-001-s296><assume.einnehmen><en> A qubit is the quantum mechanical equivalent of the bit of a conventional computer. It can, however, not only encode the zero and the one, but assume all possible states in between as well.
<G-vec00169-001-s297><assume.einnehmen><de> Dabei wird die Unterscheidung wichtig zwischen den vielen Akteuren, die innerhalb der einzelnen Felder nur unbewusst die habituellen Vorgaben reproduzieren und damit deren „scholastische“, moralische und ästhetische Standards als Distinktionsgewinne etablieren und den wenigen, die eine eigentlich „unmögliche Position“[2] im Feld einnehmen und damit die Autonomie als gesellschaftliche Form zu adressieren und zu benutzen in der Lage sind, jene „Urheber großer symbolischer Revolutionen“ wie etwa Flaubert und Baudelaire, die gerade in ihrer Betonung von Form und Autonomie ein neues, das literarische Feld begründen konnten.
<G-vec00169-001-s297><assume.einnehmen><en> Here it becomes important to distinguish between the many actors, who only unconsciously reproduce habitual directives and thus establish their “scholastic”, moral and aesthetic standards as distinction gains, and the few who assume what is actually an “impossible position”[2] in the field and are therefore capable of addressing and using autonomy as a social form, those “authors of great symbolic revolutions”, such as Flaubert and Baudelaire, who were able to found a new field, the literary field, specifically in their emphasis on form and autonomy.
<G-vec00169-001-s298><assume.einnehmen><de> Die akkumulativ verwendeten Logos, ihrer ursprünglichen Signalwirkung beraubt, verweisen auf die mögliche Leere ästhetischer Codes und den Platz, den das imaginäre Gegenüber auf der Suche nach Sinn und Unsinn einnehmen muss.
<G-vec00169-001-s298><assume.einnehmen><en> The accumulatively used logos, robbed of their original signal effect, refer to a possible void of aesthetic codes and the place that an imaginary counterpart must assume in search of sense and nonsense.
<G-vec00169-001-s299><assume.einnehmen><de> In Zusammenarbeit mit der Messe Frankfurt stärken wir die internationale Position der Fachmesse nachhaltig und werden in der ostafrikanischen Sicherheitsbranche eine einzigartige Position einnehmen.
<G-vec00169-001-s299><assume.einnehmen><en> By working together with Messe Frankfurt, we will be able to strengthen the international position of the trade fair in the long term and to assume a unique position in the East African security sector.
<G-vec00169-001-s300><assume.einnehmen><de> Da kommunale EntsorgerInnen die Rolle der AuftragnehmerInnen einnehmen, ist es umso wichtiger, dass die VertreterInnen der KonsumentInnen, wie die AK, besser in den Austausch eingebunden werden.
<G-vec00169-001-s300><assume.einnehmen><en> Due to the fact that disposal contractors assume the role of agent it is even more important that representatives of the consumer, such as the AK, are more involved in the exchange.
<G-vec00169-001-s301><assume.einnehmen><de> Universitätsarchiv Angegliederte Einrichtungen Der Universität angegliedert sind selbstständige Einrichtungen, die sich der Lehre und/oder der Forschung widmen und gemäß Hochschulgesetz §35 die Stellung einer universitären Einrichtung einnehmen.
<G-vec00169-001-s301><assume.einnehmen><en> The university has a number of affiliated, independent institutes which are dedicated to research and/or teaching and which, in accordance with Section 35 of the Higher Education Act (HSG), assume the status of a university institute.
<G-vec00169-001-s302><assume.einnehmen><de> Einbezug der Zivilgesellschaft: Die Zivilgesellschaft soll einen wichtigen Platz in der Arbeit der internationalen Gremien für Nachhaltige Entwicklung einnehmen.
<G-vec00169-001-s302><assume.einnehmen><en> Civil society involvement: civil society should assume an important place in the work carried out by the international bodies for sustainable development.
<G-vec00169-001-s303><assume.einnehmen><de> Der Regisseur konnte seinen Platz in der Internationalen Jury nicht einnehmen, weil man ihn und seinen Regie-Kollegen Mohammad Rasoulof aufgrund eines geplanten Films in ihrem Heimatland zu sechs Jahren Gefängnis und 20 Jahren Berufsverbot verurteilt hatte.
<G-vec00169-001-s303><assume.einnehmen><en> He was unable to assume his role on the International Jury, because he and his director colleague Mohammad Rasoulof were sentenced to six years in prison and banned from working in their profession for 20 years.
<G-vec00169-001-s304><assume.einnehmen><de> Keine außerirdische Kraft darf unmittelbar annähern, oder eine nahe Umlaufbahn einnehmen, oder eine Landung vornehmen, oder Handel treiben, es sei denn, dies erfolgt offen und mit der ausdrücklichen Zustimmung der Bevölkerung der Erde, erlangt durch demokratische Mittel.
<G-vec00169-001-s304><assume.einnehmen><en> No extraterrestrial force shall make close approach, or assume close orbit, or make any landing, or engage in trade, except openly and with the expressed consent of the People of Earth achieved through a democratic means.
<G-vec00169-001-s305><assume.einnehmen><de> Sie können nun irgendeine Mudra-Stellung mit ihren Armen einnehmen, die sich für sie richtig und bequem anfühlt und sauber die Energien hält.
<G-vec00169-001-s305><assume.einnehmen><en> They can now assume any positions with their arms that feel appropriate, comfortable and cleanly hold the energies.
<G-vec00169-001-s306><assume.einnehmen><de> Im Bereich der Nanowissenschaften will KIT eine weltweit führende Rolle einnehmen.
<G-vec00169-001-s306><assume.einnehmen><en> In the area of nanosciences, KIT intends to assume a world leading role.
<G-vec00169-001-s307><assume.einnehmen><de> "Der Audi mit der Startnummer ""2"" profitierte unter anderem davon, dass der für Position zwei qualifizierte Toyota mit der Startnummer ""8"" seinen Platz in der Startaufstellung nicht einnehmen konnte."
<G-vec00169-001-s307><assume.einnehmen><en> Among other things, the Audi designated as car number '2' benefited from the fact that the number '8' Toyota, which had qualified in position two, could not assume its place on the grid.
<G-vec00169-001-s308><assume.einnehmen><de> Die neue Forschergruppe wird bei den Forschungs- und Entwicklungsarbeiten auf diesem Gebiet eine international führende Rolle einnehmen.
<G-vec00169-001-s308><assume.einnehmen><en> The new work group will assume a globally leading role in research and development in this field.
<G-vec00345-001-s294><assume.einnehmen><de> Die Position, die wir in einer Beziehung einnehmen, und das Gefühl der Zugehörigkeit zu einer Gruppe kennzeichnen die jeweilige Stufe in der Entwicklung zum Du.
<G-vec00345-001-s294><assume.einnehmen><en> The position that we assume within a relationship and the feeling of belonging to a group, characterise the respective level in the development with regard to the other person.
<G-vec00345-001-s295><assume.einnehmen><de> Der bewußte Wille scheint einen entscheidenden Platz einnehmen zu wollen.
<G-vec00345-001-s295><assume.einnehmen><en> The conscious will seems to want to assume a larger role.
<G-vec00345-001-s296><assume.einnehmen><de> Ein Qubit ist das quantenmechanische Pendant zum Bit des klassischen Computers, kann aber nicht nur die Null und die Eins codieren, sondern auch alle möglichen Zustände dazwischen einnehmen.
<G-vec00345-001-s296><assume.einnehmen><en> A qubit is the quantum mechanical equivalent of the bit of a conventional computer. It can, however, not only encode the zero and the one, but assume all possible states in between as well.
<G-vec00345-001-s297><assume.einnehmen><de> Dabei wird die Unterscheidung wichtig zwischen den vielen Akteuren, die innerhalb der einzelnen Felder nur unbewusst die habituellen Vorgaben reproduzieren und damit deren „scholastische“, moralische und ästhetische Standards als Distinktionsgewinne etablieren und den wenigen, die eine eigentlich „unmögliche Position“[2] im Feld einnehmen und damit die Autonomie als gesellschaftliche Form zu adressieren und zu benutzen in der Lage sind, jene „Urheber großer symbolischer Revolutionen“ wie etwa Flaubert und Baudelaire, die gerade in ihrer Betonung von Form und Autonomie ein neues, das literarische Feld begründen konnten.
<G-vec00345-001-s297><assume.einnehmen><en> Here it becomes important to distinguish between the many actors, who only unconsciously reproduce habitual directives and thus establish their “scholastic”, moral and aesthetic standards as distinction gains, and the few who assume what is actually an “impossible position”[2] in the field and are therefore capable of addressing and using autonomy as a social form, those “authors of great symbolic revolutions”, such as Flaubert and Baudelaire, who were able to found a new field, the literary field, specifically in their emphasis on form and autonomy.
<G-vec00345-001-s298><assume.einnehmen><de> Die akkumulativ verwendeten Logos, ihrer ursprünglichen Signalwirkung beraubt, verweisen auf die mögliche Leere ästhetischer Codes und den Platz, den das imaginäre Gegenüber auf der Suche nach Sinn und Unsinn einnehmen muss.
<G-vec00345-001-s298><assume.einnehmen><en> The accumulatively used logos, robbed of their original signal effect, refer to a possible void of aesthetic codes and the place that an imaginary counterpart must assume in search of sense and nonsense.
<G-vec00345-001-s299><assume.einnehmen><de> In Zusammenarbeit mit der Messe Frankfurt stärken wir die internationale Position der Fachmesse nachhaltig und werden in der ostafrikanischen Sicherheitsbranche eine einzigartige Position einnehmen.
<G-vec00345-001-s299><assume.einnehmen><en> By working together with Messe Frankfurt, we will be able to strengthen the international position of the trade fair in the long term and to assume a unique position in the East African security sector.
<G-vec00345-001-s300><assume.einnehmen><de> Da kommunale EntsorgerInnen die Rolle der AuftragnehmerInnen einnehmen, ist es umso wichtiger, dass die VertreterInnen der KonsumentInnen, wie die AK, besser in den Austausch eingebunden werden.
<G-vec00345-001-s300><assume.einnehmen><en> Due to the fact that disposal contractors assume the role of agent it is even more important that representatives of the consumer, such as the AK, are more involved in the exchange.
<G-vec00345-001-s301><assume.einnehmen><de> Universitätsarchiv Angegliederte Einrichtungen Der Universität angegliedert sind selbstständige Einrichtungen, die sich der Lehre und/oder der Forschung widmen und gemäß Hochschulgesetz §35 die Stellung einer universitären Einrichtung einnehmen.
<G-vec00345-001-s301><assume.einnehmen><en> The university has a number of affiliated, independent institutes which are dedicated to research and/or teaching and which, in accordance with Section 35 of the Higher Education Act (HSG), assume the status of a university institute.
<G-vec00345-001-s302><assume.einnehmen><de> Einbezug der Zivilgesellschaft: Die Zivilgesellschaft soll einen wichtigen Platz in der Arbeit der internationalen Gremien für Nachhaltige Entwicklung einnehmen.
<G-vec00345-001-s302><assume.einnehmen><en> Civil society involvement: civil society should assume an important place in the work carried out by the international bodies for sustainable development.
<G-vec00345-001-s303><assume.einnehmen><de> Der Regisseur konnte seinen Platz in der Internationalen Jury nicht einnehmen, weil man ihn und seinen Regie-Kollegen Mohammad Rasoulof aufgrund eines geplanten Films in ihrem Heimatland zu sechs Jahren Gefängnis und 20 Jahren Berufsverbot verurteilt hatte.
<G-vec00345-001-s303><assume.einnehmen><en> He was unable to assume his role on the International Jury, because he and his director colleague Mohammad Rasoulof were sentenced to six years in prison and banned from working in their profession for 20 years.
<G-vec00345-001-s304><assume.einnehmen><de> Keine außerirdische Kraft darf unmittelbar annähern, oder eine nahe Umlaufbahn einnehmen, oder eine Landung vornehmen, oder Handel treiben, es sei denn, dies erfolgt offen und mit der ausdrücklichen Zustimmung der Bevölkerung der Erde, erlangt durch demokratische Mittel.
<G-vec00345-001-s304><assume.einnehmen><en> No extraterrestrial force shall make close approach, or assume close orbit, or make any landing, or engage in trade, except openly and with the expressed consent of the People of Earth achieved through a democratic means.
<G-vec00345-001-s305><assume.einnehmen><de> Sie können nun irgendeine Mudra-Stellung mit ihren Armen einnehmen, die sich für sie richtig und bequem anfühlt und sauber die Energien hält.
<G-vec00345-001-s305><assume.einnehmen><en> They can now assume any positions with their arms that feel appropriate, comfortable and cleanly hold the energies.
<G-vec00345-001-s306><assume.einnehmen><de> Im Bereich der Nanowissenschaften will KIT eine weltweit führende Rolle einnehmen.
<G-vec00345-001-s306><assume.einnehmen><en> In the area of nanosciences, KIT intends to assume a world leading role.
<G-vec00345-001-s307><assume.einnehmen><de> "Der Audi mit der Startnummer ""2"" profitierte unter anderem davon, dass der für Position zwei qualifizierte Toyota mit der Startnummer ""8"" seinen Platz in der Startaufstellung nicht einnehmen konnte."
<G-vec00345-001-s307><assume.einnehmen><en> Among other things, the Audi designated as car number '2' benefited from the fact that the number '8' Toyota, which had qualified in position two, could not assume its place on the grid.
<G-vec00345-001-s308><assume.einnehmen><de> Die neue Forschergruppe wird bei den Forschungs- und Entwicklungsarbeiten auf diesem Gebiet eine international führende Rolle einnehmen.
<G-vec00345-001-s308><assume.einnehmen><en> The new work group will assume a globally leading role in research and development in this field.
<G-vec00169-001-s281><capture.einnehmen><de> Sie sagen, dass Sie diesen Ort einnehmen werden, und dass die Männer dort einen Risikofaktor darstellen.
<G-vec00169-001-s281><capture.einnehmen><en> You say that you’re going to capture this place, and that men being there constitutes a risk factor.
<G-vec00169-001-s282><capture.einnehmen><de> 3 So spricht der HERR: Diese Stadt wird ganz gewiß in die Hand des Heeres des Königs von Babel gegeben werden, und er wird sie einnehmen.
<G-vec00169-001-s282><capture.einnehmen><en> "3 And this is what the LORD says: 'This city will certainly be handed over to the army of the king of Babylon, who will capture it.'"""
<G-vec00169-001-s283><capture.einnehmen><de> Durch den robusten Aufbau und den äuÃ erst groÃ en Messbereich von bis zu 570 km/h wird es auf dem Markt eine hervorragende Stellung einnehmen.
<G-vec00169-001-s283><capture.einnehmen><en> Its rugged construction and extremely wide measurement range up to 570 km/h will enable it to capture a leading position in the market.
<G-vec00169-001-s284><capture.einnehmen><de> 15 Und der König des Nordens wird kommen und einen Wall aufschütten und eine befestigte Stadt einnehmen.
<G-vec00169-001-s284><capture.einnehmen><en> 15 Then the king of the North will come and build up siege ramps and will capture a fortified city.
<G-vec00169-001-s285><capture.einnehmen><de> Sobald ihr einen der Kristalle am Rand der Karte kontrolliert, könnt ihr den Kristall in der Mitte einnehmen.
<G-vec00169-001-s285><capture.einnehmen><en> Once you have taken control of one of the crystals on the side of the map, you may capture the crystal in the middle.
<G-vec00169-001-s286><capture.einnehmen><de> _____ Cyrus würde Babylon einnehmen _____ Ronald Reagan würde Präsident der Vereinigten Staaten _____ Ägypten würde nie wieder eine starke, führende Macht werden _____ Moralischer Niedergang in den letzten Tagen _____ Eine 20-jährige Trockenheit in Deutschland _____ Babylon würde nach seiner Zerstörung nie wieder bewohnt werden 2.
<G-vec00169-001-s286><capture.einnehmen><en> _____ Cyrus would capture Babylon_____ George Washington would become president of the United States._____ Egypt would never again be a strong, leading nation._____ Morals would degenerate in the last days._____ Germany would have a 20-year drought._____ Babylon, once destroyed, would never be inhabited again.2.
<G-vec00169-001-s287><capture.einnehmen><de> Mit ihm kann man auf keinen Fall Durchhang geben, sonst wird es sicherlich Führung einnehmen.
<G-vec00169-001-s287><capture.einnehmen><en> With it in any case, you can not give slack, otherwise it will certainly capture leadership.
<G-vec00169-001-s288><capture.einnehmen><de> In Uplink fallen Funkverstärker in den Spielbereich, die die Spieler einnehmen und halten müssen, um Punkte zu sammeln.
<G-vec00169-001-s288><capture.einnehmen><en> In Uplink, communication relays are dropped into the play area and players must capture and hold them to gain points.
<G-vec00169-001-s289><capture.einnehmen><de> Wenn sich dein Anführer auf einem Burgfried befindet (es muss nicht zwingend sein eigener sein, du kannst auch die Burgen Anderer einnehmen) und dir genug Gold zur Verfügung steht, kannst du Einheiten ausbilden.
<G-vec00169-001-s289><capture.einnehmen><en> Whenever your commander is on a keep (not only your own, but also the keep of any enemy castles you capture) and you have enough gold, you can recruit units for your army.
<G-vec00169-001-s290><capture.einnehmen><de> Das Einnehmen von Seelen in einem so frühen Alter, ist eine verabscheuenswerte Handlung.
<G-vec00169-001-s290><capture.einnehmen><en> The capture of souls at such an early age is a despicable thing.
<G-vec00169-001-s291><capture.einnehmen><de> Vor einer Militäroffensive gegen die Kalifatsmetropole Mosul müssen irakische Truppen mehrere IS-Hochburgen am Euphrat einnehmen.
<G-vec00169-001-s291><capture.einnehmen><en> Before a military offensive is launched against the Caliphate metropolis, Mosul, Iraqi forces must capture several IS strongholds on the Euphrates.
<G-vec00169-001-s292><capture.einnehmen><de> Die angreifende Flotte muss in den Hafen segeln, ihn einnehmen und dabei den Kanonenbeschuss der Küstenverteidigung überstehen.
<G-vec00169-001-s292><capture.einnehmen><en> The attacking fleet must sail into the harbour and capture the port, running the gauntlet of coastal gun defences.
<G-vec00169-001-s293><capture.einnehmen><de> TR-Dustbowl BLU muss beide Control Points auf jeder Stage einnehmen, während RED dies verhindern muss.
<G-vec00169-001-s293><capture.einnehmen><en> BLU must capture both control points on every stage, whereas RED must defend the points.
<G-vec00169-001-s294><capture.einnehmen><de> 11:15 Und der König des Nordens wird kommen und einen Wall aufschütten und eine feste Stadt einnehmen.
<G-vec00169-001-s294><capture.einnehmen><en> 11:15 Then the king of the North will come and build up siege ramps and will capture a fortified city.
<G-vec00286-001-s281><capture.einnehmen><de> Sie sagen, dass Sie diesen Ort einnehmen werden, und dass die Männer dort einen Risikofaktor darstellen.
<G-vec00286-001-s281><capture.einnehmen><en> You say that you’re going to capture this place, and that men being there constitutes a risk factor.
<G-vec00286-001-s282><capture.einnehmen><de> 3 So spricht der HERR: Diese Stadt wird ganz gewiß in die Hand des Heeres des Königs von Babel gegeben werden, und er wird sie einnehmen.
<G-vec00286-001-s282><capture.einnehmen><en> "3 And this is what the LORD says: 'This city will certainly be handed over to the army of the king of Babylon, who will capture it.'"""
<G-vec00286-001-s283><capture.einnehmen><de> Durch den robusten Aufbau und den äuÃ erst groÃ en Messbereich von bis zu 570 km/h wird es auf dem Markt eine hervorragende Stellung einnehmen.
<G-vec00286-001-s283><capture.einnehmen><en> Its rugged construction and extremely wide measurement range up to 570 km/h will enable it to capture a leading position in the market.
<G-vec00286-001-s284><capture.einnehmen><de> 15 Und der König des Nordens wird kommen und einen Wall aufschütten und eine befestigte Stadt einnehmen.
<G-vec00286-001-s284><capture.einnehmen><en> 15 Then the king of the North will come and build up siege ramps and will capture a fortified city.
<G-vec00286-001-s285><capture.einnehmen><de> Sobald ihr einen der Kristalle am Rand der Karte kontrolliert, könnt ihr den Kristall in der Mitte einnehmen.
<G-vec00286-001-s285><capture.einnehmen><en> Once you have taken control of one of the crystals on the side of the map, you may capture the crystal in the middle.
<G-vec00286-001-s286><capture.einnehmen><de> _____ Cyrus würde Babylon einnehmen _____ Ronald Reagan würde Präsident der Vereinigten Staaten _____ Ägypten würde nie wieder eine starke, führende Macht werden _____ Moralischer Niedergang in den letzten Tagen _____ Eine 20-jährige Trockenheit in Deutschland _____ Babylon würde nach seiner Zerstörung nie wieder bewohnt werden 2.
<G-vec00286-001-s286><capture.einnehmen><en> _____ Cyrus would capture Babylon_____ George Washington would become president of the United States._____ Egypt would never again be a strong, leading nation._____ Morals would degenerate in the last days._____ Germany would have a 20-year drought._____ Babylon, once destroyed, would never be inhabited again.2.
<G-vec00286-001-s287><capture.einnehmen><de> Mit ihm kann man auf keinen Fall Durchhang geben, sonst wird es sicherlich Führung einnehmen.
<G-vec00286-001-s287><capture.einnehmen><en> With it in any case, you can not give slack, otherwise it will certainly capture leadership.
<G-vec00286-001-s288><capture.einnehmen><de> In Uplink fallen Funkverstärker in den Spielbereich, die die Spieler einnehmen und halten müssen, um Punkte zu sammeln.
<G-vec00286-001-s288><capture.einnehmen><en> In Uplink, communication relays are dropped into the play area and players must capture and hold them to gain points.
<G-vec00286-001-s289><capture.einnehmen><de> Wenn sich dein Anführer auf einem Burgfried befindet (es muss nicht zwingend sein eigener sein, du kannst auch die Burgen Anderer einnehmen) und dir genug Gold zur Verfügung steht, kannst du Einheiten ausbilden.
<G-vec00286-001-s289><capture.einnehmen><en> Whenever your commander is on a keep (not only your own, but also the keep of any enemy castles you capture) and you have enough gold, you can recruit units for your army.
<G-vec00286-001-s290><capture.einnehmen><de> Das Einnehmen von Seelen in einem so frühen Alter, ist eine verabscheuenswerte Handlung.
<G-vec00286-001-s290><capture.einnehmen><en> The capture of souls at such an early age is a despicable thing.
<G-vec00286-001-s291><capture.einnehmen><de> Vor einer Militäroffensive gegen die Kalifatsmetropole Mosul müssen irakische Truppen mehrere IS-Hochburgen am Euphrat einnehmen.
<G-vec00286-001-s291><capture.einnehmen><en> Before a military offensive is launched against the Caliphate metropolis, Mosul, Iraqi forces must capture several IS strongholds on the Euphrates.
<G-vec00286-001-s292><capture.einnehmen><de> Die angreifende Flotte muss in den Hafen segeln, ihn einnehmen und dabei den Kanonenbeschuss der Küstenverteidigung überstehen.
<G-vec00286-001-s292><capture.einnehmen><en> The attacking fleet must sail into the harbour and capture the port, running the gauntlet of coastal gun defences.
<G-vec00286-001-s293><capture.einnehmen><de> TR-Dustbowl BLU muss beide Control Points auf jeder Stage einnehmen, während RED dies verhindern muss.
<G-vec00286-001-s293><capture.einnehmen><en> BLU must capture both control points on every stage, whereas RED must defend the points.
<G-vec00286-001-s294><capture.einnehmen><de> 11:15 Und der König des Nordens wird kommen und einen Wall aufschütten und eine feste Stadt einnehmen.
<G-vec00286-001-s294><capture.einnehmen><en> 11:15 Then the king of the North will come and build up siege ramps and will capture a fortified city.
<G-vec00092-001-s209><take.einnehmen><de> sollten Es ist wichtig, dass Sie nicht zu viele Tabletten einnehmen.
<G-vec00092-001-s209><take.einnehmen><en> than you should It is important not to take too many tablets.
<G-vec00092-001-s210><take.einnehmen><de> Und danach eine andere Stellung einnehmen.
<G-vec00092-001-s210><take.einnehmen><en> And then take a different position.
<G-vec00092-001-s211><take.einnehmen><de> Nachdem klar war, das Video einen großen Part der Show einnehmen sollte, schlugen zunächst Greg Mills, der die Videoregie führt, und Produktionsleiter Marcus Pohl das G-LEC System vor und trafen damit genau den Nerv der Scorpions – und auch den von Lichtdesigner Rainer Becker.
<G-vec00092-001-s211><take.einnehmen><en> After it was clear that video technology would take a big part of the show, Greg Mills, who is the video producer, and the production manager Marcus Pohl proposed the G-LEC system and caught the taste of the Scorpions - and also of light designer Rainer Becker.
<G-vec00092-001-s212><take.einnehmen><de> Die Mitglieder des Teams werden verschiedene Rollen einnehmen, damit der WWM täglich gut vorankommt: Sprecher, Presse, Beziehungen zu Organisationen, Kommunikation, Video, Fotographie, Web Publishing, Logistik, medizinische und legale Angelegenheiten, etc.
<G-vec00092-001-s212><take.einnehmen><en> Members of the Base Team will take on different roles, in order to ensure that the WM works well from day to day: spokesperson, press, relations with outside organizations, communication, video, photography, web publishing, logistics, medical and legal issues, etc.
<G-vec00092-001-s213><take.einnehmen><de> Die Kinder vergöttern diese Platte, und bei Muttis wird viel Zeit seine Vorbereitung nicht einnehmen.
<G-vec00092-001-s213><take.einnehmen><en> Children adore this dish, and its preparation will not take a lot of time from mummies.
<G-vec00092-001-s214><take.einnehmen><de> Hinweis: Wenn Sie allergisch auf Meeresfrüchte sind sollten Sie dieses Produkt nicht einnehmen.
<G-vec00092-001-s214><take.einnehmen><en> Warning: Do not take this product if you are allergic to seafood.
<G-vec00092-001-s215><take.einnehmen><de> Sie können diese Medikamente auch bei übergewichtigen Menschen einnehmen.
<G-vec00092-001-s215><take.einnehmen><en> You can also take these drugs for people who are overweight.
<G-vec00092-001-s216><take.einnehmen><de> Die maximale Dosis, die Sie in jeder 24-stündigen Periode einnehmen sollen, ist 300 Mg.
<G-vec00092-001-s216><take.einnehmen><en> The maximum dose that you should take in any 24-hour period is 300 mg.
<G-vec00092-001-s217><take.einnehmen><de> "Ein neuer Praktizierender sagte zu dem Reporter: ""Ich möchte, dass die ganze Welt von der Verfolgung in China erfährt, damit die Menschen sich entscheiden können, welche Position sie einnehmen werden."
<G-vec00092-001-s217><take.einnehmen><en> "A new practitioner told the reporter, ""I want the whole world to know about the persecution in China, so that people will know which position they should take."
<G-vec00092-001-s218><take.einnehmen><de> Die Menge der Arzneimittel, die Sie einnehmen, hängt von der Stärke des Arzneimittels ab.
<G-vec00092-001-s218><take.einnehmen><en> The amount of medicine that you take depends on the strength of the medicine.
<G-vec00092-001-s219><take.einnehmen><de> 1937 hatte er erklärt: ‚Wir müssen die Araber vertreiben und ihren Platz einnehmen.
<G-vec00092-001-s219><take.einnehmen><en> In 1937 he had argued that “we must expel the Arabs and take their places.
<G-vec00092-001-s220><take.einnehmen><de> Sie müssen, um eine neue Anzeige Bitte beachten Sie, dass Sie gerade sehen können, die Gefahren mit wird rechtliche Schritte gegen die tatsächlichen Arzt oder die Klinik, falls etwas bewegt sich völlig falsch nicht einnehmen.
<G-vec00092-001-s220><take.einnehmen><en> You need to in order to indication a new please note that you just view the dangers along with will not take legal action against the actual physician or even the clinic in case a thing moves drastically wrong.
<G-vec00092-001-s221><take.einnehmen><de> Ich werde Dir auch zeigen, wie man diese Fehler beheben kann, so dass Deine Webseite ihren rechtmäßigen Platz in den Suchergebnissen einnehmen kann.
<G-vec00092-001-s221><take.einnehmen><en> I’ll also show you how to fix these sins, so that your web pages can take their rightful place in the search engines.
<G-vec00092-001-s222><take.einnehmen><de> Denn, im 'extremsten' Fall, tritt zwischen Festival und Filmemacher ein dritter Dienstleister, der eine zentrale Stellung in der Kommunikation und im Informationsfluss einnehmen könnte.
<G-vec00092-001-s222><take.einnehmen><en> In the most 'extreme' case, a third-party supplier might step between festival and filmmaker and take on a central role in communications and the flow of information.
<G-vec00092-001-s223><take.einnehmen><de> Nachmittags können die Gäste im Salón, im Garten oder in ihrem Zimmer den Tee einnehmen.
<G-vec00092-001-s223><take.einnehmen><en> In the afternoon, guests can take tea in the SalÃ3n, in the garden or in their room.
<G-vec00092-001-s224><take.einnehmen><de> Der Händler sollte eine beratende Rolle einnehmen: Ich habe den Markt für dich sondiert, lieber Konsument.
<G-vec00092-001-s224><take.einnehmen><en> The retailer should take on a consulting role: I've scoured the market for you, dear consumer.
<G-vec00092-001-s225><take.einnehmen><de> Nun wollen wir auch im Gesamtmarkt für Business Analytics und Performance Management eine führende Position einnehmen.
<G-vec00092-001-s225><take.einnehmen><en> And now we want to take a leading position in the overall market for business analytics and performance management as well.
<G-vec00092-001-s226><take.einnehmen><de> Der materielle sowie der immaterielle Wert und der Nutzen eine Produktes oder einer Marke sind danach die bestimmenden Faktoren für die Ermittlung der Position, die das Produkt und die Marke im Markt einnehmen muss.
<G-vec00092-001-s226><take.einnehmen><en> The material as well as immaterial value and the benefit of a product or a brand are thus the determining factors for the assessment of the position that the product has to take on the market.
<G-vec00092-001-s227><take.einnehmen><de> Viele Kinder verziehen angewidert das Gesicht, wenn sie Medikamente einnehmen sollen.
<G-vec00092-001-s227><take.einnehmen><en> Many children pull a disgusted face when they have to take medicine. Which is understandable.
<G-vec00078-001-s334><adopt.einnehmen><de> Mit anderen Worten wird danach verlangt, wieder eine Haltung zur Moderne einzunehmen.
<G-vec00078-001-s334><adopt.einnehmen><en> In other words, they are now asked to once again adopt an attitude towards modernity.
<G-vec00078-001-s335><adopt.einnehmen><de> die Fähigkeit, in theaterwissenschaftlichen und religiösen Fragen in einem breiteren sozialen Kontext zu diskutieren und in solchen Diskussionen einen vernünftigen und verantwortungsvollen Standpunkt einzunehmen.
<G-vec00078-001-s335><adopt.einnehmen><en> the capacity to enter into discussion on matters related to theology and religion in a broader social context and to adopt a reasonable and responsible standpoint in such discussions.
<G-vec00078-001-s336><adopt.einnehmen><de> "All das wurde mit dieser neuen Haltung gesehen – nicht ""neu"", das Bewußtsein war da, voll, es gab eine ganze Tendenz, diese Haltung mehr und mehr einzunehmen, aber nun war es GEWUSST, vollkommen gewußt: Was und wie man sein soll."
<G-vec00078-001-s336><adopt.einnehmen><en> So it all was seen in the new attitude – not “new,” the consciousness was fully there, there had been a whole tendency to increasingly adopt that attitude, but now it was KNOWN, fully known: what one must be, how one must be.
<G-vec00078-001-s337><adopt.einnehmen><de> In solchen Phasen Transaktionen durchzuführen kann zwar manchmal frustrierend sein, sie eröffnen jedoch bedeutende Chancen für aktive Investoren die bereit sind, eine nonkonformistische Sichtweise einzunehmen und die ein gewisses Maß an kurzfristiger Volatilität akzeptieren.
<G-vec00078-001-s337><adopt.einnehmen><en> Whilst it can sometimes be frustrating to transact during these periods, they crucially serve to create and highlight significant opportunities for active investors willing to adopt a contrarian view who are able to accept some short term volatility.
<G-vec00078-001-s338><adopt.einnehmen><de> Unsere, unter Einsatz dort und hier in Europa von Förderern weiterhin aufrechterhaltene Präsenz, ist eine dauerhafte Mahnung an die Bevölkerung dort, eine neue Haltung zu ihrer natürlichen Umgebung einzunehmen.
<G-vec00078-001-s338><adopt.einnehmen><en> Our continued presence with the support of our friends in Europe is a constant hint to the people there to adopt a different view to their environment.
<G-vec00078-001-s339><adopt.einnehmen><de> Das heißt, was bleibt, ist die richtigen Schlüsse zu ziehen und die Positionen einzunehmen, die zumindest über den Positionen sind, die im Moment von den freiesten und hellsichtigsten Russen verteidigt werden.
<G-vec00078-001-s339><adopt.einnehmen><en> That said, what remains is to draw the correct conclusions and adopt positions that are, at the very least, beyond the positions currently defended by the freest and most clear-sighted Russians.
<G-vec00078-001-s340><adopt.einnehmen><de> Das Chu, das für jeden die Notwendigkeit seine Rolle zu kennen, seinen Platz, sein Gleichgewicht zu finden und immer die richtige physische oder moralische Haltung einzunehmen, in Beziehung setzt.
<G-vec00078-001-s340><adopt.einnehmen><en> The Chu, which relates the need for everyone to know their role, to find their place and their balance and to ensure that they always adopt the right physical or moral attitude.
<G-vec00078-001-s341><adopt.einnehmen><de> Um unterschiedliche Entfernungen kontinuierlich fokussieren zu können, ist der Anwender gezwungen, eine unnatürliche Kopf- und Körperhaltung einzunehmen.
<G-vec00078-001-s341><adopt.einnehmen><en> To be able to focus continuously at different distances, spectacle wearers are forced to adopt an unnatural head position and body posture.
<G-vec00078-001-s342><adopt.einnehmen><de> In der ersten Schrift würde man vergeblich nach einem Hinweis auf diese Erscheinung und eine bestimmte Darlegung der Position suchen, die das neue Organ in dieser Frage einzunehmen gedenkt.
<G-vec00078-001-s342><adopt.einnehmen><en> We would seek in vain in the first announcement for any reference to this phenomenon, or a definite statement of the position the new organ intends to adopt on this question.
<G-vec00078-001-s343><adopt.einnehmen><de> """Von Eigeninteressen geblendet haben sie all ihre Unzulänglichkeit offenbart, eine auch nur im weitesten Sinne konstruktive Haltung einzunehmen."
<G-vec00078-001-s343><adopt.einnehmen><en> """Blinded by their own interests, they have revealed their inability to adopt any kind of constructive attitude."
<G-vec00078-001-s344><adopt.einnehmen><de> Es handelt sich um die Haltungen die einzunehmen sind und nicht um die Methoden, die man benutzen kann.
<G-vec00078-001-s344><adopt.einnehmen><en> It is about the attitudes to adopt and not the method to use.
<G-vec00078-001-s345><adopt.einnehmen><de> Allzu selten nutzen Filmindustrie und Kinopublikum gleichermaßen das Potential, über das Medium Film ungewohnte und fremde Perspektiven einzunehmen und so zu umfassenderen Welt-Bildern zu gelangen.
<G-vec00078-001-s345><adopt.einnehmen><en> Rarely film industry and movie audiences really make use of the possibility to adopt unfamiliar and strange perspectives and thus attain wider world-views through the medium of film.
<G-vec00078-001-s346><adopt.einnehmen><de> "Grundidee der Konferenz, die von Engagement Global mit organisiert wird, ""ist es andere Perspektiven einzunehmen, nicht nur die eigene eurozentrische, sondern auch die von Experten aus anderen Ländern zu hören"", erklärt Sabine Witt, Leiterin der Außenstelle Sachsen von Engagement Global."
<G-vec00078-001-s346><adopt.einnehmen><en> """The basic idea of the conference, co-organized by Engagement Global, the German service for development initiatives, is to adopt other views, not just Eurocentric ones, but also those of experts from other countries,"" explained Sabine Witt, head of the Saxony branch of Engagement Global."
<G-vec00078-001-s347><adopt.einnehmen><de> Aber ich muss deutlich darauf hinweisen, dass die Übung, die den klaren Zielvorstellungen des Buddha entspricht, voraussetzt, dass wir darauf vorbereitet sind, eine kritische Einstellung gegenüber der gewöhnlichen Funktionsweise unseres Geistes einzunehmen.
<G-vec00078-001-s347><adopt.einnehmen><en> But I have to emphasize that the training that accords with the Buddha's own clear intentions presupposes that we are prepared to adopt a critical stance towards the ordinary functioning of our mind.
<G-vec00078-001-s348><adopt.einnehmen><de> In intensiven Diskussionen bestärkten Eichbehörden, interessierte Kreise und Industrie die PTB in ihrem Bestreben, die Rolle einer kompetenten Unterstützerin aller Beteiligten einzunehmen.
<G-vec00078-001-s348><adopt.einnehmen><en> In in-depth discussions, verification authorities, interested parties and industrial firms all encouraged PTB in its efforts to adopt the role of a competent facilitator for all parties with a stake in this topic.
<G-vec00078-001-s349><adopt.einnehmen><de> In ihr baten sie die schwedische Regierung eine starke Haltung gegen die KPCh einzunehmen, sie aufzufordern, die Todesstrafe aufzugeben, die brutale Verfolgung von religiösen Gläubigen und Aktivisten mit abweichenden Meinungen zu beenden und alle unschuldigen Menschen freizulassen.
<G-vec00078-001-s349><adopt.einnehmen><en> In it, they asked the Swedish government to adopt a strong attitude towards the CCP, asking them to stop the death penalty, to stop the brutal persecution of religious believers and activists with different opinions, and to release all innocent people.
<G-vec00078-001-s350><adopt.einnehmen><de> Aus der Tatsache, daß die bürgerlichen Politiker in diesen, wie in allen Fragen keine prinzipielle Stellung einnehmen, daß sie Gelegenheitspolitik treiben, folgert der Sozialdemokrat Schippel auch für sich das Recht und die Notwendigkeit, den inneren reaktionären Kern des Schutzzolles und des Militarismus, respektive die fortschrittliche Bedeutung des Freihandels und der Miliz zu verkennen, das heißt gleichfalls keine prinzipielle Stellung zu den beiden Fragen einzunehmen.
<G-vec00078-001-s350><adopt.einnehmen><en> The fact that in these, as in all questions, the bourgeois politicians do not adopt a position based on principle, that they follow a policy of opportunism, leads the Social Democrat, Schippel, to conclude that he too has the same right. He therefore necessarily fails to appreciate the inner reactionary core of protective tariffs and of militarism, and, conversely, the progressive significance of free trade and of the militia; that is, he too fails to adopt a position based on principle towards the two questions.
<G-vec00078-001-s351><adopt.einnehmen><de> Der Kursleiter schlägt Ihnen vor, eine präzise, rigorose, anspruchsvolle Position einzunehmen.
<G-vec00078-001-s351><adopt.einnehmen><en> The practitioner asks you to adopt a specific, demanding, and strict position.
<G-vec00169-001-s309><assume.einnehmen><de> Ein zweiter Handgriff ermöglicht es dem Nutzer, eine für ihn komfortable Arbeitsposition einzunehmen oder diese bei Bedarf zu wechseln.
<G-vec00169-001-s309><assume.einnehmen><en> A second handle enables the user to assume a comfortable work position or to change the position if required.
<G-vec00169-001-s310><assume.einnehmen><de> Der Junge ist deshalb auf ihn eifersÃ1⁄4chtig und möchte ihn beiseite schieben, um seine Position einzunehmen.
<G-vec00169-001-s310><assume.einnehmen><en> The boy is jealous of him and would like to push him aside in order to assume his position.
<G-vec00169-001-s311><assume.einnehmen><de> Aber der Streit um den moralischen Universalismus betrifft Fragen der Gerechtigkeit; und diese Fragen lassen sich grundsätzlich mit Argumenten entscheiden, wenn alle Parteien bereit sind, die Perspektive des jeweils anderen einzunehmen, um den Konflikt im gleichmäßigen Interesse aller Seiten zu regeln.
<G-vec00169-001-s311><assume.einnehmen><en> But the dispute about moral universalism concerns issues of justice; and these issues can in principle be resolved when all parties are prepared to assume the perspective of the respective other in order to resolve the conflict in the equal interests of all sides.
<G-vec00169-001-s312><assume.einnehmen><de> Wiederholt hat er andere zur Teilnahme an seinen Projekten eingeladen, oder sie gebeten andere Rollen einzunehmen, um Alltag und sozio-ökonomische Bedingungen bestimmter Gruppen zu untersuchen.
<G-vec00169-001-s312><assume.einnehmen><en> Many times he has invited others to take part in his projects or asked them to assume different roles so as to explore everyday life and the socio-economic conditions of certain groups.
<G-vec00169-001-s313><assume.einnehmen><de> Ich bitte euch nicht, die Rolle einer gütigen Person einzunehmen.
<G-vec00169-001-s313><assume.einnehmen><en> I do not ask you to assume the role of a gracious person.
<G-vec00169-001-s314><assume.einnehmen><de> Die Entscheidung den üblichen Bühnenraum zu verlassen, ermöglicht dem Zuschauer neue Perspektiven einzunehmen.
<G-vec00169-001-s314><assume.einnehmen><en> The decision to leave the traditional space of the stage makes it possible for the audience to assume new perspectives.
<G-vec00169-001-s315><assume.einnehmen><de> Die unterschiedlichen Höhen der Causeway-Elemente animieren den Nutzer drei verschiedene Positionen einzunehmen: Sitzen, Stehen, Anlehnen und ermöglichen ergonomische Freiheit.
<G-vec00169-001-s315><assume.einnehmen><en> The various heights of the Causeway elements encourage users to assume one of three different positions: sitting, standing or leaning, and they allow ergonomic freedom.
<G-vec00169-001-s316><assume.einnehmen><de> Knien Sie auf das Board und versuchen Sie, eine stabile Position einzunehmen.
<G-vec00169-001-s316><assume.einnehmen><en> Knee down on the board and try to assume a stable position.
<G-vec00169-001-s317><assume.einnehmen><de> Nasarbajew ist bestrebt, Kasachstan durch sein konstruktives Engagement in internationalen Fragen eine Rolle auf der geopolitischen Bühne einzunehmen.
<G-vec00169-001-s317><assume.einnehmen><en> Nazarbayev is eager, Kazakhstan to assume a role on the geopolitical stage by its constructive engagement in international issues.
<G-vec00169-001-s318><assume.einnehmen><de> Die Begutachtenden bestärken den Forschungsbereich nachdrücklich darin, aufgrund seiner wissenschaftlichen Exzellenz und seines umfassenden Portfolios eine prominente Position in der Energieforschungslandschaft einzunehmen und den Dialog mit der Gesellschaft und Politik zu verstärken.
<G-vec00169-001-s318><assume.einnehmen><en> The experts strongly encourage the research field to assume a prominent position in the energy research landscape due to its scientific excellence and its comprehensive portfolio and to strengthen the dialogue with society and politics.
<G-vec00169-001-s319><assume.einnehmen><de> Durch den Abschluss des Zertifikatsstudiums erhalten Sie die Chance, eine vollkommen neue Rolle in Ihrem Unternehmen einzunehmen.
<G-vec00169-001-s319><assume.einnehmen><en> Completing studies for the certificate will provide you with the opportunity to assume a completely new role within your company.
<G-vec00169-001-s320><assume.einnehmen><de> Der ergonomische Sitz und die ergonomisch geformte Rückenlehne sind anatomisch geformt, um die Wirbelsäule zu unterstützen und dem Benutzer zu helfen, während des Trainings die korrekte Position einzunehmen.
<G-vec00169-001-s320><assume.einnehmen><en> The ergonomic seat and backrest are anatomically shaped to support the Spinal Column and to help users assume the correct position during workout.
<G-vec00169-001-s321><assume.einnehmen><de> Der Studiengang befähigt Sie eigenständige berufliche Positionen bei der Gestaltung gesellschaftlicher Transformationsprozesse einzunehmen.
<G-vec00169-001-s321><assume.einnehmen><en> The study programme qualifies you to assume a professional position in the shaping of societal transformation processes.
<G-vec00169-001-s322><assume.einnehmen><de> Nehmen Sie Platz auf dem Sitzball, um automatisch eine aufrechte Position einzunehmen.
<G-vec00169-001-s322><assume.einnehmen><en> Take a seat on the ball to assume automatically an upright position.
<G-vec00169-001-s323><assume.einnehmen><de> Sie zeigten, wie es dem Enzym gelingt, zwei Elektronen hintereinander auf Wasserstoffionen zu übertragen und dabei stabile Zwischenzustände einzunehmen.
<G-vec00169-001-s323><assume.einnehmen><en> They were able to demonstrate how the enzyme succeeds in transferring two electrons in succession to two hydrogen ions and thereby assume stable intermediate states.
<G-vec00345-001-s309><assume.einnehmen><de> Ein zweiter Handgriff ermöglicht es dem Nutzer, eine für ihn komfortable Arbeitsposition einzunehmen oder diese bei Bedarf zu wechseln.
<G-vec00345-001-s309><assume.einnehmen><en> A second handle enables the user to assume a comfortable work position or to change the position if required.
<G-vec00345-001-s310><assume.einnehmen><de> Der Junge ist deshalb auf ihn eifersÃ1⁄4chtig und möchte ihn beiseite schieben, um seine Position einzunehmen.
<G-vec00345-001-s310><assume.einnehmen><en> The boy is jealous of him and would like to push him aside in order to assume his position.
<G-vec00345-001-s311><assume.einnehmen><de> Aber der Streit um den moralischen Universalismus betrifft Fragen der Gerechtigkeit; und diese Fragen lassen sich grundsätzlich mit Argumenten entscheiden, wenn alle Parteien bereit sind, die Perspektive des jeweils anderen einzunehmen, um den Konflikt im gleichmäßigen Interesse aller Seiten zu regeln.
<G-vec00345-001-s311><assume.einnehmen><en> But the dispute about moral universalism concerns issues of justice; and these issues can in principle be resolved when all parties are prepared to assume the perspective of the respective other in order to resolve the conflict in the equal interests of all sides.
<G-vec00345-001-s312><assume.einnehmen><de> Wiederholt hat er andere zur Teilnahme an seinen Projekten eingeladen, oder sie gebeten andere Rollen einzunehmen, um Alltag und sozio-ökonomische Bedingungen bestimmter Gruppen zu untersuchen.
<G-vec00345-001-s312><assume.einnehmen><en> Many times he has invited others to take part in his projects or asked them to assume different roles so as to explore everyday life and the socio-economic conditions of certain groups.
<G-vec00345-001-s313><assume.einnehmen><de> Ich bitte euch nicht, die Rolle einer gütigen Person einzunehmen.
<G-vec00345-001-s313><assume.einnehmen><en> I do not ask you to assume the role of a gracious person.
<G-vec00345-001-s314><assume.einnehmen><de> Die Entscheidung den üblichen Bühnenraum zu verlassen, ermöglicht dem Zuschauer neue Perspektiven einzunehmen.
<G-vec00345-001-s314><assume.einnehmen><en> The decision to leave the traditional space of the stage makes it possible for the audience to assume new perspectives.
<G-vec00345-001-s315><assume.einnehmen><de> Die unterschiedlichen Höhen der Causeway-Elemente animieren den Nutzer drei verschiedene Positionen einzunehmen: Sitzen, Stehen, Anlehnen und ermöglichen ergonomische Freiheit.
<G-vec00345-001-s315><assume.einnehmen><en> The various heights of the Causeway elements encourage users to assume one of three different positions: sitting, standing or leaning, and they allow ergonomic freedom.
<G-vec00345-001-s316><assume.einnehmen><de> Knien Sie auf das Board und versuchen Sie, eine stabile Position einzunehmen.
<G-vec00345-001-s316><assume.einnehmen><en> Knee down on the board and try to assume a stable position.
<G-vec00345-001-s317><assume.einnehmen><de> Nasarbajew ist bestrebt, Kasachstan durch sein konstruktives Engagement in internationalen Fragen eine Rolle auf der geopolitischen Bühne einzunehmen.
<G-vec00345-001-s317><assume.einnehmen><en> Nazarbayev is eager, Kazakhstan to assume a role on the geopolitical stage by its constructive engagement in international issues.
<G-vec00345-001-s318><assume.einnehmen><de> Die Begutachtenden bestärken den Forschungsbereich nachdrücklich darin, aufgrund seiner wissenschaftlichen Exzellenz und seines umfassenden Portfolios eine prominente Position in der Energieforschungslandschaft einzunehmen und den Dialog mit der Gesellschaft und Politik zu verstärken.
<G-vec00345-001-s318><assume.einnehmen><en> The experts strongly encourage the research field to assume a prominent position in the energy research landscape due to its scientific excellence and its comprehensive portfolio and to strengthen the dialogue with society and politics.
<G-vec00345-001-s319><assume.einnehmen><de> Durch den Abschluss des Zertifikatsstudiums erhalten Sie die Chance, eine vollkommen neue Rolle in Ihrem Unternehmen einzunehmen.
<G-vec00345-001-s319><assume.einnehmen><en> Completing studies for the certificate will provide you with the opportunity to assume a completely new role within your company.
<G-vec00345-001-s320><assume.einnehmen><de> Der ergonomische Sitz und die ergonomisch geformte Rückenlehne sind anatomisch geformt, um die Wirbelsäule zu unterstützen und dem Benutzer zu helfen, während des Trainings die korrekte Position einzunehmen.
<G-vec00345-001-s320><assume.einnehmen><en> The ergonomic seat and backrest are anatomically shaped to support the Spinal Column and to help users assume the correct position during workout.
<G-vec00345-001-s321><assume.einnehmen><de> Der Studiengang befähigt Sie eigenständige berufliche Positionen bei der Gestaltung gesellschaftlicher Transformationsprozesse einzunehmen.
<G-vec00345-001-s321><assume.einnehmen><en> The study programme qualifies you to assume a professional position in the shaping of societal transformation processes.
<G-vec00345-001-s322><assume.einnehmen><de> Nehmen Sie Platz auf dem Sitzball, um automatisch eine aufrechte Position einzunehmen.
<G-vec00345-001-s322><assume.einnehmen><en> Take a seat on the ball to assume automatically an upright position.
<G-vec00345-001-s323><assume.einnehmen><de> Sie zeigten, wie es dem Enzym gelingt, zwei Elektronen hintereinander auf Wasserstoffionen zu übertragen und dabei stabile Zwischenzustände einzunehmen.
<G-vec00345-001-s323><assume.einnehmen><en> They were able to demonstrate how the enzyme succeeds in transferring two electrons in succession to two hydrogen ions and thereby assume stable intermediate states.
<G-vec00169-001-s314><capture.einnehmen><de> Versuche, so viele Dörfer wie möglich einzunehmen und zu halten, um genügend Gold zu bekommen.
<G-vec00169-001-s314><capture.einnehmen><en> Try to capture and keep control of as many villages as possible to keep the gold coming in
<G-vec00169-001-s315><capture.einnehmen><de> Die übermächtigen feindlichen Kräfte waren in der Lage, den ersten Stützpunkt und einen Großteil der Stadt einzunehmen.
<G-vec00169-001-s315><capture.einnehmen><en> The superior enemy forces were eventually able to capture this first checkpoint and most of the town.
<G-vec00169-001-s316><capture.einnehmen><de> Während die heilige Stadt von Gott aus dem Himmel herabkommt (Offenbarung 21:2), werden die Gottlosen versuchen, diese einzunehmen.
<G-vec00169-001-s316><capture.einnehmen><en> As the holy city comes down from God out of heaven (Revelation 21:2), the wicked attempt to capture it.
<G-vec00169-001-s317><capture.einnehmen><de> Bei dieser Mission ist es das Ziel einer Taliban Einheit kurzfristig eine Patriot Batterie in Afghanistan einzunehmen, um mit ihr einen sowjetischen Hubschrauber auf der anderen Seite der Grenze abzuschießen.
<G-vec00169-001-s317><capture.einnehmen><en> The objective of this mission is for a Taliban unit to capture a Patriot battery in Afghanistan to shoot down a Soviet helicopter on the other side of the border.
<G-vec00169-001-s318><capture.einnehmen><de> Immer wieder versuchten feindliche Armeen, Luanda einzunehmen und immer wieder führte das zu Vertreibung und Leid der bäuerlichen Bevölkerung um die Stadt herum.
<G-vec00169-001-s318><capture.einnehmen><en> Over and over again hostile armies have tried to capture Luanda and it has always resulted in displacement and agony for the farming population around the city.
<G-vec00169-001-s319><capture.einnehmen><de> Um eine Stadt einzunehmen, muss Ihre eigene gepanzerte Kolonne die feindliche Stadt erreichen und die Verteidigung der feindlichen Stadt besiegen.
<G-vec00169-001-s319><capture.einnehmen><en> To capture the city, your friendly tank convoy must reach the enemy city and it must win against the defense line setup by the defending city.
<G-vec00169-001-s320><capture.einnehmen><de> Diese Phase funktioniert auf dieselbe Weise, wie der Kontrolle-Spielmodus – die Spieler werfen an den Kontrollpunkten ihre Drohnen ab, um diese einzunehmen.
<G-vec00169-001-s320><capture.einnehmen><en> This stage works in the same manner as the Control game mode – each player can deploy a drone at a control point to capture it.
<G-vec00169-001-s321><capture.einnehmen><de> Er wird den Kampf gegen Gott wieder aufnehmen und versuchen, die heilige Stadt einzunehmen.
<G-vec00169-001-s321><capture.einnehmen><en> He will resume the battle against God as he tries to capture the holy city.
<G-vec00169-001-s322><capture.einnehmen><de> Sie umzingeln die heilige Stadt, um sie einzunehmen (Offenbarung 20:9), dann fällt Feuer von Gott aus dem Himmel und verzehrt sie.
<G-vec00169-001-s322><capture.einnehmen><en> They surround the holy city to capture it (Revelation 20:9), and fire comes down from God out of heaven and devours them.
<G-vec00169-001-s323><capture.einnehmen><de> Sie sind hochtaktische Einheiten mit der einzigartigen Fähigkeit, Gebäude doppelt so schnell einzunehmen wie andere Zombies.
<G-vec00169-001-s323><capture.einnehmen><en> But they are highly tactical units with the unique ability to capture buildings twice as fast as any other.
<G-vec00169-001-s324><capture.einnehmen><de> Abgesehen davon, dass er das nötige Talent mitbrachte, verstand er es auch, die Leute mit seinem Charme und seiner Liebenswürdigkeit für sich einzunehmen.
<G-vec00169-001-s324><capture.einnehmen><en> Apart from bringing the necessary talent, he also knew how to capture people with his charm and kindness.
<G-vec00169-001-s325><capture.einnehmen><de> Wenn du eine Stadt viele Tage belagerst, um gegen sie zu kämpfen und sie einzunehmen, sollst du ihre Bäume nicht vernichten, indem du die Axt gegen sie schwingst.
<G-vec00169-001-s325><capture.einnehmen><en> When you shall besiege a city a long time, in making war against it to capture it, you shall not destroy its trees, nor wield an axe against them;
<G-vec00169-001-s326><capture.einnehmen><de> Gelingt es dem angreifenden Team vor Ablauf der Zeit den Punkt einzunehmen, so muss im zweiten Abschnitt der Karte eine Fracht ins Ziel befördert werden.
<G-vec00169-001-s326><capture.einnehmen><en> If the attackers manage to capture the point before the time runs out, a payload must be taken to a target destination in the second section of the map.
<G-vec00169-001-s327><capture.einnehmen><de> Um einen Kontrollpunkt einzunehmen, müssen die Piloten in Reichweite des Ziels fliegen und die Richtungstaste C drücken, um eine Drohne abzusetzen.
<G-vec00169-001-s327><capture.einnehmen><en> To capture a control point, fly within range of the objective and tap the C directional button to deploy a drone.
<G-vec00169-001-s328><capture.einnehmen><de> Satan wird die Menschen glauben machen, dass er zu Unrecht aus dem Himmel ausgestossen worden sei und dass es ihnen mit vereinten Kräften gelingen würde, die Stadt einzunehmen und unter ihre Kontrolle zu bringen.
<G-vec00169-001-s328><capture.einnehmen><en> NOTE: Satan will deceive people into believing that he was unjustly deposed from heaven and that together they can capture the city and take control.
<G-vec00286-001-s314><capture.einnehmen><de> Versuche, so viele Dörfer wie möglich einzunehmen und zu halten, um genügend Gold zu bekommen.
<G-vec00286-001-s314><capture.einnehmen><en> Try to capture and keep control of as many villages as possible to keep the gold coming in
<G-vec00286-001-s315><capture.einnehmen><de> Die übermächtigen feindlichen Kräfte waren in der Lage, den ersten Stützpunkt und einen Großteil der Stadt einzunehmen.
<G-vec00286-001-s315><capture.einnehmen><en> The superior enemy forces were eventually able to capture this first checkpoint and most of the town.
<G-vec00286-001-s316><capture.einnehmen><de> Während die heilige Stadt von Gott aus dem Himmel herabkommt (Offenbarung 21:2), werden die Gottlosen versuchen, diese einzunehmen.
<G-vec00286-001-s316><capture.einnehmen><en> As the holy city comes down from God out of heaven (Revelation 21:2), the wicked attempt to capture it.
<G-vec00286-001-s317><capture.einnehmen><de> Bei dieser Mission ist es das Ziel einer Taliban Einheit kurzfristig eine Patriot Batterie in Afghanistan einzunehmen, um mit ihr einen sowjetischen Hubschrauber auf der anderen Seite der Grenze abzuschießen.
<G-vec00286-001-s317><capture.einnehmen><en> The objective of this mission is for a Taliban unit to capture a Patriot battery in Afghanistan to shoot down a Soviet helicopter on the other side of the border.
<G-vec00286-001-s318><capture.einnehmen><de> Immer wieder versuchten feindliche Armeen, Luanda einzunehmen und immer wieder führte das zu Vertreibung und Leid der bäuerlichen Bevölkerung um die Stadt herum.
<G-vec00286-001-s318><capture.einnehmen><en> Over and over again hostile armies have tried to capture Luanda and it has always resulted in displacement and agony for the farming population around the city.
<G-vec00286-001-s319><capture.einnehmen><de> Um eine Stadt einzunehmen, muss Ihre eigene gepanzerte Kolonne die feindliche Stadt erreichen und die Verteidigung der feindlichen Stadt besiegen.
<G-vec00286-001-s319><capture.einnehmen><en> To capture the city, your friendly tank convoy must reach the enemy city and it must win against the defense line setup by the defending city.
<G-vec00286-001-s320><capture.einnehmen><de> Diese Phase funktioniert auf dieselbe Weise, wie der Kontrolle-Spielmodus – die Spieler werfen an den Kontrollpunkten ihre Drohnen ab, um diese einzunehmen.
<G-vec00286-001-s320><capture.einnehmen><en> This stage works in the same manner as the Control game mode – each player can deploy a drone at a control point to capture it.
<G-vec00286-001-s321><capture.einnehmen><de> Er wird den Kampf gegen Gott wieder aufnehmen und versuchen, die heilige Stadt einzunehmen.
<G-vec00286-001-s321><capture.einnehmen><en> He will resume the battle against God as he tries to capture the holy city.
<G-vec00286-001-s322><capture.einnehmen><de> Sie umzingeln die heilige Stadt, um sie einzunehmen (Offenbarung 20:9), dann fällt Feuer von Gott aus dem Himmel und verzehrt sie.
<G-vec00286-001-s322><capture.einnehmen><en> They surround the holy city to capture it (Revelation 20:9), and fire comes down from God out of heaven and devours them.
<G-vec00286-001-s323><capture.einnehmen><de> Sie sind hochtaktische Einheiten mit der einzigartigen Fähigkeit, Gebäude doppelt so schnell einzunehmen wie andere Zombies.
<G-vec00286-001-s323><capture.einnehmen><en> But they are highly tactical units with the unique ability to capture buildings twice as fast as any other.
<G-vec00286-001-s324><capture.einnehmen><de> Abgesehen davon, dass er das nötige Talent mitbrachte, verstand er es auch, die Leute mit seinem Charme und seiner Liebenswürdigkeit für sich einzunehmen.
<G-vec00286-001-s324><capture.einnehmen><en> Apart from bringing the necessary talent, he also knew how to capture people with his charm and kindness.
<G-vec00286-001-s325><capture.einnehmen><de> Wenn du eine Stadt viele Tage belagerst, um gegen sie zu kämpfen und sie einzunehmen, sollst du ihre Bäume nicht vernichten, indem du die Axt gegen sie schwingst.
<G-vec00286-001-s325><capture.einnehmen><en> When you shall besiege a city a long time, in making war against it to capture it, you shall not destroy its trees, nor wield an axe against them;
<G-vec00286-001-s326><capture.einnehmen><de> Gelingt es dem angreifenden Team vor Ablauf der Zeit den Punkt einzunehmen, so muss im zweiten Abschnitt der Karte eine Fracht ins Ziel befördert werden.
<G-vec00286-001-s326><capture.einnehmen><en> If the attackers manage to capture the point before the time runs out, a payload must be taken to a target destination in the second section of the map.
<G-vec00286-001-s327><capture.einnehmen><de> Um einen Kontrollpunkt einzunehmen, müssen die Piloten in Reichweite des Ziels fliegen und die Richtungstaste C drücken, um eine Drohne abzusetzen.
<G-vec00286-001-s327><capture.einnehmen><en> To capture a control point, fly within range of the objective and tap the C directional button to deploy a drone.
<G-vec00286-001-s328><capture.einnehmen><de> Satan wird die Menschen glauben machen, dass er zu Unrecht aus dem Himmel ausgestossen worden sei und dass es ihnen mit vereinten Kräften gelingen würde, die Stadt einzunehmen und unter ihre Kontrolle zu bringen.
<G-vec00286-001-s328><capture.einnehmen><en> NOTE: Satan will deceive people into believing that he was unjustly deposed from heaven and that together they can capture the city and take control.
