<G-vec00001-001-s068><erect.aufrechten><de> Eine hervorragende Form der italienischen Zypressen mit feinen aufrechten Laub, frischer grünen Farbe und einer kompakten Krone.
<G-vec00001-001-s068><erect.aufrechten><en> A superb form of Italian cypress withfine erect foliage, fresh green colour and compact crown.
<G-vec00001-001-s069><erect.aufrechten><de> Crassula pyramidalis ist eine kleine Sukkulente aus Südafrika, bis zu 10 cm hoch, mit aufrechten bis niederliegendenem Stamm.
<G-vec00001-001-s069><erect.aufrechten><en> Crassula pyramidalis is a small, sparingly clustering succulent, native to South Africa, up to 10 cm tall with erect to decumbent stem, dichotomously branching.
<G-vec00001-001-s070><erect.aufrechten><de> Ein einjähriges Kraut mit aufrechten Stängeln zu 80 cm groÃ .
<G-vec00001-001-s070><erect.aufrechten><en> An annual herb with erect stems to 80 cm tall.
<G-vec00001-001-s071><erect.aufrechten><de> Mit einem Abszess in den Körperhöhlen werden alle Trennwände zerstört, eine Erektion verschlechtert sich, der Penis ist in einem aufrechten Zustand gebogen (Peyronie-Krankheit).
<G-vec00001-001-s071><erect.aufrechten><en> With an abscess in the cavernous bodies, all partitions are destroyed, an erection worsens, the penis is bent in an erect state (Peyronie's disease).
<G-vec00001-001-s072><erect.aufrechten><de> "Die Band schneidende Methode kann einen Gewinn von einem Zoll oder zwei in Länge, am Risiko gesamten Verlustes der Stütze vom aufrechten Penis, damit, in den Wörtern von einem Mann schaffen, ""es schlägt herum wie ein Hubschrauberblatt""."
<G-vec00001-001-s072><erect.aufrechten><en> "The ligament-cutting method may create a gain of an inch or two in length, at the risk of total loss of support of the erect penis, so that, in the words of one man, ""it flaps around like a helicopter blade."""
<G-vec00001-001-s073><erect.aufrechten><de> NBPEL - die Länge des aufrechten Gliedes ohne Lineal, das in die Schamgegend gedrückt wird.
<G-vec00001-001-s073><erect.aufrechten><en> NBPEL - the length of the erect member without a ruler pressed into the pubis.
<G-vec00001-001-s074><erect.aufrechten><de> Ich würde als unsern Vertreter einen aufrechten, israelisch aussehenden Pioniertyp bevorzugen, der englisch mit einem ausgesprochenen hebräischen Accent bevorzugen.
<G-vec00001-001-s074><erect.aufrechten><en> I would have preferred as our representative an erect, Israeli-looking pioneer-type who speaks English with a pronounced Hebrew accent.
<G-vec00001-001-s075><erect.aufrechten><de> BPEL - die Länge des aufrechten Gliedes mit einem Lineal, das in den Schambein gedrückt wird.
<G-vec00001-001-s075><erect.aufrechten><en> BPEL - the length of the erect penis with a ruler pressed into the pubis.
<G-vec00001-001-s076><erect.aufrechten><de> Die Anlage ist eine jährliche, schnell wachsende, mit aufrechten, starke Stämme, 30-90 cm hoch.
<G-vec00001-001-s076><erect.aufrechten><en> The plant is an annual, fast-growing, with erect, robust stems, 30-90 cm tall.
<G-vec00001-001-s077><erect.aufrechten><de> Hat einen aufrechten, verzweigten dicht an der Spitze des Stiels.
<G-vec00001-001-s077><erect.aufrechten><en> Has an erect, branched close to the top of the stem.
<G-vec00001-001-s078><erect.aufrechten><de> Kardamom, Elettaria cardamomum, ist ein Kraut mit langen, schmalen Blättern, die an aufrechten Stängeln sitzen, umgeben von vielen Schichten kegelförmiger Kleinblätter.
<G-vec00001-001-s078><erect.aufrechten><en> Cardamom, Elettaria cardamomum, is a herb with long, narrow leaves on erect stems surrounded by many layers of small, cone-shaped leaves, the so-called leaf sheaths.
<G-vec00001-001-s079><erect.aufrechten><de> Die allmähliche Verfeinerung der Menschenhand und die mit ihr Schritt haltende Ausbildung des Fußes für den aufrechten Gang hat unzweifelhaft auch durch solche Korrelation auf andre Teile des Organismus rückgewirkt.
<G-vec00001-001-s079><erect.aufrechten><en> The gradually increasing perfection of the human hand, and the commensurate adaptation of the feet for erect gait, have undoubtedly, by virtue of such correlation, reacted on other parts of the organism.
<G-vec00001-001-s080><erect.aufrechten><de> Ein Kennzeichen dieser Rasse ist der Breite Kopf, Stumpf Dreieck, Tiefe Schnauze, die relativ kleinen Augen und die aufrechten Ohren übertragene etwa im Einklang mit der obersten Zeile des Halses.
<G-vec00001-001-s080><erect.aufrechten><en> A feature of the breed is the wide head, obtuse triangle, the deep snout, the relatively small eyes and erect ears carried forward approximately in line with the top line of the neck.
<G-vec00001-001-s081><erect.aufrechten><de> „All diese schwarzen Wände der großen Caldera mit ihren wie mit Zinnen versehenen Kämmen, mit ihren aufrechten Felsen, vermitteln den Eindruck einer danteskischen Vision.
<G-vec00001-001-s081><erect.aufrechten><en> “All those steep black walls with huge basins, and their crests that seem to be crenellated, and their erect rocks, offer the appearance of a macabre vision.
<G-vec00001-001-s082><erect.aufrechten><de> Die Blüten sind geruchlos, auf aufrechten Stielen bis zu 4,5 cm dunkel oder grünlich-gelbe Farbe, mit dunkelrot oder braun-rote Plakette auf der Außenseite.
<G-vec00001-001-s082><erect.aufrechten><en> The flowers are odorless, on erect peduncles up to 4.5 cm dark or greenish-yellow color, with dark red or brownish-red plaque on the outside.
<G-vec00001-001-s083><erect.aufrechten><de> Ein Strauch mit aufrechten Stängeln bis zu 2,5 m hoch Blätter sind dunkelgrün, rau, fallen farbige in Gelb-und Rottönen.
<G-vec00001-001-s083><erect.aufrechten><en> A shrub with erect stems up to 2.5m high leaves are dark green, rough, fall colored in yellow and red tones.
<G-vec00001-001-s084><erect.aufrechten><de> C. tenuiflora ist gut angepasst durch ihre Fähigkeit sofort zur aufrechten Stellung zurüchzuschnellen, die frühere Schneeschmelze ausnutzend und durch ihren intensiven Zuwachs die anderen Komponenten des Unterholzes zu untedrücken.
<G-vec00001-001-s084><erect.aufrechten><en> C. tenuiflora is well adapted by its capacity to immediately spring into an erect position to take advantage of the earlier snowmelt, and its vigorous growth suppresses the other understorey compoments.
<G-vec00001-001-s085><erect.aufrechten><de> Beschreibung: krautige Pflanzen, jährlich, mit aufrechten, verzweigten Stängel 20-60 cm hoch.
<G-vec00001-001-s085><erect.aufrechten><en> Description: Plants herbaceous, annual, with erect, branched stems 20-60 cm tall.
<G-vec00001-001-s086><erect.aufrechten><de> Bei aufrechten Ohren, Sie sind klein, gleicher Größe aufrecht, und vertikal wie möglich.
<G-vec00001-001-s086><erect.aufrechten><en> In the case of erect ears, they are small, equal-sized upright, and carried vertically as possible.
