<G-vec00684-002-s014><scour.absuchen><de> Daher haben wir beschlossen, die Galerie nach den schönsten und kreativsten Grundstücken der Community abzusuchen.
<G-vec00684-002-s014><scour.absuchen><en> So we decided to scour the Gallery for you to find some of the most beautiful and creative lots made by the community.
<G-vec00684-002-s049><scour.absuchen><de> Sie sind dem Verhungern nahe und suchen das Umland nach Essen ab.
<G-vec00684-002-s049><scour.absuchen><en> They are in danger of starvation and scour the remaining countryside for food.
<G-vec00684-002-s050><scour.absuchen><de> Sie suchen das Schlachtfeld nach Spuren der Verwüstung ab: Munition, Müll, verrostete Gerätschaften.
<G-vec00684-002-s050><scour.absuchen><en> They scour the battlefield for signs of devastation: munitions, rubbish, rusted equipment.
