<G-vec00243-002-s027><fret.abrichten><de> Abgerichtet wird dann aber erst, nachdem der Hals eingeleimt und alles vormontiert wurde.
<G-vec00243-002-s027><fret.abrichten><en> Adjusting the fret level follows after the neck has been glued to the body and everything has been pre-assembled.
