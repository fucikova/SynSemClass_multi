<G-vec00301-001-s414><attend.betreuen><de> TIGGES Rechtsanwälte betreuen Mandanten persönlich und individuell.
<G-vec00301-001-s414><attend.betreuen><en> TIGGES Rechtsanwälte attend to their clients personally and individually.
<G-vec00301-001-s415><attend.betreuen><de> Durch die 2011 gegründete Auslandsniederlassung bei Shanghai ist CSZ vor Ort und in Deutschland bestens aufgestellt, um westliche Kunden bei der Umsetzung Ihrer anspruchsvollen Bauvorhaben im Wachstumsland China zu betreuen.
<G-vec00301-001-s415><attend.betreuen><en> Through the 2011 established overseas branch near Shanghai CSZ is optimally positioned on the ground as well as in Germany to attend western clients when realizing their ambitious building project in growth country China.
<G-vec00301-001-s416><attend.betreuen><de> Interessierte Einzelhändler vermitteln wir gerne an engagierte Kunden von uns weiter, die sie ortsnah und individuell betreuen können.
<G-vec00301-001-s416><attend.betreuen><en> Interested retailers are gladly intermediated by us to our engaged customers, who are able to attend them locally and individually.
<G-vec00301-001-s417><attend.betreuen><de> Unsere norddeutschen Kunden betreuen wir aus Hamburg und Kiel.
<G-vec00301-001-s417><attend.betreuen><en> We attend to customers in northern Germany from our offices at Hamburg and Kiel.
<G-vec00301-001-s418><attend.betreuen><de> Unsere speziell dafür ausgebildeten Mitarbeiter-/innen betreuen Sie und pflegende Angehörige im Raum Bad Godesberg und Bonn diskret und zuverlässig.
<G-vec00301-001-s418><attend.betreuen><en> Our assistants are specially trained for this and attend you and your family carers discreetly and reliably within the region of Bad Godesberg and Bonn.
<G-vec00301-001-s419><attend.betreuen><de> KunstexpertInnen aus verschiedenen Ländern und Kontinenten erhalten die Einladung, auf der Basis einer vordefinierten Honorarstruktur KünstlerInnen, NaturwissenschaftlerInnen und GeisteswissenschaftlerInnen mit Beiträgen zum Projektthema zu betrauen und kuratorisch zu betreuen.
<G-vec00301-001-s419><attend.betreuen><en> Art experts from different countries and continents get the invitation to entrust artists, scientists and art scholars with contributions on the project’s topic and to attend to them as curators.
<G-vec00301-001-s420><attend.betreuen><de> Viele sprechen verschiedene Fremdsprachen, und insgesamt sind wir in der Lage, Eigenheimbesitzer und Käufer aus vielen Ländern zu betreuen, immer mit einem persönlichen Service und dem Fokus, die Ergebnisse zu erzielen, die Sie als Verkäufer oder Käufer – erwarten.
<G-vec00301-001-s420><attend.betreuen><en> Many speak different languages, and between us we are able to attend homeowners and buyers from many countries, always offering a personalised service focused on achieving the results you – as a vendor or a buyer – are looking for.
<G-vec00301-001-s421><attend.betreuen><de> Die Eigentümer, Familie Theile, betreuen die Gäste und vermitteln interressante Informationen über das Leben am Rande der Namibwüste.
<G-vec00301-001-s421><attend.betreuen><en> The owners, Family Theile, attend personally to the guests and provide interesting information about life at the edge of the Namib Desert.
<G-vec00301-001-s422><attend.betreuen><de> Kurzfristig können sich die Mitarbeiter bis zu zehn Tage freistellen lassen, um Familienmitglieder zuhause zu betreuen.
<G-vec00301-001-s422><attend.betreuen><en> Employees can take up to ten days of leave at short notice in order to attend to family members at home.
<G-vec00301-001-s423><attend.betreuen><de> Unsere Handelsvertreter betreuen Sie vor Ort und unterstützen unsere Vertriebsabteilung dabei, die optimale Lösung für Sie zu entwickeln.
<G-vec00301-001-s423><attend.betreuen><en> Our sales representatives attend you on site and support our sales department in developing the optimal solution for you.
<G-vec00301-001-s424><attend.betreuen><de> Vereinfachen Sie Ihre Lieferkette, indem Sie uns die Sorge um Ihre Hardware überlassen, während Sie sich auf Ihre Anwendung fokussieren und Ihre Kunden betreuen.
<G-vec00301-001-s424><attend.betreuen><en> Simplify your supply chain by letting us take care of your hardware while you focus on your application and attend to your customers.
<G-vec00301-001-s425><attend.betreuen><de> Wir betreuen unsere Kunden persönlich.
<G-vec00301-001-s425><attend.betreuen><en> We personally attend to our customers.
<G-vec00211-002-s112><oversee.betreuen><de> Rutgers, der zuletzt bei Plum Fintech tätig war, einem Anbieter von Lösungen für persönliche Sparassistenten, wird das britische Geschäft leiten und Robinhoods neues Londoner Büro betreuen.
<G-vec00211-002-s112><oversee.betreuen><en> Rutgers, who most recently served at personal savings assistant solutions provider Plum Fintech, will lead the U.K. business and oversee Robinhood’s new London office, the blog post notes.
<G-vec00211-002-s142><supervise.betreuen><de> Die endgültige Entscheidung einer Betreuungsperson, Sie als Doktorandin/ als Doktorand zu betreuen, erfolgt in der Regel erst nach einer persönlichen Kontaktaufnahme.
<G-vec00211-002-s142><supervise.betreuen><en> The final decision of a potential supervisor to supervise your dissertation will only be taken after a meeting in person.
<G-vec00212-002-s038><manage.betreuen><de> Numerische Simulationsrechnungen werden eingesetzt, um die Laborentwicklungen zu unterstützen und zu betreuen.
<G-vec00212-002-s038><manage.betreuen><en> Numerically calculated simulations are used to support and manage laboratory developments.
<G-vec00212-002-s039><manage.betreuen><de> Mit der Mehrzahl unserer Mandanten unterhalten wir langfristig angelegte Kooperationsverhältnisse und betreuen das gesamte Forderungsportfolio im In- und Ausland.
<G-vec00212-002-s039><manage.betreuen><en> We maintain long-term relations of cooperation with the majority of our clients and manage their entire portfolio of national and international claims.
<G-vec00212-002-s040><manage.betreuen><de> Die MIGROS IT Services betreuen mit syslink Xandria etwa 125 SAP Systeme für 13'000 SAP User auf 250 Servern.
<G-vec00212-002-s040><manage.betreuen><en> The MIGROS IT Services manage about 125 SAP systems for 13'000 SAP users on 250 servers using syslink Xandria.
<G-vec00212-002-s041><manage.betreuen><de> Kurz: Wir betreuen das Projekt, bis es länderübergreifend am Start ist.
<G-vec00212-002-s041><manage.betreuen><en> In short, we manage the project until it is ready for launch in all countries.
<G-vec00212-002-s042><manage.betreuen><de> Dank unserer günstigen geographischen Lage können wir sowohl Projekte in den Niederlanden als auch in Deutschland auf effiziente Weise betreuen.
<G-vec00212-002-s042><manage.betreuen><en> Our geographically favourable position ensures that we are able to manage our projects efficiently in both the Netherlands and Germany.
<G-vec00212-002-s043><manage.betreuen><de> Wir projektieren, verkaufen, installieren und betreuen Systemlösungen aus dem Bereich Kommunikationstechnik mit jahrelanger exklusiver Spezialisierung auf AVAYA.
<G-vec00212-002-s043><manage.betreuen><en> We plan, sell, install and manage system solutions in the communication technology sector, having exclusively focused on AVAYA telephone system, telephones and accessories for many years.
<G-vec00212-002-s044><manage.betreuen><de> Als einer der größten Projektträger Deutschlands betreuen die hochqualifizierten Mitarbeiterinnen und Mitarbeiter mehr als 10.000 Vorhaben und etwa 1,4 Milliarde Euro Forschungsgelder.
<G-vec00212-002-s044><manage.betreuen><en> As one of the largest project management agencies in Germany, our highly qualified employees currently manage more than 10,000 projects and around 1.4 billion Euros in research funds.
<G-vec00212-002-s045><manage.betreuen><de> So lassen sich professionelle Social-Media-Auftritte entwickeln, die wir als Full-Service-Dienstleister operativ für sie betreuen - Reporting inklusive.
<G-vec00212-002-s045><manage.betreuen><en> This enables us to develop professional social media profiles that we, as a full-service provider, can operationally manage on your behalf - including reporting.
<G-vec00212-002-s046><manage.betreuen><de> Wir betreuen von der Reservierung der Kunden bis zur Reinigung nach deren Abreise.
<G-vec00212-002-s046><manage.betreuen><en> We manage from the booking of your clients until the cleaning after your departure.
<G-vec00212-002-s047><manage.betreuen><de> MarkenrechtWir konzipieren und betreuen nationale sowie internationale Markenportfolios von der Prioritätsrecherche über Markenanmeldungen bis hin zu deren nationaler wie multinationaler Verteidigung und Durchsetzung.
<G-vec00212-002-s047><manage.betreuen><en> TrademarksWe develop and manage national and international trademark portfolios, ranging from trademark clearance and prosecution through to national and multinational defense and enforcement.
<G-vec00212-002-s048><manage.betreuen><de> Innerhalb unserer agilen Entwicklungsumgebung wirst du mehrere agile Teams betreuen, teilweise über mehrere Standorte hinweg.
<G-vec00212-002-s048><manage.betreuen><en> You will manage several agile teams within our agile development environment, sometimes across multiple sites.
<G-vec00212-002-s049><manage.betreuen><de> Wir organisieren und betreuen Projekte, Kongresse, Incentives, Meetings und Messen.
<G-vec00212-002-s049><manage.betreuen><en> We organise and manage projects, conventions, incentives, meetings and trade fairs.
<G-vec00212-002-s050><manage.betreuen><de> Die 630 Mitarbeiter von Marken betreuen jeden Monat 50.000 Arzneimittellieferungen und biologische Lieferungen aller Temperaturbereiche in über 150 Ländern.
<G-vec00212-002-s050><manage.betreuen><en> Marken's 630 staff members manage 50,000 drug and biological shipments every month at all temperature ranges in more than 150 countries.
<G-vec00212-002-s051><manage.betreuen><de> Gerne betreuen wir konstruktive Aufgaben aller Art, entwickeln Lösungen in moderner CAE-Umgebung (Pro Engineer Wildfire und AutoCAD, andere Programme können im Kontext größerer Aufträge durch uns erworben und eingesetzt werden), erstellen Fertigungszeichnungen, recherchieren Partner für die Fertigung, Bezugsquellen, etc....
<G-vec00212-002-s051><manage.betreuen><en> We manage any project in the arena of technical engineering. We also create solutions using modern methods of computer admitted engineering (Pro Engineer Wildfire and AutoCAD, the employment of other solutions is possible in context of major assignments), and generate technical drawing, acquire partners for manufacturing, supply, etc.
<G-vec00212-002-s052><manage.betreuen><de> Wir betreuen aufgrund unserer internationalen Ausrichtung und Ausbildung grenzüberschreitende Wirtschaftsprojekte, wobei wir für jede internationale Causa die am besten geeignete ausländische Partnerkanzlei aus unserem Netzwerk heranziehen, die das Know-How in der jeweiligen nationalen Rechtsordnung einbringt.
<G-vec00212-002-s052><manage.betreuen><en> Given our international background and expertise we also manage cross-border business projects. For each international deal, we cooperate with the most suitable network partner law firm which provides the relevant know-how of national laws.
<G-vec00212-002-s053><manage.betreuen><de> "In vielen Verwaltungen fehlen einfach die Fachleute, um komplexe Bauwerke zu betreuen", sagt er.
<G-vec00212-002-s053><manage.betreuen><en> "Many administrations simply lack the experts to manage complex construction projects," he says.
<G-vec00212-002-s054><manage.betreuen><de> Darüber hinaus betreuen wir viele bi- oder multilaterale Forschungskooperationen und Initiativen zum Aufbau eigener exzellenter Forschungskapazitäten in anderen Weltregionen.
<G-vec00212-002-s054><manage.betreuen><en> Moreover, we manage numerous bi- or multilateral research cooperations and initiatives seeking to build their own excellent research capabilities in other regions of the world.
<G-vec00212-002-s055><manage.betreuen><de> Architekten und Ingenieure Egal ob Sie ein Projekt oder ein gesamtes Portfolio als Berater betreuen oder designen, Sie werden vor Herausforderungen stehen, wenn es um die Lenkung und Verwaltung des Informationsflusses, der Kommunikation und der Prozesse geht, besonders bei BIM und IPD.
<G-vec00212-002-s055><manage.betreuen><en> Whether you have to manage just one project or process or you need to manage your entire portfolio involving thousands of individuals – there will be issues and challenges controlling and managing information, communication and processes throughout the entire project (and asset) lifecycle.
<G-vec00212-002-s056><manage.betreuen><de> Aktuell betreuen unsere Mitarbeiter mehr als 18.000 Wohnungen in Deutschlands wirtschaftlich starken Ballungsräumen und Metropolen.
<G-vec00212-002-s056><manage.betreuen><en> Our employees currently manage over 18,000 residential properties in the economically strong conurbations and major cities of Germany.
<G-vec00215-002-s195><advise.betreuen><de> Darüber hinaus betreuen wir Mandanten — nicht zuletzt aufgrund der Expertise unserer auch als Notare in Berlin tätigen anwaltlichen Kollegen — bundesweit auch in allen anderen erbrechtlichen Angelegenheiten.
<G-vec00215-002-s195><advise.betreuen><en> In addition, we also advise clients across Germany — not least thanks to the expertise of our colleagues who are also notaries in Berlin — in all other matters of inheritance law.
<G-vec00215-002-s196><advise.betreuen><de> Wir betreuen daneben vermögensstarke Stiftungen in allen Fragen des Stiftungs- und Gemeinnützigkeitsrechts sowie große Kunstsammler bei allen Rechts- und Steuerfragen des Erwerbs, Aufbaus und der Veräußerung ihrer Sammlung.
<G-vec00215-002-s196><advise.betreuen><en> We also advise foundations on all aspects of foundation law and charity law and major art collectors on all legal and tax aspects regarding the acquisition, creation and sale of their collections.
<G-vec00215-002-s197><advise.betreuen><de> Mit unserem großen interdisziplinären Team können wir jederzeit große Verfahren mit den erforderlichen personellen Ressourcen betreuen.
<G-vec00215-002-s197><advise.betreuen><en> With our large inter-disciplinary team, we can advise on large proceedings with the required personnel resources at any time.
<G-vec00215-002-s198><advise.betreuen><de> Sollte es in Ihrer Nähe keine Vertretung geben, betreuen wir Sie gerne direkt von unserem Firmenstandort in Österreich.
<G-vec00215-002-s198><advise.betreuen><en> If there is no agency in your area, we will gladly advise you direct from our premises in Austria.
<G-vec00215-002-s199><advise.betreuen><de> Im Baubereich betreuen wir unsere Klienten bei Streitfällen in Schlichtungs- und Schiedsverfahren sowie Gerichtsverfahren vor allen ordentlichen Gerichten im Zusammenhang mit der Verfolgung oder der Abwehr von Forderungen, Gewährleistungs- und Schadenersatzansprüchen.
<G-vec00215-002-s199><advise.betreuen><en> We advise our clients on matters of construction law in dispute settlement cases, arbitration proceedings, and court cases before all ordinary courts of law when it comes to the pursuit of or defence against claims, including warranty claims, and claims for damages.
<G-vec00215-002-s200><advise.betreuen><de> Andreas Hünerwadel: Wir betreuen Produzenten und Händler von Energie sowie Berater von Energieunternehmen.
<G-vec00215-002-s200><advise.betreuen><en> Andreas Hünerwadel: We advise producers and vendors of energy as well as consultants of energy enterprises.
<G-vec00215-002-s201><advise.betreuen><de> Als Referentinnen und Referenten betreuen sie Ihre Dissertation und öffnen Ihnen Türen für Ihren weiteren akademischen Werdegang.
<G-vec00215-002-s201><advise.betreuen><en> As supervisors, faculty will advise you on your thesis and provide guidance for your future academic career.
<G-vec00215-002-s202><advise.betreuen><de> In schwierigen Fragen des Strafvollstreckungsrechts und der vermögensrechtlichen Folgen betreuen Sie die Fachanwälte für Strafrecht der Kanzlei Dr. Bader & Partner umfassend.
<G-vec00215-002-s202><advise.betreuen><en> The highly skilled lawyers of Dr. Bader & Partner comprehensively assist and advise you on all related issues.
<G-vec00215-002-s203><advise.betreuen><de> Wir betreuen Sie bei allen Fragen rund um Marketing und Verkauf – von der zielgruppen- gerechten Zusammenstellung des Sortiments bis zu verkaufs- fördernden Promotionen.
<G-vec00215-002-s203><advise.betreuen><en> We advise and support you in any matters concerning sales or marketing, ranging from target group-based communication and composition of range or promotional activities.
<G-vec00215-002-s204><advise.betreuen><de> Die auf Arbeitsrecht spezialisierten Fachleute der Kanzlei betreuen sowohl italienische als auch ausländische Arbeitnehmer und Betriebe bei der Abfassung von Einzel- und Tarifverträgen, insbesondere bezüglich aller Aspekte, die die Beziehungen zwischen Unternehmen, Personal und Mitarbeitern betreffen, und bieten Unterstützung im Zusammenhang mit der Verwaltung von Expatriates und Impatriates.
<G-vec00215-002-s204><advise.betreuen><en> E-Mail Employment law Our specialists in labour law advise Italian and foreign employees and companies in the preparation of personal and collective contracts, with particular reference to all aspects concerning the relations between company, employees and collaborators, as well as advice on managing expatriates and impatriates.
<G-vec00215-002-s205><advise.betreuen><de> Nun begann ich, Sportler in einem internationalen Umfeld zu betreuen.
<G-vec00215-002-s205><advise.betreuen><en> Then I started to advise professional athletes at the international level.
<G-vec00215-002-s206><advise.betreuen><de> Deutsche Studierende betreuen die Gäste, die von vier Kontinenten kommen, und helfen bei Fragen zur Alltags- und Freizeitgestaltung.
<G-vec00215-002-s206><advise.betreuen><en> German students will advise the visitors, who hail from four continents, and assist with questions on everyday life and leisure activities.
<G-vec00215-002-s207><advise.betreuen><de> Im Falle einer Panne oder eines Unfalles betreuen wir Sie direkt per Telefon und organisieren Hilfe.
<G-vec00215-002-s207><advise.betreuen><en> If you have had a breakdown or accident, we will advise you directly over the phone and organise help for you.
<G-vec00215-002-s208><advise.betreuen><de> Ihre Rechtsanwälte betreuen Unternehmen mit führender Marktstellung sowie erfolgreiche, innovative Mittelständler, Hidden Champions und Manager in Spitzenpositionen sowohl bundesweit als auch international.
<G-vec00215-002-s208><advise.betreuen><en> Its lawyers advise companies with leading market position as well as successful, innovative medium-sized entities, hidden champions and managers in leading positions, nationwide as well as internationally.
<G-vec00215-002-s209><advise.betreuen><de> Wir betreuen namhafte Initiatoren geschlossener Fonds mit Investitionen insbesondere in den USA.
<G-vec00215-002-s209><advise.betreuen><en> We are specialized in the field of closed property funds and advise well-known initiators for more than 30 years.
<G-vec00215-002-s210><advise.betreuen><de> Wesentliches Ziel dieser Hilfe ist es, Familien in ihren Erziehungsaufgaben zu begleiten und zu betreuen und sie bei der Bewältigung von Alltagsproblemen und der Lösung von Konflikten und Krisen sowie im Kontakt zu Ämtern und Institutionen zu unterstützen.
<G-vec00215-002-s210><advise.betreuen><en> The main objective of this type of assistance is to accompany and advise families in educating their children and to support them in dealing with everyday tasks, resolving conflicts and crises, and in communicating with authorities and institutions.
<G-vec00215-002-s211><advise.betreuen><de> Wir betreuen Vorhabenträger genauso wie Bieter oder die von einer Verfügung Betroffenen, Nachbarn und Konkurrenten sowie die öffentliche Hand selbst.
<G-vec00215-002-s211><advise.betreuen><en> We advise project developers and bidders as well as people affected by a decree, neighbors and competitors.
<G-vec00215-002-s212><advise.betreuen><de> „Wir betreuen unsere Kunden mit einem engagierten und eingespielten Team.
<G-vec00215-002-s212><advise.betreuen><en> “We serve and advise our customers with a dedicated and experienced team.
<G-vec00215-002-s213><advise.betreuen><de> Und wir betreuen Sie in jeder Phase Ihres individuellen Anliegens: von der Planung einer Anlage bis zur optimierten Arbeitsumgebung für die Mitarbeiter, von der Sicherung einer Baustelle bis hin zum Havariemanagement.
<G-vec00215-002-s213><advise.betreuen><en> And we will advise you on every phase of your particular project: from planning a production operation to optimising your employees’ working environment, from making a construction site safe through to disaster management.
<G-vec00221-002-s076><serve.betreuen><de> Den amerikanischen Markt wird in Kürze ein nordamerikanischer Partner betreuen.
<G-vec00221-002-s076><serve.betreuen><en> A north-American partner will serve the American market soon.
<G-vec00221-002-s077><serve.betreuen><de> Die Lehrstühle sind mit zwei oder drei Doktoranden durch die Fakultät ausgestattet und verfügen in den meisten Fällen über weitere projektfinanzierte Mitarbeiter, die auch Projekte und Abschlussarbeiten betreuen.
<G-vec00221-002-s077><serve.betreuen><en> Staff-student ratio: The Faculty of Media provides funding for two or three doctoral students per chair. In most cases, each chair has further project-funded doctoral students who also serve as tutors for projects and theses.
<G-vec00221-002-s078><serve.betreuen><de> Wir betreuen jeden Monat 260,000-Leute (das ist 1 in 10), aber das ist immer noch nicht genug, da wir schätzen, dass 1 in 4-Leuten im Silicon Valley von Hunger bedroht ist.
<G-vec00221-002-s078><serve.betreuen><en> We serve 260,000 people every month (that’s 1 in 10), but that’s still not enough because we estimate that 1 in 4 people in Silicon Valley is at risk of hunger.
<G-vec00221-002-s079><serve.betreuen><de> Wir betreuen Kunden in ganz Deutschland, von Berlin bis Hamburg und München.
<G-vec00221-002-s079><serve.betreuen><en> We serve customers throughout Germany, from Berlin to Hamburg and Munich.
<G-vec00221-002-s080><serve.betreuen><de> Wir betreuen Kunden auch in Englisch und Deutsch.
<G-vec00221-002-s080><serve.betreuen><en> We serve clients well in English and German.
<G-vec00221-002-s081><serve.betreuen><de> Sie soll als legitimierte, unabhängige Institution gesellschaftliche Zukunftsthemen wissenschaftlich betreuen und vertreten.
<G-vec00221-002-s081><serve.betreuen><en> The academy is intended to serve as a legitimate, independent institution promoting and providing scientific expertise on issues concerning the future of society.
<G-vec00221-002-s082><serve.betreuen><de> Da wir unsere Kunden vorwiegend im Außendienst betreuen, sind wir nicht immer im Büro.
<G-vec00221-002-s082><serve.betreuen><en> Since we serve our customers primarily in the field, we are not always in the office.
<G-vec00221-002-s083><serve.betreuen><de> Zu dem Kundenkreis von Connect-Sprachenservice gehören neben zahlreichen Behörden und Anwaltskanzleien in erster Linie international agierende mittelständische Unternehmen sowie Werbeagenturen, die solche Unternehmen betreuen.
<G-vec00221-002-s083><serve.betreuen><en> On top of numerous authorities and law firms not only in Vienna but throughout Austria and Germany, Connect Translations | Translation and Interpreting Agency Vienna also has translation and interpreting customers primarily including some internationally-active medium-sized enterprises, as well as marketing agencies that serve such companies.
<G-vec00221-002-s084><serve.betreuen><de> Verkürzen Sie die Berichtszeit um die Hälfte, steigern Sie die Moral und betreuen Sie jährlich fast 50.000 Sozialarbeitsfälle besser.
<G-vec00221-002-s084><serve.betreuen><en> Cut reporting time in half, increase morale, and better serve the nearly 50,000 social work cases received annually.
<G-vec00221-002-s085><serve.betreuen><de> Als 360-Grad-Agentur betreuen wir Kunden aus allen Branchen und Ländern.
<G-vec00221-002-s085><serve.betreuen><en> As a 360-degree agency, we serve customers from all sectors and countries.
<G-vec00221-002-s086><serve.betreuen><de> Rund 75 hochqualifizierte Mitarbeiter betreuen Mexiko, Zentralamerika und die Karibik und ermöglichen schnelle Reaktionszeiten.
<G-vec00221-002-s086><serve.betreuen><en> About 75 highly trained employees serve Mexico, Central America and the Caribbean, ensuring fast response times.
<G-vec00221-002-s087><serve.betreuen><de> Neben der reinen prozessualen anwaltlichen Tätigkeit vertreten und betreuen wir die rechtlichen Interessen von Privatpersonen und mittelständischen Betrieben auch außerhalb des Gerichtssaals.
<G-vec00221-002-s087><serve.betreuen><en> Beside the pure procedural lawyer practice we represent and serve the legal interests of private persons and middle-class companies also outside the courtroom.
<G-vec00221-002-s088><serve.betreuen><de> Wir betreuen oberen Ebenen von Regierungen bei Themen wie Außenpolitik und Diplomatie.
<G-vec00221-002-s088><serve.betreuen><en> We serve top levels of government on issues such as foreign affairs and public diplomacy.
<G-vec00221-002-s089><serve.betreuen><de> Derzeit betreuen wir eine Vielzahl an Eigentumswohnanlagen und Gewerbeobjekte verschiedener Art.
<G-vec00221-002-s089><serve.betreuen><en> Currently, we serve a variety of condominiums and commercial buildings of various kinds
<G-vec00221-002-s090><serve.betreuen><de> Wir betreuen unsere Kunden aus unseren Büros in führenden Finanzzentren in Nordamerika und Europa.
<G-vec00221-002-s090><serve.betreuen><en> We serve our clients from offices in leading financial centers across North America and Europe.
<G-vec00221-002-s091><serve.betreuen><de> Wir betreuen 210 Dörfer, die 21 Zentren zugeordnet sind, in einem Gebiet von über 4 000 km².
<G-vec00221-002-s091><serve.betreuen><en> We serve 210 groups in twenty-one centers over an area of more that 4,000 square kms.
<G-vec00221-002-s092><serve.betreuen><de> Wir analysieren das soziale Umfeld aus dem die Kinder kommen, um sie optimal betreuen zu können.
<G-vec00221-002-s092><serve.betreuen><en> We are the social environment in which children are analyzed in order to optimally serve.
<G-vec00221-002-s093><serve.betreuen><de> Unsere Kunden wollen wir nach deren speziellen Bedürfnissen betreuen und ihnen individuelle und flexible Lösungen anbieten.
<G-vec00221-002-s093><serve.betreuen><en> We want to serve our customers depending on their individual needs by offering individual and flexible solutions.
<G-vec00221-002-s094><serve.betreuen><de> Wir betreuen über 4000 Kunden weltweit, darunter 43, die auf der Fortune-500-Liste der umsatzstärksten Unternehmen der Welt stehen.
<G-vec00221-002-s094><serve.betreuen><en> We serve over 4000 customers worldwide, including 43 that are listed on the Fortune 500.
<G-vec00301-002-s314><attend.betreuen><de> Unsere Consulting Dienstleistungen betreuen unsere Kunden in allen Projekt und Betriebsphasen, unsere Services sind spezifische Managed Services die unsere Kunden primär in einer effizienten Betriebsführung der SAP Systemlandschaft unterstützen.
<G-vec00301-002-s314><attend.betreuen><en> Our consulting services attend to our customers in all projects and operating phases, and our services are specifically managed services that assist our customers primarily in an efficient operational management of the SAP system landscape.
<G-vec00301-002-s315><attend.betreuen><de> Wir betreuen als Generalplaner Ihre Bauaufgabe - von einfachen Zweckbauten bis hin zu Gebäuden mit besonderen gestalterischen Ansprüchen und vom ersten Planungskonzept bis zur termin- und kostengerechten Fertigstellung.
<G-vec00301-002-s315><attend.betreuen><en> As general planners, we attend to all the needs of your construction project - whether a simple utility building or a complex one with special design requirements, and from the initial planning concept to completion on schedule and within budget.
<G-vec00301-002-s316><attend.betreuen><de> So begleiten wir deutsche Mandanten bei ihren internationalen Projekten und betreuen eine Vielzahl ausländischer Mandanten bei ihren Unternehmungen in Deutschland.
<G-vec00301-002-s316><attend.betreuen><en> Hence, we assist German clients with international projects and attend to a multiplicity of foreign clients who are commercially active in Germany.
<G-vec00301-002-s317><attend.betreuen><de> Auf der Station betreuen die Fachärzte die stationären Patienten der Inneren Medizin, sowie andere stationäre Patienten der Klinik, die aufgrund ihrer komplexen und verschiedenen Pathologien die ergänzende Intervention eines Internisten erfordern.
<G-vec00301-002-s317><attend.betreuen><en> Hospitalization On the ward the specialists attend to hospitalized patients of the Unit, and other hospitalized patients in the clinic, with complex or multiple pathologies, who need the additional intervention by an internist.
<G-vec00301-002-s318><attend.betreuen><de> Wir werden Sie sofort betreuen.
<G-vec00301-002-s318><attend.betreuen><en> We will attend to you right away.
<G-vec00301-002-s319><attend.betreuen><de> Demzufolge ist nach unserer Überzeugung eine Spezialisierung auf bestimmte Rechtsgebiete und Branchen notwendig, um Mandanten schnell und mit hoher fachlicher Qualität zu beraten und betreuen.
<G-vec00301-002-s319><attend.betreuen><en> Therefore, according to our beliefs, a specialization in certain fields of law and branches of trade are necessary to advise and attend to a client quickly and with a level of high professional quality.
<G-vec00301-002-s320><attend.betreuen><de> Plexus-Agenturen betreuen über 200 Kunden aus dem B2B und B2C-Bereich.
<G-vec00301-002-s320><attend.betreuen><en> Plexus agencies attend to more than 200 clients from the B2B and B2C areas.
<G-vec00301-002-s321><attend.betreuen><de> Die Leiter des Historischen Museums betreuen die Touristen.
<G-vec00301-002-s321><attend.betreuen><en> The curators from the history museum attend the tourists.
<G-vec00301-002-s322><attend.betreuen><de> Das 1992 gegründete Gästehaus Villa Ticino wird nach wie vor dem neuen Team mit Stolz geführt, die Reisende aus aller Welt persönlich empfangen und betreuen.
<G-vec00301-002-s322><attend.betreuen><en> Villa Ticino Guest House was established in 1992 and is now managed and run by the new team who personally welcome and attend to travellers from all around the globe.
<G-vec00301-002-s323><attend.betreuen><de> Wir betreuen Kunden im Handwerk, in der Industrie und in den Verwaltungen.
<G-vec00301-002-s323><attend.betreuen><en> We attend to customers in trades, industry and
<G-vec00301-002-s325><attend.betreuen><de> Die Eber und die anderen Sauen betreuen gelegentlich, aber grundsätzlich vorzüglich, die neuen Ferkelwürfe und lassen sich von den Ferkeln „nerven“, während die Mutter-Sau in der Zwischenzeit in Ruhe ihrem Fressbedürfnis nachkommen kann.
<G-vec00301-002-s325><attend.betreuen><en> The boar and the other sows attend occasionally, but always exquisite, the new piglet litters and can be "nervous" of the piglets, while the mother-sow in the meantime be able to meet their feeding needs at rest.
<G-vec00301-002-s326><attend.betreuen><de> Wir werden Sie in jedem unserer Büros freundlich betreuen.
<G-vec00301-002-s326><attend.betreuen><en> We will attend you kindly in any of our offices.
<G-vec00301-002-s327><attend.betreuen><de> Wenden Sie sich an unser Call Center, das rund um die Uhr erreichbar ist, und einer unserer Mitarbeiter wird Sie in Ihrer Sprache betreuen, damit Sie Ihren Fall ausführlich erläutern können, und wir können einen unserer Ärzte kontaktieren, der im Hafen von Pollensa arbeitet.
<G-vec00301-002-s327><attend.betreuen><en> Contact our Call Center, available 24/7, and one of our agents will attend you in your language so that you can explain your case in detail and we can contact one of our doctors collaborating in the Port of Pollensa.
