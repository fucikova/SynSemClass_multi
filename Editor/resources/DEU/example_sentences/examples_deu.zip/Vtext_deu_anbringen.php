<G-vec00407-001-s083><attach.anbringen><de> Lassen Sie das Armband gründlich trocknen, bevor Sie es an Ihrer Apple Watch anbringen.
<G-vec00407-001-s083><attach.anbringen><en> Let the band air dry thoroughly before you attach it to your Apple Watch.
<G-vec00407-001-s084><attach.anbringen><de> Um diese Dekoration sicher anbringen, sollte es unmittelbar nach dem Nagellack aufgetragen werden.
<G-vec00407-001-s084><attach.anbringen><en> In order to securely attach this decoration, it should be applied immediately after the nail polish.
<G-vec00407-001-s085><attach.anbringen><de> Du kannst die Sekret-Wunde an einer beliebigen Körperstelle anbringen und erhältst ein realistisches Ergebnis.
<G-vec00407-001-s085><attach.anbringen><en> You can attach the zipper wound to any body and get a realistic result.
<G-vec00407-001-s086><attach.anbringen><de> Ausführliche Informationen übersichtlich am Produkt anbringen.
<G-vec00407-001-s086><attach.anbringen><en> Attach comprehensive, clear information to the product.
<G-vec00407-001-s087><attach.anbringen><de> Unser Rat: An die Rolle erst ein festes Gummiband anbringen und an ihm die Hauptschnur verbinden.
<G-vec00407-001-s087><attach.anbringen><en> Our advise: First attach a solid rubber band to the roller and connect the main line to it.
<G-vec00407-001-s088><attach.anbringen><de> Wer die SSD Temperatur dennoch reduzieren möchte, könnte beispielsweise eine aktive SSD Kühlung durch direkte Belüftung vornehmen oder handelsübliche Silikon Wärmeleitpads zur Verteilung der Hitze auf der Platinenoberseite anbringen.
<G-vec00407-001-s088><attach.anbringen><en> Anyway, who like to reduce the SSD temperature, could perform an active SSD cooling by direct ventilation or attach commercially available silicone heat transfer pads to the top of the PCB.
<G-vec00407-001-s089><attach.anbringen><de> Sie können das Material entweder direkt auf der Wand oder auf einem Trägermaterial aus Sperrholz anbringen, das an der Wand befestigt wird.
<G-vec00407-001-s089><attach.anbringen><en> You can attach the material either directly onto the wall or onto plywood attached to the wall.
<G-vec00407-001-s090><attach.anbringen><de> Die teuflisch gut aussehenden Dämonen Hörner lassen sich einfach anbringen und überzeugen durch ihr fantastisches Aussehen.
<G-vec00407-001-s090><attach.anbringen><en> The devilishly good-looking Demon Horns are easy to attach and convince with their fantastic looks.
<G-vec00407-001-s091><attach.anbringen><de> Kopieren Sie als letzten Schritt das bestätigte RMA-Formular mit der erteilten RMA-Nummer zweimal: eine Ausfertigung bitte deutlich sichtbar an der Außenseite der Verpackung all Ihrer Rücksendungen anbringen, die zweite Ausfertigung dem Produkt beilegen.
<G-vec00407-001-s091><attach.anbringen><en> As a last step, copy the confirmed RMA form with the assigned RMA number twice: please attach one copy to a clearly visible position on the outside of the packaging on all your return consignments.
<G-vec00407-001-s092><attach.anbringen><de> Tipp: Wer die SSD Temperatur reduzieren möchte, könnte beispielsweise a) den Energiesparmodus anpassen oder b) eine aktive SSD Kühlung durch direkte Belüftung vornehmen oder c) handelsübliche Silikon Wärmeleitpads zur Verteilung der Hitze auf der Platinen Ober- und Unterseite anbringen.
<G-vec00407-001-s092><attach.anbringen><en> Tip: Who like to reduce the SSD temperature, for example can a) adjust the energy saving settings or b) perform an active SSD cooling by direct ventilation or c) attach commercially available silicone heat transfer pads to the top and bottom of the PCB.
<G-vec00407-001-s093><attach.anbringen><de> optional können sie prospektablagen aus mattem acrylglas anbringen.
<G-vec00407-001-s093><attach.anbringen><en> as an option, you can attach brochure trays made of satin acrylic.
<G-vec00407-001-s094><attach.anbringen><de> Die Gruselige Wanddeko Flammenmonster ist eine Folie die du ganz leicht mit Reißzwecken oder doppelseitigen Klebeband an der Wand anbringen und wiederverwenden kannst.
<G-vec00407-001-s094><attach.anbringen><en> The Creepy Wall Deco Flame monster is a foil that you can easily attach to the wall with zips or double-sided tape and reuse.
<G-vec00407-001-s095><attach.anbringen><de> Wählen Sie zwischen verschiedenen Größen, unabhängig davon, ob Sie Ihn vertikal oder horizontal über dem Waschtisch anbringen wollen.
<G-vec00407-001-s095><attach.anbringen><en> Choose between various sizes of your Keuco Edition 300 light mirror, regardless of whether you want attach it vertically or horizontally above the basin.
<G-vec00407-001-s096><attach.anbringen><de> Sie können die Holzklammern auf Bilderrahmen oder Holzkörbe kleben, so lassen sich Bilder oder kleine Zettel anbringen.
<G-vec00407-001-s096><attach.anbringen><en> You can glue the wooden clips on picture frames or wooden baskets, so you can attach pictures or small pieces of paper.
<G-vec00407-001-s097><attach.anbringen><de> Sie können ihn anbringen, wo Sie möchten.
<G-vec00407-001-s097><attach.anbringen><en> You can attach it wherever you want.
<G-vec00407-001-s098><attach.anbringen><de> "Mit diesem einzigartigen BDSM-Gerät können Sie einen ultra-leistungsfähigen Klitorisvibrator vom Typ ""Magic Wand"" anbringen, während Sie bei Ihrem Partner verweilen, indem Sie ihn allen Arten von sexuellem Missbrauch aussetzen....."
<G-vec00407-001-s098><attach.anbringen><en> "Indeed, this unique BDSM device will allow you to attach an ultra powerful clitoral vibrator such as a ""Magic Wand"" while you linger on your partner by subjecting her to all kinds of sexual abuse..."
<G-vec00407-001-s099><attach.anbringen><de> verfügt über alle Funktionen von Stella 1 und bietet eine zusätzliche Befestigungsmanschette, um das System einfach und schnell an Pfosten, Stangen und Rohren anbringen zu können.
<G-vec00407-001-s099><attach.anbringen><en> has all functions of Stella 1 and offers additionally support brackets, in order to attach the system simply and fast at posts, bars and tubes.
<G-vec00407-001-s100><attach.anbringen><de> Der Wäscher hat ein handliches Ring auf einem Schlüsselbund zu hängen, es an einen Haken in der Küche anbringen, etc.
<G-vec00407-001-s100><attach.anbringen><en> The scrubber has a handy ring to hang it on a keychain, attach it to a hook in the kitchen, etc.
<G-vec00407-001-s101><attach.anbringen><de> Sie können entweder einen Draht bis einen der Eingänge (wie im Beispiel unten, im kleinen Schwingungskreis über links) oder eine Prüfspitze auf einem Draht direkt anbringen, um zu ziehen.
<G-vec00407-001-s101><attach.anbringen><en> You can either attach directly a wire to one of the entrances (as in the example below, in the small oscillating circuit above left), or a probe on a wire to pull.
<G-vec00407-001-s121><attach.anbringen><de> Das heißt, dass Ladungssicherungsmaterialien so an der Ladeeinheit angebracht und/oder befestigt werden können, dass eine ausreichende Sicherung der Ladung möglich ist und die Ladung dabei unversehrt bleibt.
<G-vec00407-001-s121><attach.anbringen><en> This means that it must be possible to attach and/or secure load securing materials to the cargo unit in such a way that the load can be adequately secured while remaining undamaged.
<G-vec00407-001-s122><attach.anbringen><de> Sperrholz oder Schaumstoff müssen entsprechend dick sein, damit sie leichter an den Rahmen angebracht werden können.
<G-vec00407-001-s122><attach.anbringen><en> Plywood or foam would need to be accordingly thick, to make them easier to attach to the frame.
<G-vec00407-001-s123><attach.anbringen><de> Die mitgelieferten Zahlen von 1 - 9 und die Buchstaben von a - f können einfach durch Aufkleben angebracht werden.
<G-vec00407-001-s123><attach.anbringen><en> This item comes with the numbers 1?9 and the letters a?f that you can simply attach by sticking them on.
<G-vec00407-001-s124><attach.anbringen><de> Einfache Montage, nur die Beine müssen angebracht werden.
<G-vec00407-001-s124><attach.anbringen><en> Easy assembly, simply attach the legs
<G-vec00407-001-s125><attach.anbringen><de> Benutze die Antigrav-Einheit vor der Tür, dadurch wird sie an die Unterseite der Tür angebracht und die Tür wird halb hochgehoben.
<G-vec00407-001-s125><attach.anbringen><en> Use the anti-gravity device in front of the door, this will attach it to the underside of the door, allowing it to rise halfway.
<G-vec00407-001-s126><attach.anbringen><de> Es handelt sich hier um eine weiße Eisenfolie, auf der Magnete angebracht werden können.
<G-vec00407-001-s126><attach.anbringen><en> This is a white iron sheet to which you can attach magnets.
<G-vec00407-001-s127><attach.anbringen><de> Stück Beschreibung Die Pumpe ist mit Saugnäpfen ausgestattet, so dass sie am Boden eines Reservoirs angebracht werden kann.
<G-vec00407-001-s127><attach.anbringen><en> Description The pump is equipped with suction cups so that you can attach it to the bottom of the reservoir.
<G-vec00407-001-s128><attach.anbringen><de> Im konkreten Anwendungsfall des Forschungsprojekts soll ein S3-Label wie ein Klebestreifen auf einem pneumatischen Antrieb von Festo angebracht werden.
<G-vec00407-001-s128><attach.anbringen><en> In the actual application of the research project, the aim is to attach an S3 label like an adhesive strip to a Festo pneumatic drive.
<G-vec00407-001-s129><attach.anbringen><de> Zum anderen können mittels Ankerstich Schlingen an Bäumen fixiert oder eine Selbstsicherungsschlinge am Gurt und in Karabinern angebracht werden.
<G-vec00407-001-s129><attach.anbringen><en> On the other hand, girth hitches can also be used to fasten slings to trees and to attach a personal anchor sling to a harness and carabiner.
<G-vec00407-001-s130><attach.anbringen><de> Geringfügige Montage erforderlich, die Beine müssen angebracht werden.
<G-vec00407-001-s130><attach.anbringen><en> Assembly required, simply attach the legs
<G-vec00407-001-s131><attach.anbringen><de> Dieser Paketaufschriftzettelwird Ihnen dann per E-mail zugeschickt und muss ausgedruckt und auf dem Paket angebracht werden.
<G-vec00407-001-s131><attach.anbringen><en> This package label will be sent to you via e-mail which you then will have to print out and attach to the package.
<G-vec00407-001-s132><attach.anbringen><de> Sie werden einfach mit Magnetband oder Klettband auf den zu verblendeten Seiten der Möbel angebracht und machen aus diesen akustisch wirksame Oberflächen, die überdies sehr dekorativ aussehen.
<G-vec00407-001-s132><attach.anbringen><en> They easily attach with velcro or magnets to the furniture and turn them into highly decorative acoustic surfaces.
<G-vec00407-001-s133><attach.anbringen><de> Artikelcode Dieser Artikel enthält ein Universal-Zubehör-Verbindungsstück vom Typ 3, mit dem Bugaboo Accessoires am Schiebebügel des Bugaboo Bee oder Bugaboo Donkey angebracht werden können.
<G-vec00407-001-s133><attach.anbringen><en> This item contains an universal accessory connector type #3 that can be used to attach accessories to the handlebar for the Bugaboo Bee or the Bugaboo Donkey.
<G-vec00407-001-s181><attach.anbringen><de> Für elektrische Geräte und Apparate ist es nicht erforderlich, die CE-Kennzeichnung auf dem Produkt selbst anzubringen.
<G-vec00407-001-s181><attach.anbringen><en> It is not necessary to attach the CE marking to an electrical device.
<G-vec00407-001-s182><attach.anbringen><de> Im Verstand halten, daß dir erlaubt wirst, pics, wenn du mindestens bekanntgegeben hast 15 Anzeigen anzubringen auf diesem Forum.
<G-vec00407-001-s182><attach.anbringen><en> Keep in mind that you will be allowed to attach pics when you have posted, at least, 15 messages on this forum.
<G-vec00407-001-s183><attach.anbringen><de> Das optische Auslesen des Sensors erlaubt es, den Sensor in jeder beliebigen Geometrie anzubringen.
<G-vec00407-001-s183><attach.anbringen><en> The optical selection of the sensor makes it possible to attach the sensor in any chosen geometry.
<G-vec00407-001-s184><attach.anbringen><de> weitere Infos Anhängeetiketten Anhängeetiketten sind auf der Vorder- und Rückseite bedruckbare Kartonzuschnitte, die mit einer Lochstanzung ausgestattet sind, um Fäden anzubringen.
<G-vec00407-001-s184><attach.anbringen><en> Hang tags are cardboard blanks, which can be printed on front and back, and are equipped with hole punching to attach threads.
<G-vec00407-001-s185><attach.anbringen><de> Er ist selbstklebend und leicht anzubringen.
<G-vec00407-001-s185><attach.anbringen><en> It is self-adhesive and easy to attach.
<G-vec00407-001-s186><attach.anbringen><de> 5.12 Der Verkäufer ist in seinem Shop nicht dazu berechtigt, Links, die auf externe Webseiten verweisen, in irgendeiner Form anzubringen.
<G-vec00407-001-s186><attach.anbringen><en> 5.12 The seller is not entitled to attach links to external websites to his online-shop in any form.
<G-vec00407-001-s187><attach.anbringen><de> Durch die reduzierte Größe des Datenträgers, ist es möglich, die Tags an kleine metallische Posten von außen anzubringen.
<G-vec00407-001-s187><attach.anbringen><en> The reduced tag size allows users to attach them even to small metallic carriers.
<G-vec00407-001-s188><attach.anbringen><de> Sie sind dann bereit, Ihr Prügelgerät anzubringen.
<G-vec00407-001-s188><attach.anbringen><en> You are then ready to attach your spanking implement.
<G-vec00407-001-s189><attach.anbringen><de> Segway Switzerland bietet Ihnen die nachfolgenden Handbücher und Anleitungen, um Ihren Segway PT zu verstehen oder um weitere oder neue Bestandteile anzubringen.
<G-vec00407-001-s189><attach.anbringen><en> Segway Switzerland offers you the following handbooks and instructions for your records, to help you understand your Segway PT or to attach further or new components.
<G-vec00407-001-s190><attach.anbringen><de> Sogar der Leica-Gurt hat die perfekte Länge, so wie er aus der Box kommt, und er ist viel einfacher anzubringen, einzustellen und abzunehmen als jeder andere.
<G-vec00407-001-s190><attach.anbringen><en> Even LEICA's included strap is the perfect length right out of the box, and much easier to attach, adjust and remove than anything else.
<G-vec00407-001-s191><attach.anbringen><de> Diese Halterung ermöglicht es Ihnen die Garmin VIRB Ultra 30 an Ihrem Hangelenk oder an runden Objekten mit einem Durchmesser von bis zu 203 mm anzubringen.
<G-vec00407-001-s191><attach.anbringen><en> This mount enables you to attach your Garmin VIRB Ultra 30 on your wrist or other round objects with a diameter up to 203 mm.
<G-vec00407-001-s192><attach.anbringen><de> Für den einfachen Zugriff auf dieses kleine Werkzeug benötigen Sie einen Golfhutclip, um es an Ihrem Hut anzubringen.
<G-vec00407-001-s192><attach.anbringen><en> For easy access to this little tool, you would need a golf hat clip to carry it along to attach on your hat.
<G-vec00407-001-s193><attach.anbringen><de> Leicht anzubringen, lang genug um die Leine vom Rad weg zu halten wenn der Hund mal nicht so zieht und eine 90 Gradabwinkelung ist auch kein Problem.
<G-vec00407-001-s193><attach.anbringen><en> Easy to attach, long enough to keep the leash away from the wheel when the dog is not pulling and a 90 degree angle is no problem.
<G-vec00407-001-s194><attach.anbringen><de> Sie sind in drei Qualitätsstufen Basixx, Axxent und Luxxus erhältlich und sind problemlos anzubringen.
<G-vec00407-001-s194><attach.anbringen><en> They are available in three quality levels Basixx, Axxent and Luxxus and are easy to attach.
<G-vec00407-001-s195><attach.anbringen><de> Der Prozeß des freien christlichen ecard Annoncierens erlaubt Christen von auf der ganzen Erde, Zugang zu den Informationen und Produkte durch eine bestimmte Organisation anbieten zu lassen, die christliche ecards bereitstellt.Zusätzlich zu einem personifizierten Text erlaubt ein freies christliches ecard einem Verbraucher, unterschiedliche Hintergründe, Bilder und Musik zu verursachen, um zu ihren christlichen ecards anzubringen.
<G-vec00407-001-s195><attach.anbringen><en> The process of free Christian ecard advertising allows Christians from all over the world to have access to information and products offered by a particular organization providing Christian ecards.In addition to a personalized text, a free Christian ecard allows a consumer to create different backgrounds, images and music to attach to their Christian ecards.
<G-vec00407-001-s196><attach.anbringen><de> Die Ringe auf jeder Seite des Balls ermöglichen Ihnen, eine Kette oder anderes BDSM-Zubehör anzubringen.
<G-vec00407-001-s196><attach.anbringen><en> The rings on each side of the ball allow you to attach a chain or other BDSM accessory.
<G-vec00407-001-s197><attach.anbringen><de> Es war wichtig, die Magnete nicht zu früh anzubringen, da sich ansonsten die Metallspäne aus der Farbe gelöst und an die Magnete geheftet hätten.
<G-vec00407-001-s197><attach.anbringen><en> It was important not to put the magnets on too early, otherwise the metal chips could have loosened from the paint and attach to the magnets.
<G-vec00407-001-s198><attach.anbringen><de> Ich kaufte ein Paket der hölzernen Schrauben und der Unterlegscheiben, um das Zeichen zum Ende des Besens anzubringen und bohrte vier weitere Löcher an der Unterseite, um zusätzliche Stärke zur Verfügung zu stellen.
<G-vec00407-001-s198><attach.anbringen><en> This would reduce their extension to less than an inch. I bought a packet of wood screws and of washers to attach the sign to the end of the broom and drilled four more holes at the bottom to provide additional strength.
<G-vec00407-001-s199><attach.anbringen><de> Was ich vermisst habe: Eine Möglichkeit das Handy anzubringen, denn Navigation ist auch hier nötig.
<G-vec00407-001-s199><attach.anbringen><en> What I missed: A possibility to attach the mobile phone, because navigation is also necessary here.
<G-vec00519-002-s128><attach.anbringen><de> Auf solchen Tafeln können Prospekte mit Beispielen, verschiedenen Erinnerungen oder Notizen von meiner Mutter angebracht werden.
<G-vec00519-002-s128><attach.anbringen><en> On such boards it is possible to attach leaflets with examples, different reminders or notes from my mother.
<G-vec00519-002-s129><attach.anbringen><de> Der Halter kann auf der Rückseite Ihres Smartphones angebracht werden.
<G-vec00519-002-s129><attach.anbringen><en> Silicone cardholder with 3M tape to attach it to the back of your smartphone.
<G-vec00519-002-s131><attach.anbringen><de> Während die Wii-Fernbedienung zwar eine Reihe von Problemen gelöst und auch die Kritiker überzeugt hat, trat für uns eine neue Herausforderung auf: Um mit der Wii-Fernbedienung zu spielen, musste ein Sensor am Fernsehgerät angebracht werden.
<G-vec00519-002-s131><attach.anbringen><en> While the Wii Remote solved a variety of problems and won over its critics, we were then faced with a new challenge. In order to actually play with the Wii Remote, we needed to attach a sensor to the TV.
<G-vec00519-002-s132><attach.anbringen><de> GEPÄCK-SPANNGURT Personalisiere dein aufblasbares SUP mit verschiedenfarbigen Spanngurten, die an den Gepäcksystembefestigungen angebracht werden können.
<G-vec00519-002-s132><attach.anbringen><en> Quickly personalise your inflatable SUP with a variety of different coloured bungee cords to attach to your cargo tie down points.
<G-vec00519-002-s133><attach.anbringen><de> Du kannst auch eine Wasserwaage mit Laser benutzen, was einfacher und genauer sein könnte (es gibt viele Modelle, die an der Wand angebracht werden können).
<G-vec00519-002-s133><attach.anbringen><en> You can also use a laser level, which may be easier and more accurate (there are many models that can attach to a wall).
<G-vec00519-002-s134><attach.anbringen><de> WingLights 360 sind unsere originalen, hochwertigen Fahrtrichtungsanzeiger, die an den Lenkerenden Ihres Fahrrads angebracht werden.
<G-vec00519-002-s134><attach.anbringen><en> USD Cart (0) indicators and sidelights that magnetically attach to the handlebar ends of your bicycle.
<G-vec00519-002-s135><attach.anbringen><de> Erweitertes QD-Magazin kann nun angebracht werden.
<G-vec00519-002-s135><attach.anbringen><en> Can now attach extended QD mag.
