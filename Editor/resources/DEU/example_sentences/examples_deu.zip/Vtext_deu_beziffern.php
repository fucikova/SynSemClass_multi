<G-vec00003-001-s151><estimate.beziffern><de> Seriöse Berechnungen beziffern diese Zusatzkosten auf bis zu 3 Prozent.
<G-vec00003-001-s151><estimate.beziffern><en> Serious calculations estimate additional costs of up to 3 percent.
<G-vec00003-001-s152><estimate.beziffern><de> Das Wachstum würde ich, ohne konkrete Zahlen, als überdurchschnittlich beziffern.
<G-vec00003-001-s152><estimate.beziffern><en> Without going into specific numbers I'd estimate the growth to be exceptionally high.
<G-vec00003-001-s153><estimate.beziffern><de> Die bei Männern gegenÃ1⁄4ber Frauen grundsätzlich höhere Krankenhausinzidenz (10:1 fÃ1⁄4r nrAAA, 6Â:Â 1 fÃ1⁄4r rAAA) ist konsistent mit den Ergebnissen anderen Studien, die das Geschlechterverhältnis mit circa 2,6–6:1 beziffern, wobei methodische Heterogenität einen direkten Vergleich erschwert (13, 22 –25).
<G-vec00003-001-s153><estimate.beziffern><en> The overall higher hospital incidence for men as compared to women (of 10:1 for nrAAA, and 6:1 for rAAA) is consistent with the results of other studies, which estimate the sex ratio to be around 2.6–6:1, although direct comparisons are difficult to make due to methodological heterogeneity (13, 22 –25).
<G-vec00003-001-s154><estimate.beziffern><de> Thomas Michels: Offen gesprochen ist das sehr schwer, konkrete Aufwände zu beziffern.
<G-vec00003-001-s154><estimate.beziffern><en> Thomas Michels: Speaking openly, it is really difficult to estimate concrete expenses.
<G-vec00003-001-s155><estimate.beziffern><de> Es kann sehr schwierig sein, bei der Mandatsübernahme die genaue Höhe eines Honorars zu beziffern.
<G-vec00003-001-s155><estimate.beziffern><en> It can be difficult to estimate the total fee when undertaking an assignment.
<G-vec00003-001-s156><estimate.beziffern><de> Unserer Erfahrung nach ist es aber sehr schwer, die genaue Anzahl von Homepages mit rechtsextremen Inhalten zu beziffern, es sind lediglich grobe Schätzungen möglich.
<G-vec00003-001-s156><estimate.beziffern><en> In our experience, however, it is very difficult to estimate the exact number of sites with far-right material – it's really only possible to make a rough estimate.
<G-vec00003-001-s157><estimate.beziffern><de> Auf jährlich 1,5 Milliarden Euro beziffern EU-Experten den volkswirtschaftlichen Schaden durch Keime, die gleich gegen mehrere Antibiotika resistent geworden sind.
<G-vec00003-001-s157><estimate.beziffern><en> EU experts estimate the annual economic damage caused by germs that have become resistant to multiple antibiotics to be around €1.5 billion.
<G-vec00322-002-s046><quantify.beziffern><de> Die Verwaltung von ausstehenden Forderungen ist Teil der Unternehmensführung und bedeutet eine erhebliche Investition von Zeit und Geld, die zu Beginn eines Postens nur schwer zu beziffern ist und Fachkenntnisse erfordert.
<G-vec00322-002-s046><quantify.beziffern><en> The management of unsettled credit in the administration of a company is a considerable investment in terms of time and money, which is often difficult to quantify when the position is opened, and also requires specific know how.
