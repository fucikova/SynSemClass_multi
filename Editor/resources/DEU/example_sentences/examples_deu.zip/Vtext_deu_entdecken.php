<G-vec00169-001-s023><glean.entdecken><de> Erforschung von neuen potentiellen neuroprotektiven Mechanismen, die wir bei unseren Studien zur Regeneration entdeck(t)en.
<G-vec00169-001-s023><glean.entdecken><en> To investigate new potential mechanisms of neuroprotection, which we glean(ed) from our studies on regeneration.
<G-vec00503-001-s235><reveal.entdecken><de> Ein Ausblick auf das Meer ist selbstverständlich und mit einem Blick in den Teller entdecken Sie jedes Mal frische Zutaten aus der Umgebung zubereitet auf hervorragende Weise.
<G-vec00503-001-s235><reveal.entdecken><en> Given the location, the view of the sea is mesmerising while your view of the plate will always reveal fresh, local ingredients prepared in an excellent manner.
<G-vec00503-001-s236><reveal.entdecken><de> Bestellcode: WG492 Assassins Creed Odyssey - Xbox One Konsolenspiel - in dem Sie durch die eigene Familie zum Tode verurteilt sind und sich auch eine erstaunliche Reise begeben, auf der Sie vom Söldner-Abschaum zum legendären griechischen Held werden und die Geheimnisse Ihrer Vergangenheit entdecken.
<G-vec00503-001-s236><reveal.entdecken><en> Assassins Creed Odyssey - Xbox One Console Game, in which you are sentenced to death by your own family and embark on a wonderful journey on which you will become a legendary Greek hero from the mercenary to reveal the secrets of your past.
<G-vec00503-001-s237><reveal.entdecken><de> Assassins Creed Odyssey - Xbox One Konsolenspiel - in dem Sie durch die eigene Familie zum Tode verurteilt sind und sich auch eine erstaunliche Reise begeben, auf der Sie vom Söldner-Abschaum zum legendären griechischen Held werden und die Geheimnisse Ihrer Vergangenheit entdecken.
<G-vec00503-001-s237><reveal.entdecken><en> Assassins Creed Odyssey - PS4 Console Game, in which you are sentenced to death by your own family and embark on a wonderful journey on which you will become a legendary Greek hero from the mercenary to reveal the secrets of your past.
<G-vec00503-001-s238><reveal.entdecken><de> - Entdecken Sie die maximale Leistung Ihrer Smartphones, Tablets, PCs, NAS, Smart TVs und Spielekonsolen mit dem Dual Band Gigabit Router 1200, so dass Sie nahtlos UHD Videos streamen oder Online-Spiele rund um Ihr Zuhause genießen können.
<G-vec00503-001-s238><reveal.entdecken><en> - Reveal the maximum power of your smartphones, tablets, PCs, NAS, Smart TVs and game consoles by using the Dual Band Gigabit Router 1200, enabling you to seamlessly stream UHD videos or enjoy online games all around your home.
<G-vec00503-001-s239><reveal.entdecken><de> Wählen Sie eine Hexe, um eine versteckte Anzahl an Freispiele zu entdecken, die Sie gewinnen können.
<G-vec00503-001-s239><reveal.entdecken><en> Select a witch to reveal a hidden number of free games you’ll win.
<G-vec00503-001-s240><reveal.entdecken><de> Die Analyse der graphischen Spur, die die Preisbewegung nach sich lasst, erlaubt bestimmte Gesetzmäßigkeiten zu entdecken, die später als Handelssignale für die Traders und Analytiker dienen.
<G-vec00503-001-s240><reveal.entdecken><en> Analysis of the graphical line of the price movement enables to reveal certain patterns that later become trading signals for the traders and analysts.
<G-vec00503-001-s241><reveal.entdecken><de> Dieses leistungsstarke Teleskop wurde entworfen, um das Glühen von derartigem Staub zu entdecken und somit die Verstecke der jungen, sich gerade bildenden Sterne ausfindig zu machen.
<G-vec00503-001-s241><reveal.entdecken><en> This powerful telescope was designed to spot the heat glow of dust like this, to reveal the hiding places where new stars form.
<G-vec00503-001-s242><reveal.entdecken><de> Bei ihren Nachforschungen entdecken sie eine dunkle Seite des Lebens in Arcadia Bay, aber Max und Chloe sind entschlossen, die Wahrheit aufzudecken.
<G-vec00503-001-s242><reveal.entdecken><en> Their investigation begins to reveal a much darker side to life in Arcadia Bay, but Max and Chloe remain determined to uncover the truth.
<G-vec00503-001-s243><reveal.entdecken><de> Wir spazieren am Hotelstrand entlang, tauchen in Felsenbecken ein und entdecken die verborgenen Geheimnisse der Küste.
<G-vec00503-001-s243><reveal.entdecken><en> Stroll along the hotels’ beach,dip into rock pools, and reveal the hidden secrets of the coast.
<G-vec00503-001-s244><reveal.entdecken><de> Er sah in ihnen lebendige Vermittler, die in einem vergangenen Wort das Gegenwärtige entdecken, es neu zu sehen und neu zu leben vermögen.
<G-vec00503-001-s244><reveal.entdecken><en> He saw them as living mediators who reveal the present in a word from the past, allowing us to see and live it in a new way.
<G-vec00503-001-s245><reveal.entdecken><de> Â Â Assassins Creed Odyssey - PS4 Konsolenspiel - in dem Sie durch die eigene Familie zum Tode verurteilt sind und sich auch eine erstaunliche Reise begeben, auf der Sie vom Söldner-Abschaum zum legendären griechischen Held werden und die Geheimnisse Ihrer Vergangenheit entdecken.
<G-vec00503-001-s245><reveal.entdecken><en> Â Â Assassins Creed Odyssey - PS4 Console Game, in which you are sentenced to death by your own family and embark on a wonderful journey on which you will become a legendary Greek hero from the mercenary to reveal the secrets of your past.
<G-vec00503-001-s246><reveal.entdecken><de> Diesen mitteleuropäischen, verführerischen und verspielten geschichtlichen Zeitraum werden Sie nicht nur in den Kirchen, sondern auch beim Spaziergang durch den alten Stadtkern, auf den Straßen und Fassaden entdecken.
<G-vec00503-001-s246><reveal.entdecken><en> In addition to the churches, this Central European seductive, playful and historical period will reveal itself to you whilst walking around the historical City core admiring its facades and streets.
<G-vec00503-001-s247><reveal.entdecken><de> Istrien und Poreč entdecken Ihnen alle ihre Geheimnisse im Hotel Laguna Molindrio.
<G-vec00503-001-s247><reveal.entdecken><en> Istria and Poreč will reveal all their secrets to you at the Hotel Laguna Molindrio.
<G-vec00503-001-s248><reveal.entdecken><de> Gönnen Sie sich ein einmaliges historisches Erlebnis und entdecken Sie mit uns 75 Geheimnisse einer bekannten Tatra-Seilbahn.
<G-vec00503-001-s248><reveal.entdecken><en> Treat yourself to a unique historical experience and reveal 75 secrets of a famous cable car of the Tatras with us.
<G-vec00503-001-s249><reveal.entdecken><de> Die Kinder freuen sich über die Säulen zum Entdecken des Artenreichtums.
<G-vec00503-001-s249><reveal.entdecken><en> Children will enjoy the signposts that reveal the surrounding biodiversity.
<G-vec00503-001-s250><reveal.entdecken><de> Alternativ begeben Sie sich ins Inland und entdecken Sie die versteckten Schätze der Region.
<G-vec00503-001-s250><reveal.entdecken><en> Or drive inland to reveal the hidden gems of this region.
<G-vec00503-001-s251><reveal.entdecken><de> "Die natürlichen Schönheiten (Naturpark ""Kopački rit"", See ""Biljsko jezero""...), das historische Erbe wie das Jagdschloss des Prinzen Savoyen oder viele bedeutende Events (Internationale Ethnotreffen, Fischertage in Kopačevo...) entdecken ein reichhaltiges kulturelles, natürliches und gastronomisches Baranjer Angebot, das die Gemeinde Bilje zu einem idealen Ort für Abenteurer, Jäger, Fischer, Radfahrer und Naturliebhaber macht."
<G-vec00503-001-s251><reveal.entdecken><en> Natural beauties (Nature Park Kopački rit, the Bilje Lake…), historical heritage such as the hunting castle of the Prince of Savoy, and many important events (International Ethno Meetings, Fishing Days in Kopačevo…) reveal Baranja’s rich cultural, natural and gastronomic offer, which makes the Bilje Municipality the ideal place for adventurers, hunters, fishermen, cyclists and nature lovers.
<G-vec00503-001-s252><reveal.entdecken><de> Assassins Creed Odyssey - PS4 Konsolenspiel - in dem Sie durch die eigene Familie zum Tode verurteilt sind und sich auch eine erstaunliche Reise begeben, auf der Sie vom Söldner-Abschaum zum legendären griechischen Held werden und die Geheimnisse Ihrer Vergangenheit entdecken.
<G-vec00503-001-s252><reveal.entdecken><en> Assassins Creed Odyssey PC Game, in which you are sentenced to death by your own family and embark on a wonderful journey on which you will become a legendary Greek hero from the mercenary to reveal the secrets of your past.
<G-vec00503-001-s253><reveal.entdecken><de> Bestellcode: MXESD0058 Assassins Creed Odyssey - PS4 Konsolenspiel - in dem Sie durch die eigene Familie zum Tode verurteilt sind und sich auch eine erstaunliche Reise begeben, auf der Sie vom Söldner-Abschaum zum legendären griechischen Held werden und die Geheimnisse Ihrer Vergangenheit entdecken.
<G-vec00503-001-s253><reveal.entdecken><en> Assassins Creed Odyssey - Xbox One Console Game, in which you are sentenced to death by your own family and embark on a wonderful journey on which you will become a legendary Greek hero from the mercenary to reveal the secrets of your past.
<G-vec00001-001-s114><found.entdecken><de> Es wird entdeckt, dass Nahrung in Lagerräumen fehlt, geplündert von jenen, die davon wussten und in Panik gerieten, an sich selber dachten.
<G-vec00001-001-s114><found.entdecken><en> Food in storage holds is found missing, looted by those who knew about it and panicked, thinking of themselves.
<G-vec00001-001-s115><found.entdecken><de> Aber auch Prinzen, Grafen und Freiherrn entdeckt man unter den Unterstützern.
<G-vec00001-001-s115><found.entdecken><en> And more than one prince, count or freiherr can be found among the supporters as well.
<G-vec00001-001-s116><found.entdecken><de> Und als es zu der Zeit von einem Freund namens Joe Lisa zurückverfolgt wurde, stellte sich heraus: Bob Thomas hatte jene Worte in die B-1-Akte über mich geschrieben, (das ist eine Geheimakte), und jene Worte waren vom GO bis 1980 benutzt worden, um sicher zu stellen, daß alles was ich sagte als Halluzination gekennzeichnet wurde, damit die Infiltratoren niemals entdeckt würden.
<G-vec00001-001-s116><found.entdecken><en> "And when it was checked back by a friend at that time named Joe Lisa, it was found that: Bob Thomas had written those words in the""B-1"" file, (that's an ""intelligence file"") about me, and that those words had been used by the GO all up until 1980 and B-1 to make sure that anything I said was labelled ""hallucination"" so that the plants would never be found out."
<G-vec00001-001-s117><found.entdecken><de> Wenn das Programm Inkonsistenzen zwischen IFO und VOB Dateien entdeckt, versucht es, diese zu beheben.
<G-vec00001-001-s117><found.entdecken><en> If mismatch between information in ifo and vob files is found program will try to fix the problem.
<G-vec00001-001-s118><found.entdecken><de> Er hat schlicht und ergreifend seine Liebe zum Sport noch nicht entdeckt.
<G-vec00001-001-s118><found.entdecken><en> He just hasn´t found a love for sport yet.
<G-vec00001-001-s119><found.entdecken><de> Koffein wasserfrei ist im Wesentlichen Koffein, die in Lebensmitteln und Getränken (wie Tee und Kaffee), aber ohne die Wasser Material entdeckt wird.
<G-vec00001-001-s119><found.entdecken><en> Caffeine anhydrous is basically caffeine that is found in foods as well as beverages (such as tea and also coffee) however without the water content.
<G-vec00001-001-s120><found.entdecken><de> Wenn ihr die Barmherzigkeit schon entdeckt habt, seid nicht stolz oder überheblich, glaubt nicht dass ihr schon vollkommen seid.
<G-vec00001-001-s120><found.entdecken><en> If you have found my mercy already, do not be proud and presumptuous to assume that you are already perfect.
<G-vec00001-001-s121><found.entdecken><de> Du spielst wie gesagt alle Instrumente auf den Alben selbst, bist auch bei NORMA LOY schon als Gitarrist aufgetaucht, wie ich im Internet auf einer NORMA LOY-Seite entdeckt habe.
<G-vec00001-001-s121><found.entdecken><en> Like you said, you play all instruments on the albums yourself, and you have also served as guitarist for NORMA LOY as I have found on the internet on the NORMA LOY page.
<G-vec00001-001-s122><found.entdecken><de> Hollywood hat Clenbuterol entdeckt, erklärt es das brandneue abnehmen-Wundermittel und nahm den neuesten Trend im Schlankheits-Tabletten.
<G-vec00001-001-s122><found.entdecken><en> Hollywood has found Clenbuterol, stated it the brand-new weight-loss wonder drug and began the latest craze in slendering tablets.
<G-vec00001-001-s123><found.entdecken><de> Dank der weisen Entscheidung der französischen Restauratoren wurde die Tempelanlage nahezu in ihrem Orginalzustand (so wie sie entdeckt wurde) belassen.
<G-vec00001-001-s123><found.entdecken><en> Thanks to the wisdom of some french historians, the temple is still quite in the same condition like it was when it was found.
<G-vec00001-001-s124><found.entdecken><de> In den Neolithikumschichten des Hügels wurden 25 Gräber entdeckt.
<G-vec00001-001-s124><found.entdecken><en> 25 graves were found in the Neolithic layers of the mound.
<G-vec00001-001-s125><found.entdecken><de> Sie wurde in vielen, vielen Ländern entdeckt.
<G-vec00001-001-s125><found.entdecken><en> Many, many countries it's been found in.
<G-vec00001-001-s126><found.entdecken><de> Umso glücklicher war ich, als ich dieses tolle Praktikum bei SKIDATA im Internet entdeckt habe.
<G-vec00001-001-s126><found.entdecken><en> That’s why I was all the more happy that I found online this great internship at SKIDATA.
<G-vec00001-001-s127><found.entdecken><de> Sie haben soeben den richtigen Ort für die Unterkunft im Königreich der mährischen Weinberge entdeckt.
<G-vec00001-001-s127><found.entdecken><en> You have just found the right place for accommodation in the kingdom of the Moravian vineyards.
<G-vec00001-001-s128><found.entdecken><de> Am Haupteingang wurden die Überreste einer Hydraulik-Uhr entdeckt.
<G-vec00001-001-s128><found.entdecken><en> Remains were found of a hydraulic clock at its central entrance.
<G-vec00001-001-s129><found.entdecken><de> Eine Praktizierende wurde entdeckt, als sie einen Dafa Artikel las.
<G-vec00001-001-s129><found.entdecken><en> One practitioner was found reading a Falun Gong article.
<G-vec00001-001-s130><found.entdecken><de> Folsäure-Mangel im Körper tatsächlich entdeckt worden vorzeitigen Haarausfall in einem frühen Alter zu verursachen, während sie zahlreiche andere gesundheitlichen Probleme enthüllt.
<G-vec00001-001-s130><found.entdecken><en> Folic acid deficiency in the human body has been found to cause early hair loss at a very early age while exposing yourself to numerous other health-related problems.
<G-vec00001-001-s131><found.entdecken><de> Die Hunderte von Benutzern, die Vorteile entdeckt haben, haben nur Erfolgsgeschichten zu erzählen.
<G-vec00001-001-s131><found.entdecken><en> The countless users that have found advantages have only success stories to narrate.
<G-vec00001-001-s132><found.entdecken><de> In einem Berg auf einer nahe gelegenen Insel wurde eine wertvolle Erzader entdeckt.
<G-vec00001-001-s132><found.entdecken><en> In a mountain on a nearby island, a valuable ore vein has been found.
