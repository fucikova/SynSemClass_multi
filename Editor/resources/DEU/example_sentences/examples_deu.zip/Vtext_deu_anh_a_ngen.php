<G-vec00407-001-s022><append.anhängen><de> Falls kein Abschnittstitel gefunden wird, ist die Voreinstellung, neue Einträge an das Ende der Datei anzuhängen.
<G-vec00407-001-s022><append.anhängen><en> If no section title is found, the default is to append new entries to the end of the file.
<G-vec00407-001-s043><append.anhängen><de> 9.0 Erstellen und Textdokumente bearbeiten.Age Date Diff Calculator 1.2 Berechnen Alter von bestimmten Geburtsdatum oder Differenz zwischen zwei Daten.TaskRun Week Planner 2015.3 Planen Sie Ihre Woche auf einer 7 Tage Kalender Raster.Join Multiple RTF Files Into One Software 7.0 Vertikal angehängt viele RTF-Dateien, speichern Ergebnis als neue RTF-Datei.Byte Converter 1.6 Konvertieren numerische Werte zwischen verschiedenen digitalen Informationseinheiten.Target Sum Finder 1.0 Lösungen zu finden, um die Zielsumme für eine Menge von Daten zu treffen.STIMS Buffer 1.0 Berechnen Sie Rezepte für biologische Puffer.Free Jetico Scientific Calculator 1.0 Führen wissenschaftliche, technische und mathematische Berechnungen.Rupees to Words Finder 1.0 Konvertieren Indische Rupien oder US-Dollar Zahlen, Worte.1833 Programme in dieser Kategorie / 92 Seiten.1...
<G-vec00407-001-s043><append.anhängen><en> 1.2 Calculate age from given birth date or difference between two dates.TaskRun Week Planner 2015.3 Plan your week on a seven day calendar grid.Join Multiple RTF Files Into One Software 7.0 Vertically append many RTF files, save result as a new RTF file.Byte Converter 1.6 Convert numeric values between different digital information units.Target Sum Finder 1.0 Find solutions to hit target sum for a set of data.STIMS Buffer 1.0 Calculate recipes for biological buffers.Free Jetico Scientific Calculator 1.0 Perform scientific, engineering, and mathematical calculations.Rupees to Words Finder 1.0 Convert Indian Rupees or US Dollars numerals to words.1833 programs in this category / 92 pages.1...
<G-vec00407-001-s044><append.anhängen><de> "Wir haben drei Bonustracks von langen vergriffenen Alben gefunden, die an das Originalalbum angehängt wurden, um diese The Complete Coral Christmas Recordings zu machen: ""Be a Santa"" kommt aus dem Album The McGuire Sisters Sing ""Subways Are for Sleeping"", ""Peace"" ist von May You Always und ""Ave Maria"" kommt von In Harmony with Him."
<G-vec00407-001-s044><append.anhängen><en> "We found three bonus tracks from long out-of-print albums to append to the original album to make this The Complete Coral Christmas Recordings: ""Be a Santa"" comes from the album The McGuire Sisters Sing ""Subways Are for Sleeping,"" ""Peace"" is from May You Always, and ""Ave Maria"" comes from In Harmony with Him."
<G-vec00407-001-s045><append.anhängen><de> Meistens wirst Du vermutlich den Befehl zum Anhaengen (-A) oder Loeschen (-D) einer Regel verwenden.
<G-vec00407-001-s045><append.anhängen><en> Most commonly, you will probably use the append (-A) and delete (-D) commands.
<G-vec00407-001-s047><append.anhängen><de> "Bei Auswahl der Option "" Werteliste verwenden "" können Sie beliebig viele Einträge für die Dropdown-Liste der Auswahlliste sowie für die zugehörigen XML-Werte einfügen, anhängen, bearbeiten und löschen."
<G-vec00407-001-s047><append.anhängen><en> If you select Use List of Values, you can insert, append, edit, and delete any number of entries for the drop-down list of the combo box as well as for the corresponding XML values.
<G-vec00407-001-s048><append.anhängen><de> -a Ausgabe an vorhandene Binärdatei anhängen.
<G-vec00407-001-s048><append.anhängen><en> -a Append output to existing binary file.
<G-vec00407-001-s049><append.anhängen><de> 0 bedeutet anhängen, 1 bedeutet nicht anhängen.
<G-vec00407-001-s049><append.anhängen><en> 0 means append; 1 means don't append.
<G-vec00407-001-s051><append.anhängen><de> Wenn Sie eine CSV- oder FLF (fixed length)-Datei in ein Mapforce Datenmapping laden, können Sie Felder anhängen, einfügen und entfernen und vor dem Import der Datei die Namen der Feldüberschriften sowie die Werte bei Bedarf ändern.
<G-vec00407-001-s051><append.anhängen><en> When you load a CSV or fixed length (FLF) flat file into a MapForce data mapping design, you can append, insert, and remove fields as well as change field header names and values as required before importing the file.
<G-vec00407-001-s052><append.anhängen><de> "Wird ein Zertifikat definiert, so können die Schlüsselinformationen des Zertifikats durch Aktivieren des Kontrollkästchens Keyinfo anhängen (am unteren Rend des Dialogfelds ""Signatureinstellungen"") mit der Signatur gespeichert werden; dadurch muss der Benutzer der Authentic-Ansicht kein Zertifikat bei der Überprüfung angeben."
<G-vec00407-001-s052><append.anhängen><en> If a certificate is specified, the certificate's key information can be saved with the signature by checking the Append Keyinfo checkbox (at the bottom of the XML Signature Settings dialog); this obviates the need for the Authentic View user to specify a certificate during verification.
<G-vec00407-001-s053><append.anhängen><de> Nachdem sie durch den Marlboro infiziert Ihren Computer .oops Bedrohung, das Virus beginnt XOR-Verschlüsselungsmodus anhängen, die wichtigen Dateien auf dem infizierten Computer zu machen, nicht mehr geöffnet werden kann,.
<G-vec00407-001-s053><append.anhängen><en> After getting your computer infected by the Marlboro .oops threat, the virus begins to append XOR encryption mode to render the important files on the compromised computer no longer openable.
<G-vec00407-001-s054><append.anhängen><de> Klicken Sie mehrmals auf Feld anhängen, um sieben CSV-Felder zu erstellen.
<G-vec00407-001-s054><append.anhängen><en> Click Append Field several times to create seven CSV fields.
<G-vec00407-001-s055><append.anhängen><de> Cerber 4.1.4 nutzt die MachineGuid Wert des Computers eine neue Erweiterung anhängen, so können Sie eine Datei erwarten namens ‚picture.img’ zu werden ‚picture.img.k8d1‘.
<G-vec00407-001-s055><append.anhängen><en> Cerber 4.1.4 uses the computer’s MachineGuid value to append a new extension, so you may expect a file named ‘picture.img’ to become ‘picture.img.k8d1’.
<G-vec00407-001-s056><append.anhängen><de> Und wenn wir .xml an die URL anhängen, bekommen wir die XML-Antwort.
<G-vec00407-001-s056><append.anhängen><en> And if we append .xml to the URL we'll get the XML response.
<G-vec00407-001-s057><append.anhängen><de> Wenn Sie beispielsweise einen Docker-Container auf dem ersten CPU-Kern sperren möchten, müssen Sie --cpuset-cpus=0 an Ihren Docker-Startbefehl docker run anhängen.
<G-vec00407-001-s057><append.anhängen><en> If you for instance want to lock down a Docker container to the first CPU core, you'd append --cpuset-cpus=0 to your docker run command.
<G-vec00407-001-s058><append.anhängen><de> Wenn Sie den Mauszeiger über einen markierten Bereich halten wird der Schalter Anhängen auch im markierten Bereich des Fensters angezeigt.
<G-vec00407-001-s058><append.anhängen><en> When you hover the mouse cursor over a highlighted area an Append button also display highlighted area of the pane.
<G-vec00407-001-s059><append.anhängen><de> Um einen unvollständigen Namen durch das Anhängen von Suffixen aus einer Liste konfigurierter Suffixe aufzulösen, klicken Sie auf Diese DNS-Suffixe anhängen (in Reihenfolge) und dann auf Hinzufügen, um Suffixe der Liste hinzuzufügen.
<G-vec00407-001-s059><append.anhängen><en> To resolve an unqualified name by appending the suffixes from a list of configured suffixes, click Append these DNS suffixes (in order), and then click Add to add suffixes to the list.
<G-vec00407-001-s060><append.anhängen><de> Die Optionen sind dieselben wie oben beschrieben: ersetzen, anhängen, voranstellen .
<G-vec00407-001-s060><append.anhängen><en> Options are the same as mentioned above: Replace, Append, Prepend .
<G-vec00407-001-s061><append.anhängen><de> Zur einfacheren Auswertung vor Beginn der Leitfähigkeitsmessung mit einem neuen Stoff Messung → Neue Messreihe anhängen auswählen.
<G-vec00407-001-s061><append.anhängen><en> In order to simplify the evaluation, select Measurement → Append new Measurement Series before measuring the conductivity of a new substance.
<G-vec00407-001-s062><append.anhängen><de> Die Aktionen Node(s) einfügen und Node(s) anhängen verfügen über eine Option, um den/die eingefügten/angehängten Node(s) von der ursprünglichen Stelle in den Projektseitenquellen zu entfernen.
<G-vec00407-001-s062><append.anhängen><en> The Insert Node(s) and Append Node(s) actions have an option to remove the inserted/appended node/s from their original locations in a project's page sources.
<G-vec00407-001-s063><append.anhängen><de> Die von den HZI-Forschern entwickelte molekulare Sonde basiert auf einem Siderophor-Konjugat, an welche sie funktionelle Einheiten anhängen können.
<G-vec00407-001-s063><append.anhängen><en> The molecular probe developed by the HZI researchers is based on a siderophore conjugate to which they can append functional units.
<G-vec00407-001-s064><append.anhängen><de> Du mußt A Quickscanner's Paper als Ausgangspunkt benutzen und einen möglist guten Quickscanner anhängen.
<G-vec00407-001-s064><append.anhängen><en> You have to use A Quickscanner's Paper as a starting point and append a good quickscanner.
<G-vec00407-001-s065><append.anhängen><de> "Schieben Sie den Mauszeiger ungefähr in die Nähe des gewünschten Wegpunktes, drücken Sie die rechte Maustaste (beim Mac: Wahltaste und Maustaste) und wählen Sie ""Einfügen"" oder ""Anhängen""."
<G-vec00407-001-s065><append.anhängen><en> "Move the mouse pointer approximately into the vicinity of the way point desired, click the right mouse button (for Mac: option key and the mouse button), and choose ""Insert"" or ""Append""."
<G-vec00407-001-s143><attach.anhängen><de> Text: Das Einsatz > Datei anhängen > Neuestes Objekt ist in Outlook 2016 neu, daher funktioniert diese Methode in früheren Outlook-Versionen nicht.
<G-vec00407-001-s143><attach.anhängen><en> Note: The Insert > Attach File > Recent Item is new in Outlook 2016, therefore this method does not work in earlier Outlook versions.
<G-vec00407-001-s144><attach.anhängen><de> Wallee ermöglicht es Ihnen, Bestell-E-Mails, Rechnungen oder andere Dokumente, die Sie an die Kommunikation mit Ihren Kunden über unseren integrierten Ressourcen-Editor anhängen möchten, vollständig anzupassen.
<G-vec00407-001-s144><attach.anhängen><en> Wallee allows you to fully customize order emails, invoices or any other document that you wish to attach to communications with your customers via our built in resource editor.
<G-vec00407-001-s145><attach.anhängen><de> Der PowerPoint-Export kann jetzt Folien an eine bestehende PPTX-Datei anhängen.
<G-vec00407-001-s145><attach.anhängen><en> The PowerPoint export can now attach slides to an existing PPTX file.
<G-vec00407-001-s146><attach.anhängen><de> "Als externe Dateien können an gleicher Stelle über den Button ""Stattdessen eine Datei als Signatur anhängen"" Text-, HTML - oder Grafikdateien eingebunden werden."
<G-vec00407-001-s146><attach.anhängen><en> "External files, text, HTML or image files can be imported in the same place with the button ""Instead, attach a file as a signature""."
<G-vec00407-001-s147><attach.anhängen><de> - Das Foto, das Sie anhängen müssen neue Pass Größe sein.
<G-vec00407-001-s147><attach.anhängen><en> - The photograph you attach must be recent passport-size.
<G-vec00407-001-s148><attach.anhängen><de> In dem Dokument, das Sie anhängen Sie zählen einige der wichtigsten Änderungen.
<G-vec00407-001-s148><attach.anhängen><en> In the document that you attach you count some of the most significant changes.
<G-vec00407-001-s149><attach.anhängen><de> Sie können dann das neue HTML-Dokument anstelle Ihres Word-Dokumentes anhängen.
<G-vec00407-001-s149><attach.anhängen><en> You can then attach the new HTML document instead of your Word document.
<G-vec00407-001-s150><attach.anhängen><de> 系 xì: (Anhängen) wird nicht alleine verwendet.
<G-vec00407-001-s150><attach.anhängen><en> 系 xì: (attach) is not used alone.
<G-vec00407-001-s151><attach.anhängen><de> Einige Artikel können kombiniert oder benutzt werden anhängen.
<G-vec00407-001-s151><attach.anhängen><en> Some items can be combined or used in attach.
<G-vec00407-001-s152><attach.anhängen><de> Sie können einzigartige Effekte hinzufügen, verschiedene Filter anwenden, Texte auf Bildern platzieren, Sticker anhängen, und noch vieles mehr mit dem Photo Editor Werkzeug des CraterTM Editors.
<G-vec00407-001-s152><attach.anhängen><en> Add unique effects, apply different filters, place text on images, attach stickers, and much more with the Photo Editor tool accessed from the CraterTM Editor.
<G-vec00407-001-s153><attach.anhängen><de> Man kann auch eine vorhandene Datei anhängen, die als Signatur dienen.
<G-vec00407-001-s153><attach.anhängen><en> One can also attach an existing file that will serve as a signature.
<G-vec00407-001-s154><attach.anhängen><de> Anlagen zum Versand [top] Um eine Datei, die auf Ihrem Computer gespeichert ist, zu versenden, klicken Sie auf Anhängen und wählen Sie dann Anhang .Um eine Datei zu senden, die bereits in den Dokumenten abgespeichert ist, klicken Sie auf Anhängen und wählen Sie dann Dokumente .
<G-vec00407-001-s154><attach.anhängen><en> Outgoing attachments [top] To send a file stored on your computer, click on Attach and then select Attachments .To send a file already stored in the Documents, click on Attach and then select Documents .
<G-vec00407-001-s156><attach.anhängen><de> Die Radical Universal Aero-Taschen sind für's Anhängen an den Spannsitz gedacht.
<G-vec00407-001-s156><attach.anhängen><en> And the Radical Universal Aero panniers are made to attach to a mesh seat.
<G-vec00407-001-s157><attach.anhängen><de> Sie können ein Dokument einem Kontakt anhängen (oder mit ihm verlinken).
<G-vec00407-001-s157><attach.anhängen><en> You can attach (or link) a Document to a Contact.
<G-vec00407-001-s158><attach.anhängen><de> Stattdessen kannst du ein vorhandenes Foto, Video oder GIF anhängen, indem du eines aus den Thumbnails neben dem Kamera-Button auswählst oder das Galeriesymbol antippst.
<G-vec00407-001-s158><attach.anhängen><en> Alternatively, you can attach an existing photo, video, or GIF by choosing from the thumbnails alongside the camera button or by tapping the gallery icon .
<G-vec00407-001-s159><attach.anhängen><de> Um unsere Dienste nutzen zu können, müssen Sie nicht einmal Kreditkarten- oder andere Zahlungsinformationen anhängen.
<G-vec00407-001-s159><attach.anhängen><en> To use our services, you don't even need to attach any credit card or other payment information.
<G-vec00407-001-s160><attach.anhängen><de> Aktivieren Sie Kopie des gesendeten Faxes anhängen, wenn Sie mit der Empfangsbestätigung eine Kopie der gesendeten Faxnachricht empfangen möchten.
<G-vec00407-001-s160><attach.anhängen><en> Select Attach a copy of the sent fax if you want to receive copies of the faxes that you send with the receipts.
<G-vec00407-001-s161><attach.anhängen><de> Hotmail wollte uns nicht Bilder an unsere Mail anhängen lassen und erst nach etlichen Einwahlversuchen konnten die letzten Tagebucheintragungen auf den Weg nach Bremen zu Dirk Borchers, unserem Webmaster und Dominique, unserer fleißigen Übersetzerin, gesendet werden.
<G-vec00407-001-s161><attach.anhängen><en> Hotmail doesn't want us to attach our pictures to the mails we are going to send and it takes dozens of connection- attempts before we can get our latest diary-update on the way to Dirk Borchers, our webmaster in Bremen.
<G-vec00407-001-s066><append.anhängen><de> Klicken Sie (in der Symbolleiste des Fensters) auf das Anhängen oder Einfügen -Symbol, um eine Zeile zur Liste hinzuzufügen.
<G-vec00407-001-s066><append.anhängen><en> Click the Append or Insert icons (located in the pane's toolbar) to add a line to the list.
<G-vec00407-001-s067><append.anhängen><de> Wenn Sie die Anhängen Wenn Sie diese Option wählen, wird das zuletzt ausgewählte Element an das Ende des Zellenwerts angehängt.
<G-vec00407-001-s067><append.anhängen><en> If you choose the Append option, the item you have selected lately will be added to the end of the cell value;
<G-vec00407-001-s068><append.anhängen><de> Klicken Sie auf eine der Schaltflächen AND anhängen oder OR anhängen .
<G-vec00407-001-s068><append.anhängen><en> Click the Append AND or Append OR button.
<G-vec00407-001-s069><append.anhängen><de> Zusätzlich dazu können Sie (durch Rechtsklick in eine Zeile und Anhängen oder Einfügen eines Day -Elements) in der Tabelle unterhalb des Diagramms neue Kursdaten für die beiden Unternehmen eingeben.
<G-vec00407-001-s069><append.anhängen><en> Furthermore, the table below the chart allows new trading data to be entered for the two companies (right-click in a row and append or insert a Day element).
<G-vec00407-001-s072><append.anhängen><de> Bei Komponentenlisten besteht neben dem vollständigen Ersetzen der enthaltenen Komponenten auch die Möglichkeit, die Komponenten des Quelldokuments an die Komponentenliste des Zieldokuments voranzustellen oder anzuhängen.
<G-vec00407-001-s072><append.anhängen><en> For component lists, the dialog additionally delivers the possibility to prepend or append the components of the source document.
<G-vec00407-001-s073><append.anhängen><de> Die Möglichkeit, WSDL-Elemente, die in der grafischen Ansicht zu sehen sind, hinzuzufügen, anzuhängen und zu löschen (kontextsensitives Menü).
<G-vec00407-001-s073><append.anhängen><en> Ability to add, append, and delete any WSDL element visible in the graphical view (context sensitive menu).
<G-vec00407-001-s074><append.anhängen><de> Sie können Formeln verwenden, um Text von einer Zelle an eine andere wie folgt anzuhängen.
<G-vec00407-001-s074><append.anhängen><en> You can use formula to append text from one cell to another as follows.
<G-vec00407-001-s200><attach.anhängen><de> Tags: Die neue Konfigurations-Objektklasse „Tag“ erlaubt es, kurze Texte an fast alle anderen Objekte anzuhängen.
<G-vec00407-001-s200><attach.anhängen><en> Tags: The new configuration object class “Tag” allows to attach short texts to almost any other object.
<G-vec00407-001-s201><attach.anhängen><de> Um einen Datenpunkt an den Trendlog anzuhängen, drücken Sie auf die Schaltfläche Add... und wählen das vorher erzeugte Register reg_1_Read aus.
<G-vec00407-001-s201><attach.anhängen><en> To attach a data point to the trend log, press the Add... button and select the reg_1_Read register which was created previously.
<G-vec00407-001-s202><attach.anhängen><de> Wenn Sie möchten, fügen Sie Bilder hinzu, die Sie auf dem Web gefunden werden, müssen Sie entweder herunterladen oder befestigen Sie Ihren link stattdessen kann einige Zeit dauern, wie Sie benötigen, öffnen Sie einen Webbrowser, öffnen Sie eine Bild-such-Website oder einer Website, die Bilder gehostet werden, laden Sie das Bild oder den link kopieren und es an die Nachricht anzuhängen.
<G-vec00407-001-s202><attach.anhängen><en> If you want to add images that you found on the Web, you either have to download them or attach their link instead which may take quite some time as you need to open a web browser, open an image search site or a site images are hosted on, download the image or copy the link, and attach it to the message.
<G-vec00407-001-s203><attach.anhängen><de> • Gehen Sie zu dem Ordner, in dem das PatXML- Dokument gespeichert ist, und klicken Sie auf Öffnen, um das Dokument anzuhängen.
<G-vec00407-001-s203><attach.anhängen><en> • Navigate to the folder where the PatXML document is saved and click Open to attach the document.
<G-vec00407-001-s204><attach.anhängen><de> Kopiere alle geöffneten Dateien: Kopiert alle geöffneten Word-Dokumente und ermöglicht es Ihnen, sie an einem beliebigen Speicherort einzufügen oder in E-Mails anzuhängen.
<G-vec00407-001-s204><attach.anhängen><en> Copy All Open Files: Copies all open Word documents and allows you paste them to any file location or to attach in emails.
<G-vec00407-001-s205><attach.anhängen><de> Bei Verwendung von MindView Mac als Ihre Mind Mapping-Software profitieren Sie von 6 frei wählbaren Ansichten, der Möglichkeit, Notizen zu machen, Dateien anzuhängen und den Zweigen Grafiken hinzuzufügen.
<G-vec00407-001-s205><attach.anhängen><en> When it comes to Mac mind mapping software, you get what you pay for. Using MindView Mac as your mind mapping software brings you the power of 6 interchangeable views, the ability to take notes, attach files and add visuals to the branches.
<G-vec00407-001-s206><attach.anhängen><de> Von nun an müssen Sie Dateien nicht mehr zwischen Ihrem PC und externen Geräten kopieren oder sich um die Größe von Dateien sorgen, wenn Sie versuchen, diese an eine eMail anzuhängen.
<G-vec00407-001-s206><attach.anhängen><en> From now on, there is no need to copy files back and forth between your PC and external devices or worry about the size of the files as you try to attach them to an email.
<G-vec00407-001-s207><attach.anhängen><de> Sie haben die Möglichkeit Anschreiben, Lebensläufe, Zeugnisse und andere Anlagen anzuhängen.
<G-vec00407-001-s207><attach.anhängen><en> You can attach cover letters, CVs, certificates and other attachments.
<G-vec00407-001-s208><attach.anhängen><de> Es ist jetzt auch möglich, externe Dateien an ein Verzeichnis anzuhängen.
<G-vec00407-001-s208><attach.anhängen><en> It is now also possible to attach external files to a directory.
<G-vec00407-001-s209><attach.anhängen><de> Bei geräten autocostruite die teilnehmer müssen anzuhängen, den schaltplan des gerätes verwendet .
<G-vec00407-001-s209><attach.anhängen><en> In the case of equipment self-made, the participants must attach the wiring diagram of the apparatus used .
<G-vec00407-001-s210><attach.anhängen><de> Die MAPI-Standardschnittstelle ermöglicht WinZip und anderen Anwendungen (einschließlich Windows selbst), Ihr E-Mail-Programm zu steuern und beispielsweise anzuweisen, eine neue Nachricht zu erstellen oder eine Datei anzuhängen.
<G-vec00407-001-s210><attach.anhängen><en> MAPI is a standard interface that allows WinZip and other programs (including Windows itself) to instruct your email program to create a new message, attach a file to it, etc.
<G-vec00407-001-s211><attach.anhängen><de> Nachdem Sie den Trailer erfolgreich anzuhängen, von da an um einen Anhänger LKW fahren zu bekommen.
<G-vec00407-001-s211><attach.anhängen><en> After you successfully attach the trailer, from that point on you get to drive a trailer truck.
<G-vec00407-001-s102><append.anhängen><de> Ihre Autoresponder-Software muss dazu den GET-Parameter an die Danke-Seite-Url anhängen.
<G-vec00407-001-s102><append.anhängen><en> Your autoresponder software must append the GET parameter to the thank you page URL.
<G-vec00407-001-s125><append.anhängen><de> Eine Art, dies zu tun, ist das File für die Eingabe zu öffnen, Lesen der Daten in eine Liste hinein, die Daten an die Liste anhängen und dann die ganze Liste rausschreiben auf eine neue Version der alten Datei.
<G-vec00407-001-s125><append.anhängen><en> One way to do that would be to open the file for input, read the data into a list, append the data to the list and then write the whole list out to a new version of the old file.
<G-vec00407-001-s154><append.anhängen><de> Um diese zusätzlichen Parameter in der Pfadangabe erscheinen zu lassen, kann man /* an eine Regel anhängen.
<G-vec00407-001-s154><append.anhängen><en> In order to make these additional parameters appear in the path info part, we should append /* to the rule.
<G-vec00407-001-s156><append.anhängen><de> Die Folge ist, dass das Oracle Listener Programm auch so konfiguriert werden kann, Loginformationen an eine Datei anzuhängen.
<G-vec00407-001-s156><append.anhängen><en> If a password has not been set, the Oracle listener program can be configured to append log information to a file.
<G-vec00407-001-s157><append.anhängen><de> "- Inhalte in Multizeilen einer Textspalte mit "" Änderungen an vorhandenen Text anhängen"" aktiviert, kann in bestimmten Situationen nicht gespeichert werden."
<G-vec00407-001-s157><append.anhängen><en> "- Contents in Multiple line of text column with ""Append Changes to Existing Text"" enabled cannot be saved in some situations."
<G-vec00407-001-s173><append.anhängen><de> Fähigkeit, umzuziehen, um anzuhängen und Aufzeichnungen zur verbotenen Liste hinzuzufügen.
<G-vec00407-001-s173><append.anhängen><en> Ability to remove, append and add records to banned list.
<G-vec00407-001-s180><append.anhängen><de> Falls Ja, werden die ausgewählten Regionen an die vorher bearbeiteten Regionen angehängt.
<G-vec00407-001-s180><append.anhängen><en> If Yes, the selected regions append to the previously edited regions.
<G-vec00407-001-s181><append.anhängen><de> Der Client akzeptiert Cookies: Es werden keine Informationen angehängt.
<G-vec00407-001-s181><append.anhängen><en> If the client accepts cookies: does not append information
<G-vec00407-001-s182><append.anhängen><de> Schalte automatische Protokollierung ein, d.h. Protokolle aller Spiele werden an die Datei (- bedeutet Standard-Ausgabe) angehängt.
<G-vec00407-001-s182><append.anhängen><en> Turn on automatic logging, i.e. append logs of all games to filename (- means stdout).
<G-vec00407-002-s086><append.anhängen><de> Somit sprechen wir eine bestimmte Partition an indem wir den Laufwerksnamen nehmen und daran ein 's' gefolgt von der Partitionsnummer anhängen.
<G-vec00407-002-s086><append.anhängen><en> Thus, to name a particular partition, we take the disk name, append a `s' and the partition number.
<G-vec00486-002-s034><suspend.anhängen><de> Und dass die US-Geheimdienste und das „Verteidigungsbündnis“ NATO es mit der Wahrheit beim Kampf für unsere Werte und Freiheit nicht sonderlich genau nehmen, weiß man ja nicht erst seit den, bis heute „spurlos verschwundenen“ Massenvernichtungswaffen im Irak-Krieg 2003… doch auch beim Giftgasangriff von Ghouta (Damaskus) 2013, den man damals ebenfalls sofort Assad anhängen wollte, wurden wir belogen.
<G-vec00486-002-s034><suspend.anhängen><en> And the fact that the US Secret Services and the „DEFENSIVE ALLIANCE“ NATO particularly exactly do not take it with the truth in the fight for our values and freedom, one does not know only since him, till this day „without a trace to disappeared“ weapons of mass destruction during the Iraq war 2003…, nevertheless, also in the poison gas attack about Ghouta (Damascus) 2013 which one wanted to suspend at that time also immediately Assad, we were lied.
<G-vec00486-002-s035><suspend.anhängen><de> Angelschnur an den Halter für Steckelemente binden und einmal um das Rad des Wegaufnehmers wickeln und ein Massestück anhängen.
<G-vec00486-002-s035><suspend.anhängen><en> Tie a piece of fishing line to the holder for plug-in elements, wind it once around the wheel of the displacement sensor, and suspend a weight from it.
<G-vec00519-002-s550><attach.anhängen><de> Einmal pro Spielzug: Du kannst 1 als Spezialbeschwörung beschworenes Monster wählen, das dein Gegner kontrolliert; hänge es als offenes Xyz-Material an diese Karte an.
<G-vec00519-002-s550><attach.anhängen><en> Once per turn: You can target 1 Special Summoned monster your opponent controls; attach it to this card as a face-up Xyz Material.
<G-vec00519-002-s551><attach.anhängen><de> Umsetzung: Addiere zur Einerziffer 25 und hänge das Quadrat der Einerziffer an.
<G-vec00519-002-s551><attach.anhängen><en> In words: Add 25 to the ones digit and attach the square of the ones digit.
<G-vec00519-002-s552><attach.anhängen><de> Wenn du Interesse daran hast mit uns zusammenzuarbeiten, fülle einfach die nachfolgenden Informationen aus und hänge deinen Lebenslauf an.
<G-vec00519-002-s552><attach.anhängen><en> If you are interested in working with us, fill out the following information and attach your curriculum.
<G-vec00519-002-s553><attach.anhängen><de> Hänge auch 2 bis 3 Fotos deines Accessoires an, in möglichst hoher Qualität und Auflösung.
<G-vec00519-002-s553><attach.anhängen><en> Attach 2 or 3 photos, with the best quality possible, of your accessory entry.
<G-vec00519-002-s554><attach.anhängen><de> Hänge keine Graphiken oder Photos an oder lange Dissertationen oder deine Lebensgeschichte.
<G-vec00519-002-s554><attach.anhängen><en> Don't attach Graphics or Photos or long dissertations or your life history.
<G-vec00519-002-s555><attach.anhängen><de> Hänge dieses Bild an das Ticket an.
<G-vec00519-002-s555><attach.anhängen><en> Attach that image to the ticket.
<G-vec00519-002-s556><attach.anhängen><de> Lege Gollum und Bilbo Beutlin in die Rätselzone und hänge Bilbos magischer Ring an Bilbo Beutlin an.
<G-vec00519-002-s556><attach.anhängen><en> Place Gollum and Bilbo Baggins in the riddle area and attach Bilbo's Magic Ring to Bilbo Baggins.
<G-vec00519-002-s557><attach.anhängen><de> Hänge die Datei an eine neue E-Mail an und sende sie an deine eigene E-Mail-Adresse.
<G-vec00519-002-s557><attach.anhängen><en> Attach the file to a new e-mail and send it to your own e-mail address.
<G-vec00519-002-s558><attach.anhängen><de> Hänge zusätzliche Dokumente an und verbinde sie mit den Notizbuchseiten.
<G-vec00519-002-s558><attach.anhängen><en> Attach additional documents and associate them with notebook pages.
<G-vec00519-002-s559><attach.anhängen><de> Es gibt viele Hänge an denen sich Ungeübte probieren können.
<G-vec00519-002-s559><attach.anhängen><en> There are many attach for those untrained who can try.
