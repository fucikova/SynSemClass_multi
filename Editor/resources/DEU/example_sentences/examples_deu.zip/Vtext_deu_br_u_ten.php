<G-vec00468-001-s073><breed.brüten><de> Die Feldlerchen die in Estland brüten kommen noch gut zurecht, es gibt mehr als eine halbe Millionen Paare.
<G-vec00468-001-s073><breed.brüten><en> The skylarks that breed in Estonia still manage quite well, they are more than half a million pairs.
<G-vec00468-001-s074><breed.brüten><de> Papageientaucher kommen nur zum Brüten an Land, während der übrigen Zeit sind sie ausschließlich auf dem Meer.
<G-vec00468-001-s074><breed.brüten><en> Puffins come ashore only to breed, while other times they are exclusively on the sea.
<G-vec00468-001-s075><breed.brüten><de> Hunderttausende Seevögel brüten auf den Inseln und auch bei Hiddensee.
<G-vec00468-001-s075><breed.brüten><en> Hundreds of thousands of sea birds breed and nest on the island and also near Hiddensee.
<G-vec00468-001-s076><breed.brüten><de> Wenn sich Insekten in den Nestern von Vögeln und Tieren in gemäßigten und nördlichen Breiten brüten, werden die Puppen, die sich nach dem Verlassen der Besitzer im Nest befanden, bis zum nächsten Jahr, in dem die Bewohner im Tierheim wieder auftauchen, in dieser Art geschlängert.
<G-vec00468-001-s076><breed.brüten><en> When insects breed in the nests of birds and animals in temperate and northern latitudes, the pupae that were in the nest after the owners left it will languish in this species until the next year, when the inhabitants reappear in the shelter.
<G-vec00468-001-s077><breed.brüten><de> Viele seiner 250 endemischen Buntbarscharten sind Maulbrüter: Zum Schutz ihrer Nachkommen nehmen sie ihre Eier ins Maul, damit sie nicht von anderen Fischen gefressen werden, und brüten ihre Larven im Maul aus.
<G-vec00468-001-s077><breed.brüten><en> Many of its 250 endemic species of cichlids are mouthbreeders: To protect their offspring and prevent other fish from devouring it, cichlids carry and breed their eggs in their mouths.
<G-vec00468-001-s078><breed.brüten><de> Von den Sturmmöwen, die auf der Insel Matsalu brüten, fliegen die Altvögel sofort nach der Brutzeit weg und direkt in die Richtung ihres Überwinterungsgebietes.
<G-vec00468-001-s078><breed.brüten><en> Of the common gulls that breed on the Matsalu islets, the adult birds leave immediately after the nesting period and head straight for their wintering areas.
<G-vec00468-001-s079><breed.brüten><de> Auf der Kap-Halbinsel im Stadtgebiet von Kapstadt sind sie Kulturfolger, die sogar in Hausgärten von Villen brüten.
<G-vec00468-001-s079><breed.brüten><en> Keeping close to civilisation on Cape Peninsula they even breed in the gardens of villas located in the suburbs of Cape Town.
<G-vec00468-001-s080><breed.brüten><de> Aufgrund des großen Platzangebot im Herp Nursery II ist das ein Riesenvorteil, so kann man in dem Gerät auch problemlos Arten mit unterschiedlichen Temperaturbedürfnissen bebrüten oder auf besondere Geschlechter brüten.
<G-vec00468-001-s080><breed.brüten><en> Thanks to the plenty of space the Herp Nursery offer, this is a big advantage as you can incubate different species with different temperature requirements or breed for specific sexes and all in one device!
<G-vec00468-001-s081><breed.brüten><de> Hier gibt es nur Personen, die versehentlich vom Körper oder Kopf gefallen sind, und es gibt keine dauerhaften Populationen, die im Bett brüten.
<G-vec00468-001-s081><breed.brüten><en> Here there are only individuals that accidentally fell from the body or head, and there are no permanent populations that breed in bed.
<G-vec00468-001-s082><breed.brüten><de> Auch einige Paare der Gryllteiste (Cepphus grylle) brüten auf Bonden.
<G-vec00468-001-s082><breed.brüten><en> A few hundred pairs of black guillemot (Cepphus grylle) also breed here.
<G-vec00468-001-s083><breed.brüten><de> Die Sibirien Katze brüten ist ein erklecklich Katze, wiegend bis zu zwanzig Pfunde, mit ein isolierend beschlagen über etwas kleiner ölig Haar.
<G-vec00468-001-s083><breed.brüten><en> The Siberian cat breed is a large cat, weighing up to twenty pounds, with an insulating coat of slightly oily hair.
<G-vec00468-001-s084><breed.brüten><de> So brüten verschiedene Singvögel ebenso wie Falken auf hohen Bäumen oder in Felsnischen.
<G-vec00468-001-s084><breed.brüten><en> Various songbirds and falcons breed on the high trees or in coves.
<G-vec00468-001-s085><breed.brüten><de> Jährlich kommen hunderte Vögel hierher, um zu brüten.
<G-vec00468-001-s085><breed.brüten><en> Hundreds of bird species come here every year to breed.
<G-vec00468-001-s086><breed.brüten><de> Seeschwalben brüten in Kolonien und tauchen nach kleinen Fischen in den Küstengewässern.
<G-vec00468-001-s086><breed.brüten><en> Terns breed in colonies and dive for small fish in coastal waters.
<G-vec00468-001-s087><breed.brüten><de> Diese Vögel werden in diesem Jahr noch nicht brüten.
<G-vec00468-001-s087><breed.brüten><en> These birds will not breed yet this year.
<G-vec00468-001-s088><breed.brüten><de> Jetzt sind die Blauracken, Bienenfresser, Würger, Warbler und einige Schnäpper gekommen, viele von Ihnen werden hier brüten und neue Populationen schaffen.
<G-vec00468-001-s088><breed.brüten><en> The European Rollers, Redd-footed and Lesser Kestrels, Bee-eater, Shrikes, Warbler and some flycatchers are now here, many of them are here to breed and create new populations.
<G-vec00468-001-s089><breed.brüten><de> Momentan brüten rund 15.000 Paare in den Niederlanden, davon etwa 7000 im niederländischen Wattenmeer.
<G-vec00468-001-s089><breed.brüten><en> As of 2010, around 15,000 pairs breed in the Netherlands, of which around 7000 in the Dutch wadden region.
<G-vec00468-001-s090><breed.brüten><de> Auf Ameland brüten über fünfzig Vogelarten, von der Silbermöwe zur Hohltaube und von Rohrweihe zur Pieper.
<G-vec00468-001-s090><breed.brüten><en> About fifty bird species breed on Ameland, from the herring gull to the pigeon hole and from the harrier to the meadow pipit.
<G-vec00468-001-s091><breed.brüten><de> Die einzigen Bewohner auf diesen Inseln sind Vögel, die dort auf ihren Vogelwanderungen Station machen oder brüten.
<G-vec00468-001-s091><breed.brüten><en> The only inhabitants on these islands are birds who stopped by on their way to the north or breed there in the nature sanctuary.
<G-vec00197-001-s028><hatch.brüten><de> Die Weibchen brüten die beiden bräunlich gefleckten Eier allein aus.
<G-vec00197-001-s028><hatch.brüten><en> The females hatch the two, brownish spotted eggs alone.
<G-vec00197-001-s029><hatch.brüten><de> 15 Der Igel wird auch daselbst nisten und legen, brüten und aushecken unter ihrem Schatten; auch werden die Weihen daselbst zusammenkommen.
<G-vec00197-001-s029><hatch.brüten><en> 15 There shall the arrow-snake make her nest, and lay, and hatch, and gather under her shadow; there also shall the vultures be gathered one with another.
<G-vec00197-001-s030><hatch.brüten><de> Die Eier brüten in vier oder fünf Tagen, was bis zu 3,000 braten pro Nest.
<G-vec00197-001-s030><hatch.brüten><en> The eggs hatch in four or five days, yielding up to 3,000 fry per nest.
<G-vec00197-001-s031><hatch.brüten><de> Ein oder zwei Wochen brüten neue Larven aus, die eine neue Population zum Leben erwecken können.
<G-vec00197-001-s031><hatch.brüten><en> A week or two of them hatch new larvae that can give life to a new population.
<G-vec00197-001-s032><hatch.brüten><de> Die Eier brüten in Blattform schwimmenden leptocephalus Larven, die Drift mit den Strömen.
<G-vec00197-001-s032><hatch.brüten><en> The eggs hatch into leaf-shaped floating leptocephalus larvae that drift with the currents.
<G-vec00197-001-s033><hatch.brüten><de> Obwohl die Wirte das fremde Ei leicht erkennen können, brüten sie es häufig aus.
<G-vec00197-001-s033><hatch.brüten><en> Although the hosts can easily recognize the foreign egg, they frequently hatch it.
<G-vec00197-001-s034><hatch.brüten><de> Jedes so häufig brütest du ein chao, das stumpf ist und nichts tut, aber Schlaf aus.
<G-vec00197-001-s034><hatch.brüten><en> Every so often you will hatch a chao that is dull and does nothing but sleep.
<G-vec00197-001-s035><hatch.brüten><de> Naja, außer du brütest vorher so ein Dutzend andere aus, denke ich mal...
<G-vec00197-001-s035><hatch.brüten><en> Well, unless you hatch a dozen others before, I guess...
