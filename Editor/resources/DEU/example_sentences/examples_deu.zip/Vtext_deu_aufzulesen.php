<G-vec00169-001-s018><glean.aufzulesen><de> 15 Als sie nun aufstand, um aufzulesen, befahl Boas seinen Knechten: Auch zwischen den Garben darf sie auflesen, und ihr sollt ihr nichts zuleide tun.
<G-vec00169-001-s018><glean.aufzulesen><en> "15 When she rose to glean, Boaz commanded his servants, saying, ""Let her glean even among the sheaves, and do not insult her."
<G-vec00169-001-s019><glean.aufzulesen><de> 2:23 Und so hielt sie sich zu den Mägden des Boas, um aufzulesen, bis die Gerstenernte und die Weizenernte beendigt waren.
<G-vec00169-001-s019><glean.aufzulesen><en> 2:23 So she kept with the maidens of Boaz to glean, until the end of the barley-harvest and of the wheat-harvest.
