<G-vec00222-002-s038><play.abspielen><de> Wenn Sie derzeit einen DVD-Codec verwenden, um DVD-Filme abzuspielen, wie den Encoder, der mit Windows 7 Professional geliefert wird, ist dieser Encoder nach dem Durchführen des Upgrades auf Windows 8 möglicherweise nicht verfügbar.
<G-vec00222-002-s038><play.abspielen><en> If you currently use a DVD codec to play DVD movies, such as the encoder that comes with Windows 7 Professional, this encoder might not be available in Windows 10.
<G-vec00222-002-s039><play.abspielen><de> Dank dieser Anwendung ist es auch möglich, Bilder oder Videos auf dem Tablet anzuzeigen, Sounds auf dem Roboter abzuspielen oder eine Vorschau dessen zu sehen, was der Roboter durch seine Kamera sieht.
<G-vec00222-002-s039><play.abspielen><en> It is also possible, thanks to this application, to show images or videos on the tablet, to play sounds on the robot, or to have a glimpse of what the robot perceives through its camera.
<G-vec00222-002-s040><play.abspielen><de> 1 Kommentar Wenn Sie Musik genauso gerne hören möchten wie ich, sollten Sie sicherstellen, dass Sie über ein tolles Audio-Setup (Lautsprecher oder Kopfhörer) und einen Musik-Player (App) verfügen, um Ihre Lieblingsmusik von Ihrem Computer abzuspielen.
<G-vec00222-002-s040><play.abspielen><en> 1 Comment If you like listening to music as much as I do, you want to make sure you have a great audio setup (speakers or headphones) and a music player (app) to play your favorite tunes off your computer.
<G-vec00222-002-s041><play.abspielen><de> Du brauchst nichts weiter als deine Stimme, um Google Assistant aufzufordern, zum Beispiel deinen Lieblingsfilm abzuspielen oder die Lautstärke zu erhöhen.
<G-vec00222-002-s041><play.abspielen><en> You can ask Google Assistant to play your favourite movie, turn up the volume, and more, using just your voice!
<G-vec00222-002-s042><play.abspielen><de> c. Wenn der Standby-Modus einen geringen Stromverbrauch aufweist, dauert es 3 Sekunden vom Druckknopf, um die Datei abzuspielen.
<G-vec00222-002-s042><play.abspielen><en> c. When the standby mode is low power consumption, it will take 3 sec from push button to play file.
<G-vec00222-002-s043><play.abspielen><de> Musikvideo: Adobe Flash Player (Version 9 oder höher) wird benötigt um dieses Musikvideo abzuspielen.
<G-vec00222-002-s043><play.abspielen><en> — Audio clip: Adobe Flash Player (version 9 or above) is required to play this audio clip.
<G-vec00222-002-s044><play.abspielen><de> Oder Sie können die Taste „Open File“ drücken und Blu-ray ISO Dateien wählen, um abzuspielen.
<G-vec00222-002-s044><play.abspielen><en> Or you can press the “Open File” button and select Blu-ray ISO files to play.
<G-vec00222-002-s045><play.abspielen><de> Dltere Audio-CD-Player sind oft nicht in der Lage, die Datendatei als solche zu erkennen und versuchen sie abzuspielen.
<G-vec00222-002-s045><play.abspielen><en> Older Audio CD players are often not capable of recognizing the data file and attempt to play it.
<G-vec00222-002-s046><play.abspielen><de> Außerdem hast du noch diese anderen Möglichkeiten, um mit Spotify Inhalte in deinem Auto abzuspielen.
<G-vec00222-002-s046><play.abspielen><en> You can also try these alternative ways to play Spotify in your car.
<G-vec00222-002-s047><play.abspielen><de> Tippen Sie auf die eingebettete Mediendatei, um sie in Mein Flow abzuspielen.
<G-vec00222-002-s047><play.abspielen><en> Tap the embedded media file to play it in My Flow.
<G-vec00222-002-s048><play.abspielen><de> Selbst wenn Sie kein Geld haben, um Apple TV zu benutzen, können Sie Chromecast verwenden, um Videos vom Telefon zum Fernseher abzuspielen.
<G-vec00222-002-s048><play.abspielen><en> Even if you don't have the cash to use Apple TV you can still use Chromecast to play video from phone to TV.
<G-vec00222-002-s049><play.abspielen><de> Klicken Sie einfach auf das folgende Bild, um das Video abzuspielen.
<G-vec00222-002-s049><play.abspielen><en> Please click on the picture to play the video.
<G-vec00222-002-s050><play.abspielen><de> Es hat viel zu bieten, aber es gibt ein Problem, dass es nur für uns gibt, Spotify-Musik auf einem Gerät gleichzeitig abzuspielen.
<G-vec00222-002-s050><play.abspielen><en> It has a lot to offer, but there is one upsetting issue that it's only available for us to play Spotify music on one device at a time.
<G-vec00222-002-s051><play.abspielen><de> Optionen im Wiedergabemenü hinzugefügt, um die derzeit abgespielte Datei zu wiederholen oder die Soundliste von vorne abzuspielen, sobald das Ende der Liste erreicht ist.
<G-vec00222-002-s051><play.abspielen><en> Added options to the Play menu to repeat the currently played sound or to repeat the sound list, when the end of the list is reached.
<G-vec00222-002-s052><play.abspielen><de> Sie können einige gute Drittanbieteranwendungen ausprobieren, um Ihre Datei abzuspielen.
<G-vec00222-002-s052><play.abspielen><en> You can try some good third party applications to play your file.
<G-vec00222-002-s053><play.abspielen><de> Um die Aktion langsamer abzuspielen oder die Aktion nach jedem Schritt anzuhalten, benutzen Sie den Menüpunkt "Ausführen-Optionen" im Bedienfeldmenü.
<G-vec00222-002-s053><play.abspielen><en> To play the actions more slowly or to make the actions stop after each step try the "Playback Options" panel menu item. 9.
<G-vec00222-002-s054><play.abspielen><de> Octagon SF8008 4K bietet mit einem USB 3.0-, USB 2.0- sowie einem MicroSD-Slot und einem Kartenleser genügend Möglichkeiten, um Inhalte von externen Speichermedien abzuspielen und so das Entertainment-Erlebnis nochmals zu erhöhen.
<G-vec00222-002-s054><play.abspielen><en> Octagon SF8008 4K offers enough possibilities with a USB 3.0, USB 2.0 and a MicroSD slot and a card reader to play content from external storage media and thus increase the entertainment experience again.
<G-vec00222-002-s056><play.abspielen><de> Der integrierte ARM-Prozessor in Hyperion Fury treibt die Fusion Engine für unglaubliche Zielverfolgungsgeschwindigkeiten und ermöglicht es Dir gleichzeitig, Deine bevorzugten Makros zu speichern und abzuspielen.
<G-vec00222-002-s056><play.abspielen><en> Hyperion Fury on-board ARM processor powers the Fusion Engine for incredible tracking speeds while allowing you to save and play back your favorite macros.
<G-vec00382-003-s038><play_up.abspielen><de> Wenn Sie derzeit einen DVD-Codec verwenden, um DVD-Filme abzuspielen, wie den Encoder, der mit Windows 7 Professional geliefert wird, ist dieser Encoder nach dem Durchführen des Upgrades auf Windows 8 möglicherweise nicht verfügbar.
<G-vec00382-003-s038><play_up.abspielen><en> If you currently use a DVD codec to play DVD movies, such as the encoder that comes with Windows 7 Professional, this encoder might not be available in Windows 10.
<G-vec00382-003-s039><play_up.abspielen><de> Dank dieser Anwendung ist es auch möglich, Bilder oder Videos auf dem Tablet anzuzeigen, Sounds auf dem Roboter abzuspielen oder eine Vorschau dessen zu sehen, was der Roboter durch seine Kamera sieht.
<G-vec00382-003-s039><play_up.abspielen><en> It is also possible, thanks to this application, to show images or videos on the tablet, to play sounds on the robot, or to have a glimpse of what the robot perceives through its camera.
<G-vec00382-003-s040><play_up.abspielen><de> 1 Kommentar Wenn Sie Musik genauso gerne hören möchten wie ich, sollten Sie sicherstellen, dass Sie über ein tolles Audio-Setup (Lautsprecher oder Kopfhörer) und einen Musik-Player (App) verfügen, um Ihre Lieblingsmusik von Ihrem Computer abzuspielen.
<G-vec00382-003-s040><play_up.abspielen><en> 1 Comment If you like listening to music as much as I do, you want to make sure you have a great audio setup (speakers or headphones) and a music player (app) to play your favorite tunes off your computer.
<G-vec00382-003-s041><play_up.abspielen><de> Du brauchst nichts weiter als deine Stimme, um Google Assistant aufzufordern, zum Beispiel deinen Lieblingsfilm abzuspielen oder die Lautstärke zu erhöhen.
<G-vec00382-003-s041><play_up.abspielen><en> You can ask Google Assistant to play your favourite movie, turn up the volume, and more, using just your voice!
<G-vec00382-003-s042><play_up.abspielen><de> c. Wenn der Standby-Modus einen geringen Stromverbrauch aufweist, dauert es 3 Sekunden vom Druckknopf, um die Datei abzuspielen.
<G-vec00382-003-s042><play_up.abspielen><en> c. When the standby mode is low power consumption, it will take 3 sec from push button to play file.
<G-vec00382-003-s043><play_up.abspielen><de> Musikvideo: Adobe Flash Player (Version 9 oder höher) wird benötigt um dieses Musikvideo abzuspielen.
<G-vec00382-003-s043><play_up.abspielen><en> — Audio clip: Adobe Flash Player (version 9 or above) is required to play this audio clip.
<G-vec00382-003-s044><play_up.abspielen><de> Oder Sie können die Taste „Open File“ drücken und Blu-ray ISO Dateien wählen, um abzuspielen.
<G-vec00382-003-s044><play_up.abspielen><en> Or you can press the “Open File” button and select Blu-ray ISO files to play.
<G-vec00382-003-s045><play_up.abspielen><de> Dltere Audio-CD-Player sind oft nicht in der Lage, die Datendatei als solche zu erkennen und versuchen sie abzuspielen.
<G-vec00382-003-s045><play_up.abspielen><en> Older Audio CD players are often not capable of recognizing the data file and attempt to play it.
<G-vec00382-003-s046><play_up.abspielen><de> Außerdem hast du noch diese anderen Möglichkeiten, um mit Spotify Inhalte in deinem Auto abzuspielen.
<G-vec00382-003-s046><play_up.abspielen><en> You can also try these alternative ways to play Spotify in your car.
<G-vec00382-003-s047><play_up.abspielen><de> Tippen Sie auf die eingebettete Mediendatei, um sie in Mein Flow abzuspielen.
<G-vec00382-003-s047><play_up.abspielen><en> Tap the embedded media file to play it in My Flow.
<G-vec00382-003-s048><play_up.abspielen><de> Selbst wenn Sie kein Geld haben, um Apple TV zu benutzen, können Sie Chromecast verwenden, um Videos vom Telefon zum Fernseher abzuspielen.
<G-vec00382-003-s048><play_up.abspielen><en> Even if you don't have the cash to use Apple TV you can still use Chromecast to play video from phone to TV.
<G-vec00382-003-s049><play_up.abspielen><de> Klicken Sie einfach auf das folgende Bild, um das Video abzuspielen.
<G-vec00382-003-s049><play_up.abspielen><en> Please click on the picture to play the video.
<G-vec00382-003-s050><play_up.abspielen><de> Es hat viel zu bieten, aber es gibt ein Problem, dass es nur für uns gibt, Spotify-Musik auf einem Gerät gleichzeitig abzuspielen.
<G-vec00382-003-s050><play_up.abspielen><en> It has a lot to offer, but there is one upsetting issue that it's only available for us to play Spotify music on one device at a time.
<G-vec00382-003-s051><play_up.abspielen><de> Optionen im Wiedergabemenü hinzugefügt, um die derzeit abgespielte Datei zu wiederholen oder die Soundliste von vorne abzuspielen, sobald das Ende der Liste erreicht ist.
<G-vec00382-003-s051><play_up.abspielen><en> Added options to the Play menu to repeat the currently played sound or to repeat the sound list, when the end of the list is reached.
<G-vec00382-003-s052><play_up.abspielen><de> Sie können einige gute Drittanbieteranwendungen ausprobieren, um Ihre Datei abzuspielen.
<G-vec00382-003-s052><play_up.abspielen><en> You can try some good third party applications to play your file.
<G-vec00382-003-s053><play_up.abspielen><de> Um die Aktion langsamer abzuspielen oder die Aktion nach jedem Schritt anzuhalten, benutzen Sie den Menüpunkt "Ausführen-Optionen" im Bedienfeldmenü.
<G-vec00382-003-s053><play_up.abspielen><en> To play the actions more slowly or to make the actions stop after each step try the "Playback Options" panel menu item. 9.
<G-vec00382-003-s054><play_up.abspielen><de> Octagon SF8008 4K bietet mit einem USB 3.0-, USB 2.0- sowie einem MicroSD-Slot und einem Kartenleser genügend Möglichkeiten, um Inhalte von externen Speichermedien abzuspielen und so das Entertainment-Erlebnis nochmals zu erhöhen.
<G-vec00382-003-s054><play_up.abspielen><en> Octagon SF8008 4K offers enough possibilities with a USB 3.0, USB 2.0 and a MicroSD slot and a card reader to play content from external storage media and thus increase the entertainment experience again.
<G-vec00382-003-s056><play_up.abspielen><de> Der integrierte ARM-Prozessor in Hyperion Fury treibt die Fusion Engine für unglaubliche Zielverfolgungsgeschwindigkeiten und ermöglicht es Dir gleichzeitig, Deine bevorzugten Makros zu speichern und abzuspielen.
<G-vec00382-003-s056><play_up.abspielen><en> Hyperion Fury on-board ARM processor powers the Fusion Engine for incredible tracking speeds while allowing you to save and play back your favorite macros.
