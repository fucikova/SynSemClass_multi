<G-vec00018-002-s023><explode.aufplatzen><de> Wenn Sie Blasen haben, sollten Sie sie nicht aufplatzen.
<G-vec00018-002-s023><explode.aufplatzen><en> If you have blisters, you should not explode them.
