<G-vec00510-001-s038><rise.ansteigen><de> Zwischen 2009 und 2015 wuchs die Einwohnerzahl der Hauptstadt Honiara um 35 % auf 87 000 an, bis 2050 wird sie auf etwa 180 000 ansteigen.
<G-vec00510-001-s038><rise.ansteigen><en> The number of people living in the capital Honiara increased by 35% to 87,000 between 2009 and 2015; by 2050 it will rise to around 180,000.
<G-vec00510-001-s039><rise.ansteigen><de> In jeder Platte gibt es Gebiete, wo die Gesteinsschichten bröckelig und nicht solide sind, und wenn das bröckelt, kann alles auf der Oberfläche passieren, von einem Abfall bis zu einem Ansteigen, einschließlich Verschiebungen im Grundwasserspiegel.
<G-vec00510-001-s039><rise.ansteigen><en> In every plate, there are areas where the layers of rock are crumbly, not solid, and when this crumbles, anything could happen on the surface, from a drop to a rise, including shifts in the water table.
<G-vec00510-001-s040><rise.ansteigen><de> Wenn die Zinsen für Anleihen mit zehnjähriger Laufzeit um nur einen Prozentpunkt ansteigen (von 3 auf 4%), bedeutet dies einen Anstieg der jährlichen Zinsbelastung für den US- Haushalt um 100 bis 150 Milliarden Dollar, also beinahe 1% des öffentlichen Defizits, das von irgendwoher finanziert werden muss, während aber die Fed gerade dabei ist, ihr Programm des Aufkaufs staatlicher Anleihen zurückzufahren.
<G-vec00510-001-s040><rise.ansteigen><en> But a 1% interest rate rise on the 10 year note (from 3% to 4%) means a steady increase in the annual interest rate payments on the US debt in the order of $100 billion to $150 billion (7), nearly 1% of the public debt to offset whilst the Fed has begun to reduce its bond repurchase programme.
<G-vec00510-001-s041><rise.ansteigen><de> Weltweit wird die Zahl der Alzheimer-Patienten/-innen bis 2050 auf 45 Millionen ansteigen, wobei drei von vier Patienten/-innen in einem Entwicklungsland und zwölf Millionen in Europa leben werden.
<G-vec00510-001-s041><rise.ansteigen><en> Globally, AD prevalence is expected to rise to 45 million by 2050, with three of every four AD patients living in a developing nation. Twelve million people in this latter group will be living in Europe.
<G-vec00510-001-s042><rise.ansteigen><de> Autismus ist am Ansteigen sogar, wo Imfpungen nicht eintreten.
<G-vec00510-001-s042><rise.ansteigen><en> Autism is on the rise even where vacinations are not occurring.
<G-vec00510-001-s043><rise.ansteigen><de> In seltenen Fällen kann die Temperatur über alle zwei Wochen ansteigen.
<G-vec00510-001-s043><rise.ansteigen><en> In rare cases, the temperature may rise over the course of all two weeks.
<G-vec00510-001-s044><rise.ansteigen><de> Zuletzt prognostiziert Alé, dass aufgrund des ungebremst wachsenden Formatdschungels die IT-Budgets auch weiterhin stark ansteigen werden.
<G-vec00510-001-s044><rise.ansteigen><en> To round up, Alé forecast that based on the burgeoning jungle of formats, the IT budget will continue to rise sharply.
<G-vec00510-001-s045><rise.ansteigen><de> In einem Zustand der Vergiftung erweitert der Patient die Blutgefäße und der Blutdruck kann ansteigen.
<G-vec00510-001-s045><rise.ansteigen><en> In a state of intoxication, the patient dilates the blood vessels and blood pressure can rise.
<G-vec00510-001-s046><rise.ansteigen><de> Auch mit radikalsten GegenMaßnahmen werden die fossilen Emissionen noch auf 400 Milliarden Tonnen ansteigen.
<G-vec00510-001-s046><rise.ansteigen><en> Even with the most radical counter measures, the fossil emission will rise to 400 billion tons.
<G-vec00510-001-s047><rise.ansteigen><de> Dabei könnte bei Ausschöpfung des vorhandenen Potenzials die Energieerzeugung bis 2020 auf 15.000 MW ansteigen.
<G-vec00510-001-s047><rise.ansteigen><en> However, by total exploitation of the possibilities in this field, the volume of energy production could rise to 15,000 MW in 2020.
<G-vec00510-001-s048><rise.ansteigen><de> In städtischen Regionen ist FGM sogar im Ansteigen: Laut der Untersuchung werden 78% der Frauen in städtischen Regionen Opfer von FGM, bevor sie 14 Jahre alt sind.
<G-vec00510-001-s048><rise.ansteigen><en> It is also on the rise in urban areas: According to the survey 78% of women in urban areas are circumcised by the age of 14.
<G-vec00510-001-s049><rise.ansteigen><de> Unter anderem aufgrund des demografischen Wandels und des ausgabensteigernden medizinisch-technischen Fortschritts könnten die Beitragssätze bis zum Jahr 2050 auf über 60 Prozent ansteigen.
<G-vec00510-001-s049><rise.ansteigen><en> Partly as a result of demographic change and expenses-driving medical and technological progress, contribution rates could rise to more than 60 percent by the year 2050.
<G-vec00510-001-s050><rise.ansteigen><de> Alleine in der Europäischen Union wird gemäß den Prognosen der EU-Kommission die Zahl der jährlich durch Krebs verursachten Todesfälle von 1,12 Millionen im Jahr 2000 auf 1,4 Millionen im Jahr 2015 ansteigen.
<G-vec00510-001-s050><rise.ansteigen><en> The European Commission forecasts that in the European Union alone, the annual number of deaths caused by cancer will rise from 1.12 million in 2000 to 1.4 million in 2015.
<G-vec00510-001-s051><rise.ansteigen><de> Die EBIT-Marge im Segment liegt bei 9,3 %, wird aber im Laufe des Geschäftsjahrs kontinuierlich ansteigen.
<G-vec00510-001-s051><rise.ansteigen><en> The segment's EBIT margin was 9.3% but will rise steadily over the course of the fiscal year.
<G-vec00510-001-s052><rise.ansteigen><de> Dank der Fenstersysteme kann die Raumluftfeuchte bis auf 64 % ansteigen, ohne dass es zur Kondensatbildung kommt.
<G-vec00510-001-s052><rise.ansteigen><en> Thanks to the window systems, indoor humidity can rise up to 64% without any condensation.
<G-vec00510-001-s053><rise.ansteigen><de> Der Blutdruck kann ansteigen, die Herzfrequenz steigt, Schwindel beginnt und es kommt sogar zu Ohnmacht.
<G-vec00510-001-s053><rise.ansteigen><en> Blood pressure may rise, heart rate increases, dizziness begins, and even fainting occurs.
<G-vec00510-001-s054><rise.ansteigen><de> Doch bereits 10 °C Abkühlung der Garagentemperatur durch nächtlich fallende Gradzahlen, lassen die relative Feuchtigkeit in der Luft um mehr als 30 % ansteigen.
<G-vec00510-001-s054><rise.ansteigen><en> Even a cooling of 10°C in the garage due to temperatures dropping at night allows the relative humidity of the air to rise by more than 30%.
<G-vec00510-001-s055><rise.ansteigen><de> Aufgrund stark gestiegener Preise wird das weltweite Marktvolumen für die 17 Elemente, die als „Seltene Erden“ bezeichnet werden, im Jahr 2011 voraussichtlich auf 27 Milliarden Euro ansteigen.
<G-vec00510-001-s055><rise.ansteigen><en> Due to skyrocketing prices, worldwide market volumes for the 17 elements known as “rare earths” are expected to rise to EUR 27 billion in 2011.
<G-vec00510-001-s056><rise.ansteigen><de> 2016 etwas mehr Schwung fÃ1⁄4r alle Bundesländer erwartet Angetrieben vor allem von einer anziehenden Binnenkonjunktur wird das Wirtschaftswachstum in Österreich von 0,9 Prozent auf 1,5 Prozent im Jahr 2016 ansteigen.
<G-vec00510-001-s056><rise.ansteigen><en> Somewhat more momentum expected for all federal provinces in 2016 Driven primarily by an expanding domestic economy, Austrian economic growth in 2016 is likely to rise from 0.9 percent to 1.5 percent.
<G-vec00510-001-s038><rise.ansteigen><de> Zwischen 2009 und 2015 wuchs die Einwohnerzahl der Hauptstadt Honiara um 35 % auf 87 000 an, bis 2050 wird sie auf etwa 180 000 ansteigen.
<G-vec00510-001-s038><rise.ansteigen><en> The number of people living in the capital Honiara increased by 35% to 87,000 between 2009 and 2015; by 2050 it will rise to around 180,000.
<G-vec00510-001-s039><rise.ansteigen><de> In jeder Platte gibt es Gebiete, wo die Gesteinsschichten bröckelig und nicht solide sind, und wenn das bröckelt, kann alles auf der Oberfläche passieren, von einem Abfall bis zu einem Ansteigen, einschließlich Verschiebungen im Grundwasserspiegel.
<G-vec00510-001-s039><rise.ansteigen><en> In every plate, there are areas where the layers of rock are crumbly, not solid, and when this crumbles, anything could happen on the surface, from a drop to a rise, including shifts in the water table.
<G-vec00510-001-s040><rise.ansteigen><de> Wenn die Zinsen für Anleihen mit zehnjähriger Laufzeit um nur einen Prozentpunkt ansteigen (von 3 auf 4%), bedeutet dies einen Anstieg der jährlichen Zinsbelastung für den US- Haushalt um 100 bis 150 Milliarden Dollar, also beinahe 1% des öffentlichen Defizits, das von irgendwoher finanziert werden muss, während aber die Fed gerade dabei ist, ihr Programm des Aufkaufs staatlicher Anleihen zurückzufahren.
<G-vec00510-001-s040><rise.ansteigen><en> But a 1% interest rate rise on the 10 year note (from 3% to 4%) means a steady increase in the annual interest rate payments on the US debt in the order of $100 billion to $150 billion (7), nearly 1% of the public debt to offset whilst the Fed has begun to reduce its bond repurchase programme.
<G-vec00510-001-s041><rise.ansteigen><de> Weltweit wird die Zahl der Alzheimer-Patienten/-innen bis 2050 auf 45 Millionen ansteigen, wobei drei von vier Patienten/-innen in einem Entwicklungsland und zwölf Millionen in Europa leben werden.
<G-vec00510-001-s041><rise.ansteigen><en> Globally, AD prevalence is expected to rise to 45 million by 2050, with three of every four AD patients living in a developing nation. Twelve million people in this latter group will be living in Europe.
<G-vec00510-001-s042><rise.ansteigen><de> Autismus ist am Ansteigen sogar, wo Imfpungen nicht eintreten.
<G-vec00510-001-s042><rise.ansteigen><en> Autism is on the rise even where vacinations are not occurring.
<G-vec00510-001-s043><rise.ansteigen><de> In seltenen Fällen kann die Temperatur über alle zwei Wochen ansteigen.
<G-vec00510-001-s043><rise.ansteigen><en> In rare cases, the temperature may rise over the course of all two weeks.
<G-vec00510-001-s044><rise.ansteigen><de> Zuletzt prognostiziert Alé, dass aufgrund des ungebremst wachsenden Formatdschungels die IT-Budgets auch weiterhin stark ansteigen werden.
<G-vec00510-001-s044><rise.ansteigen><en> To round up, Alé forecast that based on the burgeoning jungle of formats, the IT budget will continue to rise sharply.
<G-vec00510-001-s045><rise.ansteigen><de> In einem Zustand der Vergiftung erweitert der Patient die Blutgefäße und der Blutdruck kann ansteigen.
<G-vec00510-001-s045><rise.ansteigen><en> In a state of intoxication, the patient dilates the blood vessels and blood pressure can rise.
<G-vec00510-001-s046><rise.ansteigen><de> Auch mit radikalsten GegenMaßnahmen werden die fossilen Emissionen noch auf 400 Milliarden Tonnen ansteigen.
<G-vec00510-001-s046><rise.ansteigen><en> Even with the most radical counter measures, the fossil emission will rise to 400 billion tons.
<G-vec00510-001-s047><rise.ansteigen><de> Dabei könnte bei Ausschöpfung des vorhandenen Potenzials die Energieerzeugung bis 2020 auf 15.000 MW ansteigen.
<G-vec00510-001-s047><rise.ansteigen><en> However, by total exploitation of the possibilities in this field, the volume of energy production could rise to 15,000 MW in 2020.
<G-vec00510-001-s048><rise.ansteigen><de> In städtischen Regionen ist FGM sogar im Ansteigen: Laut der Untersuchung werden 78% der Frauen in städtischen Regionen Opfer von FGM, bevor sie 14 Jahre alt sind.
<G-vec00510-001-s048><rise.ansteigen><en> It is also on the rise in urban areas: According to the survey 78% of women in urban areas are circumcised by the age of 14.
<G-vec00510-001-s049><rise.ansteigen><de> Unter anderem aufgrund des demografischen Wandels und des ausgabensteigernden medizinisch-technischen Fortschritts könnten die Beitragssätze bis zum Jahr 2050 auf über 60 Prozent ansteigen.
<G-vec00510-001-s049><rise.ansteigen><en> Partly as a result of demographic change and expenses-driving medical and technological progress, contribution rates could rise to more than 60 percent by the year 2050.
<G-vec00510-001-s050><rise.ansteigen><de> Alleine in der Europäischen Union wird gemäß den Prognosen der EU-Kommission die Zahl der jährlich durch Krebs verursachten Todesfälle von 1,12 Millionen im Jahr 2000 auf 1,4 Millionen im Jahr 2015 ansteigen.
<G-vec00510-001-s050><rise.ansteigen><en> The European Commission forecasts that in the European Union alone, the annual number of deaths caused by cancer will rise from 1.12 million in 2000 to 1.4 million in 2015.
<G-vec00510-001-s051><rise.ansteigen><de> Die EBIT-Marge im Segment liegt bei 9,3 %, wird aber im Laufe des Geschäftsjahrs kontinuierlich ansteigen.
<G-vec00510-001-s051><rise.ansteigen><en> The segment's EBIT margin was 9.3% but will rise steadily over the course of the fiscal year.
<G-vec00510-001-s052><rise.ansteigen><de> Dank der Fenstersysteme kann die Raumluftfeuchte bis auf 64 % ansteigen, ohne dass es zur Kondensatbildung kommt.
<G-vec00510-001-s052><rise.ansteigen><en> Thanks to the window systems, indoor humidity can rise up to 64% without any condensation.
<G-vec00510-001-s053><rise.ansteigen><de> Der Blutdruck kann ansteigen, die Herzfrequenz steigt, Schwindel beginnt und es kommt sogar zu Ohnmacht.
<G-vec00510-001-s053><rise.ansteigen><en> Blood pressure may rise, heart rate increases, dizziness begins, and even fainting occurs.
<G-vec00510-001-s054><rise.ansteigen><de> Doch bereits 10 °C Abkühlung der Garagentemperatur durch nächtlich fallende Gradzahlen, lassen die relative Feuchtigkeit in der Luft um mehr als 30 % ansteigen.
<G-vec00510-001-s054><rise.ansteigen><en> Even a cooling of 10°C in the garage due to temperatures dropping at night allows the relative humidity of the air to rise by more than 30%.
<G-vec00510-001-s055><rise.ansteigen><de> Aufgrund stark gestiegener Preise wird das weltweite Marktvolumen für die 17 Elemente, die als „Seltene Erden“ bezeichnet werden, im Jahr 2011 voraussichtlich auf 27 Milliarden Euro ansteigen.
<G-vec00510-001-s055><rise.ansteigen><en> Due to skyrocketing prices, worldwide market volumes for the 17 elements known as “rare earths” are expected to rise to EUR 27 billion in 2011.
<G-vec00510-001-s056><rise.ansteigen><de> 2016 etwas mehr Schwung fÃ1⁄4r alle Bundesländer erwartet Angetrieben vor allem von einer anziehenden Binnenkonjunktur wird das Wirtschaftswachstum in Österreich von 0,9 Prozent auf 1,5 Prozent im Jahr 2016 ansteigen.
<G-vec00510-001-s056><rise.ansteigen><en> Somewhat more momentum expected for all federal provinces in 2016 Driven primarily by an expanding domestic economy, Austrian economic growth in 2016 is likely to rise from 0.9 percent to 1.5 percent.
