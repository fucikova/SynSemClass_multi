<G-vec00510-001-s038><rise.ansteigen><de> Zwischen 2009 und 2015 wuchs die Einwohnerzahl der Hauptstadt Honiara um 35 % auf 87 000 an, bis 2050 wird sie auf etwa 180 000 ansteigen.
<G-vec00510-001-s038><rise.ansteigen><en> The number of people living in the capital Honiara increased by 35% to 87,000 between 2009 and 2015; by 2050 it will rise to around 180,000.
<G-vec00510-001-s039><rise.ansteigen><de> In jeder Platte gibt es Gebiete, wo die Gesteinsschichten bröckelig und nicht solide sind, und wenn das bröckelt, kann alles auf der Oberfläche passieren, von einem Abfall bis zu einem Ansteigen, einschließlich Verschiebungen im Grundwasserspiegel.
<G-vec00510-001-s039><rise.ansteigen><en> In every plate, there are areas where the layers of rock are crumbly, not solid, and when this crumbles, anything could happen on the surface, from a drop to a rise, including shifts in the water table.
<G-vec00510-001-s040><rise.ansteigen><de> Wenn die Zinsen für Anleihen mit zehnjähriger Laufzeit um nur einen Prozentpunkt ansteigen (von 3 auf 4%), bedeutet dies einen Anstieg der jährlichen Zinsbelastung für den US- Haushalt um 100 bis 150 Milliarden Dollar, also beinahe 1% des öffentlichen Defizits, das von irgendwoher finanziert werden muss, während aber die Fed gerade dabei ist, ihr Programm des Aufkaufs staatlicher Anleihen zurückzufahren.
<G-vec00510-001-s040><rise.ansteigen><en> But a 1% interest rate rise on the 10 year note (from 3% to 4%) means a steady increase in the annual interest rate payments on the US debt in the order of $100 billion to $150 billion (7), nearly 1% of the public debt to offset whilst the Fed has begun to reduce its bond repurchase programme.
<G-vec00510-001-s041><rise.ansteigen><de> Weltweit wird die Zahl der Alzheimer-Patienten/-innen bis 2050 auf 45 Millionen ansteigen, wobei drei von vier Patienten/-innen in einem Entwicklungsland und zwölf Millionen in Europa leben werden.
<G-vec00510-001-s041><rise.ansteigen><en> Globally, AD prevalence is expected to rise to 45 million by 2050, with three of every four AD patients living in a developing nation. Twelve million people in this latter group will be living in Europe.
<G-vec00510-001-s042><rise.ansteigen><de> Autismus ist am Ansteigen sogar, wo Imfpungen nicht eintreten.
<G-vec00510-001-s042><rise.ansteigen><en> Autism is on the rise even where vacinations are not occurring.
<G-vec00510-001-s043><rise.ansteigen><de> In seltenen Fällen kann die Temperatur über alle zwei Wochen ansteigen.
<G-vec00510-001-s043><rise.ansteigen><en> In rare cases, the temperature may rise over the course of all two weeks.
<G-vec00510-001-s044><rise.ansteigen><de> Zuletzt prognostiziert Alé, dass aufgrund des ungebremst wachsenden Formatdschungels die IT-Budgets auch weiterhin stark ansteigen werden.
<G-vec00510-001-s044><rise.ansteigen><en> To round up, Alé forecast that based on the burgeoning jungle of formats, the IT budget will continue to rise sharply.
<G-vec00510-001-s045><rise.ansteigen><de> In einem Zustand der Vergiftung erweitert der Patient die Blutgefäße und der Blutdruck kann ansteigen.
<G-vec00510-001-s045><rise.ansteigen><en> In a state of intoxication, the patient dilates the blood vessels and blood pressure can rise.
<G-vec00510-001-s046><rise.ansteigen><de> Auch mit radikalsten GegenMaßnahmen werden die fossilen Emissionen noch auf 400 Milliarden Tonnen ansteigen.
<G-vec00510-001-s046><rise.ansteigen><en> Even with the most radical counter measures, the fossil emission will rise to 400 billion tons.
<G-vec00510-001-s047><rise.ansteigen><de> Dabei könnte bei Ausschöpfung des vorhandenen Potenzials die Energieerzeugung bis 2020 auf 15.000 MW ansteigen.
<G-vec00510-001-s047><rise.ansteigen><en> However, by total exploitation of the possibilities in this field, the volume of energy production could rise to 15,000 MW in 2020.
<G-vec00510-001-s048><rise.ansteigen><de> In städtischen Regionen ist FGM sogar im Ansteigen: Laut der Untersuchung werden 78% der Frauen in städtischen Regionen Opfer von FGM, bevor sie 14 Jahre alt sind.
<G-vec00510-001-s048><rise.ansteigen><en> It is also on the rise in urban areas: According to the survey 78% of women in urban areas are circumcised by the age of 14.
<G-vec00510-001-s049><rise.ansteigen><de> Unter anderem aufgrund des demografischen Wandels und des ausgabensteigernden medizinisch-technischen Fortschritts könnten die Beitragssätze bis zum Jahr 2050 auf über 60 Prozent ansteigen.
<G-vec00510-001-s049><rise.ansteigen><en> Partly as a result of demographic change and expenses-driving medical and technological progress, contribution rates could rise to more than 60 percent by the year 2050.
<G-vec00510-001-s050><rise.ansteigen><de> Alleine in der Europäischen Union wird gemäß den Prognosen der EU-Kommission die Zahl der jährlich durch Krebs verursachten Todesfälle von 1,12 Millionen im Jahr 2000 auf 1,4 Millionen im Jahr 2015 ansteigen.
<G-vec00510-001-s050><rise.ansteigen><en> The European Commission forecasts that in the European Union alone, the annual number of deaths caused by cancer will rise from 1.12 million in 2000 to 1.4 million in 2015.
<G-vec00510-001-s051><rise.ansteigen><de> Die EBIT-Marge im Segment liegt bei 9,3 %, wird aber im Laufe des Geschäftsjahrs kontinuierlich ansteigen.
<G-vec00510-001-s051><rise.ansteigen><en> The segment's EBIT margin was 9.3% but will rise steadily over the course of the fiscal year.
<G-vec00510-001-s052><rise.ansteigen><de> Dank der Fenstersysteme kann die Raumluftfeuchte bis auf 64 % ansteigen, ohne dass es zur Kondensatbildung kommt.
<G-vec00510-001-s052><rise.ansteigen><en> Thanks to the window systems, indoor humidity can rise up to 64% without any condensation.
<G-vec00510-001-s053><rise.ansteigen><de> Der Blutdruck kann ansteigen, die Herzfrequenz steigt, Schwindel beginnt und es kommt sogar zu Ohnmacht.
<G-vec00510-001-s053><rise.ansteigen><en> Blood pressure may rise, heart rate increases, dizziness begins, and even fainting occurs.
<G-vec00510-001-s054><rise.ansteigen><de> Doch bereits 10 °C Abkühlung der Garagentemperatur durch nächtlich fallende Gradzahlen, lassen die relative Feuchtigkeit in der Luft um mehr als 30 % ansteigen.
<G-vec00510-001-s054><rise.ansteigen><en> Even a cooling of 10°C in the garage due to temperatures dropping at night allows the relative humidity of the air to rise by more than 30%.
<G-vec00510-001-s055><rise.ansteigen><de> Aufgrund stark gestiegener Preise wird das weltweite Marktvolumen für die 17 Elemente, die als „Seltene Erden“ bezeichnet werden, im Jahr 2011 voraussichtlich auf 27 Milliarden Euro ansteigen.
<G-vec00510-001-s055><rise.ansteigen><en> Due to skyrocketing prices, worldwide market volumes for the 17 elements known as “rare earths” are expected to rise to EUR 27 billion in 2011.
<G-vec00510-001-s056><rise.ansteigen><de> 2016 etwas mehr Schwung fÃ1⁄4r alle Bundesländer erwartet Angetrieben vor allem von einer anziehenden Binnenkonjunktur wird das Wirtschaftswachstum in Österreich von 0,9 Prozent auf 1,5 Prozent im Jahr 2016 ansteigen.
<G-vec00510-001-s056><rise.ansteigen><en> Somewhat more momentum expected for all federal provinces in 2016 Driven primarily by an expanding domestic economy, Austrian economic growth in 2016 is likely to rise from 0.9 percent to 1.5 percent.
<G-vec00298-002-s019><increase.ansteigen><de> Sobald Ihr Rang und Ihre Aktivität ansteigen, erhalten Sie Zugriff auf die Trading-Informationen von Mitgliedern des nächsthöheren Niveaus.
<G-vec00298-002-s019><increase.ansteigen><en> As your rank and activity increase, you will access information of better and more active traders.
<G-vec00298-002-s020><increase.ansteigen><de> Dagegen wird die Bevölkerung Afrikas und Asiens in den nächsten Jahrzehnten weiter stark ansteigen, wobei insbesondere in Afrika ein drastischer Bevölkerungsanstieg zu erwarten ist (siehe Grafik).
<G-vec00298-002-s020><increase.ansteigen><en> The populations of Africa and Asia will continue to increase significantly – and dramatically so in Africa – over the next few decades (chart).
<G-vec00298-002-s021><increase.ansteigen><de> Neben dem Geschlecht und dem Alter lassen berufliche und umweltbedingte Faktoren, körperliche und psychische Belastungen, Stress, Ernährungsgewohnheiten, Schwangerschaft, Stillzeiten, Krankheiten, Medikamente, darunter die Anti-Baby-Pille, Nikotin und Alkohol den Vitaminbedarf ansteigen.
<G-vec00298-002-s021><increase.ansteigen><en> Besides gender and age, occupational and environmental factors, physical and mental pressures, stress, diet, pregnancy, breastfeeding, illnesses, drugs including the birth control pill, nicotine and alcohol can also increase the vitamin requirements of the body.
<G-vec00298-002-s022><increase.ansteigen><de> Bis 2030 wird diese Zahl über 25 % ansteigen.
<G-vec00298-002-s022><increase.ansteigen><en> By 2030, that number will increase by nearly 50% (46%)4.
<G-vec00298-002-s023><increase.ansteigen><de> Es ist zu erwarten, dass Armut und Hunger sprunghaft ansteigen werden.
<G-vec00298-002-s023><increase.ansteigen><en> It is to be expected that poverty and hunger will increase sharply.
<G-vec00298-002-s024><increase.ansteigen><de> Die Unterzeichnung des Freihandelsabkommens der Europäischen Freihandelsassoziation (European Free Trade Association, EFTA) mit Singapur im Jahr 2003 – das erste mit einem asiatischen Land – ließ den Handel zwischen der Schweiz und Singapur sprunghaft ansteigen.
<G-vec00298-002-s024><increase.ansteigen><en> The signing of the European Free Trade Association with Singapore in 2003 – the first with an Asian country – caused a sharp increase in trade between the two countries.
<G-vec00298-002-s025><increase.ansteigen><de> Man kann davon ausgehen, dass der Markt f√ľr VRF Systeme weiter schnell ansteigen wird.
<G-vec00298-002-s025><increase.ansteigen><en> It is expected that the market value of VRF systems will continue to increase rapidly.
<G-vec00298-002-s026><increase.ansteigen><de> Bis Ende 2007 wird die Produktionskapazität durch die Fertigstellung der ersten beiden Ausbaustufen der Produktionslinie V auf 432 MWp ansteigen (das entspricht einer Nominalkapazität von 540 MWp).
<G-vec00298-002-s026><increase.ansteigen><en> By the end of 2007, production capacity is expected to increase to 432 MWp (corresponding to a nominal capacity of 540 MWp) based on completion of the first two stages of production line V.
<G-vec00298-002-s027><increase.ansteigen><de> Beim reduzierten Material wurde eine weitere Analyse durchgeführt, um eine Zeit-Extraktionskurve zu generieren, die zeigt, dass die Auflösung des Lithiums relativ schnell vonstatten geht und in der ersten Stunde 50 % erreicht; auch nach vier Stunden kann sie weiter ansteigen.
<G-vec00298-002-s027><increase.ansteigen><en> An additional test was done on the reduced material to generate a time-extraction curve, shown below, which shows dissolution of the lithium is relatively fast, reaching 50% in the first hour, and may continue to increase beyond 4 hours.
<G-vec00298-002-s028><increase.ansteigen><de> Die Erhöhung des Lebensstandards einer ständig wachsenden Weltbevölkerung wird den weltweiten Energieverbrauch in den nächsten 25 Jahren dramatisch ansteigen lassen.
<G-vec00298-002-s028><increase.ansteigen><en> Rising living standards of a growing world population will cause global energy consumption to increase dramatically over the next half century.
<G-vec00298-002-s029><increase.ansteigen><de> Die Herzfrequenz kann in der Sauna auf bis zu 150 Schläge pro Minute ansteigen, sodass sich Saunagänger unmittelbar nach dem Saunabesuch nicht notwendigerweise müde fühlen müssen.
<G-vec00298-002-s029><increase.ansteigen><en> In the sauna, the heart rate may increase to up to 150 beats per minute, so sauna goers may not necessarily feel sleepy immediately afterwards.
<G-vec00298-002-s030><increase.ansteigen><de> Ab dem ersten Januar 2016 wird der Leaders Guild-Beitrag von 30$ auf 36$ ansteigen.
<G-vec00298-002-s030><increase.ansteigen><en> Beginning January 1, 2016 Leaders Guild fees will increase from $30 to $36.
<G-vec00298-002-s031><increase.ansteigen><de> Glaukom — Das ist ein Ansteigen des Augendrucks, der Blindheit verursachen kann.
<G-vec00298-002-s031><increase.ansteigen><en> Glaucoma — An increase in eye pressure that can cause blindness.
<G-vec00298-002-s032><increase.ansteigen><de> Wenn wir nicht bald den enormen Mengen an Kohlendioxide (CO2), die ausgeleitet werden, Einhalt gebieten, wird die globale Durchschnittstemperatur ansteigen mit Konsequenzen für Natur, Tierwelt und Menschen zu Folge.
<G-vec00298-002-s032><increase.ansteigen><en> If we not put a stop to the vast amounts of CO2 emitted a great increase in the global average temperature will occur with severe consequences for both nature, animals and humans.
<G-vec00298-002-s033><increase.ansteigen><de> Die Dauer eines Tagesschlafs wird wahrscheinlich leicht ansteigen.
<G-vec00298-002-s033><increase.ansteigen><en> The duration of a day's sleep is likely to increase slightly.
<G-vec00298-002-s034><increase.ansteigen><de> Es ist sehr wahrscheinlich, dass die Temperaturen stark ansteigen werden, der Niederschlag unzuverlässiger wird und generell die Variabilität zwischen den Jahreszeiten zunehmen wird.
<G-vec00298-002-s034><increase.ansteigen><en> It is very likely that it could be affected by strong increase in temperature, a less reliable precipitation, and generally increased intra-seasonal variability.
<G-vec00298-002-s035><increase.ansteigen><de> Der Studienverlauf folgt einem Konzept, nach dem einerseits die fachwissenschaftlichen Themen systematisch aufgebaut und vermittelt werden, andererseits mit zunehmender Studiendauer die Spezialisierungen und die praktischen Anteile ansteigen.
<G-vec00298-002-s035><increase.ansteigen><en> The course of study follows a concept in which the one hand, the scientific topics fold be established systematically and provides, on the other hand, with increasing duration of study specializations and practical proportions increase.
<G-vec00298-002-s036><increase.ansteigen><de> Die Weltbevölkerung musst enorm ansteigen, um die Übernahme der Dunklen zu verhindern.
<G-vec00298-002-s036><increase.ansteigen><en> The population of the Earth had to increase enormously to prevent the dark takeover.
<G-vec00298-002-s037><increase.ansteigen><de> Bei sich ständig ändernden Wechselkursen können die Auswirkungen der Wechselkursschwankungen dazu führen, dass die Kosten für Ihre Immobilie im Ausland plötzlich ansteigen.
<G-vec00298-002-s037><increase.ansteigen><en> With exchange rates always on the move, the impact of rate movements can lead to a sudden increase in the cost of your overseas property.
<G-vec00109-002-s038><rise.ansteigen><de> Die meisten Berechnungen und Analysen für das Jahr 2013 gehen davon aus, dass die Arbeitslosigkeit in Spanien weiterhin ansteigen wird.
<G-vec00109-002-s038><rise.ansteigen><en> Most calculations and analyses for 2013 are based on the assumption that unemployment in Spain will continue to rise.
<G-vec00109-002-s039><rise.ansteigen><de> Und auch über das Ansteigen von steuerlichem Grundfreibetrag, Kindergeldfreibetrag, Kindergeld und Kinderzuschlag sind wir auf dem aktuellen Wissensstand.
<G-vec00109-002-s039><rise.ansteigen><en> And when it comes to the rise in the basic tax-free allowance, the child allowance, child benefit and child supplement, our knowledge is entirely up to date.
<G-vec00109-002-s040><rise.ansteigen><de> In einigen EU15-Ländern löste die Höhe der Zuwanderungszahlen bei Politikern und in der Öffentlichkeit die Sorge aus, dass die hohen Arbeitslosenzahlen ansteigen würden, sobald "billige" Arbeitskräfte auf den Markt strömten.
<G-vec00109-002-s040><rise.ansteigen><en> In some EU15 countries, the high number of predicted immigrants raised fears among politicians and the general public that already high unemployment rates would rise further once 'cheap' labour flooded the market.
<G-vec00109-002-s041><rise.ansteigen><de> Der Begriff Kaltpressung ist ein bißchen irreführend, denn auch bei kalter Pressung kann die Temperatur des Preßgutes durch Reibung ohne weiteres auf 40 °C ansteigen.
<G-vec00109-002-s041><rise.ansteigen><en> The term cold-pressed is somewhat confusing, because even cold-pressed oils are not obtained at refrigerator or even room temperature; due to friction in the seeds the temperature may rise well up to 40 °C. Some oil mills improve the quality of their products by artificial cooling during the extraction procedure.
<G-vec00109-002-s042><rise.ansteigen><de> Die optimale Temperatur liegt im Sommer bei 25 ° C. An sehr sonnigen Tagen kann diese Temperatur problemlos auf 35 ° C ansteigen, damit dem Kaktus genügend Feuchtigkeit zur Verfügung steht.
<G-vec00109-002-s042><rise.ansteigen><en> The most optimal temperature is around 25 ° C during the summer. On really sunny days, this temperature can rise to 35 ° C without problems, ensuring that the cactus has sufficient moisture available.
<G-vec00109-002-s043><rise.ansteigen><de> Aber selbst wenn es sich in der Nähe des Uterusbodens befindet, haben Ärzte keine Eile, den Alarm auszulösen, da sie mit dem Verlauf der Schwangerschaft ansteigen können.
<G-vec00109-002-s043><rise.ansteigen><en> But even if it is located close to the bottom of the uterus, doctors are not in a hurry to sound the alarm, as with the course of pregnancy it can rise.
<G-vec00109-002-s044><rise.ansteigen><de> Gleichzeitig werden sich die weltweiten Hygienestandards erhöhen, wodurch auch die Nachfrage nach Vliesstoffprodukten für hygienische Anwendungen weiter ansteigen wird.
<G-vec00109-002-s044><rise.ansteigen><en> At the same time, hygiene standards are improving globally, which comes with another rise in the demand for nonwovens for hygiene applications.
<G-vec00109-002-s045><rise.ansteigen><de> In dieser Quelle ist ein ständiger Fluss von Gedanken, der zu dem Punkt ansteigen kann, wo das Gewissen aufgibt und der Damm mit zerstörender Gewalt bricht.
<G-vec00109-002-s045><rise.ansteigen><en> In this fountain there is a steady flow of thoughts, which can rise to a point where the conscience gives in and the dam breaks under destructive power.
<G-vec00109-002-s046><rise.ansteigen><de> Sogar in einem Land wie Indien, in dem eine starke Arbeitsethik herrscht, aber Corona-Infektionen noch immer ansteigen, ergab unsere Umfrage, dass 76 Prozent der Menschen bis Oktober an ihren Arbeitsplatz zurückkehren würden.
<G-vec00109-002-s046><rise.ansteigen><en> Even in a country like India, where there’s a strong work ethic but coronavirus cases are still on the rise, our survey found that 76% of people would return to work by October.
<G-vec00109-002-s047><rise.ansteigen><de> Da das kommende Vorzeigemodell den Gerüchten zufolge deutlich teurer wird als seine Vorgänger, soll auch der Durchschnittspreis für das iPhone ab Oktober stark ansteigen.
<G-vec00109-002-s047><rise.ansteigen><en> Since the upcoming show model is rumored to be significantly more expensive than its predecessors, the average price for the iPhone is expected to rise sharply from October.
<G-vec00109-002-s048><rise.ansteigen><de> Das bedeutet, dass die Körpertemperatur von Astronauten bei körperlicher Belastung leicht auf über 40 °C ansteigen kann.
<G-vec00109-002-s048><rise.ansteigen><en> This means that the body temperature of astronauts can easily rise to over 40 °C during physical exertion.
<G-vec00109-002-s049><rise.ansteigen><de> Festgesetzte Jackpots sind immer gleich groß, während progressive Jackpots solange weiter ansteigen bis ein glücklicher Gewinner den gesamten Betrag gewinnt.
<G-vec00109-002-s049><rise.ansteigen><en> Fixed jackpots are always the same, while progressive jackpots continue to rise until someone wins the whole amount.
<G-vec00109-002-s050><rise.ansteigen><de> Nach dem Eintritt in den weiblichen Organismus des Erregers kann die Temperatur stark ansteigen, was auch eine Fehlgeburt hervorruft.
<G-vec00109-002-s050><rise.ansteigen><en> After getting into the female organism of the pathogen, the temperature can rise sharply, which also provokes miscarriage.
<G-vec00109-002-s051><rise.ansteigen><de> Die Marge für das operative Ergebnis vor Einmaleffekten (EBIT) wird voraussichtlich auf über 6% ansteigen.
<G-vec00109-002-s051><rise.ansteigen><en> The operating income margin before exceptionals is expected to rise above 6%.
<G-vec00109-002-s052><rise.ansteigen><de> Die Statistiken zeigen ein Ansteigen des Antisemitismus.
<G-vec00109-002-s052><rise.ansteigen><en> Statistics show a rise in anti-Semitism.
<G-vec00109-002-s053><rise.ansteigen><de> 4.Der Fahrer kann den "Schließen" -Knopf an der Steuerbox drücken und die "Schließen" -Anzeigeleuchte wird eingeschaltet, um zu zeigen, dass die Klammer im geschlossenen Zustand ist, 1-2 Sekunden, so dass sie ansteigen kann.
<G-vec00109-002-s053><rise.ansteigen><en> 4.The driver can press the "close" button on the control box and the "Close" indicator light is turned on to show that the clamp is in closed state, 1―2 seconds so can rise.
<G-vec00109-002-s054><rise.ansteigen><de> Der Anteil der Patienten über 65 wird in den nächsten Jahren und Jahrzehnten dramatisch ansteigen.
<G-vec00109-002-s054><rise.ansteigen><en> The proportion of patients over the age of 65 will rise dramatically in the years and decades to come.
<G-vec00109-002-s055><rise.ansteigen><de> Aber selbst wenn alle User nur die kostenlose Midnight Blue Karte aus Plastik nehmen würden, dann würde auch in diesem Fall die Nachfrage an MCO Token stark ansteigen.
<G-vec00109-002-s055><rise.ansteigen><en> But even if all users would only take the free Midnight Blue card made of plastic, the demand for MCO tokens would rise strongly in this case as well.
<G-vec00109-002-s056><rise.ansteigen><de> Beim Szenario mit hohen Emissionen (RCP8.5) würden die Emissionen in den nächsten Jahrzehnten weiter stark ansteigen.
<G-vec00109-002-s056><rise.ansteigen><en> Under the high-emissions scenario, corresponding to RCP8.5, emissions would continue to rise rapidly over the next few decades.
<G-vec00109-002-s057><rise.ansteigen><de> Dieser Anstieg resultierte im Wesentlichen aus zwei Effekten: Einerseits verursachte die beschriebene Integration von Distributionsgesellschaften in Deutschland zusätzliche Personalkosten in Höhe von 14,4 Mio EUR, denen allerdings ein Rückgang der bezogenen Leistungen gegenübersteht.
<G-vec00109-002-s057><rise.ansteigen><en> This rise can be primarily attributed to two factors. First, the previously-mentioned integration of distribution companies in Germany led to additional staff costs of EUR 14.4m offsetting the related drop in services used.
<G-vec00109-002-s058><rise.ansteigen><de> Ziel bis 2020 ist, dass sich bei einem Anstieg des BIP von einem Prozent auch der Energieverbrauch nur um ein Prozent erhöht.
<G-vec00109-002-s058><rise.ansteigen><en> The vision is that, by 2020, a one-percent rise of energy use should propel GDP growth of one percent.
<G-vec00109-002-s059><rise.ansteigen><de> Nach dem Tires-Tal beginnen wir unseren Anstieg zu Nigra Pass, ganz allein: das ist nun fast Mittagszeit, und wenige Motorräder sind unterwegs.
<G-vec00109-002-s059><rise.ansteigen><en> After Tires valley we start our rise to Nigra pass all alone: by now it’s almost lunchtime and few motorcycles are on the road.
<G-vec00109-002-s060><rise.ansteigen><de> Er ist nach einem leichten Anstieg in der ersten Jahreshälfte 2019 wieder um 6 auf 126 Punkte gesunken.
<G-vec00109-002-s060><rise.ansteigen><en> Following a slight rise in the first half year 2019, the index declined 6 points to 126 points.
<G-vec00109-002-s061><rise.ansteigen><de> In Verbindung mit dem Anstieg von Euroskeptizismus, der behauptet, alle Antworten zu haben, wird eine Reform der europäischen Strukturen absolut notwendig.
<G-vec00109-002-s061><rise.ansteigen><en> Combined with the rise in Eurosceptism, which claims to hold all the answers, this makes a change in European structures absolutely necessary.
<G-vec00109-002-s062><rise.ansteigen><de> Die Ergebnisverbesserung zum Vorjahr ergibt sich einerseits aus einem Rückgang der Risikovorsorge und andererseits aus einem Anstieg der zinsunabhängigen Erträge, bedingt durch eine Neugeschäftssteigerung und dem Ausbau des Cross Sellings mit Markets-Produkten.
<G-vec00109-002-s062><rise.ansteigen><en> The improvement on the previous year is due on the one hand to a decline in risk provisions and on the other hand to an increase in non-interest business resulting from a rise in new business and the expansion of cross-selling with products from the Markets Business Area.
<G-vec00109-002-s063><rise.ansteigen><de> Die wirtschaftliche Lage in Russland und Kasachstan hat sich nach dem Anstieg des Ölpreises verbessert.
<G-vec00109-002-s063><rise.ansteigen><en> The economic situation in Russia and Kazakhstan has improved after the rise of the oil price.
<G-vec00109-002-s064><rise.ansteigen><de> Insgesamt wurden im Oktober 26.690 Nutzfahrzeuge neu zugelassen – ein Anstieg um 27 Prozent gegenüber dem Vorjahresmonat.
<G-vec00109-002-s064><rise.ansteigen><en> In October a total of 26,690 new commercial vehicles were registered – a rise of 27 per cent as compared to the same month last year.
<G-vec00109-002-s065><rise.ansteigen><de> Werden die Treibhausgasemissionen erheblich reduziert, könnten der Anstieg der durchschnittlichen weltweiten Oberflächentemperatur auf 0,9 C bis 2,3 C über den vorindustriellen Werten und der Anstieg des Meeresspiegels bis Ende dieses Jahrhunderts auf 30-50 cm gegenüber dem Niveau von 1986-2005 begrenzt werden.
<G-vec00109-002-s065><rise.ansteigen><en> If greenhouse gas emissions are reduced significantly, the rise in global average surface temperature could be limited to between 0.9°C and 2.3C above pre-industrial levels, and sea level rise to 30-50 cm relative to 1986-2005, towards the end of this century.
<G-vec00109-002-s066><rise.ansteigen><de> Darüber hinaus reichen eine riesige Bibliothek von Spielen und ein unglaubliches Willkommensbonuspaket aus, um den rasanten Anstieg der Popularität des Spielbanks und die vielen Summen zu erklären, die es in den Spielkreisen verursacht hat.
<G-vec00109-002-s066><rise.ansteigen><en> In addition, a huge library of games and an incredible welcome bonus package are enough to explain the casino’s rapid rise in popularity and the lots of buzz it’s been causing in the gambling circles.
<G-vec00109-002-s067><rise.ansteigen><de> Die UN prognostizierte daher einen Anstieg der Krätze und Vaginalinfektionen bei Frauen, denen die Körperhygiene, wie auch den Zugang zur medizinischen Versorgung verweigert wird.
<G-vec00109-002-s067><rise.ansteigen><en> It gave cause for the UN to predict a rise in scabies and vaginal infections among women denied methods of hygiene as well as access to health care.
<G-vec00109-002-s068><rise.ansteigen><de> Als die Einnahmen der Serie weiter durch Anstieg der weltweiten Verbreitung und DVD-Verkäufen zunahmen, stoppten die Originalsprecher ihr Erscheinen in Proben im April 2004.
<G-vec00109-002-s068><rise.ansteigen><en> As the show's revenue continued to rise through syndication and DVD sales, the main cast stopped appearing for script readings in April 2004.
<G-vec00109-002-s069><rise.ansteigen><de> Dieser verbesserte Ansatz hat zu einem deutlichen Anstieg im Online-Verkauf geführt und zu einem signifikant verbesserten Budget-Einsatz im Vergleich zu noch vor etwa zwei Jahren.
<G-vec00109-002-s069><rise.ansteigen><en> This improved approach has led to a noticeable rise in online sales and to a significantly improved use of budget compared to two years ago.
<G-vec00109-002-s070><rise.ansteigen><de> Zum Beispiel würde eine Erwärmung in Grönland um 5.5°C, die über 1000 Jahre andauert, wahrscheinlich zum Anstieg des Meeresspiegels von etwa 3 Metern führen.
<G-vec00109-002-s070><rise.ansteigen><en> For instance, a Greenland warming of 5.5°C, if sustained for 1,000 years, would likely7 result in a sea level rise of about 3 meters.
<G-vec00109-002-s071><rise.ansteigen><de> Deutschland, die Top-Country in der Europäischen Union verwaltet nur einen winzige 0,1 Prozent Anstieg seines zweiten Quartal-Bruttoinlandsprodukts (BIP).
<G-vec00109-002-s071><rise.ansteigen><en> Germany, the top country in the European Union, managed only a tiny 0.1 per cent rise in its second-quarter gross domestic product (GDP).
<G-vec00109-002-s072><rise.ansteigen><de> Aufgrund der ungebrochen hohen Nachfrage nach Gewerbe- und Wohnraummietflächen ist auch im zweiten Halbjahr des laufenden Geschäftsjahres mit einem Anstieg der Mietpreise - insbesondere im Wohnimmobilienbereich - zu rechnen.
<G-vec00109-002-s072><rise.ansteigen><en> Given the sustained strong demand for commercial and residential rental properties, rentals - particularly in the residential segment - are expected to rise in the second half of 2008.
<G-vec00109-002-s073><rise.ansteigen><de> Für die anspruchsvolleren gibt es die Hauptstraße nach Orebic, die einen starken Anstieg mit der größten Neigung auf die gesamte Peljesac mount trägt.
<G-vec00109-002-s073><rise.ansteigen><en> For those more demanding there is the main road to Orebic, which carries a large mount rise with the largest tilt on the whole of Peljesac.
<G-vec00109-002-s074><rise.ansteigen><de> Die Bestellungen bei MAN Diesel & Turbo gingen um 16 % zurück, während Renk in der ersten Jahreshälfte einen Anstieg beim Auftragseingang von 7 % meldete.
<G-vec00109-002-s074><rise.ansteigen><en> Orders at MAN Diesel & Turbo declined by 16%, whereas Renk saw a 7% rise in order intake in the first half of the year.
<G-vec00109-002-s075><rise.ansteigen><de> Das Ereignis trat rund 1 000 mal schneller ein als erwartet (nach Ansicht des Autors ist damit auch das akute Versagen der westantarktischen Gletscherplatte -plötzlicher Anstieg des Meeresspiegels um 6 bis 7 Meter - nicht mit Sicherheit auszuschließen.
<G-vec00109-002-s075><rise.ansteigen><en> The event occurred around 1000 times more quickly than expected (in the opinion of the author, therefore, the acute failure of the West Antarctic glacier plate - and a sudden rise of the sea level by 6 to 7 meters - cannot be ruled out with any certainty.
