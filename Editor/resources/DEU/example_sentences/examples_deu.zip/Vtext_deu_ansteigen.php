<G-vec00510-001-s038><rise.ansteigen><de> Zwischen 2009 und 2015 wuchs die Einwohnerzahl der Hauptstadt Honiara um 35 % auf 87 000 an, bis 2050 wird sie auf etwa 180 000 ansteigen.
<G-vec00510-001-s038><rise.ansteigen><en> The number of people living in the capital Honiara increased by 35% to 87,000 between 2009 and 2015; by 2050 it will rise to around 180,000.
<G-vec00510-001-s039><rise.ansteigen><de> In jeder Platte gibt es Gebiete, wo die Gesteinsschichten bröckelig und nicht solide sind, und wenn das bröckelt, kann alles auf der Oberfläche passieren, von einem Abfall bis zu einem Ansteigen, einschließlich Verschiebungen im Grundwasserspiegel.
<G-vec00510-001-s039><rise.ansteigen><en> In every plate, there are areas where the layers of rock are crumbly, not solid, and when this crumbles, anything could happen on the surface, from a drop to a rise, including shifts in the water table.
<G-vec00510-001-s040><rise.ansteigen><de> Wenn die Zinsen für Anleihen mit zehnjähriger Laufzeit um nur einen Prozentpunkt ansteigen (von 3 auf 4%), bedeutet dies einen Anstieg der jährlichen Zinsbelastung für den US- Haushalt um 100 bis 150 Milliarden Dollar, also beinahe 1% des öffentlichen Defizits, das von irgendwoher finanziert werden muss, während aber die Fed gerade dabei ist, ihr Programm des Aufkaufs staatlicher Anleihen zurückzufahren.
<G-vec00510-001-s040><rise.ansteigen><en> But a 1% interest rate rise on the 10 year note (from 3% to 4%) means a steady increase in the annual interest rate payments on the US debt in the order of $100 billion to $150 billion (7), nearly 1% of the public debt to offset whilst the Fed has begun to reduce its bond repurchase programme.
<G-vec00510-001-s041><rise.ansteigen><de> Weltweit wird die Zahl der Alzheimer-Patienten/-innen bis 2050 auf 45 Millionen ansteigen, wobei drei von vier Patienten/-innen in einem Entwicklungsland und zwölf Millionen in Europa leben werden.
<G-vec00510-001-s041><rise.ansteigen><en> Globally, AD prevalence is expected to rise to 45 million by 2050, with three of every four AD patients living in a developing nation. Twelve million people in this latter group will be living in Europe.
<G-vec00510-001-s042><rise.ansteigen><de> Autismus ist am Ansteigen sogar, wo Imfpungen nicht eintreten.
<G-vec00510-001-s042><rise.ansteigen><en> Autism is on the rise even where vacinations are not occurring.
<G-vec00510-001-s043><rise.ansteigen><de> In seltenen Fällen kann die Temperatur über alle zwei Wochen ansteigen.
<G-vec00510-001-s043><rise.ansteigen><en> In rare cases, the temperature may rise over the course of all two weeks.
<G-vec00510-001-s044><rise.ansteigen><de> Zuletzt prognostiziert Alé, dass aufgrund des ungebremst wachsenden Formatdschungels die IT-Budgets auch weiterhin stark ansteigen werden.
<G-vec00510-001-s044><rise.ansteigen><en> To round up, Alé forecast that based on the burgeoning jungle of formats, the IT budget will continue to rise sharply.
<G-vec00510-001-s045><rise.ansteigen><de> In einem Zustand der Vergiftung erweitert der Patient die Blutgefäße und der Blutdruck kann ansteigen.
<G-vec00510-001-s045><rise.ansteigen><en> In a state of intoxication, the patient dilates the blood vessels and blood pressure can rise.
<G-vec00510-001-s046><rise.ansteigen><de> Auch mit radikalsten GegenMaßnahmen werden die fossilen Emissionen noch auf 400 Milliarden Tonnen ansteigen.
<G-vec00510-001-s046><rise.ansteigen><en> Even with the most radical counter measures, the fossil emission will rise to 400 billion tons.
<G-vec00510-001-s047><rise.ansteigen><de> Dabei könnte bei Ausschöpfung des vorhandenen Potenzials die Energieerzeugung bis 2020 auf 15.000 MW ansteigen.
<G-vec00510-001-s047><rise.ansteigen><en> However, by total exploitation of the possibilities in this field, the volume of energy production could rise to 15,000 MW in 2020.
<G-vec00510-001-s048><rise.ansteigen><de> In städtischen Regionen ist FGM sogar im Ansteigen: Laut der Untersuchung werden 78% der Frauen in städtischen Regionen Opfer von FGM, bevor sie 14 Jahre alt sind.
<G-vec00510-001-s048><rise.ansteigen><en> It is also on the rise in urban areas: According to the survey 78% of women in urban areas are circumcised by the age of 14.
<G-vec00510-001-s049><rise.ansteigen><de> Unter anderem aufgrund des demografischen Wandels und des ausgabensteigernden medizinisch-technischen Fortschritts könnten die Beitragssätze bis zum Jahr 2050 auf über 60 Prozent ansteigen.
<G-vec00510-001-s049><rise.ansteigen><en> Partly as a result of demographic change and expenses-driving medical and technological progress, contribution rates could rise to more than 60 percent by the year 2050.
<G-vec00510-001-s050><rise.ansteigen><de> Alleine in der Europäischen Union wird gemäß den Prognosen der EU-Kommission die Zahl der jährlich durch Krebs verursachten Todesfälle von 1,12 Millionen im Jahr 2000 auf 1,4 Millionen im Jahr 2015 ansteigen.
<G-vec00510-001-s050><rise.ansteigen><en> The European Commission forecasts that in the European Union alone, the annual number of deaths caused by cancer will rise from 1.12 million in 2000 to 1.4 million in 2015.
<G-vec00510-001-s051><rise.ansteigen><de> Die EBIT-Marge im Segment liegt bei 9,3 %, wird aber im Laufe des Geschäftsjahrs kontinuierlich ansteigen.
<G-vec00510-001-s051><rise.ansteigen><en> The segment's EBIT margin was 9.3% but will rise steadily over the course of the fiscal year.
<G-vec00510-001-s052><rise.ansteigen><de> Dank der Fenstersysteme kann die Raumluftfeuchte bis auf 64 % ansteigen, ohne dass es zur Kondensatbildung kommt.
<G-vec00510-001-s052><rise.ansteigen><en> Thanks to the window systems, indoor humidity can rise up to 64% without any condensation.
<G-vec00510-001-s053><rise.ansteigen><de> Der Blutdruck kann ansteigen, die Herzfrequenz steigt, Schwindel beginnt und es kommt sogar zu Ohnmacht.
<G-vec00510-001-s053><rise.ansteigen><en> Blood pressure may rise, heart rate increases, dizziness begins, and even fainting occurs.
<G-vec00510-001-s054><rise.ansteigen><de> Doch bereits 10 °C Abkühlung der Garagentemperatur durch nächtlich fallende Gradzahlen, lassen die relative Feuchtigkeit in der Luft um mehr als 30 % ansteigen.
<G-vec00510-001-s054><rise.ansteigen><en> Even a cooling of 10°C in the garage due to temperatures dropping at night allows the relative humidity of the air to rise by more than 30%.
<G-vec00510-001-s055><rise.ansteigen><de> Aufgrund stark gestiegener Preise wird das weltweite Marktvolumen für die 17 Elemente, die als „Seltene Erden“ bezeichnet werden, im Jahr 2011 voraussichtlich auf 27 Milliarden Euro ansteigen.
<G-vec00510-001-s055><rise.ansteigen><en> Due to skyrocketing prices, worldwide market volumes for the 17 elements known as “rare earths” are expected to rise to EUR 27 billion in 2011.
<G-vec00510-001-s056><rise.ansteigen><de> 2016 etwas mehr Schwung fÃ1⁄4r alle Bundesländer erwartet Angetrieben vor allem von einer anziehenden Binnenkonjunktur wird das Wirtschaftswachstum in Österreich von 0,9 Prozent auf 1,5 Prozent im Jahr 2016 ansteigen.
<G-vec00510-001-s056><rise.ansteigen><en> Somewhat more momentum expected for all federal provinces in 2016 Driven primarily by an expanding domestic economy, Austrian economic growth in 2016 is likely to rise from 0.9 percent to 1.5 percent.
<G-vec00298-002-s019><increase.ansteigen><de> Sobald Ihr Rang und Ihre Aktivität ansteigen, erhalten Sie Zugriff auf die Trading-Informationen von Mitgliedern des nächsthöheren Niveaus.
<G-vec00298-002-s019><increase.ansteigen><en> As your rank and activity increase, you will access information of better and more active traders.
<G-vec00298-002-s020><increase.ansteigen><de> Dagegen wird die Bevölkerung Afrikas und Asiens in den nächsten Jahrzehnten weiter stark ansteigen, wobei insbesondere in Afrika ein drastischer Bevölkerungsanstieg zu erwarten ist (siehe Grafik).
<G-vec00298-002-s020><increase.ansteigen><en> The populations of Africa and Asia will continue to increase significantly – and dramatically so in Africa – over the next few decades (chart).
<G-vec00298-002-s021><increase.ansteigen><de> Neben dem Geschlecht und dem Alter lassen berufliche und umweltbedingte Faktoren, körperliche und psychische Belastungen, Stress, Ernährungsgewohnheiten, Schwangerschaft, Stillzeiten, Krankheiten, Medikamente, darunter die Anti-Baby-Pille, Nikotin und Alkohol den Vitaminbedarf ansteigen.
<G-vec00298-002-s021><increase.ansteigen><en> Besides gender and age, occupational and environmental factors, physical and mental pressures, stress, diet, pregnancy, breastfeeding, illnesses, drugs including the birth control pill, nicotine and alcohol can also increase the vitamin requirements of the body.
<G-vec00298-002-s022><increase.ansteigen><de> Bis 2030 wird diese Zahl über 25 % ansteigen.
<G-vec00298-002-s022><increase.ansteigen><en> By 2030, that number will increase by nearly 50% (46%)4.
<G-vec00298-002-s023><increase.ansteigen><de> Es ist zu erwarten, dass Armut und Hunger sprunghaft ansteigen werden.
<G-vec00298-002-s023><increase.ansteigen><en> It is to be expected that poverty and hunger will increase sharply.
<G-vec00298-002-s024><increase.ansteigen><de> Die Unterzeichnung des Freihandelsabkommens der Europäischen Freihandelsassoziation (European Free Trade Association, EFTA) mit Singapur im Jahr 2003 – das erste mit einem asiatischen Land – ließ den Handel zwischen der Schweiz und Singapur sprunghaft ansteigen.
<G-vec00298-002-s024><increase.ansteigen><en> The signing of the European Free Trade Association with Singapore in 2003 – the first with an Asian country – caused a sharp increase in trade between the two countries.
<G-vec00298-002-s025><increase.ansteigen><de> Man kann davon ausgehen, dass der Markt f√ľr VRF Systeme weiter schnell ansteigen wird.
<G-vec00298-002-s025><increase.ansteigen><en> It is expected that the market value of VRF systems will continue to increase rapidly.
<G-vec00298-002-s026><increase.ansteigen><de> Bis Ende 2007 wird die Produktionskapazität durch die Fertigstellung der ersten beiden Ausbaustufen der Produktionslinie V auf 432 MWp ansteigen (das entspricht einer Nominalkapazität von 540 MWp).
<G-vec00298-002-s026><increase.ansteigen><en> By the end of 2007, production capacity is expected to increase to 432 MWp (corresponding to a nominal capacity of 540 MWp) based on completion of the first two stages of production line V.
<G-vec00298-002-s027><increase.ansteigen><de> Beim reduzierten Material wurde eine weitere Analyse durchgeführt, um eine Zeit-Extraktionskurve zu generieren, die zeigt, dass die Auflösung des Lithiums relativ schnell vonstatten geht und in der ersten Stunde 50 % erreicht; auch nach vier Stunden kann sie weiter ansteigen.
<G-vec00298-002-s027><increase.ansteigen><en> An additional test was done on the reduced material to generate a time-extraction curve, shown below, which shows dissolution of the lithium is relatively fast, reaching 50% in the first hour, and may continue to increase beyond 4 hours.
<G-vec00298-002-s028><increase.ansteigen><de> Die Erhöhung des Lebensstandards einer ständig wachsenden Weltbevölkerung wird den weltweiten Energieverbrauch in den nächsten 25 Jahren dramatisch ansteigen lassen.
<G-vec00298-002-s028><increase.ansteigen><en> Rising living standards of a growing world population will cause global energy consumption to increase dramatically over the next half century.
<G-vec00298-002-s029><increase.ansteigen><de> Die Herzfrequenz kann in der Sauna auf bis zu 150 Schläge pro Minute ansteigen, sodass sich Saunagänger unmittelbar nach dem Saunabesuch nicht notwendigerweise müde fühlen müssen.
<G-vec00298-002-s029><increase.ansteigen><en> In the sauna, the heart rate may increase to up to 150 beats per minute, so sauna goers may not necessarily feel sleepy immediately afterwards.
<G-vec00298-002-s030><increase.ansteigen><de> Ab dem ersten Januar 2016 wird der Leaders Guild-Beitrag von 30$ auf 36$ ansteigen.
<G-vec00298-002-s030><increase.ansteigen><en> Beginning January 1, 2016 Leaders Guild fees will increase from $30 to $36.
<G-vec00298-002-s031><increase.ansteigen><de> Glaukom — Das ist ein Ansteigen des Augendrucks, der Blindheit verursachen kann.
<G-vec00298-002-s031><increase.ansteigen><en> Glaucoma — An increase in eye pressure that can cause blindness.
<G-vec00298-002-s032><increase.ansteigen><de> Wenn wir nicht bald den enormen Mengen an Kohlendioxide (CO2), die ausgeleitet werden, Einhalt gebieten, wird die globale Durchschnittstemperatur ansteigen mit Konsequenzen für Natur, Tierwelt und Menschen zu Folge.
<G-vec00298-002-s032><increase.ansteigen><en> If we not put a stop to the vast amounts of CO2 emitted a great increase in the global average temperature will occur with severe consequences for both nature, animals and humans.
<G-vec00298-002-s033><increase.ansteigen><de> Die Dauer eines Tagesschlafs wird wahrscheinlich leicht ansteigen.
<G-vec00298-002-s033><increase.ansteigen><en> The duration of a day's sleep is likely to increase slightly.
<G-vec00298-002-s034><increase.ansteigen><de> Es ist sehr wahrscheinlich, dass die Temperaturen stark ansteigen werden, der Niederschlag unzuverlässiger wird und generell die Variabilität zwischen den Jahreszeiten zunehmen wird.
<G-vec00298-002-s034><increase.ansteigen><en> It is very likely that it could be affected by strong increase in temperature, a less reliable precipitation, and generally increased intra-seasonal variability.
<G-vec00298-002-s035><increase.ansteigen><de> Der Studienverlauf folgt einem Konzept, nach dem einerseits die fachwissenschaftlichen Themen systematisch aufgebaut und vermittelt werden, andererseits mit zunehmender Studiendauer die Spezialisierungen und die praktischen Anteile ansteigen.
<G-vec00298-002-s035><increase.ansteigen><en> The course of study follows a concept in which the one hand, the scientific topics fold be established systematically and provides, on the other hand, with increasing duration of study specializations and practical proportions increase.
<G-vec00298-002-s036><increase.ansteigen><de> Die Weltbevölkerung musst enorm ansteigen, um die Übernahme der Dunklen zu verhindern.
<G-vec00298-002-s036><increase.ansteigen><en> The population of the Earth had to increase enormously to prevent the dark takeover.
<G-vec00298-002-s037><increase.ansteigen><de> Bei sich ständig ändernden Wechselkursen können die Auswirkungen der Wechselkursschwankungen dazu führen, dass die Kosten für Ihre Immobilie im Ausland plötzlich ansteigen.
<G-vec00298-002-s037><increase.ansteigen><en> With exchange rates always on the move, the impact of rate movements can lead to a sudden increase in the cost of your overseas property.
