<G-vec00197-001-s033><devise.ausdenken><de> Sie selbst wird die Schemata, die Pläne und die Methoden liefern, die besser sind als alles, was wir uns ausdenken können.
<G-vec00197-001-s033><devise.ausdenken><en> She herself will provide the schemes, the plans, the methods better than any we can devise.
<G-vec00197-001-s024><invent.ausdenken><de> Hier können Sie wirklich kreativ werden und sich Ihre eigenen Aktionsformen ausdenken.
<G-vec00197-001-s024><invent.ausdenken><en> You can get creative and invent your own form of protest.
<G-vec00197-001-s025><invent.ausdenken><de> In den Ästen der Bäume stecken Geschichten, die wir sehen, und andere, die wir uns ausdenken.
<G-vec00197-001-s025><invent.ausdenken><en> Hidden among the tree branches are the stories we see, and those we invent.
<G-vec00197-001-s026><invent.ausdenken><de> Nicht durch die Worte, die wir sagen, nicht durch die Antworten, die wir uns ausdenken.
<G-vec00197-001-s026><invent.ausdenken><en> Not by the words we speak, not by the answers we invent ourselves: «by whose warmth».
<G-vec00197-001-s027><invent.ausdenken><de> Und wenn das geschieht, muss man sich nichts anderes mehr ausdenken.
<G-vec00197-001-s027><invent.ausdenken><en> And when that happens, one doesn’t need to invent anything else.
<G-vec00197-001-s036><devise.ausdenken><de> Die vier sind Räuber und Big F hatte viel Zeit, sich den perfekten Plan auszudenken.
<G-vec00197-001-s036><devise.ausdenken><en> The four are robbers and Big F had a lot of time to devise the perfect plan.
<G-vec00197-001-s037><devise.ausdenken><de> Kontaktieren Sie uns und wir versuchen Programm nach Ihren Vorstellungen auszudenken und vorzubereiten.
<G-vec00197-001-s037><devise.ausdenken><en> Contact us and we will try to devise and prepare your imaginative programme.
<G-vec00197-001-s028><invent.ausdenken><de> Sich ein möglichst gutes Experiment auszudenken, das dann die Studentengruppe auf dem Parabelflug selbst durchführen darf.
<G-vec00197-001-s028><invent.ausdenken><en> To invent an experiment that is as good as possible, which the students then are allowed to perform on the parabolic flight by themselves.
<G-vec00197-001-s029><invent.ausdenken><de> "Und die gegnerischen Webbs hatten keinen Grund, sich die Vorstellung einer ""Siegelung"" auszudenken, wenn sie Fanny zu einen Fall von bloßem Ehebruch hätten machen können."
<G-vec00197-001-s029><invent.ausdenken><en> "And, the hostile Webbs had no reason to invent a ""sealing"" idea if they could have made Fanny into a mere case of adultery."
<G-vec00197-001-s030><invent.ausdenken><de> Wir brauchen uns nichts anderes auszudenken, wir sind bereits dieses Werkzeug, das wirksam sein kann, vorausgesetzt, dass wir Träger dessen werden, was ich an anderer Stelle bereits die Revolution der Zärtlichkeit genannt habe.
<G-vec00197-001-s030><invent.ausdenken><en> We need not invent another; we ourselves are already this instrument that can be effective provided that we become subject to what I have elsewhere previously called the revolution of tenderness.
