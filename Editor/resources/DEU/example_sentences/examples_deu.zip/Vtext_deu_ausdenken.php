<G-vec00197-001-s033><devise.ausdenken><de> Sie selbst wird die Schemata, die Pläne und die Methoden liefern, die besser sind als alles, was wir uns ausdenken können.
<G-vec00197-001-s033><devise.ausdenken><en> She herself will provide the schemes, the plans, the methods better than any we can devise.
<G-vec00197-001-s024><invent.ausdenken><de> Hier können Sie wirklich kreativ werden und sich Ihre eigenen Aktionsformen ausdenken.
<G-vec00197-001-s024><invent.ausdenken><en> You can get creative and invent your own form of protest.
<G-vec00197-001-s025><invent.ausdenken><de> In den Ästen der Bäume stecken Geschichten, die wir sehen, und andere, die wir uns ausdenken.
<G-vec00197-001-s025><invent.ausdenken><en> Hidden among the tree branches are the stories we see, and those we invent.
<G-vec00197-001-s026><invent.ausdenken><de> Nicht durch die Worte, die wir sagen, nicht durch die Antworten, die wir uns ausdenken.
<G-vec00197-001-s026><invent.ausdenken><en> Not by the words we speak, not by the answers we invent ourselves: «by whose warmth».
<G-vec00197-001-s027><invent.ausdenken><de> Und wenn das geschieht, muss man sich nichts anderes mehr ausdenken.
<G-vec00197-001-s027><invent.ausdenken><en> And when that happens, one doesn’t need to invent anything else.
<G-vec00197-001-s036><devise.ausdenken><de> Die vier sind Räuber und Big F hatte viel Zeit, sich den perfekten Plan auszudenken.
<G-vec00197-001-s036><devise.ausdenken><en> The four are robbers and Big F had a lot of time to devise the perfect plan.
<G-vec00197-001-s037><devise.ausdenken><de> Kontaktieren Sie uns und wir versuchen Programm nach Ihren Vorstellungen auszudenken und vorzubereiten.
<G-vec00197-001-s037><devise.ausdenken><en> Contact us and we will try to devise and prepare your imaginative programme.
<G-vec00197-001-s028><invent.ausdenken><de> Sich ein möglichst gutes Experiment auszudenken, das dann die Studentengruppe auf dem Parabelflug selbst durchführen darf.
<G-vec00197-001-s028><invent.ausdenken><en> To invent an experiment that is as good as possible, which the students then are allowed to perform on the parabolic flight by themselves.
<G-vec00197-001-s029><invent.ausdenken><de> "Und die gegnerischen Webbs hatten keinen Grund, sich die Vorstellung einer ""Siegelung"" auszudenken, wenn sie Fanny zu einen Fall von bloßem Ehebruch hätten machen können."
<G-vec00197-001-s029><invent.ausdenken><en> "And, the hostile Webbs had no reason to invent a ""sealing"" idea if they could have made Fanny into a mere case of adultery."
<G-vec00197-001-s030><invent.ausdenken><de> Wir brauchen uns nichts anderes auszudenken, wir sind bereits dieses Werkzeug, das wirksam sein kann, vorausgesetzt, dass wir Träger dessen werden, was ich an anderer Stelle bereits die Revolution der Zärtlichkeit genannt habe.
<G-vec00197-001-s030><invent.ausdenken><en> We need not invent another; we ourselves are already this instrument that can be effective provided that we become subject to what I have elsewhere previously called the revolution of tenderness.
<G-vec00402-002-s029><conceive.ausdenken><de> Machtgierig, so egowahnsinnig hohl waren sie bereit, alles zu tun, was sie in ihren verworfenen Phantasien ausdenken konnten, um ihre Macht zu behalten und dem Tag der Abrechnung zuvor zu kommen.
<G-vec00402-002-s029><conceive.ausdenken><en> Power greedy, so ego-maniacally hollow, they were willing to do anything at all their warped imaginations could conceive of to maintain their power and forestall the day of reckoning.
<G-vec00402-002-s030><conceive.ausdenken><de> Und doch hatte sie schon mehr erlebt, als sich irgendein moderner Autor für seine Romanheldin ausdenken könnte.
<G-vec00402-002-s030><conceive.ausdenken><en> And yet, she had experienced more at this young age than a modern writer could possibly conceive of for a heroine in his book.
<G-vec00402-002-s031><conceive.ausdenken><de> Letztlich funktioniert aber keine Form richtig gut, so dass wir uns immer wieder neue Formen ausdenken.
<G-vec00402-002-s031><conceive.ausdenken><en> Finally however there was no form that functioned really well, which means we always have to conceive of new forms.
<G-vec00040-002-s028><devise.ausdenken><de> Wenn wir uns daran zurückzuerinnern versuchen, was die Aufgabe vor dreißig Jahren war, dann können wir soetwas antworten wie: „Ob wir für die ungarische Nation, für eine tausendjährige Gemeinschaft, die für ihr Bestehenbleiben in der modernen Zeit notwendige neue Lebensform finden werden, oder wenn es diese nicht geben sollte, wir diese werden ausdenken können?“ Dies war eine sehr schwere und peinigende Frage.
<G-vec00040-002-s028><devise.ausdenken><en> If we try to recall what the task was thirty years ago,we can say that it was something like the following question: Can we discover – or if it doesn’t already exist, can we devise – a new way of life needed for the 1,000-year-old community that is the Hungarian nation to be able to survive in the modern age? This was a very difficult, agonising question.
<G-vec00040-002-s029><devise.ausdenken><de> Die Art und Weise Gottes geht weit über alles hinaus, was der menschliche Geist sich ausdenken oder erträumen kann.
<G-vec00040-002-s029><devise.ausdenken><en> The way of God is far beyond anything the human mind can devise or dream about.
<G-vec00040-002-s030><devise.ausdenken><de> (Wendell Willkie sagte) "Zwei Millionen Menschen, nur weil sie Juden sind, wurden bereits auf jede feindselige Weise, die sich Hitler ausdenken konnte, ermordet, Millionen anderer Juden... stehen unmittelbar vor ihrer Vernichtung..."...
<G-vec00040-002-s030><devise.ausdenken><en> [...Wendell Wilkie said] 'Two million human beings, merely because they are Jews, have already been murdered by every fiendish means which Hitler could devise. Millions of other Jews [...] face immediate destruction [...]'
<G-vec00040-002-s024><invent.ausdenken><de> Wir glauben, dass ReimaGO® helfen kann: Die App belohnt Kinder dafür, dass sie aktiv sind, und Eltern können sich außerdem zusätzliche Belohnungen ausdenken.
<G-vec00040-002-s024><invent.ausdenken><en> We believe ReimaGO® can help: The app will reward kids for being active, and parents can even invent additional rewards.
<G-vec00040-002-s187><invent.ausdenken><de> Ich dachte, es kann ja nicht schaden, sich mal was Neues auszudenken.
<G-vec00040-002-s187><invent.ausdenken><en> thought, it won't hurt, to invent something new.
