<G-vec00097-001-s011><erupt.ausbrechen><de> All die Pyrotechnik am Fourth of July zusammengenommen kann es nicht mit der explosiven Kraft aufnehmen, mit der diese Esten ausbrechen, wenn sie einstimmig singen.
<G-vec00097-001-s011><erupt.ausbrechen><en> All the pyrotechnics on The Fourth of July put together can't match the explosive power these Estonians erupt with when they sing in unison.
<G-vec00097-001-s015><erupt.ausbrechen><de> Der Vater sagt: „All eure Krankheiten werden ausbrechen.
<G-vec00097-001-s015><erupt.ausbrechen><en> The Father says: All your sickness will erupt.
<G-vec00097-001-s016><erupt.ausbrechen><de> Die Empörung gegen Zia ul-Huq und gleichzeitig die Symphatiebekundung für Chomeini könnten aber in Pakistan auch ohne die Intervention der Sowjets ausbrechen.
<G-vec00097-001-s016><erupt.ausbrechen><en> However, in Pakistan the anger against Zia-ul-Haq, accompanied by sympathy for Khomeini, might erupt even without the intervention of the Soviets.
<G-vec00097-001-s017><erupt.ausbrechen><de> Sakurajima: Yunohira LookoutDer Aufstieg zum Sakurajimagipfel ist streng verboten, weil der Vulkan jederzeit ausbrechen kann.
<G-vec00097-001-s017><erupt.ausbrechen><en> Sakurajima: Yunohira LookoutThe ascent to Sakurajima top is strictly forbidden, since the volcano may always erupt with strong blasts.
<G-vec00097-001-s018><erupt.ausbrechen><de> 4., Januar 2010 zwei neue Öffnungen, die später in eine Spalte zusammengeführt entlang der tektonischen Trend des Gipfelbereichs eröffnete seine westlichen Krater ausgerichtet und damit begonnen, große Mengen an Schwefeldioxid und gelegentliche Felsmaterial Asche ausbrechen.
<G-vec00097-001-s018><erupt.ausbrechen><en> On Jan 4, 2010, two new vents that later merged into a fissure aligned along the tectonic trend of the summit area opened in its western crater and started to erupt large amounts of sulphur dioxide gas and occasional lithic ash.
<G-vec00097-001-s019><erupt.ausbrechen><de> Allerdings sollten die Zähne richtig und vollständig ausbrechen.
<G-vec00097-001-s019><erupt.ausbrechen><en> However, the teeth should erupt properly and fully.
<G-vec00097-001-s020><erupt.ausbrechen><de> Angst kommt von Enge und wirkt wie ein explosiver Bodensatz, der jederzeit als Wut, Haß, Eifersucht, Sadismus und nackte Gewalt ausbrechen kann.
<G-vec00097-001-s020><erupt.ausbrechen><en> Fear comes from constriction and acts like an explosive residue which can erupt at any time as anger, hatred, jealousy, sadism and unconcealed violence.
<G-vec00097-001-s021><erupt.ausbrechen><de> Nord-Amerika zieht diagonal, eine Situation, die bald ausbrechen wird, was Beben und sinkenden Boden und Desaster in fast jedem Unionsstaat (US-Bundesstaat) kreiert.
<G-vec00097-001-s021><erupt.ausbrechen><en> N America pulls diagonally, a situation that will soon erupt creating quakes and sinking ground and disaster in almost every State of the Union.
<G-vec00097-001-s022><erupt.ausbrechen><de> Der erste Zahn Ihres Babys kann als einer ausbrechen oder mit einem anderen gepaart werden.
<G-vec00097-001-s022><erupt.ausbrechen><en> The first tooth of your baby can erupt as one, or paired with another.
<G-vec00097-001-s023><erupt.ausbrechen><de> Wir dürfen nicht passiv warten, bis Krisen ausbrechen, sondern müssen die Ursachen für politische Gewalt bei den Wurzeln angehen.
<G-vec00097-001-s023><erupt.ausbrechen><en> We must not wait passively for crises to erupt, but tackle the root causes of political violence.
<G-vec00097-001-s024><erupt.ausbrechen><de> Dabei dient Flamenco ihnen als Ausgangspunkt, von dem sie in Jazz, Fusion und Weltmusik ausbrechen.
<G-vec00097-001-s024><erupt.ausbrechen><en> Flamenco serves as their base, from which they erupt into jazz, fusion and world music.
<G-vec00097-001-s025><erupt.ausbrechen><de> Wenn wir erst einmal CMEs verstanden haben, können wir anfangen, Vorhersagen darüber zu treffen, welche magnetischen Strukturen ausbrechen und welche schließlich den größten Effekt auf der Erde hervorrufen.
<G-vec00097-001-s025><erupt.ausbrechen><en> Once we understand why CMEs occur, we can start to predict which magnetic structures will erupt and eventually which ones will have the greatest effect on Earth.
<G-vec00097-001-s026><erupt.ausbrechen><de> Wir können nicht genau wissen, wo und in welcher Form die neuen sozialen Konflikte ausbrechen werden, ob sie sich als dauerhaft erweisen und verallgemeinern werden.
<G-vec00097-001-s026><erupt.ausbrechen><en> We can't know exactly where these new social conflicts will erupt, or in what form; whether they will take hold and become generalised.
<G-vec00097-001-s027><erupt.ausbrechen><de> Es kann also ein Cialis Cost 20mg und ein Öl vorher ausbrechen und die Ergebnisse ablenken.
<G-vec00097-001-s027><erupt.ausbrechen><en> So it may erupt a Cialis Cost 20mg and a oil before and distract out the results.
<G-vec00097-001-s028><erupt.ausbrechen><de> Die böse Meere ausbrechen in diesem gewaltigen Sturm Blitze.
<G-vec00097-001-s028><erupt.ausbrechen><en> The angry seas erupt in this formidable Lightning Storm.
<G-vec00097-001-s029><erupt.ausbrechen><de> Weisheitszahn fängt an, ausbrechen oder am Ende der Adoleszenz, oder nach 20 Jahren.Zu diesem Zeitpunkt erfährt eine Person, die Schmerzempfindung, die unerträglich werden kann.Also nicht wider Besuch beim Zahnarzt - finden Sie es bei den erst...
<G-vec00097-001-s029><erupt.ausbrechen><en> wisdom tooth begins to erupt or at the end of adolescence, or after 20 years.At this time a person experiences the sensation of pain, which can become unbearable.So do not resist visiting the dentist - refer to it at the first sign of pain.An...
<G-vec00097-001-s030><erupt.ausbrechen><de> Bagana weiterhin kleine Asche Explosionen von Zeit zu Zeit ausbrechen produzieren Asche Federn, die 2.4-3 km Höhe steigen und werden von der Darwin-VAAC überwacht.
<G-vec00097-001-s030><erupt.ausbrechen><en> Bagana continues to erupt small ash explosions from time to time, producing ash plumes that rise to 2.4-3 km altitude and are monitored by the Darwin VAAC.
<G-vec00097-001-s031><erupt.ausbrechen><de> Zwei dieser Kegel, Mawenzi und Shira, sind nicht mehr aktiv und gelten nach wissenschaftlichen Erkenntnissen als erloschen, während der höchste, Kibo, inaktiv ist und noch einmal ausbrechen könnte.
<G-vec00097-001-s031><erupt.ausbrechen><en> Two of these cones, the Mawenzi and Shira, are no longer active and are scientifically proven to be extinct, while the highest one, Kibo, is dormant and might erupt once.
<G-vec00097-001-s032><erupt.ausbrechen><de> Akne ist eine infektiöse entzündliche Hauterkrankung, die zuerst während Teenager ausbricht und kann weiterhin jahrelang sogar im Erwachsenenalter ausbrechen.
<G-vec00097-001-s032><erupt.ausbrechen><en> Acne is an infectious inflammatory skin condition that first erupts during teenage and may continue to erupt for years even during adulthood.
<G-vec00097-001-s033><erupt.ausbrechen><de> Diese Seite zeigt heisse Quellen, die (normalerweise) nicht ausbrechen.
<G-vec00097-001-s033><erupt.ausbrechen><en> This page is about the beauty of hot springs which do not (usually) erupt.
<G-vec00097-001-s034><erupt.ausbrechen><de> Niemand kann in die Zukunft sehen und vorhersagen, wann und wo welche Krise ausbricht.
<G-vec00097-001-s034><erupt.ausbrechen><en> No one can see into the future; no one can predict what crises will erupt when and where.
<G-vec00097-001-s035><erupt.ausbrechen><de> Je nachdem, wie lange wir darauf warten mussten, dass der Old Faithful ausbricht, ergibt sich vielleicht die Möglichkeit zu einem kurzen Rundgang um das Upper Geyser Basin.
<G-vec00097-001-s035><erupt.ausbrechen><en> Depending on how long we had to wait for Old Faithful to erupt, there may possibly be an opportunity for a short walk around the Upper Geyser Basin.
<G-vec00097-001-s036><erupt.ausbrechen><de> Das Establishment weiß, er ist da, aber sie fürchten das Chaos, das ausbricht, wenn es die Massen erfahren.
<G-vec00097-001-s036><erupt.ausbrechen><en> The establishment knows it is there but fears the chaos that will erupt if the populace knows.
<G-vec00097-001-s041><erupt.ausbrechen><de> Die Leidenschaft, die endlich ausgebrochen war.
<G-vec00097-001-s041><erupt.ausbrechen><en> The passion that was finally able to erupt.
<G-vec00097-001-s042><erupt.ausbrechen><de> In diesem Straßendschungel brodelt ein Vulkan, der kurz davor ist auszubrechen.
<G-vec00097-001-s042><erupt.ausbrechen><en> In this street jungle a volcano is seething that is about to erupt any moment.
<G-vec00097-001-s043><erupt.ausbrechen><de> Nur die Hitlerschen Narren können nicht begreifen, dass nicht nur das europäische Hinterland, sondern auch das deutsche Hinterland der deutschen Truppen einen Vulkan darstellt, bereit auszubrechen und die Hitlerschen Abenteurer zu begraben.
<G-vec00097-001-s043><erupt.ausbrechen><en> Only the Hitlerite fools fail to understand that not only the European rear but also the German rear of the German troops represents a volcano which is ready to erupt and overwhelm the Hitlerite adventurers.
<G-vec00097-001-s044><erupt.ausbrechen><de> Seine Software macht coole Grafiken und wenn Unterbrechungen auszubrechen, den letzten Spin ist abgeschlossen, und Sie können ganz einfach überprüfen die Geschichte.
<G-vec00097-001-s044><erupt.ausbrechen><en> Its software renders cool graphics and when disconnections erupt, the last spin is completed and you can easily check the history.
<G-vec00097-001-s045><erupt.ausbrechen><de> Plötzlich schien die Welt auszubrechen, mit einem enormen Getöse und einem strahlenden Lichtblitz, so hell wie die Sonne.
<G-vec00097-001-s045><erupt.ausbrechen><en> Suddenly, the world seemed to erupt with a tremendous roar and a brilliant flash of light, bright as the sun.
<G-vec00097-001-s049><erupt.ausbrechen><de> Kontroversen über Halal-Essen brechen in Kantinen aus, über Gebete auf öffentlichen Straßen, während Karikaturen regelmäßig den Islam verspotten.
<G-vec00097-001-s049><erupt.ausbrechen><en> Disputes erupt over Halal foods in cafeterias, prayers in the street, while cartoons regularly lampoon Islam.
<G-vec00097-001-s050><erupt.ausbrechen><de> Auf der Erde brechen immer noch Vulkane aus und es ist selbstverständlich, dass ähnliche Aktivitäten auf dem Mond erwartet werden.
<G-vec00097-001-s050><erupt.ausbrechen><en> Volcanoes still erupt on the Earth, and it is natural to expect similar activity on the moon.
<G-vec00097-001-s051><erupt.ausbrechen><de> Wo Affen Ihre Balkonsäulen klettern, als ob sie Bäume waren, nisten sich in den Ecken der Korridore, als wären sie Klippen, Granitfelsen brechen in die gewundenen weißen Gehwege aus.
<G-vec00097-001-s051><erupt.ausbrechen><en> Where monkeys climb your balcony pillars as if they were trees, swifts nest in the corners of corridors as if they were cliffs, granite crags erupt into the sinuous white walkways.
<G-vec00097-001-s052><erupt.ausbrechen><de> Die beiden Vulkane Katla und Hekla brechen aus und gefährden den Erfolg der Reise.
<G-vec00097-001-s052><erupt.ausbrechen><en> When the twin volcanos Katla and Hekla erupt, the success of the voyage hangs in the balance.
<G-vec00097-001-s053><erupt.ausbrechen><de> Blasen brechen aus und hinterlassen an ihrer Stelle Erosion.
<G-vec00097-001-s053><erupt.ausbrechen><en> Bubbles erupt, leaving in their place erosion.
<G-vec00097-001-s067><erupt.ausbrechen><de> "Der Zweck der ""Black History"" ist die Weiße in ihren historischen Schuld zu erinnern und von Natur aus verhaßt Verhalten droht erneut ausbrechen zu jeder Zeit."
<G-vec00097-001-s067><erupt.ausbrechen><en> "The purpose of ""black history"" is to remind whites of their historical guilt and their innately hateful behavior threatening to re-erupt at any time."
<G-vec00097-001-s082><erupt.ausbrechen><de> Sie können nicht anders, sie müssen immer wieder in die Anbetung des heiligen Gottes ausbrechen.
<G-vec00097-001-s082><erupt.ausbrechen><en> They have no choice but to erupt again and again with worshiping of the holy God.
<G-vec00097-001-s092><erupt.ausbrechen><de> Die berechtigte Wut der Tamilen über die seit Jahrzehnten fest verwurzelte Diskriminierung wird unweigerlich in neuen Formen wieder ausbrechen.
<G-vec00097-001-s092><erupt.ausbrechen><en> The legitimate grievances and anger felt by Tamils over decades of entrenched discrimination will inevitably erupt in new forms.
<G-vec00218-002-s095><break.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00218-002-s095><break.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00218-002-s096><break.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00218-002-s096><break.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00218-002-s097><break.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00218-002-s097><break.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00218-002-s098><break.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00218-002-s098><break.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00218-002-s099><break.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00218-002-s099><break.ausbrechen><en> He could not break free
<G-vec00218-002-s100><break.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00218-002-s100><break.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00218-002-s101><break.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00218-002-s101><break.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00218-002-s102><break.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00218-002-s102><break.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00218-002-s103><break.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00218-002-s103><break.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00218-002-s104><break.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00218-002-s104><break.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00218-002-s105><break.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00218-002-s105><break.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00218-002-s106><break.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00218-002-s106><break.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00218-002-s107><break.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00218-002-s107><break.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00218-002-s108><break.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00218-002-s108><break.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00218-002-s109><break.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00218-002-s109><break.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00218-002-s110><break.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00218-002-s110><break.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00218-002-s111><break.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00218-002-s111><break.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00218-002-s112><break.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00218-002-s112><break.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00218-002-s113><break.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00218-002-s113><break.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00296-003-s095><break_down.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00296-003-s095><break_down.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00296-003-s096><break_down.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00296-003-s096><break_down.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00296-003-s097><break_down.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00296-003-s097><break_down.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00296-003-s098><break_down.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00296-003-s098><break_down.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00296-003-s099><break_down.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00296-003-s099><break_down.ausbrechen><en> He could not break free
<G-vec00296-003-s100><break_down.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00296-003-s100><break_down.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00296-003-s101><break_down.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00296-003-s101><break_down.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00296-003-s102><break_down.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00296-003-s102><break_down.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00296-003-s103><break_down.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00296-003-s103><break_down.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00296-003-s104><break_down.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00296-003-s104><break_down.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00296-003-s105><break_down.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00296-003-s105><break_down.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00296-003-s106><break_down.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00296-003-s106><break_down.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00296-003-s107><break_down.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00296-003-s107><break_down.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00296-003-s108><break_down.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00296-003-s108><break_down.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00296-003-s109><break_down.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00296-003-s109><break_down.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00296-003-s110><break_down.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00296-003-s110><break_down.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00296-003-s111><break_down.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00296-003-s111><break_down.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00296-003-s112><break_down.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00296-003-s112><break_down.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00296-003-s113><break_down.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00296-003-s113><break_down.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00599-002-s095><break_up.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00599-002-s095><break_up.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00599-002-s096><break_up.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00599-002-s096><break_up.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00599-002-s097><break_up.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00599-002-s097><break_up.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00599-002-s098><break_up.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00599-002-s098><break_up.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00599-002-s099><break_up.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00599-002-s099><break_up.ausbrechen><en> He could not break free
<G-vec00599-002-s100><break_up.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00599-002-s100><break_up.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00599-002-s101><break_up.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00599-002-s101><break_up.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00599-002-s102><break_up.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00599-002-s102><break_up.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00599-002-s103><break_up.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00599-002-s103><break_up.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00599-002-s104><break_up.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00599-002-s104><break_up.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00599-002-s105><break_up.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00599-002-s105><break_up.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00599-002-s106><break_up.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00599-002-s106><break_up.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00599-002-s107><break_up.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00599-002-s107><break_up.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00599-002-s108><break_up.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00599-002-s108><break_up.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00599-002-s109><break_up.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00599-002-s109><break_up.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00599-002-s110><break_up.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00599-002-s110><break_up.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00599-002-s111><break_up.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00599-002-s111><break_up.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00599-002-s112><break_up.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00599-002-s112><break_up.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00599-002-s113><break_up.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00599-002-s113><break_up.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
