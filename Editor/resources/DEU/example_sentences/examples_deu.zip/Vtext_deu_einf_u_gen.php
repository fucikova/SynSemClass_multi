<G-vec00407-001-s133><add.einfügen><de> Sobald die Artikel veröffentlicht werden, werden wir die Links hier einfügen.
<G-vec00407-001-s133><add.einfügen><en> As the articles are published we will add links to them from here.
<G-vec00407-001-s134><add.einfügen><de> Die Wertschöpfungskette ist ein Hochmodell, das stellt dar, wie Unternehmen Rohstoffe als Eingabe erhalten, wie Mehrwert für die Rohstoffe durch die verschiedenen Prozesse einfügen, und wie fertige Produkte an Kunden verkaufen.
<G-vec00407-001-s134><add.einfügen><en> Value chain is a high-level model of how businesses receive raw materials as input, add value to the raw materials through various processes, and sell finished products to customers.
<G-vec00407-001-s135><add.einfügen><de> Zu Ihrer Information: Sie können so viele Kategorien erstellen wie Sie möchten, eine Partitur in mehrere Kategorien einfügen und auch die Kategorien in vier Sprachversionen präsentieren.
<G-vec00407-001-s135><add.einfügen><en> Please note: You can create as many categories as you need; add the same score to different categories; present catalogues in other language versions.
<G-vec00407-001-s136><add.einfügen><de> Du solltest keine Nummern in deine Access Liste einfügen, nur weil Du einmal zufällig eine IP Adresse zugewiesen bekommen hast.
<G-vec00407-001-s136><add.einfügen><en> You shouldn't add an IP address to your access list just because one time your hostname appeared as numbers.
<G-vec00407-001-s137><add.einfügen><de> Sie können außerdem eine Bemerkung zu jedem Adressdatensatz in das dafür vorgesehene Textfeld einfügen.
<G-vec00407-001-s137><add.einfügen><en> In addition, you can add remarks to any address in the text box provided for this purpose.
<G-vec00407-001-s138><add.einfügen><de> Einfügen einer GeoMap auf einer Webseite ganz einfach per Drag & Drop.
<G-vec00407-001-s138><add.einfügen><en> Add an Alkacon GeoMap to your website by Drag & Drop.
<G-vec00407-001-s139><add.einfügen><de> Sie können eine beliebige Anzahl von kostenlosen und kostenpflichtigen Plugins, um Ihren Code einfügen.
<G-vec00407-001-s139><add.einfügen><en> You can use any number of free and paid plugins to add your code.
<G-vec00407-001-s140><add.einfügen><de> In einem Topf die Kirschen mit Kerne und den Madeirawein und bis zur vollständige Verdampfung kochen; am Ende, Sherry-Essig einfügen.
<G-vec00407-001-s140><add.einfügen><en> Put the cherries (whole) in a pan together with Madeira wine and boil until the wine evaporates completely; add the sherry vinegar at the end.
<G-vec00407-001-s141><add.einfügen><de> Sie können zum Beispiel Ihre Lieblingstransaktionen in einer geeigneten grafischen Form in das Easy Access Menü einfügen.
<G-vec00407-001-s141><add.einfügen><en> For example, you can add your favourite transactions to the easy access menu in a more graphical form.
<G-vec00407-001-s142><add.einfügen><de> Sie können auch ein Video direkt aus dem E-Mail Ersteller einfügen.
<G-vec00407-001-s142><add.einfügen><en> You can also add a video straight from the email builder.
<G-vec00407-001-s143><add.einfügen><de> Suchen Sie das Dokument das Sie einfügen wollen, und klicken Sie auf den Namen.
<G-vec00407-001-s143><add.einfügen><en> Find the document you would like to add and click on its name.
<G-vec00407-001-s144><add.einfügen><de> Hier können Sie selbst noch die Anzahl der Elemente bearbeiten, in dem Sie auf Einfügen oder Löschen klicken, oder den gesamten Korb ausleeren.
<G-vec00407-001-s144><add.einfügen><en> Here you can edit the number of items by clicking on the item add, or delete or empty the whole basket.
<G-vec00407-001-s145><add.einfügen><de> Wenn Sie einen A/B-Test in eine Kampagne einfügen, müssen Sie mindestens zwei Varianten einer Nachricht erstellen.
<G-vec00407-001-s145><add.einfügen><en> If you add an A/B test to the campaign, you must create at least two versions of the message.
<G-vec00407-001-s146><add.einfügen><de> In die Glossareinträge können Sie wie bei anderen Texten auch Grafiken oder Bilder einfügen.
<G-vec00407-001-s146><add.einfügen><en> You can add graphics or images to glossary entries, as you can to other text.
<G-vec00407-001-s147><add.einfügen><de> Sie können auch den Namen des Absenders einfügen.
<G-vec00407-001-s147><add.einfügen><en> You also can add the name of the sender.
<G-vec00407-001-s148><add.einfügen><de> Darüber hinaus haben Sie Zugriff auf einige Bearbeitungsoptionen zum Ausschneiden von Rahmen, Hinzufügen von Wasserzeichen oder einfügen der Größe und Dauer.
<G-vec00407-001-s148><add.einfügen><en> You’ll also have access to some editing options to cut out frames, add watermarks or add size and duration.
<G-vec00407-001-s149><add.einfügen><de> Erweitert/Hintergrundbild einfügen...
<G-vec00407-001-s149><add.einfügen><en> Advanced/Add picture to the background...
<G-vec00407-001-s150><add.einfügen><de> "So könnten Sie etwa auf allen Seiten, auf denen Sie Fernseher anbieten, das Tag ""TV"" einfügen."
<G-vec00407-001-s150><add.einfügen><en> For example, you could add a “TV” tag on all of the pages where you sell televisions.
<G-vec00407-001-s151><add.einfügen><de> Sie haben eine neue Bestandsimmobilie und möchten diese neu in ihr Portfolio einfügen.
<G-vec00407-001-s151><add.einfügen><en> You have acquired a new facility and whish to add it to your existing portfolio.
<G-vec00499-001-s133><add.einfügen><de> Sobald die Artikel veröffentlicht werden, werden wir die Links hier einfügen.
<G-vec00499-001-s133><add.einfügen><en> As the articles are published we will add links to them from here.
<G-vec00499-001-s134><add.einfügen><de> Die Wertschöpfungskette ist ein Hochmodell, das stellt dar, wie Unternehmen Rohstoffe als Eingabe erhalten, wie Mehrwert für die Rohstoffe durch die verschiedenen Prozesse einfügen, und wie fertige Produkte an Kunden verkaufen.
<G-vec00499-001-s134><add.einfügen><en> Value chain is a high-level model of how businesses receive raw materials as input, add value to the raw materials through various processes, and sell finished products to customers.
<G-vec00499-001-s135><add.einfügen><de> Zu Ihrer Information: Sie können so viele Kategorien erstellen wie Sie möchten, eine Partitur in mehrere Kategorien einfügen und auch die Kategorien in vier Sprachversionen präsentieren.
<G-vec00499-001-s135><add.einfügen><en> Please note: You can create as many categories as you need; add the same score to different categories; present catalogues in other language versions.
<G-vec00499-001-s136><add.einfügen><de> Du solltest keine Nummern in deine Access Liste einfügen, nur weil Du einmal zufällig eine IP Adresse zugewiesen bekommen hast.
<G-vec00499-001-s136><add.einfügen><en> You shouldn't add an IP address to your access list just because one time your hostname appeared as numbers.
<G-vec00499-001-s137><add.einfügen><de> Sie können außerdem eine Bemerkung zu jedem Adressdatensatz in das dafür vorgesehene Textfeld einfügen.
<G-vec00499-001-s137><add.einfügen><en> In addition, you can add remarks to any address in the text box provided for this purpose.
<G-vec00499-001-s138><add.einfügen><de> Einfügen einer GeoMap auf einer Webseite ganz einfach per Drag & Drop.
<G-vec00499-001-s138><add.einfügen><en> Add an Alkacon GeoMap to your website by Drag & Drop.
<G-vec00499-001-s139><add.einfügen><de> Sie können eine beliebige Anzahl von kostenlosen und kostenpflichtigen Plugins, um Ihren Code einfügen.
<G-vec00499-001-s139><add.einfügen><en> You can use any number of free and paid plugins to add your code.
<G-vec00499-001-s140><add.einfügen><de> In einem Topf die Kirschen mit Kerne und den Madeirawein und bis zur vollständige Verdampfung kochen; am Ende, Sherry-Essig einfügen.
<G-vec00499-001-s140><add.einfügen><en> Put the cherries (whole) in a pan together with Madeira wine and boil until the wine evaporates completely; add the sherry vinegar at the end.
<G-vec00499-001-s141><add.einfügen><de> Sie können zum Beispiel Ihre Lieblingstransaktionen in einer geeigneten grafischen Form in das Easy Access Menü einfügen.
<G-vec00499-001-s141><add.einfügen><en> For example, you can add your favourite transactions to the easy access menu in a more graphical form.
<G-vec00499-001-s142><add.einfügen><de> Sie können auch ein Video direkt aus dem E-Mail Ersteller einfügen.
<G-vec00499-001-s142><add.einfügen><en> You can also add a video straight from the email builder.
<G-vec00499-001-s143><add.einfügen><de> Suchen Sie das Dokument das Sie einfügen wollen, und klicken Sie auf den Namen.
<G-vec00499-001-s143><add.einfügen><en> Find the document you would like to add and click on its name.
<G-vec00499-001-s144><add.einfügen><de> Hier können Sie selbst noch die Anzahl der Elemente bearbeiten, in dem Sie auf Einfügen oder Löschen klicken, oder den gesamten Korb ausleeren.
<G-vec00499-001-s144><add.einfügen><en> Here you can edit the number of items by clicking on the item add, or delete or empty the whole basket.
<G-vec00499-001-s145><add.einfügen><de> Wenn Sie einen A/B-Test in eine Kampagne einfügen, müssen Sie mindestens zwei Varianten einer Nachricht erstellen.
<G-vec00499-001-s145><add.einfügen><en> If you add an A/B test to the campaign, you must create at least two versions of the message.
<G-vec00499-001-s146><add.einfügen><de> In die Glossareinträge können Sie wie bei anderen Texten auch Grafiken oder Bilder einfügen.
<G-vec00499-001-s146><add.einfügen><en> You can add graphics or images to glossary entries, as you can to other text.
<G-vec00499-001-s147><add.einfügen><de> Sie können auch den Namen des Absenders einfügen.
<G-vec00499-001-s147><add.einfügen><en> You also can add the name of the sender.
<G-vec00499-001-s148><add.einfügen><de> Darüber hinaus haben Sie Zugriff auf einige Bearbeitungsoptionen zum Ausschneiden von Rahmen, Hinzufügen von Wasserzeichen oder einfügen der Größe und Dauer.
<G-vec00499-001-s148><add.einfügen><en> You’ll also have access to some editing options to cut out frames, add watermarks or add size and duration.
<G-vec00499-001-s149><add.einfügen><de> Erweitert/Hintergrundbild einfügen...
<G-vec00499-001-s149><add.einfügen><en> Advanced/Add picture to the background...
<G-vec00499-001-s150><add.einfügen><de> "So könnten Sie etwa auf allen Seiten, auf denen Sie Fernseher anbieten, das Tag ""TV"" einfügen."
<G-vec00499-001-s150><add.einfügen><en> For example, you could add a “TV” tag on all of the pages where you sell televisions.
<G-vec00499-001-s151><add.einfügen><de> Sie haben eine neue Bestandsimmobilie und möchten diese neu in ihr Portfolio einfügen.
<G-vec00499-001-s151><add.einfügen><en> You have acquired a new facility and whish to add it to your existing portfolio.
<G-vec00407-001-s038><insert.einfügen><de> "Bei Auswahl der Option "" Werteliste verwenden "" können Sie beliebig viele Einträge für die Dropdown-Liste der Auswahlliste sowie für die zugehörigen XML-Werte einfügen, anhängen, bearbeiten und löschen."
<G-vec00407-001-s038><insert.einfügen><en> If you select Use List of Values, you can insert, append, edit, and delete any number of entries for the drop-down list of the combo box as well as for the corresponding XML values.
<G-vec00407-001-s039><insert.einfügen><de> "3. in Gmail Labs suchen und markieren ""Ermöglichen 'to Auswahl Einfügen von Bildern ."
<G-vec00407-001-s039><insert.einfügen><en> "3. In Gmail Labs seek and tick ""Enable "" for Selecting Insert images ."
<G-vec00407-001-s040><insert.einfügen><de> "Klicken Sie auf die ""Bild"" Option im ""Weitere Elemente Einfügen"" im Bedienfeld."
<G-vec00407-001-s040><insert.einfügen><en> "Click on the ""Image"" option in the Insert Additional Elements panel."
<G-vec00407-001-s041><insert.einfügen><de> Sie können wahlweise einen Link für eine neue Skype-Gruppe oder für eine vorhandene Gruppe einfügen.
<G-vec00407-001-s041><insert.einfügen><en> You can choose to insert a link of a new Skype group or insert a link of an existing group.
<G-vec00407-001-s042><insert.einfügen><de> Jetzt klicken Sie auf Dieses Skript einfügen.
<G-vec00407-001-s042><insert.einfügen><en> Now click on Insert this script.
<G-vec00407-001-s043><insert.einfügen><de> Angenommen, Sie haben eine Reihe von Daten, und Sie müssen 2 leere Spalten abwechselnd in alle anderen 2-Spalten einfügen.
<G-vec00407-001-s043><insert.einfügen><en> Supposing you have a range of data, and you need to alternately insert 2 blank columns every other 2 columns.
<G-vec00407-001-s044><insert.einfügen><de> Um die Fragen und Antworten in Zusammenhang zueinander zu bringen, werde ich die entsprechenden Zitate aus dem Buch Die TranceFormation Amerikas von Cathy O'Brien and Mark Phillips einfügen.
<G-vec00407-001-s044><insert.einfügen><en> In order to have the questions and answers in context, I am going to insert the particular quote from Trance Formation of America by Cathy O'Brien and Mark Phillips.
<G-vec00407-001-s045><insert.einfügen><de> Tabs, ist dies einer der beste Weg, um eine große Zahl von Inhalten in einem Minimum an Platz einfügen.
<G-vec00407-001-s045><insert.einfügen><en> Tabs, this is one of the best way to insert a large number of content in a minimum of space.
<G-vec00407-001-s046><insert.einfügen><de> Wenn Sie mehrere tausend Trennzeichen gleichzeitig in eine lange Zahl einfügen möchten, versuchen Sie es mit der folgenden Methode.
<G-vec00407-001-s046><insert.einfügen><en> If you want to insert several thousand separators to a long number at once, please try the following method.
<G-vec00407-001-s047><insert.einfügen><de> Zusätzlich dazu können Sie (durch Rechtsklick in eine Zeile und Anhängen oder Einfügen eines Day -Elements) in der Tabelle unterhalb des Diagramms neue Kursdaten für die beiden Unternehmen eingeben.
<G-vec00407-001-s047><insert.einfügen><en> Furthermore, the table below the chart allows new trading data to be entered for the two companies (right-click in a row and append or insert a Day element).
<G-vec00407-001-s048><insert.einfügen><de> Sie können so viele Aufzählungssymbole wie möglich in die aktive Zelle einfügen.
<G-vec00407-001-s048><insert.einfügen><en> You can insert as many bullet symbols as possible in the active cell.
<G-vec00407-001-s049><insert.einfügen><de> Jedes Kind kann ein zweites Bild einfügen und direkt bearbeiten.
<G-vec00407-001-s049><insert.einfügen><en> Each child may insert a second picture and work on it.
<G-vec00407-001-s050><insert.einfügen><de> "Unter ""Einstellungen → Funktionen"" können Sie jetzt bei ""In aktuelles Bild einfügen"" auswählen, ob das Bild unterhalb (v) oder rechts (>) eingefügt werden soll."
<G-vec00407-001-s050><insert.einfügen><en> "In ""Settings → Functions"" you can select by ""Insert into current image"" whether the image should be inserted below (v) or right (>)."
<G-vec00407-001-s051><insert.einfügen><de> Mit der Tastenkombination Alt + N öffnet sich die Registerkarte „Einfügen“ und jeder Option auf der Taskleiste wird ein Buchstabe zugeordnet.
<G-vec00407-001-s051><insert.einfügen><en> "The keyboard combination ""Alt"" + ""N"" (then choose a letter) opens the Insert tab, and each option on the task bar is assigned a letter."
<G-vec00407-001-s052><insert.einfügen><de> Klicken Sie auf Einfügen, um den Vorgang abzuschließen.
<G-vec00407-001-s052><insert.einfügen><en> § Click Insert to complete the operation.
<G-vec00407-001-s053><insert.einfügen><de> Dann in der Fügen Sie Arbeitsmappeninformationen ein Dialog, überprüfen Sie die Informationen, die Sie einfügen möchten aus Abschnitt Informationen, dann gehen Sie, um den Ort anzugeben, die Sie einfügen möchten, können Sie Zellen, Fußzeile (linke Fußzeile, mittlere Fußzeile, rechte Fußzeile) oder Kopfzeile (linke Kopfzeile, zentrale Kopfzeile, rechte Überschrift).
<G-vec00407-001-s053><insert.einfügen><en> Then in the Insert Workbook Information dialog, check the information you want to insert from Information section, then go to specify the location you want to insert to, you can choose cells, footer (left footer, centre footer, right footer) or header (left header, centre header, right header).
<G-vec00407-001-s054><insert.einfügen><de> Dann in der Fügen Sie Arbeitsmappeninformationen ein Dialog, überprüfen Sie die Informationen, die Sie einfügen möchten aus Abschnitt Informationen, dann gehen Sie, um den Ort anzugeben, die Sie einfügen möchten, können Sie Zellen, Fußzeile (linke Fußzeile, mittlere Fußzeile, rechte Fußzeile) oder Kopfzeile (linke Kopfzeile, zentrale Kopfzeile, rechte Überschrift).
<G-vec00407-001-s054><insert.einfügen><en> Then in the Insert Workbook Information dialog, check the information you want to insert from Information section, then go to specify the location you want to insert to, you can choose cells, footer (left footer, centre footer, right footer) or header (left header, centre header, right header).
<G-vec00407-001-s055><insert.einfügen><de> Neue Aktion zum Einfügen mehrerer Hex oder ASCII Bytes auf einmal, optional wiederholend.
<G-vec00407-001-s055><insert.einfügen><en> Added action to insert multiple Hex or ASCII bytes at once, optionally repeating.
<G-vec00407-001-s056><insert.einfügen><de> Um die Erweiterung hinzuzufügen, melden Sie sich mit CloudSearch mit Facebook oder Google, Holen Sie sich eine integration von code und einfügen, wo Ihr Ecwid store installiert ist.
<G-vec00407-001-s056><insert.einfügen><en> To add the extension, sign up with CloudSearch using Facebook or Google, get an integration code and insert where your Ecwid store is installed.
<G-vec00407-001-s057><insert.einfügen><de> "Spalte einfügen Der Befehl ""Spalte einfügen"" fügt eine Spalte links von der derzeit aktiven Cursorposition in der derzeit aktiven Tabelle ein."
<G-vec00407-001-s057><insert.einfügen><en> "The ""Insert column"" command inserts a column to the left of the current cursor position in the currently active table."
<G-vec00407-001-s058><insert.einfügen><de> "Wählen Sie ""Einfügen"" > ""Kapitel einfügen von"" > ""InDesign-Datei (IDML)"" und wählen Sie dann die Datei aus, die importiert werden soll."
<G-vec00407-001-s058><insert.einfügen><en> Choose Insert Chapter From > InDesign File (IDML), choose the file to import, and click Import.
<G-vec00407-001-s059><insert.einfügen><de> Klicken Sie im Menü Einfügen auf XML-Schema/Datei einfügen .
<G-vec00407-001-s059><insert.einfügen><en> On the Insert menu, click Insert XML Schema/File .
<G-vec00407-001-s060><insert.einfügen><de> Wenn Sie die Arbeitsblatt-Information einfügen möchten, können Sie die Arbeitsblatt-Information in der ersten Zeile jedes Bereichs sowie Formatierung als Kommentarstile einfügen.
<G-vec00407-001-s060><insert.einfügen><en> If you want to insert the worksheet information, you can insert the worksheet information in the first row of each range as well as formatting as comment styles.
<G-vec00407-001-s061><insert.einfügen><de> Im Insert Video von Online-Video-Site Dialogbox, in der YouTube-Code einbetten und klicken Sie auf Einfügen einfügen .
<G-vec00407-001-s061><insert.einfügen><en> In the Insert Video from Online Video Site dialogue box, paste in the YouTube embed code and click Insert.
<G-vec00407-001-s062><insert.einfügen><de> Um die Größe der Bilder mit dem neuem “Drag und Drop” Herausgeber zu verändern, müssen Sie zu aller erst diese herüberziehen und es einfügen, genauso wie im Bilderblock oder klicken Sie auf Bild einfügen.
<G-vec00407-001-s062><insert.einfügen><en> To resize the images in the new Drag and Drop Editor, you would need to first drag and drop and image block or click on insert image.
<G-vec00407-001-s063><insert.einfügen><de> Einfügen oder löschen von Feldern wie zum Beispiel Autor, Dateiname, Pfad, Dateigröße, Einfügen oder Input.
<G-vec00407-001-s063><insert.einfügen><en> Insert, or delete fields like author, file name, path, file size, fill in or input.
<G-vec00407-001-s064><insert.einfügen><de> Wenn Sie nur einige Nachrichten signieren möchten: Schreiben Sie eine Nachricht und wählen Sie dann Am Ende einfügen oder An Cursor Position einfügen unter Mehr (rechts) im Bereich Signatur .
<G-vec00407-001-s064><insert.einfügen><en> If you wish to sign some messages: write the message and then, in More (on the right), choose Insert at bottom or Insert at cursor in the Signature section.
<G-vec00407-001-s065><insert.einfügen><de> Außer den obigen Formeln kann ich hier ein einfaches Tool vorstellenKutools for ExcelMit seinen Datum einfügen Feature, können Sie alle montags oder freitags in einem Monat so schnell wie möglich einfügen.
<G-vec00407-001-s065><insert.einfügen><en> Except the above formulas, here, I can introduce an easy tool-Kutools for Excel, with its Insert Date feature, you can insert all Mondays or Fridays in a month as quickly as you can.
<G-vec00407-001-s066><insert.einfügen><de> Mit den Fügen Sie Arbeitsmappeninformationen ein Nutzen von Kutools for ExcelSie können nicht nur Systemdatum und -uhrzeit in eine bestimmte Zelle einfügen, sondern auch Systemdatum und -uhrzeit in die Kopf- oder Fußzeile des Arbeitsblatts einfügen.
<G-vec00407-001-s066><insert.einfügen><en> With the Insert Workbook Information utility of Kutools for Excel, you can not only insert system date and time into a certain cell, but also insert the system date and time into worksheet's header or footer as you need.
<G-vec00407-001-s067><insert.einfügen><de> Normalerweise können Sie leere Zeilen einfach einfügen, indem Sie Zeilen auswählen, mit der rechten Maustaste klicken und im Kontextmenü in Excel Einfügen auswählen.
<G-vec00407-001-s067><insert.einfügen><en> Normally we can insert blank rows easily by selecting rows, right clicking, and select Insert from the context menu in Excel.
<G-vec00407-001-s068><insert.einfügen><de> Kreis einfügen Alt + O Einen Kreis einfügen.
<G-vec00407-001-s068><insert.einfügen><en> Insert Circle Alt + O Insert a new circle.
<G-vec00407-001-s069><insert.einfügen><de> "Zeile einfügen Der Befehl ""Zeile einfügen"" fügt eine Zeile oberhalb der aktuellen Cursorposition in der derzeit aktiven Tabelle ein."
<G-vec00407-001-s069><insert.einfügen><en> "The ""Insert row"" command inserts a row above the current cursor position in the currently active table."
<G-vec00407-001-s070><insert.einfügen><de> In Word-Dokument können Sie mithilfe der Funktion Einfügen schnell mehrere Bilder gleichzeitig einfügen.
<G-vec00407-001-s070><insert.einfügen><en> In Word document, you can quickly insert multiple pictures at once by using the Insert function.
<G-vec00407-001-s071><insert.einfügen><de> Der VBA-Code kann für unseren Excel-Anfänger etwas schwierig sein, daher empfehle ich Ihnen hier ein praktisches Tool.Kutools for ExcelMit seinen Datei am Cursor einfügen können Sie den gesamten Inhalt eines Arbeitsblatts aus einer geschlossenen Arbeitsmappe schnell und einfach einfügen.
<G-vec00407-001-s071><insert.einfügen><en> The VBA code may be somewhat difficult for our Excel beginner, so, here, I will recommend you a handy tool-Kutools for Excel, with its Insert File at Cursor feature, you can insert the whole content of a worksheet from a closed workbook quickly and easily.
<G-vec00407-001-s072><insert.einfügen><de> Im neuen Popup-Dialog (Kopfzeile or Fußzeile Wählen Sie den Bereich, in den Sie das Logo einfügen möchten, und klicken Sie auf Bild einfügen klicken.
<G-vec00407-001-s072><insert.einfügen><en> In the new popping dialog (Header or Footer dialog), select the section you want to place the logo, then click Insert Picture button.
<G-vec00407-001-s073><insert.einfügen><de> Die Inhalte können Sie über das Zahnradsymbol mit den Optionen Aktuelles Datum einfügen und Aktuelles Datum und Uhrzeit einfügen erweitern.
<G-vec00407-001-s073><insert.einfügen><en> You can expand the content using the Gear icon and the options Insert current date or Insert current date and time.
<G-vec00407-001-s074><insert.einfügen><de> "Nach dem Aufruf der Seite: ""SDA-Archiv generieren"" den Klartext in das obere Fenster eintippen oder besser mit einem Textprogramm vorschreiben und dann per ""Kopieren"" und ""Einfügen"" in das Klartextfenster einfügen (rechte Maus-Taste)."
<G-vec00407-001-s074><insert.einfügen><en> "After click on: ""Create a JavaScript SDA"" type your plaintext into the upper window or better first prepare the text with an Editor program and then ""copy"" and ""insert"" it into the plaintext window (right mouse button)."
<G-vec00407-001-s075><insert.einfügen><de> Sobald die entsprechende Zahl erreicht ist, können Sie mit dem „Zeitprogrammbefehl“>„Zeile einfügen“ in der „Probentabelle“ eine Probenzeile mit den Probendaten für einen Checkstandard einfügen.
<G-vec00407-001-s075><insert.einfügen><en> "As soon as the corresponding number is reached, you can use the ""Time program command"">""Insert new line"" in the ""Sample table"" to insert a sample line with the data of the sample for a check standard."
<G-vec00407-001-s108><insert.einfügen><de> Zum Patchen einer Kernel-Funktion benötigt kGraft etwas Platz am Anfang der Funktion, damit ein Sprung zu einer neuen Funktion eingefügt werden kann.
<G-vec00407-001-s108><insert.einfügen><en> To patch a kernel function, kGraft needs some space at the start of the function to insert a jump to a new function.
<G-vec00407-001-s109><insert.einfügen><de> Zum Beispiel stellt jeder Plasmid-Vektor eine bekannte Anzahl von Restriktionsseiten zur Verfügung, inwelche das DNA Fragment in die multiple Klonierungsstelle eingefügt werden kann.
<G-vec00407-001-s109><insert.einfügen><en> For example, any given plasmid vector, will provide you with a finite number of restriction sites to incorporate the insert via the multiple cloning site.
<G-vec00407-001-s110><insert.einfügen><de> Textbausteine können bei ReplyButler nicht nur statische Texte enthalten sondern auch dynamische Daten aus dem Internet, die passend zur aktuellen E-Mail ermittelt und eingefügt werden.
<G-vec00407-001-s110><insert.einfügen><en> Text modules can do more than insert static text. They can also insert dynamic data from the internet, that was queried for the current e-mail.
<G-vec00407-001-s111><insert.einfügen><de> LABEL_TYPE_STRIPES (2) Es werden Label an drei gedachten vertikalen Linien eingefügt.
<G-vec00407-001-s111><insert.einfügen><en> LABEL_TYPE_STRIPES (2) Label will be insert along three invisible vertical lines.
<G-vec00407-001-s112><insert.einfügen><de> TextWenn die vorhandenen Tabellenzeilen kleiner als die Zeilen sind, die Sie einfügen möchten, können Sie diese Operation wiederholen, bis Sie genügend Zeilen in die Tabelle eingefügt haben.
<G-vec00407-001-s112><insert.einfügen><en> Note: If the existing table rows are less than the rows you want to insert, you can repeat this operation until you insert enough rows into the table.
<G-vec00407-001-s113><insert.einfügen><de> Linientypen können für bestimmte Schutzmaterialien neu erstellt und in Engineering Base eingefügt werden.
<G-vec00407-001-s113><insert.einfügen><en> For certain protection materials, you can create new line styles and insert them in Engineering Base.
<G-vec00407-001-s114><insert.einfügen><de> Öffnet im crossDesk das Fenster, mit dem ein Symbol an die aktuelle Cursor-Position im Target Editor eingefügt werden kann.
<G-vec00407-001-s114><insert.einfügen><en> Opens a window in crossDesk that enables you to insert a symbol at the current cursor position in the Target Editor.
<G-vec00407-001-s115><insert.einfügen><de> Es muss keine Schnittstelle eingefügt werden, es muss nur in der Nähe sein.
<G-vec00407-001-s115><insert.einfügen><en> It doesn't need to insert any interface, it just needs to be close.
<G-vec00407-001-s116><insert.einfügen><de> Es können Synonyme für die Sprache eingefügt, geändert oder gelöscht werden.
<G-vec00407-001-s116><insert.einfügen><en> Insert, modify or remove synonyms for this language.
<G-vec00407-001-s117><insert.einfügen><de> String, in den der Teilstring eingefügt werden soll.
<G-vec00407-001-s117><insert.einfügen><en> String into which to insert substring.
<G-vec00407-001-s118><insert.einfügen><de> In diesem Artikel werde ich darüber sprechen, wie mehrere Aufzählungszeichen in eine Liste von Zellen in Google-Tabelle und Microsoft Excel eingefügt werden.
<G-vec00407-001-s118><insert.einfügen><en> This article, I will talk about how to insert multiple bullet points into a list of cells in Google sheet and Microsoft Excel.
<G-vec00407-001-s119><insert.einfügen><de> 3) Geben Sie einen Ort an, an dem das neue Blatt eingefügt werden soll.
<G-vec00407-001-s119><insert.einfügen><en> 3) Specify a location to insert the new sheet;
<G-vec00407-001-s120><insert.einfügen><de> Drücken Sie F5 Um den Code auszuführen, wird ein Dialogfeld geöffnet, in dem Sie daran erinnert werden, Zellen auszuwählen, in die Kommentare mit ihren Formelergebnissen eingefügt werden sollen.
<G-vec00407-001-s120><insert.einfügen><en> Press F5 key to run the code, a dialog pops out to remind you to select cells you want to insert comments with their formula results.
<G-vec00407-001-s121><insert.einfügen><de> "'*ElternKnoten' (englisch ""ParentNode"") ist der Knoten, in welchen der neue Knoten eingefügt werden soll."
<G-vec00407-001-s121><insert.einfügen><en> '*ParentNode' is the node into which to insert the new node.
<G-vec00407-001-s122><insert.einfügen><de> Mit den Schaltern am unteren Rand bestimmen Sie, aus welcher Spalte der Tabelle der entsprechende Wert bei einem Doppelklick eingefügt wird.
<G-vec00407-001-s122><insert.einfügen><en> With the buttons on the bottom, you can select which column of the table to insert on a double-click.
<G-vec00407-001-s123><insert.einfügen><de> Hier kann ein Kommentartext eingefügt, bearbeitet oder gelöscht werden.
<G-vec00407-001-s123><insert.einfügen><en> This can be used to insert, alter or delete a comment text as wished.
<G-vec00407-001-s124><insert.einfügen><de> Wenn Sie Dateien aus der unteren Liste des Übertragen-Dialogs in das Eingabefeld für die Logmeldung ziehen, werden die Pfadnamen im Klartext in das Eingebafeld eingefügt.
<G-vec00407-001-s124><insert.einfügen><en> Dragging files from the list at the bottom of the commit dialog to the log message edit box will insert the paths as plain text into that edit box.
<G-vec00407-001-s125><insert.einfügen><de> Mit einem Klick in eine Zeile der Spalte Block kann ein Kontextmenü geöffnet werden, über das der Block dupliziert, gelöscht oder eine neue Zeile eingefügt werden soll.
<G-vec00407-001-s125><insert.einfügen><en> Clicking into a row of the column Block, you may open a popup menu enabling you to duplicate, remove, or insert a new line in the block.
<G-vec00407-001-s126><insert.einfügen><de> Wenn auswählen Anzeige leer für ungültige Daten Optional wird ein leerer Barcode eingefügt, wenn ungültige Daten vorliegen.
<G-vec00407-001-s126><insert.einfügen><en> If select Display blank for invalid data option, it will insert a blank barcode when there is invalid data.
<G-vec00407-001-s251><insert.einfügen><de> Ein Mitglied des Vereins shoulds solche Verwendung Karten in die Spielautomaten einzufügen.
<G-vec00407-001-s251><insert.einfügen><en> A member of such club should use cards to insert into the machine à sous machines.
<G-vec00407-001-s252><insert.einfügen><de> Die letzte Option ist die Regulierung Zeichen soll die Zahl der von Ihnen gesuchte Dokument sind einzufügen.
<G-vec00407-001-s252><insert.einfügen><en> The last option regulation sign is intended to insert the number of document you are looking for.
<G-vec00407-001-s253><insert.einfügen><de> Die Dateiinformationen einfügen Nutzen von Kutools for Word kann Ihnen helfen, den Dateinamen oder Pfad eines Dokuments nach Bedarf in die Kopf- oder Fußzeile einzufügen.
<G-vec00407-001-s253><insert.einfügen><en> The Insert File information utility of Kutools for Word can help you easily insert file name or path of a document to header or footer as you need.
<G-vec00407-001-s254><insert.einfügen><de> Es braucht nur wenige Schritte, eine grundlegende Vorlage auszuwählen, und den Text, Bilder und Feinschliff einzufügen.
<G-vec00407-001-s254><insert.einfügen><en> It only takes a few seconds to choose a basic template, insert text and images, and add the finishing touches.
<G-vec00407-001-s255><insert.einfügen><de> Außerdem Trasportounito hat die Unterzeichnung von einem Abkommen von dem unaufschiebbaren Programm vorgeschlagen, als das der politische eindeutige Wille die technischen Details (Referenz jen Produkte von der von der Handelskammer von Genua verwirklicht Studie von der Machbarkeit) in die städtischen Instrumente „einzufügen hat bestätigt“,„Autoparco zu Cornigliano definiert von ein für alle mal“ zu „besitz ergreifen“.
<G-vec00407-001-s255><insert.einfügen><en> Moreover Trasportounito has proposed the subscription of an agreement of intransgressible program “that it confirms the univocal political will to install the car park to Cornigliano once and for all defining some the technical details (having like reference those producing from the study of prefeasibility realized from the Chamber of Commerce of Genoa) to insert in the town-planning instruments”.
<G-vec00407-001-s256><insert.einfügen><de> Text: Im obigen Code können Sie die Nummer ändern 4 zu einer anderen Nummer, um Platz nach einzufügen.
<G-vec00407-001-s256><insert.einfügen><en> Note: In the above code, you can change the number 4 to other number to insert space after.
<G-vec00407-001-s257><insert.einfügen><de> Bestimmen, Schnitt, und erstrecken sich Kanal und einzufügen, Anwendung Kalibrieren Geräte und Handwerkzeuge....
<G-vec00407-001-s257><insert.einfügen><en> Determine, cut, and extend channel and insert, applying calibrating devices and hand-tools ....
<G-vec00407-001-s258><insert.einfügen><de> Ich hatte dieselbe Reaktion gegenüber kürzlichen Berichten, dass ein Newcomer Astronom beschloss dass es Zeit sei ein neues Tierkreiszeichen in den Zodiak einzufügen.
<G-vec00407-001-s258><insert.einfügen><en> I had the same response to recent reports that an up-and-coming astronomer decided it was time to insert a new sign into the Zodiac.
<G-vec00407-001-s259><insert.einfügen><de> Um ein Base64-kodiertes Bild einzufügen, muss das Ergebnis des XPath-Ausdrucks der Eigenschaft Bildquelle der Base64-kodierte Textstring des Bilds sein.
<G-vec00407-001-s259><insert.einfügen><en> To insert a Base64-encoded image, the XPath expression of the Image Source property must resolve to the image's Base64-encoded text string.
<G-vec00407-001-s260><insert.einfügen><de> Die ISOVOLTA Press Fit Tools sind für Druckpressen vorgesehen, die dazu genutzt werden, vormontierte Einpresssteckverbinder in die Löcher einer Platine einzufügen.
<G-vec00407-001-s260><insert.einfügen><en> The ISOVOLTA Press Fit Tools are developed for presses used to insert pre-assembled press-fit connectors into the holes of a printed circuit board.
<G-vec00407-001-s261><insert.einfügen><de> Um einen vollständigen Auftrag einzufügen, ziehen Sie die Auftragsbezeichnung in den Bereich „Seitenansicht“ .
<G-vec00407-001-s261><insert.einfügen><en> To insert an entire job, drag the job label to the Page View pane.
<G-vec00407-001-s262><insert.einfügen><de> Beschreibung: es ermöglicht die Video-Vorschau einzufügen, die aus externen Ressourcen (youtube, vimeo) oder der Webseite (Innere Ressource) hochgeladen wird.
<G-vec00407-001-s262><insert.einfügen><en> Description: used to insert video preview, which can be loaded from the off-site services (youtube, vimeo) or from your website (self hosted).
<G-vec00407-001-s263><insert.einfügen><de> Klicken Sie auf Vorübersetzung speichern, um die Ergebnisse der Vorübersetzung in den Zieltext einzufügen.
<G-vec00407-001-s263><insert.einfügen><en> Click Save Pre-translation to insert the results of the pre-translation in the target text.
<G-vec00407-001-s264><insert.einfügen><de> Um Bilder einzufügen, müssen Sie nur klicken Einfügen | Bilder, die Fotos auswählen, die Sie gerade vorbereitet.
<G-vec00407-001-s264><insert.einfügen><en> To insert pictures, you just need to click Insert | Pictures, select the photos you just prepared.
<G-vec00407-001-s265><insert.einfügen><de> Danach ging das Ganze wieder an die Redaktionskommission zurück, und diese Kommission versuchte, alle Änderungen einzufügen.
<G-vec00407-001-s265><insert.einfügen><en> Then everything went back to the editing commission and that commission tried to insert all of the amendments.
<G-vec00407-001-s266><insert.einfügen><de> Normalerweise können wir Checkbox-Symbole durch Anklicken einfügen Einsatz > Symbole, während es unmöglich erscheint, anklickbare Checkbox-Steuerelemente in eine E-Mail-Nachricht einzufügen.
<G-vec00407-001-s266><insert.einfügen><en> Normally we can insert checkbox symbols by clicking Insert > Symbols, while it seems impossible to insert clickable checkbox controls in an email message.
<G-vec00407-001-s267><insert.einfügen><de> hat die Hafen Autorität präzisiert, dass sie auch im programm eine Aufklärung von den Technikern ist, die, zu das von aus den hafen Räumen, immer ich espletano oder beabsichtigen organisations- und informativen, um im Netz von der Referenz für den Hafen von Genua sie einzufügen Dienste von dem bescheinigt Abwiegen espletare.
<G-vec00407-001-s267><insert.einfügen><en> the Harbour Authority has specified that it is also in program a recognition of the operators whom, always to out of the harbour spaces, they carry out or they intend to carry out services of certifyd weighing so as to insert them in the organizational and informative net of reference for the port of Genoa.
<G-vec00407-001-s268><insert.einfügen><de> BibTex ist ein Syytem, das es dir ermöglicht, Referenzen aus einer (Datei)Datenbank in Texdokumente einzufügen.
<G-vec00407-001-s268><insert.einfügen><en> BibTex is an system which enables you to insert references from a (file) database into Tex documents.
<G-vec00407-001-s269><insert.einfügen><de> Wenn ein View aktualisierbar ist, können INSERT-, UPDATE-, oder DELETE-Operationen in dem View durchgeführt werden, um neue Zeilen in die Basistabelle(n) einzufügen oder vorhandene Zeilen zu löschen oder zu modifizieren.
<G-vec00407-001-s269><insert.einfügen><en> If a view is updatable, INSERT, UPDATE, or DELETE operations can be made on the view to insert new rows into the base table(s), or to modify or delete existing rows.
<G-vec00407-001-s344><insert.einfügen><de> Sobald du deine Retargeting-Anzeige veröffentlichst, fügen wir automatisch einen Facebook-Werbepixel auf der Landingpage ein.
<G-vec00407-001-s344><insert.einfügen><en> We’ll automatically insert a Facebook ad pixel on the landing page when you publish your retargeting ad.
<G-vec00407-001-s345><insert.einfügen><de> Über die Registerkarte Titel fügen Sie Quellennachweise in Ihren Text ein.
<G-vec00407-001-s345><insert.einfügen><en> On the References tab you can insert citations into your text.
<G-vec00407-001-s346><insert.einfügen><de> Fügen Sie die Bilder nicht selbst in das Worddokument ein – von Ihnen sind nur die Stellen zu markieren, an die sie gehören.
<G-vec00407-001-s346><insert.einfügen><en> Do not insert the images into the Word document yourself – you only have to mark the places where they belong.
<G-vec00407-001-s347><insert.einfügen><de> Aber mach dir keine Sorgen, Kutools for Excel Fügen Sie die Sequenznummer ein Dienstprogramm kann Ihnen helfen, es schnell und einfach zu beenden.
<G-vec00407-001-s347><insert.einfügen><en> But, please don’t worry about, Kutools for Excel’s Insert Sequence Number utility can help you finish it quickly and easily.
<G-vec00407-001-s348><insert.einfügen><de> Einige kostenlose Hosting-Provider fügen automatisch Werbung auf Ihrer Webseite ein.
<G-vec00407-001-s348><insert.einfügen><en> Some Free Hosting providers automatically insert advertising onto your Website.
<G-vec00407-001-s349><insert.einfügen><de> Bitte fügen Sie nun ein Image Control in das UserForm ein.
<G-vec00407-001-s349><insert.einfügen><en> Now please insert an Image Control into the UserForm.
<G-vec00407-001-s350><insert.einfügen><de> Bitte fügen Sie Ihre Aufenthaltsdaten ein und lesen Sie die Bedingungen Ihres Zimmers.
<G-vec00407-001-s350><insert.einfügen><en> Please insert your travel dates and check the conditions of your room.
<G-vec00407-001-s351><insert.einfügen><de> Zur Strukturierung fügen Sie einfach per Kontextmenü vor jede Notiz den aktuellen Zeitpunkt ein.
<G-vec00407-001-s351><insert.einfügen><en> For better structure you simply insert the current time before every note by context menu.
<G-vec00407-001-s352><insert.einfügen><de> Die Arbeiten fügen sich aber zugleich ein in den gewaltigen symbolischen Bedeutungsraum des Kreises, den die Kultur, die Überlieferung, die intuitive Verwendung, das Experiment, die künstlerische Revolte je aufgedeckt haben.
<G-vec00407-001-s352><insert.einfügen><en> However, at the same time, the works insert themselves into the enormous symbolic semantic space of the circle, which culture, tradition, intuitive use, the experiment, the artistic revolt have each revealed.
<G-vec00407-001-s353><insert.einfügen><de> Bitte fügen Sie nur 3 Zahlen nach ILS oder ILP ein.
<G-vec00407-001-s353><insert.einfügen><en> Please insert only 3 numbers following the word ILS or ILP.
<G-vec00407-001-s354><insert.einfügen><de> Wenn Sie installiert haben Kutools for Excelmit seiner Kraft Fügen Sie die Sequenznummer ein können Sie Sequenznummern nur schnell und einfach in die gefilterten Daten einfügen.
<G-vec00407-001-s354><insert.einfügen><en> If you have installed Kutools for Excel, with its powerful Insert Sequence number feature, you can insert sequence numbers into the filtered data only quickly and easily.
<G-vec00407-001-s355><insert.einfügen><de> In den folgenden Kapiteln dieses Handbuchs fügen Sie dann Daten in diese Datenbank ein und aktualisieren die darin enthaltenen Daten.
<G-vec00407-001-s355><insert.einfügen><en> In subsequent chapters in this book, you will insert and update data in this database.
<G-vec00407-001-s356><insert.einfügen><de> Die Platzhalter fügen den E-Mail-Trenntext, den eigentlichen Inhalt der E-Mail sowie einen Fußbereich ein.
<G-vec00407-001-s356><insert.einfügen><en> The placeholders insert delimiter text, the email contents, and a footer.
<G-vec00407-001-s357><insert.einfügen><de> 3, bitte haften nicht Ihre Hand oder fügen mechanische feine Wurzeln innen ein.
<G-vec00407-001-s357><insert.einfügen><en> 3, please do not stick your hand or insert mechanical fine roots within .
<G-vec00407-001-s358><insert.einfügen><de> In Excel fügen wir normalerweise ein Diagramm ein, um die Daten besser zu beschreiben.
<G-vec00407-001-s358><insert.einfügen><en> In Excel, we usually insert a chart to better describe the data.
<G-vec00407-001-s359><insert.einfügen><de> Nur in Excel 2013 und 2016: Fügen Sie ein zweites Arbeitsblatt ein.
<G-vec00407-001-s359><insert.einfügen><en> (Only if you try to reproduce with Excel 2013 or later: Insert a second worksheet.
<G-vec00407-001-s360><insert.einfügen><de> Was BMW anbetrifft ICOM mit interner Festplatte, fügen Sie direkt interne Festplatte in Computer ein und öffnen Computer, um zu bestimmen und zu programmieren.
<G-vec00407-001-s360><insert.einfügen><en> As for BMW ICOM with internal hard disk, you directly insert internal hard disk into computer, and open computer to diagnose and program.
<G-vec00407-001-s592><insert.einfügen><de> In einer Pivot-Tabelle können Sie Seitenumbrüche einfügen, um jede Pivot-Tabellengruppe zu separaten Seiten zu drucken.
<G-vec00407-001-s592><insert.einfügen><en> In a pivot table, we can insert page breaks to print each group of pivot table to separate pages.
<G-vec00407-001-s593><insert.einfügen><de> In diesem Artikel zeigen wir Ihnen, wie Sie eine leere neue Zeile automatisch einfügen, indem Sie in Excel auf eine Befehlsschaltfläche klicken.
<G-vec00407-001-s593><insert.einfügen><en> In this article, we will show you how to insert a blank new row automatically by clicking on a Command Button in Excel.
<G-vec00407-001-s594><insert.einfügen><de> "Es gibt auch die Operatoren $@ und #@, die eine ""listentrennende"" Funktion aufweisen, indem sie alle Elemente einer Liste in den umgebenden Kontext einfügen."
<G-vec00407-001-s594><insert.einfügen><en> There are also 'list splicing' operators $@ and #@ that insert all elements of a list in the surrounding context.
<G-vec00407-001-s595><insert.einfügen><de> Beachten Sie, dass im Mapping anstelle der Schaltfläche Aktion: Einfügen nun eine Schaltfläche Aktion: Aktualisieren; Einfügen () angezeigt wird.
<G-vec00407-001-s595><insert.einfügen><en> Notice that, back on the mapping, the Action: Insert button has now changed to an Action: Update; Insert () button.
<G-vec00407-001-s596><insert.einfügen><de> "Interpolierte Tempokurven bleiben nun erhalten, wenn sie mit dem Befehl ""Abschnitt an Abspielposition einfügen"" an einer neuen Position eingesetzt werden."
<G-vec00407-001-s596><insert.einfügen><en> "Interpolated tempo curves are now maintained when pasted to a new position using the ""Insert Section at Playhead"" command."
<G-vec00407-001-s597><insert.einfügen><de> Während Sie mit Pivot Table arbeiten, können Sie Slicer einfügen, um Daten visuell von der Tabelle zu filtern.
<G-vec00407-001-s597><insert.einfügen><en> While working with Pivot Table, you may insert slicers to filter data visually of the table.
<G-vec00407-001-s598><insert.einfügen><de> Setzen Sie den Cursor an die Stelle, an der Sie einen Barcode einfügen möchten, und klicken Sie dann auf, um dieses Dienstprogramm anzuwenden Kutoolen > Strichcode > Strichcode.
<G-vec00407-001-s598><insert.einfügen><en> Place the cursor to the position where you want to insert a barcode, and then applying this utility by clicking Kutools > Barcode > Barcode.
<G-vec00407-001-s599><insert.einfügen><de> Setzen Sie den Cursor an die Stelle, an der Sie eine Akzentmarkierung einfügen möchten, und klicken Sie auf Einsatz > Symbol > Mehr Symbole öffnen Symbol Dialog.
<G-vec00407-001-s599><insert.einfügen><en> Put the cursor at the place you want to insert an accent mark, and click Insert > Symbol > More Symbols to open the Symbol dialog.
<G-vec00407-001-s600><insert.einfügen><de> In diesem Artikel zeigen wir Ihnen, wie Sie denselben Text in jede zweite Zeile in Excel einfügen.
<G-vec00407-001-s600><insert.einfügen><en> In this article, we will show you how to insert same text in every other row in Excel.
<G-vec00407-001-s601><insert.einfügen><de> Beim SEO Poisoning nutzen Internetkriminelle Schwachstellen auf unzähligen Websites, auf denen sie unsichtbare Links einfügen.
<G-vec00407-001-s601><insert.einfügen><en> SEO poisoning involves Internet criminals exploiting weaknesses on countless websites to insert invisible links.
<G-vec00407-001-s602><insert.einfügen><de> Empfohlene Bild – Verwenden Sie nativen WP Medien Uploader, um die empfohlene Bild für ein Rezept einfügen.
<G-vec00407-001-s602><insert.einfügen><en> Featured image – Use the native WP media Uploader to insert the featured image for a recipe.
<G-vec00407-001-s603><insert.einfügen><de> Setzen Sie den Cursor an die Position, an der Sie die Tabelle mit verknüpfbaren Inhalten einfügen möchten, klicken Sie auf Referenzen > Inhaltsverzeichnis > Benutzerdefiniertes Inhaltsverzeichnis.
<G-vec00407-001-s603><insert.einfügen><en> Now place the cursor at the position you want to insert the table of linkable contents, click References > Table of Contents > Custom Table of Contents.
<G-vec00407-001-s604><insert.einfügen><de> Zunächst zeigen wir Ihnen, wie Sie Anhänge direkt in den Text einer verfassten E-Mail-Nachricht einfügen.
<G-vec00407-001-s604><insert.einfügen><en> First of all, we will show you how to insert attachments in the body of a composing e-mail message directly.
<G-vec00407-001-s605><insert.einfügen><de> Wählen Sie den Typ der Zwischensummenformel, aus der Sie einfügen möchten Verwenden Sie die Funktion Option, wähle ich die Sum Funktion.
<G-vec00407-001-s605><insert.einfügen><en> Select what type of subtotal formula you want to insert from Use function option, I choose the Sum function.
<G-vec00407-001-s606><insert.einfügen><de> Wenn Sie im letzten Eingabefeld die Anzahl der Stellen eingegeben haben, dann können Sie mit der Taste <Tabulator> ein weiteres Eingabefeld einfügen, um eine zusätzliche Hierarchieebene zu definieren.
<G-vec00407-001-s606><insert.einfügen><en> When you have entered the number of digits in the last input field, you can use the <Tab> key to insert another input field to define an additional hierarchy level.
<G-vec00407-001-s607><insert.einfügen><de> Platzieren Sie die Einfügemarke an der Stelle, an der Sie das Textfeld einfügen wollen.
<G-vec00407-001-s607><insert.einfügen><en> Place the insertion point where you want to insert the text field.
<G-vec00407-001-s608><insert.einfügen><de> Auf der letzten Seite, wo endet der Auftrag, bevor Sie die Bestellung abschließen, auf der rechten Seite, Geben Sie Ihre Promo-Code einfügen.
<G-vec00407-001-s608><insert.einfügen><en> On the last page, where the order finishes, before completing the order, on the right, type Insert your promo code.
<G-vec00407-001-s609><insert.einfügen><de> ● Einfügen eines Rhythmus-Patterns in einem Song Wechseln Sie zu dem Punkt, an dem Sie das Rhythmus-Pat-tern einfügen möchten, und führen Sie die Schritte 4 - 7 aus.
<G-vec00407-001-s609><insert.einfügen><en> ● Inserting a rhythm pattern in a song Move to the point you want to insert the rhythm pattern, and perform steps 4 - 7.
<G-vec00407-001-s610><insert.einfügen><de> Beachten Sie, dass im Mapping anstelle der Schaltfläche Aktion: Einfügen nun eine Schaltfläche Aktion: Ignorieren; Einfügen () angezeigt wird.
<G-vec00407-001-s610><insert.einfügen><en> Notice that, back on the mapping, the Action: Insert button has now changed to an Action: Ignore; Insert () button.
