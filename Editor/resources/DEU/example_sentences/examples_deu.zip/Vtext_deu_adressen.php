<G-vec00301-002-s095><address.adressen><de> Namen, Adressen, E-Mail-Adressen, Computernamen oder alle Informationen, die zur Identifizierung von Personen oder zur Kontaktaufnahme dienen, werden nicht absichtlich erfasst.
<G-vec00301-002-s095><address.adressen><en> It does not intentionally collect anyone’s name, address, email address, computer name, or any information that will be used to identify you or contact you.
<G-vec00301-002-s096><address.adressen><de> Enthält den Ländercode, wie er durch die umgekehrte IP Adressen Suche bestimmt wird.
<G-vec00301-002-s096><address.adressen><en> Contains a country code as determined by reverse IP address lookup.
<G-vec00301-002-s097><address.adressen><de> Auf jeden Fall stand da geschrieben, dass man 1 zu jedem der 6 Namen und Adressen, die in diesem Artikel angegeben sind, senden soll.
<G-vec00301-002-s097><address.adressen><en> Anyway, it said that you send $1.00 to each of the 6 names and address stated in the article.
<G-vec00301-002-s098><address.adressen><de> Wenn Sie dergleichen Information nicht mehr erhalten möchten, bitten wir um eine kurze Nachricht an eine der obengenannten Adressen.
<G-vec00301-002-s098><address.adressen><en> In case you do not want (anymore) to receive such information, please contact us on the above-mentioned address.
<G-vec00301-002-s099><address.adressen><de> Sie haben einen Schlüsselanhänger an Ihrem Schlüsselbund, der auf der Vorderseite das ABUS Logo zeigt, und auf der Rückseite einen Code, eine E-Mail Adressen sowie einen QR-Code aufweist.
<G-vec00301-002-s099><address.adressen><en> The key fob is attached to your keyring, and shows the ABUS logo on the front and a code, email address and OR code on the back.
<G-vec00301-002-s100><address.adressen><de> Eine vollständige und eindeutige Benennung des Mitglieds oder der Mitglieder des Stiftungsrats, zu welchem der Stifter gehören kann, einschließlich ihrer Adressen.
<G-vec00301-002-s100><address.adressen><en> A complete and clear designation of the member or members of the Foundation Council, to which the Founder may belong, including their address.
<G-vec00301-002-s101><address.adressen><de> Sofern innerhalb des Internetangebotes die Möglichkeit zur Eingabe persönlicher oder geschäftlicher Daten (E-Mail Adressen, Namen, Anschriften) besteht, so erfolgt die Preisgabe dieser Daten seitens des Nutzers auf ausdrücklich freiwilliger Basis.
<G-vec00301-002-s101><address.adressen><en> If there is an option for entering personal or business information (email address, name and address) within this internet content, revealing such information on the part of the user is expressly on a voluntary basis.
<G-vec00301-002-s102><address.adressen><de> Die Multicast IP Adressen sowie Port und Protokoll (RTP/UDP) sind frei definierbar.
<G-vec00301-002-s102><address.adressen><en> The multicast IP address as well port and protocol (RTP / UDP) are freely definable.
<G-vec00301-002-s103><address.adressen><de> Weiterhin sammeln wir automatisch Daten über Ihren Browser und Ihr Betriebssystem, zuvor und danach besuchte Internetseiten, allgemeine Serverloginformationen, Internet Protocol (IP) Adressen, Mobilfunkanbieter und Betriebssystem des Mobiltelefons.
<G-vec00301-002-s103><address.adressen><en> We may collect information about your computer, including where available your operating system and browser type, websites you visited before and after visiting the Site, standard server log information and IP Address (see below).
<G-vec00301-002-s104><address.adressen><de> Verwenden Sie DHCP-Reservierungen für die Zuteilung von Adressen.
<G-vec00301-002-s104><address.adressen><en> Use DHCP reservations for address allocation.
<G-vec00301-002-s105><address.adressen><de> Jede Partei muss die andere unverzüglich schriftlich über geänderte Adressen oder Faxnummern informieren.
<G-vec00301-002-s105><address.adressen><en> Each party shall promptly notify to the other in writing any change of address or facsimile numbers.
<G-vec00301-002-s106><address.adressen><de> In den Cookies werden keine sensiblen Informationen wie Namen, Adressen oder Zahlungsdetails gespeichert.
<G-vec00301-002-s106><address.adressen><en> We do not store any sensible data, such as your name, billing address, or payment details in the cookies.
<G-vec00301-002-s107><address.adressen><de> Diese Mailinglisten werden von SecuritySpace verwaltet und die Email Adressen werden von uns nicht an Dritte weitergegeben.
<G-vec00301-002-s107><address.adressen><en> These mailing lists are managed by SecuritySpace, and your email address will not be disclosed to others by us.
<G-vec00301-002-s108><address.adressen><de> Geben Sie die E-Mail Adressen in das angezeigte Formular ein.
<G-vec00301-002-s108><address.adressen><en> Enter the email address in the provided form.
<G-vec00301-002-s109><address.adressen><de> Das 5 Sterne Hotel gehört zu den besten Adressen in Zürich.
<G-vec00301-002-s109><address.adressen><en> The 5 stars hotel is one of the first address’ in Zurich.
<G-vec00301-002-s110><address.adressen><de> Die offensichtlichste solche Einschränkung ist die Tatsache, dass 32-bit Spiele nur bis zu 4GB RAM in Deinem Rechner nutzen können (auf Grund der maximal möglichen Adressen für RAM Bytes).
<G-vec00301-002-s110><address.adressen><en> The most obvious being the fact that 32-bit software can only address 4GB of RAM in your system, due to a hard limit on the number of RAM bytes the software can address.
<G-vec00301-002-s111><address.adressen><de> Du kannst deine Bestellung in mehrere Teillieferungen unterteilen und sie so an verschiedene Adressen senden lassen.
<G-vec00301-002-s111><address.adressen><en> You can split your order into several parts and send each part to a different shipping address.
<G-vec00301-002-s112><address.adressen><de> Dann kannst du bei dem angegebenen Übernahme-Account die gelöschten Adressen als Aliasse hinzufügen.
<G-vec00301-002-s112><address.adressen><en> After deletion you can enter the deleted mail address as an alias in your Premium Tutanota account.
<G-vec00301-002-s113><address.adressen><de> Wir weisen darauf hin, dass diese Website Google Analytics mit der Erweiterung „_anonymizeIp()“ verwendet und daher IP- Adressen von Google in Mitgliedstaaten innerhalb der Europäischen Union oder in anderen Vertragsstaaten des Abkommens über den Europäischen Wirtschaftsraum vor der Übertragung gekürzt werden, um so einen direkten Personenbezug auszuschließen.
<G-vec00301-002-s113><address.adressen><en> Your IP address will be processed by Google only in a shortened form within the member states of the European Union or in other member states of the European Economic Area, if the IPAnonymization is activated on this website.
