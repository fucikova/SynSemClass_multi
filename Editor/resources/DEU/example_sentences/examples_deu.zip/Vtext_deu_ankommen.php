<G-vec00097-001-s038><arrive.ankommen><de> Natürlich kannst du (Enkel) helfen, gerne angekommen zu sein und die Schockenergien von ihrem letzten Übergang zu transzendieren.
<G-vec00097-001-s038><arrive.ankommen><en> Of course, you can help (grandchild), to arrive and to transcend shock energies from her last transition.
<G-vec00097-001-s039><arrive.ankommen><de> Nach einer Weile gab der Weise Li Linfu einen Bambusstab und sagte: „Reite weiter auf dem Stab, er hält an wenn wir am Bestimmungsort angekommen sind.
<G-vec00097-001-s039><arrive.ankommen><en> After a while, the priest gave Li Linfu a bamboo pole and said: “Ride on the pole. It will stop when we arrive at the destination.
<G-vec00097-001-s040><arrive.ankommen><de> Einmal dort angekommen findet man sich schnell und leicht in der Stadt zurecht, denn die öffentlichen Verkehrsmittel, vor allem die U-Bahnen des sogenannten Maß Rapid Transit, bringen Touristen schnell und verlässlich in die anderen Teile der Stadt.
<G-vec00097-001-s040><arrive.ankommen><en> Once there, getting around is quick and easy thanks to the Mass Rapid Transit metro system which services all main parts of the city. When you first arrive in the city and are not sure of directions, a taxi is a good option for getting around, and they are good value too.
<G-vec00097-001-s041><arrive.ankommen><de> Ich war noch nicht in Basel angekommen, als ich mich entschied, dass ich definitiv an dieses Showcase gehen musste.
<G-vec00097-001-s041><arrive.ankommen><en> I didn’t arrive in Basel yet, when I had decided that I’d definitively got to go to this showcase.
<G-vec00097-001-s042><arrive.ankommen><de> An der Brücke Ponte Milvio (Olympiastadium) angekommen, fahren Sie weiter bis zum Lungotevere, wobei Sie bis zur Ampel der Piazza delle Cinque Giornate direkt am Fluss entlangfahren.
<G-vec00097-001-s042><arrive.ankommen><en> "Once you arrive to Ponte Milvio (Olympic Stadium) continue along side the river side until you reach the stop light in ""Piazza della cinque giornate""."
<G-vec00097-001-s043><arrive.ankommen><de> Die lang erwartete Winterurlaub angekommen, baut Weihnachtsstimmung.
<G-vec00097-001-s043><arrive.ankommen><en> As the long awaited winter holidays arrive, Christmas spirit builds up.
<G-vec00097-001-s044><arrive.ankommen><de> Im Falle wenn Ihre Bestellung innerhalb von 30 Werktagen nicht angekommen ist oder in irgendeiner Form beschädigt angekommen ist, garantieren wir Ihnen eine kostenlose Rücksendung, setzen Sie nur mit uns in Verbindung (Kontakt), damit wir Ihre Bestellung wieder versenden können.
<G-vec00097-001-s044><arrive.ankommen><en> If your order does not arrive within 30 business days or arrives damaged in any way, we guarantee to give you a free reshipment, just Contact us so that we may reship.
<G-vec00097-001-s045><arrive.ankommen><de> "Wenn du an der Hauptküstenstrasse angekommen siehst du schon den Wegweiser “Essaouira""."
<G-vec00097-001-s045><arrive.ankommen><en> "When you arrive to the main coast street you will see the sign “Essaouira""."
<G-vec00097-001-s046><arrive.ankommen><de> Kurz nachdem du angekommen bist, erhalten deine Freunde zu Hause die Nachricht, daß du überhaupt nicht von Gott gebraucht wirst.
<G-vec00097-001-s046><arrive.ankommen><en> Yet after you arrive, your friends back home receive word that you're not being used of God at all.
<G-vec00097-001-s047><arrive.ankommen><de> X angekommen, müssen Sie 1 km Feldweg zurücklegen, der Sie zurückführen kann... aber tun Sie es nicht... fahren Sie weiter zum Ziel und Sie werden mit dem köstlichen Essen und der unvergesslichen Landschaft belohnt.
<G-vec00097-001-s047><arrive.ankommen><en> X arrive you have to travel 1km of dirt road that can lead you back... but do not do it... continue towards the goal and you will be rewarded by the delicious food and unforgettable scenery.
<G-vec00097-001-s048><arrive.ankommen><de> Wenn Sie am Uhrturm angekommen sind, lädt Sie die imposante Struktur ein, sie zu entdecken.
<G-vec00097-001-s048><arrive.ankommen><en> Once you arrive at the Clock Tower, the imposing structure invites you to discover it.
<G-vec00097-001-s049><arrive.ankommen><de> »Zu dem Ehrendoktorat in Almata sind Nachweispapiere nicht angekommen, wann der Beehrte die Dissidenten getroffen hat.
<G-vec00097-001-s049><arrive.ankommen><en> »For the honorary doctorate in Almaty the papers proving when the recipient met the dissidents didn't arrive in time.
<G-vec00097-001-s050><arrive.ankommen><de> Wenn du in Essaouira angekommen bist, fährst du die Küstenstrasse entlang, das Meer auf deiner linken Seite und folgst der Straße bis du das Club Mistral und Skyriders Center linker Hand siehst.
<G-vec00097-001-s050><arrive.ankommen><en> When you arrive in Essaouira you take the coast street with the ocean on your left side. Follow this road till you see the Club Mistral and Skyriders Center.
<G-vec00097-001-s051><arrive.ankommen><de> Wir waren noch nicht einmal richtig in Mohacs angekommen, da wurde bereits eine Transportmöglichkeit für unsere Fahrräder organisiert.
<G-vec00097-001-s051><arrive.ankommen><en> We didn’t even quite arrive in Mohacs yet, when they already organized a way to transport our bicycles.
<G-vec00097-001-s052><arrive.ankommen><de> Sobald Sie hier angekommen sind, wissen Sie, dass Sie sich in einem tropischen Paradies befinden – einzigartig für Andalusien.
<G-vec00097-001-s052><arrive.ankommen><en> As soon as you arrive, you will know you are in tropical paradise unique to Andalucia.
<G-vec00097-001-s053><arrive.ankommen><de> Sollte der Gast ohne Rücksprache mit Reisebüro PUNTARKA NOVA oder dem Anbieter der Dienstleistung am Tag des Nutzungsbeginns bei der gebuchten Unterkunft bis Mitternacht nicht angekommen sein, gilt die Buchung als gekündigt.
<G-vec00097-001-s053><arrive.ankommen><en> Should the customer not arrive at the booked accommodation unit before midnight on the arrival date, and the customer has not informed Tourist agency PUNTARKA NOVA or the host, the reservation is considered to be cancelled, and therefore the cancellation costs will be charged as described above.
<G-vec00097-001-s054><arrive.ankommen><de> Sie und ihre Freunde haben überlebt und sie sind an ihrem Zielort angekommen.
<G-vec00097-001-s054><arrive.ankommen><en> Luckily, she and her friend survive and they arrive to their destination.
<G-vec00097-001-s055><arrive.ankommen><de> Dort angekommen ist es noch früh am Nachmittag.
<G-vec00097-001-s055><arrive.ankommen><en> It is still early in the afternoon as we arrive at the campsite.
<G-vec00097-001-s056><arrive.ankommen><de> Sobald Sie angekommen sind, können Sie mit einem Eis in der Hand an der Promenade entlang spazieren, oder an Bord einer Fähre gehen und die kurze Überfahrt zur Insel Cumbrae machen.
<G-vec00097-001-s056><arrive.ankommen><en> Once you arrive, stroll along the promenade with an ice cream or jump aboard the ferry and take the short crossing to the Isle of Cumbrae .
<G-vec00097-001-s057><arrive.ankommen><de> Wir sind nur 3 Blocks vom Bahnhof entfernt, wo Sie ankommen werden entfernt.
<G-vec00097-001-s057><arrive.ankommen><en> We are located only 3 blocks from the train station where you will arrive.
<G-vec00097-001-s058><arrive.ankommen><de> Sie ist allerdings eine schwierig zu messende Größe, da jeweils zu definieren wäre, in welcher Hautschicht der Wirkstoff ankommen muss, um die gewünschten Effekte auszulösen.
<G-vec00097-001-s058><arrive.ankommen><en> Nevertheless, this particular factor is difficult to measure as also the individual skin layer would have to be determined in which the active agent is supposed to arrive in order to trigger the desired effects.
<G-vec00097-001-s059><arrive.ankommen><de> Ihre Rize Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s059><arrive.ankommen><en> Your Rize flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s060><arrive.ankommen><de> Ihre Dasarahalli Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s060><arrive.ankommen><en> Your Dasarahalli flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s061><arrive.ankommen><de> Wenn Sie ankommen, fordern Sie bitte eine Karte / einen Führer mit 3 Reiserouten und amüsanten Fakten an.
<G-vec00097-001-s061><arrive.ankommen><en> When you arrive, please request a map/guide that has 3 itineraries and fun facts.
<G-vec00097-001-s062><arrive.ankommen><de> Ihre Kukatpalle Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s062><arrive.ankommen><en> Your Kukatpalle flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s063><arrive.ankommen><de> Wenn Sie mit Zug bis Burgas ankommen, müssen Sie in den Bus bis Sozopol einsteigen.
<G-vec00097-001-s063><arrive.ankommen><en> If you arrive by train to Burgas then you have to get on the bus to Sozopol.
<G-vec00097-001-s064><arrive.ankommen><de> Wenn Sie früher ankommen, bitte verbringen Sie die ersten Nächte in einem Hotel oder einer Jugendherberge.
<G-vec00097-001-s064><arrive.ankommen><en> If you arrive earlier, please book a hotel/hostel room for the first nights.
<G-vec00097-001-s065><arrive.ankommen><de> Wenn Sie in Yawatahama einsteigen, dauert es etwas mehr als zwei Stunden, bis Sie in Matsuyama ankommen.
<G-vec00097-001-s065><arrive.ankommen><en> If you get on at Yawatahama, it will take just over two hours to arrive at Matsuyama.
<G-vec00097-001-s066><arrive.ankommen><de> Ihre Almus Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s066><arrive.ankommen><en> Your Almus flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s067><arrive.ankommen><de> Die kompakte Bauweise erlaubt es dem Fahrer zu schlängeln sich durch die seitlich so dass sie schneller am Ziel ankommen.
<G-vec00097-001-s067><arrive.ankommen><en> The compact design allows riders to weave through the sideways making them arrive at the destination more quickly.
<G-vec00097-001-s068><arrive.ankommen><de> Ihre Rajkot Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s068><arrive.ankommen><en> Your Rajkot flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s069><arrive.ankommen><de> Ihre Govurdak Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s069><arrive.ankommen><en> Your Govurdak flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s070><arrive.ankommen><de> Wenn Sie am Flughafen ankommen und Ihr Gepäck mehr als Ihre Freigepäckgrenze wiegt, berechnen wir Ihnen eine Gebühr für jedes Kilogramm Übergewicht.
<G-vec00097-001-s070><arrive.ankommen><en> If your hold luggage weighs more than your allowance when you arrive at the airport we charge you a fee for each 1kg of excess weight.
<G-vec00097-001-s071><arrive.ankommen><de> Ihre Baklan Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s071><arrive.ankommen><en> Your Baklan flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s072><arrive.ankommen><de> Ihre NewcastleuponTyne Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s072><arrive.ankommen><en> Your NewcastleuponTyne flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s073><arrive.ankommen><de> Ihre Angren Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s073><arrive.ankommen><en> Your Angren flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s074><arrive.ankommen><de> Ihre Muridke Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s074><arrive.ankommen><en> Your Muridke flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s075><arrive.ankommen><de> Ihre Tagum Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s075><arrive.ankommen><en> Your Tagum flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s076><arrive.ankommen><de> Als Diätassistent habe ich selbst in der Küche gestanden und weiß worauf es ankommt.
<G-vec00097-001-s076><arrive.ankommen><en> As Diätassistent I confessed in the kitchen and know on which it arrive.
<G-vec00097-001-s077><arrive.ankommen><de> Es ist der Pfad, auf dem wir gehen, um dorthin zu kommen, wohin wir gehen wollen; ausgedrückt in der überlieferten Weisheit, dass nur ankommt, wer auch aufbricht – bis zum ultimativen Ende der Straße.
<G-vec00097-001-s077><arrive.ankommen><en> It’s the path we walk to get to where we’re going, the ancient wisdom that in leaving you arrive and the ultimate end of the road.
<G-vec00097-001-s078><arrive.ankommen><de> Um einen Asteroiden erfolgreich abbauen zu können, muss man beachten, dass die Geschwindigkeit und Position des Asteroiden beachtet werden müssen, bevor man den Flug versendet, damit man zum richtigen Zeitpunkt ankommt.
<G-vec00097-001-s078><arrive.ankommen><en> To have a successful Astroploatation, you must keep in mind the Asteroid's speed and current location and time needed for your fleet to arrive thus sending the flight to such coordinates that it would intersect the Asteroid.
<G-vec00097-001-s079><arrive.ankommen><de> Ich weiß genau, wie das Bestellungssystem funktioniert und ich bin nicht besorgt, wenn das Paket ein wenig zu spät ist, da ich genau weiß, dass es ankommt.
<G-vec00097-001-s079><arrive.ankommen><en> I know how they order system works and when my package is a bit late I do not worry because I know that it will arrive no matter what.
<G-vec00097-001-s080><arrive.ankommen><de> Manchmal braucht es Zeit, bis die E-Mail ankommt.
<G-vec00097-001-s080><arrive.ankommen><en> Sometimes it just takes time for the email to arrive.
<G-vec00097-001-s081><arrive.ankommen><de> Es ist natürlich eine bequeme Sache, wenn man am normalen Bahnhof von Zermatt ankommt, nur die Straße überqueren muss und sich in den nächsten Zug in Richtung Gipfel setzen kann.
<G-vec00097-001-s081><arrive.ankommen><en> Of course, it is a very comfortable thing to arrive to the common main station of Zermatt and have only to cross the street in order to take then the next train in direction to the peak.
<G-vec00097-001-s082><arrive.ankommen><de> Mit LINEA entwickelte der Hub ein System, das Kunden per E-Mail oder SMS informiert, wenn ihr Gepäck nicht wie geplant ankommt.
<G-vec00097-001-s082><arrive.ankommen><en> LINEA, a system developed by the Hub, informs customers by email or text message if their baggage won't arrive as planned.
<G-vec00097-001-s083><arrive.ankommen><de> Es ist immer möglich, dass eine Packung nicht ankommt.
<G-vec00097-001-s083><arrive.ankommen><en> It always can happen that a package doesn´t arrive.
<G-vec00097-001-s084><arrive.ankommen><de> Zunächst möchten Sie, dass der Computer bereit ist, bevor der Benutzer (oder Ihr Mitarbeiter) bei der Arbeit ankommt.
<G-vec00097-001-s084><arrive.ankommen><en> First you want, that the computer is ready before the user (or your employees) arrive at work.
<G-vec00097-001-s085><arrive.ankommen><de> Die Rücksendung solcher Ware liegt in der Verantwortung des Kunden und er muss Sorge tragen, dass die Ware materialgerecht verpackt und unbeschädigt bei uns ankommt.
<G-vec00097-001-s085><arrive.ankommen><en> The return of such items is the full responsibility of the customer, and the goods must be securely packaged to ensure that they arrive back to us undamaged.
<G-vec00097-001-s086><arrive.ankommen><de> Die Aufrechterhaltung des Blutflusses - auch teilweise - bietet die Möglichkeit einer erfolgreichen Wiederbelebung, sobald geschultes medizinisches Personal vor Ort ankommt.
<G-vec00097-001-s086><arrive.ankommen><en> Keeping the blood flow active — even partially — extends the opportunity for a successful resuscitation once trained medical staff arrive on site.
<G-vec00097-001-s087><arrive.ankommen><de> Ich warte darauf, dass das Paket per Post ankommt.
<G-vec00097-001-s087><arrive.ankommen><en> I am waiting for the parcel to arrive by mail.
<G-vec00097-001-s088><arrive.ankommen><de> Die Vorauszahlung dient dem Unternehmen als Garantie dafür, dass der Kunde ankommt und den gebuchten Zeitraum vollständig bezahlt, und dem Kunden als Garantie dafür, dass er die vereinbarte Wohnung für den vereinbarten gebuchten Zeitraum erhält.
<G-vec00097-001-s088><arrive.ankommen><en> Prepayment serves for the company as a guarantee that the client will arrive and will pay for the booked period in full, and for the client as a guarantee that he or she will receive the agreed apartment for the agreed booked period.
<G-vec00097-001-s089><arrive.ankommen><de> Ein Tsunami kann in den Küstenregionen erst wahrgenommen werden, wenn er tatsächlich schon ankommt.
<G-vec00097-001-s089><arrive.ankommen><en> A tsunami can only be noticed by the coast once it arrives, or is about to arrive.
<G-vec00097-001-s090><arrive.ankommen><de> Dieser strengt sich an, um Gott näher zu kommen und er hat die notwendigen Mittel ergriffen, um sich abzusichern, dass er an dem versprochenen Reiseziel ankommt.
<G-vec00097-001-s090><arrive.ankommen><en> So he competed in coming closer to God, and he took the necessary means to ensure that he would arrive at the promised destination.
<G-vec00097-001-s091><arrive.ankommen><de> Dadurch wissen wir, dass unser Budget direkt an der richtigen Stelle ankommt.
<G-vec00097-001-s091><arrive.ankommen><en> Now we're sure that our budget will arrive directly at the proper place.
<G-vec00097-001-s092><arrive.ankommen><de> Wir sind ein Unternehmen, das den Dienst der Entwicklung von Hydraulikschläuchen für Baumaschinen, landwirtschaftlichen und anderen Geräten, die Hydraulik zu haben, mit dem Mehrwert, den wir aus mit einem mobilen Mehr... Computer, die vollständig mit den notwendigen Materialien ausgestattet ist, die es uns ankommt macht bietet um, wo Sie Ihren Computer und erfordert unseren Service sofort.
<G-vec00097-001-s092><arrive.ankommen><en> We are a company that provides the service of development of hydraulic hoses for construction machines, agricultural and other equipment that have hydraulics, with the added value that we consist More... with a mobile computer that is fully equipped with the necessary materials, which makes us arrive to where you have your computer and requires our service immediately.
<G-vec00097-001-s093><arrive.ankommen><de> Leider kommt es immer wieder vor, dass aufgegebenes Reisegepäck am Zielort nicht ankommt oder beschädigt wird.
<G-vec00097-001-s093><arrive.ankommen><en> Unfortunately, it happens again and again that checked luggage does not arrive at its destination or that it is damaged.
<G-vec00097-001-s094><arrive.ankommen><de> Also, wenn Ihre Zeit nicht ankommt, überprüfen Sie, um sicherzustellen, dass es nicht wirklich ein Baby auf dem Weg ist.
<G-vec00097-001-s094><arrive.ankommen><en> So, if your period doesn’t arrive, check to make sure it’s not actually a baby on the way.
<G-vec00097-001-s152><arrive.ankommen><de> Wir sind pünktlich, daher empfehlen wir Ihnen, einige Minuten im Voraus anzukommen.
<G-vec00097-001-s152><arrive.ankommen><en> We are punctual so we advise that you arrive a few minutes early
<G-vec00097-001-s153><arrive.ankommen><de> Kostenloser Versand erfordert keine Transport Steuern, aber es dauert länger, um anzukommen und den Wert der Bestellung übersteigt $50 und die standard-Versand dauert wesentlich weniger, um anzukommen, sondern erfordern zusätzliche Gebühren.
<G-vec00097-001-s153><arrive.ankommen><en> Free shipping requires no transportation taxes but takes longer to arrive and the value of the order has to exceed $50 and the standard shipping can take significantly less to arrive but will require additional fees.
<G-vec00097-001-s154><arrive.ankommen><de> Kostenloser Versand erfordert keine Transport Steuern, aber es dauert länger, um anzukommen und den Wert der Bestellung übersteigt $50 und die standard-Versand dauert wesentlich weniger, um anzukommen, sondern erfordern zusätzliche Gebühren.
<G-vec00097-001-s154><arrive.ankommen><en> Free shipping requires no transportation taxes but takes longer to arrive and the value of the order has to exceed $50 and the standard shipping can take significantly less to arrive but will require additional fees.
<G-vec00097-001-s155><arrive.ankommen><de> Es wird empfohlen, 10 Minuten vor Abreise anzukommen.
<G-vec00097-001-s155><arrive.ankommen><en> It is recommended to arrive 10 minutes prior to departure.
<G-vec00097-001-s156><arrive.ankommen><de> "Er sagte:""Dieses Ergebnis ist sehr wichtig, denn ich habe meine Führung auf Jorge um drei Punkte ausgebaut, aber es ist besonders wichtig vor ihm im Rennen anzukommen und mit einem kleinen Vorsprung den ersten Teil der Meisterschaft abzuschließen."
<G-vec00097-001-s156><arrive.ankommen><en> He said: “This result is very important because I extend three points on Jorge, but especially to arrive in front of him in the race is important and to have a small advantage at the end of the first part of the championship.
<G-vec00097-001-s157><arrive.ankommen><de> Welche Wohltat, nach dem doch sehr hektischen und überfüllten Vietnam in Laos anzukommen.
<G-vec00097-001-s157><arrive.ankommen><en> What an ease to arrive in Laos after the very hectic and crowded Vietnam.
<G-vec00097-001-s158><arrive.ankommen><de> Der Bahnhof Tiburtina von Rom ist ein Knotenpunkt für nationale und internationale Züge, aber auch Ausgangspunkt für zahlreiche Autobusse der Stadtlinie und der Metro – somit der perfekte Ort, um anzukommen, aber auch um aufzubrechen, um Rom wirklich zu 360 Grad zu erleben.
<G-vec00097-001-s158><arrive.ankommen><en> Rome's Tiburtina Station is a junction for national and international trains, as well as the departure point for many of the city's bus and subway lines – not just the perfect place to arrive, but the best starting point for your 360-degree exploration of Rome.
<G-vec00097-001-s159><arrive.ankommen><de> Darüber hinaus zeigen die Forscher, dass die Schimpansen für den Erwerb dieser Früchte ihre Nester morgens früher verlassen (oft noch im Dunkeln, wenn Leoparden auf der Jagd sind), um vor allen anderen am Frühstücksort anzukommen.
<G-vec00097-001-s159><arrive.ankommen><en> Moreover, the researchers found that they leave their nest earlier (and often in the dark when leopards are more likely to attack) for these fruits in order to arrive before others, especially when the breakfast sites were far away.
<G-vec00097-001-s160><arrive.ankommen><de> Wenn Sie beispielsweise ein Spiel an einem Sonntag sehen möchten, würden Sie idealerweise Ihre Reise buchen, um am Freitag anzukommen und am Dienstag abreisen.
<G-vec00097-001-s160><arrive.ankommen><en> So, for example, if you want to see a match on a Sunday then you ideally would book your journey to arrive Friday and to return Tuesday.
<G-vec00097-001-s161><arrive.ankommen><de> Emmers Ereignis begann mit 3 P.M. Wir hatten beabsichtigt, früh anzukommen, aber, weil Bob Kopien von der Literatur an einem photokopierenden Geschäft erstellen musste, kamen wir um die Zeit an, die das Ereignis begann.
<G-vec00097-001-s161><arrive.ankommen><en> Emmer's event started at 3 p.m. We had intended to arrive early but, because Bob had to make copies of literature at a photocopying shop, we arrived around the time the event started.
<G-vec00097-001-s162><arrive.ankommen><de> Ich musste mehrmals, dass die Sendung nur langsam anzukommen beschweren.
<G-vec00097-001-s162><arrive.ankommen><en> I had to complain several times that the shipment has been slow to arrive.
<G-vec00097-001-s163><arrive.ankommen><de> Nehmen somme Ihres Penis bezogenen Anliegen zu verwalten und machen eine äußerst konstruktive Änderung, die Sie und Ihre Mitarbeiter werden zweifellos von jetzt und für mehrere vielen Jahren anzukommen zu gewinnen.
<G-vec00097-001-s163><arrive.ankommen><en> Take somme manage of your penis related concerns and make a hugely constructive change that you and your associate will undoubtedly gain from now and for several many years to arrive.
<G-vec00097-001-s164><arrive.ankommen><de> Es ist dann normal, es im Syndikalisierungsatz, in der Gewohnheit wiederzufinden, die Fachleute an der Spitze der Unternehmen zu stellen in der Entwicklung der Lehre, die durch die alten gelenkt wurde, die Tatsache, daß das Unternehmen sich verpflichtet, diese Lehrlinge zu rekrutieren und ihnen für die besten erlaubt, in der Generaldirektion anzukommen.
<G-vec00097-001-s164><arrive.ankommen><en> It is then normal to find it in the rate of unionization, in the practice to put the professionals at the head of the companies, in the development of the training directed by the old ones, the fact that the company begins to recruit these apprentices and allow them for the best to arrive at the general direction.
<G-vec00097-001-s165><arrive.ankommen><de> Diese Sehnsucht, tief in meinem Herzen verankert, trieb mich 1988 ins Elsass, um mit meinem damaligen Ehemann meinen Traum zu verwirklichen, ein idyllisches Landhaus umzubauen, um so endlich anzukommen.
<G-vec00097-001-s165><arrive.ankommen><en> In 1988 this yearning deep in my heart took me to the Alsace to realize my dream and rebuild an idyllic cottage together with my former husband and thus to finally arrive home.
<G-vec00097-001-s166><arrive.ankommen><de> Fahrer und Flotten müssen auch für härteste Winterbedingungen gerüstet sein, um teure Ausfallzeiten zu vermeiden und sicher am Ziel anzukommen.
<G-vec00097-001-s166><arrive.ankommen><en> To avoid expensive downtime and to arrive at destinations safely, drivers and fleets must be equipped adequately to also deal with harsh winter conditions.
<G-vec00097-001-s167><arrive.ankommen><de> "Und man kann zu erfrischen die Gefühle »versuchen"": zum Klub getrennt anzukommen, die zufällige Bekanntschaft, natanzewatsja genug, und später zu spielen, nach Hause abzufahren (natürlich den Anschein gegeben, was das Haus jemand einen von Ihnen sind)."
<G-vec00097-001-s167><arrive.ankommen><en> "And it is possible to try ""to refresh feelings"": to arrive to club separately, to play casual acquaintance, to dance to the heart's content much, and then to leave home (having pretended, of course, that is the house someone one of you)."
<G-vec00097-001-s168><arrive.ankommen><de> Dem Kommando dieser Abteilung durch die Zusammenhängenden war die Verfügung übergeben, im Stab der Vereinigung anzukommen.
<G-vec00097-001-s168><arrive.ankommen><en> The order to arrive to force staff was transmitted to command of this group through coherent.
<G-vec00097-001-s169><arrive.ankommen><de> "Über Radwege kommen wir in das hektische Leben der ""Stadt Porteña"", um im Herzen der Innenstadt anzukommen, wo sich der May Square befindet."
<G-vec00097-001-s169><arrive.ankommen><en> Over bike paths, we will get into the frenetic life of the “city porteña” to arrive in the heart of downtown, where May Square is located.
<G-vec00097-001-s170><arrive.ankommen><de> Bitte stellen Sie sicher, dass Sie zu Hause sind, wenn Pakete werden erwartet, um anzukommen.
<G-vec00097-001-s170><arrive.ankommen><en> • Please make sure you are at home when packages are expected to arrive.
