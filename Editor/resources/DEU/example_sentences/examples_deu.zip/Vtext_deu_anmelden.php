<G-vec00060-001-s087><announce.anmelden><de> Auf eine Reihe seiner Erfindungen konnte er mit Erfolg internationale Patente anmelden - nicht nur zum Thema Licht übrigens.
<G-vec00060-001-s087><announce.anmelden><en> On a number of its inventions it could announce international patents with success - not only about light by the way.
<G-vec00060-001-s088><announce.anmelden><de> Die Anmeldung für die Woche ist denkbar einfach: Auf der Online-Plattform mit gültiger eMail-Adresse registrieren, anmelden, Plätze buchen – fertig.
<G-vec00060-001-s088><announce.anmelden><en> The registration for the week is very easy: On on-line platform with valid email address register, announce, places book - completely.
<G-vec00060-001-s089><announce.anmelden><de> Der Gewinner wird auf dieser Seite erscheinen, und wir werden über Twitter und Facebook anmelden.
<G-vec00060-001-s089><announce.anmelden><en> The winner will appear on this page and we will announce via Twitter and Facebook.
<G-vec00060-001-s090><announce.anmelden><de> "Zum kommenden Wettbewerb ""Beste Arbeitgeber im Gesundheitswesen 2008"" können sich alle schwerpunktmäßig im Bereich der Pflege kranker, alter und behinderter Menschen tätigen Einrichtungen aus Deutschland ab 20 Beschäftigten ab sofort anmelden."
<G-vec00060-001-s090><announce.anmelden><en> To the coming competition “best employers in the health service 2008” can announce themselves all in particular within the range of the care ill, old and handicapped humans active mechanisms from Germany starting from 20 persons employed immediately.
<G-vec00060-001-s091><announce.anmelden><de> Süd sagt zu diesem Zeitpunkt nichts, da Nord-Süd gegenwärtig die Wette gewinnt, aber wenn Ost anmeldet, dann würde Süd freudig 31 anmelden, und Nord-Süd würde gewinnen, da Süd Vorrang vor Ost hat.
<G-vec00060-001-s091><announce.anmelden><en> South would be silent at this point as North-South are currently winning the bet, but when East declares, South would then happily announce 31 and North-South would win, since South has priority over East.
<G-vec00060-001-s092><announce.anmelden><de> Für die Abgabe der Umsatzsteuer-Voranmeldungen können Sie eine Dauerfristverlängerung beantragen und bei Bedarf eine jährliche Sondervorauszahlung anmelden.
<G-vec00060-001-s092><announce.anmelden><en> To submit advance sales tax returns, you can request a permanent extension and announce an annual special prepayment, if required.
<G-vec00060-001-s093><announce.anmelden><de> Die Anmeldung für die Woche ist denkbar einfach: Auf der Online-Plattform mit gültiger eMail-Adresse registrieren, anmelden, Plätze buchen â fertig.
<G-vec00060-001-s093><announce.anmelden><en> The registration for the week is very easy: On on-line platform with valid email address register, announce, places book - completely.
<G-vec00060-001-s094><announce.anmelden><de> Selbst Mitarbeiter oder Mitglieder, die ihren PC „nicht nur ausschließlich“ privat nutzen, müssen diesen Internet-PC anmelden.
<G-vec00060-001-s094><announce.anmelden><en> Even coworkers or members, who use their PC „not only exclusively “privately, must announce this internet PC.
<G-vec00060-001-s095><announce.anmelden><de> Gleichzeitig können Sie bei monatlicher Abgabefrist der Umsatzsteuer-Voranmeldung die jährliche Sondervorauszahlung anmelden.
<G-vec00060-001-s095><announce.anmelden><en> You can also announce the annual special prepayment if you have to submit the advance sales tax return each month.
<G-vec00060-001-s096><announce.anmelden><de> Wenn Sie Flor haben, müssen Sie das anmelden bevor Sie zum ersten Stich spielen und bevor Sie jegliche Wetten platzieren oder annehmen.
<G-vec00060-001-s096><announce.anmelden><en> If you have Flor you must announce it before playing to the first trick, and before making or accepting any other kinds of bets.
<G-vec00206-002-s095><account.anmelden><de> Falls Sie in Zukunft keine solche E-Mails mehr erhalten möchten, können Sie diese jederzeit abbestellen, indem Sie in einer der E-Mails, die Sie von uns erhalten, auf den entsprechende Abmeldelink klicken oder indem Sie sich auf unserer Webseite mithilfe Ihrer E-Mail-Adresse und Ihrem Kennwort bei Ihrem Corel-Konto anmelden und dann auf die Option „Kommunikationseinstellungen verwalten" klicken.
<G-vec00206-002-s095><account.anmelden><en> You may opt-out of receiving such future emails by clicking the unsubscribe link in any email you receive, or by signing into your Corel account through our website using your email address and password, and clicking on Manage Your Communication Preferences.
<G-vec00206-002-s096><account.anmelden><de> Dafür müssen diese Kontakte nur Skype herunterladen und sich mit ihrem Messenger-Konto anmelden.
<G-vec00206-002-s096><account.anmelden><en> All they need to do is get Skype and sign in with their Messenger account.
<G-vec00206-002-s097><account.anmelden><de> Auf diese Weise können auf jedem Endgerät auf dem Sie sich mit Ihrem Google-Konto anmelden, dieselben personalisierten Werbebotschaften geschaltet werden.
<G-vec00206-002-s097><account.anmelden><en> This way, the same personalised advertising messages can appear on any device you use to sign in to your Google Account.
<G-vec00206-002-s098><account.anmelden><de> Sparen Sie noch mehr Zeit, indem Sie sich über Ihr Amazonkonto anmelden.
<G-vec00206-002-s098><account.anmelden><en> Save yourself even more time - login using your Amazon account.
<G-vec00206-002-s099><account.anmelden><de> Aus diesem Grund sollten Sie sich als Root ausschließlich zur Systemwartung oder -administration anmelden.
<G-vec00206-002-s099><account.anmelden><en> For this reason, the root account is best used only to perform system maintenance or administration.
<G-vec00206-002-s100><account.anmelden><de> Wenn Sie sich mit einem anderen Domänenkonto bei der Provisioning Services Console anmelden, können Sie möglicherweise nicht auf die Farm zugreifen.
<G-vec00206-002-s100><account.anmelden><en> When you log on to the Provisioning Services Console using a different domain account, you might not be able to access the farm.
<G-vec00206-002-s101><account.anmelden><de> Dann können sie die Zahlung annehmen, indem sie sich bei PayPal anmelden oder registrieren (das geht schnell und einfach).
<G-vec00206-002-s101><account.anmelden><en> If your recipients already have a PayPal account, they can claim the payment by logging in to their account.
<G-vec00206-002-s102><account.anmelden><de> Wenn Sie sich bei Microsoft-Produkten mit einem Arbeits- oder Schulkonto anmelden, kann der Besitzer, der mit Ihrer E-Mail-Adresse verbundenen Domäne, Ihr Konto sowie den Zugang zu Ihren Daten und die Verarbeitung Ihrer Daten, einschließlich der Inhalte Ihrer Mitteilungen und Dateien, kontrollieren und administrieren.
<G-vec00206-002-s102><account.anmelden><en> If you sign into Microsoft products with a work or school account, the owner of the domain associated with your email address may control and administer your account, and access and process your data, including the contents of your communications and files.
<G-vec00206-002-s103><account.anmelden><de> – Einfach mit Facebook-Account anmelden und Lieblingsgeräte direkt Teilen oder Senden.
<G-vec00206-002-s103><account.anmelden><en> – Simply log in with Facebook account and share or send favorite devices directly.
<G-vec00206-002-s104><account.anmelden><de> Stellen Sie zum Beheben dieses Problems sicher, dass Sie sich bei Ihrem Microsoft-Konto anmelden können.
<G-vec00206-002-s104><account.anmelden><en> To resolve this issue, verify that you can sign in to your Microsoft account.
<G-vec00206-002-s105><account.anmelden><de> Das erste Mal, wenn Sie sich in Ihrem Dynadot-Konto anmelden, bitten wir Sie, eine geheime Frage und Antwort einzurichten.
<G-vec00206-002-s105><account.anmelden><en> The first time you login to your Dynadot account, we ask you to set up a secret question and answer.
<G-vec00206-002-s106><account.anmelden><de> Um Spiele mit Ihren Facebook-Freunden zu spielen, müssen Sie sich mit Ihrem Facebook-Konto anmelden.
<G-vec00206-002-s106><account.anmelden><en> In order to play matches with Your Facebook friends, you need to login with your Facebook account.
<G-vec00206-002-s107><account.anmelden><de> Als angemeldeter Benutzer müssen Sie nicht jedes Mal Ihre persönlichen Daten angeben, sondern Sie können sich vor oder im Rahmen einer Bestellung einfach mit Ihrer E-Mail-Adresse und dem von Ihnen bei Registrierung frei gewählten Passwort in Ihrem Kundenkonto anmelden.
<G-vec00206-002-s107><account.anmelden><en> With a customer account you must not enter your personal data every time you use our online shop, but you may log on to your customer account before or during an order with your e-mail address and the password, which you have chosen during the registration process.
<G-vec00206-002-s108><account.anmelden><de> Wenn Sie ein Upgrade Ihres bestehenden MEE-Servers durchführen, müssen Sie sich zunächst über das integrierte Administratorkonto anmelden und sicherstellen, dass Sie über die richtigen Anmeldeinformationen verfügen.
<G-vec00206-002-s108><account.anmelden><en> If you are upgrading your existing MEE server it is important to log in with the built-in admin account first and ensure you have the correct credentials.
<G-vec00206-002-s109><account.anmelden><de> Teilen von Fotos und Videos auf Flickr Sie müssen sich bei Ihrem Flickr-Konto anmelden, um Fotos oder Videos hochladen zu können.
<G-vec00206-002-s109><account.anmelden><en> Sharing photos and videos on Flickr Log in to your Flickr account before you upload photos or videos.
<G-vec00206-002-s110><account.anmelden><de> Gib einfach deine e-Mail Adresse ein und klicke auf "Für Newsletter anmelden".
<G-vec00206-002-s110><account.anmelden><en> Enter your e-mail address below and click on "Get Account" to
<G-vec00206-002-s111><account.anmelden><de> Außerdem können Sie eine Übersicht Ihrer von Volvo Cars gespeicherten personenbezogenen Kundendaten einsehen und Ihre Informationen korrigieren oder aktualisieren, indem Sie sich im Verbraucherportal von Volvo Cars oder einem vergleichbaren, auf Ihrem örtlichen Markt angebotenen Dienst anmelden.
<G-vec00206-002-s111><account.anmelden><en> In addition, you may be able to access an overview of certain Customer-provided personal data held by Volvo Cars, and correct or update your information, by logging in to your MyVolvo account. Security
<G-vec00206-002-s112><account.anmelden><de> Eine andere Möglichkeit ist, dass Sie sich bei dem Apple-Konto anmelden, mit dem Sie die Videos im iTunes Store gekauft haben, dann können Sie diese Dateien mit iTunes, aber nicht mit dem VLC wiedergeben.
<G-vec00206-002-s112><account.anmelden><en> Another way is to sign in Apple account that you used to buy videos from iTunes store, then you can play these files on iTunes, but note that this doesn't play with VLC.
<G-vec00206-002-s113><account.anmelden><de> Mit dieser App müssen Sie sich nicht einmal auf Ihrem Instagram-Konto anmelden, um neue Fotos und mehr zu checken.
<G-vec00206-002-s113><account.anmelden><en> With this app, you don’t even need to log onto your Instagram account to check out new photos, like a photo, and more.
<G-vec00228-002-s022><nominate.anmelden><de> Ein Familienoberhaupt kann über die Website maximal sieben Familienmitglieder anmelden, die mindestens zwei Jahre alt sind.
<G-vec00228-002-s022><nominate.anmelden><en> The Family Head may nominate via the Website, a maximum of seven Family Members aged two or above.
<G-vec00239-002-s037><enroll.anmelden><de> Dabei verarbeiten wir Ihre personenbezogenen Daten auf der Grundlage der Vertragserfüllung (Artikel 6 Absatz 1 lit b DSGVO), um Sie zu dem gewünschten Seminar anzumelden.
<G-vec00239-002-s037><enroll.anmelden><en> We process your personal data on the basis of the initiation at your request/performance of a contract pursuant to Article 6 (1) (b) GDPR to enroll you for the desired seminar.
<G-vec00239-002-s038><enroll.anmelden><de> Suche dein örtliches PADI Tauchcenter auf, um dich für den Kurs anzumelden und dein PADI Sidemount Diver and Tec Sidemount Diver Manual (das Buch zum Kurs) zu erhalten.
<G-vec00239-002-s038><enroll.anmelden><en> Visit our Diving Center to enroll in the course and get your PADI Sidemount Diver and Tec Sidemount Diver Manual. The Scuba gear you will use
<G-vec00239-002-s039><enroll.anmelden><de> Es gibt keine obligatorischen Impfungen für ein Kind in staatlichen Schule anzumelden, obwohl einige private Schulen ihre eigenen Anforderungen haben können.
<G-vec00239-002-s039><enroll.anmelden><en> There are no mandatory vaccinations to enroll a child in state school, although some private schools may have their own requirements.
<G-vec00369-002-s152><sign.anmelden><de> Sind Sie bereit sich anzumelden, dann klicken Sie bitte hier.
<G-vec00369-002-s152><sign.anmelden><en> If you're ready to apply, click here to sign up as an Affiliate!
<G-vec00369-002-s153><sign.anmelden><de> Zusätzlich zur Anmeldung via E-Mail habt ihr auch die Möglichkeit, euch direkt an unserem Stand auf der gamescom in Halle 6.1, B21 für den Tanzwettbewerb anzumelden.
<G-vec00369-002-s153><sign.anmelden><en> You will also have the opportunity to sign up for this contest directly at gamescom by visiting our booth, located at hall 6, B21 and B31 and asking for the Dance Contest sign up.
<G-vec00369-002-s154><sign.anmelden><de> Das klingt schon extrem sinnig und ich bin mir sicher, dass einige Leser an dieser Stelle bereits auf dem Weg zu Google sind, um den Weg zur Partner Network-Seite in Erfahrung zu bringen und sich dort anzumelden.
<G-vec00369-002-s154><sign.anmelden><en> This sounds extremely smart and I’m certain some of you might have stopped reading already, googling the Partner Network site and trying to sign up.
<G-vec00369-002-s155><sign.anmelden><de> Deshalb ist es wichtig, sich bei mehreren Anbietern anzumelden und sicherzustellen, dass verschiedene Arten von Spielen verfügbar sind.
<G-vec00369-002-s155><sign.anmelden><en> That’s why it’s important to sign up with multiple software providers and ensure that different kinds of game are available.
<G-vec00369-002-s156><sign.anmelden><de> Um dich für Etsy Payments anzumelden und Zahlungen für über Etsy Payments erfolgte Transaktionen zu erhalten, musst du gültige Kontoinformationen für ein Bankkonto in Australien, Kanada, der Europäischen Union, Hongkong, Neuseeland, Norwegen, Singapur, der Schweiz oder den USA bereitstellen.
<G-vec00369-002-s156><sign.anmelden><en> For you to sign up for Etsy Payments and receive payment for transactions made through Etsy Payments, you must provide valid account information for a bank account in the United States, Australia, Canada, the European Union, Hong Kong, New Zealand, Norway, Singapore, or Switzerland.
<G-vec00369-002-s157><sign.anmelden><de> Unter Umständen müssen Sie Ihre Zahlungsinformationen eingeben, um sich für die kostenlose Testversion anzumelden.
<G-vec00369-002-s157><sign.anmelden><en> You may be required to enter your billing information in order to sign up for the Free Trial.
<G-vec00369-002-s158><sign.anmelden><de> Klicken Sie auf Start und Sie werden aufgefordert, bei Ihrem iCloud- oder iTunes-Konto anzumelden.
<G-vec00369-002-s158><sign.anmelden><en> (2) You will be prompted to sign in using your iCloud details.
<G-vec00369-002-s159><sign.anmelden><de> Wenn Sie von dem Signalanbiete aufgefordert werden sich bei einem Broker anzumelden, ist es sehr wahrscheinlich, dass es ein Marketing-Scam ist (nicht immer, aber doch meistens).
<G-vec00369-002-s159><sign.anmelden><en> If the signal will ask you to sign up at a broker to use it then it’s highly likely it’s a marketing scam (not always, but most of the time).
<G-vec00369-002-s160><sign.anmelden><de> Verantwortung der Eltern Sie müssen Ihr Kind zu Anfang jedes Besuches begleiten, um es dort anzumelden.
<G-vec00369-002-s160><sign.anmelden><en> You need to accompany your children to Play Time to sign them in at the beginning of each session.
<G-vec00369-002-s161><sign.anmelden><de> Es gibt üblicherweise keine bestimmten Anforderungen, um sich für einen E-ZPass anzumelden.
<G-vec00369-002-s161><sign.anmelden><en> There are usually not specific requirements to sign up for an E-Z Pass.
<G-vec00369-002-s162><sign.anmelden><de> „Ich entschied mich für den Gewichtsverlust-Programm anzumelden, weil ich eine Empfehlung von einem Freund, der an dem Programm teilgenommen hatte, bekam.
<G-vec00369-002-s162><sign.anmelden><en> “I decided to sign up for the weight loss programme because I had got a recommendation for it from acquaintances who had attended it before.
<G-vec00369-002-s163><sign.anmelden><de> Um die Sicherheit Ihrer Daten zu gewährleisten, wird dafür diejenige E-mail-Adresse benötigt, die Sie verwendet haben, um sich für Ihr persönliches Konto anzumelden.
<G-vec00369-002-s163><sign.anmelden><en> To ensure the security of your data, you will need the e-mail address you used to sign up for your personal account.
<G-vec00369-002-s164><sign.anmelden><de> Sie können uns jederzeit per E-Mail erreichen, um sich für die Veranstaltungen anzumelden.
<G-vec00369-002-s164><sign.anmelden><en> You can email us any time to sign up for the activities.
<G-vec00369-002-s165><sign.anmelden><de> Wir weisen darauf hin, dass es für die WLAN-Nutzung im Center nicht erforderlich ist, sich für das VIP-Programm anzumelden.
<G-vec00369-002-s165><sign.anmelden><en> Please note that it is not mandatory to sign up to the VIP Programme in order to connect to the Wi-Fi at the Centre.
<G-vec00369-002-s166><sign.anmelden><de> Anmeldedaten: Um sich für den Newsletter anzumelden, reicht es aus, wenn Sie Ihre E-Mailadresse angeben.
<G-vec00369-002-s166><sign.anmelden><en> Login-data: in order to sign up for the newsletter it is sufficient to provide your email address.
<G-vec00369-002-s167><sign.anmelden><de> Internetdienstanbieter (ISPs) können die serverbasierte Anmeldefunktion nicht verwenden, um Kunden über das Internet anzumelden.
<G-vec00369-002-s167><sign.anmelden><en> Internet Service Providers (ISPs) cannot use the server-based sign-up feature to sign up customers over the Internet.
<G-vec00369-002-s168><sign.anmelden><de> Um mit uns Kontakt aufzunehmen, einen Ausbildungskatalog anzufordern oder sich für einen unserer Kurse anzumelden, füllen Sie bitte dieses Formular aus.
<G-vec00369-002-s168><sign.anmelden><en> To contact us, to sign up for one of our courses, or to request a training catalog, please fill in this form.
<G-vec00369-002-s169><sign.anmelden><de> Ebenfalls am Freitag schrieb Bildungsminister Kevin Yeung Yun-hung einen offenen Brief an die Schulleiter, Lehrer, Schüler und ihre Eltern und forderte sie auf, sich für kostenlose Tests anzumelden.
<G-vec00369-002-s169><sign.anmelden><en> Also on Friday, Secretary for Education Kevin Yeung Yun-hung wrote an open letter to the city's principals, teachers, students and their parents, calling on them to sign up for free tests.
<G-vec00369-002-s170><sign.anmelden><de> Alles, was Sie tun müssen, ist sich bei einem Casino anzumelden und Sie müssen möglicherweise Ihr Konto überprüfen.
<G-vec00369-002-s170><sign.anmelden><en> All you need to do is sign up with a casino and you may be required to verify your account.
<G-vec00377-002-s095><register.anmelden><de> Die Basisstation kann währenddessen auch im Ruhezustand ein Signal senden um ein Mobilteil anzumelden.
<G-vec00377-002-s095><register.anmelden><en> Meanwhile, the base station may also send a signal when it is in sleep mode in order to register a handset.
<G-vec00377-002-s096><register.anmelden><de> Vergiss nicht, dein Projekt anzumelden, damit wir deine Kontaktinformationen haben.
<G-vec00377-002-s096><register.anmelden><en> Make sure to register your project so we have your contact information.
<G-vec00377-002-s097><register.anmelden><de> Und seit 2006 ist es in der Europäischen Union sogar möglich, grenzüberschreitende, europäische Genossenschaften anzumelden.
<G-vec00377-002-s097><register.anmelden><en> And since 2006, it has even been possible to register cross-border European cooperatives inside the European Union.
<G-vec00377-002-s098><register.anmelden><de> In der Vergangenheit war es nötig eine Aufenthaltsgenehmigung (Ikamet) zu besitzen, um in der Türkei ein KfZ zu erwerben und anzumelden.
<G-vec00377-002-s098><register.anmelden><en> In the past it was necessary to have a residence permit (Ikamet) to buy and register a car in Turkey.
<G-vec00377-002-s099><register.anmelden><de> Die Verpackungsgesetzgebung verpflichtet Erstinverkehrbringer von Verkaufsverpackungen, ihre Produzentenverantwortung wahrzunehmen und ihre Verpackungen zur Sammlung und Verwertung bei einem dualen System anzumelden.
<G-vec00377-002-s099><register.anmelden><en> European packaging legislation requires initial distributors of sales packaging to honour their product responsibility and register their packaging with a recycling system provider (dual system) for collection and recycling.
<G-vec00377-002-s100><register.anmelden><de> Wenn Sie unser API im Auftrag eines Unternehmens oder einer anderen Rechtspersönlichkeit zur Entwicklung vewenden, gewährleisten Sie, dass Sie die vollständige rechtliche Vollmacht haben, eine Anwendung im Auftrag dieser Rechtspersönlichkeit anzumelden und jene an diese Bedingungen zu binden.
<G-vec00377-002-s100><register.anmelden><en> If you are developing on our API on behalf of a company or other entity, you represent and warrant that you have full legal authority to register an Application on behalf of that entity and bind it to these Terms.
<G-vec00377-002-s101><register.anmelden><de> Nachfolgend sehen Sie, welche Dokumente erforderlich sind, um Ihr Schiff bei der maltesischen Registrierung anzumelden.
<G-vec00377-002-s101><register.anmelden><en> Please see below which documents are necessary in order to register your vessel with the Maltese Registration.
<G-vec00377-002-s102><register.anmelden><de> Gesellschaften ab 20 Personen sind möglichst frühzeitig, spätestens fünf Tage vor Reiseantritt, anzumelden.
<G-vec00377-002-s102><register.anmelden><en> Groups of 20 or more people should register as soon as possible and at the latest 5 days before the intended cruise.
<G-vec00377-002-s103><register.anmelden><de> In diesem Fall ist das Fahrrad vor Fahrtantritt telefonisch beim Kundenservice anzumelden (siehe die Bestimmungen für das Sondergepäck).
<G-vec00377-002-s103><register.anmelden><en> In such a case, you must call customer service in advance to register the bicycle (see regulations for special luggage).
<G-vec00377-002-s104><register.anmelden><de> Eine Geruchsmarke in der Europäischen Union anzumelden ist zwar theoretisch möglich, doch in Praxis bisher schwer umzusetzen.
<G-vec00377-002-s104><register.anmelden><en> Although it is theoretically possible to register an scent trademark in the European Union, it has so far been difficult to do so in practice.
<G-vec00377-002-s105><register.anmelden><de> Um ein Modul im Studium Generale anzumelden, reicht eine formlose E-Mail an das Studienbüro.
<G-vec00377-002-s105><register.anmelden><en> In order to register a Studium Generale module, all you need to do is send an informal e-mail to the Office for Student Affairs.
<G-vec00377-002-s106><register.anmelden><de> Denken Sie auf jeden Fall daran, Ihren neuen Namen als Marke anzumelden.
<G-vec00377-002-s106><register.anmelden><en> Don't forget to register your name as a trademark in order to protect it.
<G-vec00377-002-s107><register.anmelden><de> NEIN - sie braucht sich nicht bei den Behörden anzumelden, um dort weniger als drei Monate mit Ihnen zu leben; sie kann allerdings dazu aufgefordert werden, ihre Anwesenheit zu melden.
<G-vec00377-002-s107><register.anmelden><en> NO - To live with you there for less than 3 months, she does not need to register with the authorities, though she might be asked to report her presence.
<G-vec00377-002-s108><register.anmelden><de> Hier finden Sie alle notwendigen Informationen um Gäste bei uns anzumelden.
<G-vec00377-002-s108><register.anmelden><en> You will find all the necessary information in order to register guests with us here.
<G-vec00377-002-s109><register.anmelden><de> Um sich bei der besten, regulierten Plattform anzumelden und Geld zu verdienen, klicken Sie hier.
<G-vec00377-002-s109><register.anmelden><en> To register and earn money through the best regulated platform, click here.
<G-vec00377-002-s110><register.anmelden><de> Weiterhin ist die Auflegung des RAIF beim Luxemburger Handelsund Gesellschaftsregister anzumelden, die zentrale Verwaltung des RAIF muss in Luxemburg stattfinden.
<G-vec00377-002-s110><register.anmelden><en> Establishment of a RAIF must be registered on a list held by Luxembourg’s trade and companies register, and the RAIF must be managed by a Luxembourg-based management company.
<G-vec00377-002-s111><register.anmelden><de> Zu Beginn ist auch dieser Bildschirm noch leer und Sie können über die "+"-Funktion in das "ADD DEVICE"- Menü gelangen um hier Ihre vorhanden Geräte anzumelden.
<G-vec00377-002-s111><register.anmelden><en> At the beginning and this screen is empty and you can use the "+" - function in the "Add Device" - menu access to register your available devices here.
<G-vec00377-002-s112><register.anmelden><de> In diesen Fällen wäre der Empfänger der Leistungen dazu verpflichtet, den Erbringer als Angestellten für fremde Rechnung bei der Sozialversicherung anzumelden und seine steuerlichen und sozialen Verpflichtungen in Spanien zu erfüllen.
<G-vec00377-002-s112><register.anmelden><en> If these cases, the service receiver is actually your employer, and they are required to register you with the social security as an employee and meet their tax and employer obligations in Spain.
<G-vec00377-002-s113><register.anmelden><de> Jedes Mitglied verpflichtet sich, über seine Person keine falschen oder missverständlichen Angaben zu machen und sich insbesondere nicht unter einer falschen Identität anzumelden.
<G-vec00377-002-s113><register.anmelden><en> Each member agrees not to provide false or misleading personal information, and, in particular, agrees not to register under a false identity.
<G-vec00239-003-s095><sign_up.anmelden><de> Wenn Sie über ein Konto verfügen und sich auf dieser Website anmelden, setzen wir ein temporäres Cookie, um festzustellen, ob Ihr Browser Cookies akzeptiert.
<G-vec00239-003-s095><sign_up.anmelden><en> If you have an account and sign up for this site, we’ll set a temporary cookie to see if your browser accepts cookies.
<G-vec00239-003-s096><sign_up.anmelden><de> Die Auswahl einer Vorlage kann entweder erfolgen, wenn Sie sich zunächst beim Editor anmelden oder indem Sie eine andere Vorlage über die Vorlagenauswahl auswählen.
<G-vec00239-003-s096><sign_up.anmelden><en> Choosing a template can either be done when you initially sign up to the editor, or by selecting another one via the Template picker.
<G-vec00239-003-s097><sign_up.anmelden><de> Magazine schickt Ihnen seine besten Produktivitäts-Tipp zusammen mit seinem beliebten Kurs „In 10 Schritten zur maximalen Produktivität“, wenn Sie sich bei Nozbe anmelden.
<G-vec00239-003-s097><sign_up.anmelden><en> Magazine will send you his best productivity advice along with his popular "10-Steps to Ultimate Productivity" course when you sign up for Nozbe.
<G-vec00239-003-s098><sign_up.anmelden><de> Falls Sie noch kein myTalkTalk Kundenkonto haben, können Sie hier anmelden.
<G-vec00239-003-s098><sign_up.anmelden><en> If you do not have a myTalkTalk customer account, you can sign up here.
<G-vec00239-003-s099><sign_up.anmelden><de> Um sich bei Ihrem Konto anzumelden, klicken Sie auf "Anmelden" und geben Sie Ihr E-Mail-Konto und Ihr Passwort ein.
<G-vec00239-003-s099><sign_up.anmelden><en> To sign in to your account, click "Sign In" and enter the email address and password.
<G-vec00239-003-s100><sign_up.anmelden><de> Falls Sie in einem Kurs keine Prüfung machen (sondern nur eine Teilnahmebestätigung brauchen), müssen Sie sich nicht für die dazugehörige Prüfung anmelden.
<G-vec00239-003-s100><sign_up.anmelden><en> If you're not taking an exam in a course, you do not need to sign up for the exam.
<G-vec00239-003-s101><sign_up.anmelden><de> Deutschland Österreich België Schweiz Česká republika Solltest Du Dich für den Newsletter anmelden, bekommst Du als Erstanmelder einen 10 € Gutschein (Mindesteinkaufswert 100 €).
<G-vec00239-003-s101><sign_up.anmelden><en> Shipping Options Language sign up for the newsletter, you will receive a €10 voucher as first applicant (minimum purchase €100).
<G-vec00239-003-s102><sign_up.anmelden><de> Wenn Sie sich als Mitglied anmelden, werden Sie auch gebeten, einen Benutzernamen und ein Passwort auszuwählen.
<G-vec00239-003-s102><sign_up.anmelden><en> When you sign up to become a Member, you will also be asked to choose a password.
<G-vec00239-003-s103><sign_up.anmelden><de> Zum Erstellen einer Umfrage mithilfe der Vorlage zum Austrittsgespräch von Mitarbeitern müssen Sie sich lediglich bei SurveyMonkey registrieren oder anmelden.
<G-vec00239-003-s103><sign_up.anmelden><en> To create a survey using the Employee Exit survey template, just sign up or sign in to SurveyMonkey.
<G-vec00239-003-s104><sign_up.anmelden><de> Sie können sich innerhalb von wenigen Minuten anmelden und sich für die GMAT test in Vallendar registrieren.
<G-vec00239-003-s104><sign_up.anmelden><en> You can within few minutes sign up and register for the GMAT test in Santiago de Querétaro.Find the list of availabilities below.
<G-vec00239-003-s105><sign_up.anmelden><de> Sie können sich für unsere Seminare im Komplementärstudium über myStudy anmelden, indem Sie die Seminare mit dem Kürzel „FSL-SZ“ im Titel suchen.
<G-vec00239-003-s105><sign_up.anmelden><en> To register for our courses within Complementary Studies, sign into myStudy and look for the seminar titles that include the abbreviation “FSL-SZ.”
<G-vec00239-003-s106><sign_up.anmelden><de> Wenn Sie Mitglied in einer formellen Reaktionsgruppe sind, bei der Sie sich manuell anmelden müssen, bevor Sie Anrufe entgegennehmen können, sind Sie möglicherweise nicht bei der Gruppe angemeldet.
<G-vec00239-003-s106><sign_up.anmelden><en> If you are in a formal response group where you need to manually sign in to before you can take calls, you might not be signed in to the group.
<G-vec00239-003-s107><sign_up.anmelden><de> Wenn Sie MFA noch nicht konfiguriert oder nicht auf die MFA-Anforderung einer PIN geantwortet haben, können Sie sich nicht bei der App anmelden.
<G-vec00239-003-s107><sign_up.anmelden><en> If you haven't configured MFA or didn't respond to the MFA request for a PIN then you won't be able to sign in to the app.
<G-vec00239-003-s108><sign_up.anmelden><de> Geben Sie Ihre Emailadresse und Ihr Passwort ein und klicken Sie auf “anmelden”.
<G-vec00239-003-s108><sign_up.anmelden><en> Enter your email-adress and password and click “sign in”
<G-vec00239-003-s109><sign_up.anmelden><de> Zuerst müssen Sie sich für das Google AdSense-Programm anmelden.
<G-vec00239-003-s109><sign_up.anmelden><en> First, you need to sign up for Google AdSense.
<G-vec00239-003-s110><sign_up.anmelden><de> Mit Samsung Pass auf Websites anmelden Sie können sich mit Samsung Pass ganz einfach auf Websites anmelden, die das automatische Ausfüllen von IDs und Passwörtern unterstützen.
<G-vec00239-003-s110><sign_up.anmelden><en> Using Samsung Pass to sign in to websites You can use Samsung Pass to easily sign in to websites that support ID and password autofill.
<G-vec00239-003-s111><sign_up.anmelden><de> Zusätzlich zu Ihrem Log-in bei CareerBuilder.com, können Sie sich auch mit Ihrer Microsoft Windows Live ID anmelden, die Ihren Log-in authentifiziert.
<G-vec00239-003-s111><sign_up.anmelden><en> In addition to the CareerBuilder sign-in, CareerBuilder offers the ability to sign in using Microsoft Windows Live ID service, which provides authentication for online sign in.
<G-vec00239-003-s112><sign_up.anmelden><de> Klicken Sie auf das aktuell verwendete Konto oder geben Sie die Anmeldeinformationen für Ihr Microsoft OneDrive / Office 365-Administratorkonto ein und klicken Sie auf Anmelden.
<G-vec00239-003-s112><sign_up.anmelden><en> Click the account you are using, if available, or enter your Microsoft OneDrive / Office 365 administrator account credentials and click Sign in.
<G-vec00239-003-s113><sign_up.anmelden><de> Blossom: Darf ich noch sagen, Oliver, dass Interessierte sich anmelden können für meinen Newsletter, das kann man auf meiner Webseite tun, und jedes Mal wenn eine neue Botschaft gekommen ist, sende ich eine Benachrichtigung hinaus.
<G-vec00239-003-s113><sign_up.anmelden><en> Blossom: Can I just say, Oliver, people can sign up for my newsletter which they can do on my website, then whenever a new channeling has gone up I always send out a newsletter to let them know .
<G-vec00488-002-s032><declare.anmelden><de> Zweifel über die Gültigkeit des Zuschlages können nur Bieter des betreffenden Fohlens, der Auktionator oder der Veranstalter anmelden.
<G-vec00488-002-s032><declare.anmelden><en> Only bidders of the said foal, the auctioneer or the auction management are entitled to declare such doubts.
<G-vec00488-002-s033><declare.anmelden><de> Für jene Zigaretten, die Sie über diese Freimenge hinaus mitführen, müssen Sie die Tabaksteuer beim Zollamt unverzüglich (mündlich) anmelden und entrichten.
<G-vec00488-002-s033><declare.anmelden><en> You shall immediately declare (orally) any number of cigarettes in excess of this quantity at the customs office and pay tobacco duties.
<G-vec00488-002-s034><declare.anmelden><de> Viele Unternehmen mussten in den letzten Jahren Konkurs anmelden, die italienische Industrieproduktion ist auf das Niveau der 80er Jahre zurückgefallen.
<G-vec00488-002-s034><declare.anmelden><en> Many companies had to declare bankruptcy in the last years and the Italian industrial production fell back to the level of the 1980s.
<G-vec00488-002-s035><declare.anmelden><de> Fahrgäste können gegen Zahlung einer entsprechenden Gebühr eine Aufwertung bis zu einer Summe von 2,500 USD anmelden.
<G-vec00488-002-s035><declare.anmelden><en> Passengers may declare additional valuation, up to $2,500, upon payment of the applicable charge.
<G-vec00488-002-s036><declare.anmelden><de> Bei der Einreise nach und der Ausreise aus Luxemburg müssen Sie Geldbeträge ab 10 000 Euro oder dem Gegenwert in anderer Währung beim Zoll unter Verwendung eines bestimmten Formulars anmelden.
<G-vec00488-002-s036><declare.anmelden><en> When entering or leaving Spain, you must declare any sum of money of or equivalent to EUR 10 000 and above to customs using a specific form .
<G-vec00488-002-s037><declare.anmelden><de> Im Jahr 2009 musste die Firma allerdings Insolvenz anmelden und fand sich für ein Jahr unter dem Dach der Kienzle AG wieder.
<G-vec00488-002-s037><declare.anmelden><en> However, the company had to declare bankruptcy in 2009 and landed under control of Kienzle AG for one year.
<G-vec00488-002-s038><declare.anmelden><de> Ein fairer Wettbewerb mit identischen Ausgangsbedingungen kann dadurch nicht stattfinden, viele europäische Photovoltaikfirmen mussten in den letzten Jahren Insolvenz anmelden, teilbedingt durch die billige Konkurrenz aus China.
<G-vec00488-002-s038><declare.anmelden><en> A fair competition with equal starting points can therefore not take place. In the last years many European photovoltaic companies had to declare insolvency, partly due to the cheap Chinese competition.
<G-vec00488-002-s039><declare.anmelden><de> Als Endresultat dieser Krise mussten viele Banken und Unternehmen Insolvenz anmelden.
<G-vec00488-002-s039><declare.anmelden><en> The end result of this crisis is that many banks and business were forced to either close or declare bankruptcy.
<G-vec00488-002-s040><declare.anmelden><de> Wollen Sie Ihr Tier mit auf die Reise nehmen, müssen Sie dies rechtzeitig schriftlich bei Ihrer Fluggesellschaft oder dem Reiseveranstalter anmelden.
<G-vec00488-002-s040><declare.anmelden><en> If you want to take your animal with you, you must declare this to your airline company or tour operator on time and in writing.
<G-vec00488-002-s041><declare.anmelden><de> Spreadshirt wird die Steuer beim deutschen Bundeszentralamt für Steuern anmelden und an dieses abführen.
<G-vec00488-002-s041><declare.anmelden><en> Spreadshirt will declare and pay the taxes to Germany’s Federal Central Tax Office.
<G-vec00507-002-s190><log.anmelden><de> Um deine Reise nach Monastery of Rates zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s190><log.anmelden><en> To organise your trip to France, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s191><log.anmelden><de> Um deine Reise nach Niagara Falls Station zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s191><log.anmelden><en> To organise your trip to Perth, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s192><log.anmelden><de> Um deine Reise nach East Brunswick Township zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s192><log.anmelden><en> To organise your trip to Cambridge, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s193><log.anmelden><de> Um deine Reise nach Kirkkonummi zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s193><log.anmelden><en> To organise your trip to Siena, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s195><log.anmelden><de> Um deine Reise nach Casa-Voyageurs Station zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s195><log.anmelden><en> To organise your trip to Oualidia, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s196><log.anmelden><de> Um deine Reise nach Sizilien zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s196><log.anmelden><en> To organise your trip to Cosenza, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s197><log.anmelden><de> Um deine Reise nach Flughafen Washington Dulles (IAD) zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s197><log.anmelden><en> To organise your trip to Mahād, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s198><log.anmelden><de> Um deine Reise nach Dänemark zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s198><log.anmelden><en> To organise your trip to Moscow, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s199><log.anmelden><de> Um deine Reise nach Palmanova zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s199><log.anmelden><en> To organise your trip to Koper, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s200><log.anmelden><de> Um deine Reise nach Lourdes zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s200><log.anmelden><en> To organise your trip to Glasgow, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s201><log.anmelden><de> Um deine Reise nach Dubrovnik zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s201><log.anmelden><en> To organise your trip to Italy, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s202><log.anmelden><de> Um deine Reise nach St Ives zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s202><log.anmelden><en> To organise your trip to Malmesbury, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s203><log.anmelden><de> Um deine Reise nach Korfu zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s203><log.anmelden><en> To organise your trip to Favignana, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s204><log.anmelden><de> Um deine Reise nach Hoboken zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s204><log.anmelden><en> To organise your trip to Jersey City, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s205><log.anmelden><de> Um deine Reise nach Reggio Calabria zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s205><log.anmelden><en> To organise your trip to Patti, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s206><log.anmelden><de> Um deine Reise nach Miami Beach zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s206><log.anmelden><en> To organise your trip to Virginia Beach, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s207><log.anmelden><de> Um deine Reise nach Montenegro zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s207><log.anmelden><en> To organise your trip to Greece, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s208><log.anmelden><de> Um deine Reise nach Mailand zu planen, einfach bei Rome2rio anmelden, deine Reisesuchanfrage eingeben und Bahn- oder Bustickets buchen.
<G-vec00507-002-s208><log.anmelden><en> To organise your trip to Lecco, log on to Rome2rio, enter your journey search, and book your train or bus tickets.
<G-vec00507-002-s095><pre-register.anmelden><de> Die Basisstation kann währenddessen auch im Ruhezustand ein Signal senden um ein Mobilteil anzumelden.
<G-vec00507-002-s095><pre-register.anmelden><en> Meanwhile, the base station may also send a signal when it is in sleep mode in order to register a handset.
<G-vec00507-002-s096><pre-register.anmelden><de> Vergiss nicht, dein Projekt anzumelden, damit wir deine Kontaktinformationen haben.
<G-vec00507-002-s096><pre-register.anmelden><en> Make sure to register your project so we have your contact information.
<G-vec00507-002-s097><pre-register.anmelden><de> Und seit 2006 ist es in der Europäischen Union sogar möglich, grenzüberschreitende, europäische Genossenschaften anzumelden.
<G-vec00507-002-s097><pre-register.anmelden><en> And since 2006, it has even been possible to register cross-border European cooperatives inside the European Union.
<G-vec00507-002-s098><pre-register.anmelden><de> In der Vergangenheit war es nötig eine Aufenthaltsgenehmigung (Ikamet) zu besitzen, um in der Türkei ein KfZ zu erwerben und anzumelden.
<G-vec00507-002-s098><pre-register.anmelden><en> In the past it was necessary to have a residence permit (Ikamet) to buy and register a car in Turkey.
<G-vec00507-002-s099><pre-register.anmelden><de> Die Verpackungsgesetzgebung verpflichtet Erstinverkehrbringer von Verkaufsverpackungen, ihre Produzentenverantwortung wahrzunehmen und ihre Verpackungen zur Sammlung und Verwertung bei einem dualen System anzumelden.
<G-vec00507-002-s099><pre-register.anmelden><en> European packaging legislation requires initial distributors of sales packaging to honour their product responsibility and register their packaging with a recycling system provider (dual system) for collection and recycling.
<G-vec00507-002-s100><pre-register.anmelden><de> Wenn Sie unser API im Auftrag eines Unternehmens oder einer anderen Rechtspersönlichkeit zur Entwicklung vewenden, gewährleisten Sie, dass Sie die vollständige rechtliche Vollmacht haben, eine Anwendung im Auftrag dieser Rechtspersönlichkeit anzumelden und jene an diese Bedingungen zu binden.
<G-vec00507-002-s100><pre-register.anmelden><en> If you are developing on our API on behalf of a company or other entity, you represent and warrant that you have full legal authority to register an Application on behalf of that entity and bind it to these Terms.
<G-vec00507-002-s101><pre-register.anmelden><de> Nachfolgend sehen Sie, welche Dokumente erforderlich sind, um Ihr Schiff bei der maltesischen Registrierung anzumelden.
<G-vec00507-002-s101><pre-register.anmelden><en> Please see below which documents are necessary in order to register your vessel with the Maltese Registration.
<G-vec00507-002-s102><pre-register.anmelden><de> Gesellschaften ab 20 Personen sind möglichst frühzeitig, spätestens fünf Tage vor Reiseantritt, anzumelden.
<G-vec00507-002-s102><pre-register.anmelden><en> Groups of 20 or more people should register as soon as possible and at the latest 5 days before the intended cruise.
<G-vec00507-002-s103><pre-register.anmelden><de> In diesem Fall ist das Fahrrad vor Fahrtantritt telefonisch beim Kundenservice anzumelden (siehe die Bestimmungen für das Sondergepäck).
<G-vec00507-002-s103><pre-register.anmelden><en> In such a case, you must call customer service in advance to register the bicycle (see regulations for special luggage).
<G-vec00507-002-s104><pre-register.anmelden><de> Eine Geruchsmarke in der Europäischen Union anzumelden ist zwar theoretisch möglich, doch in Praxis bisher schwer umzusetzen.
<G-vec00507-002-s104><pre-register.anmelden><en> Although it is theoretically possible to register an scent trademark in the European Union, it has so far been difficult to do so in practice.
<G-vec00507-002-s105><pre-register.anmelden><de> Um ein Modul im Studium Generale anzumelden, reicht eine formlose E-Mail an das Studienbüro.
<G-vec00507-002-s105><pre-register.anmelden><en> In order to register a Studium Generale module, all you need to do is send an informal e-mail to the Office for Student Affairs.
<G-vec00507-002-s106><pre-register.anmelden><de> Denken Sie auf jeden Fall daran, Ihren neuen Namen als Marke anzumelden.
<G-vec00507-002-s106><pre-register.anmelden><en> Don't forget to register your name as a trademark in order to protect it.
<G-vec00507-002-s107><pre-register.anmelden><de> NEIN - sie braucht sich nicht bei den Behörden anzumelden, um dort weniger als drei Monate mit Ihnen zu leben; sie kann allerdings dazu aufgefordert werden, ihre Anwesenheit zu melden.
<G-vec00507-002-s107><pre-register.anmelden><en> NO - To live with you there for less than 3 months, she does not need to register with the authorities, though she might be asked to report her presence.
<G-vec00507-002-s108><pre-register.anmelden><de> Hier finden Sie alle notwendigen Informationen um Gäste bei uns anzumelden.
<G-vec00507-002-s108><pre-register.anmelden><en> You will find all the necessary information in order to register guests with us here.
<G-vec00507-002-s109><pre-register.anmelden><de> Um sich bei der besten, regulierten Plattform anzumelden und Geld zu verdienen, klicken Sie hier.
<G-vec00507-002-s109><pre-register.anmelden><en> To register and earn money through the best regulated platform, click here.
<G-vec00507-002-s110><pre-register.anmelden><de> Weiterhin ist die Auflegung des RAIF beim Luxemburger Handelsund Gesellschaftsregister anzumelden, die zentrale Verwaltung des RAIF muss in Luxemburg stattfinden.
<G-vec00507-002-s110><pre-register.anmelden><en> Establishment of a RAIF must be registered on a list held by Luxembourg’s trade and companies register, and the RAIF must be managed by a Luxembourg-based management company.
<G-vec00507-002-s111><pre-register.anmelden><de> Zu Beginn ist auch dieser Bildschirm noch leer und Sie können über die "+"-Funktion in das "ADD DEVICE"- Menü gelangen um hier Ihre vorhanden Geräte anzumelden.
<G-vec00507-002-s111><pre-register.anmelden><en> At the beginning and this screen is empty and you can use the "+" - function in the "Add Device" - menu access to register your available devices here.
<G-vec00507-002-s112><pre-register.anmelden><de> In diesen Fällen wäre der Empfänger der Leistungen dazu verpflichtet, den Erbringer als Angestellten für fremde Rechnung bei der Sozialversicherung anzumelden und seine steuerlichen und sozialen Verpflichtungen in Spanien zu erfüllen.
<G-vec00507-002-s112><pre-register.anmelden><en> If these cases, the service receiver is actually your employer, and they are required to register you with the social security as an employee and meet their tax and employer obligations in Spain.
<G-vec00507-002-s113><pre-register.anmelden><de> Jedes Mitglied verpflichtet sich, über seine Person keine falschen oder missverständlichen Angaben zu machen und sich insbesondere nicht unter einer falschen Identität anzumelden.
<G-vec00507-002-s113><pre-register.anmelden><en> Each member agrees not to provide false or misleading personal information, and, in particular, agrees not to register under a false identity.
