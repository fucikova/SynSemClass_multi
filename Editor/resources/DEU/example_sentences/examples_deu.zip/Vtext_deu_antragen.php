<G-vec00290-002-s027><gird.antragen><de> Bleibt nüchtern und setzt eure Hoffnung ganz auf die Gnade, die euch angetragen wird, wenn Jesus Christus sich offenbaren wird.
<G-vec00290-002-s027><gird.antragen><en> Wherefore gird up the loins of your mind, be sober, and hope to the end for the grace that is to be brought unto you at the revelation of Jesus Christ;
