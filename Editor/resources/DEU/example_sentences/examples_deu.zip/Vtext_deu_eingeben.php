<G-vec00407-001-s095><insert.eingeben><de> Die Registrierung ist einfach und schnell: Sie müssen nur Ihre E-Mail Adresse eingeben.
<G-vec00407-001-s095><insert.eingeben><en> The registration is easy and fast; you only have to insert your email address.
<G-vec00407-001-s096><insert.eingeben><de> Die Bedienung ist extrem einfach: Röhrchen eingeben, Deckel schließen, Geschwindigkeit / Zeit einstellen, und auf Start drücken.
<G-vec00407-001-s096><insert.eingeben><en> Operation is extremely simple for this high-level of sophistication: Insert tubes, close lid, adjust speed/time, and press Start.
<G-vec00407-001-s097><insert.eingeben><de> Damit können Sie jederzeit neue Trigger eingeben und positionieren, ohne alle anderen vorhandenen Triggerpositionen anpassen oder ändern zu müssen.
<G-vec00407-001-s097><insert.eingeben><en> That way, you can insert and position new triggers at any time, without having to alter all your existing triggers to adjust the firing position.
<G-vec00407-001-s098><insert.eingeben><de> Empfehlen Sie uns weiter: Gleich ins Stammgastportal einloggen, unter „Empfehlung“ die Daten eines Freundes oder Bekannten eingeben und persönliche Urlaubsempfehlung absenden.
<G-vec00407-001-s098><insert.eingeben><en> Recommend us:Log in at our portal for regular guests, go to „Recommendation“ and insert the data of your friend or acquaintance to send your personal holiday recommendation.
<G-vec00407-001-s099><insert.eingeben><de> Oben an der Tür befindet sich ein Adressfenster, in das Sie die Hausnummer oder den Namen des Empfängers eingeben können.Dank der drei kleinen Fenster kann ohne Öffnen des Schlosses und der Tür überprüft werden, ob sich in der Box ein Brief befindet.An der Unterseite der Box befindet sichein Loch zum Verlassen von Zeitungen, Werbemagazinen oder Flugblättern.
<G-vec00407-001-s099><insert.eingeben><en> At the top of the door, there is an address window in which you can insert the house number or the recipients name. Thanks to three small windows, it is possible, without opening the lock and door, to check whether there is a letter inside the box. At the base of the box, there is a hole for leaving newspapers, advertising magazines or leaflets.
<G-vec00407-001-s100><insert.eingeben><de> Den Text dafür können Sie selbst frei eingeben und so dem Beschenkten einen ganz persönlichen Gruß übermitteln.
<G-vec00407-001-s100><insert.eingeben><en> You can insert the text for your voucher individually and offer your friends a very personal gift.
<G-vec00407-001-s101><insert.eingeben><de> Häufig müssen Sie nur die Datenträger in Ihren PC eingeben und den Anweisungen folgen, die Ihnen bereitgestellt werden.
<G-vec00407-001-s101><insert.eingeben><en> Most of the time, all you need to do is insert the media into your PC and follow the directions provided to you.
<G-vec00407-001-s102><insert.eingeben><de> "Wenn Sie schon den Code der Unterkunft kennen, können Sie diesen im Feld ""Schnellsuche"" oben rechts auf der Homepage eingeben."
<G-vec00407-001-s102><insert.eingeben><en> If you already know the accommodation code you can insert it in the 'Quick Search' field on the top right of the homepage.
<G-vec00407-001-s103><insert.eingeben><de> Wenn Sie aber diese Kundendaten in eine Software von einem Drittanbieter eingeben, wird dieses Unternehmen die Daten in Ihrem Auftrag verarbeiten und als Datenverarbeiter agieren.
<G-vec00407-001-s103><insert.eingeben><en> But if you insert that client data into a third party software, the software company will process this data on your behalf, making them the data processor.
<G-vec00407-001-s104><insert.eingeben><de> Wenn Sie bereits schon registriert sind haben, können Sie Ihre Identifizierung Daten eingeben und automatisch weiter gehen.
<G-vec00407-001-s104><insert.eingeben><en> If you are already registered for the e-shop insert your data details and you will automatically proceed.
<G-vec00407-001-s105><insert.eingeben><de> "Wenn Sie ""Skrill"" als bevorzugte Zahlungsmethode wählen, müssen Sie die E-Mail-Adresse eingeben, die Ihr Skrill-Konto repräsentiert."
<G-vec00407-001-s105><insert.eingeben><en> "Should you choose ""Skrill"" as your preferable payment method, you will be required to insert the email which represents your Skrill account."
<G-vec00407-001-s106><insert.eingeben><de> Ferner müssen Sie Ihre Anschrift, Ihre Telefonnummer oder Ihre E-Mail-Adresse eingeben.
<G-vec00407-001-s106><insert.eingeben><en> You must also insert your address, telephone number or e-mail address.
<G-vec00407-001-s107><insert.eingeben><de> Ist der Graph G fertig aufgebaut, lassen wir den Benutzer zwei Worte from und to eingeben, zu denen eine Ableitung gesucht werden soll.
<G-vec00407-001-s107><insert.eingeben><en> After the graph G has been completely constructed, we let the user insert two words from and to, for which a derivation is to be searched.
<G-vec00218-002-s627><enter.eingeben><de> •diese Webseite für Sie einfacher machen, indem Sie Informationen nicht mehr als einmal eingeben.
<G-vec00218-002-s627><enter.eingeben><en> · help make this Site easier for you to use by not having to enter information more than once.
<G-vec00218-002-s628><enter.eingeben><de> Daten, die Sie uns bereitstellen: Wir erfassen und speichern alle Daten, die Sie auf unseren Websites eingeben oder uns im Zusammenhang mit der Nutzung unserer Websites, Anwendungen, Dienstleistungen oder Tools bereitstellen.
<G-vec00218-002-s628><enter.eingeben><en> We may collect and store any personal information you enter on our website or on a mobile application, or provide to us in some other manner.
<G-vec00218-002-s629><enter.eingeben><de> Alternativ dazu können Sie einen XPath-Ausdruck eingeben, mit dem der gewünschte Node im Schema ausgewählt wird.
<G-vec00218-002-s629><enter.eingeben><en> Alternatively, enter an XPath expression that selects the required node in the schema.
<G-vec00218-002-s630><enter.eingeben><de> Wenn Volume-Kopfdaten aus der Sicherungsdatei wiederhergestellt werden, dann müssen Sie das korrekte Passwort eingeben, welches gültig war als die Volume-Kopfdatensicherung erstellt wurde (und/oder die richtigen Schlüsseldateien bereitstellen).
<G-vec00218-002-s630><enter.eingeben><en> When restoring a volume header from the backup file, you will need to enter the correct password (and/or to supply the correct keyfiles) that was/were valid when the volume header backup was created.
<G-vec00218-002-s631><enter.eingeben><de> Wenn Sie Aufträge erstellen, mit denen AS2-Nachrichten versendet werden, können Sie den Partner aus einer Liste von bereits definierten Handelspartnern auswählen (statt dass Sie die Partnerdaten für jeden FlowForce-Auftrag eigens eingeben müssen).
<G-vec00218-002-s631><enter.eingeben><en> Namely, when you create jobs that send AS2 messages, you will be able to select the partner from a list of trading partners already defined (instead of having to enter the partner details for each FlowForce job).
<G-vec00218-002-s632><enter.eingeben><de> G r Pn o Zifferntasten Verwenden Sie die Zifferntasten zum Eingeben von Nummern und Werten.
<G-vec00218-002-s632><enter.eingeben><en> G r Pn o Use the number buttons to enter numbers and values.
<G-vec00218-002-s633><enter.eingeben><de> Damit eine vollständige Liste mit Hotels in einer bestimmten Region angezeigt wird, dürfen Sie keine Reisedaten eingeben.
<G-vec00218-002-s633><enter.eingeben><en> To ensure a full hotel listing for a particular geographical area, do not enter your travel dates.
<G-vec00218-002-s634><enter.eingeben><de> Cookies sparen auch Zeit, da Sie nicht immer wieder dieselben Informationen eingeben müssen.
<G-vec00218-002-s634><enter.eingeben><en> Cookies save you time by eliminating the need to repeatedly enter the same information.
<G-vec00218-002-s635><enter.eingeben><de> So können Sie Platzhaltertext u. a. lateinisch, arabisch, hebräisch und chinesisch eingeben.
<G-vec00218-002-s635><enter.eingeben><en> You can enter placeholder text Roman, Arabic, Hebrew, Chinese among others.
<G-vec00218-002-s636><enter.eingeben><de> Unter Umständen müssen Sie Ihre Zahlungsinformationen eingeben, um sich für die kostenlose Testversion anzumelden.
<G-vec00218-002-s636><enter.eingeben><en> You may be required to enter your billing information in order to sign up for the Free Trial.
<G-vec00218-002-s637><enter.eingeben><de> Eine eigene App ist eine Datei oder eine Menge von Dateien, die Datenbanktabellen, Layouts, Scripts und Beziehungen sowie die zugehörigen Daten enthält, die Sie eingeben und mit denen Sie arbeiten.
<G-vec00218-002-s637><enter.eingeben><en> A solution is a file or set of files containing database tables, layouts, and scripts, and the associated data that you enter and work with.
<G-vec00218-002-s638><enter.eingeben><de> - Wenn Sie ein Mitglied des InstaHe!p Affiliate Programmes sind können Sie hier Ihre ID eingeben.
<G-vec00218-002-s638><enter.eingeben><en> - If you are a member of the InstaHe!p affiliate program, enter your ID here to show all links with your id.
<G-vec00218-002-s639><enter.eingeben><de> Eine ausführliche Beschreibung für die Reise nach Poreč mit dem Auto erhalten Sie, indem Sie ihren Abfahrtsort eingeben und auf die Schaltfläche "Wegbeschreibung anfordern" weiter unten klicken.
<G-vec00218-002-s639><enter.eingeben><en> If you need more detailed information on getting to Labin by car, enter your starting point and click on "Get Directions" button below.
<G-vec00218-002-s640><enter.eingeben><de> Deine Zahlungsinformationen werden aber nicht in deinem Kundenkonto gespeichert und du musst sie bei jedem Einkauf wieder neu eingeben.
<G-vec00218-002-s640><enter.eingeben><en> However, your payment information is not stored in your customer account and you will have to enter it again for each purchase.
<G-vec00218-002-s641><enter.eingeben><de> Natürlich können Sie auch Suchbegriffe direkt in der Freitext-Suche eingeben.
<G-vec00218-002-s641><enter.eingeben><en> You can enter search terms directly into the free text search.
<G-vec00218-002-s642><enter.eingeben><de> Sie helfen uns, Daten wie Ihren Benutzernamen und Spracheinstellungen zu speichern, so dass Sie diese beim nächsten Besuch nicht erneut eingeben müssen.
<G-vec00218-002-s642><enter.eingeben><en> These cookies help us to remember data, such as your username and language preference to save you having to enter them again next time you visit.
<G-vec00218-002-s643><enter.eingeben><de> Finden Sie die besten Hotelschnäppchen in Kucukcekmece, indem Sie Ihre Reisedaten in das Suchfeld eingeben.
<G-vec00218-002-s643><enter.eingeben><en> Simply enter your planned dates of stay in our search box to find the best hotel deals Hotels
<G-vec00218-002-s644><enter.eingeben><de> Über folgenden Link können Sie Ihre Benutzer-ID (E-Mail-Adresse) eingeben, um Ihr Passwort zurückzusetzen.
<G-vec00218-002-s644><enter.eingeben><en> Please enter your email address below. You will receive a link to reset your password.
<G-vec00218-002-s645><enter.eingeben><de> Wir erfassen einige Daten über die Benutzer, die sie bei der Registrierung und bei der Nutzung unseres Dienstes eingeben.
<G-vec00218-002-s645><enter.eingeben><en> We collect some data about the users they enter during registration and when using our service.
<G-vec00322-002-s274><specify.eingeben><de> Das App für die Fahrer lässt die Bestellung annehmen, den gewünschten Kreis eingeben und die Bestellungen nach Standort wählen.
<G-vec00322-002-s274><specify.eingeben><en> Application for drivers allows them to take orders, specify desirable area of order and select orders by location.
<G-vec00322-002-s275><specify.eingeben><de> Sie müssen das nicht eingeben.
<G-vec00322-002-s275><specify.eingeben><en> You do not have to specify this.
<G-vec00322-002-s276><specify.eingeben><de> Wenn der Kunde, der ein Affiliate-Konto eröffnen möchte, bereits über einen registrierten Kundenbereich verfügt, muss er Ihren Affiliate-Code in das Feld "Affiliate-Code" im Registrierungsformular für ein neues Konto eingeben.
<G-vec00322-002-s276><specify.eingeben><en> If the client, who would like to open Affiliate-account already has registered Members Area, he has to specify your affiliate code in "Affiliate code" field in the registration form of a new account.
<G-vec00322-002-s277><specify.eingeben><de> Dies ermöglicht die automatische Umleitung der Besucher von der URL, die sie in einen Browser eingeben, auf eine Website mit einer anderen URL.
<G-vec00322-002-s277><specify.eingeben><en> This allows automatic redirection of visitors from the URL they specify in a browser to a site with a different URL.
<G-vec00322-002-s278><specify.eingeben><de> FORCE PASSWORD CHANGE-Klausel Steuert, ob der Benutzer beim Anmelden ein neues Kennwort eingeben muss.
<G-vec00322-002-s278><specify.eingeben><en> FORCE PASSWORD CHANGE clause Controls whether the user must specify a new password when they log in.
<G-vec00322-002-s279><specify.eingeben><de> Zu installierende Produkte auswählen: Wenn Sie weder die lizenzierte Version noch die Evaluierungsversion eines Produkts installieren möchten, müssen Sie das Kontrollkästchen Evaluieren manuell deaktivieren und dürfen keinen Lizenzschlüssel für das Produkt eingeben.
<G-vec00322-002-s279><specify.eingeben><en> Choose the products to be installed: If you do not want to install either the licensed version or the evaluation version of a product, manually deselect the Evaluate check box and do not specify the license key for the product.
<G-vec00322-002-s280><specify.eingeben><de> Sie können auch Platzhalter für Land und Region eingeben.
<G-vec00322-002-s280><specify.eingeben><en> You also can specify a wild card for country and region.
<G-vec00322-002-s281><specify.eingeben><de> Außerdem müssen Sie möglicherweise den Namen des Datenbankservers eingeben.
<G-vec00322-002-s281><specify.eingeben><en> You may also need to specify the database server name.
<G-vec00322-002-s282><specify.eingeben><de> In der Dateiliste kann man die Layouts wählen, die gedruckt werden müssen, und die Druckeinstellungen für jedes Layout auch eingeben.
<G-vec00322-002-s282><specify.eingeben><en> You can select layouts for printing in the file list as well as specify printing settings for each layout in particular.
<G-vec00322-002-s283><specify.eingeben><de> Mit dieser Option können Sie die Benutzernamen bestimmter vertrauenswürdiger Benutzer eingeben, für die die Gerätesicherheitseinstellungen nicht erforderlich sind.
<G-vec00322-002-s283><specify.eingeben><en> This option allows you to specify the user names of specific, trusted users of whom you do not need to require device security settings.
<G-vec00322-002-s284><specify.eingeben><de> Wenn Sie im Feld "Einzug" eine Zahl eingeben, rückt Microsoft Excel den Inhalt der Zelle von links um die angegebene Anzahl von Zeichenstellen ein.
<G-vec00322-002-s284><specify.eingeben><en> If you specify a number in the Indent box, Microsoft Excel indents the contents of the cell from the left by the specified number of character spaces.
<G-vec00322-002-s285><specify.eingeben><de> Zum Aktivieren von PrintMe müssen Sie unter bestimmten Voraussetzungen auch Informationen über Ihren Proxyserver eingeben.
<G-vec00322-002-s285><specify.eingeben><en> When you enable PrintMe, you may need to specify information about the proxy server.
<G-vec00322-002-s286><specify.eingeben><de> DHT-Netzwerk aktivieren: Damit das NAS Dateien auch dann herunterladen kann, wenn keine Tracker des Torrent verbunden werden können, müssen Sie DHT- (Distributed Hash Table) Netzwerk aktivieren und die UDP-Portnummer für DHT eingeben.
<G-vec00322-002-s286><specify.eingeben><en> Enable DHT network: To allow the NAS to download the files even no trackers of the torrent can be connected, enable DHT (Distributed Hash Table) network and specify the UDP port number for DHT.
<G-vec00322-002-s287><specify.eingeben><de> Wenn Sie diese Option auswählen, müssen Sie zum gewünschten Verzeichnis navigieren oder den Pfad im Feld Speicherort eingeben.
<G-vec00322-002-s287><specify.eingeben><en> If you select this option, you must browse to your desired location or specify the path in the Location box.
<G-vec00322-002-s288><specify.eingeben><de> Sie können keine unterschiedlichen Standardwerte für verschiedene Benutzer eingeben.
<G-vec00322-002-s288><specify.eingeben><en> You cannot specify different defaults for different users.
<G-vec00322-002-s289><specify.eingeben><de> Zum Durchführen der Analyse müssen Sie eine untere Spezifikationsgrenze und/oder eine obere Spezifikationsgrenze eingeben, um Ihre Prozessanforderungen zu definieren.
<G-vec00322-002-s289><specify.eingeben><en> To perform the analysis, you must specify a lower or upper specification limit (or both) to define your process requirements.
