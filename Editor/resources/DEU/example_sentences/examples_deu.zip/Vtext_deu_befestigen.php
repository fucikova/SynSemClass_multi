<G-vec00407-001-s032><attach.befestigen><de> Wir werden den Rand des Blattes am Grund vom Klebeband oder dem Leim befestigen.
<G-vec00407-001-s032><attach.befestigen><en> Let's attach the sheet edge to a bottom an adhesive tape or glue.
<G-vec00407-001-s033><attach.befestigen><de> Weiter bleibt es nur übrig, unter dekorativ kolpatschkami die Verbindungsstellen der Fäden zu verbergen und, am fertigen Kollier den Verschluss zu befestigen.
<G-vec00407-001-s033><attach.befestigen><en> Further it is necessary only to hide under decorative caps of a junction of threads and to attach a fastener to a ready necklace.
<G-vec00407-001-s034><attach.befestigen><de> Wenn der Stecker im Gehäuse untergebracht ist, wird das Kabel zu einer Schlaufe, mit der Sie das Netzteil am Schlüsselbund oder anderen Zubehörteilen befestigen können.
<G-vec00407-001-s034><attach.befestigen><en> When the connector is housed in the body, the cable becomes a loop that allows you to attach the power bank to a keychain or other accessories.
<G-vec00407-001-s035><attach.befestigen><de> Mit diesen kannst du diese geheimnisvolle Maske gut am Kopf befestigen.
<G-vec00407-001-s035><attach.befestigen><en> With these you can attach this mysterious mask to your head.
<G-vec00407-001-s036><attach.befestigen><de> Der Basil Magnolia Sattelüberzug ist in der Farbe blau erhältlich und lässt sich einfach am Sattel Ihres Fahrrads befestigen.
<G-vec00407-001-s036><attach.befestigen><en> The Basil Magnolia Saddle Cover is available in beautiful teal blue and is easy to attach to the saddle of your bike.
<G-vec00407-001-s037><attach.befestigen><de> Nutzen Sie die praktische und praktische Möglichkeit, Ihr Telefon am Armaturenbrett des Fahrzeugs zu befestigen.
<G-vec00407-001-s037><attach.befestigen><en> Take advantage of a convenient and practical way to attach your phone to the car dashboard.
<G-vec00407-001-s038><attach.befestigen><de> Gut zu wissen:Beide Taschen lassen sich mit dem separat erhältlichen Legend Gear Satteltaschen-Halter SLS mit wenigen Handgriffen am Motorrad befestigen und abnehmen.
<G-vec00407-001-s038><attach.befestigen><en> Good to know:Both bags are quick and easy to attach and remove again with the Legend Gear SLS Saddle Strap, which can be ordered separately.
<G-vec00407-001-s039><attach.befestigen><de> Mit dem Knopf lässt sich das Schwert am Gürtel befestigen.
<G-vec00407-001-s039><attach.befestigen><en> Comes complete with scabbard and button to attach to belt.
<G-vec00407-001-s040><attach.befestigen><de> "Insbesondere kann man für die Befestigung den Montageschaum, den Leim «die flüssigen Nägel» oder ""der Drache"" verwenden., Nachdem das Material am Türleinen sicher befestigt ist, kann man das Stück laminirowannogo DWP des entsprechenden Umfanges oben befestigen oder, irgendwelchen obiwotschnyj das Material zu verwenden."
<G-vec00407-001-s040><attach.befestigen><en> "In particular, for fastening it is possible to use polyurethane foam, glue ""liquid nails"" or ""Dragon"". After material is reliably attached to a door cloth, from above it is possible to attach a piece of the laminated DVP of the corresponding size or to use any obivochny material."
<G-vec00407-001-s041><attach.befestigen><de> Außerdem bekommt du noch zwei Kinderwagenclips, damit du deine neue Lieblingstasche ganz einfach am Kinderwagen befestigen kannst.
<G-vec00407-001-s041><attach.befestigen><en> You also get two stroller clips, so you can easily attach your new favorite bag to the stroller.
<G-vec00407-001-s042><attach.befestigen><de> Du kannst die Tasche entweder mit dem gepolsterten Schultergurt tragen oder diese auch einfach am Gestell des i2 befestigen.
<G-vec00407-001-s042><attach.befestigen><en> You can either carry the bag with the padded shoulder strap or simply attach it to the i2 frame.
<G-vec00407-001-s043><attach.befestigen><de> Auf unserer Webseite findest du den Basil KF Lenkerhalter, mit dem du den Korb einfach am Lenker befestigen kannst.
<G-vec00407-001-s043><attach.befestigen><en> You can easily attach the basket to your handlebars with the Basil KF handlebar holder (sold separately).
<G-vec00407-001-s044><attach.befestigen><de> Ihr Freund am Freund von den Stecknadeln zu befestigen.
<G-vec00407-001-s044><attach.befestigen><en> To attach them to each other pins.
<G-vec00407-001-s045><attach.befestigen><de> Ich nähe historische Tournüren-Kleider und war auf der Suche nach einer Lösung zum Raffen des Überrocks, bei der es nicht nötig ist, den Überrock am Unterrock zu befestigen.
<G-vec00407-001-s045><attach.befestigen><en> I sew historic bustle dresses and I was looking for a solution to gather up the top coat, where it is not necessary to attach it to the petticoat.
<G-vec00407-001-s065><attach.befestigen><de> Die einfachste Methode ist, an der Siebunterseite präparierte Papiere oder Schneidefilme zu befestigen, aus denen das Motiv scherenschnittartig herausgearbeitet wurde.
<G-vec00407-001-s065><attach.befestigen><en> The easiest way of sealing the screen is to attach stencils from papers or foils to it.
<G-vec00407-001-s066><attach.befestigen><de> An einer Pinnwand oder einem Memoboard genutzt, lassen sich mit den Pins Notizzettel und Fotos schnell und einfach befestigen.
<G-vec00407-001-s066><attach.befestigen><en> Attach notices or photos quickly and easily to your pinboard or notice board with these pins.
<G-vec00407-001-s067><attach.befestigen><de> Das Hotel liegt im Gras oder auf den Stützen sie an jeder Ecke der Erde Charme befestigen.
<G-vec00407-001-s067><attach.befestigen><en> Located in the grass or on the supports they attach to any corner of the earth charm.
<G-vec00407-001-s068><attach.befestigen><de> Am Ende werden wir mit einem speziellen Klebezement die Veneers an den Zähnen befestigen.
<G-vec00407-001-s068><attach.befestigen><en> Finally, a special cement-based adhesive is used to attach the veneers.
<G-vec00407-001-s069><attach.befestigen><de> Unterstützt von neue Sensoren An der Rückseite der hinteren Abdeckung befestigen Uhr 4 und ein Prozessor leistungsstärkere Anwendungen, die sich für Outdoor-Aktivitäten und Sportarten einsetzen, wurden stark entwickelt.
<G-vec00407-001-s069><attach.befestigen><en> Supported by new sensors Attach to the back of the back cover Watch 4 and a processor more powerful, applications dedicated to outdoor activities and sports have been greatly developed.
<G-vec00407-001-s070><attach.befestigen><de> Diese LED / LCD / Plasma TV-Wandhalterung wird mit allen notwendigen Materialien geliefert, um sie einfach an der Wand zu befestigen.
<G-vec00407-001-s070><attach.befestigen><en> This LED / LCD / Plasma TV wall bracket is supplied with all necessary materials to easily attach it to the wall.
<G-vec00407-001-s071><attach.befestigen><de> Die Tasche ist tatsächlich fertig, es bleibt nur übrig, an ihr die herankommenden Griffe zu befestigen.
<G-vec00407-001-s071><attach.befestigen><en> The bag is almost ready, it is necessary only to attach to it suitable handles.
<G-vec00407-001-s072><attach.befestigen><de> Eine der Lieblingsbeschäftigungen vieler seefahrender Wissenschaftler*innen (weltweit) ist es Styroportrinkbecher zu bemalen, an den Geräten zu befestigen und in die Tiefsee hinab zu lassen.
<G-vec00407-001-s072><attach.befestigen><en> A favourite pastime for many seafaring scientists (worldwide), is to paint styrofoam cups, attach them to their equipment and to send everything to the bottom of the sea.
<G-vec00407-001-s073><attach.befestigen><de> Dank der praktischen Aufhängung – einer Kombination aus Öse und einer Biegung – kannst du den Kesselhaken sowohl an deinem Dreibein als auch an der Querstange deiner Kochstelle über dem Feuer befestigen.
<G-vec00407-001-s073><attach.befestigen><en> Thanks to the mount as a combination of eye and crook, you can attach the Trammel Hook to a tripod or at a crossbar over your fire cooking place.
<G-vec00407-001-s074><attach.befestigen><de> Von dem, man wer die Plakate oder die ähnlichen Materialien, die auf berechnet sind hängt, dass sie ständig tauschen kann, wir empfehlen, an der Wand die Leiste zu befestigen, die Schrauben mit schkantami verwendend (siehe die Zeichnung Mitte rechts), durchbohren wir in der Leiste die kleinen Öffnungen.
<G-vec00407-001-s074><attach.befestigen><en> That who hangs up posters or the similar materials, calculated that they can be changed, we recommend to attach to a wall a lath, using screws with shkantami (drawing in the middle on the right see), we bore through in a lath small apertures.
<G-vec00407-001-s075><attach.befestigen><de> Bohrschrauben zur Trockenmauer an dickem Metall zu befestigen.
<G-vec00407-001-s075><attach.befestigen><en> Self drilling screws used to attach drywall to heavy gauge metal.
<G-vec00407-001-s076><attach.befestigen><de> Mit dieser Power Core austauschbar Kombination Roboter-System kann der Mini-Cons und drone Fahrzeuge (separat erhältlich) an die Macht bis alle Commander Figur befestigen.
<G-vec00407-001-s076><attach.befestigen><en> With this Power Core interchangeable robot combination system, MINI-CONS and drone vehicles (sold separately) can attach to power up any Commander figure.
<G-vec00407-001-s077><attach.befestigen><de> Jeder Schlüsselanhänger ist rund 3,5 cm groß und kommt mit einem Ring, um Ihre Schlüssel oder an einer Tasche oder an andere Gegenstände zu befestigen.
<G-vec00407-001-s077><attach.befestigen><en> Each keyring figure is around 3.5cm tall and comes complete with a ring to attach to your keys, bag or other items.
<G-vec00407-001-s078><attach.befestigen><de> An diesem befindet sich ein Karabiner, sodass du das gute Stück problemlos an deinem Rucksack befestigen kannst.
<G-vec00407-001-s078><attach.befestigen><en> This one is equipped with a carabiner, so you can easily attach the flask to your backpack.
<G-vec00407-001-s079><attach.befestigen><de> """Nike + iPod"" erhält die Trainingsdaten von einem drahtlosen Sensor (separat erhältlich), den Sie an Ihrem Schuh befestigen."
<G-vec00407-001-s079><attach.befestigen><en> Nike + iPod collects workout data from a wireless sensor (sold separately) that you attach to your shoe.
<G-vec00407-001-s080><attach.befestigen><de> Diese Satteltasche hat 2 Klettbänder, die Sie an den Ringen an der Vorderseite Ihres Sattels befestigen.
<G-vec00407-001-s080><attach.befestigen><en> This saddlebag has 2 Velcro strips that you attach to the rings on the front of your saddle.
<G-vec00407-001-s081><attach.befestigen><de> Die hölzernen Konstruktionen in die Projektlage heben stropami, wofür sie an den Konstruktionen befestigen, und dann hängen zum Haken des Hebemechanismus auf.
<G-vec00407-001-s081><attach.befestigen><en> Wooden designs in design position lift slings for what them attach to designs, and then suspend to a hook of the elevating mechanism.
<G-vec00407-001-s082><attach.befestigen><de> Es könnte in der Tat helfen, die Brust zu erweitern, indem Fettgewebe sowie Bänder zu verbessern sowie Form auf die Brust geben Unterstützung, während auch die Luftkanäle Verlängerung, die an der Brustwarze Bereich befestigen, für vollere sowie stärkere Brüste.
<G-vec00407-001-s082><attach.befestigen><en> It could in fact assist to expand the breast by enhancing fatty tissue as well as ligaments giving support as well as form to the breast, while also lengthening the air ducts that attach to the nipple area, for fuller as well as stronger breasts.
<G-vec00407-001-s231><attach.befestigen><de> Heile die Katze und befestige die normalen Menschen.
<G-vec00407-001-s231><attach.befestigen><en> Heal the cat and attach the normal people.
<G-vec00407-001-s232><attach.befestigen><de> Skizziere mit deinem Wachsstift oder -marker dein Design direkt auf den Stein oder befestige die Schablone an deinem Stein.
<G-vec00407-001-s232><attach.befestigen><en> Sketch your design onto the stone directly using your wax pencil or marker, or attach the stencil to your stone.
<G-vec00407-001-s233><attach.befestigen><de> Ich befestige es gerne an fast jeder Position die ich mit meinem großen Dildo mache;) Meine Fantasie kennt keine Grenzen.
<G-vec00407-001-s233><attach.befestigen><en> I like to attach it to almost every position I use my big dildo;) My fantasy knows no boundaries ..
<G-vec00407-001-s234><attach.befestigen><de> Befestige das Fledermaushäuschen an der vorgesehenen Stelle.
<G-vec00407-001-s234><attach.befestigen><en> Attach the bat house to the intended site.
<G-vec00407-001-s235><attach.befestigen><de> Setz dann Kai in die Kapsel, befestige die Klinge und die Drachenflügel und zieh am Zugriemen.
<G-vec00407-001-s235><attach.befestigen><en> Place Kai in the capsule, attach the blade and dragon wings, then pull the rip cord.
<G-vec00407-001-s236><attach.befestigen><de> Befestige das Dach.
<G-vec00407-001-s236><attach.befestigen><en> Attach the roof.
<G-vec00407-001-s237><attach.befestigen><de> Befestige ein kleines Bündel Federn am Stab.
<G-vec00407-001-s237><attach.befestigen><en> Attach a small cluster of feathers to the stick.
<G-vec00407-001-s238><attach.befestigen><de> Ich befestige die Leine hauptsächlich an der Front, um mehr Kontrolle zu haben (es gibt eine Menge Leute, die sich über den hinteren Haken beschweren, der das Nylon schnell abnutzt, aber es ist noch zu früh, um dies zu beurteilen).
<G-vec00407-001-s238><attach.befestigen><en> I mainly attach the leash on front to have more control (there are a lot of people complaining about the back hook wearing out nylon fast but it's too early to tell).
<G-vec00407-001-s239><attach.befestigen><de> Drucke hier dein Etikett für kostenlose Rücksendung mit Royal Mail aus und befestige es an der Außenseite deiner Sendung.
<G-vec00407-001-s239><attach.befestigen><en> Please create your free Royal mail returns label here and attach this to the outside of your package.
<G-vec00407-001-s240><attach.befestigen><de> Befestige das Garn mit einem Slipknoten auf der Häkelnadel und häkle dann eine Luftmaschenkette aus 200 Luftmaschen.
<G-vec00407-001-s240><attach.befestigen><en> Attach the yarn to your crochet hook with a slipknot, then work up a foundation chain of 200 chain stitches.
<G-vec00407-001-s241><attach.befestigen><de> Befestige das Ende der Schnur an einem Stab.
<G-vec00407-001-s241><attach.befestigen><en> Attach the end of the string to a stick.
<G-vec00407-001-s242><attach.befestigen><de> Befestige die Minifigur einfach an ihrem LEGO Tag und platziere sie auf dem LEGO Toypad, um sie im Spiel zum Leben zu erwecken.
<G-vec00407-001-s242><attach.befestigen><en> Simply attach the minifigure to her LEGO Toy Tag and place her on the LEGO Toy Pad to bring her to life in the game.
<G-vec00407-001-s243><attach.befestigen><de> Befestige das Solarpanel.
<G-vec00407-001-s243><attach.befestigen><en> Attach the solar panel.
<G-vec00407-001-s244><attach.befestigen><de> Befestige den unteren Teil der Folie.
<G-vec00407-001-s244><attach.befestigen><en> Attach the bottom of the film.
<G-vec00407-001-s245><attach.befestigen><de> Wenn Sie die Basisstation mit Isofix befestigen, sorgt diese Vorrichtung für mehr Stabilität und einer höheren Sicherheit.
<G-vec00407-001-s245><attach.befestigen><en> When you attach the base station to Isofix, this device provides more stability and greater security.
<G-vec00407-001-s246><attach.befestigen><de> Dazu muss man planen Bleistift die Form und die Leitungen in der entsprechenden Lage mit Hilfe fein gwosdikow oder polossotschek des Klebebandes befestigen.
<G-vec00407-001-s246><attach.befestigen><en> For this purpose it is necessary to plan a pencil a form and to attach wires in the relevant provision by means of thin tacks or stripes of an adhesive tape.
<G-vec00407-001-s247><attach.befestigen><de> Die Tasche hat drei Karabinerhaken zur Befestigung am Sattel und pro Seite jeweils ein Paar Lederlaschen, um weiteres Gepäck (Jacke, Decke…) zu befestigen.
<G-vec00407-001-s247><attach.befestigen><en> The saddle bagag has three karabiner hooks for easy, secure mounting to the saddle and a set of leather strings on each side to attach further luggage. (Jackets, blankets...)
<G-vec00407-001-s248><attach.befestigen><de> Der Selflock Haken Easy Wide ist eine schnelle und einfache Möglichkeit, Geräte an einer Traverse zu befestigen.
<G-vec00407-001-s248><attach.befestigen><en> The Selflock Hook Easy Wide is a fast and simple way to attach devices to a truss.
<G-vec00407-001-s249><attach.befestigen><de> Sie sind in der Lage, zu befestigen mit YOOX über eine Reihe von social-networking-Stationen.
<G-vec00407-001-s249><attach.befestigen><en> You are able to attach with YOOX through an range of social networking stations.
<G-vec00407-001-s250><attach.befestigen><de> Aber bei der scheinenden äußerlichen Einfachheit sind solche Frisuren nicht in der Erfüllung immer einfach: einfach wird rastschessat das Haar den Schleier offenbar ungenügend für die Bildung der schönen Hochzeitsfrisur eben befestigen.
<G-vec00407-001-s250><attach.befestigen><en> But at the seeming external simplicity such hairdresses are not always simple performed by: it is simple to comb hair and to attach a veil will be obviously insufficiently for creation of a beautiful wedding hairdress.
<G-vec00407-001-s251><attach.befestigen><de> Einfach zu befestigen und zu betreiben.
<G-vec00407-001-s251><attach.befestigen><en> Easy to attach and operate . 3
<G-vec00407-001-s252><attach.befestigen><de> Gel extra stark, alkoholfrei, nach Form zu geben und befestigen Frisuren für eine definierte Look.
<G-vec00407-001-s252><attach.befestigen><en> Gel extra strong, alcohol-free, to give form and attach hairstyles for a more defined look.
<G-vec00407-001-s253><attach.befestigen><de> Konstruieren Sie einen Jumper auf dem Boden und die Decke im erforderlichen Abstand von der Wand und befestigen.
<G-vec00407-001-s253><attach.befestigen><en> Construct a jumper on the floor and ceiling at the required distance from the wall and attach.
<G-vec00407-001-s254><attach.befestigen><de> Critical enthält auch eine Magnethalterung, die es Tätowierern ermöglicht, sie auf jeder magnetischen Oberfläche zu befestigen, sodass die beim Tätowieren leicht zu erreichen sind.
<G-vec00407-001-s254><attach.befestigen><en> Critical has also included a magnetic mount with both tattoo power supplies, allowing artists to attach them to any magnetic surface, making them easy to reach while tattooing.
<G-vec00407-001-s255><attach.befestigen><de> Das Monster können einen sticky Thread an der Wand befestigen und ziehen sich bewegen, aber es bewegt sich gerade nur, Sie müssen also herausfinden, wie die Ebene navigieren.
<G-vec00407-001-s255><attach.befestigen><en> The monster can attach a sticky thread to the wall and pull itself to move around, but it moves straight only, so you have to figure out how to navigate the level.
<G-vec00407-001-s256><attach.befestigen><de> Diese Silikon-AirPod-Abdeckungen lassen sich mühelos an Ihren Kopfhörern befestigen und bieten eine Möglichkeit, sie sicher, sauber und schön zu halten.
<G-vec00407-001-s256><attach.befestigen><en> These silicone AirPod covers attach effortlessly to your earphones, providing a way to keep them safe, clean and looking great.
<G-vec00407-001-s257><attach.befestigen><de> Es kann auch die Auskleidung der die Bakterien ermöglicht Blase beschädigen leichter zu befestigen.
<G-vec00407-001-s257><attach.befestigen><en> It can also damage the lining of the bladder allowing the bacteria to attach more readily.
<G-vec00407-001-s258><attach.befestigen><de> Dieser Plattenhalter wird komplett mit Edelstahl-Befestigungsmaterial geliefert, um Ihr Nummernschild am Plattenhalter zu befestigen.
<G-vec00407-001-s258><attach.befestigen><en> This plate holder comes complete with stainless steel mounting material to attach your license plate to the plate holder.
<G-vec00407-001-s259><attach.befestigen><de> Ein möglicher Einsatzbereich: Die Inventurliste direkt am Stahlregal befestigen.
<G-vec00407-001-s259><attach.befestigen><en> A possible application: Attach the inventory list directly on the steel shelf.
<G-vec00407-001-s260><attach.befestigen><de> Mit Klettverschlüssen können Sie das RX-9T beispielsweise an der Decke eines Autos befestigen.
<G-vec00407-001-s260><attach.befestigen><en> Velcro fasteners allow you to attach the RX-9T to the ceiling of a car, for example.
<G-vec00407-001-s261><attach.befestigen><de> Sony Alpha A6300 Sony Alpha a6500 Ein Zubehörschuh (Hot shoe) kann benutzt werden, um ein externes Blitzgerät zu befestigen, sowie Belichtungsmesser, Bildsucher, Entfernungsmesser und andere Geräte.
<G-vec00407-001-s261><attach.befestigen><en> Sony Alpha A6300 Sony Alpha a6500 A hot shoe can be used to attach an external flash, as well as light meters, viewfinders, rangefinders and other attachments.
<G-vec00407-001-s262><attach.befestigen><de> Dadurch können sie den Batterieadapter an ihrer Kamera befestigen.
<G-vec00407-001-s262><attach.befestigen><en> This allows you to attach the battery adapter to your camera.
<G-vec00407-001-s263><attach.befestigen><de> Ich gefaltet die Schmetterlingsflügel wo befestigen sie auf den Körper, mit einem Lineal die Falte gerade machen.
<G-vec00407-001-s263><attach.befestigen><en> I folded the butterfly wings where they attach to the body, using a ruler to make the fold straight.
<G-vec00290-001-s029><brace.befestigen><de> Befestigen Sie sich für erstaunliches, Spielqualität auf einer Spielvorrichtung, die balanciert wird, um die Weise zu ändern, die, Sie an bewegliche Vorrichtungen denken.Drahtlosen on-line-Anschluß, dVD und 4.3-inch LCD Schirm und intensiver Datenspeicher und uSB-gegründete Peripheriewahlen habend, ist das bewegliche...
<G-vec00290-001-s029><brace.befestigen><en> Brace yourself for astonishing, gaming quality on a gaming device which is poised to change the way you think about portable devices.Having wireless on-line connection, dVD and 4.3-inch LCD screen, and intense data storage and uSB-based peripherals options, the Playstaion Portable is a perfect answer for the mobile digital way...
<G-vec00178-001-s057><secure.befestigen><de> Ich genoss es, die Saugnapfbasis zu verwenden, um sie an einem Spiegel zu befestigen, an dem ich sie zurückdrücken konnte, während der Saugnapf sie sicher an ihrem Platz hielt.
<G-vec00178-001-s057><secure.befestigen><en> I enjoyed using the suction cup base to secure it to a mirror where I could push back against it as the suction cup held it securely in place.
<G-vec00178-001-s058><secure.befestigen><de> Das Verbindungskabel ist lang genug, um die Erweiterungsplatine auch etwas entfernt von der Mutterplatine zu befestigen.
<G-vec00178-001-s058><secure.befestigen><en> The connection cable is long enough to secure the expansion board slightly away from the main board.
<G-vec00178-001-s059><secure.befestigen><de> Wenn Sie auf der Tablettoberfläche ein Blatt Papier mit einem Bild darauf befestigen, kann das Tablet das Bild verfolgen - dies wird als Digitalisierung bezeichnet und wird häufig zur Erfassung handschriftlicher Signaturen verwendet.
<G-vec00178-001-s059><secure.befestigen><en> Also, if you secure to the tablet surface a piece of paper with an image on it, the tablet can trace the image – this is called digitizing and often used for capturing handwritten signatures.
<G-vec00178-001-s060><secure.befestigen><de> Installieren Sie je nach Bedarf mehrere Keilanker, um die Kletterwand an Ort und Stelle zu befestigen.
<G-vec00178-001-s060><secure.befestigen><en> Install several wedge anchors as appropriate to secure your climbing wall base in place.
<G-vec00178-001-s061><secure.befestigen><de> Bei dieser Brosche sind die Korkeinlagen mit Naturfarben ineingefärbt und in Tombak gefasst.Um dieses Stück Korkschmuck an der Kleidung befestigen zu können, ist auf der Rückseite eine Nadel mit Sicherheitsverschluß angebracht.
<G-vec00178-001-s061><secure.befestigen><en> In this brooch, the Cork pads are with natural dyes in colored and drawn in Tombak. To secure this piece of Cork jewelry to clothing, a needle with a safety CAP is attached on the back.
<G-vec00178-001-s062><secure.befestigen><de> Damit positionieren und befestigen Sie ein Profil mit äußerst geringem Aufwand.
<G-vec00178-001-s062><secure.befestigen><en> That means you can position and secure a profile with the greatest of ease.
<G-vec00178-001-s063><secure.befestigen><de> Befestigen Sie die Tasche an den Verzurrösen ► Link.
<G-vec00178-001-s063><secure.befestigen><en> Secure the bag to the fastening rings ► Link.
<G-vec00178-001-s064><secure.befestigen><de> Starke Stangen, zum des Schlaghauses an den Boden zu befestigen.
<G-vec00178-001-s064><secure.befestigen><en> Strong stakes to secure the bounce house to the ground.
<G-vec00178-001-s065><secure.befestigen><de> Holen Sie Terrassenmöbel, Mülleimer, Gartengeräte und Gartenverzierungen herein oder befestigen Sie sie.
<G-vec00178-001-s065><secure.befestigen><en> Take patio furniture, bins, gardening tools and ornaments inside or secure them
<G-vec00178-001-s066><secure.befestigen><de> Das Set besteht aus sechs Kissen Stuhlhussen mit abnehmbaren Reißverschluss und Riemen sie an den Stuhl zu befestigen.
<G-vec00178-001-s066><secure.befestigen><en> The set includes six removable cushion covers with zip and lanyards to secure them to the chair.
<G-vec00178-001-s067><secure.befestigen><de> (5) Entfernt die vier Schrauben die die LCD Platine befestigen und legt die Platine mit der Oberseite sichtbar ab.
<G-vec00178-001-s067><secure.befestigen><en> (5) Remove the four screws that secure the LCD card and lay the card down face up.
<G-vec00178-001-s068><secure.befestigen><de> billige adidas schuhe Zum Beispiel befestigen ein Seil Befestigung an einem High-Kabel-Maschine, die die Enden des Seils neben Ihrem Kopf halten und stehen Crunches ausführen.
<G-vec00178-001-s068><secure.befestigen><en> For example, under armour hoodies secure a rope attachment to a high-cable machine, hold the ends of the rope next to your head and perform standing crunches.
<G-vec00178-001-s069><secure.befestigen><de> Um mit dem OC 3 zu reinigen, einfach Tank abnehmen und mit Wasser befüllen, Pistole aus dem Gerät nehmen und Tank wieder richtig befestigen.
<G-vec00178-001-s069><secure.befestigen><en> In order to clean with the OC 3, simply remove the tank and fill with water, take the spray gun from the device and secure the tank again properly.
<G-vec00178-001-s070><secure.befestigen><de> Nehmen Sie eine der großen Gefäße, den Deckel ein Loch zu machen, setzen Sie in das Loch und befestigen Sie die Metallstange - ist die Zukunft Hals.
<G-vec00178-001-s070><secure.befestigen><en> Take one of the great vessels, the lid to make a hole, insert into the hole and secure the metal rod - is the future neck.
<G-vec00178-001-s071><secure.befestigen><de> Mit der magnetischen Polymerbasis lässt sich die Lampe auf den meisten metallenen Oberflächen befestigen.
<G-vec00178-001-s071><secure.befestigen><en> The magnetic polymer base allows you to secure the lamp to most metal surfaces
<G-vec00178-001-s072><secure.befestigen><de> Wenn Sie einige Gesundheit und Fitness-Programm tun, können Anavar Ihnen helfen zu befestigen, um Erz unglaubliches Ergebnis zu entwickeln.
<G-vec00178-001-s072><secure.befestigen><en> If you are doing some health and fitness program, Anavar could aid you to secure as well as develop ore awesome outcome.
<G-vec00178-001-s073><secure.befestigen><de> Einfach auflegen, die seiten des bivvy und befestigen sie sie mit klammern oder, wie im fall des M3, entfernen sie die füllung.
<G-vec00178-001-s073><secure.befestigen><en> It is simple, hang up the sides of the bivvy and secure it with the fasteners or, in the case of the M3 remove the infill.
<G-vec00178-001-s074><secure.befestigen><de> Nur vorwärts gerichtete Sitze sind an Bord gestattet und das Bordpersonal muss in der Lage sein, diesen sicher am Flugzeugsitz zu befestigen.
<G-vec00178-001-s074><secure.befestigen><en> Only forward facing seats are allowed on board and the crew must be able to secure it safely to the aircraft seat.
<G-vec00178-001-s075><secure.befestigen><de> Neuen Draht vorsichtig wie folgt einsetzen: Ein Ende des Drahtes in der Kerbe befestigen.
<G-vec00178-001-s075><secure.befestigen><en> Carefully replace the new wire as follows: Secure one end of the wire into the groove.
<G-vec00407-001-s264><attach.befestigen><de> • Nehmen Sie den Ableitungsschlauch, der im Installationskit enthalten ist, und befestigen Sie in am Abflussanschluss auf der Rückseite des ADVANTAGE Plus.
<G-vec00407-001-s264><attach.befestigen><en> • Locate the drain hose located in the installation kit and attach the fitting to the drain fitting on the back of the ADVANTAGE Plus.
<G-vec00407-001-s265><attach.befestigen><de> Auch die richtige Technik für die Durchführung ein Kanu Overland und wie sicher und befestigen Sie das Kanu an Ihrem Fahrzeug auf Reisen Ende sind wichtige Dinge, die man lernt, wenn man Wildnis Kanus Ausbildung übernehmen wird.
<G-vec00407-001-s265><attach.befestigen><en> Also, the proper technique for carrying a canoe overland as well as how to safely and securely attach the canoe to your vehicle at trips end are important things that you will learn when you take wilderness canoes training.
<G-vec00407-001-s266><attach.befestigen><de> Entfernen Sie den Empfänger und befestigen Sie den Schlauch an der Seite auf der Nabe und befestigen Sie das andere Ende an der Nabe auf der linken Seite des Tremblr.
<G-vec00407-001-s266><attach.befestigen><en> Remove the receiver and attach the hose to the boss on its side then attach the other end to the boss on the left side of the Tremblr.
<G-vec00407-001-s268><attach.befestigen><de> Befestigen Sie es auf Untergründen, kleben Sie es auf Schubladen oder eine beliebige Aufbewahrungsbox und schreiben Sie einfach mit einem Stift auf das, was Sie darin aufbewahrt haben.
<G-vec00407-001-s268><attach.befestigen><en> Attach it to those small plastic container, stick it on drawers or any storage box and simply use a pen to write on it what you have stored inside.
<G-vec00407-001-s269><attach.befestigen><de> Befestigen Sie den Leser am 16-poligen Anschluss Ihres Autos, der sich normalerweise unter dem Lenkrad befindet.
<G-vec00407-001-s269><attach.befestigen><en> Attach the reader to your carâ€2s 16-pin port, which is usually located under the steering wheel.
<G-vec00407-001-s270><attach.befestigen><de> Befestigen Sie jedes beliebige Filmobjektiv am Bildsucher um eine getreue photorealistische Visualisierung zu erhalten.
<G-vec00407-001-s270><attach.befestigen><en> Attach any cinema lens to the viewfinder to get a true rendering of the image.
<G-vec00407-001-s271><attach.befestigen><de> Bei der Hilfe kruglogubzew biegen Sie die Anschlussringel auseinander, festigen Sie sie auf den Blindverschlüssen und befestigen Sie an ihm beide Teile samotschka.
<G-vec00407-001-s271><attach.befestigen><en> By means of kruglogubets unbend connecting ringlets, fix them on caps and attach to them both parts of a lock.
<G-vec00407-001-s272><attach.befestigen><de> Befestigen Sie die Abdeckung entgegengesetzt der Schritte 1 und 2.
<G-vec00407-001-s272><attach.befestigen><en> Attach the cover reverse steps 1 and 2
<G-vec00407-001-s273><attach.befestigen><de> Dann können Sie die Fahrräder nacheinander in die verstellbaren Radschienen, und befestigen Sie die Rahmenhalterungen an den Rädern.
<G-vec00407-001-s273><attach.befestigen><en> Then you can place the bicycles one by one in the adjustable wheel channels and attach the frame brackets to the bicycles.
<G-vec00407-001-s274><attach.befestigen><de> Der Glaskörper wird durch Gas oder Silikonöl ersetzt, um die Netzhaut wieder zu befestigen, da sie nur durch den Druck des Glaskörpers in ihrer Lage gehalten wird.
<G-vec00407-001-s274><attach.befestigen><en> The vitreous is replaced by gas or silicone oil, in order to attach the retina again. Precaution
<G-vec00407-001-s275><attach.befestigen><de> Befestigen Sie dann einen kalten Gegenstand an der beschädigten Stelle - Fleisch aus dem Gefrierschrank, kaltes Metall oder idealerweise einen Eisbeutel.
<G-vec00407-001-s275><attach.befestigen><en> then attach any cold object to the damaged area - meat from the freezer, cold metal, or, ideally, an ice pack.
<G-vec00407-001-s276><attach.befestigen><de> Befestigen Sie unter Verwendung der Muttern an den oberen Gewindestangen die Halteklammer an der Maschine.
<G-vec00407-001-s276><attach.befestigen><en> Attach the drive bracket to the machine using the nuts on the top bars.
<G-vec00407-001-s277><attach.befestigen><de> Befestigen Sie einfach die Dartscheibe umgibt auf der Dartscheibe, Klemmen Dartscheibe leicht um eine Standard-Borsten, keine Befestigungen erforderlich.
<G-vec00407-001-s277><attach.befestigen><en> Simply attach the dartboard surrounds around the dartboard, clamps easily around a standard bristle dartboard, no fixings required.
<G-vec00407-001-s278><attach.befestigen><de> PicNClic - Befestigen Sie Audio zum Bild, klicken Sie mit der Maus oder auf den Bildschirm tippen, um zum nächsten Foto und Soundclip zu bewegen.
<G-vec00407-001-s278><attach.befestigen><en> PicNClic - Attach audio to picture, click the mouse or tap the screen to move to the next photo and sound clip.
<G-vec00407-001-s279><attach.befestigen><de> Befestigen Sie Stäbe und Federn aneinander, um einfache Pendel, Federschwingungen, Hookesches Gesetz und Rotationsbewegung zu untersuchen.
<G-vec00407-001-s279><attach.befestigen><en> Attach rods and springs to investigate simple pendulums, spring oscillations, Hooke's Law and rotational motion.
<G-vec00407-001-s280><attach.befestigen><de> Damit man den Schlauch von der Hand nicht halten musste, befestigen Sie an der Wand in der bequemen Höhe die Ergreifung, die zulassen wird das Netz in einer beliebigen Lage so, dass der Strahl des Wassers zu unterbringen fiel schief auf die Schultern und den Brustkorb badend unabhängig von seiner Größe.
<G-vec00407-001-s280><attach.befestigen><en> That it was not necessary to hold a hose a hand, to a wall at convenient height attach capture which will allow to place a grid in any position so that the water stream fell slantwise on shoulders and a thorax bathing irrespective of its growth.
<G-vec00407-001-s281><attach.befestigen><de> Befestigen Sie den Clip dann an Ihrem Monitor.
<G-vec00407-001-s281><attach.befestigen><en> Then, attach the clip to your monitor.
<G-vec00407-001-s282><attach.befestigen><de> Wie man es benutzt: Legen Sie das Foto von unten in den Rahmen und befestigen Sie es mit einem Clip am Garn.
<G-vec00407-001-s282><attach.befestigen><en> How to use it: Insert the photo into the frame from below and attach it to the twine with a clip.
<G-vec00407-001-s283><attach.befestigen><de> Liganden enthalten ungesättigte Fettsäuren die sich an das Cholesterin befestigt und es zur Leber zur Beseitigung transportieren, eine Funktion die das metabolische Syndrom das zum Bluthochdruck führt verhindert.
<G-vec00407-001-s283><attach.befestigen><en> Ligands contain polyunsaturated fatty acids that attach themselves to cholesterol and transport it to the liver for elimination, a function that avoids metabolic syndrome linked to hypertension
<G-vec00407-001-s284><attach.befestigen><de> Hergestellt aus leichtem Styropor, ausgestattet mit einem Griff für die Angelschnur sowie mit einer Schnur, die an einem Träger oder Ständer befestigt ist.
<G-vec00407-001-s284><attach.befestigen><en> Made of a light Styrofoam tipped with a fishing line mount and a string to attach it to rod pod or rest.
<G-vec00407-001-s285><attach.befestigen><de> Der Hartan Sonnenschirm ist ein idealer Schattenspender und wird einfach am Hartan Kinderwagen befestigt.
<G-vec00407-001-s285><attach.befestigen><en> The Hartan Parasol is an ideal shade and is easy to attach at the Hartan stroller.
<G-vec00407-001-s286><attach.befestigen><de> Sie können einfach befestigt werden und sind dazu in drei unterschiedlichen Farben erhältlich.
<G-vec00407-001-s286><attach.befestigen><en> They are easy to attach and are available in three different colors.
<G-vec00407-001-s287><attach.befestigen><de> Auf der Rückseite befindet sich eine Halterung, die zum Beispiel an dem Gürtel in der Hose leicht befestigt werden kann.
<G-vec00407-001-s287><attach.befestigen><en> On the back there is a fastening, which makes it easy to attach, for example, to the belt in the trousers.
<G-vec00407-001-s288><attach.befestigen><de> Diese Teile können sicher an Ihrem Motor an der dafür vorgesehenen Stelle befestigt werden.
<G-vec00407-001-s288><attach.befestigen><en> These parts will attach securely to your engine in the space provided.
<G-vec00407-001-s289><attach.befestigen><de> Das Halsband ist ein hübsches Standarddesign mit einem glänzenden D-Ring auf der Vorderseite, an dem die Leine befestigt werden kann.
<G-vec00407-001-s289><attach.befestigen><en> The collar is a pretty standard design featuring a shiny riveted 'D' ring on the front for the leash to attach to.
<G-vec00407-001-s290><attach.befestigen><de> Sie werden einfach mit ihrem Schliesssystem um Ihre Brustwarzen befestigt.
<G-vec00407-001-s290><attach.befestigen><en> They will simply attach around your nipples thanks to their closure system.
<G-vec00407-001-s291><attach.befestigen><de> Dank der extrem starken verbauten Magnete können an diesem Messerblock mindestens 8 Messer mit bis zu 900 g Gewicht sicher befestigt werden.
<G-vec00407-001-s291><attach.befestigen><en> Thanks to the extremely strong embedded magnets, you can safely attach at least 8 knives with a weight of up to 900Â g.
<G-vec00407-001-s292><attach.befestigen><de> Wir machen das dritte Paar und ist sie an ersten zwei befestigt.
<G-vec00407-001-s292><attach.befestigen><en> We do the third couple and we attach it to the first to two.
<G-vec00407-001-s293><attach.befestigen><de> Der Bass Buggie kann in sehr kurzer Zeit am Kontrabass befestigt werden: das einstellbare Gürtelsystem wird mit einer strapazierfähigen, elastischen Schlaufe am Hals angebracht, während das andere Ende des Bass Buggies am Stachelhalter befestigt wird.
<G-vec00407-001-s293><attach.befestigen><en> It's easy and fast to attach the Buggie to the double bass: the adjustable double belt system attaches to the neck of the double bass with a sturdy elastic strap, while the lower end of the Bass Buggie attaches to the endpin, which does not have to be removed.
<G-vec00407-001-s294><attach.befestigen><de> Danach werden die beiden Anhängungen aufgeklappt, mit der die Betonierbühne an der Schalung befestigt wird.
<G-vec00407-001-s294><attach.befestigen><en> The two support brackets are then deployed. These are used to attach the concreting platform to the formwork.
<G-vec00407-001-s295><attach.befestigen><de> Dieses Holzmodell von Master Series ist einfach zu installieren und hat zwei abnehmbare Befestigungselemente, die an den Knöcheln des Untergebenen befestigt werden.
<G-vec00407-001-s295><attach.befestigen><en> This wooden model, proposed by Master Series, is easy to install and has two removable fasteners, to attach to your subject's ankles.
<G-vec00407-001-s296><attach.befestigen><de> So können Gemälde auch im Inneren der Transportkiste befestigt werden.
<G-vec00407-001-s296><attach.befestigen><en> It can also be used to attach paintings to the inside of transportation crates.
<G-vec00407-001-s297><attach.befestigen><de> Die Magnetrahmen sorgen dafür, dass die verschiedenen Filter einfach am Filterhalter befestigt werden können.
<G-vec00407-001-s297><attach.befestigen><en> The magnetic frames ensure that you can easily attach the various filters to the filter holder.
<G-vec00407-001-s298><attach.befestigen><de> Um ihn noch einfacher, aber auch in allen Situationen benutzen zu können, liefert Doc Johnson diesen Dildo mit einem abnehmbaren Vac-U-Lock Saugnapf, der sicher an jeder glatten, ebenen Oberfläche befestigt werden kann.
<G-vec00407-001-s298><attach.befestigen><en> In order to use it even more easily, but also in all situations, Doc Johnson has supplied this dildo with a Vac-U-Lock removable suction cup, which will attach securely to any smooth, flat surface.
<G-vec00407-001-s299><attach.befestigen><de> Die Larve, die eine Auster werden soll, muss irgendwo an einer Wand befestigt werden.
<G-vec00407-001-s299><attach.befestigen><en> The larva to become an oyster needs to attach to a wall somewhere.
<G-vec00407-001-s300><attach.befestigen><de> Das weisse Ladekabel hat einen runden Kopf mit zwei Magnettasten, die sicher an Ihrem Sextoy befestigt werden können.
<G-vec00407-001-s300><attach.befestigen><en> The white charging cable has a round head with two magnetic buttons that attach securely to your toy.
<G-vec00407-001-s301><attach.befestigen><de> Mit den beiden mitgelieferten Messingschrauben wird der Tonabnehmer an der Headshell befestigt.
<G-vec00407-001-s301><attach.befestigen><en> Two brass mounting screws are provided to attach the cartridge to the shell.
<G-vec00322-002-s092><fix.befestigen><de> Es muss also mit einer Kausche befestigt oder an eine Kupplung mit sehr glatter Oberfläche gebunden werden.
<G-vec00322-002-s092><fix.befestigen><en> For this reason it is necessary to fix the rope with a thimble or tie it to a coupler with a very smooth surface.
<G-vec00322-002-s093><fix.befestigen><de> Vor dem Verkleben der Mineralwolle-Dämmplatten sollte das Sockelprofil, das entsprechend der Dicke der Wärmedämmplatten ausgewählt wird, sorgfältig waagerecht ausgerichtet und befestigt werden.
<G-vec00322-002-s093><fix.befestigen><en> Mounting the skirting Carefully level and fix the skirting matched to the insulation board thickness before bonding the mineral wool boards.
<G-vec00322-002-s094><fix.befestigen><de> Das Regalsystem wird mit nur vier Schrauben und Dübeln an der Wand befestigt.
<G-vec00322-002-s094><fix.befestigen><en> Four screws and dowels are needed to fix the shelf on the wall.
<G-vec00322-002-s095><fix.befestigen><de> In diesem Artikel wird Dekorin zeigen und zeigen, wie die Verengung der Sofas und Sessel mit einer neuen Polsterung durchgeführt wird, was die Füllung der Kissen ersetzen kann, wie man die Federn befestigt und die kleinen Schäden verschleiert.
<G-vec00322-002-s095><fix.befestigen><en> In this article Dekorin will tell and show how the constriction of the sofas and armchairs with a new upholstery is performed, what can replace the filling of the pillows, how to fix the springs and disguise the minor damages.
<G-vec00322-002-s096><fix.befestigen><de> Wie man eine verlorene Masche in einer Strickarbeit befestigt.
<G-vec00322-002-s096><fix.befestigen><en> How to fix a lost knitted stitch
<G-vec00322-002-s097><fix.befestigen><de> Der Montagerahmen wird in den Kanal eingesetzt und befestigt.
<G-vec00322-002-s097><fix.befestigen><en> Push the installation frame into the duct and fix it.
<G-vec00322-002-s098><fix.befestigen><de> Fügt an der Display Platine die Abstandshalter hinzu und befestigt diese mit den mitgelieferten Muttern.
<G-vec00322-002-s098><fix.befestigen><en> Add the spacers to the display board and fix them with the nuts.
<G-vec00322-002-s099><fix.befestigen><de> Zunächst wird das Fliehkraftgerät mit der Tischklemme am Tisch befestigt.
<G-vec00322-002-s099><fix.befestigen><en> Use the bench clamp to fix the centrifugal force apparatus to the table.
<G-vec00322-002-s100><fix.befestigen><de> Belgien Das mit einem funkelnden SS34 Xirius Chaton versehene 53005 Swarovski...Crystal Rivet ist in einer breiten Palette an bezaubernden Farben erhältlich, unter anderem in Messing mit Beschichtung in den Farben Gold, Silber, Dunkelsilber und Rotgold sowie Edelstahl....Mithilfe dieser Niete lässt sich perfekt sicherstellen, dass Kristalle extra sicher befestigt sind, wobei sich die Ausführung in Edelstahl besonders gut für die Anwendung auf Lederartikeln eignet.
<G-vec00322-002-s100><fix.befestigen><en> 53005 Rivets Featuring a dazzling SS34 Xirius Chaton, the 53005 Swarovski Crystal R...ivet offers a choice of stunning colors, including gold-, silver-, gunmetal- and rose gold-finished brass, in addition to stainless steel. It is a perfect way to ensure that crystals are fix...ed extra securely, with the stainless steel version being especially well suited for use on leather goods.
<G-vec00322-002-s101><fix.befestigen><de> Dann schneidet ihr kleine Notizzettel (oder nehmt einfach einen Post-it-Block) und befestigt sie mit Papierklammern am Bierdeckel.
<G-vec00322-002-s101><fix.befestigen><en> Then cut small notepads (or take a post-it pad) and fix them with a paper clip.
<G-vec00322-002-s102><fix.befestigen><de> Die Handhabung ist schnell und einfach: Man schiebt das Seil durch den Lauf, befestigt vorn auf dem Adapter den Laufreiniger und zieht mit Hilfe der Griffscheibe das Seil durch den Lauf.
<G-vec00322-002-s102><fix.befestigen><en> It is quick and simple to operate: push the wire through the barrel, fix the barrel cleaner on the adaptor and pull the wire through the barrel with the help of the grip disc.
