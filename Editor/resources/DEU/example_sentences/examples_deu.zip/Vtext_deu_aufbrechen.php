<G-vec00081-001-s076><break.aufbrechen><de> Doch ich kann es nicht in die Praxis umsetzen.“ Ich dachte nach: “Das Fa kann allen Eigensinn aufbrechen, das Fa kann alles Böse besiegen, das Fa kann alle Lügen strafen, das Fa kann den rechten Gedanken festigen.“ (Aus „Störungen beseitigen“ in Essentielles für weitere Fortschritte) Ich beschloss, das Fa mit ihm zu lernen.
<G-vec00081-001-s076><break.aufbrechen><en> "I thought: ""The Fa can break all attachments, the Fa can destroy all evil, the Fa can shatter all lies, and the Fa can strengthen righteous thoughts."" (from ""Drive Out Interference"") I decided to study the Fa with him."
<G-vec00081-001-s077><break.aufbrechen><de> Nahrung Die Kakadus ernähren sich überwiegend von Pflanzen, wobei sie auch sehr harte Nüsse und Samen mit den kräftigen Schnäbeln aufbrechen können.
<G-vec00081-001-s077><break.aufbrechen><en> Food The cockatoos live mainly from plants, with what they can break also very hard nuts and seeds with the powerful beaks open.
<G-vec00081-001-s078><break.aufbrechen><de> Malz ist zu fein geschrotet -> Körner nur aufbrechen, nicht feinmahlen.
<G-vec00081-001-s078><break.aufbrechen><en> Malt is too finely crushed -> only break grains up, do not mill too finely.
<G-vec00081-001-s079><break.aufbrechen><de> Dies soll bis 2025 nichts weniger als die Vierte Industrielle Revolution werden und viele Errungenschaften der vorhergehenden industriellen Revolutionen wie Mechanisierung, Kraftmaschinen und Fließband aufbrechen, neu kombinieren oder gar restlos ersetzen.
<G-vec00081-001-s079><break.aufbrechen><en> By 2025, this will be nothing less than the fourth industrial revolution and will break down, regroup or even completely replace many achievements of the previous industrial revolutions, such as mechanisation, engines and the production line.
<G-vec00081-001-s080><break.aufbrechen><de> """Nochmals, es ist mit Sinnlichkeit als der Grund, Sinnlichkeit als die Quelle... daß [Menschen] Fenster aufbrechen, Plünderei ergreifen, Einbruch begehen, Landstraßen überfallen, Vergewaltigung begehen, und dann werden sie gefangen von, Könige lassen sie auf verschiedene Weise quälen."
<G-vec00081-001-s080><break.aufbrechen><en> """Again, it is with sensuality for the reason, sensuality for the source... that [men] break into windows, seize plunder, commit burglary, ambush highways, commit adultery, and when they are captured, kings have them tortured in many ways."
<G-vec00081-001-s081><break.aufbrechen><de> Das Wachstum hat begonnen und ihr werdet so schnell wachsen, dass diese Schale, die die menschlichen Konditionierungen und das Ego bilden, einfach aufbrechen wird.
<G-vec00081-001-s081><break.aufbrechen><en> And you’ll grow so fast that this shell, which is this human conditioning and egos will just break open.
<G-vec00081-001-s082><break.aufbrechen><de> Ein stiller, nachdenklicher Reisefilm ist es geworden, der sich vor allem der Frage widmet, warum man glaubt, aufbrechen zu müssen.
<G-vec00081-001-s082><break.aufbrechen><en> It has turned out to be a quiet, thoughtful film, which dedicates itself above all to the question of why one believes in having to break open.
<G-vec00081-001-s083><break.aufbrechen><de> Wenn Sie Kutools for ExcelMit seinen Finde und zerbrich gebrochene Links Mit dieser Funktion können Sie die Verbindungszellen anzeigen und lokalisieren und sie nach Bedarf aufbrechen.
<G-vec00081-001-s083><break.aufbrechen><en> If you have Kutools for Excel, with its Find and Break Broken Links feature, you can view and locate the link cells, and break them as you need.
<G-vec00081-001-s084><break.aufbrechen><de> Gelegenheitsdiebe haben kaum eine Chance, denn ein Aufbrechen der verschlossenen und verriegelten Fenster mit Schraubendreher, Zange und Keil ist fast unmöglich.
<G-vec00081-001-s084><break.aufbrechen><en> Occasional thieves have virtually no chance and are discouraged because it is almost impossible to break the closed and locked windows with simple tools like screwdriver, tongs and wedges.
<G-vec00081-001-s085><break.aufbrechen><de> Und weil die Elektronik um den Fuß herum verteilt ist, kann man die Fessel auch nicht so leicht aufbrechen oder durchschneiden – und das, obwohl man für das Anbringen und Entfernen der Fussfesseln keine Werkzeuge benötigt.
<G-vec00081-001-s085><break.aufbrechen><en> And because the electronics are distributed around the ankle, it is also not so easy to break or cut through the ankle bracelet – and this despite the fact that that no tools are needed to attach and remove the devices.
<G-vec00081-001-s086><break.aufbrechen><de> Zuerst muss man die drei Glieder von einer der Stücke Kette aufbrechen.
<G-vec00081-001-s086><break.aufbrechen><en> First, break open all three links of one of the pieces of chain.
<G-vec00081-001-s087><break.aufbrechen><de> Dieser Begriff bezeichnet solche Stoffgemische, die zum Aufbrechen von Ölfilmen an der Wasseroberfläche führen und die Bildung von Dispersionen (feinen Tröpfchen) fördern.
<G-vec00081-001-s087><break.aufbrechen><en> This term denotes substance mixtures which break up oil films on the surface of the water and which facilitate the formation of dispersions (i.e. fine droplets).
<G-vec00081-001-s088><break.aufbrechen><de> Belastbar und ein Leichtgewicht, sind diese Töpfe genau so konzipiert, dass sie leicht aufbrechen können, damit Ihre Cannabis-Pflanzen groß und stark wachsen können.
<G-vec00081-001-s088><break.aufbrechen><en> Resilient and lightweight, these pots have been designed to break down over time so that your cannabis plants can grow big and strong.
<G-vec00081-001-s089><break.aufbrechen><de> anCnoc Peated Range - 11.1 ppm Die Rascan Werkzeug wird verwendet zum Aufbrechen der obersten Ebene des rauen Boden und bereiten den Boden für die Torf Ernte vor.
<G-vec00081-001-s089><break.aufbrechen><en> anCnoc Peated Range - 11.1 ppm The Rascan tool is used to break up the top level of rough ground and prepare the land for peat harvesting.
<G-vec00081-001-s090><break.aufbrechen><de> Die Bindung an das Rad der Wiedergeburt aufzubrechen hängt hauptsächlich von unserer Ernsthaftigkeit und Entschlossenheit ab: Das ist es nämlich, was uns den Weg frei macht und warum auch die Lebewesen diese Bindung nicht anrühren und nicht aufbrechen wollen.
<G-vec00081-001-s090><break.aufbrechen><en> To break open the binding of the wheel of rebirth depends mainly on our being earnest and intent: That's what will clear our way. This is why living beings don't want to touch that binding, don't want to break it open.
<G-vec00081-001-s091><break.aufbrechen><de> Es ist schwer zu sagen, welche Ergebnisse eine soziale Revolution in Saudi-Arabien haben wird, aber es ist klar, dass der jetzige Zustand zu einem bestimmten Punkt aufbrechen muss.
<G-vec00081-001-s091><break.aufbrechen><en> What the result of a social explosion will be in Saudi Arabia is hard to tell, but it is clear that the status quo is bound to break up at a certain point.
<G-vec00081-001-s092><break.aufbrechen><de> Internetunternehmen bedrohen Kundenbeziehungen Auf der Konferenz beleuchten Experten, wie die Luftfahrtunternehmen alte Strukturen aufbrechen und neue Wege einschlagen können.
<G-vec00081-001-s092><break.aufbrechen><en> Internet businesses threaten customer relationships Experts at the conference will be shedding light on how aviation companies can break free of old structures and explore new routes.
<G-vec00081-001-s093><break.aufbrechen><de> Lipnja 2015 ein Team von Experten und Helfern nach Nigeria aufbrechen, um im Nigerdelta mit Hilfe der PURE-Watte, eines speziellen Flieses, auf eigene Kosten ein ölverseuchtes Gewässer zu reinigen .
<G-vec00081-001-s093><break.aufbrechen><en> June 2015 a team of experts and volunteers to Nigeria break up, to in the Niger Delta with the help of PURE cotton, a special Flieses, at his own expense to clean an oil-contaminated waters.
<G-vec00081-001-s094><break.aufbrechen><de> Ozon und UV-Strahlung können die Kettenmoleküle des Elastomerwerkstoffs aufbrechen.
<G-vec00081-001-s094><break.aufbrechen><en> Ozone and UV radiation can break down the chain molecules of the elastomer material.
<G-vec00081-001-s114><break.aufbrechen><de> Richtet den Bereich mit Hilfe von Gartenrechen,sicher sein, große Klumpen aufzubrechen.
<G-vec00081-001-s114><break.aufbrechen><en> Aligns the area with the help of garden rakes,be sure to break up large clumps.
<G-vec00081-001-s115><break.aufbrechen><de> Während der Weltsicherheitsrat die Verhängung neuer Sanktionen gegen Eritrea erwägt und das Land immer mehr als Paria behandelt, versucht Uganda, die Isolation Eritreas aufzubrechen.
<G-vec00081-001-s115><break.aufbrechen><en> While the Security Council is always trying to impose new sanctions against Eritrea to marginalize the country, Uganda is trying to break up Eritrea's isolation.
<G-vec00081-001-s116><break.aufbrechen><de> Sie müssen sich unter der Oberfläche zu graben und sich an die Wurzel dessen, was führte zu Ihren aufzubrechen.
<G-vec00081-001-s116><break.aufbrechen><en> You need to dig below the surface and get to the root of what led to your break up.
<G-vec00081-001-s117><break.aufbrechen><de> [Jemand versucht die Tür aufzubrechen.
<G-vec00081-001-s117><break.aufbrechen><en> [Somebody tries to break out the door.
<G-vec00081-001-s118><break.aufbrechen><de> Wir haben vor, dieses Marktsegment vollständig aufzubrechen mit der Einführung unserer neuen Maschine, die zur BAUMA 2010 auf den Markt gebracht werden soll.
<G-vec00081-001-s118><break.aufbrechen><en> We are planning to break open this market segment completely with the introduction of our new machine, to be launched at BAUMA 2010.
<G-vec00081-001-s119><break.aufbrechen><de> Ich bin überzeugt: Seine mutige Politik der ausgestreckten Hand ist der richtige Weg, um die verhärteten Fronten in vielen Konflikten aufzubrechen und die friedliche Zusammenarbeit zwischen den Völkern zu fördern.
<G-vec00081-001-s119><break.aufbrechen><en> I am convinced that his courageous policy of reaching out to others is the right path to break through hardened fronts in many conflicts and to promote peaceful cooperation among nations.
<G-vec00081-001-s120><break.aufbrechen><de> Sie hatte keine Ahnung davon, daß es jetzt mit Karl soweit gekommen war, daß er fremde Türen mit Messern aufzubrechen suchte.
<G-vec00081-001-s120><break.aufbrechen><en> She had no idea that Karl would now come so far as to try to break open strange doors with knives.
<G-vec00081-001-s121><break.aufbrechen><de> Was genau hinter den verschlossenen Türen des inneren Heiligtums geschah, während die Untoten und Dämonen versuchten diese aufzubrechen, wird wohl für immer im Dunkeln bleiben.
<G-vec00081-001-s121><break.aufbrechen><en> What exactly happened behind the closed doors of the inner sanctum while demons and undead strove to break then down,
<G-vec00081-001-s122><break.aufbrechen><de> Dafür röstet er den Kaffee besonders schonend: Rund 20 Minuten bekommt die Kaffeebohne bei ihm Zeit, um aufzubrechen und ihr Aroma freizusetzen.
<G-vec00081-001-s122><break.aufbrechen><en> He roasts the beans sparingly, giving them just 20 minutes to break open and release their aroma.
<G-vec00081-001-s123><break.aufbrechen><de> Überschriften und Bilder helfen dabei, den Inhalt aufzubrechen.
<G-vec00081-001-s123><break.aufbrechen><en> Headings and images both help to break up your content.
<G-vec00081-001-s124><break.aufbrechen><de> Das Wandern bedurfte einer kleinen Anfahrt, direkt am Haus zu Fuß aufzubrechen war eigentlich nicht möglich.
<G-vec00081-001-s124><break.aufbrechen><en> The hiking required a small approach, right at the house on foot break was not really possible.
<G-vec00081-001-s125><break.aufbrechen><de> Mit anderen Worten, ein einziger blutiger Zusammenstoß würde ausreichen, um die Armee aufzubrechen.
<G-vec00081-001-s125><break.aufbrechen><en> In other words, a single bloody clash would be sufficient to break the army in pieces.
<G-vec00081-001-s126><break.aufbrechen><de> Nachdem der Kunstrasen gelegt hat sollte broomed werden per hand oder mit einem Besen macht die Fasern aufzustehen und zu beginnen, um aufzubrechen oder Ausfransen der Kunstrasen Fasern vor keinen Sand in die Grasnarbe fallen gelassen wird.
<G-vec00081-001-s126><break.aufbrechen><en> After the artificial turf has been laid out it should be broomed by hand or with a power broom to stand up the fibers and to begin to break up or fray the artificial turf fibers before any sand is dropped into the turf.
<G-vec00081-001-s127><break.aufbrechen><de> Es geht darum, den Komplex, der unsere Realität ist, aufzubrechen, in seinen Facetten zu zeigen, um ihn so befragbar und verhandelbar zu machen.
<G-vec00081-001-s127><break.aufbrechen><en> The aim is to break open the complex that constitutes our reality, showing it in all its facets as a way of enabling us to interrogate it.
<G-vec00081-001-s128><break.aufbrechen><de> Die Herausforderung fÃ1⁄4r die Linke liegt darin, die Kluft zwischen einer liberalen und konservativen Rechten aufzubrechen und eine Alternative zu bieten, die soziale Rechte und Schutz erweitert, gleichzeitig jedoch demokratische Rechte und BÃ1⁄4rger_innenrechte verteidigt.
<G-vec00081-001-s128><break.aufbrechen><en> The challenge for the left is to break the divide between a liberal and conservative right and offer an alternative that extends social rights and protections but also defends democratic and civil rights.
<G-vec00081-001-s129><break.aufbrechen><de> Schmelzenthalpien sind dabei ein einfaches Beispiel für endotherme Vorgänge, da man meistens Wärmearbeit in ein System geben muss, um dessen feste Kristallstruktur aufzubrechen und es in eine flüssige Phase mit frei gegeneinander beweglichen Molekülen zu überführen.
<G-vec00081-001-s129><break.aufbrechen><en> Melt enthalpies are a simple example of endothermic processes, since one usually has to give heat work in a system in order to break up its solid crystal structure and convert it into a liquid phase with molecules that move freely relative to one another.
<G-vec00081-001-s130><break.aufbrechen><de> Der Imperiale Bergungsdienst geht davon aus, dass die Fabrik nun ein Netzwerk von Traktorstrahlen nutzt, um nahegelegene Asteroiden einzufangen und aufzubrechen und so die Versorgung mit Rohstoffen für ihre endlose Massenproduktion sicherzustellen.
<G-vec00081-001-s130><break.aufbrechen><en> The Imperial Reclamation Service believes the Foundry now uses a network of tractor beams to capture and break apart nearby asteroids, providing raw materials for its endless mass production.
<G-vec00081-001-s131><break.aufbrechen><de> Die einströmende Suspension wird in eine Vortexrotation mit hoher Flussgeschwindigkeit versetzt, um vorhandene Flocken aufzubrechen und die Entstehung neuer Flocken durch die Agglomeration von Fasern zu verhindern.
<G-vec00081-001-s131><break.aufbrechen><en> In order to break up existing flocks and prevent the agglomeration of fibers into new flocks, the incoming suspension is put into a vortex rotation with a high flow velocity.
<G-vec00081-001-s132><break.aufbrechen><de> Sie dachten, es sei niemand zu Hause und riefen einen Schlüsseldienst herbei, um das Schloss aufzubrechen und entdeckten dann, dass Herr Zhao daheim war.
<G-vec00081-001-s132><break.aufbrechen><en> They thought that no one was home and called a locksmith to break the lock and discovered that Mr. Zhao was home.
<G-vec00218-002-s038><break.aufbrechen><de> Wir mussten sie aufbrechen, ohne sie zu zerbrechen.
<G-vec00218-002-s038><break.aufbrechen><en> We needed to break it up, without breaking it.
<G-vec00218-002-s039><break.aufbrechen><de> Ralf Heinrich, Schulleiter, erklärt: „Mit Musik kann man wirklich vieles aufbrechen und auch manche Themen, die ernst sind, kann man mit ganz anderem Schwung versehen.
<G-vec00218-002-s039><break.aufbrechen><en> Ralf Heinrich, a headmaster, states, “Music can be used to break down an awful lot of barriers and some topics, which are serious, can be given a very different impetus.
<G-vec00218-002-s040><break.aufbrechen><de> Um es Unternehmen und ihren Mitarbeitern einfacher zu machen, haben einige der Normungsgremien weitere Richtlinien herausgegeben, die die riesige Liste der Kontrollen in erreichbare Ziele aufbrechen.
<G-vec00218-002-s040><break.aufbrechen><en> So to make it easier for companies and the humans that work there, some of the standards group have issued further guidelines that break the huge list of controls into more achievable goals.
<G-vec00218-002-s041><break.aufbrechen><de> Das einladende Café mit Sonnenterrasse garantiert einen gelungenen Start in den Tag, bevor aktive Urlauber in die zahlreichen Abenteuer der Region aufbrechen.
<G-vec00218-002-s041><break.aufbrechen><en> The inviting café with a sun terrace guarantees a successful start to the day, before active holidaymakers break into the numerous adventures of the region.
<G-vec00218-002-s042><break.aufbrechen><de> So kommt es, dass Menschen Aufbrechen.
<G-vec00218-002-s042><break.aufbrechen><en> So it happens that people break up.
<G-vec00218-002-s043><break.aufbrechen><de> Die neuen Online-Postleitzahlen gelten als Wegbereiter für das „Internet der Dinge“ und sollen die Knappheit an IP-Adressen für den Anschluss von PCs und Handys an das Datennetz aufbrechen.
<G-vec00218-002-s043><break.aufbrechen><en> The new online postal codes are valid as pioneers for the “Internet of things” and are to break open the shortage of IP addresses for the connection of PCs and cell phones to the data net.
<G-vec00218-002-s045><break.aufbrechen><de> Um Ihnen die Formatierung zu vereinfachen, stellt TortoiseSVN Dialoge für einige Eigenschaften zur Verfügung, die die Auswahlmöglichkeiten anzeigen oder die Eigenschaft in ihre individuellen Komponenten aufbrechen.
<G-vec00218-002-s045><break.aufbrechen><en> To help get the formatting correct, TortoiseSVN presents edit dialogs for some particular properties which show the possible values or break the property into its individual components.
<G-vec00218-002-s046><break.aufbrechen><de> Sie schrien, dass sie die Tür aufbrechen würden, wenn wir nicht öffneten.
<G-vec00218-002-s046><break.aufbrechen><en> They yelled that they would break in if we refused to open the door.
<G-vec00218-002-s047><break.aufbrechen><de> Die Intention dahinter blieb immer das Aufbrechen von Bekanntem, die positive Aufladung des (öffentlichen) Raums sowie eine bleibende Erinnerung an das gemeinschaftliche Zusammenarbeiten zu erschaffen.
<G-vec00218-002-s047><break.aufbrechen><en> The intention behind it was always to break up the familiar and stimulate the positive charge of (public) space and a lasting memory for the community.
<G-vec00218-002-s048><break.aufbrechen><de> Anhand der Spektren – die den Einzelbildern eines Films entsprechen – lässt sich deshalb gleichsam in Zeitlupe nachweisen, wie sich der Eisenkomplex unter Laserbeschuss über mehrere Stufen verformt, die Bindungen aufbrechen und schließlich das Radikal entsteht.
<G-vec00218-002-s048><break.aufbrechen><en> On the basis of the spectra, which correspond to the individual images of a film, it can thus be revealed – essentially in slow motion – how the iron complex deforms under pulsed laser illumination over several stages, the bonds break up and finally the radical is formed.
<G-vec00218-002-s049><break.aufbrechen><de> Auch wenn Sie in einem Zustand der Verleugnung sind, können Sie sehen, dass es Fragen gibt, und zumindest einige Teil von euch rüstet sich für das Aufbrechen.
<G-vec00218-002-s049><break.aufbrechen><en> Even if you are in a state of denial, you can see that there are issues and at least some part of you is gearing up for the break up.
<G-vec00218-002-s050><break.aufbrechen><de> Sie möchten auch die alte Blumenerde aufbrechen, bevor Sie sie verwenden, da sie mit der Zeit trocken und verdichtet werden kann.
<G-vec00218-002-s050><break.aufbrechen><en> You also want to break up the old potting soil before using it, as it can get dry and compacted over time.
<G-vec00218-002-s051><break.aufbrechen><de> „Sam, kann man die Bindung aufbrechen?“ fragte ich.
<G-vec00218-002-s051><break.aufbrechen><en> “Sam, is there a way to break the bond?”
<G-vec00218-002-s052><break.aufbrechen><de> Am Tag: Die Eier mit einem Sägemesser leicht mittig anschneiden und in zwei Hälften aufbrechen.
<G-vec00218-002-s052><break.aufbrechen><en> On the same day Cut the eggs lightly in the middle with a serrated knife and break them into two halves.
<G-vec00218-002-s053><break.aufbrechen><de> Wenn es genug Luftfeuchtigkeit gibt, kann Wind die Ballungen von Wasser-Partikel aufbrechen und so Ionen erzeugen.
<G-vec00218-002-s053><break.aufbrechen><en> When there is enough humidity in the air, wind can break the balls of water particles and thus create ions.
<G-vec00218-002-s054><break.aufbrechen><de> Ein großer Teil des Bildes wird mit Hilfe von Schablonen angelegt, die das Bild in Schichten aufbrechen.
<G-vec00218-002-s054><break.aufbrechen><en> Much of the paint is applied using stencils that break up the images into layers.
<G-vec00218-002-s055><break.aufbrechen><de> Zellulasen müssen das Material erst „aufbrechen“ und aufbereiten.
<G-vec00218-002-s055><break.aufbrechen><en> Cellulose enzymes first have to break down the material and process it.
<G-vec00218-002-s056><break.aufbrechen><de> Der Wind kann WILD IN KAPSTADT auftanken und die Tür aufbrechen, wenn das passiert.
<G-vec00218-002-s056><break.aufbrechen><en> THE WIND CAN GET WILD IN CAPE TOWN AND WILL BREAK THE DOOR OPEN WHEN THAT HAPPENS.
<G-vec00372-002-s023><disrupt.aufbrechen><de> Sich schwach und unmotiviert zu fühlen, sollte nicht normal sein, so dass es wichtig ist, dieses Muster aufzubrechen, sobald man sich dessen bewusst wird.
<G-vec00372-002-s023><disrupt.aufbrechen><en> Feeling weak and unmotivated shouldn't be your norm, so it's important to disrupt this pattern as soon as you become aware of it.
<G-vec00389-002-s022><crush.aufbrechen><de> Die Köpfe mit einem Hammer aufbrechen und die großen Schalenstücke entfernen.
<G-vec00389-002-s022><crush.aufbrechen><en> Crush the heads with a hammer; remove the large pieces of shell.
<G-vec00389-002-s023><crush.aufbrechen><de> Auf dieselbe Weise werden eines Tages eure Freunde von der Unsichtbaren Welt kommen, die Türen eurer Gefängnisse aufbrechen und sagen: „Geht in der Freiheit hinaus!“ Alle heutigen Menschen befinden sich jetzt unter der geistigen Herrschaft der „Türken“, wovon sie sich befreien sollen.
<G-vec00389-002-s023><crush.aufbrechen><en> In the same way one day your friends from the Invisible world will come, will crush the doors of your prisons and will say: “Go outside on free!” Today all contemporary people find under the spiritual slavery of the Turks, which they have to set free from.
<G-vec00389-002-s024><crush.aufbrechen><de> Mein Titan Schraubenschlüssel kann ebenso leicht eine Mutter aus einem Bolzen brechen, als auch Schädel aufbrechen.
<G-vec00389-002-s024><crush.aufbrechen><en> My titanium wrench can crack a rusted nut from a bolt as easily as it can crush skulls.
<G-vec00296-003-s038><break_down.aufbrechen><de> Wir mussten sie aufbrechen, ohne sie zu zerbrechen.
<G-vec00296-003-s038><break_down.aufbrechen><en> We needed to break it up, without breaking it.
<G-vec00296-003-s039><break_down.aufbrechen><de> Ralf Heinrich, Schulleiter, erklärt: „Mit Musik kann man wirklich vieles aufbrechen und auch manche Themen, die ernst sind, kann man mit ganz anderem Schwung versehen.
<G-vec00296-003-s039><break_down.aufbrechen><en> Ralf Heinrich, a headmaster, states, “Music can be used to break down an awful lot of barriers and some topics, which are serious, can be given a very different impetus.
<G-vec00296-003-s040><break_down.aufbrechen><de> Um es Unternehmen und ihren Mitarbeitern einfacher zu machen, haben einige der Normungsgremien weitere Richtlinien herausgegeben, die die riesige Liste der Kontrollen in erreichbare Ziele aufbrechen.
<G-vec00296-003-s040><break_down.aufbrechen><en> So to make it easier for companies and the humans that work there, some of the standards group have issued further guidelines that break the huge list of controls into more achievable goals.
<G-vec00296-003-s041><break_down.aufbrechen><de> Das einladende Café mit Sonnenterrasse garantiert einen gelungenen Start in den Tag, bevor aktive Urlauber in die zahlreichen Abenteuer der Region aufbrechen.
<G-vec00296-003-s041><break_down.aufbrechen><en> The inviting café with a sun terrace guarantees a successful start to the day, before active holidaymakers break into the numerous adventures of the region.
<G-vec00296-003-s042><break_down.aufbrechen><de> So kommt es, dass Menschen Aufbrechen.
<G-vec00296-003-s042><break_down.aufbrechen><en> So it happens that people break up.
<G-vec00296-003-s043><break_down.aufbrechen><de> Die neuen Online-Postleitzahlen gelten als Wegbereiter für das „Internet der Dinge“ und sollen die Knappheit an IP-Adressen für den Anschluss von PCs und Handys an das Datennetz aufbrechen.
<G-vec00296-003-s043><break_down.aufbrechen><en> The new online postal codes are valid as pioneers for the “Internet of things” and are to break open the shortage of IP addresses for the connection of PCs and cell phones to the data net.
<G-vec00296-003-s044><break_down.aufbrechen><de> Die Bindung an das Rad der Wiedergeburt aufzubrechen hängt hauptsächlich von unserer Ernsthaftigkeit und Entschlossenheit ab: Das ist es nämlich, was uns den Weg frei macht und warum auch die Lebewesen diese Bindung nicht anrühren und nicht aufbrechen wollen.
<G-vec00296-003-s044><break_down.aufbrechen><en> To break open the binding of the wheel of rebirth depends mainly on our being earnest and intent: That's what will clear our way. This is why living beings don't want to touch that binding, don't want to break it open.
<G-vec00296-003-s045><break_down.aufbrechen><de> Um Ihnen die Formatierung zu vereinfachen, stellt TortoiseSVN Dialoge für einige Eigenschaften zur Verfügung, die die Auswahlmöglichkeiten anzeigen oder die Eigenschaft in ihre individuellen Komponenten aufbrechen.
<G-vec00296-003-s045><break_down.aufbrechen><en> To help get the formatting correct, TortoiseSVN presents edit dialogs for some particular properties which show the possible values or break the property into its individual components.
<G-vec00296-003-s046><break_down.aufbrechen><de> Sie schrien, dass sie die Tür aufbrechen würden, wenn wir nicht öffneten.
<G-vec00296-003-s046><break_down.aufbrechen><en> They yelled that they would break in if we refused to open the door.
<G-vec00296-003-s047><break_down.aufbrechen><de> Die Intention dahinter blieb immer das Aufbrechen von Bekanntem, die positive Aufladung des (öffentlichen) Raums sowie eine bleibende Erinnerung an das gemeinschaftliche Zusammenarbeiten zu erschaffen.
<G-vec00296-003-s047><break_down.aufbrechen><en> The intention behind it was always to break up the familiar and stimulate the positive charge of (public) space and a lasting memory for the community.
<G-vec00296-003-s048><break_down.aufbrechen><de> Anhand der Spektren – die den Einzelbildern eines Films entsprechen – lässt sich deshalb gleichsam in Zeitlupe nachweisen, wie sich der Eisenkomplex unter Laserbeschuss über mehrere Stufen verformt, die Bindungen aufbrechen und schließlich das Radikal entsteht.
<G-vec00296-003-s048><break_down.aufbrechen><en> On the basis of the spectra, which correspond to the individual images of a film, it can thus be revealed – essentially in slow motion – how the iron complex deforms under pulsed laser illumination over several stages, the bonds break up and finally the radical is formed.
<G-vec00296-003-s049><break_down.aufbrechen><de> Auch wenn Sie in einem Zustand der Verleugnung sind, können Sie sehen, dass es Fragen gibt, und zumindest einige Teil von euch rüstet sich für das Aufbrechen.
<G-vec00296-003-s049><break_down.aufbrechen><en> Even if you are in a state of denial, you can see that there are issues and at least some part of you is gearing up for the break up.
<G-vec00296-003-s050><break_down.aufbrechen><de> Sie möchten auch die alte Blumenerde aufbrechen, bevor Sie sie verwenden, da sie mit der Zeit trocken und verdichtet werden kann.
<G-vec00296-003-s050><break_down.aufbrechen><en> You also want to break up the old potting soil before using it, as it can get dry and compacted over time.
<G-vec00296-003-s051><break_down.aufbrechen><de> „Sam, kann man die Bindung aufbrechen?“ fragte ich.
<G-vec00296-003-s051><break_down.aufbrechen><en> “Sam, is there a way to break the bond?”
<G-vec00296-003-s052><break_down.aufbrechen><de> Am Tag: Die Eier mit einem Sägemesser leicht mittig anschneiden und in zwei Hälften aufbrechen.
<G-vec00296-003-s052><break_down.aufbrechen><en> On the same day Cut the eggs lightly in the middle with a serrated knife and break them into two halves.
<G-vec00296-003-s053><break_down.aufbrechen><de> Wenn es genug Luftfeuchtigkeit gibt, kann Wind die Ballungen von Wasser-Partikel aufbrechen und so Ionen erzeugen.
<G-vec00296-003-s053><break_down.aufbrechen><en> When there is enough humidity in the air, wind can break the balls of water particles and thus create ions.
<G-vec00296-003-s054><break_down.aufbrechen><de> Ein großer Teil des Bildes wird mit Hilfe von Schablonen angelegt, die das Bild in Schichten aufbrechen.
<G-vec00296-003-s054><break_down.aufbrechen><en> Much of the paint is applied using stencils that break up the images into layers.
<G-vec00296-003-s055><break_down.aufbrechen><de> Zellulasen müssen das Material erst „aufbrechen“ und aufbereiten.
<G-vec00296-003-s055><break_down.aufbrechen><en> Cellulose enzymes first have to break down the material and process it.
<G-vec00296-003-s056><break_down.aufbrechen><de> Der Wind kann WILD IN KAPSTADT auftanken und die Tür aufbrechen, wenn das passiert.
<G-vec00296-003-s056><break_down.aufbrechen><en> THE WIND CAN GET WILD IN CAPE TOWN AND WILL BREAK THE DOOR OPEN WHEN THAT HAPPENS.
