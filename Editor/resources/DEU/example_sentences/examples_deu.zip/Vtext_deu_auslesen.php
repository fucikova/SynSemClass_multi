<G-vec00207-002-s057><read.auslesen><de> Der Unterschied dabei ist, das die meisten Hoster die IP der bekannten TS-Viewer Anbieter schon auf Ihren Servern in der Whitelist eingetragen haben und die Daten ausgelesen werden können.
<G-vec00207-002-s057><read.auslesen><en> The difference is, that the most hosters the IP of known TS Viewer provider already on your servers in the whitelist have entered and the data can be read out.
<G-vec00207-002-s058><read.auslesen><de> Einmal ausgelesen ist die Zeitung nichts mehr wert.
<G-vec00207-002-s058><read.auslesen><en> Once read, one could think the newspaper is worthless.
<G-vec00207-002-s059><read.auslesen><de> Deshalb bieten die TV EXPLORER HD+ Messgeräte eine spezielle Funktion, mit der diese Daten ausgelesen und zur späteren Auswertung in einer Datei abgespeichert werden können.
<G-vec00207-002-s059><read.auslesen><en> That is why TV EXPLORER HD+ meters have a special feature that allows you to read and store them automatically in a file that may be used later on.
<G-vec00207-002-s060><read.auslesen><de> Ich hatte an einem Tag gleich die Hälfte ausgelesen, weil es mich einfach gefesselt hat und ich kann es all jenen, die Blogger sind, gerne werden möchten oder sich einfach nur für diesen Bereich interessieren, sehr empfehlen.
<G-vec00207-002-s060><read.auslesen><en> I just read about the half of the book in one day, because it thrilled me so much and I just can recommend it to bloggers, people who like to become a blogger and also people who are interested in this matter.
<G-vec00207-002-s061><read.auslesen><de> Dieser Dateiname findet sich in der URL des Bildes wieder und wird von Google dementsprechend ausgelesen.
<G-vec00207-002-s061><read.auslesen><en> This file name is reflected in the image’s URL and is therefore read by Google. 2.
<G-vec00207-002-s062><read.auslesen><de> The Einschaltsteuereinrichtung Gemäß einer zweiten Ausgestaltung der Erfindung werden in diesem Solenoid-Ansteuersystem die Spannungskurvenformdaten nacheinander in benachbarte Bereiche der Speichereinrichtung eingeschrieben, aber durch die Leseeinrichtung aus Bereichen in der Speichereinrichtung ausgelesen, die voneinander beabstandet sind.
<G-vec00207-002-s062><read.auslesen><en> [0011] According to a second aspect of the invention, the voltage waveform data in this solenoid-driving system sequentially written in adjacent portions of the memory device, but read by the reading means from areas in the memory means, which are spaced apart.
<G-vec00207-002-s063><read.auslesen><de> Wenn jemand die Website besucht hat, wird im Computer des Kunden ein Cookie gespeichert (falls diese vom Kunden akzeptiert werden) oder wird ausgelesen, falls der Kunde diese Website vorher schon einmal aufgesucht hat.
<G-vec00207-002-s063><read.auslesen><en> When someone visits the site, a cookie is placed on the customer’s machine (if the customer accepts cookies) or is read if the customer has visited the site previously.
<G-vec00207-002-s064><read.auslesen><de> Beleginformationen werden im Fiskalmodul des Druckers gespeichert welche von der Finanzverwaltung ausgelesen werden können.
<G-vec00207-002-s064><read.auslesen><en> Document information is stored in the fiscal module of the printer which can be read out by the tax authorities.
<G-vec00207-002-s065><read.auslesen><de> Diese Fehlercodes können mit speziellen Computern ausgelesen werden.
<G-vec00207-002-s065><read.auslesen><en> These error codes can be read with specific computers.
<G-vec00207-002-s066><read.auslesen><de> Die Füllhöhe wird mit dem Display ausgelesen, und die aktivierten digitalen Ausgänge werden mit LEDs angezeigt.
<G-vec00207-002-s066><read.auslesen><en> The depht of the level can be read on the display and the activated digital outputs are indicated by light emitting diodes.
<G-vec00207-002-s067><read.auslesen><de> Aktive Vibrationsdämpfer verrichten ihre Arbeit, Daten werden ausgelesen und ausgewertet.
<G-vec00207-002-s067><read.auslesen><en> Active vibration isolating modules do their job, data is read out and analyzed.
<G-vec00207-002-s068><read.auslesen><de> Geänderte Daten werden nicht automatisch spontan übermittelt sondern müssen auf entsprechende Statusrückmeldungen hin ausgelesen werden.
<G-vec00207-002-s068><read.auslesen><en> There is no spontaneous automatic transmission of data changes, these have to be read out after the respective status messages.
<G-vec00207-002-s069><read.auslesen><de> Im Takt von 50ms werden permanent die Istwerte von Strom- und Spannung gemessen und können über die Schnittstellen am Gerät ausgelesen werden.
<G-vec00207-002-s069><read.auslesen><en> Power and voltage values are measured at intervals of 50ms and can be read out via the interface in the device.
<G-vec00207-002-s070><read.auslesen><de> Bei Cookies handelt es sich um kleine Textdateien, die auf Ihrem Rechner abgelegt werden und später von einem Webserver ausgelesen werden können.
<G-vec00207-002-s070><read.auslesen><en> Cookies are small text files that are stored on your computer and can later be read by a web server.
<G-vec00207-002-s071><read.auslesen><de> Behind-Metal-Tags können noch aus einer Entfernung von sieben Metern ausgelesen werden.
<G-vec00207-002-s071><read.auslesen><en> Behind-Metal tags can still be read from a distance of seven metres.
<G-vec00207-002-s072><read.auslesen><de> Sie werden manuell gelesen und dabei auch ausgelesen.
<G-vec00207-002-s072><read.auslesen><en> They are read manually and also read out.
<G-vec00207-002-s073><read.auslesen><de> Die erforderlichen Inventardaten werden ohne Installation von Agenten direkt aus den IT-Systemen ausgelesen.
<G-vec00207-002-s073><read.auslesen><en> The necessary inventory data is read directly from the IT systems without installing agents.
<G-vec00207-002-s074><read.auslesen><de> Zu Servicezwecken können bestimmte Zustandsdaten des Verstärkers sowie Fehlerberichte ausgelesen werden.
<G-vec00207-002-s074><read.auslesen><en> For service purposes, information may be read from an amplifier, concerning its condition during operation and errors reported.
<G-vec00207-002-s075><read.auslesen><de> Die Datei sollte nicht ausgelesen werden, wenn ein Syslog-Prozess läuft, der den Systemaufruf syslog(2) zur Protokollierung benutzt.
<G-vec00207-002-s075><read.auslesen><en> This file should not be read if a syslog process is running which uses the syslog(2) system call facility to log kernel messages.
