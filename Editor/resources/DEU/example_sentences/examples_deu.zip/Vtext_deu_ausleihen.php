<G-vec00505-001-s038><borrow.ausleihen><de> Eine Auswahl an Lesematerial (sowohl authentische Literatur als auch Kurzgeschichten) und DVDs kann von den Studenten ausgeliehen werden.
<G-vec00505-001-s038><borrow.ausleihen><en> There is a selection of reading materials (both unabridged literature and abridged stories) and DVDs that the students may borrow.
<G-vec00505-001-s039><borrow.ausleihen><de> Wie ich dann mein brand eins wieder hatte, habe ich es ein paar Mal ausgeliehen.
<G-vec00505-001-s039><borrow.ausleihen><en> When I had my “brand eins”, I let some other people borrow it.
<G-vec00505-001-s040><borrow.ausleihen><de> Die handgehaltenen Videospielgeräte sind heutzutage weg, aber sie haben Zugang zu den Tablets und Handys und nutzen sie unabhängig davon, ob sie ihre eigenen haben oder sie von Eltern ausgeliehen haben, insbesondere Mobiltelefone.
<G-vec00505-001-s040><borrow.ausleihen><en> The handheld video games devices are gone these days, but they have access to the tablets and cell phones and use it independently whether they have their own or they used to borrow from parents, mobile phones are in particular.
<G-vec00505-001-s041><borrow.ausleihen><de> Wir haben einen Waschraum mit Waschmaschinen, einem Trockner und einem Bügelbrett ausgestattet (Bügeleisen kann an der Rezeption ausgeliehen werden).
<G-vec00505-001-s041><borrow.ausleihen><en> We have fitted out a laundry area, including washing machines, a tumble dryer and an ironing board (it is possible to borrow an iron at reception).
<G-vec00505-001-s042><borrow.ausleihen><de> Eine Ausleihe außer Haus ist in diesem Fall nicht möglich.
<G-vec00505-001-s042><borrow.ausleihen><en> In this case it is not possible to borrow books for home loan.
<G-vec00505-001-s043><borrow.ausleihen><de> Sie glaubten, dass samouglublennaya Asien ist es, eine Ausleihe aus Europa zur Förderung der körperlichen, real, aber es ist praktisch unmöglich, die mechanische Übertragung des Kapitalismus in den asiatischen, Nicht-EU im Allgemeinen, die Erde.
<G-vec00505-001-s043><borrow.ausleihen><en> They believed that samouglublennaya Asia is seeking to borrow from Europe to boost physical, real activity, but it is virtually impossible to achieve the mechanical transfer of capitalism in the Asian, non-European in general, the soil.
<G-vec00505-001-s044><borrow.ausleihen><de> Wenn Sie einen 401 (k)-Konto, kann es sehr verlockend, Ausleihe von Ihrem Konto vor allem, wenn Ihr Kontostand ist sehr hoch und könnte leicht ein Darlehen auszahlen bestehenden Schulden, Fonds ein Haus kaufen, oder der Preis für Hochschule Studiengebühren.
<G-vec00505-001-s044><borrow.ausleihen><en> If you have a 401(k) account, it can be very tempting to borrow from your account especially when your balance is very high and a loan could easily pay off existing debt, fund a home purchase, or pay for college tuition.
<G-vec00505-001-s045><borrow.ausleihen><de> Für die Ausleihe der Bühne wird eine Kautionshinterlegung von 200 Euro in bar erforderlich.
<G-vec00505-001-s045><borrow.ausleihen><en> In order to borrow the stage you will need to deposit of 200 Euro in cash.
<G-vec00505-001-s046><borrow.ausleihen><de> Damit wir berechnen die Kosten für die Zahlung der Piper wir Ausleihe aus der mathematischen Physik.
<G-vec00505-001-s046><borrow.ausleihen><en> To help us calculate the cost of paying the piper we will borrow from the math of physics.
<G-vec00505-001-s047><borrow.ausleihen><de> Für die Ausleihe dieser Bestände benötigen Sie einen Bibliotheksausweis der ZB MED.
<G-vec00505-001-s047><borrow.ausleihen><en> You need a library card of the ZB MED to borrow these holdings.
<G-vec00505-001-s048><borrow.ausleihen><de> Was Sie wissen müssen, Teil 1 Kredit zur Gründung eines der wichtigsten Dinge, die Sie tun können, um, um Ihre finanzielle Stabilität zu erfassen und drastisch erhöhen Ihre Fähigkeit zur Ausleihe notwendigen Mittel, um ein neues Zuhause, neue Auto oder selbst bezahlen Hochschule Aufwendungen.
<G-vec00505-001-s048><borrow.ausleihen><en> 2007-11-13 22:16:19 - Establishing credit? what you need to know part 1 Establishing credit is one of the most important things you can do in order to add stability to your financial record and dramatically increase your ability to borrow necessary funds in order to purchase a new home, new car or even pay for college expenses.
<G-vec00505-001-s049><borrow.ausleihen><de> Eine weitere Schwierigkeit bestand darin, einen elektrischen Rollstuhl zur Ausleihe zu erhalten, um Entwicklungen und Tests unter reellen Bedingungen durchführen zu können.
<G-vec00505-001-s049><borrow.ausleihen><en> Another difficulty was to find a wheelchair to borrow in order to develop and run tests under real conditions.
<G-vec00505-001-s050><borrow.ausleihen><de> Zur Ausleihe legen Sie bitte Ihren Benutzungsausweis vor.
<G-vec00505-001-s050><borrow.ausleihen><en> Please present your library card when you wish to borrow an item.
<G-vec00505-001-s051><borrow.ausleihen><de> Voraussetzung für die Ausleihe ist dieEinschreibungals Benutzer/in in einer NEBIS Bibliothek.
<G-vec00505-001-s051><borrow.ausleihen><en> Users must be registered with a NEBIS library to borrow any media.
<G-vec00505-001-s052><borrow.ausleihen><de> Ausleihe von technischem Material Die ZHdK bietet für Studierende und Mitarbeitende einen umfangreichen Gerätepark zur Ausleihe an.
<G-vec00505-001-s052><borrow.ausleihen><en> Borrowing of Technical Equipment The ZHdK allows students and employees to borrow an extensive range of equipment.
<G-vec00505-001-s053><borrow.ausleihen><de> Alle anderen Personen können eine Mitgliedschaft der Zürcher Kunstgesellschaft erwerben, mit der man neben der Ausleihe ein Jahr lang auch alle Ausstellungen im Kunsthaus beliebig oft besuchen kann.Mit der Anmeldung anerkennt der/die Benutzer/in die Benutzungs - und die Gebührenordnung .
<G-vec00505-001-s053><borrow.ausleihen><en> All other persons can purchase a membership of the Zurich Art Society, which entitles for one year not only to borrow items from the library but also to visit all exhibitions in the Kunsthaus Zürich as often as one pleases.Registration implies acceptance of the library's user regulations as well as the fees and charges.
<G-vec00505-001-s054><borrow.ausleihen><de> Eine Ausleihe nach Hause ist in diesem Fall nicht möglich.
<G-vec00505-001-s054><borrow.ausleihen><en> In this case it is not possible to borrow books and media for home loan.
<G-vec00505-001-s055><borrow.ausleihen><de> Beim Maskenhändler auf dem Marktplatz ausleihen, nachdem du die Geister-Maske verkauft hast, und verkaufen an den Typ der nachts südlich der Lon Lon-Farm herum läuft, nachdem du mit Lord Jabu Jabu fertig bist.
<G-vec00505-001-s055><borrow.ausleihen><en> Borrow it in Happy Mask Shop at Market after you sold the Spooky Mask, and sell it at night to the guy running around south of Lon Lon Ranch after you are done with Lord Jabu Jabu.
<G-vec00505-001-s056><borrow.ausleihen><de> Weil... wir unseren Gsten beste Untersttzung anbieten, um die Stadt Rom besichtigen zu knnen und die Kultur der Etrusker, Rmer und Christen in Latium zu entdecken: Sie knnen Landkarten und Touristeninformationen in Ihrer eigenen Sprache erhalten; Bcher in verschiedenen Sprachen ausleihen; multimediale Dienstleistungen nutzen; whlen Sie Konzerte und Ausstellungen von unseren aktualisierten Listen; Eintrittsreservierungen fr Museen und Kunstgalerieen.
<G-vec00505-001-s056><borrow.ausleihen><en> Because... we provide the best support to our guests in order to make it easier to visit Rome and to discover the Etruscan, Roman and Christian culture of Latium: you can get maps and tourist information in your own language; borrow books in different languages; benefit of multi-medial services;choose concerts and exhibitions from our updated lists; have reservations for entrance in museums and art galleries.
<G-vec00505-001-s057><borrow.ausleihen><de> Organizing Mittel für den persönlichen Ursachen von externen Quellen können einfach sein, aber die gleiche Aufgabe wird schwieriger, wenn es um Geld für kommerzielle oder geschäftliche Zwecke ausleihen kommt.
<G-vec00505-001-s057><borrow.ausleihen><en> Organizing funds for personal causes from external sources might be easy but the same task becomes more difficult when it comes to borrow money for commercial or business purpose.
<G-vec00505-001-s058><borrow.ausleihen><de> Sie können außerdem Schwimmwesten, Neoprenanzüge, Spritzdecken, Paddle Floats, Pumpen und verschiedene Paddel ausleihen.
<G-vec00505-001-s058><borrow.ausleihen><en> You can also borrow life jackets, wetsuits, spray decks, paddle floats, pumps and various paddles.
<G-vec00505-001-s059><borrow.ausleihen><de> Die Schüler können Bücher aus der Bibliothek ausleihen oder ihre eigenen Bücher kaufen.
<G-vec00505-001-s059><borrow.ausleihen><en> Students can borrow books from the library or purchase their own books.
<G-vec00505-001-s060><borrow.ausleihen><de> wir haben in unserer Kindergartenbücherei tiptoi-Bücher, die sie sich gerne ausleihen können (Öffnungszeiten: montags und donnerstags von 13:45 bis16:00 Uhr).
<G-vec00505-001-s060><borrow.ausleihen><en> We have tiptoi books in our Preschool library, which you can borrow anytime (opening hours: Mondays and Thursdays from 1:45pm to 4pm).
<G-vec00505-001-s061><borrow.ausleihen><de> Sie befinden sich nur wenige Meter von der Reception und dem Rancho entfernt.Sämtliche Unterkünfte sind rollstuhlgängig, verfügen ueber Alufenster mit Moskitoschutzgitter, Keramikböden, Steckdosen 110V/60 Hz, Wäscheleine, Hängematte, gedeckten Sitzplatz, Gartenbestuhlung, Blick und Treppen zum Fluss Sapoa sowie private Parkplätze.In der kleinen Bibliothek neben dem Rancho gibt es Bücher zum Ausleihen und Tauschen, Spiele zum Zeitvertreib und Infos zur Weiterreise.Auf den Hügeln bietet sich eine herrliche Sicht auf den Vulkan Orosi (Costa Rica) und zum Vulkan Concepcion im Lago de Nicaragua.
<G-vec00505-001-s061><borrow.ausleihen><en> You are only a few metersaway from the reception and the Ranch.All rooms are wheelchair accessible, have over aluminum windows with mosquito netting, ceramic floors,110V/60 Hz power outlets, clothesline, hammock, covered patio, garden furniture, stairs and look forSapoa flow as well as private parking.In the small library next to the ranch, there are books to borrow and swap, time-killersand information for onward journey.On the hills, offers a magnificent view of the Orosi Volcano (Costa Rica) and the volcanoConcepcion in the Lago de Nicaragua.
<G-vec00505-001-s062><borrow.ausleihen><de> Dies ist die schnelle Quelle bis zur Höhe nötig ausleihen, um den plötzliche Ausgaben.
<G-vec00505-001-s062><borrow.ausleihen><en> This is the fast source to borrow the needful amount to meet the sudden expenses.
<G-vec00505-001-s063><borrow.ausleihen><de> Wenn sie ausleihen Grim 's Zauberbuch es ' ll keine Zeit mehr zu vergehen jedoch.
<G-vec00505-001-s063><borrow.ausleihen><en> If they borrow Grim\'s spell book it\'ll take no time at all however.
<G-vec00505-001-s064><borrow.ausleihen><de> Gleich am Strand gibt es eine Surf-Schule, wo man das Windsurfen erlernen oder sich auch nur ein Brett für eine Stunde ausleihen kann.
<G-vec00505-001-s064><borrow.ausleihen><en> Right on the beach, there is a surf school where one can learn to surf or simply borrow a surfboard for an hour.
<G-vec00505-001-s065><borrow.ausleihen><de> Unser Automatenfiguren und traumhaften Bildergeschichten können Sie auch von uns ausleihen.
<G-vec00505-001-s065><borrow.ausleihen><en> Let yourself surprise! You can also borrow our animated puppets and enchanting picture stories.
<G-vec00505-001-s066><borrow.ausleihen><de> Großes Kanu mit kleinem Elektromotor zum Ausleihen.
<G-vec00505-001-s066><borrow.ausleihen><en> A large canoe is available with a small electric motor to borrow.
<G-vec00505-001-s067><borrow.ausleihen><de> Sie können unsere Kanus für herrliche Ausflüge auf dem See ausleihen.
<G-vec00505-001-s067><borrow.ausleihen><en> You may borrow our canoes for wonderful excursions on the lake.
<G-vec00505-001-s068><borrow.ausleihen><de> Barbecue zum Ausleihen und Outdoor-Möbel steht auf der Veranda und in dem Rücken, auch einen cafeset am Eingang zur Verfügung.
<G-vec00505-001-s068><borrow.ausleihen><en> Barbecue available to borrow and outdoor furniture stands on the porch and in the back, even a cafeset available at the entrance.
<G-vec00505-001-s069><borrow.ausleihen><de> Sie finden hier einen Empfangsbereich mit Kamin, wo Sie Bücher und Gesellschaftsspiele ausleihen können, ein beheiztes Hallenbad und eine gebührenpflichtige Tiefgarage.
<G-vec00505-001-s069><borrow.ausleihen><en> Facilities of the complex include a lobby with a fireplace where you can borrow books and board games, a heated indoor pool, and a parking garage.
<G-vec00505-001-s070><borrow.ausleihen><de> Sie befinden sich nur wenige MeterÂ von der Reception und dem Rancho entfernt.Sämtliche UnterkÃ1⁄4nfte sind rollstuhlgängig, verfÃ1⁄4gen ueber Alufenster mit Moskitoschutzgitter, Keramikböden,Â Steckdosen 110V/60 Hz, Wäscheleine, Hängematte, gedeckten Sitzplatz, Gartenbestuhlung, Blick und Treppen zumÂ Fluss Sapoa sowie private Parkplätze.In der kleinen Bibliothek neben dem Rancho gibt es BÃ1⁄4cher zum Ausleihen und Tauschen, Spiele zum ZeitvertreibÂ und Infos zur Weiterreise.Auf den HÃ1⁄4geln bietet sich eine herrliche Sicht auf den Vulkan Orosi (Costa Rica) und zum VulkanÂ Concepcion im Lago de Nicaragua.
<G-vec00505-001-s070><borrow.ausleihen><en> You are only a few metersaway from the reception and the Ranch.All rooms are wheelchair accessible, have over aluminum windows with mosquito netting, ceramic floors,110V/60 Hz power outlets, clothesline, hammock, covered patio, garden furniture, stairs and look forSapoa flow as well as private parking.In the small library next to the ranch, there are books to borrow and swap, time-killersand information for onward journey.On the hills, offers a magnificent view of the Orosi Volcano (Costa Rica) and the volcanoConcepcion in the Lago de Nicaragua.
<G-vec00505-001-s071><borrow.ausleihen><de> Vor Ort kann man für eine geringe Gebühr Liegestühle und Sonnenschirme ausleihen.
<G-vec00505-001-s071><borrow.ausleihen><en> Locally you can borrow for a small fee, sun loungers and parasols.
<G-vec00505-001-s072><borrow.ausleihen><de> Studierende können bis zu 5 Bücher über das Wochenende ausleihen (von Freitag auf Montag).
<G-vec00505-001-s072><borrow.ausleihen><en> Students may borrow up to 5 books over the weekend (from Friday to Monday).
<G-vec00505-001-s073><borrow.ausleihen><de> Sie können Fahrräder, Golfschläger, Krippen und verschiedene Spiele ausleihen.
<G-vec00505-001-s073><borrow.ausleihen><en> You can borrow bicycles, golf clubs, cribs and various games.
<G-vec00505-001-s074><borrow.ausleihen><de> Um Bücher auszuleihen, ist jedoch eine Mitgliedschaft erforderlich.
<G-vec00505-001-s074><borrow.ausleihen><en> Visitors are welcome to browse; membership is required to borrow books.
<G-vec00505-001-s075><borrow.ausleihen><de> Sofern Sie Ihr Studium erfolgreich abschließen, sind Sie lebenslang berechtigt, kostenfrei Medien der Bibliothek der FH Vorarlberg auszuleihen.
<G-vec00505-001-s075><borrow.ausleihen><en> If you complete your studies successfully, you will have a lifelong entitlement to borrow media from the FH Vorarlberg library free of charge.
<G-vec00505-001-s076><borrow.ausleihen><de> Die Onleihe ist ein digitales Angebot der Bibliothek des Goethe-Instituts Yaoundé für Kamerun, das Ihnen ermöglicht, digitale Medien auszuleihen.
<G-vec00505-001-s076><borrow.ausleihen><en> The eLibrary is a digital service offered by the Goethe-Institut Yaoundé library for Cameroon which allows you to borrow digital media.
<G-vec00505-001-s077><borrow.ausleihen><de> Die Onleihe ist ein digitales Angebot der Bibliothek der Goethe-Institute in Afrika, das Ihnen ermöglicht, digitale Medien auszuleihen.
<G-vec00505-001-s077><borrow.ausleihen><en> eLibrary The eLibrary is a digital service offered by the Goethe-Institut in Africa which allows you to borrow digital media.
<G-vec00505-001-s078><borrow.ausleihen><de> Die Onleihe ist ein digitales Angebot der Bibliothek des Goethe-Instituts Johannesburg für Südafrika, das Ihnen ermöglicht, digitale Medien auszuleihen.
<G-vec00505-001-s078><borrow.ausleihen><en> The eLibrary is a digital service offered by the Goethe-Institut Johannesburg library for South Africa which allows you to borrow digital media.
<G-vec00505-001-s079><borrow.ausleihen><de> Diese dreifach-Printing-Technik sparte auch Geld ein, als man sie nutzte, um Bürgerkriegsszenen aus „Raintree County“ (Camera 65) sowie Szenen mit marschierenden Soldaten aus „The Alamo“ (Todd-AO) „auszuleihen“.
<G-vec00505-001-s079><borrow.ausleihen><en> "This triple-printing technique also allowed some money to be saved by using it to ""borrow"" the Civil War battle sequences from ""Raintree County"" (Camera 65) and scenes of marching soldiers from ""The Alamo"" (Todd-AO)."
<G-vec00505-001-s080><borrow.ausleihen><de> Ich hatte 4 Bibliothek Karten für jede Bibliothek im Umkreis von 20 km, und ich ging jeden Mittwoch zu meinen Lieblings-Bibliothek zum Lesen und um Bücher auszuleihen.
<G-vec00505-001-s080><borrow.ausleihen><en> I had 4 library cards for every library within 20 km and I went every Wednesday to my favourite library to read and borrow books.
<G-vec00505-001-s081><borrow.ausleihen><de> Ich teilte mein Heim mit sieben Leuten, als ich mich eines Abends entschloss, den Computer meiner Zimmergenossin auszuleihen.
<G-vec00505-001-s081><borrow.ausleihen><en> I was sharing a home with seven people when one night I decided to borrow my roommate’s computer.
<G-vec00505-001-s082><borrow.ausleihen><de> Die Künstlerinnen und Künstler wurden gebeten, Bücher auszuleihen, die sie für ihre lokale Szene für wichtig erachten und die im Rahmen der Ausstellung präsentiert werden.
<G-vec00505-001-s082><borrow.ausleihen><en> For the exhibition we asked artists to borrow the books that they think are of great significance to the local scene to be introduced throughout the course of the exhibition.
<G-vec00505-001-s083><borrow.ausleihen><de> Nur man braucht, und... stehenzubleiben, auszuleihen.
<G-vec00505-001-s083><borrow.ausleihen><en> It is necessary to stop and... to borrow.
<G-vec00505-001-s084><borrow.ausleihen><de> F: (S) Ich wurde so erzogen, kein Geld auszuleihen und meine Rechnungen zuerst zu bezahlen... und dann, wenn noch etwas übrig bleibt...
<G-vec00505-001-s084><borrow.ausleihen><en> Q: (S) Well, I was brought up to not borrow money and to keep all the bills paid first … then if there is anything left over …
<G-vec00505-001-s085><borrow.ausleihen><de> TV, DVDs, Bücher auszuleihen, Freier Internet-, Sicherheits-Schränke, Wäsche-, CCTV, Handtücher, Haartrockner und einen Parkplatz.
<G-vec00505-001-s085><borrow.ausleihen><en> TV, DVDs, books to borrow, Free Internet, security cabinets, CCTV, towels, Hair Dryer and parking. from 9.16 USD
<G-vec00505-001-s086><borrow.ausleihen><de> Für das Festival wurden über den → Festivalblog sechs Haushalte aus Morley gesucht, die bereit waren, Werke aus der Leeds Art Gallery auszuleihen.
<G-vec00505-001-s086><borrow.ausleihen><en> The → festival’s blog was used to locate six households in Morley willing to borrow works from Leeds Art Gallery for the project.
<G-vec00505-001-s123><borrow.ausleihen><de> Er möchte einen Teil unserer Reiterei ausleihen, um sich besser auf der Insel bewegen zu können.
<G-vec00505-001-s123><borrow.ausleihen><en> He wants to borrow some of our cavalry to help him move around the island.
<G-vec00505-001-s124><borrow.ausleihen><de> Wenn Sie die Stadt auf eigene Faust erkunden möchten, können Sie einen Audioguide ausleihen, der in schwedischer und englischer Sprache erhältlich ist.
<G-vec00505-001-s124><borrow.ausleihen><en> If you would like to experience the city by yourself, you can borrow our audio guides (Swedish and English).
<G-vec00505-001-s170><borrow.ausleihen><de> Gern können Sie sich bei uns einen Schlitten ausleihen und wir zeigen Ihnen die besten Naturrodelbahnen rund um den Bacherhof.
<G-vec00505-001-s170><borrow.ausleihen><en> You are also welcome to borrow a toboggan from us, and we will be happy to show you the best sled runs close to the Bacherhof.
<G-vec00505-001-s171><borrow.ausleihen><de> Den Abschlussbericht zum Vorhaben können Sie unter Angabe der Projektnummer ausleihen.
<G-vec00505-001-s171><borrow.ausleihen><en> If you would like to borrow the project report please indicate the project number.
<G-vec00505-001-s274><borrow.ausleihen><de> Wenn Sie die Umgebung erkunden möchten, können Sie an der Rezeption Fahrräder ausleihen.
<G-vec00505-001-s274><borrow.ausleihen><en> Guests wishing to explore the surroundings can borrow bikes from the hotel reception.
<G-vec00505-001-s275><borrow.ausleihen><de> Sie können bis zu fünf Medien gleichzeitig ausleihen, davon maximal drei Bücher und maximal zwei DVDs/CDs.
<G-vec00505-001-s275><borrow.ausleihen><en> User can borrow up to five items at the same time, these may include a maximum of three Books and two DVDs/CDs.
<G-vec00369-002-s038><hire.ausleihen><de> Wer es im Sommerurlaub in Tirol lieber gemütlich angeht, der kann das Tal ganz bequem mit einem E-Bike oder dem Mountainbike erkunden, das Sie sich ebenso wie eine Mountainbike-Tourenkarte kostenlos in unserem Naturhotel in Tirol ausleihen können.
<G-vec00369-002-s038><hire.ausleihen><en> For those who prefer calmer summer holidays in the Alps, you can explore the valley with an e-bike or mountain bike, which you can hire for free at our hotel in the Austrian Alps along with our MTB tour maps.
<G-vec00369-002-s039><hire.ausleihen><de> Wenn Sie den Attersee und das Salzkammergut per Rad erkunden möchten, dann haben wir auch das passende E-Bike der Marke Kalkoff zum Ausleihen.
<G-vec00369-002-s039><hire.ausleihen><en> If you want to explore the Attersee and the Salzkammergut by bike, then we also have the right e-bike for hire.
<G-vec00369-002-s040><hire.ausleihen><de> Im Frühling und Sommer haben wir 4 Banana-Flitzer zum kostenfreien Ausleihen.
<G-vec00369-002-s040><hire.ausleihen><en> In spring and summer, we have four Banana bikes for free hire.
<G-vec00369-002-s041><hire.ausleihen><de> In Berlin brachte das Unternehmen erst vor wenigen Wochen unter der Marke Jump seiner gleichnamigen Tochterfirma knallrote Pedelecs zum Ausleihen auf die Straße.
<G-vec00369-002-s041><hire.ausleihen><en> Just a few weeks ago in Berlin, the company launched bright red pedelecs for hire under the Jump brand of its eponymous subsidiary.
<G-vec00369-002-s042><hire.ausleihen><de> Verbringen Sie den Rest des Tages nach Ihren Vorstellungen auf der zauberhaften kleinen Insel Cayo Jutias; Sie können sich zum Beispiel ein Boot ausleihen oder im Meer schwimmen, das hier wirklich traumhaft schön ist.
<G-vec00369-002-s042><hire.ausleihen><en> Spend the rest of the afternoon on the lovely Cayo Jutias key as you wish; you can hire a boat or have a swim in the beautiful sea. Return to Viñales for the night.
<G-vec00369-002-s043><hire.ausleihen><de> Tennisschläger, Brettspiele und DVDs können Sie in der Unterkunft kostenlos ausleihen.
<G-vec00369-002-s043><hire.ausleihen><en> Guests enjoy free hire of tennis racquets, board games and DVDs.
<G-vec00369-002-s044><hire.ausleihen><de> An der Unterkunft können Sie Fahrräder ausleihen und die Umgebung ist ideal zum Golfen und Reiten.
<G-vec00369-002-s044><hire.ausleihen><en> Bike hire is available at the property and the area is popular for golfing and horse riding.
<G-vec00369-002-s045><hire.ausleihen><de> Das moderne Besucherzentrum bietet Ausstellung, Film und Multimediaguides zum Ausleihen.
<G-vec00369-002-s045><hire.ausleihen><en> The modern visitor center offers exhibition, film and multimedia guides for hire.
<G-vec00369-002-s046><hire.ausleihen><de> Dieses können Sie auf dem Camping ausleihen.
<G-vec00369-002-s046><hire.ausleihen><en> You can hire them at the campsite.
<G-vec00369-002-s047><hire.ausleihen><de> Im Tourismusbüro Westendorf gibt es topmoderne GPS-Geräte von Garmin zum Ausleihen.
<G-vec00369-002-s047><hire.ausleihen><en> Westendorf's tourist office offers high-tech GPS devices, by Garmin, for hire.
<G-vec00369-002-s048><hire.ausleihen><de> Im Sommer können Sie Mountainbikes ausleihen.
<G-vec00369-002-s048><hire.ausleihen><en> In summer you can hire mountain bikes.
<G-vec00369-002-s049><hire.ausleihen><de> Es gibt auch eine Skischule und einige Verleihcenter, wo man Skis, Snowboards, Schlitten und Schneeschuhe ausleihen kann.
<G-vec00369-002-s049><hire.ausleihen><en> There are also a ski school and some rental shops where you can hire skis, snowboards, sleds and snowshoes.
<G-vec00369-002-s050><hire.ausleihen><de> In der Unterkunft können Sie Skiausrüstung ausleihen und die Umgebung ist zum Skifahren beliebt.
<G-vec00369-002-s050><hire.ausleihen><en> Ski equipment hire is available at the property and the area is popular for skiing.
<G-vec00369-002-s051><hire.ausleihen><de> In der Unterkunft können Sie Fahrräder ausleihen und die Gegend eignet sich ideal zum Golfspielen.
<G-vec00369-002-s051><hire.ausleihen><en> Bike hire is available at the property and the area is popular for golfing.
<G-vec00369-002-s052><hire.ausleihen><de> Wir haben 2 Boote zum Ausleihen.
<G-vec00369-002-s052><hire.ausleihen><en> We have two boats for hire.
<G-vec00369-002-s053><hire.ausleihen><de> Top Equipment online ausleihen.
<G-vec00369-002-s053><hire.ausleihen><en> Hire top equipment online.
<G-vec00369-002-s054><hire.ausleihen><de> Kautionen, Reinigungsgebühren und die Gebühren für das Ausleihen der Bettwäsche müssen im Voraus überwiesen werden.
<G-vec00369-002-s054><hire.ausleihen><en> Security deposits, cleaning fees and linen hire must be paid in advance by a bank transfer.
<G-vec00369-002-s055><hire.ausleihen><de> Wenn Sie ihre eigene Rodel nicht dabei haben, dann können Sie sich an vielen Startpunkten einen Schlitten ausleihen.
<G-vec00369-002-s055><hire.ausleihen><en> If you didn’t bring your toboggan with you, there are many places where you can hire one.
<G-vec00369-002-s056><hire.ausleihen><de> Die Campbewohnerinnen und -bewohner können die Werkzeige maximal für drei Tage ausleihen.
<G-vec00369-002-s056><hire.ausleihen><en> Residents can hire the tools for a maximum of three days.
<G-vec00490-002-s361><rent.ausleihen><de> Die begreifen einfach nicht, dass hier auch Leute wohnen, die am nächsten Tag arbeiten müssen.“ Die Wohnungen, die an Touristen vermietet werden, gehen in die Tausende – die meisten davon ohne Lizenz.
<G-vec00490-002-s361><rent.ausleihen><en> “We hear noise, music, shouting every few minutes; they don't understand that there are locals living here, people who work the next day.” Apartments available for rent for tourists number in the thousands, much of them unlicensed.
<G-vec00490-002-s362><rent.ausleihen><de> BonCams.com vermietet, verkauft, handelt, teilt oder transferiert anderweitig Informationen nicht an Außenstehende, abgesehen von der Kommunikation mit Unternehmen der BonCams.com Gruppe und Dienstleistern, um die einwandfreie Funktionalität der BonCams.com Dienste sicherzustellen.
<G-vec00490-002-s362><rent.ausleihen><en> CamGirlz Online! does not rent, sell, trade, share, or otherwise transfer information to outside parties except the communication to CamGirlz Online! group companies and service providers in order to ensure the good functioning of CamGirlz Online! services.
<G-vec00490-002-s363><rent.ausleihen><de> 9.12. camvideox vermietet, verkauft, handelt, teilt oder transferiert anderweitig Informationen nicht an Außenstehende, abgesehen von der Kommunikation mit Unternehmen der camvideox Gruppe und Dienstleistern, um die einwandfreie Funktionalität der camvideox Dienste sicherzustellen.
<G-vec00490-002-s363><rent.ausleihen><en> 9.12. camvideox does not rent, sell, trade, share, or otherwise transfer information to outside parties except the communication to camvideox group companies and service providers in order to ensure the good functioning of camvideox services.
<G-vec00490-002-s364><rent.ausleihen><de> Vor Ort werden Autos und Fahrräder vermietet.
<G-vec00490-002-s364><rent.ausleihen><en> Guests can rent cars and bicycles at the hotel.
<G-vec00490-002-s365><rent.ausleihen><de> Club Ciudadela verkauft, vermietet oder verleast seine Kundeninformationen nicht an Dritte.
<G-vec00490-002-s365><rent.ausleihen><en> Club Ciudadela does not sell, rent or lease its customer informations to third parties.
<G-vec00490-002-s366><rent.ausleihen><de> Der Zugang zur Driving Range ist kostenlos und der Golfpark vermietet auch Golfschläger.
<G-vec00490-002-s366><rent.ausleihen><en> Access to the practice is free of charge and the Golf Parc is happy to rent clubs to visitors.
<G-vec00490-002-s367><rent.ausleihen><de> Cams Cool vermietet, verkauft, handelt, teilt oder transferiert anderweitig Informationen nicht an Außenstehende, abgesehen von der Kommunikation mit Unternehmen der Cams Cool Gruppe und Dienstleistern, um die einwandfreie Funktionalität der Cams Cool Dienste sicherzustellen.
<G-vec00490-002-s367><rent.ausleihen><en> Cams Cool does not rent, sell, trade, share, or otherwise transfer information to outside parties except the communication to Cams Cool group companies and service providers in order to ensure the good functioning of Cams Cool services.
<G-vec00490-002-s368><rent.ausleihen><de> XChatory vermietet, verkauft, handelt, teilt oder transferiert anderweitig Informationen nicht an Außenstehende, abgesehen von der Kommunikation mit Unternehmen der XChatory Gruppe und Dienstleistern, um die einwandfreie Funktionalität der XChatory Dienste sicherzustellen.
<G-vec00490-002-s368><rent.ausleihen><en> Cams Avenue does not rent, sell, trade, share, or otherwise transfer information to outside parties except the communication to Cams Avenue group companies and service providers in order to ensure the good functioning of Cams Avenue services.
<G-vec00490-002-s369><rent.ausleihen><de> Unsere Ferienhäuser und Ferienwohnung werden mit einer Buchungsbestätigung vermietet.
<G-vec00490-002-s369><rent.ausleihen><en> Our Rules for rent our Holiday homes villas and Vacation Apartments,
<G-vec00490-002-s370><rent.ausleihen><de> Free Tranny Cams vermietet, verkauft, handelt, teilt oder transferiert anderweitig Informationen nicht an Außenstehende, abgesehen von der Kommunikation mit Unternehmen der Free Tranny Cams Gruppe und Dienstleistern, um die einwandfreie Funktionalität der Free Tranny Cams Dienste sicherzustellen.
<G-vec00490-002-s370><rent.ausleihen><en> Free Tranny Cams does not rent, sell, trade, share, or otherwise transfer information to outside parties except the communication to Free Tranny Cams group companies and service providers in order to ensure the good functioning of Free Tranny Cams services.
<G-vec00490-002-s371><rent.ausleihen><de> Für Feiern wird das Ferienhaus nicht vermietet.
<G-vec00490-002-s371><rent.ausleihen><en> We do not rent the holiday home for parties.
<G-vec00490-002-s372><rent.ausleihen><de> Tarkett verkauft und vermietet Ihre personenbezogenen Daten nicht an Dritte und legt sie Dritten gegenüber nicht offen.
<G-vec00490-002-s372><rent.ausleihen><en> Tarkett will not sell, rent or disclose your personal data to any other parties.
<G-vec00490-002-s373><rent.ausleihen><de> Das Hostel vermietet nicht nur Zimmer zum Übernachten, sondern auch iPods mit Berliner Musik, DVDs mit Berlin-Filmklassikern wie Good Bye Lenin und das freundliche Team steht seinen Gästen mit vielen Tipps Tag und Nacht zur Seite.
<G-vec00490-002-s373><rent.ausleihen><en> The hostel is not only a place to sleep, but you can also rent iPods filled with Berlin music, classic Berlin films on DVD such as Good Bye Lenin, and the friendly team is there to help day and night.
<G-vec00490-002-s374><rent.ausleihen><de> Vermietet werden nur die 2 Wohnungen im Parterre.
<G-vec00490-002-s374><rent.ausleihen><en> Only the 2 apartments in the ground floor are for rent.
<G-vec00490-002-s375><rent.ausleihen><de> Free Live Sex Cams vermietet, verkauft, handelt, teilt oder transferiert anderweitig Informationen nicht an Außenstehende, abgesehen von der Kommunikation mit Unternehmen der Free Live Sex Cams Gruppe und Dienstleistern, um die einwandfreie Funktionalität der Free Live Sex Cams Dienste sicherzustellen.
<G-vec00490-002-s375><rent.ausleihen><en> Free Live Sex Cams does not rent, sell, trade, share, or otherwise transfer information to outside parties except the communication to Free Live Sex Cams group companies and service providers in order to ensure the good functioning of Free Live Sex Cams services.
<G-vec00490-002-s376><rent.ausleihen><de> Außerdem kauft, verkauft und vermietet Kruizinga.de neue und gebrauchte Lager- und Transportmittel.
<G-vec00490-002-s376><rent.ausleihen><en> Moreover, Kruizinga.com is able to buy, sell and rent new and used material handling equipment.
<G-vec00490-002-s377><rent.ausleihen><de> Sollte die Anzahlung nicht spätestens 7 Tage nach Buchungsbestätigung eingegangen sein, kann das Mietobjekt an andere Interessenten vermietet werden.
<G-vec00490-002-s377><rent.ausleihen><en> If the deposit is not received at least 7 days after confirmation was received, the landlord is free to rent the premises to other prospective clients.
<G-vec00490-002-s378><rent.ausleihen><de> Vor Ort werden Autos, Fahrräder und Limousinen vermietet.
<G-vec00490-002-s378><rent.ausleihen><en> Cars and bicycles are available for rent on site.
<G-vec00490-002-s379><rent.ausleihen><de> Wenn Sie zum Beispiel Kosten sparen möchten, dann entscheiden Sie sich doch einfach für eine Eventlocation, die Ihnen nur den Veranstaltungsraum vermietet.
<G-vec00490-002-s379><rent.ausleihen><en> For example, if you want to save money, then opt for an event location that only lets you rent the function room.
<G-vec00505-002-s170><borrow.ausleihen><de> Man kann seine eigene Kamera verwenden oder eine Canon SLR Ausrüstung vor Ort ausleihen.
<G-vec00505-002-s170><borrow.ausleihen><en> You can use your own camera of borrow Canon SLR equipment on location.
<G-vec00505-002-s171><borrow.ausleihen><de> Hier können Sie entspannt fernsehen oder Spiele und Bücher ausleihen.
<G-vec00505-002-s171><borrow.ausleihen><en> You can relax while watching TV there as well as borrow games and books.
<G-vec00505-002-s019><rent.ausleihen><de> Im Hotel können Sie folgende Artikel ausleihen: Bademantel €7, Bademantel & Badeslipper €10, Bademantel & Badeslipper & Handtücher €15.
<G-vec00505-002-s019><rent.ausleihen><en> You can rent the following items at the hotel: bathrobe €7, bathrobe & slippers €10, bathrobe & slippers & towels €15.
<G-vec00505-002-s020><rent.ausleihen><de> So könnt ihr bei Konrad euer Fahrrad selbst reparieren, bei EliStu bekommt ihr Unterstützung, wenn ihr Eltern seid oder werden wollt, es gibt kostenlose BAföG-, Finanz- und Rechtsberatung, beim Bürodienst könnt ihr Geschirr, ein Megaphone und (manchmal) sogar einen Bus und bei Ton&Licht Lautsprecher für eure Veranstaltungen ausleihen.
<G-vec00505-002-s020><rent.ausleihen><en> You can get your bike fixed at KonRad, EliStu offers you support if you have or intend to have kids, we offer free BAföG-, financial and legal consultation, you can rent dishes, a megaphone and (sometimes) even a bus at our office as well as speakers and entire lighting systems for your events at Ton&Licht.
<G-vec00505-002-s021><rent.ausleihen><de> Kunden können die orangenen Fahrräder rund um die Uhr über eine Smartphone-App buchen und an einem der zahlreichen Orte in der Stadt ausleihen.
<G-vec00505-002-s021><rent.ausleihen><en> Customers can book the orange bicycles around the clock using a smartphone app and rent them from one of the numerous locations across the city.
<G-vec00505-002-s022><rent.ausleihen><de> Zur Erkundung der Stadt können Sie sich im Palomar Fahrräder ausleihen.
<G-vec00505-002-s022><rent.ausleihen><en> Guests can rent bikes from the Palomar to explore the city.
<G-vec00505-002-s023><rent.ausleihen><de> Sie können diese in der Unterkunft ausleihen.
<G-vec00505-002-s023><rent.ausleihen><en> Guests can rent them at the property.
<G-vec00505-002-s024><rent.ausleihen><de> Sie können sich gern im Garten entspannen und auch direkt im Hotel Fahrräder und Boote ausleihen.
<G-vec00505-002-s024><rent.ausleihen><en> Guests can also relax in the garden or rent bikes and boats directly from the hotel.
<G-vec00505-002-s025><rent.ausleihen><de> Gerne könnt Ihr bei uns Bettwäsche gegen eine Gebühr ausleihen.
<G-vec00505-002-s025><rent.ausleihen><en> You are invited to rent bedclothes for a fee.
<G-vec00505-002-s026><rent.ausleihen><de> Krapi hatte bequem Fahrräder, die wir ausleihen konnten, und da das Wetter so perfekt war, beschlossen wir, dass man am besten auf zwei Rädern den Weg weiter erkunden wollte.
<G-vec00505-002-s026><rent.ausleihen><en> Krapi conveniently had bicycles we could rent, and with the weather as perfect as it was we decided that two-wheels was the perfect way to explore further.
<G-vec00505-002-s027><rent.ausleihen><de> Bevor du dich für eine Ausrüstung entscheidest, kannst du Skier und Zubehör bei uns ausleihen und ausgiebig testen.
<G-vec00505-002-s027><rent.ausleihen><en> Before you decide on your equipment you can rent out skis and accessories from us and try these out.
<G-vec00505-002-s028><rent.ausleihen><de> Natürlich könnt Ihr bei uns auch Windsurf und SUP Material ausleihen.
<G-vec00505-002-s028><rent.ausleihen><en> Of course you can rent windsurf and SUP material as well.
<G-vec00505-002-s029><rent.ausleihen><de> Im Sommer können Sie sich bei uns ein Fahrrad ausleihen, für den Winter haben wir Rodeln bereit (Gratis für unsere Gäste).
<G-vec00505-002-s029><rent.ausleihen><en> In the summer you can rent a bike, during winter you can rent toboggans (free for our guests). Facilities:
<G-vec00505-002-s030><rent.ausleihen><de> Sie können diese an der Unterkunft für NOK 70 ausleihen oder selbst mitbringen.
<G-vec00505-002-s030><rent.ausleihen><en> You can rent them on site for 70 NOK or bring your own.
<G-vec00505-002-s031><rent.ausleihen><de> Quer über die Stadt verteilt gibt es zahlreiche Stationen, an denen ihr euch ein Kajak oder Kanu ausleihen könnt.
<G-vec00505-002-s031><rent.ausleihen><en> Throughout the city, there are numerous stations where you can rent a kayak or canoe.
<G-vec00505-002-s032><rent.ausleihen><de> Neben dem Schwimmbad können Sie sich Liegestühle und Sonnenblende ausleihen sowie die Natur bewundern, die sie umgibt.
<G-vec00505-002-s032><rent.ausleihen><en> At the pool you can rent sun loungers and umbrellas and admire the nature that surrounds you.
<G-vec00505-002-s033><rent.ausleihen><de> Es gibt Schwimmwesten für die ganze Familie zu ausleihen.
<G-vec00505-002-s033><rent.ausleihen><en> Life jackets for the whole family are available to rent.
<G-vec00505-002-s034><rent.ausleihen><de> Du darfst keine Filme kaufen oder ausleihen, die nicht „freigegeben“ sind.
<G-vec00505-002-s034><rent.ausleihen><en> You may not buy or rent films which are not ‘approved’.
<G-vec00505-002-s035><rent.ausleihen><de> Um beim Ausleihen im Geschäft Zeit zu sparen, können Sie Ihre Ausrüstung auch online reservieren.
<G-vec00505-002-s035><rent.ausleihen><en> If you choose to rent and save time in the shop, you can also reserve everything you need online.
<G-vec00505-002-s036><rent.ausleihen><de> Am Strand unterhalb des Hotels gibt es ein hervorragendes Tauchzentrum mit Tauchschule und PADI-Programmen, wo sich Anfänger ebenso wie erfahrene Taucher Ausrüstungen ausleihen und die fantastische Unterwasserwelt erkunden können.
<G-vec00505-002-s036><rent.ausleihen><en> On the beach below the Valamar Tamaris Villas, you’ll find an excellent PADI diving centre and school where novice and experienced divers can rent equipment to discover a vibrant underwater world.
<G-vec00505-002-s037><rent.ausleihen><de> Sie können Fahrräder ausleihen.
<G-vec00505-002-s037><rent.ausleihen><en> You can rent bikes.
