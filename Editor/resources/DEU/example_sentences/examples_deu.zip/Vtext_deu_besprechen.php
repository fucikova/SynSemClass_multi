<G-vec00057-001-s035><confer.besprechen><de> Bevor sie von Jesus Abschied nahmen, überreichten sie ihm einen Geldbeutel als Zeichen der Hochachtung seiner alexandrinischen Freunde und als Entschädigung für Zeit und Geld, die er für die Reise nach Cäsarea aufgewendet hatte, um sich mit ihnen zu besprechen.
<G-vec00057-001-s035><confer.besprechen><en> They were nonplused by his apparent indifference to the honor they had sought to confer upon him. Before taking leave of Jesus, they presented him with a purse in token of the esteem of his Alexandrian friends and in compensation for the time and expense of coming over to Caesarea to confer with them.
<G-vec00057-001-s036><confer.besprechen><de> Während des Laubhüttenfestes sahen Tausende von Gläubigen aus allen Teilen des Römischen Reichs Jesus und hörten ihn lehren, und viele von ihnen begaben sich sogar hinaus nach Bethanien, um mit ihm den Fortschritt des Königreichs in ihren Heimatgebieten zu besprechen.
<G-vec00057-001-s036><confer.besprechen><en> During the feast of tabernacles, thousands of believers from all parts of the Roman Empire saw Jesus, heard him teach, and many even journeyed out to Bethany to confer with him regarding the progress of the kingdom in their home districts.
<G-vec00057-001-s076><discuss.besprechen><de> Dann auf jeden Fall setzen Sie sich über Ihren Besuch auf Ihrem Lebensmittelgeschäft, Ihre Arbeit auf individuelle Untersuchung Papiere, sowie Ihre Optionen für den Tag und nutzen Sie die Entspannung unserer Kraft zusammen, um zu gehen und mit einem Arzt besprechen.
<G-vec00057-001-s076><discuss.besprechen><en> Then you definitely put away your visit to your grocery store, your work on custom investigation papers, as well as your options for the day and get the relaxation of our strength together to go and discuss with a health care provider.
<G-vec00057-001-s077><discuss.besprechen><de> Die Kleinbauern besprechen mit Yildirim die Anbauplanung und Fruchtfolge.
<G-vec00057-001-s077><discuss.besprechen><en> The small farmers discuss the planning of the cultivation and crop rotation with Yildirim.
<G-vec00057-001-s078><discuss.besprechen><de> Besprechen Sie Nutzen und Risiken dieser Therapie sorgfältig mit Ihrem Arzt.
<G-vec00057-001-s078><discuss.besprechen><en> Also, please discuss the benefits and risks of this therapy with your doctor.
<G-vec00057-001-s079><discuss.besprechen><de> Wir werden es kurz besprechen.
<G-vec00057-001-s079><discuss.besprechen><en> We'll discuss it momentarily.
<G-vec00057-001-s080><discuss.besprechen><de> Am Dienstag traf Dezember 2, 2003, Erzbischof Flynn eine Gruppe schwarze Minister und andere von der überwiegend schwarzen Gemeinschaft von Nordminneapolis, um den Schäferbuchstaben und seine Implikationen zu besprechen.
<G-vec00057-001-s080><discuss.besprechen><en> On Tuesday, December 2, 2003, Archbishop Flynn met with a group of black ministers and others from the predominantly black community of north Minneapolis to discuss the pastoral letter and its implications.
<G-vec00057-001-s081><discuss.besprechen><de> Bitte kontaktieren Sie Icecat, um die Möglichkeiten zu besprechen.
<G-vec00057-001-s081><discuss.besprechen><en> Please contact Icecat to discuss the possibilities.
<G-vec00057-001-s082><discuss.besprechen><de> Eine abwechslungsreiche Ernährung mit viel Obst und Gemüse kann alle Nährstoffe (Vitamine und Mineralien) benötigt werden.Es ist wichtig, mit Ihrem Arzt über die Einnahme dieses Produktes während der Schwangerschaft besprechen.
<G-vec00057-001-s082><discuss.besprechen><en> A varied diet rich in fruits and vegetables can provide all the nutrients (vitamins and minerals) is needed.It is important to discuss with your doctor about taking this product during pregnancy.
<G-vec00057-001-s083><discuss.besprechen><de> Wenn Sie Fragen zu uns oder zu den von uns angebotenen Produkten haben, stehen Ihnen unsere Experten jederzeit gerne zur Verfügung, um Ihren spezifischen Bedarf zu besprechen.
<G-vec00057-001-s083><discuss.besprechen><en> If you have any questions about us or any of our products, our experts are here, ready to discuss your needs.
<G-vec00057-001-s084><discuss.besprechen><de> Preservation and Presentation gibt Anlass, drängende Fragen zur Konservierung und Präsentation von zeitgenössischer Kunst zu besprechen, insbesondere solcher Kunst, die experimentelle Technologien und Medien einsetzt.
<G-vec00057-001-s084><discuss.besprechen><en> Preservation and Presentation offers an opportunity to discuss some of the most urgent issues associated with strategies of conservation and presentation of contemporary art that uses experimental technologies and complex media.
<G-vec00057-001-s085><discuss.besprechen><de> Bitte kontaktieren Sie uns, um zu besprechen wie wir für Ihre nächste Anwendung Kunststoffspritzguss- und Montageteile entwickeln und herstellen können.
<G-vec00057-001-s085><discuss.besprechen><en> Contact us to discuss how we can provide a Molded and Assembled component solution for your next program.
<G-vec00057-001-s086><discuss.besprechen><de> Patienten, die für Lyme-Borreliose mit Antibiotika behandelt werden, sollten ihre Bedenken in Bezug auf die Gesundheit der Knochen mit ihrem Arzt besprechen.
<G-vec00057-001-s086><discuss.besprechen><en> Patients being treated for Lyme disease with antibiotics should discuss their concerns regarding bone health with their physician.
<G-vec00057-001-s087><discuss.besprechen><de> Dies sollten Sie mit Ihrem CF-Zentrum/CF-Ärztin oder -Arzt besprechen.
<G-vec00057-001-s087><discuss.besprechen><en> This, you should discuss with your CF center.
<G-vec00057-001-s088><discuss.besprechen><de> Hier besprechen wir uns, dokumentieren Projektaktivitäten und planen nächste Schritte.
<G-vec00057-001-s088><discuss.besprechen><en> We discuss matters, document project activities and plan the next steps.
<G-vec00057-001-s089><discuss.besprechen><de> Außerdem kann man mit dem Anstaltsarzt/der Anstaltsärztin besprechen, ob eine Grippeschutzimpfung sinnvoll ist.
<G-vec00057-001-s089><discuss.besprechen><en> In addition, you can discuss with the prison doctor, whether getting the flu shot makes sense.
<G-vec00057-001-s090><discuss.besprechen><de> Bitte kontaktieren Sie Ihren Account Manager bei Icecat, um Ihre Optionen zu besprechen.
<G-vec00057-001-s090><discuss.besprechen><en> Please contact your account manager at Icecat to discuss your options.
<G-vec00057-001-s091><discuss.besprechen><de> Tom Naratil und Brian Hull treffen sich regelmäßig mit Finanzberatern und Linienvorgesetzten, um Wege zur kontinuierlichen Verbesserung unserer Kundendienstleistungen zu besprechen.
<G-vec00057-001-s091><discuss.besprechen><en> Tom Naratil and Brian Hull meet regularly withÂ financial advisors and field leaders to discuss waysÂ to continually enhance how we serve clients.
<G-vec00057-001-s092><discuss.besprechen><de> Zusätzlich werden Ihnen zwei persönliche Mentoren (einer der Dozenten und ein Student des zweiten Studienjahres) zugewiesen, an die Sie sich wenden können, um Ihren Studienfortschritt zu besprechen.
<G-vec00057-001-s092><discuss.besprechen><en> Additionally, you will be assigned two personal mentors (one of the lecturers and a second-year student), to whom you can turn to discuss your study progress.
<G-vec00057-001-s093><discuss.besprechen><de> Ngala Nor’dzin und Ngala ’ö-Dzin essen oft mit Ngak’chang Rinpoche und Khandro Déchen zu Abend, um die Entwicklung ihrer Sanghas und Fragen, die bei der Verbreitung der Unterweisungen auftauchen, zu besprechen.
<G-vec00057-001-s093><discuss.besprechen><en> Ngala Nor’dzin and Ngala ’ö-Dzin often dine with Ngak’chang Rinpoche and Khandro Déchen in order to discuss the evolution of their sangha and questions arising from the dissemination of the teachings.
<G-vec00057-001-s094><discuss.besprechen><de> Wir werden diese an mehr Länge wenn besprechen, von individuellen Sammlungen handelnd.
<G-vec00057-001-s094><discuss.besprechen><en> We shall discuss these at more length when treating of individual collections.
<G-vec00057-001-s095><discuss.besprechen><de> Besprechen Sie die Situation mit dem Partner.
<G-vec00057-001-s095><discuss.besprechen><en> Discuss the situation with your partner.
<G-vec00057-001-s096><discuss.besprechen><de> Besprechen Sie die modernen Kunstwerke.
<G-vec00057-001-s096><discuss.besprechen><en> Now discuss their modern art works.
<G-vec00057-001-s097><discuss.besprechen><de> Besprechen Sie mit Ihrem Kind alle gefährlichen Momente.
<G-vec00057-001-s097><discuss.besprechen><en> Discuss with your child in advance all the dangerous moments.
<G-vec00057-001-s098><discuss.besprechen><de> Besprechen Sie alle Vorteile und Nachteile, während sie mit Tritace behandelt werden, wenn Sie stillen.
<G-vec00057-001-s098><discuss.besprechen><en> Discuss all potential benefits and disadvantages while being treated with Tritace if you are breastfeeding.
<G-vec00057-001-s099><discuss.besprechen><de> Besprechen Sie mit Ihrem Arzt, ob Sie ein schwaches Immunsystem oder eine Autoimmunerkrankung wie HIV haben, bevor Sie Imiquad (Imiquimod) einnehmen.
<G-vec00057-001-s099><discuss.besprechen><en> Discuss with your doctor if you have a weak immune system or autoimmune disorder such as HIV before taking Imiquad (Imiquimod).
<G-vec00057-001-s100><discuss.besprechen><de> Besprechen Sie alles im Zusammenhang mit Maniaplanet.
<G-vec00057-001-s100><discuss.besprechen><en> Discuss everything related to Maniaplanet.
<G-vec00057-001-s101><discuss.besprechen><de> Besprechen Sie alle möglichen Risiken zu Ihrem Baby.
<G-vec00057-001-s101><discuss.besprechen><en> Discuss any possible risks to your baby.
<G-vec00057-001-s102><discuss.besprechen><de> Besprechen Sie die möglichen Risiken dieses Medikaments immer mit Ihrem Arzt, bevor Sie mit der Behandlung beginnen.
<G-vec00057-001-s102><discuss.besprechen><en> Always discuss the potential risks of this medication with your physician before commencing treatment.
<G-vec00057-001-s103><discuss.besprechen><de> Besprechen Sie mit Ihrem Arzt, wenn Sie Bronchitis oder Emphysem, eine Herzkrankheit oder kongestive Herzinsuffizienz in der Geschichte, dem Diabetes, der Nierekrankheit, einer Schilddrüse-Störung, einem neuen Herzanfall haben.
<G-vec00057-001-s103><discuss.besprechen><en> Discuss with your doctor if you have bronchitis or emphysema, a heart disease or congestive heart failure in history, diabetes, kidney disease, a thyroid disorder, a recent heart attack.
<G-vec00057-001-s104><discuss.besprechen><de> Besprechen Sie die Risiken von Nebenwirkungen mit Ihrem Arzt, bevor Sie diese Augentropfen verwenden.
<G-vec00057-001-s104><discuss.besprechen><en> Discuss the risks of all side effects with your physician before using these eye drops.
<G-vec00057-001-s105><discuss.besprechen><de> Besprechen Sie die Punkte und führen Sie zwei Übungen durch.
<G-vec00057-001-s105><discuss.besprechen><en> Discuss the points and complete two exercises.
<G-vec00057-001-s106><discuss.besprechen><de> Besprechen Sie diese Bemühungen mit dem sozialen Arbeiter, und er wird oder sie in der Lage sein, Sie in den Fragen zu konsultieren, wie es am besten ist, sich dem Kontakt mit den äusserlichen Bemühungen zu nähern.
<G-vec00057-001-s106><discuss.besprechen><en> Discuss these stresses with your social worker and he or she will be able to advise you on how best to approach dealing with external stresses.
<G-vec00057-001-s107><discuss.besprechen><de> Besprechen Sie die minimale Mietperiode, denn die Perioden sind bei allen Automietefirmen unterschiedlich.
<G-vec00057-001-s107><discuss.besprechen><en> Discuss minimal rental period since the periods vary with different car rental companies.
<G-vec00057-001-s108><discuss.besprechen><de> Besprechen Sie alles im Zusammenhang mit Shootmania.
<G-vec00057-001-s108><discuss.besprechen><en> Discuss everything related to Shootmania.
<G-vec00057-001-s109><discuss.besprechen><de> Besprechen Sie, wer es holt und bringt.
<G-vec00057-001-s109><discuss.besprechen><en> Discuss, who gets and brings it.
<G-vec00057-001-s110><discuss.besprechen><de> Besprechen Sie mit den Eltern einen Zeitplan für den Nachmittag.
<G-vec00057-001-s110><discuss.besprechen><en> Discuss an after-school schedule ahead of time with the parents.
<G-vec00057-001-s111><discuss.besprechen><de> Besprechen Sie das Risiko von Nebenwirkungen mit Ihrem Arzt, bevor Sie dieses Medikament einnehmen.
<G-vec00057-001-s111><discuss.besprechen><en> Discuss the risk of side effects with your physician before using this medication.
<G-vec00057-001-s112><discuss.besprechen><de> Besprechen Sie dies mit Ihrem Arzt, bevor Sie mit der Einnahme dieses Arzneimittels beginnen.
<G-vec00057-001-s112><discuss.besprechen><en> Discuss this with your physician before you begin taking this drug.
<G-vec00057-001-s113><discuss.besprechen><de> Besprechen Sie dies...
<G-vec00057-001-s113><discuss.besprechen><en> Discuss this...
<G-vec00057-001-s132><discuss.besprechen><de> Während der Abschlussbesprechung stellt der Auditor (bei einem Auditteam der Teamleiter) alle Ergebnisse vor und bespricht die festgestellten Abweichungen und Nichtkonformitäten.
<G-vec00057-001-s132><discuss.besprechen><en> During the closing meeting, the auditor (or lead auditor in the case of an audit team) shall present all findings and discuss all deviations and non-conformities which have been identified.
<G-vec00057-001-s133><discuss.besprechen><de> Damit Ihr Besuch im K Club etwas Besonderes ist, organisiert unser Golf Guest Services-Team Ihre Startzeiten, Golfstunden, Caddies, Werbegeschenke, bespricht Gruppentarife und passt Ihre Bedürfnisse an Ihren Tag an.
<G-vec00057-001-s133><discuss.besprechen><en> Ensuring your visit to The K Club is special, our Golf Guest Services Team will organise your tee times, golf lessons, caddies, corporate gifts, discuss group rates and tailor your needs towards your day.
<G-vec00057-001-s134><discuss.besprechen><de> Monatlich bespricht der Vorstand, wie der Verein mit den verfügbaren freien Spenden aus dem Internationalen Hilfsfonds helfen kann.
<G-vec00057-001-s134><discuss.besprechen><en> Every month the Board will discuss how the Association can help with the available independent donations from the International Relief Fund.
<G-vec00057-001-s135><discuss.besprechen><de> Dieser Artikel bespricht einige sorgen, die Menschen zu Gesicht, wenn sie sich entscheiden, eine Schadensersatzklage Unfall am Arbeitsplatz Datei.
<G-vec00057-001-s135><discuss.besprechen><en> This article will discuss some worries that people face when they decide to file an accident compensation claim at work.
<G-vec00057-001-s136><discuss.besprechen><de> Sieh dir an, wie unser Content Manager Chris Brennan diese Möglichkeit in einem unserer neuesten Facebook-Live-Videos bespricht.
<G-vec00057-001-s136><discuss.besprechen><en> Watch our content manager Chris Brennan discuss the possibility on one of our recent Facebook Live videos.
<G-vec00057-001-s137><discuss.besprechen><de> "Gewöhnlich sitzt Nachbarschaft Aktivisten und die Polizei über Kaffee hin und bespricht die verschiedenen ""Problemeigenschaften"" in der Nachbarschaft."
<G-vec00057-001-s137><discuss.besprechen><en> "Typically, neighborhood activists and the police sit down over coffee and discuss the various ""problem properties"" in the neighborhood."
<G-vec00057-001-s138><discuss.besprechen><de> Der Chirurg nimmt eine klinische Untersuchung vor und bespricht mit Ihnen alle Details bezüglich der Chirurgie, Anästhesie, Hämodilution (Blutverdünnung), Erholungsphase sowie Ihrem Lebensablauf nach dem Eingriff.
<G-vec00057-001-s138><discuss.besprechen><en> The surgeon will carry out a clinical examination and will discuss all the details of the surgery with you: the anaesthetic, the blood thinning drugs, the post operative care, the recovery period and your lifestyle after the procedure.
<G-vec00057-001-s139><discuss.besprechen><de> Ein Arzt wird nicht nur eine Routineuntersuchung durchführen, sondern er oder sie prüft auch auf versteckte Verletzungen, redet über die richtige Ernährungsweise, bespricht Trainingsprogramme und stellt sicher, dass Ihr Kind mental bereit für eine extra Ladung Stress ist, die meistens mit organisiertem Sport einhergeht.
<G-vec00057-001-s139><discuss.besprechen><en> Not only will the doctor conduct a routine physical, he or she can also check for any underlying injuries, talk about proper nutrition, discuss training and exercise programs and even make sure your child is mentally prepared for the extra layer of pressure that can come along with organized sports.
<G-vec00057-001-s140><discuss.besprechen><de> Man bespricht, aber man sieht auch Jahr für Jahr neue Bands der europäischen Szene.
<G-vec00057-001-s140><discuss.besprechen><en> Here you discuss things, but year after year you also see new bands from the European scene.
<G-vec00057-001-s141><discuss.besprechen><de> huidverjongende behandelingen.Während einer völlig unverbindlichen Konsultation bespricht der Arzt alle Aspekte der Behandlung mit Ihnen.
<G-vec00057-001-s141><discuss.besprechen><en> The doctor will discuss all aspects of the procedure with you during a no-obligation consultation.
<G-vec00057-001-s142><discuss.besprechen><de> "Es wurde einmal gesagt, dass""große Geister besprechen Ideen, durchschnittliche Geister besprechen Ereignisse, kleiner Verstand bespricht Leute""."
<G-vec00057-001-s142><discuss.besprechen><en> "It was once said, that, ""Great minds discuss ideas, average minds discuss events, small minds discuss people""."
<G-vec00057-001-s143><discuss.besprechen><de> Ein Audiologe bewertet die Art und den Grad des Hörverlusts, schätzt den funktionalen Nutzen von Hörgeräten ein und bespricht die möglichen Vorteile einer Behandlung mit einem Cochlea-Implantat.
<G-vec00057-001-s143><discuss.besprechen><en> An audiologist will evaluate the type and degree of hearing loss, assess the functional benefit received with hearing aids, and discuss the potential benefits to be gained from a cochlear implant.
<G-vec00057-001-s144><discuss.besprechen><de> Nicht kaufen Dianabol Anabolika Stacks, bevor Sie dieses Dianabol Bewertungen lesen: Steroide für die Massen Gebäude, das über bespricht nur wie funktioniert Dianabol Job, Dosierung und auch wo zu kaufen Anabolika für Muskelaufbau Dianabol in München Deutschland .
<G-vec00057-001-s144><discuss.besprechen><en> Do not purchase Dianabol Anabolic Steroids Stacks before you read this Dianabol Reviews: Steroids for mass building that will discuss concerning just how does Dianabol job, dosage and also where to buy Anabolic Steroids for mass building Dianabol in Massachusetts US.
<G-vec00057-001-s145><discuss.besprechen><de> Sie erhalten einen ausführlichen Bericht Ihrer gesamten Anlagen, den Ihr Berater mit Ihnen bespricht.
<G-vec00057-001-s145><discuss.besprechen><en> You receive a detailed report of all your investments, which your adviser will discuss with you.
<G-vec00057-001-s146><discuss.besprechen><de> Bei allen anderen Sitzungen bespricht der Rat Angelegenheiten zu anderen Pflichten und Aufgaben des Euro-Systems und der EZB.
<G-vec00057-001-s146><discuss.besprechen><en> At all other meetings, the Council meets to discuss issues relating to the other responsibilities and tasks of the Euro system and ECB.
<G-vec00057-001-s147><discuss.besprechen><de> Nach dem Eintritt bespricht ein Arzt oder eine Hebamme mit Ihnen den Schwangerschaftsverlauf und die Wehentätigkeit sowie den Ablauf der Geburt.
<G-vec00057-001-s147><discuss.besprechen><en> Following admission to the clinic, a doctor or midwife will discuss with you the course of your pregnancy, your contractions and the birth procedure.
<G-vec00057-001-s148><discuss.besprechen><de> Die Antwort bespricht den, an dem Sie am wenigsten interessiert sind, und sagt nichts über den anderen aus.
<G-vec00057-001-s148><discuss.besprechen><en> The reply will discuss the one you are least interested in and say nothing about the other.
<G-vec00057-001-s149><discuss.besprechen><de> Die Chefin der Region wird das Abkommen mit dem Verwaltungsleiter der Assoziation Wladimir Jablonski unterschreiben und bespricht mit ihm die Prioritätsprojekte, die es geplant wird, im Rahmen der zweiseitigen Partnerschaft zu realisieren.
<G-vec00057-001-s149><discuss.besprechen><en> The head of the region will sign an agreement with the chairman of the Association Vladimir Yablonsky and discuss with him the priority projects planned to be implemented in the framework of bilateral partnership.
<G-vec00057-001-s150><discuss.besprechen><de> "Obwohl das Vibhaṅga hinzufügt, daß Samen abgesondert wird, wenn er ""aus seiner Basis fällt"", bespricht es diesen Punkt nicht in irgendeinem Detail."
<G-vec00057-001-s150><discuss.besprechen><en> "Although the Vibhaṅga adds that semen is discharged when it ""falls from its base,"" it does not discuss this point in any detail."
<G-vec00057-001-s151><discuss.besprechen><de> Darüber hinaus haben die Experten in der gesamten Fabrik eine Fülle räumlicher Gegebenheiten geschaffen, damit sich die Mitarbeiter spontan austauschen können, denn von Angesicht zu Angesicht sind Dinge leichter besprochen und Fragen schneller geklärt.
<G-vec00057-001-s151><discuss.besprechen><en> Over and above this, the experts have created a host of areas throughout the factory so that the employees can exchange information spontaneously, because it is easier to discuss things and clear up questions quicker face to face.
<G-vec00057-001-s152><discuss.besprechen><de> Zusammen mit dem Patienten werden medizinische Maßnahmen besprochen undder Fortschritt der Genesung betrachtet.
<G-vec00057-001-s152><discuss.besprechen><en> He/she will discuss with you the medical measures undertaken and the progress in convalescence.
<G-vec00057-001-s153><discuss.besprechen><de> Zusätzlich führte der CRO Workshops mit dem Management der drei Divisionen sowie mit der Konzern­leitung durch, bei denen die jeweilige ­Risikosituation analysiert, Maßnahmen besprochen und Toprisiken definiert wurden.
<G-vec00057-001-s153><discuss.besprechen><en> In addition, the CRO conducted workshops with the management of the three ­divisions as well as with the Executive Committee to analyze the risk situation, to discuss measures to mitigate the risks, and to define the actual top risks of each unit.
<G-vec00057-001-s154><discuss.besprechen><de> Innerhalb der Technical Group werden Erkenntnisse zur Arbeitssicherheit ausgetauscht (ganz aktuell zum Beispiel zur Bergung von Personen aus engen Räumen), Reparaturen und Anlagenoptimierungen besprochen und Hinweise zur Vermeidung von Schäden gegeben.
<G-vec00057-001-s154><discuss.besprechen><en> They also share insights into occupational health & safety (currently, for example, on rescuing people from confined spaces), discuss repairs and plant optimisations and advise one another on avoiding damage.
<G-vec00057-001-s155><discuss.besprechen><de> Da nun Prof. Riemann die zahlreichen Beweise, die ich zur Unterstützung meiner Anschauung mitteilte, nicht widerlegt, ja sogar nicht einmal besprochen hat, muss ich schließen, daß er an dem eigentlichen Gegenstand meiner Arbeit vorbeigegangen ist.
<G-vec00057-001-s155><discuss.besprechen><en> Professor Reimann does not disprove the numerous proofs which I offered to support my opinion; he did not even discuss them. I must conclude that he missed the actual subject of my work.
<G-vec00057-001-s156><discuss.besprechen><de> Hätten sie alle Themen im Moment ihres Aufkommens miteinander besprochen, hätten sie entdecken können, dass ihre Spekulationen falsch waren.
<G-vec00057-001-s156><discuss.besprechen><en> Were they to discuss any issues that might crop up, they would discover that their speculations were false.
<G-vec00057-001-s157><discuss.besprechen><de> Während keine Marke oder Lieferanten besprochen wird, gehen wir über die grundlegenden Fakten und Wahrheiten, die grundlegenden Prinzipien in Reihenfolge um Ihnen ein richtiges Verständnis zu geben.
<G-vec00057-001-s157><discuss.besprechen><en> While we will certainly not discuss any sort of brand or supplier, we will certainly go over the basic realities and facts, the fundamental concepts in order to supply you a mutual understanding.
<G-vec00057-001-s158><discuss.besprechen><de> Diese Ideen dürfen dann nicht im Papierkorb verschwinden, sondern müssen gemeinsam besprochen werden, auch wenn sie vielleicht im ersten Schritt nicht umsetzbar erscheinen.
<G-vec00057-001-s158><discuss.besprechen><en> Then you need to be careful not to discard their ideas, but to discuss them together, even if they perhaps appear impossible to implement at first.
<G-vec00057-001-s159><discuss.besprechen><de> Unter der Leitung des FEI Director Driving, Manuel Bandeira De Mello, wurden die Turnierregeln ausführlich erörtert und es wurden an Hand von Videoaufnahmen verschiedene Vorfälle besprochen.
<G-vec00057-001-s159><discuss.besprechen><en> FEI Driving Director Manuel Bandeira De Mello led the meeting in which the World Cup Rules were discussed and clarified. The group looked at several videos to discuss various incidents.
<G-vec00057-001-s160><discuss.besprechen><de> Der Befehl Twin_Inkey_Clear bricht die Eingabe in einem Fenster vorzeitig ab und wirkt sowohl auf eine einfache Zeicheneingabe (Twin_Inkey) als auch auf den Twin_Input Befehl, der jetzt besprochen wird.
<G-vec00057-001-s160><discuss.besprechen><en> The command Twin_Inkey_Clear cancels the input inside a window prematurely and applies to a simple character input (Twin_Inkey) as well as to the command Twin_Input, which we will discuss next.
<G-vec00057-001-s161><discuss.besprechen><de> Während der Tour haben wir die Möglichkeit, den Palazzo Medici, Palazzo Vecchio, das wichtigste bürgerliche Gebäude der Stadt, zu sehen; Dort werden auch die Freiluftskulpturen der Loggia della Signoria besprochen.
<G-vec00057-001-s161><discuss.besprechen><en> During the tour we will have the opportunity to observe Palazzo Medici, Palazzo Vecchio the most important civil building in the city; where will also discuss the open air sculptures found within the Loggia della Signoria.
<G-vec00057-001-s162><discuss.besprechen><de> Für Werke besteht zudem ein fester Regeltermin, bei dem die aktuelle Unfallsituation besprochen wird.
<G-vec00057-001-s162><discuss.besprechen><en> Plants also have a set date on which to discuss the current accident situation.
<G-vec00057-001-s163><discuss.besprechen><de> Zusätzlich führte der CRO Workshops mit dem Management der drei Divisionen sowie mit der Konzernleitung durch, bei denen Risikosituationen analysiert, Maßnahmen besprochen und Toprisiken definiert wurden.
<G-vec00057-001-s163><discuss.besprechen><en> In addition, the CRO conducted workshops with the management of the three divisions as well as with the Executive Committee to analyze the risk situation, to discuss measures to mitigate risks, and to define the actual top risks for each unit.
<G-vec00057-001-s164><discuss.besprechen><de> Händler und Hersteller ziehen Bilanz der abgelaufenen Saison, die Zusammenarbeit wird besprochen und der Blick in die nächste Saison gewagt.
<G-vec00057-001-s164><discuss.besprechen><en> Dealers and manufacturers take stock of the past year, discuss cooperation and venture a look into the next season.
<G-vec00057-001-s165><discuss.besprechen><de> Dabei wird geklärt, wie es den gefiederten Freunden geht und Probleme / Fragen besprochen.
<G-vec00057-001-s165><discuss.besprechen><en> It is clarified, as the feathered friends go and discuss problems / issues.
<G-vec00057-001-s166><discuss.besprechen><de> Der Lehrer wählt einen Lehrer aus, der für die Passage aus dem Gedicht von Bedeutung ist, das der Lehrer mit den Schülern besprochen hat.
<G-vec00057-001-s166><discuss.besprechen><en> The teacher chooses a teacher who is meaningful to be with the passage from the poem the teacher has chosen to discuss with the students.
<G-vec00057-001-s167><discuss.besprechen><de> Mit einem Projektpartner aus unserem Institut wird das Forschungsvorhaben zu Beginn des Aufenthalts am HIIG besprochen und durch regelmäßigen Austausch, Präsentationsmöglichkeiten und mögliche gemeinsame Veröffentlichungen unterstützt.
<G-vec00057-001-s167><discuss.besprechen><en> Together with a project partner from a complementary research area, individuals will discuss their research plan at the beginning of their stay at the institute and will be supported through regular conversations as well as possible publications.
<G-vec00057-001-s168><discuss.besprechen><de> Mit dem Geschäftsführer ­Günther Paul und mit seinem Sohn Patrick als designierten Nachfolger habe ich in München auf der Laser Messe oder in San Jose auf der Photonics West zusammengesessen, Geschäfte vereinbart und Visionen besprochen.
<G-vec00057-001-s168><discuss.besprechen><en> I sat with GÃ1⁄4nther Paul, then managing director, and his son Patrick Paul, designated successor, at the LASER trade show in Munich and Photonics West in San Jose to close deals and discuss our vision for the future.
<G-vec00057-001-s169><discuss.besprechen><de> Im Proseminar wird besprochen, wie mit Hilfe der in?nitesimalen Elemente die grundlegenden Aussagen der Analysis neu formuliert und bewiesen werden koennen.
<G-vec00057-001-s169><discuss.besprechen><en> The proseminar will discuss how the basic statements of the analysis can be reformulated and proven with the help of the in?nitesimalen elements.
<G-vec00057-001-s625><discuss.besprechen><de> Gerne können Sie mit unserer Studienberatung einen Termin vereinbaren, um Ihre Situation und Ihre Möglichkeiten zu besprechen.
<G-vec00057-001-s625><discuss.besprechen><en> You can make an appointment with our Course Guidance team to discuss your situation and the opportunities on offer.
<G-vec00057-001-s626><discuss.besprechen><de> "Und um zu besprechen, in welchen vielversprechenden ""Challenger"" es sich wohl lohnt, künftig zu investieren."
<G-vec00057-001-s626><discuss.besprechen><en> "They also discuss which promising ""challengers"" will be worth an investment in the future."
<G-vec00057-001-s627><discuss.besprechen><de> Bitte kontaktieren Sie mich, Lyn Neville, um die perfekte Wanderung für Sie besprechen, für Gruppen, Studenten aus Übersee, Lehrplan, Feiern, ein Gespenst zu Fuß oder mit einem besonders maßgeschneiderte Spaziergang.
<G-vec00057-001-s627><discuss.besprechen><en> Please contact me, Lyn Neville . to discuss the perfect walk for you,for groups, overseas students,school syllabus, celebrations, a ghost walk or an especially tailor- made walk.
<G-vec00057-001-s628><discuss.besprechen><de> Es ist wichtig, sich seiner Familienanamnese und seiner genetischen Prädisposition für ALS bewusst zu sein und mit einem Arzt zusammenzuarbeiten, um etwaige Symptome und diagnostische Maßnahmen zu besprechen.
<G-vec00057-001-s628><discuss.besprechen><en> It is important to be aware of your family history and genetic predisposition for ALS and to work with a doctor to discuss any symptoms and testing.
<G-vec00057-001-s629><discuss.besprechen><de> Kontaktieren Sie Ihren Roland-Händler, um seinen Vorratsstatus zu besprechen.
<G-vec00057-001-s629><discuss.besprechen><en> Please contact your Roland dealer and discuss his stock status.
<G-vec00057-001-s630><discuss.besprechen><de> Daher hat der kürzlich angestellte Minister für Öffentliche Arbeiten, Verkehr und Kommunikationen, Oskar Valentin Plichta, seinen Amtsgenossen in Südafrika, Mac Maharaj, um einen dringenden Gesprächstermin gebeten, um dieses zu besprechen.
<G-vec00057-001-s630><discuss.besprechen><en> Therefore, the newly appointed Minister for Works, Transport and Communication, Oskar Valentin Plichta, requests an urgent meeting with the South African Transport Minister, Mac Maharaj, to discuss this.
<G-vec00057-001-s631><discuss.besprechen><de> Der Milliardär Richard Branson hostete auf seiner Privatinsel eine Veranstaltung mit den klügsten Köpfen der Bitcoin Welt, um die Zukunft der Blockchain Technologie zu besprechen.
<G-vec00057-001-s631><discuss.besprechen><en> Billionaire Richard Branson hosted the greatest minds in Bitcoin on his private Island to discuss the future of Blockchain technology.
<G-vec00057-001-s632><discuss.besprechen><de> Um die größtmögliche Effizienz Ihres Chargierungssystems zu erreichen ist es äußerst wichtig, dass Sie all diese Optionen mit dem Hersteller des Chargierungssystems besprechen.
<G-vec00057-001-s632><discuss.besprechen><en> It is important to discuss all of these options with the batching system manufacturer, in order to ensure the most efficient overall batching operation.
<G-vec00057-001-s633><discuss.besprechen><de> Über das Wochenende ziehen wir wieder auf den Big4, um mit Marc und Teri Details unserer geplanten Reise zu besprechen.
<G-vec00057-001-s633><discuss.besprechen><en> For the weekend we decide to stay at the Big4 and discuss the travel plans in detail with Marc and Teri.
<G-vec00057-001-s634><discuss.besprechen><de> Wenn die eine Million Unterschriften gesammelt ist, treffen sich Vertreter der Kommission mit den Organisatoren, um das Begehren detailliert zu besprechen.
<G-vec00057-001-s634><discuss.besprechen><en> Once one million signatures have been collected, representatives from the Commission will meet with organisers and discuss the initiative in detail.
<G-vec00057-001-s635><discuss.besprechen><de> Der Präsident der Europäischen Kommission José Manuel Barroso und das Kollegium der Kommissionsmitglieder besuchten heute Dublin für mehrere Treffen mit Taoiseach (Premierminister) Enda Kenny, Tánaiste (Vizepremier) Eamon Gilmore und Mitgliedern der irischen Regierung, um die gemeinsame Arbeit an den Hauptprioritäten des irischen EU-Ratsvorsitzes zur Schaffung von Stabilität, Arbeitsplätzen und Wachstum in Europa zu besprechen.
<G-vec00057-001-s635><discuss.besprechen><en> The President of the European Commission, Mr José Manuel Barroso and the College of Commissioners visited Dublin today for meetings with Taoiseach Enda Kenny, Tánaiste Eamon Gilmore and members of the Government to discuss working together with the Irish Presidency on its key priorities of delivering stability, jobs and growth for Europe.
<G-vec00057-001-s636><discuss.besprechen><de> Kontaktieren Sie uns, um Ihr Vorhaben mit uns zu besprechen.
<G-vec00057-001-s636><discuss.besprechen><en> Also, BAUNAT only offers certified jewellery and diamonds; contact us to discuss your ideas.
<G-vec00057-001-s637><discuss.besprechen><de> Bitte kontaktieren Sie die US-Niederlassung, bevor Sie die Anzahlung für die Anmeldung übermitteln, um die Bearbeitungsfristen für die Bearbeitung des Visums für Studierende in Bezug auf Ihren Bewerbungstermin zu besprechen.
<G-vec00057-001-s637><discuss.besprechen><en> Please contact the U.S. office before submitting the enrollment deposit to discuss student visa processing deadlines in relation to your application submission date.
<G-vec00057-001-s638><discuss.besprechen><de> Vertreter des Amtes des Öffentlichen Wächters werden anwesend sein, um das neue Online-Einreichungssystem von OPG102 sowie Vertreter des Ministeriums für Arbeit und Renten zu besprechen.
<G-vec00057-001-s638><discuss.besprechen><en> Representatives from the Office of the Public Guardian will be on hand to discuss the new OPG102 online submission system as well as representatives from the Department of Work and Pensions.
<G-vec00057-001-s639><discuss.besprechen><de> Heute ist Dienstag, Kanada Unsere Kunden gekommen, um unser Büro, um sein neues Projekt mit unserem Manager besprechen.
<G-vec00057-001-s639><discuss.besprechen><en> Today is Tuesday, Our Canada customer come to our office to discuss his new project with our manager.
<G-vec00057-001-s640><discuss.besprechen><de> Auf der diesjährigen Tourismusmesse Tok Tok im südpazifischen Inselstaat Vanuatu trafen sich die führenden Vertreter der Tourismusindustrie des Pazifikraumes, um in Port Vila neue Produkte und Services für den Inselstaat zu besprechen.
<G-vec00057-001-s640><discuss.besprechen><en> At this year’s tourism trade show Tok Tok in the South Pacific Vanuatu, the leading representatives of the tourism industry met in Port Vila to discuss new products and services for the local tourism industry.
<G-vec00057-001-s641><discuss.besprechen><de> Die Besucher trafen hierbei erstmals auf 450 ausstellende Firmen, um konkrete Projekte zu besprechen, neue Kontakte zu knüpfen und Geschäfte zu tätigen.
<G-vec00057-001-s641><discuss.besprechen><en> The visitors came to discuss specific projects, make new contacts and to do business with the 450 suppliers present.
<G-vec00057-001-s642><discuss.besprechen><de> Wenden Sie sich noch heute an uns, um die Möglichkeiten von DURA-BASE®für Ihre nächsteÖlfeld-Baustellezu besprechen.
<G-vec00057-001-s642><discuss.besprechen><en> Contact us today to discuss DURA-BASE® options for your next oil field construction site.
<G-vec00057-001-s643><discuss.besprechen><de> Dann traf er sich mit seinen Generälen, um die Strategie zu besprechen.
<G-vec00057-001-s643><discuss.besprechen><en> He then met with his generals to discuss the strategy to take.
<G-vec00208-002-s035><confer.besprechen><de> Dies bedeutet, dass der betreffende Prüfer beauftragt ist, bis zu dem genannten Zeitpunkt das Verfahren mit dem Anmelder im Auftrag der Prüfungsabteilung zu führen; er kann sich indessen informell jederzeit mit den anderen Mitgliedern der Abteilung besprechen, wenn besondere Zweifelsfragen oder Schwierigkeiten auftreten.
<G-vec00208-002-s035><confer.besprechen><en> This means that this examiner is entrusted to act on behalf of the examining division in all communications with the applicant up to that point, but he may confer informally with the other members of the division at any time if a special point of doubt or difficulty arises.
<G-vec00208-002-s036><confer.besprechen><de> Das ist eine gute Zeit für den Schlagmann, seine Strategie mit den anderen zu besprechen.
<G-vec00208-002-s036><confer.besprechen><en> This is a good time for the batsmen to confer with each other on strategy.
<G-vec00208-002-s037><confer.besprechen><de> Gerne besprechen wir alle weiteren Details mit Ihnen persönlich.
<G-vec00208-002-s037><confer.besprechen><en> We would like to confer with you personally about all further details.
<G-vec00208-002-s038><confer.besprechen><de> Bitte besprechen Sie mit uns, was möglich ist.
<G-vec00208-002-s038><confer.besprechen><en> Please confer with us what is possible otherwise.
<G-vec00384-002-s069><inquire.besprechen><de> Tragen Sie nachfolgend Ihre Kontaktangaben ein und wir werden uns schnellstmöglich mit Ihnen in Verbindung setzen, um Ihre Wünsche zu besprechen.
<G-vec00384-002-s069><inquire.besprechen><en> Please enter your details below so we can contact you as soon as possible to inquire about your requirements.
