<G-vec00318-002-s436><align.ausrichten><de> Mittlerweile machen neue Konstruktions-Methoden und Theorien aus der Luft- und Raumfahrt es möglich, die einzelnen Fasern in den verschiedenen Bereichen der Oberteile jeweils so auszurichten, wie sie dort am besten passen.
<G-vec00318-002-s436><align.ausrichten><en> Meanwhile make new construction methods and theories of aerospace it possible for the individual fibers in the different areas of the tops align each as they fit best there.
<G-vec00318-002-s437><align.ausrichten><de> Zurück nach oben Sachregister und Schlagwortverzeichnisse Sie brauchen die Zahlen nicht so auszurichten, wie sie auf der Vorlage aussehen.
<G-vec00318-002-s437><align.ausrichten><en> You don't need to align the numbers as they appear in the image; just put a comma followed by the page numbers.
<G-vec00318-002-s438><align.ausrichten><de> Er hat die Kamera so auszurichten, dass die optische Achse der Kamera während der gesamten Belichtungszeit bestmöglich das Fahrzeug trifft.
<G-vec00318-002-s438><align.ausrichten><en> He has to align the camera in order that the optical axis of the camera hits the vehicle during the entire exposure time as good as possible.
