<G-vec00241-001-s114><carry.befördern><de> 5d4) Wir befördern Sie nicht, wenn Sie zum Zeitpunkt der Reise jünger als 14 Jahre sind und Ihre Buchung oder eine verknüpfte Buchung keine mitreisende Person enthält, die mindestens 16 Jahre alt ist.
<G-vec00241-001-s114><carry.befördern><en> 5d4) We will not carry you if you are aged under 14 at the date of travel and are not travelling with someone aged 16 or older on your booking or on a linked booking.
<G-vec00241-001-s115><carry.befördern><de> Im Skigebiet Lienzer Bergbahnen können die 12 Skilifte bis zu 13.000 Personen pro Stunde befördern.
<G-vec00241-001-s115><carry.befördern><en> In ski resort Lienzer Bergbahnen the 12 lifts can carry 13,000 people per hour.
<G-vec00241-001-s116><carry.befördern><de> • Matte stets in einem Packsack oder einem anderen Schutzbeutel befördern.
<G-vec00241-001-s116><carry.befördern><en> • Always carry the air mattress in a stuff sack or other protective bag.
<G-vec00241-001-s117><carry.befördern><de> Mit dem Merger zwischen der deutschen Schifffahrtslinie Hapag-Lloyd mit der chilenischen Reederei CSAV würden die vier größten Linien der Welt, Maersk, MSC, CMA CGM und Hapag-Lloyd mehr als 40% der Containerkapazität der Welt befördern.
<G-vec00241-001-s117><carry.befördern><en> With the German shipping line Hapag-Lloyd's merger with the Chilean line CSAV, the top four lines in the world, i.e. Maersk, MSC, CMA CGM & Hapag-Lloyd would now carry over 40% of the world's container capacity.
<G-vec00241-001-s118><carry.befördern><de> Die deutschen Eisenbahnen befördern täglich 6,3 Millionen Fahrgäste, 6 Millionen im Nahverkehr und 300.000 im Fernverkehr.
<G-vec00241-001-s118><carry.befördern><en> The German railways carry 6.3 million passengers per day in regional transport and 300,000 inter-city passengers.
<G-vec00241-001-s119><carry.befördern><de> Huminsäure ist im Stande, die anorganischen Spurenelemente durch die Zellmembran zu befördern.
<G-vec00241-001-s119><carry.befördern><en> Humic substances carry minerals through cell membrane.
<G-vec00241-001-s120><carry.befördern><de> Güter oder Personen zu befördern, wenn dies direkt oder indirekt die Untervermietung des Fahrzeuges beinhaltet.
<G-vec00241-001-s120><carry.befördern><en> To carry passengers or goods when this implies subletting vehicle directly or indirectly.
<G-vec00241-001-s121><carry.befördern><de> Gerne befördern wir den Kinderwagen sowie Hunde kostenlos.
<G-vec00241-001-s121><carry.befördern><en> We do carry for free children's buggies and dogs.
<G-vec00241-001-s122><carry.befördern><de> Die Dorfbewohner bauten Plattformen aus Bambus, an denen sie kleine Räder befestigten, um Getreide und Güter von einem Dorf zum nächsten befördern zu können.
<G-vec00241-001-s122><carry.befördern><en> The villagers created a bamboo platform with small wheels along a track to carry crops and goods from one village to the next.
<G-vec00241-001-s123><carry.befördern><de> Die zehn modernen Lifte befördern in der Stunde insgesamt beinahe 11.000 Personen bergwärts.
<G-vec00241-001-s123><carry.befördern><en> The ten modern lifts carry nearly 11.000 people uphill per hour.
<G-vec00241-001-s124><carry.befördern><de> In der Kabine von Flugzeugen erlaubt, bis zu 7 kg Handgepäck pro Passagier zu befördern.
<G-vec00241-001-s124><carry.befördern><en> In the cabin of aircraft allowed to carry up to 7 kg of hand luggage per passenger.
<G-vec00241-001-s125><carry.befördern><de> Heute befördern Düsenjets weltweit jährlich mehr als fünf Milliarden Passagiere.
<G-vec00241-001-s125><carry.befördern><en> Today jet planes carry more than five billion passengers worldwide.
<G-vec00241-001-s126><carry.befördern><de> Güter oder Personen zu befördern, ohne hierfür die erforderlichen Genehmigungen vorliegen zu haben.
<G-vec00241-001-s126><carry.befördern><en> To carry persons or goods without having obtained the corresponding official permits.
<G-vec00241-001-s127><carry.befördern><de> Zur rechten Zeit wird dann Sein Wille schon nach außen hinaus zu strahlen anfangen, und ich und alle meinesgleichen werden denselben alsogleich in uns völlig aufnehmen und ihn befördern in alle Unendlichkeit hinaus; darum führen wir auch eigenschaftlich den Namen,Erzboten‘, weil wir die Austräger und die Auswirker des göttlichen Willens sind.
<G-vec00241-001-s127><carry.befördern><en> At the right time His intention will then begin to shine out, and I and all those like me will immediately fully take in the same into our being and carry it into all infinity; therefore we also carry the name ‘supreme messengers’, because we are the bearers and executers of the divine will.
<G-vec00241-001-s128><carry.befördern><de> Mit dem Ziehwagen können Sie auf einfache Weise die Untensilien und das Essen für den Tag befördern.
<G-vec00241-001-s128><carry.befördern><en> With the pull cart can carry easily the utensils and the food for the day.
<G-vec00241-001-s129><carry.befördern><de> Vor Kurzem haben wir eine Art kleinen Unimog für Afrika entwickelt, der Personen und Güter mit einer Batterieladung 80 Kilometer weit befördern kann.
<G-vec00241-001-s129><carry.befördern><en> We recently developed a kind of small Unimog for Africa that can carry passengers and goods for 80 kilometres on one battery charge.
<G-vec00241-001-s130><carry.befördern><de> Es kann vorkommen, dass Waren vorhanden sind, dass die volle Möglichkeit besteht, den Warenumsatz zu entfalten, das Verkehrswesen aber nicht mit der Entwicklung des Warenumsatzes Schritt hält und nicht imstande ist, die Güter zu befördern.
<G-vec00241-001-s130><carry.befördern><en> It may happen that goods are available, that all the possibilities exist for expanding trade turnover, but transport cannot keep up with the development of trade turnover and refuses to carry the freight.
<G-vec00241-001-s131><carry.befördern><de> Sie hat den Vorteil, dass man etwas in ihr befördern kann, selbst wenn es nur Luft ist und dass sie per Aufdruck eine deutlich sichtbare Botschaft vermittelt.
<G-vec00241-001-s131><carry.befördern><en> It has the advantage that one can carry something in it, even if it's only air and it transports a visible message in the print on it.
<G-vec00241-001-s132><carry.befördern><de> Die Wissenschaftler des DLR-Institut für Planetenforschung warten nun mit Spannung darauf, dass weitere Instrumente wie das Spektrometer VIRTIS, an denen sie beteiligt sind, Daten zu den Gasen liefern, die die Staubteilchen von der Kometenoberfläche ins All befördern.
<G-vec00241-001-s132><carry.befördern><en> Now, the scientists at the DLR Institute of Planetary Research are waiting with bated breath for other instruments, among them the spectrometer VIRTIS, in which they were contributing partners, to deliver data on the gases that carry the dust particles from the surface of the comet into space.
<G-vec00060-001-s038><convey.befördern><de> Es ist nicht genug für euch, mich direkt zu hören, aber es genügt, den Keim von Misstrauen zu sammeln von solchen, die ihr Wissen jenseits des Urantia Buches zu Leuten befördern, die gar nichts hören können.
<G-vec00060-001-s038><convey.befördern><en> It is not enough for you to hear me directly, but it is enough to gather the seeds of distrust of those who would convey what they know beyond the Urantia Book to people who can not hear a thing.
<G-vec00060-001-s039><convey.befördern><de> Der Luftdurchsatz ist die Fähigkeit, das angehobene Material zu befördern und bei großen Staubmengen vorübergehend in den Leitungen zu halten.
<G-vec00060-001-s039><convey.befördern><en> The air flow rate is the capacity to convey the lifted material and, when there is a lot of dust, to keep it suspended in the tubes.
<G-vec00060-001-s040><convey.befördern><de> Abwasserentsorgungsnetze sammeln und befördern Wasser von häuslichen, industriellen und gewerblichen Abwassereinleitungen zu zentralen Wasseraufbereitungsanlagen, ohne die Gesundheit der Gemeinschaften und der Umwelt zu gefährden.
<G-vec00060-001-s040><convey.befördern><en> Wastewater collection networks are used to safely collect and convey water from domestic, industrial, and commercial waste discharges to centralized wastewater treatment plants without compromising the health of communities and the environment.
<G-vec00060-001-s041><convey.befördern><de> Du hast die Vergangenheit dich befördern lassen, unterdessen du es bist, der dich selbst befördern muss.
<G-vec00060-001-s041><convey.befördern><en> You have let the past convey you when it is you who must convey yourself.
<G-vec00060-001-s042><convey.befördern><de> Überdimensionierte, riesige Luftrohre befördern die gewaltigen Luftmassen durch das Gebäude, die für das Prüfen der Ventilatoren im Prüfstand benötigt werden.
<G-vec00060-001-s042><convey.befördern><en> Huge, oversized air ducts convey the vast air mass needed to test the fans in the test chamber through the building.
<G-vec00060-001-s043><convey.befördern><de> Dieser Mischapparat verfügt über einen Rotor mit zwei Gewindeschnecken, die sich drehen, das Produkt in die entgegengesetzte Richtung befördern und, infolgedessen, alle Bestandteile vermischen.
<G-vec00060-001-s043><convey.befördern><en> This mixing machine has a rotor with two double thread spiral worms that convey the product by reverse spinning to mix and blend the different components into an homogeneous mixture in a few minutes.
<G-vec00060-001-s044><convey.befördern><de> Das Beste ist, die Liebe, die diese kleine Familie ist in der Lage, jeden Tag in der Behandlung von diesem schönen Ort zu befördern; nicht, das Restaurant zu erwähnen, ist das Baby des Hauses ein super Koch (die Nudeln nicht verpassen, um biancada).
<G-vec00060-001-s044><convey.befördern><en> The best thing is the love that this little family is able to convey every day in the management of this beautiful place; not to mention the restaurant, the baby of the house is a super chef (do not miss the noodles to biancada).
<G-vec00060-001-s045><convey.befördern><de> Transportmischer und Betonpumpen bilden hierbei ein eingespieltes Team: Wirtschaftliche und wendige Transportmischer bringen den Beton vom Mischwerk zur Baustelle, leistungsstarke Betonpumpen befördern ihn dorthin, wo er tatsächlich gebraucht wird.
<G-vec00060-001-s045><convey.befördern><en> To achieve this, transport mixers and concrete pumps must form a well-coordinated team: Economical and manoeuvrable truck mixers transport the concrete from the mixing plant to the construction site, and powerful concrete pumps convey it to where it is actually needed.
<G-vec00060-001-s046><convey.befördern><de> Logistikunternehmen, die schwere Güter im KV befördern wollen, müssen die gleiche Nutzlast wie im reinen Straßentransport realisieren können.
<G-vec00060-001-s046><convey.befördern><en> Therefore logistics companies need to have the same payload as for dedicated road haulage if they want to convey heavy goods.
<G-vec00337-001-s012><expedite.befördern><de> In Italien gibt es ein gut etabliertes Netzwerk von Muslimen, die Flüchtlinge in andere Länder mit besseren Sozialsystemen als Italiens befördern.
<G-vec00337-001-s012><expedite.befördern><en> In Italy, there is a well established network of Muslims to expedite the refugees to other countries with better welfare systems than that of Italy.
<G-vec00276-001-s019><promote.befördern><de> Aus diesen Beobachtungen, Interviews und Gesprächen haben sie folgende Handlungsempfehlungen abgeleitet: Es geht vor allem darum, die ästhetische und politische Ermächtigung von Kindern und Jugendlichen im Schulalltag zu befördern, kritische Reflexion und Mitgestaltung des Schulalltags zu stärken, sowie Digitalität und Umweltfreundlichkeit in die Schulpraxis einzubeziehen.
<G-vec00276-001-s019><promote.befördern><en> They used these observations, interviews and conversations to draw up the following Action Recommendations. The chief aim is to promote the aesthetic and political empowerment of children and teenagers in school life, to strengthen critical reflection and participation in school life, and to include digitality and environmental friendliness in school practice.
<G-vec00276-001-s020><promote.befördern><de> These 6: Die TTIP-Verhandlungen bergen das Potential, auch die Interessen der Verbraucherinnen und Verbraucher zu befördern.
<G-vec00276-001-s020><promote.befördern><en> Thesis 6: The TTIP negotiations have the potential to promote the interests of consumers.
<G-vec00276-001-s021><promote.befördern><de> Ein reifer Überrest Der Herr ruft einen reifen Überrest hervor, um sie zu befördern und mit neuer Autorität auszustatten.
<G-vec00276-001-s021><promote.befördern><en> Mature Remnant The Lord is calling forth a mature remnant to promote them with new authority.
<G-vec00276-001-s022><promote.befördern><de> Zwar muss die Bedeutung nationaler und regionaler Besonderheiten und verschiedener historischer, kultureller und religiöser Gegebenheiten berücksichtigt werden, aber es ist die Pflicht der Staaten, unabhängig von politischen, wirtschaftlichen und kulturellen Systemen alle Menschenrechte und Grundfreiheiten zu befördern und zu schützen.
<G-vec00276-001-s022><promote.befördern><en> While the significance of national and regional particularities and various historical, cultural and religious backgrounds must be borne in mind that it is duty of states, regardless of political, economic and cultural systems, to promote and protect all human rights and fundamental freedoms.
<G-vec00276-001-s023><promote.befördern><de> Innerhalb von bis zu drei Bedürfnisfeldern sollen Politikinstrumente gesammelt, analysiert und entwickelt werden, die Suffizienz befördern.
<G-vec00276-001-s023><promote.befördern><en> In up to three need areas, political instruments that promote sufficiency will be collected, analyzed and developed.
<G-vec00276-001-s024><promote.befördern><de> "Andere Supplemente befördern eine lange Liste von Elemente in dem Versuch ""etwas mehr"" zu bieten."
<G-vec00276-001-s024><promote.befördern><en> Other supplements promote a long list of elements in an attempt to offer something 'more'.
<G-vec00276-001-s025><promote.befördern><de> Letztlich befördern auf der Ebene von Gesellschaften interne und externe Einflüsse den sozialen Wandel, etwa im Zuge von Gesetzgebungen oder nationalen wie internationalen politischen Entwicklungen.
<G-vec00276-001-s025><promote.befördern><en> Ultimately, internal and external influences promote social change at the level of societies, for example in the course of legislation or national and international political developments.
<G-vec00276-001-s026><promote.befördern><de> Handelsabkommen sollten wirtschaftliche und soziale Entwicklung in den Partnerländern befördern.
<G-vec00276-001-s026><promote.befördern><en> Trade agreements should promote the economic and social development of partner countries.
<G-vec00276-001-s027><promote.befördern><de> Der Sand an der Westseite bietet Schutz und soll das Pflanzenwachstum befördern.
<G-vec00276-001-s027><promote.befördern><en> The sand on the west side offers protection and should promote growth.
<G-vec00276-001-s028><promote.befördern><de> Aus Sicht der Panelisten besitzt sie großes Potenzial, um nicht nur das Bildungsziel 4, sondern alle Ziele der Agenda 2030 zu befördern.
<G-vec00276-001-s028><promote.befördern><en> From the point of view of the panelists, it has enormous potential to promote not only educational Goal 4, but all the goals of the 2030 Agenda.
<G-vec00276-001-s029><promote.befördern><de> Vor Bekanntwerden der Agenda für die im Dezember beginnende deutsche G20-Präsidentschaft will die ungewöhnliche Allianz aus Wirtschaftsverband, Umweltorganisation und Forschungsinstitut so ambitionierten Klimaschutz, Planungssicherheit, fairen Wettbewerb und notwendige Investitionen befördern.
<G-vec00276-001-s029><promote.befördern><en> The unusual alliance between an industry association, an environmental organization and a research institute seeks to drive ambitious climate protection, create more predictability for planning, promote fair competition and secure the necessary investments.
<G-vec00276-001-s030><promote.befördern><de> "Das KIT hat als eine der ersten Forschungseinrichtungen den Zuschlag zum neuen Förderprogramm ""Open Access Publizieren"" der Deutschen Forschungsgemeinschaft erhalten, das nachhaltige Strukturen der modernen Wissenschaftskommunikation befördern soll."
<G-vec00276-001-s030><promote.befördern><en> KIT was among the first research organisations to be awarded funding under the DFG's new Open Access Publishing programme, which aims to promote sustainable modern scholarly communication structures.
<G-vec00276-001-s031><promote.befördern><de> "Quests: Die Quest ""Einen Herzog befördern"" verschwindet nun, wenn ein König inaktiv wird und später als Statthalter wiederkehrt."
<G-vec00276-001-s031><promote.befördern><en> "Quests: The quest ""Promote a duke"" will disappear if a king becomes inactive and later returns as a governor."
<G-vec00276-001-s032><promote.befördern><de> Die Talentstrategie von Kautex ist einfach: Unsere Mitarbeiter entwickeln und intern befördern.
<G-vec00276-001-s032><promote.befördern><en> Kautex's talent strategy is simple: develop our people and promote from within.
<G-vec00276-001-s033><promote.befördern><de> Wer gegendemonstriert, fordert die Einschränkung des uneingeschränkten Wanderns der Anderen, um die Einwanderung zu befördern, oder eben einfach nur zu verhindern, dass sie eingeschränkt wird.
<G-vec00276-001-s033><promote.befördern><en> Whoever demonstrates against it demands restriction of unrestricted migration of others in order to promote immigration or simply to prevent its being restricted.
<G-vec00276-001-s034><promote.befördern><de> In den frühen 70er Jahren kehrte Saadetin Erkan, geboren in Hacilar, der in Ankara Ingenieurswesen studiert hatte, mit der Idee zurück, die Ressourcen der einzelnen Haushalte zusammenzulegen, um industrielle Entwicklung zu befördern.
<G-vec00276-001-s034><promote.befördern><en> The ethic of self-help and cooperation lies at the origins of Hacilar's economic miracle. In the early 1970s, one local son, Saadetin Erkan, who had studied engineering in Ankara, returned to the community with the idea of pooling household resources from the village to promote industrial development.
<G-vec00276-001-s035><promote.befördern><de> Solche ungedeckten Schecks wecken Erwartungen, die sie nicht einlösen können, und sie befördern die Neigung des Menschen, fromme Erwartungen für realer zu halten als ein ausgeprägtes Realitätsbewusstsein.
<G-vec00276-001-s035><promote.befördern><en> These foul cheques rouse expectations they cannot deliver, and they also promote the tendency of humans to consider pious expectations more real than a solid perception of reality.
<G-vec00276-001-s036><promote.befördern><de> Das IKI-Projekt kann je nach Bedarf Länder unterstützen, die für sie passende Lösung zu finden und im Anschluss deren rechtlich-institutionelle Umsetzung befördern.
<G-vec00276-001-s036><promote.befördern><en> Depending on their needs, the IKI project can help countries find solutions that work for them and then promote legal and institutional implementation.
<G-vec00276-001-s037><promote.befördern><de> Das wird sicher alte Industrien schädigen – aber neue befördern – denn Innovation ist nun halt mal zu aller Erst kreative Zerstörung.
<G-vec00276-001-s037><promote.befördern><en> But it will also promote new ones. Because, as we all know, the first step towards innovation is the destruction of old things.
<G-vec00241-002-s114><carry.befördern><de> Früher haben sie einen offenen Brunnen benutzt, und mussten das Trinkwasser mit Kanus befördern.
<G-vec00241-002-s114><carry.befördern><en> In former times they used an open pond, from which they had to carry their drinking water in canoa.
<G-vec00241-002-s115><carry.befördern><de> Die maximale einmalige Menge, die wir für Sie befördern, beträgt 24 Tonnen Material.
<G-vec00241-002-s115><carry.befördern><en> The maximum one-time batch we will carry for you is 24 tons of material.
<G-vec00241-002-s116><carry.befördern><de> Der menschliche Körper enthält verschiedene Kreisläufe, welche Substanzen befördern, die lebenswichtig sind.
<G-vec00241-002-s116><carry.befördern><en> The human body is comprised of several different circulatory systems which carry substances vital for survival.
<G-vec00241-002-s117><carry.befördern><de> Unsere Getriebe werden entwickelt, um mehr Tonnen Ladung pro Liter Kraftstoff zu befördern und Ihnen die Möglichkeit zu geben, je nach Fahrbedingungen zwischen unterschiedlichen Betriebsarten zu wählen.
<G-vec00241-002-s117><carry.befördern><en> Allison Automatics are designed to carry more tonnage per gallon/liter of fuel and give you a choice of operating modes to best suit your driving conditions.
<G-vec00241-002-s118><carry.befördern><de> Der Aluminium Taschenhaken bietet Dir eine sichere Möglichkeit Deine Einkaufstasche oder Handtasche zu befördern, ohne auf anderen wertvollen Stauraum zurück zugreifen.
<G-vec00241-002-s118><carry.befördern><en> The aluminium bag hook offers you a safe way to carry your shopping bag or handbag without having to access other valuable storage space.
<G-vec00241-002-s119><carry.befördern><de> Bei der Buchung und beim Check-in der Flüge mit Aeroflot PJSC muss der Passagier angeben, dass er beabsichtigt, Waffen im Gepäck zu befördern.
<G-vec00241-002-s119><carry.befördern><en> When booking and checking in for Aeroflot PJSC flights, the passenger must declare his/her intention to carry weapons as baggage.
<G-vec00241-002-s121><carry.befördern><de> Beim “Sommerliftln” befördern euch 24 Bergbahnen der familienfreundlichen Region zu Ausgangspunkten für Wanderungen, Mountainbike-Touren und lustigen Sommerrodel-Partien.
<G-vec00241-002-s121><carry.befördern><en> The 24 “summer lifts” of the family-friendly region carry you to the starting points of hiking trips, mountain bike tours, and joyful summer toboggan runs.
<G-vec00241-002-s122><carry.befördern><de> Wir befördern Sie Hin und holen Sie auch gerne wieder ab.
<G-vec00241-002-s122><carry.befördern><en> We carry you to the airport and also pick you up again.
<G-vec00241-002-s123><carry.befördern><de> An Subduktionszonen sinken Platten ozeanischer Lithosphäre in den Erdmantel und befördern basaltische Erdkruste und in Mineralen gespeichertes Wasser ins Erdinnere.
<G-vec00241-002-s123><carry.befördern><en> At subduction zones, slabs of oceanic lithosphere sink into the mantle and carry basaltic crust and H2O stored in hydrous minerals into Earth’s interior.
<G-vec00241-002-s124><carry.befördern><de> 45 moderne Bergbahnen befördern Sie schnell und komfortabel von Gipfel zu Gipfel.
<G-vec00241-002-s124><carry.befördern><en> 45 modern mountain railways carry you fast and comfortable from summit to summit.
<G-vec00241-002-s125><carry.befördern><de> (d) Auf Flügen von/nach Großbritannien kann TUIfly auf Grund der strengen gesetzlichen Vorschriften keine Tiere befördern.
<G-vec00241-002-s125><carry.befördern><en> (d) TUIfly is unable to carry any animals on flights to and from the UK, owing to the country’s strict statutory requirements.
<G-vec00241-002-s126><carry.befördern><de> Somit entsteht ein Monorail-System mit der höchsten Transportdichte der Welt, welches bis zu 48.000 Passagiere pro Stunde in zwei Richtungen befördern wird.
<G-vec00241-002-s126><carry.befördern><en> Thus, a monorail system with the highest transportation density of the world is being created, which will carry up to 48,000 passengers per hour in two directions.
<G-vec00241-002-s127><carry.befördern><de> Es hatte eine aerodynamische Karosserie und konnte 42 Passagiere befördern.
<G-vec00241-002-s127><carry.befördern><en> It had an aerodynamic body and could carry 42 passengers.
<G-vec00241-002-s128><carry.befördern><de> Über 1 Million Privat- und Geschäftskunden befördern wir jährlich zu den attraktivsten Reisezielen innerhalb Europas.
<G-vec00241-002-s128><carry.befördern><en> Each year we carry more than one million private and corporate customers to the most attractive destinations throughout Europe!
<G-vec00241-002-s129><carry.befördern><de> 8.4.1 Vorbehaltlich Artikel 8.3.2 und 8.3.3 werden wir uns weigern, die in Artikel 8.3 beschriebenen Gegenstände als Gepäck zu befördern und können uns auch nach Entdeckung weigern, diese Gegenstände weiter als Gepäck zu befördern.
<G-vec00241-002-s129><carry.befördern><en> 8.4.1 Subject to Articles 8.3.2 and 8.3.3, we will refuse to carry as Baggage the items described in Article 8.3, and we may refuse further carriage of any such items upon discovery.
<G-vec00241-002-s131><carry.befördern><de> IEEE untersucht jetzt Methoden, Wave Division Multiplexing-Technologie (WDM) einzusetzen, mit der mehrfache Wellenlängen über die gleiche Glasfaser Signale befördern können, mit dem Potential, 100 Gbit/s über ein Glasfaserpaar zu übertragen, wobei jede Faser 25 Gbit/s auf vier verschiedenen Wellenlängen überträgt.
<G-vec00241-002-s131><carry.befördern><en> IEEE is now looking at ways to use wave division multiplexing (WDM) technology that will allow multiple wavelengths over the same fiber to carry signals, providing the potential to transmit 100 Gbps over a fiber pair where each fiber carries 25 Gbps on four different wavelengths.
<G-vec00241-002-s132><carry.befördern><de> Wir haben Höchstmaße und -gewicht für Gepäck festgelegt, das Sie in unserem Flugzeug befördern können.
<G-vec00241-002-s132><carry.befördern><en> We have specified maximum dimensions and weight for Baggage that you carry on to our aircraft.
<G-vec00276-002-s019><promote.befördern><de> Das optionale Studienprofil „Kreation & Innovation“ vermittelt Ihnen über drei Semester in aufeinander abgestimmten Modulen umfassende Kompetenzen, um kreative Prozesse zu verstehen und selbst befördern zu können.
<G-vec00276-002-s019><promote.befördern><en> This study profile teaches you comprehensive competencies over the course of three semesters in coordinated modules, in order to understand creative processes and to promote them yourself.
<G-vec00276-002-s020><promote.befördern><de> Sobald alles vorbei ist, bin ich trotzdem bereit, Sie zum Direktor des neu gebauten Standort-19 zu befördern, natürlich nachdem Sie sich etwas erholt haben.
<G-vec00276-002-s020><promote.befördern><en> Regardless, once this is all over, I'm prepared to promote you to Director of the newly constructed Site 19, after you've taken some time to recuperate, of course.
<G-vec00276-002-s021><promote.befördern><de> Ein eigens dafür eingerichtetes Cluster bringt regelmäßig Akteure aus Wirtschaft, Wissenschaft und Zivilgesellschaft zusammen, um den Wissenstransfer zwischen Verwaltung, Politik und Marktteilnehmern zu befördern.
<G-vec00276-002-s021><promote.befördern><en> A specially equipped cluster regularly brings together stakeholders from industry, science and civil society in order to promote knowledge transfer between the government, politics and market participants.
<G-vec00276-002-s022><promote.befördern><de> Der Einfluss strategischer Kulturen kann den Aufbau kooperativer Sicherheitsstrukturen befördern oder ihm entgegenwirken.
<G-vec00276-002-s022><promote.befördern><en> The influence of strategic cultures can promote the development of cooperative security structures or counteract it.
<G-vec00276-002-s023><promote.befördern><de> Die Inhalte der Partnerschaftsabkommen zeigen, dass es vorrangig darum geht, investitionsfreundliche politische Rahmenbedingungen in afrikanischen Ländern zu schaffen und Investitionen der Privatwirtschaft zu befördern.
<G-vec00276-002-s023><promote.befördern><en> The contents of the partnership agreements show that the predominant aim is to create conditions in African countries that are conducive to investment and to promote private-sector investment.
<G-vec00276-002-s024><promote.befördern><de> Um diese Möglichkeiten zu befördern, findet an der Cologne Business School seit Jahren das so genannte New Students Integeration Programme statt, in dessen Rahmen die Studenten des neuen Jahrgangs von älteren Kommilitonen empfangen und bei Team-Herausforderungen begleitet werden.
<G-vec00276-002-s024><promote.befördern><en> To promote such opportunities, programs like the New Students Integration have taken place at the Cologne Business School for years, where incoming freshmen are welcomed by upper classmates, who accompany them through team challenges.
<G-vec00276-002-s025><promote.befördern><de> Es werden alle notwendigen Mittel zu Verfügung gestellt, so dass die Gesamtheit der Bevölkerung der katalanischen Gesellschaft die vollständige Information und die genaue Kenntnis erhält, die zur Ausübung des Entscheidungsrechts nötig sind und die sie zur Teilnahme am Entscheidungsprozess befördern.
<G-vec00276-002-s025><promote.befördern><en> All the necessary tools will be enabled so that the whole of the population and all of Catalan society have all of the information and knowledge regarding the right to decide process, and to promote their participation in the process. -Dialogue.
<G-vec00276-002-s026><promote.befördern><de> Massendemonstrationen und Aufstände sind Beispiele dafür, wie Gruppendruck eingesetzt werden kann, um Böses zu befördern.
<G-vec00276-002-s026><promote.befördern><en> Mass demonstrations and riots are examples of how group pressure can be used to promote what is evil.
<G-vec00276-002-s027><promote.befördern><de> EINMALIG – Befördern: Erhöht die Stärke eines Lanevasallen drastisch und gewährt ihm Immunität gegen magischen Schaden (120 Sekunden Abklingzeit) (Reichweite: 1200 Einheiten).
<G-vec00276-002-s027><promote.befördern><en> Unique – Promote: Greatly increases the power of a lane minion and grants it immunity to magic damage (120 second cooldown) (1200 range). Recipe
<G-vec00276-002-s028><promote.befördern><de> Mitglieder der Zunft sind durch besondere Verpflichtungen (Bande) verbunden, Frieden zu befördern, Eintracht zu pflegen, und in Einigkeit und Bruderliebe zu leben.
<G-vec00276-002-s028><promote.befördern><en> Craftsmen are bound by peculiar ties to promote peace, cultivate harmony, and live in concord and brotherly love.
<G-vec00276-002-s029><promote.befördern><de> Wir befördern den Fang und lassen ihn wieder frei.
<G-vec00276-002-s029><promote.befördern><en> We promote catch and release.
<G-vec00276-002-s030><promote.befördern><de> Die Gastprofessur soll dazu dienen, die Frauen- und Geschlechterforschung in Profilbereichen der Freien Universität zu stärken und ihre internationale Vernetzung zu befördern, Forschung und Lehre im Bereich der interdisziplinären Geschlechterforschung zu internationalisieren und zu verbessern.
<G-vec00276-002-s030><promote.befördern><en> The Dahlem International Network Professorship for Gender Studies aims to strengthen gender studies within the key research focus areas of the Freie Universität Berlin and to promote international and interdisciplinary gender studies research.
<G-vec00276-002-s031><promote.befördern><de> 5) Den Gebrauch des Katechismus der Katholischen Kirche zu befördern, der für die Menschen unserer Zeit die Gesamtheit des Glaubens wesentlich und vollständig zusammenfaßt.
<G-vec00276-002-s031><promote.befördern><en> 5) To promote the use of the Catechism of the Catholic Church, as essential and complete formulation of the content of the faith for the men and women of our time.
<G-vec00276-002-s032><promote.befördern><de> Seine wichtigste These lautet, dass Internet und moderne Technologien eben nicht nur Freiheit und Demokratie befördern, sondern gleichzeitig Werkzeuge für Repressionen und Massenüberwachung sind.
<G-vec00276-002-s032><promote.befördern><en> His most important thesis argues that the internet and modern technology don’t just only promote freedom and democracy but are also tools for repression and mass surveillance.
<G-vec00276-002-s033><promote.befördern><de> Die Netzwerke betreiben strategische Forschung, befördern Interdisziplinarität in Themen, Projekten und Methoden, machen den jeweiligen Standort sichtbar und stärken sein Forschungsprofil.
<G-vec00276-002-s033><promote.befördern><en> The networks conduct strategic research, promote interdisciplinarity in topics, projects and methods, make the respective location visible and strengthen its research profile.
<G-vec00276-002-s034><promote.befördern><de> Sie können Einheiten auswählen, zuordnen und befördern und Sie können mehrere Tausend Soldaten mit verschiedenen Charakteristiken ausstatten.
<G-vec00276-002-s034><promote.befördern><en> You can choose, assign, promote and award up to several thousand people with various characteristics.
<G-vec00276-002-s035><promote.befördern><de> Es ist so einfach, jemandem einen Titel zu verleihen und/oder ihn zu befördern.
<G-vec00276-002-s035><promote.befördern><en> It’s so easy to assign a title to someone and/or promote him.
<G-vec00276-002-s036><promote.befördern><de> Im Fokus steht die Frage, inwiefern der Erfahrungshintergrund einer Migration Abläufe und Strukturen in den Einrichtungen beeinflusst und inwiefern eine interkulturelle Öffnung die Teilhabe von (Post-) Migrantinnen und Migranten befördern kann.
<G-vec00276-002-s036><promote.befördern><en> The focus is on the question to what extent the experience background of a migration influences processes and structures in the institutions and to what extent an intercultural opening can promote the participation of (post) migrants.
<G-vec00276-002-s037><promote.befördern><de> Am zweiten Tag hatten die Teilnehmenden Gelegenheit, vier Praxisbeispiele der Partnerorganisationen von DVV kennenzulernen und die Frage zu vertiefen, wie Erwachsenbildung als treibende Kraft die Umsetzung der verschiedenen Ziele der Agenda 2030 befördern kann.
<G-vec00276-002-s037><promote.befördern><en> On the second day, the participants had the opportunity to get to know four practical examples from the partner organisations of DVV International in Quito, and to delve into the question of how adult education, as a driving force, can promote the implementation of the various goals of the 2030 Agenda.
<G-vec00261-003-s114><carry_on.befördern><de> Früher haben sie einen offenen Brunnen benutzt, und mussten das Trinkwasser mit Kanus befördern.
<G-vec00261-003-s114><carry_on.befördern><en> In former times they used an open pond, from which they had to carry their drinking water in canoa.
<G-vec00261-003-s115><carry_on.befördern><de> Die maximale einmalige Menge, die wir für Sie befördern, beträgt 24 Tonnen Material.
<G-vec00261-003-s115><carry_on.befördern><en> The maximum one-time batch we will carry for you is 24 tons of material.
<G-vec00261-003-s116><carry_on.befördern><de> Der menschliche Körper enthält verschiedene Kreisläufe, welche Substanzen befördern, die lebenswichtig sind.
<G-vec00261-003-s116><carry_on.befördern><en> The human body is comprised of several different circulatory systems which carry substances vital for survival.
<G-vec00261-003-s117><carry_on.befördern><de> Unsere Getriebe werden entwickelt, um mehr Tonnen Ladung pro Liter Kraftstoff zu befördern und Ihnen die Möglichkeit zu geben, je nach Fahrbedingungen zwischen unterschiedlichen Betriebsarten zu wählen.
<G-vec00261-003-s117><carry_on.befördern><en> Allison Automatics are designed to carry more tonnage per gallon/liter of fuel and give you a choice of operating modes to best suit your driving conditions.
<G-vec00261-003-s118><carry_on.befördern><de> Der Aluminium Taschenhaken bietet Dir eine sichere Möglichkeit Deine Einkaufstasche oder Handtasche zu befördern, ohne auf anderen wertvollen Stauraum zurück zugreifen.
<G-vec00261-003-s118><carry_on.befördern><en> The aluminium bag hook offers you a safe way to carry your shopping bag or handbag without having to access other valuable storage space.
<G-vec00261-003-s119><carry_on.befördern><de> Bei der Buchung und beim Check-in der Flüge mit Aeroflot PJSC muss der Passagier angeben, dass er beabsichtigt, Waffen im Gepäck zu befördern.
<G-vec00261-003-s119><carry_on.befördern><en> When booking and checking in for Aeroflot PJSC flights, the passenger must declare his/her intention to carry weapons as baggage.
<G-vec00261-003-s120><carry_on.befördern><de> Mit dem Ziehwagen können Sie auf einfache Weise die Untensilien und das Essen für den Tag befördern.
<G-vec00261-003-s120><carry_on.befördern><en> With the pull cart can carry easily the utensils and the food for the day.
<G-vec00261-003-s121><carry_on.befördern><de> Beim “Sommerliftln” befördern euch 24 Bergbahnen der familienfreundlichen Region zu Ausgangspunkten für Wanderungen, Mountainbike-Touren und lustigen Sommerrodel-Partien.
<G-vec00261-003-s121><carry_on.befördern><en> The 24 “summer lifts” of the family-friendly region carry you to the starting points of hiking trips, mountain bike tours, and joyful summer toboggan runs.
<G-vec00261-003-s122><carry_on.befördern><de> Wir befördern Sie Hin und holen Sie auch gerne wieder ab.
<G-vec00261-003-s122><carry_on.befördern><en> We carry you to the airport and also pick you up again.
<G-vec00261-003-s123><carry_on.befördern><de> An Subduktionszonen sinken Platten ozeanischer Lithosphäre in den Erdmantel und befördern basaltische Erdkruste und in Mineralen gespeichertes Wasser ins Erdinnere.
<G-vec00261-003-s123><carry_on.befördern><en> At subduction zones, slabs of oceanic lithosphere sink into the mantle and carry basaltic crust and H2O stored in hydrous minerals into Earth’s interior.
<G-vec00261-003-s124><carry_on.befördern><de> 45 moderne Bergbahnen befördern Sie schnell und komfortabel von Gipfel zu Gipfel.
<G-vec00261-003-s124><carry_on.befördern><en> 45 modern mountain railways carry you fast and comfortable from summit to summit.
<G-vec00261-003-s125><carry_on.befördern><de> (d) Auf Flügen von/nach Großbritannien kann TUIfly auf Grund der strengen gesetzlichen Vorschriften keine Tiere befördern.
<G-vec00261-003-s125><carry_on.befördern><en> (d) TUIfly is unable to carry any animals on flights to and from the UK, owing to the country’s strict statutory requirements.
<G-vec00261-003-s126><carry_on.befördern><de> Somit entsteht ein Monorail-System mit der höchsten Transportdichte der Welt, welches bis zu 48.000 Passagiere pro Stunde in zwei Richtungen befördern wird.
<G-vec00261-003-s126><carry_on.befördern><en> Thus, a monorail system with the highest transportation density of the world is being created, which will carry up to 48,000 passengers per hour in two directions.
<G-vec00261-003-s127><carry_on.befördern><de> Es hatte eine aerodynamische Karosserie und konnte 42 Passagiere befördern.
<G-vec00261-003-s127><carry_on.befördern><en> It had an aerodynamic body and could carry 42 passengers.
<G-vec00261-003-s128><carry_on.befördern><de> Über 1 Million Privat- und Geschäftskunden befördern wir jährlich zu den attraktivsten Reisezielen innerhalb Europas.
<G-vec00261-003-s128><carry_on.befördern><en> Each year we carry more than one million private and corporate customers to the most attractive destinations throughout Europe!
<G-vec00261-003-s129><carry_on.befördern><de> 8.4.1 Vorbehaltlich Artikel 8.3.2 und 8.3.3 werden wir uns weigern, die in Artikel 8.3 beschriebenen Gegenstände als Gepäck zu befördern und können uns auch nach Entdeckung weigern, diese Gegenstände weiter als Gepäck zu befördern.
<G-vec00261-003-s129><carry_on.befördern><en> 8.4.1 Subject to Articles 8.3.2 and 8.3.3, we will refuse to carry as Baggage the items described in Article 8.3, and we may refuse further carriage of any such items upon discovery.
<G-vec00261-003-s130><carry_on.befördern><de> Güter oder Personen zu befördern, ohne hierfür die erforderlichen Genehmigungen vorliegen zu haben.
<G-vec00261-003-s130><carry_on.befördern><en> To carry persons or goods without having obtained the corresponding official permits.
<G-vec00261-003-s131><carry_on.befördern><de> IEEE untersucht jetzt Methoden, Wave Division Multiplexing-Technologie (WDM) einzusetzen, mit der mehrfache Wellenlängen über die gleiche Glasfaser Signale befördern können, mit dem Potential, 100 Gbit/s über ein Glasfaserpaar zu übertragen, wobei jede Faser 25 Gbit/s auf vier verschiedenen Wellenlängen überträgt.
<G-vec00261-003-s131><carry_on.befördern><en> IEEE is now looking at ways to use wave division multiplexing (WDM) technology that will allow multiple wavelengths over the same fiber to carry signals, providing the potential to transmit 100 Gbps over a fiber pair where each fiber carries 25 Gbps on four different wavelengths.
<G-vec00261-003-s132><carry_on.befördern><de> Wir haben Höchstmaße und -gewicht für Gepäck festgelegt, das Sie in unserem Flugzeug befördern können.
<G-vec00261-003-s132><carry_on.befördern><en> We have specified maximum dimensions and weight for Baggage that you carry on to our aircraft.
<G-vec00316-003-s114><carry_out.befördern><de> Früher haben sie einen offenen Brunnen benutzt, und mussten das Trinkwasser mit Kanus befördern.
<G-vec00316-003-s114><carry_out.befördern><en> In former times they used an open pond, from which they had to carry their drinking water in canoa.
<G-vec00316-003-s115><carry_out.befördern><de> Die maximale einmalige Menge, die wir für Sie befördern, beträgt 24 Tonnen Material.
<G-vec00316-003-s115><carry_out.befördern><en> The maximum one-time batch we will carry for you is 24 tons of material.
<G-vec00316-003-s116><carry_out.befördern><de> Der menschliche Körper enthält verschiedene Kreisläufe, welche Substanzen befördern, die lebenswichtig sind.
<G-vec00316-003-s116><carry_out.befördern><en> The human body is comprised of several different circulatory systems which carry substances vital for survival.
<G-vec00316-003-s117><carry_out.befördern><de> Unsere Getriebe werden entwickelt, um mehr Tonnen Ladung pro Liter Kraftstoff zu befördern und Ihnen die Möglichkeit zu geben, je nach Fahrbedingungen zwischen unterschiedlichen Betriebsarten zu wählen.
<G-vec00316-003-s117><carry_out.befördern><en> Allison Automatics are designed to carry more tonnage per gallon/liter of fuel and give you a choice of operating modes to best suit your driving conditions.
<G-vec00316-003-s118><carry_out.befördern><de> Der Aluminium Taschenhaken bietet Dir eine sichere Möglichkeit Deine Einkaufstasche oder Handtasche zu befördern, ohne auf anderen wertvollen Stauraum zurück zugreifen.
<G-vec00316-003-s118><carry_out.befördern><en> The aluminium bag hook offers you a safe way to carry your shopping bag or handbag without having to access other valuable storage space.
<G-vec00316-003-s119><carry_out.befördern><de> Bei der Buchung und beim Check-in der Flüge mit Aeroflot PJSC muss der Passagier angeben, dass er beabsichtigt, Waffen im Gepäck zu befördern.
<G-vec00316-003-s119><carry_out.befördern><en> When booking and checking in for Aeroflot PJSC flights, the passenger must declare his/her intention to carry weapons as baggage.
<G-vec00316-003-s120><carry_out.befördern><de> Mit dem Ziehwagen können Sie auf einfache Weise die Untensilien und das Essen für den Tag befördern.
<G-vec00316-003-s120><carry_out.befördern><en> With the pull cart can carry easily the utensils and the food for the day.
<G-vec00316-003-s121><carry_out.befördern><de> Beim “Sommerliftln” befördern euch 24 Bergbahnen der familienfreundlichen Region zu Ausgangspunkten für Wanderungen, Mountainbike-Touren und lustigen Sommerrodel-Partien.
<G-vec00316-003-s121><carry_out.befördern><en> The 24 “summer lifts” of the family-friendly region carry you to the starting points of hiking trips, mountain bike tours, and joyful summer toboggan runs.
<G-vec00316-003-s122><carry_out.befördern><de> Wir befördern Sie Hin und holen Sie auch gerne wieder ab.
<G-vec00316-003-s122><carry_out.befördern><en> We carry you to the airport and also pick you up again.
<G-vec00316-003-s123><carry_out.befördern><de> An Subduktionszonen sinken Platten ozeanischer Lithosphäre in den Erdmantel und befördern basaltische Erdkruste und in Mineralen gespeichertes Wasser ins Erdinnere.
<G-vec00316-003-s123><carry_out.befördern><en> At subduction zones, slabs of oceanic lithosphere sink into the mantle and carry basaltic crust and H2O stored in hydrous minerals into Earth’s interior.
<G-vec00316-003-s124><carry_out.befördern><de> 45 moderne Bergbahnen befördern Sie schnell und komfortabel von Gipfel zu Gipfel.
<G-vec00316-003-s124><carry_out.befördern><en> 45 modern mountain railways carry you fast and comfortable from summit to summit.
<G-vec00316-003-s125><carry_out.befördern><de> (d) Auf Flügen von/nach Großbritannien kann TUIfly auf Grund der strengen gesetzlichen Vorschriften keine Tiere befördern.
<G-vec00316-003-s125><carry_out.befördern><en> (d) TUIfly is unable to carry any animals on flights to and from the UK, owing to the country’s strict statutory requirements.
<G-vec00316-003-s126><carry_out.befördern><de> Somit entsteht ein Monorail-System mit der höchsten Transportdichte der Welt, welches bis zu 48.000 Passagiere pro Stunde in zwei Richtungen befördern wird.
<G-vec00316-003-s126><carry_out.befördern><en> Thus, a monorail system with the highest transportation density of the world is being created, which will carry up to 48,000 passengers per hour in two directions.
<G-vec00316-003-s127><carry_out.befördern><de> Es hatte eine aerodynamische Karosserie und konnte 42 Passagiere befördern.
<G-vec00316-003-s127><carry_out.befördern><en> It had an aerodynamic body and could carry 42 passengers.
<G-vec00316-003-s128><carry_out.befördern><de> Über 1 Million Privat- und Geschäftskunden befördern wir jährlich zu den attraktivsten Reisezielen innerhalb Europas.
<G-vec00316-003-s128><carry_out.befördern><en> Each year we carry more than one million private and corporate customers to the most attractive destinations throughout Europe!
<G-vec00316-003-s129><carry_out.befördern><de> 8.4.1 Vorbehaltlich Artikel 8.3.2 und 8.3.3 werden wir uns weigern, die in Artikel 8.3 beschriebenen Gegenstände als Gepäck zu befördern und können uns auch nach Entdeckung weigern, diese Gegenstände weiter als Gepäck zu befördern.
<G-vec00316-003-s129><carry_out.befördern><en> 8.4.1 Subject to Articles 8.3.2 and 8.3.3, we will refuse to carry as Baggage the items described in Article 8.3, and we may refuse further carriage of any such items upon discovery.
<G-vec00316-003-s130><carry_out.befördern><de> Güter oder Personen zu befördern, ohne hierfür die erforderlichen Genehmigungen vorliegen zu haben.
<G-vec00316-003-s130><carry_out.befördern><en> To carry persons or goods without having obtained the corresponding official permits.
<G-vec00316-003-s131><carry_out.befördern><de> IEEE untersucht jetzt Methoden, Wave Division Multiplexing-Technologie (WDM) einzusetzen, mit der mehrfache Wellenlängen über die gleiche Glasfaser Signale befördern können, mit dem Potential, 100 Gbit/s über ein Glasfaserpaar zu übertragen, wobei jede Faser 25 Gbit/s auf vier verschiedenen Wellenlängen überträgt.
<G-vec00316-003-s131><carry_out.befördern><en> IEEE is now looking at ways to use wave division multiplexing (WDM) technology that will allow multiple wavelengths over the same fiber to carry signals, providing the potential to transmit 100 Gbps over a fiber pair where each fiber carries 25 Gbps on four different wavelengths.
<G-vec00316-003-s132><carry_out.befördern><de> Wir haben Höchstmaße und -gewicht für Gepäck festgelegt, das Sie in unserem Flugzeug befördern können.
<G-vec00316-003-s132><carry_out.befördern><en> We have specified maximum dimensions and weight for Baggage that you carry on to our aircraft.
