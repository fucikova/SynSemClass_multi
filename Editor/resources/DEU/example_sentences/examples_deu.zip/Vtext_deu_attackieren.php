<G-vec00441-001-s361><attack.attackieren><de> Rasend erzürnt, attackieren und bedrohen sie.
<G-vec00441-001-s361><attack.attackieren><en> Furiously enraged, they attack and threaten.
<G-vec00441-001-s362><attack.attackieren><de> Jakes Dungeon Stein spielen, W verwenden,A,S,D-Tasten zu bewegen, Maus zu zielen, klicken Sie links zu attackieren, der rechten Maustaste, um Geschicklichkeit, Leertaste, um zu rollen, Q-Taste, um Waffen zu wechseln, E-Taste zum Handeln, 1 Schlüssel für die Sandwich-und M-Taste, um die Karte zu verwenden.
<G-vec00441-001-s362><attack.attackieren><en> To play Jake's Dungeon Stone, use W,A,S,D keys to move, mouse to aim, left click to attack, right click to use skill, SPACEBAR to roll, Q key to switch weapon, E key to action, 1 key for sandwich and M key to use map.
<G-vec00441-001-s363><attack.attackieren><de> Ein langes, sehr schweres Par 4, das vor allem den sehr guten Golfer, der das Grün mit dem zweiten Schlag attackieren muss, in tiefe Verzweiflung stürzen wird, wenn ihm nicht zwei perfekte Golfschläge gelingen.
<G-vec00441-001-s363><attack.attackieren><en> A long, very difficult par 4, especially for very good golfers who must attack the green with the second shot and who will plunge into great distress if they do not succeed in making two perfect shots.
<G-vec00441-001-s364><attack.attackieren><de> Die Conyers Gesetzentwurf schlägt vor, dieses Problem auf zwei Wegen zu attackieren.
<G-vec00441-001-s364><attack.attackieren><en> The Conyers bill proposes to attack this problem in two ways.
<G-vec00441-001-s365><attack.attackieren><de> Jin Youfeng kooperierte nicht mit seinen Verfolgern und der Wärter Zhou Shaokun befahl dem Häftling Liu Daqing und weiteren Gefangenen, ihn barbarisch zu attackieren.
<G-vec00441-001-s365><attack.attackieren><en> Jin Youfeng did not cooperate with the perpetrators, and guard Zhou Shaokun ordered inmates Liu Daqing and others to barbarically attack him.
<G-vec00441-001-s366><attack.attackieren><de> Befehligen Sie Ihre Truppen feindliche Kontrollpunkte zu attackieren.
<G-vec00441-001-s366><attack.attackieren><en> Command your troops to attack enemy control points.
<G-vec00441-001-s367><attack.attackieren><de> Scavengers sind die einzigen Zombies mit der Fähigkeit, aus der Entfernung zu attackieren.
<G-vec00441-001-s367><attack.attackieren><en> Scavengers are the only zombies with the ability to attack from a distance.
<G-vec00441-001-s368><attack.attackieren><de> Kein schädlicher Code wird das sichere Spam-Filter-System zu attackieren.
<G-vec00441-001-s368><attack.attackieren><en> No malicious code will attack our secure spam filtering system.
<G-vec00441-001-s369><attack.attackieren><de> "Sie sagten: ""Du bist der Anführer bei der Organisierung, das Gericht zu attackieren."
<G-vec00441-001-s369><attack.attackieren><en> "They said, ""You are the head organising this, to attack the court."
<G-vec00441-001-s370><attack.attackieren><de> Man kann die Aggression zurückweisen und sie attackieren, aber den Krieg gegen die israelisch-zionistische Aggression müssen die arabischen Staaten selbst führen.
<G-vec00441-001-s370><attack.attackieren><en> It is possible to refute the aggression and attack it, but the war against the Israeli-Zionist aggression must be lead by the Arab states themselves.
<G-vec00441-001-s371><attack.attackieren><de> Während die chinesischen Führer, angefangen bei Mao Tsetung Schwankungen und Tendenzen zur Bildung einer Einheitsfront mit den Chruschtschow-Breschnew-Revisionisten erkennen lassen und sich mit den jugoslawischen, polnischen, spanischen und anderen Revisionisten vereinigen und küssen, lassen sie keine Gelegenheit verstreichen, um J. Stalin, diesen großen Marxisten-Leninisten, den treuen Schüler und Fortsetzer des Werkes Lenins zu attackieren und zu verunglimpfen.
<G-vec00441-001-s371><attack.attackieren><en> And in fact, while they show vacillations and inclinations towards a common front with the Khrushchevite-Brezhnevite revisionists, while they make up and kiss with Yugoslav, Polish, Spanish and other revisionists, the Chinese revisionists, beginning with Mao Tsetung, leave no opportunity unused to attack and vilify J. V. Stalin, the great Marxist-Leninist, the disciple and faithful continuer of the work of Lenin.
<G-vec00441-001-s372><attack.attackieren><de> """Nach einem Unfall im Streckenabschnitt Kesselchen war ich in der Schlussphase mit einer beschädigten Frontpartie unterwegs und konnte den Lexus vor uns nicht voll attackieren."
<G-vec00441-001-s372><attack.attackieren><en> """After an accident at the section Kesselchen, I had to complete the last part of the race with a damaged front and was thus not able to fully attack the Lexus in front of me."
<G-vec00441-001-s373><attack.attackieren><de> ARCADE Mechanik ist zu einfach, nur Sie Ihren Finger über den Bildschirm gleiten, den Gegner zu attackieren.
<G-vec00441-001-s373><attack.attackieren><en> Árcade mechanics is too simple, only you glide your finger across the screen to attack your opponent.
<G-vec00441-001-s374><attack.attackieren><de> Die Castortransporte wurden als ein Druckpunkt benutzt, um das jetzt verbliebene System der Kernenergiegewinnung in den neunziger Jahren zu attackieren und zu erschweren.
<G-vec00441-001-s374><attack.attackieren><en> The Castor transports were used as a point of pressure, in order to attack the now remaining system of nuclear energy production in the nineties and to make it more difficult.
<G-vec00441-001-s375><attack.attackieren><de> Danach war es für mich ein interessantes Rennen, ich musste auf meine Reifen aufpassen und gleichzeitig attackieren und verteidigen, speziell gegen Michael (Schumacher) und Adrian (Sutil).
<G-vec00441-001-s375><attack.attackieren><en> After that it was an interesting race for me as I had to look after my tyres and at the same time I had to attack and also defend at different times, particularly with Michael and Adrian.
<G-vec00441-001-s376><attack.attackieren><de> Wir glauben, es ist sehr wahrscheinlich, dass der gehackte Computer benutzt wurde, um andere Falun Dafa-Webseiten und Datenserver zu attackieren.
<G-vec00441-001-s376><attack.attackieren><en> We believe it is very likely that the hacked computer was used to attack other Dafa websites and data servers.
<G-vec00441-001-s377><attack.attackieren><de> Obwohl es in einigen Fällen wurde berichtet, eine falsch-positive Erkennung sein, Malware kann dies oft verwenden, um einen Computer zu attackieren und sie infizieren.
<G-vec00441-001-s377><attack.attackieren><en> Despite in some cases it was reported to be a false-positive detection, malware may often use this to attack a computer and infect it.
<G-vec00441-001-s378><attack.attackieren><de> "Allan McNish (Audi R10 TDI #1): ""Um überhaupt eine Siegchance zu haben, mussten wir von Anfang an attackieren."
<G-vec00441-001-s378><attack.attackieren><en> "Allan McNish (Audi R10 TDI #1): ""To have any chance of a victory we had to attack immediately."
<G-vec00441-001-s379><attack.attackieren><de> Aus der Not heraus attackieren diese daher Schafe oder andere Nutztiere.
<G-vec00441-001-s379><attack.attackieren><en> Then, out of necessity they attack sheep or other farm animals.
