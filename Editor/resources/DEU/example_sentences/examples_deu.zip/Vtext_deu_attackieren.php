<G-vec00441-001-s361><attack.attackieren><de> Rasend erzürnt, attackieren und bedrohen sie.
<G-vec00441-001-s361><attack.attackieren><en> Furiously enraged, they attack and threaten.
<G-vec00441-001-s362><attack.attackieren><de> Jakes Dungeon Stein spielen, W verwenden,A,S,D-Tasten zu bewegen, Maus zu zielen, klicken Sie links zu attackieren, der rechten Maustaste, um Geschicklichkeit, Leertaste, um zu rollen, Q-Taste, um Waffen zu wechseln, E-Taste zum Handeln, 1 Schlüssel für die Sandwich-und M-Taste, um die Karte zu verwenden.
<G-vec00441-001-s362><attack.attackieren><en> To play Jake's Dungeon Stone, use W,A,S,D keys to move, mouse to aim, left click to attack, right click to use skill, SPACEBAR to roll, Q key to switch weapon, E key to action, 1 key for sandwich and M key to use map.
<G-vec00441-001-s363><attack.attackieren><de> Ein langes, sehr schweres Par 4, das vor allem den sehr guten Golfer, der das Grün mit dem zweiten Schlag attackieren muss, in tiefe Verzweiflung stürzen wird, wenn ihm nicht zwei perfekte Golfschläge gelingen.
<G-vec00441-001-s363><attack.attackieren><en> A long, very difficult par 4, especially for very good golfers who must attack the green with the second shot and who will plunge into great distress if they do not succeed in making two perfect shots.
<G-vec00441-001-s364><attack.attackieren><de> Die Conyers Gesetzentwurf schlägt vor, dieses Problem auf zwei Wegen zu attackieren.
<G-vec00441-001-s364><attack.attackieren><en> The Conyers bill proposes to attack this problem in two ways.
<G-vec00441-001-s365><attack.attackieren><de> Jin Youfeng kooperierte nicht mit seinen Verfolgern und der Wärter Zhou Shaokun befahl dem Häftling Liu Daqing und weiteren Gefangenen, ihn barbarisch zu attackieren.
<G-vec00441-001-s365><attack.attackieren><en> Jin Youfeng did not cooperate with the perpetrators, and guard Zhou Shaokun ordered inmates Liu Daqing and others to barbarically attack him.
<G-vec00441-001-s366><attack.attackieren><de> Befehligen Sie Ihre Truppen feindliche Kontrollpunkte zu attackieren.
<G-vec00441-001-s366><attack.attackieren><en> Command your troops to attack enemy control points.
<G-vec00441-001-s367><attack.attackieren><de> Scavengers sind die einzigen Zombies mit der Fähigkeit, aus der Entfernung zu attackieren.
<G-vec00441-001-s367><attack.attackieren><en> Scavengers are the only zombies with the ability to attack from a distance.
<G-vec00441-001-s368><attack.attackieren><de> Kein schädlicher Code wird das sichere Spam-Filter-System zu attackieren.
<G-vec00441-001-s368><attack.attackieren><en> No malicious code will attack our secure spam filtering system.
<G-vec00441-001-s369><attack.attackieren><de> "Sie sagten: ""Du bist der Anführer bei der Organisierung, das Gericht zu attackieren."
<G-vec00441-001-s369><attack.attackieren><en> "They said, ""You are the head organising this, to attack the court."
<G-vec00441-001-s370><attack.attackieren><de> Man kann die Aggression zurückweisen und sie attackieren, aber den Krieg gegen die israelisch-zionistische Aggression müssen die arabischen Staaten selbst führen.
<G-vec00441-001-s370><attack.attackieren><en> It is possible to refute the aggression and attack it, but the war against the Israeli-Zionist aggression must be lead by the Arab states themselves.
<G-vec00441-001-s371><attack.attackieren><de> Während die chinesischen Führer, angefangen bei Mao Tsetung Schwankungen und Tendenzen zur Bildung einer Einheitsfront mit den Chruschtschow-Breschnew-Revisionisten erkennen lassen und sich mit den jugoslawischen, polnischen, spanischen und anderen Revisionisten vereinigen und küssen, lassen sie keine Gelegenheit verstreichen, um J. Stalin, diesen großen Marxisten-Leninisten, den treuen Schüler und Fortsetzer des Werkes Lenins zu attackieren und zu verunglimpfen.
<G-vec00441-001-s371><attack.attackieren><en> And in fact, while they show vacillations and inclinations towards a common front with the Khrushchevite-Brezhnevite revisionists, while they make up and kiss with Yugoslav, Polish, Spanish and other revisionists, the Chinese revisionists, beginning with Mao Tsetung, leave no opportunity unused to attack and vilify J. V. Stalin, the great Marxist-Leninist, the disciple and faithful continuer of the work of Lenin.
<G-vec00441-001-s372><attack.attackieren><de> """Nach einem Unfall im Streckenabschnitt Kesselchen war ich in der Schlussphase mit einer beschädigten Frontpartie unterwegs und konnte den Lexus vor uns nicht voll attackieren."
<G-vec00441-001-s372><attack.attackieren><en> """After an accident at the section Kesselchen, I had to complete the last part of the race with a damaged front and was thus not able to fully attack the Lexus in front of me."
<G-vec00441-001-s373><attack.attackieren><de> ARCADE Mechanik ist zu einfach, nur Sie Ihren Finger über den Bildschirm gleiten, den Gegner zu attackieren.
<G-vec00441-001-s373><attack.attackieren><en> Árcade mechanics is too simple, only you glide your finger across the screen to attack your opponent.
<G-vec00441-001-s374><attack.attackieren><de> Die Castortransporte wurden als ein Druckpunkt benutzt, um das jetzt verbliebene System der Kernenergiegewinnung in den neunziger Jahren zu attackieren und zu erschweren.
<G-vec00441-001-s374><attack.attackieren><en> The Castor transports were used as a point of pressure, in order to attack the now remaining system of nuclear energy production in the nineties and to make it more difficult.
<G-vec00441-001-s375><attack.attackieren><de> Danach war es für mich ein interessantes Rennen, ich musste auf meine Reifen aufpassen und gleichzeitig attackieren und verteidigen, speziell gegen Michael (Schumacher) und Adrian (Sutil).
<G-vec00441-001-s375><attack.attackieren><en> After that it was an interesting race for me as I had to look after my tyres and at the same time I had to attack and also defend at different times, particularly with Michael and Adrian.
<G-vec00441-001-s376><attack.attackieren><de> Wir glauben, es ist sehr wahrscheinlich, dass der gehackte Computer benutzt wurde, um andere Falun Dafa-Webseiten und Datenserver zu attackieren.
<G-vec00441-001-s376><attack.attackieren><en> We believe it is very likely that the hacked computer was used to attack other Dafa websites and data servers.
<G-vec00441-001-s377><attack.attackieren><de> Obwohl es in einigen Fällen wurde berichtet, eine falsch-positive Erkennung sein, Malware kann dies oft verwenden, um einen Computer zu attackieren und sie infizieren.
<G-vec00441-001-s377><attack.attackieren><en> Despite in some cases it was reported to be a false-positive detection, malware may often use this to attack a computer and infect it.
<G-vec00441-001-s378><attack.attackieren><de> "Allan McNish (Audi R10 TDI #1): ""Um überhaupt eine Siegchance zu haben, mussten wir von Anfang an attackieren."
<G-vec00441-001-s378><attack.attackieren><en> "Allan McNish (Audi R10 TDI #1): ""To have any chance of a victory we had to attack immediately."
<G-vec00441-001-s379><attack.attackieren><de> Aus der Not heraus attackieren diese daher Schafe oder andere Nutztiere.
<G-vec00441-001-s379><attack.attackieren><en> Then, out of necessity they attack sheep or other farm animals.
<G-vec00441-002-s044><ambush.attackieren><de> Um ihre Beute zu fangen, verankert sich die Spinne mit ihren Hinterbeinen an einem Felsen oder einer Pflanze und platziert ihre Vorderbeine auf der Wasseroberfläche, bereit die Beute zu attackieren.
<G-vec00441-002-s044><ambush.attackieren><en> In order to catch its prey, the spider will typically anchor its hind legs to a stone or a plant, with its front legs resting on the surface of the water, ready to ambush.
<G-vec00441-002-s437><attack.attackieren><de> GJ: In Politik und Krieg muss man den Feind attackieren, wo er am schwächsten und man selbst am stärksten ist.
<G-vec00441-002-s437><attack.attackieren><en> GJ: In politics and warfare, one must attack the enemy where he is weakest and you are strongest.
<G-vec00441-002-s438><attack.attackieren><de> Sie attackieren und schlagen ihn.
<G-vec00441-002-s438><attack.attackieren><en> They attack him and beat him.
<G-vec00441-002-s439><attack.attackieren><de> Sogar die New York Times berichtete über den – als gefährlich dargestellten – Plan von acht Kommunarden, ihren Vize mit Pudding, Joghurt und Mehl zu attackieren, sodass Uwe Johnson seinen Freund und Nachbarn Günter Grass beauftragte, diese Studenten aus seiner Wohnung zu entfernen.
<G-vec00441-002-s439><attack.attackieren><en> Even the New York Times featured a report on the plan of eight communards to attack the Vice-President with pudding, yogurt, and flour. Because of this bad publicity, Uwe Johnson hastily asked his friend and neighbor Günter Grass to evict the students from his apartment.
<G-vec00441-002-s440><attack.attackieren><de> Wenn sie dich attackieren und beißen, kannst du sterben.
<G-vec00441-002-s440><attack.attackieren><en> If they attack and bite you, you can die.
<G-vec00441-002-s441><attack.attackieren><de> Wir dürfen nichts als selbstverständlich ansehen und wir werden in den kommenden Rennen weiter in jedem Bereich voll attackieren.
<G-vec00441-002-s441><attack.attackieren><en> We can take nothing for granted and we will stay at maximum attack on every front in the next races.
<G-vec00441-002-s442><attack.attackieren><de> Dieser war kein Unbekannter, denn Fabian Wegmann hatte den Grand Prix Miguel Indurain schon einmal vor zwei Jahren gewonnen, kannt also die Strecke und wusste genau, wo er attackieren sollte.
<G-vec00441-002-s442><attack.attackieren><en> The winner was somebody who knows well the race since Fabian Wegmann has already won here two years ago and, he knows well the climb and saw exactly where to attack.
<G-vec00441-002-s443><attack.attackieren><de> Spieler sind mit und ohne Ball schneller, explosive Schüsse werden von allen Winkeln abgefeuert und jeder sucht nach der Möglichkeit, um zu attackieren.
<G-vec00441-002-s443><attack.attackieren><en> Players are quicker on and off the ball, explosive shots are fired from all angles and everyone is looking for that space to attack.
<G-vec00441-002-s444><attack.attackieren><de> Sie dürfen unsere Seite nicht über einen Denial-of-Service-Angriff oder einen Distributed-Denial-of-Service-Angriff attackieren.
<G-vec00441-002-s444><attack.attackieren><en> You must not attack our site via a denial-of-service attack or a distributed denial-of service attack.
<G-vec00441-002-s445><attack.attackieren><de> Sie d√ľrfen unsere Website nicht durch einen Denial-of-Service-Angriff oder einen Distributed-Denial-of-Service-Angriff attackieren.
<G-vec00441-002-s445><attack.attackieren><en> You must not attack our site via a denial-of-service attack or a distributed denial-of service attack.
<G-vec00441-002-s446><attack.attackieren><de> Ein Bosnier (20) und zwei Komplizen (17, 31) brechen mehrere Fahrkarten- und Zigaretten-Automaten auf und attackieren 10 Zeugen mit einem Kanister.
<G-vec00441-002-s446><attack.attackieren><en> A Bosnian (20) and two accomplices (17, 31) break open several ticket and cigarette machines and attack 10 witnesses with one canister.
<G-vec00441-002-s447><attack.attackieren><de> Githa hat dann das Tempo angezogen und ich habe immer wieder versucht zu attackieren um Angelika abzuhängen.
<G-vec00441-002-s447><attack.attackieren><en> Githa then pulled away and I also tried to attack Angelika, but I wasn’t possible to get rid of her.
<G-vec00441-002-s448><attack.attackieren><de> (offizielles Expansionspacket zu Rome: Total War) Werden Sie Zeuge vom Niedergang Roms als barbarische Horden attackieren und einen bitteren Bruderkampf zwischen rivalisierenden römischen Fraktionen auslösen.
<G-vec00441-002-s448><attack.attackieren><en> (official expansion pack to Rome: Total War) Witness the decline of Rome as Barbarian hordes attack, forcing a bitter internal struggle between rival factions.
<G-vec00441-002-s449><attack.attackieren><de> Sie attackieren nicht nur andere Kreaturen, um deren Nahrung zu fressen oder zu zerstören, sondern zerstören oftmals auch die Stabilität von Höhlen und Tunneln mit ihrem ziellosen Buddeln und Fressen von Mineralien.
<G-vec00441-002-s449><attack.attackieren><en> Not only do they attack other creatures to devour them or destroy their food sources, their aimless digging and mineral eating often completely destroys the stability of caves and tunnels.
<G-vec00441-002-s450><attack.attackieren><de> Die tollwütigen Wölfe attackieren gerne im Rudel und werden versuchen, Dich und Deine Krieger einzukreisen.
<G-vec00441-002-s450><attack.attackieren><en> The rabid wolves will always attack in the pack and try to encircle you and your warriors.
<G-vec00441-002-s451><attack.attackieren><de> Radioaktive Implantate, sogenannte „Seeds”, werden vorsichtig innerhalb des Tumorgewebes platziert und so positioniert, dass sie den Krebs am effizientesten attackieren können.
<G-vec00441-002-s451><attack.attackieren><en> Radioactive “seeds” are carefully placed inside of the cancerous tissue and positioned to attack the cancer most efficiently. Buried penis
<G-vec00441-002-s452><attack.attackieren><de> Mit lebhafter und schnörkelloser Sprache erklärt Aagaard, wie die besten Spieler der Welt attackieren.
<G-vec00441-002-s452><attack.attackieren><en> In lively no-nonsense language, Aagaard explains how the best players in the world attack. Content:
<G-vec00441-002-s453><attack.attackieren><de> Gegner und eigene Einheiten attackieren sich in Echtzeit und sorgen für ein actionreiches und realistisches Schlachtenabbild.
<G-vec00441-002-s453><attack.attackieren><en> Enemies and friendly units attack in real time and build an action-packed and realistic battle portrayal.
<G-vec00441-002-s454><attack.attackieren><de> Für einige Zeit attackieren eure Soldaten doppelt so schnell wie vorher.
<G-vec00441-002-s454><attack.attackieren><en> For a short period your soldiers attack at twice their normal speed.
<G-vec00441-002-s455><attack.attackieren><de> Die Täter wollen möglichst viele Ziele mit wenig Aufwand attackieren und etwa durch den Verkauf von Datensätzen oder Erpressung Geld verdienen.
<G-vec00441-002-s455><attack.attackieren><en> The perpetrators want to attack as many targets as possible with as little effort as possible, and earn money from the sale of data sets or through extortion.
