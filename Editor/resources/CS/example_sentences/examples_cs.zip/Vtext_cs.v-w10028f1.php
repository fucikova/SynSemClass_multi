<T-wsj1303-001-p1s6#T-wsj1303-001-p1s6a8><ev-w1778f1.v-w10028f1> Tento veselý, dobrácký vedoucí pracovník - rád <start_vs>žertuje<end_vs> s Američany o svém jménu, které je synonymem pro dvanáct - byl teprve na začátku tohoto roku jmenován zástupcem prezidenta. 
<T-wsj1388-001-p1s15#T-wsj1388-001-p1s15a11><ev-w1778f1.v-w10028f1> "Učil mě, jak hrát jako cikán," <start_vs>žertuje<end_vs> hudebník. 
<T-wsj1682-001-p1s17#T-wsj1682-001-p1s17a14><ev-w1778f1.v-w10028f1> "Pokud já mohu vykazovat známky vyzrálosti, může již téměř kdokoli," <start_vs>žertuje<end_vs>. 
