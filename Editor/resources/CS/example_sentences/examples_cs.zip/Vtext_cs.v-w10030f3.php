<T-wsj1643-001-p1s10#T-wsj1643-001-p1s10a12><ev-w1880f7.v-w10030f3> Proč byste neposlouchali svou zkušenost, zapisovanou do historie, <start_vauxs>zatímco<end_vauxs> ji <start_vs>žijete<end_vs>? 
