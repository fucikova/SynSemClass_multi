<G-vec00081-001-s095><block.blocken><en> "It is also possible to block Facebook social plugins with add-ons for your browser, for example with the ""Facebook Blocker""."
<G-vec00081-001-s095><block.blocken><de> "Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00081-001-s096><block.blocken><en> Afterwards, the police tried to block the news.
<G-vec00081-001-s096><block.blocken><de> Anschließend versuchte die Polizei, die Nachrichten hierüber zu blocken.
<G-vec00081-001-s097><block.blocken><en> The naive approach would be to block TCP packets coming from the server.
<G-vec00081-001-s097><block.blocken><de> Die einfache Annaeherung daran wuerde sein, alle einkommenden TCP-Pakete von diesem Server zu blocken.
<G-vec00081-001-s098><block.blocken><en> Block: Now requires 10% of your stamina bar to activate (down from 20%)
<G-vec00081-001-s098><block.blocken><de> Blocken: Benötigt zur Aktivierung nun 10% der Ausdauer (zuvor: 20%).
<G-vec00081-001-s099><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00081-001-s099><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00081-001-s100><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00081-001-s100><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00081-001-s101><block.blocken><en> If you block our cookies in your browser, you may not be able to us some of areas of our website.
<G-vec00081-001-s101><block.blocken><de> Falls Sie unsere Cookies in Ihrem Browser blocken, können Sie manche Bereiche unserer Website nicht nutzen.
<G-vec00081-001-s102><block.blocken><en> In this case, it's a good idea to use robots.txt to block the search engines and at the same time add password protection as an extra level of security.
<G-vec00081-001-s102><block.blocken><de> In diesem Fall ist es sinnvoll, die Robots.txt zum Blocken der Suchmaschinen zu nutzen und gleichzeitig ein Passwortschutz für zusätzliche Sicherheit einzurichten.
<G-vec00081-001-s103><block.blocken><en> "You can also block Facebook social plugins with add-ons for your browser, for example with the ""Facebook blocker""."
<G-vec00081-001-s103><block.blocken><de> "Sie können im Übrigen Facebook-Social-Plugins mit Add-ons für Ihren Browser blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00081-001-s104><block.blocken><en> In the given example, you would (1) block the cavalry camp and (2) the melee camp with your heavy units and then (3) defeat the sector boss with your attack units, utilizing your three Marshals.
<G-vec00081-001-s104><block.blocken><de> Im gegebenen Beispiel würdet Ihr (1) das Reiterlager sowie (2) das Nahkampflager mit Euren schweren Einheiten blocken und dann (3) den Sektorboss mit Euren Angriffseinheiten und drei Marschällen besiegen.
<G-vec00081-001-s105><block.blocken><en> However, if you use your browser settings to block all cookies you may not be to access some parts of our site.
<G-vec00081-001-s105><block.blocken><de> Falls Sie in Ihren Browsereinstellungen alle Cookies blocken, können Sie möglicherweise nicht auf alle Teile unserer Websites zugreifen.
<G-vec00081-001-s106><block.blocken><en> It comes with a block feature that allows you to solely block out profane websites and messages.
<G-vec00081-001-s106><block.blocken><de> Enthält eine Blocken-Funktion, mit der Sie unangemessene Webseiten und Nachrichten blocken können.
<G-vec00081-001-s107><block.blocken><en> – block third-party cookies.
<G-vec00081-001-s107><block.blocken><de> – Cookies von externen Drittanbietern blocken.
<G-vec00081-001-s108><block.blocken><en> Increases the chance to block an attack by 0.9% .
<G-vec00081-001-s108><block.blocken><de> Erhöht die Wahrscheinlichkeit einen Angriff zu blocken um 0.9% .
<G-vec00081-001-s109><block.blocken><en> Block: The Lizardman can sometimes hold up their spear to defend themselves against oncoming attacks.
<G-vec00081-001-s109><block.blocken><de> Blocken: Der Echsenmensch hebt seinen Speer um sich gegen kommende Angriffe zu schützen.
<G-vec00081-001-s110><block.blocken><en> Try to block Dirk Nowitzki!
<G-vec00081-001-s110><block.blocken><de> Sie können versuchen Dirk Nowitzki zu blocken.
<G-vec00081-001-s111><block.blocken><en> Firewall to block scanning, attacks, and other hostile activity from external networks.
<G-vec00081-001-s111><block.blocken><de> Firewall gegen Angriffe von Außen und Blocken von Ports und unerwünschter Dienste.
<G-vec00081-001-s112><block.blocken><en> "Furthermore, in individual cases, it is possible to block social media plugins using add-ons for your browser, e.g., blocking the Facebook plugin using ""Facebook Blocker""."
<G-vec00081-001-s112><block.blocken><de> "Ergänzend besteht im Einzelfall die Möglichkeit, Socialplug-ins mithilfe von Add-ons für Ihren Browser zu blocken, so etwa das Facebook plug-in mit dem ""Facebook Blocker""."
<G-vec00081-001-s113><block.blocken><en> A block of cookies may affect the functionality of your Website session.
<G-vec00081-001-s113><block.blocken><de> Bitte beachte, dass das Blocken von Cookies die Funktionalität der Internetseite beeinträchtigen kann.
<G-vec00367-001-s095><block.blocken><en> "It is also possible to block Facebook social plugins with add-ons for your browser, for example with the ""Facebook Blocker""."
<G-vec00367-001-s095><block.blocken><de> "Ebenfalls ist es möglich Facebook-Social-Plugins mit Add-ons für Ihren Browser zu blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00367-001-s096><block.blocken><en> Afterwards, the police tried to block the news.
<G-vec00367-001-s096><block.blocken><de> Anschließend versuchte die Polizei, die Nachrichten hierüber zu blocken.
<G-vec00367-001-s097><block.blocken><en> The naive approach would be to block TCP packets coming from the server.
<G-vec00367-001-s097><block.blocken><de> Die einfache Annaeherung daran wuerde sein, alle einkommenden TCP-Pakete von diesem Server zu blocken.
<G-vec00367-001-s098><block.blocken><en> Block: Now requires 10% of your stamina bar to activate (down from 20%)
<G-vec00367-001-s098><block.blocken><de> Blocken: Benötigt zur Aktivierung nun 10% der Ausdauer (zuvor: 20%).
<G-vec00367-001-s099><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00367-001-s099><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00367-001-s100><block.blocken><en> Mastery: Critical Block now increases critical block chance by 12% (down from 17.6%).
<G-vec00367-001-s100><block.blocken><de> 'Meisterschaft: Kritisches Blocken' erhöht jetzt die Chance auf kritisches Blocken um 12% (vorher 17,6%).
<G-vec00367-001-s101><block.blocken><en> If you block our cookies in your browser, you may not be able to us some of areas of our website.
<G-vec00367-001-s101><block.blocken><de> Falls Sie unsere Cookies in Ihrem Browser blocken, können Sie manche Bereiche unserer Website nicht nutzen.
<G-vec00367-001-s102><block.blocken><en> In this case, it's a good idea to use robots.txt to block the search engines and at the same time add password protection as an extra level of security.
<G-vec00367-001-s102><block.blocken><de> In diesem Fall ist es sinnvoll, die Robots.txt zum Blocken der Suchmaschinen zu nutzen und gleichzeitig ein Passwortschutz für zusätzliche Sicherheit einzurichten.
<G-vec00367-001-s103><block.blocken><en> "You can also block Facebook social plugins with add-ons for your browser, for example with the ""Facebook blocker""."
<G-vec00367-001-s103><block.blocken><de> "Sie können im Übrigen Facebook-Social-Plugins mit Add-ons für Ihren Browser blocken, zum Beispiel mit dem ""Facebook Blocker""."
<G-vec00367-001-s104><block.blocken><en> In the given example, you would (1) block the cavalry camp and (2) the melee camp with your heavy units and then (3) defeat the sector boss with your attack units, utilizing your three Marshals.
<G-vec00367-001-s104><block.blocken><de> Im gegebenen Beispiel würdet Ihr (1) das Reiterlager sowie (2) das Nahkampflager mit Euren schweren Einheiten blocken und dann (3) den Sektorboss mit Euren Angriffseinheiten und drei Marschällen besiegen.
<G-vec00367-001-s105><block.blocken><en> However, if you use your browser settings to block all cookies you may not be to access some parts of our site.
<G-vec00367-001-s105><block.blocken><de> Falls Sie in Ihren Browsereinstellungen alle Cookies blocken, können Sie möglicherweise nicht auf alle Teile unserer Websites zugreifen.
<G-vec00367-001-s106><block.blocken><en> It comes with a block feature that allows you to solely block out profane websites and messages.
<G-vec00367-001-s106><block.blocken><de> Enthält eine Blocken-Funktion, mit der Sie unangemessene Webseiten und Nachrichten blocken können.
<G-vec00367-001-s107><block.blocken><en> – block third-party cookies.
<G-vec00367-001-s107><block.blocken><de> – Cookies von externen Drittanbietern blocken.
<G-vec00367-001-s108><block.blocken><en> Increases the chance to block an attack by 0.9% .
<G-vec00367-001-s108><block.blocken><de> Erhöht die Wahrscheinlichkeit einen Angriff zu blocken um 0.9% .
<G-vec00367-001-s109><block.blocken><en> Block: The Lizardman can sometimes hold up their spear to defend themselves against oncoming attacks.
<G-vec00367-001-s109><block.blocken><de> Blocken: Der Echsenmensch hebt seinen Speer um sich gegen kommende Angriffe zu schützen.
<G-vec00367-001-s110><block.blocken><en> Try to block Dirk Nowitzki!
<G-vec00367-001-s110><block.blocken><de> Sie können versuchen Dirk Nowitzki zu blocken.
<G-vec00367-001-s111><block.blocken><en> Firewall to block scanning, attacks, and other hostile activity from external networks.
<G-vec00367-001-s111><block.blocken><de> Firewall gegen Angriffe von Außen und Blocken von Ports und unerwünschter Dienste.
<G-vec00367-001-s112><block.blocken><en> "Furthermore, in individual cases, it is possible to block social media plugins using add-ons for your browser, e.g., blocking the Facebook plugin using ""Facebook Blocker""."
<G-vec00367-001-s112><block.blocken><de> "Ergänzend besteht im Einzelfall die Möglichkeit, Socialplug-ins mithilfe von Add-ons für Ihren Browser zu blocken, so etwa das Facebook plug-in mit dem ""Facebook Blocker""."
<G-vec00367-001-s113><block.blocken><en> A block of cookies may affect the functionality of your Website session.
<G-vec00367-001-s113><block.blocken><de> Bitte beachte, dass das Blocken von Cookies die Funktionalität der Internetseite beeinträchtigen kann.
<G-vec00081-001-s133><block.blockieren><en> Spyzie has a user-friendly interface and allows you to block apps on your kid’s phone.
<G-vec00081-001-s133><block.blockieren><de> Spyzie verfügt über eine benutzerfreundliche Oberfläche und ermöglicht es Ihnen, Apps auf dem Handy Ihres Kindes zu blockieren.
<G-vec00081-001-s134><block.blockieren><en> Avoid sleeping on your stomach, since this can block breathing, promote acid reflux and cause stress.
<G-vec00081-001-s134><block.blockieren><de> Vermeide es, auf dem Bauch zu schlafen, da dies die Atmung blockieren, Sodbrennen fördern und Stress verursachen kann.
<G-vec00081-001-s135><block.blockieren><en> "Block Apps Make sure the ON/OFF button in the lower right corner is in ""ON "" status."
<G-vec00081-001-s135><block.blockieren><de> "Apps blockieren Vergewissern Sie sich, dass sich die EIN / AUS-Taste in der rechten unteren Ecke im Status "" EIN"" befindet."
<G-vec00081-001-s136><block.blockieren><en> If the autoplay switch is not working for you, you may want to use third-party tools instead to block autoplay on YouTube.
<G-vec00081-001-s136><block.blockieren><de> Wenn die autoplay-Option nicht für Sie arbeiten, können Sie möchten verwenden von Drittanbieter-tools statt zu blockieren autoplay auf YouTube.
<G-vec00081-001-s137><block.blockieren><en> Here is a jammer device that designed to block the mobile phone signals and the WiFi signal which is named 25W High Power 3G Phone WiFi Signal Jammer with Outer Detachable Power Supply and can help you a lot once you have known the details as follows about it.
<G-vec00081-001-s137><block.blockieren><de> Ist hier ein Störsendergerät, das entwarf, die Handysignale und das WiFi-Signal zu blockieren, das 25W Telefon-WiFi-Signal-Störsender der hohen Leistung 3G mit äußerer abnehmbarer Stromversorgung genannt wird und Ihnen viel einmal helfen kann Sie, die Details über es wie folgt gewusst zu haben.
<G-vec00081-001-s138><block.blockieren><en> Can easily block all the adult and non-restricted pages anytime.
<G-vec00081-001-s138><block.blockieren><de> Kann leicht alle Adult und unbeschränkten Seiten jederzeit blockieren.
<G-vec00081-001-s139><block.blockieren><en> This technique concentrates on the pace of shifting your pieces with no efforts to hit or block your opponent’s checkers.
<G-vec00081-001-s139><block.blockieren><de> Diese Technik konzentriert sich auf das Tempo der Verlagerung Ihrer Stücke mit, keine Mühe zu schlagen oder zu blockieren gegnerischen Steine.
<G-vec00081-001-s140><block.blockieren><en> You can even block email notifications and create profiles with separate restriction settings.
<G-vec00081-001-s140><block.blockieren><de> Sie können sogar E-Mail-Benachrichtigungen blockieren und Profile mit separaten Einschränkungseinstellungen erstellen.
<G-vec00081-001-s141><block.blockieren><en> Immune-based therapeutics Nanobodies can be used to combat cancer and other diseases by inhibiting ligand-receptor interactions, such as antagonizing anti-von Willebrand factor to block the initiation of thrombosis, or inhibiting anti-TNF-a to treat arthritis.
<G-vec00081-001-s141><block.blockieren><de> Nanobodies kann, um Krebs und andere Krankheiten, indem man Ligandempfänger Interaktionen, wie Bekämpfung von Faktor AntiVon Willebrand verwendet werden, um die Inbetriebnahme der Thrombose zu blockieren sperrt, oder das Sperren zu bekämpfen anti--TNF-a, um Arthritis zu behandeln.
<G-vec00081-001-s142><block.blockieren><en> Block all network traffic – Blocks all network traffic.
<G-vec00081-001-s142><block.blockieren><de> Sämtlichen Netzwerkverkehr blockieren – Blockiert den gesamten Netzwerkverkehr.
<G-vec00081-001-s143><block.blockieren><en> You can block the use of such cookies by creating an exclusion cookie.
<G-vec00081-001-s143><block.blockieren><de> Sie können den Einsatz solcher Cookies blockieren, indem Sie im Browser ein sogenanntes Ausschlusscookie setzen.
<G-vec00081-001-s144><block.blockieren><en> ALA is a 50/50 combination of natural form r-lipoic and synthetic s-lipoic acid—and the synthetic form may actually block the activity of r-lipoic acid, resulting in a weaker product.
<G-vec00081-001-s144><block.blockieren><de> ALS ist eine 50/50 Kombination aus R-Liponsäure in natürlicher Form und synthetischer S-Liponsäure - und die synthetische Form kann sogar die Aktivität von R-Liponsäure blockieren, was ein schwächeres Produkt ergibt.
<G-vec00081-001-s145><block.blockieren><en> It can block the noise transmission.
<G-vec00081-001-s145><block.blockieren><de> Es kann die Geräuschübertragung blockieren.
<G-vec00081-001-s146><block.blockieren><en> In the case of this sculpture it would be difficult to approach the problem in this manner because the thin leg portions of the sculpture would solidify too quickly and block the exit route for the molten wax.
<G-vec00081-001-s146><block.blockieren><de> Bei dieser Skulptur, es wäre schwierig, das Problem auf diese Weise, weil die dünnen Beine Teile der Skulptur würde zu schnell erstarren und blockieren die Ausfahrt Route für das geschmolzene Wachs Ansatz.
<G-vec00081-001-s147><block.blockieren><en> File Anti-Virus and Mail Anti-Virus: in the section Action on threat detection, select Block or Disinfect .
<G-vec00081-001-s147><block.blockieren><de> Datei-Anti-Virus / Mail-Anti-Virus – im Abschnitt Aktion beim Fund einer Bedrohung wählen Sie Blockieren oder Desinfizieren .
<G-vec00081-001-s148><block.blockieren><en> You can change the settings to block cookies or to alert you when cookies are being sent to your device.
<G-vec00081-001-s148><block.blockieren><de> Sie können die Einstellungen ändern, um Cookies zu blockieren oder Sie lassen sich warnen, wenn Cookies auf Ihr Gerät gesendet werden.
<G-vec00081-001-s149><block.blockieren><en> After selecting the restrict application option a window will appear where you have to fill the login id and password to block the blackberry browser or website.
<G-vec00081-001-s149><block.blockieren><de> Nach Auswahl der Option Anwendung einschränken erscheint ein Fenster, in dem Sie die Login-ID und das Passwort eingeben müssen, um den Blackberry-Browser oder die Webseite zu blockieren.
<G-vec00081-001-s150><block.blockieren><en> "If you do not want social networks to collect data about you through active plugins, you can either simply deactivate the social plugins with one click on our web pages or select ""block third party cookies"" in your browser settings."
<G-vec00081-001-s150><block.blockieren><de> "Wenn du nicht möchtest, dass soziale Netzwerke über aktive Plugins Daten über dich sammeln, kannst du entweder die Social Plugins einfach mit einem Klick auf unseren Webseiten deaktivieren oder in deinen Browser-Einstellungen die Funktion ""Cookies von Drittanbietern blockieren"" wählen."
<G-vec00081-001-s151><block.blockieren><en> Newer versions of Google Chrome block this extension and it should be enough of a proof to realize that nothing good can come out of VideoX.
<G-vec00081-001-s151><block.blockieren><de> Neuere Versionen von Google Chrome blockieren diese Erweiterung, und es sollte ausreichen, einen Nachweis zu erkennen, dass nichts Gutes herauskommen kann VideoX.
<G-vec00367-001-s133><block.blockieren><en> Spyzie has a user-friendly interface and allows you to block apps on your kid’s phone.
<G-vec00367-001-s133><block.blockieren><de> Spyzie verfügt über eine benutzerfreundliche Oberfläche und ermöglicht es Ihnen, Apps auf dem Handy Ihres Kindes zu blockieren.
<G-vec00367-001-s134><block.blockieren><en> Avoid sleeping on your stomach, since this can block breathing, promote acid reflux and cause stress.
<G-vec00367-001-s134><block.blockieren><de> Vermeide es, auf dem Bauch zu schlafen, da dies die Atmung blockieren, Sodbrennen fördern und Stress verursachen kann.
<G-vec00367-001-s135><block.blockieren><en> "Block Apps Make sure the ON/OFF button in the lower right corner is in ""ON "" status."
<G-vec00367-001-s135><block.blockieren><de> "Apps blockieren Vergewissern Sie sich, dass sich die EIN / AUS-Taste in der rechten unteren Ecke im Status "" EIN"" befindet."
<G-vec00367-001-s136><block.blockieren><en> If the autoplay switch is not working for you, you may want to use third-party tools instead to block autoplay on YouTube.
<G-vec00367-001-s136><block.blockieren><de> Wenn die autoplay-Option nicht für Sie arbeiten, können Sie möchten verwenden von Drittanbieter-tools statt zu blockieren autoplay auf YouTube.
<G-vec00367-001-s137><block.blockieren><en> Here is a jammer device that designed to block the mobile phone signals and the WiFi signal which is named 25W High Power 3G Phone WiFi Signal Jammer with Outer Detachable Power Supply and can help you a lot once you have known the details as follows about it.
<G-vec00367-001-s137><block.blockieren><de> Ist hier ein Störsendergerät, das entwarf, die Handysignale und das WiFi-Signal zu blockieren, das 25W Telefon-WiFi-Signal-Störsender der hohen Leistung 3G mit äußerer abnehmbarer Stromversorgung genannt wird und Ihnen viel einmal helfen kann Sie, die Details über es wie folgt gewusst zu haben.
<G-vec00367-001-s138><block.blockieren><en> Can easily block all the adult and non-restricted pages anytime.
<G-vec00367-001-s138><block.blockieren><de> Kann leicht alle Adult und unbeschränkten Seiten jederzeit blockieren.
<G-vec00367-001-s139><block.blockieren><en> This technique concentrates on the pace of shifting your pieces with no efforts to hit or block your opponent’s checkers.
<G-vec00367-001-s139><block.blockieren><de> Diese Technik konzentriert sich auf das Tempo der Verlagerung Ihrer Stücke mit, keine Mühe zu schlagen oder zu blockieren gegnerischen Steine.
<G-vec00367-001-s140><block.blockieren><en> You can even block email notifications and create profiles with separate restriction settings.
<G-vec00367-001-s140><block.blockieren><de> Sie können sogar E-Mail-Benachrichtigungen blockieren und Profile mit separaten Einschränkungseinstellungen erstellen.
<G-vec00367-001-s141><block.blockieren><en> Immune-based therapeutics Nanobodies can be used to combat cancer and other diseases by inhibiting ligand-receptor interactions, such as antagonizing anti-von Willebrand factor to block the initiation of thrombosis, or inhibiting anti-TNF-a to treat arthritis.
<G-vec00367-001-s141><block.blockieren><de> Nanobodies kann, um Krebs und andere Krankheiten, indem man Ligandempfänger Interaktionen, wie Bekämpfung von Faktor AntiVon Willebrand verwendet werden, um die Inbetriebnahme der Thrombose zu blockieren sperrt, oder das Sperren zu bekämpfen anti--TNF-a, um Arthritis zu behandeln.
<G-vec00367-001-s142><block.blockieren><en> Block all network traffic – Blocks all network traffic.
<G-vec00367-001-s142><block.blockieren><de> Sämtlichen Netzwerkverkehr blockieren – Blockiert den gesamten Netzwerkverkehr.
<G-vec00367-001-s143><block.blockieren><en> You can block the use of such cookies by creating an exclusion cookie.
<G-vec00367-001-s143><block.blockieren><de> Sie können den Einsatz solcher Cookies blockieren, indem Sie im Browser ein sogenanntes Ausschlusscookie setzen.
<G-vec00367-001-s144><block.blockieren><en> ALA is a 50/50 combination of natural form r-lipoic and synthetic s-lipoic acid—and the synthetic form may actually block the activity of r-lipoic acid, resulting in a weaker product.
<G-vec00367-001-s144><block.blockieren><de> ALS ist eine 50/50 Kombination aus R-Liponsäure in natürlicher Form und synthetischer S-Liponsäure - und die synthetische Form kann sogar die Aktivität von R-Liponsäure blockieren, was ein schwächeres Produkt ergibt.
<G-vec00367-001-s145><block.blockieren><en> It can block the noise transmission.
<G-vec00367-001-s145><block.blockieren><de> Es kann die Geräuschübertragung blockieren.
<G-vec00367-001-s146><block.blockieren><en> In the case of this sculpture it would be difficult to approach the problem in this manner because the thin leg portions of the sculpture would solidify too quickly and block the exit route for the molten wax.
<G-vec00367-001-s146><block.blockieren><de> Bei dieser Skulptur, es wäre schwierig, das Problem auf diese Weise, weil die dünnen Beine Teile der Skulptur würde zu schnell erstarren und blockieren die Ausfahrt Route für das geschmolzene Wachs Ansatz.
<G-vec00367-001-s147><block.blockieren><en> File Anti-Virus and Mail Anti-Virus: in the section Action on threat detection, select Block or Disinfect .
<G-vec00367-001-s147><block.blockieren><de> Datei-Anti-Virus / Mail-Anti-Virus – im Abschnitt Aktion beim Fund einer Bedrohung wählen Sie Blockieren oder Desinfizieren .
<G-vec00367-001-s148><block.blockieren><en> You can change the settings to block cookies or to alert you when cookies are being sent to your device.
<G-vec00367-001-s148><block.blockieren><de> Sie können die Einstellungen ändern, um Cookies zu blockieren oder Sie lassen sich warnen, wenn Cookies auf Ihr Gerät gesendet werden.
<G-vec00367-001-s149><block.blockieren><en> After selecting the restrict application option a window will appear where you have to fill the login id and password to block the blackberry browser or website.
<G-vec00367-001-s149><block.blockieren><de> Nach Auswahl der Option Anwendung einschränken erscheint ein Fenster, in dem Sie die Login-ID und das Passwort eingeben müssen, um den Blackberry-Browser oder die Webseite zu blockieren.
<G-vec00367-001-s150><block.blockieren><en> "If you do not want social networks to collect data about you through active plugins, you can either simply deactivate the social plugins with one click on our web pages or select ""block third party cookies"" in your browser settings."
<G-vec00367-001-s150><block.blockieren><de> "Wenn du nicht möchtest, dass soziale Netzwerke über aktive Plugins Daten über dich sammeln, kannst du entweder die Social Plugins einfach mit einem Klick auf unseren Webseiten deaktivieren oder in deinen Browser-Einstellungen die Funktion ""Cookies von Drittanbietern blockieren"" wählen."
<G-vec00367-001-s151><block.blockieren><en> Newer versions of Google Chrome block this extension and it should be enough of a proof to realize that nothing good can come out of VideoX.
<G-vec00367-001-s151><block.blockieren><de> Neuere Versionen von Google Chrome blockieren diese Erweiterung, und es sollte ausreichen, einen Nachweis zu erkennen, dass nichts Gutes herauskommen kann VideoX.
<G-vec00081-001-s152><block.blockieren><en> Page number in the upper left corner, making snowmen, snow, combined with permanent erosion should block them for 30 seconds.
<G-vec00081-001-s152><block.blockieren><de> Seitenzahl in der oberen linken Ecke, so dass Schneemänner, Schnee, mit ständigen Erosion kombiniert sollten sie für 30 Sekunden blockiert.
<G-vec00081-001-s153><block.blockieren><en> "If you do not want us to recognize your computer, please set your internet browser to ""Delete Cookies"" from your computer hard drive, to block cookies or to receive a warning before a cookie is stored."
<G-vec00081-001-s153><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00081-001-s154><block.blockieren><en> You can set your browser to block cookies from Google Analytics.
<G-vec00081-001-s154><block.blockieren><de> Sie können Ihren Browser so einstellen, dass Cookies von Google Analytics blockiert werden.
<G-vec00081-001-s155><block.blockieren><en> The Government enforces a blacklist of domains to block specific sites for illicit content.
<G-vec00081-001-s155><block.blockieren><de> Die Regierung setzt eine Blacklist durch, die bestimmte Domains mit illegalen Inhalten blockiert.
<G-vec00081-001-s156><block.blockieren><en> Anti-Banner will not block banners from this list.
<G-vec00081-001-s156><block.blockieren><de> Die Banner aus dieser Liste werden nicht von Anti-Banner blockiert.
<G-vec00081-001-s157><block.blockieren><en> In some cases such networks block sites such as Facebook, YouTube or other social media or gaming sites.
<G-vec00081-001-s157><block.blockieren><de> Bestimmte Webseiten wie Facebook, YouTube oder Online-Gaming-Seiten werden vom Netzwerk-Admin einfach per Firewall blockiert.
<G-vec00081-001-s158><block.blockieren><en> 2 - Please check that your Internet Browser (especially Internet Explorer) didn't block the download (if so, an Information Bar appears at the top part of your browser)
<G-vec00081-001-s158><block.blockieren><de> 2 - Prüfen Sie, daß Ihr Browser (insbesondere Internet Explorer), das Downloaden nicht blockiert hat (eine Informationsleiste erscheint in oberem Teil des Browsers).
<G-vec00081-001-s159><block.blockieren><en> On the positive side, it should be noted that the nuclear weapons states did not block this minimal consensus.
<G-vec00081-001-s159><block.blockieren><de> Positiv bleibt auch festzuhalten, dass die Nuklearwaffenstaaten diesen Minimalkonsens nicht blockiert haben.
<G-vec00081-001-s160><block.blockieren><en> You can adjust the settings in your browser in order to restrict or block cookies that are set by the Site (or any other site on the Internet).
<G-vec00081-001-s160><block.blockieren><de> Sie können die Einstellungen Ihres Browsers so anpassen, dass Cookies, die von der Website (oder einer anderen Website im Internet) gesetzt werden, beschränkt oder blockiert werden.
<G-vec00081-001-s161><block.blockieren><en> The administrator can decide to block the potential detected threat or exclude it by selecting Add Exclusion to Policy .
<G-vec00081-001-s161><block.blockieren><de> Der Administrator kann dann entscheiden, ob die erkannte potenzielle Bedrohung blockiert werden soll, oder sie über die Option Ausnahme zu Richtlinie hinzufügen ausschließen.
<G-vec00081-001-s162><block.blockieren><en> We have managed to block so much.
<G-vec00081-001-s162><block.blockieren><de> Wir haben bereits sehr vieles erfolgreich blockiert.
<G-vec00081-001-s163><block.blockieren><en> For example, you can configure a rule to explicitly block outbound traffic to a specific computer through the firewall but allow the same traffic to other computers.
<G-vec00081-001-s163><block.blockieren><de> Beispielsweise können Sie eine Regel so konfigurieren, dass sie ausdrücklich durch die Firewall ausgehenden Datenverkehr blockiert, jedoch denselben Datenverkehr zulässt, wenn er an andere Computer gesendet wird.
<G-vec00081-001-s164><block.blockieren><en> However, there have outraged guggulsterones of trainable order unisom professional and av block, reacting familial expulsion block, acclimated for the spite of hypertension.
<G-vec00081-001-s164><block.blockieren><de> Es hat jedoch empörte Guggulsterone der trainierbaren Ordnung unisom professional und av blockiert, die familiäre Vertreibungssperre reagierten, gewöhnt für Hypertonie.
<G-vec00081-001-s165><block.blockieren><en> Yet, if you are possessive, it tends to block positive response from others.
<G-vec00081-001-s165><block.blockieren><de> Wenn du aber besitzgierig bist, werden positive Rückmeldungen von Anderen blockiert.
<G-vec00081-001-s166><block.blockieren><en> A second client attempting to access a locked working copy will block for 10 seconds and then get an error.
<G-vec00081-001-s166><block.blockieren><de> Ein weiterer Client, der versucht, auf die gesperrte Arbeitskopie zuzugreifen, blockiert für 10 Sekunden und bekommt dann einen Fehler.
<G-vec00081-001-s167><block.blockieren><en> If you don't want us to recognize your computer, please configure your Internet browser to delete the cookies from your hard disk, block all cookies or warn you before a cookie is stored.
<G-vec00081-001-s167><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00081-001-s168><block.blockieren><en> BOT will block all traffic that is allowed in a normal IPCop installation.
<G-vec00081-001-s168><block.blockieren><de> BOT blockiert die Verbindungen, die in einer normalen IPCop Installation erlaubt sind.
<G-vec00081-001-s169><block.blockieren><en> If you found an advertisement that Adblock Plus doesn't block, please check first whether you are using the right filter subscription .
<G-vec00081-001-s169><block.blockieren><de> Falls Sie ein Werbebanner gefunden haben, das nicht von Adblock Plus blockiert wird, sollten Sie zuerst überprüfen, ob Sie die richtige Filterliste abonniert haben.
<G-vec00081-001-s170><block.blockieren><en> If the ownership structure does not correspond to economic reality, block or tax the cross-border payments.
<G-vec00081-001-s170><block.blockieren><de> Wenn die Eigentumsverhältnisse nicht der wirtschaftlichen Realität entsprechen, sollten grenzüberschreitende Zahlungen blockiert oder besteuert werden.
<G-vec00367-001-s152><block.blockieren><en> Page number in the upper left corner, making snowmen, snow, combined with permanent erosion should block them for 30 seconds.
<G-vec00367-001-s152><block.blockieren><de> Seitenzahl in der oberen linken Ecke, so dass Schneemänner, Schnee, mit ständigen Erosion kombiniert sollten sie für 30 Sekunden blockiert.
<G-vec00367-001-s153><block.blockieren><en> "If you do not want us to recognize your computer, please set your internet browser to ""Delete Cookies"" from your computer hard drive, to block cookies or to receive a warning before a cookie is stored."
<G-vec00367-001-s153><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00367-001-s154><block.blockieren><en> You can set your browser to block cookies from Google Analytics.
<G-vec00367-001-s154><block.blockieren><de> Sie können Ihren Browser so einstellen, dass Cookies von Google Analytics blockiert werden.
<G-vec00367-001-s155><block.blockieren><en> The Government enforces a blacklist of domains to block specific sites for illicit content.
<G-vec00367-001-s155><block.blockieren><de> Die Regierung setzt eine Blacklist durch, die bestimmte Domains mit illegalen Inhalten blockiert.
<G-vec00367-001-s156><block.blockieren><en> Anti-Banner will not block banners from this list.
<G-vec00367-001-s156><block.blockieren><de> Die Banner aus dieser Liste werden nicht von Anti-Banner blockiert.
<G-vec00367-001-s157><block.blockieren><en> In some cases such networks block sites such as Facebook, YouTube or other social media or gaming sites.
<G-vec00367-001-s157><block.blockieren><de> Bestimmte Webseiten wie Facebook, YouTube oder Online-Gaming-Seiten werden vom Netzwerk-Admin einfach per Firewall blockiert.
<G-vec00367-001-s158><block.blockieren><en> 2 - Please check that your Internet Browser (especially Internet Explorer) didn't block the download (if so, an Information Bar appears at the top part of your browser)
<G-vec00367-001-s158><block.blockieren><de> 2 - Prüfen Sie, daß Ihr Browser (insbesondere Internet Explorer), das Downloaden nicht blockiert hat (eine Informationsleiste erscheint in oberem Teil des Browsers).
<G-vec00367-001-s159><block.blockieren><en> On the positive side, it should be noted that the nuclear weapons states did not block this minimal consensus.
<G-vec00367-001-s159><block.blockieren><de> Positiv bleibt auch festzuhalten, dass die Nuklearwaffenstaaten diesen Minimalkonsens nicht blockiert haben.
<G-vec00367-001-s160><block.blockieren><en> You can adjust the settings in your browser in order to restrict or block cookies that are set by the Site (or any other site on the Internet).
<G-vec00367-001-s160><block.blockieren><de> Sie können die Einstellungen Ihres Browsers so anpassen, dass Cookies, die von der Website (oder einer anderen Website im Internet) gesetzt werden, beschränkt oder blockiert werden.
<G-vec00367-001-s161><block.blockieren><en> The administrator can decide to block the potential detected threat or exclude it by selecting Add Exclusion to Policy .
<G-vec00367-001-s161><block.blockieren><de> Der Administrator kann dann entscheiden, ob die erkannte potenzielle Bedrohung blockiert werden soll, oder sie über die Option Ausnahme zu Richtlinie hinzufügen ausschließen.
<G-vec00367-001-s162><block.blockieren><en> We have managed to block so much.
<G-vec00367-001-s162><block.blockieren><de> Wir haben bereits sehr vieles erfolgreich blockiert.
<G-vec00367-001-s163><block.blockieren><en> For example, you can configure a rule to explicitly block outbound traffic to a specific computer through the firewall but allow the same traffic to other computers.
<G-vec00367-001-s163><block.blockieren><de> Beispielsweise können Sie eine Regel so konfigurieren, dass sie ausdrücklich durch die Firewall ausgehenden Datenverkehr blockiert, jedoch denselben Datenverkehr zulässt, wenn er an andere Computer gesendet wird.
<G-vec00367-001-s164><block.blockieren><en> However, there have outraged guggulsterones of trainable order unisom professional and av block, reacting familial expulsion block, acclimated for the spite of hypertension.
<G-vec00367-001-s164><block.blockieren><de> Es hat jedoch empörte Guggulsterone der trainierbaren Ordnung unisom professional und av blockiert, die familiäre Vertreibungssperre reagierten, gewöhnt für Hypertonie.
<G-vec00367-001-s165><block.blockieren><en> Yet, if you are possessive, it tends to block positive response from others.
<G-vec00367-001-s165><block.blockieren><de> Wenn du aber besitzgierig bist, werden positive Rückmeldungen von Anderen blockiert.
<G-vec00367-001-s166><block.blockieren><en> A second client attempting to access a locked working copy will block for 10 seconds and then get an error.
<G-vec00367-001-s166><block.blockieren><de> Ein weiterer Client, der versucht, auf die gesperrte Arbeitskopie zuzugreifen, blockiert für 10 Sekunden und bekommt dann einen Fehler.
<G-vec00367-001-s167><block.blockieren><en> If you don't want us to recognize your computer, please configure your Internet browser to delete the cookies from your hard disk, block all cookies or warn you before a cookie is stored.
<G-vec00367-001-s167><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00367-001-s168><block.blockieren><en> BOT will block all traffic that is allowed in a normal IPCop installation.
<G-vec00367-001-s168><block.blockieren><de> BOT blockiert die Verbindungen, die in einer normalen IPCop Installation erlaubt sind.
<G-vec00367-001-s169><block.blockieren><en> If you found an advertisement that Adblock Plus doesn't block, please check first whether you are using the right filter subscription .
<G-vec00367-001-s169><block.blockieren><de> Falls Sie ein Werbebanner gefunden haben, das nicht von Adblock Plus blockiert wird, sollten Sie zuerst überprüfen, ob Sie die richtige Filterliste abonniert haben.
<G-vec00367-001-s170><block.blockieren><en> If the ownership structure does not correspond to economic reality, block or tax the cross-border payments.
<G-vec00367-001-s170><block.blockieren><de> Wenn die Eigentumsverhältnisse nicht der wirtschaftlichen Realität entsprechen, sollten grenzüberschreitende Zahlungen blockiert oder besteuert werden.
<G-vec00081-001-s266><block.sperren><en> 4 letter a) Privacy Code article 4 point 2) GDPR and precisely: collecting, registration, organization, storage, consultation, elaboration, modification, selection, comparison, se, interconnection, block, communication, cancellation, and destruction of data.
<G-vec00081-001-s266><block.sperren><de> 4 Buchstabe a) Datenschutzgesetz und Artikel 4, Punkt 2 DSGVO angegebenen Vorgänge und genau: Erheben, Erfassen, Eintragung, Organisation, Speicherung, Abfragen, Bearbeitung, Veränderung, Auslesen, Auszug, Abgleich, Verknüpfung, Sperre, Offenlegung, Löschung und Vernichtung der Daten.
<G-vec00081-001-s267><block.sperren><en> "The customer has not been assigned a status with the "" Block "" function for the "" Internal Shipping Document (MLI)"" workflow category."
<G-vec00081-001-s267><block.sperren><de> "Dem Kunden ist kein Zustand mit der Funktion "" Sperre "" für den Workflow-Bereich "" Interner Lieferschein (MLI)"" zugeordnet."
<G-vec00081-001-s268><block.sperren><en> "the part of the quote BOM line has a status with the ""Block"" function assigned."
<G-vec00081-001-s268><block.sperren><de> "dem Teil der Angebotsstücklistenposition ein Zustand mit der Funktion ""Sperre"" zugeordnet ist."
<G-vec00081-001-s269><block.sperren><en> The access had the name Block 343 and could be barred with iron bars in the road and iron grilles.
<G-vec00081-001-s269><block.sperren><de> Der Zugang hatte den Namen Sperre 343 und konnte mit Eisenstangen in den Straßen- und Eisengitter versperrt werden.
<G-vec00081-001-s270><block.sperren><en> "The credit has not been assigned a status with the "" Block "" function for the "" Invoice (VFR)"" workflow category."
<G-vec00081-001-s270><block.sperren><de> "Der Gutschrift ist kein Zustand mit der Funktion "" Sperre "" für den Workflow-Bereich "" Rechnung (VFR)"" zugeordnet."
<G-vec00081-001-s271><block.sperren><en> "The withdrawal notice has not been assigned a status with the ""Block"" function for the ""Withdrawal Notices Customer (MLE)"" workflow category."
<G-vec00081-001-s271><block.sperren><de> "Der Entnahmemeldung ist kein Zustand mit der Funktion ""Sperre"" für den Workflow-Bereich ""Entnahmemeldungen Kunde (MLE)"" zugeordnet."
<G-vec00081-001-s272><block.sperren><en> The block may only be lifted after a special request by the user to DENSO or after a new registration.
<G-vec00081-001-s272><block.sperren><de> Die Aufhebung der Sperre ist erst nach gesondertem Antrag des Nutzers bei DENSO oder nach neuer Registrierung möglich.
<G-vec00081-001-s273><block.sperren><en> "The customer has not been assigned a status with the "" Block "" function for the "" Order (Standard Order) (VU)"" workflow category."
<G-vec00081-001-s273><block.sperren><de> "Dem Kunden ist kein Zustand mit der Funktion "" Sperre "" für den Workflow-Bereich "" Auftrag (Normalauftrag) (VU)"" zugeordnet."
<G-vec00081-001-s274><block.sperren><en> "The part has not been assigned a status with the "" Block "" function for the "" Standard BOM (P_S)"" workflow category."
<G-vec00081-001-s274><block.sperren><de> "Dem Teil ist kein Zustand mit der Funktion "" Sperre "" für den Workflow-Bereich "" Standardstückliste (P_S)"" zugeordnet."
<G-vec00081-001-s275><block.sperren><en> "The shipping document has not been assigned a status with the ""Block"" function for the workflow category of the corresponding transport document."
<G-vec00081-001-s275><block.sperren><de> "Dem Lieferschein ist kein Zustand mit der Funktion ""Sperre"" für den Workflow-Bereich des entsprechenden Transportbelegs zugeordnet."
<G-vec00081-001-s276><block.sperren><en> "The blanket purchase order has not been assigned a status with the ""Block"" function for the ""Blanket Purchase Order (E_RA)"" workflow category."
<G-vec00081-001-s276><block.sperren><de> "Der Rahmenbestellung ist kein Zustand mit der Funktion ""Sperre"" für den Workflow-Bereich ""Rahmenbestellung (E_RA)"" zugeordnet."
<G-vec00081-001-s277><block.sperren><en> Block a Pinterest profile to prevent someone from following you, messaging you or interacting with your Pins.
<G-vec00081-001-s277><block.sperren><de> Sperre das Pinterest-Profil eines anderen Nutzers, um zu verhindern, dass dieser dir folgt, dir Nachrichten sendet oder mit deinen Pins interagiert.
<G-vec00081-001-s278><block.sperren><en> "The parts have not been assigned any statuses with the "" Block "" function for the "" Demo Shipping Document (VUD)"" workflow category."
<G-vec00081-001-s278><block.sperren><de> "Den Teilen sind keine Zustände mit der Funktion "" Sperre "" für den Workflow-Bereich "" Demo-Lieferschein (VUD)"" zugeordnet."
<G-vec00081-001-s279><block.sperren><en> "the part (assembly) of the subordinate work order has a status with the ""Block"" function assigned."
<G-vec00081-001-s279><block.sperren><de> "dem Teil (Baugruppe) des untergeordneten Produktionsauftrags ein Zustand mit der Funktion ""Sperre"" zugeordnet ist."
<G-vec00081-001-s280><block.sperren><en> You have also the right to require the cancellation, anonymisation or the block of data processed in breach of the law, as well as to oppose in any event, for legitimate reasons, to their processing.
<G-vec00081-001-s280><block.sperren><de> Sie haben auch das Recht, die Löschung, Anonymisierung oder Sperre der widerrechtlich vearbeiteten Daten zu verlangen, und sich aus legitimen Gründen deren Verarbeitung zu widersetzen.
<G-vec00081-001-s281><block.sperren><en> "The supplier has not been assigned a status with the "" Block "" function for the "" Material Resource Planning (MDD)"" workflow category."
<G-vec00081-001-s281><block.sperren><de> "Dem Lieferanten ist kein Zustand mit der Funktion "" Sperre "" für den Workflow-Bereich "" Disposition (MDD)"" zugeordnet."
<G-vec00081-001-s282><block.sperren><en> "The quote has not been assigned a status with the ""Block"" function for the ""Quote (VN)"" workflow category."
<G-vec00081-001-s282><block.sperren><de> "Dem Angebot ist kein Zustand mit der Funktion ""Sperre"" für den Workflow-Bereich ""Angebot (VN)"" zugeordnet."
<G-vec00081-001-s283><block.sperren><en> "The customer of the shipping document has not been assigned a status with the ""Block"" function for the workflow category of the corresponding transport document."
<G-vec00081-001-s283><block.sperren><de> "Dem Kunden des Lieferscheins ist kein Zustand mit der Funktion ""Sperre"" für den Workflow-Bereich des entsprechenden Transportbelegs zugeordnet."
<G-vec00081-001-s284><block.sperren><en> "The screen displays the statuses of the part with the "" Block "" function for the "" Stock Receipt (E_WE)"" workflow category."
<G-vec00081-001-s284><block.sperren><de> "In dem Screen werden die Zustände des Teils mit der Funktion "" Sperre "" für den Workflow-Bereich "" Wareneingang (E_WE)"" angezeigt."
<G-vec00081-001-s285><block.sperren><en> to delete or block your data.
<G-vec00081-001-s285><block.sperren><de> Ihre Daten löschen oder sperren zu lassen.
<G-vec00081-001-s286><block.sperren><en> 7.4 OSRAM may block access to the OSRAM Web Site at any time, especially if you violate your duties under these Terms of Use.
<G-vec00081-001-s286><block.sperren><de> 7.4 OSRAM darf den Zugang zur OSRAM-Website jederzeit sperren, insbesondere wenn Sie gegen Ihre Pflichten aus diesen Nutzungsbedingungen verstoßen.
<G-vec00081-001-s287><block.sperren><en> You can remotely block or unblock any app
<G-vec00081-001-s287><block.sperren><de> Sie können Apps aus der Ferne sperren und entsperren.
<G-vec00081-001-s288><block.sperren><en> To do so, select the Tools | Block Use for All Groups menu item.
<G-vec00081-001-s288><block.sperren><de> Wählen Sie dazu den Menüpunkt Extras | Benutzung für alle Gruppen sperren .
<G-vec00081-001-s289><block.sperren><en> Ghostery uses AI techniques to dynamically block ads in web pages.
<G-vec00081-001-s289><block.sperren><de> Ghostery verwendet KI-Techniken, um dynamisch Werbung auf Internetseiten zu sperren.
<G-vec00081-001-s290><block.sperren><en> We will then block your data in a timely fashion, so that you will no longer be contacted, and we will proceed to erase the data within a reasonable time period.
<G-vec00081-001-s290><block.sperren><de> Wir werden Ihre Daten dann zeitnah sperren, so dass Sie nicht weiter kontaktiert werden und nach einem angemessenen Zeitraum löschen.
<G-vec00081-001-s291><block.sperren><en> In that case, we will block your data on request.
<G-vec00081-001-s291><block.sperren><de> Soweit eine solche Verpflichtung besteht, sperren wir Ihre Daten auf Wunsch.
<G-vec00081-001-s292><block.sperren><en> In the event that Casino770 reasonably determines that you used or attempted to use a product endowed with artificial intelligence in combination with our Service or Software, Casino770 reserves the right to rescind or block your account immediately, and to not reimburse the amount credited to your account, and prohibit your access to all other Internet Sites, Services and Software offered by the corporation.
<G-vec00081-001-s292><block.sperren><de> Sollte Casino770 begründeterweise annehmen, dass Sie ein Martingal oder künstliche Intelligenz mit unserem Angebot oder unserer Software verwenden oder dies versuchen, behält sich Casino770 das Recht vor, Ihr Konto mit sofortiger Wirkung aufzulösen oder zu sperren, den auf Ihrem Konto verbleibenden Betrag nicht auszuzahlen un dIhnen den Zugang zu allen anderen Internetseiten, Angeboten und Software, die vom Unternehmen angeboten werden, zu verbieten.
<G-vec00081-001-s293><block.sperren><en> Objecting: In certain circumstances, you also have the right to object to processing of your personal data and to ask us to block, erase and restrict your personal data.
<G-vec00081-001-s293><block.sperren><de> Widerspruch: Unter bestimmten Umständen haben Sie auch das Recht, der Verarbeitung Ihrer personenbezogenen Daten zu widersprechen und uns zu bitten, Ihre personenbezogenen Daten zu sperren, zu löschen und einzuschränken.
<G-vec00081-001-s294><block.sperren><en> If you have registered more than one account - play with only one of them and notify the administration, so they can block the others.
<G-vec00081-001-s294><block.sperren><de> Hast du dich mit mehr als einem Account registriert, spiele nur noch mit einem und benachrichtige die Admins über das Feedback, so dass sie die anderen Accounts sperren können.
<G-vec00081-001-s295><block.sperren><en> You can also block apps or even lock the phone remotely.
<G-vec00081-001-s295><block.sperren><de> Sie können auch Apps sperren oder das Telefon remote sperren.
<G-vec00081-001-s296><block.sperren><en> At one point, Facebook will be yours block access to your account until it does not verify your real identity.
<G-vec00081-001-s296><block.sperren><de> An einem Punkt wird Facebook dein sein Sperren Sie den Zugriff auf Ihr Konto bis es nicht geht verifiziere deine wahre Identität.
<G-vec00081-001-s297><block.sperren><en> Block Camera Block the built-in camera, making it inaccessible to applications.
<G-vec00081-001-s297><block.sperren><de> Kamera sperren Sperren Sie die integrierte Kamera, sodass Anwendungen keinen Zugriff mehr darauf haben.
<G-vec00081-001-s298><block.sperren><en> Block Camera Block the built-in camera, making it inaccessible to applications.
<G-vec00081-001-s298><block.sperren><de> Kamera sperren Sperren Sie die integrierte Kamera, sodass Anwendungen keinen Zugriff mehr darauf haben.
<G-vec00081-001-s299><block.sperren><en> Tip: You can block your card at any time free of charge via e-banking or mobile banking .
<G-vec00081-001-s299><block.sperren><de> Tipp: Sperren Sie Ihre Kreditkarte jederzeit kostenlos via E-Banking oder Mobile Banking .
<G-vec00081-001-s300><block.sperren><en> If you no longer consent to the use of your data for advertising purposes, you may revoke this at any time; we will then block your data for this purpose.
<G-vec00081-001-s300><block.sperren><de> Falls Sie mit der Verwendung Ihrer Daten zu Werbezwecken nicht mehr einverstanden sind, können Sie dem jederzeit widersprechen; wir werden Ihre Daten dann für diesen Verwendungszweck sperren.
<G-vec00081-001-s301><block.sperren><en> The provider has the right to block users permanently and to refuse another access to the platform.
<G-vec00081-001-s301><block.sperren><de> Die Anbieterin hat das Recht, Nutzer dauerhaft zu sperren und einen erneuten Zugang zur Plattform zu verweigern.
<G-vec00081-001-s302><block.sperren><en> Nevertheless, if you block or erase cookie, it may not be possible to reset previously specified preferences or customised settings, and our capacity to customize the user experience will be limited. special offers
<G-vec00081-001-s302><block.sperren><de> Falls Sie Cookies sperren oder löschen kann es vorkommen, dass ein Reset zuvor gemachter bevorzugter, nutzerspezifischer Einstellungen nicht möglich ist; des Weiteren werden unsere Fähigkeiten, die Nutzererfahrung nutzerspezifisch zu gestalten, eingeschränkt.
<G-vec00081-001-s303><block.sperren><en> To block a program, you just need to add the executable file (.exe file) of the application.
<G-vec00081-001-s303><block.sperren><de> Zum Sperren eines Programms müssen Sie nur die ausführbare Datei (.exe-Datei) der Anwendung hinzufügen.
<G-vec00367-001-s285><block.sperren><en> to delete or block your data.
<G-vec00367-001-s285><block.sperren><de> Ihre Daten löschen oder sperren zu lassen.
<G-vec00367-001-s286><block.sperren><en> 7.4 OSRAM may block access to the OSRAM Web Site at any time, especially if you violate your duties under these Terms of Use.
<G-vec00367-001-s286><block.sperren><de> 7.4 OSRAM darf den Zugang zur OSRAM-Website jederzeit sperren, insbesondere wenn Sie gegen Ihre Pflichten aus diesen Nutzungsbedingungen verstoßen.
<G-vec00367-001-s287><block.sperren><en> You can remotely block or unblock any app
<G-vec00367-001-s287><block.sperren><de> Sie können Apps aus der Ferne sperren und entsperren.
<G-vec00367-001-s288><block.sperren><en> To do so, select the Tools | Block Use for All Groups menu item.
<G-vec00367-001-s288><block.sperren><de> Wählen Sie dazu den Menüpunkt Extras | Benutzung für alle Gruppen sperren .
<G-vec00367-001-s289><block.sperren><en> Ghostery uses AI techniques to dynamically block ads in web pages.
<G-vec00367-001-s289><block.sperren><de> Ghostery verwendet KI-Techniken, um dynamisch Werbung auf Internetseiten zu sperren.
<G-vec00367-001-s290><block.sperren><en> We will then block your data in a timely fashion, so that you will no longer be contacted, and we will proceed to erase the data within a reasonable time period.
<G-vec00367-001-s290><block.sperren><de> Wir werden Ihre Daten dann zeitnah sperren, so dass Sie nicht weiter kontaktiert werden und nach einem angemessenen Zeitraum löschen.
<G-vec00367-001-s291><block.sperren><en> In that case, we will block your data on request.
<G-vec00367-001-s291><block.sperren><de> Soweit eine solche Verpflichtung besteht, sperren wir Ihre Daten auf Wunsch.
<G-vec00367-001-s292><block.sperren><en> In the event that Casino770 reasonably determines that you used or attempted to use a product endowed with artificial intelligence in combination with our Service or Software, Casino770 reserves the right to rescind or block your account immediately, and to not reimburse the amount credited to your account, and prohibit your access to all other Internet Sites, Services and Software offered by the corporation.
<G-vec00367-001-s292><block.sperren><de> Sollte Casino770 begründeterweise annehmen, dass Sie ein Martingal oder künstliche Intelligenz mit unserem Angebot oder unserer Software verwenden oder dies versuchen, behält sich Casino770 das Recht vor, Ihr Konto mit sofortiger Wirkung aufzulösen oder zu sperren, den auf Ihrem Konto verbleibenden Betrag nicht auszuzahlen un dIhnen den Zugang zu allen anderen Internetseiten, Angeboten und Software, die vom Unternehmen angeboten werden, zu verbieten.
<G-vec00367-001-s293><block.sperren><en> Objecting: In certain circumstances, you also have the right to object to processing of your personal data and to ask us to block, erase and restrict your personal data.
<G-vec00367-001-s293><block.sperren><de> Widerspruch: Unter bestimmten Umständen haben Sie auch das Recht, der Verarbeitung Ihrer personenbezogenen Daten zu widersprechen und uns zu bitten, Ihre personenbezogenen Daten zu sperren, zu löschen und einzuschränken.
<G-vec00367-001-s294><block.sperren><en> If you have registered more than one account - play with only one of them and notify the administration, so they can block the others.
<G-vec00367-001-s294><block.sperren><de> Hast du dich mit mehr als einem Account registriert, spiele nur noch mit einem und benachrichtige die Admins über das Feedback, so dass sie die anderen Accounts sperren können.
<G-vec00367-001-s295><block.sperren><en> You can also block apps or even lock the phone remotely.
<G-vec00367-001-s295><block.sperren><de> Sie können auch Apps sperren oder das Telefon remote sperren.
<G-vec00367-001-s296><block.sperren><en> At one point, Facebook will be yours block access to your account until it does not verify your real identity.
<G-vec00367-001-s296><block.sperren><de> An einem Punkt wird Facebook dein sein Sperren Sie den Zugriff auf Ihr Konto bis es nicht geht verifiziere deine wahre Identität.
<G-vec00367-001-s297><block.sperren><en> Block Camera Block the built-in camera, making it inaccessible to applications.
<G-vec00367-001-s297><block.sperren><de> Kamera sperren Sperren Sie die integrierte Kamera, sodass Anwendungen keinen Zugriff mehr darauf haben.
<G-vec00367-001-s298><block.sperren><en> Block Camera Block the built-in camera, making it inaccessible to applications.
<G-vec00367-001-s298><block.sperren><de> Kamera sperren Sperren Sie die integrierte Kamera, sodass Anwendungen keinen Zugriff mehr darauf haben.
<G-vec00367-001-s299><block.sperren><en> Tip: You can block your card at any time free of charge via e-banking or mobile banking .
<G-vec00367-001-s299><block.sperren><de> Tipp: Sperren Sie Ihre Kreditkarte jederzeit kostenlos via E-Banking oder Mobile Banking .
<G-vec00367-001-s300><block.sperren><en> If you no longer consent to the use of your data for advertising purposes, you may revoke this at any time; we will then block your data for this purpose.
<G-vec00367-001-s300><block.sperren><de> Falls Sie mit der Verwendung Ihrer Daten zu Werbezwecken nicht mehr einverstanden sind, können Sie dem jederzeit widersprechen; wir werden Ihre Daten dann für diesen Verwendungszweck sperren.
<G-vec00367-001-s301><block.sperren><en> The provider has the right to block users permanently and to refuse another access to the platform.
<G-vec00367-001-s301><block.sperren><de> Die Anbieterin hat das Recht, Nutzer dauerhaft zu sperren und einen erneuten Zugang zur Plattform zu verweigern.
<G-vec00367-001-s302><block.sperren><en> Nevertheless, if you block or erase cookie, it may not be possible to reset previously specified preferences or customised settings, and our capacity to customize the user experience will be limited. special offers
<G-vec00367-001-s302><block.sperren><de> Falls Sie Cookies sperren oder löschen kann es vorkommen, dass ein Reset zuvor gemachter bevorzugter, nutzerspezifischer Einstellungen nicht möglich ist; des Weiteren werden unsere Fähigkeiten, die Nutzererfahrung nutzerspezifisch zu gestalten, eingeschränkt.
<G-vec00367-001-s303><block.sperren><en> To block a program, you just need to add the executable file (.exe file) of the application.
<G-vec00367-001-s303><block.sperren><de> Zum Sperren eines Programms müssen Sie nur die ausführbare Datei (.exe-Datei) der Anwendung hinzufügen.
<G-vec00081-001-s323><block.verhindern><en> Both candidates have built part of their campaigns in opposition to Peña Nieto, seeking to block the possible return of the PRI to power (after having governed Mexico for over 70 years, this party lost the presidency to the PAN in 2000).
<G-vec00081-001-s323><block.verhindern><de> Beide haben einen Teil ihrer Kampagne als Gegenposition zu Peña Nieto aufgebaut und versuchen damit, die Rückkehr der PRI an die Macht zu verhindern (nachdem diese Mexiko etwas mehr als 70 Jahre lang regiert hatte, hat sie die Präsidentschaft im Jahre 2000 an die PAN verloren hatte).
<G-vec00081-001-s324><block.verhindern><en> It doesn't block Iran's path to the bomb; it paves Iran's path to the bomb.
<G-vec00081-001-s324><block.verhindern><de> Die Atomgespräche verhindern nicht Irans Weg zur Bombe, sie bereiten Irans Weg zur Bombe.
<G-vec00081-001-s325><block.verhindern><en> Also in virtue of his knowledge of the German-speaking world, De Gasperi was able to block the mutilation of the Brenner.
<G-vec00081-001-s325><block.verhindern><de> Nicht zuletzt wegen seiner guten Kenntnis der deutschsprachigen Welt gelang es De Gasperi, eine „Verstümmelung“ des Brenners zu verhindern.
<G-vec00081-001-s326><block.verhindern><en> The giant house with its garden is located on the crest of a hill and appears to block with its building the 'descent' of the many small houses of the village.
<G-vec00081-001-s326><block.verhindern><de> "Die gigantische Villa mit ihrem Garten befindet sich auf dem Kamm eines Hügels und scheint mit ihrem Gebäude das ""Abrutschen"" der vielen kleinen Häuser des Dorfes zu verhindern."
<G-vec00081-001-s327><block.verhindern><en> Incognito mode and browser plugins like Privacy Badger help against this, but with Perfect Privacy you can just block this by activating the Tracking & Advertisement filter of TrackStop.
<G-vec00081-001-s327><block.verhindern><de> Inkognito-Modus und Browser-Plugins wie Privacy Badger schützen davor, aber mit Perfect Privacy können Sie dies ebenso verhindern indem Sie Tracking-Domains grundsätzlich blockieren.
<G-vec00081-001-s328><block.verhindern><en> It is a disgrace that an EPP government in Hungary is attempting to block Europe taking a common position on the issue.
<G-vec00081-001-s328><block.verhindern><de> Es ist eine Schande, dass die konservative EVP-Regierung in Ungarn versucht, einen gemeinsamen Standpunkt der EU in dieser Frage zu verhindern.
<G-vec00081-001-s329><block.verhindern><en> Currently, most of industries use copper or chromium zirconium copper as SAW contact tip, which has poor wear resistance and prone to block the tips caused by adhesion and splashing, or the welding wire and contact tips will be bonded and resulting in the failure of contact tips.
<G-vec00081-001-s329><block.verhindern><de> Derzeit verwenden die meisten Industriezweige Kupfer oder Chrom-Zirkoniumkupfer als SAW-Kontaktspitze, die eine schlechte Verschleißfestigkeit aufweist und anfällig ist, die Spitzen zu verhindern, die durch Adhäsion und Spritzen verursacht werden, oder der Schweißdraht und Kontaktspitzen werden verklebt und führen zum Ausfall des Kontakts Tipps.
<G-vec00081-001-s330><block.verhindern><en> Discover, track, contain, and block the progression of network-based advanced malware, zero-day attacks, and persistent threats.
<G-vec00081-001-s330><block.verhindern><de> Spüren Sie netzwerkbasierte, fortschrittliche Malware, Zero-Day-Angriffe und anhaltende Bedrohungen auf, verfolgen Sie sie nach, grenzen Sie sie ein und verhindern Sie deren Ausbreitung.
<G-vec00081-001-s331><block.verhindern><en> You can also block the loading of the plug-ins using add-ons for your browser, e.g.
<G-vec00081-001-s331><block.verhindern><de> Sie können das Laden der Plugins auch mit Add-Ons für Ihren Browser komplett verhindern, z.
<G-vec00081-001-s332><block.verhindern><en> Unwanted call blocking is a feature that helps block your Skype Number from receiving unwanted spam calls.
<G-vec00081-001-s332><block.verhindern><de> Das Blockieren unerwünschter Anrufe ist eine Funktion, mit dem Sie verhindern, dass Ihre Skype-Rufnummer unerwünschte Spam-Anrufe empfängt.
<G-vec00081-001-s333><block.verhindern><en> We can all function like the input/output elements in semiotic machines, like simple relays of television or the Internet that facilitate or block the transmission of information, communication or affects.
<G-vec00081-001-s333><block.verhindern><de> Wir alle können als Input/Output-Komponenten semiotischer Maschinen funktionieren, als einfache Relais von Fernsehen oder Internet, die die Weitergabe von Information, Kommunikation und Affekten bewerkstelligen und/oder verhindern.
<G-vec00081-001-s334><block.verhindern><en> In other words, they don't block the free software community from making full use of the manual.
<G-vec00081-001-s334><block.verhindern><de> In anderen Worten, sie verhindern nicht, dass die freie Software Gemeinschaft vollen Nutzen aus den Anleitungen zieht.
<G-vec00081-001-s335><block.verhindern><en> is able to influence the pathogen itself and thereby can block its infection process.
<G-vec00081-001-s335><block.verhindern><de> einen direkten Einfluss auf Pflanzenschädlinge ausüben und somit deren Infektion verhindern.
<G-vec00081-001-s336><block.verhindern><en> He even wanted to block the publishing.
<G-vec00081-001-s336><block.verhindern><de> Er wollte sogar dessen Veröffentlichung verhindern.
<G-vec00081-001-s337><block.verhindern><en> You can generally block storage of cookies by a corresponding setting of your browser software; however, we inform you that in this case you may not be able to use all functions of this website in their full scope.
<G-vec00081-001-s337><block.verhindern><de> Du kannst eine Speicherung von Cookies generell durch eine entsprechende Einstellung deiner Browser-Software verhindern; wir weisen dich jedoch darauf hin, dass du in diesem Fall gegebenenfalls nicht sämtliche Funktionen dieser Webseite vollumfänglich nutzen kannst.
<G-vec00081-001-s338><block.verhindern><en> You may block the installation of cookies by selecting the corresponding setting in your browser software; please, however, please note that you will not be able to use all the functions of this website to their full extent if you choose to do so.
<G-vec00081-001-s338><block.verhindern><de> Sie können die Installation der Cookies durch eine entsprechende Einstellung Ihrer Browser Software verhindern; wir weisen Sie jedoch darauf hin, dass Sie in diesem Fall gegebenenfalls nicht sämtliche Funktionen dieser Website voll umfänglich nutzen können.
<G-vec00081-001-s339><block.verhindern><en> The entire machinery set up by the Russian Revolution of March functioned to block the Congress of Soviets.
<G-vec00081-001-s339><block.verhindern><de> Der ganze, von der russischen Märzrevolution geschaffene Apparat funktionierte, um die Abhaltung des Sowjetkongresses zu verhindern.
<G-vec00081-001-s340><block.verhindern><en> "At any time, users can also block the use of their data in general, for all the solutions deployed, by selecting the ""opt-out option"" presented by the respective solution."
<G-vec00081-001-s340><block.verhindern><de> "Darüber hinaus hat der Nutzer jederzeit die Möglichkeit, die Datennutzung generell bei allen eingesetzten Lösungen zu verhindern, indem die seitens der Lösung angebotene sogenannte ""Opt-Out-Option"" gewählt wird."
<G-vec00081-001-s341><block.verhindern><en> The US Khazarian mafia is using both Democratic Vice-Presidential candidate Tim Kaine and Republican Presidential candidate Donald Trump to try to block the merger, the sources say.
<G-vec00081-001-s341><block.verhindern><de> Die Khasarische Mafia in den USA benutzt sowohl den Demokratischen Vize-Präsidentschafts-Kandidaten Tim Kaine als auch den Republikanischen Präsidentschafts-Kandidaten Donald Trump für die Versuche, den Zusammenschluss zu verhindern, sagen die Quellen.
<G-vec00367-001-s323><block.verhindern><en> Both candidates have built part of their campaigns in opposition to Peña Nieto, seeking to block the possible return of the PRI to power (after having governed Mexico for over 70 years, this party lost the presidency to the PAN in 2000).
<G-vec00367-001-s323><block.verhindern><de> Beide haben einen Teil ihrer Kampagne als Gegenposition zu Peña Nieto aufgebaut und versuchen damit, die Rückkehr der PRI an die Macht zu verhindern (nachdem diese Mexiko etwas mehr als 70 Jahre lang regiert hatte, hat sie die Präsidentschaft im Jahre 2000 an die PAN verloren hatte).
<G-vec00367-001-s324><block.verhindern><en> It doesn't block Iran's path to the bomb; it paves Iran's path to the bomb.
<G-vec00367-001-s324><block.verhindern><de> Die Atomgespräche verhindern nicht Irans Weg zur Bombe, sie bereiten Irans Weg zur Bombe.
<G-vec00367-001-s325><block.verhindern><en> Also in virtue of his knowledge of the German-speaking world, De Gasperi was able to block the mutilation of the Brenner.
<G-vec00367-001-s325><block.verhindern><de> Nicht zuletzt wegen seiner guten Kenntnis der deutschsprachigen Welt gelang es De Gasperi, eine „Verstümmelung“ des Brenners zu verhindern.
<G-vec00367-001-s326><block.verhindern><en> The giant house with its garden is located on the crest of a hill and appears to block with its building the 'descent' of the many small houses of the village.
<G-vec00367-001-s326><block.verhindern><de> "Die gigantische Villa mit ihrem Garten befindet sich auf dem Kamm eines Hügels und scheint mit ihrem Gebäude das ""Abrutschen"" der vielen kleinen Häuser des Dorfes zu verhindern."
<G-vec00367-001-s327><block.verhindern><en> Incognito mode and browser plugins like Privacy Badger help against this, but with Perfect Privacy you can just block this by activating the Tracking & Advertisement filter of TrackStop.
<G-vec00367-001-s327><block.verhindern><de> Inkognito-Modus und Browser-Plugins wie Privacy Badger schützen davor, aber mit Perfect Privacy können Sie dies ebenso verhindern indem Sie Tracking-Domains grundsätzlich blockieren.
<G-vec00367-001-s328><block.verhindern><en> It is a disgrace that an EPP government in Hungary is attempting to block Europe taking a common position on the issue.
<G-vec00367-001-s328><block.verhindern><de> Es ist eine Schande, dass die konservative EVP-Regierung in Ungarn versucht, einen gemeinsamen Standpunkt der EU in dieser Frage zu verhindern.
<G-vec00367-001-s329><block.verhindern><en> Currently, most of industries use copper or chromium zirconium copper as SAW contact tip, which has poor wear resistance and prone to block the tips caused by adhesion and splashing, or the welding wire and contact tips will be bonded and resulting in the failure of contact tips.
<G-vec00367-001-s329><block.verhindern><de> Derzeit verwenden die meisten Industriezweige Kupfer oder Chrom-Zirkoniumkupfer als SAW-Kontaktspitze, die eine schlechte Verschleißfestigkeit aufweist und anfällig ist, die Spitzen zu verhindern, die durch Adhäsion und Spritzen verursacht werden, oder der Schweißdraht und Kontaktspitzen werden verklebt und führen zum Ausfall des Kontakts Tipps.
<G-vec00367-001-s330><block.verhindern><en> Discover, track, contain, and block the progression of network-based advanced malware, zero-day attacks, and persistent threats.
<G-vec00367-001-s330><block.verhindern><de> Spüren Sie netzwerkbasierte, fortschrittliche Malware, Zero-Day-Angriffe und anhaltende Bedrohungen auf, verfolgen Sie sie nach, grenzen Sie sie ein und verhindern Sie deren Ausbreitung.
<G-vec00367-001-s331><block.verhindern><en> You can also block the loading of the plug-ins using add-ons for your browser, e.g.
<G-vec00367-001-s331><block.verhindern><de> Sie können das Laden der Plugins auch mit Add-Ons für Ihren Browser komplett verhindern, z.
<G-vec00367-001-s332><block.verhindern><en> Unwanted call blocking is a feature that helps block your Skype Number from receiving unwanted spam calls.
<G-vec00367-001-s332><block.verhindern><de> Das Blockieren unerwünschter Anrufe ist eine Funktion, mit dem Sie verhindern, dass Ihre Skype-Rufnummer unerwünschte Spam-Anrufe empfängt.
<G-vec00367-001-s333><block.verhindern><en> We can all function like the input/output elements in semiotic machines, like simple relays of television or the Internet that facilitate or block the transmission of information, communication or affects.
<G-vec00367-001-s333><block.verhindern><de> Wir alle können als Input/Output-Komponenten semiotischer Maschinen funktionieren, als einfache Relais von Fernsehen oder Internet, die die Weitergabe von Information, Kommunikation und Affekten bewerkstelligen und/oder verhindern.
<G-vec00367-001-s334><block.verhindern><en> In other words, they don't block the free software community from making full use of the manual.
<G-vec00367-001-s334><block.verhindern><de> In anderen Worten, sie verhindern nicht, dass die freie Software Gemeinschaft vollen Nutzen aus den Anleitungen zieht.
<G-vec00367-001-s335><block.verhindern><en> is able to influence the pathogen itself and thereby can block its infection process.
<G-vec00367-001-s335><block.verhindern><de> einen direkten Einfluss auf Pflanzenschädlinge ausüben und somit deren Infektion verhindern.
<G-vec00367-001-s336><block.verhindern><en> He even wanted to block the publishing.
<G-vec00367-001-s336><block.verhindern><de> Er wollte sogar dessen Veröffentlichung verhindern.
<G-vec00367-001-s337><block.verhindern><en> You can generally block storage of cookies by a corresponding setting of your browser software; however, we inform you that in this case you may not be able to use all functions of this website in their full scope.
<G-vec00367-001-s337><block.verhindern><de> Du kannst eine Speicherung von Cookies generell durch eine entsprechende Einstellung deiner Browser-Software verhindern; wir weisen dich jedoch darauf hin, dass du in diesem Fall gegebenenfalls nicht sämtliche Funktionen dieser Webseite vollumfänglich nutzen kannst.
<G-vec00367-001-s338><block.verhindern><en> You may block the installation of cookies by selecting the corresponding setting in your browser software; please, however, please note that you will not be able to use all the functions of this website to their full extent if you choose to do so.
<G-vec00367-001-s338><block.verhindern><de> Sie können die Installation der Cookies durch eine entsprechende Einstellung Ihrer Browser Software verhindern; wir weisen Sie jedoch darauf hin, dass Sie in diesem Fall gegebenenfalls nicht sämtliche Funktionen dieser Website voll umfänglich nutzen können.
<G-vec00367-001-s339><block.verhindern><en> The entire machinery set up by the Russian Revolution of March functioned to block the Congress of Soviets.
<G-vec00367-001-s339><block.verhindern><de> Der ganze, von der russischen Märzrevolution geschaffene Apparat funktionierte, um die Abhaltung des Sowjetkongresses zu verhindern.
<G-vec00367-001-s340><block.verhindern><en> "At any time, users can also block the use of their data in general, for all the solutions deployed, by selecting the ""opt-out option"" presented by the respective solution."
<G-vec00367-001-s340><block.verhindern><de> "Darüber hinaus hat der Nutzer jederzeit die Möglichkeit, die Datennutzung generell bei allen eingesetzten Lösungen zu verhindern, indem die seitens der Lösung angebotene sogenannte ""Opt-Out-Option"" gewählt wird."
<G-vec00367-001-s341><block.verhindern><en> The US Khazarian mafia is using both Democratic Vice-Presidential candidate Tim Kaine and Republican Presidential candidate Donald Trump to try to block the merger, the sources say.
<G-vec00367-001-s341><block.verhindern><de> Die Khasarische Mafia in den USA benutzt sowohl den Demokratischen Vize-Präsidentschafts-Kandidaten Tim Kaine als auch den Republikanischen Präsidentschafts-Kandidaten Donald Trump für die Versuche, den Zusammenschluss zu verhindern, sagen die Quellen.
<G-vec00081-001-s342><block.versperren><en> No single party should be allowed to unilaterally block the road to peace.
<G-vec00081-001-s342><block.versperren><de> Keine Partei darf einseitig die Straße zum Frieden versperren.
<G-vec00081-001-s343><block.versperren><en> Although this could decrease the exit time, it also increases the chances of an accident – and an injured person at a door would block others from escaping (Figure 3).
<G-vec00081-001-s343><block.versperren><de> Obwohl dies die Zeit zum Verlassen des Raumes verringern könnte, erhöht es auch die Wahrscheinlichkeit eines Unfalls – und eine verletzte Person vor einer Tür würde anderen den Fluchtweg versperren (Abbildung 3).
<G-vec00081-001-s344><block.versperren><en> The path leads through sound clouds: crystalline musical shapes that seem to block the view in various formations and densities.
<G-vec00081-001-s344><block.versperren><de> Der Weg führt durch Klangwolken: kristalline musikalische Gestalten, die in unterschiedlicher Formung und Dichte den Blick zu versperren scheinen.
<G-vec00081-001-s345><block.versperren><en> "The goal of populist revolution in Latin America is to block the return to power of the corrupt minority; Putin's system of ""sovereign democracy"" prevents the dangerous majority being represented politically."
<G-vec00081-001-s345><block.versperren><de> "Ziel der populistischen Revolutionen in Lateinamerika ist es, einer korrupten Minderheit für immer den Weg zurück an die Macht zu versperren; und Putins System der ""souveränen Demokratie"" verhindert, dass die gefährliche Mehrheit politisch repräsentiert ist."
<G-vec00081-001-s346><block.versperren><en> Clouds in the east block the view of the rising eclipsed moon.
<G-vec00081-001-s346><block.versperren><de> Wolken im Osten versperren den Blick auf den aufgehenden verfinsterten Mond.
<G-vec00081-001-s347><block.versperren><en> Once you have reached the great circus (4), a few tendrils will grow behind you and block the exit.
<G-vec00081-001-s347><block.versperren><de> Habt ihr den großen Platz auf dem Garten erreicht (4), wachsen hinter euch ein paar Ranken und versperren somit den Ausgang.
<G-vec00081-001-s348><block.versperren><en> Located at 1538 m above sea level, it was meant to block the access to Val di Sole.
<G-vec00081-001-s348><block.versperren><de> In einer Höhe von 1.538 m gelegen, hatte es die Aufgabe, den Zugang zum Val di Sole zu versperren.
<G-vec00081-001-s349><block.versperren><en> This single network requires a constant maintenance because dead leaves or falling rocks would early have done all to block.
<G-vec00081-001-s349><block.versperren><de> Dieses einmalige Netz verlangt eine konstante Wartung, denn welke Blätter oder Steinschläge würden früh alles machen zu versperren.
<G-vec00081-001-s350><block.versperren><en> They block the way to fulfilment.
<G-vec00081-001-s350><block.versperren><de> Sie versperren ihnen den Weg zur Erfüllung.
<G-vec00081-001-s351><block.versperren><en> The real purpose of the CCP is to use the so-called welcome group to block the protesters.
<G-vec00081-001-s351><block.versperren><de> Der wahre Zweck der KPC besteht darin, die sogenannte Begrüßungs-Gruppe zu benutzen, um die Protestierenden zu versperren.
<G-vec00081-001-s352><block.versperren><en> The only changes are grazing sheep which sometimes block the way.
<G-vec00081-001-s352><block.versperren><de> Die einzige Abwechselung sind grasende Schafe die manchmal den Weg versperren.
<G-vec00081-001-s353><block.versperren><en> This task isn't made too easy for you, since there are numerous obstacles and traps to block your way.
<G-vec00081-001-s353><block.versperren><de> Diese Aufgabe wird dir nicht leicht gemacht, denn zahlreiche Fallen und Hindernisse versperren den Weg.
<G-vec00081-001-s354><block.versperren><en> Help us to conquer the menace of evil, which so easily takes root in the hearts of the people of today, and whose immeasurable effects already weigh down upon our modern world and seem to block the paths towards the future!
<G-vec00081-001-s354><block.versperren><de> O Unbeflecktes Herz, hilf uns, die Gefahr des Bösen zu überwinden, das so leicht in den Herzen der heutigen Menschen Wurzel faßt und dessen unermeßliche Auswirkungen über dem heutigen Leben lasten und den Weg in die Zukunft zu versperren scheinen.
<G-vec00081-001-s355><block.versperren><en> Instead of luxury shops one can only see concrete walls, asphalt streets and there like to block the sight of industrial facilities, scientific institutes and a women’s prison.
<G-vec00081-001-s355><block.versperren><de> Statt luxuriöser Geschäfte säumen nun Mauern aus Betonfertigteilen die einsamen Asphaltpisten, um die Sicht auf die ehemaligen Musterbetriebe der Schwerindustrie, Forschungsinstitute und ein Frauengefängnis zu versperren.
<G-vec00081-001-s356><block.versperren><en> It was clear that the Chinese government had applied pressure just before Jiang's arrival, as three coaches arrived to partly block his view of any practitioners.
<G-vec00081-001-s356><block.versperren><de> Es war klar, dass die chinesische Regierung kurz vor Jiangs Ankunft Druck ausgeübt hatte, als drei Reisebusse kamen, um seinen Anblick auf Praktizierende zu versperren.
<G-vec00081-001-s357><block.versperren><en> It was intended to block his view of his brother's nearby residence, the grander Tudenham House.
<G-vec00081-001-s357><block.versperren><de> Sein Erbauer Lord Belvedere, der Eigentümer des Jagdhauses, wollte damit den Blick auf die nahe gelegene Residenz seines Bruders, das noch grandiosere Tudenham House, versperren.
<G-vec00081-001-s358><block.versperren><en> Clouds block the view on the Southern Alps at Lake Tekapo.
<G-vec00081-001-s358><block.versperren><de> Wolken versperren die Sicht auf die Southern Alps beim Lake Tekapo.
<G-vec00081-001-s359><block.versperren><en> Beware of office furniture and objects falling from the sky to block your path.
<G-vec00081-001-s359><block.versperren><de> Vermeide Büromöbel und von oben herabfallende Objekte, die dir den Weg versperren.
<G-vec00081-001-s360><block.versperren><en> Don't hesitate to damage the cubes if you feel they block your way to the victory.
<G-vec00081-001-s360><block.versperren><de> Zögere nicht, Barrieren zu zerstören, wenn sie dir offensichtlich den Weg zum Sieg versperren.
<G-vec00367-001-s342><block.versperren><en> No single party should be allowed to unilaterally block the road to peace.
<G-vec00367-001-s342><block.versperren><de> Keine Partei darf einseitig die Straße zum Frieden versperren.
<G-vec00367-001-s343><block.versperren><en> Although this could decrease the exit time, it also increases the chances of an accident – and an injured person at a door would block others from escaping (Figure 3).
<G-vec00367-001-s343><block.versperren><de> Obwohl dies die Zeit zum Verlassen des Raumes verringern könnte, erhöht es auch die Wahrscheinlichkeit eines Unfalls – und eine verletzte Person vor einer Tür würde anderen den Fluchtweg versperren (Abbildung 3).
<G-vec00367-001-s344><block.versperren><en> The path leads through sound clouds: crystalline musical shapes that seem to block the view in various formations and densities.
<G-vec00367-001-s344><block.versperren><de> Der Weg führt durch Klangwolken: kristalline musikalische Gestalten, die in unterschiedlicher Formung und Dichte den Blick zu versperren scheinen.
<G-vec00367-001-s345><block.versperren><en> "The goal of populist revolution in Latin America is to block the return to power of the corrupt minority; Putin's system of ""sovereign democracy"" prevents the dangerous majority being represented politically."
<G-vec00367-001-s345><block.versperren><de> "Ziel der populistischen Revolutionen in Lateinamerika ist es, einer korrupten Minderheit für immer den Weg zurück an die Macht zu versperren; und Putins System der ""souveränen Demokratie"" verhindert, dass die gefährliche Mehrheit politisch repräsentiert ist."
<G-vec00367-001-s346><block.versperren><en> Clouds in the east block the view of the rising eclipsed moon.
<G-vec00367-001-s346><block.versperren><de> Wolken im Osten versperren den Blick auf den aufgehenden verfinsterten Mond.
<G-vec00367-001-s347><block.versperren><en> Once you have reached the great circus (4), a few tendrils will grow behind you and block the exit.
<G-vec00367-001-s347><block.versperren><de> Habt ihr den großen Platz auf dem Garten erreicht (4), wachsen hinter euch ein paar Ranken und versperren somit den Ausgang.
<G-vec00367-001-s348><block.versperren><en> Located at 1538 m above sea level, it was meant to block the access to Val di Sole.
<G-vec00367-001-s348><block.versperren><de> In einer Höhe von 1.538 m gelegen, hatte es die Aufgabe, den Zugang zum Val di Sole zu versperren.
<G-vec00367-001-s349><block.versperren><en> This single network requires a constant maintenance because dead leaves or falling rocks would early have done all to block.
<G-vec00367-001-s349><block.versperren><de> Dieses einmalige Netz verlangt eine konstante Wartung, denn welke Blätter oder Steinschläge würden früh alles machen zu versperren.
<G-vec00367-001-s350><block.versperren><en> They block the way to fulfilment.
<G-vec00367-001-s350><block.versperren><de> Sie versperren ihnen den Weg zur Erfüllung.
<G-vec00367-001-s351><block.versperren><en> The real purpose of the CCP is to use the so-called welcome group to block the protesters.
<G-vec00367-001-s351><block.versperren><de> Der wahre Zweck der KPC besteht darin, die sogenannte Begrüßungs-Gruppe zu benutzen, um die Protestierenden zu versperren.
<G-vec00367-001-s352><block.versperren><en> The only changes are grazing sheep which sometimes block the way.
<G-vec00367-001-s352><block.versperren><de> Die einzige Abwechselung sind grasende Schafe die manchmal den Weg versperren.
<G-vec00367-001-s353><block.versperren><en> This task isn't made too easy for you, since there are numerous obstacles and traps to block your way.
<G-vec00367-001-s353><block.versperren><de> Diese Aufgabe wird dir nicht leicht gemacht, denn zahlreiche Fallen und Hindernisse versperren den Weg.
<G-vec00367-001-s354><block.versperren><en> Help us to conquer the menace of evil, which so easily takes root in the hearts of the people of today, and whose immeasurable effects already weigh down upon our modern world and seem to block the paths towards the future!
<G-vec00367-001-s354><block.versperren><de> O Unbeflecktes Herz, hilf uns, die Gefahr des Bösen zu überwinden, das so leicht in den Herzen der heutigen Menschen Wurzel faßt und dessen unermeßliche Auswirkungen über dem heutigen Leben lasten und den Weg in die Zukunft zu versperren scheinen.
<G-vec00367-001-s355><block.versperren><en> Instead of luxury shops one can only see concrete walls, asphalt streets and there like to block the sight of industrial facilities, scientific institutes and a women’s prison.
<G-vec00367-001-s355><block.versperren><de> Statt luxuriöser Geschäfte säumen nun Mauern aus Betonfertigteilen die einsamen Asphaltpisten, um die Sicht auf die ehemaligen Musterbetriebe der Schwerindustrie, Forschungsinstitute und ein Frauengefängnis zu versperren.
<G-vec00367-001-s356><block.versperren><en> It was clear that the Chinese government had applied pressure just before Jiang's arrival, as three coaches arrived to partly block his view of any practitioners.
<G-vec00367-001-s356><block.versperren><de> Es war klar, dass die chinesische Regierung kurz vor Jiangs Ankunft Druck ausgeübt hatte, als drei Reisebusse kamen, um seinen Anblick auf Praktizierende zu versperren.
<G-vec00367-001-s357><block.versperren><en> It was intended to block his view of his brother's nearby residence, the grander Tudenham House.
<G-vec00367-001-s357><block.versperren><de> Sein Erbauer Lord Belvedere, der Eigentümer des Jagdhauses, wollte damit den Blick auf die nahe gelegene Residenz seines Bruders, das noch grandiosere Tudenham House, versperren.
<G-vec00367-001-s358><block.versperren><en> Clouds block the view on the Southern Alps at Lake Tekapo.
<G-vec00367-001-s358><block.versperren><de> Wolken versperren die Sicht auf die Southern Alps beim Lake Tekapo.
<G-vec00367-001-s359><block.versperren><en> Beware of office furniture and objects falling from the sky to block your path.
<G-vec00367-001-s359><block.versperren><de> Vermeide Büromöbel und von oben herabfallende Objekte, die dir den Weg versperren.
<G-vec00367-001-s360><block.versperren><en> Don't hesitate to damage the cubes if you feel they block your way to the victory.
<G-vec00367-001-s360><block.versperren><de> Zögere nicht, Barrieren zu zerstören, wenn sie dir offensichtlich den Weg zum Sieg versperren.
