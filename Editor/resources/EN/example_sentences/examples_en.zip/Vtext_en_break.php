<G-vec00081-001-s038><break.abbrechen><en> """If we need to break in the middle of a job, we can easily save the settings, run a different job and reset back to the previous job at a later time."
<G-vec00081-001-s038><break.abbrechen><de> """Wenn wir bei der Hälfte eines Jobs abbrechen müssen, können wir die Einstellungen einfach speichern, einen anderen Job laufen lassen und später zu dem ursprünglichen Job zurückkehren."
<G-vec00081-001-s039><break.abbrechen><en> Also the kite was flying very bad and restless, too. I was ready to have a break and go home, as I felt that the wind was getting stronger.
<G-vec00081-001-s039><break.abbrechen><de> Ich wollte schon abbrechen und hatte mir vorgenommen einen größeren Drachen zu bauen, da bemerkte ich, dass der Wind auffrischte.
<G-vec00081-001-s040><break.abbrechen><en> 12 They will plunder your wealth and loot your merchandise; they will break down your walls and demolish your fine houses and throw your stones, timber and rubble into the sea.
<G-vec00081-001-s040><break.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00081-001-s041><break.abbrechen><en> It often happens that branches break under this enormous weight.
<G-vec00081-001-s041><break.abbrechen><de> Oft kommt es auch vor, dass Aeste durch dieses enorme Gewicht abbrechen.
<G-vec00081-001-s042><break.abbrechen><en> When a predator attacks, the lizard can break off its own tail as a means of distraction.
<G-vec00081-001-s042><break.abbrechen><de> Wenn Raubangriffe, die Eidechse sein eigenes Endstück als abbrechen können Mittel der Ablenkung.
<G-vec00081-001-s043><break.abbrechen><en> Then, starting at the base, bend the tough outer leaves back until they break off.
<G-vec00081-001-s043><break.abbrechen><de> Dann, beginnend an der Basis, biegen Sie die harten äußeren Blätter zurück, bis sie abbrechen.
<G-vec00081-001-s044><break.abbrechen><en> No moving parts such as adjuster wheels, lights, turbines, or other components that will sooner or later break or calcify.
<G-vec00081-001-s044><break.abbrechen><de> Ohne Umstell-Rädchen, Lämpchen, Turbinen oder andere bewegliche Teile, die früher oder später abbrechen oder verkalken.
<G-vec00081-001-s045><break.abbrechen><en> Lucas Auer: I would ban all parts that can easily break off the car.
<G-vec00081-001-s045><break.abbrechen><de> Lucas Auer: Ich würde alle Teile, die leicht abbrechen können, vom Auto verbannen.
<G-vec00081-001-s046><break.abbrechen><en> 16:39 I will also give you into their hand, and they shall throw down your vaulted place, and break down your lofty places; and they shall strip you of your clothes, and take your beautiful jewels; and they shall leave you naked and bare.
<G-vec00081-001-s046><break.abbrechen><de> 16:39 Und will dich in ihre Hände geben, daß sie deine Kapellen abbrechen und deine Altäre umreißen und dir deine Kleider ausziehen und dein schönes Gerät dir nehmen und dich nackt und bloß sitzen lassen.
<G-vec00081-001-s047><break.abbrechen><en> The For Each setting can be specified with or without the Break Loop If setting.
<G-vec00081-001-s047><break.abbrechen><de> Die For Each- Einstellung kann mit oder ohne die Schleife abbrechen, wenn -Einstellung definiert werden.
<G-vec00081-001-s048><break.abbrechen><en> Under no circumstances should you break off your German courses before this level, as otherwise you will quickly forget what you have learned.
<G-vec00081-001-s048><break.abbrechen><de> Ihren Deutschkurs sollten Sie auf keinen Fall vor dieser Stufe abbrechen, da Sie sonst das Gelernte schnell vergessen werden.
<G-vec00081-001-s049><break.abbrechen><en> As I stopped to look at a Géant de Bataille, which had three splendid blooms, I distinctly saw the stalk of one of the roses bend, close to me, as if an invisible hand had bent it, and then break, as if that hand had picked it!
<G-vec00081-001-s049><break.abbrechen><de> Als ich stehen blieb und eine Géanit des batailles betrachtete, die drei wundervolle Knospen trug, sah ich ganz deutlich, ganz nahe neben mir, einen der Stiele sich herumlegen, als ob eine unsichtbare Hand ihn gefaßt hätte, sah ihn abbrechen, wie wenn diese Hand ihn gepflückt.
<G-vec00081-001-s050><break.abbrechen><en> In addition, it is for the woman's benefit to break it off, to be able to meet a man who can be fully committed to having a relationship.
<G-vec00081-001-s050><break.abbrechen><de> Außerdem, ist es für die Frau die Nutzen für sie abbrechen, der Lage sein, einen Mann, der voll und ganz auf eine Beziehung begangen werden kann gerecht sein.
<G-vec00081-001-s051><break.abbrechen><en> The sand storm was too strong so we had to break up the mission half way down.
<G-vec00081-001-s051><break.abbrechen><de> Der Sandsturm war so stark, dass wir auf halber Strecke abbrechen mussten.
<G-vec00081-001-s052><break.abbrechen><en> Wearing makeup every day can dry out your lashes and irritate your eyes, which can cause your lashes to break or even fall out.
<G-vec00081-001-s052><break.abbrechen><de> Jeden Tag Make-up zu tragen kann deine Wimpern austrocknen und deine Augen reizen, was bewirken kann, dass die Wimpern abbrechen oder sogar ausfallen.
<G-vec00081-001-s053><break.abbrechen><en> No (inaudible), I must unfortunately break the discussion off now, sorry.
<G-vec00081-001-s053><break.abbrechen><de> Nein (nervöses Gestammle), ich muss jetzt leider das Gespräch abbrechen.
<G-vec00081-001-s054><break.abbrechen><en> This method is not as reliable as using software solutions though, as the download can break or the service may be down at exactly that moment when you need it.
<G-vec00081-001-s054><break.abbrechen><de> Diese Methode ist jedoch nicht so zuverlässig wie die Verwendung von Softwarelösungen, da der Download abbrechen kann oder der Dienst genau dann, wenn Sie ihn benötigen, ausfällt.
<G-vec00081-001-s055><break.abbrechen><en> Grandma would break off a leaf from her Aloe Vera plant and come to my rescue.
<G-vec00081-001-s055><break.abbrechen><de> Großmutter würde ein Blatt von ihrem Aloe Vera Betrieb abbrechen und zu meiner Rettung kommen.
<G-vec00081-001-s056><break.abbrechen><en> In the Break dialog, click the All button to select all memebers, click the Ok button, and finally click the Yes button in the new Kutools for Outlook dialog.
<G-vec00081-001-s056><break.abbrechen><de> "Klicken Sie im Dialogfeld ""Abbrechen"" auf das Symbol Alle Klicken Sie auf die Schaltfläche, um alle Mitglieder auszuwählen Ok Klicken Sie auf und dann auf Ja Schaltfläche im neuen Kutools für Outlook-Dialogfeld."
<G-vec00081-001-s076><break.aufbrechen><en> "I thought: ""The Fa can break all attachments, the Fa can destroy all evil, the Fa can shatter all lies, and the Fa can strengthen righteous thoughts."" (from ""Drive Out Interference"") I decided to study the Fa with him."
<G-vec00081-001-s076><break.aufbrechen><de> Doch ich kann es nicht in die Praxis umsetzen.“ Ich dachte nach: “Das Fa kann allen Eigensinn aufbrechen, das Fa kann alles Böse besiegen, das Fa kann alle Lügen strafen, das Fa kann den rechten Gedanken festigen.“ (Aus „Störungen beseitigen“ in Essentielles für weitere Fortschritte) Ich beschloss, das Fa mit ihm zu lernen.
<G-vec00081-001-s077><break.aufbrechen><en> Food The cockatoos live mainly from plants, with what they can break also very hard nuts and seeds with the powerful beaks open.
<G-vec00081-001-s077><break.aufbrechen><de> Nahrung Die Kakadus ernähren sich überwiegend von Pflanzen, wobei sie auch sehr harte Nüsse und Samen mit den kräftigen Schnäbeln aufbrechen können.
<G-vec00081-001-s078><break.aufbrechen><en> Malt is too finely crushed -> only break grains up, do not mill too finely.
<G-vec00081-001-s078><break.aufbrechen><de> Malz ist zu fein geschrotet -> Körner nur aufbrechen, nicht feinmahlen.
<G-vec00081-001-s079><break.aufbrechen><en> By 2025, this will be nothing less than the fourth industrial revolution and will break down, regroup or even completely replace many achievements of the previous industrial revolutions, such as mechanisation, engines and the production line.
<G-vec00081-001-s079><break.aufbrechen><de> Dies soll bis 2025 nichts weniger als die Vierte Industrielle Revolution werden und viele Errungenschaften der vorhergehenden industriellen Revolutionen wie Mechanisierung, Kraftmaschinen und Fließband aufbrechen, neu kombinieren oder gar restlos ersetzen.
<G-vec00081-001-s080><break.aufbrechen><en> """Again, it is with sensuality for the reason, sensuality for the source... that [men] break into windows, seize plunder, commit burglary, ambush highways, commit adultery, and when they are captured, kings have them tortured in many ways."
<G-vec00081-001-s080><break.aufbrechen><de> """Nochmals, es ist mit Sinnlichkeit als der Grund, Sinnlichkeit als die Quelle... daß [Menschen] Fenster aufbrechen, Plünderei ergreifen, Einbruch begehen, Landstraßen überfallen, Vergewaltigung begehen, und dann werden sie gefangen von, Könige lassen sie auf verschiedene Weise quälen."
<G-vec00081-001-s081><break.aufbrechen><en> And you’ll grow so fast that this shell, which is this human conditioning and egos will just break open.
<G-vec00081-001-s081><break.aufbrechen><de> Das Wachstum hat begonnen und ihr werdet so schnell wachsen, dass diese Schale, die die menschlichen Konditionierungen und das Ego bilden, einfach aufbrechen wird.
<G-vec00081-001-s082><break.aufbrechen><en> It has turned out to be a quiet, thoughtful film, which dedicates itself above all to the question of why one believes in having to break open.
<G-vec00081-001-s082><break.aufbrechen><de> Ein stiller, nachdenklicher Reisefilm ist es geworden, der sich vor allem der Frage widmet, warum man glaubt, aufbrechen zu müssen.
<G-vec00081-001-s083><break.aufbrechen><en> If you have Kutools for Excel, with its Find and Break Broken Links feature, you can view and locate the link cells, and break them as you need.
<G-vec00081-001-s083><break.aufbrechen><de> Wenn Sie Kutools for ExcelMit seinen Finde und zerbrich gebrochene Links Mit dieser Funktion können Sie die Verbindungszellen anzeigen und lokalisieren und sie nach Bedarf aufbrechen.
<G-vec00081-001-s084><break.aufbrechen><en> Occasional thieves have virtually no chance and are discouraged because it is almost impossible to break the closed and locked windows with simple tools like screwdriver, tongs and wedges.
<G-vec00081-001-s084><break.aufbrechen><de> Gelegenheitsdiebe haben kaum eine Chance, denn ein Aufbrechen der verschlossenen und verriegelten Fenster mit Schraubendreher, Zange und Keil ist fast unmöglich.
<G-vec00081-001-s085><break.aufbrechen><en> And because the electronics are distributed around the ankle, it is also not so easy to break or cut through the ankle bracelet – and this despite the fact that that no tools are needed to attach and remove the devices.
<G-vec00081-001-s085><break.aufbrechen><de> Und weil die Elektronik um den Fuß herum verteilt ist, kann man die Fessel auch nicht so leicht aufbrechen oder durchschneiden – und das, obwohl man für das Anbringen und Entfernen der Fussfesseln keine Werkzeuge benötigt.
<G-vec00081-001-s086><break.aufbrechen><en> First, break open all three links of one of the pieces of chain.
<G-vec00081-001-s086><break.aufbrechen><de> Zuerst muss man die drei Glieder von einer der Stücke Kette aufbrechen.
<G-vec00081-001-s087><break.aufbrechen><en> This term denotes substance mixtures which break up oil films on the surface of the water and which facilitate the formation of dispersions (i.e. fine droplets).
<G-vec00081-001-s087><break.aufbrechen><de> Dieser Begriff bezeichnet solche Stoffgemische, die zum Aufbrechen von Ölfilmen an der Wasseroberfläche führen und die Bildung von Dispersionen (feinen Tröpfchen) fördern.
<G-vec00081-001-s088><break.aufbrechen><en> Resilient and lightweight, these pots have been designed to break down over time so that your cannabis plants can grow big and strong.
<G-vec00081-001-s088><break.aufbrechen><de> Belastbar und ein Leichtgewicht, sind diese Töpfe genau so konzipiert, dass sie leicht aufbrechen können, damit Ihre Cannabis-Pflanzen groß und stark wachsen können.
<G-vec00081-001-s089><break.aufbrechen><en> anCnoc Peated Range - 11.1 ppm The Rascan tool is used to break up the top level of rough ground and prepare the land for peat harvesting.
<G-vec00081-001-s089><break.aufbrechen><de> anCnoc Peated Range - 11.1 ppm Die Rascan Werkzeug wird verwendet zum Aufbrechen der obersten Ebene des rauen Boden und bereiten den Boden für die Torf Ernte vor.
<G-vec00081-001-s090><break.aufbrechen><en> To break open the binding of the wheel of rebirth depends mainly on our being earnest and intent: That's what will clear our way. This is why living beings don't want to touch that binding, don't want to break it open.
<G-vec00081-001-s090><break.aufbrechen><de> Die Bindung an das Rad der Wiedergeburt aufzubrechen hängt hauptsächlich von unserer Ernsthaftigkeit und Entschlossenheit ab: Das ist es nämlich, was uns den Weg frei macht und warum auch die Lebewesen diese Bindung nicht anrühren und nicht aufbrechen wollen.
<G-vec00081-001-s091><break.aufbrechen><en> What the result of a social explosion will be in Saudi Arabia is hard to tell, but it is clear that the status quo is bound to break up at a certain point.
<G-vec00081-001-s091><break.aufbrechen><de> Es ist schwer zu sagen, welche Ergebnisse eine soziale Revolution in Saudi-Arabien haben wird, aber es ist klar, dass der jetzige Zustand zu einem bestimmten Punkt aufbrechen muss.
<G-vec00081-001-s092><break.aufbrechen><en> Internet businesses threaten customer relationships Experts at the conference will be shedding light on how aviation companies can break free of old structures and explore new routes.
<G-vec00081-001-s092><break.aufbrechen><de> Internetunternehmen bedrohen Kundenbeziehungen Auf der Konferenz beleuchten Experten, wie die Luftfahrtunternehmen alte Strukturen aufbrechen und neue Wege einschlagen können.
<G-vec00081-001-s093><break.aufbrechen><en> June 2015 a team of experts and volunteers to Nigeria break up, to in the Niger Delta with the help of PURE cotton, a special Flieses, at his own expense to clean an oil-contaminated waters.
<G-vec00081-001-s093><break.aufbrechen><de> Lipnja 2015 ein Team von Experten und Helfern nach Nigeria aufbrechen, um im Nigerdelta mit Hilfe der PURE-Watte, eines speziellen Flieses, auf eigene Kosten ein ölverseuchtes Gewässer zu reinigen .
<G-vec00081-001-s094><break.aufbrechen><en> Ozone and UV radiation can break down the chain molecules of the elastomer material.
<G-vec00081-001-s094><break.aufbrechen><de> Ozon und UV-Strahlung können die Kettenmoleküle des Elastomerwerkstoffs aufbrechen.
<G-vec00081-001-s114><break.aufbrechen><en> Aligns the area with the help of garden rakes,be sure to break up large clumps.
<G-vec00081-001-s114><break.aufbrechen><de> Richtet den Bereich mit Hilfe von Gartenrechen,sicher sein, große Klumpen aufzubrechen.
<G-vec00081-001-s115><break.aufbrechen><en> While the Security Council is always trying to impose new sanctions against Eritrea to marginalize the country, Uganda is trying to break up Eritrea's isolation.
<G-vec00081-001-s115><break.aufbrechen><de> Während der Weltsicherheitsrat die Verhängung neuer Sanktionen gegen Eritrea erwägt und das Land immer mehr als Paria behandelt, versucht Uganda, die Isolation Eritreas aufzubrechen.
<G-vec00081-001-s116><break.aufbrechen><en> You need to dig below the surface and get to the root of what led to your break up.
<G-vec00081-001-s116><break.aufbrechen><de> Sie müssen sich unter der Oberfläche zu graben und sich an die Wurzel dessen, was führte zu Ihren aufzubrechen.
<G-vec00081-001-s117><break.aufbrechen><en> [Somebody tries to break out the door.
<G-vec00081-001-s117><break.aufbrechen><de> [Jemand versucht die Tür aufzubrechen.
<G-vec00081-001-s118><break.aufbrechen><en> We are planning to break open this market segment completely with the introduction of our new machine, to be launched at BAUMA 2010.
<G-vec00081-001-s118><break.aufbrechen><de> Wir haben vor, dieses Marktsegment vollständig aufzubrechen mit der Einführung unserer neuen Maschine, die zur BAUMA 2010 auf den Markt gebracht werden soll.
<G-vec00081-001-s119><break.aufbrechen><en> I am convinced that his courageous policy of reaching out to others is the right path to break through hardened fronts in many conflicts and to promote peaceful cooperation among nations.
<G-vec00081-001-s119><break.aufbrechen><de> Ich bin überzeugt: Seine mutige Politik der ausgestreckten Hand ist der richtige Weg, um die verhärteten Fronten in vielen Konflikten aufzubrechen und die friedliche Zusammenarbeit zwischen den Völkern zu fördern.
<G-vec00081-001-s120><break.aufbrechen><en> She had no idea that Karl would now come so far as to try to break open strange doors with knives.
<G-vec00081-001-s120><break.aufbrechen><de> Sie hatte keine Ahnung davon, daß es jetzt mit Karl soweit gekommen war, daß er fremde Türen mit Messern aufzubrechen suchte.
<G-vec00081-001-s121><break.aufbrechen><en> What exactly happened behind the closed doors of the inner sanctum while demons and undead strove to break then down,
<G-vec00081-001-s121><break.aufbrechen><de> Was genau hinter den verschlossenen Türen des inneren Heiligtums geschah, während die Untoten und Dämonen versuchten diese aufzubrechen, wird wohl für immer im Dunkeln bleiben.
<G-vec00081-001-s122><break.aufbrechen><en> He roasts the beans sparingly, giving them just 20 minutes to break open and release their aroma.
<G-vec00081-001-s122><break.aufbrechen><de> Dafür röstet er den Kaffee besonders schonend: Rund 20 Minuten bekommt die Kaffeebohne bei ihm Zeit, um aufzubrechen und ihr Aroma freizusetzen.
<G-vec00081-001-s123><break.aufbrechen><en> Headings and images both help to break up your content.
<G-vec00081-001-s123><break.aufbrechen><de> Überschriften und Bilder helfen dabei, den Inhalt aufzubrechen.
<G-vec00081-001-s124><break.aufbrechen><en> The hiking required a small approach, right at the house on foot break was not really possible.
<G-vec00081-001-s124><break.aufbrechen><de> Das Wandern bedurfte einer kleinen Anfahrt, direkt am Haus zu Fuß aufzubrechen war eigentlich nicht möglich.
<G-vec00081-001-s125><break.aufbrechen><en> In other words, a single bloody clash would be sufficient to break the army in pieces.
<G-vec00081-001-s125><break.aufbrechen><de> Mit anderen Worten, ein einziger blutiger Zusammenstoß würde ausreichen, um die Armee aufzubrechen.
<G-vec00081-001-s126><break.aufbrechen><en> After the artificial turf has been laid out it should be broomed by hand or with a power broom to stand up the fibers and to begin to break up or fray the artificial turf fibers before any sand is dropped into the turf.
<G-vec00081-001-s126><break.aufbrechen><de> Nachdem der Kunstrasen gelegt hat sollte broomed werden per hand oder mit einem Besen macht die Fasern aufzustehen und zu beginnen, um aufzubrechen oder Ausfransen der Kunstrasen Fasern vor keinen Sand in die Grasnarbe fallen gelassen wird.
<G-vec00081-001-s127><break.aufbrechen><en> The aim is to break open the complex that constitutes our reality, showing it in all its facets as a way of enabling us to interrogate it.
<G-vec00081-001-s127><break.aufbrechen><de> Es geht darum, den Komplex, der unsere Realität ist, aufzubrechen, in seinen Facetten zu zeigen, um ihn so befragbar und verhandelbar zu machen.
<G-vec00081-001-s128><break.aufbrechen><en> The challenge for the left is to break the divide between a liberal and conservative right and offer an alternative that extends social rights and protections but also defends democratic and civil rights.
<G-vec00081-001-s128><break.aufbrechen><de> Die Herausforderung fÃ1⁄4r die Linke liegt darin, die Kluft zwischen einer liberalen und konservativen Rechten aufzubrechen und eine Alternative zu bieten, die soziale Rechte und Schutz erweitert, gleichzeitig jedoch demokratische Rechte und BÃ1⁄4rger_innenrechte verteidigt.
<G-vec00081-001-s129><break.aufbrechen><en> Melt enthalpies are a simple example of endothermic processes, since one usually has to give heat work in a system in order to break up its solid crystal structure and convert it into a liquid phase with molecules that move freely relative to one another.
<G-vec00081-001-s129><break.aufbrechen><de> Schmelzenthalpien sind dabei ein einfaches Beispiel für endotherme Vorgänge, da man meistens Wärmearbeit in ein System geben muss, um dessen feste Kristallstruktur aufzubrechen und es in eine flüssige Phase mit frei gegeneinander beweglichen Molekülen zu überführen.
<G-vec00081-001-s130><break.aufbrechen><en> The Imperial Reclamation Service believes the Foundry now uses a network of tractor beams to capture and break apart nearby asteroids, providing raw materials for its endless mass production.
<G-vec00081-001-s130><break.aufbrechen><de> Der Imperiale Bergungsdienst geht davon aus, dass die Fabrik nun ein Netzwerk von Traktorstrahlen nutzt, um nahegelegene Asteroiden einzufangen und aufzubrechen und so die Versorgung mit Rohstoffen für ihre endlose Massenproduktion sicherzustellen.
<G-vec00081-001-s131><break.aufbrechen><en> In order to break up existing flocks and prevent the agglomeration of fibers into new flocks, the incoming suspension is put into a vortex rotation with a high flow velocity.
<G-vec00081-001-s131><break.aufbrechen><de> Die einströmende Suspension wird in eine Vortexrotation mit hoher Flussgeschwindigkeit versetzt, um vorhandene Flocken aufzubrechen und die Entstehung neuer Flocken durch die Agglomeration von Fasern zu verhindern.
<G-vec00081-001-s132><break.aufbrechen><en> They thought that no one was home and called a locksmith to break the lock and discovered that Mr. Zhao was home.
<G-vec00081-001-s132><break.aufbrechen><de> Sie dachten, es sei niemand zu Hause und riefen einen Schlüsseldienst herbei, um das Schloss aufzubrechen und entdeckten dann, dass Herr Zhao daheim war.
<G-vec00081-001-s209><break.brechen><en> In Chopper Mania your skills will be tested with high pressure gameplay, including your mouse and keyboard, used to press buttons, break walls, avoid moving parts and mostly, beware of your limits.
<G-vec00081-001-s209><break.brechen><de> In Chopper Mania Ihre Fähigkeiten werden mit Hochdruck Gameplay getestet werden, einschließlich Ihrer Maus und Tastatur verwendet, um Knöpfe, brechen Wände drücken, zu vermeiden beweglichen Teile und vor allem, Vorsicht vor Ihre Grenzen.
<G-vec00081-001-s210><break.brechen><en> Forex Trading Breakeven EA will set the currency trading to break even after x +pips.
<G-vec00081-001-s210><break.brechen><de> Forex Trading Break-even-EA wird die Währung Handel gesetzt auch nach x + Pips zu brechen.
<G-vec00081-001-s211><break.brechen><en> To break a young person’s heart, it suffices to rebuff his confidence.
<G-vec00081-001-s211><break.brechen><de> Um das Herz eines Jugendlichen zu brechen genügt es, ihm kein Vertrauen entgegenzubringen.
<G-vec00081-001-s212><break.brechen><en> SF6 Circuit Breaker is the use of a circuit breaker of the SF6 gas as the insulating and arc extinguishing medium, s is a colorless, odorless, non-toxic and flammable gases, its chemical properties are fairly stable below 150 ℃, although at a high temperature will break down to produce toxic gas interrupter state, and will produce a small amount of the active substance, but through the use of the adsorbent and the contact has a self-cleaning function, equipment and personal will not cause harm.
<G-vec00081-001-s212><break.brechen><de> SF6-Leistungsschalter ist die Verwendung eines Leistungsschalters des SF6-Gases als Isolier- und Lichtbogenlöschmittel, s ist ein farbloses, geruchloses, ungiftiges und brennbares Gas, seine chemischen Eigenschaften sind ziemlich stabil unter 150 °C, wenn auch hoch Temperatur wird brechen, um giftige Gas Unterbrecher Zustand zu produzieren, und wird eine kleine Menge des Wirkstoffs zu produzieren, aber durch die Verwendung der Adsorptionsmittel und der Kontakt hat eine Selbstreinigung Funktion, Ausrüstung und persönliche wird nicht schaden.
<G-vec00081-001-s213><break.brechen><en> Codes of the game require that she hit their stiffs no matter how rich the shoe is in large cards that will break him.
<G-vec00081-001-s213><break.brechen><de> Codes des Spiels verlangen, dass sie ihre Stiffs egal wie reich die Schuh-Hit ist in große Karten, die ihn brechen.
<G-vec00081-001-s214><break.brechen><en> For us the Creators laws never change or break down.
<G-vec00081-001-s214><break.brechen><de> Für uns Hopi ändern sich die Gesetze des Schöpfers niemals, noch brechen sie ein.
<G-vec00081-001-s215><break.brechen><en> "And as the young protesters shouted Sixty-eight of the ""Peace and Love"" with iron bars in hand, throwing stones at police and bombs molotov between a cry of love and the other, Today in the Church, dictators were born in the post-conciliar season, menano locked knees and break your legs to anyone who dissents to the Grand Revolution of Mercy."
<G-vec00081-001-s215><break.brechen><de> Und wie die jungen Demonstranten riefen Achtundsechzig der â Peace and Loveâ mit Eisenstangen in der Hand, warfen Steine â â auf die Polizei und Bomben molotov zwischen einem Schrei der Liebe und der anderen, Heute in der Kirche, Diktatoren wurden in der nachkonziliaren Saison geboren, Menano gesperrt Knie und brechen deine Beine für jeden, der zum Grand dissents Revolution der Barmherzigkeit.
<G-vec00081-001-s216><break.brechen><en> These place stress on the roots of your hair, making them more likely to break from the root.
<G-vec00081-001-s216><break.brechen><de> Sie haben eine anstrengende Wirkung auf die Haarwurzeln deiner Haare und es ist eher wahrscheinlich, dass sie an der Wurzel brechen.
<G-vec00081-001-s217><break.brechen><en> Use the arrow keys to steer, accelerate and reverse and space to break.
<G-vec00081-001-s217><break.brechen><de> Verwenden Sie die Pfeiltasten zu steuern, beschleunigen und rückwärts und Raum zu brechen.
<G-vec00081-001-s218><break.brechen><en> This kind of flower usb flash drives break the sterotype of people think leather means robust, It's romantic looking welcome by most of the females or artists.
<G-vec00081-001-s218><break.brechen><de> Diese Art der Blume USB-Sticks brechen die sterotype Leute denken, Leder heißt robust, es ist romantisch suchen begrüßen die von den meisten Weibchen oder Künstler.
<G-vec00081-001-s219><break.brechen><en> The bulk of the work you do as an Ebay seller will be easy and repetitive, but it is the minor details that will make or break your business.
<G-vec00081-001-s219><break.brechen><de> Die Masse der Arbeit, die Sie erledigen, da ein Ebay Verkäufer einfach und sich wiederholend ist, aber es ist die kleinen Details, die bilden oder Ihr Geschäft brechen.
<G-vec00081-001-s220><break.brechen><en> Man should not chew, crush or break the Testosterone pills.
<G-vec00081-001-s220><break.brechen><de> Mann sollte nicht kauen, zermalmen oder brechen die Testosteron-Tabletten.
<G-vec00081-001-s221><break.brechen><en> A revolutionary topical gel, your pump will never be the same.- Enhances Muscular to Help Break Trough Plateaus,- Helps Flush Muscles by Increasing Blood...
<G-vec00081-001-s221><break.brechen><de> Ein revolutionäres, topisches Gel, Ihre Pumpe wird niemals mehr dieselbe sein.- Verbessert Muskulös, um Trough Plateaus zu brechen,-...
<G-vec00081-001-s222><break.brechen><en> The wave built itself up to a dreadful height, began to break above us and overturned the zodiac.
<G-vec00081-001-s222><break.brechen><de> Die Welle vor uns baute sich zu einer furchterregenden Höhe auf und begann über uns zu brechen.
<G-vec00081-001-s223><break.brechen><en> If we are to ever live in peaceful and just communities, we must break the cycle of teaching war to young people, generation after generation.
<G-vec00081-001-s223><break.brechen><de> Wenn wir jemals in friedlichen und gerechten Gemeinschaften leben wollen, müssen wir den Kreis der generationenlangen Kriegsunterweisung für junge Menschen brechen.
<G-vec00081-001-s224><break.brechen><en> and the elders of that city shall bring down the heifer unto a valley with running water, which is neither plowed nor sown, and shall break the heifer's neck there in the valley.
<G-vec00081-001-s224><break.brechen><de> und sollen sie hinabführen in einen kiesigen Grund, der weder bearbeitet noch besät ist, und daselbst im Grund ihr den Hals brechen.
<G-vec00081-001-s225><break.brechen><en> People sometimes judge others by their appearances, and they sometimes break their promises in order to protect their own selfish interests.
<G-vec00081-001-s225><break.brechen><de> Die Menschen beurteilen andere Menschen oft nach ihrem äußeren Erscheinungsbild, sie brechen auch manchmal ihre Versprechen, um ihre eigenen selbstsüchtigen Interessen zu schützen.
<G-vec00081-001-s226><break.brechen><en> It is possible through rooting the device and do whatever you want and break the rules which have been restricted by default.
<G-vec00081-001-s226><break.brechen><de> Es ist möglich, das Gerät zu verwurzeln und zu tun, was immer Sie wollen, und die Regeln zu brechen, die standardmäßig eingeschränkt wurden.
<G-vec00081-001-s227><break.brechen><en> They help us to break down our pride and human logic, and to have an unconditioned trust in God.
<G-vec00081-001-s227><break.brechen><de> Diese erlauben uns, den Block des Stolzes und der menschlichen Logik zu brechen; sie helfen uns, ein bedingungsloses Vertrauen auf Gott zu haben.
<G-vec00081-001-s228><break.brechen><en> The rise of populism in Europe, the crisis caused by Brexit, the risk that the new administration in Washington might break the trade agreements with Europeans have all been identified by German Chancellor Angela Merkel and the French President Francois Hollande as major threats to Europe's stability.
<G-vec00081-001-s228><break.brechen><de> Die Verschärfung des Populismus, der Brexit, die Möglichkeit, dass die neue Verwaltung in Washington die Handelsabkommen mit den Europäern bricht, sind ebensoviele Bedrohungen gegen die Stabilität des Kontinents.
<G-vec00081-001-s229><break.brechen><en> The emission of wadiy, a thick sticky substance that comes out after urination, with no sense of physical pleasure, does not break the fast, and a person does not have to do ghusl, but he does have to do istinjaa' (clean his private parts) and do wudoo'.
<G-vec00081-001-s229><break.brechen><de> Die Absonderung von Wadiy, eine dicke, klebrige Substanz, die nach dem Urinieren erscheint, ohne ein Gefühl von körperlicher Freude, bricht das Fasten nicht, und die Person muss kein Ghusl machen, sondern lediglich Istinjā' (die Intimsphäre reinigen) und Wudū' (Fatāwa al-Lajnah al-Dā'imah #10/279).
<G-vec00081-001-s230><break.brechen><en> Rufus Wainwright has a plethora of talent, the charm of a dandy, a voice that can break your heart and a bright future.
<G-vec00081-001-s230><break.brechen><de> Rufus Wainwright hat Talent zum Verschwenden, den Charme eines Dandys, eine Stimme, die Herzen bricht, und eine große Zukunft vor sich.
<G-vec00081-001-s231><break.brechen><en> Even though it arises from a pragmatic attitude and goes directly to the point in regards to the objective of openings, nobody likes to see when someone tries to break the appearance of the social refinement that these events have.
<G-vec00081-001-s231><break.brechen><de> Auch wenn es von einer pragmatischen Einstellung herrührt und direkt auf den Zweck einer Eröffnung hindeutet, will es niemand sehen, dass man mit den Regeln des raffinierten Auftretens bei diesen Veranstaltungen bricht.
<G-vec00081-001-s232><break.brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00081-001-s232><break.brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00081-001-s233><break.brechen><en> Facial and body waxing is done, forget conventional techniques depilate with thread and feels different, does not break the hair root extracts it, retards growth...
<G-vec00081-001-s233><break.brechen><de> Gesichts- und Körperbehandlungen Haarentfernung getan, vergessen konventionellen Techniken enthaaren mit Gewinde und fühlt sich anders an, bricht nicht die Haarwurzel extrahiert sie, verlangsamt das Wachstum...
<G-vec00081-001-s234><break.brechen><en> The 32-year-old photographer from Miesbach (Upper Bavaria) regards himself as patriotic and aware of his tradition; his photographs, however, break the usual clichés.
<G-vec00081-001-s234><break.brechen><de> Der 32-jährige Fotograf aus Miesbach im Voralpenland hält sich selbst für heimatverbunden und traditionsbewusst, aber in seinen Fotografien bricht er mit den üblichen Klischees.
<G-vec00081-001-s235><break.brechen><en> If some needs 10 mm tiles, the blocks are cut in the thickness of 15 mm (less than this, the slab will break), if you need 20 mm tiles, we cut the blocks in 20 mm thickness and if your requirement is 30 mm tile, we will cut it in 30 mm thickness.
<G-vec00081-001-s235><break.brechen><de> Wenn einige Bedürfnisse 10 mm Fliesen, die Blöcke in der Dicke geschnitten, von 15 Millimeter (weniger als diese, die Platte bricht), wenn Sie brauchen 20 mm Fliesen, wir schneiden Sie die Blöcke in 20 mm Dicke und wenn Ihre Anforderung ist 30 mm Fliese, wir schneiden Sie es in 30 mm Dicke.
<G-vec00081-001-s236><break.brechen><en> Yet only from that night do we see the dawn of the resurrection break forth.
<G-vec00081-001-s236><break.brechen><de> Aber nur aus dieser Nacht bricht die Morgenröte der Auferstehung an.
<G-vec00081-001-s237><break.brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00081-001-s237><break.brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00081-001-s238><break.brechen><en> Japanese director Takashi Miike is well known for films that make a decisive break with taboos and conventions, and for his ruthlessly graphic portrayal of violence.
<G-vec00081-001-s238><break.brechen><de> Takashi Miike ist dafür bekannt, dass er in seinen Filmen mit großer Entschlossenheit Tabus bricht und bei der Darstellung von Gewalt keine Rücksichten kennt.
<G-vec00081-001-s239><break.brechen><en> Bent needle will break, if the needle touches the plate.
<G-vec00081-001-s239><break.brechen><de> Bent Nadel bricht, wenn die Nadel die Platte berührt.
<G-vec00081-001-s240><break.brechen><en> 7 The whole earth is at rest and quiet; they break forth into singing.
<G-vec00081-001-s240><break.brechen><de> 7 Jetzt ruht die ganze Erde und ist still; man bricht in Jubel aus.
<G-vec00081-001-s241><break.brechen><en> Those extra pounds spent procuring an item will replay themselves over time when that item doesn't break.
<G-vec00081-001-s241><break.brechen><de> Die zusätzlichen Pfunde, die für die Beschaffung eines Gegenstandes aufgewendet werden, werden sich im Laufe der Zeit wiederholen, wenn dieser Gegenstand nicht bricht.
<G-vec00081-001-s242><break.brechen><en> Further outside there's a reef where moderate waves break.
<G-vec00081-001-s242><break.brechen><de> Weiter draußen befindet sich ein Riff, wo eine schöne, moderate Welle bricht, wer`s mag.
<G-vec00081-001-s243><break.brechen><en> After being processed into curved insulated glass, it is widely used in glass architecture, even if the glass break, it will shatter into small blunt fragments reducing the risk of injury.
<G-vec00081-001-s243><break.brechen><de> Nachdem es zu gebogenem Isolierglas verarbeitet wurde, ist es in der Glasarchitektur weit verbreitet, auch wenn das Glas bricht, zerbricht es in kleine, stumpfe Bruchstücke, wodurch die Verletzungsgefahr verringert wird.
<G-vec00081-001-s244><break.brechen><en> It makes my heart break.
<G-vec00081-001-s244><break.brechen><de> Sie bricht mein Herz.
<G-vec00081-001-s245><break.brechen><en> Then you simply fold down the breaking stamp integrated into the sides and use it to break the tile cleanly at the scoring line – all in one step.
<G-vec00081-001-s245><break.brechen><de> Danach legt man den seitlich integrierten Brechstempel einfach um und bricht die Fliese damit sauber an der vorhandenen Ritzlinie – alles in einem Arbeitsschritt.
<G-vec00081-001-s246><break.brechen><en> Additionally, many of the accounts on sale are stolen, and people who share accounts run the risk that the person using the account won't give it back, or that the person will break a game rule causing the account to be banned or muted for which the account creator will be accountable.
<G-vec00081-001-s246><break.brechen><de> Zusätzlich dazu sind viele Konten, die zum Verkauf stehen, gestohlen und die Spieler, die Konten teilen, gehen das Risiko ein, dass die Person das ausgeliehene Konto nicht wieder zurückgibt oder dass die Person eine Regel des Spiels bricht und das Konto gesperrt oder stummgeschaltet wird, wofür dann der Kontoinhaber haften muss.
<G-vec00081-001-s304><break.brechen><en> Nails start exfoliating, hair - to break and drop out.
<G-vec00081-001-s304><break.brechen><de> Die Nägel beginnen sloitsja, das Haar - gebrochen zu werden und auszufallen.
<G-vec00081-001-s305><break.brechen><en> Very often when bending the fox can break with a crunch, and in certain cases they are not rumpled at compression.
<G-vec00081-001-s305><break.brechen><de> Sehr oft können beim Beugen fuchs- mit dem Knirschen gebrochen werden, und in einigen Fällen werden sie bei der Kompression nicht zerknittert.
<G-vec00081-001-s306><break.brechen><en> The large belt wheel break, particularly in vehicles with more armature current (torque).
<G-vec00081-001-s306><break.brechen><de> Das große Riemenrad ist bei einigen Fahrzeugen gebrochen, vor allem natürlich bei Fahrzeugen mit aufgedrehtem Ankerstrom (Drehmoment).
<G-vec00081-001-s307><break.brechen><en> If the Zionists break resolutions in throngs, this is no reason to behave, but if there is a break of a resolution once or twice by an organization like Hizbollah, this is a reason to terrorize in the most brutal way – not Hizbollah in the first place, but the whole Lebanese people.
<G-vec00081-001-s307><break.brechen><de> Wenn die israelischen Zionisten Resolutionen zuhauf brechen, dann ist das kein Grund, aber wenn ein- oder zweimal eine Resolution gebrochen wird durch eine Organisation wie Hizbollah, dann ist das ein Grund, nicht etwa vorwiegend die Hizbollah, sondern das ganze libanesische Volk auf das Brutalste zu terrorisieren.
<G-vec00081-001-s308><break.brechen><en> Mostly the seal was a monogram or sometimes a mysterious symbol and only a certain person was permitted to break the seal.
<G-vec00081-001-s308><break.brechen><de> "Die Siegelabdrücke wurden meist als Monogramme, manchmal auch als geheimnisvolle Symbole angebracht und durften nur von bestimmten Personen ""gebrochen"" (geöffnet) werden."
<G-vec00081-001-s309><break.brechen><en> In case that her opponents have limited snake skills, they might easily break a neck while Cindy sits on their face.
<G-vec00081-001-s309><break.brechen><de> Sollten ihre Gegnerinnen nicht absolut gelenkig sein, wird ihnen das Genick gebrochen, während Cindy auf ihren Gesicht sitzt.
<G-vec00081-001-s310><break.brechen><en> "Palmer points to the fact that Cannon, after his 1925 break with Foster, argued for the primacy of program over faction and insisted that votes should be taken on the ""main political line, regardless of who is for or against."""
<G-vec00081-001-s310><break.brechen><de> "Palmer weist darauf hin, dass Cannon, nachdem er 1925 mit Foster gebrochen hatte, für das Primat des Programms über die Fraktion argumentierte und darauf bestand, dass Abstimmungen stattfinden sollten über die „politische Hauptlinie, egal wer dafür und wer dagegen ist""."
<G-vec00081-001-s311><break.brechen><en> """I did break all the rules."
<G-vec00081-001-s311><break.brechen><de> """Ich habe wirklich alle Regeln gebrochen."
<G-vec00081-001-s312><break.brechen><en> At an epilation at a high speed thin hairs are not pulled out as it has to be, and simply break.
<G-vec00081-001-s312><break.brechen><de> Bei epiljazii auf der hohen Geschwindigkeit fein woloski werden nicht herausgezogen, wie es sein soll, und einfach werden gebrochen.
<G-vec00081-001-s313><break.brechen><en> The box took a huge damage of post office, but did not break the...
<G-vec00081-001-s313><break.brechen><de> Die Box hat einen riesigen Schaden der Post, nicht gebrochen, aber die...
<G-vec00081-001-s314><break.brechen><en> Whether we break them ourselves or not, there are always lots of broken ceramics about (as it is unnecessary to fire, so it is to break), and all of them are excellent.
<G-vec00081-001-s314><break.brechen><de> Egal ob gebrochen wird oder nicht, gebrochene Keramik gibt es immer in Fülle (wie der Brand, so ist auch das Brechen überflüssig).
<G-vec00081-001-s315><break.brechen><en> What I can't bear, however, is when the shinobi, among them Goemon first of all, jump several hundreds of meters and not only stretch all laws of physics, but outright break them.
<G-vec00081-001-s315><break.brechen><de> Womit ich nichts anfangen kann ist, wenn die Shinobi, darunter vor allem Goemon, hunderte von Meter weit springen und physikalische Gesetze nicht nur etwas gedehnt wurden, sondern schlichtweg gebrochen werden.
<G-vec00081-001-s316><break.brechen><en> Well dried up mushrooms slightly bend, easily break, but do not crumble.
<G-vec00081-001-s316><break.brechen><de> werden die gut ausgetrockneten Pilze ein wenig gebogen, werden leicht gebrochen, aber bröckeln nicht ab.
<G-vec00081-001-s317><break.brechen><en> "Calls to pressure corporations and governments in countries like the U.S. or Canada to take the side of the Palestinians against the Israeli government reinforce the very illusions in ""democratic"" imperialism from which young activists and working-class militants desperately need to break."
<G-vec00081-001-s317><break.brechen><de> "Aufrufe, die Firmen oder Regierungen in Ländern wie den USA oder Kanada unter Druck setzen sollen, damit sie gegen die israelische Regierung eine Seite mit den Palästinensern beziehen, verstärken genau die Illusionen in ""demokratischen"" Imperialismus, von denen junge Aktivisten und militante Arbeiter so dringend gebrochen werden müssen."
<G-vec00081-001-s318><break.brechen><en> This is the only way to break the spell.
<G-vec00081-001-s318><break.brechen><de> Nur so kann der Zauber gebrochen werden.
<G-vec00081-001-s319><break.brechen><en> 126 It is time to act, LORD,for they break your Torah.
<G-vec00081-001-s319><break.brechen><de> 126 Es ist Zeit für Jehova zu handeln: sie haben dein Gesetz gebrochen.
<G-vec00081-001-s320><break.brechen><en> When asked why we are being singled out and controlled, the police reply is usually “it is our job to control you”, “we have the right to check you”, and “we are looking for criminals who break the law”.
<G-vec00081-001-s320><break.brechen><de> Gefragt, warum sie uns herauspicken und kontrollieren, bekommt man für gewöhnlich von Seiten der Polizei zu hören: „Es ist unser Job, dich zu kontrollieren“, „Wir haben das Recht, dich zu überprüfen“ und: „Wir suchen Kriminelle, die das Gesetz gebrochen haben“.
<G-vec00081-001-s321><break.brechen><en> When the people break the covenant, God presents himself to Moses in the cloud in order to renew that pact, proclaiming his own name and its meaning.
<G-vec00081-001-s321><break.brechen><de> Nachdem das Volk den Bund gebrochen hatte, zeigte sich Gott vor Mose in einer Wolke, um jenen Bund zu erneuern, wobei er seinen Namen und dessen Bedeutung kundtat.
<G-vec00081-001-s322><break.brechen><en> For these reasons, it is more necessary than ever to strengthen the associative realities consolidated by a long experience, and those that can find new flowering and development, to break the grip of solitude, make room for solidarity and collaboration, and give life to new collective subjects to orient the life of societies and the functioning of institutions on the way of social cohesion and economic and cultural progress.
<G-vec00081-001-s322><break.brechen><de> Es muss der Griff der Einsamkeit gebrochen, der Solidarität und Zusammenarbeit Raum gegeben und neuen kollektiven Subjekten neues Leben verliehen werden, um das Leben von Gesellschaften und das Funktionieren von Institutionen hin zu einem sozialen Zusammenhalt und einem wirtschaftlichen und kulturellen Fortschritt auszurichten.
<G-vec00081-001-s570><break.unterbrechen><en> PTR is meant to break the cycle of pain by loosening up the body and helping the patient relax.
<G-vec00081-001-s570><break.unterbrechen><de> PRT zielt darauf ab, den Schmerzzyklus zu unterbrechen, indem sich der Körper völlig entspannt.
<G-vec00081-001-s571><break.unterbrechen><en> If you do have problems simply insert a fingertip alongside the Vac-u-lock adaptor to break the suction.
<G-vec00081-001-s571><break.unterbrechen><de> Wenn Sie Probleme haben, stecken Sie einfach eine Fingerspitze neben den Vac-Lock-Adapter, um die Saugwirkung zu unterbrechen.
<G-vec00081-001-s572><break.unterbrechen><en> (6) (But) whoever hears (the Dharma teachings) will be able to break the continuum of birth and death and will never be parted from a supremely great blissful awareness.
<G-vec00081-001-s572><break.unterbrechen><de> 6) (Aber) jeder, der die (Dharma-Unterweisungen) hört, wird in der Lage sein, das Kontinuum von Geburt und Tod zu unterbrechen und wird niemals mehr vom äußerst erhabenen glückseligen Gewahrsein getrennt sein.
<G-vec00081-001-s573><break.unterbrechen><en> Nor did I wish to break the silence.
<G-vec00081-001-s573><break.unterbrechen><de> Auch ich wollte das Schweigen nicht unterbrechen.
<G-vec00081-001-s574><break.unterbrechen><en> The place on the American pattern with large ground planes which break the fairways.
<G-vec00081-001-s574><break.unterbrechen><de> Der Platz nach Amerikanischem Muster mit großen Erdflächen welche die Fairways unterbrechen.
<G-vec00081-001-s575><break.unterbrechen><en> The Break button breaks an entity creating a gap in it.
<G-vec00081-001-s575><break.unterbrechen><de> Der Button Unterbrechen unterbricht die Einheit, indem eine Lücke erstellt wird.
<G-vec00081-001-s576><break.unterbrechen><en> Have spent a night to break our journey back to France.
<G-vec00081-001-s576><break.unterbrechen><de> Habe eine Nacht verbracht, um unsere Reise nach Frankreich zu unterbrechen.
<G-vec00081-001-s577><break.unterbrechen><en> If the contents are too long to enter the cell, we usually use line breaks to break the contents so than the contents can completely be displayed in cell as below screenshot shown.
<G-vec00081-001-s577><break.unterbrechen><de> Wenn der Inhalt zu lang ist, um in die Zelle zu gelangen, verwenden wir normalerweise Zeilenumbrüche, um den Inhalt zu unterbrechen, so dass der Inhalt vollständig in der Zelle angezeigt werden kann, wie im Screenshot gezeigt.
<G-vec00081-001-s578><break.unterbrechen><en> Note: For circle and ellipse entities Break operation cuts off a sector between the two points in the clockwise direction.
<G-vec00081-001-s578><break.unterbrechen><de> Hinweis: Der Vorgang Unterbrechen schneidet den Sektor vom ersten Unterbrechungspunkt in der Richtung im Uhrzeigersinn für Kreis- und Ellipse-Einheiten ab.
<G-vec00081-001-s579><break.unterbrechen><en> creating a break in an entity.
<G-vec00081-001-s579><break.unterbrechen><de> ermöglicht das Unterbrechen einer Einheit an einem Punkt.
<G-vec00081-001-s580><break.unterbrechen><en> If very hard, between stages, you can make the day break.
<G-vec00081-001-s580><break.unterbrechen><de> Wenn Sie sehr hart sind, können Sie zwischen den Phasen den Tag unterbrechen.
<G-vec00081-001-s581><break.unterbrechen><en> Therefore the early and reliable diagnosis of whooping cough is extremely important in order to promptly begin antibiotic treatment and thus break the chain of infection.
<G-vec00081-001-s581><break.unterbrechen><de> Daher ist eine frühzeitige und sichere Diagnose von Keuchhusten außerordentlich wichtig, um frühzeitig eine Therapie zu beginnen und die Infektionskette somit zu unterbrechen.
<G-vec00081-001-s582><break.unterbrechen><en> That is why it is particularly important to break the vicious circle of sleep disorders.
<G-vec00081-001-s582><break.unterbrechen><de> Deshalb ist es besonders wichtig den Teufelskreis Schlafstörungen zu unterbrechen.
<G-vec00081-001-s583><break.unterbrechen><en> The ideal place for a break after a stroll through Naschmarkt - one can have just a snack, a leisurely meal (often inspired by Asiatic cuisine) or a quick espresso.
<G-vec00081-001-s583><break.unterbrechen><de> Der ideale Ort, um einen Spaziergang über den Naschmarkt mit einem schnellen Imbiss, einem gemütlichen Essen (meist asiatisch inspiriert) oder einfach einem Espresso zu unterbrechen.
<G-vec00081-001-s584><break.unterbrechen><en> In the name of historical truth, the president had the fortitude to break the isolation the Yankees had imposed on Central America – where they had forbidden the presidents to talk with the president of Nicaragua and they wanted a military solution, they wanted to finish Nicaragua off, finish off its revolution, with a war -, the man who took that courageous step was President Vinicius Cerezo of Guatemala.
<G-vec00081-001-s584><break.unterbrechen><de> Um die historische Wahrheit zu wahren, muss gesagt werden, dass der Präsident, der den Mut hatte, die Isolierung zu unterbrechen, welche die Yankees in Mittelamerika auferlegt hatten, – wo sie den Präsidenten verboten hatten, mit dem Präsidenten von Nicaragua Gespräche zu führen und wo sie eine militärische Lösung wollten und auf dem Kriegswege Nicaragua, seine Revolution, fertig machen wollten – derjenige, der diesen mutigen Schritt tat, war Vinicio Cerezo, der Präsident von Guatemala.
<G-vec00081-001-s585><break.unterbrechen><en> Select an entity and press the Break at point button.
<G-vec00081-001-s585><break.unterbrechen><de> Wählen Sie die Einheit und drücken Sie auf den Button [Editor -> Instrumente -> Am Punkt unterbrechen] .
<G-vec00081-001-s586><break.unterbrechen><en> It is not necessary to sleep ten or twelve hours a day, so you can break the physical and mental channels, which means that the bad energy of people can easily get to your esoteric bodies.
<G-vec00081-001-s586><break.unterbrechen><de> Es ist nicht notwendig, zehn oder zwölf Stunden am Tag zu schlafen, so dass Sie die physischen und mentalen Kanäle unterbrechen können, was bedeutet, dass die schlechte Energie der Menschen leicht zu Ihren esoterischen Körpern gelangen kann.
<G-vec00081-001-s587><break.unterbrechen><en> Select the cells with address you need to break, then click Kutools > Text > Split Cells.
<G-vec00081-001-s587><break.unterbrechen><de> Wählen Sie die Zellen mit der Adresse aus, die Sie unterbrechen möchten, und klicken Sie dann auf Kutoolen > SMS > Geteilte Zellen.
<G-vec00081-001-s588><break.unterbrechen><en> When you take a break from employment or become self-employed, you will no longer be a member of a pension fund.
<G-vec00081-001-s588><break.unterbrechen><de> Wenn Sie Ihre Berufstätigkeit unterbrechen oder sich selbst­stän­dig machen, sind Sie keiner Pensionskasse mehr angeschlossen.
<G-vec00081-001-s627><break.zerbrechen><en> 19:10 Then shalt thou break the bottle in the sight of the men that go with thee, < 19:11 and shalt say unto them, Thus saith Jehovah of hosts: Even so will I break this people and this city, as one breaketh a potter's vessel, that cannot be made whole again; and they shall bury in Topheth, till there be no place to bury.
<G-vec00081-001-s627><break.zerbrechen><de> 19:10 Und du sollst den Krug zerbrechen vor den Augen der Männer, die mit dir gehen, < 19:11 und sollst zu ihnen sagen: So spricht der HERR der Heerscharen: Ebenso will ich dieses Volk und diese Stadt zerbrechen, wie man eines Töpfers Geschirr zerbricht, das man nicht mehr flicken kann; und man wird im Tophet begraben, weil es an Raum zum Begraben fehlen wird.
<G-vec00081-001-s628><break.zerbrechen><en> To be creative, it is necessary to break a framework in which you tired out yourself, and to start thinking of itself as about the person creative.
<G-vec00081-001-s628><break.zerbrechen><de> Um kreativ zu sein, muss man die Rahmen zerbrechen, in die Sie selbst sich getrieben hat, und, zu beginnen, an sich wie über den Menschen kreativ zu denken.
<G-vec00081-001-s629><break.zerbrechen><en> I will break also the bar of Damascus, and cut off the inhabitant from the plain of Aven, and him that holdeth the sceptre from the house of Eden: and the people of Syria shall go into captivity unto Kir, saith the LORD.
<G-vec00081-001-s629><break.zerbrechen><de> Und ich will die Riegel zu Damaskus zerbrechen und die Einwohner auf dem Felde Aven samt dem, der das Zepter hält, aus dem Lusthause ausrotten, daß das Volk in Syrien soll gen Kir weggeführt werden, spricht der HERR.
<G-vec00081-001-s630><break.zerbrechen><en> 12:46 In one house shall it be eaten; thou shalt not carry forth ought of the flesh abroad out of the house; neither shall ye break a bone thereof.
<G-vec00081-001-s630><break.zerbrechen><de> 12:46 In einem Haus soll es gegessen werden; du sollst nichts von dem Fleisch aus dem Haus hinausbringen, und ihr sollt kein Bein an ihm zerbrechen.
<G-vec00081-001-s631><break.zerbrechen><en> 24 I will strengthen the arms of the king of Babylon, and put my sword in his hand: but I will break the arms of Pharaoh, and he shall groan before him with the groanings of a deadly wounded man.
<G-vec00081-001-s631><break.zerbrechen><de> Eze 30:24 Aber die Arme des Königs zu Babel will ich stärken und ihm mein Schwert in seine Hand geben, und will die Arme Pharaos zerbrechen, dass er vor ihm winseln soll wie ein tödlich Verwundeter.
<G-vec00081-001-s632><break.zerbrechen><en> Not only are eggs easy to break, they cause an awful mess too!
<G-vec00081-001-s632><break.zerbrechen><de> Eier zerbrechen nicht nur leicht, sie sind hinterher auch aufwändig zu säubern.
<G-vec00081-001-s633><break.zerbrechen><en> My entire being is so tense and filled with force that it seems it could break physically.
<G-vec00081-001-s633><break.zerbrechen><de> Mein ganzes Wesen ist dermaßen angespannt und voll von der Kraft, daß es mir scheint, etwas könnte physisch zerbrechen.
<G-vec00081-001-s634><break.zerbrechen><en> It's good to develop a sense of dispassion and disenchantment for the body, to develop a sense of samvega, so that when it breaks down we don't break down, too.
<G-vec00081-001-s634><break.zerbrechen><de> Es ist gut, einen gewissen Gleichmut, eine gewisse Ernüchterung gegenüber dem Körper zu entwickeln, ein Gefühl von Samvega zu entwickeln, so dass wir, wenn er zerbricht, nicht auch zerbrechen.
<G-vec00081-001-s635><break.zerbrechen><en> To break the blocks, arrange 3 or more of them in a row by clicking on one and then clicking on another next to the first.
<G-vec00081-001-s635><break.zerbrechen><de> Um die Eisblöcke zu zerbrechen, ordne 3 oder mehr von ihnen in Reihe an, indem du auf einen Block klickst und dann auf einen benachbarten Block.
<G-vec00081-001-s636><break.zerbrechen><en> Never break your head in decision making.
<G-vec00081-001-s636><break.zerbrechen><de> Zerbrechen Sie sich nicht den Kopf darüber, was Sie wann tun sollen.
<G-vec00081-001-s637><break.zerbrechen><en> If we are going to use oil to remove makeup, the oil will break down any other substance with a similar chemical structure, being the chemical bond that holds the substance together.
<G-vec00081-001-s637><break.zerbrechen><de> Wenn wir ein Öl für die Entfernung von Make-up verwenden, wird das Öl eine andere Substanz mit einer gleichwertigen chemischen Struktur, also die chemische Bindung der beiden Substanzen, zerbrechen.
<G-vec00081-001-s638><break.zerbrechen><en> 33 And if any of them falls into any earthenware vessel, all that is in it shall be unclean, and you shall break it.
<G-vec00081-001-s638><break.zerbrechen><de> 33 Fällt aber eines jener Tiere in ein irdenes Geschirr, so wird sein ganzer Inhalt unrein, und ihr müsst es zerbrechen.
<G-vec00081-001-s639><break.zerbrechen><en> • Safety in handling: Ultem resin is cooler to the touch than metals, glass and most other plastics, and is not likely to chip or break as glass can.
<G-vec00081-001-s639><break.zerbrechen><de> • Sicherheit bei der Handhabung: Der Kunststoff Ultem fühlt sich bei Berührung kühler als Metalle, Glas und die meisten Kunststoffe an und ist nicht anfällig auf Zerbrechen oder Absplittern, wie das bei Glas der Fall ist.
<G-vec00081-001-s640><break.zerbrechen><en> If to try most to make similar calculations, it is possible to break the head easily.
<G-vec00081-001-s640><break.zerbrechen><de> Wenn am meisten zu versuchen, die ähnlichen Berechnungen zu machen, so kann man sich ungezwungen den Kopf zerbrechen.
<G-vec00081-001-s641><break.zerbrechen><en> Take care while working with small Resin parts as if your go is with too much force you can easily break the material.
<G-vec00081-001-s641><break.zerbrechen><de> Sei vorsichtig bei der Arbeit mit kleinen Resinteilen, denn wenn du mit zu viel Kraft vorgehst, kannst du das Material leicht zerbrechen.
<G-vec00081-001-s642><break.zerbrechen><en> But watch out, pipes will break if they cross or overlap!
<G-vec00081-001-s642><break.zerbrechen><de> Aber pass auf, weil Rohre zerbrechen werden, wenn sie sich kreu...
<G-vec00081-001-s643><break.zerbrechen><en> 24 Thou shalt not adore their gods, nor serve them. Thou shalt not do their works, but shalt destroy them, and break their statues.
<G-vec00081-001-s643><break.zerbrechen><de> 24 Du sollst ihre Götter nicht anbeten noch ihnen dienen noch tun, wie sie tun, sondern du sollst ihre Steinmale umreißen und zerbrechen.
<G-vec00081-001-s644><break.zerbrechen><en> Dan 2,40 And there shall be a fourth kingdom, strong as iron, because iron breaks to pieces and shatters all things; and like iron which crushes, it shall break and crush all these.
<G-vec00081-001-s644><break.zerbrechen><de> Dan 2,40 Und das vierte wird hart sein wie Eisen; denn wie Eisen alles zermalmt und zerschlägt, ja, wie Eisen alles zerbricht, so wird es auch alles zermalmen und zerbrechen.
<G-vec00081-001-s645><break.zerbrechen><en> 22 Therefore thus says the Lord GOD: ‘Behold, I am against Pharaoh king of Egypt, and will break his arms, the strong arm, and that which was broken. I will cause the sword to fall out of his hand.
<G-vec00081-001-s645><break.zerbrechen><de> 22 Darum spricht der Herr, Jehova, also: Siehe, ich will an den Pharao, den König von Ägypten, und werde seine beiden Arme zerbrechen, den starken und den zerbrochenen, und werde das Schwert seiner Hand entfallen lassen.
<G-vec00081-001-s646><break.zerstören><en> Your goal is to break all the green tiles.
<G-vec00081-001-s646><break.zerstören><de> Ihr Ziel besteht darin, alle grünen Platten zu zerstören.
<G-vec00081-001-s647><break.zerstören><en> The task of the Communist Party in the dictatorship is thus this: to organize powerfully and definitively the class of workers and peasants in a dominant class, check that all the organisms of the new state really develop revolutionary work, and break the ancient rights and relations inherent in the principle of private property.
<G-vec00081-001-s647><break.zerstören><de> Die Aufgabe der kommunistischen Partei in der proletarischen Diktatur ist deshalb: die Klasse der Arbeiter und Bauern endgültig in einer herrschenden Klasse zu organisieren; zu kontrollieren, daß alle Organe des neuen Staates wirklich revolutionär arbeiten und die Vorrechte und alten, durch das Prinzip des Privateigentums bedingten Verhältnisse zerstören.
<G-vec00081-001-s648><break.zerstören><en> Her birth helps us to understand the loving, tender, compassionate plan of love in which God reaches down and calls us to a wonderful covenant with him, that nothing and no one will be able to break.
<G-vec00081-001-s648><break.zerstören><de> Ihre Geburt lässt uns die liebevolle, zärtliche, erbarmende Initiative der Liebe erahnen, mit der Gott sich bis zu uns herabneigt und uns zu einem wunderbaren Bund mit ihm ruft, den nichts und niemand zerstören können wird.
<G-vec00081-001-s649><break.zerstören><en> You’re probably well aware that a bad bit of code can essentially break your website.
<G-vec00081-001-s649><break.zerstören><de> Sie sind sich womöglich bewusst, dass ein schlechtes Stück Code Ihre gesamte Website zerstören kann.
<G-vec00081-001-s650><break.zerstören><en> On arriving at the suspension bridge, you must break the 1st cage under the bridge: Rayman frees a purple lumz, allowing him to reach the other end of the broken bridge.
<G-vec00081-001-s650><break.zerstören><de> Bei der Hängebrücke müsst ihr den ersten Käfig darunter zerstören: Dadurch kommt ein lilafarbener Lums zum Vorschein, mit dem ihr zur anderen Seite der zerstörten Brücke gelangen könnt.
<G-vec00081-001-s651><break.zerstören><en> However, texts fields are not modified because this could break the schematic.
<G-vec00081-001-s651><break.zerstören><de> Textfelder werden jedoch nicht geändert, weil das den Schaltplan zerstören könnte.
<G-vec00081-001-s652><break.zerstören><en> DRM is reinforced by censorship laws that ban software (and hardware) that can break the handcuffs.
<G-vec00081-001-s652><break.zerstören><de> DRM wird durch Zensurgesetze, die Software (und Hardware) verbieten, verstärkt, die die Handschellen zerstören könnten.
<G-vec00081-001-s653><break.zerstören><en> The super-rich are willing to use their money and influence to break the government—Meritocracy is designed to prevent this.
<G-vec00081-001-s653><break.zerstören><de> Die Superreichen sind gewillt, ihr Geld und ihren Einfluss dafür einzusetzen, den Staat zu zerstören – die Meritokratie hat das Ziel, dies zu verhindern.
<G-vec00081-001-s654><break.zerstören><en> There are however cases of people who break down their nervous balance by wrong practices — there the madness has nothing really to do with the sadhana.
<G-vec00081-001-s654><break.zerstören><de> Es gibt jedoch Menschen, die ihr nervliches Gleichgewicht durch falsche Praktiken zerstören – in solchen Fällen hat aber der Wahnsinn wirklich nichts mit der Sadhana zu tun.
<G-vec00081-001-s655><break.zerstören><en> Our users and developers are relying on the exact behaviour of a release once it is made, so any change we make can possibly break someone's system.
<G-vec00081-001-s655><break.zerstören><de> Unsere Benutzer und Entwickler vertrauen auf das fehlerfreie Verhalten eines Releases nach dessen Freigabe, daher kann jede Änderung, die wir durchführen, möglicherweise das System von jemandem zerstören.
<G-vec00081-001-s656><break.zerstören><en> To get the mystery just make a monster break the block containing it.
<G-vec00081-001-s656><break.zerstören><de> Um das Mystery zu bekommen, muss ein Monster einfach diesen Block zerstören.
<G-vec00081-001-s657><break.zerstören><en> Sparklike in a spark Sparklike was founded in 2000, when it licensed a technology developed at the University of Helsinki for measuring the gas fill level inside insulated glazing (IG) units without having to bore holes in the spacer of the IG unit or otherwise break it.
<G-vec00081-001-s657><break.zerstören><de> Sparklike im Überblick Sparklike wurde im Jahr 2000 gegründet, als der Lizenzantrag gestellt wurde für eine an der Universität von Helsinki entwickelte Technologie zur Messung des Gasgehaltes von Isolierglas (IG), bei der man keine Löcher in die IG-Zwischenräume bohren oder es auf andere Weise zerstören musste.
<G-vec00081-001-s658><break.zerstören><en> In line with comrade Themba’s report, the conference document affirmed: “Labor brokers are parasites who on behalf of big capitalists operate to obstruct union organization and ultimately to break the unions.
<G-vec00081-001-s658><break.zerstören><de> Im Einklang mit dem Bericht des Genossen Themba bekräftigte das Konferenzdokument: „Leiharbeitsfirmen sind Parasiten, die im Dienste der Großkapitalisten die gewerkschaftliche Organisierung behindern, um letztendlich die Gewerkschaften zu zerstören.
<G-vec00081-001-s659><break.zerstören><en> We had an agreement that this windowsill was “taboo” for the time being, that you couldn’t sit, climb around or play on it, and that everybody had to be careful not to break any of the pieces.
<G-vec00081-001-s659><break.zerstören><de> Wir hatten darüber gesprochen, dass nun die Fensterbank „tabu“ war, dass man dort nun nicht sitzen und klettern und spielen konnte, sondern vorsichtig sein sollte, um nichts zu zerstören.
<G-vec00081-001-s660><break.zerstören><en> Smiling will break your negative emotional patterns.
<G-vec00081-001-s660><break.zerstören><de> Das Lächeln wird Ihre negativen emotionalen Muster zerstören.
<G-vec00081-001-s661><break.zerstören><en> When deletion is requested or otherwise required, we will anonymise the data of data subjects and/or remove their information from publicly accessible sites if the deletion of data would break essential systems or damage the logs or records necessary to the operation, development, or archival records of the WordPress open source project.
<G-vec00081-001-s661><break.zerstören><de> Wenn eine Löschung beantragt oder anderweitig erforderlich ist, wird das WordPress-Core-Team die Daten der betroffenen Personen anonymisieren und/oder ihre Informationen von öffentlich zugänglichen Websites entfernen, wenn die Löschung der Daten wesentliche Systeme zerstören oder die für den Betrieb, die Entwicklung oder die Archivierung des Open-Source-Projekts WordPress erforderlichen Protokolle oder Aufzeichnungen beschädigen würde.
<G-vec00081-001-s662><break.zerstören><en> They have to “break it” and replace it by a radically different, democratic and non-statist form of political power.
<G-vec00081-001-s662><break.zerstören><de> Sie müssen ihn „zerstören“ und durch eine radikal andere, demokratische und nicht-dirigistische Form der politischen Macht ersetzen.
<G-vec00081-001-s663><break.zerstören><en> "For example, when selecting ""Bam"" (the yellow chick), you will be able to break walls with only one shot, but he's a bit slower than the other characters, so the puzzles will be solved in a different way."
<G-vec00081-001-s663><break.zerstören><de> "Wenn man zum Beispiel ""Bam"" wählt (das gelbe Küken), kann man Wände mit nur einem Schuss zerstören, aber er ist etwas langsamer als die anderen Charaktere, deshalb werden die Puzzles auf andere Art und Weise lösen."
<G-vec00081-001-s664><break.zerstören><en> It is incumbent to the Apostles of the Apocalypse, to break this wall of silence on the identity of the Star, the Beast of the Book of Revelation.
<G-vec00081-001-s664><break.zerstören><de> Es ist die Aufgabe der Apostel der Apokalypse diese Mauer der Stille bezüglich der Identität des Sternes, das Tier der Apokalypse, zu zerstören.
