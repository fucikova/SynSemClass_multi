<G-vec00206-001-s019><count.abzählen><en> They can count on the fingers.
<G-vec00206-001-s019><count.abzählen><de> Sie können an den Fingern abzählen.
<G-vec00206-001-s020><count.abzählen><en> In line 16, there is a ruler, which is supposed to make it easier for you to count the columns.
<G-vec00206-001-s020><count.abzählen><de> In Zeile 16 ist ein Lineal zu sehen, das das Abzählen von Spalten erleichtern soll.
<G-vec00206-001-s021><count.abzählen><en> "The Westinghouse Company presented ""Elektro"", a ""moto-man"", 7 feet (2,13 meter) large and 130 kilo heavy, which was able to count by his fingers [not really]."
<G-vec00206-001-s021><count.abzählen><de> "Die Firma Westinghouse präsentierte ""Elektro"" einen ""Moto-man"", 7 Fuß (2,13 Meter) gross und 130 Kilo schwer, der an den Fingern abzählen konnte [nicht wirklich]."
<G-vec00206-001-s022><count.abzählen><en> "9 ""You shall count seven weeks for yourself; you shall begin to count seven weeks from the time you begin to put the sickle to the standing grain."
<G-vec00206-001-s022><count.abzählen><de> 9 Sieben Wochen sollst du dir abzählen; wenn man anfängt, die Sichel an die Saat zu legen, sollst du anfangen, sieben Wochen zu zählen.
<G-vec00206-001-s023><count.abzählen><en> Until 2012, e-bike experts could still easily count the number of drive systems currently on the market on one hand.
<G-vec00206-001-s023><count.abzählen><de> Bis 2012 konnten E-Bike-Experten die Anzahl der marktrelevanten Antriebssysteme noch relativ leicht mit einer Hand abzählen.
<G-vec00206-001-s024><count.abzählen><en> Once again, the middle lines are drawn and the distance from it to the front, back, left and right are plotted (simply count the studs based on the front and side view).
<G-vec00206-001-s024><count.abzählen><de> Dazu werden ebenfalls wieder erst die vorhandenen Mittelachsen eingezeichnet und anschließend die Abstände der Mittelachsen nach rechts, links, vorne und hinten (einfach aus Seiten- und Frontansicht abzählen).
<G-vec00206-001-s025><count.abzählen><en> And you will be able to count the chosen ones of even a prominent place, very easily on your fingers.
<G-vec00206-001-s025><count.abzählen><de> - Und ihr werdet die Auserwählten eines bedeutenden Ortes sehr leicht an den Fingern abzählen können.
<G-vec00206-001-s026><count.abzählen><en> On two occasions I was placed over a chair and received 25 strokes with a rubber hose, which they obliged me to count myself.
<G-vec00206-001-s026><count.abzählen><de> Ich erhielt auf einem Stuhl liegend zweimal 25 Hiebe mit einem Gummischlauch, die ich selbst abzählen musste.
<G-vec00206-001-s027><count.abzählen><en> I can probably count on one hand the companies that I know who make an aisle runner worth anything.
<G-vec00206-001-s027><count.abzählen><de> Ich kann wahrscheinlich an einer Hand abzählen die Unternehmen, die ich kenne, der eine Schneise Läufer machen etwas wert.
<G-vec00206-001-s028><count.abzählen><en> We hurried onward and after the length of time it takes to count to a thousand, we came to the first cataract on the Nile.
<G-vec00206-001-s028><count.abzählen><de> Wir beschleunigten unsere Schritte und waren in der Zeit, in der man tausend Steine abzählen würde, an der ersten Abfallstelle des Nils.
<G-vec00206-001-s029><count.abzählen><en> You shall count seven weeks to yourselves;
<G-vec00206-001-s029><count.abzählen><de> Sieben Wochen sollst du dir abzählen.
<G-vec00206-001-s030><count.abzählen><en> The Jews, practical people that they are, were able to count on their fingers that “German fists” which have been unable to overthrow their own Prussian reaction, can hardly be expected to smash Russian absolutism. The Poles, exposed to the triple-headed war, were not in a position to answer their “liberators” in audible language.
<G-vec00206-001-s030><count.abzählen><de> Die Juden, ein praktisches Volk wie sie sind, mochten sich das einfache Rechenexempel an den Fingern abzählen, daß die „deutschen Fäuste“, die es nicht einmal fertiggebracht haben, ihre eigene preußische Reaktion, zum Beispiel das Dreiklassenwahlrecht, zu „zerschmettern“, wohl wenig tauglich sind, den russischen Absolutismus zu zerschmettern.
<G-vec00206-001-s031><count.abzählen><en> You have closely observed and seen that she can intuitively capture small quantities, but not yet count them safely.
<G-vec00206-001-s031><count.abzählen><de> Du hast genau beobachtet und gesehen, dass sie kleine Mengen zwar intuitiv erfassen, aber noch nicht sicher abzählen kann.
<G-vec00206-001-s032><count.abzählen><en> I can probably count on one hand the companies that I know who make an aisle runner worth anything.
<G-vec00206-001-s032><count.abzählen><de> Ich kann wahrscheinlich an einer Hand abzählen die Unternehmen, die ich kenne, eine Schneise Läufer etwas wert zu machen.
<G-vec00206-001-s033><count.abzählen><en> Anyway, in these parts it does not matter at all, since you can possibly count the buyers on one hand;) Bottom line: nice compilation, but far too much customized on the Spanish market.
<G-vec00206-001-s033><count.abzählen><de> Aber das dürfte hierzulande wohl sowieso egal sein, denn die Käufer kann man wohl an einer Hand abzählen;) Fazit: nette Compilation, die jedoch stark auf den spanischen Markt zugeschnitten ist.
<G-vec00206-001-s034><count.abzählen><en> If you rule out the “visits” when they were just bringing my Mom to see me, or pick her up, I can count on the toes of one hand how many times my family has visited me in those 21 years.
<G-vec00206-001-s034><count.abzählen><de> "Wenn Sie ausschließen, die ""Besuche"", wenn sie nur darauf, meine Mom, mich zu sehen, oder sie abholen, Ich kann auf die Zehen einer Hand abzählen, wie oft meine Familie hat mich in jene besucht 21 Jahre."
<G-vec00206-001-s035><count.abzählen><en> Our personal experience has shown that while it is mostly cloudy in July, but real rainy days you could count in the past 3 years on one hand, usually there was a heavy shower sometimes, but after half an hour it was all over.
<G-vec00206-001-s035><count.abzählen><de> Unsere persönliche Erfahrung hat gezeigt, dass es im Juli zwar mehrheitlich bewölkt ist, richtige Regentage konnte man aber in den letzten 3 Jahren an einer Hand abzählen, meist gab es ab und zu einen kräftigen Guss, nach einer halben Stunde war aber alles wieder vorbei.
<G-vec00206-001-s036><count.abzählen><en> You can count the number of polo clubs on one hand, and there are fewer than a hundred active polo players.
<G-vec00206-001-s036><count.abzählen><de> Die Polo Clubs lassen sich an einer Hand abzählen und die Zahl der aktiven Polo Player bewegt sich im zweistelligen Bereich.
<G-vec00206-001-s037><count.abzählen><en> I can count the jewelry that I wear every day on one hand: a few precious rings, my watch, a couple of necklaces, all quite simple, nothing too loud.
<G-vec00206-001-s037><count.abzählen><de> Die Schmuckstücke, die ich jeden Tag trage, kann ich an einer Hand abzählen: Einige mir wertvolle Ringe, meine Uhr, ein paar Ketten, alles eher zurückhaltend als prunkvoll.
<G-vec00206-001-s132><count.gelten><en> All scheduled MTTs with cash buy-ins will count towards this promotion.
<G-vec00206-001-s132><count.gelten><de> Alle geplanten MTTs mit Cash Buy-Ins gelten für diese Aktion.
<G-vec00206-001-s133><count.gelten><en> The British count as the pioneers of Swiss Tourism.
<G-vec00206-001-s133><count.gelten><de> Die Briten gelten als die Pioniere des Schweizer Tourismus.
<G-vec00206-001-s134><count.gelten><en> The Hohe Tauern National Park and its surrounding mountains count as the largest winter hiking territory in the Eastern Alps.
<G-vec00206-001-s134><count.gelten><de> Der Nationalpark Hohe Tauern und seine umliegenden Berge gelten als das größte Winterwanderrevier der Ostalpen.
<G-vec00206-001-s135><count.gelten><en> "It had already been agreed upon earlier which game was to count: ""Three under a hundred"" or ""Three-five-seven."""
<G-vec00206-001-s135><count.gelten><de> "Bevor dies geschah, wurde bereits vereinbart, welches Spiel gelten sollte: ""Drei unter Hundert"" oder ""Drei - fünf - sieben""."
<G-vec00206-001-s136><count.gelten><en> If I told you there would be more you would wait and be prepared, and then it wouldn’t count as one.
<G-vec00206-001-s136><count.gelten><de> Wenn ich dir sagen würde, dass es noch Chancen gibt, und du darauf warten und dich darauf vorbereiten würdest, würde es dann auch nicht mehr gelten.
<G-vec00206-001-s137><count.gelten><en> Treated and processed goods shall count as reserved merchandise as defined by these conditions.
<G-vec00206-001-s137><count.gelten><de> Be- und verarbeitete Ware gelten als Vorbehaltsware im Sinne dieser Bedingungen.
<G-vec00206-001-s138><count.gelten><en> "When she asked for it back, the police officer who was in charge of household registry said, ""Our words do not count for anything."
<G-vec00206-001-s138><count.gelten><de> "Als sie um die Rückgabe bat, sagte der für die Registrierung der Haushalte verantwortliche Polizist: ""Unsere Worte gelten nicht für alles."
<G-vec00206-001-s139><count.gelten><en> For the young people participating in our discussion, unlike for former generations, it is not only the important acts of great men that count as historical events but also the past of every-day people.
<G-vec00206-001-s139><count.gelten><de> Anders als dies wohl für frühere Generationen der Fall gewesen ist, gelten den hier zu Wort kommenden Jugendlichen eben nicht allein die bedeutenden Taten großer Männer als geschichtliche Ereignisse, sondern ebenso die Vergangenheit alltäglicher Menschen.
<G-vec00206-001-s140><count.gelten><en> How many children does each parent have for whom he or she has to make so many sacrifices of so many sorts before the children can grow to the point where they really count as human beings and the parents can relax some of their concern.
<G-vec00206-001-s140><count.gelten><de> Wieviele Kinder haben Eltern, für die sie so viele Opfer, so verschiedener Art bringen müssen, bevor die Kinder zu einem Punkt heranwachsen, an dem sie wirklich als menschliche Wesen gelten, und sich deren Eltern zu einem gewissen Punkt entspannen können.
<G-vec00206-001-s141><count.gelten><en> If you lose your job after working in your new country for more than 1 year, you have the right to continue to live there, provided you are registered as a jobseeker and continue to meet the conditions to count as a jobseeker.
<G-vec00206-001-s141><count.gelten><de> Wenn Sie Ihren Job verloren haben, nachdem Sie mehr als ein Jahr lang in Ihrem neuen Land gearbeitet haben, dürfen Sie weiterhin dort wohnen, sofern Sie als arbeitssuchend gemeldet sind und die Voraussetzungen erfüllen, um als Arbeitssuchende/-r zu gelten.
<G-vec00206-001-s142><count.gelten><en> Clothes regulations of the Taliban count to this piece of way.
<G-vec00206-001-s142><count.gelten><de> Für dieses Stück Weg gelten die Kleidungsvorschriften der Taliban.
<G-vec00206-001-s143><count.gelten><en> If they're dramatic, they count as feelings, they exist; if they're not dramatic, they don't count and they don't really exist.
<G-vec00206-001-s143><count.gelten><de> Wenn sie dramatisch sind, zählen sie als Gefühl, sie sind vorhanden; wenn sie nicht dramatisch sind, gelten sie nicht und sind eigentlich nicht vorhanden.
<G-vec00206-001-s144><count.gelten><en> The same conditions count for the eastern board of the Praya River. There the reserve was in March 2013 - as one can see on the photo, not more than 30 to 50cm, and every year it is 6 cm less...
<G-vec00206-001-s144><count.gelten><de> Dieselben Verhältnisse gelten für das Ostufer: Die Reserve betrug im März 2013 - so wie man auf dem Foto sieht, kaum mehr als 30 bis 50cm, und jedes Jahr werden es 6cm weniger...
<G-vec00206-001-s145><count.gelten><en> "Thinking: ""A friend is one, before which I am allowed to think loudly"" This quotation of the American philosopher Ralph Waldo Emerson will count also for our partnership."
<G-vec00206-001-s145><count.gelten><de> "Denken: ""Ein Freund ist einer, vor dem ich laut denken darf"" Dieses Zitat des amerikanischen Philosophen Ralph Waldo Emerson wird auch für unsere Partnerschaft gelten."
<G-vec00206-001-s146><count.gelten><en> Several ballot papers in one ballot paper envelope shall be regarded as one ballot paper if the markings are identical or if only one of them has been marked; otherwise they shall count as one ballot paper with two invalid votes.
<G-vec00206-001-s146><count.gelten><de> Mehrere in einem Stimmzettelumschlag enthaltene Stimmzettel gelten als ein Stimmzettel, wenn sie gleich lauten oder nur einer von ihnen gekennzeichnet ist; sonst gelten sie als ein Stimmzettel mit zwei ungültigen Stimmen.
<G-vec00206-001-s147><count.gelten><en> Because the glaciers found on Mars hold the greatest amount of water ice outside its poles – and therefore count as a possible candidate to find life on Mars. The Kaunertaler glacier is in many ways comparable to the glaciers on the red planet.
<G-vec00206-001-s147><count.gelten><de> Denn die bisher entdeckten Gletscher auf dem Mars halten die größten Mengen an Wassereis außerhalb der Pole – und gelten deshalb als ein möglicher Kandidat für Leben auf dem Mars.
<G-vec00206-001-s148><count.gelten><en> All part shipments of a contract count as special business operations.
<G-vec00206-001-s148><count.gelten><de> Alle Teillieferungen eines Abschlusses gelten als besondere Geschäfte.
<G-vec00206-001-s149><count.gelten><en> The following qualifications count as suitable evidence of these skills: certificates from higher technical institutes, universities and third-level colleges and relevant training courses.
<G-vec00206-001-s149><count.gelten><de> Als Nachweis gelten Zeugnisse von Höheren technischen Lehranstalten, Zeugnisse von Universitäten und Fachhochschulen sowie Bestätigungen über einschlägige Fort- und Weiterbildungen.
<G-vec00206-001-s150><count.gelten><en> The most popular functional areas of transportation, turnover, consignment sales, packaging as well as control of production processes count as the most popular applications within logistics.
<G-vec00206-001-s150><count.gelten><de> Als populärste Anwendungen innerhalb der Logistik gelten die Funktionsbereiche Transport, Umschlag, Kommissionierung, Verpackung sowie die Steuerung von Produktionsabläufen.
<G-vec00206-001-s151><count.zählen><en> Red threes count for the players if they are laid down on the table with their melds and against if not.
<G-vec00206-001-s151><count.zählen><de> Die roten Dreien werden für den Spieler gezählt, wenn diese auf dem Tisch neben dessen Meldung liegen, und gegen den Spieler, wenn dies nicht der Fall ist.
<G-vec00206-001-s152><count.zählen><en> With five reels and five paylines come Dragons treasure and all winnings will count from left to right.
<G-vec00206-001-s152><count.zählen><de> Mit fünf Walzen und fünf Gewinnlinien ist Dragons Treasure ausgestattet und die Gewinne werden von links nach rechts gezählt.
<G-vec00206-001-s153><count.zählen><en> Any hands and/or games played prior to opting in will not count towards the progress.
<G-vec00206-001-s153><count.zählen><de> Alle Hände und/oder Spiele, die Sie vor der Anmeldung gespielt haben, werden nicht gezählt.
<G-vec00206-001-s154><count.zählen><en> In this article, I will talk about how to count the unique values in pivot table.
<G-vec00206-001-s154><count.zählen><de> In diesem Artikel werde ich darüber sprechen, wie die eindeutigen Werte in der Pivot-Tabelle gezählt werden.
<G-vec00206-001-s155><count.zählen><en> The owner was furious, but the owner was an Indian, so his opinion did not count for much.
<G-vec00206-001-s155><count.zählen><de> Der Besitzer war wütend, aber der Besitzer war ein Indianer, also hat seine Meinung nicht viel gezählt.
<G-vec00206-001-s156><count.zählen><en> Here I will provide a specific example to explain how to count cells particle equal to given value.
<G-vec00206-001-s156><count.zählen><de> Hier werde ich ein konkretes Beispiel geben, um zu erklären, wie Zellenpartikel mit dem angegebenen Wert gezählt werden.
<G-vec00206-001-s157><count.zählen><en> Note that the bishops on a1 and h1 are exchangeable with pawns at the same positions. I count this as one solution only.
<G-vec00206-001-s157><count.zählen><de> Bei der ersten Stellung sind die Läufer auf a1 und h1 mit den Bauern auf den gleichen Positionen austauschbar und deshalb wird diese nur als eine Lösung gezählt.
<G-vec00206-001-s158><count.zählen><en> The only field defined in mt_erreg is the recovered error count in the low 16 bits (as defined by MT_ST_SOFTERR_SHIFT and MT_ST_SOFTERR_MASK).
<G-vec00206-001-s158><count.zählen><de> "Das einzige definierte Feld in mt_erreg ist der "" Fehlerzähler"" (Es werden nur behobene Fehler gezählt) in den unteren 16 Bits (wie durch MT_ST_SOFTERR_SHIFT und MT_ST_SOFTERR_MASK definiert)."
<G-vec00206-001-s159><count.zählen><en> Early marriage and desire for sons is believed to be the biggest problems, but also developing country problems such as illiteracy and ignorance about contraception count as major concerns.
<G-vec00206-001-s159><count.zählen><de> Frühe Heirat und der Wunsch nach Söhnen wird angenommen, dass die größten Probleme, sondern auch die Entwicklungsländer Probleme wie Analphabetismus und Unwissenheit über Empfängnisverhütung als wichtige Anliegen gezählt.
<G-vec00206-001-s160><count.zählen><en> Although the pin count is loaded to one side, there is no lack of rivalry in this extraordinary encounter that sees both contrasting combatants perform with breathtaking determination.
<G-vec00206-001-s160><count.zählen><de> Obwohl die Pins nur auf einer Seite gezählt werden fehlt es nicht an Rivalität in diesem aussergewöhnlichem Kampf, in welchem beide gegensätzlichen Kämpferinnen mit atemberaubender Zielstrebigkeit performen.
<G-vec00206-001-s161><count.zählen><en> In the formula, A2 contains the text string which you want to count occurrences of specific character from.
<G-vec00206-001-s161><count.zählen><de> In der Formel A2 enthält die Textzeichenfolge, aus der Vorkommen von bestimmten Zeichen gezählt werden sollen.
<G-vec00206-001-s162><count.zählen><en> I can tell you that my Law Bodies are innumerable, they're impossible to count.
<G-vec00206-001-s162><count.zählen><de> Ich sage euch, ich habe unzählige Fashen, die nicht gezählt werden können.
<G-vec00206-001-s163><count.zählen><en> Biggest number of servers is in the US, I think I didn't count.
<G-vec00206-001-s163><count.zählen><de> Größte Anzahl von Servern in den USA, Ich glaube, ich habe sie nicht gezählt.
<G-vec00206-001-s164><count.zählen><en> The COUNTIF function is a statistical function in Excel which is used to count the number of cells that meet a criterion.
<G-vec00206-001-s164><count.zählen><de> Die COUNTIF function ist eine statistische Funktion in Excel, mit der die Anzahl der Zellen gezählt wird, die ein Kriterium erfüllen.
<G-vec00206-001-s165><count.zählen><en> Select the range that you will count cells by specific formatting, and open the Find and Replace dialog by pressing the Ctrl + F keys simultaneously.
<G-vec00206-001-s165><count.zählen><de> Wählen Sie den Bereich aus, in dem die Zellen nach einer bestimmten Formatierung gezählt werden, und öffnen Sie das Dialogfeld Suchen und Ersetzen, indem Sie die Taste drücken Ctrl + F Schlüssel gleichzeitig.
<G-vec00206-001-s166><count.zählen><en> We didn't count the stairs to the top of the 64 meter (210 feet) tall pyramid but some of them are so high that cables have been put in to help visitors climb up hand over hand.
<G-vec00206-001-s166><count.zählen><de> Wir haben die Stufen bis zur Spitze der 64m hohen Pyramide nicht gezählt, aber einige von ihnen sind so hoch, dass zur Unterstützung der Kletterer Seile angebracht wurden, an denen man sich in die Höhe hangeln kann.
<G-vec00206-001-s167><count.zählen><en> 1) In the formula, B1 and B2 contain the start date and end date you will count days between.
<G-vec00206-001-s167><count.zählen><de> 1) In der Formel enthalten B1 und B2 das Startdatum und das Enddatum, zwischen denen die Tage gezählt werden.
<G-vec00206-001-s168><count.zählen><en> Note that 802.11 Management Frames and Control Frames don't count as data. Roam performance
<G-vec00206-001-s168><count.zählen><de> Beachten Sie, dass 802.11-Verwaltungs- und Steuerungs-Frames nicht als Daten gezählt werden.
<G-vec00206-001-s169><count.zählen><en> Major molecular response (MMR) —PCR (a blood test that allows to detect and count very small amounts of specific parts of a gene) can still detect BCR-ABL, but at a low level (BCR-ABL levels below 0.1%).
<G-vec00206-001-s169><count.zählen><de> Gutes molekulares Ansprechen (MMR) —Mit PCR (einem Bluttest, mit dem sehr kleine Mengen eines bestimmten Teils eines Gens entdeckt und gezählt werden können) ist immer noch BCR-ABL nachweisbar, allerdings in sehr geringer Menge (Menge an BCR-ABL unter 0,1 %).
<G-vec00206-001-s246><count.rechnen><en> All people in need may count on the company’s support, although children from the poorest families, the disabled and sick have the priority.
<G-vec00206-001-s246><count.rechnen><de> Mit der Unterstützung durch die Firma können alle Bedürftigen rechnen, bevorzugt sind jedoch Kinder aus ärmsten Familien, Behinderte und Kranke.
<G-vec00206-001-s247><count.rechnen><en> Lessons schedule is only published on Thursdays on our Facebook page to make sure that we can count with adequate sea and weather conditions.
<G-vec00206-001-s247><count.rechnen><de> Der Unterrichtsplan wird nur Donnerstags auf unserer Facebook-Seite veröffentlicht, um gewährleisten zu können, dass wir mit angemessenen Meeres- und Wetterbedingungen rechnen können.
<G-vec00206-001-s248><count.rechnen><en> To increase the granulocyte count in patients with aplastic anemia.
<G-vec00206-001-s248><count.rechnen><de> Um rpaHyлoциT zu vergrößern rechnen bei den Patientinnen mit aплacTичeckoй von der Anämie.
<G-vec00206-001-s249><count.rechnen><en> And they can also count on the love of the Father.
<G-vec00206-001-s249><count.rechnen><de> Sie können auch mit dieser Liebe des Vaters rechnen.
<G-vec00206-001-s250><count.rechnen><en> "Germans carry a particular responsibility, as the historian Constantin Goschler argues: ""The German comeback after World War II had much to do with the generosity of their former adversaries, who could in turn count on profiting from West Germany's economic strength."
<G-vec00206-001-s250><count.rechnen><de> "Den Deutschen obliegt also eine besondere Verantwortung, wie der Historiker Constantin Goschler ausführt: ""Der deutsche Wiederaufstieg nach dem Zweiten Weltkrieg hatte viel mit der Großzügigkeit der ehemaligen Gegner zu tun, die im Gegenzug damit rechnen konnten, von der ökonomischen Stärke der Bundesrepublik zu profitieren."
<G-vec00206-001-s251><count.rechnen><en> Because the big parliament negotiates about it at present, at first we count in 2006 on the final law.
<G-vec00206-001-s251><count.rechnen><de> Da das große Parlament darüber zurzeit verhandelt, rechnen wir anfangs 2006 mit dem endgültigen Gesetz.
<G-vec00206-001-s252><count.rechnen><en> We can count on the politically conscious workers alone; the remaining mass, the bourgeoisie and the petty proprietors, are against us; they do not believe in the new order and take advantage of every opportunity to worsen the plight of the people.
<G-vec00206-001-s252><count.rechnen><de> Wir können nur auf die klassenbewußten Arbeiter rechnen; die übrige Masse, die Bourgeoisie und die Kleineigentümer, sind gegen uns, sie glauben nicht an die neue Ordnung, sie greifen jede Gelegenheit auf, um die Not des Volkes zu verschärfen.
<G-vec00206-001-s253><count.rechnen><en> I was never disappointed, in problematic situations I can always count on quick and effective response.
<G-vec00206-001-s253><count.rechnen><de> Ich war nie enttäuscht, in den Problemsituationen konnte ich auf schnelle und erfolgreiche Reaktion rechnen.
<G-vec00206-001-s254><count.rechnen><en> Please count on our prayers as we count on yours,
<G-vec00206-001-s254><count.rechnen><de> Sie können mit unserem Gebet rechnen, ebenso wie wir mit Ihnen rechnen.
<G-vec00206-001-s255><count.rechnen><en> Please count on our prayers as we count on yours,
<G-vec00206-001-s255><count.rechnen><de> Sie können mit unserem Gebet rechnen, ebenso wie wir mit Ihnen rechnen.
<G-vec00206-001-s256><count.rechnen><en> It is necessary to consider that children often play on a floor, hence, proceeding from it, and it is necessary to count light exposure of a room.
<G-vec00206-001-s256><count.rechnen><de> Man muss berücksichtigen, dass die Kinder auf dem Fußboden, also ausgehend davon häufig spielen, und man muss die Beleuchtungsstärke des Zimmers rechnen.
<G-vec00206-001-s257><count.rechnen><en> Besides, unlike poor countries, they can already count on the introduction of automatic information exchange.
<G-vec00206-001-s257><count.rechnen><de> Im Gegensatz zu den ärmeren Ländern dürfen sie außerdem bereits mit dem automatischen Informationsaustausch rechnen.
<G-vec00206-001-s258><count.rechnen><en> You can count on the best materials, combined with the accuracy one would expect of a clock.
<G-vec00206-001-s258><count.rechnen><de> Sie können mit den besten Materialien rechnen, die mit der Genauigkeit kombiniert wird, die Sie von einer Wanduhr erwarten dürfen.
<G-vec00206-001-s259><count.rechnen><en> Something similar applies to montage, in other words the sudden moments of aleatoric but evident connection, which are always past as soon as they are seen … – Because we not only start from a non-continuum between viewers and “reality, but also from a non-continuum between our respective elements of temporality as authors/speakers/filmmakers and try to count on something like a “media agency, which allows that which exists to happen between things, persons and signs.
<G-vec00206-001-s259><count.rechnen><de> Ähnliches gilt für die Montage, also die plötzlichen Momente von aleatorischer, aber evidenter Verbindung, die immer schon vorbei sein werden, wenn sie gesehen sind … – Denn wir gehen nicht nur von einem Nicht-Kontinuum zwischen Zuschauer_innen und Wirklichkeit“ aus, sondern ebenso von einem Nicht-Kontinuum zwischen unseren jeweiligen Elementen der Zeitlichkeit als Autor_innen/Sprecher_innen/Filmemacher_innen und versuchen, mit so etwas wie einer medialen Agency“ zu rechnen, die das, was ist, zwischen Dingen, Personen und Zeichen passieren ließe.
<G-vec00206-001-s260><count.rechnen><en> In order to place the proletariat in the best position during the ensuing battles, the leadership took the stance that although the greatest efforts should be made to use the traditional apparatus of the Red organisations, it was also necessary to warn the proletariat not to count on anything from the maximalists and reformists, who would even go so far as accepting a peace treaty with fascism.
<G-vec00206-001-s260><count.rechnen><de> Um für die weiteren Kämpfe der Arbeiterklasse die bestmöglichen Voraussetzungen zu schaffen, gab die Zentrale die Weisung, unbedingt den traditionellen Gewerkschaftsapparat zu nutzen, zugleich aber auch dem Proletariat vor Augen zu führen, nicht mit Maximalisten und Reformisten rechnen zu können, unter deren Führung die Gewerkschaften standen und die so weit gingen, einen Friedenspakt mit den Faschisten zu unterzeichnen.
<G-vec00206-001-s261><count.rechnen><en> It seems so unreal to them that they would much rather portray you as fantasists than to take your words to heart and to count on their likelihood.
<G-vec00206-001-s261><count.rechnen><de> Es erscheint ihnen so unwirklich, daß sie weit eher euch als Phantasten bezeichnen, als eure Worte sich zu Herzen zu nehmen und mit der Wahrscheinlichkeit zu rechnen.
<G-vec00206-001-s262><count.rechnen><en> According to the law, every citizen, except lifelong payments of pension funds, can count on lump sum payments to pensioners.
<G-vec00206-001-s262><count.rechnen><de> Nach dem Gesetz kann jeder Bürger mit Ausnahme der lebenslangen Zahlungen der Pensionskassen mit Pauschalzahlungen an die Rentner rechnen.
<G-vec00206-001-s263><count.rechnen><en> Fortunately, the Good News is not dependent on things like a trailer and we can continue to count on God's intervention.
<G-vec00206-001-s263><count.rechnen><de> Gott sei Dank ist die Gute Nachricht nicht abhängig von einem Anhänger und wir können weiterhin mit Gottes Wirken rechnen.
<G-vec00206-001-s264><count.rechnen><en> If you are knitting a sweater, you can count two ways.
<G-vec00206-001-s264><count.rechnen><de> Wenn du einen Pullover strickst, kannst du auf zwei Wegen rechnen.
<G-vec00206-001-s398><count.zählen><en> "In an old house in the ""Chaldäergasser"" the ghost of a miser, chained to his treasure-chests, is cursed to count coins every night."
<G-vec00206-001-s398><count.zählen><de> "In einem alten Haus in der ""Chaldäergasser"" ist der Geist eines Geizhalses, an seine Schatzkiste gekettet, dazu verflucht, jede Nacht Münzen zu zählen."
<G-vec00206-001-s399><count.zählen><en> I do not advise you to count the signs of darkness, they lead only to obscurity.
<G-vec00206-001-s399><count.zählen><de> Ich rate Euch nicht, die Zeichen der Dunkelheit zu zählen, sie führen nur zu Verfinsterung.
<G-vec00206-001-s400><count.zählen><en> However, they count double for any of the princesses or animals – and generate winnings of 300 for three symbols, 1,000 for four and 10,000 for five.
<G-vec00206-001-s400><count.zählen><de> Allerdings zählen sie doppelt für die Prinzessinnen oder die Tiere und sorgen für Gewinne von 300 bei drei, 1000 bei vier und 10.000 bei fünf Symbolen.
<G-vec00206-001-s401><count.zählen><en> For those individuals who read this and are already greatly indebted to the material proclivities, this may be a difficult choice and one that is almost impossible; therefore, during those hours that a parent is available with the child, parents are urged to make every moment count by maintaining a conscious presence with the child.
<G-vec00206-001-s401><count.zählen><de> Für jene Menschen, die sich bereits tief in dieser materiellen Vorliebe verschuldet haben und die dies hier lesen, mag das eine schwierige Entscheidung sein, eine, die beinahe unmöglich erscheint; deshalb sind Eltern während dieser Stunden in denen sie dem Kind zur Verfügung stehen angehalten jeden Moment zählen zu lassen, indem sie eine bewußte Präsenz mit dem Kind beibehalten.
<G-vec00206-001-s402><count.zählen><en> And Health Mate can count anybody's steps for free, as long as they have the app on their smartphone.
<G-vec00206-001-s402><count.zählen><de> Und Health Mate kann die Schritte von allen Teilnehmern kostenlos zählen, solange die App auf deren Smartphone installiert ist.
<G-vec00206-001-s403><count.zählen><en> It is thanks to them that we can count, make calculations and solve certain problems.
<G-vec00206-001-s403><count.zählen><de> Ihnen ist es zu verdanken, dass wir zählen, rechnen und bestimmte Probleme lösen können.
<G-vec00206-001-s404><count.zählen><en> And so on, until you count to one hundred, without losing concentration.
<G-vec00206-001-s404><count.zählen><de> Und so weiter, bis Sie hundert zählen, ohne die Konzentration zu verlieren.
<G-vec00206-001-s405><count.zählen><en> In times in which communication and global thinking are increasingly important, and in times in which innovation and change count to the usual daily business of successful, competitive organisations, we are glad to be in the position to make our offer available not only in german and english, but from now on as well in spanish language.
<G-vec00206-001-s405><count.zählen><de> In Zeiten in denen Kommunikation und globales Denken zunehmend an Wichtigkeit gewinnen, und Innovation und Wandel zum täglichen Geschäft erfolgreicher Unternehmen zählen, freuen wir uns Ihnen unser Angebot ab sofort auch in spanischer Sprache zur Verfügung stellen zu können.
<G-vec00206-001-s406><count.zählen><en> The points collected in all the races count towards the 2017 Louis Vuitton Challenger Series — where all six teams, including defender Oracle Team USA, will each race each other to select who challenges for the Louis Vuitton America’s Cup.
<G-vec00206-001-s406><count.zählen><de> Die gesammelten Punkte zählen für die Louis Vuitton Challenger Series 2017, wenn alle sechs Teams inklusive dem Titelverteidiger des America’s Cup, Team Oracle USA, zwei Mal gegeneinander fahren, um den Herausforderer für den Louis Vuitton America’s Cup zu ermitteln.
<G-vec00206-001-s407><count.zählen><en> as char(24) character set utf8)) from rdb$database -- returns 208: all 24 CHAR positions count, and two of them are 16-bit
<G-vec00206-001-s407><count.zählen><de> as char(24) character set utf8)) from rdb$database -- ergibt 208: alle 24 CHAR -Positionen zählen ud zwei von ihnen haben 16 Bit.
<G-vec00206-001-s408><count.zählen><en> We forcefully reject, however, the logic under which only patriotic Kurds count.
<G-vec00206-001-s408><count.zählen><de> Aber wir lehnen die zugrunde gelegte Logik, wonach nur patriotische Kurden zählen, entschieden ab.
<G-vec00206-001-s409><count.zählen><en> During their vacation in Livorno, tourists can count on many demonstrations and musical performances at Livorno .
<G-vec00206-001-s409><count.zählen><de> In ihrem Urlaub in Livorno, Touristen können auf vielen zählen Demonstrationen und Musikaufführungen bei Livorno .
<G-vec00206-001-s410><count.zählen><en> Count on us to help you install, configure, and use PosterJet – even before you buy.
<G-vec00206-001-s410><count.zählen><de> Egal, ob Installation, Konfiguration oder Benutzung von PosterJet, zählen Sie auf unsere Unterstützung – und das auch schon vor dem Kauf.
<G-vec00206-001-s411><count.zählen><en> The arrival and departure days count as one day.
<G-vec00206-001-s411><count.zählen><de> An- und Abreisetag zählen als ein Tag.
<G-vec00206-001-s412><count.zählen><en> In any case, Sauces of the brand “Tabasco” are not said to count as one of the specialities of the restaurant.
<G-vec00206-001-s412><count.zählen><de> Das Angebot von Soßen der Marke „Tabasco“ soll jedenfalls nicht zu den speziellen Vorzügen des Restaurants zählen.
<G-vec00206-001-s413><count.zählen><en> Whether your event is small (the Bar 21 can be set up to receive between 15 and 40 delegates) or large (in total, all the spaces available can accommodate up to 380 delegates), you can count on a beautiful setting and personal and professional service to ensure everything goes smoothly.
<G-vec00206-001-s413><count.zählen><de> Unabhängig davon, ob Sie einen kleinen (in der Bar 21 finden zwischen 15 und 40 Teilnehmer Platz) oder großen Anlass (insgesamt finden bis zu 380 Teilnehmer Platz) planen, Sie können auf die herrliche Lage und das Personal mit dem professionellen Service zählen, das dafür sorgt, dass Ihr Anlass reibungslos abläuft.
<G-vec00206-001-s414><count.zählen><en> Create Conditional Formula is a wizard in Optipe Data Tools Suite that lets you create in the currently selected cell a formula to find, count or add data conditionally, for one or multiple criteria, similar to Merge Tables application.
<G-vec00206-001-s414><count.zählen><de> Erstellen Bedingte Formel wird ein Assistent in Optipe Data Tools Suite, die, schafft in der aktuell ausgewählten Zelle, eine Formel bedingte: zu finden, zählen oder Summendaten; für ein oder mehrere Kriterien, ähnlich wie die Verknüpfen von Tabellen Anwendung.
<G-vec00206-001-s415><count.zählen><en> Go through the lists and cross out any attributes and values that you share with your competitors, because they don't count.
<G-vec00206-001-s415><count.zählen><de> Die Listen und das Kreuz heraus laufen alle mögliche Attribute und Werte durch, die Sie mit Ihren Konkurrenten teilen, weil sie nicht zählen.
<G-vec00206-001-s416><count.zählen><en> At some point, we could not count the number of times we had mutually assured each other during the six days in the House Lentischio that we could not find any better accommodation.
<G-vec00206-001-s416><count.zählen><de> Irgendwann konnten wir nicht mehr zählen, wie oft wir uns in den sechs Tagen im Haus Lentischio gegenseitig versichert haben, dass wir keine bessere Unterkunft hätten finden können.
<G-vec00206-001-s433><count.zählen><en> First impressions count – and that's what swayed MOST Mobile in favor of pladur® Relief Wood.
<G-vec00206-001-s433><count.zählen><de> Der erste Eindruck zählt – und daher entschied sich das Unternehmen MOST Mobile für die Coil-Coating-Oberfläche pladur® Relief Wood.
<G-vec00206-001-s434><count.zählen><en> The remaining Talon triple will later count to the opponent’s tricks.
<G-vec00206-001-s434><count.zählen><de> Das zweites Talon Triple zählt am Ende zum Team der Gegner.
<G-vec00206-001-s435><count.zählen><en> Take a walk, count to ten or fifteen, or divert your mind to something pleasant.
<G-vec00206-001-s435><count.zählen><de> Macht einen kleinen Spaziergang, zählt bis zehn oder fünfzehn und lenkt euch durch irgendetwas Schönes ab.
<G-vec00206-001-s436><count.zählen><en> Step 10: Rooting will begin with a progress percentage count like in screenshot below.
<G-vec00206-001-s436><count.zählen><de> Schritt 10: Rooting wird mit einem Fortschrittsprozent beginnen zählt wie in Abbildung unten.
<G-vec00206-001-s437><count.zählen><en> What she asks, doesn’t count.
<G-vec00206-001-s437><count.zählen><de> Was sie sagt, zählt nicht.
<G-vec00206-001-s438><count.zählen><en> Make every shot count and see your controller brought to life in-game as a virtual weapon, bringing deadly precision to compatible PS VR shooter games.
<G-vec00206-001-s438><count.zählen><de> Jeder Schuss zählt: Dieser Controller erwacht in deinen Spielen als virtuelle Waffe zum Leben und ermöglicht dir bei kompatiblen PS VR-Shootern tödliche Präzision.
<G-vec00206-001-s439><count.zählen><en> Under the phase contrast, the live cells will appear bright and golden and should be counted; do not count any of the dull, dead, blue cells.
<G-vec00206-001-s439><count.zählen><de> Unter Phasenkontrast erscheinen lebende Zellen hell und golden und sollten gezählt werden; Zellen die trüb, tot und blau sind zählt man nicht.
<G-vec00206-001-s440><count.zählen><en> Count the dishes out too.
<G-vec00206-001-s440><count.zählen><de> Zählt auch nicht auf die Teller.
<G-vec00206-001-s441><count.zählen><en> He takes pinhole images, alienates them, repeats them, builds collages, emphasizes text fragments, also repeats these, SICK OF GOODBYS, turns Skylines upside down, interlaces everything with gatefolds, starts giving the count with 1 and 2, lands on the 9, then REVOLUTION, then 9, then ciphers, then 9...
<G-vec00206-001-s441><count.zählen><de> Er nimmt Lochkamerabilder, verfremdet sie, wiederholt sie, baut Collagen, hebt Textfragmente hervor, wiederholt auch diese, SICK OF GOODBYS, stellt Skylines auf den Kopf, verschachtelt alles mit Gatefolds, zählt an mit 1 und 2, landet auf der 9, dann REVOLUTION, dann 9, dann Chiffren, dann 9...
<G-vec00206-001-s442><count.zählen><en> First impressions count: The new Welcome Center in the entrance hall of the nora Weinheim, Germanytraining and information center displays an attractive and modern look.
<G-vec00206-001-s442><count.zählen><de> Der erste Eindruck zählt: Im attraktiven Look präsentiert sich das neue Welcome Center im Eingangsbereich des Schulungs- und Informationszentrums.
<G-vec00206-001-s443><count.zählen><en> WHO has recently published new tools that show the way forward for health care facilities and countries: The WHO application of ICD-10 to deaths during the perinatal period: ICD-PM; and Making every baby count: audit and review of stillbirths and neonatal deaths.
<G-vec00206-001-s443><count.zählen><de> Die WHO hat vor kurzem neue Instrumente veröffentlicht, die als Wegweiser für die Länder und ihre Gesundheitseinrichtungen gedacht sind: Die WHO-Anwendung des ICD-10 auf Todesfälle während der Perinatalperiode: ICD-PM und Jedes Baby zählt: Überprüfung der Zahl der Totgeburten und der Todesfälle bei Neugeborenen.
<G-vec00206-001-s444><count.zählen><en> "A rental with one or more Free Rental Days (""Free Rental Days"") will count as a Qualified Rental as long as there is a minimum of one paid rental day."
<G-vec00206-001-s444><count.zählen><de> "Eine Anmietung mit einem oder mehreren kostenfreien Miettagen (""kostenfreie Miettage"") zählt als qualifizierende Anmietung, solange sie zumindest einen bezahlten Miettag umfasst."
<G-vec00206-001-s445><count.zählen><en> First impressions count, and I loved what I was seeing in front of me as I slipped off the red sleeve and opened the box.
<G-vec00206-001-s445><count.zählen><de> Der erste Eindruck zählt, und ich liebte das, was ich vor mir sah, als ich den roten Ärmel abriss und die Schachtel öffnete.
<G-vec00206-001-s446><count.zählen><en> The Campagnolo Vintage Wall Clock will count down the minutes until your next ride or race.
<G-vec00206-001-s446><count.zählen><de> Die Campagnolo-Vintage-Wanduhr zählt die Minuten, die Sie von Ihrer nächsten Fahrradfahrt oder vom nächsten Radrennen trennen.
<G-vec00206-001-s447><count.zählen><en> Perhaps he gives up too fast; or perhaps he doesn't try to enforce his wishes, because anything you have to force someone to do doesn't count as love or understanding.
<G-vec00206-001-s447><count.zählen><de> Vielleicht gibt er zu früh auf oder vielleicht versucht er erst gar nicht, seine Wünsche durchzusetzen, weil alles, wozu er jemanden zwingen muss, für ihn nicht als Liebe oder Verständnis zählt.
<G-vec00206-001-s448><count.zählen><en> When winter starts turning to spring, Uimonen goes round the potential breeding den sites to count how many of them have been occupied – and how many new pups have been raised safely thanks to the volunteers' work.
<G-vec00206-001-s448><count.zählen><de> Wenn der Frühling den Winter verdrängt, sucht Uimonen die möglichen Bruthöhlen auf, und zählt, wie viele belegt sind und wie viele Jungtiere dank der Freiwilligen sicher aufgezogen wurden.
<G-vec00206-001-s449><count.zählen><en> Khuzestan is a center of the Iranian oil industry, vast new oilfields are being developed, and obviously, they count on technology made in Germany.
<G-vec00206-001-s449><count.zählen><de> In Khuzestan befinden sich die größten Ölförderanlangen des Iran, weitere Ölfelder warten auf Erschließung, und ganz offen zählt man dabei auf Technologie Made in Germany.
<G-vec00206-001-s450><count.zählen><en> """Neutral"" doesn't count as connection but is a interruption in the web."
<G-vec00206-001-s450><count.zählen><de> """Neutral"" zählt nicht als Verbindung, sondern ist eine Unterbrechung des Netzes."
<G-vec00206-001-s451><count.zählen><en> But that still doesn't count in the science system.
<G-vec00206-001-s451><count.zählen><de> Aber noch zählt das nicht im Wissenschaftssystem.
