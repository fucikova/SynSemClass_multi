<G-vec00092-001-s057><call.bezeichnen><en> The offers of the tantric scene, which I got to know, I would not call the same.
<G-vec00092-001-s057><call.bezeichnen><de> Ich würde die Angebote der Tantra-Szene, die ich kennengelernt habe, nicht als das bezeichnen wollen.
<G-vec00092-001-s058><call.bezeichnen><en> Well, I read it and I would call it revolutionary.
<G-vec00092-001-s058><call.bezeichnen><de> Ich habe es gelesen und würde es als revolutionär bezeichnen.
<G-vec00092-001-s059><call.bezeichnen><en> That is something we would call highly concentrated.
<G-vec00092-001-s059><call.bezeichnen><de> So etwas würden WIR als hochkonzentriert bezeichnen.
<G-vec00092-001-s060><call.bezeichnen><en> What people call practice these days is not really practice.
<G-vec00092-001-s060><call.bezeichnen><de> Was die Leute heutzutage als Praxis bezeichnen, ist keine wirkliche Praxis mehr.
<G-vec00092-001-s061><call.bezeichnen><en> I would call it repressive tolerance, and it's still the case today.
<G-vec00092-001-s061><call.bezeichnen><de> Ich würde das als »repressive Toleranz« bezeichnen, ein Prinzip, das auch heute noch zu beobachten ist.
<G-vec00092-001-s062><call.bezeichnen><en> “Mystical bird” the Romanians call the capercaillie.
<G-vec00092-001-s062><call.bezeichnen><de> Als „mystischen Vogel“ bezeichnen die Rumänen den Auerhahn.
<G-vec00092-001-s063><call.bezeichnen><en> First, the introduction of the common currency led to a huge movement of capital into those countries that we today call PIIGS or periphery countries.
<G-vec00092-001-s063><call.bezeichnen><de> Zunächst löste die Einführung der gemeinsamen Währung eine enorme Kapitalbewegung in die Länder aus, die wir heute als PIIGS oder Peripheriestaaten bezeichnen.
<G-vec00092-001-s064><call.bezeichnen><en> We can only call them evil policemen.
<G-vec00092-001-s064><call.bezeichnen><de> Wir können sie nur als bösartige Polizisten bezeichnen.
<G-vec00092-001-s065><call.bezeichnen><en> """I wish you'd call it what it is,"" she said."
<G-vec00092-001-s065><call.bezeichnen><de> """Ich wünschte, du würdest ihn als das bezeichnen, was er ist"", sagte sie."
<G-vec00092-001-s066><call.bezeichnen><en> "Some people would call that ""progress"" or ""innovation""."
<G-vec00092-001-s066><call.bezeichnen><de> "Manche würden das jetzt als ""Fortschritt"" oder auf neudeutsch ""Innovation"" bezeichnen."
<G-vec00092-001-s067><call.bezeichnen><en> "A being can also have an incurable illness that is rapidly leading towards the destruction of the organism or body, towards what we call ""death"", and from the point of view of the body the situation is hopeless, but behind this hopelessness there is still burning a tiny flame from Paradise."
<G-vec00092-001-s067><call.bezeichnen><de> Ein Wesen kann auch einer unheilbaren Krankheit ausgesetzt sein, die den Organismus oder Körper unaufhaltsam seinem Untergang, d.h. dem, was wir als „Tod“ bezeichnen, entgegenführt, und die Situation ist damit körperlich gesehen hoffnungslos, aber trotzdem lodert hinter dieser Hoffnungslosigkeit eine kleine Flamme aus dem Paradies.
<G-vec00092-001-s068><call.bezeichnen><en> "When a word has several different definitions, you cannot limit your understanding of the word to one definition only and call the word ""understood."""
<G-vec00092-001-s068><call.bezeichnen><de> "Wenn ein Wort mehrere verschiedene Definitionen hat, können Sie Ihr Verstehen dieses Wortes nicht nur auf eine Definition beschränken und es als ""verstanden"" bezeichnen."
<G-vec00092-001-s069><call.bezeichnen><en> "Yeah, the genre itself is mainly influenced by the 80s but if you listen to Santa Cruz, you hear right away that it`s not Hard Rock from the 80s; it`s rather something I would call ""Modern Hard Rock""."
<G-vec00092-001-s069><call.bezeichnen><de> "Ja, das Genre an sich ist vornehmlich von den 80ern beeinflusst, aber hier hört man sofort, dass dies kein Hard Rock aus den 80ern ist, sondern etwas, dass ich persönlich als ""Modern Hard Rock"" bezeichnen würde."
<G-vec00092-001-s070><call.bezeichnen><en> But maybe the badly written dialogues are to blame that you seldom can call the acting well done.
<G-vec00092-001-s070><call.bezeichnen><de> Vielleicht sind aber auch die schlecht geschriebenen Dialoge daran schuld, dass man das Schauspiel selten als gelungen bezeichnen kann.
<G-vec00092-001-s071><call.bezeichnen><en> What people call this body is merely the result of a willed concentration organized in a specific way; that's how it spontaneously feels, all the time (not that it's observing itself, but if something forces it to observe itself, that's what it spontaneously feels).
<G-vec00092-001-s071><call.bezeichnen><de> Nur eine willentliche Konzentration in einer besonderen Anordnung ergibt das, was wir als Körper bezeichnen – spontan fühlt er sich immer so (er hält nicht inne, sich zu beobachten, aber wenn etwas ihn veranlaßt, sich zu betrachten, spürt er es spontan so).
<G-vec00092-001-s072><call.bezeichnen><en> "And yet, as Daniel Pauly shows us onstage at Mission Blue, each time the baseline drops, we call it the new ""normal."""
<G-vec00092-001-s072><call.bezeichnen><de> "Daniel Pauly zeigt uns in einem Vortrag während der Mission Blue, dass wir jedes Mal, wenn sich die Zahlen der Normwerte nach unten bewegen, wir sie als das neue ""Normal"" bezeichnen."
<G-vec00092-001-s073><call.bezeichnen><en> It is interesting because the action is very powerful, but I can't call it pleasant.
<G-vec00092-001-s073><call.bezeichnen><de> Es ist interessant, denn die Aktion ist sehr machtvoll, aber ich kann diese Zeit nicht als erfreulich bezeichnen.
<G-vec00092-001-s074><call.bezeichnen><en> "Micha Brumlik notes that, above all it is Levinas to whom we owe an appreciation of what one could call ""eastern European Jewry""."
<G-vec00092-001-s074><call.bezeichnen><de> "Micha Brum-lik stellt dar, dass wir vor allem Levinas eine Würdigung dessen verdanken, was man als ""Ostjudentum"" bezeichnen könnte."
<G-vec00092-001-s075><call.bezeichnen><en> With Springsteen, I would call this title very arbitrary.
<G-vec00092-001-s075><call.bezeichnen><de> Bei Springsteen würde ich diese Titel als sehr beliebig bezeichnen.
<G-vec00272-001-s057><call.bezeichnen><en> The offers of the tantric scene, which I got to know, I would not call the same.
<G-vec00272-001-s057><call.bezeichnen><de> Ich würde die Angebote der Tantra-Szene, die ich kennengelernt habe, nicht als das bezeichnen wollen.
<G-vec00272-001-s058><call.bezeichnen><en> Well, I read it and I would call it revolutionary.
<G-vec00272-001-s058><call.bezeichnen><de> Ich habe es gelesen und würde es als revolutionär bezeichnen.
<G-vec00272-001-s059><call.bezeichnen><en> That is something we would call highly concentrated.
<G-vec00272-001-s059><call.bezeichnen><de> So etwas würden WIR als hochkonzentriert bezeichnen.
<G-vec00272-001-s060><call.bezeichnen><en> What people call practice these days is not really practice.
<G-vec00272-001-s060><call.bezeichnen><de> Was die Leute heutzutage als Praxis bezeichnen, ist keine wirkliche Praxis mehr.
<G-vec00272-001-s061><call.bezeichnen><en> I would call it repressive tolerance, and it's still the case today.
<G-vec00272-001-s061><call.bezeichnen><de> Ich würde das als »repressive Toleranz« bezeichnen, ein Prinzip, das auch heute noch zu beobachten ist.
<G-vec00272-001-s062><call.bezeichnen><en> “Mystical bird” the Romanians call the capercaillie.
<G-vec00272-001-s062><call.bezeichnen><de> Als „mystischen Vogel“ bezeichnen die Rumänen den Auerhahn.
<G-vec00272-001-s063><call.bezeichnen><en> First, the introduction of the common currency led to a huge movement of capital into those countries that we today call PIIGS or periphery countries.
<G-vec00272-001-s063><call.bezeichnen><de> Zunächst löste die Einführung der gemeinsamen Währung eine enorme Kapitalbewegung in die Länder aus, die wir heute als PIIGS oder Peripheriestaaten bezeichnen.
<G-vec00272-001-s064><call.bezeichnen><en> We can only call them evil policemen.
<G-vec00272-001-s064><call.bezeichnen><de> Wir können sie nur als bösartige Polizisten bezeichnen.
<G-vec00272-001-s065><call.bezeichnen><en> """I wish you'd call it what it is,"" she said."
<G-vec00272-001-s065><call.bezeichnen><de> """Ich wünschte, du würdest ihn als das bezeichnen, was er ist"", sagte sie."
<G-vec00272-001-s066><call.bezeichnen><en> "Some people would call that ""progress"" or ""innovation""."
<G-vec00272-001-s066><call.bezeichnen><de> "Manche würden das jetzt als ""Fortschritt"" oder auf neudeutsch ""Innovation"" bezeichnen."
<G-vec00272-001-s067><call.bezeichnen><en> "A being can also have an incurable illness that is rapidly leading towards the destruction of the organism or body, towards what we call ""death"", and from the point of view of the body the situation is hopeless, but behind this hopelessness there is still burning a tiny flame from Paradise."
<G-vec00272-001-s067><call.bezeichnen><de> Ein Wesen kann auch einer unheilbaren Krankheit ausgesetzt sein, die den Organismus oder Körper unaufhaltsam seinem Untergang, d.h. dem, was wir als „Tod“ bezeichnen, entgegenführt, und die Situation ist damit körperlich gesehen hoffnungslos, aber trotzdem lodert hinter dieser Hoffnungslosigkeit eine kleine Flamme aus dem Paradies.
<G-vec00272-001-s068><call.bezeichnen><en> "When a word has several different definitions, you cannot limit your understanding of the word to one definition only and call the word ""understood."""
<G-vec00272-001-s068><call.bezeichnen><de> "Wenn ein Wort mehrere verschiedene Definitionen hat, können Sie Ihr Verstehen dieses Wortes nicht nur auf eine Definition beschränken und es als ""verstanden"" bezeichnen."
<G-vec00272-001-s069><call.bezeichnen><en> "Yeah, the genre itself is mainly influenced by the 80s but if you listen to Santa Cruz, you hear right away that it`s not Hard Rock from the 80s; it`s rather something I would call ""Modern Hard Rock""."
<G-vec00272-001-s069><call.bezeichnen><de> "Ja, das Genre an sich ist vornehmlich von den 80ern beeinflusst, aber hier hört man sofort, dass dies kein Hard Rock aus den 80ern ist, sondern etwas, dass ich persönlich als ""Modern Hard Rock"" bezeichnen würde."
<G-vec00272-001-s070><call.bezeichnen><en> But maybe the badly written dialogues are to blame that you seldom can call the acting well done.
<G-vec00272-001-s070><call.bezeichnen><de> Vielleicht sind aber auch die schlecht geschriebenen Dialoge daran schuld, dass man das Schauspiel selten als gelungen bezeichnen kann.
<G-vec00272-001-s071><call.bezeichnen><en> What people call this body is merely the result of a willed concentration organized in a specific way; that's how it spontaneously feels, all the time (not that it's observing itself, but if something forces it to observe itself, that's what it spontaneously feels).
<G-vec00272-001-s071><call.bezeichnen><de> Nur eine willentliche Konzentration in einer besonderen Anordnung ergibt das, was wir als Körper bezeichnen – spontan fühlt er sich immer so (er hält nicht inne, sich zu beobachten, aber wenn etwas ihn veranlaßt, sich zu betrachten, spürt er es spontan so).
<G-vec00272-001-s072><call.bezeichnen><en> "And yet, as Daniel Pauly shows us onstage at Mission Blue, each time the baseline drops, we call it the new ""normal."""
<G-vec00272-001-s072><call.bezeichnen><de> "Daniel Pauly zeigt uns in einem Vortrag während der Mission Blue, dass wir jedes Mal, wenn sich die Zahlen der Normwerte nach unten bewegen, wir sie als das neue ""Normal"" bezeichnen."
<G-vec00272-001-s073><call.bezeichnen><en> It is interesting because the action is very powerful, but I can't call it pleasant.
<G-vec00272-001-s073><call.bezeichnen><de> Es ist interessant, denn die Aktion ist sehr machtvoll, aber ich kann diese Zeit nicht als erfreulich bezeichnen.
<G-vec00272-001-s074><call.bezeichnen><en> "Micha Brumlik notes that, above all it is Levinas to whom we owe an appreciation of what one could call ""eastern European Jewry""."
<G-vec00272-001-s074><call.bezeichnen><de> "Micha Brum-lik stellt dar, dass wir vor allem Levinas eine Würdigung dessen verdanken, was man als ""Ostjudentum"" bezeichnen könnte."
<G-vec00272-001-s075><call.bezeichnen><en> With Springsteen, I would call this title very arbitrary.
<G-vec00272-001-s075><call.bezeichnen><de> Bei Springsteen würde ich diese Titel als sehr beliebig bezeichnen.
<G-vec00092-001-s114><call.anrufen><en> Call: Select and confirm the desired telephone number.
<G-vec00092-001-s114><call.anrufen><de> Anrufen: Wählen und bestätigen Sie die gewünschte Telefonnummer.
<G-vec00092-001-s115><call.anrufen><en> Company dedicated to the sale of minutes to call centers, More... companies and also offer call termination equipment sales ip virtuale nuemros recargs s virtual.
<G-vec00092-001-s115><call.anrufen><de> Unternehmen spezialisiert auf den Verkauf von Minuten, Unternehmen anrufen und Mehr... bieten auch die Anrufzustellung Ausrüstung Verkäufe ip virtuale nuemros recargs s virtuell.
<G-vec00092-001-s116><call.anrufen><en> He has extended His wonderful salvation to ALL who call upon His Name and repent, whatever their background: ROMANS 9:6-8 and ROMANS 11:17-27 demonstrate this clearly.
<G-vec00092-001-s116><call.anrufen><de> Er hat Seine wundervolle Errettung ALLEN verheißen, die Seinen Namen anrufen und Buße tun, ganz gleich welcher Herkunft: RÖMER 9:6-8 und RÖMER 11:17-27 machen das sehr deutlich.
<G-vec00092-001-s117><call.anrufen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00092-001-s117><call.anrufen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00092-001-s118><call.anrufen><en> It is very easy and you have nothing to worry about, she will do everything for you Call our agency and make a booking We will give you all the information you need to encounter the best escorts of Amsterdam.
<G-vec00092-001-s118><call.anrufen><de> Es ist sehr einfach, und Sie haben nichts zu befürchten, sie werden alles tun, damit Sie unsere Agentur anrufen und eine Reservierung vorzunehmen Wir Sie alle Informationen erhalten Sie brauchen die besten Begleiter von Amsterdam zu begegnen.
<G-vec00092-001-s119><call.anrufen><en> "If you do not want to wait until the web page loads and a logical question emerges about how to add traffic to ""Tele2"", you should visit the official website of the operator or call the contact center and specify how it can be done."
<G-vec00092-001-s119><call.anrufen><de> Wenn Sie nicht, bis die Download-Webseite warten möchten, und es war eine logische Frage, wie Verkehr zu „Tele2“ hinzufügen möchte, sollten Sie die offizielle Website Betreiber besuchen oder das Contact Center anrufen und klären, wie es getan werden kann.
<G-vec00092-001-s120><call.anrufen><en> When you call 112, you will be connected to an operator who will pass you on to the emergency service you require.
<G-vec00092-001-s120><call.anrufen><de> Wenn Sie die 112 anrufen, werden Sie mit einem Mitarbeiter verbunden, der Sie an den passenden Notdienst weiterleitet.
<G-vec00092-001-s121><call.anrufen><en> If you are so hungry for these moments, like me, then you should not wait any longer but call me directly.
<G-vec00092-001-s121><call.anrufen><de> Wenn du dich auch so sehr nach diesen Momenten sehnst, wie ich, dann solltest du nicht noch länger warten sondern mich direkt anrufen.
<G-vec00092-001-s122><call.anrufen><en> 2 To the church of God which is at Corinth, to those who are sanctified in Christ Jesus, called to be saints, with all who in every place call on the name of Jesus Christ our Lord, both theirs and ours:
<G-vec00092-001-s122><call.anrufen><de> 2 an die Gemeinde Gottes, die in Korinth ist, den Geheiligten in Christus Jesus, den berufenen Heiligen, samt allen, die an jedem Ort den Namen unseres Herrn Jesus Christus anrufen, ihres und unseres [Herrn].
<G-vec00092-001-s123><call.anrufen><en> Calling anywhere outside Kuwait is extremely expensive, regardless of when you call.
<G-vec00092-001-s123><call.anrufen><de> Aufruf irgendwo außerhalb Kuwait ist extrem teuer, unabhängig davon, wann Sie anrufen.
<G-vec00092-001-s124><call.anrufen><en> "To restore hope to Europe, therefore, the Churches must look to her and call upon her to continue to show herself as Mother of Hope and lead the entire European continent through the paths of mercy to a revitalising encounter with ""Jesus Christ, our Hope"" (1 Tim1:1)."
<G-vec00092-001-s124><call.anrufen><de> "Um Europa neue Hoffnung zu geben, müssen die Kirchen auf Maria schauen und sie anrufen, damit sie sich weiterhin als Mutter der Hoffnung zeigt und ganz Europa auf dem Weg des Erbarmens zur erneuernden Begegnung mit ""Jesus Christus, unsere Hoffnung"" (1 Tim 1, 1) führt."
<G-vec00092-001-s125><call.anrufen><en> Cortana can remind you of something when you call or text someone, or when they call or text you.
<G-vec00092-001-s125><call.anrufen><de> Cortana kann Sie an etwas erinnern, wenn Sie jemanden anrufen oder ihm eine SMS senden oder wenn die betreffende Person Sie anruft oder Ihnen eine SMS sendet.
<G-vec00092-001-s126><call.anrufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00092-001-s126><call.anrufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00092-001-s127><call.anrufen><en> If you have additional questions you may also call toll free: 0800 098 8202 (GB), 24 hours a day, 7 days a week.
<G-vec00092-001-s127><call.anrufen><de> Wenn Sie weitere Fragen haben, können Sie auch anrufen 0800 098 8202 (GB), 24 Stunden am Tag, 7 Tage die Woche.
<G-vec00092-001-s128><call.anrufen><en> If you would like to purcase a CD, you are most welcome to email or call me.
<G-vec00092-001-s128><call.anrufen><de> Wenn Sie eine CD bestellen möchten, können Sie mir gerne eine Email schreiben oder mich anrufen.
<G-vec00092-001-s129><call.anrufen><en> This decision came from the awareness that most students and bystanders call the ambulance only when the health condition came critical.
<G-vec00092-001-s129><call.anrufen><de> Diese Entscheidung kam aus dem Bewusstsein, dass die meisten Studenten und Umstehenden den Krankenwagen nur dann anrufen, wenn der Gesundheitszustand kritisch wurde.
<G-vec00092-001-s130><call.anrufen><en> If somebody who regularly comes to the center stops coming, especially if it is someone living alone, call and find out if they are sick, if they need any help.
<G-vec00092-001-s130><call.anrufen><de> Wenn jemand, der regelmäßig das Zentrum besucht, nicht mehr kommt, insbesondere wenn es sich um jemanden handelt, der allein lebt, sollte man anrufen und sich erkundigen, ob er krank ist oder Hilfe braucht.
<G-vec00092-001-s131><call.anrufen><en> Call: Select and confirm a favourite/your home address.
<G-vec00092-001-s131><call.anrufen><de> Anrufen: Wählen und bestätigen Sie einen Favoriten/die Heimatadresse.
<G-vec00092-001-s132><call.anrufen><en> If you are not sure since, if a voucher or coupon is valid, then you can call us or write an email.
<G-vec00092-001-s132><call.anrufen><de> Wenn ihr euch nicht sicher seit, ob ein Gutschein oder Coupon gültig ist, dann könnt ihr uns gerne anrufen oder eine Mail schreiben.
<G-vec00272-001-s114><call.anrufen><en> Call: Select and confirm the desired telephone number.
<G-vec00272-001-s114><call.anrufen><de> Anrufen: Wählen und bestätigen Sie die gewünschte Telefonnummer.
<G-vec00272-001-s115><call.anrufen><en> Company dedicated to the sale of minutes to call centers, More... companies and also offer call termination equipment sales ip virtuale nuemros recargs s virtual.
<G-vec00272-001-s115><call.anrufen><de> Unternehmen spezialisiert auf den Verkauf von Minuten, Unternehmen anrufen und Mehr... bieten auch die Anrufzustellung Ausrüstung Verkäufe ip virtuale nuemros recargs s virtuell.
<G-vec00272-001-s116><call.anrufen><en> He has extended His wonderful salvation to ALL who call upon His Name and repent, whatever their background: ROMANS 9:6-8 and ROMANS 11:17-27 demonstrate this clearly.
<G-vec00272-001-s116><call.anrufen><de> Er hat Seine wundervolle Errettung ALLEN verheißen, die Seinen Namen anrufen und Buße tun, ganz gleich welcher Herkunft: RÖMER 9:6-8 und RÖMER 11:17-27 machen das sehr deutlich.
<G-vec00272-001-s117><call.anrufen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00272-001-s117><call.anrufen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00272-001-s118><call.anrufen><en> It is very easy and you have nothing to worry about, she will do everything for you Call our agency and make a booking We will give you all the information you need to encounter the best escorts of Amsterdam.
<G-vec00272-001-s118><call.anrufen><de> Es ist sehr einfach, und Sie haben nichts zu befürchten, sie werden alles tun, damit Sie unsere Agentur anrufen und eine Reservierung vorzunehmen Wir Sie alle Informationen erhalten Sie brauchen die besten Begleiter von Amsterdam zu begegnen.
<G-vec00272-001-s119><call.anrufen><en> "If you do not want to wait until the web page loads and a logical question emerges about how to add traffic to ""Tele2"", you should visit the official website of the operator or call the contact center and specify how it can be done."
<G-vec00272-001-s119><call.anrufen><de> Wenn Sie nicht, bis die Download-Webseite warten möchten, und es war eine logische Frage, wie Verkehr zu „Tele2“ hinzufügen möchte, sollten Sie die offizielle Website Betreiber besuchen oder das Contact Center anrufen und klären, wie es getan werden kann.
<G-vec00272-001-s120><call.anrufen><en> When you call 112, you will be connected to an operator who will pass you on to the emergency service you require.
<G-vec00272-001-s120><call.anrufen><de> Wenn Sie die 112 anrufen, werden Sie mit einem Mitarbeiter verbunden, der Sie an den passenden Notdienst weiterleitet.
<G-vec00272-001-s121><call.anrufen><en> If you are so hungry for these moments, like me, then you should not wait any longer but call me directly.
<G-vec00272-001-s121><call.anrufen><de> Wenn du dich auch so sehr nach diesen Momenten sehnst, wie ich, dann solltest du nicht noch länger warten sondern mich direkt anrufen.
<G-vec00272-001-s122><call.anrufen><en> 2 To the church of God which is at Corinth, to those who are sanctified in Christ Jesus, called to be saints, with all who in every place call on the name of Jesus Christ our Lord, both theirs and ours:
<G-vec00272-001-s122><call.anrufen><de> 2 an die Gemeinde Gottes, die in Korinth ist, den Geheiligten in Christus Jesus, den berufenen Heiligen, samt allen, die an jedem Ort den Namen unseres Herrn Jesus Christus anrufen, ihres und unseres [Herrn].
<G-vec00272-001-s123><call.anrufen><en> Calling anywhere outside Kuwait is extremely expensive, regardless of when you call.
<G-vec00272-001-s123><call.anrufen><de> Aufruf irgendwo außerhalb Kuwait ist extrem teuer, unabhängig davon, wann Sie anrufen.
<G-vec00272-001-s124><call.anrufen><en> "To restore hope to Europe, therefore, the Churches must look to her and call upon her to continue to show herself as Mother of Hope and lead the entire European continent through the paths of mercy to a revitalising encounter with ""Jesus Christ, our Hope"" (1 Tim1:1)."
<G-vec00272-001-s124><call.anrufen><de> "Um Europa neue Hoffnung zu geben, müssen die Kirchen auf Maria schauen und sie anrufen, damit sie sich weiterhin als Mutter der Hoffnung zeigt und ganz Europa auf dem Weg des Erbarmens zur erneuernden Begegnung mit ""Jesus Christus, unsere Hoffnung"" (1 Tim 1, 1) führt."
<G-vec00272-001-s125><call.anrufen><en> Cortana can remind you of something when you call or text someone, or when they call or text you.
<G-vec00272-001-s125><call.anrufen><de> Cortana kann Sie an etwas erinnern, wenn Sie jemanden anrufen oder ihm eine SMS senden oder wenn die betreffende Person Sie anruft oder Ihnen eine SMS sendet.
<G-vec00272-001-s126><call.anrufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00272-001-s126><call.anrufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00272-001-s127><call.anrufen><en> If you have additional questions you may also call toll free: 0800 098 8202 (GB), 24 hours a day, 7 days a week.
<G-vec00272-001-s127><call.anrufen><de> Wenn Sie weitere Fragen haben, können Sie auch anrufen 0800 098 8202 (GB), 24 Stunden am Tag, 7 Tage die Woche.
<G-vec00272-001-s128><call.anrufen><en> If you would like to purcase a CD, you are most welcome to email or call me.
<G-vec00272-001-s128><call.anrufen><de> Wenn Sie eine CD bestellen möchten, können Sie mir gerne eine Email schreiben oder mich anrufen.
<G-vec00272-001-s129><call.anrufen><en> This decision came from the awareness that most students and bystanders call the ambulance only when the health condition came critical.
<G-vec00272-001-s129><call.anrufen><de> Diese Entscheidung kam aus dem Bewusstsein, dass die meisten Studenten und Umstehenden den Krankenwagen nur dann anrufen, wenn der Gesundheitszustand kritisch wurde.
<G-vec00272-001-s130><call.anrufen><en> If somebody who regularly comes to the center stops coming, especially if it is someone living alone, call and find out if they are sick, if they need any help.
<G-vec00272-001-s130><call.anrufen><de> Wenn jemand, der regelmäßig das Zentrum besucht, nicht mehr kommt, insbesondere wenn es sich um jemanden handelt, der allein lebt, sollte man anrufen und sich erkundigen, ob er krank ist oder Hilfe braucht.
<G-vec00272-001-s131><call.anrufen><en> Call: Select and confirm a favourite/your home address.
<G-vec00272-001-s131><call.anrufen><de> Anrufen: Wählen und bestätigen Sie einen Favoriten/die Heimatadresse.
<G-vec00272-001-s132><call.anrufen><en> If you are not sure since, if a voucher or coupon is valid, then you can call us or write an email.
<G-vec00272-001-s132><call.anrufen><de> Wenn ihr euch nicht sicher seit, ob ein Gutschein oder Coupon gültig ist, dann könnt ihr uns gerne anrufen oder eine Mail schreiben.
<G-vec00092-001-s152><call.anrufen><en> He asked the Uzbeks to call him to snap a session, if they suddenly found a new corpse and decide to bury it.
<G-vec00092-001-s152><call.anrufen><de> Er bat die Usbeken, ihn für eine Aufnahmesession anzurufen, sobald sie wieder eine Leiche finden würden, die bestattet werden musste.
<G-vec00092-001-s153><call.anrufen><en> "In my case, I am sorrowful, because I lost her 1 1/2 month ago, but it not pass one day, in which I not be remember in her about the memory key ""Grandparents"" of the phone and the need to call her for hear her voice."
<G-vec00092-001-s153><call.anrufen><de> "In meinem Fall, bin ich sehr traurig, weil ich sie vor 1 1/2 Monaten verloren habe, aber nicht ein Tag vergeht, an dem ich nicht durch die Abspeicherungstaste ""Grosseltern"" am Telefon an sie erinnert werde und das Bedürfnis verspüre, sie anzurufen, um ihre Stimme zu hören."
<G-vec00092-001-s154><call.anrufen><en> If you would like to become better acquainted with us, we invite you to take a look at our home page or call us or write to us.
<G-vec00092-001-s154><call.anrufen><de> Wenn Sie uns näher kennen lernen wollen, laden wir Sie ein, einen Blick auf unsere Homepage zu werfen oder uns anzurufen oder zu schreiben.
<G-vec00092-001-s155><call.anrufen><en> The truth is, you have the power to call on angels to light your way.
<G-vec00092-001-s155><call.anrufen><de> Die Wahrheit ist, du hast die Macht, Engel anzurufen, um deinen Weg zu beleuchten.
<G-vec00092-001-s156><call.anrufen><en> But people should be informed that earth is a planet on its own which has no connection with other worlds, and that any connection with other worlds can only be spiritually established.... Hence the human being is, in fact, able to make contact with inhabitants of advanced worlds, with the kingdom of light, by way of good and appealing thoughts for help at times of spiritual hardship.... which will then be given to him spiritually.... but that it is not advisable for him to call on beings on other stars whose spiritual degree of maturity and their ability to offer spiritual help is unknown to him.
<G-vec00092-001-s156><call.anrufen><de> Die Menschen sollen aber darüber aufgeklärt werden, daß die Erde ein Gestirn für sich ist, das keine Verbindung hat mit anderen Welten, und daß jegliche Bindung mit deren Bewohnern nur geistig herzustellen ist.... daß also sich der Mensch wohl den Bewohnern höherer Welten, des Lichtreiches, verbinden kann durch gute bittende Gedanken um Hilfe in geistiger Not.... die ihm geistig wohl auch geleistet wird.... daß es aber für ihn nicht ratsam ist, Wesen anzurufen von Gestirnen, von denen er nicht weiß, in welchem geistigen Reifegrad diese stehen und ob sie ihm geistige Hilfe gewähren können.
<G-vec00092-001-s157><call.anrufen><en> We tried to call the owner, but the phone number in the reservation confirmation was wrong.
<G-vec00092-001-s157><call.anrufen><de> Wir haben versucht, den Besitzer anzurufen, aber die Telefonnummer in der Reservierungsbestätigung war falsch.
<G-vec00092-001-s158><call.anrufen><en> Should you have further questions, do not hesitate to use the contact form or to call us directly.
<G-vec00092-001-s158><call.anrufen><de> Sollten Sie Fragen haben, zögern Sie nicht, das Kontaktformular zu nutzen oder uns direkt anzurufen.
<G-vec00092-001-s159><call.anrufen><en> Scenario: Joe is trying to call Mary but the operator doesn't know who Mary is.
<G-vec00092-001-s159><call.anrufen><de> Beispielszene: Joe versucht Mary anzurufen, aber der Operator weiß nicht, wer Mary ist.
<G-vec00092-001-s160><call.anrufen><en> I do not want that men must suffer, but I recognize the necessity, to lead them on to the right way through unusual suffering; I recognize their often uncompromising will, which defies me and which I cannot break forcibly to not endanger its perfection; I therefore can only seek to change this will through means, which finally men determine themselves, to call me, to then supply the proof to them through help for their faith that I am from eternity to eternity and stand in indissoluble connection with my creatures.
<G-vec00092-001-s160><call.anrufen><de> Ich will nicht, daß die Menschen leiden müssen, aber Ich erkenne die Notwendigkeit, sie durch ungewöhnliches Leid auf den rechten Weg zu führen, Ich erkenne ihren oft unbeugsamen Willen, der Mir trotzet und den Ich nicht gewaltsam brechen kann, um nicht seine Vollendung zu gefährden; Ich kann also diesen Willen nur zu wandeln suchen durch Mittel, die den Menschen zuletzt selbst bestimmen, Mich anzurufen, um ihnen dann durch Hilfeleistung für ihren Glauben den Beweis zu liefern, daß Ich bin von Ewigkeit zu Ewigkeit und mit Meinen Geschöpfen in unauflösbarer Verbindung stehe.
<G-vec00092-001-s161><call.anrufen><en> After that talk, I never received any further information regarding my passport, so I decided to call the Consulate to get an update on the situation.
<G-vec00092-001-s161><call.anrufen><de> Nach diesem Gespräch erhielt ich keine weiteren Informationen bezüglich der Verlängerung meines Passes und so entschloss ich mich, das Konsulat anzurufen um zu erfahren, wie der Stand der Dinge sei.
<G-vec00092-001-s162><call.anrufen><en> If we need more information before we can complete it, you'll be asked to call us.
<G-vec00092-001-s162><call.anrufen><de> Sofern wir für die weitere Bearbeitung zusätzliche Informationen benötigen, werden Sie gebeten, uns anzurufen.
<G-vec00092-001-s163><call.anrufen><en> 2007-11-13 22:16:19 - A real man Something I find 100% humor in is the fact that men are so quick to call women bitches.
<G-vec00092-001-s163><call.anrufen><de> 2007-11-13 22:16:19 - Ein Wirklicher Mann Etwas, die ich die 100%-Stimmung ist finde innen, die Tatsache, daß Männer so schnell sind, Frauen anzurufen Weibchen.
<G-vec00092-001-s164><call.anrufen><en> In his own supplications to God, he is known to have said, “Oh God, I ask you of you by every name that You have named yourself, or that You have revealed in Your book, or that You have taught any of Your creation, or that You have kept hidden in the unseen knowledge with Yourself.”[2] We are encouraged to call upon God by the name that is specific to the kind of care and help we need.
<G-vec00092-001-s164><call.anrufen><de> Wir wissen, dass er in seinen eigenen Bittgebeten zu Gott sagte: “Oh Gott, ich bitte Dich bei jedem Namen, mit dem du Dich Selbst bezeichnet hast oder den Du in Deinem Buch offenbart hast oder den Du jemandem von Deiner Schöpfung gelehrt hast oder den Du mit dem Wissen von der Verborgenheit für Dich behalten hast.”[2] Wir werden aufgefordert, Gott mit dem Namen anzurufen, der speziell zu der Art der Sorge und Hilfe, um die wir bitten wollen, passt.
<G-vec00092-001-s165><call.anrufen><en> To call the girl or guy who liked to go to a movie, all of a sudden to buy a ticket to somewhere and go (or fly) on the weekend.
<G-vec00092-001-s165><call.anrufen><de> Um das Mädchen oder den Kerl anzurufen, der gern in einen Film ging, plötzlich ein Ticket zu irgendwo zu kaufen und am Wochenende zu fliegen (oder zu fliegen).
<G-vec00092-001-s166><call.anrufen><en> It’s as easy as one, two, three. three. Just call or write us and together we will find the best solution for you.
<G-vec00092-001-s166><call.anrufen><de> Mit uns wird eine Gesellschaft eins zwei drei gegründet, es genügt, uns anzurufen oder uns zu schreiben und wir finden gemeinsam die beste Lösung für Sie.
<G-vec00092-001-s167><call.anrufen><en> I literally ran to the phone to call him.
<G-vec00092-001-s167><call.anrufen><de> Ich rannte buchstäblich zum Telefon, um ihn anzurufen.
<G-vec00092-001-s168><call.anrufen><en> After all, anyone has the right to call 911…
<G-vec00092-001-s168><call.anrufen><de> Schließlich hat jeder das Recht, 911 anzurufen...
<G-vec00092-001-s169><call.anrufen><en> In the event that you are unable to locate the driver of your private transfer or the representative of the shuttle Transport Operator, it is your responsibility to contact us on the 24/7 telephone numbers printed on your Transfer Voucher. If you fail to call these numbers and make alternative travel arrangements, we will be unable to provide the service, the Transport Operator will be relieved of their obligations and a refund will not be due.
<G-vec00092-001-s169><call.anrufen><de> Sollten Sie den Fahrer Ihres privaten Transfers oder den Vertreter des Shuttle-Transportunternehmens bei der Ankunft am Flughafen nicht finden, liegt es in Ihrer Verantwortung, uns über die 24-Stunden-Telefonnummern, die auf dem Transferbeleg aufgeführt sind, zu kontaktieren Versäumen Sie es, diese Nummern anzurufen, und vereinbaren stattdessen alternative Reisearrangements, wird die Leistung nicht erbracht, das Transportunternehmen wird von seinen Verpflichtungen entbunden und eine Erstattung wird nicht fällig.
<G-vec00092-001-s170><call.anrufen><en> When you use your mobile phone in other EU countries – to call, text (send SMS messages) or go online – there's a limit on what your operator can charge you.
<G-vec00092-001-s170><call.anrufen><de> Wenn Sie Ihr Mobiltelefon in anderen EU-Ländern verwenden – um anzurufen, eine SMS zu verschicken oder im Internet zu surfen –, kann Ihnen Ihr Mobilfunkanbieter nicht beliebig viel berechnen.
<G-vec00272-001-s152><call.anrufen><en> He asked the Uzbeks to call him to snap a session, if they suddenly found a new corpse and decide to bury it.
<G-vec00272-001-s152><call.anrufen><de> Er bat die Usbeken, ihn für eine Aufnahmesession anzurufen, sobald sie wieder eine Leiche finden würden, die bestattet werden musste.
<G-vec00272-001-s153><call.anrufen><en> "In my case, I am sorrowful, because I lost her 1 1/2 month ago, but it not pass one day, in which I not be remember in her about the memory key ""Grandparents"" of the phone and the need to call her for hear her voice."
<G-vec00272-001-s153><call.anrufen><de> "In meinem Fall, bin ich sehr traurig, weil ich sie vor 1 1/2 Monaten verloren habe, aber nicht ein Tag vergeht, an dem ich nicht durch die Abspeicherungstaste ""Grosseltern"" am Telefon an sie erinnert werde und das Bedürfnis verspüre, sie anzurufen, um ihre Stimme zu hören."
<G-vec00272-001-s154><call.anrufen><en> If you would like to become better acquainted with us, we invite you to take a look at our home page or call us or write to us.
<G-vec00272-001-s154><call.anrufen><de> Wenn Sie uns näher kennen lernen wollen, laden wir Sie ein, einen Blick auf unsere Homepage zu werfen oder uns anzurufen oder zu schreiben.
<G-vec00272-001-s155><call.anrufen><en> The truth is, you have the power to call on angels to light your way.
<G-vec00272-001-s155><call.anrufen><de> Die Wahrheit ist, du hast die Macht, Engel anzurufen, um deinen Weg zu beleuchten.
<G-vec00272-001-s156><call.anrufen><en> But people should be informed that earth is a planet on its own which has no connection with other worlds, and that any connection with other worlds can only be spiritually established.... Hence the human being is, in fact, able to make contact with inhabitants of advanced worlds, with the kingdom of light, by way of good and appealing thoughts for help at times of spiritual hardship.... which will then be given to him spiritually.... but that it is not advisable for him to call on beings on other stars whose spiritual degree of maturity and their ability to offer spiritual help is unknown to him.
<G-vec00272-001-s156><call.anrufen><de> Die Menschen sollen aber darüber aufgeklärt werden, daß die Erde ein Gestirn für sich ist, das keine Verbindung hat mit anderen Welten, und daß jegliche Bindung mit deren Bewohnern nur geistig herzustellen ist.... daß also sich der Mensch wohl den Bewohnern höherer Welten, des Lichtreiches, verbinden kann durch gute bittende Gedanken um Hilfe in geistiger Not.... die ihm geistig wohl auch geleistet wird.... daß es aber für ihn nicht ratsam ist, Wesen anzurufen von Gestirnen, von denen er nicht weiß, in welchem geistigen Reifegrad diese stehen und ob sie ihm geistige Hilfe gewähren können.
<G-vec00272-001-s157><call.anrufen><en> We tried to call the owner, but the phone number in the reservation confirmation was wrong.
<G-vec00272-001-s157><call.anrufen><de> Wir haben versucht, den Besitzer anzurufen, aber die Telefonnummer in der Reservierungsbestätigung war falsch.
<G-vec00272-001-s158><call.anrufen><en> Should you have further questions, do not hesitate to use the contact form or to call us directly.
<G-vec00272-001-s158><call.anrufen><de> Sollten Sie Fragen haben, zögern Sie nicht, das Kontaktformular zu nutzen oder uns direkt anzurufen.
<G-vec00272-001-s159><call.anrufen><en> Scenario: Joe is trying to call Mary but the operator doesn't know who Mary is.
<G-vec00272-001-s159><call.anrufen><de> Beispielszene: Joe versucht Mary anzurufen, aber der Operator weiß nicht, wer Mary ist.
<G-vec00272-001-s160><call.anrufen><en> I do not want that men must suffer, but I recognize the necessity, to lead them on to the right way through unusual suffering; I recognize their often uncompromising will, which defies me and which I cannot break forcibly to not endanger its perfection; I therefore can only seek to change this will through means, which finally men determine themselves, to call me, to then supply the proof to them through help for their faith that I am from eternity to eternity and stand in indissoluble connection with my creatures.
<G-vec00272-001-s160><call.anrufen><de> Ich will nicht, daß die Menschen leiden müssen, aber Ich erkenne die Notwendigkeit, sie durch ungewöhnliches Leid auf den rechten Weg zu führen, Ich erkenne ihren oft unbeugsamen Willen, der Mir trotzet und den Ich nicht gewaltsam brechen kann, um nicht seine Vollendung zu gefährden; Ich kann also diesen Willen nur zu wandeln suchen durch Mittel, die den Menschen zuletzt selbst bestimmen, Mich anzurufen, um ihnen dann durch Hilfeleistung für ihren Glauben den Beweis zu liefern, daß Ich bin von Ewigkeit zu Ewigkeit und mit Meinen Geschöpfen in unauflösbarer Verbindung stehe.
<G-vec00272-001-s161><call.anrufen><en> After that talk, I never received any further information regarding my passport, so I decided to call the Consulate to get an update on the situation.
<G-vec00272-001-s161><call.anrufen><de> Nach diesem Gespräch erhielt ich keine weiteren Informationen bezüglich der Verlängerung meines Passes und so entschloss ich mich, das Konsulat anzurufen um zu erfahren, wie der Stand der Dinge sei.
<G-vec00272-001-s162><call.anrufen><en> If we need more information before we can complete it, you'll be asked to call us.
<G-vec00272-001-s162><call.anrufen><de> Sofern wir für die weitere Bearbeitung zusätzliche Informationen benötigen, werden Sie gebeten, uns anzurufen.
<G-vec00272-001-s163><call.anrufen><en> 2007-11-13 22:16:19 - A real man Something I find 100% humor in is the fact that men are so quick to call women bitches.
<G-vec00272-001-s163><call.anrufen><de> 2007-11-13 22:16:19 - Ein Wirklicher Mann Etwas, die ich die 100%-Stimmung ist finde innen, die Tatsache, daß Männer so schnell sind, Frauen anzurufen Weibchen.
<G-vec00272-001-s164><call.anrufen><en> In his own supplications to God, he is known to have said, “Oh God, I ask you of you by every name that You have named yourself, or that You have revealed in Your book, or that You have taught any of Your creation, or that You have kept hidden in the unseen knowledge with Yourself.”[2] We are encouraged to call upon God by the name that is specific to the kind of care and help we need.
<G-vec00272-001-s164><call.anrufen><de> Wir wissen, dass er in seinen eigenen Bittgebeten zu Gott sagte: “Oh Gott, ich bitte Dich bei jedem Namen, mit dem du Dich Selbst bezeichnet hast oder den Du in Deinem Buch offenbart hast oder den Du jemandem von Deiner Schöpfung gelehrt hast oder den Du mit dem Wissen von der Verborgenheit für Dich behalten hast.”[2] Wir werden aufgefordert, Gott mit dem Namen anzurufen, der speziell zu der Art der Sorge und Hilfe, um die wir bitten wollen, passt.
<G-vec00272-001-s165><call.anrufen><en> To call the girl or guy who liked to go to a movie, all of a sudden to buy a ticket to somewhere and go (or fly) on the weekend.
<G-vec00272-001-s165><call.anrufen><de> Um das Mädchen oder den Kerl anzurufen, der gern in einen Film ging, plötzlich ein Ticket zu irgendwo zu kaufen und am Wochenende zu fliegen (oder zu fliegen).
<G-vec00272-001-s166><call.anrufen><en> It’s as easy as one, two, three. three. Just call or write us and together we will find the best solution for you.
<G-vec00272-001-s166><call.anrufen><de> Mit uns wird eine Gesellschaft eins zwei drei gegründet, es genügt, uns anzurufen oder uns zu schreiben und wir finden gemeinsam die beste Lösung für Sie.
<G-vec00272-001-s167><call.anrufen><en> I literally ran to the phone to call him.
<G-vec00272-001-s167><call.anrufen><de> Ich rannte buchstäblich zum Telefon, um ihn anzurufen.
<G-vec00272-001-s168><call.anrufen><en> After all, anyone has the right to call 911…
<G-vec00272-001-s168><call.anrufen><de> Schließlich hat jeder das Recht, 911 anzurufen...
<G-vec00272-001-s169><call.anrufen><en> In the event that you are unable to locate the driver of your private transfer or the representative of the shuttle Transport Operator, it is your responsibility to contact us on the 24/7 telephone numbers printed on your Transfer Voucher. If you fail to call these numbers and make alternative travel arrangements, we will be unable to provide the service, the Transport Operator will be relieved of their obligations and a refund will not be due.
<G-vec00272-001-s169><call.anrufen><de> Sollten Sie den Fahrer Ihres privaten Transfers oder den Vertreter des Shuttle-Transportunternehmens bei der Ankunft am Flughafen nicht finden, liegt es in Ihrer Verantwortung, uns über die 24-Stunden-Telefonnummern, die auf dem Transferbeleg aufgeführt sind, zu kontaktieren Versäumen Sie es, diese Nummern anzurufen, und vereinbaren stattdessen alternative Reisearrangements, wird die Leistung nicht erbracht, das Transportunternehmen wird von seinen Verpflichtungen entbunden und eine Erstattung wird nicht fällig.
<G-vec00272-001-s170><call.anrufen><en> When you use your mobile phone in other EU countries – to call, text (send SMS messages) or go online – there's a limit on what your operator can charge you.
<G-vec00272-001-s170><call.anrufen><de> Wenn Sie Ihr Mobiltelefon in anderen EU-Ländern verwenden – um anzurufen, eine SMS zu verschicken oder im Internet zu surfen –, kann Ihnen Ihr Mobilfunkanbieter nicht beliebig viel berechnen.
<G-vec00092-001-s209><call.aufrufen><en> Point.Show End; Compiler links statically call to subroutine point.
<G-vec00092-001-s209><call.aufrufen><de> Point.Show End; Compiler Links aufrufen zu statisch Punkt Subroutine.
<G-vec00092-001-s210><call.aufrufen><en> MyMail is not really what you would call a MailChimp plugin.
<G-vec00092-001-s210><call.aufrufen><de> MyMail ist nicht wirklich das, was man ein MailChimp Plugin aufrufen.
<G-vec00092-001-s211><call.aufrufen><en> Note that the trigger is invoked at the moment you call SAVE RECORD, not when it is created.
<G-vec00092-001-s211><call.aufrufen><de> Beachten Sie, dass der Trigger beim Aufrufen von SAVE RECORD und nicht beim Erstellen aktiv wird.
<G-vec00092-001-s212><call.aufrufen><en> This means that you do not need to call reset() before a foreach loop.
<G-vec00092-001-s212><call.aufrufen><de> Das bedeutet, dass Sie vor einem Durchlauf von foreach reset() nicht aufrufen müssen.
<G-vec00092-001-s213><call.aufrufen><en> Whenever you call up and use our website, we collect the personal data automatically. Your browser then transmits this to our server.
<G-vec00092-001-s213><call.aufrufen><de> Beim Aufrufen und der Nutzung unserer Website erheben wir die personenbezogenen Daten, die dein Browser automatisch an unseren Server übermittelt.
<G-vec00092-001-s214><call.aufrufen><en> Women who believe that having an elegant and sensuous fragrance is necessary to boost the romantic feel and meaning of any occasion should take relief in the fact that they have the option of using a fragrance that they can truly call their own.
<G-vec00092-001-s214><call.aufrufen><de> Frauen, die glauben, dass mit einen eleganten und sinnlichen Duft notwendig ist, die romantische Atmosphäre Erhöhung und Bedeutung der jede Gelegenheit sollte Relief in der Tatsache, dass sie haben die Möglichkeit, mit einen Duft, den sie wirklich ihre eigenen aufrufen können.
<G-vec00092-001-s215><call.aufrufen><en> As the compression is (relatively) slow, it's possible to call a procedure at regular time to follow the packing progress.
<G-vec00092-001-s215><call.aufrufen><de> Da das Komprimieren sehr langsam abläuft, ist damit das regelmäßige Aufrufen einer Prozedur zum Verfolgen des Pack-Prozesses möglich.
<G-vec00092-001-s216><call.aufrufen><en> True to the motto Together we are strong, the race track aims to call on racing professionals and fans as well as visitors of the Nürburgring and the region to be a role model also on public roads.
<G-vec00092-001-s216><call.aufrufen><de> Nach dem Motto Gemeinsam sind wir stark möchte die Rennstrecke Motorsportler, Fans sowie Besucher des Nürburgrings und der Region dazu aufrufen, auch im öffentlichen Straßenverkehr als gutes Beispiel voran zu gehen.
<G-vec00092-001-s217><call.aufrufen><en> This event was to encourage UK people to show concern for the Chinese people in mainland China who have been suffering under a brutal communist dictatorship, and was also to call on the Chinese people to quit the CCP and its related organisations.
<G-vec00092-001-s217><call.aufrufen><de> Die Veranstaltung sollte die Aufmerksamkeit der britischen Bürger auf die Chinesen im Festland China lenken, die unter der brutalen kommunistischen Diktatur leiden und gleichzeitig die Chinesen aufrufen, aus der KP Chinas und ihren angegliederten Organisationen auszutreten.
<G-vec00092-001-s218><call.aufrufen><en> If you now call library commands using [Step into], the program pointer does not jump into the library but could land in your callback routine if this is just now being called from within the library.
<G-vec00092-001-s218><call.aufrufen><de> Wenn Sie jetzt Library-Befehle mit Eintreten aufrufen, springt der Programmzeiger zwar nicht in die Library, kann aber in Ihrer Callback-Routine landen, wenn diese gerade von der Library aus aufgerufen wird.
<G-vec00092-001-s219><call.aufrufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00092-001-s219><call.aufrufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00092-001-s220><call.aufrufen><en> You can also call up the display when the ignition is switched off by pressing the SET button Link.
<G-vec00092-001-s220><call.aufrufen><de> Bei ausgeschalteter Zündung können Sie die Anzeige auch mit der Taste SET aufrufen Link.
<G-vec00092-001-s221><call.aufrufen><en> int MyFunction (char *); This defines a function of type int which can receive a char * for input, the actual function can now be put anywhere else, it is defined, so the compiler won ́t complain if we call it, and upon calling it the compiler will use the actual function instead of the prototype, no matter where it is located.
<G-vec00092-001-s221><call.aufrufen><de> int MyFunction (char *); Dies definiert eine Funktion vom Typ int, die ein char * empfangen kann, die Funktion selbst kann jetzt sonst wo stehen, sie ist definiert, der Compiler meckert nicht wenn wir sie aufrufen und beim Aufruf wird die echte Funktion verwendet, egal wo sie steht.
<G-vec00092-001-s222><call.aufrufen><en> Tip: For a form template, you can call up an overview – analogous to the internal form builder – in which the data fields are listed per form section (Function | Fields menu item).
<G-vec00092-001-s222><call.aufrufen><de> Tipp: Zu einer Formularvorlage können Sie eine Übersicht - analog zum internen Formulargenerator - aufrufen, in der die Datenfelder je Formularabschnitt aufgelistet sind (Menüpunkt Funktion | Felder).
<G-vec00092-001-s223><call.aufrufen><en> In order to prevent your users from being able to call up similar functions, you should leave this option turned on.
<G-vec00092-001-s223><call.aufrufen><de> Damit Benutzer auf Ihrem Terminal nicht ähnliche Funktionen aufrufen können, sollten Sie die Option eingeschaltet lassen.
<G-vec00092-001-s224><call.aufrufen><en> In addition to the internal mapping of logical interfaces via 'id_str', wpa_action can call external mapping scripts.
<G-vec00092-001-s224><call.aufrufen><de> Zusätzlich zum internen Mapping von logischen Schnittstellen mittels 'id_str', kann wpa_action externe Mapping-Scripts aufrufen.
<G-vec00092-001-s225><call.aufrufen><en> Should you call up this website or download contents, please note that it is your own responsibility to ensure that you act in compliance with local legislation applicable in that place.
<G-vec00092-001-s225><call.aufrufen><de> Sollten Sie diese Website aufrufen und/oder Inhalte herunterladen, so sind Sie selbst dafür verantwortlich, dass dies mit den in Ihrem Aufenthaltsort geltenden lokalen Gesetzen vereinbar ist.
<G-vec00092-001-s226><call.aufrufen><en> However, sometimes you only need little motivators; maybe a cute saying on a poster, to make you feel like you have to power to call your own shots.
<G-vec00092-001-s226><call.aufrufen><de> Aber brauchen manchmal Sie nur wenig Motivatoren; vielleicht ein hübsch sagen auf einem Plakat zu machen, Sie fühlen, wie Sie an die macht Ihre eigenen Aufnahmen aufrufen.
<G-vec00092-001-s227><call.aufrufen><en> You can call REST services by using any REST client.
<G-vec00092-001-s227><call.aufrufen><de> Sie können REST-Dienste über einen beliebigen REST-Client aufrufen.
<G-vec00272-001-s209><call.aufrufen><en> Point.Show End; Compiler links statically call to subroutine point.
<G-vec00272-001-s209><call.aufrufen><de> Point.Show End; Compiler Links aufrufen zu statisch Punkt Subroutine.
<G-vec00272-001-s210><call.aufrufen><en> MyMail is not really what you would call a MailChimp plugin.
<G-vec00272-001-s210><call.aufrufen><de> MyMail ist nicht wirklich das, was man ein MailChimp Plugin aufrufen.
<G-vec00272-001-s211><call.aufrufen><en> Note that the trigger is invoked at the moment you call SAVE RECORD, not when it is created.
<G-vec00272-001-s211><call.aufrufen><de> Beachten Sie, dass der Trigger beim Aufrufen von SAVE RECORD und nicht beim Erstellen aktiv wird.
<G-vec00272-001-s212><call.aufrufen><en> This means that you do not need to call reset() before a foreach loop.
<G-vec00272-001-s212><call.aufrufen><de> Das bedeutet, dass Sie vor einem Durchlauf von foreach reset() nicht aufrufen müssen.
<G-vec00272-001-s213><call.aufrufen><en> Whenever you call up and use our website, we collect the personal data automatically. Your browser then transmits this to our server.
<G-vec00272-001-s213><call.aufrufen><de> Beim Aufrufen und der Nutzung unserer Website erheben wir die personenbezogenen Daten, die dein Browser automatisch an unseren Server übermittelt.
<G-vec00272-001-s214><call.aufrufen><en> Women who believe that having an elegant and sensuous fragrance is necessary to boost the romantic feel and meaning of any occasion should take relief in the fact that they have the option of using a fragrance that they can truly call their own.
<G-vec00272-001-s214><call.aufrufen><de> Frauen, die glauben, dass mit einen eleganten und sinnlichen Duft notwendig ist, die romantische Atmosphäre Erhöhung und Bedeutung der jede Gelegenheit sollte Relief in der Tatsache, dass sie haben die Möglichkeit, mit einen Duft, den sie wirklich ihre eigenen aufrufen können.
<G-vec00272-001-s215><call.aufrufen><en> As the compression is (relatively) slow, it's possible to call a procedure at regular time to follow the packing progress.
<G-vec00272-001-s215><call.aufrufen><de> Da das Komprimieren sehr langsam abläuft, ist damit das regelmäßige Aufrufen einer Prozedur zum Verfolgen des Pack-Prozesses möglich.
<G-vec00272-001-s216><call.aufrufen><en> True to the motto Together we are strong, the race track aims to call on racing professionals and fans as well as visitors of the Nürburgring and the region to be a role model also on public roads.
<G-vec00272-001-s216><call.aufrufen><de> Nach dem Motto Gemeinsam sind wir stark möchte die Rennstrecke Motorsportler, Fans sowie Besucher des Nürburgrings und der Region dazu aufrufen, auch im öffentlichen Straßenverkehr als gutes Beispiel voran zu gehen.
<G-vec00272-001-s217><call.aufrufen><en> This event was to encourage UK people to show concern for the Chinese people in mainland China who have been suffering under a brutal communist dictatorship, and was also to call on the Chinese people to quit the CCP and its related organisations.
<G-vec00272-001-s217><call.aufrufen><de> Die Veranstaltung sollte die Aufmerksamkeit der britischen Bürger auf die Chinesen im Festland China lenken, die unter der brutalen kommunistischen Diktatur leiden und gleichzeitig die Chinesen aufrufen, aus der KP Chinas und ihren angegliederten Organisationen auszutreten.
<G-vec00272-001-s218><call.aufrufen><en> If you now call library commands using [Step into], the program pointer does not jump into the library but could land in your callback routine if this is just now being called from within the library.
<G-vec00272-001-s218><call.aufrufen><de> Wenn Sie jetzt Library-Befehle mit Eintreten aufrufen, springt der Programmzeiger zwar nicht in die Library, kann aber in Ihrer Callback-Routine landen, wenn diese gerade von der Library aus aufgerufen wird.
<G-vec00272-001-s219><call.aufrufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00272-001-s219><call.aufrufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00272-001-s220><call.aufrufen><en> You can also call up the display when the ignition is switched off by pressing the SET button Link.
<G-vec00272-001-s220><call.aufrufen><de> Bei ausgeschalteter Zündung können Sie die Anzeige auch mit der Taste SET aufrufen Link.
<G-vec00272-001-s221><call.aufrufen><en> int MyFunction (char *); This defines a function of type int which can receive a char * for input, the actual function can now be put anywhere else, it is defined, so the compiler won ́t complain if we call it, and upon calling it the compiler will use the actual function instead of the prototype, no matter where it is located.
<G-vec00272-001-s221><call.aufrufen><de> int MyFunction (char *); Dies definiert eine Funktion vom Typ int, die ein char * empfangen kann, die Funktion selbst kann jetzt sonst wo stehen, sie ist definiert, der Compiler meckert nicht wenn wir sie aufrufen und beim Aufruf wird die echte Funktion verwendet, egal wo sie steht.
<G-vec00272-001-s222><call.aufrufen><en> Tip: For a form template, you can call up an overview – analogous to the internal form builder – in which the data fields are listed per form section (Function | Fields menu item).
<G-vec00272-001-s222><call.aufrufen><de> Tipp: Zu einer Formularvorlage können Sie eine Übersicht - analog zum internen Formulargenerator - aufrufen, in der die Datenfelder je Formularabschnitt aufgelistet sind (Menüpunkt Funktion | Felder).
<G-vec00272-001-s223><call.aufrufen><en> In order to prevent your users from being able to call up similar functions, you should leave this option turned on.
<G-vec00272-001-s223><call.aufrufen><de> Damit Benutzer auf Ihrem Terminal nicht ähnliche Funktionen aufrufen können, sollten Sie die Option eingeschaltet lassen.
<G-vec00272-001-s224><call.aufrufen><en> In addition to the internal mapping of logical interfaces via 'id_str', wpa_action can call external mapping scripts.
<G-vec00272-001-s224><call.aufrufen><de> Zusätzlich zum internen Mapping von logischen Schnittstellen mittels 'id_str', kann wpa_action externe Mapping-Scripts aufrufen.
<G-vec00272-001-s225><call.aufrufen><en> Should you call up this website or download contents, please note that it is your own responsibility to ensure that you act in compliance with local legislation applicable in that place.
<G-vec00272-001-s225><call.aufrufen><de> Sollten Sie diese Website aufrufen und/oder Inhalte herunterladen, so sind Sie selbst dafür verantwortlich, dass dies mit den in Ihrem Aufenthaltsort geltenden lokalen Gesetzen vereinbar ist.
<G-vec00272-001-s226><call.aufrufen><en> However, sometimes you only need little motivators; maybe a cute saying on a poster, to make you feel like you have to power to call your own shots.
<G-vec00272-001-s226><call.aufrufen><de> Aber brauchen manchmal Sie nur wenig Motivatoren; vielleicht ein hübsch sagen auf einem Plakat zu machen, Sie fühlen, wie Sie an die macht Ihre eigenen Aufnahmen aufrufen.
<G-vec00272-001-s227><call.aufrufen><en> You can call REST services by using any REST client.
<G-vec00272-001-s227><call.aufrufen><de> Sie können REST-Dienste über einen beliebigen REST-Client aufrufen.
<G-vec00092-001-s247><call.aufrufen><en> There are several ways to call up the Color dialog once the part has been selected:
<G-vec00092-001-s247><call.aufrufen><de> Es gibt verschiedene Wege, den Farb-Dialog aufzurufen, nachdem das zu färbende Bauteil ausgewählt wurde.
<G-vec00092-001-s248><call.aufrufen><en> The resolution urged the central government to call for the United Nations, international human right organisations and world health organisations to send delegates to China to investigate and publish reports to safeguard basic human rights, and to demand the CCP to immediately stop the brutality.
<G-vec00092-001-s248><call.aufrufen><de> Die Resolution fordert die Zentralregierung dringlich auf, die Vereinten Nationen, die internationalen Menschenrechtsorganisationen und die Weltgesundheitsorganisationen dazu aufzurufen, Delegationen nach China zu schicken, Untersuchungen anzustellen und die Ergebnisse zu veröffentlichen, damit die grundlegenden Menschenrechte gewahrt bleiben und die KPC dazu aufgefordert wird, diese Brutalität sofort zu beenden.
<G-vec00092-001-s249><call.aufrufen><en> To “burn out” fleas with high temperatures, it is rational to call up special teams: they will cope with the task quickly and with guaranteed results (they use powerful heat guns).
<G-vec00092-001-s249><call.aufrufen><de> Um Flöhe mit hohen Temperaturen auszubrennen, ist es sinnvoll, Spezialteams aufzurufen: Sie werden die Aufgabe schnell und mit garantierten Ergebnissen erledigen (sie verwenden leistungsstarke Heißluftgebläse).
<G-vec00092-001-s250><call.aufrufen><en> It is not enough to call for the fall of this government.
<G-vec00092-001-s250><call.aufrufen><de> Es reicht nicht, nur zum Sturz dieser Regierung aufzurufen.
<G-vec00092-001-s251><call.aufrufen><en> Mobile apps can call these procedures by issuing AJAX requests.
<G-vec00092-001-s251><call.aufrufen><de> Mobile Apps können Ajax-Anforderungen absetzen, um Prozeduren aufzurufen.
<G-vec00092-001-s252><call.aufrufen><en> I know each of you by name and I come from Heaven to call you to conversion.
<G-vec00092-001-s252><call.aufrufen><de> Ich kenne jeden von euch beim Namen und kam vom Himmel um euch zur Bekehrung aufzurufen.
<G-vec00092-001-s253><call.aufrufen><en> The pan value is saved for the #Sound, so it's not needed to call it every time.
<G-vec00092-001-s253><call.aufrufen><de> Der 'Balance'-Wert wird für den #Sound gespeichert - deshalb ist es nicht nötig, diesen jedes Mal aufzurufen.
<G-vec00092-001-s254><call.aufrufen><en> Unlike the CWI, Workers Power rightly notes that “the HDP is not a working class party but a petty bourgeois organisation”—only to call for a vote for them anyway.
<G-vec00092-001-s254><call.aufrufen><de> Im Unterschied zum CWI stellt Workers Power zutreffend fest, dass „die HDP keine Partei der Arbeiterklasse, sondern eine kleinbürgerliche Organisation ist“ – um dann trotzdem zur Stimmabgabe für sie aufzurufen.
<G-vec00092-001-s255><call.aufrufen><en> It is important to call up and just say hi to your fellow franchisees because it will remind them that you are always near by.
<G-vec00092-001-s255><call.aufrufen><de> Aufzurufen ist wichtig, und gerechtes Sagen hallo zu Ihren Mitfranchisenehmern, weil sie sie erinnert, daß Sie immer nahe vorbei sind.
<G-vec00092-001-s256><call.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00092-001-s256><call.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00092-001-s257><call.aufrufen><en> God sent to every nation a prophet, mostly from amongst them, to call them to worship God alone and to shun false gods.
<G-vec00092-001-s257><call.aufrufen><de> Gott hat zu jedem Volk einen Propheten gesandt, meistens einen der ihren, um sie dazu aufzurufen, Gott allein zu dienen und falsche Götter zu meiden.
<G-vec00092-001-s258><call.aufrufen><en> The event was organised as part of a global action to raise awareness of the ongoing human rights crisis of forced disappearances in Mexico, and to call on the Mexican Government to end it.
<G-vec00092-001-s258><call.aufrufen><de> Die Veranstaltung war organisiert als Teil einer weltweiten Aktion, um Aufmerksamkeit auf die fortwährende Menschenrechtskrise des gewaltsamen Verschwindenlassens in Mexiko zu richten und die mexikanische Regierung aufzurufen, diese Krise zu beenden.
<G-vec00092-001-s259><call.aufrufen><en> Dear children, I came from Heaven to call you to a noble mission: announce Jesus to all those who do not yet know Him.
<G-vec00092-001-s259><call.aufrufen><de> Geliebte Kinder, Ich kam vom Himmel um euch zu einer edlen Mission aufzurufen: Jesus allen zu verkuendigen welche Ihn noch nicht kennen.
<G-vec00092-001-s260><call.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00092-001-s260><call.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00092-001-s261><call.aufrufen><en> I come to you this night to call you to make reparation on the Feast of the Holy Innocents and to step inside the Holy Family on the Feast of the Holy Family. When you belong to a family there are family obligations.
<G-vec00092-001-s261><call.aufrufen><de> Ich bin heute nacht zu euch gekommen um euch aufzurufen um Wiedergutmachung am Fest der Heiligen Unschuldigen Kinder zu machen und in die Heilige Familie einzutreten - am Festtag der Heiligen Familie.
<G-vec00092-001-s262><call.aufrufen><en> After practitioners explained to her that these tortures are occurring right now in China against Falun Gong practitioners and our activity here today was to call for the end of persecution against innocent people, the old lady understood the truth and signed our petition to “Support Falun Gong Practitioners in China, Denounce the Persecution Against Falun Gong”.
<G-vec00092-001-s262><call.aufrufen><de> "Nachdem die Praktizierenden ihr erklärt hatten, daß solche Folterungen gerade jetzt in China gegen Falun Gong Praktizierender geschehen, und unsere Aktivität dem Zweck diente, zu einem Ende der Verfolgung gegen unschuldige Menschen aufzurufen, verstand die alte Frau und unterschrieb unsere Petition zur ""Unterstützen Sie Falun Gong Praktizierender in China, verurteilen Sie die Verfolgung gegen Falun Gong""."
<G-vec00092-001-s263><call.aufrufen><en> To call this plugin: in Adobe Photoshop select the menu item File -> Automate -> AKVIS Magnifier;
<G-vec00092-001-s263><call.aufrufen><de> Um die Plugin-Version aufzurufen, wählen Sie den Befehl Datei -> Automatisieren -> AKVIS Magnifier in Photoshop.
<G-vec00092-001-s264><call.aufrufen><en> But the trade union bureaucracy continues to act as a brake, as we can see from their slowness to call a general strike.
<G-vec00092-001-s264><call.aufrufen><de> Aber die Gewerkschaftsbürokratie wirkt weiterhin als Bremser, deutlich sichtbar an ihrem Zögern, zum Generalstreik aufzurufen.
<G-vec00092-001-s265><call.aufrufen><en> Since the beginning of 2013, emergency rescue personnel can now use an online license plate look-up service to quickly call up the pertinent rescue data sheet for a vehicle that has been involved in an accident and to thus take into account the specific vehicle-related information in their rescue work.
<G-vec00092-001-s265><call.aufrufen><de> Dabei wird den Rettungskräften über eine seit Anfang 2013 verfügbare Online-Kennzeichenabfrage die Möglichkeit geboten, sehr schnell das jeweils zutreffende Rettungsdatenblatt eines verunfallten Fahrzeuges online aufzurufen und die speziellen fahrzeugbezogenen Angaben bei der Rettungsarbeit zu berücksichtigen.
<G-vec00272-001-s247><call.aufrufen><en> There are several ways to call up the Color dialog once the part has been selected:
<G-vec00272-001-s247><call.aufrufen><de> Es gibt verschiedene Wege, den Farb-Dialog aufzurufen, nachdem das zu färbende Bauteil ausgewählt wurde.
<G-vec00272-001-s248><call.aufrufen><en> The resolution urged the central government to call for the United Nations, international human right organisations and world health organisations to send delegates to China to investigate and publish reports to safeguard basic human rights, and to demand the CCP to immediately stop the brutality.
<G-vec00272-001-s248><call.aufrufen><de> Die Resolution fordert die Zentralregierung dringlich auf, die Vereinten Nationen, die internationalen Menschenrechtsorganisationen und die Weltgesundheitsorganisationen dazu aufzurufen, Delegationen nach China zu schicken, Untersuchungen anzustellen und die Ergebnisse zu veröffentlichen, damit die grundlegenden Menschenrechte gewahrt bleiben und die KPC dazu aufgefordert wird, diese Brutalität sofort zu beenden.
<G-vec00272-001-s249><call.aufrufen><en> To “burn out” fleas with high temperatures, it is rational to call up special teams: they will cope with the task quickly and with guaranteed results (they use powerful heat guns).
<G-vec00272-001-s249><call.aufrufen><de> Um Flöhe mit hohen Temperaturen auszubrennen, ist es sinnvoll, Spezialteams aufzurufen: Sie werden die Aufgabe schnell und mit garantierten Ergebnissen erledigen (sie verwenden leistungsstarke Heißluftgebläse).
<G-vec00272-001-s250><call.aufrufen><en> It is not enough to call for the fall of this government.
<G-vec00272-001-s250><call.aufrufen><de> Es reicht nicht, nur zum Sturz dieser Regierung aufzurufen.
<G-vec00272-001-s251><call.aufrufen><en> Mobile apps can call these procedures by issuing AJAX requests.
<G-vec00272-001-s251><call.aufrufen><de> Mobile Apps können Ajax-Anforderungen absetzen, um Prozeduren aufzurufen.
<G-vec00272-001-s252><call.aufrufen><en> I know each of you by name and I come from Heaven to call you to conversion.
<G-vec00272-001-s252><call.aufrufen><de> Ich kenne jeden von euch beim Namen und kam vom Himmel um euch zur Bekehrung aufzurufen.
<G-vec00272-001-s253><call.aufrufen><en> The pan value is saved for the #Sound, so it's not needed to call it every time.
<G-vec00272-001-s253><call.aufrufen><de> Der 'Balance'-Wert wird für den #Sound gespeichert - deshalb ist es nicht nötig, diesen jedes Mal aufzurufen.
<G-vec00272-001-s254><call.aufrufen><en> Unlike the CWI, Workers Power rightly notes that “the HDP is not a working class party but a petty bourgeois organisation”—only to call for a vote for them anyway.
<G-vec00272-001-s254><call.aufrufen><de> Im Unterschied zum CWI stellt Workers Power zutreffend fest, dass „die HDP keine Partei der Arbeiterklasse, sondern eine kleinbürgerliche Organisation ist“ – um dann trotzdem zur Stimmabgabe für sie aufzurufen.
<G-vec00272-001-s255><call.aufrufen><en> It is important to call up and just say hi to your fellow franchisees because it will remind them that you are always near by.
<G-vec00272-001-s255><call.aufrufen><de> Aufzurufen ist wichtig, und gerechtes Sagen hallo zu Ihren Mitfranchisenehmern, weil sie sie erinnert, daß Sie immer nahe vorbei sind.
<G-vec00272-001-s256><call.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00272-001-s256><call.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00272-001-s257><call.aufrufen><en> God sent to every nation a prophet, mostly from amongst them, to call them to worship God alone and to shun false gods.
<G-vec00272-001-s257><call.aufrufen><de> Gott hat zu jedem Volk einen Propheten gesandt, meistens einen der ihren, um sie dazu aufzurufen, Gott allein zu dienen und falsche Götter zu meiden.
<G-vec00272-001-s258><call.aufrufen><en> The event was organised as part of a global action to raise awareness of the ongoing human rights crisis of forced disappearances in Mexico, and to call on the Mexican Government to end it.
<G-vec00272-001-s258><call.aufrufen><de> Die Veranstaltung war organisiert als Teil einer weltweiten Aktion, um Aufmerksamkeit auf die fortwährende Menschenrechtskrise des gewaltsamen Verschwindenlassens in Mexiko zu richten und die mexikanische Regierung aufzurufen, diese Krise zu beenden.
<G-vec00272-001-s259><call.aufrufen><en> Dear children, I came from Heaven to call you to a noble mission: announce Jesus to all those who do not yet know Him.
<G-vec00272-001-s259><call.aufrufen><de> Geliebte Kinder, Ich kam vom Himmel um euch zu einer edlen Mission aufzurufen: Jesus allen zu verkuendigen welche Ihn noch nicht kennen.
<G-vec00272-001-s260><call.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00272-001-s260><call.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00272-001-s261><call.aufrufen><en> I come to you this night to call you to make reparation on the Feast of the Holy Innocents and to step inside the Holy Family on the Feast of the Holy Family. When you belong to a family there are family obligations.
<G-vec00272-001-s261><call.aufrufen><de> Ich bin heute nacht zu euch gekommen um euch aufzurufen um Wiedergutmachung am Fest der Heiligen Unschuldigen Kinder zu machen und in die Heilige Familie einzutreten - am Festtag der Heiligen Familie.
<G-vec00272-001-s262><call.aufrufen><en> After practitioners explained to her that these tortures are occurring right now in China against Falun Gong practitioners and our activity here today was to call for the end of persecution against innocent people, the old lady understood the truth and signed our petition to “Support Falun Gong Practitioners in China, Denounce the Persecution Against Falun Gong”.
<G-vec00272-001-s262><call.aufrufen><de> "Nachdem die Praktizierenden ihr erklärt hatten, daß solche Folterungen gerade jetzt in China gegen Falun Gong Praktizierender geschehen, und unsere Aktivität dem Zweck diente, zu einem Ende der Verfolgung gegen unschuldige Menschen aufzurufen, verstand die alte Frau und unterschrieb unsere Petition zur ""Unterstützen Sie Falun Gong Praktizierender in China, verurteilen Sie die Verfolgung gegen Falun Gong""."
<G-vec00272-001-s263><call.aufrufen><en> To call this plugin: in Adobe Photoshop select the menu item File -> Automate -> AKVIS Magnifier;
<G-vec00272-001-s263><call.aufrufen><de> Um die Plugin-Version aufzurufen, wählen Sie den Befehl Datei -> Automatisieren -> AKVIS Magnifier in Photoshop.
<G-vec00272-001-s264><call.aufrufen><en> But the trade union bureaucracy continues to act as a brake, as we can see from their slowness to call a general strike.
<G-vec00272-001-s264><call.aufrufen><de> Aber die Gewerkschaftsbürokratie wirkt weiterhin als Bremser, deutlich sichtbar an ihrem Zögern, zum Generalstreik aufzurufen.
<G-vec00272-001-s265><call.aufrufen><en> Since the beginning of 2013, emergency rescue personnel can now use an online license plate look-up service to quickly call up the pertinent rescue data sheet for a vehicle that has been involved in an accident and to thus take into account the specific vehicle-related information in their rescue work.
<G-vec00272-001-s265><call.aufrufen><de> Dabei wird den Rettungskräften über eine seit Anfang 2013 verfügbare Online-Kennzeichenabfrage die Möglichkeit geboten, sehr schnell das jeweils zutreffende Rettungsdatenblatt eines verunfallten Fahrzeuges online aufzurufen und die speziellen fahrzeugbezogenen Angaben bei der Rettungsarbeit zu berücksichtigen.
<G-vec00092-001-s304><call.bezeichnen><en> The Catholic church and other bigots continue to call abortion “murder.” In the U.S., doctors who carry out abortions have been murdered.
<G-vec00092-001-s304><call.bezeichnen><de> Die katholische Kirche und andere Eiferer bezeichnen Abtreibung immer noch als „Mord“, in den USA wurden Ärzte ermordet, die Abtreibungen durchführten.
<G-vec00092-001-s305><call.bezeichnen><en> Almost half, 48 percent, said they would call themselves a democratic socialist or socialist, compared to 39 percent who said they identified as neither.
<G-vec00092-001-s305><call.bezeichnen><de> Fast die Hälfte, 48 Prozent, sagten, dass sie sich als demokratische(r) Sozialist(in) oder Sozialist(in) bezeichnen würden, verglichen mit 39 Prozent, die sagten, dass sie sich als beides betrachteten.
<G-vec00092-001-s306><call.bezeichnen><en> Over the past decade and a half, you have been subjected to a number of subtle changes that we generally call Ascension Symptoms.
<G-vec00092-001-s306><call.bezeichnen><de> Während der vergangenen anderthalb Jahrzehnte wart ihr einer Reihe subtiler Veränderungen unterworfen, die wir generell als Aufstiegs-Symptome bezeichnen.
<G-vec00092-001-s307><call.bezeichnen><en> "Attorney McMahon said, ""In our lawsuit we have alleged there are various agents, spies-- whatever you want to call them--who are attached to the embassies and consulates here in America."
<G-vec00092-001-s307><call.bezeichnen><de> "Anwalt McMahon sagte: ""In unserer Anklage behaupten wir, dass es verschiedene Agenten, Spione oder wie man diese Personen auch immer bezeichnen will, gibt, die zu den Botschaften und Konsulaten hier in Amerika in Beziehung stehen."
<G-vec00092-001-s308><call.bezeichnen><en> Because this Power is becoming more and more obvious – this Truth-Power – and naturally human thought, which is childish (it has the same attitude towards supramental thought as what we may call animal thought or sentiment has towards human thought or sentiment), has almost a need for superstition (“superstition” is an ugly word for something that's not ugly: it's an ignorant, ingenuous and very trusting faith), and, well, as soon as you feel the influence of a Power, that faith makes you believe in the miracle, it makes you believe that the Supramental is going to manifest now, that you are going to become supramental, and that...
<G-vec00092-001-s308><call.bezeichnen><de> Denn diese Kraft wird immer offensichtlicher – diese Kraft der Wahrheit –, und natürlich bedarf das menschliche Denken, das von kindlicher Beschaffenheit ist (es hat zum supramentalen Denken die gleiche Beziehung wie es das, was man als animalisches Denken oder Empfinden bezeichnen kann, dem menschlichen Empfinden und Denken gegenüber hegt), beinahe eines Aberglaubens (Aberglaube ist ein häßliches Wort für etwas, das nicht eigentlich häßlich, sondern ein unwissender, naiver und sehr vertrauensvoller Glaube ist), und genau dieser Glaube läßt einen dann an Wunder glauben, sobald man den Einfluß einer Kraft fühlt – er läßt einen denken, daß das Supramental sich bald manifestiert und man supramental wird und...
<G-vec00092-001-s309><call.bezeichnen><en> We call the resulting earnings after cost of capital the business value contribution, or BVC .
<G-vec00092-001-s309><call.bezeichnen><de> Das Ergebnis nach Kapitalkosten bezeichnen wir als Business Value Contribution, kurz BVC.
<G-vec00092-001-s310><call.bezeichnen><en> "The Shia call the male descendants of the Prophet Muhammad ""Imams"" and ascribe to them a quasi-divine status."
<G-vec00092-001-s310><call.bezeichnen><de> Die Schiiten bezeichnen alle Nachkommen des Propheten Muhammad als Imame und schreiben ihnen einen quasi-göttlichen Status zu.
<G-vec00092-001-s311><call.bezeichnen><en> "We don't have to have a name for it; a worm doesn't have a name for water, but it knows that that's water – what we would call water with the word ""water."""
<G-vec00092-001-s311><call.bezeichnen><de> "Wir haben vielleicht keinen Namen dafür; ein Wurm hat keinen Namen für Wasser, aber er weiß, was das ist – etwas, das wir mit dem Wort ""Wasser"" bezeichnen würden."
<G-vec00092-001-s312><call.bezeichnen><en> What they call them is a tactical question, but in the end they will agree to only run a single candidate.
<G-vec00092-001-s312><call.bezeichnen><de> Das ist schon eine taktische Frage, wie sie sie bezeichnen werden, aber am Ende wird es nur einen geben.
<G-vec00092-001-s313><call.bezeichnen><en> It is believed that you can not call their children the names of deceased relatives.
<G-vec00092-001-s313><call.bezeichnen><de> Es wird angenommen, dass Sie ihre Kinder nicht als verstorbene Verwandte bezeichnen können.
<G-vec00092-001-s314><call.bezeichnen><en> When we reach Mayfield Bore we get a bit of a laugh about our efforts before.... there are so many trees here one must almost call it a forest.
<G-vec00092-001-s314><call.bezeichnen><de> Beim erreichen von Mayfield Bore müssen wir ab der Mühe lachen, die wir hatten um vorher genügend Brennholz zu sammeln.... es hat hier so viele Bäume, dass man es beinahe schon als Wald bezeichnen muss.
<G-vec00092-001-s315><call.bezeichnen><en> "Strangely, as soon as there's the slightest slackening in the attitude, for instance, a second of forgetfulness (what I might call ""forgetfulness,"" that is, the former old habit, the old terrestrial habit of being), the body instantly feels about to be dissolved."
<G-vec00092-001-s315><call.bezeichnen><de> Seltsam, beim geringsten Nachlassen in der Haltung, zum Beispiel in einer Sekunde der Vergessenheit (was man als Vergessenheit bezeichnen könnte, d.h. die alte Haltung von früher, die alte irdische Seinsgewohnheit), spürt der Körper sofort, daß er sich auflösen wird.
<G-vec00092-001-s316><call.bezeichnen><en> """They are only interested in healthy individuals because they don't cost anything."" If this was actually the case, we would have to call ourselves a ""healthy person insurer""."
<G-vec00092-001-s316><call.bezeichnen><de> «Die interessieren sich doch nur für die Gesunden, weil die nichts kosten.» Wäre dem tatsächlich so, müssten wir uns als «Gesundenkasse» bezeichnen.
<G-vec00092-001-s317><call.bezeichnen><en> Here we present the program for the first three-day certification seminar. Following successful examination, participants have the right to call themselves HICHERT Certified Consultants (HCC).
<G-vec00092-001-s317><call.bezeichnen><de> Hier wird das Programm für das dreitägige Zertifizierungsseminar vorgestellt, deren Teilnehmerinnen und Teilnehmer sich nach der erfolgreichen Prüfungsteilnahme als HICHERT® IBCS Certified Consultant (HCC) bezeichnen können.
<G-vec00092-001-s318><call.bezeichnen><en> At this time, when I had considered these ideas and made my plans, I had already written and published various things, but I would not have dared to call myself an novelist or even an artist yet.
<G-vec00092-001-s318><call.bezeichnen><de> Als ich damals diese Gedanken erwog und meine Pläne faßte, hatte ich zwar schon Verschiedenes geschrieben und an die Oeffentlichkeit gegeben, aber es war mir noch nicht eingefallen, mich als Schriftsteller oder gar als Künstler zu bezeichnen.
<G-vec00092-001-s319><call.bezeichnen><en> Products like the Solaris are in what we call the boutique synthesizer market, and so are for a more specialized customer.
<G-vec00092-001-s319><call.bezeichnen><de> Produkte wie der Solaris befinden sich in einem Markt, den wir als Synthesizer-Nischenmarkt bezeichnen, sie sind somit für einen fachkundigeren Musiker gedacht.
<G-vec00092-001-s320><call.bezeichnen><en> "This is what we call the ""psychic being."""
<G-vec00092-001-s320><call.bezeichnen><de> "Das bezeichnen wir dann als das ""psychische Wesen""."
<G-vec00092-001-s321><call.bezeichnen><en> That discovery I made at the age of about fifteen or sixteen, or seventeen. I began to see clearly all the “gifts” (if we can call them that) that came from father, mother, parents, grandparents, education, people who looked after me, that whole mudhole, as it were, into which you fall headfirst.
<G-vec00092-001-s321><call.bezeichnen><de> "Diese Entdeckung machte ich mit fünfzehn oder vielleicht siebzehn; ich begann, diese ""Gaben"" klar zu sehen (wenn man das als Gaben bezeichnen kann), die mir vom Vater, der Mutter, den Großeltern, der Erziehung, den Leuten, die sich um mich kümmerten, übermittelt wurden – kurz, dieses ganze Morastloch, in dem man Hals über Kopf landet."
<G-vec00092-001-s322><call.bezeichnen><en> Now, when you are in that state, the cancer is triggered by those proteins, which they call as 52 and 58.
<G-vec00092-001-s322><call.bezeichnen><de> Wenn ihr euch in einem solchen Zustand befindet, dann wird der Krebs durch diese Proteine ausgelöst, die sie als 52 und 58 bezeichnen.
<G-vec00272-001-s304><call.bezeichnen><en> The Catholic church and other bigots continue to call abortion “murder.” In the U.S., doctors who carry out abortions have been murdered.
<G-vec00272-001-s304><call.bezeichnen><de> Die katholische Kirche und andere Eiferer bezeichnen Abtreibung immer noch als „Mord“, in den USA wurden Ärzte ermordet, die Abtreibungen durchführten.
<G-vec00272-001-s305><call.bezeichnen><en> Almost half, 48 percent, said they would call themselves a democratic socialist or socialist, compared to 39 percent who said they identified as neither.
<G-vec00272-001-s305><call.bezeichnen><de> Fast die Hälfte, 48 Prozent, sagten, dass sie sich als demokratische(r) Sozialist(in) oder Sozialist(in) bezeichnen würden, verglichen mit 39 Prozent, die sagten, dass sie sich als beides betrachteten.
<G-vec00272-001-s306><call.bezeichnen><en> Over the past decade and a half, you have been subjected to a number of subtle changes that we generally call Ascension Symptoms.
<G-vec00272-001-s306><call.bezeichnen><de> Während der vergangenen anderthalb Jahrzehnte wart ihr einer Reihe subtiler Veränderungen unterworfen, die wir generell als Aufstiegs-Symptome bezeichnen.
<G-vec00272-001-s307><call.bezeichnen><en> "Attorney McMahon said, ""In our lawsuit we have alleged there are various agents, spies-- whatever you want to call them--who are attached to the embassies and consulates here in America."
<G-vec00272-001-s307><call.bezeichnen><de> "Anwalt McMahon sagte: ""In unserer Anklage behaupten wir, dass es verschiedene Agenten, Spione oder wie man diese Personen auch immer bezeichnen will, gibt, die zu den Botschaften und Konsulaten hier in Amerika in Beziehung stehen."
<G-vec00272-001-s308><call.bezeichnen><en> Because this Power is becoming more and more obvious – this Truth-Power – and naturally human thought, which is childish (it has the same attitude towards supramental thought as what we may call animal thought or sentiment has towards human thought or sentiment), has almost a need for superstition (“superstition” is an ugly word for something that's not ugly: it's an ignorant, ingenuous and very trusting faith), and, well, as soon as you feel the influence of a Power, that faith makes you believe in the miracle, it makes you believe that the Supramental is going to manifest now, that you are going to become supramental, and that...
<G-vec00272-001-s308><call.bezeichnen><de> Denn diese Kraft wird immer offensichtlicher – diese Kraft der Wahrheit –, und natürlich bedarf das menschliche Denken, das von kindlicher Beschaffenheit ist (es hat zum supramentalen Denken die gleiche Beziehung wie es das, was man als animalisches Denken oder Empfinden bezeichnen kann, dem menschlichen Empfinden und Denken gegenüber hegt), beinahe eines Aberglaubens (Aberglaube ist ein häßliches Wort für etwas, das nicht eigentlich häßlich, sondern ein unwissender, naiver und sehr vertrauensvoller Glaube ist), und genau dieser Glaube läßt einen dann an Wunder glauben, sobald man den Einfluß einer Kraft fühlt – er läßt einen denken, daß das Supramental sich bald manifestiert und man supramental wird und...
<G-vec00272-001-s309><call.bezeichnen><en> We call the resulting earnings after cost of capital the business value contribution, or BVC .
<G-vec00272-001-s309><call.bezeichnen><de> Das Ergebnis nach Kapitalkosten bezeichnen wir als Business Value Contribution, kurz BVC.
<G-vec00272-001-s310><call.bezeichnen><en> "The Shia call the male descendants of the Prophet Muhammad ""Imams"" and ascribe to them a quasi-divine status."
<G-vec00272-001-s310><call.bezeichnen><de> Die Schiiten bezeichnen alle Nachkommen des Propheten Muhammad als Imame und schreiben ihnen einen quasi-göttlichen Status zu.
<G-vec00272-001-s311><call.bezeichnen><en> "We don't have to have a name for it; a worm doesn't have a name for water, but it knows that that's water – what we would call water with the word ""water."""
<G-vec00272-001-s311><call.bezeichnen><de> "Wir haben vielleicht keinen Namen dafür; ein Wurm hat keinen Namen für Wasser, aber er weiß, was das ist – etwas, das wir mit dem Wort ""Wasser"" bezeichnen würden."
<G-vec00272-001-s312><call.bezeichnen><en> What they call them is a tactical question, but in the end they will agree to only run a single candidate.
<G-vec00272-001-s312><call.bezeichnen><de> Das ist schon eine taktische Frage, wie sie sie bezeichnen werden, aber am Ende wird es nur einen geben.
<G-vec00272-001-s313><call.bezeichnen><en> It is believed that you can not call their children the names of deceased relatives.
<G-vec00272-001-s313><call.bezeichnen><de> Es wird angenommen, dass Sie ihre Kinder nicht als verstorbene Verwandte bezeichnen können.
<G-vec00272-001-s314><call.bezeichnen><en> When we reach Mayfield Bore we get a bit of a laugh about our efforts before.... there are so many trees here one must almost call it a forest.
<G-vec00272-001-s314><call.bezeichnen><de> Beim erreichen von Mayfield Bore müssen wir ab der Mühe lachen, die wir hatten um vorher genügend Brennholz zu sammeln.... es hat hier so viele Bäume, dass man es beinahe schon als Wald bezeichnen muss.
<G-vec00272-001-s315><call.bezeichnen><en> "Strangely, as soon as there's the slightest slackening in the attitude, for instance, a second of forgetfulness (what I might call ""forgetfulness,"" that is, the former old habit, the old terrestrial habit of being), the body instantly feels about to be dissolved."
<G-vec00272-001-s315><call.bezeichnen><de> Seltsam, beim geringsten Nachlassen in der Haltung, zum Beispiel in einer Sekunde der Vergessenheit (was man als Vergessenheit bezeichnen könnte, d.h. die alte Haltung von früher, die alte irdische Seinsgewohnheit), spürt der Körper sofort, daß er sich auflösen wird.
<G-vec00272-001-s316><call.bezeichnen><en> """They are only interested in healthy individuals because they don't cost anything."" If this was actually the case, we would have to call ourselves a ""healthy person insurer""."
<G-vec00272-001-s316><call.bezeichnen><de> «Die interessieren sich doch nur für die Gesunden, weil die nichts kosten.» Wäre dem tatsächlich so, müssten wir uns als «Gesundenkasse» bezeichnen.
<G-vec00272-001-s317><call.bezeichnen><en> Here we present the program for the first three-day certification seminar. Following successful examination, participants have the right to call themselves HICHERT Certified Consultants (HCC).
<G-vec00272-001-s317><call.bezeichnen><de> Hier wird das Programm für das dreitägige Zertifizierungsseminar vorgestellt, deren Teilnehmerinnen und Teilnehmer sich nach der erfolgreichen Prüfungsteilnahme als HICHERT® IBCS Certified Consultant (HCC) bezeichnen können.
<G-vec00272-001-s318><call.bezeichnen><en> At this time, when I had considered these ideas and made my plans, I had already written and published various things, but I would not have dared to call myself an novelist or even an artist yet.
<G-vec00272-001-s318><call.bezeichnen><de> Als ich damals diese Gedanken erwog und meine Pläne faßte, hatte ich zwar schon Verschiedenes geschrieben und an die Oeffentlichkeit gegeben, aber es war mir noch nicht eingefallen, mich als Schriftsteller oder gar als Künstler zu bezeichnen.
<G-vec00272-001-s319><call.bezeichnen><en> Products like the Solaris are in what we call the boutique synthesizer market, and so are for a more specialized customer.
<G-vec00272-001-s319><call.bezeichnen><de> Produkte wie der Solaris befinden sich in einem Markt, den wir als Synthesizer-Nischenmarkt bezeichnen, sie sind somit für einen fachkundigeren Musiker gedacht.
<G-vec00272-001-s320><call.bezeichnen><en> "This is what we call the ""psychic being."""
<G-vec00272-001-s320><call.bezeichnen><de> "Das bezeichnen wir dann als das ""psychische Wesen""."
<G-vec00272-001-s321><call.bezeichnen><en> That discovery I made at the age of about fifteen or sixteen, or seventeen. I began to see clearly all the “gifts” (if we can call them that) that came from father, mother, parents, grandparents, education, people who looked after me, that whole mudhole, as it were, into which you fall headfirst.
<G-vec00272-001-s321><call.bezeichnen><de> "Diese Entdeckung machte ich mit fünfzehn oder vielleicht siebzehn; ich begann, diese ""Gaben"" klar zu sehen (wenn man das als Gaben bezeichnen kann), die mir vom Vater, der Mutter, den Großeltern, der Erziehung, den Leuten, die sich um mich kümmerten, übermittelt wurden – kurz, dieses ganze Morastloch, in dem man Hals über Kopf landet."
<G-vec00272-001-s322><call.bezeichnen><en> Now, when you are in that state, the cancer is triggered by those proteins, which they call as 52 and 58.
<G-vec00272-001-s322><call.bezeichnen><de> Wenn ihr euch in einem solchen Zustand befindet, dann wird der Krebs durch diese Proteine ausgelöst, die sie als 52 und 58 bezeichnen.
<G-vec00092-001-s437><call.nennen><en> Because Croatia, the country of a thousand islands – as they like to call it, is a blend of a thousand year-old historical and cultural heritage, unreal natural beauty, top quality gastronomy, different lifestyles, dialects and mentalities.
<G-vec00092-001-s437><call.nennen><de> Weil Kroatien, das Land der tausend Inseln – wie es liebevoll genannt wird, eine Verbindung des tausendjährigen historischen und kulturellen Erbes, der unglaublichen natürlichen Schönheit, einer ausgezeichneten Küche und unterschiedlicher Lebensstile, Dialekte und Mentalitäten darstellt.
<G-vec00092-001-s438><call.nennen><en> History buffs will want to visit ancient Kalidon, ancient Pleuron, the castle of Kyra Rhini, as the locals call it, and the Windmill, a revolutionary monument.
<G-vec00092-001-s438><call.nennen><de> Historisch interessierte Feriengäste werden das antike Kalydon, das antike Pleuron, das Kastell von Kyra Rhini, wie es von den Einheimischen genannt wird, und die Windmühle, ein Revolutions-Denkmal, besuchen wollen.
<G-vec00092-001-s439><call.nennen><en> "This is why we call it ""the large marine aerosol""."
<G-vec00092-001-s439><call.nennen><de> "Darum wird das Meer auch ""das große marine Aerosol"" genannt."
<G-vec00092-001-s440><call.nennen><en> They call software development “industry” and then try to argue that this means it should be subject to patent monopolies.
<G-vec00092-001-s440><call.nennen><de> Softwareentwicklung wird „Industrie“ genannt und dann versucht zu argumentieren, dies würde bedeuten, dass es dadurch Patentmonopolen unterworfen sein sollte.
<G-vec00092-001-s441><call.nennen><en> Children's areas Huldreheimen, or the 'heart' of Sirdal Ski Centre as we like to call it, is one of our two popular children's areas.
<G-vec00092-001-s441><call.nennen><de> Kinderbereiche Hulderheimen, oder auch das «Herz» des Sirdal Skisenter, wie es genannt wird, ist eines der zwei Kinderbereiche.
<G-vec00092-001-s442><call.nennen><en> The ruin the Voss call the Dark Heart lies deep in the twisted Nightmare Lands.
<G-vec00092-001-s442><call.nennen><de> Die Ruine, die von den Voss das Dunkle Herz genannt wird, liegt tief in den seltsamen Albtraumlanden.
<G-vec00092-001-s443><call.nennen><en> Today we call the belief in purgatory ancient superstition, but the truth is that humankind, in this century more than ever before, has had to flee from its effects.
<G-vec00092-001-s443><call.nennen><de> Der Glaube an das Fegefeuer wird heute alter Aberglauben genannt, und doch ist die Wahrheit die, daß die Menschheit in diesem Jahrhundert mehr denn je vor seinen Wirkungen fliehen musste.
<G-vec00092-001-s444><call.nennen><en> "Just opposite, there is Trouville-sur-Mer, a corner of the Côte Fleurie that some call the ""Queen of Beaches"", particularly renowned for its fishing harbour."
<G-vec00092-001-s444><call.nennen><de> "Gegenüber liegt Trouville-sur-Mer, ein Ort an der Blühenden Küste (Côte Fleurie), von einigen auch genannt die ""Königin der Strände""."
<G-vec00092-001-s445><call.nennen><en> They call it Hot Spot. This reduce to visible area reduces the memory size dramatically. So it is a good idea to use it.
<G-vec00092-001-s445><call.nennen><de> Und es erhält dabei die ursprünglichen Koordinaten des Nullunktes, in MMF Hot Spot genannt, sodass der Sprite immer an der gleichen Stelle gezeichnet wird.
<G-vec00092-001-s446><call.nennen><en> "since 1991: The city of Safwan near Kuwait - the ""motorway of death"" and uranium dust: children die of malformations, cancer, leukemia, heart disease - and there are stillbirths Woman speaker: The city of Safwan on the border with Kuwait: Soldiers call this road between Basra and Safwan also as the ""motorway of death "" (26'20'')."
<G-vec00092-001-s446><call.nennen><de> "ab 1991: Die Stadt Safwan nahe Kuwait - die""Autobahn des Todes"" und der Uranstaub: Kinder sterben an Fehlbildungen, Krebs, Leukämie, Herzerkrankungen - und Totgeburten Sprecherin: Die Stadt Safwan an der Grenze zu Kuwait: Die Straße zwischen Basra und Safwan wird von Soldaten auch ""Autobahn des Todes "" genannt (26'20'')."
<G-vec00092-001-s447><call.nennen><en> On Wednesday evening Bruce Springsteen performed in the Olympiastadion Berlin and showed once again with how much passion and stage presence he, the Boss, as his fans like to call him, has been standing on the stages of this world for almost 40 years now.
<G-vec00092-001-s447><call.nennen><de> Bruce Springsteen spielte am Mittwoch Abend im Olympiastadion Berlin und zeigte wieder einmal, mit wieviel Leidenschaft und Bühnenpräsenz der Boss, wie er von seinen Fans genannt wird, seit beinahe 40 Jahren auf den Bühnen dieser Welt steht.
<G-vec00092-001-s448><call.nennen><en> [15] It was on the outskirts of the city, on a slope directly above the harbor access road, which the people living there call “the mountain.”
<G-vec00092-001-s448><call.nennen><de> [15] Sie war am Rande der Stadt, am Abhang direkt über der Zugangsstraße zum Hafen gelegen und wurde von den Bewohnern „the mountain“ genannt.
<G-vec00092-001-s449><call.nennen><en> "Exactly sixty years ago, in 1953, Sherpa Tenzing Norgay and Edmund Hillary were the first to reach the summit of the ""Holy Mother"", as the Tibetans call the eight-thousander."
<G-vec00092-001-s449><call.nennen><de> "Genau vor sechzig Jahren, im Jahr 1953, waren Sherpa Tenzing Norgay und Edmund Hillary die ersten, die den Gipfel der ""Heiligen Mutter"", wie der Achttausender von den Tibetern genannt wird, erreichten."
<G-vec00092-001-s450><call.nennen><en> "Chinese natives believe that ""the monk's fruit"" as they call it, plays a big part in their renowned longevity ."
<G-vec00092-001-s450><call.nennen><de> "Chinesen glauben, dass Sie Ihr hohes Alter diesem ""Mönchsobst"", wie es in China genannt wird, zu verdanken haben."
<G-vec00092-001-s451><call.nennen><en> "While the disciple confronts the obstacles her mind and psyche place in the path, the sheikh does the real work of transformation, softening the heart and preparing the disciple for the awakening of the consciousness of the heart, the divine consciousness that is present in the innermost chamber of the heart, what the Sufis call the ""heart of hearts."""
<G-vec00092-001-s451><call.nennen><de> "Während die Schülerin sich mit den Hindernissen auseinandersetzt, die ihr der Verstand und ihre Psyche in den Weg stellen, leistet der sheikh die wirkliche Arbeit der Transformation, indem er das Herz weich macht und die Schülerin auf das Erwachen des Bewusstseins des Herzens vorbereitet, des göttlichen Bewusstseins, das in der innersten Kammer des Herzens, die von den Sufis ""das Herz der Herzen"" genannt wird, gegenwärtig ist."
<G-vec00092-001-s452><call.nennen><en> "Of course, very conveniently, the band also invented its own genre – ""symphonic extreme metal art"" and when you call something art, it ́s immediately beyond the critique..."
<G-vec00092-001-s452><call.nennen><de> "Klarer- und bequemerweise hat diese Band auch gleich ihr eigenes Genre erfunden – ""symphonic extreme metal art"", und wenn etwas Kunst genannt wird, dann entzieht es sich automatisch jeglicher Kritik..."
<G-vec00092-001-s453><call.nennen><en> Built-in louver insulating glass, also call built in shutter glass, insulated glass blinds, double glass with blinds, is a traditional sunshade product in which the louver is installed in the hollow glass cavity.
<G-vec00092-001-s453><call.nennen><de> Eingebaute Jalousie Isolierglas, auch in Shutterglas, Isolierglas Jalousien, Doppelglas mit Jalousien genannt, ist ein traditionelles Sonnenschutzprodukt, bei dem die Jalousie led in den Hohlglashohlraum eingebaut ist.
<G-vec00092-001-s454><call.nennen><en> "Traditionally, the extra card was placed face down on the table (people still often call it ""doubling down""), and it would only be revealed at the end of the round."
<G-vec00092-001-s454><call.nennen><de> "Traditionsgemäß wurde die zusätzliche Karte verdeckt auf den Spieltisch gelegt (was nach wie vor ""doubling down"" genannt wird) und erst am Ende der Runde aufgedeckt."
<G-vec00092-001-s455><call.nennen><en> "The next day started with a beautiful sunrise in the desert and was followed by a lot of oil fields with ""donkey pumps"", as the locals call the oil pumps."
<G-vec00092-001-s455><call.nennen><de> "Der nächste Tag begann mit einem wunderschönen Sonnenaufgang in der Wüste, gefolgt von vielen Ölfeldern mit ""Eselspumpen"", wie die Ölpumpen dort genannt wurden."
<G-vec00272-001-s437><call.nennen><en> Because Croatia, the country of a thousand islands – as they like to call it, is a blend of a thousand year-old historical and cultural heritage, unreal natural beauty, top quality gastronomy, different lifestyles, dialects and mentalities.
<G-vec00272-001-s437><call.nennen><de> Weil Kroatien, das Land der tausend Inseln – wie es liebevoll genannt wird, eine Verbindung des tausendjährigen historischen und kulturellen Erbes, der unglaublichen natürlichen Schönheit, einer ausgezeichneten Küche und unterschiedlicher Lebensstile, Dialekte und Mentalitäten darstellt.
<G-vec00272-001-s438><call.nennen><en> History buffs will want to visit ancient Kalidon, ancient Pleuron, the castle of Kyra Rhini, as the locals call it, and the Windmill, a revolutionary monument.
<G-vec00272-001-s438><call.nennen><de> Historisch interessierte Feriengäste werden das antike Kalydon, das antike Pleuron, das Kastell von Kyra Rhini, wie es von den Einheimischen genannt wird, und die Windmühle, ein Revolutions-Denkmal, besuchen wollen.
<G-vec00272-001-s439><call.nennen><en> "This is why we call it ""the large marine aerosol""."
<G-vec00272-001-s439><call.nennen><de> "Darum wird das Meer auch ""das große marine Aerosol"" genannt."
<G-vec00272-001-s440><call.nennen><en> They call software development “industry” and then try to argue that this means it should be subject to patent monopolies.
<G-vec00272-001-s440><call.nennen><de> Softwareentwicklung wird „Industrie“ genannt und dann versucht zu argumentieren, dies würde bedeuten, dass es dadurch Patentmonopolen unterworfen sein sollte.
<G-vec00272-001-s441><call.nennen><en> Children's areas Huldreheimen, or the 'heart' of Sirdal Ski Centre as we like to call it, is one of our two popular children's areas.
<G-vec00272-001-s441><call.nennen><de> Kinderbereiche Hulderheimen, oder auch das «Herz» des Sirdal Skisenter, wie es genannt wird, ist eines der zwei Kinderbereiche.
<G-vec00272-001-s442><call.nennen><en> The ruin the Voss call the Dark Heart lies deep in the twisted Nightmare Lands.
<G-vec00272-001-s442><call.nennen><de> Die Ruine, die von den Voss das Dunkle Herz genannt wird, liegt tief in den seltsamen Albtraumlanden.
<G-vec00272-001-s443><call.nennen><en> Today we call the belief in purgatory ancient superstition, but the truth is that humankind, in this century more than ever before, has had to flee from its effects.
<G-vec00272-001-s443><call.nennen><de> Der Glaube an das Fegefeuer wird heute alter Aberglauben genannt, und doch ist die Wahrheit die, daß die Menschheit in diesem Jahrhundert mehr denn je vor seinen Wirkungen fliehen musste.
<G-vec00272-001-s444><call.nennen><en> "Just opposite, there is Trouville-sur-Mer, a corner of the Côte Fleurie that some call the ""Queen of Beaches"", particularly renowned for its fishing harbour."
<G-vec00272-001-s444><call.nennen><de> "Gegenüber liegt Trouville-sur-Mer, ein Ort an der Blühenden Küste (Côte Fleurie), von einigen auch genannt die ""Königin der Strände""."
<G-vec00272-001-s445><call.nennen><en> They call it Hot Spot. This reduce to visible area reduces the memory size dramatically. So it is a good idea to use it.
<G-vec00272-001-s445><call.nennen><de> Und es erhält dabei die ursprünglichen Koordinaten des Nullunktes, in MMF Hot Spot genannt, sodass der Sprite immer an der gleichen Stelle gezeichnet wird.
<G-vec00272-001-s446><call.nennen><en> "since 1991: The city of Safwan near Kuwait - the ""motorway of death"" and uranium dust: children die of malformations, cancer, leukemia, heart disease - and there are stillbirths Woman speaker: The city of Safwan on the border with Kuwait: Soldiers call this road between Basra and Safwan also as the ""motorway of death "" (26'20'')."
<G-vec00272-001-s446><call.nennen><de> "ab 1991: Die Stadt Safwan nahe Kuwait - die""Autobahn des Todes"" und der Uranstaub: Kinder sterben an Fehlbildungen, Krebs, Leukämie, Herzerkrankungen - und Totgeburten Sprecherin: Die Stadt Safwan an der Grenze zu Kuwait: Die Straße zwischen Basra und Safwan wird von Soldaten auch ""Autobahn des Todes "" genannt (26'20'')."
<G-vec00272-001-s447><call.nennen><en> On Wednesday evening Bruce Springsteen performed in the Olympiastadion Berlin and showed once again with how much passion and stage presence he, the Boss, as his fans like to call him, has been standing on the stages of this world for almost 40 years now.
<G-vec00272-001-s447><call.nennen><de> Bruce Springsteen spielte am Mittwoch Abend im Olympiastadion Berlin und zeigte wieder einmal, mit wieviel Leidenschaft und Bühnenpräsenz der Boss, wie er von seinen Fans genannt wird, seit beinahe 40 Jahren auf den Bühnen dieser Welt steht.
<G-vec00272-001-s448><call.nennen><en> [15] It was on the outskirts of the city, on a slope directly above the harbor access road, which the people living there call “the mountain.”
<G-vec00272-001-s448><call.nennen><de> [15] Sie war am Rande der Stadt, am Abhang direkt über der Zugangsstraße zum Hafen gelegen und wurde von den Bewohnern „the mountain“ genannt.
<G-vec00272-001-s449><call.nennen><en> "Exactly sixty years ago, in 1953, Sherpa Tenzing Norgay and Edmund Hillary were the first to reach the summit of the ""Holy Mother"", as the Tibetans call the eight-thousander."
<G-vec00272-001-s449><call.nennen><de> "Genau vor sechzig Jahren, im Jahr 1953, waren Sherpa Tenzing Norgay und Edmund Hillary die ersten, die den Gipfel der ""Heiligen Mutter"", wie der Achttausender von den Tibetern genannt wird, erreichten."
<G-vec00272-001-s450><call.nennen><en> "Chinese natives believe that ""the monk's fruit"" as they call it, plays a big part in their renowned longevity ."
<G-vec00272-001-s450><call.nennen><de> "Chinesen glauben, dass Sie Ihr hohes Alter diesem ""Mönchsobst"", wie es in China genannt wird, zu verdanken haben."
<G-vec00272-001-s451><call.nennen><en> "While the disciple confronts the obstacles her mind and psyche place in the path, the sheikh does the real work of transformation, softening the heart and preparing the disciple for the awakening of the consciousness of the heart, the divine consciousness that is present in the innermost chamber of the heart, what the Sufis call the ""heart of hearts."""
<G-vec00272-001-s451><call.nennen><de> "Während die Schülerin sich mit den Hindernissen auseinandersetzt, die ihr der Verstand und ihre Psyche in den Weg stellen, leistet der sheikh die wirkliche Arbeit der Transformation, indem er das Herz weich macht und die Schülerin auf das Erwachen des Bewusstseins des Herzens vorbereitet, des göttlichen Bewusstseins, das in der innersten Kammer des Herzens, die von den Sufis ""das Herz der Herzen"" genannt wird, gegenwärtig ist."
<G-vec00272-001-s452><call.nennen><en> "Of course, very conveniently, the band also invented its own genre – ""symphonic extreme metal art"" and when you call something art, it ́s immediately beyond the critique..."
<G-vec00272-001-s452><call.nennen><de> "Klarer- und bequemerweise hat diese Band auch gleich ihr eigenes Genre erfunden – ""symphonic extreme metal art"", und wenn etwas Kunst genannt wird, dann entzieht es sich automatisch jeglicher Kritik..."
<G-vec00272-001-s453><call.nennen><en> Built-in louver insulating glass, also call built in shutter glass, insulated glass blinds, double glass with blinds, is a traditional sunshade product in which the louver is installed in the hollow glass cavity.
<G-vec00272-001-s453><call.nennen><de> Eingebaute Jalousie Isolierglas, auch in Shutterglas, Isolierglas Jalousien, Doppelglas mit Jalousien genannt, ist ein traditionelles Sonnenschutzprodukt, bei dem die Jalousie led in den Hohlglashohlraum eingebaut ist.
<G-vec00272-001-s454><call.nennen><en> "Traditionally, the extra card was placed face down on the table (people still often call it ""doubling down""), and it would only be revealed at the end of the round."
<G-vec00272-001-s454><call.nennen><de> "Traditionsgemäß wurde die zusätzliche Karte verdeckt auf den Spieltisch gelegt (was nach wie vor ""doubling down"" genannt wird) und erst am Ende der Runde aufgedeckt."
<G-vec00272-001-s455><call.nennen><en> "The next day started with a beautiful sunrise in the desert and was followed by a lot of oil fields with ""donkey pumps"", as the locals call the oil pumps."
<G-vec00272-001-s455><call.nennen><de> "Der nächste Tag begann mit einem wunderschönen Sonnenaufgang in der Wüste, gefolgt von vielen Ölfeldern mit ""Eselspumpen"", wie die Ölpumpen dort genannt wurden."
<G-vec00092-001-s494><call.nennen><en> I also habitually call it creative packaging.
<G-vec00092-001-s494><call.nennen><de> Ich nenne es auch gewöhnlich kreative Verpackungen.
<G-vec00092-001-s495><call.nennen><en> It felt as if I remained by the place I call the gate for a short moment, taking it all in and processing it.
<G-vec00092-001-s495><call.nennen><de> Es fühlte sich an als wäre ich eine kurze Weile an diesem Ort, den ich das Tor nenne, geblieben um alles aufzunehmen und zu begreifen.
<G-vec00092-001-s496><call.nennen><en> I call them packages because they're more than just new modes.
<G-vec00092-001-s496><call.nennen><de> Ich nenne sie Pakete, weil sie mehr als nur neue Modi sind.
<G-vec00092-001-s497><call.nennen><en> [...] your KTM 1090 ADVENTURE R for offroad and call it adventure biking.
<G-vec00092-001-s497><call.nennen><de> [...] deine KTM 1090 ADVENTURE R fürs Offroad-Fahren vor und nenne das Ganze eine Abenteuer-Tour.
<G-vec00092-001-s498><call.nennen><en> "Let's take a look at my first image – a fun image I call ""Swing Shift."""
<G-vec00092-001-s498><call.nennen><de> "Sehen Sie sich mein erstes Foto an – ein lustiges Foto, dass ich ""Swing Shift"" nenne."
<G-vec00092-001-s499><call.nennen><en> """One is often forced in public to duplicate oneself – as I always call it."
<G-vec00092-001-s499><call.nennen><de> """In der Öffentlichkeit ist man gezwungen, oft sich selbst zu kopieren – wie ich das immer nenne."
<G-vec00092-001-s500><call.nennen><en> Now that's what I call a hottie.
<G-vec00092-001-s500><call.nennen><de> Nun da ist, was ich ein hottie nenne.
<G-vec00092-001-s501><call.nennen><en> """, ""Call the greatest success of your career"" and so on."
<G-vec00092-001-s501><call.nennen><de> """, ""Nenne den größten Erfolg deiner Karriere"" und so weiter."
<G-vec00092-001-s502><call.nennen><en> / “The Loxone home automation system was easy to combine with the Fronius inverter - that‘s what I call Plug & Play!” says Brandstötter.
<G-vec00092-001-s502><call.nennen><de> / „Die Loxone Hausautomatisierung ließ sich unkompliziert mit dem Fronius Wechselrichter verbinden - das nenne ich Plug & Play.“ sagt Brandstötter.
<G-vec00092-001-s503><call.nennen><en> "I like to call them ""postcard landmarks"" because photos of these tributes and buildings are most likely to end up on postcards or in calendars."
<G-vec00092-001-s503><call.nennen><de> "Ich nenne sie ""Postkarten Merkmale"" weil Fotos von diesen Gedenkstätten und Gebäuden oft auf Postkarten und Kalendern zu finden sind."
<G-vec00092-001-s504><call.nennen><en> I call that paradigm shift.
<G-vec00092-001-s504><call.nennen><de> Ich nenne das Paradigmenwechsel.
<G-vec00092-001-s505><call.nennen><en> I call it the rise of the freelance generalist.
<G-vec00092-001-s505><call.nennen><de> Ich nenne das den Aufstieg der Allround-Freiberufler.
<G-vec00092-001-s506><call.nennen><en> I therefore call it the constant part of capital, or, more shortly, constant capital.
<G-vec00092-001-s506><call.nennen><de> Ich nenne ihn daher konstanten Kapitalteil, oder kürzer: konstantes Kapital.
<G-vec00092-001-s507><call.nennen><en> I call it a brand name since in the Middle East there have existed (and still do) two famous American universities – one in Cairo and another in Beirut.
<G-vec00092-001-s507><call.nennen><de> Ich nenne das so, weil es im Nahen/Mittleren Osten zwei berühmte amerikanische Universitäten gab (und noch gibt), eine in Kairo, die andere in Beirut.
<G-vec00092-001-s508><call.nennen><en> Stand in the magnificence of My light, but do not call it your own.
<G-vec00092-001-s508><call.nennen><de> Stehe in der Herrlichkeit Meines Lichts, doch nenne es nicht dein eigenes.
<G-vec00092-001-s509><call.nennen><en> "An intellectual infinity, but in time not so long away, consists in what I call the ""shame of democracy"", the democratic handing over of power to the National Socialists in Germany in 1933."
<G-vec00092-001-s509><call.nennen><de> Eine intellektuelle Unendlichkeit, zeitlich aber gar nicht so weite Strecke ist es bis zu dem, was ich die »Schmach der Demokratie« nenne, die dämonkratische Machtübergabe an die Nationalsozialisten in Deutschland 1933.
<G-vec00092-001-s510><call.nennen><en> "But to be able to say that a point is black or white, I must first know under what conditions a point is called white or black; in order to be able to say ""p"" is true (or false) I must have determined under what conditions I call ""p"" true, and thereby I determine the sense of the proposition."
<G-vec00092-001-s510><call.nennen><de> "Um aber sagen zu können, ein Punkt sei schwarz oder weiß, muss ich vorerst wissen, wann man einen Punkt schwarz und wann man ihn weiß nennt; um sagen zu können, ""p"" ist wahr (oder falsch), muss ich bestimmt haben, unter welchen Umständen ich ""p"" wahr nenne, und damit bestimme ich den Sinn des Satzes."
<G-vec00092-001-s511><call.nennen><en> In each thought you will implant dynamism (electricity); after that broadness; then density (weight), and lastly power of movement, or as I call it, growth.
<G-vec00092-001-s511><call.nennen><de> Ihr werdet in jeden Gedanken Dynamik (Elektrizität) hineinführen, danach werdet ihr diesem Gedanken Breite geben, dann Dichte (Gewicht) und endlich – Bewegungskraft, oder wie ich sie nenne: Wachsen.
<G-vec00092-001-s512><call.nennen><en> "For want of a better name I call them the ""Emmy-Emma"" group (a nickname for them given by my son, Rick)."
<G-vec00092-001-s512><call.nennen><de> "Aus Mangel an einem besseren Namen ich nenne sie die ""Emmy-Emma""-Gruppe (ein Spitzname für sie da von meinem Sohn, Rick)."
<G-vec00272-001-s494><call.nennen><en> I also habitually call it creative packaging.
<G-vec00272-001-s494><call.nennen><de> Ich nenne es auch gewöhnlich kreative Verpackungen.
<G-vec00272-001-s495><call.nennen><en> It felt as if I remained by the place I call the gate for a short moment, taking it all in and processing it.
<G-vec00272-001-s495><call.nennen><de> Es fühlte sich an als wäre ich eine kurze Weile an diesem Ort, den ich das Tor nenne, geblieben um alles aufzunehmen und zu begreifen.
<G-vec00272-001-s496><call.nennen><en> I call them packages because they're more than just new modes.
<G-vec00272-001-s496><call.nennen><de> Ich nenne sie Pakete, weil sie mehr als nur neue Modi sind.
<G-vec00272-001-s497><call.nennen><en> [...] your KTM 1090 ADVENTURE R for offroad and call it adventure biking.
<G-vec00272-001-s497><call.nennen><de> [...] deine KTM 1090 ADVENTURE R fürs Offroad-Fahren vor und nenne das Ganze eine Abenteuer-Tour.
<G-vec00272-001-s498><call.nennen><en> "Let's take a look at my first image – a fun image I call ""Swing Shift."""
<G-vec00272-001-s498><call.nennen><de> "Sehen Sie sich mein erstes Foto an – ein lustiges Foto, dass ich ""Swing Shift"" nenne."
<G-vec00272-001-s499><call.nennen><en> """One is often forced in public to duplicate oneself – as I always call it."
<G-vec00272-001-s499><call.nennen><de> """In der Öffentlichkeit ist man gezwungen, oft sich selbst zu kopieren – wie ich das immer nenne."
<G-vec00272-001-s500><call.nennen><en> Now that's what I call a hottie.
<G-vec00272-001-s500><call.nennen><de> Nun da ist, was ich ein hottie nenne.
<G-vec00272-001-s501><call.nennen><en> """, ""Call the greatest success of your career"" and so on."
<G-vec00272-001-s501><call.nennen><de> """, ""Nenne den größten Erfolg deiner Karriere"" und so weiter."
<G-vec00272-001-s502><call.nennen><en> / “The Loxone home automation system was easy to combine with the Fronius inverter - that‘s what I call Plug & Play!” says Brandstötter.
<G-vec00272-001-s502><call.nennen><de> / „Die Loxone Hausautomatisierung ließ sich unkompliziert mit dem Fronius Wechselrichter verbinden - das nenne ich Plug & Play.“ sagt Brandstötter.
<G-vec00272-001-s503><call.nennen><en> "I like to call them ""postcard landmarks"" because photos of these tributes and buildings are most likely to end up on postcards or in calendars."
<G-vec00272-001-s503><call.nennen><de> "Ich nenne sie ""Postkarten Merkmale"" weil Fotos von diesen Gedenkstätten und Gebäuden oft auf Postkarten und Kalendern zu finden sind."
<G-vec00272-001-s504><call.nennen><en> I call that paradigm shift.
<G-vec00272-001-s504><call.nennen><de> Ich nenne das Paradigmenwechsel.
<G-vec00272-001-s505><call.nennen><en> I call it the rise of the freelance generalist.
<G-vec00272-001-s505><call.nennen><de> Ich nenne das den Aufstieg der Allround-Freiberufler.
<G-vec00272-001-s506><call.nennen><en> I therefore call it the constant part of capital, or, more shortly, constant capital.
<G-vec00272-001-s506><call.nennen><de> Ich nenne ihn daher konstanten Kapitalteil, oder kürzer: konstantes Kapital.
<G-vec00272-001-s507><call.nennen><en> I call it a brand name since in the Middle East there have existed (and still do) two famous American universities – one in Cairo and another in Beirut.
<G-vec00272-001-s507><call.nennen><de> Ich nenne das so, weil es im Nahen/Mittleren Osten zwei berühmte amerikanische Universitäten gab (und noch gibt), eine in Kairo, die andere in Beirut.
<G-vec00272-001-s508><call.nennen><en> Stand in the magnificence of My light, but do not call it your own.
<G-vec00272-001-s508><call.nennen><de> Stehe in der Herrlichkeit Meines Lichts, doch nenne es nicht dein eigenes.
<G-vec00272-001-s509><call.nennen><en> "An intellectual infinity, but in time not so long away, consists in what I call the ""shame of democracy"", the democratic handing over of power to the National Socialists in Germany in 1933."
<G-vec00272-001-s509><call.nennen><de> Eine intellektuelle Unendlichkeit, zeitlich aber gar nicht so weite Strecke ist es bis zu dem, was ich die »Schmach der Demokratie« nenne, die dämonkratische Machtübergabe an die Nationalsozialisten in Deutschland 1933.
<G-vec00272-001-s510><call.nennen><en> "But to be able to say that a point is black or white, I must first know under what conditions a point is called white or black; in order to be able to say ""p"" is true (or false) I must have determined under what conditions I call ""p"" true, and thereby I determine the sense of the proposition."
<G-vec00272-001-s510><call.nennen><de> "Um aber sagen zu können, ein Punkt sei schwarz oder weiß, muss ich vorerst wissen, wann man einen Punkt schwarz und wann man ihn weiß nennt; um sagen zu können, ""p"" ist wahr (oder falsch), muss ich bestimmt haben, unter welchen Umständen ich ""p"" wahr nenne, und damit bestimme ich den Sinn des Satzes."
<G-vec00272-001-s511><call.nennen><en> In each thought you will implant dynamism (electricity); after that broadness; then density (weight), and lastly power of movement, or as I call it, growth.
<G-vec00272-001-s511><call.nennen><de> Ihr werdet in jeden Gedanken Dynamik (Elektrizität) hineinführen, danach werdet ihr diesem Gedanken Breite geben, dann Dichte (Gewicht) und endlich – Bewegungskraft, oder wie ich sie nenne: Wachsen.
<G-vec00272-001-s512><call.nennen><en> "For want of a better name I call them the ""Emmy-Emma"" group (a nickname for them given by my son, Rick)."
<G-vec00272-001-s512><call.nennen><de> "Aus Mangel an einem besseren Namen ich nenne sie die ""Emmy-Emma""-Gruppe (ein Spitzname für sie da von meinem Sohn, Rick)."
<G-vec00092-001-s513><call.nennen><en> "On the other hand, by combining the values celebrated by the maker culture – an openness towards knowledge, collaborative working, need-based, resource-efficient and decentralised production – with the designer's ability to create things that benefit others and not just themselves, while ideally involving the user as an equal participant, we can create a model you might call ""do-it-together""."
<G-vec00092-001-s513><call.nennen><de> "Wenn allerdings die von der Maker-Kultur propagierten Werte wie offener Umgang mit Wissen, gemeinschaftliches Handeln und bedürfnisgerechte, ressourcenschonende und dezentrale Produktion mit der Fähigkeit des Designers gekoppelt werden, nicht nur für sich selbst, sondern für andere zu gestalten – im Idealfall unter gleichberechtigter Teilhabe des Nutzers – entstünde ein Zusammenhang, der sich dann ""Do-it-together"" nennen könnte."
<G-vec00092-001-s514><call.nennen><en> Not in such a way that we call error truth, but in such a way that we accept them as they are, as human beings, and meet their needs.
<G-vec00092-001-s514><call.nennen><de> Nicht in einer Weise, dass wir Falsches wahr nennen, sondern sie als Menschen annehmen wie sie sind und ihren Bedürfnissen begegnen.
<G-vec00092-001-s515><call.nennen><en> "This cultural dimension is what the economist may call ""real capital"" (in contrast to financial capital)."
<G-vec00092-001-s515><call.nennen><de> "Diese kulturelle Dimension ist das, was der Wirtschaftswissenschaftler ""Realkapital"" nennen könnte (im Gegensatz zu Finanzkapital)."
<G-vec00092-001-s516><call.nennen><en> Reactivity is closely related to what researchers call demand effects (Orne 1962; Zizzo 2010) and the Hawthorne effect (Adair 1984; Levitt and List 2011) .
<G-vec00092-001-s516><call.nennen><de> Die Reaktivität ist eng verwandt mit dem, was (Orne 1962; Zizzo 2010) Nachfrageeffekte nennen (Orne 1962; Zizzo 2010) und den Hawthorne-Effekt (Adair 1984; Levitt and List 2011) .
<G-vec00092-001-s517><call.nennen><en> "Let's call the book Maps of Time ""Christian, version 1.0""."
<G-vec00092-001-s517><call.nennen><de> "Nennen wir die Buch Karten der Zeit ""Christian, Version 1.0""."
<G-vec00092-001-s518><call.nennen><en> The most meaningful, if you could call it that, part of the experience was feeling flooded and caressed so fully in utter love and compassion.
<G-vec00092-001-s518><call.nennen><de> Das Bedeutungsvollste, wenn man es so nennen kann, ist der Teil der Erfahrung wo ich mich so voll überflutet und gestreichelt fühlte mit äußerster Liebe und Mitgefühl.
<G-vec00092-001-s519><call.nennen><en> They call themselves Anufo or the people of Anu.
<G-vec00092-001-s519><call.nennen><de> Sie nennen sich Anufo oder die Leute von Anu.
<G-vec00092-001-s520><call.nennen><en> Incidentally as you move up from one sphere to the other in Yoga Nidra, you are encountering what the Sufis call the 'light that sees' rather than 'the light that can (or could) be seen'.
<G-vec00092-001-s520><call.nennen><de> "Wenn Sie sich im Yoga Nidra von einer Sphäre zur nächsten erheben, finden Sie schließlich das, was die Sufis ""das Licht das man sieht"" nennen - und nicht mehr das Licht, das man sehen kann."
<G-vec00092-001-s521><call.nennen><en> "The below 29 Literary critics and critics call a month – in free choice – four new books, they ""möglichst viele Leser..."
<G-vec00092-001-s521><call.nennen><de> "Die unten aufgeführten 29 Literaturkritikerinnen und -kritiker nennen monatlich – in freier Auswahl – vier Buch-Neuerscheinungen, denen sie ""möglichst viele Leser..."
<G-vec00092-001-s522><call.nennen><en> The makers themselves call it Doom Pop and even though it`s definitely not everyone`s cup of tea, I`m at least strangely fascinated by this quite deranged concoction.
<G-vec00092-001-s522><call.nennen><de> Doom Pop nennen das die Macher selbst und obwohl es definitiv nicht jedermanns Sache sein wird, bin doch zumindest ich auf irgendeine Weise von der doch sehr durchgeknallten Mischung extrem fasziniert.
<G-vec00092-001-s523><call.nennen><en> Call it a way to articulate critique of the flow while embodying the flow.
<G-vec00092-001-s523><call.nennen><de> Man könnte das einen Weg nennen, Kritik am Flow zu äußern und ihn zugleich zu verkörpern.
<G-vec00092-001-s524><call.nennen><en> Whatever you call it, it’s there to assist you all the time.
<G-vec00092-001-s524><call.nennen><de> Was auch immer Sie es nennen, es ist da, um zu helfen, die Sie die ganze Zeit.
<G-vec00092-001-s525><call.nennen><en> "And with this new perception I feel, inexpressibly, a concentration of... the truth of what we call Sri Aurobindo gathering around and on and within this body (there is really neither ""within"" nor ""without"")."
<G-vec00092-001-s525><call.nennen><de> "(Schweigen) Mit dieser neuen Wahrnehmung fühle ich auf unaussprechliche Weise, wie sich eine Konzentration der... der Wahrheit von dem, was wir Sri Aurobindo nennen, um und auf und im Körper sammelt (es gibt kein ""darin"" oder ""außerhalb"")."
<G-vec00092-001-s526><call.nennen><en> As soon as a â smile relationshipâ has been established, as many call it, a visit will be announced.
<G-vec00092-001-s526><call.nennen><de> Sobald das „Lächelverhältnis“, wie es viele nennen, hergestellt ist, wird ein Besuch angekündigt.
<G-vec00092-001-s527><call.nennen><en> We can also call it nibbana or the Unconditioned.
<G-vec00092-001-s527><call.nennen><de> Wir können es auch Nibbana nennen, oder das Unbedingte.
<G-vec00092-001-s528><call.nennen><en> """Jazz du monde"" is what the musicians call their craft, and they indeed knead together all the influences that they have encountered in a multicultural metropolis like Paris."
<G-vec00092-001-s528><call.nennen><de> """Jazz du Monde"" nennen die Musiker ihr Metier und verarbeiten alle Einflüsse, die sie in einer multikulturell geprägten Großstadt wie Paris antreffen."
<G-vec00092-001-s529><call.nennen><en> Those who are at first concerned with being happier until they have optimized happiness will find a way to afford the happy life that they call their dream life.
<G-vec00092-001-s529><call.nennen><de> Die, die sich zuerst damit beschäftigen glücklicher zu sein, bis sie das Glücklichsein optimiert haben, werden einen Weg finden, sich das glückliche Leben leisten zu können, das sie ihr Traumleben nennen.
<G-vec00092-001-s530><call.nennen><en> That is what we Bolsheviks call a real offensive.
<G-vec00092-001-s530><call.nennen><de> Das nennen wir Bolschewiki eine wirkliche Offensive.
<G-vec00092-001-s531><call.nennen><en> We call this energy future 24 hours of sun.
<G-vec00092-001-s531><call.nennen><de> Wir nennen diese Energiezukunft 24 Stunden Sonne.
<G-vec00272-001-s513><call.nennen><en> "On the other hand, by combining the values celebrated by the maker culture – an openness towards knowledge, collaborative working, need-based, resource-efficient and decentralised production – with the designer's ability to create things that benefit others and not just themselves, while ideally involving the user as an equal participant, we can create a model you might call ""do-it-together""."
<G-vec00272-001-s513><call.nennen><de> "Wenn allerdings die von der Maker-Kultur propagierten Werte wie offener Umgang mit Wissen, gemeinschaftliches Handeln und bedürfnisgerechte, ressourcenschonende und dezentrale Produktion mit der Fähigkeit des Designers gekoppelt werden, nicht nur für sich selbst, sondern für andere zu gestalten – im Idealfall unter gleichberechtigter Teilhabe des Nutzers – entstünde ein Zusammenhang, der sich dann ""Do-it-together"" nennen könnte."
<G-vec00272-001-s514><call.nennen><en> Not in such a way that we call error truth, but in such a way that we accept them as they are, as human beings, and meet their needs.
<G-vec00272-001-s514><call.nennen><de> Nicht in einer Weise, dass wir Falsches wahr nennen, sondern sie als Menschen annehmen wie sie sind und ihren Bedürfnissen begegnen.
<G-vec00272-001-s515><call.nennen><en> "This cultural dimension is what the economist may call ""real capital"" (in contrast to financial capital)."
<G-vec00272-001-s515><call.nennen><de> "Diese kulturelle Dimension ist das, was der Wirtschaftswissenschaftler ""Realkapital"" nennen könnte (im Gegensatz zu Finanzkapital)."
<G-vec00272-001-s516><call.nennen><en> Reactivity is closely related to what researchers call demand effects (Orne 1962; Zizzo 2010) and the Hawthorne effect (Adair 1984; Levitt and List 2011) .
<G-vec00272-001-s516><call.nennen><de> Die Reaktivität ist eng verwandt mit dem, was (Orne 1962; Zizzo 2010) Nachfrageeffekte nennen (Orne 1962; Zizzo 2010) und den Hawthorne-Effekt (Adair 1984; Levitt and List 2011) .
<G-vec00272-001-s517><call.nennen><en> "Let's call the book Maps of Time ""Christian, version 1.0""."
<G-vec00272-001-s517><call.nennen><de> "Nennen wir die Buch Karten der Zeit ""Christian, Version 1.0""."
<G-vec00272-001-s518><call.nennen><en> The most meaningful, if you could call it that, part of the experience was feeling flooded and caressed so fully in utter love and compassion.
<G-vec00272-001-s518><call.nennen><de> Das Bedeutungsvollste, wenn man es so nennen kann, ist der Teil der Erfahrung wo ich mich so voll überflutet und gestreichelt fühlte mit äußerster Liebe und Mitgefühl.
<G-vec00272-001-s519><call.nennen><en> They call themselves Anufo or the people of Anu.
<G-vec00272-001-s519><call.nennen><de> Sie nennen sich Anufo oder die Leute von Anu.
<G-vec00272-001-s520><call.nennen><en> Incidentally as you move up from one sphere to the other in Yoga Nidra, you are encountering what the Sufis call the 'light that sees' rather than 'the light that can (or could) be seen'.
<G-vec00272-001-s520><call.nennen><de> "Wenn Sie sich im Yoga Nidra von einer Sphäre zur nächsten erheben, finden Sie schließlich das, was die Sufis ""das Licht das man sieht"" nennen - und nicht mehr das Licht, das man sehen kann."
<G-vec00272-001-s521><call.nennen><en> "The below 29 Literary critics and critics call a month – in free choice – four new books, they ""möglichst viele Leser..."
<G-vec00272-001-s521><call.nennen><de> "Die unten aufgeführten 29 Literaturkritikerinnen und -kritiker nennen monatlich – in freier Auswahl – vier Buch-Neuerscheinungen, denen sie ""möglichst viele Leser..."
<G-vec00272-001-s522><call.nennen><en> The makers themselves call it Doom Pop and even though it`s definitely not everyone`s cup of tea, I`m at least strangely fascinated by this quite deranged concoction.
<G-vec00272-001-s522><call.nennen><de> Doom Pop nennen das die Macher selbst und obwohl es definitiv nicht jedermanns Sache sein wird, bin doch zumindest ich auf irgendeine Weise von der doch sehr durchgeknallten Mischung extrem fasziniert.
<G-vec00272-001-s523><call.nennen><en> Call it a way to articulate critique of the flow while embodying the flow.
<G-vec00272-001-s523><call.nennen><de> Man könnte das einen Weg nennen, Kritik am Flow zu äußern und ihn zugleich zu verkörpern.
<G-vec00272-001-s524><call.nennen><en> Whatever you call it, it’s there to assist you all the time.
<G-vec00272-001-s524><call.nennen><de> Was auch immer Sie es nennen, es ist da, um zu helfen, die Sie die ganze Zeit.
<G-vec00272-001-s525><call.nennen><en> "And with this new perception I feel, inexpressibly, a concentration of... the truth of what we call Sri Aurobindo gathering around and on and within this body (there is really neither ""within"" nor ""without"")."
<G-vec00272-001-s525><call.nennen><de> "(Schweigen) Mit dieser neuen Wahrnehmung fühle ich auf unaussprechliche Weise, wie sich eine Konzentration der... der Wahrheit von dem, was wir Sri Aurobindo nennen, um und auf und im Körper sammelt (es gibt kein ""darin"" oder ""außerhalb"")."
<G-vec00272-001-s526><call.nennen><en> As soon as a â smile relationshipâ has been established, as many call it, a visit will be announced.
<G-vec00272-001-s526><call.nennen><de> Sobald das „Lächelverhältnis“, wie es viele nennen, hergestellt ist, wird ein Besuch angekündigt.
<G-vec00272-001-s527><call.nennen><en> We can also call it nibbana or the Unconditioned.
<G-vec00272-001-s527><call.nennen><de> Wir können es auch Nibbana nennen, oder das Unbedingte.
<G-vec00272-001-s528><call.nennen><en> """Jazz du monde"" is what the musicians call their craft, and they indeed knead together all the influences that they have encountered in a multicultural metropolis like Paris."
<G-vec00272-001-s528><call.nennen><de> """Jazz du Monde"" nennen die Musiker ihr Metier und verarbeiten alle Einflüsse, die sie in einer multikulturell geprägten Großstadt wie Paris antreffen."
<G-vec00272-001-s529><call.nennen><en> Those who are at first concerned with being happier until they have optimized happiness will find a way to afford the happy life that they call their dream life.
<G-vec00272-001-s529><call.nennen><de> Die, die sich zuerst damit beschäftigen glücklicher zu sein, bis sie das Glücklichsein optimiert haben, werden einen Weg finden, sich das glückliche Leben leisten zu können, das sie ihr Traumleben nennen.
<G-vec00272-001-s530><call.nennen><en> That is what we Bolsheviks call a real offensive.
<G-vec00272-001-s530><call.nennen><de> Das nennen wir Bolschewiki eine wirkliche Offensive.
<G-vec00272-001-s531><call.nennen><en> We call this energy future 24 hours of sun.
<G-vec00272-001-s531><call.nennen><de> Wir nennen diese Energiezukunft 24 Stunden Sonne.
<G-vec00092-001-s532><call.nennen><en> But for most human beings this experience only emerges through the passage you call death.
<G-vec00092-001-s532><call.nennen><de> Aber die meisten Menschen machen diese Erfahrung nur bei dem Übergang, den ihr Tod nennt.
<G-vec00092-001-s533><call.nennen><en> Some call it as “ruh.” You may call it by any name – is the love, love of God.
<G-vec00092-001-s533><call.nennen><de> Es gibt verschiedene Namen dafür, man nennt sie Paramchaitanya, Chaitanya, manche nennen sie Ruh.
<G-vec00092-001-s534><call.nennen><en> This is what you call a linguistic exchange: the idea is really to exchange your knowledge in English against the knowledge of a Spanish-speaking person in his or her language.
<G-vec00092-001-s534><call.nennen><de> Das nennt man einen sprachlichen Austausch: Die Idee ist wirklich, Ihr Wissen in deutscher Sprache gegen die Sprachkenntnisse einer spanischsprechenden Person auszutauschen.
<G-vec00092-001-s535><call.nennen><en> "Bonus: TransferWise will automatically lock the exchange rate for a specified time frame, from 24 hours for most countries, and 48 hours for several others and 72 hours for BRL (Brazilian Reals) so you're not exposed to exchange rate fluctuations (they call this the ""guaranteed rate"" feature)."
<G-vec00092-001-s535><call.nennen><de> "In vielen Fällen wenn Sie von oder nach GBP (britische Pfund), EUR (Euro) oder USD (US Dollar) Geld senden, setzt TransferWise den Wechselkurs automatisch für einen Zeitraum von 24-48 Stunden fest, so dass Sie keinen Wechselkursschwankungen ausgesetzt sind (man nennt dies die ""fester Wechselkurs""-Funktion"" (""guaranteed rate"" feature)."
<G-vec00092-001-s536><call.nennen><en> Justice as used in your common language today refers to the idea of [protection] of the individual, the even handed treatment of individuals within a given culture or society and an idea that the law will be fairly applied to all those evenly and if your brother infringes upon your rights then (you) have laws to turn to seek what you call justice which is the idea of a larger authority enforcing laws and rules that you have agreed upon.
<G-vec00092-001-s536><call.nennen><de> Gerechtigkeit, wie sie in eurer gewöhnlichen Sprache verwendet wird, bezieht sich auf die Idee des Schutzes des Individuums, die eben gegebene Behandlung von Individuen in einer gegebenen Kultur oder Gesellschaft, und auf eine Idee, dass das Gesetz ziemlich gleichmäßig auf alle jene angewandt wird, und wenn euer Bruder gegen eure Rechte verstößt, dann habt ihr Gesetze es zu wenden, zu suchen, was ihr Gerechtigkeit nennt, was die Idee einer größeren Autorität ist, die Gesetze und Regeln erlässt, mit denen ihr übereingestimmt habt.
<G-vec00092-001-s537><call.nennen><en> There is something interesting in this cellular consciousness: they have a sense of sincerity which is much sharper, and what they call in English exacting, than in the vital and the mind (even the material vital and mind).
<G-vec00092-001-s537><call.nennen><de> Etwas Interessantes zeigt sich im Bewußtsein der Zellen: Sie haben einen Sinn für Aufrichtigkeit, der VIEL exakter ist – was man im Englischen exacting [anspruchsvoll, streng] nennt – als im Vital und im Mental (das trifft sogar für das materielle Vital und Mental zu).
<G-vec00092-001-s538><call.nennen><en> "It was a show that regarded, early on, what we today call ""mediation"" to be an important component of artistic production."
<G-vec00092-001-s538><call.nennen><de> "Das war ja eine Schau, die frühzeitig sehr stark das, was man heute ""Vermittlung"" nennt, als einen wichtigen Bestandteil der künstlerischen Produktion verstanden hat."
<G-vec00092-001-s539><call.nennen><en> You are not dealing with something that you call 'Christianity', or with your own conception of a Christian, which may be all wrong, faulty, or at most inadequate.
<G-vec00092-001-s539><call.nennen><de> Ihr habt es nicht mit etwas zu tun, das sich «Christentum» nennt, oder mit eurer eigenen Vorstellung eines Christen, die völlig falsch, mangelhaft oder zumindest unangemessen sein mag.
<G-vec00092-001-s540><call.nennen><en> "Call me a ""reformist"" if you like, but I don't want such a future any more than the neo-liberal future."
<G-vec00092-001-s540><call.nennen><de> "Nennt mich eine ""Reformistin"", wenn ihr wollt, aber ich möchte solch eine Zukunft ebenso wenig wie die neoliberale Zukunft."
<G-vec00092-001-s541><call.nennen><en> Precisely what you call cleverness, beauty and strength, precisely these are rather obstacles than means to an intimate relationship with Me.
<G-vec00092-001-s541><call.nennen><de> Ja sogar genau das, was ihr Schönheit, Klugheit und Stärke nennt, sind eher die Hindernisse als die Beförderer der innerlichen Beziehung zu Mir.
<G-vec00092-001-s542><call.nennen><en> As you are civilized/conditioned/cultured long before you develop the ability to question and examine these—call them the facts of birth you received when you were born—your emergence as an individual depends upon, in turn, your curiosity and exploration of who and what you feel yourself to be somewhat independent of your given situation.
<G-vec00092-001-s542><call.nennen><de> Wenn ihr zivilisiert/konditioniert/kultiviert seid lange bevor ihr die Fähigkeit entwickelt, sie zu hinterfragen und zu untersuchen – nennt sie die Tatsachen von Geburt, die ihr erhaltet, wenn ihr geboren werdet – euer Auftauchen als Individuum hängt im Gegenzug von eurer Neugier und Erforschung ab, als wer und was ihr euch selbst fühlt, um etwas unabhängig von eurer gegebenen Situation zu sein.
<G-vec00092-001-s543><call.nennen><en> "It is said that Han Yu, a famous literary figure from the Tang dynasty, burst into tears in fear of the frightful path to ""Blue Dragon Ridge"" and wrote for help, creating the landmark we now call ""Han Yu's Cry for Help"" [9]."
<G-vec00092-001-s543><call.nennen><de> Man erzählt, dass Han Yu, ein berühmter Literat der Tang-Dynastie, aus Angst vor dem furchteinflößenden Pfad zum „Blauer Drache-Bergrücken“ in Tränen ausbrach und um Hilfe schrie, wodurch die Landmarke entstand, die sich nun „Han Yus Schrei um Hilfe“ (9) nennt.
<G-vec00092-001-s544><call.nennen><en> “Remember, at one time the distance between the bodies of land on your Earth, which you call continents, was considered great, and much time was required to travel from one to another.
<G-vec00092-001-s544><call.nennen><de> Erinnere Dich, dass einmal die Entfernung auf Eurer Erde zwischen den Erdkörpern, die Ihr Kontinente nennt, als sehr gross galt und man brauchte für die Überquerung viel Zeit.
<G-vec00092-001-s545><call.nennen><en> The Acts of the Apostles call Jesus the leader of the way into life.
<G-vec00092-001-s545><call.nennen><de> Die Apostelgeschichte nennt Jesus den Führer auf dem Weg in das Leben.
<G-vec00092-001-s546><call.nennen><en> "David Sugar, the author of Bayonne, likes to call it the ""Swiss army knife"" of the ""telephony servers,"" because tdM bus support, call ""switching"" and VoIP gateway services are already being worked on."
<G-vec00092-001-s546><call.nennen><de> "David Sugar, der Autor von Bayonne, nennt es gerne das ""Schweizer Taschenmesser"" der ""Telefonie Server"", da auch die Unterstützung des tdM Bus, ""Anrufumschaltung"" und VoIP Gateway-Dienste in Arbeit sind."
<G-vec00092-001-s547><call.nennen><en> Meditation has become a natural, almost daily part of my life- the island of stillness, how you call it, helps me to stay in touch with being myself and find deep rest and new energy.
<G-vec00092-001-s547><call.nennen><de> "Die Meditation ist ein natürlicher, beinahe täglicher Teil meines Lebens geworden - die ""Insel der Stille"", wie Ihr es so treffend nennt, hilft mir, bei mir zu bleiben und Kraft zu tanken."
<G-vec00092-001-s548><call.nennen><en> "He may call Palestinians ""Terrorists"", but he performs surgery on them, ""no matter what they believe""."
<G-vec00092-001-s548><call.nennen><de> Zwar nennt er Palästinenser «Terroristen», aber er operiert sie, «egal, was sie glauben».
<G-vec00092-001-s549><call.nennen><en> Whoever can call a Prinz Hunting Weapon his own expresses with it not only his individuality, but also, in particular, his will to give the hunter’s luck a helping hand.
<G-vec00092-001-s549><call.nennen><de> Wer eine Prinz sein Eigen nennt, drückt damit nicht nur seine Individualität aus, sondern auch und vor allem seinen Willen, dem Jagdglück ein wenig auf die Sprünge zu helfen.
<G-vec00092-001-s550><call.nennen><en> Beside of the helpless story contains the video a lot income statements of bank accounts and similar, full censored, and call it a proof.
<G-vec00092-001-s550><call.nennen><de> Neben der nutzlosen Story enthält das Video eine menge Kontostände von Bankkonto und ähnliches, voll zensiert, und nennt das auch noch einen Beweis.
<G-vec00272-001-s532><call.nennen><en> But for most human beings this experience only emerges through the passage you call death.
<G-vec00272-001-s532><call.nennen><de> Aber die meisten Menschen machen diese Erfahrung nur bei dem Übergang, den ihr Tod nennt.
<G-vec00272-001-s533><call.nennen><en> Some call it as “ruh.” You may call it by any name – is the love, love of God.
<G-vec00272-001-s533><call.nennen><de> Es gibt verschiedene Namen dafür, man nennt sie Paramchaitanya, Chaitanya, manche nennen sie Ruh.
<G-vec00272-001-s534><call.nennen><en> This is what you call a linguistic exchange: the idea is really to exchange your knowledge in English against the knowledge of a Spanish-speaking person in his or her language.
<G-vec00272-001-s534><call.nennen><de> Das nennt man einen sprachlichen Austausch: Die Idee ist wirklich, Ihr Wissen in deutscher Sprache gegen die Sprachkenntnisse einer spanischsprechenden Person auszutauschen.
<G-vec00272-001-s535><call.nennen><en> "Bonus: TransferWise will automatically lock the exchange rate for a specified time frame, from 24 hours for most countries, and 48 hours for several others and 72 hours for BRL (Brazilian Reals) so you're not exposed to exchange rate fluctuations (they call this the ""guaranteed rate"" feature)."
<G-vec00272-001-s535><call.nennen><de> "In vielen Fällen wenn Sie von oder nach GBP (britische Pfund), EUR (Euro) oder USD (US Dollar) Geld senden, setzt TransferWise den Wechselkurs automatisch für einen Zeitraum von 24-48 Stunden fest, so dass Sie keinen Wechselkursschwankungen ausgesetzt sind (man nennt dies die ""fester Wechselkurs""-Funktion"" (""guaranteed rate"" feature)."
<G-vec00272-001-s536><call.nennen><en> Justice as used in your common language today refers to the idea of [protection] of the individual, the even handed treatment of individuals within a given culture or society and an idea that the law will be fairly applied to all those evenly and if your brother infringes upon your rights then (you) have laws to turn to seek what you call justice which is the idea of a larger authority enforcing laws and rules that you have agreed upon.
<G-vec00272-001-s536><call.nennen><de> Gerechtigkeit, wie sie in eurer gewöhnlichen Sprache verwendet wird, bezieht sich auf die Idee des Schutzes des Individuums, die eben gegebene Behandlung von Individuen in einer gegebenen Kultur oder Gesellschaft, und auf eine Idee, dass das Gesetz ziemlich gleichmäßig auf alle jene angewandt wird, und wenn euer Bruder gegen eure Rechte verstößt, dann habt ihr Gesetze es zu wenden, zu suchen, was ihr Gerechtigkeit nennt, was die Idee einer größeren Autorität ist, die Gesetze und Regeln erlässt, mit denen ihr übereingestimmt habt.
<G-vec00272-001-s537><call.nennen><en> There is something interesting in this cellular consciousness: they have a sense of sincerity which is much sharper, and what they call in English exacting, than in the vital and the mind (even the material vital and mind).
<G-vec00272-001-s537><call.nennen><de> Etwas Interessantes zeigt sich im Bewußtsein der Zellen: Sie haben einen Sinn für Aufrichtigkeit, der VIEL exakter ist – was man im Englischen exacting [anspruchsvoll, streng] nennt – als im Vital und im Mental (das trifft sogar für das materielle Vital und Mental zu).
<G-vec00272-001-s538><call.nennen><en> "It was a show that regarded, early on, what we today call ""mediation"" to be an important component of artistic production."
<G-vec00272-001-s538><call.nennen><de> "Das war ja eine Schau, die frühzeitig sehr stark das, was man heute ""Vermittlung"" nennt, als einen wichtigen Bestandteil der künstlerischen Produktion verstanden hat."
<G-vec00272-001-s539><call.nennen><en> You are not dealing with something that you call 'Christianity', or with your own conception of a Christian, which may be all wrong, faulty, or at most inadequate.
<G-vec00272-001-s539><call.nennen><de> Ihr habt es nicht mit etwas zu tun, das sich «Christentum» nennt, oder mit eurer eigenen Vorstellung eines Christen, die völlig falsch, mangelhaft oder zumindest unangemessen sein mag.
<G-vec00272-001-s540><call.nennen><en> "Call me a ""reformist"" if you like, but I don't want such a future any more than the neo-liberal future."
<G-vec00272-001-s540><call.nennen><de> "Nennt mich eine ""Reformistin"", wenn ihr wollt, aber ich möchte solch eine Zukunft ebenso wenig wie die neoliberale Zukunft."
<G-vec00272-001-s541><call.nennen><en> Precisely what you call cleverness, beauty and strength, precisely these are rather obstacles than means to an intimate relationship with Me.
<G-vec00272-001-s541><call.nennen><de> Ja sogar genau das, was ihr Schönheit, Klugheit und Stärke nennt, sind eher die Hindernisse als die Beförderer der innerlichen Beziehung zu Mir.
<G-vec00272-001-s542><call.nennen><en> As you are civilized/conditioned/cultured long before you develop the ability to question and examine these—call them the facts of birth you received when you were born—your emergence as an individual depends upon, in turn, your curiosity and exploration of who and what you feel yourself to be somewhat independent of your given situation.
<G-vec00272-001-s542><call.nennen><de> Wenn ihr zivilisiert/konditioniert/kultiviert seid lange bevor ihr die Fähigkeit entwickelt, sie zu hinterfragen und zu untersuchen – nennt sie die Tatsachen von Geburt, die ihr erhaltet, wenn ihr geboren werdet – euer Auftauchen als Individuum hängt im Gegenzug von eurer Neugier und Erforschung ab, als wer und was ihr euch selbst fühlt, um etwas unabhängig von eurer gegebenen Situation zu sein.
<G-vec00272-001-s543><call.nennen><en> "It is said that Han Yu, a famous literary figure from the Tang dynasty, burst into tears in fear of the frightful path to ""Blue Dragon Ridge"" and wrote for help, creating the landmark we now call ""Han Yu's Cry for Help"" [9]."
<G-vec00272-001-s543><call.nennen><de> Man erzählt, dass Han Yu, ein berühmter Literat der Tang-Dynastie, aus Angst vor dem furchteinflößenden Pfad zum „Blauer Drache-Bergrücken“ in Tränen ausbrach und um Hilfe schrie, wodurch die Landmarke entstand, die sich nun „Han Yus Schrei um Hilfe“ (9) nennt.
<G-vec00272-001-s544><call.nennen><en> “Remember, at one time the distance between the bodies of land on your Earth, which you call continents, was considered great, and much time was required to travel from one to another.
<G-vec00272-001-s544><call.nennen><de> Erinnere Dich, dass einmal die Entfernung auf Eurer Erde zwischen den Erdkörpern, die Ihr Kontinente nennt, als sehr gross galt und man brauchte für die Überquerung viel Zeit.
<G-vec00272-001-s545><call.nennen><en> The Acts of the Apostles call Jesus the leader of the way into life.
<G-vec00272-001-s545><call.nennen><de> Die Apostelgeschichte nennt Jesus den Führer auf dem Weg in das Leben.
<G-vec00272-001-s546><call.nennen><en> "David Sugar, the author of Bayonne, likes to call it the ""Swiss army knife"" of the ""telephony servers,"" because tdM bus support, call ""switching"" and VoIP gateway services are already being worked on."
<G-vec00272-001-s546><call.nennen><de> "David Sugar, der Autor von Bayonne, nennt es gerne das ""Schweizer Taschenmesser"" der ""Telefonie Server"", da auch die Unterstützung des tdM Bus, ""Anrufumschaltung"" und VoIP Gateway-Dienste in Arbeit sind."
<G-vec00272-001-s547><call.nennen><en> Meditation has become a natural, almost daily part of my life- the island of stillness, how you call it, helps me to stay in touch with being myself and find deep rest and new energy.
<G-vec00272-001-s547><call.nennen><de> "Die Meditation ist ein natürlicher, beinahe täglicher Teil meines Lebens geworden - die ""Insel der Stille"", wie Ihr es so treffend nennt, hilft mir, bei mir zu bleiben und Kraft zu tanken."
<G-vec00272-001-s548><call.nennen><en> "He may call Palestinians ""Terrorists"", but he performs surgery on them, ""no matter what they believe""."
<G-vec00272-001-s548><call.nennen><de> Zwar nennt er Palästinenser «Terroristen», aber er operiert sie, «egal, was sie glauben».
<G-vec00272-001-s549><call.nennen><en> Whoever can call a Prinz Hunting Weapon his own expresses with it not only his individuality, but also, in particular, his will to give the hunter’s luck a helping hand.
<G-vec00272-001-s549><call.nennen><de> Wer eine Prinz sein Eigen nennt, drückt damit nicht nur seine Individualität aus, sondern auch und vor allem seinen Willen, dem Jagdglück ein wenig auf die Sprünge zu helfen.
<G-vec00272-001-s550><call.nennen><en> Beside of the helpless story contains the video a lot income statements of bank accounts and similar, full censored, and call it a proof.
<G-vec00272-001-s550><call.nennen><de> Neben der nutzlosen Story enthält das Video eine menge Kontostände von Bankkonto und ähnliches, voll zensiert, und nennt das auch noch einen Beweis.
<G-vec00092-001-s570><call.rufen><en> I call Mr.Levon Ter-Petrosyan for active cooperation and establishment of peace.
<G-vec00092-001-s570><call.rufen><de> Ich rufe Herrn Levon Ter-Petrosjan zur aktiven Zusammenarbeit auf Friedenssuche auf.
<G-vec00092-001-s571><call.rufen><en> 14 Is any sick among you? let him call to him the elders of the assembly, and let them pray over him, anointing him with oil in the name of the Lord;
<G-vec00092-001-s571><call.rufen><de> 14 Ist jemand krank, der rufe zu sich die Ältesten von der Gemeinde und lasse sie über sich beten und salben mit Öl in dem Namen des HErrn.
<G-vec00092-001-s572><call.rufen><en> Here I call on fellow practitioners to urgently search for those missing Falun Dafa practitioners, expose the evil persecution and save fellow practitioners.
<G-vec00092-001-s572><call.rufen><de> Ich rufe meine Mitpraktizierenden dazu auf, unbedingt die vermissten Falun Gong-Praktizierenden zu suchen, das Böse zu entlarven und die Mitpraktizierenden zu retten.
<G-vec00092-001-s573><call.rufen><en> And therefore I call to you time and again: Believe that you are shortly facing the end.
<G-vec00092-001-s573><call.rufen><de> Und immer wieder rufe Ich euch daher zu: Glaubet es, daß ihr kurz vor dem Ende steht.
<G-vec00092-001-s574><call.rufen><en> I know about the terrible lot of the souls; I see men in their blindness steer towards the abyss; I call out to them words of admonition and warning; I send to them guides into the way, who are to push them back onto the right way, which leads to me.
<G-vec00092-001-s574><call.rufen><de> Ich weiß um das furchtbare Los der Seelen, Ich sehe die Menschen in ihrer Blindheit dem Abgrund zusteuern, Ich rufe ihnen Mahn- und Warnworte zu, Ich sende ihnen Führer in den Weg, die sie zurückdrängen sollen auf den rechten Weg, der zu Mir führt.
<G-vec00092-001-s575><call.rufen><en> Regardless of whether they were from the business field or the Chinese consulate, they clearly heard the Falun Gong practitioners' call for ending the persecution.
<G-vec00092-001-s575><call.rufen><de> Ganz gleich, ob es Geschäftsleute waren oder vom Chinesischen Konsulat, konnten sie doch die Rufe der Praktizierenden die Verfolgung zu stoppen deutlich hören.
<G-vec00092-001-s576><call.rufen><en> I call to all Californian visionaries of immortality: first, let us make the world a better place – together.
<G-vec00092-001-s576><call.rufen><de> Ich komme zum Schluss: Allen kalifornischen Unsterblichkeits-Visionären rufe ich zu: Erstens: ja, lasst uns die Welt besser machen.
<G-vec00092-001-s577><call.rufen><en> In this case internet calls would not reach the actual owner of the call number any longer.
<G-vec00092-001-s577><call.rufen><de> Rufe aus dem Internet würden den Rufnummern-Inhaber in diesem Fall nicht mehr erreichen.
<G-vec00092-001-s578><call.rufen><en> I want to be the man that you run to whenever I call on you When everything that loved someone finally found it's way Wanna be a better man I see it in you yeah... Teile diesen Songtext
<G-vec00092-001-s578><call.rufen><de> Ich will der Mann sein, zu dem du immer rennst, egal wann ich nach dir rufe Wenn alle letztendlich ihren Weg gefunden haben Ich will ein besserer Mensch sein Ich kann es in dir sehen yeah...
<G-vec00092-001-s579><call.rufen><en> And then you will be blessed to own a supply of spiritual goods and so that you permanently increase these I admonish you again and again and call out to you to take seriously my admonition and to accept my word from above often because it is the most delicious gift I can give and because it has an exceedingly favourable influence on you.
<G-vec00092-001-s579><call.rufen><de> Und dann werdet ihr selig sein, einen Vorrat zu besitzen an geistigen Gütern, und auf daß ihr ständig diese vermehret, ermahne Ich euch immer wieder und rufe euch zu, Meine Mahnungen ernst zu nehmen und Mein Wort aus der Höhe des öfteren entgegenzunehmen, weil es die köstlichste Gabe ist, die Ich euch zuwenden kann, und weil sie überaus günstigen Einfluß hat auf euch.
<G-vec00092-001-s580><call.rufen><en> "Well, only if you want to be sarcastic and call that abovementioned gloom ""Finnish party mood""... Initially it seemed that this evening should see more people on stage than in front of it, most likely caused by the simple fact that not everybody had noticed the early schedule (first band started 20:15h, very unusual for Finland). But during the first songs the club filled up, and in the end the band faced a pretty big crowd that cheered and even wanted more."
<G-vec00092-001-s580><call.rufen><de> "Nunja, nur wenn man obengenannte düstere Stimmung sarkastischerweise als ""finnische Partylaune"" deklariert... Anfänglich schien es auch so, als sollten sich an diesem Abend mehr Musiker auf der Bühne tummelten als Publikum davor – die für Finnland ungewöhnlich früh angesetzte Beginnzeit des Konzerts (20:15h) hatte sich wohl nicht rechtzeitig herumgesprochen... doch im Laufe der ersten Songs füllte sich der Club, und am Schluss konnte diese neue finnische All-Star-Group verdienten Jubel von ziemlich vollem Haus und sogar vereinzelte Rufe nach Zugabe einheimsen."
<G-vec00092-001-s581><call.rufen><en> For, behold, I will call all the families of the kingdoms of the north, says Yahweh; and they shall come, and they shall set everyone his throne at the entrance of the gates of Jerusalem, and against all the walls of it round about, and against all the cities of Judah.
<G-vec00092-001-s581><call.rufen><de> Denn siehe, ich rufe allen Stammesgruppen in den Königreichen des Nordens zu, spricht der HERR, daß sie kommen, und jeder wird seinen Thron am Eingang der Tore Jerusalems aufstellen und gegen all seine Mauern ringsum und gegen alle Städte Judas.
<G-vec00092-001-s582><call.rufen><en> Take advantage of the time yet available and open your ears and your hearts, so that I THE LORD can soon reveal to you and do even greater things through MY messengers, call I THE LORD AND FATHER OF ETERNAL LOVE unto you.
<G-vec00092-001-s582><call.rufen><de> Nutzet die Zeit und öffnet eure Ohren und eure Herzen, auf daß ICH DER HERR euch bald noch Größeres durch MEINE Sendboten offenbaren und tun kann, rufe ICH euch zu, euer HERR und VATER DER EWIGEN LIEBE.
<G-vec00092-001-s583><call.rufen><en> He said to his companion; make the call to prayer so that we might be comforted by praying.
<G-vec00092-001-s583><call.rufen><de> Er sagte zu seinem Gefährten: Rufe zum Gebet, damit wir durch das Gebet Trost finden.
<G-vec00092-001-s584><call.rufen><en> "15 (UKJV) ""For, lo, I will call all the families of the kingdoms of the north, says the LORD; and they shall come, and they shall set every one his throne at the entering of the gates of Jerusalem, and against all the walls thereof round about, and against all the cities of Judah. """
<G-vec00092-001-s584><call.rufen><de> 15 (ELB) Denn siehe, ich rufe allen Geschlechtern der Königreiche gegen Norden, spricht Jehova, daß sie kommen und ein jeder seinen Thron stellen an den Eingang der Tore Jerusalems und wider alle seine Mauern ringsum, und wider alle Städte Judas.
<G-vec00092-001-s585><call.rufen><en> I call on each one of you to consciously decide for God and against Satan.
<G-vec00092-001-s585><call.rufen><de> Ich rufe euch auf, daß sich jeder von euch bewußt für Gott und gegen Satan entscheidet.
<G-vec00092-001-s586><call.rufen><en> I call on Member States to clarify and expand international law on environmental protection in times of war.
<G-vec00092-001-s586><call.rufen><de> Ich rufe die Mitgliedstaaten der Vereinten Nationen dazu auf, die internationalen Gesetze für den Umweltschutz in Zeiten von Kriegen zu präzisieren und auszuweiten.
<G-vec00092-001-s587><call.rufen><en> Today is a day of peace, but in the whole world there is a great lack of peace. That is why I call you all to build a new world of peace with me through prayer.
<G-vec00092-001-s587><call.rufen><de> Heute ist der Tag des Friedens, aber in der ganzen Welt ist viel Unfriede, deshalb rufe ich euch auf, daß ihr alle mit mir durch das Gebet eine neue Welt des Friedens aufbaut.
<G-vec00092-001-s588><call.rufen><en> SCP-1340-12: I hereby call this meeting into order.
<G-vec00092-001-s588><call.rufen><de> SCP-1340-12: Ich rufe dieses Treffen hiermit zur Ordnung.
<G-vec00272-001-s570><call.rufen><en> I call Mr.Levon Ter-Petrosyan for active cooperation and establishment of peace.
<G-vec00272-001-s570><call.rufen><de> Ich rufe Herrn Levon Ter-Petrosjan zur aktiven Zusammenarbeit auf Friedenssuche auf.
<G-vec00272-001-s571><call.rufen><en> 14 Is any sick among you? let him call to him the elders of the assembly, and let them pray over him, anointing him with oil in the name of the Lord;
<G-vec00272-001-s571><call.rufen><de> 14 Ist jemand krank, der rufe zu sich die Ältesten von der Gemeinde und lasse sie über sich beten und salben mit Öl in dem Namen des HErrn.
<G-vec00272-001-s572><call.rufen><en> Here I call on fellow practitioners to urgently search for those missing Falun Dafa practitioners, expose the evil persecution and save fellow practitioners.
<G-vec00272-001-s572><call.rufen><de> Ich rufe meine Mitpraktizierenden dazu auf, unbedingt die vermissten Falun Gong-Praktizierenden zu suchen, das Böse zu entlarven und die Mitpraktizierenden zu retten.
<G-vec00272-001-s573><call.rufen><en> And therefore I call to you time and again: Believe that you are shortly facing the end.
<G-vec00272-001-s573><call.rufen><de> Und immer wieder rufe Ich euch daher zu: Glaubet es, daß ihr kurz vor dem Ende steht.
<G-vec00272-001-s574><call.rufen><en> I know about the terrible lot of the souls; I see men in their blindness steer towards the abyss; I call out to them words of admonition and warning; I send to them guides into the way, who are to push them back onto the right way, which leads to me.
<G-vec00272-001-s574><call.rufen><de> Ich weiß um das furchtbare Los der Seelen, Ich sehe die Menschen in ihrer Blindheit dem Abgrund zusteuern, Ich rufe ihnen Mahn- und Warnworte zu, Ich sende ihnen Führer in den Weg, die sie zurückdrängen sollen auf den rechten Weg, der zu Mir führt.
<G-vec00272-001-s575><call.rufen><en> Regardless of whether they were from the business field or the Chinese consulate, they clearly heard the Falun Gong practitioners' call for ending the persecution.
<G-vec00272-001-s575><call.rufen><de> Ganz gleich, ob es Geschäftsleute waren oder vom Chinesischen Konsulat, konnten sie doch die Rufe der Praktizierenden die Verfolgung zu stoppen deutlich hören.
<G-vec00272-001-s576><call.rufen><en> I call to all Californian visionaries of immortality: first, let us make the world a better place – together.
<G-vec00272-001-s576><call.rufen><de> Ich komme zum Schluss: Allen kalifornischen Unsterblichkeits-Visionären rufe ich zu: Erstens: ja, lasst uns die Welt besser machen.
<G-vec00272-001-s577><call.rufen><en> In this case internet calls would not reach the actual owner of the call number any longer.
<G-vec00272-001-s577><call.rufen><de> Rufe aus dem Internet würden den Rufnummern-Inhaber in diesem Fall nicht mehr erreichen.
<G-vec00272-001-s578><call.rufen><en> I want to be the man that you run to whenever I call on you When everything that loved someone finally found it's way Wanna be a better man I see it in you yeah... Teile diesen Songtext
<G-vec00272-001-s578><call.rufen><de> Ich will der Mann sein, zu dem du immer rennst, egal wann ich nach dir rufe Wenn alle letztendlich ihren Weg gefunden haben Ich will ein besserer Mensch sein Ich kann es in dir sehen yeah...
<G-vec00272-001-s579><call.rufen><en> And then you will be blessed to own a supply of spiritual goods and so that you permanently increase these I admonish you again and again and call out to you to take seriously my admonition and to accept my word from above often because it is the most delicious gift I can give and because it has an exceedingly favourable influence on you.
<G-vec00272-001-s579><call.rufen><de> Und dann werdet ihr selig sein, einen Vorrat zu besitzen an geistigen Gütern, und auf daß ihr ständig diese vermehret, ermahne Ich euch immer wieder und rufe euch zu, Meine Mahnungen ernst zu nehmen und Mein Wort aus der Höhe des öfteren entgegenzunehmen, weil es die köstlichste Gabe ist, die Ich euch zuwenden kann, und weil sie überaus günstigen Einfluß hat auf euch.
<G-vec00272-001-s580><call.rufen><en> "Well, only if you want to be sarcastic and call that abovementioned gloom ""Finnish party mood""... Initially it seemed that this evening should see more people on stage than in front of it, most likely caused by the simple fact that not everybody had noticed the early schedule (first band started 20:15h, very unusual for Finland). But during the first songs the club filled up, and in the end the band faced a pretty big crowd that cheered and even wanted more."
<G-vec00272-001-s580><call.rufen><de> "Nunja, nur wenn man obengenannte düstere Stimmung sarkastischerweise als ""finnische Partylaune"" deklariert... Anfänglich schien es auch so, als sollten sich an diesem Abend mehr Musiker auf der Bühne tummelten als Publikum davor – die für Finnland ungewöhnlich früh angesetzte Beginnzeit des Konzerts (20:15h) hatte sich wohl nicht rechtzeitig herumgesprochen... doch im Laufe der ersten Songs füllte sich der Club, und am Schluss konnte diese neue finnische All-Star-Group verdienten Jubel von ziemlich vollem Haus und sogar vereinzelte Rufe nach Zugabe einheimsen."
<G-vec00272-001-s581><call.rufen><en> For, behold, I will call all the families of the kingdoms of the north, says Yahweh; and they shall come, and they shall set everyone his throne at the entrance of the gates of Jerusalem, and against all the walls of it round about, and against all the cities of Judah.
<G-vec00272-001-s581><call.rufen><de> Denn siehe, ich rufe allen Stammesgruppen in den Königreichen des Nordens zu, spricht der HERR, daß sie kommen, und jeder wird seinen Thron am Eingang der Tore Jerusalems aufstellen und gegen all seine Mauern ringsum und gegen alle Städte Judas.
<G-vec00272-001-s582><call.rufen><en> Take advantage of the time yet available and open your ears and your hearts, so that I THE LORD can soon reveal to you and do even greater things through MY messengers, call I THE LORD AND FATHER OF ETERNAL LOVE unto you.
<G-vec00272-001-s582><call.rufen><de> Nutzet die Zeit und öffnet eure Ohren und eure Herzen, auf daß ICH DER HERR euch bald noch Größeres durch MEINE Sendboten offenbaren und tun kann, rufe ICH euch zu, euer HERR und VATER DER EWIGEN LIEBE.
<G-vec00272-001-s583><call.rufen><en> He said to his companion; make the call to prayer so that we might be comforted by praying.
<G-vec00272-001-s583><call.rufen><de> Er sagte zu seinem Gefährten: Rufe zum Gebet, damit wir durch das Gebet Trost finden.
<G-vec00272-001-s584><call.rufen><en> "15 (UKJV) ""For, lo, I will call all the families of the kingdoms of the north, says the LORD; and they shall come, and they shall set every one his throne at the entering of the gates of Jerusalem, and against all the walls thereof round about, and against all the cities of Judah. """
<G-vec00272-001-s584><call.rufen><de> 15 (ELB) Denn siehe, ich rufe allen Geschlechtern der Königreiche gegen Norden, spricht Jehova, daß sie kommen und ein jeder seinen Thron stellen an den Eingang der Tore Jerusalems und wider alle seine Mauern ringsum, und wider alle Städte Judas.
<G-vec00272-001-s585><call.rufen><en> I call on each one of you to consciously decide for God and against Satan.
<G-vec00272-001-s585><call.rufen><de> Ich rufe euch auf, daß sich jeder von euch bewußt für Gott und gegen Satan entscheidet.
<G-vec00272-001-s586><call.rufen><en> I call on Member States to clarify and expand international law on environmental protection in times of war.
<G-vec00272-001-s586><call.rufen><de> Ich rufe die Mitgliedstaaten der Vereinten Nationen dazu auf, die internationalen Gesetze für den Umweltschutz in Zeiten von Kriegen zu präzisieren und auszuweiten.
<G-vec00272-001-s587><call.rufen><en> Today is a day of peace, but in the whole world there is a great lack of peace. That is why I call you all to build a new world of peace with me through prayer.
<G-vec00272-001-s587><call.rufen><de> Heute ist der Tag des Friedens, aber in der ganzen Welt ist viel Unfriede, deshalb rufe ich euch auf, daß ihr alle mit mir durch das Gebet eine neue Welt des Friedens aufbaut.
<G-vec00272-001-s588><call.rufen><en> SCP-1340-12: I hereby call this meeting into order.
<G-vec00272-001-s588><call.rufen><de> SCP-1340-12: Ich rufe dieses Treffen hiermit zur Ordnung.
<G-vec00092-001-s589><call.rufen><en> Send a rental inquiry through fritiden.se or call the landlordLinda Lindell at 070-5098939.
<G-vec00092-001-s589><call.rufen><de> Schicken Sie eine Buchungsanfrage über fritiden.se oder rufen Sie den VermieterLinda Lindell unter 070-5098939 an.
<G-vec00092-001-s590><call.rufen><en> As a basis for our study we assume an arbitrary collection of entities of an arbitrary nature, entities which, for brevity, we shall call points, but this is quite independent of their nature.
<G-vec00092-001-s590><call.rufen><de> Als Grundlage für unsere Studie gehen wir davon eine willkürliche Sammlung von Entitäten einer willkürlichen Charakter, Organisationen, die zu kurz, wir rufen Punkte, aber das ist ganz unabhängig von ihrer Natur.
<G-vec00092-001-s591><call.rufen><en> You are encouraged to call upon us should you require our help, and we will respond with love and help you where possible.
<G-vec00092-001-s591><call.rufen><de> Ihr seid ermuntert, nach uns zu rufen, solltet ihr unserer Hilfe bedürfen, und wir werden, wo es möglich ist, mit Liebe und Hilfe darauf antworten.
<G-vec00092-001-s592><call.rufen><en> You set the cursor on the line with the block to rename and then you call this command Rename block .
<G-vec00092-001-s592><call.rufen><de> Setzen Sie den Cursor auf die Zeile des Bausteins, den Sie umbenennen wollen und rufen Sie nun das Kommando Umbenennen auf.
<G-vec00092-001-s593><call.rufen><en> On the lower floor there are four bedrooms, a large bathroom and storage room.It is a very bright apartment with cross ventilation.It has pre-installation of natural gas for heating and natural gas.With a reform you can stay a large floor to the taste of the consumer.If you want to buy a flat in El Carmen, do not hesitate to call us, Atico inmobiliaria Inmobiliaria.
<G-vec00092-001-s593><call.rufen><de> In der unteren Etage befinden sich vier Schlafzimmer, ein großes Badezimmer und ein Abstellraum.Es ist eine sehr helle Wohnung mit Querlüftung.Es hat Erdgas zum Heizen und Erdgas vorinstalliert.Mit einer Reform können Sie eine große Etage nach dem Geschmack des Verbrauchers bleiben.Wenn Sie eine Wohnung in El Carmen kaufen möchten, rufen Sie uns bitte Atico inmobiliaria Inmobiliaria an.
<G-vec00092-001-s594><call.rufen><en> Send a Rental Inquiry Or call the landlord Peter Schmidt at 049034544 (0706195007).
<G-vec00092-001-s594><call.rufen><de> Buchungsanfrage Schicken Oder rufen Sie den Vermieter Peter Schmidt unter 049034544 (0706195007) an.
<G-vec00092-001-s595><call.rufen><en> Please call toll-free 0800 1 85 55 22 (Germany) to speak to a booking specialist or click the button below to view a list of our hotels in Germany. Weimar
<G-vec00092-001-s595><call.rufen><de> Bitte rufen Sie uns unter 0800 1 85 55 22 (Deutschland) (gebührenfrei aus Deutschland) an, um mit unserem Reservierungsservice zu sprechen oder klicken Sie auf den Button unten, um eine Liste unserer Hotels in Deutschland zu erhalten.
<G-vec00092-001-s596><call.rufen><en> Other necessary functions include music playing, call receiving and security monitoring.
<G-vec00092-001-s596><call.rufen><de> Andere notwendigen Funktionen umfassen Musikwiedergabe, rufen empfangen und Sicherheitsüberwachung.
<G-vec00092-001-s597><call.rufen><en> Call the service, they themselves only develop the immunity, the further, the harder it is to choose the drug for complete destruction.
<G-vec00092-001-s597><call.rufen><de> Rufen Sie den Dienst an, sie selbst entwickeln nur die Immunität, je weiter es desto schwieriger ist, das Medikament für die vollständige Zerstörung auszuwählen.
<G-vec00092-001-s598><call.rufen><en> In case you need help, please call our customer service on the phone number: +36 1 510 0548.
<G-vec00092-001-s598><call.rufen><de> Sollten Sie Hilfe brauchen, rufen Sie bitte unseren Kundendienst an:+36 1 510 0548.
<G-vec00092-001-s599><call.rufen><en> I was afraid that they would call the police, so I decided to go back and not tell them that I took the pills.
<G-vec00092-001-s599><call.rufen><de> Ich fürchtete sie würden die Polizei rufen, also entschied ich zurückzugehen und ihnen nicht zu sagen dass ich die Pillen nahm.
<G-vec00092-001-s600><call.rufen><en> We will be happy to call you back
<G-vec00092-001-s600><call.rufen><de> Gerne rufen wir Sie zurück.
<G-vec00092-001-s601><call.rufen><en> How much you call - All cards expire (usually 30-90 days from the first time you use it to call).
<G-vec00092-001-s601><call.rufen><de> Wie viel Sie rufen - (normalerweise 30-90 Tage nach dem ersten Mal, wenn Sie es verwenden, um Anruf) Alle Karten verfallen.
<G-vec00092-001-s602><call.rufen><en> Please get ready all the necessary information (see Question above) and call our Reservation Center.
<G-vec00092-001-s602><call.rufen><de> Bitte halten sie alle benoetigten Informationen berreit (siehe Fragen unten) und rufen sie unser Reservierungs Center an.
<G-vec00092-001-s603><call.rufen><en> Send a rental inquiry or call the landlord Eva Rapp Rock / Rappland House Rent co.Ltd at +46 70-2973363.
<G-vec00092-001-s603><call.rufen><de> Klicken Sie hier um eine Buchungsanfrage zu schicken oder rufen Sie den Vermieter Eva Rapp Rock / Rappland House Rent co.Ltd unter +46 70-2973363 an.
<G-vec00092-001-s604><call.rufen><en> If you have any questions about our Class I leak detectors, call us.
<G-vec00092-001-s604><call.rufen><de> Wenn Sie vorab Fragen rund um unsere Klasse-I-Leckanzeiger haben, rufen Sie uns an.
<G-vec00092-001-s605><call.rufen><en> It is advisable, when traveling by provincial buses in this region, to call in and buy the ticket the evening before, in order to ensure a numbered seat (as opposed to the possibility of a stool in the gangway).
<G-vec00092-001-s605><call.rufen><de> Es ist ratsam, beim Reisen durch provinzielle Busse in diesem Gebiet, in zu rufen, und travel Karte den Abend vor zu kaufen, um zu sichern, einen gezählten Sitz (im Gegensatz zur Möglichkeit von einem Hocker in der Gangway).
<G-vec00092-001-s606><call.rufen><en> And in the Assembly people were saying that person who said that, we should call him in the rainy season, when there’s lots of mud and sometimes your feet sink 50 or 80 centimeters, and you don’t realize there’s glass or sharp rocks underneath.
<G-vec00092-001-s606><call.rufen><de> In der Versammlung wurde darauf gesagt, dass man denjenigen der dies sagte, rufen sollte, wenn Regenzeit ist, wenn alles voller Schlamm ist und die Füße manchmal versinken, 50 bis 80 Zentimeter, und man nicht merkt, ob irgendwo Glas liegt, oder spitze Steine oder Stöcke.
<G-vec00092-001-s607><call.rufen><en> arriving in Paraty, you can walk 50 mts from the bus station, taking the right street in east direction, till the big tree (thereÂ ́s a pizzaria in the corner of the house)or call us and weÂ ́ll go until you in a minute.
<G-vec00092-001-s607><call.rufen><de> Ankunft in Paraty, können Sie zu Fuß 50 m von der Bushaltestelle, die die Straße rechts in Richtung Osten, bis zum großen Baum (gibt es eine Pizzeria in der Ecke des Hauses) oder rufen Sie uns an und wir gehen, bis Sie in einem Minute.
<G-vec00272-001-s589><call.rufen><en> Send a rental inquiry through fritiden.se or call the landlordLinda Lindell at 070-5098939.
<G-vec00272-001-s589><call.rufen><de> Schicken Sie eine Buchungsanfrage über fritiden.se oder rufen Sie den VermieterLinda Lindell unter 070-5098939 an.
<G-vec00272-001-s590><call.rufen><en> As a basis for our study we assume an arbitrary collection of entities of an arbitrary nature, entities which, for brevity, we shall call points, but this is quite independent of their nature.
<G-vec00272-001-s590><call.rufen><de> Als Grundlage für unsere Studie gehen wir davon eine willkürliche Sammlung von Entitäten einer willkürlichen Charakter, Organisationen, die zu kurz, wir rufen Punkte, aber das ist ganz unabhängig von ihrer Natur.
<G-vec00272-001-s591><call.rufen><en> You are encouraged to call upon us should you require our help, and we will respond with love and help you where possible.
<G-vec00272-001-s591><call.rufen><de> Ihr seid ermuntert, nach uns zu rufen, solltet ihr unserer Hilfe bedürfen, und wir werden, wo es möglich ist, mit Liebe und Hilfe darauf antworten.
<G-vec00272-001-s592><call.rufen><en> You set the cursor on the line with the block to rename and then you call this command Rename block .
<G-vec00272-001-s592><call.rufen><de> Setzen Sie den Cursor auf die Zeile des Bausteins, den Sie umbenennen wollen und rufen Sie nun das Kommando Umbenennen auf.
<G-vec00272-001-s593><call.rufen><en> On the lower floor there are four bedrooms, a large bathroom and storage room.It is a very bright apartment with cross ventilation.It has pre-installation of natural gas for heating and natural gas.With a reform you can stay a large floor to the taste of the consumer.If you want to buy a flat in El Carmen, do not hesitate to call us, Atico inmobiliaria Inmobiliaria.
<G-vec00272-001-s593><call.rufen><de> In der unteren Etage befinden sich vier Schlafzimmer, ein großes Badezimmer und ein Abstellraum.Es ist eine sehr helle Wohnung mit Querlüftung.Es hat Erdgas zum Heizen und Erdgas vorinstalliert.Mit einer Reform können Sie eine große Etage nach dem Geschmack des Verbrauchers bleiben.Wenn Sie eine Wohnung in El Carmen kaufen möchten, rufen Sie uns bitte Atico inmobiliaria Inmobiliaria an.
<G-vec00272-001-s594><call.rufen><en> Send a Rental Inquiry Or call the landlord Peter Schmidt at 049034544 (0706195007).
<G-vec00272-001-s594><call.rufen><de> Buchungsanfrage Schicken Oder rufen Sie den Vermieter Peter Schmidt unter 049034544 (0706195007) an.
<G-vec00272-001-s595><call.rufen><en> Please call toll-free 0800 1 85 55 22 (Germany) to speak to a booking specialist or click the button below to view a list of our hotels in Germany. Weimar
<G-vec00272-001-s595><call.rufen><de> Bitte rufen Sie uns unter 0800 1 85 55 22 (Deutschland) (gebührenfrei aus Deutschland) an, um mit unserem Reservierungsservice zu sprechen oder klicken Sie auf den Button unten, um eine Liste unserer Hotels in Deutschland zu erhalten.
<G-vec00272-001-s596><call.rufen><en> Other necessary functions include music playing, call receiving and security monitoring.
<G-vec00272-001-s596><call.rufen><de> Andere notwendigen Funktionen umfassen Musikwiedergabe, rufen empfangen und Sicherheitsüberwachung.
<G-vec00272-001-s597><call.rufen><en> Call the service, they themselves only develop the immunity, the further, the harder it is to choose the drug for complete destruction.
<G-vec00272-001-s597><call.rufen><de> Rufen Sie den Dienst an, sie selbst entwickeln nur die Immunität, je weiter es desto schwieriger ist, das Medikament für die vollständige Zerstörung auszuwählen.
<G-vec00272-001-s598><call.rufen><en> In case you need help, please call our customer service on the phone number: +36 1 510 0548.
<G-vec00272-001-s598><call.rufen><de> Sollten Sie Hilfe brauchen, rufen Sie bitte unseren Kundendienst an:+36 1 510 0548.
<G-vec00272-001-s599><call.rufen><en> I was afraid that they would call the police, so I decided to go back and not tell them that I took the pills.
<G-vec00272-001-s599><call.rufen><de> Ich fürchtete sie würden die Polizei rufen, also entschied ich zurückzugehen und ihnen nicht zu sagen dass ich die Pillen nahm.
<G-vec00272-001-s600><call.rufen><en> We will be happy to call you back
<G-vec00272-001-s600><call.rufen><de> Gerne rufen wir Sie zurück.
<G-vec00272-001-s601><call.rufen><en> How much you call - All cards expire (usually 30-90 days from the first time you use it to call).
<G-vec00272-001-s601><call.rufen><de> Wie viel Sie rufen - (normalerweise 30-90 Tage nach dem ersten Mal, wenn Sie es verwenden, um Anruf) Alle Karten verfallen.
<G-vec00272-001-s602><call.rufen><en> Please get ready all the necessary information (see Question above) and call our Reservation Center.
<G-vec00272-001-s602><call.rufen><de> Bitte halten sie alle benoetigten Informationen berreit (siehe Fragen unten) und rufen sie unser Reservierungs Center an.
<G-vec00272-001-s603><call.rufen><en> Send a rental inquiry or call the landlord Eva Rapp Rock / Rappland House Rent co.Ltd at +46 70-2973363.
<G-vec00272-001-s603><call.rufen><de> Klicken Sie hier um eine Buchungsanfrage zu schicken oder rufen Sie den Vermieter Eva Rapp Rock / Rappland House Rent co.Ltd unter +46 70-2973363 an.
<G-vec00272-001-s604><call.rufen><en> If you have any questions about our Class I leak detectors, call us.
<G-vec00272-001-s604><call.rufen><de> Wenn Sie vorab Fragen rund um unsere Klasse-I-Leckanzeiger haben, rufen Sie uns an.
<G-vec00272-001-s605><call.rufen><en> It is advisable, when traveling by provincial buses in this region, to call in and buy the ticket the evening before, in order to ensure a numbered seat (as opposed to the possibility of a stool in the gangway).
<G-vec00272-001-s605><call.rufen><de> Es ist ratsam, beim Reisen durch provinzielle Busse in diesem Gebiet, in zu rufen, und travel Karte den Abend vor zu kaufen, um zu sichern, einen gezählten Sitz (im Gegensatz zur Möglichkeit von einem Hocker in der Gangway).
<G-vec00272-001-s606><call.rufen><en> And in the Assembly people were saying that person who said that, we should call him in the rainy season, when there’s lots of mud and sometimes your feet sink 50 or 80 centimeters, and you don’t realize there’s glass or sharp rocks underneath.
<G-vec00272-001-s606><call.rufen><de> In der Versammlung wurde darauf gesagt, dass man denjenigen der dies sagte, rufen sollte, wenn Regenzeit ist, wenn alles voller Schlamm ist und die Füße manchmal versinken, 50 bis 80 Zentimeter, und man nicht merkt, ob irgendwo Glas liegt, oder spitze Steine oder Stöcke.
<G-vec00272-001-s607><call.rufen><en> arriving in Paraty, you can walk 50 mts from the bus station, taking the right street in east direction, till the big tree (thereÂ ́s a pizzaria in the corner of the house)or call us and weÂ ́ll go until you in a minute.
<G-vec00272-001-s607><call.rufen><de> Ankunft in Paraty, können Sie zu Fuß 50 m von der Bushaltestelle, die die Straße rechts in Richtung Osten, bis zum großen Baum (gibt es eine Pizzeria in der Ecke des Hauses) oder rufen Sie uns an und wir gehen, bis Sie in einem Minute.
<G-vec00092-001-s608><call.anrufen><en> For relaxed vacation moments, call them and they will take you to the desired location.
<G-vec00092-001-s608><call.anrufen><de> Wenn sie sich den Urlaub ohne Sorgen wünschen, rufen Sie sie an, und sie werden sie auf die gefragte Stelle bringen.
<G-vec00092-001-s609><call.anrufen><en> Call +31 (0)497 383818 or e-mail marketing@kse.nl to request free entry tickets or to pre-arrange an appointment at the event.
<G-vec00092-001-s609><call.anrufen><de> Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zumarketing@kse.nlfür kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00092-001-s610><call.anrufen><en> Visit KSE on stand G028 in hall 5.Â Call +31 (0)497 383818 or e-mail marketing@kse.nlÂ to request free entry tickets or to pre-arrange an appointment on the stand.
<G-vec00092-001-s610><call.anrufen><de> Besuchen Sie KSE auf Stand G028 in Halle 5.Â Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zu marketing@kse.nlÂ für kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00092-001-s611><call.anrufen><en> Please call:
<G-vec00092-001-s611><call.anrufen><de> Rufen Sie uns an.
<G-vec00092-001-s612><call.anrufen><en> Please call us at the opening times.
<G-vec00092-001-s612><call.anrufen><de> Bitte rufen Sie uns während der Öffnungszeiten an.
<G-vec00092-001-s613><call.anrufen><en> The cafe is strictly reservation only, so make sure to call in advance.
<G-vec00092-001-s613><call.anrufen><de> Reservierungen sind unabdingbar, um bedient zu werden, rufen Sie deshalb unbedingt im Vorfeld an.
<G-vec00092-001-s614><call.anrufen><en> Call if you are in doubt or need advice and information yourself.
<G-vec00092-001-s614><call.anrufen><de> Rufen Sie uns an, sofern Sie im Zweifel sind oder selbst Rat und Auskunft benötigen.
<G-vec00092-001-s615><call.anrufen><en> Please call (or have your lawyer call) us for more details: Tel.
<G-vec00092-001-s615><call.anrufen><de> Rufen Sie uns an (oder lassen Sie Ihren Anwalt anrufen) um weitere Informationen zu bekommen: Tel.
<G-vec00092-001-s616><call.anrufen><en> Just call us or send us e-mail.
<G-vec00092-001-s616><call.anrufen><de> Rufen Sie uns einfach an oder senden Sie uns eine E- Mail.
<G-vec00092-001-s617><call.anrufen><en> You can find more detailed information on our homepage Or call us
<G-vec00092-001-s617><call.anrufen><de> und ausführlichere Informationen finden Sie auf unserer Homepage oder rufen Sie uns an.
<G-vec00092-001-s618><call.anrufen><en> Only experts call, but then they do not give a guarantee.
<G-vec00092-001-s618><call.anrufen><de> Nur Experten rufen an, aber dann geben sie keine Garantie.
<G-vec00092-001-s619><call.anrufen><en> Call 150 and follow voice prompts to enter scratch card details.
<G-vec00092-001-s619><call.anrufen><de> Rufen Sie die 150 an und folgen Sie den Sprachanweisungen, um die Scratch-Karte auf Ihre SIM-Karte aufzuladen.
<G-vec00092-001-s620><call.anrufen><en> Call and organize all your...
<G-vec00092-001-s620><call.anrufen><de> Rufen Sie an und organisieren...
<G-vec00092-001-s621><call.anrufen><en> Or simply call us.
<G-vec00092-001-s621><call.anrufen><de> Oder rufen Sie uns einfach an.
<G-vec00092-001-s622><call.anrufen><en> Please call if your vehicle is higher than 1.95 metres
<G-vec00092-001-s622><call.anrufen><de> Bitte rufen Sie an, wenn Ihr Fahrzeug höher als 1,95 m ist.
<G-vec00092-001-s623><call.anrufen><en> Visit KSE on stand B7878, hall B. Call +31 (0)497 383818 or e-mailmarketing@kse.nlto request free entry tickets or to pre-arrange an appointment on the stand. During the IPPE, KSE gives a TECHTalk with the title ‘Dosing Slide vs. Dosing Screw.
<G-vec00092-001-s623><call.anrufen><de> Besuchen Sie KSE auf Stand B7878, Halle B. Rufen Sie an: +31 (0)497 383818 oder senden Sie eine E-Mail:marketing@kse.nlfür kostenlose Eintrittskarten oder für einen vorher vereinbarten Termin auf der Stand.
<G-vec00092-001-s624><call.anrufen><en> Call us for more information.
<G-vec00092-001-s624><call.anrufen><de> Rufen Sie uns fÃ1⁄4r weitere Informationen an.
<G-vec00092-001-s625><call.anrufen><en> Call us, or send us an e-mail, and you will quickly receive your personalized gift certificate.
<G-vec00092-001-s625><call.anrufen><de> Rufen Sie uns an, oder senden Sie uns eine mail, schnell erhalten Sie Ihren ganz persönlichen Gutschein zum verschenken.
<G-vec00092-001-s626><call.anrufen><en> Call us toll free.
<G-vec00092-001-s626><call.anrufen><de> Rufen Sie uns an Maut.
<G-vec00272-001-s608><call.anrufen><en> For relaxed vacation moments, call them and they will take you to the desired location.
<G-vec00272-001-s608><call.anrufen><de> Wenn sie sich den Urlaub ohne Sorgen wünschen, rufen Sie sie an, und sie werden sie auf die gefragte Stelle bringen.
<G-vec00272-001-s609><call.anrufen><en> Call +31 (0)497 383818 or e-mail marketing@kse.nl to request free entry tickets or to pre-arrange an appointment at the event.
<G-vec00272-001-s609><call.anrufen><de> Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zumarketing@kse.nlfür kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00272-001-s610><call.anrufen><en> Visit KSE on stand G028 in hall 5.Â Call +31 (0)497 383818 or e-mail marketing@kse.nlÂ to request free entry tickets or to pre-arrange an appointment on the stand.
<G-vec00272-001-s610><call.anrufen><de> Besuchen Sie KSE auf Stand G028 in Halle 5.Â Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zu marketing@kse.nlÂ für kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00272-001-s611><call.anrufen><en> Please call:
<G-vec00272-001-s611><call.anrufen><de> Rufen Sie uns an.
<G-vec00272-001-s612><call.anrufen><en> Please call us at the opening times.
<G-vec00272-001-s612><call.anrufen><de> Bitte rufen Sie uns während der Öffnungszeiten an.
<G-vec00272-001-s613><call.anrufen><en> The cafe is strictly reservation only, so make sure to call in advance.
<G-vec00272-001-s613><call.anrufen><de> Reservierungen sind unabdingbar, um bedient zu werden, rufen Sie deshalb unbedingt im Vorfeld an.
<G-vec00272-001-s614><call.anrufen><en> Call if you are in doubt or need advice and information yourself.
<G-vec00272-001-s614><call.anrufen><de> Rufen Sie uns an, sofern Sie im Zweifel sind oder selbst Rat und Auskunft benötigen.
<G-vec00272-001-s615><call.anrufen><en> Please call (or have your lawyer call) us for more details: Tel.
<G-vec00272-001-s615><call.anrufen><de> Rufen Sie uns an (oder lassen Sie Ihren Anwalt anrufen) um weitere Informationen zu bekommen: Tel.
<G-vec00272-001-s616><call.anrufen><en> Just call us or send us e-mail.
<G-vec00272-001-s616><call.anrufen><de> Rufen Sie uns einfach an oder senden Sie uns eine E- Mail.
<G-vec00272-001-s617><call.anrufen><en> You can find more detailed information on our homepage Or call us
<G-vec00272-001-s617><call.anrufen><de> und ausführlichere Informationen finden Sie auf unserer Homepage oder rufen Sie uns an.
<G-vec00272-001-s618><call.anrufen><en> Only experts call, but then they do not give a guarantee.
<G-vec00272-001-s618><call.anrufen><de> Nur Experten rufen an, aber dann geben sie keine Garantie.
<G-vec00272-001-s619><call.anrufen><en> Call 150 and follow voice prompts to enter scratch card details.
<G-vec00272-001-s619><call.anrufen><de> Rufen Sie die 150 an und folgen Sie den Sprachanweisungen, um die Scratch-Karte auf Ihre SIM-Karte aufzuladen.
<G-vec00272-001-s620><call.anrufen><en> Call and organize all your...
<G-vec00272-001-s620><call.anrufen><de> Rufen Sie an und organisieren...
<G-vec00272-001-s621><call.anrufen><en> Or simply call us.
<G-vec00272-001-s621><call.anrufen><de> Oder rufen Sie uns einfach an.
<G-vec00272-001-s622><call.anrufen><en> Please call if your vehicle is higher than 1.95 metres
<G-vec00272-001-s622><call.anrufen><de> Bitte rufen Sie an, wenn Ihr Fahrzeug höher als 1,95 m ist.
<G-vec00272-001-s623><call.anrufen><en> Visit KSE on stand B7878, hall B. Call +31 (0)497 383818 or e-mailmarketing@kse.nlto request free entry tickets or to pre-arrange an appointment on the stand. During the IPPE, KSE gives a TECHTalk with the title ‘Dosing Slide vs. Dosing Screw.
<G-vec00272-001-s623><call.anrufen><de> Besuchen Sie KSE auf Stand B7878, Halle B. Rufen Sie an: +31 (0)497 383818 oder senden Sie eine E-Mail:marketing@kse.nlfür kostenlose Eintrittskarten oder für einen vorher vereinbarten Termin auf der Stand.
<G-vec00272-001-s624><call.anrufen><en> Call us for more information.
<G-vec00272-001-s624><call.anrufen><de> Rufen Sie uns fÃ1⁄4r weitere Informationen an.
<G-vec00272-001-s625><call.anrufen><en> Call us, or send us an e-mail, and you will quickly receive your personalized gift certificate.
<G-vec00272-001-s625><call.anrufen><de> Rufen Sie uns an, oder senden Sie uns eine mail, schnell erhalten Sie Ihren ganz persönlichen Gutschein zum verschenken.
<G-vec00272-001-s626><call.anrufen><en> Call us toll free.
<G-vec00272-001-s626><call.anrufen><de> Rufen Sie uns an Maut.
<G-vec00092-001-s627><call.rufen><en> Just call our customer service: +49 89 4161 430 70.
<G-vec00092-001-s627><call.rufen><de> Rufen Sie einfach unseren Kundenservice an: +49 89 4161 430 70.
<G-vec00092-001-s628><call.rufen><en> Call on the help of neighbors and create for your children a whole gaming complex together.
<G-vec00092-001-s628><call.rufen><de> Rufen Sie die Hilfe von Nachbarn an und schaffen Sie für Ihre Kinder einen ganzen Spielkomplex zusammen.
<G-vec00092-001-s629><call.rufen><en> This is why hiring our immigration law firm can greatly improve your chances of success in the immigration process, and in starting a new life in the U.S. No matter what your immigration status is, or your immigration plans are, call our firm at +1 (941) 362-7100.
<G-vec00092-001-s629><call.rufen><de> Dies is der Grund, unsere Einwanderungsanwaltskanzlei zu beauftragen, damit wir Ihre Chancen auf Erfolg in dem Einwanderungsprozess erheblich verbessern können, und Sie ein neues Leben in den USA zu beginnen können, ganz gleich was Ihr Aufenthaltsstatus ist, oder Ihre Einwanderungspläne sind, rufen Sie unsere Kanzlei unter +1 (941) 362-7100 an.
<G-vec00092-001-s630><call.rufen><en> Call diligently on his name.
<G-vec00092-001-s630><call.rufen><de> Rufen Sie bestndig seinen Namen an.
<G-vec00092-001-s631><call.rufen><en> Detailed specifications, CAD and datasheets can be found on our webstore, alternatively request a catalogue or call customer service for support in selecting the rightcomponent for your application.
<G-vec00092-001-s631><call.rufen><de> Detaillierte technische Daten, CAD-Zeichnungen und Datenblätter finden Sie unter Webstore, alternativ können Sie auch auf Anfrage Kataloge anfordern oder rufen Sie unseren Kundenservice an, um sich bei der Auswahl des richtigen Wartungsgerätes, für Ihre Anwendung, beraten zu lassen.
<G-vec00092-001-s632><call.rufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00092-001-s632><call.rufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00092-001-s633><call.rufen><en> If the problem persists, call Customer Service.
<G-vec00092-001-s633><call.rufen><de> Wenn das Problem anhält, rufen Sie den Kundendienst an.
<G-vec00092-001-s634><call.rufen><en> "Make sure your status - if in the next 15 minutes it will be a wet spot, immediately call the brigade ""first aid"" - doctors know exactly how to determine the leakage of amniotic fluid."
<G-vec00092-001-s634><call.rufen><de> Stellen Sie sicher, dass Ihr Status - wenn in den nächsten 15 Minuten wird es eine nasse Stelle sein, rufen Sie sofort die Brigade „Erste Hilfe“ - die Ärzte wissen genau, wie das Austreten von Fruchtwasser zu bestimmen.
<G-vec00092-001-s635><call.rufen><en> Call the plug-in with the command Effects -> AKVIS -> Retoucher.
<G-vec00092-001-s635><call.rufen><de> Rufen Sie das Plugin mit dem Befehl Effekte -> AKVIS -> Retoucher.
<G-vec00092-001-s636><call.rufen><en> Call now gladly advise free.
<G-vec00092-001-s636><call.rufen><de> Rufen Sie jetzt gerne beraten kostenlos.
<G-vec00092-001-s637><call.rufen><en> Call now to reserve one of our most popular rooms.
<G-vec00092-001-s637><call.rufen><de> Rufen Sie jetzt an, um eines unserer beliebtesten Zimmer reservieren.
<G-vec00092-001-s638><call.rufen><en> Favorites Call a user, meeting room or conference room system listed in your favorites.
<G-vec00092-001-s638><call.rufen><de> Favoriten Rufen Sie einen Benutzer, einen Konferenzraum oder ein Konferenzraumsystem an, das in Ihren Favoriten hinterlegt ist.
<G-vec00092-001-s639><call.rufen><en> Or call YouTube in the integrated Internet browser and see YouTube videos on your TV screen in HDTV quality.
<G-vec00092-001-s639><call.rufen><de> Oder rufen Sie YouTube in dem integrierten Internet-Browser auf und sehen Sie YouTube-Videos auf Ihrem TV-Bildschirm in HDTV-Qualität.
<G-vec00092-001-s640><call.rufen><en> Call today for a quote.
<G-vec00092-001-s640><call.rufen><de> Rufen Sie noch heute ein Angebot.
<G-vec00092-001-s641><call.rufen><en> Call the Australian Customs Service at tel.
<G-vec00092-001-s641><call.rufen><de> Rufen Sie den Australian Customs Service unter Tel..
<G-vec00092-001-s642><call.rufen><en> Call now for more information.
<G-vec00092-001-s642><call.rufen><de> Rufen Sie für weitere Informationen.
<G-vec00092-001-s643><call.rufen><en> Send a rental inquiry through fritiden.se or call the landlordUlf Linderbäck at 070-6069760.
<G-vec00092-001-s643><call.rufen><de> Schicken Sie eine Buchungsanfrage Ã1⁄4ber fritiden.se oder rufen Sie den VermieterUlf Linderbäck unter 070-6069760 an.
<G-vec00092-001-s644><call.rufen><en> Iberflora and all entities and associations that collaborate in the preparation of its parallel activities final details for its next edition, from 3 rd to 5 October at Feria Valencia in joint with EUROBRICO call, the International Salon of DIY.
<G-vec00092-001-s644><call.rufen><de> Iberflora und alle Entitäten und Zuordnungen, die Zusammenarbeit in der Vorbereitung seiner parallele Aktivitäten letzte Details für die nächste Ausgabe, die 3 zum 5 Rufen Sie Oktober Feria Valencia in Verbindung mit EUROBRICO, Internationaler Salon der DIY.
<G-vec00092-001-s645><call.rufen><en> Try our new “call me back” feature, to let your busy friends know you want them to call.
<G-vec00092-001-s645><call.rufen><de> Probieren Sie unsere neue „rufen Sie mich zurück“ -Funktion, lassen Sie Ihre beschäftigt Freunde wissen, dass Sie sie nennen wollen.
<G-vec00272-001-s627><call.rufen><en> Just call our customer service: +49 89 4161 430 70.
<G-vec00272-001-s627><call.rufen><de> Rufen Sie einfach unseren Kundenservice an: +49 89 4161 430 70.
<G-vec00272-001-s628><call.rufen><en> Call on the help of neighbors and create for your children a whole gaming complex together.
<G-vec00272-001-s628><call.rufen><de> Rufen Sie die Hilfe von Nachbarn an und schaffen Sie für Ihre Kinder einen ganzen Spielkomplex zusammen.
<G-vec00272-001-s629><call.rufen><en> This is why hiring our immigration law firm can greatly improve your chances of success in the immigration process, and in starting a new life in the U.S. No matter what your immigration status is, or your immigration plans are, call our firm at +1 (941) 362-7100.
<G-vec00272-001-s629><call.rufen><de> Dies is der Grund, unsere Einwanderungsanwaltskanzlei zu beauftragen, damit wir Ihre Chancen auf Erfolg in dem Einwanderungsprozess erheblich verbessern können, und Sie ein neues Leben in den USA zu beginnen können, ganz gleich was Ihr Aufenthaltsstatus ist, oder Ihre Einwanderungspläne sind, rufen Sie unsere Kanzlei unter +1 (941) 362-7100 an.
<G-vec00272-001-s630><call.rufen><en> Call diligently on his name.
<G-vec00272-001-s630><call.rufen><de> Rufen Sie bestndig seinen Namen an.
<G-vec00272-001-s631><call.rufen><en> Detailed specifications, CAD and datasheets can be found on our webstore, alternatively request a catalogue or call customer service for support in selecting the rightcomponent for your application.
<G-vec00272-001-s631><call.rufen><de> Detaillierte technische Daten, CAD-Zeichnungen und Datenblätter finden Sie unter Webstore, alternativ können Sie auch auf Anfrage Kataloge anfordern oder rufen Sie unseren Kundenservice an, um sich bei der Auswahl des richtigen Wartungsgerätes, für Ihre Anwendung, beraten zu lassen.
<G-vec00272-001-s632><call.rufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00272-001-s632><call.rufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00272-001-s633><call.rufen><en> If the problem persists, call Customer Service.
<G-vec00272-001-s633><call.rufen><de> Wenn das Problem anhält, rufen Sie den Kundendienst an.
<G-vec00272-001-s634><call.rufen><en> "Make sure your status - if in the next 15 minutes it will be a wet spot, immediately call the brigade ""first aid"" - doctors know exactly how to determine the leakage of amniotic fluid."
<G-vec00272-001-s634><call.rufen><de> Stellen Sie sicher, dass Ihr Status - wenn in den nächsten 15 Minuten wird es eine nasse Stelle sein, rufen Sie sofort die Brigade „Erste Hilfe“ - die Ärzte wissen genau, wie das Austreten von Fruchtwasser zu bestimmen.
<G-vec00272-001-s635><call.rufen><en> Call the plug-in with the command Effects -> AKVIS -> Retoucher.
<G-vec00272-001-s635><call.rufen><de> Rufen Sie das Plugin mit dem Befehl Effekte -> AKVIS -> Retoucher.
<G-vec00272-001-s636><call.rufen><en> Call now gladly advise free.
<G-vec00272-001-s636><call.rufen><de> Rufen Sie jetzt gerne beraten kostenlos.
<G-vec00272-001-s637><call.rufen><en> Call now to reserve one of our most popular rooms.
<G-vec00272-001-s637><call.rufen><de> Rufen Sie jetzt an, um eines unserer beliebtesten Zimmer reservieren.
<G-vec00272-001-s638><call.rufen><en> Favorites Call a user, meeting room or conference room system listed in your favorites.
<G-vec00272-001-s638><call.rufen><de> Favoriten Rufen Sie einen Benutzer, einen Konferenzraum oder ein Konferenzraumsystem an, das in Ihren Favoriten hinterlegt ist.
<G-vec00272-001-s639><call.rufen><en> Or call YouTube in the integrated Internet browser and see YouTube videos on your TV screen in HDTV quality.
<G-vec00272-001-s639><call.rufen><de> Oder rufen Sie YouTube in dem integrierten Internet-Browser auf und sehen Sie YouTube-Videos auf Ihrem TV-Bildschirm in HDTV-Qualität.
<G-vec00272-001-s640><call.rufen><en> Call today for a quote.
<G-vec00272-001-s640><call.rufen><de> Rufen Sie noch heute ein Angebot.
<G-vec00272-001-s641><call.rufen><en> Call the Australian Customs Service at tel.
<G-vec00272-001-s641><call.rufen><de> Rufen Sie den Australian Customs Service unter Tel..
<G-vec00272-001-s642><call.rufen><en> Call now for more information.
<G-vec00272-001-s642><call.rufen><de> Rufen Sie für weitere Informationen.
<G-vec00272-001-s643><call.rufen><en> Send a rental inquiry through fritiden.se or call the landlordUlf Linderbäck at 070-6069760.
<G-vec00272-001-s643><call.rufen><de> Schicken Sie eine Buchungsanfrage Ã1⁄4ber fritiden.se oder rufen Sie den VermieterUlf Linderbäck unter 070-6069760 an.
<G-vec00272-001-s644><call.rufen><en> Iberflora and all entities and associations that collaborate in the preparation of its parallel activities final details for its next edition, from 3 rd to 5 October at Feria Valencia in joint with EUROBRICO call, the International Salon of DIY.
<G-vec00272-001-s644><call.rufen><de> Iberflora und alle Entitäten und Zuordnungen, die Zusammenarbeit in der Vorbereitung seiner parallele Aktivitäten letzte Details für die nächste Ausgabe, die 3 zum 5 Rufen Sie Oktober Feria Valencia in Verbindung mit EUROBRICO, Internationaler Salon der DIY.
<G-vec00272-001-s645><call.rufen><en> Try our new “call me back” feature, to let your busy friends know you want them to call.
<G-vec00272-001-s645><call.rufen><de> Probieren Sie unsere neue „rufen Sie mich zurück“ -Funktion, lassen Sie Ihre beschäftigt Freunde wissen, dass Sie sie nennen wollen.
<G-vec00092-001-s646><call.rufen><en> The beginnings of evangelization on the South American continent always call to mind the Dominican land which was the first to receive the rich deposit of faith, which the missionaries brought with steadfast fidelity and proclaimed with constancy.
<G-vec00092-001-s646><call.rufen><de> Der Beginn der Evangelisierung auf dem amerikanischen Kontinent ruft stets die dominikanischen Inseln ins Gedächtnis, da sie als Erste das reiche Glaubensgut empfangen haben, das von den Missionaren treu überliefert und beharrlich verkündet wurde.
<G-vec00092-001-s647><call.rufen><en> Whether ye call them or are silent is all one for you.
<G-vec00092-001-s647><call.rufen><de> Es ist ganz gleich für euch, ob ihr sie ruft oder ob ihr schweigt.
<G-vec00092-001-s648><call.rufen><en> And in this vocation God did not call Abraham alone, as an individual, but involved from the start his family, his household and all those in service to his house.
<G-vec00092-001-s648><call.rufen><de> Und in dieser Berufung ruft Gott Abraham nicht allein, als Einzelnen, sondern er bezieht von Anfang an seine Familie, seine Verwandtschaft und alle ein, die im Dienst an seinem Haus stehen.
<G-vec00092-001-s649><call.rufen><en> Or they can call me in one of Lifesize's persistent virtual meeting rooms, and we can sit down and talk through the issues.
<G-vec00092-001-s649><call.rufen><de> Oder die Person ruft mich in einem der bestehenden virtuellen Konferenzräume von Lifesize an, sodass wir uns zusammensetzen und alles durchsprechen können.
<G-vec00092-001-s650><call.rufen><en> It should be personal because the presence of Christ among his people can most effectively be pointed to by the person ordained to proclaim the Gospel and to call the community to serve the Lord in unity of life and witness.
<G-vec00092-001-s650><call.rufen><de> Persönlich dadurch, daß auf die Präsenz Jesu Christi unter seinem Volk am wirksamsten durch eine Person hingewiesen werden kann, die ordiniert worden ist, um das Evangelium zu verkündigen, und die Gemeinschaft dazu ruft, dem Herrn in Einheit von Leben und Zeugnis zu dienen.
<G-vec00092-001-s651><call.rufen><en> For this reason - as I stressed in the same Message - the priest's mission is irreplaceable, and even if in some regions a scarcity of clergy is being recorded, we must never doubt that God continues to call boys, young men and adults to leave everything to dedicate themselves totally to preaching the Gospel and to the pastoral ministry (cf. Message for the World Day of Prayer for Vocations 2006, L'Osservatore Romano English edition, 12 April 2006, p. 5).
<G-vec00092-001-s651><call.rufen><de> Aus diesem Grund ist – wie ich in derselben Botschaft betont habe – die Sendung des Priesters unersetzlich, und auch wenn in manchen Gegenden ein Priestermangel festzustellen ist, darf man nicht daran zweifeln, daß Gott auch weiterhin Jungen, junge Männer und Erwachsene dazu ruft, alles zu verlassen, um sich der Predigt des Evangeliums und dem Pastoraldienst zu widmen.
<G-vec00092-001-s652><call.rufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00092-001-s652><call.rufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00092-001-s653><call.rufen><en> When you are before a person who seems to be spiritually receptive, call upon your brothers Michael and Monjoronson and ask for their peace and forgiveness to be seeded into that other persons being.
<G-vec00092-001-s653><call.rufen><de> Wenn ihr vor einer Person steht, die geistig empfänglich zu sein scheint, ruft eure Brüder Michael oder Monjoronson und bittet um ihren Frieden und ihre Vergebung, damit sie in das Wesen dieser anderen Personen gesät werden.
<G-vec00092-001-s654><call.rufen><en> Whenever you fall, call upon Jesus and seek Him in the Sacrament of Confession.
<G-vec00092-001-s654><call.rufen><de> Wenn es vorkommt dass ihr faellt, ruft nach Jesus und sucht Ihn im Sakrament der Beichte.
<G-vec00092-001-s655><call.rufen><en> Call down the Avatar of Form, the embodiment of psionic potential.
<G-vec00092-001-s655><call.rufen><de> Ruft den Avatar der Form, die Verkörperung psionischen Potenzials.
<G-vec00092-001-s656><call.rufen><en> "In the first place, he continues to call the Churches of so-called ""ancient tradition"", which in the past provided the missions with a consistent number of priests, men and women religious and lay people as well as material means, giving life to an effective cooperation between Christian communities."
<G-vec00092-001-s656><call.rufen><de> Er ruft weiterhin an erster Stelle die sogenannten Kirchen mit alter Tradition auf, die in der Vergangenheit außer materiellen Gütern auch eine ansehnliche Zahl an Priestern, Ordensmännern, Ordensfrauen und Laien zur Verfügung gestellt und auf diese Weise eine wirksame Zusammenarbeit zwischen den christlichen Gemeinden geschaffen haben.
<G-vec00092-001-s657><call.rufen><en> At about four in the afternoon we get a call from Chief of Section Tomas Pochop: “Guys, a convoy of police cars will be arriving after five. It would be worth taking a couple of pictures.”
<G-vec00092-001-s657><call.rufen><de> Um vier Uhr nachmittags ruft der Chef der Abteilung Tomáš Pochop an: „Jungs, nach fünf kommt eine Kolone von Polizeiwagen, das wäre ein Foto wert.“ Im Schneegestöber warte ich auf die Fahrzeuge der Polizei der Tschechischen Republik im neuen Design.
<G-vec00092-001-s658><call.rufen><en> If you have any problems, call us and we will help.
<G-vec00092-001-s658><call.rufen><de> Solltet ihr Schwierigkeiten haben, ruft uns an, und wir helfen euch gerne weiter.
<G-vec00092-001-s659><call.rufen><en> Then when He calls you with a [single] call from the earth, immediately you will come forth.
<G-vec00092-001-s659><call.rufen><de> Wenn Er euch hierauf ein (einziges Mal) ruft, da kommt ihr sogleich aus der Erde hervor.
<G-vec00092-001-s660><call.rufen><en> He hears but cannot answer to your call.
<G-vec00092-001-s660><call.rufen><de> Er hört, reagiert aber nicht, wenn man ihn ruft.
<G-vec00092-001-s661><call.rufen><en> She might not return a call, or she might make a snide or offensive comment when talking to you.
<G-vec00092-001-s661><call.rufen><de> Vielleicht ruft er nicht zurück oder macht bei einem eurer Gespräche eine höhnische oder beleidigende Anmerkung.
<G-vec00092-001-s662><call.rufen><en> Acknowledge their presence and call them to service on your behalf.
<G-vec00092-001-s662><call.rufen><de> Erkennt ihre Präsenz an und ruft sie in eurem Auftrag um Hilfestellung an.
<G-vec00092-001-s663><call.rufen><en> Call of Duty: Advanced Warfare is a military science fiction war thriller first-person shooter video game published by Activision.
<G-vec00092-001-s663><call.rufen><de> Die Pflicht ruft: Erweiterte Warfare ist ein Military Science Fiktion Krieg Thriller Ego-Shooter Videospiel von Activision veröffentlicht.
<G-vec00092-001-s664><call.rufen><en> The planned and brutal murder of a French priest is a call to wage religious war on many levels....
<G-vec00092-001-s664><call.rufen><de> Der geplante, brutale Mord an dem französischen Priester ruft in vielfältiger Weise zum Religionskrieg auf....
<G-vec00272-001-s646><call.rufen><en> The beginnings of evangelization on the South American continent always call to mind the Dominican land which was the first to receive the rich deposit of faith, which the missionaries brought with steadfast fidelity and proclaimed with constancy.
<G-vec00272-001-s646><call.rufen><de> Der Beginn der Evangelisierung auf dem amerikanischen Kontinent ruft stets die dominikanischen Inseln ins Gedächtnis, da sie als Erste das reiche Glaubensgut empfangen haben, das von den Missionaren treu überliefert und beharrlich verkündet wurde.
<G-vec00272-001-s647><call.rufen><en> Whether ye call them or are silent is all one for you.
<G-vec00272-001-s647><call.rufen><de> Es ist ganz gleich für euch, ob ihr sie ruft oder ob ihr schweigt.
<G-vec00272-001-s648><call.rufen><en> And in this vocation God did not call Abraham alone, as an individual, but involved from the start his family, his household and all those in service to his house.
<G-vec00272-001-s648><call.rufen><de> Und in dieser Berufung ruft Gott Abraham nicht allein, als Einzelnen, sondern er bezieht von Anfang an seine Familie, seine Verwandtschaft und alle ein, die im Dienst an seinem Haus stehen.
<G-vec00272-001-s649><call.rufen><en> Or they can call me in one of Lifesize's persistent virtual meeting rooms, and we can sit down and talk through the issues.
<G-vec00272-001-s649><call.rufen><de> Oder die Person ruft mich in einem der bestehenden virtuellen Konferenzräume von Lifesize an, sodass wir uns zusammensetzen und alles durchsprechen können.
<G-vec00272-001-s650><call.rufen><en> It should be personal because the presence of Christ among his people can most effectively be pointed to by the person ordained to proclaim the Gospel and to call the community to serve the Lord in unity of life and witness.
<G-vec00272-001-s650><call.rufen><de> Persönlich dadurch, daß auf die Präsenz Jesu Christi unter seinem Volk am wirksamsten durch eine Person hingewiesen werden kann, die ordiniert worden ist, um das Evangelium zu verkündigen, und die Gemeinschaft dazu ruft, dem Herrn in Einheit von Leben und Zeugnis zu dienen.
<G-vec00272-001-s651><call.rufen><en> For this reason - as I stressed in the same Message - the priest's mission is irreplaceable, and even if in some regions a scarcity of clergy is being recorded, we must never doubt that God continues to call boys, young men and adults to leave everything to dedicate themselves totally to preaching the Gospel and to the pastoral ministry (cf. Message for the World Day of Prayer for Vocations 2006, L'Osservatore Romano English edition, 12 April 2006, p. 5).
<G-vec00272-001-s651><call.rufen><de> Aus diesem Grund ist – wie ich in derselben Botschaft betont habe – die Sendung des Priesters unersetzlich, und auch wenn in manchen Gegenden ein Priestermangel festzustellen ist, darf man nicht daran zweifeln, daß Gott auch weiterhin Jungen, junge Männer und Erwachsene dazu ruft, alles zu verlassen, um sich der Predigt des Evangeliums und dem Pastoraldienst zu widmen.
<G-vec00272-001-s652><call.rufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00272-001-s652><call.rufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00272-001-s653><call.rufen><en> When you are before a person who seems to be spiritually receptive, call upon your brothers Michael and Monjoronson and ask for their peace and forgiveness to be seeded into that other persons being.
<G-vec00272-001-s653><call.rufen><de> Wenn ihr vor einer Person steht, die geistig empfänglich zu sein scheint, ruft eure Brüder Michael oder Monjoronson und bittet um ihren Frieden und ihre Vergebung, damit sie in das Wesen dieser anderen Personen gesät werden.
<G-vec00272-001-s654><call.rufen><en> Whenever you fall, call upon Jesus and seek Him in the Sacrament of Confession.
<G-vec00272-001-s654><call.rufen><de> Wenn es vorkommt dass ihr faellt, ruft nach Jesus und sucht Ihn im Sakrament der Beichte.
<G-vec00272-001-s655><call.rufen><en> Call down the Avatar of Form, the embodiment of psionic potential.
<G-vec00272-001-s655><call.rufen><de> Ruft den Avatar der Form, die Verkörperung psionischen Potenzials.
<G-vec00272-001-s656><call.rufen><en> "In the first place, he continues to call the Churches of so-called ""ancient tradition"", which in the past provided the missions with a consistent number of priests, men and women religious and lay people as well as material means, giving life to an effective cooperation between Christian communities."
<G-vec00272-001-s656><call.rufen><de> Er ruft weiterhin an erster Stelle die sogenannten Kirchen mit alter Tradition auf, die in der Vergangenheit außer materiellen Gütern auch eine ansehnliche Zahl an Priestern, Ordensmännern, Ordensfrauen und Laien zur Verfügung gestellt und auf diese Weise eine wirksame Zusammenarbeit zwischen den christlichen Gemeinden geschaffen haben.
<G-vec00272-001-s657><call.rufen><en> At about four in the afternoon we get a call from Chief of Section Tomas Pochop: “Guys, a convoy of police cars will be arriving after five. It would be worth taking a couple of pictures.”
<G-vec00272-001-s657><call.rufen><de> Um vier Uhr nachmittags ruft der Chef der Abteilung Tomáš Pochop an: „Jungs, nach fünf kommt eine Kolone von Polizeiwagen, das wäre ein Foto wert.“ Im Schneegestöber warte ich auf die Fahrzeuge der Polizei der Tschechischen Republik im neuen Design.
<G-vec00272-001-s658><call.rufen><en> If you have any problems, call us and we will help.
<G-vec00272-001-s658><call.rufen><de> Solltet ihr Schwierigkeiten haben, ruft uns an, und wir helfen euch gerne weiter.
<G-vec00272-001-s659><call.rufen><en> Then when He calls you with a [single] call from the earth, immediately you will come forth.
<G-vec00272-001-s659><call.rufen><de> Wenn Er euch hierauf ein (einziges Mal) ruft, da kommt ihr sogleich aus der Erde hervor.
<G-vec00272-001-s660><call.rufen><en> He hears but cannot answer to your call.
<G-vec00272-001-s660><call.rufen><de> Er hört, reagiert aber nicht, wenn man ihn ruft.
<G-vec00272-001-s661><call.rufen><en> She might not return a call, or she might make a snide or offensive comment when talking to you.
<G-vec00272-001-s661><call.rufen><de> Vielleicht ruft er nicht zurück oder macht bei einem eurer Gespräche eine höhnische oder beleidigende Anmerkung.
<G-vec00272-001-s662><call.rufen><en> Acknowledge their presence and call them to service on your behalf.
<G-vec00272-001-s662><call.rufen><de> Erkennt ihre Präsenz an und ruft sie in eurem Auftrag um Hilfestellung an.
<G-vec00272-001-s663><call.rufen><en> Call of Duty: Advanced Warfare is a military science fiction war thriller first-person shooter video game published by Activision.
<G-vec00272-001-s663><call.rufen><de> Die Pflicht ruft: Erweiterte Warfare ist ein Military Science Fiktion Krieg Thriller Ego-Shooter Videospiel von Activision veröffentlicht.
<G-vec00272-001-s664><call.rufen><en> The planned and brutal murder of a French priest is a call to wage religious war on many levels....
<G-vec00272-001-s664><call.rufen><de> Der geplante, brutale Mord an dem französischen Priester ruft in vielfältiger Weise zum Religionskrieg auf....
