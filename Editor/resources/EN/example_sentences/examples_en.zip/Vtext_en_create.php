<G-vec00001-001-s019><create.anlegen><en> For this reason, you can also create the product file line for this assembly in the product file of the plant.
<G-vec00001-001-s019><create.anlegen><de> Daher können Sie auch in der Produktakte der Anlage die Produktaktenposition für diese Baugruppe anlegen.
<G-vec00001-001-s020><create.anlegen><en> Farmers can also create flower strips that create additional habitats free of fertilizers and pesticides.
<G-vec00001-001-s020><create.anlegen><de> Landwirte können außerdem Blühstreifen anlegen, die zusätzliche Habitate frei von Düngemitteln und Pflanzenschutzmitteln schaffen.
<G-vec00001-001-s021><create.anlegen><en> It is also possible to create custom settings for your materials and to adjust existing parameters at any time.
<G-vec00001-001-s021><create.anlegen><de> Sie können jederzeit auch individuelle Einstellungen für Ihre Materialien anlegen und bestehende Parameter anpassen.
<G-vec00001-001-s022><create.anlegen><en> You can create various analysis variants for profit and loss statements.
<G-vec00001-001-s022><create.anlegen><de> Für Gewinn- und Verlustrechnungen können sie verschiedene Auswertungsvarianten anlegen.
<G-vec00001-001-s023><create.anlegen><en> Locating mobile devices can also pose a security risk: According to the BSI, cyber criminals can often combine these locations with other information they uncover to create a comprehensive profile of their victims' movements.
<G-vec00001-001-s023><create.anlegen><de> Abgehörte Gespräche Ein Sicherheitsrisiko geht auch von der Ortung mobiler Geräten aus: Cyberkriminelle könnten laut BSI in Kombination mit anderen ausgespähten Informationen ein umfassendes Bewegungsprofil des Opfers anlegen.
<G-vec00001-001-s024><create.anlegen><en> The function securities for a record type also apply to the storage of generally accessible information in the InfoGuide: For instance, a user can only store information about the window of a record type if he is authorized to use all editing functions (create, change and delete) of the program concerned.
<G-vec00001-001-s024><create.anlegen><de> Die Funktionsverriegelungen für eine Datensatzart gelten zudem für die Hinterlegung von allgemein zugänglichen Informationen im InfoGuide: So kann ein Benutzer solche Informationen zum Fenster einer Datensatzart nur dann hinterlegen, wenn für ihn alle Bearbeitungsfunktionen (Anlegen, Ändern und Löschen) zum betreffenden Programm freigegeben sind.
<G-vec00001-001-s025><create.anlegen><en> You can create as many folders and subfolders as you need, and all folders can contain files.
<G-vec00001-001-s025><create.anlegen><de> Sie können so viele Ordner und Unterordner anlegen, wie Sie benötigen, alle Ordner können Dateien enthalten.
<G-vec00001-001-s026><create.anlegen><en> In this case, you do not need to create a new project in Across, but can adjust the existing project instead.
<G-vec00001-001-s026><create.anlegen><de> Sie müssen in einem solchen Fall kein neues Projekt in Across anlegen, sondern können die nötigen Anpassun gen an dem bereits bestehenden Projekt vornehmen.
<G-vec00001-001-s027><create.anlegen><en> In order to use Kenhub you need to create an account (account).
<G-vec00001-001-s027><create.anlegen><de> Um Kenhub zu nutzen musst Du ein Nutzerkonto anlegen (Nutzerkonto, Konto).
<G-vec00001-001-s028><create.anlegen><en> 2.3 If you register to use any of the Recruiter Services you must create a password which, in order to prevent fraud, you must keep confidential.
<G-vec00001-001-s028><create.anlegen><de> 2.3 Wenn Sie sich für die Nutzung irgendeines Recruiter-Dienstes registrieren, müssen Sie ein Passwort anlegen, das sie geheim halten müssen, um Betrug zu verhindern.
<G-vec00001-001-s029><create.anlegen><en> "You are able to do this by using the ""create alias"" function in your institution/organisation's profile page of the Erasmus+ OLS Licence Management System."
<G-vec00001-001-s029><create.anlegen><de> Hierfür verwenden Sie die Option „Alias anlegen“ auf der Profilseite Ihrer Institution/Organisation im Erasmus+ OLS Lizenzmanagementsystem.
<G-vec00001-001-s030><create.anlegen><en> Please note that you need to have the appropriate rights in order to create a new relation.
<G-vec00001-001-s030><create.anlegen><de> Bitte beachten Sie, dass Sie über die entsprechenden Rechte verfügen müssen, um eine neue Relation anlegen zu können.
<G-vec00001-001-s031><create.anlegen><en> There is no charge for using the service, which is powered by a special software tool developed by the EBD Group. This allows users to create their own online profile and schedule meetings at the show in advance.
<G-vec00001-001-s031><create.anlegen><de> Grundlage dafür ist ein Software-Tool der EBD Group, mit dessen Hilfe die Nutzer eigene Profile anlegen und sich bereits im Vorfeld der Messe für Meetings in Hannover verabreden können.
<G-vec00001-001-s032><create.anlegen><en> Your real name is selected automatically when you create your Ancestry account.
<G-vec00001-001-s032><create.anlegen><de> Ihr richtiger Name wird automatisch ausgewählt, wenn Sie Ihr Ancestry-Konto anlegen.
<G-vec00001-001-s033><create.anlegen><en> If you know exactly what your form looks like, you will be able to create it very quickly.
<G-vec00001-001-s033><create.anlegen><de> Wenn du genau weisst, wie dein Formular aussieht, wirst du es sehr schnell anlegen können.
<G-vec00001-001-s034><create.anlegen><en> This link allows you to create a library account.
<G-vec00001-001-s034><create.anlegen><de> Bibliothekskonto anlegen Ihr Bibliothekskonto wird über diesen Link angelegt.
<G-vec00001-001-s035><create.anlegen><en> You can create as many e-mail addresses as you like with your domain name.
<G-vec00001-001-s035><create.anlegen><de> Sie können beliebig viele E-Mail-Adressen mit Ihrem Domainnamen anlegen.
<G-vec00001-001-s036><create.anlegen><en> For the data output on paper, you have to create control codes for the output devices.
<G-vec00001-001-s036><create.anlegen><de> Für die Datenausgabe auf Papier müssen Sie Steuercodes für die Ausgabegeräte anlegen.
<G-vec00001-001-s037><create.anlegen><en> The starting point is the model wizard where you can create machines or feeders.
<G-vec00001-001-s037><create.anlegen><de> Ausgangspunkt ist immer der Modell-Assistent, in dem Maschinen oder Feeder anlegen werden können.
<G-vec00179-001-s019><create.anlegen><en> For this reason, you can also create the product file line for this assembly in the product file of the plant.
<G-vec00179-001-s019><create.anlegen><de> Daher können Sie auch in der Produktakte der Anlage die Produktaktenposition für diese Baugruppe anlegen.
<G-vec00179-001-s020><create.anlegen><en> Farmers can also create flower strips that create additional habitats free of fertilizers and pesticides.
<G-vec00179-001-s020><create.anlegen><de> Landwirte können außerdem Blühstreifen anlegen, die zusätzliche Habitate frei von Düngemitteln und Pflanzenschutzmitteln schaffen.
<G-vec00179-001-s021><create.anlegen><en> It is also possible to create custom settings for your materials and to adjust existing parameters at any time.
<G-vec00179-001-s021><create.anlegen><de> Sie können jederzeit auch individuelle Einstellungen für Ihre Materialien anlegen und bestehende Parameter anpassen.
<G-vec00179-001-s022><create.anlegen><en> You can create various analysis variants for profit and loss statements.
<G-vec00179-001-s022><create.anlegen><de> Für Gewinn- und Verlustrechnungen können sie verschiedene Auswertungsvarianten anlegen.
<G-vec00179-001-s023><create.anlegen><en> Locating mobile devices can also pose a security risk: According to the BSI, cyber criminals can often combine these locations with other information they uncover to create a comprehensive profile of their victims' movements.
<G-vec00179-001-s023><create.anlegen><de> Abgehörte Gespräche Ein Sicherheitsrisiko geht auch von der Ortung mobiler Geräten aus: Cyberkriminelle könnten laut BSI in Kombination mit anderen ausgespähten Informationen ein umfassendes Bewegungsprofil des Opfers anlegen.
<G-vec00179-001-s024><create.anlegen><en> The function securities for a record type also apply to the storage of generally accessible information in the InfoGuide: For instance, a user can only store information about the window of a record type if he is authorized to use all editing functions (create, change and delete) of the program concerned.
<G-vec00179-001-s024><create.anlegen><de> Die Funktionsverriegelungen für eine Datensatzart gelten zudem für die Hinterlegung von allgemein zugänglichen Informationen im InfoGuide: So kann ein Benutzer solche Informationen zum Fenster einer Datensatzart nur dann hinterlegen, wenn für ihn alle Bearbeitungsfunktionen (Anlegen, Ändern und Löschen) zum betreffenden Programm freigegeben sind.
<G-vec00179-001-s025><create.anlegen><en> You can create as many folders and subfolders as you need, and all folders can contain files.
<G-vec00179-001-s025><create.anlegen><de> Sie können so viele Ordner und Unterordner anlegen, wie Sie benötigen, alle Ordner können Dateien enthalten.
<G-vec00179-001-s026><create.anlegen><en> In this case, you do not need to create a new project in Across, but can adjust the existing project instead.
<G-vec00179-001-s026><create.anlegen><de> Sie müssen in einem solchen Fall kein neues Projekt in Across anlegen, sondern können die nötigen Anpassun gen an dem bereits bestehenden Projekt vornehmen.
<G-vec00179-001-s027><create.anlegen><en> In order to use Kenhub you need to create an account (account).
<G-vec00179-001-s027><create.anlegen><de> Um Kenhub zu nutzen musst Du ein Nutzerkonto anlegen (Nutzerkonto, Konto).
<G-vec00179-001-s028><create.anlegen><en> 2.3 If you register to use any of the Recruiter Services you must create a password which, in order to prevent fraud, you must keep confidential.
<G-vec00179-001-s028><create.anlegen><de> 2.3 Wenn Sie sich für die Nutzung irgendeines Recruiter-Dienstes registrieren, müssen Sie ein Passwort anlegen, das sie geheim halten müssen, um Betrug zu verhindern.
<G-vec00179-001-s029><create.anlegen><en> "You are able to do this by using the ""create alias"" function in your institution/organisation's profile page of the Erasmus+ OLS Licence Management System."
<G-vec00179-001-s029><create.anlegen><de> Hierfür verwenden Sie die Option „Alias anlegen“ auf der Profilseite Ihrer Institution/Organisation im Erasmus+ OLS Lizenzmanagementsystem.
<G-vec00179-001-s030><create.anlegen><en> Please note that you need to have the appropriate rights in order to create a new relation.
<G-vec00179-001-s030><create.anlegen><de> Bitte beachten Sie, dass Sie über die entsprechenden Rechte verfügen müssen, um eine neue Relation anlegen zu können.
<G-vec00179-001-s031><create.anlegen><en> There is no charge for using the service, which is powered by a special software tool developed by the EBD Group. This allows users to create their own online profile and schedule meetings at the show in advance.
<G-vec00179-001-s031><create.anlegen><de> Grundlage dafür ist ein Software-Tool der EBD Group, mit dessen Hilfe die Nutzer eigene Profile anlegen und sich bereits im Vorfeld der Messe für Meetings in Hannover verabreden können.
<G-vec00179-001-s032><create.anlegen><en> Your real name is selected automatically when you create your Ancestry account.
<G-vec00179-001-s032><create.anlegen><de> Ihr richtiger Name wird automatisch ausgewählt, wenn Sie Ihr Ancestry-Konto anlegen.
<G-vec00179-001-s033><create.anlegen><en> If you know exactly what your form looks like, you will be able to create it very quickly.
<G-vec00179-001-s033><create.anlegen><de> Wenn du genau weisst, wie dein Formular aussieht, wirst du es sehr schnell anlegen können.
<G-vec00179-001-s034><create.anlegen><en> This link allows you to create a library account.
<G-vec00179-001-s034><create.anlegen><de> Bibliothekskonto anlegen Ihr Bibliothekskonto wird über diesen Link angelegt.
<G-vec00179-001-s035><create.anlegen><en> You can create as many e-mail addresses as you like with your domain name.
<G-vec00179-001-s035><create.anlegen><de> Sie können beliebig viele E-Mail-Adressen mit Ihrem Domainnamen anlegen.
<G-vec00179-001-s036><create.anlegen><en> For the data output on paper, you have to create control codes for the output devices.
<G-vec00179-001-s036><create.anlegen><de> Für die Datenausgabe auf Papier müssen Sie Steuercodes für die Ausgabegeräte anlegen.
<G-vec00179-001-s037><create.anlegen><en> The starting point is the model wizard where you can create machines or feeders.
<G-vec00179-001-s037><create.anlegen><de> Ausgangspunkt ist immer der Modell-Assistent, in dem Maschinen oder Feeder anlegen werden können.
<G-vec00001-001-s038><create.anlegen><en> This helps to create the user in the simplest way new components to create programs and to use the most diverse Optimizer.
<G-vec00001-001-s038><create.anlegen><de> Dies hilft dem Bediener auf einfachste Weise neue Bauteile anzulegen, Programme zu erstellen und die vielfältigsten Optimierungstools zu verwenden.
<G-vec00001-001-s039><create.anlegen><en> Description This extension provides for all methods in the shop two charges modules, which makes it possible to create various commissions and fees.
<G-vec00001-001-s039><create.anlegen><de> Beschreibung Diese Erweiterung stellt für alle Zahlungsarten im Shop zwei Gebührenmodule zur Verfügung, die es möglich macht, verschiedene Provisionen und Gebühren anzulegen.
<G-vec00001-001-s040><create.anlegen><en> For this reason it is necessary to create a new account.
<G-vec00001-001-s040><create.anlegen><de> Aus diesem Grund ist es nötig ein neues Konto anzulegen.
<G-vec00001-001-s041><create.anlegen><en> The third stage (edit) allows the user to edit existing groups, and create new ones.
<G-vec00001-001-s041><create.anlegen><de> Die dritte Stufe (Bearbeiten) erlaubt dem Benutzer, bestehende Gruppen zu bearbeiten und neue Gruppen anzulegen.
<G-vec00001-001-s042><create.anlegen><en> The first error is thrown if there are too many threads in the JVM and there is not enough memory left to create a new thread.
<G-vec00001-001-s042><create.anlegen><de> Der erste Fehler wird geworfen, wenn zu viele Threads innerhalb der JVM bestehen und nicht mehr genug Speicher zur Verfügung steht, um einen neuen nativen Thread anzulegen.
<G-vec00001-001-s043><create.anlegen><en> Please click „Register now“ to create a new account.
<G-vec00001-001-s043><create.anlegen><de> Klicken Sie einfach auf „Registrieren“ um ein neues Konto anzulegen.
<G-vec00001-001-s044><create.anlegen><en> Amongst these features are the possibility to create projects and to work on several different scripts at once, a script compiler making you aware of possible errors while you write your scripts, a 'find & replace function' allowing you to replace every instance of a given variable in moments, and many more.
<G-vec00001-001-s044><create.anlegen><de> "Unter anderen zählen hierzu die Möglichkeit, Projekte anzulegen und an mehreren Scripten gleichzeitig zu arbeiten, ein Script-Compiler, der Dir Fehler bereits während des Schreibens der Scripte anzeigt, sowie eine ""Suche und Ersetze""-Funktion, die es ermöglicht, jede Instanz einer Variablen in wenigen Augenblicken zu ersetzen."
<G-vec00001-001-s045><create.anlegen><en> To create a new mailing, click Create .
<G-vec00001-001-s045><create.anlegen><de> Klicken Sie auf Neu, um ein neues Mailing anzulegen.
<G-vec00001-001-s046><create.anlegen><en> Anmerkung: You need the permissions for the Public Spot Wizard, in order to create a new Public Spot user.
<G-vec00001-001-s046><create.anlegen><de> Anmerkung: Sie benötigen das Zugriffsrecht Public-Spot-Assistent (Benutzer anlegen), um einen neuen Public Spot-Benutzer anzulegen.
<G-vec00001-001-s047><create.anlegen><en> CIROS® Education offers all functions of CIROS® Studio, minus the capability to create new models or connect robot control systems.
<G-vec00001-001-s047><create.anlegen><de> CIROS® Education bietet alle Funktionen von CIROS® Studio ohne die Möglichkeiten neue Modelle anzulegen und Robotersteuerungen anzubinden.
<G-vec00001-001-s048><create.anlegen><en> The JUWEL terraces allow you to create varied aquarium floor levels easy and permanently, thereby creating an extraordinary illusion of depth.
<G-vec00001-001-s048><create.anlegen><de> Die JUWEL Terrassen ermöglichen es Ihnen den Bodengrund einfach und dauerhaft in verschiedenen Ebenen anzulegen und erzeugen so eine außerordentliche Tiefenwirkung.
<G-vec00001-001-s049><create.anlegen><en> And we've reached our goal to protect and create enough sustainably managed forests around the world to cover our current paper use and produce fibre for generations.
<G-vec00001-001-s049><create.anlegen><de> Und wir haben unser Ziel erreicht, so viele nachhaltig bewirtschaftete Wälder zu schützen und neu anzulegen, wie wir brauchen, um unseren aktuellen Papierbedarf zu decken und Holzfasern für weitere Generationen zu erzeugen.
<G-vec00001-001-s050><create.anlegen><en> Enter your e-mail address to create your account.
<G-vec00001-001-s050><create.anlegen><de> Geben Sie Ihre E-Mail-Adresse an um ein Konto anzulegen.
<G-vec00001-001-s051><create.anlegen><en> mod_dav_svn, however, can come to your aid. By activating an “ operational logging ” feature, you can ask mod_dav_svn to create a separate log file describing what sort of high-level operations your clients are performing.
<G-vec00001-001-s051><create.anlegen><de> Durch die Aktivierung einer „ operativen Protokollierung “ können Sie mod_dav_svn veranlassen, eine gesonderte Protokolldatei anzulegen, die festhält, welche Art von Funktionen Ihre Clients auf höherer Ebene ausführen.
<G-vec00001-001-s052><create.anlegen><en> "It was not possible to create a ""Favorites"" folder via the context menu (right mouse): this is now solved."
<G-vec00001-001-s052><create.anlegen><de> "Es war nicht möglich ""Favoriten"" Ordner innerhalb des Kontextmenüs (rechte Maus) anzulegen, das Problem ist gelöst."
<G-vec00001-001-s053><create.anlegen><en> "Click on ""Add"" to create a new manufacturer."
<G-vec00001-001-s053><create.anlegen><de> "Klicke auf ""Hinzufügen"", um einen neuen Hersteller anzulegen."
<G-vec00001-001-s054><create.anlegen><en> We encourage you to to create a user account when registering (you register either before or during the ordering process).
<G-vec00001-001-s054><create.anlegen><de> Wir empfehlen Ihnen, bei der Registrierung (die wahlweise vor oder während des Bestellvorganges erfolgt) ein Benutzerkonto anzulegen.
<G-vec00001-001-s055><create.anlegen><en> For example, when creating a Layout Specification, you can click this button on the Spot Color Resource to create additional spot colors.
<G-vec00001-001-s055><create.anlegen><de> Wenn Sie beispielsweise eine Layoutspezifikation erstellen, können Sie auf die zur Ressource Volltonfarbe gehörende Schaltfläche klicken, um weitere Volltonfarben anzulegen.
<G-vec00001-001-s056><create.anlegen><en> It also allows the user to create new files and folders.
<G-vec00001-001-s056><create.anlegen><de> Ebenfalls ist es möglich, neue Dateien und Ordner anzulegen.
<G-vec00179-001-s038><create.anlegen><en> This helps to create the user in the simplest way new components to create programs and to use the most diverse Optimizer.
<G-vec00179-001-s038><create.anlegen><de> Dies hilft dem Bediener auf einfachste Weise neue Bauteile anzulegen, Programme zu erstellen und die vielfältigsten Optimierungstools zu verwenden.
<G-vec00179-001-s039><create.anlegen><en> Description This extension provides for all methods in the shop two charges modules, which makes it possible to create various commissions and fees.
<G-vec00179-001-s039><create.anlegen><de> Beschreibung Diese Erweiterung stellt für alle Zahlungsarten im Shop zwei Gebührenmodule zur Verfügung, die es möglich macht, verschiedene Provisionen und Gebühren anzulegen.
<G-vec00179-001-s040><create.anlegen><en> For this reason it is necessary to create a new account.
<G-vec00179-001-s040><create.anlegen><de> Aus diesem Grund ist es nötig ein neues Konto anzulegen.
<G-vec00179-001-s041><create.anlegen><en> The third stage (edit) allows the user to edit existing groups, and create new ones.
<G-vec00179-001-s041><create.anlegen><de> Die dritte Stufe (Bearbeiten) erlaubt dem Benutzer, bestehende Gruppen zu bearbeiten und neue Gruppen anzulegen.
<G-vec00179-001-s042><create.anlegen><en> The first error is thrown if there are too many threads in the JVM and there is not enough memory left to create a new thread.
<G-vec00179-001-s042><create.anlegen><de> Der erste Fehler wird geworfen, wenn zu viele Threads innerhalb der JVM bestehen und nicht mehr genug Speicher zur Verfügung steht, um einen neuen nativen Thread anzulegen.
<G-vec00179-001-s043><create.anlegen><en> Please click „Register now“ to create a new account.
<G-vec00179-001-s043><create.anlegen><de> Klicken Sie einfach auf „Registrieren“ um ein neues Konto anzulegen.
<G-vec00179-001-s044><create.anlegen><en> Amongst these features are the possibility to create projects and to work on several different scripts at once, a script compiler making you aware of possible errors while you write your scripts, a 'find & replace function' allowing you to replace every instance of a given variable in moments, and many more.
<G-vec00179-001-s044><create.anlegen><de> "Unter anderen zählen hierzu die Möglichkeit, Projekte anzulegen und an mehreren Scripten gleichzeitig zu arbeiten, ein Script-Compiler, der Dir Fehler bereits während des Schreibens der Scripte anzeigt, sowie eine ""Suche und Ersetze""-Funktion, die es ermöglicht, jede Instanz einer Variablen in wenigen Augenblicken zu ersetzen."
<G-vec00179-001-s045><create.anlegen><en> To create a new mailing, click Create .
<G-vec00179-001-s045><create.anlegen><de> Klicken Sie auf Neu, um ein neues Mailing anzulegen.
<G-vec00179-001-s046><create.anlegen><en> Anmerkung: You need the permissions for the Public Spot Wizard, in order to create a new Public Spot user.
<G-vec00179-001-s046><create.anlegen><de> Anmerkung: Sie benötigen das Zugriffsrecht Public-Spot-Assistent (Benutzer anlegen), um einen neuen Public Spot-Benutzer anzulegen.
<G-vec00179-001-s047><create.anlegen><en> CIROS® Education offers all functions of CIROS® Studio, minus the capability to create new models or connect robot control systems.
<G-vec00179-001-s047><create.anlegen><de> CIROS® Education bietet alle Funktionen von CIROS® Studio ohne die Möglichkeiten neue Modelle anzulegen und Robotersteuerungen anzubinden.
<G-vec00179-001-s048><create.anlegen><en> The JUWEL terraces allow you to create varied aquarium floor levels easy and permanently, thereby creating an extraordinary illusion of depth.
<G-vec00179-001-s048><create.anlegen><de> Die JUWEL Terrassen ermöglichen es Ihnen den Bodengrund einfach und dauerhaft in verschiedenen Ebenen anzulegen und erzeugen so eine außerordentliche Tiefenwirkung.
<G-vec00179-001-s049><create.anlegen><en> And we've reached our goal to protect and create enough sustainably managed forests around the world to cover our current paper use and produce fibre for generations.
<G-vec00179-001-s049><create.anlegen><de> Und wir haben unser Ziel erreicht, so viele nachhaltig bewirtschaftete Wälder zu schützen und neu anzulegen, wie wir brauchen, um unseren aktuellen Papierbedarf zu decken und Holzfasern für weitere Generationen zu erzeugen.
<G-vec00179-001-s050><create.anlegen><en> Enter your e-mail address to create your account.
<G-vec00179-001-s050><create.anlegen><de> Geben Sie Ihre E-Mail-Adresse an um ein Konto anzulegen.
<G-vec00179-001-s051><create.anlegen><en> mod_dav_svn, however, can come to your aid. By activating an “ operational logging ” feature, you can ask mod_dav_svn to create a separate log file describing what sort of high-level operations your clients are performing.
<G-vec00179-001-s051><create.anlegen><de> Durch die Aktivierung einer „ operativen Protokollierung “ können Sie mod_dav_svn veranlassen, eine gesonderte Protokolldatei anzulegen, die festhält, welche Art von Funktionen Ihre Clients auf höherer Ebene ausführen.
<G-vec00179-001-s052><create.anlegen><en> "It was not possible to create a ""Favorites"" folder via the context menu (right mouse): this is now solved."
<G-vec00179-001-s052><create.anlegen><de> "Es war nicht möglich ""Favoriten"" Ordner innerhalb des Kontextmenüs (rechte Maus) anzulegen, das Problem ist gelöst."
<G-vec00179-001-s053><create.anlegen><en> "Click on ""Add"" to create a new manufacturer."
<G-vec00179-001-s053><create.anlegen><de> "Klicke auf ""Hinzufügen"", um einen neuen Hersteller anzulegen."
<G-vec00179-001-s054><create.anlegen><en> We encourage you to to create a user account when registering (you register either before or during the ordering process).
<G-vec00179-001-s054><create.anlegen><de> Wir empfehlen Ihnen, bei der Registrierung (die wahlweise vor oder während des Bestellvorganges erfolgt) ein Benutzerkonto anzulegen.
<G-vec00179-001-s055><create.anlegen><en> For example, when creating a Layout Specification, you can click this button on the Spot Color Resource to create additional spot colors.
<G-vec00179-001-s055><create.anlegen><de> Wenn Sie beispielsweise eine Layoutspezifikation erstellen, können Sie auf die zur Ressource Volltonfarbe gehörende Schaltfläche klicken, um weitere Volltonfarben anzulegen.
<G-vec00179-001-s056><create.anlegen><en> It also allows the user to create new files and folders.
<G-vec00179-001-s056><create.anlegen><de> Ebenfalls ist es möglich, neue Dateien und Ordner anzulegen.
<G-vec00001-001-s057><create.bilden><en> Its bezel features 36 sparkling CRYSTALLIZED Swarovski elements in blue and green, which create a striking contrast to the anthracite-coloured stainless-steel case.
<G-vec00001-001-s057><create.bilden><de> Auf ihrer Lünette funkeln 36 CRYSTALLIZEDTM Swarovski-Elemente in Blau und Grau und bilden einen auffälligen Kontrast zum anthrazitfarbenen Edelstahlgehäuse.
<G-vec00001-001-s058><create.bilden><en> In the stream there are lots of stones and boulders and they create a small waterfall.
<G-vec00001-001-s058><create.bilden><de> Im Bach sind viele Steine, die kleine Wasserfalle bilden.
<G-vec00001-001-s059><create.bilden><en> The interior isinthe European minimalism style consisting ofglass and wood, which, combined with bright accessories and warm coloured light coming from large false windows create incredibly comfortable and harmonious atmosphere.
<G-vec00001-001-s059><create.bilden><de> Das Interieur ist imStil des europäischen Minimalismus ausgeführt— Glas und Holz, inKombination mit hervorragenden Zubehörteilen und warmem buntem Licht aus den großen Falschfenstern, bilden ein unglaublich gemütliches und harmonisches Ambiente.
<G-vec00001-001-s060><create.bilden><en> The walls are preserved to this day and they create the shape of a pentagon with 3 main gates which lead to the interior of the castle.
<G-vec00001-001-s060><create.bilden><de> Die Wände sind noch heute erhalten und bilden ein Pentagon mit 3 Haupttore, die zum Inneren der Burg führen.
<G-vec00001-001-s061><create.bilden><en> 6 Summary Combos are combinations of individual cards that create a certain starting hand .
<G-vec00001-001-s061><create.bilden><de> 6 Zusammenfassung Kombos sind Kombinationen einzelner Karten, die eine bestimmte Starthand bilden .
<G-vec00001-001-s062><create.bilden><en> The hotel offers professionalism and cordiality, which combine to create an ideal atmosphere for those who wish to spend their vacation in a young and modern atmosphere.
<G-vec00001-001-s062><create.bilden><de> Das Hotel bietet Professionalität und Herzlichkeit, die zusammen eine ideale Atmosphäre bilden für Gäste, die ihren Urlaub in einer jungen und modernen Umgebung verbringen wollen.
<G-vec00001-001-s063><create.bilden><en> These valuable buildings with their simple interiors and artistically decorated wooden churches – the most beutiful works of folk art today create the basis of The Museum of Orava Village in Zuberec.
<G-vec00001-001-s063><create.bilden><de> Diese wertvolle Bauwerke mit ihren einfachen Innenräumen und künstlich gemalte Holzkirchen - die schönsten Werke der Volkskultur, bilden heute die Grundlage des Museums der Oravaer Dorfes in Zuberec.
<G-vec00001-001-s064><create.bilden><en> Each year we create financial reserves for recultivations that are kept on aseparated account.
<G-vec00001-001-s064><create.bilden><de> Jedes Jahr bilden wir finanzielle Rückstellungen zu Rekultivierungen die auf einem getrennten Konto erfasst werden.
<G-vec00001-001-s065><create.bilden><en> Parts of a tantra massage create various touches, soft and dynamic ones.
<G-vec00001-001-s065><create.bilden><de> Einen Bestandteil der Tantra-Massage bilden Berührungen verschiedenster Art, von sanften bis zu dynamischen.
<G-vec00001-001-s066><create.bilden><en> The countryside around and modern technologies allowed to create good conditions for health children development.
<G-vec00001-001-s066><create.bilden><de> Die Rundnatur und moderne Technologie erlaubte perfekte Bedingungen für die Unterstützung der gesunden Entwicklung der Kinder zu bilden.
<G-vec00001-001-s067><create.bilden><en> Titan, the propeller machine, and Eos, the snow lance, together with the surrounding mountain landscape, create a perfect symbiosis, one which also projects the company's vision: snow guns going way beyond their limits and being part of a global project, which, given its strong identity and originality, embraces the entire environment.
<G-vec00001-001-s067><create.bilden><de> Die Propellermaschine Titan und die Schneilanze Eos bilden zusammen mit der umliegenden Berglandschaft die perfekte Symbiose, welche zusätzlich die Vision des Unternehmens mit einschließt: die Schneeerzeuger überschreiten ihre eigentlichen Grenzen und werden Teil eines globalen Projektes, welches durch seine starke Identität und Eigenständigkeit die gesamte Umgebung mit einbringt.
<G-vec00001-001-s068><create.bilden><en> Beginning with a black square, the two actors create forms from various different elements that quote Russian Constructivist motifs, such as Kazimir Malevich’s iconic Black Square on a White Background (1915).
<G-vec00001-001-s068><create.bilden><de> Beginnend mit einem schwarzen Quadrat bilden die beiden Akteure aus verschiedenen Elementen Formen, die Motive des russischen Konstruktivismus zitieren – etwa Kasimir Malewitschs ikonisches Schwarzes Quadrat auf weißem Grund (1915).
<G-vec00001-001-s069><create.bilden><en> The bright stonewalls create a simple and genuine architecture, two of the main qualities featuring the life of the Benedictine nuns, who have lived in this building for centuries, meditating and taking care of the amazing nature of Bergamo’s hills.
<G-vec00001-001-s069><create.bilden><de> Die blassen Steinmauern bilden eine einfache und aufrichtige Architektur, zwei Eigenschaften, die das Leben von den Benediktinerinnen, die religiösen Frauen, die seit Jahrhunderten dieses Gebäude bewohnen, zwischen religiöser Meditation und Pflege der schönen Natur von den Hügeln von Bergamo, kennzeichnen.
<G-vec00001-001-s070><create.bilden><en> The increasing circulation of people, goods, and data create new cultural, social, and virtual landscapes, which can not be described by traditional geo-scientific categories.
<G-vec00001-001-s070><create.bilden><de> Die Zirkulation von Menschen, Daten und Gütern bilden neue kulturelle, soziale und virtuelle Landschaften, die sich wiederum materiell im Terrain niederschreiben.
<G-vec00001-001-s071><create.bilden><en> The PIXEL Tower comprises a basic set of PIXEL Boxes, Pods, Tops, Trays and Pads which can serve to create a variety of settings.
<G-vec00001-001-s071><create.bilden><de> Der PIXEL Tower umfasst ein Basis-Set an PIXEL Boxen, Pods, Tops, Trays und Pads aus dem sich eine Vielzahl an Settings bilden lassen.
<G-vec00001-001-s072><create.bilden><en> Leading motive of our activities is to create in subconsciousness of our clients feeling of respectable and professional security service that listens to them, understands their needs and requirements and together with them looks for the most effective solutions of security risks for guarded objects.
<G-vec00001-001-s072><create.bilden><de> Leitmotiv unserer Tätigkeit ist, in Unterbewusstsein unserer Kunden das Gefühl der seriösen und prefessionellen Sicherheitsagentur zu bilden, die ihnen zuhört, ihre Bedürfnisse und Anforderungen versteht, und zusammen mit ihnen die effektivsten Lösungen sucht.
<G-vec00001-001-s073><create.bilden><en> Since palms create new leaves from above, you can remove (old) leaves from below.
<G-vec00001-001-s073><create.bilden><de> Da Palmen von oben neue Blätter bilden, können Sie (alte) Blätter von unten entfernen.
<G-vec00001-001-s074><create.bilden><en> In combination, these items of furniture create micro architectural islands in the room.
<G-vec00001-001-s074><create.bilden><de> In Kombination bilden die Möbel mikroarchitektonische Inseln im Raum.
<G-vec00001-001-s075><create.bilden><en> We create and implement the latest solutions, optimising the processes related to our services.
<G-vec00001-001-s075><create.bilden><de> Wir bilden und leiten die neusten optimierenden Prozesse ein, die mit unseren Diensten verbunden sind.
<G-vec00179-001-s057><create.bilden><en> Its bezel features 36 sparkling CRYSTALLIZED Swarovski elements in blue and green, which create a striking contrast to the anthracite-coloured stainless-steel case.
<G-vec00179-001-s057><create.bilden><de> Auf ihrer Lünette funkeln 36 CRYSTALLIZEDTM Swarovski-Elemente in Blau und Grau und bilden einen auffälligen Kontrast zum anthrazitfarbenen Edelstahlgehäuse.
<G-vec00179-001-s058><create.bilden><en> In the stream there are lots of stones and boulders and they create a small waterfall.
<G-vec00179-001-s058><create.bilden><de> Im Bach sind viele Steine, die kleine Wasserfalle bilden.
<G-vec00179-001-s059><create.bilden><en> The interior isinthe European minimalism style consisting ofglass and wood, which, combined with bright accessories and warm coloured light coming from large false windows create incredibly comfortable and harmonious atmosphere.
<G-vec00179-001-s059><create.bilden><de> Das Interieur ist imStil des europäischen Minimalismus ausgeführt— Glas und Holz, inKombination mit hervorragenden Zubehörteilen und warmem buntem Licht aus den großen Falschfenstern, bilden ein unglaublich gemütliches und harmonisches Ambiente.
<G-vec00179-001-s060><create.bilden><en> The walls are preserved to this day and they create the shape of a pentagon with 3 main gates which lead to the interior of the castle.
<G-vec00179-001-s060><create.bilden><de> Die Wände sind noch heute erhalten und bilden ein Pentagon mit 3 Haupttore, die zum Inneren der Burg führen.
<G-vec00179-001-s061><create.bilden><en> 6 Summary Combos are combinations of individual cards that create a certain starting hand .
<G-vec00179-001-s061><create.bilden><de> 6 Zusammenfassung Kombos sind Kombinationen einzelner Karten, die eine bestimmte Starthand bilden .
<G-vec00179-001-s062><create.bilden><en> The hotel offers professionalism and cordiality, which combine to create an ideal atmosphere for those who wish to spend their vacation in a young and modern atmosphere.
<G-vec00179-001-s062><create.bilden><de> Das Hotel bietet Professionalität und Herzlichkeit, die zusammen eine ideale Atmosphäre bilden für Gäste, die ihren Urlaub in einer jungen und modernen Umgebung verbringen wollen.
<G-vec00179-001-s063><create.bilden><en> These valuable buildings with their simple interiors and artistically decorated wooden churches – the most beutiful works of folk art today create the basis of The Museum of Orava Village in Zuberec.
<G-vec00179-001-s063><create.bilden><de> Diese wertvolle Bauwerke mit ihren einfachen Innenräumen und künstlich gemalte Holzkirchen - die schönsten Werke der Volkskultur, bilden heute die Grundlage des Museums der Oravaer Dorfes in Zuberec.
<G-vec00179-001-s064><create.bilden><en> Each year we create financial reserves for recultivations that are kept on aseparated account.
<G-vec00179-001-s064><create.bilden><de> Jedes Jahr bilden wir finanzielle Rückstellungen zu Rekultivierungen die auf einem getrennten Konto erfasst werden.
<G-vec00179-001-s065><create.bilden><en> Parts of a tantra massage create various touches, soft and dynamic ones.
<G-vec00179-001-s065><create.bilden><de> Einen Bestandteil der Tantra-Massage bilden Berührungen verschiedenster Art, von sanften bis zu dynamischen.
<G-vec00179-001-s066><create.bilden><en> The countryside around and modern technologies allowed to create good conditions for health children development.
<G-vec00179-001-s066><create.bilden><de> Die Rundnatur und moderne Technologie erlaubte perfekte Bedingungen für die Unterstützung der gesunden Entwicklung der Kinder zu bilden.
<G-vec00179-001-s067><create.bilden><en> Titan, the propeller machine, and Eos, the snow lance, together with the surrounding mountain landscape, create a perfect symbiosis, one which also projects the company's vision: snow guns going way beyond their limits and being part of a global project, which, given its strong identity and originality, embraces the entire environment.
<G-vec00179-001-s067><create.bilden><de> Die Propellermaschine Titan und die Schneilanze Eos bilden zusammen mit der umliegenden Berglandschaft die perfekte Symbiose, welche zusätzlich die Vision des Unternehmens mit einschließt: die Schneeerzeuger überschreiten ihre eigentlichen Grenzen und werden Teil eines globalen Projektes, welches durch seine starke Identität und Eigenständigkeit die gesamte Umgebung mit einbringt.
<G-vec00179-001-s068><create.bilden><en> Beginning with a black square, the two actors create forms from various different elements that quote Russian Constructivist motifs, such as Kazimir Malevich’s iconic Black Square on a White Background (1915).
<G-vec00179-001-s068><create.bilden><de> Beginnend mit einem schwarzen Quadrat bilden die beiden Akteure aus verschiedenen Elementen Formen, die Motive des russischen Konstruktivismus zitieren – etwa Kasimir Malewitschs ikonisches Schwarzes Quadrat auf weißem Grund (1915).
<G-vec00179-001-s069><create.bilden><en> The bright stonewalls create a simple and genuine architecture, two of the main qualities featuring the life of the Benedictine nuns, who have lived in this building for centuries, meditating and taking care of the amazing nature of Bergamo’s hills.
<G-vec00179-001-s069><create.bilden><de> Die blassen Steinmauern bilden eine einfache und aufrichtige Architektur, zwei Eigenschaften, die das Leben von den Benediktinerinnen, die religiösen Frauen, die seit Jahrhunderten dieses Gebäude bewohnen, zwischen religiöser Meditation und Pflege der schönen Natur von den Hügeln von Bergamo, kennzeichnen.
<G-vec00179-001-s070><create.bilden><en> The increasing circulation of people, goods, and data create new cultural, social, and virtual landscapes, which can not be described by traditional geo-scientific categories.
<G-vec00179-001-s070><create.bilden><de> Die Zirkulation von Menschen, Daten und Gütern bilden neue kulturelle, soziale und virtuelle Landschaften, die sich wiederum materiell im Terrain niederschreiben.
<G-vec00179-001-s071><create.bilden><en> The PIXEL Tower comprises a basic set of PIXEL Boxes, Pods, Tops, Trays and Pads which can serve to create a variety of settings.
<G-vec00179-001-s071><create.bilden><de> Der PIXEL Tower umfasst ein Basis-Set an PIXEL Boxen, Pods, Tops, Trays und Pads aus dem sich eine Vielzahl an Settings bilden lassen.
<G-vec00179-001-s072><create.bilden><en> Leading motive of our activities is to create in subconsciousness of our clients feeling of respectable and professional security service that listens to them, understands their needs and requirements and together with them looks for the most effective solutions of security risks for guarded objects.
<G-vec00179-001-s072><create.bilden><de> Leitmotiv unserer Tätigkeit ist, in Unterbewusstsein unserer Kunden das Gefühl der seriösen und prefessionellen Sicherheitsagentur zu bilden, die ihnen zuhört, ihre Bedürfnisse und Anforderungen versteht, und zusammen mit ihnen die effektivsten Lösungen sucht.
<G-vec00179-001-s073><create.bilden><en> Since palms create new leaves from above, you can remove (old) leaves from below.
<G-vec00179-001-s073><create.bilden><de> Da Palmen von oben neue Blätter bilden, können Sie (alte) Blätter von unten entfernen.
<G-vec00179-001-s074><create.bilden><en> In combination, these items of furniture create micro architectural islands in the room.
<G-vec00179-001-s074><create.bilden><de> In Kombination bilden die Möbel mikroarchitektonische Inseln im Raum.
<G-vec00179-001-s075><create.bilden><en> We create and implement the latest solutions, optimising the processes related to our services.
<G-vec00179-001-s075><create.bilden><de> Wir bilden und leiten die neusten optimierenden Prozesse ein, die mit unseren Diensten verbunden sind.
<G-vec00001-001-s171><create.entstehen><en> This BERNINA accessory enables you to create attractive decorations from wool yarns or loose wool fibers in next to no time.
<G-vec00001-001-s171><create.entstehen><de> Mit diesem BERNINA-Zubehör entstehen im Handumdrehen attraktive Dekorationen aus Wollzwirnen oder losen Wollfasern.
<G-vec00001-001-s172><create.entstehen><en> Bio-imaging technologies, i.e. digital image acquisition and processing for visualization of structure and function of living objects, are used to create images of human or animal bodies, anatomical regions and tissues, or even of individual cells and molecules.
<G-vec00001-001-s172><create.entstehen><de> Mittels Bio-Imaging, also durch digitale Bildaufnahme und -verarbeitung für die Visualisierung von Struktur und Funktion lebender Objekte, entstehen Bilder menschlicher und tierischer Körper, von anatomischen Regionen und Geweben, oder einzelnen Zellen bis hin zu Molekülen.
<G-vec00001-001-s173><create.entstehen><en> With the compact 14mm wide angle lens by walimex pro you can create unique shots.
<G-vec00001-001-s173><create.entstehen><de> Mit dem kompakten 14mm Weitwinkelobjektiv von walimex pro entstehen einzigartige Aufnahmen.
<G-vec00001-001-s174><create.entstehen><en> By increasing the collaboration between business and research, this program will create more than 20 innovations in energy that are “Made in Styria”, for export around the world.
<G-vec00001-001-s174><create.entstehen><de> Durch diese verstärkte Zusammenarbeit von Wirtschaft und Forschung werden in diesem Programm mehr als 20 Energieinnovation „Made in Styria“ für den weltweiten Export entstehen.
<G-vec00001-001-s175><create.entstehen><en> This agreement will create a union of more than 700 million people, one that will bring tangible advantages to the populations of both regions.
<G-vec00001-001-s175><create.entstehen><de> Mit diesem Abkommen wird ein Zusammenschluss von mehr als 700 Millionen Einwohnern entstehen, der für die Menschen in beiden Regionen von spürbarem Vorteil sein wird.
<G-vec00001-001-s176><create.entstehen><en> How to create concentric waves and flying carpets.
<G-vec00001-001-s176><create.entstehen><de> Wie entstehen konzentrische Wellen und Fliegende Teppiche.
<G-vec00001-001-s177><create.entstehen><en> There is the Creative Sewing Workshop for kids, or Painting Mountain Panoramas, or the Creative Natural Resources Workshop where kids get to create fairy tale worlds in the woods.
<G-vec00001-001-s177><create.entstehen><de> Für Kinder gibt es den Kreativ Näh-Workshop, Berggeschichten Malen oder den Kreativ-Kurs Naturmaterialien, in dem Kinder Märchenwelten im Wald entstehen lassen.
<G-vec00001-001-s178><create.entstehen><en> Cl: It will also create physical reflexes, physical feelings, which in a normal state of consciousness would not exist.
<G-vec00001-001-s178><create.entstehen><de> Cl: Und dadurch entstehen auch körperliche Reflexe, körperliche Gefühle, die in normalem Zustand des Total-Wachbewussten nicht vorhanden sind.
<G-vec00001-001-s179><create.entstehen><en> In order to create jewellery that makes gift giving as easy as this, everyone has to work together closely and smoothly, and this process has to be sustainable.
<G-vec00001-001-s179><create.entstehen><de> Wenn Schmuck entstehen soll, der Schenken so leicht macht wie dieser, müssen alle Zwischenglieder mühelos funktionieren, eng geknüpft und nachhaltig sein.
<G-vec00001-001-s180><create.entstehen><en> Depending on the business idea and the requirements, this doesn't just create individual products such as custom-printed balls, shoes, cups, helmets, surfboards, and packaging.
<G-vec00001-001-s180><create.entstehen><de> Je nach Geschäftsidee und Anforderung entstehen so nicht nur Einzelstücke wie individuell bedruckte Bälle, Schuhe, Tassen, Helme, Surfbretter oder Verpackungen.
<G-vec00001-001-s181><create.entstehen><en> Switching arcs create large amounts of degradation gases which must be released into the surrounding air.
<G-vec00001-001-s181><create.entstehen><de> Durch die Schaltlichtbögen entstehen große Mengen an Zersetzungsgasen, die an die Umgebungsluft abgegeben werden müssen.
<G-vec00001-001-s182><create.entstehen><en> Fine art – painting, graphics, sculpture, multimedia – photography, architecture and artists' archives provide a rich source, whose interdisciplinary relationships create exciting dialogues.
<G-vec00001-001-s182><create.entstehen><de> Bildende Kunst – Malerei, Grafik, Skulptur, Multimedia – Fotografie, Architektur und Künstler-Archive formen einen Fundus, aus dem durch interdisziplinäre Verschränkungen spannungsvolle Dialoge entstehen.
<G-vec00001-001-s183><create.entstehen><en> This, in turn, can create a misleading, idealized picture of the past.
<G-vec00001-001-s183><create.entstehen><de> Hieraus kann allerdings auch ein irreführendes, idealisiertes Bild der Vergangenheit entstehen.
<G-vec00001-001-s184><create.entstehen><en> This way we create cabinets or small spaces.
<G-vec00001-001-s184><create.entstehen><de> Dadurch entstehen Schränke oder kleine Räume.
<G-vec00001-001-s185><create.entstehen><en> You only need to install the engine and with some help of tools like map- and dialog-editors as well as a little Python, it is possible to create a complete game.
<G-vec00001-001-s185><create.entstehen><de> Um ein Adonthell-Spiel zu entwickeln, muss also lediglich die Engine installiert werden und dann kann mit Hilfe diverser Hilfsmittel wie Karten- und Dialogeditoren und ein wenig Python ein vollständiges Spiel entstehen.
<G-vec00001-001-s186><create.entstehen><en> Whether it is using a mobile telephone, accessing the Internet, being photographed by a CCTV camera, uploading a picture onto an internet platform, opening a door using a chip card or paying for goods with credit card – these transactions can almost always be used to create a movement profile and to reveal information about the user's lifestyle.
<G-vec00001-001-s186><create.entstehen><de> Ob wir mobil telefonieren, auf das Internet zugreifen, von einer Videokamera erfasst werden, ein Foto auf eine Internetplattform hochladen, mit einem Chip eine Tür öffnen oder bargeldlos bezahlen: Fast immer entstehen dabei Daten, die sich zu Bewegungsprofilen zusammenfügen lassen und Rückschlüsse auf unsere Lebenssituation erlauben.
<G-vec00001-001-s187><create.entstehen><en> This is intended to create a connected living space in which the animals can find food, shelter and partners more easily.
<G-vec00001-001-s187><create.entstehen><de> Dadurch soll ein zusammenhängender Lebensraum entstehen, in dem die Tiere leichter Futter, Schutz und Partner finden können.
<G-vec00001-001-s188><create.entstehen><en> "Dr Tarsitani said this by way of reply: ""I think that we must not be tranquillisers at all costs but we must not allow the masse of information to create unjustified anxiety and panic."
<G-vec00001-001-s188><create.entstehen><de> "Professor Tarsitani gibt folgende Antwort: ""Meiner Ansicht nach sollten wir nicht versuchen um jeden Preis beruhigend zu wirken, wir sollten uns vielmehr fragen, ob nicht ein Zuviel an Information zum Entstehen von ungerechtfertigter Angst und Panik führt."
<G-vec00001-001-s189><create.entstehen><en> The images create spaces of moving events.
<G-vec00001-001-s189><create.entstehen><de> Von den Bildern her entstehen Räume bewegten Geschehens.
<G-vec00001-001-s190><create.entstehen><en> I actually create each circuit in the simulator and so I use this software very intensively.
<G-vec00001-001-s190><create.entstehen><de> Bei mir entsteht eigentlich jede Schaltung erst einmal im Simulator und so nutze ich diese Software auch sehr intensiv.
<G-vec00001-001-s191><create.entstehen><en> Together, they make the 5-element recipe and create a true power package from nature.
<G-vec00001-001-s191><create.entstehen><de> Gemeinsam ergeben sie das 5-Elemente-Rezept und es entsteht ein wahres Powerpaket aus der Natur.
<G-vec00001-001-s192><create.entstehen><en> User friendly with Flash version and staying on the cutting edge of technology create a dynamic platform.
<G-vec00001-001-s192><create.entstehen><de> Dank der benutzerfreundlichen Flash-Version und dem neuesten Stand der Technik entsteht eine dynamische Plattform.
<G-vec00001-001-s193><create.entstehen><en> The overlapping branches and delicate lines accentuating the round shape of the fruits create an impression of depth.
<G-vec00001-001-s193><create.entstehen><de> Durch die stellenweise Überlagerung der Zweige und die in zarten Linien angedeutete Rundung der Früchte entsteht ein Eindruck räumlicher Tiefe.
<G-vec00001-001-s194><create.entstehen><en> We blend these with Latin American Arabica beans to create a Lungo with a truly intense character.
<G-vec00001-001-s194><create.entstehen><de> Durch die Mischung mit lateinamerikanischen Arabicas entsteht ein Lungo mit ausgeprägt intensivem Charakter.
<G-vec00001-001-s195><create.entstehen><en> This will create another product row where you can adjust the options available.
<G-vec00001-001-s195><create.entstehen><de> Dadurch entsteht eine neue Produkt-Reihe, in der Sie die verfügbaren Optionen einstellen können.
<G-vec00001-001-s196><create.entstehen><en> The dish is fermented by many bacteria to create the final product.
<G-vec00001-001-s196><create.entstehen><de> Das finale Produkt entsteht durch das Sauermilcherzeugniss.
<G-vec00001-001-s197><create.entstehen><en> When these three aspects meet, they create an incredible maelstrom, and the public is enthralled with it.
<G-vec00001-001-s197><create.entstehen><de> Wenn diese drei Aspekte aufeinandertreffen, entsteht ein unfassbarer Sog und die Öffentlichkeit ergötzt sich daran.
<G-vec00001-001-s198><create.entstehen><en> As a result, an exemption from the authorisation requirement does not create a regulatory gap which needs to be closed by the authorities.
<G-vec00001-001-s198><create.entstehen><de> Durch eine Ausnahme von der Zulassungspflicht entsteht also keine Regelungslücke, die durch die Behörden geschlossen werden müsste.
<G-vec00001-001-s199><create.entstehen><en> In the course of this expansion, the Muslims integrate the Hellenistic philosophy and culture, and in so doing create a uniquely advanced civilization .
<G-vec00001-001-s199><create.entstehen><de> Im Zuge dieser Ausbreitung integrieren die Muslime die hellenistische Philosophie und Kultur, wodurch eine einzigartige Hochkultur entsteht.
<G-vec00001-001-s200><create.entstehen><en> In combination with every look you are able to create a totally fashionable material mix.
<G-vec00001-001-s200><create.entstehen><de> In Kombination mit jedem Look entsteht von ganz alleine ein angesagter Material-Mix der Fashion-Superlative.
<G-vec00001-001-s201><create.entstehen><en> Together, the multitude of different systems working together in an integrated way create a digital ecosystem – Aareon Smart World.
<G-vec00001-001-s201><create.entstehen><de> Aus der Vielzahl integriert zusammenarbeitender Systeme, entsteht ein digitales Ökosystem – die Aareon Smart World.
<G-vec00001-001-s202><create.entstehen><en> Through clever combination screw using the instructions create one of the 15 models: crane, wind turbine, catamaran and many more .
<G-vec00001-001-s202><create.entstehen><de> Durch geschicktes Zusammenschrauben anhand der Anleitung entsteht eines der 15 Modelle: Kran, Windrad, Katamaran und viele mehr.
<G-vec00001-001-s203><create.entstehen><en> When qualified persons work unpaid it will affect the balance in the working roles and create a bad conscience that is compensated for in different ways.
<G-vec00001-001-s203><create.entstehen><de> Wenn qualifiziertes Personal unentgeltlich arbeitet, hat das Auswirkungen auf die Balance der Rollenverteilung und es entsteht ein schlechtes Gewissen, das auf verschiedene Weise kompensiert wird.
<G-vec00001-001-s204><create.entstehen><en> The music opens up to create spaces for improvisation without diluting the authentic sound of the band.
<G-vec00001-001-s204><create.entstehen><de> Es entsteht immer wieder Freiraum für Improvisation, ohne das der authentische Sound der Band verwässert wird.
<G-vec00001-001-s205><create.entstehen><en> A mix of shapes, patterns, colours and hard and soft surfaces infuses the spaces with variety and surprise, and helps to create stimulating learning spaces.
<G-vec00001-001-s205><create.entstehen><de> Die Räume bieten eine überraschende Vielfalt an Farben, Mustern, Formen, harten und weichen Oberflächen, wodurch eine stimulierende Lernatmosphäre entsteht.
<G-vec00001-001-s206><create.entstehen><en> People identify themselves with the athlete(s) and create a bond to the project.
<G-vec00001-001-s206><create.entstehen><de> Die Menschen identifizieren sich mit dem/den Athlet(en) und eine Bindung zum Vorhaben entsteht.
<G-vec00001-001-s207><create.entstehen><en> Thus we create the characteristic form, which is distinctive for our toys.
<G-vec00001-001-s207><create.entstehen><de> So entsteht die charakteristische Formgebung, die unseren Spielsachen eigen ist.
<G-vec00001-001-s208><create.entstehen><en> It's easy to create a nice floor in a short time because Marmoleum Click panels are wide and without visible joints.
<G-vec00001-001-s208><create.entstehen><de> Es ist einfach So entsteht in kurzer Zeit ein schöner Boden, denn Marmoleum Click-Platten sind breit und ohne sichtbare Fugen.
<G-vec00001-001-s209><create.entwerfen><en> Their challenge was to create a contemporary ambience, while emphasizing ecological and sustainable aspects.
<G-vec00001-001-s209><create.entwerfen><de> Die Herausforderung war, ein zeitgemäßes Ambiente zu entwerfen und dabei stark auf Ökologie und Nachhaltigkeit zu achten.
<G-vec00001-001-s210><create.entwerfen><en> Joseph Vilsmaier and Hubert von Goisern create a captivating image of Austria with images and music.
<G-vec00001-001-s210><create.entwerfen><de> Joseph Vilsmaier und Hubert von Goisern entwerfen mit Bild und Musik ein betörendes Österreich-Bild.
<G-vec00001-001-s211><create.entwerfen><en> During the premiere of ALUCOBOND® design at the MADE Expo in Milan, 3A Composites invited all architects and designers to create individual decors for their facade.
<G-vec00001-001-s211><create.entwerfen><de> Während der Premiere von ALUCOBOND® design auf der MADE Expo in Mailand, hat 3A Compositesalle Architekten und Designer eingeladen ihre eigenen Dekore für die Fassadengestaltung zu entwerfen.
<G-vec00001-001-s212><create.entwerfen><en> Curator of the TECHNOSENSUAL 'Where fashion meets Tech-nology' exhibition that took place at MuseumsQuartier Wien the last 2,5 months, she will give an insight in what it takes to create 'Electronic Couture'
<G-vec00001-001-s212><create.entwerfen><de> "Als Kuratorin der Ausstellung TECHNOSENSUAL 'Where fashion meets technology"", die in den vergangenen zweieinhalb Monaten im Museumsquartier stattfand, stellt sie dar, was alles benötigt wird, um 'Electronic Couture' zu entwerfen."
<G-vec00001-001-s213><create.entwerfen><en> Diesel's designers were to create a fashion line that especially spoke to independent people.
<G-vec00001-001-s213><create.entwerfen><de> Diesel 's Designer sollten eine Modelinie entwerfen, die vor allem unabhängige Leute anspricht.
<G-vec00001-001-s214><create.entwerfen><en> "Variation: Since you can't assume that the ""control"" version of your web page or single element is 100% perfect, you need to create another variation that'll challenge the control."
<G-vec00001-001-s214><create.entwerfen><de> "Variation: Da Du nicht davon ausgehen kannst, dass die ""Kontrollversion"" Deiner Webseite, oder das Element, 100% perfekt sind, musst Du eine andere Version entwerfen, um die Kontrollversion zu testen."
<G-vec00001-001-s215><create.entwerfen><en> I also discovered the possibility to create locations like landscapes for my subjects.
<G-vec00001-001-s215><create.entwerfen><de> Ich habe außerdem angefangen, Orte und Landschaften für meine Themen zu entwerfen.
<G-vec00001-001-s216><create.entwerfen><en> La entrada OneExpress chooses Wtransnet’s technology to create a private freight exchange aparece primero en Wtransnet Blog.
<G-vec00001-001-s216><create.entwerfen><de> La entrada DHL Supply Chain Spain und Wtransnet entwerfen ein privates System des Frachtenmanagement für Transportunternehmen aparece primero en Blog Wtransnet Deutschland.
<G-vec00001-001-s217><create.entwerfen><en> We create space in all scales, and design it comprehen-sively.
<G-vec00001-001-s217><create.entwerfen><de> Wir entwerfen Raum in allen Massstäben und konzipieren ihn ganzheitlich.
<G-vec00001-001-s218><create.entwerfen><en> Jigs@w Puzzle 2 Everything you need to play and create jigsaw puzzles from your own pictures.
<G-vec00001-001-s218><create.entwerfen><de> Jigs@w Puzzle 2 Alles was Du brauchst um Puzzles zu spielen und aus eigenen Fotos zu entwerfen.
<G-vec00001-001-s219><create.entwerfen><en> Trenbolone in Graubunden Switzerland is incredibly versatile so you could create a cycle based on your very own special tolerance as well as requirements.
<G-vec00001-001-s219><create.entwerfen><de> Trenbolon in Graubunden Schweiz ist extrem flexibel, so dass Sie einen Zyklus, basierend auf Ihre eigenen ein-of-a-kind-Toleranz sowie Anforderungen entwerfen könnte.
<G-vec00001-001-s220><create.entwerfen><en> In this way aid organizations could begin to create long-term solutions for regional regeneration while they are working on the symptoms of the problem.
<G-vec00001-001-s220><create.entwerfen><de> So könnten Hilfsorganisationen anfangen an langfristigen Lösungen für den regionalen Wiederaufbau zu entwerfen, während sie an den Symptomen des Problems arbeiten.
<G-vec00001-001-s221><create.entwerfen><en> """webMethods' Fabric product family combined with Software AG's Crossvision SOA suite will provide an end-to-end SOA solution that allows our combined client base to more effectively create, manage and govern their business processes."
<G-vec00001-001-s221><create.entwerfen><de> """webmethods' Fabric Produktfamilie in Verbindung mit der Crossvision SOA-Suite der Software AG ermöglicht eine integrierte SOA-Lösung, die es unserer gemeinsamen Kundenbasis erlaubt, ihre Geschäftsprozesse effizienter zu entwerfen, zu steuern und zu überwachen."
<G-vec00001-001-s222><create.entwerfen><en> They work with local and international companies, helping them create and bring to market meaningful products, services and experiences.
<G-vec00001-001-s222><create.entwerfen><de> Sie arbeiten mit lokalen und internationalen Unternehmen zusammen und helfen ihnen, bedeutende Produkte, Dienstleistungen und Erlebnisse zu entwerfen und zu vermarkten.
<G-vec00001-001-s223><create.entwerfen><en> You can even propose and create Instant Answers from scratch, via Duck Duck Hack.
<G-vec00001-001-s223><create.entwerfen><de> Du kannst mitDuck Duck Hacksogar direkte Antworten aus dem Nichts entwerfen.
<G-vec00001-001-s224><create.entwerfen><en> Highly skilled application engineers — at the factory and in the field — to help you troubleshoot problems or create entirely new solutions.
<G-vec00001-001-s224><create.entwerfen><de> Hochqualifizierte Applikations Ingenieure — im Unternehmen und im Feld — helfen Ihnen bei der Fehlerbehebung oder entwerfen völlig neue Lösungen.
<G-vec00001-001-s225><create.entwerfen><en> We also create effective marketing campaigns through Google Adwords (SEM) to set your products and services apart from the crowd, resulting in greater exposure.
<G-vec00001-001-s225><create.entwerfen><de> Außerdem entwerfen wir effektive Marketingkampagnen mittels Google Adwords (SEM), um Ihre Produkte oder Dienstleistungen zu platzieren und für diese zu werben.
<G-vec00001-001-s226><create.entwerfen><en> In all section which concern strategic planning, i.e. financing, production scheduling and shooting scheduling, Yamdu enables you to create multiple planning scenarios.
<G-vec00001-001-s226><create.entwerfen><de> Bei allen Funktionen, die mit strategischer Planung zu tun haben, also Finanzierung, Herstellungsplanung und Drehplanung, erlaubt es Yamdu unterschiedliche Planungsszenarien zu entwerfen.
<G-vec00001-001-s227><create.entwerfen><en> I tried to create a more interesting tour than what I saw out there already, and this has worked for me.
<G-vec00001-001-s227><create.entwerfen><de> Ich habe versucht, eine deutlich interessantere Tour zu entwerfen als das, was ich da draußen bislang gesehen habe – und das klappt gut für mich.
<G-vec00001-001-s228><create.entwickeln><en> Additionally, Mecel will be complementing this offering with their consulting services to help automakers and suppliers create, configure, customize, and extend AUTOSAR-based systems.
<G-vec00001-001-s228><create.entwickeln><de> Darüber hinaus wird Mecel Consulting-Dienstleistungen anbieten, die Automobilherstellern und Zulieferern dabei helfen, AUTOSAR-basierte System zu entwickeln, zu konfigurieren, zu erweitern und an die jeweiligen Entwicklungsplattformen anzupassen.
<G-vec00001-001-s229><create.entwickeln><en> Then we create solutions that are right for them and for their patients, and that are supported by evidence.
<G-vec00001-001-s229><create.entwickeln><de> Anschließend entwickeln wir Lösungen, die richtig für sie und ihre Patienten sind – und die von wissenschaftlichen Beweisen gestützt werden.
<G-vec00001-001-s230><create.entwickeln><en> You need to create an account on PhenQ.com to purchase the product.
<G-vec00001-001-s230><create.entwickeln><de> Sie müssen ein Konto auf PhenQ.com, um das Element zu erwerben zu entwickeln.
<G-vec00001-001-s231><create.entwickeln><en> We create thousands of custom color and additive masterbatches every year for customers around the world, and test them against the most rigorous performance standards.
<G-vec00001-001-s231><create.entwickeln><de> Wir entwickeln jedes Jahr tausende von individuellen Farb- und Additiv-Masterbatches für Kunden überall auf der Welt und testen diese auf Grundlage strengster Leistungsstandards.
<G-vec00001-001-s232><create.entwickeln><en> The main task for our engineers when designing a sunDECK tensile structure is to use this technology and create strong and stylish membranes - constructions of elements carrying only tension and in no case compression or bending.
<G-vec00001-001-s232><create.entwickeln><de> Bei der Konstruktion einer SAILTEC Membranstruktur ist die wesentliche Herausforderung für unsere Ingenieure, mit Hilfe dieser Technologie stilvolle und belastbare Membranen zu entwickeln - Konstruktionen, die nur Zugelemente beinhalten, und weder Druck- noch Biege-Elemente.
<G-vec00001-001-s233><create.entwickeln><en> With our 3D design and printing facilities, we can create your unique packaging.
<G-vec00001-001-s233><create.entwickeln><de> Mit unserem 3D-Design- und Druckmöglichkeiten können wir Ihnen Ihre einzigartigen Verpackungen entwickeln.
<G-vec00001-001-s234><create.entwickeln><en> Together with you we aim to create solutions and products that are as unique as your individual needs.
<G-vec00001-001-s234><create.entwickeln><de> Zusammen mit Ihnen streben wir danach, Lösungen und Produkte zu entwickeln, die speziell auf Ihre Anforderungen zugeschnitten sind.
<G-vec00001-001-s235><create.entwickeln><en> And it’s down to us to perhaps to create better tools or work closer with steam in the future.
<G-vec00001-001-s235><create.entwickeln><de> Und es liegt an uns, möglicherweise bessere Entwicklerwerkzeuge zu entwickeln oder noch enger mit Steam zusammen zu arbeiten.
<G-vec00001-001-s236><create.entwickeln><en> We don't just create technology—we create experiences.
<G-vec00001-001-s236><create.entwickeln><de> Wir entwickeln nicht bloß Technologie – wir schaffen Erlebnisse.
<G-vec00001-001-s237><create.entwickeln><en> We create solutions for biocatalysis and biorefining.
<G-vec00001-001-s237><create.entwickeln><de> Wir entwickeln Lösungen für die Bereiche Biokatalyse und Bioraffinerie.
<G-vec00001-001-s238><create.entwickeln><en> In this session Larry Kim will discuss how marketers should be using search and social combined to create powerful hyper-personalized strategies, how to use new audience targeting features and how to layer and shape your audiences to reach the perfect audience - yours.
<G-vec00001-001-s238><create.entwickeln><de> "Larry Kim diskutiert in dieser Session wie Online Marketer Suche und Social zusammen nutzen können, um effiziente ""hyper-personalised"" Strategien zu entwickeln, wie man die neuen Audience Targeting Features nutzen kann um so die perfekte Audience – eure Audience – anzusprechen."
<G-vec00001-001-s239><create.entwickeln><en> """Petzl's mission is to create innovative tools and services that allow men and women to progress, position, and protect themselves in vertical environments, as well as to light their way in the dark."
<G-vec00001-001-s239><create.entwickeln><de> Hallenplan Petzl hat es sich zur Aufgabe gemacht innovative Lösungen, Produkte und Leistungen zu entwickeln, die es den Menschen ermöglichen, sich im vertikalen Gelände fortzubewegen, zu positionieren, zu sichern und bei Dunkelheit über eine sichere Beleuchtung zu verfügen.
<G-vec00001-001-s240><create.entwickeln><en> of this world it is easy to knock this theory down: most workers see themselves exploited through the capitalist relationship and have not been able to create their own creativity... [back] 21 Although this pressure comes from 'inside': We wanted to write the leaflets in such a way that they have a 'correct' analysis and are at the same time understandable to everybody.
<G-vec00001-001-s240><create.entwickeln><de> "Durch einen Blick in die Fabriken, Call Center, Krankenhäuser dieser Welt lässt sich die These leicht aushebeln: Die meisten ArbeiterInnen sehen sich weiter ausgepresst durch das kapitalistische Verhältnis und haben keine eigenständige Kreativität entwickeln können... [zurück] 21 Wobei dieser Druck auch von ""innen"" kommt: Wir wollten die Flugblätter so schreiben, dass sie analytisch korrekt und gleichzeitig verständlich sind."
<G-vec00001-001-s241><create.entwickeln><en> All of these efforts are underpinned by our corporate philosophy, which aims to create superior network solutions and provide excellent information and communications services globally to meet the diversified needs of communities worldwide in the information age.
<G-vec00001-001-s241><create.entwickeln><de> Unser hoher Qualitätsstandard wird durch unsere Unternehmensphilosophie untermauert, die darauf abzielt, exzellente Netzwerklösungen zu entwickeln und hervorragende Informations- und Kommunikationsdienstleistungen zu erbringen, um den vielfältigen Bedürfnissen im digitalen Zeitalter gerecht zu werden.
<G-vec00001-001-s242><create.entwickeln><en> In addition, QNAP’s development platform embraces the open-source spirit to enable developers to create their own apps, adding potentially limitless potential for the TS-453mini.
<G-vec00001-001-s242><create.entwickeln><de> Zudem entspricht die Entwicklungsplattform von QNAP dem Open-Source-Konzept, wodurch Programmentwickler in die Lage sind, ihre eigenen Apps zu entwickeln, sodass dem TS-453mini praktisch unbegrenztes Potenzial zur Verfügung stehen.
<G-vec00001-001-s243><create.entwickeln><en> """I have always been a fan of superheroes and I'm thrilled to help to create this new animated series,"" commented Cristiano Ronaldo ."
<G-vec00001-001-s243><create.entwickeln><de> "„Ich war schon immer ein Fan von Superhelden und freue mich sehr, mithelfen zu können, diese neue Zeichentrickserie zu entwickeln"", so Cristiano Ronaldo ."
<G-vec00001-001-s244><create.entwickeln><en> We are proud to bring our unrivalled expertise to each project, helping to create world-leading telescopic and linear slides for use in a range of different applications.
<G-vec00001-001-s244><create.entwickeln><de> Wir sind stolz darauf, unsere Erfahrung in jedes Projekt einzubringen, um hochwertige Teleskopschienen und Linearführungen für den Einsatz in den unterschiedlichsten Anwendungen zu entwickeln.
<G-vec00001-001-s245><create.entwickeln><en> Together with you, we develop tailor-made solutions to improve your organization comprehensively and sustainably: We design strategies, develop organization and processes, create leadership tools and strategic personnel planning and support you in the search for and the selection of executives.
<G-vec00001-001-s245><create.entwickeln><de> Wir entwickeln mit Ihnen gemeinsam maßgeschneiderte Lösungen, um Ihre Organisation umfassend und nachhaltig zu verbessern: Wir erarbeiten Strategien, gestalten Organisation und Prozesse, entwickeln Führungsinstrumente und strategische Personalplanung und unterstützen Sie bei der Suche und Auswahl von Führungskräften.
<G-vec00001-001-s246><create.entwickeln><en> This workshop will help you to create precision not only in alignment, but also in breathing and flow of postures.
<G-vec00001-001-s246><create.entwickeln><de> Dieser Workshop wird dir helfen nicht nur bei der Ausrichtung, sondern auch im Atmen und dem Fluss der Positionen eine Genauigkeit zu entwickeln.
<G-vec00179-001-s228><create.entwickeln><en> Additionally, Mecel will be complementing this offering with their consulting services to help automakers and suppliers create, configure, customize, and extend AUTOSAR-based systems.
<G-vec00179-001-s228><create.entwickeln><de> Darüber hinaus wird Mecel Consulting-Dienstleistungen anbieten, die Automobilherstellern und Zulieferern dabei helfen, AUTOSAR-basierte System zu entwickeln, zu konfigurieren, zu erweitern und an die jeweiligen Entwicklungsplattformen anzupassen.
<G-vec00179-001-s229><create.entwickeln><en> Then we create solutions that are right for them and for their patients, and that are supported by evidence.
<G-vec00179-001-s229><create.entwickeln><de> Anschließend entwickeln wir Lösungen, die richtig für sie und ihre Patienten sind – und die von wissenschaftlichen Beweisen gestützt werden.
<G-vec00179-001-s230><create.entwickeln><en> You need to create an account on PhenQ.com to purchase the product.
<G-vec00179-001-s230><create.entwickeln><de> Sie müssen ein Konto auf PhenQ.com, um das Element zu erwerben zu entwickeln.
<G-vec00179-001-s231><create.entwickeln><en> We create thousands of custom color and additive masterbatches every year for customers around the world, and test them against the most rigorous performance standards.
<G-vec00179-001-s231><create.entwickeln><de> Wir entwickeln jedes Jahr tausende von individuellen Farb- und Additiv-Masterbatches für Kunden überall auf der Welt und testen diese auf Grundlage strengster Leistungsstandards.
<G-vec00179-001-s232><create.entwickeln><en> The main task for our engineers when designing a sunDECK tensile structure is to use this technology and create strong and stylish membranes - constructions of elements carrying only tension and in no case compression or bending.
<G-vec00179-001-s232><create.entwickeln><de> Bei der Konstruktion einer SAILTEC Membranstruktur ist die wesentliche Herausforderung für unsere Ingenieure, mit Hilfe dieser Technologie stilvolle und belastbare Membranen zu entwickeln - Konstruktionen, die nur Zugelemente beinhalten, und weder Druck- noch Biege-Elemente.
<G-vec00179-001-s233><create.entwickeln><en> With our 3D design and printing facilities, we can create your unique packaging.
<G-vec00179-001-s233><create.entwickeln><de> Mit unserem 3D-Design- und Druckmöglichkeiten können wir Ihnen Ihre einzigartigen Verpackungen entwickeln.
<G-vec00179-001-s234><create.entwickeln><en> Together with you we aim to create solutions and products that are as unique as your individual needs.
<G-vec00179-001-s234><create.entwickeln><de> Zusammen mit Ihnen streben wir danach, Lösungen und Produkte zu entwickeln, die speziell auf Ihre Anforderungen zugeschnitten sind.
<G-vec00179-001-s235><create.entwickeln><en> And it’s down to us to perhaps to create better tools or work closer with steam in the future.
<G-vec00179-001-s235><create.entwickeln><de> Und es liegt an uns, möglicherweise bessere Entwicklerwerkzeuge zu entwickeln oder noch enger mit Steam zusammen zu arbeiten.
<G-vec00179-001-s236><create.entwickeln><en> We don't just create technology—we create experiences.
<G-vec00179-001-s236><create.entwickeln><de> Wir entwickeln nicht bloß Technologie – wir schaffen Erlebnisse.
<G-vec00179-001-s237><create.entwickeln><en> We create solutions for biocatalysis and biorefining.
<G-vec00179-001-s237><create.entwickeln><de> Wir entwickeln Lösungen für die Bereiche Biokatalyse und Bioraffinerie.
<G-vec00179-001-s238><create.entwickeln><en> In this session Larry Kim will discuss how marketers should be using search and social combined to create powerful hyper-personalized strategies, how to use new audience targeting features and how to layer and shape your audiences to reach the perfect audience - yours.
<G-vec00179-001-s238><create.entwickeln><de> "Larry Kim diskutiert in dieser Session wie Online Marketer Suche und Social zusammen nutzen können, um effiziente ""hyper-personalised"" Strategien zu entwickeln, wie man die neuen Audience Targeting Features nutzen kann um so die perfekte Audience – eure Audience – anzusprechen."
<G-vec00179-001-s239><create.entwickeln><en> """Petzl's mission is to create innovative tools and services that allow men and women to progress, position, and protect themselves in vertical environments, as well as to light their way in the dark."
<G-vec00179-001-s239><create.entwickeln><de> Hallenplan Petzl hat es sich zur Aufgabe gemacht innovative Lösungen, Produkte und Leistungen zu entwickeln, die es den Menschen ermöglichen, sich im vertikalen Gelände fortzubewegen, zu positionieren, zu sichern und bei Dunkelheit über eine sichere Beleuchtung zu verfügen.
<G-vec00179-001-s240><create.entwickeln><en> of this world it is easy to knock this theory down: most workers see themselves exploited through the capitalist relationship and have not been able to create their own creativity... [back] 21 Although this pressure comes from 'inside': We wanted to write the leaflets in such a way that they have a 'correct' analysis and are at the same time understandable to everybody.
<G-vec00179-001-s240><create.entwickeln><de> "Durch einen Blick in die Fabriken, Call Center, Krankenhäuser dieser Welt lässt sich die These leicht aushebeln: Die meisten ArbeiterInnen sehen sich weiter ausgepresst durch das kapitalistische Verhältnis und haben keine eigenständige Kreativität entwickeln können... [zurück] 21 Wobei dieser Druck auch von ""innen"" kommt: Wir wollten die Flugblätter so schreiben, dass sie analytisch korrekt und gleichzeitig verständlich sind."
<G-vec00179-001-s241><create.entwickeln><en> All of these efforts are underpinned by our corporate philosophy, which aims to create superior network solutions and provide excellent information and communications services globally to meet the diversified needs of communities worldwide in the information age.
<G-vec00179-001-s241><create.entwickeln><de> Unser hoher Qualitätsstandard wird durch unsere Unternehmensphilosophie untermauert, die darauf abzielt, exzellente Netzwerklösungen zu entwickeln und hervorragende Informations- und Kommunikationsdienstleistungen zu erbringen, um den vielfältigen Bedürfnissen im digitalen Zeitalter gerecht zu werden.
<G-vec00179-001-s242><create.entwickeln><en> In addition, QNAP’s development platform embraces the open-source spirit to enable developers to create their own apps, adding potentially limitless potential for the TS-453mini.
<G-vec00179-001-s242><create.entwickeln><de> Zudem entspricht die Entwicklungsplattform von QNAP dem Open-Source-Konzept, wodurch Programmentwickler in die Lage sind, ihre eigenen Apps zu entwickeln, sodass dem TS-453mini praktisch unbegrenztes Potenzial zur Verfügung stehen.
<G-vec00179-001-s243><create.entwickeln><en> """I have always been a fan of superheroes and I'm thrilled to help to create this new animated series,"" commented Cristiano Ronaldo ."
<G-vec00179-001-s243><create.entwickeln><de> "„Ich war schon immer ein Fan von Superhelden und freue mich sehr, mithelfen zu können, diese neue Zeichentrickserie zu entwickeln"", so Cristiano Ronaldo ."
<G-vec00179-001-s244><create.entwickeln><en> We are proud to bring our unrivalled expertise to each project, helping to create world-leading telescopic and linear slides for use in a range of different applications.
<G-vec00179-001-s244><create.entwickeln><de> Wir sind stolz darauf, unsere Erfahrung in jedes Projekt einzubringen, um hochwertige Teleskopschienen und Linearführungen für den Einsatz in den unterschiedlichsten Anwendungen zu entwickeln.
<G-vec00179-001-s245><create.entwickeln><en> Together with you, we develop tailor-made solutions to improve your organization comprehensively and sustainably: We design strategies, develop organization and processes, create leadership tools and strategic personnel planning and support you in the search for and the selection of executives.
<G-vec00179-001-s245><create.entwickeln><de> Wir entwickeln mit Ihnen gemeinsam maßgeschneiderte Lösungen, um Ihre Organisation umfassend und nachhaltig zu verbessern: Wir erarbeiten Strategien, gestalten Organisation und Prozesse, entwickeln Führungsinstrumente und strategische Personalplanung und unterstützen Sie bei der Suche und Auswahl von Führungskräften.
<G-vec00179-001-s246><create.entwickeln><en> This workshop will help you to create precision not only in alignment, but also in breathing and flow of postures.
<G-vec00179-001-s246><create.entwickeln><de> Dieser Workshop wird dir helfen nicht nur bei der Ausrichtung, sondern auch im Atmen und dem Fluss der Positionen eine Genauigkeit zu entwickeln.
<G-vec00001-001-s247><create.erschaffen><en> Mixes really well with bordeaux to create really dark reds.
<G-vec00001-001-s247><create.erschaffen><de> Kann gut mit unserem Bordeaux gemischt werden um wirklich dunkle Rottöne zu erschaffen.
<G-vec00001-001-s248><create.erschaffen><en> Combine Matrox multi-monitor products with touchscreens to create impressive multi-display, multi-touch installations.
<G-vec00001-001-s248><create.erschaffen><de> Kombinieren Sie Matrox-Produkte für mehrere Monitore mit Touchscreens, um beeindruckende Multi-Touch-Installationen zu erschaffen.
<G-vec00001-001-s249><create.erschaffen><en> SRS devices create an immersive 3D soundfield using only two speakers, simulating the kind of audio experience delivered by devices that support Dolby Digital.
<G-vec00001-001-s249><create.erschaffen><de> SRS Geräte erschaffen eine immersive 3D Soundumgebung mit nur zwei Boxen und simulieren die Audioerfahrung, die man durch Geräte erhält, welche Dolby Digital unterstützen.
<G-vec00001-001-s250><create.erschaffen><en> The tears flow incessantly, they fill one and a half liters of plastic bottles, they create waterfalls and rivers.
<G-vec00001-001-s250><create.erschaffen><de> Die Tränen fließen unaufhörlich, sie füllen eineinhalb Liter Plastikflaschen, sie erschaffen Wasserfälle und Flüsse.
<G-vec00001-001-s251><create.erschaffen><en> The thing that separates humans from the plants, however, that humans have a chance to be remembered because of the love we create and share. Food
<G-vec00001-001-s251><create.erschaffen><de> Die Sache, die den Menschen von den Pflanzen trennt, ist jedoch, dass Menschen aufgrund der Liebe, die wir erschaffen und teilen, eine Chance haben, erinnert zu werden.
<G-vec00001-001-s252><create.erschaffen><en> I'm also fascinated by the social impact of graphic design: we are not here to create for a few people but to have a positive impact on the transmission of knowledge in the public domain.
<G-vec00001-001-s252><create.erschaffen><de> Außerdem fasziniert mich der soziale Einfluss von Grafikdesign; wir sind nicht dafür da, nur für eine kleine Gruppe an Menschen Dinge zu erschaffen, sondern vielmehr einen positiven Einfluss auf die Vermittlung von Wissen in der Öffentlichkeit zu nehmen.
<G-vec00001-001-s253><create.erschaffen><en> Insight Pulselive works closely with the ICC and their commercial partners to create and deliver a digital and social strategy which fulfils their objective of ‘capitalising on digital to create value for the ICC and their stakeholders’.
<G-vec00001-001-s253><create.erschaffen><de> Pulselive arbeitet eng mit dem ICC und dessen Geschäftspartnern zusammen, um eine digitale und soziale Strategie zu erschaffen und bereitzustellen, mit der das Ziel der Aktivierung der digitalen Welt erreicht werden soll, um für den ICC und seine Stakeholder einen Mehrwert zu schaffen.
<G-vec00001-001-s254><create.erschaffen><en> MH: Â I just love to create.
<G-vec00001-001-s254><create.erschaffen><de> Mike Harrison: Ich liebe es einfach, etwas zu erschaffen.
<G-vec00001-001-s255><create.erschaffen><en> When you want to create your personal website or a professional website for your business, you need a competent partner who will take care of hosting and all technical issues.
<G-vec00001-001-s255><create.erschaffen><de> Sobald Sie Ihre eigene Homepage oder eine professionelle Webseite für Ihr Unternehmen im Internet erschaffen möchten, benötigen Sie einen kompetenten Partner, der sich um Webhosting und alle technischen Belange kümmert.
<G-vec00001-001-s256><create.erschaffen><en> This is important here at home, but we must also create regulations which are capable of repelling attacks from Brussels.
<G-vec00001-001-s256><create.erschaffen><de> Dies ist auch hier Zuhause wichtig, doch müssen wir Regeln erschaffen, die in der Lage sind, auch die aus Brüssel kommenden Angriffe abzuwehren.
<G-vec00001-001-s257><create.erschaffen><en> I would not create a lesser creature than what I am capable of.
<G-vec00001-001-s257><create.erschaffen><de> Ich möchte keine mindere Schöpfung erschaffen, als Ich in der Lage bin.
<G-vec00001-001-s258><create.erschaffen><en> In a beautiful natural environment of the cultivated world of water with many fishes, wild ducks and swans our team will strive to create pleasant and unique gourmet moments for our guests .
<G-vec00001-001-s258><create.erschaffen><de> Unser Team wird sich bemühen in wunderschö ner NaturUmgebung der gepflegten Wasserwelt mit vielen Fischen, Wildenten und Schwäne für unsere Gäste gemütliche und unwiederholbare Gourmandmomente zu erschaffen .
<G-vec00001-001-s259><create.erschaffen><en> And he and his team create dazzling interactive environments from moving water and flying light, powered by simple gestures caught through sensors.
<G-vec00001-001-s259><create.erschaffen><de> Sein Team und er erschaffen dabei umwerfende interaktive Umgebungen durch sich bewegendes Wasser oder fliegendes Licht, angetrieben durch einfache Gesten, die von Sensoren erfasst werden.
<G-vec00001-001-s260><create.erschaffen><en> Taylor tells us that electrons can create themselves out of nothing in the manner Baron Munchausen saved himself from sinking into a bog by pulling himself up by his bootstraps.
<G-vec00001-001-s260><create.erschaffen><de> Taylor erzählt uns, dass Elektronen sich selbst aus dem nichts erschaffen können, in der Art, wie Baron Münchausen sich selbst davor bewahrte, im Sumpf zu versinken, indem er sich selbst an seinen Stiefelriemen herauszog.
<G-vec00001-001-s261><create.erschaffen><en> We have a dormant potential. If we want to and have a strong will, we could transform these normal permanent atoms into super atoms or highly intelligent quantic atoms and make them shine like tiny points of light to one day create new genetics through the power of the atom Nous.
<G-vec00001-001-s261><create.erschaffen><de> Wir besitzen ein schlafendes Potential... wenn wir wollten und wir einen eisernen Willen hätten, könnten wir diese normalen Atome in Super-Atome oder höchst intelligente, quantische Atome verwandeln und sie wie winzige Lichtpunkte leuchten lassen, um eines Tages mittels der Kraft des Atom Nous eine neue Genetik zu erschaffen.
<G-vec00001-001-s262><create.erschaffen><en> With the technology built into the glasses and special lenses, it's possible to create an authentic and interactive environment in real time.
<G-vec00001-001-s262><create.erschaffen><de> Durch die in den Brillen verbaute Technik und spezielle Linsen wird es möglich, eine authentisch wirkende und interaktive Umgebung in Echtzeit zu erschaffen.
<G-vec00001-001-s263><create.erschaffen><en> It should be relatively easy to create an OpenBSD port.
<G-vec00001-001-s263><create.erschaffen><de> Es sollte relativ einfach sein, einen OpenBSD-Port zu erschaffen.
<G-vec00001-001-s264><create.erschaffen><en> James Cameron's big-budget (and even bigger-grossing) films create unreal worlds all their own.
<G-vec00001-001-s264><create.erschaffen><de> James Camerons mit großem Budget (und noch größerem finanziellen Erfolg) gedrehte Filme erschaffen ihre ganz eigenen unwirklichen Welten.
<G-vec00001-001-s265><create.erschaffen><en> The mind has a basic habit, which is to create things.
<G-vec00001-001-s265><create.erschaffen><de> Der Geist hat eine grundlegende Gewohnheit: Dinge zu erschaffen.
<G-vec00179-001-s247><create.erschaffen><en> Mixes really well with bordeaux to create really dark reds.
<G-vec00179-001-s247><create.erschaffen><de> Kann gut mit unserem Bordeaux gemischt werden um wirklich dunkle Rottöne zu erschaffen.
<G-vec00179-001-s248><create.erschaffen><en> Combine Matrox multi-monitor products with touchscreens to create impressive multi-display, multi-touch installations.
<G-vec00179-001-s248><create.erschaffen><de> Kombinieren Sie Matrox-Produkte für mehrere Monitore mit Touchscreens, um beeindruckende Multi-Touch-Installationen zu erschaffen.
<G-vec00179-001-s249><create.erschaffen><en> SRS devices create an immersive 3D soundfield using only two speakers, simulating the kind of audio experience delivered by devices that support Dolby Digital.
<G-vec00179-001-s249><create.erschaffen><de> SRS Geräte erschaffen eine immersive 3D Soundumgebung mit nur zwei Boxen und simulieren die Audioerfahrung, die man durch Geräte erhält, welche Dolby Digital unterstützen.
<G-vec00179-001-s250><create.erschaffen><en> The tears flow incessantly, they fill one and a half liters of plastic bottles, they create waterfalls and rivers.
<G-vec00179-001-s250><create.erschaffen><de> Die Tränen fließen unaufhörlich, sie füllen eineinhalb Liter Plastikflaschen, sie erschaffen Wasserfälle und Flüsse.
<G-vec00179-001-s251><create.erschaffen><en> The thing that separates humans from the plants, however, that humans have a chance to be remembered because of the love we create and share. Food
<G-vec00179-001-s251><create.erschaffen><de> Die Sache, die den Menschen von den Pflanzen trennt, ist jedoch, dass Menschen aufgrund der Liebe, die wir erschaffen und teilen, eine Chance haben, erinnert zu werden.
<G-vec00179-001-s252><create.erschaffen><en> I'm also fascinated by the social impact of graphic design: we are not here to create for a few people but to have a positive impact on the transmission of knowledge in the public domain.
<G-vec00179-001-s252><create.erschaffen><de> Außerdem fasziniert mich der soziale Einfluss von Grafikdesign; wir sind nicht dafür da, nur für eine kleine Gruppe an Menschen Dinge zu erschaffen, sondern vielmehr einen positiven Einfluss auf die Vermittlung von Wissen in der Öffentlichkeit zu nehmen.
<G-vec00179-001-s253><create.erschaffen><en> Insight Pulselive works closely with the ICC and their commercial partners to create and deliver a digital and social strategy which fulfils their objective of ‘capitalising on digital to create value for the ICC and their stakeholders’.
<G-vec00179-001-s253><create.erschaffen><de> Pulselive arbeitet eng mit dem ICC und dessen Geschäftspartnern zusammen, um eine digitale und soziale Strategie zu erschaffen und bereitzustellen, mit der das Ziel der Aktivierung der digitalen Welt erreicht werden soll, um für den ICC und seine Stakeholder einen Mehrwert zu schaffen.
<G-vec00179-001-s254><create.erschaffen><en> MH: Â I just love to create.
<G-vec00179-001-s254><create.erschaffen><de> Mike Harrison: Ich liebe es einfach, etwas zu erschaffen.
<G-vec00179-001-s255><create.erschaffen><en> When you want to create your personal website or a professional website for your business, you need a competent partner who will take care of hosting and all technical issues.
<G-vec00179-001-s255><create.erschaffen><de> Sobald Sie Ihre eigene Homepage oder eine professionelle Webseite für Ihr Unternehmen im Internet erschaffen möchten, benötigen Sie einen kompetenten Partner, der sich um Webhosting und alle technischen Belange kümmert.
<G-vec00179-001-s256><create.erschaffen><en> This is important here at home, but we must also create regulations which are capable of repelling attacks from Brussels.
<G-vec00179-001-s256><create.erschaffen><de> Dies ist auch hier Zuhause wichtig, doch müssen wir Regeln erschaffen, die in der Lage sind, auch die aus Brüssel kommenden Angriffe abzuwehren.
<G-vec00179-001-s257><create.erschaffen><en> I would not create a lesser creature than what I am capable of.
<G-vec00179-001-s257><create.erschaffen><de> Ich möchte keine mindere Schöpfung erschaffen, als Ich in der Lage bin.
<G-vec00179-001-s258><create.erschaffen><en> In a beautiful natural environment of the cultivated world of water with many fishes, wild ducks and swans our team will strive to create pleasant and unique gourmet moments for our guests .
<G-vec00179-001-s258><create.erschaffen><de> Unser Team wird sich bemühen in wunderschö ner NaturUmgebung der gepflegten Wasserwelt mit vielen Fischen, Wildenten und Schwäne für unsere Gäste gemütliche und unwiederholbare Gourmandmomente zu erschaffen .
<G-vec00179-001-s259><create.erschaffen><en> And he and his team create dazzling interactive environments from moving water and flying light, powered by simple gestures caught through sensors.
<G-vec00179-001-s259><create.erschaffen><de> Sein Team und er erschaffen dabei umwerfende interaktive Umgebungen durch sich bewegendes Wasser oder fliegendes Licht, angetrieben durch einfache Gesten, die von Sensoren erfasst werden.
<G-vec00179-001-s260><create.erschaffen><en> Taylor tells us that electrons can create themselves out of nothing in the manner Baron Munchausen saved himself from sinking into a bog by pulling himself up by his bootstraps.
<G-vec00179-001-s260><create.erschaffen><de> Taylor erzählt uns, dass Elektronen sich selbst aus dem nichts erschaffen können, in der Art, wie Baron Münchausen sich selbst davor bewahrte, im Sumpf zu versinken, indem er sich selbst an seinen Stiefelriemen herauszog.
<G-vec00179-001-s261><create.erschaffen><en> We have a dormant potential. If we want to and have a strong will, we could transform these normal permanent atoms into super atoms or highly intelligent quantic atoms and make them shine like tiny points of light to one day create new genetics through the power of the atom Nous.
<G-vec00179-001-s261><create.erschaffen><de> Wir besitzen ein schlafendes Potential... wenn wir wollten und wir einen eisernen Willen hätten, könnten wir diese normalen Atome in Super-Atome oder höchst intelligente, quantische Atome verwandeln und sie wie winzige Lichtpunkte leuchten lassen, um eines Tages mittels der Kraft des Atom Nous eine neue Genetik zu erschaffen.
<G-vec00179-001-s262><create.erschaffen><en> With the technology built into the glasses and special lenses, it's possible to create an authentic and interactive environment in real time.
<G-vec00179-001-s262><create.erschaffen><de> Durch die in den Brillen verbaute Technik und spezielle Linsen wird es möglich, eine authentisch wirkende und interaktive Umgebung in Echtzeit zu erschaffen.
<G-vec00179-001-s263><create.erschaffen><en> It should be relatively easy to create an OpenBSD port.
<G-vec00179-001-s263><create.erschaffen><de> Es sollte relativ einfach sein, einen OpenBSD-Port zu erschaffen.
<G-vec00179-001-s264><create.erschaffen><en> James Cameron's big-budget (and even bigger-grossing) films create unreal worlds all their own.
<G-vec00179-001-s264><create.erschaffen><de> James Camerons mit großem Budget (und noch größerem finanziellen Erfolg) gedrehte Filme erschaffen ihre ganz eigenen unwirklichen Welten.
<G-vec00179-001-s265><create.erschaffen><en> The mind has a basic habit, which is to create things.
<G-vec00179-001-s265><create.erschaffen><de> Der Geist hat eine grundlegende Gewohnheit: Dinge zu erschaffen.
<G-vec00001-001-s266><create.erstellen><en> Enter the cute world of FishAO, create your own fisherman or fishergirl, make and meet friends, and...
<G-vec00001-001-s266><create.erstellen><de> Betrete die süße Welt von FishAO, erstelle deine eigenen Fischer oder Fischerin, treffe Freunde und...
<G-vec00001-001-s267><create.erstellen><en> Create metrics files and Create a FOP userconfig file: Brought up to date with FOP 0.93.
<G-vec00001-001-s267><create.erstellen><de> PV Erstelle Metric-Dateien und Erstelle eine FOP-Benutzerkonfigurationsdatei: Auf aktuellen Stand mit FOP 0.93 gebracht.
<G-vec00001-001-s268><create.erstellen><en> Create metrics files and Create a FOP userconfig file: Brought up to date with FOP 0.93.
<G-vec00001-001-s268><create.erstellen><de> PV Erstelle Metric-Dateien und Erstelle eine FOP-Benutzerkonfigurationsdatei: Auf aktuellen Stand mit FOP 0.93 gebracht.
<G-vec00001-001-s269><create.erstellen><en> To see more from Tasty on Facebook, log in or create an account.
<G-vec00001-001-s269><create.erstellen><de> Um auf Facebook mehr von Tasty zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s270><create.erstellen><en> To see more from Mary Fonden on Facebook, log in or create an account.
<G-vec00001-001-s270><create.erstellen><de> Um auf Facebook mehr von Juta Spiza zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s271><create.erstellen><en> To see more from Çağdaş Market on Facebook, log in or create an account.
<G-vec00001-001-s271><create.erstellen><de> Um auf Facebook mehr von Çağdaş Market zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s272><create.erstellen><en> Create your own high resolution device mockups.
<G-vec00001-001-s272><create.erstellen><de> Erstelle dein eigenes hochauflösendes Device Mockup.
<G-vec00001-001-s273><create.erstellen><en> To see more from コネクシオ株式会社 on Facebook, log in or create an account.
<G-vec00001-001-s273><create.erstellen><de> Um auf Facebook mehr von ALMADOTaiwan zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s274><create.erstellen><en> Based on your requirements I will create the adequate pictorial world.
<G-vec00001-001-s274><create.erstellen><de> Basierend auf Ihren Anforderungen erstelle ich die gewünschten Bilderwelten und Motive.
<G-vec00001-001-s275><create.erstellen><en> To see more from Kspエンジニアリング on Facebook, log in or create an account.
<G-vec00001-001-s275><create.erstellen><de> Um auf Facebook mehr von 震飛龍 zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s276><create.erstellen><en> Create a new component.
<G-vec00001-001-s276><create.erstellen><de> Erstelle ein neues Bauteil.
<G-vec00001-001-s277><create.erstellen><en> To see more from Polyvalence on Facebook, log in or create an account.
<G-vec00001-001-s277><create.erstellen><de> Um auf Facebook mehr von KENZO zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s278><create.erstellen><en> Create a Memoji of yourself.
<G-vec00001-001-s278><create.erstellen><de> Erstelle ein Memoji von dir selbst.
<G-vec00001-001-s279><create.erstellen><en> To see more from IndiaClub Jakarta on Facebook, log in or create an account.
<G-vec00001-001-s279><create.erstellen><de> Um auf Facebook mehr von IndiaClub Jakarta zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00001-001-s280><create.erstellen><en> Create an account for your organization.
<G-vec00001-001-s280><create.erstellen><de> Erstelle einen Account für deine Organisation.
<G-vec00001-001-s281><create.erstellen><en> Just create a packing list for the trip Â and book the ticket.
<G-vec00001-001-s281><create.erstellen><de> Erstelle eine Packliste für die Reise und buche ein Ticket.
<G-vec00001-001-s282><create.erstellen><en> With a global community of over 100 million registered players, you will enjoy all aspects of managing a soccer club; create and train your team, bid for talented players in the live transfer market and compete with other managers in League, Cup and Champions League fixtures.
<G-vec00001-001-s282><create.erstellen><de> Mit einer Gemeinde von über 100 Millionen registrierten Spielern, wirst du alle Aspekte des Manager-Daseins genießen; erstelle und trainiere deine Mannschaft, biete um talentierte Spieler im Live-Transfermarkt und streite mit anderen Managern in der Liga, Champions League und im Pokal mit.
<G-vec00001-001-s283><create.erstellen><en> The idea of the course is to offer students the necessary guidance to create a sadhana, or practice of Integral Yoga Hatha it to include all the aforementioned aspects of traditional Hatha Yoga.
<G-vec00001-001-s283><create.erstellen><de> Die Idee des Kurses ist es, Studenten bieten die erforderlichen Leitlinien erstelle ich eine Sadhana oder Praxis des Integralen Yoga Hatha Es sollen alle genannten Aspekte des traditionellen Hatha-Yoga.
<G-vec00001-001-s284><create.erstellen><en> There are all colors of the rainbow to create your rainbow pony.
<G-vec00001-001-s284><create.erstellen><de> Es gibt alle Farben des Regenbogens Erstelle dein Regenbogen Pony.
<G-vec00179-001-s266><create.erstellen><en> Enter the cute world of FishAO, create your own fisherman or fishergirl, make and meet friends, and...
<G-vec00179-001-s266><create.erstellen><de> Betrete die süße Welt von FishAO, erstelle deine eigenen Fischer oder Fischerin, treffe Freunde und...
<G-vec00179-001-s267><create.erstellen><en> Create metrics files and Create a FOP userconfig file: Brought up to date with FOP 0.93.
<G-vec00179-001-s267><create.erstellen><de> PV Erstelle Metric-Dateien und Erstelle eine FOP-Benutzerkonfigurationsdatei: Auf aktuellen Stand mit FOP 0.93 gebracht.
<G-vec00179-001-s268><create.erstellen><en> Create metrics files and Create a FOP userconfig file: Brought up to date with FOP 0.93.
<G-vec00179-001-s268><create.erstellen><de> PV Erstelle Metric-Dateien und Erstelle eine FOP-Benutzerkonfigurationsdatei: Auf aktuellen Stand mit FOP 0.93 gebracht.
<G-vec00179-001-s269><create.erstellen><en> To see more from Tasty on Facebook, log in or create an account.
<G-vec00179-001-s269><create.erstellen><de> Um auf Facebook mehr von Tasty zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s270><create.erstellen><en> To see more from Mary Fonden on Facebook, log in or create an account.
<G-vec00179-001-s270><create.erstellen><de> Um auf Facebook mehr von Juta Spiza zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s271><create.erstellen><en> To see more from Çağdaş Market on Facebook, log in or create an account.
<G-vec00179-001-s271><create.erstellen><de> Um auf Facebook mehr von Çağdaş Market zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s272><create.erstellen><en> Create your own high resolution device mockups.
<G-vec00179-001-s272><create.erstellen><de> Erstelle dein eigenes hochauflösendes Device Mockup.
<G-vec00179-001-s273><create.erstellen><en> To see more from コネクシオ株式会社 on Facebook, log in or create an account.
<G-vec00179-001-s273><create.erstellen><de> Um auf Facebook mehr von ALMADOTaiwan zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s274><create.erstellen><en> Based on your requirements I will create the adequate pictorial world.
<G-vec00179-001-s274><create.erstellen><de> Basierend auf Ihren Anforderungen erstelle ich die gewünschten Bilderwelten und Motive.
<G-vec00179-001-s275><create.erstellen><en> To see more from Kspエンジニアリング on Facebook, log in or create an account.
<G-vec00179-001-s275><create.erstellen><de> Um auf Facebook mehr von 震飛龍 zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s276><create.erstellen><en> Create a new component.
<G-vec00179-001-s276><create.erstellen><de> Erstelle ein neues Bauteil.
<G-vec00179-001-s277><create.erstellen><en> To see more from Polyvalence on Facebook, log in or create an account.
<G-vec00179-001-s277><create.erstellen><de> Um auf Facebook mehr von KENZO zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s278><create.erstellen><en> Create a Memoji of yourself.
<G-vec00179-001-s278><create.erstellen><de> Erstelle ein Memoji von dir selbst.
<G-vec00179-001-s279><create.erstellen><en> To see more from IndiaClub Jakarta on Facebook, log in or create an account.
<G-vec00179-001-s279><create.erstellen><de> Um auf Facebook mehr von IndiaClub Jakarta zu sehen, melde dich an oder erstelle ein Konto.
<G-vec00179-001-s280><create.erstellen><en> Create an account for your organization.
<G-vec00179-001-s280><create.erstellen><de> Erstelle einen Account für deine Organisation.
<G-vec00179-001-s281><create.erstellen><en> Just create a packing list for the trip Â and book the ticket.
<G-vec00179-001-s281><create.erstellen><de> Erstelle eine Packliste für die Reise und buche ein Ticket.
<G-vec00179-001-s282><create.erstellen><en> With a global community of over 100 million registered players, you will enjoy all aspects of managing a soccer club; create and train your team, bid for talented players in the live transfer market and compete with other managers in League, Cup and Champions League fixtures.
<G-vec00179-001-s282><create.erstellen><de> Mit einer Gemeinde von über 100 Millionen registrierten Spielern, wirst du alle Aspekte des Manager-Daseins genießen; erstelle und trainiere deine Mannschaft, biete um talentierte Spieler im Live-Transfermarkt und streite mit anderen Managern in der Liga, Champions League und im Pokal mit.
<G-vec00179-001-s283><create.erstellen><en> The idea of the course is to offer students the necessary guidance to create a sadhana, or practice of Integral Yoga Hatha it to include all the aforementioned aspects of traditional Hatha Yoga.
<G-vec00179-001-s283><create.erstellen><de> Die Idee des Kurses ist es, Studenten bieten die erforderlichen Leitlinien erstelle ich eine Sadhana oder Praxis des Integralen Yoga Hatha Es sollen alle genannten Aspekte des traditionellen Hatha-Yoga.
<G-vec00179-001-s284><create.erstellen><en> There are all colors of the rainbow to create your rainbow pony.
<G-vec00179-001-s284><create.erstellen><de> Es gibt alle Farben des Regenbogens Erstelle dein Regenbogen Pony.
<G-vec00001-001-s285><create.erstellen><en> Adding to this, you have the ability to create many types of forms, including:
<G-vec00001-001-s285><create.erstellen><de> Außerdem hast Du die Möglichkeit, viele verschiedene Formulare zu erstellen, einschließlich: Pop-ups.
<G-vec00001-001-s286><create.erstellen><en> Public now the translation of a very interesting article found a few days ago on how to create custom styles per le custom gallery di Flickr.
<G-vec00001-001-s286><create.erstellen><de> Öffentliche nun die Übersetzung der ein sehr interessanter Artikel vor ein paar Tagen zum Erstellen gefunden benutzerdefinierte Stile per le benutzerdefinierte Galerie di Flickr.
<G-vec00001-001-s287><create.erstellen><en> The elements you add to create your website . Blocks
<G-vec00001-001-s287><create.erstellen><de> Es sond Elemente die Sie hinzufügen um Ihre Homepage zu erstellen .
<G-vec00001-001-s288><create.erstellen><en> You can create portfolios in various ways at justETF.
<G-vec00001-001-s288><create.erstellen><de> Portfolios erstellen können Sie bei justETF auf verschiedene Arten.
<G-vec00001-001-s289><create.erstellen><en> If most of Wettingen had belonged to the abbey back then, it would be possible to create a list of all domiciled genders on the basis of this document.
<G-vec00001-001-s289><create.erstellen><de> Hätte damals schon praktisch ganz Wettingen dem Kloster gehört, müsste sich auf der Basis dieser Urkunde eine Liste der ansässigen Geschlechter erstellen lassen.
<G-vec00001-001-s290><create.erstellen><en> Entries of associations of the SQD file in the Windows Registry may be incorrect In this case, you can try to delete the file for the extension of the SQD file and create it again.
<G-vec00001-001-s290><create.erstellen><de> Die Einträge über die Verknüpfungen der SQD- Datei im Windowsregister können falsch sein In solchem Fall können Sie versuchen die Datei zu löschen, die die Dateiextension SQD betrifft, und sie erneut erstellen.
<G-vec00001-001-s291><create.erstellen><en> Flipping helps you create beautiful patterns and shift image’s focus.
<G-vec00001-001-s291><create.erstellen><de> Flipping hilft Ihnen, schöne Muster und Shift-Bild Fokus erstellen.
<G-vec00001-001-s292><create.erstellen><en> In this scenario, when you create a machine catalog, you can specify the VDA version installed on the machines.
<G-vec00001-001-s292><create.erstellen><de> In diesem Fall können Sie beim Erstellen eines Maschinenkatalogs die auf den Maschinen installierte VDA-Version angeben.
<G-vec00001-001-s293><create.erstellen><en> Easily create a lot of folders based on the values in selected cells...
<G-vec00001-001-s293><create.erstellen><de> Schnell viele Ordner auf Basis der Werte in markierten Zellen erstellen...
<G-vec00001-001-s294><create.erstellen><en> Besides, Fotolr Photo Album-photo transfer and manager enables you to create different photo albums as you want, which can help classified your photos methodically.
<G-vec00001-001-s294><create.erstellen><de> Außerdem, Fotolr Photo Album-Foto-Transfer und Manager können Sie verschiedene Fotoalben erstellen, wie Sie wollen, die Ihre Fotos helfen können methodisch klassifiziert.
<G-vec00001-001-s295><create.erstellen><en> Create or function a number of drills to get rid of subterranean oil and gas, or eliminate key products regarding evaluating during gas and acrylic research .
<G-vec00001-001-s295><create.erstellen><de> Erstellen oder eine Reihe von Bohrern arbeiten, um loszuwerden, von unterirdischen Öl- und Gas, oder Schlüsselprodukte eliminieren während Gas und Acryl-Forschung in Bezug auf die Bewertung.
<G-vec00001-001-s296><create.erstellen><en> Click Create to create the specified data object:
<G-vec00001-001-s296><create.erstellen><de> Klicken Sie Erstellen um die Erstellung abzuschließen.
<G-vec00001-001-s297><create.erstellen><en> We collect this information in order to make strategic decisions on the one hand and to create relevant marketing material for our sales people and our customers on the other.
<G-vec00001-001-s297><create.erstellen><de> Wir sammeln diese Informationen, um einerseits strategische Entscheidungen treffen und andererseits relevantes Marketingmaterial für unsere Verkäuferinnen und Verkäufer und für die Kundinnen und Kunden erstellen zu können.
<G-vec00001-001-s298><create.erstellen><en> Click private table at the bottom of the Lobby view, select your preferred settings for the table, choose a password and click 'Create'.
<G-vec00001-001-s298><create.erstellen><de> "Klicken Sie auf den entsprechenden Button am unteren Rand der Lobby, wählen Sie die gewünschten Einstellungen für den Tisch, wählen Sie ein Passwort und klicken Sie auf ""Erstellen""."
<G-vec00001-001-s299><create.erstellen><en> When you create a team, you can pay for multiple user accounts upfront during checkout, and then invite people to join your team and fill those seats.
<G-vec00001-001-s299><create.erstellen><de> Wenn Sie ein Team erstellen, können Sie während des Bezahlvorgangs mehrere Benutzerkonten vorab kaufen und dann Personen einladen, Ihrem Team beizutreten und diese Plätze zu belegen.
<G-vec00001-001-s300><create.erstellen><en> Specialized in clinical studies, our employees create innovative and user-friendly label solutions.
<G-vec00001-001-s300><create.erstellen><de> Auf klinische Studien spezialisiert, erstellen unsere Mitarbeiter innovative und anwenderfreundliche Kennzeichnungslösungen.
<G-vec00001-001-s301><create.erstellen><en> That's when the idea for Jimdo was born: Create a tool that makes building your own website fun.
<G-vec00001-001-s301><create.erstellen><de> Da war die Idee geboren: Ein Baukasten, mit dem es einfach Spaß macht, großartige Websites zu erstellen.
<G-vec00001-001-s302><create.erstellen><en> Sen, it changes completely and it is constructed using the revision control system to deploy a firewall configuration can create one or more machines.
<G-vec00001-001-s302><create.erstellen><de> Sen, ändert sie vollständig und ist unter Verwendung der Revisions-Kontrollsystem, eine Firewall-Konfiguration kann eine oder mehrere Maschinen erstellen bereitstellen.
<G-vec00001-001-s303><create.erstellen><en> Creating and viewing reports requires the Create reports and See process permissions, see Restricting access to processes.
<G-vec00001-001-s303><create.erstellen><de> Das Erstellen und Anzeigen der Reporte erfordert Berechtigungen für Report erstellen und Prozess sehen, siehe Abschnitt Zugriff auf Prozesse einschränken.
<G-vec00179-001-s285><create.erstellen><en> Adding to this, you have the ability to create many types of forms, including:
<G-vec00179-001-s285><create.erstellen><de> Außerdem hast Du die Möglichkeit, viele verschiedene Formulare zu erstellen, einschließlich: Pop-ups.
<G-vec00179-001-s286><create.erstellen><en> Public now the translation of a very interesting article found a few days ago on how to create custom styles per le custom gallery di Flickr.
<G-vec00179-001-s286><create.erstellen><de> Öffentliche nun die Übersetzung der ein sehr interessanter Artikel vor ein paar Tagen zum Erstellen gefunden benutzerdefinierte Stile per le benutzerdefinierte Galerie di Flickr.
<G-vec00179-001-s287><create.erstellen><en> The elements you add to create your website . Blocks
<G-vec00179-001-s287><create.erstellen><de> Es sond Elemente die Sie hinzufügen um Ihre Homepage zu erstellen .
<G-vec00179-001-s288><create.erstellen><en> You can create portfolios in various ways at justETF.
<G-vec00179-001-s288><create.erstellen><de> Portfolios erstellen können Sie bei justETF auf verschiedene Arten.
<G-vec00179-001-s289><create.erstellen><en> If most of Wettingen had belonged to the abbey back then, it would be possible to create a list of all domiciled genders on the basis of this document.
<G-vec00179-001-s289><create.erstellen><de> Hätte damals schon praktisch ganz Wettingen dem Kloster gehört, müsste sich auf der Basis dieser Urkunde eine Liste der ansässigen Geschlechter erstellen lassen.
<G-vec00179-001-s290><create.erstellen><en> Entries of associations of the SQD file in the Windows Registry may be incorrect In this case, you can try to delete the file for the extension of the SQD file and create it again.
<G-vec00179-001-s290><create.erstellen><de> Die Einträge über die Verknüpfungen der SQD- Datei im Windowsregister können falsch sein In solchem Fall können Sie versuchen die Datei zu löschen, die die Dateiextension SQD betrifft, und sie erneut erstellen.
<G-vec00179-001-s291><create.erstellen><en> Flipping helps you create beautiful patterns and shift image’s focus.
<G-vec00179-001-s291><create.erstellen><de> Flipping hilft Ihnen, schöne Muster und Shift-Bild Fokus erstellen.
<G-vec00179-001-s292><create.erstellen><en> In this scenario, when you create a machine catalog, you can specify the VDA version installed on the machines.
<G-vec00179-001-s292><create.erstellen><de> In diesem Fall können Sie beim Erstellen eines Maschinenkatalogs die auf den Maschinen installierte VDA-Version angeben.
<G-vec00179-001-s293><create.erstellen><en> Easily create a lot of folders based on the values in selected cells...
<G-vec00179-001-s293><create.erstellen><de> Schnell viele Ordner auf Basis der Werte in markierten Zellen erstellen...
<G-vec00179-001-s294><create.erstellen><en> Besides, Fotolr Photo Album-photo transfer and manager enables you to create different photo albums as you want, which can help classified your photos methodically.
<G-vec00179-001-s294><create.erstellen><de> Außerdem, Fotolr Photo Album-Foto-Transfer und Manager können Sie verschiedene Fotoalben erstellen, wie Sie wollen, die Ihre Fotos helfen können methodisch klassifiziert.
<G-vec00179-001-s295><create.erstellen><en> Create or function a number of drills to get rid of subterranean oil and gas, or eliminate key products regarding evaluating during gas and acrylic research .
<G-vec00179-001-s295><create.erstellen><de> Erstellen oder eine Reihe von Bohrern arbeiten, um loszuwerden, von unterirdischen Öl- und Gas, oder Schlüsselprodukte eliminieren während Gas und Acryl-Forschung in Bezug auf die Bewertung.
<G-vec00179-001-s296><create.erstellen><en> Click Create to create the specified data object:
<G-vec00179-001-s296><create.erstellen><de> Klicken Sie Erstellen um die Erstellung abzuschließen.
<G-vec00179-001-s297><create.erstellen><en> We collect this information in order to make strategic decisions on the one hand and to create relevant marketing material for our sales people and our customers on the other.
<G-vec00179-001-s297><create.erstellen><de> Wir sammeln diese Informationen, um einerseits strategische Entscheidungen treffen und andererseits relevantes Marketingmaterial für unsere Verkäuferinnen und Verkäufer und für die Kundinnen und Kunden erstellen zu können.
<G-vec00179-001-s298><create.erstellen><en> Click private table at the bottom of the Lobby view, select your preferred settings for the table, choose a password and click 'Create'.
<G-vec00179-001-s298><create.erstellen><de> "Klicken Sie auf den entsprechenden Button am unteren Rand der Lobby, wählen Sie die gewünschten Einstellungen für den Tisch, wählen Sie ein Passwort und klicken Sie auf ""Erstellen""."
<G-vec00179-001-s299><create.erstellen><en> When you create a team, you can pay for multiple user accounts upfront during checkout, and then invite people to join your team and fill those seats.
<G-vec00179-001-s299><create.erstellen><de> Wenn Sie ein Team erstellen, können Sie während des Bezahlvorgangs mehrere Benutzerkonten vorab kaufen und dann Personen einladen, Ihrem Team beizutreten und diese Plätze zu belegen.
<G-vec00179-001-s300><create.erstellen><en> Specialized in clinical studies, our employees create innovative and user-friendly label solutions.
<G-vec00179-001-s300><create.erstellen><de> Auf klinische Studien spezialisiert, erstellen unsere Mitarbeiter innovative und anwenderfreundliche Kennzeichnungslösungen.
<G-vec00179-001-s301><create.erstellen><en> That's when the idea for Jimdo was born: Create a tool that makes building your own website fun.
<G-vec00179-001-s301><create.erstellen><de> Da war die Idee geboren: Ein Baukasten, mit dem es einfach Spaß macht, großartige Websites zu erstellen.
<G-vec00179-001-s302><create.erstellen><en> Sen, it changes completely and it is constructed using the revision control system to deploy a firewall configuration can create one or more machines.
<G-vec00179-001-s302><create.erstellen><de> Sen, ändert sie vollständig und ist unter Verwendung der Revisions-Kontrollsystem, eine Firewall-Konfiguration kann eine oder mehrere Maschinen erstellen bereitstellen.
<G-vec00179-001-s303><create.erstellen><en> Creating and viewing reports requires the Create reports and See process permissions, see Restricting access to processes.
<G-vec00179-001-s303><create.erstellen><de> Das Erstellen und Anzeigen der Reporte erfordert Berechtigungen für Report erstellen und Prozess sehen, siehe Abschnitt Zugriff auf Prozesse einschränken.
<G-vec00001-001-s304><create.erstellen><en> Run the affiliate programs: Select the promoting method, get your HTML code or create your own link.
<G-vec00001-001-s304><create.erstellen><de> Führen Sie die Partnerprogramme: Wählen Sie die Förderungsmethode, erhalten Sie Ihren HTML- Code oder erstellen Sie Ihren eigenen Link.
<G-vec00001-001-s305><create.erstellen><en> Or create your own package.
<G-vec00001-001-s305><create.erstellen><de> Oder erstellen Sie Ihr eigenes Paket.
<G-vec00001-001-s306><create.erstellen><en> CoffeeCup Responsive Site Designer - Create responsive Web sites in a WYSIWYG environment.
<G-vec00001-001-s306><create.erstellen><de> CoffeeCup Responsive Site Designer - Erstellen Sie ansprechende Webseiten in einer WYSIWYG-Umgebung.
<G-vec00001-001-s307><create.erstellen><en> Easily create the most beautiful photo greeting cards online with just a few clicks.
<G-vec00001-001-s307><create.erstellen><de> Erstellen Sie Ihre schönsten Fotogrusskarten mit wenigen Klicks einfach online.
<G-vec00001-001-s308><create.erstellen><en> Create concept diagram for showing the relationships among concepts.
<G-vec00001-001-s308><create.erstellen><de> Erstellen Sie Konzeptkarte für Darstellung der Beziehungen zwischen Konzepten.
<G-vec00001-001-s309><create.erstellen><en> Create and print a sophisticated, finished document from multiple files in real time.
<G-vec00001-001-s309><create.erstellen><de> Erstellen Sie komplexe, druckfertige Dokumente anhand von mehreren Dateien in Echtzeit.
<G-vec00001-001-s310><create.erstellen><en> Create the sales quote for customer 10000.
<G-vec00001-001-s310><create.erstellen><de> Erstellen Sie die Verkaufsquote für Kunden 10000.
<G-vec00001-001-s311><create.erstellen><en> Adjust the color temperature based on the ambient light or create a colored glow for extra atmosphere.
<G-vec00001-001-s311><create.erstellen><de> Passen Sie die Farbtemperatur basierend auf dem Umgebungslicht an oder erstellen Sie einen farbigen Schimmer für zusätzliche Atmosphäre.
<G-vec00001-001-s312><create.erstellen><en> "Create a storyboard that identifies recurring themes in ""The Black Cat""."
<G-vec00001-001-s312><create.erstellen><de> "Erstellen Sie ein Storyboard, das wiederkehrende Themen in ""The Black Cat"" identifiziert."
<G-vec00001-001-s313><create.erstellen><en> Convert Multiple FLV Files To MPEG or AVI Files Software - Create multiple MPEG or AVI files from multiple FLV files.
<G-vec00001-001-s313><create.erstellen><de> Convert Multiple FLV Files To MPEG or AVI Files Software - Erstellen Sie mehrere MPEG oder AVI -Dateien von mehreren FLV-Dateien.
<G-vec00001-001-s314><create.erstellen><en> Create a Samsung MDM License Key device policy with the keys and license information you received from Samsung.
<G-vec00001-001-s314><create.erstellen><de> Erstellen Sie eine Geräterichtlinie für Samsung-MDM-Lizenzschlüssel mit den Schlüsseln und Lizenzinformationen, die Sie von Samsung erhalten haben.
<G-vec00001-001-s315><create.erstellen><en> Create digital magazines, eBooks and interactive online documents that draw people in with audio, video, slideshows and animations.
<G-vec00001-001-s315><create.erstellen><de> Erstellen Sie digitale Magazine, eBooks und Online-Dokumente mit interaktivem Content wie Audio, Video, Dia-Shows oder Animationen, die Leser in ihren Bann ziehen.
<G-vec00001-001-s316><create.erstellen><en> Directly create campaigns, edit ads, and manage millions of keywords at once.
<G-vec00001-001-s316><create.erstellen><de> Erstellen Sie direkt Kampagnen, bearbeiten Sie Anzeigen, und verwalten Sie Millionen Keywords auf einmal.
<G-vec00001-001-s317><create.erstellen><en> Create either WinPE or Linux bootable media so you can start your machine from a CD/DVD or USB stick.
<G-vec00001-001-s317><create.erstellen><de> Erstellen Sie ein Boot-Medium auf WinPE- oder Linux-Basis, damit Sie Ihre Maschine jederzeit per CD/DVD oder USB-Stick starten können.
<G-vec00001-001-s318><create.erstellen><en> Create conversation notes that are subsequently available to your colleagues.
<G-vec00001-001-s318><create.erstellen><de> Erstellen Sie Gesprächsnotizen, die in der Folge auch für Ihre Kollegen verfügbar sind.
<G-vec00001-001-s319><create.erstellen><en> Develop coastal lands and create a beautiful archipelago made of recycled garbage.
<G-vec00001-001-s319><create.erstellen><de> Entwickeln Küste landet, und erstellen Sie eine wunderschöne Inselgruppe aus recyceltem Müll.
<G-vec00001-001-s320><create.erstellen><en> To make access to NIS maps harder for an attacker, create a random string for the DNS hostname, such as o7hfawtgmhwg.domain.com.
<G-vec00001-001-s320><create.erstellen><de> Um den Zugang zu NIS-Maps fr einen Angreifer zu erschweren, erstellen Sie einen zuflligen String fr den DNS-Hostnamen, wie zum Beispiel o7hfawtgmhwg.domain.com.
<G-vec00001-001-s321><create.erstellen><en> With Ecwid, you can change your store design as much as you want: use ready-made themes or create your own.
<G-vec00001-001-s321><create.erstellen><de> Mit Ecwid, Sie können Ihren Shop-Design, so viel wie Sie wollen, ändern: Verwenden Sie fertige Themen oder erstellen Sie Ihre eigenen.
<G-vec00001-001-s322><create.erstellen><en> Choose a preset promotion or create a customcampaign Commerce: a set of related components and activities used for promotions.
<G-vec00001-001-s322><create.erstellen><de> Wählen Sie eine vordefinierte Werbeaktion aus oder erstellen Sie eine kundenspezifischeKampagne Commerce: Das ist eine Reihe miteinander verbundener Komponenten und Aktivitäten, die für Aktionen dienen.
<G-vec00179-001-s304><create.erstellen><en> Run the affiliate programs: Select the promoting method, get your HTML code or create your own link.
<G-vec00179-001-s304><create.erstellen><de> Führen Sie die Partnerprogramme: Wählen Sie die Förderungsmethode, erhalten Sie Ihren HTML- Code oder erstellen Sie Ihren eigenen Link.
<G-vec00179-001-s305><create.erstellen><en> Or create your own package.
<G-vec00179-001-s305><create.erstellen><de> Oder erstellen Sie Ihr eigenes Paket.
<G-vec00179-001-s306><create.erstellen><en> CoffeeCup Responsive Site Designer - Create responsive Web sites in a WYSIWYG environment.
<G-vec00179-001-s306><create.erstellen><de> CoffeeCup Responsive Site Designer - Erstellen Sie ansprechende Webseiten in einer WYSIWYG-Umgebung.
<G-vec00179-001-s307><create.erstellen><en> Easily create the most beautiful photo greeting cards online with just a few clicks.
<G-vec00179-001-s307><create.erstellen><de> Erstellen Sie Ihre schönsten Fotogrusskarten mit wenigen Klicks einfach online.
<G-vec00179-001-s308><create.erstellen><en> Create concept diagram for showing the relationships among concepts.
<G-vec00179-001-s308><create.erstellen><de> Erstellen Sie Konzeptkarte für Darstellung der Beziehungen zwischen Konzepten.
<G-vec00179-001-s309><create.erstellen><en> Create and print a sophisticated, finished document from multiple files in real time.
<G-vec00179-001-s309><create.erstellen><de> Erstellen Sie komplexe, druckfertige Dokumente anhand von mehreren Dateien in Echtzeit.
<G-vec00179-001-s310><create.erstellen><en> Create the sales quote for customer 10000.
<G-vec00179-001-s310><create.erstellen><de> Erstellen Sie die Verkaufsquote für Kunden 10000.
<G-vec00179-001-s311><create.erstellen><en> Adjust the color temperature based on the ambient light or create a colored glow for extra atmosphere.
<G-vec00179-001-s311><create.erstellen><de> Passen Sie die Farbtemperatur basierend auf dem Umgebungslicht an oder erstellen Sie einen farbigen Schimmer für zusätzliche Atmosphäre.
<G-vec00179-001-s312><create.erstellen><en> "Create a storyboard that identifies recurring themes in ""The Black Cat""."
<G-vec00179-001-s312><create.erstellen><de> "Erstellen Sie ein Storyboard, das wiederkehrende Themen in ""The Black Cat"" identifiziert."
<G-vec00179-001-s313><create.erstellen><en> Convert Multiple FLV Files To MPEG or AVI Files Software - Create multiple MPEG or AVI files from multiple FLV files.
<G-vec00179-001-s313><create.erstellen><de> Convert Multiple FLV Files To MPEG or AVI Files Software - Erstellen Sie mehrere MPEG oder AVI -Dateien von mehreren FLV-Dateien.
<G-vec00179-001-s314><create.erstellen><en> Create a Samsung MDM License Key device policy with the keys and license information you received from Samsung.
<G-vec00179-001-s314><create.erstellen><de> Erstellen Sie eine Geräterichtlinie für Samsung-MDM-Lizenzschlüssel mit den Schlüsseln und Lizenzinformationen, die Sie von Samsung erhalten haben.
<G-vec00179-001-s315><create.erstellen><en> Create digital magazines, eBooks and interactive online documents that draw people in with audio, video, slideshows and animations.
<G-vec00179-001-s315><create.erstellen><de> Erstellen Sie digitale Magazine, eBooks und Online-Dokumente mit interaktivem Content wie Audio, Video, Dia-Shows oder Animationen, die Leser in ihren Bann ziehen.
<G-vec00179-001-s316><create.erstellen><en> Directly create campaigns, edit ads, and manage millions of keywords at once.
<G-vec00179-001-s316><create.erstellen><de> Erstellen Sie direkt Kampagnen, bearbeiten Sie Anzeigen, und verwalten Sie Millionen Keywords auf einmal.
<G-vec00179-001-s317><create.erstellen><en> Create either WinPE or Linux bootable media so you can start your machine from a CD/DVD or USB stick.
<G-vec00179-001-s317><create.erstellen><de> Erstellen Sie ein Boot-Medium auf WinPE- oder Linux-Basis, damit Sie Ihre Maschine jederzeit per CD/DVD oder USB-Stick starten können.
<G-vec00179-001-s318><create.erstellen><en> Create conversation notes that are subsequently available to your colleagues.
<G-vec00179-001-s318><create.erstellen><de> Erstellen Sie Gesprächsnotizen, die in der Folge auch für Ihre Kollegen verfügbar sind.
<G-vec00179-001-s319><create.erstellen><en> Develop coastal lands and create a beautiful archipelago made of recycled garbage.
<G-vec00179-001-s319><create.erstellen><de> Entwickeln Küste landet, und erstellen Sie eine wunderschöne Inselgruppe aus recyceltem Müll.
<G-vec00179-001-s320><create.erstellen><en> To make access to NIS maps harder for an attacker, create a random string for the DNS hostname, such as o7hfawtgmhwg.domain.com.
<G-vec00179-001-s320><create.erstellen><de> Um den Zugang zu NIS-Maps fr einen Angreifer zu erschweren, erstellen Sie einen zuflligen String fr den DNS-Hostnamen, wie zum Beispiel o7hfawtgmhwg.domain.com.
<G-vec00179-001-s321><create.erstellen><en> With Ecwid, you can change your store design as much as you want: use ready-made themes or create your own.
<G-vec00179-001-s321><create.erstellen><de> Mit Ecwid, Sie können Ihren Shop-Design, so viel wie Sie wollen, ändern: Verwenden Sie fertige Themen oder erstellen Sie Ihre eigenen.
<G-vec00179-001-s322><create.erstellen><en> Choose a preset promotion or create a customcampaign Commerce: a set of related components and activities used for promotions.
<G-vec00179-001-s322><create.erstellen><de> Wählen Sie eine vordefinierte Werbeaktion aus oder erstellen Sie eine kundenspezifischeKampagne Commerce: Das ist eine Reihe miteinander verbundener Komponenten und Aktivitäten, die für Aktionen dienen.
<G-vec00001-001-s323><create.erstellen><en> Use Enterprise Integration Patterns (EIPs)—the standard for enterprise connectivity—to easily create integrations from endpoints.
<G-vec00001-001-s323><create.erstellen><de> Mit EIPs (Enterprise Integration Patterns), dem Standard für Unternehmenskonnektivität, können Integrationen ausgehend von Endpunkten problemlos erstellt werden.
<G-vec00001-001-s324><create.erstellen><en> At this point, RTW Planner will validate your credit card, process the payment and create your booking.
<G-vec00001-001-s324><create.erstellen><de> An dieser Stelle wird Ihre Kreditkarte vom Round the World-Planner überprüft, die Zahlung verarbeitet und Ihre Buchung erstellt.
<G-vec00001-001-s325><create.erstellen><en> You may create any number of folders, subfolders and lists within your collection, but a particular object must exist only once within the whole collection.
<G-vec00001-001-s325><create.erstellen><de> Innerhalb dieser Sammlung können zwar beliebig viele Ordner, Unterordner und Listen erstellt werden, aber jedes Objekt kann in der ganzen Sammlung nur einmal existieren.
<G-vec00001-001-s326><create.erstellen><en> When a class is deactivated, you can no longer create objects that are instances of that class.
<G-vec00001-001-s326><create.erstellen><de> Wenn eine Klasse deaktiviert ist, können keine Objekte mehr erstellt werden, die Instanzen dieser Klasse sind.
<G-vec00001-001-s327><create.erstellen><en> iTunes will then create a duplicate version of the song you've selected.
<G-vec00001-001-s327><create.erstellen><de> iTunes erstellt dann eine doppelte Version des Songs Sie ausgewählt haben.
<G-vec00001-001-s328><create.erstellen><en> After students create their own storyboards about a particular person or about an important event in Black History, let them share their work and have a rich class discussion.
<G-vec00001-001-s328><create.erstellen><de> Nachdem die Schüler ihre eigenen Storyboards über eine bestimmte Person oder über ein wichtiges Ereignis in Black History erstellt haben, sollen sie ihre Arbeit teilen und eine reiche Klassen-Diskussion haben.
<G-vec00001-001-s329><create.erstellen><en> Joined by The Joker, Harley Quinn, Lex Luthor and others from the outrageous Injustice League, create and play as an all-new super-villain and uncover the true intentions of the Justice Syndicate!
<G-vec00001-001-s329><create.erstellen><de> Zusammen mit dem Joker, Harley Quinn, Lex Luthor und anderen aus den Reihen der ungeheuerlichen Injustice League erstellt ihr einen brandneuen Superschurken und findet mit diesem die wahren Beweggründe des geheimnisvollen Justice Syndicate heraus.
<G-vec00001-001-s330><create.erstellen><en> The project will create a set of incubators looking at how financial institutions can address the barriers to financing more positive social and environmental impacts.
<G-vec00001-001-s330><create.erstellen><de> Im Rahmen dieses Projekts werden sogenannte Inkubatoren erstellt, anhand derer evaluiert wird, wie Finanzinstitute die Hürden für Finanzierungen mit positiver Wirkung auf Gesellschaft und Umwelt bewältigen können.
<G-vec00001-001-s331><create.erstellen><en> We at G+H Schallschutz have decades of experience in the construction of acoustic measuring rooms, which we use to plan and create reverberation rooms to meet the precise requirements of our customers.
<G-vec00001-001-s331><create.erstellen><de> Auf Basis der jahrzehntelangen Erfahrung beim Bau von akustischen Messräumen, plant und erstellt G+H Hallräume, die individuelle Kundenanforderungen perfekt erfüllen.
<G-vec00001-001-s332><create.erstellen><en> Exclusive to ELEMNT ROAM, Route to Start is an on-device navigation feature that will find the shortest way back to the start of your ride and create turn-by-turn directions.
<G-vec00001-001-s332><create.erstellen><de> Route to Start ist eine exklusive Funktion für ELEMNT ROAM und eine Navigationsfunktion auf dem Gerät, die den kürzesten Weg zurück zum Start Ihrer Fahrt findet und Abbiegehinweise erstellt.
<G-vec00001-001-s333><create.erstellen><en> The data processed can be used to create pseudonymous usage profiles of users.
<G-vec00001-001-s333><create.erstellen><de> Dabei können aus den verarbeiteten Daten pseudonyme Nutzungsprofile der Nutzer erstellt werden.
<G-vec00001-001-s334><create.erstellen><en> In order to create a custom kernel configuration file and build a custom kernel, the full FreeBSD source tree must first be installed.
<G-vec00001-001-s334><create.erstellen><de> Bevor eine angepasste Kernelkonfigurationsdatei erstellt werden kann, muss zuerst der vollständige FreeBSD Quellcodebaum installiert werden.
<G-vec00001-001-s335><create.erstellen><en> To create a new virtual machine, only the images that correspond to the configured search template are used as source images.
<G-vec00001-001-s335><create.erstellen><de> Wenn eine neue virtuelle Maschine erstellt werden soll, werden als Quell-Images nur solche Images angezeigt werden, die dem hier konfigurierten Suchmuster entsprechen.
<G-vec00001-001-s336><create.erstellen><en> The review of the content of this web site does not create an attorney-client relationship with MALDJIAN LAW GROUP LLC, including its attorneys, agents or associates.
<G-vec00001-001-s336><create.erstellen><de> Die Überprüfung des Inhalts dieser Website erstellt ein Anwalt-Mandanten-Verhältnis nicht mit MALDJIAN LAW GROUP LLC, einschließlich seiner Anwälte, Agenten oder assoziierten Unternehmen.
<G-vec00001-001-s337><create.erstellen><en> And clicking the New Free button will create a new appointment showing time as free automatically.
<G-vec00001-001-s337><create.erstellen><de> Und klick den Neu Kostenlos Mit der Schaltfläche wird ein neuer Termin erstellt, der die Zeit automatisch als frei anzeigt.
<G-vec00001-001-s338><create.erstellen><en> For all large-scale translation projects, we use the SDL Trados Studio to create a dictionary of the specialist terminology and a translation memory (TM) of all the segments translated.
<G-vec00001-001-s338><create.erstellen><de> Für jedes größere Übersetzungsprojekt wird von uns im SDL Trados Studio ein Wörterbuch der verwendeten Fachterminologie und ein Translation Memory (TM) aus allen übersetzten Segmenten erstellt.
<G-vec00001-001-s339><create.erstellen><en> Create a buttongadget with a gtk stock image.
<G-vec00001-001-s339><create.erstellen><de> Erstellt ein ButtonGadget mit einem GTK stock image.
<G-vec00001-001-s340><create.erstellen><en> Automatically create a line of the same type as a chosen other line.
<G-vec00001-001-s340><create.erstellen><de> Erstellt automatisch eine Linie des gleichen Typs wie eine ausgewählte andere Linie.
<G-vec00001-001-s341><create.erstellen><en> So you create your own color profile, which can be repeatedly called.
<G-vec00001-001-s341><create.erstellen><de> So erstellt man sein eigenes Farbprofil, das dann immer wieder aufrufbar ist.
<G-vec00179-001-s323><create.erstellen><en> Use Enterprise Integration Patterns (EIPs)—the standard for enterprise connectivity—to easily create integrations from endpoints.
<G-vec00179-001-s323><create.erstellen><de> Mit EIPs (Enterprise Integration Patterns), dem Standard für Unternehmenskonnektivität, können Integrationen ausgehend von Endpunkten problemlos erstellt werden.
<G-vec00179-001-s324><create.erstellen><en> At this point, RTW Planner will validate your credit card, process the payment and create your booking.
<G-vec00179-001-s324><create.erstellen><de> An dieser Stelle wird Ihre Kreditkarte vom Round the World-Planner überprüft, die Zahlung verarbeitet und Ihre Buchung erstellt.
<G-vec00179-001-s325><create.erstellen><en> You may create any number of folders, subfolders and lists within your collection, but a particular object must exist only once within the whole collection.
<G-vec00179-001-s325><create.erstellen><de> Innerhalb dieser Sammlung können zwar beliebig viele Ordner, Unterordner und Listen erstellt werden, aber jedes Objekt kann in der ganzen Sammlung nur einmal existieren.
<G-vec00179-001-s326><create.erstellen><en> When a class is deactivated, you can no longer create objects that are instances of that class.
<G-vec00179-001-s326><create.erstellen><de> Wenn eine Klasse deaktiviert ist, können keine Objekte mehr erstellt werden, die Instanzen dieser Klasse sind.
<G-vec00179-001-s327><create.erstellen><en> iTunes will then create a duplicate version of the song you've selected.
<G-vec00179-001-s327><create.erstellen><de> iTunes erstellt dann eine doppelte Version des Songs Sie ausgewählt haben.
<G-vec00179-001-s328><create.erstellen><en> After students create their own storyboards about a particular person or about an important event in Black History, let them share their work and have a rich class discussion.
<G-vec00179-001-s328><create.erstellen><de> Nachdem die Schüler ihre eigenen Storyboards über eine bestimmte Person oder über ein wichtiges Ereignis in Black History erstellt haben, sollen sie ihre Arbeit teilen und eine reiche Klassen-Diskussion haben.
<G-vec00179-001-s329><create.erstellen><en> Joined by The Joker, Harley Quinn, Lex Luthor and others from the outrageous Injustice League, create and play as an all-new super-villain and uncover the true intentions of the Justice Syndicate!
<G-vec00179-001-s329><create.erstellen><de> Zusammen mit dem Joker, Harley Quinn, Lex Luthor und anderen aus den Reihen der ungeheuerlichen Injustice League erstellt ihr einen brandneuen Superschurken und findet mit diesem die wahren Beweggründe des geheimnisvollen Justice Syndicate heraus.
<G-vec00179-001-s330><create.erstellen><en> The project will create a set of incubators looking at how financial institutions can address the barriers to financing more positive social and environmental impacts.
<G-vec00179-001-s330><create.erstellen><de> Im Rahmen dieses Projekts werden sogenannte Inkubatoren erstellt, anhand derer evaluiert wird, wie Finanzinstitute die Hürden für Finanzierungen mit positiver Wirkung auf Gesellschaft und Umwelt bewältigen können.
<G-vec00179-001-s331><create.erstellen><en> We at G+H Schallschutz have decades of experience in the construction of acoustic measuring rooms, which we use to plan and create reverberation rooms to meet the precise requirements of our customers.
<G-vec00179-001-s331><create.erstellen><de> Auf Basis der jahrzehntelangen Erfahrung beim Bau von akustischen Messräumen, plant und erstellt G+H Hallräume, die individuelle Kundenanforderungen perfekt erfüllen.
<G-vec00179-001-s332><create.erstellen><en> Exclusive to ELEMNT ROAM, Route to Start is an on-device navigation feature that will find the shortest way back to the start of your ride and create turn-by-turn directions.
<G-vec00179-001-s332><create.erstellen><de> Route to Start ist eine exklusive Funktion für ELEMNT ROAM und eine Navigationsfunktion auf dem Gerät, die den kürzesten Weg zurück zum Start Ihrer Fahrt findet und Abbiegehinweise erstellt.
<G-vec00179-001-s333><create.erstellen><en> The data processed can be used to create pseudonymous usage profiles of users.
<G-vec00179-001-s333><create.erstellen><de> Dabei können aus den verarbeiteten Daten pseudonyme Nutzungsprofile der Nutzer erstellt werden.
<G-vec00179-001-s334><create.erstellen><en> In order to create a custom kernel configuration file and build a custom kernel, the full FreeBSD source tree must first be installed.
<G-vec00179-001-s334><create.erstellen><de> Bevor eine angepasste Kernelkonfigurationsdatei erstellt werden kann, muss zuerst der vollständige FreeBSD Quellcodebaum installiert werden.
<G-vec00179-001-s335><create.erstellen><en> To create a new virtual machine, only the images that correspond to the configured search template are used as source images.
<G-vec00179-001-s335><create.erstellen><de> Wenn eine neue virtuelle Maschine erstellt werden soll, werden als Quell-Images nur solche Images angezeigt werden, die dem hier konfigurierten Suchmuster entsprechen.
<G-vec00179-001-s336><create.erstellen><en> The review of the content of this web site does not create an attorney-client relationship with MALDJIAN LAW GROUP LLC, including its attorneys, agents or associates.
<G-vec00179-001-s336><create.erstellen><de> Die Überprüfung des Inhalts dieser Website erstellt ein Anwalt-Mandanten-Verhältnis nicht mit MALDJIAN LAW GROUP LLC, einschließlich seiner Anwälte, Agenten oder assoziierten Unternehmen.
<G-vec00179-001-s337><create.erstellen><en> And clicking the New Free button will create a new appointment showing time as free automatically.
<G-vec00179-001-s337><create.erstellen><de> Und klick den Neu Kostenlos Mit der Schaltfläche wird ein neuer Termin erstellt, der die Zeit automatisch als frei anzeigt.
<G-vec00179-001-s338><create.erstellen><en> For all large-scale translation projects, we use the SDL Trados Studio to create a dictionary of the specialist terminology and a translation memory (TM) of all the segments translated.
<G-vec00179-001-s338><create.erstellen><de> Für jedes größere Übersetzungsprojekt wird von uns im SDL Trados Studio ein Wörterbuch der verwendeten Fachterminologie und ein Translation Memory (TM) aus allen übersetzten Segmenten erstellt.
<G-vec00179-001-s339><create.erstellen><en> Create a buttongadget with a gtk stock image.
<G-vec00179-001-s339><create.erstellen><de> Erstellt ein ButtonGadget mit einem GTK stock image.
<G-vec00179-001-s340><create.erstellen><en> Automatically create a line of the same type as a chosen other line.
<G-vec00179-001-s340><create.erstellen><de> Erstellt automatisch eine Linie des gleichen Typs wie eine ausgewählte andere Linie.
<G-vec00179-001-s341><create.erstellen><en> So you create your own color profile, which can be repeatedly called.
<G-vec00179-001-s341><create.erstellen><de> So erstellt man sein eigenes Farbprofil, das dann immer wieder aufrufbar ist.
<G-vec00001-001-s361><create.erzeugen><en> Thankfully, we’ve got a comprehensive selection of stylish and practical napkins, tablecoverings, placemats and take-away products, which allow you to create a special atmosphere that is a magnet for guests.
<G-vec00001-001-s361><create.erzeugen><de> Zum Glück haben wir eine umfangreiche Auswahl an stilvollen und praktischen Servietten, Tischdecken, Tischsets und Take-away-Produkten, mit denen Sie eine besondere Atmosphäre erzeugen können, die Ihre Gäste magnetisch anziehen wird.
<G-vec00001-001-s362><create.erzeugen><en> Disclosed are a tungsten-copper alloy, a metal material having the same and a fabrication method for the tungsten-copper alloy, the fabrication method including generating tungsten-copper composite powders such that tungsten is coated on copper powders and the composition ratios of copper and tungsten are different, sequentially laminating the tungsten-copper composite powders to create a plurality of layers, having sequentially increasing or decreasing contents of tungsten, and sintering the plurality of layers under..
<G-vec00001-001-s362><create.erzeugen><de> Es handelt sich um eine Wolfram-Kupfer-Legierung, ein Metallmaterial mit demselben und ein Herstellungsverfahren für die Wolfram-Kupfer-Legierung, wobei das Herstellungsverfahren das Herstellen von Wolfram-Kupfer-Verbundpulvern umfasst, so dass Wolfram auf Kupferpulver und die Zusammensetzungsverhältnisse von Kupfer und Wolfram unterschiedlich sind, sequentielles Laminieren der Wolfram-Kupfer-Verbundpulver, um eine Vielzahl von Schichten zu erzeugen, die sequentiell zunehmende oder abnehmende Inhalte von Wolfram aufweisen, und das Sintern der Vielzahl von Schichten unter.
<G-vec00001-001-s363><create.erzeugen><en> If you want to change the data base already existing, you must first create Xdobry representation of schema.
<G-vec00001-001-s363><create.erzeugen><de> Falls Sie die bereits existierende Datenbank verändern wollen, müssen Sie zuerst die Xdobry Repräsentation der Schema erzeugen.
<G-vec00001-001-s364><create.erzeugen><en> This command allows you to create PostScript files.
<G-vec00001-001-s364><create.erzeugen><de> Ausgabe nach Postscript Dieser Befehl erlaubt es Ihnen, Postscript-Dateien zu erzeugen.
<G-vec00001-001-s365><create.erzeugen><en> It is a highly energy-packed construction material that bees produce and, with the aid of heat, use to create their highly regular honeycombs: cells that provide the space and protective shell for new life (breeding cells) and storage (honeycomb cells).
<G-vec00001-001-s365><create.erzeugen><de> Es ist ein energetisch hoch verdichteter, von Bienen erzeugter Baustoff, aus dem die Bienen mithilfe von Wärme ihre äußerst regelmäßigen Waben erzeugen: Zellen, die Raum und schützende Hülle geben für neues Leben (Brutzellen) und für die Vorratshaltung (Honigwaben).
<G-vec00001-001-s366><create.erzeugen><en> You can easily create a desktop link to a backup job from within the program, from which the backup job can be directly started by just double clicking it.
<G-vec00001-001-s366><create.erzeugen><de> Sie können aus dem Programm heraus Links auf Backup-Jobs erzeugen, über die Sie ganz einfach per Doppelklick das Backup starten können.
<G-vec00001-001-s367><create.erzeugen><en> Using this tool you can easily create a self extracting tar archive which extracts all necessary files to a temporary directory and calls the startup script.
<G-vec00001-001-s367><create.erzeugen><de> Man kann damit einfach ein selbstextrahierendes Tar-Archiv erzeugen, welches alle notwendigen Dateien in ein temporaeres Verzeichnis extrahiert und dann das Startscript aufruft.
<G-vec00001-001-s368><create.erzeugen><en> Even the seemingly increased plant stems in the vase to create the impression of water and glass.
<G-vec00001-001-s368><create.erzeugen><de> Auch die vergrößert erscheinenden Pflanzenstiele in der Vase erzeugen den Eindruck von Wasser und Glas.
<G-vec00001-001-s369><create.erzeugen><en> Its 2.70 m area comfortably handle several hours and in very harsh conditions, including high current boundary waves and when the waves create disturbing.
<G-vec00001-001-s369><create.erzeugen><de> Seine 2,70 m-Bereich bequem handhaben mehrere Stunden und in sehr harten Bedingungen, einschließlich hoher Strom Grenzwellen und wenn die Wellen erzeugen störend.
<G-vec00001-001-s370><create.erzeugen><en> When the framing box partially covers multiple snapshots, the sound of those snapshots is transformed to create a new sound.
<G-vec00001-001-s370><create.erzeugen><de> Liegt der Auswahlrahmen teilweise über mehreren Snapshots, wird der Klang dieser Snapshots transformiert, um einen neuen Klang zu erzeugen.
<G-vec00001-001-s371><create.erzeugen><en> A frontal projection onto five or seven parallel screens, stroboscopic effects, rapidly repetitive hypnotic or numbing visual patterns and sound frequencies with bass tones as low as -40 db, which the audience physiologically 'hears' through the body, combine to create an effect of conscious polarization and the removal of all perceptive distance from this stream of audio-visual data.
<G-vec00001-001-s371><create.erzeugen><de> Eine frontale Projektion auf 5-7 parallelen Leinwände, Stroboskopeffekte, schnelle repetitive Bildmuster, die hypnotisch oder auch betäubend wirken, und Soundfrequenzen mit Baßtönen bis zu –40 db, die der Zuhörer physiologisch mit dem Körper »hört«, erzeugen einen Effekt bewusster Polarisierung und Auslöschung jeglicher Wahrnehmungsdistanz zu diesem Strom audiovisueller Daten.
<G-vec00001-001-s372><create.erzeugen><en> Newer versions create some inexplicable communication problems and should therefore not be selected.
<G-vec00001-001-s372><create.erzeugen><de> Neuere Versionen erzeugen zum Teil unerklärliche Kommunikationsprobleme und sollten deshalb nicht gewählt werden.
<G-vec00001-001-s373><create.erzeugen><en> Over a length of more than 40 metres, these aluminium panels create a modern and almost futuristic visual impression.
<G-vec00001-001-s373><create.erzeugen><de> Auf einer Länge von über 40 Metern erzeugen die Aluminiumplatten einen modernen, fast schon futuristischen Eindruck.
<G-vec00001-001-s374><create.erzeugen><en> This technology is used to create special lighting effects inside airplanes and automobiles.
<G-vec00001-001-s374><create.erzeugen><de> Diese Technologie kommt zum Einsatz, um besondere Lichtstimmungen im Innenraum von Flugzeugen und Autos zu erzeugen.
<G-vec00001-001-s375><create.erzeugen><en> It must be affordable for all social classes to watch a match of Rapid in the stadium. Furthermore, it must, also in the new Weststadion, continue to be possible to create the passionate and emotional atmosphere that Rapid is famous for.
<G-vec00001-001-s375><create.erzeugen><de> Der Stadionbesuch bei Rapid muss für alle Gesellschaftsschichten leistbar sein und es muss weiterhin möglich bleiben, die leidenschaftliche und emotionale Atmosphäre, für die Rapid berühmt ist, auch im neuen »Weststadion« zu erzeugen.
<G-vec00001-001-s376><create.erzeugen><en> Through the OPT-4K-ASC4806-PL upgrade it is now possible to process 4K signals or create perspective PIPs.
<G-vec00001-001-s376><create.erzeugen><de> Durch das OPT-4K-ASC4806-PL Upgrade ist es nun auch möglich 4K Signale zu verarbeiten oder perspektivische PIPs zu erzeugen.
<G-vec00001-001-s377><create.erzeugen><en> Introduced in Firebird 2.0, CREATE OR ALTER EXCEPTION will create the exception if it does not already exist, or will alter the definition if it does, without affecting dependencies.
<G-vec00001-001-s377><create.erzeugen><de> Erzeugen oder ändern einer Exception In Firebird 2.0 eingeführt, erzeugt CREATE OR ALTER EXCEPTION eine Exception, wenn diese nicht schon vorhanden ist.
<G-vec00001-001-s378><create.erzeugen><en> As a very light anabolic steroid Anavar is not fit for bulking cycles or gaining stages; you will not create a vast amount of lean muscle mass cells through its usage when talking performance boosting functions; nonetheless, exactly what is created will certainly be solid muscle cells.
<G-vec00001-001-s378><create.erzeugen><de> Als ganz leicht anabole Steroide Anavar nicht passen Zyklen für Füllstoffe oder dem Erwerb von Stufen; Sie wird sicherlich nicht eine große Menge an mageren Muskelgewebe über seine Verwendung zu erzeugen, wenn der Effizienzsteigerung Ziele zu sprechen; dennoch, genau das, was geschaffen wird sicherlich solide Muskelmasse Gewebe sein.
<G-vec00001-001-s379><create.erzeugen><en> During the first stress phase, water temperature was slowly increased to create a mortality of at least 60% among a part of the mussels.
<G-vec00001-001-s379><create.erzeugen><de> Während einer ersten Stressphase wurde die Wassertemperatur langsam erhöht, um eine Mortalität von mindestens 60% unter den Muscheln zu erzeugen.
<G-vec00179-001-s361><create.erzeugen><en> Thankfully, we’ve got a comprehensive selection of stylish and practical napkins, tablecoverings, placemats and take-away products, which allow you to create a special atmosphere that is a magnet for guests.
<G-vec00179-001-s361><create.erzeugen><de> Zum Glück haben wir eine umfangreiche Auswahl an stilvollen und praktischen Servietten, Tischdecken, Tischsets und Take-away-Produkten, mit denen Sie eine besondere Atmosphäre erzeugen können, die Ihre Gäste magnetisch anziehen wird.
<G-vec00179-001-s362><create.erzeugen><en> Disclosed are a tungsten-copper alloy, a metal material having the same and a fabrication method for the tungsten-copper alloy, the fabrication method including generating tungsten-copper composite powders such that tungsten is coated on copper powders and the composition ratios of copper and tungsten are different, sequentially laminating the tungsten-copper composite powders to create a plurality of layers, having sequentially increasing or decreasing contents of tungsten, and sintering the plurality of layers under..
<G-vec00179-001-s362><create.erzeugen><de> Es handelt sich um eine Wolfram-Kupfer-Legierung, ein Metallmaterial mit demselben und ein Herstellungsverfahren für die Wolfram-Kupfer-Legierung, wobei das Herstellungsverfahren das Herstellen von Wolfram-Kupfer-Verbundpulvern umfasst, so dass Wolfram auf Kupferpulver und die Zusammensetzungsverhältnisse von Kupfer und Wolfram unterschiedlich sind, sequentielles Laminieren der Wolfram-Kupfer-Verbundpulver, um eine Vielzahl von Schichten zu erzeugen, die sequentiell zunehmende oder abnehmende Inhalte von Wolfram aufweisen, und das Sintern der Vielzahl von Schichten unter.
<G-vec00179-001-s363><create.erzeugen><en> If you want to change the data base already existing, you must first create Xdobry representation of schema.
<G-vec00179-001-s363><create.erzeugen><de> Falls Sie die bereits existierende Datenbank verändern wollen, müssen Sie zuerst die Xdobry Repräsentation der Schema erzeugen.
<G-vec00179-001-s364><create.erzeugen><en> This command allows you to create PostScript files.
<G-vec00179-001-s364><create.erzeugen><de> Ausgabe nach Postscript Dieser Befehl erlaubt es Ihnen, Postscript-Dateien zu erzeugen.
<G-vec00179-001-s365><create.erzeugen><en> It is a highly energy-packed construction material that bees produce and, with the aid of heat, use to create their highly regular honeycombs: cells that provide the space and protective shell for new life (breeding cells) and storage (honeycomb cells).
<G-vec00179-001-s365><create.erzeugen><de> Es ist ein energetisch hoch verdichteter, von Bienen erzeugter Baustoff, aus dem die Bienen mithilfe von Wärme ihre äußerst regelmäßigen Waben erzeugen: Zellen, die Raum und schützende Hülle geben für neues Leben (Brutzellen) und für die Vorratshaltung (Honigwaben).
<G-vec00179-001-s366><create.erzeugen><en> You can easily create a desktop link to a backup job from within the program, from which the backup job can be directly started by just double clicking it.
<G-vec00179-001-s366><create.erzeugen><de> Sie können aus dem Programm heraus Links auf Backup-Jobs erzeugen, über die Sie ganz einfach per Doppelklick das Backup starten können.
<G-vec00179-001-s367><create.erzeugen><en> Using this tool you can easily create a self extracting tar archive which extracts all necessary files to a temporary directory and calls the startup script.
<G-vec00179-001-s367><create.erzeugen><de> Man kann damit einfach ein selbstextrahierendes Tar-Archiv erzeugen, welches alle notwendigen Dateien in ein temporaeres Verzeichnis extrahiert und dann das Startscript aufruft.
<G-vec00179-001-s368><create.erzeugen><en> Even the seemingly increased plant stems in the vase to create the impression of water and glass.
<G-vec00179-001-s368><create.erzeugen><de> Auch die vergrößert erscheinenden Pflanzenstiele in der Vase erzeugen den Eindruck von Wasser und Glas.
<G-vec00179-001-s369><create.erzeugen><en> Its 2.70 m area comfortably handle several hours and in very harsh conditions, including high current boundary waves and when the waves create disturbing.
<G-vec00179-001-s369><create.erzeugen><de> Seine 2,70 m-Bereich bequem handhaben mehrere Stunden und in sehr harten Bedingungen, einschließlich hoher Strom Grenzwellen und wenn die Wellen erzeugen störend.
<G-vec00179-001-s370><create.erzeugen><en> When the framing box partially covers multiple snapshots, the sound of those snapshots is transformed to create a new sound.
<G-vec00179-001-s370><create.erzeugen><de> Liegt der Auswahlrahmen teilweise über mehreren Snapshots, wird der Klang dieser Snapshots transformiert, um einen neuen Klang zu erzeugen.
<G-vec00179-001-s371><create.erzeugen><en> A frontal projection onto five or seven parallel screens, stroboscopic effects, rapidly repetitive hypnotic or numbing visual patterns and sound frequencies with bass tones as low as -40 db, which the audience physiologically 'hears' through the body, combine to create an effect of conscious polarization and the removal of all perceptive distance from this stream of audio-visual data.
<G-vec00179-001-s371><create.erzeugen><de> Eine frontale Projektion auf 5-7 parallelen Leinwände, Stroboskopeffekte, schnelle repetitive Bildmuster, die hypnotisch oder auch betäubend wirken, und Soundfrequenzen mit Baßtönen bis zu –40 db, die der Zuhörer physiologisch mit dem Körper »hört«, erzeugen einen Effekt bewusster Polarisierung und Auslöschung jeglicher Wahrnehmungsdistanz zu diesem Strom audiovisueller Daten.
<G-vec00179-001-s372><create.erzeugen><en> Newer versions create some inexplicable communication problems and should therefore not be selected.
<G-vec00179-001-s372><create.erzeugen><de> Neuere Versionen erzeugen zum Teil unerklärliche Kommunikationsprobleme und sollten deshalb nicht gewählt werden.
<G-vec00179-001-s373><create.erzeugen><en> Over a length of more than 40 metres, these aluminium panels create a modern and almost futuristic visual impression.
<G-vec00179-001-s373><create.erzeugen><de> Auf einer Länge von über 40 Metern erzeugen die Aluminiumplatten einen modernen, fast schon futuristischen Eindruck.
<G-vec00179-001-s374><create.erzeugen><en> This technology is used to create special lighting effects inside airplanes and automobiles.
<G-vec00179-001-s374><create.erzeugen><de> Diese Technologie kommt zum Einsatz, um besondere Lichtstimmungen im Innenraum von Flugzeugen und Autos zu erzeugen.
<G-vec00179-001-s375><create.erzeugen><en> It must be affordable for all social classes to watch a match of Rapid in the stadium. Furthermore, it must, also in the new Weststadion, continue to be possible to create the passionate and emotional atmosphere that Rapid is famous for.
<G-vec00179-001-s375><create.erzeugen><de> Der Stadionbesuch bei Rapid muss für alle Gesellschaftsschichten leistbar sein und es muss weiterhin möglich bleiben, die leidenschaftliche und emotionale Atmosphäre, für die Rapid berühmt ist, auch im neuen »Weststadion« zu erzeugen.
<G-vec00179-001-s376><create.erzeugen><en> Through the OPT-4K-ASC4806-PL upgrade it is now possible to process 4K signals or create perspective PIPs.
<G-vec00179-001-s376><create.erzeugen><de> Durch das OPT-4K-ASC4806-PL Upgrade ist es nun auch möglich 4K Signale zu verarbeiten oder perspektivische PIPs zu erzeugen.
<G-vec00179-001-s377><create.erzeugen><en> Introduced in Firebird 2.0, CREATE OR ALTER EXCEPTION will create the exception if it does not already exist, or will alter the definition if it does, without affecting dependencies.
<G-vec00179-001-s377><create.erzeugen><de> Erzeugen oder ändern einer Exception In Firebird 2.0 eingeführt, erzeugt CREATE OR ALTER EXCEPTION eine Exception, wenn diese nicht schon vorhanden ist.
<G-vec00179-001-s378><create.erzeugen><en> As a very light anabolic steroid Anavar is not fit for bulking cycles or gaining stages; you will not create a vast amount of lean muscle mass cells through its usage when talking performance boosting functions; nonetheless, exactly what is created will certainly be solid muscle cells.
<G-vec00179-001-s378><create.erzeugen><de> Als ganz leicht anabole Steroide Anavar nicht passen Zyklen für Füllstoffe oder dem Erwerb von Stufen; Sie wird sicherlich nicht eine große Menge an mageren Muskelgewebe über seine Verwendung zu erzeugen, wenn der Effizienzsteigerung Ziele zu sprechen; dennoch, genau das, was geschaffen wird sicherlich solide Muskelmasse Gewebe sein.
<G-vec00179-001-s379><create.erzeugen><en> During the first stress phase, water temperature was slowly increased to create a mortality of at least 60% among a part of the mussels.
<G-vec00179-001-s379><create.erzeugen><de> Während einer ersten Stressphase wurde die Wassertemperatur langsam erhöht, um eine Mortalität von mindestens 60% unter den Muscheln zu erzeugen.
<G-vec00001-001-s380><create.erzeugen><en> Since 23 is telnet, this would create a secure telnet session through an SSH tunnel.
<G-vec00001-001-s380><create.erzeugen><de> Da der Port 23 für Telnet reserviert ist, erzeugt das eine sichere Telnet-Verbindung durch einen SSH-Tunnel.
<G-vec00001-001-s381><create.erzeugen><en> A request with the click of a mouse is all you need to create CNC programs for all individual parts and for fully-automatic nesting which is optimized for the selected panel material via the BetterNest software.
<G-vec00001-001-s381><create.erzeugen><de> Die Anforderung per Mausklick genügt und schon werden die CNC-Programme für alle Einzelteile erzeugt und vollautomatisch über die BetterNest-Software optimiert auf das gewählte Plattenmaterial verschachtelt.
<G-vec00001-001-s382><create.erzeugen><en> Managing increasingly complex electronic systems and industry standards such as automotive Ethernet create additional requirements for automotive testing, alongside security issues.
<G-vec00001-001-s382><create.erzeugen><de> Das Managen immer komplexer werdender elektronischer Systeme und Industriestandards wie Automotive Ethernet erzeugt neben Sicherheitsaspekten zusätzliche Anforderungen an Automotive-Tests.
<G-vec00001-001-s383><create.erzeugen><en> Based on this you can easily create your own extensions.
<G-vec00001-001-s383><create.erzeugen><de> Auf dieser Basis können sehr einfach weitere Erweiterungen erzeugt werden.
<G-vec00001-001-s384><create.erzeugen><en> This will help to create an atmosphere of cleanliness and to discourage negative energy from coming back.
<G-vec00001-001-s384><create.erzeugen><de> Dies erzeugt eine Atmosphäre der Sauberkeit und schreckt die negativen Energien davon ab zurückzukehren.
<G-vec00001-001-s385><create.erzeugen><en> Create an optimized version of the executable.
<G-vec00001-001-s385><create.erzeugen><de> Diese Option erzeugt eine optimierte Version der ausführbaren Datei.
<G-vec00001-001-s386><create.erzeugen><en> It is the first Camera Obscura building in Greece and the first one worldwide to create a panorama image.
<G-vec00001-001-s386><create.erzeugen><de> Es ist das erste Camera Obscura Gebäude von Griechenland, und das erste weltweit das ein panoramatisches Abbild erzeugt.
<G-vec00001-001-s387><create.erzeugen><en> This will demonstrate not only how to create and use the Entry widget but also how to define our own event handling functions and connect them to widgets.
<G-vec00001-001-s387><create.erzeugen><de> Dies wird nicht nur demonstrieren, wie man das Entry-Widget erzeugt und verwendet, sonden auch wie eigene Ereignisbehandlungsfunktionen definiert und mit den Widgets verbunden werden.
<G-vec00001-001-s388><create.erzeugen><en> On this web site you can create and check International Bank Account Numbers (IBAN).
<G-vec00001-001-s388><create.erzeugen><de> Auf dieser Webseite können Internationale Kontonummern (IBAN/International Bank Account Number) erzeugt und überprüft werden.
<G-vec00001-001-s389><create.erzeugen><en> they are used to create moods, especially with the colour orange.
<G-vec00001-001-s389><create.erzeugen><de> mit farben erzeugt man stimmungen, speziell mit dem farbton orange.
<G-vec00001-001-s390><create.erzeugen><en> "- The motion blur (temporal anti-aliasing): this technology can create a ""blur"" effect when an object is moving, a trail if you want."
<G-vec00001-001-s390><create.erzeugen><de> - Das motion blur (temporal anti-aliasing): Dieser Effekt erzeugt eine Unschärfe wenn sich ein Objekt im Bild bewegt, eine Art Bildschatten wenn man so will.
<G-vec00001-001-s391><create.erzeugen><en> The spatial nature of the sound patterns will create a response in your brain/mind/body that opens a doorway into the Fifth Perspective, and eventually you will find yourself in an expanded state of awareness.
<G-vec00001-001-s391><create.erzeugen><de> Die räumliche Natur der Klangmuster erzeugt in eurem Gehirn/Geist/Körper eine Reaktion, die eine Pforte zur Fünften Perspektive öffnet, und am Ende findet ihr euch in einem erweiterten Zustand des Gewahrseins wieder.
<G-vec00001-001-s392><create.erzeugen><en> They are each changing very quickly as they draw closer together, and create a balance that will bring harmony and peace to Earth.
<G-vec00001-001-s392><create.erzeugen><de> Beide verändern sich sehr rasch, während sie näher zueinander rücken, und das erzeugt ein Gleichgewicht, das Frieden und Harmonie zur Erde bringen wird.
<G-vec00001-001-s393><create.erzeugen><en> What does not create this sense of wellbeing in these two phenomena is an absolutely wrong food, is something that cannot be transformed or digested, but that on the contrary breaks down and undermines the organism's mental as well as bodily state.
<G-vec00001-001-s393><create.erzeugen><de> Etwas, das in diesen beiden Erscheinungen dieses Empfinden von Wohlbefinden nicht erzeugt, ist eine absolut falsche Nahrung, ist etwas, das nicht umgesetzt oder verdaut werden kann, sondern vielmehr sowohl den seelischen als auch den körperlichen Zustand des Organismus unterminiert und zerstört.
<G-vec00001-001-s394><create.erzeugen><en> This function will create an exact copy of the selected database.
<G-vec00001-001-s394><create.erzeugen><de> Duplizieren macht genau das: es erzeugt eine exakte Kopie der Database.
<G-vec00001-001-s395><create.erzeugen><en> The data type “2D: x/y/Label” will create the element if the channel type if text.
<G-vec00001-001-s395><create.erzeugen><de> Das Element wird von der Import-Funktion “2D: x/y/Label” erzeugt, wenn für den Label-Kanal ein Text-Kanal ausgewählt wird.
<G-vec00001-001-s396><create.erzeugen><en> As you roll the 01 across a surface, it can also create a 3D model of the item you’re measuring.
<G-vec00001-001-s396><create.erzeugen><de> Rollen Sie das 01 über eine Oberfläche, kann es auch ein 3D-Modell erzeugt von dem Element, das Sie Messen.
<G-vec00001-001-s397><create.erzeugen><en> The only downside is that it’s an extremely expensive chemical to produce. It’s also not overly hazardous despite being an oral steroid, it doesn’t create many adverse effects at all, and is fairly moderate on the natural endocrine system (for a steroid, that is).
<G-vec00001-001-s397><create.erzeugen><de> Es ist ebenfalls nicht übermäßig schädlich trotz einer Zahn Steroid ist, ist es nicht viele negative Effekte überhaupt nicht erzeugt, und auch einigermaßen Licht auf die natürliche Hormonsystem (für ein Steroid, das ist).
<G-vec00001-001-s398><create.erzeugen><en> More ice will create a thicker drink.
<G-vec00001-001-s398><create.erzeugen><de> Mehr Eis erzeugt ein dickeres Getränk.
<G-vec00179-001-s380><create.erzeugen><en> Since 23 is telnet, this would create a secure telnet session through an SSH tunnel.
<G-vec00179-001-s380><create.erzeugen><de> Da der Port 23 für Telnet reserviert ist, erzeugt das eine sichere Telnet-Verbindung durch einen SSH-Tunnel.
<G-vec00179-001-s381><create.erzeugen><en> A request with the click of a mouse is all you need to create CNC programs for all individual parts and for fully-automatic nesting which is optimized for the selected panel material via the BetterNest software.
<G-vec00179-001-s381><create.erzeugen><de> Die Anforderung per Mausklick genügt und schon werden die CNC-Programme für alle Einzelteile erzeugt und vollautomatisch über die BetterNest-Software optimiert auf das gewählte Plattenmaterial verschachtelt.
<G-vec00179-001-s382><create.erzeugen><en> Managing increasingly complex electronic systems and industry standards such as automotive Ethernet create additional requirements for automotive testing, alongside security issues.
<G-vec00179-001-s382><create.erzeugen><de> Das Managen immer komplexer werdender elektronischer Systeme und Industriestandards wie Automotive Ethernet erzeugt neben Sicherheitsaspekten zusätzliche Anforderungen an Automotive-Tests.
<G-vec00179-001-s383><create.erzeugen><en> Based on this you can easily create your own extensions.
<G-vec00179-001-s383><create.erzeugen><de> Auf dieser Basis können sehr einfach weitere Erweiterungen erzeugt werden.
<G-vec00179-001-s384><create.erzeugen><en> This will help to create an atmosphere of cleanliness and to discourage negative energy from coming back.
<G-vec00179-001-s384><create.erzeugen><de> Dies erzeugt eine Atmosphäre der Sauberkeit und schreckt die negativen Energien davon ab zurückzukehren.
<G-vec00179-001-s385><create.erzeugen><en> Create an optimized version of the executable.
<G-vec00179-001-s385><create.erzeugen><de> Diese Option erzeugt eine optimierte Version der ausführbaren Datei.
<G-vec00179-001-s386><create.erzeugen><en> It is the first Camera Obscura building in Greece and the first one worldwide to create a panorama image.
<G-vec00179-001-s386><create.erzeugen><de> Es ist das erste Camera Obscura Gebäude von Griechenland, und das erste weltweit das ein panoramatisches Abbild erzeugt.
<G-vec00179-001-s387><create.erzeugen><en> This will demonstrate not only how to create and use the Entry widget but also how to define our own event handling functions and connect them to widgets.
<G-vec00179-001-s387><create.erzeugen><de> Dies wird nicht nur demonstrieren, wie man das Entry-Widget erzeugt und verwendet, sonden auch wie eigene Ereignisbehandlungsfunktionen definiert und mit den Widgets verbunden werden.
<G-vec00179-001-s388><create.erzeugen><en> On this web site you can create and check International Bank Account Numbers (IBAN).
<G-vec00179-001-s388><create.erzeugen><de> Auf dieser Webseite können Internationale Kontonummern (IBAN/International Bank Account Number) erzeugt und überprüft werden.
<G-vec00179-001-s389><create.erzeugen><en> they are used to create moods, especially with the colour orange.
<G-vec00179-001-s389><create.erzeugen><de> mit farben erzeugt man stimmungen, speziell mit dem farbton orange.
<G-vec00179-001-s390><create.erzeugen><en> "- The motion blur (temporal anti-aliasing): this technology can create a ""blur"" effect when an object is moving, a trail if you want."
<G-vec00179-001-s390><create.erzeugen><de> - Das motion blur (temporal anti-aliasing): Dieser Effekt erzeugt eine Unschärfe wenn sich ein Objekt im Bild bewegt, eine Art Bildschatten wenn man so will.
<G-vec00179-001-s391><create.erzeugen><en> The spatial nature of the sound patterns will create a response in your brain/mind/body that opens a doorway into the Fifth Perspective, and eventually you will find yourself in an expanded state of awareness.
<G-vec00179-001-s391><create.erzeugen><de> Die räumliche Natur der Klangmuster erzeugt in eurem Gehirn/Geist/Körper eine Reaktion, die eine Pforte zur Fünften Perspektive öffnet, und am Ende findet ihr euch in einem erweiterten Zustand des Gewahrseins wieder.
<G-vec00179-001-s392><create.erzeugen><en> They are each changing very quickly as they draw closer together, and create a balance that will bring harmony and peace to Earth.
<G-vec00179-001-s392><create.erzeugen><de> Beide verändern sich sehr rasch, während sie näher zueinander rücken, und das erzeugt ein Gleichgewicht, das Frieden und Harmonie zur Erde bringen wird.
<G-vec00179-001-s393><create.erzeugen><en> What does not create this sense of wellbeing in these two phenomena is an absolutely wrong food, is something that cannot be transformed or digested, but that on the contrary breaks down and undermines the organism's mental as well as bodily state.
<G-vec00179-001-s393><create.erzeugen><de> Etwas, das in diesen beiden Erscheinungen dieses Empfinden von Wohlbefinden nicht erzeugt, ist eine absolut falsche Nahrung, ist etwas, das nicht umgesetzt oder verdaut werden kann, sondern vielmehr sowohl den seelischen als auch den körperlichen Zustand des Organismus unterminiert und zerstört.
<G-vec00179-001-s394><create.erzeugen><en> This function will create an exact copy of the selected database.
<G-vec00179-001-s394><create.erzeugen><de> Duplizieren macht genau das: es erzeugt eine exakte Kopie der Database.
<G-vec00179-001-s395><create.erzeugen><en> The data type “2D: x/y/Label” will create the element if the channel type if text.
<G-vec00179-001-s395><create.erzeugen><de> Das Element wird von der Import-Funktion “2D: x/y/Label” erzeugt, wenn für den Label-Kanal ein Text-Kanal ausgewählt wird.
<G-vec00179-001-s396><create.erzeugen><en> As you roll the 01 across a surface, it can also create a 3D model of the item you’re measuring.
<G-vec00179-001-s396><create.erzeugen><de> Rollen Sie das 01 über eine Oberfläche, kann es auch ein 3D-Modell erzeugt von dem Element, das Sie Messen.
<G-vec00179-001-s397><create.erzeugen><en> The only downside is that it’s an extremely expensive chemical to produce. It’s also not overly hazardous despite being an oral steroid, it doesn’t create many adverse effects at all, and is fairly moderate on the natural endocrine system (for a steroid, that is).
<G-vec00179-001-s397><create.erzeugen><de> Es ist ebenfalls nicht übermäßig schädlich trotz einer Zahn Steroid ist, ist es nicht viele negative Effekte überhaupt nicht erzeugt, und auch einigermaßen Licht auf die natürliche Hormonsystem (für ein Steroid, das ist).
<G-vec00179-001-s398><create.erzeugen><en> More ice will create a thicker drink.
<G-vec00179-001-s398><create.erzeugen><de> Mehr Eis erzeugt ein dickeres Getränk.
<G-vec00001-001-s418><create.schaffen><en> And whenever, through a huge effort, you actually get peace somewhere, you will want to create war somewhere else.
<G-vec00001-001-s418><create.schaffen><de> Und immer wenn irgendwo mit großem Aufwand Frieden geschaffen wird, macht man halt woanders einen kleinen Krieg.
<G-vec00001-001-s419><create.schaffen><en> The proposed measures will greatly benefit shipping as they will reduce costs, simplify administration, facilitate trade and create a level playing field between all types of transport.
<G-vec00001-001-s419><create.schaffen><de> Die vorgeschlagenen Maßnahmen werden sich eindeutig positiv auf die Schifffahrt auswirken, da durch sie die Kosten gesenkt, die Verwaltung vereinfacht, der Handel erleichtert und gleiche Wettbewerbsbedingungen für alle Verkehrsträger geschaffen werden.
<G-vec00001-001-s420><create.schaffen><en> """I’m certain that the standardized early data exchange between the process participants made possible by FAIR@Link will create great added value for everyone."
<G-vec00001-001-s420><create.schaffen><de> „Ich bin mir sicher, dass durch den standardisierten frühzeitigen Datenaustausch zwischen den Prozessbeteiligten, den FAIR@Link ermöglicht, ein großer Mehrwert für alle geschaffen wird.
<G-vec00001-001-s421><create.schaffen><en> Efficiency isn’t about more or less space, it’s about using the space you have to create a seamless workflow for people.
<G-vec00001-001-s421><create.schaffen><de> Bei Effizienz geht es nicht um mehr oder weniger Platz – es geht darum, den vorhandenen Platz so zu nutzen, dass für die Mitarbeiter ein nahtloser Arbeitsfluss geschaffen wird.
<G-vec00001-001-s422><create.schaffen><en> It is hoped that immigration’s problem will be solved by using supportive EU funds to create employment positions for migrants with qualifications.
<G-vec00001-001-s422><create.schaffen><de> Es ist zu hoffen, dass das Problem der Einwanderung gelöst wird, indem unterstützende EU-Mittel für Beschäftigungsmöglichkeiten von Einwanderern mit Qualifikationen geschaffen werden.
<G-vec00001-001-s423><create.schaffen><en> The goal is to create a concrete basis for developing further joint projects.
<G-vec00001-001-s423><create.schaffen><de> Damit soll eine konkrete Grundlage für die Entwicklung weiterführender gemeinsamer Projekte geschaffen werden.
<G-vec00001-001-s424><create.schaffen><en> These measures improve forage supply during the summer and create new habitats.
<G-vec00001-001-s424><create.schaffen><de> Damit werden das Nahrungsangebot im Sommer verbessert und neue Lebensräume geschaffen.
<G-vec00001-001-s425><create.schaffen><en> The linear connectors make it possible to create individual combinations and to dismantle them again easily.
<G-vec00001-001-s425><create.schaffen><de> Mittels Linearverbinder können individuelle Kombinationen geschaffen und leicht wieder auseinandergebaut werden.
<G-vec00001-001-s426><create.schaffen><en> This project sought to create a state of the art, comprehensive system solution to protect human lives and freight.
<G-vec00001-001-s426><create.schaffen><de> Um den Schutz von Menschen und Gütern sicherzustellen, sollte eine moderne, umfassende Systemlösung geschaffen werden.
<G-vec00001-001-s427><create.schaffen><en> We create clusters of villages, which pool their resources together to support a priest.
<G-vec00001-001-s427><create.schaffen><de> Wir haben Gruppen von Dörfern geschaffen, die mit vereinten Kräften für einen Priester aufkommen.
<G-vec00001-001-s428><create.schaffen><en> By offering a performance-based fee agreement, we create a win-win situation between the asset manager and the owner.
<G-vec00001-001-s428><create.schaffen><de> Über ein erfolgsabhängiges Honorarmodel wird immer eine Win-Win-Situation zwischen Asset Manager und Eigentümer geschaffen.
<G-vec00001-001-s429><create.schaffen><en> To celebrate Live's fifteenth birthday, Christian Kleine create a generative Live Set that you can download for free.
<G-vec00001-001-s429><create.schaffen><de> Um den fünfzehnten Geburtstag von Live zu feiern, hat Christian Kleine ein generatives Live Set geschaffen, das Du kostenlos herunterladen kannst.
<G-vec00001-001-s430><create.schaffen><en> Ancient beauty recipes combine with a state of the art organic cosmetics to create an innovative line exclusive to the VITA NOVA hotels, giving beauty and wellness to your skin.
<G-vec00001-001-s430><create.schaffen><de> Alte Schönheitsrezepte und modernste Biokosmetik in einer neuen Linie, die speziell für die VITA NOVA-Hotels geschaffen wurde, um Ihre Haut schöner und gesünder zu machen.
<G-vec00001-001-s431><create.schaffen><en> The aim of the study is to investigate whether the native tree species sengon can be used to rehabilitate degraded land and create economically profitable land-use alternatives to the establishment of palm oil plantations.
<G-vec00001-001-s431><create.schaffen><de> Ziel der Studie ist es, zu untersuchen, ob mithilfe der einheimischen Baumart Sengon degradierte Flächen rehabilitiert und ökonomisch profitable Landnutzungsalternativen zum Anbau von Ölpalmplantagen geschaffen werden können.
<G-vec00001-001-s432><create.schaffen><en> The individuals who, over a period of many years, devoted themselves to calling persistently for a historically founded and educationally productive utilization of the former company grounds succeeded in making themselves heard by the responsible persons in the local government: the city of Erfurt will create and operate a place of history and learning with an exhibition and educational offers.
<G-vec00001-001-s432><create.schaffen><de> Das Engagement von Menschen, die über Jahre nicht aufgaben und unbeirrt einen historisch fundierten und pädagogisch produktiven Umgang mit dem ehemaligen Firmengelände forderten, erreichte die Zuständigen in der Kommune: die Stadt Erfurt hat mit Unterstützung von Bund und Land einen Geschichts- und Lernort mit Ausstellung und pädagogischen Angeboten geschaffen.
<G-vec00001-001-s433><create.schaffen><en> The success of the collection, designed ad hoc, especially for this sector, is defined by the quality feel and romantic mood that Scandola furnishings manage to create, along with the company's professionalism and skill in responding to the demands of different living styles.
<G-vec00001-001-s433><create.schaffen><de> Die außerordentliche Qualität und die romantische Atmosphäre, die durch die Einrichtungskonzepte Scandola geschaffen werden kann, haben gemeinsam mit der Professionalität und der Fähigkeit des Unternehmens hinsichtlich der Erfüllung unterschiedlichster Wohnbedürfnisse zum großen Erfolg der eigens für diesen Sektor erarbeiteten Kollektion beigetragen.
<G-vec00001-001-s434><create.schaffen><en> The new project is expected to create added value for the population.
<G-vec00001-001-s434><create.schaffen><de> Mit dem neuen Projekt werde ein Mehrwert für die Bevölkerung geschaffen.
<G-vec00001-001-s435><create.schaffen><en> «No, we can create gaps as necessary,» the Haul corrected.
<G-vec00001-001-s435><create.schaffen><de> «Nein, es werden nur entsprechende Lücken geschaffen,» widersprach die Haul.
<G-vec00001-001-s436><create.schaffen><en> The way to ensure growth in breastfeeding rates is to create supportive environments: this includes informing women of the health benefits of breastfeeding, providing them with advice and support at the initial stages, and making sure they can breastfeed at work – and everywhere else.
<G-vec00001-001-s436><create.schaffen><de> Um eine Steigerung der Stillraten sicherzustellen, müssen unterstützende Umfelder geschaffen werden: hierzu gehört es auch, Frauen über die gesundheitlichen Vorteile des Stillens aufzuklären, ihnen Beratung und Unterstützung zu Beginn des Stillens zu bieten und zu gewährleisten, dass sie auch am Arbeitsplatz – und überall sonst – stillen können.
<G-vec00179-001-s418><create.schaffen><en> And whenever, through a huge effort, you actually get peace somewhere, you will want to create war somewhere else.
<G-vec00179-001-s418><create.schaffen><de> Und immer wenn irgendwo mit großem Aufwand Frieden geschaffen wird, macht man halt woanders einen kleinen Krieg.
<G-vec00179-001-s419><create.schaffen><en> The proposed measures will greatly benefit shipping as they will reduce costs, simplify administration, facilitate trade and create a level playing field between all types of transport.
<G-vec00179-001-s419><create.schaffen><de> Die vorgeschlagenen Maßnahmen werden sich eindeutig positiv auf die Schifffahrt auswirken, da durch sie die Kosten gesenkt, die Verwaltung vereinfacht, der Handel erleichtert und gleiche Wettbewerbsbedingungen für alle Verkehrsträger geschaffen werden.
<G-vec00179-001-s420><create.schaffen><en> """I’m certain that the standardized early data exchange between the process participants made possible by FAIR@Link will create great added value for everyone."
<G-vec00179-001-s420><create.schaffen><de> „Ich bin mir sicher, dass durch den standardisierten frühzeitigen Datenaustausch zwischen den Prozessbeteiligten, den FAIR@Link ermöglicht, ein großer Mehrwert für alle geschaffen wird.
<G-vec00179-001-s421><create.schaffen><en> Efficiency isn’t about more or less space, it’s about using the space you have to create a seamless workflow for people.
<G-vec00179-001-s421><create.schaffen><de> Bei Effizienz geht es nicht um mehr oder weniger Platz – es geht darum, den vorhandenen Platz so zu nutzen, dass für die Mitarbeiter ein nahtloser Arbeitsfluss geschaffen wird.
<G-vec00179-001-s422><create.schaffen><en> It is hoped that immigration’s problem will be solved by using supportive EU funds to create employment positions for migrants with qualifications.
<G-vec00179-001-s422><create.schaffen><de> Es ist zu hoffen, dass das Problem der Einwanderung gelöst wird, indem unterstützende EU-Mittel für Beschäftigungsmöglichkeiten von Einwanderern mit Qualifikationen geschaffen werden.
<G-vec00179-001-s423><create.schaffen><en> The goal is to create a concrete basis for developing further joint projects.
<G-vec00179-001-s423><create.schaffen><de> Damit soll eine konkrete Grundlage für die Entwicklung weiterführender gemeinsamer Projekte geschaffen werden.
<G-vec00179-001-s424><create.schaffen><en> These measures improve forage supply during the summer and create new habitats.
<G-vec00179-001-s424><create.schaffen><de> Damit werden das Nahrungsangebot im Sommer verbessert und neue Lebensräume geschaffen.
<G-vec00179-001-s425><create.schaffen><en> The linear connectors make it possible to create individual combinations and to dismantle them again easily.
<G-vec00179-001-s425><create.schaffen><de> Mittels Linearverbinder können individuelle Kombinationen geschaffen und leicht wieder auseinandergebaut werden.
<G-vec00179-001-s426><create.schaffen><en> This project sought to create a state of the art, comprehensive system solution to protect human lives and freight.
<G-vec00179-001-s426><create.schaffen><de> Um den Schutz von Menschen und Gütern sicherzustellen, sollte eine moderne, umfassende Systemlösung geschaffen werden.
<G-vec00179-001-s427><create.schaffen><en> We create clusters of villages, which pool their resources together to support a priest.
<G-vec00179-001-s427><create.schaffen><de> Wir haben Gruppen von Dörfern geschaffen, die mit vereinten Kräften für einen Priester aufkommen.
<G-vec00179-001-s428><create.schaffen><en> By offering a performance-based fee agreement, we create a win-win situation between the asset manager and the owner.
<G-vec00179-001-s428><create.schaffen><de> Über ein erfolgsabhängiges Honorarmodel wird immer eine Win-Win-Situation zwischen Asset Manager und Eigentümer geschaffen.
<G-vec00179-001-s429><create.schaffen><en> To celebrate Live's fifteenth birthday, Christian Kleine create a generative Live Set that you can download for free.
<G-vec00179-001-s429><create.schaffen><de> Um den fünfzehnten Geburtstag von Live zu feiern, hat Christian Kleine ein generatives Live Set geschaffen, das Du kostenlos herunterladen kannst.
<G-vec00179-001-s430><create.schaffen><en> Ancient beauty recipes combine with a state of the art organic cosmetics to create an innovative line exclusive to the VITA NOVA hotels, giving beauty and wellness to your skin.
<G-vec00179-001-s430><create.schaffen><de> Alte Schönheitsrezepte und modernste Biokosmetik in einer neuen Linie, die speziell für die VITA NOVA-Hotels geschaffen wurde, um Ihre Haut schöner und gesünder zu machen.
<G-vec00179-001-s431><create.schaffen><en> The aim of the study is to investigate whether the native tree species sengon can be used to rehabilitate degraded land and create economically profitable land-use alternatives to the establishment of palm oil plantations.
<G-vec00179-001-s431><create.schaffen><de> Ziel der Studie ist es, zu untersuchen, ob mithilfe der einheimischen Baumart Sengon degradierte Flächen rehabilitiert und ökonomisch profitable Landnutzungsalternativen zum Anbau von Ölpalmplantagen geschaffen werden können.
<G-vec00179-001-s432><create.schaffen><en> The individuals who, over a period of many years, devoted themselves to calling persistently for a historically founded and educationally productive utilization of the former company grounds succeeded in making themselves heard by the responsible persons in the local government: the city of Erfurt will create and operate a place of history and learning with an exhibition and educational offers.
<G-vec00179-001-s432><create.schaffen><de> Das Engagement von Menschen, die über Jahre nicht aufgaben und unbeirrt einen historisch fundierten und pädagogisch produktiven Umgang mit dem ehemaligen Firmengelände forderten, erreichte die Zuständigen in der Kommune: die Stadt Erfurt hat mit Unterstützung von Bund und Land einen Geschichts- und Lernort mit Ausstellung und pädagogischen Angeboten geschaffen.
<G-vec00179-001-s433><create.schaffen><en> The success of the collection, designed ad hoc, especially for this sector, is defined by the quality feel and romantic mood that Scandola furnishings manage to create, along with the company's professionalism and skill in responding to the demands of different living styles.
<G-vec00179-001-s433><create.schaffen><de> Die außerordentliche Qualität und die romantische Atmosphäre, die durch die Einrichtungskonzepte Scandola geschaffen werden kann, haben gemeinsam mit der Professionalität und der Fähigkeit des Unternehmens hinsichtlich der Erfüllung unterschiedlichster Wohnbedürfnisse zum großen Erfolg der eigens für diesen Sektor erarbeiteten Kollektion beigetragen.
<G-vec00179-001-s434><create.schaffen><en> The new project is expected to create added value for the population.
<G-vec00179-001-s434><create.schaffen><de> Mit dem neuen Projekt werde ein Mehrwert für die Bevölkerung geschaffen.
<G-vec00179-001-s435><create.schaffen><en> «No, we can create gaps as necessary,» the Haul corrected.
<G-vec00179-001-s435><create.schaffen><de> «Nein, es werden nur entsprechende Lücken geschaffen,» widersprach die Haul.
<G-vec00179-001-s436><create.schaffen><en> The way to ensure growth in breastfeeding rates is to create supportive environments: this includes informing women of the health benefits of breastfeeding, providing them with advice and support at the initial stages, and making sure they can breastfeed at work – and everywhere else.
<G-vec00179-001-s436><create.schaffen><de> Um eine Steigerung der Stillraten sicherzustellen, müssen unterstützende Umfelder geschaffen werden: hierzu gehört es auch, Frauen über die gesundheitlichen Vorteile des Stillens aufzuklären, ihnen Beratung und Unterstützung zu Beginn des Stillens zu bieten und zu gewährleisten, dass sie auch am Arbeitsplatz – und überall sonst – stillen können.
<G-vec00001-001-s437><create.gestalten><en> The idea was to create simple hair accessories made from cartonboard instead of plastic that is simple to handle.
<G-vec00001-001-s437><create.gestalten><de> Daher meine Idee, einfach zu handhabende Accessoires für Haare zu gestalten, die statt aus Kunststoff aus Karton gemacht sind.
<G-vec00001-001-s438><create.gestalten><en> "On the other hand, by combining the values celebrated by the maker culture – an openness towards knowledge, collaborative working, need-based, resource-efficient and decentralised production – with the designer's ability to create things that benefit others and not just themselves, while ideally involving the user as an equal participant, we can create a model you might call ""do-it-together""."
<G-vec00001-001-s438><create.gestalten><de> "Wenn allerdings die von der Maker-Kultur propagierten Werte wie offener Umgang mit Wissen, gemeinschaftliches Handeln und bedürfnisgerechte, ressourcenschonende und dezentrale Produktion mit der Fähigkeit des Designers gekoppelt werden, nicht nur für sich selbst, sondern für andere zu gestalten – im Idealfall unter gleichberechtigter Teilhabe des Nutzers – entstünde ein Zusammenhang, der sich dann ""Do-it-together"" nennen könnte."
<G-vec00001-001-s439><create.gestalten><en> With these multifunctional candle holders out of glass you will be able to create the perfect table decoration, because you can place them free and they are fire proof.
<G-vec00001-001-s439><create.gestalten><de> oder Produktbeschreibung Mit diesen multifunktionalen Kerzenhaltern aus Glas können Sie die perfekte Tischdekoration gestalten, denn sie lassen sich frei platzieren und sind feuerfest.
<G-vec00001-001-s440><create.gestalten><en> With this stove, you can create and change the ambience in your living space just as you wish.
<G-vec00001-001-s440><create.gestalten><de> So können Sie Ihr Wohnzimmer-Ambiente mit diesem Kaminofen ganz nach Ihren Wünschen gestalten und individuell verändern.
<G-vec00001-001-s441><create.gestalten><en> Whether you want to introduce your child to robotics or create a true robotics course for your students, you'll be able to count on its comprehensive and totally open-source teaching materials (in French) .
<G-vec00001-001-s441><create.gestalten><de> Ob für Ihr Kind zu Hause oder für den Robotik-Unterricht in der Klasse, mit dem umfassenden Open-Source Lehrmaterial (in französischer Sprache) können Sie einen perfekten Robotik-Workshop gestalten.
<G-vec00001-001-s442><create.gestalten><en> Use them to create breathtakingly beautiful wedding invitation cards, revive your blog or social media pages or make a gorgeous greeting card suitable for any occasion.
<G-vec00001-001-s442><create.gestalten><de> Verwenden Sie sie, um atemberaubend schöne Hochzeitseinladungskarten zu gestalten, Abwechslung in Ihren Blog oder Ihre Website zu bringen oder eine wunderschöne Grußkarte für jeden Anlass herzustellen.
<G-vec00001-001-s443><create.gestalten><en> Snug, manufactured by Yorkshire based Sutcliffe Play, transforms playgrounds into creative environments inspiring children to explore, create, discover and learn.
<G-vec00001-001-s443><create.gestalten><de> Der in Yorkshire ansässige Spielplatzgerätehersteller Sutcliffe Play entwickelte das innovative Spielkonzept Snug, welches Spielplätze in kreative Spiellandschaften verwandelt und die Kinder zum Erkunden, Gestalten, Entdecken und Lernen inspiriert.
<G-vec00001-001-s444><create.gestalten><en> With a targeted use of material, light and colour we create a highly motivating surrounding and support the idea of applied corporate identity.
<G-vec00001-001-s444><create.gestalten><de> Durch den gezielten Einsatz von Material, Licht und Farbe gestalten wir ein hochmotivierendes Umfeld und unterstützen den gelebten CI-Gedanken.
<G-vec00001-001-s445><create.gestalten><en> More than 4,000 actors and artists from the most diverse countries and cultures, wearing elaborate costumes and playing all sorts of instruments, create an unforgettable street parade.
<G-vec00001-001-s445><create.gestalten><de> Mehr als 4.000 Akteure aus den unterschiedlichsten Ländern und Kulturkreisen gestalten einen unvergesslichen Straßenumzug, aufwendige Kostüme und allerlei Instrumente inklusive.
<G-vec00001-001-s446><create.gestalten><en> We continuously develop our capabilities and create a powerful, global organization in an attractive working environment.
<G-vec00001-001-s446><create.gestalten><de> In einem attraktiven Arbeitsumfeld entwickeln wir unsere Fähigkeiten kontinuierlich weiter und gestalten eine leistungsstarke, globale Organisation.
<G-vec00001-001-s447><create.gestalten><en> Misfits want to create, do their own thing.
<G-vec00001-001-s447><create.gestalten><de> Aussteiger wollen gestalten, ihr eigenes Ding machen.
<G-vec00001-001-s448><create.gestalten><en> If you need a second wrap for a different vehicle, you have a couple of options: you can run a second contest, or you can start a 1-to-1 Project with your winning designer to create the additional assets.
<G-vec00001-001-s448><create.gestalten><de> Wenn Sie weitere Fahrzeuge gestalten lassen möchten, so haben Sie verschiedene Optionen: Sie können einen weiteren Wettbewerb starten oder Sie arbeiten mit dem Gewinner Ihres Wettbewerbs in einem 1-zu-1-Projekt an der Gestaltung der zusätzlichen Designs weiter.
<G-vec00001-001-s449><create.gestalten><en> Art Text offers you the chance to expand your artistic potential and create astonishing objects and text by taking advantage of easy-to-use multiple layers.
<G-vec00001-001-s449><create.gestalten><de> Art Text hilft Ihnen, Ihr künstlerisches Potenzial zu erweitern und erstaunlich schöne Objekte und Texte zu gestalten, indem es Sie mit einfach benutzbaren, beliebigen Ebenen unterstützt.
<G-vec00001-001-s450><create.gestalten><en> Digital Smile Design is a state of the art instrument in aesthetic dentistry, enabling each patient to create the ideal solution for his smile together with his doctor.
<G-vec00001-001-s450><create.gestalten><de> Digital Smile Design ist das neueste Instrument im Bereich der ästhetischen Zahnmedizin, welches jedem Patienten ermöglicht, zusammen mit seinem Arzt die ideelle Lösung für sein Lächeln zu gestalten.
<G-vec00001-001-s451><create.gestalten><en> Then we would make fotos and create a nice CD-Cover.
<G-vec00001-001-s451><create.gestalten><de> Wir machen Fotos mit ihr und gestalten ein tolles CD-Cover.
<G-vec00001-001-s452><create.gestalten><en> Reverse logistics can be defined as the application of logistics concepts to residues in order to create an economically and environmentally efficient residue stream by using all activities of spatiotemporal transformation, including changes in amount and types [1].
<G-vec00001-001-s452><create.gestalten><de> Die Entsorgungs-Logistik kann definiert werden als Anwendung der Logistikkonzeption auf Rückstände, um mit allen Tätigkeiten der raumzeitlichen Transformation - einschließlich der Mengen- und Sortenänderung - einen ökonomisch und ökologisch effizienten Rückstandsfluss zu gestalten [1].
<G-vec00001-001-s453><create.gestalten><en> The uniqueness of this project exists in the fact that children of all social levels, migrants handicapped and nicht handicapped, will work together to create and perform a musical theater play with professional musical assistence and accompaniment.
<G-vec00001-001-s453><create.gestalten><de> Die Einmaligkeit des Projektes besteht darin, dass Kinder aus allen sozialen Schichten, Migranten, Kinder mit Behinderung und nicht behinderte Kinder erstmalig in -einem- Projekt zusammen geführt werden, miteinander kreativ ein musikalisches Theaterstück erarbeiten, gestalten und zur Aufführung bringen und dabei gleichzeitig professionell begleitet an Musik herangeführt werden.
<G-vec00001-001-s454><create.gestalten><en> The Inflexion UI provides a fast and reliable solution without changes to the underlying application code, enabling the developer to create dynamic 2D and 3D graphics, animation, and special effects.
<G-vec00001-001-s454><create.gestalten><de> Das Inflexion-UI-Produkt bietet eine schnelle und zuverlässige Lösung mit der Entwickler ohne Änderung des Applikationscodes dynamische 2D- und 3D-Graphiken, Animationen und Spezialeffekte gestalten können.
<G-vec00001-001-s455><create.gestalten><en> Attractive cruising regions, memorable excursions, highly-efficient on-board service: Our aim is to create an exceptional travel experience for our guests.
<G-vec00001-001-s455><create.gestalten><de> Attraktive Fahrgebiete, ereignisreiche Ausflugsprogramm, leistungsstarker Service an Bord: Unser Ziel ist es, unseren Gästen ein außergewöhnliches Reise-Erlebnis zu gestalten.
<G-vec00179-001-s437><create.gestalten><en> The idea was to create simple hair accessories made from cartonboard instead of plastic that is simple to handle.
<G-vec00179-001-s437><create.gestalten><de> Daher meine Idee, einfach zu handhabende Accessoires für Haare zu gestalten, die statt aus Kunststoff aus Karton gemacht sind.
<G-vec00179-001-s438><create.gestalten><en> "On the other hand, by combining the values celebrated by the maker culture – an openness towards knowledge, collaborative working, need-based, resource-efficient and decentralised production – with the designer's ability to create things that benefit others and not just themselves, while ideally involving the user as an equal participant, we can create a model you might call ""do-it-together""."
<G-vec00179-001-s438><create.gestalten><de> "Wenn allerdings die von der Maker-Kultur propagierten Werte wie offener Umgang mit Wissen, gemeinschaftliches Handeln und bedürfnisgerechte, ressourcenschonende und dezentrale Produktion mit der Fähigkeit des Designers gekoppelt werden, nicht nur für sich selbst, sondern für andere zu gestalten – im Idealfall unter gleichberechtigter Teilhabe des Nutzers – entstünde ein Zusammenhang, der sich dann ""Do-it-together"" nennen könnte."
<G-vec00179-001-s439><create.gestalten><en> With these multifunctional candle holders out of glass you will be able to create the perfect table decoration, because you can place them free and they are fire proof.
<G-vec00179-001-s439><create.gestalten><de> oder Produktbeschreibung Mit diesen multifunktionalen Kerzenhaltern aus Glas können Sie die perfekte Tischdekoration gestalten, denn sie lassen sich frei platzieren und sind feuerfest.
<G-vec00179-001-s440><create.gestalten><en> With this stove, you can create and change the ambience in your living space just as you wish.
<G-vec00179-001-s440><create.gestalten><de> So können Sie Ihr Wohnzimmer-Ambiente mit diesem Kaminofen ganz nach Ihren Wünschen gestalten und individuell verändern.
<G-vec00179-001-s441><create.gestalten><en> Whether you want to introduce your child to robotics or create a true robotics course for your students, you'll be able to count on its comprehensive and totally open-source teaching materials (in French) .
<G-vec00179-001-s441><create.gestalten><de> Ob für Ihr Kind zu Hause oder für den Robotik-Unterricht in der Klasse, mit dem umfassenden Open-Source Lehrmaterial (in französischer Sprache) können Sie einen perfekten Robotik-Workshop gestalten.
<G-vec00179-001-s442><create.gestalten><en> Use them to create breathtakingly beautiful wedding invitation cards, revive your blog or social media pages or make a gorgeous greeting card suitable for any occasion.
<G-vec00179-001-s442><create.gestalten><de> Verwenden Sie sie, um atemberaubend schöne Hochzeitseinladungskarten zu gestalten, Abwechslung in Ihren Blog oder Ihre Website zu bringen oder eine wunderschöne Grußkarte für jeden Anlass herzustellen.
<G-vec00179-001-s443><create.gestalten><en> Snug, manufactured by Yorkshire based Sutcliffe Play, transforms playgrounds into creative environments inspiring children to explore, create, discover and learn.
<G-vec00179-001-s443><create.gestalten><de> Der in Yorkshire ansässige Spielplatzgerätehersteller Sutcliffe Play entwickelte das innovative Spielkonzept Snug, welches Spielplätze in kreative Spiellandschaften verwandelt und die Kinder zum Erkunden, Gestalten, Entdecken und Lernen inspiriert.
<G-vec00179-001-s444><create.gestalten><en> With a targeted use of material, light and colour we create a highly motivating surrounding and support the idea of applied corporate identity.
<G-vec00179-001-s444><create.gestalten><de> Durch den gezielten Einsatz von Material, Licht und Farbe gestalten wir ein hochmotivierendes Umfeld und unterstützen den gelebten CI-Gedanken.
<G-vec00179-001-s445><create.gestalten><en> More than 4,000 actors and artists from the most diverse countries and cultures, wearing elaborate costumes and playing all sorts of instruments, create an unforgettable street parade.
<G-vec00179-001-s445><create.gestalten><de> Mehr als 4.000 Akteure aus den unterschiedlichsten Ländern und Kulturkreisen gestalten einen unvergesslichen Straßenumzug, aufwendige Kostüme und allerlei Instrumente inklusive.
<G-vec00179-001-s446><create.gestalten><en> We continuously develop our capabilities and create a powerful, global organization in an attractive working environment.
<G-vec00179-001-s446><create.gestalten><de> In einem attraktiven Arbeitsumfeld entwickeln wir unsere Fähigkeiten kontinuierlich weiter und gestalten eine leistungsstarke, globale Organisation.
<G-vec00179-001-s447><create.gestalten><en> Misfits want to create, do their own thing.
<G-vec00179-001-s447><create.gestalten><de> Aussteiger wollen gestalten, ihr eigenes Ding machen.
<G-vec00179-001-s448><create.gestalten><en> If you need a second wrap for a different vehicle, you have a couple of options: you can run a second contest, or you can start a 1-to-1 Project with your winning designer to create the additional assets.
<G-vec00179-001-s448><create.gestalten><de> Wenn Sie weitere Fahrzeuge gestalten lassen möchten, so haben Sie verschiedene Optionen: Sie können einen weiteren Wettbewerb starten oder Sie arbeiten mit dem Gewinner Ihres Wettbewerbs in einem 1-zu-1-Projekt an der Gestaltung der zusätzlichen Designs weiter.
<G-vec00179-001-s449><create.gestalten><en> Art Text offers you the chance to expand your artistic potential and create astonishing objects and text by taking advantage of easy-to-use multiple layers.
<G-vec00179-001-s449><create.gestalten><de> Art Text hilft Ihnen, Ihr künstlerisches Potenzial zu erweitern und erstaunlich schöne Objekte und Texte zu gestalten, indem es Sie mit einfach benutzbaren, beliebigen Ebenen unterstützt.
<G-vec00179-001-s450><create.gestalten><en> Digital Smile Design is a state of the art instrument in aesthetic dentistry, enabling each patient to create the ideal solution for his smile together with his doctor.
<G-vec00179-001-s450><create.gestalten><de> Digital Smile Design ist das neueste Instrument im Bereich der ästhetischen Zahnmedizin, welches jedem Patienten ermöglicht, zusammen mit seinem Arzt die ideelle Lösung für sein Lächeln zu gestalten.
<G-vec00179-001-s451><create.gestalten><en> Then we would make fotos and create a nice CD-Cover.
<G-vec00179-001-s451><create.gestalten><de> Wir machen Fotos mit ihr und gestalten ein tolles CD-Cover.
<G-vec00179-001-s452><create.gestalten><en> Reverse logistics can be defined as the application of logistics concepts to residues in order to create an economically and environmentally efficient residue stream by using all activities of spatiotemporal transformation, including changes in amount and types [1].
<G-vec00179-001-s452><create.gestalten><de> Die Entsorgungs-Logistik kann definiert werden als Anwendung der Logistikkonzeption auf Rückstände, um mit allen Tätigkeiten der raumzeitlichen Transformation - einschließlich der Mengen- und Sortenänderung - einen ökonomisch und ökologisch effizienten Rückstandsfluss zu gestalten [1].
<G-vec00179-001-s453><create.gestalten><en> The uniqueness of this project exists in the fact that children of all social levels, migrants handicapped and nicht handicapped, will work together to create and perform a musical theater play with professional musical assistence and accompaniment.
<G-vec00179-001-s453><create.gestalten><de> Die Einmaligkeit des Projektes besteht darin, dass Kinder aus allen sozialen Schichten, Migranten, Kinder mit Behinderung und nicht behinderte Kinder erstmalig in -einem- Projekt zusammen geführt werden, miteinander kreativ ein musikalisches Theaterstück erarbeiten, gestalten und zur Aufführung bringen und dabei gleichzeitig professionell begleitet an Musik herangeführt werden.
<G-vec00179-001-s454><create.gestalten><en> The Inflexion UI provides a fast and reliable solution without changes to the underlying application code, enabling the developer to create dynamic 2D and 3D graphics, animation, and special effects.
<G-vec00179-001-s454><create.gestalten><de> Das Inflexion-UI-Produkt bietet eine schnelle und zuverlässige Lösung mit der Entwickler ohne Änderung des Applikationscodes dynamische 2D- und 3D-Graphiken, Animationen und Spezialeffekte gestalten können.
<G-vec00179-001-s455><create.gestalten><en> Attractive cruising regions, memorable excursions, highly-efficient on-board service: Our aim is to create an exceptional travel experience for our guests.
<G-vec00179-001-s455><create.gestalten><de> Attraktive Fahrgebiete, ereignisreiche Ausflugsprogramm, leistungsstarker Service an Bord: Unser Ziel ist es, unseren Gästen ein außergewöhnliches Reise-Erlebnis zu gestalten.
<G-vec00001-001-s456><create.herstellen><en> This process makes it possible to create hollow objects with a volume of up to 3000 liters.
<G-vec00001-001-s456><create.herstellen><de> Mit diesem lassen sich hohle Gegenstände mit einem Volumen bis zu 3000 Litern herstellen.
<G-vec00001-001-s457><create.herstellen><en> If you create a public embroidery product for sale in the marketplace, the product will be published on the Site at the time the stitch file is completed (typically within 24-48 hours but it may be longer).
<G-vec00001-001-s457><create.herstellen><de> Wenn Sie ein öffentliches Stickerei-Produkt für den Verkauf am Markt herstellen, wird das Produkt zum Zeitpunkt der Fertigstellung der Stickmusterdatei auf der Website veröffentlicht (in der Regel innerhalb von 24-48 Stunden, in einigen Fällen jedoch auch länger).
<G-vec00001-001-s458><create.herstellen><en> With the Powder Male Lubricant, you can easily create your own long-lasting lubricant in only few minutes.
<G-vec00001-001-s458><create.herstellen><de> Mit dem Male Powder Lubricant können Sie sehr leicht in wenigen Minuten Ihr eigenes langfristiges Gleitmittel herstellen.
<G-vec00001-001-s459><create.herstellen><en> Each time you visit our website, which contains such a map, data is loaded from Google’s web servers that create the visual appearance and functionality of the map on our website.
<G-vec00001-001-s459><create.herstellen><de> Bei jedem Aufruf unserer Website, welche eine solche Landkarte enthält, werden Daten von den Webservern von Google geladen, die das optische Erscheinungsbild und die Funktionalität der Landkarte auf unserer Website herstellen.
<G-vec00001-001-s460><create.herstellen><en> Create an equilibrium sera bio nitrivec Cure diseases 1.1.1.
<G-vec00001-001-s460><create.herstellen><de> Gleichgewicht herstellen sera bio nitrivec Krankheiten heilen 1.1.1.
<G-vec00001-001-s461><create.herstellen><en> You can also create an elegant decoration with white candles.
<G-vec00001-001-s461><create.herstellen><de> Mit weißen Kerzen können Sie ebenfalls eine elegante Dekoration herstellen.
<G-vec00001-001-s462><create.herstellen><en> With our large range of color for 3D printed resin, you can prototype colored glass or create any kind of decorative or functional part.
<G-vec00001-001-s462><create.herstellen><de> Mit unserer großen Auswahl an Farben für den 3D-Druck in Harz, können Sie farbige Prototypen aus Glas herstellen oder jede Art dekorativer oder funktioneller Teile.
<G-vec00001-001-s463><create.herstellen><en> Dr. Jacob argued when I suggested that he needed to create clear guidelines for his staff and then leave them alone to do their jobs.
<G-vec00001-001-s463><create.herstellen><de> Dr. Jacob argumentierte, als ich vorschlug, daß er freie Richtlinien für seinen Personal herstellen und sie allein dann lassen musste, um ihre Arbeiten zu erledigen.
<G-vec00001-001-s464><create.herstellen><en> 2007-04-06 22:07:14 - Graphic creations with software A basic understanding of computers is all a person needs to create their own graphics with today's design software.
<G-vec00001-001-s464><create.herstellen><de> 2007-04-06 22:07:14 - Graphische Kreationen Mit Software Ein grundlegendes Verständnis der Computer ist alles eine Person muss ihre eigenen Graphiken mit heutiger Design-Software herstellen.
<G-vec00001-001-s465><create.herstellen><en> To remain faithful to Christian heritage and to give attention to a deepening of the faith of all adherents, contributes, then, eo ipso to overcoming all of the misunderstandings which can arise from collaboration among charitable institutions and recipients: respect for the ultimate responsibility of the pastors ordered toward the ecclesial diakonia; the collaboration with other confessions and other religions; the financial equilibrium between institutional functionaries and local collaborators; all of the elements which create an unfailing trust between donors and recipients.
<G-vec00001-001-s465><create.herstellen><de> Das treue Festhalten am christlichen Erbe und die Sorge um eine Glaubensvertiefung aller Anhänger tragen eo ipso dazu bei, manches Unverständnis in der Zusammenarbeit zwischen karitativen und Empfängereinrichtungen zu überwinden: Die Respektierung der Letztverantwortung der geweihten Hirten für die kirchliche Diakonie; die Zusammenarbeit mit anderen Konfessionen und anderen Religionen; die finanzielle Ausgewogenheit zwischen den Hauptamtlichen der Institutionen und den freien Mitarbeitern - das alles sind Elemente, die jenes unverzichtbare Vertrauen zwischen Spendern und Empfängern herstellen.
<G-vec00001-001-s466><create.herstellen><en> This kind of technology would permanently alter the entertainment industry: Expert skills would no longer be needed to create 3D films.
<G-vec00001-001-s466><create.herstellen><de> Eine solche Technologie würde die Unterhaltungsindustrie nachhaltig verändern: Man bräuchte keine Fachkenntnisse mehr, um 3D-Filme herstellen zu können.
<G-vec00001-001-s467><create.herstellen><en> You must not modify, copy, transmit, distribute, display, reproduce, publish, perform, license, frame, create derivative works from, transfer or use in any other way for commercial or public purposes in whole or in part any content obtained from a Bühler website without the prior written permission of the owner of the relevant Intellectual Property Rights.
<G-vec00001-001-s467><create.herstellen><de> Das Abwandeln, Kopieren, Verteilen, Übermitteln, Reproduzieren, Veröffentlichen, Lizenzieren, Darstellen, Gestalten, Herstellen abgeleiteter Werke, die Abänderung oder jegliche andere Verwendung für kommerzielle oder öffentliche Zwecke als Ganzes oder als Teil jeglichen Inhalts der Bühler Website ohne vorhergehende schriftliche Einwilligung des Inhabers des betreffenden Immaterialgüterrechts ist verboten.
<G-vec00001-001-s468><create.herstellen><en> It will allow Bühler Leybold Optics to innovate customer products, create sample products, and conduct physical and durability testing.
<G-vec00001-001-s468><create.herstellen><de> Damit kann Bühler Leybold Optics für Kunden neueste Produktinnovationen entwickeln, Musterprodukte herstellen und physikalische Eigenschaften sowie Beständigkeit ihrer Produkte erproben.
<G-vec00001-001-s469><create.herstellen><en> How to create a luxury dish from simple, inexpensive ingredients.
<G-vec00001-001-s469><create.herstellen><de> Wie man aus einfachen und preiswerten Zutaten ein Luxusgericht herstellen kann.
<G-vec00001-001-s470><create.herstellen><en> Intelligent packaging, which creates a connection between the product and consumer, will require intelligent pigments and functional coatings – to create innovative printing ink solutions.
<G-vec00001-001-s470><create.herstellen><de> Intelligente Verpackungen, die eine Verbindung zwischen Produkt und Konsument herstellen, benötigen intelligente Pigmente und funktionale Beschichtungen – kurzum innovative Druckfarbenlösungen.
<G-vec00001-001-s471><create.herstellen><en> That works for landing pages, too. For a high converting landing page (a lead magnet), your headline must be creative, straight to the point, create urgency and solve a particular problem.
<G-vec00001-001-s471><create.herstellen><de> Das funktioniert auch für Deine Landingpage.Für eine Landingpage mit hoher Konversionsrate muss Deine Überschrift kreativ und konkret formuliert sein, Dringlichkeit herstellen und ein bestimmtes Problem lösen.
<G-vec00001-001-s472><create.herstellen><en> Since 2011, Stéphane has been one of three artists in residence appointed by the Montreal Nature Museums group to create organic links between the city’s four natural science museums.
<G-vec00001-001-s472><create.herstellen><de> Seit 2011 ist Stéphane Roy einer von drei von der Montreal Nature Museums Group ernannten Artists in Residence, die biodynamische Verknüpfungen zwischen den vier naturwissenschaftlichen Museen der Stadt herstellen.
<G-vec00001-001-s473><create.herstellen><en> You fear the one and you are supposed to create the other.
<G-vec00001-001-s473><create.herstellen><de> Das eine fürchtet man, das andere soll man herstellen.
<G-vec00001-001-s474><create.herstellen><en> Any reputable manufacturer can create good smartphones.
<G-vec00001-001-s474><create.herstellen><de> Jeder seriöse Hersteller kann gute Smartphones herstellen.
<G-vec00179-001-s456><create.herstellen><en> This process makes it possible to create hollow objects with a volume of up to 3000 liters.
<G-vec00179-001-s456><create.herstellen><de> Mit diesem lassen sich hohle Gegenstände mit einem Volumen bis zu 3000 Litern herstellen.
<G-vec00179-001-s457><create.herstellen><en> If you create a public embroidery product for sale in the marketplace, the product will be published on the Site at the time the stitch file is completed (typically within 24-48 hours but it may be longer).
<G-vec00179-001-s457><create.herstellen><de> Wenn Sie ein öffentliches Stickerei-Produkt für den Verkauf am Markt herstellen, wird das Produkt zum Zeitpunkt der Fertigstellung der Stickmusterdatei auf der Website veröffentlicht (in der Regel innerhalb von 24-48 Stunden, in einigen Fällen jedoch auch länger).
<G-vec00179-001-s458><create.herstellen><en> With the Powder Male Lubricant, you can easily create your own long-lasting lubricant in only few minutes.
<G-vec00179-001-s458><create.herstellen><de> Mit dem Male Powder Lubricant können Sie sehr leicht in wenigen Minuten Ihr eigenes langfristiges Gleitmittel herstellen.
<G-vec00179-001-s459><create.herstellen><en> Each time you visit our website, which contains such a map, data is loaded from Google’s web servers that create the visual appearance and functionality of the map on our website.
<G-vec00179-001-s459><create.herstellen><de> Bei jedem Aufruf unserer Website, welche eine solche Landkarte enthält, werden Daten von den Webservern von Google geladen, die das optische Erscheinungsbild und die Funktionalität der Landkarte auf unserer Website herstellen.
<G-vec00179-001-s460><create.herstellen><en> Create an equilibrium sera bio nitrivec Cure diseases 1.1.1.
<G-vec00179-001-s460><create.herstellen><de> Gleichgewicht herstellen sera bio nitrivec Krankheiten heilen 1.1.1.
<G-vec00179-001-s461><create.herstellen><en> You can also create an elegant decoration with white candles.
<G-vec00179-001-s461><create.herstellen><de> Mit weißen Kerzen können Sie ebenfalls eine elegante Dekoration herstellen.
<G-vec00179-001-s462><create.herstellen><en> With our large range of color for 3D printed resin, you can prototype colored glass or create any kind of decorative or functional part.
<G-vec00179-001-s462><create.herstellen><de> Mit unserer großen Auswahl an Farben für den 3D-Druck in Harz, können Sie farbige Prototypen aus Glas herstellen oder jede Art dekorativer oder funktioneller Teile.
<G-vec00179-001-s463><create.herstellen><en> Dr. Jacob argued when I suggested that he needed to create clear guidelines for his staff and then leave them alone to do their jobs.
<G-vec00179-001-s463><create.herstellen><de> Dr. Jacob argumentierte, als ich vorschlug, daß er freie Richtlinien für seinen Personal herstellen und sie allein dann lassen musste, um ihre Arbeiten zu erledigen.
<G-vec00179-001-s464><create.herstellen><en> 2007-04-06 22:07:14 - Graphic creations with software A basic understanding of computers is all a person needs to create their own graphics with today's design software.
<G-vec00179-001-s464><create.herstellen><de> 2007-04-06 22:07:14 - Graphische Kreationen Mit Software Ein grundlegendes Verständnis der Computer ist alles eine Person muss ihre eigenen Graphiken mit heutiger Design-Software herstellen.
<G-vec00179-001-s465><create.herstellen><en> To remain faithful to Christian heritage and to give attention to a deepening of the faith of all adherents, contributes, then, eo ipso to overcoming all of the misunderstandings which can arise from collaboration among charitable institutions and recipients: respect for the ultimate responsibility of the pastors ordered toward the ecclesial diakonia; the collaboration with other confessions and other religions; the financial equilibrium between institutional functionaries and local collaborators; all of the elements which create an unfailing trust between donors and recipients.
<G-vec00179-001-s465><create.herstellen><de> Das treue Festhalten am christlichen Erbe und die Sorge um eine Glaubensvertiefung aller Anhänger tragen eo ipso dazu bei, manches Unverständnis in der Zusammenarbeit zwischen karitativen und Empfängereinrichtungen zu überwinden: Die Respektierung der Letztverantwortung der geweihten Hirten für die kirchliche Diakonie; die Zusammenarbeit mit anderen Konfessionen und anderen Religionen; die finanzielle Ausgewogenheit zwischen den Hauptamtlichen der Institutionen und den freien Mitarbeitern - das alles sind Elemente, die jenes unverzichtbare Vertrauen zwischen Spendern und Empfängern herstellen.
<G-vec00179-001-s466><create.herstellen><en> This kind of technology would permanently alter the entertainment industry: Expert skills would no longer be needed to create 3D films.
<G-vec00179-001-s466><create.herstellen><de> Eine solche Technologie würde die Unterhaltungsindustrie nachhaltig verändern: Man bräuchte keine Fachkenntnisse mehr, um 3D-Filme herstellen zu können.
<G-vec00179-001-s467><create.herstellen><en> You must not modify, copy, transmit, distribute, display, reproduce, publish, perform, license, frame, create derivative works from, transfer or use in any other way for commercial or public purposes in whole or in part any content obtained from a Bühler website without the prior written permission of the owner of the relevant Intellectual Property Rights.
<G-vec00179-001-s467><create.herstellen><de> Das Abwandeln, Kopieren, Verteilen, Übermitteln, Reproduzieren, Veröffentlichen, Lizenzieren, Darstellen, Gestalten, Herstellen abgeleiteter Werke, die Abänderung oder jegliche andere Verwendung für kommerzielle oder öffentliche Zwecke als Ganzes oder als Teil jeglichen Inhalts der Bühler Website ohne vorhergehende schriftliche Einwilligung des Inhabers des betreffenden Immaterialgüterrechts ist verboten.
<G-vec00179-001-s468><create.herstellen><en> It will allow Bühler Leybold Optics to innovate customer products, create sample products, and conduct physical and durability testing.
<G-vec00179-001-s468><create.herstellen><de> Damit kann Bühler Leybold Optics für Kunden neueste Produktinnovationen entwickeln, Musterprodukte herstellen und physikalische Eigenschaften sowie Beständigkeit ihrer Produkte erproben.
<G-vec00179-001-s469><create.herstellen><en> How to create a luxury dish from simple, inexpensive ingredients.
<G-vec00179-001-s469><create.herstellen><de> Wie man aus einfachen und preiswerten Zutaten ein Luxusgericht herstellen kann.
<G-vec00179-001-s470><create.herstellen><en> Intelligent packaging, which creates a connection between the product and consumer, will require intelligent pigments and functional coatings – to create innovative printing ink solutions.
<G-vec00179-001-s470><create.herstellen><de> Intelligente Verpackungen, die eine Verbindung zwischen Produkt und Konsument herstellen, benötigen intelligente Pigmente und funktionale Beschichtungen – kurzum innovative Druckfarbenlösungen.
<G-vec00179-001-s471><create.herstellen><en> That works for landing pages, too. For a high converting landing page (a lead magnet), your headline must be creative, straight to the point, create urgency and solve a particular problem.
<G-vec00179-001-s471><create.herstellen><de> Das funktioniert auch für Deine Landingpage.Für eine Landingpage mit hoher Konversionsrate muss Deine Überschrift kreativ und konkret formuliert sein, Dringlichkeit herstellen und ein bestimmtes Problem lösen.
<G-vec00179-001-s472><create.herstellen><en> Since 2011, Stéphane has been one of three artists in residence appointed by the Montreal Nature Museums group to create organic links between the city’s four natural science museums.
<G-vec00179-001-s472><create.herstellen><de> Seit 2011 ist Stéphane Roy einer von drei von der Montreal Nature Museums Group ernannten Artists in Residence, die biodynamische Verknüpfungen zwischen den vier naturwissenschaftlichen Museen der Stadt herstellen.
<G-vec00179-001-s473><create.herstellen><en> You fear the one and you are supposed to create the other.
<G-vec00179-001-s473><create.herstellen><de> Das eine fürchtet man, das andere soll man herstellen.
<G-vec00179-001-s474><create.herstellen><en> Any reputable manufacturer can create good smartphones.
<G-vec00179-001-s474><create.herstellen><de> Jeder seriöse Hersteller kann gute Smartphones herstellen.
<G-vec00001-001-s475><create.herstellen><en> Then combine all that info to create an imaginary person (or imaginary people) who fit the profile of your target audience members.
<G-vec00001-001-s475><create.herstellen><de> Kombinieren Sie dann alle, die Info, zum einer eingebildeten Person (oder der eingebildeten Leute) herzustellen das das Profil Ihrer Zielpublikum Mitglieder paßte.
<G-vec00001-001-s476><create.herstellen><en> The purpose of Qigong is to create balance and harmony between body(essence), breath(energy) and mind(spirit).
<G-vec00001-001-s476><create.herstellen><de> Der Zweck von Qigong ist es, Harmonie und Gleichgewicht zwischen Körper(Essenz), Atem(Energie) und Geist(Spiritualität) herzustellen.
<G-vec00001-001-s477><create.herstellen><en> Here we are using MILO; which is an excellent short cut - all you have to do is create the MILO drink.
<G-vec00001-001-s477><create.herstellen><de> Hier verwenden wir MILO; welches eine ausgezeichnete Abkürzung ist – du brauchst nichts weiter zu tun, als das MILO-Getränk herzustellen.
<G-vec00001-001-s478><create.herstellen><en> Exercise relieves the body of stress and it's by-products to create clearer, more creative thinking.
<G-vec00001-001-s478><create.herstellen><de> Übung entlastet den Körper von Druck und es ist die Nebenerscheinungen, zum des Reinigers, kreativeres Denken herzustellen.
<G-vec00001-001-s479><create.herstellen><en> Based in Coachella, CA, and licensed for both volatile and non-volatile manufacturing, Mojave Jane currently utilizes state of the art CO2 extraction technologies and proven distillation techniques to create products for both recreational and medical cannabis users.
<G-vec00001-001-s479><create.herstellen><de> Mit Sitz in Coachella, Kalifornien, und lizenziert für volatile und nicht-volatile Herstellung, nutzt Mojave Jane derzeit modernste CO2-Extraktionstechnologie n und bewährte Destillationstechniken, um Produkte sowohl für den Freizeitgebrauch als auch für Konsumenten medizinischen Cannabis herzustellen.
<G-vec00001-001-s480><create.herstellen><en> There is lots of software around nowadays that can create plants and trees in 3D.
<G-vec00001-001-s480><create.herstellen><de> Es gibt zwar inzwischen massig Software um sich Pflanzen und Bäume in 3D herzustellen.
<G-vec00001-001-s481><create.herstellen><en> While the mechanical components of a few of the objects may need further perfection and some motors still require fine tuning, the artist’s desire has always been to create - in each case - something that is ultimately a totally viable, functioning machine.
<G-vec00001-001-s481><create.herstellen><de> Die mechanischen Bestandteile einzelner Objekte mögen der Perfek- tionierung bedürfen, die Motoren ein Finetuning benötigen, aber der Wunsch des Künstlers war es - in jedem Fall -, etwas herzustellen, dass schließlich eine voll funktionstüchtige Maschine ist.
<G-vec00001-001-s482><create.herstellen><en> As a manufacturer of cooper, we are always working to create mirror cheap sunglasses.
<G-vec00001-001-s482><create.herstellen><de> Als Hersteller von Cooper arbeiten wir ständig daran, eine billige Sonnenbrille herzustellen.
<G-vec00001-001-s483><create.herstellen><en> In our programmes we're trying to create a space of possibility in which cinema and the forms of our perception can be constantly expanded and changed.
<G-vec00001-001-s483><create.herstellen><de> Wir versuchen, mit unseren Programmen dafür einen Möglichkeitsraum herzustellen, in dem sich das Kino und die Form unserer Wahrnehmung stets erweitern und verändern können.
<G-vec00001-001-s484><create.herstellen><en> You agree not to copy, modify, distribute, sell or create derivative works based on any of the Content.
<G-vec00001-001-s484><create.herstellen><de> Sie stimmen zu, keine auf jeglichem Inhalt basierende, sekundäre Arbeiten zu kopieren, modifizieren, vertreiben, verkaufen oder herzustellen.
<G-vec00001-001-s485><create.herstellen><en> Guaranteed for 5 years and perfect in the oven, microwave and water bath, they are available in different shapes to create the best pastry.
<G-vec00001-001-s485><create.herstellen><de> Sie sind 5 Jahre lang garantiert und perfekt im Backofen, in der Mikrowelle und im Wasserbad, sie sind in verschiedenen Formen erhältlich, um das beste Gebäck herzustellen.
<G-vec00001-001-s486><create.herstellen><en> So it's traveling through the Sun, and whatever node is able to create that connection is where the portal is able to be opened.
<G-vec00001-001-s486><create.herstellen><de> Er geht also durch die Sonne, und welcher Knoten auch immer in der Lage ist, diese Verbindung herzustellen, dort ist es, wo das Portal geöffnet werden kann.
<G-vec00001-001-s487><create.herstellen><en> There exists the method of concluding contracts between agricultural co-operatives and entire villages, the purpose of which is to supply the peasants with seed and thus obtain higher crop yields, to ensure the prompt delivery of grain by the peasants to the state, giving them in return a bonus in the shape of a certain addition to the contractual price, and to create stable relations between the state and the peasantry.
<G-vec00001-001-s487><create.herstellen><de> Eine solche Methode des Abschlusses von Verträgen zwischen landwirtschaftlichen Genossenschaften und ganzen Dörfern gibt es bereits; ihr Zweck ist es, die Bauern mit Saatgut zu versorgen, dadurch höhere Ernteerträge zu erzielen, zu gewährleisten, dass die Bauern dem Staat rechtzeitig Getreide liefern, ihnen dafür eine Prämie in Form eines gewissen Zuschlags zu dem Vertragspreis zu gewähren und ein stabiles Verhältnis zwischen Staat und Bauernschaft herzustellen.
<G-vec00001-001-s488><create.herstellen><en> This raw material must also be processed heavily by man in order to create fibres such as viscose, rayon and acetate (rayon is a common name for many types of the same thing).
<G-vec00001-001-s488><create.herstellen><de> Auch diese Rohstoffe müssen vom Menschen stark verarbeitet werden, um Fasern wie Viskose, Rayon und Acetat herzustellen (Viskose ist ein gebräuchlicher Name für viele Varianten desselben Stoffes).
<G-vec00001-001-s489><create.herstellen><en> Do this a few times to create 5 different new products and then evaluate them to see which to go with.
<G-vec00001-001-s489><create.herstellen><de> Zu sehen tun Sie dies einige Male, 5 unterschiedliche neue Produkte herzustellen und sie dann auszuwerten, um welchem, um zu gehen mit.
<G-vec00001-001-s490><create.herstellen><en> My original idea was to create an elegant female form.
<G-vec00001-001-s490><create.herstellen><de> Meine ursprüngliche Idee war es, eine elegante weibliche Form herzustellen.
<G-vec00001-001-s491><create.herstellen><en> One of his main concerns was to create an understanding of the cultural differences, also among his colleagues on the Works Council.
<G-vec00001-001-s491><create.herstellen><de> Ein Hauptanliegen war es ihm aber auch, Verständnis für die kulturellen Unterschiede herzustellen, auch bei seinen Betriebsratskollegen.
<G-vec00001-001-s492><create.herstellen><en> Business-to-business (B2B) e-commerce is expected to create most of the revenue generated from Internet sales in Asia.
<G-vec00001-001-s492><create.herstellen><de> Geschäft-zu-Geschäft (B2B) Ehandel wird erwartet, um die meisten des Einkommens herzustellen, das vom Internet erzeugt wird Verkäufe in Asien.
<G-vec00001-001-s493><create.herstellen><en> It’s a laudable wish to create a LED screen than matches TV screen in resolution.
<G-vec00001-001-s493><create.herstellen><de> Es ist ein lobenswerter Wunsch, zum eines LED-Bildschirms als Gleiche TV-Bildschirm in der Auflösung herzustellen.
<G-vec00179-001-s475><create.herstellen><en> Then combine all that info to create an imaginary person (or imaginary people) who fit the profile of your target audience members.
<G-vec00179-001-s475><create.herstellen><de> Kombinieren Sie dann alle, die Info, zum einer eingebildeten Person (oder der eingebildeten Leute) herzustellen das das Profil Ihrer Zielpublikum Mitglieder paßte.
<G-vec00179-001-s476><create.herstellen><en> The purpose of Qigong is to create balance and harmony between body(essence), breath(energy) and mind(spirit).
<G-vec00179-001-s476><create.herstellen><de> Der Zweck von Qigong ist es, Harmonie und Gleichgewicht zwischen Körper(Essenz), Atem(Energie) und Geist(Spiritualität) herzustellen.
<G-vec00179-001-s477><create.herstellen><en> Here we are using MILO; which is an excellent short cut - all you have to do is create the MILO drink.
<G-vec00179-001-s477><create.herstellen><de> Hier verwenden wir MILO; welches eine ausgezeichnete Abkürzung ist – du brauchst nichts weiter zu tun, als das MILO-Getränk herzustellen.
<G-vec00179-001-s478><create.herstellen><en> Exercise relieves the body of stress and it's by-products to create clearer, more creative thinking.
<G-vec00179-001-s478><create.herstellen><de> Übung entlastet den Körper von Druck und es ist die Nebenerscheinungen, zum des Reinigers, kreativeres Denken herzustellen.
<G-vec00179-001-s479><create.herstellen><en> Based in Coachella, CA, and licensed for both volatile and non-volatile manufacturing, Mojave Jane currently utilizes state of the art CO2 extraction technologies and proven distillation techniques to create products for both recreational and medical cannabis users.
<G-vec00179-001-s479><create.herstellen><de> Mit Sitz in Coachella, Kalifornien, und lizenziert für volatile und nicht-volatile Herstellung, nutzt Mojave Jane derzeit modernste CO2-Extraktionstechnologie n und bewährte Destillationstechniken, um Produkte sowohl für den Freizeitgebrauch als auch für Konsumenten medizinischen Cannabis herzustellen.
<G-vec00179-001-s480><create.herstellen><en> There is lots of software around nowadays that can create plants and trees in 3D.
<G-vec00179-001-s480><create.herstellen><de> Es gibt zwar inzwischen massig Software um sich Pflanzen und Bäume in 3D herzustellen.
<G-vec00179-001-s481><create.herstellen><en> While the mechanical components of a few of the objects may need further perfection and some motors still require fine tuning, the artist’s desire has always been to create - in each case - something that is ultimately a totally viable, functioning machine.
<G-vec00179-001-s481><create.herstellen><de> Die mechanischen Bestandteile einzelner Objekte mögen der Perfek- tionierung bedürfen, die Motoren ein Finetuning benötigen, aber der Wunsch des Künstlers war es - in jedem Fall -, etwas herzustellen, dass schließlich eine voll funktionstüchtige Maschine ist.
<G-vec00179-001-s482><create.herstellen><en> As a manufacturer of cooper, we are always working to create mirror cheap sunglasses.
<G-vec00179-001-s482><create.herstellen><de> Als Hersteller von Cooper arbeiten wir ständig daran, eine billige Sonnenbrille herzustellen.
<G-vec00179-001-s483><create.herstellen><en> In our programmes we're trying to create a space of possibility in which cinema and the forms of our perception can be constantly expanded and changed.
<G-vec00179-001-s483><create.herstellen><de> Wir versuchen, mit unseren Programmen dafür einen Möglichkeitsraum herzustellen, in dem sich das Kino und die Form unserer Wahrnehmung stets erweitern und verändern können.
<G-vec00179-001-s484><create.herstellen><en> You agree not to copy, modify, distribute, sell or create derivative works based on any of the Content.
<G-vec00179-001-s484><create.herstellen><de> Sie stimmen zu, keine auf jeglichem Inhalt basierende, sekundäre Arbeiten zu kopieren, modifizieren, vertreiben, verkaufen oder herzustellen.
<G-vec00179-001-s485><create.herstellen><en> Guaranteed for 5 years and perfect in the oven, microwave and water bath, they are available in different shapes to create the best pastry.
<G-vec00179-001-s485><create.herstellen><de> Sie sind 5 Jahre lang garantiert und perfekt im Backofen, in der Mikrowelle und im Wasserbad, sie sind in verschiedenen Formen erhältlich, um das beste Gebäck herzustellen.
<G-vec00179-001-s486><create.herstellen><en> So it's traveling through the Sun, and whatever node is able to create that connection is where the portal is able to be opened.
<G-vec00179-001-s486><create.herstellen><de> Er geht also durch die Sonne, und welcher Knoten auch immer in der Lage ist, diese Verbindung herzustellen, dort ist es, wo das Portal geöffnet werden kann.
<G-vec00179-001-s487><create.herstellen><en> There exists the method of concluding contracts between agricultural co-operatives and entire villages, the purpose of which is to supply the peasants with seed and thus obtain higher crop yields, to ensure the prompt delivery of grain by the peasants to the state, giving them in return a bonus in the shape of a certain addition to the contractual price, and to create stable relations between the state and the peasantry.
<G-vec00179-001-s487><create.herstellen><de> Eine solche Methode des Abschlusses von Verträgen zwischen landwirtschaftlichen Genossenschaften und ganzen Dörfern gibt es bereits; ihr Zweck ist es, die Bauern mit Saatgut zu versorgen, dadurch höhere Ernteerträge zu erzielen, zu gewährleisten, dass die Bauern dem Staat rechtzeitig Getreide liefern, ihnen dafür eine Prämie in Form eines gewissen Zuschlags zu dem Vertragspreis zu gewähren und ein stabiles Verhältnis zwischen Staat und Bauernschaft herzustellen.
<G-vec00179-001-s488><create.herstellen><en> This raw material must also be processed heavily by man in order to create fibres such as viscose, rayon and acetate (rayon is a common name for many types of the same thing).
<G-vec00179-001-s488><create.herstellen><de> Auch diese Rohstoffe müssen vom Menschen stark verarbeitet werden, um Fasern wie Viskose, Rayon und Acetat herzustellen (Viskose ist ein gebräuchlicher Name für viele Varianten desselben Stoffes).
<G-vec00179-001-s489><create.herstellen><en> Do this a few times to create 5 different new products and then evaluate them to see which to go with.
<G-vec00179-001-s489><create.herstellen><de> Zu sehen tun Sie dies einige Male, 5 unterschiedliche neue Produkte herzustellen und sie dann auszuwerten, um welchem, um zu gehen mit.
<G-vec00179-001-s490><create.herstellen><en> My original idea was to create an elegant female form.
<G-vec00179-001-s490><create.herstellen><de> Meine ursprüngliche Idee war es, eine elegante weibliche Form herzustellen.
<G-vec00179-001-s491><create.herstellen><en> One of his main concerns was to create an understanding of the cultural differences, also among his colleagues on the Works Council.
<G-vec00179-001-s491><create.herstellen><de> Ein Hauptanliegen war es ihm aber auch, Verständnis für die kulturellen Unterschiede herzustellen, auch bei seinen Betriebsratskollegen.
<G-vec00179-001-s492><create.herstellen><en> Business-to-business (B2B) e-commerce is expected to create most of the revenue generated from Internet sales in Asia.
<G-vec00179-001-s492><create.herstellen><de> Geschäft-zu-Geschäft (B2B) Ehandel wird erwartet, um die meisten des Einkommens herzustellen, das vom Internet erzeugt wird Verkäufe in Asien.
<G-vec00179-001-s493><create.herstellen><en> It’s a laudable wish to create a LED screen than matches TV screen in resolution.
<G-vec00179-001-s493><create.herstellen><de> Es ist ein lobenswerter Wunsch, zum eines LED-Bildschirms als Gleiche TV-Bildschirm in der Auflösung herzustellen.
<G-vec00001-001-s494><create.kreieren><en> Fusion gives you everything you need to create exciting broadcast graphics, dramatic titles, and even major feature film visual effects!
<G-vec00001-001-s494><create.kreieren><de> Fusion gibt Ihnen alles, was Sie brauchen, um spannende Broadcastgrafiken, dramatische Titel und sogar spielfilmartige visuelle Effekte zu kreieren.
<G-vec00001-001-s495><create.kreieren><en> A specific algorithm can then use this data to create personalized newsletters and mailings.
<G-vec00001-001-s495><create.kreieren><de> Aus den Daten kann nun ein bestimmter Algorithmus personalisierte Newsletter und Mailings kreieren.
<G-vec00001-001-s496><create.kreieren><en> Simply blend braids and twists to create a hairstyle that's beautiful from both the front and back.
<G-vec00001-001-s496><create.kreieren><de> Kombiniere einfach Zöpfe und Twists, um eine Frisur zu kreieren, die sowohl vorne als auch hinten wunderschön aussieht.
<G-vec00001-001-s497><create.kreieren><en> Their role is to support the local crafts businesses in presenting themselves and their products on the CatGen platform. They can also help the artisans to additionally create their own websites.
<G-vec00001-001-s497><create.kreieren><de> Die Handelspartner unterstützen die lokalen Handwerksbetriebe darin, sich und ihre Produkte auf der CatGen-Plattform vorzustellen oder zusätzlich eigene Websites zu kreieren.
<G-vec00001-001-s498><create.kreieren><en> In order to create more business, we need to take new risks.
<G-vec00001-001-s498><create.kreieren><de> Um mehr Business zu kreieren, müssen wir Neues wagen.
<G-vec00001-001-s499><create.kreieren><en> InStock /Dance Fitness Clothing Gorgeous hues of color on the panels of this girls' crop top swirl together to create a mesmerising print.
<G-vec00001-001-s499><create.kreieren><de> InStock /Tanz und Fitness Die wunderschönen Farbtöne der Einsätze dieses Crop-Tops für Mädchen verlaufen in einen Wirbel und kreieren den tollen Print.
<G-vec00001-001-s500><create.kreieren><en> It even has a royal history: In 1832, Prince Wenzel Clemens Metternich ordered his chef to create an exquisite dessert for his fastidious guests. But the chef was very ill and the order was delegated.
<G-vec00001-001-s500><create.kreieren><de> 1832, das Wiener Biedermeier, Fürst Wenzel Clemens Metternich befielt ein exquisites Dessert für seine verwöhnten Gäste zu kreieren, doch der Chefkoch liegt krank im Bett und der Auftrag wird weitergeleitet.
<G-vec00001-001-s501><create.kreieren><en> "The theatrical installation is the result of his work as an ""artist in residence"" at the Musée d'Art Contemporain in Montreal; the museum grants this position on a regular basis to artists with the understanding that they create an independent work using a combination of equal elements of theater and the visual arts."
<G-vec00001-001-s501><create.kreieren><de> "Die theatrale Installation ist das Ergebnis seiner Tätigkeit als ""artist in residence"" am Musée d'Art Contemporain in Montréal, die das Museum regelmäßig an Künstler mit der Auflage vergibt, ein eigenständiges Werk zu kreieren, das Theater und Bildende Kunst als gleichberechtigte Elemente verbindet."
<G-vec00001-001-s502><create.kreieren><en> For their new campaign Unite All Originals mega brand adidas invited hip-hop legends Run DMC and DJ talent A-trak to create the soundtrack for a very special interactive video experience that they launched earlier this month.
<G-vec00001-001-s502><create.kreieren><de> Für ihre neue KampagneUnite All Originals hat Mega-Brand adidas die Hip-Hop-Legenden vonRun DMC und DJ-WunderkindA-trak eingeladen den Soundtrack für eine ganz besondere, interaktive Video Experience zu kreieren.
<G-vec00001-001-s503><create.kreieren><en> We will soon launch a web shop where you can create your own inspirational messages.
<G-vec00001-001-s503><create.kreieren><de> Bald starten wir einen Webshop, in dem Sie selbst Ihre inspirativen Botschaften kreieren können.
<G-vec00001-001-s504><create.kreieren><en> Canva also has all the professional photos you need to create your presentations.
<G-vec00001-001-s504><create.kreieren><de> Canva hat außerdem alle professionellen Fotos, die Du brauchst, um Deine Präsentationen zu kreieren.
<G-vec00001-001-s505><create.kreieren><en> The BERNINA embroidery software lets you use your BERNINA’s capabilities to the full to create your own distinctive embroidery artworks.
<G-vec00001-001-s505><create.kreieren><de> So schöpfen Sie mit der BERNINA Sticksoftware die Möglichkeiten Ihrer BERNINA voll aus und kreieren Ihre eigenen unverwechselbaren Stickkunstwerke.
<G-vec00001-001-s506><create.kreieren><en> The quality of the materials and a high-quality leather processing mixed with Berlin design language create authentic handbags for free spirits.
<G-vec00001-001-s506><create.kreieren><de> Die Qualität der Materialien und eine hochwertige Lederverarbeitung gemixt mit Berliner Designsprache kreieren authentische Handtaschen für Freigeister.
<G-vec00001-001-s507><create.kreieren><en> One can be sure that with such a strong and recognizable pattern, the Maison Louis Vuitton will create new colourful interpretations in the future.
<G-vec00001-001-s507><create.kreieren><de> Wir können sicher sein, dass mit solch einem starken und wiedererkennbaren Muster die Maison Louis Vuitton auch in Zukunft neue farbenprächtige Interpretationen des Canvas kreieren wird.
<G-vec00001-001-s508><create.kreieren><en> You create your own food at Mongos.
<G-vec00001-001-s508><create.kreieren><de> Sie kreieren Ihr eigenes Essen bei Mongos.
<G-vec00001-001-s509><create.kreieren><en> Enjoy this elegant and original way to create your wedding presentation.
<G-vec00001-001-s509><create.kreieren><de> Genießen Sie diese elegante und originelle Art, Ihre Hochzeits-Präsentation zu kreieren.
<G-vec00001-001-s510><create.kreieren><en> "Maybe you can criticize ""Rashomon"" for its somewhat emotional and morally correct ending, yet, Kurosawa manages to create a picture, in which hope seems to be out of reach, thanks to a world full of humans who lie to others and themselves."
<G-vec00001-001-s510><create.kreieren><de> "Vielleicht kann man ""Rashomon"" für sein etwas emotionales und moralisches Ende kritisieren, Kurosawa schafft es aber dennoch gekonnt ein Bild zu kreieren, in dem Hoffnung, dank einer Welt voller Menschen, die sich und andere belügen, nicht mehr greifbar zu sein scheint."
<G-vec00001-001-s511><create.kreieren><en> If there was a Supreme Being that was some kind of directional force behind all that is, and he was like a man, he wouldn't be able to create a peanut butter sandwich let alone a universe.
<G-vec00001-001-s511><create.kreieren><de> Wenn da ein höchstes Wesen war, von einer Art zielgerichteter Kraft, die hinter allem ist, war und er wie ein Mensch war, würde er nicht fähig sein, ein Erdnußbutterbrot zu kreieren, geschweige denn ein Universum.
<G-vec00001-001-s512><create.kreieren><en> For SilverStone, every new form factor presents an opportunity to create designs that can completely abandon conventional perception of what enclosures could look and feel.
<G-vec00001-001-s512><create.kreieren><de> Fur SilverStone bietet jeder neue Formfaktor die Chance, Designs zu kreieren, welche vollstandig von den herkommlichen Vorstellungen, wie ein Gehause aussehen und was es aussagen soll, abweichen.
<G-vec00179-001-s494><create.kreieren><en> Fusion gives you everything you need to create exciting broadcast graphics, dramatic titles, and even major feature film visual effects!
<G-vec00179-001-s494><create.kreieren><de> Fusion gibt Ihnen alles, was Sie brauchen, um spannende Broadcastgrafiken, dramatische Titel und sogar spielfilmartige visuelle Effekte zu kreieren.
<G-vec00179-001-s495><create.kreieren><en> A specific algorithm can then use this data to create personalized newsletters and mailings.
<G-vec00179-001-s495><create.kreieren><de> Aus den Daten kann nun ein bestimmter Algorithmus personalisierte Newsletter und Mailings kreieren.
<G-vec00179-001-s496><create.kreieren><en> Simply blend braids and twists to create a hairstyle that's beautiful from both the front and back.
<G-vec00179-001-s496><create.kreieren><de> Kombiniere einfach Zöpfe und Twists, um eine Frisur zu kreieren, die sowohl vorne als auch hinten wunderschön aussieht.
<G-vec00179-001-s497><create.kreieren><en> Their role is to support the local crafts businesses in presenting themselves and their products on the CatGen platform. They can also help the artisans to additionally create their own websites.
<G-vec00179-001-s497><create.kreieren><de> Die Handelspartner unterstützen die lokalen Handwerksbetriebe darin, sich und ihre Produkte auf der CatGen-Plattform vorzustellen oder zusätzlich eigene Websites zu kreieren.
<G-vec00179-001-s498><create.kreieren><en> In order to create more business, we need to take new risks.
<G-vec00179-001-s498><create.kreieren><de> Um mehr Business zu kreieren, müssen wir Neues wagen.
<G-vec00179-001-s499><create.kreieren><en> InStock /Dance Fitness Clothing Gorgeous hues of color on the panels of this girls' crop top swirl together to create a mesmerising print.
<G-vec00179-001-s499><create.kreieren><de> InStock /Tanz und Fitness Die wunderschönen Farbtöne der Einsätze dieses Crop-Tops für Mädchen verlaufen in einen Wirbel und kreieren den tollen Print.
<G-vec00179-001-s500><create.kreieren><en> It even has a royal history: In 1832, Prince Wenzel Clemens Metternich ordered his chef to create an exquisite dessert for his fastidious guests. But the chef was very ill and the order was delegated.
<G-vec00179-001-s500><create.kreieren><de> 1832, das Wiener Biedermeier, Fürst Wenzel Clemens Metternich befielt ein exquisites Dessert für seine verwöhnten Gäste zu kreieren, doch der Chefkoch liegt krank im Bett und der Auftrag wird weitergeleitet.
<G-vec00179-001-s501><create.kreieren><en> "The theatrical installation is the result of his work as an ""artist in residence"" at the Musée d'Art Contemporain in Montreal; the museum grants this position on a regular basis to artists with the understanding that they create an independent work using a combination of equal elements of theater and the visual arts."
<G-vec00179-001-s501><create.kreieren><de> "Die theatrale Installation ist das Ergebnis seiner Tätigkeit als ""artist in residence"" am Musée d'Art Contemporain in Montréal, die das Museum regelmäßig an Künstler mit der Auflage vergibt, ein eigenständiges Werk zu kreieren, das Theater und Bildende Kunst als gleichberechtigte Elemente verbindet."
<G-vec00179-001-s502><create.kreieren><en> For their new campaign Unite All Originals mega brand adidas invited hip-hop legends Run DMC and DJ talent A-trak to create the soundtrack for a very special interactive video experience that they launched earlier this month.
<G-vec00179-001-s502><create.kreieren><de> Für ihre neue KampagneUnite All Originals hat Mega-Brand adidas die Hip-Hop-Legenden vonRun DMC und DJ-WunderkindA-trak eingeladen den Soundtrack für eine ganz besondere, interaktive Video Experience zu kreieren.
<G-vec00179-001-s503><create.kreieren><en> We will soon launch a web shop where you can create your own inspirational messages.
<G-vec00179-001-s503><create.kreieren><de> Bald starten wir einen Webshop, in dem Sie selbst Ihre inspirativen Botschaften kreieren können.
<G-vec00179-001-s504><create.kreieren><en> Canva also has all the professional photos you need to create your presentations.
<G-vec00179-001-s504><create.kreieren><de> Canva hat außerdem alle professionellen Fotos, die Du brauchst, um Deine Präsentationen zu kreieren.
<G-vec00179-001-s505><create.kreieren><en> The BERNINA embroidery software lets you use your BERNINA’s capabilities to the full to create your own distinctive embroidery artworks.
<G-vec00179-001-s505><create.kreieren><de> So schöpfen Sie mit der BERNINA Sticksoftware die Möglichkeiten Ihrer BERNINA voll aus und kreieren Ihre eigenen unverwechselbaren Stickkunstwerke.
<G-vec00179-001-s506><create.kreieren><en> The quality of the materials and a high-quality leather processing mixed with Berlin design language create authentic handbags for free spirits.
<G-vec00179-001-s506><create.kreieren><de> Die Qualität der Materialien und eine hochwertige Lederverarbeitung gemixt mit Berliner Designsprache kreieren authentische Handtaschen für Freigeister.
<G-vec00179-001-s507><create.kreieren><en> One can be sure that with such a strong and recognizable pattern, the Maison Louis Vuitton will create new colourful interpretations in the future.
<G-vec00179-001-s507><create.kreieren><de> Wir können sicher sein, dass mit solch einem starken und wiedererkennbaren Muster die Maison Louis Vuitton auch in Zukunft neue farbenprächtige Interpretationen des Canvas kreieren wird.
<G-vec00179-001-s508><create.kreieren><en> You create your own food at Mongos.
<G-vec00179-001-s508><create.kreieren><de> Sie kreieren Ihr eigenes Essen bei Mongos.
<G-vec00179-001-s509><create.kreieren><en> Enjoy this elegant and original way to create your wedding presentation.
<G-vec00179-001-s509><create.kreieren><de> Genießen Sie diese elegante und originelle Art, Ihre Hochzeits-Präsentation zu kreieren.
<G-vec00179-001-s510><create.kreieren><en> "Maybe you can criticize ""Rashomon"" for its somewhat emotional and morally correct ending, yet, Kurosawa manages to create a picture, in which hope seems to be out of reach, thanks to a world full of humans who lie to others and themselves."
<G-vec00179-001-s510><create.kreieren><de> "Vielleicht kann man ""Rashomon"" für sein etwas emotionales und moralisches Ende kritisieren, Kurosawa schafft es aber dennoch gekonnt ein Bild zu kreieren, in dem Hoffnung, dank einer Welt voller Menschen, die sich und andere belügen, nicht mehr greifbar zu sein scheint."
<G-vec00179-001-s511><create.kreieren><en> If there was a Supreme Being that was some kind of directional force behind all that is, and he was like a man, he wouldn't be able to create a peanut butter sandwich let alone a universe.
<G-vec00179-001-s511><create.kreieren><de> Wenn da ein höchstes Wesen war, von einer Art zielgerichteter Kraft, die hinter allem ist, war und er wie ein Mensch war, würde er nicht fähig sein, ein Erdnußbutterbrot zu kreieren, geschweige denn ein Universum.
<G-vec00179-001-s512><create.kreieren><en> For SilverStone, every new form factor presents an opportunity to create designs that can completely abandon conventional perception of what enclosures could look and feel.
<G-vec00179-001-s512><create.kreieren><de> Fur SilverStone bietet jeder neue Formfaktor die Chance, Designs zu kreieren, welche vollstandig von den herkommlichen Vorstellungen, wie ein Gehause aussehen und was es aussagen soll, abweichen.
<G-vec00001-001-s513><create.legen><en> You use the analysis line assignment to create freely definable key performance indicators to whose calculation values from analyses are relevant.
<G-vec00001-001-s513><create.legen><de> Mit Hilfe der Auswertungszeilenzuordnung legen Sie freidefinierbare Kennzahlen an, für deren Berechnung Werte aus Auswertungen relevant sind.
<G-vec00001-001-s514><create.legen><en> Create a corporate account when you are registering: You will thus have access to special privileges reserved for your enterprise.
<G-vec00001-001-s514><create.legen><de> Legen Sie bei Ihrer Registrierung einen Firmenaccount an: So haben Sie Zugriff auf bestimmte Vorteile, die Ihrem Unternehmen vorbehalten sind.
<G-vec00001-001-s515><create.legen><en> Create here the directory hello and in it the file hello.go.
<G-vec00001-001-s515><create.legen><de> Legen Sie hier das Verzeichnis hello an und darin die Datei hello.go.
<G-vec00001-001-s516><create.legen><en> "If messages such as ""Data base directory not found"" appear, then please create a ""C:\HEXAGON"" directory and copy all the relevant .cfg files into it."
<G-vec00001-001-s516><create.legen><de> "Wenn Sie nun Meldungen erhalten wie ""Datenbank-Directory nicht gefunden"", legen Sie bitte ein Verzeichnis ""C:\HEXAGON"" an und kopieren Sie alle cfg-Dateien dorthin."
<G-vec00001-001-s517><create.legen><en> Here you can create and manage your articles.
<G-vec00001-001-s517><create.legen><de> Legen Sie hier Ihre Artikel an und verwalten diese.
<G-vec00001-001-s518><create.legen><en> involving the local parts of the file, that were not transferred with, because they were already present on the server B), to then extracted to create the location.
<G-vec00001-001-s518><create.legen><de> unter Einbeziehung der lokalen Teile der Datei, die nicht mit übertragen wurden, weil Sie auf dem Server B schon vorhanden waren), um sie dann entpackt an den Speicherort zu legen.
<G-vec00001-001-s519><create.legen><en> "Or you send us a wish list via email and we create a ""virtual WunschKISTE"" on your name."
<G-vec00001-001-s519><create.legen><de> "Oder Du sendest uns per eMail eine Wunschliste zu und wir legen eine ""virtuelle Kiste"" auf Deinen Namen an."
<G-vec00001-001-s520><create.legen><en> With extensive planning and support options, Cisco Services can help you create the foundation for more effective client relationships and improved customer service with integrated contact center solutions.
<G-vec00001-001-s520><create.legen><de> Mit den umfassenden Service-Optionen für Planung und Support von Cisco legen Sie das Fundament für die Nutzung von integrierten Contact Center-Lösungen zur effektiven Kommunikation mit Kunden und zur Verbesserung des Kundenservice.
<G-vec00001-001-s521><create.legen><en> Through our action research and our service design and design thinking approach, we were able to create together with the 360 team and all participants a basis for an internal cultural change and are now looking forward to the next steps.
<G-vec00001-001-s521><create.legen><de> Durch unsere Action Research, sowie unseren Service Design und Design Thinking Ansatz, konnten wir gemeinsam mit dem 360 Team und allen Teilnehmernerste Grundsteine für einen internen, kulturellen Wandeln legen und freuen uns nun auf die nächsten Schritte.
<G-vec00001-001-s522><create.legen><en> When an Internet user comes to our site via one of these links, we create a cookie with a life of one year indicating that your identifier is the source of the contact.
<G-vec00001-001-s522><create.legen><de> Wenn ein Internetnutzer über einen solchen Link auf unsere Seite gelangt, legen wir einen Cookie mit einer Laufzeit von einem Jahr an, der anzeigt, dass Sie der Grund für die Kontaktaufnahme waren.
<G-vec00001-001-s523><create.legen><en> Thus, the United States introduced Russia to Syria to support the regime and create the atmosphere for the American solution.
<G-vec00001-001-s523><create.legen><de> Es waren demnach die USA, die den Russen Zutritt in Syrien verschafften, damit diese das syrische Regime unterstützen und die Weichen für eine amerikanische Lösung legen.
<G-vec00001-001-s524><create.legen><en> Click profiling lets you create profiles – independent of individual mailings or links – that are associated with all the tracked links in your mailings.
<G-vec00001-001-s524><create.legen><de> Mit der Klickprofilierung legen Sie – unabhängig von einzelnen Mailings oder einzelnen Links – Profile an, denen alle getrackten Links Ihrer Mailings zugeordnet werden.
<G-vec00001-001-s525><create.legen><en> To make you feel comfortable while Hula Hooping in any way, appealing functionality in addition to a modern design ensures a noticeable value: Please choose when ordering an individual diameter to create a perfect fit as the basis for an effective workout.
<G-vec00001-001-s525><create.legen><de> Damit Sie sich beim Hula Hooping in jeder Hinsicht wohlfühlen, sorgt die ansprechende Funktionalität neben dem modernen Design für einen spürbaren Mehrwert: Wählen Sie bei der Bestellung einen individuellen Durchmesser, um eine optimale Passform als Basis für ein effektives Training zu legen.
<G-vec00001-001-s526><create.legen><en> "For example, for the tax territory ""Germany"" you create the revenue group 1 for business activities that are taxed using the German standard tax rate."
<G-vec00001-001-s526><create.legen><de> "So legen Sie beispielsweise unter dem Steuergebiet ""Deutschland"" die Erlösgruppe ""1"" an für Geschäftsvorgänge, die zum deutschen Regelsteuersatz besteuert werden."
<G-vec00001-001-s527><create.legen><en> Here too, please create a customer account in our online shop and then contact us briefly.
<G-vec00001-001-s527><create.legen><de> Auch hier legen Sie sich bitte ein Kundenkonto in unserem Onlineshop an und nehmen anschließend kurz Kontakt mit uns auf.
<G-vec00001-001-s528><create.legen><en> You create extensive tunnel systems that connect the various rooms and inputs together.
<G-vec00001-001-s528><create.legen><de> Sie legen ausgedehnte Tunnelsysteme an, die die verschiedenen Räume und Eingänge miteinander verbinden.
<G-vec00001-001-s529><create.legen><en> Example: If you want to sync desktop and notebook, then install Easy2Sync for Outlook on both and create a task on the desktop.
<G-vec00001-001-s529><create.legen><de> Wenn Sie also Desktop und Notebook synchronisieren möchten, installieren Sie Easy2Sync auf beiden und legen auf dem Desktop eine Aufgabe an.
<G-vec00001-001-s530><create.legen><en> We'll create a new project, import videos and play them back in different ways.
<G-vec00001-001-s530><create.legen><de> Wir legen ein neues Projekt an, importieren Videos und spielen sie auf verschiedene Weise ab.
<G-vec00001-001-s531><create.legen><en> To do that, create a new attribute with the string type and with a length of 50 in the Schema Manager for users and/or groups.
<G-vec00001-001-s531><create.legen><de> Legen Sie dazu im Schemamanager für Benutzer und/oder Gruppen ein neues Attribut (Typ String) mit einer Länge von 50 Zeichen an.
<G-vec00001-001-s551><create.schaffen><en> And if the person tries to create this condition himself then, due to imperfection, the opposite usually will happen: unkindness will destroy harmony, and indifference or animosities will become people’s companions in life, although within themselves they harbour the desire for unity and mutual understanding.
<G-vec00001-001-s551><create.schaffen><de> Und wenn sich der Mensch selbst einen solchen Zustand zu schaffen sucht, wird der Unvollkommenheit wegen zumeist das Gegenteil der Fall sein: Lieblosigkeit wird Harmonie zerstören, und Gleichgültigkeit oder Feindseligkeiten werden Lebensbegleiter sein von Menschen, denen jedoch das Verlangen nach Verbundenheit und gegenseitigem Verstehen innewohnt.
<G-vec00001-001-s552><create.schaffen><en> The successful project of the parliamentary buildings is not enough to create confidence in the technology: therefore, it would be important to support more projects up until their demonstration.
<G-vec00001-001-s552><create.schaffen><de> Das erfolgreiche Projektbeispiel der Parlamentsbauten reicht nicht, um Vertrauen in die Technologie zu schaffen: Deshalb wäre es wichtig, dass weitere Projekte bis zur Demonstration unterstützt werden.
<G-vec00001-001-s553><create.schaffen><en> If you need to send flowers to Oistins, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00001-001-s553><create.schaffen><de> Wenn Sie Blumen in die Oistins schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00001-001-s554><create.schaffen><en> In effect the customer can, even with modest means, create a personal investment plan protected by an insurance policy to at least guarantee the initial capital in the event of losses.
<G-vec00001-001-s554><create.schaffen><de> Der Kunde kann praktisch auch mit einem bescheidenen Kapital eine wahrhaftige Vermögensverwaltung schaffen, die durch eine Versicherungspolice geschützt ist, so dass im Todesfall die Rückerstattung mindestens des Anfangskapitals garantiert ist.
<G-vec00001-001-s555><create.schaffen><en> If you need to send flowers to Lhokseumawe, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00001-001-s555><create.schaffen><de> Wenn Sie Blumen in die Lhokseumawe schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00001-001-s556><create.schaffen><en> "This ""intensification"" certainly did and does not mean, neither in Metzger's context of the Art Strike nor in the institutional practice of intensifying theory production that is to be discussed here, a praise of pure contemplation, but rather a condensation, not an invocation to flee from the world, but rather to change the world, not to cease all production, but rather to create worlds."
<G-vec00001-001-s556><create.schaffen><de> "Dieses ""Vertiefen in Theorie"" bedeutet(e) nun sicherlich weder in Metzgers Kontext des Kunststreiks noch in jener institutionellen Praxis der Vertiefung, von der im Folgenden die Rede sein wird, ein Lob der reinen Kontemplation, sondern vielmehr Intensität und Intensivierung, nicht die Anrufung der Weltflucht, sondern Weltveränderung, nicht die Einstellung jedweder Produktion, sondern das Schaffen von Welten."
<G-vec00001-001-s557><create.schaffen><en> One might think that Thomson would have eagerly supported Maxwell 's theory which his own work had helped to create, but this was not so.
<G-vec00001-001-s557><create.schaffen><de> Man könnte denken, dass Thomson hätte eifrig unterstützt Maxwell 's Theorie der seine eigene Arbeit geholfen hatte zu schaffen, aber dies war nicht so.
<G-vec00001-001-s558><create.schaffen><en> The natural materials, soothing colours and minimalist designs create a sense of calm that takes us back to the very heart of cooking .
<G-vec00001-001-s558><create.schaffen><de> Die natürlichen Materialien, die sanften Farben und das minimalistische Design schaffen ein Gefühl der Ruhe, das uns mitten ins Herz des Kochens zurückführt.
<G-vec00001-001-s559><create.schaffen><en> To log in under the account of the administrator and to create the new account of the user instead of the damaged.
<G-vec00001-001-s559><create.schaffen><de> Ins System unter der Berechnungsaufzeichnung des Verwalters einzugehen und, die neue Berechnungsaufzeichnung des Benutzers anstatt der Beschädigten zu schaffen.
<G-vec00001-001-s560><create.schaffen><en> The living room features a wooden floor associated with a nice mosaic inspired by catalan modernism and elegant and charming furniture and decoration to create a warm and welcoming atmosphere.
<G-vec00001-001-s560><create.schaffen><de> Das Wohnzimmer verfügt über einen Holzboden mit einem schönen Mosaik von katalanischen Modernismus und elegante und charmante Möbel und Dekoration inspiriert, um eine warme und einladende Atmosphäre zu schaffen assoziiert.
<G-vec00001-001-s561><create.schaffen><en> If you need to send flowers to Yinchuan, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00001-001-s561><create.schaffen><de> Wenn Sie Blumen in die Yinchuan schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00001-001-s562><create.schaffen><en> """Surely it is better to create tomorrow's past than to repeat today's"" Edgar Mansfield (1907-1996) The first day of this five-day course will be an introduction to the ideals and principles which guide the work of Tomorrow's Past."
<G-vec00001-001-s562><create.schaffen><de> """Sicherlich ist es besser die Vergangenheit von morgen zu schaffen, als die heutige zu wiederholen"" Edgar Mansfield (1907-1996) Der erste Tag dieses fünftägigen Kurses wird eine Einführung in die Ideale und Grundsätze sein, die durch die Arbeiten des Kurses führen."
<G-vec00001-001-s563><create.schaffen><en> You’re trying to create credibility and demonstrate your expertise.
<G-vec00001-001-s563><create.schaffen><de> Du willst Glaubwürdigkeit schaffen und Deine Kompetenz unter Beweis stellen.
<G-vec00001-001-s564><create.schaffen><en> We thus create the conditions for reliable results and proven test procedures.
<G-vec00001-001-s564><create.schaffen><de> Auf diese Weise schaffen wir die Voraussetzungen für zuverlässige Ergebnisse und erprobte Testabläufe.
<G-vec00001-001-s565><create.schaffen><en> You want to create rich graphical interfaces and complex, but here, it can quickly become a challenge.
<G-vec00001-001-s565><create.schaffen><de> Sie möchten die reiche und komplexe grafische Oberflächen zu schaffen, aber hier kann es schnell zu einer Herausforderung werden.
<G-vec00001-001-s566><create.schaffen><en> decoration How to make your own waterproofing the floor in the garage: create...
<G-vec00001-001-s566><create.schaffen><de> Dekoration Wie Sie Ihre eigene Abdichtung der Boden in der Garage zu machen: schaffen...
<G-vec00001-001-s567><create.schaffen><en> And it can create jobs.
<G-vec00001-001-s567><create.schaffen><de> Und er kann neue Arbeitsplätze schaffen.
<G-vec00001-001-s568><create.schaffen><en> If you need to send flowers to Kırşehir Akpınar, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00001-001-s568><create.schaffen><de> Wenn Sie Blumen in die Akpınar schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00001-001-s569><create.schaffen><en> If you need to send flowers to al-Ulmah, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00001-001-s569><create.schaffen><de> Wenn Sie Blumen in die al-Ulmah schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00179-001-s551><create.schaffen><en> And if the person tries to create this condition himself then, due to imperfection, the opposite usually will happen: unkindness will destroy harmony, and indifference or animosities will become people’s companions in life, although within themselves they harbour the desire for unity and mutual understanding.
<G-vec00179-001-s551><create.schaffen><de> Und wenn sich der Mensch selbst einen solchen Zustand zu schaffen sucht, wird der Unvollkommenheit wegen zumeist das Gegenteil der Fall sein: Lieblosigkeit wird Harmonie zerstören, und Gleichgültigkeit oder Feindseligkeiten werden Lebensbegleiter sein von Menschen, denen jedoch das Verlangen nach Verbundenheit und gegenseitigem Verstehen innewohnt.
<G-vec00179-001-s552><create.schaffen><en> The successful project of the parliamentary buildings is not enough to create confidence in the technology: therefore, it would be important to support more projects up until their demonstration.
<G-vec00179-001-s552><create.schaffen><de> Das erfolgreiche Projektbeispiel der Parlamentsbauten reicht nicht, um Vertrauen in die Technologie zu schaffen: Deshalb wäre es wichtig, dass weitere Projekte bis zur Demonstration unterstützt werden.
<G-vec00179-001-s553><create.schaffen><en> If you need to send flowers to Oistins, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00179-001-s553><create.schaffen><de> Wenn Sie Blumen in die Oistins schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00179-001-s554><create.schaffen><en> In effect the customer can, even with modest means, create a personal investment plan protected by an insurance policy to at least guarantee the initial capital in the event of losses.
<G-vec00179-001-s554><create.schaffen><de> Der Kunde kann praktisch auch mit einem bescheidenen Kapital eine wahrhaftige Vermögensverwaltung schaffen, die durch eine Versicherungspolice geschützt ist, so dass im Todesfall die Rückerstattung mindestens des Anfangskapitals garantiert ist.
<G-vec00179-001-s555><create.schaffen><en> If you need to send flowers to Lhokseumawe, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00179-001-s555><create.schaffen><de> Wenn Sie Blumen in die Lhokseumawe schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00179-001-s556><create.schaffen><en> "This ""intensification"" certainly did and does not mean, neither in Metzger's context of the Art Strike nor in the institutional practice of intensifying theory production that is to be discussed here, a praise of pure contemplation, but rather a condensation, not an invocation to flee from the world, but rather to change the world, not to cease all production, but rather to create worlds."
<G-vec00179-001-s556><create.schaffen><de> "Dieses ""Vertiefen in Theorie"" bedeutet(e) nun sicherlich weder in Metzgers Kontext des Kunststreiks noch in jener institutionellen Praxis der Vertiefung, von der im Folgenden die Rede sein wird, ein Lob der reinen Kontemplation, sondern vielmehr Intensität und Intensivierung, nicht die Anrufung der Weltflucht, sondern Weltveränderung, nicht die Einstellung jedweder Produktion, sondern das Schaffen von Welten."
<G-vec00179-001-s557><create.schaffen><en> One might think that Thomson would have eagerly supported Maxwell 's theory which his own work had helped to create, but this was not so.
<G-vec00179-001-s557><create.schaffen><de> Man könnte denken, dass Thomson hätte eifrig unterstützt Maxwell 's Theorie der seine eigene Arbeit geholfen hatte zu schaffen, aber dies war nicht so.
<G-vec00179-001-s558><create.schaffen><en> The natural materials, soothing colours and minimalist designs create a sense of calm that takes us back to the very heart of cooking .
<G-vec00179-001-s558><create.schaffen><de> Die natürlichen Materialien, die sanften Farben und das minimalistische Design schaffen ein Gefühl der Ruhe, das uns mitten ins Herz des Kochens zurückführt.
<G-vec00179-001-s559><create.schaffen><en> To log in under the account of the administrator and to create the new account of the user instead of the damaged.
<G-vec00179-001-s559><create.schaffen><de> Ins System unter der Berechnungsaufzeichnung des Verwalters einzugehen und, die neue Berechnungsaufzeichnung des Benutzers anstatt der Beschädigten zu schaffen.
<G-vec00179-001-s560><create.schaffen><en> The living room features a wooden floor associated with a nice mosaic inspired by catalan modernism and elegant and charming furniture and decoration to create a warm and welcoming atmosphere.
<G-vec00179-001-s560><create.schaffen><de> Das Wohnzimmer verfügt über einen Holzboden mit einem schönen Mosaik von katalanischen Modernismus und elegante und charmante Möbel und Dekoration inspiriert, um eine warme und einladende Atmosphäre zu schaffen assoziiert.
<G-vec00179-001-s561><create.schaffen><en> If you need to send flowers to Yinchuan, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00179-001-s561><create.schaffen><de> Wenn Sie Blumen in die Yinchuan schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00179-001-s562><create.schaffen><en> """Surely it is better to create tomorrow's past than to repeat today's"" Edgar Mansfield (1907-1996) The first day of this five-day course will be an introduction to the ideals and principles which guide the work of Tomorrow's Past."
<G-vec00179-001-s562><create.schaffen><de> """Sicherlich ist es besser die Vergangenheit von morgen zu schaffen, als die heutige zu wiederholen"" Edgar Mansfield (1907-1996) Der erste Tag dieses fünftägigen Kurses wird eine Einführung in die Ideale und Grundsätze sein, die durch die Arbeiten des Kurses führen."
<G-vec00179-001-s563><create.schaffen><en> You’re trying to create credibility and demonstrate your expertise.
<G-vec00179-001-s563><create.schaffen><de> Du willst Glaubwürdigkeit schaffen und Deine Kompetenz unter Beweis stellen.
<G-vec00179-001-s564><create.schaffen><en> We thus create the conditions for reliable results and proven test procedures.
<G-vec00179-001-s564><create.schaffen><de> Auf diese Weise schaffen wir die Voraussetzungen für zuverlässige Ergebnisse und erprobte Testabläufe.
<G-vec00179-001-s565><create.schaffen><en> You want to create rich graphical interfaces and complex, but here, it can quickly become a challenge.
<G-vec00179-001-s565><create.schaffen><de> Sie möchten die reiche und komplexe grafische Oberflächen zu schaffen, aber hier kann es schnell zu einer Herausforderung werden.
<G-vec00179-001-s566><create.schaffen><en> decoration How to make your own waterproofing the floor in the garage: create...
<G-vec00179-001-s566><create.schaffen><de> Dekoration Wie Sie Ihre eigene Abdichtung der Boden in der Garage zu machen: schaffen...
<G-vec00179-001-s567><create.schaffen><en> And it can create jobs.
<G-vec00179-001-s567><create.schaffen><de> Und er kann neue Arbeitsplätze schaffen.
<G-vec00179-001-s568><create.schaffen><en> If you need to send flowers to Kırşehir Akpınar, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00179-001-s568><create.schaffen><de> Wenn Sie Blumen in die Akpınar schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00179-001-s569><create.schaffen><en> If you need to send flowers to al-Ulmah, just select some design among our Turkish flowers – take a look at our pages with pictures and vivid photos of the bouquets. When we started to create the list of bouquets and flower arrangements for you to choose from, we wanted it to have designs in different styles, so every visitor of our Internet flower shop can find something nice for themselves.
<G-vec00179-001-s569><create.schaffen><de> Wenn Sie Blumen in die al-Ulmah schicken müssen, wählen Sie einfach etwas Design unter unseren türkischen Blumen-werfen Sie einen Blick auf unsere Seiten mit Bildern und lebhaften Fotos von den Sträußen.Als wir begannen, die Liste der Blumensträuße und Blumenarrangements für Sie zur Auswahl zu schaffen, wollten wir, dass es Designs in verschiedenen Stilen haben, so dass jeder Besucher unserer Internet-Blumenladen kann etwas nettes für sich selbst zu finden.
<G-vec00001-001-s570><create.schaffen><en> Create the conditions for mental activity.
<G-vec00001-001-s570><create.schaffen><de> Schaffen Sie die Voraussetzungen für geistige Aktivität.
<G-vec00001-001-s571><create.schaffen><en> Call on the help of neighbors and create for your children a whole gaming complex together.
<G-vec00001-001-s571><create.schaffen><de> Rufen Sie die Hilfe von Nachbarn an und schaffen Sie für Ihre Kinder einen ganzen Spielkomplex zusammen.
<G-vec00001-001-s572><create.schaffen><en> """ We don't often see such a beautiful and efficient eye-catcher: use flowers that would otherwise be thrown away and create a beautiful decoration."
<G-vec00001-001-s572><create.schaffen><de> Wir sehen nicht oft einen so schönen und effizienten Blickfang: Verwenden Sie Blumen, die sonst weggeworfen würden, und schaffen Sie eine schöne Dekoration.
<G-vec00001-001-s573><create.schaffen><en> Create stronger relationships with your customers by offering to be the keeper of their valuable digital data.
<G-vec00001-001-s573><create.schaffen><de> Schaffen Sie stärkere Beziehungen zu Ihren Kunden, indem Sie Ihnen anbieten, ihre wertvollen digitalen Daten aufzubewahre.
<G-vec00001-001-s574><create.schaffen><en> At first create a loop of the average size on the end of a wire, then unbend it down and create one more loop.
<G-vec00001-001-s574><create.schaffen><de> Erstens bilden Sie die Schlinge des mittleren Umfanges ausgangs des Drahtes, dann otognite sie nach unten und schaffen Sie noch eine Schlinge.
<G-vec00001-001-s575><create.schaffen><en> To create similar laying use the curling iron of small diameter, do not wind hair at roots and try to hold the device horizontally.
<G-vec00001-001-s575><create.schaffen><de> Um das ähnliche Verpacken zu schaffen nutzen Sie plojkoj des kleinen Durchmessers aus, drehen Sie das Haar bei den Wurzeln nicht zusammen und bemühen Sie sich, das Gerät horizontal zu halten.
<G-vec00001-001-s576><create.schaffen><en> Archive Brand: Yankeecandle Lamp Fragrance:Â Halloween Pumpkin Create own, unique fra..
<G-vec00001-001-s576><create.schaffen><de> Archiv Die Handelsmarke: Yankeecandle Duftlampe: Halloween Pumpkin Schaffen Sie die eige..
<G-vec00001-001-s577><create.schaffen><en> Partnering with a name like FedEx Express will not only create confidence in your shipping capabilities – but our small business support team can advise you on how and what to offer in terms of delivery.
<G-vec00001-001-s577><create.schaffen><de> Wenn Sie sich mit einem starken Partner wie FedEx Express zusammenschließen, schaffen Sie Vertrauen in Ihre Lieferfähigkeiten – und unser Support-Team für kleine Unternehmen berät Sie gerne wie und was Sie zum Thema Lieferung anbieten können.
<G-vec00001-001-s578><create.schaffen><en> Video: Ford Mustang owners gather in Poland, create amazing mini movie — AutoMK
<G-vec00001-001-s578><create.schaffen><de> ideo: Ford Mustang Besitzer versammeln sich in Polen, schaffen Sie erstaunlichen kleinen Film.
<G-vec00001-001-s579><create.schaffen><en> On the national level, the international Donors Working Group also works to create framework conditions that foster the abandonment of female genital mutilation by seeking a dialogue with governments and by supporting local media in their attempts to overcome the taboo and publicly raise the issue of female genital mutilation.
<G-vec00001-001-s579><create.schaffen><de> Die internationale Donors Working Group setzt sich außerdem dafür ein, auf nationaler Ebene günstige Rahmenbedingungen für eine Abkehr von weiblicher Genitalverstümmelung zu schaffen, indem sie den Dialog mit Regierungen sucht und lokale Medien unterstützt, sich über das Tabu hinweg zu setzen und weibliche Genitalverstümmelung öffentlich zu thematisieren.
<G-vec00001-001-s580><create.schaffen><en> Create a soft and soothing glow with this fun ceramic unicorn table lamp.
<G-vec00001-001-s580><create.schaffen><de> Mit dieser lustigen Keramik Einhorn Tischlampe schaffen Sie einen sanften und beruhigenden Glanz.
<G-vec00001-001-s581><create.schaffen><en> Use a stimulating intonation and rhythm when you speak to create a tension that attracts your audience
<G-vec00001-001-s581><create.schaffen><de> Belebende Intonation - durch den Ihnen gemäßen Sprechrhythmus schaffen Sie einen Spannungsbogen, der Ihren Zuhörer fesselt.
<G-vec00001-001-s582><create.schaffen><en> Don't just run jobs, create the agile enterprise. Simplify application automation.
<G-vec00001-001-s582><create.schaffen><de> Führen Sie nicht nur Jobs aus, sondern schaffen Sie das agile Unternehmen.
<G-vec00001-001-s583><create.schaffen><en> Example 3—your corporate event: Opt for one of our glazed atriums with adjoining show rooms, and create an exclusive ambience for a compelling appearance of your brand.
<G-vec00001-001-s583><create.schaffen><de> Beispiel 3 – Ihr Corporate Event: Wählen Sie eines unserer verglasten Atrien mit angrenzenden Showrooms und schaffen Sie ein exklusives Ambiente für einen starken Auftritt Ihrer Marke.
<G-vec00001-001-s584><create.schaffen><en> Hairpin Green Create a bespoke feel in your space with the Green Geometric infinite Loop Striped Wallpaper Mural, a cool loop design that is eye-catching yet soft and welcoming in tone.
<G-vec00001-001-s584><create.schaffen><de> Schaffen Sie mit dem Tapeten-Wandbild „Endlosschleife – Geometrisch/Gestreift – Blau“, einem coolen Schleifen-Design, das auffallend und dennoch weich und einladend im Ton ist, ein individuelles Gefühl in Ihrem Raum.
<G-vec00001-001-s585><create.schaffen><en> Consequently, create places where you find the strength to no longer give resonance to the power of war - neither in the world nor in yourself.
<G-vec00001-001-s585><create.schaffen><de> Schaffen Sie also Orte, wo Sie die Kraft finden, den Kriegskräften keine Resonanz mehr zu geben, weder denen in der Welt noch denen in Ihnen selbst.
<G-vec00001-001-s586><create.schaffen><en> Create this new top level domain for your family - a home on the Internet.
<G-vec00001-001-s586><create.schaffen><de> Schaffen Sie mit dieser neuen Top Level Domain für Ihre Familie ein Zuhause im Netz.
<G-vec00001-001-s587><create.schaffen><en> Information Treat yourself to beautiful moments and create a pleasant atmosphere at home.
<G-vec00001-001-s587><create.schaffen><de> Gönnen Sie sich schöne Momente und schaffen Sie zuhause ein angenehmes Ambiente.
<G-vec00001-001-s588><create.schaffen><en> Create everlasting memories with your loved one on the island, against a backdrop of sun, sea and beautiful sunset views.
<G-vec00001-001-s588><create.schaffen><de> Schaffen Sie bleibende Erinnerungen mit Ihrem oder Ihrer Liebsten auf der sonnigen Insel mit dem Meer und Sonnenuntergängen als perfekte Kulisse.
<G-vec00179-001-s570><create.schaffen><en> Create the conditions for mental activity.
<G-vec00179-001-s570><create.schaffen><de> Schaffen Sie die Voraussetzungen für geistige Aktivität.
<G-vec00179-001-s571><create.schaffen><en> Call on the help of neighbors and create for your children a whole gaming complex together.
<G-vec00179-001-s571><create.schaffen><de> Rufen Sie die Hilfe von Nachbarn an und schaffen Sie für Ihre Kinder einen ganzen Spielkomplex zusammen.
<G-vec00179-001-s572><create.schaffen><en> """ We don't often see such a beautiful and efficient eye-catcher: use flowers that would otherwise be thrown away and create a beautiful decoration."
<G-vec00179-001-s572><create.schaffen><de> Wir sehen nicht oft einen so schönen und effizienten Blickfang: Verwenden Sie Blumen, die sonst weggeworfen würden, und schaffen Sie eine schöne Dekoration.
<G-vec00179-001-s573><create.schaffen><en> Create stronger relationships with your customers by offering to be the keeper of their valuable digital data.
<G-vec00179-001-s573><create.schaffen><de> Schaffen Sie stärkere Beziehungen zu Ihren Kunden, indem Sie Ihnen anbieten, ihre wertvollen digitalen Daten aufzubewahre.
<G-vec00179-001-s574><create.schaffen><en> At first create a loop of the average size on the end of a wire, then unbend it down and create one more loop.
<G-vec00179-001-s574><create.schaffen><de> Erstens bilden Sie die Schlinge des mittleren Umfanges ausgangs des Drahtes, dann otognite sie nach unten und schaffen Sie noch eine Schlinge.
<G-vec00179-001-s575><create.schaffen><en> To create similar laying use the curling iron of small diameter, do not wind hair at roots and try to hold the device horizontally.
<G-vec00179-001-s575><create.schaffen><de> Um das ähnliche Verpacken zu schaffen nutzen Sie plojkoj des kleinen Durchmessers aus, drehen Sie das Haar bei den Wurzeln nicht zusammen und bemühen Sie sich, das Gerät horizontal zu halten.
<G-vec00179-001-s576><create.schaffen><en> Archive Brand: Yankeecandle Lamp Fragrance:Â Halloween Pumpkin Create own, unique fra..
<G-vec00179-001-s576><create.schaffen><de> Archiv Die Handelsmarke: Yankeecandle Duftlampe: Halloween Pumpkin Schaffen Sie die eige..
<G-vec00179-001-s577><create.schaffen><en> Partnering with a name like FedEx Express will not only create confidence in your shipping capabilities – but our small business support team can advise you on how and what to offer in terms of delivery.
<G-vec00179-001-s577><create.schaffen><de> Wenn Sie sich mit einem starken Partner wie FedEx Express zusammenschließen, schaffen Sie Vertrauen in Ihre Lieferfähigkeiten – und unser Support-Team für kleine Unternehmen berät Sie gerne wie und was Sie zum Thema Lieferung anbieten können.
<G-vec00179-001-s578><create.schaffen><en> Video: Ford Mustang owners gather in Poland, create amazing mini movie — AutoMK
<G-vec00179-001-s578><create.schaffen><de> ideo: Ford Mustang Besitzer versammeln sich in Polen, schaffen Sie erstaunlichen kleinen Film.
<G-vec00179-001-s579><create.schaffen><en> On the national level, the international Donors Working Group also works to create framework conditions that foster the abandonment of female genital mutilation by seeking a dialogue with governments and by supporting local media in their attempts to overcome the taboo and publicly raise the issue of female genital mutilation.
<G-vec00179-001-s579><create.schaffen><de> Die internationale Donors Working Group setzt sich außerdem dafür ein, auf nationaler Ebene günstige Rahmenbedingungen für eine Abkehr von weiblicher Genitalverstümmelung zu schaffen, indem sie den Dialog mit Regierungen sucht und lokale Medien unterstützt, sich über das Tabu hinweg zu setzen und weibliche Genitalverstümmelung öffentlich zu thematisieren.
<G-vec00179-001-s580><create.schaffen><en> Create a soft and soothing glow with this fun ceramic unicorn table lamp.
<G-vec00179-001-s580><create.schaffen><de> Mit dieser lustigen Keramik Einhorn Tischlampe schaffen Sie einen sanften und beruhigenden Glanz.
<G-vec00179-001-s581><create.schaffen><en> Use a stimulating intonation and rhythm when you speak to create a tension that attracts your audience
<G-vec00179-001-s581><create.schaffen><de> Belebende Intonation - durch den Ihnen gemäßen Sprechrhythmus schaffen Sie einen Spannungsbogen, der Ihren Zuhörer fesselt.
<G-vec00179-001-s582><create.schaffen><en> Don't just run jobs, create the agile enterprise. Simplify application automation.
<G-vec00179-001-s582><create.schaffen><de> Führen Sie nicht nur Jobs aus, sondern schaffen Sie das agile Unternehmen.
<G-vec00179-001-s583><create.schaffen><en> Example 3—your corporate event: Opt for one of our glazed atriums with adjoining show rooms, and create an exclusive ambience for a compelling appearance of your brand.
<G-vec00179-001-s583><create.schaffen><de> Beispiel 3 – Ihr Corporate Event: Wählen Sie eines unserer verglasten Atrien mit angrenzenden Showrooms und schaffen Sie ein exklusives Ambiente für einen starken Auftritt Ihrer Marke.
<G-vec00179-001-s584><create.schaffen><en> Hairpin Green Create a bespoke feel in your space with the Green Geometric infinite Loop Striped Wallpaper Mural, a cool loop design that is eye-catching yet soft and welcoming in tone.
<G-vec00179-001-s584><create.schaffen><de> Schaffen Sie mit dem Tapeten-Wandbild „Endlosschleife – Geometrisch/Gestreift – Blau“, einem coolen Schleifen-Design, das auffallend und dennoch weich und einladend im Ton ist, ein individuelles Gefühl in Ihrem Raum.
<G-vec00179-001-s585><create.schaffen><en> Consequently, create places where you find the strength to no longer give resonance to the power of war - neither in the world nor in yourself.
<G-vec00179-001-s585><create.schaffen><de> Schaffen Sie also Orte, wo Sie die Kraft finden, den Kriegskräften keine Resonanz mehr zu geben, weder denen in der Welt noch denen in Ihnen selbst.
<G-vec00179-001-s586><create.schaffen><en> Create this new top level domain for your family - a home on the Internet.
<G-vec00179-001-s586><create.schaffen><de> Schaffen Sie mit dieser neuen Top Level Domain für Ihre Familie ein Zuhause im Netz.
<G-vec00179-001-s587><create.schaffen><en> Information Treat yourself to beautiful moments and create a pleasant atmosphere at home.
<G-vec00179-001-s587><create.schaffen><de> Gönnen Sie sich schöne Momente und schaffen Sie zuhause ein angenehmes Ambiente.
<G-vec00179-001-s588><create.schaffen><en> Create everlasting memories with your loved one on the island, against a backdrop of sun, sea and beautiful sunset views.
<G-vec00179-001-s588><create.schaffen><de> Schaffen Sie bleibende Erinnerungen mit Ihrem oder Ihrer Liebsten auf der sonnigen Insel mit dem Meer und Sonnenuntergängen als perfekte Kulisse.
<G-vec00001-001-s589><create.schaffen><en> Proper composting requires adequate mass to create an environment suitable for bacterial growth.
<G-vec00001-001-s589><create.schaffen><de> Passende Kompostierung erfordert, dass angemessene Masse eine Umwelt schafft, die passend ist für bakterielles Wachstum.
<G-vec00001-001-s590><create.schaffen><en> The raw materials warehouse asks how to create the best conditions for storing the essential oils.
<G-vec00001-001-s590><create.schaffen><de> Das Rohstofflager fragt an, wie man für die Lagerung der ätherischen Öle die besten Bedingungen schafft.
<G-vec00001-001-s591><create.schaffen><en> It is impossible, through hatred and persecution or slander and bitterness, to create in one's neighbour joy, inspiration or zest for life.
<G-vec00001-001-s591><create.schaffen><de> Durch Haß und Verfolgung, Verleumdung und Bitterkeit schafft man bei seinem Nächsten unmöglich Freude und Inspiration oder Lebenslust.
<G-vec00001-001-s592><create.schaffen><en> Create Conditional Formula is a wizard in Optipe Data Tools Suite that lets you create in the currently selected cell a formula to find, count or add data conditionally, for one or multiple criteria, similar to Merge Tables application.
<G-vec00001-001-s592><create.schaffen><de> Erstellen Bedingte Formel wird ein Assistent in Optipe Data Tools Suite, die, schafft in der aktuell ausgewählten Zelle, eine Formel bedingte: zu finden, zählen oder Summendaten; für ein oder mehrere Kriterien, ähnlich wie die Verknüpfen von Tabellen Anwendung.
<G-vec00001-001-s593><create.schaffen><en> Thus, for example, which does not jeopardize solid relationships and the corresponding families, which does not create confusion in others with false promises or otherwise, that do not abuse a preeminent position and, finally, the that it does not precede the selfishness of the own satisfaction to the well-being of our fellow human beings.
<G-vec00001-001-s593><create.schaffen><de> So zum Beispiel die nicht gefährdet feste Beziehungen und die entsprechenden Familien, die keine Verwirrung in anderen mit falschen Versprechungen schafft oder andernfalls, die eine herausragende Stellung nicht missbrauchen und schließlich die dass es nicht den Egoismus der eigenen Zufriedenheit, das Wohlbefinden unserer Mitmenschen vorausgehen.
<G-vec00001-001-s594><create.schaffen><en> It does not restore, or create safe havens.
<G-vec00001-001-s594><create.schaffen><de> Sie restauriert nicht, schafft keine Reservate.
<G-vec00001-001-s595><create.schaffen><en> Even though the manufacturing sector does not create new jobs, it generates innovation, wealth and high value added services.
<G-vec00001-001-s595><create.schaffen><de> Auch wenn der Produktionssektor keine neuen Arbeitsplätze schafft, erzeugt er Innovation, Wohlstand und einen hohen Wertzuwachs.
<G-vec00001-001-s596><create.schaffen><en> Linear create it to have the linear object representation and not the icon, Because the second wanted to write artistic hand seq time consuming.
<G-vec00001-001-s596><create.schaffen><de> Lineare es schafft die lineare Objektdarstellung haben und nicht das Symbol, Da der zweite wollte künstlerische Hand seq Zeit schreiben raubend.
<G-vec00001-001-s597><create.schaffen><en> Given the present water quality, this will create good conditions for aquacultures, in particular for pisciculture.
<G-vec00001-001-s597><create.schaffen><de> Dies schafft bei der vorhandenen Wasserqualität gute Voraussetzungen für Aquakulturen, besonders für die Fischzucht.
<G-vec00001-001-s598><create.schaffen><en> The well can be used and the fireplace is another feature typical of the traditional houses in the agricultural areas of the region Marche, that is able to create a cozy atmosphere and to heat not only the space but also the owners' and the hosts' souls.
<G-vec00001-001-s598><create.schaffen><de> Der Brunnen kann genutzt werden und der Kamin ist ein weiteres Merkmal der traditionellen Häuser in den landwirtschaftlichen Gebieten der Region Marken: der Kamin schafft eine gemütliche Atmosphäre, man heizt nicht nur den Raum, sondern auch die Seele des Besitzers und der Gastgeber.
<G-vec00001-001-s599><create.schaffen><en> Cascio uses simple material such as cardboard, wood and neon to create allegorical installations that reflect obsessions, hopes and dreams of social progress.
<G-vec00001-001-s599><create.schaffen><de> Cascio verwendet einfaches Material wie Karton, Holz und Neonlicht und schafft damit allegorische Installationen, die Obsessionen, Hoffnungen und Träume des gesellschaftlichen Fortschritts spiegeln.
<G-vec00001-001-s600><create.schaffen><en> In Austria, where the differentiation is belated, it is not out of the question that, in particular, an “independent” party might split off from the official party and immediately, as in Germany, create a possible mass base for the Communist Party.
<G-vec00001-001-s600><create.schaffen><de> Da eine solche Differenzierung sich bisher nicht vollzogen hat, ist es vor allem nicht ausgeschlossen, daß sich in Österreich eine „unabhängige“ Partei von der offiziellen Sozialdemokratie abspaltet, die der Kommunistischen Partei mit einem Schlage – wie es in Deutschland der Fall war – eine Massenbasis schafft.
<G-vec00001-001-s601><create.schaffen><en> The setting, spirit, sense of welcome and quality of services of the Olympic Museum create the conditions that make it so unique.
<G-vec00001-001-s601><create.schaffen><de> Mit seinem Umfeld, seiner Geisteshaltung, seiner Betreuung und den qualitativ hochstehenden Dienstleistungen schafft das Olympische Museum einzigartige Bedingungen, die sich von anderen Angeboten deutlich unterscheiden.
<G-vec00001-001-s602><create.schaffen><en> In doing so, and in keeping with the «Code of Conduct», APG|SGA seeks to achieve a reasonable return on its capital so as to safeguard its growth and independence, and thereby create added value for shareholders.
<G-vec00001-001-s602><create.schaffen><de> Dabei achtet APG|SGA unter Einhaltung des «Code of Conduct» auf eine angemessene Rendite ihres Eigenkapitals, um ihre Entwicklung und Unabhängigkeit zu sichern und schafft damit einen Mehrwert für die Aktionäre.
<G-vec00001-001-s603><create.schaffen><en> Crosscan’s highly accurate sensors create the necessary acceptance in the stores, which provides a fair benchmark of the store performance.
<G-vec00001-001-s603><create.schaffen><de> Die hochgenaue Zählung der Crosscan Sensoren schafft die notwendige Akzeptanz in den Filialen, welche für eine faire Bewertung der Filialleistung sorgt.
<G-vec00001-001-s604><create.schaffen><en> Sustainable corporate policies and practices ultimately create long-term value for our stakeholders and promote innovation,” said Severin Schwan, CEO of Roche.
<G-vec00001-001-s604><create.schaffen><de> Eine nachhaltige Unternehmenspolitik schafft letztendlich langfristigen Mehrwert für unsere Stakeholder und fördert Innovation,“ so Severin Schwan, CEO von Roche.
<G-vec00001-001-s605><create.schaffen><en> "The agreement will offer the advantage of reduced tariffs on goods traded between the tripartite countries and create new opportunities for intra-regional trade"" adds William Scalco."
<G-vec00001-001-s605><create.schaffen><de> "Das Abkommen garantiert reduzierte Zollgebühren auf Waren, die zwischen den Unterzeichner-Ländern gehandelt werden und schafft neue Chancen für den innerregionalen Handel"", fügt Salco hinzu."
<G-vec00001-001-s606><create.schaffen><en> The highly protective impermeable materials in the Mölnlycke BARRIER surgical drapes and surgical staff clothing create vital barriers between the patient and healthcare professionals.
<G-vec00001-001-s606><create.schaffen><de> Die undurchlässigen Materialien mit hohem Schutz der BARRIER® OP-Abdeckungen und OP-Bekleidung schafft wichtige Barrieren zwischen den Patienten und dem medizinischen Fachpersonal.
<G-vec00001-001-s607><create.schaffen><en> All in all, Kjellberg Finsterwalde has put together a package of extensive measures which will contribute to improving the working conditions of the employees as well as to the efficiency and transparency of processes and, thus, will create an important basis for future development.
<G-vec00001-001-s607><create.schaffen><de> Alles in allem hat Kjellberg Finsterwalde ein gewaltiges Paket an Maßnahmen geschnürt, das neben der Verbesserung der Arbeitsbedingungen für die Mitarbeiter wesentlich zu Effizienz und Transparenz der Prozesse beitragen wird und damit eine wichtige Grundlage für die künftige Entwicklung schafft.
<G-vec00179-001-s589><create.schaffen><en> Proper composting requires adequate mass to create an environment suitable for bacterial growth.
<G-vec00179-001-s589><create.schaffen><de> Passende Kompostierung erfordert, dass angemessene Masse eine Umwelt schafft, die passend ist für bakterielles Wachstum.
<G-vec00179-001-s590><create.schaffen><en> The raw materials warehouse asks how to create the best conditions for storing the essential oils.
<G-vec00179-001-s590><create.schaffen><de> Das Rohstofflager fragt an, wie man für die Lagerung der ätherischen Öle die besten Bedingungen schafft.
<G-vec00179-001-s591><create.schaffen><en> It is impossible, through hatred and persecution or slander and bitterness, to create in one's neighbour joy, inspiration or zest for life.
<G-vec00179-001-s591><create.schaffen><de> Durch Haß und Verfolgung, Verleumdung und Bitterkeit schafft man bei seinem Nächsten unmöglich Freude und Inspiration oder Lebenslust.
<G-vec00179-001-s592><create.schaffen><en> Create Conditional Formula is a wizard in Optipe Data Tools Suite that lets you create in the currently selected cell a formula to find, count or add data conditionally, for one or multiple criteria, similar to Merge Tables application.
<G-vec00179-001-s592><create.schaffen><de> Erstellen Bedingte Formel wird ein Assistent in Optipe Data Tools Suite, die, schafft in der aktuell ausgewählten Zelle, eine Formel bedingte: zu finden, zählen oder Summendaten; für ein oder mehrere Kriterien, ähnlich wie die Verknüpfen von Tabellen Anwendung.
<G-vec00179-001-s593><create.schaffen><en> Thus, for example, which does not jeopardize solid relationships and the corresponding families, which does not create confusion in others with false promises or otherwise, that do not abuse a preeminent position and, finally, the that it does not precede the selfishness of the own satisfaction to the well-being of our fellow human beings.
<G-vec00179-001-s593><create.schaffen><de> So zum Beispiel die nicht gefährdet feste Beziehungen und die entsprechenden Familien, die keine Verwirrung in anderen mit falschen Versprechungen schafft oder andernfalls, die eine herausragende Stellung nicht missbrauchen und schließlich die dass es nicht den Egoismus der eigenen Zufriedenheit, das Wohlbefinden unserer Mitmenschen vorausgehen.
<G-vec00179-001-s594><create.schaffen><en> It does not restore, or create safe havens.
<G-vec00179-001-s594><create.schaffen><de> Sie restauriert nicht, schafft keine Reservate.
<G-vec00179-001-s595><create.schaffen><en> Even though the manufacturing sector does not create new jobs, it generates innovation, wealth and high value added services.
<G-vec00179-001-s595><create.schaffen><de> Auch wenn der Produktionssektor keine neuen Arbeitsplätze schafft, erzeugt er Innovation, Wohlstand und einen hohen Wertzuwachs.
<G-vec00179-001-s596><create.schaffen><en> Linear create it to have the linear object representation and not the icon, Because the second wanted to write artistic hand seq time consuming.
<G-vec00179-001-s596><create.schaffen><de> Lineare es schafft die lineare Objektdarstellung haben und nicht das Symbol, Da der zweite wollte künstlerische Hand seq Zeit schreiben raubend.
<G-vec00179-001-s597><create.schaffen><en> Given the present water quality, this will create good conditions for aquacultures, in particular for pisciculture.
<G-vec00179-001-s597><create.schaffen><de> Dies schafft bei der vorhandenen Wasserqualität gute Voraussetzungen für Aquakulturen, besonders für die Fischzucht.
<G-vec00179-001-s598><create.schaffen><en> The well can be used and the fireplace is another feature typical of the traditional houses in the agricultural areas of the region Marche, that is able to create a cozy atmosphere and to heat not only the space but also the owners' and the hosts' souls.
<G-vec00179-001-s598><create.schaffen><de> Der Brunnen kann genutzt werden und der Kamin ist ein weiteres Merkmal der traditionellen Häuser in den landwirtschaftlichen Gebieten der Region Marken: der Kamin schafft eine gemütliche Atmosphäre, man heizt nicht nur den Raum, sondern auch die Seele des Besitzers und der Gastgeber.
<G-vec00179-001-s599><create.schaffen><en> Cascio uses simple material such as cardboard, wood and neon to create allegorical installations that reflect obsessions, hopes and dreams of social progress.
<G-vec00179-001-s599><create.schaffen><de> Cascio verwendet einfaches Material wie Karton, Holz und Neonlicht und schafft damit allegorische Installationen, die Obsessionen, Hoffnungen und Träume des gesellschaftlichen Fortschritts spiegeln.
<G-vec00179-001-s600><create.schaffen><en> In Austria, where the differentiation is belated, it is not out of the question that, in particular, an “independent” party might split off from the official party and immediately, as in Germany, create a possible mass base for the Communist Party.
<G-vec00179-001-s600><create.schaffen><de> Da eine solche Differenzierung sich bisher nicht vollzogen hat, ist es vor allem nicht ausgeschlossen, daß sich in Österreich eine „unabhängige“ Partei von der offiziellen Sozialdemokratie abspaltet, die der Kommunistischen Partei mit einem Schlage – wie es in Deutschland der Fall war – eine Massenbasis schafft.
<G-vec00179-001-s601><create.schaffen><en> The setting, spirit, sense of welcome and quality of services of the Olympic Museum create the conditions that make it so unique.
<G-vec00179-001-s601><create.schaffen><de> Mit seinem Umfeld, seiner Geisteshaltung, seiner Betreuung und den qualitativ hochstehenden Dienstleistungen schafft das Olympische Museum einzigartige Bedingungen, die sich von anderen Angeboten deutlich unterscheiden.
<G-vec00179-001-s602><create.schaffen><en> In doing so, and in keeping with the «Code of Conduct», APG|SGA seeks to achieve a reasonable return on its capital so as to safeguard its growth and independence, and thereby create added value for shareholders.
<G-vec00179-001-s602><create.schaffen><de> Dabei achtet APG|SGA unter Einhaltung des «Code of Conduct» auf eine angemessene Rendite ihres Eigenkapitals, um ihre Entwicklung und Unabhängigkeit zu sichern und schafft damit einen Mehrwert für die Aktionäre.
<G-vec00179-001-s603><create.schaffen><en> Crosscan’s highly accurate sensors create the necessary acceptance in the stores, which provides a fair benchmark of the store performance.
<G-vec00179-001-s603><create.schaffen><de> Die hochgenaue Zählung der Crosscan Sensoren schafft die notwendige Akzeptanz in den Filialen, welche für eine faire Bewertung der Filialleistung sorgt.
<G-vec00179-001-s604><create.schaffen><en> Sustainable corporate policies and practices ultimately create long-term value for our stakeholders and promote innovation,” said Severin Schwan, CEO of Roche.
<G-vec00179-001-s604><create.schaffen><de> Eine nachhaltige Unternehmenspolitik schafft letztendlich langfristigen Mehrwert für unsere Stakeholder und fördert Innovation,“ so Severin Schwan, CEO von Roche.
<G-vec00179-001-s605><create.schaffen><en> "The agreement will offer the advantage of reduced tariffs on goods traded between the tripartite countries and create new opportunities for intra-regional trade"" adds William Scalco."
<G-vec00179-001-s605><create.schaffen><de> "Das Abkommen garantiert reduzierte Zollgebühren auf Waren, die zwischen den Unterzeichner-Ländern gehandelt werden und schafft neue Chancen für den innerregionalen Handel"", fügt Salco hinzu."
<G-vec00179-001-s606><create.schaffen><en> The highly protective impermeable materials in the Mölnlycke BARRIER surgical drapes and surgical staff clothing create vital barriers between the patient and healthcare professionals.
<G-vec00179-001-s606><create.schaffen><de> Die undurchlässigen Materialien mit hohem Schutz der BARRIER® OP-Abdeckungen und OP-Bekleidung schafft wichtige Barrieren zwischen den Patienten und dem medizinischen Fachpersonal.
<G-vec00179-001-s607><create.schaffen><en> All in all, Kjellberg Finsterwalde has put together a package of extensive measures which will contribute to improving the working conditions of the employees as well as to the efficiency and transparency of processes and, thus, will create an important basis for future development.
<G-vec00179-001-s607><create.schaffen><de> Alles in allem hat Kjellberg Finsterwalde ein gewaltiges Paket an Maßnahmen geschnürt, das neben der Verbesserung der Arbeitsbedingungen für die Mitarbeiter wesentlich zu Effizienz und Transparenz der Prozesse beitragen wird und damit eine wichtige Grundlage für die künftige Entwicklung schafft.
<G-vec00001-001-s646><create.erstellen><en> Be the first one to see: create an alert on new properties in Riudecanyes and you'll receive new offers by email.
<G-vec00001-001-s646><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Riudecanyes erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s647><create.erstellen><en> The board is still publicly accessible, but posters who are not members of IFPUG will need to create a user account with an email/password.
<G-vec00001-001-s647><create.erstellen><de> Der Vorstand ist nach wie vor öffentlich zugänglich, aber Plakate, die nicht Mitglieder IFPUG sind, müssen Sie ein Benutzerkonto mit einem E-Mail / Passwort erstellen.
<G-vec00001-001-s648><create.erstellen><en> Be the first one to see: create an alert on new properties in Tarancón and you'll receive new offers by email.
<G-vec00001-001-s648><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Tarancón erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s649><create.erstellen><en> To create chapters, you add print layouts from a single project or multiple projects to open books.
<G-vec00001-001-s649><create.erstellen><de> Sie erstellen Kapitel, indem Sie Printlayouts aus einem Einzelprojekt oder mehreren Projekten zu einem geöffneten Buch hinzufügen.
<G-vec00001-001-s650><create.erstellen><en> Be the first one to see: create an alert on new properties in Llançà and you'll receive new offers by email.
<G-vec00001-001-s650><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Llançà erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s651><create.erstellen><en> Be the first one to see: create an alert on new properties in Sant Celoni and you'll receive new offers by email.
<G-vec00001-001-s651><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Sant Celoni erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s652><create.erstellen><en> Have students create their own creative scene, targeting images that will require various uses of ser and estar .
<G-vec00001-001-s652><create.erstellen><de> Lassen Sie die Schüler ihre eigene kreative Szene erstellen und auf Bilder zielen, die verschiedene Einsatzmöglichkeiten von Ser und Estar erfordern.
<G-vec00001-001-s653><create.erstellen><en> Be the first one to see: create an alert on new properties in Bellvitge and you'll receive new offers by email.
<G-vec00001-001-s653><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Bellvitge erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s654><create.erstellen><en> Related Products Bentley LumenRT Integrate life-like digital nature into your simulated infrastructure designs, and create high-impact visuals for stakeholders.
<G-vec00001-001-s654><create.erstellen><de> Verwandte Produkte Bentley LumenRT Integrieren Sie realitätsgetreue digitale Naturelemente in Ihre digitalen Infrastrukturentwürfe, um hochqualitative Visualisierungen für die Projektbeteiligten zu erstellen.
<G-vec00001-001-s655><create.erstellen><en> Be the first one to see: create an alert on new properties in Garrucha and you'll receive new offers by email.
<G-vec00001-001-s655><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Garrucha erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s656><create.erstellen><en> Be the first one to see: create an alert on new properties in Vinuesa and you'll receive new offers by email.
<G-vec00001-001-s656><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Vinuesa erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s657><create.erstellen><en> Be the first one to see: create an alert on new properties in Naval and you'll receive new offers by email.
<G-vec00001-001-s657><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Naval erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s658><create.erstellen><en> Takeaways Use Google data and insights to create smarter and more effective advertising campaigns.
<G-vec00001-001-s658><create.erstellen><de> Nutzen Sie für das Erstellen intelligenterer und effektiverer Werbekampagnen die Daten und Einblicke von Google.
<G-vec00001-001-s659><create.erstellen><en> Creating contentdescribes how to create content with images, blocks, links, and forms.
<G-vec00001-001-s659><create.erstellen><de> Inhalte erstellenbeschreibt, wie Sie Inhalte mit Bildern, Blöcken, Links und Formularen erstellen.
<G-vec00001-001-s660><create.erstellen><en> Be the first one to see: create an alert on new properties in Fondón and you'll receive new offers by email.
<G-vec00001-001-s660><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Fondón erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s661><create.erstellen><en> Be the first one to see: create an alert on new properties in Escatrón and you'll receive new offers by email.
<G-vec00001-001-s661><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Escatrón erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s662><create.erstellen><en> Be the first one to see: create an alert on new properties in Níjar and you'll receive new offers by email.
<G-vec00001-001-s662><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Níjar erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00001-001-s663><create.erstellen><en> Create your own country, city or even street maps to illustrate in detail those attractions and restaurants you visited on your trip through Australia or Africa.
<G-vec00001-001-s663><create.erstellen><de> Sie erstellen dabei eigene Land-, Stadt- oder sogar Straßenkarten, um auf Wunsch im Detail zu illustrieren, welche Sehenswürdigkeiten und Restaurants Sie auf Ihrer Reise durch Australien oder Afrika besucht haben.
<G-vec00001-001-s664><create.erstellen><en> This tutorial will tell you how to create a bubble chart with multiple series in Excel step by step.
<G-vec00001-001-s664><create.erstellen><de> In diesem Tutorial erfahren Sie Schritt für Schritt, wie Sie ein Blasendiagramm mit mehreren Reihen in Excel erstellen.
<G-vec00179-001-s646><create.erstellen><en> Be the first one to see: create an alert on new properties in Riudecanyes and you'll receive new offers by email.
<G-vec00179-001-s646><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Riudecanyes erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s647><create.erstellen><en> The board is still publicly accessible, but posters who are not members of IFPUG will need to create a user account with an email/password.
<G-vec00179-001-s647><create.erstellen><de> Der Vorstand ist nach wie vor öffentlich zugänglich, aber Plakate, die nicht Mitglieder IFPUG sind, müssen Sie ein Benutzerkonto mit einem E-Mail / Passwort erstellen.
<G-vec00179-001-s648><create.erstellen><en> Be the first one to see: create an alert on new properties in Tarancón and you'll receive new offers by email.
<G-vec00179-001-s648><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Tarancón erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s649><create.erstellen><en> To create chapters, you add print layouts from a single project or multiple projects to open books.
<G-vec00179-001-s649><create.erstellen><de> Sie erstellen Kapitel, indem Sie Printlayouts aus einem Einzelprojekt oder mehreren Projekten zu einem geöffneten Buch hinzufügen.
<G-vec00179-001-s650><create.erstellen><en> Be the first one to see: create an alert on new properties in Llançà and you'll receive new offers by email.
<G-vec00179-001-s650><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Llançà erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s651><create.erstellen><en> Be the first one to see: create an alert on new properties in Sant Celoni and you'll receive new offers by email.
<G-vec00179-001-s651><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Sant Celoni erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s652><create.erstellen><en> Have students create their own creative scene, targeting images that will require various uses of ser and estar .
<G-vec00179-001-s652><create.erstellen><de> Lassen Sie die Schüler ihre eigene kreative Szene erstellen und auf Bilder zielen, die verschiedene Einsatzmöglichkeiten von Ser und Estar erfordern.
<G-vec00179-001-s653><create.erstellen><en> Be the first one to see: create an alert on new properties in Bellvitge and you'll receive new offers by email.
<G-vec00179-001-s653><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Bellvitge erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s654><create.erstellen><en> Related Products Bentley LumenRT Integrate life-like digital nature into your simulated infrastructure designs, and create high-impact visuals for stakeholders.
<G-vec00179-001-s654><create.erstellen><de> Verwandte Produkte Bentley LumenRT Integrieren Sie realitätsgetreue digitale Naturelemente in Ihre digitalen Infrastrukturentwürfe, um hochqualitative Visualisierungen für die Projektbeteiligten zu erstellen.
<G-vec00179-001-s655><create.erstellen><en> Be the first one to see: create an alert on new properties in Garrucha and you'll receive new offers by email.
<G-vec00179-001-s655><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Garrucha erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s656><create.erstellen><en> Be the first one to see: create an alert on new properties in Vinuesa and you'll receive new offers by email.
<G-vec00179-001-s656><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Vinuesa erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s657><create.erstellen><en> Be the first one to see: create an alert on new properties in Naval and you'll receive new offers by email.
<G-vec00179-001-s657><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Naval erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s658><create.erstellen><en> Takeaways Use Google data and insights to create smarter and more effective advertising campaigns.
<G-vec00179-001-s658><create.erstellen><de> Nutzen Sie für das Erstellen intelligenterer und effektiverer Werbekampagnen die Daten und Einblicke von Google.
<G-vec00179-001-s659><create.erstellen><en> Creating contentdescribes how to create content with images, blocks, links, and forms.
<G-vec00179-001-s659><create.erstellen><de> Inhalte erstellenbeschreibt, wie Sie Inhalte mit Bildern, Blöcken, Links und Formularen erstellen.
<G-vec00179-001-s660><create.erstellen><en> Be the first one to see: create an alert on new properties in Fondón and you'll receive new offers by email.
<G-vec00179-001-s660><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Fondón erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s661><create.erstellen><en> Be the first one to see: create an alert on new properties in Escatrón and you'll receive new offers by email.
<G-vec00179-001-s661><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Escatrón erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s662><create.erstellen><en> Be the first one to see: create an alert on new properties in Níjar and you'll receive new offers by email.
<G-vec00179-001-s662><create.erstellen><de> Seien Sie die erste Person, die dieses Objekt sieht: eine Benachrichtigung für neue Wohnungen in Níjar erstellen und Sie erhalten über Ihre E-Mail die neuesten Angebote.
<G-vec00179-001-s663><create.erstellen><en> Create your own country, city or even street maps to illustrate in detail those attractions and restaurants you visited on your trip through Australia or Africa.
<G-vec00179-001-s663><create.erstellen><de> Sie erstellen dabei eigene Land-, Stadt- oder sogar Straßenkarten, um auf Wunsch im Detail zu illustrieren, welche Sehenswürdigkeiten und Restaurants Sie auf Ihrer Reise durch Australien oder Afrika besucht haben.
<G-vec00179-001-s664><create.erstellen><en> This tutorial will tell you how to create a bubble chart with multiple series in Excel step by step.
<G-vec00179-001-s664><create.erstellen><de> In diesem Tutorial erfahren Sie Schritt für Schritt, wie Sie ein Blasendiagramm mit mehreren Reihen in Excel erstellen.
<G-vec00001-001-s703><create.verursachen><en> You're publisher should supply you with these materials and if you're self-published you'll most likely need to create these materials from scratch and on your own.
<G-vec00001-001-s703><create.verursachen><de> Sie sind Verleger sollten Sie mit diesen Materialien liefern und wenn Sie Selbst-veröffentlicht werden, werden Sie die meiste wahrscheinliche Notwendigkeit, diese Materialien vom Kratzer und auf Ihren Selbst zu verursachen.
<G-vec00001-001-s704><create.verursachen><en> Ariana Crafts was founded as a custom handicraft company and is managed by a team of professionals who want to create a place for Indian handicrafts on the world map.
<G-vec00001-001-s704><create.verursachen><de> Ariana Fertigkeiten wurden als kundenspezifische Handwerksfirma gegründet und werden von einer Mannschaft der Fachleute gehandhabt, die einen Platz für indische Handwerkkünste auf dem Weltdiagramm verursachen möchten.
<G-vec00001-001-s705><create.verursachen><en> Gauge teachings by the harm they do or don't create when you put them into practice.
<G-vec00001-001-s705><create.verursachen><de> Beurteile Lehren anhand des Leidens, daß sie, wenn du sie in die Praxis umsetzt, verursachen oder auch nicht.
<G-vec00001-001-s706><create.verursachen><en> How do we create the things we do?Many people have said that creativity is the process by which we connect spiritually, connect with people, and connect with the world.
<G-vec00001-001-s706><create.verursachen><de> Wie verursachen wir die Sachen, die wir?Viele Leute haben gesagt, daß Kreativität der Prozeß ist, durch den wir Angelegenheiten anschließen, an Leute anschließen und an die Welt anschließen.
<G-vec00001-001-s707><create.verursachen><en> Mariah Burton NelsonOne of the prime reasons that most of us have occasional or everlasting problems with clutter is that we do not have a clear picture of the ideal setting we want to create for ourselves, our family and our work.
<G-vec00001-001-s707><create.verursachen><de> Mariah Burton NelsonEin der Hauptgründe, daß die meisten uns gelegentliches haben, oder ewig Probleme mit Unordnung ist, daß wir nicht eine freie Abbildung der idealen Einstellung haben, die wir für uns selbst verursachen möchten, unserer Familie und unserer Arbeit.
<G-vec00001-001-s708><create.verursachen><en> The important thing is to have enough time to consume all this knowledge or entertainment so as to create a culture of self-fulfilling activity.
<G-vec00001-001-s708><create.verursachen><de> Die wichtige Sache ist, genügend Zeit zu haben, ganzes Wissen und Unterhaltung zu verbrauchen dieses, um eine Kultur der Selbst-befriedigenden Tätigkeit, mit reichlicher Gelegenheit für Familienleben zu verursachen, der Freundschaften und der Miteinbeziehung in der größeren Gemeinschaft.
<G-vec00001-001-s709><create.verursachen><en> Second, we need to create the history.
<G-vec00001-001-s709><create.verursachen><de> Zweitens müssen wir die Geschichte verursachen.
<G-vec00001-001-s710><create.verursachen><en> It is not an easy task to create modern buildings and structures that would not spoil the general view and offend an eye of an impartial critic.
<G-vec00001-001-s710><create.verursachen><de> Es ist nicht eine einfache Aufgabe, moderne Gebäude und Strukturen zu verursachen, die nicht die allgemeine Ansicht verderben und ein Auge eines unparteiischen Kritikers beleidigen würden.
<G-vec00001-001-s711><create.verursachen><en> 2007-03-30 12:38:21 - Using candles in feng shui decorating The basic belief behind Feng Shui is that there are five elements, some combinations of which create a productive cycle, and some a destructive cycle.
<G-vec00001-001-s711><create.verursachen><de> 2007-03-30 12:38:21 - Verwenden der Kerzen beim feng shui Verzieren Der grundlegende Glaube hinter Feng Shui ist, daß es fünf Elemente gibt, von denen einige Kombinationen einen produktiven Zyklus verursachen, und einige ein zerstörender Zyklus.
<G-vec00001-001-s712><create.verursachen><en> 2007-11-13 22:16:19 - Be inspired to create better websites Being a writer, when I was asked to do some research into what makes a good website, of course I straightaway went to check out all of my favorite authors.
<G-vec00001-001-s712><create.verursachen><de> 2007-11-13 22:16:19 - Seien angespornt Sie, um bessere Web site zu verursachen Seiend ein Verfasser, als ich gebeten wurde, zu tun etwas Forschung in, was eine gute Web site bildet, selbstverständlich ging straightaway I, aus allen meine Lieblingsautoren zu überprüfen.
<G-vec00001-001-s713><create.verursachen><en> The typedef keyword is used to create a new name for an existing data type.
<G-vec00001-001-s713><create.verursachen><de> Das typedef Schlüsselwort wird verwendet, um einen neuen Namen für eine vorhandene Datenart zu verursachen.
<G-vec00001-001-s714><create.verursachen><en> Negative emotions that emit low vibrations include fear, guilt, remorse, self-doubt, jealousy, envy, bitterness and resentment, all of which create discomfort, discord and dissatisfaction.
<G-vec00001-001-s714><create.verursachen><de> Negative Gefühle, die geringe Schwingungen ausstrahlen schließen Furcht, Schuld, Reue, Selbstzweifel, Eifersucht, Neid, Bitterkeit und Groll ein, die Missbehagen, Zwietracht und Unzufriedenheit verursachen.
<G-vec00001-001-s715><create.verursachen><en> The earliest record of personal hair care dates back 2.5 million years ago, when brushes used to create cave paintings in Spain and France were adapted for use in hair grooming.
<G-vec00001-001-s715><create.verursachen><de> Vor die früheste Aufzeichnung der persönlichen Haarobacht geht 2.5 Million Jahren zurück, als die Bürsten, die benutzt wurden, um Höhleanstriche in Spanien und in Frankreich zu verursachen, für Gebrauch beim Haarpflegen angepaßt wurden.
<G-vec00001-001-s716><create.verursachen><en> create a fault in your application to make sure that the alert reaches you.
<G-vec00001-001-s716><create.verursachen><de> einen Fehler in Ihrer Anwendung zu verursachen, um zu überprüfen, ob der Alarm bei Ihnen eintrifft.
<G-vec00001-001-s717><create.verursachen><en> They can either destroy our dreams or help us create them.
<G-vec00001-001-s717><create.verursachen><de> Sie können entweder unsere Träume zerstören oder uns helfen, sie zu verursachen.
<G-vec00001-001-s718><create.verursachen><en> But in fiscal year 2019, military spending will create a deficit of almost 1,000 billion dollars in the federal budget.
<G-vec00001-001-s718><create.verursachen><de> Aber im Geschäftsjahr 2019 werden die Militärausgaben ein Defizit von fast 1.000 Milliarden Dollar im Bundeshaushalt verursachen.
<G-vec00001-001-s719><create.verursachen><en> """Metaphors create tension and excitement by producing new connections."
<G-vec00001-001-s719><create.verursachen><de> """Metaphern verursachen Spannung und Aufregung, indem sie neue Anschlüsse produzieren."
<G-vec00001-001-s720><create.verursachen><en> A lack of strength limits the ability of the body to create force for a given athletic movement.
<G-vec00001-001-s720><create.verursachen><de> Ein Mangel an Stärke begrenzt die Fähigkeit des Körpers, Kraft für eine gegebene athletische Bewegung zu verursachen.
<G-vec00001-001-s721><create.verursachen><en> 2007-11-13 22:16:19 - Country decorating ideas - create warmth and charm with country style decorating ideas Country decorating ideas can help you create a home that is warm, inviting and the perfect home to live in.
<G-vec00001-001-s721><create.verursachen><de> 2007-11-13 22:16:19 - Verzierende Ideen des Landes - verursachen Sie Wärme und bezaubern Sie mit verzierenden Ideen der Landart Verzierende Ideen des Landes können Ihnen helfen, ein Haus, das, warm ist, das Einladen und das vollkommene Haus zu verursachen, innen zu leben.
<G-vec00179-001-s703><create.verursachen><en> You're publisher should supply you with these materials and if you're self-published you'll most likely need to create these materials from scratch and on your own.
<G-vec00179-001-s703><create.verursachen><de> Sie sind Verleger sollten Sie mit diesen Materialien liefern und wenn Sie Selbst-veröffentlicht werden, werden Sie die meiste wahrscheinliche Notwendigkeit, diese Materialien vom Kratzer und auf Ihren Selbst zu verursachen.
<G-vec00179-001-s704><create.verursachen><en> Ariana Crafts was founded as a custom handicraft company and is managed by a team of professionals who want to create a place for Indian handicrafts on the world map.
<G-vec00179-001-s704><create.verursachen><de> Ariana Fertigkeiten wurden als kundenspezifische Handwerksfirma gegründet und werden von einer Mannschaft der Fachleute gehandhabt, die einen Platz für indische Handwerkkünste auf dem Weltdiagramm verursachen möchten.
<G-vec00179-001-s705><create.verursachen><en> Gauge teachings by the harm they do or don't create when you put them into practice.
<G-vec00179-001-s705><create.verursachen><de> Beurteile Lehren anhand des Leidens, daß sie, wenn du sie in die Praxis umsetzt, verursachen oder auch nicht.
<G-vec00179-001-s706><create.verursachen><en> How do we create the things we do?Many people have said that creativity is the process by which we connect spiritually, connect with people, and connect with the world.
<G-vec00179-001-s706><create.verursachen><de> Wie verursachen wir die Sachen, die wir?Viele Leute haben gesagt, daß Kreativität der Prozeß ist, durch den wir Angelegenheiten anschließen, an Leute anschließen und an die Welt anschließen.
<G-vec00179-001-s707><create.verursachen><en> Mariah Burton NelsonOne of the prime reasons that most of us have occasional or everlasting problems with clutter is that we do not have a clear picture of the ideal setting we want to create for ourselves, our family and our work.
<G-vec00179-001-s707><create.verursachen><de> Mariah Burton NelsonEin der Hauptgründe, daß die meisten uns gelegentliches haben, oder ewig Probleme mit Unordnung ist, daß wir nicht eine freie Abbildung der idealen Einstellung haben, die wir für uns selbst verursachen möchten, unserer Familie und unserer Arbeit.
<G-vec00179-001-s708><create.verursachen><en> The important thing is to have enough time to consume all this knowledge or entertainment so as to create a culture of self-fulfilling activity.
<G-vec00179-001-s708><create.verursachen><de> Die wichtige Sache ist, genügend Zeit zu haben, ganzes Wissen und Unterhaltung zu verbrauchen dieses, um eine Kultur der Selbst-befriedigenden Tätigkeit, mit reichlicher Gelegenheit für Familienleben zu verursachen, der Freundschaften und der Miteinbeziehung in der größeren Gemeinschaft.
<G-vec00179-001-s709><create.verursachen><en> Second, we need to create the history.
<G-vec00179-001-s709><create.verursachen><de> Zweitens müssen wir die Geschichte verursachen.
<G-vec00179-001-s710><create.verursachen><en> It is not an easy task to create modern buildings and structures that would not spoil the general view and offend an eye of an impartial critic.
<G-vec00179-001-s710><create.verursachen><de> Es ist nicht eine einfache Aufgabe, moderne Gebäude und Strukturen zu verursachen, die nicht die allgemeine Ansicht verderben und ein Auge eines unparteiischen Kritikers beleidigen würden.
<G-vec00179-001-s711><create.verursachen><en> 2007-03-30 12:38:21 - Using candles in feng shui decorating The basic belief behind Feng Shui is that there are five elements, some combinations of which create a productive cycle, and some a destructive cycle.
<G-vec00179-001-s711><create.verursachen><de> 2007-03-30 12:38:21 - Verwenden der Kerzen beim feng shui Verzieren Der grundlegende Glaube hinter Feng Shui ist, daß es fünf Elemente gibt, von denen einige Kombinationen einen produktiven Zyklus verursachen, und einige ein zerstörender Zyklus.
<G-vec00179-001-s712><create.verursachen><en> 2007-11-13 22:16:19 - Be inspired to create better websites Being a writer, when I was asked to do some research into what makes a good website, of course I straightaway went to check out all of my favorite authors.
<G-vec00179-001-s712><create.verursachen><de> 2007-11-13 22:16:19 - Seien angespornt Sie, um bessere Web site zu verursachen Seiend ein Verfasser, als ich gebeten wurde, zu tun etwas Forschung in, was eine gute Web site bildet, selbstverständlich ging straightaway I, aus allen meine Lieblingsautoren zu überprüfen.
<G-vec00179-001-s713><create.verursachen><en> The typedef keyword is used to create a new name for an existing data type.
<G-vec00179-001-s713><create.verursachen><de> Das typedef Schlüsselwort wird verwendet, um einen neuen Namen für eine vorhandene Datenart zu verursachen.
<G-vec00179-001-s714><create.verursachen><en> Negative emotions that emit low vibrations include fear, guilt, remorse, self-doubt, jealousy, envy, bitterness and resentment, all of which create discomfort, discord and dissatisfaction.
<G-vec00179-001-s714><create.verursachen><de> Negative Gefühle, die geringe Schwingungen ausstrahlen schließen Furcht, Schuld, Reue, Selbstzweifel, Eifersucht, Neid, Bitterkeit und Groll ein, die Missbehagen, Zwietracht und Unzufriedenheit verursachen.
<G-vec00179-001-s715><create.verursachen><en> The earliest record of personal hair care dates back 2.5 million years ago, when brushes used to create cave paintings in Spain and France were adapted for use in hair grooming.
<G-vec00179-001-s715><create.verursachen><de> Vor die früheste Aufzeichnung der persönlichen Haarobacht geht 2.5 Million Jahren zurück, als die Bürsten, die benutzt wurden, um Höhleanstriche in Spanien und in Frankreich zu verursachen, für Gebrauch beim Haarpflegen angepaßt wurden.
<G-vec00179-001-s716><create.verursachen><en> create a fault in your application to make sure that the alert reaches you.
<G-vec00179-001-s716><create.verursachen><de> einen Fehler in Ihrer Anwendung zu verursachen, um zu überprüfen, ob der Alarm bei Ihnen eintrifft.
<G-vec00179-001-s717><create.verursachen><en> They can either destroy our dreams or help us create them.
<G-vec00179-001-s717><create.verursachen><de> Sie können entweder unsere Träume zerstören oder uns helfen, sie zu verursachen.
<G-vec00179-001-s718><create.verursachen><en> But in fiscal year 2019, military spending will create a deficit of almost 1,000 billion dollars in the federal budget.
<G-vec00179-001-s718><create.verursachen><de> Aber im Geschäftsjahr 2019 werden die Militärausgaben ein Defizit von fast 1.000 Milliarden Dollar im Bundeshaushalt verursachen.
<G-vec00179-001-s719><create.verursachen><en> """Metaphors create tension and excitement by producing new connections."
<G-vec00179-001-s719><create.verursachen><de> """Metaphern verursachen Spannung und Aufregung, indem sie neue Anschlüsse produzieren."
<G-vec00179-001-s720><create.verursachen><en> A lack of strength limits the ability of the body to create force for a given athletic movement.
<G-vec00179-001-s720><create.verursachen><de> Ein Mangel an Stärke begrenzt die Fähigkeit des Körpers, Kraft für eine gegebene athletische Bewegung zu verursachen.
<G-vec00179-001-s721><create.verursachen><en> 2007-11-13 22:16:19 - Country decorating ideas - create warmth and charm with country style decorating ideas Country decorating ideas can help you create a home that is warm, inviting and the perfect home to live in.
<G-vec00179-001-s721><create.verursachen><de> 2007-11-13 22:16:19 - Verzierende Ideen des Landes - verursachen Sie Wärme und bezaubern Sie mit verzierenden Ideen der Landart Verzierende Ideen des Landes können Ihnen helfen, ein Haus, das, warm ist, das Einladen und das vollkommene Haus zu verursachen, innen zu leben.
