<EnglishT-wsj_0409-s35#EnglishT-wsj_0409-s35-t10><ev-w1227f1.v-w298f1> A surprising 78% of people said they <start_vs>exercise<end_vs> regularly, up from 73% in 1981. 
<EnglishT-wsj_0409-s54#EnglishT-wsj_0409-s54-t6><ev-w1227f1.v-w298f1> Most people said they <start_vs>exercise<end_vs> both for health and enjoyment. 
<EnglishT-wsj_0409-s58#EnglishT-wsj_0409-s58-t11><ev-w1227f1.v-w298f1> Only about a quarter of the respondents said they <start_vs>exercise<end_vs> to lose weight. 
<EnglishT-wsj_0409-s59#EnglishT-wsj_0409-s59-t24><ev-w1227f1.v-w298f1> Slightly more, like Leslie Sherren, a law librarian in San Francisco who attends dance aerobics five times a week, <start_vs>exercise<end_vs> to relieve stress. 
<EnglishT-wsj_0999-s6#EnglishT-wsj_0999-s6-t29><ev-w1227f1.v-w298f1> The Association of Quality Clubs, which puts 1988 industry revenue at $5 billion, surveyed the health-conscious over-40 market and found <start_vauxs>that<end_vauxs> 43% <start_vs>exercise<end_vs> regularly. 
