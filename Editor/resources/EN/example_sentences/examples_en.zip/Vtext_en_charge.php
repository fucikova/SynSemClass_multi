<G-vec00272-001-s057><charge.aufladen><en> The wireless companies want to charge heavy users more.
<G-vec00272-001-s057><charge.aufladen><de> Die Telekommunikationsfirmen möchten schwere Benutzer mehr aufladen.
<G-vec00272-001-s058><charge.aufladen><en> The batteries provide 550Â kWh usable capacity, a range of up to 250 miles and have the ability to charge up to 80Â percent (providing a range of 200 miles) in about 90 minutes.
<G-vec00272-001-s058><charge.aufladen><de> Die Batterien liefern mit 550 kWh genug Energie für eine Reichweite bis zu 400 km (250 Meilen) und lassen sich innerhalb von 90 Minuten auf rund 80 Prozent aufladen – um weitere 320 km (200 Meilen) zurückzulegen.
<G-vec00272-001-s059><charge.aufladen><en> Although many offer as good a rate as a credit card would, it’s worth remembering that the rate is taken at the date you charge the card up rather than the day you spend money on it.
<G-vec00272-001-s059><charge.aufladen><de> Obwohl viele so gute Rate als eine Kreditkarte bieten würde, es ist daran zu erinnern, dass der Kurs am Tag Sie die Karte aufladen genommen wird, anstatt den Tag, den Sie Geld dafür ausgeben.
<G-vec00272-001-s060><charge.aufladen><en> If lost after that we would have to charge to reload a new engine map.
<G-vec00272-001-s060><charge.aufladen><de> Wenn verlor danach müssten wir aufladen, um einen neuen Motor Karte neu zu laden.
<G-vec00272-001-s061><charge.aufladen><en> The long flight time is possible thanks to the use of carbon fibers, a new battery technology, and ultra-light solar cells, which charge the batteries through the day sufficiently to allow it to remain in operation overnight.
<G-vec00272-001-s061><charge.aufladen><de> Möglich wird die lange Flugdauer durch die Verwendung von Karbonfasern, eine neue Batterietechnik sowie ultraleichte Solarzellen, welche die Akkus tagsüber so weit aufladen, dass die Drohne über Nacht einsatzfähig bleibt.
<G-vec00272-001-s062><charge.aufladen><en> Sibenik will from next week is the function of a solar tree on which citizens will be able to charge mobile phones, laptops and other gadgets.
<G-vec00272-001-s062><charge.aufladen><de> Sibenik wird ab nächster Woche ist die Funktion einer Solarbaum auf dem die Bürger in der Lage sein Handy aufladen, Laptops und andere Geräte.
<G-vec00272-001-s063><charge.aufladen><en> Emits lightning and may charge and shelter units in order to increase its intensity.
<G-vec00272-001-s063><charge.aufladen><de> Schießt Blitze, kann sich aufladen und kann Einheiten aufnehmen und dadurch seine Intensität erhöhen.
<G-vec00272-001-s064><charge.aufladen><en> A 7500 mAh battery offers up to 20 km range, a maximum climb angle of up to 25 ° and a maximum speed of 20 km / h, and only 2.5 hours to fully charge.
<G-vec00272-001-s064><charge.aufladen><de> Ein 7500 mAh-Akku bietet eine Reichweite von bis zu 20 km, einen maximalen Steigwinkel von bis zu 25 ° und eine Höchstgeschwindigkeit von 20 km / h und nur 2,5 Stunden zum vollständigen Aufladen.
<G-vec00272-001-s065><charge.aufladen><en> Never set aside the possibility of paying thousands of dollars when buying from a dealer or a specific car company, where in the end, they charge you more for the interest which takes years to pay off.
<G-vec00272-001-s065><charge.aufladen><de> Die Möglichkeit des Zahlens von Tausenden Dollar nie beiseite setzen, wenn Kaufen von einem Händler oder von einer spezifischen Autofirma, in der im Ende, sie dich mehr für das Interesse aufladen, dem Jahre zu auszahlen dauert.
<G-vec00272-001-s066><charge.aufladen><en> Two front-facing USB 3.0 ports make it super convenient to charge your controllers and mobile devices.
<G-vec00272-001-s066><charge.aufladen><de> Über die zwei frontal ausgerichteten USB-3.0-Anschlüsse lassen sich Ihre Controller und Mobilgeräte ganz einfach aufladen.
<G-vec00272-001-s067><charge.aufladen><en> For best initial performance, charge battery before first use.
<G-vec00272-001-s067><charge.aufladen><de> Die Batterie vor dem ersten Gebrauch zunächst aufladen, um gleich die beste Leistung zu erzielen.
<G-vec00272-001-s068><charge.aufladen><en> Airwheel E3 smart electric bike has a high-efficiency USB connector that can charge the phone anytime and anywhere.
<G-vec00272-001-s068><charge.aufladen><de> Airwheel E3 smart e-Bike hat einen Hochleistungs-USB-Anschluss, der das Handy jederzeit und überall aufladen kann.
<G-vec00272-001-s069><charge.aufladen><en> START/STOP is optimized for use with 12 V EFB (Enhanced Flooded Battery) and AGM batteries, but it can charge ordinary 12 V lead-acid batteries as well.
<G-vec00272-001-s069><charge.aufladen><de> Das START/STOP wurde speziell für 12V-EFB- (Enhanced Flooded Battery) und AGM-Batterien optimiert, kann aber auch herkömmliche 12V-Bleibatterien aufladen.
<G-vec00272-001-s070><charge.aufladen><en> Now I’m without a phone, and AT&T is going to charge me $500 for termination of contract + new phone + new 2 year contract.
<G-vec00272-001-s070><charge.aufladen><de> Jetzt bin ich ohne Telefon, und AT&T wird mich aufladen $500 zur Kündigung des Vertrags + neues Handy + neue 2 Jahres-Vertrag.
<G-vec00272-001-s071><charge.aufladen><en> 1) 2.5*0.7(outside diameter*inside diameter, similarly hereinafter), for short DC2507, mostly used for small size electronic products, such as panel computer that is due to volume limitations, at present, famous brand panel computer almost adopt MicroUSB connectors to charge.
<G-vec00272-001-s071><charge.aufladen><de> 1) 2,5 * 0,7 (Außendurchmesser * Innendurchmesser, ähnlich im Folgenden), kurz DC2507, vor allem für kleine elektronische Produkte, wie Panel-Computer, der aufgrund der Volumenbeschränkungen, derzeit bekannten Marke Panel Computer fast MicroUSB-Anschlüsse verwenden aufladen.
<G-vec00272-001-s072><charge.aufladen><en> For example, if you charge your iPhone at night, in the first stage it will charge up to approximately 80% (enough that you can remove iPhone from charging), followed by the rest up to 100% its loading is very slow.
<G-vec00272-001-s072><charge.aufladen><de> Wenn Sie beispielsweise Ihr iPhone nachts aufladen, wird es in der ersten Phase ungefähr aufgeladen 80% (genug, dass Sie das iPhone vom Aufladen entfernen können), gefolgt vom Rest bis zu 100% Das Laden ist sehr langsam.
<G-vec00272-001-s073><charge.aufladen><en> With a fully charged PowerBar in your bags, you can ensure that you will always be able to charge your devices anywhere anytime without having to depend on a power socket.
<G-vec00272-001-s073><charge.aufladen><de> Mit einer voll aufgeladenen PowerBar in Ihrer Tasche können Sie sicher sein, dass Sie Ihre Geräte immer und überall aufladen können - ohne dass Sie dabei von einer Steckdose abhängig sind.
<G-vec00272-001-s074><charge.aufladen><en> During your sleep you can charge your electric bike for free.
<G-vec00272-001-s074><charge.aufladen><de> Wenn Sie schlafen können sie ihren Electrisches Fahrrad kostenloss aufladen.
<G-vec00272-001-s075><charge.aufladen><en> We offer charge and hydrostatic sale.
<G-vec00272-001-s075><charge.aufladen><de> Aufladen angebot und den verkauf von feuerlöschern aller art,.
<G-vec00272-001-s114><charge.auföaden><en> The Spark Portable Charging Station is designed to wirelessly charge up to three Spark Intelligent Flight Batteries on the go.
<G-vec00272-001-s114><charge.auföaden><de> Die mobile Ladestation für die Spark ist in der Lage bis zu drei Spark Intelligent Flight Batteries unterwegs aufzuladen.
<G-vec00272-001-s115><charge.auföaden><en> The base is called “Starkiller” because it literally drains the power from stars to charge its cannon.
<G-vec00272-001-s115><charge.auföaden><de> "Die Basis wird ""Starkiller"" genannt, weil sie buchstäblich den Sternen die Energie entzieht, um ihre Kanone aufzuladen."
<G-vec00272-001-s116><charge.auföaden><en> However, if you consider how natural it has become to charge smartphones overnight, for example, the charging cycle is practically no longer an argument to be made against e-mobility in the commercial vehicle sector.
<G-vec00272-001-s116><charge.auföaden><de> Wenn man allerdings bedenkt, wie selbstverständlich es inzwischen geworden ist, etwa Smartphones über Nacht aufzuladen, ist der Ladezyklus quasi kein Argument mehr gegen eMobility im Nutzfahrzeugbereich.
<G-vec00272-001-s117><charge.auföaden><en> The Power Bank Vidvie with a capacity of 8000 mAh is manufactured with high quality materials to quickly charge the battery of your smartphone, it is, in fact, equipped with a fast charging technology.
<G-vec00272-001-s117><charge.auföaden><de> Das Power Bank Vidvie mit einer Kapazität von 8000 mAh ist aus hochwertigen Materialien gefertigt, um den Akku Ihres Smartphones schnell aufzuladen, es ist sogar mit einer Schnellladetechnologie ausgestattet.
<G-vec00272-001-s118><charge.auföaden><en> Your own bike you covered stables and also charge the battery if necessary.
<G-vec00272-001-s118><charge.auföaden><de> Ihr eigenes Fahrrad Sie bedeckten Ställe und auch die Batterie aufzuladen, wenn nötig.
<G-vec00272-001-s119><charge.auföaden><en> Electric car owners are encouraged to stop by our resort and charge their car while dining.
<G-vec00272-001-s119><charge.auföaden><de> Besitzer von Elektroautos sind herzlich eingeladen, in unserem Resort essen zu gehen und in der Zwischenzeit ihr Fahrzeug aufzuladen.
<G-vec00272-001-s120><charge.auföaden><en> Featuring a USB-C cable and enough power to charge your phone quickly and easily, you can be certain that this car charger is compatible with your Motorola One.
<G-vec00272-001-s120><charge.auföaden><de> Mit einem USB-C-Kabel und genügend Strom, um Ihr Handy schnell und einfach aufzuladen, können Sie sicher sein, dass dieses Autoladegerät mit Ihrem Motorola One kompatibel ist.
<G-vec00272-001-s121><charge.auföaden><en> You can also connect a charging cable to the USB-C port to charge your MacBook.
<G-vec00272-001-s121><charge.auföaden><de> Sie können auch ein Ladekabel an den USB-C-Anschluss anschließen, um Ihr MacBook aufzuladen.
<G-vec00272-001-s122><charge.auföaden><en> This quality cable allows you to connect your Motorola Moto G6 to your laptop or desktop, in order to charge your phone and exchange / sync data simultaneously.
<G-vec00272-001-s122><charge.auföaden><de> Mit diesem Qualitätskabel können Sie Ihr Motorola One an Ihren Laptop oder Desktop anschließen, um Ihr Telefon aufzuladen und gleichzeitig Daten auszutauschen / zu synchronisieren.
<G-vec00272-001-s123><charge.auföaden><en> You may want to leave the battery slow charging overnight to fully charge it if it has been dead for some time.
<G-vec00272-001-s123><charge.auföaden><de> Du solltest die Batterie eventuell über Nacht langsam aufladen, um sie voll aufzuladen, falls sie einige Zeit leer war.
<G-vec00272-001-s124><charge.auföaden><en> You should also try to be on top of your competitor's prices, to undercut an existing photographer is one choice, but to neglect to value your skills and not charge enough to cover your overheads is another matter entirely.
<G-vec00272-001-s124><charge.auföaden><de> Sie sollten auch versuchen, auf Preise Ihres Konkurrenten zu sein, einen vorhandenen Photographen ist zu unterschneiden eine Wahl, aber zu vernachlässigen, Ihre Fähigkeiten zu bewerten und genug nicht aufzuladen, um Ihre overheads zu umfassen ist eine andere Angelegenheit völlig.
<G-vec00272-001-s125><charge.auföaden><en> He concentrated and used extremely rare techniques of energy modification to charge himself to full power.
<G-vec00272-001-s125><charge.auföaden><de> Er konzentrierte sich mit Hilfe seltener Techniken der Energiemodulation, um sich auf das höchste Niveau aufzuladen.
<G-vec00272-001-s126><charge.auföaden><en> So, if you choose a cordless screwdriver, then before you start working, you need to charge it.
<G-vec00272-001-s126><charge.auföaden><de> Also, wenn Sie einen Akkuschrauber wählen, dann, bevor Sie anfangen zu arbeiten, müssen Sie es aufzuladen.
<G-vec00272-001-s127><charge.auföaden><en> With his portable sculptures, Bruno Munari opened up the possibility to personalize a hotel room or any other anonymous place and thus charge it with culture.
<G-vec00272-001-s127><charge.auföaden><de> Bruno Munari dachte bei den tragbaren Kunstwerken an die Möglichkeit, ein Hotelzimmer oder einen anderen anonymen Ort zu individualisieren und mit Kultur aufzuladen.
<G-vec00272-001-s128><charge.auföaden><en> Printed solar panels could be incorporated into the tent fabric and save energy – for lamps (possibly also printed into the tent fabric), the cooker and to charge mobile phones.
<G-vec00272-001-s128><charge.auföaden><de> So könnten in den Zeltstoff eingearbeitete, gedruckte Solarpanels Energie spenden - für Lampen (möglicherweise auch in gedruckter Form in den Zeltstoff integriert), den Kocher, oder um das Handy aufzuladen.
<G-vec00272-001-s129><charge.auföaden><en> AC dynamo charger: Winding the dynamo crank can charge mobile phone, MP3, iPod and installed rechargeable battery.
<G-vec00272-001-s129><charge.auföaden><de> AC Dynamo -Ladegerät: Winding der Dynamo Kurbel können Handy, MP3, iPod und eingebauter wiederaufladbarer Akku aufzuladen.
<G-vec00272-001-s130><charge.auföaden><en> Though most bars will charge you for larger portions such as sandwiches, many tapas in the southern regions of the country come free when ordering a drink.
<G-vec00272-001-s130><charge.auföaden><de> Obwohl die meisten Bars werden Sie für größere Teile wie Sandwiches aufzuladen, vielen Tapas in den südlichen Regionen des Landes kommen kostenlos bei der Bestellung ein Getränk.
<G-vec00272-001-s131><charge.auföaden><en> Therefore it is better to charge with efforts firm where you have decided to get a cloth.
<G-vec00272-001-s131><charge.auföaden><de> Deshalb ist es besser, die Bemühungen auf die Firma aufzuladen, wo Sie sich entschieden haben, das Leinen zu erwerben.
<G-vec00272-001-s132><charge.auföaden><en> Inductive Charging Wireless charging is proving to be a popular and convenient way to charge mobile devices.
<G-vec00272-001-s132><charge.auföaden><de> Mehr Informationen Induktives Laden Induktives Laden bietet eine einfache und bequeme Methode um mobile Geräte aufzuladen.
<G-vec00272-001-s133><charge.belasten><en> You agree and reaffirm that Three Rings is authorized to charge your credit card each month, quarter, or year according to the terms of your subscription.
<G-vec00272-001-s133><charge.belasten><de> Du stimmst zu und bestätigst, dass Three Rings autorisiert ist, deine Kreditkarte gemäß deiner Abonnementbedingungen monatlich, im Quartal oder einmal jährlich zu belasten.
<G-vec00272-001-s134><charge.belasten><en> Please note Disney Vacation Homes reserves the right to charge guest credit cards in the event of damages to the property.
<G-vec00272-001-s134><charge.belasten><de> Bitte beachten Sie, dass die Disney Vacation Homes sich das Recht vorbehalten, Ihre Kreditkarten im Falle von Schäden an der Unterkunft zu belasten.
<G-vec00272-001-s135><charge.belasten><en> If the customer does not pay the deposit and/or the balance in accordance with the agreed due dates, although Velociped is willing and able to deliver the contractual services properly and has met their legal information obligations, and no legal or contractual customer right of retention exists, Velociped is entitled to withdraw from the package travel contract after a warning with a notice period, and to charge the customer cancellation fees as per point 6.
<G-vec00272-001-s135><charge.belasten><de> Leistet der Kunde die Anzahlung und/oder die Restzahlung nicht entsprechend den vereinbarten Zahlungsfälligkeiten, obwohl Velociped zur ordnungsgemäßen Erbringung der vertraglichen Leistungen bereit und in der Lage ist, seine gesetzlichen Informationspflichten erfüllt hat und kein gesetzliches oder vertragliches Zurückbehaltungsrecht des Kunden besteht, so ist Velociped berechtigt, nach Mahnung mit Fristsetzung vom Pauschalreisevertrag zurückzutreten und den Kunden mit Rücktrittskosten gemäß Ziffer 6 zu belasten.
<G-vec00272-001-s136><charge.belasten><en> If Apple is unable to successfully charge your credit card or payment account for fees due, Apple reserves the right to revoke or restrict access to your stored Content, delete your stored Content, or terminate your Account.
<G-vec00272-001-s136><charge.belasten><de> Wenn es Apple nicht möglich ist, deine Kreditkarte oder dein Zahlungskonto für die fälligen Gebühren erfolgreich zu belasten, behält sich Apple das Recht vor, deinen Zugang zu den gespeicherten Inhalten zu beenden oder zu beschränken, deine gespeicherten Inhalte zu löschen oder deinen Account zu kündigen.
<G-vec00272-001-s137><charge.belasten><en> We reserve the right to charge You a fee to cover Our reasonable costs for doing this.
<G-vec00272-001-s137><charge.belasten><de> Wir behalten uns das Recht vor, Ihnen eine Gebühr zu belasten, um unsere angemessenen Kosten in diesem Zusammenhang zu decken.
<G-vec00272-001-s138><charge.belasten><en> Additional details: The Hotel will charge your card in Swiss franc based on the exchange rate of the transaction date.
<G-vec00272-001-s138><charge.belasten><de> Weitere Details: Das Hotel wird Ihre Kreditkarte in Schweizer Franken belasten – zum am Tag der Buchung gültigen Wechselkurs.
<G-vec00272-001-s139><charge.belasten><en> "These lawsuits charge former Chinese president Jiang Zemin and the heads of the ""610 office"" [a Chinese Gestapo-like organisation set up by Jiang to implement the persecution of Falun Gong] with genocide and crimes against humanity."
<G-vec00272-001-s139><charge.belasten><de> Diese Klagen belasten den ehemaligen chinesischen Präsidenten Jiang Zemin und die Leiter des Büro 610 (einer chinesischen Gestapo- ähnlichen Organisation, von Jiang Zemin gebildet, um die Verfolgung von Falun Gong durchzuführen) mit Völkermord und Verbrechen gegen die Menschlichkeit.
<G-vec00272-001-s140><charge.belasten><en> 7 Payment We will charge your credit card or debit your bank account or send you a weekly invoice
<G-vec00272-001-s140><charge.belasten><de> 7 Zahlung Wir belasten Ihre Kreditkarte oder Ihr Bankkonto oder senden Ihnen wöchentlich eine Rechnung.
<G-vec00272-001-s141><charge.belasten><en> In the event of default by the consumer, the entrepreneur has the right, subject to legal restrictions, to charge the reasonable costs made known to the consumer beforehand.
<G-vec00272-001-s141><charge.belasten><de> Im Fall des Verzuges durch die Verbraucher, der Unternehmer unterliegt gesetzliche Einschränkungen, das Recht, die angemessen Kosten für die Verbraucher zu belasten.
<G-vec00272-001-s142><charge.belasten><en> Payment Virtual Terminal is used when you wish to charge your guest's credit card manually.
<G-vec00272-001-s142><charge.belasten><de> Payment Virtual Terminal verwendet wird, wenn Sie möchten, manuell Ihres Gastes Kreditkarte zu belasten.
<G-vec00272-001-s143><charge.belasten><en> The hotel will charge your credit card.
<G-vec00272-001-s143><charge.belasten><de> Das Hotel wird dann Ihre Kreditkarte belasten.
<G-vec00272-001-s144><charge.belasten><en> Once you have requested a Badoo premium service, you authorise Badoo to charge your chosen payment method.
<G-vec00272-001-s144><charge.belasten><de> Mit dem Kauf einer Premiumfunktion gibst du Badoo die Erlaubnis, deine ausgewählte Zahlungsmethode zu belasten.
<G-vec00272-001-s145><charge.belasten><en> If Members choose to furnish credit card information to Enterprise, Members: (a) represent that they are the individual whose name appears on the card or that they are the authorised user of the card; (b) direct Enterprise to store all such information in accordance with the applicable Enterprise Rent-A-Car Privacy Policy; and (c) authorise and instruct Enterprise to charge any rental car charges incurred by the Member to that credit card.
<G-vec00272-001-s145><charge.belasten><de> Wenn sich Mitglieder zur Übermittlung der Kreditkartendaten an Enterprise entschließen, dann (a) sichern sie zu, dass sie die Person sind, deren Name auf der Kreditkarte angegeben ist, oder dass sie der berechtigte Nutzer der Karte sind, (b) weisen sie Enterprise an, diese Daten gemäß der geltenden Datenschutzrichtlinie von Enterprise Rent-A-Car zu speichern, und (c) ermächtigen und weisen sie Enterprise an, diese Kreditkarte mit allen anfallenden Mietwagengebühren zu belasten.
<G-vec00272-001-s146><charge.belasten><en> If the credit card holder is not staying in the hotel, written permission of the owner of the card is required in order to charge the card.
<G-vec00272-001-s146><charge.belasten><de> Wenn sich der Inhaber der Kreditkarte nicht im Hotel aufhält, wird eine schriftliche Genehmigung des Karteninhabers benötigt, um die Karte zu belasten.
<G-vec00272-001-s147><charge.belasten><en> Condor Ocean View Apartments Surfers Paradise will charge the total amount of your reservation to your credit card as a security deposit 7 days prior to your arrival date.
<G-vec00272-001-s147><charge.belasten><de> Die Condor Ocean View Apartments Surfers Paradise werden Ihre Kreditkarte mit dem Gesamtbuchungsbetrag 7 Tage vor Ihrer Ankunft als Kaution belasten.
<G-vec00272-001-s148><charge.belasten><en> The hotel reserves the right to charge the total amount to the credit card provided in case the amount exceeds EUR 800
<G-vec00272-001-s148><charge.belasten><de> Das Hotel behält sich das Recht vor, die Kreditkarte mit dem kompletten Betrag zu belasten, falls die Gesamtbuchungssumme den Betrag von EUR 800 übersteigt.
<G-vec00272-001-s149><charge.belasten><en> He may also purchase goods and services whilst overseas and his credit card company has to convert those sales back into his base currency in order to charge him.
<G-vec00272-001-s149><charge.belasten><de> Er kann im Ausland auch Waren und Dienste kaufen, und seine Kreditkartengesellschaft muss diese Käufe in seine Basiswährung konvertieren, um seine Karte damit zu belasten.
<G-vec00272-001-s150><charge.belasten><en> If you fail to return the replaced product, part or accessory as instructed or return a replaced product, part or accessory that is ineligible for service, Apple will charge the credit card for the authorized amount.
<G-vec00272-001-s150><charge.belasten><de> Falls Sie das ausgetauschte Produkt, Teil oder Zubehör nicht gemäß den Anweisungen zurückgeben oder wenn Sie ein ausgetauschtes Produkt, Teil oder Zubehör zurückgeben, für das die Serviceleistung nicht beansprucht werden kann, wird Apple die Kreditkarte mit dem autorisierten Betrag belasten.
<G-vec00272-001-s151><charge.belasten><en> "At first, the police tried to charge him with ""subverting the government."""
<G-vec00272-001-s151><charge.belasten><de> Zuerst versuchte die Polizei, ihn zu belasten, indem sie behaupteten, dass er „die Regierung untergraben“ hätte.
<G-vec00347-001-s063><charge.belasten><en> You agree and reaffirm that Three Rings is authorized to charge your credit card each month, quarter, or year according to the terms of your subscription.
<G-vec00347-001-s063><charge.belasten><de> Du stimmst zu und bestätigst, dass Three Rings autorisiert ist, deine Kreditkarte gemäß deiner Abonnementbedingungen monatlich, im Quartal oder einmal jährlich zu belasten.
<G-vec00347-001-s064><charge.belasten><en> Please note Disney Vacation Homes reserves the right to charge guest credit cards in the event of damages to the property.
<G-vec00347-001-s064><charge.belasten><de> Bitte beachten Sie, dass die Disney Vacation Homes sich das Recht vorbehalten, Ihre Kreditkarten im Falle von Schäden an der Unterkunft zu belasten.
<G-vec00347-001-s065><charge.belasten><en> If the customer does not pay the deposit and/or the balance in accordance with the agreed due dates, although Velociped is willing and able to deliver the contractual services properly and has met their legal information obligations, and no legal or contractual customer right of retention exists, Velociped is entitled to withdraw from the package travel contract after a warning with a notice period, and to charge the customer cancellation fees as per point 6.
<G-vec00347-001-s065><charge.belasten><de> Leistet der Kunde die Anzahlung und/oder die Restzahlung nicht entsprechend den vereinbarten Zahlungsfälligkeiten, obwohl Velociped zur ordnungsgemäßen Erbringung der vertraglichen Leistungen bereit und in der Lage ist, seine gesetzlichen Informationspflichten erfüllt hat und kein gesetzliches oder vertragliches Zurückbehaltungsrecht des Kunden besteht, so ist Velociped berechtigt, nach Mahnung mit Fristsetzung vom Pauschalreisevertrag zurückzutreten und den Kunden mit Rücktrittskosten gemäß Ziffer 6 zu belasten.
<G-vec00347-001-s066><charge.belasten><en> If Apple is unable to successfully charge your credit card or payment account for fees due, Apple reserves the right to revoke or restrict access to your stored Content, delete your stored Content, or terminate your Account.
<G-vec00347-001-s066><charge.belasten><de> Wenn es Apple nicht möglich ist, deine Kreditkarte oder dein Zahlungskonto für die fälligen Gebühren erfolgreich zu belasten, behält sich Apple das Recht vor, deinen Zugang zu den gespeicherten Inhalten zu beenden oder zu beschränken, deine gespeicherten Inhalte zu löschen oder deinen Account zu kündigen.
<G-vec00347-001-s067><charge.belasten><en> We reserve the right to charge You a fee to cover Our reasonable costs for doing this.
<G-vec00347-001-s067><charge.belasten><de> Wir behalten uns das Recht vor, Ihnen eine Gebühr zu belasten, um unsere angemessenen Kosten in diesem Zusammenhang zu decken.
<G-vec00347-001-s068><charge.belasten><en> Additional details: The Hotel will charge your card in Swiss franc based on the exchange rate of the transaction date.
<G-vec00347-001-s068><charge.belasten><de> Weitere Details: Das Hotel wird Ihre Kreditkarte in Schweizer Franken belasten – zum am Tag der Buchung gültigen Wechselkurs.
<G-vec00347-001-s069><charge.belasten><en> "These lawsuits charge former Chinese president Jiang Zemin and the heads of the ""610 office"" [a Chinese Gestapo-like organisation set up by Jiang to implement the persecution of Falun Gong] with genocide and crimes against humanity."
<G-vec00347-001-s069><charge.belasten><de> Diese Klagen belasten den ehemaligen chinesischen Präsidenten Jiang Zemin und die Leiter des Büro 610 (einer chinesischen Gestapo- ähnlichen Organisation, von Jiang Zemin gebildet, um die Verfolgung von Falun Gong durchzuführen) mit Völkermord und Verbrechen gegen die Menschlichkeit.
<G-vec00347-001-s070><charge.belasten><en> 7 Payment We will charge your credit card or debit your bank account or send you a weekly invoice
<G-vec00347-001-s070><charge.belasten><de> 7 Zahlung Wir belasten Ihre Kreditkarte oder Ihr Bankkonto oder senden Ihnen wöchentlich eine Rechnung.
<G-vec00347-001-s071><charge.belasten><en> In the event of default by the consumer, the entrepreneur has the right, subject to legal restrictions, to charge the reasonable costs made known to the consumer beforehand.
<G-vec00347-001-s071><charge.belasten><de> Im Fall des Verzuges durch die Verbraucher, der Unternehmer unterliegt gesetzliche Einschränkungen, das Recht, die angemessen Kosten für die Verbraucher zu belasten.
<G-vec00272-001-s152><charge.berechnen><en> For cancellations received within 7 days of your scheduled arrival date, we will charge one-half of the total room charges for your reservation.
<G-vec00272-001-s152><charge.berechnen><de> Bei Stornierungen innerhalb von 7 Tagen nach Anreise berechnen wir die Hälfte der Gesamtfläche des Zimmers Gebühren für Ihre Reservierung.
<G-vec00272-001-s153><charge.berechnen><en> Dogs are welcome in our hotel. We will charge CHF 15.00 per day & pet.
<G-vec00272-001-s153><charge.berechnen><de> Hunde sind bei uns willkommen, wir berechnen Ihnen CHF 15.00 pro Tag für Ihren Vierbeiner.
<G-vec00272-001-s154><charge.berechnen><en> We only charge based on the amount of emails you send.
<G-vec00272-001-s154><charge.berechnen><de> Wir berechnen nur nach der Anzahl der gesendeten E-Mails.
<G-vec00272-001-s155><charge.berechnen><en> From figuring out which rate to charge which customer to dealing with complicated sales tax filing forms, it's understandable that you want to shove “sales tax” to number 39 on your massive to-do list.
<G-vec00272-001-s155><charge.berechnen><de> "Von herauszufinden, die rate zu berechnen, die der Kunde für den Umgang mit komplizierten Umsatz-Steuer-ausfüllen von Formularen, es ist verständlich, dass Sie möchten, um zu schieben ""sales tax"" an die Nummer 39 auf Ihre riesige to-do-Liste."
<G-vec00272-001-s156><charge.berechnen><en> If your hold luggage weighs more than your allowance when you arrive at the airport we charge you a fee for each 1kg of excess weight.
<G-vec00272-001-s156><charge.berechnen><de> Wenn Sie am Flughafen ankommen und Ihr Gepäck mehr als Ihre Freigepäckgrenze wiegt, berechnen wir Ihnen eine Gebühr für jedes Kilogramm Übergewicht.
<G-vec00272-001-s157><charge.berechnen><en> (2) If we suffer a loss due to the belated purchase, we are entitled to charge a lump sum of 10% of the value of the not rendered service as compensation, unless the customer can prove the damage is worth less.
<G-vec00272-001-s157><charge.berechnen><de> (2) Entsteht uns durch die verspätete Abnahme ein Schaden, so sind wir berechtigt, pauschal 10 % des für die nicht abgenommene Leistung vereinbarten Entgelts als Schadensersatz zu berechnen, sofern uns der Kunde keinen niedrigeren Schaden nachweist.
<G-vec00272-001-s158><charge.berechnen><en> Dispatch costs (inclusive of legally applicable VAT) Domestic deliveries (Germany): We charge a flat shipping fee of 4,95 € per order.
<G-vec00272-001-s158><charge.berechnen><de> Versandkosten (inklusive gesetzliche Mehrwertsteuer) Lieferungen im Inland (Deutschland): Wir berechnen die Versandkosten pauschal mit 4,95 € pro Bestellung.
<G-vec00272-001-s159><charge.berechnen><en> In this case we will transfer money to your account charging you 10% of the order’s amount and the minimum charge is € 5, -.
<G-vec00272-001-s159><charge.berechnen><de> Um Ihr Geld wieder Ihrem Konto gutzuschreiben, berechnen wir 10% Kosten mit einem Mindestbetrag von € 5,-.
<G-vec00272-001-s160><charge.berechnen><en> Failure to notify us will result in a day-use charge of EUR 20.– .
<G-vec00272-001-s160><charge.berechnen><de> Bei keiner Rückmeldung sehen wir uns leider gezwungen Ihnen ein day-use von EUR 20,– zu berechnen.
<G-vec00272-001-s161><charge.berechnen><en> 3.2 The following shall apply to orders which are to be delivered more than four months after conclusion of the contract: should our purchase prices and/or our applicable wages and salaries increase until the time the contract is executed, we shall be entitled to charge a higher price on a pro rata basis as a percentage of the purchase price and/or the labour costs.
<G-vec00272-001-s161><charge.berechnen><de> 3.2 Erhöhen sich bei Aufträgen, die später als vier Monate nach Abschluss ausgeliefert werden sollen, unsere Einkaufspreise und/oder der für uns gültige Lohn- und Gehaltstarif bis zur Ausführung des Auftrags, dürfen wir einen im Rahmen des prozentualen Anteils des Einkaufspreises und/oder der Lohnkosten am vereinbarten Preis verhältnismäßig entsprechend erhöhten Preis berechnen.
<G-vec00272-001-s162><charge.berechnen><en> While app design companies would charge you expensive developer and designer fees, none of that is required with Phorest Salon Software’s proposition.
<G-vec00272-001-s162><charge.berechnen><de> Und während App-Design-Firmen dir teure Entwickler- und Designergebühren berechnen würden, ist nichts davon mit dem Angebot von Phorest Salon Software erforderlich.
<G-vec00272-001-s163><charge.berechnen><en> If you cancel later than the accommodation establishes as a deadline or does not notify of the cancellation of the reservation, the accommodation may charge you an amount which in most cases is equivalent to the amount of the first night.
<G-vec00272-001-s163><charge.berechnen><de> Wenn Sie später stornieren, als die Unterkunft als Termin festlegt oder nicht über die Stornierung der Reservierung informiert, kann die Unterkunft Ihnen einen Betrag berechnen, der in den meisten Fällen der Höhe der ersten Nacht entspricht.
<G-vec00272-001-s164><charge.berechnen><en> Our arrangement for a cancellation is as follows: If you cancel more than ten days in advance, we will not charge you anything.
<G-vec00272-001-s164><charge.berechnen><de> Unser Arrangement für eine Stornierung ist wie folgt: Wenn Sie mehr als zehn Tage im Voraus kündigen, wird nicht berechnen wir Ihnen nichts.
<G-vec00272-001-s165><charge.berechnen><en> The prices we charge 1 EUR City tax per person per night.
<G-vec00272-001-s165><charge.berechnen><de> Die Preise berechnen wir 1 € Kurtaxe pro Person pro Nacht.
<G-vec00272-001-s166><charge.berechnen><en> We charge a one time handling fee of € 14.90 per booking.
<G-vec00272-001-s166><charge.berechnen><de> Wir berechnen eine einmalige Bearbeitungs- und Versandpauschale von 14,90 € pro Buchung.
<G-vec00272-001-s167><charge.berechnen><en> If release order dates are not adhered to by the customer then we are entitled to delivery and to charge in full four weeks after the written announcement with reference to the consequences of the release order which was not carried out.
<G-vec00272-001-s167><charge.berechnen><de> Werden vom Kunden Abruftermine nicht eingehalten, so sind wir berechtigt, vier Wochen nach schriftlicher Ankündigung unter Hinweis auf die Folgen des unterbliebenen Abrufes, die Gesamtmenge vollständig zu liefern und zu berechnen.
<G-vec00272-001-s168><charge.berechnen><en> In the event of delayed payment TUNZE Aquarientechnik GmbH is entitled to charge interest on arrears amounting to 1% above our rate of discount.
<G-vec00272-001-s168><charge.berechnen><de> Bei Zahlungsverzug ist Firma TUNZE Aquarientechnik GmbH, berechtigt, Verzugszinsen in Höhe von 1 % über dem jeweiligen Eigendiskontsatz zu berechnen.
<G-vec00272-001-s169><charge.berechnen><en> A note, such as “plus the usual ancillary charges” entitles the freight forwarder, Special charges and to charge for supplements.
<G-vec00272-001-s169><charge.berechnen><de> Ein Vermerk, wie etwa „zuzüglich der üblichen Nebenspesen“ berechtigt den Spediteur, Sondergebühren und Sonderauslagen zusätzlich zu berechnen.
<G-vec00272-001-s170><charge.berechnen><en> We charge a shipping fee of EUR 2.95 for all deliveries within Germany, regardless of the number of items ordered or the amount of the order value.
<G-vec00272-001-s170><charge.berechnen><de> Wir berechnen eine Versandkostenpauschale in Höhe von 2,95 Euro für alle Lieferungen innerhalb von Deutschland und unabhängig von der Anzahl der bestellten Artikel oder der Höhe des Bestellwertes.
<G-vec00272-001-s171><charge.berechnen><en> If you cancel less than 48 hours in advance, or in the case of a no show, we.ll charge you the full amount.
<G-vec00272-001-s171><charge.berechnen><de> Wenn Sie weniger als 48 Stunden im voraus, oder im Falle eines no-Show abbrechen, we.ll berechnet Ihnen den vollen Betrag.
<G-vec00272-001-s172><charge.berechnen><en> For all reservations of 7 nights or more, the hotel will charge a non-refundable deposit equivalent to 3 nights.
<G-vec00272-001-s172><charge.berechnen><de> Bei allen Buchungen von 7 Nächten oder mehr berechnet das Hotel eine nicht erstattbare Anzahlung in der Höhe von 3 Übernachtungen.
<G-vec00272-001-s173><charge.berechnen><en> Please note that in case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s173><charge.berechnen><de> Bitte beachten Sie, dass das Hotel im Falle einer vorzeitigen Abreise den gesamten Betrag des gebuchten Aufenthalts berechnet.
<G-vec00272-001-s174><charge.berechnen><en> Please note that extra charge will apply if guests upgrade the breakfast.
<G-vec00272-001-s174><charge.berechnen><de> Bitte beachten Sie, dass für die Buchung des Frühstücks ein Aufpreis berechnet wird.
<G-vec00272-001-s175><charge.berechnen><en> Please note there is an extra charge for using the sauna.
<G-vec00272-001-s175><charge.berechnen><de> Bitte beachten Sie, dass für die Nutzung der Sauna ein Aufpreis berechnet wird.
<G-vec00272-001-s176><charge.berechnen><en> In case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s176><charge.berechnen><de> Reisen Sie vor dem gebuchten Zeitpunkt ab, berechnet das Hotel den Betrag für den gesamten Aufenthalt.
<G-vec00272-001-s177><charge.berechnen><en> Room service and use of the conference hall are free of any surplus charge.
<G-vec00272-001-s177><charge.berechnen><de> Für den Zimmerservice und die Nutzung des Konferenzraums wird kein Aufschlag berechnet.
<G-vec00272-001-s178><charge.berechnen><en> The hotel provides WiFi internet; spacious and bright rooms; a restaurant and a bar; a pretty terrace with fabulous views of the lake and gardens; a large, well-lit hall, outdoor parking (additional charge); 3 meeting rooms with natural light, air conditioning and a maximum capacity for up to 140 people.
<G-vec00272-001-s178><charge.berechnen><de> WLAN-Internetzugang; geräumige, helle Zimmer; ein Restaurant und eine Bar; eine wunderschöne Sommerterrasse mit Blick auf den See und den Garten; eine große, helle Lobby, Parkplatz (wird extra berechnet); 3 Konferenzräume mit Tageslichteinfall, Klimaanlage und Platz für bis zu 140 Teilnehmer.
<G-vec00272-001-s179><charge.berechnen><en> Cancellations must be made no later than 2 weeks prior to arrival or a cancellation charge applies.
<G-vec00272-001-s179><charge.berechnen><de> Stornierungen müssen bis spätestens 2 Wochen vor der Ankunft erfolgen, andernfalls werden Stornierungsgebühren berechnet.
<G-vec00272-001-s180><charge.berechnen><en> [1] Withdrawing cash through the DKB-card is in practice free of charge in more than 99 per cent of cases, because the DKB does not charge its customers any fees and takes the fees of foreign ATMs automatically.
<G-vec00272-001-s180><charge.berechnen><de> [1] Das Abheben von Bargeld über die DKB-Karten ist in der Praxis zu über 99 Prozent kostenlos, weil die DKB ihren Kunden keine Gebühren berechnet und die Gebühren der Fremdautomaten automatisch übernimmt.
<G-vec00272-001-s181><charge.berechnen><en> No additional night charge is made for journeys abroad.
<G-vec00272-001-s181><charge.berechnen><de> Bei Auslandsfahrten wird kein Nachtzuschlag berechnet.
<G-vec00272-001-s182><charge.berechnen><en> Please note that the property will charge a 25% deposit at the moment of booking.
<G-vec00272-001-s182><charge.berechnen><de> Bitte beachten Sie, dass die Unterkunft bei der Buchung eine Anzahlung von 25 % des Gesamtpreises berechnet.
<G-vec00272-001-s183><charge.berechnen><en> If you use a credit or debit card to fully or partially fund international personal payments, PayPal will charge a cross border fee, which can range from 2.9% to 7.4% plus an additional fixed fee.
<G-vec00272-001-s183><charge.berechnen><de> Wenn Sie eine Kredit- oder Debitkarte für die vollständige oder teilweise Finanzierung von internationalen persönlichen Zahlungen verwenden, berechnet PayPal eine Auslandsgebühr, die zwischen 2,9 % und 7,4 % zuzüglich einer festen Gebühr betragen kann.
<G-vec00272-001-s184><charge.berechnen><en> • Credit card companies usually charge an additional fee for purchases in foreign currencies (foreign currency fee).
<G-vec00272-001-s184><charge.berechnen><de> • Das Kreditkarteninstitut berechnet in der Regel bei Käufen in fremder Währung eine zusätzliche Gebühr (Fremdwährungszuschlag).
<G-vec00272-001-s185><charge.berechnen><en> with kitchenette, coffee maker, toaster, electric kettle, terrace, bed linen is available, towels and tea towels are not themselves or rent (extra charge) .
<G-vec00272-001-s185><charge.berechnen><de> mit Küchenzeile, Kaffeemaschine, Toaster, Wasserkocher,Terrasse, Bettwäsche ist vorhanden, Handtücher und Geschirrtücher sind selber mitzubringen oder zu mieten (wird extra berechnet).
<G-vec00272-001-s186><charge.berechnen><en> Please note that NÃ1⁄4rnbergMesse GmbH will charge a fee of EUR 800 in the event of a contravention of this.
<G-vec00272-001-s186><charge.berechnen><de> Bitte beachten Sie, dass die NürnbergMesse GmbH im Falle von Zuwiderhandlung eine Gebühr von EUR 800 berechnet.
<G-vec00272-001-s187><charge.berechnen><en> Please note that there is an extra charge and these requests are based on availability.
<G-vec00272-001-s187><charge.berechnen><de> Bitte beachten Sie, dass ein Aufpreis berechnet wird und diese Anfragen der Verfügbarkeit unterliegen.
<G-vec00272-001-s188><charge.berechnen><en> There will be an extra charge per dog per night.
<G-vec00272-001-s188><charge.berechnen><de> Pro Hund und Nacht wird ein Aufpreis berechnet.
<G-vec00272-001-s189><charge.berechnen><en> 2.7 For the processing of mere supply contracts without set-up with an invoice amount of 50,00€, ABASS GmbH shall charge a processing fee of 5,00€ plus value-added tax.
<G-vec00272-001-s189><charge.berechnen><de> 2.7 Für die Abwicklung bloßer Lieferaufträge ohne Montage mit einem Rechnungswert bis zu 50,00 € netto berechnet ABASS GMBH eine Bearbeitungspauschale von 5,00 € zuzüglich Mehrwertsteuer.
<G-vec00272-001-s209><charge.erheben><en> 8.2.8 We will not typically charge you a fee to deposit or withdraw funds. However, if we suspect that you are misusing the deposit and/or withdrawal functionality, we reserve the right to charge you a fee to reflect any costs incurred by us in connection with such misuse.
<G-vec00272-001-s209><charge.erheben><de> Wenn wir allerdings vermuten, dass Sie die Funktionalität der Ein- und/oder Auszahlung missbrauchen, behalten wir uns das Recht vor, eine Gebühr zu erheben, um jegliche Kosten, die im Zusammenhang mit solchem Missbrauch entstanden sind, zu begleichen.
<G-vec00272-001-s210><charge.erheben><en> Some banks charge additional fees for international transfers to Germany.
<G-vec00272-001-s210><charge.erheben><de> Bei internationalen Überweisungen nach Deutschland erheben einige Banken zusätzliche Gebühren.
<G-vec00272-001-s211><charge.erheben><en> We charge a standard commission rate of 50 USD per 1 million USD traded, with the benefit of increasing discounts for larger cumulative trading volume, i.e. the more volume traded, the cheaper trading costs (commission) become.
<G-vec00272-001-s211><charge.erheben><de> Wir erheben eine Standardkommission von 50 USD pro gehandelter Million USD bei steigenden Preisnachlässen für umfangreichere Gesamthandelsvolumen, d.h. je größer das Handelsvolumen ausfällt, umso günstiger werden die Handelskosten (Kommissionen).
<G-vec00272-001-s212><charge.erheben><en> Those pipelines were very important for all the American oil majors, which had invested a great deal of money into Kazakhstan, Turkmenistan, and they were in a situation where they were developing the oil and gas and controlled them, but the only ways they had to get it out there were through Russia, and Russia was in a position to charge quite exorbitant rates on the pipelines.
<G-vec00272-001-s212><charge.erheben><de> Diese Pipelines waren sehr wichtig für alle großen amerikanischen Ölkonzerne, die sehr viel Geld in Kasachstan und Turkmenistan investiert hatten, und sie waren in einer Situation, wo sie das Öl- und Gas entwickelten und es kontrollierten, aber die einzigen Wege, um es von dort rauszubekommen, gingen durch Russland, und Russland war in der Lage, recht hohe Gebühren auf die Pipelines zu erheben.
<G-vec00272-001-s213><charge.erheben><en> If someone violates our rules or regulations, we charge a supervision fee of 1000 SEK.
<G-vec00272-001-s213><charge.erheben><de> Verstößt jemand gegen unsere Regeln oder Vorschriften, erheben wir eine Überwachungsgebühr von 1000 SEK.
<G-vec00272-001-s214><charge.erheben><en> Eventbrite reserves the right to charge fees for future use of or access to the Eventbrite APIs in Eventbrite's discretion.
<G-vec00272-001-s214><charge.erheben><de> Eventbrite behält sich das Recht vor, nach eigenem Ermessen Gebühren für die Nutzung oder den künftigen Zugriff auf die Eventbrite-APIs zu erheben.
<G-vec00272-001-s215><charge.erheben><en> *In case of no show or cancellation within 24Hrs of arrival, will incur a cancellation charge for 50% the entire length of stay.
<G-vec00272-001-s215><charge.erheben><de> * Im Falle von No Show oder Stornierung innerhalb von 24 Stunden der Anreise erfolgen, erheben wir eine Stornogebühr von 50% der gesamten Dauer des Aufenthalts.
<G-vec00272-001-s216><charge.erheben><en> 44% of hotels charge a premium for including an LRA clause.
<G-vec00272-001-s216><charge.erheben><de> 44 Prozent der Hotels erheben einen Zuschlag für die Einbindung einer Klausel zur Last Room Availability.
<G-vec00272-001-s217><charge.erheben><en> We charge a small fee for the courses, usually in the amount of 15 Euro per course day (exceptions are possible).
<G-vec00272-001-s217><charge.erheben><de> Wir erheben eine geringe Gebühr für die Kurse, die in der Regel bei 15 € pro Kurstag liegt (Ausnahmen sind möglich).
<G-vec00272-001-s218><charge.erheben><en> We charge our hearts with the best will spingiamoci and at the foot of Christ to ask him the tenderness of his understanding, the strength of His Omnipotence and the triumph of His grace.
<G-vec00272-001-s218><charge.erheben><de> Wir erheben unsere Herzen mit dem besten Willen spingiamoci und am Fuße des Christus zu bitten, ihm die Zärtlichkeit seines Verstehens, die Stärke seiner Allmacht und den Triumph seiner Gnade.
<G-vec00272-001-s219><charge.erheben><en> 2 A Contracting Party shall not impose on nationals of any other Party any residence charge not required of its own nationals.
<G-vec00272-001-s219><charge.erheben><de> 2 Ein Vertragstaat wird von den Staatsangehörigen eines anderen Vertragstaates keine Aufenthaltsgebühren erheben, die nicht auch von den eigenen Staatsangehörigen gefordert werden.
<G-vec00272-001-s220><charge.erheben><en> Until the Delhi Supreme Court decides on the validity of the patent, Monsanto may charge royalties on Bt cotton in India.
<G-vec00272-001-s220><charge.erheben><de> Bis der oberste Gerichtshofs von Delhi über die Gültigkeit des Patents entscheidet, kann Monsanto in Indien Lizenzgebühren für Bt-Baumwolle erheben.
<G-vec00272-001-s221><charge.erheben><en> We charge a flat weekly rate, don’t limit the number of users or amount of data and you can reach a real human in case you’re going to need help.
<G-vec00272-001-s221><charge.erheben><de> Wir erheben einen flachen Wochenpreis, nicht die Anzahl der Benutzer oder Datenmenge begrenzen, und Sie können ein echter Mensch in Fall erreichen Sie Hilfe brauchen.
<G-vec00272-001-s222><charge.erheben><en> Online shops may no longer charge a little extra if you pay by credit card.
<G-vec00272-001-s222><charge.erheben><de> Beispielsweise kann ein Online-Shop keinen kleinen Aufpreis erheben, wenn Sie mit der Kreditkarte bezahlen möchten.
<G-vec00272-001-s223><charge.erheben><en> Plarium may also provide links to other websites or third party services, some of which may charge separate fees, which are not included in any fees that you may pay to Plarium.
<G-vec00272-001-s223><charge.erheben><de> Des Weiteren kann Plarium Links zu anderen Webseiten oder Drittparteidienstleistungen anbieten, von denen einige separate Gebühren erheben, welche nicht in den von Ihnen an Plarium gezahlten Gebühren inbegriffen sind.
<G-vec00272-001-s224><charge.erheben><en> For payments by cash on delivery, we charge an additional processing fee of EUR 5.00 in Germany, together with the transfer fee of Deutsche Post AG, which you must pay the postman.
<G-vec00272-001-s224><charge.erheben><de> Für Zahlungen per Nachnahme erheben wir im Inland eine zusätzliche Bearbeitungsgebühr von EUR 5.00, nebst Übermittlungsentgeld der Deutschen Post AG, die Sie beim Postboten bezahlen müssen.
<G-vec00272-001-s225><charge.erheben><en> Even in hotel reservations, we always charge a performance-based commission only, which additionally is comparable, if not even below, the market standard.
<G-vec00272-001-s225><charge.erheben><de> Auch in der Hotelvermittlung erheben wir immer nur eine leistungsbezogene Kommission, die darüber hinaus vergleichbar mit dem, wenn nicht gar unter dem Marktstandard liegt.
<G-vec00272-001-s226><charge.erheben><en> Also similarly, some casinos may charge a withdrawal fee.
<G-vec00272-001-s226><charge.erheben><de> Einige Casinos erheben auch eine Auszahlungsgebühr.
<G-vec00272-001-s227><charge.erheben><en> In the case of placing claims that are unfounded or excessive, we reserve the right to charge a reasonable fee or refuse to act upon the request, which we will notify you in advance.
<G-vec00272-001-s227><charge.erheben><de> Im Falle von offensichtlich unbegründeten oder übertriebenen Anträgen, behalten wir das Recht ein berechtigtes Entgelt zu erheben oder abzulehnen nach dem Antrag zu handeln, worüber wir Sie in voraus benachrichtigen werden.
<G-vec00272-001-s456><charge.stellen><en> Should you decide not to make a reservation after receiving the offers, we reserve the right to charge an administrative fee of CHF 50.00.
<G-vec00272-001-s456><charge.stellen><de> Bei einer Absage nach der Zustellung von Offerten erlauben wir uns, Ihnen eine Bearbeitungsgebühr von CHF 50.00 in Rechnung zu stellen.
<G-vec00272-001-s457><charge.stellen><en> If a device provided for the purpose of bridging a repair period is returned in an improper condition, KARL STORZ reserves the right to charge up to 30% of the new value for the restoration of the device.
<G-vec00272-001-s457><charge.stellen><de> Sollte ein Reparaturüberbrückungsgerät in einem nicht ordnungsgemäßen Zustand retourniert werden, behält sich KARL STORZ vor, bis zu 30% des Neuwarenwertes für die Instandsetzung des Gerätes in Rechnung zu stellen.
<G-vec00272-001-s458><charge.stellen><en> If you, as the trainer, have to cancel or curtail the seminar because you unexpectedly indisposed, the service provider can charge you the costs of booked seminar rooms and seminar equipment, of accommodation and board, in accordance with its conditions of business.
<G-vec00272-001-s458><charge.stellen><de> Wenn Sie als Trainer das Seminar absagen oder abbrechen müssen, weil Sie unerwartet ausfallen, kann Ihnen der Leistungsträger Stornokosten für gebuchte Seminarräume und Seminarausstattung, für Übernachtungen und Verpflegung entsprechend seiner Geschäftsbedingungen in Rechnung stellen.
<G-vec00272-001-s459><charge.stellen><en> In the event of late clearing of the room, ACHAT may charge 50% of the regular room rate (list price) until 6 pm for the additional use of the room, from 6 pm onwards 100% of the full valid regular room rate (list price).
<G-vec00272-001-s459><charge.stellen><de> Bei verspäteter Räumung kann das Hotel über den ihm dadurch entstehenden Schaden hinaus für die zusätzliche Nutzung des Zimmers bis 18.00 Uhr 50 % des regulären Übernachtungspreises (Listenpreises) in Rechnung stellen, ab 18.00 Uhr 100% des vollen gültigen regulären Übernachtungspreis (Listenpreis).
<G-vec00272-001-s460><charge.stellen><en> If you damage the rented equipment in such a way that we can no longer rent it out, we will have to charge you the current value.
<G-vec00272-001-s460><charge.stellen><de> Sollten Sie die gemietete Ausrüstung so beschädigen, dass wir diese nicht mehr weiter vermieten können, müssen wir Ihnen den Zeitwert in Rechnung stellen.
<G-vec00272-001-s461><charge.stellen><en> You accept that TomTom may charge you for any shipping or postage costs incurred directly associated with returning the Product.
<G-vec00272-001-s461><charge.stellen><de> Sie akzeptieren, dass TomTom Ihnen Versand- oder Portokosten, die direkt mit der Rücksendung des Produkts in Verbindung stehen, in Rechnung stellen kann.
<G-vec00272-001-s462><charge.stellen><en> If the customer returns one or more of these multiple goods, the Supplier will be entitled to withdraw the discount and nevertheless charge the amount corresponding to this to the customer.
<G-vec00272-001-s462><charge.stellen><de> Sendet der Kunde von diesen mehreren Artikeln einen oder mehrere zurück, dann ist der Lieferant berechtigt, die Ermäßigung zurückzuziehen und den sich daraus ergebenden Betrag dem Kunden nachträglich in Rechnung zu stellen.
<G-vec00272-001-s463><charge.stellen><en> TIP: The fees we charge you (regardless of whether you choose to absorb or pass the fees to your attendees) are considered to be a separate transaction from the price you charge your attendees.
<G-vec00272-001-s463><charge.stellen><de> TIPP: Unabhängig davon, ob Sie die Gebühren in den Ticketpreis einrechnen oder an die Teilnehmer übertragen, gelten die anfallenden Gebühren als eigenständige Transaktion, die von dem Preis, den Sie Teilnehmern in Rechnung stellen, unabhängig ist.
<G-vec00272-001-s464><charge.stellen><en> If the delivery mistake is due to the Buyer, this cannot not imply any financial disadvantage for P.P.S, and P.P.S reserves itself the right to charge the client the costs of his/her mistake.
<G-vec00272-001-s464><charge.stellen><de> Handelt es sich um einen Fehler des Käufers, dürfen P.P.S daraus keine finanziellen Nachteile entstehen, und P.P.S behält sich das Recht vor, den Kunden die durch den Fehler des Käufers entstandenen Kosten in Rechnung zu stellen.
<G-vec00272-001-s465><charge.stellen><en> CrazyBulk also supplies complimentary worldwide shipping that lots of other supplement business generally charge.
<G-vec00272-001-s465><charge.stellen><de> CrazyBulk liefert auch kostenlosen weltweiten Versand, die viele anderen Ergänzung Geschäft im Allgemeinen Rechnung zu stellen .
<G-vec00272-001-s466><charge.stellen><en> However, as reported, the firm wrote on its website that it has “no plans to change” its business model and will not charge fees for any of its services.
<G-vec00272-001-s466><charge.stellen><de> jedoch, wie berichtet, Die Firma schrieb auf seiner Website, dass es hat “keine Pläne zu ändern” ihr Geschäftsmodell und wird nicht Gebühren für eine ihrer Dienstleistungen in Rechnung stellen.
<G-vec00272-001-s467><charge.stellen><en> If a grace period notification for a rectification of defects is not reasonable for the purchaser due to time reasons, the purchaser has the right to have the defects repaired and to charge the required expenses after having informed the supplier.
<G-vec00272-001-s467><charge.stellen><de> Sollte eine Nachfristsetzung für eine Nachbesserung aus terminlichen Gründen für den Besteller nicht zumutbar sein, behält sich dieser nach vorheriger Information des Lieferanten das Recht vor, selbst nachbessern zu lassen und die hierfür erforderlichen Aufwendungen in Rechnung zu stellen.
<G-vec00272-001-s468><charge.stellen><en> They can only charge fees for their legal services which are 10 per cent less than those which lawyers who have law offices in Berlin or the old Länder can charge their clients.
<G-vec00272-001-s468><charge.stellen><de> Sie können für ihre Berufstätigkeit als Rechtsanwalt nur Gebühren verlangen, die um zehn Prozent niedriger sind als diejenigen, die Rechtsanwälte mit Kanzleisitz in Berlin und den alten Bundesländern ihren Mandanten in Rechnung stellen dürfen.
<G-vec00272-001-s469><charge.stellen><en> You expressly grant Shutterstock the right to charge you for each automatic renewal until you timely disable automatic renewal.
<G-vec00272-001-s469><charge.stellen><de> Sie gewähren Shutterstock ausdrücklich das Recht, Ihnen jede automatische Verlängerung in Rechnung zu stellen, bis Sie die automatische Verlängerung rechtzeitig deaktivieren.
<G-vec00272-001-s470><charge.stellen><en> There is no fee charged for requesting access to your personal information, however we may charge you for the reasonable cost of processing your request.
<G-vec00272-001-s470><charge.stellen><de> Für den Zugang zu Ihren persönlichen Daten werden keine Gebühren erhoben, es kann jedoch sein, dass wir Ihnen in angemessenem Umfang die Bearbeitung Ihrer Anfrage in Rechnung stellen.
<G-vec00272-001-s471><charge.stellen><en> He must not charge a fee directly related to the outcome of the services he provides.
<G-vec00272-001-s471><charge.stellen><de> Es soll keine Honorare in Rechnung stellen, die unmittelbar vom Ergebnis der von ihm besorgten Dienste abhängen.
<G-vec00272-001-s472><charge.stellen><en> In the case of late arrivals or early departures, we do charge for the room.
<G-vec00272-001-s472><charge.stellen><de> Bei verspäteter Anreise oder verfrühter Abreise erlauben wir uns das Zimmer in Rechnung zu stellen.
<G-vec00272-001-s473><charge.stellen><en> With such device you can charge your digital products any time and any where.
<G-vec00272-001-s473><charge.stellen><de> Mit einem solchen Gerät können Sie Ihre digitalen Produkte jederzeit und überall, wo in Rechnung stellen.
<G-vec00272-001-s474><charge.stellen><en> If the alternative accommodation unit price is higher than the accommodation unit reserved by the client, the Agency is entitled to charge the client for the price difference.
<G-vec00272-001-s474><charge.stellen><de> Falls der Preis der alternativen Unterkunft höher ist als der der stornierten Unterkunft, behält sich die Agentur das Recht vor, diese Differenz in Rechnung zu stellen.
<G-vec00272-001-s589><charge.verlangen><en> Other competitors charge very high fees for similar reports.
<G-vec00272-001-s589><charge.verlangen><de> Andere Anbieter verlangen für vergleichbare Reports hohe Gebühren.
<G-vec00272-001-s590><charge.verlangen><en> a) In case of an increase attributable to a single seat Velociped can charge the amount of increase.
<G-vec00272-001-s590><charge.verlangen><de> a) Bei einer auf den Sitzplatz bezogenen Erhöhung kann Velociped vom Kunden den Erhöhungsbetrag verlangen.
<G-vec00272-001-s591><charge.verlangen><en> These organizations will charge higher fees, because they offer preparation services and added support.
<G-vec00272-001-s591><charge.verlangen><de> Diese Organisationen werden höheren Gebühren verlangen, weil sie Zubereitungsleistungen und zusätzliche Unterstützung bieten.
<G-vec00272-001-s592><charge.verlangen><en> You just have to bring the best, not to charge more than what you deliver, but to know the price of your service in order to keep the quality.
<G-vec00272-001-s592><charge.verlangen><de> Sie müssen nur das Beste zu liefern, nicht mehr verlangen als das, was Sie zu liefern, aber der Preis für Ihren Service zu kennen, um die Qualität zu halten.
<G-vec00272-001-s593><charge.verlangen><en> Business partners and visitors of our webpages have at any time the right to inquire about the origins, kind of storage and the extent of use of his or her personal data free of charge.
<G-vec00272-001-s593><charge.verlangen><de> Kunden, Kooperationspartner und Seitenbesucher haben jederzeit das Recht, kostenlos Auskunft über die Herkunft ihrer personenbezogenen Daten zu verlangen sowie über Art und Umfang der Speicherung und Nutzung dieser Daten.
<G-vec00272-001-s594><charge.verlangen><en> An expert can charge more when the time is right.
<G-vec00272-001-s594><charge.verlangen><de> Ein Experte kann mehr verlangen wenn die Zeit reif ist.
<G-vec00272-001-s595><charge.verlangen><en> Some may charge placement fees of 2,000-6,000 CZK for finding a regular sitter; other agencies charge no fee.
<G-vec00272-001-s595><charge.verlangen><de> Einige können Vermittlungsgebühren von 2,000-6,000 CZK für die Suche nach einem regelmäßigen Babysitter kostenlos; andere Agenturen verlangen keine Gebühr.
<G-vec00272-001-s596><charge.verlangen><en> If you request the direct transfer of the data to another person in charge, this will only take place if it is technically feasible.
<G-vec00272-001-s596><charge.verlangen><de> Sofern Sie die direkte Übertragung der Daten an einen anderen Verantwortlichen verlangen, erfolgt dies nur, soweit es technisch machbar ist.
<G-vec00272-001-s597><charge.verlangen><en> Avoid suppliers that charge an ongoing monthly fee to do business with them.
<G-vec00272-001-s597><charge.verlangen><de> Vermeiden Sie Anbieter, die verlangen eine laufende monatliche Gebühr mit Ihnen Geschäfte machen.
<G-vec00272-001-s598><charge.verlangen><en> On the other hand, private companies will normally charge more but offer door to door transfers for fixed prices.
<G-vec00272-001-s598><charge.verlangen><de> Auf der anderen Seite werden private Unternehmen in der Regel mehr verlangen, bieten aber Haus-zu-Haus-Transfers zu Festpreisen an.
<G-vec00272-001-s599><charge.verlangen><en> Gohlke, his co-authors, and his publisher are of course free to charge whatever they wish for their book.
<G-vec00272-001-s599><charge.verlangen><de> Gohlke, seine Mitautoren und sein Verleger können natürlich für ihr Buch verlangen, was sie wollen.
<G-vec00272-001-s600><charge.verlangen><en> We will therefore charge premium margin to ensure that sufficient account value is available to close the short position and additional margin to cover overnight shifts in the underlying value.
<G-vec00272-001-s600><charge.verlangen><de> Wir werden daher eine Premium Margin verlangen, um sicherzustellen, dass genügend Mittel zur Glattstellung der Short-Position vorhanden sind, und eine zusätzliche Margin, sich gegen Preisverschiebungen des Basiswerts über Nacht abzusichern.
<G-vec00272-001-s601><charge.verlangen><en> The accommodation provider shall be entitled to charge as a minimum the remuneration corresponding to the price usually charged in the low season.
<G-vec00272-001-s601><charge.verlangen><de> Der Beherberger ist berechtigt, mindestens jenes Entgelt zu verlangen, das dem gewöhnlich verrechneten Preis in der Nebensaison entspricht.
<G-vec00272-001-s602><charge.verlangen><en> Except for one special situation, the GNU General Public License (GNU GPL) has no requirements about how much you can charge for distributing a copy of free software.
<G-vec00272-001-s602><charge.verlangen><de> Mit Ausnahme einer bestimmten Situation beinhaltet die GNU General Public License (GPL) keinerlei Bedingungen darüber, wie viel man für den Vertrieb von Freie-Software-Kopien verlangen kann.
<G-vec00272-001-s603><charge.verlangen><en> (3) Where permissible under the relevant national law, a company may charge a fee for supplying the relevant information.
<G-vec00272-001-s603><charge.verlangen><de> (3) Die Unternehmen können für die Auskunftserteilung eine Gebühr verlangen, wenn und soweit dies nach Maßgabe des jeweiligen Landesrechts zulässig ist.
<G-vec00272-001-s604><charge.verlangen><en> Brennan could easily charge for something like this and people would still buy it.
<G-vec00272-001-s604><charge.verlangen><de> Brennan könnte glatt Geld dafür verlangen und die Leute würden den Kurs trotzdem kaufen.
<G-vec00272-001-s605><charge.verlangen><en> In the event of default in payment, the Company is entitled to charge interest on arrears in the amount of 10 percentage points above the base interest rate (§ 247 German Civil Code (BGB)).
<G-vec00272-001-s605><charge.verlangen><de> Im Falle des Zahlungsverzuges ist die Firma berechtigt, Verzugszinsen in Höhe von 10 Prozentpunkten über dem Basiszinssatz (§ 247 BGB) zu verlangen.
<G-vec00272-001-s606><charge.verlangen><en> They can only charge fees for their legal services which are 10 per cent less than those which lawyers who have law offices in Berlin or the old Länder can charge their clients.
<G-vec00272-001-s606><charge.verlangen><de> Sie können für ihre Berufstätigkeit als Rechtsanwalt nur Gebühren verlangen, die um zehn Prozent niedriger sind als diejenigen, die Rechtsanwälte mit Kanzleisitz in Berlin und den alten Bundesländern ihren Mandanten in Rechnung stellen dürfen.
<G-vec00272-001-s607><charge.verlangen><en> If you don’t charge admission, the licence fees are lower.
<G-vec00272-001-s607><charge.verlangen><de> Wenn Sie keinen Eintritt verlangen, kostet Sie die Urheberrechtsentschädigung weniger.
