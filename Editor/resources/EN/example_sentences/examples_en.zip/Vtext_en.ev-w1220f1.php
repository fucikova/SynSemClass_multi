<EnglishT-wsj_0297-s46#EnglishT-wsj_0297-s46-t11><ev-w1220f1.v-w5371f1> ``Where does that first stimulus go ?'' <start_vs>exclaims<end_vs> SUNY neurologist Paul Maccabee. 
