<G-vec00441-001-s002><clobber.einprügeln><en> Attacks on Jews provide a pretext for Israel’s rulers to clobber Arab people.
<G-vec00441-001-s002><clobber.einprügeln><de> Angriffe auf Juden liefern Israels Herrschern einen Vorwand, auf arabische Menschen einzuprügeln.
<G-vec00441-001-s003><clobber.einprügeln><en> Attacks on Jews provide a pretext for Israel's rulers to clobber Arab people.
<G-vec00441-001-s003><clobber.einprügeln><de> Angriffe auf Juden liefern Israels Herrschern einen Vorwand, auf arabische Menschen einzuprügeln.
