<T-wsj0192-001-p1s12#T-wsj0192-001-p1s12a18><ev-w1296f4.v-w10034f1> Armádní sbor snižuje průtok na řece Missouri už asi dva týdny kvůli nízkému stavu vody v přehradách, které ji <start_vs>živí<end_vs>. 
<T-wsj1110-001-p1s16#T-wsj1110-001-p1s16a9><ev-w1484f8.v-w10034f1> "Znamená to, že ujídáme z chleba, který nás <start_vs>živí<end_vs>. 
<T-wsj1572-001-p1s50#T-wsj1572-001-p1s50a19><ev-w1296f2.v-w10034f1> Ale stěží jsou jediní: podvodníci slibují - kromě jiného -, <start_vauxs>že<end_vauxs> pomáhají chránit životní prostředí, <start_vs>živí<end_vs> hladovějící rodiny a zabraňují mizení dětí. 
