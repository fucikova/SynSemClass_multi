<T-wsj1146-001-p1s135#T-wsj1146-001-p1s135a1><ev-w1880f5.v-w10032f1> Všichni kolem mě <start_vauxs>si<end_vauxs> <start_vs>žijí<end_vs> dobře. 
