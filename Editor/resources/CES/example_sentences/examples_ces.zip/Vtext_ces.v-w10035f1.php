<T-wsj1574-001-p1s7#T-wsj1574-001-p1s7a10><ev-w1125f1.v-w10035f1> Je mi 33, jsem vdaná, bezdětná a <start_vs>živím<end_vs> <start_vauxs>se<end_vauxs> psaním příběhů, jako je tenhle. 
