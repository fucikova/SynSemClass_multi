<T-wsj0089-001-p1s64#T-wsj0089-001-p1s64a10><ev-w281f1.v-w10024f1> Zato jsem viděla jednoho nebo dva muže zemřít, bůh jim <start_vs>žehnej<end_vs>. 
<T-wsj2086-001-p1s24#T-wsj2086-001-p1s24a6><ev-w281f2.v-w10024f1> Akcionáři společnosti Jaguár <start_vauxs>by<end_vauxs> <start_vauxs>museli<end_vauxs> <start_vs>žehnat<end_vs> takové dalekosáhlé dohodě. 
