<T-wsj2168-001-p1s16#T-wsj2168-001-p1s16a1><ev-w1945f2.v-w10022f1> "Mohl jste nakoupit za nabídku a prodat za návrh a vydělat jmění," <start_vs>žasnul<end_vs>. 
<T-wsj2202-001-p1s15#T-wsj2202-001-p1s15a1><ev-w1945f2.v-w10022f1> "Každý hráč, kterého tam postavili, měl lepší rychlý rotující míč, než ten předchozí," <start_vs>žasl<end_vs> manažer týmu Giants Roger Craig. 
