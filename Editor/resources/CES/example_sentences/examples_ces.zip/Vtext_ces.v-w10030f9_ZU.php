<T-wsj1596-001-p1s25#T-wsj1596-001-p1s25a22><ev-w218f2.v-w10030f9_ZU> "Konečný součet je takový, že firma <start_vs>žije<end_vs> víc z ruky do úst <start_vauxs>než<end_vauxs> dříve," řekl. 
