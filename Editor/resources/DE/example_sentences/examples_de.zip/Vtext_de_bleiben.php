<G-vec00081-001-s665><stop.bleiben><de> Es blieben vor dem Balkon auch zufällige Bürgergruppen stehen, deren Neugier periodisch durch einen Zeitungslärm geweckt wurde.
<G-vec00081-001-s665><stop.bleiben><en> Accidental groups of citizens would also stop before the balcony, their curiosity aroused by some uproar in the newspapers.
<G-vec00081-001-s666><stop.bleiben><de> "Natürlich bin ich trostlos, weil ""diese Bewertung eine sehr hohe Durchschnittsnote senken kann und ein abgelenkter Nutzer, der bei einer einfachen Analyse der durchschnittlichen Bewertung von Bewertungen stehen sollte, eine vollständig verzerrte Vorstellung von der Zufriedenheit unserer Gäste hätte."
<G-vec00081-001-s666><stop.bleiben><en> Of course I'm desolate because 'this review can lower a very high average rating, and a distracted user who should stop at a simple analysis of the average rating of reviews, would risk having a completely distorted idea of??the degree of satisfaction of our guests.
<G-vec00081-001-s667><stop.bleiben><de> Natürlich verrichtete man in der Zwischenzeit auch manche andere tägliche Arbeit; aber die vorerwähnte war für die bezeichnete Zeit eine Hauptarbeit, und weil die Sonne da wieder unter ein neues Zeichen zu stehen kam, so nannte man dieses Zeichen den,Widder' (Kostron).
<G-vec00081-001-s667><stop.bleiben><en> Naturally in the meantime one had some other daily tasks, but the previously mentioned was the main job for this time described and because the sun came to stop again under another sign, this sign was called the ram (Aries). 102,19.
<G-vec00081-001-s668><stop.bleiben><de> Passanten blieben stehen und sahen sich die Banner und Plakate an und unterschrieben die Petition, die ein Ende der Verfolgung fordert Die Falun Gong-Übenden rollten zwei Banner aus.
<G-vec00081-001-s668><stop.bleiben><en> Passers-by stop to look at banners and posters and sign petition calling for an end of the persecution
<G-vec00081-001-s669><stop.bleiben><de> Andrea Földi-Kovács: Nun, bleiben wir an diesem Punkt für einen Moment stehen.
<G-vec00081-001-s669><stop.bleiben><en> Andrea Földi-Kovács: Let's stop here for a moment.
<G-vec00081-001-s670><stop.bleiben><de> Ich vergebe mir, dass ich erlaubt und akzeptiert habe nicht aufzustehen und als diese Erkenntnis, dass ich verantwortlich bin zu stehen, eins und gleich.
<G-vec00081-001-s670><stop.bleiben><en> I forgive myself that I have accepted and allowed myself to believe that I am unable to stop myself
<G-vec00081-001-s671><stop.bleiben><de> Um den Buggy schnell und kontrolliert zum Stehen zu bekommen, brauch man auch die richtigen Bremsen.
<G-vec00081-001-s671><stop.bleiben><en> Bringing everything to a fast and controlled stop are a pair of vented steel disc brakes.
<G-vec00081-001-s672><stop.bleiben><de> Von der fröhlichen Musik angezogen, blieben viele Leute stehen und schauten zu.
<G-vec00081-001-s672><stop.bleiben><en> The joyful music attracted many people to stop and watch.
<G-vec00081-001-s673><stop.bleiben><de> """royal squad"", ist ein strategic tower game indem dir bögen, zaubersprüche, fallen und soldaten zur verfügung stehen um die f.."
<G-vec00081-001-s673><stop.bleiben><en> Royal squad is classified as strategic tower game, where you use archery, spells, traps and soldiers to stop the enemy from p..
<G-vec00081-001-s674><stop.bleiben><de> In ganz Europa blieben Züge mitten auf der Strecke stehen oder konnten nur mit reduzierter Leistungihre Fahrt fortsetzen, weil in die Schienenfahrzeuge eingedrungener Schnee elektrische Komponenten außer Funktion gesetzt hatte.
<G-vec00081-001-s674><stop.bleiben><en> In whole Europe trains had to stop at half distance or only could continue driving with reduced power, because the penetrated snow had put electronic components out of operation.
<G-vec00081-001-s675><stop.bleiben><de> – Dann bleibt die Zeit stehen.
<G-vec00081-001-s675><stop.bleiben><en> “Then time will stop.”
<G-vec00081-001-s676><stop.bleiben><de> Wenn ein Patrouillenpunkt nicht erreichbar ist, bleiben die Einheiten auf dem Weg zu diesem nicht mehr stehen.
<G-vec00081-001-s676><stop.bleiben><en> If a patrol point is not accessible the patrolling units no longer simply stop on the path to it
<G-vec00081-001-s677><stop.bleiben><de> Wichtiger Hinweis: Der Bedienungsknopf zum Herbeirufen oder zur Fahrt muss während der ganzen Fahrtzeit gedrückt gehalten werden, sonst bleibt die Fahrplattform stehen.
<G-vec00081-001-s677><stop.bleiben><en> Important notice: The control button for calling or riding the elevator must be kept pressed for the entire travel time of the platform, otherwise the platform will stop.
<G-vec00081-001-s678><stop.bleiben><de> Aber Pablo blieb nicht dabei stehen.
<G-vec00081-001-s678><stop.bleiben><en> But Pablo did not stop there.
<G-vec00081-001-s679><stop.bleiben><de> Stand man in der Öffentlichkeit auf Bänken oder ähnlichem herum, um Selbstportraits von sich zu schießen, so blieben vorbeigehende Leute oft unvermittelt stehen und schauten verwundert, belustigt und neugierig zu.
<G-vec00081-001-s679><stop.bleiben><en> When standing on benches or something similar in public to take a self portrait, people passing would often stop and look puzzled, amused, and curious.
<G-vec00081-001-s680><stop.bleiben><de> Doch dann öffnet der Himmel seine Schleusen, der Bus verlangsamt sein Tempo und bleibt dann stehen.
<G-vec00081-001-s680><stop.bleiben><en> But then the heavens open, and the bus slows down and finally comes to a stop.
<G-vec00081-001-s681><stop.bleiben><de> Weil die Fleischmann Weichen 9178/9179 Stoppfunktionen haben, bleiben die Züge stehen, wenn die Weiche falsch liegt.
<G-vec00081-001-s681><stop.bleiben><en> As the Fleischmann turnouts 9178/9179 are intelligent, the trains stop, if the turnout lies wrong.
<G-vec00081-001-s682><stop.bleiben><de> Uhren, die unter Magnetfeldeinfluß (siehe Magnetismus) bestimmter Stärke nicht stehen bleiben und deren Gangveränderungen bestimmte Grenzen nach einem Magnetfeldeinfluß nicht überschreiten, dürfen nach DIN antimagnetisch genannt werden.
<G-vec00081-001-s682><stop.bleiben><en> According to DIN, watches which do not stop when exposed to a magnetic field (see magnetism) and the accuracy of which does not exceed specified limits when exposed to a magnetic field may be described as antimagnetic.
<G-vec00081-001-s683><stop.bleiben><de> Das brachte die Panzer entweder zum Stehen, weil die Besatzung annahm, es handele sich um Minen, oder aber zwang die Soldaten auszusteigen, um nachzusehen; auf diese Weise wurden die Panzer auch mit kleineren Waffen angreifbar.
<G-vec00081-001-s683><stop.bleiben><en> This tended either to stop the tanks, the tank crew thinking they were mines, or got the soldiers out of their tanks investigating, thus becoming vulnerable to small arms fire.
