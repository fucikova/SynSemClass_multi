<G-vec00407-001-s095><insert.eingeben><de> Die Registrierung ist einfach und schnell: Sie müssen nur Ihre E-Mail Adresse eingeben.
<G-vec00407-001-s095><insert.eingeben><en> The registration is easy and fast; you only have to insert your email address.
<G-vec00407-001-s096><insert.eingeben><de> Die Bedienung ist extrem einfach: Röhrchen eingeben, Deckel schließen, Geschwindigkeit / Zeit einstellen, und auf Start drücken.
<G-vec00407-001-s096><insert.eingeben><en> Operation is extremely simple for this high-level of sophistication: Insert tubes, close lid, adjust speed/time, and press Start.
<G-vec00407-001-s097><insert.eingeben><de> Damit können Sie jederzeit neue Trigger eingeben und positionieren, ohne alle anderen vorhandenen Triggerpositionen anpassen oder ändern zu müssen.
<G-vec00407-001-s097><insert.eingeben><en> That way, you can insert and position new triggers at any time, without having to alter all your existing triggers to adjust the firing position.
<G-vec00407-001-s098><insert.eingeben><de> Empfehlen Sie uns weiter: Gleich ins Stammgastportal einloggen, unter „Empfehlung“ die Daten eines Freundes oder Bekannten eingeben und persönliche Urlaubsempfehlung absenden.
<G-vec00407-001-s098><insert.eingeben><en> Recommend us:Log in at our portal for regular guests, go to „Recommendation“ and insert the data of your friend or acquaintance to send your personal holiday recommendation.
<G-vec00407-001-s099><insert.eingeben><de> Oben an der Tür befindet sich ein Adressfenster, in das Sie die Hausnummer oder den Namen des Empfängers eingeben können.Dank der drei kleinen Fenster kann ohne Öffnen des Schlosses und der Tür überprüft werden, ob sich in der Box ein Brief befindet.An der Unterseite der Box befindet sichein Loch zum Verlassen von Zeitungen, Werbemagazinen oder Flugblättern.
<G-vec00407-001-s099><insert.eingeben><en> At the top of the door, there is an address window in which you can insert the house number or the recipients name. Thanks to three small windows, it is possible, without opening the lock and door, to check whether there is a letter inside the box. At the base of the box, there is a hole for leaving newspapers, advertising magazines or leaflets.
<G-vec00407-001-s100><insert.eingeben><de> Den Text dafür können Sie selbst frei eingeben und so dem Beschenkten einen ganz persönlichen Gruß übermitteln.
<G-vec00407-001-s100><insert.eingeben><en> You can insert the text for your voucher individually and offer your friends a very personal gift.
<G-vec00407-001-s101><insert.eingeben><de> Häufig müssen Sie nur die Datenträger in Ihren PC eingeben und den Anweisungen folgen, die Ihnen bereitgestellt werden.
<G-vec00407-001-s101><insert.eingeben><en> Most of the time, all you need to do is insert the media into your PC and follow the directions provided to you.
<G-vec00407-001-s102><insert.eingeben><de> "Wenn Sie schon den Code der Unterkunft kennen, können Sie diesen im Feld ""Schnellsuche"" oben rechts auf der Homepage eingeben."
<G-vec00407-001-s102><insert.eingeben><en> If you already know the accommodation code you can insert it in the 'Quick Search' field on the top right of the homepage.
<G-vec00407-001-s103><insert.eingeben><de> Wenn Sie aber diese Kundendaten in eine Software von einem Drittanbieter eingeben, wird dieses Unternehmen die Daten in Ihrem Auftrag verarbeiten und als Datenverarbeiter agieren.
<G-vec00407-001-s103><insert.eingeben><en> But if you insert that client data into a third party software, the software company will process this data on your behalf, making them the data processor.
<G-vec00407-001-s104><insert.eingeben><de> Wenn Sie bereits schon registriert sind haben, können Sie Ihre Identifizierung Daten eingeben und automatisch weiter gehen.
<G-vec00407-001-s104><insert.eingeben><en> If you are already registered for the e-shop insert your data details and you will automatically proceed.
<G-vec00407-001-s105><insert.eingeben><de> "Wenn Sie ""Skrill"" als bevorzugte Zahlungsmethode wählen, müssen Sie die E-Mail-Adresse eingeben, die Ihr Skrill-Konto repräsentiert."
<G-vec00407-001-s105><insert.eingeben><en> "Should you choose ""Skrill"" as your preferable payment method, you will be required to insert the email which represents your Skrill account."
<G-vec00407-001-s106><insert.eingeben><de> Ferner müssen Sie Ihre Anschrift, Ihre Telefonnummer oder Ihre E-Mail-Adresse eingeben.
<G-vec00407-001-s106><insert.eingeben><en> You must also insert your address, telephone number or e-mail address.
<G-vec00407-001-s107><insert.eingeben><de> Ist der Graph G fertig aufgebaut, lassen wir den Benutzer zwei Worte from und to eingeben, zu denen eine Ableitung gesucht werden soll.
<G-vec00407-001-s107><insert.eingeben><en> After the graph G has been completely constructed, we let the user insert two words from and to, for which a derivation is to be searched.
