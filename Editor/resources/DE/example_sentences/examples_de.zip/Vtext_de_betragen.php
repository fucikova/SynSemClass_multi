<G-vec00206-001-s114><amount.betragen><de> Die Mindestabstände von Motor- und Segelbooten mit weniger als 12 Meter Länge zur Küste betragen 50 Meter, bei längeren Schiffen 150 Meter.
<G-vec00206-001-s114><amount.betragen><en> The minimum distance of motor and sailboats with less than twelve meters in length to the coast amount to 50 meters, and for longer boats it is 150 meters.
<G-vec00206-001-s115><amount.betragen><de> Die Stückkosten der eingekauften Güter und Leistungen sowie die Prozesskosten betragen durchschnittlich über 50% der Gesamtkosten eines Unternehmens.
<G-vec00206-001-s115><amount.betragen><en> The cost per unit of the purchased goods and services as well as the process costs amount to an average of more than 50% of the overall costs of a company.
<G-vec00206-001-s116><amount.betragen><de> """Wir bauen Anlagen, die 5 bis 8 MW groß sind, das bedeutet, dass allein die Grundstücksflächen zwischen 80.000 und 150.000 m2 betragen müssen"", so Andreas Fleischmann."
<G-vec00206-001-s116><amount.betragen><en> """We build plants of sizes 5 to 8 MW, which means that the plot sizes alone should amount to 80,000 and 150,000 mÂ2,"" says Andreas Fleischmann."
<G-vec00206-001-s117><amount.betragen><de> Werden die jährlich festgelegten Jahresziele übertroffen, kann der Performance Bonus über dem Zielbonus liegen; er kann jedoch maximal 200 Prozent des Zielbonus (Cap) betragen.
<G-vec00206-001-s117><amount.betragen><en> If the annual targets are exceeded, the performance bonus may also exceed the target bonus; however, it may not amount to more than 200% of the target bonus (cap).
<G-vec00206-001-s118><amount.betragen><de> Negative Sauerstoffionen und negative Ionen betragen bis zu 10 Millionen Ionen/cmÂ3.
<G-vec00206-001-s118><amount.betragen><en> Negative oxygen ions and negative ions amount to up to 10,000,000 ions/cc.
<G-vec00206-001-s119><amount.betragen><de> Bei Lagerung durch den Verkäufer betragen die Lagerkosten 0,25% des Rechnungsbetrages der zu lagernden Liefergegenstände pro abgelaufene Woche.
<G-vec00206-001-s119><amount.betragen><en> If the goods are stored by the seller then the storage costs amount to 0.25% of the invoiced amount of the stored items for delivery per lapsed week.
<G-vec00206-001-s120><amount.betragen><de> Nach aktuellen Berechnungen betragen die Baukosten insgesamt rund 76 Millionen Euro brutto.
<G-vec00206-001-s120><amount.betragen><en> According to the latest calculations, the construction costs amount in total to about 76 million Euros gross.
<G-vec00206-001-s121><amount.betragen><de> Diese Finanzierungsanteile können bis zu 65% des kalkulierten Budgets betragen.
<G-vec00206-001-s121><amount.betragen><en> Such funding can amount to as much as 65% of the calculated budget.
<G-vec00206-001-s122><amount.betragen><de> Die Kosten für den Standard Test, der übrigens die gesetzlich weltweit vorgeschriebene UN-T Prüfung (United Nations Transportation Test - Transportvorschriften für Lithiumbatterien) beinhaltet, betragen etwa 5.000 bis 6.000 Euro.“ Günstiger, als ein eigenes Labor aufzubauen, in das nach Steinkes Angaben problemlos mehrere Millionen Euro investiert werden können.
<G-vec00206-001-s122><amount.betragen><en> The cost of the standard test amount to 5,000 to 6,000 €. The cost of the United Nations Transportation (UN-T) Test is included in the price. This is cheaper than building an own lab, since the investment for a company-owned laboratory can amount to several million euros.
<G-vec00206-001-s123><amount.betragen><de> Die Studiengebühren zum Studienbeginn 2018 betragen 630 Euro pro Monat.
<G-vec00206-001-s123><amount.betragen><en> The course fees at the beginning of the 2018 academic year amount to EUR 630 per month.
<G-vec00206-001-s124><amount.betragen><de> Die Übertragungsraten betragen 10 MB und mehr, wobei Weiterentwicklungen wie SCSI 2, Fast SCSI, Wide SCSI und andere höhere Raten bieten und zusätzlich einen Anschluss von mehr Geräten ermöglichen.
<G-vec00206-001-s124><amount.betragen><en> The data transmission rates amount to 10 MT and more, whereby advancements offer such as SCSI 2, nearly SCSI, Wide SCSI and other higher rates and make additionally a connection possible of more devices.
<G-vec00206-001-s125><amount.betragen><de> 2 Die monatliche Rückzahlung muss gesetzlich mindestens 5,6% Ihres geschuldeten Saldos betragen.
<G-vec00206-001-s125><amount.betragen><en> 2 By law, the amount you repay monthly must be at least 5.6% of your outstanding balance.
<G-vec00206-001-s126><amount.betragen><de> betragen pauschal 6,95 Euro.
<G-vec00206-001-s126><amount.betragen><en> amount to a lump sum of 6.95 Euros.
<G-vec00206-001-s127><amount.betragen><de> Die Jahreskapazität wird im Normalbetrieb 180.000 Tonnen betragen, bei Spitzenlast bis zu 220.000 Tonnen.
<G-vec00206-001-s127><amount.betragen><en> The yearly capacity will amount to in the normal operation 180,000 tons, with peak load up to 220.000 tons.
<G-vec00206-001-s128><amount.betragen><de> Um auf Dauer in solchen Situationen zu gewinnen muss unsere Gewinnerwartung (Gewinnchance) mindestens 33% (2 zu 1) betragen.
<G-vec00206-001-s128><amount.betragen><en> To continuously win in such situations our chances of winning have to amount to at least 50%.
<G-vec00206-001-s129><amount.betragen><de> 9.2 Die außergerichtlichen Inkassokosten betragen höchstens 15 % der Forderung(en) und mindestens 40,- €.
<G-vec00206-001-s129><amount.betragen><en> 9.2 The extrajudicial costs will amount to fifteen per cent (15%) maximum of the amount or amounts owed, with a minimum of € 40.
<G-vec00206-001-s130><amount.betragen><de> Dieser Einfluß kann durchaus 30% +- betragen.
<G-vec00206-001-s130><amount.betragen><en> This influence varies but can by all means amount up to 30%.
<G-vec00206-001-s131><amount.betragen><de> Die eingereichten Schätzungen der Schäden der Gemeinden betragen 613.000 Euro.Angefordert werden in etwa 552.000 Euro, denn einige Kostenanteile konnten von verschiedenen Gemeinden übernommen werden.
<G-vec00206-001-s131><amount.betragen><en> The submitted estimates of the damage to municipalities amount to 613,000 euros. About 552,000 euros are being called for, because the various municipalities were able to take on some parts of the costs.
<G-vec00206-001-s132><amount.betragen><de> In Bezug auf Enteignung, das Schiedsgericht entschieden, dass Respondents Notfallmaßnahmen nicht zu einem Verlust der des Antragstellers Eigentumsrecht oder Konzession zu betragen hat.
<G-vec00206-001-s132><amount.betragen><en> With respect to expropriation, the Arbitral Tribunal ruled that Respondent’s emergency measures did not amount to a loss of Claimant’s property right or concession.
