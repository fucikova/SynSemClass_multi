<G-vec00120-001-s019><sanction.ahnden><de> Es ist Aufgabe nationaler Politik, internationale Regeln und Standards durchzusetzen und Verstöße gegen sie zu ahnden.
<G-vec00120-001-s019><sanction.ahnden><en> It is the task of national policy-makers to impose international rules and standards and to sanction those who infringe them.
