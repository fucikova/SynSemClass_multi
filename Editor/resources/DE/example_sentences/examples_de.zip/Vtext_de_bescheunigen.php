<G-vec00337-001-s037><hasten.bescheunigen><de> Sie verlässt sich auf die Gebetsgruppen, das Kommen des Neuen Pfingsten der Liebe zu bescheunigen.
<G-vec00337-001-s037><hasten.bescheunigen><en> She counts on the prayer groups to hasten the coming of the New Pentecost of Love.
<G-vec00337-001-s038><hasten.bescheunigen><de> Sie verlässt sich auf die Gebetsgruppen, das Kommen des Neuen Pfingsten der Liebe zu bescheunigen.„...durch sie, meine kleinen Kinder, kann ich sehen, dass der Heilige Geist in der Welt wirkt...“, sagt sie.
<G-vec00337-001-s038><hasten.bescheunigen><en> "She counts on the prayer groups to hasten the coming of the New Pentecost of Love.""...through them I can see, little children, that the Holy Spirit is at work in the world..."" she says."
