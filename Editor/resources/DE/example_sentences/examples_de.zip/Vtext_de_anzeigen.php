<G-vec00060-001-s127><indicate.anzeigen><de> Hat jedoch der Hersteller oder sein Bevollmächtigter nach einer oder mehrerer dieser Richtlinien während einer Übergangszeit die Wahl der anzuwendenden Regelung, so wird durch die CE-Kennzeichnung lediglich die Konformität mit den Bestimmungen der von ihm angewandten Richtlinien angezeigt.
<G-vec00060-001-s127><indicate.anzeigen><en> However, where one or more of those Directives allow the manufacturer or his authorised representative to choose, during a transitional period, the system to be applied, the CE marking shall indicate conformity only to the provisions of those Directives applied by the manufacturer or his authorised representative.
<G-vec00060-001-s128><indicate.anzeigen><de> Das Anliegen der Spannungsversorgung und der Betriebszustand des Moduls werden durch Leuchtdioden angezeigt.
<G-vec00060-001-s128><indicate.anzeigen><en> LEDs are used to indicate applied voltage supply and the module operating status.
<G-vec00060-001-s129><indicate.anzeigen><de> Die EtherCAT Box enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s129><indicate.anzeigen><en> The EtherCAT Box has two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s130><indicate.anzeigen><de> Nach der Anmeldung wird durch Flächenlichter angezeigt, welchen jeweiligen Ladepunkt der Kunde gerade benutzen kann.
<G-vec00060-001-s130><indicate.anzeigen><en> After logging on, large lights indicate which charging point the customer can use.
<G-vec00060-001-s131><indicate.anzeigen><de> Die EtherCAT-Klemmen enthalten je zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s131><indicate.anzeigen><en> The EtherCAT Terminals have two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s132><indicate.anzeigen><de> Unabhängig vom gewählten Menü wird Ihnen der Fortschritt des Downloads auch durch das Symbol -3- Abb.2 in der Statuszeile angezeigt.
<G-vec00060-001-s132><indicate.anzeigen><en> Irrespective of the selected menu, a symbol -3- Fig.2 in the status line will indicate the status of the download progress.
<G-vec00060-001-s133><indicate.anzeigen><de> Wenn die entsprechenden Optionsfelder aktiviert sind, werden technische Stromrichtung (rote Pfeile), magnetische Feldlinien (blau) und Lorentzkraft (schwarzer Pfeil) angezeigt.
<G-vec00060-001-s133><indicate.anzeigen><en> If the corresponding checkboxes are selected, the app will indicate the conventional direction of current (red arrows), the magnetic field lines (blue) and the Lorentz force (black arrow).
<G-vec00060-001-s134><indicate.anzeigen><de> Dann wird Ihnen die Version und das Build der Plattform die Sie installiert haben angezeigt.
<G-vec00060-001-s134><indicate.anzeigen><en> This will indicate the version and build of the platform you have installed.
<G-vec00060-001-s135><indicate.anzeigen><de> Dabei werden die Planeten in der Radix in grün dargestellt; so wird angezeigt, dass es sich hier nicht mehr um ein Geburtshoroskop mit Transiten, sondern um Progressionen handelt.
<G-vec00060-001-s135><indicate.anzeigen><en> When you right click on a progression to look at it in more detail in a wheel, you'll remark that the planets are shown in green to indicate that it's not a birth chart with transits, but a progression.
<G-vec00060-001-s136><indicate.anzeigen><de> Wenn im Anhängerbetrieb am Anhänger oder am Fahrzeug eine Blinkleuchte ausfällt, wird dies durch doppelt so schnelles Blinken der Kontrollleuchte angezeigt.
<G-vec00060-001-s136><indicate.anzeigen><en> If a turn signal bulb on the trailer or vehicle fails in towing mode, the indicator lamp flashes twice as fast to indicate the bulb failure.
<G-vec00060-001-s137><indicate.anzeigen><de> Fehlmontage ausgeschlossen Als erster Hersteller von Schlaucharmaturen hat Voswinkel dieses Problem gelöst: Bei den neuen ECOVOS-Armaturen mit Blocksicherung wird das Montageende eindeutig angezeigt.
<G-vec00060-001-s137><indicate.anzeigen><en> Voswinkel is the first manufacturer of hose fittings to solve this problem: The new ECOVOS fittings with block stop feature clearly indicate when mounting is completed.
<G-vec00060-001-s138><indicate.anzeigen><de> Zudem wird durch farbliche LEDs angezeigt, dass das Gerät eine stehende Verbindung hat und auch, ob der Akku langsam leer läuft.
<G-vec00060-001-s138><indicate.anzeigen><en> In addition, colour LEDs indicate that the module has an established connection and also whether the battery is gradually going flat.
<G-vec00060-001-s139><indicate.anzeigen><de> Während die Einstellung U gilt, wird dies durch ein,,U`` in der Statuszeile von exaEdit angezeigt.
<G-vec00060-001-s139><indicate.anzeigen><en> As long as U is in effect, a U in the status line will indicate this.
<G-vec00060-001-s140><indicate.anzeigen><de> "Wenn sehr viele Figurenwechsel vorkommen, kann es auch einfacher sein, ""Instrument""-Definitionen für jeden Namen auf oberster Dateiebene zu definieren, sodass \instrumentSwitch der Wechsel der Figur angezeigt werden kann."
<G-vec00060-001-s140><indicate.anzeigen><en> "Alternatively, if there are many character changes, it may be easier to set up ""instrument"" definitions for each character at the top level so that \instrumentSwitch can be used to indicate each change."
<G-vec00060-001-s141><indicate.anzeigen><de> Zusätzlich wird der Schaltzustand der Eingänge mit je einer LED angezeigt.
<G-vec00060-001-s141><indicate.anzeigen><en> In addition, each input has an LED used to indicate its status.
<G-vec00060-001-s142><indicate.anzeigen><de> Es sollte indessen Folgendes klargemacht werden: Wenn in der Göttlichkeit irgendeiner Situation, unter extremen Umständen, und immer dann, wenn in Befolgung höchster Weisheit eine andere Vorgehensweise angezeigt erschiene – wenn die Ansprüche der Vollkommenheit aus irgendeinem Grunde eine andere und bessere Reaktionsweise gebieten sollten – dann würde der allweise Gott auf der Stelle in dieser besseren und passenderen Art handeln.
<G-vec00060-001-s142><indicate.anzeigen><en> It should be made clear, however, that, if, in the divinity of any situation, in the extremity of any circumstance, in any case where the course of supreme wisdom might indicate the demand for different conduct—if the demands of perfection might for any reason dictate another method of reaction, a better one, then and there would the all-wise God function in that better and more suitable way.
<G-vec00060-001-s143><indicate.anzeigen><de> Halten Sie die Taste Shift gedrückt und ziehen Sie die Auswahl genau zwischen die anderen beiden Spalten, bis die orangefarbenen Umrisse, die während des Ziehens angezeigt werden, sich bewegen.
<G-vec00060-001-s143><indicate.anzeigen><en> Hold down the Shift key and drag the selection exactly between the other two columns until the orange boundaries shown during the drag operation indicate a move.
<G-vec00060-001-s144><indicate.anzeigen><de> Die EtherCAT-P-Box enthält zwei Kanäle, deren Signalzustand durch Leuchtdioden angezeigt wird.
<G-vec00060-001-s144><indicate.anzeigen><en> The EtherCATP Box has two channels that indicate their signal state via light emitting diodes.
<G-vec00060-001-s145><indicate.anzeigen><de> D: Es wird angezeigt, wie viele Arbeitsmappen oder Dateien gedruckt werden.
<G-vec00060-001-s145><indicate.anzeigen><en> D: It will indicate how many workbooks or files will be printed.
<G-vec00332-001-s019><show.anzeigen><de> In der Tat, jede Art von Suchergebnissen, die angezeigt werden sind häufig tot Web-Links oder Web-Link zurück auf die genau gleiche Seite unter verschiedenen Namen.
<G-vec00332-001-s019><show.anzeigen><en> Definitely, any kind of search engine results page that do show up are typically dead links or web link back to the very same web page under various names.
<G-vec00332-001-s020><show.anzeigen><de> Mac iPhone 4 Ringtone Maker wird automatisch angezeigt iTunes Wiedergabeliste auf der linken Seite des Programms können Sie Ihre iTunes-Video auf dem Programm wählen, oder ziehen Sie Videos in das Programm direkt.
<G-vec00332-001-s020><show.anzeigen><en> Mac iPhone 4 Ringtone Maker will automatically show up iTunes playlist on the left of the program, you can choose your iTunes video to the program, or drag video to the program directly.
<G-vec00332-001-s021><show.anzeigen><de> Auch hier wird beim jeweiligen Namen die Position in der Etage angezeigt und beim Klick auf die Raumdetailseite verlinkt.
<G-vec00332-001-s021><show.anzeigen><en> Here again, move the cursor to the name to show the position, and click on the name to show the detail page.
<G-vec00332-001-s022><show.anzeigen><de> Wenn eine solche Bestätigung nicht angezeigt wird, muss die Korrektur komplex sein.
<G-vec00332-001-s022><show.anzeigen><en> If such a confirmation does not show, then the correction must be a complex one.
<G-vec00332-001-s023><show.anzeigen><de> "Wähle ""Suchen"", wenn deine Promoted Pins in den Suchergebnissen angezeigt werden sollen."
<G-vec00332-001-s023><show.anzeigen><en> "Choose ""Search"" to show your Promoted Pins in search results."
<G-vec00332-001-s024><show.anzeigen><de> In der 5-stelligen Preis Zitat kann jede Fraktion von 0 bis 9 angezeigt.
<G-vec00332-001-s024><show.anzeigen><en> In the 5-digit pricing quote, any fraction from 0 to 9 may show up.
<G-vec00332-001-s025><show.anzeigen><de> Strassenname und Strassennummer werden nun in der korrekten Reihenfolge angezeigt, entsprechend den Daten auf der zugehörigen Karte.
<G-vec00332-001-s025><show.anzeigen><en> Always show street number and street name in correct order based on map data.
<G-vec00332-001-s026><show.anzeigen><de> "Hinweis: Sie erhalten die Benennen Sie ""Ihren Ordnernamen"" um in das Kontextmenü in Outlook 2007 und ""Ihr Ordnername""Wird als der aktuelle Name des ausgewählten Ordners angezeigt."
<G-vec00332-001-s026><show.anzeigen><en> Note: You will get the Rename “your folder name” in the right-clicking menu in Outlook 2007, and “Your folder name” will show as the current name of selected folder.
<G-vec00332-001-s027><show.anzeigen><de> Wie bei jedem Produkt könnte es regelmäßig auf eBay oder Amazon, dennoch angezeigt dies ist nicht sehr wahrscheinlich so zuverlässig ab die CrazyBulk amtliche Web Site sowie es empfiehlt sich in der Regel nicht zu kaufen bei eBay oder Amazon als die Qualität oder Erstattungen können nicht garantiert werden.
<G-vec00332-001-s027><show.anzeigen><en> African Mango Extract can be bought from the BauerNutrition main web site from Algeria and also this seems like the only method to get it. Just like any product, it could periodically show up on ebay.com or Amazon, however this is not most likely to be as dependable as from the BauerNutrition main site and also it is normally recommended not to purchase from eBay or Amazon.com as the top quality or refunds could not be ensured.
<G-vec00332-001-s028><show.anzeigen><de> "• Wenn die Disc (Playlist) gewechselt wird, kann es dazu kommen, dass ""EJECT"" im Display angezeigt wird."
<G-vec00332-001-s028><show.anzeigen><en> "• When the disc is changed, ""EJECT"" will show up instantly."
<G-vec00332-001-s029><show.anzeigen><de> "Nachdem Sie die Formel eingegeben und anschließend die Eingabetaste gedrückt haben, wird die Zeilennummer der Zelle angezeigt, die ""Tinte""."
<G-vec00332-001-s029><show.anzeigen><en> "After entering the formula, and then press the Enter key, it will show the row number of the cell which contains ""ink""."
<G-vec00332-001-s030><show.anzeigen><de> Klicken Sie auf diesen Link und durch Google maps komplettes Bildschirmgroße wird Ihnen angezeigt, wo wir uns befinden.
<G-vec00332-001-s030><show.anzeigen><en> Please click in this link and the Google maps screen will show you where we are located.
<G-vec00332-001-s031><show.anzeigen><de> Klicken Sie auf die horizontale Linie neben der Beziehung UND, und es werden einige Bedingungsfelder angezeigt, klicken Sie auf die Bedingungsfelder und geben Sie das Kriterium einzeln nach Bedarf an.
<G-vec00332-001-s031><show.anzeigen><en> Click the horizontal line beside the relationship AND, and it will show some condition boxes, click the condition boxes and specify the criterion one after one as you need.
<G-vec00332-001-s032><show.anzeigen><de> Wenn sie dann noch immer auf dem Bildschirm „Bericht“ sind, wird der gewünschte Bericht angezeigt.
<G-vec00332-001-s032><show.anzeigen><en> If still on the report screen, the desired report will show.
<G-vec00332-001-s033><show.anzeigen><de> Ohne Zweifel, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel tot Web-Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00332-001-s033><show.anzeigen><en> Indeed, any type of search results page that do show up are usually dead web links or web link back to the very same page under different names.
<G-vec00332-001-s034><show.anzeigen><de> Wird dieser Punkt neben einer TV-Staffel oder Podcast-Serie angezeigt, wurde mindestens eine Folge der Staffel oder Serie noch nicht abgespielt.
<G-vec00332-001-s034><show.anzeigen><en> If this appears next to a TV show season or podcast series, there is at least one episode in the season or series that hasn't been played.
<G-vec00332-001-s035><show.anzeigen><de> • Session-Cookies:Das sind zeitlich begrenzte Cookies und diese werden durch das Schließen des Browsers ge-löscht.o adaptive_image: Speichert die aktuelle Auflösung, um die geeignete Bildgröße auszuspieleno has_js: Speichert, ob der Browser des Users JavaScript hat oder nicht, um bestimmte Funktionen oder Darstellungen wiederzugebeno cookie_agreed: Ob der User Cookie- Popup akzeptiert hat oder nicht, um zu entscheiden, ob dem User der Hinweis nochmal angezeigt werden muss oder nicht.
<G-vec00332-001-s035><show.anzeigen><en> • Session cookies:These are temporary cookies and they are deleted by closing the browser.o adaptive image: Saves the current resolution to play the appropriate image sizeo has_js: saves information on whether the user's browser has JavaScript as to provide specific functions or display formatso cookie_agreed: checks if the user has accepted the cookie popup to decide whether to show the notice again or not.
<G-vec00332-001-s036><show.anzeigen><de> Im Display können neben den Informationen des Bordcomputers (Bordcomputer 1 oder 2) auch Informationen weiterer Systeme angezeigt werden.
<G-vec00332-001-s036><show.anzeigen><en> As well as the figures from the on-board computer (computer 1 or 2), the display can also show information from other systems.
<G-vec00332-001-s037><show.anzeigen><de> Auf jeden Fall, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel Tote Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00332-001-s037><show.anzeigen><en> Indeed, any type of search engine results page that do show up are typically dead links or link back to the very same page under different names.
<G-vec00358-001-s019><show.anzeigen><de> In der Tat, jede Art von Suchergebnissen, die angezeigt werden sind häufig tot Web-Links oder Web-Link zurück auf die genau gleiche Seite unter verschiedenen Namen.
<G-vec00358-001-s019><show.anzeigen><en> Definitely, any kind of search engine results page that do show up are typically dead links or web link back to the very same web page under various names.
<G-vec00358-001-s020><show.anzeigen><de> Mac iPhone 4 Ringtone Maker wird automatisch angezeigt iTunes Wiedergabeliste auf der linken Seite des Programms können Sie Ihre iTunes-Video auf dem Programm wählen, oder ziehen Sie Videos in das Programm direkt.
<G-vec00358-001-s020><show.anzeigen><en> Mac iPhone 4 Ringtone Maker will automatically show up iTunes playlist on the left of the program, you can choose your iTunes video to the program, or drag video to the program directly.
<G-vec00358-001-s021><show.anzeigen><de> Auch hier wird beim jeweiligen Namen die Position in der Etage angezeigt und beim Klick auf die Raumdetailseite verlinkt.
<G-vec00358-001-s021><show.anzeigen><en> Here again, move the cursor to the name to show the position, and click on the name to show the detail page.
<G-vec00358-001-s022><show.anzeigen><de> Wenn eine solche Bestätigung nicht angezeigt wird, muss die Korrektur komplex sein.
<G-vec00358-001-s022><show.anzeigen><en> If such a confirmation does not show, then the correction must be a complex one.
<G-vec00358-001-s023><show.anzeigen><de> "Wähle ""Suchen"", wenn deine Promoted Pins in den Suchergebnissen angezeigt werden sollen."
<G-vec00358-001-s023><show.anzeigen><en> "Choose ""Search"" to show your Promoted Pins in search results."
<G-vec00358-001-s024><show.anzeigen><de> In der 5-stelligen Preis Zitat kann jede Fraktion von 0 bis 9 angezeigt.
<G-vec00358-001-s024><show.anzeigen><en> In the 5-digit pricing quote, any fraction from 0 to 9 may show up.
<G-vec00358-001-s025><show.anzeigen><de> Strassenname und Strassennummer werden nun in der korrekten Reihenfolge angezeigt, entsprechend den Daten auf der zugehörigen Karte.
<G-vec00358-001-s025><show.anzeigen><en> Always show street number and street name in correct order based on map data.
<G-vec00358-001-s026><show.anzeigen><de> "Hinweis: Sie erhalten die Benennen Sie ""Ihren Ordnernamen"" um in das Kontextmenü in Outlook 2007 und ""Ihr Ordnername""Wird als der aktuelle Name des ausgewählten Ordners angezeigt."
<G-vec00358-001-s026><show.anzeigen><en> Note: You will get the Rename “your folder name” in the right-clicking menu in Outlook 2007, and “Your folder name” will show as the current name of selected folder.
<G-vec00358-001-s027><show.anzeigen><de> Wie bei jedem Produkt könnte es regelmäßig auf eBay oder Amazon, dennoch angezeigt dies ist nicht sehr wahrscheinlich so zuverlässig ab die CrazyBulk amtliche Web Site sowie es empfiehlt sich in der Regel nicht zu kaufen bei eBay oder Amazon als die Qualität oder Erstattungen können nicht garantiert werden.
<G-vec00358-001-s027><show.anzeigen><en> African Mango Extract can be bought from the BauerNutrition main web site from Algeria and also this seems like the only method to get it. Just like any product, it could periodically show up on ebay.com or Amazon, however this is not most likely to be as dependable as from the BauerNutrition main site and also it is normally recommended not to purchase from eBay or Amazon.com as the top quality or refunds could not be ensured.
<G-vec00358-001-s028><show.anzeigen><de> "• Wenn die Disc (Playlist) gewechselt wird, kann es dazu kommen, dass ""EJECT"" im Display angezeigt wird."
<G-vec00358-001-s028><show.anzeigen><en> "• When the disc is changed, ""EJECT"" will show up instantly."
<G-vec00358-001-s029><show.anzeigen><de> "Nachdem Sie die Formel eingegeben und anschließend die Eingabetaste gedrückt haben, wird die Zeilennummer der Zelle angezeigt, die ""Tinte""."
<G-vec00358-001-s029><show.anzeigen><en> "After entering the formula, and then press the Enter key, it will show the row number of the cell which contains ""ink""."
<G-vec00358-001-s030><show.anzeigen><de> Klicken Sie auf diesen Link und durch Google maps komplettes Bildschirmgroße wird Ihnen angezeigt, wo wir uns befinden.
<G-vec00358-001-s030><show.anzeigen><en> Please click in this link and the Google maps screen will show you where we are located.
<G-vec00358-001-s031><show.anzeigen><de> Klicken Sie auf die horizontale Linie neben der Beziehung UND, und es werden einige Bedingungsfelder angezeigt, klicken Sie auf die Bedingungsfelder und geben Sie das Kriterium einzeln nach Bedarf an.
<G-vec00358-001-s031><show.anzeigen><en> Click the horizontal line beside the relationship AND, and it will show some condition boxes, click the condition boxes and specify the criterion one after one as you need.
<G-vec00358-001-s032><show.anzeigen><de> Wenn sie dann noch immer auf dem Bildschirm „Bericht“ sind, wird der gewünschte Bericht angezeigt.
<G-vec00358-001-s032><show.anzeigen><en> If still on the report screen, the desired report will show.
<G-vec00358-001-s033><show.anzeigen><de> Ohne Zweifel, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel tot Web-Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00358-001-s033><show.anzeigen><en> Indeed, any type of search results page that do show up are usually dead web links or web link back to the very same page under different names.
<G-vec00358-001-s034><show.anzeigen><de> Wird dieser Punkt neben einer TV-Staffel oder Podcast-Serie angezeigt, wurde mindestens eine Folge der Staffel oder Serie noch nicht abgespielt.
<G-vec00358-001-s034><show.anzeigen><en> If this appears next to a TV show season or podcast series, there is at least one episode in the season or series that hasn't been played.
<G-vec00358-001-s035><show.anzeigen><de> • Session-Cookies:Das sind zeitlich begrenzte Cookies und diese werden durch das Schließen des Browsers ge-löscht.o adaptive_image: Speichert die aktuelle Auflösung, um die geeignete Bildgröße auszuspieleno has_js: Speichert, ob der Browser des Users JavaScript hat oder nicht, um bestimmte Funktionen oder Darstellungen wiederzugebeno cookie_agreed: Ob der User Cookie- Popup akzeptiert hat oder nicht, um zu entscheiden, ob dem User der Hinweis nochmal angezeigt werden muss oder nicht.
<G-vec00358-001-s035><show.anzeigen><en> • Session cookies:These are temporary cookies and they are deleted by closing the browser.o adaptive image: Saves the current resolution to play the appropriate image sizeo has_js: saves information on whether the user's browser has JavaScript as to provide specific functions or display formatso cookie_agreed: checks if the user has accepted the cookie popup to decide whether to show the notice again or not.
<G-vec00358-001-s036><show.anzeigen><de> Im Display können neben den Informationen des Bordcomputers (Bordcomputer 1 oder 2) auch Informationen weiterer Systeme angezeigt werden.
<G-vec00358-001-s036><show.anzeigen><en> As well as the figures from the on-board computer (computer 1 or 2), the display can also show information from other systems.
<G-vec00358-001-s037><show.anzeigen><de> Auf jeden Fall, jede Art von Suchmaschine Ergebnisseite, die angezeigt werden sind in der Regel Tote Links oder Hyperlinks zurück zu genau derselben Webseite unter verschiedenen Bezeichnungen.
<G-vec00358-001-s037><show.anzeigen><en> Indeed, any type of search engine results page that do show up are typically dead links or link back to the very same page under different names.
<G-vec00276-001-s056><advertise.anzeigen><de> Die Verwendung der DoubleClick-Cookies ermöglicht Google und seinen Partner-Webseiten lediglich die Schaltung von Anzeigen auf Basis vorheriger Besuche auf unserer oder anderen Webseiten im Internet.
<G-vec00276-001-s056><advertise.anzeigen><en> The use of DoubleClick cookies allows Google and its affiliate sites to advertise on the basis of prior visits to our or other websites on the internet.
<G-vec00276-001-s057><advertise.anzeigen><de> Händler können auf EMR Anzeigen schalten, um potentielle Kunden anzusprechen.
<G-vec00276-001-s057><advertise.anzeigen><en> As a vendor, you may be interested in advertise on EMR to find prospective buyers.
<G-vec00276-001-s058><advertise.anzeigen><de> My Catholic Standard Nachrichten, Kleinanzeige, Anzeigen und mehr.
<G-vec00276-001-s058><advertise.anzeigen><en> My Catholic Standard News, Classifieds, Advertise and more.
<G-vec00276-001-s059><advertise.anzeigen><de> Gelegentlich gibt es auch Anzeigen in der Zeitung (normalerweise in der Unterhaltung/Kunst Spalte) oder in dem Gemeinde Magazin.
<G-vec00276-001-s059><advertise.anzeigen><en> On occasion they may advertise in the local paper (usually in the entertainment/arts section) or community magazine.
<G-vec00276-001-s060><advertise.anzeigen><de> Somit können die Mitglieder in Echtzeit die Daten zu Arbeitssuchenden, Arbeitgebern sowie - allgemeiner betrachtet - zu Beschäftigungsangeboten angeben, anzeigen und modifizieren.
<G-vec00276-001-s060><advertise.anzeigen><en> In this way, the members can, in real-time, modify, specify and advertise data concerning jobseekers, employers, as well as – more generally –Â job offers.
<G-vec00276-001-s061><advertise.anzeigen><de> Nachrichten, Anzeigen und Read the Paper.
<G-vec00276-001-s061><advertise.anzeigen><en> News, Advertise and Read the Paper.
<G-vec00276-001-s062><advertise.anzeigen><de> Santa Ynez Valley Journal Geschichte, Writers, Archiv, Anzeigen und Search Artikel .
<G-vec00276-001-s062><advertise.anzeigen><en> Santa Ynez Valley Journal History, Writers, Archive, Advertise and Search articles.
<G-vec00276-001-s063><advertise.anzeigen><de> Weiser Signal American Submit News/Briefe, Anzeigen und Subscribe.
<G-vec00276-001-s063><advertise.anzeigen><en> Weiser Signal American Submit News/Letters, Advertise and Subscribe.
<G-vec00060-001-s162><indicate.anzeigen><de> atariModePossible muss anzeigen, daß der MMU-Switch erlaubt ist.
<G-vec00060-001-s162><indicate.anzeigen><en> atariModePossible must indicate that MMU switching is permitted.
<G-vec00060-001-s163><indicate.anzeigen><de> Ein solches Muster kann die Ähnlichkeit seines Trägers mit einem bestimmten Vertreter der Fauna anzeigen.
<G-vec00060-001-s163><indicate.anzeigen><en> Such a pattern may indicate the similarity of its carrier with a certain representative of the fauna.
<G-vec00060-001-s164><indicate.anzeigen><de> Alle drei Männer trugen Luftwaffen-Uniformen ohne Aufkleber, die anzeigen, wer sie waren.
<G-vec00060-001-s164><indicate.anzeigen><en> All three of the men were wearing Air Force uniforms without any patches to indicate who they were.
<G-vec00060-001-s165><indicate.anzeigen><de> Sie kann den Grad der magnetischen Aufladung von Gegenständen oder Wasser anzeigen.
<G-vec00060-001-s165><indicate.anzeigen><en> It can indicate the degree of magnetization of objects or water.
<G-vec00060-001-s166><indicate.anzeigen><de> Es gibt eine andere Rangordnung von Bedeutungen, in der sie die Aura oder Tätigkeit göttlicher Wesen anzeigen, wie Krishna, Mahakali, Radha, oder auch anderer übermenschlicher Wesen; es gibt eine weitere Kategorie, in der sie die Aura um Objekte oder lebende Personen anzeigen – und hiermit ist die Reihe der Möglichkeiten noch nicht erschöpft.
<G-vec00060-001-s166><indicate.anzeigen><en> There is another order of significances in which they indicate the aura or the activity of divine beings, Krishna, Mahakali, Radha or else of other superhuman beings; there is another in which they indicate the aura around objects or living persons – and that does not exhaust the list of possibilities.
<G-vec00060-001-s167><indicate.anzeigen><de> Es gibt eine andere Rangordnung von Bedeutungen, in der sie die Aura oder Tätigkeit göttlicher Wesen anzeigen, wie Krishna, Mahakali, Radha, oder auch anderer übermenschlicher Wesen; es gibt eine weitere Kategorie, in der sie die Aura um Objekte oder lebende Personen anzeigen – und hiermit ist die Reihe der Möglichkeiten noch nicht erschöpft.
<G-vec00060-001-s167><indicate.anzeigen><en> There is another order of significances in which they indicate the aura or the activity of divine beings, Krishna, Mahakali, Radha or else of other superhuman beings; there is another in which they indicate the aura around objects or living persons – and that does not exhaust the list of possibilities.
<G-vec00060-001-s168><indicate.anzeigen><de> Ein komplettes Blutbild durchgeführt werden wird, einschließlich einer chemischen Blutbild, ein komplettes Blutbild, und eine Urinanalyse — die Ergebnisse von denen das Vorhandensein von Stoffen, die möglicherweise die Ursache eine verlangsamte Herzfrequenz anzeigen kann.
<G-vec00060-001-s168><indicate.anzeigen><en> A complete blood profile will be conducted, including a chemical blood profile, a complete blood count, and a urinalysis — the results of which may indicate the presence of substances that might be causing a slowed heart rate.
<G-vec00060-001-s169><indicate.anzeigen><de> "Dieser Punkt ist erkennbar weil links Schilder sind, die die Wege beim Namen anzeigen, die Strecke in die man rechts abbiegt ist als ""Ameno"" benannt."
<G-vec00060-001-s169><indicate.anzeigen><en> This point is recognizable because on the left side of the path there are some signs that indicate the names of the trails.
<G-vec00060-001-s170><indicate.anzeigen><de> Die LEDs, die den Zustand des ganzen Systems anzeigen, befinden sich über dem Display.
<G-vec00060-001-s170><indicate.anzeigen><en> LEDs which indicate the status of the entire system have been provided above the keypad display.
<G-vec00060-001-s171><indicate.anzeigen><de> Wenn diesen Daten das Resultat, unten gezeigt geplottet, ein Verhältnis zwischen dem Preisniveau und der Menge des Geldumlaufs anzeigen Sie werden, welches hier durch die kumulativen Importe des Schatzes approximiert wird.
<G-vec00060-001-s171><indicate.anzeigen><en> When these data are plotted the result, shown below, indicate a relationship between the price level and the amount of money in circulation which is here approximated by the cumulative imports of treasure.
<G-vec00060-001-s172><indicate.anzeigen><de> "Wenn der Anwender Daten diesen Formats über das Fenster zieht, wird der Mauscursor anzeigen, dass die Daten hier abgelegt (""fallen gelassen"") werden können."
<G-vec00060-001-s172><indicate.anzeigen><en> When the user drags data of this format over the window, the cursor will indicate that the data can be dropped there.
<G-vec00060-001-s173><indicate.anzeigen><de> Schüler präsentieren stolz ihre ESA Nachweise welche die exakte Position der ISS anzeigen während die Programmierung im Weltall lief.
<G-vec00060-001-s173><indicate.anzeigen><en> Students proudly display their ESA certificates, which indicate the position of the ISS when their code was running in space.
<G-vec00060-001-s174><indicate.anzeigen><de> Verschiedene Stoffwechselprodukte von NMP und NEP können im Urin bestimmt werden und somit eine Belastung anzeigen.
<G-vec00060-001-s174><indicate.anzeigen><en> Various NMP and NEP metabolites can be tracked in urine and indicate exposure.
<G-vec00060-001-s175><indicate.anzeigen><de> 1 Schalt- und Überwachungseinheit mit Sicherungen, Motorschutzschalter, Vorwahl-Zählwerk zum Anzeigen der Fallzahl und zum Stillsetzen der Anlage.
<G-vec00060-001-s175><indicate.anzeigen><en> 1 switching and monitoring unit with fuses, protecting switch for the motor, preset able counter to indicate the number of falls and to switch off the unit.
<G-vec00060-001-s176><indicate.anzeigen><de> Diese Störung kennzeichnet die Personen wie die Gegenstände: Zum einen sind es dysfunktionale Versatzstücke der Mode (Schuhe ohne Absätze oder als sich um den Fuß zu schnallender Absatz), die die potenziellen TrägerInnen zu geradezu unmöglichen Haltungen und Bewegungen zwingen, zum anderen sind es die autistischen Rituale der filmischen Protagonisten angesichts eines Anderen, das Unerreichbar scheint, die diese Störung anzeigen.
<G-vec00060-001-s176><indicate.anzeigen><en> This disorder is characteristic of the individuals and of the objects: in one case it is the dysfunctional set pieces of fashion (shoes with no heels or a heel strapped around the ankle), that compel the potential wearers to perform practically impossible postures and movements; on the other hand, the autistic rituals of the film protagonist vis-Ã -vis the other, that appears unattainable, that indicate this disorder.
<G-vec00060-001-s177><indicate.anzeigen><de> Views sind temporäre Tabellen, die den gesamten oder teilweisen Inhalt einer oder mehrerer Tabellen anzeigen.
<G-vec00060-001-s177><indicate.anzeigen><en> Views are temporary tables which indicate the whole or partial contents of one or several tables.
<G-vec00060-001-s178><indicate.anzeigen><de> Der aktuelle Prototyp nutzt zwei Magnetfeldsensoren, welche die Position zuverlässig anzeigen, sobald sich die beiden Spulen auf einen Abstand von 1,5 Metern genähert haben.
<G-vec00060-001-s178><indicate.anzeigen><en> The current prototype uses two magnetic field sensors which indicate the position reliably as soon as the two coils approach each other to a distance of 1.5 meters.
<G-vec00060-001-s179><indicate.anzeigen><de> Aufklärung lieferte unser Guide, der uns durch Soweto führte: Jeder Stadtteil hat sein eigenes Handzeichen, mit dem die Fahrgäste anzeigen, in welche Richtung sie wollen.
<G-vec00060-001-s179><indicate.anzeigen><en> Our guide through Soweto explained it to us: Each suburb has its own hand signal, by which the passengers indicate which direction they want to go.
<G-vec00060-001-s180><indicate.anzeigen><de> Ich sollte auch erwähnen, dass bestimmte Handgesten Buchstaben des Alphabets und Zahlen anzeigen und zur Zeit Poussins verstanden worden wären.
<G-vec00060-001-s180><indicate.anzeigen><en> I should also mention that certain hand gestures indicate letters of the alphabet and numbers, and would have been understood at the time Poussin painted them.
<G-vec00060-001-s038><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s038><reveal.anzeigen><en> The benefits stacked up beside various other kinds of weight loss devices reveal this kind of ketone to be secure, organic and efficient with absolutely no side effects.
<G-vec00060-001-s039><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s039><reveal.anzeigen><en> The benefits accumulated beside several other kinds of weight loss devices reveal this type of ketone to be safe, natural and effective with no side effects.
<G-vec00060-001-s040><reveal.anzeigen><de> Kontrollkästchen, die in romanischen Sprachen lange Textbeschreibungen haben, die aufgrund des beschränkten Platzes abgeschnitten werden, kommen jetzt automatisch mit Tool-Tips daher, die den vollständigen Text anzeigen, wenn man mit dem Mauszeiger darüber verharrt.
<G-vec00060-001-s040><reveal.anzeigen><en> Check boxes with long text labels in Romance languages that get truncated because of the limited space available now automatically come with tooltips that reveal the complete text when hovering the mouse cursor over the control.
<G-vec00060-001-s041><reveal.anzeigen><de> Und er kann Allergie und Panik anzeigen.
<G-vec00060-001-s041><reveal.anzeigen><en> And it can reveal allergies and panic.
<G-vec00060-001-s042><reveal.anzeigen><de> Sie verraten außerdem eine Retouren-Adresse für Kunden weltweit und auch die von St. Lucia auf ihrer Webseite empfehlen, dass sie auf Saint Lucia oft Schiff sollten, wenn sie wirklich das Bedürfnis, eine separate Adresse für Saint Lucia anzeigen gibt.
<G-vec00060-001-s042><reveal.anzeigen><en> They additionally reveal a returns address for global consumers and those from Saint Lucia on their returns page, suggesting they must ship to Saint Lucia quite often if they really feel the need to reveal a separate address for Saint Lucia. They provide an explanation of just how much delivery prices linked with overseas delivery, so customers should not be fear of any type of extra hidden expenses.
<G-vec00060-001-s043><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s043><reveal.anzeigen><en> The benefits accumulated beside several other types of weight loss devices reveal this kind of ketone to be risk-free, organic and efficient with zero side effects.
<G-vec00060-001-s044><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s044><reveal.anzeigen><en> The benefits stacked up close to several other kinds of weight loss systems reveal this kind of ketone to be secure, all-natural and reliable with no side effects.
<G-vec00060-001-s045><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s045><reveal.anzeigen><en> The benefits accumulated next to several other sorts of weight loss devices reveal this kind of ketone to be safe, organic and reliable with zero side effects.
<G-vec00060-001-s046><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s046><reveal.anzeigen><en> The benefits accumulated beside various other kinds of weight loss devices reveal this type of ketone to be risk-free, natural and efficient with zero side effects.
<G-vec00060-001-s047><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s047><reveal.anzeigen><en> The benefits accumulated beside various other kinds of weight loss devices reveal this kind of ketone to be safe, organic and effective with absolutely no side effects.
<G-vec00060-001-s048><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s048><reveal.anzeigen><en> The benefits accumulated alongside other sorts of weight loss systems reveal this sort of ketone to be secure, all-natural and reliable with zero side effects.
<G-vec00060-001-s049><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s049><reveal.anzeigen><en> The benefits accumulated next to several other types of weight loss devices reveal this sort of ketone to be safe, organic and efficient with absolutely no side effects.
<G-vec00060-001-s050><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s050><reveal.anzeigen><en> The benefits accumulated beside various other kinds of weight loss devices reveal this sort of ketone to be secure, all-natural and reliable with absolutely no side effects.
<G-vec00060-001-s051><reveal.anzeigen><de> Fingerabdruck vom Tatort soll bald auch Drogenmissbrauch anzeigen.
<G-vec00060-001-s051><reveal.anzeigen><en> Fingerprints from the scene of the crime will soon reveal drug abuse.
<G-vec00060-001-s052><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s052><reveal.anzeigen><en> The benefits accumulated close to several other kinds of weight loss systems reveal this kind of ketone to be safe, organic and reliable with no side effects.
<G-vec00060-001-s053><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s053><reveal.anzeigen><en> The benefits stacked up next to various other sorts of weight loss systems reveal this sort of ketone to be secure, organic and efficient with zero side effects.
<G-vec00060-001-s054><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s054><reveal.anzeigen><en> The benefits accumulated alongside several other types of weight loss devices reveal this kind of ketone to be risk-free, all-natural and effective with zero side effects.
<G-vec00060-001-s055><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00060-001-s055><reveal.anzeigen><en> The benefits stacked up close to various other types of weight loss devices reveal this type of ketone to be risk-free, all-natural and reliable with absolutely no side effects.
<G-vec00060-001-s056><reveal.anzeigen><de> Bevor Panel-Daten anzeigen, ob der Launch oder Relaunch erfolgreich oder nicht erfolgreich verläuft, liefert dieses Testverfahren Klarheit über die Attraktivität des Produktes und mögliche Vorbehalte.
<G-vec00060-001-s056><reveal.anzeigen><en> Before panel data can reveal whether or not a launch or relaunch is going successfully, this quickly established and conducted procedure gives you clarity about the attractiveness of the product and potential reservations.
<G-vec00503-001-s038><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s038><reveal.anzeigen><en> The benefits stacked up beside various other kinds of weight loss devices reveal this kind of ketone to be secure, organic and efficient with absolutely no side effects.
<G-vec00503-001-s039><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s039><reveal.anzeigen><en> The benefits accumulated beside several other kinds of weight loss devices reveal this type of ketone to be safe, natural and effective with no side effects.
<G-vec00503-001-s040><reveal.anzeigen><de> Kontrollkästchen, die in romanischen Sprachen lange Textbeschreibungen haben, die aufgrund des beschränkten Platzes abgeschnitten werden, kommen jetzt automatisch mit Tool-Tips daher, die den vollständigen Text anzeigen, wenn man mit dem Mauszeiger darüber verharrt.
<G-vec00503-001-s040><reveal.anzeigen><en> Check boxes with long text labels in Romance languages that get truncated because of the limited space available now automatically come with tooltips that reveal the complete text when hovering the mouse cursor over the control.
<G-vec00503-001-s041><reveal.anzeigen><de> Und er kann Allergie und Panik anzeigen.
<G-vec00503-001-s041><reveal.anzeigen><en> And it can reveal allergies and panic.
<G-vec00503-001-s042><reveal.anzeigen><de> Sie verraten außerdem eine Retouren-Adresse für Kunden weltweit und auch die von St. Lucia auf ihrer Webseite empfehlen, dass sie auf Saint Lucia oft Schiff sollten, wenn sie wirklich das Bedürfnis, eine separate Adresse für Saint Lucia anzeigen gibt.
<G-vec00503-001-s042><reveal.anzeigen><en> They additionally reveal a returns address for global consumers and those from Saint Lucia on their returns page, suggesting they must ship to Saint Lucia quite often if they really feel the need to reveal a separate address for Saint Lucia. They provide an explanation of just how much delivery prices linked with overseas delivery, so customers should not be fear of any type of extra hidden expenses.
<G-vec00503-001-s043><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s043><reveal.anzeigen><en> The benefits accumulated beside several other types of weight loss devices reveal this kind of ketone to be risk-free, organic and efficient with zero side effects.
<G-vec00503-001-s044><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s044><reveal.anzeigen><en> The benefits stacked up close to several other kinds of weight loss systems reveal this kind of ketone to be secure, all-natural and reliable with no side effects.
<G-vec00503-001-s045><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s045><reveal.anzeigen><en> The benefits accumulated next to several other sorts of weight loss devices reveal this kind of ketone to be safe, organic and reliable with zero side effects.
<G-vec00503-001-s046><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s046><reveal.anzeigen><en> The benefits accumulated beside various other kinds of weight loss devices reveal this type of ketone to be risk-free, natural and efficient with zero side effects.
<G-vec00503-001-s047><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s047><reveal.anzeigen><en> The benefits accumulated beside various other kinds of weight loss devices reveal this kind of ketone to be safe, organic and effective with absolutely no side effects.
<G-vec00503-001-s048><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s048><reveal.anzeigen><en> The benefits accumulated alongside other sorts of weight loss systems reveal this sort of ketone to be secure, all-natural and reliable with zero side effects.
<G-vec00503-001-s049><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s049><reveal.anzeigen><en> The benefits accumulated next to several other types of weight loss devices reveal this sort of ketone to be safe, organic and efficient with absolutely no side effects.
<G-vec00503-001-s050><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s050><reveal.anzeigen><en> The benefits accumulated beside various other kinds of weight loss devices reveal this sort of ketone to be secure, all-natural and reliable with absolutely no side effects.
<G-vec00503-001-s051><reveal.anzeigen><de> Fingerabdruck vom Tatort soll bald auch Drogenmissbrauch anzeigen.
<G-vec00503-001-s051><reveal.anzeigen><en> Fingerprints from the scene of the crime will soon reveal drug abuse.
<G-vec00503-001-s052><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s052><reveal.anzeigen><en> The benefits accumulated close to several other kinds of weight loss systems reveal this kind of ketone to be safe, organic and reliable with no side effects.
<G-vec00503-001-s053><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s053><reveal.anzeigen><en> The benefits stacked up next to various other sorts of weight loss systems reveal this sort of ketone to be secure, organic and efficient with zero side effects.
<G-vec00503-001-s054><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s054><reveal.anzeigen><en> The benefits accumulated alongside several other types of weight loss devices reveal this kind of ketone to be risk-free, all-natural and effective with zero side effects.
<G-vec00503-001-s055><reveal.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00503-001-s055><reveal.anzeigen><en> The benefits stacked up close to various other types of weight loss devices reveal this type of ketone to be risk-free, all-natural and reliable with absolutely no side effects.
<G-vec00503-001-s056><reveal.anzeigen><de> Bevor Panel-Daten anzeigen, ob der Launch oder Relaunch erfolgreich oder nicht erfolgreich verläuft, liefert dieses Testverfahren Klarheit über die Attraktivität des Produktes und mögliche Vorbehalte.
<G-vec00503-001-s056><reveal.anzeigen><en> Before panel data can reveal whether or not a launch or relaunch is going successfully, this quickly established and conducted procedure gives you clarity about the attractiveness of the product and potential reservations.
<G-vec00332-001-s038><show.anzeigen><de> Schritt 3: Jetzt gelangen Sie in das Dialogfeld Mail Setup und klicken auf Profile anzeigen klicken.
<G-vec00332-001-s038><show.anzeigen><en> Step 3: Now you get into the Mail Setup dialog box, and click the Show Profiles button.
<G-vec00332-001-s039><show.anzeigen><de> Du kannst die Informationen, die wir zum Anzeigen von Promoted Pins und anderen Empfehlungen verwenden, wie folgt in deinen Einstellungen anpassen.
<G-vec00332-001-s039><show.anzeigen><en> You can adjust the info we use to show you Promoted Pins and other recommendations in your settings by following the instructions below.
<G-vec00332-001-s040><show.anzeigen><de> "Wenn die Signalspannung über 36V befindet, wird der LCD-Bildschirm-Symbol anzeigen "">>""."
<G-vec00332-001-s040><show.anzeigen><en> "When the signal voltage is over 36V, the LCD screen will show icon "">>'."
<G-vec00332-001-s041><show.anzeigen><de> Wenn alle Schichten sichtbar sind, sollte das Bildfenster nun unseren Text mit gelblicher Färbung in der Mitte und einem weich abgedunkeltem Rand anzeigen.
<G-vec00332-001-s041><show.anzeigen><en> If all of the layers are visible, the image box should now show our text with yellowish coloring to the center with a softly darkened border.
<G-vec00332-001-s042><show.anzeigen><de> Scrollen Sie ganz nach unten und klicken Sie auf Erweiterte Einstellungen anzeigen.
<G-vec00332-001-s042><show.anzeigen><en> Scroll down to the bottom and click Show advanced settings.
<G-vec00332-001-s043><show.anzeigen><de> Wenn Sie also alle Wechselbüros für die Richtung Bank Card USD sehen wollen -> Bitcoin Cashsehen möchten, klicken Sie auf „Alle anzeigen”.
<G-vec00332-001-s043><show.anzeigen><en> "So if you want to see all the exchangers for the direction Bank Card USD -> Bitcoin Cash, click the ""Show all""."
<G-vec00332-001-s044><show.anzeigen><de> "Konten mit dem Abonnementmodus ""Auf Anfrage"" ohne aktivierter Option ""In der Bewertung anzeigen""."
<G-vec00332-001-s044><show.anzeigen><en> Accounts with “By request” subscription mode without “Show in the Rating” option enabled.
<G-vec00332-001-s045><show.anzeigen><de> Wenn die Option 'Gruppen in Formatliste anzeigen' aktiviert ist, werden die Gruppennamen in den Formatlisten angezeigt (1).
<G-vec00332-001-s045><show.anzeigen><en> When the 'Show Groups in Format List' option is enabled, the group names will be displayed in the format lists (1) .
<G-vec00332-001-s046><show.anzeigen><de> Wenn in der Struktur der Elementtabelle Felddefinitionen angezeigt werden (Definition anzeigen), können Sie die Definitionen bearbeiten, indem Sie die Definition auswählen und eine Option aus der Auswahlliste der Definition auswählen (siehe Abbildung oben).
<G-vec00332-001-s046><show.anzeigen><en> When the element's table structure shows field definitions (Show Definition), the definitions can be edited by selecting the definition and selecting an option from the definition's combo box (see screenshot above).
<G-vec00332-001-s047><show.anzeigen><de> Dieser Controller verfügt über zwei Steuerknöpfe und zwei LEDs, die anzeigen, wenn jede Funktion aktiv ist.
<G-vec00332-001-s047><show.anzeigen><en> This controller features two control knobs and two Lights that show when each function is active.
<G-vec00332-001-s048><show.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00332-001-s048><show.anzeigen><en> The benefits stacked up alongside various other types of weight loss devices show this type of ketone to be secure, organic and effective with absolutely no side effects.
<G-vec00332-001-s049><show.anzeigen><de> Schaltfläche Begriffsebene des aktuellen Begriffs anzeigen: Zeigt zum ausgewählten Term eine Begriffsinformation (z.
<G-vec00332-001-s049><show.anzeigen><en> Show concept information button: Click to show the concept information for the selected term (e.g.
<G-vec00332-001-s050><show.anzeigen><de> LED-Fernseher (Bild anzeigen) Hier zeigen wir nur Produktbilder von Sponsor-Marken, die an Open Icecat teilnehmen, da Produktbilder dem Urheberrecht unterliegen können.
<G-vec00332-001-s050><show.anzeigen><en> (show image) Here, we only show product images of sponsoring brands that joined Open Icecat as product images can be subject to copyrights.
<G-vec00332-001-s051><show.anzeigen><de> Sie zeigen außerdem eine Retouren-Adresse für internationale Verbraucher wie auch die von Jan Mayen auf ihrer Webseite empfehlen, sie müssen sehr oft auf Jan Mayen Schiff, wenn sie wirklich das Gefühl gibt das sollte eine andere Adresse für Jan Mayen anzeigen.
<G-vec00332-001-s051><show.anzeigen><en> They additionally show a returns address for global consumers and those from Jan Mayen on their returns page, proposing they must ship to Jan Mayen quite often if they really feel the have to show a separate address for Jan Mayen.
<G-vec00332-001-s052><show.anzeigen><de> "Beispielsweise können wir deinen Freunden anzeigen, dass du an einer beworbenen Veranstaltung interessiert bist oder eine Seite mit ""Gefällt mir"" markiert hast, die von einer Marke erstellt worden ist, die uns dafür bezahlt hat, dass wir ihre Anzeigen auf Facebook zeigen."
<G-vec00332-001-s052><show.anzeigen><en> For example, we may show your friends that you are interested in an advertised event or have liked a Page created by a brand that has paid us to display its ads on Facebook.
<G-vec00332-001-s053><show.anzeigen><de> Ihr Bike Fähigkeiten auf die Spur anzeigen .
<G-vec00332-001-s053><show.anzeigen><en> Show your bike skills on the track.
<G-vec00332-001-s054><show.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00332-001-s054><show.anzeigen><en> The benefits accumulated close to other sorts of weight loss systems show this sort of ketone to be safe, natural and efficient with no side effects.
<G-vec00332-001-s055><show.anzeigen><de> Ohne jede Tutorials zu sprechen, dieser Ebene des Problems möglicherweise für einige lästige anzeigen..
<G-vec00332-001-s055><show.anzeigen><en> Without any tutorials to speak of, this level of problem might show annoying for some.
<G-vec00332-001-s056><show.anzeigen><de> Das Band ist in Tabulatoren eingeteilt, die aufeinander bezogene Funktionen gruppieren und sie zusammen anzeigen.
<G-vec00332-001-s056><show.anzeigen><en> The Ribbon is divided into tabs that group related functions and show them together.
<G-vec00358-001-s038><show.anzeigen><de> Schritt 3: Jetzt gelangen Sie in das Dialogfeld Mail Setup und klicken auf Profile anzeigen klicken.
<G-vec00358-001-s038><show.anzeigen><en> Step 3: Now you get into the Mail Setup dialog box, and click the Show Profiles button.
<G-vec00358-001-s039><show.anzeigen><de> Du kannst die Informationen, die wir zum Anzeigen von Promoted Pins und anderen Empfehlungen verwenden, wie folgt in deinen Einstellungen anpassen.
<G-vec00358-001-s039><show.anzeigen><en> You can adjust the info we use to show you Promoted Pins and other recommendations in your settings by following the instructions below.
<G-vec00358-001-s040><show.anzeigen><de> "Wenn die Signalspannung über 36V befindet, wird der LCD-Bildschirm-Symbol anzeigen "">>""."
<G-vec00358-001-s040><show.anzeigen><en> "When the signal voltage is over 36V, the LCD screen will show icon "">>'."
<G-vec00358-001-s041><show.anzeigen><de> Wenn alle Schichten sichtbar sind, sollte das Bildfenster nun unseren Text mit gelblicher Färbung in der Mitte und einem weich abgedunkeltem Rand anzeigen.
<G-vec00358-001-s041><show.anzeigen><en> If all of the layers are visible, the image box should now show our text with yellowish coloring to the center with a softly darkened border.
<G-vec00358-001-s042><show.anzeigen><de> Scrollen Sie ganz nach unten und klicken Sie auf Erweiterte Einstellungen anzeigen.
<G-vec00358-001-s042><show.anzeigen><en> Scroll down to the bottom and click Show advanced settings.
<G-vec00358-001-s043><show.anzeigen><de> Wenn Sie also alle Wechselbüros für die Richtung Bank Card USD sehen wollen -> Bitcoin Cashsehen möchten, klicken Sie auf „Alle anzeigen”.
<G-vec00358-001-s043><show.anzeigen><en> "So if you want to see all the exchangers for the direction Bank Card USD -> Bitcoin Cash, click the ""Show all""."
<G-vec00358-001-s044><show.anzeigen><de> "Konten mit dem Abonnementmodus ""Auf Anfrage"" ohne aktivierter Option ""In der Bewertung anzeigen""."
<G-vec00358-001-s044><show.anzeigen><en> Accounts with “By request” subscription mode without “Show in the Rating” option enabled.
<G-vec00358-001-s045><show.anzeigen><de> Wenn die Option 'Gruppen in Formatliste anzeigen' aktiviert ist, werden die Gruppennamen in den Formatlisten angezeigt (1).
<G-vec00358-001-s045><show.anzeigen><en> When the 'Show Groups in Format List' option is enabled, the group names will be displayed in the format lists (1) .
<G-vec00358-001-s046><show.anzeigen><de> Wenn in der Struktur der Elementtabelle Felddefinitionen angezeigt werden (Definition anzeigen), können Sie die Definitionen bearbeiten, indem Sie die Definition auswählen und eine Option aus der Auswahlliste der Definition auswählen (siehe Abbildung oben).
<G-vec00358-001-s046><show.anzeigen><en> When the element's table structure shows field definitions (Show Definition), the definitions can be edited by selecting the definition and selecting an option from the definition's combo box (see screenshot above).
<G-vec00358-001-s047><show.anzeigen><de> Dieser Controller verfügt über zwei Steuerknöpfe und zwei LEDs, die anzeigen, wenn jede Funktion aktiv ist.
<G-vec00358-001-s047><show.anzeigen><en> This controller features two control knobs and two Lights that show when each function is active.
<G-vec00358-001-s048><show.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00358-001-s048><show.anzeigen><en> The benefits stacked up alongside various other types of weight loss devices show this type of ketone to be secure, organic and effective with absolutely no side effects.
<G-vec00358-001-s049><show.anzeigen><de> Schaltfläche Begriffsebene des aktuellen Begriffs anzeigen: Zeigt zum ausgewählten Term eine Begriffsinformation (z.
<G-vec00358-001-s049><show.anzeigen><en> Show concept information button: Click to show the concept information for the selected term (e.g.
<G-vec00358-001-s050><show.anzeigen><de> LED-Fernseher (Bild anzeigen) Hier zeigen wir nur Produktbilder von Sponsor-Marken, die an Open Icecat teilnehmen, da Produktbilder dem Urheberrecht unterliegen können.
<G-vec00358-001-s050><show.anzeigen><en> (show image) Here, we only show product images of sponsoring brands that joined Open Icecat as product images can be subject to copyrights.
<G-vec00358-001-s051><show.anzeigen><de> Sie zeigen außerdem eine Retouren-Adresse für internationale Verbraucher wie auch die von Jan Mayen auf ihrer Webseite empfehlen, sie müssen sehr oft auf Jan Mayen Schiff, wenn sie wirklich das Gefühl gibt das sollte eine andere Adresse für Jan Mayen anzeigen.
<G-vec00358-001-s051><show.anzeigen><en> They additionally show a returns address for global consumers and those from Jan Mayen on their returns page, proposing they must ship to Jan Mayen quite often if they really feel the have to show a separate address for Jan Mayen.
<G-vec00358-001-s052><show.anzeigen><de> "Beispielsweise können wir deinen Freunden anzeigen, dass du an einer beworbenen Veranstaltung interessiert bist oder eine Seite mit ""Gefällt mir"" markiert hast, die von einer Marke erstellt worden ist, die uns dafür bezahlt hat, dass wir ihre Anzeigen auf Facebook zeigen."
<G-vec00358-001-s052><show.anzeigen><en> For example, we may show your friends that you are interested in an advertised event or have liked a Page created by a brand that has paid us to display its ads on Facebook.
<G-vec00358-001-s053><show.anzeigen><de> Ihr Bike Fähigkeiten auf die Spur anzeigen .
<G-vec00358-001-s053><show.anzeigen><en> Show your bike skills on the track.
<G-vec00358-001-s054><show.anzeigen><de> Die Vorteile, die neben anderen Systemtypen Gewicht Verlust gestapelt anzeigen dieser Art von Keton, sichere, natürliche und wirksame mit NULL Nebenwirkungen.
<G-vec00358-001-s054><show.anzeigen><en> The benefits accumulated close to other sorts of weight loss systems show this sort of ketone to be safe, natural and efficient with no side effects.
<G-vec00358-001-s055><show.anzeigen><de> Ohne jede Tutorials zu sprechen, dieser Ebene des Problems möglicherweise für einige lästige anzeigen..
<G-vec00358-001-s055><show.anzeigen><en> Without any tutorials to speak of, this level of problem might show annoying for some.
<G-vec00358-001-s056><show.anzeigen><de> Das Band ist in Tabulatoren eingeteilt, die aufeinander bezogene Funktionen gruppieren und sie zusammen anzeigen.
<G-vec00358-001-s056><show.anzeigen><en> The Ribbon is divided into tabs that group related functions and show them together.
<G-vec00060-001-s181><indicate.anzeigen><de> Bei diesen Prozessen, und wie die bisher diskutierte Kunst anzeigt, geht es dabei immer wieder um die Frage, was diese Umwandlungsprozesse für die Menschen bedeuten und was für Subjekte sie hervorbringen.
<G-vec00060-001-s181><indicate.anzeigen><en> As the works of art discussed above indicate, these processes are repeatedly concerned with the question of what these processes of transformation mean for humans and what kinds of subjects they produce.
<G-vec00060-001-s182><indicate.anzeigen><de> Wenn wir zur Sonne hinsehen, dann können wir nichts bemerken, was eine solche Rotation anzeigt, genau weil es keine leicht sichtbare Merkmale auf der Oberfläche der Sonne gibt.
<G-vec00060-001-s182><indicate.anzeigen><en> When we look at the sun, then we cannot notice something, which would indicate such a rotation, exactly because there are no easily visible features on the surface of the sun.
<G-vec00060-001-s183><indicate.anzeigen><de> Das Firmware Update könnte noch etwas optimiert werden, da die Software keinen durchgehenden Status anzeigt.
<G-vec00060-001-s183><indicate.anzeigen><en> The Firmware update software could be optimized some more, since the software does not indicate a continuously status.
<G-vec00060-001-s184><indicate.anzeigen><de> Leber-Enzym worths wird sicherlich mit der Nutzung zu verbessern, die während dies Schäden anzeigt es Angst macht vorschlagen, die zu Schäden führen könnte.
<G-vec00060-001-s184><indicate.anzeigen><en> Liver enzyme worths will certainly enhance with use, which while this does not indicate damage it does show tension that could lead to damages.
<G-vec00060-001-s185><indicate.anzeigen><de> 1983 präsentiert Blancpain mit dem kleinsten Automatikuhrwerk, das Mondphasen, Tag, Monat und Datum anzeigt, eine Weltneuheit und rückt damit eine bis dahin weitgehend in Vergessenheit geratene Komplikation in den Mittelpunkt.
<G-vec00060-001-s185><indicate.anzeigen><en> In 1983, Blancpain brought out a world first with the smallest self-winding movement to indicate moon phase, day, month and date, thereby bringing back a complication which had all but disappeared at the time.
<G-vec00060-001-s186><indicate.anzeigen><de> Obwohl Oxandrolone als mildeste anabole Steroide daran gedacht, anzeigt es nicht, dass es keine Nebenwirkungen hat.
<G-vec00060-001-s186><indicate.anzeigen><en> Although Oxandrolone is thought about as the mildest steroid stacks, it does not indicate that it has no side-effects.
<G-vec00060-001-s187><indicate.anzeigen><de> In einer idealen Situation ist es notwendig, das Arzneimittel nur nach Erhalt der Ergebnisse der Analysen zu verschreiben, was anzeigt, für welche speziellen Mittel die nachgewiesenen Mikroorganismen empfindlich sind.
<G-vec00060-001-s187><indicate.anzeigen><en> In an ideal situation, it is necessary to prescribe the drug only after receiving the results of the analyzes, which will indicate what particular agents the detected microorganisms are sensitive to.
<G-vec00060-001-s188><indicate.anzeigen><de> Wie man auf dem unteren Bild erkennen kann, sind die Hauptfarben Orange und Violett, was Negativität anzeigt.
<G-vec00060-001-s188><indicate.anzeigen><en> As one can see from the picture below, the main colours seen are orange and violet, which indicate negativity.
<G-vec00060-001-s189><indicate.anzeigen><de> Die Verwendung des Namens der Firma Aquapol ist hier lediglich ein Mittel, das anzeigt, dass eine andere Person als der Namensträger unabhängige Informationen über die Produkte der Firma gibt.
<G-vec00060-001-s189><indicate.anzeigen><en> The use of the name of the firm Aquapol is only a means to indicate that a person different from it gives independent information about it.
<G-vec00060-001-s190><indicate.anzeigen><de> Ich denke, dass es ziemlich offensichtlich war, dass die Seite für dein Telefon oder andere ähnliche Geräte gedacht ist, da der Name der Seite das verdammt nochmal anzeigt.
<G-vec00060-001-s190><indicate.anzeigen><en> I think that it was quite obvious that the site is meant for your phone, or other similar devices, since the name of the site does fucking indicate that.
<G-vec00060-001-s191><indicate.anzeigen><de> Die meisten Browser sind Cookies akzeptieren, aber Sie können Ihren Browser so einstellen, dass alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00060-001-s191><indicate.anzeigen><en> Most browsers are initially set up to accept cookies, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00060-001-s192><indicate.anzeigen><de> Einzig der leuchtend rote Aktivator-Knopf, der präzise anzeigt, an welchem Tisch man sitzt und welches Spiel man spielt, ist ein Pluspunkt.
<G-vec00060-001-s192><indicate.anzeigen><en> The one saving grace for them are the bright red activator buttons that indicate precisely which table you're at, and what game you're playing.
<G-vec00060-001-s193><indicate.anzeigen><de> Dabei muss sich die Frau einem Bluttest-Profil zu unterziehen, das die immunologische Umwelt ihres reproduktiven Systems anzeigt.
<G-vec00060-001-s193><indicate.anzeigen><en> It requires the woman to undergo a profile of blood tests that indicate the immunological environment within her reproductive system.
<G-vec00060-001-s194><indicate.anzeigen><de> Stellen Sie Ihren Browser alle Cookies, einschließlich Cookies mit unseren Dienstleistungen verbunden zu blockieren, oder anzeigt, wenn ein Cookie von uns gesetzten.
<G-vec00060-001-s194><indicate.anzeigen><en> Set your browser to block all cookies, including cookies associated with our services, or to indicate when a cookie is being set by us.
<G-vec00060-001-s195><indicate.anzeigen><de> Der Verband der Automobilingenieure hat eine Kategorisierung von Motorölen vorgenommen, die Viskosität (Zähflüssigkeit) und die Temperatur anzeigt, bei der Motoröl verwendet werden kann.
<G-vec00060-001-s195><indicate.anzeigen><en> The Society of Automotive Engineers has developed a categorization of motor oils which will indicate the viscosity (thickness) and temperature in which engine oil can be used.
<G-vec00060-001-s196><indicate.anzeigen><de> Der Indikator wird wahrscheinlich spätestens zum Launch implementiert und einem Wifi Symbol (wie auf eurem Mobiltelefon) ähneln, welches euch Stufenweise anzeigt ob eure Gruppenmitglieder in Reichweite sind oder nicht.
<G-vec00060-001-s196><indicate.anzeigen><en> The indicator will be probably implemented latest by launch and it will look similar to the Wifi Symbol (on your cell-phone) that will gradually indicate whether or not your party members are in range.
<G-vec00060-001-s197><indicate.anzeigen><de> Deaktivieren von Cookies Die meisten Browser sind standardmäßig so eingestellt, dass sie Cookies akzeptieren, aber Sie können Ihren Browser so einstellen, dass er alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird.
<G-vec00060-001-s197><indicate.anzeigen><en> Disabling cookies Most browsers are set to accept cookies by default, but you can reset your browser to refuse all cookies or to indicate when a cookie is being sent.
<G-vec00060-001-s198><indicate.anzeigen><de> Die App übermittelt diesen Mitschnitt an den Server, der einen Abgleich der Ist-Werte mit den Soll-Werten vornimmt und auf diese Weise Fehlfunktionen frühzeitig anzeigt.
<G-vec00060-001-s198><indicate.anzeigen><en> The app sends this recording to a server, which compares current values with target values and thus can indicate malfunctions early on.
<G-vec00060-001-s199><indicate.anzeigen><de> Parallel zur Strömungsrichtung dient ein Zeiger des Trägers, der die Position auf der Skala der Versuchsrinne anzeigt.
<G-vec00060-001-s199><indicate.anzeigen><en> Parallel to the flow, a pointer of the carrier is used to indicate the position on the scale of the experimental flume.
<G-vec00060-001-s238><indicate.anzeigen><de> * Die 2 Bilder der Chromversion sind verfügbar, um die Abmessungen anzuzeigen.
<G-vec00060-001-s238><indicate.anzeigen><en> * The 2 pictures of the chrome version are available to indicate the dimensions.
<G-vec00060-001-s239><indicate.anzeigen><de> Passagen in der Nähe vom Ende des Leviathan erschien, um anzuzeigen, dass Hobbes wollte seinen Frieden mit der englischen Regierung, die verärgert die Royalisten.
<G-vec00060-001-s239><indicate.anzeigen><en> Passages near the end of the Leviathan appeared to indicate that Hobbes was trying to make his peace with the English government, which angered the Royalists.
<G-vec00060-001-s240><indicate.anzeigen><de> Diese Methode hat einen booleschen Wert als Parameter, um anzuzeigen, ob Schaltflächen gezeichnet werden sollen oder nicht.
<G-vec00060-001-s240><indicate.anzeigen><en> This method takes a boolean as a parameter to indicate whether push buttons should be painted or not.
<G-vec00060-001-s241><indicate.anzeigen><de> Sie können Flair wählen Sie Ihre Nationalität, um anzuzeigen, durch Bearbeiten oben klicken.
<G-vec00060-001-s241><indicate.anzeigen><en> You can select flair to indicate your nationality by clicking edit above.
<G-vec00060-001-s242><indicate.anzeigen><de> Liste der Geräte: Mit nur verschiedenen Videorecorder Fügen Sie die IP-Adresse des Recorders und Bearbeiten von Videorecordern bereits hinzugefügt anzuzeigen.
<G-vec00060-001-s242><indicate.anzeigen><en> List of Devices: Add different video recorders with only indicate the IP address of the recorder and edit video recorders already added.
<G-vec00060-001-s243><indicate.anzeigen><de> "Halten Sie gleichzeitig Ihre Hand, um die universelle Geste ""Stopp / Stopp / Nein"" anzuzeigen."
<G-vec00060-001-s243><indicate.anzeigen><en> "At the same time, hold your hand to indicate the universal gesture of ""stop / halt / no""."
<G-vec00060-001-s244><indicate.anzeigen><de> Dieses Foto scheint eine Art 'Blockade' durch Frank anzuzeigen, aber sie war minimal.
<G-vec00060-001-s244><indicate.anzeigen><en> This photo seems to indicate some level of blockage on Frank's side, but it was minimal.
<G-vec00060-001-s245><indicate.anzeigen><de> Das Muster auf ihm scheint, anzuzeigen, daя es von der westlichen Periode Zhou (1100 BC bis 770 BC) entstehen kann.
<G-vec00060-001-s245><indicate.anzeigen><en> The pattern on this replica seems to indicate that it may originate from the Western Zhou period (1100 BC to 770 BC).
<G-vec00060-001-s246><indicate.anzeigen><de> Das Team-Namen sind auf dem Board, um schriftliche und eine 0 platziert neben jedem Namen auf den aktuellen Spielstand anzuzeigen.
<G-vec00060-001-s246><indicate.anzeigen><en> The team names are written on the board in order and a 0 placed next to each name to indicate the current score.
<G-vec00060-001-s247><indicate.anzeigen><de> Da ein höheres Hoch und ein höheres Tief gebildet wurden, wurde Block 1 blau gekennzeichnet, um seine stark bullische Tendenz anzuzeigen.
<G-vec00060-001-s247><indicate.anzeigen><en> Since a higher high and a higher low were created, Block 1 has been labeled in blue to indicate its strong bullish bias.
<G-vec00060-001-s248><indicate.anzeigen><de> Erhöhte Konkurrenz, Produktdiversifizierung Linien scheinen, anzuzeigen, dass diese Abbildungen fortfahren, sich aufwärts zu bewegen.
<G-vec00060-001-s248><indicate.anzeigen><en> Increased competition, diversification of product lines seem to indicate that these figures will continue to move upward.
<G-vec00060-001-s249><indicate.anzeigen><de> Bei VMware®- oder Hyper-V®-Instanzen färben sich nur numerische Werte rot, um die Überlastung anzuzeigen.
<G-vec00060-001-s249><indicate.anzeigen><en> For VMware® or Hyper-V® instances, only the numerical values turn red to indicate over allocation.
<G-vec00060-001-s250><indicate.anzeigen><de> "Der Backslash ""\"" läßt sich als letztes Zeichen in einer Zeile dazu verwenden, die Fortsetzung der Direktive in der nächsten Zeile anzuzeigen."
<G-vec00060-001-s250><indicate.anzeigen><en> "The backslash ""\"" may be used as the last character on a line to indicate that the directive continues onto the next line."
<G-vec00060-001-s251><indicate.anzeigen><de> Diese Informationen können kooperieren in ihren künstlerischen Schöpfungen zu durchdringen und versuchen, die Geheimnisse zu entwirren, dass sie vererben, und auch, um anzuzeigen, dass Blake große Aufmerksamkeit für die menschliche Intuition hatte, anzeigen, einschließlich, sofort aus dem Grunde, dass während der historischen Zeit herrschte in der er lebte.
<G-vec00060-001-s251><indicate.anzeigen><en> This information can cooperate to penetrate in their artistic creations and try to unravel the mysteries that they bequeath, and also to indicate that Blake had great attention to human intuition, showing, including, right away from the reason that prevailed during the historical period in which he lived.
<G-vec00060-001-s252><indicate.anzeigen><de> Dieses Produkt wurde gemäß den Anforderungen von CE hergestellt, um die Konformität mit der grundlegenden Gesundheit und Sicherheit anzuzeigen.
<G-vec00060-001-s252><indicate.anzeigen><en> This product was produced under the requirements of CE to indicate conformity with the essential health and safety.
<G-vec00060-001-s253><indicate.anzeigen><de> Wenn Sie eingeben '2013 / 03 / 21 In eine Zelle wird dieser Apostroph vor dem Datum verwendet, um Excel anzuzeigen, dass der Wert in der Zelle ein Textwert ist (siehe folgenden Screenshot).
<G-vec00060-001-s253><indicate.anzeigen><en> When you input '2013/03/21 into a cell, that apostrophe before the date is used to indicate to Excel that the value in the cell is text value (see following screenshot).
<G-vec00060-001-s254><indicate.anzeigen><de> Das Kreuz steht für den Pakt mit den Menschen in den vier Gestalten ansehen, Personifikationen der Theologie, Literatur, Wissenschaft, und Kunst, zu dem greifen sie die Kinder der neuen Dämonen war, während eine Schar von Kritzeleien unerklärlich, lebendige Farben, Es erinnert an die geheimnisvolle Warten auf Rettung, als Embryonen bei der jungen Generation, um anzuzeigen, dass nichts verloren geht.
<G-vec00060-001-s254><indicate.anzeigen><en> The cross represents the pact with men in the four figures contemplating, personifications of Theology, literature, science, and art, to which they attack the children of the new demons was, while a bevy of doodles inexplicable, vibrant color, It evokes the mysterious waiting for salvation, as embryos related to new generations, to indicate that nothing is lost.
<G-vec00060-001-s255><indicate.anzeigen><de> Nirgendwo im Heiligen Evangelium und zu jeder Zeit seiner Verkündigung, das fleischgewordene Wort Gott hat gesagt, dass viele einladender und barmherzig zu sein, die moralische Unordnung zu empfangen und zu legitimieren, oder dass Sie Angst zu haben, zu nennen und die moralische Störung als solche, um anzuzeigen,, Bewegen auf falschen Vorwänden der Barmherzigkeit und die Falschakzeptanz.
<G-vec00060-001-s255><indicate.anzeigen><en> Nowhere in the Holy Gospel and at any time of His preaching, the Incarnate Word of God has ever said that to be welcoming and merciful to accommodate and legitimize the moral disorder, or that you have to be afraid to call and to indicate the moral disorder as such, moving on false pretexts of mercy and false acceptance.
<G-vec00060-001-s256><indicate.anzeigen><de> Wird verwendet, um das Ende irgendwelcher Medien, zum Beispiel das Ende eines Bandlaufwerks, anzuzeigen.
<G-vec00060-001-s256><indicate.anzeigen><en> Used to indicate the end of some media, for example the end of a tape drive
<G-vec00358-001-s057><show.anzeigen><de> Sie wurde herausgebracht, um Werbeanzeigen anzuzeigen, weil Super Web LLC, der Herausgeber von Cyti Web, Geld für Pay-per-Click-Websites erhält.
<G-vec00358-001-s057><show.anzeigen><en> It has been released in order to show advertisements because Super Web LLC, which is the publisher of Cyti Web, receives money from pay-per-click websites.
<G-vec00358-001-s058><show.anzeigen><de> Die Karte verzweigt dann in separate Zellen, um Details oder Beispiele für das Thema anzuzeigen.
<G-vec00358-001-s058><show.anzeigen><en> The map then branches out into separate cells to show details or examples of the topic.
<G-vec00358-001-s059><show.anzeigen><de> Man kann jetzt bei Desktop-Browsern das Bild anklicken um die obere und untere Leiste anzuzeigen und auch auszublenden.
<G-vec00358-001-s059><show.anzeigen><en> You can now click the image in desktop browsers to show and also hide the top and bottom bars.
<G-vec00358-001-s060><show.anzeigen><de> Verwende deine Highlights zum einfachen Bearbeiten oder um die Sensorendaten in deinem finalen Clip anzuzeigen.
<G-vec00358-001-s060><show.anzeigen><en> Use your highlights for easy editing or to show sensor stats in your final video.
<G-vec00358-001-s061><show.anzeigen><de> Klicken Sie auf das Diagramm, um es anzuzeigen Diagrammwerkzeuge schwimmen Band, dann klick Layout > Achsen.
<G-vec00358-001-s061><show.anzeigen><en> Click the chart to show Chart Tools in the Ribbon, then click Layout > Axes.
<G-vec00358-001-s062><show.anzeigen><de> Ebenso verwenden wir die Geo-Lokalisierung, um Ihnen in unserem Online Shop die richtigen Produkte, Preise und Steuern Ihres jeweiligen Landes anzuzeigen.
<G-vec00358-001-s062><show.anzeigen><en> Further, we use geo localisation to show you the right products, prices and taxes of the respective country in our online shop.
<G-vec00358-001-s063><show.anzeigen><de> Sie können diese ausblenden, es kann jedoch sinnvoll sein, sie wieder anzuzeigen.
<G-vec00358-001-s063><show.anzeigen><en> You can switch them off, but it may be useful to show them again.
<G-vec00358-001-s064><show.anzeigen><de> Ziel ist es, die Seite, die Google als die Relevanteste für den Nutzer erachtet, ganz oben auf der Liste anzuzeigen.
<G-vec00358-001-s064><show.anzeigen><en> The aim is to show the page that Google perceives as most relevant to users at the top of the list.
<G-vec00358-001-s065><show.anzeigen><de> Sie können Total zu Ihrem Formular hinzufÃ1⁄4gen, um die Zusammenfassung der Zahlung anzuzeigen, bevor Benutzer auf Senden klicken.
<G-vec00358-001-s065><show.anzeigen><en> You can add Total to your form to show the summary of the payment before users press Submit.
<G-vec00358-001-s066><show.anzeigen><de> Hier zeige ich Ihnen eine Möglichkeit, das Thema über oder unter den Absendern in der E-Mail-Liste in Microsoft Outlook anzuzeigen.
<G-vec00358-001-s066><show.anzeigen><en> Here I will show you a way to show the subject above or below the senders in mails list in Microsoft Outlook.
<G-vec00358-001-s067><show.anzeigen><de> Wenn Sie Ergebnisse zuvor in absteigender Reihenfolge sortiert haben, müssen Sie erneut auf die Spaltenbezeichnung klicken, um die Sortierreihenfolge wieder umzukehren und den höchsten Ressourcenverbrauch oben in der Liste anzuzeigen.
<G-vec00358-001-s067><show.anzeigen><en> If you have previously sorted results in descending order, you must click the column label again to reverse the sort order and show the highest resource consumers at the top of the list.
<G-vec00358-001-s068><show.anzeigen><de> Ein Fenster wird geöffnet, um den Erstellungsprozess anzuzeigen.
<G-vec00358-001-s068><show.anzeigen><en> A window is opened to show the build progress.
<G-vec00358-001-s069><show.anzeigen><de> Dann erscheint die zweite Select Specific Cells, um anzuzeigen, wie viele Zellen ausgewählt sind.
<G-vec00358-001-s069><show.anzeigen><en> Then the second Select Specific Cells comes out to show how many cells are selected.
<G-vec00358-001-s070><show.anzeigen><de> Um die Anrufliste anzuzeigen, drehen Sie den Steuerungsknopf.
<G-vec00358-001-s070><show.anzeigen><en> Turn the rotary pushbutton to show the call list.
<G-vec00358-001-s071><show.anzeigen><de> Zu einer bestimmten Stelle im Musiktitel wechseln: Drücken Sie, wenn der Bildschirm „Sie hören“ angezeigt wird, auf die Touch-Oberfläche und streichen Sie dann nach unten, um die abgelaufene und verbleibende Zeit anzuzeigen.
<G-vec00358-001-s071><show.anzeigen><en> Move to a specific point in the song. On the Now Playing screen, press the Touch surface, then swipe down to show the elapsed and remaining time.
<G-vec00358-001-s072><show.anzeigen><de> Beispielsweise arbeitet unser Team intensiv daran, die Suchalgorithmen für Entdeckungen zu aktualisieren, um unsere Gastgeber zu unterstützen und Gästen die relevantesten Entdeckungen anzuzeigen.
<G-vec00358-001-s072><show.anzeigen><en> For example, our team is working hard to update experience search algorithms to support our hosts and show the most relevant experiences to guests.
<G-vec00358-001-s073><show.anzeigen><de> Du kannst die Seite filtern, um nur dann Sprechblasen anzuzeigen, wenn sich die Anzahl der Klicks in einem bestimmten Grenzbereich befindet.
<G-vec00358-001-s073><show.anzeigen><en> And you can filter the page, to show only bubbles above your set click threshold.
<G-vec00358-001-s074><show.anzeigen><de> Sie können folgendermaßen vorgehen, um die neue Artikelzeile in Outlook anzuzeigen.
<G-vec00358-001-s074><show.anzeigen><en> You can do as follows to show the new item row in Outlook.
<G-vec00358-001-s075><show.anzeigen><de> Füge den folgenden Link in einem Kommentar, eine Beschreibung oder eine Nachricht ein, um dieses Bild darin anzuzeigen.
<G-vec00358-001-s075><show.anzeigen><en> Hertha Götz Include in a comment, a description or a message to show this image.
<G-vec00060-001-s926><indicate.anzeigen><de> Alle unsere bisherigen Ergebnisse zeigen an, dass sich die Mine Bama für Ressourcenuntersuchungen und eine Bewertung ihres wirtschaftlichen Potenzials eignet.
<G-vec00060-001-s926><indicate.anzeigen><en> All of our results to date indicate that the Bama Mine is a candidate for resource testing and an evaluation of its economic potential.
<G-vec00060-001-s927><indicate.anzeigen><de> Relevante Entdeckungen zeigen auch an, dass es im Bereich die Marinestation von Knossos gab.
<G-vec00060-001-s927><indicate.anzeigen><en> Relevant findings also indicate that in the area there was the naval station of Knossos. Caves & Gorges
<G-vec00060-001-s928><indicate.anzeigen><de> Die Werte Nitrat (NO3) und Nitrit (NO2) zeigen an, ob die biologischen Reinigungsprozesse funktionieren.
<G-vec00060-001-s928><indicate.anzeigen><en> The nitrate (NO3) and nitrite (NO2) values indicate whether the biological cleaning processes are functioning efficiently.
<G-vec00060-001-s929><indicate.anzeigen><de> Gleichzeitig messen die Strohschüttlersensoren (Plattensensoren) den Verlust an den Schüttlern (dem Engpaß des Mähdrescherdurchsatzes) und zeigen an, dass die Strohschüttler überlastet sind – deshalb die Fahrt VERLANGSAMEN.
<G-vec00060-001-s929><indicate.anzeigen><en> For example, the straw walker sensors measure the loss from the straw walkers (the bottleneck of combine throughput) and indicate that the straw walkers canot keep up. In this instance, the operator should slow down.
<G-vec00060-001-s930><indicate.anzeigen><de> Die Farben in diesem Bild der Galaxie J090543.56+043347.3 zeigen an, ob und wie schnell sich das Gas in dem betreffenden Bereich der Galaxie auf uns zu oder von uns weg bewegt.
<G-vec00060-001-s930><indicate.anzeigen><en> Colours in this image of the galaxy J090543.56+043347.3 indicate whether there is gas moving towards us or away from us, and at what speed.
<G-vec00060-001-s931><indicate.anzeigen><de> Beobachtungen zeigen an, dass die Temperaturschwingung etwa 0,05 ° C beträgt und schwer zu erkennen ist.
<G-vec00060-001-s931><indicate.anzeigen><en> Observations indicate that the temperature oscillation is about 0.05 C and it is difficult to detect.
<G-vec00060-001-s932><indicate.anzeigen><de> Studien zeigen an, dass diese Chemikalie möglichen Gebrauch hat, wenn sie verbessert das Lipidprofil bei der Erhöhung von Muskelmass.
<G-vec00060-001-s932><indicate.anzeigen><en> Studies indicate that this chemical has potential use in improving the lipid profile while increasing muscle mass.
<G-vec00060-001-s933><indicate.anzeigen><de> Zählungen die während der letzten zwanzig Jahre gemacht wurden zeigen an, dass die Anzahl sich verringert.
<G-vec00060-001-s933><indicate.anzeigen><en> Counts made over the last twenty years indicate that their number is decreasing .
<G-vec00060-001-s934><indicate.anzeigen><de> Werte Ã1⁄4ber 50 zeigen Wachstum an.
<G-vec00060-001-s934><indicate.anzeigen><en> Any values above 50 indicate growth.
<G-vec00060-001-s935><indicate.anzeigen><de> Drei schwarze konzentrische Scheiben mit drei Indizes in Komplementärfarben zeigen klar die Stunden, Minuten und Sekunden an.
<G-vec00060-001-s935><indicate.anzeigen><en> Three concentric black discs marked with three index in contrasting colors indicate clearly the hours, minutes and seconds.
<G-vec00060-001-s936><indicate.anzeigen><de> Gemeinsam zeigen diese Planeten an, daß diese Beziehung vermutlich einen starken Einfluß auf die Denkweise der beiden Partner ausüben wird.
<G-vec00060-001-s936><indicate.anzeigen><en> These planets together indicate that this relationship is likely to have a strong effect on the way you both think.
<G-vec00060-001-s937><indicate.anzeigen><de> Versand-Benachrichtigungen zeigen an, dass das Paket versandt wurde.
<G-vec00060-001-s937><indicate.anzeigen><en> Ship notifications indicate that the shipment information has been sent to FedEx.
<G-vec00060-001-s938><indicate.anzeigen><de> Kontroll-LEDs zeigen unmittelbar die elektrische Funktionsfähigkeit aller Leiter an.
<G-vec00060-001-s938><indicate.anzeigen><en> Control LEDs immediately indicate the electrical operability of all conductors.
<G-vec00060-001-s939><indicate.anzeigen><de> Frühere Berichte, die von Besuchern der Insel aufgezeichnet wurden, zeigen an, dass den Statuen vom mythischen König Tuu Ku Ihu und dem Gott Make Make befohlen wurde, zu wandern.
<G-vec00060-001-s939><indicate.anzeigen><en> Earlier accounts recorded by visitors to the island indicate that statues were ordered to walk by the mythical King Tuu Ku Ihu and the god Make Make.
<G-vec00060-001-s940><indicate.anzeigen><de> Stoppschilder zeigen an, dass Sie vollständig anhalten müssen, bevor Sie weiterfahren.
<G-vec00060-001-s940><indicate.anzeigen><en> Stop signs indicate that you must come to a complete stop before giving way.
<G-vec00060-001-s941><indicate.anzeigen><de> Buchstaben und Zahlen auf der Außenseite zeigen an, in welcher Position Sie diesem Buchstaben bei der Betrachtung von dieser Seite aus begegnen (z.
<G-vec00060-001-s941><indicate.anzeigen><en> Letters and numbers on the outside indicate at what position you come across this letter when looking from that side (e.g.
<G-vec00060-001-s942><indicate.anzeigen><de> Das Vorhandensein von Anzeichen von Übelkeit, das Erbrechen, die Verdauungsstörung und die Diarrhöe zeigen die erhöhten Effekte auf den Magen an.
<G-vec00060-001-s942><indicate.anzeigen><en> The presence of symptoms of nausea, vomiting, indigestion, and diarrhea indicate the increased effects on the stomach. 12 units and above
<G-vec00060-001-s943><indicate.anzeigen><de> Mit Ihrer Nutzung der Websites zeigen Sie an, dass Sie diese Nutzungsbedingungen akzeptieren und damit einverstanden sind, sich an diese zu halten.
<G-vec00060-001-s943><indicate.anzeigen><en> By using the Websites, you indicate that you accept these terms of use and that you agree to abide by them.
<G-vec00060-001-s944><indicate.anzeigen><de> Verschiedene Größen der Freibeuter-Münzen zeigen den unterschiedlichen Wert des Piraten-Spielgeldes an.
<G-vec00060-001-s944><indicate.anzeigen><en> Different sizes of buccaneer coins indicate the different value of pirate play money.
<G-vec00060-001-s976><indicate.anzeigen><de> Rechts unten zeigt das Programm den maximalen Wert der Stromstärke an.
<G-vec00060-001-s976><indicate.anzeigen><en> The program will indicate the new value of the maximal amperage.
<G-vec00060-001-s977><indicate.anzeigen><de> Viele Fragen werden in jedem Abschnitt gefragt, und der Spieler muss das Jahr ein, diese Ereignisse - wenn der Spieler zeigt an, das genaue Jahr bekommen dann die maximale Punktzahl.
<G-vec00060-001-s977><indicate.anzeigen><en> Many questions will be asked in each section and the player must set the year, these events - if the player will indicate the exact year then get maximum points.
<G-vec00060-001-s978><indicate.anzeigen><de> Der Test zeigt bereits eine hCG (humanes Choriongonadotropin) Konzentration von 12 IU/L an und eignet sich daher für eine Anwendung bereits vor dem Ausbleiben der Periode (etwa zehn Tage nach dem Geschlechtsverkehr).
<G-vec00060-001-s978><indicate.anzeigen><en> The test can already indicate an hCG (human choriongonadotropine) concentration of 12 IU/L and is therefore suitable for use even before the period has stopped (about ten days after sexual intercourse).
<G-vec00060-001-s979><indicate.anzeigen><de> 17.4 Ein Linienrichter zeigt an, ob ein Federball „in“ oder „aus“ ist, bezogen auf die ihm zugewiesene(n) Linie(n).
<G-vec00060-001-s979><indicate.anzeigen><en> 17.4 A line judge shall indicate whether a shuttle landed `in' or `out' on the line(s) assigned.
<G-vec00060-001-s980><indicate.anzeigen><de> Sie zeigt jedoch an, von Wilber selbst, die umkämpfte - im Gegensatz zur einvernehmlichen - Situation der Entwicklungsforschung.
<G-vec00060-001-s980><indicate.anzeigen><en> But it does indicate, from Wilber himself, the embattled – as opposed to the consensual – situation of developmentalism.
<G-vec00060-001-s981><indicate.anzeigen><de> 7 Zeichenfeld 8 TOTAL/REMAIN – Zeigt die momentan angezeigte Disc/Trackinformation an (Seite 14).
<G-vec00060-001-s981><indicate.anzeigen><en> 7 Character display 8 TOTAL/REMAIN – Indicate the disc/track information currently displayed (page 14).
<G-vec00060-001-s982><indicate.anzeigen><de> Die CE Markierung besagt nicht, dass ein Produkt in einem EWR Land hergestellt wurde, sie zeigt lediglich an, dass ein Produkt bewertet wurde, bevor es auf den Markt gebracht wird und somit die Rechtlichen Anforderungen innerhalb d er EU erfüllt.
<G-vec00060-001-s982><indicate.anzeigen><en> CE marking does not indicate that a product was made in the EEA, but merely states that the product is assessed before being placed on the market and thus meets the EU legislative requirements .
<G-vec00060-001-s983><indicate.anzeigen><de> Sollte dies der Fall sein, zeigt Ihnen der Server an, dass nur eine Teilmenge des Ergebnisses zurückgeliefert wurde.
<G-vec00060-001-s983><indicate.anzeigen><en> If this occurs, the server will indicate that it has only returned a partial results set.
<G-vec00060-001-s984><indicate.anzeigen><de> Während es in der Forschung weit verbreitet ist, zeigt dieses Kriterium nicht Empfindlichkeit oder Schwere, wenn es in den ersten drei Tagen nach Anfang verwendet wird an und ist deshalb häufig nicht klinisch nÃ1⁄4tzlich.
<G-vec00060-001-s984><indicate.anzeigen><en> While it is widely used in research, this criterion does not indicate survivability or severity when used in the first three days after onset and is therefore often not clinically useful.
<G-vec00060-001-s985><indicate.anzeigen><de> Halten Sie Ihren GyroTwister einfach an´s Mikrofon und unsere Software zeigt Ihnen die aktuelle Umdrehungszahl, den Kraftindex und natürlich auch den Highscore an.
<G-vec00060-001-s985><indicate.anzeigen><en> Once active, just hold your GyroTwister close to the microphone and our software will indicate the current number of rotations, the strength index and the high score.
<G-vec00060-001-s986><indicate.anzeigen><de> Der Druck auf den ganzen Körper würde einem Druck auf das ganze innere Bewusstsein gleich kommen, vielleicht mit dem Ziel einer Modifikation oder Wandlung, die es für Wissen oder Erfahrung empfänglicher machen würde; die dritte oder vierte Rippe zeigt einen Bereich an, welcher zur vitalen Natur gehört, den Bereich der Lebenskraft – einen Druck zu einer Wandlung dort.
<G-vec00060-001-s986><indicate.anzeigen><en> The pressure on the whole body would mean a pressure on the whole inner consciousness, perhaps for some modification or change which would make it more ready for knowledge or experience; the third or fourth rib would indicate a region which belongs to the vital nature, the domain of the life-force, some pressure for a change there.
<G-vec00060-001-s987><indicate.anzeigen><de> Der Mond als Symbol in der Vision zeigt meist Spiritualität im Mental an oder ganz einfach das spirituelle Bewusstsein.
<G-vec00060-001-s987><indicate.anzeigen><en> It can also indicate the flow of spiritual Ananda (nectar is in the moon according to the old tradition).
<G-vec00060-001-s988><indicate.anzeigen><de> Dieser Test zeigt nur das Vorhandensein von Strep A Antigenen von sowohl lebensfähigen als auch nicht-lebensfähigen Gruppe A Streptococcus-Bakterien in Proben an.
<G-vec00060-001-s988><indicate.anzeigen><en> This test will only indicate the presence of Strep A antigen in the specimen from both viable and non-viable Group A Streptococcus bacteria.
<G-vec00060-001-s989><indicate.anzeigen><de> Der Anzugsmechanismus des Schuhs gibt also zwei Töne aus und ein dritter zeigt an, dass die Batterie schwach ist.
<G-vec00060-001-s989><indicate.anzeigen><en> So the shoe's tightening mechanism emits two tones, and a third to indicate that the battery is low.
<G-vec00060-001-s990><indicate.anzeigen><de> Die Produkte von MSR-Electronic sichern die Kältemittel-Überwachung in geschlossenen Räumen, bei denen Leckagen vorkommen können und zeigt die mögliche erhöhte Gaskonzentration in Echtzeit an.
<G-vec00060-001-s990><indicate.anzeigen><en> The products of MSR-Electronic ensure refrigerant monitoring in closed rooms where leaks can occur and indicate the possible increased gas concentration in real time.
<G-vec00060-001-s991><indicate.anzeigen><de> Die klar ablesbare Digitalanzeige der Kamera zeigt an, ob die Kamera gerade ausgerichtet ist und ermöglicht die Feinanpassung der horizontalen Ausrichtung während der Aufnahme.
<G-vec00060-001-s991><indicate.anzeigen><en> The camera's digital level gauge uses easy-to-read graphics to indicate clearly whether the camera is level and enables fine adjustment of horizontal alignment during shooting.
<G-vec00060-001-s992><indicate.anzeigen><de> Zeigt bei stromführenden Kabeln die tatsächliche Spannung an.
<G-vec00060-001-s992><indicate.anzeigen><en> On energized wires, the meter will indicate the real voltage.
<G-vec00060-001-s993><indicate.anzeigen><de> Gebrauch von dieser Web site zeigt an, dass Sie damit einverstanden sind, durch die Ausdrücke gesprungen zu werden.
<G-vec00060-001-s993><indicate.anzeigen><en> Use of this Website will indicate that you agree to be bound by the Terms.
<G-vec00060-001-s994><indicate.anzeigen><de> Daher zeigt der anfängliche Temperaturanstieg nicht an, dass das Antibiotikum nicht geeignet ist.
<G-vec00060-001-s994><indicate.anzeigen><en> Therefore, the initial increase in temperature does not indicate that the antibiotic is not suitable.
