<G-vec00231-001-s060><favor.bevorzugen><de> Als Teil dieser Aufgabe verfügt er über ein Prioritätenkonzept, das es ihm erlaubt, je nach Bedarf bestimmte Prozesse gegenüber anderen zu bevorzugen.
<G-vec00231-001-s060><favor.bevorzugen><en> As a part of this task, it has a concept of priority, which allows it to favor certain processes over others, as needed.
<G-vec00231-001-s061><favor.bevorzugen><de> hotels online booking best price guarantieed - - ihr Glaube an ihn, wie und ihre häufigen Versuche, ihn vorzubereiten, um zu bevorzugen durch Geschenke der großen Großartigkeit anges sport t. Nicht jeder könnte solche Spielraum wie Crcesus geben, um sicher zu sein.
<G-vec00231-001-s061><favor.bevorzugen><en> hotels online booking best price guarantieed - -their belief in it as inspired, and their frequent attempts to predispose it to favor by gifts of great magnificence. Not everybody could give such offerings as Crcesus, to be sure.
<G-vec00231-001-s062><favor.bevorzugen><de> Wir könnten auch einen gewissen Prozentsatz von Personen nennen, die nicht in allen jede Art von Anti-Viren-Software-Anwendung zu haben, bevorzugen.
<G-vec00231-001-s062><favor.bevorzugen><en> We could also mention some percentage of individuals who favor not to have any type of anti-virus software application in all.
<G-vec00231-001-s063><favor.bevorzugen><de> Die Wahl, welches Spiel zu spielen, ist offensichtlich (das Euro-Spiel spielen), es sei denn, Sie herausfinden, dass das Casino bestimmte Regeln hat, die die USA Spiel bevorzugen.
<G-vec00231-001-s063><favor.bevorzugen><en> The choice of which game to play is obvious (play the Euro game), unless you find out that the casino has specific rules which favor the USA game.
<G-vec00231-001-s064><favor.bevorzugen><de> Für alle Hauttypen empfohlen, insbesondere für Kundinnen, die eine leichte Struktur bevorzugen.
<G-vec00231-001-s064><favor.bevorzugen><en> Recommended for all skin types, in particular those we favor lightweight textures.
<G-vec00231-001-s065><favor.bevorzugen><de> Große Unternehmen bevorzugen Absolventen, die auf ihren Füßen und Ansatz Geschäftsprobleme aus einer Vielzahl von verschiedenen Perspektiven zu denken.
<G-vec00231-001-s065><favor.bevorzugen><en> Large companies favor graduates who can think on their feet and approach business problems from a variety of different perspectives.
<G-vec00231-001-s066><favor.bevorzugen><de> Der Abgeordnete kündigte Widerstand der AfD im Bundestag an, sollte der Bund den Verkehrsträger Elektro aus „ideologischen Gründen“ bevorzugen.
<G-vec00231-001-s066><favor.bevorzugen><en> "The deputy announced resistance of the AFD in the Bundestag, the federal government should favor the transport of electric ""ideological reasons""."
<G-vec00231-001-s067><favor.bevorzugen><de> Sogar mischende und zusammenpassende Systeme, um irgendjemandes eigene Position zu bevorzugen können viel Bestürzung verursachen.
<G-vec00231-001-s067><favor.bevorzugen><en> Even mixing and matching systems to favor one's own position can cause a great deal of consternation.
<G-vec00231-001-s068><favor.bevorzugen><de> Um in ihre Anliegen sind, eine wachsende Zahl von Frauen bevorzugen derzeit Jungs, die einen größeren Penis haben.
<G-vec00231-001-s068><favor.bevorzugen><en> To contribute to their worries, increasingly more females currently favor males that have a larger penis.
<G-vec00231-001-s069><favor.bevorzugen><de> Wenn Sie als Taucher viel reisen, Gewicht reduzieren oder einfach eine leichte Flosse bevorzugen, suchen Sie nicht weiter.
<G-vec00231-001-s069><favor.bevorzugen><en> If you are a traveling diver, looking to reduce weight or just favor a lightweight fin, look no further.
<G-vec00231-001-s070><favor.bevorzugen><de> Mit Ausnahme von Julian der Apostat, Constantine Neffe nachfolgenden römischen Kaiser weiterhin die christliche Religion zu bevorzugen.
<G-vec00231-001-s070><favor.bevorzugen><en> Except for Julian the Apostate, Constantine’s nephew, subsequent Roman emperors continued to favor the Christian religion.
<G-vec00231-001-s071><favor.bevorzugen><de> Die Idee war, dass Regierung nicht, braucht einen ausgeglichenen Etat zu haben in allen Jahren - da engstirnige Republikaner schienen zu bevorzugen - aber Ausgabe regulieren sollte, um Überflüsse der Konjunktur abzuschwächen.
<G-vec00231-001-s071><favor.bevorzugen><en> The idea was that government need not have a balanced budget in all years - as narrow-minded Republicans seemed to favor - but should regulate spending to mitigate excesses of the business cycle.
<G-vec00231-001-s072><favor.bevorzugen><de> Die gewählte Ausstattung ist schlicht, einfach und gleichzeitig elegant, die ideale Wahl für all jene, die den Komfort bei einem Aufenthalt im Hotel bevorzugen.
<G-vec00231-001-s072><favor.bevorzugen><en> The furnishings chosen are sober and simple yet elegant, the ideal choice for those who favor comfort when staying in a hotel.
<G-vec00231-001-s073><favor.bevorzugen><de> (Genese 12: 3) Wurden Christen folglich geraten, die Juden zu bevorzugen und zu helfen.
<G-vec00231-001-s073><favor.bevorzugen><en> (Genesis 12: 3) Christians were thus advised to favor and help the Jews.
<G-vec00231-001-s074><favor.bevorzugen><de> Der einzige Weg zu den Suchmaschinen, Ihre Website zu bevorzugen ist, Inhalte zu verwenden, das einzigartig und sehr gezielte.
<G-vec00231-001-s074><favor.bevorzugen><en> The only way to get the search engines to favor your site is to use content that’s unique and highly targeted.
<G-vec00231-001-s075><favor.bevorzugen><de> Das Gehirn beginnt deshalb, das andere Auge zu bevorzugen, das nicht schlechte Vision hat.
<G-vec00231-001-s075><favor.bevorzugen><en> The brain therefore starts to favor the other eye that does not have poor vision.
<G-vec00231-001-s076><favor.bevorzugen><de> Einige bevorzugen mehr Frauen mit großen Titten plus eine schlaffe Bauch.
<G-vec00231-001-s076><favor.bevorzugen><en> Some favor more women with large tits plus a flabby stomach.
<G-vec00231-001-s077><favor.bevorzugen><de> 2007-11-13 22:16:19 - Fliegen GEGEN Das Fahren Wenn Kraftstoffkosten so hoch sind, bevorzugen Leute Fliegen zum Fahren.
<G-vec00231-001-s077><favor.bevorzugen><en> 2007-11-13 22:16:19 - Flying vs driving When fuel costs are so high, people favor flying to driving.
<G-vec00231-001-s078><favor.bevorzugen><de> Bei unserer Anlage in malaysischen Aktien sind wir wählerisch und bevorzugen Konsumwerte, für die wir im Zuge dieser Trends langfristig Wachstum absehen.
<G-vec00231-001-s078><favor.bevorzugen><en> As investors in Malaysian equities, we are selective, and we favor consumer stocks because that is where we see growth in the long term in line with these trends.
<G-vec00231-001-s079><favor.bevorzugen><de> Zahlungsschutz funktioniert oft zum Nachteil von Unternehmen – Jeder, der mit PayPal oder seiner Schwesterfirma eBay eine Rückbuchung vorgenommen hat, weiß, dass der PayPal-Zahlungsschutz den Kunden gegenüber dem Unternehmen bevorzugt.
<G-vec00231-001-s079><favor.bevorzugen><en> Payment protection often works against businesses – Anyone who has faced a chargeback or returns with PayPal or their sister company eBay knows that PayPal payment protection tends to favor the customer over the business.
<G-vec00231-001-s080><favor.bevorzugen><de> Dann, wenn sich öffentliche Meinung ändert, erkennt die Person, dass die Meinung weniger bevorzugt ist.
<G-vec00231-001-s080><favor.bevorzugen><en> Then, if public sentiment changes, the person will recognize that the opinion is less in favor.
<G-vec00231-001-s081><favor.bevorzugen><de> Schon in der Planung und Entwicklung unserer Produkte werden umweltfreundliche Produktionsverfahren und Produkte bevorzugt, um Abfälle, Abwässer und Emissionen zu vermeiden oder zu reduzieren.
<G-vec00231-001-s081><favor.bevorzugen><en> We favor eco-friendly manufacturing methods and products that either avoid or reduce waste, waste water and emissions.
<G-vec00231-001-s082><favor.bevorzugen><de> Parallel dazu wird das Ministerium für öffentliche Arbeiten bei einer transparenten Ausschreibungspolitik unterstützt und angeregt, dass nationale Baufirmen bei der Auftragsvergabe bevorzugt werden.
<G-vec00231-001-s082><favor.bevorzugen><en> In a parallel process, the project is supporting the Ministry of Public Works in introducing transparent tendering policies which favor national construction companies.
<G-vec00231-001-s083><favor.bevorzugen><de> Heute werden Soft-Dog-Trainingsmethoden bevorzugt, mit denen Service- und Haushunde in verschiedenen Teams trainiert werden können.
<G-vec00231-001-s083><favor.bevorzugen><en> Today, soft dog training methods are in favor, which can be used to train service and domestic dogs to various teams
<G-vec00231-001-s084><favor.bevorzugen><de> Angreifer nutzen bevorzugt Standards, weil sie automatisierte Werkzeuge für ihre Angriffe nutzen.
<G-vec00231-001-s084><favor.bevorzugen><en> Attackers favor using defaults because they use automated tools for their attacks.
<G-vec00231-001-s085><favor.bevorzugen><de> Dabei wird man auch oft entscheiden müssen welches Ausstattungsdetail man einem anderen bevorzugt, da nicht alles miteinander erhältlich oder kombinierbar ist.
<G-vec00231-001-s085><favor.bevorzugen><en> In doing so you often have to decide which equipment detail you favor since not every one is available together or combinable.
<G-vec00231-001-s086><favor.bevorzugen><de> Wenn der voraussichtliche Geschworene sagt, daß er die Todesstrafe bevorzugt, wird der Staatsanwalt diesen Geschworenen befragen.
<G-vec00231-001-s086><favor.bevorzugen><en> But if the prospective juror says that they favor the death penalty, the prosecutor will question this juror.
