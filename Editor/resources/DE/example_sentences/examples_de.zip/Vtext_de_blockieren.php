<G-vec00081-001-s133><block.blockieren><de> Spyzie verfügt über eine benutzerfreundliche Oberfläche und ermöglicht es Ihnen, Apps auf dem Handy Ihres Kindes zu blockieren.
<G-vec00081-001-s133><block.blockieren><en> Spyzie has a user-friendly interface and allows you to block apps on your kid’s phone.
<G-vec00081-001-s134><block.blockieren><de> Vermeide es, auf dem Bauch zu schlafen, da dies die Atmung blockieren, Sodbrennen fördern und Stress verursachen kann.
<G-vec00081-001-s134><block.blockieren><en> Avoid sleeping on your stomach, since this can block breathing, promote acid reflux and cause stress.
<G-vec00081-001-s135><block.blockieren><de> "Apps blockieren Vergewissern Sie sich, dass sich die EIN / AUS-Taste in der rechten unteren Ecke im Status "" EIN"" befindet."
<G-vec00081-001-s135><block.blockieren><en> "Block Apps Make sure the ON/OFF button in the lower right corner is in ""ON "" status."
<G-vec00081-001-s136><block.blockieren><de> Wenn die autoplay-Option nicht für Sie arbeiten, können Sie möchten verwenden von Drittanbieter-tools statt zu blockieren autoplay auf YouTube.
<G-vec00081-001-s136><block.blockieren><en> If the autoplay switch is not working for you, you may want to use third-party tools instead to block autoplay on YouTube.
<G-vec00081-001-s137><block.blockieren><de> Ist hier ein Störsendergerät, das entwarf, die Handysignale und das WiFi-Signal zu blockieren, das 25W Telefon-WiFi-Signal-Störsender der hohen Leistung 3G mit äußerer abnehmbarer Stromversorgung genannt wird und Ihnen viel einmal helfen kann Sie, die Details über es wie folgt gewusst zu haben.
<G-vec00081-001-s137><block.blockieren><en> Here is a jammer device that designed to block the mobile phone signals and the WiFi signal which is named 25W High Power 3G Phone WiFi Signal Jammer with Outer Detachable Power Supply and can help you a lot once you have known the details as follows about it.
<G-vec00081-001-s138><block.blockieren><de> Kann leicht alle Adult und unbeschränkten Seiten jederzeit blockieren.
<G-vec00081-001-s138><block.blockieren><en> Can easily block all the adult and non-restricted pages anytime.
<G-vec00081-001-s139><block.blockieren><de> Diese Technik konzentriert sich auf das Tempo der Verlagerung Ihrer Stücke mit, keine Mühe zu schlagen oder zu blockieren gegnerischen Steine.
<G-vec00081-001-s139><block.blockieren><en> This technique concentrates on the pace of shifting your pieces with no efforts to hit or block your opponent’s checkers.
<G-vec00081-001-s140><block.blockieren><de> Sie können sogar E-Mail-Benachrichtigungen blockieren und Profile mit separaten Einschränkungseinstellungen erstellen.
<G-vec00081-001-s140><block.blockieren><en> You can even block email notifications and create profiles with separate restriction settings.
<G-vec00081-001-s141><block.blockieren><de> Nanobodies kann, um Krebs und andere Krankheiten, indem man Ligandempfänger Interaktionen, wie Bekämpfung von Faktor AntiVon Willebrand verwendet werden, um die Inbetriebnahme der Thrombose zu blockieren sperrt, oder das Sperren zu bekämpfen anti--TNF-a, um Arthritis zu behandeln.
<G-vec00081-001-s141><block.blockieren><en> Immune-based therapeutics Nanobodies can be used to combat cancer and other diseases by inhibiting ligand-receptor interactions, such as antagonizing anti-von Willebrand factor to block the initiation of thrombosis, or inhibiting anti-TNF-a to treat arthritis.
<G-vec00081-001-s142><block.blockieren><de> Sämtlichen Netzwerkverkehr blockieren – Blockiert den gesamten Netzwerkverkehr.
<G-vec00081-001-s142><block.blockieren><en> Block all network traffic – Blocks all network traffic.
<G-vec00081-001-s143><block.blockieren><de> Sie können den Einsatz solcher Cookies blockieren, indem Sie im Browser ein sogenanntes Ausschlusscookie setzen.
<G-vec00081-001-s143><block.blockieren><en> You can block the use of such cookies by creating an exclusion cookie.
<G-vec00081-001-s144><block.blockieren><de> ALS ist eine 50/50 Kombination aus R-Liponsäure in natürlicher Form und synthetischer S-Liponsäure - und die synthetische Form kann sogar die Aktivität von R-Liponsäure blockieren, was ein schwächeres Produkt ergibt.
<G-vec00081-001-s144><block.blockieren><en> ALA is a 50/50 combination of natural form r-lipoic and synthetic s-lipoic acid—and the synthetic form may actually block the activity of r-lipoic acid, resulting in a weaker product.
<G-vec00081-001-s145><block.blockieren><de> Es kann die Geräuschübertragung blockieren.
<G-vec00081-001-s145><block.blockieren><en> It can block the noise transmission.
<G-vec00081-001-s146><block.blockieren><de> Bei dieser Skulptur, es wäre schwierig, das Problem auf diese Weise, weil die dünnen Beine Teile der Skulptur würde zu schnell erstarren und blockieren die Ausfahrt Route für das geschmolzene Wachs Ansatz.
<G-vec00081-001-s146><block.blockieren><en> In the case of this sculpture it would be difficult to approach the problem in this manner because the thin leg portions of the sculpture would solidify too quickly and block the exit route for the molten wax.
<G-vec00081-001-s147><block.blockieren><de> Datei-Anti-Virus / Mail-Anti-Virus – im Abschnitt Aktion beim Fund einer Bedrohung wählen Sie Blockieren oder Desinfizieren .
<G-vec00081-001-s147><block.blockieren><en> File Anti-Virus and Mail Anti-Virus: in the section Action on threat detection, select Block or Disinfect .
<G-vec00081-001-s148><block.blockieren><de> Sie können die Einstellungen ändern, um Cookies zu blockieren oder Sie lassen sich warnen, wenn Cookies auf Ihr Gerät gesendet werden.
<G-vec00081-001-s148><block.blockieren><en> You can change the settings to block cookies or to alert you when cookies are being sent to your device.
<G-vec00081-001-s149><block.blockieren><de> Nach Auswahl der Option Anwendung einschränken erscheint ein Fenster, in dem Sie die Login-ID und das Passwort eingeben müssen, um den Blackberry-Browser oder die Webseite zu blockieren.
<G-vec00081-001-s149><block.blockieren><en> After selecting the restrict application option a window will appear where you have to fill the login id and password to block the blackberry browser or website.
<G-vec00081-001-s150><block.blockieren><de> "Wenn du nicht möchtest, dass soziale Netzwerke über aktive Plugins Daten über dich sammeln, kannst du entweder die Social Plugins einfach mit einem Klick auf unseren Webseiten deaktivieren oder in deinen Browser-Einstellungen die Funktion ""Cookies von Drittanbietern blockieren"" wählen."
<G-vec00081-001-s150><block.blockieren><en> "If you do not want social networks to collect data about you through active plugins, you can either simply deactivate the social plugins with one click on our web pages or select ""block third party cookies"" in your browser settings."
<G-vec00081-001-s151><block.blockieren><de> Neuere Versionen von Google Chrome blockieren diese Erweiterung, und es sollte ausreichen, einen Nachweis zu erkennen, dass nichts Gutes herauskommen kann VideoX.
<G-vec00081-001-s151><block.blockieren><en> Newer versions of Google Chrome block this extension and it should be enough of a proof to realize that nothing good can come out of VideoX.
<G-vec00367-001-s133><block.blockieren><de> Spyzie verfügt über eine benutzerfreundliche Oberfläche und ermöglicht es Ihnen, Apps auf dem Handy Ihres Kindes zu blockieren.
<G-vec00367-001-s133><block.blockieren><en> Spyzie has a user-friendly interface and allows you to block apps on your kid’s phone.
<G-vec00367-001-s134><block.blockieren><de> Vermeide es, auf dem Bauch zu schlafen, da dies die Atmung blockieren, Sodbrennen fördern und Stress verursachen kann.
<G-vec00367-001-s134><block.blockieren><en> Avoid sleeping on your stomach, since this can block breathing, promote acid reflux and cause stress.
<G-vec00367-001-s135><block.blockieren><de> "Apps blockieren Vergewissern Sie sich, dass sich die EIN / AUS-Taste in der rechten unteren Ecke im Status "" EIN"" befindet."
<G-vec00367-001-s135><block.blockieren><en> "Block Apps Make sure the ON/OFF button in the lower right corner is in ""ON "" status."
<G-vec00367-001-s136><block.blockieren><de> Wenn die autoplay-Option nicht für Sie arbeiten, können Sie möchten verwenden von Drittanbieter-tools statt zu blockieren autoplay auf YouTube.
<G-vec00367-001-s136><block.blockieren><en> If the autoplay switch is not working for you, you may want to use third-party tools instead to block autoplay on YouTube.
<G-vec00367-001-s137><block.blockieren><de> Ist hier ein Störsendergerät, das entwarf, die Handysignale und das WiFi-Signal zu blockieren, das 25W Telefon-WiFi-Signal-Störsender der hohen Leistung 3G mit äußerer abnehmbarer Stromversorgung genannt wird und Ihnen viel einmal helfen kann Sie, die Details über es wie folgt gewusst zu haben.
<G-vec00367-001-s137><block.blockieren><en> Here is a jammer device that designed to block the mobile phone signals and the WiFi signal which is named 25W High Power 3G Phone WiFi Signal Jammer with Outer Detachable Power Supply and can help you a lot once you have known the details as follows about it.
<G-vec00367-001-s138><block.blockieren><de> Kann leicht alle Adult und unbeschränkten Seiten jederzeit blockieren.
<G-vec00367-001-s138><block.blockieren><en> Can easily block all the adult and non-restricted pages anytime.
<G-vec00367-001-s139><block.blockieren><de> Diese Technik konzentriert sich auf das Tempo der Verlagerung Ihrer Stücke mit, keine Mühe zu schlagen oder zu blockieren gegnerischen Steine.
<G-vec00367-001-s139><block.blockieren><en> This technique concentrates on the pace of shifting your pieces with no efforts to hit or block your opponent’s checkers.
<G-vec00367-001-s140><block.blockieren><de> Sie können sogar E-Mail-Benachrichtigungen blockieren und Profile mit separaten Einschränkungseinstellungen erstellen.
<G-vec00367-001-s140><block.blockieren><en> You can even block email notifications and create profiles with separate restriction settings.
<G-vec00367-001-s141><block.blockieren><de> Nanobodies kann, um Krebs und andere Krankheiten, indem man Ligandempfänger Interaktionen, wie Bekämpfung von Faktor AntiVon Willebrand verwendet werden, um die Inbetriebnahme der Thrombose zu blockieren sperrt, oder das Sperren zu bekämpfen anti--TNF-a, um Arthritis zu behandeln.
<G-vec00367-001-s141><block.blockieren><en> Immune-based therapeutics Nanobodies can be used to combat cancer and other diseases by inhibiting ligand-receptor interactions, such as antagonizing anti-von Willebrand factor to block the initiation of thrombosis, or inhibiting anti-TNF-a to treat arthritis.
<G-vec00367-001-s142><block.blockieren><de> Sämtlichen Netzwerkverkehr blockieren – Blockiert den gesamten Netzwerkverkehr.
<G-vec00367-001-s142><block.blockieren><en> Block all network traffic – Blocks all network traffic.
<G-vec00367-001-s143><block.blockieren><de> Sie können den Einsatz solcher Cookies blockieren, indem Sie im Browser ein sogenanntes Ausschlusscookie setzen.
<G-vec00367-001-s143><block.blockieren><en> You can block the use of such cookies by creating an exclusion cookie.
<G-vec00367-001-s144><block.blockieren><de> ALS ist eine 50/50 Kombination aus R-Liponsäure in natürlicher Form und synthetischer S-Liponsäure - und die synthetische Form kann sogar die Aktivität von R-Liponsäure blockieren, was ein schwächeres Produkt ergibt.
<G-vec00367-001-s144><block.blockieren><en> ALA is a 50/50 combination of natural form r-lipoic and synthetic s-lipoic acid—and the synthetic form may actually block the activity of r-lipoic acid, resulting in a weaker product.
<G-vec00367-001-s145><block.blockieren><de> Es kann die Geräuschübertragung blockieren.
<G-vec00367-001-s145><block.blockieren><en> It can block the noise transmission.
<G-vec00367-001-s146><block.blockieren><de> Bei dieser Skulptur, es wäre schwierig, das Problem auf diese Weise, weil die dünnen Beine Teile der Skulptur würde zu schnell erstarren und blockieren die Ausfahrt Route für das geschmolzene Wachs Ansatz.
<G-vec00367-001-s146><block.blockieren><en> In the case of this sculpture it would be difficult to approach the problem in this manner because the thin leg portions of the sculpture would solidify too quickly and block the exit route for the molten wax.
<G-vec00367-001-s147><block.blockieren><de> Datei-Anti-Virus / Mail-Anti-Virus – im Abschnitt Aktion beim Fund einer Bedrohung wählen Sie Blockieren oder Desinfizieren .
<G-vec00367-001-s147><block.blockieren><en> File Anti-Virus and Mail Anti-Virus: in the section Action on threat detection, select Block or Disinfect .
<G-vec00367-001-s148><block.blockieren><de> Sie können die Einstellungen ändern, um Cookies zu blockieren oder Sie lassen sich warnen, wenn Cookies auf Ihr Gerät gesendet werden.
<G-vec00367-001-s148><block.blockieren><en> You can change the settings to block cookies or to alert you when cookies are being sent to your device.
<G-vec00367-001-s149><block.blockieren><de> Nach Auswahl der Option Anwendung einschränken erscheint ein Fenster, in dem Sie die Login-ID und das Passwort eingeben müssen, um den Blackberry-Browser oder die Webseite zu blockieren.
<G-vec00367-001-s149><block.blockieren><en> After selecting the restrict application option a window will appear where you have to fill the login id and password to block the blackberry browser or website.
<G-vec00367-001-s150><block.blockieren><de> "Wenn du nicht möchtest, dass soziale Netzwerke über aktive Plugins Daten über dich sammeln, kannst du entweder die Social Plugins einfach mit einem Klick auf unseren Webseiten deaktivieren oder in deinen Browser-Einstellungen die Funktion ""Cookies von Drittanbietern blockieren"" wählen."
<G-vec00367-001-s150><block.blockieren><en> "If you do not want social networks to collect data about you through active plugins, you can either simply deactivate the social plugins with one click on our web pages or select ""block third party cookies"" in your browser settings."
<G-vec00367-001-s151><block.blockieren><de> Neuere Versionen von Google Chrome blockieren diese Erweiterung, und es sollte ausreichen, einen Nachweis zu erkennen, dass nichts Gutes herauskommen kann VideoX.
<G-vec00367-001-s151><block.blockieren><en> Newer versions of Google Chrome block this extension and it should be enough of a proof to realize that nothing good can come out of VideoX.
<G-vec00081-001-s152><block.blockieren><de> Seitenzahl in der oberen linken Ecke, so dass Schneemänner, Schnee, mit ständigen Erosion kombiniert sollten sie für 30 Sekunden blockiert.
<G-vec00081-001-s152><block.blockieren><en> Page number in the upper left corner, making snowmen, snow, combined with permanent erosion should block them for 30 seconds.
<G-vec00081-001-s153><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00081-001-s153><block.blockieren><en> "If you do not want us to recognize your computer, please set your internet browser to ""Delete Cookies"" from your computer hard drive, to block cookies or to receive a warning before a cookie is stored."
<G-vec00081-001-s154><block.blockieren><de> Sie können Ihren Browser so einstellen, dass Cookies von Google Analytics blockiert werden.
<G-vec00081-001-s154><block.blockieren><en> You can set your browser to block cookies from Google Analytics.
<G-vec00081-001-s155><block.blockieren><de> Die Regierung setzt eine Blacklist durch, die bestimmte Domains mit illegalen Inhalten blockiert.
<G-vec00081-001-s155><block.blockieren><en> The Government enforces a blacklist of domains to block specific sites for illicit content.
<G-vec00081-001-s156><block.blockieren><de> Die Banner aus dieser Liste werden nicht von Anti-Banner blockiert.
<G-vec00081-001-s156><block.blockieren><en> Anti-Banner will not block banners from this list.
<G-vec00081-001-s157><block.blockieren><de> Bestimmte Webseiten wie Facebook, YouTube oder Online-Gaming-Seiten werden vom Netzwerk-Admin einfach per Firewall blockiert.
<G-vec00081-001-s157><block.blockieren><en> In some cases such networks block sites such as Facebook, YouTube or other social media or gaming sites.
<G-vec00081-001-s158><block.blockieren><de> 2 - Prüfen Sie, daß Ihr Browser (insbesondere Internet Explorer), das Downloaden nicht blockiert hat (eine Informationsleiste erscheint in oberem Teil des Browsers).
<G-vec00081-001-s158><block.blockieren><en> 2 - Please check that your Internet Browser (especially Internet Explorer) didn't block the download (if so, an Information Bar appears at the top part of your browser)
<G-vec00081-001-s159><block.blockieren><de> Positiv bleibt auch festzuhalten, dass die Nuklearwaffenstaaten diesen Minimalkonsens nicht blockiert haben.
<G-vec00081-001-s159><block.blockieren><en> On the positive side, it should be noted that the nuclear weapons states did not block this minimal consensus.
<G-vec00081-001-s160><block.blockieren><de> Sie können die Einstellungen Ihres Browsers so anpassen, dass Cookies, die von der Website (oder einer anderen Website im Internet) gesetzt werden, beschränkt oder blockiert werden.
<G-vec00081-001-s160><block.blockieren><en> You can adjust the settings in your browser in order to restrict or block cookies that are set by the Site (or any other site on the Internet).
<G-vec00081-001-s161><block.blockieren><de> Der Administrator kann dann entscheiden, ob die erkannte potenzielle Bedrohung blockiert werden soll, oder sie über die Option Ausnahme zu Richtlinie hinzufügen ausschließen.
<G-vec00081-001-s161><block.blockieren><en> The administrator can decide to block the potential detected threat or exclude it by selecting Add Exclusion to Policy .
<G-vec00081-001-s162><block.blockieren><de> Wir haben bereits sehr vieles erfolgreich blockiert.
<G-vec00081-001-s162><block.blockieren><en> We have managed to block so much.
<G-vec00081-001-s163><block.blockieren><de> Beispielsweise können Sie eine Regel so konfigurieren, dass sie ausdrücklich durch die Firewall ausgehenden Datenverkehr blockiert, jedoch denselben Datenverkehr zulässt, wenn er an andere Computer gesendet wird.
<G-vec00081-001-s163><block.blockieren><en> For example, you can configure a rule to explicitly block outbound traffic to a specific computer through the firewall but allow the same traffic to other computers.
<G-vec00081-001-s164><block.blockieren><de> Es hat jedoch empörte Guggulsterone der trainierbaren Ordnung unisom professional und av blockiert, die familiäre Vertreibungssperre reagierten, gewöhnt für Hypertonie.
<G-vec00081-001-s164><block.blockieren><en> However, there have outraged guggulsterones of trainable order unisom professional and av block, reacting familial expulsion block, acclimated for the spite of hypertension.
<G-vec00081-001-s165><block.blockieren><de> Wenn du aber besitzgierig bist, werden positive Rückmeldungen von Anderen blockiert.
<G-vec00081-001-s165><block.blockieren><en> Yet, if you are possessive, it tends to block positive response from others.
<G-vec00081-001-s166><block.blockieren><de> Ein weiterer Client, der versucht, auf die gesperrte Arbeitskopie zuzugreifen, blockiert für 10 Sekunden und bekommt dann einen Fehler.
<G-vec00081-001-s166><block.blockieren><en> A second client attempting to access a locked working copy will block for 10 seconds and then get an error.
<G-vec00081-001-s167><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00081-001-s167><block.blockieren><en> If you don't want us to recognize your computer, please configure your Internet browser to delete the cookies from your hard disk, block all cookies or warn you before a cookie is stored.
<G-vec00081-001-s168><block.blockieren><de> BOT blockiert die Verbindungen, die in einer normalen IPCop Installation erlaubt sind.
<G-vec00081-001-s168><block.blockieren><en> BOT will block all traffic that is allowed in a normal IPCop installation.
<G-vec00081-001-s169><block.blockieren><de> Falls Sie ein Werbebanner gefunden haben, das nicht von Adblock Plus blockiert wird, sollten Sie zuerst überprüfen, ob Sie die richtige Filterliste abonniert haben.
<G-vec00081-001-s169><block.blockieren><en> If you found an advertisement that Adblock Plus doesn't block, please check first whether you are using the right filter subscription .
<G-vec00081-001-s170><block.blockieren><de> Wenn die Eigentumsverhältnisse nicht der wirtschaftlichen Realität entsprechen, sollten grenzüberschreitende Zahlungen blockiert oder besteuert werden.
<G-vec00081-001-s170><block.blockieren><en> If the ownership structure does not correspond to economic reality, block or tax the cross-border payments.
<G-vec00367-001-s152><block.blockieren><de> Seitenzahl in der oberen linken Ecke, so dass Schneemänner, Schnee, mit ständigen Erosion kombiniert sollten sie für 30 Sekunden blockiert.
<G-vec00367-001-s152><block.blockieren><en> Page number in the upper left corner, making snowmen, snow, combined with permanent erosion should block them for 30 seconds.
<G-vec00367-001-s153><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00367-001-s153><block.blockieren><en> "If you do not want us to recognize your computer, please set your internet browser to ""Delete Cookies"" from your computer hard drive, to block cookies or to receive a warning before a cookie is stored."
<G-vec00367-001-s154><block.blockieren><de> Sie können Ihren Browser so einstellen, dass Cookies von Google Analytics blockiert werden.
<G-vec00367-001-s154><block.blockieren><en> You can set your browser to block cookies from Google Analytics.
<G-vec00367-001-s155><block.blockieren><de> Die Regierung setzt eine Blacklist durch, die bestimmte Domains mit illegalen Inhalten blockiert.
<G-vec00367-001-s155><block.blockieren><en> The Government enforces a blacklist of domains to block specific sites for illicit content.
<G-vec00367-001-s156><block.blockieren><de> Die Banner aus dieser Liste werden nicht von Anti-Banner blockiert.
<G-vec00367-001-s156><block.blockieren><en> Anti-Banner will not block banners from this list.
<G-vec00367-001-s157><block.blockieren><de> Bestimmte Webseiten wie Facebook, YouTube oder Online-Gaming-Seiten werden vom Netzwerk-Admin einfach per Firewall blockiert.
<G-vec00367-001-s157><block.blockieren><en> In some cases such networks block sites such as Facebook, YouTube or other social media or gaming sites.
<G-vec00367-001-s158><block.blockieren><de> 2 - Prüfen Sie, daß Ihr Browser (insbesondere Internet Explorer), das Downloaden nicht blockiert hat (eine Informationsleiste erscheint in oberem Teil des Browsers).
<G-vec00367-001-s158><block.blockieren><en> 2 - Please check that your Internet Browser (especially Internet Explorer) didn't block the download (if so, an Information Bar appears at the top part of your browser)
<G-vec00367-001-s159><block.blockieren><de> Positiv bleibt auch festzuhalten, dass die Nuklearwaffenstaaten diesen Minimalkonsens nicht blockiert haben.
<G-vec00367-001-s159><block.blockieren><en> On the positive side, it should be noted that the nuclear weapons states did not block this minimal consensus.
<G-vec00367-001-s160><block.blockieren><de> Sie können die Einstellungen Ihres Browsers so anpassen, dass Cookies, die von der Website (oder einer anderen Website im Internet) gesetzt werden, beschränkt oder blockiert werden.
<G-vec00367-001-s160><block.blockieren><en> You can adjust the settings in your browser in order to restrict or block cookies that are set by the Site (or any other site on the Internet).
<G-vec00367-001-s161><block.blockieren><de> Der Administrator kann dann entscheiden, ob die erkannte potenzielle Bedrohung blockiert werden soll, oder sie über die Option Ausnahme zu Richtlinie hinzufügen ausschließen.
<G-vec00367-001-s161><block.blockieren><en> The administrator can decide to block the potential detected threat or exclude it by selecting Add Exclusion to Policy .
<G-vec00367-001-s162><block.blockieren><de> Wir haben bereits sehr vieles erfolgreich blockiert.
<G-vec00367-001-s162><block.blockieren><en> We have managed to block so much.
<G-vec00367-001-s163><block.blockieren><de> Beispielsweise können Sie eine Regel so konfigurieren, dass sie ausdrücklich durch die Firewall ausgehenden Datenverkehr blockiert, jedoch denselben Datenverkehr zulässt, wenn er an andere Computer gesendet wird.
<G-vec00367-001-s163><block.blockieren><en> For example, you can configure a rule to explicitly block outbound traffic to a specific computer through the firewall but allow the same traffic to other computers.
<G-vec00367-001-s164><block.blockieren><de> Es hat jedoch empörte Guggulsterone der trainierbaren Ordnung unisom professional und av blockiert, die familiäre Vertreibungssperre reagierten, gewöhnt für Hypertonie.
<G-vec00367-001-s164><block.blockieren><en> However, there have outraged guggulsterones of trainable order unisom professional and av block, reacting familial expulsion block, acclimated for the spite of hypertension.
<G-vec00367-001-s165><block.blockieren><de> Wenn du aber besitzgierig bist, werden positive Rückmeldungen von Anderen blockiert.
<G-vec00367-001-s165><block.blockieren><en> Yet, if you are possessive, it tends to block positive response from others.
<G-vec00367-001-s166><block.blockieren><de> Ein weiterer Client, der versucht, auf die gesperrte Arbeitskopie zuzugreifen, blockiert für 10 Sekunden und bekommt dann einen Fehler.
<G-vec00367-001-s166><block.blockieren><en> A second client attempting to access a locked working copy will block for 10 seconds and then get an error.
<G-vec00367-001-s167><block.blockieren><de> Wenn Sie nicht möchten, dass wir Ihren Computer wiedererkennen, stellen Sie Ihren Internet-Browser bitte so ein, dass er Cookies von Ihrer Computerfestplatte löscht, alle Cookies blockiert oder Sie warnt, bevor ein Cookie gespeichert wird.
<G-vec00367-001-s167><block.blockieren><en> If you don't want us to recognize your computer, please configure your Internet browser to delete the cookies from your hard disk, block all cookies or warn you before a cookie is stored.
<G-vec00367-001-s168><block.blockieren><de> BOT blockiert die Verbindungen, die in einer normalen IPCop Installation erlaubt sind.
<G-vec00367-001-s168><block.blockieren><en> BOT will block all traffic that is allowed in a normal IPCop installation.
<G-vec00367-001-s169><block.blockieren><de> Falls Sie ein Werbebanner gefunden haben, das nicht von Adblock Plus blockiert wird, sollten Sie zuerst überprüfen, ob Sie die richtige Filterliste abonniert haben.
<G-vec00367-001-s169><block.blockieren><en> If you found an advertisement that Adblock Plus doesn't block, please check first whether you are using the right filter subscription .
<G-vec00367-001-s170><block.blockieren><de> Wenn die Eigentumsverhältnisse nicht der wirtschaftlichen Realität entsprechen, sollten grenzüberschreitende Zahlungen blockiert oder besteuert werden.
<G-vec00367-001-s170><block.blockieren><en> If the ownership structure does not correspond to economic reality, block or tax the cross-border payments.
