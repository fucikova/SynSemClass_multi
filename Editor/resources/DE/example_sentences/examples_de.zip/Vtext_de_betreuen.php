<G-vec00301-001-s414><attend.betreuen><de> TIGGES Rechtsanwälte betreuen Mandanten persönlich und individuell.
<G-vec00301-001-s414><attend.betreuen><en> TIGGES Rechtsanwälte attend to their clients personally and individually.
<G-vec00301-001-s415><attend.betreuen><de> Durch die 2011 gegründete Auslandsniederlassung bei Shanghai ist CSZ vor Ort und in Deutschland bestens aufgestellt, um westliche Kunden bei der Umsetzung Ihrer anspruchsvollen Bauvorhaben im Wachstumsland China zu betreuen.
<G-vec00301-001-s415><attend.betreuen><en> Through the 2011 established overseas branch near Shanghai CSZ is optimally positioned on the ground as well as in Germany to attend western clients when realizing their ambitious building project in growth country China.
<G-vec00301-001-s416><attend.betreuen><de> Interessierte Einzelhändler vermitteln wir gerne an engagierte Kunden von uns weiter, die sie ortsnah und individuell betreuen können.
<G-vec00301-001-s416><attend.betreuen><en> Interested retailers are gladly intermediated by us to our engaged customers, who are able to attend them locally and individually.
<G-vec00301-001-s417><attend.betreuen><de> Unsere norddeutschen Kunden betreuen wir aus Hamburg und Kiel.
<G-vec00301-001-s417><attend.betreuen><en> We attend to customers in northern Germany from our offices at Hamburg and Kiel.
<G-vec00301-001-s418><attend.betreuen><de> Unsere speziell dafür ausgebildeten Mitarbeiter-/innen betreuen Sie und pflegende Angehörige im Raum Bad Godesberg und Bonn diskret und zuverlässig.
<G-vec00301-001-s418><attend.betreuen><en> Our assistants are specially trained for this and attend you and your family carers discreetly and reliably within the region of Bad Godesberg and Bonn.
<G-vec00301-001-s419><attend.betreuen><de> KunstexpertInnen aus verschiedenen Ländern und Kontinenten erhalten die Einladung, auf der Basis einer vordefinierten Honorarstruktur KünstlerInnen, NaturwissenschaftlerInnen und GeisteswissenschaftlerInnen mit Beiträgen zum Projektthema zu betrauen und kuratorisch zu betreuen.
<G-vec00301-001-s419><attend.betreuen><en> Art experts from different countries and continents get the invitation to entrust artists, scientists and art scholars with contributions on the project’s topic and to attend to them as curators.
<G-vec00301-001-s420><attend.betreuen><de> Viele sprechen verschiedene Fremdsprachen, und insgesamt sind wir in der Lage, Eigenheimbesitzer und Käufer aus vielen Ländern zu betreuen, immer mit einem persönlichen Service und dem Fokus, die Ergebnisse zu erzielen, die Sie als Verkäufer oder Käufer – erwarten.
<G-vec00301-001-s420><attend.betreuen><en> Many speak different languages, and between us we are able to attend homeowners and buyers from many countries, always offering a personalised service focused on achieving the results you – as a vendor or a buyer – are looking for.
<G-vec00301-001-s421><attend.betreuen><de> Die Eigentümer, Familie Theile, betreuen die Gäste und vermitteln interressante Informationen über das Leben am Rande der Namibwüste.
<G-vec00301-001-s421><attend.betreuen><en> The owners, Family Theile, attend personally to the guests and provide interesting information about life at the edge of the Namib Desert.
<G-vec00301-001-s422><attend.betreuen><de> Kurzfristig können sich die Mitarbeiter bis zu zehn Tage freistellen lassen, um Familienmitglieder zuhause zu betreuen.
<G-vec00301-001-s422><attend.betreuen><en> Employees can take up to ten days of leave at short notice in order to attend to family members at home.
<G-vec00301-001-s423><attend.betreuen><de> Unsere Handelsvertreter betreuen Sie vor Ort und unterstützen unsere Vertriebsabteilung dabei, die optimale Lösung für Sie zu entwickeln.
<G-vec00301-001-s423><attend.betreuen><en> Our sales representatives attend you on site and support our sales department in developing the optimal solution for you.
<G-vec00301-001-s424><attend.betreuen><de> Vereinfachen Sie Ihre Lieferkette, indem Sie uns die Sorge um Ihre Hardware überlassen, während Sie sich auf Ihre Anwendung fokussieren und Ihre Kunden betreuen.
<G-vec00301-001-s424><attend.betreuen><en> Simplify your supply chain by letting us take care of your hardware while you focus on your application and attend to your customers.
<G-vec00301-001-s425><attend.betreuen><de> Wir betreuen unsere Kunden persönlich.
<G-vec00301-001-s425><attend.betreuen><en> We personally attend to our customers.
