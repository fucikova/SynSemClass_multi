<G-vec00418-001-s057><drop.ablegen><de> Von ihren Desktops aus können Mitarbeiter die Informationen, die auf der gemeinsamen Videowand angezeigt werden sollen, einfach ziehen und ablegen, um sie mit anderen Bedienern zu teilen.
<G-vec00418-001-s057><drop.ablegen><en> From their desktops, employees just drag and drop the information to be displayed on the collaborative video wall to share simultaneously with other operators.
<G-vec00418-001-s058><drop.ablegen><de> Ersetzen Sie es durch ein neues Bild, indem Sie eine Bilddatei in den Bereich auf der linken Seite laden oder ziehen und ablegen.
<G-vec00418-001-s058><drop.ablegen><en> To replace it with a new image, load or drag and drop a picture file onto the area on the left side.
<G-vec00418-001-s059><drop.ablegen><de> Definition [top] Der Eingangsordner ist ein spezieller Ordner in Ihren persönlichen Dokumenten, in dem die Mitglieder von Gruppen, denen Sie angehören, Dokumente ablegen können.
<G-vec00418-001-s059><drop.ablegen><en> Definition [top] The drop folder is a special folder in your private Documents, where the members of the groups you belong to may drop Documents.
<G-vec00418-001-s060><drop.ablegen><de> Beim Ablegen der Dateien werden Events erstellt (und die Mediendateien im Fenster Projektmedien hinzugefügt, wenn Sie den Explorer verwenden).
<G-vec00418-001-s060><drop.ablegen><en> Events are created where you drop the files (and the media files are added to the Project Media window if you're using the Explorer).
<G-vec00418-001-s061><drop.ablegen><de> Es ist nicht nur klug, um das Smartphone nur für den Fall in die Toilette zu halten unterstützt Sie es ablegen, sondern zusätzlich, ob es gestohlen und Sie haben aus der Ferne abwischen.
<G-vec00418-001-s061><drop.ablegen><en> It isn't only smart to keep the smartphone supported just in case you drop it within the toilet, but additionally whether it will get stolen and you've got to remotely wipe it clean.
<G-vec00418-001-s062><drop.ablegen><de> ie auf der Nuxeo Platform basierte CNG-Anwendung ermöglicht Journalisten die Zusammenstellung von Artikeln mit Texten, Fotos und Videos durch einfaches Ziehen und Ablegen.
<G-vec00418-001-s062><drop.ablegen><en> The Nuxeo Platform-based CNG application enables journalists to compile news stories using text, photos and/or videos by simply using drag and drop.
<G-vec00418-001-s063><drop.ablegen><de> Speichern Sie diese innerhalb SendBlaster, indem Sie das Programmsymbol auf den Abschnitt Verknüpfungen ziehen und ablegen.
<G-vec00418-001-s063><drop.ablegen><en> To save them within SendBlaster, simply drag and drop the program icon to the Shortcuts section.
<G-vec00418-001-s064><drop.ablegen><de> So ist es besser, zurück bringen und ablegen.
<G-vec00418-001-s064><drop.ablegen><en> That ́s better, bring it back and drop it.
<G-vec00418-001-s065><drop.ablegen><de> Wenn Sie es einmal etwas beschaulicher mögen, fahren Sie nach Gargnano und gönnen Sie sich an der Promenade neben dem Hafen einen Espresso oder Capucino und beobachten dabei, wie die Rundfahrtschiffe an- und ablegen.
<G-vec00418-001-s065><drop.ablegen><en> If you like it a bit more contemplative, head to Gargnano and treat yourself to an espresso or capucino on the promenade next to the harbor, watching the cruise ships take off and drop off.
<G-vec00418-001-s066><drop.ablegen><de> Du kannst auch die Pfeiltasten „Rechts“ und „Links“ zum Bewegen und die Leertaste oder die Pfeiltaste „Runter“ zum Ablegen eines Spielsteines benutzen.
<G-vec00418-001-s066><drop.ablegen><en> You can also use the arrow keys to move the token left or right, and the down or space key to drop a token.
<G-vec00418-001-s067><drop.ablegen><de> Hinweis: Werden Inhalte in nur einer Sprache angezeigt, können Sie Seiten an einen anderen Ort in der Seitenbaumstruktur verschieben, indem Sie sie ziehen und ablegen oder kopieren und einfügen, aber diese Seiten können nicht sortiert werden.
<G-vec00418-001-s067><drop.ablegen><en> When you show content in one language only, you can move pages to another location in the page tree structure by drag and drop or copy and paste, but it is not possible to sort pages.
<G-vec00418-001-s068><drop.ablegen><de> Selbst dann wirken die Qualitäten weiter und leiten die Körperfunktionen, bis wir unseren Träger ablegen.
<G-vec00418-001-s068><drop.ablegen><en> Even then the qualities continue to work and conduct the body functions until we drop off our vehicle.
<G-vec00418-001-s069><drop.ablegen><de> Ist die Brainstormingphase abgeschlossen, ordnen Sie die Zweige Ihrer Mind Map einfach per Ziehen und Ablegen, um die gewünschte Projektstruktur zu erhalten.
<G-vec00418-001-s069><drop.ablegen><en> Once your brainstorming phase is complete, simply drag and drop the branches of your Mind Map to transform it into the necessary Work Breakdown Structure.
<G-vec00418-001-s070><drop.ablegen><de> Zum Hochladen Datei hier ablegen oder auf den Button klicken.
<G-vec00418-001-s070><drop.ablegen><en> Drop a file here or click to upload Choose File
<G-vec00418-001-s071><drop.ablegen><de> Diese Besonderheit solltet ihr ablegen und die wirkliche Schönheit eurer Persönlichkeit erreichen.
<G-vec00418-001-s071><drop.ablegen><en> This speciality you should drop and the real beauty of your personality reached.
<G-vec00418-001-s072><drop.ablegen><de> Syntex beendet in den USA im Jahr 1993, die etwa zur gleichen Zeit entschlossen sie sich war, dieses Element in einer Reihe von ausländischen Ländern sowie ablegen.
<G-vec00418-001-s072><drop.ablegen><en> Syntex stopped in the U.S. in 1993, which was around the same time they decided to drop this item in a number of foreign countries as well.
<G-vec00418-001-s073><drop.ablegen><de> Darüber hinaus die Infektion ist relativ neu und da gibt es nicht genügend Informationen, wie es funktioniert, es könnte sogar schädliche Daten in anderen Verzeichnissen ablegen.
<G-vec00418-001-s073><drop.ablegen><en> In addition, the infection is fairly new and because there is not enough information, how it works, it could drop even malicious data in other directories.
<G-vec00418-001-s074><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Security for Microsoft SharePoint-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s074><drop.ablegen><en> You can also drag and drop files into the ESET File Security scan window. These files will be virus scanned immediately.
<G-vec00418-001-s075><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Mail Security-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s075><drop.ablegen><en> You can also drag and drop files into the ESET Mail Security scan window. These files will be virus scanned immediately.
<G-vec00345-001-s110><reckon.ablegen><de> Speziell bei den Jugendlichen entsteht so das Bild eines Gottes, der ohnehin niemandem etwas abschlagen kann und dem man daher gar keine Rechenschaft ablegen muss.
<G-vec00345-001-s110><reckon.ablegen><en> Among the youth especially, an image of God has arisen who cannot deny anyone anything and with whom one therefore does not need to reckon.
<G-vec00060-001-s095><unveil.ablegen><de> Auf Großveranstaltungen wurden Frauen aufgefordert, den Schleier abzulegen: Kleine Gruppen einheimischer Frauen sollten zur Bühne gehen und ihre Schleier in die Freudenfeuer werfen.
<G-vec00060-001-s095><unveil.ablegen><en> At mass meetings women were called upon to unveil: small groups of native women were expected to come to the podium and throw their veils on bonfires.
