<G-vec00367-001-s032><restrain.behindern><de> Und schlimmer noch, sie behindern diese Leute heute, sie zerstören, führen Kriege.
<G-vec00367-001-s032><restrain.behindern><en> And worse yet, they restrain these people today, they destroy and wage wars.
