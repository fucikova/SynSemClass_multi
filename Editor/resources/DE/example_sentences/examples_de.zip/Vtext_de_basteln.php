<G-vec00001-001-s019><craft.basteln><de> Ihre Inspiration ist: Basteln, alte Sachen, traditionelle Kostüme, klare Materialien, unklare Farben, Alltagsleben, Unaufdringlichkeit, Nonchalance und Widerspruch.
<G-vec00001-001-s019><craft.basteln><en> Their inspiration is: craft, old things, traditional costumes, clear materials, unclear colours, everyday life, unobtrusive, nonchalant and contradiction.
<G-vec00001-001-s020><craft.basteln><de> Vor einem Monat, wie berichtet erstmals von CNET, der Service in Beta gestartet, und zum ersten Mal, Menschen in den USA, Kanada, und Europa konnten My Robot Nation einfache Web-basierte Design-Tools nutzen, um ihre eigenen Miniatur-Roboter basteln.
<G-vec00001-001-s020><craft.basteln><en> A month ago, as reported first by CNET, the service launched into beta, and for the first time, people in the U.S., Canada, and Europe were able to use My Robot Nation’s simple Web-based design tools to craft their own miniature robots.
<G-vec00001-001-s021><craft.basteln><de> Wir spielen und basteln mit Waldmaterialien.
<G-vec00001-001-s021><craft.basteln><en> We play and craft with immediately available woodland materials.
<G-vec00001-001-s022><craft.basteln><de> Bunte Osterhühner Unsere bunten Osterhühner sehen sehr dekorativ aus, lassen sich leicht basteln und können in kurzer Zeit hergestellt werden.
<G-vec00001-001-s022><craft.basteln><en> Our colorful Easter hens are very decorative, are easy to craft and can be made in a short period of time.
<G-vec00001-001-s023><craft.basteln><de> Aber wenn Sie zusammen mit den Jüngeren Ihrer Familie einen Nistkasten basteln und ihn aufhängen wollen, dann sind Sie noch nicht zu spät dran.
<G-vec00001-001-s023><craft.basteln><en> But should you want to craft a nest box or two for your garden together with the younger of your family and set them up, then you are not too late at all.
<G-vec00001-001-s024><craft.basteln><de> Mit einer Kombination aus Bastelpapier, Buntstiften oder Wasserfarben sowie Watte und Wattepads könnt ihr abwechslungskreise Kunst basteln.
<G-vec00001-001-s024><craft.basteln><en> With a combination of craft paper, crayons or watercolors, as well as cotton wool and cotton wool pads, you can make a variety of art.
<G-vec00001-001-s025><craft.basteln><de> Wir basteln, kochen, schnitzen, malen und unternehmen Ausflüge in die Natur.
<G-vec00001-001-s025><craft.basteln><en> We craft, cook, paint and make excursions into nature.
<G-vec00001-001-s026><craft.basteln><de> Das Team von Crans-Montana Tourismus & Kongress betreut dort zahlreiche Animationen und Aktivitäten wie Basteln, Spiele und Bücherecke.
<G-vec00001-001-s026><craft.basteln><en> They can take part in numerous activities and entertainments, including craft projects, games and a library corner, all supervised by the staff of Crans-Montana Tourism and Congress.
<G-vec00001-001-s027><craft.basteln><de> Zum Basteln und Dekorieren mit STEINEL Heißklebepistolen Gluematic 5000, Gluematic 3002 und Gluefix.
<G-vec00001-001-s027><craft.basteln><en> For craft and decorating work using STEINEL Gluematic 5000, Gluematic 3002 und Gluefix hot-melt glue applicators.
<G-vec00001-001-s028><craft.basteln><de> Geeignet als Geschenk für Kinder und Enkel, oder für Sie selbst zum Basteln über die Feiertage.
<G-vec00001-001-s028><craft.basteln><en> Suitable as a gift for children and grandchildren, or for yourself to craft over the holidays.
<G-vec00001-001-s029><craft.basteln><de> Für unsere kleinen Gäste von 3 bis 10 Jahren bieten wir kostenfreie und qualifizierte Kinderbetreuung an, um nach dem Essen nach Herzenslust zu spielen, basteln und malen.
<G-vec00001-001-s029><craft.basteln><en> For our younger guests aged 3 to 10, we offer free and qualified childcare, so children can play, craft and paint to their heart's content after elevenses.
<G-vec00001-001-s030><craft.basteln><de> Ob Sie eine Standardgröße oder benutzerdefinierte Größe zu wählen, basteln wir jedes Kleid zu bestellen.
<G-vec00001-001-s030><craft.basteln><en> Whether you choose a standard or custom size, we craft each dress to order.
<G-vec00001-001-s031><craft.basteln><de> Wenn du etwas Günstiges und Tolles basteln möchtest, wofür du nicht in den Laden gehen musst, um irgendetwas einzukaufen, ist das hier perfekt für kleine Kinder und dazu noch ganz einfach.
<G-vec00001-001-s031><craft.basteln><en> So you want to make a cheap, fun craft that doesn't require going to the store and buying supplies? This is simple and perfect for young children.
<G-vec00001-001-s032><craft.basteln><de> Basteln Sie großartig aussehende E-Mail-Umfragen mit Ihren eigenen Fragen.
<G-vec00001-001-s032><craft.basteln><en> Craft great-looking email surveys with your own questions.
<G-vec00001-001-s033><craft.basteln><de> Kinder können sich mit Sport und Basteln ausleben oder sie stehen in einer der Abendshows im Rampenlicht.
<G-vec00001-001-s033><craft.basteln><en> Children will enjoy themselves with sports and craft activities or take the spotlight during one of the evening performances.
<G-vec00001-001-s034><craft.basteln><de> Die Regierungen versuchen nun Regeln zu basteln, um eine Wiederholung zu verhindern.
<G-vec00001-001-s034><craft.basteln><en> Governments are now trying to craft rules to prevent a recurrence.
<G-vec00001-001-s035><craft.basteln><de> Mit den beliebig langen Strick-Schnüren lässt sich Allerlei basteln und ganz nebenbei werden auch noch die Feinmotorik und die Geduld der Kinder geschult.
<G-vec00001-001-s035><craft.basteln><en> With arbitrarily long knitted cords can potpourri and craft along the way are also the fine motor skills and the patience of the children trained .
<G-vec00001-001-s036><craft.basteln><de> Zuerst die Natur des Staates selbst: Europa hat sich vorgenommen, mächtiger als der Staat zu werden und eine Außenpolitik zu basteln, die in erster Linie auf den Prinzipien der weichen Macht basiert.
<G-vec00001-001-s036><craft.basteln><en> First, the nature of the state itself: Europe has set out to transcend the state and craft a foreign policy based primarily on the principles of soft power.
<G-vec00001-001-s037><craft.basteln><de> Handgeschriebenes Songbook Wir basteln euch ein handgeschriebenes Songbook, das alle Lyrics beinhaltet, sowie exclusives Fotomaterial aus dem Studio und aus dem letzten Jahr.
<G-vec00001-001-s037><craft.basteln><en> Handwritten Songbook We will craft a handwritten songbook for you with all the lyrics and exclusive photos from the studio and the last year.
