<G-vec00081-001-s022><halt.anhalten><de> Höhepunkt dieser insgesamt außergewöhnlichen Reise nach Bosnien war der Besuch des nahegelegenen Naturschutzgebiets Hutovo Blato: Kaum angehalten, sprangen 30 Vogel-Expert/innen mit Ferngläsern aus den Autos und fingen an, die Landschaft abzusuchen – ein für uns als Laien unvergessliches Bild.
<G-vec00081-001-s022><halt.anhalten><en> The highlight of this altogether extraordinary trip to Bosnia was a visit to the nearby Hutovo Blato nature reserve: as soon as our convoy came to a halt, 30 bird experts jumped out of their vehicles and started to scan the landscape with binoculars – an unforgettable picture.
<G-vec00081-001-s023><halt.anhalten><de> In einigen Fällen muss möglicherweise der gesamte Cluster angehalten oder neugestartet werden.
<G-vec00081-001-s023><halt.anhalten><en> In some cases it may be necessary to halt or reboot the whole cluster.
<G-vec00081-001-s024><halt.anhalten><de> Wir hielten an und schauten auf einen Rollstuhl, der neben uns angehalten hatte.
<G-vec00081-001-s024><halt.anhalten><en> We stopped and looked at the wheelchair, which had glided to a halt beside us.
<G-vec00081-001-s025><halt.anhalten><de> Diese regelmäßige Datenübertragung kann aber vorübergehend angehalten werden, um Einstellungsänderungen oder andere Vorgänge durchzuführen.
<G-vec00081-001-s025><halt.anhalten><en> It is however possible to temporarily halt the periodic communications in order to carry out setting changes or other processes.
<G-vec00081-001-s026><halt.anhalten><de> Der Eindruck entsteht, als wäre der Darstellungsprozeß hier an einem Punkt angehalten worden, an dem die Materialität der Farbe noch nicht in die Materialität des darzustellenden Gegenstandes übergegangen ist.
<G-vec00081-001-s026><halt.anhalten><en> The impression is generated as if the representational process is here brought to a halt at a point where the materiality of the paint has not yet switched over into the materiality of the object to be represented.
<G-vec00081-001-s027><halt.anhalten><de> So hatte die Gruppe also angehalten, und wie zu vermuten waren die Männer weitaus nüchterner als zum Zeitpunkt ihres Aufbruchs.
<G-vec00081-001-s027><halt.anhalten><en> """The company had come to a halt, more sober men, as you may guess, than when they started."
<G-vec00081-001-s019><pause.anhalten><de> Im ausgeschalteten Zustand wird das Bewerben veröffentlichter Tweets angehalten, und neue Tweets werden erst wieder beworben, wenn diese Option wieder eingeschaltet wird.
<G-vec00081-001-s019><pause.anhalten><en> When toggled off, the promotion of published Tweets will pause and new Tweets will not be promoted until you resume promotion by toggling back on.
<G-vec00081-001-s020><pause.anhalten><de> Der Plan beinhaltet, dass ein Energiestrahl zur Erde gesandt wird, der eine solche Frequenz hat, dass er bewirkt, dass die Grundgeschwindigkeit des Energietransfers in seiner Bewegung angehalten wird.
<G-vec00081-001-s020><pause.anhalten><en> "The Plan of the ""Stasis Process"" involves sending a beam of energy to Earth that is of such a frequency that it causes the basic speed of energy transfer to pause in its movement."
<G-vec00081-001-s021><pause.anhalten><de> Wenn Kontakte immer noch nicht angezeigt: Blühen Eingabeaktion Skype angehalten werden soll.
<G-vec00081-001-s021><pause.anhalten><en> If contacts still don't appear: Bloom gesture to pause Skype.
<G-vec00081-001-s022><pause.anhalten><de> Somit kann digitales Fernsehen (DVB-T) live auf dem iPad 2 angesehen, angehalten, gespult oder aufge-nommen werden, ohne dass zusätzliche Verbindungskosten entstehen.
<G-vec00081-001-s022><pause.anhalten><en> This makes it possible to watch, pause, and rewind digital television (DVB-T) live on the iPad 2, without incurring any additional connection fees.
<G-vec00081-001-s023><pause.anhalten><de> Die Sitzung wird angehalten, der Computer bleibt jedoch eingeschaltet.
<G-vec00081-001-s023><pause.anhalten><en> Locking the Computer. Pause your session, but keep the computer on.
<G-vec00081-001-s028><halt.anhalten><de> Stups durch SamMobile hat ergeben, dass einige Anwender wurden mit Blick auf zufälligen Neustarts nach dem update das verursacht hat Samsung das anhalten der rollout vorübergehend, bis Sie herausfinden, das Problem.
<G-vec00081-001-s028><halt.anhalten><en> Prodding by SamMobile has revealed that some users were facing random reboots after the update, which has caused Samsung to halt the rollout temporarily until they figure out the issue.
<G-vec00081-001-s029><halt.anhalten><de> Beim Anhalten aufgrund eines Speicherfehlers werden die Adresse des fehlerhaften MCB sowie die Daten (4 Langworte) ausgegeben.
<G-vec00081-001-s029><halt.anhalten><en> For a halt due to a memory error the address of the faulty MCB as well as the data (4 LONGwords) are output.
<G-vec00081-001-s030><halt.anhalten><de> B. Funktionen anpassen, Alarme ansehen/löschen, Programme starten/stoppen/anhalten, etc.
<G-vec00081-001-s030><halt.anhalten><en> change functions, view/cancel alarms, start/stop/halt program, etc.
<G-vec00081-001-s031><halt.anhalten><de> Es sind Emotionen welche motivieren, oder jegliche Aktivität anhalten, Emotionen die vor Gefahr warnen, und Emotionen die euch mit euren Geliebten verbinden.
<G-vec00081-001-s031><halt.anhalten><en> It is emotions that motivate or halt any activity, emotions that warn of danger, and emotions that connect you to your beloved.
<G-vec00081-001-s032><halt.anhalten><de> Die oben genannten Szenarien können schwere Katastrophen sein, da sie Ihre Arbeit anhalten, ohne weiter zu gehen.
<G-vec00081-001-s032><halt.anhalten><en> The above scenarios may be severe disasters as they put halt to your work without proceeding any more.
<G-vec00081-001-s033><halt.anhalten><de> Wie der König das hörte, ließ er anhalten und einer seiner Leute musste zurückjagen und von des Königs Kleider holen.
<G-vec00081-001-s033><halt.anhalten><en> When the king heard that, he called halt and one of his people had to chase back and of the king's clothes bring hack.
<G-vec00081-001-s034><halt.anhalten><de> Das Einsteigen und Aussteigen aus dem Fahrzeug ist nur nach dem Anhalten auf Haltestellen oder Stationen zugelassen.
<G-vec00081-001-s034><halt.anhalten><en> Boarding and leaving vehicles is only allowed at stops or stations after the vehicle has come to a halt.
<G-vec00081-001-s035><halt.anhalten><de> Wenn der Penis wirklich beginnen fühlt steigen, könnten Sie verwenden, für 1-2 Tage anhalten.
<G-vec00081-001-s035><halt.anhalten><en> If the penile begin feels rise, you could halt from making use of for 1-2 days.
<G-vec00081-001-s024><pause.anhalten><de> Über das Inline-Mikrofon können Sie Anrufe annehmen und beenden, Titel wiedergeben und anhalten oder die Lautstärke anpassen ohne dafür Ihr Gerät in die Hand nehmen zu müssen.
<G-vec00081-001-s024><pause.anhalten><en> About the inline microphone lets you answer and end calls, play songs and pause or adjust the volume - without having to take your device in the hand.
<G-vec00081-001-s025><pause.anhalten><de> Die Trainer können durch das Touch Control Interface in ihren Präsentationen vor- und zurückspringen, die Präsentation anhalten und selbst die Lautstärke steuern.
<G-vec00081-001-s025><pause.anhalten><en> The trainer has a touch control interface that allows them to forward, pause and rewind all aspects of the presentation and even control the sound levels.
<G-vec00081-001-s026><pause.anhalten><de> Wenn Sie sehen ein YouTube-Clip und brauchen das Video anhalten,, statt des Schlagens Pause auf der YouTube-Player selbst., klicken Sie auf die Pause-Taste Pause für später in der Chrome-Toolbar installiert.
<G-vec00081-001-s026><pause.anhalten><en> When you are viewing a YouTube clip and need to pause the video, instead of hitting pause on the YouTube player itself, click the pause button Pause For Later installed in the Chrome toolbar.
<G-vec00081-001-s027><pause.anhalten><de> Es nutzt Gesten erkannt über eingebaute Webcam auf dem Gerät zu spielen, anhalten und überspringen Songs und Videos in iTunes, Spotify, Rdio, MPlayerX (neueste Version), VLC (neueste Version), Ecoute, Quicktime, Keynote und .
<G-vec00081-001-s027><pause.anhalten><en> It uses HAND GESTURES detected via built-in webcam in your device to play, pause and skip songs & videos in iTunes, Spotify, Rdio, MPlayerX (latest version), VLC (latest version), Ecoute, Quicktime, and Keynote.
<G-vec00081-001-s028><pause.anhalten><de> Danach werden sie die Rangers am Dienstag spielen, bevor sie die Leafs konfrontiert nächsten Samstagabend anhalten.
<G-vec00081-001-s028><pause.anhalten><en> After that they will play the Rangers on Tuesday before they pause to face the Leafs next Saturday night.
<G-vec00081-001-s029><pause.anhalten><de> Es gibt interaktive Features, wie anhalten und zurückspulen Optionen für Live-TV-Wiedergabe.
<G-vec00081-001-s029><pause.anhalten><en> There are interactive features, such as pause and rewind options for Live TV playback.
<G-vec00081-001-s030><pause.anhalten><de> Suchen Sie nach Orten, wo Sie logisch für Atem anhalten können.
<G-vec00081-001-s030><pause.anhalten><en> Look for places where you can logically pause for breath.
<G-vec00081-001-s031><pause.anhalten><de> Springdale liegt direkt außerhalb des Zion Nationalparks und dort werden wir kurz anhalten, um die Lunchpakete abzuholen, welche wir im Bryce Canyon genießen werden.
<G-vec00081-001-s031><pause.anhalten><en> Springdale is just outside Zion, and we'll pause there briefly to pick up sack lunches, which we generally enjoy in Bryce.
<G-vec00081-001-s032><pause.anhalten><de> Das laufende Programm kann jederzeit aufgenommen werden und es werden bis zu 30 Minuten gepuffert, so dass man jederzeit die Wiedergabe anhalten und später an der selben Stelle fortsetzen kann.
<G-vec00081-001-s032><pause.anhalten><en> The current programme can be recorded at any time and up to 30 minutes will be buffered, so you can pause the play back any time and continue at the same position later.
<G-vec00081-001-s033><pause.anhalten><de> "HomePod ist an der Spitze mit einem Oberfläche berühren, über die der Benutzer die Lautstärke ändern, Siri anhalten, überspringen oder ""fragen"" kann."
<G-vec00081-001-s033><pause.anhalten><en> "HomePod is provided at the top with a touch surface, through which the user will be able to change the volume, pause, skip or ""ask"" Siri."
<G-vec00081-001-s034><pause.anhalten><de> Zwischen den Hohlräumen, Man spürt die Musik Ihren Chor anhalten, wieder weiter mit neuen Noten und mit neuen refrãos.
<G-vec00081-001-s034><pause.anhalten><en> Between the empty spaces, You can feel the music pause your chorus, to continue again with new notes and with new refrãos.
<G-vec00081-001-s035><pause.anhalten><de> Wenn Sie eine ausgehende Warteschlange anhalten, wird der Nachrichtenversand aus dieser Warteschlange an die entsprechende Zielwarteschlange zeitlich verzögert.
<G-vec00081-001-s035><pause.anhalten><en> When you pause the operation of an outgoing queue, you postpone the sending of messages from that queue to the corresponding destination queue.
<G-vec00081-001-s036><pause.anhalten><de> Der Weg ist eine schöne Strecke durch Schluchten entlang eines Flusses, mit vielen Möglichkeiten zum anhalten und um im Wasser zu spielen.
<G-vec00081-001-s036><pause.anhalten><en> This is a great route along the river and gorges, where there are many places to pause and play in the water.
<G-vec00081-001-s037><pause.anhalten><de> Als Musik zu spielen, der Taste anhalten und abspielen.
<G-vec00081-001-s037><pause.anhalten><en> When music playing, press the button to pause and play.
<G-vec00081-001-s038><pause.anhalten><de> Das neue Elgato EyeTV Lite ist eine Software für Macs, mit der der Nutzer Live-Fernsehübertragungen ansehen, anhalten und zurückspulen sowie mehrere Stunden an TV Sendungen direkt auf dem Mac aufnehmen kann.
<G-vec00081-001-s038><pause.anhalten><en> • New Elgato EyeTV Lite Software for Mac, which enables users to watch, pause and rewind live TV and record hours of shows directly onto the Mac.
<G-vec00081-001-s039><pause.anhalten><de> Der Begriff 'Wechseljahre' wird verwendet, um die endgültige Stilllegung oder Anhalten der Hauptfunktionen der Eierstöcke im Körper einer Frau zu definieren.
<G-vec00081-001-s039><pause.anhalten><en> The term 'menopause' is used to define the permanent cessation or pause of the primary functions of the ovaries in a woman's body.
<G-vec00081-001-s040><pause.anhalten><de> Auf einem Computer unter Windows Server 2008 R2 können Sie den Serverdienst für verteilte Scanvorgänge starten, beenden oder anhalten.
<G-vec00081-001-s040><pause.anhalten><en> On a computer running Windows Server 2008 R2, you can start, stop, or pause the Distributed Scan Server service for a scan server.
<G-vec00081-001-s041><pause.anhalten><de> Klicken Sie auf Anhalten, um diesen Dienst anzuhalten.
<G-vec00081-001-s041><pause.anhalten><en> Click Pause to pause this service.
<G-vec00081-001-s042><pause.anhalten><de> Darüber hinaus können Sie eine automatische Antwort an den Absender der Kette / Witz / E-Mails weitergeleitet werden, dass sie informiert hat, dass sie wirklich länger anhalten sollte, bevor Nachrichten an Personen, wie es füllt sich Menschen Posteingänge unnötig, die blonde Witze waren nicht sehr lustig an erster Stelle, und nicht, Bill Gates ist nicht wirklich Verfolgung dieser Kette E-Mail und wird nicht geben Ihnen eine Million Dollar für die Weiterleitung.
<G-vec00081-001-s042><pause.anhalten><en> In addition, you can enable an automatic reply to the sender of chain/joke/forwarded emails that informs them that they really should pause longer before forwarding messages to people, as it fills up people's inboxes needlessly, the blonde jokes weren't very funny in the first place, and no, Bill Gates isn't really tracking this chain email and won't give you a million dollars for forwarding it.
<G-vec00081-001-s019><stop.anhalten><de> "Wir beschäftigen derzeit mehr als 100 Menschen mit Behinderungen und nicht dort anhalten "", sagte in seinem Vortrag Bruno Kostelac Košir, INA Direktor für Entwicklung und Bildung, Vertreter von Verbänden und Organisationen von Menschen mit Behinderungen auf eine verstärkte Zusammenarbeit in diesem Bereich eingeladen."
<G-vec00081-001-s019><stop.anhalten><en> "We currently employ more than 100 persons with disabilities and do not stop there "", said in his presentation Bruno Kostelac Košir, INA Director of Development and Education, inviting representatives of associations and organizations of persons with disabilities on enhanced cooperation in this area."
<G-vec00081-001-s020><stop.anhalten><de> Wir werden an einem abgelegenen Strand anhalten, wo die Crew kochen und das Barbecue-Mittagessen servieren wird.
<G-vec00081-001-s020><stop.anhalten><en> We will stop on a secluded beach, where the crew will cook and serve the barbecue lunch.
<G-vec00081-001-s021><stop.anhalten><de> Je länger ich fuhr, desto weniger wollte ich anhalten, verrückt.
<G-vec00081-001-s021><stop.anhalten><en> The longer I went, the less I wanted to stop, crazy.
<G-vec00081-001-s022><stop.anhalten><de> Diese Muskeln zu beschränken, für fünf Sekunden anhalten und dann zu entspannen.
<G-vec00081-001-s022><stop.anhalten><en> Constrain these muscles, stop for five second and then relax them.
<G-vec00081-001-s023><stop.anhalten><de> "Orthon schien mein Erstaunen zu genießen und erklärte: ""Wir haben einen Projektor, der in einem beliebigen Abstand wie gewünscht die Strahlen senden und anhalten kann."
<G-vec00081-001-s023><stop.anhalten><en> "Orthon seemed to enjoy my amazement and explained, ""We have a certain type of projector that can send out and stop beams at any distance desired."
<G-vec00081-001-s024><stop.anhalten><de> Wenn sie gemeinsam spazieren gingen, musste ihre Oma immer beim Juwelier anhalten.
<G-vec00081-001-s024><stop.anhalten><en> When they went for a walk together, her grandma always had to stop at the jeweller.
<G-vec00081-001-s025><stop.anhalten><de> Es klang ja allerdings sonderbar, wenn er vor den in die lärmerfüllte Luft geöffneten Fenstern ein altes Soldatenlied seiner Heimat spielte, das die Soldaten am Abend, wenn sie in den Kasernenfenstern liegen und auf den finstern Platz hinausschauen, von Fenster zu Fenster einander zusingen – aber sah er dann auf die Straße, so war sie unverändert und nur ein kleines Stück eines großen Kreislaufes, das man nicht an und für sich anhalten konnte, ohne alle Kräfte zu kennen, die in der Runde wirkten.
<G-vec00081-001-s025><stop.anhalten><en> When he played an old soldier's song from his homeland, which the soldiers sing from window to window as they lean out of the barracks windows and look out at the dark square, it resonated oddly in the noise-filled air of his open window – but he looked across the street, it was so unchanged and just a small piece of a giant cycle that no one could stop without knowing all the powers effecting that cycle.
<G-vec00081-001-s026><stop.anhalten><de> Das Bewusstsein entwickelt sich und wenn wir wirklich anhalten und darüber nachdenken, dann begann die Abhängigkeit von Großunternehmen uns zu kurieren ungefähr mit der Erfindung des Penizillins zur Zeit des Zweiten Weltkriegs.
<G-vec00081-001-s026><stop.anhalten><en> Consciousness is evolving, and if we really stop and think, this dependency upon large companies to cure us only began at about World War II, with the invention of penicillin.
<G-vec00081-001-s027><stop.anhalten><de> Du brauchst nichts weiter zu tun als anhalten und entspannen - etwas Musik hören, nichts weiter.
<G-vec00081-001-s027><stop.anhalten><en> All you need to do is stop and relax - listen to some music, nothing more.
<G-vec00081-001-s028><stop.anhalten><de> Ich brauchte etwa eine Stunde um die drei Blocks zurück zur Klinik zu gehen, weil ich ziemlich betrunken war von der Mixtur der Pillen und dem Alkohol, also musste ich mehrere Male anhalten um auszuruhen.
<G-vec00081-001-s028><stop.anhalten><en> It took me about an hour to walk three blocks back to the hospital because I was quite inebriated from the mixture of pills and alcohol, so I had to stop several times to rest.
<G-vec00081-001-s029><stop.anhalten><de> Aber die Pfeile fielen in solche Fülle, dass er anhalten musste.
<G-vec00081-001-s029><stop.anhalten><en> But arrows were falling in such exuberance that he had to stop.
<G-vec00081-001-s030><stop.anhalten><de> Als ich an diesen Punkt kam, war ich aber an einer ganz falschen Stelle, bremste zu spät und verpasste die Linie komplett, fast hätte ich anhalten müssen.
<G-vec00081-001-s030><stop.anhalten><en> I came to that point in the track, entirely in the wrong place, braked too late, and completely messed up the line, almost coming to a stop!
<G-vec00081-001-s031><stop.anhalten><de> Wir gehen weiter der Via Biagio ai Librai entlang bis auf die Piazza San Domenico Maggiore, wo wir anhalten, um die gleichnamige Kirche zu besichtigen.
<G-vec00081-001-s031><stop.anhalten><en> We continue along Via Biagio ai Librai until Piazza San Domenico Maggiore where we stop to visit the church.
<G-vec00081-001-s032><stop.anhalten><de> Beim Verlassen von Sedona musste sie für eine Schlage anhalten, die gemächlich die Straße überquerte.
<G-vec00081-001-s032><stop.anhalten><en> Upon leaving Sedona, she had to stop for a snake taking its sweet time crossing her driveway.
<G-vec00081-001-s033><stop.anhalten><de> Über die Tasten können Sie Titel wiedergeben, anhalten oder überspringen sowie die Lautstärke anpassen.
<G-vec00081-001-s033><stop.anhalten><en> Use the buttons to play, stop or skip through tracks and adjust the volume.
<G-vec00081-001-s034><stop.anhalten><de> Wenn Sie anhalten sollen, signalisiert man dies Ihnen mit einer Kelle oder einer Leuchtschrift.
<G-vec00081-001-s034><stop.anhalten><en> If you are to stop, a police officer signals you with a round paddle or a lighted sign.
<G-vec00081-001-s035><stop.anhalten><de> Das Roping-Pferd muss schnell anhalten, wenn die Schlinge sich um den Nacken des Kalbes legt.
<G-vec00081-001-s035><stop.anhalten><en> The calf roping horse is asked to slide to a stop as the loop settles over the calf's neck.
<G-vec00081-001-s036><stop.anhalten><de> Nach Marvin Gayes Worten, müssen Sie kurz anhalten, beobachten und zuhören – nicht auf Ihr Herz- sondern auf einzelne Bedürfnisse Ihrer Kunden und erstellen Sie eine Strategie, wie Sie am erfolgreichsten mit ihnen auf Social Media engagieren.
<G-vec00081-001-s036><stop.anhalten><en> In the words of Marvin Gaye, you've got to stop, look and listen – not to your heart – but to your customers' every need and want, then structure a strategy on how to engage successfully with them on social media.
<G-vec00081-001-s037><stop.anhalten><de> Auch bei den Wanderungen mussten wir ständig anhalten, damit sie Verschnaufpausen einlegen konnte.
<G-vec00081-001-s037><stop.anhalten><en> We also had to constantly stop during our hike to give her time to catch her breath.
<G-vec00081-001-s036><halt.anhalten><de> Wie sie Ihre Flosse fast quer stellt, um anzuhalten.
<G-vec00081-001-s036><halt.anhalten><en> How she crosses her fluke to a halt.
<G-vec00081-001-s037><halt.anhalten><de> Ihr Wachstum man anzuhalten sollte das vorhandene Bewußtsein in der Seele Kraft zentralisieren.
<G-vec00081-001-s037><halt.anhalten><en> To halt their growth one should centralise the available consciousness in the soul force.
<G-vec00081-001-s038><halt.anhalten><de> Es ist außerdem möglich, jede CPU anzuhalten, die sich im Idle-Loop befindet, dazu dient die sysctl-Variable machdep.hlt_cpus.
<G-vec00081-001-s038><halt.anhalten><en> It is also possible to halt any CPU in the idle loop with the machdep.hlt_cpus sysctl variable.
<G-vec00081-001-s039><halt.anhalten><de> In Pittsburgh, waren die Flammen nicht in der Lage, ihre letzten Dia entweder anzuhalten, trotz der Abwesenheit von Sidney Crosby, der für die Mumps getestet wurde.
<G-vec00081-001-s039><halt.anhalten><en> In Pittsburgh, the Flames were not able to halt their recent slide either, despite the absence of Sidney Crosby, who was tested for the mumps.
<G-vec00081-001-s040><halt.anhalten><de> Er reagierte nicht auf Aufrufe, anzuhalten, und schritt auch weiter, nachdem Warnschüsse in die Luft gefeuert wurden.
<G-vec00081-001-s040><halt.anhalten><en> He did not heed their calls to halt and continued walking even after they fired shots into the air.
<G-vec00081-001-s041><halt.anhalten><de> In nuun für zwei Klavier und Orchester von 1996 lässt Furrer sogar die mythische Figur Nu, die der Legende nach die Zeit anzuhalten vermag, im Stück-Titel auftauchen und spannt in dem Werk einen großen Bogen vom Ensembletutti zum vereinzelten Klavierton, vom Fortissimo zum Pianissimo, von einer wahren Sturzflut gleichzeitiger musikalischer Ereignisse zur Stille.
<G-vec00081-001-s041><halt.anhalten><en> In nuun (1996) for two pianos and orchestra, Furrer's title even evokes the mythical figure of Nu, who, according to legend, was able to bring time to a halt, and the work spans a range from the tutti ensemble to isolated piano notes, from fortissimo to pianissimo, from a true flood of simultaneous musical events to silence.
<G-vec00081-001-s042><halt.anhalten><de> Solch ein Ergebnis könnte sein, dass die Sonne 180° weg von, dem, wie in Wans Traum Königs sein sollte, würde veranlassen das Programm anzuhalten war.
<G-vec00081-001-s042><halt.anhalten><en> Such a result could be that the sun was 180° away from where should be, like in king Wan's dream, would cause the program to halt.
<G-vec00081-001-s043><halt.anhalten><de> Durch die Erhöhung der Glycosaminoglycans wird dabei geholfen, den Knorpel wieder aufzubauen und die Entwicklung bestimmter Arten von Arthritis zu verlangsamen oder anzuhalten.
<G-vec00081-001-s043><halt.anhalten><en> By increasing glycosaminoglycans, users of supplemental glucosamine may help to rebuild cartilage and slow or halt the advancement of certain types of arthritis.
<G-vec00081-001-s044><halt.anhalten><de> Die UN-Mitglieder zielen darauf, bis 2015 die Ausbreitung von HIV /AIDS, Malaria und anderen schweren Krankheiten anzuhalten.
<G-vec00081-001-s044><halt.anhalten><en> The UN (United Nations) members target to halt the spread of HIV/AIDS, malaria, and other major infectious diseases by 2015. Trends: 0 / −
<G-vec00081-001-s045><halt.anhalten><de> Die UN-Mitglieder zielen darauf, bis 2015 die Ausbreitung von HIV /AIDS, Malaria und anderen schweren Krankheiten anzuhalten.
<G-vec00081-001-s045><halt.anhalten><en> The UN members target to halt the spread of HIV/AIDS, malaria, and other major infectious diseases by 2015.
<G-vec00081-001-s046><halt.anhalten><de> Der richtige Moment, die Zeit anzuhalten.
<G-vec00081-001-s046><halt.anhalten><en> The right moment to halt the turn of time.
<G-vec00081-001-s047><halt.anhalten><de> Die einfachste Lösung besteht häufig darin, den Server brutal anzuhalten (nachdem der Befehl sync ausgeführt wurde) und dann den Rechner mit einer Rettungs-CD neu zu starten.
<G-vec00081-001-s047><halt.anhalten><en> The simplest solution is often to halt the server brutally (after running sync) and reboot it on a rescue CD.
<G-vec00081-001-s043><pause.anhalten><de> Es empfiehlt sich aber vor dem Betrachten der vergrößerten Bilder die Slideshow anzuhalten (II), weil sie sonst im Hintergrund weiterläuft und Sie dann wieder manuell zu Ihrem zuletzt besuchten Bild zurückkehren müssen.
<G-vec00081-001-s043><pause.anhalten><en> It is useful to pause (II) the slideshow if You want to see the enlarged version of a picture or watch a video. Otherwise it is marching on in the background and You have to go manually to Your last viewed picture within the slideshow window.
<G-vec00081-001-s044><pause.anhalten><de> Sie können Ihr Gerät sogar verwenden, um das Gerät Ihres Kindes anzuhalten oder zusätzliche Zeit zu gewähren, und unterstützt Sie bei der Erstellung einer Checkliste von Internetseiten, die Ihr Kind besuchen und von denen es lernen sollte.
<G-vec00081-001-s044><pause.anhalten><en> Even use your device to pause your child's device or give additional time and helps you create a checklist of the sites you want your child to visit and learn from.
<G-vec00081-001-s045><pause.anhalten><de> Es besteht auch die Möglichkeit, die Methode während eines Laufs anzuhalten.
<G-vec00081-001-s045><pause.anhalten><en> There is also a possibility to pause your method during a run.
<G-vec00081-001-s046><pause.anhalten><de> Verwende mehrzeiliges Bearbeiten, um Kampagnen, Anzeigengruppen und Promoted Pins anzuhalten, zu aktivieren und zu archivieren.
<G-vec00081-001-s046><pause.anhalten><en> Use multi-row editing to pause, activate, and archive campaigns, ad groups, and Promoted Pins.
<G-vec00081-001-s047><pause.anhalten><de> Verwenden Sie net pause, um den Dienst anzuhalten, wodurch neue Verbindungen verhindert werden.
<G-vec00081-001-s047><pause.anhalten><en> Use net pause to pause the service, which prevents new connections.
<G-vec00081-001-s048><pause.anhalten><de> Es hilft oft, für eine oder zwei Sekunden in der vollständig gestreckten und der vollständig kontrahierten Position jeder Wiederholung anzuhalten.
<G-vec00081-001-s048><pause.anhalten><en> It often helps to pause for one or two seconds in the fully stretched and the fully contracted position of each repetition.
<G-vec00081-001-s049><pause.anhalten><de> Breakpoints erlauben es, die Ausführung des Programms an einer bestimmten Zeile anzuhalten, damit man in Ruhe Variablen inspizieren und den Programmfluss besser nachvollziehen kann.
<G-vec00081-001-s049><pause.anhalten><en> Breakpoints allow to pause the execution of a program at a specific line. This way you can inspect variables without a hurry, and it allows you to comprehend the program flow much better.
<G-vec00081-001-s050><pause.anhalten><de> Klicken Sie auf ESC, um das Spiel anzuhalten.
<G-vec00081-001-s050><pause.anhalten><en> Click ESC to pause the game.
<G-vec00081-001-s051><pause.anhalten><de> Mit P-Taste, um das Spiel anzuhalten.
<G-vec00081-001-s051><pause.anhalten><en> Use P key to pause the game.
<G-vec00081-001-s052><pause.anhalten><de> Praxis, allein oder mit Ihrem Partner, bringen Sie sich selbst in der Nähe der Ejakulation und dann anzuhalten.
<G-vec00081-001-s052><pause.anhalten><en> Practice, alone or with your partner, bringing your self close to ejaculation and then pause.
<G-vec00081-001-s053><pause.anhalten><de> Klicken Sie auf Anhalten, um diesen Dienst anzuhalten.
<G-vec00081-001-s053><pause.anhalten><en> Click Pause to pause this service.
<G-vec00081-001-s054><pause.anhalten><de> Beim Betreten, sofort nach rechts, lassen Sie uns anzuhalten, um die schöne romanische Schrift, deren kreisförmige Becken sind Reliefs mit Szenen aus dem Leben von Moses und Figuren bewundern.
<G-vec00081-001-s054><pause.anhalten><en> Upon entering, immediately right, let us pause to admire the beautiful Romanesque font whose circular basin are reliefs with scenes from the life of Moses and figures.
<G-vec00081-001-s055><pause.anhalten><de> Wie das Dialogfeld Eigenschaften für bestimmte Dienste im Snap-In Dienste können Sie die Befehle am Rand des Bereichs Systemdienste verwenden, um der Verwendung einer Rolle zugeordnete Dienste zu starten, zu beenden, anzuhalten und neu zu starten.
<G-vec00081-001-s055><pause.anhalten><en> Just as you can by using the Properties dialog box for specific services in the Services snap-in, you can use commands in the margin of the System Services area to start, stop, pause, and restart services associated with the operation of a role.
<G-vec00081-001-s056><pause.anhalten><de> Klicken Sie auf Bomben zu benachbarten Kugeln oder Uhren anzuhalten der Bewegung zu entfernen.
<G-vec00081-001-s056><pause.anhalten><en> Click bombs to remove adjacent orbs or clocks to pause the movement.
<G-vec00081-001-s057><pause.anhalten><de> Geben Sie beispielsweise auf dem Clientcomputer den Befehl ipconfig /all|more ein, um die Anzeige anzuhalten, damit Sie die IP-Adressen anzeigen und notieren können, die für die Befehlsausgabe unter DNS-Server aufgeführt werden.
<G-vec00081-001-s057><pause.anhalten><en> For example, at the client computer, type ipconfig /all|more if necessary to pause the display so that you can read and note any IP addresses that are listed in DNS servers for the command output.
<G-vec00081-001-s058><pause.anhalten><de> P-Taste ist für das Spiel anzuhalten.
<G-vec00081-001-s058><pause.anhalten><en> P key is for pause the game.
<G-vec00081-001-s059><pause.anhalten><de> Der Lizenzgeber ist jederzeit ohne Ankündigung des Lizenznehmers und ohne Erklärung der Gründe berechtigt, den Zugang und die Möglichkeit anzuhalten, das Professionelle Netz ohne Ersatz irgendwelcher Aufwände, der Schäden oder der Rückgabe bekommen laut Abkommen, einschließlich im Falle jedes, einschließlich einmalig, des Verstoßes vom Lizenznehmer der Bedingungen des gegenwärtigen Abkommens zu verwenden.
<G-vec00081-001-s059><pause.anhalten><en> The Licensor has the right at any time without notice the Licensee and without explanation to pause access and opportunity to use the Professional network without reimbursing of any expenses, losses or return received under the Agreement, including in case of any, including one-fold, violations by the Licensee of conditions of the present Agreement.
<G-vec00081-001-s060><pause.anhalten><de> Drücken Sie die Leertaste, um den Timer anzuhalten.
<G-vec00081-001-s060><pause.anhalten><en> To pause the boot timer in order to review the selections, press Space .
<G-vec00081-001-s061><pause.anhalten><de> Zwar ist dies viel einfacher für die Leute, die nicht über eine Steckdose in der Toilette, bedeutet es, Sie brauchen, um anzuhalten und darüber nachdenken, die Batterielebensdauer.
<G-vec00081-001-s061><pause.anhalten><en> While this is lots more simple for those people that don’t have a power outlet in the toilet, it does mean you will need to pause and think about battery life.
<G-vec00081-001-s057><stop.anhalten><de> Diese verbindet die zwei Hauptinseln der Inselgruppe und viele Busfahrer und Reiseleiter machen sich einen Spaß daraus dort anzuhalten und den Besuchern zu ihrer ganz persönlichen „Transatlaniküberfahrt“ zu verhelfen.
<G-vec00081-001-s057><stop.anhalten><en> "It combines the two main islands of the archipelago and many bus drivers and guide will make a fun from it there stop and visitors of their own personal """"Transatlaniküberfahrt""to help."""
<G-vec00081-001-s058><stop.anhalten><de> Ungeachtet ihrer großen Vielfältigkeit, die Auswahl ist es besser, auf der klassischen Variante aus dem Wein und den Gewürzen anzuhalten.
<G-vec00081-001-s058><stop.anhalten><en> Despite their big variety, a choice it is better to stop on classical option from wine and spices.
<G-vec00081-001-s059><stop.anhalten><de> Es gibt den Motor zur Ausgabe, und der Mensch nicht im Zustand, es anzuhalten.
<G-vec00081-001-s059><stop.anhalten><en> There is a drive towards release and person is not able to stop it.
<G-vec00081-001-s060><stop.anhalten><de> Die anmutigen Bewegungen die friedliche Musik veranlasste viele Passanten, anzuhalten und zuzusehen.
<G-vec00081-001-s060><stop.anhalten><en> The graceful movements and peaceful music attracted many passers-by to stop and watch.
<G-vec00081-001-s061><stop.anhalten><de> So ist es den Mädchen mit den Fingern fein und lang besser, die Auswahl auf den kurzen ovalen oder quadratischen Nägeln anzuhalten.
<G-vec00081-001-s061><stop.anhalten><en> So, with fingers thin and long it is better for girls to stop the choice on short oval or square nails.
<G-vec00081-001-s062><stop.anhalten><de> von einer wertvollen Hilfe für die Raucher, die wünschen, sich den Tabak anzuhalten, sie beruhigt die Angst, die Ängste und die Nervosität die das Entwöhnen in Nikotin begleiten.
<G-vec00081-001-s062><stop.anhalten><en> of an invaluable help for the smokers wishing to stop the tobacco, it calms the anxiety, the anguishes and the nervousness which accompany weaning with nicotine.
<G-vec00081-001-s063><stop.anhalten><de> Das Auto parallel der Borte (4) geebnet und endgültig abgebremst, ist nötig es das Signal der Wendung abzuschalten und, den Motor anzuhalten.
<G-vec00081-001-s063><stop.anhalten><en> Having levelled the car in parallel a border (4) and definitively having braked, it is necessary to disconnect a signal of turn and to stop the engine.
<G-vec00081-001-s064><stop.anhalten><de> Da hilft nur, anzuhalten, das Auto zu reparieren und die fehlerhaften Teile auszuwechseln.
<G-vec00081-001-s064><stop.anhalten><en> The only thing to do is stop and get the car repaired and the faulty components replaced.
<G-vec00081-001-s065><stop.anhalten><de> Khiray war versucht, in der nächsten größeren Stadt anzuhalten und einen Arzt oder Kräuterheiler danach zu fragen.
<G-vec00081-001-s065><stop.anhalten><en> Khiray was tempted to stop at the next big city and ask a doctor or herb healer for it.
<G-vec00081-001-s066><stop.anhalten><de> Versuchen Sie, das nächste Auto anzuhalten (was auf einer abgelegenen Straße Stunden dauern kann), berichten Sie, was Sie beobachtet haben und fragen Sie um Rat.
<G-vec00081-001-s066><stop.anhalten><en> Try to stop the next car (which can take hours on a remote road), report what you have observed, and ask for advice.
<G-vec00081-001-s067><stop.anhalten><de> Ich fühlte als würde ich darum kämpfen mich anzuhalten von diesem Zurückziehen und ich wollte weiter gehen, aber das sollte nicht sein.
<G-vec00081-001-s067><stop.anhalten><en> I felt as if I was fighting to stop myself from being pulled out and I wanted to continue forward but that wasn't meant to be.
<G-vec00081-001-s068><stop.anhalten><de> Angesichts der endlosen Kurven besteht fast die Gefahr in einen meditativen Zustand zu verfallen, was man aber aufgrund der schwierigen Strecke und der ablenkenden, wunderschön-schaurigen Landschaft besser vermeiden sollte.Die Straße ist eng und es gibt nur wenige Möglichkeiten anzuhalten.
<G-vec00081-001-s068><stop.anhalten><en> In view of the endless curves almost the danger exists to go to ruin in a meditative state, what one, however should prevent.The street is narrow and there are only few possibilities to stop.
<G-vec00081-001-s069><stop.anhalten><de> Andere sehenswerte Orte: Wenn du vom Westen kommst, lohnt es sich auf jeden Fall in Transsylvanien anzuhalten.
<G-vec00081-001-s069><stop.anhalten><en> Other places to see: If you come from the west, there's a use to stop in Transylvania.
<G-vec00081-001-s070><stop.anhalten><de> Wir rufen zu keiner physischen Gewalt auf, veröffentlichen aber diese Angaben in der Hoffnung, dass es diese Menschen wie auch ihre Kampfgefährten dazu bewegt, anzuhalten und mit allen möglichen Mitteln die verbrecherischen Befehle des Kreml-Regimes zu sabotieren.
<G-vec00081-001-s070><stop.anhalten><en> We do not call for the physical liquidation of these people, we publish their data in the hope that it will encourage them and their comrades to stop and to sabotage the criminal orders of the Kremlin's regime in every possible way.
<G-vec00081-001-s071><stop.anhalten><de> Die moderne Bundesstraße 14 folgt dem Verlauf der römischen Via Annia und gibt dem Besucher die Gelegenheit, dieses Erbe des DOC-Gebiets DOC Friuli Latisana zu bewundern, anzuhalten und zu genießen.
<G-vec00081-001-s071><stop.anhalten><en> State road 14, which today retraces the path of the old Via Annia, offers an opportunity to stop, admire and enjoy the heritage of the Friuli Latisana DOC area, the products of which the chairman and members of this consortium are pleased to offer the consumer.
<G-vec00081-001-s072><stop.anhalten><de> Unter diesen internationalen Richtlinien wäre es für die US-Marine illegal, ein Seefahrzeug in internationalen Gewässern anzuhalten, das der Regierung Nordkoreas, Syriens oder China gehört.
<G-vec00081-001-s072><stop.anhalten><en> Under these international guidelines it would be illegal for the U.S. Navy to stop a vessel belonging to the government of North Korea or Syria or China in international waters.
<G-vec00081-001-s073><stop.anhalten><de> drücken Sie dann abzuspielen oder anzuhalten, um die Musik auf each.you Steuerung können auch auf den Tasten 1, 2 oder 3, um zwischen verschiedenen Loops zu wechseln.
<G-vec00081-001-s073><stop.anhalten><en> Then press Play or Stop to control the music on each.You can also click buttons 1, 2, or 3 to switch between different loops.
<G-vec00081-001-s074><stop.anhalten><de> Da es zu spät war, den Wagen abzubremsen und anzuhalten, krachte der Wagen in die Leitplanke.
<G-vec00081-001-s074><stop.anhalten><en> As it was too late to brake and stop the car, the car ran in to the safety barrier.
<G-vec00081-001-s075><stop.anhalten><de> dass Sie genug Platz haben, um plötzlich anzuhalten, das Gleichgewicht zu halten und zu steuern.
<G-vec00081-001-s075><stop.anhalten><en> that you have enough room to suddenly stop, re-balance and steer.
