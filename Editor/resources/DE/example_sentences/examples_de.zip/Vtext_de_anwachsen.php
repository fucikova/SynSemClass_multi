<G-vec00468-001-s057><grow.anwachsen><de> Letztendlich wird Deine Seite so sehr anwachsen, dass sie Leads förmlich anzieht, sowohl durch Social Media als auch über direkte Suchanfragen.
<G-vec00468-001-s057><grow.anwachsen><en> Eventually, your site will grow to become a lead magnet, both from social media and from direct searchers.
<G-vec00468-001-s058><grow.anwachsen><de> Afrika vollzieht einen wirtschaftlichen, gesellschaftspolitischen und technologischen Wandel und wird in 25 Jahren auf 2,5 Milliarden Menschen anwachsen oder 25% der Weltbevölkerung erreichen.
<G-vec00468-001-s058><grow.anwachsen><en> Africa is undertaking an economic, socio-political and technology transformation and will grow to a 2.5 Billion population or will reach 25% of the world's population in 25 years.
<G-vec00468-001-s059><grow.anwachsen><de> Die Europäische Kommission schätzt, dass das Bruttosozialproduktwachstum der EU als Ganzes um 0,5% anwachsen werde – nicht gerade eine chinesische Zielvorgabe.
<G-vec00468-001-s059><grow.anwachsen><en> The European Commission (EC) estimates that the gross national product growth of the EU as a whole will grow by 0.5% - not exactly a Chinese target.
<G-vec00468-001-s060><grow.anwachsen><de> Sauberes Leben ist ihm etwas Fremdes und es gibt auch nicht die geringste Verbindung zwischen ihm und hehren Eigenschaften, denn er ist all dessen ledig, was ihn veranlassen könnte, sich ihnen zu nähern oder was in ihm die Charakteristika des Zutrauens zu ihnen respektive das Suchen nach ihnen oder das Sich-Befleißigen ihrer anwachsen lassen könnte.
<G-vec00468-001-s060><grow.anwachsen><en> A pure life is something foreign to him and there is not the slightest connection between him and noble qualities, for he is free of all what could induce him to approach them or what could let grow in him the confidence to them, or the search for them, or the effort to cultivate them.
<G-vec00468-001-s061><grow.anwachsen><de> Die Erwartung des Experten geht dahin, dass die Nachfrage nach komplett oder zumindest teilweise automatisierten Fahrzeugen in den nächsten Jahren stark anwachsen wird.
<G-vec00468-001-s061><grow.anwachsen><en> The expert expects demand for fully or at least partially automated vehicles will grow substantially in the coming years.
<G-vec00468-001-s062><grow.anwachsen><de> Die Weltbevölkerung wird bis 2075 weiter auf 9.22 Milliarden Menschen anwachsen, bevor die Zahl wieder sinken wird.
<G-vec00468-001-s062><grow.anwachsen><en> The world population will continue to grow over the next decades, reaching a plateau in 2075 at 9.22 billion people before it starts to decline.
<G-vec00468-001-s063><grow.anwachsen><de> Das dauert alles etwas - wie bei einem Baum, der erst anwachsen und sich verwurzeln muss, aber dann schnell wächst.
<G-vec00468-001-s063><grow.anwachsen><en> It's something like a tree, whose roots have to grow first, but then it suddenly awakens.
<G-vec00468-001-s064><grow.anwachsen><de> Listen sind gewöhnlicherweise der beste Ausgangspunkt, da sie wie Stapel auf Wunsch anwachsen können.
<G-vec00468-001-s064><grow.anwachsen><en> Lists are usually the best starting point since like stacks they can grow as needed.
<G-vec00468-001-s065><grow.anwachsen><de> Aufgrund der Korngröße von 2 - 4 mm können Pflanzen bestens anwachsen.
<G-vec00468-001-s065><grow.anwachsen><en> Due to a grain size of 2 - 4 mm, plants can grow on excellently.
<G-vec00468-001-s066><grow.anwachsen><de> Laut einem Bericht vo n Bain & Company* ist der Onlineh andel in Südostasien derzeit rund 6 Milliarden USD schwer, dürfte aber bis 2020 auf insgesamt 70 Milliarden USD anwachsen.
<G-vec00468-001-s066><grow.anwachsen><en> A report from Bain & Company * estimates that the online retail market in SEA is currently worth US $6 billion, but anticipates this could grow to $70 billion by 2020.
<G-vec00468-001-s067><grow.anwachsen><de> Die ausgewogene Mischung aus Sand, Torf, essenziellen Nährstoffen und Spurenelementen ermöglicht ein schnelles Anwachsen der Pflanzen und eine Versorgung der Pflanzen während der Anwachsphase (4 – 6 Wochen).
<G-vec00468-001-s067><grow.anwachsen><en> The balanced blend of sand, peat, essential nutrients and trace elements allows plants to grow on quickly. Also, the plants are supplied with nutrients during the first phase (4 – 6 weeks).
<G-vec00468-001-s068><grow.anwachsen><de> Fußnote: 1 Nach den Annahmen von RECIPE würden ohne Klimaschutz die CO2-Emissionen bis 2050 auf 2500 Gigatonnen (Gt) anwachsen und einen globalen Temperaturanstieg auf bis zu sieben Grad gegenüber vorindustriellem Niveau bedeuten.
<G-vec00468-001-s068><grow.anwachsen><en> [1] According to RECIPE assumptions, CO2 emissions without climate protection measures would grow to 2,500 metric gigatons (Gt) by 2050 and result in a global rise in temperature of up to 7°C over pre-industrial levels.
<G-vec00468-001-s069><grow.anwachsen><de> Ihre Elemente sind entfesselt, die Jahreszeiten werden unfreundlich, Plagen kommen auf und mehren sich, und zwar deshalb, weil eure Sünden anwachsen und Krankheiten bewirken, und weil die törichte und vermessene Wissenschaft nicht die Ordnung anerkennt, die vom Schöpfer bestimmt wurde.
<G-vec00468-001-s069><grow.anwachsen><en> It is because your sins grow, producing illnesses, and science, reckless and senseless, does not recognize the order established by the Creator.
<G-vec00468-001-s070><grow.anwachsen><de> Die Anzahl der Prozessoren pro System ist dabei mittlerweile im Millionenbereich angekommen und wird zukünftig noch stärker anwachsen als bisher.
<G-vec00468-001-s070><grow.anwachsen><en> The number of processors per system has now reached the millions and looks set to grow even faster in the future.
<G-vec00468-001-s071><grow.anwachsen><de> Der Vikinglotto-Jackpot kann auf ein Maximum von 35 Millionen Euro anwachsen.
<G-vec00468-001-s071><grow.anwachsen><en> The Vikinglotto jackpot can grow to a maximum of €35 million.
<G-vec00468-001-s072><grow.anwachsen><de> Auf diese Weise entstehen Wissenssammlungen, die viele Jahre umfassen und täglich weiter anwachsen.
<G-vec00468-001-s072><grow.anwachsen><en> This results in stores of knowledge that span a number of years and grow larger by the day.
<G-vec00468-001-s073><grow.anwachsen><de> Es ist jedoch eine Tatsache, dass seitdem die Kluft zwischen Arm und Reich ständig größer wurde, die Umwelt schwerer belastet wurde als je zuvor und Kriminalität, Arbeitslosigkeit, Unterernährung, Obdachlosigkeit und Krankheiten immer weiter anwachsen.
<G-vec00468-001-s073><grow.anwachsen><en> It is a fact, however, that the gap between the poor and the rich has increased continuously since then, environmental pollution has worsened, and criminality, unemployment, malnutrition, homelessness and disease continue to grow.
<G-vec00468-001-s074><grow.anwachsen><de> Das Anwachsen dieser Mittelschicht dürfte sich nach heutigen Erkenntnissen mittelfristig fortsetzen – ja in China zwischen 2010 und 2020 sogar verdoppeln.
<G-vec00468-001-s074><grow.anwachsen><en> Based on the latest information, this middle class will continue to grow in the medium term – even doubling in size in China between 2010 and 2020.
<G-vec00468-001-s075><grow.anwachsen><de> Seit 1921 sorgen die hochwertigen und langlebigen Berg- und Wanderschuhe von Hanwag dafür, dass die Müllberge nicht unnötig anwachsen.
<G-vec00468-001-s075><grow.anwachsen><en> Since 1921, Hanwag's high-quality and durable mountain and hiking boots have ensured that the mountains of rubbish do not grow unnecessarily.
<G-vec00510-001-s057><grow.anwachsen><de> Letztendlich wird Deine Seite so sehr anwachsen, dass sie Leads förmlich anzieht, sowohl durch Social Media als auch über direkte Suchanfragen.
<G-vec00510-001-s057><grow.anwachsen><en> Eventually, your site will grow to become a lead magnet, both from social media and from direct searchers.
<G-vec00510-001-s058><grow.anwachsen><de> Afrika vollzieht einen wirtschaftlichen, gesellschaftspolitischen und technologischen Wandel und wird in 25 Jahren auf 2,5 Milliarden Menschen anwachsen oder 25% der Weltbevölkerung erreichen.
<G-vec00510-001-s058><grow.anwachsen><en> Africa is undertaking an economic, socio-political and technology transformation and will grow to a 2.5 Billion population or will reach 25% of the world's population in 25 years.
<G-vec00510-001-s059><grow.anwachsen><de> Die Europäische Kommission schätzt, dass das Bruttosozialproduktwachstum der EU als Ganzes um 0,5% anwachsen werde – nicht gerade eine chinesische Zielvorgabe.
<G-vec00510-001-s059><grow.anwachsen><en> The European Commission (EC) estimates that the gross national product growth of the EU as a whole will grow by 0.5% - not exactly a Chinese target.
<G-vec00510-001-s060><grow.anwachsen><de> Sauberes Leben ist ihm etwas Fremdes und es gibt auch nicht die geringste Verbindung zwischen ihm und hehren Eigenschaften, denn er ist all dessen ledig, was ihn veranlassen könnte, sich ihnen zu nähern oder was in ihm die Charakteristika des Zutrauens zu ihnen respektive das Suchen nach ihnen oder das Sich-Befleißigen ihrer anwachsen lassen könnte.
<G-vec00510-001-s060><grow.anwachsen><en> A pure life is something foreign to him and there is not the slightest connection between him and noble qualities, for he is free of all what could induce him to approach them or what could let grow in him the confidence to them, or the search for them, or the effort to cultivate them.
<G-vec00510-001-s061><grow.anwachsen><de> Die Erwartung des Experten geht dahin, dass die Nachfrage nach komplett oder zumindest teilweise automatisierten Fahrzeugen in den nächsten Jahren stark anwachsen wird.
<G-vec00510-001-s061><grow.anwachsen><en> The expert expects demand for fully or at least partially automated vehicles will grow substantially in the coming years.
<G-vec00510-001-s062><grow.anwachsen><de> Die Weltbevölkerung wird bis 2075 weiter auf 9.22 Milliarden Menschen anwachsen, bevor die Zahl wieder sinken wird.
<G-vec00510-001-s062><grow.anwachsen><en> The world population will continue to grow over the next decades, reaching a plateau in 2075 at 9.22 billion people before it starts to decline.
<G-vec00510-001-s063><grow.anwachsen><de> Das dauert alles etwas - wie bei einem Baum, der erst anwachsen und sich verwurzeln muss, aber dann schnell wächst.
<G-vec00510-001-s063><grow.anwachsen><en> It's something like a tree, whose roots have to grow first, but then it suddenly awakens.
<G-vec00510-001-s064><grow.anwachsen><de> Listen sind gewöhnlicherweise der beste Ausgangspunkt, da sie wie Stapel auf Wunsch anwachsen können.
<G-vec00510-001-s064><grow.anwachsen><en> Lists are usually the best starting point since like stacks they can grow as needed.
<G-vec00510-001-s065><grow.anwachsen><de> Aufgrund der Korngröße von 2 - 4 mm können Pflanzen bestens anwachsen.
<G-vec00510-001-s065><grow.anwachsen><en> Due to a grain size of 2 - 4 mm, plants can grow on excellently.
<G-vec00510-001-s066><grow.anwachsen><de> Laut einem Bericht vo n Bain & Company* ist der Onlineh andel in Südostasien derzeit rund 6 Milliarden USD schwer, dürfte aber bis 2020 auf insgesamt 70 Milliarden USD anwachsen.
<G-vec00510-001-s066><grow.anwachsen><en> A report from Bain & Company * estimates that the online retail market in SEA is currently worth US $6 billion, but anticipates this could grow to $70 billion by 2020.
<G-vec00510-001-s067><grow.anwachsen><de> Die ausgewogene Mischung aus Sand, Torf, essenziellen Nährstoffen und Spurenelementen ermöglicht ein schnelles Anwachsen der Pflanzen und eine Versorgung der Pflanzen während der Anwachsphase (4 – 6 Wochen).
<G-vec00510-001-s067><grow.anwachsen><en> The balanced blend of sand, peat, essential nutrients and trace elements allows plants to grow on quickly. Also, the plants are supplied with nutrients during the first phase (4 – 6 weeks).
<G-vec00510-001-s068><grow.anwachsen><de> Fußnote: 1 Nach den Annahmen von RECIPE würden ohne Klimaschutz die CO2-Emissionen bis 2050 auf 2500 Gigatonnen (Gt) anwachsen und einen globalen Temperaturanstieg auf bis zu sieben Grad gegenüber vorindustriellem Niveau bedeuten.
<G-vec00510-001-s068><grow.anwachsen><en> [1] According to RECIPE assumptions, CO2 emissions without climate protection measures would grow to 2,500 metric gigatons (Gt) by 2050 and result in a global rise in temperature of up to 7°C over pre-industrial levels.
<G-vec00510-001-s069><grow.anwachsen><de> Ihre Elemente sind entfesselt, die Jahreszeiten werden unfreundlich, Plagen kommen auf und mehren sich, und zwar deshalb, weil eure Sünden anwachsen und Krankheiten bewirken, und weil die törichte und vermessene Wissenschaft nicht die Ordnung anerkennt, die vom Schöpfer bestimmt wurde.
<G-vec00510-001-s069><grow.anwachsen><en> It is because your sins grow, producing illnesses, and science, reckless and senseless, does not recognize the order established by the Creator.
<G-vec00510-001-s070><grow.anwachsen><de> Die Anzahl der Prozessoren pro System ist dabei mittlerweile im Millionenbereich angekommen und wird zukünftig noch stärker anwachsen als bisher.
<G-vec00510-001-s070><grow.anwachsen><en> The number of processors per system has now reached the millions and looks set to grow even faster in the future.
<G-vec00510-001-s071><grow.anwachsen><de> Der Vikinglotto-Jackpot kann auf ein Maximum von 35 Millionen Euro anwachsen.
<G-vec00510-001-s071><grow.anwachsen><en> The Vikinglotto jackpot can grow to a maximum of €35 million.
<G-vec00510-001-s072><grow.anwachsen><de> Auf diese Weise entstehen Wissenssammlungen, die viele Jahre umfassen und täglich weiter anwachsen.
<G-vec00510-001-s072><grow.anwachsen><en> This results in stores of knowledge that span a number of years and grow larger by the day.
<G-vec00510-001-s073><grow.anwachsen><de> Es ist jedoch eine Tatsache, dass seitdem die Kluft zwischen Arm und Reich ständig größer wurde, die Umwelt schwerer belastet wurde als je zuvor und Kriminalität, Arbeitslosigkeit, Unterernährung, Obdachlosigkeit und Krankheiten immer weiter anwachsen.
<G-vec00510-001-s073><grow.anwachsen><en> It is a fact, however, that the gap between the poor and the rich has increased continuously since then, environmental pollution has worsened, and criminality, unemployment, malnutrition, homelessness and disease continue to grow.
<G-vec00510-001-s074><grow.anwachsen><de> Das Anwachsen dieser Mittelschicht dürfte sich nach heutigen Erkenntnissen mittelfristig fortsetzen – ja in China zwischen 2010 und 2020 sogar verdoppeln.
<G-vec00510-001-s074><grow.anwachsen><en> Based on the latest information, this middle class will continue to grow in the medium term – even doubling in size in China between 2010 and 2020.
<G-vec00510-001-s075><grow.anwachsen><de> Seit 1921 sorgen die hochwertigen und langlebigen Berg- und Wanderschuhe von Hanwag dafür, dass die Müllberge nicht unnötig anwachsen.
<G-vec00510-001-s075><grow.anwachsen><en> Since 1921, Hanwag's high-quality and durable mountain and hiking boots have ensured that the mountains of rubbish do not grow unnecessarily.
<G-vec00510-001-s057><grow.anwachsen><de> Letztendlich wird Deine Seite so sehr anwachsen, dass sie Leads förmlich anzieht, sowohl durch Social Media als auch über direkte Suchanfragen.
<G-vec00510-001-s057><grow.anwachsen><en> Eventually, your site will grow to become a lead magnet, both from social media and from direct searchers.
<G-vec00510-001-s058><grow.anwachsen><de> Afrika vollzieht einen wirtschaftlichen, gesellschaftspolitischen und technologischen Wandel und wird in 25 Jahren auf 2,5 Milliarden Menschen anwachsen oder 25% der Weltbevölkerung erreichen.
<G-vec00510-001-s058><grow.anwachsen><en> Africa is undertaking an economic, socio-political and technology transformation and will grow to a 2.5 Billion population or will reach 25% of the world's population in 25 years.
<G-vec00510-001-s059><grow.anwachsen><de> Die Europäische Kommission schätzt, dass das Bruttosozialproduktwachstum der EU als Ganzes um 0,5% anwachsen werde – nicht gerade eine chinesische Zielvorgabe.
<G-vec00510-001-s059><grow.anwachsen><en> The European Commission (EC) estimates that the gross national product growth of the EU as a whole will grow by 0.5% - not exactly a Chinese target.
<G-vec00510-001-s060><grow.anwachsen><de> Sauberes Leben ist ihm etwas Fremdes und es gibt auch nicht die geringste Verbindung zwischen ihm und hehren Eigenschaften, denn er ist all dessen ledig, was ihn veranlassen könnte, sich ihnen zu nähern oder was in ihm die Charakteristika des Zutrauens zu ihnen respektive das Suchen nach ihnen oder das Sich-Befleißigen ihrer anwachsen lassen könnte.
<G-vec00510-001-s060><grow.anwachsen><en> A pure life is something foreign to him and there is not the slightest connection between him and noble qualities, for he is free of all what could induce him to approach them or what could let grow in him the confidence to them, or the search for them, or the effort to cultivate them.
<G-vec00510-001-s061><grow.anwachsen><de> Die Erwartung des Experten geht dahin, dass die Nachfrage nach komplett oder zumindest teilweise automatisierten Fahrzeugen in den nächsten Jahren stark anwachsen wird.
<G-vec00510-001-s061><grow.anwachsen><en> The expert expects demand for fully or at least partially automated vehicles will grow substantially in the coming years.
<G-vec00510-001-s062><grow.anwachsen><de> Die Weltbevölkerung wird bis 2075 weiter auf 9.22 Milliarden Menschen anwachsen, bevor die Zahl wieder sinken wird.
<G-vec00510-001-s062><grow.anwachsen><en> The world population will continue to grow over the next decades, reaching a plateau in 2075 at 9.22 billion people before it starts to decline.
<G-vec00510-001-s063><grow.anwachsen><de> Das dauert alles etwas - wie bei einem Baum, der erst anwachsen und sich verwurzeln muss, aber dann schnell wächst.
<G-vec00510-001-s063><grow.anwachsen><en> It's something like a tree, whose roots have to grow first, but then it suddenly awakens.
<G-vec00510-001-s064><grow.anwachsen><de> Listen sind gewöhnlicherweise der beste Ausgangspunkt, da sie wie Stapel auf Wunsch anwachsen können.
<G-vec00510-001-s064><grow.anwachsen><en> Lists are usually the best starting point since like stacks they can grow as needed.
<G-vec00510-001-s065><grow.anwachsen><de> Aufgrund der Korngröße von 2 - 4 mm können Pflanzen bestens anwachsen.
<G-vec00510-001-s065><grow.anwachsen><en> Due to a grain size of 2 - 4 mm, plants can grow on excellently.
<G-vec00510-001-s066><grow.anwachsen><de> Laut einem Bericht vo n Bain & Company* ist der Onlineh andel in Südostasien derzeit rund 6 Milliarden USD schwer, dürfte aber bis 2020 auf insgesamt 70 Milliarden USD anwachsen.
<G-vec00510-001-s066><grow.anwachsen><en> A report from Bain & Company * estimates that the online retail market in SEA is currently worth US $6 billion, but anticipates this could grow to $70 billion by 2020.
<G-vec00510-001-s067><grow.anwachsen><de> Die ausgewogene Mischung aus Sand, Torf, essenziellen Nährstoffen und Spurenelementen ermöglicht ein schnelles Anwachsen der Pflanzen und eine Versorgung der Pflanzen während der Anwachsphase (4 – 6 Wochen).
<G-vec00510-001-s067><grow.anwachsen><en> The balanced blend of sand, peat, essential nutrients and trace elements allows plants to grow on quickly. Also, the plants are supplied with nutrients during the first phase (4 – 6 weeks).
<G-vec00510-001-s068><grow.anwachsen><de> Fußnote: 1 Nach den Annahmen von RECIPE würden ohne Klimaschutz die CO2-Emissionen bis 2050 auf 2500 Gigatonnen (Gt) anwachsen und einen globalen Temperaturanstieg auf bis zu sieben Grad gegenüber vorindustriellem Niveau bedeuten.
<G-vec00510-001-s068><grow.anwachsen><en> [1] According to RECIPE assumptions, CO2 emissions without climate protection measures would grow to 2,500 metric gigatons (Gt) by 2050 and result in a global rise in temperature of up to 7°C over pre-industrial levels.
<G-vec00510-001-s069><grow.anwachsen><de> Ihre Elemente sind entfesselt, die Jahreszeiten werden unfreundlich, Plagen kommen auf und mehren sich, und zwar deshalb, weil eure Sünden anwachsen und Krankheiten bewirken, und weil die törichte und vermessene Wissenschaft nicht die Ordnung anerkennt, die vom Schöpfer bestimmt wurde.
<G-vec00510-001-s069><grow.anwachsen><en> It is because your sins grow, producing illnesses, and science, reckless and senseless, does not recognize the order established by the Creator.
<G-vec00510-001-s070><grow.anwachsen><de> Die Anzahl der Prozessoren pro System ist dabei mittlerweile im Millionenbereich angekommen und wird zukünftig noch stärker anwachsen als bisher.
<G-vec00510-001-s070><grow.anwachsen><en> The number of processors per system has now reached the millions and looks set to grow even faster in the future.
<G-vec00510-001-s071><grow.anwachsen><de> Der Vikinglotto-Jackpot kann auf ein Maximum von 35 Millionen Euro anwachsen.
<G-vec00510-001-s071><grow.anwachsen><en> The Vikinglotto jackpot can grow to a maximum of €35 million.
<G-vec00510-001-s072><grow.anwachsen><de> Auf diese Weise entstehen Wissenssammlungen, die viele Jahre umfassen und täglich weiter anwachsen.
<G-vec00510-001-s072><grow.anwachsen><en> This results in stores of knowledge that span a number of years and grow larger by the day.
<G-vec00510-001-s073><grow.anwachsen><de> Es ist jedoch eine Tatsache, dass seitdem die Kluft zwischen Arm und Reich ständig größer wurde, die Umwelt schwerer belastet wurde als je zuvor und Kriminalität, Arbeitslosigkeit, Unterernährung, Obdachlosigkeit und Krankheiten immer weiter anwachsen.
<G-vec00510-001-s073><grow.anwachsen><en> It is a fact, however, that the gap between the poor and the rich has increased continuously since then, environmental pollution has worsened, and criminality, unemployment, malnutrition, homelessness and disease continue to grow.
<G-vec00510-001-s074><grow.anwachsen><de> Das Anwachsen dieser Mittelschicht dürfte sich nach heutigen Erkenntnissen mittelfristig fortsetzen – ja in China zwischen 2010 und 2020 sogar verdoppeln.
<G-vec00510-001-s074><grow.anwachsen><en> Based on the latest information, this middle class will continue to grow in the medium term – even doubling in size in China between 2010 and 2020.
<G-vec00510-001-s075><grow.anwachsen><de> Seit 1921 sorgen die hochwertigen und langlebigen Berg- und Wanderschuhe von Hanwag dafür, dass die Müllberge nicht unnötig anwachsen.
<G-vec00510-001-s075><grow.anwachsen><en> Since 1921, Hanwag's high-quality and durable mountain and hiking boots have ensured that the mountains of rubbish do not grow unnecessarily.
