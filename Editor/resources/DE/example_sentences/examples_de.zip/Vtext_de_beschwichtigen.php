<G-vec00535-001-s051><reassure.beschwichtigen><de> „Ana, es hat nichts mit Ihnen zu tun“, murmelte mein Vater ein wenig verärgert und wollte sie beschwichtigen.
<G-vec00535-001-s051><reassure.beschwichtigen><en> “Ana, this is not about you,” my father murmurs a little chagrined, trying to reassure her.
<G-vec00535-001-s052><reassure.beschwichtigen><de> Also wollte ich ihn beschwichtigen.
<G-vec00535-001-s052><reassure.beschwichtigen><en> So I wanted to reassure him.
<G-vec00535-001-s053><reassure.beschwichtigen><de> Erstens könnten alle anderen Akteure – aber vor allem die europäischen ­Staaten und die aufstrebenden Mächte – die USA beschwichtigen, indem sie sich bereit erklären, einen größeren Teil der Lasten zu tragen (ähnlich dem, was einige europäische Länder nun bezüglich der NATO vorhaben).
<G-vec00535-001-s053><reassure.beschwichtigen><en> First, all the other players – but especially the European states and the rising powers – could reassure the US by agreeing to greater burden-sharing (akin to the strategies that some European countries are now employing with reference to NATO).
<G-vec00535-001-s054><reassure.beschwichtigen><de> Der Sohn, zunehmend verzweifelt, versucht ihn liebevoll zu beschwichtigen.
<G-vec00535-001-s054><reassure.beschwichtigen><en> The son, increasingly distraught, tries to reassure him lovingly.
<G-vec00535-001-s055><reassure.beschwichtigen><de> „Am Montag wird ein neues Auto geliefert“, sage ich beschwichtigend zu Anastasia, aber ich kann den grimmigen Ton in meiner Stimme nicht verbergen.
<G-vec00535-001-s055><reassure.beschwichtigen><en> “A replacement vehicle will arrive on Monday,” I say to Anastasia to reassure her, but I can’t take the grim tone off my voice.
