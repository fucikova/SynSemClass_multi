<G-vec00272-001-s152><charge.berechnen><de> Bei Stornierungen innerhalb von 7 Tagen nach Anreise berechnen wir die Hälfte der Gesamtfläche des Zimmers Gebühren für Ihre Reservierung.
<G-vec00272-001-s152><charge.berechnen><en> For cancellations received within 7 days of your scheduled arrival date, we will charge one-half of the total room charges for your reservation.
<G-vec00272-001-s153><charge.berechnen><de> Hunde sind bei uns willkommen, wir berechnen Ihnen CHF 15.00 pro Tag für Ihren Vierbeiner.
<G-vec00272-001-s153><charge.berechnen><en> Dogs are welcome in our hotel. We will charge CHF 15.00 per day & pet.
<G-vec00272-001-s154><charge.berechnen><de> Wir berechnen nur nach der Anzahl der gesendeten E-Mails.
<G-vec00272-001-s154><charge.berechnen><en> We only charge based on the amount of emails you send.
<G-vec00272-001-s155><charge.berechnen><de> "Von herauszufinden, die rate zu berechnen, die der Kunde für den Umgang mit komplizierten Umsatz-Steuer-ausfüllen von Formularen, es ist verständlich, dass Sie möchten, um zu schieben ""sales tax"" an die Nummer 39 auf Ihre riesige to-do-Liste."
<G-vec00272-001-s155><charge.berechnen><en> From figuring out which rate to charge which customer to dealing with complicated sales tax filing forms, it's understandable that you want to shove “sales tax” to number 39 on your massive to-do list.
<G-vec00272-001-s156><charge.berechnen><de> Wenn Sie am Flughafen ankommen und Ihr Gepäck mehr als Ihre Freigepäckgrenze wiegt, berechnen wir Ihnen eine Gebühr für jedes Kilogramm Übergewicht.
<G-vec00272-001-s156><charge.berechnen><en> If your hold luggage weighs more than your allowance when you arrive at the airport we charge you a fee for each 1kg of excess weight.
<G-vec00272-001-s157><charge.berechnen><de> (2) Entsteht uns durch die verspätete Abnahme ein Schaden, so sind wir berechtigt, pauschal 10 % des für die nicht abgenommene Leistung vereinbarten Entgelts als Schadensersatz zu berechnen, sofern uns der Kunde keinen niedrigeren Schaden nachweist.
<G-vec00272-001-s157><charge.berechnen><en> (2) If we suffer a loss due to the belated purchase, we are entitled to charge a lump sum of 10% of the value of the not rendered service as compensation, unless the customer can prove the damage is worth less.
<G-vec00272-001-s158><charge.berechnen><de> Versandkosten (inklusive gesetzliche Mehrwertsteuer) Lieferungen im Inland (Deutschland): Wir berechnen die Versandkosten pauschal mit 4,95 € pro Bestellung.
<G-vec00272-001-s158><charge.berechnen><en> Dispatch costs (inclusive of legally applicable VAT) Domestic deliveries (Germany): We charge a flat shipping fee of 4,95 € per order.
<G-vec00272-001-s159><charge.berechnen><de> Um Ihr Geld wieder Ihrem Konto gutzuschreiben, berechnen wir 10% Kosten mit einem Mindestbetrag von € 5,-.
<G-vec00272-001-s159><charge.berechnen><en> In this case we will transfer money to your account charging you 10% of the order’s amount and the minimum charge is € 5, -.
<G-vec00272-001-s160><charge.berechnen><de> Bei keiner Rückmeldung sehen wir uns leider gezwungen Ihnen ein day-use von EUR 20,– zu berechnen.
<G-vec00272-001-s160><charge.berechnen><en> Failure to notify us will result in a day-use charge of EUR 20.– .
<G-vec00272-001-s161><charge.berechnen><de> 3.2 Erhöhen sich bei Aufträgen, die später als vier Monate nach Abschluss ausgeliefert werden sollen, unsere Einkaufspreise und/oder der für uns gültige Lohn- und Gehaltstarif bis zur Ausführung des Auftrags, dürfen wir einen im Rahmen des prozentualen Anteils des Einkaufspreises und/oder der Lohnkosten am vereinbarten Preis verhältnismäßig entsprechend erhöhten Preis berechnen.
<G-vec00272-001-s161><charge.berechnen><en> 3.2 The following shall apply to orders which are to be delivered more than four months after conclusion of the contract: should our purchase prices and/or our applicable wages and salaries increase until the time the contract is executed, we shall be entitled to charge a higher price on a pro rata basis as a percentage of the purchase price and/or the labour costs.
<G-vec00272-001-s162><charge.berechnen><de> Und während App-Design-Firmen dir teure Entwickler- und Designergebühren berechnen würden, ist nichts davon mit dem Angebot von Phorest Salon Software erforderlich.
<G-vec00272-001-s162><charge.berechnen><en> While app design companies would charge you expensive developer and designer fees, none of that is required with Phorest Salon Software’s proposition.
<G-vec00272-001-s163><charge.berechnen><de> Wenn Sie später stornieren, als die Unterkunft als Termin festlegt oder nicht über die Stornierung der Reservierung informiert, kann die Unterkunft Ihnen einen Betrag berechnen, der in den meisten Fällen der Höhe der ersten Nacht entspricht.
<G-vec00272-001-s163><charge.berechnen><en> If you cancel later than the accommodation establishes as a deadline or does not notify of the cancellation of the reservation, the accommodation may charge you an amount which in most cases is equivalent to the amount of the first night.
<G-vec00272-001-s164><charge.berechnen><de> Unser Arrangement für eine Stornierung ist wie folgt: Wenn Sie mehr als zehn Tage im Voraus kündigen, wird nicht berechnen wir Ihnen nichts.
<G-vec00272-001-s164><charge.berechnen><en> Our arrangement for a cancellation is as follows: If you cancel more than ten days in advance, we will not charge you anything.
<G-vec00272-001-s165><charge.berechnen><de> Die Preise berechnen wir 1 € Kurtaxe pro Person pro Nacht.
<G-vec00272-001-s165><charge.berechnen><en> The prices we charge 1 EUR City tax per person per night.
<G-vec00272-001-s166><charge.berechnen><de> Wir berechnen eine einmalige Bearbeitungs- und Versandpauschale von 14,90 € pro Buchung.
<G-vec00272-001-s166><charge.berechnen><en> We charge a one time handling fee of € 14.90 per booking.
<G-vec00272-001-s167><charge.berechnen><de> Werden vom Kunden Abruftermine nicht eingehalten, so sind wir berechtigt, vier Wochen nach schriftlicher Ankündigung unter Hinweis auf die Folgen des unterbliebenen Abrufes, die Gesamtmenge vollständig zu liefern und zu berechnen.
<G-vec00272-001-s167><charge.berechnen><en> If release order dates are not adhered to by the customer then we are entitled to delivery and to charge in full four weeks after the written announcement with reference to the consequences of the release order which was not carried out.
<G-vec00272-001-s168><charge.berechnen><de> Bei Zahlungsverzug ist Firma TUNZE Aquarientechnik GmbH, berechtigt, Verzugszinsen in Höhe von 1 % über dem jeweiligen Eigendiskontsatz zu berechnen.
<G-vec00272-001-s168><charge.berechnen><en> In the event of delayed payment TUNZE Aquarientechnik GmbH is entitled to charge interest on arrears amounting to 1% above our rate of discount.
<G-vec00272-001-s169><charge.berechnen><de> Ein Vermerk, wie etwa „zuzüglich der üblichen Nebenspesen“ berechtigt den Spediteur, Sondergebühren und Sonderauslagen zusätzlich zu berechnen.
<G-vec00272-001-s169><charge.berechnen><en> A note, such as “plus the usual ancillary charges” entitles the freight forwarder, Special charges and to charge for supplements.
<G-vec00272-001-s170><charge.berechnen><de> Wir berechnen eine Versandkostenpauschale in Höhe von 2,95 Euro für alle Lieferungen innerhalb von Deutschland und unabhängig von der Anzahl der bestellten Artikel oder der Höhe des Bestellwertes.
<G-vec00272-001-s170><charge.berechnen><en> We charge a shipping fee of EUR 2.95 for all deliveries within Germany, regardless of the number of items ordered or the amount of the order value.
<G-vec00003-001-s097><estimate.berechnen><de> Berechnen wir die benötigte Zeit, die der Kühler benötigt, um eine stabile Temperaturlage zu erreichen.
<G-vec00003-001-s097><estimate.berechnen><en> Let us estimate the time required for the device to reach a steady thermal state.
<G-vec00003-001-s098><estimate.berechnen><de> Ich würde vorschlagen $16 für diese Situation zu berechnen.
<G-vec00003-001-s098><estimate.berechnen><en> I’d be inclined to estimate $16 or so for this situation.
<G-vec00003-001-s099><estimate.berechnen><de> Berechnen Sie Ihre Fahrtstrecke nach Zagora mit Hilfe der google Landkarte.
<G-vec00003-001-s099><estimate.berechnen><en> Estimate the distance of your trip using the google map.
<G-vec00003-001-s100><estimate.berechnen><de> Die vorherige Positionsvorhersage wird mit der durch das Radar gemessenen Position verglichen, um eine neue genauere Vorhersage für den nächsten Scan zu berechnen.
<G-vec00003-001-s100><estimate.berechnen><en> The latest track prediction is combined with the associated plot to provide a new, improved estimate of the next target state.
<G-vec00003-001-s101><estimate.berechnen><de> Außerdem müssen Sie die Endgröße des fertigen Produkts manuell berechnen, indem Sie die Randanschnittgröße von der Größe des Maskenrahmens subtrahieren.
<G-vec00003-001-s101><estimate.berechnen><en> In this workflow, you must manually estimate the finish size of the final product by subtracting bleed size from the size of the crop box.
<G-vec00003-001-s102><estimate.berechnen><de> Außerdem müssen Sie die Endgröße des fertigen Produkts manuell berechnen, indem Sie die Randanschnittgröße von der Größe des Maskenrahmens subtrahieren.
<G-vec00003-001-s102><estimate.berechnen><en> In this finish size workflow, you must manually estimate the finish size of the final product by subtracting bleed size from the size of the crop box.
<G-vec00003-001-s103><estimate.berechnen><de> Ich würde vorschlagen $16 für diese Situation zu berechnen.
<G-vec00003-001-s103><estimate.berechnen><en> I'd be inclined to estimate $16 or so for this situation.
<G-vec00345-001-s029><reckon.berechnen><de> Jetzt nach mehr als ein Jahrhundert und mit der Bestätigung von Tausenden der wissenschaftlichen Reports, gibt CO2 die bemerkenswerteste Antwort aller Nährstoffe in der Betriebsmasse, ist- normalerweise im kurzen Versorgungsmaterial und begrenzt fast immer für Fotosynthese…, welches das steigende Niveau des atmosphärischen CO2 eine allgemeinhin freie Prämie ist und gewinnt in der Größe mit Zeit, auf der alle wir während der absehbaren Zukunft berechnen können.
<G-vec00345-001-s029><reckon.berechnen><en> Now, after more than a century, and with the confirmation of thousands of scientific reports, CO2 gives the most remarkable response of all nutrients in plant bulk, is usually in short supply, and is nearly always limiting for photosynthesis … The rising level of atmospheric CO2 is a universally free premium, gaining in magnitude with time, on which we can all reckon for the foreseeable future.
<G-vec00345-001-s030><reckon.berechnen><de> Nestle-Stahl ist eine Kraft, zum mit im Feld der Herstellung zu berechnen und erstklassige Qualität 17-4PH ASTM A564 Stangen exportierend, ordnen Sie 630 Produkte AISI 630.
<G-vec00345-001-s030><reckon.berechnen><en> Nestle Steel is a force to reckon with in the field of manufacturing and exporting premium quality 17-4PH ASTM A564 Bars Grade 630 AISI 630 Products.
<G-vec00345-001-s031><reckon.berechnen><de> 23 so soll der Priester berechnen, was er gilt bis an das Halljahr; und soll desselben Tages solche Schätzung geben, daß sie dem HERRN heilig sei.
<G-vec00345-001-s031><reckon.berechnen><en> 23 then the priest shall reckon to him the worth of your valuation up to the Year of Jubilee; and he shall give your valuation on that day, as a holy thing to the Lord.
<G-vec00345-001-s032><reckon.berechnen><de> 23 so soll ihm der Priester den Betrag nach deiner Schatzung berechnen bis zum Jubeljahr, und er soll an demselben Tage den Schatzungswert geben, daß es dem HERRN geweiht sei.
<G-vec00345-001-s032><reckon.berechnen><en> 23 the priest shall reckon unto him the amount of thy valuation, unto the year of the jubilee; and he shall give thy valuation on that day, as holy to Jehovah.
<G-vec00345-001-s033><reckon.berechnen><de> 23 so soll der Priester berechnen, was er gilt bis an das Halljahr; und soll desselben Tages solche Schätzung geben, daß sie dem HERRN heilig sei.
<G-vec00345-001-s033><reckon.berechnen><en> 23 then the priest shall reckon unto him the worth of thy estimation unto the year of jubilee: and he shall give thine estimation in that day, as a holy thing unto Jehovah.
<G-vec00345-001-s034><reckon.berechnen><de> 23 so soll der Priester berechnen, was er gilt bis zum Erlaßjahr, und er soll diese Summe am selben Tage geben, daß sie dem HERRN heilig sei.
<G-vec00345-001-s034><reckon.berechnen><en> 23 The priest shall reckon the price according to the number of years: unto the jubilee: and he that had vowed, shall give that to the Lord.
<G-vec00272-001-s171><charge.berechnen><de> Wenn Sie weniger als 48 Stunden im voraus, oder im Falle eines no-Show abbrechen, we.ll berechnet Ihnen den vollen Betrag.
<G-vec00272-001-s171><charge.berechnen><en> If you cancel less than 48 hours in advance, or in the case of a no show, we.ll charge you the full amount.
<G-vec00272-001-s172><charge.berechnen><de> Bei allen Buchungen von 7 Nächten oder mehr berechnet das Hotel eine nicht erstattbare Anzahlung in der Höhe von 3 Übernachtungen.
<G-vec00272-001-s172><charge.berechnen><en> For all reservations of 7 nights or more, the hotel will charge a non-refundable deposit equivalent to 3 nights.
<G-vec00272-001-s173><charge.berechnen><de> Bitte beachten Sie, dass das Hotel im Falle einer vorzeitigen Abreise den gesamten Betrag des gebuchten Aufenthalts berechnet.
<G-vec00272-001-s173><charge.berechnen><en> Please note that in case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s174><charge.berechnen><de> Bitte beachten Sie, dass für die Buchung des Frühstücks ein Aufpreis berechnet wird.
<G-vec00272-001-s174><charge.berechnen><en> Please note that extra charge will apply if guests upgrade the breakfast.
<G-vec00272-001-s175><charge.berechnen><de> Bitte beachten Sie, dass für die Nutzung der Sauna ein Aufpreis berechnet wird.
<G-vec00272-001-s175><charge.berechnen><en> Please note there is an extra charge for using the sauna.
<G-vec00272-001-s176><charge.berechnen><de> Reisen Sie vor dem gebuchten Zeitpunkt ab, berechnet das Hotel den Betrag für den gesamten Aufenthalt.
<G-vec00272-001-s176><charge.berechnen><en> In case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s177><charge.berechnen><de> Für den Zimmerservice und die Nutzung des Konferenzraums wird kein Aufschlag berechnet.
<G-vec00272-001-s177><charge.berechnen><en> Room service and use of the conference hall are free of any surplus charge.
<G-vec00272-001-s178><charge.berechnen><de> WLAN-Internetzugang; geräumige, helle Zimmer; ein Restaurant und eine Bar; eine wunderschöne Sommerterrasse mit Blick auf den See und den Garten; eine große, helle Lobby, Parkplatz (wird extra berechnet); 3 Konferenzräume mit Tageslichteinfall, Klimaanlage und Platz für bis zu 140 Teilnehmer.
<G-vec00272-001-s178><charge.berechnen><en> The hotel provides WiFi internet; spacious and bright rooms; a restaurant and a bar; a pretty terrace with fabulous views of the lake and gardens; a large, well-lit hall, outdoor parking (additional charge); 3 meeting rooms with natural light, air conditioning and a maximum capacity for up to 140 people.
<G-vec00272-001-s179><charge.berechnen><de> Stornierungen müssen bis spätestens 2 Wochen vor der Ankunft erfolgen, andernfalls werden Stornierungsgebühren berechnet.
<G-vec00272-001-s179><charge.berechnen><en> Cancellations must be made no later than 2 weeks prior to arrival or a cancellation charge applies.
<G-vec00272-001-s180><charge.berechnen><de> [1] Das Abheben von Bargeld über die DKB-Karten ist in der Praxis zu über 99 Prozent kostenlos, weil die DKB ihren Kunden keine Gebühren berechnet und die Gebühren der Fremdautomaten automatisch übernimmt.
<G-vec00272-001-s180><charge.berechnen><en> [1] Withdrawing cash through the DKB-card is in practice free of charge in more than 99 per cent of cases, because the DKB does not charge its customers any fees and takes the fees of foreign ATMs automatically.
<G-vec00272-001-s181><charge.berechnen><de> Bei Auslandsfahrten wird kein Nachtzuschlag berechnet.
<G-vec00272-001-s181><charge.berechnen><en> No additional night charge is made for journeys abroad.
<G-vec00272-001-s182><charge.berechnen><de> Bitte beachten Sie, dass die Unterkunft bei der Buchung eine Anzahlung von 25 % des Gesamtpreises berechnet.
<G-vec00272-001-s182><charge.berechnen><en> Please note that the property will charge a 25% deposit at the moment of booking.
<G-vec00272-001-s183><charge.berechnen><de> Wenn Sie eine Kredit- oder Debitkarte für die vollständige oder teilweise Finanzierung von internationalen persönlichen Zahlungen verwenden, berechnet PayPal eine Auslandsgebühr, die zwischen 2,9 % und 7,4 % zuzüglich einer festen Gebühr betragen kann.
<G-vec00272-001-s183><charge.berechnen><en> If you use a credit or debit card to fully or partially fund international personal payments, PayPal will charge a cross border fee, which can range from 2.9% to 7.4% plus an additional fixed fee.
<G-vec00272-001-s184><charge.berechnen><de> • Das Kreditkarteninstitut berechnet in der Regel bei Käufen in fremder Währung eine zusätzliche Gebühr (Fremdwährungszuschlag).
<G-vec00272-001-s184><charge.berechnen><en> • Credit card companies usually charge an additional fee for purchases in foreign currencies (foreign currency fee).
<G-vec00272-001-s185><charge.berechnen><de> mit Küchenzeile, Kaffeemaschine, Toaster, Wasserkocher,Terrasse, Bettwäsche ist vorhanden, Handtücher und Geschirrtücher sind selber mitzubringen oder zu mieten (wird extra berechnet).
<G-vec00272-001-s185><charge.berechnen><en> with kitchenette, coffee maker, toaster, electric kettle, terrace, bed linen is available, towels and tea towels are not themselves or rent (extra charge) .
<G-vec00272-001-s186><charge.berechnen><de> Bitte beachten Sie, dass die NürnbergMesse GmbH im Falle von Zuwiderhandlung eine Gebühr von EUR 800 berechnet.
<G-vec00272-001-s186><charge.berechnen><en> Please note that NÃ1⁄4rnbergMesse GmbH will charge a fee of EUR 800 in the event of a contravention of this.
<G-vec00272-001-s187><charge.berechnen><de> Bitte beachten Sie, dass ein Aufpreis berechnet wird und diese Anfragen der Verfügbarkeit unterliegen.
<G-vec00272-001-s187><charge.berechnen><en> Please note that there is an extra charge and these requests are based on availability.
<G-vec00272-001-s188><charge.berechnen><de> Pro Hund und Nacht wird ein Aufpreis berechnet.
<G-vec00272-001-s188><charge.berechnen><en> There will be an extra charge per dog per night.
<G-vec00272-001-s189><charge.berechnen><de> 2.7 Für die Abwicklung bloßer Lieferaufträge ohne Montage mit einem Rechnungswert bis zu 50,00 € netto berechnet ABASS GMBH eine Bearbeitungspauschale von 5,00 € zuzüglich Mehrwertsteuer.
<G-vec00272-001-s189><charge.berechnen><en> 2.7 For the processing of mere supply contracts without set-up with an invoice amount of 50,00€, ABASS GmbH shall charge a processing fee of 5,00€ plus value-added tax.
<G-vec00345-001-s035><reckon.berechnen><de> Berechnet, wieviel jeder gegeben hat.
<G-vec00345-001-s035><reckon.berechnen><en> """Reckon how much each one has given."
<G-vec00345-001-s036><reckon.berechnen><de> Manchmal werden, wenn ein Spieler fertig wird, für jedes Blatt mit 8 oder mehr Karten doppelte Strafpunkte berechnet.
<G-vec00345-001-s036><reckon.berechnen><en> Some reckon double penalty points for any hand with 8 or more cards when someone finishes.
<G-vec00169-001-s038><reclaim.berechnen><de> In bestimmten Fällen kann der Bauherr jedoch die berechnete Umsatzsteuer in den auf seinen Namen ausgestellten Rechnungen im Wert von 5 Millionen HUF (ca.
<G-vec00169-001-s038><reclaim.berechnen><en> In specific cases, however, the builder may reclaim the VAT content of invoices issued in its name up to HUF 5 million (approx.
<G-vec00169-001-s068><reclaim.berechnen><de> Im Falle einer Rechnung mit Ausweis der ausländischen Mehrwertsteuer kann die inländische Gesetzgebung im gegebenen Land die Geltendmachung der berechneten ausländischen Mehrwertsteuer im Rahmen des Vorsteuervergütungsverfahrens einschränken.
<G-vec00169-001-s068><reclaim.berechnen><en> With an invoice including foreign VAT, local legislation may restrict the amount of refundable VAT – through a foreign VAT reclaim – in the given country.
