<G-vec00057-001-s038><turn.abbiegen><de> Nach 2.5 Km rechts abbiegen, Richtung Nizza Monferrato (19.5 Km).
<G-vec00057-001-s038><turn.abbiegen><en> After 2.5 Km, turn right in the direction of Nizza Monferrato (Km. 19.5).
<G-vec00057-001-s039><turn.abbiegen><de> Abbiegen Richtung Ockelbo Straße 303. dann Richtung Zentrum und dann an der Kirche vorbei und biegen Sie die erste Straße rechts auf Åmotvägen gegen Rönnåsen.
<G-vec00057-001-s039><turn.abbiegen><en> Turn towards Ockelbo road 303rd Drive then towards the center and then past the church and turn first right on Åmotvägen against Rönnåsen.
<G-vec00057-001-s040><turn.abbiegen><de> Bei die Kreuzung-Straße zu erreichen; rechts abbiegen.
<G-vec00057-001-s040><turn.abbiegen><en> When reaching the crossing road; turn right.
<G-vec00057-001-s041><turn.abbiegen><de> "Am ""Doppel M"" rechts abbiegen in die Alte Messe und 400 m geradeaus bis zum Pantheon."
<G-vec00057-001-s041><turn.abbiegen><en> "Turn right at the ""double M""-sign and go straight for 400 m till you reach the Pantheon."
<G-vec00057-001-s042><turn.abbiegen><de> Im Jahr 1916 bauten wir rechts abbiegen.
<G-vec00057-001-s042><turn.abbiegen><en> In 1916, we built the right turn.
<G-vec00057-001-s043><turn.abbiegen><de> An der Kirche rechts abbiegen und Via Lamarmora nehmen.
<G-vec00057-001-s043><turn.abbiegen><en> At the church turn right and take Via Lamarmora.
<G-vec00057-001-s044><turn.abbiegen><de> Am Ende des König-George Street rechts abbiegen in die Randall Street und weiter einen Block bis zur ersten Ampel, die die Schnittmenge von Randall und Prince George Street ist.
<G-vec00057-001-s044><turn.abbiegen><en> At the end of King George Street make a right turn onto Randall Street and continue one block to the first traffic light, which is the intersection of Randall Street and Prince George Street.
<G-vec00057-001-s045><turn.abbiegen><de> Von Livigno nehmen wir den Passo del Foscagno und gelangen so nach Bormio, wo wir Richtung Umbrailpass/Stilfserjoch abbiegen.
<G-vec00057-001-s045><turn.abbiegen><en> From Livigno we take the Passo del Foscagno and come to Bormio, where we will turn to Umbrailpass/Stilfserjoch.
<G-vec00057-001-s046><turn.abbiegen><de> Gleich danach nach links abbiegen und der Straße folgen.
<G-vec00057-001-s046><turn.abbiegen><en> Turn left shortly afterwards and follow the road.
<G-vec00057-001-s047><turn.abbiegen><de> An den Häusern, rechts abbiegen und dann, höher, weiter in Richtung Les Grangeols.
<G-vec00057-001-s047><turn.abbiegen><en> At the houses, turn right and then, higher up, continue towards Les Grangeols.
<G-vec00057-001-s048><turn.abbiegen><de> (4 km) bis ins Stadtgebiet - 300m nach der Shell-Tankstelle an der großen Ampelkreuzung rechts abbiegen (Ausschilderung Hotelroute), nach 700 m rechts abbiegen und der Ausschilderung Parkhotel folgen.
<G-vec00057-001-s048><turn.abbiegen><en> (4 km) into the town - Turn right 300 m after the Shell gas station at the major traffic light intersection (Hotel route sign), after 700 m turn right and follow signs for the Parkhotel.
<G-vec00057-001-s049><turn.abbiegen><de> An der dritten Ampel rechts abbiegen Richtung Furtwangen/Kurgebiet/Polizei.
<G-vec00057-001-s049><turn.abbiegen><en> At the third traffic lights, turn right towards Furtwangen/Kurgebiet/Polizei.
<G-vec00057-001-s050><turn.abbiegen><de> Richtung Novigrad - Tar: An der Kreuzung bei der Tankstelle rechts zu Lanterna abbiegen.
<G-vec00057-001-s050><turn.abbiegen><en> Novigrad - Tar direction: Turn right at the intersection towards Lanterna at the petrol station.
<G-vec00057-001-s051><turn.abbiegen><de> Sie erreichen eine Kreuzung, an der Sie Rechts auf eine Asphaltstraße abbiegen, die Sie zum Restaurant führt.
<G-vec00057-001-s051><turn.abbiegen><en> You will reach a crossroads where you will turn right onto an asphalt road that will take you to a restaurant.
<G-vec00057-001-s052><turn.abbiegen><de> Wenn Sie links abbiegen, kommen Sie zur Anlegestelle der Spree – gut geeignet für eine Kaffeepause.
<G-vec00057-001-s052><turn.abbiegen><en> If you turn left, you will come to the pier on the Spree, a fine spot for a coffee break.
<G-vec00057-001-s053><turn.abbiegen><de> Vor der Brücke der Mühle, am Kreisverkehr links abbiegen.
<G-vec00057-001-s053><turn.abbiegen><en> Before the paper mill bridge, at the roundabout turn left.
<G-vec00057-001-s054><turn.abbiegen><de> Der Weg führt uns zum Dorf Koti, wo wir rechts abbiegen und bis nach Grčevje und weiter auf der Straße vorbei an der Fischzucht und der Grotte Beceletova jama (Denkmal des Volksbefreiungskampfes NOB) nach Stari grad gelangen.
<G-vec00057-001-s054><turn.abbiegen><en> We cross the stream over the footbridge and afterwards turn left and continue our path towards the Lešnica stream. The trail leads us to the village of Koti, where we turn right and go to Grčevja.
<G-vec00057-001-s055><turn.abbiegen><de> Anfahrt ParkgarageÂ - Wenn Sie sich auf der Hodzovo namestie neben dem Crowne Plaza befinden biegen Sie nach rechts ab auf die Straße Postova – dann die erste links abbiegen in die Vysoka – nach ein paar Metern können Sie unsere Garageneinfahrt sehen und in dieser parken.
<G-vec00057-001-s055><turn.abbiegen><en> Directions Parking garage Hotel Bratislava Â - If you are on the Hodzovo namestie next to the Crowne Plaza turn right onto Postova Street – then the first left into Vysoka – after a few meters you will be able to turn right into our garage.
<G-vec00057-001-s056><turn.abbiegen><de> B7 in Bahnhofstraße abbiegen und dieser folgen- Am Schild Bahngelände, Anlieger fre` vorbeifahren dann noch ca 250m bis zum Alten Bahnhof.
<G-vec00057-001-s056><turn.abbiegen><en> B7 turn into Bahnhofstrasse and the following sign on railway land, riparian fre` pass still 250m to the old railway station.
