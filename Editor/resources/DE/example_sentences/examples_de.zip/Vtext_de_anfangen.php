<G-vec00179-001-s076><start.anfangen><de> Innovation war das Markenzeichen von Grote Industries von Anfang an.
<G-vec00179-001-s076><start.anfangen><en> Innovation has been the hallmark of Grote Industries from the start.
<G-vec00179-001-s077><start.anfangen><de> Diese begann im Urwald weit oben im Whakarewarewa Forest, aber war sehr viel besser fahrbar als Stage eins, und es ging netterweise von Anfang an bergab.
<G-vec00179-001-s077><start.anfangen><en> Stage four began in the native forest up high in the Whakarewarea Forest but was a good deal more rideable than stage one and began descending from the very start which was nice!
<G-vec00179-001-s078><start.anfangen><de> Unsere Strukturen sind Kosten wettbewerbsfähig von Anfang an, aber wir wissen, dass die Anfangskosten nur ein Teil des Bildes sind.
<G-vec00179-001-s078><start.anfangen><en> Sprung buildings are cost-competitive from the start, but we know that up-front costs are only part of the picture.
<G-vec00179-001-s079><start.anfangen><de> Und in dieser Berufung ruft Gott Abraham nicht allein, als Einzelnen, sondern er bezieht von Anfang an seine Familie, seine Verwandtschaft und alle ein, die im Dienst an seinem Haus stehen.
<G-vec00179-001-s079><start.anfangen><en> And in this vocation God did not call Abraham alone, as an individual, but involved from the start his family, his household and all those in service to his house.
<G-vec00179-001-s080><start.anfangen><de> Der flinke und wendige Kleintransporter stellte von Anfang an einen echten Verkaufsschlager dar und wird heute europaweit eingesetzt.
<G-vec00179-001-s080><start.anfangen><en> The swift and agile utility vehicle has been a real bestseller right from the start and is used all over Europe today.
<G-vec00179-001-s081><start.anfangen><de> "Es gibt so viele Anpassungen von Anfang an, dass es normal ist, ein paar schwierige Momente zu machen "", bot Lefebvre über seine Schüler Nygren, der den Sprung von Europa nach Nordamerika im Laufe des Sommers gemacht."
<G-vec00179-001-s081><start.anfangen><en> There are so many adjustments to make right from the start that it’s normal to have a few difficult moments,” offered Lefebvre about his pupil Nygren, who made the jump from Europe to North America over the course of the summer.
<G-vec00179-001-s082><start.anfangen><de> Wir erforschen neue methodologische Mittel als Alternativen zur akademischen Erklärung, weil wir glauben, dass man sich dort, wo diese Erklärung vorherrscht, vor allem auf ein rein erklärendes Wissen beruft; ein Wissen, das kaum jemals in Situationen zur Anwendung kommt, da die theoretischen Mittel von Anfang an nicht als konzeptuelle Werkzeuge für ein Operieren in konkreten Situationen gedacht werden, sondern vielmehr ein konzeptuelles Wissen darstellen, das erst erlernt und dann abspeichert.
<G-vec00179-001-s082><start.anfangen><en> If we explore methodologies that are alternative to academic-lecture like explanations, it is because we believe that where explanation predominates- so does a type of purely declarative knowledge. This type of knowledge is difficult to reuse in a concrete situation given that, from the start, the theory used is not understood as a conceptual tool that can act in a concrete situation but rather as conceptual knowledge that must be learned in order to be archived.
<G-vec00179-001-s083><start.anfangen><de> Der Aufstieg ist von Anfang an sehr steil.
<G-vec00179-001-s083><start.anfangen><en> The ascent is very zooming right from the start.
<G-vec00179-001-s084><start.anfangen><de> Dadurch bieten sie genügend Robustheit für Ihre spezifische Applikation und liefern Ihnen zuverlässige Ergebnisse von Anfang an.
<G-vec00179-001-s084><start.anfangen><en> They therefore offer sufficient robustness for your specific application and provide you with reliable results from the start. Available product versions
<G-vec00179-001-s085><start.anfangen><de> Da ich von Anfang an dabei war, habe ich ein besonderes Verhältnis zu dem Spiel.
<G-vec00179-001-s085><start.anfangen><en> Since I have been there from the very start, I have a special relationship with the game.
<G-vec00179-001-s086><start.anfangen><de> Eine professionelle Installation gewährleistet die direkte Bereitstellung, sofortige Verwendung und optimale Produktivität von Anfang an.
<G-vec00179-001-s086><start.anfangen><en> Professional installation ensures direct deployment, immediate use and optimal productivity right from the start.
<G-vec00179-001-s087><start.anfangen><de> Die Kinder waren von Anfang an ein Teil des Projekts.
<G-vec00179-001-s087><start.anfangen><en> The children have been a part of the project right from the start.
<G-vec00179-001-s088><start.anfangen><de> Von Anfang an und in allen Varianten verfügte es über eine Automatikblende, d. h. die Kamera schließt die Blende im Moment der Aufnahme von alleine auf den vorher am Objektiv eingestellten Wert.
<G-vec00179-001-s088><start.anfangen><en> Right from the start and in all variations it had an automatic aperture, the camera body automatically closes the aperture to the value set on the lens prior to exposure.
<G-vec00179-001-s089><start.anfangen><de> Ebenso sind die wesentlichen Fragen der proletarischen Diktatur und der Aufgabe der Partei richtig und konsequent gestellt worden, wie es sich auch in der von Anfang an gestellten Forderung nach Spaltung der SPI zeigte.
<G-vec00179-001-s089><start.anfangen><en> It correctly set out the essential problems of the proletarian dictatorship and the party’s tasks, and from the very start defended the necessity of a split in the Socialist Party.
<G-vec00179-001-s090><start.anfangen><de> Erinnere dich daran, dass diese ersten 3 1⁄2 Jahre schreckliche Jahre von wirtschaftlichen und politischen Durcheinander, Verfolgung und Bedrängnis sein werden, wie wir es auch in der Offenbarung sehen können – jeder, der am Leben ist und die Schrift kennt, wird von Anfang an wissen wer er ist.
<G-vec00179-001-s090><start.anfangen><en> Remember, those first 3 1/2 years will be horrible years of economic and political turmoil, persecution, and hardship as seen also in The Revelation - anyone alive who knows scripture will know who he is from the start.
<G-vec00179-001-s091><start.anfangen><de> Dies werden wir aber Schritt für Schritt und NICHT von Anfang an machen, denn dann kann man besser reagieren und es bleibt auch übersichtlicher.
<G-vec00179-001-s091><start.anfangen><en> But this we will do step by step and NOT just immediately after the start, because then we can act better and everything stays clean.
<G-vec00179-001-s092><start.anfangen><de> """Durch die Zusammenarbeit mit COA-Entwicklern können wir ihnen dabei helfen, von Anfang an Übersetzbarkeit in Maßnahmen zu übertragen."
<G-vec00179-001-s092><start.anfangen><en> """Working together with COA developers we can help them design translatability into measures from the start."
<G-vec00179-001-s093><start.anfangen><de> Fachleute sind wählerischer: Sie greifen von Anfang an in das PB Swiss Tools Werkzeugset.
<G-vec00179-001-s093><start.anfangen><en> They pick tools from the PB Swiss Tools set right from the start.
<G-vec00179-001-s094><start.anfangen><de> Wir begleiten Ihr Projekt von Anfang an – mit kompetenter Beratung, einer vollständigen CAD-Datenbank und schneller Lieferung.
<G-vec00179-001-s094><start.anfangen><en> We can support your project right from the start with expert advice, a complete CAD database and fast delivery.
<G-vec00097-001-s076><begin.anfangen><de> Seine Triebe und Samen sicher überwintern, und sie entwickelte sich aus den Pflanzen anfangen, im Mai und Juni blühen.
<G-vec00097-001-s076><begin.anfangen><en> Its shoots and seeds safely overwinter, and they developed from the plants begin to bloom in May and June.
<G-vec00097-001-s077><begin.anfangen><de> Eine gegenwärtige Philosophie schlägt vor, daß Brustgesundheit Siebung an Alter 25 anfangen sollte.
<G-vec00097-001-s077><begin.anfangen><en> One current philosophy suggests breast health screening should begin at age 25.
<G-vec00097-001-s078><begin.anfangen><de> Bei der Frage nach seinen Eindrücken zur Passage in den Pyrenäen hat der Kapitän von Team Sky im Übrigen schon eine Art Ungeduld durchscheinen lassen: „Alles wird von der ersten Woche und deren Ablauf abhängen, doch das Rennen wird in den Bergen wirklich anfangen.
<G-vec00097-001-s078><begin.anfangen><en> Asked to comment on the Pyrenees, the Team Sky leader showed signs of impatience: “It will all depend on how the first week goes, but the race will really begin in the mountains.
<G-vec00097-001-s079><begin.anfangen><de> Der Feind rechnete, dass der Eintritt mit dem Süden anfangen wird, wo unsere Truppen weit vorwärts gegangen sind, die Karpaten erreicht.
<G-vec00097-001-s079><begin.anfangen><en> The enemy counted that approach will begin with the South where our troops far moved ahead, having reached the Carpathians.
<G-vec00097-001-s080><begin.anfangen><de> Wenn Sie aufgeregt, unruhig, oder nachlässige, werden Sie anfangen zu spielen, zu viel, und du wirst anfangen zu verlieren.
<G-vec00097-001-s080><begin.anfangen><en> If you start to get alarmed, restless, or apathetic, you can start betting a lot, and you most likely will begin losing.
<G-vec00097-001-s081><begin.anfangen><de> Das ist fantastisch, da es bedeutet, wenn man zweifelhaft sind Sie klein anfangen, und gehen Sie zurück, um eine größere Flasche später zu kaufen, wenn Sie die Ergebnisse, die Sie wünschen, zu erwerben wahrscheinlich.
<G-vec00097-001-s081><begin.anfangen><en> This is wonderful considering that it indicates if you are skeptical you can begin little, and maybe return to buy a larger container later on if you get the outcomes you wish.
<G-vec00097-001-s082><begin.anfangen><de> "Wir können hier gleich anfangen, danach zu fragen, was mit ""des Lebens wichtig"" gemeint ist."
<G-vec00097-001-s082><begin.anfangen><en> "We can begin just here and ask the question, What does ""vital"" mean?"
<G-vec00097-001-s083><begin.anfangen><de> """Dann könnte ich ja gleich anfangen, mich zu erholen"", sagte Robinson und sah Karl an."
<G-vec00097-001-s083><begin.anfangen><en> “Then I can begin recovering immediately,” Robinson said as he looked at Karl.
<G-vec00097-001-s084><begin.anfangen><de> Texas Einfluß' EM - ein Siebenkarte Spiel mit einfachen Richtlinien, die ein Anfänger leicht erarbeiten und anfangen kann, um sofort zu spielen.
<G-vec00097-001-s084><begin.anfangen><en> Texas Hold 'em - A seven-card game with simple rules that a beginner can easily master and begin to play right away.
<G-vec00097-001-s085><begin.anfangen><de> Sind diese Hauptstützen des alten, finstern und bösen Aberglaubens aus dem Wege geräumt, und das blitzschnell zu gleicher Zeit an allen Orten der Erde, so werden die Menschen sicher darüber erschrecken und darauf bald nachzudenken anfangen, wie und warum solches geschehen ist, und was es zu bedeuten hat.
<G-vec00097-001-s085><begin.anfangen><en> If these most important pillars of the old, dark and evil superstition are done away with, and as fast as lightning on all places of the Earth at once, that will certainly frighten the people and they will soon begin to think about how and why that happened and about its meaning.
<G-vec00097-001-s086><begin.anfangen><de> """Hört die süßen, kleinen Vögel da oben"" sagten die Rosen, ""sie wollen jetzt auch anfangen zu singen."
<G-vec00097-001-s086><begin.anfangen><en> """Listen to the dear little birds up there,"" said the roses; ""they begin to want to sing too, but are not able to manage it yet."
<G-vec00097-001-s087><begin.anfangen><de> Die Katzen haben eine interessante Besonderheit: nach der Geburt einiger Kätzchen kann die Geburt für die Zeit aufhören, und dann, wieder anfangen.
<G-vec00097-001-s087><begin.anfangen><en> Cats have an interesting feature: after the birth of several kittens childbirth can stop for a while, and then again begin.
<G-vec00097-001-s088><begin.anfangen><de> Wer nicht mehr wartet, kann anfangen zu handeln.
<G-vec00097-001-s088><begin.anfangen><en> And anyone who ceases to hope can begin to act.
<G-vec00097-001-s089><begin.anfangen><de> Irgendwo musste der Mensch anfangen, und es sei besser, es dort zu tun, wo ein anderer aufhören würde.
<G-vec00097-001-s089><begin.anfangen><en> Somewhere a man must begin, and it had better be just where another man might stop.
<G-vec00097-001-s090><begin.anfangen><de> Doch kann ich mir vorstellen, dass ein Künstler in England, der ein Kunstwerk hervorbrächte, das sogleich bei seinem Erscheinen vom Publikum durch dessen Medium, die öffentliche Presse, als ein ganz verständliches und höchst moralisches Werk anerkannt wird, anfangen würde ernsthaft zu zweifeln, ob er sich in seiner Schöpfung wirklich selbst ausgedrückt habe und ob darum dieses Werk seiner nicht ganz unwürdig und entweder absolut zweitrangig sei oder überhaupt keinen künstlerischen Wert besäße.
<G-vec00097-001-s090><begin.anfangen><en> But I can fancy that if an artist produced a work of art in England that immediately on its appearance was recognised by the public, through their medium, which is the public press, as a work that was quite intelligible and highly moral, he would begin to seriously question whether in its creation he had really been himself at all, and consequently whether the work was not quite unworthy of him, and either of a thoroughly second-rate order, or of no artistic value whatsoever.
<G-vec00097-001-s091><begin.anfangen><de> Außerhalb des Gerichtsgebäude sagten die Opfer, sie seien über das Urteil erleichtert und jetzt könnten sie anfangen, weiterzuleben.
<G-vec00097-001-s091><begin.anfangen><en> Outside court the victims said they were relieved by the sentence and that they could now begin to move on with their lives.
<G-vec00097-001-s092><begin.anfangen><de> Ich persönlich bin jedoch aus beruflichen und weltanschaulichen Gründen an Debian Sid gebunden, und kann daher mit den obigen Optionen nichts anfangen.
<G-vec00097-001-s092><begin.anfangen><en> I personally am however bound for vocational and world-descriptive reasons at Debian Sid, and can begin therefore with the above options nothing.
<G-vec00097-001-s093><begin.anfangen><de> Andere unbegreifliche Symptome der neuen Zustände des Organismus werden ebenfalls anfangen, sich im Leben zu offenbaren.
<G-vec00097-001-s093><begin.anfangen><en> Likewise, other incomprehensible symptoms of the new conditions of the organism will begin to disclose themselves in life.
<G-vec00097-001-s094><begin.anfangen><de> Denn nun beachten sie alle Anzeichen, weil sie zu glauben anfangen, daß das Ende nahe ist.
<G-vec00097-001-s094><begin.anfangen><en> For then they will pay heed to all the signs because they will begin to believe that the end is near.
<G-vec00097-001-s095><start.anfangen><de> Wenn Sie mit den besten Blättern anfangen und darauf abzielen, die Nuts zu erreichen, haben Sie bei Omaha eine wesentlich bessere Chance auf Erfolg.
<G-vec00097-001-s095><start.anfangen><en> If you start with the best hands and look to aim for The Nuts then your chances of success in Omaha are all that much greater.
<G-vec00097-001-s096><start.anfangen><de> Lass uns mit Facebook anfangen.
<G-vec00097-001-s096><start.anfangen><en> Let’s start with Facebook.
<G-vec00097-001-s097><start.anfangen><de> Wir können auch anfangen, einige neue Kleidungsstücke zu kaufen oder Bücher oder Musik oder was immer wahrhaftiger widerspiegelt, wer wir jetzt geworden sind.
<G-vec00097-001-s097><start.anfangen><en> We can also start buying some new clothes or books or music or whatever which more truly reflects who we have now become.
<G-vec00097-001-s098><start.anfangen><de> Anfangen muss man an den Wurzeln, d.h. bei der politischen Bildung der jungen Menschen.
<G-vec00097-001-s098><start.anfangen><en> You have to start at the roots, i. e. with the political education of young people.
<G-vec00097-001-s099><start.anfangen><de> "In seinen eigenen Worten: ""Ich bin dabei meine Eid auf die nationale Sicherheit zu verletzen... Ich habe die Regierungslügen so satt, dass ich nicht einmal weiß, wo ich anfangen soll""."
<G-vec00097-001-s099><start.anfangen><en> "In his own words; ""I'm about to violate my national security oath…I'm so fed up with government lies I don't even know where to start""."
<G-vec00097-001-s100><start.anfangen><de> Der Vater zweier Kinder aus der Region Casablanca war schon immer von Autoblech und Motoren fasziniert: „Ich war früher Chef in einer Autowerkstatt.“ Trotzdem musste er bei Renault da anfangen, wo fast alle Neulinge landen: in dem langgestreckten Ausbildungszentrum, das gleich am Eingang des 300 Hektar großen Fabrikgeländes liegt.
<G-vec00097-001-s100><start.anfangen><en> The father of two children from the Casablanca region has always been fascinated by car engines and bodywork: “I used to run a car workshop.” Nevertheless, when he joined Renault he had to start where nearly all new employees do: inside the long and narrow training centre that stands right by the entrance to the 300-hectare factory site.
<G-vec00097-001-s101><start.anfangen><de> „Aber jetzt möchte ich mit Karate anfangen.“ Da kann sich ihr Gatte und ständiger Begleiter Marcelo wohl auf einiges gefasst machen.
<G-vec00097-001-s101><start.anfangen><en> “But now I want to start doing karate.” So her husband and constant companion Marcelo can prepare himself for quite a lot.
<G-vec00097-001-s102><start.anfangen><de> Warnungen Dein Partner könnte einen Vorteil darin sehen und anfangen, dich zu zwingen, seine oder ihre Füße für lange Zeit zu riechen/lecken/küssen.
<G-vec00097-001-s102><start.anfangen><en> Warnings Your partner may see an advantage to this, and start forcing you to smell/lick/kiss her feet for long amounts of time.
<G-vec00097-001-s103><start.anfangen><de> Nach 45 Minuten können Sie anfangen zu essen.
<G-vec00097-001-s103><start.anfangen><en> After 45 minutes you can start eating.
<G-vec00097-001-s104><start.anfangen><de> Die Jungs, die in die Arabischen Emirate gehen wollen, warten immer noch auf den Moment, in dem sie anfangen können, und machen in der Zwischenzeit Gelegenheitsjobs.
<G-vec00097-001-s104><start.anfangen><en> The boys who want to go for work to the Arabian Emirates are still waiting for the moment they can start and are doing odd jobs in the meantime.
<G-vec00097-001-s105><start.anfangen><de> Deine Freunde werden keine Empfehlungen wenn sie anfangen Top Eleven zu spielen nachdem sie die Benachrichtigung per E-Mail, SMS oder Twitter öffnen.
<G-vec00097-001-s105><start.anfangen><en> Your friends will not become your referrals if they start playing after receiving a message via email, Twitter or SMS).
<G-vec00097-001-s106><start.anfangen><de> Am praktischen Beispiel wird das Thema »Ausgrenzung« thematisiert und reflektiert.Quer durch den großen Ausstellungsraum entsteht aus Obstkisten und Umzugskartons eine selbstgestaltete Mauer, die uns zeigen soll, dass Veränderungen im Kopf anfangen.
<G-vec00097-001-s106><start.anfangen><en> Right across the large exhibition showroom a self-designed wall will be created from fruit crates and moving boxes to demonstrate that changes start in the mind.
<G-vec00097-001-s107><start.anfangen><de> Bevor wir anfangen im Gespräch mit Fremden Omegle, wir müssen die Regeln kennen.
<G-vec00097-001-s107><start.anfangen><en> Before we start talking to strangers Omegle, we need to know the rules.
<G-vec00097-001-s108><start.anfangen><de> Wenn Sie aufgeregt, unruhig, oder nachlässige, werden Sie anfangen zu spielen, zu viel, und du wirst anfangen zu verlieren.
<G-vec00097-001-s108><start.anfangen><en> If you start to get alarmed, restless, or apathetic, you can start betting a lot, and you most likely will begin losing.
<G-vec00097-001-s109><start.anfangen><de> A.M.: Ich möchte untypisch anfangen.
<G-vec00097-001-s109><start.anfangen><en> A.M.: I will not start typically...
<G-vec00097-001-s110><start.anfangen><de> Du beginnst festzustellen, dass du innerlich wütend bist, und du magst anfangen jemand anderen zu verletzen, weil du im Moment in dem Bestreben gefangen bist, die verlorene Zeit wieder wettzumachen, die Welt geradewegs auf deine Repräsentationsrechte hin auszurichten.
<G-vec00097-001-s110><start.anfangen><en> You begin to notice that you are irate inside, and you may start to infringe on another because, at the moment, you are caught up in making up for lost time, setting the world straight on your rights of representation.
<G-vec00097-001-s111><start.anfangen><de> Die ganze Zeit werden Sie die Polnische Sprache hören und durch Spiele mit Aufnahmen über Mikrofon werden Sie direkt anfangen zu sprechen.
<G-vec00097-001-s111><start.anfangen><en> You will hear the Polish language all of the time and, using the recording games, you can start speaking straight away.
<G-vec00097-001-s112><start.anfangen><de> dann können Sie anfangen, ein...
<G-vec00097-001-s112><start.anfangen><en> then you may have to start thinking a...
<G-vec00097-001-s113><start.anfangen><de> Der Vergleich, dass die Themen, die Patti ist enttäuschender Gleichgültigkeit gegenüber den Tod eines von ihnen sogar; sieht aus wie es sein wird eine Art von Offenbarung und stattdessen die gleichen Gehirnwäsche sahen wir tun Meg: Nicht durch Erinnerungen an die Vergangenheit schwankte, denn das ist, wenn Sie anfangen, etwas zu fühlen.
<G-vec00097-001-s113><start.anfangen><en> The comparison that the subjects Patti is even more disappointing indifference to the death of one of them; looks like it's going to be some kind of revelation and instead is the same brainwashing we saw do Meg: Don't be swayed by memories of the past because that is when you start to feel something.
<G-vec00179-001-s095><start.anfangen><de> Wenn Sie mit den besten Blättern anfangen und darauf abzielen, die Nuts zu erreichen, haben Sie bei Omaha eine wesentlich bessere Chance auf Erfolg.
<G-vec00179-001-s095><start.anfangen><en> If you start with the best hands and look to aim for The Nuts then your chances of success in Omaha are all that much greater.
<G-vec00179-001-s096><start.anfangen><de> Lass uns mit Facebook anfangen.
<G-vec00179-001-s096><start.anfangen><en> Let’s start with Facebook.
<G-vec00179-001-s097><start.anfangen><de> Wir können auch anfangen, einige neue Kleidungsstücke zu kaufen oder Bücher oder Musik oder was immer wahrhaftiger widerspiegelt, wer wir jetzt geworden sind.
<G-vec00179-001-s097><start.anfangen><en> We can also start buying some new clothes or books or music or whatever which more truly reflects who we have now become.
<G-vec00179-001-s098><start.anfangen><de> Anfangen muss man an den Wurzeln, d.h. bei der politischen Bildung der jungen Menschen.
<G-vec00179-001-s098><start.anfangen><en> You have to start at the roots, i. e. with the political education of young people.
<G-vec00179-001-s099><start.anfangen><de> "In seinen eigenen Worten: ""Ich bin dabei meine Eid auf die nationale Sicherheit zu verletzen... Ich habe die Regierungslügen so satt, dass ich nicht einmal weiß, wo ich anfangen soll""."
<G-vec00179-001-s099><start.anfangen><en> "In his own words; ""I'm about to violate my national security oath…I'm so fed up with government lies I don't even know where to start""."
<G-vec00179-001-s100><start.anfangen><de> Der Vater zweier Kinder aus der Region Casablanca war schon immer von Autoblech und Motoren fasziniert: „Ich war früher Chef in einer Autowerkstatt.“ Trotzdem musste er bei Renault da anfangen, wo fast alle Neulinge landen: in dem langgestreckten Ausbildungszentrum, das gleich am Eingang des 300 Hektar großen Fabrikgeländes liegt.
<G-vec00179-001-s100><start.anfangen><en> The father of two children from the Casablanca region has always been fascinated by car engines and bodywork: “I used to run a car workshop.” Nevertheless, when he joined Renault he had to start where nearly all new employees do: inside the long and narrow training centre that stands right by the entrance to the 300-hectare factory site.
<G-vec00179-001-s101><start.anfangen><de> „Aber jetzt möchte ich mit Karate anfangen.“ Da kann sich ihr Gatte und ständiger Begleiter Marcelo wohl auf einiges gefasst machen.
<G-vec00179-001-s101><start.anfangen><en> “But now I want to start doing karate.” So her husband and constant companion Marcelo can prepare himself for quite a lot.
<G-vec00179-001-s102><start.anfangen><de> Warnungen Dein Partner könnte einen Vorteil darin sehen und anfangen, dich zu zwingen, seine oder ihre Füße für lange Zeit zu riechen/lecken/küssen.
<G-vec00179-001-s102><start.anfangen><en> Warnings Your partner may see an advantage to this, and start forcing you to smell/lick/kiss her feet for long amounts of time.
<G-vec00179-001-s103><start.anfangen><de> Nach 45 Minuten können Sie anfangen zu essen.
<G-vec00179-001-s103><start.anfangen><en> After 45 minutes you can start eating.
<G-vec00179-001-s104><start.anfangen><de> Die Jungs, die in die Arabischen Emirate gehen wollen, warten immer noch auf den Moment, in dem sie anfangen können, und machen in der Zwischenzeit Gelegenheitsjobs.
<G-vec00179-001-s104><start.anfangen><en> The boys who want to go for work to the Arabian Emirates are still waiting for the moment they can start and are doing odd jobs in the meantime.
<G-vec00179-001-s105><start.anfangen><de> Deine Freunde werden keine Empfehlungen wenn sie anfangen Top Eleven zu spielen nachdem sie die Benachrichtigung per E-Mail, SMS oder Twitter öffnen.
<G-vec00179-001-s105><start.anfangen><en> Your friends will not become your referrals if they start playing after receiving a message via email, Twitter or SMS).
<G-vec00179-001-s106><start.anfangen><de> Am praktischen Beispiel wird das Thema »Ausgrenzung« thematisiert und reflektiert.Quer durch den großen Ausstellungsraum entsteht aus Obstkisten und Umzugskartons eine selbstgestaltete Mauer, die uns zeigen soll, dass Veränderungen im Kopf anfangen.
<G-vec00179-001-s106><start.anfangen><en> Right across the large exhibition showroom a self-designed wall will be created from fruit crates and moving boxes to demonstrate that changes start in the mind.
<G-vec00179-001-s107><start.anfangen><de> Bevor wir anfangen im Gespräch mit Fremden Omegle, wir müssen die Regeln kennen.
<G-vec00179-001-s107><start.anfangen><en> Before we start talking to strangers Omegle, we need to know the rules.
<G-vec00179-001-s108><start.anfangen><de> Wenn Sie aufgeregt, unruhig, oder nachlässige, werden Sie anfangen zu spielen, zu viel, und du wirst anfangen zu verlieren.
<G-vec00179-001-s108><start.anfangen><en> If you start to get alarmed, restless, or apathetic, you can start betting a lot, and you most likely will begin losing.
<G-vec00179-001-s109><start.anfangen><de> A.M.: Ich möchte untypisch anfangen.
<G-vec00179-001-s109><start.anfangen><en> A.M.: I will not start typically...
<G-vec00179-001-s110><start.anfangen><de> Du beginnst festzustellen, dass du innerlich wütend bist, und du magst anfangen jemand anderen zu verletzen, weil du im Moment in dem Bestreben gefangen bist, die verlorene Zeit wieder wettzumachen, die Welt geradewegs auf deine Repräsentationsrechte hin auszurichten.
<G-vec00179-001-s110><start.anfangen><en> You begin to notice that you are irate inside, and you may start to infringe on another because, at the moment, you are caught up in making up for lost time, setting the world straight on your rights of representation.
<G-vec00179-001-s111><start.anfangen><de> Die ganze Zeit werden Sie die Polnische Sprache hören und durch Spiele mit Aufnahmen über Mikrofon werden Sie direkt anfangen zu sprechen.
<G-vec00179-001-s111><start.anfangen><en> You will hear the Polish language all of the time and, using the recording games, you can start speaking straight away.
<G-vec00179-001-s112><start.anfangen><de> dann können Sie anfangen, ein...
<G-vec00179-001-s112><start.anfangen><en> then you may have to start thinking a...
<G-vec00179-001-s113><start.anfangen><de> Der Vergleich, dass die Themen, die Patti ist enttäuschender Gleichgültigkeit gegenüber den Tod eines von ihnen sogar; sieht aus wie es sein wird eine Art von Offenbarung und stattdessen die gleichen Gehirnwäsche sahen wir tun Meg: Nicht durch Erinnerungen an die Vergangenheit schwankte, denn das ist, wenn Sie anfangen, etwas zu fühlen.
<G-vec00179-001-s113><start.anfangen><en> The comparison that the subjects Patti is even more disappointing indifference to the death of one of them; looks like it's going to be some kind of revelation and instead is the same brainwashing we saw do Meg: Don't be swayed by memories of the past because that is when you start to feel something.
<G-vec00097-001-s095><begin.anfangen><de> Das bedeutet, dass es das Wort Gottes ist, das redet und es der Geist des HERRN ist, der dem Wort Gottes die Stimme gibt, die anfängt das Wort zu sprechen.
<G-vec00097-001-s095><begin.anfangen><en> This means, it is the Word of God which speaks, and it is the Spirit of the Lord who gives the Word of God voice when we begin to speak the Word.
<G-vec00097-001-s096><begin.anfangen><de> Wenn in irgend einen Bereich ein Einbruch dieser unterbrechenden, schismatischen unordentlichen Mächte sei es in ein individuelles oder in ein Gemeinschaftsleben oder sonstwo geschieht, ist der übliche Weg der, dass man einen Sündenbock findet, dass man jemandem die Schuld geben kann, dass man anfängt, einander schräg anzusehen, dass man es auf dies oder jenes zurückführt, und wenn wir das tun, verfehlen wir den Punkt und den Weg, und wir werden die Sache auf diese Weise nie aufklären.
<G-vec00097-001-s096><begin.anfangen><en> When there is a breaking in, in any realm, of those disruptive, schismatic, disordering forces, in an individual life, or in a community, or anywhere, the usual way is to find a scapegoat, to blame somebody, to begin to look at one another, to put it down to this, and that, and something else, and in so doing we are missing the point and missing the way, and we will never clear it up like that.
<G-vec00097-001-s097><begin.anfangen><de> Ich wollte doch einmal ‚richtig‘ sticken (d.h., nicht auf Papier;-)) und musste jetzt heraus finden, wie man eigentlich anfängt und am Ende aufhört (auf Papier klebe ich den Faden einfach fest und ich dachte, dass man das auf Stoff anders macht;-)).
<G-vec00097-001-s097><begin.anfangen><en> I just wanted to try ‘real’ embroidery (viz. not on paper;-)) and had to find out how actually to begin and to end (on paper I simply glue on the threads but I thought that this must be done differently on fabric;-)).
<G-vec00097-001-s098><begin.anfangen><de> Die bestehende Vorstellung, dass die Eier oder die Läuse selbst in der Kopfhaut einnicken, während die Person ruhig ist und anfängt, nur mit nervöser Erregung zu basteln und zu jucken, sind pseudowissenschaftliche Mythen, unlogisch und durch keine Forschung bestätigt.
<G-vec00097-001-s098><begin.anfangen><en> The existing notion that the eggs or the lice themselves doze in the scalp while the person is calm, and they begin to tinker and itch only with nervous agitation, are pseudoscientific myths, illogical and not confirmed by any research.
<G-vec00097-001-s099><begin.anfangen><de> 28 Wenn aber dieses anfängt zu geschehen, so sehet auf und erhebet eure Häupter, darum daß sich eure Erlösung naht.
<G-vec00097-001-s099><begin.anfangen><en> 28 And when these things begin to come to pass, then look up, and lift up your heads; for your redemption draweth nigh.
<G-vec00097-001-s100><begin.anfangen><de> 9 Sieben Wochen sollst du dir abzählen; wenn man anfängt, die Sichel an die Saat zu legen, sollst du anfangen, sieben Wochen zu zählen.
<G-vec00097-001-s100><begin.anfangen><en> "9 ""You shall count seven weeks for yourself; you shall begin to count seven weeks from the time you begin to put the sickle to the standing grain."
<G-vec00097-001-s101><begin.anfangen><de> Das Substrat sollte im Winter fast durchgehend trocken gehalten werden, damit die Winterrosette, die relativ tief im Boden steckt, nicht anfängt zu faulen.
<G-vec00097-001-s101><begin.anfangen><en> In winter substrate should be kept almost dry, so that the winter leaves do not begin to rot, because the winter rosette is partly buried in the soil.
<G-vec00097-001-s102><begin.anfangen><de> Wenn es um Management, Männer und Frauen oft mit, wie man anfängt und vor allem, wie man Ergebnisse sehen Gewicht.
<G-vec00097-001-s102><begin.anfangen><en> When it comes to weight management, men and women alike often struggle with how to begin and, most importantly, how to see the results.
<G-vec00097-001-s103><begin.anfangen><de> Verfüge, dass sich in dir eine neue Salbung anfängt zu manifestieren, in den nächsten Monaten.
<G-vec00097-001-s103><begin.anfangen><en> Declare that a new anointing will begin to manifest in you in the next several months.
<G-vec00097-001-s104><begin.anfangen><de> Jedes Mal, wenn Sie wetten, nicht nur für typische Freizeit und Unterhaltung; auch anfängt zu gastronomischen Erlebnissen zu nehmen, Thematisierung und Customizing neue Erfahrungen.
<G-vec00097-001-s104><begin.anfangen><en> Every time you are betting, for not only typical leisure and entertainment; also begin to take place gastronomic experiences, theming and customizing new experiences.
<G-vec00097-001-s105><begin.anfangen><de> Der Ausruf des Gottessohnes aus Lukas 21,28: „Wenn aber dieses anfängt zu geschehen, dann seht auf und erhebt eure Häupter, weil eure Erlösung naht“ war Grundlage des Gottesdienstes, an dem über 3.500 Gläubige teilnahmen.
<G-vec00097-001-s105><begin.anfangen><en> The divine service, which was attended by over 3,500 believers, was based on the statement of the Son of God recorded in Luke 21: 28: “Now when these things begin to happen, look up and lift up your heads, because your redemption draws near.”
<G-vec00097-001-s106><begin.anfangen><de> Wenn aber dies anfängt zu geschehen, so richtet euch auf und erhebt eure Häupter, weil eure Erlösung naht.
<G-vec00097-001-s106><begin.anfangen><en> "But when these things begin to happen, look up, and lift up your heads, because your redemption is near."""
<G-vec00097-001-s107><begin.anfangen><de> Der Schaden an den Belägen wird normalerweise durch übermäßige Hitze hervorgerufen, die das Reibmaterial brüchig machen, sodass es anfängt zu brechen.
<G-vec00097-001-s107><begin.anfangen><en> A damaged pad is usually caused by excessive heat which causes the friction material to become brittle and begin to break up.
<G-vec00097-001-s108><begin.anfangen><de> Sorgen Sie nicht sich um das Vollenden sie, aber suchen Sie neuen Ideen, Antrieben, Darmgefühlen und nach neuer Energie, die anfängt, zu führen Sie zu, was Sie wünschen.
<G-vec00097-001-s108><begin.anfangen><en> Don't worry about accomplishing it, but do look for new ideas, impulses, gut feelings, and new energy that will begin to guide you to what you want.
<G-vec00097-001-s109><begin.anfangen><de> 12:45 Wenn aber jener Knecht in seinem Herzen sagt: Mein Herr verzieht zu kommen, und anfängt, die Knechte und Mägde zu schlagen und zu essen und zu trinken und sich zu berauschen, < 12:46 so wird der Herr jenes Knechtes kommen an einem Tage, an welchem er es nicht erwartet, und in einer Stunde, die er nicht weiß, und wird ihn entzweischneiden und ihm sein Teil setzen mit den Untreuen.
<G-vec00097-001-s109><begin.anfangen><en> 12:45 But if that servant shall say in his heart, My lord delayeth his coming; and shall begin to beat the menservants and the maidservants, and to eat and drink, and to be drunken; < 12:46 the lord of that servant shall come in a day when he expecteth not, and in an hour when he knoweth not, and shall cut him asunder, and appoint his portion with the unfaithful.
<G-vec00097-001-s110><begin.anfangen><de> Wenn unsere Protagonistin sehr geil ist, bis auf den Schwanz des Jungen und beginnt zu saugen, werden wir Mary Jean saugen sehen, dann wird unsere vollbusige Protagonistin in Position des Hundes gebracht, damit der Junge anfängt zu ficken, was zu einem sehr harten Ergebnis führt gute interrassische Sexszene in der Öffentlichkeit mit einer vollbusigen Frau, die einen Mann auf einem Fußballfeld fickt.
<G-vec00097-001-s110><begin.anfangen><en> When our protagonist is very horny, down to the boy’s cock and begin to suck, so we will see Mary Jean sucking cock, then our busty protagonist will be placed in position of the dog for the boy to begin to fuck, resulting in a very good Interracial sex scene in public with a busty woman fucking a man on a soccer field.
<G-vec00097-001-s111><begin.anfangen><de> 28 Wenn aber dieses anfängt zu geschehen, so sehet auf und erhebet eure Häupter, darum daß sich eure Erlösung naht.
<G-vec00097-001-s111><begin.anfangen><en> 28 But when these things begin to happen, look up and lift up your heads, because your redemption is near.”
<G-vec00097-001-s112><begin.anfangen><de> 2007-11-13 22:16:19 - Grundlegende organisierende Grundregeln So haben Sie entschieden, organisiert zu erhalten, aber Sie gerade wissen nicht, wo man anfängt.
<G-vec00097-001-s112><begin.anfangen><en> 2007-11-13 22:16:19 - Basic organizing principles So you've decided to get organized, but you just don't know where to begin.
<G-vec00097-001-s113><begin.anfangen><de> Wir möchten hoffen, dass Jeschows Fehler ausgemerzt und berichtigt werden, dass das NKWD anfängt, richtig die feindlichen Elemente der Sowjetmacht zu bekämpfen und dass ehrliche Arbeiter die Garantie haben werden, normale und ruhige Arbeitsbedingungen zu haben.
<G-vec00097-001-s113><begin.anfangen><en> We want to hope that Yezhov's mistakes will be eliminated and corrected, that the NKVD will begin to really fight elements hostile to Soviet rule and that honest workers will be assured normal and tranquil working conditions.
<G-vec00097-001-s114><begin.anfangen><de> Und wie oft er auch kaputtgeht und verbrennt, hat er doch normalerweise immer genug Vertrauen und Zuversicht, um von vorne anzufangen und sich wieder auszudehnen.
<G-vec00097-001-s114><begin.anfangen><en> However often it crashes and burns, there is normally enough faith to begin again and repeat the expansion all over again.
<G-vec00097-001-s115><begin.anfangen><de> Die Hoffnung entsteht, wenn man erfahren kann, dass nicht alles verloren ist, und deswegen ist die Übung notwendig, „zu Hause“ anzufangen, bei sich selbst anzufangen.
<G-vec00097-001-s115><begin.anfangen><en> Hope is born when you are able to feel that all is not lost; and for this to happen it is necessary to start “at home”, to begin with yourself.
<G-vec00097-001-s116><begin.anfangen><de> Es ist allgemein, mit einer Dosis von mg 30 anzufangen und sie auf mg 50 allmählich pro Tag zu erhöhen.
<G-vec00097-001-s116><begin.anfangen><en> It is common to begin with a dose of 30 mg and gradually increase it to 50 mg per day.
<G-vec00097-001-s117><begin.anfangen><de> Gefunden sehr bequem in Beijing ist unser Hotel ein bevorzugter Platz, zum und des Platzes, zu erforschen anzufangen zu bleiben.
<G-vec00097-001-s117><begin.anfangen><en> Located very conveniently in Beijing our hotel is a preferred place to stay and begin exploring the place.
<G-vec00097-001-s118><begin.anfangen><de> Dort sind viel von Gründe, warum schlecht klein Neulinge kommen in dünn (ich weiß, daß... wir bilden müssen, ihnen zu glauben kamen in dünnes, mit anzufangen) und gehen Sie zurück nach Hause nach dem Jahr eins, das in Zwanzig wiegt, zerstoße schwereres.
<G-vec00097-001-s118><begin.anfangen><en> There are plenty of reasons why poor little freshmen come in skinny (I know... we'll have to make believe they came in skinny to begin with) and go back home after year one weighing in twenty pounds heavier.
<G-vec00097-001-s119><begin.anfangen><de> Gefunden sehr bequem in Budapest ist unser Hotel ein bevorzugter Platz, zum und des Platzes, zu erforschen anzufangen zu bleiben.
<G-vec00097-001-s119><begin.anfangen><en> Located very conveniently in Budapest our hotel is a preferred place to stay and begin exploring the place.
<G-vec00097-001-s120><begin.anfangen><de> """Um mit etwas Positivem anzufangen: Die kurzen, rhythmischen Sätze in Gegenwartsform und dritter Person entsprechen der Situation des Helden"", so Hubert Winkels."
<G-vec00097-001-s120><begin.anfangen><en> """To begin with something positive: the short, rhythmic sentences in the present tense and the third person correspond to the situation of the hero,"" Hubert Winkels commented."
<G-vec00097-001-s121><begin.anfangen><de> Um anzufangen das herunterladen Sie, Sie sollten Ihrem blocker von herausragenden Fenstern (Pop Up blocker) und Presse den leichten blauen Knopf lahmlegen.
<G-vec00097-001-s121><begin.anfangen><en> To begin the download you should disable your blocker of emergent windows (Pop Up blocker) and press the light blue button.
<G-vec00097-001-s122><begin.anfangen><de> Item, daß im Menschen nicht gar verderbt sei menschlich Natur und Wesen, sondern der Mensch habe noch etwas Gutes an ihm [an sich], auch in geistlichen Sachen, als nämlich Frömmigkeit [*Fähigkeit], Geschicklichkeit, Tüchtigkeit oder Vermögen, in geistlichen Sachen etwas anzufangen, zu wirken oder mitzuwirken.
<G-vec00097-001-s122><begin.anfangen><en> Also, that in man the human nature and essence are not entirely corrupt, but that man still has something good in him, even in spiritual things, namely, capacity, skill, aptness, or ability in spiritual things to begin, to work, or to help working for something [good].
<G-vec00097-001-s123><begin.anfangen><de> Ich habe die Erfahrung gemacht, dass Heilung für viele, die mit diesen Aspekten geboren sind, damit anzufangen scheint, die Verbitterung wahrzunehmen und zu akzeptieren, dass das Misstrauen seine Gültigkeit und Berechtigung hat, in Anbetracht unserer erbärmlichen Menschheitsgeschichte.
<G-vec00097-001-s123><begin.anfangen><en> I have found that healing, for many born with these aspects, seems to begin first with recognising the bitterness, and accepting that some of the mistrust is valid and true, given our sorry human history.
<G-vec00097-001-s124><begin.anfangen><de> Niemand braucht jedoch erst zu warten, bis das Königreich tatsächlich aufgerichtet ist, um das Gesetz Gottes kennenzulernen und anzufangen, danach zu handeln.
<G-vec00097-001-s124><begin.anfangen><en> No one needs to wait, however, until the kingdom is actually established in order to begin learning and putting into practice the law of God.
<G-vec00097-001-s125><begin.anfangen><de> Es ist nötig von vorne anzufangen: das Begießen, die Beleuchtung, die Lufttemperatur.
<G-vec00097-001-s125><begin.anfangen><en> It is necessary to begin from scratch: watering, lighting, air temperature.
<G-vec00097-001-s126><begin.anfangen><de> Che wusste, dass die einzige Weise um die Situation zu beheben, war eine Weltrevolution anzufangen.
<G-vec00097-001-s126><begin.anfangen><en> In Che’s eyes, the only way to remedy the situation was to begin a world revolution.
<G-vec00097-001-s127><begin.anfangen><de> übrigens kompetent Ihnen ist erklärt: jede Kunst hat die Gewohnheit von etwas, anzufangen.
<G-vec00097-001-s127><begin.anfangen><en> By the way, it is competent to you it is declared: any art is accustomed from something to begin.
<G-vec00097-001-s128><begin.anfangen><de> Sie neigen, an der Oberseite anzufangen und in Richtung zur Unterseite zu lesen.
<G-vec00097-001-s128><begin.anfangen><en> They tend to begin at the top and read towards the bottom.
<G-vec00097-001-s129><begin.anfangen><de> Unsere Kinder haben das Potential, das Bewußtsein zu erlangen, das sie brauchen werden, um die Richtung der Zivilisation umzukehren und anzufangen, die Biosphäre unserer Erde wiederherzustellen.
<G-vec00097-001-s129><begin.anfangen><en> Our children have the potential for achieving the awareness needed to reverse civilization’s direction and begin restoring Earth’s biosphere.
<G-vec00097-001-s130><begin.anfangen><de> Um anzufangen, um sich zu verbessern und um sich zu bestätigen.
<G-vec00097-001-s130><begin.anfangen><en> To begin to improve and to get confirmation.
<G-vec00097-001-s131><begin.anfangen><de> Das Nachdenken über die drei Prinzipien kann unseren Begriff der drei Körper bereichern, doch ist es eine Sache, anzufangen zu denken, und eine ganz andere, sein Denken fortgesetzt zu entwickeln.
<G-vec00097-001-s131><begin.anfangen><en> Thought about the three principles can enrich one's conception of the three vehicles, but it is one thing to begin to think and quite another to continue and to develop one's thinking.
<G-vec00097-001-s132><begin.anfangen><de> Ihr könnt andere bitten anzufangen, gemeinsam Meditationen zu halten.
<G-vec00097-001-s132><begin.anfangen><en> You can ask others to begin holding meditations together.
<G-vec00097-001-s114><start.anfangen><de> Ich erzähle dir auch nicht, mein/e Liebe/r, anzufangen über diejenigen nachzudenken, die es härter haben als du.
<G-vec00097-001-s114><start.anfangen><en> Nor am I telling you, dear one, to start thinking about others who have it harder than you.
<G-vec00097-001-s115><start.anfangen><de> Die Hoffnung entsteht, wenn man erfahren kann, dass nicht alles verloren ist, und deswegen ist die Übung notwendig, „zu Hause“ anzufangen, bei sich selbst anzufangen.
<G-vec00097-001-s115><start.anfangen><en> Hope is born when you are able to feel that all is not lost; and for this to happen it is necessary to start “at home”, to begin with yourself.
<G-vec00097-001-s116><start.anfangen><de> Wir hatten einen Millionär als Unterstützung (Chris Curtis von Searchers fame) -- es ist sehr schwierig etwas anzufangen ohne finanzielle Unterstützung.
<G-vec00097-001-s116><start.anfangen><en> We had a millionaire backer (Chris Curtis, of Searchers fame) -- it's very hard to start without
<G-vec00097-001-s117><start.anfangen><de> Der leidgeprüften Bevölkerung möchte ich in diesem Augenblick meine Solidarität zusichern und sie zur Hoffnung ermutigen, um mit der Hilfe aller neu anzufangen.
<G-vec00097-001-s117><start.anfangen><en> At this time I would like to offer those people the assurance of my solidarity, together with a particular encouragement to have the confidence to start again with the help of all.
<G-vec00097-001-s118><start.anfangen><de> Der treue Diener besann sich lange, wie die Sache anzufangen wäre, denn es hielt schwer, nur vor das Angesicht der Königstochter zu kommen.
<G-vec00097-001-s118><start.anfangen><en> The faithful servant long thought about how to start the thing, because it was hard to come just before the face of the Kings daughter.
<G-vec00097-001-s119><start.anfangen><de> Zustand Neu Mit diesen Tees ist Ihr Ball in 5cm Höhe immer die ideale Höhe, um mit Ihrem Driver anzufangen.
<G-vec00097-001-s119><start.anfangen><en> Condition New With these tees, your ball is always at 5cm height the ideal height to start with your driver.
<G-vec00097-001-s120><start.anfangen><de> Da sich der Pariser Herbst schnell nähert, könnte der Zeitpunkt nicht besser sein, um anzufangen, Ihren Trip in diese historische, atemberaubende und romantische Stadt zu planen.
<G-vec00097-001-s120><start.anfangen><en> As autumn in Paris is fast approaching, the time could not be better to start planning your trip to this historical, breathtaking and romantic city .
<G-vec00097-001-s121><start.anfangen><de> Alles in allem ist es offensichtlich die Unfähigkeit, der Bewegung des Fortschritts zu folgen: das Bedürfnis, alles wieder in den Topf zu werfen, um von vorne anzufangen.
<G-vec00097-001-s121><start.anfangen><en> Of course, looking at it as a whole, it is the incapacity to follow the movement of progress: the need to mix everything together again in order to start all over again.
<G-vec00097-001-s122><start.anfangen><de> Der einzige Weg, diese Situation zu überwinden, ist diese Situation rückgängig zu machen, ist die Zurückweisung Gottes zu stoppen und anzufangen, seinen Gegner zurückzuweisen.
<G-vec00097-001-s122><start.anfangen><en> The only way to overcome this situation is to reverse the situation, is to stop the rejection of God and to start the rejection of his opponent.
<G-vec00097-001-s123><start.anfangen><de> Jede Bewegung unterbricht die Kontinuität der Übung und veranlaßt den Meditierenden, von vorn anzufangen.
<G-vec00097-001-s123><start.anfangen><en> Any movement breaks the continuity of the practice and this causes the meditator to start all over again.
<G-vec00097-001-s124><start.anfangen><de> um mit dem Einfachsten anzufangen: die ohmsche Serien-Impedanz.
<G-vec00097-001-s124><start.anfangen><en> Let's start with an easy aspect: the ohmic serial impedance.
<G-vec00097-001-s125><start.anfangen><de> Die Methode, klein anzufangen und dann nach und nach auszubauen, funktioniert nur im Süßwasserbereich (erst ein kleines Becken für Kaltwasserfische, dann wird für Warmwasserfische eine Heizung eingebaut, danach wird für guten Pflanzenwuchs eine gute Beleuchtung und eine Kohlendioxiddüngung installiert).
<G-vec00097-001-s125><start.anfangen><en> "The method ""start small and get larger"" is only suitable with fresh water tanks. There you can start with a small cold water tank, then expanding with a heater to a tropical fish tank. Afterwards you install a carbon dioxide fertilizer and a professional lighting to support the growth of the plants."
<G-vec00097-001-s126><start.anfangen><de> Es ist okay, mit einfachen Büchern anzufangen, so lange wie du später schwierigere liest.
<G-vec00097-001-s126><start.anfangen><en> It is okay to start off with easy books and work your way up.
<G-vec00097-001-s127><start.anfangen><de> Die wirst Du brauchen, um anzufangen, eine Beziehung zu dem Blogger aufzubauen.
<G-vec00097-001-s127><start.anfangen><en> You’ll need those to start building a relationship with the blogger.
<G-vec00097-001-s128><start.anfangen><de> Solche Wettbewerbe geben die Möglichkeit, zu traden am Forex ohne der Abschlagszahlung anzufangen.
<G-vec00097-001-s128><start.anfangen><en> Such contests give a chance to start trading on Forex without deposits.
<G-vec00097-001-s129><start.anfangen><de> Wenn man übel gelaunt ist, beispielsweise, ist es selbstverständlich, dass man nicht das Recht besitzt, zu seinem Arbeitsplsatz zu gehen und anzufangen, auf jeden zu schießen, der sich blicken lässt, wie es in den vergangenen Jahren mehr als einmal in den Vereinigten Staaten geschehen ist.
<G-vec00097-001-s129><start.anfangen><en> If he is disgruntled, for example, he understands that he does not have the right to go to his workplace and start shooting at everyone in sight, as has happened on more than one occasion in the United States in recent years.
<G-vec00097-001-s130><start.anfangen><de> Alles, was du tun musst, ist einen ruhigen, friedlichen Platz zu finden und anzufangen, den Fokus auf deinen Atem zu richten.
<G-vec00097-001-s130><start.anfangen><en> All you have to do is find a quiet, peaceful place and start focusing on your breath.
<G-vec00097-001-s131><start.anfangen><de> „Ja“, flüstert sie und nötigt mich, endlich anzufangen.
<G-vec00097-001-s131><start.anfangen><en> “Yes,” she whispers wanting me to start already.
<G-vec00097-001-s132><start.anfangen><de> Ihr aller sehnlichster Wunsch ist es, ganz unten anzufangen, auf der tiefstmöglichen Stufe des Dienens; so können sie hoffen, die höchstmögliche Ebene erfahrungsmäßiger Bestimmung zu erreichen.
<G-vec00097-001-s132><start.anfangen><en> And they all crave to start at the bottom, on the lowest possible level of ministry; thus may they hope to achieve the highest possible level of experiential destiny.
<G-vec00179-001-s114><start.anfangen><de> Ich erzähle dir auch nicht, mein/e Liebe/r, anzufangen über diejenigen nachzudenken, die es härter haben als du.
<G-vec00179-001-s114><start.anfangen><en> Nor am I telling you, dear one, to start thinking about others who have it harder than you.
<G-vec00179-001-s115><start.anfangen><de> Die Hoffnung entsteht, wenn man erfahren kann, dass nicht alles verloren ist, und deswegen ist die Übung notwendig, „zu Hause“ anzufangen, bei sich selbst anzufangen.
<G-vec00179-001-s115><start.anfangen><en> Hope is born when you are able to feel that all is not lost; and for this to happen it is necessary to start “at home”, to begin with yourself.
<G-vec00179-001-s116><start.anfangen><de> Wir hatten einen Millionär als Unterstützung (Chris Curtis von Searchers fame) -- es ist sehr schwierig etwas anzufangen ohne finanzielle Unterstützung.
<G-vec00179-001-s116><start.anfangen><en> We had a millionaire backer (Chris Curtis, of Searchers fame) -- it's very hard to start without
<G-vec00179-001-s117><start.anfangen><de> Der leidgeprüften Bevölkerung möchte ich in diesem Augenblick meine Solidarität zusichern und sie zur Hoffnung ermutigen, um mit der Hilfe aller neu anzufangen.
<G-vec00179-001-s117><start.anfangen><en> At this time I would like to offer those people the assurance of my solidarity, together with a particular encouragement to have the confidence to start again with the help of all.
<G-vec00179-001-s118><start.anfangen><de> Der treue Diener besann sich lange, wie die Sache anzufangen wäre, denn es hielt schwer, nur vor das Angesicht der Königstochter zu kommen.
<G-vec00179-001-s118><start.anfangen><en> The faithful servant long thought about how to start the thing, because it was hard to come just before the face of the Kings daughter.
<G-vec00179-001-s119><start.anfangen><de> Zustand Neu Mit diesen Tees ist Ihr Ball in 5cm Höhe immer die ideale Höhe, um mit Ihrem Driver anzufangen.
<G-vec00179-001-s119><start.anfangen><en> Condition New With these tees, your ball is always at 5cm height the ideal height to start with your driver.
<G-vec00179-001-s120><start.anfangen><de> Da sich der Pariser Herbst schnell nähert, könnte der Zeitpunkt nicht besser sein, um anzufangen, Ihren Trip in diese historische, atemberaubende und romantische Stadt zu planen.
<G-vec00179-001-s120><start.anfangen><en> As autumn in Paris is fast approaching, the time could not be better to start planning your trip to this historical, breathtaking and romantic city .
<G-vec00179-001-s121><start.anfangen><de> Alles in allem ist es offensichtlich die Unfähigkeit, der Bewegung des Fortschritts zu folgen: das Bedürfnis, alles wieder in den Topf zu werfen, um von vorne anzufangen.
<G-vec00179-001-s121><start.anfangen><en> Of course, looking at it as a whole, it is the incapacity to follow the movement of progress: the need to mix everything together again in order to start all over again.
<G-vec00179-001-s122><start.anfangen><de> Der einzige Weg, diese Situation zu überwinden, ist diese Situation rückgängig zu machen, ist die Zurückweisung Gottes zu stoppen und anzufangen, seinen Gegner zurückzuweisen.
<G-vec00179-001-s122><start.anfangen><en> The only way to overcome this situation is to reverse the situation, is to stop the rejection of God and to start the rejection of his opponent.
<G-vec00179-001-s123><start.anfangen><de> Jede Bewegung unterbricht die Kontinuität der Übung und veranlaßt den Meditierenden, von vorn anzufangen.
<G-vec00179-001-s123><start.anfangen><en> Any movement breaks the continuity of the practice and this causes the meditator to start all over again.
<G-vec00179-001-s124><start.anfangen><de> um mit dem Einfachsten anzufangen: die ohmsche Serien-Impedanz.
<G-vec00179-001-s124><start.anfangen><en> Let's start with an easy aspect: the ohmic serial impedance.
<G-vec00179-001-s125><start.anfangen><de> Die Methode, klein anzufangen und dann nach und nach auszubauen, funktioniert nur im Süßwasserbereich (erst ein kleines Becken für Kaltwasserfische, dann wird für Warmwasserfische eine Heizung eingebaut, danach wird für guten Pflanzenwuchs eine gute Beleuchtung und eine Kohlendioxiddüngung installiert).
<G-vec00179-001-s125><start.anfangen><en> "The method ""start small and get larger"" is only suitable with fresh water tanks. There you can start with a small cold water tank, then expanding with a heater to a tropical fish tank. Afterwards you install a carbon dioxide fertilizer and a professional lighting to support the growth of the plants."
<G-vec00179-001-s126><start.anfangen><de> Es ist okay, mit einfachen Büchern anzufangen, so lange wie du später schwierigere liest.
<G-vec00179-001-s126><start.anfangen><en> It is okay to start off with easy books and work your way up.
<G-vec00179-001-s127><start.anfangen><de> Die wirst Du brauchen, um anzufangen, eine Beziehung zu dem Blogger aufzubauen.
<G-vec00179-001-s127><start.anfangen><en> You’ll need those to start building a relationship with the blogger.
<G-vec00179-001-s128><start.anfangen><de> Solche Wettbewerbe geben die Möglichkeit, zu traden am Forex ohne der Abschlagszahlung anzufangen.
<G-vec00179-001-s128><start.anfangen><en> Such contests give a chance to start trading on Forex without deposits.
<G-vec00179-001-s129><start.anfangen><de> Wenn man übel gelaunt ist, beispielsweise, ist es selbstverständlich, dass man nicht das Recht besitzt, zu seinem Arbeitsplsatz zu gehen und anzufangen, auf jeden zu schießen, der sich blicken lässt, wie es in den vergangenen Jahren mehr als einmal in den Vereinigten Staaten geschehen ist.
<G-vec00179-001-s129><start.anfangen><en> If he is disgruntled, for example, he understands that he does not have the right to go to his workplace and start shooting at everyone in sight, as has happened on more than one occasion in the United States in recent years.
<G-vec00179-001-s130><start.anfangen><de> Alles, was du tun musst, ist einen ruhigen, friedlichen Platz zu finden und anzufangen, den Fokus auf deinen Atem zu richten.
<G-vec00179-001-s130><start.anfangen><en> All you have to do is find a quiet, peaceful place and start focusing on your breath.
<G-vec00179-001-s131><start.anfangen><de> „Ja“, flüstert sie und nötigt mich, endlich anzufangen.
<G-vec00179-001-s131><start.anfangen><en> “Yes,” she whispers wanting me to start already.
<G-vec00179-001-s132><start.anfangen><de> Ihr aller sehnlichster Wunsch ist es, ganz unten anzufangen, auf der tiefstmöglichen Stufe des Dienens; so können sie hoffen, die höchstmögliche Ebene erfahrungsmäßiger Bestimmung zu erreichen.
<G-vec00179-001-s132><start.anfangen><en> And they all crave to start at the bottom, on the lowest possible level of ministry; thus may they hope to achieve the highest possible level of experiential destiny.
