<G-vec00384-001-s229><inquire.anstellen><de> Die Behörden sagten seiner Familie, dass Herr Peng durch eine Krankheit starb, und es wurde Ihnen angebotenen, dass die Begräbnis Kosten übernommen werden, wenn sie nicht weiter über die Ursache seines Todes Nachforschungen anstellen würden.
<G-vec00384-001-s229><inquire.anstellen><en> Authorities told family members that Mr. Peng died of an illness and were offered funeral expenses if they agreed to not inquire further into the cause of his death.
<G-vec00384-001-s230><inquire.anstellen><de> Ich muss diese Geschichte noch ein wenig rekonstruieren und einige Nachforschungen über Angaben und Daten anstellen.
<G-vec00384-001-s230><inquire.anstellen><en> I have to reconstruct that story a bit, inquire about some facts and dates.
