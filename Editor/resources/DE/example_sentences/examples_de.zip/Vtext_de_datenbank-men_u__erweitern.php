<G-vec00407-001-s100><append.datenbank-menü_erweitern><de> Im Datenbank-Menü können Sie nun beide Datenbanken erweitern und verändern.
<G-vec00407-001-s100><append.datenbank-menü_erweitern><en> You can now append and alter both data bases in the data base menu.
