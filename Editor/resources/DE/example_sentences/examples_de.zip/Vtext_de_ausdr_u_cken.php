<G-vec00060-001-s029><convey.ausdrücken><de> Genome Editing (Crispr) Genschere, molekulares Skalpell – solche und andere Umschreibungen aus der Alltagssprache sollen ausdrücken, was die neue Methode mit dem unaussprechlichen Namen CRISPR/Cas9 kann: schneiden – genauer, das Erbgutmolekül DNA durchtrennen, und das präzise an einer bestimmten Stelle.
<G-vec00060-001-s029><convey.ausdrücken><en> Genome Editing Genome Editing (Crispr) Gene scissors, molecular scalpel – these descriptive terms are intended to convey what the new method of gene editing with rather unwieldy name of CRISPR/Cas9 can do.
<G-vec00060-001-s030><convey.ausdrücken><de> Diese zwei Worte sind so klein, sie können nicht ausdrücken wie tief der Schmerz in meinem Herzen war.
<G-vec00060-001-s030><convey.ausdrücken><en> Those two words are so small they cannot convey to you how deeply in my heart I hurt.
<G-vec00060-001-s031><convey.ausdrücken><de> In ekstatischen Zuständen, erreicht in der Ausübung strenger Disziplin, geraten Sufi-Derwische in Resonanz mit den Seelen von Wesen dieser Ebene, die etwas von der Natur der Inspiration ausdrücken, die sie belebt.
<G-vec00060-001-s031><convey.ausdrücken><en> In their ecstasy aroused in the exercise of austere disciplines, the Sufi dervishes are tuned in resonance with the souls of beings at this level who convey something of the nature of the inspiration that animates them.
<G-vec00060-001-s032><convey.ausdrücken><de> Hier finden Sie ein elegantes Setting mit sanfter Hintergrundmusik und Symbolen, die allesamt die feineren Dinge des Lebens ausdrücken.
<G-vec00060-001-s032><convey.ausdrücken><en> Here, you'll see an elegant setting with soft music playing in the background and symbols that all convey the finer things in life.
<G-vec00060-001-s033><convey.ausdrücken><de> So weißt du sicher, dass ihre Bedeutung mit dem übereinstimmt, was du der Außenwelt gegenüber ausdrücken möchtest.
<G-vec00060-001-s033><convey.ausdrücken><en> In this way, you can be sure that the meaning corresponds to what you want to convey to the outside world.
<G-vec00060-001-s034><convey.ausdrücken><de> Das größte Problem entsteht, wenn die Botschaft, die wir verkünden, dann mit diesen zweitrangigen Aspekten gleichgesetzt wird, die, obwohl sie relevant sind, für sich allein nicht das Eigentliche der Botschaft Jesu Christi ausdrücken.
<G-vec00060-001-s034><convey.ausdrücken><en> The biggest problem is when the message we preach then seems identified with those secondary aspects which, important as they are, do not in and of themselves convey the heart of Christ’s message.
<G-vec00060-001-s035><convey.ausdrücken><de> Es ist unglaublic zu sehen, wie Tony so viel Gefühl ausdrücken kann.
<G-vec00060-001-s035><convey.ausdrücken><en> It ́s amazing to see how Tony can convey so much emotion .
<G-vec00060-001-s036><convey.ausdrücken><de> Damit wollen wir ausdrücken, daß dieses Dokument etwas von der Autorität, dem Ausmaß und Verständnis eines hochrangigen Dokuments besitzt, während es gleichzeitig aber nachrangige Einzelheiten aufweist.
<G-vec00060-001-s036><convey.ausdrücken><en> By this we mean to convey the idea that it is a document that carries with it some of the authority, scope, and comprehension of a high level document but at the same time provides some low-level detail.
<G-vec00060-001-s037><convey.ausdrücken><de> "Er sieht alles in ""Zahlen"" und ""Buchstaben"", kann aber ""Wörter"" oder ""Sätze"" noch nicht ""lesen"" und kann deshalb nicht zu dem Wissen kommen, das diese ""Wörter"" und ""Sätze"" ausdrücken."
<G-vec00060-001-s037><convey.ausdrücken><en> "He sees everything as ""numbers"" and ""letters"", but he cannot yet ""read"" ""words"" or ""sentences"", and cannot therefore arrive at the knowledge that these ""words"" and ""sentences"" convey."
<G-vec00081-001-s038><put.ausdrücken><de> Einfach ausgedrückt, halten Fosagro bis vor kurzem versucht, mich und die Pflanze, und das Geld für sie zu verlassen.
<G-vec00081-001-s038><put.ausdrücken><en> Simply put, holding Fosagro until recently tried to leave myself and the plant, and the money for it.
<G-vec00081-001-s039><put.ausdrücken><de> Einfach ausgedrückt, von der Interviewer Sie mochte oder nicht, hängt ab, ob Sie angestellt werden.
<G-vec00081-001-s039><put.ausdrücken><en> Simply put, on the interviewer liked you or not depends on whether you will be hired.
<G-vec00081-001-s040><put.ausdrücken><de> Der Weg, der aus dem Leiden herausführt, ist Meditation selbst oder anders ausgedrückt: Wir müssen achtsam sein.
<G-vec00081-001-s040><put.ausdrücken><en> To put it simply, we must be mindful. Mindfulness is knowing, or presence of mind.
<G-vec00081-001-s041><put.ausdrücken><de> "Vereinfacht ausgedrückt: Je kürzer Telomere im Lauf der Zeit werden, desto ""älter"" sind die Zellen."
<G-vec00081-001-s041><put.ausdrücken><en> "Put simply: the shorter the telomeres become over time, the ""older"" the cells."
<G-vec00081-001-s042><put.ausdrücken><de> Oder anders ausgedrückt: Das Atmen ist fünfzig Mal gefährlicher als die Summe der Strahlung, die wir normalerweise aus allen Quellen erhalten.
<G-vec00081-001-s042><put.ausdrücken><en> Or to put it another way, breathing is fifty times more dangerous than the sum total of radiation we normally receive from all sources.
<G-vec00081-001-s043><put.ausdrücken><de> Das bedeutet andersherum ausgedrückt: Viele Batterieanbieter müssen bei einer Auslegung auf 20 Jahre eine hohe Kapazität wählen, um bei einer geringen Entladetiefe (DoD) eine passable Nettokapazität zu erreichen.
<G-vec00081-001-s043><put.ausdrücken><en> Put another way, this means that a number of battery suppliers must ensure a high capacity level with a 20-year design to achieve an acceptable net capacity with a lower depth of discharge (DoD).
<G-vec00081-001-s044><put.ausdrücken><de> Einfach ausgedrückt: Autofahren wird in den kommenden Jahren noch sicherer und noch komfortabler.
<G-vec00081-001-s044><put.ausdrücken><en> To put it simply, in the coming years driving a car will become even safer and more comfortable.
<G-vec00081-001-s045><put.ausdrücken><de> Abschließend möchte ich noch sagen, daß jeder, der all diesem gegenüber einen logischen und analytischen Blickwinkel hat, sich alle schriftlichen Werke der Menschheit ansehen kann, alle Bücher, und keinen finden wird, der so klar und vollständig ausgedrückt hat, wie die Dynamiken überleben können.
<G-vec00081-001-s045><put.ausdrücken><en> And to finish off, I just want to say, anyone who has a logical and analytical viewpoint of all this can look through all the written works of man, all the written books, and they will never find anyone who has put it so clearly, and so fully there on how the dynamics can survive.
<G-vec00081-001-s046><put.ausdrücken><de> Einfach ausgedrückt, können Sie einfach mit einer Ferse auf den Boden klopfen, während Sie fernsehen oder am Computer arbeiten.
<G-vec00081-001-s046><put.ausdrücken><en> Simply put, you can just knock on the floor with a heel while watching TV or working on a computer.
<G-vec00081-001-s047><put.ausdrücken><de> Anavar ist noch 17 alpha alkyliert, modifiziert, die einfach ausgedrückt, legt nahe, dass es die Leber vor Abbau vermeidet die energetischen Komponenten, und es ist das, was eine Belastung für die Leber erzeugt, wenn in teuren einer Dosierung verwendet und auch für zu lang.
<G-vec00081-001-s047><put.ausdrücken><en> Anavar is still customized 17 alpha alkylated, which simply put, suggests that it avoids the liver from breaking down the energetic components, and it is THAT which causes a pressure to the liver if made use of in expensive a dosage as well as for too long.
<G-vec00081-001-s048><put.ausdrücken><de> Gleichmut bezieht sich hier, ganz einfach ausgedrückt, darauf, dass es zur Natur von Samsara gehört, dass es immer auf und ab geht.
<G-vec00081-001-s048><put.ausdrücken><en> Equanimity here, to put it in simple language, means that the nature of samsara is that it goes up and down.
<G-vec00081-001-s049><put.ausdrücken><de> Einfach ausgedrückt ist es der Wunsch, andere Menschen mögen glücklich sein.
<G-vec00081-001-s049><put.ausdrücken><en> Put simply, it's the wish that other people may be happy.
<G-vec00081-001-s050><put.ausdrücken><de> Die Forschung hat gezeigt, dass ältere wächst zu einem Anstieg der hyperplastischen Pathologien verbunden ist, oder, einfach ausgedrückt, ein Anstieg der Rate, mit der Ihre Zellen zu reproduzieren, eine Vorstufe zu Problemen wie Krebs.
<G-vec00081-001-s050><put.ausdrücken><en> Research has shown that growing older is linked to a rise in hyperplastic pathologies, or, simply put, a rise in the rate at which your cells reproduce, a precursor to problems like cancer.
<G-vec00081-001-s051><put.ausdrücken><de> Ganz einfach ausgedrückt ist Hingabe eine geschickte und praktische Art, uns empfänglicher für die Wahrheit der Lehren der Übertragungslinie zu machen, wie sie vom Lehrer verkörpert und übertragen werden.
<G-vec00081-001-s051><put.ausdrücken><en> Put most simply, devotion is a skilful and practical way of making us more receptive to the truth of the teachings of the lineage, as embodied and transmitted by the teacher.
<G-vec00081-001-s052><put.ausdrücken><de> Einfach ausgedrückt: sie können in den höheren Schwingungs-Ebenen nicht überleben, die lediglich für Seelen vorgesehen sind, die sich über die Notwendigkeit hinaus-entwickelt haben, die niedere Ebene noch weiter erfahren zu müssen.
<G-vec00081-001-s052><put.ausdrücken><en> Simply put, they cannot survive in the higher vibrations that are for souls who have moved past the need for further experience at that level.
<G-vec00081-001-s053><put.ausdrücken><de> Einfach ausgedrückt, gibt es keinen Grund, dass jemand mit Schizophrenie in einem Job nicht erfolgreich sein kann, wenn er die richtige Behandlung erhält.
<G-vec00081-001-s053><put.ausdrücken><en> Simply put, there’s no reason someone with schizophrenia can’t thrive in a job so long as they’re receiving the right treatment.
<G-vec00081-001-s054><put.ausdrücken><de> Oder anders ausgedrückt: Damit eine innovative Geschäftseinheit nicht vom Monolithen platt gemacht wird.
<G-vec00081-001-s054><put.ausdrücken><en> Or, to put it another way: so that an innovative business unit would not be squashed by monoliths.
<G-vec00081-001-s055><put.ausdrücken><de> Einfach ausgedrückt bedeutet dies, dass alle der Jahre Beiträge in die Rentensysteme der qualifizierten Länder berücksichtigt werden können, zu entscheiden, ob eine Person durch eine Rente oder nicht.
<G-vec00081-001-s055><put.ausdrücken><en> Put simply, this means that all of the years' contributions paid into the pension systems of qualifying countries can be taken into consideration to decide if an individual is due a pension or not.
<G-vec00081-001-s056><put.ausdrücken><de> Oder anders ausgedrückt verfallen die Preise für Technische Kunststoffe seit August 2015 (1310 €/t) bis Dezember 2015 (1227 €/t) schrittweise.
<G-vec00081-001-s056><put.ausdrücken><en> Or to put it differently: technical plastics prices have fallen by increments from August 2015 (1310 €/t) to December 2015 (1231 €/t).
