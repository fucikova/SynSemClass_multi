<G-vec00169-001-s031><capitalize.entfalten><de> Einige werden ihr Leistungsvermögen entfalten, doch die meisten werden ihre Ideen verwerfen und ihre berufliche Zukunft abseits der Gründerzentren und Innovation- Highways suchen.
<G-vec00169-001-s031><capitalize.entfalten><en> Some of them will capitalize on their capacities, but most will abandon their ideas and seek careers outside of the business incubators and innovation highways.
<G-vec00001-001-s152><develop.entfalten><de> Steht man aber davor, so wie jetzt in Murnau oder im neu gestalteten wunderschönen Lenbachhaus in MÃ1⁄4nchen, so entfalten die Gemälde eine Wucht und Kraft, die man MÃ1⁄4nter kaum zugetraut hätte.
<G-vec00001-001-s152><develop.entfalten><en> However, when you are standing in front of them, as I am now in Murnau or in the remodeled, beautiful Lenbachhaus in Munich, the paintings develop a force and an energy of which you would have hardly thought MÃ1⁄4nter was capable.
<G-vec00001-001-s153><develop.entfalten><de> So bekommt der Dreizylinder mehr Luft zum Atmen und kann schon bei niedriger Drehzahl eine beachtliche Durchzugskraft entfalten: Ab 1500/min stehen bereits 85 Newtonmeter und damit mehr als drei Viertel der maximalen Durchzugskraft zur Verfügung.
<G-vec00001-001-s153><develop.entfalten><en> "This gives the three-cylinder engine more air to ""breathe"" and enables it to develop impressive torque, even at low revs: 85 metres are available even from 1500 rpm – more than three quarters of the maximum torque."
<G-vec00001-001-s154><develop.entfalten><de> Das Hauptziel des Unterrichts ist es, bei den Kindern Liebe zu entfalten — die Liebe zu den Eltern, zu Freunden, zur Natur und zum allen Lebenden.
<G-vec00001-001-s154><develop.entfalten><en> The main goal of the classes is to develop in children love for parents, friends, nature, for everything living.
<G-vec00001-001-s155><develop.entfalten><de> Das heißt unter anderem: Wer bei uns arbeitet, bekommt Freiraum, um sich und seine Fähigkeiten zu entfalten.
<G-vec00001-001-s155><develop.entfalten><en> Among other things, this means that anyone who works for us has the creative freedom to develop themselves and their skills.
<G-vec00001-001-s156><develop.entfalten><de> Um möglichst viele Ideen zu entfalten und in die Tat umsetzen zu können brauchen wir Eure Unterstützung.
<G-vec00001-001-s156><develop.entfalten><en> In order to develop and implement as many ideas as possible, we need your help.
<G-vec00001-001-s157><develop.entfalten><de> """Die Räume entfalten erst mit dem richtigen Licht ihre Wirkung"", erklärt der Architekt Jürgen Kitzmüller."
<G-vec00001-001-s157><develop.entfalten><en> """The rooms only develop their full effect with the right light,"" explains the architect Jürgen Kitzmüller."
<G-vec00001-001-s158><develop.entfalten><de> Bei körperlicher Anstrengung wird mehr sowie tiefer geatmet und Ozon gelangt mit jedem Atemzug in die Atemwege und Lungen und kann so nachteilige gesundheitliche Wirkungen entfalten.
<G-vec00001-001-s158><develop.entfalten><en> During physical exertion, we breathe faster and deeper, ozone enters the respiratory tract and lungs and thus adverse health effects can develop.
<G-vec00001-001-s159><develop.entfalten><de> Unsere internationalen Wettbewerber sind uns wichtig: Je besser sie sind, um so mehr Ansporn entfalten sie für uns.
<G-vec00001-001-s159><develop.entfalten><en> Our international competitors are important to us: The better they are, the better we develop.
<G-vec00001-001-s160><develop.entfalten><de> Wir müssen im Gegenteil unsererseits einen breiten ideologischen Kampf auf der Grundlage einer klaren, populären Argumentation und eines richtigen, gut durchdachten Herangehens an die Eigenart der nationalen Psychologie der Volksmassen entfalten.
<G-vec00001-001-s160><develop.entfalten><en> On the contrary, we for our part must develop an extensive ideological struggle based on clear, popular arguments and a correct, well thought out approach to the peculiarities of the national psychology of the masses of the people.
<G-vec00001-001-s161><develop.entfalten><de> Die Übung der Selbstbeherrschung wird dich nicht vollkommen machen (mich jedenfalls nicht), aber Selbstbeherrschung ist notwendig, um die Liebe in unseren Herzen zu entfalten und zu schützen und andere davor zu bewahren, besonders unsere Familie und unsere Freunde, durch unsere Verfehlungen verletzt zu werden, sei es aus Bosheit oder Faulheit.
<G-vec00001-001-s161><develop.entfalten><en> The practice of self control won’t make you perfect (it hasn’t with me), but self control is necessary to develop and protect the love in our hearts and prevent others, especially our family and friends, from being hurt by our lapses into nastiness or laziness.
<G-vec00001-001-s162><develop.entfalten><de> Die DEZA setzt sich dafür ein, dass Frauen und Männer gleichberechtigt ihr Potenzial entfalten und ihre Ressourcen sinnvoll einsetzen können.
<G-vec00001-001-s162><develop.entfalten><en> The SDC is helping to ensure that women and men have the same right to develop their potential and can use their resources in a meaningful way.
<G-vec00001-001-s163><develop.entfalten><de> Bei LMT Tools können Sie sich und Ihre Berufslaufbahn voll entfalten.
<G-vec00001-001-s163><develop.entfalten><en> At LMT Tools you can fully develop your career path.
<G-vec00001-001-s164><develop.entfalten><de> Dank der besonders leichten Konsistenz ziehen sie schnell in die Haut ein und entfalten dort ihre Wirkung.
<G-vec00001-001-s164><develop.entfalten><en> Thanks to their particularly light consistency they absorb fast into the skin, where they can develop their full effect.
<G-vec00001-001-s165><develop.entfalten><de> Genau das Gegenteil ist der Fall: Das Grundgesetz gewährt den Religionsgemeinschaften mit gutem Grund die Möglichkeit, mit einem institutionellen Status ihr öffentliches Wirken zu entfalten.
<G-vec00001-001-s165><develop.entfalten><en> Exactly the opposite is the case: For good reasons the Basic Law grants the religious communities the possibility to develop their public work with an institutional status.
<G-vec00001-001-s166><develop.entfalten><de> Es bestimmt nur den verfassungsrechtlichen Rahmen, innerhalb dessen sich die Politik entfalten kann.
<G-vec00001-001-s166><develop.entfalten><en> It merely determines the constitutional framework within which politics may develop.
<G-vec00001-001-s167><develop.entfalten><de> Auf der Webseite BBC auch die ausführliche Beschreibung der Ereignisse, die in einer festlichen Serie entfalten werden.
<G-vec00001-001-s167><develop.entfalten><en> On the site BBC also detailed description of events which will develop in a festive series.
<G-vec00001-001-s168><develop.entfalten><de> Man gibt dem Pferd die Chance, sich innerhalb eines großzügigen Rahmens zu entfalten.
<G-vec00001-001-s168><develop.entfalten><en> The horse needs to be given the chance to develop himself to the full within a broader framework.
<G-vec00001-001-s169><develop.entfalten><de> Bei der Dhamma-Praxis musst du die feste Absicht haben, Weisheit zu entfalten; ansonsten werden die Befleckungen und Begierden unaufhörlich die Sieger sein.
<G-vec00001-001-s169><develop.entfalten><en> In Dhamma practice you must have firm intent to develop wisdom; otherwise defilements and desires will be perpetual winners.
<G-vec00001-001-s170><develop.entfalten><de> Zwei Beispiele: Um die Kreativität von Kindern herauszufordern, müssen Spielorte Gestaltungsfreiheit zulassen, damit sich die Spielmöglichkeiten und Bewegungsabläufe flexibel und individuell entfalten können.
<G-vec00001-001-s170><develop.entfalten><en> Two examples: To challenge the creativity of children, playing venues must allow design freedom to allow playing and activities to develop flexibly and individually.
<G-vec00179-001-s152><develop.entfalten><de> Steht man aber davor, so wie jetzt in Murnau oder im neu gestalteten wunderschönen Lenbachhaus in MÃ1⁄4nchen, so entfalten die Gemälde eine Wucht und Kraft, die man MÃ1⁄4nter kaum zugetraut hätte.
<G-vec00179-001-s152><develop.entfalten><en> However, when you are standing in front of them, as I am now in Murnau or in the remodeled, beautiful Lenbachhaus in Munich, the paintings develop a force and an energy of which you would have hardly thought MÃ1⁄4nter was capable.
<G-vec00179-001-s153><develop.entfalten><de> So bekommt der Dreizylinder mehr Luft zum Atmen und kann schon bei niedriger Drehzahl eine beachtliche Durchzugskraft entfalten: Ab 1500/min stehen bereits 85 Newtonmeter und damit mehr als drei Viertel der maximalen Durchzugskraft zur Verfügung.
<G-vec00179-001-s153><develop.entfalten><en> "This gives the three-cylinder engine more air to ""breathe"" and enables it to develop impressive torque, even at low revs: 85 metres are available even from 1500 rpm – more than three quarters of the maximum torque."
<G-vec00179-001-s154><develop.entfalten><de> Das Hauptziel des Unterrichts ist es, bei den Kindern Liebe zu entfalten — die Liebe zu den Eltern, zu Freunden, zur Natur und zum allen Lebenden.
<G-vec00179-001-s154><develop.entfalten><en> The main goal of the classes is to develop in children love for parents, friends, nature, for everything living.
<G-vec00179-001-s155><develop.entfalten><de> Das heißt unter anderem: Wer bei uns arbeitet, bekommt Freiraum, um sich und seine Fähigkeiten zu entfalten.
<G-vec00179-001-s155><develop.entfalten><en> Among other things, this means that anyone who works for us has the creative freedom to develop themselves and their skills.
<G-vec00179-001-s156><develop.entfalten><de> Um möglichst viele Ideen zu entfalten und in die Tat umsetzen zu können brauchen wir Eure Unterstützung.
<G-vec00179-001-s156><develop.entfalten><en> In order to develop and implement as many ideas as possible, we need your help.
<G-vec00179-001-s157><develop.entfalten><de> """Die Räume entfalten erst mit dem richtigen Licht ihre Wirkung"", erklärt der Architekt Jürgen Kitzmüller."
<G-vec00179-001-s157><develop.entfalten><en> """The rooms only develop their full effect with the right light,"" explains the architect Jürgen Kitzmüller."
<G-vec00179-001-s158><develop.entfalten><de> Bei körperlicher Anstrengung wird mehr sowie tiefer geatmet und Ozon gelangt mit jedem Atemzug in die Atemwege und Lungen und kann so nachteilige gesundheitliche Wirkungen entfalten.
<G-vec00179-001-s158><develop.entfalten><en> During physical exertion, we breathe faster and deeper, ozone enters the respiratory tract and lungs and thus adverse health effects can develop.
<G-vec00179-001-s159><develop.entfalten><de> Unsere internationalen Wettbewerber sind uns wichtig: Je besser sie sind, um so mehr Ansporn entfalten sie für uns.
<G-vec00179-001-s159><develop.entfalten><en> Our international competitors are important to us: The better they are, the better we develop.
<G-vec00179-001-s160><develop.entfalten><de> Wir müssen im Gegenteil unsererseits einen breiten ideologischen Kampf auf der Grundlage einer klaren, populären Argumentation und eines richtigen, gut durchdachten Herangehens an die Eigenart der nationalen Psychologie der Volksmassen entfalten.
<G-vec00179-001-s160><develop.entfalten><en> On the contrary, we for our part must develop an extensive ideological struggle based on clear, popular arguments and a correct, well thought out approach to the peculiarities of the national psychology of the masses of the people.
<G-vec00179-001-s161><develop.entfalten><de> Die Übung der Selbstbeherrschung wird dich nicht vollkommen machen (mich jedenfalls nicht), aber Selbstbeherrschung ist notwendig, um die Liebe in unseren Herzen zu entfalten und zu schützen und andere davor zu bewahren, besonders unsere Familie und unsere Freunde, durch unsere Verfehlungen verletzt zu werden, sei es aus Bosheit oder Faulheit.
<G-vec00179-001-s161><develop.entfalten><en> The practice of self control won’t make you perfect (it hasn’t with me), but self control is necessary to develop and protect the love in our hearts and prevent others, especially our family and friends, from being hurt by our lapses into nastiness or laziness.
<G-vec00179-001-s162><develop.entfalten><de> Die DEZA setzt sich dafür ein, dass Frauen und Männer gleichberechtigt ihr Potenzial entfalten und ihre Ressourcen sinnvoll einsetzen können.
<G-vec00179-001-s162><develop.entfalten><en> The SDC is helping to ensure that women and men have the same right to develop their potential and can use their resources in a meaningful way.
<G-vec00179-001-s163><develop.entfalten><de> Bei LMT Tools können Sie sich und Ihre Berufslaufbahn voll entfalten.
<G-vec00179-001-s163><develop.entfalten><en> At LMT Tools you can fully develop your career path.
<G-vec00179-001-s164><develop.entfalten><de> Dank der besonders leichten Konsistenz ziehen sie schnell in die Haut ein und entfalten dort ihre Wirkung.
<G-vec00179-001-s164><develop.entfalten><en> Thanks to their particularly light consistency they absorb fast into the skin, where they can develop their full effect.
<G-vec00179-001-s165><develop.entfalten><de> Genau das Gegenteil ist der Fall: Das Grundgesetz gewährt den Religionsgemeinschaften mit gutem Grund die Möglichkeit, mit einem institutionellen Status ihr öffentliches Wirken zu entfalten.
<G-vec00179-001-s165><develop.entfalten><en> Exactly the opposite is the case: For good reasons the Basic Law grants the religious communities the possibility to develop their public work with an institutional status.
<G-vec00179-001-s166><develop.entfalten><de> Es bestimmt nur den verfassungsrechtlichen Rahmen, innerhalb dessen sich die Politik entfalten kann.
<G-vec00179-001-s166><develop.entfalten><en> It merely determines the constitutional framework within which politics may develop.
<G-vec00179-001-s167><develop.entfalten><de> Auf der Webseite BBC auch die ausführliche Beschreibung der Ereignisse, die in einer festlichen Serie entfalten werden.
<G-vec00179-001-s167><develop.entfalten><en> On the site BBC also detailed description of events which will develop in a festive series.
<G-vec00179-001-s168><develop.entfalten><de> Man gibt dem Pferd die Chance, sich innerhalb eines großzügigen Rahmens zu entfalten.
<G-vec00179-001-s168><develop.entfalten><en> The horse needs to be given the chance to develop himself to the full within a broader framework.
<G-vec00179-001-s169><develop.entfalten><de> Bei der Dhamma-Praxis musst du die feste Absicht haben, Weisheit zu entfalten; ansonsten werden die Befleckungen und Begierden unaufhörlich die Sieger sein.
<G-vec00179-001-s169><develop.entfalten><en> In Dhamma practice you must have firm intent to develop wisdom; otherwise defilements and desires will be perpetual winners.
<G-vec00179-001-s170><develop.entfalten><de> Zwei Beispiele: Um die Kreativität von Kindern herauszufordern, müssen Spielorte Gestaltungsfreiheit zulassen, damit sich die Spielmöglichkeiten und Bewegungsabläufe flexibel und individuell entfalten können.
<G-vec00179-001-s170><develop.entfalten><en> Two examples: To challenge the creativity of children, playing venues must allow design freedom to allow playing and activities to develop flexibly and individually.
<G-vec00510-001-s152><develop.entfalten><de> Steht man aber davor, so wie jetzt in Murnau oder im neu gestalteten wunderschönen Lenbachhaus in MÃ1⁄4nchen, so entfalten die Gemälde eine Wucht und Kraft, die man MÃ1⁄4nter kaum zugetraut hätte.
<G-vec00510-001-s152><develop.entfalten><en> However, when you are standing in front of them, as I am now in Murnau or in the remodeled, beautiful Lenbachhaus in Munich, the paintings develop a force and an energy of which you would have hardly thought MÃ1⁄4nter was capable.
<G-vec00510-001-s153><develop.entfalten><de> So bekommt der Dreizylinder mehr Luft zum Atmen und kann schon bei niedriger Drehzahl eine beachtliche Durchzugskraft entfalten: Ab 1500/min stehen bereits 85 Newtonmeter und damit mehr als drei Viertel der maximalen Durchzugskraft zur Verfügung.
<G-vec00510-001-s153><develop.entfalten><en> "This gives the three-cylinder engine more air to ""breathe"" and enables it to develop impressive torque, even at low revs: 85 metres are available even from 1500 rpm – more than three quarters of the maximum torque."
<G-vec00510-001-s154><develop.entfalten><de> Das Hauptziel des Unterrichts ist es, bei den Kindern Liebe zu entfalten — die Liebe zu den Eltern, zu Freunden, zur Natur und zum allen Lebenden.
<G-vec00510-001-s154><develop.entfalten><en> The main goal of the classes is to develop in children love for parents, friends, nature, for everything living.
<G-vec00510-001-s155><develop.entfalten><de> Das heißt unter anderem: Wer bei uns arbeitet, bekommt Freiraum, um sich und seine Fähigkeiten zu entfalten.
<G-vec00510-001-s155><develop.entfalten><en> Among other things, this means that anyone who works for us has the creative freedom to develop themselves and their skills.
<G-vec00510-001-s156><develop.entfalten><de> Um möglichst viele Ideen zu entfalten und in die Tat umsetzen zu können brauchen wir Eure Unterstützung.
<G-vec00510-001-s156><develop.entfalten><en> In order to develop and implement as many ideas as possible, we need your help.
<G-vec00510-001-s157><develop.entfalten><de> """Die Räume entfalten erst mit dem richtigen Licht ihre Wirkung"", erklärt der Architekt Jürgen Kitzmüller."
<G-vec00510-001-s157><develop.entfalten><en> """The rooms only develop their full effect with the right light,"" explains the architect Jürgen Kitzmüller."
<G-vec00510-001-s158><develop.entfalten><de> Bei körperlicher Anstrengung wird mehr sowie tiefer geatmet und Ozon gelangt mit jedem Atemzug in die Atemwege und Lungen und kann so nachteilige gesundheitliche Wirkungen entfalten.
<G-vec00510-001-s158><develop.entfalten><en> During physical exertion, we breathe faster and deeper, ozone enters the respiratory tract and lungs and thus adverse health effects can develop.
<G-vec00510-001-s159><develop.entfalten><de> Unsere internationalen Wettbewerber sind uns wichtig: Je besser sie sind, um so mehr Ansporn entfalten sie für uns.
<G-vec00510-001-s159><develop.entfalten><en> Our international competitors are important to us: The better they are, the better we develop.
<G-vec00510-001-s160><develop.entfalten><de> Wir müssen im Gegenteil unsererseits einen breiten ideologischen Kampf auf der Grundlage einer klaren, populären Argumentation und eines richtigen, gut durchdachten Herangehens an die Eigenart der nationalen Psychologie der Volksmassen entfalten.
<G-vec00510-001-s160><develop.entfalten><en> On the contrary, we for our part must develop an extensive ideological struggle based on clear, popular arguments and a correct, well thought out approach to the peculiarities of the national psychology of the masses of the people.
<G-vec00510-001-s161><develop.entfalten><de> Die Übung der Selbstbeherrschung wird dich nicht vollkommen machen (mich jedenfalls nicht), aber Selbstbeherrschung ist notwendig, um die Liebe in unseren Herzen zu entfalten und zu schützen und andere davor zu bewahren, besonders unsere Familie und unsere Freunde, durch unsere Verfehlungen verletzt zu werden, sei es aus Bosheit oder Faulheit.
<G-vec00510-001-s161><develop.entfalten><en> The practice of self control won’t make you perfect (it hasn’t with me), but self control is necessary to develop and protect the love in our hearts and prevent others, especially our family and friends, from being hurt by our lapses into nastiness or laziness.
<G-vec00510-001-s162><develop.entfalten><de> Die DEZA setzt sich dafür ein, dass Frauen und Männer gleichberechtigt ihr Potenzial entfalten und ihre Ressourcen sinnvoll einsetzen können.
<G-vec00510-001-s162><develop.entfalten><en> The SDC is helping to ensure that women and men have the same right to develop their potential and can use their resources in a meaningful way.
<G-vec00510-001-s163><develop.entfalten><de> Bei LMT Tools können Sie sich und Ihre Berufslaufbahn voll entfalten.
<G-vec00510-001-s163><develop.entfalten><en> At LMT Tools you can fully develop your career path.
<G-vec00510-001-s164><develop.entfalten><de> Dank der besonders leichten Konsistenz ziehen sie schnell in die Haut ein und entfalten dort ihre Wirkung.
<G-vec00510-001-s164><develop.entfalten><en> Thanks to their particularly light consistency they absorb fast into the skin, where they can develop their full effect.
<G-vec00510-001-s165><develop.entfalten><de> Genau das Gegenteil ist der Fall: Das Grundgesetz gewährt den Religionsgemeinschaften mit gutem Grund die Möglichkeit, mit einem institutionellen Status ihr öffentliches Wirken zu entfalten.
<G-vec00510-001-s165><develop.entfalten><en> Exactly the opposite is the case: For good reasons the Basic Law grants the religious communities the possibility to develop their public work with an institutional status.
<G-vec00510-001-s166><develop.entfalten><de> Es bestimmt nur den verfassungsrechtlichen Rahmen, innerhalb dessen sich die Politik entfalten kann.
<G-vec00510-001-s166><develop.entfalten><en> It merely determines the constitutional framework within which politics may develop.
<G-vec00510-001-s167><develop.entfalten><de> Auf der Webseite BBC auch die ausführliche Beschreibung der Ereignisse, die in einer festlichen Serie entfalten werden.
<G-vec00510-001-s167><develop.entfalten><en> On the site BBC also detailed description of events which will develop in a festive series.
<G-vec00510-001-s168><develop.entfalten><de> Man gibt dem Pferd die Chance, sich innerhalb eines großzügigen Rahmens zu entfalten.
<G-vec00510-001-s168><develop.entfalten><en> The horse needs to be given the chance to develop himself to the full within a broader framework.
<G-vec00510-001-s169><develop.entfalten><de> Bei der Dhamma-Praxis musst du die feste Absicht haben, Weisheit zu entfalten; ansonsten werden die Befleckungen und Begierden unaufhörlich die Sieger sein.
<G-vec00510-001-s169><develop.entfalten><en> In Dhamma practice you must have firm intent to develop wisdom; otherwise defilements and desires will be perpetual winners.
<G-vec00510-001-s170><develop.entfalten><de> Zwei Beispiele: Um die Kreativität von Kindern herauszufordern, müssen Spielorte Gestaltungsfreiheit zulassen, damit sich die Spielmöglichkeiten und Bewegungsabläufe flexibel und individuell entfalten können.
<G-vec00510-001-s170><develop.entfalten><en> Two examples: To challenge the creativity of children, playing venues must allow design freedom to allow playing and activities to develop flexibly and individually.
