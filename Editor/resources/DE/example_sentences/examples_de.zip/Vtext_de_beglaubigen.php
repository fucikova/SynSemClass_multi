<G-vec00060-001-s038><attest.beglaubigen><de> Wenn zuerst gesehen von der Straße, würde es erscheinen, dass es kaum gibt, irgendetwas hat verlassen, zur Existenz von der religiösen Stadt zu beglaubigen.
<G-vec00060-001-s038><attest.beglaubigen><en> When first seen from the road, it would appear that there is hardly anything left to attest to the existence of the religious city.
