<G-vec00179-001-s095><run.betreiben><de> Sei bereit, mit Deinem grünen Daumen Deine eigene Magic Farm zu kreieren, zu betreiben und auszubauen.
<G-vec00179-001-s095><run.betreiben><en> Get out your green thumb to run, buy, and upgrade your very own Magic Farm!
<G-vec00179-001-s096><run.betreiben><de> Wenn Sie ein Makler-Büro in der Schweiz betreiben, müssen Sie viele Anschreiben versenden.
<G-vec00179-001-s096><run.betreiben><en> If you run a real estate agency, you need to send lots of letters.
<G-vec00179-001-s097><run.betreiben><de> Als das Gut in Kalkar-Appeldorn zum Verkauf stand, stand für das Duo schnell fest, dass es ihn gemeinsam erwerben und betreiben will.
<G-vec00179-001-s097><run.betreiben><en> When the property in Kalkar-Appeldorn came on the market, the pair quickly agreed that they wanted to buy and run it together.
<G-vec00179-001-s098><run.betreiben><de> Wir betreiben auch 10 Entwicklermaschinen unter Debian.
<G-vec00179-001-s098><run.betreiben><en> We also run 10 developer workstations on Debian.
<G-vec00179-001-s099><run.betreiben><de> Ab 1995 ermöglichte eine Gesetzesänderung in NRW, dass Mitglieder von Hochschulen nichtkommerzielle Radiosender betreiben dürfen.
<G-vec00179-001-s099><run.betreiben><en> From 1995, a change to the law in NRW allowed university members to run non-profit radio stations.
<G-vec00179-001-s100><run.betreiben><de> Sie benötigen schnelles, sicheres, zuverlässiges und benutzerfreundliches Webhosting, um Ihre professionelle Website zu betreiben.
<G-vec00179-001-s100><run.betreiben><en> You need fast, secure, reliable and user friendly web hosting to run your professional website.
<G-vec00179-001-s101><run.betreiben><de> Es ist gut vorstellbar, dass Banken gemeinsame digitale Marktplätze oder Plattformen betreiben.
<G-vec00179-001-s101><run.betreiben><en> It is easy to imagine that banks might run digital marketplaces or platforms together.
<G-vec00179-001-s102><run.betreiben><de> Wir k ö nnen jedoch pers ö nliche Informationen ü ber unsere Benutzer, soweit erforderlich, an andere Dienstleistungsanbieter weitergeben, die uns helfen, die Website zu betreiben, oder die bestimmte Funktionen f ü r uns ausf ü hren.
<G-vec00179-001-s102><run.betreiben><en> We may, however, share personal information about our users, as necessary, with third party service providers that help us run the site or perform certain functions on our behalf.
<G-vec00179-001-s103><run.betreiben><de> Wir helfen bei der Gestaltung kommunaler Strategien, betreiben ein Cluster für Kreativwirtschaft und ein nationales Kompetenzzentrum in den Bereichen Bildung, Forschung, Kultur, Kommunikation und Unternehmensentwicklung.
<G-vec00179-001-s103><run.betreiben><en> We help design municipal strategies, run a creative industry cluster and a national center of expertise in the areas of education, research, culture, communication and business development.
<G-vec00179-001-s104><run.betreiben><de> Es ist die eine Sache, eine IT Infrastruktur aufzustellen und nochmal eine andere diese aufrechtzuerhalten und reibungslos zu betreiben, sie effizient und proaktiv zu verwalten, um ihre Funktion zu verbessern.
<G-vec00179-001-s104><run.betreiben><en> It's one thing to deploy IT Infrastructure, it's quite another to maintain and run it smoothly, efficiently, and proactively manage it to improve performance.
<G-vec00179-001-s105><run.betreiben><de> Heutzutage betreiben die Drei Familien die Raffinerien und Aufbereitungsanlagen von Quesh, während die Republik die Minen beaufsichtigt.
<G-vec00179-001-s105><run.betreiben><en> Today, the Three Families run Quesh's refineries and processing plants while the Republic controls the mines.
<G-vec00179-001-s106><run.betreiben><de> Nachdem eine neue Sportanlage in Klagenfurt installiert wurde, hatten wir die Möglichkeit, auf der Bergo MULTISPORT Bodenbeläge, curling.After anfänglichen Zweifel und erste Aufnahmen mit dem Stick zu betreiben, durch einen Mitarbeiter des Sports Union kam ganz enjoy.Upon Fertigstellung der Bau der Sport-Komplex die Möglichkeit, auf dem Boden von Sportanlagen MULTISPORT im Sommer Zug getestet, als Alternative zu Asphalt oder concrete.Then anweisen Abschnitt der Szene gefragt wurde, wer durchgeführt einige Tests und dann jetzt auch von den angeregten Spiel Markierungen gefragt, welche mit der Sonderlackierung für Kunststoff sein muss, anschließend aufgetragenen ..
<G-vec00179-001-s106><run.betreiben><en> After the construction of new sports facilities in Klagenfurt, the possibility has been tested to run on the curling MULTISPORT flooring. After initial skepticism, and the first litters the floor by an employee of the Sports Union, came to quite enjoy. Then instruct the Section was to the scene asked who carried out some tests also now and then enthusiastically asked about the game markers.
<G-vec00179-001-s107><run.betreiben><de> Ich komme aus einer Familie von 6: Mein Vater hat bereits seit zwei Jahren starb jetzt, meine Mutter ist Lehrerin und auch selbstständig und betreiben ein kleines Tourist Lodge in Moshi.
<G-vec00179-001-s107><run.betreiben><en> I come from a family of 6: my father has already died for two years now, my mother is a teacher and also self employed and run a small tourist lodge in Moshi.
<G-vec00179-001-s108><run.betreiben><de> UserLAnd: Einfachste Art GNU/Linux-Distros auf Android zu betreiben - Root-Rechte sind nicht erforderlich.
<G-vec00179-001-s108><run.betreiben><en> UserLAnd: Easiest way to run gnu/linux distros on android - no root required.
<G-vec00179-001-s109><run.betreiben><de> Im Notfall können Sie Live auf einem beliebigen Rechner installieren, betreiben und die Backups Ihrer Live-Sets abspielen.
<G-vec00179-001-s109><run.betreiben><en> In case of an emergency, you can install and run Live on any computer available and play your backup Live Set(s).
<G-vec00179-001-s110><run.betreiben><de> Es ist nichts falsch mit diesem, aber Sie sollten mindestens betreiben eine kleine Link-Building Kampagne auf eigene Faust erste, so haben Sie eine bessere Vorstellung davon, was man aus welchen Service Sie wählen, bekommen.
<G-vec00179-001-s110><run.betreiben><en> There's nothing wrong with this, but you should at least run a small link building campaign on your own first, so you have a better idea of what you're getting from whatever service you choose.
<G-vec00179-001-s111><run.betreiben><de> Doch wir haben mit unseren besten Fachhändlern eine hervorragende Omni-Channel-Zusammenarbeit, über Markenshops, die wir gemeinsam betreiben.
<G-vec00179-001-s111><run.betreiben><en> But with our best specialist retailers, we enjoy excellent, omni-channel collaboration through brand shops that we run together.
<G-vec00179-001-s112><run.betreiben><de> Unterstützung u. Schulung: Durch ein neues, globales Kunden-Callcenter und fortschrittlichste Produktschulung erhalten Sie das Fachwissen und die Antworten, um Ihren Betrieb effizienter zu betreiben.
<G-vec00179-001-s112><run.betreiben><en> Support & Training: A new global customer call center and leading-edge product training means you get the expertise and answers to run your operation more efficiently.
<G-vec00179-001-s113><run.betreiben><de> Um das herauszufinden, kannst Du den Manager fragen, der Dich beim Betreiben der Station unterstützt, oder Du kannst einfach daran vorbeifliegen und selber ein Auge darauf werfen.
<G-vec00179-001-s113><run.betreiben><en> Well you can ask the manager who helps you run the station, or you can just fly past it and see for yourself.
<G-vec00276-001-s311><advertise.betreiben><de> Um mit Zustimmung des Nutzers / der Nutzerin Werbung zu betreiben.
<G-vec00276-001-s311><advertise.betreiben><en> To advertise with the User's consent.
<G-vec00276-001-s312><advertise.betreiben><de> "Vielmehr fungiert die Website als Plattform, um Gastwirten oder Eigentümern von Unterkünften, die Werbung auf unserer Website betreiben (jeweils ein ""Mitglied ""), zu ermöglichen, potenziellen Gästen (jeweils ein ""Urlauber "" und gemeinsam mit einem Mitglied die ""Nutzer "") Buchungen von Zimmern in ihren Unterkünften anzubieten."
<G-vec00276-001-s312><advertise.betreiben><en> "Instead, the Site acts as a venue to allow innkeepers or owners of properties who advertise on our Site (each, a ""member "") to offer reservations for rooms in their properties to potential guests (each, a ""traveler "" and, collectively with a member, the ""users "")."
<G-vec00276-001-s313><advertise.betreiben><de> keine Werbung ohne ausdrückliche schriftliche Genehmigung des Anbieters zu betreiben.
<G-vec00276-001-s313><advertise.betreiben><en> not to advertise without the explicit written approval of the supplier.
