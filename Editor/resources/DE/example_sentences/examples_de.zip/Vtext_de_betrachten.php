<G-vec00003-001-s209><look.betrachten><de> „Wir betrachten den Technologieeinsatz immer von zwei Standpunkten: aus Sicht der Produktion und aus Sicht der Logistik.
<G-vec00003-001-s209><look.betrachten><en> „We always look at the use of technology from two different sides: from the production and logistics perspective.
<G-vec00003-001-s210><look.betrachten><de> Es ist nötig, dass wir noch einmal all die Dinge betrachten, die Israel zum Absturz brachten und es jenes großen und herrlichen Zieles beraubten, das Gott ihnen vorgesetzt hatte.
<G-vec00003-001-s210><look.betrachten><en> It is for us to look carefully again at the things which brought about Israel's downfall and robbed Israel of that great and glorious issue which God had set before them.
<G-vec00003-001-s211><look.betrachten><de> Sie betrachten al les vom Standpunkt des Menschen Kör pers oder der verkörperten Seele aus.
<G-vec00003-001-s211><look.betrachten><en> When Masters come, They look from a universal point of view.
<G-vec00003-001-s212><look.betrachten><de> Das andere Extrem ist, die Gelübde so zu betrachten wie ein Rechtsanwalt.
<G-vec00003-001-s212><look.betrachten><en> To the other extreme, we could look at the vows like a lawyer.
<G-vec00003-001-s213><look.betrachten><de> Ein Anschluß gesteht dir eine Weise, die gleichen Daten mit unterschiedlichen Arten zu betrachten, zu oder die gleichen Daten mit unterschiedlichen Namen zu verwenden.
<G-vec00003-001-s213><look.betrachten><en> A union allows you a way to look at the same data with different types, or to use the same data with different names.
<G-vec00003-001-s214><look.betrachten><de> Trotz dieser Einschränkung lädt das Bild ein, nicht nur die Stadt zu betrachten, sondern beispielsweise nach Kapellen, Grenzsteinen, Flurkreuzen oder 26 verschiedenen Schiffstypen auf dem Rhein zu suchen.
<G-vec00003-001-s214><look.betrachten><en> Despite this limitation, the townscape invites you not only to look at the town, but also to look for chapels, landmarks, wayside crosses or 26 different types of ship on the Rhine.
<G-vec00003-001-s215><look.betrachten><de> Wir nehmen diesen Jahrestag zum Anlaß, die komplexe Persönlichkeit dieses Dieners Gottes, der uns so viel Großes gelehrt, so viel Vorbildliches gezeigt hat, aus nächster Nähe zu betrachten, in der Überzeugung, daß die Zeit seine Person und sein Werk immer mehr erleuchten werden.
<G-vec00003-001-s215><look.betrachten><en> Let us take the occasion of this anniversary to look more closely at the complex personality of this servant of God who has left us so many lessons and great examples, in the conviction that time will exalt his figure and doings ever increasingly.
<G-vec00003-001-s216><look.betrachten><de> ...wir können die Erfahrungen von Lateinamerika betrachten: In Chile wurde eine Alternative aufgestellt, aber das war Anlass für einen Militärputsch und einen Destabilisierungsprozess, der von den Geheimdiensten der Vereinigten Saaten ausgeführt wurde, durch Sabotagen, durch Embargos und so weiter; denn ich habe diesen Putsch erlebt.
<G-vec00003-001-s216><look.betrachten><en> """... we can also look at the experiences of Latin America: Chile created an alternative, but then was subjected to a military coup and a process of destabilization that was carried out by the United States intelligence services, by sabotage, by embargoes and such, because I experienced that coup."
<G-vec00003-001-s217><look.betrachten><de> Dann wenn du denkst, ist es Zeit zu wässern, den Stock zu ziehen und ihn zu betrachten.
<G-vec00003-001-s217><look.betrachten><en> Then, when you think it is time to water, pull the stick and look at it.
<G-vec00003-001-s218><look.betrachten><de> Um zu verstehen, wieso die Arbeit in den letzten drei Jahrzehnten zunehmend degradiert worden ist, müssen wir daher zunächst diese historische Dynamik betrachten.
<G-vec00003-001-s218><look.betrachten><en> In order to understand how labor has been increasingly degraded over the last three decades, we must therefore look more closely at these historical dynamics first.
<G-vec00003-001-s219><look.betrachten><de> Definitionen und Vorstellungen definieren, wie Sie das Desktop-Publishing betrachten - die zu verwenden Software, die Plattform, die Sie wählen, und was die Bezeichnung für Sie bedeutet.
<G-vec00003-001-s219><look.betrachten><en> Definitions and perceptions define how you look at desktop publishing – the software to use, the platform you choose, and what the term means for you.
<G-vec00003-001-s220><look.betrachten><de> Zu jeder Zeit ist die praktische Anwendung im Ausstellungsraum zu betrachten.
<G-vec00003-001-s220><look.betrachten><en> You can take a look at the practical application at any time in the showroom.
<G-vec00003-001-s221><look.betrachten><de> Beim letzten Mal habe ich über die Gefahr der »abwesenden« Väter gesprochen; heute will ich vielmehr den positiven Aspekt betrachten.
<G-vec00003-001-s221><look.betrachten><en> Last time I spoke about the danger of “absent” fathers, today I would like to look instead at the positive aspect.
<G-vec00003-001-s222><look.betrachten><de> Um ein Opfer der sneaky Autohändler zu werden zu vermeiden, die folgenden selbst finanzierenden scams betrachten.
<G-vec00003-001-s222><look.betrachten><en> To avoid becoming a victim of sneaky car dealers, look at the following auto financing scams.
<G-vec00003-001-s223><look.betrachten><de> Ich wollte die Windhundzucht in Tschechien aus einem anderen Gesichtspunkt betrachten als gewöhnlich.
<G-vec00003-001-s223><look.betrachten><en> I would like to look at the greyhound breeding from slightly different angle than usually.
<G-vec00003-001-s224><look.betrachten><de> Wenn Sie eines der spektakulären Schweizer Replica-Uhr wie Rolex Datejust II Swiss ETA 2836 Bewegung römische Marker mit MOP Zifferblatt auf dem Display betrachten, können Sie sich nicht beschränken, für den Kauf einer einzigen – vor allem, nachdem er einen Blick auf diesen Preis.
<G-vec00003-001-s224><look.betrachten><en> When you look at one of the spectacular Swiss replica watch like Rolex Datejust II Swiss ETA 2836 Movement Roman Markers With MOP Dial on display, you can not limit yourself to buying a single – especially after having a look at this price .
<G-vec00003-001-s225><look.betrachten><de> """Wir wollen jüdische Themen sachlich betrachten, nicht emotional."
<G-vec00003-001-s225><look.betrachten><en> """Our aim is to look at Jewish topics objectively, not emotionally."
<G-vec00003-001-s226><look.betrachten><de> Betrachten wir die Unterschiede zwischen den Reaktionen in Göteborg und in Umeå.
<G-vec00003-001-s226><look.betrachten><en> Let's look at the differences between the reactions in Gothenburg and in Umeå.
<G-vec00003-001-s227><look.betrachten><de> Wenn Sie den Starry Night aus verschiedenen Perspektiven betrachten, schein es alsob der Stern über den Edelstein tanzt.
<G-vec00003-001-s227><look.betrachten><en> When you look at the Starry Night from different perspectives, it seems like the star dances over the gemstone.
<G-vec00003-001-s133><see.betrachten><de> Wir betrachten die Welt als unseren Heimatmarkt und folgen unseren Kunden über den ganzen Globus.
<G-vec00003-001-s133><see.betrachten><en> We see the world as our market and follow our customers around the globe.
<G-vec00003-001-s134><see.betrachten><de> Untersuchen wir, was wir gerade fühlen, können wir versuchen, ihn zu zerlegen, all die dazugehörigen Einzelteile zu betrachten und herauszufinden, welche seiner Teile schwach oder unzulänglich sind.
<G-vec00003-001-s134><see.betrachten><en> In examining what we are feeling, we can try to deconstruct it, see all the pieces that go into it, and discover which parts of that state of mind are weak or deficient.
<G-vec00003-001-s135><see.betrachten><de> Mythen sind auch eine bestimmte Art und Weise, Dinge zu betrachten.
<G-vec00003-001-s135><see.betrachten><en> Myth is also a particular way to see things, to take sides with history.
<G-vec00003-001-s136><see.betrachten><de> Als sich meine eigenen Lebensumstände änderten und ich vieles aus anderer Perspektive betrachten konnte, gewann das Buch immer klarer Kontur.
<G-vec00003-001-s136><see.betrachten><en> The book took even clearer shape after the circumstances of my own life changed and I was able to see many themes from a different perspective.
<G-vec00003-001-s137><see.betrachten><de> Den Innenraum der Kirche können Sie bei Gottesdiensten betrachten.
<G-vec00003-001-s137><see.betrachten><en> You can see the interior of the church during services.
<G-vec00003-001-s138><see.betrachten><de> Man kann über Menschen staunen, die sich als Wissenschaftler betrachten und die nützlichsten Erscheinungen übersehen.
<G-vec00003-001-s138><see.betrachten><en> It is amazing to see people who, thinking of themselves as scientists, overlook the most useful phenomena.
<G-vec00003-001-s139><see.betrachten><de> Bedouin Discovery heißt Sie herzlich Willkommen, die Beduinen hier nicht nur als ein Volk mit einer anderen Kultur zu betrachten, sondern mehr über unsere jahrhundertalten Traditionen und Lebensweisen zu erfahren.
<G-vec00003-001-s139><see.betrachten><en> Bedouin Discovery Tours welcomes you not only to see the Bedouin as people of a different culture, but actually learn about this ancient culture and experience the traditional way of life - at least for some days!
<G-vec00003-001-s140><see.betrachten><de> Wenn Leute in eine Kunstgalerie gehen, betrachten sie oft Bilder an einer Wand.
<G-vec00003-001-s140><see.betrachten><en> When people go to a gallery, they usually see pictures on a wall.
<G-vec00003-001-s141><see.betrachten><de> Training/Verleih (gegen Gebühr).Mountainbiken oder Teilnahme an einem ganztägigen Mountainbike-Ausflug ist eine ausgezeichnete Möglichkeit, die natürliche Schönheit der Gegend zu betrachten und sich fit zu halten.Für weitere Informationen wenden Sie sich bitte an die Rezeption.
<G-vec00003-001-s141><see.betrachten><en> Training / Rental (With charge). Mountain biking or participation in a full-day mountain bike excursion is an excellent way to see the area’s natural beauties, whilst keeping fit. For more information please ask the front desk.
<G-vec00003-001-s142><see.betrachten><de> Versucht alles mit einem klaren Geist zu betrachten, ohne Urteil, und denkt daran, auch sie kämpfen für ihre Existenz.
<G-vec00003-001-s142><see.betrachten><en> Try to see everything with a clear mind, without judgment, and remember, they too, are fighting for their existence.
<G-vec00003-001-s143><see.betrachten><de> Es empfiehlt sich aber vor dem Betrachten der vergrößerten Bilder die Slideshow anzuhalten (II), weil sie sonst im Hintergrund weiterläuft und Sie dann wieder manuell zu Ihrem zuletzt besuchten Bild zurückkehren müssen.
<G-vec00003-001-s143><see.betrachten><en> It is useful to pause (II) the slideshow if You want to see the enlarged version of a picture or watch a video. Otherwise it is marching on in the background and You have to go manually to Your last viewed picture within the slideshow window.
<G-vec00003-001-s144><see.betrachten><de> Nicht wenige betrachten jedoch die Auswüchse des Tourismus als einen wesentlichen Faktor unserer heutigen Probleme.
<G-vec00003-001-s144><see.betrachten><en> Quite a few people, however, see the growth of tourism as one of the fundamental causes of our current problems.
<G-vec00003-001-s145><see.betrachten><de> Sie betrachten ihn als Quelle des Leids und lassen deswegen ihren Zorn an ihm aus.
<G-vec00003-001-s145><see.betrachten><en> They see it as a source of misery, and thus they take out their anger on it.
<G-vec00003-001-s146><see.betrachten><de> Wenn wir die Langeweile jedoch einmal auf den Kopf stellen und sie als den Anfang einer Erfahrung betrachten, nicht als das Ende, dann stellen wir fest, was sich eigentlich hinter ihr verbirgt.
<G-vec00003-001-s146><see.betrachten><en> However, if we turn boredom upside-down and see it coming instead at the beginning of experience, we discover what its weary exterior hides.
<G-vec00003-001-s147><see.betrachten><de> Betrachten können Sie hier Fische, Anemonen oder lieber Tieger und Löwen sowie Affen, auch Elefanten und Nilkrokodile finden Sie im Kölner Zoo.
<G-vec00003-001-s147><see.betrachten><en> Here you can see fish, anemones or rather tiger and lion as well as monkeys, but also elephants and nile crocodiles can be found in the Cologne Zoo.
<G-vec00003-001-s148><see.betrachten><de> Aber es wird dort keine Aggression geben, denn es ist der perfekte Zustand, in dem ihr euch selbst betrachten könnt und weder ihr greift jemanden an noch werdet ihr angegriffen werden, ihr seht euch selbst einfach in aller Klarheit.
<G-vec00003-001-s148><see.betrachten><en> But there won't be any aggression because that's the perfect state where you see yourself and neither you aggress anyone nor you are aggressed by anyone, you just see yourself clearly.
<G-vec00003-001-s149><see.betrachten><de> Betrachten Sie die Farbveränderung live in unseren Parkettwelten.
<G-vec00003-001-s149><see.betrachten><en> Come and see the changes in colour for yourself in our Parquets Worlds.
<G-vec00003-001-s150><see.betrachten><de> Daher kann ich, unter Berücksichtigung der Inhalte der Kunstfunde, sagen, dass ich mit der Zeit dazu kam, bestimmte Abschnitte dieses Falls mit großem Interesse zu betrachten.
<G-vec00003-001-s150><see.betrachten><en> With that in mind I can say, with regard to the contents of the trove, that over time I came to see certain segments of it with great interest.
<G-vec00003-001-s151><see.betrachten><de> Wir waren nur imstande, einen sehr kleinen Bereich innerhalb dieser Höhlenstadt zu betrachten, da wir bald zu einer anderen Tür in der Wand gelangten.
<G-vec00003-001-s151><see.betrachten><en> We were only able to see a very small area within this cavern city as we soon came to another door in the wall.
<G-vec00003-001-s228><look.betrachten><de> Naja, die Zukunft ist unvorhersehbar, egal wie man sie betrachtet … und je kürzer die Zeit ist, desto unberechenbarer wird alles.
<G-vec00003-001-s228><look.betrachten><en> Well the future is unpredictable, regardless of how you look at it… and the shorter the term, the more unpredictable things become.
<G-vec00003-001-s229><look.betrachten><de> Dank der Schwenk- und Zoomfunktion für Referenz- und Probenbild kann die Probe im Detail betrachtet oder eine vollständige Übersicht der Ergebnisse eingeholt werden.
<G-vec00003-001-s229><look.betrachten><en> Also panning and zooming in on the reference and sample images makes it possible to take a closer look at your sample or get the full overview of the results.
<G-vec00003-001-s230><look.betrachten><de> "Fazit Betrachtet man die Nutzungsintensität der verschiedenen Lernformen, wird deutlich, dass diese sehr unterschiedlich ausfällt: externe und interne Lehrveranstaltungen sowie Unterweisung und/oder Einarbeitung spielen eine deutlich größere Rolle als die ""anderen"" moderneren Lernformen."
<G-vec00003-001-s230><look.betrachten><en> Conclusion A look at the intensity of use for the different forms of learning reveals considerable differences: External and internal training courses and instruction and/or induction training play a markedly larger role compared to 'other' modern forms of learning.
<G-vec00003-001-s231><look.betrachten><de> Aus Sicht der Anhänger betrachtet, heißt es Töten.
<G-vec00003-001-s231><look.betrachten><en> The way we practitioners look at it, that’s killing.
<G-vec00003-001-s232><look.betrachten><de> Wenn man diesen Hut so betrachtet, versteht man sofort, dass es sich gelohnt hat, alle Strapazen einer Promotion auf sich zu nehmen.
<G-vec00003-001-s232><look.betrachten><en> If you look at the hat, I think you can understand that it was worth while it to shoulder all the exertions.
<G-vec00003-001-s233><look.betrachten><de> Wenn man die Gesellschaft betrachtet, bestimmt meist die politische Einstellung, was man sieht.
<G-vec00003-001-s233><look.betrachten><en> When we look at society, our political vision mostly determines what we see.
<G-vec00003-001-s234><look.betrachten><de> Zentralbanken bedrucken Banknoten mit komplexen magnetischen Mustern aus ferromagnetischer — und in vielen Farben verfügbarer — Tinte, wobei mit bloßem Auge betrachtet kein Unterschied zu erkennen ist.
<G-vec00003-001-s234><look.betrachten><en> Central banks use ferromagnetic ink—which comes in many colours—to print banknotes with complex magnetic patterns that don’t look any different to the naked eye.
<G-vec00003-001-s235><look.betrachten><de> Ob einzeln oder als enges Freundespaar betrachtet, es besteht kein Zweifel, dass Rocko und Misty zwei der beliebtesten Charaktere der Welt von Pokémon sind.
<G-vec00003-001-s235><look.betrachten><en> Whether you look at them separately or take them as a pair of devoted friends, there's no doubt that Brock and Misty are two of the most popular characters in the world of Pokémon.
<G-vec00003-001-s236><look.betrachten><de> Wenn man nur die Nominallöhne betrachtet, dann bestehen innerhalb Europas erhebliche Unterschiede.
<G-vec00003-001-s236><look.betrachten><en> If you only look at the nominees, there are considerable differences within Europe.
<G-vec00003-001-s237><look.betrachten><de> Dabei gibt es viele grundsätzliche Informationen zu Gegenständen und Materialien im Kontakt mit Lebensmitteln, die es wert sind, einmal genauer betrachtet zu werden, unabhängig von Einzelstoffen, möglichen Risiken, Konsequenzen und aktuellen Nachrichten.
<G-vec00003-001-s237><look.betrachten><en> There is, however, a lot of basic information on objects and materials that come into contact with foods which it is worth taking a closer look at irrespective of individual substances, possible risks, consequences and the latest news.
<G-vec00003-001-s238><look.betrachten><de> Wenn man das große universitäre Netzwerk näher betrachtet, das die frankophonen Länder vereint, das Mediennetzwerk, den Sport, die Handwerker und Künstler, die Frauen und die Jugend, dann merkt man, dass man zu einer großen und vielfältigen Familie gehört, die darauf verzichtet, die Sprache von Molière verbindlich den anderen aufzuerlegen, sei es in der afrikanischen Savanne oder in Armenien.
<G-vec00003-001-s238><look.betrachten><en> If we look closely at the huge university network of francophone countries, the networks of media, sports, artisans and artists, women and young people, we realize that we are one big, complex family, but which is careful not to impose as mandatory the language of Molière in the African savannah or in Armenia.
<G-vec00003-001-s239><look.betrachten><de> """Die Arbeit betrachtet den finanziellen Ausgleich durch die regionale Verteilung von Einnahmen und Ausgaben der Arbeitslosenversicherung."
<G-vec00003-001-s239><look.betrachten><en> """This paper takes a look at financial compensation by means of the regional distribution of income and expenses of unemployment benefit."
<G-vec00003-001-s240><look.betrachten><de> Es ist so einfach für Frauen zu verwenden es als Dame Steroid betrachtet wird.
<G-vec00003-001-s240><look.betrachten><en> It is so user friendly for ladies it is taken a look at as the lady steroid.
<G-vec00003-001-s241><look.betrachten><de> Für die moderne junge Mädchen, sie wollen nicht einen Hauch von traditionellen Hausfrauen Bild betrachtet, ist das einzige Streben für sie Sexualität.
<G-vec00003-001-s241><look.betrachten><en> For modern young girls, they do not want to look an air of traditional housewives image, the only pursuit for them is sexuality.
<G-vec00003-001-s242><look.betrachten><de> Wer nämlich den anderen durch die Brille der Freundschaft betrachtet und nicht durch die Brillengläser des Konkurrenzkampfs oder des Konflikts, wird zum Erbauer einer lebbareren und menschlicheren Welt.
<G-vec00003-001-s242><look.betrachten><en> Indeed, those who look at others through the lens of friendship, and not with that of competition or conflict, become the builders of a more liveable and human world.
<G-vec00003-001-s243><look.betrachten><de> Mit Hilfe dieses Tools kann der Klassifikator in einem Zehntel der zuvor benötigten Zeit gebaut werden, da die Anzahl der Bilder, die betrachtet werden müssen, um einen Faktor von 100 oder mehr reduziert wurde.
<G-vec00003-001-s243><look.betrachten><en> This tool enables to intuitively build a classifier in a tenth of the previously required time as the number of images to look at is reduced by a factor of 100 or more.
<G-vec00003-001-s244><look.betrachten><de> Die Isla del Pescado liegt inmitten des großen Salzes und wird die Fischinsel genannt, weil sie wohl wie ein Fisch geformt ist, wenn man sie aus der Luft betrachtet.
<G-vec00003-001-s244><look.betrachten><en> "The ""Isla de Pescado"" is situated in the middle of the salt ocean and is called the ""fish island"" because when you look at it from the air it apparently has the shape of a fish."
<G-vec00003-001-s245><look.betrachten><de> Was sich an euch vollziehet, ist ein Erlösungsprozeß von sicherster Wirkung, und sowie ihr nun euer ganzes Leben so betrachtet, muss jede Angst von euch weichen, bin Ich es doch, Der euch zu Seinen Kinder gestalten will und euch darum das Leben gab.
<G-vec00003-001-s245><look.betrachten><en> What takes place at you, is a process of redemption of surest effect and as soon as you now look at your whole life like this, all fear must retreat from you, since it is I, who wants to fashion you to his children and for that reason gave you life.
<G-vec00003-001-s246><look.betrachten><de> Doch ihr Menschen erkennet nicht den Zweck und das Ziel des Erdenlebens.... ihr wertet es nach einer anderen Richtung aus, ihr suchet nur die Vorteile für den Körper herauszuholen und gedenket eurer Seele nicht.... ihr betrachtet die Erde als Selbstzweck, während sie doch nur das Mittel ist zum Zweck.... das Mittel, dem Geistigen die letzte Reife zu bringen.
<G-vec00003-001-s246><look.betrachten><en> But you humans don't recognise the purpose and goal of earthly life.... you misinterpret it, you only strive to benefit your body without thinking of your soul.... you look at the earth as an end in itself, whereas it is only the means to an end.... the means for the spirit to attain final maturity.
