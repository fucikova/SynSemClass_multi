<G-vec00169-001-s066><fetch.besorgen><de> Sie graben die Löcher für die Posten, besorgen Steine, setzen eine Lebhecke und flechten den Maschendrahtzaun selbst.
<G-vec00169-001-s066><fetch.besorgen><en> They dig the holes for the posts, fetch stones, put in hedges and weave the wire mesh themselves.
<G-vec00169-001-s067><fetch.besorgen><de> Nach dem Treffen müssen Sie sich den GnuPG-Schlüssel besorgen, um ihn signieren zu können.
<G-vec00169-001-s067><fetch.besorgen><en> After the meeting you'll have to fetch the GnuPG key in order to sign it.
<G-vec00169-001-s079><fetch.besorgen><de> Mit dem Fahrrad können Sie sich jeden Tag zum Deckfrühstück frische Brötchen und Ihre Zeitung besorgen.
<G-vec00169-001-s079><fetch.besorgen><en> And you can cycle off to fetch fresh rolls and your newspaper every day in time for your breakfast on deck.
<G-vec00169-001-s080><fetch.besorgen><de> Dann schmeckt Ihr Coq au Vin am Abend noch besser… Mit dem Fahrrad können Sie sich jeden Tag zum Deckfrühstück frische Brötchen und Ihre Zeitung besorgen.
<G-vec00169-001-s080><fetch.besorgen><en> Which will make your Coq au Vin in the evening taste even better… And you can cycle off to fetch fresh rolls and your newspaper every day in time for your breakfast on deck.
