<G-vec00019-001-s020><buck.abwerfen><de> Es wird dich wahrscheinlich abwerfen.
<G-vec00019-001-s020><buck.abwerfen><en> It will probably buck you off.
