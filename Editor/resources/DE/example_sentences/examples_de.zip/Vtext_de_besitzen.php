<G-vec00206-001-s098><comprise.besitzen><de> Alle Apartments sind klimatisiert und besitzen einen TV und eine voll ausgestattete Küche oder Küchenzeile mit einem Sitzbereich.
<G-vec00206-001-s098><comprise.besitzen><en> All apartments are air-cooled and comprise a TV and a well-equipped kitchen or a kitchenette with a seating area.
<G-vec00206-001-s099><comprise.besitzen><de> Da Kristalle und Quasikristalle völlig unterschiedliche Materialklassen darstellen und deutlich voneinander abweichende physikalische und chemische Eigenschaften besitzen, ist die beobachtete Mischstruktur zunächst erstaunlich.
<G-vec00206-001-s099><comprise.besitzen><en> Because crystals and quasicrystals comprise different material classes with differing physical and chemical properties, the observed intermediate structure is striking.
<G-vec00206-001-s100><comprise.besitzen><de> Sie besitzen eine kegelige metallische Abdichtung.
<G-vec00206-001-s100><comprise.besitzen><en> They comprise a cone metal sealing.
<G-vec00206-001-s101><comprise.besitzen><de> Die Black Diamond Standard Flex Center Bars besitzen einen flexiblen Mittelsteg mit Stahlfederclip, der mit allen Steigeisen kompatibel ist.
<G-vec00206-001-s101><comprise.besitzen><en> Black Diamond's Standard Flex Center Bars comprise a flexible spring-steel center bar that is compatible with all crampons.
<G-vec00185-001-s038><have.besitzen><de> Obwohl sie ein Übermaß an Energie besitzen, finden sie nicht die richtigen Plätze, diese zu nutzen und ihre Energie beginnt zu stagnieren.
<G-vec00185-001-s038><have.besitzen><en> Although they have an abundance of energy, they can't find the right places to use it and their energy is beginning to stagnate.
<G-vec00185-001-s039><have.besitzen><de> Deren fleischfarbige Stengel und Blätter besitzen die Anmutung eines menschlichen Wesens, welches sich in einer anorganischen Umgebung behaupten muss.
<G-vec00185-001-s039><have.besitzen><en> Their flesh-colored stems and leaves have the appearance of a human being, which has to assert itself in an inorganic environment.
<G-vec00185-001-s040><have.besitzen><de> Sie arbeiten fachübergreifend auch für unsere Dienstleistungsprojekte und besitzen dadurch die Kenntnisse und Erfahrung, die für die praxistaugliche Gestaltung unserer Produkte erforderlich sind.
<G-vec00185-001-s040><have.besitzen><en> They also cross departmental lines and therefore have the skills and the experience which are needed for the practical field design of our products.
<G-vec00185-001-s041><have.besitzen><de> Die Bibel behauptet nicht nur von Gott eingegeben zu sein, aber auch die Fähigkeit zu besitzen uns zu ändern und “vollständig” zu machen, ausgestattet für jede gute Arbeit.
<G-vec00185-001-s041><have.besitzen><en> The Bible claims not only to be inspired by God, but to also have the ability to change us and make us “complete,” thoroughly equipped for every good work.
<G-vec00185-001-s042><have.besitzen><de> Einfache oder doppelte Dosierlöffel besitzen eine oder zwei Dosierlaffe(n).
<G-vec00185-001-s042><have.besitzen><en> Single or double measuring spoons have one or two bowls. Zurück
<G-vec00185-001-s043><have.besitzen><de> Ich erinnere euch an das Gesetz – jenes, das nicht aus eurem Gewissen gelöscht werden kann, noch von eurem Herzen vergessen, noch in Frage gestellt werden darf, weil es von der weisen Intelligenz, der Universellen Intelligenz diktiert wurde, damit jeder Mensch innerlich das Licht besitzen würde, das ihn auf den Weg zu Gott führt.
<G-vec00185-001-s043><have.besitzen><en> I come to remind you of the Law that cannot be wiped from your conscience, not forgotten by your heart nor argued with, for it was dictated by the Mind of Wisdom, the Universal Mind, so that each man would have inside himself the light that would guide him on the road to God.
<G-vec00185-001-s044><have.besitzen><de> Alle Förderpumpen, die nach dem Verdrängungsprinzip arbeiten, besitzen eine endliche Zahl an Kolben, Zahnradflanken oder anderen Förderbauteilen.
<G-vec00185-001-s044><have.besitzen><en> All feed pumps which work on the displacement principle have a finite number of pistons, gear wheel flanks or other feed components.
<G-vec00185-001-s045><have.besitzen><de> Absolvent/innen des Programms besitzen theoretische Fachkenntnisse in Data Science und kennen Techniken und Methoden fÃ1⁄4r die praktische Anwendung.Â Der DAS in Data Science umfasst insgesamt 35 bis 45 ECTS verteilt auf eine Grundlagenveranstaltung, eine Vertiefungsrichtung,Â Wahlveranstaltungen aus einer vorgegebenen Liste sowie einem Abschlussprojekt.
<G-vec00185-001-s045><have.besitzen><en> Graduates of the programme will have a solid basis in the theoretical foundations of data science as well as in the techniques and methodologies required in practical applications. The DAS in Data Science consists in total of 35 to 45 ECTS split over a foundations course, a specialization track, a capstone project, and further courses to choose from a list .
<G-vec00185-001-s046><have.besitzen><de> Wir sollten diesbezüglich etwas Weisheit besitzen.
<G-vec00185-001-s046><have.besitzen><en> We have to be wise about it.
<G-vec00185-001-s047><have.besitzen><de> Mit dem 1990 Steroid Control Act war es somit als illegal zu besitzen oder anabole Steroide zu verkaufen, ohne ein Rezept von einem Arzt für medizinische Zwecke gegeben.
<G-vec00185-001-s047><have.besitzen><en> With the 1990 steroid control act it was thereby considered prohibited to have or offer anabolic steroids over the counter provided by a medical professional for medical purposes.
<G-vec00185-001-s048><have.besitzen><de> Bar jeder weltlichen Macht, verfolgt und täglich mit dem Tod bedroht, bringt sie Heilige hervor, die die Gnade Gottes in irdenen Gefäßen besitzen, im Licht der Verklärung leben, und von Gott zum Martyrium und zum Opfer geführt werden, und nicht zur gewaltsamen Schaffung eines selbsternannten Gottesstaates in der Welt.
<G-vec00185-001-s048><have.besitzen><en> Free of any worldly power, persecuted and daily put to death, it gives rise to saints, who have the grace of God in vessels of clay, who live in the light of the transfiguration and are led by God to martyrdom and sacrifice, not to the violent setting up in the world of an alleged State of God.
<G-vec00185-001-s049><have.besitzen><de> Alle besitzen Sat-TV sowie ein Marmorbad mit einer Badewanne, einer Dusche und Pflegeprodukten.
<G-vec00185-001-s049><have.besitzen><en> All rooms have satellite TV and a marble bathroom with bath, shower and toiletries.
<G-vec00185-001-s050><have.besitzen><de> Das sind die wichtigsten Eigenschaften, die alle Herren Running Shirts von DYNAFIT besitzen.
<G-vec00185-001-s050><have.besitzen><en> Those are the essential features that all men's running shirts by DYNAFIT have.
<G-vec00185-001-s051><have.besitzen><de> Li-Ionen Akkus moderner Pedelecs besitzen eine hohe Energiedichte und weisen daher ein gewisses Risikopotenzial der Selbstentzündung auf.
<G-vec00185-001-s051><have.besitzen><en> Li-ion batteries of state-of-the-art pedelecs have a high energy density and therefore bear a certain risk potential of spontaneous ignition.
<G-vec00185-001-s052><have.besitzen><de> Die Bibel lädt immer dazu ein, großen Respekt vor den Älteren zu haben, weil sie einen Schatz an Erfahrung besitzen und Erfolge wie Niederlagen, Freuden und große Schmerzen des Lebens, Hoffnungen und Enttäuschungen erlebt haben.
<G-vec00185-001-s052><have.besitzen><en> The Bible never ceases to insist that profound respect be shown to the elderly, since they have a wealth of experience; they have known success and failure, life’s joys and afflictions, its dreams and disappointments.
<G-vec00185-001-s053><have.besitzen><de> Wir und andere Säugetiere besitzen eine Gruppe von Enzymen, deren Aufgabe es ist, alles Ammoniak schnell in Harnstoff zu verwandeln, der nicht giftig ist.
<G-vec00185-001-s053><have.besitzen><en> We and other mammals have a set of enzymes with the special job of changing all ammonia quickly to urea, which is not toxic.
<G-vec00185-001-s054><have.besitzen><de> Aluminium-Polymer- und Aluminium-Elektrolytkondensatoren besitzen ein sehr gutes Verhalten gegenüber der Einwirkung von Spannung und Temperatur, wobei Aluminium-Polymer-Kondensatoren des Weiteren auch eine sehr positive Eigenschaft in Bezug auf das Thema Alterung besitzen.
<G-vec00185-001-s054><have.besitzen><en> Aluminum polymer and aluminum electrolytic capacitors have very good behavior against the effects of voltage and temperature, while aluminum polymer capacitors also have a very positive characteristic with respect to the subject of aging.
<G-vec00185-001-s055><have.besitzen><de> Aluminium-Polymer- und Aluminium-Elektrolytkondensatoren besitzen ein sehr gutes Verhalten gegenüber der Einwirkung von Spannung und Temperatur, wobei Aluminium-Polymer-Kondensatoren des Weiteren auch eine sehr positive Eigenschaft in Bezug auf das Thema Alterung besitzen.
<G-vec00185-001-s055><have.besitzen><en> Aluminum polymer and aluminum electrolytic capacitors have very good behavior against the effects of voltage and temperature, while aluminum polymer capacitors also have a very positive characteristic with respect to the subject of aging.
<G-vec00185-001-s056><have.besitzen><de> "2:118 Und diejenigen, die kein Wissen besitzen, sagen: \""Warum spricht Allah nicht zu uns und sendet uns kein Zeichen?\"" So, wie sie reden, redeten auch diejenigen vor ihnen."
<G-vec00185-001-s056><have.besitzen><en> 2:118 And those who have no knowledge say: Why does not Allah speak to us or a sign come to us? Even thus said those before them, the like of what they say.
<G-vec00057-001-s133><hold.besitzen><de> Recht auf Berichtigung – Sie sind berechtigt, Daten, die wir von Ihnen besitzen und die unrichtig oder unvollständig sind, zu berichtigen.
<G-vec00057-001-s133><hold.besitzen><en> Right of rectification – you have a right to correct data that we hold about you that is inaccurate or incomplete.
<G-vec00057-001-s134><hold.besitzen><de> Sie haben jedoch eine religiöse und kontrollierende Aufgabe, während die illuminati als Exekutivorgan die wahre Macht besitzen.
<G-vec00057-001-s134><hold.besitzen><en> They have a religious and controlling task, however, while the illuminati, as executive body, hold the real power.
<G-vec00057-001-s135><hold.besitzen><de> In einigen Fällen sind wir möglicherweise nicht in der Lage, Ihnen Zugriff auf persönliche Informationen zu gewähren, die wir in Bezug auf Sie besitzen, wenn eine solche Offenlegung gegen unsere gesetzlichen Verpflichtungen gegenüber unserem Klienten verstößt oder wenn dies durch geltende Gesetze oder Vorschriften verhindert wird.
<G-vec00057-001-s135><hold.besitzen><en> In some cases, we may not be able to give you access to personal information we hold regarding you if making such a disclosure would breach our legal obligations to our client or if prevented by any applicable law or regulation.
<G-vec00057-001-s136><hold.besitzen><de> Sie können auch auf die Auszeichnungen und Qualitätszertifizierungen von eCOGRA vertrauen, die alle Jackpot Factory Casinos besitzen.
<G-vec00057-001-s136><hold.besitzen><en> You can rest easy knowing that all Jackpot Factory casinos hold the eCOGRA Players Seal of Approval.
<G-vec00057-001-s137><hold.besitzen><de> Nach Abschluss der Transaktion wird CGN Mining ungefähr 19,9 % der ausgegebenen und umlaufenden Aktien des Unternehmens besitzen.
<G-vec00057-001-s137><hold.besitzen><en> Upon completion of the Transaction, CGN Mining will hold approximately 19.9% of the Company's issued and outstanding share capital.
<G-vec00057-001-s138><hold.besitzen><de> Sie besitzen ein Girokonto in Deutschland.
<G-vec00057-001-s138><hold.besitzen><en> You hold a current account in Germany.
<G-vec00057-001-s139><hold.besitzen><de> Also besitzen Sie in Ihren Händen alle möglichen und vorstellbaren Wege der Kenntnis von China und darüber hinaus...
<G-vec00057-001-s139><hold.besitzen><en> So, you hold in your hands all the possible and imaginable means for getting to know China and beyond.
<G-vec00057-001-s140><hold.besitzen><de> Sowohl Raheb als auch Ateek besitzen Doktortitel von Auslandsuniversitäten, die unter dieser Art Einfluss des alten Europa geschrieben wurden.
<G-vec00057-001-s140><hold.besitzen><en> Both Raheb and Ateek hold doctorates from foreign universities, written under that kind of old-time European influence.
<G-vec00057-001-s141><hold.besitzen><de> Wenn Sie keine Zertifizierung besitzen, stellen wir Ihnen ein paar Fragen, um Ihre Fähigkeiten zu bewerten.
<G-vec00057-001-s141><hold.besitzen><en> If you do not hold a certification, we will ask you a few questions to evaluate your skills.
<G-vec00057-001-s142><hold.besitzen><de> - Alle Teilnahmeeinrichtungen (sowohl die koordinierende als auch die Partner) müssen eine Erasmus-Universitätscharta besitzen.
<G-vec00057-001-s142><hold.besitzen><en> - All participating institutions (both coordinator and partners) must hold an Erasmus University Charter.
<G-vec00057-001-s143><hold.besitzen><de> Wir besitzen das Qualitätszertifikat nach der ISO 9001:2008.
<G-vec00057-001-s143><hold.besitzen><en> We hold the ISO 9001:2008 Quality Certificate.
<G-vec00057-001-s144><hold.besitzen><de> "Das Schiedskomitee (diejenigen, die Macht und Herrschaft über Wiki besitzen) ""gibt zu, Cberlet blind zu verehren"", wie mir ein prominenter Insider berichtete."
<G-vec00057-001-s144><hold.besitzen><en> "The Arbitration committee (those who hold the reigns of power on the Wiki) ""admit to hero-worship of Cberlet', I was informed by a prominent insider."
<G-vec00057-001-s145><hold.besitzen><de> Und als die Religion zu einer Institution wurde, erhoben die Priester den Anspruch, „die Schlüssel zum Himmel zu besitzen“.
<G-vec00057-001-s145><hold.besitzen><en> And when religion became institutionalized, these priests claimed to “hold the keys of heaven.”
<G-vec00057-001-s146><hold.besitzen><de> Als Technologieführer investieren wir kontinuierlich in Forschung und Entwicklung und besitzen mehr als 1.000 Patente.
<G-vec00057-001-s146><hold.besitzen><en> As a leader in materials technology, we continuously invest in research and development and hold over 1,000 patents.
<G-vec00057-001-s147><hold.besitzen><de> Die DSGVO betrifft den Schutz, die Erhebung und Verwaltung persönlicher (d. h. personenbezogener) Daten und gilt für alle Unternehmen und Organisationen (einschließlich Einzelunternehmern) in der EU, die persönliche Daten von Menschen in den EU-Mitgliedstaaten besitzen oder anderweitig verarbeiten.
<G-vec00057-001-s147><hold.besitzen><en> The GDPR’s focus is the protection, collection and management of personal data, (i.e. data about individuals) and it applies to all companies and organisations in the EU who hold or otherwise process personal data (including sole traders) of people in EU Member States, and even companies outside the EU that offer goods or services to the individuals in the EU or who monitor their behavior there. Sign up for GDPR online training
<G-vec00057-001-s148><hold.besitzen><de> x Wenn Sie Aktien in Ihrem Namen besitzen, ist es mehr als wahrscheinlich dass Sie Einkommen verdienen.
<G-vec00057-001-s148><hold.besitzen><en> xIf you hold company shares in your name, it is more than likely that they earned income.
<G-vec00057-001-s149><hold.besitzen><de> • Antrag auf Korrektur der personenbezogenen Daten, die wir von Ihnen besitzen.
<G-vec00057-001-s149><hold.besitzen><en> • Request correction of the personal data that we hold about you.
<G-vec00057-001-s150><hold.besitzen><de> Es beinhaltet, dass Sie dazu berechtigt sind, bestimmte persönliche Daten zu erhalten, die wir als Organisation von Ihnen besitzen.
<G-vec00057-001-s150><hold.besitzen><en> It means that you have the right to receive certain personal data that we hold as an organisation.
<G-vec00057-001-s151><hold.besitzen><de> "In einigen wenigen Fällen haben Sie das Recht persönliche Daten zu haben, die wir über Sie besitzen gelöscht (das Recht vergessen""zu werden)."
<G-vec00057-001-s151><hold.besitzen><en> "In some limited circumstances, you have the right to have personal data that we hold about you erased (the right to be forgotten"")."
<G-vec00185-001-s133><hold.besitzen><de> Recht auf Berichtigung – Sie sind berechtigt, Daten, die wir von Ihnen besitzen und die unrichtig oder unvollständig sind, zu berichtigen.
<G-vec00185-001-s133><hold.besitzen><en> Right of rectification – you have a right to correct data that we hold about you that is inaccurate or incomplete.
<G-vec00185-001-s134><hold.besitzen><de> Sie haben jedoch eine religiöse und kontrollierende Aufgabe, während die illuminati als Exekutivorgan die wahre Macht besitzen.
<G-vec00185-001-s134><hold.besitzen><en> They have a religious and controlling task, however, while the illuminati, as executive body, hold the real power.
<G-vec00185-001-s135><hold.besitzen><de> In einigen Fällen sind wir möglicherweise nicht in der Lage, Ihnen Zugriff auf persönliche Informationen zu gewähren, die wir in Bezug auf Sie besitzen, wenn eine solche Offenlegung gegen unsere gesetzlichen Verpflichtungen gegenüber unserem Klienten verstößt oder wenn dies durch geltende Gesetze oder Vorschriften verhindert wird.
<G-vec00185-001-s135><hold.besitzen><en> In some cases, we may not be able to give you access to personal information we hold regarding you if making such a disclosure would breach our legal obligations to our client or if prevented by any applicable law or regulation.
<G-vec00185-001-s136><hold.besitzen><de> Sie können auch auf die Auszeichnungen und Qualitätszertifizierungen von eCOGRA vertrauen, die alle Jackpot Factory Casinos besitzen.
<G-vec00185-001-s136><hold.besitzen><en> You can rest easy knowing that all Jackpot Factory casinos hold the eCOGRA Players Seal of Approval.
<G-vec00185-001-s137><hold.besitzen><de> Nach Abschluss der Transaktion wird CGN Mining ungefähr 19,9 % der ausgegebenen und umlaufenden Aktien des Unternehmens besitzen.
<G-vec00185-001-s137><hold.besitzen><en> Upon completion of the Transaction, CGN Mining will hold approximately 19.9% of the Company's issued and outstanding share capital.
<G-vec00185-001-s138><hold.besitzen><de> Sie besitzen ein Girokonto in Deutschland.
<G-vec00185-001-s138><hold.besitzen><en> You hold a current account in Germany.
<G-vec00185-001-s139><hold.besitzen><de> Also besitzen Sie in Ihren Händen alle möglichen und vorstellbaren Wege der Kenntnis von China und darüber hinaus...
<G-vec00185-001-s139><hold.besitzen><en> So, you hold in your hands all the possible and imaginable means for getting to know China and beyond.
<G-vec00185-001-s140><hold.besitzen><de> Sowohl Raheb als auch Ateek besitzen Doktortitel von Auslandsuniversitäten, die unter dieser Art Einfluss des alten Europa geschrieben wurden.
<G-vec00185-001-s140><hold.besitzen><en> Both Raheb and Ateek hold doctorates from foreign universities, written under that kind of old-time European influence.
<G-vec00185-001-s141><hold.besitzen><de> Wenn Sie keine Zertifizierung besitzen, stellen wir Ihnen ein paar Fragen, um Ihre Fähigkeiten zu bewerten.
<G-vec00185-001-s141><hold.besitzen><en> If you do not hold a certification, we will ask you a few questions to evaluate your skills.
<G-vec00185-001-s142><hold.besitzen><de> - Alle Teilnahmeeinrichtungen (sowohl die koordinierende als auch die Partner) müssen eine Erasmus-Universitätscharta besitzen.
<G-vec00185-001-s142><hold.besitzen><en> - All participating institutions (both coordinator and partners) must hold an Erasmus University Charter.
<G-vec00185-001-s143><hold.besitzen><de> Wir besitzen das Qualitätszertifikat nach der ISO 9001:2008.
<G-vec00185-001-s143><hold.besitzen><en> We hold the ISO 9001:2008 Quality Certificate.
<G-vec00185-001-s144><hold.besitzen><de> "Das Schiedskomitee (diejenigen, die Macht und Herrschaft über Wiki besitzen) ""gibt zu, Cberlet blind zu verehren"", wie mir ein prominenter Insider berichtete."
<G-vec00185-001-s144><hold.besitzen><en> "The Arbitration committee (those who hold the reigns of power on the Wiki) ""admit to hero-worship of Cberlet', I was informed by a prominent insider."
<G-vec00185-001-s145><hold.besitzen><de> Und als die Religion zu einer Institution wurde, erhoben die Priester den Anspruch, „die Schlüssel zum Himmel zu besitzen“.
<G-vec00185-001-s145><hold.besitzen><en> And when religion became institutionalized, these priests claimed to “hold the keys of heaven.”
<G-vec00185-001-s146><hold.besitzen><de> Als Technologieführer investieren wir kontinuierlich in Forschung und Entwicklung und besitzen mehr als 1.000 Patente.
<G-vec00185-001-s146><hold.besitzen><en> As a leader in materials technology, we continuously invest in research and development and hold over 1,000 patents.
<G-vec00185-001-s147><hold.besitzen><de> Die DSGVO betrifft den Schutz, die Erhebung und Verwaltung persönlicher (d. h. personenbezogener) Daten und gilt für alle Unternehmen und Organisationen (einschließlich Einzelunternehmern) in der EU, die persönliche Daten von Menschen in den EU-Mitgliedstaaten besitzen oder anderweitig verarbeiten.
<G-vec00185-001-s147><hold.besitzen><en> The GDPR’s focus is the protection, collection and management of personal data, (i.e. data about individuals) and it applies to all companies and organisations in the EU who hold or otherwise process personal data (including sole traders) of people in EU Member States, and even companies outside the EU that offer goods or services to the individuals in the EU or who monitor their behavior there. Sign up for GDPR online training
<G-vec00185-001-s148><hold.besitzen><de> x Wenn Sie Aktien in Ihrem Namen besitzen, ist es mehr als wahrscheinlich dass Sie Einkommen verdienen.
<G-vec00185-001-s148><hold.besitzen><en> xIf you hold company shares in your name, it is more than likely that they earned income.
<G-vec00185-001-s149><hold.besitzen><de> • Antrag auf Korrektur der personenbezogenen Daten, die wir von Ihnen besitzen.
<G-vec00185-001-s149><hold.besitzen><en> • Request correction of the personal data that we hold about you.
<G-vec00185-001-s150><hold.besitzen><de> Es beinhaltet, dass Sie dazu berechtigt sind, bestimmte persönliche Daten zu erhalten, die wir als Organisation von Ihnen besitzen.
<G-vec00185-001-s150><hold.besitzen><en> It means that you have the right to receive certain personal data that we hold as an organisation.
<G-vec00185-001-s151><hold.besitzen><de> "In einigen wenigen Fällen haben Sie das Recht persönliche Daten zu haben, die wir über Sie besitzen gelöscht (das Recht vergessen""zu werden)."
<G-vec00185-001-s151><hold.besitzen><en> "In some limited circumstances, you have the right to have personal data that we hold about you erased (the right to be forgotten"")."
