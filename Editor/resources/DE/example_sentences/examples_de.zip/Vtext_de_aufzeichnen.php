<G-vec00169-001-s070><capture.aufzeichnen><de> Unabhängige analytische Studien haben ein schockierendes Ergebnis geliefert - einige IPhone-Anwendungen können alles aufzeichnen, was auf dem Telefonbildschirm passiert.
<G-vec00169-001-s070><capture.aufzeichnen><en> Independent analytical studies produced a shocking result - some IPhone applications are able to capture everything that happens on the phone screen.
<G-vec00169-001-s071><capture.aufzeichnen><de> Wir haben zuhause die Kinect und ähnliche Technologien, die unsere Bewegungen aufzeichnen und uns so Videospiele kontrollieren lassen.
<G-vec00169-001-s071><capture.aufzeichnen><en> We also have the Kinect and its comrades that capture motion and allow us to control games.
<G-vec00169-001-s072><capture.aufzeichnen><de> Wenn Sie auf die Schaltfläche Aufzeichnen klicken, gelangen Sie zum Aufzeichnen-Fenster.
<G-vec00169-001-s072><capture.aufzeichnen><en> When you click the Capture button you enter the capture window.
<G-vec00169-001-s073><capture.aufzeichnen><de> Kaufen Herunterladen Herunterladen Herunterladen Debut Mit diesem Video-Aufnahme-Programm kann man Videodateien mittels Webcam (Videokamera) oder Aufnahmegerät (von Video) direkt auf dem Computer aufzeichnen.
<G-vec00169-001-s073><capture.aufzeichnen><en> This video recorder lets you capture video files directly on your PC or Mac using a webcam (video camera), or capture device (from video).
<G-vec00169-001-s074><capture.aufzeichnen><de> Erfahren Sie, welche 4K HDR-Spielclips Sie auf Ihrer Xbox One X aufzeichnen können.
<G-vec00169-001-s074><capture.aufzeichnen><en> Find out which 4K HDR game clips you can capture on your Xbox One X.
<G-vec00169-001-s075><capture.aufzeichnen><de> Und du erhältst eine Anfrage, bevor eine App Tastatur aktivitäten aufzeichnen oder ein Foto oder Video von deinem Bildschirm machen kann.
<G-vec00169-001-s075><capture.aufzeichnen><en> And you’ll be prompted before any app can capture keyboard activity or a photo or video of your screen.
<G-vec00169-001-s076><capture.aufzeichnen><de> Zur Auswahl stehen Modelle mit 100 MHz oder 200 MHz Bandbreite, schnellen Abtastraten bis 2,5 GS/s und einer Auflösung von 400 ps zum Aufzeichnen von Rausch- und anderen Störsignalen.
<G-vec00169-001-s076><capture.aufzeichnen><en> Choose from 100 MHz or 200 MHz bandwidth models, with fast sampling rates up to 2.5 GS/s and 400 ps resolution to capture noise and other disturbances.
<G-vec00169-001-s077><capture.aufzeichnen><de> Mit der automatischen Stapelaufzeichnung können Sie schnell Szenen von einer Videokassette aufzeichnen.
<G-vec00169-001-s077><capture.aufzeichnen><en> Automatic batch capture is a quick way to capture scenes from a video tape.
<G-vec00169-001-s078><capture.aufzeichnen><de> Zum Aufzeichnen des Traces klicken Sie in der Menüleiste auf Übertragen / Text aufzeichnen.
<G-vec00169-001-s078><capture.aufzeichnen><en> You record the traces by clicking on Transmit / Capture text.
<G-vec00169-001-s079><capture.aufzeichnen><de> Nach unserer Erfahrung ist im Grunde die Sammlung von Informationen durch die Einrichtung von CCTV Foto durchgefÃ1⁄4hrt, die eine Miniaturkamera, die auch Ton aufnehmen kann, kann verwendet werden, und nur Video aufzeichnen können.
<G-vec00169-001-s079><capture.aufzeichnen><en> In our experience, basically the collection of information is carried out by establishing covert surveillance photo, which can be used a miniature camera that can also record sound, and can only capture video.
<G-vec00169-001-s080><capture.aufzeichnen><de> Um den Trace wieder zu stoppen, klicken Sie im HyperTerminal in der oberen Menüleiste auf Übertragen / Text aufzeichnen beenden.
<G-vec00169-001-s080><capture.aufzeichnen><en> To stop the trace, click on the HyperTerminal menus Transmit / Stop text capture.
<G-vec00169-001-s081><capture.aufzeichnen><de> Mit CyberLink PowerDVD können Sie den gewünschten Aufnahmetyp und die Aufnahmegröße schnell und praktisch auswählen, bevor Sie ein Einzelbild aufzeichnen.
<G-vec00169-001-s081><capture.aufzeichnen><en> CyberLink PowerDVD lets you select your desired capture type and size quickly and conveniently before you are ready to capture a frame.
<G-vec00169-001-s082><capture.aufzeichnen><de> Im Kunstgewerbe, beim Vordruck, in Werbeunternehmen und in anderen Kunstmanufakturen werden Scanner benötigt, die Bilder mit hoher Auflösung aufzeichnen und eine perfekte Bildqualität liefern.
<G-vec00169-001-s082><capture.aufzeichnen><en> For the art, pre-press, billboard shops and other art manufactories, they need scanners presents high resolution to deliver perfect image quality to capture images.
<G-vec00169-001-s083><capture.aufzeichnen><de> Um genauere Ergebnisse zu erzielen, können Sie die Wiedergabe anhalten, die Szene im Zeitlupenmodus abspielen oder schrittweise Einzelbild für Einzelbild ansehen und anschließend das gewünschte Einzelbild aufzeichnen.
<G-vec00169-001-s083><capture.aufzeichnen><en> To be more precise, you may pause the scene, play it in slow motion, or step frame, and then capture the exact desired frame of video.
<G-vec00169-001-s084><capture.aufzeichnen><de> Alle Kameraparameter via Fernbedienung einstellen und Bilder oder Movieclips durch einfachen Knopfdruck aufzeichnen/betrachten.
<G-vec00169-001-s084><capture.aufzeichnen><en> Set all camera parameters via wireless remote control and capture / review images or movie clips by simply pushing of a button.
<G-vec00169-001-s085><capture.aufzeichnen><de> Sie können Videos von jeder Quelle direkt in jedes Format aufzeichnen, das Ihrem vorinstallierten Codec unterstützt (wie die beliebten WebM, XviD, 3IVX...).
<G-vec00169-001-s085><capture.aufzeichnen><en> You can capture video from any source directly into any format that your preinstalled codecs support (such as most popular WebM, XviD, 3IVX...).
<G-vec00169-001-s086><capture.aufzeichnen><de> Sie können Videoszenen (inklusive Audioteil) von einer DVD aufzeichnen, um sie in Ihrem CyberLink PowerDirector-Projekt zu verwenden.
<G-vec00169-001-s086><capture.aufzeichnen><en> You can capture video scenes (including the audio portion) from a DVD for use in your CyberLink PowerDirector project.
<G-vec00169-001-s087><capture.aufzeichnen><de> Aufgezeichnete Dateien zur Medienbibliothek hinzufügen: Wählen Sie diese Option aus, um aufgezeichnete Dateien direkt nach dem Aufzeichnen in die Medienbibliothek zu importieren.
<G-vec00169-001-s087><capture.aufzeichnen><en> Add captured files to media library: select this option to import captured files into the media library directly after capture.
<G-vec00169-001-s088><capture.aufzeichnen><de> Sie veränderten ein für allemal das Verhältnis zwischen Künstlern und Studio: Es war nun zu einem Ort für Experimente und Komposition geworden, und das Ziel einer Aufnahme überstieg das bloße Aufzeichnen einer Darbietung für die Reproduktion.
<G-vec00169-001-s088><capture.aufzeichnen><en> In the process, they once and for all changed the relationship between the artist and the studio: it had now become a place for experimentation and composition, and the aim of recording was no longer to merely capture a performance for playback.
<G-vec00169-001-s108><capture.aufzeichnen><de> BG SEX gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s108><capture.aufzeichnen><en> BG SEX does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s109><capture.aufzeichnen><de> Es verbindet ein ultraschnelles chromatisches Stimmgerät mit einem Metronom und einem digitalen Audiorecorder, um eine Übungssession aufzuzeichnen und das Ergebnis zu überprüfen.
<G-vec00169-001-s109><capture.aufzeichnen><en> It combines a digital audio recorder with a built-in high-speed chromatic tuner with metronome to capture a training session and review the results.
<G-vec00169-001-s110><capture.aufzeichnen><de> BongaCam Chat gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s110><capture.aufzeichnen><en> BongaCam Chat does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s111><capture.aufzeichnen><de> Das Gerät kann auch drahtlos eine Verbindung mit externen ANT+ Sensoren und anderen Geräten von Garmin herstellen, um zusätzliche Leistungsdaten aufzuzeichnen.
<G-vec00169-001-s111><capture.aufzeichnen><en> Your device can also wirelessly connect to external ANT+ sensors and other Garmin devices to capture even more performance data.
<G-vec00169-001-s112><capture.aufzeichnen><de> Einige Drohnen sind mit einer Kamera ausgestattet um die Umgebung während dem Flug aufzuzeichnen.
<G-vec00169-001-s112><capture.aufzeichnen><en> It is for internal use drone equipped with a camera to capture the surroundings from a height.
<G-vec00169-001-s113><capture.aufzeichnen><de> CAMSEX.SU gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s113><capture.aufzeichnen><en> CAMSEX.SU does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s114><capture.aufzeichnen><de> BBW Cams gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s114><capture.aufzeichnen><en> BBW Cams does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s115><capture.aufzeichnen><de> Darmowe Sex Kamerki gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s115><capture.aufzeichnen><en> Darmowe Sex Kamerki does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s116><capture.aufzeichnen><de> Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s116><capture.aufzeichnen><en> The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s117><capture.aufzeichnen><de> 69chat.me gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s117><capture.aufzeichnen><en> 69chat.me does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s118><capture.aufzeichnen><de> • Ereignisse von anderer Anwendung abfangen - Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s118><capture.aufzeichnen><en> • Intercept events from another application - The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s119><capture.aufzeichnen><de> Benutzerdefinierte Größe: Wählen Sie diese Option aus, um Bilder in der Größe aufzuzeichnen, die Sie auf der Registerkarte Screenshot im Fenster Einstellungen festgelegt haben.
<G-vec00169-001-s119><capture.aufzeichnen><en> Custom Size: select this option to capture images in the customized size specified on the Capture tab in the Settings window.
<G-vec00169-001-s120><capture.aufzeichnen><de> • Ereignisse von anderer Anwendung abfangen - Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s120><capture.aufzeichnen><en> • Intercept events from another application – The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s121><capture.aufzeichnen><de> Cams Avenue gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s121><capture.aufzeichnen><en> Cams Avenue does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s122><capture.aufzeichnen><de> Befolgen Sie nach dem Erstellen des Aufzeichnungsabbilds die Anweisungen im nächsten Abschnitt, um einen Computer mit dem Aufzeichnungsabbild zu starten und das Betriebssystem aufzuzeichnen.
<G-vec00169-001-s122><capture.aufzeichnen><en> After you have created the capture image, follow the instructions in the next section to boot a computer into the capture image and capture the operating system.
<G-vec00169-001-s123><capture.aufzeichnen><de> Verfügt über einen integrierten Datenlogger, um den Ereignisverlauf, Alarme und Kalibrierinformationen für den späteren Gebrauch aufzuzeichnen und zu speichern.
<G-vec00169-001-s123><capture.aufzeichnen><en> Incorporates a built-in logger to capture and store event history, alarms, and calibration information for later use.
<G-vec00169-001-s124><capture.aufzeichnen><de> Benutze eine Software wie tcpdump oder Wireshark, um die Daten aufzuzeichnen.
<G-vec00169-001-s124><capture.aufzeichnen><en> Use a software like tcpdump or wireshark to capture the data.
<G-vec00169-001-s125><capture.aufzeichnen><de> Das Bild wird Space sichtbar und Ihre Hologramme darüber platziert aufzuzeichnen.
<G-vec00169-001-s125><capture.aufzeichnen><en> The picture will capture both your visible space and your holograms placed on top of it.
<G-vec00169-001-s126><capture.aufzeichnen><de> Klinische Ausbildung auf höchstem Niveau An der Fakultät für Gesundheits- und Sozialwesen kommen darüber hinaus auch Panasonic Remote-Kameras zum Einsatz, um praktische Elemente der Kurse für Perioperativmediziner (ODPs) aufzuzeichnen.
<G-vec00169-001-s126><capture.aufzeichnen><en> Elsewhere within the Health and Social Care faculty, Panasonic remote cameras are used to capture practical elements of the University's Operating Department Practitioner (ODP) course.
