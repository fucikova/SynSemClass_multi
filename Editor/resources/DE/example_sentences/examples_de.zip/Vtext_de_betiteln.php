<G-vec00012-001-s093><entitle.betiteln><de> Du betitelst dein Leben.
<G-vec00012-001-s093><entitle.betiteln><en> You do entitle your life.
