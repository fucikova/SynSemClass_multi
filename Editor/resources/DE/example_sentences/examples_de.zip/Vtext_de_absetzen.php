<G-vec00081-001-s026><discontinue.absetzen><de> Darüber hinaus konnten 34% der Patienten andere Medikamente, darunter Opioide, Stimulanzien und Benzodiazepine, reduzieren oder absetzen.
<G-vec00081-001-s026><discontinue.absetzen><en> In addition, 34% of patients were able to decrease or discontinue other medications including opioids, stimulants, and benzodiazepines.
<G-vec00081-001-s027><discontinue.absetzen><de> Empire of Sports AG kann jeden Aspekt von EOS (einschließlich des Kontos), der Software, des Systems oder der Websites zu jeder Zeit ändern, modifizieren, einstellen oder absetzen und kann auch Einschränkungen für bestimmte Funktionen auferlegen oder Ihren Zugang zu Teilen oder der Gesamtheit des EOS-Eigentums ohne Mitteilung oder Haftung einschränken.
<G-vec00081-001-s027><discontinue.absetzen><en> Empire of Sports AG may change, modify, suspend, or discontinue any aspect of EOS (including the Account), the Software, System or the websites at any time and may also impose limits on certain features or restrict your access to parts or all of EOS Property without notice or liability.
<G-vec00081-001-s028><discontinue.absetzen><de> Es ist wichtig, dieses Medikament für den gesamten Zeitraum, für den es verschrieben wurde, weiter einzunehmen, da Patienten, die es absetzen, möglicherweise eine Rückkehr ihrer Symptome bemerken.
<G-vec00081-001-s028><discontinue.absetzen><en> It is important to continue taking this medication for the entire period of time for which it was prescribed, as patients who discontinue taking it may notice a return of their symptoms.
<G-vec00081-001-s029><discontinue.absetzen><de> Es gibt noch andere Gründe, warum wir ein Promo absetzen können (zum Beispiel ein unseres Tieres hasst, ist Casino, die Angebote zu werben, die nicht richtig oder wahr sind).
<G-vec00081-001-s029><discontinue.absetzen><en> There are other reasons why we may discontinue a promo (for example, one of our pet hates is casinos who advertise offers which are not accurate or true).
<G-vec00418-001-s076><drop.absetzen><de> Sie müssen dann den Fahrer auf Ihrem Rückweg am Parkplatz absetzen, bevor Sie Ihren Heimweg antreten.
<G-vec00418-001-s076><drop.absetzen><en> On your journey home, please drop off the driver at the car park, then continue your journey.
<G-vec00418-001-s077><drop.absetzen><de> 23:30 Uhr: Unser Abend neigt sich dem Ende zu, als wir Sie gegen Mitternacht in Ihrem Hotel absetzen.
<G-vec00418-001-s077><drop.absetzen><en> 11:30pm: Our evening will come to a close as we drop you back at your hotel for around midnight.
<G-vec00418-001-s078><drop.absetzen><de> Drahtglas mit laminierten verdrahtet oder wire Mesh, mit stärker Schlagzähigkeit, wenn Auswirkungen auf gewesen, ist Form ein radialer Spalt nicht absetzen verletzt Menschen, vor allem auf Hochhäuser und der Werkstatt] Gebäude unter den mächtigen erschütternder.
<G-vec00418-001-s078><drop.absetzen><en> Wired glass, laminated with wired or wire mesh, with stronger impact resistance, when been impacting, is form a radial crack not drop off to hurt human,mainly use on High-rise buildings and the workshop] building under the powerful concussive.
<G-vec00418-001-s079><drop.absetzen><de> Der Vorgang gleicht trotz der hohen Geschwindigkeit dem sanften Absetzen durch eine Dosiernadel.
<G-vec00418-001-s079><drop.absetzen><en> In spite its high speed the procedure resembles the gentle way of placing a drop with a dosing needle.
<G-vec00418-001-s080><drop.absetzen><de> Was passiert mit den Schrott Kabeldraht, nachdem Sie sie absetzen?Sie sind sortiert nach Material und in kleinere Stücke geschnitten.Die verarbeiteten Schrott ist verpackt und ausgeliefert, ein Unternehmen, das wieder schmilzt das Material und macht...
<G-vec00418-001-s080><drop.absetzen><en> What happens to the scrap cable wire after you drop them off They are sorted by material and sliced into smaller pieces The processed scrap is packaged and shipped to a company that re melts the materials and makes new products out of it An...
<G-vec00418-001-s081><drop.absetzen><de> Jede U-Bahn hat 15 Haltestellen, so dass sie Sie in der Nähe Ihres Endziels absetzen kann.
<G-vec00418-001-s081><drop.absetzen><en> Each tube has 15 stops, so it can drop you close to your final destination.
<G-vec00418-001-s082><drop.absetzen><de> Mit der linken Maustaste mit der Maus bewegen Sie den Fleisch und Fett absetzen.
<G-vec00418-001-s082><drop.absetzen><en> With the left mouse button with the mouse, move the meat and fat drop off.
<G-vec00418-001-s083><drop.absetzen><de> Der Helikopter muss nicht landen, er kann einfach darüber schweben und mit der Longline, Vorräte absetzen oder sogar Menschen aus engen Talwände retten.
<G-vec00418-001-s083><drop.absetzen><en> It doesn’t need to land, it can just hover above and use the long line to drop off supplies or even rescue people from narrow valley walls.
<G-vec00418-001-s084><drop.absetzen><de> Doch Klöden und Landis sind die Stärksten und können sich nach einer Temposteigerung des Deutschen wieder absetzen und das Ziel 25 Sekunden vor Sastre erreichen.
<G-vec00418-001-s084><drop.absetzen><en> But Klöden and Landis are the strongest and they can once again drop their opponents after an acceleration from the German to finish 25 seconds ahead of Sastre.
<G-vec00418-001-s085><drop.absetzen><de> Das Motorrad hätte mich an einer ganz anderen Stelle absetzen sollen.
<G-vec00418-001-s085><drop.absetzen><en> The motorcycle drop was to have been at an entirely different place.
<G-vec00418-001-s086><drop.absetzen><de> Unsere Gruppe wird Sie abholen und in Ihrer Unterkunft absetzen, damit Sie sich keine Sorgen machen müssen und Ihre Reise genießen können.
<G-vec00418-001-s086><drop.absetzen><en> Our group will pick you up and drop you off in your accommodation so you don’t have to worry and enjoy your trip.
<G-vec00418-001-s087><drop.absetzen><de> Der Shuttlefahrer wird Sie zum Flughafen Maastricht Aachen fahren und direkt vor dem Abflugsterminal absetzen.
<G-vec00418-001-s087><drop.absetzen><en> The shuttle driver will bring you to Maastricht Aachen Airport and drop you off in front of the departure terminal.
<G-vec00418-001-s088><drop.absetzen><de> Wenn es das Ziel wäre, die Rückseite der Sonne zu sehen, würde man bloß einen Satelliten nahe des Erdorbits absetzen und 6 Monate auf einen vollen 360 Grad Rundumblick warten müssen.
<G-vec00418-001-s088><drop.absetzen><en> If the goal were to see the backside of the Sun, one would merely have to drop a satellite near Earth's orbit and wait 6 months for a full 360 round view of the Sun.
<G-vec00418-001-s089><drop.absetzen><de> "In diesem Fall könnte man tatsächlich einen Passagier auf diesem Planeten absetzen und den Flug danach fortsetzen, da man ja nicht auf diesem Planeten ""gelandet"" ist."
<G-vec00418-001-s089><drop.absetzen><en> "In this case you could drop the passenger on this planet and indeed could continue your flight since you never in fact ""landed"" on the planet."
<G-vec00418-001-s090><drop.absetzen><de> "Wenn Sie jemanden zum Flughafen bringen, folgen Sie bitte den Schildern zum Abflug, ""Departures"", und benutzen Sie die äußere Spur, wenn Sie sie absetzen."
<G-vec00418-001-s090><drop.absetzen><en> If you are bringing someone to the airport follow the signs for 'Departures' and use the outside lane to drop them off.
<G-vec00418-001-s091><drop.absetzen><de> Eine bar, Restaurant-Buffet Buena Vista mit einer Vielzahl und Show-cooking, Snack-Bar geöffnet in der Hauptsaison genießen Sie leckere Snacks im Pool, einem Parkplatz wo Sie Ihr Fahrzeug, ein Friseur und ein Geschäft absetzen.
<G-vec00418-001-s091><drop.absetzen><en> A bar, restaurant buffet Buena Vista with a wide range and show cooking, the snack bar open in high season to enjoy delicious snacks in the pool, a parking lot where to drop off your vehicle, a Hairdresser and a shop.
<G-vec00418-001-s092><drop.absetzen><de> Lisa war spät dran für unsere Berufung und hatte keine Zeit zu Shelby absetzen, bevor er über für sie zu schießen.
<G-vec00418-001-s092><drop.absetzen><en> Lisa was running late for our appointment and didn't have time to drop Shelby off before coming over for her shoot.
<G-vec00418-001-s093><drop.absetzen><de> Wenn Sie uns nicht am Treffpunkt treffen können, können wir Sie abholen und in Ihrer Unterkunft absetzen.
<G-vec00418-001-s093><drop.absetzen><en> If you cannot meet us at the meeting point we can pick you up and drop you off in your accommodation.
<G-vec00418-001-s094><drop.absetzen><de> Reisebusse Wenn Sie mit dem Bus anreisen, möchten Sie Ihre Gruppe an einem günstig gelegenen Ort absetzen und wieder abholen.
<G-vec00418-001-s094><drop.absetzen><en> Coaches If you travel by coach, you probably want drop off and pick up your group at a suitable place.
<G-vec00301-001-s039><settle.absetzen><de> Für zwei Monate muss das Ganze nun lagern bis sich die Schwebstoffe absetzen und er langsam von oben herab den fertigen Honigschnaps abschöpfen kann.
<G-vec00301-001-s039><settle.absetzen><en> Everything then needs to be stored for 2 months until the suspended solids settle, and the finished honey schnapps can be slowly scooped off the top.
<G-vec00301-001-s040><settle.absetzen><de> Vor dem Verdünnen des Konzentrats sollte das Fläschchen mit dem Produkt aufgerührt werden, da die Insektizid-Mikrokapseln zwar sehr klein sind, jedoch ein gewisses Gewicht haben und sich allmählich absetzen.
<G-vec00301-001-s040><settle.absetzen><en> Before diluting the concentrate, the vial with the product should be stirred up, since the insecticide microcapsules, although very small, do have some weight and ways to gradually settle.
<G-vec00301-001-s041><settle.absetzen><de> Emulgatoren in Ölbadkonzentraten verteilen Fettstoffe oder Öle in Wasser und verhindern deren unerwünschtes Absetzen am Wannenrand.
<G-vec00301-001-s041><settle.absetzen><en> Emulsifiers in bath oil concentrates disperse fatty substances or oils in water and avoid that they settle at the bathtub.
<G-vec00301-001-s042><settle.absetzen><de> Holz ist bekannt, hat eine geringe Beständigkeit gegenüber Feuchtigkeit, dann auf der Formoberfläche absetzen kann.
<G-vec00301-001-s042><settle.absetzen><en> Wood is known, has a low resistance to moisture, then may settle on the mold surface.
<G-vec00301-001-s043><settle.absetzen><de> Vor der Anwendung wird empfohlen, aufrütteln, wie die Naturfasern kann am Boden absetzen.
<G-vec00301-001-s043><settle.absetzen><en> Before the application is recommended, shake up, as the natural fibers can settle to the bottom.
<G-vec00301-001-s044><settle.absetzen><de> Da Schadstoffe, die sich lange in der Luft befinden, insbesondere schädliche Gase, nicht oder kaum durch Absetzen abgeschieden werden, sind sie besonders gefährlich für Mensch, Umwelt und Maschine.
<G-vec00301-001-s044><settle.absetzen><en> Harmful substances, especially harmful gases, that remain in the air for a long time and do not settle fully or at all in the form of deposits, are extremely dangerous for employees, the environment and machines.
<G-vec00301-001-s045><settle.absetzen><de> Er kann einen kleinen Überschuss zu genehmigen und â € ~overrideâ € ™ System, aber jeder großen Überschuss sollte für eine Untersuchung nennen und vielleicht eine Forderung an den Kunden zu beweisen, dass er bald den Betrag absetzen können.
<G-vec00301-001-s045><settle.absetzen><en> He may approve a small excess and ‘override’ the system, but any large excess should call for an investigation and perhaps a demand on the customer to prove that he can settle the amount soon.
<G-vec00301-001-s046><settle.absetzen><de> An diesem Morgen fuhren wir wieder zurück auf dem Fluss, um eine Einsalzen von Papageien und Sittiche zu besuchen, sie früh morgens ankommen, um die Mineralsalze, die im Schlamm absetzen nehmen.
<G-vec00301-001-s046><settle.absetzen><en> That morning we sailed back down the river to visit a salting of parrots and parakeets, them arriving early every morning to take the mineral salts that settle in the mud.
<G-vec00301-001-s047><settle.absetzen><de> Beachten Sie, dass der Boden, wenn sie konzentriert ist sehr langsam und ungleichmäßig absetzen, eine Spur für die Jahre .
<G-vec00301-001-s047><settle.absetzen><en> Note that the ground unless it is concentrated will settle very slowly and unevenly, leaving a trace for years.
<G-vec00301-001-s048><settle.absetzen><de> In diesem Fall absetzen große Partikel auf den Boden und das Wasser dringt in den Boden.
<G-vec00301-001-s048><settle.absetzen><en> In this case large particles settle to the bottom and the water penetrates into the ground.
<G-vec00301-001-s049><settle.absetzen><de> Nette Begrüßung von den Eigentümern, die in allen absetzen wollen.
<G-vec00301-001-s049><settle.absetzen><en> Nice welcome from the owners who are trying to settle in all.
<G-vec00301-001-s050><settle.absetzen><de> Monster Hotel ist ein Spaß-Simulationsspiel, in dem Spieler Monster in Ihrem Hotel absetzen und stellen Sie sicher, sie waren glücklich.
<G-vec00301-001-s050><settle.absetzen><en> Monster Hotel is a fun simulation game in which players will settle monsters in your hotel and make sure they were happy.
<G-vec00301-001-s051><settle.absetzen><de> Sie können wählen, richtig zu essen in FLC Sam Son Golf Links oder Schritt für ein leckeres kulinarisches Erlebnis in einem bestimmten Lokal absetzen.
<G-vec00301-001-s051><settle.absetzen><en> You might choose to eat right in FLC Sam Son Golf Links or step out to settle in a certain eatery for a tasty culinary experience.
<G-vec00301-001-s052><settle.absetzen><de> Kein Absetzen in der Lidfalte.
<G-vec00301-001-s052><settle.absetzen><en> Won’t settle in the crease.
<G-vec00301-001-s053><settle.absetzen><de> Auf diese Weise können eingeschlossene Feuchtigkeit unter der Oberfläche zu erodieren und Membran Kondensat absetzen.
<G-vec00301-001-s053><settle.absetzen><en> This allows trapped moisture to erode under the finish and settle membrane condensate.
<G-vec00301-001-s054><settle.absetzen><de> "Die Dicke der Naht zwischen zwei horizontalen Reihen von Fliesen sollte nicht weniger als 3 mm: Schrumpf-Ziegelplatte ""Mail"" zur gleichen Zeit mit ihm absetzen."
<G-vec00301-001-s054><settle.absetzen><en> "The thickness of the seam between two horizontal rows of tiles should be not less than 3 mm: shrinkage brick tile ""mail"" will settle at the same time with him."
<G-vec00301-001-s055><settle.absetzen><de> In der Regel können sich die Wespen auf den gepflegten, sauberen und verglasten Balkonen physisch einfach nicht absetzen.
<G-vec00301-001-s055><settle.absetzen><en> In general, the wasps on the well-groomed, clean and glazed balconies just physically can not settle.
<G-vec00301-001-s056><settle.absetzen><de> Abwasser fließt in den Brunnen, große Teilchen absetzen, geht das Wasser durch den Boden.
<G-vec00301-001-s056><settle.absetzen><en> Wastewater flows into the well, large particles settle, the water goes through the soil.
<G-vec00301-001-s057><settle.absetzen><de> Letztendlich wird es absetzen, wie die alte Beiträge verfallen, aber dies war eine lästige Nebenwirkung.
<G-vec00301-001-s057><settle.absetzen><en> Ultimately it will settle out as the old posts expire, but this was an annoying side effect.
<G-vec00081-001-s037><discontinue.absetzen><de> Im Rahmen des gesetzlich Zulässigen behalten wir uns das Recht vor, die Forte Village Bestpreisgarantie nach unserem Ermessen und ohne vorherige Ankündigung jederzeit zu überarbeiten, zu korrigieren, aus- oder abzusetzen.
<G-vec00081-001-s037><discontinue.absetzen><en> To the extent permitted by law, we reserve the right to revise, amend, supplement, suspend or discontinue the Forte Village Best Rate Guarantee at any time in our sole discretion and without prior notice.
<G-vec00081-001-s240><discontinue.absetzen><de> Wenn eine leichte Reizung auftritt, setzen Sie das Produkt 1-2 Tage lang ab und setzen Sie es jeden zweiten Tag fort.
<G-vec00081-001-s240><discontinue.absetzen><en> If mild irritation occurs, discontinue use of the product for 1-2 days and continue using it every other day.
