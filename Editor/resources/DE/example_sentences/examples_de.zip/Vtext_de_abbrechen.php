<G-vec00081-001-s038><break.abbrechen><de> """Wenn wir bei der Hälfte eines Jobs abbrechen müssen, können wir die Einstellungen einfach speichern, einen anderen Job laufen lassen und später zu dem ursprünglichen Job zurückkehren."
<G-vec00081-001-s038><break.abbrechen><en> """If we need to break in the middle of a job, we can easily save the settings, run a different job and reset back to the previous job at a later time."
<G-vec00081-001-s039><break.abbrechen><de> Ich wollte schon abbrechen und hatte mir vorgenommen einen größeren Drachen zu bauen, da bemerkte ich, dass der Wind auffrischte.
<G-vec00081-001-s039><break.abbrechen><en> Also the kite was flying very bad and restless, too. I was ready to have a break and go home, as I felt that the wind was getting stronger.
<G-vec00081-001-s040><break.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00081-001-s040><break.abbrechen><en> 12 They will plunder your wealth and loot your merchandise; they will break down your walls and demolish your fine houses and throw your stones, timber and rubble into the sea.
<G-vec00081-001-s041><break.abbrechen><de> Oft kommt es auch vor, dass Aeste durch dieses enorme Gewicht abbrechen.
<G-vec00081-001-s041><break.abbrechen><en> It often happens that branches break under this enormous weight.
<G-vec00081-001-s042><break.abbrechen><de> Wenn Raubangriffe, die Eidechse sein eigenes Endstück als abbrechen können Mittel der Ablenkung.
<G-vec00081-001-s042><break.abbrechen><en> When a predator attacks, the lizard can break off its own tail as a means of distraction.
<G-vec00081-001-s043><break.abbrechen><de> Dann, beginnend an der Basis, biegen Sie die harten äußeren Blätter zurück, bis sie abbrechen.
<G-vec00081-001-s043><break.abbrechen><en> Then, starting at the base, bend the tough outer leaves back until they break off.
<G-vec00081-001-s044><break.abbrechen><de> Ohne Umstell-Rädchen, Lämpchen, Turbinen oder andere bewegliche Teile, die früher oder später abbrechen oder verkalken.
<G-vec00081-001-s044><break.abbrechen><en> No moving parts such as adjuster wheels, lights, turbines, or other components that will sooner or later break or calcify.
<G-vec00081-001-s045><break.abbrechen><de> Lucas Auer: Ich würde alle Teile, die leicht abbrechen können, vom Auto verbannen.
<G-vec00081-001-s045><break.abbrechen><en> Lucas Auer: I would ban all parts that can easily break off the car.
<G-vec00081-001-s046><break.abbrechen><de> 16:39 Und will dich in ihre Hände geben, daß sie deine Kapellen abbrechen und deine Altäre umreißen und dir deine Kleider ausziehen und dein schönes Gerät dir nehmen und dich nackt und bloß sitzen lassen.
<G-vec00081-001-s046><break.abbrechen><en> 16:39 I will also give you into their hand, and they shall throw down your vaulted place, and break down your lofty places; and they shall strip you of your clothes, and take your beautiful jewels; and they shall leave you naked and bare.
<G-vec00081-001-s047><break.abbrechen><de> Die For Each- Einstellung kann mit oder ohne die Schleife abbrechen, wenn -Einstellung definiert werden.
<G-vec00081-001-s047><break.abbrechen><en> The For Each setting can be specified with or without the Break Loop If setting.
<G-vec00081-001-s048><break.abbrechen><de> Ihren Deutschkurs sollten Sie auf keinen Fall vor dieser Stufe abbrechen, da Sie sonst das Gelernte schnell vergessen werden.
<G-vec00081-001-s048><break.abbrechen><en> Under no circumstances should you break off your German courses before this level, as otherwise you will quickly forget what you have learned.
<G-vec00081-001-s049><break.abbrechen><de> Als ich stehen blieb und eine Géanit des batailles betrachtete, die drei wundervolle Knospen trug, sah ich ganz deutlich, ganz nahe neben mir, einen der Stiele sich herumlegen, als ob eine unsichtbare Hand ihn gefaßt hätte, sah ihn abbrechen, wie wenn diese Hand ihn gepflückt.
<G-vec00081-001-s049><break.abbrechen><en> As I stopped to look at a Géant de Bataille, which had three splendid blooms, I distinctly saw the stalk of one of the roses bend, close to me, as if an invisible hand had bent it, and then break, as if that hand had picked it!
<G-vec00081-001-s050><break.abbrechen><de> Außerdem, ist es für die Frau die Nutzen für sie abbrechen, der Lage sein, einen Mann, der voll und ganz auf eine Beziehung begangen werden kann gerecht sein.
<G-vec00081-001-s050><break.abbrechen><en> In addition, it is for the woman's benefit to break it off, to be able to meet a man who can be fully committed to having a relationship.
<G-vec00081-001-s051><break.abbrechen><de> Der Sandsturm war so stark, dass wir auf halber Strecke abbrechen mussten.
<G-vec00081-001-s051><break.abbrechen><en> The sand storm was too strong so we had to break up the mission half way down.
<G-vec00081-001-s052><break.abbrechen><de> Jeden Tag Make-up zu tragen kann deine Wimpern austrocknen und deine Augen reizen, was bewirken kann, dass die Wimpern abbrechen oder sogar ausfallen.
<G-vec00081-001-s052><break.abbrechen><en> Wearing makeup every day can dry out your lashes and irritate your eyes, which can cause your lashes to break or even fall out.
<G-vec00081-001-s053><break.abbrechen><de> Nein (nervöses Gestammle), ich muss jetzt leider das Gespräch abbrechen.
<G-vec00081-001-s053><break.abbrechen><en> No (inaudible), I must unfortunately break the discussion off now, sorry.
<G-vec00081-001-s054><break.abbrechen><de> Diese Methode ist jedoch nicht so zuverlässig wie die Verwendung von Softwarelösungen, da der Download abbrechen kann oder der Dienst genau dann, wenn Sie ihn benötigen, ausfällt.
<G-vec00081-001-s054><break.abbrechen><en> This method is not as reliable as using software solutions though, as the download can break or the service may be down at exactly that moment when you need it.
<G-vec00081-001-s055><break.abbrechen><de> Großmutter würde ein Blatt von ihrem Aloe Vera Betrieb abbrechen und zu meiner Rettung kommen.
<G-vec00081-001-s055><break.abbrechen><en> Grandma would break off a leaf from her Aloe Vera plant and come to my rescue.
<G-vec00081-001-s056><break.abbrechen><de> "Klicken Sie im Dialogfeld ""Abbrechen"" auf das Symbol Alle Klicken Sie auf die Schaltfläche, um alle Mitglieder auszuwählen Ok Klicken Sie auf und dann auf Ja Schaltfläche im neuen Kutools für Outlook-Dialogfeld."
<G-vec00081-001-s056><break.abbrechen><en> In the Break dialog, click the All button to select all memebers, click the Ok button, and finally click the Yes button in the new Kutools for Outlook dialog.
<G-vec00081-001-s021><discontinue.abbrechen><de> Sie müssen möglicherweise ihre Ausbildung abbrechen, weil ihr Vater verfolgt wird und sie sich den Unterricht nicht mehr leisten können.
<G-vec00081-001-s021><discontinue.abbrechen><en> But they may have to discontinue their education because their father is being persecuted and they can't afford the tuition.
<G-vec00081-001-s022><discontinue.abbrechen><de> Sie sollten die Einnahme dieses Arzneimittels niemals abrupt abbrechen, wenn Sie mit der Einnahme begonnen haben, da dies zu Entzugserscheinungen führen kann.
<G-vec00081-001-s022><discontinue.abbrechen><en> You should never abruptly discontinue taking this medication once you have started taking it, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s023><discontinue.abbrechen><de> Nicht Behandlung abbrechen, es sei denn gesagt, so von Ihrem Arzt zu tun.
<G-vec00081-001-s023><discontinue.abbrechen><en> Do not discontinue treatment unless told to do so by your physician.
<G-vec00081-001-s024><discontinue.abbrechen><de> Bei Benchmark dürfen wir jegliche Produkte oder Dienste, teilweise oder ganz, entweder dauerhaft oder vorübergehend und ohne Ankündigung, überarbeiten, ändern, modifizieren oder abbrechen.
<G-vec00081-001-s024><discontinue.abbrechen><en> We at Benchmark can revise, change, modify, suspend or discontinue any of our products or services, in part or whole, either permanently or temporarily without any notice.
<G-vec00081-001-s025><discontinue.abbrechen><de> Patienten sollten die Einnahme dieses Medikaments niemals abrupt abbrechen, da dies zu Entzugssymptomen führen kann.
<G-vec00081-001-s025><discontinue.abbrechen><en> Patients should never abruptly discontinue taking this medication, as this may cause withdrawal symptoms.
<G-vec00081-001-s022><interrupt.abbrechen><de> Ein paarmal mussten wir zwischendurch abbrechen und eine Passage genauer durchgehen, aber im Grunde hab ich sie jetzt alle drauf.
<G-vec00081-001-s022><interrupt.abbrechen><en> Sometimes we had to interrupt and re-check a part, but basically I know them all by now.
<G-vec00081-001-s023><interrupt.abbrechen><de> Die Erhitzung abbrechen, sobald man den ganzen Kalk gut durcherhitzt hat und kaum noch Destillat übergeht.
<G-vec00081-001-s023><interrupt.abbrechen><en> Interrupt the heating as soon as all of the lime has been thoroughly heated and hardly any distillate develops.
<G-vec00081-001-s024><interrupt.abbrechen><de> Studien belegen auch, dass Männer eine Behandlung später als Frauen beginnen, diese abbrechen, oder sie nicht fortführen.
<G-vec00081-001-s024><interrupt.abbrechen><en> Studies show that men are more likely than women to start treatment late, to interrupt treatment and to be lost to treatment follow-up.
<G-vec00081-001-s025><interrupt.abbrechen><de> Während einer Verkehrsdurchsage können Sie die aktuelle Verkehrsdurchsage abbrechen, indem Sie kurz auf den Ein-/Ausschaltknopf drücken Abb.2.
<G-vec00081-001-s025><interrupt.abbrechen><en> While a traffic report is being played, you can interrupt the current traffic report by briefly pressing the ON/OFF button Fig.2.
<G-vec00081-001-s026><interrupt.abbrechen><de> Eine Unterbrechung der Dateiübertragung: Angenommen, Sie sind ein Bündel von Sony Vegas-Datei von Ihrer Festplatte auf USB-Laufwerk zu übertragen, dann, wenn Sie diesen Vorgang abbrechen, indem Sie Gerät trennen oder PC Absperren von Netzkabel abgetrennt wird, wird dies zu einem Verlust der Datei führt, die bei der Übertragung von Modus werden.
<G-vec00081-001-s026><interrupt.abbrechen><en> Interrupting file transfer process: Â Suppose you are transferring a bundle of Sony Vegas file from your hard disk to USB drive, then if you interrupt this process by disconnecting device or shutting PC off by unplugging power cable, this will leads to loss of file which are being in transferring mode.
<G-vec00081-001-s030><discontinue.abbrechen><de> Es ist wichtig, die Einnahme dieses Arzneimittels nach dem Beginn der Einnahme nicht abrupt abzubrechen, da dies zu Entzugserscheinungen führen kann.
<G-vec00081-001-s030><discontinue.abbrechen><en> It is important not to abruptly discontinue taking this medication once you have started taking it, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s031><discontinue.abbrechen><de> Nach dessen Erfolg beschloss er sein Studium abzubrechen und sich ausschließlich dem künstlerischen Schaffen zu widmen.
<G-vec00081-001-s031><discontinue.abbrechen><en> Following its success, he decided to discontinue his studies and concentrate fully on his artistic work.
<G-vec00081-001-s032><discontinue.abbrechen><de> Im Dezember 1273 rief er seinen Freund und Sekretär Reginald zu sich, um ihm seinen Entschluß mitzuteilen, alle Arbeiten abzubrechen, da er während der Feier der Messe infolge einer übernatürlichen Offenbarung verstanden hatte, daß alles, was er bisher geschrieben hatte, nichts weiter als »ein Haufen Spreu« war.
<G-vec00081-001-s032><discontinue.abbrechen><en> "In December 1273, he summoned his friend and secretary Reginald to inform him of his decision to discontinue all work because he had realized, during the celebration of Mass subsequent to a supernatural revelation, that everything he had written until then ""was worthless""."
<G-vec00081-001-s033><discontinue.abbrechen><de> Talk Online Panel behält sich das Recht vor, fristlos und nach alleinigem Ermessen oder vom Gesetz oder lokalen Autoritäten angeordnet, seine Geschäfte in einem speziellen Land oder überall abzubrechen oder zu beenden, womit auch individuelle Konten geschlossen werden, was zum jeweiligen Verfall der Punkte führt.
<G-vec00081-001-s033><discontinue.abbrechen><en> Talk Online Panel reserves the right, without notice and in its sole discretion, on its own volition or as dictated by law or local authorities, to discontinue or terminate its operation in a particular country or overall, thus also terminating individual accounts, leading to the forfeiture of points therein.
<G-vec00081-001-s034><discontinue.abbrechen><de> EnergyCasino behält sich das Recht vor, die Cash Rewards Aktion nach eigenem Ermessen der Firma zu verändern oder abzubrechen.
<G-vec00081-001-s034><discontinue.abbrechen><en> EnergyCasino reserves the right to alter or discontinue the Cash Rewards promotion at the company's sole discretion. English English
<G-vec00081-001-s035><discontinue.abbrechen><de> """Sie versuchten uns zu zwingen, das Programm abzubrechen."
<G-vec00081-001-s035><discontinue.abbrechen><en> """They attempted to force us to discontinue the programme."
<G-vec00081-001-s027><interrupt.abbrechen><de> Zürich Tourismus ist berechtigt, jederzeit Verbesserungen oder Änderungen an der Aktion vorzunehmen sowie die Aktion ohne Angabe von Gründen auszusetzen, abzubrechen oder zu beenden.
<G-vec00081-001-s027><interrupt.abbrechen><en> Zürich Tourism is entitled to improve or modify the terms and conditions of the competition at any time, as well as to abandon, interrupt or discontinue the competition without giving any reason.
<G-vec00081-001-s028><interrupt.abbrechen><de> Die Sandoz-Familienstiftung behält sich die Möglichkeit vor, das Programm abzubrechen, wobei bereits angestellte Begünstigte bis zum Ablauf ihres Arbeitsvertrags finanziert werden.
<G-vec00081-001-s028><interrupt.abbrechen><en> The Sandoz Family Foundation reserves the right to interrupt the programme, in which case beneficiaries already employed will continue to receive funding until their contracts expire.
<G-vec00081-001-s029><interrupt.abbrechen><de> Um den Update-Vorgang abzubrechen, klicken Sie auf Update abbrechen .
<G-vec00081-001-s029><interrupt.abbrechen><en> To interrupt the update click Cancel update .
<G-vec00081-001-s088><discontinue.abbrechen><de> Haben Sie dann immer noch Beschwerden, brechen Sie die Behandlung ab und sprechen Sie mit Ihrem Zahnarzt.
<G-vec00081-001-s088><discontinue.abbrechen><en> Again, if the discomfort continues, discontinue the treatment and consult your dental professional.
<G-vec00081-001-s106><discontinue.abbrechen><de> Wenn Sie die Übersetzung vor Abschluss der Übersetzung abbrechen, erstellen Sie die tmx-Dateien für die Übersetzungen, die Sie erstellt haben, und laden Sie sie in das Translation Memory-Repository hoch.
<G-vec00081-001-s106><discontinue.abbrechen><en> If you discontinue before completing the translation, please do create the tmx files for the you have done and upload them to the translation memory repository.
<G-vec00081-001-s107><discontinue.abbrechen><de> Bei starkem Brennen, die Anwendung abbrechen.
<G-vec00081-001-s107><discontinue.abbrechen><en> In thecase of excessive burning, discontinue use.
<G-vec00081-001-s108><discontinue.abbrechen><de> Aber halten Sie die Vorsichtsmaßnahmen im Auge - wenn die Haut erscheint gereizt oder sogar noch mehr, Wunden, die Behandlung abzubrechen und sofort mit Ihrem Hautarzt konsultieren.
<G-vec00081-001-s108><discontinue.abbrechen><en> But keep in mind the precautions - if the skin appears irritated or even more so, sores, discontinue treatment and immediately consult your dermatologist.
<G-vec00081-001-s186><discontinue.abbrechen><de> GPRO behält sich das Recht vor, von Zeit zu Zeit, zu jeder Zeit, ohne Benachrichtigung den Service (oder einen Teil davon), zu modifizieren oder, entweder kurzzeitig oder permanent, abzubrechen.
<G-vec00081-001-s186><discontinue.abbrechen><en> GPRO reserves the right from time to time, at any time, to modify or discontinue, temporarily or permanently, the Service (or any part thereof) with or without notice.
<G-vec00081-001-s192><discontinue.abbrechen><de> Wenn einer dieser Fälle passieren dann sollte man den Lauf abbrechen und einen Arzt sofort aufsuchen.
<G-vec00081-001-s192><discontinue.abbrechen><en> If any of these happen then one should discontinue the course and consult a medical professional immediately.
<G-vec00081-001-s206><discontinue.abbrechen><de> Er kann seine Daten bis zur Betätigung der Schaltfläche „Complete Registration“ jederzeit korrigieren oder die Registrierung durch Schließen seines Browserfensters oder Betätigung der Schaltfläche „Zurück“ seines Browsers abbrechen.
<G-vec00081-001-s206><discontinue.abbrechen><en> "It can correct its data at all times until the ""Complete Registration"" button is pressed or discontinue the registration by closing its browser window or pressing the ""Back"" button of its browser."
<G-vec00081-001-s270><discontinue.abbrechen><de> interVista behält sich das Recht vor, zu jeglicher Zeit und von Zeit zu Zeit die Services (oder Teile davon) mit oder ohne Ankündigung zu aktualisieren, vorübergehend oder dauerhaft zu unterbrechen oder abzubrechen.
<G-vec00081-001-s270><discontinue.abbrechen><en> Escapia Inc. reserves the right at any time and from time to time to modify or discontinue, temporarily or permanently, the Services (or any part thereof) with or without notice.
<G-vec00081-001-s282><discontinue.abbrechen><de> Eine Unverträglichkeit des Arzneimittels ist äußerst selten, aber wenn eine allergische Reaktion festgestellt wird, muss der Verlauf des Vitaminpräparats abgebrochen und ein Arzt konsultiert werden.
<G-vec00081-001-s282><discontinue.abbrechen><en> Intolerance of the drug is extremely rare, but if an allergic reaction is identified, it is necessary to discontinue the course of the vitamin preparation and consult a doctor.
