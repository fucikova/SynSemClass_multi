<G-vec00301-001-s133><fix.beseitigen><de> Ein neues Update ist verfügbar, um diese Schwachstellen zu beseitigen.
<G-vec00301-001-s133><fix.beseitigen><en> An Update is available to fix this issue.
<G-vec00301-001-s134><fix.beseitigen><de> Der Zeitaufwand um entdeckte Fehler zu beseitigen singt dadurch drastisch.
<G-vec00301-001-s134><fix.beseitigen><en> The time required to fix detected errors is reduced drastically.
<G-vec00301-001-s135><fix.beseitigen><de> Es gab einige Probleme mit der Stromversorgung und dem Kühlschrank, was aber dadurch wett gemacht wurde, dass der Vermieter umgehend reagiert hat (am Wochenende), um die Probleme zu beseitigen.
<G-vec00301-001-s135><fix.beseitigen><en> There were some problems with the power supply and the fridge, which was made up for by the landlord responding promptly (on weekends) to fix the problems.
<G-vec00301-001-s136><fix.beseitigen><de> Die protokollierten Daten werden verwendet, um Störungen oder Fehler an den Systemen, die für das Web-Angebot der Universität Konstanz erforderlich sind, zu erkennen, einzugrenzen oder zu beseitigen.
<G-vec00301-001-s136><fix.beseitigen><en> The logged information is used to identify, isolate and fix disruptions or errors in the systems needed to operate the University of Konstanz web pages.
<G-vec00301-001-s137><fix.beseitigen><de> Das Überprüfen einer Partition hilft beim Eingrenzen und Beseitigen von Problemen im Dateisystem.
<G-vec00301-001-s137><fix.beseitigen><en> Checking a partition will attempt to find and fix problems in the file system.
<G-vec00301-001-s138><fix.beseitigen><de> Wenn wir diese Programmfehler innerhalb einer Woche nicht beseitigen können.
<G-vec00301-001-s138><fix.beseitigen><en> If we can’t fix these bugs within one week.
<G-vec00301-001-s139><fix.beseitigen><de> Ein stündlich stattfindender Expertenvortrag (abwechselnd in englischer und deutscher Sprache) zum Thema „Debugging von Embedded-Vision-Anwendungen“ zeigt, wie Entwickler von IBV-Anwendungen auf einer Embedded-Plattform Programmfehler schneller finden und beseitigen können.
<G-vec00301-001-s139><fix.beseitigen><en> Presentations by experts (held every hour, alternately in English and German) on the topic of “Debugging of Embedded Vision Applications” will demonstrate how developers of machine vision applications can find and fix programming errors in embedded platforms more quickly.
<G-vec00301-001-s140><fix.beseitigen><de> So, Ihr Computer erhielt durch Budak angegriffen und wahrscheinlich auch Sie haben versucht, es tatsächlich verlorene Zeit manuell zu beseitigen.
<G-vec00301-001-s140><fix.beseitigen><en> So, your device got attacked by Bopador and also probably you have actually lost time trying to fix it manually.
<G-vec00301-001-s141><fix.beseitigen><de> Aktualisierte java-1.7.0-ibm Pakete, welche mehrere Schwachstellen beseitigen, sind jetzt für Red Hat Enterprise Linux 6 verfügbar.
<G-vec00301-001-s141><fix.beseitigen><en> Updated kernel packages that fix multiple security issues are now available for Red Hat Enterprise Linux 6.
<G-vec00301-001-s142><fix.beseitigen><de> Aus diesem Grund müssen diese ungültigen JS-Registryeinträge repariert werden, um die Wurzel des Problems zu beseitigen.
<G-vec00301-001-s142><fix.beseitigen><en> Thus, these invalid JS registry entries need to be repaired to fix the root of the problem.
<G-vec00301-001-s143><fix.beseitigen><de> Mithilfe dieser Konfigurationsoption können Sie dieses Ärgernis allerdings beseitigen.
<G-vec00301-001-s143><fix.beseitigen><en> You can fix this annoyance by using this configuration option, though.
<G-vec00301-001-s144><fix.beseitigen><de> Beide Hemmnisse konnten wir durch den Sunny Boy Smart Energy beseitigen.
<G-vec00301-001-s144><fix.beseitigen><en> The Sunny Boy Smart Energy was able to fix both issues.
<G-vec00301-001-s145><fix.beseitigen><de> Als Reaktion auf die unmittelbare und überwältigende Resonanz auf das Spiel hat das Team rund um die Uhr daran gearbeitet, alle Regionen zu unterstützen, die Kapazitäten zu erhöhen, unsere Rechenzentren mit zusätzlicher Hardware auszustatten und Bugs zu beseitigen.
<G-vec00301-001-s145><fix.beseitigen><en> In response to the immediate and overwhelming demand for the game, the team worked around the clock to support all regions, increase capacity, ship additional hardware to our datacenters, and troubleshoot and fix bugs as they sprang up.
<G-vec00301-001-s146><fix.beseitigen><de> Aus diesem Grund müssen diese ungültigen CAB-Registryeinträge repariert werden, um die Wurzel des Problems zu beseitigen.
<G-vec00301-001-s146><fix.beseitigen><en> Thus, these invalid CAB registry entries need to be repaired to fix the root of the problem.
<G-vec00301-001-s147><fix.beseitigen><de> Alles in allem ist der relativ preiswerte Antec DF500 RGB Midi-Tower durchaus schick anzusehen und erleichtert den Bau des PC Systems mit einigen Features, zeigt aber noch ein paar Schwächen, die Antec in einem kleinen Update beseitigen könnte.
<G-vec00301-001-s147><fix.beseitigen><en> All in all, the relatively inexpensive Antec DF500 RGB midi tower is quite fancy to look at and makes it easier to build the PC system with some features, but still shows some weaknesses that Antec could fix in a small update.
<G-vec00301-001-s148><fix.beseitigen><de> Wenn diese Fehlermeldungen auf ein Konfigurationsproblem mit dem X-Server hinweisen, versuchen Sie, diese Probleme zu beseitigen.
<G-vec00301-001-s148><fix.beseitigen><en> If these error messages hint at a configuration problem in the X server, try to fix these issues.
<G-vec00301-001-s149><fix.beseitigen><de> Auf Sicherheitsprobleme achten und sie beseitigen, bevor irgendjemand anders es tut.
<G-vec00301-001-s149><fix.beseitigen><en> Pay attention to security problems and fix them before anyone else does.
<G-vec00301-001-s150><fix.beseitigen><de> Aktualisierte Kernel Pakete, die eine Schwachstelle beseitigen, sind ab sofort für Red Hat Enterprise Linux 6.1 verfügbar.
<G-vec00301-001-s150><fix.beseitigen><en> Updated kernel packages that fix one security issue are now available for Red Hat Enterprise Linux 6.1 Extended Update Support.
<G-vec00301-001-s151><fix.beseitigen><de> Wir werden diese Inkonsistenz eines Tages beseitigen.
<G-vec00301-001-s151><fix.beseitigen><en> We will fix the inconsistency someday.
<G-vec00301-001-s229><resolve.beseitigen><de> Zweifachinteraktionen erfordern für Standard-Screening-Designs mit einer ähnlichen Anzahl von Durchläufen weitere Folgeversuche, um Unklarheiten zu beseitigen.
<G-vec00301-001-s229><resolve.beseitigen><en> And if there are two-factor interactions, standard screening designs with a similar number of runs will require follow-up experimentation to resolve the ambiguity.
<G-vec00301-001-s230><resolve.beseitigen><de> HP hat Upgrades zur Verfügung gestellt, um diese Schwachstelle zu beseitigen.
<G-vec00301-001-s230><resolve.beseitigen><en> HP has provided upgrades to resolve this vulnerability.
<G-vec00301-001-s231><resolve.beseitigen><de> Fachkundige Swisscom Mitarbeitende beseitigen Hardware- und Software-Störungen rasch und kompetent.
<G-vec00301-001-s231><resolve.beseitigen><en> Competent Swisscom employees resolve hardware and software problems quickly and professionally.
<G-vec00301-001-s232><resolve.beseitigen><de> Es ist wichtig zu verstehen, dass im Banken- und Finanzsektor Zahlungsausfälle ein unvermeidlicher Teil der Geschäftstätigkeit sind und das letztendliche Ergebnis davon abhängt, wie gut das Unternehmen in der Lage ist, diese zu beseitigen, wie viel Risiko es eingegangen und wie die Besicherung der Investition gestaltet ist.
<G-vec00301-001-s232><resolve.beseitigen><en> It is important to understand that, in the banking and financial sector, defaults are an inevitable part of doing business and that the eventual outcome depends on how well the company is able to resolve them, how much exposure they have taken on, and what is the security for the investment.
<G-vec00301-001-s233><resolve.beseitigen><de> Um wissenschaftliche Unsicherheiten beseitigen zu können, fördert das Bundesamt für Strahlenschutz weitere Forschung zum Thema elektrische und magnetische Felder .
<G-vec00301-001-s233><resolve.beseitigen><en> In order to resolve scientific uncertainties, the Federal Office for Radiation Protection supports further research on the subject of electric and magnetic fields .
<G-vec00301-001-s234><resolve.beseitigen><de> Einzig und allein die Person, die von Gott erwählt und gesalbt ist, kann dieses Problem beseitigen.
<G-vec00301-001-s234><resolve.beseitigen><en> Only the person who is approved and anointed by God can resolve that problem.
<G-vec00301-001-s235><resolve.beseitigen><de> Die Master Energy Control (MEC) Remote von Bosch ermöglicht es, bei Blockheizkraftwerken online Software-Updates und Ferndiagnosen durchzuführen oder Fehler zu beseitigen, ohne vor Ort zu sein.
<G-vec00301-001-s235><resolve.beseitigen><en> The Master Energy Control (MEC) Remote by Bosch makes it possible to update the software, carry out remote diagnostics, and resolve malfunctions for CHP plants without a technician having to be on site.
<G-vec00301-001-s236><resolve.beseitigen><de> Diese Frucht schmilzt Fetten und Cholesterin im Körper gerade die Dinge, die Sie zu beseitigen, Gewicht zu verlieren.
<G-vec00301-001-s236><resolve.beseitigen><en> Grapefruit. This fruit melts fat and cholesterol in the body-thing that you want to resolve to lose weight.
<G-vec00301-001-s237><resolve.beseitigen><de> Somit ist das Hygiene-Institut des Ruhrgebiets in der Lage, nachteilige Veränderungen in unserer Umwelt frühzeitig zu erkennen, ihre Auswirkungen auf den Menschen zu analysieren, die Ursachen möglichst schnell zu ermitteln und diese so effektiv vor allem jedoch so gründlich wie möglich zu beseitigen.
<G-vec00301-001-s237><resolve.beseitigen><en> Taking this into account, the Institute of Environmental Hygiene and Environmental Medicine is able to detect adverse environmental effects early. Thus we are able to analyze such effects in relation to their impact on human health, determine their cause and resolve the issue as quickly and thoroughly as possible.
<G-vec00301-001-s238><resolve.beseitigen><de> Bei intelligenter Korrelation des Pegelsignals lassen sich nicht nur die Funktionsbereitschaft der Anlage erkennen, sondern auch schon bereits beginnende Abweichungen erfassen und im Sinne einer vorausschauenden Verfügbarkeitsanalyse (prädiktive Instandhaltung) interpretieren und gegebenenfalls vor Beginn des Produktionsloses beseitigen.
<G-vec00301-001-s238><resolve.beseitigen><en> Intelligent correlation of the level signal not only shows the system is ready for operation, but already detects early deviations and in the sense of predictive availability analysis (predictive service) interpret and if necessary resolve these prior to beginning the production batch.
<G-vec00301-001-s239><resolve.beseitigen><de> Die nächste Phase des Programms wird die geplante künstliche Stimulation und Produktionstests umfassen, um eine Reihe bestehender Ungewissheiten zu beseitigen, einschließlich der Möglichkeit, komplexe künstliche Bruchsysteme im HRZ mittels der geplanten Stimulation zu erstellen.
<G-vec00301-001-s239><resolve.beseitigen><en> The next phase of the program will comprise the planned artificial stimulation and production testing, which will aim to resolve a number of current uncertainties, including whether complex artificial fracture systems can be created within the HRZ via the proposed stimulation.
<G-vec00301-001-s240><resolve.beseitigen><de> Volkswagen arbeitet intensiv daran, die Unregelmäßigkeiten mit geeigneten technischen Maßnahmen zu beseitigen und steht dazu auch in Kontakt mit den zuständigen Behörden sowie dem Deutschen Kraftfahrtbundesamt.
<G-vec00301-001-s240><resolve.beseitigen><en> Volkswagen is working hard to resolve the irregularities by appropriate technical measures and is also in contact with the responsible authorities as well as with the German Federal Motor Transport Authority (KBA).
<G-vec00301-001-s241><resolve.beseitigen><de> Sie können schnell die richtigen Entscheidungen treffen und mögliche Probleme beseitigen.
<G-vec00301-001-s241><resolve.beseitigen><en> They can quickly make the right decisions and resolve any possible issues.
<G-vec00301-001-s242><resolve.beseitigen><de> Falls der Endanbieter der Dienstleistung nicht in der Lage ist die reklamierten Mängel zu beseitigen und die Agentur keine Möglichkeit hat eine Ersatzunterkunft anzubieten, wird die Agentur auf eigene Kosten die Rückzahlung des eingezahlten Betrages leisten.
<G-vec00301-001-s242><resolve.beseitigen><en> If the service provider is not able to resolve the reported shortfalls and the Agency is not able to offer alternative accommodation, the Agency will refund on its own expenses the paid amount.
<G-vec00301-001-s243><resolve.beseitigen><de> Es nannte sich Zet und machte sich zur Aufgabe, die Disharmonie zu beseitigen und alle Dinge zu perfekter Einheit zurückzuführen.
<G-vec00301-001-s243><resolve.beseitigen><en> Naming itself Zet, this intellect sought to resolve the disharmony and return all to perfect unity.
<G-vec00301-001-s244><resolve.beseitigen><de> Diese äußerst peinlichen Einwände der Laien nur mit Gewalt zu unterdrücken und nicht durch vernünftige Gegenargumente zu beseitigen heißt, die Kirche und den Papst dem Gelächter der Feinde auszusetzen und die Christenheit unglücklich zu machen.
<G-vec00301-001-s244><resolve.beseitigen><en> To repress these very sharp arguments of the laity by force alone, and not to resolve them by giving reasons, is to expose the church and the pope to the ridicule of their enemies and to make Christians unhappy.
<G-vec00301-001-s245><resolve.beseitigen><de> Er hoffte, dass der indische Meister ihm nicht nur dabei helfen würde, den Buddhismus in Tibet wieder fest zu verankern, sondern auch Unklarheiten zu beseitigen, die sich aus Differenzen zwischen den verschiedenen Schulen ergeben hatten.
<G-vec00301-001-s245><resolve.beseitigen><en> He hoped that the Indian master would be able to help not only reestablish Buddhism in Tibet, but also resolve confusion based on differences among the schools.
